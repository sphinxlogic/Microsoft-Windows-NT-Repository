/* $XConsortium: useropt.h,v 1.2 91/05/11 10:00:34 rws Exp $ */

#define	INCL_LCD	1
#define	STATIC_ALLOC	1

#define	INCL_BLACK	1
#define	INCL_SCREEN	1
#define	INCL_2D		1
#define	SHORT_LISTS	0

#define	INCL_RULES	1
#define	INCL_METRICS	1

#define	INCL_KEYS	1
