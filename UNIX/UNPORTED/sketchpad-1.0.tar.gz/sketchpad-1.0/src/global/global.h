/* global.h 5.9.1991 JU */

/* 25.11.1991 : display name length extented to 32 Bytes (Manfred Schendel) */

/* MGS */

#ifndef __GLOBAL_H
#define __GLOBAL_H

#ifdef i386
/* #include <sys/bsdtypes.h> */
#include <sys/param.h>
#else
#include <sys/param.h>
#endif 

#define MAXUSERNAMELEN    30
#define MAXDISPLAYNAMELEN 32
#ifndef MAXHOSTNAMELEN
#  define MAXHOSTNAMELEN  32
#endif
#define TEXTLEN           80

#endif /* __GLOBAL_H */

