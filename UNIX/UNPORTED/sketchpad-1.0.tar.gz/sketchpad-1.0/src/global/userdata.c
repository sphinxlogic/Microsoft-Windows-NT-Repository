/* ========================================================================== */
/*                                                                            */
/* Filename:     userdata.c                       +-----+-----+--+--+--+--+   */
/* Version :     1.3	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/10/92	20:42:36	                      */
/*                                                                            */
/* ========================================================================== */

#include <malloc.h>
#include <stdio.h>
#include <string.h>

#include "userdata.h"
#include "global.h"
#include "../misc/list.h"
#include "../misc/sperror.h"

#ifdef _AIX
extern void* malloc (size_t);
extern int free (void*);
#endif

typedef struct
  {
    int  ident;
    char name[MAXUSERNAMELEN+1];
    char display[MAXDISPLAYNAMELEN+1];
    char host[MAXHOSTNAMELEN+1];
  } userStruct;

static list userList;

/* InitUserdata initializes this modul */

void InitUserdata (void)
{
  userList = CreateList ();
  SetFreeFunction (userList, (void (*)(void*)) free);
}

/* DeInitUserdata frees all resources held by this modul */

void DeInitUserdata (void)
{
  FreeList (userList);
}

/* NewUser add the data of the new user to the existing data */

void NewUser (int ident, char *name, char *display, char *host)
{
  userStruct *data,      /* pointer to the new userdata structure */
             *compdata,  /* pointer to the userdata structure already in */
                         /* the list to compare with new one */
             *first;     /* pointer the first userdata structure in the list */
  
  /* alloc memory and fill in the new user data */
  data = (userStruct*) malloc (sizeof (userStruct));
  if (data == NULL)
  {
    sperror ("userdata.c(54): cannot alloc memory for userdata");
    return;
  }
  data->ident = ident;
  strcpy (data->name, name);
  strcpy (data->display, display);
  strcpy (data->host, host);

  /* find the position in the list to insert the new user data */
  FirstEntry (userList);
  if (GetListState (userList) != E_OK)
  {
    /* it's the one and only entry in the list */
    InsertEndEntry (userList, data);
  }
  else
  {
    /* there are existing entries in the list */
    compdata = GetEntry (userList);
    first    = compdata;
    /* find the first userdata structure in the list whose ident */
    /* is greater the new ident */
    while (compdata->ident < ident)
    {
      NextEntry (userList);
      if (GetListState (userList) != E_OK)
      {
        break;
      }
      compdata = GetEntry (userList);
    }
    if (GetListState (userList) == E_OK)
    {
      if (compdata->ident == ident)
      {
        char string[80];

        sprintf (string, "userdata.c(101): cannot insert two user with the"
                         "same id or id is wrong error %d %d",
                         compdata->ident, ident);
        sperror (string);
        return;
      }
      /* determin where to put the new list element */
      if (first == compdata)
      {
        /* put it at the beginning of the list */
        InsertBeginEntry (userList, data);
      }
      else
      {
        PreviousEntry (userList);
        InsertEntry (userList, data);
      }
    }
    else
    {
      InsertEndEntry (userList, data);
    }
  }
}

/* RemoveUser deletes the data from the specified user from the data-base */

void RemoveUser (int ident)
{
  userStruct *data;

  FirstEntry (userList);
  /* is there anyone in this list ? */
  if (GetListState (userList) == E_OK)
  {
    data = GetEntry (userList);
    while ((GetListState (userList) == E_OK) && (data ->ident != ident))
    {
      NextEntry (userList);
      data = GetEntry (userList);
    }
    /* entry with user number ident found ? */
    if (GetListState (userList) == E_OK)
    {
      DeleteEntry (userList);
    }
  }
}

/* GetFirstUser returns the data of the user with the lowest identification */

void GetFirstUser (int *ident, char **name, char **display, char **host)
{
  userStruct *data;

  FirstEntry (userList);
  if (GetListState (userList) == E_OK)
  {
    data = GetEntry (userList);
    *ident   = data->ident;
    *name    = data->name;
    *display = data->display;
    *host    = data->host;
  }
  else
  {
    *ident = -1;
  }
}

/* GetNextUser returns the data of the user with the identification */
/* next to the last returned identification */

void GetNextUser (int *ident, char **name, char **display, char **host)
{
  userStruct *data;

  NextEntry (userList);
  if (GetListState (userList) == E_OK)
  {
    data = GetEntry (userList);
    *ident   = data->ident;
    *name    = data->name;
    *display = data->display;
    *host    = data->host;
  }
  else
  {
    *ident = -1;
  }
}

/* GetUserNameFromId returns the username corresponding to the */
/* sketchpad identification in ident */

char *GetUserNameFromId (int ident)
{
  userStruct *data;

  FirstEntry (userList);
  while (GetListState (userList) == E_OK)
  {
    data = GetEntry (userList);
    if (data->ident == ident)
    {
      return data->name;
    }
    NextEntry (userList);
  }
  return NULL;
}

/* end of userdata.c */

