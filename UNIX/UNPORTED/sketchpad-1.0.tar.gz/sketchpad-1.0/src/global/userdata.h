/* userdata.h 5.9.1991 JU */

#ifndef __USERDATA_H
#define __USERDATA_H

/* InitUserdata initializes this modul */

void InitUserdata (void);

/* DeInitUserdata frees all resources held by this modul */

void DeInitUserdata (void);

/* NewUser add the data of the new user to the existing data */

void NewUser (int ident, char *name, char *display, char *host);

/* RemoveUser deletes the data of the specified user from the data-base */

void RemoveUser (int ident);

/* GetFirstUser returns the data of the user with the lowest identification */

void GetFirstUser (int *ident, char **name, char **display, char **host);

/* GetNextUser returns the data of the user with the identification */
/* next to the last returned identification */

void GetNextUser (int *ident, char **name, char **display, char **host);

/* GetUserNameFromId returns the username corresponding to the */
/* sketchpad identification in ident */

char *GetUserNameFromId (int ident);

#endif /* __USERDATA_H */

/* end of userdata.h */

