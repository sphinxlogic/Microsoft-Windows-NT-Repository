#include <Mrm/MrmAppl.h>                   /* Motif Toolkit */

extern int ownUserNumber;
extern int new_user_flag;

extern int Init_Communication (char**);
extern void Exit_Communication (void);
extern void msg_draw_point();
extern void msg_draw_line();
extern void msg_load_pic();
extern void msg_cannot_load_pic();
extern void msg_pic_to_load();
extern void msg_pic_not_loaded();
extern void msg_quit();
extern void msg_end_pointer();
extern void msg_start_pointer();
extern void msg_start_pointer_to();
extern void msg_move_pointer();
extern void msg_tell_address();
extern void msg_clear();
extern void msg_start_freehand();
extern void msg_end_freehand();
extern void msg_erase_object();
extern void msg_write_object();
extern void msg_size_object();
extern void msg_move_object();
extern void msg_set_layer_color();
extern void msg_sync_user();
extern void msg_new_user ();
extern void msg_new_layer ();
extern void msg_rename_layer ();
extern void msg_kill_layer ();
extern void msg_clear_layer ();
extern void msg_draw_text ();
extern void msg_draw_rectangle();
extern void msg_draw_arc();
extern void msg_apply_zoom();
extern void msg_audio();

