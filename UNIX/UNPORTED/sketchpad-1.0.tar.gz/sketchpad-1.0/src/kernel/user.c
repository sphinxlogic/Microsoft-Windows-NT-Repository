/* ========================================================================== */
/*                                                                            */
/* Filename:     user.c                           +-----+-----+--+--+--+--+   */
/* Version :     1.9	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/17/92	17:26:52	                      */
/*                                                                            */
/* ========================================================================== */

# include <stdio.h>
# include <sys/stat.h>
# include <malloc.h>
# include <signal.h>

# include <X11/Xlib.h>                    /* X11 datatypes */
# include <Mrm/MrmAppl.h>                 /* Motif Toolkit */

# include "../image/picio.h"
# include "message.h"
# include "../draw/draw.h"
# include "../draw/drawstate.h"
# include "../misc/ographic.h"
# include "../ui/sketchpad.h"
# include "../ui/defs.h"
# include "../ui/layer.h"
# include "../global/userdata.h"

/* ========================================================================== */
/*      DEFINES                                                               */
/* ========================================================================== */

# define ERR(x) fprintf (stderr, __FILE__ "(%d): %s\n", __LINE__, x);
# define ERROR   -1
# define SUCCESS  0


static char     *filename = NULL;  /* string containing filename              */
       long int channel;           /* socket, used to send data               */
/*       long int eventpid; */         /* process-id of the spevent process       */

void msg_cannot_load_pic(char *filename);

/* ========================================================================== */
/*      all the communcation stuff                                            */
/* ========================================================================== */

int                ownUserNumber;
int                new_user_flag;
char               picFilename[256];


static void *(freehandArray[10]);
extern Widget             main_window_widget;       /* Root widget ID of main */

extern long int           eventpid;                 /* process pid of event h */
extern char               displayname[80];          /* X Display name @@@MS   */

extern XtInputId          input_id;                 /* id of input callback   */

extern void ISCinit();
extern void ISCexit();
extern void  msg_write_object_to(int,int,int,void*,int,int,int);
extern void  msg_lay_col_changed(int , XColor *);
extern void ManageMessageBox(char*);
extern void set_draw_color( struct _XGC*, unsigned int);
extern void set_foreign_font_attributes(int,int,int);
extern void draw_text(int,int,char*,struct _XGC*);
extern long int ISCaccept (char *parameter);
extern long int ISCsend (long int channel, char *buffer, long int nob);
extern long int ISCrecv (long int channel, char *buffer, long int nob);


/******************************************************************************/

long int Init_Communication (char *argv[])

{
  /***** local variables *****/
  long int i;


  for (i = 0; i < 10; i++) 
  {
    freehandArray[i] = NULL;
  }

  /***** get own user number from command-line                                */
  ownUserNumber = atoi (argv[2]);

  ISCinit ();

  channel = ISCaccept (argv[1]);

  if (channel < 0)
  {
    fprintf (stderr, "%s: getting connection to server failed!\n", argv[0]);
    return ERROR;
  }
  else
  {
    return SUCCESS;
  }

} /* end of Init_Communication */

/******************************************************************************/

void Exit_Communication (void)

{
  ISCexit ();
} /* end of Exit_Communication */

/******************************************************************************/

void SendMsg (void *data, int size)

{
  /***** local variables *****/
  long int nob;
 

  nob = ISCsend (channel, data, size);

  if (nob != size)
  {
    /***** local variables *****/
    char *msg;

    msg = (char *) malloc (80 * sizeof (char));
    sprintf (msg, "SendMsg: sent %ld bytes instead of %ld bytes!", nob, size);
    ERR (msg);
    free (msg);
  }

}



/* ========================================================================== */
/*      All functions for sending data to the main process:                   */
/* ========================================================================== */

void msg_draw_line (x1, y1, x2, y2, lwidth, lstyle, id1, id2)
  int x1, y1, x2, y2;
  unsigned int lwidth, lstyle;
  int id1, id2;
{
  msg_struct message;

  /* setup message ... */
  message.from = ownUserNumber;
  message.to   = TO_ALL;
  message.msg_type = MSG_DRAW_LINE;
  message.msg.line.x1 = x1;
  message.msg.line.y1 = y1;
  message.msg.line.x2 = x2;
  message.msg.line.y2 = y2;
  message.msg.line.lwidth = lwidth;
  message.msg.line.lstyle = lstyle;
  message.msg.line.id1 = id1;
  message.msg.line.id2 = id2;
  GetLayerId (GetActiveLayer (),
              &message.msg.line.layer_id,
              &message.msg.line.sketch_id);
  /* ... and send it */
  SendMsg (&message, sizeof (msg_struct));
}

void msg_lay_col_changed (int list_pos, XColor *to_color)
{ 
  msg_struct message;     /*__BUGS__*/
                          /* Generates a message to all users, when a layer    */
                          /* has been changed on color by it's owner.          */
                          /* This provides (more or less) same colors for same */
                          /* layers for all running sketchpads. (11.92, by HK) */

  message.from            = ownUserNumber;
  message.to              = TO_ALL;
  message.msg_type        = MSG_LAY_COL_CHANGED;
  message.msg.changedlaycol.list_pos       = list_pos;
  strcpy (message.msg.changedlaycol.layername, GetLayerName(list_pos)); 
  message.msg.changedlaycol.to_color.pixel = to_color->pixel;
         /* read the whole XColor-structure of the desired colormap-pixel given*/
         /* by >to_color< into the message-XColor-structure. This isn't just   */
         /* copying the three RGB-values to the message-XColor-structure, it   */
         /* also copies the flags and the pan to the goalstructure!! (HK)      */
  XQueryColor (DrawDisplay, DrawCmap, &message.msg.changedlaycol.to_color);
  SendMsg (&message, sizeof (msg_struct));
}

void msg_sync_user(int user_id, int ask, int x1, int y1, int width, int height,
                   unsigned char *layVisible)
{
  msg_struct message;
  int i;

  message.from     = ownUserNumber;
  message.to       = user_id;
  message.msg_type = MSG_SYNC_USER;
  message.msg.syncuser.ask    = ask;
  message.msg.syncuser.x1     = x1;
  message.msg.syncuser.y1     = y1;
  message.msg.syncuser.width  = width;
  message.msg.syncuser.height = height;
  if (layVisible != NULL)
  {
     for (i=0; i<MAXNUMLAYER; i++)
        message.msg.syncuser.layVisible[i] = layVisible[i];
  }
  SendMsg (&message, sizeof (msg_struct));
}

void msg_load_pic_to (filename, to)
  char *filename;
  int to;
{
  msg_struct message;

  message.from = ownUserNumber;
  message.to   = to;
  message.msg_type = MSG_PIC_LOADED;
  strcpy (message.msg.name, filename);
  SendMsg (&message, sizeof (msg_struct));
}

void msg_load_pic (filename)
  char *filename;
{
  msg_load_pic_to (filename, TO_ALL);
}

void msg_pic_not_loaded (filename)
  char *filename;
{
  msg_struct message;

/*  fprintf(stderr,"*** User: %d Tell Master that %s was not loaded.\n",
          ownUserNumber, filename);                                           */
  message.from = ownUserNumber;
  message.to   = TO_ALL;
  message.msg_type = MSG_PIC_NOT_LOADED;
  strcpy (message.msg.name, filename);
  SendMsg (&message, sizeof (msg_struct));
}

void msg_cannot_load_pic(char *filename)
{
  msg_struct message;

/*  fprintf(stderr,"*** User: %d: Tell Master to send %s\n",
          ownUserNumber, filename);                                           */
  message.from = ownUserNumber;
  message.to   = TO_MASTER;
  message.msg_type = MSG_CANNOT_LOAD_PIC;
  strcpy (message.msg.name, filename);
  SendMsg (&message, sizeof (msg_struct));
}

void msg_pic_to_load(int id1, int size, void *data, char *filename, int to)
{
  msg_struct message;

  message.from           = ownUserNumber;
  message.to             = to;
  message.msg_type       = MSG_PIC_TO_LOAD;
  message.msg.pictl.id1  = id1;
  message.msg.pictl.size = size;
  strcpy(message.msg.pictl.name, filename);
  /* send message-header */
/*fprintf(stderr,"*** User: %d: sending picture to master.\n", ownUserNumber);*/
  SendMsg (&message, sizeof (msg_struct));
  /* send rest of message */
  SendMsg (data, size);
}

void msg_quit ()
{
  msg_struct message;

  message.from     = ownUserNumber;
  message.to       = TO_ALL;
  message.msg_type = MSG_APP_ENDED;
  SendMsg (&message, sizeof (msg_struct));
}

void msg_end_pointer()
{
  msg_struct message;

  message.from     = ownUserNumber;
  message.to       = TO_ALL;
  message.msg_type = MSG_END_POINTER;
  SendMsg (&message, sizeof (msg_struct));
}

void msg_start_pointer_to(int userno, int to, int x, int y)
{
  msg_struct message;

  message.from     = ownUserNumber;
  message.to       = to;
  message.msg_type = MSG_START_POINTER;
  message.msg.pointer_to.userno = userno;
  message.msg.pointer_to.x = x;
  message.msg.pointer_to.y = y;
  SendMsg (&message, sizeof (msg_struct));
}

void msg_start_pointer(int x, int y)
{
  msg_start_pointer_to (ownUserNumber, TO_ALL, x, y);
}


void msg_move_pointer(x, y)
  int x, y;
{
  msg_struct message;

  message.from     = ownUserNumber;
  message.to       = TO_ALL;
  message.msg_type = MSG_MOVE_POINTER;
  message.msg.pointer.x = x;
  message.msg.pointer.y = y;
  SendMsg (&message, sizeof (msg_struct));
}

void msg_tell_address(void)
{
  msg_struct message;

  message.from     = ownUserNumber;
  message.to       = TO_ALL;
  message.msg_type = MSG_TELL_ADDRESS;
  SendMsg (&message, sizeof (msg_struct));
}

void msg_clear(void)
{
  msg_struct message;

  message.from     = ownUserNumber;
  message.to       = TO_ALL;
  message.msg_type = MSG_CLEAR;
  SendMsg (&message, sizeof (msg_struct));
}

void msg_start_freehand(int x, int y,
                        unsigned int lwidth, unsigned int lstyle,
                        int id1, int id2)
{
  msg_struct message;

  message.from     = ownUserNumber;
  message.to       = TO_ALL;
  message.msg_type = MSG_START_FREEHAND;
  message.msg.free.x      = x;
  message.msg.free.y      = y;
  message.msg.free.lwidth = lwidth;
  message.msg.free.lstyle = lstyle;
  message.msg.free.id1    = id1;
  message.msg.free.id2    = id2;
  GetLayerId (GetActiveLayer (),
              &message.msg.free.layer_id,
              &message.msg.free.sketch_id);
  SendMsg (&message, sizeof (msg_struct));
}

void msg_end_freehand(void)
{
  msg_struct message;

  message.from     = ownUserNumber;
  message.msg_type = MSG_END_FREEHAND;
  SendMsg (&message, sizeof (msg_struct));
}

void msg_erase_object(int id1, int id2)
{
  msg_struct message;

  message.from          = ownUserNumber;
  message.to            = TO_ALL;
  message.msg_type      = MSG_ERASE_OBJECT;
  message.msg.erase.id1 = id1;
  message.msg.erase.id2 = id2;
  GetLayerId (GetActiveLayer (),
              &message.msg.erase.layer_id,
              &message.msg.erase.sketch_id);
  SendMsg (&message, sizeof (msg_struct));
}

void msg_move_object (int id1, int id2,
                      int dx, int dy)
{
  msg_struct message;

  message.from         = ownUserNumber;
  message.to           = TO_ALL;
  message.msg_type     = MSG_MOVE_OBJECT;
  message.msg.move.id1 = id1;
  message.msg.move.id2 = id2;
  message.msg.move.dx  = dx;
  message.msg.move.dy  = dy;
  GetLayerId (GetActiveLayer (),
              &message.msg.move.layer_id,
              &message.msg.move.sketch_id);
  SendMsg (&message, sizeof (msg_struct));
}

void msg_size_object (int id1, int id2,
                      int x, int y, int w, int h)
{
  msg_struct message;

  message.from         = ownUserNumber;
  message.to           = TO_ALL;
  message.msg_type     = MSG_SIZE_OBJECT;
  message.msg.size.id1 = id1;
  message.msg.size.id2 = id2;
  message.msg.size.x   = x;
  message.msg.size.y   = y;
  message.msg.size.w   = w;
  message.msg.size.h   = h;
  GetLayerId (GetActiveLayer (),
              &message.msg.size.layer_id,
              &message.msg.size.sketch_id);
  SendMsg (&message, sizeof (msg_struct));
}

void msg_write_object_to (int id1, int id2, int size, void *data, int to,
                          int layer_id, int sketch_id)
{
  msg_struct message;

  message.from           = ownUserNumber;
  message.to             = to;
  message.msg_type       = MSG_WRITE_OBJECT;
  message.msg.wrobj.id1  = id1;
  message.msg.wrobj.id2  = id2;
  message.msg.wrobj.size = size;
  message.msg.wrobj.layer_id  = layer_id;
  message.msg.wrobj.sketch_id = sketch_id;
  /* send message-header */
  SendMsg (&message, sizeof (msg_struct));
  /* send rest of message */
  SendMsg (data, size);
}

void msg_write_object (int id1, int id2, int size, void *data)
{
  int layer_id, sketch_id;

  GetLayerId (GetActiveLayer (),
              &layer_id,
              &sketch_id);
  msg_write_object_to (id1, id2, size, data, TO_ALL, layer_id, sketch_id);
}

void msg_new_user (char *username, char *displayname, char *hostname)
{
  msg_struct message;

  message.from     = ownUserNumber;
  message.to       = TO_ALL;
  message.msg_type = MSG_NEW_USER;
  strcpy (message.msg.newuser.username, username);
  strcpy (message.msg.newuser.displayname, displayname);
  strcpy (message.msg.newuser.hostname, hostname);
  SendMsg (&message, sizeof (msg_struct));
}

void msg_new_layer (char *layername, int layer_id, int sketch_id,
                    Boolean visible_flag)
{
  msg_struct message;

  message.from     = ownUserNumber;
  message.to       = TO_ALL;
  message.msg_type = MSG_NEW_LAYER;
  strcpy (message.msg.newlayer.layername, layername);
  message.msg.newlayer.layer_id  = layer_id;
  message.msg.newlayer.sketch_id = sketch_id;
  message.msg.newlayer.visible = visible_flag;
  SendMsg (&message, sizeof (msg_struct));
}

void msg_new_layer_to (char *layername, int layer_id, int sketch_id,
                       Boolean visible_flag,
                       int to)
{
  msg_struct message;

  message.from     = ownUserNumber;
  message.to       = to;
  message.msg_type = MSG_NEW_LAYER;
  strcpy (message.msg.newlayer.layername, layername);
  message.msg.newlayer.layer_id  = layer_id;
  message.msg.newlayer.sketch_id = sketch_id;
  message.msg.newlayer.visible = visible_flag;
  SendMsg (&message, sizeof (msg_struct));
}

void msg_rename_layer (char *layername, int layer_id, int sketch_id)
{
  msg_struct message;

  message.from     = ownUserNumber;
  message.to       = TO_ALL;
  message.msg_type = MSG_RENAME_LAYER;
  strcpy (message.msg.renamelayer.layername, layername);
  message.msg.renamelayer.layer_id  = layer_id;
  message.msg.renamelayer.sketch_id = sketch_id;
  SendMsg (&message, sizeof (msg_struct));
}

void msg_kill_layer (int layer_id, int sketch_id)
{
  msg_struct message;

  message.from     = ownUserNumber;
  message.to       = TO_ALL;
  message.msg_type = MSG_KILL_LAYER;
  message.msg.killlayer.layer_id  = layer_id;
  message.msg.killlayer.sketch_id = sketch_id;
  SendMsg (&message, sizeof (msg_struct));
}

void msg_clear_layer (int layer_id, int sketch_id)
{
  msg_struct message;

  message.from     = ownUserNumber;
  message.to       = TO_ALL;
  message.msg_type = MSG_CLEAR_LAYER;
  message.msg.clearlayer.layer_id  = layer_id;
  message.msg.clearlayer.sketch_id = sketch_id;
  SendMsg (&message, sizeof (msg_struct));
}

void msg_set_layer_color (int layer_id, int sketch_id,
                          unsigned short int Layer_Red,
                          unsigned short int Layer_Green,
                          unsigned short int Layer_Blue)
{
  msg_struct message;

  message.from     = ownUserNumber;
  message.to       = TO_ALL;
  message.msg_type = MSG_SET_LAYER_COLOR;
  message.msg.layercolor.layer_id  = layer_id;
  message.msg.layercolor.sketch_id = sketch_id;
  message.msg.layercolor.red   = Layer_Red;
  message.msg.layercolor.green = Layer_Green;
  message.msg.layercolor.blue  = Layer_Blue;
  SendMsg (&message, sizeof (msg_struct));
}

void msg_draw_text ( char* chartext, int fontsize, int fontthick, int fontslant,
                     int x, int y, int w, int h,
                     int id1, int id2 )
{
  msg_struct message;

  /* setup message ... */
  message.from = ownUserNumber;
  message.to   = TO_ALL;
  message.msg_type     = MSG_DRAW_TEXT;
  strcpy (message.msg.text.txt, chartext);
  message.msg.text.fontsize  = fontsize;
  message.msg.text.fontthick = fontthick;
  message.msg.text.fontslant = fontslant;
  message.msg.text.x   = x;
  message.msg.text.y   = y;
  message.msg.text.w   = w;
  message.msg.text.h   = h;
  message.msg.text.id1 = id1;
  message.msg.text.id2 = id2;
  GetLayerId (GetActiveLayer (),
              &message.msg.text.layer_id,
              &message.msg.text.sketch_id);

  /* ... and send it */
  SendMsg (&message, sizeof (msg_struct));
}


void msg_draw_rectangle (int x, int y, int w, int h,
                         unsigned int lwidth, unsigned int lstyle,
                         int id1, int id2)
{
  msg_struct message;

  /* setup message ... */
  message.from = ownUserNumber;
  message.to   = TO_ALL;
  message.msg_type = MSG_DRAW_RECTANGLE;
  message.msg.rectangle.x = x;
  message.msg.rectangle.y = y;
  message.msg.rectangle.w = w;
  message.msg.rectangle.h = h;
  message.msg.rectangle.lwidth = lwidth;
  message.msg.rectangle.lstyle = lstyle;
  message.msg.rectangle.id1 = id1;
  message.msg.rectangle.id2 = id2;
  GetLayerId (GetActiveLayer (),
              &message.msg.rectangle.layer_id,
              &message.msg.rectangle.sketch_id);
  /* ... and send it */
  SendMsg (&message, sizeof (msg_struct));
}

void msg_draw_arc (int x, int y, int w, int h, int angle1, int angle2,
                   unsigned int lwidth, unsigned int lstyle, int id1, int id2)
{
  msg_struct message;

  /* setup message ... */
  message.from = ownUserNumber;
  message.to   = TO_ALL;
  message.msg_type = MSG_DRAW_ARC;
  message.msg.arc.x = x;
  message.msg.arc.y = y;
  message.msg.arc.w = w;
  message.msg.arc.h = h;
  message.msg.arc.angle1 = angle1;
  message.msg.arc.angle2 = angle2;
  message.msg.arc.lwidth = lwidth;
  message.msg.arc.lstyle = lstyle;
  message.msg.arc.id1 = id1;
  message.msg.arc.id2 = id2;
  GetLayerId (GetActiveLayer (),
              &message.msg.arc.layer_id,
              &message.msg.arc.sketch_id);
  /* ... and send it */
  SendMsg (&message, sizeof (msg_struct));
}


void msg_apply_zoom(int x, int y, int w, int h, int size, void *data)
{
  msg_struct message;

  message.from            = ownUserNumber;
  message.to              = TO_ALL;
  message.msg_type        = MSG_APPLY_ZOOM;
  message.msg.applyzoom.x = x;
  message.msg.applyzoom.y = y;
  message.msg.applyzoom.w = w;
  message.msg.applyzoom.h = h;
  message.msg.applyzoom.size = size;
  /* send message-header */
  SendMsg (&message, sizeof (msg_struct));
  /* send rest of message */
  SendMsg (data, size);
}

void msg_audio(Boolean set)
{
  msg_struct message;

  message.from            = ownUserNumber;
  message.to              = TO_ALL;
  message.msg_type        = MSG_AUDIO;
  message.msg.set = set;
  SendMsg (&message, sizeof (msg_struct));
}


/******************************************************************************/

long int RecvMsg (void *buffer, int size)
{
  return ISCrecv (channel, buffer, size);
}

/******************************************************************************/

void receive_message (void)

{
  /***** local variables *****/
  int            bytes;
  msg_struct     message;
  void           *o;
  XColor         col;
  layer          lay;
  struct_storage ss;
  char           no[3];

  bytes = RecvMsg (&message, sizeof (msg_struct));

  if (bytes == sizeof (msg_struct))
  {
    ss = NULL;
    switch (message.msg_type)
    {
      case MSG_PIC_LOADED:
      {
        filename = message.msg.name;

/*        fprintf(stderr,"*** User: %d: calling LoadRaster with %s\n",
                ownUserNumber, filename);                                     */

        /* perhaps PicPath is not correct ... */
        if (strcmp(OPicPath, "\0") != 0)
        {
          /* set PicPath to correct value */
          strcpy (PicPath, OPicPath);
          strcpy (OPicPath, "\0");
        }

        if (!LoadRasterImage (filename))
        {
          /* ask user what to do */
          ManageMessageBox(filename);
        }
        break;
      }

      case MSG_PIC_NOT_LOADED:
      {
        char  text[256];
        sprintf(text,"User %d: Image not loaded.", message.from);
        sperror(text);
        break;
      }
      case MSG_SEND_PIC:
      {
        filename = message.msg.name;
/*        fprintf(stderr,"*** User: %d: calling SendRasterFile with %s\n",
                ownUserNumber, filename);                                     */
        SendRasterFile(filename, TO_MASTER);
        break;
      }

      case MSG_PIC_TO_LOAD:
      {
	/* picture data from master arriving ... */

	/***** local variables *****/
	char *data;
	int  size;
	int  status;
        char tempfilename[80];

	filename = message.msg.pictl.name;
/*        fprintf(stderr,"*** User: %d: receiving raster data: %s\n", 
		       ownUserNumber, filename);                              */

	/* first receive rest of message */

	/* size of the rest of the message */
	size = message.msg.pictl.size;

	/* get memory for the rest message */
	data = (char *) malloc (size);

	/* receive rest of message */
	{
	  status = RecvMsg (data, size);
	  if (status != size)
	  {
	    fprintf(stderr,"User: received wrong size of picture data.\n");
	  }
	}
/*      fprintf(stderr,"*** User: %d: received picture data.\n");             */

	/* store data */
	sprintf(no,"%d",ownUserNumber);
	strcat(filename,".temp");
	strcat(filename,no);
	SaveRasterFile(data, size, filename);
	free (data);

        /* perhaps PicPath is not correct ... */
        if (strcmp(OPicPath, "\0") != 0)
        {
          /* set PicPath to correct value */
          strcpy (PicPath, OPicPath);
          strcpy (OPicPath, "\0");
        }

	if (!LoadRasterImage(filename))
	{
	  fprintf(stderr,"User: cannot load transmitted picture.\n");
	  /* Ask user what to do */
	  ManageMessageBox(filename);
	}
        strcpy(tempfilename, PicPath);
        strcat(tempfilename, filename);
        remove(tempfilename);
	break;
      }

      case MSG_DRAW_LINE:
      {
        lay = GetLayer (message.msg.line.layer_id,
                        message.msg.line.sketch_id);

        /* draw on window only if layer visible */
        if (GetLayerState (lay) & LS_VISIBLE)
        {
          set_draw_color (ForeignGC, GetLayerColor (lay));
          switch (message.msg.line.lstyle)
          {
            case SOLID:
              XSetLineAttributes (DrawDisplay, ForeignGC,
                                  message.msg.line.lwidth, LineSolid,
                                  CAP_STYLE, JOIN_STYLE);
              break;
            case DASHED:
              XSetLineAttributes (DrawDisplay, ForeignGC,
                                  message.msg.line.lwidth, LineOnOffDash,
                                  CAP_STYLE, JOIN_STYLE);
              break;
          }

          draw_line (message.msg.line.x1, message.msg.line.y1,
            message.msg.line.x2, message.msg.line.y2);
        }

        if (freehandArray[message.from] == NULL)
        {
          ss = GetStructStorage (lay);
          InsertLine (ss, message.msg.line.x1,
	    message.msg.line.y1,
	    message.msg.line.x2,
	    message.msg.line.y2,
            message.msg.line.lwidth,
            message.msg.line.lstyle,
	    message.msg.line.id1,
	    message.msg.line.id2);
        }
        else
        {
          AppendLineSegment (freehandArray[message.from],
	       message.msg.line.x2,
	       message.msg.line.y2);
        }
        break;
      }

      case MSG_START_POINTER:
      {
        start_pointer (message.msg.pointer_to.x, message.msg.pointer_to.y,
                       message.msg.pointer_to.userno);
        break;
      }

      case MSG_END_POINTER:
      {
        end_pointer (message.from);
        break;
      }

      case MSG_MOVE_POINTER:
      {
        move_pointer (message.msg.pointer.x, message.msg.pointer.y, message.from);
        break;
      }

      case MSG_CLEAR:
      {
        ClearRasterImage();
        break;
      }

      case MSG_CLEAR_LAYER:
      {
        if ((message.msg.clearlayer.layer_id == 1) &&
            (message.msg.clearlayer.sketch_id == 0))
        {
          (void) ClearRasterImage();
        }
        else
        {
          (void) ClearLayer (message.msg.clearlayer.layer_id, 
                             message.msg.clearlayer.sketch_id);
        }
        break;
      }

      case MSG_START_FREEHAND:
      {
        ss = GetStructStorage (GetLayer (message.msg.free.layer_id,
          message.msg.free.sketch_id));
        freehandArray[message.from] = InsertFreehand (ss, message.msg.free.x,
          message.msg.free.y, message.msg.free.lwidth, message.msg.free.lstyle,
          message.msg.free.id1, message.msg.free.id2);
        break;
      }

      case MSG_END_FREEHAND:
      {
        freehandArray[message.from] = NULL;
        break;
      }

      case MSG_ERASE_OBJECT:
      {
        ss = GetStructStorage (GetLayer (message.msg.erase.layer_id,
          message.msg.erase.sketch_id));
        o = GetObject (ss, message.msg.erase.id1, message.msg.erase.id2);
        if (o != NULL)
        {
          DeleteObject (ss, o);
        }
        break;
      }

      case MSG_MOVE_OBJECT:
      {
        ss = GetStructStorage (GetLayer (message.msg.move.layer_id,
          message.msg.move.sketch_id));
        o = GetObject (ss, message.msg.move.id1, message.msg.move.id2);
        if (o != NULL)
        {
          MoveObject (ss, o, message.msg.move.dx, message.msg.move.dy);
        }
        break;
      }

      case MSG_SIZE_OBJECT:
      {
        ss = GetStructStorage (GetLayer (message.msg.size.layer_id,
          message.msg.size.sketch_id));
        o = GetObject (ss, message.msg.size.id1, message.msg.size.id2);
        if (o != NULL)
        {
          SizeObject (ss, o, message.msg.size.x, message.msg.size.y,
	    message.msg.size.w, message.msg.size.h);
        }
        break;
      }

      case MSG_WRITE_OBJECT:
      {
        /***** local variables *****/
        void *data;

        ss = GetStructStorage (GetLayer (message.msg.wrobj.layer_id,
          message.msg.wrobj.sketch_id));
        data = (void*)malloc (message.msg.wrobj.size);

        do
        {
          bytes = RecvMsg (data, message.msg.wrobj.size);
        } while (bytes < 0);

        WriteObjects (ss, data, message.msg.wrobj.id1, &message.msg.wrobj.id2);
        free (data);
        break;
      }

      case MSG_SET_LAYER_COLOR:
      {
        fprintf (stderr, "SetLayerColor: layer_id= %d, sketch_id= %d\n",
                 message.msg.layercolor.layer_id,
                 message.msg.layercolor.sketch_id);
        fflush (stderr);
        lay = GetLayer (message.msg.layercolor.layer_id,
                        message.msg.layercolor.sketch_id);
        col.red   = message.msg.layercolor.red;
        col.green = message.msg.layercolor.green;
        col.blue  = message.msg.layercolor.blue;

        SetLayerColor (lay, col);


        /* Update layer list in manage box */
        CreateLayerList(widget_array[v_layer_manage_box3]);
        break;
      }

      case MSG_SET_NEW_USER:
      {
        NewUser (message.msg.setnewuser.sketch_id,
                 message.msg.setnewuser.username,
                 message.msg.setnewuser.displayname,
                 message.msg.setnewuser.hostname);
        break;
      }

      case MSG_NEW_USER:
      {

        new_user_flag = message.from;

        break;
      }

      case MSG_NEW_LAYER:
      {
        /***** local variables *****/
        layer p;

        p = add_layer (message.msg.newlayer.layername,
              message.msg.newlayer.layer_id,
              message.msg.newlayer.sketch_id,
              message.msg.newlayer.visible,
              True);
        if (p != NULL)
        {
	  add_buttons(p);

	  /* Update layer list in manage box */
	  CreateLayerList(widget_array[v_layer_manage_box3]);
        }
	break;
      }

      case MSG_KILL_LAYER:
      {
        delete_layer (message.msg.killlayer.layer_id,
                      message.msg.killlayer.sketch_id);

        /* Update layer list in manage box */
        CreateLayerList(widget_array[v_layer_manage_box3]);
        break;
      }

      case MSG_RENAME_LAYER:
      {
        rename_layer ( GetLayer (message.msg.renamelayer.layer_id,
                                  message.msg.renamelayer.sketch_id),
                         message.msg.renamelayer.layername );
        CreateLayerList (widget_array[v_layer_manage_box3]);
        break;
      }

      case MSG_DRAW_TEXT:
      {
        lay = GetLayer (message.msg.text.layer_id,
                        message.msg.text.sketch_id);

        /* draw on window only if layer visible */
        if (GetLayerState (lay) & LS_VISIBLE)
        {
          set_draw_color (ForeignGC, GetLayerColor (lay));
          set_foreign_font_attributes (message.msg.text.fontsize,
                                       message.msg.text.fontthick,
                                       message.msg.text.fontslant);
          draw_text (message.msg.text.x,
                       message.msg.text.y,
                       message.msg.text.txt,
                       ForeignGC);
          set_draw_color (DrawGCtext, GetLayerColor (GetActiveLayer()));
        }
        ss = GetStructStorage (lay);
        InsertText (ss, message.msg.text.x,
                        message.msg.text.y,
                        message.msg.text.w,
                        message.msg.text.h,
                        message.msg.text.txt,
                        message.msg.text.fontsize,
                        message.msg.text.fontthick,
                        message.msg.text.fontslant,
                        message.msg.text.id1,
                        message.msg.text.id2);
        break;
      }

      case MSG_DRAW_RECTANGLE:
      {
        lay = GetLayer (message.msg.rectangle.layer_id,
                        message.msg.rectangle.sketch_id);

        /* draw on window only if layer visible */
        if (GetLayerState (lay) & LS_VISIBLE)
        {
          set_draw_color (ForeignGC, GetLayerColor (lay));
          switch (message.msg.rectangle.lstyle)
          {
            case SOLID:
              XSetLineAttributes (DrawDisplay, ForeignGC,
                                  message.msg.rectangle.lwidth, LineSolid,
                                  CAP_STYLE, JOIN_STYLE);
              break;
            case DASHED:
              XSetLineAttributes (DrawDisplay, ForeignGC,
                                  message.msg.rectangle.lwidth, LineOnOffDash,
                                  CAP_STYLE, JOIN_STYLE);
              break;
          }

          XDrawRectangle (DrawDisplay, DrawWindow, ForeignGC,
                          message.msg.rectangle.x,
                          message.msg.rectangle.y,
                          message.msg.rectangle.w,
                          message.msg.rectangle.h);
        }

        ss = GetStructStorage (lay);
        InsertRectangle (ss, message.msg.rectangle.x,
                             message.msg.rectangle.y,
                             message.msg.rectangle.w,
                             message.msg.rectangle.h,
                             message.msg.rectangle.lwidth,
                             message.msg.rectangle.lstyle,
                             message.msg.rectangle.id1,
                             message.msg.rectangle.id2);
        break;
      }

      case MSG_DRAW_ARC:
      {
        lay = GetLayer (message.msg.arc.layer_id,
                        message.msg.arc.sketch_id);

        /* draw on window only if layer visible */
        if (GetLayerState (lay) & LS_VISIBLE)
        {
          set_draw_color (ForeignGC, GetLayerColor (lay));
          switch (message.msg.line.lstyle)
          {
            case SOLID:
              XSetLineAttributes (DrawDisplay, ForeignGC,
                                  message.msg.arc.lwidth, LineSolid,
                                  CAP_STYLE, JOIN_STYLE);
              break;
            case DASHED:
              XSetLineAttributes (DrawDisplay, ForeignGC,
                                  message.msg.arc.lwidth, LineOnOffDash,
                                  CAP_STYLE, JOIN_STYLE);
              break;
          }

          XDrawArc (DrawDisplay, DrawWindow, ForeignGC,
                    message.msg.arc.x,
                    message.msg.arc.y,
                    message.msg.arc.w,
                    message.msg.arc.h,
                    message.msg.arc.angle1,
                    message.msg.arc.angle2);
        }

        ss = GetStructStorage (lay);
        InsertArc (ss, message.msg.arc.x,
                       message.msg.arc.y,
                       message.msg.arc.w,
                       message.msg.arc.h,
                       message.msg.arc.angle1,
                       message.msg.arc.angle2,
                       message.msg.arc.lwidth,
                       message.msg.arc.lstyle,
                       message.msg.arc.id1,
                       message.msg.arc.id2);
        break;
      }

      case MSG_APPLY_ZOOM:
      {
        /* changed raster data from master arriving ... */

        /***** local variables *****/
        char *data;
        int  size;
        int  status;

        /* first receive rest of message */

        /* size of the rest of the message */
        size = message.msg.applyzoom.size;

        /* get memory for the rest message */
        data = (char *) malloc (size);

        /* receive rest of message */
        {
          status = RecvMsg (data, size);
          if (status != size)
          {
            fprintf(stderr,"User: received wrong size of zoom data.\n");
          }
        }

        /* update raster image on screen and related data structures */
        Apply_Foreign_Zoom(message.msg.applyzoom.x, message.msg.applyzoom.y,
                           message.msg.applyzoom.w, message.msg.applyzoom.h,
                           data);
        free (data);
        break;
      }

      case MSG_APP_ENDED:
      {
        RemoveUser (message.from);
        break; 
      }
      case MSG_LAY_COL_CHANGED: 
      {
        /* a user has changed the color of one of his layers */
        char text[80];
        if (ownUserNumber != message.from)
           {
                             /* someone else has changed the layercolor      */
             sprintf (text,"The layer '\"%s\"' has changed his color!",
                      message.msg.changedlaycol.layername );
             sperror (text);
             if ( !SetLayerColor( 
                      GetLayerFromNo (message.msg.changedlaycol.list_pos),
                      message.msg.changedlaycol.to_color)) /* sets the color */  
                  {  
                     sperror (" ATTENTION:"); /* the function SetLayerColor  */
                                              /* has returned FALSE, because */
                                              /* the desired colormap-pixel  */
                                              /* was the BlackPixelOfScreen! */
                     sperror (" The layer can't change to the new \ncolor on your screen !!");
                  };
           }
        break;
      }

      case MSG_SYNC_USER:
      {
        if (message.msg.syncuser.ask == TRUE)
        {
           int    x1,y1;
           int    width,height;
           Arg    args[1];
           Widget sbar;
           int    inc,pinc;
           unsigned char layVis[MAXNUMLAYER];
           int    i;

           XtSetArg(args[0], XmNverticalScrollBar, &sbar);
           XtGetValues(widget_array[v_scrolled_window], args, 1);
           XmScrollBarGetValues(sbar,&y1,&height,&inc,&pinc);

           XtSetArg(args[0], XmNhorizontalScrollBar, &sbar);
           XtGetValues(widget_array[v_scrolled_window], args, 1);
           XmScrollBarGetValues(sbar,&x1,&width,&inc,&pinc);

           for (i=0; i<MAXNUMLAYER; i++) layVis[i] = 0;
           GetLayerVisibility(layVis);

           {
             char  *user,*host;
             char  *display;
             char  str[256];
             int   id;

             GetFirstUser (&id, &user, &host, &display);
             while (id != message.from)
                GetNextUser (&id, &user, &host, &display);
             sprintf(str,"Partner '%s' was synchronizing the window with you.\n"
,user);
             sperror(str);
           }

           msg_sync_user(message.from, FALSE, x1, y1, width, height, layVis);
        }
        else  /* responded message */
        {
           int    x1,y1;
           int    width,height;
           int    dwidth,dheight;
           Arg    args[2];
           Widget sbar,wwin;
           int    inc,pinc;
           int    nosync;
           unsigned char *layVis;
           int    i;

           x1     = message.msg.syncuser.x1;
           y1     = message.msg.syncuser.y1;
           width  = message.msg.syncuser.width;
           height = message.msg.syncuser.height;
           layVis = message.msg.syncuser.layVisible;

           dwidth  = DisplayWidth (theDisplay, theScreen);
           dheight = DisplayHeight (theDisplay, theScreen);

           nosync = FALSE;
           if (width+106 > dwidth)
           {
              width = dwidth - 106;
              nosync = TRUE;
           }
           if (height+57 > dheight)
           {
              height = dheight - 57;
              nosync = TRUE;
           }

           XtResizeWidget(toplevel_widget,width+106,height+57,0);
           if (nosync)
              XMoveWindow(theDisplay, XtWindow(toplevel_widget), 8, 26);

           XtSetArg(args[0], XmNhorizontalScrollBar, &sbar);
           XtSetArg(args[1], XmNworkWindow, &wwin);
           XtGetValues(widget_array[v_scrolled_window], args, 2);

           XtMoveWidget(wwin, -x1, -y1);

           XtSetArg(args[0], XmNvalue, x1);
           XtSetValues(sbar, args, 1);

           XtSetArg(args[0], XmNverticalScrollBar, &sbar);
           XtGetValues(widget_array[v_scrolled_window], args, 1);

           XtSetArg(args[0], XmNvalue, y1);
           XtSetValues(sbar, args, 1);

           XFlush(theDisplay);

           SetLayerVisibility(layVis);

           if (nosync)
              sperror("WARNING: your display is to small for exact synchronisation.\n");
        }
        break;
      }


      case MSG_END_SKETCHPAD :
      {
        /*
         * Stop the SketchPad instance now. A possiblility to save the
         * current contexted should be added here later! 
         */

        /*
         * That's a lousy never comeback call (should be changed later!)
         * Simulates the press of the Quit menu entry of the user interface.
         */

        stop_sketchpad(); /* All parameters are dummies! */

        XtRemoveInput (input_id);

        break;

      }

      default :
      {
        printf ("sketchpad: received message of unknown typ (%ld)!\n", message.msg_type);
        break;
      }

    } /* switch */
  }
  else
  {
    /***** if the number of bytes equals 0, we assume that the main process died! *****/
    if (bytes == 0)
    {
      printf ("SketchPad: connection to main process lost!\n");
      exit (99);
    }
    else
    {
      fprintf (stderr,
	"(%d): received wrong sized message, possibly from (%d) !\n",
	 ownUserNumber, message.from);
      fflush (stderr);
    }
/***** end of changes! *****/
  }
}

/* end of file: user.c */
