/* syserr.h 12.7.1991 JU */

extern void syserr (long int, char**);

