/* ========================================================================== */
/*                                                                            */
/* Filename:     start.c                          +-----+-----+--+--+--+--+   */
/* Version :     1.14	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 3/1/93	17:27:34	                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

# include <malloc.h>
# include <sys/types.h>
# include <sys/stat.h>
# include <sys/socket.h>
# include <sys/errno.h>
# include <sys/dir.h>
# include <stdio.h>
# include <string.h>
# include <netdb.h>
# include <netinet/in.h>
# include <pwd.h>
# include <signal.h>
/* HC
# include <stdlib.h>
*/

# if !defined(sparc)
#   include <fcntl.h>
# else
#   include <sys/fcntl.h>
# endif

# include "message.h"
# include "../misc/list.h"
# include "syserr.h"
# include "../misc/lay.h"
# include "../global/global.h"

typedef long int boolean;

/* ========================================================================== */
/*      DEFINE STATEMENTS                                                     */
/* ========================================================================== */

# ifndef _AIX
# ifndef sparc
# define FALSE              0
# define TRUE               !FALSE
# endif  sparc
# endif  _AIX

# define USER_SETUP_FILE    "users"
# define TEMP_PIC_FILE      "temp.pic"

# define MAXUSERS                10
# define DISPLAYNAMELEN          32
# define USERNAMELEN             32
# define HOSTNAMELEN             MAXHOSTNAMELEN

# define ERROR                   -1
# define ERR(x) fprintf (stderr, __FILE__ "(%d): %s\n", __LINE__, x);

/* ========================================================================== */
/*      TYPES                                                                 */
/* ========================================================================== */

struct user_s {
                long int           userno;
                char               displayname[DISPLAYNAMELEN];
                char               username[USERNAMELEN];
                long int           userProcId;
                long int           channel;
                boolean            addressValid;
                char               hostn[HOSTNAMELEN];
                long int           pic_request;
                char               pic_name[256];
                int                initiator;
};

typedef struct
{
  int x, y, width, height;
} Rectangle;

extern long int ISCsend (long int channel, char *buffer, long int nob);
extern long int ISCstart (char *servicename, char *hostname, char *parameters);
extern void ISCgethostn (char *);
extern long int ISCselect (void);
extern long int ISCrecv (long int channel, char *buffer, long int nob); 
extern long int ISCclose (long int channel);
extern void ISCinit (void);


/* ========================================================================== */
/*      GLOBAL VARIABLES                                                      */
/* ========================================================================== */

# ifdef sparc
  extern long int errno;
# else
  extern long int errno;
#endif

char                      *errtext;

static int                numberOfUser;
static int                numberOfUser2;
static msg_struct         message;
static int                receive_socket;
static list               userList;

static int                initiator_id     = 0;
static char               pic_to_load[256] = "\0";
static int                pic_requested    = 0;
static char               *data;
static void               *(freehandArray[10]);
static Rectangle          ptr_bbox [MAXUSERS];
static int                pointer_visible[MAXUSERS];

static long int           highest_layer_id;
static long int           SPserver_channel;

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : SEND                                                      */
/*                                                                            */
/*      Version   : 1                                                         */
/*                                                                            */
/*                                                                            */
/*      Purpose   : send a message to the desired user-process                */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*                                                                            */
/*      Called by : main                                                      */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */

/*
 * typ changed from (char *) to (struct user_s *) by Manfred G. Schendel (02.12.1991) 
 */

struct user_s *findUser (long int nr)

{
  struct user_s *found;

  FirstEntry (userList);
  while (found = (struct user_s *) GetEntry (userList))
  {
    if (found->userno == nr)
    {
      return (struct user_s *) found;
    }
    NextEntry (userList);
  }
  return NULL;
} /* end of findUser */

/******************************************************************************/

long int SEND (long int nr, msg_struct msg)

{
  /***** local variables *****/
  struct user_s *foundData;
  long int      status;

  if (foundData = (struct user_s *) findUser (nr))
  {
    if (foundData->addressValid)
    {
      status = ISCsend (foundData->channel, (char *)&msg, sizeof (msg_struct));
    }
  }
  else
  {
    return ERROR;
  }

  return status;
}

/******************************************************************************/

/*
 * This function creates the user list, either from the user file or
 * adds just on local user.
 */

void CreateUserList ()

{
  /***** local variables *****/
  FILE           *f;       /* file-pointer for the user-setup file            */
  struct user_s  *user_v;  /* pointer to a user-structure                     */
  char           buffer[129];

  f = fopen (USER_SETUP_FILE, "r");

  if (f != NULL) 
  {
    numberOfUser = 0;
    while (TRUE) 
    {
      user_v = (struct user_s *) malloc (sizeof (struct user_s));

      fgets (buffer, 128, f);

      if (feof (f)) break;

      sscanf (buffer, "%s %s %s", user_v->username, user_v->displayname,
              user_v->hostn);

      /* initialize user-process id                                           */
      user_v->userProcId = -1;
      /* identify this user by it's number                                    */
      user_v->userno = numberOfUser;
      /* initialize values for picture transfer                               */
      user_v->pic_request = 0;
      user_v->initiator = -1;
      strcpy(user_v->pic_name, "\0");
      /* insert the new user entry in userList                                */
      InsertEndEntry (userList, user_v);
      /* update number of user                                                */
      numberOfUser++;
    }

    fclose (f);
  } 
  else 
  {
    /***** local variables *****/
    char          *dispEnv;
    char          *getenv();
    struct passwd *pw;

    /* allocate space for the new user entry                                  */
    user_v = (struct user_s *) malloc (sizeof (struct user_s));
    /* its number is zero                                                     */
    user_v->userno = 0;
    user_v->initiator = -1;
    gethostname (user_v->hostn, HOSTNAMELEN);
    /* get the display name from the environment                              */
    if (( dispEnv = getenv( "DISPLAY" )) == NULL ) {
      /* if display not set then set default value ':0.0'                     */
      dispEnv = ":0.0";
    }
    /* only one user                                                          */
    numberOfUser = 1;
    /* copy displayname from evironment-variable                              */
    strcpy ( user_v->displayname, dispEnv );
    /* read line from /etc/passwd                                             */
    pw = getpwuid ( getuid ());
    /* and get the user-name from there                                       */
    strcpy ( user_v->username, pw->pw_name );
    /* initialize values for picture transfer                                 */
    user_v->pic_request = 0;
    strcpy(user_v->pic_name, "\0");
    InsertEndEntry (userList, user_v);
  }

} /* end of CreateUserList */


/******************************************************************************/

void StartupSketchPads ()

{
  /***** local variables *****/
  long int       status;
  struct user_s  *user_v;  /* pointer to a user-structure                     */
  long int       i;
  char           parameters[80];

  FirstEntry (userList);

  for (i = 0; i < numberOfUser; i ++)
  {
    user_v = (struct user_s *) GetEntry (userList);
    sprintf (parameters, "%ld/%s", user_v->userno, user_v->displayname);
    status = ISCstart ("sketchpad", user_v->hostn, parameters);

    if (status >= 0)
    {
      user_v->channel = status;
      user_v->addressValid = TRUE;
    }
    else
    {
      user_v->channel = -1;
      user_v->addressValid = FALSE;
    }

    NextEntry (userList);
  }

} /* end of StartupSketchPads */

/******************************************************************************/

void StartupConferenceServer ()

{
  /***** local variables *****/
  char  parameters[80];
  char  hostname[80];
  char  displayname[80];

  ISCgethostn (hostname);
  strcpy (displayname, getenv ("DISPLAY"));
  sprintf (parameters, "%ld/%s", getpid (), displayname);
  SPserver_channel = ISCstart ("SPserver", hostname, parameters);

  if (SPserver_channel >= 0)
  {
    printf ("start: start conference server successfully!\n");
  }
  else
  {
    printf ("start: start of conference server failed!\n");
  }
} /* end of StartupConferenceServer */

/******************************************************************************/
void start_pointer (int x_new, int y_new, int user_number)
{
  /* save the pointers current position                 */
  /* which is the upper left corner of its bounding box */
  ptr_bbox[user_number].x = x_new;
  ptr_bbox[user_number].y = y_new;
  /* mark the pointer as 'visible' */
  pointer_visible[user_number] = 1;
} /* start_pointer */

/******************************************************************************/

void end_pointer (int user_number)
{
  /* mark the pointer as 'not visible' */
  pointer_visible[user_number] = 0;
} /* end_pointer */

/******************************************************************************/

void move_pointer (int x_new, int y_new, int user_number)
{
  /* save the pointer's new position */
  ptr_bbox[user_number].x = x_new;
  ptr_bbox[user_number].y = y_new;
} /* move_pointer */

/******************************************************************************/

void UpdateDatabase (msg_struct msg)
{
  struct_storage ss;
  void *o;

  switch (msg.msg_type)
  {
    case MSG_START_POINTER:
      start_pointer (msg.msg.pointer_to.x, msg.msg.pointer_to.y,
                     msg.msg.pointer_to.userno);
      break;
    case MSG_END_POINTER:
      end_pointer (msg.from);
      break;
    case MSG_MOVE_POINTER:
      move_pointer (msg.msg.pointer.x, msg.msg.pointer.y, msg.from);
      break;
    case MSG_DRAW_LINE:
      if (freehandArray[msg.from] == NULL)
      {
        ss = GetStructStorage (msg.msg.line.layer_id, msg.msg.line.sketch_id);
        if (ss != NULL)
        {
          InsertLine (ss, msg.msg.line.x1, msg.msg.line.y1, msg.msg.line.x2,
                      msg.msg.line.y2, msg.msg.line.lwidth, msg.msg.line.lstyle,
                      msg.msg.line.id1, msg.msg.line.id2);
        }
        else
        {
          fprintf (stderr, "layer %d %d nicht bekannt.\n",
                   msg.msg.line.layer_id, msg.msg.line.sketch_id);
          fflush (stderr);
        }
      }
      else
      {
        AppendLineSegment (freehandArray[msg.from], msg.msg.line.x2,
                           msg.msg.line.y2);
      }
      break;
    case MSG_START_FREEHAND :
      ss = GetStructStorage (msg.msg.free.layer_id, msg.msg.free.sketch_id);
      if (ss != NULL)
      {
        freehandArray[msg.from] = InsertFreehand (ss, msg.msg.free.x,
            msg.msg.free.y, msg.msg.free.lwidth, msg.msg.free.lstyle,
            msg.msg.free.id1, msg.msg.free.id2);
      }
      else
      {
        fprintf (stderr, "layer %d %d nicht bekannt.\n",
                 msg.msg.free.layer_id, msg.msg.free.sketch_id);
        fflush (stderr);
      }
      break;
    case MSG_END_FREEHAND :
      freehandArray[msg.from] = NULL;
      break;
    case MSG_ERASE_OBJECT :
      ss = GetStructStorage (msg.msg.erase.layer_id,
                             msg.msg.erase.sketch_id);
      if (ss != NULL)
      {
        o = GetObject (ss, msg.msg.erase.id1,
                           msg.msg.erase.id2);
        if (o != NULL)
        {
          DeleteObject (ss, o);
        }
      }
      else
      {
        fprintf (stderr, "layer %d %d nicht bekannt.\n",
                 msg.msg.erase.layer_id, msg.msg.erase.sketch_id);
        fflush (stderr);
      }
      break;
    case MSG_MOVE_OBJECT :
      ss = GetStructStorage (msg.msg.move.layer_id,
                             msg.msg.move.sketch_id);
      if (ss != NULL)
      {
        o = GetObject (ss, msg.msg.move.id1, msg.msg.move.id2);
        if (o != NULL)
        {
          MoveObject (ss, o, msg.msg.move.dx, msg.msg.move.dy);
        }
      }
      else
      {
        fprintf (stderr, "layer %d %d nicht bekannt.\n",
                 msg.msg.move.layer_id, msg.msg.move.sketch_id);
        fflush (stderr);
      }
      break;
    case MSG_SIZE_OBJECT :
      ss = GetStructStorage (msg.msg.size.layer_id,
                             msg.msg.size.sketch_id);
      if (ss != NULL)
      {
        o = GetObject (ss, msg.msg.size.id1, msg.msg.size.id2);
        if (o != NULL)
        {
          SizeObject (ss, o, msg.msg.size.x, msg.msg.size.y,
                             msg.msg.size.w, msg.msg.size.h);
        }
      }
      else
      {
        fprintf (stderr, "layer %d %d nicht bekannt.\n",
                 msg.msg.size.layer_id, msg.msg.size.sketch_id);
        fflush (stderr);
      }
      break;
    case MSG_DRAW_TEXT :
      ss = GetStructStorage (msg.msg.text.layer_id,
                             msg.msg.text.sketch_id);
      if (ss != NULL)
      {
        InsertText (ss, msg.msg.text.x,
                        msg.msg.text.y,
                        msg.msg.text.w,
                        msg.msg.text.h,
                        msg.msg.text.txt,
                        msg.msg.text.fontsize,
                        msg.msg.text.fontthick,
                        msg.msg.text.fontslant,
                        msg.msg.text.id1,
                        msg.msg.text.id2);
      }
      else
      {
        fprintf (stderr, "layer %d %d nicht bekannt.\n",
                 msg.msg.text.layer_id, msg.msg.text.sketch_id);
        fflush (stderr);
      }
      break;
    case MSG_DRAW_RECTANGLE :
      ss = GetStructStorage (msg.msg.rectangle.layer_id,
                             msg.msg.rectangle.sketch_id);
      if (ss != NULL)
      {
        InsertRectangle (ss, msg.msg.rectangle.x,
                             msg.msg.rectangle.y,
                             msg.msg.rectangle.w,
                             msg.msg.rectangle.h,
                             msg.msg.rectangle.lwidth,
                             msg.msg.rectangle.lstyle,
                             msg.msg.rectangle.id1,
                             msg.msg.rectangle.id2);
      }
      else
      {
        fprintf (stderr, "layer %d %d nicht bekannt.\n",
                 msg.msg.rectangle.layer_id, msg.msg.rectangle.sketch_id);
        fflush (stderr);
      }
      break;
    case MSG_DRAW_ARC :
      ss = GetStructStorage (msg.msg.arc.layer_id,
                             msg.msg.arc.sketch_id);
      if (ss != NULL)
      {
        InsertArc (ss, msg.msg.arc.x,
                       msg.msg.arc.y,
                       msg.msg.arc.w,
                       msg.msg.arc.h,
                       msg.msg.arc.angle1,
                       msg.msg.arc.angle2,
                       msg.msg.arc.lwidth,
                       msg.msg.arc.lstyle,
                       msg.msg.arc.id1,
                       msg.msg.arc.id2);
      }
      else
      {
        fprintf (stderr, "layer %d %d nicht bekannt.\n",
                 msg.msg.arc.layer_id, msg.msg.arc.sketch_id);
        fflush (stderr);
      }
      break;
    case MSG_CLEAR_LAYER :
      if ((message.msg.clearlayer.layer_id != 1) ||
          (message.msg.clearlayer.sketch_id != 0))
      {
        (void) ClearLayer (msg.msg.clearlayer.layer_id,
                           msg.msg.clearlayer.sketch_id);
      }
      break;
    case MSG_NEW_LAYER:
      if (msg.msg.newlayer.layer_id > highest_layer_id)
      {
        highest_layer_id = msg.msg.newlayer.layer_id;
      }
      AddLayer (msg.msg.newlayer.layername,
                msg.msg.newlayer.layer_id,
                msg.msg.newlayer.sketch_id);
      break;
    case MSG_KILL_LAYER:
      RemoveLayer (msg.msg.killlayer.layer_id,
                   msg.msg.killlayer.sketch_id);
      break;
    case MSG_RENAME_LAYER:
      RenameLayer (msg.msg.renamelayer.layername,
                   msg.msg.renamelayer.layer_id,
                   msg.msg.renamelayer.sketch_id);
      break;
    case MSG_WRITE_OBJECT:
      ss = GetStructStorage (msg.msg.wrobj.layer_id,
                             msg.msg.wrobj.sketch_id);
      if (ss != NULL)
      {
        int save;

        save = message.msg.wrobj.id2;
        WriteObjects (ss, data, msg.msg.wrobj.id1, &message.msg.wrobj.id2);
        message.msg.wrobj.id2 = save;
      }
      else
      {
        fprintf (stderr, "layer %d %d nicht bekannt.\n",
                 msg.msg.wrobj.layer_id, msg.msg.wrobj.sketch_id);
        fflush (stderr);
      }
      break;
    default:
      break;
  }
}

/******************************************************************************/

void ServeSketchPads (void)

{
  /***** local variables *****/
  long int       status;
  long int       channel;
  long int       bytes;
  struct user_s  *user_v;  /* pointer to a user-structure                     */
  long int       i;
  char  parameters[80];
  int		 msg_from;
  int		 msg_to;
  int		 msg_type;


  numberOfUser2 = numberOfUser;
  do 
  {
    /***** wait for a message from any SketchPad *****/
    channel = ISCselect ();
    bytes = ISCrecv (channel, (char *) &message, sizeof (msg_struct));

/***** HOST <--> NET
    msg_from = ntohl(message.from);
    msg_to   = ntohl(message.to);
    msg_type = ntohl(message.msg_type);
*****/
    msg_from = message.from;
    msg_to   = message.to;
    msg_type = message.msg_type;

    if ( bytes == sizeof ( msg_struct )) 
    {
      switch (msg_type) 
      {
        case MSG_APP_ENDED :
        {
          user_v = (struct user_s *) findUser (msg_from);

          if (user_v != NULL)
          {
            user_v->addressValid = 0;
            /* remove process from SketchPad service */
            ISCclose (user_v->channel);
	    free (user_v);
	    DeleteEntry (userList);
	    numberOfUser2--;
            /* tell all the other users, that this user has quited */
            for (i = 0; i < numberOfUser; i++)
            {
              SEND (i, message);
            }
	    break;
          }
          else
          {
            printf ("start: MSG_APP_ENDED from unknown SketchPad process!\n");
          }
        }

        case MSG_PIC_LOADED :
        {
          initiator_id = msg_from;
          strcpy (pic_to_load, message.msg.name);
          pic_requested = 0;
/*          fprintf (stderr, "*** Start: picture loaded: %s\n", pic_to_load); */
          fflush (stderr);
          if (msg_to == TO_ALL)
          {
            /* send message to all other SketchPad processes */
            for (i = 0; i < numberOfUser; i++)
            {
              if (i != msg_from)
              {
                SEND (i, message);
              }
            }
          }
          else
          {
            SEND (msg_to, message);
          }
          break;
        }

        case MSG_PIC_NOT_LOADED :
        {
          /* one sketchpad process could not load the requested picture */
/*          fprintf(stderr,"*** Start: Note that User cannot load pic.\n");   */
          /* @1 store situation in main process */
          if (msg_to == TO_ALL)
          {
            /* send message to all other SketchPad processes */
            for (i = 0; i < numberOfUser; i++)
            {
              if (i != msg_from)
              {
                SEND (i, message);
              }
            }
          }
          else
          {
            SEND (msg_to, message);
          }
          break;
        }

        case MSG_CLEAR_LAYER :
        {
/***** HOST <--> NET
	  message.msg.clearlayer.layer_id = ntohl(message.msg.clearlayer.layer_id);
	  message.msg.clearlayer.sketch_id = ntohl(message.msg.clearlayer.sketch_id);
******/
          if ((message.msg.clearlayer.layer_id  == 1) &&
              (message.msg.clearlayer.sketch_id == 0))
            strcpy(pic_to_load, "\0");
        }

        case MSG_DRAW_LINE :
        case MSG_DRAW_POINT :
        case MSG_START_POINTER :
        case MSG_END_POINTER :
        case MSG_MOVE_POINTER :
        case MSG_CLEAR :
        case MSG_START_FREEHAND :
        case MSG_END_FREEHAND :
        case MSG_ERASE_OBJECT :
        case MSG_MOVE_OBJECT :
        case MSG_SIZE_OBJECT :
        case MSG_NEW_LAYER :
        case MSG_KILL_LAYER :
        case MSG_RENAME_LAYER :
        case MSG_SET_LAYER_COLOR :
        case MSG_DRAW_TEXT :
        case MSG_DRAW_RECTANGLE : 
        case MSG_DRAW_ARC :
        case MSG_AUDIO :
	case MSG_LAY_COL_CHANGED:
        {
          UpdateDatabase (message);
          if (message.to == TO_ALL)
	  {
            /* send message to all other SketchPad processes */
            for (i = 0; i < numberOfUser; i++) 
            {
              if (i != message.from) 
              {
                SEND (i, message);
              }
            }
          }
          else
          {
            SEND (message.to, message);
          }

          break;
        }

        case MSG_WRITE_OBJECT :
        {
          /***** local variables *****/
          long int   bytes2;

          /* get the rest of the message */
          bytes2 = message.msg.wrobj.size;
          data = (char *) malloc (bytes2);
          status = ISCrecv (channel, data, bytes2);
          if (status != bytes2)
          {
            ERR ("MSG_WRITE_OBJECT received data of wrong size!");   
            free (data);
	    free_channel(channel);
            break;
          }

          UpdateDatabase (message);

          /* set message data to all other SketchPad processes */
          FirstEntry (userList);
          while (GetListState (userList) == E_OK)
          {
            user_v = (struct user_s *) GetEntry (userList);
            if ( user_v->userno != message.from ) 
            {
              if (user_v->addressValid == TRUE)
              {
                if ((message.to == TO_ALL) || (message.to == user_v->userno))
                {
                  /* send complete message */
                  status = ISCsend (user_v->channel, (char *) &message,
                                    sizeof (msg_struct));
                  status = ISCsend (user_v->channel, data, bytes2);
                }
              }
            }
            NextEntry (userList);
          }
          free (data);
          break;
        }

        case MSG_TELL_ADDRESS :
        {
          struct user_s *user;
          void *savepos;

          user_v = (struct user_s *) findUser (message.from);
          
          /* send the data of all user in the conference to the */
          /* user, who sent the this message */
          FirstEntry (userList);
          user = GetEntry (userList);
          while (user != NULL)
          {
            message.msg_type = MSG_SET_NEW_USER;
            message.to = user_v->userno;
            message.msg.setnewuser.sketch_id = user->userno;
            strcpy (message.msg.setnewuser.username, user->username);
            strcpy (message.msg.setnewuser.displayname, user->displayname);
            strcpy (message.msg.setnewuser.hostname, user->hostn);
            savepos = GetListPosition (userList);
            SEND (user_v->userno, message);
            SetListPosition (userList, savepos);
            NextEntry (userList);
            user = GetEntry (userList);
          }

          /* test, if the sketchpad from the user applying this message */
          /* is started manualy from within the conference. */
          /* if so, then send a message to the initiator of this */

          if (user_v != NULL)
          {
            if ((user_v->initiator >= 0) ||
                (user_v->initiator == FROM_CNFSERVER))
            {

              /* if SketchPad instance is created by conference server, the
                 layer data should be sent too. But this could cause problems
                 if it is the first SketchPad.
                 This should be varified later!!! */

              /* send the name of the background-picture to load */
              if (strlen (pic_to_load) != 0)
              {
                message.from = -1;
                message.to   = user_v->userno;
                message.msg_type = MSG_PIC_LOADED;
                strcpy (message.msg.name, pic_to_load);
                SEND (user_v->userno, message);
              }
              /* send the information about all drawing layers */
              {
                char *layer_name;
                int  layer_id, sketch_id;
                int  r;

                r = GetFirstLayer (&layer_name, &layer_id, &sketch_id);
                while (r == 1)
                {
                  if ((layer_id != 1) || (sketch_id != 0))
                  {
                    message.from     = -1;
                    message.to       = user_v->userno;
                    message.msg_type = MSG_NEW_LAYER;
                    strcpy (message.msg.newlayer.layername, layer_name);
                    message.msg.newlayer.layer_id  = layer_id;
                    message.msg.newlayer.sketch_id = sketch_id;
                    message.msg.newlayer.visible   = TRUE;
                    SEND (user_v->userno, message);
                  }
                  r = GetNextLayer (&layer_name, &layer_id, &sketch_id);
                }
              }
              {
                /***** local variables *****/
                void *o;
                char buffer[16384];

                /* send the object-data for each layer seperate */
                {
                  int   result;
                  int   layer_id;
                  int   sketch_id;
                  char  *dummyChar;
                  struct_storage ss;
                  int   objNr;
                  int   ssize;
        
                  objNr = 0;
                  result = GetFirstLayer (&dummyChar, &layer_id, &sketch_id);
                  /* for all layers do: */
                  while (result != 0)
                  {
                    ss = GetStructStorage (layer_id, sketch_id);
                    o = GetFirstObj (ss);
                    /* for all object in this layer do: */
                    while (o != NULL)
                    {
                      ReadObject (o, buffer);
                      ssize = strlen (buffer) + 1;
                      message.msg_type = MSG_WRITE_OBJECT;
                      message.from     = -1;
                      message.to       = user_v->userno;
                      GetObjId (o, &message.msg.wrobj.id1,
                                &message.msg.wrobj.id2);
                      message.msg.wrobj.size      = ssize;
                      message.msg.wrobj.layer_id  = layer_id;
                      message.msg.wrobj.sketch_id = sketch_id;
                      if (user_v->addressValid == TRUE)
                      {
                        /* send one object as message */

                        status = ISCsend (user_v->channel,(char *) &message,
                                          sizeof (msg_struct));
                        status = ISCsend (user_v->channel, buffer, ssize);
                      }
                      o = GetNextObj (ss);
                    }
                    result = GetNextLayer (&dummyChar, &layer_id, &sketch_id);
                  }
                }
              }
              /* if there is a pointer visible, we have to send this, too */
              {
                int i;

                for (i = 0; i < MAXUSERS; i ++)
                {
                  if (pointer_visible[i])
                  {
                    message.msg_type = MSG_START_POINTER;
                    message.from     = -1;
                    message.to       = user_v->userno;
                    message.msg.pointer_to.userno = i;
                    message.msg.pointer_to.x = ptr_bbox[i].x;
                    message.msg.pointer_to.y = ptr_bbox[i].y;
                    status = ISCsend (user_v->channel, (char *)&message,
                                      sizeof (msg_struct));
                  }
                }
              }

              /* 
               * Send new layer information to all SketchPads and
               * update the database. 
               */

              message.from = FROM_MASTER;
              message.msg_type = MSG_NEW_LAYER; 
              strcpy (message.msg.newlayer.layername, user_v->username);
              message.msg.newlayer.layer_id = 2;
              message.msg.newlayer.sketch_id = user_v->userno;
              UpdateDatabase (message);

              {
                int i;

                for (i = 0; i < numberOfUser; i++)
                {
		  message.to = i;
		  SEND (i, message);
                }
              }

            }
            else
            {
              msg_struct m2;
  
              m2.msg_type = MSG_NEW_LAYER;
              m2.to       = user_v->userno;
              m2.from     = message.from;
              strcpy (m2.msg.newlayer.layername, "layer one");
              m2.msg.newlayer.layer_id  = 2;
              m2.msg.newlayer.sketch_id = 0;
              UpdateDatabase (m2);
              SEND (m2.to, m2);
            }
          }
	  break;
        }

        case MSG_NEW_USER :
        {

          /* add a new SketchPad user to the conference */
          user_v = (struct user_s *) malloc (sizeof (struct user_s));
          strcpy (user_v->displayname, message.msg.newuser.displayname);
          strcpy (user_v->username, message.msg.newuser.username);

          if (strlen(message.msg.newuser.hostname) >= 1)
          {
	    strcpy (user_v->hostn, message.msg.newuser.hostname);
          }
          else
          {
            ISCgethostn (user_v->hostn);
          }

          user_v->userno = numberOfUser;
          user_v->initiator = message.from;

          if (user_v->displayname[0] == '\000')
          {
            strcpy (user_v->displayname, getenv ("DISPLAY"));
          }
          if (user_v->displayname[0] == '\000')
          {
            strcpy (user_v->displayname, "unix:0.0");
          }

	  sprintf (parameters, "%ld/%s", user_v->userno, user_v->displayname);

	  status = ISCstart ("sketchpad", user_v->hostn, parameters);

	  if (status >= 0)
	  {
            numberOfUser++;  /* number of user since conference-start         */
            numberOfUser2++; /* actual number of user at this conference      */
	    user_v->channel = status;
	    user_v->addressValid = TRUE;
	  }
	  else
	  {
	    user_v->channel = -1;
	    user_v->addressValid = FALSE;
	  }

          InsertEndEntry (userList, user_v);

          {
            int i;

            for (i = 0; i < numberOfUser; i++)
            {
              if (i != user_v->userno)
              {
                message.msg_type = MSG_SET_NEW_USER;
                message.to = i;
                message.msg.setnewuser.sketch_id = user_v->userno;
                strcpy (message.msg.setnewuser.username, user_v->username);
                strcpy (message.msg.setnewuser.displayname,
                        user_v->displayname);
                strcpy (message.msg.setnewuser.hostname, user_v->hostn);
                SEND (i, message);
              }
            }
          }

          break;
        }

        case MSG_CANNOT_LOAD_PIC :
        {
          /***** local variables *****/
          struct stat   buf;
          FILE          *temppicfile;
          char          *data;
          struct user_s *myuser;
          long int      status;
          long int      r;

          /* one sketchpad process could not load the requested picture */
/*          fprintf (stderr, "*** Start: received request to send %s.\n",   
                   message.msg.name);                                         */

          /* send message to initiating sketchpad */
          if (strcmp(message.msg.name, pic_to_load) == 0)
          {
            /* store request with user data */
            user_v = (struct user_s *) findUser (message.from);
            user_v->pic_request = 1;
            strcpy(user_v->pic_name, message.msg.name);

            if (!pic_requested)
            {
/*              fprintf(stderr,"*** Start: Telling Initiator to send %s.\n",
                message.msg.name);                                            */
              message.msg_type = MSG_SEND_PIC;
              SEND(initiator_id, message);
              pic_requested = 1;
            }
            else
            {
              stat (TEMP_PIC_FILE, &buf);
              /* read picture data from temporary file */
              if (( temppicfile = fopen ( TEMP_PIC_FILE, "r" )) == NULL )
              {
                fprintf(stderr,"cannot open temporary picture file.\n");
                exit(1);
              }
/*             fprintf(stderr,"*** Start: reading temporary picture file.\n");*/
/*              fprintf(stderr,"*** Start: sending picture data to %d\n", 
                message.from);                                                */
              myuser = (struct user_s *) findUser(message.from);

              /* send message-header */
              message.msg_type = MSG_PIC_TO_LOAD;
              message.msg.pictl.size = buf.st_size;
              strcpy(message.msg.pictl.name, pic_to_load);

              status = ISCsend (channel, (char *) &message, sizeof (msg_struct));

              if (!(data = (char *) malloc (message.msg.pictl.size)))
              {
                fprintf(stderr, "MSG_CANNOT_LOAD_PIC: unable to malloc.\n");
                exit(1);
              }
              r = fread(data, 1, message.msg.pictl.size, temppicfile);
              status = ISCsend (channel, data, message.msg.pictl.size);
              fclose(temppicfile);
            }
          }
          else
          {
/*            fprintf(stderr,"*** Start: File name is not up to date:\n"
                    "           last file loaded was %s\n", pic_to_load);     */
          }
	  break;
        }

        case MSG_SEND_PIC :
        {
          fprintf(stderr,"start.c: received MSG_SEND_PIC!\n"); 
          fprintf(stderr,"         this cannot happen!\n");
          break;
        }

        case MSG_PIC_TO_LOAD :
        {
          /* data from the initiating sketchpad process arriving ... */

          /***** local variables *****/
	  FILE          *temppicfile;
          long int      datasize;
	  long int      status;
          long int      bytes3;
	  char          *data;
	  struct user_s *myuser;

          if (message.to == TO_ALL)
          {
            /* remember picture file name */
            strcpy (pic_to_load, message.msg.pictl.name);
          }

          /* first receive rest of message */

          /* size of the rest of the message */
          datasize = message.msg.pictl.size;

          /* get memory for the rest message */
          data = (char *) malloc (datasize);

          /* receive rest of message */
          status = ISCrecv (channel, data, datasize);
          if (status != datasize)
          {
            ERR ("MSG_PIC_TO_LOAD received data of wrong size!");   
            free (data);
	    free_channel(channel);
            break;
          }
/*          fprintf(stderr,"*** Start: received picture data.\n");            */

          /* store data */
          temppicfile = fopen (TEMP_PIC_FILE, "w");
          if (temppicfile == NULL)
          {
            fprintf(stderr,"cannot open temporary picture file.\n");
            exit(1);
          }
/*          fprintf(stderr,"*** Start: writing temporary picture file.\n");   */
          bytes3 = fwrite(data, 1, datasize, temppicfile);
          fclose(temppicfile);

          /* look for sketchpads that requested data transfer */
          FirstEntry (userList);
          while (GetListState (userList) == E_OK)
          {
            myuser = (struct user_s *) GetEntry (userList);
            if ((myuser->pic_request == 1) || (message.to == TO_ALL))
            {
              if (myuser->addressValid == TRUE)
              {
                if ((strcmp(myuser->pic_name,message.msg.pictl.name) == 0) ||
                   ((message.to==TO_ALL)&&(message.from != myuser->userno)))
                {
                  /* send data to sketchpad */
/*                  fprintf (stderr, "*** Start: sending picture data to %d\n",
                           myuser->userno);                                   */
                  {
                    /* send complete message */
                    status = ISCsend (myuser->channel, (char *) &message,
                                      sizeof (msg_struct));
                    status = ISCsend (myuser->channel, data, datasize);
                    myuser->pic_request = 0;
                  }
                }
              }
            }
            NextEntry (userList);
          }
          free(data);
          break;
        }

        case MSG_APPLY_ZOOM :
        {
          /* changed raster data from initializing sketchpad arriving */

          /***** local variables *****/
          long int      datasize;
          long int      status;
          char          *data;

          /* first receive rest of message */

          /* size of the rest of the message */
          datasize = message.msg.applyzoom.size;

          /* get memory for the rest message */
          data = (char *) malloc (datasize);

          /* receive rest of message */
          status = ISCrecv (channel, data, datasize);
          if (status != datasize)
          {
            ERR ("MSG_APPLY_ZOOM received data of wrong size!");
            free (data);
	    free_channel(channel);
            break;
          }

          /* send message to all other SketchPad processes */
          FirstEntry (userList);
          while (GetListState (userList) == E_OK)
          {
            user_v = (struct user_s *) GetEntry (userList);
            if ( user_v->userno != message.from )
            {
              if (user_v->addressValid == TRUE)
              {
                if ((message.to == TO_ALL) || (message.to == user_v->userno))
                {
                  /* send complete message */
                  status = ISCsend (user_v->channel, (char *)&message,
                                    sizeof (msg_struct));
                  status = ISCsend (user_v->channel, data, datasize);
                }
              }
            }
            NextEntry (userList);
          }
          free (data);
          break;
        }

        case MSG_SYNC_USER :
        {
          SEND (message.to, message);
          break;
        }


        default :
        {
          printf ("start.c: UMO (unknown message object) received\n");
          break;
        }
      }
    } 
    else 
    {
      /* is there an error occured ?                                          */
      if (bytes == -1)
      {
        /* then print error number                                            */
        printf ("error: %d\n", errno);
      } 
      if (bytes == 0) 
      {
	free_channel(channel);
      }
      else 
      {
        /* else print own error message and size of wrong sized message       */
        printf ("wrong size of message !!! (%d Bytes)\n", bytes);
      }
    }
    /* until there are no more user-processes                                 */

  } while (numberOfUser2 > 0);


} /* end of ServeSketchPads */


/* ========================================================================== */
/*      free_channel                                                          */
/* ========================================================================== */

free_channel(channel)
{

struct user_s *user;
long int      i;

/***** connection lost to SketchPad process *****/
printf ("start: lost connection to SketchPad process on channel %d!\n",
        channel);
ISCclose (channel);

/***** remove that user from the list *****/

for (i = 0; i < numberOfUser; i ++)
  {
   user = (struct user_s *) findUser (i);
   if (user->channel == channel)
     {
       user->addressValid = FALSE;
       break;
     }
   }
numberOfUser2 --;
}

/* ========================================================================== */
/*      main                                                                  */
/* ========================================================================== */

int main (long int argc, char *argv[])

{
  /***** local variables *****/
  int  i;             /* loop-counter                                         */

  for (i = 0; i < MAXUSERS; i++)
  {
    pointer_visible[i] = 0;
    freehandArray[i] = NULL;
  }

  highest_layer_id = 1;
  errtext = (char *) malloc (128 * sizeof (char));
  userList = CreateList ();
  InitLayers ();
  AddLayer ("Background", 1, 0);

    CreateUserList ();

  ISCinit ();

    StartupSketchPads ();

  ServeSketchPads ();

  close (receive_socket);
  free (errtext);
  remove(TEMP_PIC_FILE);

  return (0);
} /* end of main */

/* end of file: start.c */
