/* ========================================================================== */
/*                                                                            */
/* Filename:     message.h                        +-----+-----+--+--+--+--+   */
/* Version :     1.5	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 2/10/93	12:13:08	                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      USED BY: sketchpad.c                                                  */
/*               start.c                                                      */
/*               draw.c                                                       */
/*                                                                            */
/* ========================================================================== */

#include "../global/global.h"
#include <X11/Intrinsic.h>

/* ========================================================================== */
/*      DEFINE STATEMENTS                                                     */
/* ========================================================================== */

/* define all used message-names */

# define MSG_PIC_LOADED         1
# define MSG_APP_ENDED          2
# define MSG_DRAW_LINE          3
# define MSG_DRAW_POINT         4
# define MSG_END_POINTER        5
# define MSG_START_POINTER      6
# define MSG_MOVE_POINTER       7
# define MSG_TELL_ADDRESS       8
# define MSG_CLEAR              9
# define MSG_START_FREEHAND    10
# define MSG_END_FREEHAND      11
# define MSG_ERASE_OBJECT      12
# define MSG_MOVE_OBJECT       13
# define MSG_SIZE_OBJECT       14
# define MSG_WRITE_OBJECT      15
# define MSG_NEW_USER          16
# define MSG_NEW_LAYER         17
# define MSG_RENAME_LAYER      18
# define MSG_KILL_LAYER        19
# define MSG_CLEAR_LAYER       20
# define MSG_DRAW_TEXT         21
# define MSG_CANNOT_LOAD_PIC   22
# define MSG_PIC_NOT_LOADED    23
# define MSG_SEND_PIC          24
# define MSG_PIC_TO_LOAD       25
# define MSG_SET_LAYER_COLOR   26
# define MSG_DRAW_RECTANGLE    27
# define MSG_DRAW_ARC          28
# define MSG_SET_NEW_USER      29
# define MSG_APPLY_ZOOM        30
# define MSG_AUDIO             31
# define MSG_LAY_COL_CHANGED   32
# define MSG_SYNC_USER         33

# define MSG_END_SKETCHPAD     44

# define FROM_CNFSERVER       -99

# define FROM_MASTER           -1
# define TO_ALL                -1
# define TO_MASTER             -2

# define LAYERNAMELEN          20
# define TEXTLEN               80
# define MAXNUMLAYER           80

# define CNFADDUSER             1
# define CNFREMOVEUSER          2

/* ========================================================================== */
/*      NEW TYPES                                                             */
/* ========================================================================== */

typedef struct {
                 int from;        /* id of user, who send the message         */
                 int to;          /* id of user to receive this message       */
                                  /* (-1 if send to all users)                */
                 int msg_type;    /* type of message, use constant from above */
                 union {

                   char name[80]; /* if msg_type == MSG_PIC_LOADED then       */
                                  /* name of picture to load                  */

                   struct {       /* if msg_type == MSG_DRAW_LINE then        */
                     int x1, y1;  /* start point of line                      */
                     int x2, y2;  /* end point of line                        */
                     int id1;
                     int id2;
                     unsigned int lwidth;          /* line attributes         */
                     unsigned int lstyle;
                     int layer_id;
                     int sketch_id;
                   } line;

                   struct {       /* if msg_type == MSG_START_POINTER         */
                     int x, y;    /* coordinates of new pointer               */
                     int userno;
                   } pointer_to;

                   struct {       /* if msg_type == MSG_MOVE_POINTER          */
                     int x, y;    /* coordinates of new or moved pointer      */
                   } pointer;

                   struct {       /* if msg_type == MSG_START_FREEHAND        */
                     int x, y;
                     unsigned int lwidth;          /* line attributes         */
                     unsigned int lstyle;
                     int id1;
                     int id2;
                     int layer_id;
                     int sketch_id;
                   } free;

                   struct {       /* if msg_type == MSG_ERASE_OBJECT          */
                     int id1;
                     int id2;
                     int layer_id;
                     int sketch_id;
                   } erase;

                   struct {       /* if msg_type == MSG_MOVE_OBJECT           */
                     int dx;
                     int dy;
                     int id1;
                     int id2;
                     int layer_id;
                     int sketch_id;
                   } move;

                   struct {       /* if msg_type == MSG_SIZE_OBJECT           */
                     int x;
                     int y;
                     int w;
                     int h;
                     int id1;
                     int id2;
                     int layer_id;
                     int sketch_id;
                   } size;

                   struct {       /* if msg_type == MSG_PIC_TO_LOAD           */
                     int id1;
                     int size;
                     char name[80];
                   } pictl;

                   struct {       /* if msg_type == MSG_WRITE_OBJECT          */
                     int id1;
                     int id2;
                     int size;
                     int layer_id;
                     int sketch_id;
                   } wrobj;

                   struct {       /* if msg_type == MSG_NEW_USER              */
                     char username[32];
                     char displayname[32];
                     char hostname[32];
                   } newuser;

                   struct {       /* if msg_type == MSG_NEW_LAYER             */
                     char layername[LAYERNAMELEN];
                     int  layer_id;
                     int  sketch_id;
                     int  visible;
                   } newlayer;

                   struct {       /* if msg_type == MSG_RENAME_LAYER          */
                     char layername[LAYERNAMELEN];
                     int  layer_id;
                     int  sketch_id;
                   } renamelayer;

                   struct {       /* if msg_type == MSG_KILL_LAYER            */
                     int  layer_id;
                     int  sketch_id;
                   } killlayer;

                   struct {       /* if msg_type == MSG_CLEAR_LAYER           */
                     int  layer_id;
                     int  sketch_id;
                   } clearlayer;

                   struct {       /* if msg_type == MSG_SET_LAYER_COLOR       */
                     int  layer_id;
                     int  sketch_id;
                     unsigned short int red;
                     unsigned short int green;
                     unsigned short int blue;
                   } layercolor;

                   struct {       /* if msg_type == MSG_DRAW_TEXT             */
                     char txt[TEXTLEN];
                     int fontsize;
                     int fontthick;
                     int fontslant;
                     int x;
                     int y;
                     int w;
                     int h;
                     int id1;
                     int id2;
                     int layer_id;
                     int sketch_id;
                   } text;

                   struct {       /* if msg_type == MSG_DRAW_RECTANGLE then   */
                     int x, y;    /* upper left corner of rectangle           */
                     int w, h;    /* width and height                         */
                     unsigned int lwidth;         /* line attributes          */
                     unsigned int lstyle;
                     int id1;
                     int id2;
                     int layer_id;
                     int sketch_id;
                   } rectangle;

                   struct {       /* if msg_type == MSG_DRAW_ARC then         */
                     int x, y;    /* upper left corner of bounding rectangle  */
                     int w, h;    /* width and height                         */
                     int angle1,
                         angle2;  /* begin and end angle of arc               */
                     unsigned int lwidth;         /* line attributes          */
                     unsigned int lstyle;
                     int id1;
                     int id2;
                     int layer_id;
                     int sketch_id;
                   } arc;

                   struct {       /* if msg_type == MSG_SET_NEW_USER          */
                     int  sketch_id;
                     char username[MAXUSERNAMELEN+1];
                     char hostname[MAXHOSTNAMELEN+1];
                     char displayname[MAXDISPLAYNAMELEN+1];
                   } setnewuser;

                   struct {       /* if msg_type == MSG_APPLY_ZOOM            */
                     int x, y;    /* upper left corner in drawing area        */
                     int w, h;    /* width and height                         */
                     int size;    /* size of data packet                      */
                   } applyzoom;

                   struct {             /* if msg_type == MSG_LAY_COL_CHANGED */
                       int list_pos;                   /* position of the       */
                                                       /* changed layer in the  */
                                                       /* layer-list to identi- */
                                                       /* fy the layer.         */
                      char layername[LAYERNAMELEN+1];  /* Name of changed Layer */
                      XColor  to_color;                /* to which color?       */
                    } changedlaycol;                 

                   struct {       /* if msg_type == MSG_SYNC_USER             */
                      int ask;                /* request or answer flag       */
                      int x1, y1;             /* upper left corner            */
                      int width, height;      /* window extensions            */
                      unsigned char layVisible[MAXNUMLAYER];
                   } syncuser;

                   Boolean set;

                 } msg;
               } msg_struct;

/* ========================================================================== */
/*      The End                                                               */
/* ========================================================================== */
