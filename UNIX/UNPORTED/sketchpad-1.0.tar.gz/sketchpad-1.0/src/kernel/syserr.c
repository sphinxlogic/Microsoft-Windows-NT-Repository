/* ========================================================================== */
/*                                                                            */
/* Filename:     syserr.c                         +-----+-----+--+--+--+--+   */
/* Version :     1.5	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/16/92	16:49:38	                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/* This function syserr translates the errno variable of the UNIX operation   */
/* system to a clear text description. The meanings of the error numbers      */
/* are dependent from the type of UNIX. This program has to be compiled with  */
/* the correct UNIX version identified by an -D option.                       */
/*                                                                            */
/* The follwing option are known, and one of them must be used!               */
/*                                                                            */
/* 1. SUN Operating System (tested version is SUN-OS 4.1.1)    : -Dsparc        */
/* 2. IBM AIX on RS/6000 (tested version is AIX 3.1)           : -D_AIX       */
/* 3. Ultrix-32 on DEC micro VAX (tested DECNet-Ultrix-32 3.1) : -Dvax        */
/*                                                                            */
/* ========================================================================== */

/* Test if the user has read the message above ...                            */

# define sparc
# if !defined(_AIX) && !defined(sparc) && !defined(vax)
# error You have to define the maschine type (-D... sparc,_AIX or vax)!
# endif

/* ========================================================================== */

# include <sys/errno.h>
# include <stdio.h>

/* ========================================================================== */

void syserr (long int errno, char *text[])

{
  /***** local variables *****/
  char   *systype;       /* operating system type                             */
  char   *t;             /* error message                                     */

  t = "unknown system error";

# ifdef sparc
  systype = "SUN-OS";
# endif
# if vax
  systype = "Ultrix";
# endif
# if _AIX
  systype = "AIX";
# endif

  switch (errno)
  {
    case EPERM            /*  1 */ : {t = "Not owner"; break;}
    case ENOENT           /*  2 */ : {t = "No such file or directory"; break;}
    case ESRCH            /*  3 */ : {t = "No such process";  break;}
    case EINTR            /*  4 */ : {t = "Interrupted system call";  break;}
    case EIO              /*  5 */ : {t = "I/O error";  break;}
    case ENXIO            /*  6 */ : 
      {t = "No such device or address";  break;}
    case E2BIG            /*  7 */ : {t = "Arg list too long";  break;}
    case ENOEXEC          /*  8 */ : {t = "Exec format error";  break;}
    case EBADF            /*  9 */ : {t = "Bad file number";  break;}
    case ECHILD           /* 10 */ : {t = "No children";  break;}
    case EAGAIN           /* 11 */ : {t = "No more processes";  break;}
    case ENOMEM           /* 12 */ : {t = "Not enough core";  break;}
    case EACCES           /* 13 */ : {t = "Permission denied";  break;}
    case EFAULT           /* 14 */ : {t = "Bad address";  break;}
    case ENOTBLK          /* 15 */ : {t = "Block device required"; break;}
    case EBUSY            /* 16 */ : {t = "Mount device busy"; break;}
    case EEXIST           /* 17 */ : {t = "File exists"; break;}
    case EXDEV            /* 18 */ : {t = "Cross-device link"; break;}
    case ENODEV           /* 19 */ : {t = "No such device"; break;}
    case ENOTDIR          /* 20 */ : {t = "Not a directory"; break;}
    case EISDIR           /* 21 */ : {t = "Is a directory"; break;}
    case EINVAL           /* 22 */ : {t = "Invalid argument"; break;}
    case ENFILE           /* 23 */ : {t = "File table overflow"; break;}
    case EMFILE           /* 24 */ : {t = "Too many open files"; break;}
    case ENOTTY           /* 25 */ : {t = "Not a typewriter"; break;}
    case ETXTBSY          /* 26 */ : {t = "Text file busy"; break;}
    case EFBIG            /* 27 */ : {t = "File too large"; break;}
    case ENOSPC           /* 28 */ : {t = "No space left on device"; break;}
    case ESPIPE           /* 29 */ : {t = "Illegal seek"; break;}
    case EROFS            /* 30 */ : {t = "Read-only file system"; break;}
    case EMLINK           /* 31 */ : {t = "Too many links"; break;}
    case EPIPE            /* 32 */ : {t = "Broken pipe"; break;}
    case EDOM             /* 33 */ : {t = "Argument too large"; break;}
    case ERANGE           /* 34 */ : {t = "Result too large"; break;}

# ifdef _AIX

    case ENOMSG           /* 35	*/ : 
      {t = "No message of desired type"; break;}
    case EIDRM	          /* 36	*/ : {t = "Identifier removed"; break;}
    case ECHRNG	          /* 37	*/ : 
      {t = "Channel number out of range"; break;}
    case EL2NSYNC         /* 38	*/ : {t = "Level 2 not synchronized"; break;}
    case EL3HLT	          /* 39	*/ : {t = "Level 3 halted"; break;}
    case EL3RST	          /* 40	*/ : {t = "Level 3 reset"; break;}
    case ELNRNG	          /* 41	*/ : {t = "Link number out of range"; break;}
    case EUNATCH          /* 42	*/ : 
      {t = "Protocol driver not attached"; break;}
    case ENOCSI	          /* 43	*/ : 
      {t = "No CSI structure available"; break;}
    case EL2HLT           /* 44	*/ : {t = "Level 2 halted"; break;}
    case EDEADLK          /* 45	*/ : {t = "Resource deadlock avoided"; break;}
    case ENOTREADY        /* 46	*/ : {t = "Device not ready"; break;}
    case EWRPROTECT	  /* 47	*/ : {t = "Write-protected media"; break;}
    case EFORMAT	  /* 48	*/ : {t = "Unformatted media"; break;}
    case ENOLCK	          /* 49 */ : {t = "No locks available"; break;}
    case ENOCONNECT       /* 50 */ : {t = "no connection"; break;}
    case ESTALE           /* 52 */ : {t = "no filesystem"; break;}
    case EDIST		  /* 53 */ : 
      {t = "old, currently unused AIX errno"; break;}
    case EINPROGRESS      /* 55 */ : {t = "Operation now in progress"; break;}
    case EALREADY         /* 56 */ : 
      {t = "Operation already in progress"; break;}
    case ENOTSOCK         /* 57 */ : 
      {t = "Socket operation on non-socket"; break;}
    case EDESTADDRREQ     /* 58 */ : 
      {t = "Destination address required"; break;}
    case EMSGSIZE         /* 59 */ : {t = "Message too long"; break;}
    case EPROTOTYPE       /* 60 */ : 
      {t = "Protocol wrong type for socket"; break;}
    case ENOPROTOOPT      /* 61 */ : {t = "Protocol not available"; break;}
    case EPROTONOSUPPORT  /* 62 */ : {t = "Protocol not supported"; break;}
    case ESOCKTNOSUPPORT  /* 63 */ : {t = "Socket type not supported"; break;}
    case EOPNOTSUPP       /* 64 */ : 
      {t = "Operation not supported on socket"; break;}
    case EPFNOSUPPORT     /* 65 */ : 
      {t = "Protocol family not supported"; break;}
    case EAFNOSUPPORT     /* 66 */ : 
      {t = "Address family not supported by protocol family"; break;}
    case EADDRINUSE       /* 67 */ : {t = "Address already in use"; break;}
    case EADDRNOTAVAIL    /* 68 */ : 
      {t = "Can't assign requested address"; break;}
    case ENETDOWN         /* 69 */ : {t = "Network is down"; break;}
    case ENETUNREACH      /* 70 */ : {t = "Network is unreachable"; break;}
    case ENETRESET        /* 71 */ : 
      {t = "Network dropped connection on reset"; break;}
    case ECONNABORTED     /* 72 */ : 
      {t = "Software caused connection abort"; break;}
    case ECONNRESET       /* 73 */ : {t = "Connection reset by peer"; break;}
    case ENOBUFS          /* 74 */ : {t = "No buffer space available"; break;}
    case EISCONN          /* 75 */ : 
      {t = "Socket is already connected"; break;}
    case ENOTCONN         /* 76 */ : {t = "Socket is not connected"; break;}
    case ESHUTDOWN        /* 77 */ : 
      {t = "Can't send after socket shutdown"; break;}
    case ETIMEDOUT        /* 78 */ : {t = "Connection timed out"; break;}
    case ECONNREFUSED     /* 79 */ : {t = "Connection refused"; break;}
    case EHOSTDOWN        /* 80 */ : {t = "Host is down"; break;}
    case EHOSTUNREACH     /* 81 */ : {t = "No route to host"; break;}
    case ERESTART	  /* 82	*/ : {t = "restart the system call"; break;}
    case EPROCLIM	  /* 83	*/ : {t = "Too many processes"; break;}
    case EUSERS		  /* 84	*/ : {t = "Too many users"; break;}
    case ELOOP		  /* 85	*/ : 
      {t = "Too many levels of symbolic links"; break;}
    case ENAMETOOLONG	  /* 86	*/ : {t = "File name too long"; break;}
    case EDQUOT		  /* 88	*/ : {t = "Disc quota exceeded"; break;}
    case EREMOTE	  /* 93	*/ : {t = "Item is not local to host"; break;}
    case ENOSYS		  /*109 */ : 
      {t = "Function not implemented  POSIX"; break;}
    case EMEDIA		  /*110 */ : {t = "media surface error"; break;}
    case ESOFT            /*111 */ : 
      {t = "I/O completed, but needs relocation"; break;}
    case ENOATTR	  /*112 */ : {t = "no attribute found"; break;}
    case ESAD		  /*113	*/ : 
      {t = "security authentication denied"; break;}
    case ENOTRUST	  /*114	*/ : {t = "not a trusted program"; break;}
# else 
    case EINPROGRESS      /* 36 */ : {t = "Operation now in progress"; break;}
    case EALREADY         /* 37 */ : 
      {t = "Operation already in progress"; break;}
    case ENOTSOCK         /* 38 */ : 
      {t = "Socket operation on non-socket"; break;}
    case EDESTADDRREQ     /* 39 */ : 
      {t = "Destination address required"; break;}
    case EMSGSIZE         /* 40 */ : {t = "Message too long"; break;}
    case EPROTOTYPE       /* 41 */ : 
      {t = "Protocol wrong type for socket"; break;}
    case ENOPROTOOPT      /* 42 */ : {t = "Protocol not available"; break;}
    case EPROTONOSUPPORT  /* 43 */ : {t = "Protocol not supported"; break;}
    case ESOCKTNOSUPPORT  /* 44 */ : {t = "Socket type not supported"; break;}
    case EOPNOTSUPP       /* 45 */ : 
      {t = "Operation not supported on socket"; break;}
    case EPFNOSUPPORT     /* 46 */ : 
      {t = "Protocol family not supported"; break;}
    case EAFNOSUPPORT     /* 47 */ : 
      {t = "Address family not supported by protocol family"; break;}
    case EADDRINUSE       /* 48 */ : {t = "Address already in use"; break;}
    case EADDRNOTAVAIL    /* 49 */ : 
      {t = "Can't assign requested address"; break;}
    case ENETDOWN         /* 50 */ : {t = "Network is down"; break;}
    case ENETUNREACH      /* 51 */ : {t = "Network is unreachable"; break;}
    case ENETRESET        /* 52 */ : 
      {t = "Network dropped connection on reset"; break;}
    case ECONNABORTED     /* 53 */ : 
      {t = "Software caused connection abort"; break;}
    case ECONNRESET       /* 54 */ : {t = "Connection reset by peer"; break;}
    case ENOBUFS          /* 55 */ : {t = "No buffer space available"; break;}
    case EISCONN          /* 56 */ : 
      {t = "Socket is already connected"; break;}
    case ENOTCONN         /* 57 */ : {t = "Socket is not connected"; break;}
    case ESHUTDOWN        /* 58 */ : 
      {t = "Can't send after socket shutdown"; break;}
    case ETOOMANYREFS     /* 59 */ : 
      {t = "Too many references: can't splice"; break;}
    case ETIMEDOUT        /* 60 */ : {t = "Connection timed out"; break;}
    case ECONNREFUSED     /* 61 */ : {t = "Connection refused"; break;}
    case ELOOP            /* 62 */ : 
      {t = "Too many levels of symbolic links"; break;}
    case ENAMETOOLONG     /* 63 */ : {t = "File name too long"; break;}
    case EHOSTDOWN        /* 64 */ : {t = "Host is down"; break;}
    case EHOSTUNREACH     /* 65 */ : {t = "No route to host"; break;}
    case ENOTEMPTY        /* 66 */ : {t = "Directory not empty"; break;}
    case EUSERS           /* 68 */ : {t = "Too many users"; break;}
    case ESTALE           /* 70 */ : {t = "NFS error code ESTALE"; break;}
    case EREMOTE          /* 71 */ : {t = "NFS error code EREMOTE"; break;}
# ifdef vax
    case ENOMSG           /* 72 */ : 
      {t = "No message of desired type"; break;}
    case EIDRM            /* 73 */ : {t = "Identifier removed"; break;}
    case EALIGN           /* 74 */ : {t = "alignment error"; break;} 
    case ENOLCK           /* 75 */ : {t = "LOCK_MAX exceeded"; break;}
# endif
# ifdef sparc
    case ENOSTR           /* 72 */ : {t = "Device is not a stream"; break;}
    case ETIME            /* 73 */ : {t = "Timer expired"; break;}
    case ENOSR            /* 74 */ : {t = "Out of streams resources"; break;}
    case ENOMSG           /* 75 */ : 
      {t = "No message of desired type"; break;}
    case EBADMSG          /* 76 */ : 
      {t = "Trying to read unreadable message"; break;}
    case EIDRM            /* 77 */ : {t = "Identifier removed"; break;}
    case EDEADLK          /* 78 */ : {t = "Deadlock condition."; break;}
    case ENOLCK           /* 79 */ : 
      {t = "No record locks available."; break;}
    case ENONET           /* 80 */ : 
      {t = "Machine is not on the network"; break;}
    case ENOLINK          /* 82 */ : {t = "the link has been severed"; break;}
    case EADV             /* 83 */ : {t = "advertise error"; break;}
    case ESRMNT           /* 84 */ : {t = "srmount error"; break;}
    case ECOMM            /* 85 */ : 
      {t = "Communication error on send"; break;}
    case EPROTO           /* 86 */ : {t = "Protocol error"; break;}
    case EMULTIHOP        /* 87 */ : {t = "multihop attempted"; break;}
    case EREMCHG          /* 89 */ : {t = "Remote address changed"; break;}
    case ENOSYS           /* 90 */ : {t = "function not implemented"; break;}
# endif
# endif
  } 

  sprintf (*text, "%s (%d, %s)", t, errno, systype); 

} /* end of syserr */

/* ========================================================================== */
/*      The End of syserr.c                                                   */
/* ========================================================================== */
