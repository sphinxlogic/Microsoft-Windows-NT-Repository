/* ========================================================================== */
/*                                                                            */
/* Filename:     grab.c                           +-----+-----+--+--+--+--+   */
/* Version :     1.3	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/15/92	10:43:29	                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/* INCLUDE STATEMENTS                                                         */
/* ========================================================================== */

#include <X11/Xos.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/cursorfont.h>
#include <X11/Xmu/WinUtil.h>

#include <stdio.h>
/* HC
#include <stdlib.h>
*/

#include "../image/picio.h"
#include "../misc/cursor.h"

extern void SetWaitState(void);
extern void ClearWaitState(void);


/* ========================================================================== */
/* DEFINE STATEMENTS                                                          */
/* ========================================================================== */

#undef DEBUG

#define lowbit(x) ((x) & (~(x) + 1))

typedef unsigned long Pixel;


/* ========================================================================== */
/* GLOBAL VARIABLES                                                           */
/* ========================================================================== */

int pformat = ZPixmap;
long add_pixel_value = 0;
Bool NoBorders = True;


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  Select_Window                                            */
/*                                                                            */
/*      Version   :  27.02.1992                                               */
/*                                                                            */
/*      Purpose   :  Routine to let user select a window using the mouse      */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  GrabWindow()                                             */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
Window Select_Window(Display *dpy, int screen)
{
  int status;
  XEvent event;
  Window target_win = None, root = RootWindow(dpy,screen);
  int buttons = 0;

  /* Make the target cursor */
  grab_cursor = XCreateFontCursor(dpy, XC_crosshair);

  /* Grab the pointer using target cursor, letting it room all over */
  status = XGrabPointer(dpy, root, False,
                        ButtonPressMask|ButtonReleaseMask, GrabModeSync,
                        GrabModeAsync, root, grab_cursor, CurrentTime);
  if (status != GrabSuccess)
  {
    sperror("Grab: Can't grab the mouse.");
    return(None);
  }

  /* Let the user select a window... */
  while ((target_win == None) || (buttons != 0)) {
    /* allow one more event */
    XAllowEvents(dpy, SyncPointer, CurrentTime);
    XWindowEvent(dpy, root, ButtonPressMask|ButtonReleaseMask, &event);
    switch (event.type) {
    case ButtonPress:
      if (target_win == None) {
        target_win = event.xbutton.subwindow; /* window selected */
        if (target_win == None) target_win = root;
      }
      buttons++;
      break;
    case ButtonRelease:
      if (buttons > 0) /* there may have been some down before we started */
        buttons--;
       break;
    }
  }

  XUngrabPointer(dpy, CurrentTime);      /* Done with pointer */

  return(target_win);
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  Image_Size                                               */
/*                                                                            */
/*      Version   :  28.02.1992                                               */
/*                                                                            */
/*      Purpose   :  Determines the pixmap size                               */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  Window_Dump()                                            */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int Image_Size(XImage *image)
{
  if (pformat != ZPixmap)
    return(image->bytes_per_line * image->height * image->depth);

  return(image->bytes_per_line * image->height);
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  Get_XColors                                              */
/*                                                                            */
/*      Version   :  28.02.1992                                               */
/*                                                                            */
/*      Purpose   :  Get the XColors of all pixels in image                   */
/*                   returns # of colors                                      */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  Window_Dump()                                            */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int Get_XColors(Display *dpy, int screen, XWindowAttributes *win_info,
                XColor **colors)
{
  int i, ncolors;

  if (!win_info->colormap)
    return(0);

  if (win_info->visual->class == TrueColor)
    return(0);    /* colormap is not needed */

  ncolors = win_info->visual->map_entries;
  if (!(*colors = (XColor *) malloc (sizeof(XColor) * ncolors)))
  {
    sperror("Get_XColors: Out of memory!");
    return(0);
  }
  if (win_info->visual->class == DirectColor)
  {
    Pixel red, green, blue, red1, green1, blue1;

    red = green = blue = 0;
    red1 = lowbit(win_info->visual->red_mask);
    green1 = lowbit(win_info->visual->green_mask);
    blue1 = lowbit(win_info->visual->blue_mask);
    for (i=0; i<ncolors; i++)
    {
      (*colors)[i].pixel = red|green|blue;
      (*colors)[i].pad = 0;
      red += red1;
      if (red > win_info->visual->red_mask)
        red = 0;
      green += green1;
      if (green > win_info->visual->green_mask)
        green = 0;
      blue += blue1;
      if (blue > win_info->visual->blue_mask)
        blue = 0;
    }
  } 
  else 
  {
    for (i=0; i<ncolors; i++) 
    {
      (*colors)[i].pixel = i;
      (*colors)[i].pad = 0;
    }
  }

  XQueryColors(dpy, win_info->colormap, *colors, ncolors);

  return(ncolors);
} /* Get_XColors */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  Window_Dump                                              */
/*                                                                            */
/*      Version   :  28.02.1992                                               */
/*                                                                            */
/*      Purpose   :  dump a window to a file which must already be open for   */
/*                   writing                                                  */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  GrabWindow()                                             */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int Window_Dump(Display *dpy, int screen, Window window, FILE *out)
{
  XWindowAttributes win_info;
  int absx, absy, x, y;
  Window dummywin;
  unsigned width, height;
  int dwidth, dheight;
  int bw;
  char *win_name;
  Bool got_win_name;
  int win_name_size;
  XImage *image;
  char errortext[128];
  unsigned buffer_size;
  int ncolors, i;
  XColor *colors;

  byte *my_data;

  /*
   * Get the parameters of the window being dumped.
   */
#ifdef DEBUG
  fprintf(stderr, "Grab: Getting target window information.\n");
#endif DEBUG
  if(!XGetWindowAttributes(dpy, window, &win_info))
  {
    sperror("Window_Dump: cannot get window attributes");
    return(0);
  }
  /* handle any frame window */
  if (!XTranslateCoordinates (dpy, window, 
                              RootWindow(dpy, screen), 0, 0,
                              &absx, &absy, &dummywin))
  {
    sprintf(errortext, "WindowDump: unable to translate window coordinates "
                       "(%d,%d)", absx, absy);
    sperror(errortext);
  }
  win_info.x = absx;
  win_info.y = absy;
  width = win_info.width;
  height = win_info.height;
  bw = 0;

  if (!NoBorders)
  {
    absx -= win_info.border_width;
    absy -= win_info.border_width;
    bw = win_info.border_width;
    width += (2 * bw);
    height += (2 * bw);
  }
  dwidth = DisplayWidth (dpy, screen);
  dheight = DisplayHeight (dpy, screen);

  /* clip to window */
  if (absx < 0) width += absx, absx = 0;
  if (absy < 0) height += absy, absy = 0;
  if (absx + width > dwidth) width = dwidth - absx;
  if (absy + height > dheight) height = dheight - absy;

  XFetchName(dpy, window, &win_name);
  if (!win_name || !win_name[0])
  {
    win_name = "xwdump";
    got_win_name = False;
  }
  else
  {
    got_win_name = True;
  }

  /* sizeof(char) is included for the null string terminator. */
  win_name_size = strlen(win_name) + sizeof(char);

  /*
   * Snarf the pixmap with XGetImage.
   */

  x = absx - win_info.x;
  y = absy - win_info.y;
  image = XGetImage (dpy, window, x, y, width, height,
          AllPlanes, pformat);
  if (!image) 
  {
    sprintf(errortext, "Window_Dump: unable to get image at %dx%d+%d+%d",
            width, height, x, y);
    sperror(errortext);
  }

  if (add_pixel_value != 0) XAddPixel (image, add_pixel_value);

  /*
   * Determine the pixmap size.
   */
  buffer_size = Image_Size(image);

#ifdef DEBUG
  fprintf(stderr, "Grab: Getting Colors.\n");
#endif DEBUG

  ncolors = Get_XColors(dpy, screen, &win_info, &colors);
  if (ncolors == 0)
  {
    if (got_win_name) XFree(win_name);
    XDestroyImage(image);
    return(0);
  }

#ifdef DEBUG
  fprintf(stderr, "Number of used colors %d\n", ncolors);
  fprintf(stderr, "Image size %d x %d\n", image->width, image->height);
#endif DEBUG

  /***** write the image in GIF format *****/

  {
    long int i;
    byte   my_r[256], my_g[256], my_b[256];

    for (i = 0; i < ncolors; i ++)
    {
      my_r[i] = (byte) (colors[i].red >> 8);
      my_g[i] = (byte) (colors[i].green >> 8);
      my_b[i] = (byte) (colors[i].blue >> 8);
    }

    /* pack bytes of image data */
    my_data = (byte *) malloc(image->width * image->height * sizeof (byte));
    if (!my_data)
    {
      sperror("Window_Dump: unable to malloc");
      return(0);
    }
    for (i = 0; i < image->height; i++)
    {
      bcopy((char *)image->data + (i * image->bytes_per_line),
            (char *) my_data + (i * image->width),
            image->width * sizeof(byte));
    }
    /* write data to SUN-rasterfile */
    WriteSUN(out, my_data, image->width, image->height,
             my_r, my_g, my_b, ncolors, FULL_COLOR);
  }

  /*
   * free the color buffer.
   */

#ifdef DEBUG
  fprintf(stderr, "WindowDump: Freeing colors.\n");
#endif DEBUG
  if(ncolors > 0) free(colors);

  /*
   * Free window name string.
   */
#ifdef DEBUG
  fprintf(stderr, "WindowDump: Freeing window name string.\n");
#endif DEBUG
  if (got_win_name) XFree(win_name);

  /*
   * Free image
   */
  XDestroyImage(image);

  return(1);
}



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  GrabWindow()                                             */
/*                                                                            */
/*      Version   :  27.02.1992                                               */
/*                                                                            */
/*      Purpose   :  grabs the image of a window to be selected by the user   */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
void GrabWindow(Display *dpy, int screen, Bool NoBord, char *out_file_name)
{
  Window target_win;
  FILE *out_file;

  NoBorders = NoBord;

  /*
   * Let the user select the target window.
   */
  target_win = Select_Window(dpy, screen);
  if (target_win != None)
  {
    Window root;
    int dummyi;
    unsigned int dummy;

    if (XGetGeometry (dpy, target_win, &root, &dummyi, &dummyi,
                      &dummy, &dummy, &dummy, &dummy) &&
        target_win != root)
      target_win = XmuClientWindow (dpy, target_win);
  }

  /*
   * Raise it!
   */
  XRaiseWindow(dpy, target_win);
  XSync(dpy, False);
  XFlush(dpy);

  SetWaitState();

  /*
   * Dump it!
   */
  if ((out_file = fopen(out_file_name, "w")) == NULL)
  {
    sperror ("Grab: cannot open file");
    return;
  }
  if (!Window_Dump(dpy, screen, target_win, out_file))
  {
    sperror("Grab: cannot dump Window");
    unlink(out_file_name);
  }
  else
  {
    fclose(out_file);
  }

  ClearWaitState();
}

