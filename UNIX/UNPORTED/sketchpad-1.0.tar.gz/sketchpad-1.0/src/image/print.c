/* ========================================================================== */
/*                                                                            */
/* Filename:     print.c                          +-----+-----+--+--+--+--+   */
/* Version :     1.2	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/8/92	13:59:29	                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*                                                                            */
/*      Module    :  print.c                                                  */
/*                                                                            */
/*      Functions :  Print() : print selected items to disk in SUN-pixrect    */
/*                             format for later conversion and printing.      */
/*                             conversion and printing.                       */
/*                                                                            */
/* ========================================================================== */



/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <stdio.h>
#include "print.h"
#include "../ui/defs.h"
#include "../misc/ographic.h"
#include "../kernel/user.h"
#include "../ui/layer.h"
#include "../draw/drawstate.h"
#include "../ui/sketchpad.h"
#include "../misc/makepath.h"
#include "../misc/wait.h"
#include "picio.h"

/* ========================================================================== */
/*      DEFINE STATEMENTS                                                     */
/* ========================================================================== */

/* ========================================================================== */
/*      GLOBAL VARIABLES                                                      */
/* ========================================================================== */



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  Print                                                     */
/*                                                                            */
/*      Version   :  24.05.1991                                               */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  Write selected layers to SUN rasterfile                  */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  Main Program of Sketchpad                                */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int Print(char *path)
{
  FILE            *fp;
  void            *obj;
  struct_storage  ss;
  layer           lay;
  int layer_id, sketch_id;

  int           x, y;
  unsigned int  borderwidth;
  unsigned int sketch_width;
  unsigned int sketch_height;
  unsigned int depth;
  Window        root;
  
  GC     my_gc;
  Pixmap my_pixmap;
  XImage *my_image;
  byte   *my_data;
  byte   my_r[256], my_g[256], my_b[256];
  int    my_numcols;
  XColor my_colors[256];
  XColor my_color;

  XRectangle rect;

  Arg AL[1];
 
  int    printall = False;
  int    printallvis = False;
  int    something_printed = False;

  int    i;

  char   *tempp1;
  char   pathname[256];

  Drawable old_draw_window;

  fp = fopen(path, "w");
  if (!fp)
  {
    /* try to create directory */
    tempp1 = strrchr(path, '/');
    strncpy(pathname, path, tempp1 - path);
    pathname[tempp1 - path] = '\0';
    if (MakePath(pathname) == 0)
    {
      if (!(fp = fopen(path, "w")))
      {
        sperror("Print: Cannot open Printfile.");
        return(0);
      }
    }
    else
    {
      return(0);
    }
  }

  SetWaitState();

  /* look what is to be printed */
  XtSetArg (AL[0], XmNset, &printall);
  XtGetValues(widget_array[v_print_box_all_button], AL, 1);
  if (printall)
  {
    /* fprintf(stderr,"Print all.\n"); */
  }
  else
  {
    XtSetArg (AL[0], XmNset, &printallvis);
    XtGetValues(widget_array[v_print_box_all_visible_button], AL, 1);
    if (printallvis)
    {
      /* fprintf(stderr,"Print all visible.\n"); */
    }
  }

  /* get size of drawing area widget */
  XGetGeometry(theDisplay, XtWindow(widget_array[v_drawing_area]), &root,
               &x, &y, &sketch_width, &sketch_height,
               &borderwidth, &depth);

  trace("height:  %d, width:  %d;\n", sketch_width, sketch_height, 0, 0);
  trace("depth:   %d\n", depth, 0, 0, 0);

  /* create pixmap of appropriate size */
  my_pixmap = XCreatePixmap(XtDisplay(widget_array[v_drawing_area]),
                            XtWindow(widget_array[v_drawing_area]),
                            sketch_width, sketch_height,
                            depth);
  if (!my_pixmap)
  {
    sperror("Print: cannot create temporary pixmap, sorry!");
    ClearWaitState();
    return(0);
  } 
  /* set pixmap background to defined value (black) */

  XFillRectangle(theDisplay, my_pixmap, theGC, 0, 0, 
                 sketch_width, sketch_height);

  /* draw visible layers into pixmap */
  rect.x = (short) 0;
  rect.y = (short) 0;
  rect.width = (unsigned short) sketch_width;
  rect.height = (unsigned short) sketch_height;

  lay = GetFirstLayer ();
  while (lay != NULL)
  {
    if (printall || (printallvis && (GetLayerState(lay) & LS_VISIBLE)) ||
        ((!printall) && (!printallvis) && (GetLayerState(lay) & LS_PRINT)))
    {
      something_printed = True;
      GetLayerId (lay, &layer_id, &sketch_id);
      if ((layer_id == 1) && (sketch_id == 0))
      {
        if (thePixmap)
        {
          XCopyArea(theDisplay, thePixmap, my_pixmap, theGC, 
                    0, 0, sketch_width, sketch_height, 0, 0);
        }
      }
      else
      {
        /* set appropriate destination for drawing */
        old_draw_window = DrawWindow;
        DrawWindow = my_pixmap;
        
        /* draw layer into pixmap */
        DrawLayer (lay, rect); 

        /* reset old destination for drawing */
        DrawWindow = old_draw_window;
      }
    }
    lay = GetNextLayer ();
  }
 
  if (something_printed)
  {
    /* copy current colormap (print file is for temporal use only, so
       why select used colors ? */
    XSync(theDisplay, False);
    my_numcols = DisplayCells(theDisplay, theScreen);
    my_numcols = (my_numcols < 256) ? my_numcols : 256;
    trace("numcols: %d\n", my_numcols, 0, 0, 0);

    /* read entire colormap (or first 256 entries) into 'my_colors' */
    for (i = 0; i < my_numcols; i++) my_colors[i].pixel = (unsigned long) i;
    XQueryColors(theDisplay, theCmap, my_colors, my_numcols);
    for (i = 0; i < my_numcols; i++)
    {
      my_r[i] = (byte) (my_colors[i].red >> 8); 
      my_g[i] = (byte) (my_colors[i].green >> 8);
      my_b[i] = (byte) (my_colors[i].blue >> 8);
    } 
    
    /* extract pixel data from pixmap */
    my_image = XGetImage(theDisplay, my_pixmap, 0, 0, sketch_width, 
                         sketch_height, AllPlanes, ZPixmap);
    if (!my_image)
    {
      sperror("Print: cannot create temporary image, sorry!");
      ClearWaitState();
      return(0);
    }
    XFreePixmap(theDisplay, my_pixmap);
    my_data = (byte *) my_image->data;

    /* write data to SUN-rasterfile */
    WriteSUN(fp, my_data, sketch_width, sketch_height, 
             my_r, my_g, my_b, 
             my_numcols, FULL_COLOR);

    XDestroyImage(my_image);
    fclose(fp);
  }
  else
  {
    sperror("Print: nothing to print!");  
    unlink(path);
  }
  ClearWaitState();
  return(1);
} /* Print */

