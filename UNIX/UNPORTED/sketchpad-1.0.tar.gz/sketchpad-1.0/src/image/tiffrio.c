/* ========================================================================== */
/*                                                                            */
/* Filename:     tiffrio.c                        +-----+-----+--+--+--+--+   */
/* Version :     1.2	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/8/92	13:59:37	                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*                                                                            */
/*      Module    : tiffrio.c                                                 */
/*                                                                            */
/*      Functions : static int TIFFError();                                   */
/*                  static int tiff_read_header();                            */
/*                  static int tiff_get_IFD();                                */
/*                  (uchar_t *) tiff_get_values();                            */
/*                  (byte *) tiff_make_raster();                              */
/*                  (byte *) tiff_make_raster_correct();                      */
/*                                                                            */
/*                  int LoadTIFF(fname,nc); (export)                          */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <stdio.h>
#include <math.h>

#include "picio.h"
#include "tiff.h"


/* ========================================================================== */
/*      FORWARD DECLARATIONS                                                  */
/* ========================================================================== */

static int TIFFError(char *);
static int tiff_read_header(FILE *);
static int tiff_get_IFD(tifImage_t *, tifCmap_t *, tifAddInfo_t *);
uchar_t * tiff_get_values(ulong_t, tifDataTypes_t, ulong_t);
byte * tiff_make_raster (uchar_t *, tifDataTypes_t, uchar_t *,
                         tifDataTypes_t, ulong_t, ulong_t, tifCompression_t, 
                         ulong_t, ulong_t, ulong_t *);
byte * tiff_make_raster_correct(uchar_t *, tifDataTypes_t, uchar_t *,
                         tifDataTypes_t, ulong_t, ulong_t, tifCompression_t,
                         ulong_t, ulong_t, ulong_t *);


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : LoadTIFF()                                                */
/*                                                                            */
/*      Version   : 01.05.1991                                                */
/*                                                                            */
/*                                                                            */
/*      Purpose   : Load TIFF Picture File into Sketchpad                     */
/*                                                                            */
/*      Accesses  : pic, r, g, b, pHIGH, pWIDE                                */
/*                                                                            */
/*      Called by : LoadRasterImage()                                         */
/*                                                                            */
/*      Calls     : tiff_read_header(), tiff_get_IFD()                        */
/*                                                                            */
/* ========================================================================== */

int LoadTIFF(char *fname, int nc)
{
  tifImage_t image;
  tifCmap_t cmap;
  tifAddInfo_t info;
  int i;

#ifdef	TIF_TRACE_ON
#ifdef	TIF_TRACE_TO_FILE
	tif_trace = fopen ("tifLoadTrace.lst", "w");
#endif	TIF_TRACE_TO_FILE
#endif	TIF_TRACE_ON

  /*
   * open picture file
   */
  tf = fopen (fname, "r");
  trace("LoadTIFF: opening file \"%s\"\n", fname, 0, 0, 0);
  if (tf == NULL)
  {
    TIFFError("LoadTIFF: error open file!");
    return(1);
  }

  /*
   * read file header
   */
  if (!tiff_read_header (tf))
  {
    TIFFError("LoadTIFF: bad header in picture file.");
    return(1);
  }

  /*
   * read IFD's        
   */
  if (!tiff_get_IFD (&image, &cmap, &info))
  {
    TIFFError("LoadTIFF: cannot read IFD's.");
    return(1);
  }
  pWIDE = (int) image.width;
  TifTrace ("\tpWIDE: %d\n",pWIDE);
  pHIGH = (int) image.height;
  TifTrace ("\tpHIGH: %d\n",pHIGH);
  pic = image.data;
  
  for (i = 0; i < cmap.size; i++)
  {
    r[i] = (byte) cmap.color[i].red;
    g[i] = (byte) cmap.color[i].green;
    b[i] = (byte) cmap.color[i].blue;
  }

#ifdef	TIF_TRACE_ON
#ifdef	TIF_TRACE_TO_FILE
	(void)fclose (tif_trace);
#endif	TIF_TRACE_TO_FILE
#endif	TIF_TRACE_ON

  return(0);
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  TIFFError()                                              */
/*                                                                            */
/*      Version   :  01.05.1991                                               */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static int TIFFError(char *st)
{
  sperror(st);
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  tiff_read_header                                         */
/*                                                                            */
/*      Version   :  01.05.1991                                               */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  read the header of a tiff picture file                   */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  LoadTIFF                                                 */
/*                                                                            */
/*      Calls     :  (int_t)   lhToI () (modul tiffmisc.c)                    */
/*                   (long_t)) chToL () (modul tiffmisc.c)                    */
/*                                                                            */
/* ========================================================================== */
static int tiff_read_header (FILE *file)
{
  uchar_t	tif_header[8];
  uchar_t	offset[4];
  int_t 	v;

  (void)fread(tif_header, 1, 8, file);
  TifTrace("\tByte Order :%c%c\n",tif_header[0],tif_header[1]);
  II = (tif_header[0] == 'I' && tif_header[1] == 'I');
  MM = (tif_header[0] == 'M' && tif_header[1] == 'M');
  v  = lhToI (&tif_header[2]);
  TifTrace("\tVersion    :%d\n",v);
  if (!(II || MM) || (v != (int_t)VERSION))
  /* Error wrong header */
  {
    TIFFError("*** ERROR : wrong header, file can not be converted ! ***");
    return (0);
  }
  (void)fread(offset, 1, 4, file);           /* holt OFFSET of NEXT IFD */
  actual_IFD = chToL(&tif_header[4]);
  if (actual_IFD == 0)
  {
    TIFFError("*** ERROR : no images in TIFF file ! ***");
    return (0);
  }
  return (1);
}



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  tiff_get_IFD()                                           */
/*                                                                            */
/*      Version   :  29.04.1991                                               */
/*                                                                            */
/*      Purpose   :  Read All ImageFileDirectories From TIFF File             */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  LoadTIFF()                                               */
/*                                                                            */
/*      Calls     :  (byte *) tiff_make_raster ()                             */
/*                   (byte *) tiff_make_raster_correct()                      */
/*                   (int_t)     lhToI ()  (modul tiffmisc.c)                 */
/*                   (double_t)  chToD ()  (modul tiffmisc.c)                 */
/*                   (long_t)    chToL ()  (modul tiffmisc.c)                 */
/*                   (double_t)  anyToD () (modul tiffmisc.c)                 */
/*                                                                            */
/* ========================================================================== */
static int tiff_get_IFD (tifImage_t *image, tifCmap_t *cmap, tifAddInfo_t *info)
{
  rctif_t		ret;
  uchar_t		entry[12],        /* enthaelt komplettes Directory */
			nr_of_entries[2],
			new_IFD[4],       /* Pointer auf  IFD */
			*tiff_lut,
			*lut,
			*strip_offsets,
			*strip_byte_counts,
			*c;
  byte			*raster_data;
  ulong_t		length,
			value_offset,
			nr_of_strips,
			rows_per_strip,
			x_size,
			y_size,
			lut_len,
			max_lut,
                        real_raster_size,
			*bits_per_sample;
  ulong_t		entry_count;
  int_t			i, j, k,
			val,
			diff_samples,
			last_tag,
			tag,
			nr_of_ch,
       			depth;
  boolean_t             correct_raster,
                        gray_rev;
  tifDataTypes_t	type_of_actual_value,
			type_of_strip_byte_count,
			type_of_strip_offset;
  double_t              nr_of_strips_buffer;

  tifCompression_t	compression;
  tifImageType_t	tiff_type;
  tifPeriod_t		periodicity;


  tag = 0;
  if (actual_IFD >=8)
  {
    /* setzt auf entry count in nth IFD */
    (void)fseek (tf, actual_IFD, SEEK_SET);
    (void)fread (nr_of_entries, 1, 2, tf);    /* holt entry count     */
    entry_count = lhToI (nr_of_entries);      /* und berechnet Inhalt */
    TifTrace("\tentry count = %d\n",entry_count);
    k        = 0;
    last_tag = 0;
    /**** Defaults setzen ***/
    compression 	= NO_COMPRESSION;
    periodicity 	= PixelPeriodicity;
    tiff_type   	= TIFF_R;
    x_size		= 0;
    y_size		= 0;
    depth               = 8;
    diff_samples	= 1;
    nr_of_strips	= 0;
    real_raster_size    = 0;
    rows_per_strip	= (1<<31) - 1;
    strip_offsets     	= No_uchar;
    strip_byte_counts 	= No_uchar;
    lut		  	= No_uchar;
    tiff_lut	  	= No_uchar;
    raster_data	  	= No_uchar;
    correct_raster      = TRUE;
    bits_per_sample     = (ulong_t *) malloc (sizeof(ulong_t));
    bits_per_sample[0]  = 1;



    while  ( k < entry_count)              /* DIR ENTRIES */
    {
      (void)fread (entry, 1, 12, tf);/* holt next DIR ENTRY */
      last_tag = tag;
      tag      = lhToI(&entry[0]);   /* berechnet TAG */
      if ((tag<MinTagNumber)||(tag>MaxTagNumber))
      {
        TifTrace("*** WARNING : illegal tag number (%d) ***\n",tag);
        k++;
        continue;
      }
      if (tag<last_tag)
      {
        char text[50];
        sprintf(text,"*** Error : illegal tag order (%d) ***", tag); 
        TIFFError(text);
      }
      /* berechnet TYPE */
      type_of_actual_value =(tifDataTypes_t) lhToI(&entry[2]);
      if (!ValidDataType (type_of_actual_value))
        return (0);
      length = chToL(&entry[4]);       /* berechnet LENGTH */
      value_offset = chToL(&entry[8]);
      c = tiff_get_values(value_offset, type_of_actual_value, length);
      switch (tag)
      {
        case  NewSubfileType:
          TifTrace ("\t\t..NewSubfileType (254) ignored\n");
          (void)free (c);
          break;		
                         		
        case SubfileType:
          TifTrace ("\t\t..SubfileType (255) ignored\n");
          (void)free (c);
          break;
                          				
        case ImageWidth:
          x_size = (ulong_t) anyToD (c, type_of_actual_value);
          TifTrace ("\t\tImageWidth: %lu\n",x_size);
          (void)free (c);
          break;
                          				
        case ImageLength:	
          y_size = (ulong_t) anyToD (c, type_of_actual_value);
          TifTrace ("\t\tImageLength: %lu\n",y_size);
          (void)free (c);
          break;
                          				
        case BitsPerSample:	
          val = lhToI(c);
          bits_per_sample = (ulong_t *) malloc (length * sizeof(ulong_t));
          for (i=0; i<length; i++)
          bits_per_sample[i] = 1;
          for (i=0; i<length; i++)
          {
            if (bits_per_sample[i] != bits_per_sample[i+1] && (i<length-1))
            {
              TifTrace ("\t\t..Different BitsPerSample (102) not yet "
               "implemented : (%d, %d, %d)\n",val, lhToI(&c[2]), lhToI(&c[4]));
              (void)free (c);
              free (bits_per_sample);
              return (0);
            }
            bits_per_sample[i] = lhToI(&c[i*2]);
          }
          diff_samples = length;
          depth        = val;
          if (length > 1)
            TifTrace ("\t\tBitsPerSample: ARRAY - all = %d\n",val);
          else
            TifTrace ("\t\tBitsPerSample: %d\n",val);
          (void)free (c);
          break;
	
        case Compression:
          compression = (tifCompression_t) lhToI(c);
          (void)free (c);
           switch (compression){
             case NO_COMPRESSION:
               TifTrace ("\t\tCompression: NO COMPRESSION\n",compression);
               break;
             case LZW:
               TifTrace ("\t\tCompression: LZW-COMPRESSION\n",compression);
               break;
             default:
               TifTrace ("\t\tCompression (%d) not yet implemented! \n",
                         compression);
               return (0);
             }
             break;

        case PhotometricInterpretation:
          val = lhToI(c);
          switch ((tifPhotoInterpret_t)val)
          {
            case (RGB):
              nr_of_ch    = 3;
              tiff_type   = TIFF_R;
              TifTrace ("\t\tPhotometricInterpretation: RGB\n");
              break;

            case (PaletteColor):
              nr_of_ch    = 1;
              tiff_type   = TIFF_P;
              TifTrace ("\t\tPhotometricInterpretation: PALETTE_COLOR\n");
              break;

            case (GrayReverse):
            case (GrayNormal):
              nr_of_ch    = 1;
              gray_rev    = ((tifPhotoInterpret_t)val == GrayReverse);
              if (bits_per_sample[0] == 1)
              {
                tiff_type = TIFF_B;
                TifTrace ("\t\tPhotometricInterpretation: BILEVEL (%d)\n",val);
              }
              else 
              {
                tiff_type   = TIFF_G;
                TifTrace ("\t\tPhotometricInterpretation: GRAY (%d)\n",val);
              }
              break;

            case (TranspMask):
              TifTrace ("\t\t.Photometric interpretation TRANSP_MASK (%d) " 
                        "not yet implemented! \n",val);
              (void)free (c);
              return (0);

            default:
              TIFFError("*** ERROR: Illegal Photometric interpretation! ***");
              (void)free (c);
              return (0);
          }
          (void)free (c);
          break;		
                                  		
        case Threshholding:
          TifTrace ("\t\t..Threshholding (263) ignored\n");
          (void)free (c);
          break;
                          				
        case CellWidth:
          TifTrace ("\t\t..CellWidth (264) ignored\n");
          (void)free (c);
          break;
                          				
        case CellLength:	
          TifTrace ("\t\t..CellLength (265) ignored\n");
          (void)free (c);
          break;				

        case FillOrder:
          TifTrace ("\t\t..FillOrder (266) ignored\n");
          (void)free (c);
          break;				
          
        case DocumentName:	
          TifTrace ("\t\tDocumentName: %s\n",c);
          (void)free (c);
          break;				

        case ImageDescription:
          TifTrace ("\t\tImageDescription: %s\n",c);
          (void)free (c);
          break;				

        case Make:		
          TifTrace ("\t\tMake: %s\n",c);
          /* Da der IMAPRO-Scanner fehlerhafte Werte liefert: */
          if (!strncmp (c,"IMAPRO",6))
            correct_raster = FALSE;
          (void)free (c);
          break;				

        case Model:		
          TifTrace ("\t\tModel: %s\n",c);
          (void)free (c);
          break;				

        case StripOffsets:
          TifTrace ("\t\tStripOffsets: ARRAY");
          nr_of_strips = length;
          strip_offsets = c;
          type_of_strip_offset = type_of_actual_value;
          TifTrace ("\t(%d Strip(s))\n", nr_of_strips);
          if (rows_per_strip == (1<<31) - 1) /* not yet set */
          {
            type_of_strip_byte_count = Long;
          }
          break;				

        case Orientation:
          TifTrace ("\t\t..Orientation (274) ignored\n");
          (void)free (c);
          break;				

        case SamplesPerPixel:
          nr_of_ch = val = lhToI (c);
          TifTrace ("\t\tSamplesPerPixel: %d\n",val);
          (void)free (c);
          if (val != diff_samples)
          {
            TIFFError("*** ERROR: SamplesPerPixel contradicts Length of "
                      "BitsPerSamples ! ***");
            return (0);
          }
          break;				

        case RowsPerStrip:
          rows_per_strip = (ulong_t) anyToD (c, type_of_actual_value);
          TifTrace ("\t\tRowsPerStrip: ");
          if (rows_per_strip >= (1<<31)-1)
            TifTrace ("INDEFINIT\n");
          else
            TifTrace ("%lu\n",rows_per_strip);
          (void)free (c);
          break;				

        case StripByteCounts:
          TifTrace ("\t\tStripByteCounts: ARRAY\n");
          strip_byte_counts = c;
          type_of_strip_byte_count = type_of_actual_value;
          break;				

        case MinSampleValue:
          TifTrace ("\t\t..MinSampleValue (280) ignored\n");
          (void)free (c);
          break;				

        case MaxSampleValue:
          TifTrace ("\t\t..MaxSampleValue (281) ignored\n");
          (void)free (c);
          break;				

        case XResolution:
          TifTrace ("\t\t..XResolution (282) ignored\n");
          (void)free (c);
          break;				

          case YResolution:
          TifTrace ("\t\t..YResolution (283) ignored\n");
          (void)free (c);
          break;				

        case PlanarConfiguration:
          val = lhToI(c);
          if (ValidPeriodicity (val))
          {
            periodicity = (tifPeriod_t)val;
            TifTrace ("\t\tPlanarConfiguration: ");
            if (periodicity == PixelPeriodicity)
              TifTrace ("PIXEL");
            else
              TifTrace ("SAMPLE");
            TifTrace ("_INTERLEAVING (%d)\n",val);
            (void)free (c);
          }
          else
          {
            TIFFError("*** ERROR: Invalid PlanarConfiguration! ***");
            (void)free (c);
            return (0);
          }
          break;				

        case PageName:
          TifTrace ("\t\t..PageName (285) ignored\n");
          (void)free (c);
          break;				
          
        case XPosition:	
          TifTrace ("\t\tXPosition: %f\n",chToD(c));
          TifTrace ("\t\t..XPosition (286) ignored\n");
          (void)free (c);
          break;

        case YPosition:
          TifTrace ("\t\tYPosition: %f\n",chToD(c));
          TifTrace ("\t\t..YPosition (287) ignored\n");
          (void)free (c);
          break;				

        case FreeOffsets:	
          TifTrace ("\t\t..FreeOffsets (288) ignored\n");
          (void)free (c);
          break;				

        case FreeByteCounts:	
          TifTrace ("\t\t..FreeByteCounts (289) ignored\n");
          (void)free (c);
          break;				

        case GrayResponseUnit:
          TifTrace ("\t\t..GrayResponseUnit (290) ignored\n");
          (void)free (c);
          break;				

        case GrayResponseCurve:
          TifTrace ("\t\t..GrayResponseCurve (291) ignored\n");
          (void)free (c);
          break;				

        case Group3Options:
          TifTrace ("\t\t..Group3Options (292) ignored\n");
          (void)free (c);
          break;				

        case Group4Options:
          TifTrace ("\t\t..Group4Options (293) ignored\n");
          (void)free (c);
          break;				
          
        case ResolutionUnit:	
          TifTrace ("\t\t..ResolutionUnit (296) ignored\n");
          (void)free (c);
          break;				

        case PageNumber:
          TifTrace ("\t\t..PageNumber (297) ignored\n");
          (void)free (c);
          break;				

        case ColorResponseCurves:
          TifTrace ("\t\t..ColorResponseCurves (301) ignored\n");
          (void)free (c);
          break;				

        case Software:
          TifTrace ("\t\tSoftware: %s\n",c);
          break;				

        case DateTime:
          TifTrace ("\t\tDateTime: %s\n",c);
          break;				

        case Artist:
          TifTrace ("\t\tArtist: %s\n",c);
          break;				

        case HostComputer:	
          TifTrace ("\t\tHostComputer: %s\n",c);
          break;				

        case Predictor:	
         val = lhToI(c);
         if (val != 1)
         {
            TIFFError("*** ERROR: Predictor for LZW- Compression:"
                      " not recognized - giving up");
            (void)free (c);
          }
          else
            TifTrace ("\t\tPredictor for LZW-Compression: %d\n", val);
          break;

        case WhitePoint:	
          TifTrace ("\t\t.WhitePoint (318) ignored\n");
          (void)free (c);
          break;				

        case PrimaryChromaticities:
          TifTrace ("\t\t..PrimaryChromaticities (319) ignored\n");
          (void)free (c);
          break;				

        case ColorMap:
          TifTrace ("\t\tColorMap: ARRAY\n");
          lut = c;
          lut_len = length;
          break;				

        default:
          break;
      }  /* switch */
      k++;
    } /* while */

    (void)fread (new_IFD, 1, 4, tf);  /* holt next IFD offset */

    if (nr_of_strips == 0)
    {
      nr_of_strips_buffer = (((double_t)y_size+rows_per_strip-1)
                              / rows_per_strip);
      if ( rows_per_strip>=((1<<31)-1) )
        nr_of_strips = (ulong_t) 1;
      else
        nr_of_strips = (ulong_t)(nr_of_strips_buffer);
    }

    nr_of_strips = (periodicity == PixelPeriodicity) ? 
                    nr_of_strips                     :
                    nr_of_strips * nr_of_ch;

    if (strip_byte_counts == No_uchar)
    {
      ulong_t sbc;
      int_t   depth;

      for (i=0, depth=0; i<nr_of_ch; i++)
        depth += bits_per_sample[i];
      sbc = (ulong_t) (((int_t) x_size * (int_t) y_size * depth)/8); 

      strip_byte_counts = (uchar_t *) lToCh(sbc);
    }

    if (correct_raster)
      raster_data = tiff_make_raster_correct (strip_offsets,
                                   type_of_strip_offset,
                                   strip_byte_counts, type_of_strip_byte_count,
                                   nr_of_strips, bits_per_sample[0],
                                   compression, x_size, y_size,
                                   &real_raster_size);
    else    /* IMAPRO-Scanner */
      raster_data = tiff_make_raster (strip_offsets, type_of_strip_offset,
                                   strip_byte_counts, type_of_strip_byte_count,
                                   nr_of_strips, bits_per_sample[0],
                                   compression, x_size, y_size,
                                   &real_raster_size);

    if (raster_data == No_uchar)
    {
      TIFFError("*** ERROR : cannot make raster ! ***");
      return (0);
    }

    if (tiff_type == TIFF_P)	/* LUT laden */
    {
      if (lut == (No_uchar))
      {
        TIFFError("*** ERROR : no lut loaded ! ***");
        return (0);
      }
      else
      {
        tiff_lut = lut;
        max_lut     =  (1<<(ulong_t)bits_per_sample[0]);
        cmap->color = (tifColor_t *)malloc (max_lut * sizeof(tifColor_t));
        if (cmap->color == (tifColor_t *)NULL)
        {
          TIFFError("*** ERROR : unable to malloc color array ! ***");
          return (0);
        }
        cmap->used = (boolean_t *)malloc (max_lut * sizeof(boolean_t));
        if (cmap->used == (boolean_t *)NULL)
        {
          TIFFError("*** ERROR : unable to malloc used array ! ***");
          return (0);
        }

        /* X-LUT zuweisen */

        cmap->size = max_lut;
        lut_len /= 3;

        for (i = 0; (i<lut_len && tiff_lut!=(uchar_t *)NULL); i++)
        {
          cmap->color[i].red   = 
                       (byte)lhToI ((uchar_t *)&tiff_lut[2*i]);
        }
        tiff_lut += (2 * lut_len);    

        for (i = 0; (i<lut_len && tiff_lut!=(uchar_t *)NULL); i++)
        {
          cmap->color[i].green = 
                       (byte)lhToI ((uchar_t *)&tiff_lut[2*i]);
        }
        tiff_lut += (2 * lut_len);    

        for (i = 0; (i<lut_len && tiff_lut!=(uchar_t *)NULL); i++)
        {
          cmap->color[i].blue  = 
                       (byte)lhToI ((uchar_t *)&tiff_lut[2*i]);
        } 

        for (k=i; k<max_lut*nr_of_ch; k++)
        {
          cmap->color[k].red   = (ushort_t)0;
          cmap->color[k].green = (ushort_t)0;
          cmap->color[k].blue  = (ushort_t)0;
          cmap->used[k]        = FALSE;
        }
      } /* else */
      (void)free (lut);
    }  /* if TIFF_P */

    if ((tiff_type == TIFF_G) || (tiff_type == TIFF_B))  /* LUT setzen */
    {
      max_lut     =  (1<<(ulong_t)bits_per_sample[0]);
      cmap->color = (tifColor_t *)malloc (max_lut * sizeof(tifColor_t));
      if (cmap->color == (tifColor_t *)NULL)
      {
        TIFFError("*** ERROR : unable to malloc color array ! ***");
        return (0);
      }
      cmap->used = (boolean_t *)malloc (max_lut * sizeof(boolean_t));
      if (cmap->used == (boolean_t *)NULL)
      {
        TIFFError("*** ERROR : unable to malloc used array ! ***");
        return (0);
      }
      cmap->size = max_lut;

      /* X-LUT zuweisen */
      if (gray_rev)
      {
        for (i = 0; i < max_lut; i++)
        {
          cmap->color[i].red   = (ushort_t) (0xFF * i / (max_lut -1));
          cmap->color[i].green = (ushort_t) (0xFF * i / (max_lut -1));
          cmap->color[i].blue  = (ushort_t) (0xFF * i / (max_lut -1));
          cmap->used[i]        = TRUE; 
        }
      }
      else 
      {
        for (i = max_lut - 1; i >= 0; i--)
        {
          cmap->color[i].red   = (ushort_t) (0xFF * i / (max_lut -1));
          cmap->color[i].green = (ushort_t) (0xFF * i / (max_lut -1));
          cmap->color[i].blue  = (ushort_t) (0xFF * i / (max_lut -1));
          cmap->used[i]        = TRUE; 
        }
      }
    }  /* if TIFF_G or TIFF_B */


    image->width   = (int_t) x_size;
    image->height  = (int_t) y_size;

    for (i=0, image->depth=0; i<nr_of_ch; i++)
      image->depth += bits_per_sample[i];

    if (tiff_type != TIFF_B)
    {
      if (real_raster_size != (image->width * image->height * image->depth)/8)  
      {
        TIFFError("*** ERROR : wrong real raster size ! ***");
        return (0);
      }
    }

/*if tag 254 is not set correctly image->depth = 24; */

    image->data    = raster_data;
    info->byteOrder= MM ? MSBFirst : (II ? LSBFirst : -1);
    info->tifType  = tiff_type;
    info->tifCompr = compression;

#ifdef	FIELD2PIXEL_INTERL
    if (tiff_type==TIFF_R && periodicity==FieldPeriodicity)
    {
      if (!tiff_ftop_interl(image, (short_t)nr_of_ch))
      {
        TIFFError("*** ERROR : tiff_ftop_interl failed ! ***");
        return (0);
      }
    }
#endif	FIELD2PIXEL_INTERL


    (void)free (bits_per_sample);

	
    actual_IFD = chToL(&new_IFD[0]);
    if (actual_IFD != 0)
    TifTrace("*** Additional image(s) in TIFF file ! -- Ignored !***\n");
  }   /* if */
  else
  {
    TIFFError("*** ERROR: Invalid IFD-Offset ! ***");
    return (0);
  }
  return (1);
} /* tiff_get_IFD */



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  tiff_get_values()                                        */
/*                                                                            */
/*      Version   :  29.04.1991                                               */
/*                                                                            */
/*      Purpose   :  Get Values From TIFF File                                */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  tiff_get_IFD()                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
uchar_t *tiff_get_values (ulong_t value_offset, tifDataTypes_t tp,
                          ulong_t length)
{
  uchar_t	*value;
  ulong_t	*new_long,
  in_IFD;
  int_t	size;

  if (!ValidDataType (tp))
    return (No_uchar);

  size = SizeOfType (tp);
  if (size * length <= 4)
  {			 /* offset zeigt in Header -> direkter Wert */
    new_long = (ulong_t *)malloc (sizeof(ulong_t));
    if (new_long == No_ulong)
    {
      TIFFError("*** ERROR : malloc failed ! ***");
      return (No_uchar);
    }
    *new_long = (ulong_t)chToL ((uchar_t *)&value_offset);
    value = (uchar_t *)new_long;
  }
  else
  {			/* naechster IFD-Eintrag */
    in_IFD = (ulong_t)ftell (tf);
    (void)fseek (tf, value_offset, SEEK_SET);
    value = (uchar_t *)malloc (size * length);
    if (value == No_uchar)
    {
      TIFFError("*** ERROR : malloc failed ! ***");
      return (No_uchar);
    }
    (void)fread (value, 1, size*length, tf);
    (void)fseek (tf, in_IFD, SEEK_SET);
  }
  return (value);
} /* tiff_get_values */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  tiff_make_raster()                                       */
/*                                                                            */
/*      Version   :  29.04.1991                                               */
/*                                                                            */
/*      Purpose   :  Read Raster Data From TIFF File                          */
/*                   (erroneous data of IMAPRO scanner are corrected)         */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  tiff_get_IFD()                                           */
/*                                                                            */
/*      Calls     :  (double_t) anyToD () (modul tiffmisc.c)                  */
/*                   (rctif_t)tiff_decomp_strip_lzw (m. TIFlzw.c)             */
/*                                                                            */
/* ========================================================================== */
byte *tiff_make_raster (uchar_t *offsets, tifDataTypes_t type_of_offset, 
                        uchar_t *counts, tifDataTypes_t type_of_count,
                        ulong_t nr_of_strips, ulong_t bits_per_sample, 
                        tifCompression_t compression, 
                        ulong_t x_size, ulong_t y_size, ulong_t *out_size)
{
  ulong_t       offset,
                in_IFD,
                data_count=0,	/* Zeiger im neuen Rasterfeld */
                count     =0,	/* Gesamtlaenge(-groesse) des Rasters */
                new_size  =0,
                result_size=0,
                j, k, l,
                rest;

  register int i;

  int_t	    count_step,
            offset_step;
  uchar_t   *data,
            *new_data,
            *buf_data;;

  if ((offsets == No_uchar) || (counts == No_uchar))
  {
    TIFFError("*** ERROR: Strip data missing! ***");
    return (No_uchar);
  }
  if (nr_of_strips < 1)
  {
    TIFFError("*** ERROR: Illegal nr of strips! ***");
    return (No_uchar);
  }
  data = No_uchar;
  buf_data = No_uchar;

  offset_step = (type_of_offset==Short) ? 2 : 4;
  count_step  = (type_of_count ==Short) ? 2 : 4;
  for (i=0; i<nr_of_strips; i++)
/*** Da der TIFF-Treiber des IMAPRO-Scanners fehlerhafte Werte liefert ********\
\*** wird hier der jeweils mittlere Long-Wert genommen : **********************/
  {
    count_step = (nr_of_strips==1) ? 0 : count_step;
    count += (ulong_t)anyToD(&counts[count_step], type_of_count);
  }
/** Richtig waere : ***********************************************************\
  count += (ulong_t)anyToD(&counts[i*count_step], type_of_count);
\******************************************************************************/

  data = (uchar_t *)malloc (count*sizeof(char_t));
  if (data == No_uchar)
  {
    TIFFError("*** ERROR: malloc (on raster data) failed! ***");
    return (No_uchar);
  }
	
  in_IFD = (ulong_t)ftell (tf);
  for (i=0; i<nr_of_strips; i++)
  {
    /* Positionieren in TIFF-File */
    offset = (ulong_t)anyToD (&offsets[i*offset_step], type_of_offset);
    (void)fseek (tf, offset, SEEK_SET);
    /* Lesen aus TIFF-File nach Puffer */
/*** Da der TIFF-Treiber des IMAPRO-Scanners fehlerhafte Werte liefert ********\
\*** wird hier der jeweils mittlere Long-Wert genommen : **********************/
    count_step = (nr_of_strips==1) ? 0 : count_step;
    count = (ulong_t)anyToD(&counts[count_step], type_of_count);
/** Richtig waere : ***********************************************************\
  count = (ulong_t)anyToD(&counts[i*count_step], type_of_count);
\******************************************************************************/

    (void)fread (&data[data_count], 1, count, tf);
    switch (compression){
      case LZW:
          if (tiff_decomp_strip_lzw (&data[data_count], count,
                                      &new_data, &new_size) != 1)
          {
            TIFFError("*** ERROR: LZW-Decompression failed! ***");
            (void)free (data);
            return (No_uchar);
          }
          result_size += new_size;
          if (buf_data != No_uchar)
            buf_data = (uchar_t *)realloc (buf_data, result_size);
          else
            buf_data = (uchar_t *)malloc (result_size);
          if (buf_data == No_uchar)
          {
            TIFFError("*** ERROR: malloc (on raster data) failed! ***");
            (void)free (data);
            return (No_uchar);
          }
          (void)memcpy(&buf_data[result_size-new_size],new_data,new_size);
          (void)free (new_data);
          break;

      case NO_COMPRESSION:
      default: break;
    }

    /* Positionieren in Puffer */
    data_count += count;
  }
  (void)fseek (tf, in_IFD, SEEK_SET);

  if (compression != NO_COMPRESSION)
  {
    (void)free (data);
    data       = buf_data;
    data_count = result_size;
  }

  *out_size = data_count;
  if (bits_per_sample != 8 && bits_per_sample != 1)
  {                               /* Angleichen der Werte auf 8 Bit */
    if (bits_per_sample < 8)
    {
      k = 8-bits_per_sample;
      j = (data_count<<3)/bits_per_sample;
      new_data = (uchar_t *)malloc (j * sizeof(uchar_t));
      rest = 0;
      for (i=0; i<j; i++)
      {
        new_data[i] = (data[i]>>k) | rest;
        rest = data[data_count] << bits_per_sample;
      }
    }
    else
    {
      k = bits_per_sample-8;
      new_data = (uchar_t *)malloc (j=(data_count<<3)/bits_per_sample);
      rest = 0;
      l    = 1;
      for (i=0; i<j; i++)
      {
        new_data[i] = (data[i]<<(k*l))|(data[i+1]>>(k*l));
        l = (l < (8/k)) ? l+1 : 1;
      }
    }
    (void)free (data);
    data = new_data;
    *out_size = j;
  }

  if (bits_per_sample == 1)  /* BILEVEL image */
  {
    uchar_t *obuf_data;
    uchar_t *nbuf_data;
    ulong_t b_count = 0;
    ulong_t x_count = 0;
    ulong_t y_count = 0;

    l = x_size * y_size * sizeof(uchar_t);
    new_data = (uchar_t *) malloc (((x_size * y_size)+8)
                                   * sizeof(uchar_t));
    if (new_data == No_uchar)
    {
      TIFFError("*** ERROR: malloc (on raster data) failed! ***");
      (void)free (data);
      return (No_uchar);
    }

    obuf_data = data;
    nbuf_data = new_data;

    for (i = 0; i< nr_of_strips; i++)
    {
      /* read all strips into new_data */
      for (j=0; j< (ulong_t) anyToD(&counts[i*count_step], type_of_count);j++)
      {
        if (y_count < y_size)
        {
          /* convert every byte of the strip */
          for (k = 0;k < 8;k++)
          {
            if (x_count < x_size)
            {
              /* mask kth Bit */
              nbuf_data[(x_count)] =
                            (obuf_data[b_count]>>(7-k)) & 1 ? 1 : 0;
              x_count += 1;
            }
          }
          b_count += 1;
          if (x_count == x_size)
          {
            b_count = 0;
            x_count = 0;
            y_count += 1;
            /* increment obuf_data and nbuf_data */
            obuf_data += ((x_size + 7) / 8);
            nbuf_data += x_size;
          }
        }
      }
    }

    (void)free (data);
    data      = new_data;
    *out_size = l;
  }

  return ((byte *) data);
} /* tiff_make_raster */



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  tiff_make_raster_correct()                               */
/*                                                                            */
/*      Version   :  01.06.1991                                               */
/*                                                                            */
/*      Purpose   :  Read Raster Data From TIFF File                          */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  tiff_get_IFD()                                           */
/*                                                                            */
/*      Calls     :  (double_t) anyToD () (modul tiffmisc.c)                  */
/*                   (rctif_t)tiff_decomp_strip_lzw (m. TIFlzw.c)             */
/*                                                                            */
/* ========================================================================== */
byte *tiff_make_raster_correct(uchar_t *offsets, tifDataTypes_t type_of_offset, 
                        uchar_t *counts, tifDataTypes_t type_of_count,
                        ulong_t nr_of_strips, ulong_t bits_per_sample, 
                        tifCompression_t compression, 
                        ulong_t x_size, ulong_t y_size, ulong_t *out_size)
{
  ulong_t offset,
          in_IFD,
          data_count=0,   /* Zeiger im neuen Rasterfeld */
          count     =0,   /* Gesamtlaenge(-groesse) des Rasters */
          new_size  =0,
          result_size=0,
          j, k, l,
          rest;

  register int i;

  int_t   count_step,
          offset_step;
  uchar_t *data,
          *new_data,
          *buf_data;

  if ((offsets == No_uchar) || (counts == No_uchar))
  {
    TIFFError("*** ERROR: Strip data missing! ***");
    return (No_uchar);
  }
  if (nr_of_strips < 1)
  {
    TIFFError("*** ERROR: Illegal nr of strips! ***");
    return (No_uchar);
  }
  data     = No_uchar;
  buf_data = No_uchar;

  offset_step = (type_of_offset==Short) ? 2 : 4;
  count_step  = (type_of_count ==Short) ? 2 : 4;
  for (i=0; i<nr_of_strips; i++)
    count += (ulong_t)anyToD(&counts[i*count_step], type_of_count);

  data = (uchar_t *)malloc (count*sizeof(char_t));
  if (data == No_uchar)
  {
    TIFFError("*** ERROR: malloc (on raster data) failed! ***");
    return (No_uchar);
  }

  in_IFD = (ulong_t)ftell (tf);
  for (i=0; i<nr_of_strips; i++)
  {
                                  /* Positionieren in TIFF-File */
    offset = (ulong_t)anyToD (&offsets[i*offset_step], type_of_offset);
    (void)fseek (tf, offset, SEEK_SET);
                                  /* Lesen aus TIFF-File nach Puffer */
    count = (ulong_t)anyToD(&counts[i*count_step], type_of_count);

    (void)fread (&data[data_count], 1, count, tf);

    switch (compression){
      case LZW:
          if (tiff_decomp_strip_lzw (&data[data_count], count,
                                     &new_data, &new_size) != 1)
          {
            TIFFError("*** ERROR: LZW-Decompression failed! ***");
            (void)free (data);
            return (No_uchar);
          }
          result_size += new_size;
          if (buf_data != No_uchar)
            buf_data = (uchar_t *)realloc (buf_data, result_size);
          else
            buf_data = (uchar_t *)malloc (result_size);
          if (buf_data == No_uchar)
          {
            TIFFError("*** ERROR: malloc (on raster data) failed! ***");
            (void)free (data);
            return (No_uchar);
          }
          (void)memcpy(&buf_data[result_size-new_size],new_data,new_size);
          (void)free (new_data);
          break;

      case NO_COMPRESSION:
      default: break;
    }
                                  /* Positionieren in Puffer */
    data_count += count;
  }  
  (void)fseek (tf, in_IFD, SEEK_SET);


  if (compression != NO_COMPRESSION)
  {
    (void)free (data);
    data       = buf_data;
    data_count = result_size;
  }

  *out_size = data_count;

  if (bits_per_sample != 8 && bits_per_sample != 1)
  {                               /* Angleichen der Werte auf 8 Bit */
    if (bits_per_sample < 8)
    {
      k = 8-bits_per_sample;
      j = (data_count<<3)/bits_per_sample;
      new_data = (uchar_t *)malloc (j * sizeof(uchar_t));
      if (new_data == No_uchar)
      {
        TIFFError("*** ERROR: malloc (on raster data) failed! ***");
        (void)free (data);
        return (No_uchar);
      }
      rest = 0;
      for (i=0; i<j; i++)
      {
        new_data[i] = (data[i]>>k) | rest;
        rest = data[data_count] << bits_per_sample;
      }
    }
    else
    {
      k = bits_per_sample-8;
      new_data = (uchar_t *)malloc (j=(data_count<<3)/bits_per_sample);
      if (new_data == No_uchar)
      {
        TIFFError("*** ERROR: malloc (on raster data) failed! ***");
        (void)free (data);
        return (No_uchar);
      }
      rest = 0;
      l    = 1;
      for (i=0; i<j; i++)
      {
        new_data[i] = (data[i]<<(k*l))|(data[i+1]>>(k*l));
        l = (l < (8/k)) ? l+1 : 1;
      }
    }
    (void)free (data);
    data      = new_data;
    *out_size = j;
  }
  
  if (bits_per_sample == 1)  /* BILEVEL image */
  {
    uchar_t *obuf_data;
    uchar_t *nbuf_data;
    ulong_t b_count = 0;
    ulong_t x_count = 0;
    ulong_t y_count = 0;

    l = x_size * y_size * sizeof(uchar_t); 

    new_data = (uchar_t *) malloc (((x_size * y_size)+8)
                                   * sizeof(uchar_t));
    if (new_data == No_uchar)
    {
      TIFFError("*** ERROR: malloc (on raster data) failed! ***");
      (void)free (data);
      return (No_uchar);
    }

    obuf_data = data;
    nbuf_data = new_data;

    for (i = 0; i< nr_of_strips; i++)
    {
      /* read all strips into new_data */
      for (j=0; j< (ulong_t) anyToD(&counts[i*count_step], type_of_count);j++)
      {
        if (y_count < y_size)
        {
          /* convert every byte of the strip */
          for (k = 0;k < 8;k++)
          {
            if (x_count < x_size)
            {
              /* mask kth Bit */
              nbuf_data[(x_count)] =
                            (obuf_data[b_count]>>(7-k)) & 1 ? 1 : 0;
              x_count += 1;
            }
          }
          b_count += 1;
          if (x_count == x_size)
          {
            b_count = 0;
            x_count = 0;
            y_count += 1;
            /* increment obuf_data and nbuf_data */
            obuf_data += ((x_size + 7) / 8);
            nbuf_data += x_size;
          }
        }
      }
    }

    (void)free (data);
    data      = new_data;
    *out_size = l;
  }

  return ((byte *) data);
} /* tiff_make_raster_correct */

