/* ========================================================================== */
/*                                                                            */
/* Filename:     picio.c                          +-----+-----+--+--+--+--+   */
/* Version :     1.4	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/15/92	10:43:38	                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*                                                                            */
/*      Module    :  picio.c                                                  */
/*                                                                            */
/*      Functions :  InitPicio()                                              */
/*                   LoadRasterImage()                                        */
/*                   ClearRasterImage()                                       */
/*                   RedrawRasterImage()                                      */
/*                                                                            */
/* ========================================================================== */


/* ========================================================================== */
/*      DEFINE & INCLUDE STATEMENTS                                           */
/* ========================================================================== */
#define MAIN

#include "picio.h"
#include <sys/param.h>
#include <Mrm/MrmAppl.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "../draw/dzoom.h"
#include "../misc/makepath.h"
#include "../misc/wait.h"
#include "../ui/defs.h"
#include "../ui/sketchpad.h"
/* #include <stdlib.h> */

#undef MAIN

#define  max(a, b) (a > b ? a : b)

#define MAXCOLORS     256

extern char* NPath(char*);
extern char SaveLayerColors(void);
extern char RestoreLayerColors(void);
extern void* GetCurrentLayer(void);
extern void SetCurrentLayer(void*);


/* ========================================================================== */
/*      GLOBAL VARIABLES                                                      */
/* ========================================================================== */

extern char picFilename[256];
static int jpeg_quality;

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :     InitPicio                                             */
/*                                                                            */
/*      Version   :     19.03.1991                                            */
/*                                                                            */
/*      Purpose   :     initialize all data structures needed for PicIO       */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :     Main program of Sketchpad                             */
/*                                                                            */
/*      Calls     :     InitFSDTables()                                       */
/*                                                                            */
/* ========================================================================== */
int InitPicio(Display *display, Window window)
{ 
  int        i;
  char       *whitestr, 
             *blackstr,
             *tempp;
  char       tempp4[MAXPATHLEN];

  XColor     ecdef;

  XGCValues  gc_values;

  /* init internal variables */

  whitestr = blackstr = NULL;
  pic = epic = cpic = NULL;
  perfect =  0;
  ncols   = -1;
  nfcols  =  0;
  noglob  =  1; 
  revvideo = 0;
  mono = 0;
  ninstall = 0;

  /* init X Variables */
  
  theDisplay = display;
  theWindow  = window;
  theScreen  = DefaultScreen(display);
  theCmap    = DefaultColormap(display, theScreen);
  rootW      = RootWindow(display,theScreen);
  theVisual  = DefaultVisual(display,theScreen);
  ncells     = DisplayCells(display, theScreen);
  thePixmap  = 0;
  theImage   = NULL;
  dispWIDE   = DisplayWidth(display,theScreen);
  dispHIGH   = DisplayHeight(display,theScreen);
  dispDEEP   = DisplayPlanes(display,theScreen);

#ifdef DEBUG
  /* XSynchronize(theDisplay, 1); */
#endif DEBUG

  /* set up white,black colors */

  white = WhitePixel(display,theScreen);
  black = BlackPixel(display,theScreen);
  if (whitestr && XParseColor(display, theCmap, whitestr, &ecdef) &&
      XAllocColor(display, theCmap, &ecdef))  white = ecdef.pixel;
  if (blackstr && XParseColor(display, theCmap, blackstr, &ecdef) &&
      XAllocColor(display, theCmap, &ecdef))  black = ecdef.pixel;

  /* set up the GC */

  gc_values.foreground = white;
  gc_values.background = black;
  gc_values.function   = GXcopy;
  gc_values.plane_mask = AllPlanes;

  theGC = XCreateGC(theDisplay, theWindow,
                     GCForeground | GCBackground | GCFunction | GCPlaneMask,
                     &gc_values);
  if (!theGC)
  {
    sperror("InitPicIO: can't create graphics context!");
    return(False);
  }

  trace("VisualClass = %d\n", theVisual->class, 0, 0, 0);
  if (theVisual->class == StaticGray || theVisual->class == GrayScale)
  {
    mono = 1;
  }

  /* set ncols to 2^dispDEEP, unless dispDEEP = 1, in which case ncols = 0;
     (ncols = max number of colors allocated.
     On 1-bit displays, no colors are allocated */

  if (dispDEEP>1)
    ncols = 1<<dispDEEP;
  else
    ncols = 0;
  if (ncols>256)
    ncols = 256;       /* so program doesn't blow up */
  trace("ncols set to %d.\n",ncols, 0, 0, 0);

  InitFSDTables();
  GenerateFSGamma();
  jpeg_quality = 75;

  /* get environment variable for picture path */
  (void) getwd(tempp4);
  if ((tempp = (char *) getenv("SP_PIC_PATH")) != NULL)
  {
    if (tempp[0] == '.')
    {
       strcat(tempp4,"/");
       strcat(tempp4,tempp);
    }
    else
    {
       strcpy(tempp4,tempp);
    }


    strcpy(PicPath, (char*)NPath(tempp4));
    if (PicPath[strlen(PicPath) - 1] != '/')
    {
      strcat(PicPath,"/");
    }
  }
  else
  {
    sperror("InitPicIO: Environment variable \"SP_PIC_PATH\" not found.");
    sperror(     "      Using current directory.");
    strcpy(PicPath, tempp4);

  }
  return(True);
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :     LoadRasterImage                                       */
/*                                                                            */
/*      Version   :     19.03.1991                                            */
/*                                                                            */
/*      Purpose   :     Load a specified picture into the sketchpad           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :     Load Callback routine of sketchpad                    */
/*                                                                            */
/*      Calls     :     ClearRasterImage()                                    */
/*                      SortColormap()                                        */
/*                      DoMonoAndRV()                                         */
/*                      AllocColors()                                         */
/*                      CreateXImage()                                        */
/*                                                                            */
/* ========================================================================== */
int LoadRasterImage(char *cpath)
{ 
  int           i,
                filetype;

  FILE          *fp;

  byte          magicno[8];    /* first 8 bytes of file */
  char          path[256];

  int           x, y;
  unsigned int  win_width, win_height;
  unsigned int  borderwidth;
  unsigned int  depth;

  Window        root;
  Arg           args[2];

  if (widget_array[v_message_box] != NULL)
    if (XtIsManaged(widget_array[v_message_box]))
    {
      XtUnmanageChild(widget_array[v_message_box]);
      widget_array[v_message_box] = NULL;
      XSync(theDisplay, False);
    }
 
  SetWaitState();

  strcpy(path, PicPath);
  strcat(path, cpath);

  trace("try to open picture file %s.\n", path, 0, 0, 0);
  fp = fopen(path, "r");
  if (!fp) 
  {
    sperror("LoadRasterImage: cannot open picture file."); 
    ClearWaitState();
    return(False);  
  }

  fread(magicno, 8, 1, fp);  
  fclose(fp);

  filetype = UNKNOWN;
  if (strncmp(magicno, "GIF87", 5) == 0) filetype = GIF;

  else if (strncmp(magicno, "VIEW", 4) == 0 ||
	   strncmp(magicno, "WEIV", 4) == 0) filetype = PM;

  else if (magicno[0] == 'P' && magicno[1] >= '1' && 
	   magicno[1] <= '6') filetype = PBM;

  else if (strncmp(magicno, "#define", 7) == 0) filetype = XBM;

  else if (magicno[0]==0x59 && (magicno[1]&0x7f)==0x26 &&
           magicno[2]==0x6a && (magicno[3]&0x7f)==0x15) filetype = FSUN;

  else if ((magicno[0] == 'I' && magicno[1] == 'I')  || 
           (magicno[0] == 'M' && magicno[1] == 'M')) filetype = TIFF;

  else if (magicno[0]==0xff && magicno[1]==0xd8 &&
           magicno[2]==0xff) filetype = JPEG;

  if (filetype == UNKNOWN)
  {
    sperror("LoadRasterImage: picture file is of unknown type.");
    ClearWaitState();
    return(False);
  }

  /* free all data corresponding to the old image */
  ClearRasterImage();

  switch (filetype) {
  case GIF:  i = LoadGIF(path, ncols); break;
  case PM:   i = LoadPM (path, ncols); break;
  case PBM:  i = LoadPBM(path, ncols); break;
  case XBM:  i = LoadXBM(path, ncols); break;
  case FSUN: i = LoadSUN(path, ncols); break;
  case TIFF: i = LoadTIFF(path, ncols); break;
  case JPEG: i = LoadJFIF(path, ncols); break;
  }

  if (i)
  {
    sperror("LoadRasterImage: could not load picture.");
    ClearWaitState();
    return(False);
  }
  /* successfully read this picture */

  cpic = pic;  cWIDE = pWIDE;  cHIGH = pHIGH;  cXOFF = cYOFF = 0;

  SortColormap();

  /* save the desired RGB colormap */
  for (i=0; i<numcols; i++)
  {
    rorg[i] = r[i];
    gorg[i] = g[i];
    borg[i] = b[i];
  }

  DoMonoAndRV();

  /* Save Layer Colors for later use */
  if(!SaveLayerColors())
  {
    sperror("LoadRasterImage: Cannot save layer colors, sorry");
  }
  XSync(theDisplay, False);

  AllocColors();

  if (!RestoreLayerColors())
  {
    sperror("AllorColors: Cannot restore layer colors, sorry");
  }

  /* inquire window geometry */
  XGetGeometry(theDisplay, theWindow, &root, &x, &y, &win_width, &win_height,
               &borderwidth, &depth);

  /* set size of the window the image has to be put in */

  eHIGH = pHIGH;
  eWIDE = pWIDE;

  if (((Dimension) eWIDE  > (Dimension) win_width) ||
      ((Dimension) eHIGH   > (Dimension) win_height))
  {
    XtSetArg ( args[0], XmNheight, max ((Dimension) win_height,
                                        (Dimension) eHIGH ));
    XtSetArg ( args[1], XmNwidth,  max ((Dimension) win_width,
                                        (Dimension) eWIDE  ));
    XtSetValues(XtWindowToWidget(theDisplay, theWindow), args, 2);
  }

  thePixmap = XCreatePixmap (theDisplay, theWindow, (unsigned int) eWIDE,
                            (unsigned int) eHIGH,
                            dispDEEP);
  if (!thePixmap)
  {
    free(pic);
    sperror("LoadRasterImage: cannot create background pixmap");
    ClearWaitState();
    return(False);
  }

  epic = pic;

  /* call the Resize function with the values of eWIDE & eHIGH.
     Resize calls CreateXImage() */
  Resize(eWIDE, eHIGH); 

  /* put the new image into the new pixmap */
  XPutImage(theDisplay, thePixmap, theGC, theImage, 0, 0, 0, 0, 
            eWIDE, eHIGH);

  strcpy (picFilename, cpath);
  /* erase the window and cause the expose callback to be called. */
  XClearArea(theDisplay, theWindow, 0, 0, 0, 0, True);

  ClearWaitState();

  return(True);

}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :     ClearRasterImage                                      */
/*                                                                            */
/*      Version   :     19.03.1991                                            */
/*                                                                            */
/*                                                                            */
/*      Purpose   :     Clear sketchpad's drawing area                        */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :     Clear Callback routine of sketchpad                   */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
void ClearRasterImage(void)
{
  static XRectangle All = {0, 0, 0, 0};
  void       *pos;
  
  /* if zoom window is open then close it */
  CloseZoomWindow();

  pos = (void *) GetCurrentLayer();

  if (thePixmap)
  {
    XFreePixmap(theDisplay, thePixmap);
    thePixmap = 0;
    FreeColors();
    if (epic != cpic && epic != NULL) free(epic);
    if (cpic !=  pic && cpic != NULL) free(cpic);
    if (pic != NULL) free(pic);
    if (theImage != NULL) XDestroyImage(theImage);
    theImage = NULL;
    pic = epic = cpic = NULL;

    RedrawAll(All);

    SetCurrentLayer(pos);

    *picFilename = '\0';
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :     RedrawRasterImage                                     */
/*                                                                            */
/*      Version   :     19.03.1991                                            */
/*                                                                            */
/*                                                                            */
/*      Purpose   :     Redraw sketchpad's drawing area or part of it         */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :     Expose Callback routine of sketchpad                  */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
void RedrawRasterImage(XRectangle rec)
{
  if (thePixmap)
  {
    /*
     * copy the exposed area from the saved pixmap to the window
     */
    XCopyArea(theDisplay, thePixmap, theWindow,
                   theGC, rec.x, rec.y, rec.width, rec.height, rec.x, rec.y);
  } /* if (thePixmap) */
}



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :     WriteRasterImage                                      */
/*                                                                            */
/*      Version   :     21.05.1991                                            */
/*                                                                            */
/*      Purpose   :     Write Raster Image to Specified File                  */
/*                      opens file, does appropriate color pre-processing,    */
/*                      calls save routine based on chosen format.            */
/*                      Returns '1' if successful                             */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :     Save Callback routine of sketchpad                    */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int WriteRasterImage(char *path, int format, int currsize, int colorstyle)
{
  FILE *fp;
  byte *thepic, *bwpic;
  int   w,h,rv,i;
  char text[256];
  char *tempp1;
  char pathname[256];

  SetWaitState();

  if (!thePixmap)
  {
    sperror("WriteRasterImage: Nothing to write");
    return(0);
  }
  bwpic = NULL;

  if (currsize) { thepic = epic;  w = eWIDE;  h = eHIGH; }
           else { thepic = cpic;  w = cWIDE;  h = cHIGH; }

  if ((colorstyle == BW_STIPPLE) || (format == XBM)) 
  {
    /* generate a FSDithered 1-byte per pixel image */
    bwpic = (byte *) malloc(w*h);
    if (!bwpic)
    {
      sperror("WriteRasterImage: unable to malloc dithered picture!");
      return(0);
    }
    FSDither(thepic, w, h, bwpic);
    thepic = bwpic;
  }

  /* open file */
  fp = fopen(path, "w");
  if (!fp)
  {
    /* try to create directory */
    tempp1 = strrchr(path, '/');
    strncpy(pathname, path, tempp1 - path);
    pathname[tempp1 - path] = '\0';
    if (MakePath(pathname) == 0)
    {
      if (!(fp = fopen(path, "w")))
      {
        sprintf(text, "WriteRasterImage: unable to create '%s'", path);
        sperror(text);
        if (bwpic) free(bwpic);
        return(0);
      }
    }
    else
    {
      if (bwpic) free(bwpic);
      return(0);
    }
  }

  if ((mono || ncols==0) && colorstyle == FULL_COLOR) {
    /* if we're saving color, but we're viewing B/W we have to NOT do
       the 'monofication' of the colormap ... */
    for (i=0; i<numcols; i++) {
      r[i] = rorg[i];  g[i] = gorg[i];  b[i] = borg[i];  /* original */
      
      if (revvideo) {
	r[i] = 255-r[i];  g[i] = 255-g[i];  b[i] = 255-b[i];
      }
   } 

/*    GammifyColors(); */
  }
      
  rv = 0;
  i = format;
  switch (i) {
  case GIF:  rv = WriteGIF(fp,thepic,w, h, r, g, b, numcols, colorstyle);
             break;
  case PM:   rv = WritePM (fp,thepic,w, h, r, g, b, numcols, colorstyle); 
             break;
  case PBM:  rv = WritePBM(fp,thepic,w, h, r, g, b, numcols, colorstyle, 0);
             break;
  case XBM:  rv = WriteXBM(fp,thepic,w, h, path);
             break;
  case FSUN: rv = WriteSUN(fp,thepic,w, h, r, g, b, numcols, colorstyle);
             break;
  case TIFF: rv = WriteTIFF(fp,thepic,w, h, r, g, b, numcols, colorstyle);
             break;
  case JPEG: rv = WriteJFIF(fp,thepic,w, h, r, g, b, numcols, colorstyle,
                            jpeg_quality);
             break;
  default:
             break;
  }

  fclose(fp);
  if (rv) unlink(path);   /* couldn't properly write file:  delete it */

  if (bwpic) free(bwpic);

  if ((mono || ncols==0) && colorstyle == FULL_COLOR) {
    /* restore normal colormap */
    DoMonoAndRV();
/*    GammifyColors(); */
  }
  ClearWaitState();
  if (!rv)
    return 1;
  else
    return 0;
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :     SetJPEGQuality()                                      */
/*                                                                            */
/*      Version   :     26.03.1992                                            */
/*                                                                            */
/*      Purpose   :     Set JPEG Quality to new value                         */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :     JPEG Callback routine of sketchpad                    */
/*                                                                            */
/* ========================================================================== */
void SetJPEGQuality(int newquality)
{
  jpeg_quality = newquality;
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :     GetJPEGQuality()                                      */
/*                                                                            */
/*      Version   :     26.03.1992                                            */
/*                                                                            */
/*      Purpose   :     Returns actual JPEG quality value                     */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/* ========================================================================== */
int GetJPEGQuality()
{
  return(jpeg_quality);
}

