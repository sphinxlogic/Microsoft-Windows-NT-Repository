/* ========================================================================== */
/*                                                                            */
/* Filename:     io.h                             +-----+-----+--+--+--+--+   */
/*                                                !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Arbeitsgruppe         !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      ---------------------------------                     */
/*                                                                            */
/*      Creation Date        :  06.06.1991 by Markus Beyer                    */
/*      Last Modification    :  06.06.1991 by Markus Beyer                    */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Modification List    :                                                */
/*                                                                            */
/*      Date        Author      Modification made                             */
/*                                                                            */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Module    :  io.h                                                     */
/*                                                                            */
/*      Functions :  Header File for Load & Save Functions                    */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*  DEFINE STATEMENTS                                                         */
/* ========================================================================== */
#undef DEBUG
#ifndef trace
#ifdef DEBUG
#define trace(v,w,x,y,z) fprintf(stderr, v, w, x, y, z);
#else
#define trace(v,w,x,y,z)
#endif DEBUG
#endif trace

#define LOAD_BOX  0
#define SLIDE_BOX 1

/* ========================================================================== */
/*  FORWARD DECLARATIONS                                                      */
/* ========================================================================== */

int Save(char *);

int Load(char *, int);

int SendRasterFile(char *, int);

int SaveRasterFile(char *, int, char *);

char *NPath(char *);
