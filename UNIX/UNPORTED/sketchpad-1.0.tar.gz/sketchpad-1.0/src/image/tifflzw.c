/* ========================================================================== */
/*                                                                            */
/* Filename:     tifflzw.c                        +-----+-----+--+--+--+--+   */
/* Version :     1.3	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/15/92	10:43:44	                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*  Functions : (rctif_t) initalize ()                                        */
/*              (rctif_t) initializeStringTable ()                            */
/*              (rctif_t) firstInitOfStringTable ()                           */
/*                                                                            */
/*              (rctif_t) addTableEntry ()                                    */
/*                                                                            */
/*              (rctif_t) writeCode ()                                        */
/*              (rctif_t) omegaSearch ()                                      */
/*              (rctif_t) tiff_comp_strip_lzw ()                              */
/*                                                                            */
/*              (rctif_t) readCode ()                                         */
/*              (rctif_t) codeSearch ()                                       */
/*              (rctif_t) codeCheck ()                                        */
/*              (rctif_t) tiff_decomp_strip_lzw ()                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <stdio.h>
#include <math.h>
#include <string.h>
#include <malloc.h>
#include "tiff.h"

/* ========================================================================== */
/*      DEFINE STATEMENTS                                                     */
/* ========================================================================== */

typedef struct Levels{
        ushort_t        level;
        char_t          contents;
        ushort_t        entry_no;
        struct  Levels  *next_on_same_level;
        struct  Levels  *next_on_lower_level;
} lzwLevels_t;

typedef enum{
        LOWER_LEVEL,
        SAME_LEVEL
} lzwLevelType_t;

struct  {
        ushort_t        size;
        lzwLevels_t     single_chars[258];
} StringTable;


enum lzwOperations {
        LZW_COMPRESSION,
        LZW_DECOMPRESSION
} CurrentOperation;



#define No_lzwLevel     ((lzwLevels_t *)NULL)

#define CLEAR_CODE      256     /* Begin Of Information Code */
#define EOI_CODE        257     /* End Of Information Code   */
#define MaxNoOfBits      9
#define MinNoOfBits     9


/** Macros **/

#define CheckNoOfBitsW(x)       ((x > 4093) ?  0 :\
                                 (x > 2047) ? 12 :\
                                 (x > 1023) ? 11 :\
                                 (x >  511) ?  0 :\
                                  MinNoOfBits     \
                                )
#define CheckNoOfBitsR(x)       ((x > 4095) ?  0 :\
                                 (x > 2045) ? 12 :\
                                 (x > 1021) ? 11 :\
                                 (x >  509) ?  0 :\
                                  MinNoOfBits     \
                                )

/* ========================================================================== */
/*      GLOBAL VARIABLES                                                      */
/* ========================================================================== */

uchar_t   Reserve;      /* Rest eines n-Bit Wertes */
ushort_t  ResCount;     /* Zaehler */
boolean_t ReadStart;    /* Flag, ob 1. Lesevorgang */
boolean_t MoreBits;     /* Flag, ob Bitzahl erhoeht wurde */
boolean_t NewTable;     /* Flag, ob StringTable initialisiert wurde */
ushort_t  NoOfBits;     /* Anzahl Bits fuer LZW-Kompression */
ushort_t  NextEntryNo;  /* Nummer fuer naechsten Eintrag */
char_t    *Omega;       /* prefix string */
ushort_t  OmegaLen;
ushort_t  OmegaCode;
boolean_t OmegaFound;
boolean_t CodeFound;
boolean_t CodeNotFound;
char_t    Key;          /* Einzelzeichen              */

char_t    *CompressedData;
ulong_t   CompressedDataLen;
char_t    *DecompressedData;

/* ========================================================================== */
/*      Functions                                                             */
/* ========================================================================== */

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  initialize                                               */
/*                                                                            */
/*      Version   :  20.08.1991                                               */
/*                                                                            */
/*      Purpose   :  initialize (recursively) subtree of string table tree    */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  initializeStrintTable()                                  */
/*                                                                            */
/*      Calls     :  (rctif_t) initialize (rekursively)                       */
/*                                                                            */
/* ========================================================================== */
rctif_t initialize (lzwLevels_t *pos)
{
  rctif_t		ret;

  if (pos->next_on_same_level != No_lzwLevel)
  {
    if ((ret=initialize (pos->next_on_same_level)) != 1)
      return (ret);
    (void)free (pos->next_on_same_level);
  }
  if (pos->next_on_lower_level != No_lzwLevel)
  {
    if ((ret=initialize (pos->next_on_lower_level)) != 1)
    return (ret);
    (void)free (pos->next_on_lower_level);
  }
  pos->contents = '\0';
  pos->entry_no = 0;
  pos->level    = 0;
  pos->next_on_lower_level = No_lzwLevel;
  pos->next_on_same_level  = No_lzwLevel;

  return (1);
} /* initialize */

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  initializeStringTable                                    */
/*                                                                            */
/*      Version   :  20.08.1991                                               */
/*                                                                            */
/*      Purpose   :  initialize (recursively) string table tree               */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  tiff_comp_strip_lzw ()                                   */
/*                   tiff_decomp_strip_lzw ()                                 */
/*                                                                            */
/*      Calls     :  (rctif_t) initialize ()                                  */
/*                                                                            */
/* ========================================================================== */
rctif_t initializeStringTable (void)
{
  lzwLevels_t	*pos;
  int_t		i;
  rctif_t	ret;

  MoreBits    = FALSE;
  NewTable    = FALSE;
  NoOfBits    = MinNoOfBits;
  NextEntryNo = 258;
  if (Omega != No_char)
    (void)free (Omega);
  Omega       = No_char;
  OmegaLen    = 0;
  OmegaCode   = 0;
  OmegaFound  = FALSE;
  CodeFound   = FALSE;
  CodeNotFound= TRUE;
  Key         = '\0';
  StringTable.size = 258;

  for (i=0; i<256; i++)
  {
    pos = &(StringTable.single_chars[i]);
    if (pos->next_on_same_level != No_lzwLevel)
    {
      if ((ret=initialize (pos->next_on_same_level)) != 1)
        return (ret);
      (void)free (pos->next_on_same_level);
    }
    if (pos->next_on_lower_level != No_lzwLevel)
    {
      if ((ret=initialize (pos->next_on_lower_level)) != 1)
        return (ret);
      (void)free (pos->next_on_lower_level);
    }
    pos->entry_no = i;
    pos->contents = (char_t)i;
    pos->level    = 0;
    pos->next_on_lower_level = No_lzwLevel;
    pos->next_on_same_level  = No_lzwLevel;
  }
  return (1);
} /* initializeStringTable */

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  firstInitOfStringTable                                   */
/*                                                                            */
/*      Version   :  20.08.1991                                               */
/*                                                                            */
/*      Purpose   :  initialize root list of string table tree                */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  tiff_comp_strip_lzw ()                                   */
/*                   tiff_decomp_strip_lzw ()                                 */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
rctif_t firstInitOfStringTable (void)
{
  lzwLevels_t	*pos;
  int_t		i;

  Reserve     = (uchar_t)0;;
  ResCount    = 0;
  ReadStart   = TRUE;
  MoreBits    = FALSE;
  NewTable    = FALSE;
  NoOfBits    = MinNoOfBits;
  NextEntryNo = 258;
  Omega       = No_char;
  OmegaLen    = 0;
  OmegaCode   = 0;
  OmegaFound  = FALSE;
  CodeFound   = FALSE;
  CodeNotFound= TRUE;
  Key         = '\0';

  CompressedData    = No_char;
  CompressedDataLen = 0;
  DecompressedData  = No_char;
  StringTable.size  = 258;

  for (i=0; i<256; i++)
  {
    pos = &(StringTable.single_chars[i]);
    pos->entry_no = i;
    pos->contents = (char_t)i;
    pos->level    = 0;
    pos->next_on_lower_level = No_lzwLevel;
    pos->next_on_same_level  = No_lzwLevel;
  }
  return (1);
} /* firstInitOfStringTable */

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  addTableEntry                                            */
/*                                                                            */
/*      Version   :  20.08.1991                                               */
/*                                                                            */
/*      Purpose   :  insert new entry into string table tree                  */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  omegaSearch ()                                           */
/*                   tiff_decomp_strip_lzw ()                                 */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
rctif_t	addTableEntry (lzwLevels_t *pos, lzwLevelType_t *level_type,
                       char_t *string)
{
  lzwLevels_t	*last;
  ushort_t	level,
  		test_bits;

  if (pos==No_lzwLevel || string==No_char)
    return (0);

  last = pos;

  switch (*level_type){
    case LOWER_LEVEL:
      if ((pos->next_on_lower_level=
          (lzwLevels_t *)malloc ((uint_t)sizeof(lzwLevels_t))
         ) == No_lzwLevel)
        return (0);
      pos   = pos->next_on_lower_level;
      level = last->level+1;
      break;

    case SAME_LEVEL:
      if ((pos->next_on_same_level=
          (lzwLevels_t *)malloc ((uint_t)sizeof(lzwLevels_t))
         ) == No_lzwLevel)
        return (0);
      pos   = pos->next_on_same_level;
      level = last->level;
      break;

    default:	
      return (0);
    } /* switch */

    pos->contents = string[level];

    pos->entry_no = NextEntryNo;
    pos->level    = level;
    pos->next_on_lower_level = No_lzwLevel;
    pos->next_on_same_level  = No_lzwLevel;
    NextEntryNo++;
    StringTable.size++;

    if (CurrentOperation == LZW_COMPRESSION)
    {
      test_bits = CheckNoOfBitsW (pos->entry_no);
      if (test_bits==0)
      {
        NewTable = TRUE;
        NoOfBits = MaxNoOfBits;
      }
    }
    else
    {
      test_bits = CheckNoOfBitsR (pos->entry_no);
    }
    if (NoOfBits < test_bits)
    {
      NoOfBits = test_bits;
      MoreBits = TRUE;
    }
    if (NoOfBits<MinNoOfBits || NoOfBits>MaxNoOfBits)
      return (0);

    return (1);
} /* addTableEntry */

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  writeCode                                                */
/*                                                                            */
/*      Version   :  20.08.1991                                               */
/*                                                                            */
/*      Purpose   :  write code or part of it (according to LZW bitlengths)   */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  tiff_comp_strip_lzw ()                                   */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
rctif_t writeCode (ushort_t code)
{
  uchar_t		output;
  ushort_t	shift_bits,
		tmp;

  shift_bits = (NoOfBits-8+ResCount);

  output = Reserve | (code >> shift_bits);  /* compute 1st byte of code */
  CompressedData[CompressedDataLen++] = output;

  tmp = (code << (16-shift_bits)); /* reserve 2nd byte of code */
  Reserve  = (tmp >> 8);

  ResCount = shift_bits % 8;
  if (shift_bits > 7)   /* code exceeds byte boundary */
  {
    output = CompressedData[CompressedDataLen++] = Reserve;
    tmp = (code << (16-ResCount)); /* reserve next byte of code */
    Reserve  = (tmp >> 8);
  }

if (code==(ushort_t)EOI_CODE && ResCount > 0)
  output = CompressedData[CompressedDataLen++] = Reserve;


return (1);
} /* writeCode */

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  omegaSearch                                              */
/*                                                                            */
/*      Version   :  20.08.1991                                               */
/*                                                                            */
/*      Purpose   :  search string (omega) recursively in string table tree,  */
/*                   creates new entry if not found                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  tiff_comp_strip_lzw ()                                   */
/*                                                                            */
/*      Calls     :  (rctif_t) addTableEntry ()                               */
/*                   (rctif_t) omegaSearch ()    (rekursively)                */
/*                                                                            */
/* ========================================================================== */
rctif_t	omegaSearch (char *omega, lzwLevels_t *pos, ushort_t level, 
                     ushort_t max_level)
{
  char_t		test;
  lzwLevelType_t	lt;
  rctif_t		ret;

  if (omega==No_char || pos==No_lzwLevel)
    return (0);

  OmegaFound = FALSE;
  test       = pos->contents;

  if (test == omega[level])
  {
    if (level == max_level)
    {
      OmegaFound = TRUE;
      OmegaCode  = pos->entry_no;
    }
    else	/* searched string must continue on lower level */
    {
      OmegaCode = pos->entry_no;
      if (pos->next_on_lower_level != No_lzwLevel)
      {
        if ((ret=omegaSearch (omega, pos->next_on_lower_level,
                              level+1, max_level)) != 1)
          return (ret);
      }
      else	/* searched string cannot be in string table */
      {
        lt = LOWER_LEVEL;
        /* add table entry */
        if ((ret=addTableEntry (pos, &lt, omega))
           != 1)
          return (ret);
      }
    } /* else */
  } /* if (test..) */
  else /* searched string must continue on same level elsewhere */
    if (pos->next_on_same_level != No_lzwLevel)
    {
      if ((ret=omegaSearch (omega, pos->next_on_same_level,
                            level, max_level)) != 1)
        return (ret);
    }
    else          /* searched string cannot be in string table */
    {
      lt = SAME_LEVEL;
      /* add table entry */
      if ((ret=addTableEntry (pos, &lt, omega))
	  != 1)
        return (ret);
    }

  return (1);
} /* omegaSearch */

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  tiff_comp_strip_lzw                                      */
/*                                                                            */
/*      Version   :  20.08.1991                                               */
/*                                                                            */
/*      Purpose   :  compress ONE data field (strip) according to LZW         */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  WriteTIFF()       (Modul tiffwio.c)                      */
/*                                                                            */
/*      Calls     :  (rctif_t) firstInitOfStringTable ()                      */
/*                   (rctif_t) initializeStringTable ()                       */
/*                   (rctif_t) omegaSearch ()                                 */
/*                   (rctif_t) writeCode ()                                   */
/*                                                                            */
/* ========================================================================== */
rctif_t tiff_comp_strip_lzw (char_t *in_strip, ulong_t size_of_in_strip,
                             char_t ** out_strip, ulong_t *size_of_out_strip)
{
  char_t	*omega;
  rctif_t	ret;

  lzwLevels_t	*start_pos;
  
  register ulong_t k;
  
  if (in_strip==No_char || size_of_in_strip<=0 ||
      size_of_out_strip==No_ulong)
    return (0);
  
  CurrentOperation = LZW_COMPRESSION;
  CompressedDataLen = 0;
  if (CompressedData != No_char)
    (void)free (CompressedData);
  
  (void)firstInitOfStringTable();
  
  CompressedData = (char_t *)malloc((uint_t)size_of_in_strip);
  if (CompressedData == No_char)
    return (0);
  
  if ((ret=writeCode ((ushort_t)CLEAR_CODE)) != 1)
    return (ret);
  
  for (k=0; k<size_of_in_strip; k++)
  {
    Key = in_strip[k];
    if (Omega != No_char)
      omega  = (char_t *)realloc (Omega, (uint_t)(OmegaLen+1));
    else
      omega  = (char_t *)malloc ((uint_t)1);
    if (Omega != omega && Omega != No_char)
      (void)free (Omega);
    Omega = No_char;
    omega[OmegaLen] = Key;
    start_pos = &(StringTable.single_chars[(int_t)(omega[0])]);
    if ((ret=omegaSearch (omega, start_pos, 0, OmegaLen)) != 1)
    {
      (void)free (CompressedData);
      return (ret);
    }
  
    Omega = omega;
    omega = No_char;
  
    if (OmegaFound)
    {
      OmegaLen++;
      if (NewTable){ /* writing clear code nescessary */
        NewTable = FALSE;
        if (Omega != No_char)
        {
          (void)free (Omega);
          Omega = No_char;
        }
        if ((ret = writeCode (OmegaCode)) != 1)
        {
          (void)free (CompressedData);
          return (ret);
        }
        if ((ret=writeCode((ushort_t)CLEAR_CODE))!=1)
        {
          (void)free (CompressedData);
          return (ret);
        }
        if ((ret=initializeStringTable ()) != 1)
        {
          (void)free (CompressedData);
          return (ret);
        }
      } /* if NewTable */
    } /* if OmegaFound */
    else 
    {
      if ((ret = writeCode (OmegaCode)) != 1)
      {
        (void)free (CompressedData);
        return (ret);
      }
      if (Omega != No_char)
      {
        (void)free (Omega);
        Omega = No_char;
      }
      if (NewTable)  /* writing clear code nescessary */
      {
        NewTable = FALSE;
        if ((ret = writeCode ((ushort_t)Key)) != 1)
        {
          (void)free (CompressedData);
          return (ret);
        }
        if ((ret=writeCode((ushort_t)CLEAR_CODE))!=1)
        {
          (void)free (CompressedData);
          return (ret);
        }
        if ((ret=initializeStringTable ()) != 1)
        {
          (void)free (CompressedData);
          return (ret);
        }
      } /* if NewTable */
      else
      {
        OmegaLen = 1;
        Omega    = (char_t *)malloc ((uint_t)1);
        Omega[0] = Key;
        OmegaCode= (ushort_t)Omega[0];
      } /* else NewTable */
    } /* else OmegaFound */
  } /* for */
  
  if (OmegaLen > 0 && Omega != No_char) 	/* No NewTable */
  {
    start_pos = &(StringTable.single_chars[(int_t)(Omega[0])]);
    if ((ret=omegaSearch (Omega, start_pos, 0, OmegaLen-1)) != 1)
    {
      (void)free (CompressedData);
      return (ret);
    }
    if ((ret = writeCode (OmegaCode)) != 1)
    {
      (void)free (CompressedData);
      return (ret);
    }
  }
  if ((ret = writeCode ((ushort_t)EOI_CODE)) != 1)
  {
    (void)free (CompressedData);
    return (ret);
  }
  if ((*out_strip=(char_t *)malloc ((uint_t)CompressedDataLen))==No_char)
  {
    (void)free (CompressedData);
    return (0);
  }
  if (CompressedDataLen > 0)
    (void)memcpy(*out_strip,CompressedData,(uint_t)CompressedDataLen);
  (void)free (CompressedData);
  *size_of_out_strip = CompressedDataLen;

  if (CompressedData != No_char)
    (void)free (CompressedData);
  CompressedData = No_char;

  return (initializeStringTable());
} /* tiff_comp_strip_lzw */

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  readCode                                                 */
/*                                                                            */
/*      Version   :  20.08.1991                                               */
/*                                                                            */
/*      Purpose   :  read LZW code (according to LZW bit lengths)             */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  tiff_decomp_strip_lzw ()                                 */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
rctif_t readCode (ushort_t *code)
{
  uchar_t	input;
  ushort_t	shift_bits,
		test_bits,
		fst_byte,
                snd_byte;
  short_t	neg_shift;
  
  if (MoreBits)
  {
    MoreBits = FALSE;
    ResCount++;
  }	
  if (ReadStart)
  {		/* start on byte boundaries */
    input = CompressedData[CompressedDataLen++];
    ReadStart = FALSE;
    shift_bits= NoOfBits-8;
    ResCount  = shift_bits;
  }
  else
  {
    input      = Reserve;	/* get last byte */
    shift_bits = ResCount;
  }

  neg_shift = 8 - shift_bits;

  fst_byte  = (ushort_t)input << shift_bits;   /* 1st byte of code */
	

  /* get 2nd byte of code */
  input = CompressedData[CompressedDataLen++];
  if (neg_shift > 0)
    snd_byte = (ushort_t)input >> (ushort_t)neg_shift;
  else
    snd_byte = (ushort_t)input << (ushort_t)(-neg_shift);

  *code = fst_byte | snd_byte;	/* compute code */

  /* if nescessary get again one byte for code */
  if (shift_bits > 8)
  {
    shift_bits -= 8;
    neg_shift = 8 - shift_bits;
    input = CompressedData[CompressedDataLen++];
    snd_byte = (ushort_t)input >> (ushort_t)neg_shift;
    *code |= snd_byte;
  }
  
  /* reserve last byte read for next code */
  Reserve = input << shift_bits;
  Reserve = Reserve >> shift_bits;

  /* compute offset for next code in bitstring */
  ResCount = (NoOfBits - (ushort_t)neg_shift);
  if ((ResCount %= NoOfBits) == 0)    /* code ended on byte boundary */
    ReadStart = TRUE;

  /* Test if legal code was read */
  test_bits = CheckNoOfBitsR (*code);
  if (!test_bits)
    return (0);

  return (1);
} /* readCode */

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  codeSearch                                               */
/*                                                                            */
/*      Version   :  20.08.1991                                               */
/*                                                                            */
/*      Purpose   :  recursively search LZW code in subtree of string table   */
/*                   tree                                                     */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  codeCheck ()                                             */
/*                                                                            */
/*      Calls     :  (rctif_t) codeSearch ()    (rekursively)                 */
/*                                                                            */
/* ========================================================================== */
rctif_t	codeSearch (ushort_t code, lzwLevels_t *pos, lzwLevels_t **found_pos,
                    ushort_t *level)
{
  ushort_t	test;
  rctif_t	ret;

  if (pos==No_lzwLevel || level==No_ushort)
    return (0);

  test = pos->entry_no;

  if (test == code)
  {
    CodeFound  = TRUE;
    *found_pos = pos;
    *level     = pos->level;
    Omega[OmegaLen] = pos->contents;
  }
  else	/* search code on lower level */
  {
    CodeFound  = FALSE;
    if (pos->next_on_lower_level != No_lzwLevel)
    {
      Omega[OmegaLen++] = pos->contents;
      Omega = (char_t *)realloc (Omega, (uint_t)(OmegaLen+1));
      if ((ret=codeSearch (code, pos->next_on_lower_level,
			   found_pos, level)) != 1)
	return (ret);
      if (!CodeFound)
        Omega = (char_t *)realloc (Omega, (uint_t)(OmegaLen--));
    }

    /* search code on same level */
    if (!CodeFound && pos->next_on_same_level != No_lzwLevel)
    {
      if ((ret=codeSearch (code, pos->next_on_same_level,
			   found_pos, level)) != 1)
        return (ret);
    }
  }
  return (1);
} /* codeSearch */

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  codeCheck                                                */
/*                                                                            */
/*      Version   :  20.08.1991                                               */
/*                                                                            */
/*      Purpose   :  search entire string table tree for LZW code             */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  tiff_decomp_strip_lzw ()                                 */
/*                                                                            */
/*      Calls     :  (rctif_t) codeSearch ()                                  */
/*                                                                            */
/* ========================================================================== */
rctif_t codeCheck (ushort_t code, lzwLevels_t **found_pos, ushort_t *level)
{
  int_t		i;
  lzwLevels_t	*pos;
  rctif_t		ret;

  if (level==No_ushort)
    return (0);

  if (code < 258)
  {
    CodeFound  = TRUE;
    *found_pos = &(StringTable.single_chars[(int_t)code]);
    if (code < 256)
      Key  = (*found_pos)->contents;
    *level   = 0;
    OmegaLen = 1;
    Omega[0] = Key;
  }
  else
  {
    CodeFound = FALSE;
    OmegaLen  = 1;
    for (i=0; i<256; i++)
    {
      if (StringTable.single_chars[i].next_on_lower_level != No_lzwLevel)
      {
        Omega[0] =
        Key      = StringTable.single_chars[i].contents;
        pos      = StringTable.single_chars[i].next_on_lower_level;
        if ((ret=codeSearch (code, pos, found_pos, level))!=1)
          return (ret);
        if (CodeFound)
        {
          OmegaLen++;
          break;
        }
      } /* if */
    } /* for */
  } /* else */

  return (1);
} /* codeCheck */

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  tiff_decomp_strip_lzw                                    */
/*                                                                            */
/*      Version   :  20.08.1991                                               */
/*                                                                            */
/*      Purpose   :  decompress LZW coded Data                                */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  LoadTIFF (module picio.c)                                */
/*                                                                            */
/*      Calls     :  (rctif_t) firstInitOfStringTable ()                      */
/*                   (rctif_t) initializeStringTable ()                       */
/*                   (rctif_t) readCode ()                                    */
/*                   (rctif_t) codeCheck ()                                   */
/*                                                                            */
/* ========================================================================== */
rctif_t	tiff_decomp_strip_lzw (char_t *in_strip, ulong_t size_of_in_strip,
                               char **out_strip, ulong_t *size_of_out_strip)
{
  char_t		*strip,
  			*new_strip,
			*out_strip_ptr,
			*old_omega,
			*old_omega2,
			code_key;
  ushort_t		code          = 0,
			old_omega_len = 0,
			level         = 0;
  ulong_t		real_size     = 0;
  lzwLevelType_t	lt            = LOWER_LEVEL;
  lzwLevels_t		*found_pos,
			*old_pos,
			*old_pos2;
  int_t			i;
  rctif_t		ret;

  if (in_strip==No_char|| size_of_in_strip<=0)
    return (0);

  (void)firstInitOfStringTable();

  *size_of_out_strip = 1024 + (size_of_in_strip * 10) % 1024;
  if ((out_strip_ptr=(char_t *)malloc((uint_t)*size_of_out_strip))==No_char)
    return (0);
  strip = out_strip_ptr;

  CurrentOperation  = LZW_DECOMPRESSION;
  if (CompressedData != No_char)
    (void)free (CompressedData);
  CompressedData    = in_strip;

  found_pos   = No_lzwLevel;
  old_pos     = No_lzwLevel;
  ret = readCode (&code);
  while ((ret == 1) && (code != (ushort_t)EOI_CODE) &&
         (CompressedDataLen <= size_of_in_strip))
  {
    if (code == (ushort_t)CLEAR_CODE)
    {
      if ((ret=initializeStringTable ()) != 1)
      {
        (void)free (strip);
        return (ret);
      }
      if ((ret=readCode (&code)) != 1)
      {
        (void)free (strip);
        return (ret);
      }
      if (code == (ushort_t)EOI_CODE)
        break;
      Omega    = (char_t *)malloc ((uint_t)1);
      Omega[0] = (char_t)code;
      *(out_strip_ptr++) = Omega[0];

      old_omega     = Omega;
      old_omega2    = No_char;
      old_omega_len = 1;
      old_pos       = &(StringTable.single_chars[(int_t)code]);
    }
    else  /* no Clear Code */
    {
      Omega = (char_t *)malloc ((uint_t)1);
      if ((ret=codeCheck (code, &found_pos, &level)) != 1)
      {
        (void)free (strip);
        return (ret);
      }
      if (CodeFound)
      {
        CodeNotFound = FALSE;
        /* WriteString (StringFromCode(code)) */
        for (i=0; i<OmegaLen; i++, out_strip_ptr++)
        {
          *out_strip_ptr = Omega[i];
        }
        code_key = Key;           /* code_key = FirstCharOfCode */
      }
      else{
        CodeNotFound = TRUE;
        code_key     = old_omega[0];
      }

      /* Construct StringFromCode(old_code) + Key */
      old_omega2 = (char_t *)realloc (old_omega, (uint_t)(old_omega_len+1));
      if (old_omega != old_omega2 && old_omega != No_char)
        (void)free (old_omega);
      old_omega = No_char;
      old_omega2[old_omega_len] = code_key;
      old_omega_len++;

      if (CodeNotFound) 
      {
        /* WriteString (StringFromCode(old_code)+Key) */
        for (i=0; i<old_omega_len; i++, out_strip_ptr++)
        {
          *out_strip_ptr = old_omega2[i];
        }
      }

      /* AddStringToTable */
      old_pos2 = old_pos;
      if (old_pos2->next_on_lower_level != No_lzwLevel)
      {
        lt = SAME_LEVEL;
        old_pos2 = old_pos2->next_on_lower_level;
        while (old_pos2->next_on_same_level != No_lzwLevel)
          old_pos2 = old_pos2->next_on_same_level;
      }
      else
        lt = LOWER_LEVEL;
      if ((ret=addTableEntry (old_pos2, &lt, old_omega2)) != 1)
      {
        (void)free (strip);
        return (ret);
      }

      /* store new omega paramaters */
      if (CodeNotFound)
      {
        old_omega  = old_omega2;
        old_omega2 = No_char;
        if (lt == SAME_LEVEL)
          old_pos = old_pos2->next_on_same_level;
        else	
          old_pos = old_pos2->next_on_lower_level;
      }
      else
      {
        old_omega     = Omega;
        old_omega_len = OmegaLen;
        if (old_omega2 != No_char)
          (void)free (old_omega2);
        old_omega2    = No_char;
        old_pos       = found_pos;
      }
      real_size = (ulong_t)(out_strip_ptr - strip);
      if (*size_of_out_strip < real_size+5)
      {
        *size_of_out_strip += 1024;
        new_strip = No_char;
        new_strip = (char_t *)realloc (strip, (uint_t)(*size_of_out_strip));
        if (new_strip == No_char)
        {
          (void)free (strip);
  	  return (0);		
        }
        if (strip != new_strip)
        {
          (void)free (strip);
          strip = new_strip;
        }
        out_strip_ptr = strip + real_size;
      }
    } /* else */
    ret = readCode (&code);
    if (code==(ushort_t)CLEAR_CODE)
      ResCount -= (MaxNoOfBits-MinNoOfBits);
  } /* while */

  if (ret != 1)
  {
    (void)free (strip);
    return (ret);
  }

  *size_of_out_strip = real_size;
  if ((*out_strip=(char_t *)malloc ((uint_t)real_size))==No_char)
  {
    (void)free (strip);
    return (0);
  }
  if (real_size > 0)
    (void)memcpy(*out_strip, strip, (uint_t)real_size);
  (void)free (strip);

  return (initializeStringTable ());
} /* tiff_decomp_strip_lzw */
