/* ========================================================================== */
/*                                                                            */
/* Filename:     io.c                             +-----+-----+--+--+--+--+   */
/* Version :     1.3	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/15/92	10:43:31	                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*                                                                            */
/*      Module    :  io.c                                                     */
/*                                                                            */
/*      Functions :  Load()  : Loads session from disk: if a layered sketch   */
/*                             is to be loaded the path is interpreted as     */
/*                             name of a master file, else the selected layer */
/*                             determines the interpretation:                 */
/*                                if it is layer one we try to load a raster  */
/*                                image, otherwise we try to load a layer.    */
/*                                                                            */
/*                   Save()  : Writes session to disk: one master file with   */
/*                             names of all layers and one file for each      */
/*                             layer.                                         */
/*                             naming convention:                             */
/*                                master file gets ending '.sess'             */
/*                                layer files get ending '.<id>'              */
/*                                  where <id> is a identification number,    */
/*                                  that ensures us that each layer has a     */
/*                                  unique name.                              */
/*                                                                            */
/*                   SendRasterFile() : Send a Picture File to Start Process  */
/*                                                                            */
/*                   SaveRasterFile() : Save a Picture File                   */
/*                                                                            */
/*                   NPath() : local function to normalize filenames:         */
/*                             eliminates "/./" and "/?????/../" parts of it  */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <stdio.h>
#include <string.h>
/* #include <stdlib.h> */
#include <malloc.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/param.h>
#include "io.h"
#include "../ui/defs.h"
#include "../misc/ographic.h"
#include "../misc/wait.h"
#include "../kernel/user.h"
#include "../kernel/message.h"
#include "../ui/layer.h"
#include "../draw/drawstate.h"
#include "../ui/sketchpad.h"
#include "../misc/makepath.h"
#include "picio.h"



#ifdef vax
/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  strstr                                                   */
/*                                                                            */
/*      Version   :  17.07.1991                                               */
/*                                                                            */
/*      Purpose   :  "standard c" strstr function for sun                     */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  NPath()                                                  */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
char *strstr(char *s1, char *s2)
{
  char *temp; 
  int  i;
  int  found = True;
 
  temp = strchr(s1, s2[0]);
  if (temp == NULL) 
  {
    return(NULL);
  }
  for(i = 0; i < strlen(s2); i++)  
  {
    if (temp[i] != s2[i])
    {
      found = False;
      break;
    }
  }
  if (found)
  {
    return(temp);
  }
  if ((s1 + strlen(s1) - temp) < strlen(s2))
  {
    return(NULL);
  }
  return(strstr(temp + 1, s2));
} /* strstr */

#endif vax



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  NPath                                                    */
/*                                                                            */
/*      Version   :  12.06.1991                                               */
/*                                                                            */
/*      Purpose   :  Normalize filename                                       */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  Load()                                                   */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
char *NPath(char *path)
{
  char newpath[256];
  char temps[256];
  char *tempp1, *tempp2;

  sprintf(newpath,""); sprintf(temps,"");
  strcpy(newpath, path);
  /* first eliminate "/./" */
  while ((tempp1 = strstr(newpath, "/./")) != NULL)
  {
    /* copy part before "/./" */
    strncpy(temps, newpath, tempp1 - newpath);
    /* append NULL character */
    temps[tempp1 - newpath] = '\0';
    /* append part after "/./" */
    strcat(temps, tempp1 + 2);
    /* store in newpath */
    strcpy(newpath, temps);
    trace("/./: newpath now: %s\n", newpath, 0, 0, 0);
  }
  /* eliminate "/?????/../" */
  if ((tempp1 = strstr(newpath, "/../")) == NULL)
  {
    /* trace("/../: newpath now: %s\n", newpath, 0, 0, 0); */
    return(newpath);
  }
  else
  {
    /* copy part before "/../" */
    strncpy(temps, newpath, tempp1 - newpath);
    /* append NULL character */
    temps[tempp1 - newpath] = '\0';
    /* look for last "/" before "/../" */
    tempp2 = strrchr(temps, '/');
    /* copy part before last "/" before "/../" to newpath */
    if(tempp2 > temps)
      strncpy(newpath, temps, tempp2 - temps - 1);
    /* append NULL character */
    newpath[tempp2 - temps] = '\0';
    /* append part after "/../" */
    strcat(newpath, tempp1 + 3);
    /* trace("/../: newpath now: %s\n", newpath, 0, 0, 0); */
    return NPath(newpath);
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  Load                                                     */
/*                                                                            */
/*      Version   :  06.06.1991                                               */
/*                                                                            */
/*      Purpose   :  Load session or layer into sketchpad                     */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  Main Program of Sketchpad                                */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int Load(char *path, int why)
{
  FILE            *mfp;
  layer           lay;
  int             layer_id, sketch_id;

  char            npath[256];
  char            masterfile[256];
  char            filename[256]; 
  char            mfilename[40];   /* filename for load message */
  char            cfilename[40]; 
  char            lfilename[256];
  char            layername[256];
  char            masterstring[256];
  char            *tempp1;
  char            *tempp2;
  char            lflag;
  char             tempp4[MAXPATHLEN];

  Arg AL[1];
 
  int    loadrel = False;
  int    loadall = False;
  int    senddata = False;
  int    something_loaded = False;

  XColor        color;
  int           red, green, blue;

  void          *pos;
  char          text[256];
  
  sprintf(npath,""); sprintf(masterfile,""); sprintf(filename,"");
  sprintf(mfilename,""); sprintf(cfilename,""); sprintf(lfilename,"");
  sprintf(layername,""); sprintf(masterstring,"");

  XSync(theDisplay, False);

  /* get environment variable for picture path */
  (void) getwd(tempp4);
  if ((tempp1 = (char *) getenv("SP_PIC_PATH")) != NULL)
  {
    if (tempp1[0] == '.')
    {
       strcat(tempp4,"/");
       strcat(tempp4,tempp1);
    }
    else
    {
       strcpy(tempp4,tempp1);
    }

    strcpy(PicPath, NPath(tempp4));
    if (PicPath[strlen(PicPath) - 1] != '/')
    {
      strcat(PicPath,"/");
    }
  }
  else
  {
    sperror("Load: Environment variable \"SP_PIC_PATH\" not found.");
    sperror("      Using current directory.");
    strcpy(PicPath, tempp4);

  }

  /* modify filename for load message */
  strcpy(npath, NPath(path));
  tempp1 = strstr(npath, PicPath);
  if (tempp1 == npath)
  {
    /* Picture is located relative to PicPath */
    strcpy(mfilename, npath + strlen(PicPath));
    loadrel = True; 
  }
  else
  {
    /* Picture is not located relative to PicPath */
    /* filename for message = filename without directory */  
    tempp1 = strrchr(npath, '/');
    if (tempp1 != NULL)
      tempp1++;
    else
      tempp1 = npath;
    strcpy(mfilename, tempp1);
    loadrel = False;
  }
  trace("mfilename set to %s\n",mfilename,0,0,0);

  /* save PicPath in OPicPath for later recovery */
  strcpy(OPicPath, PicPath);

  /* set PicPath to path of picture */ 
  tempp1 = strrchr(npath, '/');
  if (tempp1 != NULL)
  {
    strncpy(PicPath, npath, tempp1 - npath + 1);
    PicPath[tempp1 - npath + 1] = '\0';
    trace("PicPath set to %s\n",PicPath,0,0,0);
  }
  else
  {
    PicPath[0] = '\0';
  }

  /* crop directory off filename */
  tempp1 = strrchr(npath, '/');
  if (tempp1 != NULL)
    tempp1++;
  else
    tempp1 = npath;
  strcpy(cfilename, tempp1);
  trace("cfilename set to %s\n",cfilename,0,0,0);

  if (why == LOAD_BOX)
  {
    /* look what is to be loaded */
    XtSetArg (AL[0], XmNset, &loadall);
    XtGetValues(widget_array[v_load_box_all_button], AL, 1);
    if (loadall)
    {
      trace("Load all.\n", 0, 0, 0, 0); 
    }
  
    if (loadall)
    {
      something_loaded = True;
      /* open master file */
      strcpy(masterfile, npath);
      mfp = fopen(masterfile, "r");
      if (!mfp)
      {
        sperror("Load: Cannot open master file.");
        strcpy(PicPath, OPicPath);
        strcpy(OPicPath, "\0");
        return(0);
      }
  
      /* Check header */
      fgets(masterstring, 256, mfp);
      if (strcmp (masterstring, "C: *** Sketchpad Session File ***\n") != 0)
      {
        sperror("Load: This is no Sketchpad Session File."); 
        strcpy(PicPath, OPicPath);
        strcpy(OPicPath, "\0");
        return(0);
      }
  
      /* Load the whole session */
  
      /* first kill all old layers (we want a clear sketchpad) */
      lay = GetFirstLayer ();
      pos = GetCurrentLayer();
      while (lay != NULL)
      {
        GetLayerId (lay, &layer_id, &sketch_id);
  
        if ((layer_id == 1) && (sketch_id == 0))
        {
          msg_clear_layer(layer_id, sketch_id);
          (void) ClearRasterImage();
        }
        else if ((layer_id == 2) && (sketch_id == 0))
        {
          msg_clear_layer(layer_id, sketch_id);
          (void) ClearLayer (layer_id, sketch_id);
        }
        else
        {
          msg_kill_layer(layer_id, sketch_id);
          (void) delete_layer(layer_id, sketch_id);
          SetCurrentLayer(pos);
        }
        pos = GetCurrentLayer();
        lay = GetNextLayer ();
      }
  
      lay = GetFirstLayer();
  
      /* for each entry in the masterfile */
      while (fgets(masterstring, 256, mfp) != NULL)
      {
        XSync(theDisplay, False);
        strcpy(filename, "\0");
        strcpy(layername, "\0");
        trace("%s", masterstring, 0, 0, 0);
        /* examine masterstring */
        lflag = masterstring[0];
        trace("lflag: %c\n", lflag, 0, 0, 0);
        if ((lflag != 'R') && (lflag != 'O'))
        {
          /* ignore line */ 
          if (lflag != 'C')
          {
            /* no comment line */
            sprintf(text, "Load: Warning: line \"%s\" ignored!",
                    masterstring);
            sperror(text); 
          }
          continue;
        }
        tempp1 = strchr(masterstring,'<');
        if (tempp1 == NULL)
        {
          sperror("Load: Warning: error reading filename in line");
          sprintf(text, "      %s", masterstring);
          sperror(text);
          sperror("      line ignored.");
          continue;
        }       
        tempp1++;
        tempp2 = strrchr(tempp1,'>');
        if (tempp2 == NULL)
        {
          sperror("Load: Warning: error reading filename in line");
          sprintf(text, "      %s", masterstring);
          sperror(text);
          sperror("      line ignored.");
          continue;
        }       
        strncpy(filename, tempp1, tempp2 - tempp1);
        filename[tempp2 - tempp1] = '\0';
        trace("File: %s\n", filename, 0, 0, 0);
        tempp1 = strchr(tempp2,'\"');
        if (tempp1 == NULL)
        {
          sperror("Load: Warning: error reading layername in line");
          sprintf(text, "      %s", masterstring);
          sperror(text);
          sperror("      line ignored.");
          continue;
        }       
        tempp1++;
        tempp2 = strrchr(tempp1,'\"');
        if (tempp2 == NULL)
        {
          sperror("Load: Warning: error reading layername in line");
          sprintf(text, "      %s", masterstring);
          sperror(text);
          sperror("      line ignored.");
          continue;
        }       
        strncpy(layername, tempp1, tempp2 - tempp1);
        layername[tempp2 - tempp1] = '\0';
        trace("Layer: %s\n", layername, 0, 0, 0);
        tempp1 = strchr(tempp2,'#');
        if (sscanf(tempp1,"#%d #%d #%d", &red, &green, &blue) < 3)
        {
          sperror("Load: Warning: error reading color in line");
          sprintf(text, "      %s", masterstring);
          sperror(text);
          sperror("      line ignored.");
          continue;
        }       
        color.red   = (unsigned short) red;
        color.green = (unsigned short) green;
        color.blue  = (unsigned short) blue;
        trace("Color: %d  %d  %d\n", color.red, color.green, color.blue, 0);
  
        /* load raster image if it is a 'R' line */
        if (lflag == 'R')
        {
          trace("loading raster image ...\n", 0, 0, 0, 0);
          pos = GetCurrentLayer();
  
          if (LoadRasterImage(filename))
          { 
            XtSetArg (AL[0], XmNset, &senddata);
            XtGetValues(widget_array[v_load_box_picture_button], AL, 1);
            if (senddata)
            {
/*            fprintf(stderr,"*** Load: %d sending picture data: %s\n", 
                      ownUserNumber, filename);                                 */
              SendRasterFile(filename, TO_ALL); 
            }
            else
            {
              if (loadrel)
              {
                /* send filename relative to SP_PIC_PATH */
                strcpy(cfilename, filename);
                tempp1 = strrchr(mfilename, '/');
                if (tempp1 != NULL)
                {
                  strncpy(filename, mfilename, tempp1 - mfilename + 1);
                  filename[tempp1 - mfilename + 1] = '\0';
                  strcat(filename, cfilename);
        
                }
              }
/*            fprintf(stderr,"*** Load: %d sending file name: %s\n", 
                      ownUserNumber, filename);                                 */
              msg_load_pic (filename);
            }
          }
          SetCurrentLayer(pos);
        }
        else /* it is an 'O' line: load layer */
        {
          trace("loading layer file ...\n", 0, 0, 0, 0);
          lay = GetNextLayer();
          if (lay == NULL)
          {
            /* add new layer */
            lay = add_lay (layername, True);
          }
          else
          {
            /* set layer name */
            rename_layer (lay, layername);
          }
          GetLayerId (lay, &layer_id, &sketch_id);
          strcpy(lfilename,PicPath);
          strcat(lfilename,filename);
  
          LoadLayer(layer_id, sketch_id, lfilename);
          XSync(theDisplay, False);
          /* set layer color */
          SetLayerColor(lay, color); 
          msg_set_layer_color(layer_id, sketch_id,
                              color.red, color.green, color.blue);
        }
      }
      fclose(mfp);
    }
    else
    {
      /* load selected layer */
      lay = GetFirstLayer ();
      while (lay != NULL)
      {
        if (GetLayerState (lay) & LS_LOAD)
        {
          something_loaded = True;
          GetLayerId (lay, &layer_id, &sketch_id);
          if ((layer_id == 1) && (sketch_id == 0))
          {
            /* send message to all other users */
  
            if (LoadRasterImage (cfilename))
            {
              XtSetArg (AL[0], XmNset, &senddata);
              XtGetValues(widget_array[v_load_box_picture_button], AL, 1);
              if (senddata)
              {
/*              fprintf(stderr, "*** Load: %d sending picture data: %s\n",
                        ownUserNumber, cfilename);                              */
                SendRasterFile(cfilename, TO_ALL);
              }
              else
              {
                if (!loadrel)
                {
                  sperror("Load: Warning: Picture should be located in a Path "
                          "relative to SP_PIC_PATH.");
                  sprintf(text,"      Using \"%s\" as filename for Load Message.",
                          mfilename);
                  sperror(text);
                }
/*              fprintf(stderr,"*** Load: %d sending file name: %s\n",
                        ownUserNumber, mfilename);                              */
                msg_load_pic (mfilename);
              }
            }
          }
          else
          {
            LoadLayer(layer_id, sketch_id, path);
          }
        }
        lay = GetNextLayer ();
      }
    }
    if (!something_loaded)
      sperror("Load: nothing to load!");
  }

  if (why == SLIDE_BOX)
  {
    /* send message to all other users */
    if (LoadRasterImage (cfilename))
    {
      if (!loadrel)
      {
        sperror("Load: Warning: Picture should be located in a Path "
                "relative to SP_PIC_PATH.");
        sprintf(text,"      Using \"%s\" as filename for Load Message.",
                mfilename);
        sperror(text);
      }
      msg_load_pic (mfilename);
    }
  }

  strcpy(PicPath, OPicPath);
  strcpy(OPicPath, "\0");

  return(1);
} /* Load */




/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  Save                                                     */
/*                                                                            */
/*      Version   :  06.06.1991                                               */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  Save selected parts of session                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  Main Program of Sketchpad                                */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int Save(char *path)
{
  FILE            *mfp;
  layer           lay;
  int             layer_id, sketch_id;

  char            masterfile[256];
  char            filename[256]; 
  char            mffilename[256];
  char            *layername;
  char            *tempp1;
  char            pathname[256];

  Arg AL[1];
 
  int    saveall = False;
  int    saveallvis = False;
  int    something_saved = False;

  int currsize    = True;

  XColor        color;

  int    i;
  int    filecount = 0;
  char   text[256];

  sprintf(masterfile,""); sprintf(filename,""); sprintf(mffilename,"");

  XSync(theDisplay, False);

  /* look what is to be saved */
  XtSetArg (AL[0], XmNset, &saveall);
  XtGetValues(widget_array[v_save_box_all_button], AL, 1);
  if (saveall)
  {
    trace("Save all.\n", 0, 0, 0, 0); 
  }
  else
  {
    XtSetArg (AL[0], XmNset, &saveallvis);
    XtGetValues(widget_array[v_save_box_all_visible_button], AL, 1);
    if (saveallvis)
    {
      trace("Save all visible.\n", 0, 0, 0, 0); 
    }
  }

  if (saveall || saveallvis)
  {
    /* make up file name */
    (void) strcpy(masterfile, NPath(path));
    (void) strcat(masterfile, ".sess");

    trace("Path: %s\n", path, 0, 0, 0); 
    trace("Master: %s\n", masterfile, 0, 0, 0); 
    mfp = fopen(masterfile, "w");
    if (!mfp)
    {
      /* try to create directory */
      tempp1 = strrchr(masterfile, '/');
      strncpy(pathname, masterfile, tempp1 - masterfile);
      pathname[tempp1 - masterfile] = '\0';
      if (MakePath(pathname) == 0)
      {
        if (!(mfp = fopen(masterfile, "w")))
        {
          sperror("Save: Cannot open master file.");
          return(0);
        }
      }
      else
      {
        return(0);
      }
    }
    fprintf(mfp, "C: *** Sketchpad Session File ***\n");
  }

  i = 1;
  lay = GetFirstLayer ();
  while (lay != NULL)
  {
    if (saveall || (saveallvis && (GetLayerState(lay) & LS_VISIBLE)) ||
        ((!saveall) && (!saveallvis) && (GetLayerState(lay) & LS_SAVE)))
    {
      something_saved = True;
      strcpy (filename,path);
      if (saveall || saveallvis)
      {
        /* make up layer filename */
        sprintf(filename,"%s.%d", path, i);
      }
      trace("Layer: %s\n", filename, 0, 0, 0);
      GetLayerId (lay, &layer_id, &sketch_id);
      if ((layer_id == 1) && (sketch_id == 0))
      {
        layername = GetLayerCharName(lay);
        if (WriteRasterImage (filename, format, currsize, colorstyle))
        { 
          if (saveall || saveallvis)
          {
            filecount++;

            /* filename of background layer is stored in masterfile */
            /* without directory because all files of one session   */
            /* have to be placed in the same directory              */
            tempp1 = strrchr(filename, '/');
            if (tempp1 != NULL)
              tempp1++;
            else
              tempp1 = filename;
            strcpy(mffilename, tempp1);

            fprintf(mfp,"R: <%s> \"%s\" #%d #%d #%d\n",
                    mffilename, layername, 4711, 4711, 4711);
          }
        }
        else
        {
          sprintf(text, "Save: Warning: layer %s not written.",
                  layername);
          sperror(text); 
        }
      }
      else
      {
        if (WriteLayer(lay, filename))
        {
          layername = GetLayerCharName(lay);
          color.pixel = GetLayerColor(lay);
          XQueryColor(theDisplay, theCmap, &color);
          if (saveall || saveallvis)
          {
            filecount++;

            /* filename of layer is stored in masterfile            */
            /* without directory because all files of one session   */
            /* have to be placed in the same directory              */
            tempp1 = strrchr(filename, '/');
            if (tempp1 != NULL)
              tempp1++;
            else
              tempp1 = filename;
            strcpy(mffilename, tempp1);

            fprintf(mfp,"O: <%s> \"%s\" #%d #%d #%d\n",
                    mffilename, layername,
                    (int) color.red, (int) color.green, (int) color.blue);
          }
        }
        else
        {
          sprintf(text, "Save: Warning: layer %s not written.",
                  layername);
          sperror(text); 
        }
      }
      i++;
    }
    lay = GetNextLayer ();
  }

  if (saveall || saveallvis)
  {
    if (filecount == 0)
    {
      sperror("Save: Warning: No layers and no session saved.");
      unlink(masterfile);
    }
    else
      fclose(mfp);
  }
  if (!something_saved)
    sperror("Save: nothing to save");
  return(1);
} /* Save */




/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  SendRasterFile()                                         */
/*                                                                            */
/*      Version   :  18.07.1991                                               */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  Send Raster File to Start Process                        */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  User Module                                              */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int SendRasterFile(char *cpath, int to)
{
  char path[256];
  FILE *fp;
  struct stat buf;
  void *picbuf;
  struct_storage ss;
  int r;

  strcpy(path, PicPath);
  strcat(path, cpath);

/*  fprintf(stderr,"*** Send: %d: sending rasterfile %s ...\n", 
          ownUserNumber, path);                                               */

  if (stat (path, &buf) != 0)
  {
    sperror("SendRasterFile: File to send not found.");
    return(False);
  }
  picbuf = (void *) malloc (buf.st_size);

  fp = fopen (path, "r");
  if (!fp)
  {
    sperror("SendRasterFile: Cannot open rasterfile.");
    return(False);
  }

  r = fread (picbuf, 1, buf.st_size, fp);
/*  fprintf(stderr, "*** Send: %d: ... %d bytes read.\n", ownUserNumber, r);  */
  msg_pic_to_load(ownUserNumber, r, picbuf, cpath, to);

  fclose (fp);
  return(True);
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  SaveRasterFile()                                         */
/*                                                                            */
/*      Version   :  23.07.1991                                               */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  Store received rasterfile in local file system           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  User Module                                              */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int SaveRasterFile(char *picbuf, int size, char *cpath)
{
  char path[256];
  FILE *fp;
  struct stat buf;
  struct_storage ss;
  int w;
  char *tempp1;
  char pathname[256];

  strcpy(path, PicPath);
  strcat(path, cpath);

/*  fprintf(stderr,"*** Save: %d: storing rasterfile %s ...\n", 
          ownUserNumber, path);                                               */

  if (( fp = fopen (path, "w" )) == NULL )
  {
    /* try to create directory */
    tempp1 = strrchr(path, '/');
    strncpy(pathname, path, tempp1 - path);
    pathname[tempp1 - path] = '\0';
    if (MakePath(pathname) == 0)
    {
      if (!(fp = fopen(path, "w")))
      {
        sperror("SaveRasterFile: Cannot open new rasterfile for writing.");
        return(0);
      }
    }
    else
    {
      return(0);
    }
  }
/* fprintf(stderr,"*** Save: %d: writing new picture file.\n", ownUserNumber);*/
  w = fwrite(picbuf, 1, size, fp);
  fclose(fp);
/* fprintf(stderr, "*** Save: %d: ... %d bytes written.\n", ownUserNumber, w);*/
  return(1);
}

