/* ========================================================================== */
/*                                                                            */
/* Filename:     jpegio.c                         +-----+-----+--+--+--+--+   */
/* Version :     1.2	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/8/92	13:59:10	                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*                                                                            */
/* Some parts of the program have originally been taken from the xv Program   */
/* developed by the University of Pennsylvania, which is the reason for the   */
/* following Copyright notice to be shown.                                    */
/*                                                                            */
/* LoadJFIF Author: Markus Baur, University of Karlsruhe                      */
/*                  (s_baur@iravcl.ira.uka.de)                                */
/* This software is provided "as is" without any express or implied warranty. */
/*                                                                            */
/* Portions Copyright 1989, 1990, 1991, 1992 by John Bradley and              */
/*                                The University of Pennsylvania              */
/*                                                                            */
/* Permission to use, copy, and distribute for non-commercial purposes,       */
/* is hereby granted without fee, providing that the above copyright          */
/* notice appear in all copies and that both the copyright notice and this    */
/* permission notice appear in supporting documentation.                      */
/*                                                                            */
/* The software may be modified for your own purposes, but modified versions  */
/* may not be distributed.                                                    */
/*                                                                            */
/* This software is provided "as is" without any expressed or implied         */
/* warranty.                                                                  */
/*                                                                            */
/* The author may be contacted via:                                           */
/*    US Mail:   John Bradley                                                 */
/*               GRASP Lab, Room 301C                                         */
/*               3401 Walnut St.                                              */
/*               Philadelphia, PA  19104                                      */
/*                                                                            */
/*    Phone:     (215) 898-8813                                               */
/*    EMail:     bradley@cis.upenn.edu                                        */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Module    : jpegio.c - i/o routines for 'jpeg' format pictures        */
/*                                                                            */
/*      Functions :                                                           */
/*           LoadJFIF(fname, numcols) - loads a JPEG pic,                     */
/*                                      does 24to8 code if nec.               */
/*           WriteJFIF(fp, pic, w, h, rmap, gmap, bmap, numcols, colorstyle)  */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include "picio.h"
#include "jpeg/jinclude.h"
#include <setjmp.h>
#include <malloc.h>

/* ========================================================================== */
/*      DEFINE STATEMENTS                                                     */
/* ========================================================================== */

/* ========================================================================== */
/*      FORWARD DECLARATIONS                                                  */
/* ========================================================================== */

static void jselwxv();
       int WriteJFIF();


/* ========================================================================== */
/*      GLOBAL VARIABLES                                                      */
/* ========================================================================== */

static byte        *pic24;
static long         filesize;
static jmp_buf      jmpState;
static boolean      greyscale;
static char         formatStr[80];
static byte        *CurImagePtr;
static int          colorType;
static byte        *image8,
                   *image24;

static struct external_methods_struct   e_methods;


/******************************************************************************/
/******************** INTERFACE CODE FOR THE JPEG LIBRARY *********************/
/******************************************************************************/

/*********************** JPEG DECOMPRESSION FUNCTIONS *************************/

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : output_init()                                             */
/*                                                                            */
/*      Version   : 18.03.1992                                                */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static void output_init (decompress_info_ptr cinfo)
{
  pWIDE = cinfo->image_width;
  pHIGH = cinfo->image_height;

  if (cinfo->out_color_space == CS_GRAYSCALE) 
  {
    pic = (byte *) malloc(pWIDE * pHIGH);
    if (!pic) 
    {
      fprintf(stderr,"output_init: Not enough memory for Image.\n");
      exit(1);
    }
    CurImagePtr = pic;
  }
  else
  {
    pic24 = (byte *) malloc(pWIDE * pHIGH * 3);
    if (!pic24) 
    {
      fprintf(stderr,"output_init: Not enough memory for Image.\n");
      exit(1);
    }
    CurImagePtr = pic24;
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : put_color_map()                                           */
/*                                                                            */
/*      Version   : 18.03.1992                                                */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static void put_color_map (decompress_info_ptr cinfo, int num_colors,
                           JSAMPARRAY colormap)
{
  /* never done, because we let picio quantize colors */
  fprintf(stderr, "put_color_map: this should never have happened.\n");
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : put_pixel_rows()                                          */
/*                                                                            */
/*      Version   : 18.03.1992                                                */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static void put_pixel_rows (decompress_info_ptr cinfo, int num_rows,
                            JSAMPIMAGE pixel_data)
{
  JSAMPROW ptr0, ptr1, ptr2;
  long col;
  long width = cinfo->image_width;
  int row;
  static unsigned int totrows = 0;

  if (cinfo->out_color_space == CS_GRAYSCALE) 
  {
    for (row = 0; row < num_rows; row++)
    {
      ptr0 = pixel_data[0][row];
      for (col = width; col > 0; col--)
      {
        *CurImagePtr++ = GETJSAMPLE(*ptr0++);
      }
      totrows++;
    }
  }

  else
  {
    for (row = 0; row < num_rows; row++)
    {
      ptr0 = pixel_data[0][row];
      ptr1 = pixel_data[1][row];
      ptr2 = pixel_data[2][row];
      for (col = width; col > 0; col--)
      {
        *CurImagePtr++ = GETJSAMPLE(*ptr0++);
        *CurImagePtr++ = GETJSAMPLE(*ptr1++);
        *CurImagePtr++ = GETJSAMPLE(*ptr2++);
      }
      totrows++;
    }
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : output_term()                                             */
/*                                                                            */
/*      Version   : 18.03.1992                                                */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static void output_term (decompress_info_ptr cinfo)
{
  /* no work required */
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : jselwxv()                                                 */
/*                                                                            */
/*      Version   : 18.03.1992                                                */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static void jselwxv(decompress_info_ptr cinfo)
{
  cinfo->methods->output_init = output_init;
  cinfo->methods->put_color_map = put_color_map;
  cinfo->methods->put_pixel_rows = put_pixel_rows;
  cinfo->methods->output_term = output_term;
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : d_ui_method_selection()                                   */
/*                                                                            */
/*      Version   : 18.03.1992                                                */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static void d_ui_method_selection(decompress_info_ptr cinfo)
{
  /* select output colorspace */
  if (cinfo->jpeg_color_space == CS_GRAYSCALE)
  {
    cinfo->out_color_space = CS_GRAYSCALE;
/*  SetISTR(ISTR_FORMAT,"Greyscale JPEG. (%ld bytes)", filesize); */
    greyscale = TRUE;
  }
  else
  {
    cinfo->out_color_space = CS_RGB;
/*  SetISTR(ISTR_FORMAT,"Color JPEG. (%ld bytes)", filesize); */
    greyscale = FALSE;
  }

  jselwxv(cinfo);
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : JPEG_Error()                                              */
/*                                                                            */
/*      Version   : 18.03.1992                                                */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static void JPEG_Error (char *msgtext)
{
  char tempstr[200];

  sprintf(tempstr, msgtext,
          e_methods.message_parm[0], e_methods.message_parm[1],
          e_methods.message_parm[2], e_methods.message_parm[3],
          e_methods.message_parm[4], e_methods.message_parm[5],
          e_methods.message_parm[6], e_methods.message_parm[7]);
  sperror(tempstr);
  longjmp(jmpState,1);
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : JPEG_Message()                                            */
/*                                                                            */
/*      Version   : 18.03.1992                                                */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static void JPEG_Message (char *msgtext)
{
  char tempstr[200];

  sprintf(tempstr, msgtext,
          e_methods.message_parm[0], e_methods.message_parm[1],
          e_methods.message_parm[2], e_methods.message_parm[3],
          e_methods.message_parm[4], e_methods.message_parm[5],
          e_methods.message_parm[6], e_methods.message_parm[7]);
  sperror(tempstr);
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  LoadJFIF()                                               */
/*                                                                            */
/*      Version   :  18.03.1992                                               */
/*                                                                            */
/*      Purpose   :  loads a JPEG pic, does 24to8 code if nec.                */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  LoadRasterImage() in picio.c                             */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int LoadJFIF(char *fname, int nc)
{
  int i, rtval;
  struct decompress_info_struct    cinfo;
  struct decompress_methods_struct dc_methods;

  /* Set up longjmp for error recovery out of JPEG_Error */
  rtval = setjmp(jmpState);
  if (rtval)
    return rtval;               /* no cleanup attempted -- may be a problem */

  /* Set up the input file */

  if ((cinfo.input_file = fopen(fname, "r")) == NULL) 
    return 1;

  /* figure out the file size (for Informational Purposes Only) */
  fseek(cinfo.input_file, 0L, 2);
  filesize = ftell(cinfo.input_file);
  fseek(cinfo.input_file, 0L, 0);

  cinfo.output_file = NULL;     /* only wanna read */
 
  /* Initialize the system-dependent method pointers. */
  cinfo.methods  = &dc_methods;
  cinfo.emethods = &e_methods;
  e_methods.error_exit = JPEG_Error; /* provide my own error/message rtns */
  e_methods.trace_message = JPEG_Message;
  e_methods.trace_level = 0;    /* no tracing, thank you */
  jselvirtmem(&e_methods);      /* memory allocation routines */
  dc_methods.d_ui_method_selection = d_ui_method_selection;

  /* Set up default JPEG parameters. */
  j_d_defaults(&cinfo, TRUE);

  /* Set up to read a JFIF or baseline-JPEG file. */
  /* A smarter UI would inspect the first few bytes of the input file */
  /* to determine its type. */
  jselrjfif(&cinfo);
 
  /* Do it! */
  jpeg_decompress(&cinfo);

  if (greyscale)
  {
    /* fill in a greyscale colormap */
    for (i=0; i<=255; i++) r[i] = g[i] = b[i] = i;
  }
  else
  {
    /* Convert to 8 bits depth and free 24 Bit Image */
    Conv24to8(pic24, pWIDE, pHIGH, nc);
    free(pic24);
  };

  /* Release memory. */
  j_d_free_defaults(&cinfo, TRUE);

  /* Close input file */
  fclose(cinfo.input_file);
 
  sprintf(formatStr, "%dx%d %s JPEG. ", cinfo.image_width, cinfo.image_height,
          (cinfo.out_color_space == CS_GRAYSCALE) ? "Greyscale " : "Color ");
 
  /* Got it! */
  return 0;
} /* LoadJFIF */




/*********************** JPEG COMPRESSION FUNCTIONS ***************************/


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  input_init()                                             */
/*                                                                            */
/*      Version   :  26.03.1992                                               */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static void input_init (compress_info_ptr cinfo)
{
  if (colorType == GREYSCALE)
  {
    cinfo->input_components = 1;
    cinfo->in_color_space = CS_GRAYSCALE;
    CurImagePtr = image8;
  }
  else
  {
    cinfo->input_components = 3;
    cinfo->in_color_space = CS_RGB;
    CurImagePtr = image24;
  }

  cinfo->image_width  = eWIDE;
  cinfo->image_height = eHIGH;
  cinfo->data_precision = 8;
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  get_input_row()                                          */
/*                                                                            */
/*      Version   :  26.03.1992                                               */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static void get_input_row(compress_info_ptr cinfo, JSAMPARRAY pixel_row)
{
  JSAMPROW ptr0, ptr1, ptr2;
  long col;
  static unsigned int totrows = 0;

  if (cinfo->input_components == 1)
  {
    ptr0 = pixel_row[0];
    for (col = cinfo->image_width; col > 0; col--)
    {
      *ptr0++ = *CurImagePtr++;
    }
    totrows++;
  }

  else
  {
    ptr0 = pixel_row[0];
    ptr1 = pixel_row[1];
    ptr2 = pixel_row[2];
    for (col = cinfo->image_width; col > 0; col--)
    {
      *ptr0++ = *CurImagePtr++;
      *ptr1++ = *CurImagePtr++;
      *ptr2++ = *CurImagePtr++;
    }
    totrows++;
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  input_term()                                             */
/*                                                                            */
/*      Version   :  26.03.1992                                               */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static void input_term (compress_info_ptr cinfo)
{
  /* no work required */
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  jselrxv()                                                */
/*                                                                            */
/*      Version   :  26.03.1992                                               */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static void jselrxv(compress_info_ptr cinfo)
{
  cinfo->methods->input_init = input_init;
  cinfo->methods->get_input_row = get_input_row;
  cinfo->methods->input_term = input_term;
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  c_ui_method_selection()                                  */
/*                                                                            */
/*      Version   :  26.03.1992                                               */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static void c_ui_method_selection(compress_info_ptr cinfo)
{
  /* select output colorspace */
  if (colorType == GREYSCALE)
  {
    j_monochrome_default(cinfo);
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  WriteJFIF                                                */
/*                                                                            */
/*      Version   :  26.03.1992                                               */
/*                                                                            */
/*      Purpose   :  get the internal image into a format that the            */
/*                   JPEG software can grok on.                               */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int  WriteJFIF(FILE *fp, byte *inpic, int wi, int hi,
               byte *rin, byte *gin, byte *bin, int ncols, int colorstyle,
               int quality)
{
  int i;
  register byte *ip, *ep;
  int rtval;
  struct compress_info_struct    cinfo;
  struct compress_methods_struct c_methods;

  /* Set up longjmp for error recovery out of JPEG_Error */
  rtval = setjmp(jmpState);
  if (rtval)
    return rtval;               /* no cleanup attempted -- may be a problem */
 
  /* Save Colorstyle */
  colorType = colorstyle;

  /* monocity check.  if the image is mono, save it that way to save space */
  if (colorType != GREYSCALE)
  {
    for (i=0; i<ncols && rin[i]==gin[i] && rin[i]==bin[i]; i++);
    if (i==ncols) colorType = GREYSCALE;    /* made it all the way through */
  }

  /* first thing to do is build an 8/24-bit Greyscale/TrueColor image
     (meaning: non-colormapped) */

  if (colorType == GREYSCALE) 
  {   /* build an 8-bit Greyscale image */
    image8 = (byte *) malloc(eWIDE * eHIGH);
    if (!image8) 
    {
      fprintf(stderr,"output_init: Not enough memory for Image.\n");
      exit(1);
    }

    for (i=0,ip=image8,ep=inpic; i<eWIDE * eHIGH; i++, ip++, ep++)
      *ip = MONO(rin[*ep], gin[*ep], bin[*ep]);
  }
  else /* colorType = some color format */
  {
    image24 = NULL;
    if (colorType == FULL_COLOR) image24 = Smooth24();
    if (!image24) 
    {  /* smoothing didn't/not tried.  Use 'stupid' method */
      image24 = (byte *) malloc(eWIDE * eHIGH * 3);
      if (!image24)
      {  /* this simply isn't going to work */
        {
          fprintf(stderr,"output_init: Not enough memory for Image.\n");
          exit(1);
        }
      }
      for (i=0, ip=image24, ep=inpic; i<eWIDE*eHIGH; i++, ep++)
      {
        *ip++ = rin[*ep];
        *ip++ = gin[*ep];
        *ip++ = bin[*ep];
      }
    }
  }

  /* Initialize the system-dependent method pointers. */
  cinfo.methods  = &c_methods;
  cinfo.emethods = &e_methods;
  e_methods.error_exit = JPEG_Error; /* provide my own error/message rtns */
  e_methods.trace_message = JPEG_Message;
  e_methods.trace_level = 0;    /* no tracing, thank you */
  jselvirtmem(&e_methods);      /* memory allocation routines */
  c_methods.c_ui_method_selection = c_ui_method_selection;

  /* Set up default JPEG parameters. */
  j_c_defaults(&cinfo, quality, FALSE);

  /* Select input and output */
  cinfo.input_file  = NULL;
  cinfo.output_file = fp;       /* already open */
 
  jselrxv(&cinfo);              /* we'll be reading from memory */
  jselwjfif(&cinfo);            /* and writing to JFIF file format */

  /* Do it! */
  jpeg_compress(&cinfo);
 
  /* Release memory. */
  j_c_free_defaults(&cinfo);

  /* get rid of the greyscale/truecolor image */
  if (colorType == GREYSCALE) free(image8);
                         else free(image24);

  return 0;
}
