/* ========================================================================== */
/*                                                                            */
/* Filename:     tiff.h                           +-----+-----+--+--+--+--+   */
/*                                                !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Arbeitsgruppe         !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      ---------------------------------                     */
/*                                                                            */
/*      Creation Date        : 06.11.1990 by Miguel Encarnacao                */
/*      Last Modification    : 01.05.1991 by Markus Beyer                     */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Modification List    :                                                */
/*                                                                            */
/*      Date        Author      Modification made                             */
/*                                                                            */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Module    : tiff.h                                                    */
/*                                                                            */
/*      Functions : Headerfile for TIFF Load- and Save-Functions              */
/*                                                                            */
/* ========================================================================== */

#ifndef TIF_HEADERS

#define TIF_HEADERS

/**************** Type Definitions for Portability ***************************/

typedef char             char_t;
typedef short            short_t;
typedef int              int_t;
typedef long             long_t; 
#ifndef _AIX
  typedef unsigned char    uchar_t;
  typedef unsigned short   ushort_t;
  typedef unsigned int     uint_t;
  typedef unsigned long    ulong_t;
#endif _AIX
typedef float            float_t;
typedef double           double_t;
typedef uchar_t          boolean_t;

#ifndef PIC_HEADERS
typedef unsigned char byte;
#endif PIC_HEADERS

/**************** Return Codes are of Type INTEGER ***************************/

typedef long_t    rctif_t;


/**************** Global Types ************************************************/

typedef enum {		/* type of TIFF-Compression */
  INVALID_COMPRESSION,
  NO_COMPRESSION = 1,
  HUFFMANN,
  CCITT3,
  CCITT4,
  LZW,
  PACKBITS = 32773,
  MAX_COMPRESSION
} tifCompression_t;


typedef enum {		/* type of the TIFF-image */
  TIFF_INVALID,
  TIFF_B,
  TIFF_G,
  TIFF_P,
  TIFF_R,
  MAX_TIFF_TYPE
}  tifImageType_t;

typedef struct {	/* additonal information about the TIFF-file */
  int_t            byteOrder;
  tifImageType_t   tifType;
  tifCompression_t tifCompr;
} tifAddInfo_t;


/**************** Local TIFF Types ********************************************/

typedef enum {
		InvalidDataType,
		Byte=1,
		ASCII,
		Short,
		Long,
		Rational,
		MaxDataType
} tifDataTypes_t;

typedef enum {
		InvalidInterpretation = -1,
		GrayReverse,
		GrayNormal,
		RGB,
		PaletteColor,
		TranspMask,
		MaxInterpretation
} tifPhotoInterpret_t;

typedef	enum {
		InvalidPeriodicity,
		PixelPeriodicity = 1,
		FieldPeriodicity,
		MaxPeriodicity
} tifPeriod_t;

/**************** Local TIFF Types (not yet used) *****************************/
/*
typedef enum {
		NotAbsolute = 1,
		Inch,
		Centimeter
} tifResUnit_t;


typedef enum {
		HighBitsFirst=1,
		LowBitsFirst
} tifOrderToFill_t;


typedef enum {
		FullResolution=1,
		ReducedResolution,
		SinglePage
} tifTypeOfSubfile_t;

typedef enum {
		TopLeft=1,
		TopRight,
		BottomRight,
		BottomLeft,
		LeftTop,
		RightTop,
		RightBottom,
		LeftBottom
} tifTypeOfOrientation_t;

typedef enum {
		Bilevel=1,
		Dithered,
		Error_diffused
} tifThreshhold_t;
*/


/**************** Other Local Types *******************************************/

typedef	struct {
	ushort_t	tag;
	tifDataTypes_t	type;
	ulong_t		length;
	long_t		value;
	ulong_t		offset;
	char		*pointer;
	boolean_t	used;
} tifDirEntry_t;

typedef struct {
  byte       red,
             green,
             blue;      /* colors of the LUT */
} tifColor_t;

typedef struct {
  int_t      size;      /* size of the LUT */
  tifColor_t *color;
  boolean_t  *used;     /* indicates if color[i] was used in FILE-rasterdata */
} tifCmap_t;

typedef struct {                                    /* Describes a picture */
  int_t          width,
                 height,            /* Size of picture */
                 depth;             /* Bits per pixel */
  tifImageType_t type;              /* type of Image */
  uchar_t        *data;             /* Pointer to image data */
  tifCmap_t      *cmap;             /* Pointer to image look up table */ 
} ipi_image_t;

typedef struct {                                /* Describes a picture */
    int_t   width,
            height,             /* Size of picture */
            depth;              /* Bits per pixel */
    byte *data;              /* Pointer to image aera */
} tifImage_t;

typedef enum {
	NO_DIR_ENTRY=-1,    /* recognize tag order !! */
	IMAGE_WIDTH,
	IMAGE_LENGTH,
	BITS_PER_SAMPLE,
	COMPRESSION,
	PHOTO_INTERPRET,
	STRIP_OFFSETS,
	SAMPLES_PER_PIXEL,
	ROWS_PER_STRIP,
	STRIP_BYTE_COUNTS,
	PLANAR_CONFIG,
	SOFTWARE,
	DATE_TIME,
	COLOR_MAP,
	MAX_DIR_ENTRIES	    /* always last member */
} tifDirContents_t;


/**************** Praeprozessor-Anweisungen ***********************************/

#define	FIELD2PIXEL_INTERL

#define	TIF_TRACE_OFF

#define	TIF_TRACE_TO_SCREEN


/****************Trace-Praeprozessor-Anweisungen ******************************/

#ifdef TIF_TRACE_OFF
#undef TIF_TRACE_ON
#undef TIF_TRACE_TO_SCREEN
#undef TIF_TRACE_TO_FILE
#endif

#ifdef	TIF_TRACE_ON

#ifdef	  TIF_TRACE_TO_FILE
#undef	    TIF_TRACE_TO_SCREEN
#else	  !TIF_TRACE_TO_FILE

#ifdef		TIF_TRACE_TO_SCREEN	
#undef		  TIF_TRACE_TO_FILE 
#endif		TIF_TRACE_TO_SCREEN

#endif    !TIF_TRACE_TO_FILE

#else	!TIF_TRACE_ON

#undef	  TIF_TRACE_TO_FILE
#undef	  TIF_TRACE_TO_SCREEN

#endif	!TIF_TRACE_ON


/**************** Macros ******************************************************/

#define	No_uchar	((uchar_t *) NULL)
#define	No_char		((char_t *)  NULL)
#define	No_short	((short_t *) NULL)
#define No_ushort       ((ushort_t *) NULL)
#define No_ulong	((ulong_t *) NULL)

#define	SizeOfType(x)	((x==Byte||x==ASCII) ? sizeof (char_t) :(\
			 (x==Short) ? sizeof (short_t) :(        \
			 (x==Long)  ? sizeof (long_t)  :(        \
			 (x==Rational) ? 2*sizeof (long_t) : 0)))\
			)

#define ValidDataType(x)	(((int)(x) > (int)InvalidDataType)&&\
				 ((int)(x) < (int)MaxDataType))	
	
#define ValidInterpretation	(((int)(x) > (int)InvalidInterpretation)&&\
				 ((int)(x) < (int)MaxInterpretation))	
	
#define ValidPeriodicity(x)	(((int)(x) > (int)InvalidPeriodicity)&&\
				 ((int)(x) < (int)MaxPeriodicity))	
	
#define ValidDirContents(x)	(((int)(x) > (int)NO_DIR_ENTRY)&&\
				 ((int)(x) < (int)MAX_DIR_ENTRIES))	
	

/**************** Definitions *************************************************/

#define MAXLUTSIZE		256
#define MAX_STRIP_SIZE          8192    /* 8 kB */

#define	FALSE	0
#ifndef TRUE
#define	TRUE	!FALSE
#endif  TRUE

#define	SEEK_SET	0	/* Origins for fseek */
#define	SEEK_CUR	1
#define	SEEK_END	2

#define VERSION		42
#define	SoftwareText	"X Window System Ver.X11 Rel.4"


/**************** Global Variables ********************************************/

tifDirEntry_t	dir_entries[MAX_DIR_ENTRIES];

boolean_t	MM,		/* Most  Significant Byte First */
		II;     	/* Least Significant Byte First */

ulong_t		actual_IFD,	/* Pointer in files for i/o */
		in_IFD_region,
		in_offset_region,
		in_strip_region;

FILE	*tf;            	/* Pointer to TIFF-File */

#ifdef	TIF_TRACE_TO_FILE
FILE	*tif_trace;		/* Pointer to TIFF-Trace-File */
#endif	TIF_TRACE_TO_FILE

/******************************************************************************/

#define	MinTagNumber			254


/* TIFF-Tags */

#define NewSubfileType			254
#define	SubfileType			255
#define	ImageWidth			256
#define	ImageLength			257
#define	BitsPerSample			258
#define	Compression			259

#define	PhotometricInterpretation	262
#define	Threshholding			263
#define	CellWidth			264
#define	CellLength			265
#define	FillOrder			266

#define	DocumentName			269
#define	ImageDescription		270
#define	Make				271
#define	Model				272
#define	StripOffsets			273
#define	Orientation			274

#define	SamplesPerPixel			277
#define	RowsPerStrip			278
#define	StripByteCounts			279
#define	MinSampleValue			280
#define	MaxSampleValue			281
#define	XResolution			282
#define	YResolution			283
#define	PlanarConfiguration		284
#define	PageName			285
#define	XPosition			286
#define	YPosition			287
#define	FreeOffsets			288
#define	FreeByteCounts			289
#define	GrayResponseUnit		290
#define	GrayResponseCurve		291
#define	Group3Options			292
#define	Group4Options			293

#define	ResolutionUnit			296
#define	PageNumber			297

#define	ColorResponseCurves		301

#define	Software			305
#define	DateTime			306

#define	Artist				315
#define HostComputer			316
#define	Predictor			317
#define	WhitePoint			318
#define	PrimaryChromaticities		319
#define	ColorMap			320


#define	MaxTagNumber			320

/* #ifdef __STDC__ */

#if 1 /* the above condition leads to some problems ... */
/*********************** tifmisc.c ********************************************/

extern	int_t		lhToI ( uchar_t[2] );
extern	long_t		chToL (uchar_t *);
extern	double_t	chToD (uchar_t *),
			anyToD (uchar_t *, tifDataTypes_t );
extern	char_t		*sToCh (ushort_t),
			*lToCh ( ulong_t  ),
			*anyToCh (char_t *, tifDataTypes_t );

extern	int		tiff_ftop_interl (tifImage_t *, ushort_t );
extern	int		tiff_gray_to_RRR (tifImage_t *);

/* extern  void	        TifTrace(char_t *, ulong_t, ulong_t, ulong_t);	*/
extern	void	        TifTrace();	

#else  /* using non-ANSI cc. Function defs, but no params */

/*********************** tifmisc.c ********************************************/

extern	int_t		lhToI ();
extern	long_t		chToL ();
extern	double_t	chToD (),
			anyToD ();
extern	char_t		*sToCh (),
			*lToCh (),
			*anyToCh ();
extern	int		tiff_ftop_interl ();
extern	int		tiff_gray_to_RRR ();

extern	void	        TifTrace();	

/* #endif __STDC__ */
#endif 1

#endif !TIF_HEADERS
