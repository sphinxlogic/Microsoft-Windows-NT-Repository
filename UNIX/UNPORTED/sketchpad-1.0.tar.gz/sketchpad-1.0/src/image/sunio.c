/* ========================================================================== */
/*                                                                            */
/* Filename:      sunio.c                         +-----+-----+--+--+--+--+   */
/* Version :     1.4	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/15/92	10:43:42	                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include "picio.h"
extern char* XtMalloc();


/* ========================================================================== */
/*      DEFINE STATEMENTS                                                     */
/* ========================================================================== */

# undef DEBUG

# define FALSE 0
# if defined(sun) || defined(vax)
#   define TRUE !FALSE
# endif
#define TRUE 1

/* Data Type for Sun Picture File Header */
typedef struct
{
  unsigned long int  magic;
  unsigned long int  width;
  unsigned long int  height;
  unsigned long int  depth;
  unsigned long int  length;
  unsigned long int  type;
  unsigned long int  cmtype;
  unsigned long int  cmlength;
} sun_header;

/* ========================================================================== */
/*      FORWARD DECLARATIONS                                                  */
/* ========================================================================== */

static int SunError(char *);
static int sun_read_header(FILE *, long int *, long int *, long int *,
                           long int *, long int *);
static int sun_read_colortable(FILE *, long int);
static int sun_write_header(FILE *, long int, long int, long int, long int);
static int sun_write_colortable(FILE *, long int, byte[256][3]);

/* ========================================================================== */
/*      GLOBAL VARIABLES                                                      */
/* ========================================================================== */

static byte bw[2] = {0, 0xFF};

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : LoadSUN()                                                 */
/*                                                                            */
/*      Version   : 03.04.1991                                                */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int LoadSUN(fname,nc)
     char *fname;
     int   nc;

{
  FILE    *input;
  long int     width, height;
  long int     length;
  long int     cmtype;
  long int     nofcols;
  byte         colortable[256][3];
  int          row;
  byte         *temppic;

  /*
   * open picture file
   */
  input = fopen (fname, "r");
  trace("LoadSUN: opening file \"%s\"\n", fname, 0, 0, 0);
  if (input == NULL)
  {
    SunError("LoadSUN: error open file!");
    return 1;
  }

  /*
   * read file header
   */
  if (!sun_read_header (input, &width, &height, &length, &cmtype, &nofcols))
  {
    SunError("LoadSUN: bad header in picture file.");
    return 1;
  }
  pWIDE = width;
  pHIGH = height;
  
  /*
   * check colormap type
   */
  if (cmtype != 1)
  {
    SunError("LoadSUN: this type of colormap is not supported!");
    return 1;
  }

  /*
   * read color table
   */
  if (!sun_read_colortable (input, nofcols))
  {
    SunError("LoadSUN: error reading colortable!");
    return 1;
  }

  /*
   * read picture data
   */
  pic = (byte *) XtMalloc ((length + 1) * sizeof (byte));
  if (!pic)
  {
    sperror("LoadSUN: unable to malloc!");
    exit(1);
  }

  temppic = pic;
  for (row = 0; row < height; row++)
  {
    fread ((byte *) temppic, sizeof (*pic), (width + (width % 2)) , input);
    temppic += width;
  }
  return(0); 
}



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  WriteSUN()                                               */
/*                                                                            */
/*      Version   :  21.05.1991                                               */
/*                                                                            */
/*      Purpose   :  Write Raster Image to Sun Pixrect File                   */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  WriteRasterImage()                                       */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int WriteSUN(fp, thepic, w, h, r, g, b, numcols, colorstyle)
FILE   *fp;
byte   *thepic;
int    w, h;
byte   *r, *g, *b;
int    numcols;
int    colorstyle;
{
  byte  cmap[256][3];
  int   i;
  byte  tc;
  int   rv;
  int   row;
  byte  *temppic;

  /* if writing B/W stipple ... */
  if (colorstyle == BW_STIPPLE)
  {
    r = g = b = bw;
    numcols = 2;
  }

  /* Write SUN-Header */
  sun_write_header(fp, w, h, 1, numcols);

  /* Write Colortable */
  if (colorstyle == GREYSCALE)
  /* Have to do color conversion before storing */
  {
    for (i = 0; i < numcols; i++)
    {
      tc = MONO(r[i], g[i], b[i]);
      cmap[i][0] = tc;
      cmap[i][1] = tc;
      cmap[i][2] = tc;
    }
  }
  else
  {
    for (i = 0; i < numcols; i++)
    {
      cmap[i][0] = r[i];
      cmap[i][1] = g[i];
      cmap[i][2] = b[i];
    }
  }
  sun_write_colortable(fp, numcols, cmap);

  /* Finally write Picture Data */
  temppic = thepic;
  for (row = 0; row < h; row++)
  {
    rv = fwrite((byte *) temppic, sizeof (*thepic), w + (w % 2), fp);
    if (rv < (w + (w % 2)))
    {
      sperror("WriteSUN: Error writing Picture Data!");
      return(1);
    }
    temppic += w;
  }

  return(0);
}



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  SunError()                                               */
/*                                                                            */
/*      Version   :  03.04.1991                                               */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static int SunError(char *st)
{
  sperror(st);
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  sun_read_header                                          */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  read the header of a sun picture file                    */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  the I/O routines of sketchpad                            */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static int sun_read_header (FILE *file, long int *width, long int *height,
                            long int *length, long int *cmtype,
                            long int *colornum) 
{
  sun_header           head;
  long int             i;
  unsigned long int    *longword;

  (void) fread ((char *) &head, sizeof (sun_header), 1, file);

  /****************************************************************************
  * converting integer representation from MC68020 cpu to KA650 cpu           *
  ****************************************************************************/

  longword = (unsigned long int *) &head;

# ifdef vax
  for (i = 1; i <= (sizeof (sun_header) / 4); i ++)
  {
    unsigned long int  b1, b2, b3, b4;

    b1 = (*longword) >> 24 & 0x000000ff;
    b2 = (*longword) >>  8 & 0x0000ff00;
    b3 = (*longword) <<  8 & 0x00ff0000;
    b4 = (*longword) << 24 & 0xff000000;
    *longword = b1 | b2 | b3 | b4;
    longword ++;
  }
# endif

# ifdef DEBUG
    (void) printf ("magic-number ..... %10x \n", head.magic);
    (void) printf ("picture width .... %10ld \n", head.width);
    (void) printf ("picture height ... %10ld \n", head.height);
    (void) printf ("picture depth .... %10ld \n", head.depth);
    (void) printf ("length ........... %10ld \n", head.length);
    (void) printf ("type ............. %10ld \n", head.type);
    (void) printf ("colormap type .... %10ld \n", head.cmtype);
    (void) printf ("colormap length .. %10ld \n", head.cmlength);
# endif

  if ((head.magic == 0x59a66a95) && (head.type == 1))
  {
    *width    = head.width;
    *height   = head.height;
    *length   = head.length;
    *cmtype   = head.cmtype;
    *colornum = head.cmlength / 3;
    return (TRUE);
  }
  else
  {
    return (FALSE);
  }
} /* End of sun_read_header */



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  sun_read_colortable                                      */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  read the colortable of a sun picture file                */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  the I/O routines of sketchpad                            */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static int sun_read_colortable (FILE *file, long int noc)
{
  long int  i;

  for (i = 0; i < noc; i ++)
    r[i] = (byte) fgetc (file);
  for (i = 0; i < noc; i ++)
    g[i] = (byte) fgetc (file);
  for (i = 0; i < noc; i ++)
    b[i] = (byte) fgetc (file);
  return(1);

} /* End of sun_read_colortable */



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  sun_write_header                                         */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  write the header of a sun picture file                   */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  the I/O routines of sketchpad                            */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static int sun_write_header (FILE *file, long int width, long int height,
                             long int cmtype, long int colornum) 
{
  sun_header           head;
  long int             i;
  unsigned long int    *longword;

  head.magic    = 0x59a66a95L;
  head.width    = width;
  head.height   = height;
  head.depth    = 8L;
  head.length   = width * height;
  head.type     = 1L;
  head.cmtype   = cmtype;
  head.cmlength = colornum * 3;

  /****************************************************************************
  * converting integer representation from MC68020 cpu to KA650 cpu           *
  ****************************************************************************/

  longword = (unsigned long int *) &head;

# ifdef vax
  for (i = 1; i <= (sizeof (sun_header) / 4); i ++)
  {
    unsigned long int register b1, b2, b3, b4;

    b1 = (*longword) >> 24 & 0x000000ff;
    b2 = (*longword) >>  8 & 0x0000ff00;
    b3 = (*longword) <<  8 & 0x00ff0000;
    b4 = (*longword) << 24 & 0xff000000;
    *longword = b1 | b2 | b3 | b4;
    longword ++;
  }
# endif

  (void) fwrite ((char *) &head, sizeof (sun_header), 1, file);

} /* End of sun_write_header */



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  sun_write_colortable                                     */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  write the colortable of a sun picture file               */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  the I/O routines of sketchpad                            */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static int sun_write_colortable (FILE *file, long int noc, byte table[256][3])
{
  long int register i, j;

  for (j = 0; j < 3; j ++)
  {
    for (i = 0; i < noc; i ++)
    {
      fputc ((char) table[i][j], file); 
    }
  }
} /* End of sun_write_colortable */

/* End of sunio.c */
