/* ========================================================================== */
/*                                                                            */
/* Filename:     picgam.c                         +-----+-----+--+--+--+--+   */
/* Version :     1.2	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/8/92	13:59:18	                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*                                                                            */
/* Some parts of the program have originally been taken from the xv Program   */
/* developed by the University of Pennsylvania, which is the reason for the   */
/* following Copyright notice to appear in this file                          */
/*                                                                            */
/* Copyright 1989, 1990 by the University of Pennsylvania                     */
/*                                                                            */
/* Permission to use, copy, and distribute for non-commercial purposes,       */
/* is hereby granted without fee, providing that the above copyright          */
/* notice appear in all copies and that both the copyright notice and this    */
/* permission notice appear in supporting documentation.                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Module    : picgam.c Gamma Correction handling functions              */
/*                                                                            */
/*      Functions :                                                           */
/*   GenerateFSGamma()      -  called to generate floyd steinberg correction  */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include "picio.h"

/* ========================================================================== */
/*      DEFINE STATEMENTS                                                     */
/* ========================================================================== */

#define NUMHANDS 4

/* ========================================================================== */
/*      GLOBAL VARIABLES                                                      */
/* ========================================================================== */

static void spline(int *, int *, int, float *);


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : GenerateFSGamma()                                         */
/*                                                                            */
/*      Version   : 01.10.1991                                                */
/*                                                                            */
/*      Purpose   : this function generates the Floyd-Steinberg gamma curve   */
/*                  (fsgamcr)                                                 */
/*   This function generates a 4 point spline curve to be used as a           */
/*   non-linear grey 'colormap'.  Two of the points are nailed down at 0,0    */
/*   and 255,255, and can't be changed.  You specify the other two.  If       */
/*   you specify points on the line (0,0 - 255,255), you'll get the normal    */
/*   linear reponse curve.  If you specify points of 50,0 and 200,255, you'll */
/*   get grey values of 0-50 to map to black (0), and grey values of 200-255  */
/*   to map to white (255) (roughly).  Values between 50 and 200 will cover   */
/*   the output range 0-255.  The reponse curve will be slightly 's' shaped.  */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
void GenerateFSGamma()
{
  int i,j;
  static int x[4] = {0,32,224,255};
  static int y[4] = {0, 0,255,255};
  float yf[4];
  static float splint();

  spline(x, y, 4, yf);
  
  for (i=0; i<256; i++) {
    j = (int) splint(x, y, yf, 4, (float) i);
    if (j<0) j=0;
    else if (j>255) j=255;
    fsgamcr[i] = j;
  }
}



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  spline(x,y,n,y2)                                         */
/*                                                                            */
/*      Version   :  01.10.1991                                               */
/*                                                                            */
/*      Purpose   :                                                           */
/*        given arrays of data points x[0..n-1] and y[0..n-1], computes the   */
/*        values of the second derivative at each of the data points          */
/*        y2[0..n-1] for use in the splint function                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static void spline(int *x, int *y, int n, float *y2)
{
  int i,k;
  float p,qn,sig,un,u[NUMHANDS];

  y2[0] = u[0] = 0.0;

  for (i=1; i<n-1; i++) {
    sig = ((float) x[i]-x[i-1]) / ((float) x[i+1] - x[i-1]);
    p = sig * y2[i-1] + 2.0;
    y2[i] = (sig-1.0) / p;
    u[i] = (((float) y[i+1]-y[i]) / (x[i+1]-x[i])) - 
           (((float) y[i]-y[i-1]) / (x[i]-x[i-1]));
    u[i] = (6.0 * u[i]/(x[i+1]-x[i-1]) - sig*u[i-1]) / p;
  }
  qn = un = 0.0;

  y2[n-1] = (un-qn*u[n-2]) / (qn*y2[n-2]+1.0);
  for (k=n-2; k>=0; k--)
    y2[k] = y2[k]*y2[k+1]+u[k];
}



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  splint(xa,ya,y2a,n,x)                                    */
/*                                                                            */
/*      Version   :                                                           */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static float splint(xa, ya, y2a, n, x)
float y2a[],x;
int n,xa[],ya[];
{
  int klo,khi,k;
  float h,b,a;

  klo = 0;
  khi = n-1;
  while (khi-klo > 1) {
    k = (khi+klo) >> 1;
    if (xa[k] > x) khi = k;
    else klo = k;
  }
  h = xa[khi] - xa[klo];
  if (h==0.0) fprintf(stderr,"bad xvalues in splint\n");
  a = (xa[khi]-x)/h;
  b = (x-xa[klo])/h;
  return (a*ya[klo] + b*ya[khi] + ((a*a*a-a)*y2a[klo] +(b*b*b-b)*y2a[khi])
          * (h*h) / 6.0);
}
   

