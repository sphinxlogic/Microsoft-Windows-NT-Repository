/* ========================================================================== */
/*                                                                            */
/* Filename:     tiffwio.c                        +-----+-----+--+--+--+--+   */
/* Version :     1.2	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/8/92	13:59:39	                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*                                                                            */
/*      Module    : tifwio.c                                                  */
/*                                                                            */
/*      Functions : (rctif_t)   initDirEntries                                */
/*                  (rctif_t)   putValues                                     */
/*                  (rctif_t)   putStrips                                     */
/*                  (rctif_t)   putHeader                                     */
/*                  (rctif_t)   putIFD                                        */
/*                  (int)       packBits1                                     */
/*                                                                            */
/*                  (rctif_t)   WriteTIFF (export)                            */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <stdio.h>
#include <math.h>

#include "picio.h"
#include "tiff.h"
/* #include <X11/Intrinsic.h> */

/* ========================================================================== */
/*      FORWARD DECLARATIONS                                                  */
/* ========================================================================== */

/* ========================================================================== */
/*      GLOBAL VARIABLES                                                      */
/* ========================================================================== */

static	ulong_t	rows_per_strip;


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : packBits1()                                               */
/*                                                                            */
/*      Version   : 02.10.1991                                                */
/*                                                                            */
/*      Purpose   : Pack each 8 bytes of buf_data to one byte                 */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by : putStrips()                                               */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int packBits1(char_t *buf_data, ulong_t row_size, ulong_t size)
{
  ulong_t   i, j;
  uchar_t   temp;
  char_t    *unpptr,
            *pckptr;
  ulong_t   x_count,
            b_count;

  unpptr = buf_data;
  pckptr = buf_data;
  x_count = 0;
  b_count = 0;
  temp    = 0;

  for (i = 0; i < size; i++)
  {
    /* insert bit */
    temp += (unpptr[x_count] << (7 - b_count));
    x_count += 1;
    b_count += 1;
    if (b_count == 8)
    {
      b_count = 0;
      pckptr[(x_count / 8) - 1] = temp;
      temp = 0;
    }
    if (x_count == row_size)
    {
      /* line full: write bit */
      if (b_count != 0)
      {
        /* byte has not been written */
        pckptr[row_size / 8] = temp;
        pckptr += (row_size / 8) + 1;
      }
      else
      {
        /* byte has already been written */
        pckptr += (row_size / 8);
      }
      unpptr += row_size;
      b_count = 0;
      x_count = 0;
      temp = 0;
    }
  }
  return(1);
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : initDirEntries                                            */
/*                                                                            */
/*      Version   : 11.09.1991                                                */
/*                                                                            */
/*      Purpose   : initialize directory entries according to given image type*/
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by : putIFD                                                    */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
rctif_t initDirEntries (ipi_image_t *image, tifAddInfo_t *info)
{
  int_t	i;

  for (i=0; i<(int_t)MAX_DIR_ENTRIES; i++)
  {
    dir_entries[(tifDirContents_t)i].length  = (ulong_t)1;
    dir_entries[(tifDirContents_t)i].value   = (long_t)0;
    dir_entries[(tifDirContents_t)i].offset  = (ulong_t)0;
    dir_entries[(tifDirContents_t)i].pointer = (char_t *)NULL;
    dir_entries[(tifDirContents_t)i].used    = FALSE;
  }

  /* Directory Entries in order of Tag Value */

  dir_entries[IMAGE_WIDTH].tag    = ImageWidth;
  dir_entries[IMAGE_WIDTH].type   = Long;
  dir_entries[IMAGE_WIDTH].value  = (long_t)image->width;
  dir_entries[IMAGE_WIDTH].used   = TRUE;
	
  dir_entries[IMAGE_LENGTH].tag    = ImageLength;
  dir_entries[IMAGE_LENGTH].type   = Long;
  dir_entries[IMAGE_LENGTH].value  = (long_t)image->height;
  dir_entries[IMAGE_LENGTH].used   = TRUE;

  dir_entries[BITS_PER_SAMPLE].tag    = BitsPerSample;
  dir_entries[BITS_PER_SAMPLE].type   = Short;

  dir_entries[COMPRESSION].tag    = Compression;
  dir_entries[COMPRESSION].type   = Short;
  dir_entries[COMPRESSION].value  = (long_t)info->tifCompr;
  dir_entries[COMPRESSION].used   = TRUE;

  dir_entries[PHOTO_INTERPRET].tag    = PhotometricInterpretation;
  dir_entries[PHOTO_INTERPRET].type   = Short;

  dir_entries[STRIP_OFFSETS].tag  = StripOffsets;
  dir_entries[STRIP_OFFSETS].type = Long;

  dir_entries[SAMPLES_PER_PIXEL].tag  = SamplesPerPixel;
  dir_entries[SAMPLES_PER_PIXEL].type = Short;

  dir_entries[ROWS_PER_STRIP].tag    = RowsPerStrip;
  dir_entries[ROWS_PER_STRIP].type   = Long;
  dir_entries[ROWS_PER_STRIP].used   = TRUE;

  dir_entries[STRIP_BYTE_COUNTS].tag   = StripByteCounts;
  dir_entries[STRIP_BYTE_COUNTS].type  = Long;

  dir_entries[PLANAR_CONFIG].tag   = PlanarConfiguration;
  dir_entries[PLANAR_CONFIG].type  = Short;

  dir_entries[SOFTWARE].tag    = Software;
  dir_entries[SOFTWARE].length = (ulong_t)(strlen (SoftwareText) );
  dir_entries[SOFTWARE].type   = ASCII;

  dir_entries[DATE_TIME].tag  = DateTime;
  dir_entries[DATE_TIME].type = Long;

  dir_entries[COLOR_MAP].tag  = ColorMap;
  dir_entries[COLOR_MAP].type = Short;

  switch (info->tifType)
  {
    case TIFF_R:
      dir_entries[SAMPLES_PER_PIXEL].value = (long_t)3;
      dir_entries[SAMPLES_PER_PIXEL].used  = TRUE;
      dir_entries[BITS_PER_SAMPLE].length  = (ulong_t)3;
      dir_entries[BITS_PER_SAMPLE].value   = (long_t)image->depth/3;
      dir_entries[PLANAR_CONFIG].value     = (long_t)PixelPeriodicity;
      dir_entries[PLANAR_CONFIG].used      = TRUE;
      dir_entries[PHOTO_INTERPRET].value   = (long_t)RGB;
      dir_entries[PHOTO_INTERPRET].used    = TRUE;
      break;

    case TIFF_P:
      dir_entries[SAMPLES_PER_PIXEL].value = (long_t)1;
      dir_entries[SAMPLES_PER_PIXEL].used  = TRUE;
      dir_entries[BITS_PER_SAMPLE].length  = (ulong_t)1;
      dir_entries[BITS_PER_SAMPLE].value   = (long_t)image->depth;
      dir_entries[PHOTO_INTERPRET].value   = (long_t)PaletteColor;
      dir_entries[PHOTO_INTERPRET].used    = TRUE;
      break;

    case TIFF_B:
      dir_entries[SAMPLES_PER_PIXEL].value = (long_t)1;
      dir_entries[SAMPLES_PER_PIXEL].used  = TRUE;
      dir_entries[BITS_PER_SAMPLE].length  = (ulong_t)1;
      dir_entries[BITS_PER_SAMPLE].value   = (long_t)1;
      dir_entries[PHOTO_INTERPRET].value   = (long_t)GrayNormal;
      dir_entries[PHOTO_INTERPRET].used    = TRUE;
      break;

    case TIFF_G:
      dir_entries[SAMPLES_PER_PIXEL].value = (long_t)1;
      dir_entries[SAMPLES_PER_PIXEL].used  = TRUE;
      dir_entries[BITS_PER_SAMPLE].length  = (ulong_t)1;
      dir_entries[BITS_PER_SAMPLE].value   = (long_t)image->depth;
      dir_entries[PHOTO_INTERPRET].value   = (long_t)GrayNormal;
      dir_entries[PHOTO_INTERPRET].used    = TRUE;
      break;

    default:
      TifTrace ("*** ERROR: Illegal image type ! ***\n");
      return (1);
  }
  return (0);
} /* initDirEntries */ 		


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : putValues                                                 */
/*                                                                            */
/*      Version   : 11.09.1991                                                */
/*                                                                            */
/*      Purpose   : write values to TIFF file                                 */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by : putIFD                                                    */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
rctif_t putValues (tifDataTypes_t tp, ulong_t value_offset, ulong_t length,
                   char_t *ptr)
{
  ulong_t  val,
           val2;
  ushort_t sval;
  int_t    size,
           i;
  char_t   *ch,
           *c;

  if (!ValidDataType (tp))
    return (1);

  size = SizeOfType (tp);

  if ((size * length)<=4)
  {		 /* offset zeigt in Header -> direkter Wert */
    (void)fseek (tf, in_IFD_region, SEEK_SET);
    if (tp==Short && length==1)
    {
      sval = (ushort_t)value_offset;
      c = (char_t *)&sval;
    }
    else
      c = (char_t *)&value_offset;
    for (i=0; i<length; i++)
    {
      if ((ch = anyToCh (&c[i*size], tp)) != No_char)
      {
        (void)fwrite (ch, size, 1, tf);
        (void)free (ch);
        ch = No_char;
      }
      else
        return (1);
    }
    val = 0x00;
    for (i=size*length; i<4; i++)        /* mit 0-Bytes auffuellen */
      (void)fwrite (&val, 1, 1, tf);
    in_IFD_region = (ulong_t)ftell (tf);
  }
  else
  { 			 /* offset zeigt in Offset-Bereich */
    (void)fseek (tf, in_IFD_region, SEEK_SET); /* offset eintragen */
    if ((ch = anyToCh ((char_t *)&in_offset_region, Long)) == No_char)
      return (1);
    (void)fwrite (ch, 1, sizeof(ulong_t), tf);
    (void)free (ch);
    ch = No_char;
    in_IFD_region = (ulong_t)ftell (tf);
                                      /* an offset-adresse Werte eintragen */
    (void)fseek (tf, in_offset_region, SEEK_SET);
    if (ptr == No_char)
    {
      TifTrace("*** ERROR : wrong data type ! -- Abort ***\n");
      return (1);
    }
    else
    {
      if (size > sizeof (char_t))
      {
        val = size * length;
        val2 = (ulong_t)0;
        for (i=0; i<val; i+=size)
        {
          ch = anyToCh (&ptr[i], tp);
	  if (ch == No_char) /* Nullen 'rausschreiben */
	    ch = anyToCh ((char_t *)&val2, tp);
          (void)fwrite (ch, 1, size, tf);
          (void)free (ch);
          ch = No_char;
        }
      }
      else
        (void)fwrite (ptr, size, length, tf);

    }
    if (ptr != No_char)
    {
      (void)free (ptr);
      ptr = No_char;
    }
    in_offset_region = (ulong_t)ftell (tf);
  }
  return (0);
} /* putValues */



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : putStrips                                                 */
/*                                                                            */
/*      Version   : 11.09.1991                                                */
/*                                                                            */
/*      Purpose   : write picture data to TIFF file                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by : putIFD                                                    */
/*                                                                            */
/*      Calls     : (long_t) chToL     (module tiffmisc.c)                    */
/*                  (rctif_t) tif_comp_strip_lzw () (module tifflzw.c)       */
/*                                                                            */
/* ========================================================================== */
rctif_t putStrips (ulong_t nr_of_strips, char_t *data)
{
  ulong_t nr_of_bytes,
          buf_ptr,
          row_size,
          data_size;
  int_t   size_s,
          size_b,
          i;
  char_t  *ptr,
          *buf_data;
  rctif_t ret;

  buf_data = No_char;
  buf_ptr  = 0;

  if (dir_entries[STRIP_OFFSETS].used     &&
      dir_entries[STRIP_BYTE_COUNTS].used &&
      nr_of_strips > 0)
  {
    size_s = SizeOfType (dir_entries[STRIP_OFFSETS].type);
    size_b = SizeOfType (dir_entries[STRIP_BYTE_COUNTS].type);

    if (dir_entries[BITS_PER_SAMPLE].value == (long_t)1)
    {
      /* Pack each 8 bits to one byte */
      buf_data = data;
      row_size = (ulong_t) dir_entries[IMAGE_WIDTH].value;
      /* generally correct, but wrong for our purpose */
/*      data_size = 0;                                                */
/*      for (i=0; i<nr_of_strips; i++)                                */
/*      {                                                             */
/*        ptr = &(dir_entries[STRIP_BYTE_COUNTS].pointer[i*size_b]);  */
/*        data_size += *((ulong_t *)ptr);                             */
/*      }                                                             */
      data_size = dir_entries[IMAGE_WIDTH].value *
                  dir_entries[IMAGE_LENGTH].value;
      /* convert data */
      if (!packBits1(buf_data, row_size, data_size))
      {
        sperror("WriteTIFF: could not do bit packing, sorry");
        return(1);
      }
    }

    if (nr_of_strips > 1)	
      for (i=0; i<nr_of_strips; i++)
      {
                                             /* in Strip-Region positionieren */
      (void)fseek (tf, in_strip_region, SEEK_SET);
                                             /* Adresse merken (fuer offset)  */
      *((ulong_t *)&(dir_entries[STRIP_OFFSETS].pointer[i*size_s])) = 	
      in_strip_region;
                                           /* Strip 'rausschreiben          */
      ptr         = &(dir_entries[STRIP_BYTE_COUNTS].pointer[i*size_b]);
      nr_of_bytes = *((ulong_t *)ptr);

      switch (dir_entries[COMPRESSION].value)
      {
        case LZW:
          if ((ret=tiff_comp_strip_lzw (data, nr_of_bytes, &buf_data,
                                        &nr_of_bytes)) != 0)
            return (ret);
          (void)fwrite (buf_data, nr_of_bytes, 1, tf);
          if (buf_data != No_char)
          {
            (void)free (buf_data);
             buf_data = No_char;
          }
          break;

        case NO_COMPRESSION:
        default:
          buf_data = &data[buf_ptr];
          (void)fwrite (buf_data, nr_of_bytes, 1, tf);
          buf_ptr += nr_of_bytes;
          break;
      }

                                             /* neue Adresse ermitteln        */
      in_strip_region = ftell (tf) +
                        sizeof (long_t);     /* Sicherheitsabstand */
    }
    else  /* nr_of_strips == 1 */
    {
      /* in Strip-Region positionieren */
      (void)fseek (tf, in_strip_region, SEEK_SET);
      /* Adresse merken (fuer offset)  */
      dir_entries[STRIP_OFFSETS].value = in_strip_region;
                                             /* Strip 'rausschreiben          */
      nr_of_bytes = (ulong_t)dir_entries[STRIP_BYTE_COUNTS].value;

      switch (dir_entries[COMPRESSION].value)
      {
        case LZW:
          if ((ret=tiff_comp_strip_lzw (data, nr_of_bytes, &buf_data,
                                        &nr_of_bytes)) != 0)
            return (ret);
          (void)fwrite (buf_data, nr_of_bytes, 1, tf);
          if (buf_data != No_char)
          {
            (void)free (buf_data);
            buf_data = No_char;
          }
          break;

        case NO_COMPRESSION:
        default:
          buf_data = data;
          (void)fwrite (buf_data, nr_of_bytes, 1, tf);
          break;
      }
    }

    return (0);
  }
  else
    return (1);
} /* putStrips */



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : putHeader                                                 */
/*                                                                            */
/*      Version   : 11.09.1991                                                */
/*                                                                            */
/*      Purpose   : write TIFF header into TIFF file                          */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by : (rctif_t) WriteTIFF                                       */
/*                                                                            */
/*      Calls     : (int_t)   lhToI ()                                        */
/*                  (long_t)  chToL ()                                        */
/*                  (char *)  lToCh ()                                        */
/*                                                                            */
/* ========================================================================== */
rctif_t putHeader ()
{
  uchar_t    tif_header[4];
  uchar_t    *offset;

  if (!(II ^ MM))
  {
    /* Error wrong header */
    TifTrace("*** ERROR : wrong byte order, file can not be written ! ***\n");
    exit(0);
  }

  tif_header[0] =
  tif_header[1] = II ? 'I' : 'M';
  tif_header[2] = II ? (char_t)VERSION : (char_t)0;
  tif_header[3] = II ? (char_t)0       : (char_t)VERSION;

  (void)fwrite (tif_header, 1, 4, tf);
	
  TifTrace("\tByte Order :%c%c\n",tif_header[0],tif_header[1]);
  TifTrace("\tVersion    :%d\n",VERSION);

  actual_IFD = (ulong_t)(ftell (tf) + sizeof(ulong_t));
  offset     = (uchar_t *)lToCh (actual_IFD);	
  if (offset == No_uchar)
    return (1);
  (void)fwrite (offset, sizeof(ulong_t), 1, tf);
  (void)free (offset);
  offset = No_uchar;

  return (0);
} /* putHeader */



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : putIFD                                                    */
/*                                                                            */
/*      Version   : 11.09.1991                                                */
/*                                                                            */
/*      Purpose   : write one XImage data structure into TIFF file            */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by : (rctif_t) WriteTIFF                                       */
/*                                                                            */
/*      Calls     : (rctif_t) putStrips ()                                    */
/*                  (rctif_t) putValues ()                                    */
/*                  (rctif_t) initDirEntries ()                               */
/*                                                                            */
/* ========================================================================== */
rctif_t putIFD (ipi_image_t *image, tifCmap_t *x_lut, tifAddInfo_t *info)
{
  tifDataTypes_t  tp;
  tifImageType_t  raster_type;
  tifPeriod_t     periodicity;

  rctif_t         ret;
  ulong_t         length,
                  max_lut,
                  strips_per_image,
                  i,
                  strip_size,
                  strip_res_size,
                  row_size,
                  raster_length,
                  val,
                  value_or_offset,
                  data_size;
  char_t          *ptr,
                  *ec,
                  *tag,
                  *typ,
                  *len;
  int_t           j, k;
  ushort_t        entry_count,
                  buf,
                  nr_of_ch;
  ushort_t        *tiff_lut,
                  *bits_per_sample;


  raster_type    = info->tifType;

  ret = initDirEntries (image, info);
  if (ret != 0)
    return (ret);
  nr_of_ch = dir_entries[SAMPLES_PER_PIXEL].value;

  /* Limit strip size to MAX_STRIP_SIZE */
  if (raster_type == TIFF_R) 
  {
    periodicity      = (tifPeriod_t)dir_entries[PLANAR_CONFIG].value;
    if (!ValidPeriodicity (periodicity))
      return (1);
  }
  buf = ((raster_type==TIFF_R) && (periodicity==FieldPeriodicity)) ?
        1 : nr_of_ch;
  raster_length    = (ulong_t)ceil ((image->height*
                                     image->width *
                                     dir_entries[BITS_PER_SAMPLE].value*
                                     buf)
                                     /8.0);
  row_size = image->width*buf*dir_entries[BITS_PER_SAMPLE].value/8.0;
  rows_per_strip   = MAX_STRIP_SIZE/row_size;
  rows_per_strip   = (rows_per_strip > 0) ? rows_per_strip : 1;
  strip_size       = rows_per_strip * row_size;
  i                = 0;
  strips_per_image = 0;
  while (i+strip_size <= raster_length)
  {
    i += strip_size;
    strips_per_image++;
  }
  if (i < raster_length)
  {
    strips_per_image++;
    if (raster_type == TIFF_B)
    {
      data_size = dir_entries[IMAGE_WIDTH].value *
                  dir_entries[IMAGE_LENGTH].value;
      strip_res_size = data_size-i;
    }
    else
    {
      strip_res_size = raster_length-i;
    }
  }
  else
    strip_res_size = strip_size;

  if (raster_type == TIFF_R) 
  {
    if (periodicity == FieldPeriodicity)
      strips_per_image *= nr_of_ch;
  }

  dir_entries[ROWS_PER_STRIP].value  = (long_t)rows_per_strip;


  /*** Belegung der IFD-Entries **************************************/


  length = nr_of_ch;
  bits_per_sample = (ushort_t *)malloc ((uint_t)(length*sizeof(short_t)));
  if (bits_per_sample == No_ushort)
    return (1);
  for (i=0; i<length; i++)
    bits_per_sample[i] = (ushort_t)dir_entries[BITS_PER_SAMPLE].value;
  dir_entries[BITS_PER_SAMPLE].pointer = (char_t *)bits_per_sample;
  dir_entries[BITS_PER_SAMPLE].used    = TRUE;

  if (raster_type == TIFF_P)
  {
    max_lut = (1<<(ushort_t)bits_per_sample[0]);
    if (x_lut->color == (tifColor_t *)NULL)
    {
      TifTrace ("*** ERROR: Lut missing for Palette-Image ! ***\n");
      return (1);
    }
    else
    {
      tiff_lut = (ushort_t *)malloc ((uint_t)(max_lut*3*sizeof(ushort_t)));
      if (tiff_lut == No_ushort)
        return (1);

        for (i = 0; i<max_lut; i++)
        {
          tiff_lut[i]   = (ushort_t) x_lut->color[i].red; 
        }
        for (i = 0; i<max_lut; i++)
        {
          tiff_lut[i+max_lut]   = (ushort_t) x_lut->color[i].green; 
        }
        for (i = 0; i<max_lut; i++)
        {
          tiff_lut[i+(2*max_lut)]   = (ushort_t) x_lut->color[i].blue;
        }

      dir_entries[COLOR_MAP].length  = 3 * max_lut;
      dir_entries[COLOR_MAP].pointer = (char_t *)tiff_lut;
      dir_entries[COLOR_MAP].used    = TRUE;
    }
  }
  dir_entries[STRIP_OFFSETS].length  = strips_per_image;
  if (strips_per_image > 1)
    dir_entries[STRIP_OFFSETS].pointer =
    (char_t *)malloc ((uint_t)(sizeof(ulong_t)*strips_per_image));
  dir_entries[STRIP_OFFSETS].used    = TRUE;

  dir_entries[STRIP_BYTE_COUNTS].length  = strips_per_image;
  if (strips_per_image > 1)
  {
    dir_entries[STRIP_BYTE_COUNTS].pointer =
      (char_t *)malloc ((uint_t)(sizeof(ulong_t)*strips_per_image));
    if (dir_entries[STRIP_BYTE_COUNTS].pointer == No_char)
      return (1);
    if ((raster_type == TIFF_R) && (periodicity == FieldPeriodicity))
    {
      k = strips_per_image/nr_of_ch;
      for (i=0; i<k-1; i++)
        for (j=0; j<3; j++)
          *((ulong_t *)&(dir_entries[STRIP_BYTE_COUNTS].pointer[(k*j+i)*4]))=
             strip_size;
      for (j=0; j<3; j++)
        *((ulong_t *)&(dir_entries[STRIP_BYTE_COUNTS].pointer[(k*j+i)*4]))=
           strip_res_size;	
    }
    else
    {
      for (i=0; i<strips_per_image-1; i++)
        *((ulong_t *)&(dir_entries[STRIP_BYTE_COUNTS].pointer[i*4]))=
          strip_size;
      *((ulong_t *)&(dir_entries[STRIP_BYTE_COUNTS].pointer[i*4]))=
        strip_res_size;	
    }
  }
  else
    dir_entries[STRIP_BYTE_COUNTS].value = (image->width *
                                            image->height * nr_of_ch);
  dir_entries[STRIP_BYTE_COUNTS].used    = TRUE;
  
  length = dir_entries[SOFTWARE].length;
  dir_entries[SOFTWARE].pointer =
    (char_t *)malloc ((uint_t)(length*sizeof(char_t)));	
  if (dir_entries[SOFTWARE].pointer == No_char)
    return (1);
  strcpy (dir_entries[SOFTWARE].pointer, SoftwareText);
  dir_entries[SOFTWARE].used    = TRUE;
  
  /*
  length = dir_entries[DateTime].length;      ????
  dir_entries[DateTime].pointer =
    (char_t *)malloc ((uint_t)(length*sizeof(char_t)));	
  *dir_entries[DateTime].pointer = ????;
  dir_entries[DateTime].used    = TRUE;
  */

  /*** Ende: Belegung der IFD-Entries ******************************/


  /* Berechnung der Startpositionen in IFD- und Offset-Region */

  for (i=0, length=0, entry_count=0; i<(int_t)MAX_DIR_ENTRIES; i++)
    if (dir_entries[(tifDirContents_t)i].used)
    {
      entry_count++;
      length += dir_entries[(tifDirContents_t)i].length;
    }
  ec = sToCh (entry_count); 
  if (ec == No_char)
    return (1);
  (void)fwrite (ec, 1, sizeof(ushort_t), tf);
  (void)free (ec);
  ec = No_char;
  in_IFD_region = ftell (tf);
  val = (ulong_t)0;		   /* next IFD pointer = 0 */
  (void)fseek (tf, entry_count * 12, SEEK_CUR);
  (void)fwrite (&val, sizeof(ulong_t), 1, tf);
  (void)fseek (tf, in_IFD_region, SEEK_SET);

  in_offset_region = in_IFD_region +         /* Beginn des IFD     */
                     entry_count*12 + 4 +	   /* Laenge eines IFD   */
                     8;			   /* Sicherheitsabstand */

  /* Berechnung max. Laenge d. Offset-Region */

  length *= 8;	/* max. Typ-Size (Rational) */

  in_strip_region = in_offset_region + /* Beginn der Offset-Region  */
                    length +           /* max. Laenge Offset-Region */
                    8;		     /* Sicherheitsabstand        */

  /* 'Rausschreiben der Bilddaten (in Form von Strips)    */

  ret = putStrips (strips_per_image, (char_t *)image->data);

  /* 'Rausschreiben der verschiedenen DirEntries          */

  (void)fseek (tf, in_IFD_region, SEEK_SET);
  for (i=0; (i<(int_t)MAX_DIR_ENTRIES && (ret==0)); i++)
  {
    if (dir_entries[(tifDirContents_t)i].used)
    {
      value_or_offset = dir_entries[(tifDirContents_t)i].value |
                        dir_entries[(tifDirContents_t)i].offset;
      tp     = dir_entries[(tifDirContents_t)i].type;
      length = dir_entries[(tifDirContents_t)i].length;
      ptr    = dir_entries[(tifDirContents_t)i].pointer;
      tag	   = sToCh (dir_entries[(tifDirContents_t)i].tag);
      typ	   = sToCh ((ushort_t)tp);
      len	   = lToCh ((ulong_t)length);
      if ((tag == No_char)||(typ==No_char)||(len==No_char))
        return (1);
      (void)fseek (tf, in_IFD_region, SEEK_SET);
      (void)fwrite (tag, 1, sizeof(ushort_t), tf);
      (void)fwrite (typ, 1, sizeof(ushort_t), tf);
      (void)fwrite (len, 1, sizeof(ulong_t), tf);
      (void)free (tag);
      (void)free (typ);
      (void)free (len);
      in_IFD_region = ftell (tf);
      ret    = putValues (tp, value_or_offset, length, ptr);
      if (ret==1)	/* Wert ignorieren und        */
      {					/* tag,typ,len ueberschreiben */
        (void)fseek (tf, -sizeof(long_t)-2*sizeof(short_t), SEEK_CUR);
        ret = 0;
      }
    }
  }

  /* Allocierten  Speicherbereich freigeben               */

  for (i=0; i<(int_t)MAX_DIR_ENTRIES; i++)
  {
    if (dir_entries[(tifDirContents_t)i].pointer != No_char)
    {
      (void)free (dir_entries[(tifDirContents_t)i].pointer);
      dir_entries[(tifDirContents_t)i].pointer = No_char;
    }
  }
  return (ret);
} /* putIFD */



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : WriteTIFF()                                               */
/*                                                                            */
/*      Version   : 11.09.1991                                                */
/*                                                                            */
/*      Purpose   : Write TIFF Picture to File                                */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by : WriteRasterImage()                                        */
/*                                                                            */
/*      Calls     : (rctif_t) putHeader ()                                    */
/*                  (rctif_t) putIFD ()                                       */
/*                                                                            */
/* ========================================================================== */
int WriteTIFF(FILE *fp, byte *thepic, int w, int h,
              byte *r, byte *g, byte *b, int numcols, int colorstyle)
{
  rctif_t         ret;
  ipi_image_t     image;
  tifAddInfo_t    info;
  tifCmap_t       cmap;
  int             i;
 
  byte *tpic;

  tf = fp;
  tpic = thepic;

  image.width = (int_t) w;
  image.height = (int_t) h;

  info.byteOrder = LSBFirst;
  info.tifCompr  = NO_COMPRESSION;

  switch (colorstyle)
  {
    case FULL_COLOR:
      image.depth = (int_t) 8;
      image.type = (tifImageType_t) TIFF_P;
      cmap.size      = 256;
      cmap.color     = (tifColor_t *)malloc (cmap.size * sizeof(tifColor_t));
      if (cmap.color == (tifColor_t *)NULL)
      {
        sperror("WriteTIFF: unable to malloc color array ! ***\n");
        return (1);
      }
      cmap.used = (boolean_t *) NULL;
      for (i = 0; i < cmap.size; i++)
      {
        cmap.color[i].red   = r[i];
        cmap.color[i].green = g[i];
        cmap.color[i].blue  = b[i];
      }
      info.tifType   = TIFF_P;
      break;
    case GREYSCALE:
      image.depth = (int_t) 8;
      image.type = (tifImageType_t) TIFF_G;
      info.tifType   = TIFF_G;

      tpic = (byte *)malloc (w * h);
      if (tpic == (byte *) NULL)
      {
        sperror("WriteTIFF: unable to malloc temporary pic ! ***\n");
        return (1);
      }
      for (i = 0; i < w * h; i++)
      {
        tpic[i] = MONO(r[thepic[i]], g[thepic[i]], b[thepic[i]]);
      }
      break;
    case BW_STIPPLE:
      image.type = (tifImageType_t) TIFF_B;
      info.tifType   = TIFF_B;
      break;
    default:
      sperror ("WriteTIFF: This cannot happen.");
      break;
  }
  image.data = (uchar_t *) tpic;
  image.cmap = NULL;
 
#ifdef  TIF_TRACE_ON
#ifdef  TIF_TRACE_TO_FILE
  tif_trace = fopen ("tifWriteTrace.lst", "w");
#endif  TIF_TRACE_TO_FILE
#endif  TIF_TRACE_ON

  II = (info.byteOrder == LSBFirst);
  MM = (info.byteOrder == MSBFirst);

  ret = putHeader ();
  if (ret != 0)
  {
    free(tpic);
    return (ret);
  }
  ret = putIFD (&image, &cmap, &info);

#ifdef  TIF_TRACE_ON
#ifdef  TIF_TRACE_TO_FILE
  (void)fclose (tif_trace);
#endif  TIF_TRACE_TO_FILE
#endif  TIF_TRACE_ON

  free(tpic);
  return (ret);
} /* WriteTIFF */

