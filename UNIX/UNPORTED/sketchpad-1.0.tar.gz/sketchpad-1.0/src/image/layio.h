/* ========================================================================== */
/*                                                                            */
/* Filename:     layio.h                          +-----+-----+--+--+--+--+   */
/*                                                !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Arbeitsgruppe         !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      ---------------------------------                     */
/*                                                                            */
/*      Creation Date        :  14.05.1991 by Markus Beyer                    */
/*      Last Modification    :  14.05.1991 by Markus Beyer                    */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Modification List    :                                                */
/*                                                                            */
/*      Date        Author      Modification made                             */
/*                                                                            */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Module    :  layio.h                                                  */
/*                                                                            */
/*      Functions :  Header File for Layer I/O Functions                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*  DEFINE STATEMENTS                                                         */
/* ========================================================================== */

#undef DEBUG

#ifndef trace
#ifdef DEBUG
#define trace(v,w,x,y,z) fprintf(stderr, v, w, x, y, z);
#else
#define trace(v,w,x,y,z)
#endif DEBUG
#endif trace

/* ========================================================================== */
/*  INCLUDE STATEMENTS                                                        */
/* ========================================================================== */

#include "../ui/layer.h"

/* ========================================================================== */
/*  FORWARD DECLARATIONS                                                      */
/* ========================================================================== */

int LoadLayer(int, int, char *);
int WriteLayer(layer, char *);
