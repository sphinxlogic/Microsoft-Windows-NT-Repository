/* ========================================================================== */
/*                                                                            */
/* Filename:     picio.h                          +-----+-----+--+--+--+--+   */
/*                                                !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Arbeitsgruppe         !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      ---------------------------------                     */
/*                                                                            */
/*      Creation Date        :       08.03.1991 by Markus Beyer               */
/*      Last Modification    :       08.03.1991 by Markus Beyer               */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Modification List    :                                                */
/*                                                                            */
/*      Date        Author      Modification made                             */
/*                                                                            */
/*                                                                            */
/* ========================================================================== */

#ifndef PIC_HEADERS
#define PIC_HEADERS

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <stdio.h>
#include <math.h>
#include <ctype.h>
#include <string.h>

#include <X11/Xos.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/cursorfont.h>
#include <X11/keysym.h>

#include <sys/stat.h>
#include "../misc/sperror.h"

/* ========================================================================== */
/*      DEFINE STATEMENTS                                                     */
/* ========================================================================== */
/* file types that can be read */
#define UNKNOWN 0
#define GIF     1
#define PM      2
#define PBM     3
#define XBM     4
#define FSUN    5
#define TIFF    6
#define JPEG    7

/* colorstyles for saving */
#define FULL_COLOR 0
#define GREYSCALE  1
#define BW_STIPPLE 2

/* values 'epicmode' can take */
#define EM_RAW    0
#define EM_DITH   1
#define EM_SMOOTH 2

#undef DEBUG        /* Enable additional information output */

#ifndef MAIN
#define WHERE extern
#else
#define WHERE
#endif

#ifndef trace
#ifdef DEBUG
#define trace(v,w,x,y,z) fprintf(stderr, v, w, x, y, z);
#else
#define trace(v,w,x,y,z)
#endif DEBUG
#endif trace

typedef unsigned char byte;

/* MACROS */
#define CENTERX(f,x,str) ((x)-XTextWidth(f,str,strlen(str))/2)
#define CENTERY(f,y) ((y)-((f->ascent+f->descent)/2)+f->ascent)

/* RANGE forces a to be in the range b..c (inclusive) */
#define RANGE(a,b,c) { if (a<b) a=b;  if (a>c) a=c; }

/* PTINRECT returns '1' if x,y is in rect (inclusive) */
#define PTINRECT(x,y,rx,ry,rw,rh) \
           ((x)>=(rx) && (y)>=(ry) && (x)<=(rx)+(rw) && (y)<=(ry)+(rh))

/* MONO returns total intensity of r,g,b components */
#define MONO(rd,gn,bl) (((rd)*11 + (gn)*16 + (bl)*5) >> 5)  /*.33R+ .5G+ .17B*/

/* ========================================================================== */
/*      GLOBAL VARIABLES                                                      */
/* ========================================================================== */

/* X stuff */
WHERE unsigned int  ncells, dispWIDE, dispHIGH, dispDEEP;
WHERE Display       *theDisplay;
WHERE int           theScreen;
WHERE Window        theWindow;
WHERE Window        rootW;
WHERE Pixmap        thePixmap; 
WHERE XImage        *theImage;
WHERE Colormap      theCmap, LocalCmap;
WHERE GC            theGC;
WHERE unsigned long black, white, fg, bg;
WHERE Visual        *theVisual;

WHERE int           image_x0,
                    image_y0,
                    image_width,
                    image_height;

/* global vars used by LOAD routines */
WHERE byte          *pic;                   /* ptr to loaded picture */
WHERE unsigned int   pWIDE,pHIGH;           /* size of 'pic' */
WHERE byte           r[256],g[256],b[256];  /* colormap */
WHERE char          *cmd;                   /* program name for printf's */
WHERE int            mono;                  /* true if displaying grayscale */


/* more global variables, used by LoadRasterImage and picmisc */
WHERE byte          *cpic;         /* cropped version of pic */
WHERE unsigned int  cWIDE, cHIGH,  /* size of cropped region */
                    cXOFF, cYOFF;  /* offset of region from 0,0 of pic */

WHERE byte          *epic;         /* expanded version of cpic */
                                   /* points to pic when at 1:1 expansion */
                                   /* this is converted to 'theImage' */
WHERE unsigned int  eWIDE, eHIGH;  /* size of epic */
WHERE unsigned int  normFact;      /* factor to shrink picture by for 'norm' */

WHERE byte           rorg[256],gorg[256],borg[256];  /* ORIGINAL colormap */
WHERE byte           gamcr[256];   /* gamma correction curve */
WHERE byte           fsgamcr[256]; /* gamma correction curve (for FS dither) */

WHERE unsigned long freecols[256]; /* list of pixel values to free */
WHERE int           nfcols;        /* number of colors to free */
WHERE unsigned long cols[256];     /* maps pic pixel values to X pixel vals */
WHERE int           fc2pcol[256];  /* maps freecols into pic pixel values */
WHERE int           numcols;       /* # of desired colors in picture */
WHERE int           ncols;         /* max # of (different) colors to alloc */

WHERE int           expand,        /* expansion amount */
                     noglob,        /* force to only use colors it alloced */
                     revvideo,      /* reverse video */
                     perfect,       /* perfect color.  install own colormap */
                     fixedaspect,   /* fixed aspect ratio */
                     slow24,        /* use slow 24to8 algorithm */
                     rwcolor,       /* true if we should use R/W color cells */
                     rwthistime,    /* true if we DID use R/W color cells */
                     epicmode,      /* either SMOOTH, DITH, or RAW */
                     ninstall;
 
WHERE float         defaspect,     /* default aspect ratio to use */
                    normaspect;    /* normal aspect ratio of this picture */

WHERE int           crx1, cry1,    /* dimensions of cropping rectangle */
                    crx2, cry2;


#undef WHERE

#ifdef MAIN
char                PicPath[256] = "\0";
char                OPicPath[256] = "\0";
int                 format = TIFF;            /* format chosen by user */
int                 colorstyle = FULL_COLOR;  /* colorstyle chosen by user */
#else
extern char         PicPath[];
extern char         OPicPath[];
extern int          format;
extern int          colorstyle;
#endif


/* function declarations for externally-callable functions */

#ifdef __STDC__ 
/****************************** picio.c ***************************************/
int  InitPicio(Display *, Window); 
int  LoadRasterImage(char *);
void ClearRasterImage(void);
void RedrawRasterImage(XRectangle);
int  WriteRasterImage(char *, int, int, int);
void SetJPEGQuality(int newquality);
int  GetJPEGQuality(void);

/****************************** picmisc.c *************************************/
Window CreateWindow(char *, char *, unsigned int, unsigned int, 
		    unsigned long, unsigned long);
void Resize(int, int);
void SortColormap(void);
void AllocColors(void);
void AllocRWColors(void);
void DoMonoAndRV(void);
void FSDither(byte *, int, int, byte *);
void CreateXImage(void);
void FreeColors(void);

/****************************** smooth.c **************************************/
void  Smooth(void);
byte *Smooth24(void);
void ColorDither(byte *, int, int);

/****************************** picgam.c **************************************/
void GenerateFSGamma();

/****************************** con24to8.c ************************************/
int  Conv24to8(byte *, int, int, int);
void InitFSDTables(void);

/****************************** gifrio.c **************************************/
int LoadGIF(char *, int);

/****************************** gifwio.c **************************************/
int WriteGIF(FILE *, byte *, int, int, byte *, byte *, byte *, int, int);

/****************************** tiffrio.c *************************************/
int LoadTIFF(char *, int);

/****************************** tiffwio.c *************************************/
int WriteTIFF(FILE *, byte *, int, int, byte *, byte *, byte *, int, int);

/****************************** jpegio.c **************************************/
int  LoadJFIF(char *, int);
int  WriteJFIF(FILE *, byte *, int, int, byte *, byte *, byte *, int, int, int);
void CreateJPEGW(void);
void JPEGDialog(int);
int  JPEGCheckEvent(XEvent *);
void JPEGSaveParams(char *, int);

/****************************** pmio.c ****************************************/
int LoadPM(char *, int);
int WritePM(FILE *, byte *, int, int, byte *, byte *, byte *, int, int);

/****************************** pbmio.c ***************************************/
int LoadPBM(char *, int);
int WritePBM(FILE *, byte *, int, int, byte *, byte *, byte *, int, int, int);

/****************************** xbmio.c ***************************************/
int LoadXBM(char *, int);
int WriteXBM(FILE *, byte *, int, int, char *);

/****************************** sunio.c ***************************************/
int LoadSUN(char *, int);
int WriteSUN(FILE *, byte *, int, int, byte *, byte *, byte *, int, int);



#else     /* using non-ANSI cc.  Function defs, but no params */

/****************************** picio.c ***************************************/
int  InitPicio();
int  LoadRasterImage();
void ClearRasterImage();
void RedrawRasterImage();
int  WriteRasterImage();
void SetJPEGQuality();
int  GetJPEGQuality();

/****************************** picmisc.c *************************************/
Window CreateWindow();
void   Resize();
void   SortColormap();
void   AllocColors();
void   AllocRWColors();
void   DoMonoAndRV();
void   FSDither();
void   CreateXImage();
void   FreeColors();

/****************************** smooth.c **************************************/
void  Smooth();
byte *Smooth24();
void ColorDither();

/****************************** picgam.c **************************************/
void GenerateFSGamma();

/****************************** con24to8.c ************************************/
int  Conv24to8();
void InitFSDTables();

/****************************** gifrio.c **************************************/
int LoadGIF();

/****************************** gifwio.c **************************************/
int WriteGIF();

/****************************** tiffrio.c *************************************/
int LoadTIFF();

/****************************** tiffwio.c *************************************/
int WriteTIFF();

/****************************** jpegio.c **************************************/
int  LoadJFIF();
int  WriteJFIF();
void CreateJPEGW();
void JPEGDialog();
int  JPEGCheckEvent();
void JPEGSaveParams();

/****************************** pmio.c ****************************************/
int LoadPM(), WritePM();

/****************************** pbmio.c ***************************************/
int LoadPBM(), WritePBM();

/****************************** xbmio.c ***************************************/
int LoadXBM(), WriteXBM();

/****************************** sunio.c ***************************************/
int LoadSUN(), WriteSUN();

#endif __STDC__

#endif PIC_HEADERS
