/* ========================================================================== */
/*                                                                            */
/* Filename:     layio.c                          +-----+-----+--+--+--+--+   */
/* Version :     1.3	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/15/92	10:43:36	                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*                                                                            */
/*      Module    :  layio.c                                                  */
/*                                                                            */
/*      Functions :                                                           */
/*                                                                            */
/* ========================================================================== */



/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <malloc.h>
#include "layio.h"
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "../misc/ographic.h"
#include "../kernel/user.h"
#include "../kernel/message.h"
#include "../ui/layer.h"
#include "../draw/drawstate.h"
#include "../ui/sketchpad.h"
#include "../misc/sperror.h"
#include "../misc/makepath.h"

extern void msg_write_object_to(int,int,int,void*,int,int,int);

/* ========================================================================== */
/*      DEFINE STATEMENTS                                                     */
/* ========================================================================== */

/* ========================================================================== */
/*      GLOBAL VARIABLES                                                      */
/* ========================================================================== */



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  LoadLayer                                                */
/*                                                                            */
/*      Version   :  14.05.1991                                               */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  Load Layer from File                                     */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  Main Program of Sketchpad                                */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int LoadLayer(int layer_id, int sketch_id, char *path)
{
  char buffer[16384];
  FILE *fp;
  struct stat buf;
  char *buf2;
  struct_storage ss;
  int r;
  void            *obj;
  void            *oldpos;
  
  oldpos = GetCurrentLayer();

  msg_clear_layer(layer_id, sketch_id);
  ClearLayer(layer_id, sketch_id);
  ss = GetStructStorage (GetLayer (layer_id, sketch_id));

  stat (path, &buf);
  buf2 = (char *) malloc (buf.st_size + 1);
  fp = fopen (path, "r");
  if (!fp)
  {
    sperror("LoadLayer: Cannot open Layerfile.");
    return(0);
  }
  r = fread (buf2, 1, buf.st_size, fp);
  buf2[r] = '\0';
  msg_write_object_to (ownUserNumber, obj_count, strlen (buf2) + 1, buf2,
                       TO_ALL, layer_id, sketch_id);
  WriteObjects (ss, buf2, ownUserNumber, &obj_count);
  fclose (fp);

  obj = GetFirstObj(ss);
  while (obj != NULL)
  {
    ReadObject(obj, buffer);
    obj = GetNextObj(ss);
  }
  fclose(fp);

  SetCurrentLayer(oldpos);

  return(1);
} /* LoadLayer */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  WriteLayer                                               */
/*                                                                            */
/*      Version   :  14.05.1991                                               */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  Write Layer to File                                      */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  Main Program of Sketchpad                                */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int WriteLayer(layer lay, char *path)
{
  char buffer[16384];
  FILE            *fp;
  void            *obj;
  struct_storage  ss;
  char *tempp1;
  char pathname[256];
  
  ss = GetStructStorage(lay);

  obj = GetFirstObj(ss);
  fp = fopen(path, "w");
  if (!fp)
  {
    /* try to create directory */
    tempp1 = strrchr(path, '/');
    strncpy(pathname, path, tempp1 - path);
    pathname[tempp1 - path] = '\0';
    if (MakePath(pathname) == 0)
    {
      if (!(fp = fopen(path, "w")))
      {
        sperror("WriteLayer: Cannot open Layerfile.");
        return(0);
      }
    }
    else
    {
      return(0);
    }
  }
  while (obj != NULL)
  {
    ReadObject(obj, buffer);
    obj = GetNextObj(ss);
    fprintf(fp,"%s\n", buffer);
  }
  fclose(fp);
  return(1);
} /* WriteLayer */

