/* ========================================================================== */
/*                                                                            */
/* Filename:     tiffmisc.c                       +-----+-----+--+--+--+--+   */
/* Version :     1.3	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/15/92	10:43:47	                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*                                                                            */
/*      Module    : tifmisc.c                                                 */
/*                                                                            */
/*      Functions : (int_t)    lhToI   (export all)                           */
/*                  (long_t)   chToL                                          */
/*                  (double_t) chToD                                          */
/*                  (double_t) anyToD                                         */
/*                  (char_t *) anyToCh                                        */
/*                  (char_t *) sToCh                                          */
/*                  (char_t *) lToCh                                          */
/*                  int tiff_ftop_interl                                      */
/*                  int tiff_gray_to_RRR                                      */
/*                                                                            */
/* ========================================================================== */
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <malloc.h>

#include "tiff.h"
#include "picio.h"

extern	boolean_t	II,
			MM;

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  lhToI                                                    */
/*                                                                            */
/*      Version   :  06.11.1990                                               */
/*                                                                            */
/*      Purpose   :  Convert 2 Bytes into Integer                             */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  anyToD ()                                                */
/*                   getIFD ()                                                */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int_t lhToI (uchar_t pointer[])
{
  if ( II )
    return (pointer[0] | (pointer[1] << 8));
  else if ( MM )
    return (pointer[1] | (pointer[0] << 8));
  return ((int_t)0);
} /* lhToI */

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  chToL                                                    */
/*                                                                            */
/*      Version   :  06.11.1990                                               */
/*                                                                            */
/*      Purpose   :  Convert 4-Byte_Char into Long                            */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  anyToD ()                                                */
/*                   chToD ()                                                 */
/*                   getHeader ()                                             */
/*                   getIFD ()                                                */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
long_t chToL(uchar_t *chpointer)
{
  long_t  long_int=0;
  int_t	i;

  if ( II )                        /* byte order II */
    for (i=3;i>=0;i--)
    {
      long_int = long_int<<8;
      long_int |= chpointer[i]; 
    }
    else if ( MM )                   /* byte order MM */
      for (i=0;i<4;i++)
      {
        long_int = long_int<<8;
        long_int |= chpointer[i];
      }
  return (long_int);
} /* chToL */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  chToD                                                    */
/*                                                                            */
/*      Version   :  06.11.1990                                               */
/*                                                                            */
/*      Purpose   :  Convert 4-Byte_Char into Double                          */
/*                   (1. 4Byte char = Zaehler,                                */
/*                    2. 4Byte char = Nenner).                                */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  anyToD                                                   */
/*                   getIFD                                                   */
/*                                                                            */
/*      Calls     :  (long_t)   chToL ()                                      */
/*                                                                            */
/* ========================================================================== */
double_t  chToD (uchar_t *chpointer)
{	
  return (chToL(&chpointer[0]) / chToL(&chpointer[4]));
} /* chToD */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  anyToD                                                   */
/*                                                                            */
/*      Version   :  06.11.1990                                               */
/*                                                                            */
/*      Purpose   :  Convert Sequence of Bytes in Double according to TIFF    */
/*                   Type tp                                                  */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  makeRaster                                               */
/*                   getIFD                                                   */
/*                                                                            */
/*      Calls     :  (int_t)    lhToI ()                                      */
/*                   (long_t)   chToL ()                                      */
/*                   (double_t) chToD ()                                      */
/*                                                                            */
/* ========================================================================== */
double_t  anyToD (uchar_t *chpointer, tifDataTypes_t tp)
{

  switch (tp)
  {
    case (Byte):
      return ((double_t)chpointer[0]);
    case (ASCII):
      TifTrace ("*** WARNING: ASCII to DOUBLE Conversion attempted -- ignored ***\n");
      return (0.0);
    case (Short):
      return ((double_t)lhToI(chpointer));
    case (Long): 
      return ((double_t)chToL(chpointer));
    case (Rational):
      return (chToD(chpointer));
    default:
      return ((double_t)0.0);
  }
} /* anyToD */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  sToCh                                                    */
/*                                                                            */
/*      Version   :  06.11.1990                                               */
/*                                                                            */
/*      Purpose   :  Convert Short to 2Byte Char                              */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  putHeader                                                */
/*                   putIFD                                                   */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
char_t *sToCh (ushort_t short_int)
{
  char_t *chpointer;
  int_t  size;
  int_t  i;

  size = sizeof (ushort_t);
  chpointer = (char_t *)malloc (size);
  if (chpointer == (char_t *)NULL)
    return (chpointer);

  if ( II )                        /* byte order II */
    for (i=0;i<size;i++)
    {
      chpointer[i] = short_int & 0x00ff;
      short_int    = short_int>>8;
    }
    else if ( MM )			/* byte order MM */
      for (i=size-1;i>=0;i--)
      {
        chpointer[i] = short_int & 0x00ff;
        short_int    = short_int>>8;
      }
  return (chpointer);
} /* sToCh */

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  lToCh                                                    */
/*                                                                            */
/*      Version   :  06.11.1990                                               */
/*                                                                            */
/*      Purpose   :  Convert Long to 4Byte Char                               */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  putHeader                                                */
/*                   putIFD                                                   */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
char_t *lToCh (ulong_t long_int)
{
  char_t *chpointer;
  int_t  size;
  int_t  i;

  size = sizeof (ulong_t);
  chpointer = (char_t *)malloc (size);
  if (chpointer == (char_t *)NULL)
    return (chpointer);

  if ( II )                        /* byte order II */
    for (i=0;i<size;i++)
    {
      chpointer[i] = long_int & 0x000000ff;
      long_int    = long_int>>8;
    }
    else if ( MM )			/* byte order MM */
      for (i=size-1;i>=0;i--)
      {
        chpointer[i] = long_int & 0x000000ff;
        long_int    = long_int>>8;
      }
  return (chpointer);
} /* lToCh */

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  anyToCh                                                  */
/*                                                                            */
/*      Version   :  06.11.1990                                               */
/*                                                                            */
/*      Purpose   :  Convert Value to Sequence of Bytes according to TIFF     */
/*                   Type                                                     */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :  (char_t *) sToCh ()                                      */
/*                   (char_t *) lToCh ()                                      */
/*                                                                            */
/* ========================================================================== */
char_t	*anyToCh (char_t *value, tifDataTypes_t tp)
{
  switch (tp)
  {
    case (Byte):
      return (value);
    case (ASCII):
      return (value);
    case (Short):
      return (sToCh(*((ushort_t *)value)));
    case (Long):
      return (lToCh(*((ulong_t *)value)));
    case (Rational):
      TifTrace ("*** WARNING: Double-to-Character-Conversion not yet implemented! -- Ignored ***\n");
    default:
      return ((char_t *)NULL);
  }
} /* anyToCh */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  TifTrace                                                 */
/*                                                                            */
/*      Version   :  29.04.1991                                               */
/*                                                                            */
/*      Purpose   :  Write Debug Information to File or to StdOut             */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
void TifTrace (char_t *str, ulong_t value1, ulong_t value2, ulong_t value3)
{
#ifdef	TIF_TRACE_ON
#ifdef	TIF_TRACE_TO_FILE
  if (tif_trace != (FILE *)NULL)
  (void)fprintf(trace_file,str,value1,value2,value3);
#else	!TIF_TRACE_TO_FILE
#ifdef	  TIF_TRACE_TO_SCREEN
  (void)printf(str,value1,value2,value3);
#endif	  TIF_TRACE_TO_SCREEN
#endif	!TIF_TRACE_TO_FILE
#endif	TIF_TRACE_ON
} /* TifTrace */



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  tiff_ftop_interl                                         */
/*                                                                            */
/*      Version   :  29.04.1991                                               */
/*                                                                            */
/*      Purpose   :  Convert Field to Pixel Interleaving                      */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int tiff_ftop_interl (tifImage_t *image, ushort_t samples_per_pixel)
{
  register ulong_t	i, k;
  ushort_t		j;
  ulong_t		size_of_image;
  uchar_t		*out_dat;

  if (image == (tifImage_t *)NULL || samples_per_pixel <= 0)
    return (0);

  size_of_image = image->width * image->height;
  if (size_of_image <= (ulong_t)0 || image->data == (uchar_t *)NULL)
    return (0);

  out_dat = (uchar_t *)malloc(samples_per_pixel * size_of_image
						     * sizeof (char_t));
  if (out_dat == (uchar_t *)NULL)
    return (0);

  for (i=0; i<size_of_image; i++)
  {
    k = i * samples_per_pixel;
    for (j=0; j<samples_per_pixel; j++)
      out_dat[k+j] = image->data[i+j*size_of_image];
  }
  (void)free(image->data);
  image->data = (uchar_t *)out_dat;

  return (1);
} /* tiff_ftop_interl */



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  tiff_gray_to_RRR                                         */
/*                                                                            */
/*      Version   :  29.04.1991                                               */
/*                                                                            */
/*      Purpose   :  Convert 1-Channel-Grayscale into 3-Chanal-Grayscale      */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int tiff_gray_to_RRR (tifImage_t *image)
{
  register ulong_t	i, k;
  ushort_t		j;
  ulong_t			size_of_image;
  uchar_t			*out_dat;
  ushort_t		samples_per_pixel = 3;

  if (image == (tifImage_t *)NULL)
    return (0);

  size_of_image = image->width * image->height;
  if (size_of_image <= (ulong_t)0 || image->data == (uchar_t *)NULL)
    return (0);

  out_dat = (uchar_t *)malloc(samples_per_pixel * size_of_image
                                                * sizeof (char_t));
  if (out_dat == (uchar_t *)NULL)
    return (0);

  for (i=0; i<size_of_image; i++)
  {
    k = i * samples_per_pixel;
    for (j=0; j<samples_per_pixel; j++)
      out_dat[k+j] = image->data[i];
  }
  (void)free(image->data);
  image->data = (uchar_t *)out_dat;

  return (1);
} /* tif_gray_to_RRR */
