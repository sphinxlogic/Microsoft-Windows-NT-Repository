/* ========================================================================== */
/*                                                                            */
/* Filename:     ogr.c                            +-----+-----+--+--+--+--+   */
/* Version :     1.3	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/14/92	10:06:40	                      */
/*                                                                            */
/* ========================================================================== */

/* system includes */

#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <ctype.h>

/* other includes */

#include "list.h"
#include "ogr.h"
#include "../global/global.h"

/* some defines */

#define GP_LINE       1
#define GP_FREEHAND   2
#define GP_TEXT       3
#define GP_RECTANGLE  4
#define GP_ARC        5

#define ST_NONE   0
#define ST_PICKED 1

struct sstor_s
  {
    list           *object;
    int            tx;
    int            ty;
  };

struct gp_line_s
  {
    int x1, y1, x2, y2;
    unsigned int lwidth, lstyle;
  };

struct gp_point_s
  {
    int x, y;
  };

struct gp_freehand_s
  {
    list         points;
    unsigned int lwidth, lstyle;
  };

struct gp_rectangle_s
  {
    int x, y;
    unsigned int w, h;
    unsigned int lwidth, lstyle;
  };

struct gp_arc_s
  {
    int x, y;
    unsigned int w, h;
    int angle1, angle2;
    unsigned int lwidth, lstyle;
  };

struct gp_text_s
  {
    char txt[TEXTLEN];  /* the text */
    int fontsize;
    int fontthick;
    int fontslant;
  };

struct entry_s
  {
    int type;  /* the type of the graphic-primitive */
    int id1;   /* id1 and id2 are a conference wide */
    int id2;   /*   unique identifier to this object */
    int state; /* state of this object */
    int x1, y1, x2, y2; /* bounding-box of object */
    union
    {
      struct gp_line_s      line;
      struct gp_freehand_s  freehand;
      struct gp_rectangle_s rectangle;
      struct gp_arc_s       arc;
      struct gp_text_s      text;
    } gp;
  };

static struct entry_s *TextObj;

/* internal used functions */

/* freeSS: */
/* free-function to be called by the list-module on */
/* deallocating the list */

static void freeSS (struct entry_s *e)
{
  free (e);
}

void movePoints (list l, int xd, int yd)
{
  struct gp_point_s *p;

  FirstEntry (l);
  while (GetListState (l) == E_OK)
  {
    p = GetEntry (l);
    p->x -= xd;
    p->y -= yd;
    NextEntry (l);
  }
}

void extendBoundingBox (struct entry_s *e, int x, int y)
{
  int xd, yd;

  if (x < e->x1)
  {
    xd = x - e->x1;
    yd = 0;
    movePoints (e->gp.freehand.points, xd, yd);
    e->x1 = x;
  }
  if (y < e->y1)
  {
    xd = 0;
    yd = y - e->y1;
    movePoints (e->gp.freehand.points, xd, yd);
    e->y1 = y;
  }
  if (x > e->x2)
  {
    e->x2 = x;
  }
  if (y > e->y2)
  {
    e->y2 = y;
  }
}

/* exported functions */

/* CreateSS: */
/* create a new structure-store */

struct_storage CreateSS (void)
{
  struct sstor_s *ss;

  ss = (void *) malloc (sizeof (struct sstor_s));
  if (ss == NULL)
  {
    fprintf (stderr, "ographic.c: in CreateSS: malloc failed.\n");
    fflush (stderr);
    return NULL;
  }
  ss->object = CreateList ();
  ss->tx = 0;
  ss->ty = 0;
  SetFreeFunction (ss->object, (free_t *) freeSS);
  return (struct_storage) ss;
}

/* FreeSS: */
/* free a structure-store */

void FreeSS (struct_storage ss)
{
  if (ss == NULL)
  {
    fprintf (stderr, "ographic.c: FreeSS called with ss == NULL\n");
    fprintf (stderr, "            (no action taken)\n");
    fflush (stderr);
    return;
  }
  FreeList (((struct sstor_s *) ss)->object);
  free (ss);
}

/* InsertLine: */
/* insert a GP_LINE object to the structure store */

void InsertLine (struct_storage ss,
                 int x1, int y1, int x2, int y2,
                 unsigned int lwidth, unsigned int lstyle,
                 int id1, int id2)
{
  struct entry_s *e;

  if (ss == NULL)
  {
    fprintf (stderr, "ogr.c: InsertLine called with ss == NULL\n");
    fprintf (stderr, "       (no action taken)\n");
    fflush (stderr);
    return;
  }
  e = (void *) malloc (sizeof (struct entry_s));
  if (e == NULL)
  {
    fprintf (stderr, "ogr.c: in InsertLine: malloc failed/n");
    fflush (stderr);
    return;
  }
  e->type  = GP_LINE;
  e->id1   = id1;
  e->id2   = id2;
  e->state = ST_NONE;
  if (x1 > x2)
  {
    e->x1 = x2;
    e->x2 = x1;
  }
  else
  {
    e->x1 = x1;
    e->x2 = x2;
  }
  if (y1 > y2)
  {
    e->y1 = y2;
    e->y2 = y1;
  }
  else
  {
    e->y1 = y1;
    e->y2 = y2;
  }
  e->gp.line.x1 = x1 - e->x1;
  e->gp.line.y1 = y1 - e->y1;
  e->gp.line.x2 = x2 - e->x1;
  e->gp.line.y2 = y2 - e->y1;
  e->gp.line.lwidth = lwidth;
  e->gp.line.lstyle = lstyle;
  InsertEndEntry (((struct sstor_s *) ss)->object, e);
}

/* InsertFreehand: */

void *InsertFreehand (struct_storage ss,
                      int x, int y,
                      unsigned int lwidth, unsigned int lstyle,
                      int id1, int id2)
{
  struct entry_s    *e;
  struct gp_point_s *p;

  if (ss == NULL)
  {
    fprintf (stderr, "ogr.c: InsertFreehand called with ss == NULL\n");
    fprintf (stderr, "       (no action taken)\n");
    fflush (stderr);
    return NULL;
  }
  e = (void *) malloc (sizeof (struct entry_s));
  if (e == NULL)
  {
    fprintf (stderr, "ogr.c: in InsertFreehand: malloc failed/n");
    fflush (stderr);
    return NULL;
  }
  e->type  = GP_FREEHAND;
  e->id1   = id1;
  e->id2   = id2;
  e->state = ST_NONE;
  e->x1    = x;
  e->y1    = y;
  e->x2    = x;
  e->y2    = y;
  e->gp.freehand.lwidth = lwidth;
  e->gp.freehand.lstyle = lstyle;
  e->gp.freehand.points = CreateList ();
  p = (void *) malloc (sizeof (struct gp_point_s));
  if (p == NULL)
  {
    fprintf (stderr, "ogr.c: in InsertFreehand: malloc failed/n");
    fflush (stderr);
    return NULL;
  }
  p->x = 0;
  p->y = 0;
  InsertEndEntry (e->gp.freehand.points, p);
  InsertEndEntry (((struct sstor_s *) ss)->object, e);
  return e;
}

/* AppendLineSegment: */

void AppendLineSegment (void *e,
                        int x,
                        int y)
{
  struct gp_point_s *p;

  if (e == NULL)
  {
    fprintf (stderr, "ogr.c: AppendLineSegment called with e == NULL\n");
    fprintf (stderr, "       (no action taken)\n");
    fflush (stderr);
    return;
  }
  p = (void *) malloc (sizeof (struct gp_point_s));
  if (p == NULL)
  {
    fprintf (stderr, "ogr.c: in AppendLineSegment: malloc failed/n");
    fflush (stderr);
    return;
  }
  extendBoundingBox ((struct entry_s *) e, x, y);
  p->x = x - ((struct entry_s *) e)->x1;
  p->y = y - ((struct entry_s *) e)->y1;
  InsertEndEntry (((struct entry_s *) e)->gp.freehand.points, p);
}

/* GetObject: */

void *GetObject (struct_storage ss, int id1, int id2)
{
  list l;
  struct entry_s *e;

  if (ss == NULL)
  {
    fprintf (stderr, "ogr.c: GetObject called with ss == NULL\n");
    fprintf (stderr, "       (no action taken)\n");
    fflush (stderr);
    return NULL;
  }
  l = ((struct sstor_s *) ss)->object;
  FirstEntry (l);
  while (GetListState (l) == E_OK)
  {
    e = GetEntry (l);
    if ((e->id1 == id1) && (e->id2 == id2))
    {
      return e;
    }
    NextEntry (l);
  }
  return NULL;
}

/* DeleteObject: */

void DeleteObject (struct_storage ss, void *o)
{
  list l;
  struct entry_s *e;
  void *pos, *pos2;

  if (ss == NULL)
  {
    fprintf (stderr, "ogr.c: DeleteObject called with ss == NULL\n");
    fprintf (stderr, "       (no action taken)\n");
    fflush (stderr);
    return;
  }
  {
    l = ((struct sstor_s *) ss)->object;
    FirstEntry (l);
    while (GetListState (l) == E_OK)
    {
      e = GetEntry (l);
      pos2 = GetListPosition (l);
      NextEntry (l);
      if (e == o)
      {
        pos = GetListPosition (l);
        SetListPosition (l, pos2);
        DeleteEntry (l);
        free (e);

        SetListPosition (l, pos);
        return;
      }
    }
  }
}

/* MoveObject: */

void MoveObject (struct_storage ss, void *o, int xd, int yd)
{
  if (ss == NULL)
  {
    fprintf (stderr, "ogr.c: MoveObject called with ss == NULL\n");
    fprintf (stderr, "       (no action taken)\n");
    fflush (stderr);
    return;
  }
  if (o == NULL)
  {
    fprintf (stderr, "ogr.c: MoveObject called with o == NULL\n");
    fprintf (stderr, "       (no action taken)\n");
    fflush (stderr);
    return;
  }

  ((struct entry_s *) o)->x1 += xd;
  ((struct entry_s *) o)->y1 += yd;
  ((struct entry_s *) o)->x2 += xd;
  ((struct entry_s *) o)->y2 += yd;
}

/* SizeObject: */

void SizeObject (struct_storage ss, void *o, int x, int y, int w, int h)
{
  int old_x, old_y, old_w, old_h;
  list l;
  struct gp_point_s *p;

  if (ss == NULL)
  {
    fprintf (stderr, "ogr.c: SizeObject called with ss == NULL\n");
    fprintf (stderr, "       (no action taken)\n");
    fflush (stderr);
    return;
  }
  old_x = ((struct entry_s *) o)->x1;
  old_y = ((struct entry_s *) o)->y1;
  old_w = ((struct entry_s *) o)->x2 - old_x + 1;
  old_h = ((struct entry_s *) o)->y2 - old_y + 1;
  switch (((struct entry_s *) o)->type)
  {
    case GP_LINE:
      ((struct entry_s *) o)->gp.line.x1 *= w;
      ((struct entry_s *) o)->gp.line.x1 /= old_w;
      ((struct entry_s *) o)->gp.line.x2 *= w;
      ((struct entry_s *) o)->gp.line.x2 /= old_w;
      if (w < 0)
      {
        ((struct entry_s *) o)->gp.line.x1 -= w;
        ((struct entry_s *) o)->gp.line.x2 -= w;
      }
      ((struct entry_s *) o)->gp.line.y1 *= h;
      ((struct entry_s *) o)->gp.line.y1 /= old_h;
      ((struct entry_s *) o)->gp.line.y2 *= h;
      ((struct entry_s *) o)->gp.line.y2 /= old_h;
      if (h < 0)
      {
        ((struct entry_s *) o)->gp.line.y1 -= h;
        ((struct entry_s *) o)->gp.line.y2 -= h;
      }
      break;
    case GP_FREEHAND:
      l = ((struct entry_s *) o)->gp.freehand.points;
      FirstEntry (l);
      while (GetListState (l) == E_OK)
      {
        p = GetEntry (l);
        p->x *= w;
        p->x /= old_w;
        if (w < 0)
        {
          p->x -= w;
        }
        p->y *= h;
        p->y /= old_h;
        if (h < 0)
        {
          p->y -= h;
        }
        NextEntry (l);
      }
      break;
    case GP_RECTANGLE:
      if (w < 0)
      {
        ((struct entry_s *) o)->gp.rectangle.w = -w;
      }
      else
      {
        ((struct entry_s *) o)->gp.rectangle.w =  w-2;
      }
      if (h < 0)
      {
        ((struct entry_s *) o)->gp.rectangle.h = -h;
      }
      else
      {
        ((struct entry_s *) o)->gp.rectangle.h =  h-2;
      }
      break;
    case GP_ARC:
      if (w < 0)
      {
        ((struct entry_s *) o)->gp.arc.w = -w;
      }
      else
      {
        ((struct entry_s *) o)->gp.arc.w =  w-2;
      }
      if (h < 0)
      {
        ((struct entry_s *) o)->gp.arc.h = -h;
      }
      else
      {
        ((struct entry_s *) o)->gp.arc.h =  h-2;
      }
      break;

    case GP_TEXT:
      break;
  }
  ((struct entry_s *) o)->x1 = x;
  ((struct entry_s *) o)->y1 = y;
  ((struct entry_s *) o)->x2 = x + w - 1;
  ((struct entry_s *) o)->y2 = y + h - 1;
  if (w < 0)
  {
    int hh;

    hh = ((struct entry_s *) o)->x1;
    ((struct entry_s *) o)->x1 = ((struct entry_s *) o)->x2;
    ((struct entry_s *) o)->x2 = hh;
  }
  if (h < 0)
  {
    int hh;

    hh = ((struct entry_s *) o)->y1;
    ((struct entry_s *) o)->y1 = ((struct entry_s *) o)->y2;
    ((struct entry_s *) o)->y2 = hh;
  }
}

/* InsertText: */
/* insert a GP_TEXT object to the structure store */

void InsertText (struct_storage ss,
                 int x, int y, int w, int h,
                 char* chartext, int fontsize, int fontthick, int fontslant,
                 int id1, int id2)
{
  struct entry_s *e;

  if (ss == NULL)
  {
    fprintf (stderr, "ogr.c: InsertText called with ss == NULL\n");
    fprintf (stderr, "       (no action taken)\n");
    fflush (stderr);
    return;
  }
  e = (void *) malloc (sizeof (struct entry_s));
  if (e == NULL)
  {
    fprintf (stderr, "ogr.c: in InsertText: malloc failed/n");
    fflush (stderr);
    return;
  }
  e->type  = GP_TEXT;
  e->id1   = id1;
  e->id2   = id2;
  e->state = ST_NONE;
  e->x1    = x;
  e->y1    = y;
  e->x2    = x + w;
  e->y2    = y + h;
  e->gp.text.fontsize  = fontsize;
  e->gp.text.fontthick = fontthick;
  e->gp.text.fontslant = fontslant;
  strcpy (e->gp.text.txt, chartext);
  InsertEndEntry (((struct sstor_s *) ss)->object, e);
}

/* InsertRectangle: */
/* insert a GP_RECTANGLE object to the structure store */

void InsertRectangle(struct_storage ss,
                     int x, int y,
                     unsigned int w, unsigned int h,
                     unsigned int lwidth, unsigned int lstyle,
                     int id1, int id2)
{
  struct entry_s *e;

  if (ss == NULL)
  {
    fprintf (stderr, "ogr.c: InsertRectangle called with ss == NULL\n");
    fprintf (stderr, "       (no action taken)\n");
    fflush (stderr);
    return;
  }
  e = (void *) malloc (sizeof (struct entry_s));
  if (e == NULL)
  {
    fprintf (stderr, "ogr.c: in InsertRectangle: malloc failed/n");
    fflush (stderr);
    return;
  }
  e->type  = GP_RECTANGLE;
  e->id1   = id1;
  e->id2   = id2;
  e->state = ST_NONE;
  e->x1 = x;
  e->x2 = x+w+1;
  e->y1 = y;
  e->y2 = y+h+1;

  e->gp.rectangle.x = 0;
  e->gp.rectangle.y = 0;
  e->gp.rectangle.w = w;
  e->gp.rectangle.h = h;
  e->gp.rectangle.lwidth = lwidth;
  e->gp.rectangle.lstyle = lstyle;
  InsertEndEntry (((struct sstor_s *) ss)->object, e);
}

/* InsertArc: */
/* insert a GP_ARC object to the structure store */

void InsertArc (struct_storage ss,
                int x, int y,
                unsigned int w, unsigned int h,
                int angle1, int angle2,
                unsigned int lwidth, unsigned int lstyle,
                int id1, int id2)
{
  struct entry_s *e;

  if (ss == NULL)
  {
    fprintf (stderr, "ogr.c: InsertArc called with ss == NULL\n");
    fprintf (stderr, "       (no action taken)\n");
    fflush (stderr);
    return;
  }
  e = (void *) malloc (sizeof (struct entry_s));
  if (e == NULL)
  {
    fprintf (stderr, "ogr.c: in InsertArc: malloc failed/n");
    fflush (stderr);
    return;
  }

  e->type  = GP_ARC;
  e->id1   = id1;
  e->id2   = id2;
  e->state = ST_NONE;
  e->x1 = x;
  e->x2 = x+w+1;
  e->y1 = y;
  e->y2 = y+h+1;

  e->gp.arc.x = 0;
  e->gp.arc.y = 0;
  e->gp.arc.w = w;
  e->gp.arc.h = h;
  e->gp.arc.angle1 = angle1;
  e->gp.arc.angle2 = angle2;
  e->gp.arc.lwidth = lwidth;
  e->gp.arc.lstyle = lstyle;
  InsertEndEntry (((struct sstor_s *) ss)->object, e);
}

/* WriteObjects: */

  static char *scanbuf;
  static int scanNumber;
  static char scanString[3*TEXTLEN];
  static int token;

  /* the token, used by the scanner/parser */

  #define T_NULL          0
  #define T_LEFTBRACE     1
  #define T_RIGHTBRACE    2
  #define T_POINT         3
  #define T_GP_LINE       4
  #define T_GP_POLYLINE   5
  #define T_GP_RECTANGLE  6
  #define T_GP_ARC        7
  #define T_GP_TEXT       8
  #define T_GP_GROUP      9
  #define T_NUMBER       10
  #define T_STRING       11
  #define T_ERROR        -1

  /* local functions */

  static void convertString2 ( char* s_in, char* s_out)
  {
    int c;

    while (*s_in)
    {
      if (*s_in == '\\')
      {
        s_in++;
        sscanf (s_in, "%02x", &c);
        *s_out++ = (char) c;
        s_in += 2;
      }
      else
      {
        *s_out++ = *s_in++;
      }
    }
    *s_out = '\0';
  }

  static int getNextToken ()
  {
    char c;
    int  i;
    int  faktor;

    faktor = 1;
    /* go the the next printable char */
    while ((*scanbuf <= ' ') && (*scanbuf != '\0')) scanbuf++;
    c = *scanbuf;
    switch (*(scanbuf++))
    {
      case '\0':
        return T_NULL;
      case '(':
        return T_LEFTBRACE;
      case ')':
        return T_RIGHTBRACE;
      case '.':
        return T_POINT;
      case '"':
        i = 0;
        while (*scanbuf != '"')
        {
          scanString[i++] = *scanbuf++;
        }
        scanString[i] = '\0';
        scanbuf++;
        return T_STRING;
      case '-':
        faktor = -1;
        c = *scanbuf++;
        if ((c < '0') || (c > '9'))
          return T_ERROR;
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
        scanNumber = (int) c - 48;
        while (isdigit (*scanbuf))
        {
          scanNumber *= 10;
          scanNumber += (int) *scanbuf - 48;
          scanbuf++;
        }
        scanNumber *= faktor;
        return T_NUMBER;
      case 'P':
        return T_GP_POLYLINE;
      case 'G':
        return T_GP_GROUP;
      case 'L':
        return T_GP_LINE;
      case 'T':
        return T_GP_TEXT;
      case 'R':
        return T_GP_RECTANGLE;
      case 'A':
        return T_GP_ARC;
      default:
        return T_ERROR;
    }
  }

  static int getCoord (int *x, int *y)
  {
    if (token != T_NUMBER) return -1; /* error while parsing */
    *x = scanNumber;
    token = getNextToken ();
    if (token != T_NUMBER) return -1; /* error while parsing */
    *y = scanNumber;
    token = getNextToken ();
    return 0;
  }

  static int getLineAttribute (unsigned int *att)
  {
    if (token != T_NUMBER) return -1; /* error while parsing */
    *att = (unsigned int) scanNumber;
    token = getNextToken ();
    return 0;
  }

  static int getTextAttribute (int *att)
  {
    if (token != T_NUMBER) return -1; /* error while parsing */
    *att = scanNumber;
    token = getNextToken ();
    return 0;
  }


void WriteObjects (void *ss, char *buffer, int id1, int *id2)
{
  int x, y, w, h, tx, ty, pxz, pxn, pyz, pyn;

  if (ss == NULL)
  {
    fprintf (stderr, "ogr.c: WriteObjects called with ss == NULL\n");
    fprintf (stderr, "       (no action taken)\n");
    fflush (stderr);
    return;
  }
  scanbuf = buffer;
  /* get first token */
  token = getNextToken ();
  while (token == T_NUMBER)
  {
    if (getCoord (&x, &y) < 0) return; /* error while parsing */
    if (token != T_LEFTBRACE) return; /* error while parsing */
    token = getNextToken ();
    if (getCoord (&w, &h) < 0) return; /* error while parsing */
    if (getCoord (&tx, &ty) < 0) return; /* error while parsing */
    if (getCoord (&pxz, &pxn) < 0) return; /* error while parsing */
    if (getCoord (&pyz, &pyn) < 0) return; /* error while parsing */
    switch (token)
    {
      case T_GP_LINE:
        {
          int x1, y1, x2, y2;
          unsigned int lwidth, lstyle;

          token = getNextToken ();
          if (getLineAttribute (&lwidth) < 0) return; /* error while parsing */
          if (getLineAttribute (&lstyle) < 0) return; /* error while parsing */
          if (getCoord (&x1, &y1) < 0) return; /* error while parsing */
          if (getCoord (&x2, &y2) < 0) return; /* error while parsing */
          InsertLine (ss, x1 + x, y1 + y, x2 + x, y2 + y,
                          lwidth, lstyle, id1, (*id2)++);
        }
        break;
      case T_GP_POLYLINE:
        {
          unsigned int lwidth, lstyle;
          int xp, yp;
          void *o;

          token = getNextToken ();
          if (getLineAttribute (&lwidth) < 0) return; /* error while parsing */
          if (getLineAttribute (&lstyle) < 0) return; /* error while parsing */
          if (getCoord (&xp, &yp) < 0) return; /* error while parsing */
          o = InsertFreehand (ss, xp + x, yp + y,
                                  lwidth, lstyle, id1, (*id2)++);
          while (token == T_NUMBER)
          {
            if (getCoord (&xp, &yp) < 0) return; /* error while parsing */
            AppendLineSegment (o, xp + x, yp + y);
          }
        }

        break;
      case T_GP_RECTANGLE:
        {
          unsigned int lwidth, lstyle;
          int r_x, r_y, r_w, r_h;

          token = getNextToken ();
          if (getLineAttribute (&lwidth) < 0) return; /* error while parsing */
          if (getLineAttribute (&lstyle) < 0) return; /* error while parsing */
          if (getCoord (&r_x, &r_y) < 0) return; /* error while parsing */
          if (getCoord (&r_w, &r_h) < 0) return; /* error while parsing */
          InsertRectangle (ss, x + r_x, y + r_y, r_w, r_h,
                               lwidth, lstyle, id1, (*id2)++);
        }
        break;
      case T_GP_ARC:
        {
          int a_x, a_y, a_w, a_h, a_angle1, a_angle2;
          unsigned int lwidth, lstyle;

          token = getNextToken ();
          if (getLineAttribute (&lwidth) < 0) return; /* error while parsing */
          if (getLineAttribute (&lstyle) < 0) return; /* error while parsing */
          if (getCoord (&a_x, &a_y) < 0) return; /* error while parsing */
          if (getCoord (&a_w, &a_h) < 0) return; /* error while parsing */
          if (getCoord (&a_angle1, &a_angle2) < 0) return;
                                                 /* error while parsing */
          InsertArc (ss, x + a_x, y + a_y, a_w, a_h,
                         a_angle1, a_angle2,
                         lwidth, lstyle, id1, (*id2)++);
        }
        break;
      case T_GP_TEXT:
        {
          char decoded_text[TEXTLEN];
          int fontsize;
          int fontthick;
          int fontslant;

          token = getNextToken ();
          if (getTextAttribute (&fontsize) < 0) return; /* err. while parsing */
          if (getTextAttribute (&fontthick)< 0) return; /* err. while parsing */
          if (getTextAttribute (&fontslant)< 0) return; /* err. while parsing */
          if (token != T_STRING)
          {
            fprintf (stderr,"parse error. \n");
            return;
          }
          convertString2 (scanString, decoded_text);

          token = getNextToken ();      /* get the next token,           */
                                        /* which is expected to be a ')' */

          InsertText (ss, x, y, w, h, decoded_text,
                          fontsize, fontthick, fontslant, id1, (*id2)++);
        }
        break;
      default:
        return; /* error while parsing */
    }
    if (token != T_RIGHTBRACE) return; /* error while parsing */
    token = getNextToken ();
  }
  if (token != T_NULL)
  {
    fprintf (stderr, "parse error\n");
    fflush (stderr);
    return; /* error while parsing */
  }
}

/* GetFirstObj */

void *GetFirstObj (struct_storage ss)
{
  list l;

  if (ss == NULL)
  {
    fprintf (stderr, "ogr.c: GetFirstObj called with ss == NULL\n");
    fprintf (stderr, "       (no action taken)\n");
    fflush (stderr);
    return NULL;
  }
  l = ((struct sstor_s *) ss)->object;
  FirstEntry (l);
  return GetEntry (l);
}

/* ReadObject: */

/* local functions */

static void convertString (char* s_in, char* s_out)
{
  while (*s_in)
  {
    if (isascii(*s_in) && !iscntrl(*s_in) && (*s_in != '"') && (*s_in != '\\'))
    {
      *s_out++ = *s_in++;
    }
    else
    {
      *s_out++ = '\\';
      sprintf (s_out, "%02x", (int) *s_in++);
      s_out += 2;
    }
  }
  *s_out = '\0';
}

void ReadObject (object o, char *s)
{
  list l;
  struct gp_point_s *p;
  char buffer[80];
  char coded_text[3*TEXTLEN];

  if (((struct entry_s *)o) == NULL)
  {
    fprintf (stderr, "ogr.c: ReadObject called with o == NULL\n");
    fprintf (stderr, "       (no action taken)\n");
    fflush (stderr);
    return;
  }
  *s = '\0';
  sprintf (buffer, "%d %d ( %d %d 0 0 1 1 1 1 ",
           ((struct entry_s *)o)->x1, ((struct entry_s *)o)->y1,
           ((struct entry_s *)o)->x2 - ((struct entry_s *)o)->x1 + 1,
           ((struct entry_s *)o)->y2 - ((struct entry_s *)o)->y1 + 1);
  strcat (s, buffer);
  switch (((struct entry_s *)o)->type)
  {
    case GP_LINE:
      sprintf (buffer, "L %d %d %d %d %d %d",
               ((struct entry_s *)o)->gp.line.lwidth,
               ((struct entry_s *)o)->gp.line.lstyle,
               ((struct entry_s *)o)->gp.line.x1,
               ((struct entry_s *)o)->gp.line.y1,
               ((struct entry_s *)o)->gp.line.x2,
               ((struct entry_s *)o)->gp.line.y2);
      strcat (s, buffer);
      break;
    case GP_FREEHAND:
      sprintf (buffer, "P %d %d",
               ((struct entry_s *)o)->gp.freehand.lwidth,
               ((struct entry_s *)o)->gp.freehand.lstyle);
      strcat (s, buffer);
      l = ((struct entry_s *)o)->gp.freehand.points;
      FirstEntry (l);
      while (GetListState (l) == E_OK)
      {
        p = GetEntry (l);
        sprintf (buffer, " %d %d", p->x, p->y);
        strcat (s, buffer);
        NextEntry (l);
      }
      break;
    case GP_RECTANGLE:
      sprintf (buffer, "R %d %d %d %d %d %d",
               ((struct entry_s *)o)->gp.rectangle.lwidth,
               ((struct entry_s *)o)->gp.rectangle.lstyle,
               ((struct entry_s *)o)->gp.rectangle.x,
               ((struct entry_s *)o)->gp.rectangle.y,
               ((struct entry_s *)o)->gp.rectangle.w,
               ((struct entry_s *)o)->gp.rectangle.h);
      strcat (s, buffer);
      break;
    case GP_ARC:
      sprintf (buffer, "A %d %d %d %d %d %d %d %d",
               ((struct entry_s *)o)->gp.arc.lwidth,
               ((struct entry_s *)o)->gp.arc.lstyle,
               ((struct entry_s *)o)->gp.arc.x,
               ((struct entry_s *)o)->gp.arc.y,
               ((struct entry_s *)o)->gp.arc.w,
               ((struct entry_s *)o)->gp.arc.h,
               ((struct entry_s *)o)->gp.arc.angle1,
               ((struct entry_s *)o)->gp.arc.angle2);
      strcat (s, buffer);
      break;
    case GP_TEXT:
      sprintf (buffer, "T %d %d %d \"",
               ((struct entry_s *)o)->gp.text.fontsize,
               ((struct entry_s *)o)->gp.text.fontthick,
               ((struct entry_s *)o)->gp.text.fontslant);
      strcat (s, buffer);
      convertString (((struct entry_s *)o)->gp.text.txt, coded_text);
      strcat (s, coded_text);
      strcat (s, "\"");
      break;
  }
  strcat (s, " )");
}

/* GetNextObj: */

void *GetNextObj (struct_storage ss)
{
  list l;

  if (ss == NULL)
  {
    fprintf (stderr, "ogr.c: GetNextObj called with ss == NULL\n");
    fprintf (stderr, "       (no action taken)\n");
    fflush (stderr);
    return NULL;
  }
  l = ((struct sstor_s *) ss)->object;
  NextEntry (l);
  return GetEntry (l);
}

/* GetObjId: */

void GetObjId (object o, int *id1, int *id2)
{
  if (o == NULL)
  {
    fprintf (stderr, "ogr.c: GetObjId called with o == NULL\n");
    fprintf (stderr, "       (invalid id returned)\n");
    fflush (stderr);
    *id1 = 0;
    *id2 = 0;
  }
  *id1 = ((struct entry_s*) o)->id1;
  *id2 = ((struct entry_s*) o)->id2;
}
char *GetText (object o)
{
   struct entry_s *e = (struct entry_s *) o;

   return ( e->gp.text.txt );
}

void StoreTextObject (object o)
{
   TextObj = (struct entry_s *) o;
}

void GetTextObject (object *o)
{
   *o = (object) TextObj;
}

void GetTextEntry (int *x1, int *y1, int *fsize, int *fthick, int *fslant)
{
   *x1 = TextObj->x1;
   *y1 = TextObj->y1;
   *fsize  = TextObj->gp.text.fontsize;
   *fthick = TextObj->gp.text.fontthick;
   *fslant = TextObj->gp.text.fontslant;
}

/* end of ogr.c */

