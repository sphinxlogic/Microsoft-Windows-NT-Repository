void SetWaitState();
void ClearWaitState();
