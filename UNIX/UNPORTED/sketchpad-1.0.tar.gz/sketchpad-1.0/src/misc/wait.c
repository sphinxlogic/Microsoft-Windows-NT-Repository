/* ========================================================================== */
/*                                                                            */
/* Filename:     wait.c                           +-----+-----+--+--+--+--+   */
/* Version :     1.2	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/9/92	10:24:35	                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Module    :    wait.c                                                 */
/*                                                                            */
/*      Functions :    SetWaitState();                                        */
/*                     ClearWaitState();                                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <Mrm/MrmAppl.h>

#include "../ui/defs.h"
#include "../ui/sketchpad.h"
#include "../image/picio.h"
#include "../misc/cursor.h"

/* ========================================================================== */
/*      DEFINE STATEMENTS                                                     */
/* ========================================================================== */

/* ========================================================================== */
/*      GLOBAL VARIABLES                                                      */
/* ========================================================================== */

Cursor               wait_cursor;
XColor               cursor_fg, cursor_bg;


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : SetWaitState()                                            */
/*                                                                            */
/*      Version   : 24.04.1992                                                */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
void SetWaitState(void)
{
  /* define wait cursor for all winows */
  wait_cursor = XCreateFontCursor(theDisplay, XC_watch);

  /* set foreground color */
  cursor_fg.red   = 0;
  cursor_fg.blue  = 0;
  cursor_fg.green = 0;

  /* set background color */
  cursor_bg.red   = 65535;
  cursor_bg.blue  = 65535;
  cursor_bg.green = 65535;

  XRecolorCursor(theDisplay,wait_cursor,&cursor_fg,&cursor_bg);

  /* define the cursors for all boxes */
  if(widget_array[v_main_window] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_main_window]),
                  wait_cursor);
  if(widget_array[v_save_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_save_box]),
                  wait_cursor);
  if(widget_array[v_load_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_load_box]),
                  wait_cursor);
  if(widget_array[v_message_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_message_box]),
                  wait_cursor);
  if(widget_array[v_print_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_print_box]),
                  wait_cursor);
  if(widget_array[v_layer_manage_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_layer_manage_box]),
                  wait_cursor);
  if(widget_array[v_layer_status_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_layer_status_box]),
                  wait_cursor);
  if(widget_array[v_conference_list_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_conference_list_box]),
                  wait_cursor);
  if(widget_array[v_text_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_text_box]),
                  wait_cursor);
  if(widget_array[v_color_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_color_box]),
                  wait_cursor);
  if(widget_array[v_error_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_error_box]),
                  wait_cursor);
  if(widget_array[v_info_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_info_box]),
                  wait_cursor);
  if(widget_array[v_quit_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_quit_box]),
                  wait_cursor);
  if(widget_array[v_nyi] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_nyi]),
                  wait_cursor);
  if(widget_array[v_zoom_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_zoom_box]),
                  wait_cursor);
  if(widget_array[v_linestyle_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_linestyle_box]),
                  wait_cursor);
  if(widget_array[v_textstyle_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_textstyle_box]),
                  wait_cursor);
  if(widget_array[v_zoommag_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_zoommag_box]),
                  wait_cursor);
  if(widget_array[v_slideshow_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_slideshow_box]),
                  wait_cursor);
  if(widget_array[v_slideshow_rc_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_slideshow_rc_box]),
                  wait_cursor);

  /* define the cursors for some special windows */
  if(widget_array[v_drawing_area] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_drawing_area]),
                  wait_cursor);
  if(widget_array[v_zoom_area] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_zoom_area]),
                  wait_cursor);
  if(widget_array[v_conference_add_box] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_conference_add_box]),
                  wait_cursor);

  XFreeCursor(theDisplay,wait_cursor);
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  : ClearWaitState()                                          */
/*                                                                            */
/*      Version   : 24.04.1992                                                */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
void ClearWaitState(void)
{
  /* undefine the cursors for all windows */
  if(widget_array[v_main_window] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_main_window]));
  if(widget_array[v_save_box] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_save_box]));
  if(widget_array[v_load_box] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_load_box]));
  if(widget_array[v_message_box] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_message_box]));
  if(widget_array[v_print_box] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_print_box]));
  if(widget_array[v_layer_manage_box] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_layer_manage_box]));
  if(widget_array[v_layer_status_box] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_layer_status_box]));
  if(widget_array[v_conference_list_box] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_conference_list_box]));
  if(widget_array[v_text_box] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_text_box]));
  if(widget_array[v_color_box] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_color_box]));
  if(widget_array[v_error_box] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_error_box]));
  if(widget_array[v_info_box] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_info_box]));
  if(widget_array[v_quit_box] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_quit_box]));
  if(widget_array[v_nyi] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_nyi]));
  if(widget_array[v_zoom_box] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_zoom_box]));
  if(widget_array[v_linestyle_box] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_linestyle_box]));
  if(widget_array[v_textstyle_box] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_textstyle_box]));
  if(widget_array[v_zoommag_box] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_zoommag_box]));
  if(widget_array[v_slideshow_box] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_slideshow_box]));
  if(widget_array[v_slideshow_rc_box] != NULL)
    XUndefineCursor(theDisplay,XtWindow(widget_array[v_slideshow_rc_box]));

  /* define original cursors for windows with special cursors */
  if(widget_array[v_drawing_area] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_drawing_area]),
                  draw_mode_cursor);
  if(widget_array[v_zoom_area] != NULL)
    XDefineCursor(theDisplay,XtWindow(widget_array[v_zoom_area]),
                  zoom_cursor);
  if(widget_array[v_conference_add_box] != NULL)
    XUndefineCursor (theDisplay,XtWindow(widget_array[v_conference_add_box]));


}

