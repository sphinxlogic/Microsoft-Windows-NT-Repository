/*
 *  ogr.h
 *
 *  structur-storage for object orientied graphics
 *
 */

#ifndef __OGR_H
#define __OGR_H

/* types */

typedef void *struct_storage;
typedef void *object;

/* functions */

/* CreateSS: */
/* create a new structure-store */

struct_storage CreateSS (void);

/* FreeSS: */
/* free a structure-store */

void FreeSS (struct_storage);

/* InsertLine: */
/* insert a GP_LINE object to the structure store */

void InsertLine (struct_storage,
                 int, int, int, int,
                 unsigned int, unsigned int,
                 int, int);

/* InsertFreehand: */

void *InsertFreehand (struct_storage ss,
                      int x, int y,
                      unsigned int lwidth, unsigned int lstyle,
                      int id1, int id2);

/* AppendLineSegment: */

void AppendLineSegment (void *e, int x, int y);

/* GetObject: */

void *GetObject (struct_storage ss, int id1, int id2);

/* DeleteObject: */

void DeleteObject (struct_storage ss, void *o);

/* MoveObject: */

void MoveObject (struct_storage ss, void *o, int xd, int yd);

/* SizeObject: */

void SizeObject (struct_storage ss, void *o, int x, int y, int w, int h);

/* insert a GP_TEXT object to the structure store */

void InsertText (struct_storage ss,
                 int x, int y, int w, int h,
                 char* chartext, int fontsize, int fontthick, int fontslant,
                 int id1, int id2);

/* InsertRectangle: */
/* insert a GP_RECTANGLE object to the structure store */

void InsertRectangle(struct_storage ss,
                     int x, int y,
                     unsigned int w, unsigned int h,
                     unsigned int lwidth, unsigned int lstyle,
                     int id1, int id2);

/* InsertArc: */
/* insert a GP_ARC object to the structure store */

void InsertArc (struct_storage ss,
                int x, int y,
                unsigned int w, unsigned int h,
                int angle1, int angle2,
                unsigned int lwidth, unsigned int lstyle,
                int id1, int id2);


/* WriteObjects: */

void WriteObjects (void *ss, char *buffer, int id1, int *id2);

/* GetFirstObj */

void *GetFirstObj (struct_storage ss);

/* ReadObject: */

void ReadObject (object o, char *s);

/* GetNextObj: */

void *GetNextObj (struct_storage ss);

/* GetObjId: */

void GetObjId (object o, int *id1, int *id2);

char *GetText (object o);
 
void StoreTextObject (object o);
 
void GetTextObject (object *o);
 
void GetTextEntry (int *x1, int *y1, int *fsize, int *fthick, int *fslant);
 

#endif /* __OGR_H */
