/* ========================================================================== */
/*                                                                            */
/* Filename:     makepath.c                       +-----+-----+--+--+--+--+   */
/* Version :     1.3	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/14/92	10:06:27	                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Module    :  makepath                                                 */
/*                                                                            */
/*      Functions :  MakePath(): create given path                            */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <sys/errno.h>

extern void sperror(char*);

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  MakePath                                                 */
/*                                                                            */
/*      Version   :  05.03.1992                                               */
/*                                                                            */
/*      Purpose   :  creates directory hierarchy                              */
/*                   returns 0 on success, nonzero on error                   */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  Save()                                                   */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int MakePath(char *pathname)
{
  char localfullname[256];
  char localtruncname[256];
  char *tempp1; 
  char errtext[80];
  int retval;
  mode_t mode = 0770;

  /* copy pathname to local variable */
  strcpy (localfullname, pathname);

  /* delete terminating slash if exists */
  if (localfullname[strlen(localfullname) - 1] == '/')
    localfullname[strlen(localfullname) - 1] = '\0';
    
  /* try to create directory */
  retval = mkdir (localfullname, mode);
  if (retval == -1)
  {
    /* if component of the path prefix does not exist process path prefix */
    if (errno == ENOENT)
    {
      tempp1 = strrchr(localfullname, '/');
      if(tempp1 > localfullname)
      {
        strncpy(localtruncname, localfullname, tempp1 - localfullname);
        /* append NULL character */
        localtruncname[tempp1 - localfullname] = '\0';
        /* make parent directory */
        if (MakePath(localtruncname) == 0)
        {
          /* make directory */
          MakePath(localfullname);
        }
        else
        {
          return(1);
        }
      }
      else
      {
        fprintf(stderr,"MakePath: this cannot happen.\n");
        exit(1);
      }
    } 
    else
    {
      sprintf(errtext, "MakePath: cannot create %s", localfullname);
      sperror(errtext);
      return(1);
    }
  }
  return(0);
} /* MakePath */

