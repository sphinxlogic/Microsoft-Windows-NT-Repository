/* ========================================================================== */
/*                                                                            */
/* Filename:     list.c                           +-----+-----+--+--+--+--+   */
/* Version :     1.3	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/14/92	10:06:13	                      */
/*                                                                            */
/* ========================================================================== */

/* system includes */

#include <stdio.h>
/* HC
#include <stdlib.h>
*/

/* exported constants */

#define E_OK        0 /* no error occured */
#define E_NYI       1 /* function not yet implemented */
#define E_NOMEM     2 /* no more memory to allocate */
#define E_TOPOFLIST 3 /* the function PreviousEntry has */
                      /* reached the top of the list */
#define E_ENDOFLIST 4 /* the function NextEntry has */
                      /* reached the end of the list */
#define E_NOCURRENT 5 /* there is no current entry to */
                      /* deal with */
#define E_FOUND     6 /* found something */
#define E_NOTFOUND  7 /* found nothing */

/* internal constants */

#define NO_ENTRY  ((struct entry *) NULL)

/* exported types */

typedef void* list;
typedef int comp_t(void*, void*);
typedef void free_t(void*);

/* internal struct's */

struct entry
  {
    void         *data; /* data assign to this entry */
    struct entry *next; /* next entry in the list */
    struct entry *prev; /* previous entry in the list */
  };

struct llist
  {
    int          state;      /* status of last operation */
    struct entry *first;     /* first entry in the list */
    struct entry *last;      /* last entry in the list */
    struct entry *current;   /* current entry in the list */
    struct entry *lastfound; /* the last entry that was */
                             /* found with FoundEntry */
    free_t       *free;      /* function used to free the */
                             /* data of the entrys */
    comp_t       *comp;      /* compare function used at */
                             /* last FindEntry */
    void         *data;      /* compare data used last */
                             /* FindEntry */
  };

/* functions */

/* CreateList : */
/* allocate and initialize a new list instance */

list CreateList(void)
{
  struct llist *l;

  l = (struct llist*) malloc (sizeof(struct llist));
  l->state     = E_OK;
  l->first     = NO_ENTRY;
  l->last      = NO_ENTRY;
  l->current   = NO_ENTRY;
  l->lastfound = NO_ENTRY;
  l->free      = NULL;
  l->comp      = NULL;
  l->data      = NULL;
  return (list) l;
}

/* SetFreeFunction : */
/* set the free-function for this list */

void SetFreeFunction(list l, free_t *f)
{
  ((struct llist*) l)->free = f;
}

/* FreeList : */
/* free the entire list including all entrys and the */
/* assigned data */

void FreeList(list l)
{
  struct entry *e, *e2;

  /* is there a free-function for the data ? */
  if (((struct llist*) l)->free != NULL)
  {
    /* free all data assign to the entrys */
    e = ((struct llist*) l)->first;
    while (e != NO_ENTRY)
    {
      ((struct llist*) l)->free (e->data);
      e = e->next;
    }
  }
  /* free all entrys themselves */
  e = ((struct llist*) l)->first;
  while (e != NO_ENTRY)
  {
    e2 = e->next;
    free (e);
    e = e2;
  }
  /* and free the list-control struct */
  free (l);
}

/* FirstEntry : */
/* set the current entry to the first entry on the list */

void FirstEntry(list l)
{
  ((struct llist*) l)->current = ((struct llist*) l)->first;
  if (((struct llist*) l)->current != NO_ENTRY)
  {
    ((struct llist*) l)->state = E_OK;
  }
  else
  {
    ((struct llist*) l)->state = E_NOCURRENT;
  }
}

/* LastEntry : */
/* set the current entry to the last entry on the list */

void LastEntry(list l)
{
  ((struct llist*) l)->current = ((struct llist*) l)->last;
  ((struct llist*) l)->current = E_OK;
}

/* NextEntry : */
/* set the current entry to the next entry following the */
/* current entry in the list */

void NextEntry(list l)
{
  /* is there a current entry ? */
  if (((struct llist*) l)->current != NO_ENTRY)
  {
    /* there is a current entry */
    ((struct llist*) l)->current =
      ((struct llist*) l)->current->next;
    if (((struct llist*) l)->current == NO_ENTRY)
      ((struct llist*) l)->state = E_ENDOFLIST;
    else
      ((struct llist*) l)->state = E_OK;
  }
  else
    /* there is no current entry */
    ((struct llist*) l)->state = E_NOCURRENT;
}

/* PreviousEntry : */
/* set the current entry to the entry preceding the */
/* current entry in the list */

void PreviousEntry(list l)
{
  /* is there a current entry ? */
  if (((struct llist*) l)->current != NO_ENTRY)
  {
    ((struct llist*) l)->current =
      ((struct llist*) l)->current->prev;
    if (((struct llist*) l)->current == NO_ENTRY)
      ((struct llist*) l)->state = E_TOPOFLIST;
    else
      ((struct llist*) l)->state = E_OK;
  }
  else
    /* there is no current entry */
    ((struct llist*) l)->state = E_NOCURRENT;
}

/* InsertEntry : */
/* allocate a new entry, initialize it and put it behind */
/* the current entry in the list */

void InsertEntry(list l, void *data)
{
  struct entry *new; /* pointer to the new entry */

  /* is there a current entry ? */
  if (((struct llist*) l)->current != NO_ENTRY)
  {
    /* there is a current entry */
    /* allocate memory for a new entry */
    new = (struct entry*) malloc (sizeof(struct entry));
    if (new != NULL)
    {
      /* initialize the new entry */
      new->data = data;
      /* put it behind the current entry in the list */
      new->prev = ((struct llist*) l)->current;
      new->next = ((struct llist*) l)->current->next;
      ((struct llist*) l)->current->next = new;
      /* was the current entry the last in the list ? */
      if (new->next != NO_ENTRY)
        /* no */
        new->next->prev = new;
      else
        /* yes */
        ((struct llist*) l)->last = new;
      ((struct llist*) l)->state = E_OK;
    }
    else
      ((struct llist*) l)->state = E_NOMEM;
  }
  else
    /* there is no current entry */
    ((struct llist*) l)->state = E_NOCURRENT;
}

/* InsertEndEntry : */
/* allocate a new entry, initialize it and put it at the */
/* end of the list */

void InsertEndEntry(list l, void *data)
{
  struct entry *new; /* pointer to the new entry */

  /* allocate memory for a new entry */
  new = (struct entry*) malloc (sizeof (struct entry));
  if (new != NULL)
  {
    /* initialize the new entry */
    new->data = data;
    new->next = NO_ENTRY;
    /* and put it at the end of the list - */
    new->prev = ((struct llist*) l)->last;
    ((struct llist*) l)->last = new;
    /* is it not the only element in the list now ? */
    if (new->prev != NO_ENTRY)
      new->prev->next = new;
    else
      ((struct llist*) l)->first = new;
    /* all is ok */
    ((struct llist*) l)->state = E_OK;
  }
  else
    ((struct llist*) l)->state = E_NOMEM;
}

/* InsertBeginEntry : */
/* allocate a new entry, initialize it and put it at the */
/* beginning of the list */

void InsertBeginEntry(list l, void *data)
{
  struct entry *new; /* pointer to the new entry */

  /* allocate memory for a new entry */
  new = (struct entry*) malloc (sizeof(struct entry));
  if (new != NULL)
  {
    /* initialize the new entry */
    new->data = data;
    new->prev = NO_ENTRY;
    /* and put it at the beginning of the list */
    new->next = ((struct llist*) l)->first;
    ((struct llist*) l)->first = new;
    /* is it not the only element in the list now ? */
    if (new->next != NO_ENTRY)
      new->next->prev = new;
    else
       ((struct llist*) l)->last = new;
    /* all is ok */
    ((struct llist*) l)->state = E_OK;
  }
  else
    ((struct llist*) l)->state = E_NOMEM;
}

/* UpdateEntry : */
/* update the data of the current entry */

void UpdateEntry(list l, void *data)
{
  /* is there a current entry ? */
  if (((struct llist*) l)->current != NO_ENTRY)
  {
    /* there is a current entry */
    /* update data pointer */
    ((struct llist*) l)->current->data = data;
    ((struct llist*) l)->state = E_OK;
  }
  else
    /* there is no current entry */
    ((struct llist*) l)->state = E_NOCURRENT;
}

/* GetEntry : */
/* get the data of the current entry */

void *GetEntry(list l)
{
  /* is there a current entry ? */
  if (((struct llist*) l)->current != NO_ENTRY)
  {
    /* there is a current entry */
    return ((struct llist*) l)->current->data;
  }
  else
  {
    /* there is no current entry */
    ((struct llist*) l)->state = E_NOCURRENT;
    return NULL;
  }
}

/* DeleteEntry : */
/* remove the current entry from the list and free its */
/* data */

void DeleteEntry(list l)
{
  struct entry *e;

  /* is there a current entry ? */
  if (((struct llist*) l)->current != NO_ENTRY)
  {
    /* there is a current entry */
    /* is there a free function installed ? */
    if (((struct llist*) l)->free != NULL)
      ((struct llist*) l)->free
        (((struct llist*) l)->current->data);
    /* remove the current entry from the list - */
    e = ((struct llist*) l)->current;
    /* is it the first entry in the list ? */
    if (e->prev != NO_ENTRY)
      e->prev->next = e->next;
    else
      ((struct llist*) l)->first = e->next;
    /* is it the last entry in the list ? */
    if (e->next != NO_ENTRY)
      e->next->prev = e->prev;
    else
      ((struct llist*) l)->last = e->prev;
    /* free the current entry */
    free (e);
    /* there's no longer a current entry */
    ((struct llist*) l)->current = NO_ENTRY;
  }
  else
  {
    /* there is no current entry */
    ((struct llist*) l)->state = E_NOCURRENT;
  }
}

/* FindEntry : */
/* search from the beginning of the list a given entry */
/* therefor use the compare function p */

void FindEntry(list l, void *data, comp_t *p)
{
  struct entry *e;

  /* save the compare function for future use */
  ((struct llist *) l)->comp = p;
  /* search from the first entry on */
  e = ((struct llist *) l)->first;
  /* until the end of the list, or something found */
  while (e != NO_ENTRY)
  {
    /* compare the list-data with the search data */
    if (p (data, e->data) == 0)
    {
      /* oh hello, i found something wonderfull ... */
      ((struct llist *) l)->state = E_FOUND;
      return;
    }
    /* sorry, nothing found, try the next one */
    e = e->next;
  }
  /* oh god, really nothing found ? */
  ((struct llist *) l)->state = E_NOTFOUND;
}

/* FindNextEntry : */
/* search from the current entry of the list a given */
/* entry. Therefor use the compare function p */

void FindNextEntry(list l, void *data, comp_t *p)
{
  struct entry *e;

  /* save the compare function for future use */
  ((struct llist *) l)->comp = p;
  /* search from the next entry on */
  NextEntry (l);
  e = ((struct llist *) l)->current;
  /* until the end of the list, or something found */
  while (e != NO_ENTRY)
  {
    /* compare the list-data with the search data */
    if (p (data, e->data) == 0)
    {
      /* something found */
      ((struct llist *) l)->state = E_FOUND;
      return;
    }
    /* nothing found */
    e = e->next;
  }
  /* nothing found at all */
  ((struct llist *) l)->state = E_NOTFOUND;
}

/* GetListState : */
/* return the state of the last operation done on this */
/* list */

int GetListState(list l)
{
  return ((struct llist*) l)->state;
}

/* GetListPosition: */

void *GetListPosition(list l)
{
  return ((struct llist*) l)->current;
}

/* SetListPosition: */

void SetListPosition(list l, void *p)
{
  ((struct llist*) l)->current = (struct entry *) p;
  if (p != NULL)
  {
    ((struct llist *) l)->state = E_OK;
  }
  else
  {
    ((struct llist *) l)->state = E_ENDOFLIST;
  }
}

