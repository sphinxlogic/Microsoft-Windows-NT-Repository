/* ========================================================================== */
/*                                                                            */
/* Filename:     cursor.h                         +-----+-----+--+--+--+--+   */
/* Version :     1.2	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/9/92	10:24:53	                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Definition of the cursors used by SketchPad                           */
/*                                                                            */
/*      Cursors are changed by SetWaitState while doing complex operations    */
/*                                                                            */
/* ========================================================================== */

Cursor      draw_mode_cursor;    /* used in setdraw.c */
Cursor      zoom_cursor;         /* used in dzoom.c */
Cursor      size_cursor;         /* used in dselector.c */
Cursor      grab_cursor;         /* used in grab.c */




