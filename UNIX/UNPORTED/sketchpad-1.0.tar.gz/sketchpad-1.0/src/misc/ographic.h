/*
 *  ographic.h
 *
 *  structur-storage for object orientied graphics
 *
 */

#ifndef __OGRAPHIC_H
#define __OGRAPHIC_H

#include <Mrm/MrmAppl.h>

/* exported constants */

#define GP_LINE       1
#define GP_FREEHAND   2
#define GP_TEXT       3
#define GP_RECTANGLE  4
#define GP_ARC        5

#define ST_NONE   0
#define ST_PICKED 1

/* types */

typedef void *struct_storage;
typedef void *object;

/* functions */

/* CreateSS: */
/* create a new structure-store */

extern struct_storage CreateSS(void);

/* FreeSS: */
/* free a structure-store */

extern void FreeSS(struct_storage);

/* SetTransformation: */
/* set the transformation applied to the objects on drawing */

extern void SetTransformation(struct_storage, int, int);

/* InsertLine: */
/* insert a GP_LINE object to the structure store */

extern void InsertLine(struct_storage, int, int, int, int,
                       unsigned int, unsigned int, int, int);

/* InsertFreehand: */

extern object InsertFreehand(struct_storage, int, int,
                             unsigned int, unsigned int, int, int);

/* AppendLineSegment: */

extern void AppendLineSegment(void*, int, int);

/* InsertText: */
/* insert a GP_TEXT object to the structure store */

extern void InsertText(struct_storage, int, int,
                       int, int, char*, int, int, int, int, int);

/* InsertRectangle: */
/* insert a GP_RECTANGLE object to the structure store */

void InsertRectangle(struct_storage,
                     int, int,
                     unsigned int, unsigned int,
                     unsigned int, unsigned int,
                     int, int);

/* InsertArc: */
/* insert a GP_ARC object to the structure store */

void InsertArc (struct_storage,
                int, int,
                unsigned int, unsigned int,
                int, int,
                unsigned int, unsigned int,
                int, int);


/* DrawStructure: */
/* draw all objects in the stucture store */

extern void DrawStructure(struct_storage, XRectangle);

/* PickObject: */
/* take the nearest object to (x, y) and toggle the pick-state. */
/* if the pick-state from a object has changed, then redraw it */

extern void PickObject(struct_storage, object);

/* FindObject: */

extern object FindObject(struct_storage, int, int);

/* DeselectAll: */

extern void DeselectAll(struct_storage);

/* DeselectAllExceptOne: */

extern void DeselectAllExceptOne (struct_storage, object);

/* PickObjectArea: */

extern void PickObjectArea (struct_storage, int, int, int, int);

/* ObjectState: */

extern int ObjectState(object);

/* ObjectType: */

extern int ObjectType(object);

/* GetObjectBoundingBox: */

extern void GetObjectBoundingBox (object, int*, int*, int*, int*);

/* MoveObject: */

extern void MoveObject (struct_storage, void*, int, int);

/* DeletePickedObjects: */

extern void DeletePickedObjects (struct_storage);

/* GetFirstObj: */

extern object GetFirstObj (struct_storage);

/* GetFirstPickedObj: */

extern object GetFirstPickedObj (struct_storage);

/* GetNextObj: */

extern object GetNextObj (struct_storage);

/* GetNextPickedObj: */

extern object GetNextPickedObj (struct_storage);

/* SizeObject: */

extern void SizeObject (struct_storage, object, int, int, int, int);

/* DeleteObject: */

extern void DeleteObject (struct_storage, object);

/* GetObjectId: */

extern void GetObjectId (object, int*, int*);

/* GetObject: */

extern object GetObject (struct_storage, int, int);

/* ReadObject: */

extern void ReadObject (object, char*);

/* WriteObjects: */

extern void WriteObjects (struct_storage, char*, int, int*);

extern char *GetText (object o);
 
extern void StoreTextObject (object o);
 
extern void GetTextObject (object *o);
 
extern void GetTextEntry (int *x1, int *y1, int *fsize, int *fthick, int *fslant);
 
#endif /* __OGRAPHIC_H */

