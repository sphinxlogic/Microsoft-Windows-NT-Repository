/*
 *  list.h
 *
 *  a modul to handle lists of generic objects
 *
 */

#define E_OK        0 /* no error occured */
#define E_NYI       1 /* function not yet implemented */
#define E_NOMEM     2 /* no more memory to allocate */
#define E_TOPOFLIST 3 /* the function PreviousEntry has */
                      /* reached the top of the list */
#define E_ENDOFLIST 4 /* the function NextEntry has */
                      /* reached the end of the list */
#define E_NOCURRENT 5 /* there is no current entry to */
                      /* deal with */
#define E_FOUND     6 /* found something */
#define E_NOTFOUND  7 /* found nothing */

/* types */

typedef void* list;
typedef int comp_t(void*, void*);
typedef void free_t(void*);

/* functions */

/* CreateList : */
/* allocate and initialize a new list instance */

extern list CreateList (void);

/* SetFreeFunction : */
/* set the free function for this list */

void SetFreeFunction(list, free_t*);

/* FreeList : */
/* free the entire list including all entrys and the */
/* assigned data */

extern void FreeList (list);

/* FirstEntry : */
/* set the current entry to the first entry on the list */

extern void FirstEntry (list);

/* LastEntry : */
/* set the current entry to the last entry on the list */

extern void LastEntry (list);

/* NextEntry : */
/* set the current entry to the next entry following the */
/* current entry in the list */

extern void NextEntry (list);

/* PreviousEntry : */
/* set the current entry to the entry preceding the */
/* current entry in the list */

extern void PreviousEntry (list);

/* InsertEntry : */
/* allocate a new entry, initialize it and put it behind */
/* the current entry in the list */

extern void InsertEntry (list, void*);

/* InsertEndEntry : */
/* allocate a new entry, initialize it and put it at the */
/* end of the list */

extern void InsertEndEntry (list, void*);

/* InsertBeginEntry : */
/* allocate a new entry, initialize it and put it at the */
/* beginning of the list */

extern void InsertBeginEntry (list, void*);

/* UpdateEntry : */
/* update the data of the current entry */

extern void UpdateEntry(list, void*);

/* GetEntry : */
/* get the data of the current entry */

extern void *GetEntry(list);

/* DeleteEntry : */
/* remove the current entry from the list and free its */
/* data */

extern void DeleteEntry (list);

/* FindEntry : */
/* search from the beginning of the list a given entry */
/* therefor use the compare function p */

extern void FindEntry (list, void*, comp_t*);

/* FindNextEntry : */
/* search from the current entry of the list a given */
/* entry. Therefor use the compare function p */

extern void FindNextEntry (list, void*, comp_t*);

/* GetListState: */
/* return the state of the last operation done on this */
/* list */

extern int GetListState(list l);

/* GetListPosition: */

extern void *GetListPosition(list l);

/* SetListPosition: */

extern void SetListPosition(list l, void *p);
