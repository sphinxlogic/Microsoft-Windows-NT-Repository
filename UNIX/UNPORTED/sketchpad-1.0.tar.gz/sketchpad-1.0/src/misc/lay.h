/*
 *  lay.h
 *
 *  modul to manage the layers of the sketchpad in the
 *  main-process
 *
 */

#ifndef __LAY_H
#define __LAY_H

#include "ogr.h"

void InitLayers (void);
void AddLayer (char *layer_name, int layer_id, int sketch_id);
void RemoveLayer (int layer_id, int sketch_id);
void RenameLayer (char *layer_name, int layer_id, int sketch_id);
int GetFirstLayer (char **layer_name, int *layer_id, int *sketch_id);
int GetNextLayer (char **layer_name, int *layer_id, int *sketch_id);
struct_storage GetStructStorage (int layer_id, int sketch_id);
int ClearLayer (int layer_id, int sketch_id);

#endif /* __LAY_H */
