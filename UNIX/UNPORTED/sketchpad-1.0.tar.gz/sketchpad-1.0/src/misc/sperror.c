/* ========================================================================== */
/*                                                                            */
/* Filename:     sperror.c                        +-----+-----+--+--+--+--+   */
/* Version :     1.2	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/9/92	10:24:31	                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Module    : main for usage of uil user interface definition           */
/*                                                                            */
/*      Functions : sperror for printing run-time-errors and warnings in      */
/*                  a special subwindow                                       */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      DEFINE  STATEMENTS                                                    */
/* ========================================================================== */

#define ERROR_LIST_MAX 10

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <stdio.h>

#include <Xm/List.h>

#include "../ui/sketchpad.h"
#include "../ui/defs.h"

/* ========================================================================== */
/*      GLOBAL VARIABLES                                                      */
/* ========================================================================== */

static int      list_top =  0;            /* number of entries in error list */
static XmString string[ERROR_LIST_MAX+1]; /* XmStrings for error list        */

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  CreateErrorList                                          */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  Creates an error list in error subwindow                 */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  error_proc                                               */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void CreateErrorList (Widget w)
{
  int i;
  Arg args[1];

  if (w != NULL)
  {
    XtSetArg (args[0], XmNitemCount, 0);
    XtSetValues (w, args, 1);
    for (i=0; i < list_top; i++)
    {
      XmListAddItem (w, string[i], 0);
    }
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  AddErrorListEntry                                        */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  Adds a line in error subwindow                           */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  error_proc                                               */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void AddErrorListEntry (Widget w, char *text)
{
  int i;
  Arg args[1];

  string[list_top] = XmStringCreateLtoR (text, XmSTRING_DEFAULT_CHARSET);
  XmListAddItem (w, string[list_top], 0);

  if (list_top > ERROR_LIST_MAX - 1)
  {
    list_top = ERROR_LIST_MAX - 1;
    XmListDeleteAllItems(w);
    XtSetArg (args[0], XmNitemCount, 0);
    XtSetValues (w, args, 1);
    for (i=0; i <= list_top; i++)
    {
      XmStringFree(string[i]);
      string[i] = XmStringCopy(string[i+1]);
      XmListAddItem (w, string[i], 0);
    }
  }
  list_top++;
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  sperror                                                  */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  handling of errors (all errors are fatal)                */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  various other proc's                                     */
/*                                                                            */
/*      Calls     :  AddErrorListEntry, CreateErrorList                       */
/*                                                                            */
/* ========================================================================== */
void sperror (char *problem_string)
{
  if (widget_array[v_error_box] == NULL)
  {
    if (MrmFetchWidget(s_MrmHierarchy,
                        "c_error_box",
                        toplevel_widget,
                        &widget_array[v_error_box],
                        &dummy_class) != MrmSUCCESS)
    {
      fprintf(stderr,"can`t fetch ERROR-box !\n");
    }
    XtManageChild(widget_array[v_error_box]);
    CreateErrorList(widget_array[v_error_box_error_list]);
  }
  AddErrorListEntry(widget_array[v_error_box_error_list], problem_string);
}

