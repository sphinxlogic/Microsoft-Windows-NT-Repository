/* ========================================================================== */
/*                                                                            */
/* Filename:     lay.c                            +-----+-----+--+--+--+--+   */
/* Version :     1.2	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/9/92	10:23:55	                      */
/*                                                                            */
/* ========================================================================== */

#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include "list.h"
#include "ogr.h"

#define LAYERNAMELEN 20
#define ERR(x) fprintf (stderr, __FILE__ "(%d): %s\n", __LINE__, x);

struct layer_s
{
  char           layer_name[LAYERNAMELEN];
  int            layer_id;
  int            sketch_id;
  struct_storage ss;
};

static list layerList;

void InitLayers (void)
{
  layerList = CreateList ();
}

void AddLayer (char *layer_name, int layer_id, int sketch_id)
{
  struct layer_s *l;

  l = (struct layer_s*) malloc (sizeof (struct layer_s));
  if (l == NULL)
  {
    ERR ("cannot alloc memory");
    return;
  }
  strcpy (l->layer_name, layer_name);
  l->layer_id  = layer_id;
  l->sketch_id = sketch_id;
  l->ss        = CreateSS ();
  InsertEndEntry (layerList, l);
}

void RemoveLayer (int layer_id, int sketch_id)
{
  struct layer_s *l;

  FirstEntry (layerList);
  l = GetEntry (layerList);
  while (l != NULL)
  {
    if ((l->layer_id == layer_id) && (l->sketch_id == sketch_id))
    {
      FreeSS (l->ss);
      DeleteEntry (layerList);
      return;
    }
    NextEntry (layerList);
    l = GetEntry (layerList);
  }
}

void RenameLayer (char *layer_name, int layer_id, int sketch_id)
{
  struct layer_s *l;

  FirstEntry (layerList);
  l = GetEntry (layerList);
  while (l != NULL)
  {
    if ((l->layer_id == layer_id) && (l->sketch_id == sketch_id))
    {
      strcpy (l->layer_name, layer_name);
      return;
    }
    NextEntry (layerList);
    l = GetEntry (layerList);
  }
}

int GetFirstLayer (char **layer_name, int *layer_id, int *sketch_id)
{
  struct layer_s *l;

  FirstEntry (layerList);
  l = GetEntry (layerList);
  if (l != NULL)
  {
    *layer_name = l->layer_name;
    *layer_id   = l->layer_id;
    *sketch_id  = l->sketch_id;
    return 1;
  }
  else
  {
    return 0;
  }
}

int GetNextLayer (char **layer_name, int *layer_id, int *sketch_id)
{
  struct layer_s *l;

  NextEntry (layerList);
  l = GetEntry (layerList);
  if (l != NULL)
  {
    *layer_name = l->layer_name;
    *layer_id   = l->layer_id;
    *sketch_id  = l->sketch_id;
    return 1;
  }
  else
  {
    return 0;
  }
}

struct_storage GetStructStorage (int layer_id, int sketch_id)
{
  struct layer_s *l;
  void *pos;

  pos = GetListPosition (layerList);
  FirstEntry (layerList);
  do
  {
    l = GetEntry (layerList);
    if (l == NULL) return NULL;
    NextEntry (layerList);
  } while ((l->layer_id != layer_id) || (l->sketch_id != sketch_id));
  SetListPosition (layerList, pos);
  return (struct_storage) l->ss;
}

/* ClearLayer: */

int ClearLayer (int layer_id, int sketch_id)
{
  void            *obj;
  struct_storage  ss;
  void            *listpos;

  listpos = GetListPosition (layerList);
  ss = GetStructStorage (layer_id, sketch_id);

  obj = GetFirstObj (ss);
  while (obj != NULL)
  {
    DeleteObject (ss, obj);
    obj = GetFirstObj (ss);
  }
  SetListPosition (layerList, listpos);
  return(1);
} /* ClearLayer */

