/* ========================================================================== */
/*                                                                            */
/* Filename:     ISCsend.c                        +-----+-----+--+--+--+--+   */
/*                                                !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Arbeitsgruppe         !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-AGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               W-6100 Darmstadt, F. R. Germany  +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-AGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Creation Date        : 29.06.1991 by Manfred G. Schendel              */
/*      Last Modification    : 01.07.1991 by Manfred G. Schendel              */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Modification List    :                                                */
/*                                                                            */
/*      Date        Author      Modification made                             */
/*                                                                            */
/*      01.07.1991  MS          redesign and validation                       */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

# include <stdio.h>
# include <string.h>
# include <malloc.h>
# include <fcntl.h>
# include <unistd.h>
# include <sys/types.h>
# include <sys/time.h>
# include <sys/socket.h>
# include <netinet/in.h>
# include <netdb.h>

# include "ISCdefinitions.h"

/* ========================================================================== */

# define ERROR -1

# define ERR(x) fprintf (stderr, __FILE__ "(%d): %s\n", __LINE__, x);

extern isc_record isc_con[ISC_MAX_CONNECTIONS];
extern long int errno;
extern void ISCmsg(int,char*,char*);

/* ========================================================================== */

long int ISCsend (long int channel, char *buffer, long int nob)

{
  /***** local variables *****/
  unsigned char cnob[sizeof (long int)];
  unsigned char info[10];
  long int      status;
  long int      sent;
  char          msg[128];

  if ((channel < 0) || (channel >= ISC_MAX_CONNECTIONS))
  {
    ISCmsg (0, "ISCsend", "wrong channel number specified!");
    return ERROR;
  }

  if (isc_con[channel].alive != TRUE)
  {
    ISCmsg (0, "ISCsend", "specified channel not functional!");
    return ERROR;
  }

  sent = 0;

  while (sent < nob)
  {
    status = write (isc_con[channel].socket, &buffer[sent], nob - sent);

    if (status > 0)
    {
      sent += status;
    }
    else
    {
      if (status == -1)
      {
/*        sleep (1); */
          sent = 0;
          break;
      }
    }
  }

  return sent;
} /* end of ISCsend */

/* end of ISCsend.c */
