/* ========================================================================== */
/*                                                                            */
/* Filename:     ISCgetdevice.c                   +-----+-----+--+--+--+--+   */
/*                                                !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Arbeitsgruppe         !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-AGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               W-6100 Darmstadt, F. R. Germany  +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-AGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      ---------------------------------                     */
/*                                                                            */
/*      Creation Date        : 11.09.1991 by Manfred G. Schendel              */
/*      Last Modification    : 11.09.1991 by Manfred G. Schendel              */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Modification List    :                                                */
/*                                                                            */
/*      Date        Author      Modification made                             */
/*                                                                            */
/*      11.09.1991  MS          new AppAddInput                               */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

# include <stdio.h>
# include <string.h>
# include <malloc.h>
# include <fcntl.h>
# include <unistd.h>
# include <sys/types.h>
# include <sys/time.h>
# include <sys/socket.h>
# include <sys/errno.h>
# include <netinet/in.h>
# include <netdb.h>

# include "ISCdefinitions.h"

/* ========================================================================== */

# define ERR(x) fprintf (stderr, __FILE__ "(%d): %s\n", __LINE__, x);

extern isc_record isc_con[ISC_MAX_CONNECTIONS];
extern int errno;
extern void ISCmsg(int,char*,char*);

/* ========================================================================== */

long int ISCgetdevice (long int channel) 

{
  /***** local variables *****/
  char          msg[128];

  if ((channel < 0) || (channel >= ISC_MAX_CONNECTIONS))
  {
    ISCmsg (0, "ISCgetdevice", "wrong channel number specified!");
    return ERROR;
  }

  if (isc_con[channel].alive != TRUE)
  {
    ISCmsg (0, "ISCgetdevice", "specified channel not functional!");
    return ERROR;
  }

  return isc_con[channel].socket;

} /* end of ISCgetdevice */

/* end of ISCgetdevice.c */
