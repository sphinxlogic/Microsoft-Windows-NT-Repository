/* ========================================================================== */
/*                                                                            */
/* Filename:     ISCselect.c                      +-----+-----+--+--+--+--+   */
/*                                                !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Arbeitsgruppe         !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-AGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               W-6100 Darmstadt, F. R. Germany  +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-AGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Creation Date        : 29.06.1991 by Manfred G. Schendel              */
/*      Last Modification    : 01.07.1991 by Manfred G. Schendel              */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Modification List    :                                                */
/*                                                                            */
/*      Date        Author      Modification made                             */
/*                                                                            */
/*      01.07.1991  MS          redesign and validation                       */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

# include <stdio.h>
# include <string.h>
# include <malloc.h>
# include <fcntl.h>
# include <unistd.h>
# include <sys/types.h>
# include <sys/time.h>
# include <sys/socket.h>
# ifdef _AIX
# include <sys/select.h>
# endif
# include <netinet/in.h>
# include <netdb.h>

# include "ISCdefinitions.h"

/* ========================================================================== */

# define ERROR -1

extern isc_record isc_con[ISC_MAX_CONNECTIONS];
extern long int errno;
extern void ISCmsg(int,char*,char*);

/* ========================================================================== */

long int ISCselect (void)

{
  /***** local variables *****/
  long int i;
  fd_set   read_socket_mask;
  fd_set   return_mask;
  long int status;

  ISCmsg (2, "ISCselect", "select next channel ready for reading");

  /***** create read socket mask *****/
  FD_ZERO (&read_socket_mask);

  for (i = 0; i < ISC_MAX_CONNECTIONS; i ++)
  {
    if (isc_con[i].alive == TRUE)
    {
      FD_SET (isc_con[i].socket, &read_socket_mask);
    }
  }

  status = select (32, &read_socket_mask, NULL, NULL, NULL);

  if (status <= 0)
  {
    ISCmsg (0, "ISCselect", "error at select system call!");
    return ERROR;
  }
  
  for (i = 0; i < ISC_MAX_CONNECTIONS; i ++)
  {
    if (FD_ISSET (isc_con[i].socket, &read_socket_mask))
    {
      return i;
    }
  }

  return ERROR;

} /* end of ISCselect */

/* end of ISCselect.c */
