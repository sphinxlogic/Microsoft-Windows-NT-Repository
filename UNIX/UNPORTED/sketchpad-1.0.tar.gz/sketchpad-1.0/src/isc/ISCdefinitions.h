/* ========================================================================== */
/*                                                                            */
/* Filename:     ISCdefinitions.h                 +-----+-----+--+--+--+--+   */
/*                                                !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Arbeitsgruppe         !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-AGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               W-6100 Darmstadt, F. R. Germany  +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-AGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      ---------------------------------                     */
/*                                                                            */
/*      Creation Date        : 20.06.1991 by Manfred G. Schendel              */
/*      Last Modification    : 01.07.1991 by Manfred G. Schendel              */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Modification List    :                                                */
/*                                                                            */
/*      Date        Author      Modification made                             */
/*                                                                            */
/*      01.07.1991  MS          redesign and validation                       */
/*                                                                            */
/* ========================================================================== */

/*
 * Brief description:
 * ------------------
 *
 * This file contains all global types and definition of the ISC interface.
 * The file should be included into all source codes of the ISC functions.
 */

# ifndef _AIX
# define FALSE  0
# define TRUE   !FALSE
# endif

# define ISC_MAX_CONNECTIONS  10
# define ERROR -1


typedef long int boolean;

typedef struct
{
  boolean            free;
  long int           portnumber;
  long int           internetnumber;
  char               *hostname[20];
  long int           socket;
  struct sockaddr_in ip_addr;
  long int           pid;
  boolean            alive;
} isc_record;

/* end of ISCdefinitions.h */
