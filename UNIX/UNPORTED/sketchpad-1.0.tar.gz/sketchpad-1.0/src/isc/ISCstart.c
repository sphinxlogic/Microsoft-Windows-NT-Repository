/* ========================================================================== */
/*                                                                            */
/* Filename:     ISCstart.c                       +-----+-----+--+--+--+--+   */
/*                                                !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Arbeitsgruppe         !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-AGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               W-6100 Darmstadt, F. R. Germany  +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-AGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Creation Date        : 15.04.1991 by Manfred G. Schendel              */
/*      Last Modification    : 21.11.1991 by Manfred G. Schendel              */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Modification List    :                                                */
/*                                                                            */
/*      Date        Author      Modification made                             */
/*                                                                            */
/*      16.05.1991  MS          remote SketchPad start by inetd               */
/*      21.11.1991  MS          SPserver service added                        */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

# include <stdio.h>
# include <string.h>
# include <malloc.h>
# include <fcntl.h>
# include <unistd.h>
# include <sys/types.h>
# include <sys/time.h>
# include <sys/socket.h>
# include <sys/errno.h>
# include <netinet/in.h>
# include <netdb.h>

# include "ISCdefinitions.h"

/***** the registered services ***********************************************/

# define  UNKNOWN   0
# define  SKETCHPAD 1
# define  SPSERVER  2

/* ========================================================================== */

extern isc_record isc_con[ISC_MAX_CONNECTIONS];
extern void ISCmsg(int,char*,char*);
extern void ISCsyserr(int,char**);

# ifdef HP
extern int      errno;
# else
extern      int errno;
# endif

/* ========================================================================== */


long int sendINetD (char *hostname, char *message)

{
  /***** local variables *****/
  struct servent     *spservice;
  struct hostent     *hostdata;
  struct sockaddr_in address;
  long int   s;
  long int   status;


  spservice = getservbyname ("sketchpad", "tcp");
  if (spservice == NULL)
  {
    ISCmsg (0, "ISCstart/sendINetD", "Call to getservbyname failed!\n");
    return (-1);
  }

  s = socket (AF_INET, SOCK_STREAM, 0);
  if (s < 0)
  {
    ISCmsg (0, "ISCstart/sendINetD", "Call to socket failed!\n");
    return -1;
  }

  address.sin_port = spservice->s_port;
  hostdata = gethostbyname (hostname);
  if (hostdata == NULL)
  {
    ISCmsg (0, "ISCstart/sendINetD", "Call to gethostbyname failed!\n");
    return -1;
  }

  address.sin_family = hostdata->h_addrtype;
  bcopy (hostdata->h_addr, (caddr_t) &address.sin_addr, hostdata->h_length);

  status = connect (s, &address, sizeof (address));
  if (status < 0)
  {
    ISCmsg (0, "ISCstart/sendINetD", "Call to connect failed!\n");
    return -1;
  }

  status = write (s, message, strlen (message));

  if (status != strlen (message))
  {
    ISCmsg (0, "ISCstart/sendINetD", "Call to write failed!\n");
    return -1;
  }

  close (s);
  return(0);
}

/* ========================================================================== */

/*
 * This function starts up a new process for the specified service
 * on the requested host and connects it by a network channel.
 * The parameters given are passed to the command line parameters
 * of the new process.
 */

long int ISCstart (char *servicename, char *hostname, char *parameters)

{
  /***** local variables *****/
  char           *localhostn[80];
  struct servent *service_info;
  struct hostent *hostdata;
  char           *msg;
  long int       connection;
  long int       i;
  long int       status;
  long int       s;
  char           connect_id[80];
  long int       portnumber;
  long int       service;

  msg = (char *) malloc (80 * sizeof (char));

  ISCmsg (2, "ISCstart", "spawning a new process");

  /***** check parameters *****/

  /* 1. Was a known service specified? */

  service = UNKNOWN;
  if (!strcmp ("sketchpad", servicename)) service = SKETCHPAD;
  if (!strcmp ("SPserver", servicename)) service = SPSERVER;

  if (service == UNKNOWN)
  {
    ISCmsg (0, "ISCstart", 
      "An unknown service had been specified to the communication interface");
    return ERROR;
  }

  /***** if service = SPSERVER, the process must run in the same host *****/
  gethostname (localhostn, 80);
  /* printf ("local host %s, host name given %s\n", localhostn, hostname); */
  if (service == SPSERVER)
  {
    if (strcmp ((char *) localhostn, (char *) hostname))
    {
      ISCmsg (0, "ISCstart",
	"SPserver must run on the same host!");
    }
  }

  /* 2. Is the given hostname known to that system? */

  hostdata = gethostbyname (hostname);

  if (hostdata == NULL)
  {
    ISCmsg (0, "ISCstart", "The specified hostname is not known to the network!");
    return ERROR;
  }

  /***** search for free channel *****/

  connection = -1;

  for (i = 0; i < ISC_MAX_CONNECTIONS; i ++)
  {
    if (isc_con[i].free)
    {
      isc_con[i].free = FALSE;
      connection = i;
      break;
    }
  }

  if (connection == -1)
  {
    ISCmsg (0, "ISCstart", "All connections channels are occupied!");
    return ERROR;
  }

  /***** get own host identification *****/

  hostdata = gethostbyname (localhostn);
  service_info = getservbyname ("sketchpad", "tcp");

  /***** create own network link *****/

  {
    /***** local variables *****/
    struct sockaddr_in inetaddr;
    char               buffer[129];
    long int           nob;
    long int           status;

    s = socket (AF_INET, SOCK_STREAM, 0);

    if (s <= 0)
    {
      ISCmsg (0, "ISCstart", "couldn't create socket");
      return ERROR;
    }

    nob = 0x8000L;
    status = setsockopt (s, SOL_SOCKET, SO_SNDBUF, &nob, sizeof (long int));

    if (status != 0)
    {
      ISCsyserr (errno, &msg);
      sprintf (buffer, "setsockopt failed; error code: %s", msg);
      ISCmsg (0, "ISCstart", buffer);
    }

    /* searching for next free TCP portnumber on that host */
    /* later, this should be taken from the service info record */
    portnumber = 5801 + 1;

    while (TRUE)
    {
      bzero ((char *) &inetaddr, sizeof (struct sockaddr_in));
      inetaddr.sin_family = AF_INET;
      bcopy (hostdata->h_addr, (caddr_t) &inetaddr.sin_addr, hostdata->h_length);
      inetaddr.sin_port = htons ((unsigned short int) portnumber);
      status = bind (s, &inetaddr, sizeof (inetaddr));

      if (status != 0)
      {
	/***** error = address already in use ? *****/
	if (errno == EADDRINUSE)
	{
	  portnumber ++;
	  continue;
	}

	ISCmsg (0, "ISCstart", "error at bind");
	return ERROR;
      }
      else
      {
	break;
      }
    }
  }

  /***** startup new process *****/

  if ((!strcmp ((char *) localhostn, (char *) hostname)) || (service == SPSERVER))
  {
    /***** start process on same machine *****/

    /***** local variables *****/
    long int pid;
    char     displayname[30];
    char     dummy[30];

    /* building connection id for child process */

    sprintf (connect_id, "%s/%ld", localhostn, portnumber);
    sscanf (parameters, "%[^/]/%s", dummy, displayname);

    pid = fork ();

    if (pid == -1)
    {
      ISCmsg (0, "ISCstart", "can't create new process");
      return (-1);
    }
    if (pid == 0) /* this is the child process */
    {
      switch (service)
      {
        case SKETCHPAD :
        {
#ifdef __OBJECTCENTER__
           execlp ("xobjectcenter", "xobjectcenter", " -display", displayname, 
	    connect_id, parameters, NULL);  
#else
	  execlp ("sketchpad", "sketchpad", "-display", displayname, 
	    connect_id, parameters, NULL); 
#endif
          break;
        }
        case SPSERVER :
        {
	  execlp ("SPserver", "SPserver", "-display", displayname, 
	    connect_id, parameters, NULL); 
          break;
        }
        default :
        {
          printf ("ISCstart: internal error 0815, please report!\n");
          break;
        }
      }
      return (0);
    }
    isc_con[connection].pid = pid;
  }
  else
  {
    /***** start new process on other machine via INetD *****/

    /***** local variables *****/
    char     string[256];
    char     displayname[30];
    char     dummy[30];
    long int status;

    if (service != SKETCHPAD)
    {
      printf ("ISCstart: internal error 0815A, please report!\n");
      return ERROR;
    }

    sscanf (parameters, "%[^/]/%s", dummy, displayname);
    sprintf (string, "sketchpad %s %s/%ld %s", 
      displayname, localhostn, portnumber, parameters);

    status = sendINetD (hostname, string);   
    if (status == -1)
    {
      return -1;
    }
    printf ("start: sendINetD successful!\n");

    sleep (5);   /***** wait for process to come up *****/

  }

  /***** connect channel to new process *****/

  {
    /***** local variables *****/
    long int addrlen;

    ISCmsg (2, "ISCstart", "listening for socket to accept ...");
    status = listen (s, 1);

    if (status != 0)
    {
      ISCsyserr (errno, &msg);
      ISCmsg (0, "ISCstart", "error at listen");
    }
    addrlen = sizeof (isc_con[i].ip_addr);
    isc_con[connection].socket = 
      accept (s, &isc_con[connection].ip_addr, &addrlen);
    isc_con[connection].alive = TRUE;

    if (status < 0)
    {
      ISCsyserr (errno, &msg);
      ISCmsg (0, "ISCstart", "error at accept");
      return ERROR;
    }
  }

  free (msg);
  return connection;

} /* end of ISCstart */

/* end of ISCstart.c */
