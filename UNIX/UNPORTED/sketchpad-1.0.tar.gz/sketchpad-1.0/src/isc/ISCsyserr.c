/* ========================================================================== */
/*                                                                            */
/* Filename:     ISCsyserr.c                      +-----+-----+--+--+--+--+   */
/*                                                !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Arbeitsgruppe         !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-AGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               W-6100 Darmstadt, F. R. Germany  +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-AGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Creation Date        : 15.04.1988 by Manfred G. Schendel              */
/*      Last Modification    : 01.07.1991 by Manfred G. Schendel              */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Modification List    :                                                */
/*                                                                            */
/*      Date        Author      Modification made                             */
/*                                                                            */
/*      12.02.1991  MS          extended for IBM AIX operating system         */
/*      01.07.1991  MS          redesign and validation                       */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

# include <stdio.h>
# include <string.h>
# include <malloc.h>
# include <fcntl.h>
# include <unistd.h>
# include <sys/types.h>
# include <sys/time.h>
# include <sys/socket.h>
# include <netinet/in.h>
# include <netdb.h>
# include <sys/errno.h>

# include "ISCdefinitions.h"

/******************************************************************************/

/*
 *
 * This function should support a clear text error message for
 * all system call errors of the following operating systems:
 *
 * 1. DECNet Ultrix-32 version 3.1     compiled with -Dvax
 * 2. SUN OS version 4.1.1             compiled with -Dsparc
 * 3. IBM AIX version 3.1.0            compiled with -D_AIX
 *
 */

void ISCsyserr (long int errno, char *text[])

{
  *text = "unknown system error";
  switch (errno)
  {
    case EPERM            /*  1 */ : {*text = "Not owner"; break;}
    case ENOENT           /*  2 */ : {*text = "No such file or directory"; break;}
    case ESRCH            /*  3 */ : {*text = "No such process";  break;}
    case EINTR            /*  4 */ : {*text = "Interrupted system call";  break;}
    case EIO              /*  5 */ : {*text = "I/O error";  break;}
    case ENXIO            /*  6 */ : {*text = "No such device or address";  break;}
    case E2BIG            /*  7 */ : {*text = "Arg list too long";  break;}
    case ENOEXEC          /*  8 */ : {*text = "Exec format error";  break;}
    case EBADF            /*  9 */ : {*text = "Bad file number";  break;}
    case ECHILD           /* 10 */ : {*text = "No children";  break;}
    case EAGAIN           /* 11 */ : {*text = "No more processes";  break;}
    case ENOMEM           /* 12 */ : {*text = "Not enough core";  break;}
    case EACCES           /* 13 */ : {*text = "Permission denied";  break;}
    case EFAULT           /* 14 */ : {*text = "Bad address";  break;}
    case ENOTBLK          /* 15 */ : {*text = "Block device required"; break;}
    case EBUSY            /* 16 */ : {*text = "Mount device busy"; break;}
    case EEXIST           /* 17 */ : {*text = "File exists"; break;}
    case EXDEV            /* 18 */ : {*text = "Cross-device link"; break;}
    case ENODEV           /* 19 */ : {*text = "No such device"; break;}
    case ENOTDIR          /* 20 */ : {*text = "Not a directory"; break;}
    case EISDIR           /* 21 */ : {*text = "Is a directory"; break;}
    case EINVAL           /* 22 */ : {*text = "Invalid argument"; break;}
    case ENFILE           /* 23 */ : {*text = "File table overflow"; break;}
    case EMFILE           /* 24 */ : {*text = "Too many open files"; break;}
    case ENOTTY           /* 25 */ : {*text = "Not a typewriter"; break;}
    case ETXTBSY          /* 26 */ : {*text = "Text file busy"; break;}
    case EFBIG            /* 27 */ : {*text = "File too large"; break;}
    case ENOSPC           /* 28 */ : {*text = "No space left on device"; break;}
    case ESPIPE           /* 29 */ : {*text = "Illegal seek"; break;}
    case EROFS            /* 30 */ : {*text = "Read-only file system"; break;}
    case EMLINK           /* 31 */ : {*text = "Too many links"; break;}
    case EPIPE            /* 32 */ : {*text = "Broken pipe"; break;}
    case EDOM             /* 33 */ : {*text = "Argument too large"; break;}
    case ERANGE           /* 34 */ : {*text = "Result too large"; break;}

# ifdef _AIX

    case ENOMSG           /* 35	*/ : {*text = "No message of desired type"; break;}
    case EIDRM	          /* 36	*/ : {*text = "Identifier removed"; break;}
    case ECHRNG	          /* 37	*/ : {*text = "Channel number out of range"; break;}
    case EL2NSYNC         /* 38	*/ : {*text = "Level 2 not synchronized"; break;}
    case EL3HLT	          /* 39	*/ : {*text = "Level 3 halted"; break;}
    case EL3RST	          /* 40	*/ : {*text = "Level 3 reset"; break;}
    case ELNRNG	          /* 41	*/ : {*text = "Link number out of range"; break;}
    case EUNATCH          /* 42	*/ : {*text = "Protocol driver not attached"; break;}
    case ENOCSI	          /* 43	*/ : {*text = "No CSI structure available"; break;}
    case EL2HLT           /* 44	*/ : {*text = "Level 2 halted"; break;}
    case EDEADLK          /* 45	*/ : {*text = "Resource deadlock avoided"; break;}
    case ENOTREADY        /* 46	*/ : {*text = "Device not ready"; break;}
    case EWRPROTECT	  /* 47	*/ : {*text = "Write-protected media"; break;}
    case EFORMAT	  /* 48	*/ : {*text = "Unformatted media"; break;}
    case ENOLCK	          /* 49 */ : {*text = "No locks available"; break;}
    case ENOCONNECT       /* 50 */ : {*text = "no connection"; break;}
    case ESTALE           /* 52 */ : {*text = "no filesystem"; break;}
    case EDIST		  /* 53 */ : {*text = "old, currently unused AIX errno"; break;}
    case EINPROGRESS      /* 55 */ : {*text = "Operation now in progress"; break;}
    case EALREADY         /* 56 */ : {*text = "Operation already in progress"; break;}
    case ENOTSOCK         /* 57 */ : {*text = "Socket operation on non-socket"; break;}
    case EDESTADDRREQ     /* 58 */ : {*text = "Destination address required"; break;}
    case EMSGSIZE         /* 59 */ : {*text = "Message too long"; break;}
    case EPROTOTYPE       /* 60 */ : {*text = "Protocol wrong type for socket"; break;}
    case ENOPROTOOPT      /* 61 */ : {*text = "Protocol not available"; break;}
    case EPROTONOSUPPORT  /* 62 */ : {*text = "Protocol not supported"; break;}
    case ESOCKTNOSUPPORT  /* 63 */ : {*text = "Socket type not supported"; break;}
    case EOPNOTSUPP       /* 64 */ : {*text = "Operation not supported on socket"; break;}
    case EPFNOSUPPORT     /* 65 */ : {*text = "Protocol family not supported"; break;}
    case EAFNOSUPPORT     /* 66 */ : {*text = "Address family not supported by protocol family"; break;}
    case EADDRINUSE       /* 67 */ : {*text = "Address already in use"; break;}
    case EADDRNOTAVAIL    /* 68 */ : {*text = "Can't assign requested address"; break;}
    case ENETDOWN         /* 69 */ : {*text = "Network is down"; break;}
    case ENETUNREACH      /* 70 */ : {*text = "Network is unreachable"; break;}
    case ENETRESET        /* 71 */ : {*text = "Network dropped connection on reset"; break;}
    case ECONNABORTED     /* 72 */ : {*text = "Software caused connection abort"; break;}
    case ECONNRESET       /* 73 */ : {*text = "Connection reset by peer"; break;}
    case ENOBUFS          /* 74 */ : {*text = "No buffer space available"; break;}
    case EISCONN          /* 75 */ : {*text = "Socket is already connected"; break;}
    case ENOTCONN         /* 76 */ : {*text = "Socket is not connected"; break;}
    case ESHUTDOWN        /* 77 */ : {*text = "Can't send after socket shutdown"; break;}
    case ETIMEDOUT        /* 78 */ : {*text = "Connection timed out"; break;}
    case ECONNREFUSED     /* 79 */ : {*text = "Connection refused"; break;}
    case EHOSTDOWN        /* 80 */ : {*text = "Host is down"; break;}
    case EHOSTUNREACH     /* 81 */ : {*text = "No route to host"; break;}
    case ERESTART	  /* 82	*/ : {*text = "restart the system call"; break;}
    case EPROCLIM	  /* 83	*/ : {*text = "Too many processes"; break;}
    case EUSERS		  /* 84	*/ : {*text = "Too many users"; break;}
    case ELOOP		  /* 85	*/ : {*text = "Too many levels of symbolic links"; break;}
    case ENAMETOOLONG	  /* 86	*/ : {*text = "File name too long"; break;}
    case EDQUOT		  /* 88	*/ : {*text = "Disc quota exceeded"; break;}
    case EREMOTE	  /* 93	*/ : {*text = "Item is not local to host"; break;}
    case ENOSYS		  /*109 */ : {*text = "Function not implemented  POSIX"; break;}
    case EMEDIA		  /*110 */ : {*text = "media surface error"; break;}
    case ESOFT            /*111 */ : {*text = "I/O completed, but needs relocation"; break;}
    case ENOATTR	  /*112 */ : {*text = "no attribute found"; break;}
    case ESAD		  /*113	*/ : {*text = "security authentication denied"; break;}
    case ENOTRUST	  /*114	*/ : {*text = "not a trusted program"; break;}
# else 
    case EINPROGRESS      /* 36 */ : {*text = "Operation now in progress"; break;}
    case EALREADY         /* 37 */ : {*text = "Operation already in progress"; break;}
    case ENOTSOCK         /* 38 */ : {*text = "Socket operation on non-socket"; break;}
    case EDESTADDRREQ     /* 39 */ : {*text = "Destination address required"; break;}
    case EMSGSIZE         /* 40 */ : {*text = "Message too long"; break;}
    case EPROTOTYPE       /* 41 */ : {*text = "Protocol wrong type for socket"; break;}
    case ENOPROTOOPT      /* 42 */ : {*text = "Protocol not available"; break;}
    case EPROTONOSUPPORT  /* 43 */ : {*text = "Protocol not supported"; break;}
    case ESOCKTNOSUPPORT  /* 44 */ : {*text = "Socket type not supported"; break;}
    case EOPNOTSUPP       /* 45 */ : {*text = "Operation not supported on socket"; break;}
    case EPFNOSUPPORT     /* 46 */ : {*text = "Protocol family not supported"; break;}
    case EAFNOSUPPORT     /* 47 */ : {*text = "Address family not supported by protocol family"; break;}
    case EADDRINUSE       /* 48 */ : {*text = "Address already in use"; break;}
    case EADDRNOTAVAIL    /* 49 */ : {*text = "Can't assign requested address"; break;}
    case ENETDOWN         /* 50 */ : {*text = "Network is down"; break;}
    case ENETUNREACH      /* 51 */ : {*text = "Network is unreachable"; break;}
    case ENETRESET        /* 52 */ : {*text = "Network dropped connection on reset"; break;}
    case ECONNABORTED     /* 53 */ : {*text = "Software caused connection abort"; break;}
    case ECONNRESET       /* 54 */ : {*text = "Connection reset by peer"; break;}
    case ENOBUFS          /* 55 */ : {*text = "No buffer space available"; break;}
    case EISCONN          /* 56 */ : {*text = "Socket is already connected"; break;}
    case ENOTCONN         /* 57 */ : {*text = "Socket is not connected"; break;}
    case ESHUTDOWN        /* 58 */ : {*text = "Can't send after socket shutdown"; break;}
    case ETOOMANYREFS     /* 59 */ : {*text = "Too many references: can't splice"; break;}
    case ETIMEDOUT        /* 60 */ : {*text = "Connection timed out"; break;}
    case ECONNREFUSED     /* 61 */ : {*text = "Connection refused"; break;}
    case ELOOP            /* 62 */ : {*text = "Too many levels of symbolic links"; break;}
    case ENAMETOOLONG     /* 63 */ : {*text = "File name too long"; break;}
    case EHOSTDOWN        /* 64 */ : {*text = "Host is down"; break;}
    case EHOSTUNREACH     /* 65 */ : {*text = "No route to host"; break;}
    case ENOTEMPTY        /* 66 */ : {*text = "Directory not empty"; break;}
    case EUSERS           /* 68 */ : {*text = "Too many users"; break;}
    case ESTALE           /* 70 */ : {*text = "NFS error code ESTALE"; break;}
    case EREMOTE          /* 71 */ : {*text = "NFS error code EREMOTE"; break;}
# ifdef vax
    case ENOMSG           /* 72 */ : {*text = "No message of desired type"; break;}
    case EIDRM            /* 73 */ : {*text = "Identifier removed"; break;}
    case EALIGN           /* 74 */ : {*text = "alignment error"; break;} 
    case ENOLCK           /* 75 */ : {*text = "LOCK_MAX exceeded"; break;}
# endif
# ifdef sparc
    case ENOSTR           /* 72 */ : {*text = "Device is not a stream"; break;}
    case ETIME            /* 73 */ : {*text = "Timer expired"; break;}
    case ENOSR            /* 74 */ : {*text = "Out of streams resources"; break;}
    case ENOMSG           /* 75 */ : {*text = "No message of desired type"; break;}
    case EBADMSG          /* 76 */ : {*text = "Trying to read unreadable message"; break;}
    case EIDRM            /* 77 */ : {*text = "Identifier removed"; break;}
    case EDEADLK          /* 78 */ : {*text = "Deadlock condition."; break;}
    case ENOLCK           /* 79 */ : {*text = "No record locks available."; break;}
    case ENONET           /* 80 */ : {*text = "Machine is not on the network"; break;}
    case ERREMOTE         /* 81 */ : {*text = "Object is remote"; break;}
    case ENOLINK          /* 82 */ : {*text = "the link has been severed"; break;}
    case EADV             /* 83 */ : {*text = "advertise error"; break;}
    case ESRMNT           /* 84 */ : {*text = "srmount error"; break;}
    case ECOMM            /* 85 */ : {*text = "Communication error on send"; break;}
    case EPROTO           /* 86 */ : {*text = "Protocol error"; break;}
    case EMULTIHOP        /* 87 */ : {*text = "multihop attempted"; break;}
    case EDOTDOT          /* 88 */ : {*text = "Cross mount point (not an error)"; break;}
    case EREMCHG          /* 89 */ : {*text = "Remote address changed"; break;}
    case ENOSYS           /* 90 */ : {*text = "function not implemented"; break;}
# endif
# endif
  }
} /* end of syserr */
