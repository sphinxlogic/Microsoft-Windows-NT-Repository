/* ========================================================================== */
/*                                                                            */
/* Filename:     ISCinit.c                        +-----+-----+--+--+--+--+   */
/*                                                !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Arbeitsgruppe         !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-AGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               W-6100 Darmstadt, F. R. Germany  +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-AGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      ---------------------------------                     */
/*                                                                            */
/*      Creation Date        : 18.06.1991 by Manfred G. Schendel              */
/*      Last Modification    : 01.07.1991 by Manfred G. Schendel              */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Modification List    :                                                */
/*                                                                            */
/*      Date        Author      Modification made                             */
/*                                                                            */
/*      01.07.1991  MS          redesign and validation                       */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

# include <stdio.h>
/* # include <stdlib.h> */
# include <string.h>
# include <malloc.h>
# include <fcntl.h>
# include <unistd.h>
# include <sys/types.h>
# include <sys/time.h>
# include <sys/socket.h>
# include <netinet/in.h>
# include <netdb.h>

# include "ISCdefinitions.h"

extern void ISCmsg (long int level, char *function, char *message);

/* ========================================================================== */

isc_record isc_con[ISC_MAX_CONNECTIONS];
FILE       *info;
boolean    debug;
long int   pid;

/* ========================================================================== */

void ISCinit ()

{
  /***** local variables *****/
  long int i;
  char     *buffer;

  for (i = 0; i < ISC_MAX_CONNECTIONS; i ++)
  {
    isc_con[i].free = TRUE;
    isc_con[i].alive = FALSE;
  }

  /***** some more debug information requested? *****/
  debug = FALSE;
  pid = getpid ();

  buffer = (char *) getenv ("ISCDEBUG");

  info = fopen (buffer, "w");

  if (info != NULL)
  {
    debug = TRUE;
    fprintf (stderr, "ISCinit: debug information send to file <%s>.\n", buffer);
  }
  ISCmsg (2, "ISCinit", "initialization successful");

} /* end of ISCinit */

/* end of ISCinit.c */
