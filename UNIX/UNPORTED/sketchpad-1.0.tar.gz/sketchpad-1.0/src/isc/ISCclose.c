/* ========================================================================== */
/*                                                                            */
/* Filename:     ISCclose.c                       +-----+-----+--+--+--+--+   */
/*                                                !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Arbeitsgruppe         !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-AGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               W-6100 Darmstadt, F. R. Germany  +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-AGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      ---------------------------------                     */
/*                                                                            */
/*      Creation Date        : 22.06.1991 by Manfred G. Schendel              */
/*      Last Modification    : 01.07.1991 by Manfred G. Schendel              */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Modification List    :                                                */
/*                                                                            */
/*      Date        Author      Modification made                             */
/*                                                                            */
/*      01.07.1991  MS          redesign and validation                       */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

# include <stdio.h>
# include <string.h>
# include <malloc.h>
# include <fcntl.h>
# include <unistd.h>
# include <sys/types.h>
# include <sys/time.h>
# include <sys/socket.h>
# include <netinet/in.h>
# include <netdb.h>
# include <signal.h>

# include "ISCdefinitions.h"

/* ========================================================================== */

extern isc_record isc_con[ISC_MAX_CONNECTIONS];
extern long int errno;
extern void ISCmsg(int,char*,char*);

/* ========================================================================== */

long int ISCclose (long int channel)

{
  ISCmsg (2, "ISCclose", "closing a channel ...");

  if ((channel < 0) || (channel >= ISC_MAX_CONNECTIONS))
  {
    ISCmsg (0, "ISCclose", "wrong channel number specified!");
    return ERROR;
  }

  if (isc_con[channel].alive != TRUE)
  {
    ISCmsg (0, "ISCclose", "specified channel not functional!");
    return ERROR;
  }

  close (isc_con[channel].socket);
  isc_con[channel].alive = FALSE;

} /* end of ISCclose */

/* end of ISCclose.c */
