/* ========================================================================== */
/*                                                                            */
/* Filename:     ISCaccept.c                      +-----+-----+--+--+--+--+   */
/*                                                !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Arbeitsgruppe         !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-AGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               W-6100 Darmstadt, F. R. Germany  +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-AGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      ---------------------------------                     */
/*                                                                            */
/*      Creation Date        : 29.06.1991 by Manfred G. Schendel              */
/*      Last Modification    : 01.07.1991 by Manfred G. Schendel              */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Modification List    :                                                */
/*                                                                            */
/*      Date        Author      Modification made                             */
/*                                                                            */
/*      01.07.1991  MS          redesign and validation                       */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

# include <stdio.h>
# include <string.h>
# include <malloc.h>
# include <fcntl.h>
# include <unistd.h>
# include <sys/types.h>
# include <sys/time.h>
# include <sys/socket.h>
# include <netinet/in.h> 
# include <netdb.h>

# include "ISCdefinitions.h"
# include "ISCglobals.h"
/* ========================================================================== */

extern isc_record isc_con[ISC_MAX_CONNECTIONS];
long int ISCaccept (char *parameter)

{
  /***** local variables *****/
  long int            status;
  struct hostent      *hostdata;
  struct sockaddr_in  addr;
  char                *hostname[20];
  long int            portnumber;
  long int            channel;
  long int            i;
  long int            s;
  char                *msg;
  char                buffer[129];
  long int            nob;

  msg = (char *) malloc (80 * sizeof (char));

  /***** get connection information from parameter string *****/
  sscanf (parameter, "%[^/]/%ld", hostname, &portnumber);

  /***** search for a free channel *****/
  channel = -1;

  for (i = 0; i < ISC_MAX_CONNECTIONS; i ++)
  {
    if (isc_con[i].free)
    {
      isc_con[i].free = FALSE;
      channel = i;
      break;
    }
  }

  if (channel == -1)
  {
    ISCmsg (0, "ISCaccept", "no more free channel available!");
    return ERROR;
  }

  bzero (&addr, sizeof (struct sockaddr_in));
  hostdata = gethostbyname (hostname);
  addr.sin_family = hostdata->h_addrtype;
  bcopy (hostdata->h_addr, (caddr_t) &addr.sin_addr, hostdata->h_length);
  addr.sin_port = htons ((unsigned short int) portnumber);

  s = socket (AF_INET, SOCK_STREAM, 0);

  nob = 0x8000L;
  status = setsockopt (s, SOL_SOCKET, SO_SNDBUF, &nob, sizeof (long int));

  if (status != 0)
  {
    ISCsyserr (errno, &msg);
    sprintf (buffer, "setsockopt failed; error code: %s", msg);
    ISCmsg (0, "ISCaccept", buffer);
  }

  status = connect (s, &addr, sizeof (addr));

  if (status != 0)
  {
    ISCsyserr (errno, &msg);
    ISCmsg (0, "ISCaccept", "could not accept connection");
    return ERROR;
  }

  isc_con[channel].socket = s;
  isc_con[channel].alive = TRUE;

  free (msg);
  return channel;
} /* end of ISCaccept */

/* end of ISCaccept.c */
