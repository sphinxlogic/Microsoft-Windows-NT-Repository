/* ========================================================================== */
/*                                                                            */
/* Filename:     ISCrecv.c                        +-----+-----+--+--+--+--+   */
/*                                                !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Arbeitsgruppe         !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-AGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               W-6100 Darmstadt, F. R. Germany  +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-AGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Creation Date        : 29.06.1991 by Manfred G. Schendel              */
/*      Last Modification    : 01.07.1991 by Manfred G. Schendel              */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Modification List    :                                                */
/*                                                                            */
/*      Date        Author      Modification made                             */
/*                                                                            */
/*      01.07.1991  MS          redesign and validation                       */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

# include <stdio.h>
# include <string.h>
# include <malloc.h>
# include <fcntl.h>
# include <unistd.h>
# include <sys/types.h>
# include <sys/time.h>
# include <sys/socket.h>
# include <sys/errno.h>
# include <netinet/in.h>
# include <netdb.h>

# include "ISCdefinitions.h"

extern void ISCmsg(int,char*,char*);
extern void ISCsyserr(int,char**);

/* ========================================================================== */

# define ERROR -1

# define ERR(x) fprintf (stderr, __FILE__ "(%d): %s\n", __LINE__, x);

extern isc_record isc_con[ISC_MAX_CONNECTIONS];
# ifdef HP
extern int      errno;
# else
extern      int errno;
# endif

/* ========================================================================== */

long int ISCrecv (long int channel, char *buffer, long int nob) 

{
  /***** local variables *****/
  long int      bytes;
  long int      point;
  char          msg[128];
  char          *msg1;
  long int      rnob;      /* number of bytes to read by next receive */
  long int      nobr;
  char          cpid[80];

  msg1 = (char *) malloc (128 * sizeof (char));
  sprintf (cpid, "*** Process id is %ld", getpid());

  if ((channel < 0) || (channel >= ISC_MAX_CONNECTIONS))
  {
    ISCmsg (0, "ISCrecv", "wrong channel number specified!");
    return ERROR;
  }

  if (isc_con[channel].alive != TRUE)
  {
    ISCmsg (0, "ISCrecv", "specified channel not functional!");
    return ERROR;
  }

  rnob = nob;
  point = 0;

  while (rnob > 0)
  {
    bytes = read (isc_con[channel].socket, &buffer[point], rnob);

    if (bytes < 0)
    {
      ISCsyserr (errno, &msg1);
      ERR ("error at read");
      ERR (msg1);
      ERR (cpid);
      point = 0;
      break;
    }
    else
    {
      if (bytes == 0)
      {
	ISCmsg (0, "ISCrecv", "no data to read!");
        point = 0;
	break;
      }

      rnob -= bytes;
      point += bytes;
    }
  }

  free (msg1);

  /* printf ("ISCrecv: received %8ld of %8ld bytes!\n", point, nob); */

  return point;

} /* end of ISCrecv */

/* end of ISCrecv.c */
