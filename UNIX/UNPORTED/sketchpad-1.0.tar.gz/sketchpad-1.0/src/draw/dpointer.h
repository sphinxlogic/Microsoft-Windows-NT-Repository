/* ========================================================================== */
/*           Forward-Declarations of Functions defined in 'dpointer.c'        */
/* ========================================================================== */

extern void start_pointer ( int, int, int );
extern void move_pointer ( int, int, int );
extern void end_pointer ( int );
extern void redraw_all_pointers ( XRectangle );
extern void handle_pointer ( XEvent* );
