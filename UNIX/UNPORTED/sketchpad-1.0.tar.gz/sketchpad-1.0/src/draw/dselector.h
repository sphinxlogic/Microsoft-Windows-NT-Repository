/* ========================================================================== */
/*           Forward-Declarations of Functions defined in 'dselector.c'       */
/* ========================================================================== */

extern void set_marker ( int, int, int );
extern void bounding_box ( XRectangle );
extern void handle_selector ( XEvent* );
