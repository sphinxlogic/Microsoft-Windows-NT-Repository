/* ========================================================================== */
/*      DEFINE STATEMENTS                                                     */
/* ========================================================================== */

#define CAP_STYLE  CapButt
#define JOIN_STYLE JoinMiter


#define MODE           1
#define SELECT_MODE    2
#define LINE_WIDTH     3
#define LINE_STYLE     4
#define TEXT_SIZE      5
#define TEXT_THICKNESS 6
#define TEXT_SLANT     7

#define BOUNDING_BOX_MODE   1
#define SPECIAL_POINTS_MODE 2

#define SOLID  1
#define DASHED 2

#define LINE_WIDTH_MIN  1
#define LINE_WIDTH_MAX 20

#define TEXT_SIZE_MIN  5
#define TEXT_SIZE_MAX 40
#define TEXT_SIZE_DEF 24

#define MEDIUM 1
#define BOLD   2

#define ROMAN  1
#define ITALIC 2

#define MAXUSERS 1000

#define MARKER_SIZE 6       /* the markers drawn when an object is picked are */
                            /* squares. MARKER_SIZE defines the lenght of its */
                            /* edges in pixels.                               */ 

#define DOT_LIMIT 5         /* the number of points which are ignored at      */
                            /* freehand drawing at maximum                    */
#define MIN_DIST 10         /* the minimum distance of points which are to be */
                            /* drawn in each case at freehand drawing         */


/* ========================================================================== */
/*      TYPES                                                                 */
/* ========================================================================== */

/* this type describes a rectangle similar to the 'XRectangle'; the           */
/* difference to the 'XRectangle' is that in 'MyRectangle' all components     */
/* are integers instead of (unsigned) short, so they can be negativ           */

typedef struct
{
  int x, y, width, height;

} MyRectangle;


/* ========================================================================== */
/*      The Type of the Variable containing the current Drawing State         */
/* ========================================================================== */

typedef struct
{
  int mode;                /* drawing mode; the values of the Radio Buttons   *
                            * v_draw_button_pointer etc.                      */
  int select_mode;         /* select mode; indicates wether selecting any     *
                            * object means the whole object or only one point *
                            * of this object.                                 */
  int line_width;          /* width of the lines &                            */
  int line_style;          /* line style of the lines which are drawn with    *
                            * DrawGCsolid                                     */
  int text_size;           /* size of text which is drawn                     */
  int text_thickness;      /* medium / bold                                   */
  int text_slant;          /* italic / roman                                  */
} DrawStateType;


/* ========================================================================== */
/*      The Type of the Variable containing all the available fonts           */
/* ========================================================================== */

typedef struct
{
  Boolean      exact;
  int          real_size;
  XFontStruct *font;
} FontTableType1;

typedef struct
{
  FontTableType1 roman, italic;
} FontTableType2;

typedef struct
{
  FontTableType2 medium, bold;
} FontTableType;

/* in this table we store all available fonts at initialization time */
extern FontTableType FontTable[TEXT_SIZE_MAX];


/* ========================================================================== */
/*      Global Variables defined in 'drawstate.c'                             */
/* ========================================================================== */

extern Widget       DrawWidget;
extern Display     *DrawDisplay;
extern Window       DrawWindow;
extern Screen      *DrawScreen;
extern Colormap     DrawCmap;

extern GC           DrawGCsolid;
extern GC           DrawGCxor;
extern GC           DrawGCWhite;
extern GC           ForeignGC;
extern GC           DrawGCtext;

extern XFontStruct *ptr_font;
extern XFontStruct *text_font;
extern XFontStruct *new_text_font;

extern XmFontList   text_font_list;
extern XmFontList   foreign_text_font_list;

extern int          obj_count;

/* ========================================================================== */
/*      Forward-Declarations of Functions defined in 'drawstate.c'            */
/* ========================================================================== */

extern Boolean set_draw_state ( int, int );
extern int     get_draw_state ( int );

extern void toggle_select_mode ();
