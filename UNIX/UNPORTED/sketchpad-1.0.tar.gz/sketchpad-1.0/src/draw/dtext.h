/* ========================================================================== */
/*           Forward-Declarations of Functions defined in 'dtext.c'           */
/* ========================================================================== */

#define TEXTLEN 80

extern XRectangle compute_text_box ( char* );
extern void draw_text ( int, int, char*, GC );
extern void handle_text ( XEvent* );
