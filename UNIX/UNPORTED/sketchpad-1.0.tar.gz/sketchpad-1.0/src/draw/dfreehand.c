/* ========================================================================== */
/*                                                                            */
/* Filename:     dfreehand.c                      +-----+-----+--+--+--+--+   */
/* Version :     1.2	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/9/92	10:07:38	                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Part      :  drawing module                                           */
/*                                                                            */
/*      Functions :  dfreehand()                                              */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <Mrm/MrmAppl.h>

#include "drawstate.h"
#include "drawmisc.h"

#include "../misc/ographic.h"
#include "../ui/layer.h"
#include "../kernel/user.h"


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  handle_freehand()                                        */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  handles freehand drawing                                 */
/*                                                                            */
/*      Accesses  :  ownUserNumber, obj_count                                 */
/*                                                                            */
/*      Called by :  draw () in draw.c                                        */
/*                                                                            */
/*      Calls     :  InsertFreehand(), AppendLineSegment()                    */
/*                   in misc/ographic.c,                                      */
/*                                                                            */
/*                   msg_draw_line(),                                         */
/*                   msg_start_freehand(), msg_end_freehand(),                */
/*                   in kernel/user.c,                                        */
/*                                                                            */
/*                   GetActiveLayer(), GetStructStorage()                     */
/*                   in ui/layer.c,                                           */
/*                                                                            */
/*                   dist() in drawmisc.c                                     */
/*                                                                            */
/* ========================================================================== */

void handle_freehand ( XEvent* startevent )
{
  XEvent         event;               /* current event in the queue           */

  XPoint         start, act, old;     /* the starting point and the actual    */
                                      /* and last position of the mouse       */

  struct_storage ss;                  /* the structure storage in which the   */
                                      /* objects are to be written            */

  void          *freehandObj;         /* the freehand-object which is beeing  */
                                      /* created                              */

  unsigned short dots = 0;            /* number of dots ignored until now     */

  ss = GetStructStorage (GetActiveLayer ());

  start.x = startevent->xbutton.x;
  start.y = startevent->xbutton.y;

  old.x = start.x;
  old.y = start.y;

  msg_start_freehand (old.x, old.y,
                      get_draw_state (LINE_WIDTH),
                      get_draw_state (LINE_STYLE),
                      ownUserNumber, obj_count);

  freehandObj = InsertFreehand (ss, old.x, old.y,
                                get_draw_state (LINE_WIDTH),
                                get_draw_state (LINE_STYLE),
                                ownUserNumber, obj_count);

  /* get the next event */
  XNextEvent (DrawDisplay,&event);

  /* loop until the button is released */
  while (!((event.type == ButtonRelease) && (event.xbutton.button == Button1)))
  {
    if (event.type == MotionNotify)
    {
      act.x = event.xmotion.x;
      act.y = event.xmotion.y;

      if ((dots++ >= DOT_LIMIT) || (dist (old, act) >= MIN_DIST))
      {
        /* draw line solid on window */
        XDrawLine (DrawDisplay, DrawWindow, DrawGCsolid,
                   old.x, old.y, act.x, act.y);

        /* send message */
        msg_draw_line (old.x, old.y, act.x, act.y,
                       get_draw_state (LINE_WIDTH),
                       get_draw_state (LINE_STYLE),
                       ownUserNumber, obj_count);

        /* insert segment of freehand-object in struct.-storage */
        AppendLineSegment (freehandObj, act.x, act.y);

        old.x = act.x;
        old.y = act.y;

        dots = 0;
      } /* if */
    } /* if */
    XNextEvent (DrawDisplay,&event);
  } /* while */

  act.x = event.xbutton.x;
  act.y = event.xbutton.y;

  /* draw last line solid on window */
  XDrawLine (DrawDisplay, DrawWindow, DrawGCsolid,
             old.x, old.y, act.x, act.y);

  /* send message */
  msg_draw_line (old.x, old.y, act.x, act.y,
                 get_draw_state (LINE_WIDTH),
                 get_draw_state (LINE_STYLE),
                 ownUserNumber, obj_count);
  msg_end_freehand ();

  obj_count++;

  /* insert last segment of freehand-object in struct.-storage */
  AppendLineSegment (freehandObj, act.x, act.y);
} /* handle_freehand */
