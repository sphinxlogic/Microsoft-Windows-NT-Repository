/* ========================================================================== */
/*                                                                            */
/* Filename:     dzoom.c                          +-----+-----+--+--+--+--+   */
/* Version :     1.4	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/15/92	10:45:42	                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Part      :  drawing module                                           */
/*                                                                            */
/*      Functions :  handle_zoom ()                                           */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      DEFINE STATEMENTS                                                     */
/* ========================================================================== */

#define MOVE 0
#define SIZE 1

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <Mrm/MrmAppl.h>

#include "dzoom.h"
#include "drawstate.h"

#include "../ui/defs.h"
#include "../misc/ographic.h"
#include "../misc/cursor.h"
#include "../ui/layer.h"
#include "../kernel/user.h"
#include "../ui/sketchpad.h"
#include "../image/picio.h"

#include <stdio.h>
/* HC
#include <stdlib.h>
*/

#define min(a,b)      ((a) < (b) ? (a) : (b))

/* ========================================================================== */
/*      GLOBAL VARIABLES                                                      */
/* ========================================================================== */
int DefaultZoomMagnification = 10;

int rect_selected = False;

int ActualZoomMagnification;         /* Magnification for pixels in zoom area */

int ZoomAreaWidth = 10;              /* Width of zoom area                    */
int ZoomAreaHeight = 10;             /* Height of zoom area                   */
int OrigWidth = 10;                  /* Width of zoomed area in orig. image   */
int OrigHeight = 10;                 /* Height of zoomed area in orig. image  */

int Orig_X = 0;                      /* upper left corner of zoomed area      */
int Orig_Y = 0;                      /*       in original image               */

XGCValues  ZoomGCval;
GC         ZoomGC = NULL;            /* GC used for pixmap manipulations      */
Pixmap     ZoomPixmap = 0;        /* Pixmap for expose events in zoom win. */
Pixmap     SaveZoomPixmap = 0;    /* Save Pixmap for cancel action in      */
                                     /*    zoom window                        */
Pixmap     SaveOrigPixmap = 0;    /* Save Pixmap for cancel action in      */
                                     /*    original window                    */

byte       *temppic = NULL;          /* copy of zoomed area of epic for later */
                                     /*    saving to file                     */

int CurrPos_X = 0;                   /* position of zoomed pixel currently    */
int CurrPos_Y = 0;                   /* edited                                */

unsigned long DrawPixel;             /* color map entry for edit color        */

byte ColorIndex;
/* ========================================================================== */
/*      FORWARD DECLARATIONS                                                  */
/* ========================================================================== */

void Apply_Zoom(void);
void Cancel_Zoom(void);
void Zoom_Done(void);

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  select_rectangle()                                       */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  gets an rectangular area of the drawing area             */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  handle_*()                                               */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
void select_rectangle(XEvent *startevent, XPoint *u_l, XPoint *l_r)
{
  XEvent event;                       /* current event in the queue           */

  XPoint act_u_l, act_l_r,            /* actual upper left and lower right    */
         old_u_l, old_l_r;            /* corners of border rectangle          */

  unsigned int width, height;         /* its width and height                 */

  int state;

  act_u_l.x = startevent->xbutton.x;
  act_u_l.y = startevent->xbutton.y;
  act_l_r.x   = act_u_l.x;
  act_l_r.y   = act_u_l.y;

  old_u_l.x   = act_u_l.x;
  old_u_l.y   = act_u_l.y;
  old_l_r.x   = act_l_r.x;
  old_l_r.y   = act_l_r.y;

  width   = 0;
  height  = 0;
  state   = MOVE;

  /* draw starting point on window */
  XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                  act_u_l.x, act_l_r.y, width, height);

  /* get the first event */
  event = *startevent;

  /* loop until the left button is released and the right button is pressed   */
  /* or the right button is pressed                                           */
  while (!((event.type == ButtonPress) && (event.xbutton.button == Button3)))
  {
    switch(event.type)
    {
      case (ButtonPress):
      {
        if (event.xbutton.button == Button1)
          state = SIZE; 
        break;
      }
      case (ButtonRelease):
      {
        if (event.xbutton.button == Button1)
          state = MOVE;
        break;
      }
      case (MotionNotify):
      {
        switch (state)
        {
          case (SIZE):
          {
            act_l_r.x = event.xmotion.x;
            act_l_r.y = event.xmotion.y;

            /* undraw old rectangle */
            XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                            act_u_l.x, act_u_l.y, width, height);
      
            if (act_l_r.x > pWIDE)
            {
              act_l_r.x = pWIDE;
            }

            if (act_l_r.x < act_u_l.x)
            {
              act_u_l.x  = act_l_r.x;
              width = act_u_l.x - act_l_r.x;
            }
            else
            {
              width = act_l_r.x - act_u_l.x;
            }

            if (act_l_r.y > pHIGH)
            {
              act_l_r.y = pHIGH;
            }

            if (act_l_r.y < act_u_l.y)
            {
              act_u_l.y   = act_l_r.y;
              height = act_u_l.y - act_l_r.y;
            }
            else
            {
              height = act_l_r.y - act_u_l.y;
            }

            if (width >= ((dispWIDE - 50) / ActualZoomMagnification))
            {
              width = ((dispWIDE - 50) / ActualZoomMagnification);
              act_l_r.x = act_u_l.x + width;
            }
             
            if (height >= ((dispHIGH - 100) / ActualZoomMagnification))
            {
              height = ((dispHIGH - 100) / ActualZoomMagnification);
              act_l_r.y = act_u_l.y + height;
            }
            /* draw new rectangle */
            XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                            act_u_l.x, act_u_l.y, width, height);

            /* actual point is now old point */
            old_l_r.x = act_l_r.x;
            old_l_r.y = act_l_r.y;
            break;
          } /* size mode */
          case (MOVE): 
          {
            /* undraw old rectangle */
            XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                            act_u_l.x, act_u_l.y, width, height);

            if (event.xmotion.x >= width)
            { 
              act_u_l.x = event.xmotion.x - width;
              act_l_r.x = event.xmotion.x;
            }
            else
            { 
              act_u_l.x = 0;
              act_l_r.x = width;
            }

            if (event.xmotion.x > pWIDE)
            { 
              act_l_r.x = pWIDE;
              act_u_l.x = act_l_r.x - width;
            }

            if (event.xmotion.y >= height)
            { 
              act_u_l.y = event.xmotion.y - height;
              act_l_r.y = event.xmotion.y;
            }
            else
            { 
              act_u_l.y = 0;
              act_l_r.y = height;
            }

            if (event.xmotion.y > pHIGH)
            { 
              act_l_r.y = pHIGH;
              act_u_l.y = act_l_r.y - height;
            }

            /* draw new rectangle */
            XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                            act_u_l.x, act_u_l.y, width, height);

            /* actual points are now old points */
            old_u_l.x = act_u_l.x;
            old_u_l.y = act_u_l.y;
            old_l_r.x = act_l_r.x;
            old_l_r.y = act_l_r.y;
            break;

          } /* move mode */
          default: /* error */
            break;
        }
      } /* MotionNotify */
      default:
        break;
    } /* switch */
    XNextEvent (DrawDisplay,&event);
  } /* while */

  /* undraw old rectangle */
  XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                  act_u_l.x, act_u_l.y, width, height);

  *u_l = act_u_l;
  *l_r = act_l_r;

} /* select_rectangle */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  handle_zoom ()                                           */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  handles zooming of an area of the sketch                 */
/*                                                                            */
/*      Accesses  :  ownUserNumber, obj_count                                 */
/*                                                                            */
/*      Called by :  draw () in draw.c                                        */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */

void handle_zoom ( XEvent* startevent )
{
  XPoint  u_l, l_r;

  XWindowAttributes    old_attrib;
  XSetWindowAttributes new_attrib;
  XColor cursor_fg, cursor_bg;

  if (!thePixmap)
  {
    sperror("Zoom: no image to edit.");
    return;
  }

  if (!rect_selected)
  {
    Arg AL[2];
    int MaxMagnification;
    int width, height;
    int w, h;
    unsigned long curr_pix;

    ActualZoomMagnification = DefaultZoomMagnification;

    select_rectangle(startevent, &u_l, &l_r);
    rect_selected = True;

    width  = ((l_r.x - u_l.x) == 0 ? 1 : (l_r.x - u_l.x));
    height = ((l_r.y - u_l.y) == 0 ? 1 : (l_r.y - u_l.y));
    
    /* draw rectangle to indicate zoomed area */
    XDrawRectangle (DrawDisplay, thePixmap, DrawGCxor,
                    (u_l.x - 1), (u_l.y - 1), (width + 1), (height + 1));
    XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                    (u_l.x - 1), (u_l.y - 1), (width + 1), (height + 1));

    /* Set Zoom Area Width and Height */
    ZoomAreaWidth = width * ActualZoomMagnification;
    ZoomAreaHeight = height * ActualZoomMagnification;

    if (widget_array[v_zoom_box] == NULL)
    {
      if (MrmFetchWidget(s_MrmHierarchy,
          "c_zoom_box",
          toplevel_widget,
          &widget_array[v_zoom_box],
          &dummy_class) != MrmSUCCESS)
      {
        sperror("can`t fetch Box !");
        return;
      }
    }

    XtManageChild(widget_array[v_zoom_box]);
    XSync(theDisplay, False);

    XtSetArg (AL[0], XmNheight, ZoomAreaHeight);
    XtSetArg (AL[1], XmNwidth, ZoomAreaWidth);
    XtSetValues(widget_array[v_zoom_area], AL, 2);

    MaxMagnification = min( (dispWIDE-50)/width , (dispHIGH-100)/height );
    XtSetArg (AL[0], XmNmaximum, MaxMagnification);
    XtSetValues(widget_array[v_zoom_mag_scale], AL, 1);
    
    /* define cursor for zoomed window */
    zoom_cursor = XCreateFontCursor(DrawDisplay,XC_crosshair);

    /* set foreground color */
    cursor_fg.red   = 65535;
    cursor_fg.blue  = 0;
    cursor_fg.green = 0;

    /* set background color */
    cursor_bg.red   = 65535;
    cursor_bg.blue  = 65535;
    cursor_bg.green = 65535;

    XRecolorCursor(DrawDisplay,zoom_cursor,&cursor_fg,&cursor_bg);
    XDefineCursor(DrawDisplay,XtWindow(widget_array[v_zoom_area]),
                  zoom_cursor);

    /* XFreeCursor(DrawDisplay,zoom_cursor); */

    /* Save upper left corner of zoomed area in original window */
    Orig_X = u_l.x;
    Orig_Y = u_l.y;
    OrigWidth = width;
    OrigHeight = height;

    /* Create new EventMask for Zoom Area */
    XGetWindowAttributes (DrawDisplay, XtWindow(widget_array[v_zoom_area]),
                          &old_attrib);
    new_attrib.event_mask = (old_attrib.your_event_mask|
                          ButtonPressMask|ButtonReleaseMask|PointerMotionMask);

    /* Set new Event Mask */
    XSelectInput (DrawDisplay, XtWindow(widget_array[v_zoom_area]),
                          new_attrib.event_mask);


    /* set up graphics context */
    ZoomGCval.function   = GXcopy;
    ZoomGCval.foreground = WhitePixel (theDisplay, theScreen);
    ZoomGCval.background = BlackPixel (theDisplay, theScreen);

    ZoomGC = XCreateGC  (theDisplay,
                         XtWindow(widget_array[v_zoom_area]),
                         (GCFunction|GCForeground|GCBackground),
                         &ZoomGCval);
    if (!ZoomGC)
    {
      sperror("Zoom: cannot create graphics context");
      Zoom_Done();
      return;
    }

    /* initialize draw color */
    ColorIndex = epic[0];
    DrawPixel =  cols[epic[0]];

    /* Create Pixmap for Expose Events */
    ZoomPixmap = XCreatePixmap (theDisplay, XtWindow(widget_array[v_zoom_area]),
                                ZoomAreaWidth, ZoomAreaHeight, dispDEEP);
    if (!ZoomPixmap)
    {
      sperror("Zoom: cannot create pixmap");
      Zoom_Done();
      return;
    }

    /* Create Save Pixmap for Cancel Function */
    SaveZoomPixmap = XCreatePixmap (theDisplay,
                                XtWindow(widget_array[v_zoom_area]),
                                ZoomAreaWidth, ZoomAreaHeight, dispDEEP);
    if (!SaveZoomPixmap)
    {
      sperror("Zoom: cannot create pixmap");
      Zoom_Done();
      return;
    }

    /* Create Zoomed image */
    for (h = 0; h < height; h++)
      for (w = 0; w < width; w++)
      {
        if (((w + u_l.x) < pWIDE) && ((h + u_l.y) < pHIGH))
        {
          curr_pix = XGetPixel(theImage, w + u_l.x, h + u_l.y);
          XSetForeground(theDisplay, ZoomGC, curr_pix);
          XFillRectangle(theDisplay, ZoomPixmap,
                          ZoomGC, w * ActualZoomMagnification, 
                          h * ActualZoomMagnification, 
                          ActualZoomMagnification, ActualZoomMagnification);
        }
      }

    /* Copy Zoomed image to Zoom Window */
    XCopyArea(theDisplay, ZoomPixmap, XtWindow(widget_array[v_zoom_area]),
              ZoomGC, 0,0, ZoomAreaWidth, ZoomAreaHeight, 0, 0);
 
    /* Copy Zoomed Image to Save Pixmap */
    XCopyArea(theDisplay, ZoomPixmap, SaveZoomPixmap,
              ZoomGC, 0,0, ZoomAreaWidth, ZoomAreaHeight, 0, 0);
 
    /* Create small Save Pixmap for original window */
    SaveOrigPixmap = XCreatePixmap (theDisplay,
                                XtWindow(widget_array[v_drawing_area]),
                                OrigWidth, OrigHeight, dispDEEP);
    if (!SaveOrigPixmap)
    {
      sperror("Zoom: cannot create pixmap");
      Zoom_Done();
      return;
    }

    /* copy zoomed area of original window into small save pixmap */
    XCopyArea(theDisplay, thePixmap, SaveOrigPixmap,
              ZoomGC, Orig_X, Orig_Y, OrigWidth, OrigHeight, 0, 0);
  
    /* create a copy of epic for later saving to file */
    
    temppic = (byte *) malloc(OrigWidth * OrigHeight);
    if (!temppic)
    {
      sperror("Zoom: unable to malloc temppic!");
      Zoom_Done();
      return;
    }

    /* copy area from epic to temppic */
    { 
      int i, j;
      for (i = 0; i < OrigHeight; i++)
        for (j = 0; j < OrigWidth; j++)
        {
          temppic[(i * OrigWidth) + j] = 
                 epic[((Orig_Y + i) * pWIDE) + Orig_X + j];
        }
    }
  }
  else
  {
    if (startevent->type == ButtonPress)
    {
      if (startevent->xbutton.button == Button1)
      {
        fprintf(stderr,"Zoom: Button 1 in Drawingarea geklickt\n");
      }
      if (startevent->xbutton.button == Button3)
      {
        fprintf(stderr,"Zoom: Button 3 in Drawingarea geklickt\n");
      }
    }
  }  
} /* handle_zoom */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  Apply_Zoom()                                             */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  definitely applies the changes made in the zoom window   */
/*                   to the original raster image                             */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  zoom_proc in sketchpad.c                                 */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
void Apply_Zoom (void)
{
  if ((ZoomPixmap != 0) && (SaveZoomPixmap != 0))
  {
    /* update save zoom pixmap */
    XCopyArea(theDisplay, ZoomPixmap, SaveZoomPixmap,
              ZoomGC, 0,0, ZoomAreaWidth, ZoomAreaHeight, 0, 0);

    /* update save original pixmap */
    XCopyArea(theDisplay, thePixmap, SaveOrigPixmap,
              ZoomGC, Orig_X, Orig_Y, OrigWidth, OrigHeight, 0, 0);
   
    /* update the XImage of the original picture */
    theImage = XGetSubImage(theDisplay, thePixmap, Orig_X, Orig_Y,
              OrigWidth, OrigHeight, AllPlanes, ZPixmap, theImage,
              Orig_X, Orig_Y);

    /* copy area from temppic to epic */
    { 
      int i, j;
      for (i = 0; i < OrigHeight; i++)
        for (j = 0; j < OrigWidth; j++)
        {
          epic[((Orig_Y + i) * pWIDE) + Orig_X + j] =
                 temppic[(i * OrigWidth) + j];
        }
    }
    msg_apply_zoom(Orig_X, Orig_Y, OrigWidth, OrigHeight,
                   (OrigWidth * OrigHeight * sizeof(unsigned char)),
                   (void *) temppic);
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  Cancel_Zoom()                                            */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  cancels the changes made in the zoom window              */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  zoom_proc in sketchpad.c                                 */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
void Cancel_Zoom (void)
{
  XRectangle expose_rec;

  if ((ZoomPixmap != 0) && (SaveZoomPixmap != 0))
  {
    /* reset zoom pixmap */
    XCopyArea(theDisplay, SaveZoomPixmap, ZoomPixmap,
              ZoomGC, 0,0, ZoomAreaWidth, ZoomAreaHeight, 0, 0);

    /* reset zoom window */
    XCopyArea(theDisplay, ZoomPixmap,  XtWindow(widget_array[v_zoom_area]),
              ZoomGC, 0,0, ZoomAreaWidth, ZoomAreaHeight, 0, 0);
   
    /* reset the pixmap of the original picture */
    XCopyArea(theDisplay, SaveOrigPixmap, thePixmap,
              ZoomGC, 0, 0, OrigWidth, OrigHeight, Orig_X, Orig_Y);
   
   /* copy area from epic to temppic */
    {
      int i, j;
      for (i = 0; i < OrigHeight; i++)
        for (j = 0; j < OrigWidth; j++)
        {
          temppic[(i * OrigWidth) + j] =
                 epic[((Orig_Y + i) * pWIDE) + Orig_X + j];
        }
    }

    expose_rec.x      = Orig_X;
    expose_rec.y      = Orig_Y;
    expose_rec.width  = OrigWidth;
    expose_rec.height = OrigHeight;
    RedrawAll(expose_rec);
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  Zoom_Done()                                              */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  resets the global variables for later new zoom action    */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  zoom_proc in sketchpad.c                                 */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
void Zoom_Done (void)
{
  Cancel_Zoom();

  rect_selected = False;
  if (ZoomPixmap != 0)
    XFreePixmap(theDisplay, ZoomPixmap);
  ZoomPixmap = 0;

  if (SaveZoomPixmap != 0)
    XFreePixmap(theDisplay, SaveZoomPixmap);
  SaveZoomPixmap = 0;

  if (SaveOrigPixmap != 0)
    XFreePixmap(theDisplay, SaveOrigPixmap);
  SaveOrigPixmap = 0;

  if (ZoomGC != 0)
    XFreeGC(theDisplay, ZoomGC);
  ZoomGC = 0;
  
  if (temppic != NULL)
    free(temppic);
  temppic = NULL;

  /* clear rectangle indicating zoomed area */
  XDrawRectangle (DrawDisplay, thePixmap, DrawGCxor, (Orig_X - 1),
                  (Orig_Y - 1), (OrigWidth + 1), (OrigHeight + 1));
  XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor, (Orig_X - 1),
                  (Orig_Y - 1), (OrigWidth + 1), (OrigHeight + 1));
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  Redraw_Zoom()                                            */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  handles expose events in the zoomed drawing area         */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  expose_proc in sketchpad.c                               */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
void Redraw_Zoom(XRectangle rec)
{
  if (ZoomPixmap != 0)
  {
    XCopyArea(theDisplay, ZoomPixmap, XtWindow(widget_array[v_zoom_area]),
              ZoomGC, rec.x, rec.y, rec.width, rec.height, rec.x, rec.y);
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  Zoomed_Draw()                                            */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  handles draw events in the zoomed drawing area           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  draw_proc in sketchpad.c                                 */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
void Zoomed_Draw (XEvent *event)
{
  XEvent my_event;
  int NewPos_X, NewPos_Y;
  layer lay;

  my_event = *event;

  switch(my_event.type)
  {
    case (ButtonPress):
    {
      if (my_event.xbutton.button == Button1)
      {
        /* draw while button is pressed */
        do
        {
          if ((my_event.type == MotionNotify) ||
              ((my_event.type == ButtonPress) && 
               (my_event.xbutton.button == Button1)))
          {
            NewPos_X = ((my_event.xmotion.x / ActualZoomMagnification) 
                        * ActualZoomMagnification);
            NewPos_Y = ((my_event.xmotion.y / ActualZoomMagnification)
                        * ActualZoomMagnification);
            if (((NewPos_X != CurrPos_X) || (NewPos_Y != CurrPos_Y)) &&
                (NewPos_X >= 0) && (NewPos_X < ZoomAreaWidth) &&
                (NewPos_Y >= 0) && (NewPos_Y < ZoomAreaHeight))
            {
              CurrPos_X = NewPos_X;
              CurrPos_Y = NewPos_Y;

              XSetForeground(theDisplay, ZoomGC, DrawPixel);
              /* draw into Zoom Pixmap */
              XFillRectangle(theDisplay, ZoomPixmap,
                              ZoomGC, CurrPos_X, CurrPos_Y,
                              ActualZoomMagnification, ActualZoomMagnification);

              /* draw into Zoom Window */
              XFillRectangle(theDisplay, XtWindow(widget_array[v_zoom_area]),
                              ZoomGC, CurrPos_X, CurrPos_Y,
                              ActualZoomMagnification, ActualZoomMagnification);

              /* draw into original window and pixmap */
   
              lay = GetFirstLayer();
              if (GetLayerState (lay) & LS_VISIBLE)
              {
                XDrawPoint (theDisplay, XtWindow(widget_array[v_drawing_area]),
                            ZoomGC,
                            Orig_X + (CurrPos_X / ActualZoomMagnification),
                            Orig_Y + (CurrPos_Y / ActualZoomMagnification));
              }
              XDrawPoint (theDisplay, thePixmap,
                          ZoomGC,
                          Orig_X + (CurrPos_X / ActualZoomMagnification),
                          Orig_Y + (CurrPos_Y / ActualZoomMagnification));

              /* update temppic */
              temppic[((CurrPos_Y / ActualZoomMagnification) * OrigWidth) +
                       (CurrPos_X / ActualZoomMagnification)] = ColorIndex;

            } /* if moved */
          } /* if MotionNotify */
          XNextEvent (DrawDisplay,&my_event);
        } 
        while (!((my_event.type == ButtonRelease) && 
                 (my_event.xbutton.button == Button1)));
      }
      else if (my_event.xbutton.button == Button3)
      {
        XImage *TempImg;

        /* select color while button is pressed */
        do
        {
          if ((my_event.type == MotionNotify) ||
              ((my_event.type == ButtonPress) &&
               (my_event.xbutton.button == Button3)))
          {
            NewPos_X = ((my_event.xmotion.x / ActualZoomMagnification)
                        * ActualZoomMagnification);
            NewPos_Y = ((my_event.xmotion.y / ActualZoomMagnification)
                        * ActualZoomMagnification);
            if ((NewPos_X != CurrPos_X) || (NewPos_Y != CurrPos_Y))
            {
              CurrPos_X = NewPos_X;
              CurrPos_Y = NewPos_Y;

              TempImg = XGetImage(theDisplay, ZoomPixmap, CurrPos_X, CurrPos_Y,
                                  3, 3, AllPlanes, ZPixmap);

              DrawPixel = XGetPixel(TempImg, 1, 1);

              XDestroyImage(TempImg);

              /* update color index */
              ColorIndex = temppic[((CurrPos_Y / ActualZoomMagnification)
                                   * OrigWidth) +
                                    (CurrPos_X / ActualZoomMagnification)];

            } /* if moved */
          } /* if MotionNotify */
          XNextEvent (DrawDisplay,&my_event);
        }
        while (!((my_event.type == ButtonRelease) &&
                 (my_event.xbutton.button == Button3)));
      }
      break;
    }
    default:
      break;
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  Apply_Foreign_Zoom()                                     */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  updates all data structures related with raster image on */
/*                   screen when MSG_APPLY_ZOOM is received                   */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
void Apply_Foreign_Zoom(int x, int y, int w, int h, char *data)
{
  XRectangle expose_rec;

  /* Close the Zoom Window */
  CloseZoomWindow();

  /* copy area from received data to epic */
  {
    int i, j;
    for (i = 0; i < h; i++)
      for (j = 0; j < w; j++)
      {
        epic[((y + i) * pWIDE) + x + j] =
               (byte) data[(i * w) + j];
      }
  }

  /* set up graphics context */
  ZoomGCval.function   = GXcopy;
  ZoomGCval.foreground = WhitePixel (theDisplay, theScreen);
  ZoomGCval.background = BlackPixel (theDisplay, theScreen);

  ZoomGC = XCreateGC  (theDisplay,
                       XtWindow(widget_array[v_drawing_area]),
                       (GCFunction|GCForeground|GCBackground),
                       &ZoomGCval);
  if (!ZoomGC)
  {
    sperror("ApplyForeignZoom: cannot create graphics context");
    return;
  }

  /* draw changes into drawing area pixmap */
  {
    unsigned long Pix;
    int i, j;
    for (i = 0; i < h; i++)
      for (j = 0; j < w; j++)
      {
        Pix = cols[(byte) data[(i * w) + j]];
        XSetForeground(theDisplay, ZoomGC, Pix);
        XDrawPoint (theDisplay, thePixmap, ZoomGC, x + j, y + i);
      }
  }

  /* redraw changed rectangle in drawing area */
  expose_rec.x        = x;
  expose_rec.y        = y;
  expose_rec.width    = w;
  expose_rec.height   = h;
  RedrawAll(expose_rec);

  /* update the XImage of the original picture */
  theImage = XGetSubImage(theDisplay, thePixmap, x, y, w, h,
             AllPlanes, ZPixmap, theImage, x, y);

  XFreeGC(theDisplay, ZoomGC);
  ZoomGC = NULL;
  return;
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  GetDefaultZoomMagnification()                            */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  returns default zoom magnification                       */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int GetDefaultZoomMagnification(void)
{
  return(DefaultZoomMagnification);
}



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  SetDefaultZoomMagnification()                            */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  sets the default zoom magnification                      */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
void SetDefaultZoomMagnification(int Mag)
{
  DefaultZoomMagnification = Mag;
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  GetActualZoomMagnification()                             */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  returns actual zoom magnification                        */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int GetActualZoomMagnification(void)
{
  return(ActualZoomMagnification);
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  SetActualZoomMagnification()                             */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*      Purpose   :  sets the actual zoom magnification                       */
/*                   resizes the zoomed image, if the result will not be      */
/*                   larger then the screen                                   */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
void SetActualZoomMagnification(int Mag)
{
  char textbuf[80];
  Arg AL[2];
  int w, h;
  XImage *TempImage;
  unsigned long curr_pix;

  /* check if resized image fits on screen */
  if (Mag > ActualZoomMagnification)
  {
    int tooLarge = False;
    if ((OrigWidth * Mag) > (dispWIDE - 50))
    {
      Mag = (dispWIDE - 50) / OrigWidth;
      tooLarge = True;
    }
    if ((OrigHeight * Mag) > (dispHIGH - 100))
    {
      Mag = (dispHIGH - 100) / OrigHeight;
      tooLarge = True;
    }
    if (tooLarge)
    {
      sprintf(textbuf,"Zoom: zoomed area too large:");
      sperror(textbuf);
      sprintf(textbuf,"      Magnification set to %d.", Mag);
      sperror(textbuf);
    }
  }

  /* set zoom drawing area width and height */
  ZoomAreaWidth = OrigWidth * Mag;
  ZoomAreaHeight = OrigHeight * Mag;

  XtSetArg (AL[0], XmNheight, ZoomAreaHeight);
  XtSetArg (AL[1], XmNwidth, ZoomAreaWidth);
  XtSetValues(widget_array[v_zoom_area], AL, 2);

  /* create temporary image for drawing in new pixmap */
  TempImage = XGetImage(theDisplay, thePixmap, Orig_X, Orig_Y, 
                      OrigWidth, OrigHeight, AllPlanes, ZPixmap);

  XSync(theDisplay,False);

  /* free expose pixmap and save pixmap */
  XFreePixmap(theDisplay, ZoomPixmap);
  ZoomPixmap = 0;
  XFreePixmap(theDisplay, SaveZoomPixmap);
  SaveZoomPixmap = 0;

  XSync(theDisplay,False);

  /* create new pixmap for expose events */
  ZoomPixmap = XCreatePixmap (theDisplay, XtWindow(widget_array[v_zoom_area]),
                              ZoomAreaWidth, ZoomAreaHeight, dispDEEP);
  if (!ZoomPixmap)
  {
    sperror("Zoom: cannot create pixmap");
    Zoom_Done();
    return;
  }

  /* create new save pixmap for cancel function */
  SaveZoomPixmap = XCreatePixmap (theDisplay,
                              XtWindow(widget_array[v_zoom_area]),
                              ZoomAreaWidth, ZoomAreaHeight, dispDEEP);
  if (!SaveZoomPixmap)
  {
    sperror("Zoom: cannot create pixmap");
    Zoom_Done();
    return;
  }

  XSync(theDisplay,False);

  /* create zoomed image */
  for (h = 0; h < OrigHeight; h++)
    for (w = 0; w < OrigWidth; w++)
    {
      curr_pix = XGetPixel(TempImage, w, h);
      XSetForeground(theDisplay, ZoomGC, curr_pix);
      XFillRectangle(theDisplay, ZoomPixmap,
                      ZoomGC, w * Mag, h * Mag, Mag, Mag);
    }

  /* TempImage is not longer needed: free it */
  XDestroyImage(TempImage);

  XSync(theDisplay,False);

  /* Copy Zoomed image to Zoom Window */
  XCopyArea(theDisplay, ZoomPixmap, XtWindow(widget_array[v_zoom_area]),
            ZoomGC, 0,0, ZoomAreaWidth, ZoomAreaHeight, 0, 0);

  /* Copy Zoomed Image to Save Pixmap */
  XCopyArea(theDisplay, ZoomPixmap, SaveZoomPixmap,
            ZoomGC, 0,0, ZoomAreaWidth, ZoomAreaHeight, 0, 0);

  ActualZoomMagnification = Mag; 
} /* SetActualZoomMagnification */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  CloseZoomWindow()                                        */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  closes the zoom window                                   */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
void CloseZoomWindow(void)
{
  if (rect_selected)
  {
    XtUnmanageChild(widget_array[v_zoom_box]);
    widget_array[v_zoom_box] = NULL;
    Zoom_Done();
  }
}

