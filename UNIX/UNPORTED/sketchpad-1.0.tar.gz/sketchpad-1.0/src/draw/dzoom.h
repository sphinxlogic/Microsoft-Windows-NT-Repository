#ifndef ZOOM_HEADERS
#define ZOOM_HEADERS

/* ========================================================================== */
/*           Forward-Declarations of Functions defined in 'dzoom.c'           */
/* ========================================================================== */

extern void handle_zoom ( XEvent* );

extern void Apply_Zoom(void);
extern void Cancel_Zoom(void);
extern void Zoom_Done(void);

extern void Zoomed_Draw (XEvent *event);

extern void Redraw_Zoom(XRectangle);

extern void Apply_Foreign_Zoom(int x, int y, int w, int h, char *data);

extern void SetDefaultZoomMagnification(int);
extern int  GetDefaultZoomMagnification(void);
extern void SetActualZoomMagnification(int);
extern int  GetActualZoomMagnification(void);

extern void CloseZoomWindow(void);

#endif ZOOM_HEADERS
