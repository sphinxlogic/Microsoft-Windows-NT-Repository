/* ========================================================================== */
/*           Forward-Declarations of Functions defined in 'drectangle.c'      */
/* ========================================================================== */

extern void handle_rectangle ( XEvent* );
