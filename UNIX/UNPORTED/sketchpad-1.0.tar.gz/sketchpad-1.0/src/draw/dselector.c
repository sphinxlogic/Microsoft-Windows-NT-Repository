/* ========================================================================== */
/*                                                                            */
/* Filename:     dselector.c                      +-----+-----+--+--+--+--+   */
/* Version :     1.3	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/15/92	10:45:40	                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Module    :  drawing module                                           */
/*                                                                            */
/*      Functions :  wait_for_button_release (),                              */
/*                   set_marker (), bounding_box (), bounding_boxes (),       */
/*                   in_box (), on_sizer_button (), calculate_new_bbox (),    */
/*                   rubber_size_object (), size_object (),                   */
/*                   screen_move_objects (), ss_move_objects (),              */
/*                   move_objects (),                                         */
/*                   calculate_new_dragbox (), select_area (),                */
/*                   handle_selector ()                                       */
/*                                                                            */
/* ========================================================================== */


/* ========================================================================== */
/*      DEFINE STATEMENTS                                                     */
/* ========================================================================== */

#define WAITTIME  300
#define TIMEOUT     1
#define BUTTONR     2


#define ABS(a)      (a<0 ? -a : a)
#define ABSMIN(a,b) (ABS(a)>ABS(b) ? b : a)


/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <Mrm/MrmAppl.h>
#include <X11/cursorfont.h>
#include <sys/timeb.h>

#include "drawstate.h"

#include "../misc/sperror.h"
#include "../misc/ographic.h"
#include "../misc/list.h"
#include "../misc/cursor.h"
#include "../ui/layer.h"

extern void msg_size_object();
extern void msg_move_object();
extern void PopEditWindow (void*);


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  wait_for_button_release()                                */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  waits for a Button-Release-Event, but waits <WAITTIME>   */
/*                   Milliseconds at maximum.                                 */
/*                   Returns <TIMEOUT> if there was no Button-Release-Event   */
/*                   in between, and <BUTTONR> there is occured one.          */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  handle_selector ()                                       */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

static int wait_for_button_release ( struct timeb starttime )
{
  struct timeb acttime;
  XEvent       event;
  int          endflag = 0;
  int          diff;

  /* we wait for 'endflag' to be set to either TIMEOUT or BUTTONR */
  do {
    /* get actual time */
    ftime (&acttime);

    /* compute difference to starting time */
    diff = acttime.millitm - starttime.millitm;
    if (diff < 0) diff += 1000; /* milliseconds wrap around */

    /* did we wait long enough ? Then it's TIMEOUT ! */
    if (diff > WAITTIME)
      endflag = TIMEOUT;

    /* did a ButtonRelease-Event from the Button 1 occur in between ? */
    /* Then it's BUTTONR ! */
    if ((XCheckTypedEvent (DrawDisplay, ButtonRelease, &event)) &&
        (event.xbutton.button == Button1))
      endflag = BUTTONR;
  } while (!endflag);

  return endflag;
} /* wait_for_button_release */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  set_marker()                                             */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  sets a marker, which is a rectangle, of a specified      */
/*                   sort <number> on a specified position <x,y> on the       */
/*                   drawing area.                                            */
/*                   <number> specifies which marker is to be drawn:          */
/*                                                                            */
/*                         1 --  2 --  3                                      */
/*                         |           |                                      */
/*                         8           4                                      */
/*                         |           |                                      */
/*                         7 --  6 --  5                                      */
/*                                                                            */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  bounding_box(),                                          */
/*                   indirect calls:                                          */
/*                   assignment to the function variable 'marker'             */
/*                   in ui/sketchpad.c                                        */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

void set_marker ( int x, int y, int number)
{
  int left; /* difference between the (left or right) edge of the bounding    */
            /* box and the left edge of the marker                            */
  int top;  /* difference between the (top or bottom) edge of the bounding    */
            /* box and the top edge of the marker                             */

  if ((number >= 1) && (number <= 3))         /* top edge of bounding box     */
    top = 0;
  else
    if ((number == 4) || (number == 8))       /* middle of right or left edge */
      top = MARKER_SIZE/2;
    else                                      /* bottom edge                  */
      top = MARKER_SIZE - 1;

  if ((number >= 7) || (number == 1))         /* left edge                    */
    left = 0;
  else
    if ((number == 2) || (number == 6))       /* middle of top or bottom edge */
      left = MARKER_SIZE/2;
    else                                      /* right edge                   */
      left = MARKER_SIZE - 1;

  /* draw the marker, which is a rectangle */
  XDrawRectangle (DrawDisplay, DrawWindow, DrawGCWhite,
                  x - left, y - top, MARKER_SIZE - 1, MARKER_SIZE - 1);
} /* set_marker */

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  bounding_box()                                           */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  draw a bounding box. The bounding box consists of a      */
/*                   rectangle <rec> and the eight markers                    */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  only indirect calls:                                     */
/*                   assignment to the function variable 'bbox'               */
/*                   in ui/sketchpad.c                                        */
/*                                                                            */
/*      Calls     :  set_marker()                                             */
/*                                                                            */
/* ========================================================================== */

void bounding_box ( XRectangle rec )
{
  int x1, y1;    /* upper left corner           */
  int xmitte;    /* middle of a horizontal edge */
  int x2, y2;    /* lower right corner          */
  int ymitte;    /* middle of a vertical edge   */

  x1     = rec.x;
  xmitte = rec.x + (rec.width + 1)/2;
  x2     = rec.x +  rec.width;
  y1     = rec.y;
  ymitte = rec.y + (rec.height + 1)/2;
  y2     = rec.y +  rec.height;

  /* draw the edges of the bounding box */
  XDrawRectangle (DrawDisplay, DrawWindow, DrawGCWhite,
                  rec.x, rec.y, rec.width, rec.height);

  /* draw the markers of the bounding box */
  set_marker (x1,     y1,     1);
  set_marker (xmitte, y1,     2);
  set_marker (x2,     y1,     3);
  set_marker (x2,     ymitte, 4);
  set_marker (x2,     y2,     5);
  set_marker (xmitte, y2,     6);
  set_marker (x1,     y2,     7);
  set_marker (x1,     ymitte, 8);
} /* bounding_box */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  bounding_boxes()                                         */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  draw bounding boxes of all selected objects in xor-Mode. */
/*                   The bounding boxes are simply rectangles.                */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  handle_selector ()                                       */
/*                                                                            */
/*      Calls     :  FirstEntry(), GetListState(), GetEntry(), NextEntry()    */
/*                   in misc/list.c,                                          */
/*                                                                            */
/*                   GetObjectBoundingBox() in misc/ographic.c                */
/*                                                                            */
/* ========================================================================== */

void bounding_boxes ( list sel_obj, int xdiff, int ydiff )
{
  void *o;
  int x1, y1;    /* upper left corner  */
  int x2, y2;    /* lower right corner */

  /* walk through the whole list and draw for each */
  /* object in the list its bounding-box           */
  FirstEntry (sel_obj);
  while (GetListState (sel_obj) == E_OK)
  {
    o = GetEntry (sel_obj);
    GetObjectBoundingBox (o, &x1, &y1, &x2, &y2);
    x1 += xdiff;
    y1 += ydiff;
    x2 += xdiff;
    y2 += ydiff;

    /* draw the bounding box without markers */
    XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                    x1, y1, x2 - x1, y2 - y1);

    NextEntry (sel_obj);
  }
} /* bounding_boxes */
 

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  in_box()                                                 */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  check wether a point <x,y> is in a box with the          */
/*                   upper left coordinates <x_box, y_box> and the size       */
/*                   MARKER_SIZE.                                             */
/*                   Returns 'TRUE' if the box is met and 'FALSE' otherwise.  */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  on_sizer_button()                                        */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

static Boolean in_box ( int x, int y, int x_box, int y_box )
{
  if ((x < x_box) || (x > (x_box + MARKER_SIZE)) ||
      (y < y_box) || (y > (y_box + MARKER_SIZE)))
    return FALSE;
  else
    return TRUE;
} /* in_box */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  on_sizer_button()                                        */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  check wether a point <x,y> is on a sizer button of a     */
/*                   specified object <o>.                                    */
/*                   Returns 0, if no button is met, otherwise the number of  */
/*                   the button is returned (see 'set_marker()' for a         */
/*                   description of the sizer button numbers).                */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  handle_selector ()                                       */
/*                                                                            */
/*      Calls     :  in_box(),                                                */
/*                                                                            */
/*                   GetObjectBoundingBox() in misc/ographic.c                */
/*                                                                            */
/* ========================================================================== */

int on_sizer_button ( void *o, int x, int y )
{
  int x1, y1;    /* upper left corner of the bounding box */
  int x2, y2;    /* lower right corner                    */

  /* get the coordinates of the bounding box */
  GetObjectBoundingBox (o, &x1, &y1, &x2, &y2);

  /* check for each of the eight markers */
  if (in_box (x, y, x1, y1))
    return 1;
  else if (in_box (x, y, (x1 + x2)/2 - MARKER_SIZE / 2, y1))
    return 2;
  else if (in_box (x, y, x2 - MARKER_SIZE + 1, y1))
    return 3;
  else if (in_box (x, y, x2 - MARKER_SIZE + 1, (y1 + y2)/2 - MARKER_SIZE / 2))
    return 4;
  else if (in_box (x, y, x2 - MARKER_SIZE + 1, y2 - MARKER_SIZE + 1))
    return 5;
  else if (in_box (x, y, (x1 + x2)/2 - MARKER_SIZE / 2, y2 - MARKER_SIZE + 1))
    return 6;
  else if (in_box (x, y, x1 , y2 - MARKER_SIZE + 1))
    return 7;
  else if (in_box (x, y, x1 , (y1 + y2)/2 - MARKER_SIZE / 2))
    return 8;
  else /* no marker met */
    return 0;
} /* on_sizer_button */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  calculate_new_bbox()                                     */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  calculates the new bounding box of the currently         */
/*                   resized object.                                          */
/*                   The calculation is depending in wether the 'shift' key   */
/*                   was pressed when klicking on the sizer-button; if the    */
/*                   'shift' key was pressed, only proportional sizing is     */
/*                   allowed.                                                 */
/*                                                                            */
/*                   Gets the number of the the selected sizer-button         */
/*                   (<button>), a flag showing wether the 'shift' key was    */
/*                   pressed when klicking on the sizer-button (<shift>),     */
/*                   the difference of the current mouse position             */
/*                   to the starting point (<xdiff, ydiff>) and the old       */
/*                   bounding box of the object (<oldbbox>).                  */
/*                                                                            */
/*                   Returns the new bounding box of the resized object       */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  rubber_size_object()                                     */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

static MyRectangle calculate_new_bbox ( int button, Boolean shift,
                                        int xdiff, int ydiff,
                                        MyRectangle oldbbox )
{
  MyRectangle newbbox;

  if (shift)
  {
    float f;

    /* now only proportional sizing is possible         */

    /* for this reason, the sizer-buttons on            */
    /* top, bottom, left and right make no sense and so */
    /* there is no reaction to a use of them            */

    /* first, we have to calculate the factor for       */
    /* sizing proportionally out of xdiff and ydiff     */

    switch (button)
    {
      case 1: /* top left */
        if (xdiff == ABSMIN (xdiff, ydiff))
        {
          f = - ((float) xdiff / (float)oldbbox.width);
        }
        else
        {
          f = - ((float) ydiff / (float)oldbbox.height);
        }

        newbbox.width  = (int) (oldbbox.width  * (1.0 + f));
        newbbox.height = (int) (oldbbox.height * (1.0 + f));
        newbbox.x      = oldbbox.x + oldbbox.width  - newbbox.width;
        newbbox.y      = oldbbox.y + oldbbox.height - newbbox.height;
        break;
      case 3: /* top right */
        if (xdiff == ABSMIN (xdiff, ydiff))
        {
          f = (float) xdiff / (float)oldbbox.width;
        }
        else
        {
          f = - ((float) ydiff / (float)oldbbox.height);
        }

        newbbox.width  = (int) (oldbbox.width  * (1.0 + f));
        newbbox.height = (int) (oldbbox.height * (1.0 + f));
        newbbox.x      = oldbbox.x;
        newbbox.y      = oldbbox.y + oldbbox.height - newbbox.height;
        break;
      case 5: /* bottom right */
        if (xdiff == ABSMIN (xdiff, ydiff))
        {
          f = (float) xdiff / (float)oldbbox.width;
        }
        else
        {
          f = (float) ydiff / (float)oldbbox.height;
        }

        newbbox.width  = (int) (oldbbox.width  * (1.0 + f));
        newbbox.height = (int) (oldbbox.height * (1.0 + f));
        newbbox.x      = oldbbox.x;
        newbbox.y      = oldbbox.y;
        break;
      case 7: /* bottom left */
        if (xdiff == ABSMIN (xdiff, ydiff))
        {
          f = - ((float) xdiff / (float)oldbbox.width);
        }
        else
        {
          f = (float) ydiff / (float)oldbbox.height;
        }

        newbbox.width  = (int) (oldbbox.width  * (1.0 + f));
        newbbox.height = (int) (oldbbox.height * (1.0 + f));
        newbbox.x      = oldbbox.x + oldbbox.width  - newbbox.width;
        newbbox.y      = oldbbox.y;
        break;
      default: /* top, bottom, left or right */
        newbbox.x      = oldbbox.x;
        newbbox.y      = oldbbox.y;
        newbbox.width  = oldbbox.width;
        newbbox.height = oldbbox.height;
        break;
    }
  }
  else /* no shift */
  {
    switch (button)
    {
      case 1: /* top left */
        newbbox.x      = oldbbox.x      + xdiff;
        newbbox.y      = oldbbox.y      + ydiff;
        newbbox.width  = oldbbox.width  - xdiff;
        newbbox.height = oldbbox.height - ydiff;
        break;
      case 2: /* top */
        newbbox.x      = oldbbox.x;
        newbbox.y      = oldbbox.y      + ydiff;
        newbbox.width  = oldbbox.width;
        newbbox.height = oldbbox.height - ydiff;
        break;
      case 3: /* top right */
        newbbox.x      = oldbbox.x;
        newbbox.y      = oldbbox.y      + ydiff;
        newbbox.width  = oldbbox.width  + xdiff;
        newbbox.height = oldbbox.height - ydiff;
        break;
      case 4: /* right */
        newbbox.x      = oldbbox.x;
        newbbox.y      = oldbbox.y;
        newbbox.width  = oldbbox.width  + xdiff;
        newbbox.height = oldbbox.height;
        break;
      case 5: /* bottom right */
        newbbox.x      = oldbbox.x;
        newbbox.y      = oldbbox.y;
        newbbox.width  = oldbbox.width  + xdiff;
        newbbox.height = oldbbox.height + ydiff;
        break;
      case 6: /* bottom */
        newbbox.x      = oldbbox.x;
        newbbox.y      = oldbbox.y;
        newbbox.width  = oldbbox.width;
        newbbox.height = oldbbox.height + ydiff;
        break;
      case 7: /* bottom left */
        newbbox.x      = oldbbox.x      + xdiff;
        newbbox.y      = oldbbox.y;
        newbbox.width  = oldbbox.width  - xdiff;
        newbbox.height = oldbbox.height + ydiff;
        break;
      case 8: /* left */
        newbbox.x      = oldbbox.x      + xdiff;
        newbbox.y      = oldbbox.y;
        newbbox.width  = oldbbox.width  - xdiff;
        newbbox.height = oldbbox.height;
        break;
    }
  }

  return newbbox;
} /* calculate_new_bbox */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  rubber_size_object()                                     */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  realizes the rubberbanding for sizing an object.         */
/*                                                                            */
/*                   Gets the number of the the selected sizer-button         */
/*                   (<button>), a flag showing wether the 'shift' key was    */
/*                   pressed when klicking on the sizer-button (<shift>),     */
/*                   the coordinates where the user pressed the               */
/*                   mousebutton (<startingpoint>) and the old bounding box   */
/*                   of the object (<oldbbox>).                               */
/*                                                                            */
/*                   Returns the new bounding box of the resized object       */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  size_object()                                            */
/*                                                                            */
/*      Calls     :  calculate_new_bbox()                                     */
/*                                                                            */
/* ========================================================================== */

MyRectangle rubber_size_object ( int button, Boolean shift,
                                 XPoint startingpoint, MyRectangle oldbbox )
{
  int         xdiff, ydiff;
  int         xf, yf;
  MyRectangle newbbox;
  XEvent      event;

  XColor      cursor_fg, cursor_bg;

  newbbox = oldbbox;

  xdiff = ydiff = 0;

  /* set the cursor shape according to wether sizing */
  /* is done proportionally or not                   */
  if (shift)
  {
    switch (button)
    {
      case 1: /* top left */
        size_cursor = XCreateFontCursor (DrawDisplay, XC_top_left_corner);
        break;
      case 2: /* top middle */
        size_cursor = XCreateFontCursor (DrawDisplay, XC_dot);
        break;
      case 3: /* top right */
        size_cursor = XCreateFontCursor (DrawDisplay, XC_top_right_corner);
        break;
      case 4: /* left middle */
        size_cursor = XCreateFontCursor (DrawDisplay, XC_dot);
        break;
      case 5: /* bottom right */
        size_cursor = XCreateFontCursor (DrawDisplay, XC_bottom_right_corner);
        break;
      case 6: /* bottom middle */
        size_cursor = XCreateFontCursor (DrawDisplay, XC_dot);
        break;
      case 7: /* bottom left */
        size_cursor = XCreateFontCursor (DrawDisplay, XC_bottom_left_corner);
        break;
      case 8: /* right middle */
        size_cursor = XCreateFontCursor (DrawDisplay, XC_dot);
        break;
    }
  }
  else /* no shift */
  {
    switch (button)
    {
      case 1: /* top left */
        size_cursor = XCreateFontCursor (DrawDisplay, XC_ul_angle);
        break;
      case 2: /* top middle */
        size_cursor = XCreateFontCursor (DrawDisplay, XC_top_tee);
        break;
      case 3: /* top right */
        size_cursor = XCreateFontCursor (DrawDisplay, XC_ur_angle);
        break;
      case 4: /* left middle */
        size_cursor = XCreateFontCursor (DrawDisplay, XC_right_tee);
        break;
      case 5: /* bottom right */
        size_cursor = XCreateFontCursor (DrawDisplay, XC_lr_angle);
        break;
      case 6: /* bottom middle */
        size_cursor = XCreateFontCursor (DrawDisplay, XC_bottom_tee);
        break;
      case 7: /* bottom left */
        size_cursor = XCreateFontCursor (DrawDisplay, XC_ll_angle);
        break;
      case 8: /* right middle */
        size_cursor = XCreateFontCursor (DrawDisplay, XC_left_tee);
        break;
    }
  }

  /* set foreground color */
  /* black */
  cursor_fg.red   = 0;
  cursor_fg.blue  = 0;
  cursor_fg.green = 0;

  /* set background color */
  /* white */
  cursor_bg.red   = 65535;
  cursor_bg.blue  = 65535;
  cursor_bg.green = 65535;

  XRecolorCursor (DrawDisplay, size_cursor, &cursor_fg, &cursor_bg);

  XDefineCursor (DrawDisplay, DrawWindow, size_cursor);

  XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                  newbbox.x, newbbox.y,
                  newbbox.width - 1, newbbox.height - 1);
  do {
    XNextEvent (DrawDisplay, &event);
    if (event.type == MotionNotify)
    {
      XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                      newbbox.x, newbbox.y,
                      newbbox.width - 1, newbbox.height - 1);

      xdiff = event.xmotion.x - startingpoint.x;
      ydiff = event.xmotion.y - startingpoint.y;

      /* calculate the new bounding box */
      newbbox = calculate_new_bbox (button, shift, xdiff, ydiff, oldbbox);

      xf = yf = 1;
      if (newbbox.width < 0)
      {
        newbbox.width = -newbbox.width;
        newbbox.x     -= newbbox.width;
        xf = -1;
      }
      if (newbbox.height < 0)
      {
        newbbox.height = -newbbox.height;
        newbbox.y      -= newbbox.height;
        yf = -1;
      }

      XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                      newbbox.x, newbbox.y,
                      newbbox.width - 1, newbbox.height - 1);
    }
  } while (!((event.type == ButtonRelease) &&
             (event.xbutton.button == Button1)));

  XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                  newbbox.x, newbbox.y,
                  newbbox.width - 1, newbbox.height - 1);

  /* set cursor shape back */
  size_cursor = XCreateFontCursor (DrawDisplay, XC_arrow);
  /* set foreground color */
  cursor_fg.red   = 65535;
  cursor_fg.blue  = 0;
  cursor_fg.green = 0;
  /* set background color */
  cursor_bg.red   = 65535;
  cursor_bg.blue  = 65535;
  cursor_bg.green = 65535;
  XRecolorCursor (DrawDisplay, size_cursor, &cursor_fg, &cursor_bg);
  XDefineCursor (DrawDisplay, DrawWindow, size_cursor);
  /* XFreeCursor (DrawDisplay, size_cursor); */

  if (xf == -1)
  {
    newbbox.width = -newbbox.width;
    newbbox.x     -= newbbox.width;
  }
  if (yf == -1)
  {
    newbbox.height = -newbbox.height;
    newbbox.y      -= newbbox.height;
  }

  return newbbox;
} /* rubber_size_object */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  size_object()                                            */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  realizes the sizing of an object.                        */
/*                   Sizes the object on screen and in the structure storage  */
/*                   and sends the other users a msg. how to size the object. */
/*                                                                            */
/*                   Gets a pointer to the selected object (<o>), the         */
/*                   coordinates where the user pressed the mousebutton       */
/*                   (<startingpoint>), the number of the the selected        */
/*                   sizer-button (<button>) and a flag showing wether the    */
/*                   'shift' key was pressed when klicking on the             */
/*                   sizer-button (<shift>)                                   */
/*                                                                            */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  handle_selector ()                                       */
/*                                                                            */
/*      Calls     :  rubber_size_object(),                                    */
/*                                                                            */
/*                   GetObjectBoundingBox(), GetObjectId(), SizeObject()      */
/*                   in misc/ographic.c,                                      */
/*                                                                            */
/*                   msg_size_object()                                        */
/*                   in kernel/user.c                                         */
/*                                                                            */
/* ========================================================================== */

static void size_object ( object o, XPoint startingpoint,
                          int button, Boolean shift)
{
  int         x2, y2;
  int         id1, id2;
  MyRectangle oldbbox, newbbox;

  GetObjectBoundingBox (o, &(oldbbox.x), &(oldbbox.y), &x2, &y2);

  oldbbox.width  = x2 - oldbbox.x + 1;
  oldbbox.height = y2 - oldbbox.y + 1;

  newbbox = rubber_size_object (button, shift, startingpoint, oldbbox);

  GetObjectId (o, &id1, &id2);
  msg_size_object (id1, id2, newbbox.x, newbbox.y,
                             newbbox.width, newbbox.height);
  SizeObject (GetStructStorage (GetActiveLayer ()), o, newbbox.x, newbbox.y,
                     newbbox.width, newbbox.height);
} /* size_object */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  screen_move_objects()                                    */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  realizes the moving of all selected objects.             */
/*                   Moves the objects only on screen.                        */
/*                                                                            */
/*                   Gets the list of all selected objects (<sel_obj>) and the*/
/*                   coordinates where the user pressed the mousebutton       */
/*                   (<startingpoint>).                                       */
/*                                                                            */
/*                   Returns the difference of the point the user released    */
/*                   the mousebutton from the starting point (<xdiff_adr>,    */
/*                   <ydiff_adr>).                                            */
/*                                                                            */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  move_objects()                                           */
/*                                                                            */
/*      Calls     :  bounding_boxes()                                         */
/*                                                                            */
/* ========================================================================== */

void screen_move_objects
     ( list sel_obj, XPoint startingpoint, int* xdiff_adr, int* ydiff_adr )
{
  XEvent event;

  /* accumulated motion of the objects */
  *xdiff_adr = *ydiff_adr = 0;

  bounding_boxes (sel_obj, *xdiff_adr, *ydiff_adr);

  do {
    XNextEvent (DrawDisplay, &event);

    if (event.type == MotionNotify)
    {
      bounding_boxes (sel_obj, *xdiff_adr, *ydiff_adr);

      *xdiff_adr = event.xmotion.x - startingpoint.x;
      *ydiff_adr = event.xmotion.y - startingpoint.y;

      bounding_boxes (sel_obj, *xdiff_adr, *ydiff_adr);
    }
  } while (!((event.type == ButtonRelease) &&
             (event.xbutton.button == Button1)));

  bounding_boxes (sel_obj, *xdiff_adr, *ydiff_adr);
} /* screen_move_objects */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  ss_move_objects()                                        */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  realizes the moving of all selected objects.             */
/*                   Moves the objects only in the structure storage and      */
/*                   sends the other users a msg. how to move the objects.    */
/*                                                                            */
/*                   Gets the list of all selected objects (<sel_obj>) and    */
/*                   two integers indicating how the objects have to be       */
/*                   moved (<xdiff, ydiff>).                                  */
/*                                                                            */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  move_objects()                                           */
/*                                                                            */
/*      Calls     :  FirstEntry(), GetListState(), GetEntry(), NextEntry()    */
/*                   in misc/list.c,                                          */
/*                                                                            */
/*                   msg_move_object() in kernel/user.c,                      */
/*                                                                            */
/*                   MoveObject() in misc/ographic.c                          */
/*                                                                            */
/* ========================================================================== */

static void ss_move_objects ( list sel_obj, int xdiff, int ydiff )
{
  object o;
  int id1, id2;

  FirstEntry (sel_obj);

  while (GetListState (sel_obj) == E_OK)
  {
    o = GetEntry (sel_obj);
    GetObjectId (o, &id1, &id2);

    msg_move_object (id1, id2, xdiff, ydiff);
    MoveObject (GetStructStorage (GetActiveLayer ()), o, xdiff, ydiff);

    NextEntry (sel_obj);
  }
} /* ss_move_objects */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  move_objects ()                                          */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  realizes the moving of all selected objects.             */
/*                   Moves the objects on screen and in the structure storage */
/*                   and sends the other users a msg. how to move the objects.*/
/*                                                                            */
/*                   Gets the coordinates where the user pressed the          */
/*                   mousebutton (<startingpoint>).                           */
/*                                                                            */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  handle_selector ()                                       */
/*                                                                            */
/*      Calls     :  screen_move_objects(), ss_move_objects(),                */
/*                                                                            */
/*                   CreateList(), InsertEndEntry(), FreeList()               */
/*                   in misc/list.c,                                          */
/*                                                                            */
/*                   GetFirstPickedObj(), GetNextPickedObj()                  */
/*                   in misc/ographic.c                                       */
/*                                                                            */
/* ========================================================================== */

static void move_objects ( XPoint startingpoint )
{
  object o;
  list   sel_obj;
  int    xdiff, ydiff;
  struct_storage ss;

  ss = GetStructStorage (GetActiveLayer ());
  /* make a list of all picked objects */
  sel_obj = CreateList ();

  o = GetFirstPickedObj (ss);
  while (o != NULL)
  {
    InsertEndEntry (sel_obj, o);
    o = GetNextPickedObj (ss);
  }

  screen_move_objects (sel_obj, startingpoint, &xdiff, &ydiff);

  ss_move_objects (sel_obj, xdiff, ydiff);

  FreeList (sel_obj);

} /* move_objects */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  calculate_new_dragbox()                                  */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  calculates a new drag box for selecting objects          */
/*                   within a certain rectangle.                              */
/*                                                                            */
/*                   Gets the coordinates where the user pressed the          */
/*                   mousebutton (<startingpoint>) and the actual position    */
/*                   of the mouse (<newpoint>).                               */
/*                                                                            */
/*                   Returns the new drag box as a rectangle.                 */
/*                                                                            */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  select_area()                                            */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

static MyRectangle calculate_new_dragbox
                   ( XPoint startingpoint, XPoint newpoint )
{
  MyRectangle new_dragbox;

  if (newpoint.x < startingpoint.x)
  {
    new_dragbox.x     = newpoint.x;
    new_dragbox.width = startingpoint.x - newpoint.x;
  }
  else
  {
    new_dragbox.x     = startingpoint.x;
    new_dragbox.width = newpoint.x - startingpoint.x;
  }

  if (newpoint.y < startingpoint.y)
  {
    new_dragbox.y      = newpoint.y;
    new_dragbox.height = startingpoint.y - newpoint.y;
  }
  else
  {
    new_dragbox.y      = startingpoint.y;
    new_dragbox.height = newpoint.y - startingpoint.y;
  }

  return new_dragbox;
} /* calculate_new_dragbox */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  select_area()                                            */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  realizes the selecting of all objects in a dragged box.  */
/*                                                                            */
/*                   Gets the coordinates where the user pressed the          */
/*                   mousebutton (<startingpoint>).                           */
/*                                                                            */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  handle_selector ()                                       */
/*                                                                            */
/*      Calls     :  calculate_new_dragbox(),                                 */
/*                                                                            */
/*                   PickObjectArea() in misc/ographic.c                      */
/*                                                                            */
/* ========================================================================== */

void select_area ( XPoint startingpoint )
{
  XEvent      event;
  XPoint      motionpoint;
  MyRectangle dragbox;

  /* make a rubber-band dragbox */
  dragbox = calculate_new_dragbox (startingpoint, startingpoint);

  /* show the drag box on the window */
  XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                  dragbox.x, dragbox.y, dragbox.width, dragbox.height);
  do {
    XNextEvent (DrawDisplay, &event);
    if (event.type == MotionNotify)
    {
      /* undraw the old dragbox */
      XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                      dragbox.x, dragbox.y, dragbox.width, dragbox.height);

      motionpoint.x = event.xmotion.x;
      motionpoint.y = event.xmotion.y;

      dragbox = calculate_new_dragbox (startingpoint, motionpoint);

      /* draw the new dragbox */
      XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                      dragbox.x, dragbox.y, dragbox.width, dragbox.height);
    }
  } while (!((event.type == ButtonRelease) &&
             (event.xbutton.button == Button1)));

  /* undraw the old dragbox */
  XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                  dragbox.x, dragbox.y, dragbox.width, dragbox.height);

  /* pick all objects within the box */
  PickObjectArea (GetStructStorage (GetActiveLayer ()), dragbox.x, dragbox.y,
                     (dragbox.x + dragbox.width), (dragbox.y + dragbox.height));
} /* select_area */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  handle_selector ()                                       */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  handle the selector                                      */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  draw() in draw.c                                         */
/*                                                                            */
/*      Calls     :  wait_for_button_release (),                              */
/*                   on_sizer_button (), size_object (), move_objects (),     */
/*                   select_area (),                                          */
/*                                                                            */
/*                   FindObject (), DeselectAllExceptOne (),                  */
/*                   PickObject (), ObjectState (), ObjectType (),            */
/*                   DeselectAll ()                                           */
/*                   in misc/ographic.c.                                      */
/*                                                                            */
/* ========================================================================== */

void handle_selector ( XEvent* startevent )
{
  object       o;
  struct timeb starttime;
  XPoint       startingpoint;
  struct_storage ss;

  ss = GetStructStorage (GetActiveLayer ());
  startingpoint.x = startevent->xbutton.x;
  startingpoint.y = startevent->xbutton.y;

  /* check in which select_mode we are */
  if (get_draw_state (SELECT_MODE) == BOUNDING_BOX_MODE)
  {
    /* remember starting time */
    ftime (&starttime);

    /* did the user pick on an object ? */
    o = FindObject (ss, startingpoint.x, startingpoint.y);

    if (o != NULL)  /* he met an object */
    {
      if (startevent->xbutton.button == Button1)
      {
        /* wait wether the user does a short klick or holds the mouse button */
        if (wait_for_button_release (starttime) == BUTTONR) 
        {
          /* did the user not hold down the Shift-key ? */
          if ((startevent->xbutton.state & ShiftMask) == 0)
          {
            /* then mark all objects as 'not picked' except the one */
            /* the users klicked on */
            DeselectAllExceptOne (ss, o);
          }

          /* toggle the pick-state of the object the user klicked on */
          PickObject (ss, o);
        }
        else /* the user holds down the mousebutton */
        {
          int but_no; /* holds the number of the button the user klicked on */
                      /* or '0' if no button is met                         */

          /* if the object the user klicked on is not picked yet, */
          /* then pick it now.                                    */
          if ((ObjectState (o) & ST_PICKED) == 0)
          {
            PickObject (ss, o);
          }

          /* has the user grabbed on a sizer-button ? */
          if (but_no = on_sizer_button (o, startingpoint.x, startingpoint.y))
          {
            /* check wether the object is a TEXT-object or not. */
            /* Text can't be sized.                             */
            if (ObjectType (o) == GP_TEXT)
            {
              sperror ("sorry, text can't be sized!");
              sperror ("       (not yet)");
             }
             else
             {
               /* size the object the user klicked on */
               size_object (o, startingpoint, but_no,
                         (startevent->xbutton.state & ShiftMask) );
             }
          }
          else
          {
            /* move all picked objects */
            move_objects (startingpoint);
          }
        }
      }
          /* right mouse button was pressed */
      else if (startevent->xbutton.button == Button3)
      {
        if (ObjectType (o) == GP_TEXT)
        {
          DeselectAll (ss);
          PickObject (ss, o);
          PopEditWindow(o);
	}
      }
    }
    else /* he met no object */
    {
      /* did the user not hold down the Shift-key ? */
      if ((startevent->xbutton.state & ShiftMask) == 0)
      {
        /* then deselect all objects */
        DeselectAll (ss);
      }

      /* drag a box and select all objects within the box */
      select_area (startingpoint);
    }
  }
  else
  {
    sperror ("selectmode is specialpoints");
  }
} /* handle_selector */




