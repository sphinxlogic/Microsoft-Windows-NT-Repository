/* ========================================================================== */
/*                                                                            */
/* Filename:     drawmisc.c                       +-----+-----+--+--+--+--+   */
/* Version :     1.5	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/15/92	10:45:33	                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Part      :  drawing module                                           */
/*                                                                            */
/*      Functions :  remove_events(), dist(), set_font_table(),               */
/*                   get_font_table()                                         */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <Mrm/MrmAppl.h>
#include <stdio.h>

#include "drawstate.h"


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  remove_events ()                                         */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  remove motion events from the event queue, if there are  */
/*                   more than one such event.                                */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  handle_pointer in dpointer.c,                            */
/*                   handle_ellipse () in dellipse.c                          */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

void remove_events ( XEvent* event_adr )
{
  XEvent    nextreport;               /* the next event in the queue          */

  Boolean   anotherEventinQ;          /* Flag: TRUE if there's an event in    */
                                      /*       the queue waiting to be read   */


  /* if there are more than one MotionEvent in the queue, just
     pass them by, react only to the last of them */

  /* are there events in the queue ? */
  if (XEventsQueued (DrawDisplay, QueuedAlready) > 0)
  {
    anotherEventinQ = TRUE;
    /* look for the next event */
    XPeekEvent (DrawDisplay, &nextreport);

    /* loop while there are more motion events */
    while ((nextreport.type == MotionNotify) && (anotherEventinQ))
    {
      XNextEvent (DrawDisplay, event_adr);
      if (XEventsQueued (DrawDisplay, QueuedAlready) > 0)
        XPeekEvent (DrawDisplay, &nextreport);
      else
        anotherEventinQ = FALSE;
    } /* while */
  } /* if */

} /* remove_events */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  dist()                                                   */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  computes the distance between two points                 */
/*                   in a very simplified way: the minimum of the             */
/*                   x-distance and the y-distance is defined to be the       */
/*                   distance. This is to avoid float calculations.           */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  handle_freehand()                                        */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

int dist (XPoint point1, XPoint point2)
{
  int x_dist;
  int y_dist;

  x_dist = point1.x - point2.x;
  y_dist = point1.y - point2.y;

  x_dist = (x_dist > 0) ? x_dist : -x_dist;
  y_dist = (y_dist > 0) ? y_dist : -y_dist;

  return ( (x_dist > y_dist) ? x_dist : y_dist );
} /* dist */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  set_font_table()                                         */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  sets all fonts in the FontTable --                       */
/*                   sets the exact font, if available, the 'next best' font, */
/*                   if the exact one is not available.                       */
/*                                                                            */
/*      Accesses  :  FontTable[]                                              */
/*                                                                            */
/*      Called by :  init_draw_proc()                                         */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

void set_font_table ()
{
  int  size;
  int  next_smaller, next_bigger;

  char fontstring[80];

  /****************************************************************************/
  /* first: get all the fonts you can get                                     */
  /****************************************************************************/

  fprintf (stderr, "loading fonts ");

  for (size=TEXT_SIZE_MIN; size<TEXT_SIZE_MAX; size++)
  {
    fprintf (stderr, ".");

    /*********** MEDIUM, ROMAN ***********/

    sprintf (fontstring,
             "-adobe-times-medium-r-normal-*-%d-*-*-*-*-*-iso8859-1", size);

    if ((new_text_font = XLoadQueryFont (DrawDisplay, fontstring)) != NULL)
    {
      FontTable[size].medium.roman.font      = new_text_font;
      FontTable[size].medium.roman.real_size = size;
      FontTable[size].medium.roman.exact     = True;
    }


/******************************************************************/
/* For getting a better performance in starting up the sketchpad, */
/* we suppose that a font does not exist in any other type if it  */
/* does not exist in type  MEDIUM, ROMAN  in the specified size.  */
/******************************************************************/

if (new_text_font != NULL)
{
    /*********** MEDIUM, ITALIC ***********/

    sprintf (fontstring,
             "-adobe-times-medium-i-normal-*-%d-*-*-*-*-*-iso8859-1", size);

    if ((new_text_font = XLoadQueryFont (DrawDisplay, fontstring)) != NULL)
    {
      FontTable[size].medium.italic.font      = new_text_font;
      FontTable[size].medium.italic.real_size = size;
      FontTable[size].medium.italic.exact     = True;
    }

    /*********** BOLD, ROMAN ***********/

    sprintf (fontstring,
             "-adobe-times-bold-r-normal-*-%d-*-*-*-*-*-iso8859-1", size);

    if ((new_text_font = XLoadQueryFont (DrawDisplay, fontstring)) != NULL)
    {
      FontTable[size].bold.roman.font      = new_text_font;
      FontTable[size].bold.roman.real_size = size;
      FontTable[size].bold.roman.exact     = True;
    }


    /*********** BOLD, ITALIC ***********/

    sprintf (fontstring,
             "-adobe-times-bold-i-normal-*-%d-*-*-*-*-*-iso8859-1", size);

    if ((new_text_font = XLoadQueryFont (DrawDisplay, fontstring)) != NULL)
    {
      FontTable[size].bold.italic.font      = new_text_font;
      FontTable[size].bold.italic.real_size = size;
      FontTable[size].bold.italic.exact     = True;
    }
} /* performance-improving trick */
  } /* for */
  fprintf (stderr, "\n");


  /****************************************************************************/
  /* second: get the next best fonts to the fonts we couldn't get exact       */
  /****************************************************************************/

  /*********** MEDIUM, ROMAN ************/

  next_smaller = 0;
  next_bigger  = 0;

  for (size=TEXT_SIZE_MIN; size<TEXT_SIZE_MAX; size++)
  {
    /*** this font could be loaded exactly before ***/
    if (FontTable[size].medium.roman.exact)
    {
      next_smaller = size;
    } /* if ...exact */

    /*** this font could NOT be loaded exactly before (was not available) ***/
    else
    {
      /** a smaller and a bigger font are known **/
      if ((next_smaller) && (next_bigger > size) &&
                            (next_bigger < TEXT_SIZE_MAX))
      {
        if ((next_bigger - size) >= (size - next_smaller))
        {
          FontTable[size].medium.roman.font =
            FontTable[next_smaller].medium.roman.font;
          FontTable[size].medium.roman.real_size = next_smaller;
        }
        else
        {
          FontTable[size].medium.roman.font = 
            FontTable[next_bigger].medium.roman.font;
          FontTable[size].medium.roman.real_size = next_bigger;
        }
      }
      /** a smaller font is known, but there exists no bigger one **/
      else if ((next_smaller) && (next_bigger >= TEXT_SIZE_MAX))
      {
        FontTable[size].medium.roman.font = 
          FontTable[next_smaller].medium.roman.font;
        FontTable[size].medium.roman.real_size = next_smaller;
      }
      /** a bigger font is known, but there exists no smaller one **/
      else if ((!(next_smaller)) && (next_bigger > size) &&
                                    (next_bigger < TEXT_SIZE_MAX))
      {
        FontTable[size].medium.roman.font = 
          FontTable[next_bigger].medium.roman.font;
        FontTable[size].medium.roman.real_size = next_bigger;
      }
      /** there does not exist either a smaller or a bigger font **/
      else if ((!(next_smaller)) && (next_bigger >= TEXT_SIZE_MAX))
      {
        fprintf (stderr, "Error in set_font_table: no font to load!\n");
      }
      /** we don't know anything about a bigger font **/
      else
      {
        Boolean bigger_found = False;
        int     bigger_test  = size;

        /***** search for a bigger font *****/

        while ((!(bigger_found)) && (bigger_test < TEXT_SIZE_MAX))
        {
          bigger_test++;
          bigger_found = FontTable[bigger_test].medium.roman.exact;
        } /* while */

        if (bigger_found)
        {
          next_bigger = bigger_test;
        }
        else
        {
          next_bigger = TEXT_SIZE_MAX+1;
        } /* else */

        /* now do the same procedure as done before with the well-known fonts */
        if ((next_smaller) && (next_bigger > size) &&
                              (next_bigger < TEXT_SIZE_MAX))
        {
          if ((next_bigger - size) >= (size - next_smaller))
          {
            FontTable[size].medium.roman.font =
              FontTable[next_smaller].medium.roman.font;
            FontTable[size].medium.roman.real_size = next_smaller;
          }
          else
          {
            FontTable[size].medium.roman.font =
              FontTable[next_bigger].medium.roman.font;
            FontTable[size].medium.roman.real_size = next_bigger;
          }
        }
        else if ((next_smaller) && (next_bigger >= TEXT_SIZE_MAX))
        {
          FontTable[size].medium.roman.font =
            FontTable[next_smaller].medium.roman.font;
          FontTable[size].medium.roman.real_size = next_smaller;
        }
        else if ((!(next_smaller)) && (next_bigger > size) &&
                                      (next_bigger < TEXT_SIZE_MAX))
        {
          FontTable[size].medium.roman.font =
            FontTable[next_bigger].medium.roman.font;
          FontTable[size].medium.roman.real_size = next_bigger;
        }
        else if ((!(next_smaller)) && (next_bigger >= TEXT_SIZE_MAX))
        {
          fprintf (stderr, "Error in set_font_table: no font to load!\n");
        }
      } /* else */
    } /* else */
  } /* for (...) */

  /*********** MEDIUM, ITALIC ***********/

  next_smaller = 0;
  next_bigger  = 0;

  for (size=TEXT_SIZE_MIN; size<TEXT_SIZE_MAX; size++)
  {
    /*** this font could be loaded exactly before ***/
    if (FontTable[size].medium.italic.exact)
    {
      next_smaller = size;
    } /* if ...exact */

    /*** this font could NOT be loaded exactly before (was not available) ***/
    else
    {
      /** a smaller and a bigger font are known **/
      if ((next_smaller) && (next_bigger > size) &&
                            (next_bigger < TEXT_SIZE_MAX))
      {
        if ((next_bigger - size) >= (size - next_smaller))
        {
          FontTable[size].medium.italic.font =
            FontTable[next_smaller].medium.italic.font;
          FontTable[size].medium.italic.real_size = next_smaller;
        }
        else
        {
          FontTable[size].medium.italic.font =
            FontTable[next_bigger].medium.italic.font;
          FontTable[size].medium.italic.real_size = next_bigger;
        }
      }
      /** a smaller font is known, but there exists no bigger one **/
      else if ((next_smaller) && (next_bigger >= TEXT_SIZE_MAX))
      {
        FontTable[size].medium.italic.font =
          FontTable[next_smaller].medium.italic.font;
        FontTable[size].medium.italic.real_size = next_smaller;
      }
      /** a bigger font is known, but there exists no smaller one **/
      else if ((!(next_smaller)) && (next_bigger > size) &&
                                    (next_bigger < TEXT_SIZE_MAX))
      {
        FontTable[size].medium.italic.font =
          FontTable[next_bigger].medium.italic.font;
        FontTable[size].medium.italic.real_size = next_bigger;
      }
      /** there does not exist either a smaller or a bigger font **/
      else if ((!(next_smaller)) && (next_bigger >= TEXT_SIZE_MAX))
      {
        fprintf (stderr, "Error in set_font_table: no font to load!\n");
      }
      /** we don't know anything about a bigger font **/
      else
      {
        Boolean bigger_found = False;
        int     bigger_test  = size;

        /***** search for a bigger font *****/

        while ((!(bigger_found)) && (bigger_test < TEXT_SIZE_MAX))
        {
          bigger_test++;
          bigger_found = FontTable[bigger_test].medium.italic.exact;
        } /* while */

        if (bigger_found)
        {
          next_bigger = bigger_test;
        }
        else
        {
          next_bigger = TEXT_SIZE_MAX+1;
        } /* else */

        /* now do the same procedure as done before with the well-known fonts */
        if ((next_smaller) && (next_bigger > size) &&
                              (next_bigger < TEXT_SIZE_MAX))
        {
          if ((next_bigger - size) >= (size - next_smaller))
          {
            FontTable[size].medium.italic.font =
              FontTable[next_smaller].medium.italic.font;
            FontTable[size].medium.italic.real_size = next_smaller;
          }
          else
          {
            FontTable[size].medium.italic.font =
              FontTable[next_bigger].medium.italic.font;
            FontTable[size].medium.italic.real_size = next_bigger;
          }
        }
        else if ((next_smaller) && (next_bigger >= TEXT_SIZE_MAX))
        {
          FontTable[size].medium.italic.font =
            FontTable[next_smaller].medium.italic.font;
          FontTable[size].medium.italic.real_size = next_smaller;
        }
        else if ((!(next_smaller)) && (next_bigger > size) &&
                                      (next_bigger < TEXT_SIZE_MAX))
        {
          FontTable[size].medium.italic.font =
            FontTable[next_bigger].medium.italic.font;
          FontTable[size].medium.italic.real_size = next_bigger;
        }
        else if ((!(next_smaller)) && (next_bigger >= TEXT_SIZE_MAX))
        {
          fprintf (stderr, "Error in set_font_table: no font to load!\n");
        }
      } /* else */
    } /* else */
  } /* for (...) */

  /************ BOLD, ROMAN *************/

  next_smaller = 0;
  next_bigger  = 0;

  for (size=TEXT_SIZE_MIN; size<TEXT_SIZE_MAX; size++)
  {
    /*** this font could be loaded exactly before ***/
    if (FontTable[size].bold.roman.exact)
    {
      next_smaller = size;
    } /* if ...exact */

    /*** this font could NOT be loaded exactly before (was not available) ***/
    else
    {
      /** a smaller and a bigger font are known **/
      if ((next_smaller) && (next_bigger > size) &&
                            (next_bigger < TEXT_SIZE_MAX))
      {
        if ((next_bigger - size) >= (size - next_smaller))
        {
          FontTable[size].bold.roman.font =
            FontTable[next_smaller].bold.roman.font;
          FontTable[size].bold.roman.real_size = next_smaller;
        }
        else
        {
          FontTable[size].bold.roman.font = 
            FontTable[next_bigger].bold.roman.font;
          FontTable[size].bold.roman.real_size = next_bigger;
        }
      }
      /** a smaller font is known, but there exists no bigger one **/
      else if ((next_smaller) && (next_bigger >= TEXT_SIZE_MAX))
      {
        FontTable[size].bold.roman.font = 
          FontTable[next_smaller].bold.roman.font;
        FontTable[size].bold.roman.real_size = next_smaller;
      }
      /** a bigger font is known, but there exists no smaller one **/
      else if ((!(next_smaller)) && (next_bigger > size) &&
                                    (next_bigger < TEXT_SIZE_MAX))
      {
        FontTable[size].bold.roman.font = 
          FontTable[next_bigger].bold.roman.font;
        FontTable[size].bold.roman.real_size = next_bigger;
      }
      /** there does not exist either a smaller or a bigger font **/
      else if ((!(next_smaller)) && (next_bigger >= TEXT_SIZE_MAX))
      {
        fprintf (stderr, "Error in set_font_table: no font to load!\n");
      }
      /** we don't know anything about a bigger font **/
      else
      {
        Boolean bigger_found = False;
        int     bigger_test  = size;

        /***** search for a bigger font *****/

        while ((!(bigger_found)) && (bigger_test < TEXT_SIZE_MAX))
        {
          bigger_test++;
          bigger_found = FontTable[bigger_test].bold.roman.exact;
        } /* while */

        if (bigger_found)
        {
          next_bigger = bigger_test;
        }
        else
        {
          next_bigger = TEXT_SIZE_MAX+1;
        } /* else */

        /* now do the same procedure as done before with the well-known fonts */
        if ((next_smaller) && (next_bigger > size) &&
                              (next_bigger < TEXT_SIZE_MAX))
        {
          if ((next_bigger - size) >= (size - next_smaller))
          {
            FontTable[size].bold.roman.font =
              FontTable[next_smaller].bold.roman.font;
            FontTable[size].bold.roman.real_size = next_smaller;
          }
          else
          {
            FontTable[size].bold.roman.font =
              FontTable[next_bigger].bold.roman.font;
            FontTable[size].bold.roman.real_size = next_bigger;
          }
        }
        else if ((next_smaller) && (next_bigger >= TEXT_SIZE_MAX))
        {
          FontTable[size].bold.roman.font =
            FontTable[next_smaller].bold.roman.font;
          FontTable[size].bold.roman.real_size = next_smaller;
        }
        else if ((!(next_smaller)) && (next_bigger > size) &&
                                      (next_bigger < TEXT_SIZE_MAX))
        {
          FontTable[size].bold.roman.font =
            FontTable[next_bigger].bold.roman.font;
          FontTable[size].bold.roman.real_size = next_bigger;
        }
        else if ((!(next_smaller)) && (next_bigger >= TEXT_SIZE_MAX))
        {
          fprintf (stderr, "Error in set_font_table: no font to load!\n");
        }
      } /* else */
    } /* else */
  } /* for (...) */

  /************ BOLD, ITALIC ************/

  next_smaller = 0;
  next_bigger  = 0;

  for (size=TEXT_SIZE_MIN; size<TEXT_SIZE_MAX; size++)
  {
    /*** this font could be loaded exactly before ***/
    if (FontTable[size].bold.italic.exact)
    {
      next_smaller = size;
    } /* if ...exact */

    /*** this font could NOT be loaded exactly before (was not available) ***/
    else
    {
      /** a smaller and a bigger font are known **/
      if ((next_smaller) && (next_bigger > size) &&
                            (next_bigger < TEXT_SIZE_MAX))
      {
        if ((next_bigger - size) >= (size - next_smaller))
        {
          FontTable[size].bold.italic.font =
            FontTable[next_smaller].bold.italic.font;
          FontTable[size].bold.italic.real_size = next_smaller;
        }
        else
        {
          FontTable[size].bold.italic.font = 
            FontTable[next_bigger].bold.italic.font;
          FontTable[size].bold.italic.real_size = next_bigger;
        }
      }
      /** a smaller font is known, but there exists no bigger one **/
      else if ((next_smaller) && (next_bigger >= TEXT_SIZE_MAX))
      {
        FontTable[size].bold.italic.font = 
          FontTable[next_smaller].bold.italic.font;
        FontTable[size].bold.italic.real_size = next_smaller;
      }
      /** a bigger font is known, but there exists no smaller one **/
      else if ((!(next_smaller)) && (next_bigger > size) &&
                                    (next_bigger < TEXT_SIZE_MAX))
      {
        FontTable[size].bold.italic.font = 
          FontTable[next_bigger].bold.italic.font;
        FontTable[size].bold.italic.real_size = next_bigger;
      }
      /** there does not exist either a smaller or a bigger font **/
      else if ((!(next_smaller)) && (next_bigger >= TEXT_SIZE_MAX))
      {
        fprintf (stderr, "Error in set_font_table: no font to load!\n");
      }
      /** we don't know anything about a bigger font **/
      else
      {
        Boolean bigger_found = False;
        int     bigger_test  = size;

        /***** search for a bigger font *****/

        while ((!(bigger_found)) && (bigger_test < TEXT_SIZE_MAX))
        {
          bigger_test++;
          bigger_found = FontTable[bigger_test].bold.italic.exact;
        } /* while */

        if (bigger_found)
        {
          next_bigger = bigger_test;
        }
        else
        {
          next_bigger = TEXT_SIZE_MAX+1;
        } /* else */

        /* now do the same procedure as done before with the well-known fonts */
        if ((next_smaller) && (next_bigger > size) &&
                              (next_bigger < TEXT_SIZE_MAX))
        {
          if ((next_bigger - size) >= (size - next_smaller))
          {
            FontTable[size].bold.italic.font =
              FontTable[next_smaller].bold.italic.font;
            FontTable[size].bold.italic.real_size = next_smaller;
          }
          else
          {
            FontTable[size].bold.italic.font =
              FontTable[next_bigger].bold.italic.font;
            FontTable[size].bold.italic.real_size = next_bigger;
          }
        }
        else if ((next_smaller) && (next_bigger >= TEXT_SIZE_MAX))
        {
          FontTable[size].bold.italic.font =
            FontTable[next_smaller].bold.italic.font;
          FontTable[size].bold.italic.real_size = next_smaller;
        }
        else if ((!(next_smaller)) && (next_bigger > size) &&
                                      (next_bigger < TEXT_SIZE_MAX))
        {
          FontTable[size].bold.italic.font =
            FontTable[next_bigger].bold.italic.font;
          FontTable[size].bold.italic.real_size = next_bigger;
        }
        else if ((!(next_smaller)) && (next_bigger >= TEXT_SIZE_MAX))
        {
          fprintf (stderr, "Error in set_font_table: no font to load!\n");
        }
      } /* else */
    } /* else */
  } /* for (...) */

} /* set_font_table */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  get_font_table()                                         */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  gets a certain font from the FontTable and returns it    */
/*                   in 'font'. in 'exact' a flag indicating wether this font */
/*                   matches the description <size,thickness,slant> exact     */
/*                   or not.                                                  */
/*                   returns 'False' if the font is NULL, 'True' otherwise    */
/*                                                                            */
/*      Accesses  :  FontTable[]                                              */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

Boolean get_font_table (int size, int thickness, int slant,
                        XFontStruct* font, Boolean exact)
{
  font  = NULL;
  exact = False;

  switch (thickness)
  {
    case MEDIUM:
    {
      switch (slant)
      {
        case ROMAN:
        {
          font  = FontTable[size].medium.roman.font;
          exact = FontTable[size].medium.roman.exact;
          break;
        }
        case ITALIC:
        {
          font  = FontTable[size].medium.italic.font;
          exact = FontTable[size].medium.italic.exact;
          break;
        }
      };
      break;
    }
    case BOLD:
    {
      switch (slant)
      {
        case ROMAN:
        {
          font  = FontTable[size].bold.roman.font;
          exact = FontTable[size].bold.roman.exact;
          break;
        }
        case ITALIC:
        {
          font  = FontTable[size].bold.italic.font;
          exact = FontTable[size].bold.italic.exact;
          break;
        }
      };
      break;
    }
  }
  return (Boolean)font;
} /* get_font_table */

