/* ========================================================================== */
/*        Forward-Declarations of Functions defined in 'setdraw.c'            */
/* ========================================================================== */

extern void init_draw_proc ( void );
extern void set_draw_mode ( int );
extern void free_draw_proc ( void );
extern void set_clip ( XRectangle, XRectangle );
extern void destroy_clip_area ();
extern void set_draw_color ( GC, unsigned long );
extern void set_foreign_font_attributes ( int, int, int );
