/* ========================================================================== */
/*                                                                            */
/* Filename:     dellipse.c                       +-----+-----+--+--+--+--+   */
/* Version :     1.2	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/9/92	10:07:19	                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Part      :  drawing module                                           */
/*                                                                            */
/*      Functions :  calculate_angle (), calculate_end_angle (),              */
/*                   get_begin_angle (), get_end_angle (),                    */
/*                   handle_ellipse ()                                        */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <math.h>
#include <values.h>

#include <Mrm/MrmAppl.h>

#include "drawstate.h"
#include "drawmisc.h"

#include "../ui/defs.h"
#include "../misc/ographic.h"
#include "../ui/layer.h"
#include "../kernel/user.h"


/* ========================================================================== */
/*      DEFINE STATEMENTS                                                     */
/* ========================================================================== */

#ifndef MIN
#define MIN(a,b) (a>b ? b : a)
#endif

/* constants for defining the direction in which the arc is to be drawn       */
#define CW  0                                /* clockwise         arc drawing */
#define CCW 1                                /* counter-clockwise arc drawing */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  calculate_angle ()                                       */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  calculates an angle for drawing an arc from the x/y-     */
/*                   positions of a line                                      */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  get_begin_angle ()                                       */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

void calculate_angle (XPoint middle, XPoint end,
                      float aspect_ratio, int* angle_p)
{
  double xdiff, ydiff;                /* the differences in x/y-direction of  */
                                      /* the two points                       */

  float angle, skewed_angle;          /* the normal and the skewed angle for  */
                                      /* drawing the arc. The normal angle is */
                                      /* measured in the normal coordinate    */
                                      /* system of the screen, the skewed     */
                                      /* angle is measured in the coordinate  */
                                      /* system of the ellipse (if the ellipse*/
                                      /* is a circle, both coordinate systems */
                                      /* are identical).                      */
                                      /* Float variables are needed to get    */
                                      /* the angle more exact.                */
  float adjust;                       /* this adjust is needed to convert the */
                                      /* normal angle into the skewed angle   */


  xdiff = (double) (end.x - middle.x);
  ydiff = (double) (middle.y - end.y);

  /* calculate the angle in the range [-pi, pi] from x/y differences          */
  angle = atan2(ydiff, xdiff);

  /* We have to change the coordinate system here from the normal to the      */
  /* ellipse's system, because the X function 'XDrawArc' needs angles in the  */
  /* ellipse's coordinate system.                                             */

  if (angle >= 0)
    if (angle < M_PI_2)
      adjust = 0;
    else
      adjust = M_PI;
  else
    if (angle > -M_PI_2)
      adjust = 0;
    else
      adjust = -M_PI;

  skewed_angle = atan(tan(angle) * aspect_ratio) + adjust;
 
  /* transform the skewed angle from radians to degrees */
  skewed_angle = (180 / M_PI) * skewed_angle;

  /* We have to change the format of this angle from [float] <angle1> to      */
  /* [int] <degrees*64>, because the X function 'XDrawArc' needs this format. */
  *angle_p = (int) rint (skewed_angle*64);

  return;
} /* calculate_angle */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  compute_direction ()                                     */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  computes the actual arc drawing direction                */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  calculate_end_angle ()                                   */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

unsigned int compute_direction (int begin_angle, int actual_angle,
                                int last_angle, unsigned int old_dir)
{
  unsigned int new_dir;


  /* check wether the user moved the mouse pointer over the start position,   */
  /* if so, set the current direction.                                        */
  if ((actual_angle < begin_angle) && (begin_angle <= last_angle))
  {
    /* the cursor was moved over the begin angle in clockwise direction or    */    /* over the NULL-angle in counterclockwise direction                      */

    /* now we check wether it was moved over the NULL-position or not         */
    if (((  0    <= actual_angle) && (actual_angle <   90*64))  &&
        ((270*64 <  last_angle  ) && (last_angle   <= 360*64)))
    {
      /* cursor was moved over the NULL-position. We have to react only if    */
      /* the begin_angle is exactly the NULL-position.                        */

      if (begin_angle == 0)
      {
        /* begin_angle == NULL-position; we have to set the direction         */
        new_dir = CCW;
      }
      else
      {
        /* begin_angle != NULL-position, we can ignore this                   */
        new_dir = old_dir;
      }
    }
    else
    {
      /* cursor was moved over the begin_angle, which is NOT the              */
      /* NULL-position. We have to set the direction.                         */
      new_dir = CW;
    }
  }
  else if ((actual_angle > begin_angle) && (begin_angle >= last_angle))
  {
    /* the cursor was moved over the begin angle in counterclockwise          */
    /* direction or over the NULL-angle in clockwise direction                */

    /* now we check wether it was moved over the NULL-position or not         */
    if (((  0    <= last_angle  ) && (last_angle   <   90*64))  &&
        ((270*64 <  actual_angle) && (actual_angle <= 360*64)))
    {
      /* cursor was moved over the NULL-position. We have to react only if    */
      /* the begin_angle is exactly the NULL-position.                        */

      if (begin_angle == 0)
      {
        /* begin_angle == NULL-position; we have to set the direction         */
        new_dir = CW;
      }
      else
      {
        /* begin_angle != NULL-position, we can ignore this                   */
        new_dir = old_dir;
      }
    }
    else
    {
      /* cursor was moved over the begin_angle, which is NOT the              */
      /* NULL-position. We have to set the direction.                         */
      new_dir = CCW;
    }
  }
  else
  {
    /* the cursor was NOT moved over the begin angle or the NULL-angle.       */
    /* we can ignore this                                                     */
    new_dir = old_dir;
  }

  return new_dir;
} /* compute_direction */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  calculate_end_angle ()                                   */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  calculates an angle for drawing an arc from the x/y-     */
/*                   positions of a line                                      */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  get_end_angle ()                                         */
/*                                                                            */
/*      Calls     :  calculate_angle (), compute_direction ()                 */
/*                                                                            */
/* ========================================================================== */

void calculate_end_angle (XPoint middle, XPoint end,
                          float aspect_ratio, int begin_angle, int* angle_p,
                          int* last_angle, unsigned int* direction)
{
  /* calculate the angle */
  calculate_angle (middle, end, aspect_ratio, angle_p);

  /* change the angle so that we have only angles in the range  */
  /* [0,360] instead of [-180,180]                              */
  if (*angle_p < 0)
    *angle_p = 360*64 + *angle_p;

  /* compute the actual direction                                             */
  *direction = compute_direction (begin_angle, *angle_p, *last_angle,
                                  *direction);
  *last_angle = *angle_p;

  /* transform the angle by subtracting the begin_angle. Doing this we get    */
  /* the Null Point at the Point of the begin_angle.                          */
  *angle_p = *angle_p - begin_angle;

  /* change sign of angles if needed so that the angle is drawn in the right  */
  /* direction                                                                */
  if (*direction == CW)
  {
    /* drawing is done clockwise */
    /* transform the angle so that it is always negativ.                      */
    if (*angle_p > 0)
      *angle_p = *angle_p - 360*64;
  }
  else
  {
    /* drawing is done counter-clockwise */
    /* transform the angle so that it is always positiv.                      */
    if (*angle_p < 0)
      *angle_p = 360*64 + *angle_p;
  }

  return;
} /* calculate_end_angle */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  get_begin_angle ()                                       */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  gets the begin_angle for drawing an arc with             */
/*                   rubberbanding                                            */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  handle_ellipse ()                                        */
/*                                                                            */
/*      Calls     :  calculate_angle ()                                       */
/*                                                                            */
/* ========================================================================== */

void get_begin_angle (XPoint middle, float aspect_ratio,
                      XPoint* actual, int* begin_angle_p)
{
  XPoint act;                         /* actual position of the mouse         */
  XEvent event;                       /* the actual event                     */

  /* draw the rubberband line */
  act.x = actual->x;
  act.y = actual->y;

  XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
             middle.x, middle.y, act.x, act.y);

  XGrabPointer (DrawDisplay, DrawWindow, True,
                ButtonPressMask|ButtonReleaseMask|PointerMotionMask,
                GrabModeAsync, GrabModeAsync, DrawWindow, None, CurrentTime);
             
  /* draw the rubberband line while waiting for a button-press event */
  XNextEvent (DrawDisplay,&event);

  while (!((event.type == ButtonPress) && (event.xbutton.button == Button1)))
  {
    if (event.type == MotionNotify)
    {
      /* undraw old line */
      XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
                 middle.x, middle.y, act.x, act.y);

      /* get position of mouse */
      act.x = event.xmotion.x;
      act.y = event.xmotion.y;

      /* draw new line */
      XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
                 middle.x, middle.y, act.x, act.y);
    }

    XNextEvent (DrawDisplay,&event);
  }

  /* undraw old line */
  XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
             middle.x, middle.y, act.x, act.y);

  /* get position of button press */
  act.x = event.xbutton.x;
  act.y = event.xbutton.y;

  /* draw new line */
  XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
             middle.x, middle.y, act.x, act.y);

  /* loop until the button is released */
  while (!((event.type == ButtonRelease) && (event.xbutton.button == Button1)))
  {
    if (event.type == MotionNotify)
    {
      /* if there are more than one motion event, remove them from the queue */
      remove_events (&event);

      /* undraw old line */
      XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
                 middle.x, middle.y, act.x, act.y);

      /* get new position */
      act.x = event.xmotion.x;
      act.y = event.xmotion.y;

      /* draw new line */
      XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
                 middle.x, middle.y, act.x, act.y);
    } /* if */
    XNextEvent (DrawDisplay, &event);
  } /* while */

  /* undraw old line */
  XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
             middle.x, middle.y, act.x, act.y);

  XUngrabPointer (DrawDisplay, CurrentTime);

  /* get new position */
  act.x = event.xbutton.x;
  act.y = event.xbutton.y;

  /* get angle from x/y-positions */
  calculate_angle (middle, act, aspect_ratio, begin_angle_p);

  /* return the last mouse position */
  actual->x = act.x;
  actual->y = act.y;

  /* ... and change the begin_angle so that we have only angles in the range  */
  /* [0,360] instead of [-pi,pi]                                              */
  if (*begin_angle_p < 0)
    *begin_angle_p = 360*64 + *begin_angle_p;

  return;
} /* get_begin_angle */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  get_end_angle ()                                         */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  gets the end_angle for drawing an arc with               */
/*                   rubberbanding                                            */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  handle_ellipse ()                                        */
/*                                                                            */
/*      Calls     :  calculate_end_angle ()                                   */
/*                                                                            */
/* ========================================================================== */

void get_end_angle (XPoint middle, XPoint lu,
                    int width, int height, float aspect_ratio,
                    int begin_angle, XPoint actual, int* end_angle_p)
{
  XPoint       act;                   /* actual position of the mouse         */
  XEvent       event;                 /* the actual event                     */

  int          last_angle;            /* a buffer with the last angle the     */
                                      /* pointer had marked                   */
  unsigned int direction = CW;        /* a flag indicating in which direction */
                                      /* the arc is drawn (clockwise/counter- */
                                      /* clockwise).                          */
                                      /* Can get the values CW and CCW.       */


  /* draw the rubberband line & arc */
  act.x = actual.x;
  act.y = actual.y;

  last_angle   = begin_angle;
  *end_angle_p = 0;

  XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
             middle.x, middle.y, act.x, act.y);
  XDrawArc  (DrawDisplay, DrawWindow, DrawGCxor,
             lu.x, lu.y, width*2, height*2,
             begin_angle, *end_angle_p);

  XGrabPointer (DrawDisplay, DrawWindow, True,
                ButtonPressMask|ButtonReleaseMask|PointerMotionMask,
                GrabModeAsync, GrabModeAsync, DrawWindow, None, CurrentTime);

  /* draw the rubberband line & arc while waiting for a button-press event */
  XNextEvent (DrawDisplay,&event);

  while (!((event.type == ButtonPress) && (event.xbutton.button == Button1)))
  {
    if (event.type == MotionNotify)
    {
      /* undraw old line & arc */
      XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
                 middle.x, middle.y, act.x, act.y);
      XDrawArc  (DrawDisplay, DrawWindow, DrawGCxor,
                 lu.x, lu.y, width*2, height*2,
                 begin_angle, *end_angle_p);

      /* get position of mouse */
      act.x = event.xmotion.x;
      act.y = event.xmotion.y;

      /* calculate angle from x/y-positions */
      calculate_end_angle (middle, act, aspect_ratio,
                           begin_angle, end_angle_p, &last_angle, &direction);

      /* draw new line & arc */
      XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
                 middle.x, middle.y, act.x, act.y);
      XDrawArc  (DrawDisplay, DrawWindow, DrawGCxor,
                 lu.x, lu.y, width*2, height*2,
                 begin_angle, *end_angle_p);
    }

    XNextEvent (DrawDisplay,&event);
  }

  /* undraw old line & arc */
  XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
             middle.x, middle.y, act.x, act.y);
  XDrawArc  (DrawDisplay, DrawWindow, DrawGCxor,
             lu.x, lu.y, width*2, height*2,
             begin_angle, *end_angle_p);

  /* get position of button press */
  act.x = event.xbutton.x;
  act.y = event.xbutton.y;

  /* calculate angle from x/y-positions */
  calculate_end_angle (middle, act, aspect_ratio,
                       begin_angle, end_angle_p, &last_angle, &direction);

  /* draw new line & arc */
  XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
             middle.x, middle.y, act.x, act.y);
  XDrawArc  (DrawDisplay, DrawWindow, DrawGCxor,
             lu.x, lu.y, width*2, height*2,
             begin_angle, *end_angle_p);

  /* loop until the button is released */
  while (!((event.type == ButtonRelease) && (event.xbutton.button == Button1)))
  {
    if (event.type == MotionNotify)
    {
      /* if there are more than one motion event, remove them from the queue */
      remove_events (&event);

      /* undraw old line & arc */
      XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
                 middle.x, middle.y, act.x, act.y);
      XDrawArc  (DrawDisplay, DrawWindow, DrawGCxor,
                 lu.x, lu.y, width*2, height*2,
                 begin_angle, *end_angle_p);

      /* get new position */
      act.x = event.xmotion.x;
      act.y = event.xmotion.y;

      /* calculate angle from x/y-positions */
      calculate_end_angle (middle, act, aspect_ratio,
                           begin_angle, end_angle_p, &last_angle, &direction);

      /* draw new line & arc */
      XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
                 middle.x, middle.y, act.x, act.y);
      XDrawArc  (DrawDisplay, DrawWindow, DrawGCxor,
                 lu.x, lu.y, width*2, height*2,
                 begin_angle, *end_angle_p);
    } /* if */
    XNextEvent (DrawDisplay,&event);
  } /* while */

  XUngrabPointer (DrawDisplay, CurrentTime);

  /* undraw old line & arc */
  XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
             middle.x, middle.y, act.x, act.y);
  XDrawArc  (DrawDisplay, DrawWindow, DrawGCxor,
             lu.x, lu.y, width*2, height*2,
             begin_angle, *end_angle_p);

  /* get new position */
  act.x = event.xbutton.x;
  act.y = event.xbutton.y;

  /* get angle from x/y-positions */
  calculate_end_angle (middle, act, aspect_ratio,
                       begin_angle, end_angle_p, &last_angle, &direction);

  return;
} /* get_end_angle */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  handle_ellipse ()                                        */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  handles circle, ellipse and arc drawing with             */
/*                   bounding box and rubberbanding                           */
/*                                                                            */
/*      Accesses  :  ownUserNumber, obj_count                                 */
/*                                                                            */
/*      Called by :  draw () in draw.c                                        */
/*                                                                            */
/*      Calls     :  get_begin_angle (), get_end_angle (),                    */
/*                                                                            */
/*                   remove_events () in drawmisc.c,                          */
/*                                                                            */
/*                   InsertArc () in misc/ographic.c,                         */
/*                                                                            */
/*                   msg_draw_arc () in kernel/user.c,                        */
/*                                                                            */
/*                   GetActiveLayer(), GetStructStorage()                     */
/*                   in ui/layer.c                                            */
/*                                                                            */
/* ========================================================================== */

void handle_ellipse ( XEvent* startevent, Boolean circle, Boolean full )
{
  XEvent event;                       /* current event in the queue           */

  XPoint start, act;                  /* the starting point and the actual    */
                                      /* and last position of the mouse       */
  XPoint lu, middle;                  /* the upper left corner and the middle */
                                      /* of the rectangle                     */
  unsigned int width, height;         /* its width and height                 */
  float aspect_ratio;                 /* and its aspect ratio (width/height)  */

  int begin_angle, end_angle;         /* the begin and end angle of the arc   */

  struct_storage ss;                  /* the structure storage in which the   */
                                      /* objects are to be written            */

  ss = GetStructStorage (GetActiveLayer ());

  start.x  = startevent->xbutton.x;
  start.y  = startevent->xbutton.y;

  act.x    = start.x;
  act.y    = start.y;

  middle.x = start.x;
  middle.y = start.y;
  width    = 0;
  height   = 0;
  lu.x     = middle.x;
  lu.y     = middle.y;

  /* draw starting point on window */
  XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                  lu.x-1, lu.y-1, (width+1)*2, (height+1)*2);
  XDrawLine      (DrawDisplay, DrawWindow, DrawGCxor,
                  middle.x, middle.y, middle.x + width, middle.y);
  XDrawLine      (DrawDisplay, DrawWindow, DrawGCxor,
                  middle.x, middle.y, middle.x, middle.y - height);
  XDrawArc       (DrawDisplay, DrawWindow, DrawGCxor,
                  lu.x, lu.y, width*2, height*2, 0, 360*64);

  /* get the next event */
  XNextEvent (DrawDisplay,&event);

  /* loop until the button is released */
  while (!((event.type == ButtonRelease) && (event.xbutton.button == Button1)))
  {
    if (event.type == MotionNotify)
    {
      /* if there are more than one motion event, remove them from the queue */
      remove_events (&event);

      act.x = event.xmotion.x;
      act.y = event.xmotion.y;

      /* undraw old rectangle */
      XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                      lu.x-1, lu.y-1, (width+1)*2, (height+1)*2);
      XDrawLine      (DrawDisplay, DrawWindow, DrawGCxor,
                      middle.x, middle.y, middle.x + width, middle.y);
      XDrawLine      (DrawDisplay, DrawWindow, DrawGCxor,
                      middle.x, middle.y, middle.x, middle.y - height);
      XDrawArc       (DrawDisplay, DrawWindow, DrawGCxor,
                      lu.x, lu.y, width*2, height*2, 0, 360*64);

      if (act.x < start.x)
      {
        width = start.x - act.x;
      }
      else
      {
        width = act.x - start.x;
      }

      if (act.y < start.y)
      {
        height = start.y - act.y;
      }
      else
      {
        height = act.y - start.y;
      }

      if (circle)
      {
        width  = MIN(width, height);
        height = width;
      }

      lu.x  = middle.x - width;
      lu.y  = middle.y - height;

      /* draw new rectangle */
      XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                      lu.x-1, lu.y-1, (width+1)*2, (height+1)*2);
      XDrawLine      (DrawDisplay, DrawWindow, DrawGCxor,
                      middle.x, middle.y, middle.x + width, middle.y);
      XDrawLine      (DrawDisplay, DrawWindow, DrawGCxor,
                      middle.x, middle.y, middle.x, middle.y - height);
      XDrawArc       (DrawDisplay, DrawWindow, DrawGCxor,
                      lu.x, lu.y, width*2, height*2, 0, 360*64);

    } /* if */
    XNextEvent (DrawDisplay,&event);
  } /* while */

  act.x = event.xbutton.x;
  act.y = event.xbutton.y;

  /* undraw old rectangle */
  XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                  lu.x-1, lu.y-1, (width+1)*2, (height+1)*2);
  XDrawLine      (DrawDisplay, DrawWindow, DrawGCxor,
                  middle.x, middle.y, middle.x + width, middle.y);
  XDrawLine      (DrawDisplay, DrawWindow, DrawGCxor,
                  middle.x, middle.y, middle.x, middle.y - height);
  XDrawArc       (DrawDisplay, DrawWindow, DrawGCxor,
                  lu.x, lu.y, width*2, height*2, 0, 360*64);

  if (act.x < start.x)
  {
    width = start.x - act.x;
  }
  else
  {
    width = act.x - start.x;
  }

  if (act.y < start.y)
  {
    height = start.y - act.y;
  }
  else
  {
    height = act.y - start.y;
  }

  if (circle)
  {
    width  = MIN(width, height);
    height = width;
  }

  lu.x  = middle.x - width;
  lu.y  = middle.y - height;

  if (full)
  {
    /* set angles to 0 and 360 degrees */
    begin_angle = 0;
    end_angle   = 360*64;
  }
  else
  {
    /* calculate aspect ratio */
    if (height == 0)
      if (width == 0)
        aspect_ratio = 1.0;
      else
        aspect_ratio = MAXFLOAT;
    else
      aspect_ratio = (float) width / (float) height;

    /* draw bounding rectangle again */
    XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                    lu.x-1, lu.y-1, (width+1)*2, (height+1)*2);
    XDrawArc       (DrawDisplay, DrawWindow, DrawGCxor,
                    lu.x, lu.y, width*2, height*2, 0, 360*64);

    /* get the begin_angle */
    get_begin_angle (middle, aspect_ratio, &act, &begin_angle);

    /* undraw whole ellipse */
    XDrawArc       (DrawDisplay, DrawWindow, DrawGCxor,
                    lu.x, lu.y, width*2, height*2, 0, 360*64);

    /* get the end_angle */
    get_end_angle (middle, lu, width, height, aspect_ratio,
                   begin_angle, act, &end_angle);

    /* undraw old rectangle */
    XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                    lu.x-1, lu.y-1, (width+1)*2, (height+1)*2);
  }

  /* draw ellipse solid on window */
  XDrawArc (DrawDisplay, DrawWindow, DrawGCsolid,
            lu.x, lu.y, width*2, height*2,
            begin_angle, end_angle);

  /* send message */
  msg_draw_arc (lu.x, lu.y, width*2, height*2,
                begin_angle, end_angle,
                get_draw_state (LINE_WIDTH),
                get_draw_state (LINE_STYLE),
                ownUserNumber, obj_count);

  /* insert ellipse-object in structure-storage */
  InsertArc (ss, lu.x, lu.y, width*2, height*2,
             begin_angle, end_angle,
             get_draw_state (LINE_WIDTH), get_draw_state (LINE_STYLE),
             ownUserNumber, obj_count);

  obj_count++;
} /* handle_ellipse */
