/* ========================================================================== */
/*           Forward-Declarations of Functions defined in 'drawmisc.c'        */
/* ========================================================================== */

extern void remove_events ( XEvent* );
extern int dist ( XPoint, XPoint );
extern void set_font_table ();
extern Boolean get_font_table (int, int, int, XFontStruct*, Boolean);
