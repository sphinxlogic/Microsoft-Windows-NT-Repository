/* ========================================================================== */
/*                                                                            */
/* Filename:     dpointer.c                       +-----+-----+--+--+--+--+   */
/* Version :     1.2	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/9/92	10:07:41	                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Module    :  drawing module                                           */
/*                                                                            */
/*      Functions :  draw_pointer (), ptr_in_box (),                          */
/*                   redraw_all_except_one_pointer (), remove_pointer (),     */
/*                   start_pointer (), move_pointer (), end_pointer (),       */
/*                   redraw_all_pointers (), handle_pointer ()                */
/*                                                                            */
/* ========================================================================== */


/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */


#include <string.h>
#include <Mrm/MrmAppl.h>

#include "drawstate.h"
#include "drawmisc.h"

#include "../misc/ographic.h"
#include "../ui/layer.h"
#include "../kernel/user.h"
#include "../ui/sketchpad.h"
#include "../ui/defs.h"
#include "../global/global.h"
#include "../global/userdata.h"
#include "../image/picio.h"


/* ========================================================================== */
/*      DEFINE STATEMENTS                                                     */
/* ========================================================================== */

#define ARROWLEN 10


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  draw_pointer()                                           */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  routine for drawing the pointer in the drawing area      */
/*                                                                            */
/*      Accesses  :  ptr_bbox[]                                               */
/*                                                                            */
/*      Called by :  redraw_all_except_one_pointer(), start_pointer(),        */
/*                   move_pointer(), redraw_all_pointers()                    */
/*                                                                            */
/*      Calls     :  GetUserNameFromId in global/userdata.c                   */
/*                                                                            */
/* ========================================================================== */

static void draw_pointer ( int user_number )
{
  char         ptr_txt[MAXUSERNAMELEN+1];

  int          direction_return;
  int          font_ascent_return, font_descent_return;
  XCharStruct  overall_return;

  XRectangle   ptr_rec;
  XPoint       ptr_txt_point, arrow_points[5];
  int          x, y;

  /* get the coordinates of the upper left corner of the pointer */
  x = ptr_bbox[user_number].x;
  y = ptr_bbox[user_number].y;

  /* get pointer-text. this text is simply the name of the user */
  strcpy (ptr_txt, GetUserNameFromId (user_number));

  /* compute size of bounding rectangle */
  XTextExtents (ptr_font, ptr_txt, strlen (ptr_txt), &direction_return,
                &font_ascent_return, &font_descent_return, &overall_return);

  ptr_rec.width  = overall_return.rbearing - overall_return.lbearing + 3;
  ptr_rec.height = overall_return.ascent   + overall_return.descent  + 3;

  /* compute position of bounding rectangle and pointer-text */
  ptr_rec.x = x + ARROWLEN;
  ptr_rec.y = y + ARROWLEN;

  ptr_txt_point.x = ptr_rec.x - overall_return.lbearing + 2;
  ptr_txt_point.y = ptr_rec.y + overall_return.ascent +
                                overall_return.descent + 1;

  /* compute bounding box for restoring picture */
  ptr_bbox[user_number].width  = ARROWLEN + ptr_rec.width  + 1;
  ptr_bbox[user_number].height = ARROWLEN + ptr_rec.height + 1;

  /* draw the pointer which consists of a rectangle with a text and an arrow */
  XDrawImageString (DrawDisplay, DrawWindow, DrawGCWhite,
                    ptr_txt_point.x, ptr_txt_point.y, ptr_txt, strlen(ptr_txt));
  XDrawRectangle   (DrawDisplay, DrawWindow, DrawGCWhite,
                    ptr_rec.x, ptr_rec.y, ptr_rec.width, ptr_rec.height);

  /* build up the arrow */
  arrow_points[0].x = x;
  arrow_points[0].y = y + ARROWLEN/2;
  arrow_points[1].x = x;
  arrow_points[1].y = y;
  arrow_points[2].x = x + ARROWLEN/2;
  arrow_points[2].y = y;
  arrow_points[3].x = x;
  arrow_points[3].y = y;
  arrow_points[4].x = ptr_rec.x;
  arrow_points[4].y = ptr_rec.y;

  /* and draw the arrow */
  XDrawLines (DrawDisplay, DrawWindow, DrawGCWhite,
              arrow_points, 5, CoordModeOrigin);
} /* draw_pointer */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  ptr_in_box()                                             */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  checks wether a pointer meets a rectangle and            */
/*                   returns 'TRUE' if it does, 'FALSE' otherwise             */
/*                                                                            */
/*      Accesses  :  ptr_bbox[]                                               */
/*                                                                            */
/*      Called by :  redraw_all_except_one_pointer(), redraw_all_pointers()   */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

static Boolean ptr_in_box ( int i, XRectangle rec )
{
  /* check wether the pointer meets the rectangle */
  if ((ptr_bbox[i].x + ptr_bbox[i].width  >= rec.x             ) &&
      (ptr_bbox[i].x                      <= rec.x + rec.width ) &&
      (ptr_bbox[i].y + ptr_bbox[i].height >= rec.y             ) &&
      (ptr_bbox[i].y                      <= rec.y + rec.height))
    return TRUE;
  else
    return FALSE;
} /* ptr_in_box */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  redraw_all_except_one_pointer()                          */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  draw visible pointers again after removing a pointer,    */
/*                   except one of them.                                      */
/*                                                                            */
/*      Accesses  :  pointer_visible[]                                        */
/*                                                                            */
/*      Called by :  remove_pointer()                                         */
/*                                                                            */
/*      Calls     :  ptr_in_box(), draw_pointer()                             */
/*                                                                            */
/* ========================================================================== */

static void redraw_all_except_one_pointer
          ( XRectangle expose_rec, int exception_number )
{
  int i;

  /* check for each pointer wether it is visible and within the exposed area  */
  for(i=0; i<MAXUSERS; i++)
    if (pointer_visible[i] && ptr_in_box (i, expose_rec))

      /* if the pointer is not the one which is not to be drawn, draw it again*/
      if (i != exception_number)
        draw_pointer (i);
} /* redraw_all_except_one_pointer */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  remove_pointer()                                         */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  routine for removing a pointer and restoring picture in  */
/*                   drawing area                                             */
/*                                                                            */
/*      Accesses  :  ptr_bbox[]                                               */
/*                                                                            */
/*      Called by :  end_pointer(), move_pointer()                            */
/*                                                                            */
/*      Calls     :  redraw_all_except_one_pointer(),                         */
/*                   RedrawRasterImage() in image/picio.c,                    */
/*                                                                            */
/*                   GetFirstLayer (), GetLayerState (), GetNextLayer (),     */
/*                   DrawLayer () in ui/layer.c                               */
/*                                                                            */
/* ========================================================================== */

static void remove_pointer ( int user_number )
{
  void *layer;

  /* clear area */
  XClearArea (XtDisplay (widget_array[v_drawing_area]),
              XtWindow  (widget_array[v_drawing_area]),
              ptr_bbox[user_number].x,     ptr_bbox[user_number].y,
              ptr_bbox[user_number].width, ptr_bbox[user_number].height,
              FALSE);

  /* draw the background image in that area again */
  RedrawRasterImage (ptr_bbox[user_number]);

  /* draw objects in that area of visible layers again */
  layer = GetFirstLayer ();
  while (layer != NULL)
  {
    if (GetLayerState (layer) & LS_VISIBLE)
    {
      DrawLayer (layer, ptr_bbox[user_number]);
    }
    layer = GetNextLayer ();
  }

  /* draw all visible pointers except the own one in that area again */
  redraw_all_except_one_pointer (ptr_bbox[user_number], user_number);

} /* remove_pointer */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  start_pointer()                                          */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  routine for drawing a pointer in the drawing area        */
/*                                                                            */
/*      Accesses  :  ptr_bbox[], pointer_visible[]                            */
/*                                                                            */
/*      Called by :  handle_pointer (),                                       */
/*                   receiveMessageProc() in kernel/user.c                    */
/*                                                                            */
/*      Calls     :  draw_pointer()                                           */
/*                                                                            */
/* ========================================================================== */

void start_pointer ( int x_new, int y_new, int user_number)
{
  /* save the pointers current position                 */
  /* which is the upper left corner of its bounding box */
  ptr_bbox[user_number].x = x_new;
  ptr_bbox[user_number].y = y_new;

  /* draw the pointer on the own window */
  draw_pointer (user_number);

  /* mark the pointer as 'visible' */
  pointer_visible[user_number] = TRUE;
} /* start_pointer */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  move_pointer()                                           */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  routine for removing the pointer, restoring the picture  */
/*                   and drawing a new pointer in the drawing area            */
/*                                                                            */
/*      Accesses  :  ptr_bbox[]                                               */
/*                                                                            */
/*      Called by :  handle_pointer (),                                       */
/*                   receiveMessageProc() in kernel/user.c                    */
/*                                                                            */
/*      Calls     :  remove_pointer(), draw_pointer()                         */
/*                                                                            */
/* ========================================================================== */

void move_pointer ( int x_new, int y_new, int user_number )
{
  /* remove the pointer from the old location on the window */
  remove_pointer (user_number);

  /* save the pointer's new position */
  ptr_bbox[user_number].x = x_new;
  ptr_bbox[user_number].y = y_new;

  /* draw it again at the new position */
  draw_pointer (user_number);
} /* move_pointer */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  end_pointer()                                            */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  routine for removing pointer and restoring picture in    */
/*                   drawing area                                             */
/*                                                                            */
/*      Accesses  :  pointer_visible[]                                        */
/*                                                                            */
/*      Called by :  handle_pointer (),                                       */
/*                   set_draw_mode() in setdraw.c,                            */
/*                   receiveMessageProc() in kernel/user.c                    */
/*                                                                            */
/*      Calls     :  remove_pointer()                                         */
/*                                                                            */
/* ========================================================================== */

void end_pointer ( int user_number )
{
  /* remove the pointer from the window */
  remove_pointer (user_number);

  /* mark the pointer as 'not visible' */
  pointer_visible[user_number] = FALSE;
} /* end_pointer */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  redraw_all_pointers()                                    */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  draw all visible pointers again                          */
/*                                                                            */
/*      Accesses  :  pointer_visible[]                                        */
/*                                                                            */
/*      Called by :  expose_proc() in ui/sketchpad.c,                         */
/*                   PickObject(), DeselectAll(), DeselectAllExceptOne(),     */
/*                   MoveObject(), DeletePickedObjects(), SizeObject(),       */
/*                   DeleteObject() and WriteObjects() in misc/ographic.c     */
/*                                                                            */
/*      Calls     :  ptr_in_box(), draw_pointer()                             */
/*                                                                            */
/* ========================================================================== */

void redraw_all_pointers ( XRectangle expose_rec )
{
  int i;

  /* check for each pointer wether it is visible and within the exposed area  */
  for(i=0; i<MAXUSERS; i++)
    if (pointer_visible[i] && ptr_in_box (i, expose_rec))

      /* draw the pointer again */
      draw_pointer (i);
} /* redraw_all_pointers */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  handle_pointer ()                                        */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  handles the pointer                                      */
/*                                                                            */
/*      Accesses  :  my_pointer_visible                                       */
/*                                                                            */
/*      Called by :  draw () in draw.c                                        */
/*                                                                            */
/*      Calls     :  end_pointer (), start_pointer (), move_pointer (),       */
/*                                                                            */
/*                   remove_events () in drawmisc.c,                          */
/*                                                                            */
/*                   msg_end_pointer (), msg_start_pointer (),                */
/*                   msg_move_pointer ()                                      */
/*                   in kernel/user.c                                         */
/*                                                                            */
/* ========================================================================== */

void handle_pointer ( XEvent* startevent )
{
  XEvent event;                       /* current event in the queue           */

  XPoint pos;                         /* the actual position of the pointer   */


  /* if an old pointer is still visible to others, remove it before */
  /* starting a new one                                             */

  if (my_pointer_visible)
  {
    /* send message for removing old pointer */
    msg_end_pointer ();

    /* remove pointer on own window */
    end_pointer (ownUserNumber);

    my_pointer_visible = FALSE;
  }

  /* get the start position */
  pos.x = startevent->xbutton.x;
  pos.y = startevent->xbutton.y;

  /* send message with coordinates to others */
  msg_start_pointer (pos.x, pos.y);

  /* start pointer on own window */
  start_pointer (pos.x, pos.y, ownUserNumber);

  my_pointer_visible = TRUE;

  /* get the next event */
  XNextEvent (DrawDisplay,&event);

  /* loop until the button is released */
  while (!((event.type == ButtonRelease) && (event.xbutton.button == Button1)))
  {
    if (event.type == MotionNotify)
    {
      /* if there are more than one motion event, remove them from the queue */
      remove_events (&event);

      /* get the actual position */
      pos.x = event.xmotion.x;
      pos.y = event.xmotion.y;

      /* send message for restoring picture and drawing new cursor */
      msg_move_pointer (pos.x, pos.y);
 
      /* move pointer on own window */
      move_pointer (pos.x, pos.y, ownUserNumber);
    } /* if */
    XNextEvent (DrawDisplay,&event);
  } /* while */
} /* handle_pointer */
