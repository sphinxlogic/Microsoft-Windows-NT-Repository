/* ========================================================================== */
/*           Forward-Declarations of Functions defined in 'dpolyline.c'       */
/* ========================================================================== */

extern void handle_polyline ( XEvent* );
