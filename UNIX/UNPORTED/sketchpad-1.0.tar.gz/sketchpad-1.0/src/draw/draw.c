/* ========================================================================== */
/*                                                                            */
/* Filename:     draw.c                           +-----+-----+--+--+--+--+   */
/* Version :     1.3	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/15/92	10:45:32	                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Part      :  drawing module                                           */
/*                                                                            */
/*      Functions :  draw_line(),                                             */
/*                   draw()                                                   */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <stdio.h>
#include <Mrm/MrmAppl.h>

#include "drawstate.h"
#include "setdraw.h"

#include "dpointer.h"
#include "dselector.h"
#include "dline.h"
#include "dpolyline.h"
#include "dfreehand.h"
#include "drectangle.h"
#include "dellipse.h"
#include "dtext.h"
#include "dzoom.h"

#include "../misc/ographic.h"
#include "../ui/defs.h"
#include "../kernel/user.h"
#include "../kernel/message.h"
#include "../ui/sketchpad.h"
#include "../ui/layer.h"
# ifdef IBM3D
#include "../ibm3d/tb.h"
#include "../ibm3d/dreiD.h"
# endif

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  draw_line()                                              */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  routine for drawing in pixmap and drawing area           */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  receiveMessageProc() in kernel/user.c,                   */
/*                                                                            */
/*                   indirect calls:                                          */
/*                   assignment to the function variable 'line'               */
/*                   in ui/sketchpad.c                                        */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

void draw_line ( int x1, int y1, int x2, int y2 )
{
  /* draw line solid on window */
  XDrawLine (DrawDisplay, DrawWindow, ForeignGC, x1, y1, x2, y2);
} /* draw_line */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  draw()                                                   */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  handle inputs in DrawingArea                             */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  draw_proc() in sketchpad.c (callback procedure)          */
/*                                                                            */
/*      Calls     :  handle_selector () in dselector.c,                       */
/*                   handle_pointer () in dpointer.c,                         */
/*                   handle_line () in dline.c,                               */
/*                   handle_freehand () in dfreehand.c,                       */
/*                   handle_rectangle () in drectangle.c,                     */
/*                   handle_ellipse () in dellipse.c,                         */
/*                   handle_text () in dtext.c,                               */
/*                                                                            */
/*                   get_draw_state() in setdraw.c,                           */
/*                                                                            */
/*                   GetActiveLayer(), GetLayerColor () in layer.c            */
/*                                                                            */
/* ========================================================================== */

void draw ( XEvent* DrawEvent )
{
# ifdef IBM3D
  void  draw_ibm3d (XEvent *);
  int   Mode3d ();

  if (Mode3d() == M3D_VIEW)
  {
    draw_ibm3d (DrawEvent);
    return;
  }
# endif
  /* check wether an active layer exists */
  if (GetActiveLayer () != NULL)
  {
    /* decide what to do -- according to the MODE the user has chosen */
    switch (DrawEvent->type)
    {
      case ButtonPress:
        if (DrawEvent->xbutton.button == Button1)
        {
          switch (get_draw_state(MODE))
          {
            case v_draw_button_selector:
              handle_selector (DrawEvent);
            break;

            case v_draw_button_pointer:
              handle_pointer (DrawEvent);
            break;

            case v_draw_button_line:
              XSetForeground (DrawDisplay, DrawGCsolid,
                              GetLayerColor (GetActiveLayer()));
              handle_line (DrawEvent);
            break;

            case v_draw_button_polyline:
              XSetForeground (DrawDisplay, DrawGCsolid,
                              GetLayerColor (GetActiveLayer()));
              handle_polyline (DrawEvent);
            break;

            case v_draw_button_freehand:
              XSetForeground (DrawDisplay, DrawGCsolid,
                              GetLayerColor (GetActiveLayer()));
              handle_freehand (DrawEvent);
            break;

            case v_draw_button_rectangle:
              XSetForeground (DrawDisplay, DrawGCsolid,
                              GetLayerColor (GetActiveLayer()));
              handle_rectangle (DrawEvent);
            break;

            case v_draw_button_circle:
              XSetForeground (DrawDisplay, DrawGCsolid,
                              GetLayerColor (GetActiveLayer()));
              handle_ellipse (DrawEvent, True, True);
            break;

            case v_draw_button_ellipse:
              XSetForeground (DrawDisplay, DrawGCsolid,
                              GetLayerColor (GetActiveLayer()));
              handle_ellipse (DrawEvent, False, True);
            break;

            case v_draw_button_arc:
              XSetForeground (DrawDisplay, DrawGCsolid,
                              GetLayerColor (GetActiveLayer()));
              handle_ellipse (DrawEvent, False, False);
            break;

            case v_draw_button_text:
              XSetForeground (DrawDisplay, DrawGCtext,
                              GetLayerColor (GetActiveLayer()));
              handle_text (DrawEvent);
            break;

            case v_draw_button_zoom:
              handle_zoom (DrawEvent);
            break;


          } /* switch (get_draw_state (MODE)) */
        } /* if */
        else if (DrawEvent->xbutton.button == Button3)
        {
          switch (get_draw_state(MODE))
          {
            case v_draw_button_zoom:
              handle_zoom (DrawEvent);
            break;

            case v_draw_button_selector:
              handle_selector (DrawEvent);
            break;
          } /* switch */
        } /* else if */
      break;

      case ButtonRelease:
/*
 *      printf ("ButtonRelease.\n");
 */
      break;

      case MotionNotify:
/*
 *      printf ("MotionNotify.\n");
 */
      break;

      default:
/*
 *      printf ("something else.\n");
 */
      break;

    } /* switch (DrawEvent->Type) */

  } /* if */

} /* draw() */

# ifdef IBM3D
void draw_ibm3d ( XEvent* DrawEvent )
{
  void ViReadXY (short, short);

  switch (DrawEvent->type)
  {
    case ButtonPress:   if (DrawEvent->xbutton.button == Button1)
                        if( Mode3d() == M3D_VIEW )
                        {
                          ViReadXY ((short)DrawEvent->xbutton.x, (short)DrawEvent->xbutton.y);
                          return;
                        }
                        break;

    case ButtonRelease: /* printf ("ButtonRelease.\n"); */
                        break;

/*         if(Mode3d()==M3D_VIEW) */
/*         { */
/*           void ViEndPos( short, short ); */
/*  */
/*           ViEndPos (report.xbutton.x, act.y = report.xbutton.y); */
/*           ready = TRUE; */
/*         } */
      break;

    case MotionNotify:  /* printf ("MotionNotify.\n"); */
			break;

/*         if(Mode3d()==M3D_VIEW) */
/*         { */
/*           void ViCoordStream( short, short ); */
/*           ViCoordStream( report.xmotion.x, report.xmotion.y ); */
/*         } */
      break;

      default:          printf ("something else.\n");
                        break;
  } /* switch (DrawEvent->Type) */

} /* draw_ibm3d() */
# endif IBM3D
