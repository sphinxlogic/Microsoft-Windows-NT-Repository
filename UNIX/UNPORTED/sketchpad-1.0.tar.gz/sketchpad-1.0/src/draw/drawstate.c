/* ========================================================================== */
/*                                                                            */
/* Filename:     drawstate.c                      +-----+-----+--+--+--+--+   */
/* Version :     1.3	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/15/92	10:45:36	                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Part      : drawing module                                            */
/*                                                                            */
/*      Functions : set_draw_state(), get_draw_state()                        */
/*                                                                            */
/* ========================================================================== */


/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <Mrm/MrmAppl.h>
#include <stdio.h>

#include "../misc/sperror.h"
#include "../misc/ographic.h"
#include "../ui/sketchpad.h"
#include "../ui/layer.h"
#include "../ui/defs.h"


/* ========================================================================== */
/*      DEFINE STATEMENTS                                                     */
/* ========================================================================== */

#define CAP_STYLE  CapButt
#define JOIN_STYLE JoinMiter


#define MODE           1
#define SELECT_MODE    2
#define LINE_WIDTH     3
#define LINE_STYLE     4
#define TEXT_SIZE      5
#define TEXT_THICKNESS 6
#define TEXT_SLANT     7

#define BOUNDING_BOX_MODE   1
#define SPECIAL_POINTS_MODE 2

#define SOLID  1
#define DASHED 2

#define LINE_WIDTH_MIN  0
#define LINE_WIDTH_MAX 20

#define TEXT_SIZE_MIN  5
#define TEXT_SIZE_MAX 40
#define TEXT_SIZE_DEF 24

#define MEDIUM 1
#define BOLD   2

#define ROMAN  1
#define ITALIC 2


/* ========================================================================== */
/*      GLOBAL VARIABLES                                                      */
/* ========================================================================== */

typedef struct
{
  Boolean      exact;
  int          real_size;
  XFontStruct *font;
} FontTableType1;

typedef struct
{
  FontTableType1 roman, italic;
} FontTableType2;

typedef struct
{
  FontTableType2 medium, bold;
} FontTableType;

/* in this table we store all available fonts at initialization time */
FontTableType FontTable[TEXT_SIZE_MAX];

Widget       DrawWidget;            /* the Widget, Display, Window and Screen */
Display     *DrawDisplay;           /* of the Drawing Area                    */
Window       DrawWindow;
Screen      *DrawScreen;
Colormap     DrawCmap;              /* the colormap                           */

GC           DrawGCsolid;           /* for drawing solid lines etc.           */
GC           DrawGCxor;             /* for rubberbanding                      */
GC           DrawGCWhite;           /* for drawing the pointers & bound. box. */
GC           ForeignGC;             /* for drawing because of messages etc.   */
GC           DrawGCtext;            /* for drawing text                       */

XFontStruct *ptr_font = NULL;       /* the font for the pointer-text          */
XFontStruct *text_font = NULL;      /* the font for the text                  */
XFontStruct *new_text_font = NULL;  /* the new font for the text              */

XmFontList   text_font_list;        /* holds the fonts for the text           */
XmFontList   foreign_text_font_list;/* same for the texts from other users    */


int          obj_count = 0;         /* counts the objects a user creates      */
                                    /* is used for giving the objects unique  */
                                    /* numbers                                */


/* ========================================================================== */
/*      LOCAL VARIABLES                                                       */
/* ========================================================================== */

typedef struct
{
  int mode;                /* drawing mode; the values of the Radio Buttons   */
                           /* v_draw_button_pointer etc.                      */
  int select_mode;         /* select mode; indicates wether selecting any     *
                            * object means the whole object or only one point *
                            * of this object.                                 */
  int line_width;          /* width of the lines &                            */
  int line_style;          /* line style of the lines which are drawn with    *
                            * DrawGCsolid                                     */
  int text_size;           /* size of text which is drawn                     */ 
  int text_thickness;      /* medium / bold                                   */
  int text_slant;          /* italic / roman                                  */
} DrawStateType;

static DrawStateType DrawState = {v_draw_button_line,
                                  BOUNDING_BOX_MODE,
                                  LINE_WIDTH_MIN, SOLID,
                                  TEXT_SIZE_DEF, BOLD, ROMAN};


/* ========================================================================== */
/*      FORWARD DECLARATIONS OF FUNCTIONS                                     */
/* ========================================================================== */

int get_draw_state ( int );


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  set_draw_state()                                         */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  Set values of the components of the variable 'DrawState' */
/*                   Returns 'True' if succesfull, 'False' if not.            */
/*                                                                            */
/*      Accesses  :  DrawState                                                */
/*                                                                            */
/*      Called by :  set_draw_mode_proc()                                     */
/*                                                                            */
/*      Calls     :  -                                                        */
/*                                                                            */
/* ========================================================================== */

Boolean set_draw_state ( int component, int value )
{
  char textbuf[80];

  /*  Select the DrawingState component which is to be set */
  switch (component)
  {
    case MODE:
      /* check wether value is out of range */
      if ((value < v_draw_button_min) || (value > v_draw_button_max))
      {
        if (value == v_nyi)
        {
          DrawState.mode = v_nyi;
        } /* if */
        else
        {
          sprintf (textbuf, "draw: set_draw_state: value for "
                            "drawing mode out of range: value=%d.",value);
          sperror (textbuf);
          return False;
        } /* else */
      } /* if */
      else
      {
        /* set the value */
        DrawState.mode = value;
      } /* else */
    break;

    case SELECT_MODE:
      switch (value)
      {
        case BOUNDING_BOX_MODE:
          DrawState.select_mode = BOUNDING_BOX_MODE;
        break;
        case SPECIAL_POINTS_MODE:
          DrawState.select_mode = SPECIAL_POINTS_MODE;
        break;
        default:
          sprintf (textbuf, "draw: set_draw_state: value for "
                            "select mode out of range: value=%d.",value);
          sperror (textbuf);
          return False;
        break;
      } /* switch */
    break;

    case LINE_STYLE:
      switch (value)
      {
        case SOLID:
          DrawState.line_style = SOLID;
          XSetLineAttributes (DrawDisplay, DrawGCsolid,
                              get_draw_state (LINE_WIDTH),
                              LineSolid,
                              CAP_STYLE, JOIN_STYLE);
        break;
        case DASHED:
          DrawState.line_style = DASHED;
          XSetLineAttributes (DrawDisplay, DrawGCsolid,
                              get_draw_state (LINE_WIDTH),
                              LineOnOffDash,
                              CAP_STYLE, JOIN_STYLE);
        break;
        default:
          sprintf (textbuf, "draw: set_draw_state: value for "
                            "line style out of range: value=%d.",value);
          sperror (textbuf);
          return False;
        break;
      } /* switch */
    break;

    case LINE_WIDTH:
      if (value < LINE_WIDTH_MIN)
      {
        sprintf (textbuf, "draw: set_draw_state: value for "
                          "line width too small (MIN=%d): value=%d.",
                           LINE_WIDTH_MIN, value);
        sperror (textbuf);
        return False;
      } /* if */
      else if (value > LINE_WIDTH_MAX)
      {
        sprintf (textbuf, "draw: set_draw_state: value for "
                          "line width too big (MAX=%d): value=%d.",
                           LINE_WIDTH_MAX, value);
        sperror (textbuf);
        return False;
      } /* else if */
      else /* value in correct range */
      {
        DrawState.line_width = value;
        switch (get_draw_state (LINE_STYLE))
        {
          case SOLID:
            XSetLineAttributes (DrawDisplay, DrawGCsolid,
                                value, LineSolid,
                                CAP_STYLE, JOIN_STYLE);
            break;
          case DASHED:
            XSetLineAttributes (DrawDisplay, DrawGCsolid,
                                value, LineOnOffDash,
                                CAP_STYLE, JOIN_STYLE);
            break;
          default:
            sprintf (textbuf, "draw: set_draw_state: value for "
                              "line style out of range: value=%d.",value);
            sperror (textbuf);
            sperror ("setting line style to SOLID.");

            XSetLineAttributes (DrawDisplay, DrawGCsolid,
                                value, LineSolid,
                                CAP_STYLE, JOIN_STYLE);
            return False;
            break;
        } /* switch */
      } /* else */
    break;

    case TEXT_SIZE:
      if (value < TEXT_SIZE_MIN)
      {
        sprintf (textbuf, "draw: set_draw_state: value for "
                          "text size too small (MIN=%d): value=%d.",
                           TEXT_SIZE_MIN, value);
        sperror (textbuf);
        return False;
      } /* if */
      else if (value >= TEXT_SIZE_MAX)
      {
        sprintf (textbuf, "draw: set_draw_state: value for "
                          "text size too big (MAX=%d): value=%d.",
                           TEXT_SIZE_MIN, value);
        sperror (textbuf);
        return False;
      } /* else if */
      else /* value in correct range: search a fitting font */
      {
        Boolean new_text_font_exact     = False;
        int     new_text_font_real_size = 0;

        new_text_font = NULL;

        switch (get_draw_state (TEXT_THICKNESS))
        {
          case BOLD:
            switch (get_draw_state (TEXT_SLANT))
            {
              case ROMAN:
                new_text_font           = FontTable[value].bold.roman.font;
                new_text_font_exact     = FontTable[value].bold.roman.exact;
                new_text_font_real_size = FontTable[value].bold.roman.real_size;
                break;
              case ITALIC:
                new_text_font           = FontTable[value].bold.italic.font;
                new_text_font_exact     = FontTable[value].bold.italic.exact;  
                new_text_font_real_size =
                                         FontTable[value].bold.italic.real_size;
                break;
              default:
                sprintf (textbuf, "draw: set_draw_state: value for "
                                  "text slant out of range: value=%d.",
                                  get_draw_state (TEXT_SLANT));
                sperror (textbuf);
                sperror ("setting text slant to ROMAN.");

                new_text_font           = FontTable[value].bold.roman.font;
                new_text_font_exact     = FontTable[value].bold.roman.exact;  
                new_text_font_real_size = FontTable[value].bold.roman.real_size;
                return False;
                break;
            } /* switch (TEXT_SLANT) */
            break;
          case MEDIUM:
            switch (get_draw_state (TEXT_SLANT))
            {
              case ROMAN:
                new_text_font           = FontTable[value].medium.roman.font;
                new_text_font_exact     = FontTable[value].medium.roman.exact;  
                new_text_font_real_size =
                                        FontTable[value].medium.roman.real_size;
                break;
              case ITALIC:
                new_text_font           = FontTable[value].medium.italic.font;
                new_text_font_exact     = FontTable[value].medium.italic.exact;
                new_text_font_real_size =
                                       FontTable[value].medium.italic.real_size;
                break;
              default:
                sprintf (textbuf, "draw: set_draw_state: value for "
                                  "text slant out of range: value=%d.",
                                  get_draw_state (TEXT_SLANT));
                sperror (textbuf);
                sperror ("setting text slant to ROMAN.");

                new_text_font           = FontTable[value].medium.roman.font;
                new_text_font_exact     = FontTable[value].medium.roman.exact;  
                new_text_font_real_size =
                                        FontTable[value].medium.roman.real_size;

                return False;
                break;
            } /* switch (TEXT_SLANT) */
            break;
          default:
            sprintf (textbuf, "draw: set_draw_state: value for "
                              "text thickness out of range: value=%d.",
                              get_draw_state (TEXT_THICKNESS));
            sperror (textbuf);
            sperror ("setting text thickness to BOLD.");

            switch (get_draw_state (TEXT_SLANT))
            {
              case ROMAN:
                new_text_font           = FontTable[value].bold.roman.font;
                new_text_font_exact     = FontTable[value].bold.roman.exact;  
                new_text_font_real_size = FontTable[value].bold.roman.real_size;
                break;
              case ITALIC:
                new_text_font           = FontTable[value].bold.italic.font;
                new_text_font_exact     = FontTable[value].bold.italic.exact;  
                new_text_font_real_size =
                                         FontTable[value].bold.italic.real_size;
                break;
              default:
                sprintf (textbuf, "draw: set_draw_state: value for "
                                  "text slant out of range: value=%d.",
                                  get_draw_state (TEXT_SLANT));
                sperror (textbuf);
                sperror ("setting text slant to ROMAN.");

                new_text_font           = FontTable[value].bold.roman.font;
                new_text_font_exact     = FontTable[value].bold.roman.exact;  
                new_text_font_real_size = FontTable[value].bold.roman.real_size;

                return False;
                break;
            } /* switch (TEXT_SLANT) */

            return False;
            break;
        } /* switch (TEXT_THICKNESS) */

        if (new_text_font == NULL)
        {
          fprintf (stderr,
                   "set_draw_state: Error: no font with size %d available!\n",
                   value);
          sperror ("old font not changed!");
          return False;
        } /* if */
        else
        {
          XGCValues DrawGCval;

          text_font_list = XmFontListCreate (new_text_font,
                                             XmSTRING_DEFAULT_CHARSET);
          DrawGCval.font = new_text_font->fid;
          XChangeGC (DrawDisplay, DrawGCtext, GCFont, &DrawGCval);

          DrawState.text_size = value;

          if (new_text_font_exact == False)
          {
            sprintf (textbuf, "Warning: font size %d is not available;",
                               value);
            sperror (textbuf);
            sprintf (textbuf, "         taking font size %d instead.",
                               new_text_font_real_size);
            sperror (textbuf);
          } /* if */
        } /* else */
      } /* else */
    break;

    case TEXT_THICKNESS:
    {
      Boolean new_text_font_exact     = False;
      int     new_text_font_real_size = 0;

      new_text_font = NULL;

      switch (value)
      {
        case MEDIUM:
          /* search a fitting font */
          switch (get_draw_state (TEXT_SLANT))
          {
            case ROMAN:
              new_text_font           =
                FontTable [get_draw_state (TEXT_SIZE)].medium.roman.font;
              new_text_font_exact     =
                FontTable [get_draw_state (TEXT_SIZE)].medium.roman.exact;
              new_text_font_real_size =
                FontTable [get_draw_state (TEXT_SIZE)].medium.roman.real_size;
              break;
            case ITALIC:
              new_text_font           =
                FontTable [get_draw_state (TEXT_SIZE)].medium.italic.font;
              new_text_font_exact     =
                FontTable [get_draw_state (TEXT_SIZE)].medium.italic.exact;
              new_text_font_real_size =
                FontTable [get_draw_state (TEXT_SIZE)].medium.italic.real_size;
              break;
            default:
              sprintf (textbuf, "draw: set_draw_state: value for "
                                "text slant out of range: value=%d.",
                                get_draw_state (TEXT_SLANT));
              sperror (textbuf);
              sperror ("setting text slant to ROMAN.");

              new_text_font           =
                FontTable [get_draw_state (TEXT_SIZE)].medium.roman.font;
              new_text_font_exact     =
                FontTable [get_draw_state (TEXT_SIZE)].medium.roman.exact;
              new_text_font_real_size =
                FontTable [get_draw_state (TEXT_SIZE)].medium.roman.real_size;
              return False;
              break;
          } /* switch (TEXT_SLANT) */
        break;
        case BOLD:
          /* search a fitting font */
          switch (get_draw_state (TEXT_SLANT))
          {
            case ROMAN:
              new_text_font           =
                FontTable [get_draw_state (TEXT_SIZE)].bold.roman.font;
              new_text_font_exact     =
                FontTable [get_draw_state (TEXT_SIZE)].bold.roman.exact;
              new_text_font_real_size =
                FontTable [get_draw_state (TEXT_SIZE)].bold.roman.real_size;
              break;
            case ITALIC:
              new_text_font           =
                FontTable [get_draw_state (TEXT_SIZE)].bold.italic.font;
              new_text_font_exact     =
                FontTable [get_draw_state (TEXT_SIZE)].bold.italic.exact;
              new_text_font_real_size =
                FontTable [get_draw_state (TEXT_SIZE)].bold.italic.real_size;
              break;
            default:
              sprintf (textbuf, "draw: set_draw_state: value for "
                                "text slant out of range: value=%d.",
                                get_draw_state (TEXT_SLANT));
              sperror (textbuf);
              sperror ("setting text slant to ROMAN.");

              new_text_font           =
                FontTable [get_draw_state (TEXT_SIZE)].bold.roman.font;
              new_text_font_exact     =
                FontTable [get_draw_state (TEXT_SIZE)].bold.roman.exact;
              new_text_font_real_size =
                FontTable [get_draw_state (TEXT_SIZE)].bold.roman.real_size;
              return False;
              break;
          } /* switch (TEXT_SLANT) */
        break;
        default:
          sprintf (textbuf, "draw: set_draw_state: value for "
                            "text thickness out of range: value=%d.",value);
          sperror (textbuf);
          return False;
        break;
      } /* switch (value) */

      if (new_text_font == NULL)
      {
        fprintf (stderr,
                "set_draw_state: Error: no font with thickness %d available!\n",
                 value);
        sperror ("old font not changed!");
        return False;
      } /* if */
      else
      {
        XGCValues DrawGCval;

        text_font_list = XmFontListCreate (new_text_font,
                                           XmSTRING_DEFAULT_CHARSET);
        DrawGCval.font = new_text_font->fid;
        XChangeGC (DrawDisplay, DrawGCtext, GCFont, &DrawGCval);

        DrawState.text_thickness = value;

        if (new_text_font_exact == False)
        {
/*
          sprintf (textbuf, "Warning: font size %d is not available;",
                             get_draw_state (TEXT_SIZE));
          sperror (textbuf);
          sprintf (textbuf, "         taking font size %d instead.",
                             new_text_font_real_size);
          sperror (textbuf);
*/
        } /* if */
      } /* else */
    } /* case */
    break;

    case TEXT_SLANT:
    {
      Boolean new_text_font_exact     = False;
      int     new_text_font_real_size = 0;

      new_text_font = NULL;

      switch (value)
      {
        case ROMAN:
          /* search a fitting font */
          switch (get_draw_state (TEXT_THICKNESS))
          {
            case BOLD:
              new_text_font           =
                FontTable [get_draw_state (TEXT_SIZE)].bold.roman.font;
              new_text_font_exact     =
                FontTable [get_draw_state (TEXT_SIZE)].bold.roman.exact;
              new_text_font_real_size =
                FontTable [get_draw_state (TEXT_SIZE)].bold.roman.real_size;
              break;
            case MEDIUM:
              new_text_font           =
                FontTable [get_draw_state (TEXT_SIZE)].medium.roman.font;
              new_text_font_exact     =
                FontTable [get_draw_state (TEXT_SIZE)].medium.roman.exact;
              new_text_font_real_size =
                FontTable [get_draw_state (TEXT_SIZE)].medium.roman.real_size;
              break;
            default:
              sprintf (textbuf, "draw: set_draw_state: value for "
                                "text thickness out of range: value=%d.",
                                get_draw_state (TEXT_THICKNESS));
              sperror (textbuf);
              sperror ("setting text thickness to BOLD.");

              new_text_font           =
                FontTable [get_draw_state (TEXT_SIZE)].bold.roman.font;
              new_text_font_exact     =
                FontTable [get_draw_state (TEXT_SIZE)].bold.roman.exact;
              new_text_font_real_size =
                FontTable [get_draw_state (TEXT_SIZE)].bold.roman.real_size;
              return False;
              break;
          } /* switch (TEXT_THICKNESS) */
        break;
        case ITALIC:
          /* search a fitting font */
          switch (get_draw_state (TEXT_THICKNESS))
          {
            case BOLD:
              new_text_font           =
                FontTable [get_draw_state (TEXT_SIZE)].bold.italic.font;
              new_text_font_exact     =
                FontTable [get_draw_state (TEXT_SIZE)].bold.italic.exact;
              new_text_font_real_size =
                FontTable [get_draw_state (TEXT_SIZE)].bold.italic.real_size;
              break;
            case MEDIUM:
              new_text_font           =
                FontTable [get_draw_state (TEXT_SIZE)].medium.italic.font;
              new_text_font_exact     =
                FontTable [get_draw_state (TEXT_SIZE)].medium.italic.exact;
              new_text_font_real_size =
                FontTable [get_draw_state (TEXT_SIZE)].medium.italic.real_size;
              break;
            default:
              sprintf (textbuf, "draw: set_draw_state: value for "
                                "text thickness out of range: value=%d.",
                                get_draw_state (TEXT_THICKNESS));
              sperror (textbuf);
              sperror ("setting text thickness to BOLD.");

              new_text_font           =
                FontTable [get_draw_state (TEXT_SIZE)].bold.italic.font;
              new_text_font_exact     =
                FontTable [get_draw_state (TEXT_SIZE)].bold.italic.exact;
              new_text_font_real_size =
                FontTable [get_draw_state (TEXT_SIZE)].bold.italic.real_size;
              return False;
              break;
          } /* switch (TEXT_THICKNESS) */
        break;

        default:
          sprintf (textbuf, "draw: set_draw_state: value for "
                            "text slant out of range: value=%d.",value);
          sperror (textbuf);
          return False;
        break;
      } /* switch (value) */

      if (new_text_font == NULL)
      {
        fprintf (stderr,
                "set_draw_state: Error: no font with slant %d available!\n",
                 value);
        sperror ("old font not changed!");
        return False;
      } /* if */
      else
      {
        XGCValues DrawGCval;

        text_font_list = XmFontListCreate (new_text_font,
                                           XmSTRING_DEFAULT_CHARSET);
        DrawGCval.font = new_text_font->fid;
        XChangeGC (DrawDisplay, DrawGCtext, GCFont, &DrawGCval);

        DrawState.text_slant = value;

        if (new_text_font_exact == False)
        {
/*
          sprintf (textbuf, "Warning: font size %d is not available;",
                             get_draw_state (TEXT_SIZE));
          sperror (textbuf);
          sprintf (textbuf, "         taking font size %d instead.",
                             new_text_font_real_size);
          sperror (textbuf);
*/
        } /* if */
      } /* else */
    } /* case */
    break;

    default :
      sperror ("draw: set_draw_state: DrawState component unknown.");
      return False;
    break;

  } /* switch (component) */

  /* if we reach this point, everything seems to be ok */
  return True;

} /* set_draw_state */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  get_draw_state()                                         */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  Get values of the components of the variable 'DrawState' */
/*                                                                            */
/*      Accesses  :  DrawState                                                */
/*                                                                            */
/*      Called by :  draw() in draw.c                                         */
/*                                                                            */
/*      Calls     :  -                                                        */
/*                                                                            */
/* ========================================================================== */

int get_draw_state ( int component )
{

  /* Select the DrawingState component which is to be read & return its value */
  switch (component)
  {
    case MODE:
      return(DrawState.mode);
    break;

    case SELECT_MODE:
      return(DrawState.select_mode);
    break;

    case LINE_WIDTH:
      return(DrawState.line_width);
    break;

    case LINE_STYLE:
      return(DrawState.line_style);
    break;

    case TEXT_SIZE:
      return(DrawState.text_size);
    break;

    case TEXT_THICKNESS:
      return(DrawState.text_thickness);
    break;

    case TEXT_SLANT:
      return(DrawState.text_slant);
    break;

    default :
      sperror ("draw: get_draw_state: DrawState component unknown.");
      return(0);
    break;

  } /* switch */
return(0);
} /* get_draw_state */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  toggle_select_mode()                                     */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  toggles the value of the drawstate component'select_mode'*/
/*                                                                            */
/*      Accesses  :  DrawState                                                */
/*                                                                            */
/*      Called by :  edit_pull_proc() in sketchpad.c                          */
/*                                                                            */
/*      Calls     :  -                                                        */
/*                                                                            */
/* ========================================================================== */

void toggle_select_mode ()
{
  if (get_draw_state (SELECT_MODE) == BOUNDING_BOX_MODE)
  {
    set_draw_state (SELECT_MODE, SPECIAL_POINTS_MODE);
  } /* if */
  else
  {
    set_draw_state (SELECT_MODE, BOUNDING_BOX_MODE);
  } /* else */
} /* toggle_select_mode */
