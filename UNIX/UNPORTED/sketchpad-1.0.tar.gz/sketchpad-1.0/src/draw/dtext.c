/* ========================================================================== */
/*                                                                            */
/* Filename:     dtext.c                          +-----+-----+--+--+--+--+   */
/* Version :     1.2	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/9/92	10:08:08	                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Module    :  drawing module                                           */
/*                                                                            */
/*      Functions :  compute_text_box (), draw_text_box (), move_text_box (), */
/*                   draw_text (), handle_text ()                             */
/*                                                                            */
/* ========================================================================== */


/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <stdio.h>
#include <string.h>
#include <Mrm/MrmAppl.h>
#include <Xm/Text.h>

#include "../misc/sperror.h"
#include "drawstate.h"

#include "../misc/ographic.h"
#include "../ui/layer.h"
#include "../kernel/user.h"
#include "../ui/sketchpad.h"
#include "../ui/defs.h"


/* ========================================================================== */
/*      DEFINE STATEMENTS                                                     */
/* ========================================================================== */

#define TEXTLEN 80


/* ========================================================================== */
/*      GLOBAL VARIABLES                                                      */
/* ========================================================================== */

XRectangle act_text_box;         /* the bounding box of the text */
XPoint     last_text_box_pos;    /* the last position of the */
                                 /* bounding box of the text */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  draw_text ()                                             */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  routine for drawing the texts from other users           */
/*                   in the drawing area                                      */
/*                                                                            */
/*      Accesses  :  foreign_text_font_list                                   */
/*                                                                            */
/*      Called by :  handle_text () and others                                */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

void draw_text ( int text_pos_x, int text_pos_y, char* text, GC curr_GC )
{
  Dimension    w, h;
  XmString     text_xmstring;                  /* the text as compound string */

  /* create compound string from char* */
  text_xmstring = XmStringCreateLtoR (text, XmSTRING_DEFAULT_CHARSET);

  /* compute size of bounding rectangle */
  XmStringExtent (foreign_text_font_list, text_xmstring, &w, &h);

  /* draw the text string without changing the background around the text */
  XmStringDraw (DrawDisplay, DrawWindow,
                foreign_text_font_list, text_xmstring,
                curr_GC,
                (Position)text_pos_x, (Position)text_pos_y,
                w,
                XmALIGNMENT_BEGINNING, XmSTRING_DIRECTION_L_TO_R,
                None);
} /* draw_text */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  compute_text_box ()                                      */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  routine for computing the size of the box, in which the  */
/*                   text is to be placed finally.                            */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  InsertText () in misc/ographic.c,                        */
/*                   handle_text ()                                           */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

XRectangle compute_text_box ( char *text )
{
  XRectangle   text_box;
  Dimension    w, h;
  XmString     text_xmstring;                  /* the text as compound string */

  /* create compound string from char* */
  text_xmstring = XmStringCreateLtoR (text, XmSTRING_DEFAULT_CHARSET);

  /* compute size of bounding rectangle */
  XmStringExtent (text_font_list, text_xmstring, &w, &h);

  text_box.x = 0;
  text_box.y = 0;
  text_box.width  = w;
  text_box.height = h;

  return text_box;
} /* compute_text_box */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  draw_text_box ()                                         */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  routine for drawing the box, in which the text is to be  */
/*                   placed finally. The box has the exact size the whole     */
/*                   time it is used and is drawn in XOR mode, so it is       */
/*                   undrawn simply by drawing it again.                      */
/*                                                                            */
/*      Accesses  :  act_text_box, last_text_box_pos                          */
/*                                                                            */
/*      Called by :  handle_text (), move_text_box ()                         */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

static void draw_text_box ( int x_pos, int y_pos )
{
  XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                  x_pos, y_pos, act_text_box.width, act_text_box.height);

  last_text_box_pos.x = x_pos;
  last_text_box_pos.y = y_pos;
} /* draw_text_box */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  move_text_box ()                                         */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  routine for moving the box, in which the text is to be   */
/*                   placed finally. The box has the exact size the whole     */
/*                   time it is used.                                         */
/*                                                                            */
/*      Accesses  :  last_text_box_pos                                        */
/*                                                                            */
/*      Called by :  handle_text ()                                           */
/*                                                                            */
/*      Calls     :  draw_text_box ()                                         */
/*                                                                            */
/* ========================================================================== */

static void move_text_box ( int x_new, int y_new )
{
  draw_text_box (last_text_box_pos.x, last_text_box_pos.y);
  draw_text_box (x_new, y_new);
} /* move_text_box */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  handle_text ()                                           */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  gets the text string from the motif text widget and      */
/*                   handles the text input in the drawing area               */
/*                                                                            */
/*      Accesses  :  ownUserNumber, obj_count                                 */
/*                                                                            */
/*      Called by :  draw () in draw.c                                        */
/*                                                                            */
/*      Calls     :  GetActiveLayer(), GetStructStorage()                     */
/*                   in ui/layer.c,                                           */
/*                                                                            */
/*                   InsertText () in misc/ographic.c,                        */
/*                                                                            */
/*                   msg_draw_text () in kernel/user.c,                       */
/*                                                                            */
/*                   compute_text_box (), draw_text_box (), move_text_box (), */
/*                   draw_text ()                                             */
/*                                                                            */
/* ========================================================================== */

void handle_text ( XEvent* startevent )
{
  XEvent   event;                       /* current event in the queue         */
  XPoint   pos;                         /* the actual position of the cursor  */
  char     text[TEXTLEN];               /* the text itself                    */
  char    *text1;                       /* the text before beeing checked     */

  struct_storage ss;                    /* the structure storage in which the */
                                        /* objects are to be written          */

  ss = GetStructStorage (GetActiveLayer ());

  /* get the text which is to be drawn */
  text1 = XmTextGetString(widget_array[v_text_box_edit_box]);

  if (strlen(text1)<1) /* text is too short */
  {
    sperror ("text too short (min. one character).");
  }
  else
  {
    if ((strlen(text1)+1)>TEXTLEN) /* text is too long */
    {
      char help[TEXTLEN];
      char textbuf[80];

      sprintf (textbuf, "text too long (max. %d characters incl. '\\0').",
               TEXTLEN);
      sperror (textbuf);

      strncpy (help, text1, TEXTLEN);
      help[TEXTLEN-1] = '\0';
      strcpy (text, help);
    }
    else /* text is correct sized */
    {
      strcpy (text, text1);
    }

    /* compute dimension of box around the text */
    act_text_box = compute_text_box (text);

    /* get the start position */
    pos.x = startevent->xbutton.x;
    pos.y = startevent->xbutton.y;

    /* draw the text box at this point */
    draw_text_box (pos.x, pos.y);

    /* get the next event */
    XNextEvent (DrawDisplay,&event);

    /* loop until the button is released */
    while (!((event.type == ButtonRelease) && (event.xbutton.button == Button1)))
    {
      if (event.type == MotionNotify)
      {
        /* get the actual position */
        pos.x = event.xmotion.x;
        pos.y = event.xmotion.y;

        /* move text_box to this new position */
        move_text_box (pos.x, pos.y);
      } /* if */
      XNextEvent (DrawDisplay,&event);
    } /* while */

    /* undraw the text_box */
    draw_text_box (pos.x, pos.y);

    /* draw text string on window */
    {
      Dimension    w, h;
      XmString     text_xmstring;              /* the text as compound string */

      /* create compound string from char* */
      text_xmstring = XmStringCreateLtoR (text, XmSTRING_DEFAULT_CHARSET);

      /* compute size of bounding rectangle */
      XmStringExtent (text_font_list, text_xmstring, &w, &h);

      /* draw the text string without changing the background around the text */
      XmStringDraw (DrawDisplay, DrawWindow,
                    text_font_list, text_xmstring,
                    DrawGCtext,
                    (Position)pos.x, (Position)pos.y,
                    w,
                    XmALIGNMENT_BEGINNING, XmSTRING_DIRECTION_L_TO_R,
                    None);
    }
/*  draw_text (pos.x, pos.y, text, DrawGCtext); */

    /* send message */
    msg_draw_text (text, get_draw_state (TEXT_SIZE),
                   get_draw_state (TEXT_THICKNESS),
                   get_draw_state (TEXT_SLANT),
                   pos.x, pos.y, act_text_box.width, act_text_box.height,
                   ownUserNumber, obj_count);

    /* insert text-object in structure-storage */
    InsertText (ss, pos.x, pos.y, act_text_box.width, act_text_box.height,
                text,
                get_draw_state (TEXT_SIZE),
                get_draw_state (TEXT_THICKNESS),
                get_draw_state (TEXT_SLANT),
                ownUserNumber, obj_count);

    obj_count++;
  } /* else */
} /* handle_text */
