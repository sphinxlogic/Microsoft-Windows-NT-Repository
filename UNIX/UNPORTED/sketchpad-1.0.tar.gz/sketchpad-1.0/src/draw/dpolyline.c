/* ========================================================================== */
/*                                                                            */
/* Filename:     dpolyline.c                      +-----+-----+--+--+--+--+   */
/* Version :     1.2	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/9/92	10:07:43	                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Part      :  drawing module                                           */
/*                                                                            */
/*      Functions :  draw_solid_line(), handle_polyline ()                    */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <Mrm/MrmAppl.h>

#include "drawstate.h"

#include "../ui/defs.h"
#include "../misc/ographic.h"
#include "../ui/layer.h"
#include "../kernel/user.h"


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  draw_solid_line()                                        */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  draws a solid line on window and in structure storage    */
/*                   and sends a message to the others                        */
/*                                                                            */
/*      Accesses  :  ownUserNumber, obj_count                                 */
/*                                                                            */
/*      Called by :  handle_polyline()                                        */
/*                                                                            */
/*      Calls     :  InsertLine () in misc/ographic.c,                        */
/*                                                                            */
/*                   msg_draw_line () in kernel/user.c                        */
/*                                                                            */
/* ========================================================================== */

void draw_solid_line ( struct_storage ss, XPoint start, XPoint act)
{
  /* draw line solid on window */
  XDrawLine (DrawDisplay, DrawWindow, DrawGCsolid,
             start.x, start.y, act.x, act.y);

  /* send message */
  msg_draw_line (start.x, start.y, act.x, act.y,
                 get_draw_state (LINE_WIDTH),
                 get_draw_state (LINE_STYLE),
                 ownUserNumber, obj_count);

  /* insert line-object in structure-storage */
  InsertLine (ss, start.x, start.y, act.x, act.y,
              get_draw_state (LINE_WIDTH), get_draw_state (LINE_STYLE),
              ownUserNumber, obj_count);

  obj_count++;
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  handle_polyline()                                        */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  handles polyline drawing with rubberbanding              */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  draw () in draw.c                                        */
/*                                                                            */
/*      Calls     :  GetActiveLayer(), GetStructStorage()                     */
/*                   in ui/layer.c,                                           */
/*                                                                            */
/*                   draw_solid_line()                                        */
/*                                                                            */
/* ========================================================================== */

void handle_polyline ( XEvent* startevent )
{
  XEvent event = *startevent;         /* current event in the queue           */

  XPoint start, act;                  /* the starting point and the actual    */
                                      /* position of the mouse                */

  struct_storage ss;                  /* the structure storage in which the   */
                                      /* objects are to be written            */

  ss = GetStructStorage (GetActiveLayer ());

  start.x = event.xbutton.x;
  start.y = event.xbutton.y;
  act.x   = event.xbutton.x;
  act.y   = event.xbutton.y;

  /* draw starting point on window */
  XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
             start.x, start.y, act.x, act.y);

  /* loop until the middle or right Button is released */
  while (!((event.type == ButtonRelease)     &&
          ((event.xbutton.button == Button2) ||
           (event.xbutton.button == Button3))))
  {
    /* get the next event */
    XWindowEvent (DrawDisplay,DrawWindow,
                  (ButtonPressMask | ButtonReleaseMask | PointerMotionMask),
                  &event);

    if (event.type == MotionNotify)
    {
      /* undraw old line */
      XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
                 start.x, start.y, act.x, act.y);

      act.x = event.xmotion.x;
      act.y = event.xmotion.y;

      /* draw new line */
      XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
                 start.x, start.y, act.x, act.y);

    } /* if */
    else if (event.type == ButtonPress)
    {
      if (event.xbutton.button == Button1)
      {
        /* undraw old line */
        XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
                   start.x, start.y, act.x, act.y);

        act.x = event.xbutton.x;
        act.y = event.xbutton.y;

        draw_solid_line (ss, start, act);

        start.x = event.xbutton.x;
        start.y = event.xbutton.y;

        /* loop until the Button is released */
        while (!((event.type == ButtonRelease)     &&
                 (event.xbutton.button == Button1)))
        {
          XNextEvent (DrawDisplay,&event);
        } /* while */
      } /* if */
      if (event.xbutton.button == Button2)
      {
        /* undraw old line */
        XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
                   start.x, start.y, act.x, act.y);

        act.x = event.xbutton.x;
        act.y = event.xbutton.y;

        draw_solid_line (ss, start, act);

        /* loop until the Button is released */
        while (!((event.type == ButtonRelease)     &&
                 (event.xbutton.button == Button2)))
        {
          XNextEvent (DrawDisplay,&event);
        } /* while */
      } /* if */
      else if (event.xbutton.button == Button3)
      {
        /* undraw old line */
        XDrawLine (DrawDisplay, DrawWindow, DrawGCxor,
                   start.x, start.y, act.x, act.y);

        /* draw last point again because it has been drawn twice now */
        /* draw it again to give it the right color                  */
        XDrawPoint (DrawDisplay, DrawWindow, DrawGCxor,
                    start.x, start.y);

        /* loop until the Button is released */
        while (!((event.type == ButtonRelease)     &&
                 (event.xbutton.button == Button3)))
        {
          XNextEvent (DrawDisplay,&event);
        } /* while */
      } /* if */
    } /* if */
  } /* while */
} /* handle_polyline */
