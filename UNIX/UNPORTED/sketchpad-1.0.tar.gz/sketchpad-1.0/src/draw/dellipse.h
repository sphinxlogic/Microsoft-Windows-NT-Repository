/* ========================================================================== */
/*           Forward-Declarations of Functions defined in 'dellipse.c'        */
/* ========================================================================== */

extern void handle_ellipse ( XEvent*, Boolean, Boolean );
