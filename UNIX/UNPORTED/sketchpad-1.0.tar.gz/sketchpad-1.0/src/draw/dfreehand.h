/* ========================================================================== */
/*           Forward-Declarations of Functions defined in 'dfreehand.c'       */
/* ========================================================================== */

extern void handle_freehand ( XEvent* );
