/* ========================================================================== */
/*                                                                            */
/* Filename:     drectangle.c                     +-----+-----+--+--+--+--+   */
/* Version :     1.3	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/15/92	10:45:39	                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Part      :  drawing module                                           */
/*                                                                            */
/*      Functions :  handle_rectangle ()                                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <Mrm/MrmAppl.h>

#include "drawstate.h"

#include "../ui/defs.h"
#include "../misc/ographic.h"
#include "../ui/layer.h"
#include "../kernel/user.h"


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  handle_rectangle()                                       */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  handles rectangle drawing with rubberbanding             */
/*                                                                            */
/*      Accesses  :  ownUserNumber, obj_count                                 */
/*                                                                            */
/*      Called by :  draw () in draw.c                                        */
/*                                                                            */
/*      Calls     :  InsertRectangle () in misc/ographic.c,                   */
/*                                                                            */
/*                   msg_draw_rectangle () in kernel/user.c,                  */
/*                                                                            */
/*                   GetActiveLayer(), GetStructStorage()                     */
/*                   in ui/layer.c                                            */
/*                                                                            */
/* ========================================================================== */

void handle_rectangle ( XEvent* startevent )
{
  XEvent event;                       /* current event in the queue           */

  XPoint start, act, old;             /* the starting point and the actual    */
                                      /* and last position of the mouse       */
  XPoint lu;                          /* the upper left corner of the rect.   */
  unsigned int width, height;         /* its width and height                 */

  struct_storage ss;                  /* the structure storage in which the   */
                                      /* objects are to be written            */

  ss = GetStructStorage (GetActiveLayer ());

  start.x = startevent->xbutton.x;
  start.y = startevent->xbutton.y;

  act.x   = start.x;
  act.y   = start.y;
  old.x   = start.x;
  old.y   = start.y;

  lu.x    = start.x;
  lu.y    = start.y;
  width   = 0;
  height  = 0;

  /* draw starting point on window */
  XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                  lu.x, lu.y, width, height);

  /* get the next event */
  XNextEvent (DrawDisplay,&event);

  /* loop until the button is released */
  while (!((event.type == ButtonRelease) && (event.xbutton.button == Button1)))
  {
    if (event.type == MotionNotify)
    {
      act.x = event.xmotion.x;
      act.y = event.xmotion.y;

      /* undraw old rectangle */
      XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                      lu.x, lu.y, width, height);

      if (act.x < start.x)
      {
        lu.x  = act.x;
        width = start.x - act.x;
      }
      else
      {
        lu.x  = start.x;
        width = act.x - start.x;
      }

      if (act.y < start.y)
      {
        lu.y   = act.y;
        height = start.y - act.y;
      }
      else
      {
        lu.y   = start.y;
        height = act.y - start.y;
      }

      /* draw new rectangle */
      XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                      lu.x, lu.y, width, height);

      /* actual point is now old point */
      old.x = act.x;
      old.y = act.y;
    } /* if */
    XNextEvent (DrawDisplay,&event);
  } /* while */

  act.x = event.xbutton.x;
  act.y = event.xbutton.y;

  /* undraw old rectangle */
  XDrawRectangle (DrawDisplay, DrawWindow, DrawGCxor,
                  lu.x, lu.y, width, height);

  if (act.x < start.x)
  {
    lu.x  = act.x;
    width = start.x - act.x;
  }
  else
  {
    lu.x  = start.x;
    width = act.x - start.x;
  }

  if (act.y < start.y)
  {
    lu.y   = act.y;
    height = start.y - act.y;
  }
  else
  {
    lu.y   = start.y;
    height = act.y - start.y;
  }

  /* draw rectangle solid on window */
  XDrawRectangle (DrawDisplay, DrawWindow, DrawGCsolid,
                  lu.x, lu.y, width, height);

  /* send message */
  msg_draw_rectangle (lu.x, lu.y, width, height,
                      get_draw_state (LINE_WIDTH),
                      get_draw_state (LINE_STYLE),
                      ownUserNumber, obj_count);

  /* insert rectangle-object in structure-storage */
  InsertRectangle (ss, lu.x, lu.y, width, height,
                   get_draw_state (LINE_WIDTH), get_draw_state (LINE_STYLE),
                   ownUserNumber, obj_count);

  obj_count++;
} /* handle_rectangle */
