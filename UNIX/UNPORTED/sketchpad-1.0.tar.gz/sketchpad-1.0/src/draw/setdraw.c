/* ========================================================================== */
/*                                                                            */
/* Filename:     setdraw.c                        +-----+-----+--+--+--+--+   */
/* Version :     1.4	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/18/92	12:28:01	                      */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*      Part      :  drawing module                                           */
/*                                                                            */
/*      Functions :  init_draw_proc(), free_draw_proc(), set_draw_mode(),     */
/*                   set_clip (), set_foreign_font_attributes()               */
/*                                                                            */
/* ========================================================================== */


/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <Mrm/MrmAppl.h>
#include <X11/cursorfont.h>
#include <stdio.h>
/* HC
#include <stdlib.h>
*/

#include "../misc/sperror.h"
#include "../misc/cursor.h"
#include "../kernel/user.h"
#include "drawmisc.h"
#include "drawstate.h"
#include "draw.h"
#include "../ui/defs.h"


/* ========================================================================== */
/*      DEFINE STATEMENTS                                                     */
/* ========================================================================== */

#define PTRFONTNAME  "8x13"


/* ========================================================================== */
/*      GLOBAL VARIABLES                                                      */
/* ========================================================================== */

#include "../misc/ographic.h"
#include "../ui/sketchpad.h"
#include "../ui/layer.h"


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  set_draw_mode()                                          */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  set cursor shape etc. according to the actual drawing    */
/*                   mode.                                                    */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  the Callback rout. set_draw_mode_proc(), init_draw_proc()*/
/*                                                                            */
/*      Calls     :  set_draw_state() in drawstate.c,                         */
/*                                                                            */
/*                   DeselectAll () in misc/ographic.c,                       */
/*                                                                            */
/*                   GetStructStorage (), GetActiveLayer () in ui/layer.c     */
/*                                                                            */
/* ========================================================================== */

void set_draw_mode ( int actual_mode )
{
  XColor cursor_fg, cursor_bg;
  char   textbuf[80];

  /* check wether mode is out of range */
  if ((actual_mode < v_draw_button_min) || (actual_mode > v_draw_button_max)
      && (actual_mode != v_nyi))
  {
    sprintf (textbuf, "draw: set_draw_mode: actual_mode out of range: "
                      "actual_mode=%d.", actual_mode);
    sperror (textbuf);
  }
  else
  {
    /* Simply call the function set_draw_state with the actual_mode */
    /* as parameter for setting the drawing mode                    */
    set_draw_state (MODE, actual_mode);

    /* if there exists an active layer: deselect all objects! */
    if (GetActiveLayer () != NULL)
    {
      DeselectAll (GetStructStorage (GetActiveLayer ()));
    }

    /* if there is an old pointer visible: remove it! */
    if (my_pointer_visible)
    {
      /* send message for removing old pointer */
      msg_end_pointer ();
 
      /* remove pointer on own window */
      end_pointer (ownUserNumber);

      /* mark pointer as 'not visible' */
      my_pointer_visible = FALSE;
    }

    /* set cursor shape according to the mode */
    switch (actual_mode)
    {
      case v_draw_button_selector:
        draw_mode_cursor = XCreateFontCursor(DrawDisplay,XC_arrow);
      break;

      case v_draw_button_pointer:
        draw_mode_cursor = XCreateFontCursor(DrawDisplay,XC_hand1);
      break;

      case v_draw_button_line:
        draw_mode_cursor = XCreateFontCursor(DrawDisplay,XC_crosshair);
      break;

      case v_draw_button_polyline:
        draw_mode_cursor = XCreateFontCursor(DrawDisplay,XC_crosshair);
      break;

      case v_draw_button_freehand:
        draw_mode_cursor = XCreateFontCursor(DrawDisplay,XC_crosshair);
      break;

      case v_draw_button_rectangle:
        draw_mode_cursor = XCreateFontCursor(DrawDisplay,XC_crosshair);
      break;

      case v_draw_button_circle:
        draw_mode_cursor = XCreateFontCursor(DrawDisplay,XC_crosshair);
      break;

      case v_draw_button_ellipse:
        draw_mode_cursor = XCreateFontCursor(DrawDisplay,XC_crosshair);
      break;

      case v_draw_button_arc:
        draw_mode_cursor = XCreateFontCursor(DrawDisplay,XC_crosshair);
      break;

      case v_draw_button_text:
        draw_mode_cursor = XCreateFontCursor(DrawDisplay,XC_crosshair);
      break;

      case v_draw_button_zoom:
        draw_mode_cursor = XCreateFontCursor(DrawDisplay,XC_crosshair);
      break;

      case v_nyi:
        draw_mode_cursor = XCreateFontCursor(DrawDisplay,XC_question_arrow);
      break;

      default:
        draw_mode_cursor = XCreateFontCursor(DrawDisplay,XC_crosshair);
      break;
    } /* switch */

    /* set color of cursor */
/*
 *  cursor_fg = &BlackPixelOfScreen(DrawScreen);
 *  cursor_bg = &WhitePixelOfScreen(DrawScreen);
 */

    /* set foreground color */
    /* black */
    cursor_fg.red   = 0;
    cursor_fg.blue  = 0;
    cursor_fg.green = 0;

    /* set background color */
    /* white */
    cursor_bg.red   = 65535;
    cursor_bg.blue  = 65535;
    cursor_bg.green = 65535;

    XRecolorCursor(DrawDisplay,draw_mode_cursor,&cursor_fg,&cursor_bg);
    XDefineCursor(DrawDisplay,DrawWindow,draw_mode_cursor);

    /* XFreeCursor(DrawDisplay,draw_mode_cursor); */
  } /* else */
} /* set_draw_mode */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  init_draw_proc()                                         */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  Initialize the Drawing Area attributes                   */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  sketchpad.c                                              */
/*                                                                            */
/*      Calls     :  -                                                        */
/*                                                                            */
/* ========================================================================== */

void init_draw_proc ()
{

/* ========================================================================== */
/*      LOCAL VARIABLES                                                       */
/* ========================================================================== */

  XGCValues            DrawGCval;

  XWindowAttributes    old_attrib;
  XSetWindowAttributes new_attrib;

  XColor               cursor_fg, cursor_bg;

  int                  i;

  int                  size;

/* ========================================================================== */
/*  Initialization                                                            */
/* ========================================================================== */

  DrawWidget  = widget_array[v_drawing_area];
  DrawDisplay = XtDisplay (DrawWidget);
  DrawWindow  = XtWindow (DrawWidget);
  DrawScreen  = XtScreen (DrawWidget);
  DrawCmap    = DefaultColormapOfScreen (DrawScreen);

  /* load fonts */
  /* font for pointers */
  if ((ptr_font = XLoadQueryFont (DrawDisplay, PTRFONTNAME)) == NULL)
  {
    fprintf (stderr,
         "init_draw_proc: Warning: couldn't load correct font for pointer.\n");
    fprintf (stderr, "trying to get another font...\n");
    if ((ptr_font = XLoadQueryFont (DrawDisplay, "*")) == NULL)
    {
      fprintf (stderr, "init_draw_proc: Fatal Error: can't load any font!\n");
      exit(-1);
    }
  };

  /* initialize all fonts in the font_table */
  for (size=0; size<TEXT_SIZE_MAX; size++)
  {
    FontTable[size].medium.roman.exact      = False;
    FontTable[size].medium.roman.real_size  = 0;
    FontTable[size].medium.roman.font       = NULL;
    FontTable[size].medium.italic.exact     = False;
    FontTable[size].medium.italic.real_size = 0;
    FontTable[size].medium.italic.font      = NULL;
    FontTable[size].bold.roman.exact        = False;
    FontTable[size].bold.roman.real_size    = 0;
    FontTable[size].bold.roman.font         = NULL;
    FontTable[size].bold.italic.exact       = False;
    FontTable[size].bold.italic.real_size   = 0;
    FontTable[size].bold.italic.font        = NULL;
  } 

  /* load fonts into table */
  set_font_table ();

  /* get some font for text */
  if ((text_font = FontTable[TEXT_SIZE_DEF].bold.roman.font) == NULL)
  {
    fprintf (stderr, "init_draw_proc: Fatal Error: can't load text font!\n");
    exit(-1);
  };
  text_font_list = XmFontListCreate (text_font, XmSTRING_DEFAULT_CHARSET);

  /* do the same with the font list for texts from other users */
  foreign_text_font_list = XmFontListCreate (text_font,
                                             XmSTRING_DEFAULT_CHARSET);


  /* set up drawing GC's */

  /* GC for solid drawing */
  DrawGCval.function   = GXcopy;
  DrawGCval.foreground = WhitePixel (DrawDisplay, DefaultScreen (DrawDisplay));
  DrawGCval.background = BlackPixel (DrawDisplay, DefaultScreen (DrawDisplay));
  DrawGCval.line_width = LINE_WIDTH_MIN;
  DrawGCval.line_style = LineSolid;
  DrawGCval.cap_style  = CAP_STYLE;
  DrawGCval.join_style = JOIN_STYLE;
  DrawGCval.font       = ptr_font->fid;
  DrawGCsolid          = XCreateGC (DrawDisplay, DrawWindow,
                                    (GCFunction|GCForeground|GCBackground|
                                     GCLineWidth|GCLineStyle|GCCapStyle|
                                     GCJoinStyle|GCFont),
                                    &DrawGCval);

  /* for drawing pointers */
  {
    unsigned long planeMask[1];
    unsigned long pixels[1];
    Status success;

    success = XAllocColorCells(DrawDisplay, DrawCmap, False,
                               planeMask, 0, pixels, 1);
    if (success) {
       XStoreNamedColor(DrawDisplay, DrawCmap, "white",
                        pixels[0], (DoRed|DoGreen|DoBlue));
    }
    else {
       sperror("Cannot allocate color for selection color\n");
    }
    DrawGCval.foreground = pixels[0];
  }
  DrawGCWhite          = XCreateGC (DrawDisplay, DrawWindow,
                                    (GCFunction|GCForeground|GCBackground|
                                     GCLineWidth|GCLineStyle|GCCapStyle|
                                     GCJoinStyle|GCFont),
                                    &DrawGCval);

  /* for drawing because of messages etc. */
  DrawGCval.foreground = WhitePixel (DrawDisplay, DefaultScreen (DrawDisplay));
  ForeignGC            = XCreateGC (DrawDisplay, DrawWindow,
                                    (GCFunction|GCForeground|GCBackground|
                                     GCLineWidth|GCLineStyle|GCCapStyle|
                                     GCJoinStyle|GCFont),
                                    &DrawGCval);

  /* for drawing text */
  DrawGCval.font       = text_font->fid;
  DrawGCtext           = XCreateGC (DrawDisplay, DrawWindow,
                                    (GCFunction|GCForeground|GCBackground|
                                     GCLineWidth|GCLineStyle|GCCapStyle|
                                     GCJoinStyle|GCFont),
                                    &DrawGCval);

  /* GC for rubberbanding */
  DrawGCval.function   = GXinvert;
  DrawGCval.font       = ptr_font->fid;
  DrawGCxor            = XCreateGC (DrawDisplay, DrawWindow,
                                    (GCFunction|GCForeground|GCBackground|
                                     GCLineWidth|GCLineStyle|GCCapStyle|
                                     GCJoinStyle|GCFont),
                                    &DrawGCval);

  /* Set actual drawing mode to v_draw_button_freehand */
  set_draw_state (MODE, v_draw_button_freehand);

  /* Set actual selector mode to BOUNDING_BOX_MODE */
  set_draw_state (SELECT_MODE, BOUNDING_BOX_MODE);

  /* Set actual line width to the minimum value    */
  set_draw_state (LINE_WIDTH, LINE_WIDTH_MIN);

  /* Set actual line style to solid                */
  set_draw_state (LINE_STYLE, SOLID);

  /* Set actual text size to default size          */
  set_draw_state (TEXT_SIZE, TEXT_SIZE_DEF);

  /* Set actual text thickness to bold             */
  set_draw_state (TEXT_THICKNESS, BOLD);

  /* Set actual text slant to roman                */
  set_draw_state (TEXT_SLANT, ROMAN);

  /* set cursor shape & color */
  draw_mode_cursor = XCreateFontCursor(DrawDisplay,XC_crosshair);

  /* set foreground color */
  /* black */
  cursor_fg.red   = 0;
  cursor_fg.blue  = 0;
  cursor_fg.green = 0;

  /* set background color */
  /* white */
  cursor_bg.red   = 65535;
  cursor_bg.blue  = 65535;
  cursor_bg.green = 65535;

  XRecolorCursor(DrawDisplay,draw_mode_cursor,&cursor_fg,&cursor_bg);
  XDefineCursor(DrawDisplay,DrawWindow,draw_mode_cursor);

  /* XFreeCursor(DrawDisplay,draw_mode_cursor); */

  /* Create new EventMask for DrawingArea */
  XGetWindowAttributes (DrawDisplay, DrawWindow, &old_attrib);
  new_attrib.event_mask = (old_attrib.your_event_mask|
                           ButtonPressMask|ButtonReleaseMask|PointerMotionMask);

  /* Set new Event Mask */
  XSelectInput (DrawDisplay, DrawWindow, new_attrib.event_mask);

  /* initialize variables for pointer handling */
  for (i=0; i<MAXUSERS; i++)
  {
    pointer_visible[i] = FALSE;

    ptr_bbox[i].x      = 0;
    ptr_bbox[i].y      = 0;
    ptr_bbox[i].width  = 0;
    ptr_bbox[i].height = 0;
  }

} /* init_draw_proc() */

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  free_draw_proc()                                         */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  free the resources (GC's, Fonts,...) needed for drawing  */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  the Callback rout. quit_proc()                           */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

void free_draw_proc()
{
  int size;

  XFreeGC (DrawDisplay, DrawGCsolid);
  XFreeGC (DrawDisplay, DrawGCWhite);
  XFreeGC (DrawDisplay, ForeignGC);
  XFreeGC (DrawDisplay, DrawGCtext);
  XFreeGC (DrawDisplay, DrawGCxor);

  if (ptr_font)
    XFreeFont (DrawDisplay, ptr_font);

  if (text_font)
    XFreeFont (DrawDisplay, text_font);
/*
  if (new_text_font)
    XFreeFont (DrawDisplay, new_text_font);
*/
  XmFontListFree (text_font_list);
  XmFontListFree (foreign_text_font_list);

  for (size=0; size<TEXT_SIZE_MAX; size++)
  {
    if (FontTable[size].medium.roman.font)
    {
      XFreeFont (DrawDisplay, FontTable[size].medium.roman.font);
    }
    if (FontTable[size].medium.italic.font)
    {
      XFreeFont (DrawDisplay, FontTable[size].medium.italic.font);
    }
/*
    if (FontTable[size].bold.roman.font)
    {
      XFreeFont (DrawDisplay, FontTable[size].bold.roman.font);
    }
*/
    if (FontTable[size].bold.italic.font)
    {
      XFreeFont (DrawDisplay, FontTable[size].bold.italic.font);
    }
  }

} /* free_draw_proc() */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  set_clip()                                               */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  routine for setting the clipping region of the GC;       */
/*                   the clipping region is the intersection of two rectangles*/
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by : only indirect calls:                                      */
/*                  assignment to the function variable 'setclip'             */
/*                  in ui/sketchpad.c                                         */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

void set_clip ( XRectangle rec1, XRectangle rec2 )
{
  Region clipregion, ownregion;

  /* create first region */
  clipregion = XCreateRegion();
  XUnionRectWithRegion (&rec1, clipregion, clipregion);

  /* create second region */
  ownregion  = XCreateRegion();
  XUnionRectWithRegion (&rec2, ownregion, ownregion);

  /* compute the intersection between the two regions */
  XIntersectRegion (clipregion, ownregion, clipregion);

  /* the intersection is the current clipping region */
  XSetRegion (DrawDisplay, DrawGCsolid, clipregion);
} /* set_clip */


/* ========================================================================== */
/*  This Function has to be removed lateron !!                                */
/*  it sets the clipping region to the whole window                           */
/* ========================================================================== */

void destroy_clip_area ()
{
  XSetClipMask (DrawDisplay, DrawGCsolid, None);
} /* destroy_clip_area */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  set_draw_color()                                         */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  set the current drawing color in the given GC            */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

void set_draw_color ( GC gr_context, unsigned long color_pixel )
{
  XSetForeground (DrawDisplay, gr_context, color_pixel);
} /* set_draw_color */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  set_foreign_font_attributes ()                           */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  set the current text font in the ForeignGC               */
/*                                                                            */
/*      Accesses  :  FontTable[]                                              */
/*                                                                            */
/*      Called by :  receive_message() in kernel/user.c,                      */
/*                   draw_object() in misc/ographic.c                         */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

void set_foreign_font_attributes ( int size, int thick, int slant )
{
  Boolean new_text_font_exact = False;

  new_text_font = NULL;

  switch (thick)
  {
    case BOLD:
      switch (slant)
      {
        case ROMAN:
          new_text_font       = FontTable[size].bold.roman.font;
          new_text_font_exact = FontTable[size].bold.roman.exact;
          break;
        case ITALIC:
          new_text_font       = FontTable[size].bold.italic.font;
          new_text_font_exact = FontTable[size].bold.italic.exact;
          break;
        default:
          new_text_font       = FontTable[size].bold.roman.font;
          new_text_font_exact = FontTable[size].bold.roman.exact;
          break;
      } /* switch (slant) */
      break;
    case MEDIUM:
      switch (slant)
      {
        case ROMAN:
          new_text_font       = FontTable[size].medium.roman.font;
          new_text_font_exact = FontTable[size].medium.roman.exact;
          break;
        case ITALIC:
          new_text_font       = FontTable[size].medium.italic.font;
          new_text_font_exact = FontTable[size].medium.italic.exact;
          break;
        default:
          new_text_font       = FontTable[size].medium.roman.font;
          new_text_font_exact = FontTable[size].medium.roman.exact;
          break;
      } /* switch (slant) */
      break;
    default:
      switch (slant)
      {
        case ROMAN:
          new_text_font       = FontTable[size].bold.roman.font;
          new_text_font_exact = FontTable[size].bold.roman.exact;
          break;
        case ITALIC:
          new_text_font       = FontTable[size].bold.italic.font;
          new_text_font_exact = FontTable[size].bold.italic.exact;
          break;
        default:
          new_text_font       = FontTable[size].bold.roman.font;
          new_text_font_exact = FontTable[size].bold.roman.exact;
          break;
      } /* switch (slant) */
      break;
  } /* switch (thick) */

  if (new_text_font_exact == False)
  {
/*
    char    textbuf[80];

    sprintf (textbuf,
             "set_foreign_font_attributes: "
             "Error: no font with correct attributes %d, %d, %d available!",
             size, thick, slant);
    sperror (textbuf);
    sperror ("warning: objects might appear in wrong size!!!");
*/
  } /* if */

  if (new_text_font == NULL)
  {
    fprintf (stderr,
             "set_foreign_font_attributes: "
             "Error: no font found. Old font not changed.\n");
  } /* if */
  else
  {
    XGCValues DrawGCval;

    foreign_text_font_list = XmFontListCreate (new_text_font,
                                               XmSTRING_DEFAULT_CHARSET);
    DrawGCval.font = new_text_font->fid;
    XChangeGC (DrawDisplay, ForeignGC, GCFont, &DrawGCval);
  } /* else */
} /* set_foreign_font_attributes */

