/*============================================================================*/
/*                                                                            */
/* Forward declarations for layer module                                      */
/*                                                                            */
/*============================================================================*/

#ifndef LAYERS_HEADERS
#define LAYERS_HEADERS

#include "../misc/ographic.h"

#define LS_NONE       0
#define LS_VISIBLE    1
#define LS_LOAD       2
#define LS_SAVE       4
#define LS_PRINT      8
#define LS_CLEAR     16
#define LS_ACTIVE    32 
#define LS_COLOR     64 

#define LAYERNAMELEN 20

typedef void* layer;

extern void InitLayers(void);
extern int ClearLayer (int, int);
extern void CreateLayerList(Widget);
extern layer GetActiveLayer(void);
extern struct_storage GetStructStorage(layer);
extern char *GetLayerName(int);
extern char *GetLayerCharName(layer);
extern layer add_layer(char*, int, int,
                       Boolean, Boolean);
extern void  add_buttons(layer);
extern layer add_lay(char*, Boolean);
extern void delete_lay(int);
extern void delete_layer(int, int);
extern void show_lay(Widget, WidgetClass, unsigned long);
extern void AddCallback(int);
extern void rename_layer(layer, char*);
extern void SetLayerName(int, char*);
extern layer GetFirstLayer (void);
extern layer GetNextLayer (void);
extern void SetLayerState (layer, int);
extern int  GetLayerState (layer);
extern layer GetLayer (int, int);
extern layer GetLayerFromNo (int);
extern void GetLayerId (layer, int*, int*);
extern unsigned long GetLayerColor (layer);
extern Boolean SetLayerColor (layer, XColor);
extern Boolean SaveLayerColors (void);
extern Boolean RestoreLayerColors (void);
extern void DrawLayer (layer, XRectangle);
extern void *GetCurrentLayer(void);
extern void SetCurrentLayer(void*);
extern unsigned long int GetEditColor(Widget);
extern int get_layer_list_position (Widget);

#endif LAYERS_HEADERS



