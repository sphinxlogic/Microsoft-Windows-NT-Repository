/* ========================================================================== */
/*    header file for sketchpad.c                                             */
/* ========================================================================== */

#include <Mrm/MrmAppl.h>

extern Widget widget_array []; 

extern Widget toplevel_widget; 

extern XImage *pic_image;          /* background_image                */

extern MrmHierarchy s_MrmHierarchy;
extern MrmType dummy_class;

extern long int sketch_width,
                sketch_height;

extern Colormap cmap;

extern Boolean    my_pointer_visible;
extern Boolean    pointer_visible [];
extern XRectangle ptr_bbox [];
extern char       hostn[];

extern int        layer_state;

extern XRectangle WholeDrawingArea;
extern void RedrawAll(XRectangle);
extern void IRedraw(XRectangle);
extern void stop_sketchpad();
