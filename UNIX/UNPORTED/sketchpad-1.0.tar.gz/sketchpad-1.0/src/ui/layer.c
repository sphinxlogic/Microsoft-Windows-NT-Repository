/* ========================================================================== */
/*                                                                            */
/* Filename:     layer.c                          +-----+-----+--+--+--+--+   */
/* Version :     1.2	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/8/92	11:42:58	                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*                                                                            */
/*  Forward declarations of includes, variables and constants                 */
/*                                                                            */
/* ========================================================================== */

#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include "../misc/sperror.h"
#include "../misc/list.h"
#include "../misc/ographic.h"
#include "../kernel/user.h"
#include "../draw/drawstate.h"
#include "../draw/setdraw.h"
#include <Mrm/MrmAppl.h>                   /* Motif Toolkit */
#include <Xm/ToggleB.h>
#include <Xm/PushB.h>
#include <Xm/List.h>
#include <Xm/Label.h>
#include <Xm/Scale.h>
#include <Xm/Text.h>
#include "sketchpad.h"
#include "defs.h"

#define LS_NONE       0  /* flags for keeping     */
#define LS_VISIBLE    1  /* layer status in       */
#define LS_LOAD       2  /* 'layer_s.layer_state' */
#define LS_SAVE       4
#define LS_PRINT      8
#define LS_CLEAR     16
#define LS_ACTIVE    32
#define LS_COLOR     64

#define LAYERNAMELEN 20
#define LAYERCOLORS  10

struct layer_s
{
  char           layer_name[LAYERNAMELEN];
  int            layer_state;
  int            layer_id;
  int            sketch_id;
  XmString       layer_XmName;
  Widget         visible_layer_button;     /*   Widget IDs of     */
  Widget         load_layer_button;        /*                     */
  Widget         save_layer_button;        /*     the layer       */
  Widget         print_layer_button;       /*                     */
  Widget         active_layer_button;      /*    buttons in       */
  Widget         label_layer_button;       /*                     */
  Widget         color_layer_button;       /*     Subwindows      */
  struct_storage layer_objects;
  unsigned long int color; 
};

typedef struct layer_s* layer;

static list layer_list;
static int id;
static layer active_layer = NULL;

/* default colors for the layers. If there are installed more layers than     */
/* default colors are availible, then the color for these layers is 'black'   */

static char* default_colors [LAYERCOLORS+1] =
               {
                 "red","green","blue","yellow","cyan",          /* the colors */
                 "magenta","grey","brown","violet","tan",
                 ""                                             /* the end    */
               };
static int next_color = 0;

static unsigned long layer_pixels [LAYERCOLORS];
static Boolean layer_pixels_free [LAYERCOLORS];
static int layer_colors_allocated = 0;
static int layers_installed = 0;

struct layer_color_s
{
  int    layer_id;
  int    sketch_id;
  XColor color;
};

typedef struct layer_color_s* layer_color;

static list actual_layer_color_list = NULL;

static void ButtonCB();
static void ToggleCB(Widget w,unsigned long type,
		     XmToggleButtonCallbackStruct *call_data);
       layer add_layer(char*, int, int, Boolean, Boolean);
       void add_buttons();
       void delete_layer();
       layer GetLayer();
       layer GetLayerFromNo();
       void CreateLayerList();

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  InitLayers                                               */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  Initializing the layers by using list module             */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  init_application() in sketchpad.c                        */
/*                                                                            */
/*      Calls     :  CreateList()                                             */
/*                                                                            */
/* ========================================================================== */
void InitLayers(void)
{
  layer p;

  unsigned long plane_masks[1];
  unsigned long pixels[1];

  int i;

  Boolean success;

  for (i=1; i<LAYERCOLORS; i++)
  {
    layer_pixels_free[i] = False;
  }

  do
  {
    success = XAllocColorCells (DrawDisplay, DrawCmap, False, plane_masks, 0,
                                pixels, 1);
    if (success)
    {
      layer_pixels [layer_colors_allocated] = pixels [0];
      XStoreNamedColor (DrawDisplay, DrawCmap, "black",
                        pixels[0], (DoRed|DoGreen|DoBlue));
      layer_pixels_free[layer_colors_allocated] = True;
      layer_colors_allocated++;
    }
  } while ((layer_colors_allocated<LAYERCOLORS) && (success));

  if (! success)
  {
    char text[80];
    sprintf(text, "could allocate only %d of %d required layer colors.",
            layer_colors_allocated, LAYERCOLORS);
    sperror(text);
  }

  /* Initialize layer list */
  layer_list = CreateList ();
  id=1;

  /* Set the first layer as background */
  p = (layer) malloc (sizeof (struct layer_s));
  strcpy (p->layer_name, "Background");
  p->layer_state = LS_VISIBLE | LS_LOAD ;
  p->layer_XmName = XmStringCreateLtoR (p->layer_name,
                                        XmSTRING_DEFAULT_CHARSET);
  p->load_layer_button = (Widget) NULL;
  p->save_layer_button = (Widget) NULL;
  p->print_layer_button = (Widget) NULL;
  p->active_layer_button = (Widget) NULL;
  p->label_layer_button = (Widget) NULL;
  p->layer_objects = CreateSS ();
  SetTransformation (p->layer_objects, 0, 0);
  p->layer_id = id++; /* == 1 */
  p->sketch_id = 0;

  /* background has no color, as a dummy just store 'black' in its cell */
  p->color = BlackPixelOfScreen (DrawScreen);

  InsertEndEntry (layer_list, p);
  active_layer = NULL;
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  show_lay                                                 */
/*                                                                            */
/*      Version   :  2                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  showing Layer-Toggle-Buttons in c_layer_proc             */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  layer_pull_proc                                          */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
void show_lay(Widget w, WidgetClass c, unsigned long type)
{
  layer p;
  Arg args[1];
  Boolean flag;
  Widget button;

  FirstEntry (layer_list);
  while (GetListState (layer_list) == E_OK)
  {
    p = (layer) GetEntry (layer_list);

    /*
     * Create Widget for each layer in list
     * The type parameter is for selecting the
     * buttons in several Subwindows
     */

    button = XtCreateWidget (p->layer_name, c, w, NULL, 0);

    switch (type)
    {
      case LS_NONE :
        p->label_layer_button = button;
        XtManageChild (button);
        break;

      case LS_LOAD :
        p->load_layer_button = button;
        XtManageChild (button);
        break;

      case LS_SAVE :
        p->save_layer_button = button;
        XtManageChild (button);
        break;

      case LS_PRINT :
        p->print_layer_button = button;
        XtManageChild (button);
        break;

      case LS_ACTIVE :
        if ((p->layer_id == 1) || (p->sketch_id != ownUserNumber))
        {
          /* no toggle-button for background layer */
          /* Fetch toggle-button from uil file     */
          button=NULL;
          if (MrmFetchWidget(s_MrmHierarchy, "c_empty_button", w,
              &button, &dummy_class) == MrmSUCCESS)
          {
            p->active_layer_button = button;
            XtManageChild (button);
          }
          else
          {
            sperror("Can't fetch active_layer_button");
          }
        }
        else
        {
          /* Fetch toggle-button from uil file     */
          button=NULL;
          if (MrmFetchWidget(s_MrmHierarchy, "c_toggle_button", w,
              &button, &dummy_class) == MrmSUCCESS)
          {
            p->active_layer_button = button;
            XtManageChild (button);
          }
          else
          {
            sperror("Can't fetch active_layer_button");
          }
        }
        break;

      case LS_VISIBLE :
        /* Fetch toggle-button from uil file     */
        button=NULL;
        if (MrmFetchWidget(s_MrmHierarchy, "c_toggle_button", w,
            &button, &dummy_class) == MrmSUCCESS)
        {
          p->visible_layer_button = button;
          XtManageChild (button);
        }
        else
        {
          sperror("Can't fetch visible_layer_button");
        }
        break;

      case LS_COLOR:
        if (p->layer_id == 1)
        {
          /* no color-button for background layer */
          /* Fetch push-button from uil file      */
          button=NULL;
          if (MrmFetchWidget(s_MrmHierarchy, "c_empty_button", w,
              &button, &dummy_class) == MrmSUCCESS)
          {
            p->color_layer_button = button;
            XtSetArg (args[0], XmNmarginTop, 9);
            XtSetValues (button, args, 1);
            XtManageChild (button);
          }
          else
          {
            sperror("Can't fetch color_layer_button");
          }
        }
        else
        if (p->sketch_id != ownUserNumber)  /* it's a foreign layer ? */
        {
          /* no color-push-button for foreign layers */
          /* Fetch push-button from uil file         */
          button=NULL;
          if (MrmFetchWidget(s_MrmHierarchy, "c_empty_button", w,
              &button, &dummy_class) == MrmSUCCESS)
          {
            p->color_layer_button = button;
            XtSetArg (args[0], XmNbackground, p->color);
            XtSetValues (button, args, 1);
            XtManageChild (button);
          }
          else
          {
            sperror("Can't fetch color_layer_button");
          }
        }
        else
        {
          button=NULL;
          if (MrmFetchWidget(s_MrmHierarchy, "c_push_button", w,
              &button, &dummy_class) == MrmSUCCESS)
          {
            p->color_layer_button = button;
            XtSetArg (args[0], XmNbackground, p->color);
            XtSetValues (button, args, 1);
            XtManageChild (button);
          }
          else
          {
            sperror("Can't fetch color_layer_button");
          }
        }
        break;
    }

    /* Making layer active & visible */
    if (p->layer_state & type)
    {
      flag = True;
    }
    else
    {
      flag = False;
    }
    XtSetArg (args[0], XmNset, flag);
    XtSetValues (button, args, 1);

    /* Adding Callbacks */
    if ( (type == LS_VISIBLE) || (type == LS_PRINT) ||
         (type == LS_LOAD)    || (type == LS_SAVE)  ||
         (type == LS_CLEAR) )
    {
      XtAddCallback (button, XmNvalueChangedCallback, ButtonCB, (caddr_t) type);
    }
    /* Add no 'active callback' for background */
    if ( (type == LS_ACTIVE) && (p->layer_id != 1) )
    {
      XtAddCallback (button, XmNvalueChangedCallback, ButtonCB, (caddr_t) type);
    }
    NextEntry (layer_list); 
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  add_lay                                                  */
/*                                                                            */
/*      Version   :  2                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  adding layer in layer list                               */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  add_lay_proc in sketchpad.c, Load in image/io.c          */
/*                                                                            */
/*      Calls     :  msg_new_layer ,add_layer                                 */
/*                                                                            */
/* ========================================================================== */
layer add_lay (char *name, Boolean visible_flag)
{
  layer p;

  msg_new_layer (name, id, ownUserNumber, visible_flag);
  /* the one who adds the layer adds it always visible! */
  p = add_layer (name, id++, ownUserNumber,
                 True, False);

  /* make old active layer inactive */
  active_layer->layer_state = active_layer->layer_state & ~(LS_ACTIVE);
  /* deselect all objects in old active layer */
  DeselectAll(active_layer->layer_objects);
  
  /* make layer active */
  p->layer_state |= LS_ACTIVE;

  add_buttons(p);

  active_layer = p;
  return p;
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  add_layer                                                */
/*                                                                            */
/*      Version   :  3                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  adding layer in layer list                               */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  add_lay , receiveMessageProc                             */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
layer add_layer (char *name, int layer_id, int sketch_id,
                 Boolean visible_flag, Boolean conference_flag)
{
  layer  p;
  XColor Layer_XColor;

  unsigned long plane_masks[1];
  unsigned long pixels[1];

  Boolean a_free_one;
  int place, i;

  if (GetLayer (layer_id, sketch_id) == NULL)
  {
    XColor             exact_Layer_XColor, screen_Layer_XColor;
    unsigned short int Layer_Red   = 0;
    unsigned short int Layer_Green = 0;
    unsigned short int Layer_Blue  = 0;

    if (sketch_id == ownUserNumber)
    {
      id = layer_id + 1;
    }
    if (XLookupColor (DrawDisplay, DrawCmap, default_colors [next_color],
		      &exact_Layer_XColor, &screen_Layer_XColor))
    {
      Layer_Red   = exact_Layer_XColor.red;
      Layer_Green = exact_Layer_XColor.green;
      Layer_Blue  = exact_Layer_XColor.blue;
    }
    else
    {
      char text[80];
      sprintf(text, "add_lay: unknown color: %s! color is now black!",
	      default_colors [next_color]);
      sperror(text);
    }

    Layer_XColor.red   = Layer_Red;
    Layer_XColor.green = Layer_Green;
    Layer_XColor.blue  = Layer_Blue;
    Layer_XColor.flags = (DoRed|DoGreen|DoBlue);

    /* alloc memory for new Layer */
    p = (layer) malloc (sizeof (struct layer_s));
    if(p==NULL)
    {
      sperror("No memory !!");
      return (NULL);
    }

    /* set the first created object-layer as active layer */
    if (active_layer == NULL)
    {
      active_layer = p;
      visible_flag = 1;
    }
    strcpy (p->layer_name, name);
    p->layer_XmName = XmStringCreateLtoR (p->layer_name,
					  XmSTRING_DEFAULT_CHARSET);
    p->layer_objects = CreateSS ();
    p->layer_id = layer_id;
    p->sketch_id = sketch_id;

    if (visible_flag)
    {
      p->layer_state = LS_VISIBLE;
    }
    else
    {
      p->layer_state = LS_NONE;
    }

    /* are there still allocated color cells free? */
    a_free_one = False;
    i=0;
    do
    {
      if (layer_pixels_free[i])
      {
	a_free_one = True;
	place = i;
      }
      i++;
    } while ((i<LAYERCOLORS)&&(!a_free_one));

    if (a_free_one)
    {                    /* yes, just store default color in color cell */
      Layer_XColor.pixel = layer_pixels[place];

      XStoreColor (DrawDisplay, DrawCmap, &Layer_XColor);

      p->color = layer_pixels[place];
      layer_pixels_free[place] = False;

      layers_installed++;

      next_color++;
      if (!(*(default_colors [next_color])))
      {
	next_color = 0;
      }
    }
    else
    {        /* no, try to allocate a new one and store the color in it */
      if (XAllocColorCells (DrawDisplay, DrawCmap, False, plane_masks, 0,
			    pixels, 1))
      {
	Layer_XColor.pixel = pixels[0];

	XStoreColor (DrawDisplay, DrawCmap, &Layer_XColor);

	p->color = pixels[0];

	next_color++;
	if (!(*(default_colors [next_color])))
	{
	  next_color = 0;
	}
      }
      else
      {
	p->color = BlackPixelOfScreen (DrawScreen);

	sperror("couldn't allocate color for new layer,");
	sperror(" new layer color now black.");
      }
    }

    if (widget_array[v_layer_manage_box3] != 0)
    {
      XmListAddItem (widget_array[v_layer_manage_box3], p->layer_XmName,0);
    }

    InsertEndEntry (layer_list, p);

    /* Was layer created by conference module ? */
    if (conference_flag == True)
    {
      if (sketch_id == ownUserNumber)
      {
	p->layer_state = LS_VISIBLE | LS_ACTIVE;
	active_layer = p;
      }
    }

    SetTransformation (p->layer_objects, 0, 0);
    return p;
  }
  else
  {
    return NULL;
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  add_buttons                                              */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  managing buttons in several subwindows                   */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  add_layer                                                */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
void add_buttons(layer p)
{
  Arg args[1];

  /*   add buttons in load-box       */
  if (widget_array[v_load_box] != NULL)
  {
    p->load_layer_button = XtCreateWidget (p->layer_name,
      xmToggleButtonWidgetClass, widget_array[v_load_box_layer_box], NULL, 0);
    XtManageChild (p->load_layer_button);
    XtSetArg (args[0], XmNset, False);
    XtSetValues (p->load_layer_button, args, 1);
    XtAddCallback (p->load_layer_button, XmNvalueChangedCallback,
                   ButtonCB, (caddr_t) LS_LOAD);
  }
  else
  {
    p->load_layer_button = (Widget) NULL;
  }

  /*   add buttons in save-box       */
  if (widget_array[v_save_box] != NULL)
  {
    p->save_layer_button = XtCreateWidget (p->layer_name,
      xmToggleButtonWidgetClass, widget_array[v_save_box_layer_box], NULL, 0);
    XtManageChild (p->save_layer_button);
    XtSetArg (args[0], XmNset, False);
    XtSetValues (p->save_layer_button, args, 1);
    XtAddCallback (p->save_layer_button, XmNvalueChangedCallback,
                   ButtonCB, (caddr_t) LS_SAVE);
  }
  else
  {
    p->save_layer_button = (Widget) NULL;
  }

  /*   add buttons in print-box       */
  if (widget_array[v_print_box] != NULL)
  {
    p->print_layer_button = XtCreateWidget (p->layer_name,
      xmToggleButtonWidgetClass, widget_array[v_print_box_layer_box], NULL, 0);
    XtManageChild (p->print_layer_button);
    XtSetArg (args[0], XmNset, False);
    XtSetValues (p->print_layer_button, args, 1);
    XtAddCallback (p->print_layer_button, XmNvalueChangedCallback,
                   ButtonCB, (caddr_t) LS_PRINT);
  }
  else
  {
    p->print_layer_button = (Widget) NULL;
  }

  /*     add buttons in status-box       */
  if (widget_array[v_layer_status_box] != NULL)
  {
    /* add visible button */
    p->visible_layer_button=NULL;
    if (MrmFetchWidget(s_MrmHierarchy,"c_toggle_button",
                       widget_array[v_layer_status_boxA],
                       &(p->visible_layer_button),
                       &dummy_class)  == MrmSUCCESS)
    {
      XtManageChild (p->visible_layer_button);
      if (p->layer_state & LS_VISIBLE)
      {
        XtSetArg (args[0], XmNset, True);
        XtSetValues (p->visible_layer_button, args, 1);
      }
      XtAddCallback (p->visible_layer_button, XmNvalueChangedCallback,
                       ButtonCB, (caddr_t) LS_VISIBLE);
    }
    else
    {
      sperror("Can't fetch visible_layer_button");
    }

    /* add active button */
    if (p->sketch_id != ownUserNumber)
    {
       /* no toggle-button for layer of foreign users */
       /* Fetch toggle-button from uil file     */
       p->active_layer_button=NULL;
       if (MrmFetchWidget(s_MrmHierarchy, "c_empty_button",
	   widget_array[v_layer_status_boxB], 
           &p->active_layer_button, &dummy_class) == MrmSUCCESS)
       {
         XtManageChild (p->active_layer_button);
       }
       else
       {
         sperror("Can't fetch active_layer_button");
       }
     }
     else
     {
       /* add active button */
       p->active_layer_button=NULL;
       if (MrmFetchWidget(s_MrmHierarchy,"c_toggle_button",
                          widget_array[v_layer_status_boxB],
                          &(p->active_layer_button),
                          &dummy_class)  == MrmSUCCESS)
       {
         XtManageChild (p->active_layer_button);
         if (p->layer_state & LS_ACTIVE)
         {
           XtSetArg (args[0], XmNset, True);
           XtSetValues (p->active_layer_button, args, 1);
           XtSetArg (args[0], XmNset, False);
           XtSetValues (active_layer->active_layer_button, args, 1);
         }
         XtAddCallback (p->active_layer_button, XmNvalueChangedCallback,
                          ButtonCB, (caddr_t) LS_ACTIVE);
       }
       else
       {
         sperror("Can't fetch active_layer_button");
       }
    }
    /* add label (name) for button */
    p->label_layer_button = XtCreateWidget (p->layer_name,
      xmLabelWidgetClass, widget_array[v_layer_status_boxC], NULL, 0);
    XtManageChild (p->label_layer_button);
    XtSetArg (args[0], XmNlabelString, p->layer_XmName);
    XtSetValues (p->label_layer_button, args, 1);

    /* add color button */ 
    if (p->sketch_id != ownUserNumber)
    {
      /* no color-button for background layer */
      /*           and layer of foreign users */
      /* Fetch push-button from uil file      */
      p->color_layer_button=NULL;
      if (MrmFetchWidget(s_MrmHierarchy, "c_empty_button",
	  widget_array[v_layer_status_boxD],
          &p->color_layer_button, &dummy_class) == MrmSUCCESS)
      {
        XtSetArg (args[0], XmNbackground, p->color);
        XtSetValues (p->color_layer_button, args, 1);
        XtManageChild (p->color_layer_button);
      }
      else
      {
        sperror("Can't fetch color_layer_button");
      }
    }
    else
    {
      p->color_layer_button=NULL;
      if (MrmFetchWidget(s_MrmHierarchy,"c_push_button",
                       widget_array[v_layer_status_boxD],
                       &(p->color_layer_button),
                       &dummy_class)  == MrmSUCCESS)
      {
        XtManageChild (p->color_layer_button);
        XtSetArg (args[0], XmNbackground, p->color);
        XtSetValues (p->color_layer_button, args, 1);
      }
      else
      {
        sperror("Can't fetch label_layer_button");
      }
    }
  }
  else
  {
    p->label_layer_button   = (Widget) NULL;
    p->color_layer_button   = (Widget) NULL;
    p->active_layer_button  = (Widget) NULL;
    p->visible_layer_button = (Widget) NULL;
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  CreateLayerList                                          */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  install the layer list for scrolled list                 */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  layer_pull_proc , receiveMessageProc                     */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
void CreateLayerList(Widget w)
{
  layer p;
  int i;
  Arg args[1];

  if (w != NULL)
  {
    XtSetArg (args[0], XmNitemCount, 0);
    XtSetValues (w, args, 1);
    FirstEntry (layer_list);
    i = 1;
    while (GetListState (layer_list) == E_OK)
    {
      p = GetEntry (layer_list);
      XmListAddItem (w, p->layer_XmName, i++);
      NextEntry (layer_list);
    }
    /*
     *  This is for debugging XmScrolledList on SUN
     */
    for (; i < 11; i++)
    {
      XmListAddItem (w, XmStringCreateLtoR("", XmSTRING_DEFAULT_CHARSET), i);
    }
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  delete_layer_buttons                                     */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  delete layer buttons in several subwindows               */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  delete_layer                                             */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
void delete_layer_buttons(layer p)
{
  /* delete layer buttons in load-box */
  if (widget_array[v_load_box] != NULL)
  {
    XtUnmanageChild(p->load_layer_button);
    XtDestroyWidget(p->load_layer_button);
  }

  /* delete layer buttons in save-box */
  if (widget_array[v_save_box] != NULL)
  {
    XtUnmanageChild(p->save_layer_button);
    XtDestroyWidget(p->save_layer_button);
  }

  /* delete layer buttons in print-box */
  if (widget_array[v_print_box] != NULL)
  {
    XtUnmanageChild(p->print_layer_button);
    XtDestroyWidget(p->print_layer_button);
  }

  /* delete layer buttons in status-box: */
  /*    active, visible, label, color    */
  if (widget_array[v_layer_status_box] != NULL)
  {
    XtUnmanageChild(p->active_layer_button);
    XtDestroyWidget(p->active_layer_button);
    XtUnmanageChild(p->visible_layer_button);
    XtDestroyWidget(p->visible_layer_button);
    XtUnmanageChild(p->label_layer_button);
    XtDestroyWidget(p->label_layer_button);
    XtUnmanageChild(p->color_layer_button);
    XtDestroyWidget(p->color_layer_button);
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  delete_lay                                               */
/*                                                                            */
/*      Version   :  2                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  removing selected Layer from Sketchpad                   */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  delete_lay_proc                                          */
/*                                                                            */
/*      Calls     :  delete_layer, msg_kill_layer, DeleteEntry                */
/*                                                                            */
/* ========================================================================== */
void delete_lay (int pos)
{
  layer          p;
  
  /* search selected layer in list */
  p = GetLayerFromNo (pos);

  if (p != NULL)
  {
    if (active_layer == p)
    {
      /* if layer is active, print warning ! */
      sperror("Warning: you killed an active layer !!");
    }
    if (p->layer_id == 1)
    {
      /* if layer is background layer, delete will not be recognized */
      sperror("Warning: you can not kill background layer !!");
    }
    else
    if (p->sketch_id != ownUserNumber)
    {
      /* if layer is your partners layer, delete will not be recognized */
      sperror("Warning: you can not kill your partners layer !!");
    }
    else
    {
      msg_kill_layer (p->layer_id, p->sketch_id);
      delete_layer (p->layer_id, p->sketch_id);
    }
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  delete_layer                                             */
/*                                                                            */
/*      Version   :  2                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  removing selected Layer from Sketchpad                   */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  receiveMessageProc, delete_lay                           */
/*                                                                            */
/*      Calls     :  RedrawAll, delete_layer_buttons,                         */
/*                                                                            */
/* ========================================================================== */
void delete_layer (int layer_id, int sketch_id)
{
  layer          p, q;
  Arg            args[1];
  unsigned long  pixels[1];
  int            i, place;
  Boolean        color_in_allocated_colors;

  p = GetLayer (layer_id, sketch_id);

  if (p != NULL)
  {
    delete_layer_buttons (p);

    if (widget_array[v_layer_manage_box4] != NULL)
    {
      XmTextSetString (widget_array[v_layer_manage_box4], "");
    }

    if (widget_array[v_layer_manage_box3] != 0)
    {
      XmListDeleteItem (widget_array[v_layer_manage_box3], p->layer_XmName);
    }

    DeleteEntry (layer_list);

    /* free color for this layer */
    pixels [0] = p->color;

    /* check wether the pixel is BlackPixelOfScreen */
    /* we can't write into BlackPixelOfScreen ! */
    if (p->color != BlackPixelOfScreen (DrawScreen))
    {
      XStoreNamedColor (DrawDisplay, DrawCmap, "black",
                        pixels[0], (DoRed|DoGreen|DoBlue));

      /* free color only if none of the first 10 colors */
      color_in_allocated_colors = False;
      for (i=0; i<LAYERCOLORS; i++)
      {
        if (p->color == layer_pixels[i])
        {
          color_in_allocated_colors = True;
          place = i;
        }
      }
      if (color_in_allocated_colors)
      {
        layer_pixels_free[place] = True;
      }
      else
      {
        XFreeColors (DrawDisplay, DrawCmap, pixels, 1, 0);
      }
    }
    
    if (active_layer == p)
    {
      free(p);
      active_layer = NULL;
      FirstEntry (layer_list);
      while (GetListState (layer_list) == E_OK)
      {
        q = (layer) GetEntry (layer_list);
        if (q->layer_id != 1)
        {
          active_layer = q;
          active_layer->layer_state = active_layer->layer_state | LS_ACTIVE;
          if (widget_array[v_layer_status_box] != NULL)
          {
            XtSetArg (args[0], XmNset, True);
            XtSetValues (active_layer->active_layer_button, args, 1);
          }
        /* leave loop by brutal force (Sorry !) */
        break;
        }
        NextEntry (layer_list);
      }
    }else {
     free(p);
   }
    if (active_layer == NULL)
    {
      sperror("D E E P   T R U B B L E  : You killed your last layer !");
    }

    RedrawAll (WholeDrawingArea);
  }
  else
  {
    char text[80];
    sperror("delete_layer: don't know this layer, can't kill it:");
    sprintf(text, "layer_id = %d, sketch_id = %d.",layer_id,sketch_id);
    sperror(text);
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  GetActiveLayer                                           */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  get pointer to active layer                              */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

layer GetActiveLayer (void)
{
  if (active_layer != NULL)
    return active_layer;
  else
    return NULL;
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  GetStructStorage                                         */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  return the object-storage of this layer                  */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
struct_storage GetStructStorage (layer lay)
{
  return lay->layer_objects;
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  GetLayerName                                             */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  Get the name of a layer in a XmList                      */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  set_pos_proc                                             */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
char *GetLayerName(int num)
{
  FirstEntry(layer_list);
  while(num-- > 1)
  {
    NextEntry(layer_list);
  }  
  return((layer) GetEntry(layer_list))->layer_name;
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  rename_layer                                             */
/*                                                                            */
/*      Version   :  2                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  Rename layer and buttons in several subwindows           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  SetLayerName , receiveMessageProc                        */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
void rename_layer (layer p, char *name)
{
  Arg args[1];
  XmString xms;

  /* rename layername in layerlist */
  strcpy (p->layer_name, name);
  xms = XmStringCreateLtoR (name, XmSTRING_DEFAULT_CHARSET);
  p->layer_XmName = xms;

  /* rename buttons in several subwindows */
  if (p->label_layer_button != NULL)
  {
    XtSetArg (args[0], XmNlabelString, xms);
    XtSetValues (p->label_layer_button, args, 1);
  }
  if (p->load_layer_button != NULL)
  {
    XtSetArg (args[0], XmNlabelString, xms);
    XtSetValues (p->load_layer_button, args, 1);
  }
  if (p->save_layer_button != NULL)
  {
    XtSetArg (args[0], XmNlabelString, xms);
    XtSetValues (p->save_layer_button, args, 1);
  }
  if (p->print_layer_button != NULL)
  {
    XtSetArg (args[0], XmNlabelString, xms);
    XtSetValues (p->print_layer_button, args, 1);
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  SetLayerName                                             */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  Set the name of a layer in a layer list                  */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  rename_lay_proc                                          */
/*                                                                            */
/*      Calls     :  rename_layer , msg_rename_layer                          */
/*                                                                            */
/* ========================================================================== */
void SetLayerName (int num, char *name)
{
  layer p;

  FirstEntry(layer_list);
  while(num-- > 1)
  {
    NextEntry(layer_list);
  }  
  p = GetEntry (layer_list);
  msg_rename_layer (name, p->layer_id, p->sketch_id);
  rename_layer(p, name);
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  AddCallback                                              */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  adding callbacks in: load-box, save-box                  */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  button_proc                                              */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
void AddCallback (int num)
{
  if (widget_array[num] != NULL)
  {
    XtAddCallback (widget_array[num], XmNvalueChangedCallback, 
		   (XtCallbackProc)ToggleCB,(caddr_t) num);
  }
  else
  {
    sperror("Cannot add callback !");
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  ToggleCB                                                 */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  manages callbacks in several subwindows                  */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  callbacks in : load-box, save-box                        */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void ToggleCB (Widget w,unsigned long type,
               XmToggleButtonCallbackStruct *call_data)
{
  layer p;
  Arg args[1];

  if (call_data->set == True)
  {
    FirstEntry (layer_list);
    while (GetListState (layer_list) == E_OK)
    {
      p = (layer) GetEntry (layer_list);
      switch(type)
      {
        /* if 'save all' or 'save all visible' is selected, */
        /* then switch radio buttons for layers off         */
        case v_save_box_all_button:
        case v_save_box_all_visible_button:
          if ( p->layer_state & LS_SAVE )
          {
            p->layer_state = p->layer_state ^ LS_SAVE;
            XtSetArg (args[0], XmNset, False);
            XtSetValues (p->save_layer_button, args, 1);
          }
          break;

        /* if 'load layered sketch' is selected,    */
        /* then switch radio buttons for layers off */
        case v_load_box_all_button:
          if ( p->layer_state & LS_LOAD )
          {
            p->layer_state = p->layer_state ^ LS_LOAD;
            XtSetArg (args[0], XmNset, False);
            XtSetValues (p->load_layer_button, args, 1);
          }
          break;
      }
      NextEntry (layer_list);
    }
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  ButtonCB                                                 */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  writing status of buttons in layer list                  */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  --                                                       */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void ButtonCB (Widget w,unsigned long client_data,
               XmToggleButtonCallbackStruct *call_data)
{
  unsigned long type;
  layer    p, old_active_layer;
  Arg      args[1];

  old_active_layer = active_layer;
  type = client_data;
  FirstEntry (layer_list);

  switch (type)
  {
    case LS_VISIBLE :
      while (GetListState (layer_list) == E_OK)
      {
        p = (layer) GetEntry (layer_list);

        if (p->visible_layer_button == w)
        {
          if (call_data->set == True)
            p->layer_state = p->layer_state | LS_VISIBLE;
          else
            p->layer_state = p->layer_state ^ LS_VISIBLE;
        }
        NextEntry (layer_list);
      }
      RedrawAll (WholeDrawingArea);
      break;

    case LS_ACTIVE :
      while (GetListState (layer_list) == E_OK)
      {
        p = (layer) GetEntry (layer_list);

        if (p->active_layer_button == w)
        {
          if (call_data->set == True)
          {
            active_layer = p;
            p->layer_state = p->layer_state | LS_ACTIVE;

            if (p->layer_state & LS_VISIBLE)
            {
            }
            else
            {
              p->layer_state = p->layer_state | LS_VISIBLE;
              XtSetArg (args[0], XmNset, True);
              XtSetValues (p->visible_layer_button, args, 1);
              RedrawAll (WholeDrawingArea);
            }
          }
          else
          {
            p->layer_state = p->layer_state ^ LS_ACTIVE;
          }
        }
        NextEntry (layer_list);
      }
      DeselectAll (old_active_layer->layer_objects);
      break;

    case LS_LOAD :
      while (GetListState (layer_list) == E_OK)
      {
        p = (layer) GetEntry (layer_list);

        if (p->load_layer_button == w)
        {
          if (call_data->set == True)
          {
            p->layer_state = p->layer_state | LS_LOAD;
            /* switch 'load layered sketch' button off */
            XtSetArg (args[0], XmNset, False);
            XtSetValues (widget_array[v_load_box_all_button], args, 1);
          }
          else
            p->layer_state = p->layer_state ^ LS_LOAD;
        }
        NextEntry (layer_list);
      }
      break;

    case LS_SAVE :
      while (GetListState (layer_list) == E_OK)
      {
        p = (layer) GetEntry (layer_list);

        if (p->save_layer_button == w)
        {
          if (call_data->set == True)
          {
            p->layer_state = p->layer_state | LS_SAVE;
            /* switch 'save all' and 'save all visible' buttons off */
            XtSetArg (args[0], XmNset, False);
            XtSetValues (widget_array[v_save_box_all_button], args, 1);
            XtSetArg (args[0], XmNset, False);
            XtSetValues (widget_array[v_save_box_all_visible_button], args, 1);
          }
          else
            p->layer_state = p->layer_state ^ LS_SAVE;
        }
        NextEntry (layer_list);
      }
      break;

/*    case LS_CLEAR :
      while (GetListState (layer_list) == E_OK)
      {
        p = (layer) GetEntry (layer_list);

        if (p->clear_layer_button == w)
        {
          if (call_data->set == True)
          {
            p->layer_state = p->layer_state | LS_CLEAR;
          }
          else
            p->layer_state = p->layer_state ^ LS_CLEAR;
        }
        NextEntry (layer_list);
      }
      break;
*/
    case LS_PRINT :
      while (GetListState (layer_list) == E_OK)
      {
        p = (layer) GetEntry (layer_list);

        if (p->print_layer_button == w)
        {
          if (call_data->set == True)
          {
            p->layer_state = p->layer_state | LS_PRINT;
          }
          else
            p->layer_state = p->layer_state ^ LS_PRINT;
        }
        NextEntry (layer_list);
      }
      break;


    default :
    {
      char text[80];
      sprintf(text, "ButtonCB: got type %d,", type);
      sperror(text);
      sperror("don't know why or what to do with this!");
    }
  }
}

/* GetFirstLayer: */

layer GetFirstLayer (void)
{
  FirstEntry (layer_list);
  return GetEntry (layer_list);
}

/* GetNextLayer: */

layer GetNextLayer (void)
{
  NextEntry (layer_list);
  return GetEntry (layer_list);
}

/* GetLayerState: */

int GetLayerState (layer lay)
{
  if (lay != NULL)
  {
    return lay->layer_state;
  }
  else
  {
    return -1;
  }
}

/* SetLayerState: */

void SetLayerState (layer lay, int state)
{
  if (lay != NULL)
  {
    lay->layer_state = state;
  }
}

/* GetLayer: */

layer GetLayer (int layer_id, int sketch_id)
{
  layer p;

  FirstEntry (layer_list);
  p = GetEntry (layer_list);
  while (p != NULL)
  {
    if ((p->layer_id == layer_id) && (p->sketch_id == sketch_id))
    {
      return p;
    }
    NextEntry (layer_list);
    p = GetEntry (layer_list);
  }
  return NULL;
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  ClearLayer                                               */
/*                                                                            */
/*      Version   :  14.05.1991                                               */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  Clear the specified Layer                                */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  Main Program of Sketchpad                                */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
int ClearLayer (int layer_id, int sketch_id)

{
  void            *obj;
  struct_storage  ss;
  void            *listpos;

  listpos = GetListPosition(layer_list);

  ss = GetStructStorage (GetLayer (layer_id, sketch_id));

  obj = GetFirstObj(ss);
  while (obj != NULL)
  {
    DeleteObject(ss, obj);
    obj = GetFirstObj(ss);
  }
  SetListPosition(layer_list, listpos);
  return(1);
} /* ClearLayer */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  GetLayerFromNo                                           */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  Get the layer from the layer's number in a list          */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  pic_io_proc                                              */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
layer GetLayerFromNo (int num)
{
  layer p;

  FirstEntry(layer_list);
  while(num-- > 1)
  {
    NextEntry(layer_list);
  }  

  if (GetListState (layer_list) == E_OK)
  {
    p = GetEntry (layer_list);
  }
  else
  {
    p = NULL;
  }

  return p;
}


/* GetLayerId: */

void GetLayerId (layer lay, int *layer_id, int *sketch_id)
{
  if (lay)
  {
    *layer_id = lay->layer_id;
    *sketch_id = lay->sketch_id;
  }
  else
  {
    *layer_id = 0;
    *sketch_id = 0;
  }
}


/* GetLayerCharName: */

char *GetLayerCharName (layer lay)
{
  return lay->layer_name;
}


/* GetLayerColor: */

unsigned long GetLayerColor (layer lay)
{
  return lay->color;
}


/* GetEditColor: */
unsigned long int GetEditColor (Widget w)
{
  layer p;
  unsigned long int edit_color;

  FirstEntry (layer_list);
  while (GetListState (layer_list) == E_OK)
  {
    p = (layer) GetEntry (layer_list);
    if (p->color_layer_button == w)
    {
      edit_color = p->color;
    }
    NextEntry (layer_list);
  }
  return (edit_color);
}



/* SetLayerColor */

Boolean SetLayerColor (layer lay, XColor new_color)
{
  if (&new_color == NULL)
  {
    sperror("SetLayerColor: got a NULL-pointer as new_color,");
    sperror(" can't set the layer color, take no action!");
    return False;
  }
  else
  {
    if (lay->color == BlackPixelOfScreen (DrawScreen))
    {
      sperror("SetLayerColor: can't set layer color,");
      sperror(" it's the BlackPixelOfScreen. No action taken!");
      return False;
    }
    else
    {
      new_color.pixel = lay->color;
      XStoreColor (DrawDisplay, DrawCmap, &new_color);
      return True;
    }
  }
}


static void actual_layer_color_list_free_func (void *list_entry)
{
  free (list_entry);
}


Boolean SaveLayerColors ()
{
  layer          p;
  layer_color    c;
  XColor         old_layer_color;

  if (actual_layer_color_list == NULL)
  {
    actual_layer_color_list = CreateList ();
    SetFreeFunction (actual_layer_color_list,
                     actual_layer_color_list_free_func);

    FirstEntry (layer_list);
    while (GetListState (layer_list) == E_OK)
    {
      p = GetEntry (layer_list);

      if (!(p->layer_id==1) && (p->sketch_id==0))   /* save all layer colors   */
                                                    /* except background color */
      {
        c = (layer_color) malloc (sizeof (struct layer_color_s));
        if (c == NULL)
        {
          sperror("SaveLayerColors:");
          sperror(" not enough memory, layer colors not saved.");
          FreeList (actual_layer_color_list);
          actual_layer_color_list = NULL;
          return False;
        }
        else
        {
          /* get the color values */
          old_layer_color.pixel = p->color;
          XQueryColor (DrawDisplay, DrawCmap, &old_layer_color);

          /* save color of this layer in list */
          c->layer_id    = p->layer_id;
          c->sketch_id   = p->sketch_id;
          c->color.red   = old_layer_color.red;
          c->color.green = old_layer_color.green;
          c->color.blue  = old_layer_color.blue;
          c->color.pixel = p->color;
          InsertEndEntry (actual_layer_color_list, c);

          /* set color of this layer to black */
          if (p->color != BlackPixelOfScreen (DrawScreen))
          {
            XStoreNamedColor (DrawDisplay, DrawCmap, "black",
                              p->color, (DoRed|DoGreen|DoBlue));
          }
        }
      }
      NextEntry (layer_list);
    }
    return True;
  }
  else /* LayerColors already saved */
  {
    sperror("SaveLayerColors:");
    sperror(" LayerColors already saved, not saved a second time.");
    return False;
  }
}


Boolean RestoreLayerColors ()
{
  layer_color c;
  XColor      new_layer_color;

  if (actual_layer_color_list == NULL)
  {
    sperror("RestoreLayerColors:");
    sperror(" no actual_layer_color_list, can't restore layer colors.");
    return False;
  }

  new_layer_color.flags = (DoRed|DoGreen|DoBlue);

  FirstEntry (actual_layer_color_list);
  while (GetListState (actual_layer_color_list) == E_OK)
  {
    c = GetEntry (actual_layer_color_list);

    /* store this color for the layer */
    new_layer_color.red   = c->color.red;
    new_layer_color.green = c->color.green;
    new_layer_color.blue  = c->color.blue;
    new_layer_color.pixel = c->color.pixel;
    if (new_layer_color.pixel != BlackPixelOfScreen (DrawScreen))
    {
      XStoreColor (DrawDisplay, DrawCmap, &new_layer_color);
    }
    NextEntry (actual_layer_color_list);
  }
  FreeList (actual_layer_color_list);
  actual_layer_color_list = NULL;

  return True;
}


/* DrawLayer: */

void DrawLayer (layer lay, XRectangle rec)
{
  set_draw_color (ForeignGC, GetLayerColor (lay));
  set_draw_color (DrawGCtext, GetLayerColor (lay));
  DrawStructure (GetStructStorage (lay), rec);
}


/* GetCurrentLayer */

void *GetCurrentLayer()
{
  return GetListPosition(layer_list);
}


/* SetCurrentLayer */

void SetCurrentLayer(void *position)
{
  SetListPosition(layer_list, position);
}




/* __BUGS__ (by HK) */
/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  get_layer_list_position                                  */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  Get's the positionnumber in the layer-list of that       */
/*                   layer, which's color is edited in the color-edit-box,    */
/*                   by the widget-pointer of the color-button in the         */
/*                   color-status-box.  (HK)                                  */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  color_edit                                               */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
int get_layer_list_position (Widget w)
{
   layer lay;
   int   lauf=0;

  FirstEntry (layer_list);
  while (GetListState (layer_list) == E_OK)
  {
    lay = (layer) GetEntry (layer_list);
    if (lay->color_layer_button == w)
    {
      return (lauf);
    }
    lauf++;
    NextEntry (layer_list);
  }
  return (-1);
}

void GetLayerVisibility(unsigned char *layVisibility)
{
  layer p;
  int   i;

  i = 0;
  FirstEntry (layer_list);
  while (GetListState (layer_list) == E_OK)
  {
    p = (layer) GetEntry (layer_list);
    layVisibility[i] = (p->layer_state & LS_VISIBLE);
    NextEntry(layer_list);
    i++;
  }
}

void SetLayerVisibility(unsigned char *layVisibility)
{
  layer p;
  int   i;
  Arg   args[2];

  i = 0;
  FirstEntry (layer_list);
  while (GetListState (layer_list) == E_OK)
  {
    p = (layer) GetEntry (layer_list);
    if (layVisibility[i])
    {
      p->layer_state |= LS_VISIBLE;
      XtSetArg (args[0], XmNset, True);
    }
    else
    {
      p->layer_state &= ~LS_VISIBLE;
      XtSetArg (args[0], XmNset, False);
    }
    if (p->visible_layer_button)
       XtSetValues (p->visible_layer_button, args, 1);
    NextEntry(layer_list);
    i++;
  }
  RedrawAll (WholeDrawingArea);
}

