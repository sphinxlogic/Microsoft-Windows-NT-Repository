/* ========================================================================== */
/*                                                                            */
/* Filename:     color.c                          +-----+-----+--+--+--+--+   */
/* Version :     1.6	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 1/4/93	15:26:55	                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*                                                                            */
/*      Module    : module for color editing function in layers status box    */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*                                                                            */
/*  Forward declarations of includes, variables and constants                 */
/*                                                                            */
/* ========================================================================== */

#include <Xm/Scale.h>

#include <stdio.h>
#include <string.h>
#include "../misc/sperror.h"
#include "../misc/list.h"
#include "../misc/ographic.h"
#include "../draw/drawstate.h"
#include "sketchpad.h"
#include "defs.h"
#include "layer.h"

#define UNDEFINED  0

static unsigned long int edit_color = 0L;
static int rx, gx, bx;
       int    edicol_layerNo;
       XColor new_color;

/* ========================================================================== */
/*                                                                            */
/*      Fnctnames :  minimum                                                  */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  return the minimum of three float numbers                */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  RGB_to_HSV                                               */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
float minimum (float a, float b, float c)
{
  float min;
  
  min = a;
  min = (b < min) ? b : min;
  min = (c < min) ? c : min;
  return (min);
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  maximum                                                  */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  return the maximum of three float numbers                */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  RGB_to_HSV                                               */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
float maximum (float a, float b, float c)
{
  float max;

  max = a;
  max = (b > max) ? b : max;
  max = (c > max) ? c : max;
  return (max);
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  RGB_to_HSV                                               */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  converts RGB to HSV value                                */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  color_edit, set_label_color                              */
/*                                                                            */
/*      Calls     :  maximum, minimum                                         */
/*                                                                            */
/* ========================================================================== */
void RGB_to_HSV (float r, float g, float b, float *h, float *s, float *v)
{
  float max, min;
  float delta;

  max = maximum(r, g, b);
  min = minimum(r, g, b);
  *v = max;

  if (max != 0)
  {
    *s = (max - min)/max;
  }
  else
  {
    *s = 0;
  }
  if (*s == 0)
  {
    *h = UNDEFINED;
  }
  else
  {
    delta = max - min;
    if (r == max)
    {
      *h = (g - b)/delta;
    }
    else if (g == max)
    {
      *h = 2 + (b - r)/delta;
    }
    else if (b == max)
    {
      *h = 4 + (r - g)/delta;
    }
    *h = *h * 60;
    if (*h < 0)
    {
      *h = *h + 360;
    }
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  HSV_to_RGB                                               */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  converts HSV to RGB color                                */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  color_edit                                               */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
void HSV_to_RGB (float *r, float *g, float *b, float h, float s, float v)
{
  int   i;
  float f, p, q, t;

  if (s == 0)
  {
    if (h == UNDEFINED)
    {
      *r = v;
      *g = v;
      *b = v;
    }
    else
    {
      /* -fs
        fprintf(stderr, "HSV_to_RGB ERRROR !!\n");
      */
      *r = v;
      *g = v;
      *b = v;
    }
  }
  else
  {
    if (h == 360)
    {
      h = 0;
    }
    h = h / 60;
    i = (int) h;
    f = h - i;
    p = v * (1 - s);
    q = v * (1 - (s * f));
    t = v * (1 - (s * (1 - f)));

    switch (i)
    {
      case 0:
        *r = v;
        *g = t;
        *b = p;
        break;

      case 1:
        *r = q;
        *g = v;
        *b = p;
        break;

      case 2:
        *r = p;
        *g = v;
        *b = t;
        break;
 
      case 3:
        *r = p;
        *g = q;
        *b = v;
        break;

      case 4:
        *r = t;
        *g = p;
        *b = v;
        break;

      case 5:
        *r = v;
        *g = p;
        *b = q;
        break;
    } 
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  set_RGB                                                  */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  sets RGB sliders (float parameters)                      */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  color_edit                                               */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
void set_RGB (float r, float g, float b)
{
  int i;

  i = (int)(r * 65535);
  XmScaleSetValue (widget_array[v_color_box_scale_red], i);
  i = (int)(g * 65535);
  XmScaleSetValue (widget_array[v_color_box_scale_green], i);
  i = (int)(b * 65535);
  XmScaleSetValue (widget_array[v_color_box_scale_blue], i);
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  set_int_RGB                                              */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  sets RGB sliders (int parameters)                        */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  set_label_color                                          */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
void set_int_RGB (int r, int g, int b)
{
  XmScaleSetValue (widget_array[v_color_box_scale_red], r);
  XmScaleSetValue (widget_array[v_color_box_scale_green], g);
  XmScaleSetValue (widget_array[v_color_box_scale_blue], b);
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  get_RGB                                                  */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  gets RGB slider values                                   */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  color_edit, set_label_color                              */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
void get_RGB (float *r, float *g, float *b)
{
  int i;

  XmScaleGetValue (widget_array[v_color_box_scale_red], &i);
  *r=((float)i)/65535;
  XmScaleGetValue (widget_array[v_color_box_scale_green], &i);
  *g=((float)i)/65535;
  XmScaleGetValue (widget_array[v_color_box_scale_blue], &i);
  *b=((float)i)/65535;
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  get_int_RGB                                              */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  gets RGB slider values as integer                        */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  color_edit                                               */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
void get_int_RGB (int *r, int *g, int *b)
{
  int i;

  XmScaleGetValue (widget_array[v_color_box_scale_red], &i);
  *r=i;
  XmScaleGetValue (widget_array[v_color_box_scale_green], &i);
  *g=i;
  XmScaleGetValue (widget_array[v_color_box_scale_blue], &i);
  *b=i;
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  set_HSV                                                  */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  sets HSV sliders                                         */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  color_edit, set_label_color                              */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
void set_HSV (float h, float s, float v)
{
  int i;

  i = (int)h;
  XmScaleSetValue (widget_array[v_color_box_scale_hue], i);
  i = (int)(s * 1000);
  XmScaleSetValue (widget_array[v_color_box_scale_sat], i);
  i = (int)(v * 1000);
  XmScaleSetValue (widget_array[v_color_box_scale_val], i);
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  get_HSV                                                  */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  gets HSV slider values (float parameters)                */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  color_edit                                               */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
void get_HSV (float *h, float *s, float *v)
{
  int i;

  XmScaleGetValue (widget_array[v_color_box_scale_hue], &i);
  *h=(float)i;
  XmScaleGetValue (widget_array[v_color_box_scale_sat], &i);
  *s=((float)i)/1000;
  XmScaleGetValue (widget_array[v_color_box_scale_val], &i);
  *v=((float)i)/1000;
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  set_label_color                                          */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  sets label in color edit box                             */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  color_edit                                               */
/*                                                                            */
/*      Calls     :  set_int_RGB, get_RGB, RGB_to_HSV, set_HSV                */
/*                                                                            */
/* ========================================================================== */
void set_label_color (unsigned long int col)
{
  Arg args[1];
  XColor farbe;
  int rr, gg, bb;
  float r, g, b, h, s, v;
 
  r = 0;
  g = 0;
  b = 0;
  h = 0;
  s = 0;
  v = 0;
  XtSetArg (args[0], XmNbackground, col);
  XtSetValues (widget_array[v_color_box_color_label], args, 1);
  farbe.pixel = col;
  XQueryColor (DrawDisplay, DrawCmap, &farbe);
  rr = farbe.red;
  gg = farbe.green;
  bb = farbe.blue;
  set_int_RGB(rr, gg, bb);
  get_RGB (&r, &g, &b);
  RGB_to_HSV(r, g, b, &h, &s, &v);
  set_HSV(h, s, v);
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  color_edit                                               */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  edit colors of the layers                                */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  color_proc                                               */
/*                                                                            */
/*      Calls     :  get_RGB, RGB_to_HSV, set_HSV, get_int_RGB, HSV_to_RGB    */
/*                   get_HSV, set_RGB, set_label_color,                       */
/*                   layer.c: get_layer_list_position                         */
/*                                                                            */
/* ========================================================================== */
void color_edit (Widget w, int *tag)
{
  int rr, gg, bb;
  float r, g, b;
  float h, s, v;

  switch (*tag)
  {
    /* RGB sliders have been moved */
    case v_color_box_scale_red:
    case v_color_box_scale_green:
    case v_color_box_scale_blue:

      new_color.pixel = edit_color;
      XQueryColor (DrawDisplay, DrawCmap, &new_color);
      get_RGB (&r, &g, &b);
      RGB_to_HSV(r, g, b, &h, &s, &v);
      set_HSV (h, s, v);
      get_int_RGB (&rr, &gg, &bb);
      new_color.red   = rr;
      new_color.green = gg;
      new_color.blue  = bb;

      /* check wether the pixel is BlackPixelOfScreen */
      /* we can't write into BlackPixelOfScreen ! */
      if (new_color.pixel != BlackPixelOfScreen (DrawScreen))
      {
        XStoreColor (DrawDisplay, DrawCmap, &new_color);
      }
      else
      {
        sperror("sorry, you can't change that layer color!");
      }
      break;

    /* HSV sliders have been moved */
    case v_color_box_scale_hue:
    case v_color_box_scale_sat:
    case v_color_box_scale_val:

      new_color.pixel = edit_color;
      XQueryColor (DrawDisplay, DrawCmap, &new_color);
      get_HSV (&h, &s, &v);
      HSV_to_RGB (&r, &g, &b, h, s, v);
      set_RGB (r, g, b);
      get_int_RGB (&rr, &gg, &bb);
      new_color.red   = rr;
      new_color.green = gg;
      new_color.blue  = bb;

      /* check wether the pixel is BlackPixelOfScreen */
      /* we can't write into BlackPixelOfScreen ! */
      if (edit_color != BlackPixelOfScreen (DrawScreen))
      {
        XStoreColor (DrawDisplay, DrawCmap, &new_color);
      }
      else
      {
        sperror("sorry, you can't change that layer color!");
      }
      break;

    /* search color of layer, which is to be edited */
    case v_push_button:
    case v_attributes_selectcolor_button:
      if (*tag == v_push_button) {
         edit_color = GetEditColor(w);
      }
      else {
         unsigned long mask;
         XGCValues values;

         XGetGCValues(DrawDisplay, DrawGCWhite, GCForeground, &values);
         edit_color = values.foreground;
      }

      /* save the old color for 'cancel box' */
      new_color.pixel = edit_color;
      XQueryColor (DrawDisplay, DrawCmap, &new_color);
      rx = new_color.red;
      gx = new_color.green;
      bx = new_color.blue;
      edicol_layerNo = (get_layer_list_position (w) +1);
      break;

    /* set the color for label in color-box */
    case v_color_box_color_label:
      set_label_color(edit_color);
      break;

    /* get back old layer color */
    case v_color_box_cancel_button:
      /* if it's BlackPixelOfScreen then no action is required */
      if (edit_color != BlackPixelOfScreen (DrawScreen))
      {
        new_color.pixel = edit_color;
        XQueryColor (DrawDisplay, DrawCmap, &new_color);
        new_color.red   = rx;
        new_color.green = gx;
        new_color.blue  = bx;
        XStoreColor (DrawDisplay, DrawCmap, &new_color);
      }
      break;

    default:
      break;
  }
}

