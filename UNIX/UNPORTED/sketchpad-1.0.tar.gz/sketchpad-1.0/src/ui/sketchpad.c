/* ========================================================================== */
/*                                                                            */
/* Filename:     sketchpad.c                      +-----+-----+--+--+--+--+   */
/* Version :     1.3	                          !     !     !  !  !  !  !   */
/*                                                !     !     +--+--+--+--+   */
/* Author:       Fraunhofer Institiut             !     !     !  !  !  !  !   */
/*               Graphische Datenverarbeitung     +-----+-----+--+--+--+--+   */
/*               (FhG-IGD)                        !     !     !  !  !  !  !   */
/*               Abteilung 9: Methoden zur        !     !     +--+--+--+--+   */
/*               Gruppenarbeit, Wilhelminenstr.7, !     !     !  !  !  !  !   */
/*               D-6100 Darmstadt, West-Germany   +-----+-----+--+--+--+--+   */
/*                                                ! FFFFFF hh !     GGGG  !   */
/* Rights:       Copyright (c) 1992 by FhG-IGD.   ! FFFFFF hh !    GGGGGG !   */
/*               All rights reserved.             ! FFF    hh h    GG     !   */
/*               FhG-IGD provides this product    ! FFFFF  hhhhhh  GG GG  !   */
/*               without warranty of any kind     ! FFFFF  hhh!hhh GG  GG !   */
/*               and shall not be liable for      ! FFF    hh ! hh GGGGGG !   */
/*               any damages caused by the use    ! FFF    hh ! hh  GGGG  !   */
/*               of this product.                 +-----------+-----------+   */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/*                       Public Domain SketchPad                              */
/*                      -------------------------                             */
/*                                                                            */
/*      Last Modification    : 12/8/92	11:43:00	                      */
/*                                                                            */
/* ========================================================================== */

/* ========================================================================== */
/*      DEFINE  STATEMENTS                                                    */
/* ========================================================================== */

/* ========================================================================== */
/*      INCLUDE STATEMENTS                                                    */
/* ========================================================================== */

#include <stdio.h>
#include <sys/types.h>
#include <signal.h>
/* HC
#include <stdlib.h>
*/
#include <Mrm/MrmAppl.h>                    /* Motif Toolkit */
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include <Xm/ToggleB.h>
#include <Xm/PushB.h>
#include <Xm/Text.h>
#include <Xm/FileSB.h>
#include <Xm/Scale.h>
#include <Xm/List.h>

#include "../image/print.h"

#include "../misc/ographic.h"
#include "../misc/sperror.h"
#include "../kernel/user.h"
#include "../kernel/message.h"
#include "../draw/drawstate.h"
#include "../draw/setdraw.h"
#include "../draw/draw.h"
#include "../draw/dtext.h"
#include "../image/picio.h"
#include "../image/io.h"
#include "../global/userdata.h"
#include "../image/grab.h"
#include "layer.h"
#include "color.h"
#include "defs.h"

/* ========================================================================== */
/*      GLOBAL VARIABLES                                                      */
/* ========================================================================== */

Widget          toplevel_widget;          /* Root widget ID of application    */
XtAppContext    app_context;              /* The Application Context          */
long int        isc_device;               /* socket of communication          */
extern long int channel;                  /* channel number of ISC from user.c*/
XtInputId       input_id;                 /* id of input callback             */
 
/*
 * The ISC Interface needs a window id as address for sending events,
 * so main_window_widget cannot be static! (changed MS 25.4.91)
 */

Widget main_window_widget;                /* Root widget ID of main           */
                                          /* MRM fetch                        */
 
Widget widget_array [v_max_widget + 1];   /* Place to keep all other          */
                                          /* widget IDs                       */

static int pos = 1;                       /* Selected Layer in scrolled list  */

static char *name[v_max_widget];

MrmHierarchy    s_MrmHierarchy;            /* MRM database hierarch ID        */
MrmType         dummy_class;               /* and class variable              */

static char     *db_filename_vec[] =
       {"sketchpad.uid"};                  /* MRM database file list          */

static int db_filename_num =              
       (sizeof db_filename_vec / sizeof db_filename_vec[0]);

XmStringCharSet charset = (XmStringCharSet) XmSTRING_DEFAULT_CHARSET;
                                           /* used to set up XmStrings        */

Colormap cmap = 0;

int layer_state;

char picFilename[256];

static char PictureToLoad[256];

XRectangle ptr_bbox [MAXUSERS];       /* Bounding Box of whole pointer        */
Boolean    my_pointer_visible =FALSE; /* Flag: TRUE if a pointer has been sent*/
                                      /*       to other users and is still    */
                                      /*       visible there. This pointer has*/
                                      /*       to be removed before drawing a */
                                      /*       new one!                       */
Boolean    pointer_visible[MAXUSERS]; /* Flags:TRUE if a pointer from user nr.*/
                                      /*       x is visible                   */

XRectangle WholeDrawingArea = {0,0,10000,10000};

long int       eventpid;              /* process id of event handler          */
char           displayname[80];       /* name of X server to connect          */
extern void receive_message (void);
extern XColor new_color; 
extern int edicol_layerNo;
extern void msg_lay_col_changed( int, XColor*);
extern long int ISCgetdevice (long int channel);


static Boolean end_sketch = 0;     /* flag whether SketchPad is quitted by */
                                      /*                    Conference module */
static void edit_text_proc(Widget, int *, unsigned long *);
/*============================================================================*/
/*   functions used by the callback-functions                                 */
/*============================================================================*/

/*============================================================================*/
/*   callback-funktions, called only by the Motif-Toolkit                     */
/*============================================================================*/

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  quit_proc                                                */
/*                                                                            */
/*      Version   :  2 (MGS changes, 02.12.1991)                              */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  exit procecure of the whole application                  */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  the XmNActivateCallback of the file_quit_button          */
/*                   and by receive_message function if the SketchPad         */
/*                   instance is stopped by the conference management.        */
/*                                                                            */
/*      Calls     :  free_draw_proc()                                         */
/*                                                                            */
/* ========================================================================== */

void quit_proc(Widget w, int *tag, unsigned long *reason)

{
  struct_storage ss;
  layer lay;

  /* falls der eigene Pointer bei den anderen noch sichtbar ist, */
  /* muss er beendet werden */
  if (my_pointer_visible)
  {
    msg_end_pointer ();
  }

  /* dem Master eine Nachricht schicken */
  msg_quit ();

  /* close all outstanding connections */
  Exit_Communication ();

  /* free user database */
  DeInitUserdata ();

  /* free resources */
  free_draw_proc();

  /* Objekt-Speicher freigeben */
  lay = GetFirstLayer ();
  while (lay != NULL)
  {
    ss = GetStructStorage (lay);
    FreeSS (ss);
    lay = GetNextLayer ();
  }

  exit(1);
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  external_quit_proc                                       */
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  exit the SketchPad by conference                         */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  several Callbacks of quit_box                            */
/*                                                                            */
/*      Calls     :  quit_proc                                                */
/*                                                                            */
/* ========================================================================== */
static void external_quit_proc(Widget w, int *tag, unsigned long *reason)
{
  switch(*tag)
  {
    /* SketchPad is to be ended by Conference module */
    case v_quit_box_save_button:
      end_sketch = True;
      break;

    /* End the SketchPad without save */
    case v_save_box:
      if (end_sketch == True)
      {
        quit_proc((Widget)NULL, (int *)v_save_box, (unsigned long *)NULL);
      }
      break;
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  grab_proc                                                */
/*                                                                            */
/*      Version   :  27.02.1992                                               */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  callback procedure for grabbing window image             */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  the XmNActivateCallback of the file_grab_button          */
/*                                                                            */
/*      Calls     :  GrabWindow()                                             */
/*                                                                            */
/* ========================================================================== */
static void grab_proc(Widget w, int *tag, unsigned long *reason)
{
  char temp_file[10];
  char path[256];

  strcpy(temp_file, "temp.grab");
  switch(*tag)
  {
    /* User wants to grab a window image */
    case v_file_grab_button:
      strcpy(path, PicPath);
      strcat(path, temp_file);
      GrabWindow(theDisplay, theScreen, True, path);
      LoadRasterImage(temp_file);
      SendRasterFile(temp_file, TO_ALL);
      /* remove(path); */
      break;
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  slideshow_proc                                           */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  handles callbacks of the slide show box                  */
/*                                                                            */
/*      Accesses  :  widget_array, the subwindow we have to manage.           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void slideshow_proc(Widget w, int *tag, unsigned long *reason)
{
         char      script_file[14];
  static char      path[256];
  static int       entrycount, i;
  static int       actual_slide  = -1;
  static char    **slidenames = NULL;
         char      imagestring[256];
         char     *tempp;
         FILE     *fp;
         XmString  xms;

  strcpy(script_file,"slideshow.scr");  
  switch(*tag)
  {
    case v_slideshow_file_text:
      /* set entry in file window to default value */
      if (path[0] == '\0')
      {
        strcpy(path, PicPath);
        strcat(path, script_file);
      }
      XmTextSetString(widget_array[v_slideshow_file_text], path);
      break;

    case v_slideshow_file_button:
      /* free all current list items */
      XmListDeleteAllItems(widget_array[v_slideshow_text]);
      if (slidenames != NULL)
      {
        for (i = 0; i < entrycount; i++) free(slidenames[i]);
        free(slidenames);
        slidenames = NULL;
        entrycount = 0;
        actual_slide = -1;
      }

      /* load contents of script file into scrolled window */
      strcpy(path, XmTextGetString (widget_array[v_slideshow_file_text]));
      fp = fopen(path, "r");
      if (fp == NULL)
      {
        sperror("Slideshow: cannot open script file");
        return;
      }
      entrycount = 0;
      while(fgets(imagestring, 256, fp) != NULL)
      {
        imagestring[strlen(imagestring)-1] = '\0';
        if ((tempp = strrchr(imagestring, '/')) != NULL)
          tempp++;
        else
          tempp = imagestring;
        xms = XmStringCreateLtoR(tempp, XmSTRING_DEFAULT_CHARSET);
        XmListAddItem (widget_array[v_slideshow_text], xms, 0);
        entrycount++;
      }
      if (entrycount == 0)
      {
        sperror ("SlideShow: no slides in script file");
        return;
      }
      fseek(fp, 0L, SEEK_SET);
      slidenames = (char **)malloc(entrycount * sizeof(char *));
      for (i = 0; i < entrycount; i++)
      {
        slidenames[i] = (char *) malloc (256 * sizeof(char));
        fgets(slidenames[i], 256, fp);
        slidenames[i][strlen(slidenames[i])-1] = '\0';
      }
      fclose(fp);
      break;

    case v_slideshow_text_create:
      for (i = 0; i < entrycount; i++)
      {
        if ((tempp = strrchr(slidenames[i], '/')) != NULL)
          tempp++;
        else
          tempp = slidenames[i];
        xms = XmStringCreateLtoR(tempp, XmSTRING_DEFAULT_CHARSET);
        XmListAddItem (widget_array[v_slideshow_text], xms, 0);
      }
      XmListSelectPos(widget_array[v_slideshow_text], actual_slide + 1, False);
      XmListSetBottomPos(widget_array[v_slideshow_text], actual_slide + 1);
      break;

    case v_slideshow_text_select:
      /* store selected item */
      actual_slide = (((XmListCallbackStruct *)reason)->item_position) - 1;
      Load(slidenames[actual_slide], SLIDE_BOX);
      break;

    case v_slideshow_next_button:
      /* load next slide */
      if (slidenames != NULL)
      {
        actual_slide = ((actual_slide + 1) % entrycount);
        XmListSelectPos(widget_array[v_slideshow_text], actual_slide+1, False);
        XmListSetBottomPos(widget_array[v_slideshow_text], actual_slide+1);
        Load(slidenames[actual_slide], SLIDE_BOX);
      }
      else
      {
        sperror("Slideshow: no slides to load.");
        return;
      }
      break;

    case v_slideshow_prev_button:
      /* load previous slide */
      if(slidenames != NULL)
      {
        if (actual_slide == -1) actual_slide = 0;
        else actual_slide = ((actual_slide + entrycount - 1) % entrycount);
        XmListSelectPos(widget_array[v_slideshow_text], actual_slide+1, False);
        XmListSetBottomPos(widget_array[v_slideshow_text], actual_slide+1);
        Load(slidenames[actual_slide], SLIDE_BOX);
      }
      else
      {
        sperror("Slideshow: no slides to load.");
        return;
      }
      break;

    case v_slideshow_close_button:
      /* close slideshow window */
      break;
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  create_object_proc                                       */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  all menu buttons that have to manage subwindows call back*/
/*                   to this routine. We manage the right subwindows for them.*/
/*                                                                            */
/*      Accesses  :  widget_array, the subwindow we have to manage.           */
/*                                                                            */
/*      Called by :  the XmNcascadingCallbacks of the leave menu buttons.     */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void create_object_proc (Widget widget, int *tag, unsigned long *reason)
{
  int num = *tag;
  Arg       args[1];
  char      dir[255];
  XmString  xms;

  if (widget_array[num] == NULL)
  {
    if (MrmFetchWidget(s_MrmHierarchy,
        name[num], 
        toplevel_widget,
        &widget_array[num], 
        &dummy_class) != MrmSUCCESS)
    {
      sperror("can`t fetch Box !");
    }
  }

  if (num == v_zoom_box) return;

  XtManageChild(widget_array[num]);
  switch (num)
  {
    case v_load_box:
      strcpy(dir, PicPath);
      dir[strlen(PicPath) - 1] = 0;
      xms = XmStringCreateLtoR(dir, XmSTRING_DEFAULT_CHARSET);
      XtSetArg(args[0], XmNdirectory, xms);
      XtSetValues(widget_array[v_load_box3], args, 1);
      break;

    case v_save_box:
      strcpy(dir, PicPath);
      dir[strlen(PicPath) - 1] = 0;
      xms = XmStringCreateLtoR(dir, XmSTRING_DEFAULT_CHARSET);
      XtSetArg(args[0], XmNdirectory, xms);
      XtSetValues(widget_array[v_save_box3], args, 1);
      break;

    case v_linestyle_box:
      /* set up correct value of LINE_STYLE button */
      switch (get_draw_state (LINE_STYLE))
      {
        case SOLID:
          XtSetArg(args[0], XmNmenuHistory,
                            widget_array[v_linestyle_box_style_solid_button]);
          break;
        case DASHED:
          XtSetArg(args[0], XmNmenuHistory,
                            widget_array[v_linestyle_box_style_dash_button]);
          break;
      }
      XtSetValues(widget_array[v_linestyle_box_style_option], args, 1);

      /* set up correct value of LINE_WIDTH scale */
      XtSetArg(args[0], XmNvalue, get_draw_state (LINE_WIDTH));
      XtSetValues(widget_array[v_linestyle_box_thickness_scale], args, 1);
      break;

    case v_textstyle_box:
      /* set up correct value of TEXT_SIZE scale */
      XtSetArg(args[0], XmNvalue, get_draw_state (TEXT_SIZE));
      XtSetValues(widget_array[v_textstyle_box_size_scale], args, 1);
      break;
  
  } /* switch */
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  destroy_object_proc                                      */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  deletes a menu supporting subwindow that is not needed   */
/*                   any longer.                                              */
/*                                                                            */
/*      Accesses  :  widget_array, the subwindow to be destroyed              */
/*                                                                            */
/*      Called by :  Callbacks of widgets which should be destroyed           */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void destroy_object_proc(Widget widget, int *tag, unsigned long *reason)
{
  int num = *tag;
  Arg args[1];

  if (XtIsManaged(widget_array[num]))
  {
      XtUnmanageChild(widget_array[num]);
      widget_array[num] = NULL;
      XSync(theDisplay, False);
  }

  if (widget_array[v_jpeg_form] != NULL)
  {
    /* remove jpeg form from save box */
    XtSetArg (args[0], XmNbottomAttachment, XmATTACH_FORM);
    XtSetValues (widget_array[v_save_box5], args, 1);
    XtUnmanageChild (widget_array[v_jpeg_form]);
    XtDestroyWidget(widget_array[v_jpeg_form]);
    widget_array[v_jpeg_form] = NULL;
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  create_proc                                              */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  all widgets that are created call back to this procedure.*/
/*                   we just log the ID in the global array.                  */
/*                                                                            */
/*      Accesses  :  widget_array                                             */
/*                                                                            */
/*      Called by :  the XmNCreateCallbacks of all used widgets.              */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void create_proc(Widget w, int *tag, unsigned long *reason)
{
  int widget_num = *tag;

  widget_array[widget_num] = w;
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  set_draw_mode_proc()                                     */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  all paint-radio-buttons that are pushed call back to     */
/*                   this routine. We use the tag to tell us what widget      */
/*                   it is, then react accordingly.                           */
/*                                                                            */
/*      Accesses  :  nyi-widget                                               */
/*                                                                            */
/*      Called by :  the XmNvalueChangedCallbacks of the drawing functions    */
/*                   radio buttons.                                           */
/*                                                                            */
/*      Calls     :  set_draw_mode()                                          */
/*                                                                            */
/* ========================================================================== */
static void set_draw_mode_proc(Widget w, int *tag,
                               XmToggleButtonCallbackStruct *callback_data)
{

/* ========================================================================== */
/*     LOCAL VARIABLES                                                        */
/* ========================================================================== */

  int actual_mode = *tag;

/* ========================================================================== */

/*   fprintf (stderr, "set_draw_mode_proc: testing mode\n"); */
/*   fprintf (stderr, "set_draw_mode_proc: 2D OK\n"); */

  if (callback_data->set)            /* react only to the buttons which
                                        are  SET, not to those being resetted */
  {
    if (actual_mode == v_nyi)
    {
      /* The user activated a 'not yet implemented' push button.  Send
       * the user a message. */
      if (widget_array[v_nyi] == NULL)
                                      /* The first time, fetch from */
      {                               /* the data base. */
        if (MrmFetchWidget(s_MrmHierarchy, "c_nyi", toplevel_widget,
            &widget_array[v_nyi], &dummy_class) != MrmSUCCESS)
        {
          sperror("can't fetch nyi widget");
        }
      }
      /*  Put up the message box saying 'not yet implemented'. */
      XtManageChild(widget_array[v_nyi]);
    } /* if == v_nyi */

    set_draw_mode(actual_mode);
  } /* if ->set */
} /* set_draw_mode_proc() */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  draw_proc()                                              */
/*                                                                            */
/*      Version   :  1.0                                                      */
/*                                                                            */
/*                                                                            */
/*      Purpose   :  callback-procedure for drawing in the DrawingArea        */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  sketchpad.uil (callback for input in DrawingArea)        */
/*                                                                            */
/*      Calls     :  draw()                                                   */
/*                                                                            */
/* ========================================================================== */
static void draw_proc(Widget DrawWidget, int *tag,
                      XmDrawingAreaCallbackStruct *callback_data)
{
  int widget_num = *tag;
  switch (widget_num)
  {
    case v_drawing_area:
    {
      draw(callback_data->event);
      break;
    }
    case v_zoom_area:
    {
      Zoomed_Draw(callback_data->event);
      break;
    }
  } /* switch */
} /* draw_proc */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  edit_pull_proc                                           */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  manages the pulldown menues when a edit menu button is   */
/*                   pressed.                                                 */
/*                                                                            */
/*      Accesses  :  the pulldown menu widgets that are to be managed.        */
/*                                                                            */
/*      Called by :  the XmNcascadeCallbacks of the edit menu buttons.        */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void edit_pull_proc(Widget w, int *tag, unsigned long *reason)
{
  char buffer[16384];
  FILE *f;
  struct stat buf;
  char *buf2;
  struct_storage ss;

  if (GetActiveLayer () != NULL)
  {
    ss = GetStructStorage (GetActiveLayer ());
    switch (*tag)
    {
      case v_edit_copy_button:
      case v_edit_cut_button:
      case v_edit_button_cut:
        {
          void *o;
  
          f = fopen ("cut-paste-buffer", "w");
          if (f != NULL)
          {
            o = GetFirstPickedObj (ss);
            while (o != NULL)
            {
              ReadObject (o, buffer);
              fprintf (f, "%s\n", buffer);
              o = GetNextPickedObj (ss);
            }
            fclose (f);
          }
        }
        break;
      case v_edit_button_erase:
        break;
      case v_edit_paste_button:
      case v_edit_button_paste:
        break;
    } /* switch */
    switch (*tag)
    {
      case v_edit_cut_button:
      case v_edit_button_cut:
      case v_edit_button_erase:
        {
          void *o;
          int id1, id2;

          o = GetFirstPickedObj (ss);
          while (o != NULL)
          {
            GetObjectId (o, &id1, &id2);
            msg_erase_object (id1, id2);
            o = GetNextPickedObj (ss);
          }
          DeletePickedObjects (ss);
        }
        break;
      case v_edit_copy_button:
        break;
      case v_edit_paste_button:
      case v_edit_button_paste:
        stat ("cut-paste-buffer", &buf);
        buf2 = (char *) malloc (buf.st_size + 1);
        f = fopen ("cut-paste-buffer", "r");
        if (f != NULL)
        {
          int r;

          r = fread (buf2, 1, buf.st_size, f);
          buf2[r] = '\0';
          msg_write_object (ownUserNumber, obj_count, strlen (buf2) + 1, buf2);
          WriteObjects (ss, buf2, ownUserNumber, &obj_count);
          fclose (f);
        }
        break;
      case v_edit_edit_button:
        toggle_select_mode();
        if (get_draw_state (SELECT_MODE) == SPECIAL_POINTS_MODE)
        {
          DeselectAll (ss);
        }
        break;
      default:
        /* The user activated a 'not yet implemented' edit button.  Send
         * the user a message. */
        if (widget_array[v_nyi] == NULL)
                                    /* The first time, fetch from */
          {                         /* the data base. */
            if (MrmFetchWidget(s_MrmHierarchy, "c_nyi", toplevel_widget,
                &widget_array[v_nyi], &dummy_class) != MrmSUCCESS) {
                  sperror("can't fetch nyi widget");
                }
          }
         /*  Put up the message box saying 'not yet implemented'. */
         XtManageChild(widget_array[v_nyi]);
         break;
    } /* switch */
  } /* if */
}
 

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  layer_pull_proc                                          */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  manages the pulldown menues when a layers menu button is */
/*                   pressed.                                                 */
/*                                                                            */
/*      Accesses  :  the pulldown menu widgets that are to be managed.        */
/*                                                                            */
/*      Called by :  the XmNcascadeCallbacks of the layers menu buttons.      */
/*                                                                            */
/*      Calls     :  show_lay() CreateLayerList()                             */
/*                                                                            */
/* ========================================================================== */
static void layer_pull_proc (Widget w, int *tag, unsigned long *reason)
{
  switch (*tag)
  {
    case v_save_box_layer_box:
      show_lay(w, xmToggleButtonWidgetClass, LS_SAVE);
      break;

    case v_load_box_layer_box:
      show_lay(w, xmToggleButtonWidgetClass, LS_LOAD);
      break;

    case v_print_box_layer_box:
      show_lay(w, xmToggleButtonWidgetClass, LS_PRINT);
      break;

    case v_layer_status_boxA:
      show_lay(w, xmToggleButtonWidgetClass, LS_VISIBLE);
      break;

    case v_layer_status_boxB:
      show_lay(w, xmToggleButtonWidgetClass, LS_ACTIVE);
      break;

    case v_layer_status_boxC:
      show_lay(w, xmLabelWidgetClass, LS_NONE );
      break;

    case v_layer_status_boxD:
      show_lay(w, xmLabelWidgetClass, LS_COLOR );
      break;

    case v_layer_manage_box3:
      CreateLayerList (widget_array[v_layer_manage_box3]);
      break;
    }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  delete_lay_proc                                          */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  removing a layer from layer list                         */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  Callback of del_box_ok_button                            */
/*                                                                            */
/*      Calls     :  delete_lay()                                             */
/*                                                                            */
/* ========================================================================== */
static void delete_lay_proc(Widget w, int *tag, unsigned long *reason)
{
  if (*tag == v_layer_manage_box_delete_button)
  {
    delete_lay (pos); 
    pos = 1;
    XmListDeselectAllItems(widget_array[v_layer_manage_box3]);
    XmListSelectPos(widget_array[v_layer_manage_box3],pos,TRUE);
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  color_proc                                               */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  is concerned with color editing stuff                    */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  Drag callback of color-box                               */
/*                                                                            */
/*      Calls     :  color_edit                                               */
/*                                                                            */
/* ========================================================================== */
static void color_proc (Widget w, int *tag, XmScaleCallbackStruct *data)
{
  static int layChanged = True;

  switch (*tag)
  {
    /* RGB or HSV sliders have been moved */
    case v_color_box_scale_red:
    case v_color_box_scale_green:
    case v_color_box_scale_blue:
    case v_color_box_scale_hue:
    case v_color_box_scale_sat:
    case v_color_box_scale_val:
      color_edit(w, tag);
      break;

    /* Callbacks of sketchpad.uil (look at 'color_edit' in color.c) */
    case v_push_button:
    case v_attributes_selectcolor_button:
      if (*tag == v_push_button) layChanged = True;
      else layChanged = False;
      color_edit(w, tag);
      break;

    case v_color_box_cancel_button:
    case v_color_box_color_label:
      if (widget_array[v_color_box] != NULL)
      {
        color_edit(w, tag);
      }
      break;
    case v_color_box_ok_button:   /* The apply-button has been pushed */
                                  /* Send it to the world, the user   */
                                  /* has changed a layercolor !       */
      if (layChanged)
         msg_lay_col_changed (edicol_layerNo, &new_color);
      break;

      default: break;

  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  text_proc                                                */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  is concerned with text editing stuff                     */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  Callback of text-box                                     */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void text_proc(Widget w, int *tag, unsigned long *reason)
{
  switch (*tag)
  {
    case v_text_box_cancel_button:
    case v_text_box_clear_button:
      XmTextSetString(widget_array[v_text_box_edit_box], "");
      break;
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  zoom_proc                                                */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  is concerned with zooming stuff                          */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  Callback of zoom-box                                     */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void zoom_proc(Widget w, int *tag, unsigned long *reason)
{
  static int DefaultTempMag; /* used by zoom attribute box */
  static int ActualTempMag;  /* used by slider in zoom box */

  switch (*tag)
  {
    /******** cases of widgets in the zoom box **********************/
    case v_zoom_box:
    {
      XmScaleSetValue(widget_array[v_zoom_mag_scale],
                      GetDefaultZoomMagnification());
      ActualTempMag = GetDefaultZoomMagnification();
      break;
    }
    case v_zoom_cancel_button:
    {
      Cancel_Zoom();
      break;
    }
    case v_zoom_apply_button:
    {
      Apply_Zoom();
      break;
    }
    case v_zoom_done_button:
    {
      Zoom_Done();
      break;
    }
    case v_zoom_mag_scale:
    {
      XmScaleGetValue(widget_array[v_zoom_mag_scale], &ActualTempMag);
      break;
    }
    case v_zoom_resize_button:
    {
      SetActualZoomMagnification(ActualTempMag);
      /* get Magnification actually set (might be lower than requested) */
      ActualTempMag = GetActualZoomMagnification();
      XmScaleSetValue(widget_array[v_zoom_mag_scale], ActualTempMag);
      break;
    }

    /******** cases of widgets in the zoom magnification box ********/
    case v_zoommag_box:
    {
      DefaultTempMag = GetDefaultZoomMagnification();
      XmScaleSetValue(widget_array[v_zoommag_box_scale], DefaultTempMag);
      break;
    }

    case v_zoommag_box_apply_button:
    {
      SetDefaultZoomMagnification(DefaultTempMag);
      break;
    }

    case v_zoommag_box_cancel_button:
    {
      DefaultTempMag = GetDefaultZoomMagnification();
      XmScaleSetValue(widget_array[v_zoommag_box_scale], DefaultTempMag);
      break;
    }

    case v_zoommag_box_scale:
    {
      XmScaleGetValue(widget_array[v_zoommag_box_scale], &DefaultTempMag);
      break;
    }
  }
} /* zoom_proc */



/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  jpeg_proc                                                */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  is concerned with jpeg parameters                        */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  Callback of jpeg-stuff                                   */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void jpeg_proc(Widget w, int *tag, unsigned long *reason)
{
  Arg       args[1];

  static int ActualTempVal;  /* used by jpeg slider */

  switch (*tag)
  {
    case v_jpeg_form_scale:
    {
      XmScaleGetValue(widget_array[v_jpeg_form_scale], &ActualTempVal);
      SetJPEGQuality(ActualTempVal);
      break;
    }

    case v_jpeg_form:
    {
      /* set quality value */
      XtSetArg(args[0], XmNvalue, GetJPEGQuality());
      XtSetValues(widget_array[v_jpeg_form_scale], args, 1);
      break;
    }
  }
} /* jpeg_proc */


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  audio_proc                                               */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  is concerned with audio connection                       */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  Callback of audio button in main window                  */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void audio_proc(Widget w, int *tag, unsigned long *reason)
{
  switch(*tag)
  {
    case v_audio_button:
      if (widget_array[v_audio_button] != NULL)
      {
        msg_audio(XmToggleButtonGetState(widget_array[v_audio_button]));
      }
      break;

  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  button_proc                                              */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  managing callbacks for several buttons                   */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  callbacks of : save-box, load-box                        */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void button_proc(Widget w, int *tag, unsigned long *reason)
{
  switch(*tag)
  {
    case v_save_box_all_button:
      AddCallback(v_save_box_all_button);
      break;

    case v_save_box_all_visible_button:
      AddCallback(v_save_box_all_visible_button);
      break;

    case v_load_box_all_button:
      AddCallback(v_load_box_all_button);
      break;
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  add_user_proc                                            */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  including a new user in the conference                   */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  callback in conference-add-box                           */
/*                                                                            */
/*      Calls     :  msg_new_user, CreateLayerList                            */
/*                                                                            */
/* ========================================================================== */
static void add_user_proc (Widget w, int *tag, unsigned long *reason)
{
  Display *test_display;
  char    display_string[MAXDISPLAYNAMELEN];

  if(*tag == v_conference_add_box_ok_button)
  {
    SetWaitState ();
    XFlush (theDisplay);
    strcpy (display_string, 
            XmTextGetString (widget_array[v_conference_add_box4]));
    if (display_string[0] == '\000') 
    {
       strcpy (display_string,(char*) getenv ("DISPLAY"));
    }
    if (display_string[0] == '\000') 
    {
       strcpy (display_string, "unix:0.0");
    }

    test_display = XOpenDisplay (display_string);
    if ( test_display == NULL ) 
    {
       sperror ("\n Can`t add user. Invalid display-name !");
    }
    else 
    {
       XCloseDisplay (test_display);
/*__BUGS__ by Hendrik */
     /* msg_new_user (XmTextGetString (widget_array[v_conference_add_box3]),
                     display_string, 
                     XmTextGetString (widget_array[v_conference_add_box5])); */
       msg_new_user (XmTextGetString (widget_array[v_conference_add_box3]),
                     display_string, 
                     "" /* Hostname */ );
       new_user_flag = -1;
    }
    ClearWaitState ();
    XFlush (theDisplay);
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  set_pos_proc                                             */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  getting the position in some XmList widgets              */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  SingleSelectionCallbacks of XmList widgets               */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void set_pos_proc(Widget w, int *tag, XmListCallbackStruct *data)
{
  Widget w_text;
  char *s = NULL;

  switch (*tag)
  {
    case v_layer_manage_box3:
      XmStringGetLtoR(data->item, XmSTRING_DEFAULT_CHARSET, &s);
      if (strcmp(s,""))
      {
         pos=data->item_position;
      }
      w_text=widget_array[v_layer_manage_box4];
      XmTextSetString(w_text, GetLayerName(pos));
      XmListDeselectAllItems(widget_array[v_layer_manage_box3]);
      XmListSelectPos(widget_array[v_layer_manage_box3],pos,FALSE);
      break;

    case v_conference_sync_box_list:
      {
         int upos;

         upos = data->item_position;
         XmListDeselectAllItems(widget_array[v_conference_sync_box_list]);
         XmListSelectPos(widget_array[v_conference_sync_box_list],upos,FALSE);
      }
      break;

    default:
      break;
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  conference_list_proc                                     */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  manages the pulldown menues when a conference menu       */
/*                   button ist pressed.                                      */
/*                                                                            */
/*      Accesses  :  the pulldown menu widgets that are to be managed.        */
/*                                                                            */
/*      Called by :  the XmNcascadeCallbacks of the conference menu buttons.  */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void conference_list_proc (Widget w, int *tag, unsigned long *reason)
{
  int id, i;
  char *username;
  char *hostname;
  char *displayname;
  char text[132];
  XmString name;
  Arg args[1];

  if (widget_array[v_conference_list_box] != NULL)
  {
    XtSetArg (args[0], XmNitemCount, 0);
    XtSetValues (w, args, 1);
    GetFirstUser (&id, &username, &hostname, &displayname);
    i = 1;
    while (id != -1)
    {
      sprintf (text, "%10s, %15s, %10s, %3d", username, hostname, displayname, id);
      name = XmStringCreateLtoR(text, XmSTRING_DEFAULT_CHARSET);
      XmListAddItem (w, name, i++);
      GetNextUser (&id, &username, &hostname, &displayname);
    }
    for (; i < 6; i++)
    {
      XmListAddItem (w, XmStringCreateLtoR("", XmSTRING_DEFAULT_CHARSET), i);
    }
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  conference_sync_proc                                     */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  manages the pulldown menues when a conference menu       */
/*                   button ist pressed.                                      */
/*                                                                            */
/*      Accesses  :  the pulldown menu widgets that are to be managed.        */
/*                                                                            */
/*      Called by :  the XmNcascadeCallbacks of the conference menu buttons.  */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void conference_sync_proc (Widget w, int *tag, unsigned long *reason)
{
  int id, i;
  char *username;
  char *hostname;
  char *displayname;
  char text[132];
  XmString name;
  Arg args[1];

  if (widget_array[v_conference_sync_box] != NULL)
  {
    XtSetArg (args[0], XmNitemCount, 0);
    XtSetValues (w, args, 1);
    GetFirstUser (&id, &username, &hostname, &displayname);
    i = 1;
    while (id != -1)
    {
      if (id != ownUserNumber)          /* don't sync with yourself !! */
      {
        sprintf (text,"%10s,%15s,%10s,%3d",username,hostname,displayname,id);
        name = XmStringCreateLtoR(text, XmSTRING_DEFAULT_CHARSET);
        XmListAddItem (w, name, i++);
      }
      GetNextUser (&id, &username, &hostname, &displayname);
    }
    for (; i < 6; i++)
    {
      XmListAddItem (w, XmStringCreateLtoR("", XmSTRING_DEFAULT_CHARSET), i);
    }
    XmListSelectPos(widget_array[v_conference_sync_box_list], 1, FALSE);
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  synchronize_proc                                         */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  manages the synchronization when the synchronize         */
/*                   button ist pressed.                                      */
/*                                                                            */
/*      Accesses  :  the pulldown menu widgets that are to be managed.        */
/*                                                                            */
/*      Called by :  the XmNactivateCallback of the synchronize menu button.  */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void synchronize_proc (Widget w, int *tag, unsigned long *reason)
{
  char *text;
  XmStringTable sTable;
  Arg   args[1];
  int   id;

  XtSetArg(args[0], XmNselectedItems, &sTable);
  XtGetValues(widget_array[v_conference_sync_box_list], args, 1);
  XmStringGetLtoR (sTable[0], XmSTRING_DEFAULT_CHARSET, &text);
  if (strcmp(text,""))
  {
    id = atoi(&text[strlen(text)-3]);
    text[10] = '\0';
    msg_sync_user(id,TRUE,0,0,0,0,NULL);
  }
  else
  {
    sperror("WARNING: no partner selected !");
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  objects_pull_proc                                        */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  manages the pulldown menues when a objects menu button is*/
/*                   pressed.                                                 */
/*                                                                            */
/*      Accesses  :  the pulldown menu widgets that are to be managed.        */
/*                                                                            */
/*      Called by :  the XmNcascadeCallbacks of the objects menu buttons.     */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void objects_pull_proc(Widget w, int *tag, unsigned long *reason)
{
  /* The user activated a 'not yet implemented' objects button.  Send */
  /* the user a message. */
  if (widget_array[v_nyi] == NULL)
  /* The first time, fetch from */
  /*       the data base.       */
  {
    if (MrmFetchWidget(s_MrmHierarchy, "c_nyi", toplevel_widget,
        &widget_array[v_nyi], &dummy_class) != MrmSUCCESS)
    {
      sperror("can't fetch nyi widget");
    }
  }
  /*  Put up the message box saying 'not yet implemented'. */
  XtManageChild(widget_array[v_nyi]);
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  attributes_pull_proc                                     */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  manages the pulldown menues when a attributes menu       */
/*                   button ist pressed.                                      */
/*                                                                            */
/*      Accesses  :  the pulldown menu widgets that are to be managed.        */
/*                                                                            */
/*      Called by :  the XmNcascadeCallbacks of the attributes menu buttons.  */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void attributes_pull_proc(Widget w, int *tag, unsigned long *reason)
{
  /* The user activated a 'not yet implemented' attributes button.  Send
   * the user a message. */
  if (widget_array[v_nyi] == NULL)
  /* The first time, fetch from */
  /*      the data base.        */
  {
    if (MrmFetchWidget(s_MrmHierarchy, "c_nyi", toplevel_widget,
        &widget_array[v_nyi], &dummy_class) != MrmSUCCESS)
    {
       sperror("can't fetch nyi widget");
    }
  }
  /*  Put up the message box saying 'not yet implemented'. */
  XtManageChild(widget_array[v_nyi]);
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  set_linestyle_proc                                       */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  manages the action when a button in the linestyle menu   */
/*                   is pressed.                                              */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  the Callbacks of the linestyle menu buttons and scale.   */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

static void set_linestyle_proc (Widget w, int *tag, unsigned long *data)
{

  int value;
  static int current_slider_value = LINE_WIDTH_MIN;
  static int current_menu_value   = SOLID;
  static int old_slider_value     = LINE_WIDTH_MIN;
  static int old_menu_value       = SOLID;

  switch (*tag)
  {
    case v_linestyle_box_style_solid_button:
      current_menu_value = SOLID;
      set_draw_state (LINE_STYLE, current_menu_value);
      set_draw_state (LINE_WIDTH, current_slider_value);
      old_menu_value   = current_menu_value;
      old_slider_value = current_slider_value;
      break;
    case v_linestyle_box_style_dash_button:
      current_menu_value = DASHED;
      set_draw_state (LINE_STYLE, current_menu_value);
      set_draw_state (LINE_WIDTH, current_slider_value);
      old_menu_value   = current_menu_value;
      old_slider_value = current_slider_value;
      break;
    case v_linestyle_box_thickness_scale:
      XmScaleGetValue (widget_array[v_linestyle_box_thickness_scale], &value);
      current_slider_value = value;
      set_draw_state (LINE_STYLE, current_menu_value);
      set_draw_state (LINE_WIDTH, current_slider_value);
      old_menu_value   = current_menu_value;
      old_slider_value = current_slider_value;
      break;
/*
    case v_linestyle_box_cancel_button:
      XmScaleSetValue (widget_array[v_linestyle_box_thickness_scale],
                       old_slider_value);
      current_slider_value = old_slider_value;

      n = 0;
      switch (old_menu_value)
      {
        case SOLID:
          XtSetArg (args[n], XmNmenuHistory,
                    widget_array[v_linestyle_box_style_solid_button]); n++;
          break;
        case DASHED:
          XtSetArg (args[n], XmNmenuHistory,
                    widget_array[v_linestyle_box_style_dash_button]); n++;
          break;
      }
      XtSetValues (widget_array[v_linestyle_box_style_option], args, n);
      current_menu_value = old_menu_value;
       break;
*/
    default:
      sperror("set_linestyle_proc: Illegal parameter");
      break;
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  set_textstyle_proc                                       */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  manages the action when a button in the textstyle menu   */
/*                   is pressed.                                              */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  the Callbacks of the textstyle menu buttons and scale.   */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */

static void set_textstyle_proc (Widget w, int *tag, unsigned long *data)
{

  int value;
  static int current_slider_value = TEXT_SIZE_DEF;
  static int old_slider_value     = TEXT_SIZE_DEF;
  static int current_thick_value  = BOLD;
  static int old_thick_value      = BOLD;
  static int current_slant_value  = ROMAN;
  static int old_slant_value      = ROMAN;

  switch (*tag)
  {
    case v_textstyle_box_thick_b_button:
      current_thick_value = BOLD;
      break;
    case v_textstyle_box_thick_m_button:
      current_thick_value = MEDIUM;
      set_draw_state (TEXT_THICKNESS, current_thick_value);
      old_thick_value = current_thick_value;
      break;
    case v_textstyle_box_slant_r_button:
      current_slant_value = ROMAN;
      set_draw_state (TEXT_SLANT, current_slant_value);
      old_slant_value = current_slant_value;
      break;
    case v_textstyle_box_slant_i_button:
      current_slant_value = ITALIC;
      set_draw_state (TEXT_SLANT, current_slant_value);
      old_slant_value = current_slant_value;
      break;
    case v_textstyle_box_size_scale:
      XmScaleGetValue (widget_array[v_textstyle_box_size_scale], &value);
      current_slider_value = value;
      if (set_draw_state (TEXT_SIZE, current_slider_value))
      {
        old_slider_value = current_slider_value;
      }
      else
      {
        old_slider_value = get_draw_state (TEXT_SIZE);
        XmScaleSetValue (widget_array[v_textstyle_box_size_scale],
                         old_slider_value);
        current_slider_value = old_slider_value;
      };

      break;
/*
    case v_textstyle_box_apply_button:
      if (set_draw_state (TEXT_SIZE, current_slider_value))
      {
        old_slider_value = current_slider_value;
      }
      else
      {
        old_slider_value = get_draw_state (TEXT_SIZE);
        XmScaleSetValue (widget_array[v_textstyle_box_size_scale],
                         old_slider_value);
        current_slider_value = old_slider_value;
      };

      set_draw_state (TEXT_THICKNESS, current_thick_value);
      old_thick_value = current_thick_value;

      set_draw_state (TEXT_SLANT, current_slant_value);
      old_slant_value = current_slant_value;

      break;
    case v_textstyle_box_cancel_button:
      XmScaleSetValue (widget_array[v_textstyle_box_size_scale],
                       old_slider_value);
      current_slider_value = old_slider_value;

      n = 0;
      switch (old_thick_value)
      {
        case BOLD:
          XtSetArg (args[n], XmNmenuHistory,
                    widget_array[v_textstyle_box_thick_b_button]); n++;
          break;
        case MEDIUM:
          XtSetArg (args[n], XmNmenuHistory,
                    widget_array[v_textstyle_box_thick_m_button]); n++;
          break;
      }
      XtSetValues (widget_array[v_textstyle_box_thick_option], args, n);
      current_thick_value = old_thick_value;

      n = 0;
      switch (old_slant_value)
      {
        case ROMAN:
          XtSetArg (args[n], XmNmenuHistory,
                    widget_array[v_textstyle_box_slant_r_button]); n++;
          break;
        case ITALIC:
          XtSetArg (args[n], XmNmenuHistory,
                    widget_array[v_textstyle_box_slant_i_button]); n++;
          break;
      }
      XtSetValues (widget_array[v_textstyle_box_slant_option], args, n);
      current_slant_value = old_slant_value;

      break;
*/
    default:
      break;
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  expose_proc                                              */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  handles the expose problems some windows might get when  */
/*                   being overlapped by others                               */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  the XmNexposeCallbacks of the attributes menu buttons.   */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static void expose_proc(Widget w, int *tag, XmDrawingAreaCallbackStruct *expose)
{
  XExposeEvent *event;
  XRectangle    expose_rec;
  layer lay;
  int layer_id, sketch_id;

  event = (XExposeEvent *) expose->event;
  if (*tag == v_drawing_area)
  {
    expose_rec.x      = event->x;
    expose_rec.y      = event->y;
    expose_rec.width  = event->width;
    expose_rec.height = event->height;

    /* redraw all layers */
    lay = GetFirstLayer ();
    while (lay != NULL)
    {
      if (GetLayerState (lay) & LS_VISIBLE)
      {
        GetLayerId (lay, &layer_id, &sketch_id);
        if ((layer_id == 1) && (sketch_id == 0))
        {
          RedrawRasterImage (expose_rec);
        }
        else
        {
          DrawLayer (lay, expose_rec);
        }
      }
      lay = GetNextLayer ();
    }

    /* redraw visible pointers in expose region */
    redraw_all_pointers (expose_rec);
  }
  else if (*tag == v_zoom_area)
  {
    expose_rec.x      = event->x;
    expose_rec.y      = event->y;
    expose_rec.width  = event->width;
    expose_rec.height = event->height;

    Redraw_Zoom(expose_rec);
  }
}

/* No Header ,no Callback */
void RedrawAll(XRectangle expose_rec)
{
  layer lay;
  int layer_id, sketch_id;

  if ((expose_rec.x == WholeDrawingArea.x) && 
      (expose_rec.y == WholeDrawingArea.y) &&
      (expose_rec.width == WholeDrawingArea.width) && 
      (expose_rec.height == WholeDrawingArea.height))
  {
    XClearArea (XtDisplay(widget_array[v_drawing_area]),
                XtWindow(widget_array[v_drawing_area]), 0, 0, 0, 0, True);
  }
  else
  {
    XClearArea (XtDisplay(widget_array[v_drawing_area]),
                XtWindow(widget_array[v_drawing_area]),
                expose_rec.x, expose_rec.y,
                expose_rec.width, expose_rec.height, True);
  }

  /* redraw all layers */
  lay = GetFirstLayer ();
  while (lay != NULL)
  {
    if (GetLayerState (lay) & LS_VISIBLE)
    {
      GetLayerId (lay, &layer_id, &sketch_id);
      if ((layer_id == 1) && (sketch_id == 0))
      {
        RedrawRasterImage (expose_rec);
      }
      else
      {
        DrawLayer (lay, expose_rec);
      }
    }
    lay = GetNextLayer ();
  }

  /* redraw visible pointers in expose region */
  redraw_all_pointers (expose_rec);
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  pic_io_proc                                              */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  handles all callbacks for loading, saving, etc of pic's. */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void pic_io_proc(Widget w, int *tag,
                        XmFileSelectionBoxCallbackStruct *data)
{
  int widget_num;
  char *filename = NULL;              /* string containing filename      */

  layer lay;
  int layer_id, sketch_id;

  widget_num = *tag;
  switch (widget_num)
  {
    case v_save_box:
      /* Get File Name */
      XmStringGetLtoR(data->value, charset, &filename);
      if (strlen (filename) > 0)
      {
        Save(filename);
      }
      else
      {
        sperror("Save: please specify a file name!");
      }

      /* Abort SketchPad, when Conference module wants to do it */
      if (end_sketch == True)
      {
        quit_proc((Widget)NULL, (int *)v_save_box, (unsigned long int *)NULL);
      }
      break;

    case v_load_box:
      /* Get File Name */
      XmStringGetLtoR(data->value, charset, &filename);
      if (strlen (filename) > 0)
      {
        Load(filename, LOAD_BOX);
      }
      else
      {
        sperror("Load: please specify a file name!");
      }

      /* Update layer list in manage box */
      CreateLayerList(widget_array[v_layer_manage_box3]);
      break;


    case v_layer_manage_box_clear_button:
      lay = GetLayerFromNo (pos);
      GetLayerId (lay, &layer_id, &sketch_id);

      if (sketch_id == ownUserNumber)
      {
        msg_clear_layer (layer_id, sketch_id);

        if ((layer_id == 1) && (sketch_id == 0))
        {
          (void) ClearRasterImage();
          *picFilename = '\0';
        }
        else
        {
          (void) ClearLayer (layer_id, sketch_id);
        }
      }      
      else
      {
	 sperror("Warning: you cannot clear a partners layer!");
      }
     break;

    case v_print_box:
      /* Get File Name */
      filename = XmTextGetString (widget_array[v_print_box_text_box]);
      if (strlen (filename) > 0)
      {
        Print(filename);
      }
      else
      {
        sperror("Print: please specify a file name!");
      }
      break;

    default:
      if (widget_array[v_nyi] == NULL)
      /* The first time, fetch from */
      /*       the data base.       */
      {
        if (MrmFetchWidget(s_MrmHierarchy, "c_nyi", toplevel_widget,
            &widget_array[v_nyi], &dummy_class) != MrmSUCCESS)
        {
          sperror("can't fetch nyi widget");
        }
      }
      /*  Put up the message box saying 'not yet implemented'. */
      XtManageChild(widget_array[v_nyi]);
      break;
  }
}                


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  help_proc                                                */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  handles help calls, makes a rehash of directories        */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  help-callback in : save-box, load-box                    */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void help_proc(Widget w, int *tag, unsigned long *reason)
{
  XmString name;
  char     *tmp;
  char     dir[255];
  Arg   args[1];
  Widget   child;

  switch (*tag)
  {
    case v_load_box:
      child = XmFileSelectionBoxGetChild(widget_array[v_load_box3],
                                         XmDIALOG_FILTER_TEXT);
      tmp = XmTextGetString(child);
      strcpy(dir, tmp);
      dir[strlen(tmp) -2] = 0;
      name = XmStringCreateLtoR(dir, XmSTRING_DEFAULT_CHARSET);
      XtSetArg(args[0], XmNdirectory, name);
      XtSetValues(widget_array[v_load_box3], args, 1);
      break;

    case v_save_box:
      child = XmFileSelectionBoxGetChild(widget_array[v_save_box3],
                                         XmDIALOG_FILTER_TEXT);
      tmp = XmTextGetString(child);
      strcpy(dir, tmp);
      dir[strlen(tmp) -2] = 0;
      name = XmStringCreateLtoR(dir, XmSTRING_DEFAULT_CHARSET);
      XtSetArg(args[0], XmNdirectory, name);
      XtSetValues(widget_array[v_save_box3], args, 1);
      break;
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  set_font_proc                                            */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  handles font_selection_callbacks(n y i)                  */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void set_font_proc(Widget w, int *tag, unsigned long *reason)
{
}      


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  rename_lay_proc                                          */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  handles all callbacks for renaming layers                */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  Callback of layer_manage_box_ok_button                   */
/*                                                                            */
/*      Calls     :  SetLayerName()                                           */
/*                                                                            */
/* ========================================================================== */
static void rename_lay_proc(Widget w, int *tag,
                            XmListCallbackStruct *data)
{
    char name[LAYERNAMELEN];

    strcpy(name, XmTextGetString (widget_array[v_layer_manage_box4]));
    if (strlen (name) != 0)
    {
       SetLayerName (pos, XmTextGetString (widget_array[v_layer_manage_box4]));
    }
}   

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  add_lay_proc                                             */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  including a new layer into layer list                    */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  Callback of layer_add_box_ok_button                      */
/*                                                                            */
/*      Calls     :  add_lay()                                                */
/*                                                                            */
/* ========================================================================== */
static void add_lay_proc(Widget w, int *tag, unsigned long *reason)
{
  layer new_layer;
  struct_storage ss;
  char name[LAYERNAMELEN];

  if(*tag == v_layer_manage_box_add_button)
  {
    strcpy(name, XmTextGetString (widget_array[v_layer_manage_box4]));
    if ( (strlen (name) == 0) || (!strcmp(name,"Background")) )
    {
      strcpy (name, "new Layer");
    }
    new_layer = add_lay (name, False);
    ss = GetStructStorage (new_layer);
    SetTransformation (ss, 0, 0);
    pos = 1;
    XmListDeselectAllItems(widget_array[v_layer_manage_box3]);
    XmListSelectPos(widget_array[v_layer_manage_box3],pos,TRUE);
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  ManageMessageBox()                                       */
/*                                                                            */
/*      Version   :  24.07.1991                                               */
/*                                                                            */
/*      Purpose   :  Open message box to ask user what to do (load another    */
/*                   file, request data, do nothing)                          */
/*                   Only the box is opened. Handling of events is performed  */
/*                   by callback function load_action_proc().                 */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  User Module                                              */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
void ManageMessageBox(char *cpath)
{
  char path[256];

  if (widget_array[v_message_box] == NULL)
  {
    if (MrmFetchWidget(s_MrmHierarchy,
                       name[v_message_box],
                       toplevel_widget,
                       &widget_array[v_message_box],
                       &dummy_class) != MrmSUCCESS)
    {
      sperror("ManageMessageBox: can`t fetch Box.");
    }
  }
  strcpy (PictureToLoad, cpath);
  strcpy(path, PicPath);
  strcat(path, cpath);
  XmTextSetString(widget_array[v_message_box_text], path);
  XtManageChild(widget_array[v_message_box]);
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  load_action_proc()                                       */
/*                                                                            */
/*      Version   :  24.07.1991                                               */
/*                                                                            */
/*      Purpose   :  Handling of events caused by user action in load message */
/*                   box                                                      */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  buttons in message box                                   */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static void load_action_proc(Widget w, int *tag, unsigned long *data)
{
  char path[256];
  char cpath[256];
  char SPicPath[256];
  char *tempp;
  char *cp;

  strcpy(SPicPath,"\0");
  switch (*tag)
  {
    case v_message_box_load_button:
      strcpy(SPicPath, PicPath);
      strcpy(path, XmTextGetString (widget_array[v_message_box_text]));

      /* modify filename for loading picture */
      strcpy(path, NPath(path));
      cp = strstr(path, PicPath);
      if (cp == path)
      {
        /* Picture is located relative to PicPath */
        strcpy(cpath, path + strlen(PicPath));
      }
      else
      {
        /* Picture is not located relative to PicPath */
        tempp = strrchr(path, '/');
        strncpy(PicPath, path, tempp - path + 1);
        PicPath[tempp - path + 1] = '\0';
        trace("PicPath set to %s\n",PicPath,0,0,0);

        /* crop directory off filename */
        tempp = strrchr(path, '/');
        if (tempp != NULL) tempp++;
        strcpy(cpath, tempp);
        trace("cpath set to %s\n",cpath,0,0,0);
      }
/*      fprintf(stderr, "*** Action: try to load %s.", cpath);                */

      if (!LoadRasterImage(cpath))
      {
        strcpy(PicPath, SPicPath);
        ManageMessageBox(PictureToLoad);
      }
      strcpy(PicPath, SPicPath);
      break;
    case v_message_box_get_button:
/*      fprintf(stderr,"*** Action: request to send %s.\n", PictureToLoad);   */
      msg_cannot_load_pic(PictureToLoad);
      break;
    case v_message_box_cancel_button:
/*      fprintf(stderr,"*** Action: abort load communication.\n");            */
      msg_pic_not_loaded(PictureToLoad);
      break;
    default:
      fprintf(stderr,"LoadAction: This cannot happen.\n");
      break;
  }
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  format_proc()                                            */
/*                                                                            */
/*      Version   :                                                           */
/*                                                                            */
/*      Purpose   :                                                           */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :                                                           */
/*                                                                            */
/*      Calls     :                                                           */
/*                                                                            */
/* ========================================================================== */
static void format_proc(Widget w, int *tag, unsigned long *data)
{
  Arg args[2];

  switch (*tag)
  {
    case v_save_box5_format_gif_button:
      format = GIF;
      break;
    case v_save_box5_format_tiff_button:
      format = TIFF;
      break;
    case v_save_box5_format_sun_button:
      format = FSUN;
      break;
    case v_save_box5_format_jpeg_button:
      format = JPEG;
      break;
    case v_save_box5_format_pbm_button:
      format = PBM;
      break;
    case v_save_box5_format_pm_button:
      format = PM;
      break;
    case v_save_box5_format_xbm_button:
      format = XBM;
      break;
    case v_save_box5_color_full_button:
      colorstyle = FULL_COLOR;
      break;
    case v_save_box5_color_grey_button:
      colorstyle = GREYSCALE;
      break;
    case v_save_box5_color_bw_button:
      colorstyle = BW_STIPPLE;
      break;
    default:
      break;
  }
  if (*tag == v_save_box5_format_jpeg_button)
  {
    if (widget_array[v_jpeg_form] == NULL)
    {
      /* add jpeg form in save box */
      if (MrmFetchWidget(s_MrmHierarchy,name[v_jpeg_form],
                         widget_array[v_save_form],
                         &widget_array[v_jpeg_form],
                         &dummy_class)  == MrmSUCCESS)
      {
        XtManageChild(widget_array[v_jpeg_form]);
        XtSetArg (args[0], XmNbottomAttachment, XmATTACH_WIDGET);
        XtSetArg (args[1], XmNbottomWidget, widget_array[v_jpeg_form]);
        XtSetValues (widget_array[v_save_box5], args, 2);
      }
      else
      {
        sperror("Can't fetch jpeg quality form");
      }
    }
  }
  else
  {
    if (widget_array[v_jpeg_form] != NULL)
    {
      /* remove jpeg form from save box */
      XtSetArg (args[0], XmNbottomAttachment, XmATTACH_FORM);
      XtSetValues (widget_array[v_save_box5], args, 1);
      XtUnmanageChild (widget_array[v_jpeg_form]);
      XtDestroyWidget(widget_array[v_jpeg_form]);
      widget_array[v_jpeg_form] = NULL;
    }
  }
}


/* No Header, no Callback */
void IRedraw(XRectangle rec)
{
  layer lay;
  int layer_id, sketch_id;

  XClearArea (XtDisplay(widget_array[v_drawing_area]),
              XtWindow(widget_array[v_drawing_area]),
              rec.x, rec.y, rec.width, rec.height, False);
  lay = GetFirstLayer ();
  if (GetLayerState (lay) & LS_VISIBLE)
  {
    GetLayerId (lay, &layer_id, &sketch_id);
    if ((layer_id == 1) && (sketch_id == 0))
    {
      RedrawRasterImage (rec);
    }
  }
}


/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  stop_sketchpad                                           */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  aborting the SketchPad by Conference module              */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  receive_message in ../kernel/user.c                      */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
void stop_sketchpad ()
{
  if (widget_array[v_quit_box] == NULL)
  {
    if (MrmFetchWidget(s_MrmHierarchy,
        name[v_quit_box],
        toplevel_widget,
        &widget_array[v_quit_box],
        &dummy_class) != MrmSUCCESS)
    {
      sperror("can`t fetch Box !");
    }
    else
    {

    }
  }
  XtManageChild(widget_array[v_quit_box]);
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  init_application                                         */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  one-time initialisation of the application               */
/*                                                                            */
/*      Accesses  :  global data structures                                   */
/*                                                                            */
/*      Called by :  main                                                     */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void init_application()
{
  int i,k;

  /* Initialize the application data structures. */
  for (k = 0; k < v_max_widget; k++)
       widget_array[k] = NULL;

  /* Initialize the names of Subwindows opened by create_obj_proc() */
  for(i=0; i < v_max_widget; i++)
  {
     name[i]=NULL;
  }
  name[v_save_box]            = "c_save_box";
  name[v_load_box]            = "c_load_box";
  name[v_slideshow_box]       = "c_slideshow_box";
  name[v_slideshow_rc_box]    = "c_slideshow_rc_box";
  name[v_message_box]         = "c_message_box";
  name[v_print_box]           = "c_print_box";
  name[v_jpeg_form]           = "c_jpeg_form";
  name[v_layer_manage_box]    = "c_layer_manage_box";
  name[v_layer_status_box]    = "c_layer_status_box";
  name[v_conference_add_box]  = "c_conference_add_box";
  name[v_conference_list_box] = "c_conference_list_box";
  name[v_conference_sync_box] = "c_conference_sync_box";
  name[v_text_box]            = "c_text_box";
  name[v_edit_text_box]       = "c_edit_text_box";
  name[v_zoom_box]            = "c_zoom_box";
  name[v_zoommag_box]         = "c_zoommag_box";
  name[v_color_box]           = "c_color_box";
  name[v_linestyle_box]       = "c_linestyle_box";
  name[v_textstyle_box]       = "c_textstyle_box";
  name[v_quit_box]            = "c_quit_box";
  name[v_info_box]            = "c_info_box";
}

/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  comm_callback                                            */
/*                                                                            */
/*      Purpose   :  signals waiting data to be read from main process        */
/*                                                                            */
/*      Accesses  :                                                           */
/*                                                                            */
/*      Called by :  XToolkit                                                 */
/*                                                                            */
/*      Calls     :  receive_message from kernel/user.c                       */
/*                                                                            */
/* ========================================================================== */
void comm_callback (caddr_t cldata, int *source, XtInputId *id)

{
  receive_message ();
} /* end of comm_callback */


/* ========================================================================== */
/*    The names and addresses of things that Mrm has to bind.                 */
/* ========================================================================== */
static MRMRegisterArg reglist[] = 
{
  {"quit_proc", (caddr_t) quit_proc},
  {"slideshow_proc", (caddr_t) slideshow_proc},
  {"grab_proc", (caddr_t) grab_proc},
  {"external_quit_proc", (caddr_t) external_quit_proc},
  {"create_object_proc", (caddr_t) create_object_proc},
  {"destroy_object_proc", (caddr_t) destroy_object_proc},
  {"create_proc", (caddr_t) create_proc},
  {"set_draw_mode_proc", (caddr_t) set_draw_mode_proc},
  {"edit_pull_proc", (caddr_t) edit_pull_proc},
  {"conference_list_proc", (caddr_t) conference_list_proc},
  {"conference_sync_proc", (caddr_t) conference_sync_proc},
  {"synchronize_proc", (caddr_t) synchronize_proc},
  {"objects_pull_proc", (caddr_t) objects_pull_proc},
  {"attributes_pull_proc", (caddr_t) attributes_pull_proc},
  {"expose_proc", (caddr_t) expose_proc},
  {"pic_io_proc" , (caddr_t) pic_io_proc },
  {"help_proc", (caddr_t) help_proc },
  {"rename_lay_proc", (caddr_t) rename_lay_proc},
  {"add_lay_proc", (caddr_t) add_lay_proc},
  {"delete_lay_proc", (caddr_t) delete_lay_proc},
  {"layer_pull_proc",(caddr_t) layer_pull_proc},
  {"set_font_proc", (caddr_t) set_font_proc},
  {"set_pos_proc", (caddr_t) set_pos_proc},
  {"draw_proc", (caddr_t) draw_proc},
  {"add_user_proc", (caddr_t) add_user_proc},
  {"button_proc", (caddr_t) button_proc},
  {"text_proc", (caddr_t) text_proc},
  {"edit_text_proc", (caddr_t) edit_text_proc},
  {"zoom_proc", (caddr_t) zoom_proc},
  {"jpeg_proc", (caddr_t) jpeg_proc},
  {"color_proc", (caddr_t) color_proc},
  {"audio_proc", (caddr_t) audio_proc},
  {"load_action_proc", (caddr_t) load_action_proc},
  {"format_proc", (caddr_t) format_proc},
  {"set_linestyle_proc", (caddr_t) set_linestyle_proc},
  {"set_textstyle_proc", (caddr_t) set_textstyle_proc},
};

static int reglist_num = (sizeof reglist / sizeof reglist[0]);

/* ========================================================================== */
/*                                                                            */
/*                           MAIN PROGRAMM                                    */
/*                                                                            */
/* ========================================================================== */

unsigned int main (unsigned int argc, char *argv[])

{
/* we do not need this any longer
 *
 *  XtWorkProcId workProcId;
 */

  Arg args[1];
    
  /***** save display command line parameter, before toolkit removings *****/
  strcpy (displayname, argv[2]);

  /*
   *  Initialize the MRM
   */

  MrmInitialize();

  /*
   *  Initialize the toolkit. We get back a top level shell widget.
   */

  toplevel_widget = XtAppInitialize(&app_context,  /* application context     */
                                    (String) "Sketchpad",
                                    (XrmOptionDescList) NULL,
                                    (Cardinal) 0,
                                    (int *) &argc, 
                                    (String *) argv,
                                    (String *) NULL,
                                    (ArgList) NULL,
                                    (Cardinal) 0);

  /*
   * Open the UID files in the hierarchy.
   */

  if (MrmOpenHierarchy (db_filename_num,    /* number of files    */
                        db_filename_vec,    /* files              */
                        NULL,               /* os_ext_list (null) */
                        &s_MrmHierarchy)    /* ptr to returned id */
                        != MrmSUCCESS) 
  {
    sperror("can't open hierarchy");
  }

  init_application();

  /*
   * Register our callback routines so that the resource manager can 
   * resolve them at widget-creation time.
   */

  if (MrmRegisterNames (reglist, reglist_num) != MrmSUCCESS)
  {
    sperror("can't register names");
  }

  /*
   * Get the main part of the application 
   */

  if (MrmFetchWidget (s_MrmHierarchy,
                      "c_main_window",
                      toplevel_widget,
                      &main_window_widget,
                      &dummy_class) != MrmSUCCESS)
  {
    fprintf(stderr, "can't fetch  main window\n");
  }

  /*
   * Manage the main part and realize everything. The interface
   * comes up on the display now.
   */

  XtManageChild(main_window_widget);
  XtRealizeWidget(toplevel_widget);
  

  /*
   * Start background function for receiving messages
   *
   * This is done now by asynchron X Event ClientMessage generated
   * from SIGIO.
   *
   * workProcId = XtAddWorkProc ( receiveMessageProc, NULL );
   */

  Init_Communication (argv); /* defined in kernel/user.c */

  isc_device = ISCgetdevice (channel);

  input_id = XtAppAddInput (app_context,
                            (int) isc_device,
                            (caddr_t) XtInputReadMask, 
                            (XtInputCallbackProc) comm_callback,
                            (caddr_t) NULL);


  /*
   * Init the user database
   */

  InitUserdata ();

  /*
   * Initialize DrawingArea
   */


  init_draw_proc ();

  /*
   *  Initialize two layers
   */

  InitLayers();

  /*
   * Initialize Pic-IO-Functions
   */

  InitPicio (XtDisplay(widget_array[v_drawing_area]), 
             XtWindow(widget_array[v_drawing_area]));

  msg_tell_address (); /* defined in kernel/user.c */

  /*
   *  Loop and process events
   */

  XtAppMainLoop(app_context);

  return (-1);
}

void *dlopen()
{
    return 0;
}

void *dlsym()
{
    return 0;
}

int dlclose()
{
    return -1;
}


/*--------------------------------------------------------------*/
/*          Einfuegung der Funktion "PopEditWindow"		*/
/*	    Poppen eines Fensters zum Editieren eines Textes	*/
/*--------------------------------------------------------------*/
void PopEditWindow (object o)
{
   char *text;

   text = GetText(o);
   StoreTextObject(o);

   if (widget_array[v_edit_text_box] == NULL)
   {
     if (MrmFetchWidget(s_MrmHierarchy,
         name[v_edit_text_box],
         toplevel_widget,
         &widget_array[v_edit_text_box],
         &dummy_class) != MrmSUCCESS)
     {
       sperror("can`t fetch Box !");
     }
     XtManageChild(widget_array[v_edit_text_box]);
     XmTextSetString(widget_array[v_edit_text_box_edit_box], text);
   }
   else
   {
     XmTextSetString(widget_array[v_edit_text_box_edit_box], text);
   }
}
/* ========================================================================== */
/*                                                                            */
/*      Fnctname  :  edit_text_proc                                           */
/*                                                                            */
/*      Version   :  1                                                        */
/*                                                                            */
/*      Purpose   :  is concerned with text editing stuff                     */
/*                                                                            */
/*      Accesses  :  --                                                       */
/*                                                                            */
/*      Called by :  Callback of edit-text-box                                */
/*                                                                            */
/*      Calls     :  --                                                       */
/*                                                                            */
/* ========================================================================== */
static void edit_text_proc(Widget w, int *tag, unsigned long *reason)
{
  char *oldtext,*newtext;
  object o;
  struct_storage ss;

  ss = GetStructStorage (GetActiveLayer ());
  GetTextObject(&o);
  oldtext = GetText(o);
  newtext = XmTextGetString(widget_array[v_edit_text_box_edit_box]);

  switch (*tag)
  {
    case v_edit_text_box_clear_button:
        XmTextSetString(widget_array[v_edit_text_box_edit_box], "");
        break;
    case v_edit_text_box_cancel_button:
        PickObject (ss, o);		/* deselect object again */
        break;
    case v_edit_text_box_okay_button:
	if (strcmp(oldtext,newtext))
	{
	   int id1,id2;
	   Dimension w,h;
	   XmString text_xmstring;
           int  fsize,fthick,fslant;
           int  ofsize,ofthick,ofslant;
	   int  x1,y1;
	   XRectangle bbox;

	   ofsize = get_draw_state (TEXT_SIZE);
	   ofthick = get_draw_state (TEXT_THICKNESS);
	   ofslant = get_draw_state (TEXT_SLANT);
           GetTextEntry (&x1, &y1, &fsize, &fthick, &fslant);
	   set_draw_state (TEXT_SIZE, fsize);
	   set_draw_state (TEXT_THICKNESS, fthick);
	   set_draw_state (TEXT_SLANT, fslant);
	   GetObjectId (o, &id1, &id2);
	   msg_erase_object (id1, id2);
	   DeletePickedObjects (ss);
           if (strlen(newtext) > 0)
           {
	      bbox = compute_text_box (newtext);

 	      set_draw_color (DrawGCtext, GetLayerColor(GetActiveLayer()));
 
	      /* create compound string from char* */
	      text_xmstring = XmStringCreateLtoR (newtext, XmSTRING_DEFAULT_CHARSET);

	      /* compute size of bounding rectangle */
	      XmStringExtent (text_font_list, text_xmstring, &w, &h);

	      /* draw the text string without changing the background around the text */
	      XmStringDraw (DrawDisplay, DrawWindow, text_font_list, text_xmstring,
			    DrawGCtext, (Position)x1, (Position)y1, w,
			    XmALIGNMENT_BEGINNING, XmSTRING_DIRECTION_L_TO_R, None);

	      msg_draw_text (newtext, fsize, fthick, fslant,
			     x1, y1, bbox.width, bbox.height,
			     ownUserNumber, obj_count);
	      InsertText (ss, x1, y1, bbox.width, bbox.height,
			      newtext, fsize, fthick, fslant,
			      ownUserNumber, obj_count);
	      obj_count++;
           }
	   set_draw_state (TEXT_SIZE, ofsize);
	   set_draw_state (TEXT_THICKNESS, ofthick);
	   set_draw_state (TEXT_SLANT, ofslant);
        }
	else
	{
           PickObject (ss, o);		/* deselect object again */
	}
        break;
  }
}
