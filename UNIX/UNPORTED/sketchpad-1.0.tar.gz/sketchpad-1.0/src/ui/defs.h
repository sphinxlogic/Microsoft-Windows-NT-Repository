/*============================================================================*/
/* definition of constants for all widgets/objects                            */
/*============================================================================*/
/*
 * These numbers are matched with corresponding numbers in the sketchpad
 * uil module.
 */
 
#define   v_main_window                             1
#define     v_menu_bar                              2
#define       v_file_menu_button                    3
#define         v_file_menu                         4
#define           v_file_load_button                5
#define           v_file_save_button                6
#define           v_file_print_button               7
#define           v_file_grab_button                8
#define           v_file_slideshow_button           9
#define           v_file_quit_button               10
#define       v_edit_menu_button                   11
#define         v_edit_menu                        12
#define           v_edit_undo_button               13
#define           v_edit_cut_button                14
#define           v_edit_copy_button               15
#define           v_edit_paste_button              16
#define           v_edit_edit_button               18
#define       v_layer_menu_button                  21
#define         v_layer_menu                       22
#define           v_layer_manage_button            23
#define           v_layer_status_button            24
#define       v_conference_menu_button             31
#define         v_conference_menu                  32
#define           v_conference_list_button         33
#define           v_conference_add_button          34
#define           v_conference_sync_button         35
#define       v_info_button                        41
#define       v_objects_menu_button                51
#define         v_objects_menu                     52
#define           v_objects_select_button          53
#define           v_objects_group_button           54
#define           v_objects_ungroup_button         55
#define           v_objects_align_button           56
#define           v_objects_load_button            57
#define           v_objects_save_button            58
#define       v_attributes_menu_button             61
#define         v_attributes_menu                  62
#define           v_attributes_linestyle_button    63
#define           v_attributes_textstyle_button    64
#define           v_attributes_fillstyle_button    65
#define           v_attributes_zoommag_button      66
#define           v_attributes_selectcolor_button  67

#define     v_draw_functions                       71

#define       v_draw_button_min                  v_draw_button_pointer

#define       v_draw_button_pointer                72
#define       v_draw_button_selector               73
#define       v_draw_button_line                   74
#define       v_draw_button_polyline               75
#define       v_draw_button_freehand               76
#define       v_draw_button_rectangle              77
#define       v_draw_button_circle                 78
#define       v_draw_button_ellipse                79
#define       v_draw_button_arc                    80
#define       v_draw_button_text                   81
#define       v_draw_button_zoom                   82
#define       v_draw_button_move                   83

#define       v_draw_button_max                    v_draw_button_move

#define     v_edit_functions                       84

#define       v_edit_button_min                    v_edit_button_erase
#define       v_edit_button_erase                  85
#define       v_edit_button_cut                    86
#define       v_edit_button_paste                  87
#define       v_edit_button_max                    v_edit_button_paste

#define     v_scrolled_window                      91
#define       v_drawing_area                       92
#define     v_fhg_logo                            101
#define       v_fhg_logo_label                    102
#define       v_audio_button                      103


#define   v_save_box                              111
#define     v_save_box3                           112
#define     v_save_form                           113
#define       v_save_box4                         114
#define       v_save_box_layer_box                115
#define         v_save_box_select_label           116
#define         v_save_box_all_button             117
#define         v_save_box_all_visible_button     118
#define       v_save_box5                         119
#define         v_save_box5_label                 120
#define         v_save_box5_format_option         121
#define         v_save_box5_format_menu           122
#define         v_save_box5_format_gif_button     123
#define         v_save_box5_format_tiff_button    124
#define         v_save_box5_format_sun_button     125
#define         v_save_box5_format_xbm_button     126
#define         v_save_box5_format_jpeg_button    127
#define         v_save_box5_format_pbm_button     128
#define         v_save_box5_format_pm_button      129
#define         v_save_box5_color_option          130
#define         v_save_box5_color_menu            131
#define         v_save_box5_color_full_button     132
#define         v_save_box5_color_grey_button     133
#define         v_save_box5_color_bw_button       134

#define   v_load_box                              141
#define     v_load_box3                           142
#define     v_load_form                           143
#define       v_load_box4                         144
#define       v_load_box5                         145
#define       v_load_box_layer_box                146
#define         v_load_box_select_label           147
#define         v_load_box_all_button             148
#define         v_load_box_file_button            149
#define         v_load_box_picture_button         150
#define         v_load_box_type_label             151

#define   v_message_box                           161
#define     v_message_box_label                   162
#define     v_message_box_text                    163
#define     v_message_box_rc                      164
#define     v_message_box_load_button             165
#define     v_message_box_get_button              166
#define     v_message_box_cancel_button           167

#define   v_print_box                             171
#define     v_print_box2                          172
#define     v_print_box_layer_box                 173
#define       v_print_box_select_label            174
#define       v_print_box_all_button              175
#define       v_print_box_all_visible_button      176
#define       v_print_box_text_label              177
#define       v_print_box_text_box                178
#define       v_print_box_print_button            179
#define       v_print_box_cancel_button           180

#define   v_layer_manage_box                      191
#define     v_layer_manage_box2                   192
#define     v_layer_manage_box3                   193
#define     v_layer_manage_box4                   194
#define       v_layer_manage_box_add_button       195
#define       v_layer_manage_box_delete_button    196
#define       v_layer_manage_box_clear_button     197
#define       v_layer_manage_box_rename_button    198
#define       v_layer_manage_cancel_button        199

#define   v_layer_status_box                      211
#define      v_layer_status_box2                  212
#define      v_layer_status_box3                  213
#define      v_layer_status_box4                  214
#define        v_layer_status_boxA                215
#define          v_layer_status_boxA_label        216
#define        v_layer_status_boxB                217
#define          v_layer_status_boxB_label        218
#define        v_layer_status_boxC                219
#define          v_layer_status_boxC_label        220
#define        v_layer_status_boxD                221
#define          v_layer_status_boxD_label        222
#define        v_layer_status_cancel_button       223

#define  v_conference_add_box                     231
#define    v_conference_add_box2                  232
#define    v_conference_add_box3                  233
#define    v_conference_add_box4                  234
#define    v_conference_add_box5                  235
#define      v_conference_add_box_label3          236
#define      v_conference_add_box_label4          237
#define      v_conference_add_box_label5          238
#define      v_conference_add_box_ok_button       239
#define      v_conference_add_box_cancel_btn      240

#define  v_conference_list_box                    251
#define    v_conference_list_box_label            252
#define    v_conference_list_box_list             253
#define    v_conference_list_box_button           254

#define  v_text_box                               261
#define    v_text_box2                            262
#define      v_text_box_edit_box                  263
#define      v_text_box_clear_button              264
#define      v_text_box_cancel_button             265

#define  v_color_box                              271
#define    v_color_box2                           272
#define      v_color_box_red_label                273
#define      v_color_box_green_label              274
#define      v_color_box_blue_label               275
#define      v_color_box_hue_label                276
#define      v_color_box_sat_label                277
#define      v_color_box_val_label                278
#define      v_color_box_scale_red                279
#define      v_color_box_scale_green              280
#define      v_color_box_scale_blue               281
#define      v_color_box_scale_hue                282
#define      v_color_box_scale_sat                283
#define      v_color_box_scale_val                284
#define    v_color_box3                           285
#define      v_color_box4                         286
#define        v_color_box_ok_button              287
#define        v_color_box_cancel_button          288
#define      v_color_box_color_label              289

#define  v_error_box                              291
#define    v_error_box2                           292
#define      v_error_box_error_list               293
#define      v_error_box_hide_button              294

#define  v_info_box                               301
#define    v_info_box_label                       302
#define    v_info_box_button                      303
#define    v_info_box_logo                        304

#define  v_quit_box                               311
#define    v_quit_box2                            312
#define      v_quit_box_label                     313
#define      v_quit_box_save_button               314
#define      v_quit_box_cancel_button             315

#define  v_nyi                                    321
#define  v_toggle_button                          322
#define  v_push_button                            323

#define  v_zoom_box                               331 
#define    v_zoom_sw                              332 
#define      v_zoom_area                          333 
#define    v_zoom_buttons_rc                      334 
#define      v_zoom_apply_button                  335 
#define      v_zoom_cancel_button                 336 
#define      v_zoom_done_button                   337 
#define    v_zoom_resize_rc                       338
#define      v_zoom_mag_scale                     339
#define      v_zoom_resize_button                 340

#define  v_linestyle_box                          351
#define    v_linestyle_box_thickness_scale        352
#define    v_linestyle_box_style_option           353
#define      v_linestyle_box_style_menu           354
#define        v_linestyle_box_style_solid_button 355
#define        v_linestyle_box_style_dash_button  356
#define    v_linestyle_box_apply_button           357
#define    v_linestyle_box_cancel_button          358
#define    v_linestyle_box_hide_button            359

#define  v_textstyle_box                          371
#define    v_textstyle_box_size_scale             372
#define    v_textstyle_box_option_form            373
#define      v_textstyle_box_thick_option         374
#define        v_textstyle_box_thick_menu         375
#define          v_textstyle_box_thick_b_button   376
#define          v_textstyle_box_thick_m_button   377
#define      v_textstyle_box_slant_option         378
#define        v_textstyle_box_slant_menu         379
#define          v_textstyle_box_slant_r_button   380
#define          v_textstyle_box_slant_i_button   381
#define    v_textstyle_box_apply_button           382
#define    v_textstyle_box_cancel_button          383
#define    v_textstyle_box_hide_button            384

#define  v_zoommag_box                            391
#define    v_zoommag_box_label                    392
#define    v_zoommag_box_apply_button             393
#define    v_zoommag_box_cancel_button            394
#define    v_zoommag_box_hide_button              395
#define    v_zoommag_box_scale                    396

#define  v_jpeg_form                              401
#define    v_jpeg_form_label                      402
#define    v_jpeg_form_scale                      403

#define  v_slideshow_box                          411
#define    v_slideshow_form                       412
#define      v_slideshow_file_label               413
#define      v_slideshow_file_text                414
#define      v_slideshow_file_button              415
#define      v_slideshow_separator_1              416
#define      v_slideshow_next_button              417
#define      v_slideshow_prev_button              418
#define      v_slideshow_separator_2              419
#define      v_slideshow_close_button             420
#define    v_slideshow_text                       421
#define      v_slideshow_text_create              422
#define      v_slideshow_text_select              423

#define  v_slideshow_rc_box                       430 
#define    v_slideshow_rc_prev_button             431 
#define    v_slideshow_rc_next_button             432 
#define    v_slideshow_rc_close_button            433 

#define v_edit_text_box                           440
#define   v_edit_text_box2                        441
#define   v_edit_text_box_edit_box                442
#define   v_edit_text_box_clear_button            443
#define   v_edit_text_box_cancel_button           444
#define   v_edit_text_box_okay_button             445

#define  v_conference_sync_box                    451
#define    v_conference_sync_box_label            452
#define    v_conference_sync_box_list             453
#define    v_conference_sync_box_cancel_btn       454
#define    v_conference_sync_box_okay_btn         455

#define  v_max_widget                             455
