/* $XConsortium: string.h,v 1.1 92/06/11 15:29:56 rws Exp $ */


#include <strings.h>

extern	char	*strchr();
extern	char	*strrchr();
extern	char	*strtok();
extern	char	*strstr();
extern	char	*strdup();
extern	char	*strpbrk();
extern	int	strcspn();
