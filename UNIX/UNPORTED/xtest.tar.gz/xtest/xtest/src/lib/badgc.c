/*
 * Copyright 1990, 1991 by the Massachusetts Institute of Technology and
 * UniSoft Group Limited.
 * 
 * Permission to use, copy, modify, distribute, and sell this software and
 * its documentation for any purpose is hereby granted without fee,
 * provided that the above copyright notice appear in all copies and that
 * both that copyright notice and this permission notice appear in
 * supporting documentation, and that the names of MIT and UniSoft not be
 * used in advertising or publicity pertaining to distribution of the
 * software without specific, written prior permission.  MIT and UniSoft
 * make no representations about the suitability of this software for any
 * purpose.  It is provided "as is" without express or implied warranty.
 *
 * $XConsortium: badgc.c,v 1.6 92/06/11 15:41:15 rws Exp $
 */

#include "xtest.h"
#include "Xlib.h"
#include "Xutil.h"
#include "xtestlib.h"
#include "pixval.h"

/*
 * Return a bad GC id on display disp by creating a GC and 
 * invalidating it using the proposed X Testing extension function
 * XTestSetGContextOfGC.
 */
GC
badgc(disp)
Display	*disp;
{
GC	gc;

	gc = XCreateGC(disp, DefaultRootWindow(disp), 0L, (XGCValues *)0);
	XTestSetGContextOfGC(gc, (GContext)0xFFFFFFFF);
	/* known invalid as top 3 bits set. */

	return(gc);
}
