/* hello -- print a greeting message and exit.
   Copyright (C) 1992 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

#include <stdio.h>
#include "getopt.h"

#ifdef	STDC_HEADERS
#include <stdlib.h>
#else	/* Not STDC_HEADERS */
extern void exit ();
#endif	/* STDC_HEADERS */

struct option longopts[] =
  {
    { "version", 0, 0, 'v' },
    { "help", 0, 0, 'h' },
    { "traditional", 0, 0, 't' },
    { 0, 0, 0, 0 }
  };

extern char version[];

char usage[] = "Usage: %s [-htv] [--help] [--traditional] [--version]\n";

int
main (argc, argv)
     int argc;
     char *argv[];
{
  int optc;
  int h = 0, v = 0, t = 0, lose = 0, z = 0;

  while ((optc = getopt_long (argc, argv, "htv", longopts, (int *) 0)) != EOF)
    {
      switch (optc)
	{
	case 'v':
	  v = 1;
	  break;
	case 'h':
	  h = 1;
	  break;
	case 't':
	  t = 1;
	  break;
	default:
	  lose = 1;
	  break;
	}
    }

  if (optind == argc - 1 && !strcmp (argv[optind], "sailor"))
    z = 1;
  else if (lose || optind < argc)
    {
      /* Print error message and exit.  */
      fprintf (stderr, usage, argv[0]);
      exit (1);
    }

  if (v)
    /* Print version number.  */
    fprintf (stderr, "%s\n", version);

  if (h)
    {
      /* Print help info and exit.  */
      fputs ("This is GNU Hello, THE greeting printing program.\n",
	     stderr);
      fprintf (stderr, usage, argv[0]);
      fputs ("  -h, --help\t\t\tPrint a summary of the options\n", stderr);
      fputs ("  -t, --traditional\t\tUse traditional greeting format\n",
	     
	     stderr);
      fputs ("  -v, --version\t\t\tPrint the version number\n", stderr);
      exit (1);
    }

  /* Print greeting message and exit.  */
  if (z)
    puts ("Nothing happens here.");
  else
    {
      if (t)
        printf ("hello, world\n");
      else
        puts ("Hello, world!");
    }

  exit (0);
}
