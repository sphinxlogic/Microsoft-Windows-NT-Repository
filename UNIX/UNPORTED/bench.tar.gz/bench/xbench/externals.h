extern Display *dpy;
extern Window  win;
extern int     benchRunning;
extern int     screenHeight;
extern int     sync;
