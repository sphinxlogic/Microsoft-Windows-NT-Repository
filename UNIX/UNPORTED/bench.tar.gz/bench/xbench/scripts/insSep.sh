#!/bin/sh

#
# insert _ line after every input line
#

read line
echo $line;
read line                  
while [ "$line" != "" ]; do       
   echo "_"                     
   echo $line                  
   read line                  
done
