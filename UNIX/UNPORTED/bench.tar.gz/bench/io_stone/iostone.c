#ifdef DOCUMENTATION
From eannet@infovax Sat Jan 28 06:34:28 1989
Received: by tumult
	id AA15305; Sat, 28 Jan 89 06:34:19 -0100
Received: by infovax.TUM-Info-LAN (1.2La/R1.4)
	id AA15314; Sat, 28 Jan 89 06:34:22 -0100
Date: Sat, 28 Jan 89 06:34:22 -0100
From: The Great Satan <daemon@cmr.icst.nbs.gov>
Message-Id: <<8901280056.AA20326@cmr.icst.nbs.gov>>
Subject: io_stonec from stones
Apparently-To: hartl@lan.informatik.tu-muenchen.dbp.de
Status: R

Date: Fri, 27 Jan 89 19:56:43 EST
Organization: National Institute of Standards and Technology
Formerly: National Bureau of Standards
Sub-Organization: National Computer and Telecommunications Laboratory
Disclaimer: Opinions expressed are those of the sender
	and do not reflect NIST policy or agreement.

Apparently-To: @RELAY.CS.NET:hartl@lan.informatik.tu-muenchen.dbp.de

Caveat receptor. <nistlib@cmr.icst.nbs.gov> or <nistlib@icst-cmr.arpa>,
[John Antonishek] <ant@cmr.icst.nbs.gov>.
-- with thanks to Eric Grosse at Bell Labs and Jack Dongarra at Argonne Labs
------------------------------------------------------------------------

                       WELCOME TO NISTLIB
                         Formerly NBSLIB

 On August 23, 1988, the National Bureau of Standards became the
         National Institute of Standards and Technology.

This collection of computer performance benchmark routines is or-
ganized  into  a number of subdirectories, primarily by contribu-
tor.

Your attention is directed to subdirectory "export" which con-
tains  the  benchmark  routines  recommended  by  NBSIR  88-3795,
"Benchmarks to Supplant Export 'FPDR'  Calculations",  by  Bailey
(NASA-Ames),  Brooks  (LLNL), Dongarra (ANL), Hayes (LANL), Heath
(ORNL), and Lyon (NIST), June 1988.  These are  mostly  carefully
selected well-known benchmarks which, as a group, are intended to
give a fair picture of the potential performance of a computer in
a  number  of  application  fields.   This report may be obtained
from:

                   US Department of Commerce,
                Office of Export Administration,
             Room 4078, Herbert C. Hoover Building,
                14th and Constitution Avenue, NW,
                      Washington, DC 20230.

Contact (301) 975-5681 if you have difficulty.
Compliments of nbslib   Fri Jan 27 19:56:33 EST 1989
-- nbslib software is in the public domain or else copyrighted by a
   U. S. government contractor which licenses the government to use,
   reproduce, and distribute it.  Neither the United States, nor the 
   Department of Commerce, nor the National Bureau of Standards, nor
   any of its employees, makes any warranty, express or implied, or
   assumes any legal liability or reponsibility for the accuracy,
   completeness, or usefulness of any information, apparatus, product,
   process, or software disclosed or represents that its use would not
   infringe privately owned rights.
------------------------------------------------------------------------
#endif
/*
*	"I/O Stone" Benchmark Program
*
*	Written by:	Arvin Park (park@princeton)
*		Department of Computer Science
*		Princeton University
*		Princeton, New Jersey 08544
*		(609) 452-6304
*
*	Version:  C/1
*	Date:  12/10/86
*
*	Defines: If your version of "C" does not include a time(2)
*		function, define NOTIME. Use a stopwatch to measure
*		elapsed wall time.  Divide 400000 by the elapsed time
*		to get the correct number of iostones/second.
*
*	To compile:  cc -O io.c -o io
*
*	Note:	[1] This program should be run without other processes
*		competing for system resources.  Run it in the dead of
*		night if you have to.
*
*		[2] This program uses 4 megabytes of disk space.  Make
*		sure that at least this much space is available on
*		your file system before you run the program.
*
*		Results: If you get results from a new (machine/operating
*		system/disk controller and drive) combination please
*		send them to park@princeton.  Please include complete
*		information on the machine type, operating system,
*		version, disk controller, and disk drives.  Also make
*		a note of any system modifications that have been
*		performed.
*/

#define FILESIZE (16L*1024L*1024L)	/*size of file in bytes*/
#define MAXBUFFERSIZE (64L*1024L)	/*maximum buffer size*/
#define NBLOCKSIZES 9			/*number of different block sizes*/
#define CONST 100000L			/*iostone normalization constant*/
#define ITER 8 				/*number of iterations of the code*/
/* Define only one of the following two.*/
/*#define NOTIME			/*define if no time function in library*/
#define TIME				/*Use time(2)function*/

char buffer [MAXBUFFERSIZE];		/*a temporary data buffer*/
char *filename [100];			/*name of temporary file*/
unsigned int nbytes;			/*number of bytes transferred*/
int fd;					/*file descriptor*/
long offset;				/*file offset*/
int i,j,k;				/*counter variables*/
long bsize [NBLOCKSIZES];		/*array for different block sizes*/
int bfreq [NBLOCKSIZES];		/*number of accesses for each block*/

#ifdef TIME
 long time();
 long starttime;
 long totaltime;
#endif

main() {
	init();
					/*start timing*/
#ifdef NOTIME
	printf("start timing\n");
#endif
#ifdef TIME
	starttime = time(0);
#endif

	for(k=0; k<ITER; k++)		/*perform string of file operations*/
		readswrites();
					/*stop timer*/
#ifdef NOTIME
	printf("stop timing\n");
#endif
#ifdef TIME
	totaltime = time(0) - starttime;
	printf("total time = %ld\n", totaltime);
	if(totaltime!=0)
		printf("This machine benchmarks at %ld iostones/second\n",
		(long) (CONST*ITER)/totaltime);
#endif
}

init(){
		/* create a temporary file*/
        sprintf (filename, "/tmp/io%ld", time(0));
	if((fd = creat(filename, 0640))<0){
		printf("init: Cannot create temporary file\n");
		exit(1);
	}
		/*To both read and write the file*/
		/*it must be closed then opened*/
	close(fd);
	if((fd = open(filename,2))<0){
		printf("init: Cannot open temporary file\n");
		exit(1);
	}
			/*Unlink the file so that it will*/
			/*disappear when the program*/
			/*terminates.*/
	unlink(filename);

	lseek(fd,0L,0);	/*write initial portion of file*/
	for(i=0; i<(FILESIZE)/4096; i++){
		if((nbytes = write(fd, buffer, 4096))<0){
			printf("init: error writing block\n");
			exit(1);
 		}
	}

			/*set file block sizes and access*/
			/*frequencies.*/
	bsize[0] = 256; bfreq[0] = 128;
	bsize[1] = 512; bfreq[1] = 64;
	bsize[2] = 1024; bfreq[2] = 64;
	bsize[3] = 2048; bfreq[3] = 64;
	bsize[4] = 4096; bfreq[4] = 32;
	bsize[5] = 8192; bfreq[5] = 16;
	bsize[6] = 16384; bfreq[6] = 8;
	bsize[7] = 32768; bfreq[7] = 4;
	bsize[8] = 65536; bfreq[8] = 4;

	srand48(time(0));	/*initialize random number generator*/
}

readswrites(){
	for(j=0; j<NBLOCKSIZES; j++){
		for(i=0; i<bfreq[j]; i++){
			offset=(long) ((mrand48()%(FILESIZE/bsize[j]))*bsize[j]);
			lseek(fd,offset,0);
			if((nbytes = read(fd, buffer, bsize[j]))<0){
				printf("readwrites: read error\n");
				exit(1);
			}
			offset=(long) ((mrand48()%(FILESIZE/bsize[j]))*bsize[j]);
			lseek(fd, offset, 0);
			if((nbytes = read(fd, buffer, bsize[j]))<0){
				printf("readswrites: read error\n");
				exit(1);
			}
			offset=(long) ((mrand48()%(FILESIZE/bsize[j]))*bsize[j]);
			lseek(fd, offset, 0);
			if((nbytes = write (fd, buffer, bsize [j]))<0){
				printf("readswrites: write error\n");
				exit(1);
			}
		}
	}
}

