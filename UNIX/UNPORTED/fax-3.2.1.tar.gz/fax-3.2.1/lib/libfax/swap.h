/*
  swap.h

  (c) Copyright 1991 by David M. Siegel.
      All rights reserved.

  %W% %G% %U%
*/

#ifndef in_libfax_swap_h
#define in_libfax_swap_h 1

/*
  Prototypes:
*/

unsigned char swap_bits(
#ifdef _PROTO
    unsigned char c
#endif
);

#endif
