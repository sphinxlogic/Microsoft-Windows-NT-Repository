/* Entry for the GNATS system.
   Copyright (C) 1993 Free Software Foundation, Inc.
   Contributed by Tim Wicinski (wicinski@barn.com).

This file is part of GNU GNATS.

GNU GNATS is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU GNATS is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU GNATS; see the file COPYING.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

#include <stdio.h>
#include <sys/types.h>

#include <getopt.h>
#include <ansidecl.h>
#ifdef HAVE_SYSLOG_H
#include <syslog.h>
#endif

#include <signal.h>

#include "config.h"
#include "gnats.h"
#include "globals.h"

static void version		PARAMS((void));

/* Name of this program.  */
char *program_name;

/* Whether or not to automatically create a directory for an unrecognized
   category.  Not used (yet).  */
int flag_autocreate = FALSE;

#ifdef LOG_LEVEL
/* Level to log syslog messages at, if we have that ability.  */
int log_level = LOG_LEVEL;
#endif

/* If true, send the submitter an acknowledgement.  */
int flag_ack = ACKNOWLEDGE;

/* If true, send the responsible person mail if they haven't analyzed
   a PR within the designatsed response time.  */
int flag_notify = NOTIFY;

/* Program used to check whether a PR was analyzed within the agreed
   response time or not.  */
char *at_pr = NULL;

struct option long_options[] =
{
  {"mailer", 1, NULL, 'm'},
  {"directory", 1, NULL, 'd'},
  {"file", 1, NULL, 'f'},
  {"version", 0, NULL, 'V'},
#if 0
  {"autocreate", 0, NULL, 'A'},
#endif
  {"debug", 0, NULL, 'D'},
  {"usage", 0, NULL, '?'},
  {NULL, 0, NULL, 0}
};

void
unlock_death ()
{
  signal (SIGSEGV, SIG_DFL);
#ifdef SIGIOT
  signal (SIGIOT, SIG_DFL);
#endif
#ifdef SIGILL
  signal (SIGILL, SIG_DFL);
#endif
#ifdef SIGABRT
  signal (SIGABRT, SIG_DFL);
#endif

  unlock_gnats ();

  /* Tell queue-pr to leave the queue file there.  */
  exit (1);
}

void
main (argc, argv)
     int argc;
     char **argv;
{
  char *logging = NULL;
  FILE *fp = stdin;
  int option;

  /* Path to a PR if the message being processed is a reply.  */
  char *pr_path;

  program_name = basename (argv[0]);

  /* Note: `A' isn't included here yet.  */
  while ((option = getopt_long (argc, argv, "m:d:f:VDh",
				long_options, (int *)0)) != EOF)
    {
      switch (option)
	{
	case 'm':
	  mail_agent = optarg;
	  break;

	case 'd':
	  gnats_root = optarg;
	  break;

	case 'f':
	  fp = fopen (optarg, "r");
	  if (fp == (FILE *)NULL)
	    punt (1, "gnats couldn't read the queue file (%s)", optarg);
	  break;

	case 'V':
	  version ();
	  break;

#if 0
	  /* Don't let them do this yet.  */
	case 'A':
	  flag_autocreate = TRUE;
	  break;
#endif

	case 'D':
	  debug_level = LOG_INFO;
	  break;

	case 'h':
	  /* Fall through.  */

	default:
	    log_msg (LOG_INFO, 0,
		     "[-DV?] [-d gnats-root] [-f filename] [-m mail-program]\n\
\t [--directory=gnats-root] [--file=filename] [--mailer=mail-program]\n\
\t [--debug] [--version] [--usage]\n");
	  exit (-1);
	}
    }

/* Check the options after processing.  Currently, check logging options.  */
  if (logging != NULL)
    {
      if (strcmp (logging, "SYSLOG") == 0)
#ifdef HAVE_SYSLOG_H
	log_method = SYSLOG;
#else
	log_method = MAIL; /* FIXME */
#endif
      else if (strcmp (logging, "MAIL") == 0)
	log_method = MAIL;
      else if (strcmp (logging, "STDERR") == 0)
	log_method = STDERR;
    }

  switch (log_method)
    {
    case MAIL:
      /* FIXME */
      gnats_logfile = open_mail_file (GNATS_ADMIN);
      if (gnats_logfile == (FILE *)NULL)
	punt (1, "can not open mail agent. ");

      fprintf (gnats_logfile, "To: %s\n", GNATS_ADMIN);
      fprintf (gnats_logfile, "Subject: gnats log file\n\n");
      break;
#ifdef HAVE_SYSLOG_H
    case SYSLOG:
      /* Old syslog only takes two arguments and doesn't have facilities
	 like LOG_USER.  The new syslog does.  */
#ifdef LOG_USER
      openlog (program_name, LOG_PID, log_level);
#else
      openlog (program_name, LOG_PID);
#endif
      break;
#endif
    case STDERR:
      gnats_logfile = stderr;
      break;
    default:
      break;
    }


  /* initialize the whole thing, before locking. */
  init_gnats ();

  if (!init_responsibles ())
    punt (1, "can not initialize the responsible chain");

  signal (SIGSEGV, unlock_death);
#ifdef SIGIOT
  signal (SIGIOT, unlock_death);
#endif
#ifdef SIGILL
  signal (SIGILL, unlock_death);
#endif
#ifdef SIGABRT
  signal (SIGABRT, unlock_death);
#endif

  /* lock the whole thing. */
  lock_gnats ();

  /* Read the message header in.  */
  read_header (fp);

  /* Check if the message is a reply to an existing PR; if it is, then
     just append this message to the end of that PR.  Otherwise, process
     it normally.  */
  pr_path = check_if_reply (fp);
  if (pr_path)
    append_report (fp, pr_path);
  else
    gnats (fp);

  /* Clean up.  */
  if (log_method == MAIL)
    close_mail_file (gnats_logfile);
#ifdef HAVE_SYSLOG_H
  else if (log_method == SYSLOG)
    closelog ();
#endif

  /* unlock the whole thing. */
  unlock_gnats ();
  exit (0);
}

static void
version ()
{
  printf ("file-pr %s.\n", version_string);
}
