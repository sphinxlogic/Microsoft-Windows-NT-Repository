/* If you wish to use at_pr (tell the person responsible when a
   PR hasn't been analyzed within its notification period), define
   this macro.  */
#define NOTIFY		TRUE

/* If GNATS should send a reply to the person who submitted the bug, telling
   them the PR number and other information, define this to TRUE.  */
#define ACKNOWLEDGE	TRUE

/* Define this to be the submitter-id to be used when a PR comes in either
   without one, or with a bogus id.  An alternative to "unknown" might be
   "net", if you anticipate getting lots of reports from the Net.  */
#define DEFAULT_SUBMITTER	"unknown"
