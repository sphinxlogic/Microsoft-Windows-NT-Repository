/* Routines to handle messages.
   Copyright (C) 1993 Free Software Foundation, Inc.
   Contributed by Tim Wicinski (wicinski@polyp.barn.com).

This file is part of GNU GNATS.

GNU GNATS is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU GNATS is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU GNATS; see the file COPYING.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

#include <stdio.h>
#include <sys/types.h>

#ifdef HAVE_LIMITS_h
#include <limits.h>
#endif
#ifdef HAVE_SYSLOG_H
#include <syslog.h>
#endif

#include "globals.h"
#include "headers.h"
#include "gnats.h"

typedef struct
{
  /* what you check against */
  char *name;
  /* the stored value that is extracted */
  char *value;
} Header;

Header header[NUM_HEADER_ITEMS];

static short lookup_header		PARAMS((char *));

void
read_header (fp)
     FILE *fp;
{
  int i;
  bool received = FALSE;
  bool headers_found = FALSE;
  char *l;
  char line[STR_MAX];
  char token[STR_MAX];

  while (read_string (line, fp) != -1)
    {
      /* If there's a blank line, get out quickly.  */
    keep_going:
      if (*line == '\n')
	break;

      l = get_token (line, token);
      i = lookup_header (token);
      switch (i)
	{
	case -1:		/* error from lookup_header  */
	  /* no need to print an error for a unknown msg header */
	  break;
	case RECEIVED:
	  /* Only save one `Received:' line.  */
	  if (received == FALSE)
	    {
	      char temp[STR_MAX];
	      char *b;

	      /* If it begins with a tab, it's a typical `Received:' header
		 which provides you with mailer id information.  */
	      read_string (temp, fp);
	      if (*temp != '\t')
		{
		  header[i].value = (char *) strdup (l);
		  strcpy (line, temp);
		  goto keep_going;
		}

	      b = (char *) xmalloc (strlen (l) + strlen (temp) + 2);
	      sprintf (b, "%s%s", l, temp);
	      header[i].value = (char *) strdup (b);
	      free (b);

	      received = TRUE;
	    }
	  else
	    {
	      /* Swallow every `Received:' header after we've gotten our
		 first one.  Only swallow the line after it if it begins
		 with a tab, otherwise we could end up eating a From:
		 line or something equally disastrous.  */
	      read_string (line, fp);
	      if (*line != '\t')
		goto keep_going;
	    }
	  break;
	default:
	  headers_found = TRUE;
	  header[i].value = (char *) strdup (l);
	}
    }

   /* If no headers found, then back up and send it thru read_pr.  */
   if (!headers_found)
     rewind (fp);
}

void 
write_header (fp, string)
     FILE *fp;
     Header_Name string;
{
  register int i;

  if (string != NUM_HEADER_ITEMS)
    fprintf (fp, "%s %s", header[string].name, header[string].value);
  else
    for (i = 0; i < NUM_HEADER_ITEMS; i++)
      if (header[i].value != NULL)
	{
	  if (i == SM_FROM)
	    fprintf (fp, "%s%s", header[i].name, header[i].value);
	  else
	    {
	      if (*header[i].value)
		fprintf (fp, "%s %s", header[i].name, header[i].value);
	      else
		fprintf (fp, "%s\n", header[i].name);
	    }
	}
}

void
init_header ()
{
  memset (&header[0], 0, sizeof (Header) * NUM_HEADER_ITEMS);

  header[SM_FROM].name = "From ";
  header[RETURN_PATH].name = "Return-Path:";
  header[RECEIVED].name = "Received:";
  header[MSG_ID].name = "Message-Id:";
  header[DATE].name = "Date:";
  header[FROM].name = "From:";
  header[SENDER].name = "Sender:";
  header[REPLY_TO].name = "Reply-To:";
  header[TO].name = "To:";
  header[APPAR_TO].name = "Apparently-To:";
  header[CC].name = "Cc:";
  header[IN_REP_TO].name = "In-Reply-To:";
  header[SUBJECT].name = "Subject:";
  header[REFERENCES].name = "References:";
  header[COMMENTS].name = "Comments:";
  header[KEYWORDS].name = "Keywords:";
  header[X_SEND_PR].name = "X-Send-Pr-Version:";
}

/* Look to see if STRING is a mail header we know about.  */
static short 
lookup_header (string)
     char *string;
{
  int i;

  for (i = 0; i < NUM_HEADER_ITEMS; i++)
    if ((header[i].name != NULL && string != NULL)
	&& (strncasecmp (header[i].name, string, strlen (string)) == 0))
      return i;

  return -1;
}

char *
header_name (name)
     Header_Name name;
{
  if (name < 0 || name >= NUM_HEADER_ITEMS)
    return NULL;
  else
    return header[name].name;
}

char *
header_value (name)
     Header_Name name;
{
  if (name < 0 || name >= NUM_HEADER_ITEMS)
    return NULL;
  else
    return header[name].value;
}

void 
set_header (name, string)
     Header_Name name;
     char *string;
{

  if (name < 0 || name >= NUM_HEADER_ITEMS || !string)
    return;

  header[name].value = (char *) strdup (string);
}
