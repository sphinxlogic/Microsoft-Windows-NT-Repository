#!/bin/sh
# Create a send-pr distribution for a GNATS site.
# Copyright (C) 1993 Free Software Foundation, Inc.
# Contributed by Brendan Kehoe (brendan@cygnus.com).
#
# This file is part of GNU GNATS.
#
# GNU GNATS is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# GNU GNATS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with GNU GNATS; see the file COPYING.  If not, write to
# the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

GNATS_ROOT=@GNATS_ROOT@
VERSION=@VERSION@
GNATS_SITE=@GNATS_SITE@

FILES="COPYING README send-pr.sh install-sid.sh send-pr.elisp send-pr.texi \
       send-pr.man send-pr.info texinfo.tex categories"

if [ $# != 2 ]; then
  echo "usage: $0 directory release"
  exit 1
fi
 
if [ ! -d $GNATS_ROOT ]; then
  echo "$0: GNATS base directory $GNATS_ROOT does not exist."
  exit 1
fi

if [ ! -d $GNATS_ROOT/gnats-dist ]; then
  echo "$0: GNATS send-pr distribution directory $GNATS_ROOT/gnats-dist does not exist."
  exit 1
fi

if [ ! -d $1 ]; then
  echo "$0: no such destination directory"
  exit 1
fi

for f in $FILES; do
  if [ ! -f $GNATS_ROOT/gnats-dist/$f ]; then
    echo "$0: could not copy $f to $1"
    exit 1
  fi
  rm -f $1/$f
  cp $GNATS_ROOT/gnats-dist/$f $1
done

cat > $1/Makefile << __EOF__
#
# Makefile for building a standalone send-pr.
#
VERSION=$VERSION
RELEASE=$2

prefix = /usr/local
bindir = $(prefix)/bin
infodir = $(prefix)/info
lispdir = $(prefix)/emacs/lisp
mandir = $(prefix)/man
man1dir = $(mandir)/man1

all: send-pr send-pr.el install-sid

send-pr: send-pr.sh
	sed -e 's/@VERSION@/$(VERSION)/g' \
	    -e 's/@DEFAULT_RELEASE@/$(RELEASE)/g' send-pr.sh > send-pr

send-pr.el: send-pr.elisp
	sed -e 's/@VERSION@/$(VERSION)/g' \
	    -e 's/@DEFAULT_RELEASE@/$(RELEASE)/g' send-pr.elisp > send-pr.el

install-sid: install-sid.sh
	sed -e 's/@VERSION@/$(VERSION)/g' \
	    -e 's/@BINDIR@/$(bindir)/g' install-sid.sh > install-sid

install: all
	if [ -d $(prefix) ]; then true ; else mkdir $(prefix) ; fi
	if [ -d $(bindir) ]; then true ; else mkdir $(bindir) ; fi
	cp send-pr $(bindir)
	chmod 755 $(bindir)/send-pr
	cp install-sid $(bindir)
	chmod 755 $(bindir)/install-sid
	-parent=`echo $(lispdir)|sed -e 's@/[^/]*$$@@'`; \
	if [ -d $$parent ] ; then true ; else mkdir $$parent ; fi
	if [ -d $(lispdir) ] ; then true ; else mkdir $(lispdir) ; fi
	cp send-pr.el $(lispdir)
	cp send-pr.info $(infodir)
	if [ -d $(libdir) ] ; then true ; else mkdir $(libdir) ; fi
	if [ -d $(libdir)/gnats ] ; then true ; else mkdir $(libdir)/gnats ; fi
	cp categories $(libdir)/gnats/$(GNATS_SITE)
	-parent=`echo $(man1dir)|sed -e 's@/[^/]*$$@@'`; \
	if [ -d $$parent ] ; then true ; else mkdir $$parent ; fi
	if [ -d $(man1dir) ] ; then true ; else mkdir $(man1dir) ; fi
	cp send-pr.1 $(man1dir)

clean:
	rm -f send-pr send-pr.el

__EOF__

exit 0
