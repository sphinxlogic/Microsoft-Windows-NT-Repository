/*
 *      (c) Copyright 1990 Sun Microsystems, Inc. Sun design patents
 *      pending in the U.S. and foreign countries. See LEGAL_NOTICE
 *      file for terms of the license.
 */

#ident	"@(#)environ.h	1.5	91/09/14 SMI"

extern	char	**MakeEnviron(/* ScreenInfo *scrInfo */);
