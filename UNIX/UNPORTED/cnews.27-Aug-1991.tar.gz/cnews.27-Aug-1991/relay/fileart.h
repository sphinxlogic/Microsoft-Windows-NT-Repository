/* imports from fileart.c */
extern void filedebug();
extern void fileart();

#define JUNK "junk"			/* lost+found pseudo-ng. */
