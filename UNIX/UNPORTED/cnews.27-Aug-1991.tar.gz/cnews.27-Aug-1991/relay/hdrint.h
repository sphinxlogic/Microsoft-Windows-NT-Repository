/*
 * definitions internal to the header modules (hdr*.c)
 */
#ifdef REALSTDC
#undef REALSTDC
#endif
#ifdef __STDC__
#if __STDC__ >= 1		/* microsoft, etc. brain-damage */
#define REALSTDC		/* truth in advertising: really ANSI */
#endif				/* __STDC__ < 1 */
#endif				/* __STDC__ */

/*
 * using const seemed like a good idea at the time.  then i discovered
 * const-poisoning.
 */
#define const

#ifndef DEFDIST
#define DEFDIST "world"		/* default Distribution: */
#endif

struct hdrdef {
	const char *hdrnm;	/* ascii name */
	unsigned hdrlen;	/* STRLEN(hdrnm) */
	int hdroff;		/* offset into struct header */
};
typedef const struct hdrdef *hdrlist[];

extern const struct hdrdef pathhdr, xrefhdr;
extern const hdrlist reqdhdrs, opthdrs, hdrvilest;

extern boolean headdebug;
