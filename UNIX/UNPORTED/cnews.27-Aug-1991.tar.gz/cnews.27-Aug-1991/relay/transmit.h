/* imports from transmit.c */
extern statust trclose();
extern void transdebug(), transmit(), trcmd(), trbatch();
