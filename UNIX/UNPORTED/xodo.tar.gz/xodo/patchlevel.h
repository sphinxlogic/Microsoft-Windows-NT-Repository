#define VERSION    "1.1"	/* 3 characters exactly */
#define PATCHLEVEL 0		/* xodometer patch level */
