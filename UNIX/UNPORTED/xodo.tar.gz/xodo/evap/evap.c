
#include <ctype.h>
#include <malloc.h>
#include <stdio.h>
#include <sys/types.h>
#include <pwd.h>
#include "evap.h"

FILE   *popen();


evap(argc, argv, pdt, check_parameters_function, pvt)
  int    *argc;
  char   **argv[];
  struct pdt_header pdt;
  int    *check_parameters_function;
  Parameter_Value *pvt;

/*
  Step through the parameters, checking if they are valid, and if they
  require a value that one is specified and that it is valid. Note that
  it changes argv and argc to point to file names that appear AFTER all
  the parameters.  pvt is modified with the new parameter values.
  Because argv[0], the program name, is no longer available after calling
  evaluate_parameters, stuff it into pvt[P_HELP].unconverted_value.
 
  If a help message module is specified in the PDT header, then search the
  message module archive file libevapmm.a for the help text and display it
  if the -help switch is specified on the command line.  If the message
  module cannot be located then generate a short Usage: report.
 
  The check_parameters_function is currently unused and should be NULL.
 
  Complete documentation can be found in the header file evap.h.
 
  Stephen.O.Lidie@CDC1.CC.Lehigh.EDU, 91/12/28. (PDT version 1.0)
    . Original release.
 
  Stephen.O.Lidie@CDC1.CC.Lehigh.EDU, 91/06/24. (PDT version 1.1)
    . Improve error messages.
    . Add type name.
    . Add support for display_command_information (-help) message modules.
    . Fix a small bug in type key handling.
    . Add support for PDTEND file_list option.
 
  Stephen.O.Lidie@CDC1.CC.Lehigh.EDU, 91/08/01. (PDT version 1.1)
    . Allow -- to end command line parameters.
    . Don't print the colon after the type for disci; generate_pdt supplies
      it for us.  This allows the description to be better customized.
    . When type-checking keywords, first search for an exact match ( as is
      currently done) and if that fails, search for a substring match.
    . In a similar manner, when the exact match for a command line parameter
      fails, try a substring match (but not for the alias).
    . If the evaluate_parameters message module is missing, generate a short
      Usage: display.
    . If no parameter alias, use the full spelling for Usage: and -help.
 
  Stephen.O.Lidie@CDC1.CC.Lehigh.EDU, 91/12/02. (PDT version 1.2)
    . Do the 'which' function internally rather than using slow system.
    . exec the ar command to display the message module rather than
      using slow system.
    . If an environment variable is specified as a default value for a
      parameter, the variable is defined and the parameter is not 
      specified, use the value of the environment variable for the
      parameter's value.
 
  lusol@Lehigh.EDU 93/01/02. (PDT version 1.2)  Version 1.4
    . Evaluate parameter values within grave accents, or
      backticks.  Add -usage_help to display_command_information.
      Add support for parameter descriptions in the message module
      file for -full_help.
 
  lusol@Lehigh.EDU 93/02/19. (PDT version 1.2)  Version 1.5
    . Document the interface to X11 Release 4 XGetDefault.
    . For parameters of type File expand $HOME and ~.
    
 
  Copyright (C) 1990 - 1993 by Lehigh University.  All rights reserved.

*/
{

  char   *arg;
  char   *command;
  char   *default_variable;
  short  full_help;
  short  usage_help;
  char   *getenv();
  int    i, j, entry;
  char   *parameter_help[P_MAX_PARAMETER_HELP];
  int    parameter_help_count;
  char   *parameter_help_name;

  char   *strtok();

  full_help = FALSE;		/* assume standard -help (brief) help */
  usage_help = FALSE;		/* assume standard -help (brief) help */

  if (strncmp(pdt.version, "PDT Version", 11) != 0) {
    printf("Error - evaluate_parameters has detected an illegal PDT.\n");
    exit(1);
  }

  if (check_parameters_function != NULL) {
    printf("Informative - check_parameters_function is not supported.\n");
  }

  command = *argv[0];
  pvt[P_HELP].unconverted_value = command;

  while (*argc > 1 && (*argv)[1][0] == '-') {
    (*argc)--;
    arg = *++(*argv);		/* get this parameter */
    arg++;			/* skip over the - */
    if (*arg == '-') return(0); /* allow -- to end command line parameters */
    entry = -1;
    if (strcmp(arg, "full_help") == 0) {
      full_help = TRUE;		/* flag special full help from disci */
      pvt[P_HELP].specified = TRUE;
      continue;			/* while argc */
    }  
    if (strcmp(arg, "usage_help") == 0) {
      usage_help = TRUE;	/* flag special usage help from disci */
      pvt[P_HELP].specified = TRUE;
      continue;			/* while argc */
    }  

    for (i=0; (pvt[i].parameter) != NULL && entry == -1; i++) 
      if ( (strcmp(arg, pvt[i].parameter) == 0) && pvt[i].changeable)
        entry = i;		/* exact match on full form */

    for (i=0; (pvt[i].parameter) != NULL && entry == -1; i++)
      if ( (strcmp(arg, pvt[i].alias) == 0) && pvt[i].changeable)
        entry = i;		/* exact match on alias */

    if (entry == -1) {		/* no match so far, try a substring match */
      for (i=0; (pvt[i].parameter) != NULL; i++) 
        if ( (strncmp(arg, pvt[i].parameter, strlen(arg)) == 0) &&
             pvt[i].changeable) {
          if (entry != -1) {
            printf("Ambiguous parameter: -%s.\n", arg);
            printf("Type %s -help for command line parameter information.\n",
                  pvt[P_HELP].unconverted_value);
            exit(1);
          }
          entry = i;		/* substring match on full form */
        }
    }

    if (entry ==  -1) {
      printf("Invalid parameter: -%s.\n", arg);
      printf("Type %s -help for command line parameter information.\n",
            pvt[P_HELP].unconverted_value);
      exit(1);
    }

    pvt[entry].specified = TRUE; /* mark it as specified by the user */
    if (pvt[entry].type != P_TYPE_SWITCH) { /* value for non-switch types */
      if (*argc > 1) {
        (*argc)--;
        pvt[entry].unconverted_value = *++(*argv);
      } else {
        printf("Value required for parameter -%s.\n", arg);
        printf("Type %s -help for command line parameter information.\n",
              pvt[P_HELP].unconverted_value);
        exit(1);
      }
    } /* ifend */

    evap_type_verification(&pvt[entry], pvt[P_HELP].unconverted_value);

  } /* while argc */

  if (pvt[P_HELP].specified) {	/* display command information */
    if (full_help) {
      printf ("Command Source:  ");
      evap_display_which(command);
      printf ("\nMessage Module Name:  %s\n\n", pdt.help_module_name);
      fflush(stdout);		/* not sure why I NEED this! */
    }

    if ( usage_help || (evap_display_message_module(pdt.help_module_name,
          parameter_help, &parameter_help_count) != 0) )
      evap_display_usage(command, pdt, pvt);

    printf ("\nParameters:\n");
    if ( ! full_help )
      printf( "\n" );
    for (i=0; (pvt[i].parameter != NULL); i++) {
      /* changeable = -1 means valid but HIDDEN from -disci */
      if (pvt[i].changeable == 1) { /*valid and advertisable*/
	if ( full_help )
	  printf( "\n" );
	if (strcmp(pvt[i].alias, "") != 0)
          printf ("-%s, %s%s\n",pvt[i].parameter, pvt[i].alias,
                 pvt[i].description);
        else
          printf ("-%s%s\n",pvt[i].parameter, pvt[i].description);

	if ( full_help && (parameter_help_count >= 0) ) {
	  printf( "\n" );
          if ( i == P_HELP ) {
            printf(
	     "\tIndicates display brief help information, which includes\n" );
            printf(
             "\ta command description with examples, plus a synopsis of\n" );
	    printf(
             "\tthe command line parameters.  If you specify -full_help\n" );
	    printf(
             "\trather than -help complete parameter help is displayed\n" );
	    printf(
             "\tif it's available.\n" );
          }
	  /*
             Search parameter_help for this parameter's description.
	     Each entry is a list of new-line-separated lines - the
	     first line is the name of the parameter.
          */
	  for ( j=0; j <= parameter_help_count; j++ ) {
	    parameter_help_name = strtok( parameter_help[j], "\n" );
	    if ( strcmp( pvt[i].parameter, parameter_help_name ) == 0 ) {
	      printf( "%s", parameter_help[j]+strlen(parameter_help_name)+1 );
	    } /* ifend */
	  } /* forend */
	} /* ifend */
      } /* ifend */ 
    } /* forend */
    if (strncmp(pdt.version, "PDT Version 1.0 ", 16) > 0) {
      if (strcmp(pdt.file_list, "no_file_list") == 0)
	;
      else if (strcmp(pdt.file_list, "required_file_list") == 0) {
        printf("\n file(s) required by this command\n");
      } else {
        printf("\n [file(s)] optionally required by this command\n");
      }
    } /* ifend PDT version 1.1 or greater */
    printf ("\n");
    exit(0);
  }

  /*
    Now loop through the PDT looking for unspecified parameters.

    If there is a default environment variable specified and it is
    defined then update the structure member unconverted_value.

    Then perform type verification.
  */
  if (strncmp(pdt.version, "PDT Version 1.1 ", 16) > 0) {
    for (i = 0; pvt[i].parameter != NULL; i++) {

      if ( i == P_HELP ) continue; /* for */
      if (! pvt[i].specified) {
	if (pvt[i].default_variable != NULL) {
	  if ((default_variable = getenv(pvt[i].default_variable)) != NULL) {
	    pvt[i].unconverted_value = default_variable;
	  } /* ifend */
	} /* ifend default variable */ 
	evap_type_verification(&pvt[i], command);
      } /* ifend parameter not specified */

    } /* forend */
  } /* ifend PDT version 1.2 or greater */

  /*
    Complain if there are any $required parameters.  Perform type conversion.
  */
  for (i=0; (pvt[i].parameter != NULL); i++) {
    if (strcmp("$required", pvt[i].unconverted_value) == 0) {
      printf ("Parameter %s is required but was omitted.\n",
pvt[i].parameter);
      printf("Type %s -help for command line parameter information.\n",
            pvt[P_HELP].unconverted_value);
      exit(1);
    }
    evap_type_conversion(&pvt[i]);
  } /* forend */

  if (strncmp(pdt.version, "PDT Version 1.0 ", 16) > 0) {
    if ((strcmp(pdt.file_list, "no_file_list") == 0) &&
          (*argc > 1)) {
      printf("Trailing file name(s) not permitted.\n");
      printf("Type %s -help for command line parameter information.\n",
            pvt[P_HELP].unconverted_value);
      exit(1);
    } 
    if ((strcmp(pdt.file_list, "required_file_list") == 0) &&
          (*argc == 1)) {
      printf ("Trailing file name(s) required.\n");
      printf("Type %s -help for command line parameter information.\n",
            pvt[P_HELP].unconverted_value);
      exit(1);
    }
  } /* ifend PDT version 1.1 or greater */

} /* end evaluate_parameters */




evap_type_verification(pvte, command_name)
  Parameter_Value *pvte;
  char   *command_name;

/*
  Type-check/initialize the unconverted_value member (a C string).
  Evaluate backticked items.
*/
{

#define BACKMAX 1024

  char   *backcomd;
  int    backcnt;
  int    backincr;
  char   *backline;
  char   *backptr;
  FILE   *backtick;
  int    i;
  int    valid;
  char   *value;
  char   home[6];
  struct passwd *pwent;
  char   *home_ptr;

  if ( pvte->unconverted_value[0] == '`' &&
      pvte->unconverted_value[strlen( pvte->unconverted_value ) - 1] == '`' )
{
    backcomd = (char *)malloc( 10 + strlen( pvte->unconverted_value ) );
    sprintf( backcomd, "echo %s", pvte->unconverted_value );
    if ( (backtick = popen( backcomd, "r" )) != NULL ) {
      backcnt = 1;
      backline = (char *)malloc( BACKMAX * backcnt );
      backptr = fgets( backline, BACKMAX, backtick );
      pvte->unconverted_value = backline;
      while ( backptr != NULL ) {
	backline = (char *) realloc( backline, BACKMAX * ++backcnt );
	pvte->unconverted_value = backline;
	backincr = (BACKMAX * (backcnt - 1)) - (backcnt - 1);
	backptr = fgets( backline+backincr, BACKMAX, backtick );
      }
      pvte->unconverted_value[strlen( pvte->unconverted_value ) - 1] = '\0';
      pclose( backtick );
      free( backcomd );
    } /* ifend backtick evaluation */
  } /* backticks */

  value = pvte->unconverted_value; /* get value from pvt entry */
  switch (pvte->type) {

  case P_TYPE_SWITCH:
    pvte->unconverted_value = "TRUE";
    break;

  case P_TYPE_STRING:
    break; /* anything OK */

  case P_TYPE_REAL:
    if (FALSE) { /* no type enforcment (no U*X consistency either) */
      printf("Expecting real reference, found \"%s\" for parameter -%s.\n",
            pvte->unconverted_value, pvte->parameter);
      printf("Type %s -help for command line parameter information.\n",
            command_name);
      exit(1);
    }
    break;

  case P_TYPE_INTEGER:
    if((isdigit(*value)) || (value[0] == '+') || (value[0] == '-'))
      value++;
    else {
      printf("Expecting integer reference, found \"%s\" for parameter -%s.\n",
            pvte->unconverted_value, pvte->parameter);
      printf("Type %s -help for command line parameter information.\n",
            command_name);
      exit(1);
    }
    for(; *value != '\0'; value++) {
      if(! isdigit(*value)) {
        printf(
         "Expecting integer reference, found \"%s\" for parameter -%s.\n",
              pvte->unconverted_value, pvte->parameter);
        printf("Type %s -help for command line parameter information.\n",
              command_name);
        exit(1);
      }
    }
    break;

  case P_TYPE_BOOLEAN:
    if((strcmp(value, "TRUE") != 0) && (strcmp(value, "FALSE") != 0)) {
      printf("Expecting boolean reference, found \"%s\" for parameter -%s.\n",
            pvte->unconverted_value, pvte->parameter);
      printf("Type %s -help for command line parameter information.\n",
            command_name);
      exit(1);
    }
    break;

  case P_TYPE_FILE:
    home_ptr = NULL;
    strncpy( home, value, 5);	/* look for $HOME or ~ */
    home[5] = '\0';
    if ( strcmp( home, "$HOME" ) == 0) 
      home_ptr = value+5;
    if ( *value == '~')
      home_ptr = value+1;
    if ( home_ptr != NULL ) {	/* expand the shorthand */
      if ( (pwent = getpwuid( getuid() )) != NULL ) {
        pvte->unconverted_value = (char *)malloc( strlen( value ) + strlen(
pwent->pw_dir ) );
	strcpy( pvte->unconverted_value, pwent->pw_dir );
	strcat( pvte->unconverted_value, home_ptr );
	value = pvte->unconverted_value;
      } /* ifend pwent */
    } /* ifend expand $HOME */
    if (strlen(value) > 255) {
      printf("Expecting file reference, found \"%s\" for parameter -%s.\n",
            pvte->unconverted_value, pvte->parameter);
      printf("Type %s -help for command line parameter information.\n",
            command_name);
      exit(1);
    }
    break;

  case P_TYPE_KEY:
    if (pvte->valid_values[0]) {

      for(valid=FALSE, i=0; pvte->valid_values[i] && ! valid; i++)
        if (strcmp(value, pvte->valid_values[i]) == 0)
          valid = TRUE;		/* ok, got one */

      if (! valid)		/* no exact match, try a substring match */
        for(valid=FALSE, i=0; pvte->valid_values[i]; i++)
          if (strncmp(value, pvte->valid_values[i], strlen(value)) == 0) {
            if (valid) {
              printf("Ambiguous keyword for parameter -%s: %s.\n",
                    pvte->parameter, value);
              printf("Type %s -help for command line parameter
information.\n",
                    command_name);
              exit(1);
            }
            valid = TRUE;	/* ok, got one */
            pvte->unconverted_value = pvte->valid_values[i];
          } /* ifend update value in pvt */

      if (! valid) {		/* no matches */
        printf("\"%s\" is not a valid value for the parameter -%s.\n",
               pvte->unconverted_value, pvte->parameter);
        printf("Type %s -help for command line parameter information.\n",
              command_name);
        exit(1);
      }
    }
    break;

  case P_TYPE_APPLICATION:
    break;			/* anything is valid in this case */

  case P_TYPE_NAME:
    for ( ; *value != '\0'; value++ ) {
      if ( *value == ' ' || *value == '\n' || *value == '\t' ) {
	printf("Expecting name reference, found \"%s\" for parameter -%s.\n",
	       pvte->unconverted_value, pvte->parameter);
	printf("Type %s -help for command line parameter information.\n",
	       command_name);
	exit(1);
      }
    }
    break;

  default:
    printf("Error in evap_type_verification (default), please get help!\n");
    exit(1);
    break;
  }
  return;

} /* end evap_type_verification */




evap_type_conversion(pvte)
  Parameter_Value *pvte;

/*
  Convert all the unconverted values, which are C strings, in a type-dependent
  manner, and store the result in the value variant record (union).
*/
{

  char   *value;

  value = pvte->unconverted_value; /* get value from pvt entry */
  switch (pvte->type) {

  case P_TYPE_SWITCH:
    if (strcmp(value, "TRUE") == 0)
      pvte->value.switch_value = TRUE;
    else
      pvte->value.switch_value = FALSE;
    break;

  case P_TYPE_STRING:
    pvte->value.string_value = value;
    break;

  case P_TYPE_REAL:
    sscanf(value, "%lg", &pvte->value.real_value);
    break;

  case P_TYPE_INTEGER:
    sscanf(value, "%d", &pvte->value.integer_value);
    break;

  case P_TYPE_BOOLEAN:
    if (strcmp(value, "TRUE") == 0)
      pvte->value.boolean_value = TRUE;
    else
      pvte->value.boolean_value = FALSE;
    break;

  case P_TYPE_FILE:
    pvte->value.file_value = value;
    break;

  case P_TYPE_KEY:
    pvte->value.key_value = value;
    break;

  case P_TYPE_APPLICATION:
    pvte->value.application_value = value;
    break;

  case P_TYPE_NAME:
    pvte->value.name_value = value;
    break;

  default:
    printf("Error in evap_type_conversion (default), please get help!\n");
    exit(1);
    break;
  }
  return;

} /* end evap_type_conversion */




evap_display_message_module(message_module_name, parameter_help,
			    parameter_help_count)
 char   *message_module_name;
 char   *parameter_help[];
 int    *parameter_help_count;

/*
  Search an evaluate_parameters message module file for the specified help
  module and, if found, display it.
 
  The message_module_name parameter is either a simple message module name or
  a message module name prefixed with the path name of a local message module
  archive file.  For example:
 
    disci.mm               names a message module disci.mm in file libevapmm.a
    my_mm/my_program.mm    names a message module my_progam.mm in file my_mm
*/
{

  FILE*  a;			/* stream to read ar output from */
  char   afn[256];		/* evap ar message module path name */
  char   ar_str[512];		/* ar p libevapmm.a mm */
  char*  cp;			/* character pointer */
  short  parameter_help_in_progress;

  extern char *strrchr();	/* string.h vs. strings.h hassles!!!! */
				/* freakin' U*X inconsistencies...    */

  if (message_module_name == NULL)
    return;			/* if no message module specified */

  cp = strrchr(message_module_name, '/'); /* check for local archive path */
  if (cp == NULL) {		/* simple message module name */
    strcpy(afn, P_EVAP_MM_PATH); /* use default ar file name */
  } else {			/* private message module ar file */
    *cp = '\0'; /* separate file path name and message module name */
    strcpy(afn, message_module_name);
    strcpy(message_module_name, cp+1);
  } /* ifend simple message module */

  sprintf(ar_str, "ar p %s %s 2> /dev/null", afn,
        message_module_name);

  *parameter_help_count = -1;	/* no parameters have help so far */
  parameter_help_in_progress = FALSE; /* not collecting parameter help */

  if ( (a = popen( ar_str, "r" )) == NULL )
    return( 1 );		/* do usage */

  if ( fgets( ar_str, 512, a ) == NULL )
    return( 1 );		/* do usage */

  do {				/* copy message module until EOF */
    if ( ar_str[0] == '.' ) {	/* or until start of parameter help */
      parameter_help_in_progress = TRUE;
      /*
	Create an array of parameter help: the first line is the parameter
	name and successive lines are the associated help text.
      */
      (*parameter_help_count)++;
      parameter_help[*parameter_help_count] =
	(char *)malloc( P_MAX_PARAMETER_HELP_LENGTH );
      strcpy( parameter_help[*parameter_help_count], ar_str+1 );
      continue; /* do */
    } /* ifend start of parameter help */
    if ( parameter_help_in_progress ) {
      if ( strlen( parameter_help[*parameter_help_count] ) + strlen( ar_str )
	  < P_MAX_PARAMETER_HELP_LENGTH ) {
	strcat( parameter_help[*parameter_help_count], ar_str );
      } else {
	sprintf( ar_str,
		"\n*** Parameter Help Text Exceeds %d Characters ***\n",
		P_MAX_PARAMETER_HELP_LENGTH );
	strcpy( parameter_help[*parameter_help_count] +
	       P_MAX_PARAMETER_HELP_LENGTH - strlen( ar_str ) - 1,
	       ar_str );
      }
    } else {
      printf( "%s", ar_str );
    }
  } while (fgets( ar_str, 512, a) != NULL); /* doend */
  pclose( a );

  return(0);			/* success */

} /* end evap_display_message_module */





evap_display_usage(command, pdt, pvt)
  char   *command;
  struct pdt_header pdt;
  Parameter_Value pvt[];

/*
  Generate a 'standard' usage display in lieu of a help message module.
*/
{

  int    i;
  int    optional_param_count;

  optional_param_count = 0;
  printf("\nUsage: %s", command);

  for(i=0; pvt[i].parameter != NULL; i++) {
    if (pvt[i].changeable == 1) { /* valid and advertisable */
      optional_param_count++;
      if (strcmp(pvt[i].unconverted_value, "$required") == 0) {
        optional_param_count--;
        if (strcmp(pvt[i].alias, "") != 0)
          printf(" -%s", pvt[i].alias);
        else
          printf(" -%s", pvt[i].parameter);
      } /* ifend */
    } /* ifend */
  } /* forend */

  if (optional_param_count > 0) {
    printf(" [");
    for(i=0; pvt[i].parameter != NULL; i++) {
      if (pvt[i].changeable == 1) { /* if advertisable */
        if (strcmp(pvt[i].unconverted_value, "$required") != 0) {
          if (strcmp(pvt[i].alias, "") != 0)
            printf(" -%s", pvt[i].alias);
          else
            printf(" -%s", pvt[i].parameter);
        } /* ifend */
      } /* ifend */
    } /* forend */
    printf("]");
  } /* ifend */

  if (strncmp(pdt.version, "PDT Version 1.0 ", 16) > 0) {
    if (strcmp(pdt.file_list, "required_file_list") == 0)
      printf(" file(s)\n");
    else if (strcmp(pdt.file_list, "optional_file_list") == 0)
      printf(" [file(s)]\n");
    else
      printf("\n");
  } /* ifend PDT version 1.1 or greater */
  else
    printf("\n");

} /* end evap_display_usage */




evap_display_which(command)
  char   *command;

/*
  Perform a fast 'which' function to show the source of this command.
  (Copied from which.c on UUNET.UU.NET, but with a few bug fixes.)
*/
{

  char   *getenv(), *path = getenv("PATH");
  char   test[1000], *pc, save;
  int    len, namelen = strlen(command), found;

  extern char *strrchr();	/* string.h vs. strings.h hassles! */
  char name[256];		/* name exclusive of path */
  char *cp;			/* character pointer */  

  cp = strrchr(command, '/');	/* look for path separator */
  if (cp == NULL)
    strcpy(name, command);	/* if a simple file name */
  else {
    printf("%s\n", command);	/* must be an explicit path */
    return(0);
  }

  pc = path;
  found = 0;

  while (*pc != '\0' && found == 0) {
    len = 0;

    while (*pc != ':' && *pc != '\0') {
      len++;
      pc++;
    } /* whilend */

    save = *pc;
    *pc = '\0';
    sprintf(test, "%s/%s", pc-len, name);
    *pc = save;
    if (*pc)
      pc++;

    found = (0 == access(test, 01)); /* executable */
    if (found)
      puts(test);

  } /* whilend */

  return 0;

} /* end evap_display_which */
