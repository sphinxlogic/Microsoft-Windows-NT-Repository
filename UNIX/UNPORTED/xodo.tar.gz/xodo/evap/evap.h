#if 0

  evap.h - header file for evaluate_parameters (PDT Version 1.2)

  Copyright (C) 1990 - 1993 by Lehigh University.  All rights reserved.


                               Table of Contents

  Revision History
  Introduction
  PDT Syntax
  Creating a PDT
  Usage Notes
  Separately Compiled Modules
  Further Information on Types
  Special Default Value $required
  Using Environment Variables as Default Values
  Customization of the PDT Structure
  Interface to X11 Release 4 XGetDefault
  Human Interface Guidlines
  Installation
  Display Command Information
  Adding New Message Modules
  Notes and Cautions
  Acknowledgment


                               Revision History                            

  Stephen.O.Lidie@CDC1.CC.Lehigh.EDU, LUCC, 90/12/28. (PDT version 1.0)
    . Original release - evaluate_parameters and generate_pdt.

  Stephen.O.Lidie@CDC1.CC.Lehigh.EDU, LUCC, 91/07/01. (PDT version 1.1)
    . Minor bug fixes in generate_pdt.
    . Add support for the name type.
    . Add the new command display_command_information (disci).
    . Add support for help message modules.
    . Add the new command add_message_modules (addmm).
    . Minor bug fix in evaluate_parameters handling of key type.
    . Improve evaluate_parameters error messages.
    . Provide an install script for VX/VE, EP/IX, SunOS, Stardent and AIX.
    . Add support for PDTEND file_list option.
    . Add -qualifier parameter to generate_pdt so that the PDT/PVT names
      can be qualified for 'multiple entry point' programs.  Similar to
      COMPASS QUAL blocks.

   Stephen.O.Lidie@CDC1.CC.Lehigh.EDU, LUCC, 91/08/01. (PDT version 1.1)
    . Allow -- to end command line parameters.
    . Don't print the colon after the type for disci; generate_pdt supplies
      it for us.  This allows the description to be better customized.
    . When type-checking keywords, first search for an exact match (as is
      currently done) and if that fails, search for a substring match.
    . In a similar manner, when the exact match for a command line parameter
      fails, try a substring match (but not for the alias).
    . If the evaluate_parameters message module is missing, generate a short
      Usage: display.
    . If no parameter alias, use the full spelling for Usage: and -help.

   Stephen.O.Lidie@CDC1.CC.Lehigh.EDU, LUCC, 91/12/02. (PDT version 1.2)
    . Do the 'which' function internally rather than using slow system.
    . exec the ar command to display the message module rather than
      using slow system.
    . If an environment variable is specified as a default value for a
      parameter, the variable is defined and the parameter is not 
      specified, use the value of the environment variable for the
      parameter's value.
 
  lusol@Lehigh.EDU 93/01/02. (PDT version 1.2)  Version 1.4
    . Evaluate parameter values within grave accents, or
      backticks.  Add -usage_help to display_command_information.
      Add support for parameter descriptions in the message module
      file for -full_help.
 
  lusol@Lehigh.EDU 93/02/19. (PDT version 1.2)  Version 1.5
    . Document the interface to X11 Release 4 XGetDefault.
    . For parameters of type File expand $HOME and ~.
  


                                 Introduction

  Function evaluate_parameters parses a U*X command line in a simple and
  consistent manner, performs type checking of parameter values, and provides
  the user with first-level help.  evaluate_parameters handles command lines
  in the following format:

    command [-parameters] [file_list]

  where parameters and file_list are all optional.  A typical example is the
  C compiler:

    cc -O -o chunk chunk.c

  In this case there are two parameters and a file_list consisting of a
  single file name for the cc command.

  There are several advantages to using evaluate_parameters in all your C
  programs:

    - Every program calling evaluate_parameters has a -help switch which
      lists all the command line arguments and their aliases, the types
      of parameter values they expect, and their default values.  Many U*X
      commands have no man pages so this first-level help is the only help
      available to a user.  This is provided automatically as part of
      evaluate_parameters; no code is required in your application.  

      An optional help message module can be defined to provide additional
      help.  (See the section Adding New Message Modules.)

    - The command display_command_information is available which emulates its
      NOS/VE counterpart.  This command displays information about any command
      using evaluate_parameters.

    - Because evaluate_parameters allows command line arguments to have an
      alias, parameters can be given meaningful names which a user can readily
      understand.  Hackers, on the other hand, can use the abbreviation to
      speed their work.

    - evaluate_parameters verifies that the value specified for a command
      line argument is of the appropriate type. Types currently supported are
      switch, string, real, integer, boolean, file, key, application and name.
      Parameter values are available in two forms; unconverted C strings and
      type-converted values.

    - Your job of developing applications is simplified because you don't
      waste time writing code to process arguments again, and again, and
again!

    - Automatic man page generation for programs calling evaluate_parameters.

    - New versions of evaluate_parameters will guarantee backward
compatability
      with previous versions until the Universe ends.

    - Most importantly, as long as you adhere to the Human Interface
Guidlines,
      evaluate_parameters provides for a consistent user interface.

  Using evaluate_parameters is extremely easy:

    1) Create a Parameter Description Table, analogous to a C function
       prototype, which names all command line arguments and their types.
       Additionally, a PDT specifies the parameter alias and a default value.
       (Optionally, a help message module can be defined which names a text
       file of additional help information.  See Adding New Message Modules
       for more information.)

    2) Feed the PDT to program generate_pdt, which generates a C structure
       that can be #included into your application.  This structure, known
       as a Parameter Description Table (PDT) assists evaluate_parameters in
       parsing the command line.

    3) Call evaluate_parameters in function main.  Command line parameters
       are scanned and their values are stored in the PDT for later use.

    4) (Optionally, add a help message module to the message module archive
       file.  See Adding New Message Modules for more details.)

  Examine addmm.c for an extremely simple example of using
evaluate_parameters.


                                 PDT Syntax

  Here is the PDT syntax.  Optional constructs are enclosed in [], and the
  | character separates possible values in a list.

    PDT [(message_module_name.mm)] [program_name, program_alias]
      [parameter_name[, parameter_alias]: parameter_type [ = default_value]]
    PDTEND [optional_file_list | required_file_list | no_file_list]

  So, the simplest possible PDT would be:

    PDT
    PDTEND

  This PDT would simply define a -help switch for the command, but is rather
  useless. 

  A typical PDT would look more like this:

    PDT (frog.mm) frog
      number, n: integer = 1
    PDTEND no_file_list

  This PDT, for command frog, defines a help message module frog.mm and a
  single parameter, number (or n), of type integer with a default value of 1.
  The PDTEND no_file_list indicator indicates that no trailing file_list
  can appear on the command line.  Of course, the -help switch is defined
  automatically.

  The default_value can also be an environment variable - see the section
  Using Environment Variables as Default Values for complete details.


                                Creating a PDT

  evaluate_parameters requires a Parameter Description Table (PDT) to guide it
  in parsing the command line.  The program generate_pdt interprets a
  Parameter Description Table (PDT) and generates C statements that declare
  and initialize the PDT.  Here is generate_pdt's PDT; it declares -input (or
  -i) and -output (or -o) parameters, of type file, and that default to
  standard input and standard output, respectively.  The -qualifier (or -q)
  parameter, of type string, defaults to an empty string.

    PDT (genpdt.mm) generate_pdt, genpdt
      input, i: file = stdin
      output, o: file = stdout
      qualifier, q: string = ""
    PDTEND no_file_list

  A PDT for the 'mini' C compiler example described in the Introduction could
  be:

    PDT cc
      Optimize, O: switch
      object, o: file
    PDTEND optional_file_list

  The PDT says that the Optimize parameter can have no parameter value; that
  is, it must stand alone.  The object parameter is of type file.  An
  optional file_list can follow the command line parameters.

  If cc used evaluate_parameters with this PDT a user could envoke the
  compiler in various ways, some of which are more obvious than others (of
  course, the command line parameters could be specified in any order):

    cc -Optimize -object chunk chunk.c
    cc -Optimize -o chunk chunk.c
    cc -O -object chunk chunk.c
    cc -O -o chunk chunk.c

  A special -help (or -disci) parameter is automatically generated.  Executing
  any command that uses evaluate_parameters and specifying the -help option
  produces a display of all command line arguments for that command, similar
  to NOS/VE's DISPLAY_COMMAND_INFORMATION.  Continuing our cc example, the
  following command:

    cc -help

  would produce this first-level help display:

    Name:  cc

    Parameters:

    -help, disci: Display Command Information
    -Optimize, O: switch
    -object, o: file

     [file(s)] optionally required by this command

  The first line of a Parameter Description Table declaration must be PDT (or
  pdt) and the last line must be PDTEND (or pdtend).  Everything in between
  defines one or more command line arguments, one per line.  The synatx is
  similar to CYBIL, Pascal and C function headers:  a parameter name followed
  by an optional alias, a colon followed by the type of parameter (switch,
  string, real, integer, boolean, file, key, application, name) and an equal
  sign followed by the parameter's default value.

  With this information evaluate_parameters can parse a command line in a
  consistent manner, perform type checking, and provide first-level help via
  the -help parameter, similar to NOS/VE's System Command Language.

  Here are examples of all the supported types:

    PDT beam
      verbose, v: switch
      command, c: string = "ps -el"
      scale_factor, sf: real = 1.23408900023456e-1
      millisecond_update_interval, mui: integer = 500
      ignore_output_file_column_one, iofco: boolean = TRUE
      output, o: file = stdout
      queue, q: key plotter, postscript, text, printer, keyend = printer
      destination, d: application = `hostname`
      tty, t: name = /dev/console
    PDTEND optional_file_list


                                 Usage Notes

  Here are two sample main programs that simply print the envoking command's
  name, command line arguments as described by the PDT, and all file names.
  They are essentially identical, although the first uses the array approach
  and prints the unconverted values (stored as C strings), while the second
  uses pointers and prints the converted values (stored as a type appropriate
  for the parameter).  These programs are patterned after the examples in K&R,
  page 115, second edition.  There are a few items worth noting in each:

    1) The first executable statement in your C application must be a call
       to evaluate_parameters.

                                    NOTE

            Because of variations in U*X implementations, the actual
            name of evaluate_parameters is evap.  This unobvious name
            was chosen simply because it was short enough to prevent
            problems with C compilers, loaders and archive programs.
            The real name, evaluate_parameters, will continue to be
            used everywhere except in actual examples.

    2) evaluate_parameters increments argv and decrements argc as it parses
       the command line, leaving argv pointing to just before the file
       names (if any).  The net result is that argc will be >= 1.  If it is
       one, there are no trailing file names.  This is analogous to the
       situation where a command, not using evaluate_parameters, is envoked
       with no parameters; argc = 1 and argv simply points to the envoking
       program's name.

    3) Parameter values are stored in the Parameter Value Table structure
       (pvt) in a format appropriate for the type (string for string, long
       double for real, int for integer, short for boolean, etcetera).  The
       unconverted parameter value is also available as a C string.

    4) Because of item #2 above, the name of the program in argv[0] is no
       longer available.  Therefore, evaluate_parameters stores it in the PDT
       structure pvt[P_HELP].unconverted_value just in case you need it.

  Assume that the file beam_pdt_in contains the PDT described at the end of
  the section Creating a PDT.  First use the command generate_pdt to convert
  the file beam_pdt_in into a C structure declaration for use by your
  application and evaluate_parameters:

      generate_pdt -input beam_pdt_in -output beam_pdt_out

  The resulting PDT declaration on file beam_pdt_out can be included in main:

  Sample main using arrays:

    #include <evap.h>
    #include "beam_pdt_out"

    main (argc, argv)
          int argc;
          char *argv[];

    /* evaluate_parameters, array version, unconverted values. */

    {
      int i;

      evap (&argc, &argv, pdt, NULL, pvt);
      printf("\nProgram name:\n  %s\n", pvt[P_HELP].unconverted_value);

      if (P_NUMBER_OF_PARAMETERS > 1 ) {
        printf("\nCommand line parameters and values:\n");
        for (i=1; i < P_NUMBER_OF_PARAMETERS; i++)
          printf("  Parameter %s=\"%s\"\n", pvt[i].parameter,
                pvt[i].unconverted_value);
      }

      if (argc > 1) {
        printf("\nFile names:\n  ");
        for(i=1; i < argc; i++)
          printf("%s%s", argv[i], (i < argc-1) ? " " : "");
        printf("\n");
      }
    } /* end main */


  Sample main using pointers:

    #include <evap.h>
    #include "beam_pdt_out"

    main (argc, argv)
          int argc;
          char *argv[];

    /* evaluate_parameters, pointer version, type-converted values. */

    {
      Parameter_Value *pvte; /* parameter value table entry */

      evap (&argc, &argv, pdt, NULL, pvt);
      printf("\nProgram name:\n  %s\n", pvt[P_HELP].unconverted_value);

      if (P_NUMBER_OF_PARAMETERS > 1) {
        printf("\nCommand parameters and values:\n");
        pvte = &pvt[1];
        while (pvte->parameter != NULL) {
          switch (pvte->type) {

          case P_TYPE_SWITCH:
            printf("  switch      parameter %s=%d\n", pvte->parameter,
                  pvte->value.switch_value);
            break;

          case P_TYPE_STRING:
            printf("  string      parameter %s=\"%s\"\n", pvte->parameter,
                  pvte->value.string_value);
            break;

          case P_TYPE_REAL:
            printf("  real        parameter %s=%.15lg\n", pvte->parameter,
                  pvte->value.real_value);
            break;

          case P_TYPE_INTEGER:
            printf("  integer     parameter %s=%d\n", pvte->parameter,
                  pvte->value.integer_value);
            break;

          case P_TYPE_BOOLEAN:
            printf("  boolean     parameter %s=%d\n", pvte->parameter,
                  pvte->value.boolean_value);
            break;

          case P_TYPE_FILE:
            printf("  file        parameter %s=\"%s\"\n", pvte->parameter,
                  pvte->value.file_value);
            break;

          case P_TYPE_KEY:
            printf("  key         parameter %s=\"%s\"\n", pvte->parameter,
                  pvte->value.key_value);
            break;

          case P_TYPE_APPLICATION:
            printf("  application parameter %s=\"%s\"\n", pvte->parameter,
                  pvte->value.application_value);
            break;

          case P_TYPE_NAME:
            printf("  name        parameter %s=\"%s\"\n", pvte->parameter,
                  pvte->value.name_value);
            break;

          default:
            printf("Error!  Murphy says 'Plugh'!\n");
            break;
          } /* casend */

          pvte++; /* next parameter value table entry */

        } /* whilend */
      }

      if (argc > 1) {
        printf("\nFile names:\n  ");
          while (*++argv != NULL)
            printf("%s%s",*argv, (*argv != NULL) ? " " : "");
        printf("\n");
      }
    } /* end main */


  Parameter names and their aliases can be at most 31 characters long.

  The values for parameters are stored in a format appropriate for their type.
  Please examine the pvt structure (below) for complete details.  Parameter
  values are also available, as a C string, exactly as they appeared on the
  command line.

  Each parameter has a structure of type parameter_value, which is defined
  below.  All the parameter structures are grouped together in a Parameter
  Value Table array named pvt, which is an array of elements of type
  parameter_value.  An application indexes into the pvt array using a defined
  symbol of the form P_FULL_PARAMETER_NAME.  So, to access the parameter_value
  structure for the scale_factor, references of the following form would be
  used:

    sf = pvt[P_SCALE_FACTOR].value.real_value; /* get long double value */

  After calling evaluate_parameters, a program accesses the PDT structure for
  information on what parameters were specified and their values.  To
  determine if the verbose switch in the example above was specified code such
  as the following could be used:

    if(pvt[P_VERBOSE].specified)
        ... do verbose stuff ...
    else
        ... do quiet stuff ...

  Of course, there are numerous examples of PDT code in the C source files
  genpdt.c, disci.c and addmm.c.


                          Separately Compiled Modules

  evaluate_parameters can be used when you compile C functions separately from
  main.  Include <evap.h> as usual and include the PDT structure created by
  generate_pdt too.  Define the symbol P_EVAP_EXTERN somewhere before the
  include for the PDT structure.  This will declare the Parameter Value Table
  (pvt) as an external and will not allocate storage.  For example:

    #include <evap.h>
    #define P_EVAP_EXTERN
    #include "beam_pdt_out"

    void test_func()
    {
      printf("Program name is %s\n", pvt[P_HELP].unconverted_value);
    }


                         Further Information on Types

  The switch type is a special type that emulates the typical U*X standalone
  switch.  It means that no parameter value can appear after the switch.
  evaluate_parameters treats this type similarly to a boolean type:  the value
  in the PDT structure is initialized to FALSE, and if the switch parameter is
  specified the value is reset to TRUE.  You can therefore use either of the
  structure members specified or value to test if the parameter was specified
  on the command line.  The switch type is short int.

  The string type is simply a C string.

  The real type is a floating point number.  Currently, there is no type
  checking for this type.  A real number on my machine (a CYBER) ranges from
  -5.221944407065762533458763552E+1232 to 5.221944407065762533458763552E+1232.
  The real type is long double.

  The integer type is an integer number.  Range is -9223372036854775808 to
  9223372036854775807, at least on real machines :-).  The integer type is
  int.

  The boolean type is either TRUE or FALSE.  The boolean type is short int.

  The file type is a standard U*X file name, which as far as I can tell can be
  any random string of characters, as long as its length is less than 256.
  Here is sample C code to process the output file defined previously (o is a
  variable of type FILE *):

    if (pvt[P_OUTPUT].specified) {
      if ((o=fopen(pvt[P_OUTPUT].value.file_value, "w")) == NULL) {
        printf("Cannot open output file!\n");
        exit(1);
      }
    } else  /* just use standard output */
      o = stdout;

  The key type is a special type that enumerates valid values.  The queue
  parameter in a previous example above only recognizes the values plotter,
  postscript, text, and printer.  evaluate_parameters will not accept other
  values for this parameter.  Currently, a maximum of 32 values can be
  specified.  The key type is a C string.

  The applicaton type is a special type that is not type checked because its
  interpretation is application specific.  This means that anything can be
  specified for this type of parameter.

  The name type is a string of characters without imbedded spaces.  It is just
  like a string except that it can be specified without the bounding quotes.
  If you require a parameter that may included imbedded spaces use a string.


                        Special Default Value $required

  All parameters can have a special default value $required.  When this
  default is specified, evaluate_parameters will ensure that the parameter is
  specified and given a valid value.


                  Using Environment Variables as Default Values

  Consider the following PDT:

    PDT (frog.mm) frog
      number, n: integer = D_FROG_NUMBER, 1
    PDTEND no_file_list

  The integer parameter number (or n) has a default value of 1.  However,
  if the environment variable D_FROG_NUMBER is defined AND if number is
  not specified on the command line, evaluate_parameters will use the value
  of the environment variable as the parameter's default value.  With this
  feature users can easily customize command parameters to their liking.

  Although the name of the environment variable can be whatever you choose,
  the following scheme is suggested for consistency and to avoid conflicts
  in names:  

    . Use all uppercase characters.
    . Begin the variable name with D_, to suggest a default variable.
    . Continue with the name of the command followed by an underscore.
    . Complete the variable name with the name of the parameter or its
      alias.

  So, for example, D_DISCI_DO would name a default variable for the
  display_option (do) parameter of the display_command_information
  (disci) command.


                       Customization of the PDT Structure

  The PDT structure parameter_value is defined below, and, although
  initialized by generate_pdt, can be customized in the following ways:

    . You can change the description as displayed by -help.
    . You can change the changeable member to -1 so that a parameter is
      not advertised in response to a -help, although it can still be
      changed by the user, similar to the NOS/VE HIDDEN attribute.


                     Interface to X11 Release 4 XGetDefault

  For X11 applications call evaluate_parameters as usual then open the X
  display.  You can then use code similar to the following to establish
  default X values for all unspecified command line parameters:

  /*
     For all unspecified parameters see if there is an X default value. 
     Variable "i" is type integer and "X_default" is type char *.       
  */

  for ( i = 0 ; i < P_NUMBER_OF_PARAMETERS; i++ ) {
    if ( ! pvt[i].specified ) {
      X_default = XGetDefault( theDisplay, ProgramName, pvt[i].parameter );
      if ( X_default != NULL ) {
        pvt[i].unconverted_value = X_default;
        evap_type_conversion( &pvt[i] ); /* convert string to proper type */
      } /* ifend non-null X default for this parameter */
    } /* ifend unspecified parameter */
  } /* forend all evaluate_parameters parameters */



                           Human Interface Guidlines

  To make evaluate_parameters successful, you, the application developer, must
  follow certain conventions when choosing parameter names and aliases.

  Parameter names consist of one or more words, separated by underscores, and
  describe the parameter (for example, OUTPUT and TERMINAL_MODEL).

  You can abbreviate parameters:  use the first letter of each word in the
  parameter name.  Do not use underscores.  For example, you can abbreviate
  Command as C and Delay_Period as DP.

  There are exceptions to this standard:

    - PASSWORD is abbreviated PW.
    - The words MINIMUM and MAXIMUM are abbreviated MIN and MAX.  So, the
      abbreviation for the parameter maximum_byte_count is maxbc.


                                 Installation

  Execute the shell script install_evap, probably as root, which seems to
  work on EP/IX, SunOS, AIX and Stardent; changes may be required for your
  particular flavor of U*x.  For VX/VE use the install_evap_vxve script.

  The default catalog for the install is /usr/local.  If this is not
  appropriate for your machine then edit the script and change the value
  of the variables INC, LIB and BIN.


                           Display Command Information

  Besides evap.c, genpdt.c and addmm.c, this package includes the
  special command display_command_information (disci).  disci does just what
  it says:  it displays information about any evap-compliant command (that is,
  any application that uses evaluate_parameters to parse its command line).
  There are usage, brief and full display options on the command.  For
example,
  try disci on itself:

    display_command_information -command disci

  This will give brief command information.  Then examine the full display:

    disci -c disci -do f

  Try disci on generate_pdt and add_message_modules too.


                            Adding New Message Modules

  A message module is simply a text file of additional information used by
  disci (in reality evaluate_parameters).  Message modules for applications
  using evaluate_parameters are maintained in an archive file named
  libevapmm.a, typically in the catalog /usr/local/lib.  The name of the
  message module associated with a command is stored in the command's PDT. 
  Please examine the files in the directory message_module for examples.
  So, to create a message module for your command you must do two things:

    1) Use the add_message_modules (addmm) command to add your help text
       to the ar message module database.  Use a text editor and create
       your file, with a name of the form hhhh.mm, where hhhh is the
       name of your application (the .mm 'extension' implies a message
       module).  The file name cannot exceed 14 characters, a limit 
       imposed by the ar utility.  Then:

         add_message_modules hhhh.mm

    2) Modify the command's PDT to include the name of this file.  Either
       manually change the pdt_header structure member help_module_name
       from NULL to "hhhh.mm" (not recommended), or re-create your PDT
       using generate_pdt (highly recommended).  The message module name 
       is specified on the PDT statement:

         PDT (hhhh.mm) command_hhhh
           parameter declarations ...
         PDTEND required_file_list

       Examine the sample PDTs in the catalog pdt.  Then simply re-compile.

  You can maintain a private message module too.  If the message module name
  specified in the PDT header has one or more slashes in it, then the
  message module name specifies BOTH a path name to the message module
  archive file and the name of the message module contained in that library.
  For instance, in the following PDT declaration the message module name is
  again hhhh.mm, but this time it resides in the archive file my_mm_library
  rather than in libevapmm.a in the installation catalog:

       PDT (my_mm_library/hhhh.mm) command_hhhh
         parameter declarations ...
       PDTEND required_file_list

  Now use add_message_modules:

       addmm -mml my_mm_library hhhh.mm

  Use display_command_information -command add_message_modules -display_option
  full (disci -c addmm -do f) to see further information.
    

                               Notes and Cautions

  The PDT parsing code in genpdt.c is really pretty stupid.  Although most of
  the PDT declaration is free-form there are two contructs that must be
  entered in a particular fashion:

    1) A key type declaration MUST be entered such that a trailing comma
       separates all the valid keywords, as in this example:

         display_option, do: key brief, b, full, f, keyend = brief

       The following key declaration would not parse properly:

         display_option, do: key brief b full f keyend = brief

    2) When specifying a help message module on the PDT statement, the
       message module name MUST be surrounded by parentheses without any
       embedded spaces.  Here is a valid example:

         PDT (disci.mm) display_command_information, disci

       This example is illegal and will not parse correctly:

         PDT ( disci.mm ) display_command_information, disci

  Finally, be sure to end the last line of the PDT declaration, the PDTEND
  statement, with a <cr>.  Failure to do so will cause generate_pdt to sense
  end-of-file prematurely.  


                                 Acknowledgment

  Many thanks to Control Data Corporation for pioneering the concept of a
  typed, consistent user interface; an interface used by the NOS/VE operating
  system and ALL its applications; an interface that has meaningful command
  and parameter names instead of short, cryptic ones.  Control Data invented
  the concept of first-level help for ALL commands with
  DISPLAY_COMMAND_INFORMATION and DISPLAY_FUNCTION_INFORMATION, providing a
  level of global consistency not found in any other OS in the world (well,
  as I write this on my Mac I might have to reconsider (-:)!

  Also, many thanks to Mark 'dog' Miller for coding the alpha version of
  evaluate_parameters.

  Copyright (C) 1990 - 1993 by Lehigh University.  All rights reserved.

#endif

#define P_PDT_VERSION "1.2"	/* PDT version */

#ifndef NULL
#define NULL 0			/* NULL */
#endif
#ifndef TRUE
#define TRUE  1			/* TRUE */
#endif
#ifndef FALSE
#define FALSE 0			/* FALSE */
#endif

#define P_TYPE_SWITCH      0	/* type ordinals */
#define P_TYPE_STRING      1
#define P_TYPE_REAL        2
#define P_TYPE_INTEGER     3
#define P_TYPE_BOOLEAN     4
#define P_TYPE_FILE        5
#define P_TYPE_KEY         6
#define P_TYPE_APPLICATION 7
#define P_TYPE_NAME        8
#define P_MAXIMUM_TYPES    9	/* maximum types supported */

#define P_MAX_KEYWORD_LENGTH 31	/* maximum parameter length */
#define P_MAX_KEYWORD_VALUE_LENGTH 256 /* maximum parameter value length */
#define P_MAX_PARAMETER_HELP 256 /* maximum parameters that can have full_help
*/
#define P_MAX_PARAMETER_HELP_LENGTH 1024 /* maximum parameter help length */
#define P_MAX_VALID_VALUES 32	/* maximum number of key values */

#define P_HELP 0		/* display command information */

struct pdt_header {		/* PDT header */
  char *version;		/* PDT version */
  char *help_module_name;	/* help module */
  char *file_list;		/* trailing file list flag */
};

struct parameter_value {	/* parameter value */
  char  *parameter;		/* official parameter spelling */
  char  *alias;			/* this parameter also known as */
  short int specified;		/* if this param entered by user */
  short int changeable;		/* if param changeable by user */
  short int type;		/* this parameter's type */
  char  *default_variable;	/* default environment variable */
  char  *unconverted_value;	/* value before type converstion */
  char  *description;		/* for usage information */
  char  *valid_values[P_MAX_VALID_VALUES]; /* valid values, last one NULL */
  union {			/* type dependent value */
    short int switch_value;
    char *string_value;
#ifdef nosve
    long double real_value;
#else
    double real_value;
#endif
    int integer_value;
    short int boolean_value;
    char *file_value;
    char *key_value;
    char *application_value;
    char *name_value;
  } value;
};

typedef struct parameter_value Parameter_Value; /* an alias */
