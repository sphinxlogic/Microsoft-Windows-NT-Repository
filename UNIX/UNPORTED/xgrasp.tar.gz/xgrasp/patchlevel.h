#ident "@(#)patchlevel.h	1.6 91/04/03 XGRASP"
/*
 * patchlevel.h - for xgrasp.
 */
#define patchlevel 1.6
#define DATE "Tue Apr  3 14:00:00 PST 1991"
