/***************************************************************************
 *
 * HEADER:
 *  file cache
 *
 **************************************************************************/

void
fc_set_root_dir(char *hostname);

char * 
fc_make_cache_path(char *rem_path);

int
fc_mkdir_path(char *path);

int
fc_delete_cache(void);

