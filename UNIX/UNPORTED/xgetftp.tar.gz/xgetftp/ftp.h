/*=========================================================================
 * HEADER:
 *  "ftp"
 *=======================================================================*/

/*
 * Exported variables
 */

extern FILE *response_stream;	/* where the response should go --
				   normally it should go to stdout */


/*
 * Function prototypes.
 */

int
ftp_init_conn(char *hostname);

int
ftp_send_command(char *fmt, ...);

int
ftp_get_response(FILE *fdout);

int
ftp_get_next_response(int oldcode, FILE *fdout);

int
ftp_init_dataconn(void);

int
ftp_get_data(FILE *fdout);

int
ftp_put_data(FILE *fdout);

void
ftp_close_conn(void);
