/*************************************************************************
 *
 * User configuration file
 *
 * Modify before compiling and installing program
 *
 ************************************************************************/

/*
 * ARCHIEBIN should have complete path for archie client program.
 */
#define ARCHIEBIN       "/usr/bin/archie"

/*
 * ARCHIESRVRARG defines the argument needed to invoke a specific
 * server.  If you have a client based on Prospero, you should 
 * use the "-h" option.
 *
 */
/* #define ARCHIESRVRARG	"-h" */
#define ARCHIESRVRARG	"-server"

/*
 * ARCHIESERVER defines the server to use.  Change this to be your
 * favorite server.
 *
 */
#define ARCHIESERVER    "archie.sura.net"
