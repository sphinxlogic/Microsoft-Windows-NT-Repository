/*************************************************************************
 *
 * HEADER: 
 *  prefs
 *
 **************************************************************************/

/*
 * User Preference ids
 */
#define prefCACHE_VIEW   	1
#define prefREUSE_VIEW   	2
#define prefREUSE_DIR		3
#define prefAUTOSAVE_DIR 	4
#define prefCONFIRM      	5


/*
 * User Preference structure
 */
typedef struct _pref
{
    char cache_view;		/* save viewed files or not?	  */
    char reuse_view;		/* reuse previous view caches?    */
    char reuse_dir;		/* reuse previous dir cache?      */
    char autosave_dir;		/* save directory cache upon exit?*/
    char confirm;		/* ask user before reusing cache? */
    char show_hidden;		/* show hidden files?		  */
    char log_session;		/* log ftp session?		  */
} Prefs;


/*
 * Exported variables
 */
extern Prefs 	user_prefs;	/* User preferences 	  	  */

int
prefs_save(Prefs prefs);

int
prefs_load(Prefs *pprefs);

