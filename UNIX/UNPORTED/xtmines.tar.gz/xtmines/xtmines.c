/* xtmines: game where you try to cross a minefield */
/* Written by Timothy Tsai  April 13, 1992 */

#include "xtmines.h"

int	bw = def_bw;	/* border width for all windows */
int	x  = def_x;	/* frame x */
int	y  = def_y;	/*       y */
int	w  = def_w;	/*       width */
int	h  = def_h;	/*       height */
int	fh = def_fh;	/* field height */

int	num_bombs_left;
int	num_time_left;			/* num of seconds */
int	num_time_left_at_start;		/* num of seconds */
int	num_score		= 0;
int	num_grenades_left	= NUM_GRENADES_AT_START;
int	num_tombstones		= 0;
int	num_lives		= STARTING_NUM_LIVES;
int	automark		= TRUE;
int	sanity			= FALSE;
int	extended_automark	= FALSE;
showtype	show		= DEF_SHOW;
int	used_showfig;
int	used_sanity;
int	used_eautomark;

int	finished;	/* reach goal yet? */
int	dead = FALSE;

int	num_bonus;
int	pause_time;
long	time_at_start_of_level;	/* time at start of each level */

Display		*disp;
Window		root,frame,field,wind[NUMWINDS];
int		screen,depth;
Visual		*visual;
unsigned long	white,black;
Font		fonts,fontm,fontt;
XFontStruct	*fontsstruct,*fontmstruct,*fonttstruct;
int		fontsw,fontsh,fontsa,
		fontshoww,fontshowh,fontshowa,
		fontmw,fontmh,fontma,
		fonttw,fontth,fontta;

XColor		color[NUMCOLORS];
GC		gcs,gcm,gct;
Colormap	cmap;

ranktype	level;
ranktype	start_level=DEF_LEVEL;

extern int show_hiscores();
extern void show_and_add_scores();


main(argc,argv)
int argc;
char **argv;
{
	XEvent		event;


	printf("xtmines -- by Timothy K. Tsai (ttsai@uiuc.edu)\n");
	printf("   Version %d.%d (patchlevel %d) -- last modification on %s\n",
		MAJOR_VERSION_NUM,MINOR_VERSION_NUM,PATCHLEVEL,LAST_MOD_DATE);

	if (argc==2) {
	   if (!strcmp(argv[1],"-s")) {
		show_hiscores(NOX);
		exit(0);
	   }
	   else if ((argv[1][0]=='-') && (argv[1][1]=='l'))
		switch (argv[1][2]-'0') {
			case 0	: start_level = grunt; break;
			case 1	: start_level = corporal; break;
			case 2	: start_level = lieutenant; break;
			case 3	: start_level = captain; break;
			case 4	: start_level = mmajor; break;
			case 5	: start_level = general; break;
			case 6	: start_level = president; break;
			case 7	: start_level = king; break;
			case 8	: start_level = emperor; break;
			case 9	: start_level = angel; break;
			default	: fprintf(stderr,
				     "Error: Rank should be in range (0-9)\n");
				  exit(ILLEGAL_ARGUMENT);
		}
	   else {
		fprintf(stderr,"   xtmines\n");
		fprintf(stderr,"      -s    show high scores list\n");
		fprintf(stderr,"      -lr   start at level r\n");
		exit(ILLEGAL_ARGUMENT);
	   }
	}
	else if (argc != 1) {
		fprintf(stderr,"   xtmines\n");
		fprintf(stderr,"      -s    show high scores list\n");
		fprintf(stderr,"      -lr   start at level r\n");
		exit(ILLEGAL_ARGUMENT);
	}

	open_display();
	load_fonts();
	create_map_frame();
	create_GC_colormap();
	set_event_masks();

	for (level=start_level;(level<=HIGHEST_PLAYABLE_RANK) && 
	(num_lives>0);level++) {
		init_values();

		set_field();
		show_bomb_status(manvx,manvy);
		refresh();

		time_at_start_of_level = time(0);

		finished = FALSE;

		while (!finished) {
			if (XPending(disp) > 0) {
				XNextEvent(disp,&event);
				handle_event(&event);
			}
			else usleep(XPENDING_UDELAY);
			if ((!dead) && (!finished))
				dead = update_time();
		}
	}

	show_and_add_scores();
}
