/* xtmines: game where you try to cross a minefield */
/* Written by Timothy Tsai  April 13, 1992 */

#define LAST_MOD_DATE		"June 19, 1992"
#define MAJOR_VERSION_NUM	1
#define MINOR_VERSION_NUM	2

#include <stdio.h>
#include <X11/Xlib.h>
#define XK_MISCELLANY
#include <X11/keysymdef.h>
#include "patchlevel.h"
/* bitmaps */
#include "safe.bm"
#include "man.bm"
#include "bomb.bm"
#include "tstone.bm"
#include "goal.bm"
#include "trail.bm"
#include "pow.bm"
#include "bombmark.bm"
#include "safewrong.bm"
#include "bombmarkwrong.bm"

#define FALSE		0
#define TRUE		1

#define NUMROWS				25
#define NUMCOLS				40
#define BOMB_EXPLODE_UDELAY		10000
#define XPENDING_UDELAY			50000
#define SECONDS_PER_LEVEL		(5*60)
#define NUM_GRENADES_AT_START		3
#define	POINTS_PER_GRENADE		100
#define POINTS_PER_TOMBSTONE		200
#define POINTS_FOR_USED_SHOWFIG		50
#define PERCENT_FOR_USED_SANITY		1
#define PERCENT_FOR_USED_EAUTOMARK	10
#define GRENADE_DISTANCE		5
#define STARTING_NUM_LIVES		3
#define LOWEST_LEVEL_FOR_REWARD		lieutenant
#define LOWEST_SCORE_FOR_REWARD		3000
#define MAXLIVES			6

#define MAXSTRLEN	200
#define BUTTON1		1	/* use mouse button 1 */
#define BUTTON2		2	/* use mouse button 2 */
#define BUTTON3		3	/* use mouse button 3 */
/* status font */
#define FONTS		"*courier-bold-r-normal--24*"
/* main font */
#define FONTM		"*courier-bold-r-normal--14*"
/* time font */
#define FONTT		"*courier-bold-r-normal--18*"
#define def_fh		NUMROWS*(man_height+1)
					/* field height */
#define	def_bw		4       	/* border width for all windows */
#define	def_x		0      	 	/* frame x */
#define	def_y		0       	/*       y */
#define	def_w		2*def_bw + NUMCOLS*(man_width+1)
					/*       width */
#define	def_h		def_fh+140     /*       height */

extern int	bw;	/* border width for all windows */
extern int	x;	/* frame x */
extern int	y;	/*       y */
extern int	w;	/*       width */
extern int	h;	/*       height */
extern int	fh;	/* field height */

extern int	finished;
extern int	dead;

#define SUCCESS			0
#define OUT_OF_RANGE		1
#define NO_MARK_TO_REMOVE	2
#define CANT_MARK		3
#define TIME_IS_OVER		TRUE
#define NO_GRENADES_LEFT	4
#define TOO_FAR_TO_TOSS_GRENADE	5
#define ILLEGAL_POSITION	6
#define SQUARE_IS_UNSAFE	7
#define CANT_EXPLODE		8
#define DIED			9
#define ILLEGAL_ARGUMENT	10
#define NOX			11
#define DOX			12
#define CHECK_FAILED		13

typedef enum {bombs_left,bonus_wind,time_left,score, grenades_left,rank,
		lives_left,
		automark_wind,giveup_wind,tgrenade_wind,show_wind,quit_wind,
		refresh_wind,eautomark_wind,sanitycheck_wind,pause_wind,
		status} windtype;
#define NUM1WINDS	6	/* num of winds per row */
#define	NUMWINDS	17	/* tot num of winds */
typedef enum {grunt,corporal,lieutenant,captain,mmajor,general,president,
		king,emperor,angel,god} ranktype;
#define NUMRANKS		10	/* doesn't include god */
#define HIGHEST_PLAYABLE_RANK	angel
#define DEF_LEVEL	grunt
extern ranktype	level;
extern ranktype start_level;
extern int num_bombs_at_start[NUMRANKS];
extern int num_bonus;

extern int	num_bombs_left;
extern int	num_time_left;		/* num of seconds */
extern int	num_time_left_at_start;	/* num of seconds */
extern long	time_at_start_of_level;
extern int	num_score;
extern int	num_grenades_left;
extern int	num_tombstones;
extern int	num_lives;
extern int	automark;
extern int	extended_automark;
extern int	sanity;
#define MIN_EXTENDED_MARK_LEVEL		lieutenant
extern int	pause_time;

extern Display		*disp;
extern Window		root,frame,field,wind[NUMWINDS];
extern int		screen,depth;
extern Visual		*visual;
extern unsigned long	white,black;
extern Font		fonts,fontm,fontt;
extern XFontStruct	*fontsstruct,*fontmstruct,*fonttstruct;
extern int		fontsw,fontsh,fontsa,
			fontshoww,fontshowh,fontshowa,
			fontmw,fontmh,fontma,
			fonttw,fontth,fontta;

#define font_color	0
#define background_color 1
#define field_color	2
#define NUMCOLORS	3
#define FONTCOLOR	"black"
#define BACKGROUNDCOLOR	"white"
#define FIELDCOLOR	"black"
extern XColor		color[NUMCOLORS];
extern GC		gcs,gcm,gct;
extern Colormap	cmap;

typedef enum {bm_empty,bm_safe,bm_man,bm_bomb,bm_tombstone,bm_goal,
		bm_trail,bm_pow,bm_bombmark,bm_safewrong,bm_bombmarkwrong} 
		bmtype;
#define NUMBITMAPS	11
typedef enum {fc_empty,fc_trail,fc_man,fc_bomb,fc_tombstone,
		fc_goal} fieldcont;
typedef enum {fm_nomark,fm_safe,fm_bomb} fieldmark;
typedef struct {
		fieldcont	c;
		fieldmark	m;
		int		done;	/* used for mark_allaround_ok() */
	} fieldstruct;
extern fieldstruct FIELD[NUMCOLS][NUMROWS];
typedef enum {sh_man,sh_fig} showtype;
#define DEF_SHOW	sh_fig
extern showtype show;
extern int used_showfig;	/* boolean: used showfig on present level? */
extern int used_sanity;		/* boolean: used sanity on present level? */
extern int used_eautomark;	/* boolean: used eautomark on present level? */
extern Pixmap bitmap[NUMBITMAPS];
extern int bmwidth[NUMBITMAPS];
extern int bmheight[NUMBITMAPS];

extern int manvx,manvy;		/* current virtual man position */

extern void open_display();
extern void load_fonts();
extern void create_map_frame();
extern void create_GC_colormap();
extern void set_event_masks();
extern void init_values();
extern int illegal_bomb_position();
extern void set_field();

/* This is a kludge for system without usleep() */
#ifdef NOUSLEEP
extern void usleep();
#endif
extern void PrintStr();
extern void InvPrintStr();
extern void WindPrint();
extern char *num_rank_to_words();
extern char *clock_time_str();
extern void print_display();
extern void draw();
extern void clear();
extern void draw_field();
extern void refresh();
extern int setxy();
extern int setvxvy();
extern int bomb_status();
extern void show_bomb_status();
extern void show_all_bombs();
extern void do_promotion();
extern int move_man();
extern int remove_mark();
extern int mark_ok();
extern int mark_allaround_ok();
extern int mark_bomb();
extern void die();
extern int current_bonus();
extern int explode();
extern void uptdate_time();
extern int throw_grenade();
extern int update_time();
extern int do_sanity_check();
extern int do_pause();
