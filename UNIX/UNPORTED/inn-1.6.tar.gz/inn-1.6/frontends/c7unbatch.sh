#! /bin/sh
decode | /usr/ucb/compress -d
