#!/bin/sh
#
#	newfiles.sh -- find new RCS files in postgres tree
#

if [ -z "$PGMASTERTREE" ]; then
    MASTER=/usr/local/dev/postgres/mastertree
else
    MASTER=$PGMASTERTREE
fi

SRCDIRS=`cat $1`
OTHERS=`co -s -p $MASTER/newconf/dirs_other.mk`

SRCDIR=`basename $2`
flags=$3
TREE=$4
TOP=$4/$SRCDIR
if [ $5 ]
then
	checkout=true
	OBJDIR=`basename $6`
fi

cd $TREE

for i in $SRCDIRS
do
	cd $TREE/$SRCDIR/$i
	if [ -d RCS ]
	then
		echo \*\*\* $SRCDIR/$i
		f=`rcsnew $flags`
		for j in $f
		do
			if [ -f $j ]
			then
				echo \-\- $SRCDIR/$i/$j
				if [ $checkout ]
				then
					co -q $j
				fi
			else
				echo \+\+ $SRCDIR/$i/$j NEW FILES
				if [ $checkout ]
				then
				      co -q $j
				      ln -s $TREE/$SRCDIR/$i/$j $TREE/$OBJDIR/$i
				fi
			fi
		done
	fi
done

for i in $OTHERS
do
	cd $TREE/$i
	if [ -d RCS ]
	then
		echo \*\*\* $i
		f=`rcsnew -n`
		for j in $f
		do
			echo \-\- $i/$j
			if [ $checkout ]
			then
				co -q $j
			fi
		done
	fi
done
exit 0
