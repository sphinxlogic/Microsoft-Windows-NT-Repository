/* ----------------------------------------------------------------
 *   FILE
 *	pre_nestdots.c
 *
 *   DESCRIPTION
 *	this contains the preprocessing code to expand nested
 *	dot expressions from query plans.
 *
 *   INTERFACE ROUTINES
 *	ReplaceNestedDots()
 *
 *   IDENTIFICATION
 *	$Header: /private/postgres/src/executor/RCS/pre_nestdots.c,v 1.2 1991/11/14 11:07:27 glass Exp $
 * ----------------------------------------------------------------
 */

#include "executor/executor.h"

/* ----------------
 *	ReplaceNestedDots
 * ----------------
 */
void
ReplaceNestedDots(parseTree, planP)
    List	parseTree;
    Plan	*planP;
{
    Plan	originalPlan;
    Plan	newPlan;

    originalPlan = (*planP);

    (*planP) = newPlan;
}
