/*
 * access/internal.h --
 *	Internal definitions.
 *
 * Identification:
 *	$Header: /private/postgres/src/access/index/RCS/internal.h,v 1.1 1991/01/29 15:20:19 cimarron Exp $
 */

#ifndef	InternalDefined
#define InternalDefined	1

#include "tmp/postgres.h"
#include "access/skey.h"
#include "utils/rel.h"

/*
 * OperatorRelationFillScanKeyEntry --
 *	Fills the scan key entry for an OPERATOR object.
 */
extern
void
OperatorRelationFillScanKeyEntry ARGS((
	Relation	operatorRelation,
	ObjectId	operatorObjectId,
	ScanKeyEntry	entry
));

#endif	/* !defined(InternalDefined) */
