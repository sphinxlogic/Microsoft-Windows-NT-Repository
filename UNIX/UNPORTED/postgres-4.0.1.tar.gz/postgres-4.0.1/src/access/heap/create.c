/* ----------------------------------------------------------------
 *   FILE
 *	create.c
 *	
 *   DESCRIPTION
 *	Access method creation and deletion of relations code.
 *	THIS FILE IS BEING OBSOLETED BY lib/catalog/heap.c  -cim 1/13/1991
 *
 *   INTERFACE ROUTINES
 *	amcreate
 *	amcreatr
 *	amdestroy
 *
 *   NONFUNCTIONAL BAGGAGE
 *	amcreatv
 *	amcreati
 *	ambuild
 *	ammergev
 *
 *   NOTES
 *	This file should be split - amcreate and amdestroy are more
 *	catalog-support functions and they should go in a file in
 *	lib/C/catalog.  amcreatr() is the real access-method function
 *	here and it should stay.  -cim 6/19/90
 *	
 *	amcreate/amcreatr/amdestroy have a crapload of wrapper
 *	functions called fancy names like RelationNameCreateHeapRelation(),
 *	etc.  something should be done about these, as well as all the
 *	NewXXX routines like NewCreate, NewDestroy... etc.
 *
 *   IDENTIFICATION
 *	$Header: /private/postgres/src/access/heap/RCS/create.c,v 1.35 1991/05/01 02:49:10 cimarron Exp $
 * ----------------------------------------------------------------
 */

#include <sys/file.h>
#include <strings.h>

#include "tmp/postgres.h"

RcsId("$Header: /private/postgres/src/access/heap/RCS/create.c,v 1.35 1991/05/01 02:49:10 cimarron Exp $");

#include "access/heapam.h"
#include "access/relscan.h"
#include "utils/log.h"
#include "utils/mcxt.h"
#include "utils/rel.h"
#include "utils/relcache.h"

#ifdef sprite
#include "sprite_file.h"
#endif /* sprite */
