/* ----------------------------------------------------------------
 *   FILE
 *	access.c
 *	
 *   DESCRIPTION
 *	heap access method interface routines
 *	NOTE: THIS FILE IS BEING OBSOLETED.  -cim 1/28/1991
 *
 *   INTERFACE ROUTINES
 *
 *   NOTES
 *	If you are calling these routines, then you should change
 *	to the heap_ functions instead.  I am systematically searching
 *	out and removing all references to these old routines and
 *	soon this file will go away -cim.
 *	
 *   IDENTIFICATION
 *	$Header: /private/postgres/src/access/heap/RCS/access.c,v 1.31 1991/08/01 11:05:00 mer Exp $
 * ----------------------------------------------------------------
 */

#include <sys/file.h>
#include <strings.h>

#include "tmp/postgres.h"

RcsId("$Header: /private/postgres/src/access/heap/RCS/access.c,v 1.31 1991/08/01 11:05:00 mer Exp $");

#include "access/heapam.h"
#include "access/htup.h"
#include "access/relscan.h"
#include "access/skey.h"
#include "access/tqual.h"

#include "storage/buf.h"
#include "storage/bufmgr.h"
#include "storage/bufpage.h"
#include "storage/itemid.h"
#include "storage/itemptr.h"
#include "storage/page.h"
#include "storage/lmgr.h"

#include "utils/memutils.h"
#include "utils/fmgr.h"
#include "utils/inval.h"
#include "utils/log.h"
#include "utils/mcxt.h"
#include "utils/rel.h"
#include "utils/relcache.h"

/* ----------------------------------------------------------------
 *	access.c	- Interface to access method routines
 * ----------------------------------------------------------------
 */
