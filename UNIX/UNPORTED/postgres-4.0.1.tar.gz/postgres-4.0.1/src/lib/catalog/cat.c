/*
 * cat.c --
 *	POSTGRES system catalog code.
 */

#include "c.h"

RcsId("$Header: /private/postgres/src/lib/catalog/RCS/cat.c,v 1.3 1989/09/05 17:13:58 mao C_Demo_1 $");
