/*
 * form.h --
 *	POSTGRES formated tuple (user) attribute values definitions.
 *
 * Identification:
 *	$Header: /private/postgres/src/lib/H/storage/RCS/form.h,v 1.6 1991/04/28 09:15:17 cimarron Exp $
 */

#ifndef	FormIncluded	/* Include this file only once. */
#define FormIncluded	1

#include "tmp/c.h"

/*
 * FormData --
 *	Formated (aligned) data.
 *
 * Note:
 *	Currently assumes that long alignment is the most strict alignment
 *	needed.
 */
typedef struct FormData {
	long	filler;
} FormData;

typedef Pointer	Form;

/*
 * FormIsValid --
 *	True iff the formated tuple attribute values is valid.
 */
#define	FormIsValid(form) PointerIsValid(form)

#endif	/* !defined(FormIncluded) */
