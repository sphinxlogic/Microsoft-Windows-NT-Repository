/* $Header: /private/postgres/src/lib/H/storage/RCS/procq.h,v 1.1 1991/07/29 07:11:32 mer Exp $ */


/* don't include twice */

#ifndef _PROCQ_H_
#define _PROCQ_H_

#include "storage/shmem.h"


typedef struct procQueue {
  SHM_QUEUE	links;
  int		size;
} PROC_QUEUE;

#endif _PROCQ_H_
