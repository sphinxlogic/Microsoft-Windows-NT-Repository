/*
 * page.h --
 *	POSTGRES buffer page abstraction definitions.
 */

#ifndef	PageIncluded		/* Include this file only once */
#define PageIncluded	1

/*
 * Identification:
 */
#define PAGE_H	"$Header: /private/postgres/src/lib/H/storage/RCS/page.h,v 1.8 1991/04/28 09:15:27 cimarron Exp $"

#include "tmp/c.h"

typedef Pointer	Page;

/*
 * PageIsValid --
 *	True iff page is valid.
 */
#define	PageIsValid(page) PointerIsValid(page)

#endif	/* !defined(PageIncluded) */
