/* File:  plsync.h    Wed Jul  6 16:49:47 PDT 1988   w.klas   	    */
/* 	$Header: /private/postgres/src/lib/H/storage/RCS/plsync.h,v 1.9 1991/06/10 21:01:02 kemnitz Exp $*/

#include "storage/ipci.h"    /* this includes also sys/types.h and sys/ipc.h*/

#include <stdio.h>
#include <sys/file.h>

#include "tmp/postgres.h"
#include "storage/pldebug.h"

#define LT_LockStartValue   255
#define LT_ExclusiveLock    (-255)
#define LT_SharedLock	    (-1)

#define PLT_LockStartValue  255
#define PLT_ExclusiveLock   (-255)
#define PLT_SharedLock	    (-1)


/* the following manipulation modes are allowed	on a transaction    */
/*   semaphore	    	    	    	    	    	    	    */
typedef     int	    SemManipulationMode;  
#define	    PLT_SemUnlock   1
#define	    PLT_SemLock	    2
    	    	    	    	    	
#ifdef HAS_TEST_AND_SET
static int  LockLockId = -1;
#else
static int  LockSemId = -1; 	    /* semaphore associated with shared     */
    	    	    	    	    /*	    lock table segment	    	    */
#endif
static int  TransactionSemId = -1;  /* semaphore associated with XID 	    */
    	    	    	    	    /*	semaphore set 	    	    	    */
static int  SynchInteraction = 0;   /*flag for controlling the CONTINUE	    */
    	    	    	    	    /*  intercation 	    	    	    */
