/*
 * rlock.h --
 *	POSTGRES rule lock definitions.
 *
 * Identification:
 *	$Header: /private/postgres/src/lib/H/rules/RCS/rlock.h,v 1.10 1990/08/17 08:53:08 cimarron Exp $
 */

#ifndef RLOCK_H
#define RLOCK_H

#include "rules/prs2locks.h"

#endif
