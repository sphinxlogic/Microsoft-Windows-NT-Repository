/* $Header: /private/postgres/src/lib/H/executor/RCS/x_result.h,v 1.3 1990/10/01 07:45:54 cimarron Exp $ */
extern TupleTableSlot ExecResult ARGS((Result node));
extern List ExecInitResult ARGS((Plan node, EState estate, int level, Plan parent));
extern void ExecEndResult ARGS((Result node));
