/* $Header: /private/postgres/src/lib/H/executor/RCS/x_shmem.h,v 1.1 1991/07/24 16:10:29 hong Exp $ */

struct memoryheaderdata {
    char                        *beginaddr;
    int                         size;
    struct memoryheaderdata     *next;
};
typedef struct memoryheaderdata MemoryHeaderData;
typedef MemoryHeaderData *MemoryHeader;
extern char *ExecSMReserve();
extern void ExecSMInit();
extern MemoryHeader ExecGetSMSegment();
extern void ExecSMSegmentFree();
extern void ExecSMSegmentFreeUnused();
