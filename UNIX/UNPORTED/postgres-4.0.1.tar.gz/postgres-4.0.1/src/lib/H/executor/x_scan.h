/* $Header: /private/postgres/src/lib/H/executor/RCS/x_scan.h,v 1.5 1990/10/01 07:45:55 cimarron Exp $ */
extern TupleTableSlot ExecScan ARGS((Plan node, int accessMtd));
