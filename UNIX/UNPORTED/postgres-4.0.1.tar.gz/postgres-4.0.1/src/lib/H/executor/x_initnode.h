/* $Header: /private/postgres/src/lib/H/executor/RCS/x_initnode.h,v 1.3 1990/10/01 07:45:45 cimarron Exp $ */
extern List ExecInitNode ARGS((Plan node, EState estate, int level, Plan parent));
