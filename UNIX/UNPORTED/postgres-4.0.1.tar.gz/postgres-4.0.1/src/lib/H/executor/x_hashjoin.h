/* $Header: /private/postgres/src/lib/H/executor/RCS/x_hashjoin.h,v 1.3 1991/09/22 22:03:50 hong Exp $ */
extern TupleTableSlot ExecHashJoin ARGS((HashJoin node));
extern List ExecInitHashJoin ARGS((Sort node, EState estate, int level, Plan parent));
extern void ExecEndHashJoin ARGS((HashJoin node));
extern TupleTableSlot ExecHashJoinOuterGetTuple ARGS((Plan node, int curbatch, HashJoinState hjstate));
extern TupleTableSlot ExecHashJoinGetSavedTuple ARGS((HashJoinState hjstate, char *buffer, File file, Pointer tupleSlot, int *block, char **position));
extern int ExecHashJoinNewBatch ARGS((HashJoinState hjstate, int newbatch));
extern int ExecHashJoinGetBatch ARGS((int bucketno, HashJoinTable hashtable, int nbatch));
extern char *ExecHashJoinSaveTuple ARGS((HeapTuple heapTuple, char *buffer, File file, char *position));
