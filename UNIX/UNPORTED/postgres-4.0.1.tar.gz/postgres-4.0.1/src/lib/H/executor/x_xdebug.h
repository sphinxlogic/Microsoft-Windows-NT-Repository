/* $Header: /private/postgres/src/lib/H/executor/RCS/x_xdebug.h,v 1.3 1990/10/01 07:46:06 cimarron Exp $ */
extern void ExecXInitialize ARGS(());
extern void ExecXNewTree ARGS(());
extern void ExecXAddNode ARGS((int base_id, char *title, int supernode_id));
extern void ExecXSignalNode ARGS((int base_id, int signal));
extern void ExecXShowTree ARGS(());
extern void ExecXHideTree ARGS(());
extern void ExecXTerminate ARGS(());
extern void x_at_init ARGS((Plan node, BaseNode state));
extern void x_post_init ARGS((Plan node, BaseNode state));
extern void x_pre_proc ARGS((Plan node, BaseNode state));
extern void x_post_proc ARGS((Plan node, BaseNode state));
extern void x_pre_end ARGS((Plan node, BaseNode state));
extern void x_post_end ARGS((Plan node, BaseNode state));
extern void InitXHook ARGS((HookNode hook));
