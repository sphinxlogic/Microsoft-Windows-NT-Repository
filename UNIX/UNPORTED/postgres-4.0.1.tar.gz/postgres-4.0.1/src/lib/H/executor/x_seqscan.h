/* $Header: /private/postgres/src/lib/H/executor/RCS/x_seqscan.h,v 1.3 1990/10/01 07:45:58 cimarron Exp $ */
extern TupleTableSlot SeqNext ARGS((SeqScan node));
extern TupleTableSlot ExecSeqScan ARGS((SeqScan node));
extern ObjectId InitScanRelation ARGS((Plan node, EState estate, int level, ScanState scanstate, Plan outerPlan));
extern List ExecInitSeqScan ARGS((Plan node, EState estate, int level, Plan parent));
extern void ExecEndSeqScan ARGS((SeqScan node));
extern void ExecSeqReScan ARGS((Plan node));
extern List ExecSeqMarkPos ARGS((Plan node));
extern void ExecSeqRestrPos ARGS((Plan node));
