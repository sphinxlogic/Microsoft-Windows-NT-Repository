/* $Header: /private/postgres/src/lib/H/executor/RCS/x_parallel.h,v 1.2 1990/10/01 07:45:50 cimarron Exp $ */
extern List ExecInitParallel ARGS((Parallel node, EState estate, int level));
extern List ExecParallel ARGS((Parallel node));
extern void ExecEndParallel ARGS((Parallel node));
