/* $Header: /private/postgres/src/lib/H/executor/RCS/x_nestloop.h,v 1.3 1990/10/01 07:45:49 cimarron Exp $ */
extern TupleTableSlot ExecNestLoop ARGS((NestLoop node));
extern List ExecInitNestLoop ARGS((NestLoop node, EState estate, int level, Plan parent));
extern List ExecEndNestLoop ARGS((NestLoop node));
