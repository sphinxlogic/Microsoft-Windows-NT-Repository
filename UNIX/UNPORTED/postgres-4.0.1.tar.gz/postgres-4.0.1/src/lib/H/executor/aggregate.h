/* $Header: /private/postgres/src/lib/H/executor/RCS/aggregate.h,v 1.3 1991/09/05 15:26:57 hong Exp $ */
extern void ExecEndAgg ARGS((Agg node));
extern List ExecInitAgg ARGS((Agg node, EState estate, Plan parent));
extern TupleTableSlot ExecAgg ARGS((Agg node));
