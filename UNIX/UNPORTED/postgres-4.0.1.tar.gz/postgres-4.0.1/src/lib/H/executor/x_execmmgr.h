/* $Header: /private/postgres/src/lib/H/executor/RCS/x_execmmgr.h,v 1.2 1990/10/01 07:45:40 cimarron Exp $ */
extern Pointer ExecAllocNormal ARGS((Size size));
extern void ExecFreeNormal ARGS((Pointer pointer));
extern Pointer ExecAllocDebug ARGS((String routine, String file, int line, Size size));
extern void ExecFreeDebug ARGS((String routine, String file, int line, Pointer pointer));
extern void ExecDumpAllocList ARGS((String caller, bool verbose));
