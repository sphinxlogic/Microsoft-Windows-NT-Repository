/* $Header: /private/postgres/src/lib/H/executor/RCS/x_execfmgr.h,v 1.6 1992/07/08 05:02:24 mer Exp $ */
extern Datum GetAttributeByName ARGS((TupleTableSlot slot, char *attname, bool *isNull));
extern Datum GetAttributeByNum ARGS((TupleTableSlot slot, char *attname, bool *isNull));
extern Datum arrayFmgr ARGS((ObjectId functionOid, int numberArguments, Datum parameterValues[], bool *isNullP));
