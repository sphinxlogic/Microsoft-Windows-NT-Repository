/* $Header: /private/postgres/src/lib/H/executor/RCS/x_append.h,v 1.3 1990/10/01 07:45:27 cimarron Exp $ */
extern List exec_append_initialize_next ARGS((Append node, int level));
extern List ExecInitAppend ARGS((Append node, EState estate, int level, Plan parent));
extern TupleTableSlot ExecProcAppend ARGS((Append node));
extern void ExecEndAppend ARGS((Append node));
