/* $Header: /private/postgres/src/lib/H/executor/RCS/x_endnode.h,v 1.2 1990/10/01 07:45:30 cimarron Exp $ */
extern void ExecEndNode ARGS((Plan node));
