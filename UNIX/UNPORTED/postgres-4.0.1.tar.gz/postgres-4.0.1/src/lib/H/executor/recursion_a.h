/***********************************************************************
 ** *   Recursion Header A (recursion_a.h)                          * **
 ** *           Jimmy Bell                                          * **
 ** *                                                               * **
 ***********************************************************************
 *	Definitions of types used throughout recursive query processing.
 *
 * IDENTIFICATION:
 *   $Header: /private/postgres/src/lib/H/executor/RCS/recursion_a.h,v 1.3 1990/01/30 17:23:11 jamesb Version_2 $
 *
 */

#ifndef RecursionAIncluded
#define RecursionAIncluded

typedef int Command;

/* The recursive evaluation methods considered (implemented) */
typedef	enum RecursiveMethod {
	RecursiveMethodNone,
	RecursiveMethodNaive,
	RecursiveMethodSemiNaive
} RecursiveMethod;

#endif /* RecursionIncluded */

