/* $Header: /private/postgres/src/lib/H/executor/RCS/x_debug.h,v 1.2 1990/10/01 07:45:29 cimarron Exp $ */
extern DebugVariablePtr SearchDebugVariables ARGS((String debug_variable));
extern bool DebugVariableSet ARGS((String debug_variable, int debug_value));
extern bool DebugVariableProcessCommand ARGS((char *buf));
extern void DebugVariableFileSet ARGS((String filename));
