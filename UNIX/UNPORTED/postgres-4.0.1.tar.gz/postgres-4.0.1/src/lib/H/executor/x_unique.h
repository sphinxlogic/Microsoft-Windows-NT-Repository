/* $Header: /private/postgres/src/lib/H/executor/RCS/x_unique.h,v 1.3 1990/10/01 07:46:05 cimarron Exp $ */
extern bool ExecIdenticalTuples ARGS((List t1, List t2));
extern TupleTableSlot ExecUnique ARGS((Unique node));
extern List ExecInitUnique ARGS((Unique node, EState estate, int level, Plan parent));
extern void ExecEndUnique ARGS((Unique node));
