/* $Header: /private/postgres/src/lib/H/executor/RCS/x_mergejoin.h,v 1.3 1990/10/01 07:45:47 cimarron Exp $ */
extern List MJFormOSortopI ARGS((List qualList, ObjectId sortOp));
extern List MJFormISortopO ARGS((List qualList, ObjectId sortOp));
extern bool MergeCompare ARGS((List eqQual, List compareQual, ExprContext econtext));
extern void ExecMergeTupleDump ARGS((ExprContext econtext, MergeJoinState mergestate));
extern TupleTableSlot ExecMergeJoin ARGS((MergeJoin node));
extern List ExecInitMergeJoin ARGS((MergeJoin node, EState estate, int level, Plan parent));
extern void ExecEndMergeJoin ARGS((MergeJoin node));
