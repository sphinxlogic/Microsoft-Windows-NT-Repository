/* $Header: /private/postgres/src/lib/H/executor/RCS/x_procnode.h,v 1.3 1990/10/01 07:45:51 cimarron Exp $ */
extern TupleTableSlot ExecProcNode ARGS((Plan node));
