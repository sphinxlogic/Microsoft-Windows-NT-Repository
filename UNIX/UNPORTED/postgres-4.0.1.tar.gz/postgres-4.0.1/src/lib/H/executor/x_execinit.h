/* $Header: /private/postgres/src/lib/H/executor/RCS/x_execinit.h,v 1.3 1991/07/24 16:11:30 hong Exp $ */
extern void InitializeExecutor ARGS(());
