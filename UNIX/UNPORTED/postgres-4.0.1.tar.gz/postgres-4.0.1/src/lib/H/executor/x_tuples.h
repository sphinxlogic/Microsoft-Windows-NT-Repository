/* $Header: /private/postgres/src/lib/H/executor/RCS/x_tuples.h,v 1.7 1992/03/06 18:24:49 mer Exp $ */

extern TupleTable ExecCreateTupleTable ARGS((int initialSize));
extern void ExecDestroyTupleTable ARGS((TupleTable table, bool shouldFree));
extern int ExecAllocTableSlot ARGS((TupleTable table));
extern Pointer ExecGetTableSlot ARGS((TupleTable table, int slotnum));
    
#ifndef EXEC_DEBUGSTORETUP
extern Pointer ExecStoreTuple ARGS((Pointer tuple, Pointer slot, Buffer buffer, bool shouldFree));
#else    
extern Pointer ExecStoreTupleDebug ARGS((String file, int line, Pointer tuple, Pointer slot, bool shouldFree));
#endif EXEC_DEBUGSTORETUP
    
extern Pointer ExecClearTuple ARGS((Pointer slot));
extern bool ExecNullSlot ARGS((Pointer slot));
extern bool ExecSlotPolicy ARGS((Pointer slot));
extern bool ExecSetSlotPolicy ARGS((Pointer slot, bool shouldFree));
extern void ExecInitResultTupleSlot ARGS((EState estate, CommonState commonstate));
extern void ExecInitScanTupleSlot ARGS((EState estate, CommonScanState commonscanstate));
extern void ExecInitViewTupleSlot ARGS((EState estate, CommonScanState commonscanstate));
extern void ExecInitMarkedTupleSlot ARGS((EState estate, MergeJoinState merg));
extern void ExecInitOuterTupleSlot ARGS((EState estate, HashJoinState hashstate));
extern void ExecInitHashTupleSlot ARGS((EState estate, HashJoinState hashstate));
extern AttributePtr ExecGetTupType ARGS((Plan node));
extern Buffer ExecGetBuffer ARGS((Plan node));
extern AttributePtr ExecTypeFromTL ARGS((List targetList));
