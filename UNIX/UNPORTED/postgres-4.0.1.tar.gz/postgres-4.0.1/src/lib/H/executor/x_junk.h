
/* $Header: /private/postgres/src/lib/H/executor/RCS/x_junk.h,v 1.1 1991/01/17 18:55:06 sp Exp $ */

extern JunkFilter ExecInitJunkFilter ARGS((List targetList));
extern bool ExecGetJunkAttribute ARGS((JunkFilter junkfilter, TupleTableSlot slot, Name attrName, Datum *value, Boolean *isNull));
extern HeapTuple ExecRemoveJunk ARGS(( JunkFilter junkfilter, TupleTableSlot slot));
