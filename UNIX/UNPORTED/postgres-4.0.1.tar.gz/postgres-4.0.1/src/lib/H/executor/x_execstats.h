/* $Header: /private/postgres/src/lib/H/executor/RCS/x_execstats.h,v 1.4 1991/02/07 00:45:55 hong Exp $ */
extern void ResetTupleCount ARGS(());
extern void DisplayTupleCount ARGS(());
