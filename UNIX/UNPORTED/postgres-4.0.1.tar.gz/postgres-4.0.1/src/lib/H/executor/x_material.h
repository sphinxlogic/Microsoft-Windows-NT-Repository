/* $Header: /private/postgres/src/lib/H/executor/RCS/x_material.h,v 1.3 1990/10/01 07:45:46 cimarron Exp $ */
extern TupleTableSlot ExecMaterial ARGS((Material node));
extern List ExecInitMaterial ARGS((Sort node, EState estate, int level, Plan parent));
extern void ExecEndMaterial ARGS((Material node));
extern List ExecMaterialMarkPos ARGS((Material node));
extern void ExecMaterialRestrPos ARGS((Material node));
