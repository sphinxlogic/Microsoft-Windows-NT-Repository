/* $Header: /private/postgres/src/lib/H/executor/RCS/x_exist.h,v 1.2 1990/10/01 07:45:42 cimarron Exp $ */
extern List ExecExistential ARGS((Plan node));
extern List ExecEndExistential ARGS((Plan node));
extern List ExecInitExistential ARGS((Plan node, EState estate, int level));
