/* ----------------------------------------------------------------
 *  FILE
 *	catalog/sysunmap.h
 *
 *  DESCRIPTION
 *	this file undefines the type mappings done by #including
 *	catalog/catmacros.h
 *
 *   NOTES
 *	This is hack until the type scheme is completely reorganized.
 *
 *	This file is going away very soon -cim 8/6/90
 * ----------------------------------------------------------------
 */

#ifndef SYSUNMAP_H
#define SYSUNMAP_H	"$Header: /private/postgres/src/lib/H/catalog/RCS/sysunmap.h,v 1.3 1990/08/08 08:20:51 cimarron Exp $"
#undef bool	
#undef bytea	
#undef char16	
#undef dt	
#undef int2	
#undef int28	
#undef int4	
#undef oid	
#undef oid8	
#undef regproc	
#undef text	

#endif
