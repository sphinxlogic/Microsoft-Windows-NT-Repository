/* $Header: /private/postgres/src/lib/H/planner/RCS/relnode.h,v 1.5 1991/11/15 16:23:23 hong Exp $ */

#include "nodes/relation.h"
extern Rel get_rel ARGS((LispValue relid));
extern Rel rel_member ARGS((LispValue relid, LispValue rels));
