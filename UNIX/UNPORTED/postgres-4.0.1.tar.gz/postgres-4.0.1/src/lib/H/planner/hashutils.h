/*------------------------------------------------------------------
 * Identification:
 *     $Header: /private/postgres/src/lib/H/planner/RCS/hashutils.h,v 1.6 1991/11/15 16:22:29 hong Exp $
 */

extern LispValue group_clauses_by_hashop ARGS((LispValue clauseinfo_list, LispValue inner_relid));
extern HInfo match_hashop_hashinfo ARGS((ObjectId hashop, LispValue hashinfo_list));
