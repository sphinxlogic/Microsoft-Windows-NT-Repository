/* $Header: /private/postgres/src/lib/H/planner/RCS/prepqual.h,v 1.5 1991/11/18 17:30:26 mer Exp $ */

extern LispValue preprocess_qualification ARGS((LispValue qual, LispValue tlist));
extern LispValue cnfify ARGS((LispValue qual, bool removeAndFlag));
extern LispValue pull_args ARGS((LispValue qual));
extern LispValue pull_ors ARGS((LispValue orlist));
extern LispValue pull_ands ARGS((LispValue andlist));
extern LispValue find_nots ARGS((LispValue qual));
extern LispValue push_nots ARGS((LispValue qual));
extern LispValue normalize ARGS((LispValue qual));
extern LispValue or_normalize ARGS((LispValue orlist));
extern LispValue distribute_args ARGS((LispValue item, LispValue args));
extern LispValue qualcleanup ARGS((LispValue qual));
extern LispValue remove_ands ARGS((LispValue qual));
extern LispValue update_relations ARGS((LispValue tlist));
extern LispValue update_clauses ARGS((LispValue update_relids, LispValue qual, LispValue command));
