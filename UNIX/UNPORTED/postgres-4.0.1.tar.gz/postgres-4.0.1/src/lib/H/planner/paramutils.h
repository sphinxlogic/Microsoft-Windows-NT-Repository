/*$Header: /private/postgres/src/lib/H/planner/RCS/paramutils.h,v 1.2 1989/12/06 12:13:40 ong Version_2 $ */
extern LispValue find_parameters ARGS((LispValue plan));
extern LispValue find_all_parameters ARGS((LispValue tree));
extern LispValue substitute_parameters ARGS((LispValue plan, int params));
extern LispValue assoc_params ARGS((LispValue plan, LispValue param_alist));
