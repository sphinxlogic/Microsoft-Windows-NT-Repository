/* $Header: /private/postgres/src/lib/H/planner/RCS/clauseinfo.h,v 1.4 1991/11/17 20:37:27 mer Exp $ */

extern bool valid_or_clause ARGS((LispValue clauseinfo));
extern LispValue get_actual_clauses ARGS((LispValue clauseinfo_list));
extern LispValue get_relattvals ARGS((LispValue clauseinfo_list));
extern LispValue get_joinvars ARGS((LispValue relid, LispValue clauseinfo_list));
extern LispValue get_joinvar ARGS((ObjectId relid, CInfo clauseinfo));
extern LispValue get_opnos ARGS((LispValue clauseinfo_list));
