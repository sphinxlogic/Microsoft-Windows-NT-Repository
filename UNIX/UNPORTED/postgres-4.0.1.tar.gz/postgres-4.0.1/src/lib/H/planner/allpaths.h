/* $Header: /private/postgres/src/lib/H/planner/RCS/allpaths.h,v 1.4 1991/11/15 16:22:00 hong Exp $
 */
extern LispValue find_paths ARGS((LispValue rels, int nest_level, LispValue sortkeys));
extern LispValue find_rel_paths ARGS((LispValue rels, int level, LispValue sortkeys));
extern LispValue find_join_paths ARGS((LispValue outer_rels, int levels_left, int nest_level));
