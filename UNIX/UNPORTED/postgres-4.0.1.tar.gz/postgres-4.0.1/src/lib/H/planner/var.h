/*
 * Header file for varnodes stuff 
 * in var.c
 * $Header: /private/postgres/src/lib/H/planner/RCS/var.h,v 1.7 1992/07/04 04:04:00 mao Exp $
 */

extern LispValue pull_var_clause ARGS((LispValue clause));
extern bool var_equal ARGS((LispValue var1, LispValue var2));
extern int numlevels ARGS((Var var));
extern LispValue pull_agg_clause ARGS((LispValue clause));
