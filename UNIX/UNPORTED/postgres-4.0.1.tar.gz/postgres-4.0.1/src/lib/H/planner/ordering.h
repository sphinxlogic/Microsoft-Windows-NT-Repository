/* $Header: /private/postgres/src/lib/H/planner/RCS/ordering.h,v 1.3 1989/09/05 17:31:37 mao Version_2 $ */

extern bool equal_path_path_ordering ARGS((LispValue path_ordering1, LispValue path_ordering2));
extern bool equal_path_merge_ordering ARGS((LispValue path_ordering, LispValue merge_ordering));
extern bool equal_merge_merge_ordering ARGS((LispValue merge_ordering1, LispValue merge_ordering2));
