/* $Header: /private/postgres/src/lib/H/planner/RCS/planner.h,v 1.8 1991/11/15 16:23:11 hong Exp $ */

extern Plan planner ARGS((LispValue parse));
extern Plan make_sortplan ARGS((List tlist, List sortkeys, List sortops, Plan plannode));
extern Plan init_query_planner ARGS((LispValue root, LispValue tlist, LispValue qual));
extern Existential make_existential ARGS((Plan left, Plan right));
extern void init_planner ARGS(());
