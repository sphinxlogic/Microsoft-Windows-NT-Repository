/* $Header: /private/postgres/src/lib/H/planner/RCS/indexnode.h,v 1.4 1991/11/15 16:22:31 hong Exp $ */

extern LispValue find_relation_indices ARGS((Rel rel));
extern LispValue find_secondary_index ARGS((bool notfirst, ObjectId relid));
