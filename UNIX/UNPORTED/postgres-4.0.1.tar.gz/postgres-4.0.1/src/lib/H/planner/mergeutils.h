/*------------------------------------------------------------------
 * Identification:
 *     $Header: /private/postgres/src/lib/H/planner/RCS/mergeutils.h,v 1.6 1991/11/15 16:22:57 hong Exp $
 */

extern LispValue group_clauses_by_order ARGS((LispValue clauseinfo_list, LispValue inner_relid));
extern MInfo match_order_mergeinfo ARGS((MergeOrder ordering, LispValue mergeinfo_list));
