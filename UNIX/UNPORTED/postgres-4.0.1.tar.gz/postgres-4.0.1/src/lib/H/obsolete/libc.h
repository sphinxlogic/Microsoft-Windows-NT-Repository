#ifndef	LibCIncluded	/* Include this file only once. */
#define LibCIncluded	1
/* ----------------
 *	THIS FILE IS GOING AWAY.. -cim 6/12/90
 * ----------------
 */

#define LIBC_H_OBSOLETE 1
#define LIBC_H_OBSOLETE 2
    
#if 0
/*
 * libc.h --
 *	Standard UNIX C library definitions.
 *
 * Note:
 *	This file for the Sun UNIX OPERATING SYSTEM!!!
 *
 * Identification:
 *	$Header: /private/postgres/src/lib/H/obsolete/RCS/libc.h,v 1.1 1990/06/12 21:25:10 cimarron Version_2 $
 */

/*
 *	MDD 11-Apr-89, removed #include <memory.h>
 */

extern char
	*memccpy(),
	*memchr(),
	*memcpy(),
	*memset();
extern int memcmp();

#ifndef C_H
#include "c.h"
#endif

/* ----------------
 *	LibCCopyLength is only used within this file. -cim 6/12/90
 * ----------------
 */
typedef int	LibCCopyLength;

/*
 * memccpy --
 *	memory(3)
 */
extern
char *
memccpy ARGS((
	const String		toBuffer,
	const String		fromBuffer,
	const char		stopCharacter,
	const LibCCopyLength	length
));

/*
 * memchr --
 *	memory(3)
 */
extern
char *
memchr ARGS((
	const String		buffer,
	const char		stopCharacter,
	const LibCCopyLength	length
));

/*
 * memchr --
 *	memory(3)
 */
extern
int
memcmp ARGS((
	const String		buffer1,
	const String		buffer2,
	const LibCCopyLength	length
));

/*
 * memcpy --
 *	memory(3)
 */
extern
char *
memcpy ARGS((
	const String		toBuffer,
	const String		fromBuffer,
	const LibCCopyLength	length
));

/*
 * memset --
 *	memory(3)
 */
extern
char *
memset ARGS((
	const String		toBuffer,
	const char		value,
	const LibCCopyLength	length
));

#endif
#endif	/* !defined(LibCIncluded) */
