#ifndef	ControlIncluded	/* Include this file only once. */
#define ControlIncluded	1
/* ----------------
 *	THIS FILE IS GOING AWAY.  -cim
 * ----------------
 */

#define CONTROL_H_OBSOLETE 1
#define CONTROL_H_OBSOLETE 2

#if 0
/*
 * control.h --
 *	Postgres control definition
 *
 * Identification:
 *	$Header: /private/postgres/src/lib/H/obsolete/RCS/control.h,v 1.1 1990/06/12 21:25:01 cimarron Version_2 $
 */


#ifndef C_H
#include "c.h"
#endif

typedef int		ControlChannel;
#define   ControlChannelValid(channel)	((channel) != -1)

typedef unsigned short	ControlType;
#define   ControlTypeMax		16
#define   ControlTypeValid(type)	((type) < ControlTypeMax)

typedef unsigned short	ControlSize;
#define   ControlSizeMax		256
#define   ControlSizeValid(size)	((size) < ControlSizeMax)

typedef char		*ControlData;
#define  ControlDataValid(data)		((data) != NULL)

typedef void ControlHandler ARGS((
	ControlType	type,
	ControlData	data,
	ControlSize	size
));

extern
void
ControlInstall ARGS((
	ControlType	type,
	ControlHandler	handler
));

extern
void
ControlReceive ARGS((
	ControlChannel	channel,
	ControlType	*typeP,
	ControlData	*dataP,
	ControlSize	*sizeP
));

extern
void
ControlDispatch ARGS((
	ControlType	type,
	ControlData	data,
	ControlSize	size
));

extern
void
ControlSend ARGS((
	ControlChannel	channel,
	ControlType	type,
	ControlData	data,
	ControlSize	size
));

#endif

#endif	/* !defined(ControlIncluded) */
