#ifndef	TupSizIncluded	/* Include this file only once. */
#define TupSizIncluded	1
/* ----------------------------------------------------------------
 *	THIS FILE IS GOING AWAY -cim 6/8/90
 * ----------------------------------------------------------------
 */

#define TUPSIZ_H_OBSOLETE 1
#define TUPSIZ_H_OBSOLETE 2
    
#if 0
/*
 * tupsiz.h --
 *	POSTGRES tuple size definitions.
 *
 * Identification:
 *	$Header: /private/postgres/src/lib/H/obsolete/RCS/tupsiz.h,v 1.1 1990/06/12 21:25:17 cimarron Version_2 $
 */
#ifndef C_H
#include "c.h"
#endif

typedef Size	TupleSize;

#define MaxTupleSize	0x7fffffff

/*
 * TupleSizeIsValid --
 *	True iff the tuple size is valid.
 */
extern
bool
TupleSizeIsValid ARGS((
	TupleSize	size
));

#endif
#endif	/* !defined(TupSizIncluded) */
