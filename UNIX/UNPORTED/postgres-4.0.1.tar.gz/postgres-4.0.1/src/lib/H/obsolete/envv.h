#ifndef	EnvVIncluded		/* Include this only once */
#define EnvVIncluded	1
/* ----------------
 *	THIS FILE IS GOING AWAY -cim 6/8/90
 * ----------------
 */

#define ENVV_H_OBSOLETE 1
#define ENVV_H_OBSOLETE 2
    
#if 0
/*
 * envv.h --
 *	POSTGRES known environment variable definitions.
 *
 * Identification:
 *	$Header: /private/postgres/src/lib/H/obsolete/RCS/envv.h,v 1.1 1990/06/12 21:25:08 cimarron Version_2 $
 */

typedef String	EnvVarName;

/*
 * getenv --
 *	getenv(3).
 */
extern
String
getenv ARGS((
	EnvVarName	name
));

/*
 * EnableAbortEnvVarName --
 *	Enables system abort iff set to a non-empty string in environment.
 */
#define EnableAbortEnvVarName	"POSTGRESABORT"

/* START HERE */

#endif
#endif	/* !defined(EnvVIncluded) */
