#ifndef	ACCESS_H
#define	ACCESS_H	"$Header: /private/postgres/src/lib/H/obsolete/RCS/access.h,v 1.1 1990/06/12 21:24:36 cimarron Version_2 $"

#define ACCESS_H_OBSOLETE 1    
#define ACCESS_H_OBSOLETE 2

/* ----------------
 *	this file has been made obsolete.  references to it should
 *	be replaced by skey.h -cim 6/8/90
 * ----------------
 */
#include "skey.h"

#endif
