
/*
 * anum.h --
 *	POSTGRES known attribute number definitions.
 *
 * Identification:
 *	$Header: /private/postgres/src/lib/H/obsolete/RCS/anum.h,v 1.13 1990/08/17 08:54:21 cimarron Exp $
 */

#ifndef	ANumIncluded
#define ANumIncluded

/* ----------------
 *	This file has been obsoleted by the information in the
 *	lib/H/catalog/pg_xxx.h files.
 * ----------------
 */
#define ANUM_H_OBSOLETE	1
#define ANUM_H_OBSOLETE	2

#define AccessMethodOperatorAccessMethodIdAttributeNumber	1
#define AccessMethodOperatorOperatorClassIdAttributeNumber	2
#define AccessMethodOperatorOperatorIdAttributeNumber		3
#define AccessMethodOperatorStrategyAttributeNumber		4
#define AccessMethodNameAttributeNumber				1
#define AttributeRelationIdAttributeNumber			1
#define AttributeNameAttributeNumber				2
#define AttributeNumberAttributeNumber				8
#define AttributeProcAttributeNumber				12
#define IndexRelationIdAttributeNumber				1
#define IndexHeapRelationIdAttributeNumber			2
#define IndexKeyAttributeNumber					3
#define IndexIsArchivedAttributeNumber				6
#define InheritancePrecidenceListRelationIdAttributeNumber	1
#define	InheritsRelationIdAttributeNumber			1
#define	InheritsParentAttributeNumber				2
#define	InheritsSequenceNumberAttributeNumber			3
#define	LanguageNameAttributeNumber				1
#define OperatorNameAttributeNumber				1
#define OperatorKindAttributeNumber				4
#define OperatorLeftAttributeNumber				7
#define OperatorRightAttributeNumber				8
#define	OperatorResultAttributeNumber				9
#define	OperatorProcedureAttributeNumber			14
#define	OperatorRestrictAttributeNumber				15
#define	OperatorJoinAttributeNumber				16
#define OperatorClassNameAttributeNumber			1
#define	ProcedureNameAttributeNumber				1
#define	ProcedureReturnTypeAttributeNumber			8
#define	ProcedureBinaryAttributeNumber				10
#define RelationNameAttributeNumber				1
#define RelationPagesAttributeNumber				4
#define RelationTuplesAttributeNumber				5
#define	RelationExpiresAttributeNumber				6
#define	RelationPreservedAttributeNumber			7
#define RelationHasIndexAttributeNumber				8
#define RelationStubAttributeNumber				15
#define	RuleNameAttributeNumber					1
#define	RulePlansRuleIdAttributeNumber				1
#define	RulePlansPlanIdAttributeNumber				2
#define	RulePlansPlanAttributeNumber				3
#define	StatisticRelationIdAttributeNumber			1
#define	StatisticAttributeNumberAttributeNumber			2
#define	StatisticOperatorAttributeNumber			3
#define	StatisticLowKeyAttributeNumber				4
#define	StatisticHighKeyAttributeNumber				5
#define	TypeNameAttributeNumber					1
#define TypeLengthAttributeNumber				3
#define	TypeIsDefinedAttributeNumber				7
#define	TypeDefaultAttributeNumber				14
#define	VersionRelationIdAttributeNumber			1
#define	VersionBaseRelationIdAttributeNumber			2

#define Prs2RuleNameAttributeNumber				1
#define Prs2RuleEventTypeAttributeNumber			2
#define Prs2RuleEventTargetRelationAttributeNumber		3
#define Prs2RuleEventTargetAttributeAttributeNumber		4
#define Prs2RuleNecessaryAttributeNumber			5
#define Prs2RuleSufficientAttributeNumber			6
#define Prs2RuleTextAttributeNumber				7

#define Prs2PlansRuleIdAttributeNumber				1
#define Prs2PlansPlanNumberAttributeNumber			2
#define Prs2PlansCodeAttributeNumber				3

#define AttributeRelationNumberOfAttributes			12
#define InheritsRelationNumberOfAttributes			3
#define InheritancePrecidenceListRelationNumberOfAttributes	3
#define IndexRelationNumberOfAttributes				6
#define	OperatorRelationNumberOfAttributes			16
#define ProcedureRelationNumberOfAttributes			10
/* #define RelationRelationNumberOfAttributes			15 */
#define RelationRelationNumberOfAttributes			15
#define	RulePlansRelationNumberOfAttributes			3
#define	RuleRelationNumberOfAttributes				9
#define TypeRelationNumberOfAttributes				14
#define Prs2RuleRelationNumberOfAttributes			7
#define Prs2PlansRelationNumberOfAttributes			3

/* XXX well known relation identifiers put here for now */
#define VariableRelationId		90
#define	AttributeRelationId		75

#endif	/* !defined(ANumIncluded) */
