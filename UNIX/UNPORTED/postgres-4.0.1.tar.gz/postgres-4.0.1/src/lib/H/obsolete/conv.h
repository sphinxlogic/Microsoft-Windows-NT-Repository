#ifndef	ConvIncluded	/* Include this file only once */
#define ConvIncluded	1
    
/* ----------------
 *	THIS FILE IS GOING AWAY.  -cim 6/8/90
 * ----------------
 */

#define CONV_H_OBSOLETE 1    
#define CONV_H_OBSOLETE 2

#if 0
/*
 * conv.h --
 *	Internal/external data conversion definitions.
 *
 * Identification:
 *	$Header: /private/postgres/src/lib/H/obsolete/RCS/conv.h,v 1.1 1990/06/12 21:25:03 cimarron Version_2 $
 */

#ifndef C_H
#include "c.h"
#endif

typedef Pointer	External;
typedef Pointer	Internal;		/* this is called Datum, elsewhere */
typedef int16	InternalLength;
typedef bool	InternalByValue;

/*
 * ExternalIsValid --
 *	Returns true iff external representation is valid.
 */
extern
bool
ExternalIsValid ARGS((
	External	data,
	InternalLength	length,
	InternalByValue	byValue
));

/*
 * InternalIsValid --
 *	Returns true iff internal representation is valid.
 */
extern
bool
InternalIsValid ARGS((
	Internal	data,
	InternalLength	length,
	InternalByValue	byValue
));

/*
 * ExternalGetLength --
 *	Returns the length of external data.
 */
extern
uint32
ExternalGetLength ARGS((
	External	data,
	InternalLength	length,
	InternalByValue	byValue
));

/*
 * ExternalGetInternal --
 *	Returns the internal representation corresponding to external data.
 */
extern
Internal
ExternalGetInternal ARGS((
	External	data,
	InternalLength	length,
	InternalByValue	byValue
));

/*
 * InternalGetExternal --
 *	Returns the external representation corresponding to internal data.
 */
extern
External
InternalGetExternal ARGS((
	Internal	data,
	InternalLength	length,
	InternalByValue	byValue
));

#endif

#endif	/* !defined(ConvIncluded) */
