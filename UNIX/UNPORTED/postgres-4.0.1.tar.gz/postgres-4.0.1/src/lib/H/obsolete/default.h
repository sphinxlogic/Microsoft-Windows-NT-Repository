#ifndef	DefaultIncluded		/* Include this file only once */
#define DefaultIncluded	1

/* ----------------
 *	THIS FILE IS GOING AWAY.  -cim 6/12/90
 * ----------------
 */
#define DEFAULT_H_OBSOLETE 1
#define DEFAULT_H_OBSOLETE 2
    
#if 0    
/*
 * default.h --
 *	POSTGRES tunable defaults definitions.
 *
 * Identification:
 *	$Header: /private/postgres/src/lib/H/obsolete/RCS/default.h,v 1.1 1990/06/12 21:25:06 cimarron Version_2 $
 */

#ifndef C_H
#include "c.h"
#endif

/*
 * LookupDefault --
 *	Returns default value associated with given string.
 *
 * Exceptions:
 *	BadArg if string is invalid.
 *
 * Note:
 *	Until the defaults are stored in the DEFAULT relation, default
 * will be returned.
 */
extern
String		/* XXX Datum */
FetchDefault ARGS((
	String	string,
	String	standard
));
#endif
#endif	/* !defined(DefaultIncluded) */
