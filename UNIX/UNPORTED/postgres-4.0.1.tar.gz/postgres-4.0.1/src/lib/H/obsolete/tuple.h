#ifndef	TUPLE_H
#define	TUPLE_H	"$Header: /private/postgres/src/lib/H/obsolete/RCS/tuple.h,v 1.1 1990/06/12 21:25:15 cimarron Version_2 $"
    
#define TUPLE_H_OBSOLETE 1
#define TUPLE_H_OBSOLETE 2

/* ----------------
 *	this file has been made obsolete.  references to it should
 *	be replaced by htup.h -cim 6/8/90
 * ----------------
 */
#include "htup.h"

#endif
