/*
 * rproc.h --
 *	POSTGRES known registered procedure definitions.
 *
 * Identification:
 *	$Header: /private/postgres/src/lib/H/obsolete/RCS/rproc.h,v 1.5 1990/08/17 08:54:19 cimarron Exp $
 */

#ifndef	RProcIncluded	/* Include this file only once. */
#define RProcIncluded	1

#define RPROC_H_OBSOLETE 1
#define RPROC_H_OBSOLETE 2

/* ----------------
 *	This file has been obsoleted by the information in
 *	lib/H/catalog/pg_proc.h
 * ----------------
 */
#include "catalog/pg_proc.h"

#if 0
/*
 * Internal/external conversion functions
 */
#define TextInRegProcedure			46

/*
 * Equality testing functions
 */
#define NameEqualRegProcedure			62
#define Character16EqualRegProcedure		62
#define Integer16EqualRegProcedure		63
#define Integer32EqualRegProcedure		65
#define ObjectIdEqualRegProcedure		184
#endif

#endif	/* !defined(RProcIncluded) */
