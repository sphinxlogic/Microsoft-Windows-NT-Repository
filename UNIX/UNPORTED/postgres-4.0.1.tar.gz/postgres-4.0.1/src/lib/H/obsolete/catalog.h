#ifndef	_CATALOG_H_
#define	_CATALOG_H_	"$Header: /private/postgres/src/lib/H/obsolete/RCS/catalog.h,v 1.2 1990/08/17 08:54:23 cimarron Exp $"

#define CATALOG_H_OBSOLETE 1
#define CATALOG_H_OBSOLETE 2
    
/* ----------------
 *	this file has been made obsolete by the information in
 *	src/lib/H/catalog/pg_xxx.h
 * ----------------
 */
#include "cat.h"

#endif _CATALOG_H_
