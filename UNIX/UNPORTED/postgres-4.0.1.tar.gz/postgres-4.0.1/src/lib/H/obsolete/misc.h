#ifndef MiscIncluded       /* include this file only once */
#define MiscIncluded 1
/* ----------------
 *	THIS FILE IS GOING AWAY -cim 6/8/90
 * ----------------
 */

#define MISC_H_OBSOLETE 1
#define MISC_H_OBSOLETE 2
    
#if 0
/* ----------------------------------------------------------------
 * misc.h
 *      miscellanous defines used in POSTGRES
 *      
 * Identification:
 *      $Header: /private/postgres/src/lib/H/obsolete/RCS/misc.h,v 1.1 1990/06/12 21:25:12 cimarron Version_2 $
 * ----------------------------------------------------------------
 */
static char     misc_h[] = "$Header: /private/postgres/src/lib/H/obsolete/RCS/misc.h,v 1.1 1990/06/12 21:25:12 cimarron Version_2 $";

/* ----------------------------------------------------------------
 *	misc #defines
 * ----------------------------------------------------------------
 */

#define FALSE 0
#define TRUE 1

#define NullPointer		((Pointer) 0)

#define MaxInteger 		2147483647

#define InvalidLogXid           InvalidTransactionId
#define InvalidLogBlockNumber   4294967295
#define UnknownLogBlockNumber   4294967294
#define InvalidIndex            4294967295

/* InvalidLogBlockNumber = 2^32 - 1 = max(uint32)
 * UnknownLogBlockNumber = 2^32 - 2 = max(uint32) - 1 */

/* ----------------------------------------------------------------
 *   RelationTupleFormGetRelationName is an accessor function
 *   that should be added to rel.h
 * ----------------------------------------------------------------
 */

#define RelationTupleFormGetRelationName(relationTuple) \
   (relationTuple->relname)

/* ----------------------------------------------------------------
 *	OFFSET is useful to get the offset of a member in
 *	another structure
 * ----------------------------------------------------------------
 */

#define OFFSET(type,mem)	((int) &(((type *) NULL)->mem))

/* ----------------------------------------------------------------
 *	puts adds a newline, fputs doesnt so we use
 *	Puts. This also eliminates the confusion caused
 *	by fputs stupid backward arguments
 * ----------------------------------------------------------------
 */

#define Puts(s) fputs(s, stdout)

/* ----------------------------------------------------------------
 *	miscellaneous programming style #defines
 * ----------------------------------------------------------------
 */

#define forever for (;;)

#define FUNCTION  /* empty macro used for cross referencing */

#define INCOMPLETE /* empty macro */

#define INEFFICIENT /* bad function - revise it */

#define NOTTESTED   /* function not fully tested (perhaps buggy) */

/* ----------------------------------------------------------------
 *	Debugging stuff
 * ----------------------------------------------------------------
 */

#define NoDebugLevel 0
#define AccessDebugLevel NoDebugLevel+2
#define GeneralDebugLevel AccessDebugLevel+2
#define PrintDebugLevel GeneralDebugLevel+2
#define ComputeDebugLevel PrintDebugLevel+2
#define FormDebugLevel ComputeDebugLevel+2
#define RepeatPrintDebugLevel FormDebugLevel+2
#define RepeatComputeDebugLevel RepeatPrintDebugLevel+2
#define RepeatFormDebugLevel RepeatComputeDebugLevel+2

#define NoInternalDebugLevel NoDebugLevel+1
#define AccessInternalDebugLevel AccessDebugLevel+1
#define GeneralInternalDebugLevel GeneralDebugLevel+1
#define PrintInternalDebugLevel PrintDebugLevel+1
#define ComputeInternalDebugLevel ComputeDebugLevel+1
#define FormInternalDebugLevel FormDebugLevel+1
#define RepeatPrintInternalDebugLevel RepeatPrintDebugLevel+1
#define RepeatComputeInternalDebugLevel RepeatComputeDebugLevel+1
#define RepeatFormInternalDebugLevel RepeatFormDebugLevel+1

#endif
#endif /* defined MiscIncluded */
