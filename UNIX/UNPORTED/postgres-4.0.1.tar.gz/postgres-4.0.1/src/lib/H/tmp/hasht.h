/*
 * hasht.h--
 *	hash table related functions that are not directly supported
 *	under utils/hash.
 *
 * Identification:
 *	$Header: /private/postgres/src/lib/H/tmp/RCS/hasht.h,v 1.4 1991/11/14 14:56:26 jolly Exp $
 *
 */

#ifndef	HashTIncluded		/* Include this file only once */
#define HashTIncluded	1

#include "utils/hsearch.h"

void HashTableWalk ARGS((HTAB *hashtable, void (*func)(), int arg));

#endif	/* !defined(HashTIncluded) */
