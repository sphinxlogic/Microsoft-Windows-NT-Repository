/*
 * oid.h --
 *	POSTGRES object identifier definitions.
 *
 * $Header: /private/postgres/src/lib/H/tmp/RCS/oid.h,v 1.10 1991/08/12 22:16:07 mao Exp $
 */

#ifndef	OIdIncluded		/* Include this file only once */
#define OIdIncluded	1

#include "tmp/c.h"

typedef uint32	oid;

#define ObjectId oid

#define InvalidObjectId	0

#endif	/* !defined(OIdIncluded) */
