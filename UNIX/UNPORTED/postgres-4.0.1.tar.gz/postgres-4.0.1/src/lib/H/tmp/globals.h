/*
 * globals.h --
 *
 */

#ifndef	GlobalsIncluded		/* Include this file only once */
#define	GlobalsIncluded	1

/*
 * Identification:
 */
#define GLOBALS_H	"$Header: /private/postgres/src/lib/H/tmp/RCS/globals.h,v 1.9 1992/06/10 05:07:52 mer Exp $"

#include "tmp/c.h"
#include "storage/sinval.h"

extern int Debugfile;
extern int Ttyfile;
extern int Portfd;
extern int Packfd;
extern int Pipefd;
extern int Noversion;		/* moved from magic.c	*/

extern BackendId    MyBackendId;
extern BackendTag   MyBackendTag;
extern NameData	    MyDatabaseNameData;
extern Name	    MyDatabaseName;
extern bool	    MyDatabaseIdIsInitialized;
extern ObjectId	    MyDatabaseId;
extern bool	    TransactionInitWasProcessed;

extern bool	    IsUnderPostmaster;

extern struct bcommon Ident;	/* moved from dlog */

extern LastOidProcessed;	/* for query rewrite */

#define MAX_PARSE_BUFFER 8192

/* ----------------
 *	number of buffers in buffer pool
 * ----------------
 */
#define NDBUFS 16

#endif	/* !defined(GlobalsIncluded) */
