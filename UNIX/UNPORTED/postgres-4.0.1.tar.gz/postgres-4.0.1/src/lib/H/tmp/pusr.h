/*
 * pusr.h --
 *	POSTGRES user permissions definitions.
 *
 * Identification:
 *	$Header: /private/postgres/src/lib/H/tmp/RCS/pusr.h,v 1.2 1990/08/17 08:54:32 cimarron Exp $
 */

#ifndef	PUsrIncluded		/* Include this file only once */
#define PUsrIncluded	1

#include "tmp/postgres.h"

#define PUSR_H	"$Header: /private/postgres/src/lib/H/tmp/RCS/pusr.h,v 1.2 1990/08/17 08:54:32 cimarron Exp $"

/*
 * GetUserId --
 *	Returns user id.
 *
 * Exceptions:
 *	BadState if called before InitUser.
 */
extern
ObjectId
GetUserId ARGS((
	void
));

/*
 * InitUser --
 *	Sets user permission information.
 *
 * Exceptions:
 *	BadState if called more than once.
 */
extern
void
InitUser ARGS((
	void
));

#endif	/* !defined(PUsrIncluded) */
