/*
 * regproc.h --
 *	POSTGRES registered procedure definitions.
 */

#ifndef	RegProcIncluded		/* Include this file only once */
#define RegProcIncluded	1

/*
 * Identification:
 */
#define REGPROC_H	"$Header: /private/postgres/src/lib/H/tmp/RCS/regproc.h,v 1.3 1991/08/12 22:20:59 mao Exp $"

#include "tmp/c.h"
#include "tmp/oid.h"

typedef ObjectId	RegProcedure;

#endif	/* !defined(RegProcIncluded) */
