#ifndef	_MAGIC_H_
#define	_MAGIC_H_	"$Header: /private/postgres/src/lib/H/tmp/RCS/magic.h,v 1.4 1991/12/15 02:00:57 glass Exp $"

/*
 *	magic.h		- definitions of the indexes of the magic numbers
 */

#define	PG_RELEASE	1
#define PG_VERSION	1
#define	PG_VERFILE	"PG_VERSION"

#define	M_RELATION_R	0
#define	M_ADT_R		1
#define	M_INT4_EQ_F	2

/* #define	NMAGIC		3*/

#endif
