/* 
 * atoms.h
 * - string,atom lookup thingy, reduces strcmp traffic greatly
 * in the bowels of the system.  Look for actual defs in lib/C/atoms.c
 *
 * $Header: /private/postgres/src/lib/H/parser/RCS/atoms.h,v 1.4 1991/11/14 23:31:13 jolly Exp $
 */

/*
#define lengthof(byte_array)	(sizeof(byte_array) / sizeof((byte_array)[0]))
#define endof(byte_array)	(&byte_array[lengthof(byte_array)])
*/
typedef struct ScanKeyword {
	char	*name;
	int	value;
} ScanKeyword;

extern ScanKeyword *ScanKeywordLookup ARGS((char *txt));
extern String AtomValueGetString ARGS((int atomval));
extern ScanKeyword	ScanKeywords[];

