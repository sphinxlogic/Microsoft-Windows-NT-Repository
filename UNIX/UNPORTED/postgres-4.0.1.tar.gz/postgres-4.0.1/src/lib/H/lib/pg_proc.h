/* ------------------------------------------
 *   FILE
 *	pg_proc.h
 * 
 *   DESCRIPTION
 *	prototypes for functions in lib/catalog/pg_proc.c
 *
 *   IDENTIFICATION
 *	$Header: /private/postgres/src/lib/H/lib/RCS/pg_proc.h,v 1.1 1991/11/14 23:26:49 jolly Exp $
 * -------------------------------------------
 */
#ifndef PG_PROC_H
#define PG_PROC_H
void ProcedureDefine ARGS((Name procedureName , Name returnTypeName , Name languageName , char *prosrc , char *probin , Boolean canCache , List argList ));
#endif
