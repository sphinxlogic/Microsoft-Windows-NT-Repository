/* ------------------------------------------
 *   FILE
 *	fcache.h
 * 
 *   DESCRIPTION
 *	prototypes for functions in lib/C/fcache.c
 *
 *   IDENTIFICATION
 *	$Header: /private/postgres/src/lib/H/lib/RCS/fcache.h,v 1.1 1991/11/14 14:54:27 jolly Exp $
 * -------------------------------------------
 */
#ifndef FCACHE_H
#define FCACHE_H
FunctionCachePtr init_fcache ARGS((ObjectId foid , Boolean use_syscache ));
void set_fcache ARGS((Node node , ObjectId foid ));
#endif
