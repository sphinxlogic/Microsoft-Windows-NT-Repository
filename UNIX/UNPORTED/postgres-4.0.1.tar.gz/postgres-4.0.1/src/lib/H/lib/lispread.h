/* ------------------------------------------
 *   FILE
 *	lispread.h
 * 
 *   DESCRIPTION
 *	prototypes for functions in lib/C/lispread.c
 *
 *   IDENTIFICATION
 *	$Header: /private/postgres/src/lib/H/lib/RCS/lispread.h,v 1.1 1991/11/14 14:57:50 jolly Exp $
 * -------------------------------------------
 */

#ifndef LISPREAD_H
#define LISPREAD_H
NodeTag lispTokenType ARGS((char *token , int length ));
LispValue lispRead ARGS((bool read_car_only ));
char *lsptok ARGS((char *string , int *length ));
LispValue lispReadStringWithParams ARGS((char *string , ParamListInfo *thisParamListP ));
LispValue lispReadString ARGS((char *string ));
#endif LISPREAD_H
