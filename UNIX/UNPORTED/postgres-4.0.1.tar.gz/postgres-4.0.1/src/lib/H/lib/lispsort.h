/* $Header: /private/postgres/src/lib/H/lib/RCS/lispsort.h,v 1.2 1992/07/08 07:10:45 joey Exp $ */
extern LispValue lisp_qsort ARGS((LispValue list,    /* the list to be sorted */
				  int (*compare)()));  /* function to compare 
							 two nodes */
