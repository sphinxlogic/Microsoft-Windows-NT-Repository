/* $Header: /private/postgres/src/lib/H/lib/RCS/lisplist.h,v 1.1 1991/11/11 23:18:11 hong Exp $ */
/* lisplist.c */
LispValue MakeList ARGS((LispValue, ... ));
