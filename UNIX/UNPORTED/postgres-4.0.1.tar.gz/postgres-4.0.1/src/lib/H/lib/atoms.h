/* ------------------------------------------
 *   FILE
 *	atoms.h
 * 
 *   DESCRIPTION
 *	prototypes for functions in lib/C/atoms.c
 *
 *   IDENTIFICATION
 *	$Header: /private/postgres/src/lib/H/lib/RCS/atoms.h,v 1.1 1991/11/14 14:54:11 jolly Exp $
 * -------------------------------------------
 */
#ifndef ATOMS_H
#define ATOMS_H
ScanKeyword *ScanKeywordLookup ARGS((char *text ));
String AtomValueGetString ARGS((int atomval ));
#endif

