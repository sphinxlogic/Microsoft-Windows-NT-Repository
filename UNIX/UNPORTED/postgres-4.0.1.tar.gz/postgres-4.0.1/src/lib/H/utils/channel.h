#ifndef	_CHANNEL_H_
#define	_CHANNEL_H_	"$Header: /private/postgres/src/lib/H/utils/RCS/channel.h,v 1.3 1989/09/05 17:04:44 mao Version_2 $"

/*
 * communication channels definitions
 */

#define	NCHANN	16	/* max number of open channels */

struct	deque {
	int		dq_len;
	char		*dq_data;
	struct	deque	*dq_next;
};

struct	chdisp {
	short		ch_fd;		/* file descriptor for this channel */
	short		ch_flags;	/* status flags */
	struct	deque	*ch_data;	/* data deque */
};

#define	CH_OPEN  1
#define	CH_PRIME 2
#define	CH_SLAVE 4

#define	BOOTLEN	128	/* XXX */

extern	struct	chdisp	Chtab[];

#endif
