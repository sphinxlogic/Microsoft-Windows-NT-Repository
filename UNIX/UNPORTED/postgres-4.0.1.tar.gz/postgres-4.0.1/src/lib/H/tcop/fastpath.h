/*  $Header: /private/postgres/src/lib/H/tcop/RCS/fastpath.h,v 1.1 1991/11/11 23:13:19 hong Exp $ */
/* fastpath.c */
int HandleFunctionRequest ARGS((void ));
