/* $Header: /private/postgres/src/lib/H/tcop/RCS/pfrag.h,v 1.1 1991/11/11 23:14:08 hong Exp $ */
/* pfrag.c */
Fragment InitialPlanFragments ARGS((List parsetree , Plan plan ));
bool plan_is_parallelizable ARGS((Plan plan ));
void OptimizeAndExecuteFragments ARGS((List fragmentlist , CommandDest destination ));
