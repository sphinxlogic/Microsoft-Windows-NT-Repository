/* $Header: /private/postgres/src/lib/H/tcop/RCS/parsev.h,v 1.1 1991/11/11 23:13:38 hong Exp $ */
/* parsev.c */
void ValidateParse ARGS((List parse ));
