/* $Header: /private/postgres/src/lib/H/tcop/RCS/utility.h,v 1.1 1991/11/11 23:13:54 hong Exp $ */
/* utility.c */
void ProcessUtility ARGS((int command , LispValue args , char *commandString , CommandDest dest ));
