/*
 * att.h --
 *	POSTGRES attribute definitions.
 */

#ifndef	AttIncluded		/* Include this file only once */
#define AttIncluded	1

/*
 * Identification:
 */
#define ATT_H	"$Header: /private/postgres/src/lib/H/access/RCS/att.h,v 1.10 1991/04/28 09:16:03 cimarron Exp $"

#include "tmp/c.h"
#include "access/skey.h"   	/* just to reduce levels of #include */
#include "catalog/pg_attribute.h"

typedef AttributeTupleForm	Attribute;

typedef Attribute		*AttributePtr;

/*
 * AttributeIsValid
 *	True iff the attribute is valid.
 */
#define	AttributeIsValid(attribute) PointerIsValid(attribute)

#endif	/* !defined(AttIncluded) */
