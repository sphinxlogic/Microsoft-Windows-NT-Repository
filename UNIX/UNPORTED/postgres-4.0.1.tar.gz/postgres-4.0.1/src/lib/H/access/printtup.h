/*
 * printtup.h --
 *
 *
 * Identification:
 *	$Header: /private/postgres/src/lib/H/access/RCS/printtup.h,v 1.7 1992/03/06 22:17:57 clarsen Exp $
 */

#ifndef	PrintTupIncluded		/* Include this file only once */
#define PrintTupIncluded	1

extern void printtup ARGS((HeapTuple tuple, struct attribute *typeinfo[]));
extern void printtup_internal ARGS((HeapTuple tuple, struct attribute *typeinfo[]));
extern void debugtup ARGS((HeapTuple tuple, struct attribute *typeinfo[]));

#endif	/* !defined(PrintTupIncluded) */
