/*
 * tup.h --
 *	POSTGRES tuple structure definitions.
 *
 * Identification:
 *	$Header: /private/postgres/src/lib/H/access/RCS/tup.h,v 1.5 1990/08/17 08:51:14 cimarron Exp $
 */

#ifndef	TupIncluded	/* Include this file only once. */
#define TupIncluded	1

#include "tmp/c.h"

#endif	/* !defined(TupIncluded) */
