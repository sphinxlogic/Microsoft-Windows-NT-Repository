/*
 * Tuple macros used by both index tuples and heap tuples.
 * 
 * "$Header: /private/postgres/src/lib/H/access/RCS/tupmacs.h,v 1.3 1992/04/03 01:08:12 mer Exp $"
 */

#ifndef TUPMACS_H
#define TUPMACS_H

#define att_isnull(ATT, BITS) (!((BITS)[(ATT) >> 3] & (1 << ((ATT) & 0x07))))

#define fetchatt(A, T) \
 ((*(A))->attbyval ? \
  ((*(A))->attlen > sizeof(short) ? (char *) *(long *) (T) : \
   ((*(A))->attlen < sizeof(short) ? (char *) *(T) : \
	(char *) * (short *) (T))) : (char *) (T))
	
#endif

