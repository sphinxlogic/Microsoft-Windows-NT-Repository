/*
 * xcxt.h --
 *	POSTGRES transaction context definitions.
 *
 *  NOTE: THIS FILE MUST DIE - GREG
 *
 * Identification:
 *	$Header: /private/postgres/src/lib/H/access/RCS/xcxt.h,v 1.13 1991/11/08 15:43:58 kemnitz Exp $
 */

#ifndef	XCxtIncluded	/* Include this file only once */
#define XCxtIncluded	1
#endif	/* !defined(XCxtIncluded) */
