/*
 *  btreectl.h -- Public structure definitions for using the amctl()
 *		  interface to btrees.
 *
 *	$Header: /private/postgres/src/lib/H/access/RCS/btreectl.h,v 1.2 1990/08/17 08:50:41 cimarron Exp $
 */

#ifndef	BTREECTL_H
#define	BTREECTL_H

#include "access/itup.h"

typedef struct BTreeCtlArgData {
	IndexTuple	rlockLeft;
	IndexTuple	rlockRight;
} BTreeCtlArgData;

typedef	BTreeCtlArgData		*BTreeCtlArg;

#endif	/* BTREECTL_H */
