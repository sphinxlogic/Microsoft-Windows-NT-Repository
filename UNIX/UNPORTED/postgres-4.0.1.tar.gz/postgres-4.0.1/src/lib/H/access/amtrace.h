/*
 *  amtrace -- trace info for reporting to user interface
 *
 *	$Header: /private/postgres/src/lib/H/access/RCS/amtrace.h,v 1.3 1989/09/05 17:03:22 mao Version_2 $
 */

# define 	T_SPLIT_OLD	0
# define 	T_SPLIT_NEW	1
# define	T_SEARCHED 	2
# define	T_INSERTED	3
# define	T_RETRIEVED 4
# define	T_SEED		5
# define	T_INIT		6

/* # define	TRACE(flag, tid)	(AM_Trace(flag, tid)) */
# define	TRACE(flag,tid)

# define	MAXTRACE_ENTRIES	1000
