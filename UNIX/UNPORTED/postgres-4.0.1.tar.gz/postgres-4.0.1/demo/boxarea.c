typedef struct {
	double  xh, yh, xl, yl;     /* high and low coords */
} BOX;

#define ABS(X) ((X) > 0 ? (X) : -(X))

int
boxarea(box)

BOX *box;

{
	int width, height;

	width  = ABS(box->xh - box->xl);
	height = ABS(box->yh - box->yl);
	return (width * height);
}
