#!/bin/sh

# $Header: /private/postgres/bench/RCS/wholebench.sh,v 1.1 1991/12/12 12:14:31 mer Exp $

if [ -d $POSTGRESHOME/data/base/bench ]
then
	echo Destroying old bench database ...
	echo destroydb bench | $POSTGRESHOME/bin/postgres -Q template1
fi

$POSTGRESHOME/bench/create.sh
echo Running the benchmark....
$POSTGRESHOME/bench/runwisc.sh
