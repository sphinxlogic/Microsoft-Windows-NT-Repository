#!/bin/sh
# $HEADER:
# 
# wisconsin.sh - populates and runs the wisconsin benchmark on a database
# named "bench".
#

if (test ! -z "$POSTGRESHOME")
then
    PGHOME=$POSTGRESHOME
else
    PGHOME=/usr/postgres
fi

POSTGRES=$PGHOME/bin/postgres

x=1
for i in query1 query2 query3 query4 query5 query6 query7 query8 query9 \
         query10 query11 query12 query13 query14 query15 query16 query17 \
         query18 query19 query26 query27 query28 query29 query30 query31 \
         query32
do
	echo "retrieve (x=$x)" >> /tmp/pg$$
	cat $i >> /tmp/pg$$
	x=`expr $x + 1`
done

#
# the whole benchmark, and the retrieve (x=<i>)'s
#
# Note that in our published benchmark numbers, we executed the command in the
# following fashion:
#
# time $POSTGRES -texecutor -tplanner -f hashjoin -Q bench < /tmp/pg$$
#
#

time $POSTGRES -texecutor -tplanner -Q bench < /tmp/pg$$
