#! /bin/sh
#
#	tardy - a tar post-processor
#	Copyright (C) 1993 Peter Miller.
#	All rights reserved.
#
#	This program is free software; you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation; either version 2 of the License, or
#	(at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.
#
#	You should have received a copy of the GNU General Public License
#	along with this program; if not, write to the Free Software
#	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
#
# MANIFEST: Test the -Prefix option
#

work=/tmp/$$
PAGER=cat
export PAGER

fail()
{
	set +x
	echo FAILED test of the -Prefix option 1>&2
	cd $here
	find $work -type d -user $USER -exec chmod u+w {} \;
	rm -rf $work
	exit 1
}
pass()
{
	set +x
	echo PASSED 1>&2
	cd $here
	find $work -type d -user $USER -exec chmod u+w {} \;
	rm -rf $work
	exit 0
}
trap "fail" 1 2 3 15

here=`pwd`
if test $? -ne 0 ; then exit 1; fi
mkdir $work
if test $? -ne 0 ; then exit 1; fi
cd $work
if test $? -ne 0 ; then fail; fi

#
# sed script to orthoganalize the columns
#
cat > sf << 'fubar'
s/^........./& /
s/\// /
fubar
if test $? -ne 0 ; then fail; fi

#
# awk script to pass the uid and name
#	(mode uid gid size name)
#
cat > af << 'fubar'
{ print $5 }
fubar
if test $? -ne 0 ; then fail; fi

#
# create a tar file
#
mkdir foo
if test $? -ne 0 ; then fail; fi
cp af sf foo
if test $? -ne 0 ; then fail; fi
cd foo
if test $? -ne 0 ; then fail; fi
tar cf ../test.in .
if test $? -ne 0 ; then fail; fi
cd ..
if test $? -ne 0 ; then fail; fi

#
# create the expected output
#
cat > test.ok << 'fubar'
prefix/
prefix/af
prefix/sf
fubar
if test $? -ne 0 ; then fail; fi

#
# put your test here
#
$here/bin/tardy -prefix prefix < test.in > test.out1
if test $? -ne 0 ; then fail; fi

$here/bin/tardy -list test.out1 /dev/null 2> test.out2
if test $? -ne 0 ; then fail; fi

awk -f af < test.out2 > test.out4
if test $? -ne 0 ; then fail; fi

diff test.ok test.out4
if test $? -ne 0 ; then fail; fi

#
# Only definite negatives are possible.
# The functionality exercised by this test appears to work,
# no other guarantees are made.
#
pass
