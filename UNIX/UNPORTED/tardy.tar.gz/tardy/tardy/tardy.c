/*
 *	tardy - a tar post-processor
 *	Copyright (C) 1993 Peter Miller.
 *	All rights reserved.
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * MANIFEST: functions to manipulate tar archives
 */

#include <errno.h>
#include <fcntl.h>
#include <grp.h>
#include <pwd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <error.h>
#include <tardy.h>

#define NOT_SET -1

#define TBLOCK 512
#define NAMSIZ 100

/*
 * The magic field is filled with this if uname and gname are valid.
 */
#define	TMAGIC		"ustar  "	/* 7 chars and a null */

/*
 * The linkflag defines the type of file
 */
#define	LF_OLDNORMAL	'\0'		/* Normal disk file, Unix compat */
#define	LF_NORMAL	'0'		/* Normal disk file */
#define	LF_LINK		'1'		/* Link to previously dumped file */
#define	LF_SYMLINK	'2'		/* Symbolic link */
#define	LF_CHR		'3'		/* Character special file */
#define	LF_BLK		'4'		/* Block special file */
#define	LF_DIR		'5'		/* Directory */
#define	LF_FIFO		'6'		/* FIFO special file */
#define	LF_CONTIG	'7'		/* Contiguous file */
/* Further link types may be defined later. */


typedef struct header_ty header_ty;
struct header_ty
{
	char	name[NAMSIZ];
	char	mode[8];
	char	uid[8];
	char	gid[8];
	char	size[12];
	char	mtime[12];
	char	chksum[8];
	char	linkflag;
	char	linkname[NAMSIZ];
	char	magic[8];
	char	uname[32];
	char	gname[32];
	char	devmajor[8];
	char	devminor[8];
};

static	int	uid = NOT_SET;
static	int	gid = NOT_SET;
static	char	*uname;
static	char	*gname;
static	char	*prefix;
static	int	mode_set = NOT_SET;
static	int	mode_clear = NOT_SET;
static	int	list;


static char *copy_string _((char *));

static char *
copy_string(s)
	char	*s;
{
	char	*cp;

	errno = ENOMEM;
	cp = malloc(strlen(s) + 1);
	if (!cp)
		nfatal("malloc");
	strcpy(cp, s);
	return cp;
}


void
tardy_user_name_by_string(s)
	char	*s;
{
	if (uname)
		fatal("duplicate -User_NAme option");
	uname = s;
}


void
tardy_user_name_by_number(n)
	long		n;
{
	struct passwd	*pw;

	if (uname)
		fatal("duplicate -User_NAme option");
	if (n < 0 || n >= (1L << 16))
		fatal("uid %ld out of range", n);
	pw = getpwuid(n);
	if (!pw)
		fatal("uid %ld unknown", n);
	uname = copy_string(pw->pw_name);
}


void
tardy_user_number_by_string(s)
	char		*s;
{
	struct passwd	*pw;

	if (uid != NOT_SET)
		fatal("duplicate -User_NUmber option");
	pw = getpwnam(s);
	if (!pw)
		fatal("user \"%s\" unknown", s);
	uid = pw->pw_uid;
}


void
tardy_user_number_by_number(n)
	long	n;
{
	if (n < 0 || n >= (1L << 16))
		fatal("user number %ld out of range", n);
	if (uid != NOT_SET)
		fatal("duplicate -User_NUmber option");
	uid = n;
}


void
tardy_group_name_by_string(s)
	char	*s;
{
	if (gname)
		fatal("duplicate -Group_NAme option");
	gname = s;
}


void
tardy_group_name_by_number(n)
	long		n;
{
	struct group	*gr;

	if (gname)
		fatal("duplicate -Group_NAme option");
	if (n < 0 || n >= (1L << 16))
		fatal("gid %ld out of range", n);
	gr = getgrgid(n);
	if (!gr)
		fatal("gid %ld unknown", n);
	gname = copy_string(gr->gr_name);
}


void
tardy_group_number_by_string(s)
	char		*s;
{
	struct group	*gr;

	if (gid != NOT_SET)
		fatal("duplicate -Group_NUmber option");
	gr = getgrnam(s);
	if (!gr)
		fatal("group \"%s\" unknown", s);
	gid = gr->gr_gid;
}


void
tardy_group_number_by_number(n)
	long		n;
{
	if (n < 0 || n >= (1L << 16))
		fatal("group number %d out of range", n);
	if (gid != NOT_SET)
		fatal("duplicate -Group_NUmber option");
	gid = n;
}


static int all_zero _((char *, long));

static int
all_zero(buf, len)
	char	*buf;
	long	len;
{
	while (len > 0)
	{
		if (*buf++)
			return 0;
		--len;
	}
	return 1;
}


static int checksum _((char *));

static int
checksum(block)
	char		*block;
{
	header_ty	*hp;
	unsigned char	*cp;
	unsigned char	*ep;
	int		sum;

	hp = (header_ty *)block;
	cp = (unsigned char *)block;
	ep = (unsigned char *)hp->chksum;
	sum = ((unsigned char)' ') * sizeof(hp->chksum);
	while (cp < ep)
		sum += *cp++;
	cp = (unsigned char *)(hp->chksum + sizeof(hp->chksum));
	ep = (unsigned char *)(block + TBLOCK);
	while (cp < ep)
		sum += *cp++;
	return sum;
}


static void to_octal _((char *, long, long));

static void
to_octal(buf, len, n)
	char	*buf;
	long	len;
	long	n;
{
	buf[--len] = 0;
	memset(buf, ' ', len);
	while (len > 0)
	{
		buf[--len] = '0' + (n & 7);
		n >>= 3;
		if (!n)
			break;
	}
}


static long octal _((char *, long));

static long
octal(buf, len)
	char	*buf;
	long	len;
{
	long	value;

	value = 0;
	while (len > 0 && *buf == ' ')
	{
		++buf;
		--len;
	}
	if (len <= 0)
		return -1;
	while (len > 0)
	{
		if (!*buf || *buf == ' ')
			break;
		if (*buf < '0' || *buf > '7')
			return -1;
		value = (value << 3) + (*buf++ & 7);
		--len;
	}
	return value;
}


static long strnlen _((char *, long));

static long
strnlen(s, n)
	char	*s;
	long	n;
{
	char	*ss = s;

	while (n > 0 && *s)
	{
		++s;
		--n;
	}
	return (s - ss);
}


static void apply_prefix _((char *, char *));

static void
apply_prefix(prefix, name)
	char	*prefix;
	char	*name;
{
	char	pname[NAMSIZ];
	long	len;
	long	len1;
	long	len2;
	char	*np;

	if (name[0] == '.' && name[1] == '/')
	{
		np = name + 2;
		len2 = strnlen(np, NAMSIZ - 2);
	}
	else
	{
		np = name;
		len2 = strnlen(np, NAMSIZ);
	}
	len1 = strlen(prefix);
	len = len1 + 1 + len2;
	if (len > NAMSIZ)
		fatal("prefix makes name too long");
	memcpy(pname, prefix, len1);
	pname[len1] = '/';
	memcpy(pname + len1 + 1, np, len2);
	if (len < NAMSIZ)
		memset(pname + len, 0, NAMSIZ - len);
	memcpy(name, pname, NAMSIZ);
}


void
tardy(ifn, ofn)
	char		*ifn;
	char		*ofn;
{
	long		skip;
	char		block[TBLOCK];
	header_ty	*hp = (header_ty *)block;
	int		ifd;
	int		ofd;

	if (ifn)
	{
		ifd = open(ifn, O_RDONLY, 0666);
		if (ifd < 0)
			nfatal("open \"%s\"", ifn);
	}
	else
	{
		ifd = 0;
		ifn = "(standard input)";
	}

	if (ofn)
	{
		ofd = open(ofn, O_WRONLY | O_CREAT | O_TRUNC, 0666);
		if (ofd < 0)
			nfatal("open \"%s\"", ofn);
	}
	else
	{
		ofd = 1;
		ofn = "(standard output)";
	}

	skip = 0;
	for (;;)
	{
		long	nbytes;

		/*
		 * read a block of input
		 */
		nbytes = read(ifd, block, TBLOCK);
		if (!nbytes)
			break;
		if (nbytes < 0)
			nfatal("read \"%s\"", ifn);
		if (nbytes != TBLOCK)
			fatal("short block (%d bytes expected, %d bytes read)", TBLOCK, nbytes);
		/*
		 * chew over header blocks
		 */
		if (skip == 0 && all_zero(block, TBLOCK))
			skip = (1L << 30);
		else if (skip == 0)
		{
			long	hmode;
			long	huid;
			long	hgid;
			long	hchksum;
			long	hsize;
			long	hmtime;
			long	cs2;

			hchksum = octal(hp->chksum, sizeof(hp->chksum));
			if (hchksum < 0)
				fatal("%s: corrupted checksum field", ifn);
			cs2 = checksum(block);
			if (hchksum != cs2)
				fatal("%s: checksum does not match (calculated 0%o, file has 0%o)", ifn, cs2, hchksum);
			hmode = octal(hp->mode, sizeof(hp->mode));
			if (hmode < 0)
				fatal("%s: corrupted mode field", ifn);
			huid = octal(hp->uid, sizeof(hp->uid));
			if (huid < 0)
				fatal("%s: corrupted uid field", ifn);
			hgid = octal(hp->gid, sizeof(hp->gid));
			if (hgid < 0)
				fatal("%s: corrupted gid field", ifn);
			hsize = octal(hp->size, sizeof(hp->size));
			if (hsize < 0)
				fatal("%s: corrupted size field", ifn);
			hmtime = octal(hp->mtime, sizeof(hp->mtime));
			if (hmtime < 0)
				fatal("%s: corrupted mtime field", ifn);

			/*
			 * perform the modifications requested
			 */
			if (mode_set != NOT_SET || mode_clear != NOT_SET)
			{
				if (mode_set == NOT_SET)
					mode_set = 0;
				if (mode_clear == NOT_SET)
					mode_clear = 0;
				if (hmode & 0111)
					hmode |= 0111;
				hmode |= mode_set;
				hmode &= ~mode_clear;
				to_octal(hp->mode, sizeof(hp->mode), hmode);
			}
			if (uid != NOT_SET)
				to_octal(hp->uid, sizeof(hp->uid), uid);
			if (gid != NOT_SET)
				to_octal(hp->gid, sizeof(hp->gid), gid);
			if (prefix)
			{
				apply_prefix(prefix, hp->name);
				if (hp->linkflag == LF_LINK)
					apply_prefix(prefix, hp->linkname);
			}

			if
			(
				(uname || gname)
			&&
				memcmp(hp->magic, TMAGIC, sizeof(hp->magic))
			)
			{
				memcpy(hp->magic, TMAGIC, sizeof(hp->magic));
				strcpy(hp->uname, "nobody");
				strcpy(hp->gname, "nogroup");
				to_octal(hp->devmajor, sizeof(hp->devmajor), 0L);
				to_octal(hp->devminor, sizeof(hp->devminor), 0L);
			}

			if (uname)
			{
				long	len;

				len = strnlen(uname, sizeof(hp->uname));
				memcpy(hp->uname, uname, len);
				if (len < sizeof(hp->uname))
					memset(hp->uname + len, 0, sizeof(hp->uname) - len);
			}
			if (gname)
			{
				long	len;

				len = strnlen(gname, sizeof(hp->gname));
				memcpy(hp->gname, gname, len);
				if (len < sizeof(hp->gname))
					memset(hp->gname + len, 0, sizeof(hp->gname) - len);
			}

			/*
			 * adjust the checksum
			 */
			to_octal
			(
				hp->chksum,
				sizeof(hp->chksum),
				checksum(block)
			);

			/*
			 * skip the file contents
			 */
			if
			(
				hp->linkflag == LF_OLDNORMAL
			||
				hp->linkflag == LF_NORMAL
			)
				skip = (hsize + TBLOCK - 1) / TBLOCK;
			else
				skip = 0;

			if (list)
			{
				fprintf
				(
					stderr,
					"%04lo %3ld %3ld %5ld %s\n",
					(hmode & 07777),
					huid,
					hgid,
					hsize,
					hp->name
				);
			}
		}
		else if (skip > 0)
			--skip;

		/*
		 * write the block to the output
		 */
		nbytes = write(ofd, block, TBLOCK);
		if (nbytes < 0)
			nfatal("write \"%s\"", ofn);
		if (nbytes == 0)
			fatal("write \"%s\": end of tape", ofn);
		if (nbytes != TBLOCK)
			fatal("write \"%s\": wierd failure", ofn);
	}

	close(ifd);
	close(ofd);
}


void
tardy_prefix(s)
	char	*s;
{
	if (prefix)
		fatal("duplicate -Prefix option");
	prefix = s;
}


void
tardy_mode_set(n)
	int	n;
{
	if (mode_set != NOT_SET)
		fatal("duplicate -Mode_Set option");
	mode_set = (n & 0777);
}


void
tardy_mode_clear(n)
	int	n;
{
	if (mode_clear != NOT_SET)
		fatal("duplicate -Mode_Clear option");
	mode_clear = (n & 07777);
}


void
tardy_list()
{
	if (list)
		fatal("duplicate -List option");
	list = 1;
}
