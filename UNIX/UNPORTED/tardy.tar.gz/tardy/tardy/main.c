/*
 *	tardy - a tar post-processor
 *	Copyright (C) 1993 Peter Miller.
 *	All rights reserved.
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * MANIFEST: operating system entry point
 */

#include <stdio.h>

#include <arglex.h>
#include <error.h>
#include <help.h>
#include <version.h>
#include <tardy.h>


enum
{
	arglex_token_user,
	arglex_token_user_name,
	arglex_token_user_number,
	arglex_token_group,
	arglex_token_group_name,
	arglex_token_group_number,
	arglex_token_prefix,
	arglex_token_mode_set,
	arglex_token_mode_clear,
	arglex_token_list
};

static arglex_table_ty argtab[] =
{
	{ "-User",		(arglex_token_ty)arglex_token_user,	    },
	{ "-User_NAme",		(arglex_token_ty)arglex_token_user_name,    },
	{ "-User_NUmber",	(arglex_token_ty)arglex_token_user_number,  },
	{ "-Group",		(arglex_token_ty)arglex_token_group,	    },
	{ "-Group_NAme",	(arglex_token_ty)arglex_token_group_name,   },
	{ "-Group_NUmber",	(arglex_token_ty)arglex_token_group_number, },
	{ "-Prefix",		(arglex_token_ty)arglex_token_prefix,	    },
	{ "-Mode_Set",		(arglex_token_ty)arglex_token_mode_set,	    },
	{ "-Mode_Clear",	(arglex_token_ty)arglex_token_mode_clear,   },
	{ "-List",		(arglex_token_ty)arglex_token_list,	    },
	{ 0, (arglex_token_ty)0, }, /* end marker */
};


static void usage _((void));

static void
usage()
{
	char	*progname;

	progname = arglex_progname_get();
	fprintf(stderr, "Usage: %s [ <option>... ][ <infile> [ <outfile> ]]\n", progname);
	fprintf(stderr, "       %s -Help\n", progname);
	fprintf(stderr, "       %s -VERSion\n", progname);
	exit(1);
}


static void main_help _((void));

static void
main_help()
{
	static char *text[] =
	{
"NAME",
"	%s - a tar post-processor",
"",
"SYNOPSIS",
"	%s [ <option>... ][ <infile> [ <outfile> ]]",
"	%s -Help",
"	%s -VERSion",
"",
"DESCRIPTION",
"	The %s program is used to manipulate tar(1) archive",
"	files.	This is	of most	use when preparing sources for",
"	Internet archive sites.",
"",
"	The GNU	tar format headers are understood.",
"",
"OPTIONS",
"	The following options are understood:",
"",
"	-Help",
"		Provide	some help with using the %s program.",
"",
"	-VERSion",
"		Print the version of the %s program being",
"		executed.",
"",
"	-User <arg>",
"		This option may	be used	to set both the	user name",
"		and user number	fields in the header of	every",
"		file in	the archive file.  The argument	may be",
"		either a string	or a number.  It is an error if	a",
"		corresponding entry cannot be found in the",
"		/etc/passwd file.",
"",
"	-User_NAme <string>",
"		This option is used to set the user name field in",
"		the header of every file in the	archive	file.",
"		The string may be any arbitrary	string,	it is not",
"		restricted to a	known user.",
"",
"	-User_NAme <number>",
"		This option is used to set the user name field in",
"		the header of every file in the	archive	file.",
"		The number is mapped to	a user name through the",
"		/etc/passwd file.  It is an error if a",
"		corresponding user cannot be found.",
"",
"	-User_NUmber <string>",
"		This option is used to set the user number field",
"		in the header of every file in the archive file.",
"		The string is mapped to	a user number through the",
"		/etc/passwd file.  It is an error if a",
"		corresponding user cannot be found.",
"",
"	-User_NUmber <number>",
"		This option is used to set the user number field",
"		in the header of every file in the archive file.",
"		The number may be any arbitrary	number,	it is not",
"		restricted to a	known user.",
"",
"	-Group <arg>",
"		This option may	be used	to set both the	group",
"		name and group number fields in	the header of",
"		every file in the archive file.	 The argument may",
"		be either a string or a	number.	 It is an error",
"		if a corresponding entry cannot	be found in the",
"		/etc/group file.",
"",
"	-Group_NAme <string>",
"		This option is used to set the group name field",
"		in the header of every file in the archive file.",
"		The string may be any arbitrary	string,	it is not",
"		restricted to a	known group.",
"",
"	-Group_NAme <number>",
"		This option is used to set the group name field",
"		in the header of every file in the archive file.",
"		The number is mapped to	a group	name through the",
"		/etc/group file.  It is	an error if a",
"		corresponding group cannot be found.",
"",
"	-Group_NUmber <string>",
"		This option is used to set the group number field",
"		in the header of every file in the archive file.",
"		The string is mapped to	a group	number through",
"		the /etc/group file.  It is an error if	a",
"		corresponding group cannot be found.",
"",
"	-Group_NUmber <number>",
"		This option is used to set the group number field",
"		in the header of every file in the archive file.",
"		The number may be any arbitrary	number,	it is not",
"		restricted to a	known group.",
"",
"	-Prefix	<string>",
"		This option is used to add a prefix directory",
"		name to	the name of every file in the archive",
"		file.",
"",
"	-Mode_Set <bits>",
"		This option may	be used	to set the mode	of each",
"		file in	the archive file.  The <bits> specified are",
"		set in the mode.  You should use an octal number",
"		with a leading zero as the argument; if	you omit",
"		the leading zero it will be interpreted	as",
"		decimal.",
"",
"	-Mode_Clear <bits>",
"		This option may	be used	to set the mode	of each",
"		file in	the archive file.  The <bits> specified are",
"		cleared	in the mode.  You should use an	octal",
"		number with a leading zero as the argument; if",
"		you omit the leading zero it will be interpreted",
"		as decimal.  The -Mode_Set option is applied",
"		first, the -Mode_Clear option is applied specond;",
"		if neither is specified	the mode of each file is",
"		unaltered.",
"",
"	All options may be abbreviated; the abbreviation is",
"	documented as the upper case letters, all lower case",
"	letters and underscores (_) are optional.  You must use",
"	consecutive sequences of optional letters.",
"",
"	All options are case insensitive, you may type them in",
"	upper case or lower case or a combination of both, case",
"	is not important.",
"",
"	For example: the arguments \"-prefix, \"-PREF\" and \"-p\"",
"	are all interpreted to mean the -Prefix option.  The",
"	argument \"-pfx\" will not be understood, because",
"	consecutive optional characters were not supplied.",
"",
"	Options and other command line arguments may be mixed",
"	arbitrarily on the command line.",
"",
"	The GNU long option names are understood.  Since all",
"	option names for %s are long, this means ignoring the",
"	extra leading '-'.  The \"--option=value\" convention is",
"	also understood.",
"",
"EXIT STATUS",
"	The %s program will exit with a status of 1 on any",
"	error.	The %s program will only exit with a	status of",
"	0 if there are no errors.",
"",
"COPYRIGHT",
"	%C",
"",
"AUTHOR",
"	%A",
	};

	help(text, SIZEOF(text), usage);
}


int main _((int, char **));

int
main(argc, argv)
	int	argc;
	char	**argv;
{
	char	*infile;
	char	*outfile;

	arglex_init(argc, argv, argtab);
	switch (arglex())
	{
	case arglex_token_help:
		main_help();
		exit(0);
	
	case arglex_token_version:
		version();
		exit(0);

	default:
		break;
	}
	infile = 0;
	outfile = 0;
	while (arglex_token != arglex_token_eoln)
	{
		switch (arglex_token)
		{
		default:
			error
			(
				"misplaced \"%s\" command line argument",
				arglex_value.alv_string
			);
			usage();

		case arglex_token_string:
			if (!infile)
				infile = arglex_value.alv_string;
			else if (!outfile)
				outfile = arglex_value.alv_string;
			else
			{
				error("too many file names specified");
				usage();
			}
			break;

		case arglex_token_stdio:
			if (!infile)
				infile = "";
			else if (!outfile)
				outfile = "";
			else
			{
				error("too many file names specified");
				usage();
			}
			break;

		case arglex_token_user:
			switch (arglex())
			{
			default:
				error
				(
			"the -User option requires a string or numeric argument"
				);
				usage();

			case arglex_token_string:
				tardy_user_name_by_string(arglex_value.alv_string);
				tardy_user_number_by_string(arglex_value.alv_string);
				break;

			case arglex_token_number:
				tardy_user_name_by_number(arglex_value.alv_number);
				tardy_user_number_by_number(arglex_value.alv_number);
				break;
			}
			break;

		case arglex_token_user_name:
			switch (arglex())
			{
			default:
				error
				(
		   "the -User_NAme option requires a string or numeric argument"
				);
				usage();

			case arglex_token_string:
				tardy_user_name_by_string(arglex_value.alv_string);
				break;

			case arglex_token_number:
				tardy_user_name_by_number(arglex_value.alv_number);
				break;
			}
			break;

		case arglex_token_user_number:
			switch (arglex())
			{
			default:
				error
				(
		 "the -User_NUmber option requires a string or numeric argument"
				);
				usage();

			case arglex_token_string:
				tardy_user_number_by_string(arglex_value.alv_string);
				break;

			case arglex_token_number:
				tardy_user_number_by_number(arglex_value.alv_number);
				break;
			}
			break;

		case arglex_token_group:
			switch (arglex())
			{
			default:
				error
				(
		       "the -Group option requires a string or numeric argument"
				);
				usage();

			case arglex_token_string:
				tardy_group_name_by_string(arglex_value.alv_string);
				tardy_group_number_by_string(arglex_value.alv_string);
				break;

			case arglex_token_number:
				tardy_group_name_by_number(arglex_value.alv_number);
				tardy_group_number_by_number(arglex_value.alv_number);
				break;
			}
			break;

		case arglex_token_group_name:
			switch (arglex())
			{
			default:
				error
				(
		  "the -Group_NAme option requires a string or numeric argument"
				);
				usage();

			case arglex_token_string:
				tardy_group_name_by_string(arglex_value.alv_string);
				break;

			case arglex_token_number:
				tardy_group_name_by_number(arglex_value.alv_number);
				break;
			}
			break;

		case arglex_token_group_number:
			switch (arglex())
			{
			default:
				error
				(
		"the -Group_NUmber option requires a string or numeric argument"
				);
				usage();

			case arglex_token_string:
				tardy_group_number_by_string(arglex_value.alv_string);
				break;

			case arglex_token_number:
				tardy_group_number_by_number(arglex_value.alv_number);
				break;
			}
			break;

		case arglex_token_prefix:
			if (arglex() != arglex_token_string)
			{
				error
				(
				 "the -Prefix option requires a string argument"
				);
				usage();
			}
			tardy_prefix(arglex_value.alv_string);
			break;

		case arglex_token_mode_set:
			if (arglex() != arglex_token_number)
			{
				error
				(
		   "the -Mode_Set option must be followed by a numeric argument"
				);
				usage();
			}
			tardy_mode_set(arglex_value.alv_number);
			break;

		case arglex_token_mode_clear:
			if (arglex() != arglex_token_number)
			{
				error
				(
		 "the -Mode_Clear option must be followed by a numeric argument"
				);
				usage();
			}
			tardy_mode_clear(arglex_value.alv_number);
			break;

		case arglex_token_list:
			tardy_list();
			break;
		}
		arglex();
	}
	if (outfile && !*outfile)
		outfile = 0;
	if (infile && !*infile)
		infile = 0;
	tardy(infile, outfile);
	exit(0);
	return 0;
}
