/* @(#)resources.h	1.3 (UKC) 30/5/92 */

/* 
 * Copyright 1991 Richard Hesketh / rlh2@ukc.ac.uk
 *                Computing Lab. University of Kent at Canterbury, UK
 *
 * Permission to use, copy, modify and distribute this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the names of Richard Hesketh and The University of
 * Kent at Canterbury not be used in advertising or publicity pertaining to
 * distribution of the software without specific, written prior permission.
 * Richard Hesketh and The University of Kent at Canterbury make no
 * representations about the suitability of this software for any purpose.
 * It is provided "as is" without express or implied warranty.
 *
 * Richard Hesketh AND THE UNIVERSITY OF KENT AT CANTERBURY DISCLAIMS ALL
 * WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL Richard Hesketh OR THE
 * UNIVERSITY OF KENT AT CANTERBURY BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
 * OF THIS SOFTWARE.
 *
 * Author:  Richard Hesketh / rlh2@ukc.ac.uk, 
 *                Computing Lab. University of Kent at Canterbury, UK
 */

#ifndef PROG_NAME
#define PROG_NAME "gspreview"
#endif

#ifdef QMS_CLIPPING

#define QMS_CLIP_PATH "/initclip{ newpath 13.44 94.32 moveto 13.44 791.04 \
  lineto 581.52 791.04 lineto 581.52 94.32 lineto closepath clip } bind def\n\
  initclip newpath clippath stroke\n"

#define QMS_PER_PAGE "gsave initmatrix newpath clippath stroke grestore\n"
#endif /* QMS_CLIPPING */

#define PAGE_SETUP "initclip clippath pathbbox\n\
		    /ury exch def /urx exch def /lly exch def /llx exch def\n\
		    /pwidth urx llx sub def\n\
		    /pheight ury lly sub def\n"

#define PAGE_PORTRAIT 0
#define PAGE_LANDSCAPE 90
#define PAGE_UPSIDEDOWN 180
#define PAGE_SEASCAPE 270 

#define DEFAULT_SIZES "Letter=216x279 A5=148x210 A4=210x297 A3=297x420"

#define DEFAULT_PAGE "A4"

struct page_size_entry {
	String	size_name;
	short	width;
	short	height;
	struct page_size_entry *next;
};

struct app_resources {
	/* resources settable by command line and app-defaults */
	Boolean picasso;	/* clip output to QMS colour printer size */
	Boolean use_stdin;	/* reading input from stdin */
	Boolean ignore_comments;/* for files whose comments are wrong */
	int	initial_page;	/* which page to display at start up */
	int	resolution;	/* dpi for X and Y axis of page */
	int	page_layout;	/* portrait, landscape, upsideDown or seascape*/
	String  page_sizes;	/* list of page sizes in mm (e.g."A4=210x297")*/
	String  page_size_name;	/* name of default page size (e.g. "Letter") */

	/* program set resources */
	Widget	current_scaling; /* widget in scaleDialogBox currently set */
	Widget	current_layout;  /* widget in optionsDialogBox currently set */
	struct page_size_entry *page_size_list;  /* list of available sizes */
	short	page_size_index; /* current index into page size list */
	short   page_width;	 /* width in mm of output page */
	short	page_height;	 /* height in mm of output page */
	Pixmap	background_pixmap;	/* pixmap in which to draw output */
};

extern struct app_resources prog_resources;
