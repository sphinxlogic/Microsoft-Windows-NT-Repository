#ifndef lint
static char sccsid[] = "@(#)file.c	1.8 (UKC) 9/7/92";
#endif /* !lint */

/* 
 * Copyright 1992 Richard Hesketh / rlh2@ukc.ac.uk
 *                Computing Lab. University of Kent at Canterbury, UK
 *
 * Permission to use, copy, modify and distribute this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the names of Richard Hesketh and The University of
 * Kent at Canterbury not be used in advertising or publicity pertaining to
 * distribution of the software without specific, written prior permission.
 * Richard Hesketh and The University of Kent at Canterbury make no
 * representations about the suitability of this software for any purpose.
 * It is provided "as is" without express or implied warranty.
 *
 * Richard Hesketh AND THE UNIVERSITY OF KENT AT CANTERBURY DISCLAIMS ALL
 * WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL Richard Hesketh OR THE
 * UNIVERSITY OF KENT AT CANTERBURY BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
 * OF THIS SOFTWARE.
 *
 * Author:  Richard Hesketh / rlh2@ukc.ac.uk, 
 *                Computing Lab. University of Kent at Canterbury, UK
 */

/* file selection routines for loadFile popup dialog box */

#include <X11/Xos.h>
#include <X11/cursorfont.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Xukc/ScrollList.h>
#include <X11/Xukc/text.h>

#include <stdio.h>
#include <pwd.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <errno.h>

extern char *reason();

extern Widget WI_file_list, WI_filename_entry, WI_file_dialog_layout;
extern Widget WI_file_error_label;

#ifndef PROG_NAME
#	define PROG_NAME "gspreview"
#endif /* PROG_NAME */

#define SYMBOLIC_LINK 1
#define DIRECTORY_FILE 2
#define REGULAR_FILE 4

struct file_entry {
	char *filename;
	char type;
	char *displayed_name;
	struct file_entry *next;
};

static struct file_entry *files = NULL;
static char pathname[MAXPATHLEN + 1];


/* for quick sort */
static int
compare_names(a, b)
String a, b;
{
	char *dot = "./";
	char *dotdot = "../";

	if (!strcmp(*(String *)a, dotdot))
		return (-1);
	if (!strcmp(*(String *)b, dotdot))
		return (1);
	if (!strcmp(*(String *)a, dot))
		return (-1);
	if (!strcmp(*(String *)b, dot))
		return (1);
        return (strcmp(*(String *)a, *(String *)b));
}


static void
apply_new_translations(lw)
Widget lw;
{
	static XtTranslations trans = NULL;

	if (trans == NULL)
		trans = XtParseTranslationTable("<BtnDown>: Set() Notify()\n\
<BtnDown>(2+): load_file()");

	XtVaGetValues(lw, XtNlistWidget, &lw, NULL);
	XtVaSetValues(lw, XtNtranslations, trans, NULL);
}


static void
dispose_of_file_list(fl)
struct file_entry *fl;
{
	while (fl) {
		struct file_entry *next = fl->next;

		XtFree(fl->filename);
		XtFree(fl->displayed_name);
		XtFree(fl);
		fl = next;
	}
}


static struct file_entry *
scan_directory(dir, str_list, file_count)
String dir;
String **str_list;
int *file_count;
{
	DIR *dd;
	struct dirent *dir_entry;
	struct stat stbuf;
	struct file_entry new_entry;
	struct file_entry *file_list = NULL, *current = NULL;
	char statpath[MAXPATHLEN + 1];
	char *eop;

	*file_count = 0;
	*str_list = NULL;

	if (dir == NULL || *dir == '\0')
		return (struct file_entry *)NULL;

	dd = opendir(dir);

	if (dd == NULL) {
		/* some error happened .. try to recover */

		return (struct file_entry *)NULL;
	}

	(void)strcpy(statpath, dir);
	eop = statpath + strlen(statpath);

	dir_entry = readdir(dd);
	for (; dir_entry != NULL; dir_entry = readdir(dd)) {

		new_entry.type = 0;
		new_entry.filename = NULL;
		new_entry.displayed_name = NULL;
		new_entry.next = NULL;

		*eop = '\0';
		(void)strcat(eop, dir_entry->d_name);

		if (lstat(statpath, &stbuf) < 0) {
			switch (errno) {
			case ENOENT:
				continue;
				break;
			}
			continue;
		}
		if (S_ISLNK(stbuf.st_mode)) {
			new_entry.type |= SYMBOLIC_LINK;

			if (stat(statpath, &stbuf) < 0) {
				switch (errno) {
				case ENOENT:
					continue;
					break;
				}
				continue;
			}
		}
		if (S_ISDIR(stbuf.st_mode) || S_ISREG(stbuf.st_mode)) {
			int len;

			new_entry.type |= S_ISDIR(stbuf.st_mode)
					? DIRECTORY_FILE : REGULAR_FILE;
			new_entry.filename = XtNewString(dir_entry->d_name);

			len = strlen(new_entry.filename) + 1;
			if (new_entry.type & SYMBOLIC_LINK)
				len++;
			if (new_entry.type & DIRECTORY_FILE)
				len++;
			new_entry.displayed_name = XtMalloc(len);

			(void)strcpy(new_entry.displayed_name,
							new_entry.filename);
			if (new_entry.type & SYMBOLIC_LINK)
				(void)strcat(new_entry.displayed_name, "@");
			if (new_entry.type & DIRECTORY_FILE)
				(void)strcat(new_entry.displayed_name, "/");

			if (file_list == NULL)
				current = file_list = (struct file_entry *)
						XtMalloc(
						   sizeof(struct file_entry));
			else {
				current->next = (struct file_entry *)
						XtMalloc(
						   sizeof(struct file_entry));
				current = current->next;
			}

			*current = new_entry;
			(*file_count)++;
		}
	}
	closedir(dd);

	if (*file_count) {
		int idx;
		current = file_list;

		/* produce a list of strings to display in the scrolled
		 * list widget.
		 */
		*str_list = (String *)XtMalloc(sizeof(String) * (*file_count));
		for (idx = 0; idx < *file_count; current = current->next, idx++)
			(*str_list)[idx] = current->displayed_name;
	}

	return (file_list);
}


static void
get_working_directory()
{
#if defined(SVR4) || defined(SYSV)
	extern char *getcwd();

	if (getcwd(pathname, MAXPATHLEN + 1) == NULL) {
#else
	if (getwd(pathname) == NULL) {
#endif
		fprintf(stderr, "%s: Error getting current directory (%s)\n",
			PROG_NAME, pathname);
		exit(1);
	}
	(void)strcat(pathname, "/");
}


static void
load_file_busy(is_busy)
Boolean is_busy;
{
	static Cursor busy_cursor = NULL;
	static Cursor old_text_cursor = NULL;
	Widget lw;

	if (busy_cursor == NULL)
		busy_cursor = XCreateFontCursor(XtDisplay(WI_file_list),
						XC_watch);

	if (!XtIsRealized(WI_file_list))
		return;

	XtVaGetValues(WI_file_list, XtNlistWidget, &lw, NULL);

	if (is_busy) {
		XtVaGetValues(WI_filename_entry, XtNcursor,
				&old_text_cursor, NULL);
		XDefineCursor(XtDisplay(WI_file_list),
				XtWindow(WI_filename_entry), busy_cursor);
		XDefineCursor(XtDisplay(WI_file_list),
				XtWindow(WI_file_dialog_layout), busy_cursor);
		if (lw != NULL && XtIsRealized(lw))
			XDefineCursor(XtDisplay(WI_file_list), XtWindow(lw),
				busy_cursor);
	} else {
		XDefineCursor(XtDisplay(WI_file_list),
				XtWindow(WI_file_dialog_layout), None);
		XDefineCursor(XtDisplay(WI_file_list),
				XtWindow(WI_filename_entry), old_text_cursor);
		if (lw != NULL && XtIsRealized(lw))
			XDefineCursor(XtDisplay(WI_file_list), XtWindow(lw),
				None);
	}
	XFlush(XtDisplay(WI_file_list));
}


/************************* Module Exported Routines *********************/


Boolean
GotoDirectory(path)
String path;
{
	static String old_path = NULL;

	if (old_path == NULL) {
		/* initialize to current working directory */
		get_working_directory();
		old_path = XtNewString(pathname);
	}

	if (path == NULL) {
		if (old_path == NULL)
			return FALSE;
		else
			path = old_path;
	}
	errno = 0;

	if (chdir(path) < 0) {
		char tmp[500];

		(void)sprintf(tmp, "Cannot open (%s)", reason());
		XtVaSetValues(WI_file_error_label, XtNlabel, tmp, NULL);
		XBell(XtDisplay(WI_file_error_label), 0);
		return FALSE;
	}
	if (old_path != path) {
		XtFree(old_path);
		old_path = XtNewString(path);
	}
	return TRUE;
}


String
ExpandFilename(filename)
String filename;
{
	static String expanded_file = NULL;
	String str;
	struct passwd *pwd;
	char found_slash = 0;

	if (expanded_file != NULL) {
		XtFree(expanded_file);
		expanded_file = NULL;
	}

	if (filename == NULL)
		return NULL;
		
	if (*filename != '~') {
		if (*filename == '/')
			return (filename);
		get_working_directory();
		expanded_file = XtMalloc(strlen(pathname) + strlen(filename) + 2);
		(void)sprintf(expanded_file, "%s%s", pathname, filename);
		return (expanded_file);
	}

	str = filename;
	while (*str != '\0' && *str != '/') str++;
	if (*str) {
		found_slash = 1;
		*str = '\0';
	}

	if (*(filename + 1)) {
		pwd = getpwnam(filename + 1);
		if (pwd == NULL) {
			char tmp[500];

			(void)sprintf(tmp, "No such user (%s)",
					filename + 1);
			XtVaSetValues(WI_file_error_label, XtNlabel,
					tmp, NULL);
			XBell(XtDisplay(WI_file_error_label), 0);
			if (found_slash)
				*str = '/';
			return (filename);
		}
	} else
		pwd = getpwuid(getuid());

	if (found_slash)
		*str = '/';

	if (pwd == NULL) {
		if (found_slash)
			*str = '/';
		return (filename);
	}
	expanded_file = XtMalloc(strlen(pwd->pw_dir) + strlen(str) + 1);
	(void)sprintf(expanded_file, "%s%s", pwd->pw_dir, str);
	return (expanded_file);
}


void
ResetFileList(filename)
String filename;
{
	int count;
	String *str_list;
	struct file_entry *new_files = NULL;
	char *str;

	str = ExpandFilename(filename);
	(void)strcpy(pathname, str);

	str = pathname + strlen(pathname);
	while(str >= pathname && *str != '/') str--;
	if (str >= pathname) {
		*(++str) = '\0';
		if (!GotoDirectory(pathname))
			return;
	}

	load_file_busy(TRUE);
	get_working_directory();

	if (new_files = scan_directory(pathname, &str_list, &count)) {
		dispose_of_file_list(files);
		files = new_files;
		qsort(str_list, count, sizeof(String), compare_names);
		XukcScrListChange(WI_file_list, str_list, count);
		XukcScrListSelectItem(WI_file_list, 1, FALSE, TRUE);
		apply_new_translations(WI_file_list);
	}
	load_file_busy(FALSE);
}


void
UpdateFileList(dir)
String dir;
{
	int count;
	String *str_list;
	struct file_entry *new_files = NULL;
	char new_path[MAXPATHLEN + 1];

	load_file_busy(TRUE);
	get_working_directory();

	(void)strcpy(new_path, pathname);

	if (dir != NULL && strcmp(dir, ".")) {
		if (!strcmp(dir, "..")) {
			char *eos = new_path + strlen(new_path) - 1;
			while (eos > new_path && *(eos - 1) != '/') eos--;
			*eos = '\0';
		} else
			(void)sprintf(new_path, "%s%s/", pathname, dir);
	}

	if (new_files = scan_directory(new_path, &str_list, &count)) {
		(void)strcpy(pathname, new_path);
		if (GotoDirectory(pathname) < 0) {
			load_file_busy(FALSE);
			return;
		}
		dispose_of_file_list(files);
		files = new_files;
		qsort(str_list, count, sizeof(String), compare_names);
		XukcScrListChange(WI_file_list, str_list, count);
		XukcScrListSelectItem(WI_file_list, 1, FALSE, TRUE);
		apply_new_translations(WI_file_list);
		XukcNewTextWidgetString(WI_filename_entry, pathname);
	} else {
		char tmp[500];

		(void)sprintf(tmp, "Cannot open (%s)", reason());
		XtVaSetValues(WI_file_error_label, XtNlabel, tmp, NULL);
		XBell(XtDisplay(WI_file_error_label), 0);
	}
	load_file_busy(FALSE);
}


void
SelectFileCB(w, client_data, call_data)
Widget w;
XtPointer client_data, call_data;
{
	struct file_entry *chosen;
	int count;
	XawListReturnStruct *picked_string = (XawListReturnStruct *)call_data;
	char *eos;

	get_working_directory();

	chosen = files;
	while (chosen != NULL &&
	       picked_string->string != chosen->displayed_name)
		chosen = chosen->next;

	if (chosen == NULL)
		return; /* should never get here */

	eos = pathname + strlen(pathname) - 1;
	while (eos > pathname && *eos != '/') eos--;
	*(++eos) = '\0';

	if (chosen->type & DIRECTORY_FILE) {
		UpdateFileList(chosen->filename);
	} else {
		(void)strcat(pathname, chosen->filename);
		XukcNewTextWidgetString(WI_filename_entry, pathname);
	}
}


void
FileKeyPressACT(w, event, params, num_params)
Widget w;
XEvent *event;
String *params;
Cardinal *num_params;
{
	/* called whenever a user types something into the filename entry
	 * Widget.  We check to see if a directory is being specified and
	 * second-guess the user and put up the directories entries in
	 * the scrolling list.
	 */
	String text = XukcGetTextWidgetString(w);
	String eop, str;

	if (text == NULL || !*text)
		return;

	eop = text + strlen(text);
	while (eop > text && *eop != '/') eop--;

	str = XtMalloc(eop - text + 2);
	(void)strncpy(str, text, eop - text + 1);
	str[eop - text + 1] = '\0';
	if (strcmp(str, pathname))
		ResetFileList(str);
	XtFree(str);
}
