#ifndef lint
/* From: "$Xukc: page.c,v 1.14 91/07/10 13:59:48 rlh2 Exp $"; */
static char sccsid[] = "@(#)page.c	1.5 (UKC) 31/5/92";
#endif /* !lint */

/* 
 * Copyright 1991 Richard Hesketh / rlh2@ukc.ac.uk
 *                Computing Lab. University of Kent at Canterbury, UK
 *
 * Permission to use, copy, modify and distribute this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the names of Richard Hesketh and The University of
 * Kent at Canterbury not be used in advertising or publicity pertaining to
 * distribution of the software without specific, written prior permission.
 * Richard Hesketh and The University of Kent at Canterbury make no
 * representations about the suitability of this software for any purpose.
 * It is provided "as is" without express or implied warranty.
 *
 * Richard Hesketh AND THE UNIVERSITY OF KENT AT CANTERBURY DISCLAIMS ALL
 * WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL Richard Hesketh OR THE
 * UNIVERSITY OF KENT AT CANTERBURY BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
 * OF THIS SOFTWARE.
 *
 * Author:  Richard Hesketh / rlh2@ukc.ac.uk, 
 *                Computing Lab. University of Kent at Canterbury, UK
 */

#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Xukc/Label.h>
#include <X11/Xukc/memory.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <ctype.h>
#include "resources.h"

#define COMMENT_IS(s) (strcmp(comment, s) == 0)
#define PUSHBACK(c) (ungetc(fd, c), file_count--)
#define NEWLINE '\n'
#define RETURN '\l'
#define COMMENT '%'
#define NEXT_CHARACTER (ch = getc(fd), file_count++)

#define TRUE 1
#define FALSE 0

#define TIMEOUT 10 /* milliseconds */
#define TIMEOUT_COUNT BUFSIZ /* characters */

#define COMMENT_SIZE 15

static long epsf = 0, mark_last_trailer = 0, mark_end_prolog = 0;
static long comment_start = 0, file_count = 0, page_num = 0;
static char start_of_line = TRUE;
static char comment[COMMENT_SIZE];
static int ch, max_pages = -1, next_page_num = -1;
static int current_page = 1;
static Widget dpy_w = NULL;
static FILE *file = NULL, *search_file = NULL;
static String filename = NULL;
static String current_page_file = NULL, next_page_file = NULL;
static Cardinal page_offset_list = 0;
static XtIntervalId timeout_id = 0;
static XtAppContext app_context;
static Boolean next_page_waiting = FALSE, awaiting_show_page = FALSE;
static Boolean show_page_found = TRUE, first_page_shown = FALSE;
static Boolean ignore_first_ready = TRUE;
static char command[250];

String zcat_file = NULL;

extern Widget WI_page_label;

void SetNumPages();
void ShowPage();
void FoundShowPage();
void FoundReady();
void ResetGhostscript();
void InitializePageFiles();

extern void BusyProcessing();
extern void KillGhostscript();
extern void ClearOutput();
extern void ResetOutputHandling();
extern void CloseStdin();

/* page control routines */

static void
page_scanning_indicator(running)
Boolean running;
{
	/* If the page scanner is running then we display the page
	 * number label in reverse video.  We unhighlight it when
	 * finished scanning.
	 */
	static Pixel fg, bg;
	static Boolean initialized = FALSE;

	if (!initialized) {
		XtVaGetValues(WI_page_label, XtNforeground, &fg,
						XtNbackground, &bg, NULL);
		initialized = TRUE;
	}

	if (running)
		XtVaSetValues(WI_page_label, XtNforeground, bg,
						XtNbackground, fg, NULL);
	else
		XtVaSetValues(WI_page_label, XtNforeground, fg,
						XtNbackground, bg, NULL);
}


static void
reset_file_scanning(fp)
FILE *fp;
{
	epsf = 0;
	mark_last_trailer = 0;
	mark_end_prolog = 0;
	comment_start = 0;
	file_count = 0;
	page_num = 0;
	start_of_line = TRUE;
	max_pages = -1;
	next_page_num = -1;
	next_page_waiting = FALSE;
	awaiting_show_page = FALSE;
	show_page_found = TRUE;
	first_page_shown = FALSE;
	ignore_first_ready = TRUE;

	XukcDestroyList(&page_offset_list, FALSE);
	page_offset_list = 0;
	SetNumPages(-1, -1);
	ClearOutput();
	rewind(fp);
}


/* Copy a section of the input file to a temporary file then tell Ghostscript
 * to read it in.  Individual pages are read in like this.
 */
static void
dump_file(fd, page, from, to)
FILE *fd;
int page;
long from, to;
{
	FILE *next_page;
	char buffer[BUFSIZ];
	long bytes_left, num_blocks, i;

	if ((next_page = fopen(next_page_file, "w")) == NULL) {
		fprintf(stderr, "cannot open temporary page file in /tmp\n");
		exit(2);
	}

	if (fseek(fd, from, 0) < 0) {
		fprintf(stderr, "internal error in dump_file(): lseek() failed\n");
		exit(3);
	}

#ifdef QMS_CLIPPING
	if (prog_resources.picasso)
		fprintf(next_page, "%s", page ? QMS_PER_PAGE : QMS_CLIP_PATH);
#endif /* QMS_CLIPPING */

	num_blocks = (to - from) / BUFSIZ;
	for (i = num_blocks; i > 0; i--) {
		if (!fread(buffer, 1, BUFSIZ, fd)) {
			fprintf(stderr, "error reading file\n");
			exit(4);
		}
		if (!fwrite(buffer, 1, BUFSIZ, next_page)) {
			fprintf(stderr, "error writing file\n");
			exit(5);
		}
	}
	if ((bytes_left = (to - from) - (num_blocks * BUFSIZ)) > 0) {
		if (!fread(buffer, 1, bytes_left, fd)) {
			fprintf(stderr, "error reading file\n");
			exit(4);
		}
		if (!fwrite(buffer, 1, bytes_left, next_page)) {
			fprintf(stderr, "error writing file\n");
			exit(5);
		}
	}

	if (fclose(next_page)) {
		fprintf(stderr, "error closing file\n");
		exit(6);
	}
}


int
get_number(fd)
FILE *fd;
{
	int i = 0;

	while (isspace(ch))
		NEXT_CHARACTER;

	while (isdigit(ch)) {
		i = i * 10 + ch - '0';
		NEXT_CHARACTER;
	}

	return (i);
}


void
mark_page(file_pos, page)
long file_pos;
int page;
{
	if (!page && !page_offset_list)
		return;

	(void)XukcAddObjectToList(&page_offset_list,
					(XtPointer)file_pos, FALSE);
	if (!first_page_shown) {
		if (page == 1) {
			/* process the prolog */
			dump_file(file, 0, 0l, file_pos);
			next_page_waiting = TRUE;
			awaiting_show_page = FALSE;
			FoundShowPage();
			current_page = 1;
			SendCommandToGhostscript(command);
			next_page_waiting = FALSE;
		} else if (page == prog_resources.initial_page + 1) {
			/* show the first page asked for by the user. */
			long page_start = (long)XukcGetObjectOnList(
						page_offset_list,
						prog_resources.initial_page);
			dump_file(file, 1, page_start, file_pos);
			if (max_pages < 1)
				max_pages = 1;
			next_page_waiting = TRUE;
			awaiting_show_page = FALSE;
			FoundShowPage();
			next_page_num = prog_resources.initial_page;
			first_page_shown = TRUE;
			current_page = prog_resources.initial_page;
		} else if (page == 0) {
			/* either there is only one page in this file
			 * or the user asked for a non-existant page.
			 */
			if (prog_resources.initial_page != 1)
				/* non-existant page */
				XBell(XtDisplay(WI_page_label), 0);

			dump_file(file, 1, (long)XukcGetObjectOnList(
				page_offset_list, 1),
				(long)XukcGetObjectOnList(page_offset_list, 2));
			if (max_pages < 1)
				max_pages = 1;
			next_page_waiting = TRUE;
			awaiting_show_page = FALSE;
			FoundShowPage();
			next_page_num = 1;
			first_page_shown = TRUE;
			current_page = 1;
		}
	}
	if (page > max_pages)
		SetNumPages(next_page_num, page);
}


check_comment(fd)
FILE *fd;
{
	int i = 0;

	comment_start = file_count;
	while (NEXT_CHARACTER != EOF && !isspace(ch) && i < COMMENT_SIZE)
		comment[i++] = ch;
	comment[i] = '\0';
	if (COMMENT_IS("%EndProlog")||COMMENT_IS("%EndSetup"))
		mark_end_prolog = comment_start;
#if 0
	else if (COMMENT_IS("%Pages:"))
		SetNumPages(next_page_num, get_number(fd));
#endif
	else if (COMMENT_IS("%EndDocument"))
		--epsf;
	else if (COMMENT_IS("%Trailer") && !epsf) {
		mark_last_trailer = comment_start;
		mark_page(comment_start, 0);
	} else if (COMMENT_IS("%Page:") && !epsf)
		mark_page(comment_start, ++page_num);
	else if (COMMENT_IS("%BeginDocument:"))
		epsf++;
}


static void
finished_scan()
{
	page_scanning_indicator(FALSE);

	if (!page_offset_list) {
		/* its an uncommented PostScript file so just
		 * move through it one page at a time.
		 */
		BusyProcessing(TRUE);
#ifdef QMS_CLIPPING
		if (prog_resources.picasso) {
			if (fseek(file, 0l, 2) < 0) {
				fprintf(stderr, "internal error in finished_scan(): lseek() failed\n");
				exit(3);
			}
			dump_file(file, 0, 0l, ftell(file));
			(void)sprintf(command, "(%s)run\n", next_page_file);
		} else
			(void)sprintf(command, "(%s)run\n", filename);
#else
		(void)sprintf(command, "(%s)run\n", filename);
#endif /* QMS_CLIPPING */
		SendCommandToGhostscript(command);
		SetNumPages(-1, -1);
		next_page_num = 1;
	}
}


static void
scan_for_pages(client_data, id)
XtPointer client_data;
XtIntervalId *id;
{
	FILE *fd = (FILE *)client_data;
	int j = TIMEOUT_COUNT;

	
	/* look for a comment on the first line of the file (%!PS- etc) */
	NEXT_CHARACTER;
	if (ch == COMMENT)
		check_comment(fd);

	/* now check each line for a comment and process any found */
	do {
		if ((ch != NEWLINE) && (ch != RETURN)) {
			NEXT_CHARACTER;
			continue;
		}
		/* at the start of a newline look for a comment */
		NEXT_CHARACTER;
		if (ch == COMMENT)
			check_comment(fd);
	} while (j-- && ch != EOF);

	if (ch != EOF)
		timeout_id = XtAppAddTimeOut(app_context, TIMEOUT,
					scan_for_pages, client_data);
	else {
#if 0
		if (mark_last_trailer > 0)
			(void)XukcAddObjectToList(&page_offset_list,
					(XtPointer)mark_last_trailer, FALSE);
#endif
		finished_scan();
	}
}


/****************** Module Exported Routines ********************/

void
SetNumPages(this_page, num_pages)
int this_page, num_pages;
{
	char pg[30];
	char tp[10], np[10];

	if (num_pages >= 0)
		max_pages = num_pages;
	
	if (this_page >= 0)
		(void)sprintf(tp, "%d", this_page);
	else
		(void)strcpy(tp, "?");
	if (num_pages >= 0)
		(void)sprintf(np, "%d", num_pages);
	else
		(void)strcpy(np, "?");

	if (num_pages > 0 && this_page > num_pages)
		(void)sprintf(pg, "EOF");
	else
		(void)sprintf(pg, "%s of %s", tp, np);
	XtVaSetValues(WI_page_label, XtNlabel, pg, NULL);
}


Boolean
FileIsCommented()
{
	return (page_offset_list != 0);
}


void
StartScanForPages(w, fname, fp, fd)
Widget w;
String fname;
FILE *fp;
FILE *fd;
{
	String tmp;

	BusyProcessing(TRUE);
	InitializePageFiles();

	tmp = filename;
	filename = XtNewString(fname);
	if (tmp != NULL)
		XtFree(tmp);

	file = fd;
	search_file = fp;
	dpy_w = w;

	if (prog_resources.use_stdin) {
		/* we were reading from stdin so we should stop reading from
		 * it.
		 */
		CloseStdin();
	}
	reset_file_scanning(fp);
	ResetGhostscript();

	if (prog_resources.ignore_comments)
		finished_scan();
	else {
		/* hightlight the page label to show we are scanning for
		 * pages.
		 */
		page_scanning_indicator(TRUE);

		/* start off the timeout process to find the page offsets */
		app_context = XtWidgetToApplicationContext(w);
		timeout_id = XtAppAddTimeOut(app_context, TIMEOUT,
					scan_for_pages, (XtPointer)fp);


	}
	current_page = 1;
}


void
ShowPage(page_num, reset)
int page_num;
Boolean reset;
{
	long from_offset, to_offset;

	if (filename == NULL || page_num < (reset ? 0 : 1) ||
	    (max_pages > 0 && page_num > max_pages)) {
		XBell(XtDisplay(WI_page_label), 0);
		return; /* an invalid page */
	}

	if (page_offset_list == 0) {
		/* is a page already being processed? */
		if (next_page_waiting) {
			XBell(XtDisplay(dpy_w), 0);
			return; /* need to wait until page finished */
		}
			
		BusyProcessing(TRUE);
		if (page_num == 1 && first_page_shown) {
			StartScanForPages(dpy_w, filename, search_file, file);
			next_page_waiting = FALSE;
			next_page_num = page_num;
			current_page = page_num;
			return;
		}
		next_page_num = page_num;
		first_page_shown = TRUE;
		next_page_waiting = TRUE;
		awaiting_show_page = TRUE;
		SendCommandToGhostscript("\n");
		current_page = page_num;
		return;
	}

	if (reset) {
		to_offset = (long)XukcGetObjectOnList(page_offset_list, 1);
		dump_file(file, 0, 0l, to_offset);
		next_page_waiting = TRUE;
		FoundShowPage();
		next_page_num = 1;
		first_page_shown = TRUE;
		FoundReady();
		awaiting_show_page = FALSE;
		current_page = page_num;
		return;
	} else {
		from_offset = (long)XukcGetObjectOnList(page_offset_list,
							page_num);
		to_offset = (long)XukcGetObjectOnList(page_offset_list,
							page_num + 1);
	}

	if (to_offset <= from_offset) {
		/* race condition where we haven't found this page in the
		 * file yet so we should ignore it.
		 */
		XBell(XtDisplay(dpy_w), 0);
		return;
	}

	dump_file(file, page_num, from_offset, to_offset);
	next_page_num = page_num;
	if (!next_page_waiting && !awaiting_show_page) {
		next_page_waiting = TRUE;
		FoundShowPage();
	}
	next_page_waiting = TRUE;
	current_page = page_num;
	return;
}


void
ShowLastPage()
{
	ShowPage(max_pages, FALSE);
}


int
CurrentPageNumber()
{
	return (current_page);
}


void
FoundCopyPage()
{
	String tmp_name;

	if (page_offset_list && next_page_waiting) {
		BusyProcessing(TRUE);
		command[0] = '\0';
		SendCommandToGhostscript("\n");
	} else {
		BusyProcessing(FALSE);
		SetNumPages(next_page_num, max_pages);
	}
	awaiting_show_page = FALSE;
}


void
FoundShowPage()
{
	String tmp_name;

	if (page_offset_list && next_page_waiting) {
		BusyProcessing(TRUE);
		(void)sprintf(command, "(%s)run\n", next_page_file);
		if (first_page_shown || !ignore_first_ready)
			SendCommandToGhostscript("\n");
		tmp_name = next_page_file;
		next_page_file = current_page_file;
		current_page_file = tmp_name;
	} else {
		BusyProcessing(FALSE);
		next_page_waiting = FALSE;
	}
	SetNumPages(next_page_num, max_pages);
	awaiting_show_page = FALSE;
}


void
FoundReady()
{
	if (prog_resources.use_stdin)
		return;

	if (!page_offset_list && !ignore_first_ready) {
		/* we have reached the end of an uncommented PostScript file */
		BusyProcessing(FALSE);
		if (next_page_num > max_pages) {
			max_pages = next_page_num - 1;
			awaiting_show_page = FALSE;
		}
		SetNumPages(next_page_num, max_pages);
		if (awaiting_show_page) {
			/* must have caught an error so we should
			 * reset Ghostscript
			 */
			KillGhostscript(TRUE);
		}
	} else if (next_page_waiting) {
		awaiting_show_page = TRUE;
		SendCommandToGhostscript(command);
		next_page_waiting = FALSE;
	}
	ignore_first_ready = FALSE;
}


void
FoundError()
{
	BusyProcessing(FALSE);
	awaiting_show_page = FALSE;
	next_page_waiting = FALSE;
	ignore_first_ready = FALSE;
}


void
RemovePageProcessingTimeout()
{
	if (timeout_id != NULL) {
		XtRemoveTimeOut(timeout_id);
		timeout_id = NULL;
	}
}


void
ResetGhostscript()
{
	static Boolean needs_reset = FALSE;

	/* send a reset command to Ghostscript */
	if (needs_reset) {
		KillGhostscript(TRUE);
		ResetOutputHandling();
	}
	ignore_first_ready = TRUE;
	needs_reset = TRUE;
	RemovePageProcessingTimeout();
}


void
DeleteTempFiles()
{
	if (current_page_file != NULL) {
		(void)unlink(current_page_file);
		XtFree(current_page_file);
		current_page_file = NULL;
	}
	if (next_page_file != NULL) {
		(void)unlink(next_page_file);
		XtFree(next_page_file);
		next_page_file = NULL;
	}
	if (zcat_file != NULL) {
		(void)unlink(zcat_file);
		XtFree(zcat_file);
		zcat_file = NULL;
	}
}


void InitializePageFiles()
{
#define file_template "/tmp/gsp%d.%d"
	static Boolean initialized = FALSE;
	char page_file[250];
	extern int getpid();

	if (initialized)
		return;

	(void)umask(~(S_IREAD|S_IWRITE));

	(void)sprintf(page_file, file_template, getpid(), 0);
	current_page_file = XtNewString(page_file);

	(void)sprintf(page_file, file_template, getpid(), 1);
	next_page_file = XtNewString(page_file);

	(void)sprintf(page_file, file_template, getpid(), 2);
	zcat_file = XtNewString(page_file);

	next_page_waiting = FALSE;
	awaiting_show_page = FALSE;
	SetNumPages(-1, -1);
	initialized = TRUE;
}
