#ifndef lint
static char sccsid[] = "@(#)output.c	1.4 (UKC) 31/5/92";
#endif /* !lint */

/* 
 * Copyright 1991 Richard Hesketh / rlh2@ukc.ac.uk
 *                Computing Lab. University of Kent at Canterbury, UK
 *
 * Permission to use, copy, modify and distribute this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the names of Richard Hesketh and The University of
 * Kent at Canterbury not be used in advertising or publicity pertaining to
 * distribution of the software without specific, written prior permission.
 * Richard Hesketh and The University of Kent at Canterbury make no
 * representations about the suitability of this software for any purpose.
 * It is provided "as is" without express or implied warranty.
 *
 * Richard Hesketh AND THE UNIVERSITY OF KENT AT CANTERBURY DISCLAIMS ALL
 * WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL Richard Hesketh OR THE
 * UNIVERSITY OF KENT AT CANTERBURY BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
 * OF THIS SOFTWARE.
 *
 * Author:  Richard Hesketh / rlh2@ukc.ac.uk, 
 *                Computing Lab. University of Kent at Canterbury, UK
 */

#include <stdio.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Xukc/Label.h>
#include <X11/Xukc/ScrollList.h>
#include <X11/Xukc/text.h>
#include <X11/Xukc/memory.h>

#include "errors.h"

#ifdef DEBUG
#define TRACE_ON fprintf(stderr, 
#define TRACE_OFF );
#else
static void _noop_() {};
#define TRACE_ON _noop_(
#define TRACE_OFF );
#endif /* DEBUG */

extern Widget WI_output_dialog_shell, WI_output_text;
extern Widget WI_error_dialog_shell, WI_error_text_label;
extern Widget WI_operand_stack_list, WI_execution_stack_list;
extern Widget WI_dictionary_stack_list;

#define START_OF_LINE (1 << 0)
#define IN_LINE (1 << 1)
#define USER_OUTPUT (1 << 2)
#define SYSTEM_OUTPUT (1 << 3)
#define SYSTEM_ERROR (1 << 4)
#define RECOGNISED_TOKEN (1 << 5)
#define UNRECOGNISED_TOKEN (1 << 6)
#define FOUND_EOL (1 << 7)

#define RESET_FLAGS parse_flags = START_OF_LINE | USER_OUTPUT
#define RESET_FLAG(flag) parse_flags &= !(flag)
#define SET_FLAG(flag) parse_flags |= (flag)

#define GS_MSG_MARKER '\001'
#define GS_ERROR_MARKER '\002'
#define GS_SYSTEM_PREFIX "%GSPreview"
#define GS_SYSTEM_PREFIX_LEN 10
#define GS_ERROR_MSG "Error% "
#define GS_ERROR_MSG_LEN 7
#define GS_WARNING_MSG "Warning% "
#define GS_WARNING_MSG_LEN 9
#define GS_SYSTEM_MSG "% "
#define GS_SYSTEM_MSG_LEN 2
#define GS_SHOW_PAGE "Directive% >>showpage"
#define GS_SHOW_PAGE_LEN 21
#define GS_COPY_PAGE "Directive% >>copypage"
#define GS_COPY_PAGE_LEN 21
#define GS_READY "Directive% Ready"
#define GS_READY_LEN 16

#define ERROR_MESSAGE_LINE 0
#define OSTACK_LINE 1
#define ESTACK_LINE 2
#define DSTACK_LINE 3

void OutputError();

extern void SendNextPage();
extern void FoundError();
extern char *index();

static char parse_flags = (START_OF_LINE | USER_OUTPUT);
static Boolean errors_processed = FALSE;
static Cardinal exec_list = 0, op_list = 0, dict_list = 0;

static Boolean first_line = TRUE;


static void
display_in_list(w, stack, list)
Widget w;
String stack;
Cardinal *list;
{
	Cardinal num_on_list = 0;
	String next_member = NULL;
	String *str_list = NULL;

	XukcDestroyList(list, TRUE);
	while (*stack && (next_member = index(stack, GS_ERROR_MARKER)) != NULL){
		*next_member = '\0';
		if (stack == next_member)
			(void)XukcAddObjectToList(list,
					(XtPointer)XtNewString("<blank>"),
					FALSE);
		else
			(void)XukcAddObjectToList(list,
					(XtPointer)XtNewString(stack),
					FALSE);
		stack = next_member + 1;
	}
	stack[strlen(stack)-1] = '\0'; /* knock off trailing new line */
	(void)XukcAddObjectToList(list, (XtPointer)XtNewString(stack), FALSE);
	str_list = (String *)XukcGetListPointer(*list, &num_on_list);
	XukcScrListChange(w, str_list, num_on_list);
}


static void
process_error(text)
String text;
{
	static int error_line_count = 0;

	switch (error_line_count) {
		case ERROR_MESSAGE_LINE:
			OutputError(text, TRUE);
			error_line_count++;
			break;
		case ESTACK_LINE:
			/* "Execution Stack: " */
			while (*text && *text != ':') text++;
			display_in_list(WI_execution_stack_list, text + 2,
					&exec_list);
			error_line_count++;
			break;
		case OSTACK_LINE:
			/* "Operand Stack: " */
			while (*text && *text != ':') text++;
			display_in_list(WI_operand_stack_list, text + 2,
					&op_list);
			error_line_count++;
			break;
		case DSTACK_LINE:
			/* "Dictionary Stack: " */
			while (*text && *text != ':') text++;
			display_in_list(WI_dictionary_stack_list, text + 2,
					&dict_list);
			error_line_count = 0;
			break;
	}
	FoundError();
}


/********** Module Exported Routines ************/


void
ResetOutputHandling()
{
	first_line = TRUE;
}


/* ARGSUSED */
void
ClearOutput(w, client_data, call_data)
Widget w;
XtPointer client_data, call_data;
{
	XukcClearTextWidget(WI_output_text);
}


void
OutputText(text, popup)
String text;
Boolean popup;
{
	/* places output on the end of the output text widget */
	XukcAppendToTextWidget(WI_output_text, text);
	if (popup) {
		CentreDialog(WI_output_dialog_shell);
		XtPopup(WI_output_dialog_shell, XtGrabNone);
	}
}


void
OutputError(text, popup)
String text;
Boolean popup;
{
	char *errmsg;
	char *ptr;
	Cardinal i;

	/* split error message up and parse it to produce a more
	 * user readable one! 
	 *   text = "Error:<space>\errortype<space>in<space>operand*"
	 */
	text = index(text, ' ') + 1;
	ptr = index(text, ' ');
	*ptr = '\0';
	ptr += 4; /* " in " */
	for (i = XtNumber(errors) - 1; i > 0; i--)
		if (strcmp(errors[i].gs_name, text) == 0)
			break;

	errmsg = XtMalloc(strlen(errors[i].error_message) + strlen(ptr) + 12);
	(void)sprintf(errmsg, "%s\nOperand = %s", errors[i].error_message,
			ptr);
	
	/* places output on the end of the error label widget */
	XtVaSetValues(WI_error_text_label, XtNlabel, errmsg, NULL);
	CentreDialog(WI_error_dialog_shell);
	XtPopup(WI_error_dialog_shell, XtGrabNone);
	XtFree(errmsg);
}


void
ParseError(text)
String text;
{
	static char *line_buf = NULL;
	char *inptr;

	if (!*text)
		return;

	/* look for an end of line in this text buffer */
	if ((inptr = index((char *)text, '\n')) == NULL &&
	    index((char *)text + ((parse_flags & START_OF_LINE)
				== START_OF_LINE), GS_MSG_MARKER) == NULL) {
		/* squirrel away the line text until we have a complete line */
		if (parse_flags & START_OF_LINE) {
			if (*text == GS_MSG_MARKER)
				text++; /* skip the system message marker */
			XtFree(line_buf);
			line_buf = XukcGrowString((char *)NULL, strlen(text) + 2);
			(void)strcpy(line_buf, text);
			RESET_FLAG(START_OF_LINE);
			SET_FLAG(IN_LINE);
		} else {
			line_buf = XukcGrowString(line_buf, strlen(line_buf) +
							strlen(text) + 2);
			(void)strcat(line_buf, text);
		}
		return;
	} else {
		char *tmp_ptr;
		/* end of line found so process this line and check for
		 * a next line.
		 */
		if (*text == GS_MSG_MARKER && (parse_flags & START_OF_LINE))
			text++; /* skip the system message marker */
		tmp_ptr = index((char *)text, GS_MSG_MARKER);

		if (tmp_ptr != NULL && (inptr == NULL || tmp_ptr < inptr))
			inptr = tmp_ptr;
		*inptr = '\0';

		if (parse_flags & START_OF_LINE) {
			XtFree(line_buf);
			line_buf = XukcGrowString((char *)NULL, strlen(text) + 2);
			(void)strcpy(line_buf, text);
		} else {
			line_buf = XukcGrowString(line_buf, strlen(line_buf) +
							strlen(text) + 2);
			(void)strcat(line_buf, text);
		}

		RESET_FLAG(IN_LINE);
		SET_FLAG(START_OF_LINE);
		(void)strcat(line_buf, "\n");
		text = inptr + 1;
	}

	if (strncmp(line_buf, GS_SYSTEM_PREFIX, GS_SYSTEM_PREFIX_LEN) == 0) {
		/* found a Ghostscript generated line! */
		inptr = line_buf + GS_SYSTEM_PREFIX_LEN;
		if (strncmp(inptr, GS_SYSTEM_MSG, GS_SYSTEM_MSG_LEN) == 0) {
			/* a Ghostscript message .. nothing urgent */
			inptr += GS_SYSTEM_MSG_LEN;
			OutputText("GS> ", FALSE);
			OutputText(inptr, FALSE);
TRACE_ON "GS> %s\n", inptr TRACE_OFF
		} else if (strncmp(inptr, GS_WARNING_MSG, GS_WARNING_MSG_LEN) == 0){
			/* a Ghostscript error .. do special processing */
			inptr += GS_WARNING_MSG_LEN;
			OutputText("GS-Warning> ", FALSE);
			OutputText(inptr, FALSE);
TRACE_ON "GS-Warning> %s\n", inptr TRACE_OFF
		} else if (strncmp(inptr, GS_ERROR_MSG, GS_ERROR_MSG_LEN) == 0){
			/* a Ghostscript error .. do special processing */
			inptr += GS_ERROR_MSG_LEN;
			process_error(inptr);
TRACE_ON "GS-Error> %s\n", inptr TRACE_OFF
		} else if (strncmp(inptr, GS_SHOW_PAGE, GS_SHOW_PAGE_LEN) == 0){
			/* a showpage prompt so we can press return if
			 * a page is there to display.
			 */
TRACE_ON "FoundShowPage()\n" TRACE_OFF
			FoundShowPage();
		} else if (strncmp(inptr, GS_COPY_PAGE, GS_COPY_PAGE_LEN) == 0){
			/* a copypage prompt so we can press return if
			 * a page is there to display.
			 */
			FoundCopyPage();
		} else if (strncmp(inptr, GS_READY, GS_READY_LEN) == 0){
			/* a Ghostscript prompt so we can process the next
			 * page if there is one.
			 */
TRACE_ON "FoundReady()\n" TRACE_OFF
			FoundReady();
		}
	} else
		/* tiz normal text so output it to the output window */
		if (!first_line)
			OutputText(line_buf, TRUE);
		else
			first_line = FALSE;

	ParseError(text);
}


/* ARGSUSED */
void
ClearErrors(w, client_data, call_data)
Widget w;
XtPointer client_data, call_data;
{
	XtVaSetValues(WI_error_text_label, XtNlabel, "", NULL);
}
