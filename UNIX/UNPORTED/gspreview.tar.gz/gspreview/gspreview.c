#ifndef lint
/* from   "$Xukc: gspreview.c,v 1.16 91/07/10 14:48:50 rlh2 Exp $" */
static char sccsid[] = "@(#)gspreview.c	1.12 (UKC) 9/7/92";
#endif /* !lint */

/* 
 * Copyright 1991,1992 Richard Hesketh / rlh2@ukc.ac.uk
 *                     Computing Lab. University of Kent at Canterbury, UK
 *
 * Permission to use, copy, modify and distribute this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the names of Richard Hesketh and The University of
 * Kent at Canterbury not be used in advertising or publicity pertaining to
 * distribution of the software without specific, written prior permission.
 * Richard Hesketh and The University of Kent at Canterbury make no
 * representations about the suitability of this software for any purpose.
 * It is provided "as is" without express or implied warranty.
 *
 * Richard Hesketh AND THE UNIVERSITY OF KENT AT CANTERBURY DISCLAIMS ALL
 * WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL Richard Hesketh OR THE
 * UNIVERSITY OF KENT AT CANTERBURY BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
 * OF THIS SOFTWARE.
 *
 * Author:  Richard Hesketh / rlh2@ukc.ac.uk, 
 *                Computing Lab. University of Kent at Canterbury, UK
 */

#include <stdio.h>
#include <fcntl.h>
#include <ctype.h>		/* for isspace() */
#include <sys/types.h>
#include <sys/stat.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Shell.h>
#include <X11/Xaw/Simple.h>
#include <X11/Xukc/Label.h>
#include <X11/Xukc/Toggle.h>
#include <X11/Xukc/ScrollList.h>
#include <X11/Xukc/text.h>
#include <X11/Xukc/Convert.h>
#include "resources.h"

#ifdef DEBUG
#define TRACE_ON fprintf(stderr, 
#define TRACE_OFF );
#else
static void _noop_() {};
#define TRACE_ON _noop_(
#define TRACE_OFF );
#endif /* DEBUG */

#define BOOTSTRAP_TIMEOUT 100 /* in milliseconds */

extern char *index();	

extern Widget XukcDirtGO();
extern void XukcDirtRegisterApplicationDefaults();
extern Display *XukcToolkitInitialize();

extern String ExpandFilename();
extern String UncompressFile();
extern void KillGhostscript();
extern void ClearOutput();
extern void ClearErrors();
extern void SelectFileCB();
extern void FileKeyPressACT();
extern int CurrentPageNumber();
extern void ShowPage();
extern void ShowLastPage();
extern void DeleteTempFiles();
extern void StartGhostscript();
extern void ProcessStdin();
extern void ResetFileList();

extern Widget WI_gspreview, WI_ps_window, WI_filename_entry;
extern Widget WI_output_view;
extern Widget WI_file_dialog_shell, WI_page_dialog_shell;
extern Widget WI_options_dialog_shell, WI_error_dialog_shell;
extern Widget WI_output_dialog_shell;
extern Widget WI_page_value, WI_filename_label;
extern Widget WI_file_error_label;
extern Widget WI_options_ignore_comments, WI_options_page_size_list;
extern Widget WI_options_portrait, WI_options_landscape;
extern Widget WI_options_upside_down, WI_options_seascape;
extern Widget WI_normal_size_button, WI_custom_size_button;
extern Widget WI_custom_resolution_button;
extern Widget WI_scaling_custom_entry, WI_scaling_resolution_entry;

void CentreDialog();
void BusyProcessing();
void QuitGSP();
void LoadFile();

static int change_count = 0;
static FILE *fp = NULL, *fd = NULL;
static String current_file = NULL;
static int next_paper_tray = 0;
static int next_set_scale = 0;
static int next_layout = PAGE_PORTRAIT;
static Widget next_set_scale_widget;
static Widget next_layout_widget;

static String app_defaults[] = {
	"*gspreview.borderWidth: 2",
	"*fileDialogShell.borderWidth: 2",
	"*pageDialogShell.borderWidth: 2",
	"*errorDialogShell.borderWidth: 2",
	"*outputDialogShell.borderWidth: 2",
	"*optionsDialogShell.borderWidth: 2",
	"*scaleDialogShell.borderWidth: 2"
};

struct app_resources prog_resources;

#define offset(field) XtOffset(struct app_resources *, field)
static XtResource gspreview_resources[] = {
        {"picassoPrinter", "PicassoPrinter", XtRBoolean, sizeof(Boolean),
         offset(picasso), XtRImmediate, (XtPointer)FALSE},
        {"ignoreComments", "IgnoreComments", XtRBoolean, sizeof(Boolean),
         offset(ignore_comments), XtRImmediate, (XtPointer)FALSE},
        {"pageLayout", "PageLayout", "PageLayout", sizeof(int),
         offset(page_layout), XtRImmediate, (XtPointer)PAGE_PORTRAIT},
        {"pageResolution", "PageResolution", XtRInt, sizeof(int),
         offset(resolution), XtRImmediate, (XtPointer)0},
	{"useStdin", "UseStdin", XtRBoolean, sizeof(Boolean),
	 offset(use_stdin), XtRImmediate, (XtPointer)FALSE},
	{"paperSizes", "PaperSizes", XtRString, sizeof(String),
	 offset(page_sizes), XtRImmediate, (XtPointer)DEFAULT_SIZES},
	{"paperTray", "PaperTray", XtRString, sizeof(String),
	 offset(page_size_name), XtRImmediate, (XtPointer)DEFAULT_PAGE},
	{"initialPage", "Page", XtRInt, sizeof(int),
	 offset(initial_page), XtRImmediate, (XtPointer)1},
};

/* command line options */
static XrmOptionDescRec gspreview_options[] = {
        {"-picasso", ".picassoPrinter", XrmoptionNoArg, (XtPointer)"true"},
        {"-comments", ".ignoreComments", XrmoptionNoArg, (XtPointer)"true"},
        {"+comments", ".ignoreComments", XrmoptionNoArg, (XtPointer)"false"},
	{"-", ".useStdin", XrmoptionNoArg, (XtPointer)"true"},
	{"-res", ".pageResolution", XrmoptionSepArg, (XtPointer)NULL},
	{"-resolution", ".pageResolution", XrmoptionSepArg, (XtPointer)NULL},
	{"-sizes", ".paperSizes", XrmoptionSepArg, (XtPointer)NULL},
	{"-paper", ".paperTray", XrmoptionSepArg, (XtPointer)NULL},
	{"-portrait", ".pageLayout", XrmoptionNoArg, (XtPointer)"portrait"},
	{"-landscape", ".pageLayout", XrmoptionNoArg, (XtPointer)"landscape"},
	{"-upsidedown", ".pageLayout", XrmoptionNoArg, (XtPointer)"upsidedown"},
	{"-seascape", ".pageLayout", XrmoptionNoArg, (XtPointer)"seascape"},
	{"-page", ".initialPage", XrmoptionSepArg, (XtPointer)NULL},
};

static EnumListRec page_orientations[] = {
	{ "portrait", PAGE_PORTRAIT },
	{ "landscape", PAGE_LANDSCAPE },
	{ "upsidedown", PAGE_UPSIDEDOWN },
	{ "seascape", PAGE_SEASCAPE },
};

static XtConvertArgRec page_orientations_Args[] = {
	{ XtAddress,    (XtPointer)page_orientations, sizeof(EnumList) },
	{ XtImmediate,  (XtPointer)XtNumber(page_orientations), sizeof(Cardinal) },
	{ XtAddress,    "PageLayout",  sizeof(String) },
};


static void
load_error(error_str)
String error_str;
{
	char tmp[500];

	/* found an error when opening the PS file .. so display
	 * an error message in the Load File window and
	 * pop it back up again to prompt the user to enter
	 * a correct filename.
	 */
	(void)sprintf(tmp, "Error: %s", error_str);
	BusyProcessing(FALSE);
	XtVaSetValues(WI_file_error_label, XtNlabel, tmp, NULL);
	XtPopup(WI_file_dialog_shell, XtGrabNone);
	XBell(XtDisplay(WI_file_dialog_shell), 0);
}


/* ARGSUSED */
static void
clear_load_error(w, client_data, call_data)
Widget w;
XtPointer client_data, call_data;
{
	XtVaSetValues(WI_file_error_label, XtNlabel, "", NULL);
}


static void
RelativePageMovement(number)
int number;
{
	ShowPage(CurrentPageNumber() + number, FALSE);
}


static void
AbsolutePageMovement(number)
int number;
{
	ShowPage(number, FALSE);
}


static void
do_count(w, event, params, num_params)
Widget w;
XEvent *event;
String *params;
Cardinal *num_params;
{
        char strbuf[128];
        int keycode, len;
        XComposeStatus compose_status;

	if ((len = XLookupString(event, strbuf, 128, &keycode,
	     &compose_status)) == 0)
		return;

	change_count *= 10;
	change_count += strbuf[0] - '0';
}


static void
cancel_count(w, event, params, num_params)
Widget w;
XEvent *event;
String *params;
Cardinal *num_params;
{
	change_count = 0;
}


static void
next_page_action(w, event, params, num_params)
Widget w;
XEvent *event;
String *params;
Cardinal *num_params;
{
	if (fp == NULL)
		return;
	RelativePageMovement(change_count == 0 ? 1 : change_count);
}


static void
previous_page_action(w, event, params, num_params)
Widget w;
XEvent *event;
String *params;
Cardinal *num_params;
{
	if (fp == NULL)
		return;
	RelativePageMovement(change_count == 0 ? -1 : -change_count);
}


static void
goto_page_action(w, event, params, num_params)
Widget w;
XEvent *event;
String *params;
Cardinal *num_params;
{
	if (fp == NULL)
		return;
	AbsolutePageMovement(change_count == 0 ? 1 : change_count);
}


static void
goto_page_callback(w, client_data, call_data)
Widget w;
XtPointer client_data, call_data;
{
	int value;

	XtVaGetValues(WI_page_value, XtNvalue, &value, NULL);
	AbsolutePageMovement(value);
}


static void
reread_file(w, event, params, num_params)
Widget w;
XEvent *event;
String *params;
Cardinal *num_params;
{
	FILE *f1, *f2;

	if (fp == NULL)
		return;

	/* re-open two file descriptors .. one for scanning and one for reading
	 * from to dump the page files.
	 */
	if ((f1 = fopen(current_file, "r")) == NULL) {
		load_error(reason());
		return;
	}
	if ((f2 = fopen(current_file, "r")) == NULL) {
		fprintf(stderr, "%s: cannot open \"%s\" (%s)\n", PROG_NAME,
			current_file, reason());
		exit(1);
	}

	(void)fclose(fp);
	(void)fclose(fd);
	fp = f1;
	fd = f2;

	StartScanForPages(WI_ps_window, current_file, fp, fd);
}


static void
goto_last(w, event, params, num_params)
Widget w;
XEvent *event;
String *params;
Cardinal *num_params;
{
	if (fp == NULL)
		return;
	ShowLastPage();
}


static void
goto_first(w, event, params, num_params)
Widget w;
XEvent *event;
String *params;
Cardinal *num_params;
{
	if (fp == NULL)
		return;
	AbsolutePageMovement(1);
}


static void
load_file_callback(w, client_data, call_data)
Widget w;
XtPointer client_data, call_data;
{
	String str = NULL;

	XtVaGetValues(WI_filename_entry, XtNstring, &str, NULL);

	if (str == NULL || *str == '\0')
		return;

	prog_resources.initial_page = 1;
	LoadFile(str);
}


static void
toggle_comments(w, client_data, call_data)
Widget w;
XtPointer client_data, call_data;
{
	Pixel fg, bg;

	prog_resources.ignore_comments = !prog_resources.ignore_comments;

	XtVaSetValues(WI_options_ignore_comments, XtNstate,
			prog_resources.ignore_comments, NULL);
	XtVaGetValues(WI_filename_label, XtNforeground, &fg,
					 XtNbackground, &bg, NULL);
	XtVaSetValues(WI_filename_label, XtNforeground, bg,
					 XtNbackground, fg, NULL);
}


static void
toggle_action(w, event, params, num_params)
Widget w;
XEvent *event;
String *params;
Cardinal *num_params;
{
	toggle_comments(w, (XtPointer)NULL, (XtPointer)NULL);
}


static void
set_page_scaling(w, client_data, call_data)
Widget w;
XtPointer client_data, call_data;
{
	int scale = atoi((String)client_data);

	next_set_scale = scale;
	next_set_scale_widget = w;
}


static void
check_number_entry(w, event, params, num_params)
Widget w;
XEvent *event;
String *params;
Cardinal *num_params;
{
	String str = NULL;
	char tmp[20];

	XtVaGetValues(w, XtNstring, &str, NULL);
	(void)sprintf(tmp, "%d", atoi(str));
	XukcNewTextWidgetString(w, tmp);
}


static void
reboot_ghostscript(w, client_data, call_data)
Widget w;
XtPointer client_data, call_data;
{
	int current_page = CurrentPageNumber();

	if (fp == NULL)
		return;

	ClearOutput();
	ResetOutputHandling();

	if (FileIsCommented()) {
		KillGhostscript(TRUE);
		(void)ShowPage(0, TRUE);
		AbsolutePageMovement(current_page);
	} else
		reread_file(w, (XEvent *)0, (String *)0, (Cardinal *)0);
}


static void
reboot_action(w, event, params, num_params)
Widget w;
XEvent *event;
String *params;
Cardinal *num_params;
{
	reboot_ghostscript(w, (XtPointer)NULL, (XtPointer)NULL);
}


static void
apply_scale(w, client_data, call_data)
Widget w;
XtPointer client_data, call_data;
{
	String str = NULL;

	if (next_set_scale == 0) {
		XtVaGetValues(WI_scaling_custom_entry, XtNstring, &str, NULL);
		prog_resources.resolution = -(atoi(str));
	} else if (next_set_scale > 0) {
		XtVaGetValues(WI_scaling_resolution_entry, XtNstring, &str,
				NULL);
		prog_resources.resolution = atoi(str);
	} else
		prog_resources.resolution = next_set_scale;

	prog_resources.current_scaling = next_set_scale_widget;
}


static void
set_page_layout(w, client_data, call_data)
Widget w;
XtPointer client_data, call_data;
{
	next_layout = atoi((char *)client_data);
	next_layout_widget = w;
}


static void
set_page_size(w, client_data, call_data)
Widget w;
XtPointer client_data, call_data;
{
	XawListReturnStruct *picked_string = (XawListReturnStruct *)call_data;

	next_paper_tray = picked_string->list_index;
}


static void
apply_options(w, client_data, call_data)
Widget w;
XtPointer client_data, call_data;
{
	struct page_size_entry *szptr = prog_resources.page_size_list;

	prog_resources.page_size_index = next_paper_tray;

	prog_resources.page_layout = next_layout;
	prog_resources.current_layout = next_layout_widget;

	for (; next_paper_tray > 0 && szptr->next != NULL; next_paper_tray--)
		szptr = szptr->next;

	prog_resources.page_width = szptr->width;
	prog_resources.page_height = szptr->height;
}


/* This is called to initially load a file if one was given on the command
 * line. */
/* ARGSUSED */
static void
bootstrap_timeout(client_data, id)
XtPointer client_data;	/* argv[0] - filename of PS file */
XtIntervalId *id;
{
	BusyProcessing(TRUE);
	LoadFile((String)client_data);
}


static void
centre_dialog(w, client_data, call_data)
Widget w;
XtPointer client_data, call_data;
{
	CentreDialog(w);
}


static void
comment_start()
{
	XtVaSetValues(WI_options_ignore_comments, XtNstate,
			prog_resources.ignore_comments, NULL);

	if (prog_resources.ignore_comments) {
		Pixel fg, bg;

		XtVaGetValues(WI_filename_label, XtNforeground, &fg,
					 XtNbackground, &bg, NULL);
		XtVaSetValues(WI_filename_label, XtNforeground, bg,
					 XtNbackground, fg, NULL);
	}
}


static void
process_ghostview_event(w, client_data, event, cont)
Widget w;
XtPointer client_data;
XEvent *event;
Boolean *cont;
{
	static Atom next_page = NULL;
	XEvent ev;

	if (next_page == NULL)
		next_page = XInternAtom(XtDisplay(w), "NEXT", 0);

	ev.xclient.type = ClientMessage;
	ev.xclient.display = XtDisplay(w);
	ev.xclient.window = (Window)event->xclient.data.l[0];
	ev.xclient.message_type = next_page;
	ev.xclient.format = 32;
	XSendEvent(XtDisplay(w), ev.xclient.window, False, 0, &ev);
}


static void
free_page_list(ptr)
struct page_size_entry *ptr;
{
	if (ptr == NULL)
		return;

	free_page_list(ptr->next);
	XtFree(ptr->size_name);
	XtFree(ptr);
}


static void
parse_page_sizes(w)
Widget w;
{
	/* take the prog_resources.page_sizes string and parse it
	 * to produce a list of structures describing the different
	 * size pages.
	 */
	static String *str_list = NULL;
	struct page_size_entry *new = NULL;
	char *delim, *str;
	int width, height, count = 0, list_count;
	char name[200];

	free_page_list(prog_resources.page_size_list);
	prog_resources.page_size_list = NULL;

	str = prog_resources.page_sizes;
	while ((str = index(str, '=')) != NULL) {
		str++;
		count++;
	}

	list_count = count;
	if (str_list != NULL)
		XtFree(str_list);
	str_list = (String *)XtMalloc(sizeof(String) * list_count);

	str = prog_resources.page_sizes;
	do {
		/* each page size is whitespace separated */
		for (delim = str; *delim && !isspace(*delim); ) delim++;

		if (!*delim)
			delim = str + strlen(str);

		if (sscanf(str, "%[^=]=%dx%d", name, &width, &height) != 3) {
			fprintf(stderr, "%s: unable to parse page sizes \"%s\"\n",
				PROG_NAME, str);
			exit(1);
		}
		if (new == NULL)
			new = prog_resources.page_size_list =
				       (struct page_size_entry *)
				       XtMalloc(sizeof(struct page_size_entry));
		else {
			new->next = (struct page_size_entry *)
				    XtMalloc(sizeof(struct page_size_entry));
			new = new->next;
		}
		new->next = NULL;
		new->size_name = XtNewString(name);
		new->width = width;
		new->height = height;
		str_list[list_count - count] = new->size_name;

		str = delim + 1;
		count--;
		while (count && *str && isspace(*str)) str++;
	} while (count > 0);

	XukcScrListChange(w, str_list, (Cardinal)list_count);

	/* now check which paper size has been set as the default and
	 * highlight it in the list and set the internal page_width and
	 * page_height variables.
	 */
	while (list_count > 0 &&
	       strcmp(str_list[list_count - 1], prog_resources.page_size_name))
			list_count--;

	if (list_count) {
		(void)XukcScrListSelectItem(w, list_count, TRUE, TRUE);
		apply_options(w, (XtPointer)NULL, (XtPointer)NULL);
	} else {
		fprintf(stderr, "%s: uknown paper tray setting \"%s\"\n",
			PROG_NAME, prog_resources.page_size_name);
		exit(1);
	}
}


reset_scaling(w, client_data, call_data)
Widget w;
XtPointer client_data, call_data;
{
	XukcSetToggle(prog_resources.current_scaling, FALSE);
}


reset_options(w, client_data, call_data)
Widget w;
XtPointer client_data, call_data;
{
	XukcSetToggle(prog_resources.current_layout, FALSE);
	(void)XukcScrListSelectItem(WI_options_page_size_list,
				    prog_resources.page_size_index + 1,
				    TRUE, TRUE);
}


set_ui_defaults()
{
	next_layout = prog_resources.page_layout;

	parse_page_sizes(WI_options_page_size_list);

	/* set whether we are using comments or not */
	comment_start();

	if (prog_resources.resolution > 0) {
		char val_str[30];
		(void)sprintf(val_str, "%d", prog_resources.resolution);
		XukcNewTextWidgetString(WI_scaling_resolution_entry, val_str);
		next_set_scale_widget = WI_custom_resolution_button;
	} else if (prog_resources.resolution < 0) {
		char val_str[30];
		(void)sprintf(val_str, "%d", -prog_resources.resolution);
		XukcNewTextWidgetString(WI_scaling_custom_entry, val_str);
		next_set_scale_widget = WI_custom_size_button;
	} else
		next_set_scale_widget = WI_normal_size_button;
	XtVaSetValues(next_set_scale_widget, XtNstate, TRUE, 0);
	prog_resources.current_scaling = next_set_scale_widget;

	switch (prog_resources.page_layout) {
	case PAGE_PORTRAIT:
		next_layout_widget = WI_options_portrait;
		break;
	case PAGE_LANDSCAPE:
		next_layout_widget = WI_options_landscape;
		break;
	case PAGE_UPSIDEDOWN:
		next_layout_widget = WI_options_upside_down;
		break;
	case PAGE_SEASCAPE:
		next_layout_widget = WI_options_seascape;
		break;
	}
	XtVaSetValues(next_layout_widget, XtNstate, TRUE, 0);
	prog_resources.current_layout = next_layout_widget;
}


main(argc, argv)
int argc;
char *argv[];
{
	Widget tmp;
	Display *dpy;
	XtAppContext app_context;
	XrmDatabase sdb;

	dpy = XukcToolkitInitialize(NULL, "gspreview", "GSPreview",
					&argc, argv,
					gspreview_options,
					XtNumber(gspreview_options),
					(String *)NULL);

	XukcDirtRegisterApplicationDefaults(DefaultScreenOfDisplay(dpy),
						app_defaults,
						XtNumber(app_defaults));

#ifdef BITMAP_FILE_PATH
#if defined(XlibSpecificationRelease) && XlibSpecificationRelease > 4
	sdb = XtScreenDatabase(DefaultScreenOfDisplay(dpy));
#else
	sdb = dpy->db;
#endif
	XukcAddToBitmapFilePath(&sdb, "gspreview", "GSPreview",
				BITMAP_FILE_PATH);
#endif /* BITMAP_FILE_PATH */

	tmp = XtAppCreateShell("gspreview", "GSPreview",
					applicationShellWidgetClass, dpy,
					(ArgList)NULL, 0);

	XtSetTypeConverter(XtRString, "PageLayout",
				XukcCvtStringToNamedValue,
				page_orientations_Args,
				XtNumber(page_orientations_Args),
				XtCacheNone, (XtDestructor)NULL);

        XtGetApplicationResources(tmp, (XtPointer)&prog_resources,
                                       (XtResourceList)gspreview_resources,
                                       XtNumber(gspreview_resources),
                                       (ArgList)NULL, 0);

	app_context = XtWidgetToApplicationContext(tmp);

	WcRegisterCallback(app_context, "quit_gsp", QuitGSP);
	WcRegisterCallback(app_context, "next_page", next_page_action);
	WcRegisterCallback(app_context, "previous_page", previous_page_action);
	WcRegisterCallback(app_context, "goto_page", goto_page_callback);
	WcRegisterCallback(app_context, "load_file", load_file_callback);
	WcRegisterCallback(app_context, "centre_dialog", centre_dialog);
	WcRegisterCallback(app_context, "clear_load_error", clear_load_error);
	WcRegisterCallback(app_context, "clear_errors", ClearErrors);
	WcRegisterCallback(app_context, "clear_output", ClearOutput);
	WcRegisterCallback(app_context, "toggle_comments", toggle_comments);
	WcRegisterCallback(app_context, "set_page_scaling", set_page_scaling);
	WcRegisterCallback(app_context, "apply_scale", apply_scale);
	WcRegisterCallback(app_context, "set_page_layout", set_page_layout);
	WcRegisterCallback(app_context, "set_page_size", set_page_size);
	WcRegisterCallback(app_context, "apply_options", apply_options);
	WcRegisterCallback(app_context, "redisplay_page", reboot_ghostscript);
	WcRegisterCallback(app_context, "reset_scaling", reset_scaling);
	WcRegisterCallback(app_context, "reset_options", reset_options);
	WcRegisterCallback(app_context, "select_file", SelectFileCB);

	WcRegisterAction(app_context, "do_count", do_count);
	WcRegisterAction(app_context, "cancel_count", cancel_count);
	WcRegisterAction(app_context, "next_page", next_page_action);
	WcRegisterAction(app_context, "previous_page", previous_page_action);
	WcRegisterAction(app_context, "goto_page", goto_page_action);
	WcRegisterAction(app_context, "goto_last", goto_last);
	WcRegisterAction(app_context, "goto_first", goto_first);
	WcRegisterAction(app_context, "reread_file", reread_file);
	WcRegisterAction(app_context, "load_file", load_file_callback);
	WcRegisterAction(app_context, "centre_dialog", centre_dialog);
	WcRegisterAction(app_context, "gs_quit", QuitGSP);
	WcRegisterAction(app_context, "toggle_comments", toggle_action);
	WcRegisterAction(app_context, "check_number_entry", check_number_entry);
	WcRegisterAction(app_context, "redisplay_page", reboot_action);
	WcRegisterAction(app_context, "check_entered_filename",
							FileKeyPressACT);

	XukcCreateUserInterface(tmp);

	/* clean up on KillClient or Server shutdown events */
	XSetIOErrorHandler(QuitGSP);

	XtRealizeWidget(tmp);

	/* make all keyboard entry in the File dialog shell go into the
	 * filename text entry area.
	 */
	XtSetKeyboardFocus(WI_file_dialog_shell, WI_filename_entry);
	XtSetKeyboardFocus(WI_gspreview, WI_ps_window);

	/* We need a way to guarantee that the rendering window will be
	 * there before we start the Ghostscript interpreter .. however we
	 * cannot do this in X.
	 * So synchronize with the X Server and hope for the best.
	 */
	XSync(XtDisplay(tmp), FALSE);

	set_ui_defaults();
	UpdateFileList((String)NULL);

	/* Process client_messages coming from "gs" for "ghostview" */
	XtAddEventHandler(WI_ps_window, NoEventMask, TRUE,
			  process_ghostview_event, (XtPointer)NULL);

	if (argc > 1) {
		BusyProcessing(TRUE);
		XtAppAddTimeOut(app_context, BOOTSTRAP_TIMEOUT,
				bootstrap_timeout, (XtPointer)argv[1]);
	} else
		OpenStdin(fileno(stdin));

	/* A kludge to get around the form widget's size semantics and
	 * force the filename label to be the right width.
	 */
	{
		Position l_x;
		Dimension p_width;

		XtUnmanageChild(WI_filename_label);
		XtVaGetValues(XtParent(WI_filename_label), XtNwidth,
				&p_width, NULL);
		XtVaGetValues(WI_filename_label, XtNx, &l_x, NULL);
		XtVaSetValues(WI_filename_label, XtNwidth,
				p_width - l_x - 1, NULL);
		XtManageChild(WI_filename_label);
	}

	XtAppMainLoop(app_context);
}


void
CentreDialog(w)
Widget w;
{
        Position x, y;
        Dimension width, height;

#if 0
        XtVaGetValues(w, XtNx, &x, XtNy, &y, NULL);
	if (x != -9999 && y != -9999)
		return;

        XtVaGetValues(WI_gspreview, XtNx, &x, XtNy, &y, XtNwidth, &width,
                                XtNheight, &height, NULL);
        x += width/2;
        y += height/2;
TRACE_ON ">centre_dialog(%d, %d)\n", x, y TRACE_OFF
        XtVaGetValues(w, XtNwidth, &width, XtNheight, &height, NULL);
        x -= width/2;
        y -= height/2;
        XtVaSetValues(w, XtNx, x, XtNy, y, NULL);

TRACE_ON "<centre_dialog(%d, %d)\n", x, y TRACE_OFF
#else
#if 1
	/* why does this not work properly under twm? */
	XtTranslateCoords(WI_output_view, 0, 0, &x, &y);
#else
{
	int nx, ny;
	Window child;

	XTranslateCoordinates(XtDisplay(WI_output_view),
				XtWindow(WI_output_view),
				DefaultRootWindow(XtDisplay(WI_output_view)),
				0 ,0, &nx, &ny, &child);
	x = nx;
	y = ny;
}
#endif
	XtVaSetValues(w, XtNx, x, XtNy, y, NULL);
#endif
}


void
BusyProcessing(state)
Boolean state;
{
	XtVaSetValues(WI_ps_window, XtVaTypedArg, XtNcursor, XtRString,
			state ? "watch" : "hand1", 6, NULL);
	XFlush(XtDisplay(WI_ps_window));
}


void
QuitGSP()
{
	KillGhostscript(FALSE);
	DeleteTempFiles();
	exit(0);
}


void
RereadFile()
{
	reread_file();
}


void
LoadFile(str)
String str;
{
	FILE *f1, *f2;
	char tmp[500];
	struct stat stat_buf;

	str = ExpandFilename(str);
	XukcNewTextWidgetString(WI_filename_entry, str);

	/* check the type of file and ignore directories etc */
	if (stat(str, &stat_buf) < 0) {
		load_error(reason());
		return;
	}

	if (!(stat_buf.st_mode & S_IFREG)) {
		if (stat_buf.st_mode & S_IFDIR)
			(void)strcpy(tmp, "File is a directory");
		else
			(void)strcpy(tmp, "Illegal file type");
		load_error(tmp);
		return;
	}

	/* its a ".Z" compressed file so uncompress it into a tempfile */
	if (strcmp(str + strlen(str) - 2, ".Z") == 0) {
		String newstr;

		if ((newstr = UncompressFile(str)) == NULL) {
			(void)sprintf(tmp, "Cannot uncompress (%s)", reason());
			load_error(tmp);
			return;
		}
		str = newstr;
	}

	/* open two file descriptors .. one for scanning and one for reading
	 * from to dump to the page files.
	 */
	if ((f1 = fopen(str, "r")) == NULL) {
		load_error(reason());
		return;
	}
	if ((f2 = fopen(str, "r")) == NULL) {
		fprintf(stderr, "%s: cannot open \"%s\" (%s)\n", PROG_NAME,
			str, reason());
		exit(1);
	}

	if (fp != NULL) {
		(void)fclose(fp);
		(void)fclose(fd);
	}
	fp = f1;
	fd = f2;

	XtPopdown(WI_file_dialog_shell);
	XFlush(XtDisplay(WI_file_dialog_shell));

	if (current_file != NULL)
		XtFree(current_file);
	current_file = XtNewString(str);

	ResetFileList(str);

	/* start up the Ghostscript Interpreter and connect to it via pipes.
	 */
	StartGhostscript();
	change_count = 0;

	/* do scanning of file for %%Page: and other comments in the
	 * background when the first page is found it is automatically
	 * loaded and scanning continues.
	 */
	StartScanForPages(WI_ps_window, current_file, fp, fd);

	(void)sprintf(tmp, "(%s)", current_file);
	XtVaSetValues(WI_filename_label, XtNlabel, tmp, NULL);
}
