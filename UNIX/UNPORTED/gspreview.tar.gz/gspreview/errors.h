/* @(#)errors.h	1.2 (UKC) 28/4/92 */
/* List of error codes and more readable messages */

struct error_list {
	char *gs_name;
	char *error_message;
};

static struct error_list errors[] = {
	"/unknown", "Unknown error!",
	"/dictfull", "Dictionary Full",
	"/dictstackoverflow", "Dictionary Stack Overflow",
	"/dictstackunderflow", "Dictionary Stack Underflow",
	"/execstackoverflow", "Execution Stack Overflow",
	"/interrupt", "Interruption!",
	"/invalidaccess", "Invalid Access",
	"/invalidexit", "Invalid Exit",
	"/invalidfileaccess", "Invalid File Access",
	"/invalidfont", "Invalid Font",
	"/invalidrestore", "Invalid Restore",
	"/ioerror", "IO Error",
	"/limitcheck", "Limit Check",
	"/nocurrentpoint", "No Current Point",
	"/rangecheck", "Range Check",
	"/stackoverflow", "Stack Overflow",
	"/stackunderflow", "Stack Underflow",
	"/syntaxerror", "Syntax Error",
	"/timeout", "Timeout",
	"/typecheck", "Type Check",
	"/undefined", "Undefined Name in Operand",
	"/undefinedfilename", "Undefined Filename",
	"/undefinedresult", "Undefined Result",
	"/unmatchedmark", "Unmatched Mark",
	"/VMerror", "Virtual Memory Error"
};
