#define VERSION 1
#define PATCHLEVEL 6
#define FIX 1
