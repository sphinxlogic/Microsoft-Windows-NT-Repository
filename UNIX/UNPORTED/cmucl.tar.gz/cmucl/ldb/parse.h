/* $Header: parse.h,v 1.1 90/02/24 19:37:27 wlott Exp $ */

/* All parse routines take a char ** as their only argument */

boolean more_p();
char *parse_token();
lispobj parse_lispobj();
char *parse_addr();
long parse_number();
