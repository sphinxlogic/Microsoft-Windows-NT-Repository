/* $Header: print.h,v 1.1 90/02/24 19:37:30 wlott Exp $ */

extern char *lowtag_Names[], *subtype_Names[];

extern void print();
