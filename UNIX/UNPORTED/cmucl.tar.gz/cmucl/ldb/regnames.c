/* $Header: regnames.c,v 1.5 91/05/24 18:38:02 wlott Exp $ */

#include "lispregs.h"

char *lisp_register_names[] = { REGNAMES, 0 };
