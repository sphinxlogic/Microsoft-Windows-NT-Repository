/* $Header: alloc.h,v 1.1 90/02/24 19:37:11 wlott Exp $ */

lispobj alloc_cons(), alloc_string(), alloc_number();
