/* $Header: version.c,v 1.1 90/02/24 19:37:34 wlott Exp $ */
int version = VERSION;
