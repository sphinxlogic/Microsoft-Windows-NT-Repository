
#include <stdio.h>
#include <signal.h>
#ifndef SVR4
#include <strings.h>
#endif
#include <sys/time.h>

#ifndef	TRUE
#define	TRUE 	1
#endif

#ifndef	FALSE
#define	FALSE	0
#endif


#define CLUBS 		1
#define DIAMONDS	2
#define HEARTS		3
#define SPADES		4

#define MIN_RANK	1	/*  2  */
#define MAX_RANK	13	/* Ace */
#define MAX_SUIT	4	/* 1..4 */

#define	ROUND_WINDOW	1
#define	LEAD_WINDOW	2
#define INP_WINDOW	3
#define	TEXT_WINDOW	4
#define	PLAY_WINDOW	5
#define	SCORE_WINDOW	6
#define	MESG_WINDOW	7

