#include <stdio.h>
/*
 * Routines to send and receive on sockets.  Four bytes of length are
 * sent, followed by the null terminated string.
 *
 */
read_socket(s, buf)
int	s;			/* socket to talk on */
char	*buf;			/* string to send */
{
	int nbytes;
	int	partial, this;

	if (read(s, (char *) &nbytes, sizeof(int)) != sizeof (int))
	  return 0;
	nbytes = ntohl(nbytes);
	
	partial = 0;
	while (partial < nbytes) {
	  this = read(s, buf+partial, nbytes);
	  if (!this)
	    return 0;
	  partial = partial + this;
	}
	if (partial != nbytes)
	  return 0;
	else
	  return nbytes;
}


write_socket(s, buf)
int	s;			/* socket to talk on */
char	*buf;			/* string to read on */
{
	int nbytes, netnbytes;

	nbytes = strlen(buf) + 1;
	netnbytes = htonl(nbytes);
	(void) write(s, (char *) &netnbytes, sizeof(int));
	(void) write(s, buf, nbytes);
}
