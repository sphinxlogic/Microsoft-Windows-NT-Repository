/*
 * local.h
 *
 * Specify local configuration info
 *
 */

/* where the distributor, dealer and instructions live */

#define HEARTSLIB "/opt/lib/hearts"

/* If you can edit /etc/services, define PORT as 0, else
   define PORT as an unused internet port address (PORT = xxxx) */

#define PORT 5040

/* Dealer port numbers are handed out starting at DIST_PORT.
   Allocate a block of ports starting at DIST_PORT = xxxx. */

#define DIST_PORT 5041

/* Set to 1 if you want the Jack of Diamonds to be worth -10 */

#define MIKEYJ 1

/* If you're using X11R4, uncomment this for xawclient.c */

/* #define X11R4 */

/* This stuff for SVR4 without bcopy and bzero (Greg Lehey, LEMIS, 18 May 1993) */
#ifdef __svr4__
#define bcopy(s, d, l) memmove (d, s, l)
#define bzero(d, l) memset (d, 0, l)
#endif
