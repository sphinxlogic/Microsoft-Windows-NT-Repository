/*
 * nmtest.c -- this is the C code portion of tests for the GNU nm program
 */

main(argc, argv)
int argc;
char *argv[];
{
}

int
one ()
{

}

char
two ()
{
}
