long long c=2863311530LL,c3=2863311530LL*3;
main(){if(c*3!=c3)abort();exit(0);}
