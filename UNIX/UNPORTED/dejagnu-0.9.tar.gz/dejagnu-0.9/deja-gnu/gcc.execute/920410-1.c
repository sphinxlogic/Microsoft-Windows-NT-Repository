main(){int d[40000];d[0]=0;exit(0);}
