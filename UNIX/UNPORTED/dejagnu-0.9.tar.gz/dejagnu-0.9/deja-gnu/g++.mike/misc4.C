// Cfront bug A.2 (See Language System Release Notes for the
// SPARCompiler C++ version 3.0)

extern int f(int);
inline int f(int ii) { return ii; }	// ERROR - redeclaration 7.2 3.4
int ii = f(0);
int (*pf)(int) = &f;
