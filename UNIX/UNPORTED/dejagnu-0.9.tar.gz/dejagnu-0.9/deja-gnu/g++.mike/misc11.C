template<class T> class A;
void f () { A<int> *a; }
