void a(){}
void b(){return a();}
