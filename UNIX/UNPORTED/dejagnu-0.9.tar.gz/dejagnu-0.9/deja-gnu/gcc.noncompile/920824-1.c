struct s{struct s{int i;}x;};
