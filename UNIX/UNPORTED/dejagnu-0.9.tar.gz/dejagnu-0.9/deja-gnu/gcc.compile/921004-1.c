/* REPRODUCED:CC1:SIGNAL MACHINE:i386 OPTIONS: */
long long f()
{
long long*g,*s;
return*g+*s;
}
