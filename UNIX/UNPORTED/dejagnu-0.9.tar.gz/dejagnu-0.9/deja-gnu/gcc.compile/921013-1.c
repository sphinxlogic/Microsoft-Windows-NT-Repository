f(int x,short y)
{
long z=y<0?x>0?x:0:y;
}
