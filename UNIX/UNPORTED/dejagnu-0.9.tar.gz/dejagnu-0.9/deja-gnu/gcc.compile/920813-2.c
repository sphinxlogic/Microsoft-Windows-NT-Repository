static g();f(){return g();}
