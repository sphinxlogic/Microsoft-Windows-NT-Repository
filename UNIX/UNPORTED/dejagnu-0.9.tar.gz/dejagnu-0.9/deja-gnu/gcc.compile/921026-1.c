f(unsigned short*a)
{
a[0]=65535;
}
