x(c){1LL<<c;}
