void f(int,int);
void f(x,y)unsigned char x;unsigned short y;{}
