void
fun (nb)
     int nb;
{
  int th, h, em, nlwm, nlwS, nlw, sy;

  while (nb--)
    while (h--)
      {
	nlw = nlwm;
	while (nlw)
	  {
	    if (nlwS == 1)
	      {
	      }
	    else
	      if (nlwS == 1)
		{
		}
	    nlwS--; nlw--;
	  }
	if (em)
	  nlwS--;
	if (++sy == th)
	  sy = 0;
      }
}
