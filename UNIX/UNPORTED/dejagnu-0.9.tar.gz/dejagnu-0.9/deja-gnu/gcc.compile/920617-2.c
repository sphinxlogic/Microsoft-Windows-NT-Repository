f(a,b,c,d)float a[],d;int b[],c;{}
