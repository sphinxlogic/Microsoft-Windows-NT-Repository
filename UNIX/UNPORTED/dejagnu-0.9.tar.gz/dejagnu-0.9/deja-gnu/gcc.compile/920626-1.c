f(x)unsigned x;{return x>>-5;}
