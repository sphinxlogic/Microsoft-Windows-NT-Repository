x(y,z)float*y;{*y=z;}
