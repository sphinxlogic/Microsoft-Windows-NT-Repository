typedef unsigned short t;
struct foo{t d;};
int bar(d)t d;{struct foo u;u.d=d;return(int)(&u);}
