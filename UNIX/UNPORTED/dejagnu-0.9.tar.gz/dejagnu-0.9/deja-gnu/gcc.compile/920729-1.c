extern int i;extern volatile int i;
f(){int j;for(;;)j = i;}
