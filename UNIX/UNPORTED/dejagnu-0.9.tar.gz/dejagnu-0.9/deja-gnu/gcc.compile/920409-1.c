x(){int y;y>0.0?y:y-1;}
