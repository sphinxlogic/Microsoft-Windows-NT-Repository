f(){static void*t[]={&&x};x:;}
g(){static unsigned p[5];}
