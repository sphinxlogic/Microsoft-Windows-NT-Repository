f(n){struct z{int a,b[n],c[n];};}
