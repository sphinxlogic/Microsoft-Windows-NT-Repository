f(x,y){memcpy (&x,&y,8192);}
