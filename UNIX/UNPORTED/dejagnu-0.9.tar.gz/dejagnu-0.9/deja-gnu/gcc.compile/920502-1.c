extern void*t[];x(i){goto*t[i];}
