f(){short x=32000;}
