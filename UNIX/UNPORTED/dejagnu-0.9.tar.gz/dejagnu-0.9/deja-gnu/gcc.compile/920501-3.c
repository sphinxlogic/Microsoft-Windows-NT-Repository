struct{long long x:24,y:40;}v;
x(){v.y=0;}
