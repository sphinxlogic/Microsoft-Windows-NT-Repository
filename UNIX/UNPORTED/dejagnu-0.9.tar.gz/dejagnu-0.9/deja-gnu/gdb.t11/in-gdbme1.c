void
bar (x)
int x;
{
    printf ("%d\n", x);
}

static void
unused ()
{
    /* Not used for anything */
}
