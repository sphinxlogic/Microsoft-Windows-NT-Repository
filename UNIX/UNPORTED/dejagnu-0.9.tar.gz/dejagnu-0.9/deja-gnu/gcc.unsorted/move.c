typedef char type;

type
foo (b)
{
  type a;
  for (a = 10; a < b; a++)
    ;
}
