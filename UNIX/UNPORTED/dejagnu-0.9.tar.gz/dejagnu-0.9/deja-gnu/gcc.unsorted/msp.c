foo ()
{
  int a[16384];
  bar (a);
}
