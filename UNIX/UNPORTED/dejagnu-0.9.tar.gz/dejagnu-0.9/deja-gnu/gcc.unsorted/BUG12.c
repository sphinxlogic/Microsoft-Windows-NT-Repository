long long
main ()
{
  return 1.1e10;       
}
