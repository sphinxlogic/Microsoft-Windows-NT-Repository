foo (a, b, c, d)
{
  if (a < 0)
    {
      b = c;
    }
  else
    {
      b = d;
    }
  return b + 75;
}
