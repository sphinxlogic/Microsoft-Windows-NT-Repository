# 1 "imm.c"
void
imm (a)
     int *a;
{
 







}
