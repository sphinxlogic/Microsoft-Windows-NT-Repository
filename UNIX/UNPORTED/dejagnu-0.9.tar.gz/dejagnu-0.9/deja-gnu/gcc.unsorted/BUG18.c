main()
{
  if ((signed int) 1 < (signed int) -2147483648)
    printf("true\n");
}
