unsigned long long
main ()
{
  return (unsigned long long) 7816234 << 671111;
}
