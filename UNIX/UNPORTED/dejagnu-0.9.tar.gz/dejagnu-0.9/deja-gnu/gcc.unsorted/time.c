main ()
{
  int i;
  for (i = 3000000; --i;)
    {
    }
}
