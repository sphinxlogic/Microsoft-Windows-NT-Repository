foo (a, b)
     short a, b;
{
  return a < b;
}
