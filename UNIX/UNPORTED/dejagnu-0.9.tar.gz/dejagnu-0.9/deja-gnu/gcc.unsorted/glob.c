typedef int tt;

tt a1;
tt a2;
tt a3;

foo ()
{
  a1++;
  a2++;
  a1++;
}
