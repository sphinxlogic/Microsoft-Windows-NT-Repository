foo (a)
{
  return (a & ~0xfff) == 0;
}
