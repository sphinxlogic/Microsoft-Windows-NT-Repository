foo (a)
{
  int b = a;
  return b + 8762345;
}
