foo ()
{
  return (int)foo;
}
