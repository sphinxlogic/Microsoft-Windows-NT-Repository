main ()
{
  int i;

  for (i = 5000000; i >=0; i--)
    {
    }
}
