foo (a)
{
  ++a;
  return a == 0;
}
