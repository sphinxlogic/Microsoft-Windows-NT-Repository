foo (a, b)
{
  return ~(a ^ ~123);
}
