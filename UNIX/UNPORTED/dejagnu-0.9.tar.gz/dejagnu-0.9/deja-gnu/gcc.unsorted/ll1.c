long long
foo (long long a)
{
  return a + ((long long) 10230101 << 32) + 7561;
}
