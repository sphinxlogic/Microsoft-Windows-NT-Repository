main (int *p)
{
  int a;

  a = 0;
  p[1] = a;
  a = 0;
  p[2] = a;
  a = 123456;
  p[3] = a; 
}
