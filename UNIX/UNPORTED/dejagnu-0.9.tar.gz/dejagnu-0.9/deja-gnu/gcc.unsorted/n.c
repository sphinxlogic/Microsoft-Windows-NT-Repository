char_autoincr (b1, c)
    short *b1;
    short c;
{
  *b1 = c;
}
