int foo (unsigned short a, unsigned short b) { return a + b; }
