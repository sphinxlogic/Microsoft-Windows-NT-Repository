foo ()
{
  return *(short *) 126;
}
