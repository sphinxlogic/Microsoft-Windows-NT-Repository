double
foo ()
{
  return 3.141592653589793238462643;
}
