typedef unsigned long long ULL;
ULL back;
ULL hpart, lpart;
ULL
build(int h, int l)
{
  hpart = h;
  hpart <<= 32;
  lpart = l;
  lpart &= 0xFFFFFFFFLL;	/* HERE */
  back = hpart | lpart;
  return back;
}

doit(int h, int l)
{
  ULL x; int *p;
  x = build(h, l);
  p = (int *)&x;
  printf("0x%08x 0x%08x\n", p[0], p[1]);
}

main()
{
  doit(0, 1); doit(0, 0); doit(0, -1); doit(0, -2);
}
