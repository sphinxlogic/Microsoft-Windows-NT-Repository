int
foo (a)
{
  return foo (a - 1) * a;
}
