double
foo (float a, float b) { return (double) a * (double) b; }
