foo (int *p)
{
  *p = (unsigned short) *p;
}
