foo (a)
{
  return a;
}
