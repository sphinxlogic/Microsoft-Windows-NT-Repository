foo (double *p)
{
  p[0] = p[1];
}
