main (a)
{
  return - 256 + a ;
}
