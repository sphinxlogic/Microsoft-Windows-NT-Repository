foo (a)
     double a;
{
  return -a;
}
