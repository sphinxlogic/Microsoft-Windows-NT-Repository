long long
foo (a, b)
     long long a, b;
{
  return a * b;
}
