foo (a, b)
{
  return a >> (char) b;
}
