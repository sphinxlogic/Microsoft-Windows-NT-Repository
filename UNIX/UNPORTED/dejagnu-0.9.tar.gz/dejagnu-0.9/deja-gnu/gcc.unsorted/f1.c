double
foo ()
{
  return 1.2587624368724;
}
