foo (a, p)
     int *p;
{
  *p = a > 0;
}
