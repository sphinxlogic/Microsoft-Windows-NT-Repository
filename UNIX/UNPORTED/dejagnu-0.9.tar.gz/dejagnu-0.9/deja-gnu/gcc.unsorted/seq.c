foo (a)
{
  return a < 0;
}
