main (a)
{
  return a + (~0 - 240);
}
