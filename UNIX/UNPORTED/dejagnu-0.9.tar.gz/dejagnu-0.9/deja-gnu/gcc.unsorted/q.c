
unsigned
reg0indreg1 (r0, p1)
     unsigned short  r0;  unsigned short p1;
{
  return (r0 + p1);
}
