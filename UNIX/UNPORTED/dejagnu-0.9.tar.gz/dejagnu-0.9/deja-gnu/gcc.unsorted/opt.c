int
foo (a)
{
  return (a == 2);
}
