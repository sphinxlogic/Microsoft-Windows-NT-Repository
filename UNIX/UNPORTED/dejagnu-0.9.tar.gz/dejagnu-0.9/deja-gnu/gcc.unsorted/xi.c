foo (a)
{
  int r = 0;
  if (a)
    r = 1;
  return r;
}
