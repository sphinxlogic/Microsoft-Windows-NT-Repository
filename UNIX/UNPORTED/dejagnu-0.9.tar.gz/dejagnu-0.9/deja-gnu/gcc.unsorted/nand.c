nadn (a, b)
{
  return (~a) | (~b);
}
