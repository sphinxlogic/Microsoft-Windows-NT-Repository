enum tree_code {
  ERROR_MARK,
  IDENTIFIER_NODE,
  OP_IDENTIFIER,
  TREE_LIST,
  VOID_TYPE, 
  INTEGER_TYPE,
  REAL_TYPE,
  COMPLEX_TYPE,
  ENUMERAL_TYPE,
  BOOLEAN_TYPE,
  CHAR_TYPE,
  POINTER_TYPE,
  OFFSET_TYPE,
  REFERENCE_TYPE,
  METHOD_TYPE,
  FILE_TYPE,
  ARRAY_TYPE,
  SET_TYPE,
  STRING_TYPE,
  RECORD_TYPE,
  UNION_TYPE, 
  FUNCTION_TYPE,
  LANG_TYPE,
  LABEL_STMT,
  GOTO_STMT,
  RETURN_STMT,
  EXPR_STMT,
  WITH_STMT,
  LET_STMT,
  IF_STMT,
  EXIT_STMT,
  CASE_STMT,
  LOOP_STMT,
  COMPOUND_STMT,
  ASM_STMT,
  INTEGER_CST,
  REAL_CST,
  COMPLEX_CST,
  STRING_CST,
  FUNCTION_DECL,
  LABEL_DECL,
  CONST_DECL,
  TYPE_DECL,
  VAR_DECL,
  PARM_DECL,
  RESULT_DECL,
  FIELD_DECL,
  COMPONENT_REF,
  INDIRECT_REF,
  OFFSET_REF,
  BUFFER_REF,
  ARRAY_REF,
  CONSTRUCTOR,
  COMPOUND_EXPR,
  MODIFY_EXPR,
  INIT_EXPR,
  NEW_EXPR,
  DELETE_EXPR,
  PUSH_EXPR,
  POP_EXPR,
  COND_EXPR,
  CALL_EXPR,
  METHOD_CALL_EXPR,
  WITH_CLEANUP_EXPR,
  PLUS_EXPR,
  MINUS_EXPR,
  MULT_EXPR,
  TRUNC_DIV_EXPR,
  CEIL_DIV_EXPR,
  FLOOR_DIV_EXPR,
  ROUND_DIV_EXPR,
  TRUNC_MOD_EXPR,
  CEIL_MOD_EXPR,
  FLOOR_MOD_EXPR,
  ROUND_MOD_EXPR,
  RDIV_EXPR,
  EXACT_DIV_EXPR,
  FIX_TRUNC_EXPR,
  FIX_CEIL_EXPR,
  FIX_FLOOR_EXPR,
  FIX_ROUND_EXPR,
  FLOAT_EXPR,
  EXPON_EXPR,
  NEGATE_EXPR,
  MIN_EXPR,
  MAX_EXPR,
  ABS_EXPR,
  FFS_EXPR,
  LSHIFT_EXPR,
  RSHIFT_EXPR,
  LROTATE_EXPR,
  RROTATE_EXPR,
  BIT_IOR_EXPR,
  BIT_XOR_EXPR,
  BIT_AND_EXPR,
  BIT_ANDTC_EXPR,
  BIT_NOT_EXPR,
  TRUTH_ANDIF_EXPR,
  TRUTH_ORIF_EXPR,
  TRUTH_AND_EXPR,
  TRUTH_OR_EXPR,
  TRUTH_NOT_EXPR,
  LT_EXPR,
  LE_EXPR,
  GT_EXPR,
  GE_EXPR,
  EQ_EXPR,
  NE_EXPR,
  IN_EXPR,
  SET_LE_EXPR,
  CARD_EXPR,
  RANGE_EXPR,
  CONVERT_EXPR,
  NOP_EXPR,
  SAVE_EXPR,
  RTL_EXPR,
  ADDR_EXPR,
  REFERENCE_EXPR,
  WRAPPER_EXPR,
  ANTI_WRAPPER_EXPR,
  ENTRY_VALUE_EXPR,
  COMPLEX_EXPR,
  CONJ_EXPR,
  REALPART_EXPR,
  IMAGPART_EXPR,
  PREDECREMENT_EXPR,
  PREINCREMENT_EXPR,
  POSTDECREMENT_EXPR,
  POSTINCREMENT_EXPR,
  LAST_AND_UNUSED_TREE_CODE
};
extern char *tree_code_type[];
extern int tree_code_length[];
enum machine_mode {
 VOIDmode,
 QImode, 
 HImode,
 PSImode,
 SImode,
 PDImode,
 DImode,
 TImode,
 QFmode,
 HFmode, 
 SFmode,
 DFmode,
 XFmode,
 TFmode,
 CQImode,
 CHImode,
 CSImode,
 CDImode,
 CTImode,
 CQFmode,
 CHFmode,
 CSFmode,
 CDFmode,
 CXFmode,
 CTFmode,
 BImode, 
 BLKmode,
 EPmode,
MAX_MACHINE_MODE };
enum built_in_function
{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_FSQRT,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,
};
typedef union tree_node *tree;
struct tree_common
{
  int uid;
  union tree_node *chain;
  union tree_node *type;
  unsigned char code : 8;
  unsigned external_attr : 1;
  unsigned public_attr : 1;
  unsigned static_attr : 1;
  unsigned volatile_attr : 1;
  unsigned packed_attr : 1;
  unsigned readonly_attr : 1;
  unsigned literal_attr : 1;
  unsigned nonlocal_attr : 1;
  unsigned permanent_attr : 1;
  unsigned addressable_attr : 1;
  unsigned regdecl_attr : 1;
  unsigned this_vol_attr : 1;
  unsigned unsigned_attr : 1;
  unsigned asm_written_attr: 1;
  unsigned inline_attr : 1;
  unsigned used_attr : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
};
struct tree_int_cst
{
  char common[sizeof (struct tree_common)];
  long int_cst_low;
  long int_cst_high;
};
extern double ldexp ();
extern double atof ();
union real_extract
{
  double  d;
  int i[sizeof (double ) / sizeof (int)];
};
double  real_value_from_int_cst ();
struct tree_real_cst
{
  char common[sizeof (struct tree_common)];
  struct rtx_def *rtl;
  double  real_cst;
};
struct tree_string
{
  char common[sizeof (struct tree_common)];
  struct rtx_def *rtl;
  int length;
  char *pointer;
};
struct tree_complex
{
  char common[sizeof (struct tree_common)];
  struct rtx_def *rtl;
  union tree_node *real;
  union tree_node *imag;
};
struct tree_identifier
{
  char common[sizeof (struct tree_common)];
  int length;
  char *pointer;
};
struct tree_list
{
  char common[sizeof (struct tree_common)];
  union tree_node *purpose;
  union tree_node *value;
};
struct tree_exp
{
  char common[sizeof (struct tree_common)];
  int complexity;
  union tree_node *operands[1];
};
struct tree_type
{
  char common[sizeof (struct tree_common)];
  union tree_node *values;
  union tree_node *sep;
  union tree_node *size;
  enum machine_mode mode : 8;
  unsigned char size_unit;
  unsigned char align;
  unsigned char sep_unit;
  union tree_node *pointer_to;
  union tree_node *reference_to;
  int parse_info;
  int symtab_address;
  union tree_node *name;
  union tree_node *max;
  union tree_node *next_variant;
  union tree_node *main_variant;
  union tree_node *basetypes;
  union tree_node *noncopied_parts;
  struct lang_type *lang_specific;
};
struct tree_decl
{
  char common[sizeof (struct tree_common)];
  char *filename;
  int linenum;
  union tree_node *size;
  enum machine_mode mode : 8;
  unsigned char size_unit;
  unsigned char align;
  unsigned char voffset_unit;
  union tree_node *name;
  union tree_node *context;
  int offset;
  union tree_node *voffset;
  union tree_node *arguments;
  union tree_node *result;
  union tree_node *initial;
  char *print_name;
  char *assembler_name;
  struct rtx_def *rtl;
  int frame_size;
  struct rtx_def *saved_insns;
  int block_symtab_address;
  struct lang_decl *lang_specific;
};
struct tree_stmt
{
  char common[sizeof (struct tree_common)];
  char *filename;
  int linenum;
  union tree_node *body;
};
struct tree_if_stmt
{
  char common[sizeof (struct tree_common)];
  char *filename;
  int linenum;
  union tree_node *cond, *thenpart, *elsepart;
};
struct tree_bind_stmt
{
  char common[sizeof (struct tree_common)];
  char *filename;
  int linenum;
  union tree_node *body, *vars, *supercontext, *bind_size, *type_tags;
  union tree_node *subblocks;
};
struct tree_case_stmt
{
  char common[sizeof (struct tree_common)];
  char *filename;
  int linenum;
  union tree_node *index, *case_list;
};
union tree_node
{
  struct tree_common common;
  struct tree_int_cst int_cst;
  struct tree_real_cst real_cst;
  struct tree_string string;
  struct tree_complex complex;
  struct tree_identifier identifier;
  struct tree_decl decl;
  struct tree_type type;
  struct tree_list list;
  struct tree_exp exp;
  struct tree_stmt stmt;
  struct tree_if_stmt if_stmt;
  struct tree_bind_stmt bind_stmt;
  struct tree_case_stmt case_stmt;
};

extern char *oballoc ();
extern char *permalloc ();
extern tree make_node ();
extern tree copy_node ();
extern tree copy_list ();
extern tree get_identifier ();
extern tree build_int_2 ();
extern tree build_real ();
extern tree build_real_from_string ();
extern tree build_real_from_int_cst ();
extern tree build_complex ();
extern tree build_string ();
extern tree build ();
extern tree build_nt ();
extern tree build_tree_list ();
extern tree build_op_identifier ();
extern tree build_decl ();
extern tree build_let ();
extern tree make_signed_type ();
extern tree make_unsigned_type ();
extern void fixup_unsigned_type ();
extern tree build_pointer_type ();
extern tree build_reference_type ();
extern tree build_index_type ();
extern tree build_array_type ();
extern tree build_function_type ();
extern tree build_method_type ();
extern tree build_offset_type ();
extern tree array_type_nelts ();
extern tree build_binary_op ();
extern tree build_indirect_ref ();
extern tree build_unary_op ();
extern tree build_type_variant ();
extern void layout_type ();
extern tree type_hash_canon ();
extern void layout_decl ();
extern tree fold ();
extern tree combine ();
extern tree convert ();
extern tree convert_units ();
extern tree size_in_bytes ();
extern tree genop ();
extern tree build_int ();
extern tree get_pending_sizes ();
extern tree sizetype;
extern tree chainon ();
extern tree tree_cons (), perm_tree_cons (), temp_tree_cons ();
extern tree saveable_tree_cons ();
extern tree tree_last ();
extern tree nreverse ();
extern int list_length ();
extern int integer_zerop ();
extern int integer_onep ();
extern int integer_all_onesp ();
extern int type_unsigned_p ();
extern int staticp ();
extern int lvalue_or_else ();
extern tree save_expr ();
extern tree stabilize_reference ();
extern tree get_unwidened ();
extern tree get_narrower ();
extern tree type_for_size ();
extern tree unsigned_type ();
extern tree signed_type ();
extern tree get_floating_type ();
extern char *function_cannot_inline_p ();

extern tree integer_zero_node;
extern tree integer_one_node;
extern tree size_zero_node;
extern tree size_one_node;
extern tree null_pointer_node;
extern tree error_mark_node;
extern tree void_type_node;
extern tree integer_type_node;
extern tree unsigned_type_node;
extern tree char_type_node;
extern char *input_filename;
extern int lineno;
extern int pedantic;
extern int immediate_size_expand;
extern tree current_function_decl;
extern int current_function_calls_setjmp;
extern int all_types_permanent;

extern tree expand_start_stmt_expr ();
extern tree expand_end_stmt_expr ();
extern void expand_expr_stmt (), clear_last_expr ();
extern void expand_label (), expand_goto (), expand_asm ();
extern void expand_start_cond (), expand_end_cond ();
extern void expand_start_else (), expand_end_else ();
extern void expand_start_loop (), expand_start_loop_continue_elsewhere ();
extern void expand_loop_continue_here ();
extern void expand_end_loop ();
extern int expand_continue_loop ();
extern int expand_exit_loop (), expand_exit_loop_if_false ();
extern int expand_exit_something ();
extern void expand_start_delayed_expr ();
extern tree expand_end_delayed_expr ();
extern void expand_emit_delayed_expr ();
extern void expand_null_return (), expand_return ();
extern void expand_start_bindings (), expand_end_bindings ();
extern void expand_start_case (), expand_end_case ();
extern int pushcase (), pushcase_range ();
extern void expand_start_function (), expand_end_function ();
extern char *input_filename;
extern char *main_input_filename;
extern int lineno;
struct file_stack
  {
    char *name;
    struct file_stack *next;
    int line;
  };
extern struct file_stack *input_file_stack;
extern int input_file_stack_tick;
enum rid
{
  RID_UNUSED,
  RID_INT,
  RID_CHAR,
  RID_FLOAT,
  RID_DOUBLE,
  RID_VOID,
  RID_UNUSED1,
  RID_UNSIGNED,
  RID_SHORT,
  RID_LONG,
  RID_AUTO,
  RID_STATIC,
  RID_EXTERN,
  RID_REGISTER,
  RID_TYPEDEF,
  RID_SIGNED,
  RID_CONST,
  RID_VOLATILE,
  RID_INLINE,
  RID_NOALIAS,
  RID_MAX,
};
struct lang_identifier
{
  struct tree_identifier ignore;
  tree global_value, local_value, label_value, implicit_decl;
  tree error_locus;
};
extern int pedantic;
extern tree build_component_ref(), build_conditional_expr(), build_compound_expr();
extern tree build_unary_op(), build_binary_op(), build_function_call();
extern tree build_binary_op_nodefault ();
extern tree build_indirect_ref(), build_array_ref(), build_c_cast();
extern tree build_modify_expr();
extern tree c_sizeof (), c_alignof ();
extern void store_init_value ();
extern tree digest_init ();
extern tree c_expand_start_case ();
extern tree default_conversion ();
extern tree commontype ();
extern tree build_label ();
extern int start_function ();
extern void finish_function ();
extern void store_parm_decls ();
extern tree get_parm_info ();
extern void pushlevel ();
extern tree poplevel ();
extern tree groktypename(), lookup_name();
extern tree lookup_label(), define_label();
extern tree implicitly_declare(), getdecls(), gettags ();
extern tree start_decl();
extern void finish_decl();
extern tree start_struct(), finish_struct(), xref_tag();
extern tree grokfield();
extern tree start_enum(), finish_enum();
extern tree build_enumerator();
extern tree make_index_type ();
extern tree double_type_node, long_double_type_node, float_type_node;
extern tree char_type_node, unsigned_char_type_node, signed_char_type_node;
extern tree short_integer_type_node, short_unsigned_type_node;
extern tree long_integer_type_node, long_unsigned_type_node;
extern tree long_long_integer_type_node, long_long_unsigned_type_node;
extern tree unsigned_type_node;
extern tree string_type_node, char_array_type_node, int_array_type_node;
extern int current_function_returns_value;
extern int current_function_returns_null;
extern tree ridpointers[];
extern int dollars_in_ident;
extern int flag_cond_mismatch;
extern int flag_no_asm;
extern int warn_implicit;
extern int warn_return_type;
extern int warn_write_strings;
extern int warn_pointer_arith;
extern int warn_strict_prototypes;
extern int warn_cast_qual;
extern int flag_traditional;
extern	struct	_iobuf {
	int	_cnt;
	char	*_ptr;
	char	*_base;
	int	_bufsiz;
	short	_flag;
	char	_file;
} _iob[20 ];
struct _iobuf 	*fopen();
struct _iobuf 	*fdopen();
struct _iobuf 	*freopen();
long	ftell();
char	*gets();
char	*fgets();
char	*sprintf();
extern int errno;
extern int errno;
void yyerror ();
typedef union {long itype; tree ttype; enum tree_code code; } YYSTYPE;
static tree lastiddecl;
static tree make_pointer_declarator ();
static tree combine_strings ();
static void reinit_parse_for_function ();
tree current_declspecs;
tree declspec_stack;
int undeclared_variable_notice;
static int yylex ();
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;
int	yychar;
YYSTYPE	yylval;
yyltype  yylloc;
int yynerrs;
int yydebug;
int lineno;
struct _iobuf  *finput;
static int maxtoken;
static char *token_buffer;
static int max_wide;
static int *wide_buffer;
static int end_of_file;
struct resword { char *name; short token; enum rid rid; };
inline
static int
hash (str, len)
     register char *str;
     register int len;
{
  static int hash_table[] =
    {
     91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
     91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
     91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
     91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
     91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
     91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
     91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
     91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
     91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
     91, 91, 91, 91, 91,  1, 91,  2,  1, 32,
      7,  5, 18, 20,  1, 17, 91,  1, 18,  1,
     28,  1, 23, 91, 12, 20,  1, 41,  7, 15,
     91, 91, 10, 91, 91, 91, 91, 91,
    };
  register int hval = len ;
  switch (hval)
    {
      default:
      case 3:
        hval += hash_table[str[2]];
      case 2:
      case 1:
        return hval + hash_table[str[0]] + hash_table[str[len - 1]];
    }
}
inline
struct resword *
is_reserved_word (str, len)
     register char *str;
     register int len;
{
  static struct resword reswords[] =
    {
      { "", }, { "", }, { "", }, { "", }, { "", }, { "", }, { "", },
      {"asm",  282 , RID_UNUSED  },
      {"auto",  260 , RID_AUTO },
      {"__asm",  282 , RID_UNUSED  },
      {"do",  273 , RID_UNUSED  },
      {"__asm__",  282 , RID_UNUSED  },
      {"break",  278 , RID_UNUSED  },
      {"__typeof__",  283 , RID_UNUSED  },
      { "", },
      {"__alignof__",  284 , RID_UNUSED  },
      { "", },
      {"__attribute__",  285 , RID_UNUSED  },
      { "", },
      {"__attribute",  285 , RID_UNUSED  },
      { "", },
      {"__volatile__",  262 , RID_VOLATILE },
      {"int",  261 , RID_INT },
      {"__volatile",  262 , RID_VOLATILE },
      { "", },
      {"float",  261 , RID_FLOAT },
      {"goto",  281 , RID_UNUSED  },
      {"short",  261 , RID_SHORT },
      {"__typeof",  283 , RID_UNUSED  },
      {"__inline__",  260 , RID_INLINE },
      {"__alignof",  284 , RID_UNUSED  },
      {"__inline",  260 , RID_INLINE },
      {"__signed__",  261 , RID_SIGNED },
      {"default",  277 , RID_UNUSED  },
      {"else",  271 , RID_UNUSED  },
      {"void",  261 , RID_VOID },
      {"__signed",  261 , RID_SIGNED },
      {"if",  270 , RID_UNUSED  },
      {"volatile",  262 , RID_VOLATILE },
      {"struct",  268 , RID_UNUSED  },
      {"extern",  260 , RID_EXTERN },
      {"__const",  262 , RID_CONST },
      {"while",  272 , RID_UNUSED  },
      {"__const__",  262 , RID_CONST },
      {"switch",  275 , RID_UNUSED  },
      {"for",  274 , RID_UNUSED  },
      {"inline",  260 , RID_INLINE },
      {"return",  280 , RID_UNUSED  },
      {"typeof",  283 , RID_UNUSED  },
      {"typedef",  260 , RID_TYPEDEF },
      {"char",  261 , RID_CHAR },
      {"enum",  267 , RID_UNUSED  },
      {"register",  260 , RID_REGISTER },
      {"signed",  261 , RID_SIGNED },
      {"sizeof",  266 , RID_UNUSED  },
      { "", }, { "", }, { "", }, { "", },
      {"double",  261 , RID_DOUBLE },
      {"static",  260 , RID_STATIC },
      {"case",  276 , RID_UNUSED  },
      { "", }, { "", }, { "", }, { "", },
      {"const",  262 , RID_CONST },
      { "", }, { "", }, { "", },
      {"long",  261 , RID_LONG },
      { "", }, { "", },
      {"continue",  279 , RID_UNUSED  },
      { "", }, { "", },
      {"unsigned",  261 , RID_UNSIGNED },
      { "", }, { "", }, { "", }, { "", }, { "", }, { "", }, { "", }, { "", }, { "", },
      { "", }, { "", }, { "", }, { "", }, { "", },
      {"union",  269 , RID_UNUSED  },
    };
  if (len <=     13      && len >=     2      )
    {
      register int key = hash (str, len);
      if (key <=      91     )
        {
          register char *s = reswords[key].name;
          if (*s == *str && !strcmp (str + 1, s + 1))
            return &reswords[key];
        }
    }
  return 0;
}
tree ridpointers[(int) RID_MAX];

void
init_lex ()
{
}
static void
reinit_parse_for_function ()
{
}
static int
skip_white_space (c)
     register int c;
{
}
static char *
extend_token_buffer (p)
     char *p;
{
}
static int
readescape ()
{
}

void
yyerror (string)
     char *string;
{
}
static int nextchar = -1;
static int
yylex ()
{
  register char *p;
  register int value;
  register struct resword *ptr;
  p = token_buffer;

  if (ptr = is_reserved_word (token_buffer, p - token_buffer))
    {
      return 1;
    }
  return value;
}
