int
isinf ()
{
  return 0;
}
