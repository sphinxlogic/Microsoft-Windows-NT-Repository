foo (a, b)
{
  return a % (1 << b);
}
