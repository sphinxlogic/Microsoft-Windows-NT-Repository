main (a)
{
  return a + 128;
}
