foo (a)
{
  return a * 84;
}
