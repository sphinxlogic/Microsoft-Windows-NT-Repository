foo (a) {return -a;}
