lop (a)
{
  do
    a--;
  while (a >= -1);
}
