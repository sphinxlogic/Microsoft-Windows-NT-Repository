foo (a)
{
  return a & 255;
}
