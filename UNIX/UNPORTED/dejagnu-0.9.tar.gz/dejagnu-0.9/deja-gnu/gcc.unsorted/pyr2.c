foo (a)
{
  return ((int *)0)[a];
}
