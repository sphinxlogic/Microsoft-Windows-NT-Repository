foo ()
{
  return (int) &foo;
}
