foo (a, b, p)
     int *p;
{
  return 34 + *p;
}
