foo (a, b)
{
  a = b + b;
  if (a)
    return a;
  return b;
}
