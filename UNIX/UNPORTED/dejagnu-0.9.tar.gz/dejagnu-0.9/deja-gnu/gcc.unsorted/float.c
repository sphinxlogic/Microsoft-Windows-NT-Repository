double
foo (a, b, c)
     double a, b, c;
{
  return a * b + c * a;
}
