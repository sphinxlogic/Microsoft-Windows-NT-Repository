int
foo ()
{
  return 7561;
}
