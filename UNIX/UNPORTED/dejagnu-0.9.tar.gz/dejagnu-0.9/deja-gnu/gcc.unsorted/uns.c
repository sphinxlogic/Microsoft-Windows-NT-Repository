foo (a)
{
  if ((unsigned) a < 234)
    return 1;
}
     
