foo (double a)
{
  return (a != 0);
}
