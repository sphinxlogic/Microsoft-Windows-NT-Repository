/* AE program profiling system.
   Names for schema commands:
   Copyright (C) 1989, 1990 by James R. Larus (larus@cs.wisc.edu)

   AE and AEC are free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 1, or (at your option) any
   later version.

   AE and AEC are distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with GNU CC; see the file COPYING.  If not, write to James R.
   Larus, Computer Sciences Department, University of Wisconsin--Madison,
   1210 West Dayton Street, Madison, WI 53706, USA or to the Free
   Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA. */


/* $Header: /var/home/larus/AE/AE/RCS/schema.h,v 2.0 90/02/09 17:20:49 larus Exp Locker: larus $ */


#define FUNCTION_START "start_function"
#define FUNCTION_END "end_function"

#define BLOCK_START "start_block"
#define BLOCK_START_TARGET "start_block_target"

#define BLOCK_END "end_block"
#define BLOCK_END_NEXT_TARGET "end_block_next_target"

#define BLOCK_END_JUMP "end_block_jump"
#define BLOCK_END_JUMP_NEXT_TARGET "end_block_jump_next_target"

#define BLOCK_END_CJUMP "end_block_cjump"

#define LOOP_BEGIN "begin_loop"
#define LOOP_CONT "continue_loop"
#define LOOP_END "end_loop"

#define UNEVENTFUL_INST "uneventful_inst"

#define STORE_INST "store_inst"
#define STORE_D_INST "store_d_inst"
#define STORE_UNKNOWN_INST "store_unknown_inst"

#define LOAD_INST "load_inst"
#define LOAD_D_INST "load_d_inst"
#define LOAD_UNKNOWN_INST "load_unknown_inst"

#define COMPUTE_DEFN_ "compute_defn_"
#define COMPUTE_DEFN_0 "compute_defn_0"
#define COMPUTE_DEFN_1 "compute_defn_1"
#define COMPUTE_DEFN_2 "compute_defn_2"
#define UNKNOWN_DEFN "unknown_defn"

#define CALL_INST "call_inst"
#define DCALL_INST "dcall_inst"
#define CALL_INDIRECT_INST "call_indirect_inst"
#define DCALL_INDIRECT_INST "dcall_indirect_inst"

#define LOOP_ENTRY "%loop_entry"
#define LOOP_BACK "%loop_back"
#define LOOP_EXIT "%loop_exit"
