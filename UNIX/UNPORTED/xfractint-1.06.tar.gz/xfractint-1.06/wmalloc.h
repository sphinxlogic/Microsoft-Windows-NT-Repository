#ifndef _WMALLOC_H
#define _WMALLOC_H
#include <sys/types.h>

#if defined(__STDC__) && ! defined (Ptr) /* ansi C */
# define Void void
# define Ptr Void *
/* in dem Fall gar nichts da der ANSI-standard kein return bei void erwartet */
# define Vreturn return
#endif				/* __STDC__ */

#if ! defined(__STDC__) && ! defined (Ptr) /* k&r */
/* in diesem Falle 0 da der K&R-standard voreingestellt int benutzt */
# define Void /* H3 */
# define Ptr char *
# define Vreturn return(0)
# ifndef const
#  define const
# endif /* const */
# ifndef volatile
#  define volatile
# endif /* volatile */
#endif				/* ! __STDC__ */

#if ! defined(_SIZE_T)
# define _SIZE_T
  typedef unsigned int size_t;
#endif				/* _SIZE_T */

#if ! defined(NULL)
# define NULL  0
#endif				/* NULL */

/* WYM  malloc Paket */
extern Ptr      wmalloc(size_t);
extern Ptr      wrealloc(Ptr, size_t);
extern Ptr      wfree(Ptr);
/* debug GDB malloc Paket */
extern Ptr      mmalloc(Ptr, size_t);
extern Ptr      mrealloc(Ptr, Ptr, size_t);
extern Void     mfree(Ptr, size_t);

#endif				/* _WMALLOC_H */
