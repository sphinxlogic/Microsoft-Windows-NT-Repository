#include "fractint.h"

extern long ltempsqrx,ltempsqry;
extern long lmagnitud, llimit, llimit2, lclosenuff, l16triglim;
extern int overflow, bitshift;
extern struct lcomplex lold, lnew;

longbailout()
{
    ltempsqrx = lsqr(lnew.x); ltempsqry = lsqr(lnew.y);
    lmagnitud = ltempsqrx + ltempsqry;
    if (lmagnitud >= llimit || lmagnitud < 0 || labs(lnew.x) > llimit2
	|| labs(lnew.y) > llimit2 || overflow)
	    { overflow=0;
	    return(1); }
    lold = lnew;
    return(0);
}

FManOWarfpFractal() {}
FJuliafpFractal() {}
FBarnsley1FPFractal() {}
FBarnsley2FPFractal() {}
FLambdaFPFractal() {}
