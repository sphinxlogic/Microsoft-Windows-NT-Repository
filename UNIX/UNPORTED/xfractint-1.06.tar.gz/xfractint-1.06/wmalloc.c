#include "wmalloc.h"
#include <stdio.h>
#if defined(__STDC__)
#if defined(__STRICT_ANSI__) || ! defined(__m68k__)
#include <stdlib.h>
#endif /*(__STRICT_ANSI__) || ! defined(__m68k__) */
#if ! defined(__m68k__)
#include <malloc.h>
#endif /* __m68k__ */
#else
#include <malloc.h>
#endif /* __STDC__ */
#if defined(__svr4__) || defined(i386)
#include <memory.h>
#include <string.h>
#endif

Void wnospace (Void); 
Void wnospace ()
{
	exit(99);
}

Ptr
wrealloc(Ptr ptr, size_t size)
{
	Ptr             p;
	if ((int) ptr) {
#if defined(__MMALLOC__)
		p = (Ptr) mrealloc((Ptr) NULL, (Ptr) ptr, size);
#else
		p = (Ptr) realloc((Ptr) ptr, size);
#endif				/* __MMALLOC__ */
	} else {
#if defined(__MMALLOC__)
		if ((int) (p = (Ptr) mmalloc((Ptr) NULL, size))) {
#else
		if ((int) (p = (Ptr) malloc(size))) {
#endif				/* __MMALLOC__ */
			memset((Ptr) p, '\0', size);
		}
	}
	if (!(int) p)
		wnospace();
	return ((Ptr) p);
}

Ptr
wmalloc(size_t size)
{

#ifndef MIN_LIMIT
#define MIN_LIMIT 32
#endif

	Ptr             p;
	if (size < MIN_LIMIT) size =(size_t) MIN_LIMIT;
#if defined(__MMALLOC__)
	if (!(int) (p = (Ptr) mmalloc((Ptr) NULL, size))) {
#else
	if (!(int) (p = (Ptr) malloc(size))) {
#endif				/* __MMALLOC__ */
		wnospace();
		return ((Ptr) NULL);
	} else {
		memset((Ptr) p, '\0', size);
		return ((Ptr) p);
	}
}


Ptr
wfree(Ptr p)
{
	if ((int) p) {
#if defined(__MMALLOC__)
		mfree((Ptr) NULL, (Ptr) p);
#else
		free((Ptr) p);
#endif				/* __MMALLOC__ */
	}
	return ((Ptr) NULL);
}
