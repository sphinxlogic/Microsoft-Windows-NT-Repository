#include <stdio.h>
#include <stdlib.h>
#include "fractint.h"
#include "mpmath.h"
#include "helpdefs.h"
#include "prototyp.h"

extern int row, col, xdots, ydots, bitshift, fractype;
extern int ixstart, ixstop, iystart, iystop, colors, helpmode;
extern double param[], xxmin, xxmax, yymin, yymax;
extern long delx, dely, ltempsqrx, ltempsqry,  *lx0,  *ly0;
extern double tempsqrx, tempsqry;
extern struct lcomplex lold, lnew, *longparm;
extern struct complex old, new, *floatparm;
extern llimit2;
static int bbase;
static long xpixel, ypixel;
static double xpixelfp, ypixelfp;
static long initz, djx, djy, dmx, dmy;
static double initzfp, djxfp, djyfp, dmxfp, dmyfp;
static long jx, jy, mx, my, xoffset, yoffset;
static double jxfp, jyfp, mxfp, myfp, xoffsetfp, yoffsetfp;
static long jxmin, jxmax, jymin, jymax, mxmin, mxmax, mymin, mymax;
static double jxminfp, jxmaxfp, jyminfp, jymaxfp, mxminfp, mxmaxfp, myminfp,
	mymaxfp;
static long x_per_inch, y_per_inch, inch_per_xdot, inch_per_ydot;
static double x_per_inchfp, y_per_inchfp, inch_per_xdotfp, inch_per_ydotfp;
struct Perspective {
   long x, y, zx, zy;
};

struct Perspectivefp {
   double x, y, zx, zy;
};

struct Perspective LeftEye, RightEye, *Per;
struct Perspectivefp LeftEyefp, RightEyefp, *Perfp;
struct lcomplex jbc;
struct complex jbcfp;

static char StereoFile[] = "glasses1.map";
static char GreyFile[] = "altern.map";

#define NUM_VAR 17

static char  v0[] = {"Julia from x"};
static char  v1[] = {"Julia to x"};
static char  v2[] = {"Julia from y"};
static char  v3[] = {"Julia to y"};
static char  v4[] = {"Mandelbrot from x"};
static char  v5[] = {"Mandelbrot to x"};
static char  v6[] = {"Mandelbrot from y"};
static char  v7[] = {"Mandelbrot to y"};
static char  v8[] = {"Number of z pixels"};
static char  v9[] = {"Penetration level"};
static char  v10[] = {"Location of z origin"};
static char  v11[] = {"Depth of z"};
static char  v12[] = {"Screen height"};
static char  v13[] = {"Screen width"};
static char  v14[] = {"Distance to Screen"};
static char  v15[] = {"Distance between eyes (0 for Greyscale)"};
static char  v16[] = {"Blue:Red Ratio (0 for Greyscale)"};
static char  *v[NUM_VAR] = {v0,v1,v2,v3,v4,v5,v6,v7,v8,v9,
    v10,v11,v12,v13,v14,v15,v16};

static double fg, fg16;
static long
        zdots = 128L,
        shell = 30L,
        origin = (long)(8.0 * (1L << 16)),
   height = (long)(7.0 * (1L << 16)),
        width = (long)(10.0 * (1L << 16)),
   dist = (long)(24.0 * (1L << 16)),
   eyes = (long)(0.0 * (1L << 16)),
   depth = (long)(8.0 * (1L << 16)),
   brratio = (long)(0.0 * (1L << 16));

double originfp=8, heightfp=7, widthfp=10, distfp=24, eyesfp=0, depthfp=8,
    brratiofp=0;

int JulibrotSetup(void) {
        int r;
        int oldhelpmode;
   struct fullscreenvalues d[NUM_VAR];
   char *mapname;

   if(colors < 255) {
      static char  msg[]=
          {"Sorry, but Julibrots require a 256-color video mode"};
      stopmsg(0,msg);
      return(0);
   }

   fg = (double)(1L << bitshift);
   fg16 = (double)(1L << 16);

   for (r = 0; r < NUM_VAR; ++r)
      d[r].type = 'f';

        jxmaxfp = (long)((d[0].uval.dval = xxmax) * fg);
        jxminfp = (long)((d[1].uval.dval = xxmin) * fg);
        jymax = (long)((d[2].uval.dval = yymax) * fg);
        jymin = (long)((d[3].uval.dval = yymin) * fg);
        mxmax = (long)((d[4].uval.dval = param[0]) * fg);
        mxmin = (long)((d[5].uval.dval = param[1]) * fg);
        mymax = (long)((d[6].uval.dval = param[2]) * fg);
        mymin = (long)((d[7].uval.dval = param[3]) * fg);
   d[8].uval.dval = (double)zdots;
   d[9].uval.dval = (double)shell;
   d[10].uval.dval = (double)origin / fg16;
   d[11].uval.dval = (double)depth / fg16;
   d[12].uval.dval = (double)height / fg16;
   d[13].uval.dval = (double)width / fg16;
   d[14].uval.dval = (double)dist / fg16;
   d[15].uval.dval = (double)eyes / fg16;
   d[16].uval.dval = (double)brratio / fg16;

   stackscreen();
   oldhelpmode = helpmode;
   helpmode = HT_JULIBROT;
   if((r = fullscreen_prompt("Julibrot Parameters",
                              NUM_VAR, v, d, 0, 0, 0)) >= 0) {
      jxmin = (long)((xxmax = d[0].uval.dval) * fg);
      jxmax = (long)((xxmin = d[1].uval.dval) * fg);
      xoffset = (jxmax + jxmin) / 2;       /* Calculate average */
      jymin = (long)((yymax = d[2].uval.dval) * fg);
      jymax = (long)((yymin = d[3].uval.dval) * fg);
      yoffset = (jymax + jymin) / 2;       /* Calculate average */
      mxmin = (long)((param[0] = d[4].uval.dval) * fg);
      mxmax = (long)((param[1] = d[5].uval.dval) * fg);
      mymin = (long)((param[2] = d[6].uval.dval) * fg);
      mymax = (long)((param[3] = d[7].uval.dval) * fg);
      zdots = (long)(d[8].uval.dval);
      shell = (long)(d[9].uval.dval);
      origin = (long)(d[10].uval.dval * fg16);
      depth = (long)(d[11].uval.dval * fg16);
      height = (long)(d[12].uval.dval * fg16);
      width = (long)(d[13].uval.dval * fg16);
      dist = (long)(d[14].uval.dval * fg16);
      eyes = (long)(d[15].uval.dval * fg16);
      brratio = (long)(d[16].uval.dval * fg16);
      dmx = (mxmax - mxmin) / zdots;
      dmy = (mymax - mymin) / zdots;
      longparm = &jbc;

      x_per_inch = (long)((d[1].uval.dval - d[0].uval.dval) / d[13].uval.dval * fg);
      y_per_inch = (long)((d[3].uval.dval - d[2].uval.dval) / d[12].uval.dval * fg);
                inch_per_xdot = (long)(d[13].uval.dval / xdots * fg16);
                inch_per_ydot = (long)(d[12].uval.dval / ydots * fg16);
      initz = origin - (depth / 2);
      LeftEye.x = -(RightEye.x = eyes / 2);
      LeftEye.y = RightEye.y = 0l;
      LeftEye.zx = RightEye.zx = dist;
      LeftEye.zy = RightEye.zy = dist;
      bbase = (int)(128.0 * d[16].uval.dval);
   }

   helpmode = oldhelpmode;
   unstackscreen();

   if(d[16].uval.dval == 0.0)
      mapname = GreyFile;
   else
      mapname = StereoFile;
   if (ValidateLuts(mapname) != 0)
      return(0);
   spindac(0,1);                 /* load it, but don't spin */

   return(r >= 0);
}

int JulibrotfpSetup(void) {
        int r;
        int oldhelpmode;
   struct fullscreenvalues d[NUM_VAR];
   char *mapname;

   if(colors < 255) {
      static char  msg[]=
          {"Sorry, but Julibrots require a 256-color video mode"};
      stopmsg(0,msg);
      return(0);
   }

   for (r = 0; r < NUM_VAR; ++r)
      d[r].type = 'f';

        jxmaxfp = d[0].uval.dval = xxmax;
        jxminfp = d[1].uval.dval = xxmin;
        jymaxfp = d[2].uval.dval = yymax;
        jyminfp = d[3].uval.dval = yymin;
        mxmaxfp = d[4].uval.dval = param[0];
        mxminfp = d[5].uval.dval = param[1];
        mymaxfp = d[6].uval.dval = param[2];
        myminfp = d[7].uval.dval = param[3];
   d[8].uval.dval = (double)zdots;
   d[9].uval.dval = (double)shell;
   d[10].uval.dval = originfp;
   d[11].uval.dval = depthfp;
   d[12].uval.dval = heightfp;
   d[13].uval.dval = widthfp;
   d[14].uval.dval = distfp;
   d[15].uval.dval = eyesfp;
   d[16].uval.dval = brratiofp;

   stackscreen();
   oldhelpmode = helpmode;
   helpmode = HT_JULIBROT;
   if((r = fullscreen_prompt("Julibrot Parameters",
                              NUM_VAR, v, d, 0, 0, 0)) >= 0) {
      jxminfp = xxmax = d[0].uval.dval;
      jxmaxfp = xxmin = d[1].uval.dval;
      xoffsetfp = (jxmaxfp + jxminfp) / 2;       /* Calculate average */
      jyminfp = yymax = d[2].uval.dval;
      jymaxfp = yymin = d[3].uval.dval;
      yoffsetfp = (jymaxfp + jyminfp) / 2;       /* Calculate average */
      mxminfp = param[0] = d[4].uval.dval;
      mxmaxfp = param[1] = d[5].uval.dval;
      myminfp = param[2] = d[6].uval.dval;
      mymaxfp = param[3] = d[7].uval.dval;
      zdots = (long)(d[8].uval.dval);
      shell = (long)(d[9].uval.dval);
      originfp = d[10].uval.dval;
      depthfp = d[11].uval.dval;
      heightfp = d[12].uval.dval;
      widthfp = d[13].uval.dval;
      distfp = d[14].uval.dval;
      eyes = d[15].uval.dval;
      brratio = d[16].uval.dval;
      dmxfp = (mxmaxfp - mxminfp) / zdots;
      dmyfp = (mymaxfp - myminfp) / zdots;
      floatparm = &jbcfp;

      x_per_inchfp = (d[1].uval.dval - d[0].uval.dval) / d[13].uval.dval;
      y_per_inchfp = (d[3].uval.dval - d[2].uval.dval) / d[12].uval.dval;
      inch_per_xdotfp = d[13].uval.dval / xdots;
      inch_per_ydotfp = d[12].uval.dval / ydots;
      initzfp = originfp - (depthfp / 2);
      LeftEyefp.x = -(RightEyefp.x = eyesfp / 2);
      LeftEyefp.y = RightEyefp.y = 0;
      LeftEyefp.zx = RightEyefp.zx = distfp;
      LeftEyefp.zy = RightEyefp.zy = distfp;
      bbase = (int)(128.0 * d[16].uval.dval);
   }

   helpmode = oldhelpmode;
   unstackscreen();

   if(d[16].uval.dval == 0.0)
      mapname = GreyFile;
   else
      mapname = StereoFile;
   if (ValidateLuts(mapname) != 0)
      return(0);
   spindac(0,1);                 /* load it, but don't spin */

   return(r >= 0);
}

int jb_per_pixel(void) {
        jx = multiply(Per->x - xpixel, initz, 16);
   jx = divide(jx, dist, 16) - xpixel;
   jx = multiply(jx << (bitshift - 16), x_per_inch, bitshift);
   jx += xoffset;
        djx = divide(depth, dist, 16);
        djx = multiply(djx, Per->x - xpixel, 16) << (bitshift - 16);
        djx = multiply(djx, x_per_inch, bitshift) / zdots;

        jy = multiply(Per->y - ypixel, initz, 16);
        jy = divide(jy, dist, 16) - ypixel;
        jy = multiply(jy << (bitshift - 16), y_per_inch, bitshift);
   jy += yoffset;
        djy = divide(depth, dist, 16);
        djy = multiply(djy, Per->y - ypixel, 16) << (bitshift - 16);
        djy = multiply(djy, y_per_inch, bitshift) / zdots;

   return(1);
}

int jbfp_per_pixel(void) {
	jxfp = ((Perfp->x-xpixelfp)*initzfp/distfp-xpixelfp)*x_per_inchfp;
	jxfp += xoffsetfp;
	djxfp = depthfp/distfp*(Perfp->x-xpixelfp)*x_per_inchfp/zdots;

	jyfp = ((Perfp->y-ypixelfp)*initzfp/distfp-ypixelfp)*y_per_inchfp;
	jyfp += yoffsetfp;
	djyfp = depthfp/distfp*(Perfp->y-ypixelfp)*y_per_inchfp/zdots;

   return(1);
}

static int n, zpixel, plotted, color;

int zline(long x, long y) {
   xpixel = x;
   ypixel = y;
        mx = mxmin;
        my = mymin;
   if((row + col) & 1)
      Per = &LeftEye;
   else
      Per = &RightEye;
   curfractalspecific->per_pixel();
   for(zpixel = 0; zpixel < zdots; zpixel++) {
      lold.x = jx;
      lold.y = jy;
      jbc.x = mx;
      jbc.y = my;
      if(check_key())
         return(-1);
      ltempsqrx = multiply(lold.x, lold.x, bitshift);
      ltempsqry = multiply(lold.y, lold.y, bitshift);
      for(n = 0; n < shell; n++) {
         if(curfractalspecific->orbitcalc())
            break;
      }
      if(n == shell) {
         if(brratio) {
            color = (int)(128l * zpixel / zdots);
            if((row + col) & 1)
               (*plot)(col, row, 127 - color);
            else {
                                color = (int)(multiply((long)color << 16, brratio, 16) >> 16);
               (*plot)(col, row, 127 + bbase - color);
            }
         }
         else {
            color = (int)(254l * zpixel / zdots);
            (*plot)(col, row, color + 1);
         }
         plotted = 1;
         break;
      }
      mx += dmx;
      my += dmy;
      jx += djx;
      jy += djy;
   }
   return(0);
}

int zlinefp(double x, double y) {
   static int keychk = 0;
   xpixelfp = x;
   ypixelfp = y;
        mxfp = mxminfp;
        myfp = myminfp;
   if((row + col) & 1)
      Perfp = &LeftEyefp;
   else
      Perfp = &RightEyefp;
   curfractalspecific->per_pixel();
   for(zpixel = 0; zpixel < zdots; zpixel++) {
      old.x = jxfp;
      old.y = jyfp;
      jbcfp.x = mxfp;
      jbcfp.y = myfp;
      if (keychk++>500) {
	  keychk=0;
	  if(check_key())
	     return(-1);
      }
      tempsqrx = sqr(old.x);
      tempsqry = sqr(old.y);
      for(n = 0; n < shell; n++) {
         if(curfractalspecific->orbitcalc())
            break;
      }
      if(n == shell) {
         if(brratio) {
            color = (int)(128l * zpixel / zdots);
            if((row + col) & 1)
               (*plot)(col, row, 127 - color);
            else {
		color = color*brratiofp;
               (*plot)(col, row, 127 + bbase - color);
            }
         }
         else {
            color = (int)(254l * zpixel / zdots);
            (*plot)(col, row, color + 1);
         }
         plotted = 1;
         break;
      }
      mxfp += dmxfp;
      myfp += dmyfp;
      jxfp += djxfp;
      jyfp += djyfp;
   }
   return(0);
}

int Std4dFractal(void) {
   long x, y;
   int xdot, ydot;

   for(y = 0, ydot = (ydots >> 1) - 1; ydot >= 0; ydot--, y -= inch_per_ydot) {
                plotted = 0;
                x = -(width >> 1);
                for(xdot = 0; xdot < xdots; xdot++, x += inch_per_xdot) {
         col = xdot;
         row = ydot;
         if(zline(x, y) < 0)
            return(-1);
         col = xdots - col - 1;
         row = ydots - row - 1;
         if(zline(-x, -y) < 0)
            return(-1);
      }
      if(!plotted) break;
   }
   return(0);
}

int Std4dfpFractal(void) {
   double x, y;
   int xdot, ydot;

   for(y=0, ydot = (ydots >> 1) - 1; ydot >= 0; ydot--,y -= inch_per_ydotfp) {
                plotted = 0;
                x = -widthfp/2;
                for(xdot = 0; xdot < xdots; xdot++, x += inch_per_xdotfp) {
         col = xdot;
         row = ydot;
         if(zlinefp(x, y) < 0)
            return(-1);
         col = xdots - col - 1;
         row = ydots - row - 1;
         if(zlinefp(-x, -y) < 0)
            return(-1);
      }
      if(!plotted) break;
   }
   return(0);
}
