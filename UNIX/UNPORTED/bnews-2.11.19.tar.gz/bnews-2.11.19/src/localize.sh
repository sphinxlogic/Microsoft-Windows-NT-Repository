rm -f Makefile
cp Makefile.dst Makefile
chmod u+w Makefile
ed - Makefile  <<'EOF'
g/^#USG /s/#USG //p
g/^#V7 /dp
g/^#VMS /dp
g/^#BSD4_[123] /dp
g/#NOTVMS/s/#NOTVMS.*//p
/^DEBUG/s;$;-g;p
g/termlib/s//curses/p
g/lib/s'/usr/lib'/opt/lib'p
g/bin/s'/usr/bin'/opt/bin'p
g/spool/s'/usr/spool'/var/spool'p
g/CFLAGS/s'-O'-O3 -traditional'p
w
q
EOF
rm -f defs.h
cp defs.dist defs.h
chmod u+w defs.h
ed - defs.h <<'EOF'
/ROOTID/s/10/0/p
/N_UMASK/s/000/002/p
/INTERNET/s;/\* ;;p
/MYDOMAIN/s;.UUCP;.lemis.de;p
/DOXREFS/s;/\* ;;p
/LOCKF/s;/\* ;;p
/MKDIRSUB/s;/\* ;;p
/RENAMESUB/s;/\* ;;p
/SENDMAIL/s;/\* ;;p
/SENDMAIL/s;/usr/lib;/usr/ucblib;p
/HIDDENNET/s;frooz;onlyyou;p
/MYORG/s/Frobozz Inc., St. Louis/LEMIS, Feldatal/p
/ORGDISTRIB/s;/\* ;;p
/ORGDISTRIB/s;froozum;lemis;p
/PAGE/s;usr/ucb;usr/bin;p
w
q
EOF
