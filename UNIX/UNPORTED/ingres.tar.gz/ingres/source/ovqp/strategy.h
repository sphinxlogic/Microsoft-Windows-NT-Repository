/*
**  STRATEGY.H
**
**	Version:
**		@(#)strategy.h	8.1	12/31/84
*/

# define	opGTGE	opGT
# define	opLTLE	opLT
