# ifndef	lint
# define	SCCSID(arg) static char Sccsid[] = "arg";
# else		lint
# define	SCCSID(arg)
# endif		lint
