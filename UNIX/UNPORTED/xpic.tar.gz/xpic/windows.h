/* $Header: windows.h,v 1.3 89/07/02 15:59:31 moraes Exp $ */

#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>

void CreateWindows();
void RedrawPicWin();
