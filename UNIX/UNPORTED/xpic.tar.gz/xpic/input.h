/* $Header: input.h,v 1.3 89/07/02 15:58:26 moraes Exp $ */
extern void finished_input();
extern char *get_input();
