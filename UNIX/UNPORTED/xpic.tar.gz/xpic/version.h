/* $Header: version.h,v 1.3 89/07/02 15:59:23 moraes Exp $ */
static int progVersion = 2;
static char *progStatus = "";
