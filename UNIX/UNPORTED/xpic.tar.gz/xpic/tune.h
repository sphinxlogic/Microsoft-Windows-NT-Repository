#define LIBDIR "/local/share/X11/xpic"
#define PROGRAMNAME "/local/bin/X11/xpic"
#define DUMPDIR "/tmp"
