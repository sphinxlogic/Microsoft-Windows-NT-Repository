/* $Header: spline.h,v 1.3 89/07/02 15:59:11 moraes Exp $ */
void FlattenSpline();
XPoint *InitSpline();
