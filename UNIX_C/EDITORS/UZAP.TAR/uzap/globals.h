#include <stdio.h>
#include <ctype.h>
#include <curses.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>

/***************************************************************************/
/*                               Uzap!                                     */
/*        Copyright (c) 1989  Robert Silvers - pRevious, Inc.              */
/*                       -All rights reserved-                             */
/*                 Developed at the University of Lowell                   */
/*                                                                         */
/* This software is supplied free of charge.  This software, or any part   */
/* of it, may  not  be  redistributed or otherwise made available to, or   */
/* used  by, any  other  person  without the inclusion of this copyright   */
/* notice.  This software may not be used to make a profit in any way.     */
/*                                                                         */
/* This  software  is provided with absolutely no warranty, to the extent  */
/* permitted  by  applicable  state law.  In no event, unless required by  */
/* applicable law, will the author(s) of this this software be liable for  */
/* any damages caused by this software.                                    */
/*                                                                         */
/***************************************************************************/

#define VERSION "V1.0"
#define PRINTB(X) Bold(); printf(X); Normal()
#define PRINTM(x) CHome(); printf(x); Home()
#define PRINTG(x) Graphics(); printf(x); Asc()

extern int pos;                   /* Position in binary             */
extern int block;                 /* Current block displayed        */
extern int loaded;                /* TRUE if a file is loaded       */
extern int modified;              /* TRUE if file was modified      */
extern int max;                   /* Number of blocks in file       */
extern int size;                  /* Size of file                   */
extern unsigned char string[512]; /* Global search string           */
extern char filename[128];        /* Filename used for I            */
extern char sfilename[128];       /* Actual saved-filename          */
extern char dfilename[128];       /* Default save-filename          */
extern unsigned char *image;      /* The binary image to edit       */

typedef struct node ELEMENT;
typedef ELEMENT     *LINK;
extern LINK    head;
extern LINK    tail;

extern struct node{               /* Undo buffer                    */
   int address;
   unsigned char value;
   struct node *next;
   struct node *prev;
}undobuffer;

extern char GetKey();
extern void Cls(), Bold(), Blink(), Inverse(), Underline(), Normal(),
       Graphics(), Asc(), DrawScreen(), Refresh(), Move(), GetEscSequence(), 
       Home(), Beep(), abort(), cont(), CHome(); 




