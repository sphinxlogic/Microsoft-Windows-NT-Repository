/* options for Prime MicroGnuEmacs by Robert A. Larson

-32ix
/* get routine names in stack dump
-store_owner_field
/* tell it to run fast
-standardintrinsics
-optimize 1
/* -pbstring was broken, and either got fixed or the other changes...
-pbstring
/* find varargs.h in *>sys>prime
-include *>sys>prime

/* real options
-define PREFIXREGION
-define NOTAB

