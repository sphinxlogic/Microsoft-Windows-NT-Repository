
/*
 * This code copyright 1988 by Doug Davis (doug@letni.lawnet.com) 
 *  You are free to modify, hack, fold, spindle, or mutlate this code in
 *  any maner provided you give credit where credit is due and don't pretend
 *  you wrote it.
 *  If you do my lawyers (and I have a lot of lawyers) will teach you a lesson
 *  in copyright law that you will never ever forget.
 */
#include "defs.h"

FILE	*EditFile;
LINE	*current	= (LINE *) NULL;
LINE	*find_work	= (LINE *) NULL;
LINE	*l_end		= (LINE *) NULL;
LINE	*l_start	= (LINE *) NULL; 
char	*Bottom="Bottom of file.";
char	*Eof="Search ending, bottom of file.";
char	*Progname;
char	*Top="Top of file.";
char	*find_string = NULL;
char	Dots		= 'N';
char	WriteOnQuit	= 'N';
char	buf[BUFSIZ];
int	Debug;
long	CurrentLine;
long	NumberLines;
long	find_line = 1L;
char	*HelpName=WSEDHELP;
