/*
 * This code copyright 1988 by Doug Davis (doug@letni.lawnet.com) 
 *  You are free to modify, hack, fold, spindle, or mutlate this code in
 *  any maner provided you give credit where credit is due and don't pretend
 *  you wrote it.
 *  If you do my lawyers (and I have a lot of lawyers) will teach you a lesson
 *  in copyright law that you will never ever forget.
 */
#include <sys/types.h>
#include <signal.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/stat.h>
#include <stdio.h>
#include <errno.h>
#include "curses.h"

#define WSEDHELP	"/usr/lib/rsedhelp";
#define	MAXREPLACE	4096 /* biggest tmp line size for global replacement */
#define	BEGINDOTS	24L * 1024L /* size of file to warrent dots to show
					that we are doing something */

typedef struct line {
	struct line *previous;
	struct line *next;
	char text[1]; /* has to be end */
} LINE;

#ifndef MSDOS
	#ifdef CBREAK
	#define One_Char()	crmode();
	#else
	#define One_Char()	cbreak();
	#endif
#endif MSDOS
