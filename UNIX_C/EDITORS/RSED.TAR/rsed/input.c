
/*
 * This code copyright 1988 by Doug Davis (doug@letni.lawnet.com) 
 *  You are free to modify, hack, fold, spindle, or mutlate this code in
 *  any maner provided you give credit where credit is due and don't pretend
 *  you wrote it.
 *  If you do my lawyers (and I have a lot of lawyers) will teach you a lesson
 *  in copyright law that you will never ever forget.
 */
#include "defs.h"
#include "externs.h"

long
getlnum()
{
	getstring(buf, 10, '\0');
	return(makenum(buf));
}

char
yesno()
{
	char c;
	for (;;) {
#ifdef MSDOS
		c=getch();
#else MSDOS
		c=getchar();
#endif MSDOS
		if (islower(c))
			c=toupper(c);
		switch (c) {
			case 'Y':
				puts("Yes.");
				return(c);
			break;
			case 'N':
				puts("No.");
				return(c);
			break;
			default:
				puts("<Y>es or <N>o please.");
			break;
		}
	}
}
/*
 *	This routine gets a string..
 *
 */
char *
getstring(str, len, first)
char	*str;
int	len;
char	first;
{
	char *p, c;
	p = str;
	if (first != '\0')  {
		*(p++) = first;
		putchar(first);
	}		
	for ( ;; ) {
#ifdef MSDOS
		c = getch();
#else
		c = getchar();
#endif MSDOS
		switch(c) {
			case '\b': {
				if (p > str) {
					*p='\0';
					fputs("\010 \010", stdout);
					*(p--)='\0';
				} else {
					putchar('\007');
					}
				}
				break;
			case '\n':
			case '\r': {
				*p='\0';
				putchar('\n');
				return(*str != '\0' ? str : NULL);
				} break;
			default: {
				if (p < str+len) {
					*(p++) = c;
					putchar(c);
				} else { 
					putchar('\007');
				}
			} break;
		}
	}
}
