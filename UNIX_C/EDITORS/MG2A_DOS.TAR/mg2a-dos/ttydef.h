/*
 *	Termcap terminal file, nothing special, just make it big
 *	enough for windowing systems.
 */

#define	GOSLING			/* Compile in fancy display.	*/
/* #define	MEMMAP		*/	/* Not memory mapped video.	*/

#define	NROW	25    			/* Rows.			*/
#define	NCOL	80			/* Columns.			*/
#define	MOVE_STANDOUT			/* don't move in standout mode	*/
/* #define	STANDOUT_GLITCH		/* possible standout glitch	*/
#define XKEYS

#define KFIRST	K00
#define KHOME	K00
#define KDOWN	K01
#define	KUP	K02
#define	KLEFT	K03
#define	KRIGHT	K04
#define	KPGUP	K05
#define	KPGDN	K06
#define	KEND	K07
#define	KDELETE	K08
#define	KINSERT	K09
#define KCLEFT	K0A
#define KCRIGHT	K0B
#define KCPGUP	K0C
#define KCPGDN	K0D
#define KCHOME	K0E
#define KCEND	K0F

#define	KF1	K10
#define KF2	K11
#define KF3	K12
#define KF4	K13
#define KF5	K14
#define KF6	K15
#define KF7	K16
#define KF8	K17
#define	KF9	K18
#define KF10	K19
#define	KSF1	K1A
#define	KSF2	K1B
#define	KSF3	K1C
#define	KSF4	K1D
#define	KSF5	K1E
#define	KSF6	K1F
#define	KSF7	K20
#define	KSF8	K21
#define	KSF9	K22
#define	KSF10	K23
#define KCF1	K24
#define KCF2	K25
#define KCF3	K26
#define KCF4	K27
#define KCF5	K28
#define KCF6	K29
#define KCF7	K2A
#define KCF8	K2B
#define KCF9	K2C
#define KCF10	K2D
#define KLAST	K2D

#define	NFUND_XMAPS	1
#define	FUND_XMAPS	{KFIRST,KLAST,ibm_keys,(KEYMAP*)NULL}
extern	int (*(ibm_keys[]))(); /* should be FN ibmkeys[], but not defined yet */
/*
 * Extra map segments for dired mode -- just use fundamental mode segments
 */
#define	NDIRED_XMAPS	NFUND_XMAPS
#define	DIRED_XMAPS	FUND_XMAPS

