/*
 * Name:	Mg 2a
 *		Spawn CLI for MSDOS (TurboC 1.5)
 *
 */
#include	"def.h"
#include	<process.h>

extern	char	*getenv();

/*
 * On MSDOS, we got no job control like system V, so always
 * run a subshell. Bound to "C-C", and used
 * as a subcommand by "C-Z". (daveb)
 *
 * Returns 0 if the shell executed OK, something else if
 * we couldn't start shell or it exited badly.
 */
spawncli(f, n, k)
{
	char *comspec;
	int		errp = FALSE;

	ttcolor(CTEXT);
	ttnowindow();
	ttmove(nrow-1, 0);
	if (epresf != FALSE) {
		tteeol();
		epresf = FALSE;
	}
	ttclose();
	sgarbf = TRUE;				/* Force repaint.	*/
	if ((comspec = getenv("COMSPEC")) == NULL)
		errp = -1;
	else
		errp = spawnl(P_WAIT, comspec, "COMMAND.COM", (char *)NULL);

	ttopen();
	if(errp == -1)
		ewprintf("Failed to create process");

	return ( errp );
}
