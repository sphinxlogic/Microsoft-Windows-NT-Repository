/*
 * Name:	Mg 2a
 *		MSDOS system header file (TurboC 1.5)
 */

/* can't include these, the ANSI style prototypes conflict with the
 * definitions in defs.h
 */
/* #include <stdlib.h> */
/* #include <string.h> */
/* #include <dir.h> */
/* #include <stdio.h> */
#define NULL	0L

#define	KBLOCK	1024			/* Kill grow.			*/
#define	GOOD	0			/* Good exit status.		*/
#define	MAXPATH	256			/* Maximum length of path for chdir */

#define LOCAL_VARARGS			/* use sys/default/varargs.h */
#define DO_METAKEY			/* ALT acts like META */
#define METABIT 0x200
#define FKEYS				/* we have dedicated function keys */
/* #define NO_DIRED */			/* dired works now */
#define C_ALLOCA			/* used by regex, C version of alloca*/

typedef long	RSIZE;			/* Type for file/region sizes	*/
typedef short	KCHAR;			/* Type for internal keystrokes	*/
/* typedef short	KEY;		/* Type for internal keystrokes	*/

/*
 * Macros used by the buffer name making code.
 * Start at the end of the file name, scan to the left
 * until BDC1 (or BDC2, if defined) is reached. The buffer
 * name starts just to the right of that location, and
 * stops at end of string (or at the next BDC3 character,
 * if defined). BDC2 and BDC3 are mainly for VMS.
 */
#define	BDC1	'/'
#define	BDC2	'\\'

#define bcopy(s,d,n)	memcpy(d,s,n)	/* memory-to-memory copy	*/
#define bcmp(s1,s2,n)	memcmp(s2,s1,n) /* memory comparison		*/
#define bzero(s,n)	memset(s,0,n)	/* memory zero			*/

#define fncmp	stricmp
#define getwd(cwd)	getcwd(cwd,NFILEN) /* get current working dir	*/
extern char *getcwd();

#define MALLOCROUND(m)	(m+=7,m&=~7)	/* round up to 8 byte boundry	*/
