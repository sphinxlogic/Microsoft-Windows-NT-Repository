/* Since dnaerror.c is copyrighted, this file just includes the copy	*/
/* you should already have.  You may have to change the path name if	*/
/* your setup is not standard.  If you don't have this file (even	*/
/* on the original tape), then you will have to get one from Sun,	*/
/* or derive your own.							*/
/*									*/
/* All dnaerror does, is to simulate perror(), but with DECNET errors	*/
/* if they apply.							*/

#include "/usr/sunlink/dna/tests/dnaerror.c"
