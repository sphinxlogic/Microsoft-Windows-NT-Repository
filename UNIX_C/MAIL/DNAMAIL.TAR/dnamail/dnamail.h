  /* these lines get compiled into every object file */
static char *version = "DnaMail (v1.1)";
static char *CopyRight 
	= "Copyright (C) D. B. Johnson, Feb., 1988; Lockheed Missiles & Space";

/* uncomment this if you want to run standalone */
/* #define STANDALONE */

/* local defines */
#define MAXLINE 256
#define MAIL_OBJECT 27
#define TMPFILE "/tmp/dnamail.XXXXXX"

#define TRUE 1
#define FALSE 0

/* external routines */
char *copystr(), *mailtime();
