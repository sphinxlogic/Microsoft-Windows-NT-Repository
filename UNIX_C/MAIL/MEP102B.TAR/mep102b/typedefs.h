/* 
 * System data types
 */

typedef	char	STRING[255];
