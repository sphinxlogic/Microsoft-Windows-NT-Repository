# define	TRUE	1
# define	FALSE	0

#if USG
# define	MEMCPY(a,b,c)	memcpy(a,b,c)
#else
# define	MEMCPY(a,b,c)	bcopy(b,a,c)
#endif
 
# define MEPTEMP	"/tmp/mep-XXXXXX"	/* temp files */

# define MEPCONFIG	".meprc"	/* notify/stat setting*/
# define MEPTWIT	".meptwits"	/* twitlist file */
# define MEPCOMMAND	".mepcmds"	/* valid commands */
# define MEPTOTWIT	".meptwitmsg"	/* sent to twits */
# define MEPFAIL	".mepfailmsg"	/* sent on command fail */
# define MEPVERSION	"1.02B"

typedef	struct	persons
{
	char	pattern[512];
	char	op;
	char	path[512];
};

extern	int	biffer, notify, log;
extern	int	firstmessage;	/* First message read = 1 else 0	*/

extern	char	fromline[512],/* From line from message	*/
		toline[512],		/* To: line from message		*/
		subline[512],		/* Message subject			*/
		linebuffer[512],	/* Big buffer for messages	*/
		logfile[80];

extern	char	namem[80], names[80], namet[80];
extern	char	username[20], homedir[80];

extern	int	num_cmds;
extern	int	num_twits;
extern	struct  persons twitlist[100];	/* Twit list	*/
extern	STRING	comlist[100];
extern	error();			/* Error messages			*/
extern	char *logged();
