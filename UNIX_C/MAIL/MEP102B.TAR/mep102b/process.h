/*
 * Process.c header file process.h
 * John Antypas
 * Used in message.c to handle each individual mail message
 * All messages are passed through process_message here.
 * It can call features such as twit_list(name) which will 
 * return TRUE if that person is on the twitlist and
 * command(line) which will handle the @ commands
 */

extern	void	proces_message();	/* Handles message	*/

