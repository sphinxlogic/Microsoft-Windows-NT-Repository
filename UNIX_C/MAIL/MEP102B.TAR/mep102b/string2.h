/*
      String2 -- String2 header file

      Make sure to link with string2.o

      strindex(s,t) -- Return index to pattern t in string s or -1
      strreplace(s,p,r) -- Replace pattern p by pattern r in string s.
                           Return char pointer to s or NULL if error.
      strword(r,s,c,i) -- Returns:
            If (i<0) ; the number of words in string s is returned sa result.
               (i>0) ; the ith word is returned in r from string s.
*/
extern	int	strword();
extern	int	strindex();
extern	char	*strreplace();
#define	strdelete(s,p,q)	strreplace(s,p,q,"");
