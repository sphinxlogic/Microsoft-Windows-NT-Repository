# include	<stdio.h>
# include	"typedefs.h"
# include	"globals.h"
# include	"string2.h"

extern	int	check_commands();
extern	FILE	*popen();

/* 
 * Twit(name)
 *
 * Returns TRUE if name is a twit, false otherwise
 *
 */
twit(name,mpath)
char	name[];
char	*mpath;
{
	int	loop = 1;

	while (loop <= num_twits)
	{
		if (strindex(name,twitlist[loop].pattern) != -1)
		{ 
			switch(twitlist[loop].op)
			{
				case 'D' : return(1); 
				case 'T' : return(2);
				case 'S' : {
							strcpy(mpath,twitlist[loop].path);
							return(3);
						}
			}
		}
		loop++;
	}
	return(0);
}

/*
 * Do_Notify.  Notify user if twit sends mail if NOTIFY variable is set
 */
do_notify()
{
	FILE	*od, *md, *fopen();
	char buffer[80];
	
	if (notify == TRUE)
	{
		strcpy(namet,mktemp(MEPTEMP));
		md = fopen(namet,"w+");
		fprintf(md,"\nFor: %s@%s\n\n",username,homedir);
		fprintf(md,"\nSomeone at address:\n");
		fprintf(md,"\t%s\n",fromline);
		fprintf(md,"has tried to send you mail.  ");
		fprintf(md,"TwitMinder has discarded it.\n\n");
		fclose(md);
		sprintf(buffer,"/usr/ucb/Mail -s \"MEP Twit Alert\" %s",username);
		od = popen(buffer,"w");
		md = fopen(namet,"r");
		fgets(buffer,512,md);
		while (!feof(md))
		{
			fputs(buffer,od);
			fgets(buffer,512,md);
		}
		fclose(md);
		pclose(od);
		unlink(namet);
		sprintf(buffer,"%s/%s",homedir,MEPTOTWIT);
		od = fopen(buffer,"r");
		if (od != NULL)
		{
			fclose(od);
sprintf(buffer,"cat %s/%s | /usr/ucb/Mail -s \"Your message\" %s", homedir, MEPTOTWIT, fromline);
			system(buffer);
		}
	}
}

/*
 * Process_message
 *
 * When given a message, performs the following:
 *
 * - Checks to see if person wants logging done
 *   If so, performs the log entry
 * - Checks to see if sender is on twitlist and if
 *   so, will discard mail to bit bucket and if notify
 *   option is set will send mail to that effect
 * - Process @commands
 * 
 */
process_message()
{
	int	i;
	FILE	*of, *fp, *md, *fopen();
	char	ppath[512], buffer[512];
	char	term[9];
	
	switch(twit(fromline,ppath))
	{
		case 2 : {
			do_notify();
			unlink(namem);
			return(0);
		}
		case 1 : {
			unlink(namem);
			return(0);
		}
		case 3 : {
			 /* Special */
			strcpy(term,logged(username));
			if (term != NULL)
			{
				sprintf(buffer,"/dev/%s",term);
				fp = fopen(buffer,"w");
				fprintf(fp,"\007\007Express mail has arrived.\n");
				fclose(fp);
			}
			/* See if forward is required	*/
			i = strlen(ppath);
			if (i != 0)
			{
	sprintf(buffer,"cat %s | /usr/ucb/Mail -s Forward-Mail %s",namem,ppath);
				system(buffer);
			}	
	}
	case 0 : {
			 /* Normal */ 
			if (biffer == TRUE)
			{
				strcpy(term,logged(username));
				if (strlen(term) != 0)
				{
					sprintf(buffer,"/dev/%s",term);
					fp = fopen(buffer,"w");
					fprintf(fp,"\007You have new mail.\n");
					fclose(fp);
				}
			}
		}
		if (log == TRUE)
		{
		/* 
			Ok, so write down in log file when each message
			arrives and the sender.
		*/
			char	buffer2[80];
			FILE *pd;
	
			pd = popen("date","r");
			fgets(buffer2,80,pd);
			pclose(pd);
			md = fopen(logfile,"a");
			sprintf(buffer,"From: %s @ %s",fromline,buffer2);
			fputs(buffer,md);
			fclose(md);
		}
	}
	check_commands();
	fp = fopen(namem,"r");
	sprintf(buffer,"/usr/spool/mail/%s",username);
	of = fopen(buffer,"a");
	fgets(buffer,512,fp);
	while (!feof(fp))
	{
		fputs(buffer,of);
		fgets(buffer,512,fp);
	}
	fclose(fp);
	unlink(namem);
	fputs("\n",of);		/* message break */
	fclose(of);
}
