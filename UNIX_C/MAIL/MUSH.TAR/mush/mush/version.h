/* @(#)version.h	(c) Copyright 1989 (Dan Heller) */

#define MUSHNAME	"Mail User's Shell"
#define RELEASE_DATE	"5/02/90"
#define RELEASE		7
#define REVISION	"1"
#define PATCHLEVEL	1
