/*
 * $Source: /usr/src/local/local.bin/ease/src/RCS/fixstrings.h,v $
 * $Locker:  $
 *
 * $Revision: 2.0 $
 * Check-in $Date: 88/06/15 14:41:57 $
 * $State: Exp $
 *
 * $Author: root $
 *
 * $Log:	fixstrings.h,v $
 * Revision 2.0  88/06/15  14:41:57  root
 * Baseline release for net posting. ADR.
 * 
 * Version 1.3  87/03/05  19:37:50  jeff
 * Edited RCS header and FLUKEid[] string.
 * 
 * Version 1.2  87/02/25  16:55:16  jeff
 * Add some RCS header lines.  No code changes.
 * 
 */

/* FLUKE jps 16-apr-86 - revector the string routines to custom-coded ones
 *  which handle NULL pointers.
 */
#define strcat	Xstrcat
#define strncat	Xstrncat
#define strcmp	Xstrcmp
#define strncmp	Xstrncmp
#define strcpy	Xstrcpy
#define strncpy	Xstrncpy
#define strlen	Xstrlen
#define index	Xindex
#define rindex	Xrindex
