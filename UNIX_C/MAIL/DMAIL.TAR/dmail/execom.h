
/*
 * EXECOM.H
 *
 * (C) 1985 by Matthew Dillon    17 December 1985
 */

struct COMMAND {
    int  (*func)();
    int  stat;
    int  val;
    char *name;
};

extern struct COMMAND Command[];
extern char *Desc[];

#define C_NO        0x01	/* Not implimented yet */


