/* chksum.h */
/* calcchecksum() was converted to a macro for effectivity reasons. */
/* Don't (!!) give it an argument that has to be evaluated. This    */
/* is guaranteed to slow it down.                                   */

/* Update file checksums. */

#define calcchecksum(ch)        \
{                               \
  extern LONG Ceor, Csum, Crot; \
                                \
  Ceor ^= ch;                   \
  Csum += ch + 1;               \
                                \
  if (Crot & 0x80000000L)       \
  {                             \
    Crot <<= 1;                 \
    Crot ++;                    \
  }                             \
  else                          \
    Crot <<= 1;                 \
                                \
  Crot += ch;                   \
}
