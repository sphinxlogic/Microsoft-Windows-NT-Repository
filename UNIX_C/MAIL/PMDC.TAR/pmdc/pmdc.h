/*
 *	$Source: /source/4.3/watchmkr/pmdc/RCS/pmdc.h,v $
 *	$Author: asp $
 *	$Locker:  $
 *	$Header: pmdc.h,v 2.1 86/01/02 01:03:31 asp Exp $
 */

#include <stdio.h>

extern char *ds();		/* Creates a dynstr from its argument */
extern char *cat();		/* Destructively concatenates 3 dynstr's */
