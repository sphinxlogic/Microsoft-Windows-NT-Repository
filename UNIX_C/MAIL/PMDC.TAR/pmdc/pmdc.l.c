# include "stdio.h"
# define U(x) x
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX BUFSIZ
# define output(c) putc(c,yyout)
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
# define ECHO fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin = {stdin}, *yyout = {stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;
#include    "pmdc.h"
#include    "pmdc.y.h"
#include    <ctype.h>

/* Nuke the output routine */
#undef output
#define output(X) 0
# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:
    	    	;
break;
case 2:
	return(HOME);
break;
case 3:
	return(MODE);
break;
case 4:
	return(ERR);
break;
case 5:
	return(DB);
break;
case 6:
	return(FORMAT);
break;
case 7:
	{ yylval.dynstr = ds(yytext);
			  return(NUM); 
			  }
break;
case 8:
		return(IF);
break;
case 9:
		return(THEN);
break;
case 10:
	return(OTHERWISE);
break;
case 11:
		return(END);
break;
case 12:
		return(NOT);
break;
case 13:
		return(AND);
break;
case 14:
		return(OR);
break;
case 15:
		return(IS);
break;
case 16:
	return(HEADER);
break;
case 17:
		return(BODY);
break;
case 18:
	return(CONTAINS);
break;
case 19:
		return(FROM);
break;
case 20:
		return(TO);
break;
case 21:
		return(LEFTP);
break;
case 22:
		return(RIGHTP);
break;
case 23:
		return(SEMICOLON);
break;
case 24:
		return(RUN);
break;
case 25:
		return(PUT);
break;
case 26:
	return(BARF);
break;
case 27:
{ yytext[yyleng-1] = '\0';
			  yylval.dynstr = ds(yytext+1);
			  return(STRING); }
break;
case 28:
	{ yylval.dynstr = ds(yytext);
			  return(STRING); }
break;
case -1:
break;
default:
fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */
int yyvstop[] = {
0,

-28,
0,

21,
0,

22,
0,

-28,
0,

23,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-1,
-28,
0,

28,
0,

-27,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-8,
-28,
0,

-15,
-28,
0,

-28,
0,

-28,
0,

-14,
-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-20,
-28,
0,

28,
-1,
0,

1,
28,
0,

-1,
0,

27,
0,

-7,
-28,
0,

-13,
-28,
0,

-28,
0,

-28,
0,

-28,
0,

-11,
-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

8,
28,
0,

15,
28,
0,

-28,
0,

-12,
-28,
0,

14,
28,
0,

-28,
0,

-25,
-28,
0,

-24,
-28,
0,

-28,
0,

-28,
0,

20,
28,
0,

1,
0,

7,
28,
0,

-7,
-28,
0,

13,
28,
0,

-17,
-28,
0,

-28,
0,

-28,
0,

11,
28,
0,

-28,
0,

-28,
0,

-19,
-28,
0,

-28,
0,

-2,
-28,
0,

-3,
-28,
0,

12,
28,
0,

-28,
0,

25,
28,
0,

24,
28,
0,

-28,
0,

-9,
-28,
0,

17,
28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

19,
28,
0,

-28,
0,

2,
28,
0,

3,
28,
0,

-28,
0,

-28,
0,

9,
28,
0,

-28,
0,

-28,
0,

-28,
0,

-6,
-28,
0,

-16,
-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

6,
28,
0,

16,
28,
0,

-28,
0,

-28,
0,

-28,
0,

-18,
-28,
0,

-28,
0,

-28,
0,

-5,
-28,
0,

-28,
0,

18,
28,
0,

-4,
-28,
0,

-10,
-28,
0,

5,
28,
0,

-28,
0,

4,
28,
0,

10,
28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-28,
0,

-26,
-28,
0,

26,
28,
0,
0};
# define YYTYPE int
struct yywork { YYTYPE verify, advance; } yycrank[] = {
0,0,	0,0,	1,3,	0,0,	
3,3,	0,0,	0,0,	4,4,	
0,0,	0,0,	1,0,	1,0,	
3,24,	3,24,	0,0,	4,4,	
4,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	2,0,	2,0,	
0,0,	1,0,	0,0,	1,4,	
7,0,	3,0,	9,0,	0,0,	
4,25,	1,5,	1,6,	0,0,	
10,0,	19,0,	0,0,	11,0,	
0,0,	1,7,	7,26,	3,3,	
16,0,	2,0,	4,4,	0,0,	
2,23,	0,0,	12,0,	0,0,	
1,8,	2,5,	2,6,	13,0,	
18,0,	17,0,	21,0,	20,0,	
26,0,	36,62,	36,62,	0,0,	
14,0,	15,0,	0,0,	22,0,	
37,63,	37,63,	0,0,	0,0,	
2,8,	29,0,	26,51,	31,0,	
32,0,	27,0,	39,0,	28,0,	
33,0,	0,0,	0,0,	35,0,	
42,0,	43,0,	36,0,	53,0,	
30,0,	0,0,	1,9,	1,10,	
1,11,	37,0,	1,12,	1,13,	
34,0,	1,14,	1,15,	38,0,	
41,0,	45,0,	1,16,	1,17,	
1,18,	1,19,	9,27,	1,20,	
1,21,	1,22,	2,9,	2,10,	
2,11,	10,28,	2,12,	2,13,	
11,29,	2,14,	2,15,	54,0,	
19,42,	16,38,	2,16,	2,17,	
2,18,	2,19,	12,30,	2,20,	
2,21,	2,22,	12,31,	14,34,	
13,32,	15,36,	17,39,	13,33,	
18,40,	22,45,	18,41,	23,23,	
21,44,	14,35,	20,43,	27,52,	
22,46,	28,53,	15,37,	23,47,	
23,48,	29,55,	24,24,	24,24,	
25,50,	25,50,	30,56,	31,57,	
32,58,	33,59,	35,61,	34,60,	
39,65,	43,69,	28,54,	40,66,	
40,66,	38,64,	42,68,	44,0,	
45,71,	47,49,	41,67,	49,49,	
23,49,	24,24,	53,77,	25,50,	
46,72,	46,72,	55,0,	49,49,	
49,73,	24,24,	24,24,	25,50,	
25,50,	57,0,	23,23,	60,0,	
40,0,	51,74,	51,74,	58,0,	
52,76,	52,76,	59,0,	54,78,	
56,80,	56,80,	61,0,	70,0,	
24,24,	46,0,	25,50,	64,0,	
62,62,	62,62,	63,63,	63,63,	
65,87,	65,87,	67,0,	66,66,	
66,66,	71,0,	51,0,	78,0,	
47,49,	52,0,	49,49,	68,89,	
68,89,	56,0,	69,90,	69,90,	
75,74,	75,74,	84,0,	62,62,	
51,75,	63,63,	44,70,	79,0,	
81,0,	65,0,	66,66,	62,62,	
62,62,	63,63,	63,63,	82,0,	
72,72,	72,72,	66,66,	66,66,	
68,0,	0,0,	88,0,	69,0,	
94,0,	75,0,	95,0,	74,74,	
74,74,	60,84,	62,62,	91,0,	
63,63,	97,0,	99,0,	0,0,	
55,79,	66,66,	57,81,	72,72,	
96,0,	61,85,	58,82,	77,93,	
77,93,	59,83,	64,86,	72,72,	
72,72,	106,0,	74,74,	76,76,	
76,76,	67,88,	83,98,	83,98,	
78,94,	70,91,	74,74,	74,74,	
102,0,	80,80,	80,80,	87,87,	
87,87,	71,92,	72,72,	0,0,	
77,0,	84,99,	79,95,	85,100,	
85,100,	0,0,	76,76,	86,101,	
86,101,	74,74,	82,97,	83,0,	
92,104,	92,104,	76,76,	76,76,	
80,80,	124,0,	87,87,	103,0,	
81,96,	89,89,	89,89,	94,105,	
80,80,	80,80,	87,87,	87,87,	
85,0,	95,106,	107,0,	91,103,	
86,0,	76,76,	88,102,	90,90,	
90,90,	92,0,	93,93,	93,93,	
96,107,	98,98,	98,98,	80,80,	
89,89,	87,87,	99,109,	97,108,	
105,0,	108,115,	108,115,	110,0,	
89,89,	89,89,	111,0,	100,100,	
100,100,	106,113,	90,90,	105,112,	
112,0,	93,93,	113,0,	114,0,	
98,98,	117,0,	90,90,	90,90,	
118,0,	93,93,	93,93,	89,89,	
98,98,	98,98,	108,0,	101,101,	
101,101,	102,110,	100,100,	104,104,	
104,104,	115,115,	115,115,	109,116,	
109,116,	90,90,	100,100,	100,100,	
93,93,	119,0,	103,111,	98,98,	
116,116,	116,116,	120,125,	120,125,	
121,0,	122,0,	101,101,	124,129,	
134,0,	107,114,	104,104,	129,0,	
115,115,	100,100,	101,101,	101,101,	
109,0,	132,0,	104,104,	104,104,	
115,115,	115,115,	133,0,	116,116,	
123,128,	123,128,	136,0,	120,0,	
132,133,	135,0,	110,117,	116,116,	
116,116,	101,101,	125,125,	125,125,	
111,118,	104,104,	137,0,	115,115,	
0,0,	0,0,	0,0,	118,123,	
0,0,	114,121,	128,128,	128,128,	
0,0,	123,0,	116,116,	113,120,	
0,0,	112,119,	117,122,	126,130,	
126,130,	125,125,	127,131,	127,131,	
0,0,	0,0,	130,130,	130,130,	
0,0,	125,125,	125,125,	0,0,	
119,124,	128,128,	0,0,	121,126,	
122,127,	0,0,	131,131,	131,131,	
0,0,	128,128,	128,128,	0,0,	
126,0,	129,132,	0,0,	127,0,	
125,125,	130,130,	138,139,	138,139,	
134,135,	133,134,	139,139,	139,139,	
0,0,	130,130,	130,130,	0,0,	
128,128,	131,131,	0,0,	0,0,	
0,0,	0,0,	0,0,	136,137,	
0,0,	131,131,	131,131,	0,0,	
0,0,	135,136,	0,0,	138,0,	
130,130,	139,139,	0,0,	0,0,	
0,0,	0,0,	137,138,	0,0,	
0,0,	139,139,	139,139,	0,0,	
131,131,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
139,139,	0,0,	0,0,	0,0,	
0,0};
struct yysvf yysvec[] = {
0,	0,	0,
yycrank+-1,	0,		0,	
yycrank+-21,	yysvec+1,	0,	
yycrank+-3,	0,		yyvstop+1,
yycrank+-6,	0,		0,	
yycrank+0,	0,		yyvstop+3,
yycrank+0,	0,		yyvstop+5,
yycrank+-2,	yysvec+3,	yyvstop+7,
yycrank+0,	0,		yyvstop+9,
yycrank+-4,	yysvec+3,	yyvstop+11,
yycrank+-10,	yysvec+3,	yyvstop+13,
yycrank+-13,	yysvec+3,	yyvstop+15,
yycrank+-24,	yysvec+3,	yyvstop+17,
yycrank+-29,	yysvec+3,	yyvstop+19,
yycrank+-38,	yysvec+3,	yyvstop+21,
yycrank+-39,	yysvec+3,	yyvstop+23,
yycrank+-18,	yysvec+3,	yyvstop+25,
yycrank+-31,	yysvec+3,	yyvstop+27,
yycrank+-30,	yysvec+3,	yyvstop+29,
yycrank+-11,	yysvec+3,	yyvstop+31,
yycrank+-33,	yysvec+3,	yyvstop+33,
yycrank+-32,	yysvec+3,	yyvstop+35,
yycrank+-41,	yysvec+3,	yyvstop+37,
yycrank+-146,	0,		yyvstop+39,
yycrank+149,	0,		yyvstop+42,
yycrank+151,	0,		yyvstop+44,
yycrank+-34,	yysvec+3,	yyvstop+46,
yycrank+-51,	yysvec+3,	yyvstop+48,
yycrank+-53,	yysvec+3,	yyvstop+50,
yycrank+-47,	yysvec+3,	yyvstop+52,
yycrank+-62,	yysvec+3,	yyvstop+54,
yycrank+-49,	yysvec+3,	yyvstop+56,
yycrank+-50,	yysvec+3,	yyvstop+58,
yycrank+-54,	yysvec+3,	yyvstop+60,
yycrank+-70,	yysvec+3,	yyvstop+62,
yycrank+-57,	yysvec+3,	yyvstop+64,
yycrank+-60,	yysvec+3,	yyvstop+66,
yycrank+-67,	yysvec+3,	yyvstop+69,
yycrank+-73,	yysvec+3,	yyvstop+72,
yycrank+-52,	yysvec+3,	yyvstop+74,
yycrank+-162,	yysvec+3,	yyvstop+76,
yycrank+-74,	yysvec+3,	yyvstop+79,
yycrank+-58,	yysvec+3,	yyvstop+81,
yycrank+-59,	yysvec+3,	yyvstop+83,
yycrank+-141,	yysvec+3,	yyvstop+85,
yycrank+-75,	yysvec+3,	yyvstop+87,
yycrank+-175,	yysvec+3,	yyvstop+89,
yycrank+-176,	yysvec+23,	yyvstop+92,
yycrank+0,	yysvec+24,	yyvstop+95,
yycrank+-178,	yysvec+23,	yyvstop+98,
yycrank+0,	yysvec+25,	yyvstop+100,
yycrank+-188,	yysvec+3,	yyvstop+102,
yycrank+-191,	yysvec+3,	yyvstop+105,
yycrank+-61,	yysvec+3,	yyvstop+108,
yycrank+-93,	yysvec+3,	yyvstop+110,
yycrank+-152,	yysvec+3,	yyvstop+112,
yycrank+-195,	yysvec+3,	yyvstop+114,
yycrank+-159,	yysvec+3,	yyvstop+117,
yycrank+-165,	yysvec+3,	yyvstop+119,
yycrank+-168,	yysvec+3,	yyvstop+121,
yycrank+-161,	yysvec+3,	yyvstop+123,
yycrank+-172,	yysvec+3,	yyvstop+125,
yycrank+203,	0,		yyvstop+127,
yycrank+205,	0,		yyvstop+130,
yycrank+-177,	yysvec+3,	yyvstop+133,
yycrank+-207,	yysvec+3,	yyvstop+135,
yycrank+210,	0,		yyvstop+138,
yycrank+-184,	yysvec+3,	yyvstop+141,
yycrank+-218,	yysvec+3,	yyvstop+143,
yycrank+-221,	yysvec+3,	yyvstop+146,
yycrank+-173,	yysvec+3,	yyvstop+149,
yycrank+-187,	yysvec+3,	yyvstop+151,
yycrank+239,	0,		yyvstop+153,
yycrank+0,	0,		yyvstop+156,
yycrank+250,	0,		yyvstop+158,
yycrank+-223,	yysvec+3,	yyvstop+161,
yycrank+274,	0,		yyvstop+164,
yycrank+-266,	yysvec+3,	yyvstop+167,
yycrank+-189,	yysvec+3,	yyvstop+170,
yycrank+-205,	yysvec+3,	yyvstop+172,
yycrank+284,	0,		yyvstop+174,
yycrank+-206,	yysvec+3,	yyvstop+177,
yycrank+-213,	yysvec+3,	yyvstop+179,
yycrank+-277,	yysvec+3,	yyvstop+181,
yycrank+-200,	yysvec+3,	yyvstop+184,
yycrank+-294,	yysvec+3,	yyvstop+186,
yycrank+-298,	yysvec+3,	yyvstop+189,
yycrank+286,	0,		yyvstop+192,
yycrank+-220,	yysvec+3,	yyvstop+195,
yycrank+312,	0,		yyvstop+197,
yycrank+326,	0,		yyvstop+200,
yycrank+-229,	yysvec+3,	yyvstop+203,
yycrank+-303,	yysvec+3,	yyvstop+205,
yycrank+329,	0,		yyvstop+208,
yycrank+-222,	yysvec+3,	yyvstop+211,
yycrank+-224,	yysvec+3,	yyvstop+213,
yycrank+-238,	yysvec+3,	yyvstop+215,
yycrank+-231,	yysvec+3,	yyvstop+217,
yycrank+332,	0,		yyvstop+219,
yycrank+-232,	yysvec+3,	yyvstop+222,
yycrank+346,	0,		yyvstop+224,
yycrank+366,	0,		yyvstop+227,
yycrank+-258,	yysvec+3,	yyvstop+230,
yycrank+-285,	yysvec+3,	yyvstop+232,
yycrank+370,	0,		yyvstop+234,
yycrank+-314,	yysvec+3,	yyvstop+237,
yycrank+-247,	yysvec+3,	yyvstop+239,
yycrank+-296,	yysvec+3,	yyvstop+241,
yycrank+-340,	yysvec+3,	yyvstop+243,
yycrank+-374,	yysvec+3,	yyvstop+246,
yycrank+-317,	yysvec+3,	yyvstop+249,
yycrank+-320,	yysvec+3,	yyvstop+251,
yycrank+-326,	yysvec+3,	yyvstop+253,
yycrank+-328,	yysvec+3,	yyvstop+255,
yycrank+-329,	yysvec+3,	yyvstop+257,
yycrank+372,	0,		yyvstop+259,
yycrank+383,	0,		yyvstop+262,
yycrank+-331,	yysvec+3,	yyvstop+265,
yycrank+-334,	yysvec+3,	yyvstop+267,
yycrank+-355,	yysvec+3,	yyvstop+269,
yycrank+-385,	yysvec+3,	yyvstop+271,
yycrank+-362,	yysvec+3,	yyvstop+274,
yycrank+-363,	yysvec+3,	yyvstop+276,
yycrank+-407,	yysvec+3,	yyvstop+278,
yycrank+-283,	yysvec+3,	yyvstop+281,
yycrank+417,	0,		yyvstop+283,
yycrank+-438,	yysvec+3,	yyvstop+286,
yycrank+-441,	yysvec+3,	yyvstop+289,
yycrank+429,	0,		yyvstop+292,
yycrank+-369,	yysvec+3,	yyvstop+295,
yycrank+445,	0,		yyvstop+297,
yycrank+457,	0,		yyvstop+300,
yycrank+-375,	yysvec+3,	yyvstop+303,
yycrank+-380,	yysvec+3,	yyvstop+305,
yycrank+-366,	yysvec+3,	yyvstop+307,
yycrank+-387,	yysvec+3,	yyvstop+309,
yycrank+-384,	yysvec+3,	yyvstop+311,
yycrank+-396,	yysvec+3,	yyvstop+313,
yycrank+-469,	yysvec+3,	yyvstop+315,
yycrank+473,	0,		yyvstop+318,
0,	0,	0};
struct yywork *yytop = yycrank+532;
struct yysvf *yybgin = yysvec+1;
char yymatch[] = {
00  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,011 ,012 ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
011 ,01  ,'"' ,01  ,01  ,01  ,01  ,01  ,
011 ,011 ,01  ,01  ,01  ,01  ,01  ,01  ,
'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,
'0' ,'0' ,01  ,011 ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
0};
char yyextra[] = {
0,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,0,0,0,
1,1,1,1,1,0,0,0,
0};
#ifndef lint
static	char ncform_sccsid[] = "@(#)ncform 1.1 86/07/08 SMI"; /* from S5R2 1.2 */
#endif

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
yylook(){
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych, yyfirst;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	yyfirst=1;
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank && !yyfirst){  /* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
			*yylastch++ = yych = input();
			yyfirst=0;
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
yyback(p, m)
	int *p;
{
if (p==0) return(0);
while (*p)
	{
	if (*p++ == m)
		return(1);
	}
return(0);
}
	/* the following are only used in the lex library */
yyinput(){
	return(input());
	}
yyoutput(c)
  int c; {
	output(c);
	}
yyunput(c)
   int c; {
	unput(c);
	}
