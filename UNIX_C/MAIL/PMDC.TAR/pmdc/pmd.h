/*
 *	$Source: /source/4.3/watchmkr/pmdc/RCS/pmd.h,v $
 *	$Author: rlk $
 *	$Locker:  $
 *	$Header: pmd.h,v 2.4 86/10/17 15:29:38 rlk Exp $
 */

#define MAXLINELEN 2000		/* Longest line that can be read */

/* Externals for the pmd runtime package */
#include <stdio.h>
#include <ctype.h>

/* These should appear in lex.yy.c */
extern int  ppmode;
extern char *pphome;
extern char *pperrf;
extern char *ppdbfile;
extern char *ppformat;
extern ppact();
extern FILE *ppin;
extern char ppline[MAXLINELEN];

/* These are in runtime.c */
extern ppputact();
extern pprunact();
extern ppbarfact();
extern pphead();
extern ppbody();
