
typedef union  {
	char *dynstr;
} YYSTYPE;
extern YYSTYPE yylval;
# define HOME 257
# define MODE 258
# define ERR 259
# define DB 260
# define FORMAT 261
# define IF 262
# define THEN 263
# define OTHERWISE 264
# define END 265
# define NOT 266
# define AND 267
# define OR 268
# define LEFTP 269
# define RIGHTP 270
# define IS 271
# define HEADER 272
# define BODY 273
# define CONTAINS 274
# define FROM 275
# define TO 276
# define STRING 277
# define NUM 278
# define RUN 279
# define PUT 280
# define BARF 281
# define SEMICOLON 282
