/**			help.c			**/

/*** help routine for MSG program 

     (C) Copyright 1985, Dave Taylor

***/

#include "headers.h"

help()
{
	/*** help me!  Read file 'helpfile' and echo to screen ***/

	FILE *hfile;
	char buffer[SLEN];
	int  lines=0;

	dprint0("help()\n");

	sprintf(buffer, "%s/%s", helphome, helpfile);
	if ((hfile = fopen(buffer,"r")) == NULL) {
	  error1("couldn't open helpfile %s",buffer);
	  return(FALSE);
	}
	
	ClearScreen();

	while (fgets(buffer, SLEN, hfile) != NULL) {
	  if (lines > LINES-3) {
	    PutLine(LINES,0,"Press any key to continue: ");
	    (void) ReadCh();
	    lines = 0;
	    ClearScreen();
	    printf("%s\r", buffer);
	  }
	  else 
	    printf("%s\r", buffer);
	  lines++;
	}

	PutLine(LINES,0,"Please type <space> to return: ");

	(void) ReadCh();
	clear_error();

	return(TRUE);
}
