/**		quit.c		**/

/** quit: leave the current mailbox and quit the program.
  
    (C) Copyright 1985, Dave Taylor
**/

#ifndef TRUE
#define TRUE	1
#endif

quit()
{
	/* a wonderfully short routine!! */

	leave_mbox();

	leave();
}

resync()
{
	/* leave the current mailbox and read it in again.  This
	   is used as needed to allow editing of messages and so
	   on... */

	leave_mbox();

	error("reading mailfile in again...");

	newmbox(2, TRUE);
	showscreen();
}
