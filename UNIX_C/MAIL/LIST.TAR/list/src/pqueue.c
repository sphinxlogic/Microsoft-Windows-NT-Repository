/*
  ----------------------------------------------------------------------------
  |                    MAIL QUEUE PROCESSING ROUTINES                        |
  |                                                                          |
  |                             Version 1.0                                  |
  |                                                                          |
  |                (or, when Computer Science gets to you)                   |
  |                                                                          |
  |                    Written by Anastasios Kotsikonas                      |
  |                           (tasos@cs.bu.edu)                              |
  |                                                                          |
  | AGREEMENT: This software can be used and distributed freely as long      |
  | as you do not remove or alter the Copyright notice in the file defs.h;   |
  | this notice is #define'd in the symbol VERSION. Although you may alter   |
  | the code provided, you may not alter the functions create_header()       |
  | and create_multi_recipient_header() in list.c and listserv.c.            |
  | By using this software you are bound by this agreement.                  |
  | This software comes with no warranties and cannot be sold for profit.    |
  | The AGREEMENT and COPYRIGHT notices should be included in all source     |
  | files when distributing this software.                                   |
  | COPYRIGHT: Copyright (c) 1991, Anastasios C. Kotsikonas                  |
  ----------------------------------------------------------------------------

  The 'system' mailmethod is used to attempt another delivery of the
  specified file. If it cannot be done, the file is queued again.
*/

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include "defs.h"
#include "struct.h"
#include "global.h"
#include "pqueue.h"

extern BOOLEAN sysmail (char *);

void   main (int, char **, char **);
void   usage (void);
void   gexit (void);

void main (int argc, char **argv, char **envp)
{
  char msg [MAX_LINE], *options = "eD";
  int c;
  FILE *f;
  struct stat stat_buf;
  extern char *optarg;
  extern int optopt, optind;

  while ((c = getopt (argc, argv, options)) != EOF)
    switch ((char) c) {
    case 'e': tty_echo = TRUE; break;
    case 'D': debug = TRUE; break;
    case '?':
    default:
      usage ();
  }
  if (argc < 2)
    fprintf (stderr, "pqueue: filename(s) missing.\n"),
    exit (3);
#ifndef _MINIX
  if (lockf (open (PQUEUE_LOCK_FILE, O_RDWR), F_TLOCK, 0))
    fprintf (stderr, "pqueue: Unable to lock %s. Aborting.\n",
	     PQUEUE_LOCK_FILE),
    exit (2);
#endif
  init_signals();
  catch_signals();
  if ((report = fopen (REPORT_PQUEUE, "a")) == NULL)
    fprintf (stderr, "pqueue: Could not open %s\n", REPORT_PQUEUE),
    exit (1);
  if ((f = fopen (PID_PQUEUE, "w")) != NULL)
    fprintf (f, "%d", getpid()),
    fclose (f);
  signal (SIGINT, gexit);
  while (--argc >= optind) { /* main loop */
    if (stat (argv [argc], &stat_buf))
      sprintf (msg, "\nmain(): Could not stat %s", argv [argc]),
      report_progress (report, msg, TRUE),
      exit (1);
    if (sysmail (argv [argc]))
      if (unlink (argv [argc]))
	sprintf (msg, "\nmain(): Could not unlink file %s", argv [argc]),
 	report_progress (report, msg, TRUE),
	exit (1);
  }
  fclose (report);
  gexit ();
}

void usage ()
{
  fprintf (stderr, "Usage: pqueue [-e] [-D] <files>\n\
-e: Echo reports to the screen.\n\
-D: Turn debug on.\n");
  exit (3);
}

/*
  Graceful exit. Remove pid file.
*/

void gexit ()
{
  unlink (PID_PQUEUE);
  exit (0);
}
