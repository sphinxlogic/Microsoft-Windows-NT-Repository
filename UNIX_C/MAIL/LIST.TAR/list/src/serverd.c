/*
  ----------------------------------------------------------------------------
  |                       DISCUSSION LIST SYSTEM DAEMON			     |
  |                                                                          |
  |                              Version 3.0                                 |
  |                                                                          |
  |                (or, when Computer Science gets to you)                   |
  |                                                                          |
  |                    Written by Anastasios Kotsikonas                      |
  |                           (tasos@cs.bu.edu)                              |
  |                                                                          |
  | AGREEMENT: This software can be used and distributed freely as long      |
  | as you do not remove or alter the Copyright notice in the file defs.h;   |
  | this notice is #define'd in the symbol VERSION. Although you may alter   |
  | the code provided, you may not alter the functions create_header() in    |
  | list.c and listserv.c. By using this software you are bound by this      |
  | agreement.                                                               |
  | This software comes with no warranties and cannot be sold for profit.    |
  | The AGREEMENT and COPYRIGHT notices should be included in all source     |
  | files when distributing this software.                                   |
  | COPYRIGHT: Copyright (c) 1991, Anastasios C. Kotsikonas                  |
  ----------------------------------------------------------------------------

  Spawn list or listserv upon arrival of new messages. Send mail to
  MANAGER if something went wrong (only if using UCB mail).
  serverd will not spawn if the current load average is above max_load
  and the -l flag is on, until it has delayed MAX_TRIES * 30 seconds.
  serverd communicates with listerv via exit status 6 and 7; this are
  the request to shutdwon/restart the system; on status 7, serverd spawns
  start and dies; if it cannot restart, it sends mail and commits suicide.
  serverd reports to REPORT_SERVERD.

  COMMAND LINE OPTIONS:
    -1: Execute only once -- to be used with cron.
    -l: Enforce restrictions based on the current load average.
    -e: Echo reports to the screen.

  EXIT CODES:
    0: OK
    1: Could not open file
    2: Could not lock file
    3: Command line option error
    4: Syntax error in file
    5: Could not spawn
    6: Shutdown request
    7: Restart request
    8: Received system signal
    9: Too many multiple recipients
   10: Could not connect to server
   11: Server broke connection
   12: Could not create socket
   13: No such host
   14: Could not connect to port
   15: Connection timed out
   16: Malloc failed
*/

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include "defs.h"
#include "serverd.h"
#include "struct.h"
#include "global.h"

#ifdef __STDC__
#include <stdarg.h>
extern int  syscom (char *, ...);
#else
#include <varargs.h>
extern int  syscom ();
#endif
extern double atof ();
extern int  sys_config (FILE *, SYS *);
extern int  getopt (int, char **, char *);
extern void init_signals (void);
extern void catch_signals (void);

void   main (int, char **, char **);
void   serverd_config (char *alias);
void   usage (void);
void   gexit (void);

char *exit_string[] = {  /* Define exit status strings */
/* 0 */ "OK", 
/* 1 */ "Could not open file", 
/* 2 */ "Could not lock file",
/* 3 */ "Command line option error",
/* 4 */ "Syntax error in file",
/* 5 */ "Could not spawn",
/* 6 */ "Shutdown request",
/* 7 */ "Restart request",
/* 8 */ "Received system signal",
/* 9 */ "Too many multiple recipients",
/* 10 */"Could not connect to server",
/* 11 */"Server broke connection",
/* 12 */"Could not create socket",
/* 13 */"No such host",
/* 14 */"Could not connect to port",
/* 15 */"Could not deliver mail",
/* 16 */"Malloc failed",
/* 17 */ "Unknown exit code"
};
  
void main (int argc, char **argv, char **envp)
{
  struct stat stat_buf;
  int i, status, try, fd, nlists;
  FILE *f, *loadf, *report;
  float load, max_load;
  BOOLEAN loadr = FALSE, execute_once = FALSE;
  char list [MAX_LINE];
  char server [MAX_LINE];
  char msg [MAX_LINE];
  int c;
  char *options = "1l:e";
  extern char *optarg;
  extern int optopt;

  while ((c = getopt (argc, argv, options)) != EOF)
    switch ((char) c) {
      case '1': execute_once = TRUE; break;
      case 'e': tty_echo = TRUE; break;
      case 'l': loadr = TRUE; 
		max_load = (float) atof (optarg); 
		break;
      case ':': 
        fprintf (stderr, "serverd:  Option '%c' requires an argument.\n",
		 optopt);
	exit (3);
      case '?':
      default:
	usage ();
    }
#ifndef _MINIX
  if (lockf ((fd = open (SERVERD_LOCK_FILE, O_RDWR)), F_TLOCK, 0))
    fprintf (stderr, "serverd: Unable to lock %s. Aborting.\n", 
             SERVERD_LOCK_FILE),
    exit (2);
#endif
  if ((report = fopen (REPORT_SERVERD, "a")) == NULL)
    fprintf (stderr, "serverd: Could not open %s\n", REPORT_SERVERD),
    exit (1);

  if ((f = fopen (PID_SERVERD, "w")) != NULL)
    fprintf (f, "%d", getpid()),
    fclose (f);
  signal (SIGINT, gexit);
  init_signals();
  catch_signals ();

  nlists = sys_config (report, &sys);
  while (007) {
    for (i = 0; i < nlists; ++i) {
      serverd_config (sys.lists[i].alias);
      if (!stat (list_mail_f, &stat_buf) && stat_buf.st_size > 0) {
	sprintf (msg, "\n--- NEW MAIL FOR %s ---\n", sys.lists[i].alias);
	report_progress (report, msg, FALSE);
        if (loadr) { /* enforce restrictions */
          try = 0;
        again_list:
          syscom ("%s | %s -F, '{ print $4 }' | %s -d' ' -f5 > %s",
		  UPTIME, AWK, CUT, LOAD_FILE);
          if ((loadf = fopen (LOAD_FILE, "r")) == NULL)
	    sprintf (msg, "\nCould not open %s", LOAD_FILE),
	    report_progress (report, msg, TRUE),
	    exit (1);
          fscanf (loadf, "%f", &load);
          fclose (loadf);
          unlink (LOAD_FILE);
          if (load > max_load && try < MAX_TRIES) {
	    ++try;
            sleep (30);
	    goto again_list;
          }
        }
	RESET (list);
	sprintf (list, "%s %s %s", LIST, sys.lists[i].alias,
		 sys.lists[i].cmdoptions);
	report_progress (report, list, TRUE);
        if ((status = system (list)) > 127) {   /* run list */
          sprintf (msg, "serverd died: LIST: %s", exit_string[status / 256]);
          if (sys.options & BSD_MAIL)
	    syscom ("%s -s \"%s\" %s < /dev/null", UCB_MAIL, msg, sys.manager);
	  report_progress (report, msg, TRUE);
	  exit (status / 256);
        }
        else if (status == 127) {
	  sprintf (msg, "serverd died: could not execute shell for list");
	  if (sys.options & BSD_MAIL)
	    syscom ("%s -s \"%s\" %s < /dev/null", UCB_MAIL, msg, sys.manager);
	  report_progress (report, msg, TRUE);
	  exit (5);
        }
      }
      if (sys.frequency > 0)
        sleep (sys.frequency);     /* do a quickie to The Spy Who Loved Him */
    }
    if (!stat (SERVER_MAIL_FILE, &stat_buf) && stat_buf.st_size > 0) {
      report_progress (report, "\n--- NEW MAIL FOR SERVER ---\n", FALSE);
      if (loadr) { /* Enforce restrictions */
        try = 0;
      again_server:
        syscom ("%s | %s -F, '{ print $4 }' | %s -d' ' -f5 > %s",
                UPTIME, AWK, CUT, LOAD_FILE);
        if ((loadf = fopen (LOAD_FILE, "r")) == NULL)
          sprintf (msg, "\nCould not open %s", LOAD_FILE),
          report_progress (report, msg, TRUE),
          exit (1);
        fscanf (loadf, "%f", &load);
        fclose (loadf);
        unlink (LOAD_FILE);
        if (load > max_load && try < MAX_TRIES) {
          ++try;
          sleep (30);
          goto again_server;
        }
      }
      RESET (server);
      sprintf (server, "%s %s", SERVER, sys.server.cmdoptions);
      report_progress (report, server, TRUE);
      if ((status = system (server)) > 127) { /* run server */
        sprintf (msg,"serverd died: LISTSERV: %s", exit_string[status / 256]);
	if (sys.options & BSD_MAIL)
	  syscom ("%s -s \"%s\" %s < /dev/null", UCB_MAIL, msg, sys.manager);
	report_progress (report, msg, TRUE);
	if (status == 6 * 256)  /* Shutdown request */
	  unlink (PID_SERVERD),
	  exit (6);
	if (status == 7 * 256) {  /* Restart request */
	  execl (START, START_OPTIONS, START_OPTIONS, NULL);
	  sprintf (msg, "serverd commits suicide: Could not restart system");
          report_progress (report, msg, TRUE);
          if (sys.options & BSD_MAIL)
            syscom ("%s -s \"%s\" %s < /dev/null", UCB_MAIL, msg, sys.manager);
	  exit (5);
	}
	else
	  exit (status / 256);
      }
      else if (status == 127) {
	sprintf (msg, "serverd died: could not execute shell for listserv");
	if (sys.options & BSD_MAIL)
	  syscom ("%s -s \"%s\" %s < /dev/null", UCB_MAIL, msg, sys.manager);
	report_progress (report, msg, TRUE);
	exit (5);
      }
    }
    if (execute_once)
      gexit();
    if (sys.frequency > 0)
      sleep (sys.frequency);     /* do a quickie to Money Penny */
  }
}

void serverd_config (char *alias)
{
  setup_string (list_mail_f, alias, LIST_MAIL_FILE);
}

void usage ()
{
  fprintf (stderr, "Usage: serverd [-1] [-e] [-l load]\n\
-1: Execute only once.\n\
-e: Echo reports to the screen.\n\
-l: Enforce load restrictions.\n");
  exit (3);
}

/*
  Graceful exit. Remove pid file.
*/

void gexit ()
{
  unlink (PID_SERVERD);
  exit (0);
}
