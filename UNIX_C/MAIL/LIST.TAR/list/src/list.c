/*
  ----------------------------------------------------------------------------
  |		   DISCUSSION LIST MAIL-DISTRIBUTION PROGRAM		     |
  |									     |
  |				 Version 2.6				     |
  |                                                                          |
  |                (or, when Computer Science gets to you)                   |
  |									     |
  |		       Written by Anastasios Kotsikonas                      |
  |		    	      (tasos@cs.bu.edu)			     	     |
  |	                                                                     |
  | AGREEMENT: This software can be used and distributed freely as long      |
  | as you do not remove or alter the Copyright notice in the file defs.h;   |
  | this notice is #define'd in the symbol VERSION. Although you may alter   |
  | the code provided, you may not alter the functions create_header()       |
  | and create_multi_recipient_header() in list.c and listserv.c.	     |
  | By using this software you are bound by this agreement.		     |
  | This software comes with no warranties and cannot be sold for profit.    |
  | The AGREEMENT and COPYRIGHT notices should be included in all source     |
  | files when distributing this software.				     |
  | COPYRIGHT: Copyright (c) 1991, Anastasios C. Kotsikonas                  |
  ----------------------------------------------------------------------------

  NOTE: Anything appearing in capital letters refers to #define's in the
  header files provided.

  PURPOSE: Create discussion lists. Members of the list send messages to
  them, and each of these messages is forwarded to the rest of the members.
  Any message(s) not from subscribers are returned to the original senders,
  or can be forwarded to MANAGER. Messages from "undesired" senders can be
  ignored by placing their email addresses in the IGNORED file (this would
  usually include root and the list's login name to avoid infinite loops).

  OVERVIEW: A discussion list resides in a subdirectory of /usr/server/lists
  whose name is the list's alias (in the aliases file) in capital letters.
  When the program is killed or it abnormally dies, a message
  is sent to MANAGER (if using UCB mail) along with a copy of the current 
  report file (more on that below). Use the -1 flag when running the
  program. The discussion list to be processed is given as argument to the
  -L option in upper case. Any progress is reported to the list's REPORT_LIST
  file and to the administrator's terminal. All messages sent to this list are
  saved in the MBOX file. The program can be run as stand-alone, or in
  conjunction with the other programs provided (start, serverd and listserv).
  Please note that a line beginning with "From " and another one beginning
  with "From: " must appear in the header of each message, and a blank line
  must separate the header from the body of the message. Discussion lists
  can be linked with peers and have access to news groups.

  COMMAND LINE OPTIONS:
    -r: Restricted mail; since it is possible to have another distribution
        list at some other site as a subscriber, then the following problem
	arises: if a message is coming from a member of the other list, his/
	her message was forwarded to the members of that list from the other
	site; we do not want to send this message back to them, because they
	will receive this message twice. Therefore, when this flag is on,
	for every message received, its sender is checked against a list
	of "restricted" mail addresses (a subset of the subscribers). If a
	match is found, then mail is forwarded to the people listed in the
	filename following this email address -- for the appropriate format
	see below. If no match is found, then the message is forwarded to
	to all of the subscribers. See also below.
    -1: Execute only once; this is used when the program is running in
        conjunction with listserv, in which case execution is interchanged
        and controlled by the serverd program.
    -e: Echo reports to the screen.
    -s: Do not check for subscriptions.
    -p: By default, replies to posted messages go to the list; this option 
        forces replies to be forwarded to the original author.
    -m: Usually, each outgoing message has a single recipient. This switches
        to multiple recipients -- the argument to it is the number of
	multiple recipients to be included in this message.
    -v: Display the version number of this package.
    -f: Forward any message(s) from unsubscribed senders to MANAGER. This
        way, any ordinary user account can be used as the list's address.
    -L: The argument following is the list name to process.
    -D: Turn debug on. A transaction of the last email sent out is kept
        in the files /usr/server/sent and /usr/server/received. This assumes
        use of the 'system' mail method.

  DISCLAIMER: If for any reason during the use of this program, implied
  or not, you happen to die, or suffer any injury of any kind (physical
  or mental), I, Mr. Anastasios Kotsikonas, AM NOT RESPONSIBLE at all.
  In fact, I AM NOT RESPONSIBLE FOR ANYTHING that may happen to you, or
  your computer and operating system.

  PLEASE: If you upgrade the code, send me a copy, and do not even attempt to
  put your name for credit. Send to tasos@cs.bu.edu or tasos@bucsf.bu.edu.

  EXIT CODES:
    0: OK
    1: Could not open file
    2: Could not lock file
    3: Command line option error
    4: Syntax error in file
    5: Could not spawn
    6: Shutdown request
    7: Restart request
    8: Received system signal
    9: Too many multiple recipients

  ENJOY!!!

  Approximate algorithm:
  {
    Place a lock so that no other list program will access any files.
    Read LIST_MAIL_FILE
    If new message(s) have arrived then {
      Append messages to MBOX
      For each message do {
        If the person is in the IGNORED file, go on to the next message.
        If the person sending it is subscribed (listed in SUBSCRIBERS) then
	  If the person does not acknowledge his/her message, he/she
	    never receives his/her message back
	  If the -r flag is on then
	    check if the sender is listed in RESTRICTED
	    If so then
	      forward mail to all people listed in the file after the 
	      restricted-sender's address
	    Else
	      distribute to all people in SUBSCRIBERS
	  Else
	    distribute to all people in SUBSCRIBERS, NEWSF (only to those
	    newsgroups that are supposed to received messages) and PEERS
	    according to the following:
	      Email from regular SUBSCRIBERS is sent to NEWS and PEERS as well
	      Email from news is sent to SUBSCRIBERS and PEERS
	      Email from peers is sent to SUBSCRIBERS and NEWS
	Else if it news feed (listed in NEWSF)
	  distribute to SUBSCRIBERS
        Else 
          if -f specified, forward it to MANAGER; otherwise return the
	  message to the sender.
      }
      Remove mail files.
    }
    Repeat process after IDLE_TIME, or die if -1 specified.
  }

  Required files:
    SUBSCRIBERS     <-- The list of subscribed people
    ALIASES	    <-- Aliases of email addresses of subscribers, news & peers
    NEWSF	    <-- List of news groups
    PEERS	    <-- List of peer lists
    RESTRICTED      <-- Addresses of senders whose messages
                        require special handling (usually 
		        addresses of other lists): mail is 
			forwarded only to people found in the 
			file after the sender's address; see below
    IGNORED         <-- The list of undesired people
    LIST_LOCK_FILE  <-- Lock file

  Input files:
    LIST_MAIL_FILE  <-- File where new messages go
    MAIL_COPY       <-- Copy of this file (actual work file)
    MSG_NO          <-- Current message count
    SUBSCRIBERS
    RESTRICTED
    IGNORED

  Output files:
    MBOX            <-- A log of all messages sent to date
    REPORT_LIST     <-- Progress report
    HEADERS	    <-- A log of all emails sent (just the sender's address)
    MSG             <-- Body of message (no header)
    MSG_NO          <-- Write last message count
    MAILFORWARD     <-- Completed message (with header and a copy
    			of MSG) to be forwarded

  Format of the SUBSCRIBERS file:
    One entry per line; each entry is the full email address of the subscriber
    as it appears in the "From " field, followed by the word "ACK" (in which
    case his/her message will be sent back to him/her as an acknowledgement)
    "NOACK" (the opposite), or POSTPONE (no mail will be sent until the
    user changes mode again), followed by the subscriber's name 
    -- this option may be
    reset by the subscriber at any moment by sending a proper request to 
    listserv. Do not include any blank lines.

  Format of the RESTRICTED file:
    One entry per line; each entry is the full email address of the
    subscriber, followed by a file name where email addresses of recipients
    are listed (just like in the SUBSCRIBERS file).When mail arrives from a 
    sender listed in the RESTRICTED file and the -r flag is on, then mail 
    will not be forwarded to SUBSCRIBERS, but instead to the people 
    listed in the file following the restricted-sender's address. Example:
      tasos@bucsf.bu.edu  /grad/tasos/.recipients
      tasos@cs.bu.edu     /grad/tasos/.otherrecipients
    If the recipient file given is the word "NONE", then no one will receive
    any messages. This is useful in the case that other distribution sites
    are subscribers and do forward the message back to the sender, 
    in which case we protect ourselves from multiple reception of the same
    messages. 
    For example, when two (or more) lists are mutual subscribers, and a 
    message originated by someone in our list, this message, after being 
    distributed locally, is sent to the other list; if the other site does
    send messages back to the sender, this message will be forwarded to us
    to be distributed again, something which is highly undesirable. 
    This precludes that the other site sends messages identified only by
    their original senders, something which is unlikely but possible.
    In this case, we would put our list as one of the entries in the 
    RESTRICTED file, with the word NONE next to it. Do not include 
    any blank lines.

  Format of the PEERS file:
    One entry per line -- the email address of the peer list, followed
    by its mail mode (NOACK), followed by the remote alias (how the peer list
    is known in the remote host), followed by the email address of the
    remote server that handles the remote peer list.

  Format of the NEWSF file:
    One entry per line -- the email address of the news group, followed
    by its mail mode (POSTPONE or NOACK), followed by the news group's name.

  Format of the IGNORED file:
    One entry per line -- the email addresses of the people whose messages
    are to be ignored. This is a good place to put root, sys and other
    such undesired logins.

  Format of the ALIASES file:
    One entry per line -- the new alias followed by the email address the
    user is subscribed with.

  Recommended usage:
    % list [-r] -L ALIAS &
  or
    % list [-r] -1 -L ALIAS

*/

#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include "defs.h"
#include "list.h"
#include "struct.h"
#include "global.h"

/* 
  Function prototypes:
*/

#ifdef __STDC__
#include <stdarg.h>
extern int  syscom (char *, ...);
#else
#include <varargs.h>
extern int  syscom ();
#endif
extern int  sys_config (FILE *, SYS *);
extern void report_progress (FILE *, char *, int);
extern void setup_string (char *, char *, char *);
extern void init_signals (void);
extern void catch_signals (void);
extern void get_list_name (char *, char *);
extern void extract_subscriber (FILE *, char *);
extern void extract_origin (char *);
extern int  get_list_id (char *, SYS *, int);
extern int  getopt (int, char **, char *);
extern char *upcase (char *);
extern char *locase (char *);
extern void shrink (char *);
extern void distribute (FILE *, void (*)(char *, char *, unsigned short int),
			FILE *, char *, char *, char *, char *);
extern BOOLEAN sysmail (char *);
extern BOOLEAN strinstr (char *, char *, char *);
extern BOOLEAN ignore_sender (FILE *, char *, FILE *);

void   main (int, char **, char **);
void   create_header (FILE **, char *, char *, char *, char *, char *);
void   create_multi_recipient_header (FILE **, char *, char *, char *, char *,
				      char *, int);
void   create_news_header (FILE **, char *, char *, char *, char *, char *);
void   create_gate_header (FILE **, char *, char *, char *, char *, char *,
			   char *);
void   process_message (char *, char *, BOOLEAN);
void   do_distribute (FILE *, char *, BOOLEAN, char *, char *, char *, char *,
		      char *, FILE *, BOOLEAN, BOOLEAN);
BOOLEAN copy_msg (FILE *, BOOLEAN, char *);
void   sendmail (char *, BOOLEAN, BOOLEAN, int, int, char *);
void   usage (void);
void   list_config (char *);
void   version (void);
void   gexit (void);

/*
  The control structure of the mail-distributor. Check if mail has arrived.
  If so, copy it to MAIL_COPY and proceed to lower level.
*/

void main (int argc, char **argv, char **envp)
{
  struct stat stat_buf;
  char command [MAX_LINE], *options = "1fvrL:em:spD";
  int c;
  char error [MAX_LINE];
  int nlists;
  FILE *f;
  extern char *optarg;
  extern int optopt;

  while ((c = getopt (argc, argv, options)) != EOF)
    switch ((char) c) {
      case '1': execute_once = TRUE; break;
      case 'f': errors_to_manager = TRUE; break;
      case 'r': send_to_subscribers = FALSE; break;
      case 'L': list_alias = optarg; break;
      case 'e': tty_echo = TRUE; break;
      case 's': do_not_check_subscriptions = TRUE; break;
      case 'p': article_replies_to_author = TRUE; break;
      case 'v': version ();
      case 'D': debug = TRUE; break;
      case 'm':
	multi_recip = TRUE;
	if ((maxrecipients = atoi (optarg)) < 1)
	  fprintf (stderr, "-m %d -- yeah, right!\n", maxrecipients),
	  exit (3);
	break;
      case ':': 
	fprintf (stderr, "list: Option '%c' requires an argument.\n", optopt);
	exit (3);
      case '?':
      default:
	usage ();
    }
#ifndef _MINIX
  if (lockf (open (LIST_LOCK_FILE, O_RDWR), F_TLOCK, 0))
    fprintf (stderr, "list: Unable to lock %s. Aborting.\n", LIST_LOCK_FILE),
    exit (2);
#endif
  init_signals();
  catch_signals();
  list_config (list_alias);
  if ((report = fopen (report_listf, "a")) == NULL)
    if ((report = fopen (REPORT_LIST, "a")) == NULL)
      fprintf (stderr, "list: Could not open %s and %s\n", report_listf,
	       REPORT_LIST),
      exit (1);
  if (list_alias == NULL)
    report_progress (report, "\nlist: No list to process", TRUE),
    exit (3);
  nlists = sys_config (report, &sys);
  if ((listid = get_list_id (list_alias, &sys, nlists)) < 0)
    sprintf (error, "\nlist: Unknown list %s", list_alias),
    report_progress (report, error, TRUE),
    exit (3);
  if (!execute_once)
    printf ("%s\n", VERSION);
  if (sys.options & USE_ENV_VAR) {
    if ((sys.mail.method = (char *) malloc (256 * sizeof (char))) == NULL)
      report_progress (report, "\nmain(): malloc failed", TRUE),
      exit (16);
    sprintf (sys.mail.method, "env - %s=%s %s ", sys.mail.env_var,
             sys.lists[listid].address, sys.mail.mail_prog);
  }
  if ((msg_no = fopen (msg_nof, "r")) != NULL)
    fscanf (msg_no, "%d %d\n", &public_msg, &returned_msg),
    fclose (msg_no);

  if (multi_recip)
    if ((multi_recipients = (char **) malloc (maxrecipients * sizeof (char *)))
	== NULL)
      report_progress (report, "\nmain(): malloc failed", TRUE),
      exit (16);

  if ((f = fopen (PID_LIST, "w")) != NULL)
    fprintf (f, "%d", getpid()),
    fclose (f);
  signal (SIGINT, gexit);

  do {
    if (!stat (list_mail_f, &stat_buf) && stat_buf.st_size > 0) {
      syscom ("cp %s %s", list_mail_f, mail_copyf);
      syscom ("cat %s >> %s", mail_copyf, mboxf);
      syscom ("echo >> %s", mboxf);
      syscom ("touch %s", list_moderated_f);
      syscom ("chmod 666 %s", list_moderated_f);
      if (!unlink (list_mail_f))
	syscom ("touch %s", list_mail_f), /* rewrite file */
	syscom ("chmod 666 %s", list_mail_f);
      if ((mail = fopen (mail_copyf, "r")) == NULL)
	sprintf (error, "\nlist: Could not open %s", mail_copyf),
	report_progress (report, error, TRUE),
	exit (1);
      if ((subscribers = fopen (subscribersf, "r")) == NULL)
        sprintf (error, "\nlist: Could not open %s", subscribersf),
        report_progress (report, error, TRUE),
	exit (1);
      if ((news = fopen (newsf, "r")) == NULL)
	sprintf (error, "\nlist: Could not open %s", newsf),
	report_progress (report, error, TRUE),
	exit (1);
      if ((peers = fopen (peersf, "r")) == NULL)
	sprintf (error, "\nlist: Could not open %s", peersf),
	report_progress (report, error, TRUE),
	exit (1);
      if ((restricted = fopen (restrictedf, "r")) == NULL)
	sprintf (error, "\nlist: Could not open %s", restrictedf),
	report_progress (report, error, TRUE),
	exit (1);
      if ((ignored = fopen (ignoredf, "r")) == NULL)
	sprintf (error, "\nlist: Could not open %s", ignoredf),
        report_progress (report, error, TRUE),
        exit (1);
      if ((headers = fopen (headersf, "a")) == NULL)
	sprintf (error, "\nlist: Could not open %s", headersf),
	report_progress, (report, error, TRUE),
	exit (1);
      report_progress (report, NEW_ARRIVAL, FALSE);
      distribute (mail, (void *) process_message, report, subscribersf, newsf,
		  peersf, aliasesf);
      fclose (mail);  /* Done */
      fclose (subscribers);
      fclose (news);
      fclose (peers);
      fclose (restricted);
      fclose (ignored);
      fclose (headers);
      shrink (message_idsf);
      unlink (mail_copyf);  /* Done delivering */
    }
    else if (!execute_once) /* No mail to deliver */
      if (sys.frequency > 0)
        sleep (sys.frequency);
  } while (!execute_once);
  fclose (report);
  free ((char *) sys.mail.method);
  if (multi_recip)
    free ((char **) multi_recipients);
  gexit ();
}

/* 
  Create a mail header.
*/

void create_header (FILE **f, char *filename, char *sender, char *originator,
		    char *recipient, char *subject)
{
  char error [MAX_LINE];
  char origin [MAX_LINE];

  strcpy (origin, originator);
  locase (origin);
  if ((*f = fopen (filename, "w")) == NULL)
    RESET (error),
    sprintf (error, "\ncreate_header(): Could not open %s", filename),
    report_progress (report, error, TRUE),
    exit (1);
  locase (recipient);
  if (sys.options & USE_TELNET)
    fprintf (*f, "HELO\nMAIL From: <%s>\nRCPT To: <%s>\nDATA\n",
	     sys.lists[listid].address, recipient);
  if (message_id[0] != EOS)
    fprintf (*f, "Message-Id: %s\n", message_id);
  fprintf (*f, "Comment: %s\nOriginator: %s\nErrors-To: %s\n\
Reply-To: <%s>\nSender: %s\nVersion: %s\n\
From: %s\nTo: %s\nSubject: %s\n\n",
	   sys.lists[listid].comment, origin, sys.manager, 
	   sys.lists[listid].address, sys.lists[listid].address, 
	   VERSION, sender, recipient, subject);
}

/* 
  Create a mail header with multiple recipients.
*/

void create_multi_recipient_header (FILE **f, char *filename, char *sender,
				    char *originator, char *recipient,
				    char *subject, int nrecipients)
{
  char error [MAX_LINE];
  char origin [MAX_LINE];
  int  i;

  strcpy (origin, originator);
  locase (origin);
  if ((*f = fopen (filename, "w")) == NULL)
    RESET (error),
    sprintf (error, "\ncreate_multi_recipient_header(): Could not open %s",
	     filename),
    report_progress (report, error, TRUE),
    exit (1);
  if (sys.options & USE_TELNET) {
    fprintf (*f, "HELO\nMAIL From: <%s>\n", sys.lists[listid].address);
    for (i = 0; i < nrecipients; i++)
      fprintf (*f, "RCPT To: <%s>\n", multi_recipients[i]),
      free ((char *) multi_recipients[i]);
    fprintf (*f, "DATA\n");
  }
  if (message_id[0] != EOS)
    fprintf (*f, "Message-Id: %s\n", message_id);
  fprintf (*f, "Comment: %s\nOriginator: %s\nErrors-To: %s\n\
Reply-To: <%s>\nSender: %s\nVersion: %s\n\
From: %s\nTo: %s\nSubject: %s\n\n",
	   sys.lists[listid].comment, origin, sys.manager, 
	   sys.lists[listid].address, sys.lists[listid].address, 
	   VERSION, sender, recipient, subject);
}

/*
  Create a news header for a message to be posted.
*/

void create_news_header (FILE **f, char *filename, char *sender,
			 char *originator, char *group, char *subject)
{
  char error [MAX_LINE];
  char origin [MAX_LINE];

  strcpy (origin, originator);
  locase (origin);
  if ((*f = fopen (filename, "w")) == NULL)
    RESET (error),
    sprintf (error, "\ncreate_news_header(): Could not open %s", filename),
    report_progress (report, error, TRUE),
    exit (1);
  locase (group);
  if (message_id[0] != EOS)
    fprintf (*f, "Message-Id: %s\n", message_id);
  fprintf (*f, "Path: %s\nNewsgroups: %s\nDistribution: world\n\
Organization: %s\n\
Originator: %s\nReply-To: <%s>\nSender: %s\nFrom: %s\nSubject: %s\n\n",
	   (article_replies_to_author ? sender : sys.lists[listid].address),
	   group, sys.organization, origin, 
	   (article_replies_to_author ? sender : sys.lists[listid].address),
	   sys.lists[listid].address,
	   sender, subject);
}

/*
  Create a gateway header.
*/

void create_gate_header (FILE **f, char *filename, char *sender,
			 char *originator, char *recipient, 
			 char *group, char *subject)
{
  char error [MAX_LINE];
  char origin [MAX_LINE];

  strcpy (origin, originator);
  locase (origin);
  if ((*f = fopen (filename, "w")) == NULL)
    RESET (error),
    sprintf (error, "\ncreate_gate_header(): Could not open %s", filename),
    report_progress (report, error, TRUE),
    exit (1);
  locase (group);
  if (sys.options & USE_TELNET)
    fprintf (*f, "HELO\nMAIL From: <%s>\nRCPT To: <%s>\nDATA\n",
	     sys.lists[listid].address, recipient);
  if (message_id[0] != EOS)
    fprintf (*f, "Message-Id: %s\n", message_id);
  fprintf (*f, "Newsgroups: %s\nDistribution: world\nOrganization: %s\n\
Originator: %s\nErrors-To: %s\nReply-To: <%s>\nSender: %s\n\
From: %s\nTo: %s\nSubject: %s\n\n",
	   group, sys.organization, origin, sys.manager, 
	   (article_replies_to_author ? sender : sys.lists[listid].address),
	   sys.lists[listid].address, sender, recipient, subject);
}

/*
  The heart of the distribution. Since we are now at the beginning of the
  message (as guaranteed by distribute ()), gather the rest of the message
  -- that is until the beginning of the next message, or EOF. Note that
  only the "From: ", "Originator: " and "Subject: " lines from the header
  are saved.
  The beginning of the next and every message is "From ". The actual
  text of each message is separated from its header by a blank line (universal
  format). The message is processed only if the sender is not listed in
  IGNORED.
  The entire message is stored in MSG. To distribute the message, prepare
  a new header; the completed message is stored in MAILFORWARD. Actually,
  for each subscriber we prepare a different header (different "To:" field) 
  and append MSG to MAILFORWARD. Distribute that mail to the members,
  or, either return it to the sender if he/she is not subscribed, or
  forward it to MANAGER if -f specified. Messages from MAILER_DAEMON are
  always forwarded to MANAGER. A message from a mailer daemon is identified
  by the presence of MAILER_DAEMON anywhere in the sender's email address,
  to cover local and remote mailer daemon addresses. Please look at the
  documentation for defs.h for the syntax of the MAILER_DAEMON string.
  The parameter "sender" is used for report purposes and when we are sending
  the sender's message back to him/her.
  Messages from regular subscribers are sent to peer lists and news groups.
  Messages from news groups are only distributed to local subscribers and
  peer lists. Finally, messages from peer lists are distributed locally
  and may be posted to news groups.
  In the case of restricted mail, check if the sender is listed in 
  RESTRICTED; if so, forward the message to the people listed in the
  filename found after the restricted-sender's address in RESTRICTED.
*/

void process_message (char *sender, char *linecopy, BOOLEAN sender_subscribed)
{
  char line [MAX_LINE];            /* ... from the the current message */
  char senders_subject [MAX_LINE]; /* the sender's subject */
  char subject_copy [MAX_LINE];    /* a copy of the subject */
  char report_msg [MAX_LINE];      /* place for report/error messages */
  char original_sender [MAX_LINE]; /* as it appears in his message */
  char originator [MAX_LINE];	   /* Holds the Originator: address */
  char reply_to [MAX_LINE];	   /* Holds the Reply-To: address */
  char id_copy [MAX_LINE];	   /* Holds the Message-Id: */
  FILE *forwardmail = NULL;        /* completed message to be forwarded */
  FILE *msg = NULL;

  line[0] = 
    senders_subject[0] = 
      subject_copy[0] = 
	originator[0] =
	  reply_to[0] =
	    message_id[0] =
	      id_copy[0]=
	        RESET (original_sender);

  /* Remove message header, but store the "From: " and "Subject: " fields to
     be used later when sending the message to all subscribers. */

  while (!feof (mail) && line[0] != '\n') {
    if (!strncmp (line, FROM, strlen (FROM)))
      strcpy (original_sender, line + strlen (FROM)), /* Save From: */
      original_sender [strlen (original_sender) - 1] = EOS; /* \n -> \0 */
    if (!strncmp (line, SUBJECT, strlen (SUBJECT)))
      strcpy (senders_subject, line + strlen (SUBJECT)), /* Save Subject: */
      senders_subject [strlen (senders_subject) - 1] = EOS, /* \n -> \0 */
      strcpy (subject_copy, senders_subject);
    if (!strncmp (line, ORIGIN, strlen (ORIGIN)))
      strcpy (originator, line + strlen (ORIGIN)),  /* Remove "Originator: " */
      extract_origin (originator),
      upcase (originator);
    if (!strncmp (line, REPLY_TO, strlen (REPLY_TO)))
      strcpy (reply_to, line + strlen (REPLY_TO)), /* Remove "Reply-To: " */
      extract_origin (reply_to),
      upcase (reply_to);
    if (!strncmp (line, MESSAGE_ID1, strlen (MESSAGE_ID1)) ||
        !strncmp (line, MESSAGE_ID2, strlen (MESSAGE_ID2)) ||
	!strncmp (line, MESSAGE_ID3, strlen (MESSAGE_ID3)))
      strcpy (message_id, line + strlen ("Message-") + 4),
      message_id [strlen (message_id) - 1] = EOS; /* \n -> \0 */
    RESET (line);
    fgets (line, MAX_LINE - 2, mail);
  }

  /* Gather message into MSG; check if we have reached the next message, 
     or EOF */
  if ((msg = fopen (msgf, "w")) == NULL)
    sprintf (report_msg, "\nprocess_message(): Could not open %s", msgf),
    report_progress (report, report_msg, TRUE),
    exit (1);
  RESET (line);
  while (!feof (mail) && 
	 (strncmp (line, START_OF_MESSAGE, strlen (START_OF_MESSAGE)))) {
    if (!strcmp (line, ".\n"))
      PREPEND (".", line);
    fprintf (msg, "%s", line);
    fgets (line, MAX_LINE - 2, mail);
  }
  fclose (msg);

  strcpy (linecopy, line); /*** VERY IMPORTANT: we are now at the next msg ***/
  /* Check the IGNORED file */
  if (ignore_sender (ignored, sender, report))
    return;
  if (originator[0] != EOS) /* Check for mail loop using Originator: */
    if (ignore_sender (ignored, originator, report))
      return;
  if (reply_to[0] != EOS) /* Check for mail loop using Reply-To: */
    if (ignore_sender (ignored, reply_to, report))
      return;
  if (message_id[0] != EOS) { /* Check for mail loop using Message-Id: */
    strcpy (id_copy, message_id);
    upcase (id_copy);
    if (message_ids = fopen (message_idsf, "r")) {
      if (ignore_sender (message_ids, id_copy, report)) {
        fclose (message_ids);
        return;
      }
      fclose (message_ids);
    }
    if ((message_ids = fopen (message_idsf, "a")) == NULL)
      sprintf (report_msg, "\nprocess_message(): Could not open %s",
	       message_idsf),
      report_progress (report, report_msg, TRUE),
      exit (1);
    fprintf (message_ids, "%s %s\n", message_id, sender); /* Save new id */
    fclose (message_ids);
  }
  if (sender_subscribed == NEWS)
    if (ignore_sender (peers, originator, report))
      return;

  if (originator[0] == EOS) /* Fresh message originating from this list */
    sprintf (originator, "%s", sys.lists[listid].address);
  upcase (originator);

  if (do_not_check_subscriptions)
    sender_subscribed = SUBSCRIBED;
  RESET (report_msg);
  if (sender_subscribed == NOTSUBSCRIBED ||
      strinstr (MAILER_DAEMON, sender, "|")) {/* Send error message to sender */
    sprintf (report_msg, "Invalid message #%04d. Forwarding error message to \
%s.\n%s",  ++returned_msg,
	     ((strinstr (MAILER_DAEMON, sender, "|") || errors_to_manager) ? 
	      sys.manager : sender), 
	     sender);
    report_progress (report, report_msg, TRUE);
    if ((msg_no = fopen (msg_nof, "w")) == NULL)
      sprintf (report_msg, "\nprocess_message(): Could not open %s", msg_nof),
      report_progress (report, report_msg, TRUE),
      exit (1);
    fprintf (msg_no, "%d %d\n", public_msg, returned_msg);
    fclose (msg_no);
    if ((msg = fopen (msgf, "r")) == NULL)
      sprintf (report_msg, "\nprocess_message(): Could not open %s", msgf),
      report_progress (report, report_msg, TRUE),
      exit (1);
    /* Prepare header */
    create_header (&forwardmail, mailforwardf, sys.lists[listid].address,
      originator,
      ((strinstr (MAILER_DAEMON, sender, "|") || errors_to_manager) ?
       sys.manager : sender),
      senders_subject);
    if (errors_to_manager || strinstr (MAILER_DAEMON, sender, "|"))
      fprintf (forwardmail, "\nRejected message sent to %s by %s\n\
follows.\n",
	       sys.lists[listid].address, sender);
    else
      fprintf (forwardmail, "\n%s: You are not subscribed to %s\n\
Your message is returned to you unprocessed.\n", sender, 
sys.lists[listid].address);
    fprintf (forwardmail, "-----------------------------------------------\
--------------------------------\n");
    while (!feof (msg))  /* Copy actual message */
      RESET (line),
      fgets (line, MAX_LINE - 2, msg),
      fprintf (forwardmail, "%s", line);
    COMPLETE_TELNET (forwardmail);
    fclose (msg);
    fclose (forwardmail);
    /* Form UNIX sendmail command */
    if (sys.options & USE_SYSMAIL)
      sysmail (mailforwardf);
    else
      syscom ("%s %s < %s", sys.mail.method,
              (((sys.options & USE_TELNET) == 0) ?
               ((strinstr (MAILER_DAEMON, sender, "|") || errors_to_manager) ?
                sys.manager : locase (sender)) : ""),
              mailforwardf);
    return;
  }
  /* Distribute to all subscribers */
  fprintf (headers, "%s\n", sender);
  fflush (headers);
  sprintf (report_msg, "Public message #%04d%s. Distributing to all \
subscribers%s.\n%s",
	   ++public_msg, (sender_subscribed == NEWS ? " (news)" : 
			  (sender_subscribed == PEER ? " (peer)" : "")), 
	   (sender_subscribed == SUBSCRIBED ? ", news groups and peers" : 
	    (sender_subscribed == NEWS ? ", peers" : ", news")),
	   sender);
  report_progress (report, report_msg, TRUE);
  if ((msg_no = fopen (msg_nof, "w")) == NULL)
    sprintf (report_msg, "\nprocess_message(): Could not open %s", msg_no),
    report_progress (report, report_msg, TRUE),
    exit (1);
  fprintf (msg_no, "%d %d\n", public_msg, returned_msg);
  fclose (msg_no);
  do_distribute (subscribers, subscribersf, send_to_subscribers, sender,
		 original_sender, senders_subject, subject_copy, originator,
		 report, FALSE, multi_recip);
  if (sender_subscribed == SUBSCRIBED || sender_subscribed == PEER)
    do_distribute (news, newsf, TRUE, sender, original_sender, senders_subject,
		   subject_copy, originator, report, 
		   TRUE, FALSE); /* Send to news also */
  if (sender_subscribed == SUBSCRIBED || sender_subscribed == NEWS)
    do_distribute (peers, peersf, TRUE, sender, original_sender, 
		   senders_subject, subject_copy, originator, 
		   report, FALSE, FALSE); /* Send to peers also */
}

/*
  Do the distribution of the message to the specified list of subscribers.
  The BOOLEAN argument 'posting' should be TRUE when posting AND gating to
  news, and FALSE otherwise.
*/

void do_distribute (FILE *recipient_list, char *file,
		    BOOLEAN send_to_subscribers, 
		    char *sender, char *original_sender, char *senders_subject,
		    char *subject_copy, char *originator, FILE *report,
		    BOOLEAN posting, BOOLEAN multi_recip)
{
  char name [MAX_LINE];            /* holds each subscribers name */
  char mailmode [MAX_LINE];        /* send message back to sender or not */
  char subscriber [MAX_LINE];      /* holds each subscriber's address */
  char report_msg [MAX_LINE];      /* place for report/error messages */
  char recipient_file [MAX_LINE];  /* file of subscribers to use when -r */
  char restricted_subscriber [MAX_LINE]; /* name of subscriber in RESTRICTED */
  char line [MAX_LINE];
  FILE *forwardmail;
  BOOLEAN alternate_file = FALSE;
  int  nrecipients = 0;

  if (!send_to_subscribers) {  /* -r: Check if restricted mail has arrived */
    rewind (restricted);
    while (!feof (restricted)) {
      alternate_file = TRUE;
      restricted_subscriber[0] = RESET (recipient_file);
      fscanf (restricted, "%s %s", restricted_subscriber, recipient_file);
      upcase (restricted_subscriber);
      if (!strcmp (restricted_subscriber, sender)) {
	if (!strcmp (recipient_file, NO_RECIPIENT_FILE)) {
	  /* Do not forward to anyone */
	  report_progress (report, "No alternate recipient file specified. \
Message ignored.\n", FALSE);
	  return;
	}
	/* Restricted mail; forward message only to the people listed
	   in recipient_file */
	if ((recipient_list = fopen (recipient_file, "r")) == NULL)
	  sprintf (report_msg, "\ndo_distribute(): Could not open alternate \
recipient file %s", recipient_file),
	  report_progress (report, report_msg, TRUE),
	  exit (1);
	RESET (report_msg);
	sprintf (report_msg, "Restricted mail. Distributing only to \
individuals listed in %s", recipient_file);
	report_progress (report, report_msg, TRUE);
	break;
      }
    }
  }
  rewind (recipient_list);
  while (!feof (recipient_list)) { /* Send to all of them */
    subscriber[0] = mailmode[0] = RESET (name);
    extract_subscriber (recipient_list, subscriber);
    fscanf (recipient_list, "%s ", mailmode);
    if (subscriber[0] == EOS)
      continue;
    fgets (name, MAX_LINE - 2, recipient_list); /* Skip name */
    name [strlen (name) - 1] = EOS;
    upcase (mailmode);
    if (!strcmp (mailmode, NOACK)) {
      upcase (subscriber);
      if (!strcmp (subscriber, sender) || !strcmp (subscriber, originator))
	continue;
    }
    else if (!strcmp (mailmode, POSTPONE))  /* No email to this subscriber */
      continue;
    else if (mailmode[0] != EOS && strcmp (mailmode, ACK))
      sprintf (report_msg, "\ndo_distribute(): Unrecognized mail mode %s in %s",
	       mailmode, file), 
      report_progress (report, report_msg, TRUE),
      exit (4);
    RESET (senders_subject);
    strcpy (senders_subject, subject_copy);
    if (multi_recip) {
      if ((multi_recipients[nrecipients] =
	  (char *) malloc ((strlen (subscriber) + 1) * sizeof (char))) == NULL)
        report_progress (report, "\ndo_distribute(): malloc failed", TRUE),
	exit (16);
      strcpy (multi_recipients[nrecipients++], locase (subscriber));
    }
    /* Prepare header */
    if (posting) {
      if (sys.options & POST_MAIL) /* Post to news group */
	create_news_header (&forwardmail, mailforwardf, original_sender,
			    originator, name, senders_subject);
      else if (sys.options & GATE_MAIL) /* Gate to news gateway */
	create_gate_header (&forwardmail, mailforwardf, original_sender,
			    originator, subscriber, name, senders_subject),
	posting = FALSE;
      if (!copy_msg (forwardmail, posting, original_sender))
	return;
    }
    else { /* Regular mail */
      if (multi_recip) { /* Multi recipient header */
	if (nrecipients == maxrecipients) {
	  sprintf (report_msg, "Multiple recipients of list <%s>",
		   sys.lists[listid].address);
	  create_multi_recipient_header (&forwardmail, mailforwardf,
					 original_sender, originator,
					 report_msg, senders_subject,
					 nrecipients);
	  if (!copy_msg (forwardmail, posting, original_sender))
	    return;
	}
      }
      else { /* Single recipient header */
	create_header (&forwardmail, mailforwardf, original_sender, originator,
		       subscriber, senders_subject);
	if (!copy_msg (forwardmail, posting, original_sender))
	  return;
      }
    }
    sendmail (subscriber, posting, multi_recip, nrecipients, maxrecipients,
	      mailforwardf);
    if (nrecipients == maxrecipients)
      nrecipients = 0;
  }
  if (alternate_file)  /* Close alternate recipient file */
    fclose (recipient_list);

  if (multi_recip && (nrecipients != 0)) { /* Left overs */
    sprintf (report_msg, "Multiple recipients of list <%s>",
	     sys.lists[listid].address);
    create_multi_recipient_header (&forwardmail, mailforwardf,
				   original_sender, originator,
				   report_msg, senders_subject,
				   nrecipients);
    if (copy_msg (forwardmail, posting, original_sender))
      sendmail (subscriber, posting, multi_recip, nrecipients, nrecipients, 
	        mailforwardf);
  }
}

/*
  Copy the original message to the outgoing message.
*/

BOOLEAN copy_msg (FILE *forwardmail, BOOLEAN posting, char *sender)
{
  FILE *msg;
  char line [MAX_LINE];
  char report_msg [MAX_LINE];
  int count = 0;

  if ((msg = fopen (msgf, "r")) == NULL)
    sprintf (report_msg, "\ncopy_msg(): Could not open %s", msgf),
    report_progress (report, report_msg, TRUE),
    exit (1);
  while (!feof (msg)) { /* Copy actual message */
    RESET (line);
    fgets (line, MAX_LINE - 2, msg);
    fprintf (forwardmail, "%s", line);
    count += strlen (line);
    if ((sys.options & LIMIT_MSG) && (count > sys.limits.msg)) {
      fclose (forwardmail);
      rewind (msg);
      create_header (&forwardmail, mailforwardf, sys.lists[listid].address, 
		     sys.lists[listid].address, sender, "Posting rejected");
      fprintf (forwardmail, "Your posting to list %s was rejected.\n\
Reason: message size limit exceeded (maximum allowed: %ld bytes)\n\
The first few lines of your message are included herein for reference:\n\n",
sys.lists[listid].alias, sys.limits.msg);
      report_progress (report, "Message rejected: maximum size exceeded",
		       TRUE);
      count = 0;
      while (!feof (msg) && count < 10)
	RESET (line),
	fgets (line, MAX_LINE - 2, msg),
	fprintf (forwardmail, "%s", line),
	++count;
      COMPLETE_TELNET (forwardmail);
      fclose (forwardmail);
      fclose (msg);
      sendmail (sender, FALSE, FALSE, 0, 0, mailforwardf);
      return FALSE;
    }
  }
  if (!posting && (sys.options & USE_TELNET))
    COMPLETE_FILE (forwardmail);
  fclose (forwardmail);
  fclose (msg);
  return TRUE;
}

/*
  Send email (to subscribers/news/gateways/peers). It may send one single
  copy to one recipient, or one copy to multiple recipients.
*/

void sendmail (char *subscriber, BOOLEAN posting, BOOLEAN multi_recip,
	       int nrecipients, int maxrecipients, char *mailforwardf)
{
  char *buf;
  int size, i;

  /* Form UNIX sendmail command */
  if (posting && (sys.options & POST_MAIL)) /* Post to news */
    syscom ("%s -h < %s", INEWS, mailforwardf);
  else { /* Send email */
    if (multi_recip) { 
      if (nrecipients == maxrecipients) {
	if ((sys.options & USE_TELNET) == 0) { /* Line up recipients */
	  size = strlen (multi_recipients[0]) + 1;
	  if ((buf = (char *) malloc (size * sizeof (char))) == NULL)
	    report_progress (report, "\nsendmail(): malloc failed", TRUE),
	    exit (16);
	  strcpy (buf, multi_recipients[0]);
	  for (i = 1; i < nrecipients; i++)
	    size += strlen (multi_recipients[i]) + 2,
	    buf = (char *) realloc (buf, size * sizeof (char)),
	    sprintf (buf + strlen (buf), " %s", multi_recipients[i]);
	  if (strlen (buf) > 10000)
	    report_progress (report, "Too many multiple recipients", TRUE),
	    exit (9);
	  syscom ("%s %s < %s", sys.mail.method, buf, mailforwardf);
	  free ((char *) buf);
	}
	else if (sys.options & USE_SYSMAIL)
	  sysmail (mailforwardf);
	else /* telnet */
	  syscom ("%s < %s", sys.mail.method, mailforwardf);
      }
    }
    else  /* Single recipient */
      if (sys.options & USE_SYSMAIL)
	sysmail (mailforwardf);
      else
        syscom ("%s %s < %s", sys.mail.method,
                (((sys.options & USE_TELNET) == 0) ? locase (subscriber) : ""),
                mailforwardf);
  }
}

void usage ()
{
  fprintf (stderr, "Usage: list <-L LIST_ALIAS> [-r] [-m #] [-1] [-f] [-e] \
[-s] [-p] [-v] [-D]\n\
-L: Process LIST_ALIAS (LIST_ALIAS has to be all in capital letters).\n\
-r: Restricted mail.\n\
-m: Specify number of multiple recipients in one outgoing message.\n\
-1: Execute only once.\n\
-f: Forward rejected messages to manager.\n\
-e: Echo reports to the screen.\n\
-s: Do not check for subscriptions.\n\
-p: Replies to posted messages will go to the author.\n\
-v: Version number.\n\
-D: Turn debug on.\n");
  exit (3);
}

void list_config (char *alias)
{
  if (alias == NULL)
    return;
  setup_string (subscribersf, alias, SUBSCRIBERS);
  setup_string (headersf, alias, HEADERS);
  setup_string (restrictedf, alias, RESTRICTED);
  setup_string (newsf, alias, NEWSF);
  setup_string (peersf, alias, PEERS);
  setup_string (aliasesf, alias, ALIASES);
  setup_string (ignoredf, alias, IGNORED);
  setup_string (list_mail_f, alias, LIST_MAIL_FILE);
  setup_string (list_moderated_f, alias, LIST_MODERATED_F);
  setup_string (mboxf, alias, MBOX);
  setup_string (msg_nof, alias, MSG_NO);
  setup_string (mailforwardf, alias, MAILFORWARD);
  setup_string (msgf, alias, MSG);
  setup_string (mail_copyf, alias, MAIL_COPY);
  setup_string (report_listf, alias, REPORT_LIST);
  setup_string (message_idsf, alias, MESSAGE_IDS_F);
}

void version ()
{
  fprintf (stderr, "%s\n", VERSION);
  exit (0);
}

/*
  Graceful exit. Remove pid file.
*/

void gexit ()
{
  unlink (PID_LIST);
  exit (0);
}
