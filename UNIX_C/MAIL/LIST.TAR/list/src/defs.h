/*
  AGREEMENT: This software can be used and distributed freely as long
  as you do not remove or alter the Copyright notice in this file;
  this notice is #define'd in the symbol VERSION. Although you may alter
  the code provided, you may not alter the functions create_header()
  and create_multi_recipient_header() in list.c and listserv.c.
  By using this software you are bound by this agreement. 
  This software comes with no warranties and cannot be sold for profit.
  The AGREEMENT and COPYRIGHT notices should be included in all source
  files when distributing this software.
  COPYRIGHT: Copyright (c) 1991, Anastasios C. Kotsikonas

  General system definitions.

  WARNING: Do not use the gcc preprocessor.

  WARNING: DO NOT CHANGE THE NAME OF THE 'SERVERD', 'LIST' or 'LISTSERV'
  PROGRAMS in the #define's below. If you do so, make sure that command line
  options are separated by at least a space from the filename.
  DO NOT INCLUDE ANY CHARACTERS SUCH AS &, |, <, >. etc.

  Preserve any quotes and new lines that appear below; change only path names.

  ALWAYS SPECIFY ABSOLUTE PATHS.

*/

#define VERSION		  "5.31 -- Copyright (c) 1991, Anastasios Kotsikonas"
#define PATH              "/usr/server
#define COMPLETE_FILE(f)  fprintf (f, "\n.\nQUIT\n")
#define TELNET		  "telnet `hostname` 25 > /dev/null 2>&1 "
#define BINMAIL		  "/bin/mail > /dev/null 2>&1"
#define INEWS		  "/usr/lib/news/inews"
#define SUBSCRIBERS       ".subscribers"
#define ALIASES		  ".aliases"
#define NEWSF		  ".news"
#define PEERS		  ".peers"
#define HEADERS		  ".headers"
#define RESTRICTED        ".restricted"
#define IGNORED           ".ignored"
#define INFO_FILE         ".info"
#define WELCOME_FILE      ".welcome"
#define REPORT_LIST       ".report.list"
#define WARNING		  PATH/.warning"
#define REPORT_SERVER     PATH/.report.server"
#define REPORT_SERVERD    PATH/.report.daemon"
#define REPORT_PQUEUE	  PATH/.report.pqueue"
#define CONFIG		  PATH/config"
#define LIST              PATH/list -1 -L "
#define SERVER            PATH/listserv -1 "
#define LIST_MAIL_FILE	  "mail"
#define LIST_MODERATED_F  "moderated"
#define MESSAGE_IDS_F     ".message.ids"
#define SERVER_MAIL_FILE  PATH/requests"
#define SERVERD           PATH/serverd"
#define PQUEUE		  PATH/pqueue"
#define START		  PATH/start"/* Do not give ANY command line options */
#define START_OPTIONS	  "-cr"		/* provide them here */
#define SERVERD_LOCK_FILE PATH/.lock.serverd"
#define LIST_LOCK_FILE    PATH/.lock.list"
#define SERVER_LOCK_FILE  PATH/.lock.server"
#define PQUEUE_LOCK_FILE  PATH/.lock.pqueue"
#define PID_PQUEUE	  PATH/.pid.pqueue"
#define PID_SERVERD	  PATH/.pid.daemon"
#define PID_SERVER	  PATH/.pid.server"
#define PID_LIST	  PATH/.pid.list"
#define CUT		  "cut"
#define AWK               "awk" /* Do a 'which awk' for proper path */
#define UPTIME            "uptime"  /* 'which uptime' */
#define MAILER_DAEMON     "MAILER|MAILER-DAEMON|MAILER-DEAMON|MAILER-DEMON|\
DAEMON|DEAMON|DEMON|POSTMASTER|POST-MASTER|UUCP|ROOT"
			  /* Preserve upper case; put all possibilities above
			     separated by a '|'; all of the above entries will
			     be used to identify mailer daemon messages so
			     they can get special treatment */
#define UCB_MAIL	  "/usr/ucb/mail" /* Path to UCB mail program. Remove
			  it if UCB mail is not installed on your system,
			  in which case no mail is sent to MANAGER by 'serverd'
			  or when the programs receive various signals. */

/*
  These #define's should not be altered.
*/

#define MAX_COMMANDS      15
#define KEEP_MESSAGE_IDS  500
#define DEFAULT_SERVER_ADDRESS 	  "listserv"
#define DEFAULT_SERVER_CMDOPTIONS ""
#define DEFAULT_SERVER_COMMENT	  "Boston University List Server"
#define DEFAULT_MANAGER		  "server"
#define MAX_LINE	  256
#define EOS		  '\0'
#define RESET(var)	  (var[0]) = EOS
#define BSD_PS		  0x01
#define	SYSV_PS		  0x02
#define	USE_TELNET	  0x04
#define USE_ENV_VAR	  0x08
#define USE_MY_SYSTEM	  0x10
#define BSD_MAIL	  0x20
#define POST_MAIL	  0x40
#define GATE_MAIL	  0x80
#define USE_SYSMAIL	  0x100
#define LIMIT_MSG	  0x200
#define START_OF_MESSAGE  "From " /* UNIX mail messages start w/ this string */
#define ACK		  "ACK"   /* Send message back to sender */
#define NOACK		  "NOACK" /* Do not send message back to sender */
#define POSTPONE	  "POSTPONE"  /* Postpone sending mail */
#define MAX_SIGNAL	  NSIG    /* Highest system signal caught */
#define BOOLEAN		  unsigned short int
#define TRUE		  1
#define FALSE		  0
#define SUBSCRIBED	  TRUE    /* Subscribed sender */
#define NOTSUBSCRIBED	  FALSE   /* Sender is not subscribed */
#define NEWS		  TRUE+1  /* News feed */
#define PEER		  TRUE+2
#define NEW_ARRIVAL	  "\n--- NEW MAIL HAS ARRIVED ---\n"
#define MAX_LISTS	  10
#define SUBJECT		  "Subject: "
#define MESSAGE_ID1       "Message-Id: "
#define MESSAGE_ID2	  "Message-ID: "
#define MESSAGE_ID3	  "Message-id: "

#define COMPLETE_TELNET(f) \
 if (sys.options & USE_TELNET) \
   COMPLETE_FILE (f)
