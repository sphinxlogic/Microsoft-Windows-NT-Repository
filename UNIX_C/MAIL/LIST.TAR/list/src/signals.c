/*
  ----------------------------------------------------------------------------
  |                            SIGNAL FUNCTIONS                              |
  |                                                                          |
  |                              Version 2.0                                 |
  |                                                                          |
  |                (or, when Computer Science gets to you)                   |
  |                                                                          |
  |                    Written by Anastasios Kotsikonas                      |
  |                           (tasos@cs.bu.edu)                              |
  |                                                                          |
  | AGREEMENT: This software can be used and distributed freely as long      |
  | as you do not remove or alter the Copyright notice in the file defs.h;   |
  | this notice is #define'd in the symbol VERSION. Although you may alter   |
  | the code provided, you may not alter the functions create_header()       |
  | and create_multi_recipient_header() in list.c and listserv.c.            |
  | By using this software you are bound by this agreement.                  |
  | This software comes with no warranties and cannot be sold for profit.    |
  | The AGREEMENT and COPYRIGHT notices should be included in all source     |
  | files when distributing this software.                                   |
  | COPYRIGHT: Copyright (c) 1991, Anastasios C. Kotsikonas                  |
  ----------------------------------------------------------------------------
*/

#include <stdio.h>
#include <signal.h>
#include "defs.h"
#include "struct.h"

extern void report_progress (FILE *, char *, int);

void   init_signals (void);
void   catch_signals (void);
void   my_abort (int);

static char *signals[MAX_SIGNAL + 1];   /* Signal names */

/*
  Initialize the signals[].
*/

void init_signals ()
{
  signals[SIGHUP] = "SIGHUP";
  signals[SIGINT] = "SIGINT";
  signals[SIGQUIT] = "SIGQUIT";
  signals[SIGTERM] = "SIGTERM";
  signals[SIGBUS] = "SIGBUS";
  signals[SIGSEGV] = "SIGSEGV";
}

/*
  Catch signals to print messages before aborting.
*/

void catch_signals ()
{
  signal (SIGHUP, my_abort);
  signal (SIGQUIT, my_abort);
  signal (SIGTERM, my_abort);
  signal (SIGSEGV, my_abort);
  signal (SIGBUS, my_abort);
  signal (SIGKILL, my_abort); /* Can't be caught, but why not try? */
}

/*
  Kill program after sending message to MANAGER that this is
  about to happen (message is sent only when using UCB mail).
*/

void my_abort (int sig)
{
  extern SYS sys;

  if (sig == SIGHUP) { /* Damn AIX passes signals from children to parents */
    signal (SIGHUP, my_abort);
    return;
  }
  printf ("\n*** Received %s signal ***\n", signals[sig]);
  if (sys.options & BSD_MAIL)
    syscom ("%s -s \"SERVERD/SERVER/LIST received %s\" %s &", UCB_MAIL,
	    signals[sig], sys.manager);
  exit (8);
}
