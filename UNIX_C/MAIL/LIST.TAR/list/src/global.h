/*
  AGREEMENT: This software can be used and distributed freely as long
  as you do not remove or alter the Copyright notice in the file defs.h;
  this notice is #define'd in the symbol VERSION. Although you may alter
  the code provided, you may not alter the functions create_header()
  and create_multi_recipient_header() in list.c and listserv.c.
  By using this software you are bound by this agreement.
  This software comes with no warranties and cannot be sold for profit.
  The AGREEMENT and COPYRIGHT notices should be included in all source
  files when distributing this software.
  COPYRIGHT: Copyright (c) 1991, Anastasios C. Kotsikonas
*/

char subscribersf [MAX_LINE];
char newsf [MAX_LINE];
char peersf [MAX_LINE];
char aliasesf [MAX_LINE];
char headersf [MAX_LINE];
char restrictedf [MAX_LINE];
char ignoredf [MAX_LINE];
char list_mail_f [MAX_LINE];
char report_listf [MAX_LINE];
char server_ignoredf [MAX_LINE];
char infof [MAX_LINE];
char welcomef [MAX_LINE];
char message_idsf [MAX_LINE];
char message_id [MAX_LINE];
SYS  sys;
COMMANDS commands [MAX_COMMANDS]; /* Set of recognizable commands */
BOOLEAN debug = FALSE;
