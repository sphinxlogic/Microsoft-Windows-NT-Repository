/*
  ----------------------------------------------------------------------------
  |                        DISCUSSION LIST SERVER                            |
  |									     |
  |                             Version 5.31                                  |
  |                                                                          |
  |                (or, when Computer Science gets to you)                   |
  |                                                                          |
  |                    Written by Anastasios Kotsikonas                      |
  |                           (tasos@cs.bu.edu)                              |
  |                                                                          |
  | AGREEMENT: This software can be used and distributed freely as long      |
  | as you do not remove or alter the Copyright notice in the file defs.h;   |
  | this notice is #define'd in the symbol VERSION. Although you may alter   |
  | the code provided, you may not alter the functions create_header()       |
  | and create_multi_recipient_header() in list.c and listserv.c.            |
  | By using this software you are bound by this agreement.                  |
  | This software comes with no warranties and cannot be sold for profit.    |
  | The AGREEMENT and COPYRIGHT notices should be included in all source     |
  | files when distributing this software.                                   |
  | COPYRIGHT: Copyright (c) 1991, Anastasios C. Kotsikonas                  |
  ----------------------------------------------------------------------------

  This is the system's server. People send requests to the listserv
  for subscription, removal of subscription, general information request, etc.
  The recognized commands are as follows:
    help [command]
    set <list> [<option> <value>]         option: mail
                                          value: ack, noack, postpone
    subscribe <list> <name>
    unsubscribe <list> (alias signoff)
    recipients <list> (alias review)
    information <list>
    statistics <list> [subscriber email address(es)]
    shutdown <password>
    restart <password>
    lists
    index [archive]
    get <archive> <filename> [parts]
    release

  Commands are sent to listserv one on each line of the message. The user
  is notified of the first invalid request; all subsequent commands
  are ignored -- imagine someone sending an entire book!! For each 
  successfully completed command, a confirmation is sent back to the sender.
  Commands/requests may be abbreviated.

  The user may request help in general, or on a specific command; he can
  'set list mail ack' in which case his/her messages to the list will be
  echoed back to him/her, and 'set list mail noack' (the opposite);
  A 'set list mail postpone' request will not send any
  messages to the subscriber until he resets it to one of the other options
  (used to suppress sending email temporarily). 'set list' with no arguments
  returns the current values for all options.
  To subscribe to the list, a user has to give his/her full name; 
  he/she may leave the list by issuing an 'unsubscribe' request;
  a list of the current subscribers is obtained through a 'recipients' request;
  a copy of the sender's message is also sent to peer lists in this case.
  Moreover, general information is available by means of an 'information'
  request, and finally 'statistics' compiles a count of messages sent by
  each subscriber (unless specific subscriber address are given) as well as
  a total count of messages on file; again, a copy of the message will be
  forwarded to all peer lists.

  The entire system may be remotely shut down by way of a 'shutdown' request;
  this request must be followed by a password that must match the one defined
  in config. Note that this may result in requests being queued with the
  'shutdown' one not being serviced; note thought that a copy of the original
  requests can be found in MAIL_COPY as defined in listserv.h.
  Likewise, the system may be remotely restarted by issuing a 'restart'
  request with the proper password. Note that a 'restart' request has no
  effect after a 'shutdown' (because the server is not running), and that
  any requests queued with the 'restart' will be serviced (the system will
  not restart until all requests are serviced).

  A list of all discussion lists served by this server can be obtained by
  a 'lists' request.

  Information on the current release of this server can be obtained by
  a 'release' request.

  The system includes a means for users to obtain files. The files
  can be placed anywhere in the system and are archived under
  			/usr/server/archives/*
  Each of these archives has an index of subarchives and a directory
  of files that can be obtained from that archive; there is a master
  archive in archives/listserv: the file INDEX contains names and full paths
  to all of the archives (including listserv); the file DIR is a directory 
  of files that are archived under listserv. A user
  may obtain a list of all the archives and their files by sending an
  'index' request. That request followed by a specific archive will
  send a list of files for that archive and all of its subsrchives.
  The format of the INDEX file is as follows: one line per archive
  with the following:

		  archive-name full-path-to-its-directory

  A file can be obtained via a 'get' request, specifying the archive and
  the file to get. It is possible that a file has been split in various
  parts, in which case multiple emails with the various subparts will
  be sent to the user. Note that only the master index is used in this
  case for locating the archive. Individual parts of the split file may
  be obtained by specifying them as arguments.

  A file may be archived with the farch utility, or manually by
  editing the DIR file of the target archive. The format is as follows:
  one line per file containing the following information:

  	   filename number-of-subparts directory-to-find-it

  The restriction is that the actual disk file should be all in lower case.

  A new archive may be created by creating a subdirectory under
  /usr/server/archives (the new directory may not be all in lower-case letters),
  updating the master INDEX (archives/listserv/INDEX) and all lower-level
  indeces (if any), creating a new INDEX file in the new directory with one
  entry (the new archive itself), and creating an empty DIR file in the
  same new directory.

  The hierarchical structure is only logical and directory hierarchy does
  not matter. All archives though have to be placed under /usr/server/archives.

  All commands may be abbreviated except 'shutdown' and 'restart'.

  COMMAND LINE OPTIONS:
    -1: Same as for the list program.
    -r: This option may be repeated an infinite number of times and is
        always followed by a valid listserv command (as outlined above).
        This forces a restriction to be placed on the specified command;
        whenever a user makes such a request, the request will be rejected
        if the number of users currently on the system is greater than
        the threshold specified in listserv.h. This option was added due
        to the fact that the 'statistics' request may take up a lot of
        resources to complete.
    -e: Echo reports to the screen.
    -n: Do not notify peer servers.
    -d: Disable a listserv command. This makes totally unknown to the server.
        However, help is still available for the particular request.
    -D: Turn debug on. A transaction of the last email sent out is kept
        in the files /usr/server/sent and /usr/server/received. This assumes
	use of the 'system' mail method.

  EXIT CODES:
    0: OK
    1: Could not open file
    2: Could not lock file
    3: Command line option error
    4: Syntax error in file
    5: Could not spawn
    6: Shutdown request
    7: Restart request
    8: Received system signal

  Approximate algorithm:
  {
    Place a lock so that no other programs will access the same files.
    Read the SERVER_MAIL_FILE
    if new messages have arrived then {
      For each message do {
        If the message is sent by MAILER-DAEMON forward it to MANAGER
        else {
	  if the person in not in the IGNORED file, then
          scan each line of the body of the message and treat it as a
          command with possible arguments. Reply to the sender for each such
          request. If a request cannot be processed, send an error message to
          the sender and ignore all subsequent requests.
        }
      }
    }
  }

  Required files:
    SUBSCRIBERS       <-- The list of subscribed people (diff. for each list)
    ALIASES	      <-- Aliases of email addresses of subscribers, news &
    			  peers.
    PEERS	      <-- A list of peers for a particular list (where appl.)
    IGNORED           <-- The list of undesired people (one for the server
			  and one for each list)
    SERVER_LOCK_FILE  <-- Lock file

  Input files:
    HEADERS           <-- Used for the 'statistics' request (see list.c)
    SERVER_MAIL_FILE  <-- Where new messages go
    MAIL_COPY         <-- Copy of this file (actual work file)
    MSG_NO            <-- Read last message count
    SUBSCRIBERS
    IGNORED     

  Output files:
    SERVER_MBOX       <-- A log of all messages sent
    SUBSCRIBERS       <-- After updating
    OLD_SUBSCRIBERS   <-- Temporary
    MSG_NO            <-- Write last message count
    REPORT_SERVER     <-- Progress report
    MAILFORWARD       <-- Completed message (with header and the
                          the body of the message) to be forwarded

  Format of the SUBSCRIBERS, PEERS and IGNORED files:
    See comments for list.c

  Recommended usage:
    % listserv [-r statistics] &
  or
    % listserv [-r statistics] -1

*/

#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include "defs.h"
#include "listserv.h"
#include "struct.h"
#include "global.h"

/* 
  Function prototypes:
*/

#ifdef __STDC__
#include <stdarg.h>
extern int  syscom (char *, ...);
#else
#include <varargs.h>
extern int  syscom ();
#endif
extern int  sys_config (FILE *, SYS *);
extern void report_progress (FILE *, char *, int);
extern void init_signals (void);
extern void catch_signals (void);
extern void setup_string (char *, char *, char *);
extern char *upcase (char *);
extern char *locase (char *);
extern void distribute (FILE *, void (*)(char *, char *, BOOLEAN),
			FILE *, char *, char *, char *, char *);
extern char *cleanup_name (char *);
extern void cleanup_request (char *s);
extern int  getopt (int, char **, char *);
extern void get_list_name (char *, char *);
extern int  get_list_id (char *, SYS *, int);
extern void shrink (char *);
extern BOOLEAN sysmail (char *);
extern BOOLEAN subscribed (FILE *, char *, char *, char *, char *, char *);
extern BOOLEAN strinstr (char *, char *, char *);
extern BOOLEAN ignore_sender (FILE *, char *, FILE *);
extern BOOLEAN requested_part (char *, int);

void   main (int, char **, char **);
void   process_message (char *, char *);
void   action (char *, char *, char *);
void   create_header (FILE **, char *, char *, char *, char *);
void   reject_mail (char *, char *);
void   help (char *, char *, char *);
void   unsubscribe (char *, char *, char *);
void   subscribe (char *, char *, char *);
void   set (char *, char *, char *);
void   recipients (char *, char *, char *);
void   info (char *, char *, char *);
void   stats (char *, char *, char *);
void   Shutdown (char *, char *, char *);
void   restart (char *, char *, char *);
void   lists (char *, char *, char *);
void   get (char *, char *, char *);
void   Index (char *, char *, char *);
void   notify_peer_servers (char *, char *, char *, char *);
void   init_commands (void);
void   usage (void);
void   server_config (char *);
void   gexit (void);

/*
  The control structure of the server. Check if mail has arrived.
  If so, copy it to MAIL_COPY and proceed to lower level.
  First, the command line options are analyzed (for restrictions, etc.).
*/

void main (int argc, char **argv, char **envp)
{
  struct stat stat_buf;
  char *options = "1r:d:enD";
  int c;
  BOOLEAN execute_once = FALSE, notok;
  int i, j, k;
  FILE *f;
  char error [MAX_LINE];

  extern char *optarg;
  extern int optopt;

  init_commands();
  while ((c = getopt (argc, argv, options)) != EOF)
    switch ((char) c) {
      case '1': execute_once = TRUE; break;
      case 'e': tty_echo = TRUE; break;
      case 'n': do_not_notify_peer_server = TRUE; break;
      case 'D': debug = TRUE; break;
      case 'r': 
      case 'd':
        notok = TRUE;
        k = 0;
        upcase (optarg);
        for (i = 0; i < MAX_COMMANDS; ++i) {
          notok &= (((j = strncmp (optarg, commands[i].name, strlen (optarg)))
                    != 0) ? 1 : 0);
          if (!j) {
            ++k;
	    if (c == 'r')
              restricted_commands |= commands[i].mask;
	    else if (c == 'd')
	      disabled_commands |= commands[i].mask;
	  }
	}
        if (notok)
          fprintf (stderr, "listserv: Unrecognized request '%s'\n", optarg),
          exit (3);
        if (k > 1) /* ambiguous command */
          fprintf (stderr, "listserv: Ambiguous request '%s'\n", optarg),
          exit (3);
        break;
      case ':':
          fprintf (stderr, "listserv: Option '%c' requires an argument.\n",
		   optopt);
          exit (3);
      case '?':
      default:
        usage ();
    }
#ifndef _MINIX
  if (lockf (open (SERVER_LOCK_FILE, O_RDWR), F_TLOCK, 0))
    fprintf (stderr, "listserv: Unable to lock %s. Aborting.\n", 
             SERVER_LOCK_FILE),
    exit (2);
#endif
  if (!execute_once)
    printf ("%s\n", VERSION);
  init_signals();
  catch_signals();
  if ((report = fopen (REPORT_SERVER, "a")) == NULL)
    fprintf (stderr, "listserv: Unable to open %s\n", REPORT_SERVER),
    exit (1);
  nlists = sys_config (report, &sys);
  if (sys.options & USE_ENV_VAR) {
    if ((sys.mail.method = (char *) malloc (256 * sizeof (char))) == NULL)
      report_progress (report, "\nmain(): malloc failed", TRUE),
      exit (16);
    sprintf (sys.mail.method, "env - %s=%s %s ", sys.mail.env_var,
	     sys.server.address, sys.mail.mail_prog);
   }
  if ((msg_no = fopen (MSG_NO, "r")) != NULL)
    fscanf (msg_no, "%d\n", &request_no),
    fclose (msg_no);
    
  if ((f = fopen (PID_SERVER, "w")) != NULL)
    fprintf (f, "%d", getpid()),
    fclose (f);
  signal (SIGINT, gexit);

  do {
    if (!stat (SERVER_MAIL_FILE, &stat_buf) && stat_buf.st_size > 0) {
      syscom ("cp %s %s", SERVER_MAIL_FILE, MAIL_COPY);
      syscom ("cat %s >> %s", MAIL_COPY, SERVER_MBOX);
      syscom ("echo >> %s", SERVER_MBOX);
      if (!unlink (SERVER_MAIL_FILE))
	syscom ("touch %s", SERVER_MAIL_FILE), /* rewrite file */
	syscom ("chmod 666 %s", SERVER_MAIL_FILE);
      if ((mail = fopen (MAIL_COPY, "r")) == NULL)
	sprintf (error, "listserv: Could not open %s", MAIL_COPY),
        report_progress (report, error, TRUE),
        exit (1);
      report_progress (report, NEW_ARRIVAL, FALSE);
      distribute (mail, (void *) process_message, report, NULL, NULL, NULL,
		  NULL);
      fclose (mail);  /* Done */
      shrink (message_idsf);
      unlink (MAIL_COPY);  /* Done delivering */
    }
    else if (!execute_once) /* No mail to deliver */
      if (sys.frequency > 0)
        sleep (sys.frequency);
  } while (!execute_once);
  fclose (report);
  free ((char *) sys.mail.method);
  unlink (PID_SERVER);
  if (restart_sys)
    exit (7); /* Exit status of 7 signifies a restart request */
  exit (0);
}

/*
  Process each message. Isolate each command and pass it to action().
  Before that, check if the message is from MAILER_DAEMON, in which case
  forward the message to MANAGER. Any messages from people listed in the
  IGNORED file are not processed.
  Note: Please look at the documentation for list.c for the definition of a
  mailer daemon.
*/

void process_message (char *sender, char *linecopy)
{
  char line [MAX_LINE];          /* ... from the the current message */
  char request [MAX_LINE];       /* holds each command */
  char report_msg [MAX_LINE];    /* message to be written to REPORT */
  char sender_copy [MAX_LINE];
  char id_copy [MAX_LINE];
  FILE *f;
  BOOLEAN loop = FALSE;

  peer_server_request = FALSE;
  report_msg[0] = line[0] = message_id[0] = id_copy[0] = RESET (sender_copy);
  strcpy (sender_copy, sender);  /* we do not like converting the actual */
  upcase (sender_copy);          /* address to upper case */
  sprintf (report_msg, "Request #%04d:%s\n", ++request_no, sender);
  report_progress (report, report_msg, FALSE);
  if ((msg_no = fopen (MSG_NO, "w")) == NULL)
    sprintf (report_msg, "\nprocess_message(): Could not open %s", MSG_NO),
    report_progress (report, report_msg, TRUE),
    exit (1);
  fprintf (msg_no, "%d\n", request_no);
  fclose (msg_no);

  while (!feof (mail) && line[0] != '\n') { /* Skip to beginning of message */
    if (!strncmp (line, SUBJECT, strlen (SUBJECT))) {
      sprintf (line, "%s", line + strlen (SUBJECT));
      if (!strncmp (line, PEER_SERVER_REQUEST, strlen (PEER_SERVER_REQUEST)))
	peer_server_request = TRUE;
    }
    if (!strncmp (line, MESSAGE_ID1, strlen (MESSAGE_ID1)) ||
        !strncmp (line, MESSAGE_ID2, strlen (MESSAGE_ID2)) ||
        !strncmp (line, MESSAGE_ID3, strlen (MESSAGE_ID3)))
      strcpy (message_id, line + strlen ("Message-") + 4),
      message_id [strlen (message_id) - 1] = EOS, /* \n -> \0 */
      strcpy (id_copy, message_id);
      upcase (id_copy);
    RESET (line);
    fgets (line, MAX_LINE - 2, mail);
  }

  if (message_id[0] != EOS) { /* Check for mail loop using Message-Id: */
    sprintf (message_idsf, "%s/%s", PATH", MESSAGE_IDS_F);
    if (message_ids = fopen (message_idsf, "r")) {
      if (ignore_sender (message_ids, id_copy, report))
        loop = TRUE;
      fclose (message_ids);
    }
    if (!loop) {
      if ((message_ids = fopen (message_idsf, "a")) == NULL)
        sprintf (report_msg, "\nprocess_message(): Could not open %s",
                 message_idsf),
	report_progress (report, report_msg, TRUE),
        exit (1);
      fprintf (message_ids, "%s %s\n", message_id, sender); /* Save new id */
      fclose (message_ids);
    }
  }

  if (strinstr (MAILER_DAEMON, sender_copy, "|")) {
    /* Send message to MANAGER */
    create_header (&f, MAILFORWARD, sys.server.address, sys.manager, sender);
    fprintf (f, "\nReturned mail by %s\n--------------------------------------\
-----------------------------------------\n",
             sender);
    while (!feof (mail) && 
           (strncmp (line, START_OF_MESSAGE, strlen (START_OF_MESSAGE)))) {
      RESET (line);
      fgets (line, MAX_LINE - 2, mail);
      fprintf (f, "%s", line);
    }
    COMPLETE_TELNET (f);
    fclose (f);
    DELIVER_MAIL (sys.manager);
    RESET (report_msg);
    sprintf (report_msg, "Forwarding message to %s\n", sys.manager);
    report_progress (report, report_msg, FALSE);
  }
  else /* Isolate request and call action() */
    while (!feof (mail) && 
           (strncmp (line, START_OF_MESSAGE, strlen (START_OF_MESSAGE)))) {
      cleanup_request (line);
      RESET (request);
      sscanf (line, "%s ", request);
      upcase (request);
      if (!strcmp (request, START_OF_SIGNATURE))
	one_rejection = TRUE; /* End of requests, start of .signature */
      else if (request[0] != EOS && !one_rejection && !loop)
        action (line, request, sender);
      RESET (line);
      fgets (line, MAX_LINE - 2, mail);
    }
  strcpy (linecopy, line);
  one_rejection = FALSE;
  report_progress (report, "", -TRUE); /* -TRUE for no leading newline */
}

/*
  Recognize the 'request' and call the appropriate routine, or reject the
  message if the request is not recognized. Isolate any parameters.
  If a restriction is in force for the recognized request, then get
  the number of users currently on the system and reject the request if
  this number is greater that the predetermined threshold.
*/

void action (char *line, char *request, char *sender)
{
  char params [MAX_LINE];
  char error [MAX_LINE];
  char list_name [MAX_LINE];
  int i, nusers;
  FILE *f;

  report_progress (report, line, FALSE);
  RESET (error);
  sprintf (server_ignoredf, "%s/%s", PATH", IGNORED);
  if ((ignored = fopen (server_ignoredf, "r")) == NULL)
    sprintf (error, "action(): Could not open %s", server_ignoredf),
    report_progress (report, error, TRUE),
    exit (1);
  if (ignore_sender (ignored, sender, report))
    goto abort;
  fclose (ignored);
  upcase (sender);
  RESET (params);
  sprintf (params, "%s", line + strlen (request)); /* Get parameters */
  upcase (params);
  for (i = 0; i < MAX_COMMANDS; i++) /* Walk through the valid requests */
    if (! strncmp (request, commands[i].name, strlen (request)) &&
	! (disabled_commands & commands[i].mask)) {
      if (strncmp (request, "SHUTDOWN", strlen (request)) &&
          strncmp (request, "RESTART", strlen (request)) &&
          strncmp (request, "LISTS", strlen (request)) &&
	  strncmp (request, "INDEX", strlen (request)) &&
	  strncmp (request, "GET", strlen (request)) &&
	  strncmp (request, "RELEASE", strlen (request)) &&
          strncmp (request, "HELP", strlen (request))) {
        get_list_name (params, list_name);
        listid = get_list_id (list_name, &sys, nlists);
        server_config (list_name);
        if (listid < 0) {
          if (list_name[0] == EOS)
            sprintf (error, "%s: Missing list name\n", request);
          else
            sprintf (error, "%s: Unknown list name %s\n", request, list_name);
          reject_mail (sender, error);
          return;
        }
        if ((ignored = fopen (ignoredf, "r")) == NULL)
          sprintf (error, "action(): Could not open %s", ignoredf),
          report_progress (report, error, TRUE),
          exit (1);
        if (ignore_sender (ignored, sender, report))
          goto abort;
        if (commands[i].mask & sys.lists[listid].disabled_commands) {
	  sprintf (error, "%s requests for list %s are disabled\n",
		   request, sys.lists[listid].alias);
	  reject_mail (sender, error);
	  goto abort;
	}
      }
      if (restricted_commands & commands[i].mask) { /* Restriction set */
        syscom ("%s | %s -F, '{ print $3 }' > %s", UPTIME, AWK, USERS_FILE);
        if ((f = fopen (USERS_FILE, "r")) == NULL)
	  sprintf (error, "action(): Could not open %s", USERS_FILE),
          report_progress (report, error, TRUE),
          exit (1);
        fscanf (f, "%d", &nusers);
        fclose (f);
        unlink (USERS_FILE);
        if (nusers > sys.users) {
          create_header (&f, MAILFORWARD, sys.server.address, sender, request);
          fprintf (f, "This request takes a considerable amount of resources \
and certain restrictions\nare currently in force. Please resubmit your \
request at a later time.\n");
	  COMPLETE_TELNET (f);
          fclose (f);
	  DELIVER_MAIL (sender);
          strcat (request, ": restriction enforced\n");
          report_progress (report, request, FALSE);
          goto abort;
        }
      }
      commands[i].func (request, params, sender); /* Call routine */
      goto abort;
    }
  sprintf (error, "Unrecognized request %s\n", request);
  reject_mail (sender, error);
  abort:
  fclose (ignored);
}

/*
  Create a message header addressed to 'sender' with the given 'subject'.
  Note: some mailers require the following format when using telnet:
*/

void create_header (FILE **f, char *filename, char *sender, char *recipient, 
		    char *subject)
{
  char error [MAX_LINE];

  if ((*f = fopen (filename, "w")) == NULL)
    RESET (error),
    sprintf (error, "\ncreate_header(): Could not open %s", filename),
    report_progress (report, error, TRUE),
    exit (1);
  locase (recipient);
  if (sys.options & USE_TELNET)
    fprintf (*f, "HELO\nMAIL From: <%s>\nRCPT To: <%s>\nDATA\n",
             sender, recipient);
  if (message_id[0] != EOS)
    fprintf (*f, "Message-Id: %s\n", message_id);
  fprintf (*f, "Comment: %s\nErrors-To: %s\nReply-To: <%s>\n\
Sender: %s\nVersion: %s\nFrom: %s\nTo: %s\nSubject: %s\n\n",
	   sys.server.comment, sys.manager, sender, sender, VERSION, sender,
	   recipient, subject);
}

/*
  Send a message to 'sender' indicating an invalid request. The body of
  the message is given in 'text'. Only one such mail is sent to the user
  for each of his/her invalid requests. All subsequent requests are ignored.
*/

void reject_mail (char *sender, char *text)
{
  FILE *f;
 
  if (one_rejection)
    return;
  report_progress (report, text, FALSE);
  one_rejection = TRUE;
  create_header (&f, MAILFORWARD, sys.server.address, sender, 
		 "Invalid request");
  fprintf (f, "%s\nReport any problems to '%s'.\nFor a list of the available \
requests send a message to %s\nwith the word 'help' in the body of the \
message.\n\nPS: Any subsequent requests that you might have submitted have \
been ignored.\n", text, sys.manager, sys.server.address);
  COMPLETE_TELNET (f);
  fclose (f);
  DELIVER_MAIL (sender);
}

/*
  Provide help on the various commands to 'sender'.
*/

void help (char *request, char *params, char *sender)
{
  FILE *f;
  char error [MAX_LINE];
  char param [MAX_LINE];
  char moreparams [MAX_LINE];
  BOOLEAN notok = TRUE;
  int i;

  sprintf (request + strlen (request), "%s", params); /* Used as a subject */
  error[0] = param[0] = RESET (moreparams);
  sscanf (params, "%s %s\n", param, moreparams);
  if (param[0] != EOS) {  /* Check option validity */
    for (i = 0; i < MAX_COMMANDS; ++i)
      notok &= ((strncmp (param, commands[i].name, strlen (param)) != 0) ? 
                1 : 0);
    if (notok) {
      sprintf (error, "Invalid HELP topic%s", params);
      reject_mail (sender, error);
      return;
    }
  }
  if (moreparams[0] != EOS) {  /* More than one option given */
    sprintf (error, "Too many HELP topics: %s\n", moreparams);
    reject_mail (sender, error);
    return;
  }
  create_header (&f, MAILFORWARD, sys.server.address, sender, request);
  fclose (f);
  if (param[0] == EOS)
    syscom ("cat %s >> %s", HELP_GENERAL, MAILFORWARD);
  else {
    if (!strncmp (param, "SET", strlen (param)))
      syscom ("cat %s >> %s", HELP_SET, MAILFORWARD);
    if (!strncmp (param, "SUBSCRIBE", strlen (param)))
      syscom ("cat %s >> %s", HELP_SUBSCRIBE, MAILFORWARD);
    if (!strncmp (param, "UNSUBSCRIBE", strlen (param)) ||
        !strncmp (param, "SIGNOFF", strlen(param)))
      syscom ("cat %s >> %s", HELP_UNSUBSCRIBE, MAILFORWARD);
    if (!strncmp (param, "RECIPIENTS", strlen (param)) ||
        !strncmp (param, "REVIEW", strlen(param)))
      syscom ("cat %s >> %s", HELP_RECIPIENTS, MAILFORWARD);
    if (!strncmp (param, "INFORMATION", strlen (param)))
      syscom ("cat %s >> %s", HELP_INFORMATION, MAILFORWARD);
    if (!strncmp (param, "STATISTICS", strlen (param)))
      syscom ("cat %s >> %s", HELP_STATISTICS, MAILFORWARD);
    if (!strncmp (param, "LISTS", strlen (param)))
      syscom ("cat %s >> %s", HELP_LISTS, MAILFORWARD);
    if (!strncmp (param, "INDEX", strlen (param)))
      syscom ("cat %s >> %s", HELP_INDEX, MAILFORWARD);
    if (!strncmp (param, "GET", strlen (param)))
      syscom ("cat %s >> %s", HELP_GET, MAILFORWARD);
    if (!strncmp (param, "RELEASE", strlen (param)))
      syscom ("cat %s >> %s", HELP_RELEASE, MAILFORWARD);
  }
  APPEND_TELNET ("help");
  DELIVER_MAIL (sender);
}

/*
  Unsubscribe a member if he/she is listed in SUBSCRIBERS.
*/

void unsubscribe (char *request, char *params, char *sender)
{
  FILE *f;
  char error [MAX_LINE];
  char param [MAX_LINE];
  BOOLEAN status;
  
  sprintf (request + strlen (request), " %s%s", sys.lists[listid].alias,
           params); /* Used as a subject */
  error[0] = RESET (param);
  sscanf (params, "%s", param);
  if (param[0] != EOS) { /* No parameters accepted */
    sprintf (error, "Invalid UNSUBSCRIBE option%s", params);
    reject_mail (sender, error);
    return;
  }
  if (!(status = subscribed (report, sender, subscribersf, newsf, peersf,
			     aliasesf))) {
    sprintf (error, "%s: %sYou are not subscribed to %s\n", sender, request,
             sys.lists[listid].address);
    reject_mail (sender, error);
    return;
  }
  else if (status > SUBSCRIBED) { /* Notify manager */
    NOTIFY_MANAGER ("Attempt to unsubscribe new or peer");
    return;
  }
  /* Now move the current list of subscribers to a temporary file; then
     copy each entry of this file to SUBSCRIBERS excluding the
     user to be removed. */
  syscom ("mv %s %s", subscribersf, OLD_SUBSCRIBERS);
  syscom ("grep -i -v '%s' %s > %s", sender, OLD_SUBSCRIBERS, subscribersf);
  unlink (OLD_SUBSCRIBERS);
  syscom ("mv %s %s", aliasesf, OLD_SUBSCRIBERS);
  syscom ("grep -i -v %s %s > %s", sender, OLD_SUBSCRIBERS, aliasesf);
  unlink (OLD_SUBSCRIBERS);
  create_header (&f, MAILFORWARD, sys.server.address, sender, request);
  fprintf (f, "You have been removed from list %s\nThanks for being with us.\n",
           sys.lists[listid].address);
  COMPLETE_TELNET (f);
  fclose (f);
  DELIVER_MAIL (sender);
}

/*
  Subscribe a new user if he/she is not already subscribed.
*/

void subscribe (char *request, char *params, char *sender)
{
  FILE *f;
  char error [MAX_LINE];
  char name [MAX_LINE];
  int i;
  BOOLEAN status;

  sprintf (request + strlen (request), " %s%s", sys.lists[listid].alias,
           params); /* Used as a subject */
  error[0] = RESET (name);
  cleanup_name (params); /* Remove extraneous characters */
  sscanf (params, "%s\n", name);
  if (name[0] == EOS) {  /* No user's name */
    sprintf (error, "No name given to SUBSCRIBE\n");
    reject_mail (sender, error);
    return;
  }
  if ((status = subscribed (report, sender, subscribersf, newsf, peersf,
			    aliasesf)) == SUBSCRIBED) {
    sprintf (error, "%s: You are already subscribed to %s\n", sender, 
             sys.lists[listid].address);
    reject_mail (sender, error);
    return;
  }
  else if (status > SUBSCRIBED) { /* Notify manager */
    NOTIFY_MANAGER ("Attempt to subscribe news or peer");
    return;
  }
  if ((f = fopen (subscribersf, "a")) == NULL)
    sprintf (error, "subscribe(): Could not open %s", subscribersf),
    report_progress (report, error, TRUE),
    exit (1);
  fprintf (f, "%s ", sender);
  for (i = 0; i < MAX_SET_OPTIONS; i++)  /* Copy all options */
    fprintf (f, "%s ", default_values[i]);
  fprintf (f, "%s\n", params);
  fclose (f);
  create_header (&f, MAILFORWARD, sys.server.address, sender, request);
  fprintf (f, "You have been added to list %s\nRequests to %s\n", 
           sys.lists[listid].address, sys.server.address);
  fclose (f);
  syscom ("cat %s >> %s", welcomef, MAILFORWARD);
  APPEND_TELNET ("subscribe");
  DELIVER_MAIL (sender);
}

/*
  Set options for user if he/she is subscribed.
  Adding more SET options:
  - In listserv.h, define the new MAX_SET_OPTIONS.
  - In listserv.h, define the new option in options[], the valid
    values in values[] and the default_values[].
  - the MAIL option should be first in list; this assumption is made by list
    and listserv.
*/

void set (char *request, char *params, char *sender)
{
  FILE *f, *from, *to;
  char error [MAX_LINE];
  char option [MAX_LINE];
  char subscriber [MAX_LINE];
  char oldmodes [MAX_SET_OPTIONS] [MAX_LINE];
  char newmode [MAX_LINE];
  char moreparams [MAX_LINE];
  char name [MAX_LINE];
  int  i, index;
  BOOLEAN status;

  sprintf (request + strlen (request), " %s%s", sys.lists[listid].alias,
           params); /* Used as a subject */
  error[0] = option[0] = moreparams[0] = RESET (newmode);
  sscanf (params, "%s %s %s\n", option, newmode, moreparams); /* Get params */
  upcase (option);
  upcase (newmode);
  if (!(status = subscribed (report, sender, subscribersf, newsf, peersf,
			     aliasesf))) {
    sprintf (error, "%s: %sYou are not subscribed to %s\n", sender, request,
             sys.lists[listid].address);
    reject_mail (sender, error);
    return;
  }
  else if (status > SUBSCRIBED) { /* Notify manager */
    NOTIFY_MANAGER ("Attempt to set mode for news or peer");
    return;
  }
  if (option[0] != EOS) {
    for (index = 0; index < MAX_SET_OPTIONS; index++)
      if (! strcmp (option, options[index]))
	break;
    if (index == MAX_SET_OPTIONS) {
      sprintf (error, "Invalid SET option %s\n", option);
      reject_mail (sender, error);
      return;
    }
    if (! strinstr (values[index], newmode, "|")) {
      sprintf (error, "%s SET %s value %s\n", 
               (newmode[0] != EOS ? "Invalid" : "Missing"), 
	       options[index], newmode);
      reject_mail (sender, error);
      return;
    }
  }
  if (moreparams[0] != EOS) {  /* More than one option given */
    sprintf (error, "Too many SET parameters: %s\n", moreparams);
    reject_mail (sender, error);
    return;
  }
  if (option[0] == EOS) { /* Status inquiry */
    syscom ("grep -i '%s' %s | %s -d' ' -f2,%d > %s", sender, subscribersf,
	    CUT, MAX_SET_OPTIONS + 1, OLD_SUBSCRIBERS);
    if (! one_rejection) {
      create_header (&f, MAILFORWARD, sys.server.address, sender, request);
      fprintf (f, "Current settings are:\n");
      if ((from = fopen (OLD_SUBSCRIBERS, "r")) == NULL)
 	sprintf (error, "set(): Could not open %s", OLD_SUBSCRIBERS),
	report_progress (report, error, TRUE),
	exit (1);
      for (i = 0; i < MAX_SET_OPTIONS; i++)
	RESET (newmode),
	fscanf (from, "%s ", newmode),
	fprintf (f, "%s = %s\n", options[i], newmode);
      fflush (f);
      fclose (from);
      COMPLETE_TELNET (f);
      fclose (f);
      DELIVER_MAIL (sender);
      unlink (OLD_SUBSCRIBERS);
      return;
    }
  }
  /* Change of mode */
  syscom ("mv %s %s", subscribersf, OLD_SUBSCRIBERS);
  if ((from = fopen (OLD_SUBSCRIBERS, "r")) == NULL)
    sprintf (error, "set(): Could not open %s", OLD_SUBSCRIBERS),
    report_progress (report, error, TRUE),
    exit (1);
  if ((to = fopen (subscribersf, "w")) == NULL)
    sprintf (error, "set(): Could not open %s", subscribersf),
    report_progress (report, error, TRUE),
    exit (1);
  while (!feof (from)) {
    subscriber[0] = RESET (name);
    extract_subscriber (from, subscriber);
    for (i = 0; i < MAX_SET_OPTIONS; i++)
      RESET (oldmodes[i]),
      fscanf (from, "%s ", oldmodes[i]);
    fgets (name, MAX_LINE - 2, from);
    upcase (subscriber);
    if (!feof (from)) {
      fprintf (to, "%s ", subscriber);
      if (! strcmp (sender, subscriber))
	for (i = 0; i < MAX_SET_OPTIONS; i++)
	  fprintf (to, "%s ", (i == index) ? newmode : oldmodes[i]);
      else
	for (i = 0; i < MAX_SET_OPTIONS; i++)
	  fprintf (to, "%s ", oldmodes[i]);
      fprintf (to, "%s", name);
    }
  }
  fclose (from);
  fclose (to);
  unlink (OLD_SUBSCRIBERS);
  if (! one_rejection) {
    create_header (&f, MAILFORWARD, sys.server.address, sender, request);
    fprintf (f, "%s mode reset to %s\n", options[index], newmode);
    COMPLETE_TELNET (f);
    fclose (f);
    DELIVER_MAIL (sender);
  }
}

/*
  Provide user with the current list of subscribers. Peer servers are
  also notified and they send their own compilations.
*/

void recipients (char *request, char *params, char *sender)
{
  char error [MAX_LINE];
  char param [MAX_LINE];
  FILE *f;

  sprintf (request + strlen (request), " %s%s", sys.lists[listid].alias,
           params); /* Used as a subject */
  error[0] = RESET (param);
  sscanf (params, "%s", param);
  if (param[0] != EOS) {
    sprintf (error, "Invalid RECIPIENTS option%s", params);
    reject_mail (sender, error);
    return;
  }
  create_header (&f, MAILFORWARD, sys.server.address, sender, request);
  fprintf (f, "Here is the current list of subscribers:\n\n");
  fclose (f);
  syscom ("%s -d\" \" -f1,3-6 %s > %s", CUT, subscribersf, recipf);
  syscom ("%s -f %s %s >> %s", AWK, AWK_PROG, recipf, MAILFORWARD);
  unlink (recipf);
  syscom ("echo Total number of subscribers: `cat %s | wc -l` >> %s",
          subscribersf, MAILFORWARD);
  APPEND_TELNET ("recipients");
  DELIVER_MAIL (sender);
  notify_peer_servers (peersf, "recipients", params, sender);
}

/*
  Provide user with general information about the list. A reminder, the
  actual text is in the INFO_FILE.
*/

void info (char *request, char *params, char *sender)
{
  char error [MAX_LINE];
  char param [MAX_LINE];
  FILE *f;

  sprintf (request + strlen (request), " %s%s", sys.lists[listid].alias,
           params); /* Used as a subject */
  error[0] = RESET (param);
  sscanf (params, "%s", param);
  if (param[0] != EOS) {
    sprintf (error, "Invalid INFORMATION option%s", params);
    reject_mail (sender, error);
    return;
  }
  create_header (&f, MAILFORWARD, sys.server.address, sender, request);
  fclose (f);
  syscom ("cat %s >> %s", infof, MAILFORWARD);
  APPEND_TELNET ("info");
  DELIVER_MAIL (sender);
}

/*
  Collect and send statistics about all subscribers, by grepping through
  HEADERS. If a user has selected particular names (asterisks are OK) then
  give statistics about these people only. Also include a total count
  of messages on file. Peer servers are also notified and they send their
  own compilations.
*/

void stats (char *request, char *params, char *sender)
{
  FILE *f;
  char subscriber [MAX_LINE], error [MAX_LINE];
  char junk [MAX_LINE];
  struct stat stat_buf;

  sprintf (request + strlen (request), " %s%s", sys.lists[listid].alias,
           params); /* Used as a subject */
  params [strlen (params) - 1] = EOS; /* Remove \n */
  junk[0] = RESET (error);
  sscanf (params, "%s", junk);
  if (junk[0] == EOS) /* No specific subscribers to report on */
    RESET (params);
  if (stat (headersf, &stat_buf)) {
    NOTIFY_OF_BAD_ARCHIVE ("Sorry, no mail archive found.\n", NULL);
    return;
  }
  create_header (&f, MAILFORWARD, sys.server.address, sender, request);
  fprintf (f, "Here are the number of messages per subscriber:\n\n");
  fclose (f);
  syscom ("%s %s %s %s %s %s", STATS_PROG, PATH", subscribersf,
          headersf, MAILFORWARD, params);
  APPEND_TELNET ("stats");
  DELIVER_MAIL (sender);
  notify_peer_servers (peersf, "statistics", params, sender);
}

/*
  Exit with a shutdown status if the correct password is provided.
*/

void Shutdown (char *request, char *params, char *sender)
{
  char error [MAX_LINE];
  char passwd [MAX_LINE];

  sscanf (params, "%s\n", passwd);
  if (!strcmp (sys.server.password, passwd))
    report_progress (report, "SHUTDOWN request accepted", TRUE),
    exit (6); /* Exit status of 6 signifies a shutdown request */
  RESET (error);
  sprintf (error, "Unrecognized request %s\n", request),
  reject_mail (sender, error);
}

/*
  Set the global variable 'restart_sys' to TRUE if the correct password
  is given.
*/

void restart (char *request, char *params, char *sender)
{
  char error [MAX_LINE];
  char passwd [MAX_LINE];

  sscanf (params, "%s\n", passwd);
  if (!strcmp (sys.server.password, passwd)) { 
    report_progress (report, "RESTART request accepted\n", FALSE);
    restart_sys = TRUE;
    return;
  }
  RESET (error);
  sprintf (error, "Unrecognized request %s\n", request);
  reject_mail (sender, error);
}

/*
  Provide 'sender' with a list of all discussion lists served by this server.
*/

void lists (char *request, char *params, char *sender)
{
  char param [MAX_LINE];
  FILE *f;
  int i;

  sprintf (request + strlen (request), "%s", params); /* Used as a subject */
  RESET (param);
  sscanf (params, "%s", param);
  if (param[0] != EOS) {
    sprintf (param, "Invalid LISTS option%s", params);
    reject_mail (sender, param);
    return;
  }
  create_header (&f, MAILFORWARD, sys.server.address, sender, request);
  fprintf (f, "Here is the current active list of discussion lists served by \
this server:\n\n");
  for (i = 0; i < nlists; ++i)
    fprintf (f, "%s\t%s\n", sys.lists[i].address, sys.lists[i].comment);
  COMPLETE_TELNET (f);
  fclose (f);
  DELIVER_MAIL (sender);
}

/*
  Get an index of files for the specified archive, or the master archive
  if none specified.

  Adapted USER CONTRIBUTED FUNCTION.
*/

void Index (char *request, char *params, char *sender)
{
  FILE *f, *index, *dir, *master;
  char error [MAX_LINE];
  char archive [MAX_LINE];
  char arch [MAX_LINE];
  char line [MAX_LINE];
  char file [MAX_LINE];
  char fullpath [MAX_LINE];
  char moreparams [MAX_LINE];
  char fullname [MAX_LINE];
  char desc [MAX_LINE];
  char junk [MAX_LINE];
  BOOLEAN found;
  int count, parts;

  sprintf (request + strlen (request), "%s", params); /* Used as a subject */
  error[0] = archive[0] = fullpath[0] = fullname[0] = RESET (moreparams);
  sscanf (params, "%s %s", archive, moreparams);
  locase (archive);
  if (moreparams[0] != EOS) {
    sprintf (error, "Too many arguments to INDEX: %s\n", moreparams);
    reject_mail (sender, error);
    return;
  }
  if (archive[0] == EOS) /* Get archive */
    strcpy (archive, DEFAULT_ARCHIVE);
  sprintf (fullpath, "%s/%s/%s", ARCHIVE_DIR, DEFAULT_ARCHIVE, INDEX);
  if ((master = fopen (fullpath, "r")) == NULL) {
    NOTIFY_OF_BAD_ARCHIVE ("%s: Sorry, no master index found.\n", archive);
    return;
  }
  found = FALSE;
  while (!feof (master)) { /* Look at the master index for fullpath */
    fullpath[0] = arch[0] = RESET (line);
    fgets (line, MAX_LINE - 2, master);
    if (line[0] != EOS) {
      sscanf (line, "%s %s\n", arch, fullpath);
      locase (arch);
      if (!strcmp (arch, archive)) {
 	found = TRUE;
	break;
      }
    }
  }
  fclose (master);
  if (!found) {
    NOTIFY_OF_BAD_ARCHIVE ("Sorry, archive %s not found.\n", archive);
    return;
  }
  sprintf (fullname, "%s/%s", fullpath, INDEX);
  if ((index = fopen (fullname, "r")) == NULL) { /* Open index */
    NOTIFY_OF_BAD_ARCHIVE ("Sorry, no index found in archive %s.\n", archive);
    return;
  }
  create_header (&f, MAILFORWARD, sys.server.address, sender, request);
  count = 0;
  while (!feof (index)) { /* Echo archive; goto archive a get DIR file */
    fullpath[0] = archive[0] = RESET (line);
    fgets (line, MAX_LINE - 2, index);
    if (line[0] != EOS) {
      sscanf (line, "%s %s\n", archive, fullpath);
      fprintf (f, "\n%s: %s -- Files:\n", (!count ?  "Archive" : "Subarchive"),
	       archive);
      if (chdir (fullpath))
	fprintf (f, "%s: Sorry, archive out of date.\n", archive);
      else { /* Open DIR and get file names */
	if ((dir = fopen (DIR, "r")) == NULL)
	  fprintf (f, "Cannot obtain directory information.\n");
	else
	  while (!feof (dir)) {
	    desc[0] = line[0] = junk[0] = RESET (file);
	    fscanf (dir, "%s %d %s", file, &parts, junk);
	    fgets (desc, MAX_LINE - 2, dir);
	    if (desc[strlen (desc) - 1] == '\n')
	      desc[strlen (desc) - 1] = EOS;
	    if (file[0] != EOS)
	      fprintf (f, "  %s (%d part%s %s%s\n", file, parts,
		       (parts > 1 ? "s)" : ")"),
		       ((desc[0] != EOS) ? "--" : " "), desc);
	  }
	fclose (dir);
      }
    }
    ++count;
  }
  fclose (index);
  COMPLETE_TELNET (f);
  fclose (f);
  DELIVER_MAIL (sender);
}

/*
  Send the requested file from the specified archive. The file may have been
  split in subparts, and in this case several emails will be sent -- one
  for each part. The user may also obtain certain parts.

  Adapted USER CONTRIBUTED FUNCTION.
*/

void get (char *request, char *params, char *sender)
{
  FILE *f, *dir, *master;
  char error [MAX_LINE];
  char archive [MAX_LINE];
  char arch [MAX_LINE];
  char fullpath [MAX_LINE];
  char moreparams [MAX_LINE];
  char filename [MAX_LINE];
  char fullname [MAX_LINE];
  char dirpath [MAX_LINE];
  char file [MAX_LINE];
  char line [MAX_LINE];
  char copy [MAX_LINE];
  struct stat stat_buf;
  int i, count = 0;
  BOOLEAN found;

  sprintf (request + strlen (request), "%s", params); /* Used as a subject */
  error[0] = archive[0] = fullpath[0] = fullname[0] = dirpath[0] =
  filename[0] = RESET (moreparams);
  params [strlen (params) - 1] = EOS; /* Remove \n */
  sscanf (params, "%s %s %s", archive, filename, moreparams);
  locase (archive);
  locase (filename);
  if (archive[0] == EOS || filename[0] == EOS) { /* Missing args */
    sprintf (error, "GET: missing archive or file name\n");
    reject_mail (sender, error);
    return;
  }
  if (moreparams[0] != EOS) { /* Specified parts to get */
    strcpy (copy, filename);
    upcase (copy);
    do {
      sprintf (params, "%s", params + 1);
    } while (strncmp (params, copy, strlen (copy)));
    sprintf (params, "%s", params + strlen (copy));
    sprintf (params, "%s", strchr (params, moreparams[0]));
  }
  sprintf (fullpath, "%s/%s/%s", ARCHIVE_DIR, DEFAULT_ARCHIVE, INDEX);
  if ((master = fopen (fullpath, "r")) == NULL) {
    NOTIFY_OF_BAD_ARCHIVE ("%s: Sorry, no master index found.\n", archive);
    return;
  }
  found = FALSE;
  while (!feof (master)) { /* Look at the master index for fullpath */
    fullpath[0] = arch[0] = RESET (line);
    fgets (line, MAX_LINE - 2, master);
    if (line[0] != EOS) {
      sscanf (line, "%s %s\n", arch, fullpath);
      locase (arch);
      if (!strcmp (arch, archive)) {
        found = TRUE;
        break;
      }
    }
  }
  fclose (master);
  if (!found) {
    NOTIFY_OF_BAD_ARCHIVE ("Sorry, archive %s not found.\n", archive);
    return;
  }
  sprintf (dirpath, "%s/%s", fullpath, DIR);
  if ((dir = fopen (dirpath, "r")) == NULL) { /* Dir archive */
    NOTIFY_OF_BAD_ARCHIVE ("Unable to dir archive %s\n", archive);
    return;
  }
  while (!feof (dir)) { /* Get location and file-count of file to send */
    file[0] = fullpath[0] = RESET (line);
    fgets (line, MAX_LINE - 2, dir);
    if (line[0] != EOS) {
      sscanf (line, "%s %d %s", file, &count, fullpath);
      locase (file);
      if (!strcmp (filename, file))
	break;
    }
  }
  fclose (dir);
  for (i = 1; i <= count; i++) { /* Send all parts of the file */
    RESET (fullname);
    if (count > 1)
      sprintf (fullname, "%s/%s%d", fullpath, filename, i);
    else
      sprintf (fullname, "%s/%s", fullpath, filename);
    if (moreparams[0] != EOS && !requested_part (params, i))
      continue;
    syscom ("uncompress %s > /dev/null 2>&1", fullname);
    if (stat (fullname, &stat_buf)) {
      NOTIFY_OF_BAD_ARCHIVE ("Sorry, file %s not found in specified archive.\n",
			    filename);
      return;
    }
    create_header (&f, MAILFORWARD, sys.server.address, sender, request);
    fprintf (f, "Archive %s: file %s, part %d/%d:\n\n", archive, filename, i,
	     count);
    fprintf (f, "------------------------------ Cut here \
------------------------------\n");
    fclose (f);
    syscom ("cat %s >> %s", fullname, MAILFORWARD);
    syscom ("echo ------------------------------ Cut here \
------------------------------ >> %s", MAILFORWARD);
    APPEND_TELNET ("get");
    DELIVER_MAIL (sender);
    syscom ("compress %s > /dev/null 2>&1", fullname);
  }
}

/*
  Give specific information about this release.
*/

void release (char *request, char *params, char *sender)
{
  char param [MAX_LINE];
  FILE *f;

  sprintf (request + strlen (request), "%s", params); /* Used as a subject */
  RESET (param);
  sscanf (params, "%s", param);
  if (param[0] != EOS) {
    sprintf (param, "Invalid RELEASE option%s", params);
    reject_mail (sender, param);
    return;
  }
  create_header (&f, MAILFORWARD, sys.server.address, sender, request);
  fprintf (f, "UNIX Listserv, version %s\n", VERSION);
  fprintf (f, "Last update: %s\nManager: %s\nListserv address: %s\n",
	   UPDATE_DATE, sys.manager, sys.server.address);
  COMPLETE_TELNET (f);
  fclose (f);
  DELIVER_MAIL (sender);
}

/*
  Forward a 'request' to all servers handling peer lists.
*/

void notify_peer_servers (char *file, char *request, char *params, char *sender)
{
  FILE *f, *mail;
  char *mail_method;
  char email [MAX_LINE];
  char mode [MAX_LINE];
  char alias [MAX_LINE];
  char listserv [MAX_LINE];
  char servers [MAX_LINE];
  char error [MAX_LINE];
  char subject [MAX_LINE];

  if (peer_server_request || do_not_notify_peer_server)
    return;
  if ((f = fopen (file, "r")) == NULL)
    sprintf (error, "notify_peer_servers(): Could not open %s", file),
    report_progress (report, error, TRUE),
    exit (1);
  sprintf (subject, "%s%s", PEER_SERVER_REQUEST, sys.server.address);
  RESET (servers);
  if (sys.options & USE_ENV_VAR) {
    if ((mail_method = (char *) malloc ((10 + strlen (sys.mail.env_var) +
					 strlen (sender) +
					 strlen (sys.mail.mail_prog))
					* sizeof (char))) == NULL)
      report_progress (report,  "\nnotify_peer_servers(): malloc failed",
		       TRUE),
      exit (16);
    sprintf (mail_method, "env - %s=%s %s ", sys.mail.env_var,
	     sender, sys.mail.mail_prog);
  }
  else {
    if ((mail_method = (char *) malloc ((strlen (sys.mail.method) + 1) 
					* sizeof (char))) == NULL)
      report_progress (report, "\nnotify_peer_servers(): malloc failed",
		       TRUE),
      exit (16);
    strcpy (mail_method, sys.mail.method);
  }
  while (!feof (f)) {
    email[0] = mode[0] = alias[0] = RESET (listserv);
    fscanf (f, "%s %s %s %s\n", email, mode, alias, listserv);
    if (email[0] != EOS) { /* Send mail to peer server */
      sprintf (servers + strlen (servers), "%s\n", listserv);
      create_header (&mail, MAILFORWARD, sender, listserv, 
		     subject);
      fprintf (mail, "%s %s %s\n", request, alias, params);
      COMPLETE_TELNET (mail);
      fclose (mail);
      if (sys.options & USE_SYSMAIL)
	sysmail (MAILFORWARD);
      else
	syscom ("%s %s < %s", mail_method,
		(((sys.options & USE_TELNET) == 0) ? locase (listserv) : ""),
		MAILFORWARD);
    }
  }
  if (servers[0] != EOS) { /* Notify sender as well */
    sprintf (subject, "Notification from %s", sys.server.address);
    create_header (&mail, MAILFORWARD, sys.server.address, sender, subject);
    fprintf (mail, "%s: Your request has been forwarded to the following peer \
servers,\nwho will forward you with a copy of their own results:\n\n%s", 
upcase (request), servers);
    COMPLETE_TELNET (mail);
    fclose (mail);
    if (sys.options & USE_SYSMAIL)
      sysmail (MAILFORWARD);
    else
      syscom ("%s %s < %s", mail_method,
	      (((sys.options & USE_TELNET) == 0) ? locase (sender) : ""),
	      MAILFORWARD);
  }
  free ((char *) mail_method);
  fclose (f);
}

/*
  Initialize the commands[].
*/

void init_commands ()
{
  commands[0].name = "HELP";
  commands[0].mask = 0x001;
  commands[0].func = help;
  commands[1].name = "SET";
  commands[1].mask = 0x002;
  commands[1].func = set;
  commands[2].name = "SUBSCRIBE";
  commands[2].mask = 0x004;
  commands[2].func = subscribe;
  commands[3].name = "UNSUBSCRIBE";
  commands[3].mask = 0x008;
  commands[3].func = unsubscribe;
  commands[4].name = "SIGNOFF";
  commands[4].mask = 0x008;
  commands[4].func = unsubscribe;
  commands[5].name = "RECIPIENTS";
  commands[5].mask = 0x010;
  commands[5].func = recipients;
  commands[6].name = "REVIEW";
  commands[6].mask = 0x010;
  commands[6].func = recipients;
  commands[7].name = "INFORMATION";
  commands[7].mask = 0x020;
  commands[7].func = info;
  commands[8].name = "STATISTICS";
  commands[8].mask = 0x040;
  commands[8].func = stats;
  commands[9].name = "SHUTDOWN";
  commands[9].mask = 0x080;
  commands[9].func = Shutdown;
  commands[10].name = "RESTART";
  commands[10].mask = 0x100;
  commands[10].func = restart;
  commands[11].name = "LISTS";
  commands[11].mask = 0x200;
  commands[11].func = lists;
  commands[12].name = "INDEX";
  commands[12].mask = 0x400;
  commands[12].func = Index;
  commands[13].name = "GET";
  commands[13].mask = 0x800;
  commands[13].func = get;
  commands[14].name = "RELEASE";
  commands[14].mask = 0x1000;
  commands[14].func = release;
}

void usage ()
{
  fprintf (stderr, "Usage: listserv [-1] [-e] [-n] {[-r <request>]}* \
{[-d <request>]}* [-D]\n\
-1: Execute only once.\n\
-e: Echo reports to the screen.\n\
-n: Do not notify peer servers.\n\
-r: Set restriction on 'request'.\n\
-d: Disable 'request'.\n\
-D: Turn debug on.\n");
  exit (3);
}

void server_config (char *alias)
{
  setup_string (infof, alias, INFO_FILE);
  setup_string (recipf, alias, RECIP_FILE);
  setup_string (welcomef, alias, WELCOME_FILE);
  setup_string (subscribersf, alias, SUBSCRIBERS);
  setup_string (aliasesf, alias, ALIASES);
  setup_string (newsf, alias, NEWSF);
  setup_string (peersf, alias, PEERS);
  setup_string (headersf, alias, HEADERS);
  setup_string (ignoredf, alias, IGNORED);
}

/*
  Graceful exit. Remove pid file.
*/

void gexit ()
{
  unlink (PID_SERVER);
  exit (0);
}
