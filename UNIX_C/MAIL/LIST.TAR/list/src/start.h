/*
  AGREEMENT: This software can be used and distributed freely as long
  as you do not remove or alter the Copyright notice in the file defs.h;
  this notice is #define'd in the symbol VERSION. Although you may alter
  the code provided, you may not alter the functions create_header()
  and create_multi_recipient_header() in list.c and listserv.c.
  By using this software you are bound by this agreement.
  This software comes with no warranties and cannot be sold for profit.
  The AGREEMENT and COPYRIGHT notices should be included in all source
  files when distributing this software.
  COPYRIGHT: Copyright (c) 1991, Anastasios C. Kotsikonas

  Below are the #define's pertinent to start.c

  Preserve any quotes that appear below; change only path names.

  ALWAYS SPECIFY ABSOLUTE PATHS.

*/

#define REPORT_LIST_ACC     ".rep.list.acc"
#define REPORT_SERVER_ACC   PATH/.rep.server.acc"
#define REPORT_SERVERD_ACC  PATH/.rep.serverd.acc"
#define REPORT_START_ACC    PATH/.rep.start.acc"
#define REPORT_PQUEUE_ACC   PATH/.rep.pqueue.acc"
#define REPORT_START	    PATH/.report.start"
#define MODERATED_MAIL_FILE "moderated"

char    report_list_accf [MAX_LINE];
BOOLEAN tty_echo = TRUE;
