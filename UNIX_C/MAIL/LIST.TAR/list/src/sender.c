/*
  ----------------------------------------------------------------------------
  |                	  SENDER ORIENTED FUNCTIONS			     |
  |                                                                          |
  |                              Version 2.0                                 |
  |                                                                          |
  |                (or, when Computer Science gets to you)                   |
  |                                                                          |
  |                    Written by Anastasios Kotsikonas                      |
  |                           (tasos@cs.bu.edu)                              |
  |                                                                          |
  | AGREEMENT: This software can be used and distributed freely as long      |
  | as you do not remove or alter the Copyright notice in the file defs.h;   |
  | this notice is #define'd in the symbol VERSION. Although you may alter   |
  | the code provided, you may not alter the functions create_header()       |
  | and create_multi_recipient_header() in list.c and listserv.c.            |
  | By using this software you are bound by this agreement.                  |
  | This software comes with no warranties and cannot be sold for profit.    |
  | The AGREEMENT and COPYRIGHT notices should be included in all source     |
  | files when distributing this software.                                   |
  | COPYRIGHT: Copyright (c) 1991, Anastasios C. Kotsikonas                  |
  ----------------------------------------------------------------------------
*/

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "defs.h"

extern  void report_progress (FILE *, char *, int);
extern  char *upcase (char *);
extern  void extract_subscriber (FILE *, char *);

BOOLEAN subscribed (FILE *, char *, char *, char *, char *, char *);
BOOLEAN check_file (FILE *, char *, char *, BOOLEAN);
BOOLEAN ignore_sender (FILE *, char *, FILE *);
void    extract_sender (char *);
void    extract_subscriber (FILE *f, char *subscriber);
void    extract_origin (char *);

/*
  Check if 'sender' is subscribed. Return SUBSCRIBED, NEWS PEER or
  NOTSUBSCRIBED. Comparisons are done in upper case.
*/

BOOLEAN subscribed (FILE *report, char *sender, char *subscribersf,
		    char *newsf, char *peersf, char *aliasesf)
{
  if (subscribersf == NULL) /* call made by distribute () in listserv.c */
    return NOTSUBSCRIBED;
  if (check_file (report, sender, subscribersf, FALSE) ||
      check_file (report, sender, aliasesf, TRUE))
    return SUBSCRIBED;
  else if (newsf != NULL && (check_file (report, sender, newsf, FALSE) ||
			     check_file (report, sender, aliasesf, TRUE)))
    return NEWS;
  else if (peersf != NULL && (check_file (report, sender, peersf, FALSE) ||
			      check_file (report, sender, aliasesf, TRUE)))
    return PEER;
  return NOTSUBSCRIBED;
}

/*
  Check the given file for subscription. If the file is an aliases file
  and the sender is listed in there, store his actual mailing address
  in 'sender'.
*/

BOOLEAN check_file (FILE *report, char *sender, char *file,
		    BOOLEAN checking_aliases)
{
  char subscriber [MAX_LINE];
  char mode [MAX_LINE];
  char name [MAX_LINE];
  char error [MAX_LINE];
  FILE *f;

  if ((f = fopen (file, "r")) == NULL)
    RESET (error),
    sprintf (error, "\ncheck_file(): Could not open %s", file),
    report_progress (report, error, TRUE),
    exit (1);
  upcase (sender);          /* Convert to upper case */
  while (!feof (f)) {  /* Check list of subscribers */
    subscriber[0] = mode[0] = RESET (name);
    extract_subscriber (f, subscriber);
    fscanf (f, "%s ", mode);
    if (!checking_aliases)
      fgets (name, MAX_LINE - 2, f);
    upcase (subscriber);
    if (!strcmp (sender, subscriber)) {
      fclose (f);
      if (checking_aliases)
	upcase (mode),
	strcpy (sender, mode);
      return SUBSCRIBED;
    }
  }
  fclose (f);
  return NOTSUBSCRIBED;
}

/*
  Check if 'sender' appears in the IGNORED file.
*/

BOOLEAN ignore_sender (FILE *ignored, char *sender, FILE *report)
{
  char report_msg [MAX_LINE];
  char ignored_user [MAX_LINE];
  char line[MAX_LINE];

  rewind (ignored);
  while (!feof (ignored)) { /* Check the IGNORED file first */
    line[0] = RESET (ignored_user);
    fgets (line, MAX_LINE - 2, ignored);
    sscanf (line, "%s", ignored_user);
    upcase (ignored_user);
    if (ignored_user[0] != EOS)
      if (!strcmp (ignored_user, sender)) {
        RESET (report_msg);
        sprintf (report_msg, "User %s and message ignored.\n", sender);
        report_progress (report, report_msg, FALSE);
        return TRUE;
      }
  }
  return FALSE;
}

/*
  Extract the sender's email address. To do that, skip over the leading
  "From ". That's where the address starts. Then put an EOS character at
  the end of this address (a blank terminates this address string).
*/

void extract_sender (char *s)
{
  int nsquote = 0, ndquote = 0, nparen = 0, nangle = 0, nsquare = 0;
  BOOLEAN done = FALSE;

  sprintf (s, "%s", s + strlen (START_OF_MESSAGE));
  while (*s && !done) { /* Look for end of address substring */
    (*s == '\"' ? (nsquote ? (nsquote = 0) : (nsquote = 1)) : 0);
    (*s == '\"' ? (ndquote ? (ndquote = 0) : (ndquote = 1)) : 0);
    (*s == '(' ? ++nparen : 0);
    (*s == ')' ? --nparen : 0);
    (*s == '<' ? ++nangle : 0);
    (*s == '>' ? --nangle : 0);
    (*s == '[' ? ++nsquare : 0);
    (*s == ']' ? --nsquare : 0);
    ((*s == ' ' || *s == '\t') ?
     ((nsquote || ndquote || nparen || nangle || nsquare) ? 
      0 : (done = TRUE)) : 0);
    ++s;
  }
  *(s - 1) = EOS;  /* 's' is now pointing to the sender's address */
}

/*
  Extract the subscriber's address from the file.
*/

void extract_subscriber (FILE *f, char *subscriber)
{
  int nsquote = 0, ndquote = 0, nparen = 0, nangle = 0, nsquare = 0, i = 0;
  BOOLEAN done = FALSE;
  char c;

  while (!feof (f) && !done) {
    c = fgetc (f);
    (c == '\"' ? (nsquote ? (nsquote = 0) : (nsquote = 1)) : 0);
    (c == '\"' ? (ndquote ? (ndquote = 0) : (ndquote = 1)) : 0);
    (c == '(' ? ++nparen : 0);
    (c == ')' ? --nparen : 0);
    (c == '<' ? ++nangle : 0);
    (c == '>' ? --nangle : 0);
    (c == '[' ? ++nsquare : 0);
    (c == ']' ? --nsquare : 0);
    ((c == ' ' || c == '\t') ? 
     ((nsquote || ndquote || nparen || nangle || nsquare) ? 
      0 : (done = TRUE)) : 0);
    subscriber [i++] = c;
  }
  if (i > 0)
    subscriber[i - 1] = EOS;
}

/*
  Extract the originator of the message, i.e. the list that the original
  message first originated from.
*/

void extract_origin (char *s)
{
  char *p;

  if (p = strchr (s, '<'))
    sprintf (s, "%s", p + 1); /* Remove '<' */
  if (p = strchr (s, '>'))
    *p = EOS;  /* Remove '>' */
  else {  /* Get to the end of the address */
    while (*s != EOS && !isspace (*s))
      ++s;
    *s = EOS;
  }
}
