/* 
  AGREEMENT: This software can be used and distributed freely as long
  as you do not remove or alter the Copyright notice in the file defs.h;
  this notice is #define'd in the symbol VERSION. Although you may alter
  the code provided, you may not alter the functions create_header()
  and create_multi_recipient_header() in list.c and listserv.c.
  By using this software you are bound by this agreement.
  This software comes with no warranties and cannot be sold for profit.
  The AGREEMENT and COPYRIGHT notices should be included in all source
  files when distributing this software.
  COPYRIGHT: Copyright (c) 1991, Anastasios C. Kotsikonas

  Below are the #define's pertinent to list.c

  Preserve any quotes and new lines that appear below; change only path names.

  ALWAYS SPECIFY ABSOLUTE PATHS.

*/

#define MAIL_COPY         ".messages"
#define MSG               ".msg"
#define MAILFORWARD       ".mailforward"
#define MSG_NO            ".msgno"
#define MBOX              "mbox"            /* place to save list's messages */
#define FROM              "From: " /* Keep this line and the following from */
#define ORIGIN		  "Originator: "
#define REPLY_TO	  "Reply-To: "
#define NO_RECIPIENT_FILE "NONE"

#define PREPEND(str, buf) \
  { char copy [1024];\
    RESET (copy);\
    strcat (copy, buf);\
    sprintf (buf, "%s%s", str, copy);\
  }

char mboxf [MAX_LINE];
char msg_nof [MAX_LINE];
char mailforwardf [MAX_LINE];
char msgf [MAX_LINE];
char mail_copyf [MAX_LINE];
char list_moderated_f [MAX_LINE];
char **multi_recipients;  /* List of multiple recipient addresses */
char *list_alias  = NULL; /* arg to the -L command option */

FILE *mail        = NULL; /* Source of messages */
FILE *report      = NULL; /* Progress report to the administrator */
FILE *subscribers = NULL; /* List of subscribers */
FILE *news	  = NULL; /* List of newsgroups */
FILE *peers	  = NULL; /* List of peers */
FILE *restricted  = NULL; /* List of people whose messages require special
                              handling */
FILE *ignored     = NULL; /* List of people whose messages are ignored */
FILE *msg_no      = NULL; /* Last message count */
FILE *headers     = NULL; /* File containing headers of messages only */
FILE *message_ids = NULL; /* File containing message ids */

BOOLEAN tty_echo	    = FALSE;/* -e option off */
BOOLEAN send_to_subscribers = TRUE; /* -r option off */
BOOLEAN execute_once        = FALSE;/* -1 option off */
BOOLEAN errors_to_manager   = FALSE;/* -f option off */
BOOLEAN multi_recip	    = FALSE;/* -m option off */
BOOLEAN do_not_check_subscriptions = FALSE;/* -s option off */
BOOLEAN article_replies_to_author  = FALSE;/* -p option off */
int     returned_msg = 0;           /* Counts the invalid messages */
int     public_msg = 0;             /* Counts the public messages */
int     listid = -1;
int	maxrecipients = 0;
