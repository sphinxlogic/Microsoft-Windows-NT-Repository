/*
  ----------------------------------------------------------------------------
  |                		tlock UTILITY 				     |
  |                                                                          |
  |                              Version 1.0                                 |
  |                                                                          |
  |                (or, when Computer Science gets to you)                   |
  |                                                                          |
  |                    Written by Anastasios Kotsikonas                      |
  |                           (tasos@cs.bu.edu)                              |
  |                                                                          |
  | AGREEMENT: This software can be used and distributed freely as long      |
  | as you do not remove or alter the Copyright notice in the file defs.h;   |
  | this notice is #define'd in the symbol VERSION. Although you may alter   |
  | the code provided, you may not alter the functions create_header()       |
  | and create_multi_recipient_header() in list.c and listserv.c.            |
  | By using this software you are bound by this agreement.                  |
  | This software comes with no warranties and cannot be sold for profit.    |
  | The AGREEMENT and COPYRIGHT notices should be included in all source     |
  | files when distributing this software.                                   |
  | COPYRIGHT: Copyright (c) 1991, Anastasios C. Kotsikonas                  |
  ----------------------------------------------------------------------------
*/

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include "defs.h"

void main ();

char *s[] = { 
  SERVERD_LOCK_FILE, LIST_LOCK_FILE, SERVER_LOCK_FILE, PQUEUE_LOCK_FILE, NULL
};

/*
  Test whether any locks exist on the above files by other processes.
*/

void main ()
{
#ifndef _MINIX
  int i, fd, locks = 0;

  for (i = 0; s[i]; i++) {
    if (lockf ((fd = open (s[i], O_RDWR)), F_TLOCK, 0))
      if (errno == EBADF)
	locks = -1,
	fprintf (stderr, "Cannot access %s\n", s[i]);
      else
	++locks,
	printf ("Lock placed on %s\n", s[i]);
    close (fd);
  }
  if (!locks)
#endif
    printf ("No files locked.\n");
}
