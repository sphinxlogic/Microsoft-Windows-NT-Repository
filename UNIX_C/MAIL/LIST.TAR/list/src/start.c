/*
  ----------------------------------------------------------------------------
  |                  DISCUSSION LIST SYSTEM HOUSEKEEPER                      |
  |                                                                          |
  |                              Version 2.5                                 |
  |                                                                          |
  |                (or, when Computer Science gets to you)                   |
  |                                                                          |
  |                    Written by Anastasios Kotsikonas                      |
  |                           (tasos@cs.bu.edu)                              |
  |                                                                          |
  | AGREEMENT: This software can be used and distributed freely as long	     |
  | as you do not remove or alter the Copyright notice in the file defs.h;   |
  | this notice is #define'd in the symbol VERSION. Although you may alter   |
  | the code provided, you may not alter the functions create_header()       |
  | and create_multi_recipient_header() in list.c and listserv.c.            |
  | By using this software you are bound by this agreement.                  |
  | This software comes with no warranties and cannot be sold for profit.    |
  | The AGREEMENT and COPYRIGHT notices should be included in all source     |
  | files when distributing this software.                                   |
  | COPYRIGHT: Copyright (c) 1991, Anastasios C. Kotsikonas		     |
  ----------------------------------------------------------------------------

  This is the proper way of starting the discussion list. The program verifies
  that no other serverd, list or listserv programs are running on the 
  system (and kills them before proceeding -- after confirming), 
  makes sure the required files exist (and creates new ones if missing -- 
  after confirming), backs up all reports into files with extension .acc,
  creates new directories for new discussion lists as necessary,
  and finally spawns serverd. start reports to REPORT_START.

  COMMAND LINE OPTIONS:
    -k: just kill all pertinent programs that may already be running; no
	discussion list is started in this case.
    -c: Do not confirm before killing a process.
    -r: Do not report; useful when starting up when system is rebooted.
  
  WARNING: The program won't work correctly in the absence of an extended
  egrep facility that does matching at the end of a line with a $ and 
  accepts multiple regular expressions separated by a |. In this case,
  the user may have to manually look for and terminate any such programs.
  Also when the output of the 'ps' command exceeds 80 characters (due perhaps
  to long path names) the user may again have to terminate programs by hand.
  Note that a file locking mechanism  for serverd, list and listserv is used 
  to ensure against multiple executions of the same program.

  WARNING: When using the SYSV ps command and it chops output to 80 characters,
  start may not be able to locate processes already running; this may occur if
  the path to /usr/server is too long.
*/

#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "defs.h"
#include "start.h"
#include "struct.h"
#include "global.h"

#define GET_RESPONSE  {\
			fflush (stdout); \
			fflush (stdin); \
			c = fgetc (stdin); \
			if (c != '\n' && c != EOF) \
			  while (fgetc (stdin) != '\n'); \
			fflush (stdin);\
		      }

/*
  Function prototypes:
*/

#ifdef __STDC__
#include <stdarg.h>
extern int  syscom (char *, ...);
#else
#include <varargs.h>
extern int  syscom ();
#endif
extern char *extract_filename (char *);
extern void report_progress (FILE *, char *, int);
extern int  getopt (int, char **, char *);
void   main (int, char **);
void   check_for (char *, FILE *, BOOLEAN, BOOLEAN);
void   usage (void);
void   start_abort (void);
void   backup (char *, char *);
void   start_config (char *);

void main (int argc, char **argv)
{
  char command [256];
  char line [MAX_LINE];
  char msg [2 * MAX_LINE];
  char dir [MAX_LINE];
  char *addr1, *addr2, *addr3, *addr4, *options = "ckr";
  int c;
  FILE *f, *p, *report;
  int i, nlists, pid, procs_killed = 0, procs;
  BOOLEAN just_kill = FALSE, confirm = TRUE, do_report = TRUE;
  struct stat stat_buf;
  extern char *optarg;
  extern int optopt;
  
  while ((c = getopt (argc, argv, options)) != EOF)
    switch ((char) c) {
      case 'c': confirm = FALSE; break;
      case 'k': just_kill = TRUE; break;
      case 'r': do_report = FALSE; break;
      case '?':
      default:
	usage();
    }

  /* First make sure no other SERVERD programs are running. If so, kill
     them all (after confirming) before proceeding. */
  
  backup (REPORT_START, REPORT_START_ACC);
  if ((report = fopen (REPORT_START, "a")) == NULL)
    fprintf (stderr, "start: Could not open %s\n", REPORT_START),
    start_abort();
  nlists = sys_config (report, &sys);
  if (just_kill)
    report_progress (report, "\n--- SHUTTING LISTSERV SYSTEM DOWN ---\n",FALSE);
  else
    report_progress (report, "\n--- STARTING LISTSERV SYSTEM ---\n", FALSE);
#ifndef _MINIX
  if (sys.options & BSD_PS)
    syscom ("ps -gx > /tmp/ps");  /* do not combine the two "syscom"'s */
  else
    syscom ("ps -ef | grep %s > /tmp/ps", getenv ("LOGNAME"));
  tty_echo = FALSE;
  syscom ("egrep '%s$|%s|%s$|%s |%s$|%s |%s|%s |queued' /tmp/ps > /tmp/found",
	  (addr1 = extract_filename (SERVERD)), addr1,
 	  (addr2 = extract_filename (LIST)), addr2,
	  (addr3 = extract_filename (SERVER)), addr3,
	  (addr4 = extract_filename (PQUEUE)), addr4);
  free ((char *) addr1);
  free ((char *) addr2);
  free ((char *) addr3);
  free ((char *) addr4);
  unlink ("/tmp/ps");
  tty_echo = TRUE;
  if ((f = fopen ("/tmp/found", "r")) == NULL)
    sprintf (msg, "Error opening /tmp/found. Aborting. %s",
	     ((just_kill == FALSE) ? "No discussion list started." : "")),
    report_progress (report, msg, TRUE),
    start_abort ();
  
  syscom ("wc -l /tmp/found > /tmp/nprocs");
  if ((p = fopen ("/tmp/nprocs", "r")) != NULL) {
    fscanf (p, "%d", &procs);
    if (do_report)
      sprintf (msg, "OLD LISTSERV PROCESSES RUNNING:\t%d\n", procs),
      report_progress (report, msg, FALSE);
    fclose (p);
    unlink ("/tmp/nprocs");
  }
  else
    sprintf (msg, "Error opening /tmp/nprocs. Aborting. %s",
	     ((just_kill == FALSE) ? "No discussion list started." : "")),
    report_progress (report, msg, TRUE),
    start_abort ();
  
  while (!feof (f)) {  /* get pid's and kill processes after confirming */
    RESET (line);
    fgets (line, MAX_LINE - 2, f);
    if (line[0] != EOS) {
      if (sys.options & BSD_PS)
        sscanf (line, "%d ", &pid);
      else
        sscanf (line, "%s %d ", command, &pid);
      if (confirm) {
	c = EOS;
        while (c != EOF && c != 'Y' && c != 'N') {
	  sprintf (msg, "\n%s\n%c[7m%s%c[mKill it to proceed ? (Y/N) ",
		   ((just_kill == FALSE) ? 
		    "ERROR: another listserv-system program running:" : 
		    "Listserv-system program found:"),
		   27, line, 27);
	  report_progress (report, msg, FALSE);
	  GET_RESPONSE;
        }
        if (c == 'N' || c == EOF)
	  sprintf (msg, "start aborted. %s\n",
		   ((just_kill == FALSE) ? "System not started.":"")),
	  report_progress (report, msg, TRUE),
	  exit (1);
      }
      kill (pid, SIGINT);
      ++procs_killed;
    }
  }
  fclose (f);
  unlink ("/tmp/found");
  if ((f = fopen (PID_SERVERD, "r")) != NULL)
    fscanf (f, "%d", &pid),
    kill (pid, SIGINT),
    ++procs_killed,
    fclose (f),
    unlink (PID_SERVERD);
  if ((f = fopen (PID_LIST, "r")) != NULL)
    fscanf (f, "%d", &pid),
    kill (pid, SIGINT),
    ++procs_killed,
    fclose (f),
    unlink (PID_LIST);
  if ((f = fopen (PID_SERVER, "r")) != NULL)
    fscanf (f, "%d", &pid),
    kill (pid, SIGINT),
    ++procs_killed,
    fclose (f),
    unlink (PID_SERVER);
  if ((f = fopen (PID_PQUEUE, "r")) != NULL)
    fscanf (f, "%d", &pid),
    kill (pid, SIGINT),
    ++procs_killed,
    fclose (f),
    unlink (PID_PQUEUE);
  if (do_report)
    sprintf (msg, "OLD LISTSERV PROCESSES KILLED:\t%d\n", procs_killed),
    report_progress (report, msg, FALSE);
  
  if (just_kill)  /* Done */
    report_progress (report, "", -TRUE),
    fclose (report),
    exit (0);
#endif
  
  syscom ("echo Serverd lock file > %s", SERVERD_LOCK_FILE);
  syscom ("echo List lock file > %s", LIST_LOCK_FILE);
  syscom ("echo Server lock file > %s", SERVER_LOCK_FILE);
  syscom ("echo Pqueue lock file > %s", PQUEUE_LOCK_FILE);

  backup (REPORT_SERVER, REPORT_SERVER_ACC);
  backup (REPORT_SERVERD, REPORT_SERVERD_ACC);
  backup (REPORT_PQUEUE, REPORT_PQUEUE_ACC);
  sprintf (server_ignoredf, "%s/%s", PATH", IGNORED);
  check_for (server_ignoredf, report, do_report, confirm);
  for (i = 0; i < nlists; ++i) {
    start_config (sys.lists[i].alias);
    sprintf (dir, "%s/lists/%s", PATH", sys.lists[i].alias);
    if (stat (dir, &stat_buf)) {
      if (mkdir (dir, 475))
	sprintf (msg, "Could not create directory %s", dir),
	report_progress (report, msg, TRUE),
	start_abort ();
      syscom ("chmod 733 %s", dir);
      if (do_report)
        sprintf (msg, "*** New list %s ***\n", sys.lists[i].alias),
        report_progress (report, msg, FALSE);
      syscom ("cp %s %s", server_ignoredf, dir);
      syscom ("echo %s >> %s/%s", sys.lists[i].alias, dir, IGNORED);
      syscom ("echo %s >> %s/%s", sys.lists[i].address, dir, IGNORED);
      syscom ("echo %s | sed 's/listserv/server/' >> %s/%s", sys.server.address,
	      dir, IGNORED);
      syscom ("touch %s", infof);
      syscom ("touch %s", welcomef);
      syscom ("touch %s/%s", dir, LIST_MAIL_FILE);
      syscom ("chmod 666 %s/%s", dir, LIST_MAIL_FILE);
      syscom ("touch %s/%s", dir, MODERATED_MAIL_FILE);
      syscom ("chmod 666 %s/%s", dir, MODERATED_MAIL_FILE);
    }
    check_for (subscribersf, report, do_report, confirm);
    check_for (aliasesf, report, do_report, confirm);
    check_for (newsf, report, do_report, confirm);
    check_for (peersf, report, do_report, confirm);
    check_for (restrictedf, report, do_report, confirm);
    backup (report_listf, report_list_accf);
  }
  syscom ("%s %s &", SERVERD, sys.serverd_cmdoptions);
  report_progress (report, "", -TRUE);
  fclose (report);
  exit (0);
}

/*
  Make sure that file 's' exists. Create a new one if necessary.
*/

void check_for (char *s, FILE *report, BOOLEAN do_report, BOOLEAN confirm)
{
  char c = EOS, msg [MAX_LINE];
  struct stat stat_buf;

  if (stat (s, &stat_buf)) { /* make sure we have file 's' */
    if (confirm) {
      while (c != EOF && c != 'Y' && c != 'N') {
 	if (do_report)
          sprintf (msg, "No %s file found. Create a new one? (Y/N) ", s),
	  report_progress (report, msg, FALSE);
        GET_RESPONSE;
      }
      if (c == 'N' || c == EOF)
        start_abort ();
    }
    syscom ("touch %s", s);
  }
}

/*
  Append 'src' to 'dest' and create a brand new 'src'.
*/

void backup (char *src, char *dest)
{
  struct stat stat_buf;

  if (!stat (src, &stat_buf)) /* prepare for backup */
    syscom ("cat %s >> %s", src, dest),
    unlink (src),
    syscom ("touch %s", src);
}

/*
  Print usage.
*/

void usage ()
{
  fprintf (stderr, "Usage: start [-k] [-c] [-r]\n\
-k: Just kill any listserv-system programs running.\n\
-c: Do not confirm before killing processes.\n\
-r: Restrict reporting to screen.\n");
  exit (1);
}

/*
  Abort after printing a message.
*/

void start_abort ()
{
  fprintf (stderr, "### start aborted; discussion list not started. ###\n");
  exit (1);
}

void start_config (char *alias)
{
  setup_string (subscribersf, alias, SUBSCRIBERS);
  setup_string (aliasesf, alias, ALIASES);
  setup_string (newsf, alias, NEWSF);
  setup_string (peersf, alias, PEERS);
  setup_string (restrictedf, alias, RESTRICTED);
  setup_string (ignoredf, alias, IGNORED);
  setup_string (report_listf, alias, REPORT_LIST);
  setup_string (infof, alias, INFO_FILE);
  setup_string (welcomef, alias, WELCOME_FILE);
  setup_string (report_list_accf, alias, REPORT_LIST_ACC);
}
