/*
  ----------------------------------------------------------------------------
  |                       SYSTEM MAILING ROUTINES                            |
  |									     |
  |                             Version 1.0                                  |
  |                                                                          |
  |                (or, when Computer Science gets to you)                   |
  |                                                                          |
  |                    Written by Anastasios Kotsikonas                      |
  |                           (tasos@cs.bu.edu)                              |
  |                                                                          |
  | AGREEMENT: This software can be used and distributed freely as long      |
  | as you do not remove or alter the Copyright notice in the file defs.h;   |
  | this notice is #define'd in the symbol VERSION. Although you may alter   |
  | the code provided, you may not alter the functions create_header()       |
  | and create_multi_recipient_header() in list.c and listserv.c.            |
  | By using this software you are bound by this agreement.                  |
  | This software comes with no warranties and cannot be sold for profit.    |
  | The AGREEMENT and COPYRIGHT notices should be included in all source     |
  | files when distributing this software.                                   |
  | COPYRIGHT: Copyright (c) 1991, Anastasios C. Kotsikonas                  |
  ----------------------------------------------------------------------------

  These routines implement the 'system' mailmethod. The system opens a socket
  and connects directly with sendmail for mail delivery. During the process
  of porting the code to various platforms, lots of grosse things were
  encountered with sockets and protocols, so the code may seem kludgy.

  When mail cannot be sent due to network problems, it is queued up and will 
  be delivered later by the queue daemon.
*/

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "defs.h"
#include "struct.h"
#include "sysmail.h"

#ifdef __STDC__
#include <stdarg.h>
extern int  syscom (char *, ...);
#else
#include <varargs.h>
extern int  syscom ();
#endif
extern FILE *report;
extern SYS sys;
extern BOOLEAN debug;

extern void report_progress (FILE *, char *, int);

BOOLEAN sysmail (char *);
BOOLEAN _sysmail (char *, int);
int     server_response (int, FILE *);
int     build_tcp_connection (FILE *);
void    queue_up (char *file);

/*
  The return value depends on the return value of _sysmail ().
*/

BOOLEAN sysmail (char *file)
{
  char error [MAX_LINE];

  queue = FALSE;
  if (debug) {
    if ((sent = fopen (SENT, "w")) == NULL)
      sprintf (error, "\nsysmail(): Could not open %s", SENT),
      report_progress (report, error, TRUE),
      exit (1);
    if ((received = fopen (RECEIVED, "w")) == NULL)
      sprintf (error, "\nsysmail(): Could not open %s", RECEIVED),
      report_progress (report, error, TRUE),
      exit (1);
  }
  return _sysmail (file, 1);
}

/*
  'system' mailmethod. It returns TRUE if the mail was successfully
  delivered, FALSE if it was queued.
*/

BOOLEAN _sysmail (char *file, int call)
{
  char buf [MAX_LINE] ;
  char error [MAX_LINE];
  FILE *msg;
  int sock_fd, cmd, timeout;
   
  if ((msg = fopen (file, "r")) == NULL)
    sprintf (error, "\n_sysmail(): Could not open %s", file),
    report_progress (report, error, TRUE),
    exit (1);
  sock_fd = build_tcp_connection (report);
  if ((cmd = server_response (sock_fd, report)) != ACKNOWLEDGE) {
    report_progress (report, "\n_sysmail(): Could not connect to server", TRUE);
    queue = TRUE;
    goto abort;
  }

  PROTOCOL (DATA);
  while (!feof (msg) && strcmp (buf, END_OF_TEXT)) { /* Copy header and text */
    RESET (buf);
    fgets (buf, MAX_LINE - 2, msg);
    write (sock_fd, buf, strlen (buf));
    if (debug)
      fprintf (sent, "%s", buf),
      fflush (sent);
  }
  cmd = server_response (sock_fd, report);
  PROTOCOL (CLOSE_CONNECTION);
  abort:
  if (queue)
    queue_up (file);
  CLOSEF;
  if (debug)
    fclose (sent),
    fclose (received);
  if (queue)
    return FALSE;
  else
    return TRUE;
}

/*
  Get server response. Return the command number that the server sent.
*/

int server_response (int sock_fd, FILE *report)
{
  char buf [MAX_LINE];
  int cmd, i;

  if (read (sock_fd, buf, 3) < 0) /* Get server command */
    report_progress (report, "\nserver_response(): Server dropped connection",
		     TRUE),
    exit (11);
  RESET (message);
  buf[3] = EOS;
  cmd = atoi (buf);
  sprintf (message, "%s", buf);
  i = strlen (message);
  if (debug)
    fprintf (received, "%s", buf),
    fflush (received);
  while (buf[0] != '\n') { /* Read till the end of socket */
    if (read (sock_fd, buf, 1) < 1) {
      if (debug)
        fprintf (received, "%s", buf),
 	fflush (received);
      message [i] = EOS;
      break;
    }
    message [i++] = (buf[0] != '\n' ? buf[0] : EOS);
    if (debug)
      fprintf (received, "%c", buf[0]),
      fflush (received);
  }
  return cmd;
}

/*
  Establish connection with sendmail/smtp.
*/

int build_tcp_connection (FILE *report)
{
  int sock_fd;
  struct sockaddr_in sin;
  struct hostent *hostentry;
   
  if ((sock_fd = socket (AF_INET, SOCK_STREAM, 0)) < 0)
    report_progress (report, "\nbuild_tcp_connection(): Could not create \
socket", TRUE),
    exit(12);
  if (! (hostentry = gethostbyname ("localhost")))
    report_progress (report, "\nbuild_tcp_connection(): No such host", TRUE),
    exit(13);
  sin.sin_family = AF_INET;
  sin.sin_port = htons (PORT);
  memcpy ((char *) &sin.sin_addr.s_addr, (char *) hostentry->h_addr,
	  hostentry->h_length);
  memset (sin.sin_zero, EOS, sizeof (sin.sin_zero));
  if (connect (sock_fd, (struct sockaddr *) &sin, sizeof (struct sockaddr_in))
      < 0)
    report_progress (report, "\nbuild_tcp_connection(): Could not connect to \
port", TRUE),
    exit (14);
  return sock_fd;
}

/*
  Queue up a file for later delivery.
*/

void queue_up (char *file)
{
  FILE *id;
  int id_no = 0;
  char msg [MAX_LINE];

  if ((id = fopen (IDF, "r")) != NULL)
    fscanf (id, "%d\n", &id_no),
    fclose (id);
  syscom ("mv %s %s/%d", file, QUEUE_DIR, ++id_no);
  syscom ("echo %d > %s", id_no, IDF);
  sprintf (msg, "File %s placed in the mail queue", file);
  report_progress (report, msg, TRUE);
}
