/*
  ----------------------------------------------------------------------------
  |                	    FILE ARCHIVING UTILITY			     |
  |                                                                          |
  |                              Version 1.0                                 |
  |                                                                          |
  |                (or, when Computer Science gets to you)                   |
  |                                                                          |
  |                    Written by Anastasios Kotsikonas                      |
  |                           (tasos@cs.bu.edu)                              |
  |                                                                          |
  | AGREEMENT: This software can be used and distributed freely as long      |
  | as you do not remove or alter the Copyright notice in the file defs.h;   |
  | this notice is #define'd in the symbol VERSION. Although you may alter   |
  | the code provided, you may not alter the functions create_header()       |
  | and create_multi_recipient_header() in list.c and listserv.c.            |
  | By using this software you are bound by this agreement.                  |
  | This software comes with no warranties and cannot be sold for profit.    |
  | The AGREEMENT and COPYRIGHT notices should be included in all source     |
  | files when distributing this software.                                   |
  | COPYRIGHT: Copyright (c) 1991, Anastasios C. Kotsikonas                  |
  ----------------------------------------------------------------------------

  farch archives files into the specified directories, possibly splitting
  them into smaller parts. It then updates the DIR file of the appropriate
  archive. Split files have numbers appended to their original names;
  non-split files have their names intact. Binary files are uuencoded before
  processed, and all output files are compressed.

  COMMAND LINE OPTIONS:
    -n: Do not split input files.
    -t: Tar all input files.
    -b: Input files are binary; uuencode.
    -s: Set the maximum size of each of the split subparts in kilobytes.
    -a: Specify the archive where the input files will be archived.
    -d: Specify the actual directory that the archived files will reside.

  WARNING: The program can also archive directory files, if these can be
  of any use.

  Algorithm:
  {
    Process command line arguments; allocate buffer_size
    Open master archive; get path to specified archive
    Verify existsence of target directory -- create it if necessary
    Tar files, if so requested
    for (each input file) {
      open
      get filesize
      if (-b)
	uuencode file
      if (-n or filesize <= buffer_size) { -- Do not split --
	if (-b)
	  copy uuencoded file into target directory
	else if (file does not exist in target directory)
	  copy it to target directory
	  compress it
	update (archive's directory)
      }
      else split file {
	while (not eof) {
	  get unique output filename
	  fwrite (leftover bytes from previous chunk)
	  fread (new chunk)
	  if (! -b) {
	    locate nearest newline from the end of the buffer
	    copy those skipped bytes to leftover
	  }
	  fwrite (new modified chunk)
	  compress it
	}
	fwrite (any leftovers)
	compress part
	update (archive's directory)
      }
    }
  }
*/

#include <stdio.h>
#include <malloc.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "defs.h"
#include "struct.h"
#include "listserv.h"

#define DEFAULT_SIZE    64 * 1024
#define UUE_FILE	"/tmp/uue"

extern char *extract_filename (char *);
extern char *locase (char *);
void   main (int , char **);
void   uuencode (FILE **, char *, char *, struct stat *, BOOLEAN);
void   update (char *, char *, int, char *);
void   usage (void);
void   do_archive (int, int, char **, char *, char *, char *, char *, long int,
                   BOOLEAN, BOOLEAN, BOOLEAN);
int    get_archive (char **, char *);
int    get_dir (char *, char **, char *);
int    tar_files (int, int, char **, char *);

SYS sys; /* Bogus */
COMMANDS commands [MAX_COMMANDS]; /* Bogus */

void main (int argc, char **argv)
{
  long int size = DEFAULT_SIZE;
  char *buf, *arch = NULL, *newdir = NULL, *dir, fullpath[256],
       *tarf, *options = "nbs:a:d:t:u";
  int c;
  BOOLEAN bin = FALSE, tar = FALSE, split = TRUE;
  extern char *optarg;
  extern int optopt, optind;

  buf = (char *) malloc (size * sizeof (char));
  dir = (char *) malloc (sizeof (char));
  while ((c = getopt (argc, argv, options)) != EOF)
    switch ((char) c) {
    case 'n': split = 0; break;
    case 't': tar = TRUE; tarf = optarg;
    case 'b': bin = TRUE; break;
    case 's': size = (long) atol (optarg) * 1024;
      	      if (size <= 0)
                fprintf (stderr, "How am I supposed to allocate %ld bytes?\n",
                         size),
                exit (2);
              free ((char *) buf);
              if ((buf = (char *) malloc (size * sizeof (char))) == NULL)
                fprintf (stderr, "Size too big; not enough memory.\n"),
                exit (1);
              break;
    case 'a': arch = locase (optarg); break;
    case 'd': newdir = optarg;
              if (*newdir != '/')
                fprintf (stderr, "Must specify full path for the directory.\n"),
                exit (1);
              break;
    case 'u': usage ();
    case ':': fprintf (stderr, "Option '%c' requires an argument.\n", optopt);
              exit (2);
    case '?':
    default:
      fprintf (stderr, "Unrecognized option '%c'.\n", optopt);
      usage ();
    }

  if (optind == argc)
    goto abort;
  if (get_archive (&arch, fullpath) && get_dir (newdir, &dir, fullpath)) {
    if (tar)
      if (tar_files (optind, argc, argv, tarf))
        argc = optind + 1;
      else 
	goto abort;
    do_archive (optind, argc, argv, buf, fullpath, arch, dir, size, bin,
		split, tar);
    if (tar)
      unlink (tarf);
  }
  abort:
  free ((char *) dir);
  free ((char *) buf);
}

/*
  uuencode a file.
*/

void uuencode (FILE **fin, char *file, char *infile, struct stat *finbuf,
	       BOOLEAN tar)
{
  fclose (*fin);
  printf ("\t- uuencoding...\n");
  syscom ("uuencode %s %s%s > %s", file, infile, (tar ? ".tar" : ""),
	  UUE_FILE);
  *fin = fopen (UUE_FILE, "r");
  stat (UUE_FILE, finbuf);
}

/*
  tar all input files into 'tarf'.
*/

int tar_files (int optind, int argc, char **argv, char *tarf)
{
  FILE *fin, *fout;
  char files[10000];
  int original = optind;

  if ((fout = fopen (tarf, "w")) == NULL) {
    fprintf (stderr, "Cannot write to tar file %s\n", tarf);
    return 0;
  }
  unlink (tarf);
  printf ("tarring...\n");
  RESET (files);
  while (optind < argc) {
    if ((fin = fopen (argv[optind], "r")) == NULL) {
      fprintf (stderr, "Unable to open %s for reading.\n", argv[optind]);
      return 0;
    }
    fclose (fin);
    sprintf (files + strlen (files), "%s ", argv[optind++]);
  }
  syscom ("tar cf %s %s", tarf, files);
  argv[original] = tarf;
  return 1;
}

/*
  Update the archive's directory.
*/

void update (char *path, char *file, int count, char *dir)
{
  char dirf[256];
  FILE *fout;

  dirf[0] = EOS;
  sprintf (dirf, "%s/%s", path, DIR);
  if ((fout = fopen (dirf, "a")) == NULL) {
    fprintf (stderr, "Unable to open index %s for update.\nFile %s \
not archived. Remove output file(s) from %s\n", dirf, file, dir);
    exit (1);
  }
  fprintf (fout, "%s %d %s\n", file, count, dir);
  fclose (fout);
}

void usage ()
{
  fprintf (stderr, "farch [-n] [-b] [-s size] [-a archive] [-d dir] \
[-t file] filename(s)\n");
  fprintf (stderr, "-n: do not split input file(s)\n\
-b: input files are binary: uuencode (on if -t specified)\n\
-s: maximum size of each output file (in kilobytes) -- default %ld\n\
-a: which archive index to update (subdir of %s)\n    -- \
default %s\n\
-d: actual directory to put output file(s)\n    -- default %s/%s\n\
-t: tar all input files into 'file' and archive that\n",
(long) DEFAULT_SIZE / 1024, ARCHIVE_DIR, DEFAULT_ARCHIVE, ARCHIVE_DIR,
DEFAULT_ARCHIVE);
  exit (2);
}

/*
  Archive all files given in 'argv'.
*/

void do_archive (int optind, int argc, char **argv, char *buf, char *fullpath,
	         char *archive, char *dir, long int size, BOOLEAN bin,
		 BOOLEAN split, BOOLEAN tar)
{
  FILE *fin, *fout, *flast;
  long int count, nread, nchars, total;
  char *leftovers = NULL, *s, *infile = NULL, filename[256], compressed[256];
  struct stat sbuf, finbuf;

  while (optind < argc) { /* Split and archive each file */

    s = argv[optind] + strlen (argv[optind]) - 1;
    while (s != argv[optind] && *s == '/')  /* Remove trailing / */
      *(s--) = EOS;

    if ((fin = fopen (argv[optind], "r")) == NULL) { /* Open file */
      fprintf (stderr, "Cannot open file %s for reading.\n", argv[optind]);
      goto abort;
    }

    printf ("%s:\n", argv[optind]);
    count = 1;
    nchars = 0;
    stat (argv[optind], &finbuf); /* Get size of input file */

    if (infile) /* free previous allocation */
      free ((char *) infile);
    infile = extract_filename (argv[optind]); /* get filename from path */
    locase (infile);

    if (bin) /* uuencode */
      uuencode (&fin, argv[optind], infile, &finbuf, tar);

    if (!split || finbuf.st_size <= size) { /* Not splitting;may have to copy */
      fclose (fin);
      sprintf (filename, "%s%s%s", (strcmp (dir, "/") ? dir : ""),
               ((strcmp (dir, infile) && strcmp (infile, "/")) ? "/" : ""),
               infile);

      if (bin) { /* Copy UUE_FILE to target directory */
        if ((fout = fopen (filename, "w")) == NULL) { /* Test */
          fprintf (stderr, "Cannot write to directory %s; cannot \
proceed with %s\n",
                   dir, argv[optind]);
          goto abort;
        }
        fclose (fout);
        syscom ("mv %s %s > /dev/null 2>&1", UUE_FILE, filename);
      }
      else if (stat (filename, &sbuf)) { /* File does not exist in target dir */
        if ((fout = fopen (filename, "w")) == NULL) {
          fprintf (stderr, "Cannot write to directory %s; cannot \
proceed with %s\n",
                   dir, argv[optind]);
          goto abort;
        }
        fclose (fout);
        syscom ("cp %s %s > /dev/null 2>&1", argv[optind], filename);
      }

      sprintf (compressed, "%s.Z", filename);
      if (!stat (compressed, &sbuf)) {
	fprintf (stderr, "Output file %s exists; cannot proceed with %s\n",
		 compressed, argv[optind]);
	goto abort;
      }

      syscom ("compress %s > /dev/null 2>&1", filename);
      update (fullpath, infile, 1, dir);
      printf ("\t- file not split\n\t- archived in %s\n\t- directory: %s\n",
              archive, dir);
    }
    else { /* Split file */
      while (!feof (fin)) {
        sprintf (filename, "%s%s%s%d", (strcmp (dir, "/") ? dir : ""),
                 ((strcmp (dir, infile) && strcmp (infile, "/")) ? "/" : ""),
                 infile, count);

        if (!stat (filename, &sbuf)) {
          fprintf (stderr, "Output file %s exists; cannot proceed with %s\n",
                   filename, argv[optind]);
          fout = (FILE *) -1;
          break;
        }
        if ((fout = fopen (filename, "w")) == NULL) {
          fprintf (stderr, "Cannot write to directory %s; cannot proceed \
with %s\n",
                   dir, argv[optind]);
          fout = (FILE *) -1;
          break;
        }

        total = 0;  /* Do the actual splitting */
        total += fwrite (leftovers, sizeof (char), nchars, fout);
        nread = fread (buf, sizeof (char), size - nchars, fin);
        if (nchars)
          free ((char *) leftovers);
        s = buf + nread - (nread > 0 ? 1 : 0);
        nchars = 0;
        while (s != buf && *s != '\n') /* Look for first \n from the end */
          ++nchars,
          --s;
        if (s == buf) /* No new line found; write as is */
          nchars = 0;
        nread -= nchars;
        leftovers = (char *) malloc (nchars * sizeof (char));
        strncpy (leftovers, ++s, nchars); /* Copy anything after \n */
        total += fwrite (buf, sizeof (char), nread, fout);
        fclose (fout);

        if (total == 0)
          unlink (filename);
        else { /* OK, compress */
          sprintf (compressed, "%s.Z", filename);
          if (!stat (compressed, &sbuf)) {
            fprintf (stderr, "Output file %s exists; cannot proceed with %s\n",
                     compressed, argv[optind]);
	    unlink (filename);
            goto abort;
          }
          syscom ("compress %s > /dev/null 2>&1", filename),
          ++count;
	}
      }

      fclose (fin);
      if (bin)
        unlink (UUE_FILE);
      if (nchars) /* write any leftovers */
        flast = fopen (filename, "a"),
        fwrite (leftovers, sizeof (char), nchars, flast),
        fclose (flast),
        free ((char *) leftovers);

      if (fout != (FILE *) -1) { /* Splitting successful, update DIR file */
        update (fullpath, infile, count - 1, dir);
        printf ("\t- file split in %ld parts\n\t- archived in %s\n\t\
- directory: %s\n",
                (long) count - 1, archive, dir);
      }
    }
    abort:
    ++optind;
  }
}

/*
  Get archive to update.
*/

int get_archive (char **arch, char *fullpath)
{
  FILE *master;
  char indexf[256], archiv[256], line[256];
  BOOLEAN found = FALSE;

  if (!*arch)
    *arch = DEFAULT_ARCHIVE;
  sprintf (indexf, "%s/%s/%s", ARCHIVE_DIR, DEFAULT_ARCHIVE, INDEX);
  if ((master = fopen (indexf, "r")) == NULL) {
    fprintf (stderr, "Sorry, no master index found.\n");
    return 0;
  }
  while (!feof (master)) { /* Look at the master index for fullpath */
    fullpath[0] = archiv[0] = RESET (line);
    fgets (line, MAX_LINE - 2, master);
    if (line[0] != EOS) {
      sscanf (line, "%s %s\n", archiv, fullpath);
      locase (archiv);
      if (!strcmp (*arch, archiv)) {
        found = TRUE;
        break;
      }
    }
  }
  fclose (master);
  if (!found) {
    fprintf (stderr, "Archive %s not found.\n", *arch);
    return 0;
  }
  return 1;
}

/*
  Get output directory.
*/

int get_dir (char *newdir, char **dir, char *fullpath)
{
  char *s;
  struct stat sbuf;

  free ((char *) *dir);
  if (!newdir)
    *dir = (char *) malloc ((strlen (fullpath) + 1) * sizeof (char)),
    sprintf (*dir, "%s", fullpath);
  else {
    *dir = (char *) malloc ((strlen (newdir) + 1) * sizeof (char));
    sprintf (*dir, "%s", newdir);
    s = *dir + strlen (*dir) - 1;
    while (s != *dir && *s == '/')
      *(s--) = EOS;
  }
  if (stat (*dir, &sbuf)) {
    if (mkdir (*dir, 448)) {
      fprintf (stderr, "Unable to create new directory %s\n", *dir);
      return 0;
    }
    printf ("Creating new directory %s\n", *dir);
  }
  return 1;
}
