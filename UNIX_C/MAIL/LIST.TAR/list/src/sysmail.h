/*
  AGREEMENT: This software can be used and distributed freely as long
  as you do not remove or alter the Copyright notice in the file defs.h;
  this notice is #define'd in the symbol VERSION. Although you may alter
  the code provided, you may not alter the functions create_header()
  and create_multi_recipient_header() in list.c and listserv.c.
  By using this software you are bound by this agreement.
  This software comes with no warranties and cannot be sold for profit.
  The AGREEMENT and COPYRIGHT notices should be included in all source
  files when distributing this software.
  COPYRIGHT: Copyright (c) 1991, Anastasios C. Kotsikonas
*/

#define PORT		  25
#define TIMEOUT		  10
#define MAX_CALLS	  1
#define SENT		  PATH/sent"
#define RECEIVED	  PATH/received"
#define IDF		  PATH/.queue.id"
#define QUEUE_DIR	  PATH/mqueue"

/* List of SMTP commands recognized */

#define ACKNOWLEDGE	  220
#define CLOSE_CONNECTION  221
#define OK                250
#define WILL_FORWARD      251
#define DATA		  354
#define SERVICE_UNAVAIL	  421
#define PERMISSION_DENIED 450
#define HOST_ABORTED	  451
#define DISK_FULL	  452
#define NOT_RECOGNIZED    500
#define SYNTAX_ERROR      501
#define BAD_SEQUENCE	  503
#define USER_UNKNOWN      550
#define USER_NOT_LOCAL    551
#define TOO_MUCH_DATA	  552
#define USER_AMBIGUOUS    553
#define TRANS_FAILED  	  554
#define END_OF_TEXT	  ".\n"

#define CLOSEF \
  fclose (msg),\
  close (sock_fd)

#define NOTIFY_MANAGER \
  if (sys.options & BSD_MAIL)\
    syscom ("%s -s \"Error during message delivery: check the report \
files\" %s &", UCB_MAIL, sys.manager);\

#define WARN_MANAGER \
  if (sys.options & BSD_MAIL)\
    syscom ("%s -s \"Warning during message delivery: check the report \
files\" %s &", UCB_MAIL, sys.manager);\

#define ABORT_CONNECTION \
  if (write (sock_fd, "QUIT\n", 5) < 5)\
    report_progress (report, "_sysmail(): WARNING: Error writing to \
socket, while closing connection", TRUE);\
  if (debug)\
    fprintf (sent, "QUIT\n"),\
    fflush (sent);\
  cmd = server_response (sock_fd, report);

#define PROTOCOL(arg) \
  while (!feof (msg) && cmd != arg) {\
    RESET (buf);\
    fgets (buf, MAX_LINE - 2, msg);\
    if (write (sock_fd, buf, strlen (buf)) < strlen (buf))\
      report_progress (report, "_sysmail(): WARNING: Error writing to \
socket, trying again", TRUE);\
    if (debug)\
      fprintf (sent, "%s", buf),\
      fflush (sent);\
    cmd = server_response (sock_fd, report);\
    timeout = 0;\
    while (cmd != OK && cmd != arg && timeout < TIMEOUT) {\
      ++timeout;\
      if (write (sock_fd, buf, strlen (buf)) < strlen (buf))\
	report_progress (report, "_sysmail(): WARNING: Error rewriting to \
socket", TRUE);\
      if (debug)\
        fprintf (sent, "%s", buf),\
        fflush (sent);\
      cmd = server_response (sock_fd, report);\
    }\
    if (timeout == TIMEOUT) {\
      char error [1024];\
      if (cmd == SYNTAX_ERROR || cmd == TRANS_FAILED ||\
          cmd == NOT_RECOGNIZED) {\
        sprintf (error, "_sysmail(): Command: %snot recognized by sendmail.\
\n%s\nCould not deliver mail", buf, message);\
        report_progress (report, error, TRUE);\
        NOTIFY_MANAGER;\
	ABORT_CONNECTION;\
        CLOSEF;\
        exit (15);\
      }\
      else if (cmd == BAD_SEQUENCE) {\
        sprintf (error, "_sysmail(): Command: %sissued too soon.\
\n%s\nCould not deliver mail", buf, message);\
        report_progress (report, error, TRUE);\
        NOTIFY_MANAGER;\
	ABORT_CONNECTION;\
        CLOSEF;\
        exit (15);\
      }\
      else if (cmd == SERVICE_UNAVAIL || cmd == HOST_ABORTED) {\
        sprintf (error, "_sysmail(): Service unavailable.\
\n%s\nCould not deliver mail", message);\
        report_progress (report, error, TRUE);\
        NOTIFY_MANAGER;\
	ABORT_CONNECTION;\
	queue = TRUE;\
	goto abort;\
      }\
      else if (cmd == DISK_FULL) {\
	sprintf (error, "_sysmail(): File system full.\n%s\nCould not \
deliver mail", message);\
        report_progress (report, error, TRUE);\
        NOTIFY_MANAGER;\
	ABORT_CONNECTION;\
        queue = TRUE;\
        goto abort;\
      }\
      else if (cmd == TOO_MUCH_DATA) {\
        sprintf (error, "_sysmail(): Too many recipients or message \
too long.\n%s\nCould not deliver mail", message);\
        report_progress (report, error, TRUE);\
        NOTIFY_MANAGER;\
	ABORT_CONNECTION;\
        CLOSEF;\
        exit (15);\
      }\
      else if (cmd == USER_UNKNOWN) {\
	sprintf (error, "_sysmail(): Address: %snot recognized.\n%s\nMessage \
not delivered to this recipient", buf, message);\
        report_progress (report, error, TRUE);\
	WARN_MANAGER;\
        continue;\
      }\
      else if (cmd == USER_NOT_LOCAL) {\
        sprintf (error, "_sysmail(): Address: %snot local; %s", buf, message);\
        report_progress (report, error, TRUE);\
        WARN_MANAGER;\
        continue;\
      }\
      else if (cmd == USER_AMBIGUOUS) {\
        sprintf (error, "_sysmail(): Address ambiguous: %s%s\nMessage not \
delivered to this address", buf, message);\
        report_progress (report, error, TRUE);\
        WARN_MANAGER;\
        continue;\
      }\
      else if (cmd == PERMISSION_DENIED) {\
        sprintf (error, "_sysmail(): Permission denied for address %s%s\n\
Message not delivered to this recipient", buf, message);\
        report_progress (report, error, TRUE);\
        WARN_MANAGER;\
        continue;\
      }\
      else if (cmd == WILL_FORWARD) {\
	sprintf (error, "_sysmail(): Address: %snot local; %s", buf, message);\
        report_progress (report, error, TRUE);\
        WARN_MANAGER;\
        continue;\
      }\
      sprintf (error, "_sysmail(): ERROR: Return value %d for command: %s%s\n\
Please notify tasos@cs.bu.edu", cmd, buf, message);\
      report_progress (report, error, TRUE);\
      NOTIFY_MANAGER;\
      if (call < MAX_CALLS)\
	CLOSEF,\
        sleep (60),\
	_sysmail (file, call + 1);\
      report_progress (report, "_sysmail(): ERROR: Could not deliver mail", \
TRUE);\
      CLOSEF,\
      exit (15);\
    }\
  }

static char message [1024];
static FILE *sent, *received;
static BOOLEAN queue;
