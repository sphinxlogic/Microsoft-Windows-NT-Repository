/*
  AGREEMENT: This software can be used and distributed freely as long
  as you do not remove or alter the Copyright notice in the file defs.h;
  this notice is #define'd in the symbol VERSION. Although you may alter
  the code provided, you may not alter the functions create_header()
  and create_multi_recipient_header() in list.c and listserv.c.
  By using this software you are bound by this agreement.
  This software comes with no warranties and cannot be sold for profit.
  The AGREEMENT and COPYRIGHT notices should be included in all source
  files when distributing this software.
  COPYRIGHT: Copyright (c) 1991, Anastasios C. Kotsikonas
*/

typedef struct {
  struct {
    char alias [MAX_LINE],	/* as it appears in the aliases file */
	 comment [MAX_LINE],	/* Comment: line in the outgoing mail message */
         address [MAX_LINE],	/* full email address of the list */
         cmdoptions [MAX_LINE];	/* list-specific command line options */
    int  disabled_commands;	/* mask of disabled commands for this list */
  } lists [MAX_LISTS];		/* structure for each list */
  struct {
    char address [MAX_LINE],	/* full email address of the server */
	 comment [MAX_LINE],	/* Comment: line in the outgoing mail message */
         cmdoptions [MAX_LINE],	/* listserv-specific command line options */
	 password [MAX_LINE];	/* for 'shutdown' and 'restart' */
  } server;			/* structure for the server */
  struct {
    char *method;		/* mail method to use */
    char env_var [MAX_LINE];	/* environment variable to use */
    char mail_prog [MAX_LINE];	/* which mail program to use */
  } mail;			/* mail method structure */
  struct {
    long int msg;		/* maximum message limit in bytes */
  } limits;
  char serverd_cmdoptions [MAX_LINE];/* command line options */
  char manager [MAX_LINE];	/* manager of the system */
  char arg [MAX_LINE];		/* temporary storage */
  char organization [MAX_LINE]; /* Organization's name */
  int users;			/* used by listserv when -r is given */
  int frequency;		/* how often to read mail */
  long int options;		/* various flags: BSD_PS, USE_TELNET, etc. */
} SYS;

typedef struct {
  char *name;
  int  mask;
  void (*func)();
} COMMANDS;
