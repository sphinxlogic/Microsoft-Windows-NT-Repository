/*
  ----------------------------------------------------------------------------
  |                      GENERAL PURPOSE FUNCTIONS                           |
  |                                                                          |
  |                              Version 2.0                                 |
  |                                                                          |
  |                (or, when Computer Science gets to you)                   |
  |                                                                          |
  |                    Written by Anastasios Kotsikonas                      |
  |                           (tasos@cs.bu.edu)                              |
  |                                                                          |
  | AGREEMENT: This software can be used and distributed freely as long      |
  | as you do not remove or alter the Copyright notice in the file defs.h;   |
  | this notice is #define'd in the symbol VERSION. Although you may alter   |
  | the code provided, you may not alter the functions create_header()       |
  | and create_multi_recipient_header() in list.c and listserv.c.            |
  | By using this software you are bound by this agreement.                  |
  | This software comes with no warranties and cannot be sold for profit.    |
  | The AGREEMENT and COPYRIGHT notices should be included in all source     |
  | files when distributing this software.                                   |
  | COPYRIGHT: Copyright (c) 1991, Anastasios C. Kotsikonas                  |
  ----------------------------------------------------------------------------
*/

#include <stdio.h>
#include <malloc.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <signal.h>
#include "defs.h"
#include "struct.h"

extern  COMMANDS commands[MAX_COMMANDS];

extern  int atoi (char *);
extern  BOOLEAN subscribed (FILE *, char *, char *, char *, char *, char *);
extern  void process_message (char *, char *, BOOLEAN);
#ifdef __STDC__
#include <stdarg.h>
int 	syscom (char *, ...);
#else
#include <varargs.h>
int     syscom ();
#endif
int	sys_config (FILE *, SYS *);
char    *locase (char *);
char    *upcase (char *);
void    report_progress (FILE *, char *, int);
void    distribute (FILE *mail, void (*)(), FILE *, char *, char *, char *,
		    char *);
BOOLEAN strinstr (char *, char *, char *);
char    *extract_filename (char *);
int     getopt (int, char **, char *);
char    *cleanup_name (char *);
void    cleanup_request (char *);
void	get_list_name (char *, char *);
int	get_list_id (char *, SYS *, int nlists);
void	setup_string (char *, char *, char *);
char	*_strstr (char *, char *);
void    shrink (char *);
BOOLEAN requested_part (char *, int);
int	my_system (char *);

/*
  Execute a system request.
*/

#ifdef __STDC__
int syscom (char *control, ...)
#else
int syscom (control, va_alist)
char *control;
va_dcl
#endif
{
  char command [10240];
  extern SYS sys;
  extern BOOLEAN tty_echo;
  va_list ap;
  int status;
  FILE *f;
  long int time_is = 0;
  struct tm *t;

#ifdef __STDC__
  va_start (ap, control);
#else
  va_start (ap);
#endif
  RESET (command);
  vsprintf (command, control, ap);
  va_end (ap);
  if ((sys.options & USE_MY_SYSTEM) == 0)
    status = system (command);
  else
    status = my_system (command);
  if (status) {
    if ((f = fopen (WARNING, "a")) != NULL)
      fprintf (f, "\nWARNING: System call exit status %d: %s\n",
	       status / 256, command),
      time (&time_is),
      t = localtime (&time_is),
      fprintf (f, "Time/Date: %2d:%.2d:%.2d, %2d/%.2d/%2d\n",
               t->tm_hour, t->tm_min, t->tm_sec, t->tm_mon + 1, t->tm_mday,
               t->tm_year),
      fclose (f);
    if (tty_echo)
      printf ("\nWARNING: System call exit status %d: %s\n", status / 256,
	      command);
  }
  return status;
}

/*
  Initialize the 'sys' structure from the CONFIG file. It returns the number
  of lists in the system.
*/

int sys_config (FILE *report, SYS *sys)
{
  FILE *config;
  char cmd [MAX_LINE];
  char args [MAX_LINE];
  char error [MAX_LINE];
  char mail_prog [MAX_LINE];
  char env_var [MAX_LINE];
  char *comment, *cmdarg;
  int nlists = 0, i, j, k, id;
  BOOLEAN notok;

  for (i = 0; i < MAX_LISTS; i++)
    sys->lists[i].disabled_commands = 0,
    RESET (sys->lists[i].alias),
    RESET (sys->lists[i].address),
    RESET (sys->lists[i].comment),
    RESET (sys->lists[i].cmdoptions);
  RESET (sys->server.address), RESET (sys->server.cmdoptions),
  RESET (sys->server.comment), RESET (sys->serverd_cmdoptions),
  RESET (sys->server.password), RESET (sys->arg), RESET (sys->manager),
  RESET (sys->organization), RESET (error);
  strcpy (sys->server.address, DEFAULT_SERVER_ADDRESS);
  strcpy (sys->server.cmdoptions, DEFAULT_SERVER_CMDOPTIONS);
  strcpy (sys->server.comment, DEFAULT_SERVER_COMMENT);
  strcpy (sys->manager, DEFAULT_MANAGER);
  sys->mail.method = BINMAIL;
  sys->options = 0;
  sys->users = 100;
  sys->frequency = 0;
  if ((config = fopen (CONFIG, "r")) == NULL)
    sprintf (error, "\nsys_config(): Could not open %s", CONFIG),
    report_progress (report, error, TRUE),
    exit (1);
  chmod (CONFIG, 384);
  while (! feof (config)) {
    args [0] = RESET (cmd);
    fscanf (config, "%s", cmd);
    if (cmd[0] == EOS)
      continue;
    fgets (args, MAX_LINE - 2, config);
    args [strlen (args) - 1] = EOS;
    if (cmd[0] == '#')
      continue;
    if (!strcmp (locase (cmd), "list")) {
      if (nlists >= MAX_LISTS) {
	sprintf (error, "\nsys_config(): List %s ignored: too many lists\n",
		 args);
	report_progress (report, error, FALSE);
	continue;
      }
      comment = strchr (args, '#');
      if (comment)
	*comment = EOS;
      sscanf (args, "%s%s", sys->lists [nlists].alias,
	      sys->lists [nlists].address);
      if (get_list_id (sys->lists [nlists].alias, sys, nlists) >= 0 &&
	  nlists > 0)
	sprintf (error, "\nsys_config(): Duplicate list %s in %s",
		 sys->lists [nlists].alias, CONFIG),
	report_progress (report, error, TRUE),
	exit (4);
      cmdarg = _strstr (args, " -");
      if (!cmdarg)
	cmdarg = _strstr (args, "\t-");
      if (cmdarg)
	strcat (sys->lists [nlists].cmdoptions, cmdarg);
      upcase (sys->lists [nlists].alias);
      locase (sys->lists [nlists].address);
      ++nlists;
    }
    else if (!strcmp (cmd, "server")) {
      comment = strchr (args, '#');
      if (comment)
        *comment = EOS;
      sscanf (args, "%s", sys->server.address);
      cmdarg = _strstr (args, " -");
      if (!cmdarg)
	cmdarg = _strstr (args, "\t-");
      if (cmdarg)
	strcat (sys->server.cmdoptions, cmdarg);
      locase (sys->server.address);
    }
    else if (!strcmp (cmd, "frequency")) {
      sscanf (args, "%d", &sys->frequency);
      if (sys->frequency < 0)
	sprintf (error, "\nsys_config(): Invalid 'frequency' argument %d in %s",
		 sys->frequency, CONFIG),
	report_progress (report, error, TRUE),
	exit (4);
    }
    else if (!strcmp (cmd, "limit")) {
      sscanf (args, "%s", sys->arg);
      if (!strcmp (locase (sys->arg), "message"))
	sys->options |= LIMIT_MSG,
        sscanf (args, "%s %ld", sys->arg, &sys->limits.msg);
      else
        sprintf (error, "\nsys_config(): Invalid argument %s to 'limit' in %s",
			  sys->arg, CONFIG),
 	report_progress (report, error, TRUE),
	exit (4);
    }
    else if (!strcmp (cmd, "option")) {
      sscanf (args, "%s", sys->arg);
      if (!strcmp (locase (sys->arg), "bsd_ps"))
	sys->options |= BSD_PS;
      else if (!strcmp (sys->arg, "sysv_ps"))
	sys->options |= SYSV_PS;
      else if (!strcmp (sys->arg, "bsd_mail"))
	sys->options |= BSD_MAIL;
      else if (!strcmp (sys->arg, "bad_telnet"))
	sys->options |= USE_MY_SYSTEM;
      else if (!strcmp (sys->arg, "post_mail"))
	sys->options |= POST_MAIL;
      else if (!strcmp (sys->arg, "gate_mail"))
	sys->options |= GATE_MAIL;
      else
	sprintf (error, "\nsys_config(): Invalid argument %s to 'option' in %s",
		 sys->arg, CONFIG),
	report_progress (report, error, TRUE),
	exit (4);
    }
    else if (!strcmp (cmd, "serverd")) {
      comment = strchr (args, '#');
      if (comment)
        *comment = EOS;
      cmdarg = strchr (args, '-');
      if (cmdarg)
	strcat (sys->serverd_cmdoptions, cmdarg);
    }
    else if (!strcmp (cmd, "organization")) {
      comment = strchr (args, '#');
      if (comment)
        *comment = EOS;
      strcpy (sys->organization, args + 1);
    }
    else if (!strcmp (cmd, "restriction"))
      sscanf (args, "%d", &sys->users);
    else if (!strcmp (cmd, "manager"))
      sscanf (args, "%s", sys->manager);
    else if (!strcmp (cmd, "password"))
      sscanf (args, "%s", sys->server.password),
      upcase (sys->server.password);
    else if (!strcmp (cmd, "disable")) {
      if (commands[0].name == NULL)  /* Array not initialized */
	continue;
      sscanf (args, "%s", sys->arg);
      upcase (sys->arg);
      id = get_list_id (sys->arg, sys, nlists);
      if (id < 0)
	sprintf (error, "sys_config(): Unrecognized list name %s for \
'disable' in %s", sys->arg, CONFIG),
	  report_progress (report, error, TRUE),
	  exit (4);
      sscanf (args, "%s %s", sys->arg, sys->arg); /* Get request to disable */
      upcase (sys->arg);
      notok = FALSE;
      k = 0;
      for (i = 0; i < MAX_COMMANDS; ++i) {
	notok &= (((j = strncmp (sys->arg, commands[i].name, strlen (sys->arg)))
		   != 0) ? 1 : 0);
	if (!j)
	  ++k,
	  sys->lists[id].disabled_commands |= commands[i].mask;
      }
      if (notok)
	sprintf (error, "sys_config(): Unrecognized request %s to 'disable' \
for list %s in %s", sys->arg, sys->lists[id].alias, CONFIG),
	report_progress (report, error, TRUE),
	exit (4);
      if (k > 1)
	sprintf (error, "sys_config(): Ambiguous request %s to 'disable' \
for list %s in %s", sys->arg, sys->lists[id].alias, CONFIG),
	report_progress (report, error, TRUE),
	exit (4);
    }
    else if (!strcmp (cmd, "comment")) {
      sscanf (args, "%s", sys->arg);
      if (!strcmp (locase (sys->arg), "server")) {
	comment = strchr (args, '#');
	if (comment == NULL)
	  sprintf (error, "\nsys_config(): Missing # for comment in %s",CONFIG),
          report_progress (report, error, TRUE),
          exit (4);
	RESET (sys->server.comment);
	strcat (sys->server.comment, comment + 1);
      }
      else {  /* Some list name was specified */
	upcase (sys->arg);
	id = get_list_id (sys->arg, sys, nlists);
	if (id < 0)
	  sprintf (error, "sys_config(): Unrecognized list name %s for \
'comment' in %s", sys->arg, CONFIG),
	  report_progress (report, error, TRUE),
	  exit (4);
	comment = strchr (args, '#');
	if (comment == NULL)
	  sprintf (error, "\nsys_config(): Missing # for comment in %s", CONFIG),
	  report_progress (report, error, TRUE),
	  exit (4);
	RESET (sys->lists[id].comment);
	strcat (sys->lists[id].comment, comment + 1);
      }
    }
    else if (!strcmp (cmd, "mailmethod")) {
      sscanf (args, "%s", sys->arg);
      if (!strcmp (locase (sys->arg), "telnet"))
	sys->mail.method = TELNET,
 	sys->options |= USE_TELNET;
      else if (!strcmp (locase (sys->arg), "system"))
	sys->options |= (USE_TELNET | USE_SYSMAIL);
      else if (!strcmp (sys->arg, "sendmail") || !strcmp (sys->arg, "rmail"))
	sys->mail.method = (char *) malloc (256 * sizeof (char)),
	sscanf (args, "%s %s", sys->arg, sys->mail.method),
	locase (sys->mail.method),
	strcat (sys->mail.method, " > /dev/null 2>&1");
      else if (!strcmp (sys->arg, "binmail"))
	sys->mail.method = BINMAIL;
      else if (!strcmp (sys->arg, "env_var"))
	sys->options |= USE_ENV_VAR,
	sscanf (args, "%s %s %s", sys->arg, sys->mail.env_var,
	        sys->mail.mail_prog),
	locase (sys->mail.mail_prog),
	upcase (sys->mail.env_var);
      else
	sprintf (error, "\nsys_config(): Unrecognized mail method %s in %s",
		 sys->arg, CONFIG),
	report_progress (report, error, TRUE),
	exit (4);
    }
    else
      sprintf (error, "\nUnrecognized command %s in %s", cmd, CONFIG),
      report_progress (report, error, TRUE),
      exit (4);
  }
  fclose (config);
  return nlists;
}

/*
  Convert a string to lower case.
*/

char *locase (char *s)
{
  char *r = s;
  while (*s != EOS) {
    if (isupper (*s))
      *s = tolower (*s);
    ++s;
  }
  return r;
}

/*
  Convert a string to upper case.
*/

char *upcase (char *s)
{
  char *r = s;

  while (*s != EOS) {
    if (islower (*s))
      *s = toupper (*s);
    ++s;
  }
  return r;
}

/*
  Write messages and times to REPORT_LIST and stdout. If 'report_time'
  is set to a negative value no leading newline is printed to 'report'.
  NOTE: Use strftime(), if possible.
*/

void report_progress (FILE *report, char *s, int report_time)
{
  extern BOOLEAN tty_echo;
  long int time_is = 0;
  struct tm *t;

  fprintf (report, "%s", s);
  if (report_time) {
    time (&time_is);
    t = localtime (&time_is);
    if (report_time > 0)
      fprintf (report, "\n");
    fprintf (report, "Time/Date: %2d:%.2d:%.2d, %2d/%.2d/%2d\n",
             t->tm_hour, t->tm_min, t->tm_sec, t->tm_mon + 1, t->tm_mday,
             t->tm_year);
  }
  fflush (report);
  if (tty_echo) {
    printf ("%s", s);
    if (report_time)
      printf ("\n");
    fflush (stdout);
  }
}

/*
  Start distribution. Call lower level routines; the algorithm is such that
  this routine always looks at the beginning of each message when reading
  into 'first_line', i.e. 'first_line' is always assigned a string of the form:
		'From emailaddress Date Time'
  which is the universal convention for the start of every message. It calls
  subscribed() to find out if the sender is subscribed and passes the
  result to process_message(). Since the call to extract_sender() alters
  'first_line' to contain only the sender's email address a 'linecopy' is used.
  When returning from process_message() we have already advanced to the
  beginning of the next message, and 'linecopy' contains a string of the 
  above form; therefore we need to copy that back to 'first_line'.
*/

void distribute (FILE *mail, void (*process_message)(), FILE *report,
		 char *subscribersf, char *newsf, char *peersf, char *aliasesf)
{
  char first_line[MAX_LINE], linecopy[MAX_LINE];

  first_line[0] = RESET (linecopy);
  while (!feof (mail))
    if (first_line[0] != EOS)
      extract_sender (first_line),
      process_message ((char *) first_line, (char *) linecopy, (BOOLEAN)
		       subscribed (report, first_line, subscribersf, newsf,
				   peersf, aliasesf)),
      strcpy (first_line, linecopy);
    else /* Read the first line of the very first message */
      fgets (first_line, MAX_LINE - 2, mail), /* 'From email Date Time' */
      strcpy (linecopy, first_line);
}

/*
  Look for occurence of 'string' in 'substr' and return either TRUE or FALSE.
  Look at the comments for defs.h for the syntax of 'substr'. A 'substr' of
  "*" matches everything.
*/

BOOLEAN strinstr (char *substr, char *string, char *sep)
{
  char *origstr = string, *tok, *substrcopy;
  int l;

  if (*substr == '*')
    return TRUE;
  substrcopy = (char *) malloc ((strlen (substr) + 1) * sizeof (char));
  strcpy (substrcopy, substr);
  tok = strtok (substrcopy, sep); /* Get first token */
  while (tok) { /* For every token in substr, check if it's in 'string' */
    string = origstr;
    l = strlen (tok);
    if (strlen (string) < l) {
      tok = strtok (NULL, sep);  /* get next token */
      continue;
    }
    while (strlen (string) >= l)
      if (! strncmp (tok, string, l)) {
        free (substrcopy);
        return TRUE;
      }
      else
        ++string;
    tok = strtok (NULL, sep); /* failed with this token; get the next one */
  }
  free (substrcopy);
  return FALSE;
}

/*
  Given a file path, extract the file name. In the process, any command line
  options or any characters separated from the filename are discarded.
*/

char *extract_filename (char *s)
{
  char *p, *r, *t = s, nchar = 0;

  while (*t != EOS && *t != ' ' && *t != '\t') /* Get to delimiting char */
    ++t;
  while (t != s && *t != '/') /* Go back till / or the beginning of s */
    ++nchar,
    --t;
  if (t != s || (*t == '/' && *(t + 1) != EOS))
    --nchar,
    ++t;
  r = p = (char *) malloc ((nchar + 1) * sizeof (char));
  *p = EOS;
  while (*t != EOS && *t != ' ' && *t != '\t')
    *(p++) = *(t++);
  *p = EOS;
  return r;
}

/*
  Recognize the command line parameters. It returns '?' on an unrecognized
  option, ':' if an option requires an argument and the argument is missing,
  or the recognized character itself. This code is a copyright of AT&T.
*/

# define ERR(str, ch) if (opterr) \
                        fprintf (stderr, "%s%s%c\n", argv[0], str, ch);

int opterr = 0;
int optind = 1;
int optopt;
char *optarg;

int getopt (int argc, char **argv, char *opts)
{
  static int sp = 1;
  register int c;
  register char *cp;

  if (sp == 1)
    if (optind >= argc || argv[optind][0] != '-' || argv[optind][1] == '\0')
      return EOF;
    else if (strcmp (argv[optind], "--") == NULL) {
      optind++;
      return EOF;
    }
    optopt = c = argv[optind][sp];
    if (c == ':' || (cp = strchr (opts, c)) == NULL) {
      ERR (": unknown option, -", c);
      if (argv[optind][++sp] == '\0')
        optind++,
        sp = 1;
      return '?';
    }
    if (*++cp == ':') {
      if (argv[optind][sp+1] != '\0')
        optarg = &argv[optind++][sp+1];
      else if (++optind >= argc) {
        ERR(": argument missing for -", c);
        sp = 1;
        return ':';
      }
      else
        optarg = argv[optind++];
      sp = 1;
    }
    else {
      if (argv[optind][++sp] == '\0')
        sp = 1,
        optind++;
      optarg = NULL;
    }
    return c;
}

/*
  Remove any extraneous characters from a name and convert it to lower
  case with the first character of each word capitalized.
*/

char *cleanup_name (char *s)
{
  char *tok, *copy, *sep = " ", *line;
  int j, l;

  if (s [strlen (s) - 1] == '\n')
    s [strlen (s) - 1] = EOS;
  line = (char *) malloc ((strlen (s) + 1) * sizeof (char));
  strcpy (line, s);
  *s = EOS;
  tok = strtok (line, sep);
  while (tok) {
    copy = tok;
    while (*copy != EOS) {  /* Remove extraneous characters */
      if (! isalpha (*copy) && ! isspace (*copy)) {
        for (j = 0, l = strlen (copy); j < l; copy[j] = copy[j+1], ++j);
        continue;
      }
      ++copy;
    }
    locase (tok);
    *tok = toupper (*tok);
    sprintf (s + strlen (s), " %s", tok);
    tok = strtok (NULL, sep);
  }
  free (line);
  return s;
}

/*
  Remove leading blanks from a request.
*/

void cleanup_request (char *s)
{
  while (isspace (*s))
    sprintf (s, "%s", s + 1);
}

/*
  Identify the list that the request refers to. Before doing so, remove
  any unnecessary blanks from the parameters. Also, check each parameter
  for proper syntax.
*/

void get_list_name (char *params, char *list_name)
{
  int i;
  char *s, *r, *t;
  char param [MAX_LINE];

  r = s = (char *) malloc ((strlen (params) + 1) * sizeof (char));
  strcpy (s, params);
  RESET (params);
  RESET (param);
  for (i = 0; s[i] != EOS;)
    if (isspace (s[i]) && isspace (s[i + 1]))
      sprintf (s + i, "%s", s + i + 1);
    else
      i++;
  do {
    RESET (param);
    sscanf (s, "%s", param);
    s = s + strlen (param) + 1; /* Skip over space */
    t = strpbrk (param, "*?/");
    if (t != NULL) {
      if (t == param || (t != param && ! isalpha (*(t - 1)))) /* Invalid *,? */
	*t = '+';
      if (*t == '/') /* Invalid / */
	*t = '%';
    }
    sprintf (params + strlen (params), " %s", param);
  } while (param[0] != EOS);
  strcat (params, "\n");
  free (r);
  RESET (list_name);
  sscanf (params, "%s", list_name);
  upcase (list_name);
  sprintf (params, "%s", params + strlen (list_name) + 1);
}

/*
  Given a list name, return its index in the array of known lists.
*/

int get_list_id (char *list_name, SYS *sys, int nlists)
{
  int i;

  for (i = 0; i < nlists; i++)
    if (!strcmp (list_name, sys->lists[i].alias))
      return i;
  return -1;
}

void setup_string (char *s, char *alias, char *filename)
{
  RESET (s);
  sprintf (s, "%s/lists/%s/%s", PATH", alias, filename);
}

/*
  Return the first occurence of 'sub' in 'src', or NULL if not found.
*/

char *_strstr (char *src, char *sub)
{
  if (src == NULL || sub == NULL)
    return NULL;
  while (*src != EOS) {
    if (!strncmp (src, sub, strlen (sub)))
      return src;
    ++src;
  }
  return NULL;
}

/*
  Shrink a message-id file so that it contains a maximum of KEEP_MESSAGE_IDS
  entries in it.
*/

void shrink (char *s)
{
  syscom ("tail -%d %s > /tmp/.msg", KEEP_MESSAGE_IDS, s);
  syscom ("mv /tmp/.msg %s", s);
}

/*
  Verify that 'i' is in 's'.
*/

BOOLEAN requested_part (char *s, int i)
{
  char buf [80];
  char copy [MAX_LINE];

  strncpy (copy, s, MAX_LINE - 1);
  do {
    RESET (buf);
    sscanf (copy, "%s", buf);
    sprintf (copy, "%s", strchr (copy, buf[0]) + strlen (buf));
    if (atoi (buf) == i)
      return TRUE;
  } while (buf[0] != EOS);
  return FALSE;
}

/*
  Use my_system() when either list and listserv use TELNET and there is
  an indication that the sessions do not exit.
*/

int my_system (char *s)
{
  FILE *f;
  int pid, status;
  char line [MAX_LINE], *r;
  extern SYS sys;

  if (strcmp ((r = extract_filename (s)), "telnet")) {
    status = system (s);
    free ((char *) r);
    return status;
  }
  free ((char *) r);
  strcat (s, " &"); /* Only telnet runs in the background */
  status = system (s);
  if (status > 127)
    return status;
  sleep (5);
  if (sys.options & BSD_PS)
    system ("ps -gx | grep telnet | grep -v \"grep telnet\" \
	    | grep -v telnetd > ./telnet");
  else if (sys.options & SYSV_PS)
    system ("ps -ef | grep telnet | grep -v \"grep telnet\" \
	    | grep -v telnetd > ./telnet");
  if ((f = fopen ("./telnet", "r")) == NULL)
    return -1;
  while (! feof (f)) {
    RESET (line);
    fgets (line, MAX_LINE - 2, f);
    if (line[0] != EOS)
      sscanf (line, "%d", &pid),
      sleep (15),
      kill (pid, SIGHUP);
  }
  fclose (f);
  unlink ("./telnet");
  return status;
}

/* Change history (by Bob Boyd)
21-Aug-1991   RLB     change parameter scanning for "list" lines in the
                      config file so that "-" characters in the list-alias
                      are ignored when looking for the beginning of the
                      list parameters [tasos: I defined my own strstr()]
*/
