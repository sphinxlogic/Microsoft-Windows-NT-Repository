/*
  AGREEMENT: This software can be used and distributed freely as long
  as you do not remove or alter the Copyright notice in the file defs.h;
  this notice is #define'd in the symbol VERSION. Although you may alter
  the code provided, you may not alter the functions create_header()
  and create_multi_recipient_header() in list.c and listserv.c.
  By using this software you are bound by this agreement.
  This software comes with no warranties and cannot be sold for profit.
  The AGREEMENT and COPYRIGHT notices should be included in all source
  files when distributing this software.
  COPYRIGHT: Copyright (c) 1991, Anastasios C. Kotsikonas

  Below are the #define's pertinent to listserv.c

  Preserve any quotes and new lines that appear below; change only path names.

  ALWAYS SPECIFY ABSOLUTE PATHS.

*/

#define UPDATE_DATE	  "December 9, 1991"
#define MAIL_COPY         PATH/.messages"
#define OLD_SUBSCRIBERS   PATH/.oldsubscribers"
#define MAILFORWARD       PATH/.mailforward"
#define MSG_NO            PATH/.msgno"
#define RECIP_FILE	  ".recip"
#define AWK_PROG	  PATH/.awk"
#define STATS_PROG	  PATH/.stats"
#define SERVER_MBOX       PATH/mbox"	/* place to save server's messages */
#define STATS_FILE        "/tmp/stats"
#define USERS_FILE	  "/tmp/users"
#define HELP_GENERAL	  PATH/help/general"
#define HELP_SET	  PATH/help/set"
#define HELP_SUBSCRIBE	  PATH/help/subscribe"
#define HELP_UNSUBSCRIBE  PATH/help/unsubscribe"
#define HELP_RECIPIENTS	  PATH/help/recipients"
#define HELP_INFORMATION  PATH/help/information"
#define HELP_STATISTICS	  PATH/help/statistics"
#define HELP_LISTS	  PATH/help/lists"
#define HELP_INDEX	  PATH/help/index"
#define HELP_GET	  PATH/help/get"
#define HELP_RELEASE	  PATH/help/release"
#define ARCHIVE_DIR	  PATH/archives"
#define DEFAULT_ARCHIVE	  "listserv"
#define INDEX		  "INDEX"
#define DIR		  "DIR"
#define PEER_SERVER_REQUEST "Peer Server Request: "
#define START_OF_SIGNATURE "--"
#define MAX_SET_OPTIONS	  1 

#define DELIVER_MAIL(recipient) \
  if (sys.options & USE_SYSMAIL) \
    sysmail (MAILFORWARD); \
  else \
    syscom ("%s %s < %s", sys.mail.method, \
            (((sys.options & USE_TELNET) == 0) ? locase (recipient) : ""), \
            MAILFORWARD)

#define APPEND_TELNET(func) \
  if (sys.options & USE_TELNET) {\
    if ((f = fopen (MAILFORWARD, "a")) == NULL)\
      sprintf (error, "%s(): Could not open %s", func, MAILFORWARD),\
      report_progress (report, error, TRUE),\
      exit (1);\
    COMPLETE_FILE (f);\
    fclose (f);\
  }

#define NOTIFY_MANAGER(msg) \
  create_header (&f, MAILFORWARD, sys.server.address, sys.manager, sender);\
  fprintf (f, "%s %s\n", msg, sender);\
  COMPLETE_TELNET (f);\
  fclose (f);\
  DELIVER_MAIL (sys.manager);\
  sprintf (error, "%s %s; forwarding message to %s\n", msg, sender,\
	   sys.manager);\
  report_progress (report, error, FALSE)

#define NOTIFY_OF_BAD_ARCHIVE(msg, archive) \
  create_header (&f, MAILFORWARD, sys.server.address, sender, request);\
  fprintf (f, msg, archive);\
  COMPLETE_TELNET (f);\
  fclose (f);\
  DELIVER_MAIL (sender)


char recipf [MAX_LINE];	  /* path to list + RECIP_FILE */

FILE *mail        = NULL; /* Source of messages */
FILE *report      = NULL; /* Progress report to the administrator */
FILE *subscribers = NULL; /* List of subscribers */
FILE *ignored     = NULL; /* List of people whose messages are ignored */
FILE *msg_no      = NULL; /* Last message count */
FILE *message_ids = NULL; /* List of message ids */

int     listid = -1;
int     request_no = 0;             /* Counts the public messages */
int     restricted_commands = 0;    /* Mask of restrictions */
int	disabled_commands = 0;	    /* Mask for disabling commands */
int     nlists = -1;                /* # of lists defined in CONFIG */
BOOLEAN one_rejection = FALSE;
BOOLEAN restart_sys = FALSE;
BOOLEAN tty_echo = FALSE;	    /* -e option off */
BOOLEAN do_not_notify_peer_server = FALSE;
BOOLEAN peer_server_request = FALSE;
char    *options [] = { "MAIL" }; /* valid SET options */
char    *values [] = { "ACK|NOACK|NEVERACK|POSTPONE" }; /* and values */
char    *default_values [] = { "NOACK" };
