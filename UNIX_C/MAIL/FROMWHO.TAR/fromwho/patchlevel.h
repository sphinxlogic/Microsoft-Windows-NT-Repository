/*
  fromwho patchlevel

  This includes the RCS log and the patchlevel define

  $Log:	patchlevel.h,v $
    Revision 1.3  91/12/03  11:14:15  jearls
    PATCH3: Added `-v' option to display the version number.
    
    Revision 1.2  91/11/23  12:49:40  jearls
    PATCH2: Fixed miscellanous bugs, added '-n' option to
    PATCH2: list only new mail.
    
    Revision 1.1  91/10/19  17:06:12  jearls
    PATCH1: Added support for AIX and other systems that don't
    PATCH1: use a mail spool.
    
    Revision 1.0  91/10/19  14:40:25  jearls
    Initial revision
    
*/

#define PATCHLEVEL 3
