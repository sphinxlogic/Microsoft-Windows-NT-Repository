/*
 *	S _ T A I L O R . C
 *
 *  Contains strings used to tailor SEND to a particular
 *  site.  Also check s.h for tailorable defines.
 */

char	*dfleditor = "pen";
char	*dflveditor = "pen";
char	*dflchecker = "spell";
