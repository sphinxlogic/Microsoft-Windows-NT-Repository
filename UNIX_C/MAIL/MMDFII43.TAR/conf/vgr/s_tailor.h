/*
 *	Site Tunable Parameters
 */
#undef	SENTFILE yes	/* Define to have copies of mail sent put in ,sent */
#define	PWNAME	yes	/* Define to get real name from /etc/passwd and to */
			/* treat 0 length signatures to get login name only */
#define	SENDRC	".sendrc"	/* name of run-configuration file */
