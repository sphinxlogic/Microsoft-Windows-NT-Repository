/* For systems that have no easy way to find last login time */
/* For example: SYSVR2  --  "Consider it stranded." */

setllog()
{
}

endllog()
{
}

getllog()
{
	return (0);
}

getllnam(name)
char *name;
{
	return (0);
}
