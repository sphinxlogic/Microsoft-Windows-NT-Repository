char	*verdate = "12 Mar 1987 #74";
