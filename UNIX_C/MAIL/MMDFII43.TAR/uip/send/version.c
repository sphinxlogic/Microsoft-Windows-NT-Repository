char	*verdate = "3 May 1986 #105";
