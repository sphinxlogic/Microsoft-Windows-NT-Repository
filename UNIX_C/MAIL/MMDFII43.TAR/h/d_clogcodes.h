/*
 *     codes used for logging telephone calls through the auto-dialer
 */

# define  LOG_ABAN       'A'     /*  call was abandoned  */
# define  LOG_COMP       'C'     /*  call was completed normally  */
# define  LOG_START      'S'     /*  call starting  */
# define  LOG_OPEN       'O'     /*  open the call log  */

