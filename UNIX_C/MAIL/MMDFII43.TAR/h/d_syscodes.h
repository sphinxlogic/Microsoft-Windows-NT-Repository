
/*
 *     extensions to normal errno values
 */

# define  EDNPWR          80     /*  acu has no power  */
# define  EDNABAN         81     /*  acu abandon call and retry  */
# define  EDNDIG          82     /*  illegal digit in number  */
