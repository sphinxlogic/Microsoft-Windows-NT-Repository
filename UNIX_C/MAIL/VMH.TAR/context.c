#ifndef lint
static char rcsid[] =
	"$Header: context.c,v 1.8 86/10/09 15:59:57 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif

/*
 * Routines for dealing with the context file.
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/context.c,v $
 * $Revision: 1.8 $
 * $Author: deboor $
 * 
 * FUNCTIONS:
 *	get_cur_fold()	returns the name of the current folder as specified
 *			in the context file.
 *	set_cur_fold()	installs the passed folder as the current one in
 *			the context file.
 *
 * TODO: add reading of private sequences init_sequences(): should it be
 *	done here or there?
 *
 */

#include "vmh.h"

/*
 * find_context (buf, buflen) register char *buf; register buflen;
 *	fills buf with the name of the context file.
 */
find_context (buf, buflen)
	Reg2	char	*buf;
	Reg3	int	buflen;
{
	Reg1	char	*cp;
	char		line[132];

#ifdef MH6
	if (cp = getenv ("MHCONTEXT")) {
		if (*cp != '/')
			(void) sprintf (buf, "%s/%s", rootpath, cp);
		else
			(void) strncpy (buf, cp, buflen);
	} else {
#endif MH6
		if (!readprofile ("context:", line, sizeof(line)))
			(void) sprintf (buf, "%s/%s", rootpath, context);
		else {
			if (*line != '/')
				(void) sprintf (buf,"%s/%s",rootpath,line);
			else
				(void) strncpy (buf, line, buflen);
		}
#ifdef MH6
	}
#endif MH6
}


/*
 * char *
 * get_cur_fold()
 *	returns a pointer to the name of the current folder. If the folder
 *	depends from the MH directory, only the folder name (i.e. minus
 *	the rootpath) is returned, else the full path of the folder is returned.
 */
char *
get_cur_fold()
{
	char		contextp[PATHLENGTH];
	register FILE	*cfile;
	char		line[PATHLENGTH];
	register	hlen;
	register char	*cp,
			*cp2;

	find_context (contextp, sizeof(contextp));
	if ((cfile = fopen (contextp, "r")) == NULL) {
		punt ("Can't open context file!");
	}
	while ((hlen = readheader (line, sizeof(line), cfile, TRUE))) {
		if (uprf (line, pfolder)) {
			if (!(cp = index (line, ':')))
				punt ("Malformed context file!");
			while (isspace (*++cp))
				/* void */ ;
			cp2 = contextp;
			while (!isspace (*cp))
				*cp2++ = *cp++;
			*cp2 = '\0';
			cp2 = contextp;
			if (*cp2 == '/' && !strncmp (rootpath,cp2,rootlen))
				cp2 = &contextp[rootlen+1];
			cp = (char *) Malloc (strlen (cp2)+1);
			(void) strcpy (cp, cp2);
			(void) fclose (cfile);
			return (cp);
		} else {
			while (hlen < 0)
				hlen = readheader(line,sizeof(line),cfile,TRUE);
		}
	}
	(void) fclose (cfile);
	cp = (char *) Malloc (strlen (defalt)+1);
	(void) strcpy (cp, defalt);
	return (cp);
}

/*
 * set_cur_fold (fname) char *fname;
 *	sets the current folder in the context file to fname.
 *	the current context folder is backed up before it is changed. If an
 *	error occurs, an attempt is made to restore the previous context.
 *	If this attempt fails, the old context is left in the file
 *	<old-context>.bak where <old-context> is the name of the context
 *	file.
 */
set_cur_fold (fname)
	char	*fname;
{
	FILE	*cfile,
		*tcfile;
	char	line[256];
	char	contextp[PATHLENGTH];
	char	tcontextp[PATHLENGTH];
	extern	int	errno;
	int	terr;

	find_context (contextp, sizeof(contextp));
	(void) sprintf (tcontextp, "%s.bak", contextp);
	if (rename(contextp, tcontextp) == -1) {
		punt ("Can't backup context file");
		/*NOTREACHED*/
	}
	if ((cfile = fopen (contextp, "w")) == NULL) {
		terr = errno;
		if (rename (tcontextp, contextp)) {
			errno = terr;
			punt ("Can't open new context file. .bak file left");
		} else {
			errno = terr;
			punt ("Can't open new context file. Old file restored");
		}
		/*NOTREACHED*/
	}
	if ((tcfile = fopen (tcontextp, "r")) == NULL) {
		punt ("Cannot open old context file!");
		/*NOTREACHED*/
	}

	while (fgets (line, sizeof(line), tcfile)) {
		if (uprf (line, pfolder)) {
			if (!strncmp (fname, rootpath, rootlen)) {
				fprintf (cfile, "%s: %s\n", pfolder, &fname[rootlen+1]);
			} else {
				fprintf (cfile, "%s: %s\n", pfolder, fname);
			}
		} else {
			fputs (line, cfile);
		}
	}
	(void) fclose (cfile);
	(void) fclose (tcfile);
	(void) unlink (tcontextp);
}
