#ifndef lint
static char rcsid[] =
	"$Header: fempty.c,v 2.2 86/02/08 20:59:36 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif

#include <stdio.h>

fempty(p)
	FILE	*p;
{
	if (p->_cnt>0)
		return(0);       /* If any in buf, return false */
	return(empty(fileno(p)));
}
