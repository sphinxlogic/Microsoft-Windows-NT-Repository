#ifndef lint
static char rcsid[] =
	"$Header: rdconfig.c,v 2.3 86/02/08 21:03:35 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif

/*
 * routines for dealing with the configuration file
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/rdconfig.c,v $
 * $Revision: 2.3 $
 * $Author: deboor $
 *
 * FUNCTIONS:
 *	read_config	find and read configuration file
 */
#include "vmh.h"
#include <sys/file.h>

char		helpfile[PATHLENGTH];
extern	char	pagerstr[],		/* in init.c */
		editorstr[];

read_config(progname)
	char *progname;
{
	char		confpath[PATHLENGTH];
	char		line[PATHLENGTH];	/* can have pathname */
	register FILE	*cfile;
	register char	*cp,			/* character pointer */
			*pp;			/* path pointer */

	default_config();	/* start with default */

	if (cp = index (progname, '/')) {
		getwd (confpath);
		(void) strcat (confpath, "/");
		(void) strcat (confpath, progname);
		(void) strcat (confpath, ".conf");
	} else {		/* find the thing on the path */
		for (pp = getenv("PATH"); *pp; pp++) {
			for (cp = confpath; *pp != ':'; *cp++ = *pp++)
				;
			*cp = '\0';
			(void) strcat (confpath, "/");
			(void) strcat (confpath, progname);
			if ( ! access (confpath, X_OK))
				break;
		}
		if (*pp) {
			(void) strcat (confpath, ".conf");
		} else
			return;
	}
	if ((cfile = fopen (confpath, "r")) == (FILE *) NULL) {
		return;
	}
	while (fgets (line, sizeof(line), cfile)) {
		if (cp = index (line, '\n'))
			*cp = '\0';
		for (cp = line; *cp && ! isspace (*cp); cp++)
			;
		*cp++ = '\0';
		for (; isspace (*cp); cp++)
			;
		if (uleq (line, "helpfile")) {
			(void) strcpy (helpfile, cp);
		} else if (uleq (line, "editor")) {
			(void) strcpy (editorstr, cp);
		} else if (uleq (line, "page")) {
			(void) strcpy (pagerstr, cp);
		} else {
			punt ("error in config file");
		}
	}
	(void) fclose (cfile);
}

default_config()
{
	(void) strcpy (helpfile, HELPFILE);
	(void) strcpy (editorstr, EDITOR);
	(void) strcpy (pagerstr, PAGE);
}
