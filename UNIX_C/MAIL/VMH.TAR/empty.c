#ifndef lint
static char rcsid[] =
	"$Header: empty.c,v 2.5 86/10/09 16:00:30 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif

#include <sys/ioctl.h>
#include "casts.h"

empty (fd)
	int	fd;
{
    long count;
    if (Ioctl (fd, FIONREAD, &count) < 0)
	return 1;
    return count <= 0;
}
