#ifndef lint
static char rcsid[] =
	"$Header: scroll.c,v 2.5 86/10/09 16:12:54 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif
#include "vmh.h"

/*
 * This code is pretty terrible, but until Mark Horton can get
 * his new version out of Bell Labs, I have to do it myself.
 *
 *  (note: routine name "scroll" already used by curses)
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/scroll.c,v $
 * $Revision: 2.5 $
 * $Author: deboor $
 * 
 * FUNCTIONS:
 *	dumbdeleteline	delete a line of a window on stupid terminals
 *	mydeleteline	delete a line of a window on clever terminals
 *	scrolldown	scroll a window down one line intelligently
 *	scrollup	scroll a window up one line intelligently
 */

char	*alstring,
	*dlstring,
	*clstring;

/*
 * Move window contents up a line
 */

scrollup(win)
	reg WINDOW *win;
{                               /* Delete top line, insert blank at bottom */
	if (mydeleteline(win, 0, win->_maxy -1) == -1)
		dumbdeleteline(win, 0);
}

/*
 * Move window contents down a line
 */

scrolldown(win)
	reg WINDOW *win;
{
			/* Delete last line, insert blank line at top */
	mydeleteline(win, win->_maxy -1, 0);
		/* What to do on dumb ttys here? */
}

mydeleteline(win, delnum, insnum)
	reg WINDOW *win;
	int delnum;             /* Line number to delete */
	int insnum;             /* Line number to add blank line */
{
	int dy = win->_begy;    /* Window's vertical offset */

/************************************************************************/
/*** Check and verify terminal & window qualify for real ins/del line ***/
/************************************************************************/

	if (   (strlen(dlstring) == 0)          /* Terminal must have */
	    || (strlen(alstring) == 0)          /* insert & delete line */
	    || (win->_begx != 0)                /* Window must be full */
	    || (win->_maxx != curscr->_maxx)    /* width of the screen */
	   )  return(-1);                               /* return err */

/*** Fixup teminal left in standout mode ***/

	if (curscr->_flags & _STANDOUT)
	{       _puts(SE);                      /* End standout mode */
		curscr->_flags &= ~_STANDOUT;   /* Turn off flag */
	}

/*** Goto screen version of delnum and issue delete line command ***/

	tputs( tgoto(CM, 0, delnum + dy), 1, _putchar);
	tputs( dlstring, LINES - delnum - dy, _putchar);

/*** Goto screen version of insnum and issue insert line command ***/

	tputs( tgoto(CM, 0, insnum + dy), 1, _putchar);
	tputs( alstring, LINES - insnum - dy, _putchar);

/*** Update the window structures to reflect actual changes ***/

	subsub(win, delnum, insnum);
	if (win != curscr)
		subsub(curscr, delnum + dy, insnum + dy);

/*** Put the cursor back where the curses package thinks it is ***/
	/** I wonder if this is right? **/
	tputs( tgoto(CM, curscr->_curx, curscr->_cury), 1, _putchar);

	return(0);                      /* Return ok */
}


/*
 * subsub (win, delnum, insnum)
 *	switch line buffers around so that curses thinks all is cool
 */
subsub(win, delnum, insnum)
	reg WINDOW *win;
	int delnum;             /* Line number to delete */
	int insnum;             /* Line number to add blank line */
{
	int i;
	char *templine;

/*** Delete line from win structure, saving ptr for later re-use */

	templine = win->_y[delnum];     /* Save ptr to mem of deleted line */

	for (i=delnum ; i < win->_maxy - 1 ; i++)
	{
		win->_y[i]       = win->_y[i+1];
		win->_firstch[i] = win->_firstch[i+1];
		win->_lastch[i]  = win->_lastch[i+1];
	}

/*** Insert line at insnum place in win structure ***/

	for (i = win->_maxy -1; i > insnum; i--)
	{
		win->_y[i]       = win->_y[i-1];
		win->_firstch[i] = win->_firstch[i-1];
		win->_lastch[i]  = win->_lastch[i-1];
	}
	win->_y[insnum] = templine;

	win->_firstch[insnum] = 0;
	win->_lastch[insnum] =  win->_maxx - 1;


/*** The new line is full of blanks ***/
	for (i=0 ; i < win->_maxx ; i++)
		templine[i] = ' ';
}


dumbdeleteline(win, delnum)
	reg WINDOW *win;
	int delnum;             /* Line number to delete */
{
	int oldy, oldx;

	getyx (win, oldy, oldx);

	wmove(win, delnum, 0);
	wdeleteln(win);

	wmove (win, oldy, oldx);
}
