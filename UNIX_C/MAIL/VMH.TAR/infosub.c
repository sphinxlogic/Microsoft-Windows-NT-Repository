#ifndef lint
static char rcsid[] =
	"$Header: infosub.c,v 2.6 86/02/16 15:08:12 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif

/*
 * routine for creating an individual INFO structure.
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/infosub.c,v $
 * $Revision: 2.6 $
 * $Author: deboor $
 *
 * FUNCTIONS:
 *	infosub		scan a single message
 */

#include "vmh.h"

static	char	*myname = (char *) 0;


struct	dayt	{
	u_char	day,
		month,
		year;
} *parsedat();

/*
** off_t
** offtonb (soff, str) off_t soff; char *str;
**	skips the first word (series of non-blank) of str and
**	then moves to the first non-blank after that. the offset
**	of this character is returned. If there is no second word,
**	-1 is returned.
*/
static off_t
offtonb (soff, str)
	off_t	soff;
	char	*str;
{
	register char	*cp;

	for (cp = str; *cp && !isspace (*cp); cp++)
		;
	if (! *cp)
		return ((off_t) -1);
	for (;*cp && isspace (*cp); cp++)
		;
	if (! *cp)
		return ((off_t) -1);
	return (soff + cp - str);
}

INFO *
infosub(inb, innum)
	register FILE	*inb;      /* Open msg file (not the folder) */
	int		innum;      /* Msg number of the current msg */
{

	char		buf[BUFSIZ];	/* enlarge? */
	register INFO	*srec;
	register off_t	cpos;
	off_t		fromoff = -1,
			tooff = -1;
	int		readsubj = FALSE,
			readdate = FALSE,
			readfrom = FALSE,
			readto = FALSE;
	int		sc;
	char		*cp;
	struct	dayt	*dt;
	struct stat	sb;		/* owner and group x bit determine if */
					/*  msg is "seen" or "replied"        */
					/* THIS IS A HACK. Sequences? */

	if(!myname)
		myname = getenv("USER");
	buf[0] = '\0';
	srec = AllocST(INFO);	/* get a info record */
	srec->i_subject = srec->i_path = srec->i_body = (off_t) -1;
	srec->i_mnum = innum;

	/*
	 * stat the open message, and make note of owner and group
	 *      execute bits.
	 */
	if( fstat( fileno(inb), &sb ) != 0 )
		punt( "infosub: Can't fstat msg" );
	if( IfSeen(sb.st_mode))
		srec->i_seen = 1;
	if( IfReply(sb.st_mode))
		srec->i_replied = 1;
	srec->i_size = sb.st_size;
	srec->i_mtime = sb.st_mtime;

	for(;;) {
		cpos = ftell (inb);
		sc = readheader (buf, sizeof(buf), inb, RH_NONL);
		if (! sc) {	/* => out of headers */
			srec->i_body = cpos+1;
			break;
		} else {
			switch (buf[0]) {
			case 'f': case 'F':
				if (uprf (buf, "from:") && ! readfrom) {
			from:
					readfrom = TRUE;
					if (! isme (buf)) {
						fromoff = offtonb (cpos, buf);
						srec->i_fromMe = 0;
					} else {
						srec->i_fromMe = 1;
					}
				} else if (uprf (buf, "forwarded:")) {
					srec->i_forwarded = 1;
				}
				break;
			case 'd': case 'D':
				if (uprf (buf, "date:") && !readdate) {
			date:
					for (cp = buf; *cp && *cp != ':'; cp++)
						;
/* hmmm.... */
					dt = parsedat (cp++);
					srec->i_month = dt->month;
					srec->i_day = dt->day;
					srec->i_year = dt->year;
					readdate = TRUE;
				}; break;
			case 's': case 'S':
				if (uprf (buf, "subject:") && !readsubj) {
			subject:
					srec->i_subject = offtonb (cpos, buf);
					readsubj = TRUE;
				}; break;
			case 't': case 'T':
				if (uprf (buf, "to:") && !readto){
			to:
					tooff = offtonb (cpos, buf);
					readto = TRUE;
				}; break;
			case 'r': case 'R':
				if (uprf (buf, "replied:")) {
					srec->i_replied = 1;
				} else if (uprf (buf, "resent:")) {
					srec->i_resent = 1;
				} else if (uprf (buf, "resent-from:")) {
					goto from;
				} else if (uprf (buf, "resent-to:")) {
					goto to;
				} else if (uprf (buf, "resent-subject:")) {
					goto subject;
				} else if (uprf (buf, "resent-date:")) {
					goto date;
				}
			} /* switch */

			if (sc < 0)
				while (fgets (buf, sizeof(buf), inb) &&
					! index (buf, '\n'))
					;
		}
	}
	/* set i_fromMe here */
	srec->i_path = (srec->i_fromMe ? tooff : fromoff);
	return (srec);
}

/*
 * isme (addr)
 * register char *addr;
 *	this will eventually return TRUE if the passed  addr  is the
 *	person. haven't figured out yet how to go about it.
 */
static int
isme (addr)
	register char	*addr;
{
	if (strindex (myname, addr) != -1)	/* use searchline() ? */
		return 1;
	return (0);
}

struct	tm	*localtime();
time_t		time();

/*
 * dperm[] is an array of the day-of-the-year of the first day of the month
 */
int	dperm[] = {
	0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334
};

static struct dayt *
parsedat(dbuf)
	register char *dbuf;
{
	register char		*cp;
	
	register		pnum;	/* partial number */
	static struct tm	*locvec = (struct tm *) 0;
	time_t			now;
	struct tm		dt;
	static struct	dayt	date;

	if(!locvec) {
		now = time((time_t *)0);
		Bcopy (localtime(&now), locvec = AllocS(tm), sizeof(struct tm));
	}

	/* Collect the various fields of the date */
	for (cp = dbuf; *cp && ! isdigit (*cp); cp++)
		;
	if (! *cp)
		goto baddate;

	/* get the day */
	for (pnum = 0; isdigit (*cp); cp++)
		pnum = pnum * 10 + *cp - '0';
	dt.tm_mday = pnum;

	/* get the month */
	while (*cp && !isalpha(*cp))
		cp++;
	
	if (! *cp)
		goto baddate;

	if ((dt.tm_mon = findmonth (cp)) == 0)
		dt.tm_mon = locvec->tm_mon+1; /* + 1 ? */

	/* get the year */
	while (*cp && !isdigit(*cp))	/* skip over month and wsp */
		cp++;

	if (! *cp)
		goto baddate;

	for (pnum = 0; isdigit(*cp); cp++)
		pnum = pnum * 10 + *cp - '0';
	dt.tm_year = pnum;
	date.day	= (u_char) dt.tm_mday;
	date.month	= (u_char) dt.tm_mon;
	date.year	= (u_char) dt.tm_year % 100;
	return (&date);

baddate:
	date.day = date.month = date.year = (u_char) 0;
	return (&date);

#ifdef notdef
	
	while (*cp && ! isdigit (*cp))
		cp++;

	if (! *cp)
		goto baddate;

	for (pnum = 0; isdigit (*cp); cp++)
		pnum = pnum * 10 + *cp - '0';
	dt.tm_hour = pnum;

	while (*cp && ! isdigit(*cp))
		cp++;

	if (! *cp)
		goto baddate;

	for (pnum = 0; isdigit (*cp); cp++)
		pnum = pnum * 10 + *cp - '0';
	
	while (*cp && !isspace (*cp))
		cp++;
	while (*cp && isspace(*cp))
		cp++;
	tz = cp;
	while (*cp && !isspace(*cp))
		cp++;
	*cp = '\0';
	
	/* 86400 s/day = 60s/min * 60 min/hr * 24hr/day */
	now = (dt.tm_hour * 60 + pnum) * 60 +
		86400 * (dperm[dt.tm_mon - 1] + (dt.tm_mday - 1) +
			365 * (dt.tm_year - (dt.tm_year > 100 ? 1970 : 70)));
	return (adjtime(now, tz));
baddate:
	return (time ((long *) 0));
#endif notdef
}

static struct mtab {	/* a 'trie' of sorts. */
	char		kc;
	struct	mtab	*ntbl;
	int		mno;
} jutbl[] = {		/* months which begin with 'ju' */
	'n',	0,	6,	/* june */
	'l',	0,	7,	/* july */
	'\0',	0,	0,
}, jtbl[] = {		/* months which begin with 'j' */
	'a',	0,	1,	/* january */
	'u',	jutbl,	0,	/* june or july */
	'\0',	0,	0,
}, matbl[] = {		/* begin with 'ma' */
	'r',	0,	3,	/* march */
	'y',	0,	5,	/* may */
	'\0',	0,	0,
}, mtbl[] = {		/* begin with 'm' */
	'a',	matbl,	0,	/* may or march */
	'\0',	0,	0,
}, atbl[] = {		/* begin with 'a' */
	'u',	0,	8,	/* august */
	'p',	0,	4,	/* april */
	'\0',	0,	0,
}, fchr[] = {		/* first character */
	'j',	jtbl,	0,	/* january, june or july */
	'm',	mtbl,	0,	/* march or may */
	'a',	atbl,	0,	/* april or august */
	'f',	0,	2,	/* february */
	's',	0,	9,	/* september */
	'o',	0,	10,	/* october */
	'n',	0,	11,	/* november */
	'd',	0,	12,	/* december */
	'\0',	0,	0,
};

static int
findmonth(str)
	char	*str;
{
	register char	*cp = str;
	register	mno;
	register struct	mtab	*tbl;
	register	n;

	tbl = fchr;
	while (*cp) {
		if (isupper(*cp))
			*cp = tolower(*cp);
		cp++;
	}
	for (cp = str, mno = n = 0; !mno && tbl[n].kc; n++) {
		if (*cp == tbl[n].kc) {
			if (tbl[n].ntbl) {
				tbl = tbl[n].ntbl;
				n = -1;	/* voids the n++ above */
			} else {
				mno = tbl[n].mno;
			}
			cp++;	/* advance to next letter */
		}
	}
	return mno;
}
#ifdef notdef
struct tzone {
	char	*z_nam;
	int	z_hour;
	int	z_min;
};
struct tzone zonetab[] = {
     {  "GMT",   0,       0,    },
     {  "NST",  -3,     -30,    },
     {  "AST",  -4,       0,    },
     {  "ADT",  -3,       0,    },
     {  "EST",  -5,       0,    },
     {  "EDT",  -4,       0,    },
     {  "CST",  -6,       0,    },
     {  "CDT",  -5,       0,    },
     {  "MST",  -7,       0,    },
     {  "MDT",  -6,       0,    },
     {  "PST",  -8,       0,    },
     {  "PDT",  -7,       0,    },
     {  "YST",  -9,       0,    },
     {  "YDT",  -8,       0,    },
     {  "HST", -10,       0,    },
     {  "HDT",  -9,       0,    },
     {  "BST", -11,       0,    },
     {  "BDT", -10,       0,    },
     {  "Z",     0,       0,    },
     {  "A",    -1,       0,    },
     {  "M",   -12,       0,    },
     {  "N",     1,       0,    },
     {  "Y",    12,       0,    },
     {  0                       }
 };

/* adjust for timezone */
static time_t
adjtime(tyme, tz)
	time_t	tyme;
	char	*tz;
{
	register	i;
	register	adj = 0;

	for (i = 0; !adj && zonetab[i].z_nam; i++) {
		if (! strcmp (tz, zonetab[i].z_nam)) {
			adj = (zonetab[i].z_hour * 60 + zonetab[i].z_min) * 60;
		}
	}
	return (tyme - adj);
}
#endif notdef
