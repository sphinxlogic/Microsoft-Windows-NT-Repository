#ifndef lint
static char rcsid[] =
	"$Header: mark.c,v 1.2 86/02/16 15:08:35 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif lint

/*
 * routines for tracking vi-style marks
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/mark.c,v $
 * $Revision: 1.2 $
 * $Author: deboor $
 *
 * FUNCTIONS:
 *	cmdSetMark	set a mark at the current message
 *	cmdToMark	set cursor to the another message
 *	getMark		get the value of a mark
 *	initmarks	initialize the marks of a folder
 *	setMark		set the value of a mark
 */

#include "vmh.h"

/*
 * cmdSetMark()
 *	gets a single character through the top window and calls setMark()
 *	to actually set the mark in the folder.
 */
/*ARGSUSED*/
cmdSetMark(count, undo, argc, argv)
	int	count,
		undo,
		argc;
	char	**argv;
{
	int	c;
	int	*msgs;

	if (FEmpty(F)) {
		errormsg ("Can't mark in an empty folder!",1);
		return;
	}
		
	msgs = GetMessages (&count);

	if (count > 1) {
		errormsg ("can only mark one message!",1);
		return;
	}
	
	if (argc)
		c = **argv;
	else
		c = mygetch (topWin);

	if (c < 'a' || c > 'z') {
		errormsg ("mark must be a lowercase letter", 1);
		return;
	}
	setMark (c, *msgs);
}

/*
 * cmdToMark()
 *	reads a single character through the top window and sets the message
 *	marked by that character to be the current message.
 */
cmdToMark()
{
	char	c;
	int	newcur;

	if (FEmpty (F)) {	
		errormsg ("no marks in an empty folder", 1);
		return;
	}
	c = (char) mygetch (topWin);

	if ((c < 'a' || c > 'z') && c != '\'') {
		errormsg ("mark must be a lowercase letter or '", 1);
		return;
	}
	newcur = getMark (c);
	if (newcur == 0) {
		beep();
		return;
	}
	cmdGo (newcur);
}

/*
 * setMark (label, msg) char label; int msg;
 *	marks the message given by msg with the label given by label
 *	in the current folder F.
 */
setMark (label, msg)
	char	label;
	int	msg;
{
	if (label == '\'')
		F->f_marks[26] = msg;
	else
		F->f_marks[label-'a'] = msg;
}

/*
 * getMark (label) char label;
 *	returns a the message number marked by label. 0 is returned
 *	if no message is marked by the given label.
 */
getMark (label)
	char	label;
{
	return ((label == '\'') ? F->f_marks[26] : F->f_marks[label-'a']);
}

/*
 * initmarks (f) FLDR *f;
 *	initialize the f_marks array in the folder f.
 */
initmarks (f)
	FLDR	*f;
{
	Bzero (f->f_marks, sizeof(f->f_marks));
}
