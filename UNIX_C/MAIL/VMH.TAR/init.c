#ifndef lint
static char rcsid[] =
	"$Header: init.c,v 2.14 88/01/13 19:07:21 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif

#include "vmh.h"

/*
 * initialization routines.
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/init.c,v $
 * $Revision: 2.14 $
 * $Author: deboor $
 *
 * FUNCTIONS:
 *	DeBuG		debug file output routine
 *	initprofile	initialize all profile entries
 *	initstuff	main initialization routine
 *	scanopts	parse command line options
 *	set_topSize	set size of top-most window (-scanwindow support)
 */

/* Initialization and exit routines */

int  goodbye();
int  sigwinch();

char editorstr[50];             /* Strings for favorite editor and */
char pagerstr[50];              /* display program names */
char SeqNegate[20];		/* sequence-negation string */

#ifdef MH6
char UnseenSequence[50],
     MHSequences[50];
#endif MH6

char *version;			/* for -help */

struct	sgttyb	ttyb;             /* Contains erase and kill characters */
struct	tchars	chars;            /* New tchars array */
struct	ltchars	lchars;		  /* local characters, whatever the hell that means */
char		bs;		  /* character erase */
char		litnext;	  /* initial literal next character */
char		werasec;
char		killc;		  /* line kill */
char		dsuspc;		  /* delayed suspend */
char		quit;		  /* interrupt */
char		start;		  /* flow start */
char		stop; 		  /* flow stop */
int		auto_clear;
int		Dbg = 0;
int		init_tty_mode;
int		new_tty_mode;
char		byestring[80];
char		**ignores = 0,
		**retains = 0;

initstuff(folder)
	char	*folder;
{
	char		folderstr[PATHLENGTH];  /*Full folder pathname */
	long		tostop = LTOSTOP;	/* for TIOCLBIS */
	
	extern char	*progname;
	extern FLDR	*FHead;		/* head of folder chain */
	

	(void) Ioctl(0, TIOCGETP, &ttyb);      /* Get character profiles */
	(void) Ioctl(0, TIOCGETC, &chars);     /* Get new characters */
	(void) Ioctl(0, TIOCGLTC, &lchars);
	(void) Ioctl(0, TIOCLBIS, &tostop);	/* force tostop so backgrounding works */
	bs	= ttyb.sg_erase;	/* Get backspace character */
	killc	= ttyb.sg_kill;		/* kill for mywgetstr() */
	werasec	= lchars.t_werasc;	/* werase for " */
	quit	= chars.t_intrc;	/* Get interrupt key too */
	litnext	= lchars.t_lnextc;	/* and literal-next character */
	dsuspc	= lchars.t_dsuspc;	/* for oldtty(). ^Y is turned off */
	start   = chars.t_startc;
	stop    = chars.t_stopc;

	bvShowScan = 0;                 /* reset show-info needed flag */
	initscr();                      /* initialize the screen (curses) */
	/*
	 * this is needed when the second entry in the terminal name
	 * field of the termcap entry is > 10 characters long. curses
	 * blithely copies it over the saved tty modes and leaves the
	 * terminal totally f'ed up on exit. sigh. it's being changed...
	 * --ardeb
	 */
	/* make sure modes aren't brain-damaged */
	if (! UPPERCASE && (_tty.sg_flags & LCASE)) {
		_tty.sg_flags &= ~ (LCASE);
		(void) stty (_tty_ch, &_tty);
	}
	if (CM == 0)                    /* If no cursor positioning? */
	{
		printf("Unusable terminal type: '%s' ", getenv("TERM"));
		printf("(no cursor motion ability).\n");
		printf("Check your TERM environment variable.\n");
		exit(1);                /* Not far enuf for punt() yet */
	}
	nonl();

#ifdef SIGTSTP
	(void) signal(SIGTSTP, SIG_DFL);       /* Undo damage done in initscr */
#endif
	(void) signal (SIGQUIT, goodbye);	/* quit gracefully */
#ifdef SIGWINCH
	(void) signal (SIGWINCH, sigwinch);
#endif

	set_biff_mode();
	newtty();                       /* Set vmh tty parms & signals */

	fdreserved = dup(0);            /* Spare fd for updatefolder */
	FHead = NULL;                   /* Init chain of folders */

	buildwins();                    /* Build my windows */
	startwatch();                   /* Fire up the mailwatch daemon */
	startclock();			/* and the clock */
	if (getpath(folder, folderstr, sizeof(folderstr)) !=0)
	{       char msg[100];
		perror (folderstr);
		(void) sprintf(msg, "Hm, '%s' is giving me some problems.",
			folderstr);
		punt(msg);
	}
	wclear (cmdWin);
	infomsg(version, 0);   /* Put up version number msg */
	dofolder(folderstr);
	init_stack();		/* initialize folder stack */
	dotitle (botHdr, HELPMSG);
}


/* Read in profile once, rather than each time needed */
/* reads the auto-clear, goodbye, retain and ignore entries. */

initprofile()
{
	register char	*cp;
	register	q;
	char		junk[1024];
	extern char	*nsequence;	/* in config.o */
#ifdef MH6
	extern char	*usequence;	/* in config.o */
#endif MH6

	cp = getenv ("VISUAL");
	if (cp != NULL) {
		(void) strncpy (editorstr, cp, sizeof(editorstr));
	} else if ((cp = getenv("EDITOR")) != NULL) {
		(void) strncpy(editorstr, cp, sizeof(editorstr));
	} else {
		(void) strcpy(editorstr, EDITOR);    /* else compile def */
	}


	cp = getenv("SHOWPROC");
	if (cp != NULL)
		(void) strncpy(pagerstr, cp, sizeof(pagerstr));
	else
	    if (readprofile("showproc:", pagerstr, sizeof(pagerstr)) != 1)
			(void) strcpy(pagerstr, PAGE);

	if (readprofile (nsequence, SeqNegate, sizeof (SeqNegate)) != 1)
		(void) strcpy (SeqNegate, "not");	

#ifdef MH6
	if (readprofile(usequence, UnseenSequence, sizeof(UnseenSequence)) != 1)
		*UnseenSequence = '\0';
	else {
	}

	if (readprofile("mh-sequences:", MHSequences, sizeof (MHSequences)) !=1)
		strcpy (MHSequences, mh_seq);
#endif MH6

	(void) Ioctl (0, TIOCGETP, &ttyb);

	if (ttyb.sg_ospeed <= B1200)	/* if we're at 1200 baud or lower */
		terse = auto_clear = 1;		/* default to auto-clear and terse */
	else
		terse = auto_clear = 0;		/* else no-auto-clear and no terse */

	mailinterval.tv_sec = WATCHINTERVAL;

	retains = ignores = (char **) 0;

}


WINDOW	*topHdr,
	*botHdr,
	*topWin,
	*botWin,
	*cmdWin,
	*mailWin,
	*clockWin;

int	topSize = 0,
	botSize;

/*
 * set_topSize(str) 
 *	figure out how many rows the top window should have based on the string
 *	in str. If str is non-null, a copy of it is made for later use. If
 *	str is NULL, the previously-saved copy is used. str will be NULL
 *	when this function is called from rebuild_windows().
 */
set_topSize (str) char *str;
{
	static char *spec = (char *)NULL;   /* spec as passed to first call */
	int	top_num,
		top_den;

	if ((str == (char *)NULL) && (spec != (char *)NULL)) {
		str = spec;
	} else if (str != (char *)NULL) {
		spec = newstr(str);
	}

	if (str == (char *)NULL) {
		/*
		 * If called when rebuilding windows and no specific size
		 * was given, nuke the size we determined in buildwins()
		 * so it can figure it out again.
		 */
		topSize = 0;
	} else if (index (str, '/')) {
		/*
		 * String is a fraction-of-the-screen specification, so
		 * figure it out from there...
		 */
		(void) sscanf (str, "%d/%d", &top_num, &top_den);
		topSize = (LINES * top_num) / top_den;
	} else {
		/*
		 * String must be an absolute number of rows
		 */
		(void) sscanf( str, "%d", &topSize );
	}
}

buildwins()
{
	char		hm_top[60];
	/*
	 * clock looks like this: 'hh:mm ap ' where 'h' is an hour digit, 'm' is
	 * a minute digit and 'ap' is either 'am' or 'pm'. the space is to wipe
	 * out when we go from double digit hour to single digit 
	 */
	register	clockwidth = sizeof("hh:mm ap ") - 1;
	register	mailwidth =  sizeof("*** New Mail ***") - 1;
	register	topwidth;

	if (! topSize) {
			topSize = (LINES-1)/3;/* Two lines header, take third */
	}
	if( topSize < 3 || topSize > LINES - 3 )
		punt( "scanwindow size too small");
	botSize = (LINES-1)-topSize-1;  /* Leave one more at bottom */
	topwidth = COLS - clockwidth - mailwidth;

	delwin(stdscr);         /* free up some memory */
	stdscr = (WINDOW *)NULL;
		/* Top line for header */
	topHdr =	newwin(1, topwidth, topSize, mailwidth);
		/* for clock */
	clockWin =	newwin (1, clockwidth, topSize, COLS - clockwidth);
		/* for New Mail message */
	mailWin =	newwin (1, mailwidth, topSize, 0);
		/* Rest of top half */
	topWin =	newwin(topSize, COLS, 0, 0);
		/* Bottom window header */
	botHdr =	topHdr; /*newwin(1, COLS, 1+topSize, 0);*/
		/* main window */
	botWin =	newwin(botSize, COLS, topSize+1, 0);
		/* input window */
	cmdWin =	newwin(1, COLS - 1, topSize+1+botSize, 0);

}

rebuild_windows()
{
	/*
	 * delete old windows and restore the tty state
	 */
	delwin(topHdr);
	delwin(clockWin);
	delwin(mailWin);
	delwin(topWin);
	delwin(botHdr);
	delwin(botWin);
	delwin(cmdWin);

	oldtty();

	/*
	 * reinitialize the window system and the tty. Note LINES and COLS
	 * must be reset for curses to pick up the new values.
	 */
	LINES = COLS = 0;
	initscr();
	newtty();

	/*
	 * determine top size from initial switch/profile entry
	 */
	set_topSize((char *)NULL);

	/*
	 * rebuild all windows
	 */
	buildwins();

	/*
	 * redisplay clock (idleflag must be set for it to print anything)
	 */
	idleflag = TRUE;
	startclock();
	idleflag = FALSE;

	/*
	 * refresh *** New Mail *** window
	 */
	startwatch();

	/*
	 * redo title window
	 */
	dotitle(botHdr, HELPMSG);

	/*
	 * update display of messages, centering current message in window.
	 * (Note: bvShowScan must be TRUE for update to occur)
	 */
	if (F->f_cur != (INFO *)NULL) {
		F->f_top = i_pre(F->f_cur, topSize / 2);
		F->f_line = i_diff(F->f_top, F->f_cur);
	}
	bvShowScan = TRUE;
	updatetop();
}
/*
** set_biff_mode()
**	sets biff based on the do_biff variable.
*/
set_biff_mode ()
{
	struct	stat	ttystat;
	extern	char	*sys_errlist[];
	extern	int	errno;

	if (fstat (_tty_ch, &ttystat)) {
		perror ("tty");
		punt("");
	}

	init_tty_mode = ttystat.st_mode;

	if (do_biff)
		ttystat.st_mode |= 0100;
	else
		ttystat.st_mode &= ~0100;

	(void) Fchmod (_tty_ch, ttystat.st_mode);
	new_tty_mode = ttystat.st_mode;
}

#ifdef DEBUG
FILE	*DebugFile;
#endif

extern struct swit	switches[];

int	terse = 0,		/* do terse messages/prompting */
	autoinc = 0,		/* automatically incorporate new mail */
	do_size = 0,		/* print size of msg in infowindow */
	do_biff = 0,		/* turn biff on */
	do_page = 0,		/* act like 'page' instead of 'more' */
	autoprint = 0;		/* print next message after deletion or <cr> */
char	*cFold;			/* for main() */

scanopts(argc, argv) int argc; char **argv;
{
	char		buf[BUFSIZ];
	int	ac;
	char	**av;
	
	
	int		profile = 0;
	

	initprofile();
	cFold = (char *) 0;
	def_sequence = (char *) 0;
	format_string = SCANFORMAT;
	if (readprofile (progname, buf, sizeof buf)) {
		av = brkstring (buf, " \t", "\n");
		for (ac=0; av[ac]; ac++)
			;
		ac++, av--;		/* to compensate for ++av below */
		profile = 1;
	}
startinfo:
	if (!profile) {
		ac = argc; av = argv;
	}
	while (--ac > 0 && **++av == '-') {
		++*av;	/* advance past '-' */
		pcsswitch (&av, &ac, 1);
	}

	if (profile) {
		profile = 0;
		goto startinfo;
	}
	if (ac) {
		if (**av == '+')
			++*av;
		cFold = *av;
	} 

}

#ifdef DEBUG
/*VARARGS1*/
DeBuG (fmt, args) char *fmt; int args;
{
	FILE	DbgFile;
	char	DbgBuf[BUFSIZ];

	if (Dbg) {
		DbgFile._flag = _IOWRT | _IOSTRG;
		DbgFile._ptr = DbgBuf;
		DbgFile._bufsiz = DbgFile._cnt = BUFSIZ;
		DbgFile._file = -1;

		(void) _doprnt (fmt, &args, &DbgFile);
		(void) putc ('\0', &DbgFile);

		fputs (DbgBuf, DebugFile);
		(void) fflush (DebugFile);
	}
}
#else
/*VARARGS1*/
/*ARGSUSED*/
DeBuG (fmt) char *fmt;
{
}
#endif
