#ifndef lint
static char rcsid[] =
	"$Header: typeit.c,v 2.13 88/01/13 19:18:37 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif

/*
 * routines for printing files and messages in the bottom window.
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/typeit.c,v $
 * $Revision: 2.13 $
 * $Author: deboor $
 *
 * FUNCTIONS:
 *	cmdType		type message(s) in the bottom window worrying about
 *			headers and paging
 *	typeit		type a file in the bottom window worrying about paging
 */

#include "vmh.h"

/* Type a file in a window */

typeit(filename, win)
	char	*filename;
	WINDOW	*win;
{
	FILE		*fp;
	int		c;
	struct	stat	fstb;
	char		line[132];

	wmove(win, 0, 0);

	Bzero(line,sizeof(line)); /* just in case....:-) */
	fp = fopen(filename, "r");
	if (fp == NULL) {
		errormsg("Can't open file?", 1);
	} else if (fstat (fileno(fp), &fstb) < 0) {
		errormsg ("Can't stat file?", 1);
	} else {
		init_pager (fp, win);
		while(fgets (line, sizeof(line), fp)) {
			if (putstr (line))
				break;
		}
	}
	wrefresh(win);
	if (fp != NULL)
		(void) fclose(fp);
	end_pager();

}

/*
** printheader (line, headerv, which) char *line; char **headerv; int which;
**	returns true if the header in  line  is to be printed. This is decided
**	based on the vector of headers in  headerv  and the value of  which .
**	If  which  is P_RETAIN and the header in  line  is one of those in
**	 headerv , TRUE is returned. If  which  is P_IGNORE and the header is
**	one of those in  headerv , FALSE is returned. If  which  is P_NOTHING,
**	TRUE is always returned.
*/
printheader (line, headerv, which)
	Reg1	char	*line;
	Reg2	char	**headerv;
	int		which;
{
/* If not retaining/ignoring anything, always return true */
	if (which == P_NOTHING) {
		return TRUE;
	}

/* else check for ignores/retains now */
	while (*headerv) {
			/* must prefix and end in ':' */
		if (uprf (line, *headerv) && line[strlen(*headerv)] == ':') {
			break;
		} 
		headerv++;
	}

	/* header is retained */
	return (which == P_RETAIN ? *headerv != NULL : *headerv == NULL);
}

/*
** isdashes (line) register char *line;
**	returns true if the line is nothing but dashes followed by a newline.
*/
static
isdashes (line)
	Reg1 char *line;
{
	while (*line && (*line == '-' || *line == '\n'))
		line++;
	return (! *line);
}

/*
 * cmdType (count) int count;
 *	display messages in the bottom window
 */
cmdType(count, undo)
    int	    	count;
    int	    	undo;
{
    char	filestr[PATHLENGTH];	/* path to message file */
    char	tline[256];
    char	line[2048];	/* maximum header line passed by sendmail is 1024 */
    Reg6 int	*msgs;		/* sequence of messages to show */
    Reg5 int	i;		/* index variable */
    Reg4 char	**headers;	/* headers for retain/ignore logic */
    char 	c;		/* junk char for pause */
    Reg1 int	len;
    Reg3 int	do_retains;	/* flag for retain/ignore */
    Reg2 off_t	header_end;	/* offset to end of headers */
    struct stat	fstb;
    FILE	*mf;
    
    /*
     * To undo a type command is to unsee the messages just typed...
     */
    if (undo) {
	cmdUnseen (count, FALSE);
	return;
    }

    if ((msgs = GetMessages(&count)) == NULL)  /* get the message list */
	return;
    
    /*
     * decide whether to do retain/ignore logic
     * if  retains  is non-null, do retain logic; if
     * retains  is null and  ignores  is non-null, do
     * ignore logic; if both are null, do straight type.
     */
    if (retains) {
	headers = retains;
	do_retains = P_RETAIN;		/* => retain logic */
    } else if (ignores) {
	headers = ignores;
	do_retains = P_IGNORE;		/* => ignore logic */
    } else {
	headers = (char **) 0;
	do_retains = P_NOTHING;	/* => no logic (illogic?) */
    }
    
    for (i = 0; msgs[i]; i++) {
	prt_action (" %s %d ", &F->f_name[rootlen+1], msgs[i]);
	wmove (botWin, 0, 0);
	
	(void) sprintf(filestr, "%s/%d", F->f_name, msgs[i]);
	if ((mf = fopen (filestr, "r")) == NULL) {
	    errormsg ("can't access message!", 1);
	    continue;
	} else if (fstat(fileno(mf),&fstb)<0){/* need to get file-size*/
	    errormsg ("can't fstat message!", 1);
	    (void) fclose (mf);
	    continue;
	}
	/*
	 * initialize header_end to be the end of the file.
	 * continue reading until hit end-of-file
	 */
	init_pager (mf, botWin);
	for (header_end = fstb.st_size; ! feof (mf);) {
	    /* if we're (back) in header area ... */
	    if (ftell (mf) < header_end) {
		/* unfold the beast */
		len = readheader(line,sizeof(line),mf,RH_NL);
		
		if (len > 1 && ! isdashes(line)) {
		    if (printheader(line,headers,do_retains) &&
			(putstr(line)))
			break;
		} else if (len) {/* len ! 0 => ! EOF */
		    /*must be \n => end of headers*/
		    header_end = ftell (mf);
		    if (putstr (line))
			break;
		}
	    } else {/* message body => straight printing */
		if (! fgets (tline, sizeof(tline), mf) ||
		    putstr(tline))
		    break;
	    }
	}
	(void) fclose (mf);
	end_pager();
	
	wclrtobot(botWin);
	wrefresh (botWin);
	hdrseen(filestr);              /* Mark current msg 'seen' */
	if (msgs[i+1]) {
	    wclear (cmdWin);
	    waddch (cmdWin, ':');
	    c = mygetch (cmdWin);
	    if (c == 'q' || c == 'Q' || c == quit) {
		i++;
		break;
	    }
	}
    }
    scroll_to (msgs[i-1]);
}
