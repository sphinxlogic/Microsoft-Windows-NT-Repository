#ifndef lint
static char rcsid[] =
	"$Header: popen.c,v 2.3 86/02/08 21:03:31 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif
/*
 * Derived from std popen ...
 *   csh instead of sh
 *   send stderr to pipe in addition to stdout
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/popen.c,v $
 * $Revision: 2.3 $
 * $Author: deboor $
 * 
 * FUNCTIONS:
 *	popen	open a pipe to a new shell-created process
 *	pclose	close a previously openned pipe
 */

#include <stdio.h>
#include <signal.h>
#include <sys/wait.h>
#define	tst(a,b)	(*mode == 'r'? (b) : (a))
#define	RDR	0
#define	WTR	1
static	int	popen_pid[20];

FILE *
popen(cmd,mode)
	char	*cmd;
	char	*mode;
{
	int p[2];
	register myside, hisside, pid;

	if(pipe(p) < 0)
		return NULL;
	myside = tst(p[WTR], p[RDR]);
	hisside = tst(p[RDR], p[WTR]);
	if((pid = fork()) == 0) {
		/* myside and hisside reverse roles in child */
		(void) close(myside);
		(void) dup2(hisside, tst(0, 1));
		(void) close(hisside);

		/*** New!  Make stderr go to the pipe also (jdg) ***/
		(void) dup2(1, 2);     /* make stderr(2) same as stdout(1) */

		execl("/bin/csh", "csh", "-c", cmd, 0);
		_exit(1);
	}
	if(pid == -1)
		return NULL;
	popen_pid[myside] = pid;
	(void) close(hisside);
	return(fdopen(myside, mode));
}

pclose(ptr)
	FILE *ptr;
{
	register	f,
			r,
			(*hstat)(),
			(*istat)(),
			(*qstat)();
	union	wait	status;

	f = fileno(ptr);
	(void) fclose(ptr);
	istat = signal(SIGINT, SIG_IGN);
	qstat = signal(SIGQUIT, SIG_IGN);
	hstat = signal(SIGHUP, SIG_IGN);
	while((r = wait(&status)) != popen_pid[f] && r != -1)
		;
	if(r == -1)
		status.w_retcode = -1;
	(void) signal(SIGINT, istat);
	(void) signal(SIGQUIT, qstat);
	(void) signal(SIGHUP, hstat);
	return(status.w_retcode);
}
