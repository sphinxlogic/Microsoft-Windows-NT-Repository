#ifndef lint
static char rcsid[] =
	"$Header: fldr.c,v 2.7 86/10/09 16:01:08 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif

/*
 * Routines that have a lot to do with the fldr structure
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/fldr.c,v $
 * $Revision: 2.7 $
 * $Author: deboor $
 * 
 * FUNCTIONS:
 *	freeF		free all memory used by a folder
 *	getF		find folder structure for a folder
 *	recheckfldrs	check all folders for modification
 *	syncfolders	synchronize in-core folder info with .info files
 */

#include "vmh.h"                 /* Mine */


FLDR	*F,
	*FHead;

/*
 *	get F -- check the F-list for a matching inode, otherwise
 *		build a new one and put it on the list. the folder name
 *		passed	should be an absolute pathname.
 */

FLDR *
getF(folder)
	char	*folder;
{
	struct	stat	sbuf;               /* Sigh, stat done 3 times??? */
	register FLDR	*f;
	

	if (stat(folder, &sbuf) < 0)
		punt("Stat error in getF");

	f = findF(sbuf.st_ino);         /* See if there already */
	if (f != NULL)
		return(f);       /* If exists, return it now */

	f = AllocST(FLDR);   /* Allocate a structure */
	f->f_lock = 1;

	(void) strcpy(f->f_name, folder);	/* Set name of the folder */
	f->f_inode = sbuf.st_ino;       /* Set inode number */
	f->f_mtime = sbuf.st_mtime;	/* then the mod time */
	f->f_modified = 0;		/* unmodified */
	f->f_sequences = (struct seq *)NULL;
	f->f_cur = f->f_top = f->f_bot = (INFO *) 0;	/* Init to NULL for potentially */
	f->f_head = f->f_tail = (INFO *) 0;		/* empty folder */

	f->f_link = FHead;		/* Put at start of list */
	FHead = f;			/* Rest of list after me */

	my_gmsg(f);			/* Build msgs structure */

	readinfo (f);			/* read .info file */

	f->f_modified = 0;		/* unmodified */

	init_sequences (f);		/* read in all the sequences */
					/* (sets f->f_cur, too) */
	initmarks(f);
	
	/*
	 * if non-empty folder, put cur in the center
	 */
	if (!FEmpty(f)) {
		f->f_top = i_pre (f->f_cur, topSize/2 + 1);
	}
	f->f_lock = 0;
	return(f);
}

/*
 *   Search the folder-list for the folder of interest.
 */

FLDR *
findF(inode)
	ino_t	inode;           /* Inode of directory to look for in F cache */
{
	register FLDR *f = FHead;

	while (f != NULL) {
		if (f->f_inode == inode)
			return(f);
		else
			f = f->f_link;
	}
	return((FLDR *)NULL);
}

/*
 * Make sure all the .info disk files match their in-core images
 */

syncfolders()
{
	register FLDR *f;

	set_cur_fold (strncmp(F->f_name, rootpath, rootlen) ? F->f_name :
		&F->f_name[rootlen+1]);

	for (f=FHead; f != NULL; f = f->f_link) {
		if ( ! f->f_lock )
			updatefolder(f);
	}
}

/*
 * If a fldr has been modified, write it back out to disk and
 * reset the modified flag.
 */

int	fdreserved;

updatefolder(f)
	FLDR	*f;
{
	int	chan;
	char	infopath[PATHLENGTH];

	(void) close(fdreserved);              /* Release save'd fd */


	dump_sequences (f);		/* write out the sequences */

	if ( f->f_modified ) {      /* If the .info file has changed */
		(void) strcat (strcpy (infopath, f->f_name), "/.info");
		(void) unlink(infopath);	/* Delete old .info file */

		chan = creat(infopath, 0600); /* Recreate the file */
		if (chan == -1)              /* creat open'd for write */
			punt("Open error in updatefolder");

		flushinfo (chan, f);

		(void) close(chan);
		f->f_modified = 0;
	}
	fdreserved = dup(0);            /* Reserve spare fd again! */
}


/*
 *  Release all the memory for the fldr structure and take
 *  it off the list.  Does *not* write it out to disk first.
 */

freeF(f)
	FLDR	*f;
{
	FLDR		*fprev;
	struct	seq	*sp;
	struct	seq	*tsp;


	free_sequences (f);

	if (FHead == NULL)      /* If empty list */
		punt("Empty f-list in freeF?");

	if (FHead == f)         /* If first on the list */
		FHead = f->f_link;
	else {
		for (fprev = FHead ;  ; fprev = fprev->f_link) {
			if (fprev == NULL)
				punt("F-list corrupted");
			if (fprev->f_link == f) {
				fprev->f_link = f->f_link;
				break;
			}
		}
	}
	Free ((char *)f);
}

/*
 *   Check to make sure that all the in-core .info files are still
 *   current.  Rebuild and redisplay if necessary.
 */

recheckfldrs()
{
	FLDR	*f,
		*tf;
	int	curflag;            /* True if checking "current" folder */
	struct	stat	sbuf;
	int	switchCur = 0;	/* switch to +inbox if curF is gone */
	char	*inboxV[2];	/* for switch to +inbox */

	for (f=FHead; f != NULL; f = f->f_link)
	{
		curflag = (F == f);     /* true if current folder */

		if (f->f_lock)		/*don't do ANYTHING til it's unlocked */
			continue;
		if (stat(f->f_name, &sbuf) < 0) /* Do the stat */
		{                                        /* If not there, */
			freeF(f);                        /* forget it! */
			if (curflag)                     /* current gone? */
			    switchCur = 1;	/* switch to +inbox when done */
		}
		else if (checkinfo(f))       /* else if there, check .info */
		{
			char name[PATHLENGTH];

			(void) strcpy(name, f->f_name);	/* remember ... */
			freeF(f);                       /* Release old one */
					/* Assumes new f gets put at start! */
			tf = getF(name);        /* Rebuild the f struct */
			if (curflag) {
				F = tf;
				showinfo();
				wrefresh(topWin);
			}
		}
	}
	inboxV[0] = defalt;
	inboxV[1] = (char *) 0;
	if (switchCur)
		cmdSwitch (1, 0, 1, inboxV);
}
