
/************************ Derived from MH ********************************/

#define MAXFOLDER 9999   /* Max number of messages in a folder */
#define DMAXFOLDER 4    /* Number of digits in MAXFOLDER */
char	**brkstring();

/*
 * string constants from MH config.o file.
 */
char	*context,	/* name of context file */
	*defalt,	/* default folder if none current */
	*current,	/* name of 'current message' sequence */
#ifdef MH6
	*mh_profile,	/* default name of profile */
#else
	*mh_prof,	/* default name of profile */
#endif MH6
	*mh_seq,	/* name of public sequence file per folder */
	*pfolder;	/* component for current folder in context file */

#define AMBIGSW	(-2)	/* ambiguous switch from smatch()	*/
#define UNKWNSW (-1)	/* unknown switch from smatch()		*/

struct	swit	{
	char	*str;
	int	minchars;
};
