#ifndef lint
static char rcsid[] =
	"$Header: msgs.c,v 2.7 88/01/13 19:09:39 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif

/*
 * routines for handling/creating/initializing MSGS structures.
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/msgs.c,v $
 * $Revision: 2.7 $
 * $Author: deboor $
 *
 * FUNCTIONS:
 *	GetMessages	returns the sequence of messages on which a command
 *			should act.
 *	add_new_msgs	adds new messages to a folder in a sickeningly tight
 *			loop.
 *	my_gmsg		build a folder's MSGS structure
 *	scroll_to	move cursor to the given message.
 */
#include "vmh.h"
#include <sys/dir.h>
#include <sys/file.h>

/**/
/*  Look through a folder (complete path name is input)
/*  Alloc a 'struct msgs' structure and fill it in with
/*  with such things as what the low, high, and current messages are.
/*  Return a pointer to this structure (punts if out of memory).
/**/

my_gmsg(f)
	Reg3	FLDR	*f;
{
	Reg4	DIR		*dp;     /* Directory stream handle */
	Reg2	struct direct	*d;       /* A directory entry */
	Reg1	int		j;       /* loop */

	if((dp = opendir(f->f_name)) == NULL)
		punt("Mygmsg: Can't open folder!");
						/* could stat to check dir */
						/* but since we're punting... */
	Bzero ((char *)f->f_msgs.m_msgstats, sizeof (f->f_msgs.m_msgstats));

	f->f_msgs.m_hghmsg = f->f_msgs.m_nummsg = 0;
	f->f_msgs.m_lowmsg = MAXFOLDER+100;         /* Some big number */

	for ( ; ; )             /* Loop over directory */
	{
		register char	*cp;

		d = readdir(dp);
		if (d == NULL)		/* end of directory */
			break;
		/*
		 * now whirl through the name, making a number as we go
		 */
		for (j = 0, cp = d->d_name; *cp && isdigit (*cp);)
			j = j * 10 + *cp++ - '0';

		if (*cp || j > MAXFOLDER || !j )
			continue;	/* must not have been all number */
		
		f->f_msgs.m_nummsg++;       /* Additional msg */
		Add_Msg (j, &f->f_msgs);
		if (j < f->f_msgs.m_lowmsg)
			f->f_msgs.m_lowmsg = j;
		if (j > f->f_msgs.m_hghmsg)
			f->f_msgs.m_hghmsg = j;
	}

	if (f->f_msgs.m_hghmsg == 0)
		f->f_msgs.m_lowmsg = 0;
	(void) closedir(dp);           /* Close the directory */
#ifdef DEBUG
	DeBuG("my_gmsg: hghmsg = %d lowmsg = %d nummsg = %d\n",
		f->f_msgs.m_hghmsg,f->f_msgs.m_lowmsg,f->f_msgs.m_nummsg);
#endif DEBUG
}

/*
** add_new_msgs(f) register FLDR *f;
**	does a tight loop checking access on all messages with numbers
**	greater than f->f_msgs.m_hghmsg until it finds one it can't read. For
**	each message it can read, it adds the message's number to the msgs
**	structures and continues. This function is used by cmdInc to find
**	the numbers of the newly incorporated messages.
**	Isn't it sick?
*/
add_new_msgs (f)
	Reg3	FLDR *f;
{
	char		path[PATHLENGTH];
	Reg2	char	*cp;
	Reg1	int	i;
	
	(void) strcpy (path, f->f_name);
	cp = &path[strlen(path)];
	for (i = f->f_msgs.m_hghmsg + 1; i <= MAXFOLDER; f->f_msgs.m_nummsg++, i++) {
		(void) sprintf (cp, "/%d", i);
		if (access (path, R_OK))
			break;
		Add_Msg (i, &f->f_msgs);
	}
	f->f_msgs.m_hghmsg = i - 1;
}


/*
 * GetMessages (count) int *count;
 *	returns an null-terminated array of  count  messages. If  count  is
 *	negative, the previous  count  messages are returned. If it is positive,
 *	the next  count  messages are returned. If an error occurrs, NULL is
 *	returned. *count is set to the number of messages returned (msgs[*count]
 *	== 0).
 *	In addition, the messages gotten are placed in CurSequence so when
 *	undoing something, all that cmdUndo needs to do to get the exact
 *	messages used by the command before is set UseSequence to TRUE.
 *	Pretty cute, huh? Yuck.
 */
int	UseSequence = 0;
int	*CurSequence;

int *
GetMessages ( count )
	int	*count;
{
	Reg2	int	i;
	Reg3	int	j;
	Reg1	int	*msgs;
	int		msgno;

	if (UseSequence) {
#ifdef DEBUG
		DeBuG ("GetMessages: UseSequence set; returning: ");
		for (i = 0; CurSequence[i]; i++)
			DeBuG ("%d ", CurSequence[i]);
		DeBuG("\n");
#else
		for (i = 0; CurSequence[i]; i++)
			;
#endif DEBUG
		*count = i;
		return (CurSequence);
	}

	msgs = (int *)Calloc (((*count< 0) ? -*count : *count) + 1, sizeof (int));

	if ((msgno = CurrentMsgNum()) < 0) {
		Free ((char *)msgs);
		return (NULL);
	}

	if (*count < 0) {
		*count = -*count;
		for (i = msgno, j = 0; j < *count && i > 0; i--)
			if (Exists (i,&F->f_msgs)) {
				msgs[j++] = i;
			}
		msgs[j] = 0;
	} else {
		for (i = msgno, j = 0; j < *count && i <= F->f_msgs.m_hghmsg; i++)
			if (Exists (i, &F->f_msgs))
				msgs[j++] = i;
		msgs[j] = 0;
	}
	CurSequence = msgs;	/* set it for docmds() */
	*count = j;	/* just in case */
	return (msgs);
}

/*
** scroll_to (message) int message;
**	scrolls the current folder display so that the given message number is
**	in the center, if possible. If there are too few messages in the folder,
**	the display is positioned at the beginning of the folder.
*/
scroll_to (message)
	int	message;
{
	INFO	*ss;
	int	diff;

	if (!F->f_cur)
		return;
	ss = findinfoS (message, F);
	if (ss == F->f_cur) {
	    /* Do nothing if didn't go anywhere */
	    return;
	}

	diff = i_diff (F->f_top, ss);
	if (diff < 0 || diff >= topSize) {
		F->f_top = i_pre (ss, topSize/2); /* set cur in mid-window */
	}
	F->f_cur = ss;
	F->f_line = i_diff (F->f_top, F->f_cur);
	bvShowScan = 1;
}
