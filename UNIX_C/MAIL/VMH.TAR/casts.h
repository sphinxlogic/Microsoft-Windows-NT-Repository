/*
 * this is a file to overcome the stupidity of llib-lc and other
 * things. It simply casts the arguments of the various functions
 * to what lint expects them to be. sick but necessary.
 *
 * $Author: deboor $ $Date: 86/02/16 23:00:51 $
 */
#define Ioctl(d, r, p)	ioctl ((int) (d), (int) (r), (char *) (p))
#define Fseek(f, o, p)	fseek ((FILE *)(f), (long) (o), (int) (p))
#define Bcopy(s, d, l)	bcopy ((char *) (s), (char *) (d), (int) (l))
#define Bzero(a, l)	bzero ((char *) (a), (int) (l))
#define Fchmod(f, m)	fchmod ((int) (f), (unsigned short) (m))
#define Setitimer(w, v, ov)	setitimer ((int) (w),\
				(struct itimerval *)(v), \
				(struct itimerval *)(ov))
#define Realloc(p, s)	realloc ((char *) (p), (unsigned) (s))
