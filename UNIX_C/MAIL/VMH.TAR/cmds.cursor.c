#ifndef lint
static char rcsid[] =
	"$Header: cmds.cursor.c,v 2.8 88/01/13 18:52:34 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif

/*
 * Commands which move the cursor.
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/cmds.cursor.c,v $
 * $Revision: 2.8 $
 * $Author: deboor $
 *
 * FUNCTIONS:
 *	beep		ring terminal bell
 *	cmdBot		go to bottom of passed folder (used by cmdInc)
 *	cmdBottom	go to bottom of current folder
 *	cmdDown		move cursor down
 *	cmdExposebot	bring one line up at bottom w/o shifting cursor
 *	cmdExposetop	bring one line down at top w/o shifting cursor
 *	cmdGo		go to a message w/ 0 moving to end
 *	cmdHalfdown	scroll top window down a half page
 *	cmdHalfup	scroll top window up a half page
 *	cmdHome		place cursor at top of top window
 *	cmdNext		type next message
 *	cmdOffice	place cursor at bottom of top window (opposite of Home)
 *	cmdPgminus	scroll back an entire page
 *	cmdPgplus	scroll forward an entire page
 *	cmdTop		move cursor to top of folder
 *	cmdUp		move cursor up a line
 *	cmdgo		go to a message w/ 0 moving to beginning
 *	vmh_scroll	scroll top window given # of lines
 */

#include "vmh.h"

#define PGSIZE  topSize         /* Page size for scrolling */

/*
 * cmdUp(count) int count;
 *	This is really like doing a down-cursor with a negative count,
 *	so act that way.
 */
cmdUp(count)
	int	count;
{
	cmdDown(-count);
}

/*
** cmdNext (count) int count;
**	move to the count'th next message and print it.
*/
cmdNext (count)
	int	count;
{
	int	cur = CurrentMsgNum();

	cmdDown (count);
	if (F->f_cur->i_mnum != cur)
		cmdType (1, 0, 0, (char **) 0);
	else
		errormsg ("no next message.", 1);
}

/*
** cmdDown (count) int count;
**	move the current message down  count  messages.
*/
cmdDown(count)
	int	count;
{
	register INFO	*ss;
	int		diff;

	ss =	i_post (F->f_cur, count);	/* get new cur's info structure */
	diff =	i_diff (F->f_top, ss);		/* find difference from top */
	if (ss == F->f_cur) {
		beep();
	}

	if (diff >= 0 && diff < topSize) {    /* If w/in window */
		F->f_cur = ss;           /* just set cur & redisplay */
		F->f_line = diff;
		/*bvShowScan = 1; updatetop now setup to move the + */
		/* without redisplaying the whole window, so...*/
	} else
		vmh_scroll(count);   /* else try to scroll screen */

}

/*
** cmdHome()
**	set cur to be the top message in the window
*/
cmdHome()
{
	F->f_cur = F->f_top;
	F->f_line = 0;
		/*bvShowScan = 1; why was this needed??? */
}

/*
** cmdOffice()
**	This is the opposite of cmdHome, hence its name.
**
**	Sorry about that...
*/
cmdOffice()
{
	F->f_cur = F->f_bot;
	F->f_line = i_diff (F->f_top, F->f_bot);
		/*bvShowScan = 1; how about this one??? */
}

/*
** cmdTop()
**	make first message in folder be current message
*/
cmdTop()
{
	/* test for empty folder then make sure not there already */
	if (! FEmpty(F) && (F->f_top != F->f_head)) {
		F->f_cur = F->f_top = F->f_head;
		bvShowScan = 1;
	}
}

/*
 *   Position screen to bottom of the info listing.  Put last
 *   line in the middle of the window and the cursor on the
 *   last line.  (ala emacs).
 */
cmdBot()
{       
	cmdBottom(F);
}

cmdBottom(f)            /* Split apart so newmail can use us too */
register FLDR	*f;
{
	f->f_top = i_pre (f->f_tail, topSize/2 + 1);	/* makes cur be in the middle */
	f->f_cur = f->f_tail;
	bvShowScan = 1;
}

/*
** cmdPgplus( count ) int count;
**	scroll the display forward  count  pages of messages.
*/
cmdPgplus( count )
	int	count;
{
	INFO	*ss = F->f_cur;

	vmh_scroll(PGSIZE * count);
	if (F->f_cur == ss)
		beep();
}

/*
** cmdPgminus (count) int count;
**	scroll the display back  count  pages of messages.
*/
cmdPgminus( count )
	int	count;
{
	vmh_scroll(-PGSIZE * count);
}

/*
** vmh_scroll(delta)
**	scrolls the message display  delta  lines, optimizing this
**	by using mydeleteline if the change is only one line up or down.
**	positive delta's cause forward scrolls, negative deltas cause
**	backward scrolls.
*/
vmh_scroll(delta)
	Reg2	int	delta;
{
	Reg1	FLDR	*curF = F;
	INFO		*oldtop = F->f_top;

	if (FEmpty (curF))
		return;     /* Nop if empty folder */

	/* NOTE: i_post handles any attempts to go beyond folder limits */
	curF->f_top = i_post (curF->f_top, delta);
	curF->f_cur = i_post (curF->f_cur, delta);
	curF->f_bot = i_post (curF->f_top, topSize - 1);

	/*set y-coord of current line */
	curF->f_line = i_diff (curF->f_top, curF->f_cur);

					/* Try to speed things up */
	switch (i_diff (curF->f_top, oldtop)) {
		case -1:	/* one line down, can be done w/mydeleteline */
			scrollup(topWin); break;
		case 1:			/* one line up, do w/mydeleteline */
			scrolldown(topWin); break;
		case 0:
			return;
	}
	bvShowScan = 1;
}


/*
** cmdExposebot(count)
**	bring  count  lines up from below the current screen w/o changing
**	the current message, if this doesn't cause the current msg to scroll
**	of the screen. The top message becomes the current if old current
**	is gone and count is positive, else the bottom message becomes the
**	current message (if the old current is gone, that is).
*/
cmdExposebot(count)
	int	count;
{
	INFO	*tcurline = F->f_cur;	/* save current line */
	int	diff;

	if (count > 0 && F->f_bot == F->f_tail) {
		beep(); return;
	} else if (count < 0 && F->f_top == F->f_head) {
		beep(); return;
	}
	vmh_scroll (count);

	diff = i_diff (F->f_top, tcurline);
	if (diff >= 0 && diff < topSize)
		F->f_cur = tcurline;	/* restore if feasible */
	else
		F->f_cur = (count < 0) ? F->f_bot : F->f_top;
}

/*
** cmdExposetop(count)
**	brings a line down from above. uses cmdExposebot w/a negative count.
**	simple.
*/
cmdExposetop (count)
	int	count;
{
	cmdExposebot (-count);
}

/*
** cmdHalfup(count)
**	scrolls scan window up a half page. i.e. more higher-numbered
**	messages show up.
*/
cmdHalfup (count)
	int	count;
{
	INFO	*ss = F->f_cur;

	vmh_scroll ((PGSIZE/2)*count);
	if (F->f_cur == ss)
		beep();
}

/*
** cmdHalfdown (count) int count;
**	just the opposite of cmdHalfup and implemented that way.
*/
cmdHalfdown (count)
	int	count;
{
	cmdHalfup(-count);
}

/*
** beep()
**	"ring" the terminal "bell." If the terminal has a 'visible bell'
**	capability, use it to complain. Else if it uses some other character
**	than ^G to beep, issue that string. Otherwise, just print a ^G.
*/
beep()
{
	if (VB && *VB) {
		_puts (VB);
	/*} else if (BL && *BL) {    seems curses doesn't get this one --ardeb
		_puts (BL); */
	} else {
		_putchar('\007');
	}
}

/*
 * cmdGo (message) int message;
 *	go to the given message. If message is 0, it goes to the end of
 *	the folder.
 */
cmdGo (message)
	int	message;
{
	INFO	*newcur;

	if (FEmpty (F))
		return;

	if (message == 0)
		newcur = F->f_tail;
	else
		newcur = findinfoS (message, F);

	if (! newcur)
		return;

	/*
	 * if message is onscreen, just change cur and the line number
	 */
	if (newcur->i_mnum >= F->f_top->i_mnum &&
		newcur->i_mnum <= F->f_bot->i_mnum) {
		F->f_cur = newcur;
		F->f_line = i_diff (F->f_top, newcur);
	} else {
		/*
		 * else actually scroll to the new message
		 */
		scroll_to (newcur->i_mnum);
	}
}

/*
** cmdgo (message) int message;
**	makes 'message' the current message.
*/
cmdgo (message)
	int	message;
{
	scroll_to (message);
}

