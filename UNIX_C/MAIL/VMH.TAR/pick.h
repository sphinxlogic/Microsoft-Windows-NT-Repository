/*
 * definitions for files which implement the 'pick' function:
 *	cmds.pick.c, parsesbr.c, picksbr.c searchsbr.c
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/pick.h,v $
 * $Revision: 1.2 $ $Date: 86/02/27 16:17:39 $
 * $Author: deboor $
 *
 */

#undef bool	/* damn curses */

/*
 * TYPEDEFS
 */
typedef	int	offsets[256], *offsetsP;	/* boyer-moore offset array */

typedef	enum	{ and, or, not, body, header, after, before, leftP } nodeT;
typedef	enum	{ true, false } bool;
typedef enum	{ in_header, in_body, at_eof } whereT;

typedef struct {		/* for passing dates around */
	int	day,
		month,
		year;
} DATE;

typedef	struct	_node {	/* expression tree node */
	nodeT		n_which;	/* type of node */
	int		n_value;	/* value for this subtree */
	bool		n_done;		/* subtree completely evaluated */
	union {
		struct {	/* pattern matching */
			char	*nck_key1;	/* first search key */
			offsets	nck_key1offs;	/* b-m offsets for key 1 */
			char	*nck_key2;	/* second search key */
			offsets	nck_key2offs;	/* b-m offsets for key 2 */
		} nc_keys;
#define n_key1		n_criterion.nc_keys.nck_key1
#define n_key1offs	n_criterion.nc_keys.nck_key1offs
#define n_key2		n_criterion.nc_keys.nck_key2
#define n_key2offs	n_criterion.nc_keys.nck_key2offs
		struct {	/* date matching */
			int	ncd_day,	/* day restriction */
				ncd_month,	/* month restriction */
				ncd_year;	/* year restriction */
		} nc_date;
#define n_day	n_criterion.nc_date.ncd_day
#define n_month	n_criterion.nc_date.ncd_month
#define n_year	n_criterion.nc_date.ncd_year
	} n_criterion;
	struct	_node	*n_left,	/* tree pointer: left child */
			*n_right;	/* tree pointer: right child */
} NODE;

#define NILNODE		(NODE *) NULL

#undef TRUE
#undef FALSE

/*
 * the three states in which n_value can be:
 */
#define TRUE		1	/* if node evaluated and satisfied */
#define FALSE		0	/* if node evaluated and found lacking */
#define UNKNOWN		-1	/* if node hasn't been evaluated yet */

/*
 * common variables
 */
extern	NODE	*expRoot;	/* picksbr: root of expression tree */
extern	bool	dateGiven;	/* picksbr: date given as criterion */
extern	bool	searchBody;	/* picksbr: 'search' given as criterion */

extern	char	*Cmd;		/* cmds.pick: command to apply to sequence */
extern	char	*seqName;	/* cmds.pick: name of sequence to fill */
extern	bool	zeroSeq;	/* picksbr: zero sequence before filling */


extern	char	*headers[];	/* picksbr: array of headers to look for */

extern	int	*doPick();
