#ifndef lint
static char rcsid[] =
	"$Header: clock.c,v 1.6 88/01/13 18:48:52 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif lint

/*
 * This file contains routines for playing with the clock display.
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/clock.c,v $
 * $Revision: 1.6 $
 * $Author: deboor $
 *
 * FUNCTIONS:
 *	DoTimeMsg	Print current time in time window
 *	holdclock	suspend clock updates (nop)
 *	startclock	restart clock
 * 
 */

#include "vmh.h"

int	noClock = 0;	/* do or don't display time. */

/*
** DoTimeMsg()
**	must be separate because there's no separate window for the clock (sigh)
**	Now has separate window!!!
*/
DoTimeMsg()
{
	register char		*AmPm;
	time_t			time();
	time_t			tbuf;
	register struct tm	*t;
	int			_putchar();	/* from curses */
	static	int		initialized = 0;
	register		oldx,
				oldy;

	if (((!idleflag || noClock) && initialized) || no_tty) {
		/*
		 * Reasons not to display time:
		 *	The user has turned off the clock and something's in
		 *	    that window.
		 *	We don't have control of the terminal
		 *	We aren't waiting for command input.
		 */
		return;
	}

	oldx = curscr->_curx;		/* to preserve cursor position */
	oldy = curscr->_cury;

	tbuf = time((time_t *)0);
	t = localtime(&tbuf);
	if (t->tm_hour < 12) {
		AmPm = "am";
		if (t->tm_hour == 0) t->tm_hour = 12;
	} else {
		AmPm = "pm";
		if (t->tm_hour > 12) t->tm_hour -= 12;
	}

	wmove(clockWin, 0, 0);
	/*
	 * if this is the first time through and there's no clock, we fill
	 * the window with dashes to keep it from looking funny...
	 */
	if (!noClock) {
		wprintw (clockWin, "%2d:%02d %s-", t->tm_hour, t->tm_min, AmPm);
	} else {
		waddstr (clockWin, "---------");
	}
	wrefresh (clockWin);
	tputs ( tgoto (CM, oldx, oldy), 1, _putchar);
	curscr->_curx = oldx;
	curscr->_cury = oldy;
	(void) fflush (stdout);		/* just in case */
	initialized = 1;
}

holdclock ()
{
}

/*
** startclock ()
**	called from initstuff() and by the system. when initstuff() calls, it
**	calls with a 0, but the system will pass the number of the signal,
**	which will be non-zero. Isn't this a neat hack? If it is the initial
**	time (not notinit), the timer is started and life goes on with the
**	putting up of the current time, else the time is put up and things
**	return.
*/
startclock ()
{
	DoTimeMsg ();
}

