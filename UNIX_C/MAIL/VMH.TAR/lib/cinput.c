# ifndef lint
static char rcsid[] = "$Header: cinput.c,v 1.3 85/12/03 15:59:29 deboor Exp $";
# endif

/*LINTLIBRARY*/

# include <sys/types.h>
# include <curses.h>

/*
** this is a file of routines to substitute for curses' idiotic
** input routines.
** 
** wgetch will read one character from the given window in CBREAK mode
**	and echo it on the screen, if necessary.
**
** wgetstr will read an entire line from the given window into the
**	given string, which is assumed to be long enough to hold it.
**	it does kill and erase processing (well, backspacing, anyway)
**	but not erase word. yet.
**	NOW IT DOES!!!! --ardeb 10/5/85
**
** sigh.
**
** $Log:	cinput.c,v $
** Revision 1.3  85/12/03  15:59:29  deboor
** I don't know
** 
** Revision 1.2  85/10/11  05:47:12  deboor
** 
** added comments and word erase and got rid of the
** gotos in wgetstr(). looks slick.
** 
** Revision 1.1  85/10/04  23:56:45  deboor
** Initial revision
** 
** Revision 1.1  85/04/17  11:46:10  deboor
** Initial revision
** 
*/

wgetch (win) WINDOW *win;
{
	reg	char	c;
	short		oflags;

	/*
	 * refresh the thing first (gets the cursor where it's wanted)
	 */
	wrefresh (win);	

	/*
	 * save the current tty modes
	 */
	oflags = _tty.sg_flags;

	/*
	 * then set it into cbreak noecho mode...always
	 */
	_tty.sg_flags |= CBREAK;
	_tty.sg_flags &= ~ECHO;
	ioctl (_tty_ch, TIOCSETN, &_tty);

	/*
	 * if the window is a screen and it's not allowed to scroll and it's at
	 * the bottom right corner, don't even bother to get a character.
	 */
	if (!win->_scroll && (win->_flags&_FULLWIN)
	    && win->_curx == win->_maxx - 1 && win->_cury == win->_maxy - 1)
		c = ERR;
	else
		c = getchar();

	/*
	 * if the user wants echo and it's not the erase character, echo it.
	 */
	if (_echoit && c != _tty.sg_erase) {
		waddch(win, c);
	}
	/*
	 * if we're echoing and it's the erase character, delete the previous character
	 * and leave the character there.
	 */
	if (_echoit && c == _tty.sg_erase)
		waddstr (win, "\b \b");

	/*
	 * reset the tty to its original state
	 */
	_tty.sg_flags = oflags;
	ioctl (_tty_ch, TIOCSETN, &_tty);

	return (c);
}

/*
** wgetstr (win, str) WINDOW *win; char *str;
*/
# define Unput(str)	((--str < ostr) ? ++str,0 : 1)
# define NukeC(win)	if (_echoit) waddstr (win, "\b \b")
wgetstr (win, str) WINDOW *win; reg char *str;
{
	reg int		breakout = 0,
			cx,
			cy;
	int		bx,
			by;
	char		*ostr = str;
	struct	ltchars	ltc;

	ioctl (_tty_ch, TIOCGLTC, &ltc);

	getyx (win, by, bx);
	/*
	 * saves the current cursor postion, then gets a new character.
	 * If the character is EOF or ERR or newline or return, breaks out
	 * of the loop. If the character is the erase character, it sees if
	 * wgetch() tried to back up beyond the line (cx == 0). If it did,
	 * it backs up for it, as long as there's somewhere to go. It then
	 * refreshes the screen. If the character is the kill character, it
	 * moves back to the original screen position, clears it to the bottom
	 * of the screen, resets the str pointer to the beginning.
	 */
	do {
		getyx (win, cy, cx);
		*str = wgetch(win);
		switch (*str) {
		case EOF:
		case ERR:
		case '\n':
		case '\r':
			breakout = 1; break;
		default:
			if (*str == _tty.sg_erase) {
				if (cx == 0) 
					if (win->_cury--)
						win->_curx = win->_maxx;
				wrefresh (win);
				str--;
				if (str < ostr) {
					waddstr (win, " \007");
					wrefresh (win);
					str++;
				}
			} else if (*str == _tty.sg_kill) {
				str = ostr;
				if (_echoit) {
					wmove (win, by, bx);
					wclrtobot (win);
					wrefresh(win);
				}
			} else if (*str == ltc.t_werasc) {
				if ( Unput (str)) {
					while (*str == ' ' || *str == '\t' &&
						Unput (str))
							NukeC(win);
					while (*str != ' ' && *str != '\t' &&
						Unput (str))
							NukeC(win);
					NukeC(win);
					if (_echoit) wrefresh (win);
				}
			} else
				str++;
		}
	} while ( ! breakout );

	*str = '\0';
	
	if (*str != ERR)
		return (OK);
	else
		return (ERR);
}
