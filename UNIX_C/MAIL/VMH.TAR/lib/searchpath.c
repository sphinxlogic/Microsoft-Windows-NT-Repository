#ifndef lint
static char RCSid[] = "$Header: searchpath.c,v 1.2 85/12/03 16:00:31 deboor Exp $";
#endif

/*LINTLIBRARY*/

/*
 * $Log:	searchpath.c,v $
 * Revision 1.2  85/12/03  16:00:31  deboor
 * I don't know
 * 
 * Revision 1.1  85/11/07  19:04:26  deboor
 * Initial revision
 * 
 */

#include <sys/types.h>
#include <sys/param.h>
#include <sys/file.h>
#include <strings.h>

static	char	progpath[MAXPATHLEN];

/*
 * char *
 * searchpath (prog, xs) register char *prog; register xs;
 *	returns the full path of the passed program/file  prog with
 *	access  xs . 'xs' is a combination of the ?_OK constants
 *	which are passed to access(2). If the program has a slash
 *	in its name, it is assumed to be relative to the current
 *	directory: the path of the urrent directory is prepended
 *	to the name and the resulting path checked for permission.
 *	If access is granted, the full pathname is returned, else
 *	NULL.
 *	If no slash appears in the name, the elements of the PATH
 *	envariable are searched, in order, for the given file.
 *	If any element contains a file with the desired permissions,
 *	the full path of the file in that directory is returned.
 *	If it doesn't exist anywhere along the path with the
 *	requested permission, NULL is returned.
 */
char *
searchpath (prog, xs)
	register char	*prog;
	register int	xs;
{
	register char	*cp,
			*pp,
			*c2p;

	/*
	 * if there's a slash in the name, look for it relative to
	 * the current directory.
	 */
	if (cp = index (prog, '/')) {

		/*
		 * if path is absolute, don't bother looking for it
		 * from the cwd.
		 */
		if (*prog == '/') {
			if (! access (prog, xs))
				return prog;
			else
				return ((char *) 0);
		}
		getwd (progpath);
		(void) strcat (progpath, "/");
		(void) strcat (progpath, prog);
		if (! access (progpath, xs))
			return progpath;
		else
			return ((char *) 0);
	}
	/*
	 * no slash. Look for it along the searchPATH.
	 * Algorithm:
	 * 	Using 'pp', travel along the environmental search path,
	 *	copying each element of it, in turn, into progpath. An
	 *	element is ended when *pp is a colon. When an entire element
	 *	has been copied, append a slash and then transfer the passed
	 *	program name and null terminate it. If this path has the
	 *	required access, return the current path, else continue.
	 */
	for ( pp = getenv("PATH"); *pp; pp++) {
		for (cp = progpath; *pp && *pp != ':'; *cp++ = *pp++)
			;
		*cp++ = '/';
		for (c2p = prog; *c2p; *cp++ = *c2p++)
			;
		*cp = '\0';
		if ( ! access (progpath, xs)) {
			return progpath;
		}
	}
	return ((char *) 0);	/* not on path, return NULL */
}
