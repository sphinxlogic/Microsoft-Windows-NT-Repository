#ifndef lint
static char rcsid[] =
	"$Header: cmds.pick.c,v 1.5 88/01/13 18:58:22 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif lint

/*
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/cmds.pick.c,v $
 * $Revision: 1.5 $ $Date: 88/01/13 18:58:22 $
 * $Author: deboor $
 *
 * Routines for handling the pick, find and next_pat commands.
 *
 * FUNCTIONS:
 *	cmdPick		implements the 'pick' command
 *	cmdFindF	implements the '/' (find forward) command 
 *	cmdFindB	implements the '?' (find backward) command
 *	cmdNext_pat	implements the 'n' (find next pattern) command
 *	cmdPrev_pat	implements the 'N' (find next pattern in other
 *			direction) command
 */

#include "vmh.h"
#include "pick.h"

char	*seqName;	/* name of sequence to fill */
char	*Cmd;		/* command to do on sequence when done */

/*
 * cmdPick()
 *	performs a full 'pick' with the ability to execute a command on
 *	the resulting sequence. The sequence is a public sequence and is
 *	kept with the folder until deleted.
 */
cmdPick()
{
	char	cmdline[256];
	int	*select;

	*cmdline = '\0';

	Cmd = (char *) NULL;

	if (!terse)
		prt_action (" Enter 'pick' criteria ");
	
	infomsg (":", 1);
	if (mywgetstr (cmdWin, cmdline, TRUE) == 0)
		return;
	seqName = def_sequence ? def_sequence : "select";

	mvcur(0, COLS - 1, LINES - 1, 0);       /* Move to bottom of scr */

	if ((select = doPick (cmdline)) == (int *) NULL)
		return;
	
	if (Cmd) {
		CurSequence = select;
		UseSequence = TRUE;
		sim_cmd (Cmd);
	} else {
		Free (select);	/* unneeded */
	}
}

/*
 * structure for implementing '/', '?', 'n', and 'N' commands
 */
static	struct {
	NODE	*critRoot;
	int	direction;
} expression = {
	(NODE *) NULL, 0
};

/*
 * cmdFindF(count)
 *	find messages matching a given set of criteria and advance to the
 *	nearest one forward (if count >0) or backward (if count < 0).
 *	if autoprint set, the message is printed.
 */
cmdFindF (count)
	Reg3	int	count;
{
	char		cmdline[256];
	Reg1	int	argc;
	Reg2	char	**argv;


	if (! terse)
		prt_action (" Enter 'find' criteria ");
	infomsg (count < 0 ? "?" : "/", 1);

	*cmdline = '\0';
	if (mywgetstr (cmdWin, cmdline, TRUE) == 0)
		return;
	
	if (*cmdline && ((count < 0 && *cmdline != '?') ||
		(count > 0 && *cmdline != '/'))) {
		argv = brkstring (cmdline, " \t", "\n");
		for (argc = 0; argv[argc]; argc++)
			;

		if (! parseExpr (argc, argv))
			return;

		if (expression.critRoot != (NODE *) NULL) {/* free old tree */
			freeTree (expression.critRoot);
		}
		expression.critRoot = expRoot;
	}
	expression.direction = (count < 0) ? -1 : 1;

	cmdNext_pat (count * expression.direction, TRUE);
}

/*
 * cmdFindB (count)
 *	find backwards. just like find forwards but with negative count.
 *	that's how it's implemented.
 */
cmdFindB (count)
	int	count;
{
	cmdFindF (-count);
}

/*
 * cmdNext_pat (count, nomessage)
 *	advance to the count'th next matching message from previous find
 *	if 'nomessage' is true, then the cursor is simply moved to the
 *	lower left corner during the search. otherwise the appropriate
 *	search character is printed, the command window is cleared and
 *	the cursor placed in the lower left corner.
 */
cmdNext_pat (count, nomessage)
	int	count;
	int	nomessage;
{
	Reg2	int	dir = expression.direction;
	Reg1	int	cur;
	char		msgName[PATHLENGTH];
	Reg3	char	*msgNum;
	int		begCur;
	Reg4	FILE	*msgf;

	if (count < 0)
		dir = - dir, count = -count;
	
	if (expression.critRoot == (NODE *) NULL) {
		errormsg ("no previous expression", 1);
		return;
	}

	if (! nomessage ) {
		mvwaddch (cmdWin, 0, 0, dir < 0 ? '?' : '/');
		wclrtoeol (cmdWin);
		wrefresh (cmdWin);
	}
	mvcur (0, COLS-1, LINES-1, 0);
	/*
	 * initialize loop variables to be one more than current in the
	 * proper direction
	 */
	cur = CurrentMsgNum() + dir;
	if (cur > F->f_msgs.m_hghmsg)
		cur = F->f_msgs.m_lowmsg;
	if (cur < F->f_msgs.m_lowmsg)
		cur = F->f_msgs.m_hghmsg;
	begCur = cur;
	
	(void) sprintf (msgName, "%s/", F->f_name);
	msgNum = &msgName[strlen(msgName)];
	
		/* set tree to evaluate from previous expression */
	expRoot = expression.critRoot;

	do {
		if (Exists (cur, &F->f_msgs)) {
			(void) sprintf (msgNum, "%d", cur);
			if ((msgf = fopen (msgName, "r")) == (FILE *) NULL)
				goto advance;
			if (evalMsg (msgf) == TRUE && ! --count) {
				(void) fclose (msgf);
				/*
				 * set begCur not equal to cur so that, when
				 * we break out, if this was the first message
				 * we searched, we don't get an error message
				 */
				begCur = cur - 1;
				cleanTree (expRoot);
				break;
			}
			(void) fclose (msgf);
			cleanTree (expRoot);	/* set for next eval */
		}
	advance:
		cur += dir;
		if (cur > F->f_msgs.m_hghmsg)
			cur = F->f_msgs.m_lowmsg;
		if (cur < F->f_msgs.m_lowmsg)
			cur = F->f_msgs.m_hghmsg;
	} while (cur != begCur);

	/*
	 * we're back where we started, so didn't find anything
	 */
	if (cur == begCur) {
		if (!terse)
			infomsg ("Pattern not found", 1);
		else
			infomsg ("Fail", 1);
		return;
	}

	scroll_to (cur);	/* make it the new current message */

	if (autoprint) {
		int	oldUS = UseSequence;	/* save old value */
		int	*oldCS = CurSequence;

		UseSequence = 0;
		cmdType (1, 0, 0, (char **) NULL);
		Free ((char *) CurSequence);	/* free sequence we just made */
		UseSequence = oldUS;
		CurSequence = oldCS;
	}
}

/*
 * cmdPrev_pat (count)
 *	like next_pat but in the opposite direction. Just negate the count.
 */
cmdPrev_pat (count)
	int	count;
{
	cmdNext_pat (-count, FALSE);
}
