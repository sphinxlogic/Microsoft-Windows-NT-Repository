/*
 * hostname() - a routine to simulate the gethostname() call
 * recent Unix systems.
 *
 * hostname() returns a ptr to null terminated character string
 */

char *hostname()
{
#ifdef	HOSTNAME
	return (HOSTNAME);
#else
	static char host_name_buffer[32];

	gethostname(host_name_buffer, sizeof (host_name_buffer));
	return (host_name_buffer);

#endif
	
}
