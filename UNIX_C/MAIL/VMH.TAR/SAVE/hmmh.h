
/************************ Derived from MH ********************************/

#define MAXFOLDER 999   /* Max number of messages in a folder */
#define DMAXFOLDER 3    /* Number of digits in MAXFOLDER */
char **brkstring();

		/* m_getfld definitions and return values       */
#define NAMESZ  64      /* Limit on component name size         */
#define LENERR  -2      /* Name too long error from getfld      */
#define FMTERR  -3      /* Message Format error                 */

			/* m_getfld return codes                */
#define FLD      0      /* Field returned                       */
#define FLDPLUS  1      /* Field " with more to come            */
#define FLDEOF   2      /* Field " ending at eom                */
#define BODY     3      /* Body  " with more to come            */
#define BODYEOF  4      /* Body  " ending at eom                */
#define FILEEOF  5      /* Reached end of input file            */


char scanl[512];                /* Buffer for scan subroutine */
