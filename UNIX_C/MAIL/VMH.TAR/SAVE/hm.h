#include <curses.h>             /* Includes <stdio> and <sgtty.h> for me */
#include <la.local.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "hmmh.h"

#define	MIN(a,b)	((a<b)? a:b)
#define MAX(a,b)        ((a>b)? a:b)

#define UNSEENADDR  1           /* Annotate marker field        */
#define NOTSEEN     '>'         /* Unseen character             */
#define MSGN        2           /* Start of msg name field      */
#define REPLYADDR   5           /* position in scan line        */
#define REPLYCHAR   '-'         /* Reply character              */
#define FOLDERMODE  0751        /* Default folder mode          */
#define HMTOP       "hm-top:"   /* .mh_profile entry, top window size */
#define CLOCKUPDATE 30          /* update running clock         */


				/* "inc" is invoked via "execlp (2)" */
#define INC             "/usr/new/mh/inc"
#define HELPFILE        "/usr/doc/hm.helpfile"
#define HELPMSG         " (type h for help) "
#define MAILSPOOL       "/usr/spool/mail"

/* Chmod status bits: owner exec == seen; group exec == replied */
#define IfSeen(x)  ((x &   0100))
#define SetSeen(x)  (x |=  0100)
#define ClrSeen(x)  (x &= ~0100)

#define IfReply(x) ((x &   0010))
#define SetReply(x) (x |=  0010)
#define ClrReply(x) (x &= ~0010)

#ifdef UNIXV7
#define vfork fork
#endif

/* Global Data for ~mh */

int     topSize;                /* Number of lines in top window */
int     botSize;                /* Number of lines in bottom window */
WINDOW  *topWin, *botWin;       /* The two main window structures */
WINDOW  *topHdr, *botHdr;       /* Top and bottom window titles/headers */
WINDOW  *cmdWin;                /* Command window at bottom */

char    bs;                     /* Set to current backspace key */
char    quit;                   /* Set to current interrupt key */
char    *alstring;              /* String to issue insert-line to terminal */
char    *dlstring;              /* String to issue deline-line to terminal */
char    *clstring;              /* String to issue clear-screen to terminal */

int bvShowScan;                 /* display needed flag -- hmmm */
int idleflag;                   /* Non-zero if in reading from tty */
int newmailflag;                /* Non-zero if new mail (un-inc'd) */
char rootpath[100];             /* Unix pathname for home folder */
int fdreserved;                 /* Reserved spare file-descriptor */

/* Global data kept per open folder */

struct fldr *FHead;             /* First in the chain of open folders */
struct fldr *F;                 /* Current folder */

struct fldr
{
	char foldername[150];   /* Folder pathname */
	char folderscan[150];   /* Folder/.scan */
	ino_t inode;            /* inode of folder directory */
	struct fldr *FLink;     /* link to next structure */

	La_stream *plas;        /* LA Stream handle for folder's .scan file */
	La_linepos topline;     /* Line position for top of window */
	La_linepos botline;     /* Line position for last line in window */
	La_linepos curline;     /* Line position for current line */
	La_linepos lastline;    /* Last line file position (lsize-1) */
	struct stat sbuf;       /* Stat buffer for the folder */
	struct msgs *m;         /* mh style msgs structure */
};




/*
 * mygmsg() returns this structure.  It contains the per folder
 * information which is obtained from reading the folder directory.
 */

struct  msgs {
	int     hghmsg;         /* Highest msg in directory     */
	int     nummsg;         /* Actual Number of msgs        */
	int     lowmsg;         /* Lowest msg number            */
	int     maxstats;       /* Number of bytes in msgstats  */
	char    msgstats[1];    /* Stat bytes for each msg      */
};

			/* Flag bits in msgstats                        */
#define EXISTS    01    /* Message exists                               */


/**** Misc Procs ****/

int typeit();           /* Type a file */
int mywgetstr();        /* Window getstring w/bs and del */
int dotitle();          /* Put up title into a window */
int goodbye();          /* Exit routine */
int punt();             /* Bomb out */
int my_tstp();          /* My version of curses tstp routine */
struct fldr *getF();    /* Get or allocate/set f structure */
struct fldr *findF();   /* Search list for existing f structure */
struct msgs *my_gmsg(); /* My version of get msgs routine */

char *getenv();         /* Get environment string */
char *tgetstr();        /* Get specific termcap string */
char *mktemp();
