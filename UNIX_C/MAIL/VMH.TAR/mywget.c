#ifndef lint
static char rcsid[] =
	"$Header: mywget.c,v 2.6 88/01/13 19:11:33 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif

/*
 * routines to replace curses input routines.
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/mywget.c,v $
 * $Revision: 2.6 $
 * $Author: deboor $
 *
 * FUNCTIONS:
 *	mygetch		wgetch() with idle_flag maintenance
 *	mywgetstr	wgetstr() with default and interrupt: returns 0 if
 *			^C'ed, 1 if \n'ed or \r'ed
 */

#include "vmh.h"

/* Returns zero if aborted */
/* Returns non-zero if ended w/return */

/**** If the string "s" is non-empty on entry, that is used as ****/
/**** a type-ahead prompt buffer! ****/

mywgetstr(win, s, allowspaces)
	WINDOW	*win;
	char	*s;
	int	allowspaces;
{
	int		c;              /* Next character */
	char		*p = s;         /* prompt string */
	int		pf = 0;         /* Non-zero if prompting */
	int		xinit,
			yinit;

	getyx (win, yinit, xinit);      /* Remember initial position */

	if (strlen(s))                  /* If supplied w/prompt string */
	{
		p = s + strlen(s);      /* Point p at end of string */
		wprintw(win, s);        /* Put up prompt */
		wrefresh(win);
		pf = 1;                 /* remember prompt flag */
	}

	for ( ; ; )                     /* Handles <bs> sometimes */
	{
		c = mygetch(win) & 0177;   /* Stupid idiotic compiler */
		switch (c) {
		case ERR:
		case '\n':
		case '\r':
			*p = '\0';
			return (GS_OK);
		default:
			if (c == bs) {      /* hasn't got decent switch stmt */
				if (p <= s) {
					_putchar ('\007');
				} else {
					waddstr (win, "\b \b");
					p--;            /* Decr pointer */
				}
			} else if (c == quit) {
				wprintw(win, " ... Aborted\n");
				wrefresh(win);
				*s = 0;
				return(GS_ABORT);
			} else if (c == werasec) {
# define NukeC(win)	waddstr (win, "\b \b")
				while ((--p >= s) &&
				       ((*p == ' ') || (*p == '\t'))) {
					NukeC(win);
				}
				while ((p >= s) && (*p != ' ') && (*p != '\t')){
					NukeC(win);
					p--;
				}
				p++;
			} else {               /* Normally, just add the char */
				if (pf || c == killc) {/* don't use default.. */
					p = s;         /* Zero out the string */
					*p = 0;        /* And its image on */
					wmove(win, yinit, xinit);  /* the window */
					wclrtoeol(win);
				}
				if (c > 040 || (c == 040 && allowspaces))
				{
					waddch(win, c);
					*p++ = c;
				}
			}
		}
		wrefresh(win);  /* Update screen every character */
		pf = 0;         /* non-zero only for first input character */
	}
}

mygetch(win)
	register WINDOW *win;
{
	register int i;
					/* Alarms break me up */
	idleflag = 1;                   /* Ok for mailwatch to interrupt */

	while ((i = wgetch(win)) < 0)
		;

	idleflag = 0;                   /* Not ok for mailwatch */

	return (i);
}
