/*
 * $Header: vmh.h,v 2.14 88/01/13 19:21:30 deboor Exp $
 *
 * This is the main definitions file for VMH. All global structures and
 * constants are defined here. External variables are declared here and
 * any universally-needed include files are included here.
 *
 *			FIDDLE WITH CARE
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/vmh.h,v $
 * $Revision: 2.14 $
 * $Author: deboor $
 *
 */

	/********************** INCLUDE FILES **********************/

#include <curses.h>             /* Includes <stdio> and <sgtty.h> for me */
#include <sys/param.h>		/* includes <sys/types> and a few others */
#include <sys/stat.h>
#include <sys/time.h>
#include <ctype.h>
#include <setjmp.h>
#include <strings.h>

#include "mh.h"
#include "c_env.h"

#include "casts.h"		/*to cast function arguments to lint standards*/

	/************ GLOBAL FUNCTION PARAMETER/RETURN CONSTANTS ************/

/*
 * numbers returned from is_pre_def for each pre-defined sequence
 * 0 => not pre-defined.
 */
#define	PD_ALL		1
#define PD_FIRST	2
#define PD_LAST		3
#define PD_PREV		4
#define PD_NEXT		5
#define PD_CUR		6

/*
 * constants for readheader (in vmh.c)
 */
#define RH_NL		1	/* keep newlines in read line */
#define RH_NONL		0	/* leave newlines out */

/*
 * constants for printheader (in typeit.c)
 */
#define P_NOTHING	-1	/* don't check headers */
#define	P_RETAIN	0	/* use header-retain logic */
#define P_IGNORE	1	/* use header-ignore logic */

/*
 * constants for wgetstr (in mywget.c)
 */
#define GS_ABORT	0	/* input aborted */
#define GS_OK		1	/* input ok */

	/********************** OTHER CONSTANTS **********************/

#define NOTSEEN		'>'		/* Unseen character             */
#define REPLYCHAR	'-'		/* Reply character              */
#define SIZELEN		5		/* five digits for letter size	*/
#define FROMLEN		16		/* length of from field		*/

#define FOLDERMODE	0751		/* Default folder mode          */
#define MAXARGS		100		/* maximum number of args to a command*/

/*
 * SCANFORMAT is default format string for showline:
 *
 * Conversion codes:
 *	U		'unseen' flag
 *	M		message number
 *	R		'replied' flag
 *	d		day of message
 *	m		month of message
 *	y		year of message
 *	F		return path (From field, usually)
 *	S		subject field
 *	B		message body
 *   Any codes may be preceded by a number which is taken to be
 *   the width of the field to use. This is also the maximum number
 *   number of characters which will be printed. in the case of %B,
 *   it is *only* the maximum number of characters, i.e. the field
 *   will not be space-padded.
 */
#define SCANFORMAT	"%U%M%R %2m/%2d/%1y %F %S <<%B>>"

#define BYE		"Goodbye..."		/* the default goodbye string */
#define WATCHINTERVAL	30		/* the default mailcheck interval*/

#ifdef MAXPATHLEN
#define PATHLENGTH	MAXPATHLEN	/* length for all path string variables */
#else
#define PATHLENGTH	1024
#endif

#define HELPMSG         " (type h for help) "
#define MAILSPOOL       "/usr/spool/mail"

/*
 * LEFTOVER is the number of lines left over from the previous page by the
 * `more' function in typeit.c
 */
#define LEFTOVER	2


#ifdef UNIXV7
#define vfork fork
#endif
		/************ STRUCTURES *************/

typedef struct	{			/* a command record structure */
	int	(*c_fun)();	/* the function which was called */
	int	c_count;	/* the count gotten */
	int	*c_seq;		/* the sequence for the command (NULL if none)*/
	int	c_flags;	/* command-table flags */
	int	c_argc;		/* the number of processed arguments */
	char	*c_argv[MAXARGS];/* the arguments */
} CMD;

typedef struct	_info {		/* info file structure */
	int		i_mnum;		/* the number of the message */
	size_t		i_size;		/* the size of the message */
	time_t		i_mtime;	/* when message was modified */
	u_char		i_month,	/* the month */
			i_day,		/* day */
			i_year;		/* and year % 10 of the message */
	u_char		i_fromMe : 1,	/* whether it's from the user */
			i_replied : 1,	/* whether it's been replied to */
			i_forwarded : 1,/* whether it's been forwarded */
			i_resent : 1,	/* if it's been resent */
			i_seen : 1,	/* if msg seen */
			i_invalid : 1;	/* if it's valid */
	off_t		i_subject,	/* offset to subject */
			i_body,		/* offset to body */
			i_path;		/* offset to From field */
					/* or to To field if i_fromMe is true */
	struct	_info	*i_prev,	/* the previous info line structure */
			*i_next;	/* the next info line structure */
} INFO;

typedef struct seq SEQ;

typedef struct  msgs {
	int	m_hghmsg;		/* Highest msg in directory     */
	int	m_nummsg;		/* Actual Number of msgs        */
	int	m_lowmsg;		/* Lowest msg number            */
	u_long	m_msgstats[MAXFOLDER/LONGNBITS+1];    /* Stat bits for each msg      */
} MSGS;

		/* structure for each open folder */
typedef struct fldr {
	struct	fldr	*f_link;	/* link to next structure */
/* identification */
	char		f_name[PATHLENGTH];/* Folder pathname */
	ino_t		f_inode;	/* inode of folder directory */
	time_t		f_mtime;	/* folder modification time */
/* flags */
	int		f_lock;		/* 1 if .info file being altered */
	int		f_modified;	/* 1 if info structures modified */
/* extra data */
	int		f_line;		/* screen-line number of the cur msg */
	int		f_marks[27];	/* vi-style marks */
	MSGS		f_msgs;		/* msgs status structure */
/* sequences */
	SEQ		*f_sequences;	/* the sequences for this folder */
/* info structures */
	INFO		*f_head,	/* first message */
			*f_tail,	/* last message (tail of queue) */
			*f_top,		/* top-most message */
			*f_bot,		/* bottom-most message */
			*f_cur;		/* current message */
} FLDR;

	/********************** MACRO-FUNCTIONS **********************/

/* Chmod status bits: owner exec == seen; group exec == replied */
/* Should use sequences!!! */
#define IfSeen(x)  (((x) &   0100))
#define SetSeen(x)  ((x) |=  0100)
#define ClrSeen(x)  ((x) &= ~0100)

#define IfReply(x) (((x) &   0010))
#define SetReply(x) ((x) |=  0010)
#define ClrReply(x) ((x) &= ~0010)


/*
 * macros for handling msgstats. mn is the message number and ms is a
 * MSGS *.
 */
#define	M_SHIFT	5	/* lg LONGNBITS */
#define M_MASK	31	/* LONGNBITS - 1 */
#define Exists(mn,ms)	((ms)->m_msgstats[mn>>M_SHIFT]&(1<<(mn&M_MASK)))
#define Add_Msg(mn,ms)	((ms)->m_msgstats[mn>>M_SHIFT]|=(1<<(mn&M_MASK)))
#define Del_Msg(mn,ms)	((ms)->m_msgstats[mn>>M_SHIFT]&=~(1<<(mn&M_MASK)))

/*
 * structure allocation macros
 */
#define AllocS(_sname_)	(struct _sname_ *)Malloc(sizeof (struct _sname_))
#define AllocST(_tdname_)	(_tdname_ *)Malloc(sizeof (_tdname_))

/*
#ifdef DEBUG
#define Calloc(_N_,_S_)	(DeBuG ("calloc of %d %d bytes from %s:%d\n",_N_,_S_,\
			__FILE__,__LINE__),_Calloc(_N_,_S_))
#define Malloc(_N_)	(DeBuG ("malloc %d bytes from %s:%d\n",_N_,\
			__FILE__,__LINE__),_Malloc(_N_))
#define Free(_P_)	DeBuG ("free from %s:%d\n",__FILE__,__LINE__),\
			_Free(_P_)
#else
*/

#define Calloc(n,s)	_Calloc(n,s)
#define Malloc(n)	_Malloc(n)
#define Free(p)		_Free(p)

/*#endif DEBUG*/

/* folder macros */
# define FEmpty(f)	(f->f_tail == NULL)
# define SetFEmpty(f)	(f->f_tail = (FLDR *) NULL)


#ifndef sigmask
#define sigmask(s)	(1<<((s)-1))
#endif /* sigmask */

	/******************** GLOBAL VARIABLE DECLARATIONS *******************/

/*
 * window-related data
 */
extern	int	topSize;	/* Number of lines in top window */
extern	int	botSize;	/* Number of lines in bottom window */
extern	WINDOW	*topWin,
		*botWin;	/* The two main window structures */
extern	WINDOW	*topHdr,
		*botHdr;	/* Top and bottom window titles/headers */
extern	WINDOW	*clockWin;	/* window for the time */
extern	WINDOW	*mailWin;	/* window for New Mail message */
extern	WINDOW	*cmdWin;	/* Command window at bottom */

/*
 * initial tty characters
 */
extern	char	bs;		/* Set to current backspace key */
extern	char	quit;		/* Set to current interrupt key */
extern	char	litnext;	/* set to initial literal-next character */
extern	char	dsuspc;		/* set to initial ^Y equivalent. */
extern	char	werasec;	/* set to initial ^W equivalent. */
extern	char	killc;		/* set to current kill character */

/*
 * termcap screen-manipulation strings.
 */
extern	char	*alstring;	/* String to issue insert-line to terminal */
extern	char	*dlstring;	/* String to issue deline-line to terminal */
extern	char	*clstring;	/* String to issue clear-screen to terminal */

/*
 * global internal flags
 */
extern	int	bvShowScan;	/* display needed flag -- hmmm */
extern	int	idleflag;	/* Non-zero if in reading from tty */
extern	int	newmailflag;	/* Non-zero if new mail (un-inc'd) */
extern	int	no_tty;		/* set if we don't have tty access */

extern	char	rootpath[];	/* Unix pathname for MH directory */
extern	int	rootlen;	/* length of the pathname */
extern	int	fdreserved;	/* Reserved spare file-descriptor */

extern	int	init_tty_mode;	/* initial biff state */
extern	int	new_tty_mode;	/* new biff state */
/*
 * command-line switches flags/variables
 */
extern	char	*def_sequence;	/* default sequence name for pick */
extern	char	*scanfmt;	/* format string for showline() */
extern	int	auto_clear;	/* the auto clear state */
extern	int	Dbg;		/* debug flag. */
extern	int	autoprint;	/* print on d */
extern	int	do_size;	/* put size of msg in info window */
extern	int	terse;		/* do terse prompts */
extern	int	autoinc;	/* incorporate all new mail automatically */
extern	int	do_biff;	/* turn on biff (yech) */
extern	int	do_page;	/* act like 'page' in bottom window */
extern	char	**ignores,	/* for the hm-ignore and */
		**retains;	/* hm-retain entries */
extern	char	*format_string;	/* scan window format */
extern	int	noClock;	/* don't display the current time */

extern	struct	timeval	mailinterval;
/*
 * profile entries
 */
extern	char	SeqNegate[];
#ifdef MH6
extern	char	UnseenSequence[],
		MHSequences[];
#endif MH6

		/* AREN'T THERE MORE OF THESE???? */

/*
 * configuration info 
 */
extern	char	helpfile[],	/* path of help file */
		editorstr[],	/* name of editor to use */
		pagerstr[];	/* name of pager to use */
extern	char	*VERSION;	/* the base version (w/o progname) */
extern	char	*version;	/* for help() */
extern	char	*progname;	/* name we were invoked with */

/*
 * general global data
 */
extern	int	*CurSequence;	/* the current sequence, if any */
extern	int	UseSequence;	/* flag to tell whether to use above */

extern	FLDR	*F;		/* Current folder */

extern	jmp_buf	CommandLevel;	/* to return to command level in a hurry */

	/********************** MISC PROCS **********************/

int	typeit();		/* Type a file */
int	mywgetstr();		/* Window getstring w/bs, kill, werase and del*/
int	dotitle();		/* Put up title into a window */
int	goodbye();		/* Exit routine */
int	punt();			/* Bomb out */
int	my_tstp();		/* My version of curses tstp routine */
FLDR	*getF();		/* Get or allocate/set f structure */
FLDR	*findF();		/* Search list for existing f structure */
INFO	*infosub();
int	*GetMessages();		/* returns an array of message numbers */
int	*readsequence();	/* returns a sequence as an array of message numbers */
char	*newstr();		/* mallocs room for and copies a string */

INFO	*findinfo(),		/* find info on message by linear search from head */
	*findinfoR(),		/* find info by search from a starting point */
	*findinfoS(),		/* find info by linear search, but stop when
				 * no chance of finding the message in list */
	*i_pre(),		/* return info on nth message before another */
	*i_post();		/* return info on nth message after another */
char	*get_cur_fold();	/* return name of current folder */
char	*getenv();		/* Get environment string */
char	*tgetstr();		/* Get specific termcap string */
char	*mktemp();		/* make a temporary-file name */
char	*snprintf();		/* sprintf but with a limit on the str length */
int	_putchar();		/* routine from curses */
char	*_Malloc();
char	*_Calloc();
char	*tgoto();
char	**brkstring();
