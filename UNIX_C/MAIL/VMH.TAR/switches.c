#ifndef lint
static char	rcsid[] =
	"$Header: switches.c,v 2.8 88/01/13 19:17:49 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif

/*
 * routine and structures for processing command-line switches.
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/switches.c,v $
 * $Revision: 2.8 $
 * $Author: deboor $
 *
 * FUNCTIONS:
 *	pcsswitch	process an individual switch
 */

# include "vmh.h"

extern	char		*progname;
extern	struct	timeval	mailinterval;
extern	char		byestring[];
#ifdef DEBUG
extern	FILE	*DebugFile;
#endif

struct	swit	switches[] = {
	"autoclear",	0,
#define AUTOCSW			0
	"noautoclear",	0,
#define NAUTOCSW		1
	"autoprint",	0,
#define AUTOPSW			2
	"noautoprint",	0,
#define NAUTOPSW		3
	"biff",		0,
#define BIFFSW			4
	"nobiff",	0,
#define NBIFFSW			5
	"goodbye message",	0,
#define EXITMSW			6
	"ignore  hdr,hdr,...",	0,
#define IGNORESW		7
	"page",		0,
#define PAGESW			8
	"nopage",	0,
#define NPAGESW			9
	"retain  hdr,hdr,...",	0,
#define RETAINSW		10
	"scanwindow size",	0,
#define SCANSW			11
	"sequence seq-name",	0,
#define SEQSW			12
	"size",		0,
#define SIZESW			13
	"nosize",	0,
#define NSIZESW			14
	"terse",	0,
#define TERSESW			15
	"noterse",	0,
#define NTERSESW		16
	"help",		0,
#define HELPSW			17
	"autoinc",	0,
#define INCSW			18
	"noautoinc",0,
#define NINCSW			19
	"debug",	0,
#define DEBUGSW			20
	"ndebug",	0,
#define NDEBUGSW		21
	"root mh-root directory",0,
#define ROOTSW			22
	"mailcheck time",	0,
#define MAILCHSW		23
	"nogoodbye",		0,
#define NEMSGSW			24
	"scanformat format-string",0,
#define SCANFSW			25
	"noscanformat",		0,
#define NSCANFSW		26
	"clock",		0,
#define CLOCKSW			27
	"noclock",		0,
#define NCLOCKSW		28
	"format format-string",	0,
#define FORMSW			29
	"noformat",		0,
#define NOFORMSW		30
	(char*)NULL,	0,
};

pcsswitch (av, ac, init)
	char		***av;
	int		*ac;
	Reg1	int	init;
{
	char		buf[132];
	Reg5	char	**hd;
	Reg2	int	ni;
	Reg3	int	nh;
	Reg4	int	nr;
	void		ambigsw(), help();

	switch (smatch (**av, switches)) {
	case AMBIGSW:
		if (!init)
			return (AMBIGSW);
		ambigsw (**av, switches);
		exit(1); /*NOTREACHED*/
	case HELPSW:
dohelp:
		if (! init)
			return (HELPSW);
		(void) sprintf (buf, "%s [switches] [[+]folder]\n", progname);
		help (buf, switches);
		exit(0);
	case UNKWNSW:
		if (! init) {
			prt_action (" unknown switch %s ", **av);
			return 1;
		} else {
			fprintf (stderr, "%s: unknown switch %s\n", progname, **av);
			exit(1); /*NOTREACHED*/
		}
	case AUTOCSW:
		auto_clear = 1; break;
	case NAUTOCSW:
		auto_clear = 0; break;
	case AUTOPSW:
		autoprint = 1; break;
	case NAUTOPSW:
		autoprint = 0; break;
	case BIFFSW:
		do_biff = 1; break;
	case NBIFFSW:
		do_biff = 0; break;
	case SIZESW:
		do_size = 1; bvShowScan = 1; break;	/* force (re)display when changing size flag */
	case NSIZESW:
		do_size = 0; bvShowScan = 1; break;
	case SCANSW:
		if (!--*ac) {
			if (init) {
				fprintf (stderr, "-scanwindow needs an argument\n");
				goto dohelp;
			}
		}
		++*av;
		if (!init) {
			errormsg("No changing scanwindow size while running",1);
			break;
		}
		set_topSize (**av);
		break;
	case NOFORMSW:
	case NSCANFSW:
		format_string = SCANFORMAT;
		bvShowScan = 1;
		break;
	case FORMSW:
	case SCANFSW:
		if (! --*ac) {
			if (init)
				fprintf (stderr, "-scanformat needs a format string\n");
			else
				prt_action (" scanformat must have an argument ");
			goto dohelp;
		}
		++*av;
		format_string = newstr (**av);
		bvShowScan = 1;
		break;
	case RETAINSW:
		{
			if (! --*ac) {
				if (init)
					fprintf (stderr, "-retain must have arguments\n");
				else
					prt_action (" retain must have an argument ");
				goto dohelp;
			}
			++*av;	/* advance to next string */
#ifdef DEBUG
			DeBuG("retain: string = |%s|\n", **av);
#endif
			hd = brkstring (newstr(**av), ", ", "\t\n");
			for (nh=0;hd[nh];nh++)
				;
			if (retains == (char **) 0) {
				retains = (char**)Calloc(nh+1,sizeof(char*));
				nr = 0;
			} else {
				for (nr=0;retains[nr];nr++)
					;
				retains = (char**)Realloc(retains,(nr+nh+1) * sizeof(char *));
			}
			for (nh=0; hd[nh]; nh++)
				retains[nr+nh] = hd[nh];
			retains[nr+nh]=(char*) 0;
		}; break;
	case IGNORESW:
		{
			

			if (! --*ac) {
				fprintf (stderr, "-ignore must have arguments\n");
				goto dohelp;
			}
			++*av;
			hd = brkstring (newstr(**av), ", ", " \t\n");
			for (nh=0;hd[nh];nh++)
				;
			if (ignores == (char **) 0) {
				ignores = (char**)Calloc(nh+1,sizeof(char*));
				ni = 0;
			} else {
				for (ni=0;ignores[ni];ni++)
					;
				ignores = (char**)Realloc(ignores,
					(ni+nh+1) * sizeof (char *));
			}
			for (nh=0; hd[nh]; nh++)
				ignores[ni+nh] = hd[nh];
			ignores[ni+nh]=(char*) 0;
		}; break;
	case PAGESW:
		do_page = 1; break;
	case NPAGESW:
		do_page = 0; break;
	case SEQSW:
		def_sequence = *++*av;
		if (def_sequence == (char *) 0) {
			fprintf (stderr, "-sequence takes an argument\n");
			goto dohelp;
		}
		--*ac;
		break;
	case INCSW:
		autoinc = 1; break;
	case NINCSW:
		autoinc = 0; break;
	case DEBUGSW:
#ifdef DEBUG
		Dbg = 1;
		if ((DebugFile = fopen ("DEBUG", "w")) == NULL)
			Dbg = 0;
		break;
#else
		if (!init) {
			prt_action (" Debug functions not enabled. Go Away ");
			return (-1);
		} else {
			fprintf (stderr, "Debug functions not enabled, Go Away.\n");
			exit(-1);
		}
#endif
	case NDEBUGSW:
		Dbg = 0; break;
	case TERSESW:
		terse = 1; break;
	case NTERSESW:
		terse = 0; break;
	case NEMSGSW:
		*byestring = '\0'; break;
	case EXITMSW:
		if (--*ac) {
			++*av;
			(void) strcpy (byestring, **av);
		} else {
			if (! init) {
				prt_action (" goodbye needs an argument ");
			} else {
				fprintf (stderr, "-goodbye needs an argument\n");
			}
			goto dohelp;
		}
		break;
	case ROOTSW:
		if (--*ac) {
			++*av;
#ifdef DEBUG
			DeBuG("root: root path = |%s|\n",**av);
#endif
			/*set_mh_root (**av);*/
		} else {
			if (! init)
				prt_action (" root needs an argument ");
			else
				fprintf (stderr, "-root needs an argument\n");
			goto dohelp;
		}
		break;
	case MAILCHSW:
		if (--*ac) {
			double	q, atof();

			++*av;
			q = atof (**av);
			mailinterval.tv_sec = (int) q;
			mailinterval.tv_usec = (q-(int)q) * 1000000;
		} else {
			if (init)
				fprintf (stderr, "-mailcheck needs a time\n");
			else
				prt_action (" mailcheck needs a time ");
			goto dohelp;
		}
		break;
	case CLOCKSW:
		noClock = 0;
		break;
	case NCLOCKSW:
		noClock = 1;
		break;
	}
	return 0;
}
