#ifndef lint
static char rcsid[] =
	"$Header: status.c,v 1.7 86/10/09 16:15:38 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif lint

/*
 * This file contains routines for maintaining the status line.
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/status.c,v $
 * $Revision: 1.7 $
 * $Author: deboor $
 * 
 * FUNCTIONS:
 *	dotitle		put up a title in a window as screencentered as possible
 *	errormsg	use infomsg to print an error message
 *	infomsg		put a message in the command window
 *	prt_action	do a printf to the status line
 *	putupmcount	put up the # of messages in the current folder only
 *			if it has been overwritten or the number or folder
 *			has changed.
 */

#include "vmh.h" 

/* Put up title in window */

dotitle(win, name)
	WINDOW	*win;
	char	*name;
{
	register len;
	register xpos;
	register i;

	wmove (win, 0, 0);

	len = strlen(name);
	xpos = (COLS - len) / 2 - win->_begx;	/* center it on the screen */
	if (xpos < 1) {
		xpos = 1;
	}
	for (i = 0; i < xpos; i++)
		waddch (win, '-');
	wstandout(win);
	waddstr(win, name);
	wstandend(win);
	for (i = xpos + len; i < win->_maxx; i++)
		waddch (win, '-');
	
	wrefresh(win);
	_puts (SE);	/* turn off inverse!!! */
	curscr->_flags &= ~_STANDOUT;
}

/*
** prt_action (fmt, arg) char *fmt; int arg;
**	uses the given format string and the arg (if any) to print a string
**	to the middle status line using dotitle().
*/
/* VARARGS */
prt_action (fmt, arg)
	char	*fmt;
	int	arg;
{
	char	str[132];
	FILE	fi;
	extern	int	ShowFolder;

	/*KLUDGE*/
	fi._ptr = str;				/* this imitates sprintf */
	fi._flag = _IOWRT | _IOSTRG;	/* but doesn't limit the number */
	fi._cnt = fi._bufsiz = sizeof(str)-1;/* of args (which using sprintf()*/
	fi._file = (char) -1;	/* so _doprnt won't try and (ugh) flush this */
	_doprnt (fmt, &arg, &fi);		/* would */
	(void) putc('\0', &fi);

	dotitle (botHdr, str);
	ShowFolder = 1;
}


int	ShowFolder = 1;
/*
** putupmcount()
**	prints the current folder name and the number of messages in
**	the top-most window. Saves the previous 'current folder' and
**	the number of messages were in it the last for the next time,
**	when it checks and only updates the top window if the folder
**	has changed or the number of messages in the folder has changed.
*/
putupmcount ()
{
	char		ttl[60];
	static	int	nmes = 0;
	static	FLDR	*Fp = NULL;

	if ( ! ShowFolder && Fp == F && nmes == F->f_msgs.m_nummsg)
		return;
	Fp = F; nmes = F->f_msgs.m_nummsg;
	(void) sprintf (ttl, " +%s %d msgs ", &F->f_name[rootlen+1],
		F->f_msgs.m_nummsg);

	dotitle(topHdr, ttl);        /* Put up title of new folder */
	ShowFolder = 0;
}

/*
 *  If errormsg is called w/non-zero clear flag, then the window
 *  will be cleared first.  Otherwise the text goes up to the right
 *  of any existing text in the cmd window.
 */

errormsg(s, clearflag)          /* Put up error msg in command window */
	char *s;                        /* Error msg */
	int  clearflag;                 /* If non-zero:  clear window first */
{
	char temp[256];
	(void) sprintf(temp, " *** Error *** : %s ", s);
	infomsg(temp, clearflag);
}

infomsg(s, clearflag)
	char	*s;
	int	clearflag;
{
	if (clearflag) {
		wclear(cmdWin);
		wmove(cmdWin, 0, 0);
	}
	if (clearflag && s[0] && (s[0] == ' '))
		s[0] = '?';  /* Hack */

	waddstr(cmdWin, s);
	wrefresh(cmdWin);
}

