#ifndef lint
static char rcsid[] =
	"$Header: path.c,v 2.6 86/10/09 16:08:24 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif

/*
 * routines for finding/setting/verifying pathnames.
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/path.c,v $
 * $Revision: 2.6 $
 * $Author: deboor $
 *
 * FUNCTIONS:
 *	chkacc		check for invalid folder names (nuke?)
 *	getpath		get the path of a folder and verify access
 *	initpath	initalize basic paths
 */

#include "vmh.h"
#include <sys/file.h>

char	rootpath[PATHLENGTH];	/* path of MH directory */
int	rootlen;	/* the length of the MH directory name */

/*
   Getpath

	Input:  Folder name
	Output: Full pathname of folder
	Returns: 0 if directory exists and you have (void) write access
		 1 if none such file
		-1 if non-directory file of that name
		-2 if directory, but no (void) write privledges
		-3 if null name supplied
		-4 if non-simple pathname (initial / or .. init it)
*/


getpath(folder, fullname, maxname)
	char *folder;   /* Input folder name */
	char *fullname; /* output full pathname (may point to same as input!) */
	int   maxname;  /* sizeof fullname string */
{
	struct stat sbuf;       /**** Stat is being done twice!!! ****/
	int rc;
	char temp[PATHLENGTH];         /* Sheesh */

	if (strlen(folder) == 0) return(-3);    /* Object to null path */
	if (folder[0] == '/' || chkacc(folder)) /* or .. or / ..... */
		return(-4);

				/* Always put root path first (for now?) */
	(void) sprintf(temp, "%s/%s", rootpath, folder);
	(void) strncpy(fullname, temp, maxname);       /* Don't step on toes */

	rc = stat(fullname, &sbuf);
	if (rc < 0)
		return(1);          /* Return 1 if no such file */
	if ((sbuf.st_mode & S_IFMT) != S_IFDIR)  /* If not a directory file */
	     return (-1);                        /* then return -1 */

	if (access(fullname, W_OK) != 0)   /* If no write access */
		return (-2);
	return(0);
}


/*
 * Called once at startup time to figure out root mail pathname
 */


initpath()
{
	char temp[PATHLENGTH];


	(void) readprofile("Path:", temp, sizeof(temp));

	if (*temp != '/')
		(void) sprintf(rootpath, "%s/%s", getenv("HOME"), temp);
	else
		(void) strcpy (rootpath, temp);
	rootlen = strlen (rootpath);
}
				/* Return non-zero if arg tries to 
				   move upstairs */
chkacc(arg)
	char	*arg;
{
	register char *p;
	register int sep;	/* Indicates new component */

	sep = 1;				/* Initially indicate it is */
	for (p = arg; *p; p++) {
		if (sep && p[0] == '.' && p[1] == '.')
			return 1;
		sep = (p[0] == '/');
	}
	return 0;
}
