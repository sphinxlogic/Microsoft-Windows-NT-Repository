# include <stdio.h>
# include <sys/types.h>
# include <sys/time.h>
# include <strings.h>
# include <ctype.h>

main(ac, av) char **av;
{
	FILE	*fp = fopen ("version", "r");
	FILE	*op = fopen ("version.c", "w");
	char	line[132];
	time_t	ct;
	struct	tm	*cur_time;
	char	*cp;
	int	inc = 0,
		c_ver;

	if (fp == NULL || op == NULL) {
		printf ("Can't open file(s)\n");
		exit(1);
	}
	if (ac > 1 && av[1][0] == '+')
		inc = 1;
	else if (ac > 1 && av[1][0] == '-')
		inc = -1;

	(void) fgets (line, sizeof(line), fp);
	if (cp = index(line, '\n'))
		*cp = '\0';
	fprintf (op, "char\t*VERSION = \"");

	if ((cp = rindex(line, '@')) && isdigit (*(cp+1))) {
		*cp++ = '\0';
		for (c_ver = 0; *cp && isdigit (*cp);
			c_ver = 10 *c_ver + *cp++ - '0')
			;
		fprintf (op, "%s%d ",line, c_ver + inc);
		(void) freopen ("version", "w", fp);
		fprintf (fp, "%s@%d\n",line, c_ver + inc);
		(void) fclose (fp);
	} else
		fprintf (op, "%s ", line);
	(void) time(&ct);
	cur_time = localtime (&ct);
	fprintf (op, "%d-%d-%d (%d:%02d)\";",cur_time->tm_mon+1,
		cur_time->tm_mday, cur_time->tm_year, cur_time->tm_hour,
		cur_time->tm_min);
	(void) fclose (op);
	printf ("cc -c version.c\n");
	execlp ("cc", "cc", "-c", "version.c", 0);
}
