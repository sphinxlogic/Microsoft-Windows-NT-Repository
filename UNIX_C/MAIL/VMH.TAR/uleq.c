#ifndef lint
static char *rcsid=
	"$Header: uleq.c,v 2.2 86/02/08 21:05:10 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif
/*
 * uleq.c - "unsigned" lexical compare
 * this file is actually part of the MH library, but the one there isn't
 * commented, so this one stays.
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/uleq.c,v $
 * $Revision: 2.2 $
 * $Author: deboor $
 *
 * FUNCTIONS:
 *	strindex	find a substring of a string
 *	uleq		compare for case-insensitive equality
 *	uprf		compare for one string prefixing another
 */


/*
** uleq (c1, c2) register char *c1, *c2;
**	compares the two strings pointed to by c1 and c2 w/o
**	regard to case. The strings should be ascii  letters,
**	or unexpected results will come out
**	Returns 1 if they are equal, 0 if not (hooray for someone
**	with the right sort of logic! )
*/
uleq (c1, c2)
register char  *c1,
               *c2;
{
    register int    c;

    if (!c1)
	c1 = "";
    if (!c2)
	c2 = "";

    while (c = *c1++)
	if ((c | 040) != (*c2 | 040))
	    return 0;
	else
	    c2++;
    return (*c2 == 0);
}

/*
** uprf (c1, c2) register char *c1, *c2;
**	Compares the strings pointed to by c1 and c2 to see if
**	c2 is a prefix of c1. The comparison is done without regard for.
**	1 is returned if c2 IS a prefix of c1 and 0 otherwise.
**	The strings should be of all ascii letters, or the results
**	will be strange.
*/

uprf (c1, c2)
register char  *c1,
               *c2;
{
    register int    c;

    while (c = *c2++)
	if ((c | 040) != (*c1 | 040))
	    return 0;
	else
	    c1++;

    return 1;
}

/*
** strindex (p1, p2) register char *p1, *p2;
**	returns the index into p2 at which the string p1 begins.
**	If p1 is not in p2, returns -1.
*/

int  strindex (p1, p2)
register char  *p1,
               *p2;
{
    register char  *p;

    for (p = p2; *p; p++)
	if (uprf (p, p1))
	    return (p - p2);

    return (-1);
}

