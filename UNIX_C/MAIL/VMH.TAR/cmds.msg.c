#ifndef lint
static char rcsid[] =
	"$Header: cmds.msg.c,v 1.7 88/01/13 18:57:16 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif lint

/*
 * Routines for handling individual messages.
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/cmds.msg.c,v $
 * $Revision: 1.7 $
 * $Author: deboor $
 *
 * FUNCTIONS:
 *	cmdCompose	compose a message
 *	cmdDist		distribute messages
 *	cmdEdit		edit a message
 *	cmdForward	forward messages
 *	cmdMore		type messages using entire screen
 *	cmdQuickcomp	compose messages using 'prompter'
 *	cmdQuickforward	forward messages using 'prompter'
 *	cmdQuickreply	reply to messages using 'prompter'
 *	cmdReply	reply to messages
 *	cmdSave		save message to a file
 *	cmdcompose	compose messages taking comp switches
 *	cmdforward	forward messages taking forw switches
 *	cmdreply	reply to messages taking repl switches
 */

#include "vmh.h"

/*
 * variables for 'quick' commands
 */
int	doQuick = 0;		/* flag for quick reply, send and forward */
char	*editorsw = "-editor";	/* to tell the prog. to use a diff. editor */
char	*prompter = "prompter";	/* the fast, stupid editor */

/*
** cmdQuickreply (count) int count;
**	perform a reply with 'prompter' as an editor
*/
cmdQuickreply (count) int count;
{
	doQuick = 1;
	cmdReply (count);
	doQuick = 0;
}

/*
** cmdQuickcomp (count) int count;
**	compose a message using 'prompter'
*/
cmdQuickcomp(count) int count;
{
	doQuick = 1;
	cmdCompose(count);
	doQuick = 0;
}

/*
** cmdQuickforward (count) int count;
**	forward messages using 'prompter' to edit the result.
*/
cmdQuickforward(count) int count;
{
	doQuick = 1;
	cmdForward(count);
	doQuick = 0;
}

/*
** cmdCompose(count) int count;
**	compose and send a message.
*/
/*ARGSUSED*/
cmdCompose(count) int count;
{
	char *argv[4];

	prt_action (" Compose Letter ");
	argv[0] = "comp";
	if (doQuick) {
		argv[1] = editorsw;
		argv[2] = prompter;
		argv[3] = (char *) 0;
	} else
		argv[1] = (char *) 0;
	(void) my_vfork(argv, 0);      /* Go do the comp command */
}


/*
** cmdReply (count) int count;
**	reply to messages one at a time.
*/
cmdReply( count) int count;
{
	char		temp[PATHLENGTH];	/* for foldername and msg # */
	char		msgpath[PATHLENGTH];	/* for msg pathname */
	char		*argv[6];		/* args for repl */
	char		*msgp;			/* place to sprintf msg # */
	Reg2	int 	*msgno;			/* messages to which to reply */
	int		rc;			/* return val from my_vfork() */
	Reg1		i;			/* loop counter */
	struct	stat 	sb;			/* for marking replies */
	INFO		*ss;			/* ditto */

	msgno = GetMessages(&count);
	if (msgno == NULL)
		return;
	if (count > 1) {
		prt_action (" Reply to messages %d..%d ", msgno[0], msgno[count-1]);
	} else
		prt_action (" Reply to message %d ", msgno[0]);

	(void) sprintf (msgpath, "%s/", F->f_name);
	msgp = &msgpath[strlen(msgpath)];

	argv[0] = "repl";
	(void) sprintf(temp, "+%s", F->f_name);
	argv[1] = temp;
	argv[2] = temp + strlen(temp) + 1;
	for (i = 0; msgno[i]; i++) {
		(void) sprintf(argv[2], "%d", msgno[i]);
		if (doQuick) {
			argv[3] = editorsw;
			argv[4] = prompter;
			argv[5] = (char *) 0;
		} else
			argv[3] = (char *) 0;

		rc = my_vfork(argv, 0);     /* Go do the reply command */

		if( rc != 0 ) {
			wmove( cmdWin, 0, 0 );
			waddstr( cmdWin, "*** Reply not successful ***\n" );
			wrefresh( cmdWin );
			scroll_to (msgno[i]);
			return;     /*** RETURN ***/
		}

		/*
		 *   Since the reply message may have been edited, we'll
		 *      reinfo it...
		 *   change 'edited' to 'annotated' up there!
		 *   Just mark it as replied. showline() will take care
		 *   of any reinfo'ing which needs doing.
		 */

		(void) sprintf( msgp, "%d", msgno[i]);
		if( stat( msgpath, &sb ) != 0 )
			punt( "cmdReply: can't stat msg" );

		SetReply(sb.st_mode);   /* mark inode as replied */
		(void) chmod( msgpath, (int) sb.st_mode );

		ss = findinfoR (msgno[i], F->f_cur);
		if (ss->i_mnum == msgno[i]) {
			ss->i_replied = 1;
			F->f_modified = 1;
		} else {
			punt ("Can't find message info");
			/*NOTREACHED*/
		}

		bvShowScan = 1;
	}
	scroll_to (msgno[i-1]);
}

/*
** cmdForward(count) int count;
**	forward message(s). If more than one, all are forwarded together
*/
cmdForward(count) int count;
{
	char		temp[PATHLENGTH];	/* folder name for forw */
	Reg3	char	**argv;			/* args to forw */
	Reg1	int	i;			/* loop counter */
	Reg2	char	*cp;			/* pointer into msgnums */
	
	int		*msgs;			/* list of msgs to forward */
	char		msgnums[512];		/* ascii of same */

	msgs = GetMessages(&count);
	if (msgs == NULL)
		return;
	if (count > 1) {
		prt_action (" Forward messages %d..%d together ", msgs[0], msgs[count-1]);
	} else
		prt_action (" Forward message %d ", msgs[0]);


	/* Make room for argument vector */

	if (! doQuick)
		argv = (char **) Calloc (count + 3, sizeof (char *));
	else
		argv = (char **) Calloc (count + 5, sizeof (char *));
	
	argv[0] = "forw";
	(void) sprintf(temp, "+%s", F->f_name);
	argv[1] = temp;

	/* form arguments of ascii representation of msgs to forward */
	/* in msgnums						     */
	for (i = 0, cp = msgnums; msgs[i]; i++) {

		argv[2+i] = cp;
		(void) sprintf (cp, "%d", msgs[i]);
		cp += strlen (cp) + 1;
		if (cp > msgnums + sizeof (msgnums)) {
			errormsg ("cmdForward: msgnums array too short?!", 1);
			return;
		}
	}
	if (doQuick) {
		argv[2+i] = editorsw;
		argv[3+i] = prompter;
		argv[4+i] = (char *) 0;
	} else
		argv[2+i] = (char *) 0;

	(void) my_vfork(argv, 0);      /* Go do the forward command */

	Free ((char *)argv);
	scroll_to(msgs[i-1]);
}

/*
** cmdMore (count) int count;
**	show messages using the entire screen
*/
cmdMore(count, undo)
	int count;
	int undo;
{
	
	Reg5	char	**argv;	/* args to pager program */
	Reg3	int	*msgs;	/* messages to show */
	Reg1		i;	/* loop counters */
	Reg2		j;
	Reg4		namelen;/* length of message pathname */

	if (undo) {
		cmdUnseen(count, FALSE);
		return;
	}

	namelen = strlen (F->f_name) + DMAXFOLDER + 1;

	if ((msgs = GetMessages(&count)) == NULL) {
		return;
	}
	if (count > 1) {
		prt_action (" Show messages %d..%d ",msgs[0],msgs[count-1]);
	} else
		prt_action (" Show message %d ", msgs[0]);

	argv = (char **) Calloc (count + 2, sizeof(char *));
	for (i = 0; msgs[i]; i++) {
		argv[1 + i] = (char *) Malloc (namelen);
		(void) sprintf (argv[1 + i], "%s/%d",F->f_name, msgs[i]);
	}
	argv[i+1] = (char *) 0;
		
	argv[0] = pagerstr;
	(void) my_vfork(argv, 1);      /* Go do the page command */

	for (j = 1; j < i+1; j++) {
		hdrseen (argv[j]);	/* mark the messages as 'seen' */
		Free ((char *)argv[j]);		/* free that string */
	}
	del_from_sequence ("unseen", msgs, F);
	Free ((char *)argv);			/* then the entire vector */
	scroll_to (msgs[j-2]);
}

/*
** cmdEdit()
**	edit a message.
**	should probably accept a list of messages.....
*/
cmdEdit()
{
	char	temp[PATHLENGTH + 30];	/* full path of message to edit */
	int	msgno;			/* message number to edit */


	msgno = CurrentMsgNum();
	prt_action (" Edit message number %d ", msgno);
	if (msgno < 1)
		return;
	(void) sprintf(temp, "%s %s/%d", editorstr, F->f_name, msgno);
	(void) my_system(temp, 0);           /* Go do the edit */

	hdrseen (index (temp, ' ') + 1);		/* mark it as seen */

	bvShowScan = 1;                     /* Update top half of screen */
}

/*
** cmdreply()
**	reply to got only knows what messages, prompting for
**	user input.
*/
cmdreply()
{
	multi_arg ("repl");
}

cmdcompose()
{
	multi_arg ("comp");
}

cmdforward()
{
	multi_arg ("forw");
}

/*
** multi_arg (pgm) char *pgm;
**	called by all multi-argument functions (cmdsend, cmdreply,cmdforward).
**	given the name of the program, prompts for additional arguments, gets
**	them through the cmdWin, concatenates the path of the command and the
**	arguments and calls my_system. When my_system returns, checks for
**	fcc's and puts the help message back up.
*/
multi_arg (pgm) char *pgm;
{
	char		args[100];
	char		*cmd;

	if (!terse)
		prt_action (" %s: input arguments. <esc><cr> cancels ", pgm);
	wclear (cmdWin);
	waddch (cmdWin, '>');
	wrefresh (cmdWin);

	*args = '\0';
	if (! mywgetstr (cmdWin, args, TRUE) || *args == '\033')
		return;
	
	/* form the command string in cmd */
	cmd = (char *) Malloc (strlen (pgm) + strlen (args) +2); /* 2 = 1 for \0 & 1 for ' ' */
	(void) sprintf (cmd, "%s %s", pgm, args);

	dotitle (botHdr, cmd);
	(void) my_system (cmd, 0);	/* execute the command */
	Free ((char *)cmd);		/* free the space again */
	checkfcc();
	dotitle (botHdr, HELPMSG);
}

cmdDist (count) int count;
{
	register int	*msgs;
	char		*dargv[4];
	char		msgstr[DMAXFOLDER + 1];
	char		folder[PATHLENGTH+1];
	register	i;

	msgs = GetMessages (&count);
	if (msgs == (int *) 0) {
		return;
	}
	if (count > 1) {
		prt_action (" Dist messages %d..%d ", msgs, msgs[count-1]);
	} else {
		prt_action (" Dist message %d ", msgs[0]);
	}
	(void) sprintf (folder, "+%s", F->f_name);
	dargv[0] = "dist";
	dargv[1] = folder;
	dargv[2] = msgstr;
	dargv[3] = (char *) 0;

	for (i = 0; msgs[i]; i++) {
		(void) sprintf (msgstr, "%d", msgs[i]);
		(void) my_vfork (dargv, 0);
	}
}

cmdSave(count) int count;
{
	int		msgno;
	char		msg[PATHLENGTH],
			file[PATHLENGTH];
	FILE		*msgFile,
			*saveFile;
	register int	c;

	msgno = CurrentMsgNum();
	prt_action (" Save message %d ", msgno);
	file[0] = '\0';

	infomsg("File to save to: ", TRUE);
	if (mywgetstr (cmdWin, file, FALSE) == GS_ABORT) {
		return;
	}
	sprintf(msg, "%s/%d", F->f_name, msgno);

	msgFile = fopen (msg, "r");
	if (msgFile == (FILE *)NULL) {
		errormsg("Couldn't open message", TRUE);
		return;
	}
	saveFile = fopen(file, "w");
	if (saveFile == (FILE *)NULL) {
		errormsg("Couldn't open ", TRUE);
		errormsg(file, FALSE);
		(void)fclose(msgFile);
		return;
	}

	/*
	 * XXX: high overhead for loop.
	 */
	c = getc(msgFile);
	while (c != EOF) {
		putc(c, saveFile);
		c = getc(msgFile);
	}
	(void) fclose(msgFile);
	(void) fclose(saveFile);
}
