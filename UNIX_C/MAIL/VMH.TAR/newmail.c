#ifndef lint
static char rcsid[] =
	"$Header: newmail.c,v 2.9 88/01/13 19:13:05 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif

/*
 * routines for observing and handling new mail.
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/newmail.c,v $
 * $Revision: 2.9 $
 * $Author: deboor $
 *
 * FUNCTIONS:
 *	DoNewMailMsg	print *** New Mail *** if new mail
 *	checkmail	returns 1 if there is new mail
 *	cmdInc		incorporate new mail
 *	endwatch	shut off mail watcher
 *	mailwatch	mail watcher. also runs clock
 *	startwatch	initialize and start mail watcher going.
 */

#include "vmh.h"
#include <pwd.h>
#include <sys/file.h>
#include <sys/resource.h>


int	newmailflag,
	idleflag;


/*
 *  Mail-Watch and inc commands
 *
 */

int mailwatch();                /* What is this?  A one pass compiler? */
int _putchar();               	/* Supplied by curses */

struct sigvec daemonvec = {
	mailwatch, 0, 0
};

struct timeval	mailinterval = {
	0, 0
};	/* set by initprofile but initialize u_secs to 0 */

struct itimerval maildaemon = {
	{WATCHINTERVAL, 0},	/* the reload value is the same */
	{WATCHINTERVAL, 0}	/* as the start-off value */
};

int	time_clicks;		/* the number of mail checks for each clock update */
int	cur_clicks;		/* the number we've done so far */

char mailbox[PATHLENGTH] = "";

/*
 * Checkmail
 *  Returns 1 if user has new mail
 *  Returns 0 if mailbox is empty (or can't stat file)
 *
 */

checkmail()
{
	struct stat stbuf;

	if ((stat(mailbox, &stbuf) == 0)        /* If stat worked */
	     && (stbuf.st_size > 0)             /* and file non-empty */
	   ) return (1);                        /* then user has new mail */
	return(0);
}

/*
 * Init the daemon to check for new mail
 *
 *      Some uglies involved with new mail coming while out to lunch
 *      doing an exec.  Oh well, such is hacking.
 */

startwatch()    /*** always run daemon so time updates ... ***/
{
	char		*cp;
	struct passwd	*pw;

	if ( ! *mailbox) {
		if ((pw = getpwuid (getuid())) == NULL) {
			punt ("And who do you think YOU are?\n");
		}
		if (cp = getenv ("MAILDROP"))
			(void) strcpy (mailbox, cp);
		else
			(void) sprintf(mailbox, "%s/%s", MAILSPOOL,pw->pw_name); 
		time_clicks = 60 / mailinterval.tv_sec - 1;	/* update clock every 60 seconds or so */
		cur_clicks = 0;		/* -1 above because we start at 0 */
	}

	if (mailWin->_y[0][0] != '-')
		dotitle (mailWin, "");		/* put dashes up so it don' look so weird */
	newmailflag = checkmail();      /* Init new mail flag */
	if (newmailflag)                /* If already new mail */
	{
		DoNewMailMsg();   /* Put up the msg pls */
	}

	(void) sigvec (SIGALRM, &daemonvec, (struct sigvec *) 0); /* Otherwise start up the daemon */
	maildaemon.it_value = maildaemon.it_interval = mailinterval;
	(void) Setitimer (ITIMER_REAL, &maildaemon, 0);
	(void) sigsetmask (sigblock(0) & ~sigmask(SIGALRM));
}

endwatch()
{
	(void) sigsetmask (sigblock(0) | sigmask (SIGALRM));
}

/*
 *      Deamon to wake up every now and then and check my mail!
 *      Must be started by startwatch()
 */

mailwatch()
{
	int oldx, oldy;         /* Terminal's cursor location on entry */

	getyx (curscr, oldy, oldx);   /* Remember where to put cursor back */

	if (cur_clicks++ == time_clicks) {
		DoTimeMsg();
		cur_clicks = 0;
	}
	if (idleflag && !no_tty)         /* Go back to sleep if no control */
	{
		if (!newmailflag)       /* if wasn't any new mail before */
		{
			newmailflag = checkmail();      /* Check again */
			if (newmailflag) {              /* If is now ... */

				(void) putchar('\007');
				DoNewMailMsg();
			} else if (mailWin->_y[0][0] != '-') {
				/*
				 * dash it all if none there
				 */
				dotitle (mailWin, "");

			} else {
				return;
			}
			/*
			 * restore old cursor position!
			 * This is done only if we actually produced
			 * something in the window.
			 */
			tputs( tgoto(CM, oldx, oldy), 1, _putchar);
			curscr->_curx = oldx;
			curscr->_cury = oldy;
			(void) fflush(stdout);
		}
	} 
	return;
}


/*
   Inc
*/

# include <sys/wait.h>

char	*pushArgv[2];

/*ARGSUSED*/
cmdInc(count, undo, argc, argv)
	int	count,
		undo,
		argc;
	char	**argv;
{
	FLDR	*f;        /* F ptr for inbox folder */
	int     pid;            /* Process id of kid */
	char    folder[PATHLENGTH];    /* full folder name */
	char    tmpstr[PATHLENGTH];    /* could use same string buf */
	int     oldnext;        /* next msg num before the inc cmd */
	FILE    *msgfd;         /* File ptr for each msg during (re)info */
	int     i;
	char	*msg;
	
	

	endwatch();               /* Stop the watcher daemon */

				/* Avoid inc's if no new mail yet . . . */
	if (!newmailflag)       /* If I haven't seen any new mail then . . .*/
	{
		newmailflag = checkmail();      /* Check it again */
		if (!newmailflag)               /* If still no mail */
		{
			startwatch();           /* Restart the daemon */
			infomsg("No new mail.", 1);
			return;
		}
	}

	if (getpath("inbox", folder, sizeof(folder)) != 0) {
		errormsg("Can't get to inbox?", 1);
		startwatch();
		return;
	}

	f = getF(folder);       /* Get structure for inbox */
	oldnext = nextmsgno(&f->f_msgs);
	if (oldnext == -1) {
		errormsg("Inbox full!", 1);
		return;
	}

	cmdBottom(f);                  /* Do "esc >" on inbox display */
	if (f != F) {
		pushArgv[0] = defalt;  /* Go to inbox if not already there */
		pushArgv[1] = (char *) 0;
		cmdPush (1, FALSE, 1, pushArgv);
	}

	prt_action (" Incorporating new mail ");

	infomsg ("Wait ... \n", 1);
	dump_sequences (f);	/* for getting of new 'unseen' sequence */

	f->f_lock = 1;		/* lock it now, just in case */
	if ((pid=vfork()) == 0) /* If the kid */
	{
		(void) freopen("/dev/null", "r+", stdin);
		(void) dup2 (0, 1);
		(void) dup2 (1, 2);
		/*
		 * search path for inc program. dangerous beast?
		 * naaaaahhh.
		 */
		execlp ("inc", "inc", "-silent", 0);
		errormsg("Can't execute inc!!",1);
		_exit(1);
		/*NOTREACHED*/
	} else {                            /* Parent */
		int	cpid;
		union	wait	CStat;

		do {
			/*
			 * wait for child, being sure to continue it if it
			 * decides to not restart after a ^Z
			 */
			while ((cpid = wait3 (&CStat, WUNTRACED, (struct rusage *)0)) == 0)
				;
			if ((cpid == pid) && WIFSTOPPED (CStat)) {
				(void) kill (pid, SIGCONT);
				cpid = 0;
			}
		} while (cpid != -1 && cpid != pid);
		if (CStat.w_retcode) {
			infomsg ("problems in inc!", 1);
			f->f_lock = 0;		/* unlock for further use */
			return;
		}
	}

	add_new_msgs(f);	/* add new lines to end */
	init_sequences(f);	/* get new 'unseen' messages */


	(void) sprintf (tmpstr, "%s/", f->f_name);
	msg = &tmpstr[strlen(tmpstr)];
	for (i = oldnext ; i <= (f->f_msgs.m_hghmsg) ; i++)
	{
		(void) sprintf(msg, "%d", i);
		msgfd = fopen(tmpstr, "r");
		if (msgfd == NULL)
			punt("Problems in inc!");
		linkinfo (infosub(msgfd, i), f);
		(void) fclose(msgfd);
	}

	f->f_lock = 0;		/* done messing -- unlock */
	wclear(cmdWin);
	wrefresh(cmdWin);
	startwatch();              /* Fire up mail watch daemon again */

	/*
	 *  Special case for empty to non-empty transition:
	 *      Move to top!
	 */

	if( (! f->f_top) && (f->f_tail) )
		f->f_top = f->f_cur = f->f_head;
	else
		scroll_to (oldnext);
		/*mv_cursor( f, oldlast, oldtop, oldbot ); */

	bvShowScan = 1;	/* Update the new screen */

}

/*
** DoNewMailMsg()
**	print "*** New Mail ***" in the mail window.
*/
DoNewMailMsg()
{
	wmove(mailWin, 0, 0);
	wstandout(mailWin);
	wprintw(mailWin, "*** New Mail ***");
	wstandend(mailWin);
	wrefresh(mailWin);
}

