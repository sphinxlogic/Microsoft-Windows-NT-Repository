#ifndef lint
static char rcsid[] =
	"$Header: rdprofile.c,v 2.7 86/10/21 14:17:45 deboor Exp $";

static char notice[] =
	"This program is in the public domain and is available for unlimited \
distribution as long as this notice is enclosed.";
#endif

/*
 * Read mh-profile file (has ".mh_profile" wired in)
 * Not any more! --ardeb
 *
 * $Source: /c/support/deboor/usr/src/old/vmh/RCS/rdprofile.c,v $
 * $Revision: 2.7 $
 * $Author: deboor $
 *
 * FUNCTIONS:
 *	brkstring	fracture a string into a string vector
 *	readprofile	read a profile entry
 */

#include "vmh.h"

readprofile(key, value, maxvalue)
	Reg1	char	*key;
	char		*value;
	int		maxvalue;
{
	Reg2	FILE	*in;
	char		temp[1024];
	char		*cp = getenv ("MH");
	Reg3	int	rc;
	Reg4	int	keylen = strlen(key);
	Reg5	int	checkColon = ! rindex(key, ':');


	if (! cp)
		(void) sprintf(temp, "%s/%s", getenv("HOME"),
#ifdef MH6
			mh_profile);
#else
			mh_prof);
#endif MH6
	else
		(void) strcpy (temp, cp);
	in = fopen(temp, "r");
	if (in == NULL)
		punt("Can't open .mh_profile, suggest you use mh first!");

	*value = 0;     /* Init to empty in case not found */

	for ( ; ; ) {
		rc = readheader(temp, sizeof(temp), in, RH_NONL);
		if (rc == 0)
			break;
		if (uprf (temp, key)) {
			if (checkColon && temp[keylen] != ':')
				continue;
			for (cp = temp+keylen+1; *cp && isspace (*cp); cp++)
				;
			(void) strncpy (value, cp, maxvalue);
			for (keylen = strlen(value);
				keylen < maxvalue && rc < 0;
				keylen += (rc < 0) ? -rc : rc) {
					rc = readheader (&value[keylen],
						maxvalue-keylen, in, RH_NONL);
				}
			(void) fclose( in );
			return 1;
		}
	}
	(void) fclose(in);
	return 0 ;
}

char **
brkstring (str, breaks, end)
	Reg1 char *str;
	Reg3 char *breaks;
	Reg4 char *end;
{
	char		*argv[256];
	Reg5		argc;
	char		**av;
	Reg2	 char	*tstr;
	char		tstring[512];

	for (argc = 0, tstr = tstring; *str && ! index (end, *str)
	    && argc < 255;) {
		if (index (breaks, *str)) {
			*tstr++ = '\0';
			argv[argc++] = newstr(tstring);
			while (*str && index (breaks, *str) && ! index(end, *str))
				str++;
			tstr = tstring;
		} else if (*str == '"') {
			while (*++str != '"' && !index (end, *str))
				if (*str == '\\')
					*tstr++ = do_backslash(*++str);
				else
					*tstr++ = *str;
			if (*str == '"')
				str++;
		}  else if (*str == '\\') {
			*tstr++ = do_backslash(*++str);
			str++;
		} else {
			*tstr++ = *str++;
		}
	}
	*tstr = '\0';
	argv[argc++] = newstr(tstring);
	argv[argc] = (char *) 0;
	av = (char **) Calloc (argc+1, sizeof(char *));
	Bcopy (argv, av, argc * sizeof(char *));

	return av;
}
