/**
 ** ADT: LIFO queue of int's
 **/

#ifndef LIFO_Q_SIZE
#define LIFO_Q_SIZE 20
#endif

typedef struct {
  int q[LIFO_Q_SIZE];
  int ptr;
} lifo;

#define Q_init(QQ) QQ.ptr = 0
#define Q_pop(QQ) QQ.q[(--QQ.ptr)]
#define Q_peek(QQ) QQ.q[(QQ.ptr-1)]
#define Q_push(QQ, DATA) QQ.q[QQ.ptr]=DATA, QQ.ptr=((QQ.ptr+1)%LIFO_Q_SIZE)
#define Q_size(QQ) QQ.ptr



/**
 ** ADT: boolean
 **/

#define boolean	short
#define true	1
#define false	0


