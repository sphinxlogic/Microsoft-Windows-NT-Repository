/**************************************************************************
 *      ck{,d}: an incoming mail monitor.
 *      Copyright (c) 1988 Wayne Mesard                                   *
 *                                                                        *
 *      This is free software.  It may be reproduced, retransmitted,      *
 *      redistributed and otherwise propogated at will, provided that     *
 *      this notice remains intact and in place.                          *
 *                                                                        *
 *      Direct all bug reports and comments to mesard@BBN.COM.            *
 *                                                                        *
 **************************************************************************/


#include <stdio.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>
#include "wsm_types.h"


main(argc, argv)
int argc;
char *argv[];
{
    extern char *getenv();
    extern int atoi();
    extern int getppid();	/* For parent check. */
    int check_box();
    time_t last_write();
    
    int i, c;
    int interval = 120;
    FILE *out_device = NULL;
    boolean verbose = false;
    int ppid;			/* For parent check. */
    
    char *ptr, mailbox[256];
    time_t curr, old_mtime;


    for (i=0; ++i<argc && argv[i][0]=='-';)
	switch (argv[i][1]) {
	  case 'v':
	    verbose = true;
	    break;
	  case 'i':
	    interval = atoi(argv[i]+2);
	    break;
	  case 'o':
            if (out_device != NULL)
                fclose(out_device);
            if (i+1<argc)
		if ((out_device = fopen(argv[++i], "a"))==NULL) {
		    perror(argv[i]+2);
		    exit(-1);
		}
            break;
	}

    mailbox[0] = '\0';
    if (i<argc)
	strcpy(mailbox, argv[i]);

    if (mailbox[0] == '\0')
	if (ptr = getenv("MAIL"))
	    (void) strcpy(mailbox, ptr);
	else {
	    (void) strcpy(mailbox, getenv("HOME"));
	    (void) strcat(mailbox, "/mailbox");
	}
     
    if (!strcmp("ck", argv[0]+strlen(argv[0])-2)) {
	if ((c=check_box(mailbox, (out_device?out_device:stdout), verbose, false))==0)
	    printf("No new messages.\n");
	exit(c);
    }

    ppid = getppid();
    if (fork())
	exit(0);

    old_mtime = last_write(mailbox);
    while(1) {
	if (old_mtime < (curr=last_write(mailbox))) {
	    old_mtime = curr;
	    (void) check_box(mailbox, (out_device?out_device:stderr), verbose, true);
	}

	sleep(interval);

	/* Check to see if parent has died (e.g., on logout).
	 * Commit suicide if it has.
	 * There must be a better way to do this! (setpgrp?)
	 */
	if (kill(ppid, 0))
	    exit(0);
    }
}



time_t last_write(fn)
char *fn;
{
  struct stat stbuf;

  stat(fn, &stbuf);
  return((time_t) stbuf.st_mtime);
}


#define BUFSIZE 100
#define FROM_FIELD_LEN 19
#define SUBJ_FIELD_LEN 21
#if (FROM_FIELD_LEN != 19 || SUBJ_FIELD_LEN != 21)
    HEY! Fix the fprintf() line below.
#endif
#if (BUFSIZE != 100)
    HEY! Fix the fscanf() line below.
#endif

int check_box(fn, out_device, verbose, bell)
char *fn;
FILE *out_device;
boolean verbose, bell;
{
    extern char *ctime();
    void nonwhitecpy();
    static char *margin =
	"+---------------------------------------------+\n";
    FILE *mbox;
    char *devname;
    char s[BUFSIZE], from_field[FROM_FIELD_LEN], 
         subj_field[SUBJ_FIELD_LEN];
    int headers = 0, readstat = 0;
    int count = 0;

    if (mbox = fopen(fn, "r")) {
	while ((readstat=fscanf(mbox, "%100[^\n]", s)) != EOF) {
	    (void) getc(mbox);

	    if (headers) {
		if (readstat==0) {
		    headers = 0;
		    if (count==0)
			fprintf(out_device, "%c%s",
			       (bell ? '\007' : '\0'), margin);
		    fprintf(out_device, "|%2d: %-18.18s{}%-20.20s |\n", 
			    ++count, from_field, subj_field);
		}
		else if (!strncmp(s, "From:", 5))
		    nonwhitecpy(from_field, s+6, FROM_FIELD_LEN);

		else if (!strncmp(s, "Subject:", 8))
		    nonwhitecpy(subj_field, s+9, SUBJ_FIELD_LEN);
	    }
	    else if (!strncmp(s,"\001\001\001\001", 4)) {
		headers = 1;
		subj_field[0] = from_field[0] = '\0';
	    }
	}
	fclose(mbox);
	if (count)
	    fprintf(out_device, margin);
    }
    else
	verbose = true;

    if (verbose) {
	struct stat stbuf;

	if (stat(fn, &stbuf))
	    perror(fn);
	else
	    fprintf(out_device, 
		    "[%s] Size: %d chars.\nLast modified: %s", 
		    fn,
		    stbuf.st_size, 
		    ctime((long *)&stbuf.st_mtime));
	return(-1);
    }
    return(count);

	
}



void
nonwhitecpy(d, s, dsize)
register char *d, *s;
int dsize;
{
    register char *dend = d+dsize;
    s--;
    while (isspace(*++s));
    while ((*d++ = *s++) && (d<dend));
}
