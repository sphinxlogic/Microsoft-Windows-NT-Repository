: run this script through /bin/sh

tar cvf - \
	conf/doc/mhn.rf \
	h/mhn.h \
	support/general/mhl.headers \
	support/general/viamail.sh \
	uip/ftp.c \
	uip/mhn.c > MIME/files3a.tar

(diff -c conf/doc/:MH.rf conf/doc/MH.rf; \
 diff -c conf/doc/:mh-chart.rf conf/doc/mh-chart.rf; \
 diff -c conf/doc/:send.rf conf/doc/send.rf; \
 diff -c conf/doc/:show.rf conf/doc/show.rf; \
 diff -c conf/makefiles/:doc conf/makefiles/doc; \
 diff -c conf/makefiles/support/:general conf/makefiles/support/general; \
 diff -c conf/makefiles/:uip conf/makefiles/uip; \
 diff -c h/:mshsbr.h h/mshsbr.h; \
 diff -c support/general/:scan.mailx support/general/scan.mailx; \
 diff -c support/general/:scan.size support/general/scan.size; \
 diff -c support/general/:scan.time support/general/scan.time; \
 diff -c support/general/:scan.timely support/general/scan.timely; \
 diff -c uip/:msh.c uip/msh.c; \
 diff -c uip/:mshcmds.c uip/mshcmds.c; \
 diff -c uip/:post.c uip/post.c; \
 diff -c uip/:refile.c uip/refile.c; \
 diff -c uip/:send.c uip/send.c; \
 diff -c uip/:sendsbr.c uip/sendsbr.c; \
 diff -c uip/:show.c uip/show.c; \
 diff -c uip/:whatnowsbr.c uip/whatnowsbr.c; \
 diff -c uip/:whom.c uip/whom.c) > MIME/patches3.diff

tar cvf - \
	conf/doc/MH.rf \
	conf/doc/mh-chart.rf \
	conf/doc/send.rf \
	conf/doc/show.rf \
	conf/makefiles/doc \
	conf/makefiles/support/general \
	conf/makefiles/uip \
	h/mshsbr.h \
	support/general/scan.mailx \
	support/general/scan.size \
	support/general/scan.time \
	support/general/scan.timely \
	uip/msh.c \
	uip/mshcmds.c \
	uip/post.c \
	uip/refile.c \
	uip/send.c \
	uip/sendsbr.c \
	uip/show.c \
	uip/whatnowsbr.c \
	uip/whom.c > MIME/files3b.tar

rm -f MIME/upgrade3.tar.Z
tar cvf - MIME | compress > upgrade3.tar.Z
mv upgrade3.tar.Z MIME/
