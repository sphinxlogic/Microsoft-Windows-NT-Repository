/*++
/* NAME
/*	sysexits 5
/* SUMMARY
/*	exit status codes for programs called by sendmail
/* PROJECT
/*	pc-mail
/* PACKAGE
/*	nfs
/* SYNOPSIS
/*	#include "sysexits.h"
/* DESCRIPTION
/* .nf

 /* sendmail-compatible exit status codes */

#define	EX_OK		0
#define EX_USAGE	64
#define EX_DATAERR	65
#define EX_NOINPUT	66
#define EX_NOUSER	67
#define EX_NOHOST	68
#define EX_UNAVAILABLE	69
#define EX_SOFTWARE	70
#define EX_OSERR	71
#define EX_OSFILE	72
#define EX_CANTCREAT	73
#define EX_IOERR	74
#define EX_TEMPFAIL	75
#define EX_PROTOCOL	76
#define EX_NOPERM	77
/* AUTHOR(S)
/*	Wietse Z. Venema
/*	Eindhoven University of Technology
/*	Department of Mathematics and Computer Science
/*	Den Dolech 2, P.O. Box 513, 5600 MB Eindhoven, The Netherlands
/*
/*	These codes were actually defined by Eric Allman, the originator
/*	of the sendmail program.
/* CREATION DATE
/*	Sun Oct 29 16:03:19 MET 1989
/* LAST MODIFICATION
/*	10/29/89 22:29:47
/* VERSION/RELEASE
/*	1.1
/*--*/

