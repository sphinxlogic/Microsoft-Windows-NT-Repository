/*++
/* NAME
/*	dosunix 5
/* SUMMARY
/*	UNIX <-> MS-DOS text format conversion
/* PROJECT
/*	pc-mail
/* PACKAGE
/*	nfs
/* SYNOPSIS
/*	#include <stdio.h>
/*	#include "dosunix.h"
/* DESCRIPTION
/* .nf

 /* Anticipate ANSI-compatible compilers */

#ifdef __STDC__
int     unix2dos(FILE * ifp, FILE * ofp);
int     dos2unix(FILE * dfp, FILE * pfp);
char   *dosgets(char *buf, int len, FILE * fp);

#else
int     unix2dos();
int     dos2unix();
char   *dosgets();

#endif
/* AUTHOR(S)
/*	Wietse Z. Venema
/*	Eindhoven University of Technology
/*	Department of Mathematics and Computer Science
/*	Den Dolech 2, P.O. Box 513, 5600 MB Eindhoven, The Netherlands
/* CREATION DATE
/*	Sun Oct 29 16:41:50 MET 1989
/* LAST MODIFICATION
/*	10/29/89 22:30:05
/* VERSION/RELEASE
/*	1.1
/*--*/

