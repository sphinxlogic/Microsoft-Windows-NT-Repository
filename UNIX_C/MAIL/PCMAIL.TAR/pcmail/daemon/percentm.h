/*++
/* NAME
/*	percentm 5
/* SUMMARY
/*	convert %m to system error message
/* PROJECT
/*	pc-mail
/* PACKAGE
/*	nfs
/* SYNOPSIS
/*	#include percentm.h
/* DESCRIPTION
/* .nf

 /* external interface of the percentm module */

extern char *percentm();

/* AUTHOR(S)
/*	Wietse Z. Venema
/*	Eindhoven University of Technology
/*	Department of Mathematics and Computer Science
/*	Den Dolech 2, P.O. Box 513, 5600 MB Eindhoven, The Netherlands
/* CREATION DATE
/*	Sun Oct 29 15:29:37 MET 1989
/* LAST MODIFICATION
/*	10/29/89 22:31:53
/* VERSION/RELEASE
/*	1.1
/*--*/

