/*++
/* NAME
/*	syslog 5
/* SUMMARY
/*	surrogate BSD4.3 syslog facility
/* PROJECT
/*	pc-mail
/* PACKAGE
/*	nfs
/* SYNOPSIS
/*	include "syslog.h"
/* DESCRIPTION
/* .nf

 /* Do nothing if we already have <syslog.h> */

#ifndef SYSLOG

 /* various constants */

#define	LOG_PID		1
#define	LOG_MAIL	1
#define	LOG_WARNING	1

extern  openlog();
extern  syslog();
extern  closelog();

#endif
/* AUTHOR(S)
/*	Wietse Z. Venema
/*	Eindhoven University of Technology
/*	Department of Mathematics and Computer Science
/*	Den Dolech 2, P.O. Box 513, 5600 MB Eindhoven, The Netherlands
/* CREATION DATE
/*	Sun Oct 29 15:12:57 MET 1989
/* LAST MODIFICATION
/*	10/29/89 22:29:50
/* VERSION/RELEASE
/*	1.1
/*--*/

