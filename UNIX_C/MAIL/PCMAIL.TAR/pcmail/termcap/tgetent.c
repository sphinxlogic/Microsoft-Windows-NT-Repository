/*++
/* NAME
/*	tgetent 3
/* SUMMARY
/*	extract terminal entry from capability database
/* PROJECT
/*	ms-dos/unix compatibility
/* PACKAGE
/*	termcap
/* SYNOPSIS
/*	tgetent(bp,name)
/*	char *bp,*name;
/* DESCRIPTION
/*	tgetent simulates its UNIX counterpart.
/*	Its purpose is to extract from the capability database all
/*	information for a specific terminal.
/*
/*	name should point to a string with the terminal name (usually
/*	taken from the environment with getenv(3)).
/*	bp should point to a 1024-character buffer for storage of
/*	terminal information extracted from the capability database.
/*
/*	Since the capabilities of the ms-dos console are described by a
/*	static data structure, tgetent(3) is a dummy function.
/* SEE ALSO
/*	termcap(3), Berkeley extensions to UNIX.
/* FILES
/*	ANSI.SYS, ibm pc console driver.
/* AUTHOR(S)
/*	W.Z. Venema
/*	Eindhoven University of Technology
/*	Department of Mathematics and Computer Science
/*	Den Dolech 2, P.O. Box 513, 5600 MB Eindhoven, The Netherlands
/* CREATION DATE
/*	Wed Jan  1 19:01:13 GMT+1:00 1986
/* LAST MODIFICATION
/*	90/01/22 13:57:04
/* VERSION/RELEASE
/*	2.1
/*--*/

#include "termcap.h"

tgetent(bp, name)
char   *bp,
       *name;
{
    return (1);
}
