/*++
/* NAME
/*	mail 5
/* SUMMARY
/*	global declarations for mail shell
/* PROJECT
/*	pc-mail
/* PACKAGE
/*	mail
/* SYNOPSIS
/*	#include "mail.h"
/* DESCRIPTION
/* .nf

 /* Global declarations for the mail shell */

extern int alias();			/* alias.c */
extern int call();			/* call.c */
extern int create();			/* create.c */
extern void init();			/* desk.c */
extern int junk_desk();			/* desk.c */
extern char message[];			/* desk.c */
extern char comment[];			/* desk.c */
extern void patience();			/* deskutil.c */
extern int when();			/* deskutil.c */
extern int unspool();			/* deskutil.c */
extern int save();			/* deskutil.c */
extern int filter();			/* deskutil.c */
extern int print();			/* deskutil.c */
extern int delete();			/* deskutil.c */
extern char *tstamp();			/* deskutil.c */
extern int edit();			/* edit.c */
extern int work();			/* email.c */
extern int work_disp();			/* email.c */
extern int file();			/* file.c */
extern int junk_file();			/* file.c */
extern int kbdinp();			/* kbdinp.c */
extern void kbdinit();			/* kbdinp.c */
extern void kbdrest();			/* kbdinp.c */
extern int mailfile();			/* mailfile.c */
extern int makework();			/* makework.c */
extern int mbox();			/* mbox.c */
extern int reply();			/* reply.c */
extern int setup();			/* setup.c */

/* AUTHOR(S)
/*	W.Z. Venema
/*	Eindhoven University of Technology
/*	Department of Mathematics and Computer Science
/*	Den Dolech 2, P.O. Box 513, 5600 MB Eindhoven, The Netherlands
/* CREATION DATE
/*	Sat Apr 16 16:42:07 MET 1988
/* LAST MODIFICATION
/*	90/01/22 13:02:05
/* VERSION/RELEASE
/*	2.1
/*--*/
