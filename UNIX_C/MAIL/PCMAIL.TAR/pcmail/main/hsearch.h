/* hsearch.c --- PD simple implementation of System V hsearch(3c) routine */

 /*
  * Original author: Arnold Robbins
  * 
  * Changes by me (WZV):
  * 
  * put this part of the original hsearch.c in a separate file
  * 
  * make the lookup and hashing algorithms case-insensitive
  */

#include <stdio.h>

typedef struct entry {
	char *key;
	char *data;
	} ENTRY;

typedef enum {
	FIND,
	ENTER
	} ACTION;

typedef struct element {
	ENTRY	item;
	struct element *next;
	} ELEMENT;

ENTRY *hsearch();
