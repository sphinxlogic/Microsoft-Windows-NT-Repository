/*++
/* NAME
/*	logs 5
/* SUMMARY
/*	various message services
/* PROJECT
/*	pc-mail
/* PACKAGE
/*	cico
/* SYNOPSIS
/*	#include "logs.h"
/* DESCRIPTION
/* .nf

 /* globally visible components */

#define debug(l) (dflag >= l) && dbg	/* yuck! */

extern int dflag;			/* debugging level */
extern int *systrap;			/* panic button */

extern void trap();			/* exception handler */
extern int open_log();			/* open log file */
extern int dbg();			/* write debug info */
extern void log();			/* write logging info */

/* FILES
/*	$MAILDIR/logfile
/* AUTHOR(S)
/*	W.Z. Venema
/*	Eindhoven University of Technology
/*	Department of Mathematics and Computer Science
/*	Den Dolech 2, P.O. Box 513, 5600 MB Eindhoven, The Netherlands
/* CREATION DATE
/*	Sun Apr 12 13:45:11 GMT+1:00 1987
/* LAST MODIFICATION
/*	90/01/22 13:02:03
/* VERSION/RELEASE
/*	2.1
/*--*/
