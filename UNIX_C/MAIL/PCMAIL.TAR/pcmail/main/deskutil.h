/*++
/* NAME
/*	deskutil 5
/* SUMMARY
/*	visible desk top utility funtions 
/* PROJECT
/*	pc-mail
/* PACKAGE
/*	mailsh
/* SYNOPSIS
/*	#include "deskutil.h"
/* DESCRIPTION
/* .nf

/* /* externally visible functions in deskutil.c */

extern void patience();
extern int when();
extern int unspool();
extern int save();
extern int print();
extern int delete();
/* SEE ALSO
/*      desk(3);
/* AUTHOR(S);
/*      W.Z. Venema
/*      Eindhoven University of Technology
/*      Department of Mathematics and Computer Science
/*      Den Dolech 2, P.O. Box 513, 5600 MB Eindhoven, The Netherlands
/* CREATION DATE
/*	Tue May 12 15:35:20 GMT+1:00 1987
/* LAST MODIFICATION
/*	1/22/90 13:01:33
/* VERSION/RELEASE
/*	2.1
/*--*/
