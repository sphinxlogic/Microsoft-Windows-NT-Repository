/* Map names to lower case for the MicroSoft 3.0 CL compiler/linker command */

#define  set_tty        SET_TTY     /* find current settings, and initialize */
#define  reset_tty      RESET_TTY   /* reset to settings that set_tty() found */
#define  get_msr        GET_MSR     /* get MSR byte from port. */
#define  init_comm      INIT_COMM   /* initialize the comm port interupts, */
#define  uninit_comm    UNINIT_COMM /* remove initialization, */
#define  set_xoff       SET_XOFF    /* enable/disable XON/XOFF, */
#define  get_xoff       GET_XOFF    /* read XON/XOFF state, */
#define  rcvd_xoff      RCVD_XOFF   /* returns true if XOFF rcvd, */
#define  sent_xoff      SENT_XOFF   /* true if XOFF sent, */
#define  inp_cnt        INP_CNT     /* returns count of rcv chars, */
#define  inp_char       INP_CHAR    /* get one char from buffer, */
#define  inp_flush      INP_FLUSH   /* flush input buffer, */
#define  outp_char      OUTP_CHAR   /* output a character, */
