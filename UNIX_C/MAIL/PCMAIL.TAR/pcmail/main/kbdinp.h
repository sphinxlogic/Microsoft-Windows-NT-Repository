/*++
/* NAME
/*	kbdinp
/* SUMMARY
/*	keyboard interpreter definitions
/* PROJECT
/*	pc-mail
/* PACKAGE
/*	mail
/* SYNOPSIS
/*	#include "kbdinp.h"
/* DESCRIPTION
/* .nf

 /* keyboard interpreter function types */

extern int kbdinp();			/* interpreter */
extern void kbdinit();			/* set terminal modes */
extern void kbdrest();			/* restore terminal modes */

/* SEE ALSO
/*	kbdinp(3)	keyboard interpreter implementation
/* AUTHOR(S)
/*	W.Z. Venema
/*	Eindhoven University of Technology
/*	Department of Mathematics and Computer Science
/*	Den Dolech 2, P.O. Box 513, 5600 MB Eindhoven, The Netherlands
/* CREATION DATE
/*	Sat Apr  4 19:12:01 GMT+1:00 1987
/* LAST MODIFICATION
/*	90/01/22 13:01:53
/* VERSION/RELEASE
/*	2.1
/*--*/
