/*++
/* NAME
/*      screen 3
/* SUMMARY
/*      often-used message strings
/* PROJECT
/*      pc-mail
/* PACKAGE
/*      mail
/* SYNOPSIS
/*      #include "screen.h"
/* DESCRIPTION
/*      Messages and strings used in more than one Screen structure
/*	are kept here.
/* SEE ALSO
/*      screen(5)       screen table structure
/*      kbdinp(3)      screen table interpreter
/* AUTHOR(S)
/*      W.Z. Venema
/*      Eindhoven University of Technology
/*      Department of Mathematics and Computer Science
/*      Den Dolech 2, P.O. Box 513, 5600 MB Eindhoven, The Netherlands
/* CREATION DATE
/*      Wed Apr  1 21:14:53 GMT+1:00 1987
/* LAST MODIFICATION
/*	90/01/22 13:02:34
/* VERSION/RELEASE
/*	2.1
/*--*/

#include "defs.h"
#include "screen.h"

/* general strings used in more than one Screen structure */

public char anykey[]    = "Press any key to continue";
public char initscreen[]= "Return to initial screen";
public char prevscreen[]= "Return to previous screen";
public char int_error[]	= "The program is confused";
public char pageup[]	= "Move screen one page upwards";
public char pagedn[]	= "Move screen one page downwards";
public char csrup[]	= "Move cursor upwards";
public char csrdn[]	= "Move cursor downwards";
public char getsummary[]= "Press ESC to cancel. Enter a one-line summary for identification:";
public char getaddr[]	= "Press ESC to cancel. Send message to:";
public char printcurr[]	= "Print this message";
public char delcurr[]	= "Delete this message";

/* we have a problem reading a mail message */

public char *m_msgread[] = {
    "",
    "Sorry, that message is no longer available",
    0,
};
