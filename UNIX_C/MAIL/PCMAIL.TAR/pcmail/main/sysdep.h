/*++
/* NAME
/*	sysdep 5
/* SUMMARY
/*	system dependencies for comm. port i/o
/* PROJECT
/*	pc-mail
/* PACKAGE
/*	cico
/* SYNOPSIS
/*	#include "sysdep.h"
/* DESCRIPTION
/* .nf

 /* try to unite unix and dos */

#ifdef	unix
#define	xwrite	write
#define	xread	read
extern int xopen(),xclose(),xgetc();
#endif

#ifdef MSDOS
#include <fcntl.h>
#include <signal.h>
#include <dos.h>
#include "comport.h"
#include "clmap.h"

typedef struct timetype {
        unsigned hour;
        unsigned minute;
        unsigned sec;
        unsigned hsec;
} TIME, *TIME_PTR;

extern int xread(),xwrite(),xopen(),xclose(),xgetc();
#endif

/* time-out interval serial-port i/o */

#define BYTE_TIMEOUT    20
/* AUTHOR(S)
/*	MS-DOS parts derived from uuslave sources (John Gilmore)
/*	published on usenet early 1987.
/*
/*	W.Z. Venema
/*	Eindhoven University of Technology
/*	Department of Mathematics and Computer Science
/*	Den Dolech 2, P.O. Box 513, 5600 MB Eindhoven, The Netherlands
/* CREATION DATE
/*	Sun Apr 12 17:48:08 GMT+1:00 1987
/* LAST MODIFICATION
/*	90/01/22 13:02:47
/* VERSION/RELEASE
/*	2.1
/*--*/
