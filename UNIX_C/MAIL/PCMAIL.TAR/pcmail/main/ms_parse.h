/*++
/* NAME
/*      ms_parse 5
/* SUMMARY
/*      message parser
/* PROJECT
/*      pc-mail
/* PACKAGE
/*      mailsh
/* SYNOPSIS
/*	#include "ms_parse.h"
/* DESCRIPTION
/* .nf

 /* status codes returned by ms_parse() */

#define MS_UUCP		0		/* UUCP-style From_ line */
#define MS_HEADER	1		/* RFC822-like header line */
#define MS_CONT		2		/* Continued header line */
#define MS_BODY		3		/* Line within message body */

 /* entry points of the ms_parse module */

extern int hscanf();			/* extract info from header line */
extern int ms_parse();			/* parse one line */

/* AUTHOR(S)
/*      W.Z. Venema
/*      Eindhoven University of Technology
/*      Department of Mathematics and Computer Science
/*      Den Dolech 2, P.O. Box 513, 5600 MB Eindhoven, The Netherlands
/* CREATION DATE
/*	Sat Dec  9 18:50:35 MET 1989
/* LAST MODIFICATION
/*	90/01/22 13:02:13
/* VERSION/RELEASE
/*	2.1
/*--*/
