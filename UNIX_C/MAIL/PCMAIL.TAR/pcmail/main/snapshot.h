/*++
/* NAME
/*	snapshot 5
/* SUMMARY
/*	keep overview of the mail directory
/* PROJECT
/*	pc-mail
/* PACKAGE
/*	mail
/* SYNOPSIS
/*	#include "snapshot.h"
/* DESCRIPTION
/* .nf

 /* Storage for one message entry in the snapshot table */

typedef struct {
    unsigned short msgno;		/* message sequence number */
    char    prefix;			/* message name prefix */
} SNAP_SHOT;

/* access functions */

public void snap_junk();		/* junk snapshot table */
public SNAP_SHOT *snap_shot();		/* make sure shapshot exists */

/* AUTHOR(S)
/*      W.Z. Venema
/*      Eindhoven University of Technology
/*      Department of Mathematics and Computer Science
/*      Den Dolech 2, P.O. Box 513, 5600 MB Eindhoven, The Netherlands
/* CREATION DATE
/*	Sun Dec 17 19:51:55 MET 1989
/* LAST MODIFICATION
/*	90/01/22 13:02:39
/* VERSION/RELEASE
/*	2.1
/*--*/
