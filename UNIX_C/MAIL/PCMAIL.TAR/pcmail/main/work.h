/*++
/* NAME
/*      scanwork,rmtwork 5
/* SUMMARY
/*      spool directory access for cico
/* PROJECT
/*      pc-mail
/* PACKAGE
/*      cico
/* SYNOPSIS
/*	#include <stdio.h>
/*      #include "work.h"
/* DESCRIPTION
/* .nf

 /* globally visible elements of scanwork.c */

typedef struct {
    char    type;			/* Data, eXecute */
    char    path[BUFSIZ];		/* full path name (unsent file) */
    char    sent[BUFSIZ];		/* full path name when sent */
    unsigned seqno;			/* sequence number */
    char    rqst[BUFSIZ];		/* uucp request message */
    FILE   *fp;				/* associated file pointer */
} work;

extern work *scanwork();		/* searches work files */
extern work *rmtwork();			/* assigns spool files */
extern void getwork();			/* receives remote work */

/* AUTHOR(S)
/*      W.Z. Venema
/*      Eindhoven University of Technology
/*      Department of Mathematics and Computer Science
/*      Den Dolech 2, P.O. Box 513, 5600 MB Eindhoven, The Netherlands
/* CREATION DATE
/*	Sun Apr 12 14:30:28 GMT+1:00 1987
/* LAST MODIFICATION
/*	90/01/22 13:02:58
/* VERSION/RELEASE
/*	2.1
/*--*/
