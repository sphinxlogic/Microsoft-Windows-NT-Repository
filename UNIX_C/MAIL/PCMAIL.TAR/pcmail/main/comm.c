/*++
/* NAME
/*	comm 3
/* SUMMARY
/*	cico communications parameters retrieval
/* PROJECT
/*	pc-mail
/* PACKAGE
/*	cico
/* SYNOPSIS
/*	#include "params.h"
/*	#include "comm.h"
/* DESCRIPTION
/*	Implementation module for communications parameters and other
/*	global stuff that has not yet found its place.
/* AUTHOR(S)
/*	W.Z. Venema
/*	Eindhoven University of Technology
/*	Department of Mathematics and Computer Science
/*	Den Dolech 2, P.O. Box 513, 5600 MB Eindhoven, The Netherlands
/* CREATION DATE
/*	Sun Apr 12 13:37:12 GMT+1:00 1987
/* LAST MODIFICATION
/*	90/01/22 13:01:20
/* VERSION/RELEASE
/*	2.1
/*--*/

#include <stdio.h>

#include "defs.h"
#include "params.h"
#include "comm.h"

public int ttfd = -1;				/* comm. port */
public Info *comm = 0;				/* comm. info */
public char *password = 0;			/* uucp password */
public char rmthost[BUFSIZ] = "Unknown";	/* remote host name */

public int (*Read)()  = 0;			/* protocol read function */
public int (*Write)() = 0;			/* protocol write function */
public int (*Close)() = 0;			/* protocol close function */

public char msgin[MSGBUF];			/* message receive buffer */
public char msgout[MSGBUF];  		        /* message send buffer */
