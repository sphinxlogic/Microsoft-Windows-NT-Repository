/*this is press.c*/
#include <stdio.h>
main(argc,argv)
int argc;
char *argv[];

{
FILE *infile , *outfile, *fopen();

int inchar = 1;
char outchar;
char char1;
char char2;

      infile = fopen(argv[1],"r");
   /* printf("\ninfile= %o", infile); */
      outfile = fopen(argv[2],"w");
   /* printf("\noutfile= %o", outfile); */

      while ((inchar = getc(infile)) != EOF)
       {
	 char1  = inchar;
	 char1  = char1 & 017;
	 char1  = char1 << 4;

	 inchar = getc(infile);
	 char2  = inchar;
	 char2  = inchar;
	 char2  = char2 & 017;

	 outchar = char1 + char2;

	  putc(outchar,outfile);

       }  printf("\npress finished\n");
}
