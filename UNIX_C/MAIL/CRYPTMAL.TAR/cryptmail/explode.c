/*this is explode.c*/

#include <stdio.h>
main(argc,argv)
int argc;
char *argv[];

{
FILE *infile , *outfile, *fopen();
int c;

int inchar = 1;
char char1;
char char2;

      infile = fopen(argv[1],"r");
      outfile = fopen(argv[2],"w");

      while ((inchar = getc(infile)) != EOF)
       {

	 char1  = inchar;
	 char1  = char1 >> 4;
	 char1  = char1 & 017;
	 char1  = char1 | 0100;

	 char2  = inchar;
	 char2  = char2 & 017;
	 char2  = char2 | 0100;

	  putc(char1,outfile);
	  putc(char2,outfile);
       }

      fclose(infile);
      fclose(outfile);
      printf("\nexplode finish\n");


}
