#include        <stdio.h>

#define DESTDIR         "/bin"
#define BUF_SIZE        1024000

char msgbuffer[BUF_SIZE];

char *
getline(l, here)
char *l, *here;
{
        register char *run = l;

        if (*here == 0)
                return 0;
        for (; *here && *here != '\n'; *run++ = *here++);
        here++;
        *run = 0;
        return here;
}

char *
command_message(passwd, subject)
char *passwd, *subject;
{
        char    sbuf[256],
                l[256];
        char    *run = msgbuffer;
        char    *lrun = l;

        sprintf(sbuf, "Subject: %s", subject);

        for (; (run = getline(lrun, run)) != 0; )
                if (strncmp(l, "Subject: ", strlen("Subject: ")) == 0) {
                        if (strcmp(l, sbuf) != 0)
                                return 0;
                        else
                                break;
                }
        if (run == 0)
                return 0;
        for (; (run = getline(lrun, run)) != 0 && *lrun == '\0'; )
        if (run == 0)
                return 0;
        if (strcmp(lrun,passwd) == 0)
                return run;
        return 0;
}

setup(pname, appending)
char *pname;
{
        FILE            *fd;
        int             appending;
        register char   *run;
        char            pbuf[256],
                        sbuf[256],
                        fbuf[256];

        printf("enter password to identify legal command files: ");
        run = pbuf;
        for (*run = getchar(); *run != '\n'; *run = getchar())
                run++;
        *run = 0;

        printf("enter subject to identify legal command files (one word!!): ");
        run = sbuf;
        for (*run = getchar(); *run != '\n'; *run = getchar())
                run++;
        *run = 0;

repeat: printf("write a new '.forward' or append? [aw] ");
        switch (getchar()) {
        case 'w' : case 'W' :
                appending = 0;
                for (; getchar() != '\n'; );
                break;
        case '\n' :
                appending = 1;
                break;
        case 'a' : case 'A' :
                appending = 1;
                for (; getchar() != '\n'; );
                break;
        default :
                for (; getchar() != '\n'; );
                goto repeat;
        }

        sprintf(fbuf, "%s/.forward", getenv("HOME"));
        if ((fd = fopen(fbuf, appending ? "a" : "w")) == NULL) {
                printf("cannot open .forward file for %s\n",
                       appending ? "appending" : "writing");
                exit(0);
        }

        fprintf(fd, "\\%s\n\"|%s/%s %s %s\"\n",DESTDIR,getenv("USER"),
                pname,pbuf,sbuf);
        fclose(fd);
        printf("setup done\n");
}

collect_message()
{
        register char *run = msgbuffer;

        for (*run = getchar(); *run != EOF; *run = getchar())
                run++;
        *run++ = 0;
        *run = 0;
}

do_command(body)
register char *body;
{
        FILE            *fd;
        char            *tmp = "/tmp/cmdfXXXXXX";
        char            cmdbuf[256];

        if ((fd = fopen(tmp = (char *)mktemp(tmp), "w")) == NULL)
                return;
        fprintf(fd, "%s", body);
        fclose(fd);
        sprintf(cmdbuf, "sh %s", tmp);
        system(cmdbuf);
        unlink(tmp);
}

main(ac, av)
char **av;
{
        char    *passwd,
                *body,
                *subject;

        if (ac == 1) {
                printf("doing settup\n");
                setup(av[0]);
                exit(0);
        }
        passwd = av[1];
        subject = av[2];

        collect_message();
        if ((body = command_message(passwd,subject)) != 0)
                do_command(body);
}
