#ifndef lint
static char *sccsid = "@(#)netio.c	1.7 87/07/31";
#endif lint

#include "smtp.h"
#include <setjmp.h>

#ifdef NOBOMB
#define bomb exit
#endif

char *strcpy(), *strncat();

int hooting = 0;		/* true if not server */

int
tgets(line, size, fi)		/* fgets from TCP */
char *line;
int size;
FILE *fi;
{
	register char *cr;

	*line = 0;
	if (fgets(line, size, fi) == NULL)
		return -1;
	if (ferror(fi)) {
		perror("error reading from smtp");
		bomb(E_IOERR);
	}

	/* convert \r\n -> \n */
	cr = line + strlen(line) - 2;
	if (cr >= line && *cr == '\r' && *(cr+1) == '\n') {	/* CRLF there? */
		*cr++ = '\n';
		*cr = 0;
	} else				/* no CRLF present */
		cr += 2;		/* point at NUL byte */

#ifdef HOOTING
	if (hooting) (void) printf("<<< %s", line);
#endif
	if (feof(fi)) {
		perror("read eof from smtp");
		bomb(E_IOERR);
	}
	return cr - line;
}

int
tputs(line, fo)			/* fputs to TCP */
char *line;
FILE *fo;
{
	char buf[MAXSTR];
	register char *nl;
	extern int debug;

	(void) strcpy(buf, line);
#ifdef HOOTING
	if (hooting) (void) printf(">>> %s", buf);
#endif
	/* replace terminating \n by \r\n */
	nl = buf + strlen(buf) - 1;		/* presumably \n */
	if (nl >= buf && *nl=='\n') {		/* if it is ... */
		*nl++ = '\r';
		*nl++ = '\n';
		*nl = 0;
	} else
		printf("unterminated line: <%s>\n", buf);

	(void) fputs(buf, fo);
	(void) fflush(fo);
	if (ferror(fo)) {
		(void) perror("error writing to smtp");
		bomb(E_IOERR);
	}
	return 0;
}
