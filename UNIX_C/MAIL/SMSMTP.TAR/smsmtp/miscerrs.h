/* these error numbers are local to the smtp programs, used by bomb() */
#define	E_USAGE		-1
#define E_NOHOST	-2
#define	E_CANTOPEN	-3
#define E_OSFILE	-4
#define E_IOERR		-5
#define E_TEMPFAIL	-6
