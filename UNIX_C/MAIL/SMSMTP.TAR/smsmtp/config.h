/* config.h for smtp package */

/*
 * define either BSD or SYSV.
 */
#define SYSV			/* SystemV with TCP/IP */
/* # define BSD			/* Berkeley 4.[23] */

/*
 * If set, HOSTDOMAIN overrides HOSTNAME and MYDOM.
 */
/* #define HOSTDOMAIN	"mhres.mh.nl" */

/*
 * If not set, HOSTNAME will be fetched using uname (SYSV) or gethostname (BSD)
 */
/* #define HOSTNAME	"mhres" */

/*
 * If set, MYDOM will be appended to the host name.
 */
#define MYDOM		".mh.nl"

/*
 * Define server to use. Defaults to "smtp".
 */
/* #define SERVNAME	"tsmtp" */

/*
 * Define SYSLOG when the syslog rotuine can be used. For SYSV, it will
 * use a PD syslog package.
 */
#define SYSLOG

/*
 * Define this if you want a log of mail transactions. See the code in
 * smtpd.c.
 */
#define SIMPLELOG

/*
 * The mailer used to send the mail.
 */
#define MAILER	"/bin/smail"

/*
 * Define HOOTING for printout of transaction (needed for "Transaction
 * of session")
 * Used by "netio" in "smtp"
 */
#define HOOTING

/*
 * Define NOSYSEXITS iy you don't have <sysexits.h> (or "sysexits.h" on SYSV.
 */

/* define NOSYSEXITS */

/*
 * Define this if your signal(2) takes a void function as its second arg.
 * Otherwise leave it empty
 */

/* define TYPESIG	((void)(*)())	*/
#ifndef TYPESIG
# define TYPESIG
#endif

