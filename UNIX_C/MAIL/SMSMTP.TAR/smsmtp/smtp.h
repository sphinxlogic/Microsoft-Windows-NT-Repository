/* smtp.h */

#include "config.h"

/* smtp constants and the like */

/* tunable constants */
#define MAXSTR 10240			/* maximum string length */
#define NAMSIZ MAXSTR			/* max file name length */

/* standard includes and portability */

#include <stdio.h>
#include <ctype.h>
#include <sys/types.h>
#include <errno.h>
#include "miscerrs.h"

#ifdef BSD
#include <strings.h>
#include <sys/time.h>
#include <sys/wait.h>
extern char *sprintf();
# ifndef NOSYSEXITS
#  include <sysexits.h>
# endif
#endif

#ifdef SYSV
#include <string.h>
#include <time.h>
#include <fcntl.h>
#define	index		strchr
#define	rindex		strrchr
#define	bcopy(a,b,n)	memcpy(b,a,n)
#define	bzero(a,n)	memset(a,'\0',n)
#define	SIGCHLD		SIGCLD
extern int sprintf();
# ifndef NOSYSEXITS
#  include "sysexits.h"
# endif
#endif

#ifndef EX_SOFTWARE
# define EX_SOFTWARE	70	/* internal software error */
#endif

#ifdef SYSLOG
# ifdef SYSV
#  include "syslog.h"
# else
#  include <syslog.h>
# endif
#endif

#ifndef TRUE
# define TRUE	1
# define FALSE	0
#endif
