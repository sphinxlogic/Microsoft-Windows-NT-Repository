/*--------------------------------------*\
 | file containing the definitions of	|
 | all parameters present in the data-	|
 | file.  These parameters define the	|
 | format of the cover.			|
\*--------------------------------------*/

int   CodeXPos;		/* Backcode parameter 1	*/
int   CodeYPos;		/* Backcode parameter 1	*/
int   CodeLen;		/* Backcode parameter 2	*/
char *CodeFont;		/* Backcode parameter 3	*/
int   CodeFSize;	/* Backcode parameter 4	*/

int   TsXPos;		/* Tapetype xpos, parameter 5	*/
int   TsYPos;		/* Tapetype ypos, parameter 5	*/
int   NrXPos;		/* NoiseRed xpos, parameter 6	*/
int   NrYPos;		/* NoiseRed ypos, parameter 6	*/
char *TsNrFont;		/* tapetype&NoiseRed font, p 7	*/
int   TsNrFSize;	/* ts & NoiseRed fontsize, p 8	*/

int   BT1XPos;		/* Backtitle 1 xpos, param  9	*/
int   BT1YPos;		/* Backtitle 1 ypos, param  9	*/
int   BT2XPos;		/* Backtitle 2 xpos, param  10	*/
int   BT2YPos;		/* Backtitle 2 ypos, param  10	*/
int   BTLen;		/* Backtitle Length, param  11	*/
char *BTFont;		/* Backtitle font, param 12	*/
int   BTFSize;		/* Backtitel fontsize, param 13	*/

int   FrAXPos;		/* Front A, xpos, param 14	*/
int   FrAYPos;		/* Front A, ypos, param 14	*/
int   FrBXPos;		/* Front B, xpos, param 15	*/
int   FrBYPos;		/* Front B, ypos, param 15	*/
char *FrABFont;		/* Front A&B, font, param 16	*/
int   FrABFSize;	/* Front A&B, fontsize, par 17	*/

int   FrTl1XPos;	/* Front title 1 xpos, par 18	*/
int   FrTl1YPos;	/* Front title 1 ypos, par 18	*/
int   FrTl2XPos;	/* Front title 2 xpos, par 19	*/
int   FrTl2YPos;	/* Front title 2 ypos, par 19	*/
char *FrTlFont;		/* Fronttitle font, param 20	*/
int   FrTlFSize;	/* Fronttitle fontsiz, param 21	*/

int   Tl1XPos;		/* Title 1 xpos, param 22	*/
int   Tl1YPos;		/* Title 1 ypos, param 22	*/
int   Tl2XPos;		/* Title 2 xpos, param 23	*/
int   Tl2YPos;		/* Title 2 ypos, param 23	*/
int   TlLen;		/* length of title, par 24	*/
int   TlLDist;		/* line spacing titles, par 25	*/
char *TlFont;		/* Title font, parameter 26	*/
int   TlFSize;		/* and fontsize, parameter 27	*/

int   CtTlXDist;	/* Dist between tl and ct,par28	*/
int   CtLen;		/* countlength, parameter 29	*/

int   FTlSepX1;		/* horizontal line front xfrom	*/
int   FTlSepX2;		/* horizontal line front xto	*/
int   FTlSepY;		/* horizontal line front y	*/

int   FVSepX;		/* front separation line x	*/
int   FVSepY1;		/* front separation line yfrom	*/
int   FVSepY2;		/* front separation line yto	*/



/*
 * That's it!
 */
