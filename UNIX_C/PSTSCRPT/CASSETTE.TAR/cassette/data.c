#include "xdefs.h"

CATITEM *FirstCatIt = (CATITEM *)0;
CATITEM *LastCatIt  = (CATITEM *)0;

CASS     CurCass[1];
CATITEM *CurIt = (CATITEM *)0;

int      NCatItems  = 0;
char     LineBuf[100];
char	 Buf[100];
