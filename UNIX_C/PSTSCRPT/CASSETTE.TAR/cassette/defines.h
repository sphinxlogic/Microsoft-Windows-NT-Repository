#ifndef DEFINES_H
#define DEFINES_H


#define SCRLINES	24
#define PARAMFILE1	"CASSETTE.DAT"
#define PARAMFILE2	"/usr/local/lib/CASSETTE.DAT"


/*
 * for select: WHAT do we want to select ?
 */
#define SONGS1		1
#define SONGS2		2
#define CAT_ITEMS	3

#define ENDMARKER	0
#define QUIT		99

/*
 * Main menu
 */
#define LIST_COVERS	1
#define DEL_COVERS	2
#define RD_COVER	3
#define CREAT_COVER	5
#define EDIT_COVER	6
#define SHO_COVER	7
#define FILE_COVER	9

/*
 * TapeType menu
 */
#define NONE 		'0'
#define FEO3 		'1'
#define CRO2		'2'
#define FECR		'3'
#define METAL		'4'

/*
 * Noisereduction system menu
 */
#define DOLBY_B		'1'
#define DOLBY_C		'2'
#define DBX		'3'
#define HXPRO		'4'
#define NO_NR		'9'


#define ALL		0x01
#define TO_DELETE	0x02
#define TO_PRINT	0x03
#define TO_FILE		0x04



#define SELECTED	(flag)0x1



#define CASSMAGIC "#XCASS-COVER-1"





#endif DEFINES_H
