static char *RCSid = "$Header: call.c,v 1.1 86/10/15 17:53:07 andy stab $";

/*
 * $Log:	call.c,v $
 * Revision 1.1  86/10/15  17:53:07  andy
 * Initial revision
 * 
 */

#include <stdio.h>

extern int lineno;
extern FILE *postr;

call (istr)
     register FILE *istr;
{
  FILE *fromchild, *popen();
  int i=0, j;
  char ch, cmd[512];

  while ((ch=getc(istr)) != '\n' && ch != EOF) cmd[i++] = ch;
  /* strcpy (&cmd[i], "\n\n"); */
  cmd[i] = '\n';
  cmd[i+1] = '\0';

  if ((fromchild = popen (cmd, "r")) == (FILE *)-1)
      fprintf (stderr, "call: cannot execute %s\n", cmd);

  putc ('\n', postr);
  while ((ch = (char)getc (fromchild)) != EOF)
            putc (ch, postr);

  pclose (fromchild);
           
  lineno++;
  return (1);
}

