#define	DEF_12	"  (1) (2) Cfract"
#define	DEF_14	"  (1) (4) Cfract"
#define	DEF_34	"  (3) (4) Cfract"
#define	DEF_13	"  (1) (3) Cfract"
#define	DEF_18	"  (1) (8) Cfract"
#define	DEF_23	"  (2) (3) Cfract"
#define	DEF_38	"  (3) (8) Cfract"
#define	DEF_58	"  (5) (8) Cfract"
#define	DEF_78	"  (7) (8) Cfract"
#define	DEF_ru	"  0 ysiz pt 5 div 2 copy rmoveto   (_) show  neg rmoveto"
#define	DEF_sr	"  currentfont   /dx xsiz pt 0.05 mul def  dx 0 rmoveto   f.S [ xsiz pt 0 0 ysiz pt 0 0 ]makefont setfont  (\\326)s  dx neg 0 rmoveto   setfont"
#define	DEF_sq	"  currentlinewidth currentpoint currentpoint  ysiz pt 20.8 div dup dtransform round idtransform setlinewidth pop  newpath moveto  /dy ysiz pt 0.8 mul def   /dx xsiz pt 0.8 mul def   dx 8 div dy .1875 mul neg rmoveto   0 dy rlineto dx 0 rlineto  0 dy neg rlineto  closepath        mark  currentfont /FontName get   40 string cvs   (Bold) search   {fill}   {stroke}   ifelse  cleartomark   moveto   xsiz pt 0 rmoveto   setlinewidth"
#define	DEF_ff	"  (f) show xsiz pt 20 div neg 0 rmoveto (f) s"
#define	DEF_Fi	"  (f) show xsiz pt 20 div neg 0 rmoveto (\\256) s"
#define	DEF_Fl	"  (f) show xsiz pt 20 div neg 0 rmoveto (\\257) s"
#define	DEF_fract	"  /fbot exch def   /ftop exch def   currentfont currentpoint   /f0 ysiz pt 2 div def   (0) stringwidth pop 2 div 0 rmoveto   (\\244)show   currentpoint 4 2 roll moveto   0 f0 0.75 mul rmoveto   fonttype [ xsiz pt 2 div 0 0 f0 0 0 ]makefont setfont    ftop show  moveto   fbot show  setfont"

























