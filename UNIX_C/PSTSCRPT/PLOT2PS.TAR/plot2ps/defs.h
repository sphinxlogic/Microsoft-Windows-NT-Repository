/*
    This file is part of plot2ps.

    Copyright (C) 1989 Rene' Seindal

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

    My current address is: seindal@diku.dk
*/

#include <stdio.h>

/* CONSTANTS */

#define XMAX		572	/* physical pagesizes in points */
#define YMAX		579	/* (should be 818) */

#define XMIN		18	/* lower left x coordiate (ALW) */
#define YMIN		25	/* lower left y coordiate (ALW) */

#define XRANGE		4096	/* default logical coor (values 0..XRANGE-1) */
#define YRANGE		4096	/* values 0..YRANGE-1 */

#define FONT		"Helvetica"
#define PTSIZE		12	/* pointsize for text (in points) */
#define LINEWIDTH	0.1	/* width of lines (in points) */
#define POINTDIAM	0.5	/* diameter of points (in points!) */
#define MAXPATHLENGTH 	1024	/* no path generated will contain */
				/* more segments than MAXPATHLENGTH */

/* COORDINATES AND SCALING */

extern double xscale;
extern double yscale;
extern double xoffset;
extern double yoffset;

#define X(x) (xscale * ((double)(x)) + xoffset)
#define Y(y) (yscale * ((double)(y)) + yoffset)

/*  POSTSCRIPT OUTPUT */

#define INVALID		0x01	/* plot not initialised or closed */
#define CLEANPAGE	0x02	/* page is blank */
#define CLEANPATH	0x04	/* current path is empty */

#define DIRTYPAGE state &= ~CLEANPAGE
#define DIRTYPATH state &= ~(CLEANPAGE | CLEANPATH)

extern int state;	/* state of the page */
extern int restpathlen;		/* length of current path */
