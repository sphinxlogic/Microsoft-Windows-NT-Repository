/*
    plot2ps --- convert Unix plot(5) data to PostScript

    Copyright (C) 1989 Rene' Seindal

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

    My current address is: seindal@diku.dk
*/

#include <stdio.h>

/* routines for reading plot data */
int  getch();			/* get a byte */
int  getsi();			/* get a signed short */
char *getstr();			/* get a string */

#include "bytesex.h"

main(argc,argv)
    int	argc;
    char **argv;
{
    int cmd;
    int x, y, x0, y0, x1, y1;	/* (x, y) coordinates */
    int r;			/* circle radius */
    char *l;			/* label/linemods */

    openpl();
    while ( (cmd = getch()) != EOF ) {
	switch (cmd) {
	case 'm':
	    x = getsi();
	    y = getsi();
	    move( x, y );
	    break;
	case 'n':
	    x = getsi();
	    y = getsi();
	    cont( x, y );
	    break;
	case 'p':
	    x = getsi();
	    y = getsi();
	    point( x, y );
	    break;
	case 'l':
	    x = getsi();
	    y = getsi();
	    x0 = getsi();
	    y0 = getsi();
	    line( x, y, x0, y0 );
	    break;
	case 't':
	    l = getstr();
	    label( l );
	    break;
	case 'a':
	    x = getsi();
	    y = getsi();
	    x0 = getsi();
	    y0 = getsi();
	    x1 = getsi();
	    y1 = getsi();
	    arc( x,y, x0, y0, x1, y1 );
	    break;
	case 'c':
	    x = getsi();
	    y = getsi();
	    r = getsi();
	    circle( x, y, r );
	    break;
	case 'e':
	    erase();
	    break;
	case 'f':
	    l = getstr();
	    linemod( l );
	    break;
	case 's':
	    x = getsi();
	    y = getsi();
	    x0 = getsi();
	    y0 = getsi();
	    space( x, y, x0, y0 );
	    break;
	default:
	    fprintf( stderr, "Undefinde plot command 0%o\n", cmd );
	}
    }
    closepl();
}

/* getch() reads a single byte from stdin, not reading EOF more than once,
 * and not returning more than 8 bits.
 */
int getch()
{
    int ch;
    static char eof = '\0';

    if (eof) return EOF;
    
    if ( (ch = getchar()) == EOF ) {
	eof = '\1';
	return EOF;
    }
    return ch&0377;
}

/* getsi() return a signed short integer, big endian and sign extending.
 * Returns EOF on end of file.
 */
int getsi()
{
    int m, n;
    int val;

    n = getch();
    if ( n == EOF )
	return EOF;

    m = getch();
    if ( m == EOF )
	return EOF;

#ifdef BIG_ENDIAN
    val = ((m << 8) | n);
#else
    val = ((n << 8) | m);
#endif
    if ( val & 0x8000 )
	val |= ~0x7fff;
    return val;
}

/* getstr() reads a string from stdin.  The string is terminated by EOF,
 * newline or '\0'.
 */
char *getstr()
{
    char str[1024];
    char *s = str;
    int ch;

    while ( (ch = getch()) != EOF && ch != '\n' && ch != '\0' )
	*s++ = ch;
    *s = '\0';

    return str;
}

    
