/*
    This file is part of plot2ps.

    Copyright (C) 1989 Rene' Seindal

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

    My current address is: seindal@diku.dk
*/

#include "defs.h"

#define PI  ((double)3.14159265358979323844)
#define radtodeg(x)  ((double)(x)*180.0/PI)

arc(x, y, x0, y0, x1, y1)
{
    double theta0, theta1, rad;
    int rx0, ry0, rx1, ry1;

    rx0 = x0 - x;
    ry0 = y0 - y;
    rx1 = x1 - x;
    ry1 = y1 - y;

    rad = hypot( X(x0) - X(x), Y(y0) - Y(y) );
    theta0 = (rx0 == 0) ? 180.0 : radtodeg( atan2((double)ry0, (double)rx0) );
    theta1 = (rx1 == 0) ? 180.0 : radtodeg( atan2((double)ry1, (double)rx1) );

    clear();
    printf( "%g %g %g %g %g arc\n", X(x), Y(y), rad, theta0, theta1 );
    DIRTYPATH;
}
