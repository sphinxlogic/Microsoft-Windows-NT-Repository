/*
 * Copyright (C) 1987, Thomas H. Smith -- San Francisco, California
 *   Program 'Cassette':
 *	Permission is granted to any individual or institution
 *	to use, copy, modify, or redistribute this software so long as it
 *	is not sold for profit and provided this copyright notice is retained.
 *
 *   PostScript is a registered trademark of Adobe Systems, Inc.
 */
#include <stdio.h>
#include "cassette.h"

main(argc, argv)
int argc;
char *argv[];
{
    FILE *open_file();
    char *album1, *album2;
    int number_songs = FALSE;

    album1 = argv[1];
    album2 = argv[2];

    if (argc > 1) {
	if (strcmp(argv[1], "-n") == 0) {
	    number_songs = TRUE;
	    argc--;
	    album1 = argv[2];
	    album2 = argv[3];
	}
    }

    if ((argc != 3) && (argc != 2)) {
	(void) fprintf(stderr, "usage: %s  [-n] <album1 file> [<album2 file>]",
								    argv[0]);
	exit(1);
    }

    output_ps_globals();
    output_ps_outline();
    if (argc == 2) {
	file_to_postscript(open_file(album1), number_songs, ONLY);
    } else {
	file_to_postscript(open_file(album1), number_songs, SIDE1);
	file_to_postscript(open_file(album2), number_songs, SIDE2);
    }
    output_ps_trailer();
}


FILE *
open_file(filename)
char *filename;
{
    FILE *fd, *fopen();

    fd = fopen(filename, "r");
    if (fd == NULL) {
	perror(filename);
	exit(1);
    }
    return(fd);
}


file_to_postscript(file, number_songs, position)
FILE *file;
int number_songs, position;
{
    char *title, *artist, *noise_red, **songs1, **songs2;
    int noise_type;
    extern char *input_title(), *input_artist(), *input_noise_reduction();
    extern char **input_songs();

    artist = input_artist(file);
    title = input_title(file);
    noise_red = input_noise_reduction(file, &noise_type);
    songs1 = input_songs(file);
    if (position == ONLY)		/* look for two-record sets */
	songs2 = input_songs(file);

    output_ps_artist(title, artist, position);
    output_ps_title(title, artist, position);
    output_ps_noise_reduction(noise_red, noise_type, position);
    if ((position == ONLY) && (songs2[0] != NULL)) {
	output_ps_songs(songs1, number_songs, SIDE1);
	output_ps_songs(songs2, number_songs, SIDE2);
    } else {
	output_ps_songs(songs1, number_songs, position);
    }

    (void) free(artist);
    (void) free(title);
    (void) free(noise_red);
    free_song_list(songs1);
    if (position == ONLY)
	free_song_list(songs2);
}
