/*
 * Copyright (C) 1987, Thomas H. Smith -- San Francisco, California
 *   Program 'Cassette':
 *	Permission is granted to any individual or institution
 *	to use, copy, modify, or redistribute this software so long as it
 *	is not sold for profit and provided this copyright notice is retained.
 *
 *   PostScript is a registered trademark of Adobe Systems, Inc.
 */

/* dimension tweaks dimensions in points */
#define VSPACE		4.0	/* vertical whitespace border */
#define HSPACE		6.0	/* horizontal whitespace border */
#define BORDERWIDTH	2.0	/* width of outline border */
#define DASHWIDTH	0.25	/* width of interior dashed lines */
#define CHARFUDGE	1.0	/* fudge for vertically centering text */

/* dimensions of dolby symbol */
#define DOLBY_HEIGHT	5.0
#define DOLBY_WIDTH	(DOLBY_HEIGHT+1.0)
#define DOLBY_RADIUS	(DOLBY_HEIGHT / 2.0)

/* font used for album title */
#define TITLEFONT	"Helvetica-Bold"
#define TITLESIZE	10.0

/* font used for secondary album title */
#define TITLE2FONT	"Times-Italic"
#define TITLE2SIZE	9.0

/* font used for album artist */
#define ARTISTFONT	"Helvetica"
#define ARTISTSIZE	10.0

/* font used for noise reduction */
#define NOISEFONT	"Helvetica"
#define NOISESIZE	5.0

/* font used for song list */
#define SONGFONT	"Times-Roman"
#define SONGSIZE	8.0

/* dimensions of cassette label in inches */
#define EDGEHEIGHT	0.5	/* height of label edge */
#define BODYHEIGHT	2.5	/* height of label body */
#define WIDTH		4.0	/* width of entire label */

#define CONTINUEDIST	0.75	/* indent for long song name continuation */

/* width of overhang tab */
#define TABWIDTH	(WIDTH - (TABDELTA * 2.0))
#define TABSHORTHEIGHT	0.25	/* height of short portion of overhang tab */
#define TABDELTA	0.25	/* delta between short and tall tab portions */
