/*
 * Copyright (C) 1987, Thomas H. Smith -- San Francisco, California
 *   Program 'Cassette':
 *	Permission is granted to any individual or institution
 *	to use, copy, modify, or redistribute this software so long as it
 *	is not sold for profit and provided this copyright notice is retained.
 *
 *   PostScript is a registered trademark of Adobe Systems, Inc.
 *   The name 'Dolby' and the Dolby symbol are trademarks
 *	of Dolby Industries, Inc.
 */
#include <stdio.h>
#include "dimensions.h"
#include "cassette.h"


output_ps_globals()
{
    /* global definitions */
    OUTPUT("%%\tglobals\n");
    OUTPUT("/inches { 72 mul } def\n");
    OUTPUT("/currentx { currentpoint pop } def\n");
    OUTPUT("/currenty { currentpoint exch pop } def\n");
    OUTPUT("/lowerdone { false } def\n");
    OUTPUT("/doscalefont {\n  dup dup /maxfontsize exch def\n");
    OUTPUT("  /fontsize exch def scalefont\n} def\n");
    OUTPUT("/adjustfont {\n  dup /fontsize exch fontsize mul def\n");
    OUTPUT("  scalefont\n} def\n");
    OUTPUT("/interline { fontsize 1.33 mul } def\n");
    OUTPUT("/creturn { linestart currenty interline sub moveto } def\n");

    OUTPUT("/overflowsline {");
    OUTPUT("  stringwidth pop currentx add lineend ge } def\n");
    OUTPUT("/indent { %.3f inches 0 rmoveto } def\n", CONTINUEDIST);
    OUTPUT("/breakline {\n  {\n    ( ) search exch\n");
    OUTPUT("    dup overflowsline {\n      creturn pageoverflow indent\n");
    OUTPUT("    } if show\n    {\t%% test of search\n      show\n");
    OUTPUT("    } { exit } ifelse\n  } loop\n} def\n");

    OUTPUT("/shrinkshow {\n  {\n    dup overflowsline {\n");
    OUTPUT("      currentfont .9 adjustfont setfont\n");
    OUTPUT("      fontsize maxfontsize 2 div 1 add le {\n");
    OUTPUT("        /oldindent /indent load def /indent { } def\n");
    OUTPUT("        0 fontsize rmoveto breakline\n");
    OUTPUT("        /indent /oldindent load def\n");
    OUTPUT("        exit\n      } if\n");
    OUTPUT("    } {\n      linestart currenty moveto\n");
    OUTPUT("      show exit\n    } ifelse\n  } loop\n} def\n");

    OUTPUT("/elipsesshow {\n  dup overflowsline {\n");
    OUTPUT("    {\n      ( ) search exch dup overflowsline {\n");
    OUTPUT("        (...) show pop { pop } if pop exit\n");
    OUTPUT("      } {\n        show\n      } ifelse\n");
    OUTPUT("      {\t%%test of search\n        show\n");
    OUTPUT("      } { exit } ifelse\n    } loop\n");
    OUTPUT("  } { show } ifelse\n} def\n");

    OUTPUT("/pageoverflow {\n  currenty %.3f le lowerdone not and {\n",
							VSPACE + BORDERWIDTH);
    OUTPUT("    dolowerblock linestart -%.3f moveto\n  } if\n} def\n",
					    SONGSIZE + VSPACE + BORDERWIDTH);

    OUTPUT("/dosong {\n  pageoverflow\n");
    OUTPUT("  dup overflowsline {\n    breakline\n");
    OUTPUT("  } {\n    show\n  } ifelse\n  creturn\n");
    OUTPUT("} def\n");

    /* extra lower outline if necessary */
    OUTPUT("%%\textra lower block outline\n");
    OUTPUT("/dolowerblock {\n");
    OUTPUT("  gsave newpath [] 0 setdash 0 0 moveto\n");
    OUTPUT("  0 -%.3f inches lineto\n", BODYHEIGHT);
    OUTPUT("  %.3f inches -%.3f inches lineto\n", WIDTH, BODYHEIGHT);
    OUTPUT("  %.3f inches 0 lineto\n", WIDTH);

    OUTPUT("  %.3f setlinewidth stroke\n", BORDERWIDTH);
    OUTPUT("  0 0 moveto %.3f inches 0 lineto\n", WIDTH);
    OUTPUT("  %.3f setlinewidth stroke\n", (BORDERWIDTH * 2));

    OUTPUT("  %.3f inches -%.3f inches %.3f add moveto\n", WIDTH / 2.0,
					    BODYHEIGHT, VSPACE + BORDERWIDTH);
    OUTPUT("  %.3f inches -%.3f lineto\n", WIDTH / 2.0,
						VSPACE + (BORDERWIDTH / 2));
    OUTPUT("  [.3 1] 0 setdash %.3f setlinewidth stroke\n", DASHWIDTH);
    OUTPUT("  /lowerdone { true } def\n");
    OUTPUT("  grestore\n} def\n");

    output_ps_dolby();
}


output_ps_outline()
{
    OUTPUT("\n%%\toutline of label\n");

    /* body of label */
    OUTPUT("newpath\n");
    OUTPUT("0 0 moveto\n");
    OUTPUT("0 %.3f inches lineto\n", BODYHEIGHT + EDGEHEIGHT);
    OUTPUT("%.3f inches %.3f inches lineto\n",
					WIDTH, BODYHEIGHT + EDGEHEIGHT);
    OUTPUT("%.3f inches 0 lineto\n", WIDTH);
    OUTPUT("closepath %.3f setlinewidth stroke\n", BORDERWIDTH);

    /* edge of label */
    OUTPUT("newpath\n");
    OUTPUT("0 %.3f inches moveto\n", BODYHEIGHT);
    OUTPUT("%.3f inches %.3f inches lineto\n", WIDTH, BODYHEIGHT);
    OUTPUT("0 %.3f inches moveto\n", BODYHEIGHT + EDGEHEIGHT);
    OUTPUT("%.3f inches %.3f inches lineto\n",
					WIDTH, BODYHEIGHT + EDGEHEIGHT);
    OUTPUT("%.3f setlinewidth stroke\n", BORDERWIDTH * 2);

    /* overhang of label */
    OUTPUT("newpath\n");
    OUTPUT("0 %.3f inches moveto\n", BODYHEIGHT + EDGEHEIGHT);
    OUTPUT("0 %.3f inches rlineto %.3f inches 0 rlineto\n", TABSHORTHEIGHT,
		((WIDTH - TABWIDTH) / 2.0) - TABDELTA);
    OUTPUT("%.3f inches %.3f inches rlineto\n", TABDELTA, TABDELTA);
    OUTPUT("%.3f inches 0 rlineto\n", TABWIDTH);
    OUTPUT("%.3f inches -%.3f inches rlineto\n", TABDELTA, TABDELTA);
    OUTPUT("%.3f inches %.3f inches lineto\n",
			    WIDTH, BODYHEIGHT + EDGEHEIGHT + TABSHORTHEIGHT);
    OUTPUT("0 -%.3f inches rlineto\n", TABSHORTHEIGHT);
    OUTPUT("%.3f setlinewidth stroke\n", BORDERWIDTH);

    /* dashed interior lines */
    OUTPUT("\n%%\tdashed interior lines\n");

    OUTPUT("newpath\n");
    OUTPUT("0 %.3f inches %.3f sub moveto\n", BODYHEIGHT,
				    TITLE2SIZE + (VSPACE * 2) + BORDERWIDTH);
    OUTPUT("%.3f inches %.3f inches %.3f sub lineto\n", WIDTH, BODYHEIGHT,
				    TITLE2SIZE + (VSPACE * 2) + BORDERWIDTH);

    OUTPUT("%.3f inches %.3f inches %.3f sub moveto\n", WIDTH / 2.0,
					    BODYHEIGHT, VSPACE + BORDERWIDTH);
    OUTPUT("%.3f inches %.3f lineto\n", WIDTH / 2.0,
						VSPACE + (BORDERWIDTH / 2));

    OUTPUT("[.3 1] 0 setdash %.3f setlinewidth stroke\n", DASHWIDTH);
}


output_ps_trailer()
{
    OUTPUT("showpage\n");
}


static
output_ps_dolby()
{
    OUTPUT("%%\t\tDolby trademark symbol\n");
    OUTPUT("%%\t\t\tThe name Dolby and this symbol\n");
    OUTPUT("%%\t\t\tare trademarks of Dolby Industries, Inc.\n");
    OUTPUT("/dolby {\n");
    OUTPUT("  gsave -%.3f 0 rmoveto currentpoint newpath\n", DOLBY_WIDTH);
    OUTPUT("  %.3f add %.3f -90 90 arc\n", DOLBY_RADIUS, DOLBY_RADIUS);
    OUTPUT("  currentx %.3f add currenty %.3f sub %.3f 90 -90 arc\n",
				    DOLBY_WIDTH, DOLBY_RADIUS, DOLBY_RADIUS);
    OUTPUT("  -%.3f 0 rmoveto\n", DOLBY_WIDTH);
    OUTPUT("  0 setgray currentpoint fill moveto\n");

    /* line around it */
    OUTPUT("  0 %.3f rlineto %.3f 0 rlineto\n",
					    DOLBY_HEIGHT, DOLBY_WIDTH);
    OUTPUT("  0 -%.3f rlineto -%.3f 0 rlineto\n",
					    DOLBY_HEIGHT, DOLBY_WIDTH);
    OUTPUT("  [] 0 setdash 0 setlinewidth currentpoint stroke moveto\n");

    /* line through center */
    OUTPUT("  %.3f 0 rmoveto 0 %.3f rlineto\n",
					DOLBY_WIDTH / 2.0, DOLBY_HEIGHT);
    OUTPUT("  1 setgray stroke\n");
    OUTPUT("  grestore\n} def\n");
}
