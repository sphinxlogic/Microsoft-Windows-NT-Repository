/*
 * Copyright (C) 1987, Thomas H. Smith -- San Francisco, California
 *   Program 'Cassette':
 *	Permission is granted to any individual or institution
 *	to use, copy, modify, or redistribute this software so long as it
 *	is not sold for profit and provided this copyright notice is retained.
 *
 *   PostScript is a registered trademark of Adobe Systems, Inc.
 */

#define TRUE	(1)
#define FALSE	(0)

/* cassette sides */
#define ONLY	0
#define SIDE1	1
#define SIDE2	2

/* recognized noise reduction types */
#define NONE	0
#define DOLBY_B	1
#define DOLBY_C	2
#define DBX	3
#define OTHER	4

#define OUTPUT			(void) printf
#define EMPTYSTRING(str)	(str[0] == '\0')
