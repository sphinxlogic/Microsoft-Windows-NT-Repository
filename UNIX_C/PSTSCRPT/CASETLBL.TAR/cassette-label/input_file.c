/*
 * Copyright (C) 1987, Thomas H. Smith -- San Francisco, California
 *   Program 'Cassette':
 *	Permission is granted to any individual or institution
 *	to use, copy, modify, or redistribute this software so long as it
 *	is not sold for profit and provided this copyright notice is retained.
 *
 *   PostScript is a registered trademark of Adobe Systems, Inc.
 */
#include <stdio.h>
#include <ctype.h>
#include "cassette.h"

static char buffer[BUFSIZ];
static char *bufferlist[BUFSIZ];
char *create_string(), *strip_white();


char *
input_title(fd)
FILE *fd;
{
    buffer[0] = '\0';
    (void) fgets(buffer, BUFSIZ, fd);
    /* nuke trailing newline */
    buffer[strlen(buffer) - 1] = '\0';
    escape_parens(buffer);
    return(create_string(strip_white(buffer)));
}


char *
input_artist(fd)
FILE *fd;
{
    buffer[0] = '\0';
    (void) fgets(buffer, BUFSIZ, fd);
    /* nuke trailing newline */
    buffer[strlen(buffer) - 1] = '\0';
    escape_parens(buffer);
    return(create_string(strip_white(buffer)));
}


char *
input_noise_reduction(fd, noise_type)
FILE *fd;
int *noise_type;
{
    char *noise;

    buffer[0] = '\0';
    (void) fgets(buffer, BUFSIZ, fd);
    /* nuke trailing newline */
    buffer[strlen(buffer) - 1] = '\0';
    escape_parens(buffer);
    noise = create_string(strip_white(buffer));

    /* see if this is a common noise reduction type */
    if (noise[0] == '\0') {
	*noise_type = NONE;
    } else if ((strncmp(noise, "dolby", 5) == 0) ||
				(strncmp(noise, "Dolby", 5) == 0)) {
	if ((noise[strlen(noise)-1] == 'c') || (noise[strlen(noise)-1] == 'C'))
	    *noise_type = DOLBY_C;
	else
	    *noise_type = DOLBY_B;
    } else if ((strcmp(noise, "dbx") == 0) || (strcmp(noise, "DBX") == 0)) {
	*noise_type = DBX;
    } else {
	*noise_type = OTHER;
    }

    return(noise);
}


char **
input_songs(fd)
FILE *fd;
{
    register int index;
    char **returnlist;
    extern char *malloc();

    buffer[0] = '\0';
    for (index = 0; index < BUFSIZ; index++) {
	if (fgets(buffer, BUFSIZ, fd) == NULL)
	    break;
	/* nuke trailing newline */
	buffer[strlen(buffer) - 1] = '\0';
	if (EMPTYSTRING(buffer))
	    break;
	escape_parens(buffer);
	bufferlist[index] = create_string(strip_white(buffer));
    }

    returnlist = (char **) malloc((unsigned) index * sizeof(char *) + 1);
    bcopy((char *) bufferlist, (char *) returnlist, index * sizeof(char *));
    returnlist[index] = (char *) NULL;
    return(returnlist);
}


free_song_list(songs)
char **songs;
{
    register int index;

    for (index = 0; songs[index] != NULL; index++)
	(void) free(songs[index]);
    free((char *) songs);
}


static
escape_parens(srcbuffer)
char *srcbuffer;
{
    register char *src, *dest;
    char destbuffer[BUFSIZ];
    extern char *strcpy();

    for (src = srcbuffer, dest = destbuffer;
			    (dest < &(destbuffer[BUFSIZ-1])) && (*src != '\0');
			    src++, dest++) {
	if ((*src == '(') || (*src == ')'))
	    *dest++ = '\\';
	*dest = *src;
    }
    *dest = '\0';
    (void) strcpy(srcbuffer, destbuffer);
}


static char *
strip_white(string)
char *string;
{
    register char *begin, *end;

    for (begin = string; isspace(*begin) && (*begin != '\0'); begin++) ;
    for (end = &(begin[strlen(string) - 1]);
				isspace(*end) && (end != begin); end--) ;
    if (end != begin)
	*++end = '\0';

    return(begin);
}


static char *
create_string(str)
char *str;
{
    char *newstring;
    extern char *malloc(), *strcpy();

    newstring = malloc((unsigned) strlen(str) + 1);
    (void) strcpy(newstring, str);
    return(newstring);
}
