/*
 * Copyright (C) 1987, Thomas H. Smith -- San Francisco, California
 *   Program 'Cassette':
 *	Permission is granted to any individual or institution
 *	to use, copy, modify, or redistribute this software so long as it
 *	is not sold for profit and provided this copyright notice is retained.
 *
 *   PostScript is a registered trademark of Adobe Systems, Inc.
 */
#include <stdio.h>
#include "dimensions.h"
#include "cassette.h"


output_ps_artist(title, artist, position)
char *title, *artist;
int position;
{
    OUTPUT("\n%%\tArtist\n");
    if (EMPTYSTRING(title)) {
	OUTPUT("%%\t\tNo artist specified\n");
	return;
    }

    OUTPUT("/%s findfont %.3f doscalefont setfont\n", ARTISTFONT, ARTISTSIZE);
    switch (position) {
	case ONLY:
	    OUTPUT("/linestart {\n  %.3f inches\n", WIDTH / 2.0);
	    OUTPUT("  (%s) stringwidth pop 2 div sub\n} def\n", artist);
	    OUTPUT("/lineend %.3f inches %.3f sub def\n", WIDTH, HSPACE);
	    break;
	case SIDE1:
	    OUTPUT("/linestart %.3f def\n", HSPACE + (BORDERWIDTH / 2));
	    OUTPUT("/lineend %.3f inches %.3f sub def\n", WIDTH / 2.0, HSPACE);
	    break;
	case SIDE2:
	    OUTPUT("/linestart %.3f inches def\n", WIDTH / 2.0);
	    OUTPUT("/lineend %.3f inches %.3f sub def\n", WIDTH, HSPACE);
	    break;
    }

    OUTPUT("linestart %.3f inches %.3f sub moveto\n",
				    BODYHEIGHT + EDGEHEIGHT,
				    ARTISTSIZE + VSPACE +
				    BORDERWIDTH - CHARFUDGE);

    OUTPUT("(%s) shrinkshow\n", artist);
}


output_ps_title(title, artist, position)
char *title, *artist;
int position;
{
    OUTPUT("\n%%\tTitle\n");
    OUTPUT("/%s findfont %.3f doscalefont setfont\n", TITLEFONT, TITLESIZE);

    if (EMPTYSTRING(title)) {
	/* self-titled -- use artist for title */
	title = artist;
    }

    switch (position) {
	case ONLY:
	    OUTPUT("/linestart {\n  %.3f inches\n", WIDTH / 2.0);
	    OUTPUT("  (%s) stringwidth pop 2 div sub\n} def\n", title);
	    OUTPUT("/lineend %.3f inches %.3f sub def\n", WIDTH, HSPACE);
	    break;
	case SIDE1:
	    OUTPUT("/linestart %.3f def\n", HSPACE + (BORDERWIDTH / 2));
	    OUTPUT("/lineend %.3f inches %.3f sub def\n", WIDTH / 2.0, HSPACE);
	    break;
	case SIDE2:
	    OUTPUT("/linestart %.3f inches def\n", WIDTH / 2.0);
	    OUTPUT("/lineend %.3f inches %.3f sub def\n", WIDTH, HSPACE);
	    break;
    }

    OUTPUT("linestart %.3f inches %.3f add moveto\n", BODYHEIGHT,
				    VSPACE + BORDERWIDTH + CHARFUDGE);

    if (title == artist) {
	/* if self-titled, center title vertically */
	OUTPUT("0 %.3f inches %.3f sub rmoveto\n", EDGEHEIGHT / 2.0,
				    VSPACE + BORDERWIDTH + (TITLESIZE / 2.0));
    }

    OUTPUT("(%s) shrinkshow\n", title);

    /* secondary title */
    OUTPUT("\n%%\tSecondary Title\n");
    OUTPUT("/%s findfont %.3f doscalefont setfont\n", TITLE2FONT, TITLE2SIZE);

    switch (position) {
	case ONLY:
	case SIDE1:
	    OUTPUT("/linestart %.3f def\n", HSPACE + (BORDERWIDTH / 2));
	    OUTPUT("/lineend %.3f inches %.3f sub def\n",
					(WIDTH / 2.0) - .33, HSPACE);
	    break;
	case SIDE2:
	    OUTPUT("/linestart %.3f inches %.3f add def\n", WIDTH / 2.0,
					HSPACE + (DASHWIDTH / 2));
	    OUTPUT("/lineend %.3f inches %.3f sub def\n", WIDTH - .33, HSPACE);
	    break;
    }

    OUTPUT("linestart %.3f inches %.3f sub moveto\n", BODYHEIGHT,
					TITLE2SIZE + VSPACE + BORDERWIDTH);
    OUTPUT("(%s) elipsesshow\n", title);
}


output_ps_noise_reduction(noise_red, noise_type, position)
char *noise_red;
int noise_type, position;
{
    OUTPUT("\n%%\tNoise reduction symbol\n");
    if (noise_type == NONE) {
	OUTPUT("%%\t(None specified)\n");
	return;
    }

    OUTPUT("/%s findfont %.3f doscalefont setfont\n",
						    NOISEFONT, NOISESIZE);
    if ((position == ONLY) || (position == SIDE1)) {
	OUTPUT("%.3f inches %.3f sub %.3f inches %.3f sub moveto\n",
				    WIDTH / 2.0,
				    HSPACE + (DASHWIDTH / 2), BODYHEIGHT,
				    TITLE2SIZE + VSPACE + BORDERWIDTH);
    } else /* SIDE2 */ {
	OUTPUT("%.3f inches %.3f sub %.3f inches %.3f sub moveto\n",
				    WIDTH,
				    HSPACE + (BORDERWIDTH / 2), BODYHEIGHT,
				    TITLE2SIZE + VSPACE + BORDERWIDTH);
    }

    switch (noise_type) {
	case DOLBY_B:
	    OUTPUT("dolby\n");
	    return;
	case DOLBY_C:
	    OUTPUT("( C) stringwidth pop -1 mul 0 rmoveto dolby ( C) show\n");
	    return;
	/* case DBX: */
    }

    /* other type of noise reduction */
    OUTPUT("(%s) stringwidth pop -1 mul 0 rmoveto\n", noise_red);
    OUTPUT("(%s) show\n", noise_red);
}


output_ps_songs(songs, number_songs, position)
char **songs;
int number_songs, position;
{
    register int index;

    OUTPUT("\n%%\tSong list\n");
    OUTPUT("/%s findfont %.3f doscalefont setfont\n", SONGFONT, SONGSIZE);

    if ((position == ONLY) || (position == SIDE1)) {
	OUTPUT("/linestart %.3f def\n", HSPACE + (BORDERWIDTH / 2));
	OUTPUT("/lineend %.3f inches %.3f sub def\n",
					WIDTH / 2.0, HSPACE + (DASHWIDTH / 2));
    } else /* SIDE2 */ {
	OUTPUT("/linestart %.3f inches %.3f add def\n",
					WIDTH / 2.0, HSPACE + (DASHWIDTH / 2));
	OUTPUT("/lineend %.3f inches %.3f sub def\n",
					WIDTH, HSPACE + (BORDERWIDTH / 2));
    }

    /* starting position */
    OUTPUT("\nlinestart %.3f inches %.3f sub moveto\n", BODYHEIGHT,
					TITLE2SIZE + SONGSIZE + (VSPACE * 3)
						    + BORDERWIDTH + DASHWIDTH);

    /* array of song titles */
    OUTPUT("[\n");
    for (index = 0; songs[index] != NULL; index++) {
	if (number_songs)
	    OUTPUT("  (%d.   %s)\n", index + 1, songs[index]);
	else
	    OUTPUT("  (%s)\n", songs[index]);
    }
    OUTPUT("] { dosong } forall\n");
}
