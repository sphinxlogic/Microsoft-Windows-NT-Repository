/*
** Project:		lj2ps
** File:		ljcmds.h
**
** Author:		Christopher Lishka
** Organization:	Wisconsin State Laboratory of Hygiene
**			Data Processing Dept.
**
** Copyright (C) 1990 by Christopher Lishka.
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 1, or (at your option)
** any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef LJCMDS_H
#define LJCMDS_H

  /* Global constants
  */

  /* Global structure and type definitions
  */

  /* Global variables
  */

  /* Global macro definitions
  */

  /* Global functions
  */
extern void  ljcmd_undefined();	/* Command: undefined */
extern void  ljcmd_E();		/* Command: ^[E  reset */
extern void  ljcmd_Y();		/* Command: ^[Y  display functions on */
extern void  ljcmd_Z();		/* Command: ^[Z  display functions off */
extern void  ljcmd_9();		/* Command: ^[9  clear margins */
extern void  ljcmd_eq();	/* Command: ^[=  half-line feed */
extern void  ljcmd_lp();	/* Command: ^[(  primary symbol set */
extern void  ljcmd_rp();	/* Command: ^[)  secondary symbol set */
extern void  ljcmd_lp_s();	/* Command: ^[(s primary font attributes */
extern void  ljcmd_rp_s();	/* Command: ^[)s secondary font attributes */
extern void  ljcmd_amp_a();	/* Command: ^[&a margins & movement */
extern void  ljcmd_amp_d();	/* Command: ^[&d underline */
extern void  ljcmd_amp_f();	/* Command: ^[&f macros, position stack */
extern void  ljcmd_amp_k();	/* Command: ^[&k HMI, pitch, line termination*/
extern void  ljcmd_amp_l();	/* Command: ^[&l page attributes */
extern void  ljcmd_amp_p();	/* Command: ^[&p transparent print data */
extern void  ljcmd_amp_s();	/* Command: ^[&s end-of-line wrap */
extern void  ljcmd_star_b();	/* Command: ^[*b bitmap transfer */
extern void  ljcmd_star_c();	/* Command: ^[*c graphics, soft fonts */
extern void  ljcmd_star_p();	/* Command: ^[*p device-dependent movement */
extern void  ljcmd_star_r();	/* Command: ^[*r start/end graphics */
extern void  ljcmd_star_t();	/* Command: ^[*t graphics resolution */

#endif
