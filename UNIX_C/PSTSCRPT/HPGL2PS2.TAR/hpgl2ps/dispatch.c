/*
        HPGL to PostScript converter
   Copyright (C) 1988 (and following) Federico Heinz

yahp2ps is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY.  No author or distributor accepts responsibility to anyone
for the consequences of using it or for whether it serves any
particular purpose or works at all, unless he says so in writing.
Refer to the Free Software Foundation's General Public License for full details.

Everyone is granted permission to copy, modify and redistribute yahp2ps,
but only under the conditions described in the GNU General Public
License.  A copy of this license is supposed to have been given to you
along with yahp2ps so you can know your rights and responsibilities.  It
should be in a file named COPYING.  Among other things, the copyright
notice and this notice must be preserved on all copies.

In other words, go ahead and share yahp2ps, but don't try to stop
anyone else from sharing it farther.  Help stamp out software hoarding!

yahp2ps is TOTALLY unrelated to GNU or the Free Software Foundation,
it is only released under the same conditions.

    For bug reports, wishes, etc. send e-mail to

    ...!mcvax!unido!tub!actisb!federico  (from Europe)
    ...!uunet!pyramid!actisb!federico    (from anywhere else)

    For Physical mail:

    Federico Heinz
    Beusselstr. 21
    1000 Berlin 21

    Tel. (+49 30) 396 77 92

*/
/**************************************************************************

  Main loop. Here's where the decoding takes place.

**************************************************************************/



#include "defs.h"
#include "dispatch.h"
#include "mchinery.h"
#include "io.h"


/*

  A command that does not make sense in a PostScript environment.

*/

CommandImplementation notImplemented()

{ warning("Useless command skipped.");
  endCommand();
}



/*

  A command that requires Plotter-Computer interaction in real time.

*/

CommandImplementation interactive()

{ error("Cannot handle commands requiring Plotter-Computer interaction.");
}



typedef CommandImplementation (*CommandPointer)();


static CommandPointer DoCommand[] =
  {     notImplemented,
        interactive,
        arcAbsolute,
        arcRelative,
        setAlternateChar,
        circle,
        characterPlot,
        setStandardChar,
        setDefaults,
        setAbsoluteDirection,
        setRelativeDirection,
        setLabelTerminator,
        rectangleAbsolute,
        rectangleRelative,
        wedge,
        setFillType,
        initialize,
        inputP1P2,
        inputWindow,
        putASCIILabel,
        setLineType,
        setAbsolutePlot,
        penDown,
        setRelativePlot,
        setPaperSize,
        penUp,
        shadeRectAbsolute,
        rotateCoordSys,
        shadeRectRelative,
        selectAlternate,
        setScale,
        setAbsoluteCharSize,
        setAbsoluteCharSlant,
        setSymbolMode,
        selectPen,
        setRelativeCharSize,
        selectStandard,
        setTickLength,
        userChar,
        shadeWedge,
        xTick,
        yTick,
	penThickness
  };



/*

  Process a whole HPGL document.

*/

void dispatch()

{   skipSeparator();
   while (LookAhead != EOF) (*DoCommand[getCommand()])();
}


