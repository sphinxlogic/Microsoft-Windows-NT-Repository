/*
        HPGL to PostScript converter
   Copyright (C) 1988 (and following) Federico Heinz

yahp2ps is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY.  No author or distributor accepts responsibility to anyone
for the consequences of using it or for whether it serves any
particular purpose or works at all, unless he says so in writing.
Refer to the Free Software Foundation's General Public License for full details.

Everyone is granted permission to copy, modify and redistribute yahp2ps,
but only under the conditions described in the GNU General Public
License.  A copy of this license is supposed to have been given to you
along with yahp2ps so you can know your rights and responsibilities.  It
should be in a file named COPYING.  Among other things, the copyright
notice and this notice must be preserved on all copies.

In other words, go ahead and share yahp2ps, but don't try to stop
anyone else from sharing it farther.  Help stamp out software hoarding!

yahp2ps is TOTALLY unrelated to GNU or the Free Software Foundation,
it is only released under the same conditions.

    For bug reports, wishes, etc. send e-mail to

    ...!mcvax!unido!tub!actisb!federico  (from Europe)
    ...!uunet!pyramid!actisb!federico    (from anywhere else)

    For Physical mail:

    Federico Heinz
    Beusselstr. 21
    1000 Berlin 21

    Tel. (+49 30) 396 77 92

*/
#include <stdio.h>
#include "defs.h"
#include "dispatch.h"
#include "mchinery.h"

Number TN;  /* Temporary storage for Number math */

main(argc, argv)

int argc;
char **argv;

{ while (--argc)
  { argv++;
    if (**argv == '-')
      switch(*((*argv)+1))
      { case 'l':
          if (argc-1)
          { getPenSizes(*(++argv));
            argc--;
          }
          break;
        case 'o':
          if (argc-1)
          { if (!setOutput(*(++argv)))
              error("Unable to open target file.");
            argc--;
          }
          break;
        case 'p':
          if (argc-1)
          { if (PreludeFile != NULL)
              PreludeFile = *(++argv);
            argc--;
          }
          break;
        case 's':
          PreludeFile = NULL;
          break;
        default:
          error("Usage: hpgl2ps [-l <linesizes>] [-p <preludefile>] [-s] [-o <outputfile>] inputfile");
          break;
      }
    else
      if (!setInput(*argv))
        error("Unable to open source file.");
  }
  initializeMachinery();
  penctrlInit();
  restoreDefaults();
  dispatch();
  shutdownMachinery();
}

