/*	Copyright 1985, 1986, 1987, 1988 16:51:35 Chris Lewis
		All Rights Reserved

    Permission to copy and further distribute is freely given provided
    this copyright notice remains intact and that this software is not
    sold for profit.

	Project:	Generic Troff drivers
	Module:		lj.h 2.1 90/07/18
	Author: 	Chris Lewis
	Specs:		Laserjet Driver definitions
 */

/*	We're using decipoints */
#define	LJRESOLUTION	720

/*	Troff assumes 7.5" paper width, most macro packages print in
	6.5" area within that.  Sooo, we'll center the paperwidth on the
	physical page - implying .5" inch physical margins.*/
#define	TROFF2LJX(x) (((long) (x)+pageoffset)*LJRESOLUTION/TROFFRESOLUTION)

/*	11" paper length */
#define	TROFF2LJY(y) (((long) (y)+pageyoffset)*LJRESOLUTION/TROFFRESOLUTION)

extern int ljProlog(), ljEpilog(), ljChar(), ljPage();

extern struct troff2befont ljSymFont[], ljStdFont[];

extern int fontCount;
