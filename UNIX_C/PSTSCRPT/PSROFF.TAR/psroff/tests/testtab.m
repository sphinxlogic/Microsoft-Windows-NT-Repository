.\" 2.1 90/07/18
.po .25i
.in 0
.fp 1 R
.fp 2 I
.fp 3 B
.fp 4 S
.ps 12
.vs 14
.sp |.3i
.ce 3
PSROFF TEST SHEET (2.1)
.br
Please fill out and FAX to (416) 595-5439
.br
\*(2d
.ps 10
.vs 12
.TS
l lw(1.2i) l lw(1.2i) l lw(1.2i).

UNIX	_	Hardware:	_	psroff	\*(2v
version				version

Name:	_	E-mail 	_	driver/printer	_
		address		(ps/dt/lj)
.TE
.TS
box;
c s s s s s s s s s s s s s s s
l l | l l | l l | l l | l l | l l | l l | l l.
Normal Font Listing
_
!	!	$	$	%	%	&	&	'	'	(	(	)	)	*	*
_
+	+	,	,	\-	\e-	\.	.	/	/	0	0	1	1	2	2
_
3	3	4	4	5	5	6	6	7	7	8	8	9	9	:	:
_
;	;	\&=	\&=	?	?	A	A	B	B	C	C	D	D	E	E
_
F	F	G	G	H	H	I	I	J	J	K	K	L	L	M	M
_
N	N	O	O	P	P	Q	Q	R	R	S	S	T	T	U	U
_
V	V	W	W	X	X	Y	Y	Z	Z	[	[	]	]	`	`
_
a	a	b	b	c	c	d	d	e	e	f	f	g	g	h	h
_
i	i	j	j	k	k	l	l	m	m	n	n	o	o	p	p
_
q	q	r	r	s	s	t	t	u	u	v	v	w	w	x	x
_
y	y	z	z	|	|	\(hy	\e(hy	\(bu	\e(bu	\(sq	\e(sq	\(em	\e(em	\(ru	\e(ru
_
\(14	\e(14	\(12	\e(12	\(34	\e(34	\(fi	\e(fi	\(fl	\e(fl	\(ff	\e(ff	\(Fi	\e(Fi	\(Fl	\e(Fl
_
\(de	\e(de	\(dg	\e(dg	\(fm	\e(fm	\(rg	\e(rg	\(co	\e(co	\(ct	\e(ct
.T&
c s s s s s s s s s s s s s s s
l l | l l | l l | l l | l l | l l | l l | l l.
=
Symbol Font Listing
_
"	"	#	#	<	<	>	>	@	@	\e	\ee	^	^	\(br	\e(br
_
{	{	}	}	~	~	\(sc	\e(sc	\(aa	\e(aa	\(ga	\e(ga	\(ul	\e(ul	\(sl	\e(sl
_
\(*a	\e(*a	\(*b	\e(*b	\(*g	\e(*g	\(*d	\e(*d	\(*e	\e(*e	\(*z	\e(*z	\(*y	\e(*y	\(*h	\e(*h
_
\(*i	\e(*i	\(*k	\e(*k	\(*l	\e(*l	\(*m	\e(*m	\(*n	\e(*n	\(*c	\e(*c	\(*o	\e(*o	\(*p	\e(*p
_
\(*r	\e(*r	\(*s	\e(*s	\(*t	\e(*t	\(*u	\e(*u	\(*f	\e(*f	\(*x	\e(*x	\(*q	\e(*q	\(*w	\e(*w
_
\(*G	\e(*G	\(*D	\e(*D	\(*H	\e(*H	\(*L	\e(*L	\(*C	\e(*C	\(*P	\e(*P	\(*S	\e(*S	\(*U	\e(*U
_
\(*F	\e(*F	\(*Q	\e(*Q	\(*W	\e(*W	\(sr	\e(sr	\(ts	\e(ts	\(rn	\e(rn	\(>=	\e(>=	\(<=	\e(<=
_
\(==	\e(==	\(mi	\e(mi	\(~=	\e(~=	\(ap	\e(ap	\(!=	\e(!=	\(->	\e(->	\(<-	\e(<-	\(ua	\e(ua
_
\(da	\e(da	\(eq	\e(eq	\(mu	\e(mu	\(di	\e(di	\(+-	\e(+-	\(cu	\e(cu	\(ca	\e(ca	\(sb	\e(sb
_
\(sp	\e(sp	\(ib	\e(ib	\(ip	\e(ip	\(if	\e(if	\(pd	\e(pd	\(gr	\e(gr	\(no	\e(no	\(is	\e(is
_
\(pt	\e(pt	\(es	\e(es	\(mo	\e(mo	\(pl	\e(pl	\(dd	\e(dd	\(rh	\e(rh	\(lh	\e(lh	\(**	\e(**
_
\(bs	\e(bs	\(or	\e(or	\(ci	\e(ci	\(lt	\e(lt	\(lb	\e(lb	\(rt	\e(rt	\(rb	\e(rb	\(lk	\e(lk
_
\(rk	\e(rk	\(bv	\e(bv	\(lf	\e(lf	\(rf	\e(rf	\(lc	\e(lc	\(rc	\e(rc
.TE
.br
!$%&'()*+,\(\-\./0123456789:;=?ABCDEFGHIJKLMNOPQRSTUVWXYZ[
.br
]`abcdefghijklmnopqrstuvwxyz|\(hy\(bu\(sq\(em\(ru\(14\(12\(34\(fi\(fl\(ff\(Fi\(Fl\(de\(dg\(fm\(rg\(co\(ct
.br
"#<>@\e^\(br{}~\(sc\(aa\(ga\(ul\(sl\(*a\(*b\(*g\(*d\(*e\(*z\(*y\(*h\(*i\(*k\(*l\(*m\(*n\(*c\(*o\(*p\(*r\(*s\(*t\(*u\(*f\(*x\(*q\(*w\(*G\(*D\(*H\(*L\(*C\(*P\(*S\(*U\(*F\(*Q\(*W\(sr\(ts\(rn
.br
\(>=\(<=\(==\(mi\(~=\(ap\(!=\(->\(<-\(ua\(da\(eq\(mu\(di\(+-\(cu\(ca\(sb\(sp\(ib\(ip\(if\(pd\(gr\(no\(is\(pt\(es\(mo\(pl\(dd\(rh\(lh\(**\(bs\(or\(ci\(lt\(lb\(rt\(rb\(lk\(rk\(bv\(lf\(rf\(lc\(rc
.br
\f1Roman 10p\fP
\f2Italic 10p\fP
\f3Bold 10p\fP
\f1Roman 10p\fP
\f2Italic 10p\fP
\f3Bold 10p\fP
.br
.ps 16
.vs 18
\f1Roman 16p\fP
\f2Italic 16p\fP
\f3Bold 16p\fP
\f1Roman 16p\fP
\f2Italic 16p\fP
\f3Bold 16p\fP
