.\"Document revision 2.1 90/07/18
.nr Ej 1
.TL
troff2ps testing script.
.AU "Chris Lewis"
.AS 1 10
Ever since the dawn of time, people have been dreaming of being
able to use "troff" on devices other than Wang Cat Phototypesetters.
This is a test document of one such thingie.
.AE
.MT 4 1
.SP 2i
.H 1 "Line Test"
.P
This line should be exactly 5 inches long:
.DS
\l'5i\&\(ru'
.DE
.H 2 "Extended font test"
.P
Extended font test:
.eX I
This is a standard display - this should be
Courier, fixed width.
.eE
.H 2 "Simple paragraphs"
.P
This is some more of the testing.  Can't you tell?
Testing, testing, testing testing.
This book is a practical guide to the \fBUNIX\fP system and all users
from the novice to the expert should find it useful.
Many examples are used throughout the text to illustrate techniques that make
the system attractive to use.  By giving examples of the interactions
between commands, the user is able to take full advantage of the power of the
\fBUNIX\fP system.
.P
This is some more of the testing.  Can't you tell?
Testing, testing, testing testing.
This book is a practical guide to the \fBUNIX\fP system and all users
from the novice to the expert should find it useful.
Many examples are used throughout the text to illustrate techniques that make
the system attractive to use.  By giving examples of the interactions
between commands, the user is able to take full advantage of the power of the
\fBUNIX\fP system.
.H 1 "Lists"
.P
Bullet list:
.BL
.LI
\(<- that was a bullet.
.LI
This is 2
.LI
Dashlist:
.DL
.LI
Dash
.LI
Dasher
.LE
.LE
.H 2 "Ligature test"
.P
Ligature test: fido, flu, duffle, duffin
.P
nroff doesn't like double quotes too much.
"X" should look reasonable.
More 'test` `test'\*F
.FS
This here's a footnote - slightly smaller pitch.
.FE
This is more of the paragraph.
.SK
.H 1 "Different Fonts"
.P
This is normal\f3Bold\fP\f2italic\fPnormal.
This is normal \f3Bold\fP \f2italic\fP normal.
.S 36 38
.P
\(bs
.S
.S 14 26
.P
that was the logo at 36 point.  This sentence is 14 point.
.S
.P
The Logo will be printed whether or not you have raster fonts.
The original logo is a stylized "cX".
If you don't have the vfonts installed, the rest of the line will be
normal characters with big spacing.
If the fonts are installed, you will see 75DPI big print.
.P
This is some more of bigger stuff:
.S 22
Testing
.I Testing
.B Testing
.S
.SP
.S 6
6 Point
.br
.S 7
7 Point
.br
.S 8
8 Point
.br
.S 9
9 Point
.br
.S 10
10 Point
.br
.S 11
11 Point
.br
.S 12
12 Point
.br
.S 14
14 Point
.br
.S 16
16 Point
.br
.S 18
18 Point
.br
.S 20
20 Point
.br
.S 22
22 Point
.br
.S 24
24 Point
.br
.S 28
28 Point
.br
.S 36
36 Point
.br
.S 10
.P
Now, lets have some phun with phonts:
.br
.fp 1 H
.fp 2 HO
.fp 3 HB
.ft 1
This should be Helvetica.
\f2Helvetica Oblique\fP, \f3Helvetica Bold\fP.
.br
.fp 1 BR
.fp 2 BO
.fp 3 BB
.ft 1
.P
This should be Bookman.
\f2Bookman Oblique\fP, \f3Bookman Bold\fP.
.br
.fp 1 R
.fp 2 I
.fp 3 B
.H 3 "Testing 3"
hello 3
.H 4 "Testing 4"
hello 4
.H 5 "Testing 5"
hello 5
.H 6 "Testing 6"
hello 6
.H 7 "Testing 7"
hello 7
.H 1 "Some Equations"
.S 16
Equations:
.S
.DS
.EQ
left [ x sup 2 + y sup 2 over alpha right ] ~=~ 1
.EN
.DE
.br
.DS
.EQ
x dot = f(t) bar
.EN
.DE
.DS
.EQ
lim from {n -> inf} sum from 0 to n x sub i
.EN
.DE
.DS
.EQ
t ~=~ 2 pi int sub 0 sup 1
sin ( sqrt { x sup 2 + a sup 2 } ) dx
.EN
.DE
.\".P
.\"This is a test of piling (though, this isn't eqn):
.\".DS I
.\"\b'\(lt\(lk\(lb'\b'\(lc\(lf x \b'\(rc\(rf\b'\(rt\(rk\(rb'
.\".DE
.H 2 "More Equations"
.DS
.EQ
G(z)~mark =~ e sup { ln ~ G(z) }
~=~ exp left (
sum from k>=1 { S sub k z sup k } over k right )
~=~ prod from k>=1 e sup { S sub k z sup k / k }
.EN
.DE
.DS
.EQ
lineup = left ( 1 + S sub 1 z +
{ S sub 1 sup 2 z sup 2 } over 2! + ... right )
left ( 1 + { S sub 2 z sup 2 } over 2
+ { S sub 2 sup 2 z sup 4 } over { 2 sup 2 cdot 2! }
+ ... right ) ...
.EN
.DE
.DS
.EQ
lineup = sum from m>=0 left (
sum from
pile { k sub 1 ,k sub 2 ,..., k sub m >= 0
above
k sub 1 +2k sub 2 + ... + mk sub m = m }
{ S sub 1 sup { k sub 1 } } over { 1 sup k sub 1 k sub 1 ! } ~
{ S sub 2 sup { k sub 2 } } over { 2 sup k sub 2 k sub 2 ! } ~
{ S sub m sup { k sub m } } over { m sup k sub m k sub m ! }
right ) z sup m
.EN
.DE
.H 2 "Hanging Caps"
.fp 1 PA
.fp 3 PB
.ta 1i
.in +0.6i
.ll -0.3i
.ti -0.3i
\v'1'\s36P\s0\v'-1'ater
.de Xx
'in -0.6i
..
.wh \n(nlu+1.5v Xx
noster qui est
in caelis scanctificetur nomen tuum; adveniat regnum tuum;
fiat voluntus tua, sicut in caelo, et in terra ...
Amen.
Too bad I can't read Latin so I don't know what that line meant.
But it should be a good example of INITIAL hanging caps.
(AND Palatino...)
.fp 1 R
.fp 3 B
.H 1 "tbl output"
.DS
.TS
allbox doublebox;
c c c
l l l.
Command	Reference Section	Action

cc	CP	Compiles C programs
cp	C	Copies files
disk cp	C	Copies archive media
lc	C	Lists files
login	M	Access to the system
troff	CT	Typesets text
.TE
.DE
.DS
.TS
box;
c s s
c | c | c
l | l | n.
Major New York Bridges
=
Bridge	Designer	Length
_
Brooklyn	JA Roebling	1595
Manhattan	G Lindenthal	1470
Williamsburg	LL Buck	1600
_
Queensborough	Palmer &	1182
	  Hornbostel
_
		1380
Triborough	OH Ammann	_
		383
_
Bronx Whitestone	OH Ammann	2300
Throgs Neck	OH Ammann	1800
_
George Washington	OH Ammann	3500
.TE
.DE
.DS
.TS
box;
cfB s s s.
Composition of Foods
_
.T&
c | c s s
c | c s s.
Food	Percent by Weight
\^	_
\^	Protein	Fat	Carbo-
\^	\^	\^	hydrate
_
.T&
l | n | n | n.
Apples	.4	.5	13.0
Halibut	18.4	5.2	...
Lima beans	7.5	.8	22.o
Milk	3.3	4.0	5.0
Mushrooms	3.5	.4	6.0
Rye bread	9.0	.6	52.7
.TE
.DE
.H 1 "A Test of Two Column Output"
.2C
.P
The IBM salesman and the IBM system analyst went to spend
a weekend in the forest, hunting bear.
They hired a log cabin, and when they got there, took
their backpacks off and put them inside.
At which point the salesman said to the systems analyst:
"You unpack while I go and find us a bear."
The analyst finished unpacking and then went and sat
outside to await events. He did not have to wait too long.
Soon he could hear noises in the forest. The noises got
nearer - and suddenly there was the salesman, running
across the clearing toward the cabin, pursued by one of the
largest and most ferocious Brown Bears the analyst had
ever seen.
"Open the door! shouted the salesman.
The analyst opened the door.
The salesman ran to the door, suddenly stopped, and
stepped aside.
The Bear carried by its momentum, continued though the
door and disappeared inside.
The salesman promptly shut the door on it, turned, looked
at the analyst, and said:
"Ok, you skin that one while I go rustle us up another."
.P
The IBM salesman and the IBM system analyst went to spend
a weekend in the forest, hunting bear.
They hired a log cabin, and when they got there, took
their backpacks off and put them inside.
At which point the salesman said to the systems analyst:
"You unpack while I go and find us a bear."
The analyst finished unpacking and then went and sat
outside to await events. He did not have to wait too long.
Soon he could hear noises in the forest. The noises got
nearer - and suddenly there was the salesman, running
across the clearing toward the cabin, pursued by one of the
largest and most ferocious Brown Bears the analyst had
ever seen.
"Open the door! shouted the salesman.
The analyst opened the door.
The salesman ran to the door, suddenly stopped, and
stepped aside.
The Bear carried by its momentum, continued though the
door and disappeared inside.
The salesman promptly shut the door on it, turned, looked
at the analyst, and said:
"Ok, you skin that one while I go rustle us up another."
.P
The IBM salesman and the IBM system analyst went to spend
a weekend in the forest, hunting bear.
They hired a log cabin, and when they got there, took
their backpacks off and put them inside.
At which point the salesman said to the systems analyst:
"You unpack while I go and find us a bear."
The analyst finished unpacking and then went and sat
outside to await events. He did not have to wait too long.
Soon he could hear noises in the forest. The noises got
nearer - and suddenly there was the salesman, running
across the clearing toward the cabin, pursued by one of the
largest and most ferocious Brown Bears the analyst had
ever seen.
"Open the door! shouted the salesman.
.1C
.CS
.TC
