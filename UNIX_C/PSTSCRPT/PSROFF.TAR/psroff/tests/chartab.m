.\"2.1 90/07/18
.lg 1
.DS
.TS
allbox;
cf3 p14 s s s s s
c c c || c c c
l l l || l l l.
Mathematical and Other Characters
=
character	denotation	name	character	denotation	name
=
\(pl	\e(pl	math plus	\(ib	\e(ib	improper subset
\(mi	\e(mi	math minus	\(ip	\e(ip	improper superset
\(eq	\e(eq	math equal	\(if	\e(if	infinity
\(**	\e(**	math star	\(pd	\e(pd	partial derivative
\(sc	\e(sc	section	\(gr	\e(gr	gradient
\(aa	\e\(aa or \e(aa	acute accent	\(no	\e(no	not
\(ga	\e\(ga or \e(ga	grave accent	\(is	\e(is	integral sign
\(ul	\(ul or \e(ul	underrule	\(pt	\e(pt	proportional to
\(sl	\(sl or \e(sl	slash	\(es	\e(es	empty set
\(sr	\e(sr	square root	\(mo	\e(mo	member of
\(rn	\e(rn	root en	\(br	\e(br or |	box rule
\(>=	\e(>=	\(>=	\(dd	\e(dd	dbl dagger
\(<=	\e(<=	\(<=	\(rh	\e(rh	right hand
\(==	\e(==	equivalence	\(lh	\e(lh	left hand
\(~=	\e(~=	approx =	\(or	\e(or	or
\(ap	\e(ap	approximates	\(ci	\e(ci	circle
\(!=	\e(!=	not equal	\(lt	\e(lt	left top of big { and (
\(->	\e(->	right arrow	\(lb	\e(lb	left bot of big { and (
\(<-	\e(<-	left arrow	\(rt	\e(rt	right top of big } and )
\(ua	\e(ua	up arrow	\(rb	\e(rb	right bot of big } and )
\(da	\e(da	down arrow	\(lk	\e(lk	left ctr of big { and (
\(mu	\e(mu	multiply	\(rk	\e(rk	right ctr of big } and )
\(di	\e(di	divide	\(bv	\e(bv	bold vertical
\(+-	\e(+-	plus-minus	\(lf	\e(lf	left floor
\(cu	\e(cu	cup (union)	\(rf	\e(rf	right floor
\(ca	\e(ca	intersection	\(lc	\e(lc	left ceiling
\(sb	\e(sb	subset of	\(rc	\e(rc	right ceiling
\(sp	\e(sp	superset of
.TE
.DE
.P
Alignment test:
.DS
\(sr\(rn
.DE
.P
Ligatures:
fido, floor, snaffle, suffix, shuffle.
.DS
.EQ
sum from i=0 to {i= inf} x sup i
.EN
.EQ
sqrt a+b + 1 over sqrt {ax sup 2 +bx+c}
.EN
.EQ
sqrt {a sup 2 over b sub 2}
.EN
.TS
allbox;
cf3 p14 s s s s s
c c c || c c c
l l l || l l l.
Greek Characters
=
character	denotation	name	character	denotation	name
=
\(*a	\e(*a	alpha	\(*A	\e(*A	Alpha
\(*b	\e(*b	beta	\(*B	\e(*B	Beta
\(*g	\e(*g	gamma	\(*G	\e(*G	Gamma
\(*d	\e(*d	delta	\(*D	\e(*D	Delta
\(*e	\e(*e	epsilon	\(*E	\e(*E	Epsilon
\(*z	\e(*z	zeta	\(*Z	\e(*Z	Zeta
\(*y	\e(*y	eta	\(*Y	\e(*Y	Eta
\(*h	\e(*h	theta	\(*H	\e(*H	Theta
\(*i	\e(*i	iota	\(*I	\e(*I	Iota
\(*k	\e(*k	kappa	\(*K	\e(*K	Kappa
\(*l	\e(*l	lambda	\(*L	\e(*L	Lambda
\(*m	\e(*m	mu	\(*M	\e(*M	Mu
\(*n	\e(*n	nu	\(*N	\e(*N	Nu
\(*c	\e(*c	xi	\(*C	\e(*C	Xi
\(*o	\e(*o	omicron	\(*O	\e(*O	Omicron
\(*p	\e(*p	pi	\(*P	\e(*P	Pi
\(*r	\e(*r	rho	\(*R	\e(*R	Rho
\(*s	\e(*s	sigma	\(*S	\e(*S	Sigma
\(ts	\e(ts	terminal sigma
\(*t	\e(*t	tau	\(*T	\e(*T	Tau
\(*u	\e(*u	upsilon	\(*U	\e(*U	Upsilon
\(*f	\e(*f	phi	\(*F	\e(*F	Phi
\(*x	\e(*x	chi	\(*X	\e(*X	Chi
\(*q	\e(*q	psi	\(*Q	\e(*Q	Psi
\(*w	\e(*w	omega	\(*W	\e(*W	Omega
.TE
.DE
.DS
.TS
allbox;
cf3 p14 s s s s s
c c c || c c c
l l l || l l l.
Non-ASCII Characters and minus on the Standard Fonts
=
character	denotation	name	character	denotation	name
=
\&`	\`	open quote	\(34	\e(34	3/4
\&'	\'	close quote	\(fi	\e(fi	fi
\&``	\`\`	open double quotes	\(fl	\e(fl	fl
\&''	\'\'	close double quotes	\(ff	\e(ff	ff
\(em	\e(em	3/4 em	\(Fi	\e(Fi	ffi
\(hy	\e(hy	- hyphen	\(Fl	\e(Fl	ffl
\-	\e-	minus	\(de	\e(de	degree
\(bu	\e(bu	bullet	\(dg	\e(dg	dagger
\(sq	\e(sq	square	\(fm	\e(fm	foot mark
\(ru	\e(ru	rule	\(ct	\e(ct	cent sign
\(14	\e(14	1/4	\(rg	\e(rg	registered
\(12	\e(12	1/2	\(co	\e(co	copyright
.TE
.DE
.S
