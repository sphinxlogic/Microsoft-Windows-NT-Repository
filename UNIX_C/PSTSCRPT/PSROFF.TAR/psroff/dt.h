/*	Copyright 1985, 1986, 1987, 1988 16:51:29 Chris Lewis
		All Rights Reserved

    Permission to copy and further distribute is freely given provided
    this copyright notice remains intact and that this software is not
    sold for profit.

	Project:	Generic Troff drivers
	Module:		dt.h 2.1 90/07/18
	Author: 	Chris Lewis
	Specs:		Ditroff driver definitions
			Hacked from ps.h
 */

/*	This is actually done in the back-end */
#define	DTRESOLUTION	300
/*	Troff assumes 7.5" paper width, most macro packages print in
	6.5" area within that.  Sooo, we'll center the paperwidth on the
	physical page - implying .5" inch physical margins.*/
#define	TROFF2DTX(x) ((((long) (x)+pageoffset)*dtresolution)/TROFFRESOLUTION)
/*	11" paper length */
#define	TROFF2DTY(y) ((((long) (y)+pageyoffset)*dtresolution)/TROFFRESOLUTION)

extern int dtProlog(), dtEpilog(), dtChar(), dtPage(), dtPassthru();

#ifdef	DT
extern struct troff2befont dtSymFont[], dtStdFont[];
extern int dtresolution;
#endif
