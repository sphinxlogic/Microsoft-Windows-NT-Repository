/*
 * Copyright (C) Crispin Goswell 1987, All Rights Reserved.
 */


extern Object Fid, FD, FontMatrix, FontType, Encoding, FontBBox, FontName;
extern Object UserShow, CharStrings, Metrics;
