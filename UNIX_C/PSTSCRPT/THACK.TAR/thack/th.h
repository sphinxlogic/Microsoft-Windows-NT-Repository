#include <stdio.h>
char *table[2][2]=
	{ /* FONT 0,1,2,4,5,6,7 */
	 " htnmlizsdbxfjuk p ; a_c`e'o r v-wq/.g ,&y % QTOHNMLRGIPCVEZDBSY",
	 " FXAWJUK0123456789*       ()[]  = :+ ! ? |   $$$$$$$$$$$$$$$$$$$",
	 /* FONT 3 */
	 " yqnmlizsdbxhfuk p   a c e=o r t_ Y  g   w   FQW  VL-G P    D S ",
	 " >X</ U                   {}   #  ~    *   +  $$$$$$$$$$$$$$$$$$",
	 };
