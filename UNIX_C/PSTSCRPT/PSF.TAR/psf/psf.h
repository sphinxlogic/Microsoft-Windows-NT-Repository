/* ta=4

define the escape character used with psf */

#define	ESCAPE				0x05

#define BEGIN_BOLD			"\005B"
#define END_BOLD			"\005b"

#define BEGIN_UNDERLINE		"\005U"
#define END_UNDERLINE		"\005u"

#define BEGIN_ITALICS		"\005I"
#define END_ITALICS			"\005i"

#define	BEGIN_NAME			"\005F1\005B\005P13"	/* Helvetical bold 13 point */
#define END_NAME			"\005p\005b\005f"		

#define BEGIN_SUBJECT		"\005P13\005F1\005B\005I"	/*	Helvetica bold italic 13 point */
#define END_SUBJECT			"\005i\005b\005f\005p"		/*	return to normal point, font */
