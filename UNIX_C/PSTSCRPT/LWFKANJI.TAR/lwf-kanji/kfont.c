/* 
 * $Locker:  $ 
 */ 
static char	*rcsid = "$Header: showsnf.c,v 1.4 87/12/17 13:12:46 rws Exp $";
#include <stdio.h>
#include <sys/types.h> 
#include <sys/file.h> 
#ifdef SYSV
#include <fcntl.h>
#endif /* SYSV */
#include <sys/stat.h> 
#include <errno.h> 

#include "misc.h"
#include "Xmd.h"
#include "X.h"
#include "Xproto.h"
#include "fontstruct.h"
#include "font.h"

#include "fc.h"

#ifndef u_char
#define u_char	unsigned char
#endif

char *	malloc();

int glyphPad = DEFAULTGLPAD;
int bitorder = DEFAULTBITORDER;

TempFont	tf;
char		*kbuf;

int openkfont(file)
	char	*file;
{
	struct stat	st;
	FontInfoRec f;
	int	fd, i, strings;

	if (stat(file, &st) < 0) {
		fprintf(stderr, "can't stat %s\n", file);
		return(0);
	}

	fd = open(file, O_RDONLY);
	if (fd < 0) {
		fprintf(stderr, "can't open %s\n", file);
		return(0);
	}
	kbuf = malloc(st.st_size);
	read(fd, kbuf, st.st_size);
	close(fd);
	tf.pFI = (FontInfoPtr)kbuf;
	tf.pCI = (CharInfoPtr)(kbuf + BYTESOFFONTINFO(tf.pFI));
	tf.pGlyphs = ((unsigned char *)tf.pCI) + BYTESOFCHARINFO(tf.pFI);
	tf.pFP = (FontPropPtr)(tf.pGlyphs + BYTESOFGLYPHINFO(tf.pFI));
	strings = (int)tf.pFP + BYTESOFPROPINFO(tf.pFI);

	for (i=0; i<tf.pFI->nProps; i++) {
		tf.pFP[i].name += strings;
		if (tf.pFP[i].indirect)
			tf.pFP[i].value += strings;
	}
	return(1);
}

closekfont()
{
	free(kbuf);
}

char hexstring[80];

char *kimage(crow, ccol)
    int     crow, ccol;
{
	hexstring[0] = 0;
	DumpBitmaps(&tf, crow, ccol);
	return(hexstring);
}

DumpBitmaps(pFont, crow, ccol)
    TempFont *pFont;
    int	    crow, ccol;
{
    int			ch;	/* current character */
    int			r;	/* current row */
    int			b;	/* current bit in the row */
    FontInfoPtr		pFI = pFont->pFI;
    CharInfoPtr		pCI = pFont->pCI;
    u_char *		bitmap = (u_char *)pFont->pGlyphs;
    int			bpr;

    ch = (crow - pFont->pFI->firstRow)
	 * (pFont->pFI->lastCol - pFont->pFI->firstCol + 1)
	 + ccol - pFont->pFI->firstCol;

	bpr = GLWIDTHBYTESPADDED(pCI[ch].metrics.rightSideBearing
		- pCI[ch].metrics.leftSideBearing, glyphPad);

        if ( !pCI[ch].exists || pCI[ch].metrics.characterWidth == 0)
            return;

        for (r=0; r <  pCI[ch].metrics.descent + pCI[ch].metrics.ascent; r++)
        {
	    unsigned char *row = bitmap + pCI[ch].byteOffset+(r*bpr);
            for ( b=0;
		b < pCI[ch].metrics.rightSideBearing - pCI[ch].metrics.leftSideBearing;
		b += 4) {
		if (bitorder == LSBFirst) {
			addxchar( (b&4)? (row[b>>3] & 0xf0)>>4
				     :   (row[b>>3] & 0x0f) );
		} else {
			addxchar( (b&4)? (row[b>>3] & 0x0f)
				     :   (row[b>>3] & 0xf0)>>4 );
		}
	    }
        }
}

addxchar(nib)
int nib;
{	char xs[3];

	sprintf(xs, "%1x", nib);
	strcat(hexstring, xs);
}
