/* $Header: pps.h,v 0.0 88/06/22 05:22:20 on Rel $ */
/*
 * Interface from lex front-end to pps.c
 */
/*
 * The postscript routines assume that *font is one of the following: 
 *	I - variables and operators.
 *	C - comments
 *	S - strings
 *	K - keywords
 */
extern char *font;
#define begin(S)	(sput(), (BEGIN (S)), font = "S") /* Yech! */

#ifdef ECHO
#undef ECHO
#endif
#define ECHO		echo(yytext)
