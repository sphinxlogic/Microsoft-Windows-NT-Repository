#!/bin/sh
# Public domain.
exec pty -0 "$@"
