WARNING: Do not change this file without changing Makefile accordingly!
#include "config/sessconnfile.h"
X!/bin/sh
: > SESSCONNNOW_FILE; chmod 644 SESSCONNNOW_FILE
