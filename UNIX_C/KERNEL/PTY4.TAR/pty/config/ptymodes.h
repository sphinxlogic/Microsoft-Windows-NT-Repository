#ifndef CONFIG_PTYMODES_H
#define CONFIG_PTYMODES_H

#define PTYMODE_USED 0600
#define PTYMODE_UNUSED 0666 /* whimper */

#endif
