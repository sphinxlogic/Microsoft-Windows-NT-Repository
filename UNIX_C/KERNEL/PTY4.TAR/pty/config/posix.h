#ifndef CONFIG_POSIX_H
#define CONFIG_POSIX_H

#undef POSIX_SILLINESS

/* must have #undef POSIX_SILLINESS or #define POSIX_SILLINESS
   on line 4 of this file */

/* this was originally -DPOSIX rather than -DPOSIX_SILLINESS,
   but that conflicts with Ultrix 4.0's POSIX handling */

#endif
