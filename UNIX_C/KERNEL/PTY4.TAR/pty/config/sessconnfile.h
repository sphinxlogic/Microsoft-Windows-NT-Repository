#ifndef CONFIG_SESSCONNFILE_H
#define CONFIG_SESSCONNFILE_H

#define SESSCONNLOG_FILE "/usr/local/etc/sclog"
#define SESSCONNNOW_FILE "/usr/local/etc/scnow"

#endif
