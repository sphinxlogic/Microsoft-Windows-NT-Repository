#ifndef CONFIG_DEVSTY_H
#define CONFIG_DEVSTY_H

#define DEVSTY "/dev/tty"

/* DEVSTY is the prefix of slave sides of pseudo-ttys. */

#endif
