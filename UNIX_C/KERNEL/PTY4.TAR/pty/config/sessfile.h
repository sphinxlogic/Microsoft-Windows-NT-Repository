#ifndef CONFIG_SESSFILE_H
#define CONFIG_SESSFILE_H

#define SESSLOG_FILE "/usr/local/etc/sesslog"
#define SESSNOW_FILE "/usr/local/etc/sessnow"

#endif
