#ifndef CONFIG_PTYBIN_H
#define CONFIG_PTYBIN_H

#define PTYBIN "/usr/local/ptybin"

#endif
