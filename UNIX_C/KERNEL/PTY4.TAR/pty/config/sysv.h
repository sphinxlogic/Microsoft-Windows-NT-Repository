#ifndef CONFIG_SYSV_H
#define CONFIG_SYSV_H

#undef SYSV

#endif
