#ifndef CONFIG_PTYEXT_H
#define CONFIG_PTYEXT_H

#define PTYEXT1 "pqrstuvwxyzabcdefghijklmno"
#define PTYEXT2 "0123456789abcdef"

/* Note that PTYEXT2[0] must indicate the leader of each bank. */

/* Note also that the order here determines the order of the session logs. */

#endif
