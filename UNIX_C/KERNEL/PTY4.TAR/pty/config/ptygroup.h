#ifndef CONFIG_PTYGROUP_H
#define CONFIG_PTYGROUP_H

#define PTYGROUP 4

#endif
