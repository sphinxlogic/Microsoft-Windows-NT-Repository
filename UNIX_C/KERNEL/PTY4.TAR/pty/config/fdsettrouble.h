#ifndef CONFIG_FD_SET_TROUBLE_H
#define CONFIG_FD_SET_TROUBLE_H

#undef LACKING_FD_ZERO
#undef DESPERATE_FD_SET

/* sysconf expects lines 4 and 5 */

/* XXX: deprecated */

#endif
