#ifndef CONFIG_TTYOPTS_H
#define CONFIG_TTYOPTS_H

#define TTY_WINDOWS
#undef TTY_AUXCHARS
#undef TTY_TERMIO

/* TTY_WINDOWS must be on line 4. */

#endif
