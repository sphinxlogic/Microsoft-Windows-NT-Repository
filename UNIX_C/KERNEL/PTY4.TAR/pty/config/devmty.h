#ifndef CONFIG_DEVMTY_H
#define CONFIG_DEVMTY_H

#define DEVMTY "/dev/pty"

/* DEVMTY is the prefix for all master sides of pseudo-ttys. */

#endif
