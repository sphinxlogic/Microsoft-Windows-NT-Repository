#ifndef PTY_LOGS_H
#define PTY_LOGS_H

extern int utmp_on();
extern int utmp_off();
extern int wtmp_on();
extern int wtmp_off();

#endif
