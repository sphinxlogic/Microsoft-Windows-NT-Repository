#ifndef PTY_SIGLER_H
#define PTY_SIGLER_H

extern void sigler();

#endif
