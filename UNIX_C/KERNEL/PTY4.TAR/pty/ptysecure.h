#ifndef PTY_SECURE_H
#define PTY_SECURE_H

extern int ptysecure();
extern int ptyunsecure();

#endif
