#ifndef PTY_GETPTY_H
#define PTY_GETPTY_H

extern int getfreepty();
extern int ungetpty();

#endif
