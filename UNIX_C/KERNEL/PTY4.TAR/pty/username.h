#ifndef USERNAME_H
#define USERNAME_H

extern int uid2username();
extern int username2uid();

#endif
