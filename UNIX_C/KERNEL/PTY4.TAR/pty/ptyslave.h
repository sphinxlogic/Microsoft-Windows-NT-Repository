#ifndef PTY_SLAVE_H
#define PTY_SLAVE_H

extern void slave();

#endif
