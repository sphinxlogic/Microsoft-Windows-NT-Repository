#ifndef PTY_MASTER_H
#define PTY_MASTER_H

extern void master();

#endif
