#!/bin/sh
# Public domain.
exec pty -s "$@"
