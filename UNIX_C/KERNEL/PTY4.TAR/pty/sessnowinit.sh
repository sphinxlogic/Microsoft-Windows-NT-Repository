WARNING: Do not change this file without changing Makefile accordingly!
#include "config/sessfile.h"
X!/bin/sh
: > SESSNOW_FILE; chmod 644 SESSNOW_FILE
