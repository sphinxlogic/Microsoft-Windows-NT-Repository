/* number-ptys.h - Eric H. Herrin II
 *
 * define the number of ptys here so the actual number only has to be in
 * one place.
 * 
 * Version 2.1
 */
#define NUMBER_OF_PTYS 32
