typedef enum { FALSE = 0, TRUE = 1 } bool;

#include <strings.h>
#define equal(x,y)	( strcmp((x),(y)) == 0 )
#define equaln(x,y,n)	( strncmp((x),(y),(n)) == 0 )
#define any(p,c)	( index((p),(c)) != (char *)0 )

#ifdef DEBUG
#ifndef stderr
#include <stdio.h>
#endif
#define dprintf(x)	if (debug_control) fprintf( stderr, (x) )
#define d2printf(x,y)	if (debug_control) fprintf( stderr, (x), (y) )
#define d3printf(x,y,z)	if (debug_control) fprintf( stderr, (x), (y), (z) )
#define DEBUG_FILE	"./.debug"
#define debug_test	debug_control = (bool) (access(DEBUG_FILE,0) == 0)
#define debug_var	bool debug_control = TRUE;
extern bool debug_control;
#else
#define dprintf(x)	/* null */
#define d2printf(x,y)	/* null */
#define d3printf(x,y,z)	/* null */
#define debug_test	/* null */
#define debug_var	/* null */
#endif

#ifdef BSD41
int BSD41_i;
#define bcopy(x,y,n) for ( BSD41_i = 0; BSD41_i < (n); BSD41_i++ ) \
			(y)[BSD41_i] = (x)[BSD41_i]
#define bzero(x,n) for ( BSD41_i = 0; BSD41_i < (n); BSD41_i++ ) \
			(x)[BSD41_i] = 0
#endif
