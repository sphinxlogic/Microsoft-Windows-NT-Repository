RCS file: RCS/conf.c,v
retrieving revision 1.1.1.2
retrieving revision 1.5
diff -c2 -r1.1.1.2 -r1.5  [edited]
*** /tmp/,RCSt1000435	Mon Dec  2 23:47:17 1985
--- /tmp/,RCSt2000435	Mon Dec  2 23:47:19 1985
***************
*** 268,277 ****
--- 301,3?? ----
  #define	dhstop	nodev
  #define	dhreset	nulldev
+ #define	dhoopen	nodev
+ #define	dhoclose nodev
  #define	dh11	0
  #else
  int	dhopen(),dhclose(),dhread(),dhwrite(),dhioctl(),dhstop(),dhreset();
+ int	dhoopen(),dhoclose();
  struct	tty dh11[];
  #endif
***************
*** 316,322 ****
--- 375,384 ----
  #define	dzstop	nodev
  #define	dzreset	nulldev
+ #define	dzoopen	nodev
+ #define	dzoclose nodev
  #define	dz_tty	0
  #else
  int	dzopen(),dzclose(),dzread(),dzwrite(),dzioctl(),dzstop(),dzreset();
+ int	dzoopen(),dzoclose();
  struct	tty dz_tty[];
  #endif
***************
*** ???,??? ****
--- ???,??? ----
+ 	dzoopen,	dzoclose,	dzread,		dzwrite,	/*??*/
+ 	dzioctl,	dzstop,		nulldev,	dz_tty,
+ 	ttselect,	nodev,
+ 	dhoopen,	dhoclose,	dhread,		dhwrite,	/*??*/
+ 	dhioctl,	dhstop,		nulldev,	dh11,
+ 	ttselect,	nodev,
