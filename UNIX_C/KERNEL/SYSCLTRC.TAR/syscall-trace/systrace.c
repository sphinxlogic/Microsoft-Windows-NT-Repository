/* systrace.c 4.2 SUNYSB change by J. Simonetti 03/20/85 */
#include "SYS.h"

SYSCALL(systrace)
	ret
