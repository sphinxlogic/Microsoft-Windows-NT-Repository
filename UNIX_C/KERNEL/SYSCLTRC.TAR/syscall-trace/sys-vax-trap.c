*** /sys/vax/trap.c.orig	Mon Mar 11 10:58:54 1985
--- sys-vax-trap.c	Tue May 28 18:06:56 1985
***************
*** 221,226
  	u.u_dirp = (caddr_t)u.u_arg[0];
  	u.u_r.r_val1 = 0;
  	u.u_r.r_val2 = locr0[R1];
  	if (setjmp(&u.u_qsave)) {
  		if (u.u_error == 0 && u.u_eosys == JUSTRETURN)
  			u.u_error = EINTR;

--- 221,230 -----
  	u.u_dirp = (caddr_t)u.u_arg[0];
  	u.u_r.r_val1 = 0;
  	u.u_r.r_val2 = locr0[R1];
+ 
+ 	if (u.u_procp->p_flag & SYSTRACE)		/* JDS */
+ 		entrytrace( code, callp->sy_narg );	/* JDS */
+ 
  	if (setjmp(&u.u_qsave)) {
  		if (u.u_error == 0 && u.u_eosys == JUSTRETURN)
  			u.u_error = EINTR;
***************
*** 265,270
  		locr0[R1] = u.u_r.r_val2;
  	}
  done:
  	p = u.u_procp;
  	if (p->p_cursig || ISSIG(p))
  		psig();

--- 269,278 -----
  		locr0[R1] = u.u_r.r_val2;
  	}
  done:
+ 	if (u.u_procp->p_flag & SYSTRACE &&		/* JDS */
+ 		code != 139 )			/* do not record the */
+ 						/* getdprop return */
+ 		exittrace(code, callp-> sy_narg);	/* JDS */
  	p = u.u_procp;
  	if (p->p_cursig || ISSIG(p))
  		psig();
