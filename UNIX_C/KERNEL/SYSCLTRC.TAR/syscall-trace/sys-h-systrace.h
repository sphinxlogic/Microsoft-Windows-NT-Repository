#define	FILESPEC	0
#define	ALL		1
#define	PIDONLY		2
#define	CHILDONLY	3
#define	TRACEOFF	4

