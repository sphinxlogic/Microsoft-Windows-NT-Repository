*** /sys/sys/syscalls.c	Fri Jul 29 10:07:21 1983
--- syscalls.c	Fri May  3 17:22:16 1985
***************
*** 42,48
  	"old ftime",		/*  35 = old ftime */
  	"sync",			/*  36 = sync */
  	"old kill",		/*  37 = old kill */
! 	"#38 -- 4.1a select",	/*  38 = nosys */
  	"old setpgrp",		/*  39 = old setpgrp */
  	"lstat",		/*  40 = lstat */
  	"dup",			/*  41 = dup */

--- 42,48 -----
  	"old ftime",		/*  35 = old ftime */
  	"sync",			/*  36 = sync */
  	"old kill",		/*  37 = old kill */
! 	"4.1a select",		/*  38 = nosys */
  	"old setpgrp",		/*  39 = old setpgrp */
  	"lstat",		/*  40 = lstat */
  	"dup",			/*  41 = dup */
***************
*** 49,55
  	"pipe",			/*  42 = pipe */
  	"old times",		/*  43 = old times */
  	"old profil - nosys",	/*  44 = old profil */
! 	"#45",			/*  45 = nosys */
  	"old setgid",		/*  46 = old setgid */
  	"getgid",		/*  47 = getgid */
  	"old signal",		/*  48 = old sig */

--- 49,55 -----
  	"pipe",			/*  42 = pipe */
  	"old times",		/*  43 = old times */
  	"old profil - nosys",	/*  44 = old profil */
! 	"old times",		/*  45 = nosys */
  	"old setgid",		/*  46 = old setgid */
  	"getgid",		/*  47 = getgid */
  	"old signal",		/*  48 = old sig */
***************
*** 53,60
  	"old setgid",		/*  46 = old setgid */
  	"getgid",		/*  47 = getgid */
  	"old signal",		/*  48 = old sig */
! 	"#49",			/*  49 = reserved for USG */
! 	"#50",			/*  50 = reserved for USG */
  	"acct",			/*  51 = turn acct off/on */
  	"old phys - nosys",	/*  52 = old set phys addr */
  	"old lock - nosys",	/*  53 = old lock in core */

--- 53,60 -----
  	"old setgid",		/*  46 = old setgid */
  	"getgid",		/*  47 = getgid */
  	"old signal",		/*  48 = old sig */
! 	"#49 - reserved",	/*  49 = reserved for USG */
! 	"#50 - reserved",	/*  50 = reserved for USG */
  	"acct",			/*  51 = turn acct off/on */
  	"old phys - nosys",	/*  52 = old set phys addr */
  	"old lock - nosys",	/*  53 = old lock in core */
***************
*** 66,73
  	"execve",		/*  59 = execve */
  	"umask",		/*  60 = umask */
  	"chroot",		/*  61 = chroot */
! 	"#62",			/*  62 = nosys */
! 	"#63",			/*  63 = used internally */
  	"getpagesize",		/*  64 = getpagesize */
  	"mremap",		/*  65 = mremap */
  	"vfork",		/*  66 = vfork */

--- 66,73 -----
  	"execve",		/*  59 = execve */
  	"umask",		/*  60 = umask */
  	"chroot",		/*  61 = chroot */
! 	"fstat",		/*  62 = nosys */
! 	"#63 - used internally",/*  63 = used internally */
  	"getpagesize",		/*  64 = getpagesize */
  	"mremap",		/*  65 = mremap */
  	"vfork",		/*  66 = vfork */
***************
*** 88,94
  	"getpgrp",		/*  81 = getpgrp */
  	"setpgrp",		/*  82 = setpgrp */
  	"setitimer",		/*  83 = setitimer */
! 	"#84",			/*  84 = nosys */
  	"old swapon",		/*  85 = old swapon */
  	"getitimer",		/*  86 = getitimer */
  	"gethostname",		/*  87 = gethostname */

--- 88,94 -----
  	"getpgrp",		/*  81 = getpgrp */
  	"setpgrp",		/*  82 = setpgrp */
  	"setitimer",		/*  83 = setitimer */
! 	"wait",			/*  84 = nosys */
  	"old swapon",		/*  85 = old swapon */
  	"getitimer",		/*  86 = getitimer */
  	"gethostname",		/*  87 = gethostname */
***************
*** 109,115
  	"recv",			/* 102 = recv */
  	"socketaddr",		/* 103 = socketaddr */
  	"bind",			/* 104 = bind */
! 	"#105",			/* 105 = nosys */
  	"listen",		/* 106 = listen */
  	"old vtimes",		/* 107 = old vtimes */
  	"sigvec",		/* 108 = sigvec */

--- 109,115 -----
  	"recv",			/* 102 = recv */
  	"socketaddr",		/* 103 = socketaddr */
  	"bind",			/* 104 = bind */
! 	"setsockopt",		/* 105 = nosys */
  	"listen",		/* 106 = listen */
  	"old vtimes",		/* 107 = old vtimes */
  	"sigvec",		/* 108 = sigvec */
***************
*** 122,128
  #ifdef TRACE
  	"vtrace",		/* 115 = vtrace */
  #else
! 	"#115",			/* 115 = nosys */
  #endif
  	"gettimeofday",		/* 116 = gettimeofday */
  	"getrusage",		/* 117 = getrusage */

--- 122,128 -----
  #ifdef TRACE
  	"vtrace",		/* 115 = vtrace */
  #else
! 	"#115 - nosys",		/* 115 = nosys */
  #endif
  	"gettimeofday",		/* 116 = gettimeofday */
  	"getrusage",		/* 117 = getrusage */
***************
*** 126,132
  #endif
  	"gettimeofday",		/* 116 = gettimeofday */
  	"getrusage",		/* 117 = getrusage */
! 	"#118",			/* 118 = nosys */
  	"resuba",		/* 119 = resuba */
  	"readv",		/* 120 = readv */
  	"writev",		/* 121 = writev */

--- 126,132 -----
  #endif
  	"gettimeofday",		/* 116 = gettimeofday */
  	"getrusage",		/* 117 = getrusage */
! 	"getsockopt",		/* 118 = nosys */
  	"resuba",		/* 119 = resuba */
  	"readv",		/* 120 = readv */
  	"writev",		/* 121 = writev */
***************
*** 155,161
  	"getrlimit",		/* 144 = getrlimit */
  	"setrlimit",		/* 145 = setrlimit */
  	"killpg",		/* 146 = killpg */
! 	"#147",			/* 147 = nosys */
  	"setquota",		/* 148 = setquota */
  	"qquota",		/* 149 = qquota */
  	"getsockname",		/* 150 = getsockname */

--- 155,161 -----
  	"getrlimit",		/* 144 = getrlimit */
  	"setrlimit",		/* 145 = setrlimit */
  	"killpg",		/* 146 = killpg */
! 	"#147 - nosys",		/* 147 = nosys */
  	"setquota",		/* 148 = setquota */
  	"qquota",		/* 149 = qquota */
  	"getsockname",		/* 150 = getsockname */
***************
*** 159,162
  	"setquota",		/* 148 = setquota */
  	"qquota",		/* 149 = qquota */
  	"getsockname",		/* 150 = getsockname */
  };

--- 159,163 -----
  	"setquota",		/* 148 = setquota */
  	"qquota",		/* 149 = qquota */
  	"getsockname",		/* 150 = getsockname */
+ 	"systrace",		/* 151 = systrace JDS */
  };
