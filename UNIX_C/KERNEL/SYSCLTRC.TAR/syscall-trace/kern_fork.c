*** /sys/sys/kern_fork.c	Fri Jul 29 10:07:18 1983
--- kern_fork.c	Wed May 15 11:48:36 1985
***************
*** 132,137
  	rpp->p_stat = SIDL;
  	timerclear(&rpp->p_realtimer.it_value);
  	rpp->p_flag = SLOAD | (rip->p_flag & (SPAGI|SOUSIG));
  	if (isvfork) {
  		rpp->p_flag |= SVFORK;
  		rpp->p_ndx = rip->p_ndx;

--- 132,139 -----
  	rpp->p_stat = SIDL;
  	timerclear(&rpp->p_realtimer.it_value);
  	rpp->p_flag = SLOAD | (rip->p_flag & (SPAGI|SOUSIG));
+ 	if (rip->p_flag & CHILDTRACE)
+ 		rpp->p_flag = rpp->p_flag | SYSTRACE | CHILDTRACE;
  	if (isvfork) {
  		rpp->p_flag |= SVFORK;
  		rpp->p_ndx = rip->p_ndx;
