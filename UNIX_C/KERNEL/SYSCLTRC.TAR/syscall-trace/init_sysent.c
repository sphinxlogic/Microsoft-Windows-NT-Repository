*** /sys/sys/init_sysent.c	Sun Sep 25 21:06:36 1983
--- init_sysent.c	Sun Mar 17 16:58:40 1985
***************
*** 60,65
  
  /* 2.4 processes */
  int	ptrace();
  
  /* 2.5 terminals */
  

--- 60,66 -----
  
  /* 2.4 processes */
  int	ptrace();
+ int	systrace();	/* JDS systrace system call */
  
  /* 2.5 terminals */
  
***************
*** 262,266
  	2, setquota,			/* 148 = quota */
  	4, qquota,			/* 149 = qquota */
  	3, getsockname,			/* 150 = getsockname */
  };
  int	nsysent = sizeof (sysent) / sizeof (sysent[0]);

--- 263,268 -----
  	2, setquota,			/* 148 = quota */
  	4, qquota,			/* 149 = qquota */
  	3, getsockname,			/* 150 = getsockname */
+ 	3, systrace,			/* 151 = systrace JDS */
  };
  int	nsysent = sizeof (sysent) / sizeof (sysent[0]);
