
nap(ticks)
unsigned ticks;
{
static int fd=0;

if (fd == 0) fd = open("/dev/ft",0);
read(fd,(char *)0,ticks);

}

