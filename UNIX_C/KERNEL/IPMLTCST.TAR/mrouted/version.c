char version[] = "$Revision: 1.3 $";

