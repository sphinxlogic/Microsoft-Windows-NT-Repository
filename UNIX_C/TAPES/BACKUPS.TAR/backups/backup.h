/* $Header: backup.h,v 1.3 86/10/14 01:36:46 scooter Exp $ */
/*
 * backup.h - defines and defaults for backup
 */

#define	BLOCK_SIZE	32	/* Default blocking factor */
#define	TAPE_LENGTH	2300	/* Default tape length */
#define TAPE_DENSITY	6250	/* Default tape density */
#define DEVICE	"/dev/rmt9"	/* Default device for dumps */
#define	BACKUPFILE "/etc/backup_dates"
#define DUMPCOM "/etc/dump"

#define	YES	1
#define	NO	0
#define	ALL	-1
#define	RANGE	0
#define	LIST	1

int	ignore,days,weeks,months;
int	week_ptr,week_lst[5];
int	month_ptr,month_lst[12];
int	day_ptr,day_lst[7];
int	level,line_count,lineptr;
char	string[180];
char	filesys[180];
int	quiet;
extern	int	x_opt;
