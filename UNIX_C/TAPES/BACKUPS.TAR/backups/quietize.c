static char rcsid[] = "$Header: quietize.c,v 1.7 86/10/14 01:34:03 scooter Exp $";

/*
 * quietize
 *
 * This module controls all of the procedures necessary to bring
 * the system to a quiescent state.  Basically this can be summarized
 * by the following:
 *
 *	1. Do a shutdown to tell the users goodbye (/etc/shutdown)
 *	2. Get a listing of all the processes running (/bin/ps)
 *	3. Send a SIGHUP to all user processes and handle special shutdown
 *	4. Get another listing
 *	5. Send a SIGSTOP to everything but gettys and inits
 *
 * $Log:	quietize.c,v $
 * Revision 1.7  86/10/14  01:34:03  scooter
 * Added process specific startup/shutdown stuff
 * 
 *
 */

#include	"backup.h"
#include	"ulist.h"
#include	<stdio.h>
#include	<signal.h>

struct	ulist 	*u_list,*proclist(),*proc;
int	our_pid;
int	our_ppid;

quietize(minutes)
int minutes;
{
	int fixlog(),procont();

/*
 * Begin by going through all of the warning stuff
 */

	fprintf(stderr,"\n*** Warning users ...");
	if (minutes <= 0)minutes = 5;

	signal(SIGINT,fixlog);

#ifdef	DEBUG
	if (x_opt == NO)
		shutdown(minutes);
#else	DEBUG
	shutdown(minutes);
#endif	DEBUG

/*
 * Get our pid
 */

	our_pid = getpid();

/*
 * Get the list of processes on the system
 */

	fprintf(stderr,"\n*** Finding processes ...");
	u_list = proclist();

/*
 * Blow them away
 */

	fprintf(stderr,"\n*** Hanging up processes ...");
	for (proc = u_list ; proc != NULL ; proc = proc->next)
	{
		if (proc->pid == our_pid)our_ppid = proc->ppid;
	}

#ifdef	DEBUG
	if (x_opt)
		printf("Our pid = %d, our ppid = %d\n",our_pid,our_ppid);
#endif	DEBUG

	for (proc = u_list ; proc != NULL ; proc = proc->next)
	{
		if (proc->pid == our_pid ||
		    proc->pid == our_ppid ||
		    proc->special_flag)continue;
#ifdef	DEBUG
	if (x_opt)
		printf("Hanging up proces %s (%d)\n",proc->cmd,proc->pid);
	else
#endif	DEBUG
		kill(proc->pid,SIGHUP);
	}

	/*
	 * Make an attempt to be clean by freeing up the memory
	 */

	for (proc = u_list ; proc != NULL ; )
	{
		free(proc->cmd);
		u_list = proc;
		proc = proc->next;
		free(u_list);
	}

	/*
	 * Get the left-over list
	 */

	u_list = proclist();

	/*
	 * Stop them
	 */

	fprintf(stderr,"\n*** Stopping up processes ...");

	signal(SIGINT,procont);

	for (proc = u_list ; proc != NULL ; proc = proc->next)
	{
		if ( proc->pid == our_pid ||
			proc->pid == our_ppid)continue;

#ifdef	DEBUG
		if (x_opt)
		{
			if (proc->special_flag)
				printf("Special shutdown of %s (%d) with %s\n",
					proc->cmd,proc->pid,proc->proc_shutdn);
			else
				printf("Stopping up process %s (%d)\n",proc->cmd,
					proc->pid);
		} else
#endif	DEBUG
		if (proc->special_flag)
			system(proc->proc_shutdn);
		else
			kill(proc->pid,SIGSTOP);
	}

	/*
	 * Now that things should be quiet, sync the disks
	 */

	sync();
	sleep(1);
	sync();
	sleep(5);

}

fixlog()
{
	unlink("/etc/nologin");
	fprintf(stderr,"*** Backup aborted ***\n");
	exit(0);
}

procont()
{
	int restart();

	restart();
	fprintf(stderr,"*** Backup aborted ***\n");
	exit(0);
}
