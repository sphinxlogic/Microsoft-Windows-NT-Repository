static char rcsid[] = "$Header: restart.c,v 1.3 86/10/14 01:34:06 scooter Exp $";

/*
 * restart
 *
 * This module controls the system restart after backup is complete
 *
 * $Log:	restart.c,v $
 * Revision 1.3  86/10/14  01:34:06  scooter
 * Added process specific startup/shutdown stuff
 * 
 *
 */

#include	<stdio.h>
#include	"backup.h"
#include	"ulist.h"
#include	<signal.h>

extern struct ulist	*u_list;
extern int		our_pid,our_ppid;

restart()
{
	FILE *fs;
	struct ulist *proc;
	

	/*
	 * Restart stopped processes
	 */

	fprintf(stderr,"\n*** Restarting processes ...");

	for (proc = u_list ; proc != NULL ; proc = proc->next)
	{
		if (proc->pid < 5 || proc->pid == our_pid ||
			proc->pid == our_ppid)continue;

#ifdef	DEBUG
		if (x_opt)
			if (proc->special_flag)
				printf("restarting %s with %s\n",
					proc->cmd,proc->proc_restart);
			else
				printf("starting process %d\n",proc->pid);
		else
#endif	DEBUG
		if (proc->special_flag)
			system(proc->proc_restart);
		else
			kill(proc->pid,SIGCONT);
	}

	unlink("/etc/nologin");		/* Make sure users can log in */

	unlink("/dev/printer");		/* Restart all of the printers */
	system("/usr/lib/lpd");		/* Start the deaemon */

	return(0);
}
