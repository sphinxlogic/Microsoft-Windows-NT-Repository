#ifdef lint
static char rcsid[] = "$Header: backup.c,v 1.9 86/10/20 18:37:34 scooter Exp $";
#endif lint
/*
 * backup - a program to control daily dumps
 *
 * This program has been written to control the daily dumping
 * of all of the system's files.  Backup reads from the file
 * /etc/backup_dates to get the days and times that a filesystem
 * should be backed up.  The format of backup_dates is:
 *
 * Day_of_week	Week_of_month	Month	Level	Filesystem	Message
 *
 * where:
 *	Day_of_week is one of {Mon,Tue,Wed,Thu,Fri,Sat,Sun}
 *	Week_of_month is 1-5
 *	Month is one of {Jan,Feb,...,Dec}
 *	Level is 0-9
 *	Filesystem is the NAME of the filesystem
 *	Message is a message to be printed to the operator upon
 *	        completion of the dump
 *
 * For example, backup_dates might look like:
 *
 * # Backup schedule for Genie - Genentech, Inc.
 * # Daily level 9's
 * Tue-Fri	*	*	9	/va	"/va dump complete"
 * # Monday dumps - level 1's
 * Mon	2-5	*	1	/	"root dump complete"
 * Mon	2,3,4,5	*	1	/va	"/va dump complete"
 * # Monthly level 0's
 * Mon	1	*	0	/	"root dump complete"
 * Mon	1	*	0	/va	"/va dump complete"
 *
 * Note that the "#" character is used as a comment, and that ranges
 * as well as the "*" may be used.  Obviously ranges and wildcards are
 * only allowed in the Day_of_week and Week_of_month fields.
 *
 * Usage:
 *	backup [-b blocksize] [-s tapelength] [-t device] [-f file ] [-m] [-w n]
 *             [-d density] [date]
 *
 * Diagnostics:
 *	Backup will complain if the input file is garbaged or if the
 *	filesystem is mounted.  The return status from dump is monitored
 *	to track the progress of the dump and to determine if dump
 *	fails.  If it fails, the operator will be prompted to determine
 *	if they want to retry this filesystem.
 *
 * Author: Scooter Morris, Genentech
 * Date: March, 1985
 *
 */

#include <stdio.h>
#include <sys/time.h>
#include <fstab.h>
#include <signal.h>
#include <errno.h>
#include <sys/reboot.h>
#include "backup.h"

struct tm	*localtime();
struct tm	*convdate();
struct fstab	*fsent;
char 		line[180];
extern int	errno;
int		x_opt = NO;

char		*day_names[7] =
{ "Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday" };

char		*month_names[12] =
{ "January","February","March","April","May","June","July","August",
  "September","October","November","December" };

main(argc, argv)
int argc; char *argv[];
{
	FILE	*file;
	char	*ptr;
	char	fname[BUFSIZ];	/* file name */
	char	tname[BUFSIZ];	/* tape name */
	char	fsname[BUFSIZ];
	char	dump_comm[BUFSIZ];
	char	*tmp,*rindex();
	int	f_opt = NO;
	int	t_opt = NO;
	int	m_opt = NO;
	int	date_opt = 0;
	int	ret = 0;
	int	minutes = 5;
	int	tape_block = BLOCK_SIZE;
	int	tape_size = TAPE_LENGTH;
	int	tape_density = TAPE_DENSITY;
	long	tmptime;	/* place to put time */
	struct	tm *curtim;	/* current time structure */

	int	week_day,month_week,month,day,year;

	argc--, argv++;
	while (argc > 0) {
		ptr = *argv;
		while (*ptr) switch (*ptr++) {

		case '-':
			break;

		case 'm':
		case 'M':
			m_opt = YES;
			break;

		case 'f':
		case 'F':
			f_opt = YES;
			if (*ptr == 0) {
			    argv++;
			    argc--;
			    if (*argv == 0) {
				fprintf(stderr,
					"backup: no file given with '-f'.\n");
				exit(1);
			    }
			    strcpy(fname,*argv);
			}
			else {
			    strcpy(fname,ptr);
			    *ptr = 0;
			}
			break;

		case 't':
		case 'T':
			t_opt = YES;
			if (*ptr == 0) {
			    argv++;
			    argc--;
			    if (*argv == 0) {
				fprintf(stderr,
					"backup: no device given with '-t'.\n");
				exit(1);
			    }
			    strcpy(tname,*argv);
			}
			else {
			    strcpy(fname,ptr);
			    *ptr = 0;
			}
			break;

		case 'b':
		case 'B':
			if (*ptr == 0) {
			    argv++;
			    argc--;
			    if (*argv == 0) {
				fprintf(stderr,
			"backup: no blocking factor given with '-b'.\n");
				exit(1);
			    }
			    tape_block = atoi(*argv);
			}
			else {
			    tape_block = atoi(ptr);
			    *ptr = 0;
			}
			break;
			

		case 'd':
		case 'D':
			if (*ptr == 0) {
			    argv++;
			    argc--;
			    if (*argv == 0) {
				fprintf(stderr,
			"backup: no density given with '-d'.\n");
				exit(1);
			    }
			    tape_density = atoi(*argv);
			}
			else {
			    tape_density = atoi(ptr);
			    *ptr = 0;
			}
			break;

		case 's':
		case 'S':
			if (*ptr == 0) {
			    argv++;
			    argc--;
			    if (*argv == 0) {
				fprintf(stderr,
					"backup: no size given with '-s'.\n");
				exit(1);
			    }
			    tape_size = atoi(*argv);
			}
			else {
			    tape_size = atoi(ptr);
			    *ptr = 0;
			}
			break;
		case 'w':
		case 'W':
			if (*ptr == 0) {
			    argv++;
			    argc--;
			    if (*argv == 0) {
				fprintf(stderr,
			"backup: warning time in minutes not given with '-w'.\n");
				exit(1);
			    }
			    minutes = atoi(*argv);
			}
			else {
			    minutes = atoi(ptr);
			    *ptr = 0;
			}
			break;
		case 'X':
		case 'x':
			x_opt = YES;
			printf("*** Debugging ***\n");
			break;

		case '0':
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
			month = day = year = 0;
			date_opt = sscanf(--ptr,"%d/%d/%d",&month,&day,&year);
			if (date_opt < 2)
			{
				fprintf(stderr,
				"backup: illegal date specification\n");
				exit(1);
			}
			*ptr = 0;
			break;

		default:
			fprintf(stderr,
			"Unknown option '%c' - ignored\n",ptr[-1]);
		}
		argc--, argv++;
		*ptr = 0;
	}

	quiet = 0;

	/* Ignore impatience */

	signal(SIGTERM,SIG_IGN);
	signal(SIGHUP,SIG_IGN);
	signal(SIGQUIT,SIG_IGN);
	signal(SIGTSTP,SIG_IGN);

	/* get current date */

	if (date_opt)
	{
		curtim = convdate(month,day,year);
	} else {
		time(&tmptime);
		curtim = localtime(&tmptime);
	}

	week_day = curtim -> tm_wday;
	month_week = ( (curtim -> tm_mday - 1) / 7 ) + 1;
	month = curtim -> tm_mon;

	/* get dates file name */

	if (! f_opt) sprintf(fname,"%s",BACKUPFILE);
	if (! t_opt) sprintf(tname,"%s",DEVICE);

/*
 * Open up the input file
 */

	file = fopen(fname,"r");
	if (file == NULL)
	{
		perror(file);
		exit(errno);
	}

/*
 * Give introduction
 */

	printf("backup: Performing backup for %s %s %d, %d\n",
		day_names[week_day],month_names[month],curtim->tm_mday,
		curtim->tm_year+1900);

	line_count = 0;
	while (fgets(line,180,file) != NULL)
	{
		line_count++;
		lineptr = 0;
		if(yyparse() || ignore == YES)continue;

		if (x_opt)
		{
			printf("Today: %dw %dd %dm\n",month_week,week_day,month);
			printres("Weeks: ",weeks,week_lst,week_ptr);
			printres("Days: ",days,day_lst,day_ptr);
			printres("Months: ",months,month_lst,month_ptr);
		}

		if (check_per(month_week,weeks,week_lst,week_ptr))continue;

		if (check_per(week_day,days,day_lst,day_ptr))continue;

		if (check_per(month,months,month_lst,month_ptr))continue;

		fsent = getfsfile(filesys);
		if (fsent == NULL)
		{
			fprintf(stderr,"*** No filesystem %s\n",filesys);
			continue;
		}

		if (m_opt == NO)
		{
		/*
		 * Single user - if we already haven't quietize the system
		 */

			if (!quiet) 
			{
				fprintf(stderr,"%s\n%s",
	"*** You are about ready to kick off all users!!! ***",
	"*** Are you SURE you want to do this? ");
				gets(dump_comm);
				if (dump_comm[0] != 'y' &&
				    dump_comm[0] != 'Y') abort();
				fprintf(stderr,
	"*** Are you POSITIVE??? ");
				gets(dump_comm);
				if (dump_comm[0] != 'y' &&
				    dump_comm[0] != 'Y') abort();

				fprintf(stderr,
	"*** Beginning system shutdown....");
				quietize(minutes);
				quiet++;
			}
		}

		tmp = rindex(fsent->fs_spec,'/');
		fsname[0] = '\0';
		strncpy(fsname,fsent->fs_spec,(int)tmp-(int)(fsent->fs_spec)+1);
		fsname[(int)tmp-(int)(fsent->fs_spec)+1] = '\0';
		strncat(fsname,"r",1);
		strcat(fsname,++tmp);

		printf("To perform level %d dump of %s\n",level,filesys);
		dump_comm[0] = '0';
retry:		while (*dump_comm != 'r' && *dump_comm != 'q')
		{
printf("mount first tape and press 'r' RETURN when ready: ");
			gets(dump_comm);
		}

		if (*dump_comm == 'q') continue;

		sprintf(dump_comm,"%s %1dnufsdb %s %d %d %d %s\n",
				   DUMPCOM,level,tname,
				   tape_size,tape_density,tape_block,
				   fsname);

		ret = system(dump_comm);

		sprintf(line,"mt -t %s offl\n",tname);
		system(line);
		printf("*** %s ***\n",string);
	}

	printf("Backup is now complete!\n");
	if (m_opt == NO)
	{
		restart();	/* Restart the System */
	}
}

char
getnextchar()
{
	return((char)line[lineptr++]);
}

check_per(today,target,list,count)
int today,target,count;
int list[];
{
	int i;

	if (target == ALL)
		return(0);
	else if (target == LIST)
	{
		for (i = 0 ; i < count ; i++)
		{
			if(list[i] == today)return(0);
		}
	}
	else if (target == RANGE && today >= list[0] && today <= list[1])
		return(0);

	return(1);
}

printres(string,today,list,count)
char	*string;
int	today;
int	list[];
int	count;
{
	int i;

	printf("%s ",string);
	switch(today)
	{
	case ALL:
		printf("ALL ");
		break;
	case LIST:
		printf("LIST ");
		break;
	case RANGE:
		printf("RANGE ");
		break;
	}

	printf("(%d)",count);
	for (i = 0 ; i < count ; i++)
	{
		printf(" %d,",list[i]);
	}
	printf("\n");
}

abort()
{
	fprintf(stderr,"*** Backup aborted ***\n");
	exit(1);
}
