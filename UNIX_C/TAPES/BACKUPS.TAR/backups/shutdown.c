static char rcsid[] = "$Header: shutdown.c,v 1.1 85/04/05 17:14:09 scooter Exp $";

/*
 * shutdown
 *
 * This module controls the system shutdown message stuff.
 */

#include	<stdio.h>
#include	"backup.h"

shutdown(minutes)
int minutes;
{
	char	temp[180];
	FILE	*nlfl;

/*
 * Begin by formatting the shutdown command
 */

	sprintf(temp,"/etc/shutdown -k +%d %s",minutes,
			"System going down for system backups");

	system (temp);

/*
 * Now sleep until shutdown is complete
 */

	sleep(minutes*60 + 5);

/*
 * Since shutdown unlinks /etc/nologin when it exits, we must re-do it
 */

	nlfl = fopen("/etc/nologin","w");
	if (nlfl == NULL)
	{
		fprintf(stderr,"*** Warning: unable to disable logins\n");
	} else {
		fprintf(nlfl,"NO LOGINS: System backups in progress\n");
		fflush(nlfl);
		fclose(nlfl);
	}

}
