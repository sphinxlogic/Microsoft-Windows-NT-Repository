static char rcsid[] = "$Header: proclist.c,v 1.6 87/05/25 16:55:54 scooter Exp $";

/*
 * proclist
 *
 * This routine returns a list of candidate procedures for
 * killing.
 *
 * $Log:	proclist.c,v $
 * Revision 1.6  87/05/25  16:55:54  scooter
 * Added Appleshare stuff to "special processing" list
 * 
 * Revision 1.5  86/10/15  09:26:13  scooter
 * Added syslogd to the exclusion list
 * 
 * Revision 1.4  86/10/14  01:33:46  scooter
 * Added process specific startup/shutdown stuff
 * 
 *
 */

#include "backup.h"
#include "ulist.h"
#include <stdio.h>

/*
 * Table of offsets for portions of the ps -l line
 */

#define	UID	7
#define	PID	12
#define	PPID	18
#define	STAT	61
#define	CMD	75

/*
 * List of processes to exclude
 */

char	*exlist[] =
	{ "init",
	  "swapper",
	  "pagedaemon",
	  "/etc/timed",
	  "/etc/named",
	  "/etc/syslogd",
	  "/etc/atalkad",		/* Kinetics route info server */
	  "/usr/local/lib/lsrv",	/* Appletalk spooler */
	  "/usr/local/lib/atis",	/* Appletalk name server */
	  "- std.9600",
	  "- std.4800",
	  "- std.1200",
	  "- P4800",
	  "- P1200",
	  "- D1200",
	  "- Console",
	  0 };

/*
 * Processes which require special shutdown/restart
 */

struct	proc_struct 
{
	char	*pr_name;
	char	*pr_shutdown;
	char	*pr_restart;
} special_procs[] = {
	{"/etc/rjecop","opr 0 .d","/etc/hsp_reload"},
	{"genie Aufs Daemon","kill -TERM %d","cd /usr/adm;/usr/local/lib/aufs -V AppleSharePublicVolumes -U 20"},
	{"jinn Aufs Daemon","kill -TERM %d","cd /usr/adm;/usr/local/lib/aufs -U 20"},
	{0,0,0}
};

struct ulist *
proclist()
{
	struct ulist *head=NULL;
	struct ulist *tail=NULL;
	FILE *pschan,*popen();
	char string[180],*tmp,*rindex();
	int i,ex_flag;

	pschan = popen("/bin/ps -lgaxw","r");
	if (pschan == NULL)
	{
		fprintf(stderr,"*** Unable to get ps listing ***");
		exit (1);
	}

	fgets(string,180,pschan);	/* Skip the header */

	while ( fgets(string,180,pschan) != NULL )
	{

		/*
		 * Check for excluded processes
		 */

		i = ex_flag = 0;

		while ( tmp = exlist[i++] )
		{
			if (!strncmp(string+CMD,tmp,strlen(tmp)))
			{
				ex_flag = 1;
				break;
			}
		}

		if (ex_flag) continue;

		if (head == NULL)
		{
			head = tail = (struct ulist *)
				malloc(sizeof(struct ulist));
		} else
		{
			tail->next = (struct ulist *)
				malloc(sizeof(struct ulist));
			tail = tail->next;
		}

		tail->uid = atoi(string+UID);
		tail->pid = atoi(string+PID);
		tail->ppid = atoi(string+PPID);
		strncpy(tail->stat,string+STAT,4);
		strncpy(tail->cmd,string+CMD,39);
		tmp = rindex(tail->cmd,'\n');
		if (tmp != NULL)*tmp = '\0';
		tail->special_flag = 0;
		tail->next = NULL;

		/*
		 * Check for special shutdown/startup
		 */
		
		i = 0;
		while ( tmp = special_procs[i].pr_name )
		{
			if (!strncmp(tail->cmd,tmp,strlen(tmp)))
			{
				tail->special_flag++;
				
				/* Allow single argument (pid) -- this will allow special signals */
				sprintf(tail->proc_shutdn, special_procs[i].pr_shutdown, tail->pid);
				sprintf(tail->proc_restart, special_procs[i].pr_restart, tail->pid);
				break;
			}
			i++;
		}


#ifdef	DEBUG
		if (x_opt)
			printf("%6d, %6d, %6d, %4s, %s\n",tail->uid,tail->pid,
					tail->ppid,tail->stat,tail->cmd);
#endif	DEBUG

	}
	pclose(pschan);

	return(head);
}
