/* $Header: ulist.h,v 1.2 86/10/14 01:34:47 scooter Exp $ */
struct	ulist {
	int	pid;		/* Process id */
	int	ppid;		/* Parent process id */
	int	uid;		/* Uid of the process */
	int	stat[4];	/* The process state */
	char	cmd[40];	/* The command name */
	int	special_flag;	/* Special startup/shutdown? */
	char	proc_shutdn[80];	/* shutdown command */
	char	proc_restart[80];	/* restart command */
	struct	ulist *next;
};
