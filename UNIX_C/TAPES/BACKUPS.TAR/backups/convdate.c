#ifndef lint
	static char RCSid[] = "$Header: convdate.c,v 1.1 85/05/22 15:53:36 scooter Exp $";
#endif lint

/*
 * Module to convert date from mm/dd/yy format to a "tm" structure
 */


#include	<stdio.h>
#include	<sys/time.h>
#include	<tzfile.h>

static int	dmsize[13] =
	{ -1,31,28,31,30,31,30,31,31,30,31,30,31 };

struct tm *
convdate(month,day,year)
int month,day,year;
{
	int i;
	struct tm *today;
	struct timeval tv;
	struct timezone tz;

	gettimeofday(&tv,&tz);
	today = localtime(&tv.tv_sec);

	if (year == 0)year = today->tm_year;
	if (month == 0)month = today->tm_mon+1;
	if (day == 0)day = today->tm_mday;

	if (year < 1000)year += 1900;

	tv.tv_sec = 0;

	if (isleap(year) && month > 2)
		++tv.tv_sec;
	for (--year;year >= EPOCH_YEAR;--year)
		tv.tv_sec += isleap(year) ? DAYS_PER_LYEAR : DAYS_PER_NYEAR;
	while (--month)
		tv.tv_sec += dmsize[month];
	tv.tv_sec += day - 1;
	tv.tv_sec = HOURS_PER_DAY * tv.tv_sec;
	tv.tv_sec = MINS_PER_HOUR * tv.tv_sec;
	tv.tv_sec = SECS_PER_MIN * tv.tv_sec;
	
	/* Now convert to local timezone */
	tv.tv_sec += (long)tz.tz_minuteswest*SECS_PER_MIN;
	if (localtime(&tv.tv_sec)->tm_isdst) tv.tv_sec -= SECS_PER_HOUR;

	return(localtime(&tv.tv_sec));
}
