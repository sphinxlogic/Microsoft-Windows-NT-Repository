/* $Header: dumptab.h,v 1.1 85/07/02 13:48:41 root Exp $ */

struct	dumptab {
	char	*dt_name;
	int	dt_position;	/* 1 to n */
	int	dt_weekly;	/* Sunday = 0, Saturday = 6 */
	char	*dt_comment;	/* other information */
};

struct dumptab *getdtent(), *getdtnam(), *getdtpos();
