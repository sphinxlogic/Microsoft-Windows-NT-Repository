: /bin/sh script
#set -xv
#-----------------------------------------------------------------
# PROGRAM DESCRIPTION:
#	UNARCH.LIST lists the files that have been retrieved from
#                   the archives and placed under a user's
#		    .unarchive directory. (Called by unarchive)
# ----------------------------------------------------------------

cd $HOME
if [ -d .unarchive ]
then
    cd $HOME/.unarchive
    ls > directories
    while read directory
    do
        cd $HOME/.unarchive/$directory
	echo "\n\nThe following are files that have been unarchived for you.\n"
	ls
    done< directories
    rm directories
else
    echo "\n\n There are no files that have been unarchived for you.\n\n"
fi


