: /bin/sh script
#set -xv
# ----------------------------------------------------------------
# LONGLIST:  This program displays the archive date, retention 
#            status and the filenames of archived files for the
#            user. This program is called by /usr/tools/archlist
#            if the user has given -v as an argument.
# ----------------------------------------------------------------

echo "\n\nDate Archived   Retention           File Name\n"
$TOOLDIR/dmy -f $longlist 2> /dev/null	#Convert to old date format
awk '{print " ",$3,"    ",$2,"        ",$4}' $1

# ----------------------------------------------------------------
