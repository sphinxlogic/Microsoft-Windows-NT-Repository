: /bin/sh script
# ---------------------------------------------------------------------
# MAKE.SYSADM: This file should prompt for someone to enter the logonid
# of the systems administrator.  It will then store the information 
# about the administrator (taken from the /etc/passwd file) in a file
# call "system.admin".
# ---------------------------------------------------------------------
clear
echo "\n\n\n\n\n\n"
echo "PLEASE ENTER THE LOGIN ID OF YOUR SYSTEM ADMINISTRATOR: "
read logon
grep $logon /etc/passwd > sysfile
if [ ! -s sysfile ]
then
    echo "\n\n\n"
    echo "$logon IS NOT A LOGIN ID IN THE PASSWORD FILE."
    sleep 2
    mk.sysadm
else
    echo $logon > /usr/adm/system.admin
    echo "\n\n\n"
    echo "$logon IS ESTABLISHED AS YOUR SYSTEM ADMINISTRATOR."
    sleep 2
    clear
fi
rm sysfile
