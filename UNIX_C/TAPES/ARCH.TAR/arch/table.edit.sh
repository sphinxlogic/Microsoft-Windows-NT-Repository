: /bin/sh script
# -----------------------------------------------------------------------------
# TABLE_EDIT: This script should be run only once by the system administrator
#             to add a new flags field to the /usr/adm/archtable.  The default
#             given to this flags field is "N" for "Not Specified".
# -----------------------------------------------------------------------------

if [ -s /usr/adm/archtable ]
then
    cat /usr/adm/archtable |
    sed "s/ / N /" > /usr/adm/newtable
    mv /usr/adm/newtable /usr/adm/archtable
fi
