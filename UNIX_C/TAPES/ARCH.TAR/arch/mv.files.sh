: /bin/sh script
#-----------------------------------------------------------------------------#
# MV_FILES: This program builds an executable shell script to move unarchived #
#           files from the /unarchive directory to a user's $HOME/.unarchive  #
#           date directory.                                                   #
#-----------------------------------------------------------------------------#
arch=.archive/
files=/*
loop_dte=""
while read dte filepath
do
    dirdate=`echo $dte | $TOOLDIR/ymd`
    if [ "$loop_dte" = $dte ]
    then
	continue
    else
	cat $UNARDIR/move |
	sed "s:^[^/]*\(/.*\)$:\1:" > $UNARDIR/temp1
	cat $UNARDIR/temp1 |
	sed "s:^/.*\.archive/\([^/]*\).*$:\1:" > $UNARDIR/temp2
	dte=`tail -1 $UNARDIR/temp2`
	cat $UNARDIR/temp1 |
	sed "s:^/\(.*\)\.archive/.*$:mv \1$arch$dirdate$files $home/.unarchive/$dirdate:" > $UNARDIR/temp3
	cat $UNARDIR/temp1 |
	sed "s:^/\(.*\).archive/.*$: rm -r \1:" > $UNARDIR/temp5
	tail -1 $UNARDIR/temp5 > $UNARDIR/del_dirs
	tail -1 $UNARDIR/temp3 >> $UNARDIR/move_it
	loop_dte=$dte
    fi
done < $UNARDIR/move
chmod +x $UNARDIR/del_dirs $UNARDIR/move_it
$UNARDIR/move_it
$UNARDIR/del_dirs

