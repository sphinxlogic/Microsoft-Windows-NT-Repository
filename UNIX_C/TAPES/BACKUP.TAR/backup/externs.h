/*
 * $Header: /ecn1/src/ecn/backup/RCS/externs.h,v 1.2 87/09/22 09:57:37 davy Exp $
 *
 * externs.h - external data declarations
 *
 * David A. Curry
 * Purdue Engineering Computer Network
 * November, 1985
 *
 * $Log:	externs.h,v $
 * Revision 1.2  87/09/22  09:57:37  davy
 * Installed a new variable "nodumpmsgs" to turn off "no dump today"
 * messages.
 * 
 * Revision 1.1  87/09/22  09:49:06  davy
 * Initial revision
 * 
 */

extern FILE *logfp;
extern int Weekday;
extern int Weeknum;
extern int Tapereel;
extern int Tapefile;
extern int Tapeleft;
extern int Processid;
extern int Blocksleft;
extern int Tapemounted;
extern int Firstdumprec;

extern char Date[];
extern char Label[];
extern char Update[];
extern char Verify[];
extern char Density[];
extern char Rewtape[];
extern char Catalog[];
extern char Hostname[];
extern char Blocksize[];
extern char Norewtape[];
extern char Sametapes[];
extern char Tapelength[];
extern char Remotedump[];
extern char Nodumpmsgs[];
extern char Dumpcommand[];
extern char Oninterrupt[];
extern char Controlfile[];
