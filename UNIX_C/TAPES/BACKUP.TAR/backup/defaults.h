/*
 * $Header: /ecn1/src/ecn/backup/RCS/defaults.h,v 1.2 87/09/22 09:57:27 davy Exp $
 *
 * defaults.h - default values for control file variables
 *
 * David A. Curry
 * Purdue Engineering Computer Network
 * November, 1985
 *
 * $Log:	defaults.h,v $
 * Revision 1.2  87/09/22  09:57:27  davy
 * Installed a new variable "nodumpmsgs" to turn off "no dump today"
 * messages.
 * 
 * Revision 1.1  87/09/22  09:45:56  davy
 * Initial revision
 * 
 */

#define D_LABEL		"on"
#define D_UPDATE	"on"
#define D_VERIFY	"on"
#define D_DENSITY	"1600"
#define D_REWTAPE	"/dev/rmt8"
#define D_CATALOG	"off"
#define D_HOSTNAME	"unknown"
#define D_BLOCKSIZE	"10"
#define D_NOREWTAPE	"/dev/nrmt8"
#define D_SAMETAPES	"off"
#define D_TAPELENGTH	"2300"
#define D_REMOTEDUMP	"off"
#define D_NODUMPMSGS	"off"
#define D_DUMPCOMMAND	"/etc/dump"
#define D_ONINTERRUPT	"handle"
#define D_CONTROLFILE	"/etc/backup.control"
