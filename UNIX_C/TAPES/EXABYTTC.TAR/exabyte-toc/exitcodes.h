#ifndef EXITCODES_H
#define EXITCODES_H 1

#define EXIT_OK		0
#define EXIT_USAGE	1
#define	EXIT_IO		2
#define EXIT_NOTOC	3
#define EXIT_TOOBIG	4

#endif
