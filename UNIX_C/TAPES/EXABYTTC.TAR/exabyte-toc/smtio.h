#include <sys/ioctl.h>

/* structures and defines for ioctls */
struct smt_stat {
	char	smt_type[8];	/* Cartridge type */
	unsigned long	smt_remain;		/* # of kilobytes remaining on tape */
	unsigned long	smt_size;		/* size (in kb) of tape */
	unsigned long	smt_ecc;		/* ECC count */
	long	smt_wp:1;		/* Write protected */
	long	smt_bot:1;		/* At beginning of tape */
};

#define	SMTIOGETSTAT	_IOR(m,0,struct smt_stat)	/* get the drive status */
