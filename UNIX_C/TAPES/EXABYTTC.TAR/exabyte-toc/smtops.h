#ifndef	SMTOPS_H
#define	SMTOPS_H 1

#include "smtio.h"
extern	struct smt_stat	*smt_status();

extern	int	   	 smt_open();
extern	void	   	 smt_close();
extern  void		 smt_close_without_eof();
extern	void	   	 smt_rewind();
extern	void		 smt_eof();
extern	int		 smt_read();
extern	int		 smt_write();

#endif
