/*
 * beer.c
 *
 * intermediate C program to prevent
 * setuid shell scripts
 */

main (argc, argv)
register int argc;
register char **argv;
{
	setgid (getegid ());
	setuid (geteuid ());
	switch (argc) {
	case 1:
		execl ("/bin/sh", "sh", "/etc/beer/beerscript.sh", (char *) 0);
		break;

	default:
		execl ("/bin/sh", "sh", "/etc/beer/beerscript.sh", argv[1], (char *) 0);
		break;
	}
	perror ("exec");
	exit (1);
}
