/*
 * generate.c
 *
 * produce numbers in a given range for beer.
 */

#include <stdio.h>

main (argc, argv)
int argc;
char **argv;
{
	register int start, end;

	if (argc != 3)
		fprintf (stderr, "usage: %s from to\n", argv[0]), exit (1);

	start = atoi (*++argv);
	end = atoi (*++argv);

	for (; start <= end; start++)
		printf ("%d\n", start);

	exit (0);
}
