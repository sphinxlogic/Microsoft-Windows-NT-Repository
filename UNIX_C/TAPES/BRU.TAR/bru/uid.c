main ()
{
	printf ("uid = %d\teuid = %d\n", getuid(), geteuid());
}
