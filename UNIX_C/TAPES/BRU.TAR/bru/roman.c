/*
 * roman.c
 *
 * convert integer to roman numerals for beer
 * most of the code stolen from 'swtfmt'
 */

#include <stdio.h>
#include <ctype.h>

static char *roman ();

main (argc, argv)
int argc;
char **argv;
{
	if (argc != 2)
		fprintf (stderr, "usage: %s integer\n", argv[0]), exit (1);

	printf ("%s\n", roman (atoi (argv[1])));
	exit (0);
}

static char *roman (val)
int val;
{
	static char buf[BUFSIZ];
	register int aval, i;
	register char *cp;

/* this macro is Reiser CPP dependant.... */
#define outchar(ch)	{ if (i < sizeof buf){ buf[i] = 'ch'; i++;}}

	i = 0;
	aval = abs (val);
	if (val < 0)
		outchar (-);

	while (aval >= 1000)
	{
		outchar (m);
		aval -= 1000;
	}
	if (aval >= 900)
	{
		outchar (c);
		outchar (m);
		aval -= 900;
	}
	else if (aval >= 500)
	{
		outchar (d);
		aval -= 500;
	}

	if (aval >= 400)
	{
		outchar (c);
		outchar (d);
		aval -= 400;
	}
	else
		while (aval >= 100)
		{
			outchar (c);
			aval -= 100;
		}
	if (aval >= 90)
	{
		outchar (x);
		outchar (c);
		aval -= 90;
	}
	else if (aval >= 50)
	{
		outchar (l);
		aval -= 50;
	}

	if (aval >= 40)
	{
		outchar (x);
		outchar (l);
		aval -= 40;
	}
	else
		while (aval >= 10)
		{
			outchar (x);
			aval -= 10;
		}

	if (aval >= 9)
	{
		outchar (i);
		outchar (x);
		aval -= 9;
	}
	else if (aval >= 5)
	{
		outchar (v);
		aval -= 5;
	}

	if (aval >= 4)
	{
		outchar (i);
		outchar (v);
		aval -= 4;
	}
	else
		while (aval >= 1)
		{
			outchar (i);
			aval--;
		}

	buf [i] = '\0';

	for (cp = buf; *cp; cp++)
		if (islower (*cp))
			*cp = toupper (*cp);
	return (buf);
}
