/*	This file is part of the magtape handling package MAG.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
*/

#define	TP_MAXB	32766	/* largest size parameter to `read' & `write' */

#define	TP_CDEV	(-1)
#define	TP_IMAG	(-2)

#define	TP_DENL	_tp_dnl
#define	TP_DENN	_tp_dnn
#define	TP_DENH	_tp_dnh

extern char _tp_dnl[], _tp_dnn[], _tp_dnh[];

struct tpdes	{
	int _tp_unit;		/* unit number or TP_IMAG  or TP_CDEV  */
	char *_tp_nmdns;	/* density     or filename or filename */
	char _tp_rw;		/* 'r' for reading, 'w' for writing */
	char _tp_x;		/* 'x' for persistent, ' ' for normal */
	char _tp_fildes;	/* file descriptor after `open' */

	long _tp_blkc;		/* block counter */
	int _tp_mkc;		/* accumulative TM counter */
	int _tp_mc;		/* consecutive TM counter */
	char _tp_eof;		/* EOF-flag */
};
#define	TPFILE	struct tpdes

extern TPFILE *tpopen();

