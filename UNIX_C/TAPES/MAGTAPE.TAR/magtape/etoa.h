/*	This file is part of the magtape handling package MAG.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
*/

extern char _etoa[];			/* from etoa.c */

#define	ebc2asc(c)	(_etoa[(c)&0377])
