/*	This file is part of the magtape handling package MAG.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
*/

extern char *sysdate();			/* today's date as YYDDD */
extern char *username();		/* a name for the user */

