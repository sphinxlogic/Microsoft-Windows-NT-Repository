/*	This file is part of the magtape handling package MAG.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
*/

#include	"tploc.h"

/* The tape device names */
char _tp_dnl[] = DEV_LOW;
char _tp_dnn[] = DEV_NORMAL;
char _tp_dnh[] = DEV_HIGH;
