/*	This file is part of the magtape handling package MAG.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
*/

/*LINTLIBRARY*/
#include	<stdio.h>
#include	"tp.h"

TPFILE *tpopen(unit, nmdns, rwx) char *nmdns, *rwx;
{return tpopen(unit, nmdns, rwx);}

tpclose(tf) TPFILE *tf;
{tpclose(tf); return;}

int tpread(tf, buf, size) TPFILE *tf; char *buf;
{return tpread(tf, buf, size);}

tpwrite(tf, buf, size) TPFILE *tf; char *buf;
{tpwrite(tf, buf, size); return;}

tperrout(stream) FILE *stream;
{tperrout(stream); return;}

char *sysdate()
{return sysdate();}

char *username()
{return username();}

char TP_DENL[];
char TP_DENN[];
char TP_DENH[];

char _etoa[];
