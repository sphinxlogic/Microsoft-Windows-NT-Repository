/*	This file is part of the magtape handling package MAG.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
*/

#include	<stdio.h>
#include	"aux.h"
#include	"tp.h"
#include	"sys.h"

int unit = 0;
char *nmdns = TP_DENN;
char *rx = "r";
TPFILE *from, *to;
char *filename;
int size;
char buff[TP_MAXB];

main(argc, argv)
	char *argv[];
{
	argc--, argv++;
	while (argc > 0 && argv[0][0] == '-')	{
		char *pp = argv[0];
		
		while (*++pp)	{
			switch (*pp)	{
			/* insert cases to handle the standard options */
#include	"options.h"
			/* special options */
			}
		}
		argc--, argv++;
	}
	
	printf("%s, %s\n", sysdate(), username());
	tperrout(stdout);
	from = tpopen(unit, nmdns, rx);
	to = tpopen(TP_IMAG, filename, "w");

	while ((size = tpread(from, buff, TP_MAXB)) >= 0)	{
		tpwrite(to, buff, size);
	}
	tpclose(from);
	tpclose(to);
	exit(0);

Lbad:
	exit(1);
}
