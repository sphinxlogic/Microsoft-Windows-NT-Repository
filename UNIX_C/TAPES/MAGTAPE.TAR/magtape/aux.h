/*	This file is part of the magtape handling package MAG.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
*/

#define	char2int(c)	((c)&0377)
#define	is_ascii95(c)	(040 <= (c) && (c) <= 0176)
#define	is_digit(c)	('0' <= (c) && (c) <= '9')
#define	n_items(a)	(sizeof (a)/sizeof (a)[0])

/* a define that generates 2 parameters */
#define	english(i)	(i), (i) == 1 ? "" : "s"	/* word with plural */

#ifdef	lint
/* this #define has the same syntactic properties as the original */
#define	VOID(x)	if ((int)(x)) printf("")
#else	lint
#define	VOID(x)	(x)
#endif	lint
