/*	This file is part of the magtape handling package MAG.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
*/

#include	"aux.h"
#include	"tp.h"
#include	"tpsys.h"

/*
 * _tpwtmloc writes a tape mark to a character device.
 * It must take care of the local restrictions.
 */

_tpwtmloc(tf)
	TPFILE *tf;
{
	VOID(close(tf->_tp_fildes));
	tf->_tp_fildes = open(_tpname(tf), 1);
}
