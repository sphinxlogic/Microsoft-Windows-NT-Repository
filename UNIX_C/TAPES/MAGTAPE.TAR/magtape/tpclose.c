/*	This file is part of the magtape handling package MAG.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
*/

#include	"aux.h"
#include	"tp.h"
#include	"tpsys.h"

tpclose(tf)
	TPFILE *tf;
{
	VOID(close(tf->_tp_fildes));
	if (tf->_tp_rw == 'w')	{
		tf->_tp_rw = 'r';
		VOID(close(open(_tpname(tf), 0)));
	}
	tf->_tp_fildes = 0;
}
