/*	This file is part of the magtape handling package MAG.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
*/

#include	"aux.h"
#include	"tp.h"
#include	"tpsys.h"

extern char *sprintf();

char * /* transient */
_tpname(tf)
	TPFILE *tf;
{
	static char name[20];
	int unit = tf->_tp_unit;
	char *nmdns = tf->_tp_nmdns;

	if (unit == TP_IMAG || unit == TP_CDEV)
		return nmdns;
	
	/* a real magtape */
	if (tf->_tp_rw == 'w')	{
		/* find the second name */
		while (*nmdns++)	{
		}
	}
	VOID(sprintf(name, nmdns, unit));

	return name;
}
