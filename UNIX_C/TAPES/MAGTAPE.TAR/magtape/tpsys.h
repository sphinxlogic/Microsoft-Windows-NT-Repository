/*	This file is part of the magtape handling package MAG.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
*/

#define	_TP_PREF	8	/* size of length prefix in disk images */
#define	_TP_MOPEN	2	/* max # of simultaneously open tape-files */

extern char *_tpname();
