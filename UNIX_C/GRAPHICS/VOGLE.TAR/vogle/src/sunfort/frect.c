#include "vogle.h"

/*
 * rect_
 */
rect_(x1, y1, x2, y2)
	float 	*x1, *y1, *x2, *y2;
{
	rect(*x1, *y1, *x2, *y2);
}
