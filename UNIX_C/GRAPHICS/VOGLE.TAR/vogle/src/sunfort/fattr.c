#include "vogle.h"

/*
 * pushattributes_
 */
void
pushattributes_()
{
	pushattributes();
}

/*
 * popattributes_
 */
void
popattributes_()
{
	popattributes();
}

