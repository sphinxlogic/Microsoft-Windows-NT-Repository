#include "vogle.h"

/*
 * pushmatrix_
 */
void
pushmatrix_()
{
	pushmatrix();
}

/*
 * popmatrix_
 */
void
popmatrix_()
{
	popmatrix();
}

/*
 * getmatrix_
 */
void
getmatrix_(mat)
	float	*mat;
{
	getmatrix(mat);
}

/*
 * loadmatrix_
 */
void
loadmatrix_(mat)
	float	*mat;
{
	loadmatrix(mat);
}

/*
 * multmatrix_
 */
void
multmatrix_(mat)
	float	*mat;
{
	multmatrix(mat);
}
