#include "vogle.h"

/*
 * getaspect_
 */
float
getaspect_()
{
	return(getaspect());
}

/*
 * getfactors_
 */
getfactors_(xr, yr)
	float	*xr, *yr;
{
	getfactors(xr, yr);
}

/*
 * getdisplaysize_
 */
getdisplaysize_(xs, ys)
	float	*xs, *ys;
{
	getdisplaysize(xs, ys);
}
