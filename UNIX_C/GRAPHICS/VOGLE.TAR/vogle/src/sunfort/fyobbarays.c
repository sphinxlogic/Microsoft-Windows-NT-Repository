
/*
 * yobbarays_
 *
 */
void
yobbarays_(onoff)
	int	*onoff;
{
	yobbarays(*onoff);
}
