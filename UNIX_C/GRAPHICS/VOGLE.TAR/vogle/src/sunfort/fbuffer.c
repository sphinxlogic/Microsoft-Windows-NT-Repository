#include "vogle.h"

/*
 * backbuffer_
 */
int
backbuffer_()
{
	return(backbuffer());
}

/*
 * frontbuffer_
 */
void
frontbuffer_()
{
	frontbuffer();
}

/*
 * swapbuffers_
 */
int
swapbuffers_()
{
	return(swapbuffers());
}
