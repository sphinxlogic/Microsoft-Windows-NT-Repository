#include "vogle.h"

/*
 * prefposition_
 */
void
prefposition_(x, y)
	int	*x, *y;
{
	prefposition(*x, *y);
}

/*
 * prefsize_
 */
void
prefsize_(x, y)
	int	*x, *y;
{
	prefsize(*x, *y);
}
