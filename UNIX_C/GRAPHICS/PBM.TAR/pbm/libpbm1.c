/* libpbm1.c - pbm utility library part 1
**
** Copyright (C) 1988 by Jef Poskanzer.
**
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted, provided
** that the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation.  This software is provided "as is" without express or
** implied warranty.
*/

#include <stdio.h>
#include "pbm.h"
#include "libpbm.h"


bit **
pbm_allocarray( cols, rows )
int cols, rows;
    {
    bit **bits;
    int i;

    bits = (bit **) malloc( rows * sizeof( bit *) );
    for ( i = 0; i < rows; i++ )
	{
	bits[i] = (bit *) malloc( cols * sizeof( bit ) );
	}

    return bits;
    }
