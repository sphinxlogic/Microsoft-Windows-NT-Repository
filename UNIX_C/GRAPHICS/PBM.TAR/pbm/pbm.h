/* pbm.h - header file for libpbm portable bitmap library
*/

typedef unsigned char bit;

/* Declarations of routines. */

bit **pbm_allocarray( );
	/* bits = pbm_allocarray( cols, rows ); bits[row][col]; */

bit **pbm_readpbm( );
	/* bits = pbm_readpbm( file, &cols, &rows ); */
pbm_writepbm( );
	/* pbm_writepbm( file, bits, cols, rows ); */

bit **pbm_readcbm( );
	/* bits = pbm_readcbm( file, &cols, &rows ); */
pbm_writecbm( );
	/* pbm_writecbm( file, bits, cols, rows ); */
