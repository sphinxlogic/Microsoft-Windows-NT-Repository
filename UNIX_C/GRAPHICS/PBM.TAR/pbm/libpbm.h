/* libpbm.h - internal header file for libpbm portable bitmap library
*/

#define PBM_MAGIC1 'P'
#define PBM_MAGIC2 '1'

#define CBM_MAGIC1 42
#define OCBM_MAGIC2 23
#define NCBM_MAGIC2 24

#define VERSION_OLDCBM 1
#define VERSION_RUNLEN 2

#define DEFAULT_BITSPERCOUNT 8
#define MAX_BITSPERCOUNT 12
#define MAX_MAXCOUNT 8191

#define DEFAULT_REPEATBITS 2
#define MAX_REPEATBITS 32
