/* libpbm3.c - pbm utility library part 3
**
** Copyright (C) 1988 by Jef Poskanzer.
**
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted, provided
** that the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation.  This software is provided "as is" without express or
** implied warranty.
*/

#include <stdio.h>
#include "pbm.h"
#include "libpbm.h"


pbm_writepbm( file, bits, cols, rows )
FILE *file;
bit **bits;
int cols, rows;
    {
    int row, col, linecount;

    fprintf( file, "%c%c\n%d %d\n", PBM_MAGIC1, PBM_MAGIC2, cols, rows );

    for ( row = 0; row < rows; row++ )
	{
	linecount = 0;
        for ( col = 0; col < cols; col++ )
	    {
	    if ( linecount >= 70 )
		{
		putc( '\n', file );
		linecount = 0;
		}
	    putc( bits[row][col] ? '1' : '0', file );
	    linecount++;
	    }
	putc( '\n', file );
        }
    }
