/*
 * defaults.h
 *
 * Copyright (C) 1989, Craig E. Kolb
 *
 * This software may be freely copied, modified, and redistributed,
 * provided that this copyright notice is preserved on all copies.
 *
 * There is no warranty or other guarantee of fitness for this software,
 * it is provided solely .  Bug reports or fixes may be sent
 * to the author, who may or may not act on them as he desires.
 *
 * You may not include this software in a program or other software product
 * without supplying the source, or without informing the end-user that the
 * source is available for no extra charge.
 *
 * If you modify this software, you should include a notice giving the
 * name of the person performing the modification, the date of modification,
 * and the reason for such modification.
 *
 * $Id: defaults.h,v 3.0 89/10/27 02:05:49 craig Exp $
 *
 * $Log:	defaults.h,v $
 * Revision 3.0  89/10/27  02:05:49  craig
 * Baseline for first official release.
 * 
 */

#define DEFLIGHTSAMPLES	4	/* sqrt of number of shadow rays per pixel */

#define XRESOLUTION	512		/* Default screen size (pixels) */
#define YRESOLUTION	512
#define DEFCUTOFF	0.001		/* Default tree cutoff value */
#define MAXLEVEL	3		/* Maximum ray tree depth. */
#define PIXEL_DIV	1		/* Maximum pixel subdivision factor */
#define HFOV		45		/* Field-of-view */
#define EYEX		0		/* Eye position */
#define EYEY		20
#define EYEZ		0
#define LOOKX		0		/* Look point */
#define LOOKY		0
#define LOOKZ		0
#define UPX		0		/* Up vector */
#define UPY		0
#define UPZ		1

#define DEFREDCONT	0.25		/* Default contrast threshold values. */
#define DEFGREENCONT	0.2
#define DEFBLUECONT	0.4
