/*
 * texture.h
 *
 * Copyright (C) 1989, Craig E. Kolb
 *
 * This software may be freely copied, modified, and redistributed,
 * provided that this copyright notice is preserved on all copies.
 *
 * There is no warranty or other guarantee of fitness for this software,
 * it is provided solely .  Bug reports or fixes may be sent
 * to the author, who may or may not act on them as he desires.
 *
 * You may not include this software in a program or other software product
 * without supplying the source, or without informing the end-user that the
 * source is available for no extra charge.
 *
 * If you modify this software, you should include a notice giving the
 * name of the person performing the modification, the date of modification,
 * and the reason for such modification.
 *
 * $Id: texture.h,v 3.0 89/10/27 02:06:06 craig Exp $
 *
 * $Log:	texture.h,v $
 * Revision 3.0  89/10/27  02:06:06  craig
 * Baseline for first official release.
 * 
 */

#define CHECKER		0	/* Checkerboard */
#define BLOTCH		1	/* Color blotches */
#define BUMP		2	/* Bump mapping */
#define MARBLE		3	/* marble texture */
#define FBM		4	/* fBm texture */
#define FBMBUMP		5	/* fBm bump map */
#define WOOD		6

Texture *NewCheckText(), *NewBlotchText(), *NewBumpText(), *NewMarbleText();
Texture *NewfBmText(), *NewfBmBumpText();
Texture *NewWoodText();
/*
 * Texturing routines.
 */
int	CheckerText(), BlotchText(), BumpText(), MarbleText(), fBmText();
int	fBmBumpText(), WoodText();
