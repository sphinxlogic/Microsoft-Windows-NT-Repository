/*
 * Copyright (C) 1986   Alan Kent
 *
 * Permission is granted to freely distribute part or
 * all of this code as long as it is not for profit
 * and this message is retained in the code.
 *
 * No resposibility is taken for any damage or incorect
 * results this program generates.
 * 
 */


#include <stdio.h>
#include "graph.h"


table_st *
adjacent ( tab1 , tab2 )
table_st *tab1 , *tab2;
{
    table_st *p;
    table_st *final;

    if ( tab1 == NULL ) {
	final = tab2;
    }
    else if ( tab2 == NULL ) {
	final = tab1;
    }
    else {
	if ( tab1->size != tab2->size ) {
	    abort ( "ADJACENT: Cannot join tables of different length" );
	}
	else {
	    for ( p = tab1; p->next != NULL; p = p->next );
	    p->next = tab2;
	    final = tab1;
	}
    }
    return ( final );
}
