/*
 * Copyright (C) 1986   Alan Kent
 *
 * Permission is granted to freely distribute part or
 * all of this code as long as it is not for profit
 * and this message is retained in the code.
 *
 * No resposibility is taken for any damage or incorect
 * results this program generates.
 * 
 */


#include <stdio.h>

extern int linenum;
extern char *infilename;
extern int warnings;



abort ( mesg , parm )
char *mesg , *parm;
{
    fprintf ( stderr , "%s: near line %d: " , infilename , linenum );
    fprintf ( stderr , mesg , parm );
    fprintf ( stderr , "\n" );
    while ( yyinput () > 0 );	/* read until EOF */
    exit ( 1 );
}


warn ( mesg , parm )
char *mesg , *parm;
{
    if ( warnings ) {
	fprintf ( stderr , "%s: warning near line %d: " , infilename , linenum );
	fprintf ( stderr , mesg , parm );
	fprintf ( stderr , "\n" );
    }
}

