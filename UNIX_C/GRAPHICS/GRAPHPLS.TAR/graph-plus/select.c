/*
 * Copyright (C) 1986   Alan Kent
 *
 * Permission is granted to freely distribute part or
 * all of this code as long as it is not for profit
 * and this message is retained in the code.
 *
 * No resposibility is taken for any damage or incorect
 * results this program generates.
 * 
 */


#include <stdio.h>
#include "graph.h"


table_st *
select ( table , attr_expr )
table_st *table;
attr_st *attr_expr;
{
    double eval ();

    int i , j;


    /* if any line is not selected, simply copy all following lines */
    /* back over it. This means the array may be actually larger than */
    /* necessary for the data, but it is a lot easier!!! */

    j = 0;
    for ( i = 0; i < table->size; i++ ) {
	if ( eval ( table , i , attr_expr ) != 0.0 ) { /* True */
	    /* save copy */
	    copy_entry ( table , j , i );
	    j++;
	}
    }
    table->size -= i - j;
    return ( table );
}

