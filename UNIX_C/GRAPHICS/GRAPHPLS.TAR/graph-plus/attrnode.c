/*
 * Copyright (C) 1986   Alan Kent
 *
 * Permission is granted to freely distribute part or
 * all of this code as long as it is not for profit
 * and this message is retained in the code.
 *
 * No resposibility is taken for any damage or incorect
 * results this program generates.
 * 
 */


#include <stdio.h>
#include "graph.h"

extern char *new ();

/* create an attribute expression node */

attr_st *
attr_node ( node_type , value , left , right )
int node_type;
double value;
attr_st *left , *right;
{
    attr_st *p;

    p = (attr_st *) new ( sizeof ( attr_st ) );
    p->node_type = node_type;
    p->value = value;
    p->left = left;
    p->right = right;
    return ( p );
}

