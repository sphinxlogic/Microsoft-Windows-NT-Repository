/*
 * Copyright (C) 1986   Alan Kent
 *
 * Permission is granted to freely distribute part or
 * all of this code as long as it is not for profit
 * and this message is retained in the code.
 *
 * No resposibility is taken for any damage or incorect
 * results this program generates.
 * 
 */


#include <stdio.h>
#include "graph.h"
#include "y.tab.h"


extern char *new ();


parm_st *
parm_node ( ident , parm_type )
char *ident;
int parm_type;
{
    parm_st *p;

    p = (parm_st *) new ( sizeof ( parm_st ) );
    p->ident = ident;
    p->parm_type = parm_type;
    p->next = NULL;
    if ( ident != NULL ) {
	if ( parm_type == TABLE )
	    tab_declare ( ident , NULL );
	else
	    var_declare ( ident , (double)0.0 );
    }
    return ( p );
}
