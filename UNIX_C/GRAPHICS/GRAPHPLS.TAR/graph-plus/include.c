/*
 * Copyright (C) 1986   Alan Kent
 *
 * Permission is granted to freely distribute part or
 * all of this code as long as it is not for profit
 * and this message is retained in the code.
 *
 * No resposibility is taken for any damage or incorect
 * results this program generates.
 * 
 */


#include <stdio.h>


/* This is possibly a bit dangerous as i am not sure how yacc will take */
/* to being called recursively */


extern FILE *yyin;
extern int linenum;
extern char *infilename;


include ( filename )
char *filename;
{
    FILE *old_fp , *fp;
    int old_linenum;
    char *old_filename;

    if ( filename == NULL )
	return;
    if ( ( fp = fopen ( filename , "r" ) ) == NULL )
	abort ( "failed to open include file '%s'" , filename );
    old_fp = yyin;
    old_filename = infilename;
    old_linenum = linenum;
    yyin = fp;
    infilename = filename;
    linenum = 1;
    yyparse ();
    fclose ( yyin );
    yyin = old_fp;
    infilename = old_filename;
    linenum = old_linenum;
    yyparse ();
}

