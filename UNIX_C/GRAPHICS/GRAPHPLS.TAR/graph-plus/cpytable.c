/*
 * Copyright (C) 1986   Alan Kent
 *
 * Permission is granted to freely distribute part or
 * all of this code as long as it is not for profit
 * and this message is retained in the code.
 *
 * No resposibility is taken for any damage or incorect
 * results this program generates.
 * 
 */


#include <stdio.h>
#include "graph.h"


extern table_st *new_table ();


table_st *
copy_of_table ( oldtab )
table_st *oldtab;
{
    int i;
    register table_st *table , *ftp , *ttp;

    if ( oldtab == NULL )
	return ( NULL );
    table = new_table ( num_cols ( oldtab ) , oldtab->size );
    ftp = oldtab;
    ttp = table;
    while ( ftp != NULL ) {
	for ( i = 0; i < table->size; i++ )
	    ttp->data[i] = ftp->data[i];
	ftp = ftp->next;
	ttp = ttp->next;
    }
    return ( table );
}
