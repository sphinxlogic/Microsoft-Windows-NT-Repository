/*
 * Copyright (C) 1986   Alan Kent
 *
 * Permission is granted to freely distribute part or
 * all of this code as long as it is not for profit
 * and this message is retained in the code.
 *
 * No resposibility is taken for any damage or incorect
 * results this program generates.
 * 
 */


#include <stdio.h>
#include "graph.h"

copy_entry ( table , to , from )
table_st *table;
int to , from;
{
    table_st *p;

    for ( p = table; p != NULL; p = p->next )
	p->data[to] = p->data[from];
}

