/*
 * Copyright (C) 1986   Alan Kent
 *
 * Permission is granted to freely distribute part or
 * all of this code as long as it is not for profit
 * and this message is retained in the code.
 *
 * No resposibility is taken for any damage or incorect
 * results this program generates.
 * 
 */


#include <stdio.h>
#include "graph.h"


extern table_st *new_table ();
extern double eval ();


table_st *
project ( table , attr_expr_list )
table_st *table;
expr_list_st *attr_expr_list;
{
    table_st *newtab , *p;
    expr_list_st *list;
    int count;
    int i;

    if ( table == NULL )
	abort ( "cannot project on an empty table" );
    count = 0;
    for ( list = attr_expr_list; list != NULL; list = list->next )
	count++;
    newtab = new_table ( count , table->size );
    for ( list = attr_expr_list , p = newtab; list != NULL; list = list->next , p = p->next ) {
	for ( i = 0; i < table->size; i++ )
	    p->data[i] = eval ( table , i , list->expr );
    }
    free_table ( table );
    return ( newtab );
}

