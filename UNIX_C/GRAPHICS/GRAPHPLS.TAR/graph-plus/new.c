/*
 * Copyright (C) 1986   Alan Kent
 *
 * Permission is granted to freely distribute part or
 * all of this code as long as it is not for profit
 * and this message is retained in the code.
 *
 * No resposibility is taken for any damage or incorect
 * results this program generates.
 * 
 */


#include <stdio.h>


extern char *malloc ();

int bytes_allocated = 0;


char *
new ( size )
int size;
{
    char *p;
    char buf[100];

    if ( size < 1 )
	size = 1;
    p = malloc ( size );
    if ( p == NULL ) {
	sprintf ( buf ,
	    "out of memory: request for %d bytes failed, %d allocated so far\n",
	    size , bytes_allocated );
	abort ( buf );
    }
    bytes_allocated += size;
    return ( p );
}


release ( mem )
char *mem;
{
    if ( mem == NULL )
	abort ( "Trying to free NULL pointer" );
    free ( mem );
}

