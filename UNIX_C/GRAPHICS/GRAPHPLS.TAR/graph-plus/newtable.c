/*
 * Copyright (C) 1986   Alan Kent
 *
 * Permission is granted to freely distribute part or
 * all of this code as long as it is not for profit
 * and this message is retained in the code.
 *
 * No resposibility is taken for any damage or incorect
 * results this program generates.
 * 
 */


#include <stdio.h>
#include "graph.h"


extern char *new ();


table_st *
new_table ( cols , rows )
int cols , rows;
{
    table_st **pp;
    table_st *newtab;

    newtab = NULL;
    pp = &newtab;
    while ( cols-- > 0 ) {
	(*pp) = (table_st *) new ( sizeof ( table_st ) );
	(*pp)->data = (double *) new ( sizeof ( double ) * rows );
	(*pp)->size = rows;
	(*pp)->next = NULL;
	pp = &(*pp)->next;
    }
    return ( newtab );
}

