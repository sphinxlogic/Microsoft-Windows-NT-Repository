/*
 * Copyright (C) 1986   Alan Kent
 *
 * Permission is granted to freely distribute part or
 * all of this code as long as it is not for profit
 * and this message is retained in the code.
 *
 * No resposibility is taken for any damage or incorect
 * results this program generates.
 * 
 */


#include <stdio.h>
#include "graph.h"


double
count_fun ( table , from , to )
table_st *table;
{
    if ( table == NULL )
	return ( 0.0 );
    if ( to >= table->size )
	to = table->size - 1;
    if ( from > to )
	return ( 0.0 );
    return ( (double) to - from + 1 );
}

