/*
 * Copyright (C) 1986   Alan Kent
 *
 * Permission is granted to freely distribute part or
 * all of this code as long as it is not for profit
 * and this message is retained in the code.
 *
 * No resposibility is taken for any damage or incorect
 * results this program generates.
 * 
 */


#include <stdio.h>
#include <math.h>
#include "graph.h"
#include "y.tab.h"




table_st *
cumulate ( table , attr )
table_st *table;
int attr;
{
    double total;
    double *data;
    int i;
    table_st *p;

    total = 0.0;
    p = table;
    if ( attr < 1 )
	abort ( "Cannot CUMULATE on column $0" );
    while ( --attr > 0  &&  p != NULL )
	p = p->next;
    if ( p == NULL )
	abort ( "Illegal column to CUMULATE by" );
    data = p->data;
    for ( i = 0; i < p->size; i++ ) {
	total += data[i];
	data[i] = total;
    }
    return ( table );
}

