/*
 * Copyright (C) 1986   Alan Kent
 *
 * Permission is granted to freely distribute part or
 * all of this code as long as it is not for profit
 * and this message is retained in the code.
 *
 * No resposibility is taken for any damage or incorect
 * results this program generates.
 * 
 */


#include <stdio.h>
#include "graph.h"


double
min_fun ( table , from , to )
table_st *table;
int from , to;
{
    int i;
    double val;

    if ( table == NULL )
	abort ( "MIN requires at least a single column table" );
    if ( table->size < 1 ) {
	warn ( "MIN requires at least one value in table " );
	return ( 0.0 );
    }
    if ( to >= table->size )
	to = table->size - 1;
    val = table->data[from];
    for ( i = from + 1; i <= to; i++ )
	if ( table->data[i] < val )
	    val = table->data[i];
    return ( val );
}

