/*
 *	tek4.h - CGI version
 *	copyright 1988 Ronald Florence
 */

#define WEATHER		1
#define Maxpts		1000
#define	int		short	/* for CGI functions	*/
#define Tekx		4096.0
#define Teky		3120.0
#define Vmax		31000	/* Tek programs cheat! */
#define Hmax		32000

double	xm = Hmax / Tekx,
	ym = Vmax / Teky,
	xscale = (32768 - Hmax) / 2.0,
	yscale;

#define Left		0	/* character alignment  */
#define Base		0
#define Solid		1	/* linetypes */
#define Longdash	2
#define Dotted		3
#define Dotdash		4
#define Shortdash	7
#define Altcolor	2	/* red */


extern	int	dev;		/* device handle */

#define Align(H, V)	{						\
			int	gh, gv;					\
			vst_alignment(dev, Left, Base, &gh, &gv);	\
			}
#define Clear_scr()	/*  v_clrwk(dev)  */
#define Set_line(L)	vsl_type(dev, L)
#define Increment(X,Y)	
#define Switch_pen()	{			    	\
			vst_color(dev, Altcolor);	\
			vsl_color(dev, Altcolor);	\
			vsm_color(dev, Altcolor);	\
			}

#define Set_charsize(s)	{						\
			int	chh, chw, cellh;		        \
			chh = charht[s] * ym;			        \
			vst_height(dev, chh, &chw, &cellw, &cellh);	\
			}
#define	Vector(N, PTS)	v_pline(dev, (N/2), PTS)
#define Marker(N, PTS)	v_pmarker(dev, (N/2), PTS)
#define Wr_str(X, Y, p)	v_gtext(dev, X, Y, p)
