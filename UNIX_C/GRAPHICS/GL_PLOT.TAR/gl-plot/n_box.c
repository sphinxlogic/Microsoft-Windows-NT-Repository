#ifndef lint
static char sccsid[] = "@(#) n_box.c 5.1 89/02/20";
#endif

/*
 *	Copyright (c) David T. Lewis 1987, 1988
 *	All rights reserved.
 *
 *	Permission is granted to use this for any personal noncommercial use.
 *	You may not distribute source or executable code for profit, nor
 *	may you distribute it with a commercial product without the written
 *	consent of the author.  Please send modifications to the author for
 *	inclusion in updates to the program.  Thanks.
 */

/* Fri Jul  3 23:43:36 EDT 1987
 * dtlewis
 * Routine to draw a box.
 */

extern int n_movepen(), n_draw();

int n_box(x1,y1,x2,y2)  
	int x1, y1, x2, y2;
{
	int n_movepen(), n_draw();
	if (n_movepen(x1,y1)) return(1);
	if (n_draw(x2,y1)) return(1);
	if (n_draw(x2,y2)) return(1);
	if (n_draw(x1,y2)) return(1);
	if (n_draw(x1,y1)) return(1);
	return(0);
}
