#ifndef lint
static char sccsid[] = "@(#) n_point.c 5.1 89/02/20";
#endif

/*
 *	Copyright (c) David T. Lewis 1988
 *	All rights reserved.
 *
 *	Permission is granted to use this for any personal noncommercial use.
 *	You may not distribute source or executable code for profit, nor
 *	may you distribute it with a commercial product without the written
 *	consent of the author.  Please send modifications to the author for
 *	inclusion in updates to the program.  Thanks.
 */

/* Sun Aug 21 21:59:55 EDT 1988
** dtlewis
** Routine to draw a point in normalized 2-d space.
*/

#include "config.h"
#include "bitmaps.h"
#include "graphics.h"

extern struct GL_graphics graphics;
extern int n_movepen();
extern int p_wr_pix();

int n_point(x,y)  
	int x,y;
{
	if (n_movepen(x,y)) return(1);
	if (p_wr_pix(n_to_p_x(x), n_to_p_y(y))) return(1);
	return(0);
}
