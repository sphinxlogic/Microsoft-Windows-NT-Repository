/****** Warning! Do not alter this file without updating gl.h! *******/

/*	@(#) gf_types.h 5.1 89/02/20	*/
/*
 *	Copyright (c) David T. Lewis 1988
 *	All rights reserved.
 *
 *	Permission is granted to use this for any personal noncommercial use.
 *	You may not distribute source or executable code for profit, nor
 *	may you distribute it with a commercial product without the written
 *	consent of the author.  Please send modifications to the author for
 *	inclusion in updates to the program.  Thanks.
 */

/*	Definition(s) required for more than one include file.
 */

/* Define pixel setting modes. 			*/

#define CLEAR 0
#define AND 1
#define OR 2
#define XOR 3

/* Define colors.	 			*/

#define BLACK        0
#define BLUE         1
#define GREEN        2
#define CYAN         3
#define RED          4
#define MAGENTA      5
#define BROWN        6
#define WHITE        7
#define GREY         8
#define LT_BLUE      9
#define LT_GREEN    10
#define LT_CYAN     11
#define LT_RED      12
#define LT_MAGENTA  13
#define YELLOW      14
#define LT_WHITE    15

/* Define line styles (not yet implemented).	*/

#define SOLID 0xffffffffL	/* XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX  */
#define DOTTED 0x66666666L	/* XX..XX..XX..XX..XX..XX..XX..XX..  */
#define DASHED 0xffe0ffe0L	/* XXXXXXXXXXX.....XXXXXXXXXXX.....  */
#define SHORTDASHED 0xf8f8f8f8L	/* XXXXX...XXXXX...XXXXX...XXXXX...  */
#define LONGDASHED 0xffffff00L	/* XXXXXXXXXXXXXXXXXXXXXXXX........  */
#define DOTDASHED 0xfc30fc30L	/* XXXXXX....XX....XXXXXX....XX....  */

/* Define line weights (not yet implemented).	*/

#define LIGHT 1
#define MEDIUM 2
#define HEAVY 4


