:
#  Contributed by Denis Fortin, April 1988.
#
#  mode - This trivial little command file is used to set the graphics mode
#	  of the console on Microport System V/AT.
#
#  Usage:
#		mode [value]
#
# 	where: value is an integer used to select the current display
#		     mode.  If it is omitted, the screen is returned to
#		     normal text mode.
#
#  Examples:
#	mode
#		Returns to normal text mode
#
#	mode 16
#		Puts an EGA card with Enhanced Display adapter in 640x350
#		graphics mode.
#
#	mode 6
#		Puts a CGA card in 640x200 graphics mode.
#
if [ $# -lt 1 ] 
then
	echo "\033[=h\c"
else
	echo "\033[=${1}h\c"
fi
