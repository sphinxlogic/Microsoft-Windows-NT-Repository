#ifndef lint
static char sccsid[] = "@(#) c_cellst.c 5.1 89/02/20";
#endif

/*
 *	Copyright (c) David T. Lewis 1988
 *	All rights reserved.
 *
 *	Permission is granted to use this for any personal noncommercial use.
 *	You may not distribute source or executable code for profit, nor
 *	may you distribute it with a commercial product without the written
 *	consent of the author.  Please send modifications to the author for
 *	inclusion in updates to the program.  Thanks.
 */

/* Write string of a graphics characters to the screen.			*/
/* Sat Mar 19 23:56:46 EST 1988						*/
/* system5 dtlewis 2 2.3.0-U AT						*/

/* Routine to display cell mode text string with upper left corner of	*/
/* first character located at the current graphics cursor.  The		*/
/* graphics cursor is incremented as characters are written.		*/

#include <stdio.h>
#include "config.h"
extern int c_cellchar();

int c_cellstr(strng)  
char strng[];
{
	int i;
	for(i=0; strng[i] != 0; i++)  {
		if (c_cellchar(strng[i])) return(1);
	}
	return(0);
}

