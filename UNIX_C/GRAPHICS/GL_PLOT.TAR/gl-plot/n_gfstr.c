#ifndef lint
static char sccsid[] = "@(#) n_gfstr.c 5.1 89/02/20";
#endif

/*
 *	Copyright (c) David T. Lewis 1987, 1988
 *	All rights reserved.
 *
 *	Permission is granted to use this for any personal noncommercial use.
 *	You may not distribute source or executable code for profit, nor
 *	may you distribute it with a commercial product without the written
 *	consent of the author.  Please send modifications to the author for
 *	inclusion in updates to the program.  Thanks.
 */

/* Write string of a graphics characters to the screen.			*/
/* Sat Dec 12 12:51:27 EST 1987						*/
/* system5 dtlewis 2 2.2-U AT						*/

#include <stdio.h>

extern int n_grafchar();

int n_grafstr(strng)  
char strng[];
{
	int i;
	for(i=0; strng[i] != 0; i++)  {
		if (n_grafchar(strng[i])) return(1);
	}
	return(0);
}

