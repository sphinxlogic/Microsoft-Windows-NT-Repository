/* 
 * Delta modulation uncompress
 *
 * (C) Copyright 1989, 1990 Diomidis Spinellis.  All rights reserved.
 * 
 * $Header: deltac.c,v 1.1 90/06/08 22:13:42 dds Rel $
 *
 * Permission to use, copy, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted,
 * provided that the above copyright notice appear in all copies and that
 * both that copyright notice and this permission notice appear in
 * supporting documentation.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
 * MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */


#include <stdio.h>

#ifndef lint
static char RCSid[] = "$Header: deltac.c,v 1.1 90/06/08 22:13:42 dds Rel $";
#endif

static prev, stored;

#ifdef SLOW
void
putnib(x)
	int x;
{

	if (stored) {
		if (putchar(prev | (x & 0xf)) == EOF) {
			perror("<stdout>");
			exit(1);
		}
		stored = 0;
	} else {
		prev = x << 4;
		stored = 1;
	}
}
#else
#define putnib(x) \
do { \
	if (stored) { \
		if (putchar(prev | (x & 0xf)) == EOF) { \
			perror("<stdout>"); \
			exit(1); \
		} \
		stored = 0; \
	} else { \
		prev = (x) << 4; \
		stored = 1; \
	} \
} while(0)
#endif

void
flushnib()
{
	if (stored)
		if (putchar(prev | 8) == EOF) {
			perror("<stdout>");
			exit(1);
		}
}


main(argc, argv)
	int argc;
	char *argv[];
{
	register c, cp = 256, delta;

	if (argc != 1) {
		fprintf(stderr, "%s: usage %s\n", argv[1]);
		exit(1);
	}
	while((c = getchar()) != EOF) {
		delta = c - cp;
		if (delta > 7 || delta < -7) {
			putnib(8);
			putnib(c >> 4);
			putnib(c);
		} else if (delta >= 0)
			putnib(delta);
		else
			putnib(8 | -delta);
		cp = c;
	}
	flushnib();
}
