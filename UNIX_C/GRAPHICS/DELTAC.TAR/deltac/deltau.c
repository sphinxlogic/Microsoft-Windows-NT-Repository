/* 
 * Delta modulation uncompress
 *
 * (C) Copyright 1989, 1990 Diomidis Spinellis.  All rights reserved.
 * 
 * $Header: deltau.c,v 1.1 90/06/08 22:13:50 dds Rel $
 *
 * Permission to use, copy, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted,
 * provided that the above copyright notice appear in all copies and that
 * both that copyright notice and this permission notice appear in
 * supporting documentation.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
 * MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

#include <stdio.h>

#ifndef lint
static char RCSid[] = "$Header: deltau.c,v 1.1 90/06/08 22:13:50 dds Rel $";
#endif

static prev, stored;

#ifdef SLOW
int
getnib()
{
	if (stored) {
		stored = 0;
		return prev & 0xf;
	} else {
		if ((prev = getchar()) == EOF)
			exit(0);
		else {
			stored = 1;
			return prev >> 4;
		}
	}
}
#else
#define getnib() \
( \
	(stored) ? ( \
		stored = 0, \
		prev & 0xf \
	) : ( \
		((prev = getchar()) == EOF) ? \
			exit(0) \
		: ( \
			stored = 1, \
			prev >> 4 \
		) \
	) \
)
#endif

main(argc, argv)
	int argc;
	char *argv[];
{
	register c, cn;

	if (argc != 1) {
		fprintf(stderr, "%s: usage %s\n", argv[1]);
		exit(1);
	}
	for(;;) {
		switch (c = getnib()) {
		case 8:
			/* Change code */
			cn = getnib() << 4;
			cn |= getnib();
			break;
		case 0:
			/* No change */
			break;
		case 1: case 2: case 3: case 4: case 5: case 6: case 7:
			/* Delta is +ve */
			cn += c;
			break;
		case 9: case 10: case 11: case 12: case 13: case 14: case 15:
			/* Delta is -ve */
			cn -= c & 7;
			break;
		}
		if (putchar(cn) == EOF) {
			perror("<stdout>");
			exit(1);
		}
	}
}
