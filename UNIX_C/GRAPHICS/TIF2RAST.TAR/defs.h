/*
 * tif2ps/tifdump -- convert TIFF to PostScript
 *
 * written by:
 * Andreas Lampen, TU-Berlin (andy@coma.UUCP)
 *			     (andy@db0tui62.BITNET)
 *
 * Copyright (C) 1988 by the author.
 * Permission is granted to copy and distribute this program
 * without charge, provided this copyright notice is included
 * in the copy.
 * This Software is distributed on an as-is basis. There will be
 * ABSOLUTELY NO WARRANTY for any part of this software to work
 * correct. In no case will the author be liable to you for damages
 * caused by the usage of this software.
 */

/*
 * defs.h -- general type and constant definitions
 * 
 * $Header: defs.h[1.0] Thu Dec 29 20:10:13 1988 andy@coma published $
 */

typedef char           CHAR;
typedef int            INT;
typedef unsigned int   UINT;
typedef short          SHORT;
typedef unsigned short USHORT;
typedef long           LONG;
typedef unsigned long  ULONG;
typedef double         DOUBLE;

#define ERROR -1
#define OK     0

#define VOID   void
#define LOCAL  static
#define STATIC static
#define EXPORT
