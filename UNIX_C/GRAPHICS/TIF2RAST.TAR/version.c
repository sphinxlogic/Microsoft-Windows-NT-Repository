#include "defs.h"
CHAR *version () {
  STATIC CHAR ConfID[] =  "1.0 (Sun Feb 12 21:55:10 1989 by wu@sunybcs)";
  return ConfID;
}
