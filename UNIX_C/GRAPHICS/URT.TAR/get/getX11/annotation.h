#define BLOCK_NOTE_SIZE	100

typedef struct annotation_struct {
	int		x;
	int		y;
	char		* string;
	struct annotation_struct    * next;
	} ANNOTATION;

ANNOTATION	* find_closest_annotation ();
ANNOTATION	* find_next_annotation ();
void		setup_annotation ();
void		add_to_annotation ();
