#! /bin/sh
crop 0 345 509 824 | repos -p 0 0
