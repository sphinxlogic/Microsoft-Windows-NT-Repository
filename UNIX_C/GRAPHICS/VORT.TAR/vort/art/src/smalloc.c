#include <stdio.h>

extern char	*malloc();

/*
 * smalloc
 *
 *	allocates memory - checking for null
 */
char *
smalloc(size)
	unsigned	size;
{
	char	*p, buf[BUFSIZ];

	if ((p = malloc(size)) == (char *)NULL) {
		sprintf(buf, "smalloc: request for %d bytes from malloc returns NULL.\n", size);
		fatal(buf);
	}

	return(p);
}

