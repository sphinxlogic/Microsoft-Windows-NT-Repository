# include "stdio.h"
# define U(x) x
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX BUFSIZ
# define output(c) putc(c,yyout)
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
# define ECHO fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin = {stdin}, *yyout = {stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;
#include <math.h>
#include "art.h"
#include "gram.h"

extern attr	*astackp;
extern int	linecount;

# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:
	return(SPHERE);
break;
case 2:
	return(POLYGON);
break;
case 3:
return(GEOMETRY);
break;
case 4:
	return(BOX);
break;
case 5:
return(CYLINDER);
break;
case 6:
return(ELLIPSOID);
break;
case 7:
return(COMPOSITE);
break;
case 8:
	return(CONE);
break;
case 9:
	return(RING);
break;
case 10:
	return(RING);
break;
case 11:
	return(OFFFILE);
break;
case 12:
	return(OFFFILE);
break;
case 13:
return(VORTFILE);
break;
case 14:
	return(TOP);
break;
case 15:
	return(BASE);
break;
case 16:
return(CONST);
break;
case 17:
return(COEFFS);
break;
case 18:
	return(ORDER);
break;
case 19:
	return(TORUS);
break;
case 20:
return(SUPERQUADRIC);
break;
case 21:
	return(CSG);
break;
case 22:
{
			yylval.y_int = PHONGSHADING;
			return(OPTION);
		}
break;
case 23:
{
			yylval.y_int = BACKFACING;
			return(OPTION);
		}
break;
case 24:
	return(ON);
break;
case 25:
	return(OFF);
break;
case 26:
return(MATERIAL);
break;
case 27:
	return(CENTER);
break;
case 28:
	return(COLOUR);
break;
case 29:
	return(COLOUR);
break;
case 30:
	return(AMBIENT);
break;
case 31:
return(REFLECTANCE);
break;
case 32:
return(ABSORPTION);
break;
case 33:
return(TRANSPARENCY);
break;
case 34:
	return(RADIUS);
break;
case 35:
	return(RADII);
break;
case 36:
	return(LIGHT);
break;
case 37:
return(DIRECTION);
break;
case 38:
	return(ANGLE);
break;
case 39:
	return(NUMRAYS);
break;
case 40:
	return(VERTEX);
break;
case 41:
return(LOCATION);
break;
case 42:
return(ALGEBRAIC);
break;
case 43:
	return(TILE);
break;
case 44:
	return(TEXTURE);
break;
case 45:
	return(MAP);
break;
case 46:
	return(RANGE);
break;
case 47:
return(BLENDCOLOR);
break;
case 48:
return(BLENDCOLOR);
break;
case 49:
return(SCALEFACTORS);
break;
case 50:
	return(SIZE);
break;
case 51:
return(EQUATION);
break;
case 52:
return(TRANSLATE);
break;
case 53:
	return(ROTATE);
break;
case 54:
	return(SCALE);
break;
case 55:
	return(LOOKAT);
break;
case 56:
	return(UP);
break;
case 57:
return(FIELDOFVIEW);
break;
case 58:
return(RAYSPERPIXEL);
break;
case 59:
return(VREF1);
break;
case 60:
	return(VREF1);
break;
case 61:
	return(VREF2);
break;
case 62:
	return(TITLE);
break;
case 63:
return(BACKGROUND);
break;
case 64:
return(MAXHITLEVEL);
break;
case 65:
	return(OUTPUT);
break;
case 66:
return(TWENTYFIVEBIT);
break;
case 67:
	{
			yylval.y_int = PIX_RGB;
			return(FILETYPE);
		}
break;
case 68:
	{
			yylval.y_int = PIX_RLE;
			return(FILETYPE);
		}
break;
case 69:
	{
			yylval.y_int = PIX_RGBA;
			return(FILETYPE);
		}
break;
case 70:
	{
			yylval.y_int = PIX_RLEA;
			return(FILETYPE);
		}
break;
case 71:
{
			yylval.y_str = (char *)smalloc(strlen(yytext) + 1);
			strcpy(yylval.y_str, yytext);
			return(NAME);
		}
break;
case 72:
{
			yylval.y_int = atoi(yytext);
			return(INTEGER);
		}
break;
case 73:
{
			yylval.y_flt = atof(yytext);
			return(FLOAT);
		}
break;
case 74:
	return(PLUS);
break;
case 75:
	return(MINUS);
break;
case 76:
	return(MULT);
break;
case 77:
	return(DIV);
break;
case 78:
	return(PCENT);
break;
case 79:
	return(POWER);
break;
case 80:
	return(COMMA);
break;
case 81:
	return(LP);
break;
case 82:
	return(RP);
break;
case 83:
	return(EQUALS);
break;
case 84:
	return(DOT);
break;
case 85:
	return(DOLS);
break;
case 86:
	{
			char	buf[BUFSIZ], *p;
			
			for (p = buf; (*p = getchar()) != '"'; p++)
				if (*p == '\n' || *p == EOF)
					yyerror("syntax error");

			*p = 0;

			yylval.y_str = (char *)smalloc(strlen(buf) + 1);
			strcpy(yylval.y_str, buf);

			return(STRING);
		}
break;
case 87:
	{
			astackp++;
			*astackp = *(astackp - 1);
			return(LBRACE);
		}
break;
case 88:
	{
			return(RBRACE);
		}
break;
case 89:
	{
			linecount++;
		}
break;
case 90:
	{
			;
		}
break;
case 91:
	{
			char	c1, c2;
			int	comline;
			char	buf[BUFSIZ];

			comline = linecount;

			do {
				while ((c1 = getchar()) != '*' && c1 != EOF)
					if (c1 == '\n')
						linecount++;
				c2 = getchar();
				if (c2 == '\n')
					linecount++;
			} while (c2 != '/' && c2 != EOF);

			if (c1 == EOF || c2 == EOF) {
				sprintf(buf, "art: unterminated comment - started line %d.\n", comline);
				fatal(buf);
			}
		}
break;
case -1:
break;
default:
fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */
int yyvstop[] = {
0,

72,
0,

72,
0,

90,
0,

89,
0,

86,
0,

78,
0,

81,
0,

82,
0,

76,
0,

74,
0,

80,
0,

75,
0,

73,
84,
0,

77,
0,

72,
0,

83,
0,

71,
0,

79,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

87,
0,

88,
0,

85,
0,

73,
0,

91,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

24,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

56,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

4,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

21,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

45,
71,
0,

71,
0,

71,
0,

71,
0,

25,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

67,
71,
0,

71,
0,

68,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

14,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

15,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

8,
71,
0,

71,
0,

71,
0,

71,
0,

9,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

60,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

69,
71,
0,

10,
71,
0,

70,
71,
0,

71,
0,

71,
0,

50,
71,
0,

71,
0,

71,
0,

71,
0,

43,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

38,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

29,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

36,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

18,
71,
0,

71,
0,

71,
0,

71,
0,

35,
71,
0,

71,
0,

46,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

54,
71,
0,

71,
0,

71,
0,

71,
0,

62,
71,
0,

19,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

27,
71,
0,

71,
0,

28,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

55,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

65,
71,
0,

71,
0,

71,
0,

34,
71,
0,

71,
0,

71,
0,

71,
0,

53,
71,
0,

71,
0,

1,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

40,
71,
0,

71,
0,

71,
0,

71,
0,

30,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

61,
71,
0,

71,
0,

11,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

39,
71,
0,

12,
71,
0,

71,
0,

2,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

44,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

16,
71,
0,

5,
71,
0,

71,
0,

71,
0,

51,
71,
0,

71,
0,

3,
71,
0,

41,
71,
0,

26,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

59,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

13,
71,
0,

71,
0,

42,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

7,
71,
0,

37,
71,
0,

6,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

52,
71,
0,

71,
0,

71,
0,

32,
71,
0,

23,
71,
0,

63,
71,
0,

47,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

48,
71,
0,

71,
0,

57,
71,
0,

64,
71,
0,

71,
0,

71,
0,

31,
71,
0,

71,
0,

71,
0,

71,
0,

71,
0,

17,
71,
0,

22,
71,
0,

58,
71,
0,

49,
71,
0,

20,
71,
0,

33,
71,
0,

71,
0,

66,
71,
0,
0};
# define YYTYPE int
struct yywork { YYTYPE verify, advance; } yycrank[] = {
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	1,3,	1,4,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	1,3,	0,0,	1,5,	
0,0,	1,6,	1,7,	6,39,	
0,0,	1,8,	1,9,	1,10,	
1,11,	1,12,	1,13,	1,14,	
1,15,	1,16,	1,16,	1,16,	
1,16,	1,16,	1,16,	1,16,	
1,16,	1,16,	1,16,	15,41,	
0,0,	0,0,	1,17,	0,0,	
0,0,	0,0,	1,18,	1,18,	
1,18,	1,18,	1,18,	1,18,	
1,18,	1,18,	1,18,	1,18,	
1,18,	1,18,	1,18,	1,18,	
1,18,	1,18,	1,18,	1,18,	
1,18,	1,18,	1,18,	1,18,	
1,18,	1,18,	1,18,	1,18,	
0,0,	0,0,	0,0,	1,19,	
1,18,	0,0,	1,20,	1,21,	
1,22,	1,23,	1,24,	1,25,	
1,26,	1,18,	1,18,	1,18,	
1,18,	1,27,	1,28,	1,29,	
1,30,	1,31,	1,18,	1,32,	
1,33,	1,34,	1,35,	1,36,	
1,18,	1,18,	1,18,	1,18,	
1,37,	23,53,	1,38,	14,40,	
14,40,	14,40,	14,40,	14,40,	
14,40,	14,40,	14,40,	14,40,	
14,40,	16,40,	25,56,	16,16,	
16,16,	16,16,	16,16,	16,16,	
16,16,	16,16,	16,16,	16,16,	
16,16,	18,18,	21,46,	18,18,	
18,18,	18,18,	18,18,	18,18,	
18,18,	18,18,	18,18,	18,18,	
18,18,	21,47,	24,54,	26,57,	
21,48,	28,60,	29,61,	24,55,	
18,18,	18,18,	18,18,	18,18,	
18,18,	18,18,	18,18,	18,18,	
18,18,	18,18,	18,18,	18,18,	
18,18,	18,18,	18,18,	18,18,	
18,18,	18,18,	18,18,	18,18,	
18,18,	18,18,	18,18,	18,18,	
18,18,	18,18,	35,83,	42,86,	
43,87,	44,88,	18,18,	45,89,	
18,18,	18,18,	18,18,	18,18,	
18,18,	18,18,	18,18,	18,18,	
18,18,	18,18,	18,18,	18,18,	
18,18,	18,18,	18,18,	18,18,	
18,18,	18,18,	18,18,	18,18,	
18,18,	18,18,	18,18,	18,18,	
18,18,	18,18,	20,42,	27,58,	
31,66,	22,49,	47,92,	36,84,	
30,62,	27,59,	48,93,	31,67,	
20,43,	20,44,	20,45,	22,50,	
30,63,	36,85,	32,68,	22,51,	
30,64,	33,74,	32,69,	30,65,	
32,70,	22,52,	32,71,	33,75,	
49,94,	32,72,	46,90,	34,78,	
32,73,	51,99,	33,76,	34,79,	
52,100,	53,101,	53,102,	33,77,	
54,103,	34,80,	55,104,	50,95,	
34,81,	56,105,	46,91,	57,106,	
58,107,	34,82,	50,96,	50,97,	
50,98,	59,108,	60,110,	61,113,	
62,114,	64,115,	60,111,	65,116,	
66,117,	67,118,	60,112,	68,119,	
69,122,	59,109,	70,123,	71,124,	
72,125,	73,126,	74,127,	75,128,	
76,129,	68,120,	77,130,	78,131,	
80,134,	79,132,	80,135,	81,136,	
82,137,	84,138,	85,139,	86,140,	
68,121,	79,133,	87,141,	88,142,	
89,143,	90,144,	91,145,	92,146,	
94,147,	95,148,	96,149,	97,150,	
98,151,	100,153,	101,154,	102,155,	
103,156,	104,157,	105,158,	107,161,	
106,159,	108,162,	109,163,	111,164,	
112,165,	113,166,	98,152,	106,160,	
114,167,	115,168,	116,169,	117,170,	
118,171,	119,173,	120,174,	121,175,	
122,176,	123,178,	124,179,	125,180,	
122,177,	126,181,	127,182,	128,183,	
129,184,	130,185,	131,186,	132,187,	
133,188,	135,189,	136,190,	137,191,	
118,172,	138,192,	139,193,	140,194,	
141,195,	142,196,	143,197,	144,198,	
144,199,	146,200,	147,201,	148,202,	
149,203,	150,205,	152,206,	149,204,	
153,207,	154,208,	156,209,	157,210,	
158,211,	159,212,	160,213,	161,214,	
162,215,	163,216,	164,217,	165,218,	
166,219,	167,220,	168,221,	169,222,	
170,223,	172,224,	173,225,	174,227,	
175,228,	176,229,	177,230,	181,231,	
182,232,	184,233,	185,234,	186,235,	
188,236,	189,237,	173,226,	190,238,	
191,239,	192,240,	193,241,	194,242,	
195,243,	196,244,	198,245,	199,246,	
200,247,	201,248,	202,249,	204,250,	
205,251,	206,252,	207,253,	208,254,	
209,255,	210,256,	211,258,	212,259,	
213,260,	215,261,	216,262,	210,257,	
217,263,	218,264,	219,265,	220,266,	
222,267,	223,268,	224,269,	226,270,	
228,271,	229,272,	230,273,	231,274,	
232,275,	233,276,	234,277,	235,278,	
238,279,	239,281,	240,282,	241,283,	
238,280,	242,284,	243,285,	244,286,	
245,287,	246,288,	247,289,	249,290,	
251,291,	252,292,	253,293,	254,294,	
255,295,	256,296,	257,297,	258,298,	
259,299,	260,300,	261,301,	263,302,	
264,303,	265,304,	266,305,	268,306,	
269,307,	271,308,	272,309,	273,310,	
275,311,	277,312,	278,313,	279,314,	
280,315,	281,316,	283,317,	284,318,	
285,319,	287,320,	288,321,	289,322,	
290,323,	291,324,	292,325,	293,326,	
294,327,	295,328,	296,329,	298,330,	
300,331,	301,332,	302,333,	303,334,	
306,335,	308,336,	309,337,	310,338,	
311,339,	312,340,	314,341,	315,342,	
316,343,	317,344,	318,345,	319,346,	
320,347,	321,348,	322,349,	323,350,	
324,351,	327,352,	328,353,	330,354,	
334,355,	335,356,	336,357,	337,358,	
339,359,	340,360,	341,361,	342,362,	
343,363,	345,364,	347,365,	348,366,	
349,367,	350,369,	354,370,	349,368,	
355,371,	356,372,	357,373,	358,374,	
359,375,	360,376,	362,377,	363,378,	
368,379,	369,380,	370,381,	371,382,	
372,383,	373,384,	374,385,	375,386,	
376,387,	377,388,	378,389,	380,390,	
383,391,	384,392,	386,393,	387,394,	
388,395,	389,396,	396,397,	0,0,	
0,0};
struct yysvf yysvec[] = {
0,	0,	0,
yycrank+1,	0,		yyvstop+1,
yycrank+0,	yysvec+1,	yyvstop+3,
yycrank+0,	0,		yyvstop+5,
yycrank+0,	0,		yyvstop+7,
yycrank+0,	0,		yyvstop+9,
yycrank+3,	0,		0,	
yycrank+0,	0,		yyvstop+11,
yycrank+0,	0,		yyvstop+13,
yycrank+0,	0,		yyvstop+15,
yycrank+0,	0,		yyvstop+17,
yycrank+0,	0,		yyvstop+19,
yycrank+0,	0,		yyvstop+21,
yycrank+0,	0,		yyvstop+23,
yycrank+79,	0,		yyvstop+25,
yycrank+17,	0,		yyvstop+28,
yycrank+91,	0,		yyvstop+30,
yycrank+0,	0,		yyvstop+32,
yycrank+103,	0,		yyvstop+34,
yycrank+0,	0,		yyvstop+36,
yycrank+128,	yysvec+18,	yyvstop+38,
yycrank+53,	yysvec+18,	yyvstop+40,
yycrank+128,	yysvec+18,	yyvstop+42,
yycrank+20,	yysvec+18,	yyvstop+44,
yycrank+54,	yysvec+18,	yyvstop+46,
yycrank+33,	yysvec+18,	yyvstop+48,
yycrank+62,	yysvec+18,	yyvstop+50,
yycrank+122,	yysvec+18,	yyvstop+52,
yycrank+68,	yysvec+18,	yyvstop+54,
yycrank+49,	yysvec+18,	yyvstop+56,
yycrank+130,	yysvec+18,	yyvstop+58,
yycrank+124,	yysvec+18,	yyvstop+60,
yycrank+145,	yysvec+18,	yyvstop+62,
yycrank+146,	yysvec+18,	yyvstop+64,
yycrank+154,	yysvec+18,	yyvstop+66,
yycrank+82,	yysvec+18,	yyvstop+68,
yycrank+130,	yysvec+18,	yyvstop+70,
yycrank+0,	0,		yyvstop+72,
yycrank+0,	0,		yyvstop+74,
yycrank+0,	0,		yyvstop+76,
yycrank+0,	yysvec+14,	yyvstop+78,
yycrank+0,	0,		yyvstop+80,
yycrank+80,	yysvec+18,	yyvstop+82,
yycrank+93,	yysvec+18,	yyvstop+84,
yycrank+99,	yysvec+18,	yyvstop+86,
yycrank+96,	yysvec+18,	yyvstop+88,
yycrank+155,	yysvec+18,	yyvstop+90,
yycrank+129,	yysvec+18,	yyvstop+92,
yycrank+114,	yysvec+18,	yyvstop+94,
yycrank+142,	yysvec+18,	yyvstop+96,
yycrank+166,	yysvec+18,	yyvstop+98,
yycrank+154,	yysvec+18,	yyvstop+100,
yycrank+152,	yysvec+18,	yyvstop+102,
yycrank+147,	yysvec+18,	yyvstop+104,
yycrank+156,	yysvec+18,	yyvstop+106,
yycrank+149,	yysvec+18,	yyvstop+108,
yycrank+168,	yysvec+18,	yyvstop+110,
yycrank+160,	yysvec+18,	yyvstop+112,
yycrank+169,	yysvec+18,	yyvstop+114,
yycrank+178,	yysvec+18,	yyvstop+116,
yycrank+166,	yysvec+18,	yyvstop+118,
yycrank+170,	yysvec+18,	yyvstop+120,
yycrank+178,	yysvec+18,	yyvstop+122,
yycrank+0,	yysvec+18,	yyvstop+124,
yycrank+181,	yysvec+18,	yyvstop+127,
yycrank+167,	yysvec+18,	yyvstop+129,
yycrank+173,	yysvec+18,	yyvstop+131,
yycrank+177,	yysvec+18,	yyvstop+133,
yycrank+187,	yysvec+18,	yyvstop+135,
yycrank+186,	yysvec+18,	yyvstop+137,
yycrank+192,	yysvec+18,	yyvstop+139,
yycrank+181,	yysvec+18,	yyvstop+141,
yycrank+191,	yysvec+18,	yyvstop+143,
yycrank+177,	yysvec+18,	yyvstop+145,
yycrank+197,	yysvec+18,	yyvstop+147,
yycrank+173,	yysvec+18,	yyvstop+149,
yycrank+192,	yysvec+18,	yyvstop+151,
yycrank+186,	yysvec+18,	yyvstop+153,
yycrank+179,	yysvec+18,	yyvstop+155,
yycrank+193,	yysvec+18,	yyvstop+157,
yycrank+188,	yysvec+18,	yyvstop+159,
yycrank+206,	yysvec+18,	yyvstop+161,
yycrank+203,	yysvec+18,	yyvstop+163,
yycrank+0,	yysvec+18,	yyvstop+165,
yycrank+191,	yysvec+18,	yyvstop+168,
yycrank+192,	yysvec+18,	yyvstop+170,
yycrank+196,	yysvec+18,	yyvstop+172,
yycrank+209,	yysvec+18,	yyvstop+174,
yycrank+206,	yysvec+18,	yyvstop+176,
yycrank+204,	yysvec+18,	yyvstop+178,
yycrank+206,	yysvec+18,	yyvstop+180,
yycrank+213,	yysvec+18,	yyvstop+182,
yycrank+205,	yysvec+18,	yyvstop+184,
yycrank+0,	yysvec+18,	yyvstop+186,
yycrank+200,	yysvec+18,	yyvstop+189,
yycrank+215,	yysvec+18,	yyvstop+191,
yycrank+207,	yysvec+18,	yyvstop+193,
yycrank+207,	yysvec+18,	yyvstop+195,
yycrank+219,	yysvec+18,	yyvstop+197,
yycrank+0,	yysvec+18,	yyvstop+199,
yycrank+216,	yysvec+18,	yyvstop+202,
yycrank+221,	yysvec+18,	yyvstop+204,
yycrank+216,	yysvec+18,	yyvstop+206,
yycrank+219,	yysvec+18,	yyvstop+208,
yycrank+228,	yysvec+18,	yyvstop+210,
yycrank+218,	yysvec+18,	yyvstop+212,
yycrank+226,	yysvec+18,	yyvstop+214,
yycrank+223,	yysvec+18,	yyvstop+216,
yycrank+232,	yysvec+18,	yyvstop+218,
yycrank+223,	yysvec+18,	yyvstop+220,
yycrank+0,	yysvec+18,	yyvstop+222,
yycrank+230,	yysvec+18,	yyvstop+225,
yycrank+228,	yysvec+18,	yyvstop+227,
yycrank+219,	yysvec+18,	yyvstop+229,
yycrank+234,	yysvec+18,	yyvstop+231,
yycrank+236,	yysvec+18,	yyvstop+234,
yycrank+226,	yysvec+18,	yyvstop+236,
yycrank+229,	yysvec+18,	yyvstop+238,
yycrank+239,	yysvec+18,	yyvstop+240,
yycrank+236,	yysvec+18,	yyvstop+242,
yycrank+239,	yysvec+18,	yyvstop+244,
yycrank+228,	yysvec+18,	yyvstop+246,
yycrank+236,	yysvec+18,	yyvstop+248,
yycrank+248,	yysvec+18,	yyvstop+250,
yycrank+243,	yysvec+18,	yyvstop+253,
yycrank+250,	yysvec+18,	yyvstop+255,
yycrank+252,	yysvec+18,	yyvstop+258,
yycrank+242,	yysvec+18,	yyvstop+260,
yycrank+250,	yysvec+18,	yyvstop+262,
yycrank+251,	yysvec+18,	yyvstop+264,
yycrank+252,	yysvec+18,	yyvstop+266,
yycrank+238,	yysvec+18,	yyvstop+268,
yycrank+254,	yysvec+18,	yyvstop+270,
yycrank+248,	yysvec+18,	yyvstop+272,
yycrank+0,	yysvec+18,	yyvstop+274,
yycrank+240,	yysvec+18,	yyvstop+277,
yycrank+248,	yysvec+18,	yyvstop+279,
yycrank+249,	yysvec+18,	yyvstop+281,
yycrank+245,	yysvec+18,	yyvstop+283,
yycrank+246,	yysvec+18,	yyvstop+285,
yycrank+249,	yysvec+18,	yyvstop+287,
yycrank+266,	yysvec+18,	yyvstop+289,
yycrank+264,	yysvec+18,	yyvstop+291,
yycrank+265,	yysvec+18,	yyvstop+293,
yycrank+265,	yysvec+18,	yyvstop+295,
yycrank+0,	yysvec+18,	yyvstop+297,
yycrank+269,	yysvec+18,	yyvstop+300,
yycrank+269,	yysvec+18,	yyvstop+302,
yycrank+269,	yysvec+18,	yyvstop+304,
yycrank+258,	yysvec+18,	yyvstop+306,
yycrank+262,	yysvec+18,	yyvstop+308,
yycrank+0,	yysvec+18,	yyvstop+310,
yycrank+258,	yysvec+18,	yyvstop+313,
yycrank+266,	yysvec+18,	yyvstop+315,
yycrank+278,	yysvec+18,	yyvstop+317,
yycrank+0,	yysvec+18,	yyvstop+319,
yycrank+266,	yysvec+18,	yyvstop+322,
yycrank+263,	yysvec+18,	yyvstop+324,
yycrank+280,	yysvec+18,	yyvstop+326,
yycrank+276,	yysvec+18,	yyvstop+328,
yycrank+281,	yysvec+18,	yyvstop+330,
yycrank+267,	yysvec+18,	yyvstop+332,
yycrank+268,	yysvec+18,	yyvstop+334,
yycrank+288,	yysvec+18,	yyvstop+336,
yycrank+272,	yysvec+18,	yyvstop+338,
yycrank+282,	yysvec+18,	yyvstop+340,
yycrank+291,	yysvec+18,	yyvstop+342,
yycrank+284,	yysvec+18,	yyvstop+344,
yycrank+276,	yysvec+18,	yyvstop+346,
yycrank+274,	yysvec+18,	yyvstop+348,
yycrank+289,	yysvec+18,	yyvstop+350,
yycrank+0,	yysvec+18,	yyvstop+352,
yycrank+290,	yysvec+18,	yyvstop+355,
yycrank+289,	yysvec+18,	yyvstop+357,
yycrank+294,	yysvec+18,	yyvstop+359,
yycrank+284,	yysvec+18,	yyvstop+361,
yycrank+296,	yysvec+18,	yyvstop+363,
yycrank+287,	yysvec+18,	yyvstop+365,
yycrank+0,	yysvec+18,	yyvstop+367,
yycrank+0,	yysvec+18,	yyvstop+370,
yycrank+0,	yysvec+18,	yyvstop+373,
yycrank+283,	yysvec+18,	yyvstop+376,
yycrank+299,	yysvec+18,	yyvstop+378,
yycrank+0,	yysvec+18,	yyvstop+380,
yycrank+287,	yysvec+18,	yyvstop+383,
yycrank+288,	yysvec+18,	yyvstop+385,
yycrank+286,	yysvec+18,	yyvstop+387,
yycrank+0,	yysvec+18,	yyvstop+389,
yycrank+303,	yysvec+18,	yyvstop+392,
yycrank+290,	yysvec+18,	yyvstop+394,
yycrank+292,	yysvec+18,	yyvstop+396,
yycrank+292,	yysvec+18,	yyvstop+398,
yycrank+308,	yysvec+18,	yyvstop+400,
yycrank+308,	yysvec+18,	yyvstop+402,
yycrank+299,	yysvec+18,	yyvstop+404,
yycrank+298,	yysvec+18,	yyvstop+406,
yycrank+303,	yysvec+18,	yyvstop+408,
yycrank+0,	yysvec+18,	yyvstop+410,
yycrank+317,	yysvec+18,	yyvstop+413,
yycrank+301,	yysvec+18,	yyvstop+415,
yycrank+317,	yysvec+18,	yyvstop+417,
yycrank+303,	yysvec+18,	yyvstop+419,
yycrank+313,	yysvec+18,	yyvstop+421,
yycrank+0,	yysvec+18,	yyvstop+423,
yycrank+305,	yysvec+18,	yyvstop+426,
yycrank+305,	yysvec+18,	yyvstop+428,
yycrank+324,	yysvec+18,	yyvstop+430,
yycrank+322,	yysvec+18,	yyvstop+432,
yycrank+307,	yysvec+18,	yyvstop+434,
yycrank+309,	yysvec+18,	yyvstop+436,
yycrank+320,	yysvec+18,	yyvstop+438,
yycrank+315,	yysvec+18,	yyvstop+440,
yycrank+319,	yysvec+18,	yyvstop+442,
yycrank+312,	yysvec+18,	yyvstop+444,
yycrank+0,	yysvec+18,	yyvstop+446,
yycrank+324,	yysvec+18,	yyvstop+449,
yycrank+314,	yysvec+18,	yyvstop+451,
yycrank+327,	yysvec+18,	yyvstop+453,
yycrank+317,	yysvec+18,	yyvstop+455,
yycrank+313,	yysvec+18,	yyvstop+457,
yycrank+327,	yysvec+18,	yyvstop+459,
yycrank+0,	yysvec+18,	yyvstop+461,
yycrank+320,	yysvec+18,	yyvstop+464,
yycrank+322,	yysvec+18,	yyvstop+466,
yycrank+327,	yysvec+18,	yyvstop+468,
yycrank+0,	yysvec+18,	yyvstop+470,
yycrank+324,	yysvec+18,	yyvstop+473,
yycrank+0,	yysvec+18,	yyvstop+475,
yycrank+339,	yysvec+18,	yyvstop+478,
yycrank+342,	yysvec+18,	yyvstop+480,
yycrank+337,	yysvec+18,	yyvstop+482,
yycrank+342,	yysvec+18,	yyvstop+484,
yycrank+342,	yysvec+18,	yyvstop+486,
yycrank+344,	yysvec+18,	yyvstop+489,
yycrank+333,	yysvec+18,	yyvstop+491,
yycrank+333,	yysvec+18,	yyvstop+493,
yycrank+0,	yysvec+18,	yyvstop+495,
yycrank+0,	yysvec+18,	yyvstop+498,
yycrank+340,	yysvec+18,	yyvstop+501,
yycrank+328,	yysvec+18,	yyvstop+503,
yycrank+330,	yysvec+18,	yyvstop+505,
yycrank+346,	yysvec+18,	yyvstop+507,
yycrank+337,	yysvec+18,	yyvstop+509,
yycrank+357,	yysvec+18,	yyvstop+511,
yycrank+339,	yysvec+18,	yyvstop+513,
yycrank+357,	yysvec+18,	yyvstop+515,
yycrank+346,	yysvec+18,	yyvstop+517,
yycrank+347,	yysvec+18,	yyvstop+519,
yycrank+0,	yysvec+18,	yyvstop+521,
yycrank+360,	yysvec+18,	yyvstop+524,
yycrank+0,	yysvec+18,	yyvstop+526,
yycrank+355,	yysvec+18,	yyvstop+529,
yycrank+351,	yysvec+18,	yyvstop+531,
yycrank+361,	yysvec+18,	yyvstop+533,
yycrank+358,	yysvec+18,	yyvstop+535,
yycrank+353,	yysvec+18,	yyvstop+537,
yycrank+354,	yysvec+18,	yyvstop+539,
yycrank+352,	yysvec+18,	yyvstop+541,
yycrank+365,	yysvec+18,	yyvstop+543,
yycrank+367,	yysvec+18,	yyvstop+545,
yycrank+355,	yysvec+18,	yyvstop+547,
yycrank+359,	yysvec+18,	yyvstop+549,
yycrank+0,	yysvec+18,	yyvstop+551,
yycrank+374,	yysvec+18,	yyvstop+554,
yycrank+364,	yysvec+18,	yyvstop+556,
yycrank+358,	yysvec+18,	yyvstop+558,
yycrank+373,	yysvec+18,	yyvstop+560,
yycrank+0,	yysvec+18,	yyvstop+562,
yycrank+371,	yysvec+18,	yyvstop+565,
yycrank+366,	yysvec+18,	yyvstop+567,
yycrank+0,	yysvec+18,	yyvstop+569,
yycrank+363,	yysvec+18,	yyvstop+572,
yycrank+362,	yysvec+18,	yyvstop+574,
yycrank+369,	yysvec+18,	yyvstop+576,
yycrank+0,	yysvec+18,	yyvstop+578,
yycrank+383,	yysvec+18,	yyvstop+581,
yycrank+0,	yysvec+18,	yyvstop+583,
yycrank+364,	yysvec+18,	yyvstop+586,
yycrank+381,	yysvec+18,	yyvstop+588,
yycrank+386,	yysvec+18,	yyvstop+590,
yycrank+387,	yysvec+18,	yyvstop+592,
yycrank+383,	yysvec+18,	yyvstop+594,
yycrank+0,	yysvec+18,	yyvstop+596,
yycrank+378,	yysvec+18,	yyvstop+599,
yycrank+382,	yysvec+18,	yyvstop+601,
yycrank+383,	yysvec+18,	yyvstop+603,
yycrank+0,	yysvec+18,	yyvstop+605,
yycrank+384,	yysvec+18,	yyvstop+608,
yycrank+373,	yysvec+18,	yyvstop+610,
yycrank+383,	yysvec+18,	yyvstop+612,
yycrank+387,	yysvec+18,	yyvstop+614,
yycrank+377,	yysvec+18,	yyvstop+616,
yycrank+378,	yysvec+18,	yyvstop+618,
yycrank+381,	yysvec+18,	yyvstop+620,
yycrank+385,	yysvec+18,	yyvstop+622,
yycrank+392,	yysvec+18,	yyvstop+624,
yycrank+388,	yysvec+18,	yyvstop+626,
yycrank+0,	yysvec+18,	yyvstop+628,
yycrank+381,	yysvec+18,	yyvstop+631,
yycrank+0,	yysvec+18,	yyvstop+633,
yycrank+379,	yysvec+18,	yyvstop+636,
yycrank+391,	yysvec+18,	yyvstop+638,
yycrank+394,	yysvec+18,	yyvstop+640,
yycrank+402,	yysvec+18,	yyvstop+642,
yycrank+0,	yysvec+18,	yyvstop+644,
yycrank+0,	yysvec+18,	yyvstop+647,
yycrank+407,	yysvec+18,	yyvstop+650,
yycrank+0,	yysvec+18,	yyvstop+652,
yycrank+393,	yysvec+18,	yyvstop+655,
yycrank+409,	yysvec+18,	yyvstop+657,
yycrank+391,	yysvec+18,	yyvstop+659,
yycrank+409,	yysvec+18,	yyvstop+661,
yycrank+412,	yysvec+18,	yyvstop+663,
yycrank+0,	yysvec+18,	yyvstop+665,
yycrank+394,	yysvec+18,	yyvstop+668,
yycrank+397,	yysvec+18,	yyvstop+670,
yycrank+407,	yysvec+18,	yyvstop+672,
yycrank+412,	yysvec+18,	yyvstop+674,
yycrank+403,	yysvec+18,	yyvstop+676,
yycrank+416,	yysvec+18,	yyvstop+678,
yycrank+406,	yysvec+18,	yyvstop+680,
yycrank+407,	yysvec+18,	yyvstop+682,
yycrank+407,	yysvec+18,	yyvstop+684,
yycrank+418,	yysvec+18,	yyvstop+686,
yycrank+419,	yysvec+18,	yyvstop+688,
yycrank+0,	yysvec+18,	yyvstop+690,
yycrank+0,	yysvec+18,	yyvstop+693,
yycrank+411,	yysvec+18,	yyvstop+696,
yycrank+422,	yysvec+18,	yyvstop+698,
yycrank+0,	yysvec+18,	yyvstop+700,
yycrank+418,	yysvec+18,	yyvstop+703,
yycrank+0,	yysvec+18,	yyvstop+705,
yycrank+0,	yysvec+18,	yyvstop+708,
yycrank+0,	yysvec+18,	yyvstop+711,
yycrank+406,	yysvec+18,	yyvstop+714,
yycrank+425,	yysvec+18,	yyvstop+716,
yycrank+421,	yysvec+18,	yyvstop+718,
yycrank+417,	yysvec+18,	yyvstop+720,
yycrank+0,	yysvec+18,	yyvstop+722,
yycrank+412,	yysvec+18,	yyvstop+725,
yycrank+429,	yysvec+18,	yyvstop+727,
yycrank+429,	yysvec+18,	yyvstop+729,
yycrank+430,	yysvec+18,	yyvstop+731,
yycrank+414,	yysvec+18,	yyvstop+733,
yycrank+0,	yysvec+18,	yyvstop+735,
yycrank+423,	yysvec+18,	yyvstop+738,
yycrank+0,	yysvec+18,	yyvstop+740,
yycrank+431,	yysvec+18,	yyvstop+743,
yycrank+435,	yysvec+18,	yyvstop+745,
yycrank+422,	yysvec+18,	yyvstop+747,
yycrank+427,	yysvec+18,	yyvstop+749,
yycrank+0,	yysvec+18,	yyvstop+751,
yycrank+0,	yysvec+18,	yyvstop+754,
yycrank+0,	yysvec+18,	yyvstop+757,
yycrank+437,	yysvec+18,	yyvstop+760,
yycrank+439,	yysvec+18,	yyvstop+762,
yycrank+436,	yysvec+18,	yyvstop+764,
yycrank+422,	yysvec+18,	yyvstop+766,
yycrank+444,	yysvec+18,	yyvstop+768,
yycrank+433,	yysvec+18,	yyvstop+770,
yycrank+431,	yysvec+18,	yyvstop+772,
yycrank+0,	yysvec+18,	yyvstop+774,
yycrank+436,	yysvec+18,	yyvstop+777,
yycrank+446,	yysvec+18,	yyvstop+779,
yycrank+0,	yysvec+18,	yyvstop+781,
yycrank+0,	yysvec+18,	yyvstop+784,
yycrank+0,	yysvec+18,	yyvstop+787,
yycrank+0,	yysvec+18,	yyvstop+790,
yycrank+434,	yysvec+18,	yyvstop+793,
yycrank+433,	yysvec+18,	yyvstop+795,
yycrank+431,	yysvec+18,	yyvstop+797,
yycrank+443,	yysvec+18,	yyvstop+799,
yycrank+442,	yysvec+18,	yyvstop+801,
yycrank+452,	yysvec+18,	yyvstop+803,
yycrank+453,	yysvec+18,	yyvstop+805,
yycrank+441,	yysvec+18,	yyvstop+807,
yycrank+451,	yysvec+18,	yyvstop+809,
yycrank+458,	yysvec+18,	yyvstop+811,
yycrank+460,	yysvec+18,	yyvstop+813,
yycrank+0,	yysvec+18,	yyvstop+815,
yycrank+444,	yysvec+18,	yyvstop+818,
yycrank+0,	yysvec+18,	yyvstop+820,
yycrank+0,	yysvec+18,	yyvstop+823,
yycrank+457,	yysvec+18,	yyvstop+826,
yycrank+453,	yysvec+18,	yyvstop+828,
yycrank+0,	yysvec+18,	yyvstop+830,
yycrank+447,	yysvec+18,	yyvstop+833,
yycrank+464,	yysvec+18,	yyvstop+835,
yycrank+443,	yysvec+18,	yyvstop+837,
yycrank+460,	yysvec+18,	yyvstop+839,
yycrank+0,	yysvec+18,	yyvstop+841,
yycrank+0,	yysvec+18,	yyvstop+844,
yycrank+0,	yysvec+18,	yyvstop+847,
yycrank+0,	yysvec+18,	yyvstop+850,
yycrank+0,	yysvec+18,	yyvstop+853,
yycrank+0,	yysvec+18,	yyvstop+856,
yycrank+450,	yysvec+18,	yyvstop+859,
yycrank+0,	yysvec+18,	yyvstop+861,
0,	0,	0};
struct yywork *yytop = yycrank+566;
struct yysvf *yybgin = yysvec+1;
char yymatch[] = {
00  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,011 ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
011 ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,'.' ,01  ,
'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,
'0' ,'0' ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,01  ,01  ,01  ,01  ,'A' ,
01  ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,01  ,01  ,01  ,01  ,01  ,
0};
char yyextra[] = {
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
#ifndef lint
static	char ncform_sccsid[] = "@(#)ncform 1.6 88/02/08 SMI"; /* from S5R2 1.2 */
#endif

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
yylook(){
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych, yyfirst;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	yyfirst=1;
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank && !yyfirst){  /* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
			*yylastch++ = yych = input();
			yyfirst=0;
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
yyback(p, m)
	int *p;
{
if (p==0) return(0);
while (*p)
	{
	if (*p++ == m)
		return(1);
	}
return(0);
}
	/* the following are only used in the lex library */
yyinput(){
	return(input());
	}
yyoutput(c)
  int c; {
	output(c);
	}
yyunput(c)
   int c; {
	unput(c);
	}
