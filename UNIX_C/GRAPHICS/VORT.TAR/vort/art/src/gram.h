
typedef union {
	object	*y_obj;
	light	*y_lht;
	vector	*y_pnt;
	details	*y_det;
	char	*y_str;
	eqn	*y_eqn;
	term	*y_trm;
	float	y_flt;
	int	y_int;
} YYSTYPE;
extern YYSTYPE yylval;
# define BOX 257
# define CSG 258
# define CONE 259
# define RING 260
# define TORUS 261
# define SPHERE 262
# define POLYGON 263
# define GEOMETRY 264
# define CYLINDER 265
# define ALGEBRAIC 266
# define COMPOSITE 267
# define ELLIPSOID 268
# define SUPERQUADRIC 269
# define FLOAT 270
# define INTEGER 271
# define FILETYPE 272
# define OPTION 273
# define STRING 274
# define NAME 275
# define LBRACE 276
# define RBRACE 277
# define LP 278
# define RP 279
# define RADIUS 280
# define RADII 281
# define COLOUR 282
# define CENTER 283
# define VERTEX 284
# define COMMA 285
# define PCENT 286
# define MATERIAL 287
# define REFI 288
# define MINUS 289
# define AMBIENT 290
# define LIGHT 291
# define INTENSITY 292
# define LOCATION 293
# define DOLS 294
# define EQUATION 295
# define TILE 296
# define OFFFILE 297
# define BASE 298
# define TOP 299
# define CONST 300
# define COEFFS 301
# define SCALE 302
# define ROTATE 303
# define TRANSLATE 304
# define TITLE 305
# define REFLECTANCE 306
# define DOT 307
# define ON 308
# define OFF 309
# define LOOKAT 310
# define FIELDOFVIEW 311
# define TRANSPARENCY 312
# define RAYSPERPIXEL 313
# define BACKGROUND 314
# define SIZE 315
# define MAXHITLEVEL 316
# define OUTPUT 317
# define ORDER 318
# define ABSORPTION 319
# define VREF1 320
# define VREF2 321
# define NUMRAYS 322
# define OBJECT 323
# define TEXTURE 324
# define DIRECTION 325
# define ANGLE 326
# define UP 327
# define TWENTYFIVEBIT 328
# define RANGE 329
# define MAP 330
# define BLENDCOLOR 331
# define SCALEFACTORS 332
# define VORTFILE 333
# define PLUS 334
# define MULT 335
# define DIV 336
# define COMBINE 337
# define POWER 338
# define UMINUS 339
# define EQUALS 340
