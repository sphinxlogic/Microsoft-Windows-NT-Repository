#include "vopl.h"

/*
 * degree_
 */
degree_(ord)
	int	*ord;
{
	degree(*ord);
}
