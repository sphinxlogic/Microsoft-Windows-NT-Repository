#include "vopl.h"

/*
 * savestr
 *
 *	Save a string of goddam characters somewhere
 */
char *
savestr(old, string)
	char	*old, *string;
{
	char	*p;

	if (string == (char *)NULL)
		return ((char *)NULL);

	p = old;

	if (p != (char *)NULL) {
		if (strlen(string) > strlen(p)) {
			free(p);
			p = (char *)malloc(strlen(string) + 1);
		}
	} else
		p = (char *)malloc(strlen(string) + 1);

	strcpy(p, string);

	return(p);
}
