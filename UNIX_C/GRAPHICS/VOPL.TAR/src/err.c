#include "vopl.h"
#include "vogle.h"

/*
 * vopl_error
 *
 *	Prints an error message.
 */
void
vopl_error(str)
	char	*str;
{
	if (vdevice.initialised)
		vexit();

	fprintf(stderr,"vopl: %s\n", str);
	exit(1);
}
