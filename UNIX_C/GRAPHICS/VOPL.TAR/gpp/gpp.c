/*
 *   gpp
 *  
 *   Graph plotting programme. 
 *
 */
#include "vogle.h"
#include "gpp.h"

/*
 * main driver
 */
main(argc, argv)
	int	argc;
	char	**argv;
{
	int	i;
	char	cm[2];
	graph	*p;

	doargs(argc, argv);

	vinit(device);

	viewport(-wholescale, wholescale, -wholescale, wholescale);

	color(BLACK);
	clear();

	mapcolor(WHITE, 150, 150, 150);
	color(WHITE);

	if (fontname[0])
		font(fontname);

	readgraphs();
	
	if (!uxscale || !uyscale /* || !uzscale */) 
		for (p = gp; p != (graph *)NULL; p = p->nxt) {
			if (!uxscale)
				adjustscale(p->x, p->npnts, 'x');

			if (!uyscale)
				adjustscale(p->y, p->npnts, 'y');

			/*if (!uzscale)
				adjustscale(p->z, p->npnts, 'z');*/
		}

	axistitle(xlabel, 'x');
	axistitle(ylabel, 'y');
	/*axistitle(zlabel, 'z');*/

	drawaxes2();
	drawtitle();

	i = 0;
	cm[1] = '\0';

	font("markers");

	for (p = gp; p != (graph *)NULL; p = p->nxt) {
		cm[0] = 'a' + (i++);
		marker(cm);
		color(i % 7);
		plot2(p->x, p->y, p->npnts);
	}

	if (do_legend)
		drawlegend();


	getkey();

	vexit();
}
