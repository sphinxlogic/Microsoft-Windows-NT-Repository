/***********************************************************************
 * $Author: markv $
 * $Revision: 1.1 $
 * $Date: 88/09/17 01:10:52 $
 * $Log:	antialiasing.c,v $
 * Revision 1.1  88/09/17  01:10:52  markv
 * Initial revision
 * 
 ***********************************************************************/

#include <stdio.h>
#include <math.h>
#include "defs.h"

/***********************************************************************
 *
 * Flt rnd() ;
 *
 * returns a (psuedo-)random number in the range 0-1.  This may
 * not be portable, for now it assumes that random() returns an
 * int in the range 0-(2^31-1).  Caveat Emptor!
 ***********************************************************************/

#define MAXRAND		(2147483647.0)

Flt
rnd ()
{
	return (((Flt) random ()) / ((Flt) MAXRAND));
}
