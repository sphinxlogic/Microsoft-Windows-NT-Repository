/***********************************************************************
 * $Log:	pic.h,v $
 * Revision 1.1  88/09/11  11:00:50  markv
 * Initial revision
 * 
 * Revision 1.1  88/09/09  11:59:56  markv
 * Initial revision
 * 
 ***********************************************************************/
typedef struct Pic {
	char	* filename ;
	FILE	* filep ;
	int	x, y ;
} Pic ;
