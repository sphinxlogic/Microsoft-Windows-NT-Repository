
/**************************************************************************
   Touchup a bitmap graphics editor for the Sun Workstation running SunView
   Copyright (c) 1988 by Raymond Kreisel
   1/22/88 @ Suny Stony Brook

   This program may be redistributed without fee as long as this copyright
   notice is intact.

==> PLEASE send comments and bug reports to one of the following addresses:

	   Ray Kreisel
	   CS Dept., SUNY at Stony Brook, Stony Brook NY 11794

	   UUCP: {allegra, philabs, pyramid, research}!sbcs!rayk   
	   ARPA-Internet: rayk@sbcs.sunysb.edu			
	   CSnet: rayk@suny-sb
	   (If nobody is home at any of the above addresses try:
		S72QKRE@TOWSONVX.BITNET			        )

 "If I get home before daylight, I just might get some sleep tonight...."

**************************************************************************/
/**************************************************************************
	file: fonts
	purpose: the get most of the good system fixed width fonts
		from the sys dirs and set them up in memory

	modifications:
		date:	Tue Mar 22 22:04:58 EST 1988
		author:	rayk
		changes:add comments
**************************************************************************/

#include <pixrect/pixrect_hs.h>



#define cour_b_10F  "/usr/lib/fonts/fixedwidthfonts/cour.b.10"
#define cour_b_12F  "/usr/lib/fonts/fixedwidthfonts/cour.b.12"
#define cour_b_16F  "/usr/lib/fonts/fixedwidthfonts/cour.b.16"
#define cour_b_24F  "/usr/lib/fonts/fixedwidthfonts/cour.b.24"

#define cour_r_10F  "/usr/lib/fonts/fixedwidthfonts/cour.r.10"
#define cour_r_12F  "/usr/lib/fonts/fixedwidthfonts/cour.r.12"
#define cour_r_16F  "/usr/lib/fonts/fixedwidthfonts/cour.r.16"
#define cour_r_24F  "/usr/lib/fonts/fixedwidthfonts/cour.r.24"

#define screen_r_7F   "/usr/lib/fonts/fixedwidthfonts/screen.r.7"
#define screen_r_11F  "/usr/lib/fonts/fixedwidthfonts/screen.r.11"
#define screen_r_12F  "/usr/lib/fonts/fixedwidthfonts/screen.r.12"
#define screen_r_14F  "/usr/lib/fonts/fixedwidthfonts/screen.r.14"
#define screen_b_12F  "/usr/lib/fonts/fixedwidthfonts/screen.b.12"
#define screen_b_14F  "/usr/lib/fonts/fixedwidthfonts/screen.b.14"

#define pcfont_b_14F  "/usr/lib/fonts/fixedwidthfonts/pcfont.b.14"
#define pcfont_r_14F  "/usr/lib/fonts/fixedwidthfonts/pcfont.r.14"

#define serif_r_10F  "/usr/lib/fonts/fixedwidthfonts/serif.r.10"
#define serif_r_11F  "/usr/lib/fonts/fixedwidthfonts/serif.r.11"
#define serif_r_16F  "/usr/lib/fonts/fixedwidthfonts/serif.r.16"

struct  pixfont  *screen_r_7;
struct  pixfont  *screen_r_11;
struct  pixfont  *screen_r_12;
struct  pixfont  *screen_r_14;
struct  pixfont  *screen_b_12;
struct  pixfont  *screen_b_14;

struct  pixfont  *pcfont_b_14;
struct  pixfont  *pcfont_r_14;

struct  pixfont  *cour_b_10;
struct  pixfont  *cour_b_12;
struct  pixfont  *cour_b_16;
struct  pixfont  *cour_b_24;

struct  pixfont  *cour_r_10;
struct  pixfont  *cour_r_12;
struct  pixfont  *cour_r_14;
struct  pixfont  *cour_r_16;
struct  pixfont  *cour_r_18;
struct  pixfont  *cour_r_24;

struct  pixfont  *serif_r_10;
struct  pixfont  *serif_r_11;
struct  pixfont  *serif_r_16;


#define FONT_NO 19


struct  pixfont  *font_array[FONT_NO];

init_font()
{

   screen_r_7  = pf_open(screen_r_7F);
   screen_r_11 = pf_open(screen_r_11F);
   screen_r_12 = pf_open(screen_r_12F);
   screen_r_14 = pf_open(screen_r_14F);
   screen_b_12 = pf_open(screen_b_12F);
   screen_b_14 = pf_open(screen_b_14F);

   pcfont_b_14 = pf_open(pcfont_b_14F);
   pcfont_r_14 = pf_open(pcfont_r_14F);

   cour_b_10 = pf_open(cour_b_10F); 
   cour_b_12 = pf_open(cour_b_12F);
   cour_b_16 = pf_open(cour_b_16F);
   cour_b_24 = pf_open(cour_b_24F); 

   cour_r_10 = pf_open(cour_r_10F);
   cour_r_12 = pf_open(cour_r_12F);
   cour_r_16 = pf_open(cour_r_16F);
   cour_r_24 = pf_open(cour_r_24F);

   serif_r_10 = pf_open(serif_r_10F);           
   serif_r_11 = pf_open(serif_r_11F);          
   serif_r_16 = pf_open(serif_r_16F);

  font_array[0] = cour_r_10;
  font_array[1] = cour_r_12;
  font_array[2] = cour_r_16;
  font_array[3] = cour_r_24;

  font_array[4] = cour_b_10;
  font_array[5] = cour_b_12;
  font_array[6] = cour_b_16;
  font_array[7] = cour_b_24;

  font_array[8] = serif_r_10;
  font_array[9] = serif_r_11;
  font_array[10] = serif_r_16;

  font_array[11] = screen_r_7;
  font_array[12] = screen_r_11;
  font_array[13] = screen_r_12;
  font_array[14] = screen_r_14;
  font_array[15] = screen_b_12;
  font_array[16] = screen_b_14;

  font_array[17] = pcfont_b_14;
  font_array[18] = pcfont_r_14;
}

