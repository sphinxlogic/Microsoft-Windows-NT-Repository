
/**************************************************************************
   Touchup a bitmap graphics editor for the Sun Workstation running SunView
   Copyright (c) 1988 by Raymond Kreisel
   1/22/88 @ Suny Stony Brook

   This program may be redistributed without fee as long as this copyright
   notice is intact.

==> PLEASE send comments and bug reports to one of the following addresses:

	   Ray Kreisel
	   CS Dept., SUNY at Stony Brook, Stony Brook NY 11794

	   UUCP: {allegra, philabs, pyramid, research}!sbcs!rayk   
	   ARPA-Internet: rayk@sbcs.sunysb.edu			
	   CSnet: rayk@suny-sb
	   (If nobody is home at any of the above addresses try:
		S72QKRE@TOWSONVX.BITNET			        )

 "If I get home before daylight, I just might get some sleep tonight...."

**************************************************************************/
/**************************************************************************
	file:  cms_rainbow.c
	purpose: this file contains that funciton that initalizes the
		the default color table for color sun usage

	modifications:
		date:	Tue Mar 22 22:04:58 EST 1988
		author:	rayk
		changes:add comments
**************************************************************************/

extern unsigned char red[256],green[256],blue[256];

set_colorentry(i, r, g, b)
{
  red[i] =r;
  green[i] =g;
  blue[i]=b;
}



void init_colortable()

{
    int i, red, green, blue;
    set_colorentry(0, 255, 255, 255);	/* white */
    set_colorentry(1, 0, 0, 0);		/* black */
    red = blue = green = 0;

    for (i = 2; i < 30; i++) {
	red += 9;
	set_colorentry(i, red, green, blue);
    }
    set_colorentry(30, 255, 0, 0);	/* red */
    red = 255; blue = green = 0;
    for (i = 30; i < 62; i++) {
	green += 6;
	set_colorentry(i, red, green, blue);
    }
    set_colorentry(62, 255, 195, 0);	/* orange */ /* note diff = 33 */
    red = 255; blue = 0; green = 195;
    for (i = 63; i < 96; i++) {
	green += 2;
	set_colorentry(i, red, green, blue);
    }
    set_colorentry(96, 255, 255, 0);	/* yellow */
    red = 255; blue = 0; green = 255;
    for (i = 97; i < 133; i++) {
	red -= 7;
	set_colorentry(i, red, green, blue);
    }
    set_colorentry(133, 0, 255, 0);	/* green */
    red = blue = 0; green = 255;
    for (i = 134; i < 165; i++) {
	green -= 8;
	blue += 8;
	set_colorentry(i, red, green, blue);
    }
    set_colorentry(165, 0, 0, 255);	/* blue */
    red = green = 0; blue = 255;
    for (i = 165; i < 202; i++) {
	red += 7;
	set_colorentry(i, red, green, blue);
    }
    set_colorentry(202, 255, 0, 255);	/* violet */
    red = blue = 255; green = 0;
    for (i = 203; i < 239; i++) {
	green += 7;
	set_colorentry(i, red, green, blue);
    }
    set_colorentry(239, 255, 255, 255);	/* white */
    red = blue = green = 255;
    for (i = 239; i <= 255; i++) {
	green -= 9;
	red -= 9;
	blue -= 9;
	set_colorentry(i, red, green, blue);
    }
}

