#include <stdio.h>
#include "rast.h"

main(argc,argv)
int argc;
char *argv[];
{
	RASTER *irast, *Ropen();
	int i, rc;

	for (i = 1; i < argc; i++) {
		irast = Ropen(argv[i],R);
		if (irast == NULL)
			fprintf(stderr,"rasterfile open failed for \"%s\"!\n",argv[i]);
		else {
			rc = Rgetheader(irast);
			fprintf(stderr,"%s:\n",argv[i]);
			if (rc) Rinfo(irast);
			else fprintf(stderr,"not a rasterfile!\n");
			fprintf(stderr,"\n");
			Rclose(irast);
		}
	}
	exit(0);
}
