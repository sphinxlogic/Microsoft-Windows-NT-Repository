extern double suzie[300][300],sam;
extern struct ball *bl[];
extern struct sphere ls;
extern int level,nob;
extern int xsue,ysue;
