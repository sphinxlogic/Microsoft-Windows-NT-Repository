#include <stdio.h>
#include <tam.h>
#include <fcntl.h>
  
extern errno;

main(argc, argv)
int argc;
char *argv[];

{
  char *malloc();
  char *cd,*d;
  short *bm,*c;
  int fd, cont;
 register int a,b;

	cont = 60; 
/*	if((argc == 2) && (atoi(argv[1]) >1) && (atoi(argv[1]) <100))
		cont = atoi(argv[1]);*/
 
    if ((fd=open(argv[1],O_RDONLY|O_NDELAY))==0) {
      fprintf("couldn't open %s for read\n", argv[1]);
      exit(-1);
    }
    if(lseek(fd,8,0)<0)
      exit(-1);
    cd=malloc(134400);
    if(read(fd,cd,134400)!=134400)
      exit(-1);
    bm=malloc(14974);
    c=bm+7487;
    for(a=287;a>=0;a--) {
      d=a*420+cd;
      for(b=415;b>=0;b--) {
        if(!(b&15))
          c-=1;
        *c=(*c<<1)|(*(d+b)>60);
      }
    }
    cd=bm;
    a = 0;
    while(a++ != 14974)
	    fprintf(stdout, "%c", *cd++);
}
