#include <stdio.h>

main(argc,argv)
int argc;
char **argv;
{
	int fd1, fd2, i, xaxis[6];
	double yaxis[50];

	fd1 = creat("xaxis", 0600);
	fd2 = creat("yaxis", 0600);

	for(i = 0; i < 6; i++){
		xaxis[i] = 30 * i;
	}
	for(i = 0; i < 50; i++){
		yaxis[i] = i / 100.0;
	}

	write(fd1, xaxis, 6 * sizeof (int));
	write(fd2, yaxis, 50 * sizeof (double));
}
