/*
	plots_ - F77 interface to 'plot'

	The CRC graphics package

	Carl Crawford
	Purdue University
	W. Lafayette, IN. 47907

	September 1981: <crc> added 'str' to call
*/

#include	"crc.h"

plots_(dev,blank,str)
long int	*dev;
long int	*blank;
char	*str;
{
	plots((int)*dev,(int)*blank,str);
}
