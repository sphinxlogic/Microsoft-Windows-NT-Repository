/*
	newpen_ - F77 interface to 'newpen'

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

#include	"crc.h"

newpen_(n)
long	int	*n;
{
	newpen((int)*n);
}
