/*
	sline - draw lines with on center symbols

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

#include	"crc.h"

sline(x,y,n,lx,ly,j,sym)
float *x,*y,lx,ly;
int n,j,sym;
{
	float xn,yn,yn1,xn1;
	register	int i;
	int code;
	char t[2];

	xn = x[n];	
	xn1 = x[n+1];
	yn = y[n];	
	yn1 = y[n+1];
	_schk(xn,xn1);
	_schk(yn,yn1);
	xn1 = lx / (xn1 - xn);
	yn1 = ly / (yn1 - yn);

	if(j == 0)j = 1;
	code=2;
	if(j < 0){
		code=3;
		j= -j;
	}
	t[0]= 0;
	t[1]= 0;
	if(sym <= 0 )t[0]= ' ';
	else    if(sym < 11)t[0]=t[0]+sym+175;
	else    if(sym <14)t[0]=t[0]+sym+159;
	else t[0]= ' ';
	if(sym == 0)j=4096;
	plot((x[0]-xn)*xn1,(y[0]-yn)*yn1,3);
	symbol((x[0]-xn)*xn1,(y[0]-yn)*yn1,.65*HEIGHT,t,0.);
	plot((x[0]-xn)*xn1,(y[0]-yn)*yn1,3);
	for(i=1;i<n;i++){
		plot((x[i]-xn)*xn1,(y[i]-yn)*yn1,code);
		if(i%j == 0){
			symbol((x[i]-xn)*xn1,(y[i]-yn)*yn1,.65*HEIGHT,t,0.);
			plot((x[i]-xn)*xn1,(y[i]-yn)*yn1,3);
		}
	}
}
