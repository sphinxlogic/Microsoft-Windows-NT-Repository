/*
	_clean - clean up after interrupts

	The CRC graphics package

	Carl Crawford
	Purdue University
	W. Lafayette, IN 47907

	Spetember 1981
*/

#include "crc.h"

_clean()
{
	if(DEV > MBIT)_plotend();
	exit(1);
}
