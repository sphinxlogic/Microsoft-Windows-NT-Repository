/*
	fname - change file name when DEV=0

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47907

	October 1981
*/

#include	"crc.h"

fname(s)
char *s;
{
	extern	char	*malloc();

	STORE = malloc(strlen(s)+1);
	strcpy(STORE,s);
}
