#include	"crc.h"
/*
	axis - interface to 'draxis'

	The CRC graphics package

*/

axis(x,y,label,xy,size,xmin,xmax,idata)
float	x,y,size,xmin,xmax;
int	xy,idata;
char	*label;
{
	float angle;
	int xydum;
	angle = 0.0;
	xydum = 1;
	switch(xy){
		case 0:
			break;
		case 1:
			angle = 90.0;
			xydum = -1;
			break;
		case 2:
			xydum = -1;
			break;
		case 3:
			angle = 90.0;
			break;
	}	
	draxis(x,y,label,angle,xydum,size,xmin,xmax,idata);
}
