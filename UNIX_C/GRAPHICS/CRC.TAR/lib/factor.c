/*
	factor - change scale factor

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

#include	"crc.h"

factor(sf)
float	sf;
{
	_fac = sf;
}
