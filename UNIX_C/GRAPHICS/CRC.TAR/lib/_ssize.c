/*
	_ssize - calculate the length of a string

	The CRC graphics package

	Carl Crawford
	Purdue University
	W. Lafayette, IN 47907

	September 1981
*/

#include	"crc.h"

int _ssize(label)
char label[];
{
	float ns;
	int nns,i;
	ns= .5;
	for(i=0;label[i] != '\0';i++){
		if(label[i] == '$'){
			i++;
			switch (label[i]){
			case '~': /* infinity */
				ns=ns+1.33;
				break;
			case ':': /* super score */
			case ';': /* under score */
			case '[': /* open subscript */
			case ']': /* close subscript */
			case '{': /* open superscript */
			case '}': /* close superscript */
				break;
			case '_': /* back space */
				ns=ns-1.0;
				break;
			case ' ':
				ns=ns+0.5;
				break;
			default:
				ns=ns+1.0;
				break;
			}
		}
		else ns=ns+1.0;
	}
	nns=(int)ns;
	return(nns);
}
