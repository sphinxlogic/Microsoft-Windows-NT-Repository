#include	"crc.h"

/*
	_err - clean up after error

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

_err(s1,s2)
char	*s1,*s2;
{
	if(DEV > MBIT)_plotend();

	fputs(s1,stderr);
	fputs(s2,stderr);
	fputc('\n',stderr);
	exit(1);
}
