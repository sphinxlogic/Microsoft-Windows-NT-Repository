/*
	sline_ - F77 interface to 'sline'

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

#include	"crc.h"

sline_(x,y,n,lx,ly,j,sym)
float *x,*y,*lx,*ly;
long int *n,*j,*sym;
{
	sline(x,y,(int)*n,*lx,*ly,(int)*j,(int)*sym);
}
