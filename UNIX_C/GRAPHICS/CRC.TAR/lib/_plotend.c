/*
	_plotend - clean up HP and Tektronix

	The CRC graphics package

	Carl Crawford
	Purdue University
	W. Lafayette, IN 47907

	September 1981
*/

#include "crc.h"

_plotend()
{
	if(DEV == HP){
		newpen(0);
		plotp(3);
		pclose(_pipe_fd);
	}
	if(DEV == TEK){
		alpha();
		fclose(_pipe_fd);
		stty(0,_intty);
	}
	if(DEV == HP || DEV == TEK){
		signal(SIGHUP,_hsig);
		signal(SIGINT,_isig);
		signal(SIGQUIT,_qsig);
	}
	if(DEV == PLOT ){
		if(PLOTFILT ){
			pclose(_pipe_fd);
		}else {
			fclose(_pipe_fd );
		}
	}
}
