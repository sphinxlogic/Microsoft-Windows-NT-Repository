/*
	laxis_ - F77 interface to 'laxis'

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

#include	"crc.h"

laxis_(x,y,label,xy,size,logmin,logmax,flag,labell)
float	*x;
float	*y;
char	*label;
long	int	*xy;
float	*size;
long	int	*logmin;
long	int	*logmax;
long	int	*flag;
long	int	labell;
{
	laxis(*x,*y,label,(int)*xy,*size,(int)*logmin,(int)*logmax,(int)*flag);
}
