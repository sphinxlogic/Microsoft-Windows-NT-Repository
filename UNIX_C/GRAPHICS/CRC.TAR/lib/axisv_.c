#include	"crc.h"

/*
	axisv_ - f77 callable version of 'axisv'

	The CRC graphics package

	carl crawford
	purdue university
	west lafayette, indiana 47907

	april 1980
*/

axisv_(ticdis,digits)
float	*ticdis;
long	int	*digits;
{
	axisv(*ticdis,(int) *digits);
}
