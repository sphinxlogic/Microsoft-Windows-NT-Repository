#include	"crc.h"
/*
	site_ - interface to site from F77

	The CRC graphics package

	Carl Crawford
	Purdue University
	W. Lafayette, IN 47907

	Jan. 6, 1981
*/

site_(s)
char	*s;
{
	site(s);
}
