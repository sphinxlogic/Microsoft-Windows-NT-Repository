/*
	number - provide formatted numeric labelling

	The CRC graphics package

	Carl Crawford
	Purdue University
	W. Lafayette, IN 47907

	September 1981
*/

#include	"crc.h"

number(x,y,height,angle,fmt,args)
float x,y,height,angle;
int args;
char *fmt;

{
	struct _iobuf _strbuf;

	_strbuf._flag = _IOWRT+_IOSTRG;
	_strbuf._ptr = _abuf;
	_strbuf._cnt = 32767;
	_doprnt(fmt, &args, &_strbuf);
	putc('\0', &_strbuf);
	symbol(x,y,height,_abuf,angle);
}
