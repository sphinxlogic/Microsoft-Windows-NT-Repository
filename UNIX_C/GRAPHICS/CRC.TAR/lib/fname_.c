/*
	fname_ - F77 interface to 'fname'

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

#include	"crc.h"

fname_(s)
char	*s;
{
	fname(s);
}
