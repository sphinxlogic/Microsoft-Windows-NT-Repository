#include "crc.h"

/*
	alpha - put tektronix in alpha numermic mode

	The CRC graphics package

	Carl Crawford
	Purdue University
	W. Lafayette, IN 47907

	April 15, 1981
*/

alpha()
{
	if(DEV == TEK){
		_CM &= 0177774;
		plotp(US);
		if(DEVN)plotp(CAN);
		fflush(_pipe_fd);
	}
	if(DEV == HP){
		if((_CM & 1)== 0)return;
		plotp('}');
		plotp('~');
		plotp('\'');
		_CM &= 0177774;
	}
}
