/*
	where - return plot status

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

#include	"crc.h"

where(x,y,sf)
float	*x,*y,*sf;
{
	*x = _axp - _xo;
	*y = _ayp - _yo;
	*sf = _fac;
}
