/*
	scale - find minimum and maximum of vector

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

#include	"crc.h"

scale(a,n)
float *a;
int n;
{
	float ai,fmax,fmin;
	register	int i;

	fmax = fmin = *a;
	for(i=0;i<n;i++){
		ai=a[i];
		if(ai > fmax) fmax = ai;
		if(ai < fmin) fmin = ai;
	}
	a[n] = fmin;
	a[n+1] = fmax;
}
