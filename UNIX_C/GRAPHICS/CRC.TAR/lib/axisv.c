#include	"crc.h"

/*
	axisv - set variables for 'axis' subroutine

	The CRC graphics package

	carl crawford
	purdue university
	west lafayette, indiana 47907

	april 1980
*/

axisv(ticdis,digits)
float	ticdis;
int	digits;
{
	TICDIS = ticdis;
	DIGITS = digits;
}
