/*
	axis_ - F77 interface to 'axis'

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

#include	"crc.h"

axis_(x,y,label,xy,size,min,max,flag,labell)
float	*x;
float	*y;
char	*label;
long int	*xy;
float	*size;
float	*min;
float	*max;
long	int	*flag;
long	int	labell;
{
	axis(*x,*y,label,(int)*xy,*size,*min,*max,(int)*flag);
}
