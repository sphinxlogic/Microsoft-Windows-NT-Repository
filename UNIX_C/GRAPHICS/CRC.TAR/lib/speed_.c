#include	"crc.h"

/*
	speed_ - f77 interface to 'speed'

	The CRC graphics package

	Carl Crawford
	Purdue University
	W. Lafayette, IN 47907

	March 11, 1981
*/

speed_(vel)
long	int	*vel;
{
	speed((int)*vel);
}
