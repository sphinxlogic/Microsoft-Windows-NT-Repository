/*
	speed - change speed of HP plotter 

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

#include "crc.h"

speed(vel)
int vel;
{
	if(DEV == HP){
		plotp('~');
		plotp('V');
		plotp(vel<32 ? 0100+vel : vel);
	}
}
