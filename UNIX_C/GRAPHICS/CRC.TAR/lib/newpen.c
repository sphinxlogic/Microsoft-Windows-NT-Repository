/*
	newpen - change pens on HP plotter

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

#include	"crc.h"

newpen(n)
int	n;
{
	_ud = 1;
	switch(DEV) {
	    case HP:
		if((_CM & 1) == 0){
			plotp(ETX);
			_CM &= 0177774;
			_CM += 1;
		}
		if((n < 0)||(n > 4))return;
		if(_CM & 2){
			plotp('}');
			_CM &= 0177774;	
			_CM += 1;
		}
		plotp('v');
		plotp(0100 + n);
	    break;
	case TEK:
		if(DEVN == 2) {		/* Tek 4113 only	*/
		    plotp(ESC);
		    plotp('M');		/* Set line index	*/
		    plotp('L');
		    tint(n);
		    plotp(ESC);
		    plotp('M');		/* Set text index	*/
		    plotp('T');
		    tint(n);
		    }
	}
}
