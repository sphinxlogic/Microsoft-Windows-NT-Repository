/*
	where_ - F77 interface to 'where'

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

#include	"crc.h"

where_(x,y,sf)
float	*x;
float	*y;
float	*sf;
{
	where(x,y,sf);
}
