/*
	factor_ - F77 interface to 'factor'

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

#include	"crc.h"

factor_(sf)
float	*sf;
{
	factor(*sf);
}
