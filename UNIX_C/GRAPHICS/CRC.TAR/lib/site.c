#include	"crc.h"

/*
	site - change default site for gplp linkage

	The CRC graphics package

	carl crawford
	purdue university
	w. lafayette. in 47907

	jan. 5, 1981
*/

site(s)
char *s;
{
	SITE = s;
}
