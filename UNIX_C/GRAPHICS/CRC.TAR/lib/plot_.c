/*
	plot_ - F77 interface to 'plot'

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

#include	"crc.h"

plot_(x,y,i)
float	*x;
float	*y;
long int	*i;
{
	plot(*x,*y,(int)*i);
}
