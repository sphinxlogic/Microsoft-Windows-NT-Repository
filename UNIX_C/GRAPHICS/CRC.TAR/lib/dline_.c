/*
	dline_ - F77 interface to 'dline'

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

#include	"crc.h"

dline_(x,y,n,dsh,gap,m,lx,ly)
float	*x;
float	*y;
long	int	*n;
float	*dsh;
float	*gap;
long	int	*m;
float	*lx;
float	*ly;
{
	dline(x,y,(int)*n,dsh,gap,(int)*m,*lx,*ly);
}
