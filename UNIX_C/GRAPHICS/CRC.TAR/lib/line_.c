/*
	line_ F77 interface to 'line'

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

#include	"crc.h"

line_(x,y,n,bar,lx,ly)
float	*x;
float	*y;
long	int	*n;
long	int	*bar;
float	*lx;
float	*ly;
{
	line(x,y,(int)*n,(int)*bar,*lx,*ly);
}
