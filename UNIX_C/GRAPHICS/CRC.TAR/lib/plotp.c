/*
	plotp - send char to the TEK or the HP

	The CRC graphics package

	Carl Crawford
	Purdue University
	W. Lafayette, IN

	September 1981
*/

#include	"crc.h"

plotp(data)
char data;	
{
	fputc(data,_pipe_fd);
}
