#include	"crc.h"

/*
	alpha_ - f77 callable alpha

	The CRC graphics package

	carl crawford
	purdue university
	july 1980
*/


alpha_()
{
	alpha();
}
