/*
	line - draw lines

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

#include	"crc.h"

line(x,y,n,bar,lx,ly)
float *x,*y,lx,ly;
int n,bar;
{
	float xn,yn,yn1,xn1;
	register	int i;

	xn = x[n];	
	xn1 = x[n+1];
	yn = y[n];	
	yn1 = y[n+1];
	_schk(xn,xn1);
	_schk(yn,yn1);
	xn1 = lx / (xn1 - xn);
	yn1 = ly / (yn1 - yn);
	plot((x[0]-xn)*xn1,(y[0]-yn)*yn1,3);
	for(i=1;i<n;i++){
		if(bar)plot((x[i]-xn)*xn1,(y[i-1]-yn)*yn1,2);
		plot((x[i]-xn)*xn1,(y[i]-yn)*yn1,2);
	}
	if(bar){
		plot((x[n-1]+x[n-1]-x[n-2]-xn)*xn1,(y[n-1]-yn)*yn1,2);
	}
}
