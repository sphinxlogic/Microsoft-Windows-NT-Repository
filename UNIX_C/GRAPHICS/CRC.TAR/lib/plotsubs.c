#include <stdio.h>
#include "crc.h"

p_cont(xi,yi){
	putc('n',_pipe_fd);
	p_putsi(xi);
	p_putsi(yi);
}
p_erase(){
	putc('e',_pipe_fd);
}
p_move(xi,yi){
	putc('m',_pipe_fd);
	p_putsi(xi);
	p_putsi(yi);
}

p_putsi(a){
	putc((char)a,_pipe_fd);
	putc((char)(a>>8),_pipe_fd);
}

p_space(x0,y0,x1,y1){
	putc('s',_pipe_fd);
	p_putsi(x0);
	p_putsi(y0);
	p_putsi(x1);
	p_putsi(y1);
}
