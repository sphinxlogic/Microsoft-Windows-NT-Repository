/*
	symbol_ - F77 interface to 'symbol'

	The CRC graphics package

	Carl Crawford 
	Purdue University
	West Lafayette, IN 47901

	October 1981
*/

#include	"crc.h"

symbol_(x,y,height,string,angle,stringl)
float	*x;
float	*y;
float	*height;
char	*string;
float	*angle;
long	int	stringl;
{
	symbol(*x,*y,*height,string,*angle);
}
