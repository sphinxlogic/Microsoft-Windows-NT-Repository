/*
	draxis_ - F77 interface to 'draxis'

	The CRC graphics package

*/

#include	"crc.h"

draxis_(x,y,label,angle,xy,size,min,max,flag)
float	*x;
float	*y;
float	*angle;
char	*label;
long int	*xy;
float	*size;
float	*min;
float	*max;
long	int	*flag;
{
	draxis(*x,*y,label,*angle,(int)*xy,*size,*min,*max,(int)*flag);
}
