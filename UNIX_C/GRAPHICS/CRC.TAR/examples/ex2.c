/*
 *	C Example 2 - Compute and plot a sinc(x)*sinc(y) function.
 *
 *	Compile with 
 *		cc ex2.c -lm -o ex2
 *	
 *	Run with
 *		ex2 > data
 */

#include	<stdio.h>
#include	<math.h>
#define	N	64

main(){
	int	i, j;
	double	x, y, z, sinc();

	for (i=0;i<N;i++){			/* For each x */
		x = i - N/2;
		for (j=0;j<N;j++){		/* and for each y */
			y = j - N/2;
			z = sinc(x)*sinc(y);
			printf("%f\n",z);	/* Write out the value */
		}
	}

}

double sinc(x)					/* Compute the sinc(x) */
double	x;
{
	if (fabs(x) < .0001)
		return(1.0);
	else
		return(sin(x)/x);
}
