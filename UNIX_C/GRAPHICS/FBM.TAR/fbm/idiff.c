/*****************************************************************
 * idiff.c: FBM Library 0.9 (Beta test) 07-Mar-89  Michael Mauldin
 *
 * Copyright (C) 1989 by Michael Mauldin.  Permission is granted to
 * use this file in whole or in part provided that you do not sell it
 * for profit and that this copyright notice is retained unchanged.
 *
 * idiff.c: 
 *
 * USAGE
 *	% idiff [ flags ] arguments
 *
 * EDITLOG
 *	LastEditDate = Tue Mar  7 17:23:58 1989 - Michael Mauldin
 *	LastFileName = /usr2/mlm/src/misc/fbm/idiff.c
 *
 * HISTORY
 * 07-Mar-89  Michael Mauldin (mlm) at Carnegie Mellon University
 *	Beta release (version 0.9) mlm@cs.cmu.edu
 *
 * 18-Aug-88  Michael Mauldin (mlm) at Carnegie-Mellon University
 *	Created.
 *****************************************************************/

# include <stdio.h>

# define USAGE \
"Usage: idiff < original > delta\n       udiff < delta > original"

#ifndef lint
static char *fbmid =
	"$FBM idiff.c <0.9> 07-Mar-89  (C) 1989 by Michael Mauldin$";
#endif

main (argc, argv)
char *argv[];
{ register int ch, lastch=0;

  if (argc > 1 || !strcmp (argv[0] + strlen (argv[0]) - 5, "udiff"))
  { while ((ch = getchar ()) != EOF)
    { putchar (lastch = ((ch+lastch) & 255)); }
  }
  else
  { while ((ch = getchar ()) != EOF)
    { putchar ((ch-lastch) & 255);
      lastch = ch;
    }
  }
}
