
#include <stdio.h>
#include "fbm.h"
/*
 * read_pic(image, rfile, mstr, mlen)
 *
 */

read_pic(image, rfile, mstr, mlen)
FBM *image;
FILE *rfile;
char *mstr;
int mlen;
{
unsigned int		Width, Height;
int			i,j;
unsigned char		*Red, *Grn, *Blu;

fscanf(rfile,"%d %d\n",&Height,&Width);

/* Create output image header */
	image->hdr.rows = Height;
	image->hdr.cols = Width;
	/* If this is odd number of bytes, add one */
	if ((image->hdr.cols & 1) != 0) image->hdr.cols++;
	image->hdr.planes = 3;
	image->hdr.bits = 8;
	image->hdr.physbits = 8;
	image->hdr.rowlen = image->hdr.cols;
	image->hdr.plnlen = image->hdr.rows * image->hdr.cols;
	image->hdr.clrlen = 0;
	image->hdr.aspect = 1.0;
	image->hdr.title[0] = '\0';
	image->hdr.credits[0] = '\0';

/* Get the Image */
	alloc_fbm(image);

	Red = image->bm;
	Grn = Red + image->hdr.plnlen;
	Blu = Grn + image->hdr.plnlen;
	for (i=0; i< Height; i++)
	{
		for (j=0; j< Width; j++)
		{
			fread(Red++,1,1,rfile);
			fread(Grn++,1,1,rfile);
			fread(Blu++,1,1,rfile);
		}
		if (Width != image->hdr.cols)
		{
			Red++;Grn++;Blu++;
		}
	}
}
