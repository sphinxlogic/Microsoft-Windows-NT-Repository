/*****************************************************************
 * gray2clr.c: FBM Library 0.9 (Beta test) 07-Mar-89  Michael Mauldin
 *
 * Copyright (C) 1989 by Michael Mauldin.  Permission is granted to
 * use this file in whole or in part provided that you do not sell it
 * for profit and that this copyright notice is retained unchanged.
 *
 * gray2clr.c: 
 *
 * USAGE
 *	% gray2clr [ flags ] arguments
 *
 * EDITLOG
 *	LastEditDate = Thu Apr 20 17:05:31 1989 - Michael Mauldin
 *	LastFileName = /usr2/mlm/src/misc/fbm/gray2clr.c
 *
 * HISTORY
 * 07-Mar-89  Michael Mauldin (mlm) at Carnegie Mellon University
 *	Beta release (version 0.9) mlm@cs.cmu.edu
 *
 *  1-Dec-88  Michael Mauldin (mlm) at Carnegie-Mellon University
 *	Created.
 *****************************************************************/

# include <stdio.h>
# include <math.h>
# include "fbm.h"

# define USAGE "gray2clr [ -<type> ] [ -u ] < gray > color"

#ifndef lint
static char *fbmid =
	"$FBM gray2clr.c <0.9> 07-Mar-89  (C) 1989 by Michael Mauldin$";
#endif

main (argc, argv)
char *argv[];
{ FBM input, output;
  int outtype = DEF_8BIT;
  int mapped = 1;

  /* If invoked as 'unmap', set option to mapped=0 */
  if (strcmp (argv[0] + strlen (argv[0]) - 5, "unmap") == 0)
  { mapped = 0; }

  /* Get the options */
  while (--argc > 0 && (*++argv)[0] == '-')
  { while (*++(*argv))
    { switch (**argv)
      { case 'u':	mapped = 0; break;
	case 'A':	outtype = FMT_ATK; break;
	case 'B':	outtype = FMT_FACE; break;
	case 'F':	outtype = FMT_FBM; break;
	case 'G':	outtype = FMT_GIF; break;
	case 'I':	outtype = FMT_IFF; break;
	case 'L':	outtype = FMT_LEAF; break;
	case 'M':	outtype = FMT_MCP; break;
	case 'P':	outtype = FMT_PBM; break;
	case 'S':	outtype = FMT_SUN; break;
	case 'T':	outtype = FMT_TIFF; break;
	case 'X':	outtype = FMT_X11; break;
	case 'Z':	outtype = FMT_PCX; break;
	default:        fprintf (stderr, "%s\n", USAGE);
                        exit (1);
      }
    }
  }

  /* Clear the memory pointers so alloc_fbm won't be confused */
  input.cm  = input.bm  = (unsigned char *) NULL;
  output.cm = output.bm = (unsigned char *) NULL;

  /* Read the image and convert it */
  if (read_bitmap (&input, (char *) NULL) &&
      (mapped ?
       gray2clr (&input, &output, outtype == FMT_SUN) :
       clr_unmap (&input, &output)) &&
      write_bitmap (&output, stdout, outtype))
  { exit (0); }

  exit (1);
}
