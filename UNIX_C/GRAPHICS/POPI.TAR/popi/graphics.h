
/*  @(#)graphics.h 1.1 89/12/12
 *
 *  External variable definitions used by the popi program
 *  optional graphics module.
 *
 *  Popi was originally written by Gerard J. Holzmann - AT&T Bell Labs.
 *  This version is based on the code in his Prentice Hall book,
 *  "Beyond Photography - the digital darkroom," ISBN 0-13-074410-7,
 *  which is copyright (c) 1988 by Bell Telephone Laboratories, Inc. 
 *
 *  Permission is given to distribute these extensions, as long as these
 *  introductory messages are not removed, and no monies are exchanged.
 *
 *  No responsibility is taken for any errors or inaccuracies inherent
 *  either to the comments or the code of this program, but if reported
 *  (see README file) then an attempt will be made to fix them.
 */

/* External declarations for the variables declared in graphics.c. */

extern char geometry[] ;       /* X11 geometry information. */
extern char nextline[] ;       /* Next input line to be parsed. */
extern char x11_display[] ;    /* X11 display information. */
 
extern unsigned char *mptr ;   /* Pointer to scanline data. */
 
extern int iconic ;        /* Set if the window is in an iconic state. */
extern int iscolor ;       /* Set if this is a color screen. */
extern int ix ;            /* Initial X position of the icon. */
extern int iy ;            /* Initial Y position of the icon. */
extern int nfont_width ;   /* Width of normal font characters. */
extern int ops[] ;         /* Rasterop functions. */
extern int posspec ;       /* Set if -Wp or -g option is present (for X11) */
extern int tptr ;          /* Input buffer pointer. */

extern int wx ;            /* Initial X position of the open window. */
extern int wy ;            /* Initial Y position of the open window. */
