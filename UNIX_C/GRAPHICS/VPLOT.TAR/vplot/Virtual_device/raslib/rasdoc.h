char *documentation[] = {
" ",
"NAME",
#ifdef SEP
"    Raspen - SEPlib vplot filter for Movie files",
#else
"    raspen - vplot filter for Movie files (SEPlib version is preferred!)",
#endif
" ",
"SYNOPSIS",
#ifdef SEP
"    Raspen [options] in=vplot-inputfile OR headerfile on standard in",
#else 
"    raspen [options] [inputfiles]",
#endif
" ",
"This program creates Movie files for such things as plate tectonic movies,",
"or any movies based on any Vplot graphics.",
"This program supports EVERYTHING in Vplot to the FULL extent!",
"",
"OPTIONS",
"n1=1024 n2=768 aspect=1.",
"n1 and n2 control the size of the created output raster file, with one",
"page for each frame in the input file.",
"colormult scales vplot color numbers to raster byte values. The default is",
"2, but for plate tectonic movies 1 might be more appropriate.",
"colfile=colfile gives name of color table file for color=T option of movie.",
"If or=y then colors are OR'd as they are drawn. IE, color 3 and color 6 will",
"create color 7 where they overwrite. colormult should be a power of 2",
"in order for this option to work. (note 1 is a power of 2)",
"",
#include "../include/gendoc.h"
" ",
"SEE ALSO",
"    man pen"
};
int	doclength = { sizeof documentation/sizeof documentation[0] };
