#define F_COL		(0001)
#define F_FAT		(0002)
#define F_CLIP		(0004)
#define F_FONT		(0010)
#define F_JUST		(0020)
#define F_DASH		(0040)
#define F_COLT		(0100)
#define F_OVLY		(0200)

extern int vpdumb;
extern int vpstat;
extern int vpalign;
extern int vpbig;
extern int vpstyle;
extern char vpaligns[];
extern int lost;
extern int vpcolor, vpfat;
extern int vpsetflag;
extern int vpblast;
extern int vpbit;
extern int vparray[];
extern int vpasize[];
extern int vpframe;

extern int default_hshift, default_vshift;

extern char * malloc();
extern char * strcat();
