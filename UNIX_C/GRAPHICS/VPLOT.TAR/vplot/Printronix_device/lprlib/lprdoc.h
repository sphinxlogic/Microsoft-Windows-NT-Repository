char *documentation[] = {
" ",
"NAME",
#ifdef SEP
"    Lprpen - SEPlib vplot filter for printronix P300/P600 printers",
#else
"    lprpen - vplot filter for printronix P300/P600 printers",
#endif
" ",
"SYNOPSIS",
#ifdef SEP
"    Lprpen [options] in=vplot-inputfile OR headerfile on standard in",
#else 
"    [l]prpen [options] [inputfiles]",
#endif
" ",
"OPTIONS",
#include "../include/gendoc.h"
" ",
"SEE ALSO",
"    man pen"
};
int	doclength = { sizeof documentation/sizeof documentation[0] };
