#ifdef SEP
#define GETPAR fetch
#else
#define GETPAR getpar
#endif

#define NYW	50		/* width of raster lines in words */
#define XSTRSZ	990	/* starting x size */
#define XINCSZ	330	/* increment to x size */

/*
 * raster memory area
 */
extern short *mem;
extern int xlimit;
extern char inbuf[];
extern short line[];

extern int file_created;
extern char spoolfile[];
char *malloc();
