/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./filters/lprlib/lprattr.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#include <stdio.h>
#include <math.h>
#include "../include/attrcom.h"
#include "../include/params.h"

int             lpr_color = 1;

lprattr (command, value, v1, v2, v3)
    register int    command, value;
    int             v1, v2, v3;
{
int             icol;

    switch (command)
    {
    case SET_COLOR:
	if (value == 0)
	    lpr_color = 0;
	else
	    lpr_color = 1;
	break;
    default:
	break;
    }

    return 0;
}
