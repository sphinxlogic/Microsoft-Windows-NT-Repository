/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./lvplot/vp_move.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#include <stdio.h>
#include <vplot.h>
#include "vp_pc.h"

#ifdef FORTRAN

#ifndef UUU
#define MOVE vpmove_
#define X *x
#define Y *y
#else UUU
#define UMOVE	vpumove_
#define X		*x
#define Y		*y
#endif UUU

#else

#ifndef UUU
#define MOVE vp_move
#define X x
#define Y y
#else UUU
#define UMOVE	vp_umove
#define X		x
#define Y		y
#endif UUU

#endif

#ifndef UUU
MOVE (x, y)
#else UUU
UMOVE (x, y)
#endif UUU
    float           X, Y;
{
#ifndef UUU
    vp_plot (X, Y, 0);
#else UUU
float           xp, yp;
    xp = vp_pc._x0 + (X - vp_pc._xu0) * vp_pc._xscl;
    yp = vp_pc._y0 + (Y - vp_pc._yu0) * vp_pc._yscl;
    vp_plot (xp, yp, 0);
#endif UUU
}
