/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./lvplot/puth.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#ifndef FORTRAN
#include <stdio.h>

puth (w, iop)
    register int    w;
    register FILE  *iop;
{
register int    j;

    j = w & 255;		/* low order byte of halfword value */
    w >>= 8;
    putc ((char) j, iop);
    j = w & 255;		/* high order byte of halfword value */
    putc ((char) j, iop);
    return (ferror (iop));
}
#endif
