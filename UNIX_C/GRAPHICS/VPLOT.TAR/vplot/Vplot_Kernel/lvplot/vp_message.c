/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./lvplot/vp_message.c
 *
 * Joe Dellinger (SEP), Jan 8 1988
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#include <stdio.h>
#include <vplot.h>
#include "vp_pc.h"

#ifdef FORTRAN

#define TEXT	vpwmessage_

#else

#define TEXT	vp_message

#endif

#ifdef FORTRAN
TEXT (string, nchars)
#else
TEXT (string)
#endif
    char           *string;
#ifdef FORTRAN
    int            *nchars;
#endif
{
#ifdef FORTRAN
int             i, length;
#endif

    putc (VP_MESSAGE, vp_pc._pltout);

#ifdef FORTRAN
/*
 * Try to still work even if they didn't specify nchars.
 */
    length = 80;
    if (nchars != NULL)
    {
	if (*nchars >= 0)
	    length = *nchars;
    }

    for (i = 0; i < length; i++)
    {
	if (*(string + i) == '\0')
	    break;
	putc (*(string + i), vp_pc._pltout);
    }
    putc ('\0', vp_pc._pltout);
#else FORTRAN
    do
    {
	putc (*string, vp_pc._pltout);
    }
    while (*string++);
#endif FORTRAN
}
