/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./lvplot/vp_orig.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#include <stdio.h>
#include <vplot.h>
#include "vp_pc.h"

#ifdef FORTRAN

#ifndef UUU
#define ORIG	vporig_
#define X0		*x0
#define Y0		*y0
#else UUU
#define UORIG	vpuorig_
#define XU0		*xu0
#define YU0		*yu0
#endif UUU

#else

#ifndef UUU
#define ORIG	vp_orig
#define X0		x0
#define Y0		y0
#else UUU
#define UORIG	vp_uorig
#define XU0		xu0
#define YU0		yu0
#endif UUU

#endif

#ifndef UUU
ORIG (x0, y0)
    float           X0, Y0;
#else UUU
UORIG (xu0, yu0)
    float           XU0, YU0;
#endif UUU
{
#ifndef UUU
    vp_pc._x0 = X0;
    vp_pc._y0 = Y0;
#else UUU
    vp_pc._xu0 = XU0;
    vp_pc._yu0 = YU0;
#endif UUU
}
