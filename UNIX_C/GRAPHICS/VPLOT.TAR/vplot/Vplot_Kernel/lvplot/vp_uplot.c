/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./lvplot/vp_uplot.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#include <stdio.h>
#include <vplot.h>
#include "vp_pc.h"

#ifdef FORTRAN

#define UPLOT	vpuplot_
#define X		*x
#define Y		*y
#define DOWN	*down

#else

#define UPLOT	vp_uplot
#define X		x
#define Y		y
#define DOWN	down

#endif

UPLOT (x, y, down)
    float           X, Y;
    int             DOWN;
{
float           xp, yp;
    xp = vp_pc._x0 + (X - vp_pc._xu0) * vp_pc._xscl;
    yp = vp_pc._y0 + (Y - vp_pc._yu0) * vp_pc._yscl;
    vp_plot (xp, yp, DOWN);
}
