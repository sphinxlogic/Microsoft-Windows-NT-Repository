/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./lvplot/vp_style.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#include <stdio.h>
#include <vplot.h>
#include "vp_pc.h"
#include "params.h"

#ifdef FORTRAN

#define VPSTYLE	vpstyle_
#define ST		*st

#else

#define VPSTYLE	vp_style
#define ST		st

#endif

int             cur_style = STYLE;	/* default; set in "params.h" */

VPSTYLE (st)
    int             ST;
{

    cur_style = ST;
    putc (VP_SETSTYLE, vp_pc._pltout);
    switch (ST)
    {
    case ROTATED:
	putc ('r', vp_pc._pltout);
	break;
    case ABSOLUTE:
	putc ('a', vp_pc._pltout);
	break;
    case STANDARD:
    default:
	putc ('s', vp_pc._pltout);
	break;
    }
}
