/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./lvplot/vp_pendn.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#include <vplot.h>
#include "vp_pc.h"

/* go to location (x,y) and then put the pen down */
#ifdef FORTRAN

#ifndef UUU
#define PENDN vppendn_
#else UUU
#define UPENDN vpupendn_
#endif UUU
#define X *x
#define Y *y

#else

#ifndef UUU
#define PENDN vp_pendn
#else UUU
#define UPENDN vp_upendn
#endif UUU
#define X x
#define Y y

#endif

#ifndef UUU
PENDN (x, y)
#else UUU
UPENDN (x, y)
#endif UUU
    float           X, Y;
{
#ifndef UUU
    vp_plot (X, Y, vp_pc._pendown);
#else UUU
    vp_uplot (X, Y, vp_pc._pendown);
#endif UUU
    vp_pc._pendown = 1;
}
