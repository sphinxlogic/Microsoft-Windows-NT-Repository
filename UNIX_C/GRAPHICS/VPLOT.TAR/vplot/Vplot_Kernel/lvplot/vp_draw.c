/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./lvplot/vp_draw.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#include <stdio.h>
#include <vplot.h>
#include "vp_pc.h"

#ifdef FORTRAN

#ifndef UUU
#define DRAW vpdraw_
#define X *x
#define Y *y
#else UUU
#define UDRAW	vpudraw_
#define X		*x
#define Y		*y
#endif UUU

#else

#ifndef UUU
#define DRAW vp_draw
#define X x
#define Y y
#else UUU
#define UDRAW	vp_udraw
#define X		x
#define Y		y
#endif UUU

#endif

#ifndef UUU
DRAW (x, y)
#else UUU
UDRAW (x, y)
#endif UUU
    float           X, Y;
{
#ifndef UUU
    vp_plot (X, Y, 1);
#else UUU
float           xp, yp;
    xp = vp_pc._x0 + (X - vp_pc._xu0) * vp_pc._xscl;
    yp = vp_pc._y0 + (Y - vp_pc._yu0) * vp_pc._yscl;
    vp_plot (xp, yp, 1);
#endif UUU
}
