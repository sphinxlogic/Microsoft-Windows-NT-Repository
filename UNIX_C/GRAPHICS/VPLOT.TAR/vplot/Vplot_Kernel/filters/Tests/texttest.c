/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./filters/Tests/texttest.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#include <stdio.h>
#include <vplot.h>
#include <math.h>

#define NP 7

main ()
{
float           xp, yp;
int             i;

/*
 * Set up where you want the vplot output to go.
 */
    vp_filep (stdout);

/*
 * Decide what "style" plot this is to be.
 */
    vp_style (STANDARD);

/*
 * text
 */
    for (i = 0; i < NP; i++)
    {
	xp = 1. + (7. / NP) * i;
	yp = xp;
	vp_color (i + 1);
	vp_tfont (i * 2, STRING, OVLY_NORMAL);
	vp_text (xp, yp, 15, 0, "This is a test...");
/*	vp_utext(xp,yp,15,0,"This is a test..."); */
    }

/*
 * Finish up
 */
    vp_endplot ();
}
