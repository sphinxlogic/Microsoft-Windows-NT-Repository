#define ROUND(x) ((x<0)?((int)(x-0.5)):((int)(x+0.5)))
