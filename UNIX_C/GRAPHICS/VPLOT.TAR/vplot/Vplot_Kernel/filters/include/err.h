/*
 * error codes for VPLOT filters
 */
#define ERR	filtererror

#define COMMENT 0
#define WARN	1
#define FATAL	2
