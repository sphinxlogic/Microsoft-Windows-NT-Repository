/*
 *
 *  source file:   ./filters/loclib/getpar_string_store.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

/* Rewrite 3-8-86 stew  Don't invoke parser unless we see par=.  This
 *			leaves the shell's parsed output of the command
 *			line intact, fixing joe's complaint.  Also a
 *			bit faster.
 *	   2-15-88 joe  Should be hash_item "**q", not "*q". Oops.
 */
#include "fastpar.h"
#include <stdio.h>
#include <strings.h>
getpar_string_store(q,qsize,string)
hash_item **q;
int qsize;
register char *string;
{
 register int tlen, vlen;
 register char *val;

 val = index(string,'=');
 if(val == ((char *) NULL)) return;
 tlen = val - string;
 if(tlen <= 0) return;
 val++;
 vlen=strlen(val);
 if(vlen <= 0) return;
 getpar_hash_store(q,qsize,string,val,tlen,vlen);
 if( tlen==3 && 0==bcmp(string,"par",3) ) {
 	getpar_stack_par(val);
	getpar_scan(q,qsize);
	}
}
