/*
 *
 *  source file:   ./filters/loclib/doc.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

/*
 * Special version to make SEP selfdoc the same way glenn does.
 */
#include <stdio.h>
#include <strings.h>
#include "../include/extern.h"

doc ()
{
int             ii;
extern int      xargc, redin ();
extern char   **xargv;

    if ((xargc == 1 || (xargc == 2 && !strncmp ("wstype=", xargv[1], 7)))
	&& !redin ())
    {
	for (ii = 0; ii < doclength; ii++)
	    printf ("%s\n", documentation[ii]);
	exit (0);
    }
}
