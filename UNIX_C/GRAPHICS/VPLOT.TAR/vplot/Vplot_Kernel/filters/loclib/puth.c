/*
 *
 *  source file:   ./filters/loclib/puth.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#include <stdio.h>

puth (w, iop)
    register int    w;
    register FILE  *iop;
{
register int    j;

    j = w & 255;		/* low order byte of halfword value */
    w >>= 8;
    putc ((char) j, iop);
    j = w & 255;		/* high order byte of halfword value */
    putc ((char) j, iop);
    return (ferror (iop));
}
