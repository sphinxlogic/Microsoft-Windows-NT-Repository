/*
 *
 *  source file:   ./filters/loclib/geth.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#include <stdio.h>

short
geth(iop)
register FILE *iop;
{
        union {
	    unsigned short w;
	    short s;
	    } r;

	r.w = getc(iop);
	r.w += (getc(iop) << 8);
	if (feof(iop))
		return(EOF);
	return((int)r.s);
}
