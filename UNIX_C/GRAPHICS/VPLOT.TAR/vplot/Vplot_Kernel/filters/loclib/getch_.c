/*
 *
 *  source file:   ./filters/loclib/getch_.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#include "fastpar.h"
#define GETCH_QUEUE_SIZE  127

hash_item *getch_queue[GETCH_QUEUE_SIZE];
int getch_queue_size = GETCH_QUEUE_SIZE;

int
getch_(tag,type,val)
char *tag, *type;
MIXED val;
{
 register int iargc;
 static int first_invoke = 1;
 extern int xargc; extern char **xargv;

 if(first_invoke) {
    for(iargc=1; iargc<xargc; iargc++) 
	getpar_string_store(getch_queue,getch_queue_size,xargv[iargc]);
    first_invoke = 0;
    }

 return (getpar_decode(getch_queue,getch_queue_size,tag,type,val));
}

getch_add_string_(string)
char *string;
{
	getpar_string_store(getch_queue,getch_queue_size,string);
}
