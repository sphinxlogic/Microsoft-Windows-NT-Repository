# include "stdio.h"
# define U(x) x
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX 200
# define output(c) putc(c,yyout)
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
# define ECHO fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin ={stdin}, *yyout ={stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;
/* lexical scanning for fast getpar */
/* Revised 3-8-86 stew  Added time stamp to enable older method of handling
 *			multiple tags.  Moved par= intiialization to
 *			separate routine to avoid code duplication.
 */
#include <ctype.h>
#include "fastpar.h"
#undef input
#define input() ((int) *(input_stack[input_depth]++))
#undef unput
/* The redundant  =(c) insures side effects of expressions occur */
#define unput(c) (*(--(input_stack[input_depth]))=(c))
#define yywrap() getpar_pop_input()
#define yylex() getpar_lexscan()
#define yylook() getpar_yylook()

#define MAX_INPUT_DEPTH 10
static int input_depth = -1;
static char *input_stack[MAX_INPUT_DEPTH];
static char *dealloc_stack[MAX_INPUT_DEPTH];

static struct {
	char *tag;  int tlen;
	char *val;  int vlen;
       } yy;


static int  SMALLBLOCK = 4096;
static char
*suballoc (size)
int size;
{
	static char *myblock = (char *) NULL; static int bytesleft = 0;
	char *ptr; extern char *alloc();

	if(size > SMALLBLOCK) return(alloc(size));
	else
	  { 
	    if(bytesleft < size)
	       {
	        myblock = alloc (SMALLBLOCK);
		bytesleft = SMALLBLOCK - size;
	       }
	   else
	       {
		bytesleft -= size;
	       }
	   ptr = myblock;
	   myblock += size;
	   return(ptr);
	  }
}

static int  prime[10] = {31,29,23,19,17,13,11,7,5,3};
int getpar_hash(array,len)
register char *array;
register int len;
{
  register int hash;
  register int i;
  if(len >10) len=10;
  hash=0;
  for(i=0; i<len; i++)
    hash += array[i]*prime[i];
  return(hash);
}

/* workhorse to decode par files; shell already parses command line */
getpar_scan(queue,qlen)
register hash_item **queue;
register int qlen;
{
 extern int yylex();

 while(yylex()) {
	getpar_hash_store(queue,qlen,yy.tag,yy.val,yy.tlen,yy.vlen);
	if(yy.tlen == 3 && 0 == bcmp(yy.tag,"par",3))
		getpar_stack_par(yy.val);
	}
}

/* read parfile into core and put buffer on scan input stack */
getpar_stack_par(val)
char *val;
{
 register char *buffer;
 register int fd, len;
 extern int file(), fsize();
 extern char *alloc();

    fd = file(val,0);
    len = fsize(fd);
    buffer=alloc(len+3);
    buffer[0]='\n';
    read(fd,buffer+1,len);
    buffer[len+1]='\n';
    buffer[len+2]='\0';
    getpar_push_input(buffer,1);
    close(fd);
}

 /* return 1 if match; 0 otherwise */
#define getpar_hash_compare(next1,tag1,tlen1)  \
 ((next1)->tlen == (tlen1) && 0 == bcmp((next1)->tag,tag1,tlen1))

getpar_hash_store(q,qlen,tag,val,tlen,vlen)
hash_item **q;
register char *tag, *val;
register int tlen;
int qlen, vlen;
{
 register hash_item *hold, *next;
 static int storetime = 0;

 hold=(hash_item *) (q+getpar_hash(tag,tlen)%qlen);
 next=hold->next;

 while(next != ((hash_item *) NULL)) {
	if(getpar_hash_compare(next,tag,tlen) ) {
		next->val = val; next->vlen = vlen;
		next->timestamp = storetime++; return;
		}
	hold = next; next = next->next;
	}

 hold->next = next = (hash_item *) suballoc(sizeof(hash_item));
 next->next = (hash_item *) NULL;
 next->tlen = tlen;
 next->tag = tag;
 next->vlen = vlen;
 next->val = val;
 next->timestamp = storetime++;
}

hash_item *getpar_hash_lookup(q,qlen,tag,tlen)
register hash_item **q;
register char *tag;
register int tlen;
register int qlen;
{
 register hash_item *next;

 next = *(q + getpar_hash(tag,tlen)%qlen);

 while(next != ((hash_item *) NULL) ) {
	if(getpar_hash_compare(next,tag,tlen)) break;
	next = next->next;
	}
 return(next);
}

# define FOUNDTAG 2
# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:
	{
			 yy.vlen = yyleng-2; yy.val=suballoc(yy.vlen+1);
			 yy.vlen = massage(yytext+1,yy.val,yy.vlen,yytext[0]);
			 yy.val[yy.vlen]='\0'; BEGIN 0; return(FOUNDTAG);
			 }
break;
case 2:
	{
			 yy.vlen = yyleng-2; yy.val=suballoc(yy.vlen+1);
			 yy.vlen = massage(yytext+1,yy.val,yy.vlen,yytext[0]);
			 yy.val[yy.vlen]='\0'; BEGIN 0; return(FOUNDTAG);
			 }
break;
case 3:
{
				 yy.vlen=yyleng; yy.val=suballoc(yy.vlen+1);
		 		 bcopy(yytext,yy.val,yy.vlen+1); BEGIN 0;
				 return(FOUNDTAG);
				 }
break;
case 4:
{
			 yy.tlen=yyleng-1; yy.tag=suballoc(yy.tlen+1);
			 bcopy(yytext,yy.tag,yy.tlen);
			 yy.tag[yy.tlen]='\0'; BEGIN FOUNDTAG;
			 }
break;
case 5:
{
			 yy.tlen=yyleng-2; yy.tag=suballoc(yy.tlen+1);
			 bcopy(yytext+1,yy.tag,yy.tlen);
			 yy.tag[yy.tlen]='\0'; BEGIN FOUNDTAG;
			 }
break;
case 6:
/* skip comment lines */;
break;
case 7:
case 8:
;
break;
case -1:
break;
default:
fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */
	getpar_push_input(buffer,dealloc)
	register char *buffer;
	register int dealloc;
	{
	  if(input_depth++ == MAX_INPUT_DEPTH)
		err("too many nested par files\n");
	  input_stack[input_depth] = buffer;
	  if(dealloc) dealloc_stack[input_depth] = buffer;
	  else dealloc_stack[input_depth] = (char *) NULL;
	}

	int
	yywrap()
	{
	  if(((char *) NULL) != dealloc_stack[input_depth]) {
		free(dealloc_stack[input_depth]);
		dealloc_stack[input_depth] = (char *) NULL;
		}
	  input_stack[input_depth--] = (char *) NULL;
	  if(input_depth < 0) return(1);
	  return(0);
	}

	static int
	massage(string,out,len,quote)
	register char *string, *out;
	register int len, quote;
	{
 	register int i,j;
	
	for(i=0,j=0; i<len-1; j++) {
		out[j]=string[i++];
		if(out[j]==quote) /* compress doubled quotes */
			if(string[i]==quote) i++;
		}
	if(i<len) out[j++] = string[i];
	return(j);
	}
int yyvstop[] ={
0,

7,
0,

7,
0,

8,
0,

6,
7,
0,

7,
0,

3,
7,
0,

3,
7,
0,

3,
8,
0,

7,
0,

7,
0,

3,
6,
7,
0,

3,
7,
0,

6,
0,

-4,
0,

3,
0,

3,
0,

2,
0,

2,
0,

1,
0,

1,
0,

3,
6,
0,

3,
0,

3,
-4,
0,

-5,
0,

4,
0,

3,
-5,
0,

3,
4,
0,

5,
0,

3,
5,
0,
0};
# define YYTYPE char
struct yywork { YYTYPE verify, advance; } yycrank[] ={
0,0,	0,0,	1,5,	0,0,	
0,0,	3,10,	0,0,	0,0,	
0,0,	0,0,	1,6,	1,7,	
0,0,	3,11,	3,12,	18,0,	
12,0,	12,0,	0,0,	21,0,	
21,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	35,0,	
35,0,	0,0,	37,0,	37,0,	
0,0,	0,0,	0,0,	1,5,	
0,0,	2,8,	3,13,	12,0,	
1,5,	4,15,	21,0,	3,14,	
25,23,	28,26,	1,5,	11,0,	
11,0,	3,10,	35,0,	0,0,	
17,17,	37,0,	0,0,	17,17,	
17,17,	17,17,	17,17,	17,17,	
17,17,	17,17,	17,17,	17,17,	
17,17,	0,0,	1,5,	2,9,	
17,32,	3,10,	11,0,	4,16,	
6,17,	6,17,	6,17,	6,17,	
6,17,	6,17,	6,17,	6,17,	
6,17,	6,17,	6,17,	6,17,	
6,17,	6,17,	6,17,	6,17,	
6,17,	6,17,	6,17,	6,17,	
6,17,	6,17,	6,17,	6,17,	
6,17,	6,17,	0,0,	0,0,	
0,0,	0,0,	17,17,	11,22,	
6,17,	6,17,	6,17,	6,17,	
6,17,	6,17,	6,17,	6,17,	
6,17,	6,17,	6,17,	6,17,	
6,17,	6,17,	6,17,	6,17,	
6,17,	6,17,	6,17,	6,17,	
6,17,	6,17,	6,17,	6,17,	
6,17,	6,17,	8,18,	0,0,	
0,0,	0,0,	0,0,	0,0,	
16,0,	16,0,	8,18,	8,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	16,0,	
0,0,	0,0,	0,0,	8,18,	
0,0,	0,0,	0,0,	0,0,	
8,18,	0,0,	0,0,	0,0,	
16,30,	0,0,	8,18,	9,19,	
0,0,	0,0,	9,19,	9,19,	
9,19,	9,19,	9,19,	9,19,	
9,19,	9,19,	9,19,	9,19,	
16,31,	0,0,	0,0,	9,20,	
16,30,	0,0,	8,18,	9,19,	
9,19,	9,19,	9,19,	9,19,	
9,19,	9,19,	9,19,	9,19,	
9,19,	9,19,	9,19,	9,19,	
9,19,	9,19,	9,19,	9,19,	
9,19,	9,19,	9,19,	9,19,	
9,19,	9,19,	9,19,	9,19,	
9,19,	0,0,	0,0,	0,0,	
0,0,	9,19,	0,0,	9,19,	
9,19,	9,19,	9,19,	9,19,	
9,19,	9,19,	9,19,	9,19,	
9,19,	9,19,	9,19,	9,19,	
9,19,	9,19,	9,19,	9,19,	
9,19,	9,19,	9,19,	9,19,	
9,19,	9,19,	9,19,	9,19,	
9,19,	10,21,	0,0,	13,23,	
0,0,	14,26,	22,0,	22,0,	
0,0,	10,0,	10,0,	13,23,	
13,24,	14,26,	14,27,	15,29,	
0,0,	0,0,	0,0,	20,33,	
0,0,	0,0,	29,29,	0,0,	
15,0,	0,0,	0,0,	20,0,	
20,0,	22,0,	0,0,	29,0,	
10,0,	0,0,	10,21,	0,0,	
13,25,	0,0,	14,26,	10,21,	
0,0,	13,23,	22,22,	14,28,	
0,0,	10,21,	0,0,	13,23,	
15,29,	14,26,	20,0,	0,0,	
20,33,	15,29,	0,0,	29,29,	
0,0,	20,33,	22,34,	15,29,	
29,29,	0,0,	22,22,	20,33,	
31,35,	10,21,	29,29,	13,23,	
0,0,	14,26,	30,0,	30,0,	
31,0,	31,0,	0,0,	0,0,	
32,36,	0,0,	0,0,	15,29,	
34,37,	0,0,	0,0,	20,33,	
32,0,	32,0,	29,29,	0,0,	
34,0,	34,0,	0,0,	0,0,	
0,0,	30,0,	0,0,	31,0,	
0,0,	31,35,	0,0,	0,0,	
0,0,	0,0,	31,35,	0,0,	
0,0,	0,0,	30,30,	32,0,	
31,35,	32,36,	0,0,	34,0,	
0,0,	34,37,	32,36,	0,0,	
0,0,	0,0,	34,37,	0,0,	
32,36,	0,0,	30,31,	0,0,	
34,37,	0,0,	30,30,	0,0,	
31,35,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
32,36,	0,0,	0,0,	0,0,	
34,37,	0,0,	0,0,	0,0,	
0,0};
struct yysvf yysvec[] ={
0,	0,	0,
yycrank+-1,	0,		0,	
yycrank+-2,	yysvec+1,	0,	
yycrank+-4,	0,		0,	
yycrank+-6,	yysvec+3,	0,	
yycrank+0,	0,		yyvstop+1,
yycrank+7,	0,		yyvstop+3,
yycrank+0,	0,		yyvstop+5,
yycrank+-129,	0,		yyvstop+7,
yycrank+130,	0,		yyvstop+10,
yycrank+-252,	0,		yyvstop+12,
yycrank+-38,	yysvec+10,	yyvstop+15,
yycrank+-7,	yysvec+10,	yyvstop+18,
yycrank+-254,	0,		yyvstop+21,
yycrank+-256,	0,		yyvstop+23,
yycrank+-266,	yysvec+8,	yyvstop+25,
yycrank+-127,	yysvec+10,	yyvstop+29,
yycrank+7,	yysvec+6,	0,	
yycrank+-5,	yysvec+8,	yyvstop+32,
yycrank+0,	yysvec+9,	0,	
yycrank+-270,	0,		yyvstop+34,
yycrank+-10,	yysvec+10,	yyvstop+36,
yycrank+-249,	yysvec+10,	yyvstop+38,
yycrank+0,	yysvec+13,	0,	
yycrank+0,	0,		yyvstop+40,
yycrank+10,	0,		yyvstop+42,
yycrank+0,	yysvec+14,	0,	
yycrank+0,	0,		yyvstop+44,
yycrank+6,	0,		yyvstop+46,
yycrank+-273,	yysvec+8,	yyvstop+48,
yycrank+-313,	yysvec+10,	yyvstop+51,
yycrank+-315,	0,		yyvstop+53,
yycrank+-327,	0,		yyvstop+56,
yycrank+0,	0,		yyvstop+58,
yycrank+-331,	0,		yyvstop+60,
yycrank+-18,	yysvec+10,	yyvstop+63,
yycrank+0,	0,		yyvstop+66,
yycrank+-21,	yysvec+10,	yyvstop+68,
0,	0,	0};
struct yywork *yytop = yycrank+396;
struct yysvf *yybgin = yysvec+1;
char yymatch[] ={
00  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,011 ,012 ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
011 ,01  ,'"' ,01  ,01  ,01  ,01  ,047 ,
01  ,01  ,01  ,01  ,01  ,'-' ,01  ,01  ,
'-' ,'-' ,'-' ,'-' ,'-' ,'-' ,'-' ,'-' ,
'-' ,'-' ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,01  ,01  ,01  ,01  ,'-' ,
01  ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,01  ,01  ,01  ,01  ,01  ,
0};
char yyextra[] ={
0,0,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
0};
/*	ncform	4.1	83/08/11	*/

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
yylook(){
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank){		/* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
			*yylastch++ = yych = input();
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
yyback(p, m)
	int *p;
{
if (p==0) return(0);
while (*p)
	{
	if (*p++ == m)
		return(1);
	}
return(0);
}
	/* the following are only used in the lex library */
yyinput(){
	return(input());
	}
yyoutput(c)
  int c; {
	output(c);
	}
yyunput(c)
   int c; {
	unput(c);
	}
