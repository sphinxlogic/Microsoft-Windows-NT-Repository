/*
 *	opens and creates file
 *	arguments:
 *		name	character string containing filename
 *		mode	0 open only
 *			1 create only
 *			2 try open, then create
 *	returns file descriptor
 */
int 
file (name, mode)
    char           *name;
    int             mode;
{
int             filedes, open (), creat ();
    switch (mode)
    {
    case 0:
	if ((filedes = open (name, 0)) == -1)
	{
	    perror ("file()");
	    err ("file() can't open file %s\n", name);
	}
	break;
    case 2:
	if ((filedes = open (name, 2)) == -1)
    case 1:
	    if ((filedes = creat (name, 0664)) == -1)
	    {
		perror ("file()");
		err ("file() can't create file %s\n", name);
	    }
	    else
	    {
		if (-1 == close (filedes))
		{
		    perror ("file()");
		    err ("file() unable to close file %s\n", name);
		}
		if (-1 == (filedes = open (name, 2)))
		{
		    perror ("file()");
		    err ("file() unable to open file %s\n", name);
		}
	    }
    }
    return (filedes);
}
