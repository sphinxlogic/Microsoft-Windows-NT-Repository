/* added timestamp 3-8-86  stew */
typedef struct hash_dummy {
	struct hash_dummy *next;
	char *tag; int tlen;
	char *val; int vlen;
	int timestamp;
	} hash_item;

typedef union { int *i; float *f; double *g ; char *s; } MIXED;
