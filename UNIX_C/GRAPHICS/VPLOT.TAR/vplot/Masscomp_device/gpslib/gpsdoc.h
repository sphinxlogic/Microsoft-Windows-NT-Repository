char *documentation[] = {
" ",
"NAME",
#ifdef SEP
"    Gpspen - SEPlib vplot filter for Masscomp GPS files",
#else
"    gpspen - vplot filter for Masscomp GPS files",
#endif
" ",
"SYNOPSIS",
#ifdef SEP
"    Gpspen [options] in=vplot-inputfile OR headerfile on standard in",
#else 
"    gpspen [options] [inputfiles]",
#endif
" ",
"This program transforms vplot commands into Masscomp GPS commands",
"so that the color Versatec (and other Masscomp graphics) may be used.",
"",
"OPTIONS",
"colormult=1 ppi=600 aspect=1.",
"colormult scales vplot color numbers to raster byte values. The default is",
"1, but for SEP movies 2 might be more appropriate.",
"ppi is the internal vplot resolution to use.  The default 600 is harmless",
"overkill for Versatecs which run at 200 or 300 ppi.  If a lot of area fill",
"is anticipated, drop this down to the device resolution for speed.",
"aspect, if changed, chould probably be set to 0.75.",
"",
#include "../include/gendoc.h"
" ",
"SEE ALSO",
"    man pen"
};
int	doclength = { sizeof documentation/sizeof documentation[0] };
