/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./filters/gpslib/gpsplot.c
 *
 * Stewart A. Levin (SEP), July 3 1987
 *	Cribbed enviplot.c for gps filter
 */

#include <stdio.h>
#include "../include/enum.h"
#include "gpspen.h"

int             lost = YES;	/* 1 means we are lost, zero means we aren't */

gpsplot (x, y, drw)	/* efficiently get to the point x,y. */
    int             x, y, drw;	/* draw 0 means we want to move, not to draw */
{
float           flx, fly;

    flx = x;
    fly = y;
    if (drw == 0)
    {
	move (flx, fly);
    }
    else
    {
	draw (flx, fly);
    }
    lost = NO;
}
