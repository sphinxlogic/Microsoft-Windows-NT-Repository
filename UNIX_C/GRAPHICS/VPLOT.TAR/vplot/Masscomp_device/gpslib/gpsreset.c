/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./filters/gpslib/gpsreset.c
 *
 * Stewart A. Levin (SEP), July 3 1987
 *	Cribbed rasreset.c for gps filter
 */

#include <stdio.h>
#include "gpspen.h"
#include "../include/extern.h"
#include "../include/params.h"

gpsreset ()
{
    gps_region (13);		/* center of gps coordinate universe */
    set_window ((float) dev_xmin, (float) dev_ymin,
		(float) dev_xmax, (float) dev_ymax);
    line_style (20);
}
