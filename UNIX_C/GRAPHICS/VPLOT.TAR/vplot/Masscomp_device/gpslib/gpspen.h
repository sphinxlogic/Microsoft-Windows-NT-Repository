extern int gpscolor;		/* current color */
extern int dev_xmin, dev_ymin, dev_xmax, dev_ymax;
#define	Min(IX,IY)	((IX) < (IY) ? (IX) : (IY))
#define	Max(IX,IY)	((IX) > (IY) ? (IX) : (IY))
#define NCOLOR 256		/* number of colors */
