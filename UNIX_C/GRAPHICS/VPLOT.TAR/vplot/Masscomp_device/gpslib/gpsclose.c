/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./filters/gpslib/gpsclose.c
 *
 * Stewart A. Levin (SEP), July 3 1987
 *	Cribbed rasclose.c for gps filter
 */

#include <stdio.h>
#include "../include/closestat.h"
#include "../include/err.h"
#include "../include/extern.h"
#include "../include/params.h"
#include "gpspen.h"

gpsclose (status)
    int             status;
{
    switch (status)
    {
    case CLOSE_NORMAL:
	end_plot ("");
	break;
    case CLOSE_FLUSH:
    default:
	break;
    }
}
