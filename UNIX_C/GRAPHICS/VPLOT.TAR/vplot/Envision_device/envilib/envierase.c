/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./filters/envilib/envierase.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#include <stdio.h>
#include "../include/erasecom.h"
#include "envi.h"
extern FILE    *pltout;

envierase (command)
    int             command;
{
    switch (command)
    {
    case ERASE_START:
    case ERASE_MIDDLE:
	envisetmode (REG);
	putc (ESC, pltout);
	putc (ENVI_ERASE, pltout);	/* Erase Graphics Screen */
	break;
    case ERASE_END:
    default:
	break;
    }
}
