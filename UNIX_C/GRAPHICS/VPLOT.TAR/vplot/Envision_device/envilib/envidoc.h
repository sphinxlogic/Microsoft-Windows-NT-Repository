char *documentation[] = {
" ",
"NAME",
#ifdef SEP
"    Envipen - SEPlib vplot filter for Envision 220 and 215",
#else
"    envipen - vplot filter for Envision 220 and 215",
#endif
" ",
"SYNOPSIS",
#ifdef SEP
"    E[nvi]pen [options] in=vplot-inputfile OR headerfile on standard in",
#else 
"    e[nvi]pen [options] [inputfiles]",
#endif
" ",
"OPTIONS",
#ifdef SEP
"    Envipen-specific options:",
#else
"    envipen-specific options:",
#endif
"          bell=[y,n]      inform you the plot is done with a beep.",
"          wstype=[envi220,envi215] Pick envision 220 or 215.",
#include "../include/gendoc.h"
" ",
"SEE ALSO",
"    man pen"
};
int	doclength = { sizeof documentation/sizeof documentation[0] };
