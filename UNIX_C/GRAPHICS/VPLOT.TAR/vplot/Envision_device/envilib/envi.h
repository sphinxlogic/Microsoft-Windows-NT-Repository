#define ESC 033
#define FS  034
#define GS  035
#define US	037
#define ENVI_ERASE 'F'
#define MOV 2
#define TEK 1
#define REG 0

extern int lost;
extern int version;
