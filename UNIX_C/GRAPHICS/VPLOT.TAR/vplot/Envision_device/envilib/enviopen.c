/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./filters/envilib/enviopen.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#include <stdio.h>
#include "../include/enum.h"
#include "../include/extern.h"


extern int      want_bell;
extern char     wstype[];
extern int      vecarea ();
int             version;

enviopen ()
{
char            bell[10];

    version = 220;

/*
 * physical device size that can be different on different models
 */
    dev_ymax = 479;

/*
 * device capabilities
 */
    need_end_erase = NO;
    buffer_output = YES;
    smart_clip = NO;

    if (!strcmp (wstype, "envi215"))
    {
	version = 215;
	dev_ymax = 407;
	dev.area = vecarea;	/* 215's can't fill properly */
    }
    getpar ("bell", "s", bell);
    if (bell[0] == 'n')
	want_bell = 0;
    endpause = YES;
}
