/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./filters/gigilib/gigireset.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

/* 
 * Put the terminal into standard configuration.
 */
#include <stdio.h>
#include "gigi.h"
extern FILE    *pltout;

gigireset ()
{
    fprintf (pltout, "%c[2J%c[24;1H%cPpP[0,0];", ESC, ESC, ESC);
    fprintf (pltout, "@:W (W(VI7A0S0N0M2P1(M2)))@;");
    /* define temporary writing controls */
    fprintf (pltout, "S(EI0N0A)[0,0]T(I0A0D0S1)P[0,0]");
    fflush (pltout);
    lastop = '$';		/* flag that new plot was reinitialized */
}
