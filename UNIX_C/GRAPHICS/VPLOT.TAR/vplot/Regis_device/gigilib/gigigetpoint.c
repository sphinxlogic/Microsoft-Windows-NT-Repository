/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./filters/gigilib/gigigetpoint.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#include <stdio.h>

extern FILE    *pltout;

extern int      dev_xmax, dev_ymax, dev_xmin, dev_ymin;
extern int      lost;	/* used by genvector */

gigigetpoint (termout, x, y)
    FILE           *termout;
    int            *x, *y;
{
int             itemp;
char            temp[10];

    fflush (pltout);
    fprintf (pltout, "r(p(i))");
    fflush (pltout);
    fscanf (termout, "%[^0123456789]%d,%d]%*c", temp, y, x);

/* Undo the GIGI's perverse coordinate system */
    *x = *x / 2;
    *y = *y / 2;

    itemp = *y;
    *y = dev_ymin + dev_ymax - *x;
    *x = itemp;
    lost = 1;
    return (0);
}
