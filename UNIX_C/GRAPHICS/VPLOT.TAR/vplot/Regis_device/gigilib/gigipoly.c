/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./filters/gigilib/gigipoly.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 * Joe Dellinger Feb 16 1988
 *	Fixed bug in call to gigiplot
 */

#include <stdio.h>
#include "gigi.h"
extern FILE    *pltout;

int             in_a_poly = 0;

static int      need_set_shade = 0;

gigistartpoly (npts)
    int             npts;
{
    lost = 1;
    need_set_shade = 1;
    in_a_poly = 1;
    if (lastop != 'P')
	fprintf (pltout, "P");
}

gigimidpoly (x, y)
    int             x, y;
{
    gigiplot (x, y, 0);
    if (need_set_shade == 1)
    {
	need_set_shade = 0;
	fprintf (pltout, "V@W(W(S1))");
	lastop = 'V';
    }
}

gigiendpoly (last)
    int             last;
{
    fprintf (pltout, "(W(S0))V@W");
    lost = 1;
    in_a_poly = 0;
}
