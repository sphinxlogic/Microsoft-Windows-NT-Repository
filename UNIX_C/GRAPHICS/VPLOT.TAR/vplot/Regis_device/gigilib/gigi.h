#define	ESC	033

extern int lost;
extern int lastop;
extern int messagecount;
extern int in_a_poly;
