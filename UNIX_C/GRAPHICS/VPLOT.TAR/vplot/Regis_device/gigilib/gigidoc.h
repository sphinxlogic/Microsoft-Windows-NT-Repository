
char *documentation[] = {
"NAME",
#ifdef SEP
"	Gigipen - SEPlib vplot filter for Dec Gigi and VT125 (Regis) terminals",
#else
"	gigipen - vplot filter for Dec Gigi and VT125 (Regis) terminals",
#endif
" ",
"SYNOPSIS",
#ifdef SEP
"	Gigipen [options] in=file or < Header1 [Header2,...]",
#else
"	gigipen [options] file1 [file2,...] or in=file or < file",
#endif
" ",
"OPTIONS",
"	wstype=[gigi,vt125]",
#include "../include/gendoc.h"
};
int	doclength = { sizeof documentation/sizeof documentation[0] };
