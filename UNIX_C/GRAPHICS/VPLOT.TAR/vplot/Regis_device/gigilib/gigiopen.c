/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./filters/gigilib/gigiopen.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#include <stdio.h>
#include "gigi.h"
#include "../include/enum.h"
#include "../include/extern.h"

int             lastop;

gigiopen ()
{
/*
 * physical device size
 */
    dev_xmax = 383;
    dev_ymax = 240;
    dev_xmin = 0;
    dev_ymin = 0;
    pixels_per_inch = 38;
    aspect_ratio = 1.;

/*
 * device capabilities
 */
    need_end_erase = NO;
    buffer_output = YES;
    smart_clip = NO;
    num_col = 0;
    lastop = '\0';		/* Flag for "nothing has happened yet" */
}
