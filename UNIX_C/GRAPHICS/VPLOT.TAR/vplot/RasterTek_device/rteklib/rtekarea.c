/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./filters/rteklib/rtekarea.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

/* not used because POLYGON command defective */
#include "rtekpen.h"
#include "../include/vertex.h"

rtekarea (npts, head)
    int             npts;
    struct vertex  *head;
{
int             i, x, y;

    x = head->x;
    y = head->y;
/*
	rtekplot (x,y,0);
*/
    CHKLEN (8 + npts << 2);	/* cmdlen = 8+npts*4 */
    byte (PRMFIL);
    byte (1);
    byte (POLYGN);
    byte (1);
    word (npts);
    for (i = 0; i < npts; i++)
    {
	word (head->x - x);
	word (head->y - y);
	head = head->next;
    }
    byte (PRMFIL);
    byte (0);
}
