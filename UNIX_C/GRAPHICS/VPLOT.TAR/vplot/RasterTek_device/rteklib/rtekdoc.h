char *documentation[] = {
"NAME",
#ifdef SEP
"	Rpen - SEPLIB vplot filter for Raster Tech",
#else
"	rpen - vplot filter for Raster Tech",
#endif
"",
"SYNOPSIS",
#ifdef SEP
"	Rpen [options] in=vplot-input file OR header file OR stdin",
#else
"	rpen [options] [inputfiles]",
#endif
"",
"OPTIONS",
"	block=[s,m,l]   small,medium,or large dma block size",
#include "../include/gendoc.h",
"",
"SEE ALSO",
"	man pen"
};
int doclength = {sizeof documentation/sizeof documentation[0]};
