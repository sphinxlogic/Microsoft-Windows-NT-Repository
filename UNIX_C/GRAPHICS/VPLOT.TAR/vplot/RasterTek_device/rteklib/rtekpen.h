#include <stdio.h>
#include "../include/enum.h"
#include "../include/err.h"
#include "../include/extern.h"

#define RTEKDEV		"/dev/dm0"

/* global variables */
extern FILE *rtekfd;
extern int dev_xmin, dev_xmax;
extern int dev_ymin, dev_ymax;
extern int color;

/* Raster Tech - stdio macro */
#define CHKLEN(cmdlen)	(((rtekfd->_cnt) < (cmdlen)) ? rtek_flsbuf(cmdlen) : 0 )


/* Raster Tech command codes */
#define CLOAD		160
#define CMOVE		161
#define	DRWABS		129
#define	FLOOD		7
#define	GRAPHICS	4
#define	LUT8		28
#define MODDIS		44
#define	MOVABS		1
#define	NOP		0
#define	PIXEL8		41
#define PIXFUN		59
#define	PIXMOV		187
#define	POINT		136
#define	POLYGN		18
#define	PRMFIL		31
#define	QUIT		255
#define	RDMODE		211
#define	READCR		152
#define	SCRORG		54
#define	VAL8		134
#define	WINDOW		58
#define	WMSK16		68
#define	ZOOM		52
