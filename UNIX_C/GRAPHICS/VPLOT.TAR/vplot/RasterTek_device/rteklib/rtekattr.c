/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./filters/rteklib/rtekattr.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#include "rtekpen.h"
#include "../include/attrcom.h"

int             color = 7;

rtekattributes (command, v, v1, v2, v3)
    int             command, v, v1, v2, v3;
{
    switch (command)
    {
    case SET_COLOR:		/* cmdlen = 2 */
	CHKLEN (2);
	color = v;
	byte (VAL8);
	byte (v);
	break;
    case SET_COLOR_TABLE:	/* cmdlen = 5 */
	CHKLEN (5);
	byte (LUT8);
	byte (v);
	byte (v1);
	byte (v2);
	byte (v3);
	break;
    case SET_WINDOW:		/* cmdlen = 9 */
	CHKLEN (9);
	byte (WINDOW);
	word (v);
	word (v1);
	word (v2);
	word (v3);
	break;
    }

    return 0;
}
