/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./filters/rteklib/rtekgetpoint.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

#include "rtekpen.h"

rtekgetpoint (termout, x, y)
    FILE           *termout;
    int            *x, *y;
{
char            buf[4];
    CHKLEN (2);
    byte (READCR);
    byte (2);
    fflush (rtekfd);
    read (fileno (rtekfd), buf, 4);
    *x = (char) buf[1] << 8 + (unsigned char) buf[0];
    *y = (char) buf[3] << 8 + (unsigned char) buf[2];
}
