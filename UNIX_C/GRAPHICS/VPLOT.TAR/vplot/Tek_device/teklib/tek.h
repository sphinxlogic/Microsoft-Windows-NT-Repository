/*
 * special characters for tek4010
 */
#define	ESC	033
#define	FF	014
#define	GS	035
#define	US	037
#define	FS	034

/*
 * tek modes
 */
#define	ALPHA	1	/* Alpha mode */
#define	VECTOR	2	/* Vector mode */
#define	POINT	3	/* Point plot mode */

/*
 * device level variables
 */
extern int lost;			/* used by genvector */
extern int messagecount;
extern int tekmode;
