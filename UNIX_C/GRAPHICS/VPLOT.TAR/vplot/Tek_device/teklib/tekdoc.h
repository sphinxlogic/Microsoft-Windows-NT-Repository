char *documentation[] = {
" ",
"NAME",
#ifdef SEP
"    Tekpen - SEPlib vplot filter for tektronix 4010,4012,4014 terminals",
#else
"    tekpen - vplot filter for tektronix 4010,4012,4014 terminals",
#endif
" ",
"SYNOPSIS",
#ifdef SEP
"    Tek[pen] [options] in=vplot-inputfile OR headerfile on standard in",
#else 
"    tek[pen] [options] [inputfiles]",
#endif
" ",
"OPTIONS",
#include "../include/gendoc.h"
" ",
"SEE ALSO",
"    man pen"
};
int	doclength = { sizeof documentation/sizeof documentation[0] };
