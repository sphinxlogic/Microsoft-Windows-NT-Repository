/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./filters/teklib/tekmessage.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

/*
 * Device dependent subroutine to handle message operations
 */
#include	<stdio.h>
#include	"tek.h"
#include	"../include/mesgcom.h"
#include	"../include/enum.h"
extern FILE    *pltout;

int             messagecount = 0;

tekmessage (command, string)
    int             command;
    char            string[];
{
register int    i;

    switch (command)
    {
    case MESG_HOME:
    case MESG_READY:
	setmode (VECTOR);
	tekxypack (0, 773);
	setmode (ALPHA);
	for (i = messagecount; i > 0; i--)
	    fprintf (pltout, "\n");
	lost = YES;
	fflush (pltout);
	break;
    case MESG_TEXT:
	fprintf (pltout, "%s", string);
	messagecount++;
	lost = YES;
	break;
    case MESG_ON:
    case MESG_OFF:
    case MESG_ERASE:
    case MESG_HIGHLIGHT_ON:
    case MESG_HIGHLIGHT_OFF:
    case MESG_DONE:
    default:
	fflush (pltout);
	break;
    }
}
