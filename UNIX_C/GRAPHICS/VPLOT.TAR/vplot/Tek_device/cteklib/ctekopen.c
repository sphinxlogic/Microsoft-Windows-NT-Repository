/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./filters/cteklib/ctekopen.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

/*
 * Device open routine
 */
#include <stdio.h>
#include "../include/enum.h"
#include "../include/extern.h"

ctekopen ()
{
/*
 * physical device parameters
 */
    dev_xmax = 479;
    dev_ymax = 359;
    dev_xmin = 0;
    dev_ymin = 0;
    pixels_per_inch = 52.;
    aspect_ratio = 1.05;
    num_col = 8;

/*
 * device capabilities
 */
    need_end_erase = NO;
    buffer_output = YES;
    smart_clip = NO;
    endpause = YES;
}
