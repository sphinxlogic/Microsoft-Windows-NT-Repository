/*
 * Copyright 1987 the Board of Trustees of the Leland Stanford Junior
 * University. Official permission to use this software is included in
 * the documentation. It authorizes you to use this file for any
 * non-commercial purpose, provided that this copyright notice is not
 * removed and that any modifications made to this file are commented
 * and dated in the style of my example below.
 */

/*
 *
 *  source file:   ./filters/cteklib/ctekcolmap.c
 *
 * Joe Dellinger (SEP), June 11 1987
 *	Inserted this sample edit history entry.
 *	Please log any further modifications made to this file:
 */

ctekcolmap (color)
    int             color;
{
register int    c;

    switch (color)
    {
    case 0:
	c = 0;
	break;
    case 1:
	c = 4;
	break;
    case 2:
	c = 2;
	break;
    case 3:
	c = 6;
	break;
    case 4:
	c = 3;
	break;
    case 5:
	c = 5;
	break;
    case 6:
	c = 7;
	break;
    case 7:
	c = 1;
	break;
    default:
	c = 1;
    }
    return c;
}
