char *documentation[] = {
" ",
"NAME",
#ifdef SEP
"    Ctekpen - SEPlib vplot filter for Tektronix 4105 terminals",
#else
"    ctekpen - vplot filter for Tektronix 4105 terminals",
#endif
" ",
"SYNOPSIS",
#ifdef SEP
"    Ctek[pen] [options] in=vplot-inputfile OR headerfile on standard in",
#else 
"    ctek[pen] [options] [inputfiles]",
#endif
" ",
"OPTIONS",
#ifdef SEP
"    Ctekpen-specific options:",
#else
"    ctekpen-specific options:",
#endif
"          bell=[y,n]      inform you the plot is done with a beep.",
#include "../include/gendoc.h"
" ",
"SEE ALSO",
"    man pen"
};
int	doclength = { sizeof documentation/sizeof documentation[0] };
