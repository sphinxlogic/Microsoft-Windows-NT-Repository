/*
 * Modes, macros for Tek 4105.
 */
#include	<stdio.h>
#define	ESC	033
#define	FF	014
#define	GS	035
#define	US	037
#define SB	032
#define	Putc(C)	putc(C, pltout)

#define	ANSI	0	/* ANSI mode */
#define	TEK	1	/* Tek, or Alpha mode */
#define	VECTOR	2	/* Vector mode */

/*
 * device level variables
 */
extern int lost;			/* used by genvector */
extern int messagecount;
extern int tekmode;

/* 
 * TEMP: should be global option
 */
extern int draw_border;
