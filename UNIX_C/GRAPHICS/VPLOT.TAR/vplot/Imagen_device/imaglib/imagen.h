#define SET_PUSH_MASK	214
#define PUSH		211
#define POP		212
#define SET_HV_SYSTEM	205
#define CREATE_PATH	230
#define ENDPAGE		219
#define SET_PEN		232
#define BITMAP		235
#define EOPLOT		255
#define DRAW_PATH	234
#define FILL_PATH	233
#define SET_ABS_V	137
#define SET_ABS_H	135
#define CREATE_FAMILY_TABLE	221
#define SET_ADV_DIRS	206
#define SET_FAMILY	207
#define SP		128
#define SET_SP		210
#define BGLY    199
#define SET_TEXTURE  231
#define SET_REL_V	138

#define WHITE		0
#define OPAQUE		3
#define OR		7
#define BLACK		15

#define PATHLENGTH	175

/*
 * These two macros take the high and low bytes off the end
 * of an integer to make a word that the imagen will understand
 * representing an integer in the range +- 2 to the 14
 */
#define lob(A) 	((char)((A) & 0xff))
#define hib(A)	((char)(((A) >> 8) & 0xff))

/*
 * imagen externals
 */
extern int tex;
extern int stripped;
extern int brute_force;
extern int file_created;
extern int ncopies_document;
extern char label[];
extern char scratch_file[];
extern char holdreason[];
extern int lost;
extern int imag_curcolor;
