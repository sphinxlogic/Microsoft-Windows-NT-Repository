char *documentation[] = {
" ",
"NAME",
#ifdef SEP
"    Imagpen - SEPlib vplot filter for Imagen 8/300 laser printer",
#else
"    imagpen - vplot filter for Imagen 8/300 laser printer",
#endif
" ",
"    output is in IMPRESS language, if not redirected, it is sent to ipr",
" ",
"SYNOPSIS",
#ifdef SEP
"    I[mag]pen [options] in=vplot-inputfile OR headerfile on standard in",
#else 
"    i[mag]pen [options] [inputfiles]",
#endif
" ",
"OPTIONS",
#ifdef SEP
"    Options unique to Imagpen:",
#else
"    Options unique to imagpen:",
#endif
"    paper=letter    If paper=legal, 8.5x14 inch paper in use",
"    label=string    Label pages with string.  If string=no, no label",
"                      default label is user name and date",
"    strip=no        If strip=y, then makes an IMPRESS output file",
"                      without document control language",
"    tex=no          If tex=y, then strip=y and rotate plot to correct",
"                      orientation for use with TEX",
"    brute=yes       If the imagen chops your plot up, make this yes",
"                      and pray to the gods of imagen (a little slower)",
"    hold=reason     Tells the imagen to not print the job until you",
"                      release it from the imagen console with \"rj\"",
"    ncopies=n       Requests multiple copies (works only if strip=no)",
#include "../include/gendoc.h"
"FILES",
"    scratch file /scr/tmp/Impress_XXXXXX, which it deletes",
"SEE ALSO",
"    man pen"
};
int	doclength = { sizeof documentation/sizeof documentation[0] };
