/*
 * This program has been written by Kannan Varadhan.  You are welcome to
 * use, copy, modify, or circulate as you please, provided you do not
 * charge any fee for any of it, and you do not remove these header
 * comments from any of these files.
 *
 *		-- kva	Mon Dec  4 11:26:37 EST 1989
 */

#include "bibc.h"

int	i;
#define	GET_USR_DEFNS						\
	for (i = 0; i != usr_defns_ctr; i++)			\
	  GET (&bibitem, usr_defns[i], OPTIONAL)

get_article ()

{
	SET (&bibitem, rectype, "ARTICLE");
	GET (&bibitem, citekey, REQUIRED);
	GET (&bibitem, author, REQUIRED);
	GET (&bibitem, title, REQUIRED);
	GET (&bibitem, journal, REQUIRED);
	GET (&bibitem, year, REQUIRED);
	GET (&bibitem, volume, OPTIONAL);
	GET (&bibitem, number, OPTIONAL);
	GET (&bibitem, pages, OPTIONAL);
	GET (&bibitem, month, OPTIONAL);
	GET (&bibitem, note, OPTIONAL);
	GET (&bibitem, key, OPTIONAL);
	GET (&bibitem, comment, OPTIONAL);
	GET (&bibitem, cross_ref, OPTIONAL);
	GET_USR_DEFNS;
	return 0;
}

get_book () 

{
	SET (&bibitem, rectype, "BOOK");
	GET (&bibitem, citekey, REQUIRED);
	GET (&bibitem, author, REQUIRED);
	GET (&bibitem, title, REQUIRED);
	GET (&bibitem, publisher, REQUIRED);
	GET (&bibitem, year, REQUIRED);
	GET (&bibitem, volume, OPTIONAL);
	GET (&bibitem, series, OPTIONAL);
	GET (&bibitem, address, OPTIONAL);
	GET (&bibitem, edition, OPTIONAL);
	GET (&bibitem, month, OPTIONAL);
	GET (&bibitem, note, OPTIONAL);
	GET (&bibitem, key, OPTIONAL);
	GET (&bibitem, comment, OPTIONAL);
	GET (&bibitem, cross_ref, OPTIONAL);
	GET_USR_DEFNS;
	return 0;
}

get_booklet () 

{
	SET (&bibitem, rectype, "BOOKLET");
	GET (&bibitem, citekey, REQUIRED);
	GET (&bibitem, title, REQUIRED);
	GET (&bibitem, author, OPTIONAL);
	GET (&bibitem, howpublished, OPTIONAL);
	GET (&bibitem, address, OPTIONAL);
	GET (&bibitem, month, OPTIONAL);
	GET (&bibitem, year, OPTIONAL);
	GET (&bibitem, note, OPTIONAL);
	GET (&bibitem, key, OPTIONAL);
	GET (&bibitem, comment, OPTIONAL);
	GET (&bibitem, cross_ref, OPTIONAL);
	GET_USR_DEFNS;
	return 0;
}


get_inproceedings ()

{
	SET (&bibitem, rectype, "INPROCEEDINGS");
	GET (&bibitem, citekey, REQUIRED);
	GET (&bibitem, author, REQUIRED);
	GET (&bibitem, title, REQUIRED);
	GET (&bibitem, booktitle, REQUIRED);
	GET (&bibitem, year, REQUIRED);
	GET (&bibitem, editor, OPTIONAL);
	GET (&bibitem, pages, OPTIONAL);
	GET (&bibitem, organisation, OPTIONAL);
	GET (&bibitem, publisher, OPTIONAL);
	GET (&bibitem, address, OPTIONAL);
	GET (&bibitem, month, OPTIONAL);
	GET (&bibitem, note, OPTIONAL);
	GET (&bibitem, key, OPTIONAL);
	GET (&bibitem, comment, OPTIONAL);
	GET (&bibitem, cross_ref, OPTIONAL);
	GET_USR_DEFNS;
	return 0;
}


get_inbook ()

{
	SET (&bibitem, rectype, "INBOOK");
	GET (&bibitem, citekey, REQUIRED);
	GET (&bibitem, author, REQUIRED);
	GET (&bibitem, title, REQUIRED);
	GET (&bibitem, chapter, REQUIRED);
	GET (&bibitem, pages, OPTIONAL);
	GET (&bibitem, publisher, REQUIRED);
	GET (&bibitem, year, REQUIRED);
	GET (&bibitem, volume, OPTIONAL);
	GET (&bibitem, series, OPTIONAL);
	GET (&bibitem, address, OPTIONAL);
	GET (&bibitem, edition, OPTIONAL);
	GET (&bibitem, month, OPTIONAL);
	GET (&bibitem, note, OPTIONAL);
	GET (&bibitem, key, OPTIONAL);
	GET (&bibitem, comment, OPTIONAL);
	GET (&bibitem, cross_ref, OPTIONAL);
	GET_USR_DEFNS;
	return 0;
}


get_incollection ()

{
	SET (&bibitem, rectype, "INCOLLECTION");
	GET (&bibitem, citekey, REQUIRED);
	GET (&bibitem, author, REQUIRED);
	GET (&bibitem, title, REQUIRED);
	GET (&bibitem, booktitle, REQUIRED);
	GET (&bibitem, publisher, REQUIRED);
	GET (&bibitem, year, REQUIRED);
	GET (&bibitem, editor, OPTIONAL);
	GET (&bibitem, chapter, OPTIONAL);
	GET (&bibitem, pages, OPTIONAL);
	GET (&bibitem, address, OPTIONAL);
	GET (&bibitem, month, OPTIONAL);
	GET (&bibitem, note, OPTIONAL);
	GET (&bibitem, key, OPTIONAL);
	GET (&bibitem, comment, OPTIONAL);
	GET (&bibitem, cross_ref, OPTIONAL);
	GET_USR_DEFNS;
	return 0;
}


get_manual ()

{
	SET (&bibitem, rectype, "MANUAL");
	GET (&bibitem, citekey, REQUIRED);
	GET (&bibitem, title, REQUIRED);
	GET (&bibitem, author, OPTIONAL);
	GET (&bibitem, organisation, OPTIONAL);
	GET (&bibitem, address, OPTIONAL);
	GET (&bibitem, edition, OPTIONAL);
	GET (&bibitem, month, OPTIONAL);
	GET (&bibitem, note, OPTIONAL);
	GET (&bibitem, key, OPTIONAL);
	GET (&bibitem, comment, OPTIONAL);
	GET (&bibitem, cross_ref, OPTIONAL);
	GET_USR_DEFNS;
	return 0;
}


get_mastersthesis ()

{
	SET (&bibitem, rectype, "MASTERSTHESIS");
	GET (&bibitem, citekey, REQUIRED);
	GET (&bibitem, author, REQUIRED);
	GET (&bibitem, title, REQUIRED);
	GET (&bibitem, school, REQUIRED);
	GET (&bibitem, year, REQUIRED);
	GET (&bibitem, address, OPTIONAL);
	GET (&bibitem, month, OPTIONAL);
	GET (&bibitem, note, OPTIONAL);
	GET (&bibitem, key, OPTIONAL);
	GET (&bibitem, comment, OPTIONAL);
	GET (&bibitem, cross_ref, OPTIONAL);
	GET_USR_DEFNS;
	return 0;
}


get_misc ()

{
	SET (&bibitem, rectype, "MISC");
	GET (&bibitem, citekey, REQUIRED);
	GET (&bibitem, author, OPTIONAL);
	GET (&bibitem, title, OPTIONAL);
	GET (&bibitem, howpublished, OPTIONAL);
	GET (&bibitem, month, OPTIONAL);
	GET (&bibitem, year, OPTIONAL);
	GET (&bibitem, note, OPTIONAL);
	GET (&bibitem, key, OPTIONAL);
	GET (&bibitem, comment, OPTIONAL);
	GET (&bibitem, cross_ref, OPTIONAL);
	GET_USR_DEFNS;
	return 0;
}


get_phdthesis ()

{
	SET (&bibitem, rectype, "PHDTHESIS");
	GET (&bibitem, citekey, REQUIRED);
	GET (&bibitem, author, REQUIRED);
	GET (&bibitem, title, REQUIRED);
	GET (&bibitem, school, REQUIRED);
	GET (&bibitem, year, REQUIRED);
	GET (&bibitem, address, OPTIONAL);
	GET (&bibitem, month, OPTIONAL);
	GET (&bibitem, note, OPTIONAL);
	GET (&bibitem, key, OPTIONAL);
	GET (&bibitem, comment, OPTIONAL);
	GET (&bibitem, cross_ref, OPTIONAL);
	GET_USR_DEFNS;
	return 0;
}


get_proceedings ()

{
	SET (&bibitem, rectype, "PROCEEDINGS");
	GET (&bibitem, citekey, REQUIRED);
	GET (&bibitem, title, REQUIRED);
	GET (&bibitem, year, REQUIRED);
	GET (&bibitem, editor, OPTIONAL);
	GET (&bibitem, publisher, OPTIONAL);
	GET (&bibitem, organisation, OPTIONAL);
	GET (&bibitem, address, OPTIONAL);
	GET (&bibitem, month, OPTIONAL);
	GET (&bibitem, note, OPTIONAL);
	GET (&bibitem, key, OPTIONAL);
	GET (&bibitem, comment, OPTIONAL);
	GET (&bibitem, cross_ref, OPTIONAL);
	GET_USR_DEFNS;
	return 0;
}


get_techreport ()

{
	SET (&bibitem, rectype, "TECHREPORT");
	GET (&bibitem, citekey, REQUIRED);
	GET (&bibitem, author, REQUIRED);
	GET (&bibitem, title, REQUIRED);
	GET (&bibitem, institution, REQUIRED);
	GET (&bibitem, year, REQUIRED);
	GET (&bibitem, type, OPTIONAL);
	GET (&bibitem, number, OPTIONAL);
	GET (&bibitem, address, OPTIONAL);
	GET (&bibitem, month, OPTIONAL);
	GET (&bibitem, note, OPTIONAL);
	GET (&bibitem, key, OPTIONAL);
	GET (&bibitem, comment, OPTIONAL);
	GET (&bibitem, cross_ref, OPTIONAL);
	GET_USR_DEFNS;
	return 0;
}


get_unpublished ()

{
	SET (&bibitem, rectype, "UNPUBLISHED");
	GET (&bibitem, citekey, REQUIRED);
	GET (&bibitem, author, REQUIRED);
	GET (&bibitem, title, REQUIRED);
	GET (&bibitem, note, REQUIRED);
	GET (&bibitem, month, OPTIONAL);
	GET (&bibitem, year, OPTIONAL);
	GET (&bibitem, key, OPTIONAL);
	GET (&bibitem, comment, OPTIONAL);
	GET (&bibitem, cross_ref, OPTIONAL);
	GET_USR_DEFNS;
	return 0;
}
