/*
 * This program has been written by Kannan Varadhan.  You are welcome to
 * use, copy, modify, or circulate as you please, provided you do not
 * charge any fee for any of it, and you do not remove these header
 * comments from any of these files.
 *
 *		-- kva	Mon Dec  4 11:26:37 EST 1989
 */

#include <strings.h>

#define Index		(char *) index
#define	Rindex		(char *) rindex
#define Strcpy		(void *) strcpy
#define Strncpy		(void *) strncpy
#define Strcat		(void *) strcat
#define Strncat		(void *) strncat
#define Strcmp		(int) strcmp
#define	Strlen		(int) strlen

#define	Sprintf		(void) sprintf
#define	Fprintf		(void) fprintf
