/*
 * This program has been written by Kannan Varadhan.  You are welcome to
 * use, copy, modify, or circulate as you please, provided you do not
 * charge any fee for any of it, and you do not remove these header
 * comments from any of these files.
 *
 *		-- kva	Mon Dec  4 11:26:37 EST 1989
 */

#define	GLOBALS
#include "bibcent.h"

#ifdef	SHBIB
#undef	RMBIB		/* why? God alone knows	*/
#endif

#ifdef	RMBIB
#define	PROGSTR	"rmbib"
#else
#define	PROGSTR	"shbib"
#endif

main (argc, argv)
int	argc;
char	*argv[];

{
extern	int	process_record(), onerror_cleanup();

	if (process_args (argc, argv) == -1)
	  return -1	/* EXIT */;
	regprog = (REGEXP *) REGCOMP (_O_regexp);
	
	(void) process_bibfiles (_O_flist, process_record, onerror_cleanup);

	(void) finish_up ();
	return 0;
}


finish_up ()

{
	if (store.isfull)
	  (void) output_record (store.filename, store.bibentry);

	if (_O_rem)
	  {
	  DASSERT (mytmpfile);
	  (void) restore_bakfile (_O_file, mytmpfile);
	  }
	return 0;
}


onerror_cleanup (rdfd)
int	rdfd;

{
FILE	*rdfp, *fdopen();
char	buffer[100];

	if (mytmpfile)
	  {
	  rdfp = fdopen (rdfd, "r");
	  while (fgets (buffer, sizeof(buffer), rdfp))
	    Fprintf (mytmpfile, buffer);
	  (void) restore_bakfile (_O_file, mytmpfile);
	  }

	return 0;
}


process_record (file, string)
char	*file, *string;

{
int	retcode = 0;
char	tmpfn[20];

	if (_O_file != file)
	  {
	  if (_O_rem)
	    {
	    (void) restore_bakfile (_O_file, mytmpfile);
	    Sprintf (tmpfn, "%s.bak", file);
	    mytmpfile = fopen (tmpfn, "w");
	    }
	  _O_file = file;
	  }

	if (REGMATCH (regprog, string) != 1)
	  {
	  STASH (string);
	  retcode = 0;
	  }
	else switch (_O_srch)
	  {
	  case FIRST_MATCH:
		if (output_record (_O_file, string) == -1)
		  break /* record was not processed...return normally */;
		retcode = -1;
		break;
	  case LAST_MATCH:
		if (store.isfull)
		  {
		  STASH (store.bibentry);
		  free (store.bibentry);
		  }
		store.isfull = TRUE;
		store.filename = _O_file;
		store.bibentry = (char *) replstr (string);
		break;
	  case GLOBAL_MATCH:
		(void) output_record (_O_file, string);
		break;
	  }
	return retcode;
}


process_args (argc, argv)
int	argc;
char	*argv[];

{
int	opt, count, i;
extern	char	*optarg;
extern	int	optind;
char	**temp;

	if (argc <= 1)
	  _O_help = TRUE;

	while ((opt = getopt (argc, argv, "fghilrs")) != EOF)
	  switch (opt) {
	    case 'f':
		_O_srch = FIRST_MATCH;
		break;
	    case 'g':	
		_O_srch = GLOBAL_MATCH;
		break;
	    case 'l':
		_O_srch = LAST_MATCH;
		break;
	    case 'h':
		_O_help = TRUE;
		break;
	    case 'r':
#ifndef	RMBIB
		_O_rem = TRUE;
#endif
		break;
	    case 'i':
#ifdef	RMBIB
		_O_inq = TRUE;
#endif
		break;
	    case 's':
		_O_silent = TRUE;
		break;
	    case '?':
	    default:
		_O_help = TRUE;
	    }
	
	if (_O_help)
	  {
	  (void) usage ();
	  return -1;
	  }
	
#ifdef	RMBIB
	_O_rem = TRUE;
#endif

	_O_regexp = argv[optind];
	_O_files = (char **) malloc ((unsigned) (sizeof(char *) * (argc - optind + 1)));
	if (_O_files == (char **) NULL)
	  {
	  perror (PROGSTR);
	  exit (-2);
	  }

	count = 0;
	temp = _O_flist = _O_files;
	for (i = ++optind; i < argc; i++)
	  {
	  *temp = argv[i];
	  temp++;
	  count++;
	  }
	*temp = (char *) NULL;
	if (! *_O_flist)
	  *_O_flist = "-"		/* stdin */;
	if (count <= 1) _O_silent = TRUE;
	store.isfull = FALSE;

	return 0;
}
	  

restore_bakfile (file, fptr)
char	*file;
FILE	*fptr;

{
char	tmpfn[20];

	if (! fptr)
	  return 0;

	fclose (fptr);
	Sprintf (tmpfn, "%s.bak", file);
	(void) rename (tmpfn, file);
	return 0;
}


usage ()

{
#ifndef	RMBIB
Fprintf (stderr, "usage: %s [-f] [-l] [-g] [-r] [-s] [-h] reg-expn file(s)\n",
			PROGSTR);
Fprintf (stderr, "\t-f\tGet first match only\n");
Fprintf (stderr, "\t-l\tGet last matching record only\n");
Fprintf (stderr, "\t-g\tGet all matches\n");
Fprintf (stderr, "\t-r\tDelete matching record\n");
Fprintf (stderr, "\t-s\tAct Silently, ie don't echo record to stdout\n");
Fprintf (stderr, "\t-h\tPrint this help\n");
#else
Fprintf (stderr, "usage: %s [-f] [-l] [-g] [-i] [-s] [-h] reg-expn file(s)\n",
			PROGSTR);
Fprintf (stderr, "\t-f\tDelete first matching record only\n");
Fprintf (stderr, "\t-l\tDelete last matching record only\n");
Fprintf (stderr, "\t-g\tDelete all matches\n");
Fprintf (stderr, "\t-i\tInquire before deleting record\n");
Fprintf (stderr, "\t-s\tAct Silently, ie don't echo record to stdout\n");
Fprintf (stderr, "\t-h\tPrint this help\n");
#endif
return 0;
}


output_record (file, record)
char	*file, *record;

{
	if (! _O_silent)
	  Fprintf (stdout, "%s:\n", file);
#ifdef	RMBIB
	if (_O_inq)
	  {
	  Fprintf (stderr, "%s\n", record);
	  if (answer ("remove? ", NO))
	    {
	    STASH (record);
	    return -1	/* deletion did not occur */;
	    }
	  else
	    Fprintf (stdout, "%s\n", record);
	  }
#else
	    Fprintf (stdout, "%s\n", record);
#endif
	return 0;
}
