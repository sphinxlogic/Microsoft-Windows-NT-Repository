/*
 * This program has been written by Kannan Varadhan.  You are welcome to
 * use, copy, modify, or circulate as you please, provided you do not
 * charge any fee for any of it, and you do not remove these header
 * comments from any of these files.
 *
 *		-- kva	Mon Dec  4 11:26:37 EST 1989
 */

/*
 * SAFE turns off the -pester flag by default, set it to TRUE unless
 * you have absolutely pained users like me, who think they know what
 * what they are doing....As to whether they (or I) actually know or
 * not is not the issue here, is it? :-)
 */
#ifndef SAFE
#define	SAFE	TRUE
#endif

/* maximum size of string a user is permitted to input		*/
#define	MAXLEN		391

/* The number of fields a user can define for himself...	*/
#define	USR_DEFNS_MAX	5

/* hmmm..... 							*/
#define	DEFAULT_EDITOR	"/usr/ucb/vi"

/*
 * If a user defines his own fields, but no help prompts, this is 
 * What I'd say	... ;-)
 */
#define	DEFAULT_USERHLP	"You asked for it, buster, so you figure it out..."

/*
 * bibv definitions
 */
/* style file to use for bibv					*/
#define	STYLE	"specl"

/* locations of latex and bibtex				*/
#define	LATEX	"/usr/local/bin/latex"
#define	BIBTEX	"/usr/local/bin/bibtex"

/* wait4() equivalent, if you don't have it			*/
#define	wait4(PID,STATUS,OPTS,RUSAGE)	wait3 (STATUS, OPTS, RUSAGE) /* sigh */

/* Name of file output by bibv					*/
#define	OUTFILE		"bibtex"

/*
 * REGULAR EXPRESSION HANDLING
 *
 * entry handling routines only, shent and rment
 */

#define	BUFSIZE	8000
#define	RECSIZE	 800

#define	NOCASE	/* Perform caseless regular expression matching	*/
/*
 * Caseless regular expression matching is done simply by converting
 * all strings to lower case, and then performing the comparison.
 */

/*
 * There are three defines
 *	REGEXP		defines type of regular expression
 *	REGCOMP		compile the r. e. into one of type REGEXP
 *	REGMATCH	it to perform the match
 */
#define	REGEXP	regexp

#ifdef	NOCASE
#define	REGCOMP		my_rcomp
#define	REGMATCH	my_rexec
#else
#define	REGCOMP		regcomp
#define	REGMATCH	regexec
#endif


/*
 * What routine to use for gets().  gets() has flaws in it's handling.
 * I prefer to simulate gets() functionality using my_gets(), in gets.c
 *
 * If you don't trust it, you could use, gets() directly.
 */

/*#define	GETS(BUFF,SIZE)	gets (BUFF)		/* Rather not	*/
#define	GETS(BUFF,SIZE)	my_gets (BUFF, SIZE)		/* preferred	*/
