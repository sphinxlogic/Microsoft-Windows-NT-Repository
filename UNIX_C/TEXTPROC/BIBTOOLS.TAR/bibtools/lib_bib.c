/*
 * This program has been written by Kannan Varadhan.  You are welcome to
 * use, copy, modify, or circulate as you please, provided you do not
 * charge any fee for any of it, and you do not remove these header
 * comments from any of these files.
 *
 *		-- kva	Mon Dec  4 11:26:37 EST 1989
 */

#include	"includes.h"

char	*curfile;
char	**bibflist;
char	*get_atsign();

char	*
my_gets (buffer, size)
/*
 * This is an emulation of gets() using fgets.3
 * This routine reads everything upto a newline, using fgets.3
 * 
 * OUTPUT: Returns buffer on exit, (char *) NULL on error
 * The contents of buffer are the input string, a max of (size -1)
 * characters are filled on exit,
 * The buffer is zeroed and returned on EOF.
 *
 * This routine only deals with EOF as an error cleanly.  On any other 
 * error returned by fgets.3, this routine will return will return
 * (char *) NULL and a partially filled buffer....*sigh*
 *
 * if EMUL_GETS is turned on, (it probably should, neh? :-) then
 * it converts any trailing NEWLINE character ('\n') to a NIL ('\0')
 * character, else, it leaves them alone
 */
char	*buffer;
int	size;

#ifdef BUFSIZE
#undef BUFSIZE
#endif
#define	BUFSIZE	512
#define	EMUL_GETS

{
int	sizeleft, cursize;
char	lbuf[BUFSIZE];	/* These figures are unimportant...leave well alone */
char	*foo, *answer;
int	done;

	sizeleft = size - 1;
	bzero (buffer, size);
	answer = buffer;
	done = 0;

	while (done != 1)
	  {
	  if (fgets (lbuf, BUFSIZE, stdin) == (char *) NULL)
	    {
	    done = 1	/* EOF or ERROR	*/	;
	    answer = (char *) NULL;
	    }
	  else if ((foo = Index (lbuf, '\n')) != (char *) NULL)
	    {			/* DONE */
	    if (sizeleft > 0)
	      Strncat (answer, lbuf, sizeleft);
	    done = 1;
	    }
	  else if (sizeleft > 0)
	    {			/* COPY	*/
	    cursize = strlen (lbuf);
	    if (cursize <= sizeleft)
	      {
	      Strncat (answer, lbuf, cursize);
	      sizeleft -= cursize;
	      }
	    else
	      {
	      Strncat (answer, lbuf, sizeleft);
	      sizeleft = 0;
	      }
	    }
	  }

#ifdef EMUL_GETS
	if ((foo = Index (answer, '\n')) != (char *) NULL)
	  *foo = '\0';
#endif
	return answer;
}


answer (string, resp)
/*
 * Display string, query user....return TRUE if answer = resp
 */
char	*string;
char	resp;

{
char	buff[5];

	Fprintf (stderr, "%s [%c|%c] ", string, YES, NO);
	fflush (stderr);
	(void) GETS (buff, 5);
	return ((*buff == resp) ? TRUE : FALSE );
}


process_bibfiles (files, process_recd, onerror)
/*
 * For each file in files, 
 *	delineate_next_record
 *	process_record (file, record);
 *		if process_record() indicates error,
 *			onerror (open_file_descriptor);
 *			lseek to EOF
 *			cause exit()
 */
char	**files;
int	(*process_recd)(), (*onerror)();

{
char	*delineate_recd();
int	rdfd1;
char	buffer[BUFSIZE+2], excess[RECSIZE], wkbuf[BUFSIZE + RECSIZE];
int	done, cc;
char	*start, *next;

	done = FALSE;
	bibflist = files;
	rdfd1 = -1;

	Strcpy (excess, "");
	while (! done)
	  {
	  bzero (buffer, sizeof(buffer));
	  if ((cc = read (rdfd1, buffer, BUFSIZE)) <=0)
	    {
	    if ((rdfd1 = get_next_file (rdfd1)) <= 0)
	      done = TRUE;
	    DASSERT (*excess == '\0');
	    continue;
	    }
	  Strcpy (wkbuf, excess);
	  Strncat (wkbuf, buffer, cc);
	  start = wkbuf;
	  while ((next = delineate_recd (start)) != (char *) NULL)
	    {
	    if ((*process_recd) (curfile, start) < 0)
	      {
	      (void) lseek (rdfd1, (long) (-1 * Strlen(next)), L_INCR);
	      if (onerror)
	        (*onerror) (rdfd1);
	      (void) lseek (rdfd1, 0L, L_XTND);
	      next = (char *) NULL;
	      done = TRUE;	/* Abort; go to final cleanup, if any	*/
	      }
	    start = next;
	    }
	  Strcpy (excess, (start ? start : ""));
	  }
	return 0;
}


get_next_file (curfd)
/*
 * Close current file descriptor;
 * get next bib file from bibflist
 * open file, and return new file descriptor;
 */
int	curfd;

{
int	retfd;

	close (curfd);
	curfile = *bibflist++;
	if (! curfile)
	  retfd = -1;
	else if (Strcmp (curfile, "-") == SAME)
	  retfd = 0	/* stdin */;
	else
	  retfd = open (curfile, O_RDONLY);
	
	return retfd;
}


char	*
lcase (string)
/*
 * Lower case the given string
 */
char	*string;

{
char	*str, c;

	for (str = string ; *str; str++)
	  if (isupper (*str))
	    {
	    c = tolower (*str);	/* I dunno, just being paranoid, I guess */
	    *str = c;
	    }
	return string;
}


char	*
replstr (str)
/*
 * replicate the given string.  get storage, and return the new string.
 */
char	*str;

{
char	*temp, *malloc();

	temp = (char *) malloc ((unsigned) (Strlen (str) + 1));
	Strcpy (temp, str);
	return temp;
}


char	*
delineate_recd (string)
/*
 * Get next record, using '\n@' as a flag per record.
 * Match all braces, 
 * If record found, delineate current record by placing '\0' at end of
 *	current record, and return address of next record.
 * else return (char *) NULL;
 */
char	*string;

{
char	*atsign, *start, *end;
char	acount;

	if ((! string) || (! *string))
	  return (char *) NULL;

	start = Index (string, '@') + 1;
	end = (char *) NULL;
	atsign = get_atsign (start);
	if (atsign)
	  *atsign = '\0';

	acount = strcount (start, OPEN_BRACE);
	if (acount && (acount == strcount (start, CLOSE_BRACE)))
	  {
	  end = Rindex (start, CLOSE_BRACE) + 1;
	  *end = '\0';
	  if (atsign)
	    {
	    *atsign = '@';
	    end = atsign;
	    }
	  }
	else
	  {
	  DASSERT (atsign == (char *) NULL);
	  }
	return end;
}

strcount (str, c)
/*
 * Count the number of occurences of character 'c' in string "str"
 */
char	*str;
char	c;

{
char	*temp;
int	count;

	temp = str;
	count = 0;

	while (temp = Index (temp +1, c))
	  count++;
	
	return count;
}


char	*
get_atsign (str)
/*
 * Get an atsign, check if it is preceeded by a newline
 *	If yes, return value,
 *	else repeat search
 */
char	*str;

{
char	*answer;

	answer = str;
	while (answer = Index (answer, '@'))
	  if (*(answer-1) == '\n')
	    return answer;
	  else
	    answer++;
	return answer;
}


#ifdef	NOCASE
REGEXP	*
my_rcomp (re)
/*
 * STRATEGY: lcase the string inplace, and feed to regcomp(), return the
 * value returned as is...
 */
char	*re;

{
	return regcomp (lcase (re));
}


my_rexec (prog, str)
regexp	*prog;
/*
 * my_rexec = TRUE, if lcase (copy of str) contains given re
 *	    = FALSE otherwise.
 */
char	*str;

{
char	*temp;
int	retval;

	temp = (char *) replstr (str);
	(void) lcase (temp);
	retval = regexec (prog, temp);
	free (temp);
	return retval;
}
#endif NOCASE

