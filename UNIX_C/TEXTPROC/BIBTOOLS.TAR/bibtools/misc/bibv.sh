#! /bin/sh

FN=`basename $0`

case $# in
0)	echo "$FN: Usage: bibv [-style style-to-use] [ <filename> ... ]"
	exit
	;;
esac

STYLE=specl
case $1 in
"-style")	STYLE=$2; shift ; shift ;;
esac

case $# in
0)	echo "$FN: Usage: bibv [-style style-to-use] [ <filename> ... ]"
	exit
	;;
esac


FILE=bibtex
BIBFILE=${FILE}.bib
TEXFILE=${FILE}.tex
TMPFIL1=sysut1.$$

trap 'rm -f ${FILE}.bbl ${FILE}.aux ${FILE}.log ${FILE}.blg $TMPFIL1 ; exit' \
						1 2 3 15

KEYS="@ARTI|@BOOK|@CONF|@INBO|@INCO|@INPR|@MANU|@MAST|@MISC|@PHDT|@PROC|@TECH|@UNPU"

> $TEXFILE
> ${FILE}.bbl
> ${FILE}.aux
> ${FILE}.log
> ${FILE}.blg
> $TMPFIL1

echo "\documentstyle{article}"				>> $TEXFILE
echo "\begin{document}"					>> $TEXFILE
echo "\bibliographystyle{$STYLE}"			>> $TEXFILE
echo "\title{Verifying Biblio files}"			>> $TEXFILE
echo "\author{$USER}"					>> $TEXFILE
echo "\date{\today}"					>> $TEXFILE
echo "\maketitle"					>> $TEXFILE
echo ""							>> $TEXFILE
echo ""							>> $TEXFILE

BIBRECD=""
for i
do
	file="`echo $i | sed 's/\.bib//'`"
	bibfile=${file}.bib
	echo "\section{FILE $bibfile}"			>> $TEXFILE
	BIBRECD="${BIBRECD},${file}"
	RECS=`tr [a-z] [A-Z] < $bibfile | egrep $KEYS | wc -l`
	echo FILE $bibfile has $RECS records
	sed -n '/^@s/d ; /^@S/d ; /^@.*{[ 	]*\(.*\)[, 	]*/\\cite {\1}/p' $bibfile >> $TMPFIL1
#	echo "%"					>> $TMPFIL1
#	echo "%	$bibfile"				>> $TMPFIL1
#	echo "%"					>> $TMPFIL1
# This is not the exact sed expression to be used, but works in
# most cases...it is left as commented LaTeX output for convenience...
#	sed -n 's/^@.*{[ 	]*\(.*\)/%\\nocite {\1}/p' $bibfile  |
#		sed 's/[, 	]//g' >> $TMPFIL1

done
BIBRECD="`echo $BIBRECD | sed 's/,//'`"

echo "\bibliography{$BIBRECD}"				>> $TEXFILE
cat $TMPFIL1						>> $TEXFILE
echo ""							>> $TEXFILE
echo "\nocite{*}"					>> $TEXFILE
echo ""							>> $TEXFILE
echo "\end{document}"					>> $TEXFILE
exit

# Do this run silently....
latex  $FILE	2>&- 1>&- </dev/null || {
	echo "$FN: cannot run latex, see yah"
	rm -f ${FILE}.bbl ${FILE}.aux ${FILE}.log ${FILE}.blg $TMPFIL1
	exit
	}

bibtex $FILE
latex  $FILE	< /dev/null

# Cleanup...
rm -f ${FILE}.bbl ${FILE}.aux ${FILE}.log ${FILE}.blg $TMPFIL1

echo "Now print out ${FILE}.dvi to see a hardcopy..."

exit
