/* ugh...I know of no better way..*sigh* 	*/
#ifndef FILE
#include <stdio.h>
#endif
#include "strings.h"

char	*
my_gets (buffer, size)
char	*buffer;
int	size;

/*
 * This is an emulation of gets() using fgets.3
 * This routine reads everything upto a newline, using fgets.3
 * 
 * OUTPUT: Returns buffer on exit, (char *) NULL on error
 * The contents of buffer are the input string, a max of (size -1)
 * characters are filled on exit,
 * The buffer is zeroed and returned on EOF.
 *
 * This routine only deals with EOF as an error cleanly.  On any other 
 * error returned by fgets.3, this routine will return will return
 * (char *) NULL and a partially filled buffer....*sigh*
 *
 * if EMUL_GETS is turned on, (it probably should, neh? :-) then
 * it converts any trailing NEWLINE character ('\n') to a NIL ('\0')
 * character, else, it leaves them alone
 */

#ifdef BUFSIZE
#undef BUFSIZE
#endif
#define	BUFSIZE	512
#define	EMUL_GETS

{
int	sizeleft, cursize;
char	lbuf[BUFSIZE];	/* These figures are unimportant...leave well alone */
char	*foo, *answer;
int	done;

	sizeleft = size - 1;
	bzero (buffer, size);
	answer = buffer;
	done = 0;

	while (done != 1)
	  {
	  if (fgets (lbuf, BUFSIZE, stdin) == (char *) NULL)
	    {
	    done = 1	/* EOF or ERROR	*/	;
	    answer = (char *) NULL;
	    }
	  else if ((foo = Index (lbuf, '\n')) != (char *) NULL)
	    {			/* DONE */
	    if (sizeleft > 0)
	      strncat (buffer, lbuf, sizeleft);
	    done = 1;
	    }
	  else if (sizeleft > 0)
	    {			/* COPY	*/
	    cursize = strlen (lbuf);
	    if (cursize <= sizeleft)
	      {
	      strncat (buffer, lbuf, cursize);
	      sizeleft -= cursize;
	      }
	    else
	      {
	      strncat (buffer, lbuf, sizeleft);
	      sizeleft = 0;
	      }
	    }
	  }

#ifdef EMUL_GETS
	if ((foo = Index (buffer, '\n')) != (char *) NULL)
	  *foo = '\0';
#endif
	return answer;
}
