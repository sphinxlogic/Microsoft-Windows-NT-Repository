/*
 * This program has been written by Kannan Varadhan.  You are welcome to
 * use, copy, modify, or circulate as you please, provided you do not
 * charge any fee for any of it, and you do not remove these header
 * comments from any of these files.
 *
 *		-- kva	Mon Dec  4 11:26:37 EST 1989
 */

#include	"includes.h"

#define	OPTIONAL	FALSE
#define	REQUIRED	TRUE

#define	FLD_ERROR		-1
#define	FLD_NULL	0x0000
#define	ARTICLE		0x0001
#define	BOOK		0x0002
#define	BOOKLET		0x0004
#define	CONFERENCE	0x0008
#define	INBOOK		0x0010
#define	INCOLLECTION	0x0020
#define	INPROCEEDINGS	0x0040
#define	MANUAL		0x0080
#define	MASTERSTHESIS	0x0100
#define	MISC		0x0200
#define	PHDTHESIS	0x0400
#define	PROCEEDINGS	0x0800
#define	TECHREPORT	0x1000
#define	UNPUBLISHED	0x2000
#define	FLD_EDITOR	0x4000

#define	GET(VAR,FIELD,STATUS)			\
	if (get_field (&(VAR)->FIELD, ISVAL(VAR, rectype), STATUS) == -1)\
		return -1 
#define	SET(VAR,FIELD,VALUE)	{			\
		Strcpy ((VAR)->FIELD.string, VALUE);	\
		(VAR)->FIELD.full = TRUE;		\
		}
#define	RESET(VAR,FIELD)	{			\
		Strcpy ((VAR)->FIELD.string, "");	\
		(VAR)->FIELD.full = FALSE;		\
		}
#define	ISSET(VAR,FIELD)	(VAR)->FIELD.full
#define	ISVAL(VAR,FIELD)	(VAR)->FIELD.string
#define	ISHELP(VAR,FIELD)	(VAR)->FIELD.helpstring
typedef	struct	record	{
	char	full	/* Actually holds a boolean place value	*/;
	char	string[391]	/* An even 32 words / field	*/;
	char	prompt[32];
	char	helpstring[344]	/* Display if user is confused	*/;
	}	field;

typedef	struct	biblio_record	{
	field	rectype;
	field	citekey;
	field	address;
	field	annote;
	field	author;
	field	booktitle;
	field	chapter;
	field	edition;
	field	editor;
	field	howpublished;
	field	institution;
	field	journal;
	field	key;
	field	month;
	field	note;
	field	number;
	field	organisation;
	field	pages;
	field	publisher;
	field	school;
	field	series;
	field	title;
	field	type;
	field	volume;
	field	year;
	field	comment;
	field	cross_ref;
	field	usr_defns[USR_DEFNS_MAX];
	}	bibrec;

DCL (char, _O_help, FALSE);
DCL (char, _O_verify, FALSE);
DCL (char, _O_verbose, TRUE);
DCL (FILE, *outfile, stdout);
DCL (char, _O_outfilename[50], "");
DCL (char, _O_pester_usr, SAFE);

DCLX (bibrec, bibitem);
DCL (int, usr_defns_ctr, 0);


