/*
 * This program has been written by Kannan Varadhan.  You are welcome to
 * use, copy, modify, or circulate as you please, provided you do not
 * charge any fee for any of it, and you do not remove these header
 * comments from any of these files.
 *
 *		-- kva	Mon Dec  4 11:26:37 EST 1989
 */

#include	"includes.h"
#include	<pwd.h>

#define	PROGSTR	"bibv"

REGEXP	*REGCOMP();

DCLX (char, **_O_files);
DCLX (char, **_O_flist);
DCL  (char, *_O_file, (char *) NULL);
DCL  (char, *bibrecd, (char *) NULL);
DCL  (char, *style, STYLE);
DCLX (struct passwd, *pwentry);
DCLX (char, *userid);
DCL  (int, ctr, 0);

DCLX (REGEXP, *regprog);
DCLX (FILE, *texfile);

DCL  (char, _O_help, FALSE);

#define	PREAMBLE	"\\documentstyle{article}\n\
\\begin{document}\n\
\\bibliographystyle{%s}\n\
\\title{Verifying Biblio files}\n\
\\author{%s}\n\
\\date{\\today}\n\
\\maketitle\n"

#define	SECTIONHDR	"\\section{FILE %s}\n\nCiting:\n"
#define	CITE	"\\cite {%s}\n"
#define	COMMENTS	"\
%\n\
% This is a sample tex file sillustrating, and verifying all the bib\n\
% bib entries you have in the bib files you have specified.\n\
%"

#define	EPILOGUE	"\\bibliography{%s}\n\\end{document}"

#define	KEYS	"@arti|@book|@conf|@inbo|@inco|@inpr|@manu|@mast|@misc|@phdt|@proc|@tech|@unpu"
