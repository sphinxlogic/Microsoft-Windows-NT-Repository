/*
 * This program has been written by Kannan Varadhan.  You are welcome to
 * use, copy, modify, or circulate as you please, provided you do not
 * charge any fee for any of it, and you do not remove these header
 * comments from any of these files.
 *
 *		-- kva	Mon Dec  4 11:26:37 EST 1989
 */

#include	"includes.h"

#define	FIRST_MATCH	1		/* -f flag, the default	*/
#define	GLOBAL_MATCH	2		/* -g flag	*/
#define	LAST_MATCH	4		/* -l flag	*/

REGEXP	*REGCOMP();

typedef	struct	recd	{
	int	isfull;
	char	*filename;
	char	*bibentry;
	}	record;

DCL (char, _O_srch, FIRST_MATCH);
DCL (char, _O_rem, FALSE);		/* -r flag, shent only	*/
#ifdef	RMBIB
DCL (char, _O_inq, FALSE);		/* -i flag, rment only	*/
#endif
DCL (char, _O_silent, FALSE);		/* -s flag, shent only	*/
DCL (char, _O_help, FALSE);		/* -h flag	*/

DCLX (char, **_O_files);
DCLX (char, **_O_flist);
DCL  (char , *_O_file, (char *) NULL);
DCL (char, *_O_regexp, (char *) NULL);

DCLX (REGEXP, *regprog);
DCLX (FILE, *mytmpfile);

DCLX (record, store);

#ifdef RMBIB
#define	STASH(str)	fprintf (mytmpfile, "%s\n", str)
#else
#define	STASH(str)	if (mytmpfile) fprintf (mytmpfile, "%s\n", str)
#endif
