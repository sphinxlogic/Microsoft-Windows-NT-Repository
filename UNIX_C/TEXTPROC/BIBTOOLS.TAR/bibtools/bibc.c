/*
 * This program has been written by Kannan Varadhan.  You are welcome to
 * use, copy, modify, or circulate as you please, provided you do not
 * charge any fee for any of it, and you do not remove these header
 * comments from any of these files.
 *
 *		-- kva	Mon Dec  4 11:26:37 EST 1989
 */

#define	GLOBALS
#include "bibc.h"

main (argc, argv, envp)
int	argc;
char	**argv, **envp;

{
int	retval;

	retval = FLD_NULL;

	(void) process_args (argc, argv);
	(void) initialise (&bibitem);

	while (retval = my_yylex()) {
	  switch (retval) {
	    case FLD_ERROR:	Fprintf (stderr, "Uh oh! no no no\n");
				continue;
	    case ARTICLE:	retval = get_article ();	break;
	    case BOOK:		retval = get_book ();		break;
	    case BOOKLET:	retval = get_booklet ();	break;
	    case CONFERENCE:	retval = get_inproceedings ();	break;
	    case INBOOK:	retval = get_inbook ();		break;
	    case INCOLLECTION:	retval = get_incollection ();	break;
	    case INPROCEEDINGS:	retval = get_inproceedings ();	break;
	    case MANUAL:	retval = get_manual ();		break;
	    case MASTERSTHESIS:	retval = get_mastersthesis ();	break;
	    case MISC:		retval = get_misc ();		break;
	    case PHDTHESIS:	retval = get_phdthesis ();	break;
	    case PROCEEDINGS:	retval = get_proceedings ();	break;
	    case TECHREPORT:	retval = get_techreport ();	break;
	    case UNPUBLISHED:	retval = get_unpublished ();	break;
	    case FLD_EDITOR:	retval = edit (outfile, _O_outfilename, envp); break;
	    }
	  if (retval != -1)
	    (void) writeout (&bibitem, outfile);
	  (void) resetall (&bibitem);
	  }
	fclose (outfile);
	return 0;
}

writeout (bi, outfile)
bibrec	*bi;
FILE	*outfile;

{
#define	PUT(VAR,REC)							\
	if (ISSET (VAR,REC))						\
	  {								\
	  if (Index (ISVAL(VAR,REC), QUOTE_CHAR))			\
	    { tmp1 = OPEN_BRACE; tmp2 = CLOSE_BRACE ; }			\
	  else if (ISVAL(VAR,REC)[0] == '\\')				\
	    {								\
	    tmp1 = tmp2 = ' ';						\
	    ISVAL(VAR,REC)[0] = ' ';					\
	    }								\
	  else								\
	    tmp1 = tmp2 = QUOTE_CHAR;					\
	  Sprintf (recordbuf, "%s ,\n\t%s = %c%s%c", recordbuf,		\
			(VAR)->REC.prompt, tmp1, ISVAL (VAR,REC), tmp2);\
	  }
char	recordbuf[1024];
char	tmp1, tmp2;
int	i;

	Sprintf (recordbuf, "@%s { %s", ISVAL(bi, rectype), ISVAL (bi, citekey));
	PUT (bi, address);
	PUT (bi, annote);
	PUT (bi, author);
	PUT (bi, booktitle);
	PUT (bi, chapter);
	PUT (bi, edition);
	PUT (bi, editor);
	PUT (bi, howpublished);
	PUT (bi, institution);
	PUT (bi, journal);
	PUT (bi, key);
	PUT (bi, month);
	PUT (bi, note);
	PUT (bi, number);
	PUT (bi, organisation);
	PUT (bi, pages);
	PUT (bi, publisher);
	PUT (bi, school);
	PUT (bi, series);
	PUT (bi, title);
	PUT (bi, type);
	PUT (bi, volume);
	PUT (bi, year);
	PUT (bi, comment);
	for (i = 0; i != usr_defns_ctr; i++)
	  PUT (bi, usr_defns[i]);
	Strcat (recordbuf, "\n\t}\n\n");

	(void) write (2, "", 1);
	if (_O_verbose)
	  Fprintf (stderr, recordbuf);
	if (_O_verify)
	  {
	  if (answer ("Is this correct?", NO))
	    return 0;
	  }
	Fprintf (outfile, recordbuf);
	fflush (outfile);
	return 0;
}


get_field (next_field, rectype, status)
field	*next_field;
char	*rectype;
char	status;

{
#define	ERRORMSG1	\
	"ERROR: %s is a REQUIRED FIELD for %s. Let's try that again...sigh...\n"
#define ERRORMSG2	\
	"ERROR: Frankly my dear, I don't give a damn...\n"
char	inputline[512];
char	error;
char	secondtime = FALSE;

RETRY:	Fprintf (stderr, "%s%s? ", next_field->prompt, 
		((status == OPTIONAL)? " (optional)" : "" ));
	fflush (stderr);
	error = FALSE;
	bzero (inputline, 512);
	if (! GETS (inputline, 512))
	  return -1;
	switch (inputline[0]) {
	  case '\0':
		if ((status == REQUIRED) && _O_pester_usr)
		  error = TRUE;
		else
		  return 0;
		break;
	  case '?':
		Fprintf (stderr, "%s\n", next_field->helpstring);
		goto RETRY;
	  case 'x':
		if (! Strcmp(inputline, "xx"))
		  {
		  if (answer ("Abort?", YES))
		    return -1;
		  }
	  case ' ':
		(void) clr_leading_blanks (inputline);
		if (Strlen(inputline) == 0)
		  {
		  if ((status == REQUIRED) && _O_pester_usr)
		    error = TRUE;
		  else
		    return 0;
		  }
		break;
	  }
	if (error)
	  {
	  if (secondtime)
	    {
	    Fprintf (stderr, ERRORMSG2, next_field->prompt, rectype);
	    return 0;
	    }
	  else
	    {
	    Fprintf (stderr, ERRORMSG1, next_field->prompt, rectype);
	    secondtime = TRUE;
	    goto RETRY;
	    }
	  }
	Strcpy (next_field->string, inputline);
	next_field->full = TRUE;
	return 0;
}


edit (filep, editfile, envp)
FILE	*filep;
char	*editfile;
char	**envp;

{
FILE	*freopen();
char	*EDITOR, *TEXEDIT, *getenv();
char	*string, *format_cmd();
int	editorpid;
int	statresult;
struct	stat	efile;

	statresult = stat (editfile, &efile);
	if ((statresult == -1) || (efile.st_mode & S_IFREG != 1))
	  {
	  Fprintf (stderr, "Cannot edit file %s\n", editfile);
	  return -1;
	  }
	TEXEDIT = getenv ("TEXEDIT");
	if (! TEXEDIT)
	  {
	  EDITOR = getenv ("VISUAL");
	  if (! EDITOR) EDITOR = getenv ("EDITOR");
	  if (! EDITOR) EDITOR = DEFAULT_EDITOR;
	  }
	else
	  string = format_cmd (TEXEDIT, editfile);

	fclose (filep);
	editorpid = fork();
	if (editorpid < 0)
	  {
	  perror ("Cannot fork Editor");
	  exit (-2);
	  }
	else if (editorpid == 0)	/* CHILD */
	  {
	  if (TEXEDIT)
	    execle ("/bin/sh", "sh", "-c", string, (char *) NULL, envp);
	  else
	    execlp (EDITOR, EDITOR, editfile, (char *) NULL, envp);
	  perror ("Cannot exec EDITOR, using DEFAULT_EDITOR");
	  execlp (DEFAULT_EDITOR, DEFAULT_EDITOR, editfile, (char *) NULL, envp);
	  perror ("Cannot exec DEFAULT_EDITOR, giving up");
	  exit (-3);
	  }
	else
	  (void) wait ((union wait *) 0);
	filep = freopen (_O_outfilename, "a", filep);
	return -1 /* A wierd return code, indicating, print nothing..*/;
}


clr_leading_blanks (string)
char	*string;

{
char	*temp, buffer[512];

	temp = string;
	while (*temp == ' ') temp++;
	Strcpy (buffer, temp);
	Strcpy (string, buffer);
	return 0;
}



char	*
format_cmd (envstr, filename)
char	*envstr, *filename;

{
/*
 * The envstr is going to be the TEXEDIT environment string.
 * The filename is going to be the name of the bibfile we are concerned with
 * We assume that the format of the TEXEDIT string is going to be of the form
 *	<editor name> [%d] %s
 * The %d would be optional, and contain the displacement variable....
 * Since we are appending to the end of the bibfile always, we would
 * position the editor to the bottom of the file always.
 * Strategy......
 *	locate the first %, if the character spec after it is not d, 
 *		ie, it is not %d, then assume it is <editor> %s %d
 *	The %d is really unimportant then, see...
 *	stuff the stuff in, and return the cmd string...
 */
int	lineno;
FILE	*temp, *fopen();
char	*strndx, buffer[100], cmdstr[100];

	/* First find the size in terms of lines of filename	*/
	temp = fopen (filename, "r"); lineno = 0;
	if (temp)
	  {
	  while (fgets (buffer, 100, temp)) lineno++;
	  fclose (temp);
	  lineno -= 10;		/* An arbitrary figure		*/
	  }

	/* lineno = %d specs now...				*/
	strndx = Index (envstr, '%');
	if (! strndx)
	  Strcpy (cmdstr, envstr);
	else if (*++strndx == 'd')
	  Sprintf (cmdstr, envstr, lineno, filename);
	else
	  Sprintf (cmdstr, envstr, filename, lineno);
	return cmdstr;
}

