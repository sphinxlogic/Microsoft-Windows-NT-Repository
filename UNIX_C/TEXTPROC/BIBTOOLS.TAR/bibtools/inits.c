/*
 * This program has been written by Kannan Varadhan.  You are welcome to
 * use, copy, modify, or circulate as you please, provided you do not
 * charge any fee for any of it, and you do not remove these header
 * comments from any of these files.
 *
 *		-- kva	Mon Dec  4 11:26:37 EST 1989
 */

#include "bibc.h"

resetall (bibitem)
bibrec	*bibitem;

{
int	i;

	RESET (bibitem, rectype);
	RESET (bibitem, citekey);
	RESET (bibitem, address);
	RESET (bibitem, annote);
	RESET (bibitem, author);
	RESET (bibitem,	booktitle);
	RESET (bibitem,	chapter);
	RESET (bibitem,	edition);
	RESET (bibitem,	edition);
	RESET (bibitem,	editor);
	RESET (bibitem,	howpublished);
	RESET (bibitem,	institution);
	RESET (bibitem,	journal);
	RESET (bibitem,	key);
	RESET (bibitem,	month);
	RESET (bibitem,	note);
	RESET (bibitem,	number);
	RESET (bibitem,	organisation);
	RESET (bibitem,	pages);
	RESET (bibitem,	publisher);
	RESET (bibitem,	school);
	RESET (bibitem,	series);
	RESET (bibitem,	title);
	RESET (bibitem,	type);
	RESET (bibitem,	volume);
	RESET (bibitem,	year);
	RESET (bibitem, comment);
	RESET (bibitem, cross_ref);
	for (i = 0; i != usr_defns_ctr; i++)
	  RESET (bibitem, usr_defns[i]);

	return 0;
}


initialise (bibitem)
bibrec	*bibitem;

{
char	*BIBCINIT, *getenv();
char	*qmark, *colon, *userhlp, *userkey, *nextkey;

	resetall (bibitem);

#define	STORHELP(VAR,FIELD,VALUE,HELP) 		\
	{					\
	Strcpy ((VAR)->FIELD.prompt, VALUE);	\
	Strcpy ((VAR)->FIELD.helpstring, HELP);	\
	}

	STORHELP (bibitem,	rectype,	"",	""	);
	STORHELP (bibitem,	citekey,	"CITEKEY",
"The key used to cross reference with the \cite command in the\n\
 main text."							);
	STORHELP (bibitem,	address,	"ADDRESS",
"Publisher's address.For major publishing houses, just the city\n\
 is given, for smaller publishers, you might choose to give the\n\
 full address."							);
	STORHELP (bibitem,	author,		"AUTHOR",
"The name(s) of the author(s).  Separate multiple authors by the\n\
 keyword 'and'.  See the LaTeX manual for more help."		);
	STORHELP (bibitem,	annote,		"ANNOTE",
"An annotation. Not used in the standard bibliography styles, but\n\
 may be used by others."					);
	STORHELP (bibitem,	booktitle,	"BOOKTITLE",
"Title of the book, part of which is being cited."		);
	STORHELP (bibitem,	chapter,	"CHAPTER",
"A chapter number."						);
	STORHELP (bibitem,	edition,	"EDITION",
"The edition of the book--for example, 'second'."		);
	STORHELP (bibitem,	editor,		"EDITOR",
"Name(s) of editor(s), typed as in the author field.  If the author\n\
 is also indicated, then this field gives the editor of the book or\n\
 collection in which the refernce appears."			);
	STORHELP (bibitem,	howpublished,	"HOWPUBLISHED",
"How something strange has been published."			);
	STORHELP (bibitem,	institution,	"INSTITUTION",
"The institution that published the work."			);
	STORHELP (bibitem,	journal,	"JOURNAL",
"The name of a journal."					);
	STORHELP (bibitem,	key,		"KEY",
"Used for alphabetising and creating a label when the author and\n\
 editor fields are missing."					);
	STORHELP (bibitem,	month,		"MONTH",
"The month in which the work was published.  For an unpublished\n\
 work, the month in which it was written."			);
	STORHELP (bibitem,	note,		"NOTE",
"Any additional information that can help the reader."		);
	STORHELP (bibitem,	number,		"NUMBER",
"The number of a journal, magazine or technical report."	);
	STORHELP (bibitem,	organisation,	"ORGANISATION",
"The organisation sponsoring the conference."			);
	STORHELP (bibitem,	pages,		"PAGES",
"One or more page numbers, or range of page numbers, as 42--111,\n\
 or 7,41,73--97."						);
	STORHELP (bibitem,	publisher,	"PUBLISHER",
"The publisher's name."						);
	STORHELP (bibitem,	school,		"SCHOOL",
"The name of the school in which the thesis was written."	);
	STORHELP (bibitem,	series,		"SERIES",
"The name of a series or set of books."				);
	STORHELP (bibitem,	title,		"TITLE",
"The work's title"						);
	STORHELP (bibitem,	type,		"TYPE",
"The type of a technical report, for example, 'Research Note'."	);
	STORHELP (bibitem,	volume,		"VOLUME",
"The volume of a journal or multivolume work."			);
	STORHELP (bibitem,	year,		"YEAR",
"The year of publication, or for an unpublished work, the year in\n\
 which it was written."						);
	STORHELP (bibitem,	comment,	"COMMENT",
"Any relevant info associated with this record that you would like\n\
 to store herein."						);
	STORHELP (bibitem,	cross_ref,	"CROSS-REFERENCE",
"used to fill in missing field info in this record from the\n\
 cross-referenced bib-record..see BiBTeXing manual for more help.");
/*
 * Now that the standard fields are defined, see if the user would like
 * to define specific fields for themselves.  Such fields are specified
 * by the user in tthe BIBCINIT environment variables.  The format of
 * his variable shall be similiar to the MAILPATH variable used by the
 * korn shell, as....
 *	<fieldname>?<optional help string>
 * multiple fields shall be separated by <COLON>s, ':'
 * A maximum of USR_DEFNS_MAX is taken....
 */
	BIBCINIT = getenv ("BIBCINIT");
	if (BIBCINIT)
	  {
	  userkey = BIBCINIT;
	  while (userkey != (char *) NULL)
	    {
	    nextkey = (char *) NULL;
	    userhlp = DEFAULT_USERHLP;
	    if ((colon = Index (userkey, ':')) != (char *) NULL)
	      {
	      nextkey = colon + 1;
	      *colon = '\0';
	      }
	    if ((qmark = Index (userkey, '?')) != (char *) NULL)
	      {
	      userhlp = qmark + 1;
	      *qmark = '\0';
	      }
	    STORHELP (bibitem, usr_defns[usr_defns_ctr], userkey, userhlp);
	    usr_defns_ctr++;
	    if (usr_defns_ctr < USR_DEFNS_MAX)
	      userkey = nextkey;
	    else
	      userkey = (char *) NULL /* quit while we are ahead ;-) */;
	    if (qmark != (char *) NULL) *qmark = '?';
	    if (colon != (char *) NULL) *colon = ':';
	    qmark = colon = (char *) NULL;
	    }   
	  }
#undef	STORHELP
	return 0;
}


process_args (argc, argv)
int	argc;
char	*argv[];

{
#define	SHIFT	i++
#define	args(str) (! Strcmp (argv[i], str))

int	i;
char	error[80];

	for (i = 1; i < argc; SHIFT)
	  {
	  if (args ("-i") || args ("-verify"))
	    { _O_verify = _O_verbose = TRUE; continue; }
	  if args ("-verbose")
	    { _O_verbose = FALSE; continue; }
	  if args ("+verbose")
	    { _O_verbose = TRUE; continue; }
	  if args ("-pester")
	    { _O_pester_usr = FALSE; continue; }
	  if args ("+pester")
	    { _O_pester_usr = TRUE; continue; }
	  if args ("-help")
	    { _O_help = TRUE; continue; }
	  if args ("-file")
	    { SHIFT;
	      outfile = (FILE *) fopen (argv[i], "a");
	      if (outfile)
	        Strcpy (_O_outfilename, argv[i]);
	      else
		{
		Sprintf (error, "bibc: file %s could not be opened", argv[i]);
		perror (error);
		outfile = stdout;
		}
	      continue;
	    }
	  /* default: */
	    {
	    Fprintf (stderr, "bibc: %s is an invalid argument\n", argv[i]);
	    _O_help = TRUE;
	    continue;
	    }
	  }
	if (_O_help)
	  {
	  (void) usage ();
	  exit (0);
	  }
	return 0;
#undef SHIFT
#undef args
}
#define	USAGE	"Usage: bibc [-i|-verify] [+|-verbose] [+|-pester] [-file <filename>] [-help]\n"


usage ()

{
	Fprintf (stderr, USAGE);
Fprintf (stderr, "\t-i\t\t\tInquire whether to commit a record\n");
Fprintf (stderr, "\t-verify\t\t\tSame as above, a duplicate form\n");
Fprintf (stderr, "\t-verbose\t\tTurn off verbose flag\n");
Fprintf (stderr, "\t+verbose\t\tTurn on verbose flag\n");
Fprintf (stderr, "\t-pester\t\t\tDo not insist, even for required fields\n");
Fprintf (stderr, "\t+pester\t\t\tInsist once for required fields\n");
Fprintf (stderr, "\t-file <filename>\tOutput bib entries to <filename>\n");
Fprintf (stderr, "\t-help\t\t\tPrint this help output\n");
	return 0;
}

