/*
 * This program has been written by Kannan Varadhan.  You are welcome to
 * use, copy, modify, or circulate as you please, provided you do not
 * charge any fee for any of it, and you do not remove these header
 * comments from any of these files.
 *
 *		-- kva	Mon Dec  4 11:26:37 EST 1989
 */

#define	GLOBALS
#include "bibv.h"

main (argc, argv)
int	argc;
char	*argv[];

{
extern	int	process_record();

	if (process_args (argc, argv) == -1)
	  return -1	/* EXIT */;
	
	(void) set_signals_bibv ();

	Fprintf (texfile, PREAMBLE, style, userid);
	(void) process_bibfiles (_O_flist, process_record, (int (*)()) NULL);
	(void) finish_up ();
	if (execute (OUTFILE) >= 0)
	  Fprintf (stderr, "Now printout %s.dvi to see the output\n", OUTFILE);
	(void) cleanup (OUTFILE);
	return 0;
}


finish_up ()

{
char	*temp;

	Fprintf (stderr, "FILE %s has %d records\n", _O_file, ctr);
	temp = Rindex (bibrecd, ',');
	*temp = '\0';
	Fprintf (texfile, EPILOGUE, bibrecd);
	fflush (texfile);
	return 0;
}


process_record (file, string)
char	*file, *string;

{
char	*temp, *key;

	if (_O_file != file)
	  {
	  if (ctr)
	    Fprintf (stderr, "FILE %s has %d records\n", _O_file, ctr);
	  Fprintf (texfile, SECTIONHDR, file);
	  if (Strcmp ((file + strlen (file) - 4), ".bib") == SAME)
	    Strncat (bibrecd, file, (strlen(file) - 4));
	  else
	    Strcat (bibrecd, file);
	  Strcat (bibrecd, ",");
	  _O_file = file;
	  ctr = 0;
	  }

	if (REGMATCH (regprog, string) == 1)
	  {
	  temp = Index (string, OPEN_BRACE) + 1;
	  while ((*temp == ' ') || (*temp == '\t') || (*temp == '\n'))
	    temp++;
	  key = temp;
	  while ((*temp != ' ') && (*temp != '\t') && (*temp != '\n') &&
					(*temp != ','))
	    temp++;
	  *temp = '\0';
	  Fprintf (texfile, CITE, key);
	  ctr++;
	  }

	return 0;
}


process_args (argc, argv)
int	argc;
char	*argv[];

{
int	opt, count, i;
extern	char	*optarg;
extern	int	optind;
char	**temp;
char	outfile[100];

	if (argc <= 1)
	  _O_help = TRUE;

	while ((opt = getopt (argc, argv, "hs:")) != EOF)
	  switch (opt) {
	    case 'h':
		_O_help = TRUE;
		break;
	    case 's':
		style = optarg;
		break;
	    case '?':
	    default:
		_O_help = TRUE;
	    }
	
	if (_O_help)
	  {
	  usage ();
	  return -1;
	  }
	
	_O_files = (char **) malloc ((unsigned) (sizeof (char *) * (argc - optind + 1)));
	if (_O_files == (char **) NULL)
	  {
	  perror (PROGSTR);
	  exit (-2);
	  }

	count = 1;
	temp = _O_flist = _O_files;
	for (i = optind; i < argc; i++)
	  {
	  *temp = argv[i];
	  count += Strlen (*temp) + 1;
	  temp++;
	  }
	*temp = (char *) NULL;
	bibrecd = (char *) malloc ((unsigned) count);
	bzero (bibrecd, count);

	pwentry = getpwuid (getuid());
	userid = pwentry->pw_name;

	Sprintf (outfile, "%s.tex", OUTFILE);
	texfile = fopen (outfile, "w");

	regprog = (REGEXP *) REGCOMP (KEYS);
	return 0;
}
	  

usage ()

{
Fprintf (stderr, "usage: %s [-s style-file] [-h] [ filename ... ]\n", PROGSTR);
return 0;
}


execute (outfile)
char	*outfile;

{
	if (run (LATEX, "latex", outfile, TRUE) < 0)
	  return -1;
	if (run (BIBTEX, "bibtex", outfile, FALSE) < 0)
	  return -1;
	if (run (LATEX, "latex", outfile, TRUE) < 0)
	  return -1;
	if (run (LATEX, "latex", outfile, FALSE) < 0)
	  return -1;
	return 0;
}


cleanup (outfile)
char	*outfile;

{
char	fn[100];

	Sprintf (fn, "%s.bbl", outfile); unlink (fn);
	Sprintf (fn, "%s.aux", outfile); unlink (fn);
	Sprintf (fn, "%s.log", outfile); unlink (fn);
	Sprintf (fn, "%s.blg", outfile); unlink (fn);
	return 0;
}

run (progname, arg0, filename, fdstatus)
char	*progname, *arg0, *filename;
int	fdstatus;

{
int	pid;
char	emsg[100];
union	wait	status;

	Sprintf (emsg, "Cannot run %s .. Aborting", arg0);
	pid = vfork();
	if (pid < 0)		/* ERROR */
	  {
	  perror ("fork");
	  return -1;
	  }
	else if (pid == 0)	/* CHILD */
	  {
	  if (fdstatus)
	    {
	    close (0); open ("/dev/null", O_RDONLY);
	    close (1); open ("/dev/null", O_WRONLY);
	    close (2); open ("/dev/null", O_WRONLY);
	    }
	  execlp (progname, progname, filename, 0);
	  perror (emsg);
	  return -1;
	  }
	else
	  (void) wait4 (pid, &status, 0, (struct rusage *) NULL);

	if (status.w_termsig != 0)
	  {
	  Fprintf (stderr, "%s error, signal %2d %s\n", arg0,
				status.w_termsig,
				(status.w_coredump ? ", core dumped" : "")
		  );
	  return -1;
	  }
	return 0;
}

set_signals_bibv ()

{
extern	int	hangup_bibv(), abort_bibv();

	signal (SIGHUP, hangup_bibv);
	signal (SIGINT, hangup_bibv);
	signal (SIGQUIT, hangup_bibv);
	signal (SIGTERM, hangup_bibv);

	signal (SIGILL, abort_bibv);
	signal (SIGBUS, abort_bibv);
	signal (SIGSEGV, abort_bibv);
	signal (SIGSYS, abort_bibv);
	signal (SIGPIPE, abort_bibv);
	return -1;
}

hangup_bibv ()
/*
 * Nothing to do but cleanout bibtex.* files, and exit
 */

{
char	fn[100];

	Sprintf (fn, "%s.tex", OUTFILE); unlink (fn);
	Sprintf (fn, "%s.dvi", OUTFILE); unlink (fn);
	Sprintf (fn, "%s.bbl", OUTFILE); unlink (fn);
	Sprintf (fn, "%s.aux", OUTFILE); unlink (fn);
	Sprintf (fn, "%s.log", OUTFILE); unlink (fn);
	Sprintf (fn, "%s.blg", OUTFILE); unlink (fn);
	exit (-1);
}


abort_bibv (sig, code, scp)
/*
 * First print out a small message, then hangup_bibv()
 */

{
Fprintf (stderr, "Unexpected error signal %d received..aborting\n", sig);
hangup_bibv ();
/*NOT REACHED*/
}
