/*
 * This program has been written by Kannan Varadhan.  You are welcome to
 * use, copy, modify, or circulate as you please, provided you do not
 * charge any fee for any of it, and you do not remove these header
 * comments from any of these files.
 *
 *		-- kva	Mon Dec  4 11:26:37 EST 1989
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <ctype.h>
#include <assert.h>
#include <errno.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/resource.h>
#include "strings.h"
#include "config.h"
#include "regexp.h"

extern	int	errno;
#ifdef	GLOBALS
#define	DCL(TYPE,VAR,VAL)	TYPE	VAR = VAL
#define	DCLX(TYPE,VAR)		TYPE	VAR
#else
#define	DCL(TYPE,VAR,VAL)	extern	TYPE	VAR
#define	DCLX(TYPE,VAR)		extern	TYPE	VAR
#endif

#define	FALSE	0
#define	TRUE	! FALSE

#define	SAME	0

#ifdef	EBUG
#define	DEBUG
#endif

#ifdef DEBUG
#define	WRITE(STRING)	write(2,STRING,strlen(STRING));write(2,"\n",1)
#define	PRINT(FMT,VAR)	fprintf (stderr, FMT, VAR)
#define	DASSERT(COND)	assert (COND)
#else
#define	WRITE(STRING)
#define	PRINT(FMT,VAR)
#define	DASSERT(COND)
#endif

#define	QUOTE_CHAR	'"'
#define	OPEN_BRACE	'{'
#define	CLOSE_BRACE	'}'
#define	BSLASH		'\\'

#define	YES	'y'
#define	NO	'n'


