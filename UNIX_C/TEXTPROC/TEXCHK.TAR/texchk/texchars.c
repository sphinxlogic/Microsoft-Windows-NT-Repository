#include "texchars.h"

static char *Latex_Chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.:;,?!`'()[]-/*@#$%&~_^\\{}+=|<>\"\t \n";

static char *Lgl_Command_Chars = " !\"#$%&'()+,-./:;<=>@[\\]^_`{|}~";

char Lgl_Chars[256];
char Lgl_Single_Char_Commands[256];

init_legal_chars () 
{
  int j;
  char *lc = Latex_Chars;
  char *ls = Lgl_Command_Chars;
  for (j = 0; j < 256; j++) { 
      Lgl_Chars[j] = 0;
      Lgl_Single_Char_Commands[j] = 0;
  }
  while (*lc != '\0') Lgl_Chars[*lc++] = '1';  
  while (*ls != '\0') Lgl_Single_Char_Commands[*ls++] = '1';  
  return(1);
}
