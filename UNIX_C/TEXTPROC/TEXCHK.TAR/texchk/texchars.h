extern init_legal_chars();

extern char Lgl_Chars[];
extern char Lgl_Single_Char_Commands[];

#define LGL_CHAR(x) (Lgl_Chars[(x)])
#define LGL_SINGLE_COMMAND_CHAR(x) (Lgl_Single_Char_Commands[(x)])
