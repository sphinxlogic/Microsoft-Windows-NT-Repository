/*
** Configuration information for sp
*/

# include	<curses.h>

# define	True	1
# define	False	0

# define	Error	1
# define	Okay	0

# define	VERSION1	"Sp Version 4.0"
# define	VERSION2	"Copyright (C) 1988"
# define	VERSION3	"Andrew Large"

/*
** Lookup dictionary -- use /usr/dict/web2 if you have it
*/
# define	LOOK_DICT	"/usr/dict/words"

/*
** Location of common programs
*/
# define	EX	"/usr/ucb/ex"
# define	FGREP	"/usr/bin/fgrep"
# define	LOOK	"/usr/bin/look"
# define	MORE	"/usr/ucb/more"
# define	SORT	"/usr/bin/sort"
# define	SPELL	"/usr/bin/spell"

/*
** Constant sizes
*/
# define	MAX_WORDS	512	/* Max words corrected on one pass */
# define	MAX_WORD_LEN	256	/* Max length of a word */
# define	MAX_WINDOW	15	/* Maximum window size (for where) */

# define	CTRL_R		022	/* Ascii value of ^R -- for redraw */
# define	CTRL_L		014	/* Ascii value of ^L -- for redraw */
# define	ESC		033	/* Ascii value of Escape */


typedef	unsigned char	boolean;

void	leave ();
char	*sfalloc ();
