# include	"sp.h"

/*
** Global data use throughout the program
*/
char	*id = "@(#)SP\t4.0\t88/11/13";	/* Identification string for what(1) */

char	*bad_words[MAX_WORDS],		/* Words obtained from spell(1) */
	*good_words[MAX_WORDS],		/* Words to correct in document */
	*add_words[MAX_WORDS],		/* Words to add to local dictionary */
	*local_dict,			/* Local dictionary */
	*spell_doc,			/* Document we are currently spelling */
	tmp_file[16];			/* Temporary file used for */

int	num_bad,			/* Number of bad words */
	num_added,			/* Number added to local dict */
	num_ignored,			/* Number bad words ignored */
	exit_val,			/* Program exit value (for leave ()) */
	window_size;			/* Context window size (for where ()) */

boolean	local;				/* Is the local dict available? */
