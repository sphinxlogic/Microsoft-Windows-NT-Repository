# include	"sp.h"

/*
** doc_correct
** Correct the document, based upon the difference between the
** original and new lists of words.  Uses EX to make the corrections.
*/
doc_correct () {
	extern	char	*bad_words[], *good_words[], *spell_doc;
	extern	int	num_bad;
	FILE	*popen (), *ex_ptr;
	char	command[256];
	register int	loop;

	page_clear (0, False);
	mvaddstr (3,0, "Making changes ..."); refresh ();

	sprintf (command, "%s - %s", EX, spell_doc);
	ex_ptr = popen (command, "w");

	fprintf (ex_ptr, "set nomagic\n");	/* Don't match '.' */
	for (loop = 0; loop < num_bad; loop++)
		if (strcmp (bad_words[loop], good_words[loop]) != 0) {
			fprintf (ex_ptr, "%%s/\\<%s\\>/%s/g\n", bad_words[loop],
				good_words[loop]);
			fflush (ex_ptr);
		}
	fprintf (ex_ptr, "w\nq\n");
	fflush (ex_ptr); pclose (ex_ptr);

	addstr (" done"); refresh ();
}
