/*
	Write a bibliographic entry to a file.  This is simple; just
	write a newline followed by the text of the entry.
*/

# include	<stdio.h>
# include	"bibinfo.h"


BEWrite (f, be)
FILE	*f;
BibEnt	*be;
{
	fputc ('\n', f);
	fwrite (BEText (be), 1, BELen (be), f);
}
