/*
	BibEnt structure allocation and disposal
*/

# include	"bibinfo.h"

BibEnt *BEAlloc ()
{
char	*calloc ();

	return ((BibEnt *) calloc (1, sizeof (BibEnt)));
}


BEFree (bp)
BibEnt	*bp;
{
	free (bp);
}
