#define	INIT		0
#define	DEL1CHAR	1
#define	SWAP2CHARS	2
#define	CHG1CHAR	3
#define	ADD1CHAR	4
