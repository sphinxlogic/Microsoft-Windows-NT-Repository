/*
 * converters program names
 */
#define FIG2DEV	"fig2dev"
#define PIC2FIG "pic2fig"
#define X2FIG "x2fig"
#define X2PIC "x2pic"
#define X2PS "x2ps -x"

/*
 * filename defaults
 */
#define MK "Makefile"
#define TX "transfig.tex"

enum language  {box, pictex, 
	latex, epic, eepic, eepicemu,
	postscript, psfig, tpic};
#define MAXLANG tpic

enum input {fig, pic, xpic, ps};
#define MAXINPUT xps

typedef struct argument{
	char *name, *interm, *f, *s, *m, *tofig, *topic, *tops;
	enum language tolang;
	enum input type;
	struct argument *next;
} argument ;

extern enum language str2lang();
extern char *lname[];
extern char *iname[];

extern char *sysls(), *mksuff();
extern argument *arglist;
extern char *txfile, *mkfile;

extern char *optarg;
extern int optind;

