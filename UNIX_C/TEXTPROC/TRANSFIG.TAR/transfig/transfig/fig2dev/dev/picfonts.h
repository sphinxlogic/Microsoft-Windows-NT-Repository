/*  The selection of font names may be site dependent */

char		*fontnames[] = {
			"R", "R",		/* default */
			"R",			/* roman */
			"B",			/* bold */
			"I",			/* italic */
			"H",			/* sans serif */
			"C"			/* typewriter */
		};
#define MAXFONT 5
#define MAXFONTSIZE 108

#define PICFONT(F)	(fontnames[((F) <= MAXFONT) ? (F)+1 : MAXFONT])
#define PICFONTSIZE(S)  ((S) > 0 ? \
				((S) <= MAXFONTSIZE ? \
					(S) : \
					MAXFONTSIZE) : \
				font_size)
