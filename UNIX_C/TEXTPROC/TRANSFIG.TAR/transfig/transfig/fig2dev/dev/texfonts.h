static char		*fontnames[] = {
			"rm", "rm",		/* default */
			"rm",			/* roman */
			"bf",			/* bold */
			"it",			/* italic */
			"sf", 			/* sans serif */
			"tt"			/* typewriter */
		};
#define MAXFONT 5

/* The selection of font names may be site dependent.
 * Not all fonts are preloaded at all sizes.
 */

static char		*fontsizes[] = {
			"elv", "elv",		/* default */
			"fiv", "fiv", "fiv", "fiv", 	/* small fonts */
			"fiv",			/* five point font */
			"six", "sev", "egt",	/* etc */
			"nin", "ten", "elv",
			"twl", "twl", "frtn",	
			"frtn", "frtn", "svtn",
			"svtn", "svtn", "twty",
			"twty", "twty", "twty", "twty", "twfv"
			};
#define MAXFONTSIZE 25

#define TEXFONT(F)	(fontnames[((F) <= MAXFONT) ? (F)+1 : MAXFONT])
#define TEXFONTSIZE(S)	(fontsizes[((S) <= MAXFONTSIZE) ? (S)+1 : MAXFONTSIZE])
