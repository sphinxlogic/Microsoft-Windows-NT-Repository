extern struct driver dev_box;
extern struct driver dev_epic;
extern struct driver dev_latex;
extern struct driver dev_pic;
extern struct driver dev_pictex;
extern struct driver dev_ps;

struct 
	{char *name; struct driver *dev;}
	drivers[]
	= {
		{"box",		&dev_box}, 
#ifdef EPIC
		{"epic",	&dev_epic},
		{"eepic",	&dev_epic},
		{"eepicemu",	&dev_epic},
#endif
#ifdef LATEX
		{"latex",	&dev_latex},
#endif
#ifdef PIC
		{"pic",		&dev_pic},
#endif
#ifdef PICTEX
		{"pictex",	&dev_pictex},
#endif
#ifdef PS
		{"ps",		&dev_ps},
#endif
		{"",		NULL}
	};
