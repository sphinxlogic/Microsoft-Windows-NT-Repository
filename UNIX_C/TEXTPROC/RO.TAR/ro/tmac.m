..	\"===================================================
..	\"
..	\"	tmac.m
..	\"
..	\"	text macros for the "ro" text formatter
..	\"	by Ted A. Campbell
..	\"
..	\"===================================================
..	\"
..	\"===================================================
..	\"	Reset top and bottom margin registers
.M1 6
.M2 2
.M3 2
.M4 6
.ll 65
.po 8
..	\"===================================================
..	\"	Number register "P" -- current page number 
.nr P 0
..	\"===================================================
..	\"	String "DT" -- current date
.ds DT "19\\n(yr/\\n(mo/\\n(dy"
..	\"===================================================
..	\"	Macro "PH" -- page header
.de PH
.nr P +1
.HE $0
..
..	\"===================================================
..	\"	Macro "PF" -- page footer
.de PF
.FO $0
..
..	\"===================================================
..	\"	Number register "Ps" -- paragraph spacing
.nr Ps 1
..	\"===================================================
..	\"	Number register "Pi" -- paragraph indent
.nr Pi 0
..	\"===================================================
..	\"	Macro "P" -- begin paragraph
.de P
.sp \\n(Ps
.ne 2
.ti \\n(Pi
..
..	\"===================================================
..	\"	Macro "R" -- set Roman font
.de R
.ft R
..
..	\"===================================================
..	\"	Macro "I" -- set Italic font
.de I
.ft I
..
..	\"===================================================
..	\"	Macro "B" -- set Bold font
.de B
.ft B
..
..	\"===================================================
..	\"	Number register "Fn" -- current footnote number
.nr Fn 1
..	\"===================================================
..	\"	String "F" -- print current footnote number superscript
.ds F "\\u\\n(Fn\\d"
..	\"===================================================
..	\"	Macro "FS" -- start footnote
.de FS
.di no
.sp
.ti +5
\\u\\n(Fn\\d
..
..	\"===================================================
..	\"	Macro "FE" -- end footnote
.de FE
.di
.nr Fn +1
..
..	\"===================================================
..	\"	Macro "PN" -- print footnotes
.de PN
.sp 2
.ls 1
.na
.ne 6
.ce 
NOTES
.sp 1
.no
..
..	\"===================================================
..	\"	Macro "TA" -- text segment beginning 
.de TA
.ls 2
.nr Pi 5
.nr Ps 0
.sp
..
..	\"===================================================
..	\"	Macro "TZ" -- text segment ending
.de TZ
.ls 1
.nr Ps 1
..
..	\"===================================================
..	\"	Macro "BA" -- block segment beginnning
.de BA
.ls 1
.nr Pi 0
.nr Ps 1
.in +5
.ll -5
.sp
..
..	\"===================================================
..	\"	Macro "BZ" -- block segment ending
.de BZ
.in -5
.ll +5
..
..	\"===================================================
..	\"
..	\"	End of tmac.m
..	\"
..	\"===================================================
