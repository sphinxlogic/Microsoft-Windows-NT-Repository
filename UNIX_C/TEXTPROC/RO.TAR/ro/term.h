#define	ESCAPE		0x1b

/**	Single-character printer code designations ***/

#define	ROMAN		'R'	/* Restore "roman" or "regular" font */
				/* Should turn off Bold and Italic */
#define	ITALIC		'I'	/* Switch to italics or underline */
#define	BOLD		'B'	/* Switch to bold */
#define	HALFUP		'u'	/* Half-line up */
#define	HALFDOWN	'd'	/* Half-line down */


