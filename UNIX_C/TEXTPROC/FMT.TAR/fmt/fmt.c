/* 
file: fmt.c   
04/88  bgray
*/

/* a simple text formatter */


#include <stdio.h>
#include <ctype.h>
#include <string.h>


#define TRUE 1
#define FALSE 0

int iflag = FALSE;
int jflag = FALSE;
int maxlen = 72;
int tabsize = 8;
int offset = 0;
int spaces = 0;

char *progname = NULL;
char *delimiters = " \t\n\r\f";
char *usage = "usage: %s [-ij] [-l n] [-p n] [-t n] [file ...]\n";

int dir = FALSE;
int holecnt = 0;
char *holeptr[256];  /* holeptr[0] is unused */

char iline[2048] = "\0";
char *ilp = iline;
char oline[2048] = "\0";
char *olp = oline;

extern char *optarg;
extern int optind;

int max();
void exit();
char *basename(), *strtok();


main(argc, argv)
int argc;
char *argv[];
{
	int c;

	progname = basename(argv[0]);
	while ((c = getopt(argc, argv, "ijl:p:t:")) != EOF)
		switch(c) {
			case 'i' : iflag = TRUE; break;
			case 'j' : jflag = TRUE; break;
			case 'l' : maxlen = max(0, atoi(optarg)); break;
			case 'p' : offset = max(0, atoi(optarg)); break;
			case 't' : tabsize = max(1, atoi(optarg)); break;
			default : fprintf(stderr, usage, progname); exit(1); break;
		}
	
	if (optind >= argc)
		format();
	else for ( ;  (optind < argc);  optind++) {
		if (freopen(argv[optind], "r", stdin) != NULL)
			format();
		else {
			fprintf(stderr, "Couldn't open file: %s", argv[optind]);
			exit(1);
		}
	}
	return(0);
}  /* main */



format()
{
	char *p;
	
	while (ilp = gets(iline)) 
		if (*ilp == '\0')
			skipline(1);
		else if (*ilp == '.') {
			putline();
			while (*olp++ = *ilp++);
			putline();
		}
		else {
			if ((iflag) && (isspace(*ilp))) {
				putline();
				copyindent();
			}
			p = strtok(ilp, delimiters);
			while (*p) {
				putword(p);
				p = strtok(NULL, delimiters);
			}
		}
	putline();
}  /* format */



copyindent()
{
	int col = 1;
	
	for (  ;  (isspace(*ilp));  col++) {
		if (*ilp++ == '\t')
			for (  ;  (col % tabsize);  col++) 
				*olp++ = ' ';
		*olp++ = ' ';
	}
}  /* copyindent */



putword(p)
char *p;
{
	int plen;

	plen = strlen(p);
	if ((olp - oline) + spaces + plen > maxlen) {
		if ((jflag) && (holecnt))
			justifyline();
		putline();
	}
	if (spaces) {
		holeptr[++holecnt] = olp;
		for (  ;  (spaces > 0);  spaces--)
			*olp++ = ' ';
	}
	spaces = 1 + endofsentence(p, plen);
	while (*p)
		*olp++ = *p++;
}  /* putword */



justifyline()
{
	int n;
	char *fp;
	char *tp;
	
	dir = (! (dir));
	fp = olp - 1;
	olp = &oline[maxlen];
	tp = olp - 1;
	while (tp > fp) {
		while (fp >= holeptr[holecnt])
			*tp-- = *fp--;
		if (dir)
			n = ((tp - fp) - 1) / holecnt + 1;
		else
			n = (tp - fp) / holecnt;
		while (n--) 
			*tp-- = ' ';
		holecnt--;
	}
}  /* justifyline */



putline()
{
	*olp = '\0';
	if (*oline)
		printf("%*s\n", offset + strlen(oline), oline);
	*oline = '\0';
	olp = oline;
	spaces = 0;
	holecnt = 0;
}  /* putline */



skipline(n)
int n;
{
	putline();
	for (  ;  (n > 0);  n--)
		printf("\n");
}  /* skipline */



int endofsentence(p, plen)
char *p;
int plen;
{
	if (plen < 3)
		return(FALSE);
	if (!strchr(".:?!", *(p + plen - 1)))
		return(FALSE);
	if (abbr(p))
		return(FALSE);
	return(TRUE);
}  /* endofsentence */



int abbr(s)
char *s;
{
	char *p, *q, *r;

	while (*s == '(') s++;
	q = ".i.e.g.dr.mr.mrs.st.";
	for (  ;  (*q);  q++) {
		p = q;
		r = s;
		while ((*r) && (*p++ == (*r++ | 0x20))) ;
		if (!*r)
			return(TRUE);
	}
	return(FALSE);
}  /* abbr */



char *basename(s)
char *s;
{
	char *p;

	if (p = strrchr(s, '/'))
		return(++p);
	else
		return(s);
}  /* basename */



int max(a, b)
int a, b;
{
	return((a > b) ? a : b);
}  /* max */

