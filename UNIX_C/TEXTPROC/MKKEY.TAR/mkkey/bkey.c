#include <stdio.h>
#include <string.h>
#define MAXLINES 2000

extern int fseek(), fscanf(), sscanf();
extern char *malloc();
extern char *fgets();
extern int strncmp();

main(argc, argv)
int argc;
char *argv[];
{
	FILE *fp, *fopen();
	unsigned int i,j;
        char *array[MAXLINES];
        char a[2][90], b[2][90];
	int c;
        int len = 0;


	j=i=0;
	if(argc == 1){
		printf("Usage: %s file\n",argv[0]);
		exit(1);
	}
	if((fp = fopen(argv[1], "r")) == 0){
		printf("%s: Can't open %s\n",argv[0],argv[1]);
		exit(1);
	}
/* make a pass through the file to determine how many lines there are */
	while((c=fgetc(fp)) != EOF){
		if(c == '\n')
			i++;
	}
        if(i > MAXLINES){
		printf("%s: To many lines to read\n", argv[0]);
		exit(1);
	}
	for(j=0; j <= i; j++){
		if((array[j]=malloc(90)) == 0){
			printf("Can't allocate memory\n");
                	exit(1);
		}
	}
/* go back to the start of the file */
	fseek(fp,0,0);
/* start reading the file and placing each line into array */
	j=0;
	while((fgets(array[j],90,fp)) != 0){
		len=strlen(array[j]);
		array[j][len-1] = '\0';  /* zap the newline */
		j++;
	}
        fclose(fp);
	for(j=0; j < i; j++){
		sscanf(array[j],"%s %[0-9A-Za-z. \t]",a[0],a[1]);
		if(strlen(array[j]) > 65){
			printf("%s\n", array[j]);
			continue;
		}
		if(strncmp(array[j+1],a[0],strlen(a[0])) == 0){
			sscanf(array[j+1],"%s%[0-9A-Za-z. \t]",b[0],b[1]);
			if(strlen(array[j]) + strlen(b[1]) > 75){
				printf("%s\n", array[j]);
				printf("%s: %s\n",b[0],b[1]);
			} else {
                                if(b[1][0] == ' '){
					printf("%s%s\n", array[j],b[1]);
				} else {
					printf("%s %s\n", array[j],b[1]);
				}
			}
			j++;
		} else {
			printf("%s\n", array[j]);

		}
			
	}
	exit(0);
}
