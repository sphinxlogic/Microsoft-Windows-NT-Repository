
#define SUCCESS 0
#define FAILURE 1
#define ERROR 2

#define NOFLAG 0
#define ALLFLAG (1<<0)

#define MAKEFILE 'm'
#define RFC 'r'
#define BINSH 's'

extern char TagChar;
extern char DefaultTag;

extern unsigned long Flags;

extern unsigned char Style;
