^X/* Kappa: utility program
^X	Prints a table of character frequencies drawn from stdin.
^X;The table appears in natural order.
^X;Frequencies are per 1000 characters.
^X*/
^X
^X# include <stdio.h>
^X
^Xlong table[256];
^Xlong total;
^X
^Xmain()
^X	{
^X;int ch;
^X	int i;
^X	int lcmpr();
^X
^X	while ((ch = getchar()) != EOF) {
^X;;table[ch]++;
^X		total++;
^X		}
^X	printf("Total: %ld\n\n", total);
^X	for (i = 0; i < 256; i++) {
^X;;table[i] *= 1000;
^X		table[i] /= total;
^X		}
^X	for (i = 0; i < 256; i++) {
^X;;printf("%3.3ld ", table[i]);
^X		if ((i + 1) % 16 == 0) putchar('\n');
^X		if ((i + 1) % 128 == 0) putchar('\n');
^X		}
^X	}
