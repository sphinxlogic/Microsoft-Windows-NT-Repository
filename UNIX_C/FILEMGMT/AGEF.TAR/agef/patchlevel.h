/* Patchlevel for AGEF.

   SCCS ID	@(#)patchlevel.h	1.6	7/9/87
*/

#define PATCHLEVEL V3.0
