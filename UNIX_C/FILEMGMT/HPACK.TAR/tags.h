/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*							HPACK Archive Tag Settings						*
*							 TAGS.H  Updated 31/12/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1990, 1991  Peter C.Gutmann.  All rights reserved			*
*																			*
****************************************************************************/

#include "io/hpackio.h"

/* 						--------- WARNING --------

				This file should be treated as READ-ONLY!
  Never make any changes to this file yourself as it will probably render
  your version of HPACK incompatible with all other versions.  Changes to
  this  file  should  be  submitted to  Peter  Gutmann  so  they  can  be
  redistributed to all HPACK developers.

						--------------------------- */

/* This file defines all tags values used in HPACK.  The format for tags
   is as follows:

   All tags are 16 bits long.  Tags may be regarded as numeric values from
   0x0000 - 0xFFFF.  All tags are of the form <10 bits Tag ID><6 bits length>,
   except for the tag ID's of 2FE-2FF, which are treated (in combination
   with the 6-bit info field) as 128 unique tags, with the data length
   following the tag as another 16-bit value.  This gives 765 short-form
   tags and 128 long-form tags.  The length fields cover the data only;
   they do not include the lengths of the tags (or length fields) themselves */

/* The base values for each tag type */

#define SHORT_BASE		0x0000
#define LONG_BASE		0xFF80

/* Macros to ease setting up of tags */

#define SHORT_TAG(no,length)	( SHORT_BASE + ( ( no ) << 6 ) | ( length ) )
#define LONG_TAG(no)			( LONG_BASE + ( no ) )

#define TAGSIZE			sizeof( WORD )

/* Macros to extract tag ID and length from tags */

#define TAGID_MASK		0xFFC0
#define DATALEN_MASK	0x003F
#define TAGID_SHIFT		6
#define SHORT_TAGLEN	( 1 << TAGID_SHIFT )	/* Max.data size for short tag */
#define MAX_TAGLEN		0xFFFF					/* Max.possible tagged data len */

#define extractTagID(tag)	( ( ( tag ) & TAGID_MASK ) >> TAGID_SHIFT )
#define extractTagLen(tag)	( ( tag ) & DATALEN_MASK )

/* Classes of tags */

enum { NO_TAG, ATTRIBUTE_TAG, COMMENT_TAG };

/* Prototypes for the read/write tag functions */

WORD writeTag( WORD tagID, WORD tagLen, const BYTE *buffer );
WORD writeDirTag( WORD tagID, WORD tagLen, const BYTE *buffer );
ATTR readAttributeData( const WORD attributeID );
BOOLEAN readTag( WORD *tagFieldSize, WORD *tagID, WORD *tagLen );

/* Alias for fputWord() for programmer convenience */

#define fputTag		fputWord

/****************************************************************************
*																			*
*									Tag ID's								*
*																			*
****************************************************************************/

/* Tag ID's are specified as an enumerated type to solve potential problems
   with duplication of tag ID's.  New types *must* be added to the end of
   the list, *never* to the middle */

enum { TAG_MSDOS_ATTR, TAG_UNIX_ATTR, TAG_MAC_ATTR, TAG_QNX_ATTR,
	   TAG_ARC_ATTR, TAG_AMIGA_ATTR, TAG_ATARI_ATTR, TAG_APPLE_ATTR,
	   TAG_OS2_EXT_ATTR, TAG_FILE_TIME, TAG_SOCKET, TAG_ERROR, 
	   TAG_SHORT_COMMENT };

enum { TAG_LONG_COMMENT };

/****************************************************************************
*                                                                           *
*						System-specific Informatiom Tags					*
*																			*
****************************************************************************/

/* The MSDOS/OS2 attribute bits, organised as follows:

   BYTE : attributes

   7 6 5 4 3 2 1 0
   N x A D V S H R
   | | | | | | | +-> Read-only flag
   | | | | | | +---> Hidden/Invisible flag
   | | | | | +-----> System flag
   | | | | +-------> Volume label flag (not used in HPACK - set to 0)
   | | | +---------> Directory flag (not used in HPACK - set to 0)
   | | +-----------> Archive bit
   | +-------------> Unused - set to 0
   +---------------> Nominally unused - used by Novell netware? */

#define MSDOS_ATTR_RDONLY		0x01
#define MSDOS_ATTR_HIDDEN		0x02
#define MSDOS_ATTR_SYSTEM		0x04
#define MSDOS_ATTR_ARCHIVE		0x20

#define MSDOS_ATTR	SHORT_TAG( TAG_MSDOS_ATTR, 1 )

/* The UNIX permission flag bits, organised as follows:

   WORD : attributes

   FEDC B A 9 876 543 210
   ???? u g s rwx rwx rwx
   --+- | | | -+- -+- +++-> Other rwx bits
	 |  | | |  |   +------> Group rwx bits
	 |  | | |  +----------> Owner rwx bits
	 |  | | +-------------> Sticky bit
	 |  | +---------------> SGID flag
	 |  +-----------------> SUID flag
	 +--------------------> ? (not used in HPACK - set to 0) */

#define UNIX_ATTR_OTHER_X		0x0001
#define UNIX_ATTR_OTHER_W		0x0002
#define UNIX_ATTR_OTHER_R		0x0004
#define UNIX_ATTR_GROUP_X		0x0008
#define UNIX_ATTR_GROUP_W		0x0010
#define UNIX_ATTR_GROUP_R		0x0020
#define UNIX_ATTR_OWNER_X		0x0040
#define UNIX_ATTR_OWNER_W		0x0080
#define UNIX_ATTR_OWNER_R		0x0100
#define UNIX_ATTR_STICKY		0x0200
#define UNIX_ATTR_SGID			0x0400
#define UNIX_ATTR_SUID			0x0800

#define UNIX_ATTR_RBITS		( UNIX_ATTR_OTHER_R | UNIX_ATTR_GROUP_R | UNIX_ATTR_OWNER_R )
#define UNIX_ATTR_WBITS		( UNIX_ATTR_OTHER_W | UNIX_ATTR_GROUP_W | UNIX_ATTR_OWNER_W )
#define UNIX_ATTR_XBITS		( UNIX_ATTR_OTHER_X | UNIX_ATTR_GROUP_X | UNIX_ATTR_OWNER_X )

#define UNIX_ATTR	SHORT_TAG( TAG_UNIX_ATTR, 2 )

/* Macintosh file info, organised as follows:

   WORD : attributes

   F E D C B A 9 8 76543210
   | | | | | | | | ++++++++-> Unused - set to 0
   | | | | | | | +----------> Init
   | | | | | | +------------> Changed
   | | | | | +--------------> Busy
   | | | | +----------------> Bozo
   | | | +------------------> System
   | | +--------------------> Bundle
   | +----------------------> Invisible
   +------------------------> Locked

   LONG : creator
   LONG : owner */

#define MAC_ATTR_INIT			0x0100
#define MAC_ATTR_CHANGED		0x0200
#define MAC_ATTR_BUSY			0x0400
#define MAC_ATTR_BOZO			0x0800
#define MAC_ATTR_SYSTEM			0x1000
#define MAC_ATTR_BUNDLE			0x2000
#define MAC_ATTR_INVISIBLE		0x4000
#define MAC_ATTR_LOCKED			0x8000

#define MAC_ATTR	SHORT_TAG( TAG_MAC_ATTR, 10 )

/* QNX file info, organised as follows:

   BYTE : group permission
   BYTE : member permission
   BYTE : owner permission
   BYTE : owner group
   BYTE : owner member */

#define QNX_ATTR	SHORT_TAG( TAG_QNX_ATTR, 5 )

/* Archimedes file info, organised as follows:

   BYTE : attributes

   765 4 32 10
   xxx L rw RW
   -+- | -+ ++-> Read/Write Access - Owner
	|  |  +----> Read/Write Access - Others
	|  +-------> Locked bit
	+----------> Unused - set to 0

   WORD : file type */

#define	ARC_ATTR_WRITE_OWNER	0x0001
#define ARC_ATTR_READ_OWNER		0x0002
#define ARC_ATTR_WRITE_OTHER	0x0004
#define ARC_ATTR_READ_OTHER		0x0008
#define ARC_ATTR_LOCKED			0x0010

#define ARC_ATTR	SHORT_TAG( TAG_ARC_ATTR, 3 )

/* Amiga file info, organised as follows:

   BYTE : attributes

   765 4 3 2 1 0
   xxx A R W X D
   -+- | | | | +-> Delete flag
	|  | | | +---> Execute bit
	|  | | +-----> Write bit
	|  | +-------> Read bit
	|  +---------> Archive bit (0 = set, 1 = cleared)
	+------------> Unused - set to 0 */

#define AMIGA_ATTR_DELETE		0x01
#define AMIGA_ATTR_EXECUTE		0x02
#define AMIGA_ATTR_WRITE		0x04
#define AMIGA_ATTR_READ			0x08
#define AMIGA_ATTR_ARCHIVE		0x10

#define AMIGA_ATTR	SHORT_TAG( TAG_AMIGA_ATTR, 1 )

/* Atari ST file info, organised as follows:

   BYTE : attributes

   76 5 4 3 2 1 0
   xx A D V S H R
   +- | | | | | +-> Read-only flag
   |  | | | | +---> Hidden/Invisible flag
   |  | | | +-----> System flag
   |  | | +-------> Volume label flag (not used in HPACK - set to 0)
   |  | +---------> Directory flag (not used in HPACK - set to 0)
   |  +-----------> Archive bit
   +--------------> Unused - set to 0 */

#define ATARI_ATTR_RDONLY		0x01
#define ATARI_ATTR_HIDDEN		0x02
#define ATARI_ATTR_SYSTEM		0x04
#define ATARI_ATTR_ARCHIVE		0x20

#define ATARI_ATTR	SHORT_TAG( TAG_ATARI_ATTR, 1 )

/* Apple IIgs file info, organised as follows:

   WORD : attributes

   FEDCBA98 7 6 5 432 1 0
   ----+--- | | | -+- | +-> Read permission
	   |    | | |  |  +---> Write permission
	   |    | | |  +------> Unused - set to 0
	   |    | | +---------> Backup needed
	   |    | +-----------> Rename
	   |    +-------------> Destroy
	   +------------------> Unused - set to 0

   WORD : file type
   WORD : auxiliary type */

#define APPLE_ATTR_READ         0x0001
#define APPLE_ATTR_WRITE		0x0002
#define APPLE_ATTR_BACKUP		0x0020
#define APPLE_ATTR_RENAME		0x0040
#define APPLE_ATTR_DESTROY		0x0080

#define APPLE_ATTR	SHORT_TAG( TAG_APPLE_ATTR, 4 )

/* OS/2 Extended Attributes */

#define OS2_ATTR	LONG_TAG( TAG_OS2_EXT_ATTR, 0 )	/* Length added at runtime */

/* System dates for those systems which store three dates for each file
   (the modification date is stored in the file header), organised as:

   LONG : creation date
   LONG : access date */

#define FILE_TIME	SHORT_TAG( TAG_FILE_TIME, 8 )

/****************************************************************************
*                                                                           *
*							System-specific Crufties						*
*																			*
****************************************************************************/

/* BSD socket info, organised as <whatever> */

#define UNIX_SOCKET	SHORT_TAG( TAG_SOCKET, n )

/****************************************************************************
*                                                                           *
*						Security and Data Validation						*
*																			*
****************************************************************************/

/* The error recovery info: ID, fileName, dataLen */

#define ERROR_ID		"\xFE\xFE\xFE\xFE"	/* Reasonably uncommon pattern */
#define ERROR_ID_SIZE	( sizeof( ERROR_ID ) - 1 )	/* -1 if for '\0' */

#define ERROR_TAG	SHORT_TAG( TAG_ERROR, 0 )	/* Length added at runtime */

/****************************************************************************
*                                                                           *
*								Miscellaneous								*
*																			*
****************************************************************************/

/* Comments of 0-63 and 64-65534 ASCII chars.  Long comments are compressed
   using the standard archive compression method */

#define LONG_COMMENT	LONG_TAG( TAG_LONG_COMMENT )
#define SHORT_COMMENT	SHORT_TAG( TAG_SHORT_COMMENT, 0 )	/* Length must be
															   added at runtime */
