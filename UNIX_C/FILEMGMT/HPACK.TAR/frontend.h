/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*						Header File for the Main Archiver Code				*
*							FRONTEND.H  Updated 25/09/91					*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*			Copyright 1991   Peter C.Gutmann.  All rights reserved			*
*																			*
****************************************************************************/

/* The distance in bytes to the next piece of data to handle */

extern long skipDist;

/* Some general vars */

extern WORD flags;			/* Various flags set by the user */
extern WORD dirFlags;		/* Directory-handling flags set by the user */
extern WORD overwriteFlags;	/* Overwrite-on-extract flags */
extern WORD viewFlags;		/* Options for the View command */
extern WORD xlateFlags;		/* Options for output translation */
extern WORD commentType;	/* The type of the archive comment */
extern BOOLEAN archiveChanged;	/* Whether the archive has been changed */
extern char basePath[];		/* The output directory given by the -b option */
extern int basePathLen;		/* The length of the basePath */
extern int screenHeight, screenWidth;	/* The screen size */

/* The structs to handle the filepath/filename info */

typedef struct FN {
				  struct FN *next;	/* The next node in the list */
				  char *fileName;	/* The actual fileName */
				  } FILENAMEINFO;

typedef struct FP {
				  struct FP *next;	/* The next node in the list */
#if !defined( __UNIX__ ) && !defined( __MAC__ )
				  char drive;		/* The drive */
#endif /* !( __UNIX__ || __MAC__ ) */
				  char *filePath;	/* The filePath */
				  FILENAMEINFO *fileNames;	/* List of files on this path */
				  } FILEPATHINFO;

/* The start of the list of fileSpecs */

extern FILEPATHINFO *filePathListStart;
