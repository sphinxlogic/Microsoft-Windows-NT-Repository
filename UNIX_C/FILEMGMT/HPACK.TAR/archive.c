/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*					  File Archive/Dearchive Handling Routines				*
*							ARCHIVE.C  Updated 12/12/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1989 - 1991  Peter C.Gutmann.  All rights reserved		*
*																			*
****************************************************************************/

#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include "defs.h"
#include "arcdir.h"
#include "choice.h"
#include "error.h"
#include "filesys.h"
#include "flags.h"
#include "frontend.h"
#include "hpacklib.h"
#include "hpaktext.h"
#include "system.h"
#include "tags.h"
#include "crc/crc16.h"
#include "crypt/crypt.h"
#include "io/fastio.h"
#include "io/hpackio.h"
#include "store/store.h"

/* Prototypes for compression/decompression functions */

long pack( const BOOLEAN *isText, const FD inFD, const FD outFD, long noBytes );
BOOLEAN unpack( const BOOLEAN isText, const FD inFD, const FD outFD, \
				const long coprLen, const long uncoprLen );

#ifdef __MSDOS__

/* Prototypes for functions in MISC.ASM */

void printFilePath( const char *filePath, int padding );
void getFileName( char *fileName );

#endif /* __MSDOS__ */

/* Various defines */

#define MIN_FILESIZE	50	/* Any files of below this length are stored,
							   since it is not worth trying to compress
							   them */

/* A flag to indicate whether we overwrite the existing file entry at currPos
   or whether we add a new one via addFileHeader().  This is set for the
   FRESHEN, REPLACE, and UPDATE commands */

BOOLEAN overWriteEntry;

/****************************************************************************
*																			*
*								General Work Functions						*
*																			*
****************************************************************************/

/* Handle an idiot box - either return TRUE or FALSE to the caller, or
   exit if response is FALSE */

BOOLEAN confirmAction( const char *message )
	{
	char ch;

	hprintf( MESG_s_YN, message );
	hflush( stdout );
	while( ( ch = hgetch(), ch = toupper( ch ) ) != RESPONSE_YES && \
											  ch != RESPONSE_NO );
	hputchar( ch );
	hputchar( '\n' );
	return( ch == RESPONSE_YES );
	}

void idiotBox( const char *message )
	{
	char ch;

	hprintf( WARN_s_CONTINUE_YN, message );
	hflush( stdout );
	while( ( ch = hgetch(), ch = toupper( ch ) ) != RESPONSE_YES && \
											  ch != RESPONSE_NO );
	hputchar( ch );
	hputchar( '\n' );
	if( ch == RESPONSE_NO )
		{
		errorFD = 0;	/* Make sure we don't delete archive by mistake */
		error( STOPPED_AT_USER_REQUEST );
		}
	hputchar( '\n' );
	}

/* Print dots to show the length of a file.  The most elegant way to
   backspace over the dots would be to use ANSI codes, but not all systems
   have ANSI drivers.  Filenames are padded out with spaces to make them
   align nicely */

#if defined( __MSDOS__ )
  #define PADDING		12			/* 8.3 */
#elif defined( __UNIX__ )
  #define PADDING		16			/* Pad out to at least 16 chars */
#else
  #error "Need to define filename length padding in ARCHIVE.C"
#endif /* Various OS-specific defines */

static void printFileName( const char *fileName, int charsUsed, \
						   const long fileSize, const BOOLEAN printDots )
	{
	int i = 0, length, noDots;

	/* Quick check for no printing */
	if( flags & STEALTH_MODE )
		return;

	hputchar( ' ' );

	/* Determine statistics for filename.  The amount added to charsUsed
	   represents the length of ' ' + path + '/' (if used) + filename with
	   any necessary padding added + ' '.  noDots is calculated as one dot
	   for every 4K (2^12) bytes of data */
	for( i = strlen( fileName ); i && fileName[ i ] != '/'; i-- );
#if defined( __MSDOS__ )
	charsUsed += ( i ? i + 1 : 0 ) + PADDING + 2;
#elif defined( __UNIX__ )
	charsUsed += ( i ? i + 1 : 0 ) + 3 + \
				 ( ( strlen( fileName + i ) > PADDING ) ? strlen( fileName + i ) : PADDING );
#else
	hprintf( "Need to set up handling of filename padding in ARCHIVE.C, line %d\n", __LINE__ );
#endif /* OS-specific padding handling */
	length = ( screenWidth - charsUsed ) > 0 ? screenWidth - charsUsed : 0;
	noDots = ( int ) ( fileSize >> 12 ) > length ? length : ( int ) ( fileSize >> 12 );

#ifdef __MSDOS__
	printFilePath( fileName, i );
#else
	hprintf( "%s", fileName );	/* Filename may contain '%' char */
	for( i = strlen( fileName ); i < 16; i++ )
		hputchar( ' ' );
	hputchar( ' ' );		/* Always print at least one space */
#endif /* __MSDOS__ */

	/* Print dots corresponding to the file length if required, otherwise
	   print a CRLF */
	if( printDots )
		{
		for( i = 0; i < noDots; i++ )
			hputchar( '.' );
		while( i-- > 0 )
			hputchar( '\b' );
		}
	else
		hputchar( '\n' );
	}

/* Confirm skipping a file */

#define STR1_FILENAME	TRUE
#define STR2_FILENAME	FALSE

BOOLEAN confirmSkip( const char *str1, const char *str2, const BOOLEAN str1Filename )
	{
	char ch;
	int i, length = strlen( str1 ) + strlen( str2 ) + 11; /* 11 = sizeof prompt chars */

	/* Ask user for skip choice.  Note that we use a hgetch() and not a
	   hgetchar(), since hgetchar() requires a CR which is spuriously echoed */
	hprintf( MESG_s_s_YNA, str1, str2 );
	hflush( stdout );
	while( ( ch = hgetch(), ch = toupper( ch ) ) != RESPONSE_YES && \
							ch != RESPONSE_NO && ch != RESPONSE_ALL );
	hputchar( ch );

	/* Blank the current line */
	hputchar( '\r' );
	for( i = 0; i < length; i++ )
		hputchar( ' ' );
	hputchar( '\r' );

	if( ch == RESPONSE_NO )
		{
		/* Indicate file is being skipped */
		hprintf( MESG_SKIPPING_s, ( str1Filename ) ? str1 : str2 );
		return( TRUE );
		}

	if( ch == RESPONSE_ALL )
		{
		/* Do an automatic "Confirm" for all following files */
		if( flags & INTERACTIVE )
			flags &= ~INTERACTIVE;
		else
			overwriteFlags |= OVERWRITE_ALL;
		}

	return( FALSE );
	}

/* Find the filename component of a given filePath */

static char *findFilenameStart( char *filePath )
	{
	char *filePtr = filePath;
	int i;

	/* Find the first char after the last '/' */
	for( i = 0; filePath[ i ]; i++ )
		if( filePath[ i ] == '/' )
			filePtr = filePath + i + 1;	/* +1 to skip '/' */

#if defined( __MSDOS__ )
	/* Skip prepended drive specifier if necessary */
	if( filePtr[ 1 ] == ':' )
		filePtr += 2;
#endif /* __MSDOS__ */

	return( filePtr );
	}

/****************************************************************************
*																			*
*							Extract Data from an Archive					*
*																			*
****************************************************************************/

/* The following variables are visible to both extractData() and retrieveData().
   This is necessary since they are useful only for retrieveData() calls to
   extractData() */

BOOLEAN fileNameTruncated;
char *oldFileName, *fileName;

/* General-purpose data extraction handler */

typedef enum { DATA_BAD, DATA_OK, DATA_SKIPPED } DATA_STATUS;

DATA_STATUS extractData( const FD dataFD, const WORD dataInfo, \
						 const LONG dataLen, const LONG fileLen, const BOOLEAN isFile )
	{
	WORD oldFlags = flags, oldXlateFlags = xlateFlags;
	int charsUsed = 10;		/* Length of "Extracting" */
	BOOLEAN dataOK, isText, specialCase = FALSE;
	LONG dataForkLength;

	/* We can't unarchive private-key encrypted data if no password for it is
	   given.  Also set/clear doCrypt depending on whether the data needs to
	   be decrypted or not */
#pragma warn -pia
	if( ( doCrypt = dataInfo & ARCH_CRYPT ) && !( flags & CRYPT ) )
#pragma warn +pia
		{
		if( isFile )
			hprintf( MESG_DATA_IS_ENCRYPTED );
		goto skipData;
		}

	/* Special-case code to handle Apple resource vs data fork */
	if( ( dataInfo & ARCH_SYSTEM ) == OS_MAC || \
		( dataInfo & ARCH_SYSTEM ) == OS_IIGS )
		{
		/* Extract only the data fork, skipping the resource fork */
		dataForkLength = fgetLong( archiveFD );
		specialCase = TRUE;			/* Mumble mutter mumble */
		}

	/* Set the appropriate translation mode if necessary.  These are
	   different for each OS */
	if( ( flags & XLATE_OUTPUT ) && ( xlateFlags & XLATE_SMART ) )
		if( dataInfo & ARCH_ISTEXT )
			switch( dataInfo & ARCH_SYSTEM )
				{
#if !defined( __UNIX__ ) && !defined( __AMIGA__ )
				case OS_UNIX:
				case OS_AMIGA:
					xlateFlags = XLATE_EOL;
					initTranslationSystem( '\n' );
					break;
#endif /* !( __UNIX__ || __AMIGA__ ) */

/*				case OS_IBM:
					xlateFlags = XLATE_EBCDIC;
					break; */

				case OS_PRIMOS:
					xlateFlags = XLATE_PRIME;
					break;

#if !defined( __MAC__ )
				case OS_MAC:
					xlateFlags = XLATE_EOL;
					initTranslationSystem( '\r' );
					break;
#endif /* !__MAC__ */

#if !defined( __MSDOS__ ) && !defined( __OS2__ )
				case OS_MSDOS:
				case OS_OS2:
					xlateFlags = XLATE_EOL;
					initTranslationSystem( '\r' | 0x80 );
					break;
#endif /* !( __MSDOS__ || __OS2__ ) */
				}
		else
			/* No translation for non-text files */
			xlateFlags = 0;

	if( ( dataInfo & ARCH_STORAGE ) < FORMAT_UNKNOWN )
		{
		if( isFile )
			{
			hprintfs( MESG_EXTRACTING );
			if( fileNameTruncated )
				{
				hprintfs( MESG_s_AS, oldFileName );
				charsUsed += 4 + strlen( oldFileName );
				}
			printFileName( fileName, charsUsed, fileLen, choice != DISPLAY );
			}

		/* Make sure we don't print any dits during the extraction by
		   turning on stealth mode */
		if( choice == DISPLAY || !isFile )
			flags |= STEALTH_MODE;

		isText = ( dataInfo & ARCH_ISTEXT ) ? TRUE : FALSE;

		switch( dataInfo & ARCH_STORAGE )
			{
			case FORMAT_STORED:
				/* Don't bother with zero-length files */
				if( dataLen )
					dataOK = unstore( archiveFD, dataFD, ( specialCase ) ? \
									  dataForkLength : dataLen );
				else
					/* Can't corrupt a zero-length file */
					dataOK = TRUE;
				break;

			case FORMAT_PACKED:
				dataOK = unpack( isText, archiveFD, dataFD, ( specialCase ) ? \
								 dataForkLength : dataLen, fileLen );
				break;
			}

		/* Skip Apple resource fork if necessary */
		if( specialCase )
			skipDist = dataLen - dataForkLength - sizeof( LONG );
		}
	else
		{
		if( isFile )
			hprintf( MESG_UNKNOWN_ARCHIVING_METHOD );
skipData:
		if( isFile )
			hprintf( MESG__SKIPPING_s, fileName );
		skipDist += dataLen;
		return( DATA_SKIPPED );
		}
	doCrypt = FALSE;

	/* Reset various options */
	flags = oldFlags;
	xlateFlags = oldXlateFlags;

	return( dataOK );
	}

/* Retrieve data from the archive file to a data file */

void retrieveData( FILEHDRLIST *fileInfo )
	{
	FILEHDR *theHeader = &fileInfo->data;
	FD dataFD;
	char *filePath, *filePtr, *suffixPtr, ch;
	int iteration = 1, i;
	WORD auxDataLen, tagID, tagLen;
	DATA_STATUS dataStatus;

	/* Flag the fact that we've accessed the archive */
	archiveChanged = TRUE;

	fileNameTruncated = FALSE;
	fileName = buildInternalPath( fileInfo );
	if( choice == EXTRACT )
		{
		filePath = buildExternalPath( fileInfo );
		fileNameTruncated = isTruncated();

		/*  Make sure we don't overwrite an existing file unless the
			OVERWRITE_ALL option has been specified */
		if( ( dataFD = hopen( filePath, O_RDONLY | S_DENYNONE ) ) != IO_ERROR )
			{
#ifdef __MSDOS__
			/* Check if the file corresponds to a device name */
			if( sysSpecFlags & SYSPEC_CHECKSAFE )
				if( isDevice( dataFD ) )
					{
					hprintf( OSMESG_FILE_IS_DEVICEDRVR );
					if( !( overwriteFlags & OVERWRITE_PROMPT ) )
						{
						/* Don't extract without user intervention */
						hprintf( MESG__SKIPPING_s, fileName );
						skipDist += theHeader->dataLen + theHeader->auxDataLen;
						hclose( dataFD );
						return;
						}
					hputchar( '\n' );
					}
#endif /* __MSDOS__ */

			hclose( dataFD );

			if( !( overwriteFlags & OVERWRITE_ALL ) )
				{
				/* Check whether we want a forced skip of this file */
				if( overwriteFlags & OVERWRITE_NONE )
					{
					ch = RESPONSE_NO;
					hprintf( MESG_WONT_OVERWRITE_EXISTING_s, fileName );
					}
				else
					{
					/* Find the filename component of the filePath */
					filePtr = findFilenameStart( filePath );

					if( overwriteFlags & OVERWRITE_SMART )
						{
						/* Find either the '.' in the filename or the end of
						   the filename.  In either case we stop after
						   the 8th char to allow room for the ".000" */
						for( i = 0; *filePtr && *filePtr != '.' && i < 8; \
							 i++, filePtr++ );
						for( iteration = strlen( fileName ) + 1; iteration && \
							 fileName[ iteration - 1 ] != '/'; iteration-- );
						suffixPtr = fileName + iteration + i;
						if( filePtr - filePath > MAX_PATH - 5 )
							/* No room for ".000\0", panic */
							error( PATH_S_TOO_LONG, filePath );

						/* Now try and open a new file with a numerical
						   suffix.  Increment the suffix until we can open
						   the file */
						strcpy( filePtr, ".000" );
						while( ( dataFD = hopen( filePath, O_RDONLY | S_DENYNONE ) ) != IO_ERROR )
							{
							hclose( dataFD );

							/* Set the suffix to the iteration count.  We
							   could check to see whether the / 100, / 10
							   parts are worth doing but the code overhead
							   is probably not worth it since this code
							   won't be executed much */
							strcpy( filePtr, ".000" );
							i = iteration++;
							filePtr[ 1 ] += i / 100;
							i %= 100;
							filePtr[ 2 ] += i / 10;
							i %= 10;
							filePtr[ 3 ] += i;
							}

						/* Finally, update the fileName to reflect the changes
						   to the filePath */
						strcpy( suffixPtr, filePtr );

						/* We have now found a unique filename which we can use */
						fileNameTruncated = TRUE;	/* Force printing of original name */
						ch = RESPONSE_YES;
						}
					else
						if( overwriteFlags & OVERWRITE_PROMPT )
							{
							while( ( dataFD = hopen( filePath, O_RDONLY | S_DENYNONE ) ) != IO_ERROR )
								{
								hclose( dataFD );
								hprintf( MESG_s_ALREADY_EXISTS_ENTER_NEW_NAME, \
										 fileName );
#ifdef __MSDOS__
								/* Call B&D filename input routine */
								getFileName( fileName );
#else
								/* Nasty input routine - should check for
								   illegal chars and suchlike.  Will also
								   overflow if anyone enters more than
								   16K chars */
								hflush( stdout );
								hgets( ( char * ) mrglBuffer );
								mrglBuffer[ MAX_PATH - 1 ] = '\0';
								strcpy( fileName, ( char * ) mrglBuffer );
#endif /* __MSDOS__ */
								hputchar( '\r' );
								for( i = 0; i < 79; i++ )
									hputchar( ' ' );
								hputchar( '\r' );

								/* Do a path length check */
								i = MAX_PATH - strlen( filePath ) - 1;	/* -1 is for '\0' */
								if( strlen( fileName ) > i )
									{
									/* Path too long, truncate and issue warning */
									strncpy( filePtr, fileName, i );
									filePtr[ i ] = '\0';
									hprintf( MESG_PATH_s__TOO_LONG, filePath );
									}
								else
									/* Copy name across */
									strcpy( filePtr, fileName );
								}
							fileNameTruncated = TRUE;	/* Force printing of original name */
							ch = RESPONSE_YES;
							}
						else
							ch = ( confirmSkip( filePath, MESG_ALREADY_EXISTS__OVERWRITE, \
												STR1_FILENAME ) ) ? RESPONSE_NO : RESPONSE_YES;
					}

				if( ch == RESPONSE_NO )
					{
					skipDist += theHeader->dataLen + theHeader->auxDataLen;
					return;
					}
				}
			}
		else
			if( flags & INTERACTIVE )
				/* Ask the user whether they want to extract this file */
				if( confirmSkip( MESG_EXTRACT, fileName, STR2_FILENAME ) )
					{
					skipDist += theHeader->dataLen + theHeader->auxDataLen;
					return;
					}

		if( ( dataFD = hcreat( filePath, CREAT_ATTR ) ) == IO_ERROR )
			error( CANNOT_OPEN_DATAFILE, fileName );

		if( fileNameTruncated )
			oldFileName = fileInfo->fileName;

		/* Set the file to delete in case of error to the unarchived file */
		strcpy( errorFileName, filePath );
		errorFD = dataFD;
		}
	else
		{
		if( flags & INTERACTIVE )
			/* Ask the user whether they want to handle this file */
			if( confirmSkip( ( choice == DISPLAY ) ? MESG_DISPLAY : MESG_TEST, \
							 fileName, STR2_FILENAME ) )
				{
				skipDist += theHeader->dataLen + theHeader->auxDataLen;
				return;
				}

		dataFD = STDOUT;
		if( choice == TEST )
			setOutputIntercept( OUT_NONE );
		}

	/* Extract the data */
	dataStatus = extractData( dataFD, theHeader->archiveInfo,
							  theHeader->dataLen, theHeader->fileLen, TRUE );

	/* Check the file has not been corrupted */
	if( dataStatus == DATA_BAD )
		/* A klane korruption.... */
		hprintf( WARN_FILE_PROBABLY_CORRUPTED );

	if( choice == EXTRACT || choice == TEST )
		{
		if( choice == TEST && dataStatus == DATA_OK )
			hprintf( MESG_FILE_TESTED_OK );

		if( choice == TEST )
			{
			resetOutputIntercept();
			skipDist += theHeader->auxDataLen;
			}
		else
			{
			hclose( dataFD );
			errorFD = 0;	/* We no longer need to delete the extracted file on error */

			/* Give files their real date if necessary */
			if( !( flags & TOUCH_FILES ) )
				setFileTime( filePath, theHeader->fileTime );

			if( dataStatus == DATA_SKIPPED )
				{
				/* File was never extracted, remove it, skip auxData, and exit */
				hunlink( filePath );
				skipDist += theHeader->auxDataLen;
				return;
				}

			/* Set the files' attributes properly if there are any recorded.
			   This must be done after the hclose() since it changes the
			   attributes */
			if( flags & STORE_ATTR )
				{
				/* Grovel through the auxData field looking for attribute tags */
				auxDataLen = theHeader->auxDataLen;
				while( auxDataLen )
					if( readTag( &auxDataLen, &tagID, &tagLen ) == ATTRIBUTE_TAG )
						/* We've found an attribute tag, read in the attributes
						   and set them */
						hchmod( filePath, readAttributeData( tagID ) );
				}
			else
				skipDist += theHeader->auxDataLen;
			}
		}
	else
		{
		hprintf( MESG_HIT_A_KEY );
		hflush( stdout );
		hgetch();	/* getchar() only terminates on CR */
		skipDist += theHeader->auxDataLen;
		}

	hputchar( '\n' );

	/* Attempt recovery if the data was corrupted */
	if( dataStatus == DATA_BAD && fileInfo->next != NULL )
		{
		/* Do an absolute seek to the start of the next data block, since we
		   may currently be anywhere in the current block, and reset input
		   data counters */
		hlseek( archiveFD, fileInfo->next->offset, SEEK_SET );
		_inByteCount = _BUFSIZE;
		skipDist = 0L;
		}
	}

/****************************************************************************
*																			*
*								Add Data to an Archive						*
*																			*
****************************************************************************/

/* Add data to the archive file from a data file */

void addData( const FILEINFO *fileInfoPtr, const WORD dirIndex, const FD dataFD )
	{
	FILEHDR theHeader;
	long dataLength, auxDataLen = 0L;
	int comprMethod, i;
	WORD errorTagLen, type = TYPE_NORMAL;
	BOOLEAN isText = FALSE;

	/* Flag the fact that we've made changes to the archive */
	archiveChanged = TRUE;

	hprintfs( MESG_ADDING );
	printFileName( fileInfoPtr->fName, 6, fileInfoPtr->fSize, TRUE );
	doCrypt = ( flags & CRYPT ) ? TRUE : FALSE;

	if( fileInfoPtr->fSize )
		if( fileInfoPtr->fSize > MIN_FILESIZE )
			{
			comprMethod = FORMAT_PACKED;
			dataLength = pack( &isText, dataFD, archiveFD, fileInfoPtr->fSize );

			/* If we've ended up expanding the data then store it instead.
			   Undoing the call to pack() is particularly nasty since there
			   may still be data in the buffer which is unwritten; there may
			   in fact still be data in the buffer from the *previous* call to
			   pack(), so we must flush the buffer before we do any seeking.
			   If this is a multipart archive we don't bother since the
			   complications involved if the data is spread over 15 different
			   disks makes recovery distrinctly nontrivial */
			if( dataLength >= fileInfoPtr->fSize && !( flags & MULTIPART_ARCH ) )
				{
				/* Go to start of line and overprint "Adding" message */
				hputchars( '\r' );
				hprintfs( MESG_ADDING );
				printFileName( fileInfoPtr->fName, 6, fileInfoPtr->fSize, TRUE );

				flush( archiveFD );
				hlseek( archiveFD, -dataLength, SEEK_CUR );
				htruncate( archiveFD );	/* Kill everything after this point */
				hlseek( dataFD, 0L, SEEK_SET );
				if( flags & ARCH_COMMENT )
					/* Move back to overwrite format info at start of data */
					hlseek( archiveFD, -( ( long ) sizeof( BYTE ) ), SEEK_CUR );
				goto storeData;
				}
			}
		else
			{
storeData:
			comprMethod = FORMAT_STORED;
			dataLength = store( &isText, dataFD, archiveFD );
			}
	else
		{
		/* Don't bother handling zero-length files */
		comprMethod = FORMAT_STORED;
		dataLength = 0L;
		}
	doCrypt = FALSE;

	/* Add storage format info for archive comments */
	if( flags & ARCH_COMMENT )
		type = commentType | getDataFormat( comprMethod );

	/* Write the file's attributes if necessary */
	if( flags & STORE_ATTR )
		{
#if defined( __MSDOS__ )
		fputTag( archiveFD, MSDOS_ATTR );
		fputByte( archiveFD, fileInfoPtr->fAttr );
		auxDataLen += TAGSIZE + sizeof( BYTE );
#elif defined( __UNIX__ )
		fputTag( archiveFD, UNIX_ATTR );
		fputWord( archiveFD, fileInfoPtr->statInfo.st_mode );	/* Save attributes */
		fputTag( archiveFD, FILE_TIME );
		fputLong( archiveFD, fileInfoPtr->statInfo.st_ctime );	/* Save change time */
		fputLong( archiveFD, fileInfoPtr->statInfo.st_atime );	/* Save access time */
		auxDataLen += TAGSIZE + sizeof( WORD ) + \
					  TAGSIZE + sizeof( LONG ) + sizeof( LONG );
#elif defined( __MAC__ )
		fputTag( archiveFD, MAC_ATTR );
		/* -- write attr's, dates, etc etc -- */
		auxDataLen += TAGSIZE + whatever;
		hprintf( "Need to set up tag handling in ARCHIVE.C, line %d\n", __LINE__ );
#elif defined( __AMIGA__ )
		fputTag( archiveFD, AMIGA_ATTR );
		/* -- write attr's, dates, etc etc -- */
		auxDataLen += TAGSIZE + whatever;
		hprintf( "Need to set up tag handling in ARCHIVE.C, line %d\n", __LINE__ );
#elif defined( __ATARI__ )
		fputTag( archiveFD, ATARI_ATTR );
		/* -- write attr's, dates, etc etc -- */
		auxDataLen += TAGSIZE + whatever;
		hprintf( "Need to set up tag handling in ARCHIVE.C, line %d\n", __LINE__ );
#elif defined( __ARC__ )
		fputTag( archiveFD, ARC_ATTR );
		/* -- write attr's, dates, etc etc -- */
		auxDataLen += TAGSIZE + whatever;
		hprintf( "Need to set up tag handling in ARCHIVE.C, line %d\n", __LINE__ );
#endif /* Various OS-dependant attribute writes */
		}

	/* Build the header from the file info and add it to the header list */
	theHeader.fileTime = fileInfoPtr->fTime;
	theHeader.fileLen = fileInfoPtr->fSize;
	theHeader.auxDataLen = ( WORD ) auxDataLen;
	theHeader.dirIndex = dirIndex;
	theHeader.dataLen = dataLength;
	theHeader.archiveInfo = ( cryptFlags & CRYPT_PUBLIC || \
							  cryptFlags & CRYPT_PRIVATE ) ? ARCH_CRYPT : 0;
	theHeader.archiveInfo |= ( cryptFlags & CRYPT_SECURED ) ? ARCH_SECURED : 0;
	theHeader.archiveInfo |= ( flags & ARCH_COMMENT ) ? FORMAT_SPECIAL : comprMethod;
	theHeader.archiveInfo |= ARCHIVE_OS;
	if( isText )
		theHeader.archiveInfo |= ARCH_ISTEXT;

	/* Include the size of the error recovery tag if necessary */
	if( flags & ERROR_RECOVER )
		{
		errorTagLen = TAGSIZE + ERROR_ID_SIZE + computeHeaderSize( &theHeader ) + \
					  strlen( fileInfoPtr->fName ) + 1 + sizeof( WORD );
		theHeader.auxDataLen += errorTagLen;
		}

	/* Make sure we have < 64K of auxiliary data */
	if( auxDataLen > MAX_TAGLEN )
		error( TOO_MUCH_EXTRA_INFO );

	if( !overWriteEntry )
		/* Add the new header to the list */
		addFileHeader( &theHeader, type );
	else
		/* Overwrite the existing header at this position */
		fileHdrCurrPtr->data = theHeader;

	/* Write the error recovery tag if necessary - if used this must be the
	   last tag */
	if( flags & ERROR_RECOVER )
		{
		/* First, write the error-recovery ID info */
		fputWord( archiveFD, ERROR_TAG | errorTagLen );
		for( i = 0; i < ERROR_ID_SIZE; i++ )
			fputByte( archiveFD, ERROR_ID[ i ] );

		/* Then write the error-recovery info itself: file header, fileName,
		   and crc16 for tag info.  Note that we can't use writeTag() for
		   the file header since we have to write the individual fields for
		   portability */
		checksumBegin( OUTPUT );
		theHeader.auxDataLen -= errorTagLen;
		writeFileHeader( &theHeader, type );
		auxDataLen = strlen( fileInfoPtr->fName );
		for( i = 0; i <= auxDataLen; i++ )
			fputByte( archiveFD, fileInfoPtr->fName[ i ] );
		checksumEnd( OUTPUT );
		fputWord( archiveFD, crc16 );
		}

	hputchars( '\n' );
	}
