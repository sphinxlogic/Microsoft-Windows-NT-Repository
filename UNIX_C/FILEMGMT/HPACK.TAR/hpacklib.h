/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*						HPACK Library Code Interface Header					*
*							HPACKLIB.H  Updated 24/12/91					*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1990 - 1991  Peter C.Gutmann.  All rights reserved		*
*																			*
****************************************************************************/

#ifndef _HPACKLIB_DEFINED

#define _HPACKLIB_DEFINED

#ifndef __MSDOS__

/* Macros to turn the generic HPACKLIB functions into their equivalent on
   the current system */

#include <stdio.h>					/* Prototypes for generic functions */
#include <malloc.h>					/* Needed for mem functions on some systems */
#include "flags.h"					/* Flags for stealth-mode check */

#define hprintf		printf			/* Output formatted string/arg-list */
#define hputchar	putchar			/* Output single char */
#define hputs		puts			/* Output string */
#define hgets		gets			/* Input string */
#define hgetch		getch			/* Get char, no echo */

#define hprintfs					if( !( flags & STEALTH_MODE ) ) \
										printf
#define hputchars					if( !( flags & STEALTH_MODE ) ) \
										putchar
#ifdef __UNIX__
  #define hflush	fflush			/* Prehistoric buffering on stdout */
#else
  #define hflush(x)					/* Ba-woooosshhhh!! */
#endif /* __UNIX__ */

#define hmalloc		malloc			/* Allocate block of memory */
#define hrealloc	realloc			/* Re-allocate block of memory */
#define hfree		free			/* Free block of memory */

#else

/* Prototypes for functions in the HPACK libraries */

void hprintf( const char *format, ... );
void hprintfs( const char *format, ... );
void hvprintf( void );
void hputchar( const char ch );
void hputchars( const char ch );
void hputs( const char *string );
int hgetch( void );

#define hflush(x)				/* No need for hflush() under a real OS */

/* The hfree() pseudo-function:  Unlike free(), hfree() is a null function
   since all cases where hmalloc() is called keep the memory allocated until
   HPACK terminates, when a block free is done.  The use of the DYNA memory
   manager does away with the need for a hfree() function */

#define hfree(ptr)

/* hmalloc() is called getMem() externally to reduce any confusion that it's
   a malloc() clone */

void *getMem( const int size );

#define hmalloc(size)	getMem( size )

/* hmallocSeg() is a MSDOS-specific hmalloc() which ensure the data is
   segment aligned.  This greatly enhances the simplicity of array indexing
   since a segment register can point at the array base and an index register
   can be used to index into it */

void *getMemSeg( const int size );

#define hmallocSeg(size)	getMemSeg( size )

/* initMem() and endMem() start up and shut down the memory manager */

void initMem( void );
void endMem( void );

#endif /* !__MSDOS__ */

#endif /* !_HPACKLIB_DEFINED */
