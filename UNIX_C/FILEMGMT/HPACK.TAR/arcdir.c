/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*						Archive Directory Handling Routines					*
*							ARCDIR.C  Updated 16/12/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1989 - 1991 Peter C.Gutmann.  All rights reserved			*
*																			*
****************************************************************************/

#include <stdlib.h>
#include <string.h>
#include "defs.h"
#include "arcdir.h"
#include "choice.h"
#include "error.h"
#include "flags.h"
#include "hpacklib.h"
#include "hpaktext.h"
#include "system.h"
#include "tags.h"
#include "crc/crc16.h"
#include "crypt/crypt.h"
#include "io/fastio.h"
#include "io/hpackio.h"
#include "store/store.h"

/* Prototypes for functions in ARCHIVE.C */

void idiotBox( const char *message );
BOOLEAN confirmAction( const char *message );

#ifdef __MSDOS__

/* Prototypes for memory management functions */

void markMem( void );
void releaseMem( void );
void ungetMem( void );

#endif /* __MSDOS__ */

/* The data structure for the name table for fileNames */

typedef struct NT {
				  char *namePtr;		/* Pointer to the name */
				  WORD dirIndex;		/* Directory index of this filename */
				  WORD type;			/* Type of this file */
				  struct NT *next;		/* The next entry in this list */
				  } NT_ENTRY;

/* The size of the memory buffer for archive information */

#if ARCHIVE_TYPE == 1
  #define MEM_BUFSIZE	1000	/* More modest memory usage in test vers. */
#else
  #define MEM_BUFSIZE	8000
#endif /* ARCHIVE_TYPE == 1 */

/* The size of the hash table.  Must be a power of 2 */

#define HASHTABLE_SIZE	4096

/* The structure which holds the archive trailer info.  The checksum field
   overlays the security field length for secured archives */

typedef struct {
			   WORD noDirHdrs;			/* No.of directory headers */
			   WORD noFileHdrs;			/* No.of file headers */
			   LONG dirInfoSize;		/* Length of dir.info.block */
			   WORD checksum;			/* CRC16 of all preceding dir.data */
			   BYTE specialInfo;		/* The kludge byte */
			   BYTE archiveID[ 4 ];		/* 'HPAK' */
			   } ARCHIVE_TRAILER;

#define TRAILER_SIZE		( sizeof( WORD ) + sizeof( WORD ) + sizeof( LONG ) + \
							  sizeof( WORD ) + sizeof( BYTE ) + ( 4 * sizeof( BYTE ) ) )

/* The size of the trailer for multipart archives */

#define MP_TRAILER_SIZE		( sizeof( WORD ) + sizeof( WORD ) + sizeof( LONG ) + \
							  sizeof( WORD ) )

/* The magic ID and temporary name extensions for HPACK archives */

char HPACK_ID[] = "HPAK";
char TEMP_EXT[] = "$$1";
char DIRTEMP_EXT[] = "$$2";
char SECTEMP_EXT[] = "$$3";

/* A special value for the fileKludge to indicate the prototype versions of
   either the LZW, LZA, or MBWA versions of HPACK */

#if ARCHIVE_TYPE == 1
  #define PROTOTYPE	0x20				/* LZW development version */
#elif ARCHIVE_TYPE == 2
  #define PROTOTYPE	0x40				/* LZA development version */
#elif ARCHIVE_TYPE == 3
  #define PROTOTYPE	0x60				/* LZA' release version */
#elif ARCHIVE_TYPE == 4
  #define PROTOTYPE	0x80				/* LZA" release version */
#elif ARCHIVE_TYPE == 5
  #define PROTOTYPE	0xA0				/* MBWA prototype version 1 */
#elif ARCHIVE_TYPE == 6
  #define PROTOTYPE	0xC0				/* MBWA prototype version 2 */
#else
  #error "Need to define ARCHIVE_TYPE"
#endif /* Various ARCHIVE_TYPE-specific defines */

#define isPrototype(value)	( ( value ) & 0xE0 )/* Whether this archive was
													created by a proto-HPACK */

/* Symbolic defines to specify whether we want getArchiveInfo() to read in
   the ID bytes or not */

#define READ_ID		TRUE
#define NO_READ_ID	FALSE

/* Defines to handle the ^Z padding which some versions of Xmodem/Ymodem do */

#define CPM_EOF				0x1A
#define	YMODEM_BLOCKSIZE	1024	/* We can have up to this many ^Z's
									   appended */

/****************************************************************************
*																			*
*								Global Variables							*
*																			*
****************************************************************************/

FILEHDRLIST *fileHdrStartPtr, *fileHdrCurrPtr;
		/* Start and current position in the list of file headers */

/* vvv This'll be the first thing up against the wall when the rewrite comes */
DIRHDRLIST **dirHdrList;			/* Table to hold directory structure */
static int currDirHdrListIndex;		/* Current pos.in list of dir.headers */
int currEntry;						/* Current index into directory array */
static int lastEntry;				/* Last used directory in dir.array */

PARTSIZELIST *partSizeStartPtr, *partSizeCurrPtr;
		/* Start and current position in the list of archive parts */

int currPart;						/* Current part no.of multipart archive */
int lastPart;						/* Last part no.of multipart archive */
static int segmentStartDisk;		/* Disk number of start of segment list */
static long segmentStartPos;		/* Position of start of segment list */
long segmentEnd;					/* End of current archive segment */

static NT_ENTRY **hashTable;		/* The table for hashing into nameTable */

static ARCHIVE_TRAILER archiveInfo;	/* The archive trailer info */

static LONG fileDataOffset;			/* Offset of current file data from start
									   of archive */
static LONG dirDataOffset;			/* Offset of current directory data from
									   start of directory data area */

/****************************************************************************
*																			*
*						Archive Directory Memory Usage						*
*																			*
****************************************************************************/

/* Struct sizes are as follows:

	FILEHDR			17 bytes		DIRHDR		 	 8 bytes
	FILEHDRLIST		22 bytes		DIRHDRLIST		36 bytes
	NT_ENTRY		12 bytes					  ----------
				  ----------						44 bytes + dirName
					51 bytes + fileName

   Data structure sizes are as follows:

	fileHdrList		entries limited by memory
	dirHdrList		8000 bytes, 2000 entries
	hashTable		16K bytes, 4096 entries (fixed size)
	nameTable		entries limited by memory
	--------------------------------------------------------
	Total :		  24,384 bytes */

/****************************************************************************
*																			*
*							General Work Functions							*
*																			*
****************************************************************************/

/* Add a file header to the lists of file headers */

static char *fileNamePtr;

void addFileHeader( FILEHDR *theHeader, WORD type )
	{
	FILEHDRLIST *fileHdrPrevPtr;
	int dirNo;

	/* Link the header into the list */
	if( fileHdrStartPtr == NULL )
		fileHdrCurrPtr = fileHdrStartPtr = ( FILEHDRLIST * ) hmalloc( sizeof( FILEHDRLIST ) );
	else
		{
		fileHdrCurrPtr->next = ( FILEHDRLIST * ) hmalloc( sizeof( FILEHDRLIST ) );
		fileHdrCurrPtr = fileHdrCurrPtr->next;
		}
	if( fileHdrCurrPtr == NULL )
		error( OUT_OF_MEMORY );
	fileHdrCurrPtr->next = NULL;
	fileHdrCurrPtr->data = *theHeader;
	fileHdrCurrPtr->offset = fileDataOffset;
	fileHdrCurrPtr->type = type;
	fileHdrCurrPtr->fileName = fileNamePtr;
	fileDataOffset += theHeader->dataLen + theHeader->auxDataLen;

	/* Update the head and tail pointers and link in the new header to the
	   list of files in this directory */
	if( ( dirNo = theHeader->dirIndex ) > lastEntry )
		/* Bad entry, move to ROOT_DIR */
		dirNo = theHeader->dirIndex = ROOT_DIR;
	if( ( fileHdrPrevPtr = dirHdrList[ dirNo ]->fileInDirListTail ) == NULL )
		/* Set up new list if necessary */
		dirHdrList[ dirNo ]->fileInDirListHead = fileHdrCurrPtr;
	else
		fileHdrPrevPtr->nextFile = fileHdrCurrPtr;
	dirHdrList[ dirNo ]->fileInDirListTail = fileHdrCurrPtr;
	fileHdrCurrPtr->prevFile = fileHdrPrevPtr;
	fileHdrCurrPtr->nextFile = NULL;
	}

/* Remove a file header from the lists of file headers */

void deleteFileHeader( FILEHDRLIST *theHeader )
	{
	FILEHDRLIST *nextPtr = theHeader->nextFile, *prevPtr = theHeader->prevFile;
	WORD dirNo = theHeader->data.dirIndex;

	/* Unlink this header from the list of files in this directory */
	if( prevPtr == NULL )
		{
		/* Delete from start of list */
		if( dirHdrList[ dirNo ]->fileInDirListTail == theHeader )
			/* Only header in list, set list to empty */
			dirHdrList[ dirNo ]->fileInDirListTail = NULL;
		dirHdrList[ dirNo ]->fileInDirListHead = nextPtr;
		}
	else
		/* Delete from middle/end of list */
		prevPtr->nextFile = nextPtr;
	if( nextPtr != NULL )
		nextPtr->prevFile = prevPtr;

	/* Free the header and associated fileName */
	hfree( theHeader->fileName );
	hfree( theHeader );
	}

/* Add a fileName to the fileNameList, checking for duplicate names */

static WORD oldHashValue;
static NT_ENTRY *nameTablePtr;

BOOLEAN addFileName( const WORD dirIndex, const WORD type, \
					 const char *fileName, const FD inFD )
	{
	int ch = TRUE;
	WORD hashValue = type;
	NT_ENTRY *tblEntry;
	int fileNameLen = 0;

	/* Insert the string in the name table.  A possible optimization at this
	   point is that if the filename is already in the filename list to not
	   insert it a second time but merely point to the first filename.  The
	   problem with this is that if the first filename is hfree()'d at a later
	   point the second reference will point to hyperspace */
	while( ch )
		{
		/* Get the next char in the name from the appropriate location.
		   Hashing the full name is probably a waste for > 5-odd chars,
		   but we still need to grovel through them all to get them into the
		   fileName list */
		if( inFD )
			{
			/* Read in char with sanity check:  With an archive which has been
			   corrupted just right we may go into an infinite loop of reading
			   EOF's or garbage here */
			if( ( ch = fgetByte( inFD ) ) == FEOF || fileNameLen >= _BUFSIZE )
				return( FALSE );
			}
		else
			ch = *fileName++;

#ifdef __UNIX__
		/* Check if we want to smash case */
		if( sysSpecFlags & SYSPEC_FORCELOWER )
			ch = tolower( ch );
#endif /* __UNIX__ */

		if( ch )	/* Don't hash the final '\0' */
			hashValue = ( hashValue << 1 ) ^ ch;
		mrglBuffer[ fileNameLen++ ] = ch;
		}
	hashValue &= HASHTABLE_SIZE - 1;				/* A faster MOD */

	/* Search the name table, with chaining in case of a collision */
	tblEntry = hashTable[ hashValue ];
	while( tblEntry != NULL )
		if( !strcmp( tblEntry->namePtr, ( char * ) mrglBuffer ) && \
					 tblEntry->dirIndex == dirIndex && tblEntry->type == type )
			return( /* tblEntry */ TRUE );	/* Already exists, exit */
		else
			tblEntry = tblEntry->next;

	/* Now add the new entry to the start of the list pointed to by hashtable
	   after remembering the current state for possible future use.  The chains
	   are organised in LRU order for no obvious reason */
	oldHashValue = hashValue;
	if( ( fileNamePtr = ( char * ) hmalloc( fileNameLen ) ) == NULL )
		error( OUT_OF_MEMORY );
	strcpy( fileNamePtr, ( char * ) mrglBuffer );
	if( ( nameTablePtr = ( NT_ENTRY * ) hmalloc( sizeof( NT_ENTRY ) ) ) == NULL )
		error( OUT_OF_MEMORY );
	nameTablePtr->namePtr = fileNamePtr;
	nameTablePtr->dirIndex = dirIndex;
	nameTablePtr->type = type;
	nameTablePtr->next = tblEntry;
	hashTable[ hashValue ] = nameTablePtr;

	/* Link the fileName to the header now if we can */
	if( inFD )
		fileHdrCurrPtr->fileName = fileNamePtr;

	return( FALSE );
	}

/* Delete the last filename entered */

void deleteLastFileName( void )
	{
	hashTable[ oldHashValue ] = nameTablePtr->next;
#ifdef __MSDOS__
	/* Undo the last hmalloc.  This works because there are no hmalloc()'s
	   between the addFileName() and deleteFileName() calls in FRONTEND.C */
	ungetMem();		/* Undo fileName malloc */
	ungetMem();		/* Undo nameTable malloc */
#else
	hfree( fileNamePtr );
#endif /* __MSDOS__ */
	}

/* Add a section size for a multipart archive */

void addPartSize( const long partSize )
	{
	/* Link the new part size into the list */
	if( partSizeStartPtr == NULL )
		partSizeCurrPtr = partSizeStartPtr = ( PARTSIZELIST * ) hmalloc( sizeof( PARTSIZELIST ) );
	else
		{
		partSizeCurrPtr->next = ( PARTSIZELIST * ) hmalloc( sizeof( PARTSIZELIST ) );
		partSizeCurrPtr = partSizeCurrPtr->next;
		}
	if( partSizeCurrPtr == NULL )
		error( OUT_OF_MEMORY );
	partSizeCurrPtr->next = NULL;
	partSizeCurrPtr->size = partSize;
	}

/* Determine which archive part a given data offset is in */

int getPartNumber( const long offset )
	{
	PARTSIZELIST *partSizePtr;
	int index;

	for( partSizePtr = partSizeStartPtr, index = 0; \
		 partSizePtr != NULL && offset >= partSizePtr->size; \
		 partSizePtr = partSizePtr->next, index++ );
	return( index );
	}

/* Get a given part of an archive */

static void readArcTrailer( void );

void getPart( const int thePart )
	{
	/* Ask for the wanted archive part */
	multipartWait( 0, thePart );
	readArcTrailer();

	/* Make sure we've got the right part */
	while( thePart != currPart )
		{
		multipartWait( 0, thePart );
		readArcTrailer();
		}
	}

/* Set up the vars used */

void initArcDir( void )
	{
	if( ( hashTable = ( NT_ENTRY ** ) hmalloc( HASHTABLE_SIZE * sizeof( NT_ENTRY * ) ) ) == NULL || \
		( dirHdrList = ( DIRHDRLIST ** ) hmalloc( MEM_BUFSIZE ) ) == NULL )
		error( OUT_OF_MEMORY );

	/* Initially there is no list of headers - this initial reset is necessary
	   to stop resetArcDir() trying to free nonexistant header lists */
	fileHdrStartPtr = NULL;
	partSizeStartPtr = NULL;

#ifndef __MSDOS__
	/* Set dirHdrList to empty so we don't try and free it in freeHdrLists() */
	dirHdrList[ ROOT_DIR ] = NULL;
#endif /* __MSDOS__ */
	}

#ifndef __MSDOS__

/* Free the mem used in the list of headers + strings */

static void freeHdrLists( void )
	{
	FILEHDRLIST *fileHdrCursor = fileHdrStartPtr, *fileHdrHeaderPtr;
	PARTSIZELIST *partSizeCursor = partSizeStartPtr, *partSizeHeaderPtr;
	NT_ENTRY *nameTblCursor, *nameTblPtr;
	int theEntry, nextEntry;

	/* Free the fileHdr list */
	while( fileHdrCursor != NULL )
		{
		fileHdrHeaderPtr = fileHdrCursor;
		fileHdrCursor = fileHdrCursor->next;
		hfree( fileHdrHeaderPtr->fileName );
		hfree( fileHdrHeaderPtr );
		}

	/* Free the dirHdr list */
	if( dirHdrList[ ROOT_DIR ] != NULL )
		for( theEntry = dirHdrList[ ROOT_DIR ]->next; theEntry != END_MARKER; \
			 theEntry = nextEntry )
			{
			nextEntry = dirHdrList[ theEntry ]->next;
			hfree( dirHdrList[ theEntry ]->dirName );
			hfree( dirHdrList[ theEntry ] );
			}

	/* Free the name table lists.  We must be careful not to free the
	   associated fileNames since they have already been freed as part of
	   the fileHdr freeing process */
	for( theEntry = 0; theEntry < HASHTABLE_SIZE; theEntry++ )
		{
		nameTblCursor = hashTable[ theEntry ];
		while( nameTblCursor != NULL )
			{
			nameTblPtr = nameTblCursor;
			nameTblCursor = nameTblCursor->next;
			hfree( nameTblPtr );
			}
		}

	/* Free the archive part size list */
	while( partSizeCursor != NULL )
		{
		partSizeHeaderPtr = partSizeCursor;
		partSizeCursor = partSizeCursor->next;
		hfree( partSizeHeaderPtr );
		}

	/* Reset header list pointer */
	fileHdrStartPtr = NULL;
	partSizeStartPtr = NULL;
	}

void endArcDir( void )
	{
	freeHdrLists();
	hfree( dirHdrList );
	hfree( hashTable );
	}
#else

void resetArcDirMem( void )
	{
	releaseMem();	/* Ah, the joys of a single-user OS */
	}
#endif /* !__MSDOS__ */

/* Reset various pointers and arrays for each new archive handled */

void resetArcDir( void )
	{
	int theEntry;

	/* Clear out the hash table */
	for( theEntry = 0; theEntry < HASHTABLE_SIZE; theEntry++ )
		hashTable[ theEntry ] = NULL;

	/* Set up initial table indices */
	currDirHdrListIndex = 1;			/* Room for ROOT_DIR header */
	currEntry = lastEntry = ROOT_DIR;   /* Entries added off root dir */
	currPart = lastPart = 0;			/* Only one part to archive */

	/* Free the various lists of headers */
#ifndef __MSDOS__
	freeHdrLists();
#else
	fileHdrStartPtr = NULL;
	partSizeStartPtr = NULL;	/* Reset header list pointers */
	markMem();	/* Cut back the heap to this point later on */
#endif /* !__MSDOS__ */
	fileDataOffset = HPACK_ID_SIZE;	/* Begin at start of archive */
	dirDataOffset = 0L;				/* No directory data to start with */

	/* Create a dummy header for the root directory.  Only some fields need
	   to be set up since the other fields are ignored by the various
	   directory-handling routines */
	if( ( dirHdrList[ ROOT_DIR ] = ( DIRHDRLIST * ) hmalloc( sizeof( DIRHDRLIST ) ) ) == NULL )
		error( OUT_OF_MEMORY );
	dirHdrList[ ROOT_DIR ]->dirIndex = ROOT_DIR;
	dirHdrList[ ROOT_DIR ]->next = END_MARKER;
	dirHdrList[ ROOT_DIR ]->data.dirTime = 0L;
	dirHdrList[ ROOT_DIR ]->data.parentIndex = ROOT_DIR;
	dirHdrList[ ROOT_DIR ]->fileInDirListHead = \
		dirHdrList[ ROOT_DIR ]->fileInDirListTail = NULL;
	dirHdrList[ ROOT_DIR ]->dirInDirListHead = \
		dirHdrList[ ROOT_DIR ]->dirInDirListTail = NULL;
	dirHdrList[ ROOT_DIR ]->dirName = ( char * ) hmalloc( 1 );	/* No need for NULL chk */
	*dirHdrList[ ROOT_DIR ]->dirName = '\0';	/* The dir with no name */

	/* Reset the directory data buffer */
	dirBufCount = 0;
	}

/* Return the current state of the archive directory data structures.
   doFixEverything can safely be initialized statically since as soon
   as it is set to FALSE we exit due to the error processing */

static BOOLEAN doFixEverything = TRUE;

void getArcdirState( FILEHDRLIST **hdrListEnd, int *dirEnd )
	{
	*hdrListEnd = fileHdrCurrPtr;
	*dirEnd = currEntry;
	}

/* Set the current archive directory structures.  The doFixEverything flag
   must be set to false at this point to make sure we don't call
   fixEverything() when performing error recovery, since calling
   fixEverything() will rebuild the directory tree into an invalid (read:
   stuffed) state */

void setArcdirState( FILEHDRLIST *hdrListEnd, const int dirEnd )
	{
#ifndef __MSDOS__
	FILEHDRLIST *fileHdrCursor = hdrListEnd->next, *fileHdrPtr;
#endif /* !__MSDOS__ */

	if( hdrListEnd != NULL )	/* This may be NULL if no files */
		{
#ifndef __MSDOS__
		/* Remove all file headers after the cutoff point */
		while( fileHdrCursor != NULL )
			{
			fileHdrPtr = fileHdrCursor;
			fileHdrCursor = fileHdrCursor->next;
			deleteFileHeader( fileHdrPtr );
			}
#endif /* !__MSDOS__ */
		hdrListEnd->next = NULL;
		}
	dirHdrList[ dirEnd ]->next = END_MARKER;
	doFixEverything = FALSE;
	}

/****************************************************************************
*																			*
*						Archive Directory Handling Functions				*
*																			*
****************************************************************************/

/* Pointers into the the fileHdrList and dirHdrList, used by the
   getFirst/NextFileEntry() and getFirst/NextDirEntry() routines */

static FILEHDRLIST *filePtr;
static DIRHDRLIST *dirPtr;

/* The current directory being handled by getFirstDir/getNextDir() */

static WORD currDir;

/* Add a directory header to the directory-by-directory list of its parent
   directory */

static void addDirHdrToList( DIRHDRLIST *theHeader )
	{
	int dirNo = theHeader->data.parentIndex;
	DIRHDRLIST *dirHdrPrevPtr;

	if( dirNo > lastEntry )
		/* Bad entry, move to ROOT_DIR */
		dirNo = theHeader->data.parentIndex = ROOT_DIR;

	/* Update the dir head and tail pointers and link in the new header */
	if( ( dirHdrPrevPtr = dirHdrList[ dirNo ]->dirInDirListTail ) == NULL )
		/* Set up new list if necessary */
		dirHdrList[ dirNo ]->dirInDirListHead = theHeader;
	else
		dirHdrPrevPtr->nextDir = theHeader;
	dirHdrList[ dirNo ]->dirInDirListTail = theHeader;
	theHeader->prevDir = dirHdrPrevPtr;
	theHeader->nextDir = NULL;
	}

/* Add a directory name to the list of directory names */

void addDirName( char *dirName, const LONG dirTime )
	{
	DIRHDRLIST *theHeader;

	if( ( theHeader = ( DIRHDRLIST * ) hmalloc( sizeof( DIRHDRLIST ) ) ) == NULL )
		error( OUT_OF_MEMORY );
	dirHdrList[ lastEntry + 1 ] = theHeader;
	currDirHdrListIndex++;
	if( currDirHdrListIndex >= MEM_BUFSIZE )
		error( OUT_OF_MEMORY );

	/* Link in new header */
	dirHdrList[ lastEntry ]->next = lastEntry + 1;
	theHeader->data.parentIndex = currEntry;
	theHeader->data.dirTime = dirTime;
	theHeader->data.dataLen = 0;
	theHeader->fileInDirListHead = theHeader->fileInDirListTail = NULL;
	theHeader->dirInDirListHead = theHeader->dirInDirListTail = NULL;
	theHeader->offset = dirDataOffset;
	theHeader->next = END_MARKER;
	theHeader->dirIndex = lastEntry + 1;

	/* Add the header to the directory-by-directory list */
	lastEntry++;
	currEntry = lastEntry;
	addDirHdrToList( theHeader );

#ifdef __UNIX__
	/* Check if we want to smash case */
	if( sysSpecFlags & SYSPEC_FORCELOWER )
		strlwr( dirName );
#endif /* __UNIX__ */

	/* Add the directory name */
	if( ( theHeader->dirName = ( char * ) hmalloc( strlen( dirName ) + 1 ) ) == NULL )
		error( OUT_OF_MEMORY );
	strcpy( theHeader->dirName, dirName );
	}

/* Write out directory data tag */

void addDirData( const WORD tagID, WORD tagLength )
	{
	if( !dirFileFD )
		{
		/* Create a temporary file to hold any relevant directory
		   information if necessary.  We could do this automatically in
		   FRONTEND.C, but by doing it here we only create it if there
		   is a need to */
		strcpy( dirFileName, errorFileName );
		strcpy( dirFileName + strlen( dirFileName ) - 3, DIRTEMP_EXT );
		if( ( dirFileFD = hcreat( dirFileName, CREAT_ATTR ) ) == IO_ERROR )
			error( CANNOT_OPEN_TEMPFILE );
		}

	/* Write the tag as either a short or a long tag */
	if( tagLength < SHORT_TAGLEN )
		fputDirWord( tagID | tagLength );
	else
		{
		fputDirWord( tagID );
		fputDirWord( tagLength );
		}

	/* Update data sizes */
	if( !tagLength )
		tagLength = extractTagLen( tagID );		/* Tag has implicit length */
	dirHdrList[ currEntry ]->data.dataLen += TAGSIZE + tagLength;
	dirDataOffset += TAGSIZE + tagLength;
	}

/* Move to the start of the directory data in the archive */

void movetoDirData( void )
	{
	hlseek( archiveFD, fileDataOffset, SEEK_SET );
	}

/* Set the current archive directory */

inline void setArchiveCwd( const WORD dirNo )
	{
	currEntry = dirNo;
	}

/* Go back up one directory level in the dirNameIndex */

inline void popDir( void )
	{
	currEntry = dirHdrList[ currEntry ]->data.parentIndex;
	}

/* Return the parent of the current directory */

inline WORD getParent( const WORD dirNo )
	{
	return( dirHdrList[ dirNo ]->data.parentIndex );
	}

/* Return the name of the specified directory */

inline char *getDirName( const WORD dirNo )
	{
	return( dirHdrList[ dirNo ]->dirName );
	}

/* Return the creation date of the specified directory */

inline LONG getDirTime( const WORD dirNo )
	{
	return( dirHdrList[ dirNo ]->data.dirTime );
	}

/* Set the creation date of the specified directory */

inline void setDirTime( const WORD dirNo, const LONG dirTime )
	{
	dirHdrList[ dirNo ]->data.dirTime = dirTime;
	}

/* Return the length of the specified directories data */

inline WORD getDirAuxDatalen( const WORD dirNo )
	{
	return( dirHdrList[ dirNo ]->data.dataLen );
	}

/* Sort the files in a directory by name.  This routine uses a modified
   insertion sort whose runtime is O( kn ) where k is the number of files out
   of order.  This algorithm runs in linear time when the files are mostly in
   order, which is usually the case.  In contrast a more advanced algorithm
   like quicksort would run in O( n^2 ) time and require O( n ) stack space
   for recursion in a similar situation.  The best algorithm is actually a
   mergesort, but the code is more than twice as long */

void sortFiles( const WORD dirNo )
	{
	FILEHDRLIST *oldStartPtr = dirHdrList[ dirNo ]->fileInDirListHead;
	FILEHDRLIST *newStartPtr, *newEndPtr;
	FILEHDRLIST *oldCurrent, *newCurrent, *prev;
	char *fileName;

	newEndPtr = newStartPtr = oldStartPtr;
	if( newStartPtr != NULL )
		{
		/* Build first node of new list */
		oldCurrent = oldStartPtr->nextFile;
		newStartPtr->nextFile = NULL;

		/* Copy the old list across to the new list, sorting it as we go */
		while( oldCurrent != NULL )
			{
			fileName = oldCurrent->fileName;
			if( strcmp( newEndPtr->fileName, fileName ) < 0 )
				{
				/* Filename is in order, just append node to end of new list */
				newCurrent = oldCurrent;
				oldCurrent = oldCurrent->nextFile;	/* Go to next node in old list */

				/* Link node to end of list and set newEnd ptr */
				newEndPtr->nextFile = newCurrent;
				newCurrent->prevFile = newEndPtr;
				newCurrent->nextFile = NULL;
				newEndPtr = newCurrent;
				}
			else
				{
				/* Find correct position in new list to insert node from old list */
				prev = newCurrent = newStartPtr;
				while( ( newCurrent != NULL ) && strcmp( newCurrent->fileName, fileName ) < 0 )
					{
					prev = newCurrent;
					newCurrent = newCurrent->nextFile;
					}

				/* Remember end of new list for shortcut add */
				if( newCurrent == NULL )
					newEndPtr = oldCurrent;

				/* Link node from old list into new list */
				if( prev == newCurrent )
					{
					/* At start of list, set node to new list start */
					newStartPtr = oldCurrent;
					newStartPtr->prevFile = NULL;
					}
				else
					{
					/* Add link to previous node */
					prev->nextFile = oldCurrent;
					oldCurrent->prevFile = prev;
					}

				/* Add link to next node */
				prev = oldCurrent->nextFile;	/* Use prev for temporary storage */
				oldCurrent->nextFile = newCurrent;
				newCurrent->prevFile = oldCurrent;
				oldCurrent = prev;
				}
			}

		/* Set fileInDirListHead to point to start of sorted list */
		dirHdrList[ dirNo ]->fileInDirListHead = newStartPtr;
		}
	}

/* Return the first entry in the file-in-directory list, or NULL if no files */

inline FILEHDRLIST *getFirstFileEntry( const WORD dirNo )
	{
	return( filePtr = dirHdrList[ dirNo ]->fileInDirListHead );
	}

/* Return the next entry in the file-in-directory list, or NULL if none */

inline FILEHDRLIST *getNextFileEntry( void )
	{
	return( filePtr = filePtr->nextFile );
	}

/* Return the first entry in the directory-in-directory list, or NULL if no files */

inline DIRHDRLIST *getFirstDirEntry( const WORD dirNo )
	{
	return( dirPtr = dirHdrList[ dirNo ]->dirInDirListHead );
	}

/* Return the next entry in the directory-in-directory list, or NULL if none */

inline DIRHDRLIST *getNextDirEntry( void )
	{
	return( dirPtr = dirPtr->nextDir );
	}

/* Return the first directory in the directory tree */

inline WORD getFirstDir( void )
	{
	currDir = ROOT_DIR;
	return( ROOT_DIR );
	}

/* Return the next directory in the directory tree */

inline WORD getNextDir( void )
	{
	currDir = dirHdrList[ currDir ]->next;
	return( currDir );
	}

/* Determine whether a given path is contained in the archives directory
   structure.  It would be easier to do the matching backwards since a
   directory can only ever have one parent and so we don't have to search a
   list of directory names; however this won't work because we don't know in
   advance the directory index of the bottom directory */

int matchPath( const char *pathName, const int pathLen, WORD *pathDirIndex )
	{
	BOOLEAN matched, hasSlash = ( *pathName == '/' ) ? TRUE : FALSE;
	int startIndex = hasSlash, endIndex, segmentLen;
	WORD currDirIndex = ROOT_DIR;
	DIRHDRLIST *currDirPtr, *prevDirPtr;
	char *dirName;

	*pathDirIndex = ROOT_DIR;	/* Initially we're at the root directory */

	/* Check for the trivial case of the path being to the archive's root
	   directory */
	if( !pathLen )
		return( PATH_FULLMATCH );

	while( TRUE )
		{
		/* Extract a directory name out of the pathname */
		endIndex = startIndex;
		while( endIndex < pathLen && pathName[ endIndex ] != '/' )
			endIndex++;

		/* Now search through the list of subdirectories in this directory
		   trying to find a match */
		currDirPtr = dirHdrList[ currDirIndex ]->dirInDirListHead;
		segmentLen = endIndex - startIndex;
		matched = FALSE;
		if( currDirPtr != NULL )
			do
				{
				dirName = currDirPtr->dirName;

				/* We must not only check that the two directory names are
				   equal but also that they are of the same length, since
				   we could get an erroneous match if one directory name is
				   merely a prefix of another */
				if( !strncmp( pathName + startIndex, dirName, segmentLen ) && \
							  segmentLen == strlen( dirName ) )
					{
					matched = TRUE;
					break;
					}
				}
#pragma warn -pia
			while( currDirPtr = currDirPtr->nextDir );
#pragma warn +pia

		if( endIndex == pathLen || !matched )
			/* We've reached the end of the pathname */
			break;

		startIndex = endIndex + 1;		/* +1 skips the '/' */
		prevDirPtr = currDirPtr;
		currDirIndex = currDirPtr->dirIndex;
		}

	/* Determine the nature of the match */
	if( matched )
		{
		/* Full match: currDirPtr contains the directory index */
		*pathDirIndex = currDirPtr->dirIndex;
		return( PATH_FULLMATCH );
		}
	else
		if( startIndex == hasSlash )
			/* No match at all */
			return( PATH_NOMATCH );
		else
			{
			/* Partial match: prevDirPtr contains last matched directory */
			*pathDirIndex = prevDirPtr->dirIndex;
			return( PATH_PARTIALMATCH );
			}
	}

/* Clean up the archive directory tree by turning it into a correct depth-
   first traversal with contiguous directory indices.  Note that since this
   procedure rearranges the order of the directories within the archive it
   will destroy the correspondence of the dirData to the directory entries */

#define MAX_DIR_NESTING	50	/* Shouldn't get > 50 nested directories */

static void fixEverything( void )
	{
	BOOLEAN skipFind = FALSE, moreDirs = TRUE;
	FILEHDRLIST *fileInfo;
	DIRHDRLIST *dirPtr, *dirPtrStack[ MAX_DIR_NESTING ];
	WORD dirStack[ MAX_DIR_NESTING ];
	int dirNo, currentLevel = 0, currCount = 0, lastCount = 0;

	if( ( dirPtr = dirHdrList[ ROOT_DIR ]->dirInDirListHead ) == NULL )
		moreDirs = FALSE;
	else
		skipFind = TRUE;

	lastEntry = ROOT_DIR;
	while( TRUE )
#pragma warn -pia
		if( moreDirs && ( skipFind || ( dirPtr = dirPtr->nextDir ) ) )
#pragma warn +pia
			{
			skipFind = FALSE;
			dirPtrStack[ currentLevel ] = dirPtr;
			dirStack[ currentLevel++ ] = currCount;
			if( currentLevel > MAX_DIR_NESTING )
				error( TOO_MANY_LEVELS_NESTING );

			/* Set correct directory number and rebuild chain of directories
			   in correct order */
			dirNo = dirPtr->dirIndex;
			dirHdrList[ dirNo ]->data.parentIndex = currCount;
			lastCount++;
			currCount = lastCount;
			dirHdrList[ lastEntry ]->next = dirNo;
			lastEntry = dirNo;

			/* Process all files in this directory.  We never bother doing
			   ROOT_DIR since all files in this automatically have the correct
			   directory index */
			if( ( fileInfo = getFirstFileEntry( dirNo ) ) != NULL )
				do
					fileInfo->data.dirIndex = lastCount;
				while( ( fileInfo = getNextFileEntry() ) != NULL );

			if( ( dirPtr = dirHdrList[ dirNo ]->dirInDirListHead ) == NULL )
				moreDirs = FALSE;
			else
				skipFind = TRUE;
			}
		else
			if( currentLevel )
				{
				dirPtr = dirPtrStack[ --currentLevel ];
				currCount = dirStack[ currentLevel ];
				moreDirs = TRUE;
				}
			else
				break;

	dirHdrList[ lastEntry ]->next = END_MARKER;
	}

/* Calculate the size of a header as it will be written to disk */

int computeHeaderSize( const FILEHDR *theHeader )
	{
	int headerSize = sizeof( WORD ) + sizeof( LONG );

	headerSize += ( theHeader->fileLen > 0xFFFF ) ? \
		sizeof( LONG ) : sizeof( WORD );
	headerSize += ( theHeader->dataLen > 0xFFFF ) ? \
		sizeof( LONG ) : sizeof( WORD );
	headerSize += ( theHeader->dirIndex > 0xFF ) ? sizeof( WORD ) + sizeof( WORD ) : \
				  ( theHeader->auxDataLen > 0xFF ) ? sizeof( BYTE ) + sizeof( WORD ) : \
				  ( theHeader->dirIndex || theHeader->auxDataLen ) ? \
					sizeof( BYTE ) + sizeof( BYTE ) : 0;

	return( headerSize );
	}

/****************************************************************************
*																			*
*						Read a Directory from a File						*
*																			*
****************************************************************************/

/* Read the file headers from a file */

static void readFileHeaders( WORD noFileHdrs )
	{
	FILEHDR theHeader;
	WORD type;

	while( noFileHdrs-- )
		{
		/* Assemble each header and add it to the directory tree */
		type = TYPE_NORMAL;		/* Reset header type */
		theHeader.archiveInfo = fgetWord( archiveFD );
		switch( theHeader.archiveInfo & ARCH_OTHER_LEN )
			{
			case OTHER_ZERO_ZERO:
				/* dirIndex = ROOT_DIR, extraLen = 0 */
				theHeader.dirIndex = ROOT_DIR;
				theHeader.auxDataLen = 0;
				break;

			case OTHER_BYTE_BYTE:
				/* dirIndex = BYTE, extraLen = BYTE */
				theHeader.dirIndex = ( WORD ) fgetByte( archiveFD );
				theHeader.auxDataLen = ( WORD ) fgetByte( archiveFD );
				break;

			case OTHER_BYTE_WORD:
				/* dirIndex = BYTE, extraLen = WORD */
				theHeader.dirIndex = ( WORD ) fgetByte( archiveFD );
				theHeader.auxDataLen = fgetWord( archiveFD );
				break;

			case OTHER_WORD_WORD:
				/* dirIndex = WORD, extraLen = WORD */
				theHeader.dirIndex = fgetWord( archiveFD );
				theHeader.auxDataLen = fgetWord( archiveFD );
			}
		theHeader.fileTime = fgetLong( archiveFD );
		if( theHeader.archiveInfo & ARCH_ORIG_LEN )
			theHeader.fileLen = fgetLong( archiveFD );
		else
			theHeader.fileLen = ( LONG ) fgetWord( archiveFD );
		if( theHeader.archiveInfo & ARCH_COPR_LEN )
			theHeader.dataLen = fgetLong( archiveFD );
		else
			theHeader.dataLen = ( LONG ) fgetWord( archiveFD );

		/* Handle type SPECIAL files by reading in the extra WORD giving
		   the file's type */
		if( ( theHeader.archiveInfo & ARCH_STORAGE ) == FORMAT_SPECIAL )
			type = fgetWord( archiveFD );

		addFileHeader( &theHeader, type );
		}
	}

/* Read the filenames from a file */

static void readFileNames( void )
	{
	FILEHDRLIST *prevPtr = NULL;

	/* Step along the chain of headers reading in the corresponding filenames */
	for( fileHdrCurrPtr = fileHdrStartPtr; fileHdrCurrPtr != NULL; \
		 prevPtr = fileHdrCurrPtr, fileHdrCurrPtr = fileHdrCurrPtr->next )
		addFileName( fileHdrCurrPtr->data.dirIndex, fileHdrCurrPtr->type, NULL, archiveFD );

	fileHdrCurrPtr = prevPtr;	/* Reset currPos to last header */
	}

/* Read the directory headers from a file */

static void readDirHeaders( WORD noDirHdrs )
	{
	WORD theEntry;
	DIRHDRLIST *theHeader;

	if( noDirHdrs )
		{
		while( noDirHdrs-- )
			{
			/* Add each header to the directory tree */
			if( ( theHeader = ( DIRHDRLIST * ) hmalloc( sizeof( DIRHDRLIST ) ) ) == NULL )
				error( OUT_OF_MEMORY );
			currDirHdrListIndex++;
			if( currDirHdrListIndex >= MEM_BUFSIZE )
				error( OUT_OF_MEMORY );

			dirHdrList[ currEntry ]->next = currEntry + 1;
			dirHdrList[ ++currEntry ] = theHeader;
			theHeader->offset = dirDataOffset;
			theHeader->dirIndex = currEntry;
			theHeader->data.parentIndex = fgetWord( archiveFD );
			theHeader->data.dataLen = fgetWord( archiveFD );
			theHeader->data.dirTime = fgetLong( archiveFD );
			theHeader->fileInDirListHead = theHeader->fileInDirListTail = NULL;
			theHeader->dirInDirListHead = theHeader->dirInDirListTail = NULL;
			dirDataOffset += theHeader->data.dataLen;
			}
		theHeader->next = END_MARKER;
		}
	lastEntry = currEntry;

	/* We've read in all the directories, now create the list of directories
	   inside directories (this has to be done after all the directories are
	   read in since they will not necessarily be in the correct order as they
	   are read) */
	for( theEntry = dirHdrList[ ROOT_DIR ]->next; theEntry != END_MARKER; \
		 theEntry = dirHdrList[ theEntry ]->next )
		addDirHdrToList( dirHdrList[ theEntry ] );
	}

/* Read the directory names from a file */

static void readDirNames( void )
	{
	WORD theEntry;
	int dirNameLength, ch;

	/* Read in directory names */
	for( theEntry = dirHdrList[ ROOT_DIR ]->next; theEntry != END_MARKER; \
		 theEntry = dirHdrList[ theEntry ]->next )
		{
		/* Read in directory name with sanity check */
		dirNameLength = 0;
#pragma warn -pia
		while( ( ch = fgetByte( archiveFD ) ) && ch != FEOF )
#pragma warn +pia
#ifdef __UNIX__
			/* Check if we want to smash case */
			if( sysSpecFlags & SYSPEC_FORCELOWER )
				mrglBuffer[ dirNameLength++ ] = tolower( ch );
			else
#endif /* __UNIX__ */
			mrglBuffer[ dirNameLength++ ] = ch;
		mrglBuffer[ dirNameLength++ ] = '\0';

		if( ( dirHdrList[ theEntry ]->dirName = \
					( char * ) hmalloc( dirNameLength ) ) == NULL )
			error( OUT_OF_MEMORY );
		strcpy( dirHdrList[ theEntry ]->dirName, ( char * ) mrglBuffer );
		}
	}

/* Read in the section sizes for a multipart archive */

static void readPartSizes( void )
	{
	int count = lastPart;

	/* Read in each sections size and set the current part to the last part
	   read */
	while( count-- )
		addPartSize( fgetLong( archiveFD ) );
	currPart = lastPart;
	}

/* Read the archive trailer information from a file */

static void getArchiveInfo( const BOOLEAN readID )
	{
	archiveInfo.noDirHdrs = fgetWord( archiveFD );
	archiveInfo.noFileHdrs = fgetWord( archiveFD );
	archiveInfo.dirInfoSize = fgetLong( archiveFD );
	checksumEnd( INPUT );
	archiveInfo.checksum = fgetWord( archiveFD );

	if( readID )
		{
		archiveInfo.specialInfo = fgetByte( archiveFD );

		/* We must use fgetByte() to get the archive ID since fgetLong() will
		   do endianness conversion */
		archiveInfo.archiveID[ 0 ] = fgetByte( archiveFD );
		archiveInfo.archiveID[ 1 ] = fgetByte( archiveFD );
		archiveInfo.archiveID[ 2 ] = fgetByte( archiveFD );
		archiveInfo.archiveID[ 3 ] = fgetByte( archiveFD );
		}
	}

/* Save the directory data to a temporary file */

static void saveDirData( void )
	{
	/* Open a temporary file (with the same reason given in FRONTEND.C for
	   using the archive name with the DIRTEMP_EXT suffix) and move the
	   directory data to it */
	strcpy( dirFileName, errorFileName );
	strcpy( dirFileName + strlen( dirFileName ) - 3, DIRTEMP_EXT );
	if( ( dirFileFD = hcreat( dirFileName, CREAT_ATTR ) ) == IO_ERROR )
		error( CANNOT_OPEN_TEMPFILE );
	hlseek( archiveFD, fileDataOffset, SEEK_SET );
	moveData( archiveFD, dirFileFD, dirDataOffset );
	flush( dirFileFD );
	}

/*  Save the security data to a temporary file */

static void saveSecData( void )
	{
	/* Open a temporary file and move the data as above */
	strcpy( secFileName, errorFileName );
	strcpy( secFileName + strlen( secFileName ) - 3, SECTEMP_EXT );
	if( ( secFileFD = hcreat( secFileName, CREAT_ATTR ) ) == IO_ERROR )
		error( CANNOT_OPEN_TEMPFILE );
	memcpy( _inBuffer, _inBuffer + TRAILER_SIZE - HPACK_ID_SIZE, secInfoLen );
	writeBuffer( secFileFD, secInfoLen );
	}

/* Read in the trailer information at the very end of an archive */

static int paddingSize;		/* No.bytes ^Z padding found by readArcTrailer() */

static void readArcTrailer( void )
	{
	BOOLEAN notArchive;
	int bytesRead;

	/* Make sure this is an HPACK archive */
	paddingSize = 0;
	hlseek( archiveFD, -( LONG ) TRAILER_SIZE, SEEK_END );
	segmentEnd = htell( archiveFD );
	resetFastIn( archiveFD );
	getArchiveInfo( READ_ID );
	if( memcmp( archiveInfo.archiveID, HPACK_ID, HPACK_ID_SIZE ) )
		{
		notArchive = TRUE;
		if( archiveInfo.archiveID[ 3 ] == CPM_EOF )
			{
			/* This may be a valid archive with CPM EOF's added to the end.
			   Try and find a valid HPACK ID before the ^Z's */
			hlseek( archiveFD, -( LONG ) ( HPACK_ID_SIZE + YMODEM_BLOCKSIZE ), SEEK_END );
			if( htell( archiveFD ) < 0L )
				/* We've gone past the start of the file; just seek to the
				   start */
				hlseek( archiveFD, 0L, SEEK_SET );
			bytesRead = hread( archiveFD, _inBuffer, HPACK_ID_SIZE + YMODEM_BLOCKSIZE );
			for( paddingSize = bytesRead - 1; paddingSize >= HPACK_ID_SIZE && \
							  _inBuffer[ paddingSize ] == CPM_EOF; paddingSize-- );
			paddingSize++;	/* Fix fencepost error */
			if( !memcmp( _inBuffer + paddingSize - HPACK_ID_SIZE, HPACK_ID, HPACK_ID_SIZE ) )
				{
				/* It is an HPACK archive, try to truncate the ^Z padding.  If
				   we can't, remember the offset of the start of any useful data */
				notArchive = FALSE;
				paddingSize = bytesRead - paddingSize;
				hlseek( archiveFD, -( LONG ) paddingSize, SEEK_END );
				if( htruncate( archiveFD ) != IO_ERROR )
					{
					hprintf( WARN_TRUNCATED_u_BYTES_EOF_PADDING, paddingSize );
					paddingSize = 0;
					}

				/* Re-read the trailer info */
				hlseek( archiveFD, -( long ) ( TRAILER_SIZE + paddingSize ), SEEK_END );
				segmentEnd = htell( archiveFD );
				resetFastIn( archiveFD );
				getArchiveInfo( READ_ID );
				}
			}

		if( notArchive )
			error( NOT_HPACK_ARCHIVE );
		}

	/* If not end of a multipart archive, adjust for size of extra fields */
	if( archiveInfo.specialInfo & SPECIAL_MULTIPART )
		segmentEnd += sizeof( WORD ) + sizeof( WORD ) + sizeof( WORD );
	}

/* Read the archive directory into memory */

void readArcDir( const BOOLEAN doSaveDirData )
	{
	long securedDataLen;

	/* Read in the trailer information */
	readArcTrailer();
	if( archiveInfo.specialInfo & SPECIAL_MULTIPART )
		/* This is part of a multipart archive, prompt for the last part */
		while( !( archiveInfo.specialInfo & SPECIAL_MULTIEND ) )
			{
			hclose( archiveFD );
			multipartWait( WAIT_PARTNO | WAIT_LASTPART, archiveInfo.checksum );
			if( ( archiveFD = hopen( errorFileName, O_RDONLY ) ) == ERROR )
				error( CANNOT_OPEN_ARCHFILE, errorFileName );
			readArcTrailer();
			}

	/* Perform bootstrap read for multipart archives */
	if( archiveInfo.specialInfo & SPECIAL_MULTIEND )
		{
		/* Set special status flag */
		flags |= MULTIPART_ARCH;

		/* Move the information from the archiveInfo fields into the segment
		   information which they overlay */
		lastPart = archiveInfo.noDirHdrs;
		segmentStartDisk = archiveInfo.noFileHdrs;
		segmentStartPos = archiveInfo.dirInfoSize;

		/* Read in the segmentation information */
		hlseek( archiveFD, segmentStartPos + HPACK_ID_SIZE, SEEK_SET );
		resetFastIn( archiveFD );
		checksumBegin( INPUT );
		readPartSizes();
		getArchiveInfo( NO_READ_ID );	/* For checksumming purposes */
		if( crc16 != archiveInfo.checksum )
			/* Directory data was corrupted, confirm to continue */
			idiotBox( MESG_ARCHIVE_DIRECTORY_CORRUPTED );

		/* Then panic */
		hputs( "Can't read multipart archives yet" );
		error( INTERNAL_ERROR );
		}

	/* Can't read encrypted archives yet (normally we would check the
	   encryption method and exit if we don't have any key information) */
	if( archiveInfo.specialInfo & SPECIAL_ENCRYPTED )
		error( CANNOT_READ_CRYPT_ARCH );

	/* Handle archive security if secured archive */
	if( archiveInfo.specialInfo & SPECIAL_SECURED )
		{
		/* Read in archive trailer and security info.  The length of this
		   field is given by archiveTrailer.checksum, which overlays the
		   length field.  The length of the secured data is the current
		   position plus the trailer size minus the size of the ID at the
		   start and the ID and kludge bytes which aren't part of the trailer
		   any more but are at the end of the archive */
		secInfoLen = archiveInfo.checksum;
		hlseek( archiveFD, -( LONG ) ( sizeof( WORD ) + secInfoLen + \
								   ( TRAILER_SIZE ) + paddingSize ), SEEK_END );
		securedDataLen = htell( archiveFD ) + TRAILER_SIZE - \
						 ( ( 2 * HPACK_ID_SIZE ) + sizeof( BYTE ) );
		resetFastIn( archiveFD );
		getArchiveInfo( NO_READ_ID );

		/* If it's a multipart archive the security info check can take
		   a while, so we ask the luser whether they want to do it or not */
		if( !( flags & MULTIPART_ARCH ) || \
			confirmAction( MESG_VERIFY_SECURITY_INFO ) )
			{
			if( choice == EXTRACT || choice == TEST || choice == DISPLAY )
				{
				/* Check the entire archive */
				hputs( MESG_VERIFYING_ARCHIVE_AUTHENTICITY );
				checkSignature( ( LONG ) HPACK_ID_SIZE, securedDataLen );
				}
			else
				{
				/* Make sure the user wants to overwrite the security info */
				if( choice != VIEW )
					idiotBox( MESG_SECURITY_INFO_WILL_BE_DESTROYED );

				/* Save the information for later recovery if necessary */
				if( choice == ADD )
					saveSecData();
				}
			}

		/* Now treat security info as padding */
		paddingSize += secInfoLen + sizeof( WORD );
		}

	/* Check this is the correct version of archive/HPACK */
	if( !isPrototype( archiveInfo.specialInfo ) )
		hprintf( "Please upgrade to a non-prototype HPACK release\n" );
	else
		if( ( archiveInfo.specialInfo & 0xE0 ) != PROTOTYPE )
			{
			hputs( "Peter has been messing with the filekludge again" );
			error( INTERNAL_ERROR );
			}

	/* Read in archive directory */
	if( hlseek( archiveFD, -( ( long ) ( archiveInfo.dirInfoSize + \
						TRAILER_SIZE + paddingSize ) ), SEEK_END ) <= 4L )
		/* Tried to seek past archive start, trailer information corrupted */
		error( ARCHIVE_DIRECTORY_CORRUPTED );
	resetFastIn( archiveFD );
	checksumBegin( INPUT );
	readDirHeaders( archiveInfo.noDirHdrs );
	readFileHeaders( archiveInfo.noFileHdrs );
	readDirNames();
	readFileNames();
	readPartSizes();
	getArchiveInfo( NO_READ_ID );	/* For checksumming purposes */
	if( crc16 != archiveInfo.checksum )
		/* Directory data was corrupted, confirm to continue */
		idiotBox( MESG_ARCHIVE_DIRECTORY_CORRUPTED );

	/* Move directory data to a temporary file if necessary since it will be
	   overwritten later */
	if( doSaveDirData && dirDataOffset )
		saveDirData();

	hlseek( archiveFD, ( LONG ) HPACK_ID_SIZE, SEEK_SET );
	}

/****************************************************************************
*																			*
*							Write a Directory to a File						*
*																			*
****************************************************************************/

/* Write the file headers to a file.  This function is split into two seperate
   routines, one of which steps through the list of headers and one which
   writes the headers themselves; the latter is also called to write the
   error recovery information */

int writeFileHeader( FILEHDR *theHeader, const WORD type )
	{
	WORD archInfo = theHeader->archiveInfo;
	int bytesWritten = sizeof( WORD ) + sizeof( LONG );	/* Constant fields */

	/* Set the field length bits depending on the field's contents */
	archInfo |= ( theHeader->fileLen > 0xFFFF ) ? ARCH_ORIG_LEN : 0;
	archInfo |= ( theHeader->dataLen > 0xFFFF ) ? ARCH_COPR_LEN : 0;
	archInfo |= ( theHeader->dirIndex > 0xFF ) ? ARCH_OTHER_LEN : \
				( theHeader->auxDataLen > 0xFF ) ? ARCH_OTHER_HI : \
				( theHeader->dirIndex || theHeader->auxDataLen ) ? \
				  ARCH_OTHER_LO : 0;

	/* Write the header itself */
	fputWord( archiveFD, archInfo );
	switch( archInfo & ARCH_OTHER_LEN )
		{
		case OTHER_BYTE_BYTE:
			/* dirIndex = BYTE, auxDataLen = BYTE */
			fputByte( archiveFD, ( BYTE ) theHeader->dirIndex );
			fputByte( archiveFD, ( BYTE ) theHeader->auxDataLen );
			bytesWritten += sizeof( BYTE ) + sizeof( BYTE );
			break;

		case OTHER_BYTE_WORD:
			/* dirIndex = BYTE, auxDataLen = WORD */
			fputByte( archiveFD, ( BYTE ) theHeader->dirIndex );
			fputWord( archiveFD, theHeader->auxDataLen );
			bytesWritten += sizeof( BYTE ) + sizeof( WORD );
			break;

		case OTHER_WORD_WORD:
			/* dirIndex = WORD, auxDataLen = WORD */
			fputWord( archiveFD, theHeader->dirIndex );
			fputWord( archiveFD, theHeader->auxDataLen );
			bytesWritten += sizeof( WORD ) + sizeof( WORD );
		}
	fputLong( archiveFD, theHeader->fileTime );
	if( archInfo & ARCH_ORIG_LEN )
		{
		fputLong( archiveFD, theHeader->fileLen );
		bytesWritten += sizeof( LONG );
		}
	else
		{
		fputWord( archiveFD, ( WORD ) theHeader->fileLen );
		bytesWritten += sizeof( WORD );
		}
	if( archInfo  & ARCH_COPR_LEN )
		{
		fputLong( archiveFD, theHeader->dataLen );
		bytesWritten += sizeof( LONG );
		}
	else
		{
		fputWord( archiveFD, ( WORD ) theHeader->dataLen );
		bytesWritten += sizeof( WORD );
		}

	/* Handle type SPECIAL files by writing an additional WORD containing
	   the file's type */
	if( ( archInfo & ARCH_STORAGE ) == FORMAT_SPECIAL )
		{
		fputWord( archiveFD, type );
		bytesWritten += sizeof( WORD );
		}

	return( bytesWritten );
	}

static LONG writeFileHeaders( void )
	{
	LONG bytesWritten = 0L;

	archiveInfo.noFileHdrs = 0;
	for( fileHdrCurrPtr = fileHdrStartPtr; fileHdrCurrPtr != NULL; \
		 fileHdrCurrPtr = fileHdrCurrPtr->next )
		{
		bytesWritten += writeFileHeader( &fileHdrCurrPtr->data, fileHdrCurrPtr->type );
		archiveInfo.noFileHdrs++;
		}

	return( bytesWritten );
	}

/* Write the filenames to a file */

static LONG writeFileNames( void )
	{
	LONG bytesWritten = 0L;
	char *strPtr;

	for( fileHdrCurrPtr = fileHdrStartPtr; fileHdrCurrPtr != NULL; \
		 fileHdrCurrPtr = fileHdrCurrPtr->next )
		{
		strPtr = fileHdrCurrPtr->fileName;
		do
			{
			fputByte( archiveFD, *strPtr );
			bytesWritten++;
			}
		while( *strPtr++ );
		}

	return( bytesWritten );
	}

/* Write the directory headers to a file */

static LONG writeDirHeaders( void )
	{
	WORD theEntry;
	DIRHDR *dirData;

	archiveInfo.noDirHdrs = 0;
	for( theEntry = dirHdrList[ ROOT_DIR ]->next; theEntry != END_MARKER; \
		 theEntry = dirHdrList[ theEntry ]->next )
		{
		dirData = &dirHdrList[ theEntry ]->data;
		fputWord( archiveFD, dirData->parentIndex );
		fputWord( archiveFD, dirData->dataLen );
		fputLong( archiveFD, dirData->dirTime );
		archiveInfo.noDirHdrs++;
		}

	return( archiveInfo.noDirHdrs * DIRHDRSIZE );
	}

/* Write the directory names to a file */

static LONG writeDirNames( void )
	{
	LONG bytesWritten = 0L;
	WORD theEntry;
	char *strPtr;

	/* Write directory names */
	for( theEntry = dirHdrList[ ROOT_DIR ]->next; theEntry != END_MARKER; \
		 theEntry = dirHdrList[ theEntry ]->next )
		{
		strPtr = dirHdrList[ theEntry ]->dirName;
		do
			{
			fputByte( archiveFD, *strPtr );
			bytesWritten++;
			}
		while( *strPtr++ );
		}

	return( bytesWritten );
	}

/* Write the size of each part in a multi-part archive */

static void writePartSizes( void )
	{
	if( flags & MULTIPART_ARCH )
		{
		/* Flag the fact that this is the last part of a multipart archive */
		archiveInfo.specialInfo |= SPECIAL_MULTIEND;

		/* Force a flush to add any possible extra segments, and remember
		   where the segmentation information starts */
		flush( archiveFD );		/* Force evaluation of lastPart */
		segmentStartDisk = lastPart;
		segmentStartPos = getCurrLength();

		/* Write out the size of each section */
		checksumBegin( OUTPUT );
		for( partSizeCurrPtr = partSizeStartPtr; partSizeCurrPtr != NULL; \
			 partSizeCurrPtr = partSizeCurrPtr->next )
			fputLong( archiveFD, partSizeCurrPtr->size );
		}
	}

/* Write the directory size information */

static void writeArchiveInfo( void )
	{
	fputWord( archiveFD, archiveInfo.noDirHdrs );
	fputWord( archiveFD, archiveInfo.noFileHdrs );
	fputLong( archiveFD, archiveInfo.dirInfoSize );

	/* Calculate checksum for any remaining archive directory data before
	   this point and write it */
	checksumEnd( OUTPUT );
	fputWord( archiveFD, crc16 );
	}

/* Write the final archive trailer */

static void writeArchiveTrailer( void )
	{
	/* Write the information for the multipart read bootstrap if necessary */
	if( flags & MULTIPART_ARCH )
		{
		/* Write total number of segments, number of data segments
		   (= segmentation information start disk), and start position of
		   segmentation information */
		flush( archiveFD );		/* Force evaluation of lastPart */
		fputWord( archiveFD, lastPart );
		fputWord( archiveFD, segmentStartDisk );
		fputLong( archiveFD, segmentStartPos );

		/* Calculate checksum for any remaining segment data before
		   this point and write it */
		checksumEnd( OUTPUT );
		fputWord( archiveFD, crc16 );
		}

	/* Write the kludge byte */
	fputByte( archiveFD, archiveInfo.specialInfo );

	/* We must use fputByte() to put the archive ID since fputLong() will do
	   endianness conversion */
	fputByte( archiveFD, HPACK_ID[ 0 ] );
	fputByte( archiveFD, HPACK_ID[ 1 ] );
	fputByte( archiveFD, HPACK_ID[ 2 ] );
	fputByte( archiveFD, HPACK_ID[ 3 ] );
	}

/* Write the directory data to the archive */

static void writeDirData( void )
	{
	LONG position = 0L, offset, delta;
	WORD dataLen, theEntry;

	/* Write out any data still in the buffer */
	flushDirBuffer();

	/* Move the directory data from the temporary file to the archive file.
	   We use a loop with fputByte() instead of a moveData call to take care
	   of buffering for us, since in general the small amount of data to be
	   moved doesn't make it worthwhile to have special code to handle the
	   moveData() version */
	if( dirDataOffset )
		{
		/* Step through the list of headers moving the data corresponding to
		   the header from the dirFile to the archive file.  Doing things
		   this way is necessary since fixEverything() may have reordered the
		   directory headers so that their order no longer corresponds to the
		   data in the dirFile */
		hlseek( dirFileFD, 0L, SEEK_SET );
		forceRead();
		for( theEntry = dirHdrList[ ROOT_DIR ]->next; theEntry != END_MARKER; \
			 theEntry = dirHdrList[ theEntry ]->next )
			/* Only do the move if there's something to move */
#pragma warn -pia
			if( dataLen = dirHdrList[ theEntry ]->data.dataLen )
#pragma warn +pia
				{
				if( ( offset = dirHdrList[ theEntry ]->offset ) < position )
					{
					/* Data is behind us, move backwards in dirFile */
					delta = position - offset;
					if( _inByteCount >= delta )
						/* Data is still in buffer; move backwards to it */
						_inByteCount -= ( int ) delta;
					else
						{
						/* Data is outside buffer, go to position */
						hlseek( dirFileFD, offset, SEEK_SET );
						forceRead();
						}
					}
				else
					/* Data is ahead of us; skipSeek to it if necessary */
					if( offset - position )
						skipSeek( dirFileFD, offset - position );

				/* Move the data across and update position */
				position = offset + dataLen;
				while( dataLen-- )
					/* Not very elegant but it nicely takes care of buffering */
					fputByte( archiveFD, fgetByte( dirFileFD ) );
				}
		}

	/* Zap the dirFile if it exists */
	if( dirFileFD )
		{
		hclose( dirFileFD );
		hunlink( dirFileName );
		dirFileFD = 0;
		}
	}

/* Write the archive directory to a file */

void writeArcDir( void )
	{
	/* Clean up the directory structure if it's safe to do so */
	if( doFixEverything )
		fixEverything();

	/* Write the directory data (if any) to the archive */
	writeDirData();

	/* Zap the security info file if it exists */
	if( secFileFD )
		{
		hclose( secFileFD );
		hunlink( secFileName );
		secFileFD = 0;
		}

	/* Build up archive trailer information and write it */
	archiveInfo.specialInfo = 0;
	checksumBegin( OUTPUT );
	archiveInfo.dirInfoSize = writeDirHeaders();
	archiveInfo.dirInfoSize += writeFileHeaders();
	archiveInfo.dirInfoSize += writeDirNames();
	archiveInfo.dirInfoSize += writeFileNames();
	archiveInfo.specialInfo |= PROTOTYPE;
	writeArchiveInfo();		/* Write directory size information */
	writePartSizes();		/* Write segment sizes if necessary */
	writeArchiveTrailer();	/* Write final trailer information */
	flush( archiveFD );

	/* If it's a multipart archive and there is only one part, redo it
	   as a normal archive */
	if( ( flags & MULTIPART_ARCH ) && !lastPart )
		{
		hlseek( archiveFD, -( long ) ( MP_TRAILER_SIZE + sizeof( BYTE ) + \
									   HPACK_ID_SIZE ), SEEK_END );
		htruncate( archiveFD );

		/* Reset its status to a normal single-part archive and rewrite
		   the trailer */
		flags &= ~MULTIPART_ARCH;
		archiveInfo.specialInfo &= ~SPECIAL_MULTIEND;
		lastPart = 0;
		writeArchiveTrailer();
		flush( archiveFD );
		}
	}
