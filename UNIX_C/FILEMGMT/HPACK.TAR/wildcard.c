/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*						 Wildcard String Matching Routines					*
*							WILDCARD.C  Updated 20/06/90					*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1989, 1990 Peter C.Gutmann.  All rights reserved			*
*																			*
****************************************************************************/

#include <ctype.h>
#include "defs.h"
#include "error.h"
#include "system.h"
#include "wildcard.h"

/* The types we can match.  These are:

	MATCHEND			- Match all following chars
	MATCHTO <end>		- Match all chars till <end>
	MATCHONE			- Match any one char
	RANGE <from> <to>	- Match all chars in range <from>...<to>
	NOTRANGE <from> <to>- Match all chars but those in range <from>...<to>
	NOT <char>			- Don't match this char
	<char>				- Match this char
*/

enum { END, MATCHEND, MATCHTO, MATCHONE, RANGE, NOTRANGE, NOT, ENDRANGE };

/* The escape character which is used to override standard wildcard
   characters.  Usually this is '\' but MSDOS and OS/2 need to use '#' since
   '\' is used in pathnames */

#if defined( __MSDOS__ ) || defined( __OS2__ )
  #define ESC	'#'
#else
  #define ESC	'\\'
#endif /* __MSDOS__ || __OS2__ */

/* A utility function to determine whether a string segment contains any
   wildcard characters */

BOOLEAN hasWildcards( char *string, int count )
	{
	char ch;

	while( count-- )
		if( ( ch = *string++ ) == '*' || ch == '?' || ch == '[' || ch == ESC )
			return( TRUE );

	/* No wildcards found in string */
	return( FALSE );
	}

/****************************************************************************
*																			*
* 						String "Compiling" Function							*
*																			*
****************************************************************************/

/* Error message handler for the string compiler function.  This is handled
   as a seperate function instead of a direct call to error() since not all
   compilers will merge the duplicate strings created when this particular
   error is invoked from several locations.  Non-MSDOS versions not
   constrained by 64K segments may wish to substitute individual messages
   which are more error-specific than this generic message */

void compileStringError( const char *string )
	{
	error( BAD_WILDCARD_FORMAT, string );
	}

/* Compile a string into a form acceptable by the wildcard-matching FSM.
   The form is pretty simple.  The only part which may require a bit of
   explanation is the mechanism for matching ranges.  This is defined by the
   regular expression:

   { "^" | "!" }? { letter { "-" letter }? }+
*/

int compileString( const char *src, char *dest )
	{
	int srcIndex = 0, destIndex = 0;
	BOOLEAN inRange;
	char ch;

#pragma warn -pia
	while( ( ch = src[ srcIndex++ ] ) && destIndex < MATCH_DEST_LEN )
#pragma warn +pia
		switch( ch )
			{
			case '*':
				if( src[ srcIndex ] )
					dest[ destIndex++ ] = MATCHTO;
				else
					dest[ destIndex++ ] = MATCHEND;

				/* Stomp repeated '*'s */
				while( src[ srcIndex ] == '*' )
					srcIndex++;

				break;

			case '?':
				dest[ destIndex++ ] = MATCHONE;
				break;

			case '[':
				if( src[ srcIndex ] == '^' || src[ srcIndex ] == '!' )
					{
					dest[ destIndex++ ] = NOTRANGE;
					srcIndex++;
					}
				else
					dest[ destIndex++ ] = RANGE;
				if( src[ srcIndex ] == ']' || src[ srcIndex ] == '-' )
					compileStringError( src );

				inRange = FALSE;
				while( ( ( ch = src[ srcIndex++ ] ) != ']' ) && \
										( destIndex < MATCH_DEST_LEN - 1 ) )
							/* destIndex < MATCH_DEST_LEN - 1 allows room for
							   the ENDRANGE and END tokens */
					switch( ch )
						{
						case END:
							compileStringError( src );
							break;

						case '-':
							if( inRange )
								compileStringError( src );
							inRange = TRUE;
							dest[ destIndex ] = dest[ destIndex - 1 ];
							dest[ destIndex - 1 ] = RANGE;
							destIndex++;
							break;

						case ESC:
#pragma warn -pia
							if( !( ch = src[ srcIndex++ ] ) )
#pragma warn +pia
								compileStringError( src );
							/* Drop through */

						default:
							dest[ destIndex++ ] = ch;
							inRange = FALSE;
							break;
						}
				if( inRange )
					compileStringError( src );
				dest[ destIndex++ ] = ENDRANGE;
				break;

			case ESC:
#pragma warn -pia
				if( !( ch = src[ srcIndex++ ] ) )
#pragma warn +pia
					compileStringError( src );
				/* Drop through */

			default:
				dest[ destIndex++ ] = ch;
			}
	dest[ destIndex++ ] = END;

	/* Very complex regular expressions can overflow the destination buffer */
	if( destIndex >= MATCH_DEST_LEN )
		error( WILDCARD_TOO_COMPLEX );

	/* Return count of no.of chars in output + null delimiter */
	return( destIndex );
	}

/****************************************************************************
*																			*
*						Wildcard String Matching Functions					*
*																			*
****************************************************************************/

/* A simple queue, used to handle backtracking.  Once the queue is full, we
   stop adding items, even if space has been freed up at the front.  This
   conveniently stops deep recursion for very complex expressions.  The queue
   size is chosen to be in the vicinity of the maximum filename length we can
   expect, to allow for a worst-case scenario of matching "*x" to "xxxxx..." */

#define QUEUE_SIZE	50

static int srcQueue[ QUEUE_SIZE ], destQueue[ QUEUE_SIZE ], queueFront, queueEnd;

/* Match a pattern string with wildcards against a literal string */

BOOLEAN matchString( const char *src, const char *dest )
	{
	char ch, matchChar;
	int srcIndex = 0, destIndex = 0;
	BOOLEAN match = TRUE, notFlag = FALSE, passedChar = FALSE;

	/* Set up queue for backtracking */
	queueFront = queueEnd = 0;

retry:
#pragma warn -pia
	while( ( ch = src[ srcIndex++ ] ) && match )
#pragma warn +pia
		switch( ch )
			{
			case MATCHEND:
				return( match );		/* Match all remaining chars */

			case MATCHTO:
				matchChar = src[ srcIndex ];
				while( caseConvert( dest[ destIndex ] ) != matchChar && dest[ destIndex ] )
					{
					/* We can't do this as part of the main loop since that
					   wouldn't let us do a match of 0 chars */
					destIndex++;
					passedChar = TRUE;	/* Remember we've matched at least one char */
					}

				/* See if we exited due to running out of chars to match rather
				   than an actual match */
				if( !dest[ destIndex ] )
					match = FALSE;
				else
					/* Push current state so we can backtrack */
					if( queueEnd < QUEUE_SIZE )
						{
						srcQueue[ queueEnd ] = srcIndex - 1;
						destQueue[ queueEnd++ ] = ( passedChar ) ? destIndex : destIndex + 1;
						}
				passedChar = FALSE;
				break;

			case MATCHONE:
				if( !dest[ destIndex++ ] )
					match = FALSE;
				break;

			case NOTRANGE:
				notFlag = TRUE;
				/* Drop through */

			case RANGE:
				/* Note that when checking for a match it is necessary to use
				   "|=" to indicate a match, since we are not using short
				   circuit evaluation and thus with "=" a later non-match may
				   cancel a previous match.  Using short-circuit evaluation
				   give little advantage, since it involves adding gotos to
				   exit the loop, and yet we must still scan over src[]
				   anyway to get to the ENDRANGE.  Note also that binary
				   &'s are used in the comparisons to avoid short-circuit
				   evaluation, since the expressions have side effects */
				match = FALSE;
				matchChar = caseConvert( dest[ destIndex ] );
				destIndex++;
				while( ( ch = src[ srcIndex++ ] ) != ENDRANGE )
					if( ch == RANGE )
						{
						/* Joining the following two statements with an '&'
						   doesn't seem to work */
						match |= matchChar >= caseConvert( src[ srcIndex ] );
						srcIndex++;
						match &= matchChar <= caseConvert( src[ srcIndex ] );
						srcIndex++;
						}
					else
						match |= matchChar == caseConvert( ch );

				if( notFlag )
					match = !match;
				notFlag = FALSE;
				break;

			default:
				match = caseConvert( ch ) == caseConvert( dest[ destIndex ] );
				destIndex++;
			}

	/* No match if there are more matchable chars in one of the strings */
	if( src[ srcIndex - 1 ] || dest[ destIndex ] )
		match = FALSE;

	/* See if we can backtrack and try again */
	if( !match && ( queueFront != queueEnd ) )
		{
		srcIndex = srcQueue[ queueFront ];
		destIndex = destQueue[ queueFront++ ];
		match = TRUE;
		goto retry;
		}

	return( match );
	}
