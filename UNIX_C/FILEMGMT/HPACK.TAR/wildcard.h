/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*						Header File for the Wildcard Routines				*
*							WILDCARD.H  Updated 20/06/90					*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1989, 1990 Peter C.Gutmann.  All rights reserved			*
*																			*
****************************************************************************/

/* The maximum allowable length of the destination string for the
   compileString() function */

#define MATCH_DEST_LEN	100

/* Prototypes for functions in WILDCARD.C */

BOOLEAN hasWildcards( char *string, int length );
int compileString( const char *src, char * dest );
BOOLEAN matchString( const char *src, const char * dest );
