/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*						  HPACK Archive Tag Handling Code					*
*							TAGS.C  Updated 31/12/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1990, 1991  Peter C.Gutmann.  All rights reserved			*
*																			*
****************************************************************************/

#include "defs.h"
#include "error.h"
#include "system.h"
#include "tags.h"
#include "io/fastio.h"

/****************************************************************************
*																			*
*							Read Tagged Data Routines						*
*																			*
****************************************************************************/

/* Read in attribute data */

ATTR readAttributeData( const WORD attributeID )
	{
	WORD wordData, retVal = 0;
	BYTE byteData;

	switch( attributeID )
		{
		case TAG_MSDOS_ATTR:
		case TAG_ATARI_ATTR:
			byteData = fgetByte( archiveFD );
#if defined( __MSDOS__ ) || defined( __ATARI__ )
			retVal = byteData;
#elif defined( __UNIX__ )
			if( byteData & MSDOS_ATTR_RDONLY )
				retVal = UNIX_ATTR_RBITS;
			else
				retVal = UNIX_ATTR_RBITS | UNIX_ATTR_WBITS;
#elif defined( __MAC__ )
			if( wordData & MSDOS_ATTR_ARCHIVE )
				retVal |= MAC_ATTR_CHANGED );
			if( wordData & MSDOS_ATTR_SYSTEM )
				retVal |= MAC_ATTR_SYSTEM;
			if( wordData & MSDOS_ATTR_HIDDEN )
				retVal |= MAC_ATTR_INVISIBLE;
			if( wordData & MSDOS_ATTR_RDONLY )
				retVal |= MAC_ATTR_LOCKED;
#else
			hprintf( "Don't know what to do with MSDOS attributes, TAGS.C line %d\n", __LINE__ );
#endif /* Various OS-specific defines */
			break;

		case TAG_UNIX_ATTR:
			wordData = fgetWord( archiveFD );
#if defined( __MSDOS__ ) || defined( __ATARI__ )
			if( !( wordData & UNIX_ATTR_OWNER_W ) )
				retVal |= MSDOS_ATTR_RDONLY;
#elif defined( __UNIX__ )
			retVal = wordData;
#elif defined( __MAC__ )
			if( !( wordData & UNIX_ATTR_OWNER_W ) )
				retVal |= MAC_ATTR_LOCKED;
#else
			hprintf( "Don't know what to do with Unix attributes, TAGS.C line %d\n", __LINE__ );
#endif /* Various OS-specific defines */
			break;

		case TAG_MAC_ATTR:
			wordData = fgetWord( archiveFD );
#if defined( __MSDOS__ ) || defined( __ATARI__ )
			if( wordData & MAC_ATTR_CHANGED )
				retVal |= MSDOS_ATTR_ARCHIVE;
			if( wordData & MAC_ATTR_SYSTEM )
				retVal |= MSDOS_ATTR_SYSTEM;
			if( wordData & MAC_ATTR_INVISIBLE )
				retVal |= MSDOS_ATTR_HIDDEN;
			if( wordData & MAC_ATTR_LOCKED )
				retVal |= MSDOS_ATTR_RDONLY;
			fgetLong( archiveFD );
			fgetLong( archiveFD );		/* Skip owner + creator info */
#elif defined( __UNIX__ )
			if( wordData & MAC_ATTR_LOCKED )
				retVal = UNIX_ATTR_RBITS;
			else
				retVal = UNIX_ATTR_RBITS | UNIX_ATTR_WBITS;
			fgetLong( archiveFD );
			fgetLong( archiveFD );		/* Skip owner + creator info */
#elif defined( __MAC__ )
			retVal = wordData;
#else
			hprintf( "Don't know what to do with Mac attributes, TAGS.C line %d\n", __LINE__ );
			fgetLong( archiveFD );
			fgetLong( archiveFD );		/* Skip owner + creator info */
#endif /* Various OS-specific defines */
			break;

		case TAG_ARC_ATTR:
			byteData = fgetByte( archiveFD );
#if defined( __MSDOS__ ) || defined( __ATARI__ )
			if( byteData & ARC_ATTR_LOCKED )
				retVal |= MSDOS_ATTR_RDONLY;
			fgetWord( archiveFD );		/* Skip file type */
#elif defined( __UNIX__ )
			if( byteData & ARC_ATTR_READ_OWNER )
				retVal |= UNIX_ATTR_OWNER_R;
			if( byteData & ARC_ATTR_WRITE_OWNER )
				retVal |= UNIX_ATTR_OWNER_W;
			if( byteData & ARC_ATTR_READ_OTHER )
				retVal |= UNIX_ATTR_GROUP_R | UNIX_ATTR_OTHER_W;
			if( byteData & ARC_ATTR_WRITE_OTHER )
				retVal |= UNIX_ATTR_GROUP_W | UNIX_ATTR_OTHER_W;
			fgetWord( archiveFD );		/* Skip file type */
#elif defined( __MAC__ )
			if( byteData & ARC_ATTR_LOCKED )
				retVal |= MAC_ATTR_LOCKED;
			fgetWord( archiveFD );		/* Skip file type */
#else
			hprintf( "Don't know what to do with Archimedes attributes, TAGS.C line %d\n", __LINE__ );
			fgetWord( archiveFD );		/* Skip file type */
#endif /* Various OS-specific defines */
			break;

		case TAG_APPLE_ATTR:
			wordData = fgetWord( archiveFD );
#if defined( __MSDOS__ ) || defined( __ATARI__ )
			if( !( wordData & APPLE_ATTR_WRITE ) )
				retVal |= MSDOS_ATTR_RDONLY;
			if( wordData & APPLE_ATTR_BACKUP )
				retVal |= MSDOS_ATTR_ARCHIVE;
			fgetLong( archiveFD );		/* Skip file, aux file types */
#elif defined( __UNIX__ )
			if( wordData & APPLE_ATTR_READ )
				retVal |= UNIX_ATTR_RBITS;
			if( wordData & APPLE_ATTR_WRITE )
				retVal |= UNIX_ATTR_WBITS;
			fgetLong( archiveFD );		/* Skip file, aux file types */
#elif defined( __MAC__ )
			if( !( wordData & APPLE_ATTR_WRITE ) )
				retVal |= MAC_ATTR_LOCKED;
			if( wordData & APPLE_ATTR_BACKUP )
				retVal |= MAC_ATTR_CHANGED;
			fgetLong( archiveFD );		/* Skip file, aux file types */
#else
			hprintf( "Don't know what to do with IIgs attributes, TAGS.C line %d\n", __LINE__ );
			fgetLong( archiveFD );		/* Skip file, aux file types */
#endif /* Various OS-specific defines */
			break;

		case TAG_AMIGA_ATTR:
			byteData = fgetByte( archiveFD );
#if defined( __MSDOS__ ) || defined( __ATARI__ )
			if( !( byteData & AMIGA_ATTR_WRITE ) )
				retVal |= MSDOS_ATTR_RDONLY;
			if( !( byteData & AMIGA_ATTR_ARCHIVE ) )
				retVal |= MSDOS_ATTR_ARCHIVE;
#elif defined( __UNIX__ )
			if( byteData & AMIGA_ATTR_READ )
				retVal |= UNIX_ATTR_RBITS;
			if( byteData & AMIGA_ATTR_WRITE )
				retVal |= UNIX_ATTR_WBITS;
			if( byteData & AMIGA_ATTR_EXECUTE )
				retVal |= UNIX_ATTR_XBITS;
#elif defined( __MAC__ )
			if( !( wordData & AMIGA_ATTR_WRITE ) )
				retVal |= MAC_ATTR_LOCKED;
			if( !( wordData & AMIGA_ATTR_ARCHIVE ) )
				retVal |= MAC_ATTR_CHANGED;
#else
			hprintf( "Don't know what to do with Amiga attributes, TAGS.C line %d\n", __LINE__ );
#endif /* Various OS-specific defines */
			break;
		}

	return( retVal );
	}

/* Grovel through a tag field looking for tags we can handle */

BOOLEAN readTag( WORD *tagFieldSize, WORD *tagID, WORD *tagLen )
	{
	WORD theTag, tagDataLen;
	WORD tagClass = NO_TAG;

	while( *tagFieldSize && !tagClass )
		{
		theTag = fgetWord( archiveFD );

		/* Extract the tag ID and data length depending on the type of the tag */
		if( theTag >= LONG_BASE )
			{
			*tagID = theTag;
			*tagLen = fgetWord( archiveFD );
			*tagFieldSize -= sizeof( WORD );
			}
		else
			{
			*tagID = extractTagID( theTag );
			*tagLen = extractTagLen( theTag );
			}
		tagDataLen = *tagLen;
		*tagFieldSize -= tagDataLen + sizeof( WORD );

		/* Now handle each tag.  At this point we only check whether we know
		   what to do with the tag, but don't do any processing.  Any tags
		   which contain useless information (as well as those we don't know
		   about) are skipped */
		switch( *tagID )
			{
			case TAG_MSDOS_ATTR:
			case TAG_UNIX_ATTR:
			case TAG_MAC_ATTR:
			case TAG_ARC_ATTR:
			case TAG_APPLE_ATTR:
				tagClass = ATTRIBUTE_TAG;
				break;

			case LONG_COMMENT:
			case SHORT_COMMENT:
				tagClass = COMMENT_TAG;
				break;

			default:
				/* Skip this tag */
				if( tagDataLen )
					{
					skipSeek( archiveFD, tagDataLen );
					tagLen = 0;
					}
			}
		}

	return( tagClass );
	}

/****************************************************************************
*																			*
*							Write Tagged Data Routines						*
*																			*
****************************************************************************/

/* The following routines are currently unused in the standard distribution
   of HPACK.  They can be used to write variable-length tagged fields to
   the archive or directory information files */

#if 0

/* Write a tag to the archive */

WORD writeTag( WORD tagID, WORD tagLength, const BYTE *dataBuffer )
	{
	int i = 0;

	/* Write the tag itself as either a short or a long tag */
	if( tagLength < SHORT_TAGLEN )
		fputWord( archiveFD, tagID | tagLength );
	else
		{
		fputWord( archiveFD, tagID );
		fputWord( archiveFD, tagLength );
		}

	/* Get the tag length if it has an implicit length */
	if( !tagLength )
		tagLength = extractTagLen( tagID );

	/* Write the data associated with the tag */
	while( i < tagLength )
		fputByte( archiveFD, dataBuffer[ i++ ] );

	return( TAGSIZE + tagLength );
	}

WORD writeDirTag( WORD tagID, WORD tagLength, const BYTE *dataBuffer )
	{
	int i = 0;

	/* Write the tag itself */
	tagID |= tagLength;
	fputDirWord( tagID );

	/* Get the tag length if it has an implicit length */
	if( !tagLength )
		tagLength = extractTagLen( tagID );

	/* Write the data associated with the tag */
	while( i < tagLength )
		fputDirByte( dataBuffer[ i++ ] );

	return( TAGSIZE + tagLength );
	}

#endif /* 0 */
