/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*							  User Flags Header File						*
*							 FLAGS.H  Updated 08/10/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1989 - 1991  Peter C.Gutmann.  All rights reserved		*
*																			*
****************************************************************************/

#ifndef _FLAGS_DEFINED

#define _FLAGS_DEFINED

/* The word used to hold the flag values */

extern WORD flags;
extern WORD dirFlags;
extern WORD cryptFlags;
extern WORD specialFlags;
extern WORD sysSpecFlags;

/* The values in the flags word */

#define OVERWRITE_SRC	0x0001	/* Delete archive if it already exists */
#define TOUCH_FILES		0x0002	/* Touch files on extraction */
#define RECURSE_SUBDIR	0x0004	/* Recurse through all subdirectories */
#define STORE_PATH		0x0008	/* Store pathname of dirs.recursed into */
#define CRYPT			0x0010  /* Encrypt the data */
#define OVERWRITE_OPTIONS	0x0020	/* Options for overwrite on extract */
#define VIEW_OPTIONS	0x0040	/* Options for the View command */
#define STORE_ATTR		0x0080	/* Store file attributes */
#define DIR_OPTIONS		0x0100	/* Special dir.options: Details in dirFlags */
#define XLATE_OUTPUT	0x0200	/* Apply translation to decompressor output */
#define STEALTH_MODE	0x0400	/* Run in stealth mode */
#define INTERACTIVE		0x0800	/* Confirm each action taken */
#define ERROR_RECOVER	0x1000	/* Write error recovery info */
#define ARCH_COMMENT	0x2000	/* Args are archive comments */
#define MULTIPART_ARCH	0x4000	/* Multi-part archive */

/* The values in the overwriteFlags word */

#define OVERWRITE_ALL	0x0001	/* Overwrite existing on extraction */
#define OVERWRITE_NONE	0x0002	/* Don't overwrite existing on extraction */
#define OVERWRITE_SMART	0x0004  /* Rename source to avoid overwrite */
#define OVERWRITE_PROMPT	0x0008	/* Prompt for new filename if collision */

/* The values in the viewFlags word */

#define VIEW_FILES		0x0001	/* View only the files in an archive */
#define VIEW_DIRS		0x0002	/* View only the dirs in an archive */
#define VIEW_ALL		0x0004	/* View everything in an archive */
#define VIEW_SORTED		0x0008	/* Sort files in directories */

/* The values in the dirFlags word */

#define DIR_MKDIR		0x0001	/* Make directory */
#define DIR_RMDIR		0x0002	/* Remove directory */
#define DIR_MVDIR		0x0004	/* Move directory */
#define DIR_ALLPATHS	0x0008	/* Add all paths (even empty ones) */
#define DIR_NOCREATE	0x0010	/* No create dir.if it doesn't already exist */
#define DIR_MULTIDIR	0x0020	/* Full paths for ??DIR, not just single dirs */

/* The values in the xlateFlags word */

#define XLATE_EOL		0x0001	/* Translate EOL character */
#define XLATE_EBCDIC	0x0002	/* Translate EBCDIC -> ASCII */
#define XLATE_PRIME		0x0004	/* Translate Prime ASCII -> std.ASCII */
#define XLATE_SMART		0x0008	/* Smart xlate depending on OS */

/* The values in the cryptFlags word */

#define CRYPT_SECURED	0x0001	/* Sign data with PKC */
#define CRYPT_PUBLIC	0x0002	/* PKC-encrypt data */
#define CRYPT_PRIVATE	0x0004	/* Private-key encrypt data */

/* The values in the sysSpecFlags word */

#if defined( __MSDOS__ )
  #define SYSPEC_VOLUME		0x0001	/* Store volume label + serial number */
  #define SYSPEC_CHECKSAFE	0x0002	/* Check for device driver as filename */
#elif defined( __UNIX__ )
  #define SYSPEC_FORCELOWER	0x0001	/* Force file/dir names to lower case */
  #define SYSPEC_CASENSITIVE	0x0002	/* Force case sensitivity */
#endif /* Various system-specific options */

#endif /* !_FLAGS_DEFINED */
