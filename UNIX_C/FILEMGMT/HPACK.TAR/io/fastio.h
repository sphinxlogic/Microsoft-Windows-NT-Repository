/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*					 	Header File for Fast I/O Routines					*
*							FASTIO.H  Updated 08/12/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1990, 1991  Peter C.Gutmann.  All rights reserved			*
*																			*
****************************************************************************/

#ifndef _FASTIO_DEFINED

#define _FASTIO_DEFINED

#ifdef SYSV
  #include "../io/hpackio.h"
#else
  #include "io/hpackio.h"
#endif /* SYSV */

/* The size of the I/O buffers */

#if defined( __MSDOS__ ) || defined( __IIGS__ )
  #define _BUFSIZE	8192
#else
  #define _BUFSIZE	16384
#endif /* __MSDOS__ || __IIGS__ */

/* The size of the directory info buffer */

#define DIRBUFSIZE	( _BUFSIZE / 2 )

/* The EOF value */

#define FEOF		-1

/* Symbolic defines for I/O checksumming */

#define INPUT		TRUE
#define OUTPUT		FALSE

/* The format of wait message to display while waiting for the luser to
   continue when handling a multipart archive */

#define WAIT_PARTNO		0x01	/* Print archive part number */
#define WAIT_NEXTDISK	0x02	/* Ask for next disk */
#define WAIT_LASTPART	0x04	/* Ask for last disk */

/* The output intercept type:  Normally data to be output is just written to
   a FD, however it can be intercepted in the _writeBuffer() routine and
   redirected/reformatted/etc.  Possible types of redirection are no output,
   raw data output (default) and formatted text output */

typedef enum { OUT_NONE, OUT_DATA, OUT_FMT_TEXT } OUTINTERCEPT_TYPE;

/* Some global vars declared in FASTIO.C */

extern BYTE *_inBuffer, *_outBuffer;	/* The I/O buffers */
extern int _inByteCount, _outByteCount;	/* Current position in buffer */
extern int _inBytesRead;				/* Actual no.bytes read */

/* Vars used to handle the general-purpose buffer */

extern BYTE *mrglBuffer, *dirBuffer;
extern int mrglBufCount, dirBufCount;

/* Prototypes for the fast I/O functions themselves */

void initFastIO( void );
void endFastIO( void );
void resetFastIn( const FD _inFD );
void resetFastOut( void );
void initTranslationSystem( const BYTE lineEndChar );
void checksumBegin( const BOOLEAN isInput );
void checksumEnd( const BOOLEAN isInput );
long getCurrLength( void );
int getByte( const FD _inFD );
void putByte( const FD _outFD, const BYTE data );
void ungetByte( void );
void skipSeek( const FD _inFD, LONG skipDist );
void writeBuffer( const FD _outFD, const int bufSize );
void writeMrglBuffer( const FD _outFD, const int bufSize );
void writeDirBuffer( const int bufSize );
void flush( const FD _outFD );
void flushMrglBuffer( const FD _outFD );
void flushDirBuffer( void );
void setOutputIntercept( OUTINTERCEPT_TYPE interceptType );
void resetOutputIntercept( void );
void multipartWait( const WORD promptType, const int partNo );

/* Function versions of the original put/get byte/word/long macros.  These
   are used instead of macro's since the macros tended to produce a huge
   amount of code due to macro expansion.  Following common usage they are
   referred to by the macro names with a prepended 'f' */

void fputByte( const FD _outFD, const BYTE data );
void fputWord( const FD _outFD, const WORD data );
void fputLong( const FD _outFD, const LONG data );
int fgetByte( const FD _inFD );
WORD fgetWord( const FD _inFD );
LONG fgetLong( const FD _inFD );

/* The corresponding routines for directory data.  We don't need to give a
   file descriptor since we always use the same directory file */

void fputDirByte( const BYTE data );
void fputDirWord( const WORD data );
void fputDirLong( const LONG data );

/* The following works because we only ever do a read when we have no more
   chars available.  Thus when we read the last char in the buffer we don't
   read in more until we need the next char after that, so that _inByteCount
   is never set to 0 which would cause problems */

#define ungetByte()		_inByteCount--

/* Macro to force a read on the next getByte() */

#define forceRead()		_inByteCount = _inBytesRead = _BUFSIZE

#endif /* !_FASTIO_DEFINED */
