/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*						  	  Fast File I/O Routines						*
*							FASTIO.C  Updated 13/12/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1990, 1991  Peter C.Gutmann.  All rights reserved			*
*																			*
****************************************************************************/

#include <stdlib.h>
#include <string.h>
#include "defs.h"
#ifdef SYSV
  #include "../arcdir.h"
  #include "../error.h"
  #include "../flags.h"
  #include "../frontend.h"
  #include "../hpacklib.h"
  #include "../hpaktext.h"
  #include "../system.h"
  #include "../crc/crc16.h"
  #include "../data/ebcdic.h"
  #include "../io/fastio.h"
  #include "../io/hpackio.h"
#else
  #include "arcdir.h"
  #include "error.h"
  #include "flags.h"
  #include "frontend.h"
  #include "hpaktext.h"
  #include "hpacklib.h"
  #include "system.h"
  #include "crc/crc16.h"
  #include "data/ebcdic.h"
  #include "io/fastio.h"
  #include "io/hpackio.h"
#endif /* SYSV */

/* Some vars used to keep track of the fast I/O routines */

BYTE *_inBuffer, *_outBuffer;
#ifdef __MSDOS__
  WORD _inBufferBase, _outBufferBase;
#endif /* __MSDOS__ */
FD _inFD, _outFD;
int _inByteCount, _outByteCount;
int _inBytesRead;

/* A flag to indicate whether we should do a checksum calculation on
   incoming/outgoing data, and the point in the buffer at which we start/stop
   checksumming data */

BOOLEAN checksumIO = FALSE;
int checksumMark = 0;

/* The number of bytes written so far for this segment, and the total number
   of bytes written before this segment (needed for multipart archives) */

static long currLength;
static long totalLength;

/* The output data intercept type */

static OUTINTERCEPT_TYPE outputIntercept = OUT_DATA;

/* Prototypes for the output routines used by the output intercept code */

void initOutFormatText( void );
void outFormatChar( const char ch );
void endOutFormatText( void );			/* Formatted text output */

/* The value to use as line terminator when doing translation to MSDOS CRLF
   format */

static BYTE lineEndChar;

/* Vars used to handle the general-purpose buffer.  This buffer is used to
   set up the encryption system, during extraction for textfile translation,
   and during changes to an archive for a general-purpose buffer for
   assembling data.  When necessary the upper half of the mrglBuffer is
   sacred to the dirInfo handling code for buffering of dirInfo */

#define DIRBUF_OFFSET	( _BUFSIZE / 2 )	/* Start of dir.info buffer */

BYTE *mrglBuffer, *dirBuffer;
int mrglBufCount, dirBufCount;
int dirBytesRead;

/* Macro to output a byte to the mrglBuffer */

#define putMrglByte(outFD,ch)	do \
									{ \
									if( mrglBufCount == _BUFSIZE ) \
										writeMrglBuffer( outFD, _BUFSIZE ); \
									mrglBuffer[ mrglBufCount++ ] = ch; \
									} \
								while( 0 )

/****************************************************************************
*																			*
*							Initialize fast I/O functions 					*
*																			*
****************************************************************************/

/* Allocate buffers for the fast I/O routines and the GP buffer.  Under MSDOS
   we make sure they're segment-aligned for fast access */

void initFastIO( void )
	{
#ifdef __MSDOS__
	if( ( _inBuffer = ( BYTE * ) hmallocSeg( _BUFSIZE * sizeof( BYTE ) ) ) == NULL || \
		( _outBuffer = ( BYTE * ) hmallocSeg( _BUFSIZE * sizeof( BYTE ) ) ) == NULL || \
		( mrglBuffer = ( BYTE * ) hmalloc( _BUFSIZE * sizeof( BYTE ) ) ) == NULL )
#else
	if( ( _inBuffer = ( BYTE * ) hmalloc( _BUFSIZE * sizeof( BYTE ) ) ) == NULL || \
		( _outBuffer = ( BYTE * ) hmalloc( _BUFSIZE * sizeof( BYTE ) ) ) == NULL || \
		( mrglBuffer = ( BYTE * ) hmalloc( _BUFSIZE * sizeof( BYTE ) ) ) == NULL )
#endif /* __MSDOS__ */
		error( OUT_OF_MEMORY );
	dirBuffer = mrglBuffer + DIRBUF_OFFSET;

#ifdef __MSDOS__
	_inBufferBase = FP_SEG( _inBuffer );
	_outBufferBase = FP_SEG( _outBuffer );
#endif /* __MSDOS__ */

	/* Set up CRC16 lookup table */
	initCRC16();
	}

#ifndef __MSDOS__

/* Free the fast I/O buffers and the GP buffer */

void endFastIO( void )
	{
	hfree( _inBuffer );
	hfree( _outBuffer );
	hfree( mrglBuffer );
	}
#endif /* !__MSDOS__ */

/* Reset input system */

inline void resetFastIn( const FD _inFD )
	{
	_inByteCount = 0;
	if( ( _inBytesRead = hread( _inFD, _inBuffer, _BUFSIZE ) ) == ERROR )
		fileError();
	}

inline void resetFastOut( void )
	{
	_outByteCount = mrglBufCount = 0;
	currLength = totalLength = 0L;
	}

inline void initTranslationSystem( const BYTE theChar )
	{
	/* Set up the line termination character */
	lineEndChar = theChar;
	}

/* Turn checksumming of input/output on/off */

void checksumBegin( const BOOLEAN isInput )
	{
	checksumIO = TRUE;

	/* Reset checksum and mark start point in buffer */
	crc16 = 0;
	checksumMark = ( isInput ) ? _inByteCount : _outByteCount;
	}

void checksumEnd( const BOOLEAN isInput )
	{
	if( checksumIO )
		if( isInput )
			/* Checksum rest of data in inBuffer */
			crc16buffer( _inBuffer + checksumMark, _inByteCount - checksumMark );
		else
			/* Checksum rest of data in outBuffer */
			crc16buffer( _outBuffer + checksumMark, _outByteCount - checksumMark );

	checksumIO = FALSE;
	}

/* Return the current position in the data in this segment */

inline long getCurrLength( void )
	{
	return( currLength + _outByteCount - HPACK_ID_SIZE );
	}

/****************************************************************************
*																			*
*							Data Fast I/O Functions							*
*																			*
****************************************************************************/

#ifndef __MSDOS__

/* Get a byte from a FD with buffer read */

int _getByte( const FD _inFD )
	{
	_inByteCount = 0;
	if( ( _inBytesRead = hread( _inFD, _inBuffer, _BUFSIZE ) ) == ERROR )
		fileError();

	/* Checksum the data if required */
	if( checksumIO )
		{
		crc16buffer( _inBuffer + checksumMark, _inByteCount - checksumMark );
		checksumMark = 0;
		}

	return( ( _inByteCount == _inBytesRead ) ? FEOF : _inBuffer[ _inByteCount++ ] );
	}

/* Put a byte to a FD with buffer write */

void _putByte( const FD _outFD, const BYTE data )
	{
	/* Checksum the data if required */
	if( checksumIO )
		{
		crc16buffer( _outBuffer + checksumMark, _outByteCount - checksumMark );
		checksumMark = 0;
		}

	writeBuffer( _outFD, _BUFSIZE );
	_outBuffer[ _outByteCount++ ] = data;
	}

/* The function versions of putByte(), putWord(), and putLong().  These should
   be implemented in assembly language for efficiency */

#ifndef BIG_ENDIAN

inline void fputLong( const FD _outFD, const LONG value )
	{
	fputByte( _outFD, value & 0xFF );
	fputByte( _outFD, ( ( value ) >> 8 ) & 0xFF );
	fputByte( _outFD, ( ( value ) >> 16 ) & 0xFF );
	fputByte( _outFD, ( ( value ) >> 24 ) & 0xFF );
	}

inline void fputWord( const FD _outFD, const WORD data )
	{
	fputByte( _outFD, ( BYTE ) ( data ) );
	fputByte( _outFD, ( data ) >> BITS_PER_BYTE );
	}

#else

inline void fputLong( const FD _outFD, const LONG value )
	{
	fputByte( _outFD, ( ( value ) >> 24 ) & 0xFF );
	fputByte( _outFD, ( ( value ) >> 16 ) & 0xFF );
	fputByte( _outFD, ( ( value ) >> 8 ) & 0xFF );
	fputByte( _outFD, value & 0xFF );
	}

inline void fputWord( const FD _outFD, const WORD data )
	{
	fputByte( _outFD, ( data ) >> BITS_PER_BYTE );
	fputByte( _outFD, ( BYTE ) ( data ) );
	}

#endif /* !BIG_ENDIAN */

inline void fputByte( const FD _outFD, const BYTE data )
	{
	/* Write the buffer if necessary */
	if( _outByteCount == _BUFSIZE )
		{
		/* Checksum the data if required */
		if( checksumIO )
			{
			crc16buffer( _outBuffer + checksumMark, _BUFSIZE - checksumMark );
			checksumMark = 0;
			}

		writeBuffer( _outFD, _BUFSIZE );
		}

	_outBuffer[ _outByteCount++ ] = data;
	}

/* The function versions of getByte(), getWord(), and getLong() */

#ifndef BIG_ENDIAN

inline LONG fgetLong( const FD _inFD )
	{
	LONG value;

	value = ( LONG ) fgetByte( _inFD );
	value |= ( LONG ) fgetByte( _inFD ) << 8;
	value |= ( LONG ) fgetByte( _inFD ) << 16;
	value |= ( LONG ) fgetByte( _inFD ) << 24;
	return( value );
	}

inline WORD fgetWord( const FD _inFD )
	{
	WORD value;

	value = ( WORD ) fgetByte( _inFD );
	value |= ( WORD ) fgetByte( _inFD ) << BITS_PER_BYTE;
	return( value );
	}

#else

inline LONG fgetLong( const FD _inFD )
	{
	LONG value;

	value = ( LONG ) fgetByte( _inFD ) << 24;
	value |= ( LONG ) fgetByte( _inFD ) << 16;
	value |= ( LONG ) fgetByte( _inFD ) << 8;
	value |= ( LONG ) fgetByte( _inFD );
	return( value );
	}

inline WORD fgetWord( const FD _inFD )
	{
	WORD value;

	value = ( WORD ) fgetByte( _inFD ) << BITS_PER_BYTE;
	value |= ( WORD ) fgetByte( _inFD );
	return( value );
	}

#endif /* !BIG_ENDIAN */

inline int fgetByte( const FD _inFD )
	{
	if( _inByteCount == _BUFSIZE )
		return( _getByte( _inFD ) );
	else
		if( _inByteCount == _inBytesRead )
			return( FEOF );
		else
			return( _inBuffer[ _inByteCount++ ] );
	}

/****************************************************************************
*																			*
*						Directory Data Fast I/O Functions					*
*																			*
****************************************************************************/

/* Write data to the temporary directory data file.  These all write to the
   directory data file so there is no need to specify a file descriptor.  We
   can't use use fputByte(), fputWord(), or fputLong() for this since these
   write to the outBuffer, so we use these versions which use the dirBuffer */

#ifndef BIG_ENDIAN

void fputDirLong( const LONG data )
	{
	fputDirByte( data & 0xFF );
	fputDirByte( ( data >> 8 ) & 0xFF );
	fputDirByte( ( data >> 16 ) & 0xFF );
	fputDirByte( ( data >> 24 ) & 0xFF );
	}

void fputDirWord( const WORD data )
	{
	fputDirByte( ( BYTE ) data );
	fputDirByte( data >> BITS_PER_BYTE );
	}

#else

void fputDirLong( const LONG data )
	{
	fputDirByte( ( data >> 24 ) & 0xFF );
	fputDirByte( ( data >> 16 ) & 0xFF );
	fputDirByte( ( data >> 8 ) & 0xFF );
	fputDirByte( data & 0xFF );
	}

void fputDirWord( const WORD data )
	{
	fputDirByte( data >> BITS_PER_BYTE );
	fputDirByte( ( BYTE ) data );
	}

#endif /* !BIG_ENDIAN */

void fputDirByte( const BYTE data )
	{
	if( dirBufCount == DIRBUFSIZE )
		writeDirBuffer( dirBufCount );
	dirBuffer[ dirBufCount++ ] = data;
	}

#endif /* !__MSDOS__ */

/****************************************************************************
*																			*
*							Fast I/O Support Functions						*
*																			*
****************************************************************************/

/* Wait for the luser to continue when handling a multipart archive */

void multipartWait( const WORD promptType, const int partNo )
	{
	int i;

	if( promptType & WAIT_PARTNO )
		hprintf( MESG_PART_d_OF_MULTIPART_ARCHIVE, partNo + 1 );
	else
		hputchar( '\n' );
	hprintf( MESG_PLEASE_INSERT_THE );
	if( promptType & WAIT_NEXTDISK )
		hprintf( MESG_NEXT_DISK );
	else
		{
		hprintf( MESG_DISK_CONTAINING );
		if( promptType & WAIT_LASTPART )
			hprintf( MESG_THE_LAST_PART );
		else
			hprintf( MESG_PART_d, partNo + 1 );
		hprintf( MESG_OF_THIS_ARCHIVE );
		}
	hprintf( MESG_AND_PRESS_A_KEY );
	hgetch();
	hputchar( '\r' );
	for( i = 0; i < 79; i++ )
		hputchar( ' ' );	/* Blank out prompt message */
	hputchar( '\r' );
	if( promptType & WAIT_NEXTDISK )
		hprintf( MESG_CONTINUING );
	}

/* Skip ahead a certain number of bytes.  Doing this as a direct hlseek() is
   not possible since some of the data may already be in the buffer or may be
   on a different disk */

void skipSeek( const FD _inFD, LONG skipLength )
	{
	int bytesInBuffer = _inBytesRead - _inByteCount;
	int thePart;

	if( skipLength < bytesInBuffer )
		/* We can satisfy the request with what is still in the buffer */
		_inByteCount += ( WORD ) skipLength;
	else
		{
		/* First use all the bytes still in the buffer */
		skipLength -= bytesInBuffer;

		/* Now we can do an hseek() if necessary */
		if( skipLength )
			/* Check if we can satisfy the seek request in the current
			   archive part */
			if( !( flags & MULTIPART_ARCH ) || \
				currPart == ( thePart = getPartNumber( skipLength ) ) )
				hlseek( _inFD, skipLength, SEEK_CUR );
			else
				{
				/* Seek destination is outside the current archive section,
				   prompt for a new disk */
				hclose( archiveFD );
				multipartWait( 0, thePart );
/* All sorts of hideous code to check the part number etc - needs a call to
   readArcDir() or some derivative to read in the trailer, then loop asking
   for another disk until it's the correct one */
				hputs( "\nPunt" );
				exit( 0 );
				}

		/* Force a read at the next getByte() */
		forceRead();
		}
	}

/* Set the output intercept */

void setOutputIntercept( OUTINTERCEPT_TYPE interceptType )
	{
	outputIntercept = interceptType;

	switch( outputIntercept )
		{
		case OUT_FMT_TEXT:
			/* Formatted text output */
			initOutFormatText();
			break;

		/* Default: No action */
		}
	}

/* Reset the output intercept to the default setting */

void resetOutputIntercept( void )
	{
	switch( outputIntercept )
		{
		case OUT_FMT_TEXT:
			/* Formatted text output */
			endOutFormatText();
			break;

		/* Default: No action */
		}

	/* Reset output intercept to default type */
	outputIntercept = OUT_DATA;
	}

/* Read in a bufferful of data, skipping to the next disk in the case of a
   multipart archive */

void vRead( const BYTE *buffer, int bufSize )
	{
	int startOffset = 0;	/* Remember start position of read */

	/* Perform a read, checking for end of data */
retry:
	if( hread( archiveFD, buffer, bufSize ) < bufSize && \
		( flags & MULTIPART_ARCH ) && currPart < lastPart )
		{
		/* More parts to go, get the next disk */
		currPart++;
		getPart( currPart );

		/* Read in the rest of _inBuffer */
		startOffset += _inBytesRead;
		hlseek( archiveFD, HPACK_ID_SIZE, SEEK_SET );
		goto retry;
		}
	}

/* Write out a certain amount of data.  This is a special version which checks
   for the disk being full by making sure the no.of bytes written are the same
   as the number of bytes requested to be written, as well as the normal
   ERROR return value, since hwrite() does not treat disk full as an ERROR,
   and also handles multi-part archives by asking for another disk */

#define MULTIPART_TRAILER_SIZE	( HPACK_ID_SIZE + sizeof( WORD ) + sizeof( BYTE ) )
#define MIN_PARTSIZE			500		/* Min.data size for which we bother */
#define MIN_ARCHIVE_SIZE		( HPACK_ID_SIZE + MIN_PARTSIZE + MULTIPART_TRAILER_SIZE )

void _writeBuffer( const FD _outFD, const BYTE *buffer, int bufSize )
	{
	int i, bytesWritten;

	switch( outputIntercept )
		{
		case OUT_FMT_TEXT:
			/* Formatted text output */
			for( i = 0; i < bufSize; i++ )
				outFormatChar( buffer[ i ] );
			break;

		case OUT_DATA:
retryWrite:
			/* Raw data output to FD */
			if( ( bytesWritten = hwrite( _outFD, buffer, bufSize ) ) == ERROR )
				fileError();
			else
				{
				/* Update count of bytes written.  Note that this does not
				   include the header or trailer information, only the raw data */
				currLength += bytesWritten;
#ifdef __MSDOS__
				/* Wonderful things to tell your kids #27: The check for the
				   identity of _outFD is necessary under MSDOS since there is
				   a ^Z (CPM EOF) on the end of the file which is not written,
				   and which ends up causing an "Out of disk space" error on
				   STDOUT if it isn't caught */
				if( ( bytesWritten != bufSize ) && ( _outFD > STDPRN ) )
#else
				if( bytesWritten != bufSize )
#endif /* __MSDOS__ */
					/* If its a multidisk archive, running out of disk space
					   should not be treated as an error */
					if( flags & MULTIPART_ARCH )
						{
						/* Check whether the archive is big enough to make it
						   worthwhile */
						currLength -= HPACK_ID_SIZE + MULTIPART_TRAILER_SIZE;
									/* Don't count info at start and end */
						i = 0;
						if( currLength > MIN_PARTSIZE )
							{
							/* Check if there's enough room to append the
							   trailer information */
							if( bytesWritten < MULTIPART_TRAILER_SIZE )
								{
								/* Not enough room to append trailer information,
								   backtrack and read in data at end of archive
								   which is about to be overwritten */
								i = MULTIPART_TRAILER_SIZE - bytesWritten;
								hlseek( archiveFD, -( LONG ) MULTIPART_TRAILER_SIZE, SEEK_END );
								hread( archiveFD, mrglBuffer + HPACK_ID_SIZE, i );

								/* Move data which will be overwritten by the
								   trailer info.into mrglBuffer as well */
								memcpy( mrglBuffer + HPACK_ID_SIZE + i, \
										_outBuffer, MULTIPART_TRAILER_SIZE );
								i += MULTIPART_TRAILER_SIZE;
								bytesWritten = MULTIPART_TRAILER_SIZE;
								}
							else
								/* Under most OS's this is the only case which
								   will ever occur since writes are rounded to
								   the disk sector size */
								bytesWritten -= MULTIPART_TRAILER_SIZE;

							/* Backtrack MULTIPART_TRAILER_SIZE bytes */
							hlseek( archiveFD, -( LONG ) MULTIPART_TRAILER_SIZE, SEEK_END );

							/* Append trailer information */
							fputWord( archiveFD, currPart++ );
							fputByte( archiveFD, SPECIAL_MULTIPART );
							fputByte( archiveFD, HPACK_ID[ 0 ] );
							fputByte( archiveFD, HPACK_ID[ 1 ] );
							fputByte( archiveFD, HPACK_ID[ 2 ] );
							fputByte( archiveFD, HPACK_ID[ 3 ] );
							hwrite( archiveFD, _outBuffer, MULTIPART_TRAILER_SIZE );
							hclose( archiveFD );
							addPartSize( totalLength + currLength );
							lastPart++;
							}
						else
							{
							/* Archive is too short to bother with, delete it */
							if( currLength > bytesWritten )
								{
								/* Read back data already written */
								currLength -= bytesWritten;		/* Don't reread data in _outBuf */
								currLength += MULTIPART_TRAILER_SIZE;	/* Adj.len.to proper size */
								i = ( int ) currLength;
								hlseek( archiveFD, HPACK_ID_SIZE, SEEK_SET );
								hread( archiveFD, mrglBuffer + HPACK_ID_SIZE, i );
								}
							bytesWritten = 0;
							hclose( archiveFD );
							hunlink( errorFileName );
							errorFD = 0;	/* No need to delete arch.on err.any more */
							hprintf( WARN_ARCHIVE_SECTION_TOO_SHORT );
							}

						/* Go to next disk */
						multipartWait( WAIT_NEXTDISK, 0 );
						if( !( flags & OVERWRITE_SRC ) && \
							( archiveFD = hopen( errorFileName, O_RDONLY ) ) != ERROR )
							{
							/* Make sure we don't overwrite an existing archive
							   unless explicity asked to */
							hclose( archiveFD );
							error( CANNOT_OPEN_ARCHFILE, errorFileName );
							}
						if( ( errorFD = archiveFD = hcreat( errorFileName, CREAT_ATTR ) ) == ERROR )
							error( CANNOT_OPEN_ARCHFILE, errorFileName );

						/* Try and write out the number of bytes we need for
						   a minimum-size archive */
						memcpy( mrglBuffer, HPACK_ID, HPACK_ID_SIZE );
						i += HPACK_ID_SIZE;
						while( hwrite( archiveFD, mrglBuffer, \
									   MIN_ARCHIVE_SIZE ) < MIN_ARCHIVE_SIZE )
							{
							hclose( archiveFD );
							hunlink( errorFileName );
							errorFD = 0;
							hprintf( WARN_ARCHIVE_SECTION_TOO_SHORT );
							multipartWait( WAIT_NEXTDISK, 0 );
							if( !( flags & OVERWRITE_SRC ) && \
								( archiveFD = hopen( errorFileName, O_RDONLY ) ) != ERROR )
								{
								/* Make sure we don't overwrite an existing
								   archive unless explicity asked to */
								hclose( archiveFD );
								error( CANNOT_OPEN_ARCHFILE, errorFileName );
								}
							if( ( errorFD = archiveFD = hcreat( errorFileName, CREAT_ATTR ) ) == ERROR )
								error( CANNOT_OPEN_ARCHFILE, errorFileName );
							}
						hlseek( archiveFD, i, SEEK_SET );	/* Seek back to last valid byte */
						totalLength += currLength;	/* Add new segment size */
						currLength = ( LONG ) i;

						/* Now we have room for an archive of at least
						   MIN_ARCHIVE_SIZE bytes as well as having written
						   out any backread data.  Move data down to start
						   of _outBuffer if necessary and retry the write */
						if( bytesWritten )
							memcpy( _outBuffer, _outBuffer + bytesWritten, bufSize - bytesWritten );
						bufSize -= bytesWritten;
						goto retryWrite;
						}
					else
						error( OUT_OF_DISK_SPACE );
				}

		/* Default: Do nothing with it */
		}
	}

/* High-level writeBuffer() routine with character set translation */

#define DC1		( 0x11 ^ 0x80 )	/* Prime ASCII run count escape code in
								   high-bit set format */
#define CPM_EOF	0x1A			/* ^Z which turns up in some MSDOS files */

void writeBuffer( const FD _outFD, const int bufSize )
	{
	static BOOLEAN isRunCount = FALSE;
#if !defined( __MSDOS__ ) && !defined( __OS2__ )
	static BOOLEAN crSeen = FALSE;
#endif /* !( __MSDOS__ || __OS2__ ) */
	BYTE ch;

	_outByteCount = 0;				/* Reset byte counter */

	/* We may have more work to do if we are using output translation.
	   The order of translation is to translate char sets, then translate
	   EOF chars */
	if( flags & XLATE_OUTPUT )
		{
		if( xlateFlags & XLATE_PRIME )
			{
			/* Translate buffer from Prime ASCII -> normal ASCII */
			while( _outByteCount < bufSize )
				{
				/* Get char, treat as run count if necessary */
				ch = _outBuffer[ _outByteCount++ ];
				if( isRunCount )
					{
					/* Output RLE'd spaces */
					while( ch-- )
						putMrglByte( _outFD, ' ' );
					isRunCount = FALSE;
					continue;
					}

				/* Don't output special chars */
				if( ch == DC1 || !ch )
					{
					isRunCount = ( ch == DC1 );
					continue;
					}

				/* Output char with high bits toggled; if it's a NL, prepend
				   a CR */
				if( ( ch ^ 0x80 ) == '\n' )
					putMrglByte( _outFD, '\r' );
				putMrglByte( _outFD, ch ^ 0x80 );
				}

			_outByteCount = 0;		/* Re-reset byte counter */
			return;					/* Leave now */
			}
		else
			{
			if( xlateFlags & XLATE_EBCDIC )
				/* Translate buffer from EBCDIC -> ASCII */
				while( _outByteCount < bufSize )
					{
					_outBuffer[ _outByteCount ] = xlateTbl[ _outBuffer[ _outByteCount ] ];
					_outByteCount++;	/* Can't do above - used on LHS and RHS */
					}

			_outByteCount = 0;		/* Reset byte counter */

			if( xlateFlags & XLATE_EOL )
				{
				/* Perform EOL translation */
				while( _outByteCount < bufSize )
					{
					/* Check whether we need to translate this char */
#if defined( __MSDOS__ ) || defined( __OS2__ )
					if( ( ch = _outBuffer[ _outByteCount++ ] ) == lineEndChar )
						{
						/* Output CRLF in place of existing line terminator */
						putMrglByte( _outFD, '\r' );
						putMrglByte( _outFD, '\n' );
						}
#else
					if( ( ch = _outBuffer[ _outByteCount++ ] ) == ( lineEndChar & 0x7F ) )
						{
						/* Check for CR of CRLF pair if necessary */
						if( ( lineEndChar & 0x80 ) && ch == '\r' )
							{
							/* Seen CR of CRLF pair */
							crSeen = TRUE;
							continue;
							}

						if( !crSeen || ( crSeen && ch == '\n' ) )
							/* See either CR alone, LF alone, or CRLF */
  #if defined( __UNIX__ ) || defined( __AMIGA__ )
							putMrglByte( _outFD, '\n' );
  #elif defined( __MAC__ )
							putMrglByte( _outFD, '\r' );
  #endif /* Various OS-specific defines */
						else
							/* Must have been a spurious CR-only */
							if( ch != CPM_EOF )
								putMrglByte( _outFD, ch );
						crSeen = FALSE;
						}
#endif /* __MSDOS__ || __OS2__ */
					else
						/* Copy the value across directly */
						if( ch != CPM_EOF )
							putMrglByte( _outFD, ch );
					}

				_outByteCount = 0;		/* Re-reset byte counter */
				return;					/* Leave now */
				}
			}
		}

	/* Call internal writeBuffer routine to do the actual write */
	_writeBuffer( _outFD, _outBuffer, bufSize );
	}

void writeMrglBuffer( const FD _outFD, const int bufSize )
	{
	mrglBufCount = 0;	/* Reset byte counter */

	/* Call internal writeBuffer routine to do the actual write */
	_writeBuffer( _outFD, mrglBuffer, bufSize );
	}

void writeDirBuffer( const int bufSize )
	{
	int bytesWritten;

	dirBufCount = 0;	/* Reset byte counter */
	if( ( bytesWritten = hwrite( dirFileFD, dirBuffer, bufSize ) ) == ERROR )
		fileError();
	else
		/* Since the dirBuffer is only ever written to disk we don't need
		   to check for ^Z irregularities under MSDOS */
		if( bytesWritten != bufSize )
			error( OUT_OF_DISK_SPACE );
	}

/* Flush the output buffers */

void flush( const FD _outFD )
	{
	if( flags & XLATE_OUTPUT )
		{
		/* If we are translating the output, first force the translation of
		   the rest of the output buffer with a call to writeBuffer, and then
		   flush the mrgl buffer if necessary */
		writeBuffer( _outFD, _outByteCount );
		flushMrglBuffer( _outFD );
		}
	else
		/* Otherwise flush the std.output buffer */
		if( _outByteCount )
			{
			/* Checksum the data if required */
			if( checksumIO )
				{
				crc16buffer( _outBuffer + checksumMark, _outByteCount - checksumMark );
				checksumMark = 0;
				}

			writeBuffer( _outFD, _outByteCount );
			}
	}

inline void flushMrglBuffer( const FD _outFD )
	{
	if( mrglBufCount )
		writeMrglBuffer( _outFD, mrglBufCount );
	}

inline void flushDirBuffer( void )
	{
	if( dirBufCount )
		writeDirBuffer( dirBufCount );
	}
