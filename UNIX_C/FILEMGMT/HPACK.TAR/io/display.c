/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*					 	Output Intercept Handling Routines					*
*							DISPLAY.C  Updated 25/10/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*			Copyright 1991  Peter C.Gutmann.  All rights reserved			*
*																			*
****************************************************************************/

#include <string.h>
#include "defs.h"
#ifdef SYSV
  #include "../frontend.h"
  #include "../hpacklib.h"
#else
  #include "frontend.h"
  #include "hpacklib.h"
#endif /* SYSV */

/* Maximum possible screen width */

#define MAX_WIDTH	150

#ifdef __MSDOS__

/* Prototypes for functions in BIOSCALL.ASM */

BYTE getAttribute( void );
void writeChar( const char ch, const BYTE attribute );

/* Text mode information */

#define NORMAL_ATTR		0x07	/* Normal text */
#define BLINK_MASK		0x80	/* Mask for blink bit */
#define INTENSITY_MASK	0x08	/* Mask for intensity bit */

#endif /* __MSDOS__ */

/* Command settings */

BOOLEAN doJustify, doCenter;
int leftMargin, rightMargin, tempIndent;

/* Internal status info */

int lineNo;
int outPos, outWords;
char outBuffer[ MAX_WIDTH ];	/* Max possible screen width */
BOOLEAN breakFollows;
#ifdef __MSDOS__
  BYTE outAttrBuffer[ MAX_WIDTH ];
  BYTE attribute;
  BOOLEAN putSpace;				/* Whether there is a space queued */
#endif /* __MSDOS__ */

/* Prototypes for various functions */

static void putWord( char *word, int length );

/* Get an optional numeric parameter */

static void getParam( char *str, int *theValue, const int defaultValue, \
					 const int minValue, const int maxValue )
	{
	char ch;
	int value = 0;
	BOOLEAN sign = FALSE, absolute = TRUE;

	/* Skip whitespace */
	while( ( ch = *str ) == ' ' || ch == '\t' )
		str++;

	/* Check for sign */
	if( ( ch = *str ) == '-' || ch == '+' )
		{
		str++;
		absolute = FALSE;	/* This is a delta not an absolute value */
		sign = ch - '+';	/* sign = ~( ch - '+' + 1 ); value *= sign */
		}

	/* Get digit */
	while( *str > '0' && *str < '9' )
		value = ( value * 10 ) + ( *str++ - '0' );

	/* Adjust sign */
	if( sign )
		value = -value;

	/* Do range check */
	if( value )
		if( absolute )
			*theValue = value;
		else
			*theValue += value;
	else
		*theValue = defaultValue;
	if( *theValue < minValue )
		*theValue = minValue;
	if( *theValue > maxValue )
		*theValue = maxValue;
	}

/* Force a line break */

static void doBreak( void )
	{
	BOOLEAN justifyValue = doJustify;

	doJustify = FALSE;		/* Make sure we don't justify half-full line */
	putWord( "", rightMargin );
	doJustify = justifyValue;
	outPos = leftMargin + tempIndent;
	tempIndent = 0;
	}

/* Process a formatting command.  Note that we can't do an immediate break in
   some cases when the command has an implied .br since it may be followed
   by further implied-.br commands, so we set the breakFollows flag which
   forces a break when we next output text */

static void processCommand( char *command )
	{
	int commandVal = *( ( int * ) command );

	switch( commandVal )
		{
#ifdef __MSDOS__
		case 'bo':
			/* Boldface text */
			attribute |= INTENSITY_MASK;
			break;
#endif /* __MSDOS__ */

		case 'bp':
			/* Page break */
			doBreak();
			while( lineNo )
				/* Print lots of blank lines */
				doBreak();

		case 'br':
			/* Line break */
			doBreak();
			break;

		case 'ce':
			/* Center text */
			doBreak();
			doCenter = TRUE;
			break;

		case 'fi':
			/* Justify text */
			breakFollows = doJustify = TRUE;
			break;

#ifdef __MSDOS__
		case 'fl':
			/* Flashing text */
			attribute |= BLINK_MASK;
			break;
#endif /* __MSDOS__ */

		case 'in':
			/* Set left margin */
			breakFollows = TRUE;
			getParam( command + 2, &leftMargin, 0, -leftMargin, rightMargin );
			break;

#ifdef __MSDOS__
		case 'it':
			/* Italic text */
			attribute |= INTENSITY_MASK;	/* Treat as italic text */
			break;

		case 'iv':
			/* Inverse text */
			attribute = ( attribute & 0x88 ) | ( ( attribute & 0x70 ) >> 4 ) | \
											   ( ( attribute & 0x07 ) << 4 );
			break;
#endif /* __MSDOS__ */

		case 'nf':
			/* Don't justify text */
			breakFollows = TRUE;
			doJustify = FALSE;
			break;

#ifdef __MSDOS__
		case 'no':
			/* Normal text mode */
			attribute = NORMAL_ATTR;
			break;
#endif /* __MSDOS__ */

		case 'rm':
			/* Set right margin */
			breakFollows = TRUE;
			rightMargin = screenWidth - rightMargin;
			getParam( command + 2, &rightMargin, 0, 0, screenWidth - leftMargin - 1 );
			rightMargin = screenWidth - rightMargin;
			break;

		case 'ti':
			/* Temporary indent */
			breakFollows = TRUE;
			getParam( command + 2, &tempIndent, -leftMargin, -leftMargin, rightMargin );
			break;

		}
	}

/* Output a word with all sorts of fancy formatting */

static void putWord( char *word, int length )
	{
	int noBlanks, i;
	static BOOLEAN forwards = TRUE;

	/* See if there is a break in the pipeline */
	if( breakFollows )
		{
		breakFollows = FALSE;
		doBreak();
		}

#ifdef __MSDOS__
	/* Add a space if there's one queued.  We couldn't output this earlier
	   since there may have been an attribute change since then */
	if( putSpace )
		{
		putSpace = FALSE;
		outBuffer[ outPos++ ] = ' ';
		outAttrBuffer[ outPos - 1 ] = attribute;
		}
#endif /* __MSDOS__ */

	/* Check whether line is full */
	if( outPos + length >= rightMargin )
		{
		outBuffer[ outPos ] = '\0';

		/* Delete trailing blank */
		if( outBuffer[ outPos - 1 ] == ' ' )
			outBuffer[ --outPos ] = '\0';

		/* Check for special text formatting */
		if( doCenter )
			{
			/* Pad out line with spaces to center text */
			for( i = 0; outBuffer[ i ] == ' '; i++ );
			noBlanks = ( ( rightMargin - leftMargin ) - strlen( outBuffer + i ) ) >> 1;
			while( noBlanks-- )
				hputchar( ' ' );
			doCenter = FALSE;
			}
		else
			if( doJustify && outPos < rightMargin )
				{
				/* Spread out the words on this line.  Note the use of
				   memmove() instead of strcpy() since the source and
				   destination strings overlap */
				noBlanks = ( rightMargin - outPos );
				while( noBlanks )
					{
					if( forwards )
						{
						/* Starting from the beginning of the line, insert
						   an extra space where there is already one */
						for( i = leftMargin + 1; i <= rightMargin; i++ )
							if( outBuffer[ i ] == ' ' )
								{
								memmove( outBuffer + i + 1, outBuffer + i, rightMargin - i );
#ifdef __MSDOS__
								memmove( outAttrBuffer + i + 1, outAttrBuffer + i, rightMargin - i );
#endif /* __MSDOS__ */
								noBlanks--;
								i++;	/* Skip new blank */
								if( !noBlanks )
									break;
								}
						}
					else
						/* Starting from the end of the line, insert an extra
						   space where there is already one */
						for( i = outPos - 1; i > leftMargin; i-- )
							if( outBuffer[ i ] == ' ' )
								{
								memmove( outBuffer + i + 1, outBuffer + i, rightMargin - i );
#ifdef __MSDOS__
								memmove( outAttrBuffer + i + 1, outAttrBuffer + i, rightMargin - i );
#endif /* __MSDOS__ */
								noBlanks--;
								i--;	/* Skip new blank */
								if( !noBlanks )
									break;
								}

					/* Reverse direction for next round */
					forwards = !forwards;
					}
				}
		outBuffer[ screenWidth + 1 ] = '\0'; /* Make sure we never overrun screen */
#ifdef __MSDOS__
		noBlanks = strlen( outBuffer );
		for( i = 0; i < noBlanks; i++ )
			writeChar( outBuffer[ i ], outAttrBuffer[ i ] );
		if( noBlanks <= screenWidth )
			hputchar( '\n' );
#else
		if( strlen( outBuffer ) == screenWidth + 1 )
			hprintf( "%s", outBuffer );	/* Line = screen width, no need for NL */
		else
			hprintf( "%s\n", outBuffer );
#endif /* __MSDOS__ */

		/* Indent next line of text */
		memset( outBuffer, ' ', leftMargin + tempIndent );
#ifdef __MSDOS__
		memset( outAttrBuffer, NORMAL_ATTR, leftMargin + tempIndent );
#endif /* __MSDOS__ */
		outPos = leftMargin + tempIndent;
		outWords = 0;

		/* Handle page breaks */
		lineNo++;
		if( lineNo >= screenHeight - 1 )
			{
			hgetch();
			lineNo = 0;
			}
		}
	strncpy( outBuffer + outPos, word, length );
#ifdef __MSDOS__
	memset( outAttrBuffer + outPos, attribute, length );
#endif /* __MSDOS__ */
	outPos += length;
	if( outPos < rightMargin )
#ifdef __MSDOS__
		if( attribute != NORMAL_ATTR )
			/* We can't add the space now since the attribute may change by
			   the time it is due to be inserted, so we queue it for later
			   insertion */
			putSpace = TRUE;
		else
			{
			outBuffer[ outPos++ ] = ' ';
			outAttrBuffer[ outPos - 1 ] = attribute;
			}
#else
		outBuffer[ outPos++ ] = ' ';
#endif /* __MSDOS__ */
	outWords++;
	}

/****************************************************************************
*																			*
*						Formatted Output Driver Code						*
*																			*
****************************************************************************/

int lineBufCount;
char lineBuffer[ MAX_WIDTH ];
BOOLEAN wasNewline;

/* Initialise the format routines */

void initOutFormatText( void )
	{
	/* Set up defaults */
	doJustify = FALSE;
	doCenter = FALSE;
	leftMargin = 0;
	rightMargin = screenWidth;

	/* Set up internal status info */
	lineNo = 0;
	outPos = 0;
	tempIndent = 0;
	lineBufCount = 0;
	wasNewline = TRUE;	/* At start we've just 'seen' a newline */
	breakFollows = FALSE;
#ifdef __MSDOS__
	attribute = getAttribute();
	putSpace = FALSE;
#endif /* __MSDOS__ */
	}

/* Output a char via the format routines */

void outFormatChar( char ch )
	{
	/* Put a word in the line buffer */
	if( ch != '\r' && ch != '\n' && ch != 0x1A && \
		( ( wasNewline && *lineBuffer == '.' ) || ( ch != ' ' && ch != '\t' ) ) )
		{
		if( ch >= ' ' && ch <= '~' )
			lineBuffer[ lineBufCount++ ] = ch;

		/* Force line break if line is overly long */
		if( leftMargin + tempIndent + lineBufCount > rightMargin )
			goto lineBreak;
		}
	else
		{
lineBreak:
		lineBuffer[ lineBufCount ] = '\0';

		/* Process the data in the lineBuffer */
		if( wasNewline && *lineBuffer == '.' )
			processCommand( lineBuffer + 1 );
		else
			if( lineBufCount )
				putWord( lineBuffer, lineBufCount );
		lineBufCount = 0;

		/* Keep track of whether we've just seen a newline, after which
		   dotcommands are valid */
		if( wasNewline )
			wasNewline = FALSE;
		if( ch == '\r' || ch == '\n' || ch == 0x1A )
			wasNewline = TRUE;
		}
	}

/* Shutdown function for formatted text output */

void endOutFormatText( void )
	{
	/* Flush last line of text */
	putWord( "", rightMargin );
	}
