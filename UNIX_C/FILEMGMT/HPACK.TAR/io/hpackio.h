/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*						  HPACK I/O Routines Header File					*
*							HPACKIO.H  Updated 03/10/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1990, 1991  Peter C.Gutmann.  All rights reserved			*
*																			*
****************************************************************************/

#ifndef _HPACKIO_DEFINED

#define _HPACKIO_DEFINED

/* The type of a FD */

typedef int			FD;

/* File I/O error return codes */

#define IO_ERROR	-1

/* File access code */

#ifndef __UNIX__
  #define O_RDONLY	0
  #define O_WRONLY	1
  #define O_RDWR	2
#endif /* __UNIX__ */

#ifdef __MSDOS__

/* Sharing mode */

#define S_COMPAT	0
#define S_DENYRDWR	( 1 << 4 )
#define S_DENYWR	( 2 << 4 )
#define S_DENYRD	( 3 << 4 )
#define S_DENYNONE	( 4 << 4 )

#else

/* Most systems won't support file locking */

#define	S_COMPAT	0
#define S_DENYRDWR	0
#define	S_DENYWR	0
#define S_DENYRD	0
#define S_DENYNONE	0

#endif /* __MSDOS__ */

/* Origin codes for hlseek() */

#define SEEK_SET	0
#define SEEK_CUR	1
#define SEEK_END	2

/* Standard streams */

#define STDIN		0
#define STDOUT		1
#define STDERR		2
#define STDAUX		3
#define STDPRN		4

#define NULL_STREAM	0

#if !defined( __MSDOS__ ) && !defined( __IIGS__ )

#include <fcntl.h>

/* Macros to turn the generic HPACKIO functions into their equivalent on
   the current system */

#define hcreat	creat			/* Create a file */
#define hopen	open			/* Open existing file */
#define hclose	close			/* Close file */
#define hlseek	lseek			/* Seek to position in file */
#define htell	tell			/* Return current position in file */
#define hread	read			/* Read data from a file */
#define hwrite	write			/* Write data to a file */
#define hchmod	chmod			/* Change file attributes */
#define hunlink	unlink			/* Delete file */
#ifndef __UNIX__
  #define hmkdir	mkdir		/* Create directory */
#else
int hmkdir( const char *dirName, const int attr );
#endif /* __UNIX__ */
#define hchdir	chdir			/* Change directory */
#define hrename	rename			/* Rename file */

#else

/* Prototypes for functions in HPACKIO library */

int hcreat( const char *fileName, const int attr );
int hopen( const char *fileName, const BYTE mode );
int hclose( const FD theFD );
long hlseek( const FD theFD, const LONG position, const int whence );
long htell( const FD theFD );
int hread( const FD theFD, const void *buffer, const unsigned int bufSize );
int hwrite( const FD theFD, const void *buffer, const unsigned int bufSize );
int htruncate( const FD theFD );
int hchmod( const char *fileName, const WORD attr );
int hunlink( const char *fileName );
int hmkdir( const char *dirName, const int attr );
int hchdir( const char *dirName );
int hrename( const char *srcName, const char *destName );

#endif /* !( __MSDOS__ || __IIGS__ ) */

#endif /* !_HPACKIO_DEFINED */
