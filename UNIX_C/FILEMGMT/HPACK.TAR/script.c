/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*							 Script File Handling Code						*
*							SCRIPT.C  Updated 09/12/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*			Copyright 1991  Peter C.Gutmann.  All rights reserved			*
*																			*
****************************************************************************/

#include <string.h>
#include <stdio.h>
#include "defs.h"
#include "error.h"
#include "filesys.h"
#include "flags.h"
#include "frontend.h"
#include "hpacklib.h"
#include "hpaktext.h"
#include "system.h"
#include "wildcard.h"
#include "io/fastio.h"
#include "io/hpackio.h"

/****************************************************************************
*																			*
*						Build/Free List of Files to Handle					*
*																			*
****************************************************************************/

/* The start of the list of fileSpecs */

FILEPATHINFO *filePathListStart = NULL;

/* Add a filespec to the list of files to handle */

void addFilespec( char *fileSpec )
	{
	FILEPATHINFO *theNode, *prevNode, *newNode;
	FILENAMEINFO *fileNamePtr, *prevFileNamePtr;
	char fileCode[ MATCH_DEST_LEN ];
	char pathName[ MAX_PATH ];
	int pathNameEnd, count, nonMatch;

	/* Check the path is of a legal length */
	if( strlen( fileSpec ) > MAX_PATH - 1 )
		error( PATH_S_TOO_LONG, fileSpec );

	/* Extract the pathname and convert it into an OS-compatible format */
	pathNameEnd = extractPath( fileSpec, pathName );

	/* Compile the filespec into a form acceptable by the wildcard-matching
	   finite-state machine */
	count = compileString( fileSpec + pathNameEnd, fileCode );

	/* Now sort the file names by path as they are added, in order to make disk
	   accesses more efficient.  This can be done by a simple insertion sort
	   since there are only a small number of names to sort, and it can be done
	   on the fly.  Note that there is one case in which the files won't be
	   sorted:  If there drive specs, normal files/paths, and files/paths
	   beginning with letters lower than ':' then they will be put before the
	   drive specs, with the rest of the normal files/paths being placed
	   after the drive specs.  However the occurrence of filenames containing
	   these characters is virtually unheard-of so no special actions are
	   taken for them */
	theNode = filePathListStart;
	if( filePathListStart == NULL )
		{
		/* Create the initial list node */
		if( ( filePathListStart = newNode = hmalloc( sizeof( FILEPATHINFO ) ) ) == NULL )
			error( OUT_OF_MEMORY );
		}
	else
		{
		/* Find the correct position to insert the new pathname */
		prevNode = filePathListStart;
		while( theNode != NULL && ( nonMatch = strcmp( pathName, theNode->filePath ) ) > 0 )
			{
			prevNode = theNode;
			theNode = theNode->next;
			}

		/* Don't insert the pathname if it's already in the list */
		if( !nonMatch )
			{
			/* Find the end of the list of fileNames and add a new node */
			for( prevFileNamePtr = fileNamePtr = theNode->fileNames; \
				 fileNamePtr != NULL; prevFileNamePtr = fileNamePtr, \
				 fileNamePtr = fileNamePtr->next )
				/* Leave now if the fileName is already in the list */
				if( !strncmp( fileNamePtr->fileName, fileCode, count ) )
					return;
			fileNamePtr = prevFileNamePtr;

			if( ( fileNamePtr->next = hmalloc( sizeof( FILENAMEINFO ) ) ) == NULL )
				error( OUT_OF_MEMORY );
			fileNamePtr = fileNamePtr->next;
			goto nodeExists;
			}

		/* Create the new node and link it into the list */
		if( ( newNode = hmalloc( sizeof( FILEPATHINFO ) ) ) == NULL )
			error( OUT_OF_MEMORY );
		if( prevNode == filePathListStart )
			{
			/* Insert at start of list */
			filePathListStart = newNode;
			theNode = prevNode;
			}
		else
			/* Insert in middle/end of list */
			prevNode->next = newNode;
		}

	newNode->next = theNode;
	theNode = newNode;

#if defined( __UNIX__ ) || defined( __MAC__ )
	/* Make sure we're not trying to override an existing base path */
	if( *basePath && *pathName == '/' )
		error( CANNOT_OVERRIDE_BASEPATH, basePath );
#else
	/* Get the drive to use and make sure we're not trying to override an
	   existing path with it  */
	if( ( ( newNode->drive = ( *pathName && pathName[ 1 ] == ':' ) ? \
				*pathName - 'A' : ERROR ) >= 0 && *basePath ) || \
				( *basePath && basePath[ 1 ] == ':' && \
				  basePath[ 2 ] && *pathName == '/' ) )
		error( CANNOT_OVERRIDE_BASEPATH, basePath );
#endif /* __UNIX__ || __MAC__ */

	if( ( newNode->filePath = ( char * ) hmalloc( pathNameEnd + 2 ) ) == NULL )
		error( OUT_OF_MEMORY );
	strncpy( newNode->filePath, pathName, pathNameEnd );
	newNode->filePath[ pathNameEnd ] = '\0';

	if( ( newNode->fileNames = hmalloc( sizeof( FILENAMEINFO ) ) ) == NULL )
		error( OUT_OF_MEMORY );
	fileNamePtr = newNode->fileNames;

nodeExists:
	fileNamePtr->next = NULL;

	/* Add the compiled filespec to the list of filespecs */
	if( ( fileNamePtr->fileName = ( char * ) hmalloc( count ) ) == NULL )
		error( OUT_OF_MEMORY );
	memcpy( fileNamePtr->fileName, fileCode, count );
	}

#ifndef __MSDOS__

/* Free up the memory used by the list of filespecs.  See the comment in
   freeArchiveNames() for why we use this complex double-stepping way of
   freeing the headers */

void freeFilespecs( void )
	{
	FILEPATHINFO *pathHeaderCursor = filePathListStart, *pathHeaderPtr;
	FILENAMEINFO *nameHeaderCursor, *nameHeaderPtr;

	/* Free the nodes of the filePath list */
	while( pathHeaderCursor != NULL )
		{
		/* Free the nodes of the fileName list */
		nameHeaderCursor = pathHeaderCursor->fileNames;
		while( nameHeaderCursor != NULL )
			{
			nameHeaderPtr = nameHeaderCursor;
			nameHeaderCursor = nameHeaderCursor->next;
			hfree( nameHeaderPtr->fileName );
			hfree( nameHeaderPtr );
			}

		pathHeaderPtr = pathHeaderCursor;
		pathHeaderCursor = pathHeaderCursor->next;
		hfree( pathHeaderPtr->filePath );
		hfree( pathHeaderPtr );
		}
	}
#endif /* !__MSDOS__ */

/****************************************************************************
*																			*
*								Process a List-File							*
*																			*
****************************************************************************/

/* The types of error we check for */

enum { NO_ERROR, ILLEGAL_CHAR_ERROR, PATH_ERROR };

#define CPM_EOF	0x1A		/* ^Z = CPM EOF char */

#define MAX_ERRORS	10		/* Max.no.errors before we give up */

void processListFile( const char *listFileName )
	{
	FD listFileFD;
	int ch = 0, theCh;
	int errType, errPos, errCount = 0, line = 1;
	static BOOLEAN firstError = TRUE;
	BOOLEAN seenCR = FALSE;

	if( ( listFileFD = hopen( listFileName, O_RDONLY | S_DENYWR ) ) == IO_ERROR )
		error( CANNOT_OPEN_SCRIPTFILE, listFileName );
	hprintfs( MESG_PROCESSING_SCRIPTFILE_s, listFileName );
	resetFastIn( listFileFD );

	/* Process each line in the listFile */
	while( ch != FEOF )
		{
		/* If we've just seen a CR and now we see a LF, skip to next line */
		if( ( ch = fgetByte( listFileFD ) ) == '\n' && seenCR )
			ch = fgetByte( listFileFD );
		seenCR = FALSE;

		/* Skip whitespace */
		while( ( ch == ' ' || ch == '\t' ) && ch != FEOF )
			ch = fgetByte( listFileFD );

		/* Get a line into the mrglBuffer */
		mrglBufCount = 0;
		errType = NO_ERROR;
		while( ch != '\r' && ch != '\n' && ch != CPM_EOF && ch != FEOF )
			{
			/* Check for an illegal char in the data */
			if( ( ch < ' ' || ch > '~' ) && ch != '\r' && ch != '\n' && \
				ch != CPM_EOF && ch != FEOF )
				{
				if( errType == NO_ERROR )
					/* Save position of first illegal char */
					errPos = mrglBufCount;
				errType = ILLEGAL_CHAR_ERROR;
				}
#ifdef __MSDOS__
			if( ch == '\\' )
				ch = '/';		/* Get dir.seperator in correct format */
#endif /* __MSDOS__ */

			/* Make sure the path is of the correct length.  Note that the
			   code is ordered so that a PATH_ERROR takes precedence over
			   an ILLEGAL_CHAR_ERROR */
			if( mrglBufCount > MAX_PATH )
				errType = PATH_ERROR;
			else
				mrglBuffer[ mrglBufCount++ ] = ch;

			if( ( ch = fgetByte( listFileFD ) ) == '#' )
				{
				/* Skip comment section and trailing whitespace */
				while( ch != '\r' && ch != '\n' && ch != CPM_EOF && ch != FEOF )
					ch = fgetByte( listFileFD );
				break;
				}
			}

		/* Remember we've just passed a CR if necessary */
		if( ch == '\r' )
			seenCR = TRUE;

		/* Skip trailing whitespace and add der terminador */
		while( mrglBufCount && \
			   ( theCh = mrglBuffer[ mrglBufCount - 1 ] ) == ' ' || theCh == '\t' )
			mrglBufCount--;
		mrglBuffer[ mrglBufCount ] = '\0';

		/* Process the line unless its a blank or comment line */
		if( mrglBufCount && *mrglBuffer != '#' )
			{
			/* At the first error we must print a newline to get the text
			   away from the HPACK title message unless we've already
			   printed one as part of the listFile message */
			if( ( errType != NO_ERROR ) && firstError && ( flags & STEALTH_MODE ) )
				{
				firstError = FALSE;
				hputchar( '\n' );
				}

			switch( errType )
				{
				case PATH_ERROR:
					mrglBuffer[ screenWidth - strlen( MESG_PATH_s__TOO_LONG_LINE_d ) - 3 ] = '\0';
								/* Truncate to fit screen size (3 = '%s' + 1) */
					hprintf( MESG_PATH_s__TOO_LONG_LINE_d, mrglBuffer, line );
					errCount++;
					break;

				case ILLEGAL_CHAR_ERROR:
					hprintf( "> %s\n  ", mrglBuffer );
					while( errPos-- )
						hputchar( ' ' );
					hprintf( MESG_BAD_CHAR_IN_FILENAME_LINE_d, line );
					errCount++;
					break;

				default:
					addFilespec( ( char * ) mrglBuffer );
				}
			}
		else
			/* It may be a script language command */
			if( strlen( ( char * ) mrglBuffer ) > 2 && mrglBuffer[ 1 ] != ' ' )
				{
				/* At the moment just complain about it */
				hprintf( WARN_UNKNOWN_SCRIPT_COMMAND_s, mrglBuffer );
				errCount++;
				}

		/* Handle special-case of ^Z if listFile came off an MSDOS system */
		if( ch == CPM_EOF )
			ch = FEOF;

		/* Exit if there are too many errors */
		if( errCount >= MAX_ERRORS )
			break;

		line++;
		}
	hclose( listFileFD );

	/* Exit if there were errors */
	if( errCount )
		error( N_ERRORS_DETECTED_IN_SCRIPTFILE, ( errCount >= MAX_ERRORS ) ? \
			   MESG_MAXIMUM_LEVEL_OF : "", errCount );
	}

