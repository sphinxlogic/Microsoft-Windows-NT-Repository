/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*						   Low Position Model Interface						*
*							MODEL4.H  Updated 03/08/90						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1990, 1991  Peter C.Gutmann.  All rights reserved			*
*																			*
****************************************************************************/

/* The set of symbols that may be encoded */

#define NO_LOW_POS	128

/* Translation tables between low positions and symbol indices */

extern int lowPosToIndex[];
extern int indexToLowPos[];

/* Cumulative frequency table */

#ifndef MAX_FREQ
  #define MAX_FREQ	16383				/* Max freq.count: 2^14 - 1 */
#endif /* !MAX_FREQ */

extern int lowPosCumFreq[];				/* Cumulative symbol frequencies */

/* Prototypes for functions in MODEL4.C */

void startLowPosModel( void );
void updateLowPosModel( const int symbol );
