/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*						   High Position Model Interface					*
*							 MODEL3.H  Updated 14/03/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1990, 1991  Peter C.Gutmann.  All rights reserved			*
*																			*
****************************************************************************/

/* The set of symbols that may be encoded */

#define NO_HIGH_POS	128

/* Translation tables between high positions and symbol indices */

extern int highPosToIndex[];
extern int indexToHighPos[];

/* Cumulative frequency table */

#ifndef MAX_FREQ
  #define MAX_FREQ	16383				/* Max freq.count: 2^14 - 1 */
#endif /* !MAX_FREQ */

extern int highPosCumFreq[];			/* Cumulative symbol frequencies */

/* Prototypes for functions in MODEL3.C */

void startHighPosModel( void );
void updateHighPosModel( const int symbol );
