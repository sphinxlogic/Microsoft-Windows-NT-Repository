#ifndef _STDLIB_DEFINED

#define _STDLIB_DEFINED

void exit( int status );

#ifndef NULL
  #define NULL    ( char * ) 0
#endif /* !NULL */

#endif /* _STDLIB_DEFINED */
