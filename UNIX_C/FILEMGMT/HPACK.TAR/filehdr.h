/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*						 Archive Directory Structure Header					*
*							FILEHDR.H  Updated 15/09/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1989 - 1991  Peter C.Gutmann.  All rights reserved		*
*																			*
****************************************************************************/

#ifndef _FILEHDR_DEFINED

#define _FILEHDR_DEFINED

/****************************************************************************
*																			*
*							File Information Bitfield						*
*																			*
****************************************************************************/

/* The bitfield is handled via bit twiddling of a WORD for portability
   reasons.

typedef struct {
			   unsigned origLen	   : 1;	\* fileLen field WORD/LONG bit *\
			   unsigned coprLen	   : 1;	\* dataLen field WORD/LONG bit *\
			   unsigned otherLen   : 2;	\* dirIndex/extraLen field length *\
			   unsigned secured	   : 1; \* Whether the data is secured/not *\
			   unsigned encrypted  : 1;	\* Whether the data is encrypted/not *\
			   unsigned isText	   : 1; \* Whether this is a text file *\
			   unsigned dataFormat : 3; \* Storage format type *\
			   unsigned systemType : 6;	\* The system the archive was created on *\
			   } ARCHIVEINFO; */

#define ARCH_ORIG_LEN	0x8000	/* fileLen field WORD/LONG flag */
#define ARCH_COPR_LEN	0x4000	/* dataLen field WORD/LONG flag */
#define ARCH_OTHER_LEN	0x3000	/* dirIndex/auxLen field length */
#define ARCH_OTHER_HI	0x2000	/* High bit of ARCH_OTHER_LEN */
#define ARCH_OTHER_LO	0x1000	/* Low bit of ARCH_OTHER_LEN */
#define ARCH_SECURED	0x0800	/* Whether the data is secured/not */
#define ARCH_CRYPT		0x0400	/* Whether the data is encrypted/not */
#define ARCH_ISTEXT		0x0200	/* Whether this is a text file */
#define ARCH_STORAGE	0x01C0	/* Storage type */
#define ARCH_SYSTEM		0x003F	/* The system the archive was created on */

/* The value of the OTHER_LEN field */

#define OTHER_ZERO_ZERO	0x0000				/* Fields: ROOT_DIR, 0 */
#define OTHER_BYTE_BYTE	( ARCH_OTHER_LO )	/* Fields: BYTE, BYTE */
#define OTHER_BYTE_WORD	( ARCH_OTHER_HI )	/* Fields: BYTE, WORD */
#define OTHER_WORD_WORD	( ARCH_OTHER_HI | ARCH_OTHER_LO )/* Fields: WORD, WORD */

/* The format of the data within the archive.  FORMAT_UNKNOWN must be the
   last entry for a valid file.  SPECIAL denotes a non-file entry with more
   information being given in the WORD following the file's header */

#define FORMAT_STORED		( 0 << 6 )
#define FORMAT_PACKED		( 1 << 6 )
#define FORMAT_UNKNOWN		( 2 << 6 )
#define FORMAT_SPECIAL		( 7 << 6 )

#define getDataFormat(format)	( ( format ) >> 6 )
#define setDataFormat(format)	( ( format ) << 6 )

#define FORMAT_MASK		0x0007		/* Mask value to extract format type */

/* The OS we are running under. 'OS_UNKNOWN' must always be the last entry. */

enum { OS_MSDOS, OS_UNIX, OS_AMIGA, OS_MAC, OS_ARCHIMEDES, OS_OS2, OS_IIGS, 
	   OS_ATARI, OS_VMS, OS_PRIMOS, OS_UNKNOWN };

/****************************************************************************
*																			*
*							  Internal File Headers							*
*																			*
****************************************************************************/

/* Note that due to the variable length of the headers when written to disk
   the lengths of some fields in this structure may not correspond to the
   actual data on disk */

typedef struct {
			   LONG fileTime;		/* Date + time of the file */
			   LONG fileLen;		/* Original data length */
			   LONG dataLen;		/* Archived data length */
			   WORD auxDataLen;		/* Auxiliary data field length */
			   WORD dirIndex;		/* Where the file is in the dir.tree */
			   WORD archiveInfo;	/* Various archive-specific info */
			   } FILEHDR;

/* The internal directory header */

typedef struct {
			   LONG dirTime;			/* Date + time of the directory */
			   WORD dataLen;			/* Directory data length */
			   WORD parentIndex;		/* The parent of this directory */
			   } DIRHDR;

/****************************************************************************
*																			*
*								Special File Types							*
*																			*
****************************************************************************/

/* The types of files with main file type SPECIAL in the archInfo.dataFormat
   field.  These have the storage type (corresponding to the true value of
   archInfo.dataFormat) stored in the low 3 bits, and a type ID in the high
   12 bits, giving 4096 types of special files */

#define TYPE_MASK			0x0FFF8		/* Mask value to extract file type */

#define TYPE_NORMAL			0
#define TYPE_COMMENT_TEXT	( 1 << 3 )
#define TYPE_COMMENT_ANSI	( 2 << 3 )
#define TYPE_COMMENT_GIF	( 3 << 3 )

#endif /* _FILEHDR_DEFINED */
