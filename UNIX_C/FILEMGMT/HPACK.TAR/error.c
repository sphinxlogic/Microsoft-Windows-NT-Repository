/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*						 	  Error Handling Routines						*
*							 ERROR.C  Updated 01/08/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1989 - 1991  Peter C.Gutmann.  All rights reserved		*
*																			*
****************************************************************************/

#ifndef __MSDOS__
  #include <stdarg.h>
  #include <stdio.h>
#endif /* !__MSDOS__ */
#include <stdlib.h>
#include "defs.h"
#include "arcdir.h"
#include "error.h"
#include "errorlvl.h"
#include "flags.h"
#include "frontend.h"
#include "hpacklib.h"
#include "hpaktext.h"
#include "system.h"
#include "crypt/crypt.h"
#include "io/hpackio.h"
#include "io/fastio.h"
#include "store/store.h"

/* Note that some of the following variables must be initialized to 'empty'
   values initially since we may call error() before they are set to a
   sensible value at runtime.  These variables are: errorFD, dirFileFD,
   workDrive, and oldArcEnd */

char errorFileName[ MAX_PATH ];	/* The name of the current output file (used
								   to delete it in case of error) */
FD errorFD = 0;	/* The FD of the current output file.  This MUST be closed before
				   the corresponding errorFileName is deleted.  Not closing it
				   results in loss of disk space since it will still be alloc-
				   ated, but the directory entry for it will have been wiped */

char dirFileName[ MAX_PATH ];	/* The name of the directory special info file
								   (if used) */
FD dirFileFD = 0;				/* The FD of the directory special info file */

char secFileName[ MAX_PATH ];	/* The name of the security info file (if used */
FD secFileFD = 0;				/* The FD of the security infor file */
int secInfoLen;					/* The length of the security info */

/* The drive and directory we started from, the original drive and directory
   on the drive we are on now, and the directory where we are now */

char startDrive, workDrive = ERROR, currentDrive;
char startDir[ MAX_PATH ], workDir[ MAX_PATH ], currentDir[ MAX_PATH ];

/* The original state of the archive */

long oldArcEnd = 0L;	/* The end of the archive before files were [A]dded */
void *oldHdrlistEnd;	/* End of list of file headers before files were [A]dded */
int oldDirEnd;
unsigned int oldDirNameEnd;

#ifdef __MSDOS__
  extern int fileErrno;	/* I/O error code */
  char archiveDrive;	/* The drive the archive is on */
#endif /* __MSDOS__ */

/* The archiveFD.  This must be made global to support multipart archive since
   the low-level read and write routines change it whenever they move to another
   section of a multipart archive */

FD archiveFD;

/****************************************************************************
*																			*
*							Exit with an Error Message						*
*																			*
****************************************************************************/

static BOOLEAN recurseCheck = FALSE;	/* Used to check for recursive calls to error() */

/* Exit with an error message.  Note that it may be necessary to call the
   functions endPack(), endArcDir(), endFastIO(), and endMem()/freeFileSpecs().
   However if an error occurs during these functions we will end up doing
   things like dereferencing null pointers unless a lot of extra code is added
   to check for this sort of thing, thus we rely on the .crt0 code to handle
   this. */

void error( ERROR_INFO *errInfo, ... )
	{
#ifndef __MSDOS__
  #ifdef NO_STDARG
	char buffer[ 20 ];				/* Buffer for string conversions */
	char *format = errInfo->msg;	/* Pointer to format string */
  #endif /* NO_STDARG */
	va_list argPtr;					/* Argument list pointer */
#endif

	hprintf( MESG_ERROR );			/* Print initial part of error message */
#if defined( NO_STDARG )
	/* vprintf() for systems which don't have it.  This only handles the
	   very few cases which are present in error messages ('%s', '%c'),
	   with two example cases ('%%' and '%d') being included to show how
	   these variations would be handled */
	va_start( argPtr, format );
	while( *format )
		{
		if( *format == '%' )
			switch( *++format )
				{
				/* String */
				case 's':
					fputs( va_arg( argPtr, char * ), stdout );
					format++;
					break;

				/* Single character */
				case 'c':
					putchar( va_arg( argPtr, char ) );
					format++;
					break;

  #if 0	/* Not needed - included only as an example */
				/* Percent sign */
				case '%':
					putchar( '%' );
					format++;
					break;

				/* Decimal integer */
				case 'd':
					fputs( itoa( va_arg( argPtr, int ), buffer, 10 ), stdout );
					format++;
					break;
  #endif /* 0 */
				/* Unknown option */
				default:
					putchar( *format );
					format++;
				}
		else
			{
			putchar( *format );
			format++;
			}
		}
	va_end( argPtr );
#elif !defined( __MSDOS__ )
	va_start( argPtr, errInfo );	/* Initialize va_ functions	*/
	vprintf( errInfo->msg, argPtr );/* Print string */
	va_end( argPtr );				/* Close va_ functions */
#else
	hvprintf();	/* Print with args off current stack frame + other nastiness */
#endif /* NO_STDARG */
	hputchar( '\n' );

	/* Shut down the encryption system if necessary */
	if( flags & CRYPT )
		endCrypt();

#if !defined( __UNIX__ ) && !defined( __MAC__ )
	/* Return to the original directory on the current drive if necessary */
	if( workDrive != ERROR )
		{
		setDrive( workDrive );
		if( *workDir )
			/* If we are on a different drive but haven't hchdir()'d from the
			   current directory on that drive then workDir will not be set */
			hchdir( workDir );
		}

	/* Return to original drive and directory */
	setDrive( startDrive );
	hchdir( startDir );
#endif /* !( __UNIX__ || __MAC__ ) */

	/* Do a nasty check for recursive calls to error() via writeArcDir() */
	if( recurseCheck )
		{
		/* Moth detected in relay bank #6 */
		hputs( MESG_ERROR_DURING_ERROR_RECOVERY );
		exit( EXIT_INT_ERR );
		}
	recurseCheck = TRUE;

	/* If we had an error during [A]dd, restore the old archive end exit */
	if( oldArcEnd )
		{
		if( archiveChanged )
			{
			/* Only attempt recovery if we've changed the archive */
			hlseek( archiveFD, oldArcEnd, SEEK_SET );
			setArcdirState( oldHdrlistEnd, oldDirEnd );
			resetFastOut();			/* Clear output buffer */
			writeArcDir();

			/* Append the old security info if necessary */
			if( secFileFD )
				{
				hlseek( secFileFD, 0, SEEK_SET );
				hlseek( errorFD, -4L, SEEK_CUR );
				moveData( secFileFD, errorFD, secInfoLen );

				/* Zap the security info file */
				hclose( secFileFD );
				hunlink( secFileName );
				}

			htruncate( errorFD );
			hclose( errorFD );
			}
		exit( ERROR );
		}

	/* Close and delete incorrect files if need be */
	if( errorFD )
		{
		hclose( errorFD );
		hunlink( errorFileName );
		}
	if( dirFileFD )
		{
		hclose( dirFileFD );
		hunlink( dirFileName );
		}
	if( secFileFD )
		{
		hclose( secFileFD );
		hunlink( secFileName );
		}

	exit( errInfo->errorLevel );

#pragma warn -par					/* Suppress 'Arg not used' warning */
	}
#pragma warn +par

/* Print an OS-specific error message for a file I/O error.  This routine
   is called if an error occurs during a file R/W operation, and thus should
   only be expected to handle problems that will not already have been
   caught in the hopen() call */

void fileError( void )
	{
#ifdef __MSDOS__
	ERROR_INFO errInfo;
	errInfo.errorLevel = EXIT_FILE_ERR;

	switch( fileErrno )
		{
		case 0x20:
			errInfo.msg = OSMESG_FILE_SHARING_VIOLATION;
			break;

		case 0x21:
			errInfo.msg = OSMESG_FILE_LOCKING_VIOLATION;
			break;

		default:
			error( FILE_ERROR, fileErrno );
		}
	error( &errInfo );
#else
	error( FILE_ERROR );
#endif
	}
