/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*						System-Specific Information Header					*
*							SYSTEM.H  Updated 10/01/92						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1989 - 1992  Peter C.Gutmann.  All rights reserved		*
*																			*
****************************************************************************/

#ifndef _SYSTEM_DEFINED

#define _SYSTEM_DEFINED

/****************************************************************************
*																			*
*							Definitions for MSDOS							*
*																			*
****************************************************************************/

#ifdef __MSDOS__

#define ARCHIVE_OS		OS_MSDOS

/* Maximum DOS path length (63 bytes + null terminator) and filename length
   (8.3 + null delimiter) */

#define MAX_PATH		64
#define MAX_FILENAME	13

/* The file attribute type and various useful attributes */

typedef BYTE			ATTR;	/* Attribute data type */

#define HIDDEN			0x02	/* Hidden file */
#define SYSTEM			0x04	/* System file */
#define DIRECT			0x10	/* Directory bit */

/* Attributes as used by HPACK.  DOS distinguishes between normal files
   (DEFAULT and RDONLY) and special files (HIDDEN and SYSTEM) so there
   are two sets of attributes for matching, one for normal files and one
   for special files */

#define FILES			0		/* No attributes to match on (will still
								   match DEFAULT and RDONLY under DOS) */
#define ALLFILES		( HIDDEN | SYSTEM )
								/* All useful file attribute types. Again
								   will also match DEFAULT and RDONLY */
#define FILES_DIRS		DIRECT	/* All normal files + directories */
#define ALLFILES_DIRS	( FILES | DIRECT )
								/* All useful file attribute types + dirs */

#define CREAT_ATTR		0		/* Bits to set for hcreat() */
#define MKDIR_ATTR		0		/* Bits to set for hmkdir() */

/* The types of files findFirst() can match (when it's not matching a
   literal file or directory name) */

#define MATCH_ALL		"*.*"	/* All files and directories */
#define SLASH_MATCH_ALL	"/*.*"	/* As above with directory delimiter */
#define MATCH_ARCHIVE	"*.HPK"	/* All archive files */

/* The data block used by findFirst()/findNext().  Remember to change
   findFirst() in HPACKIO.ASM if this struct is changed */

typedef struct {
			   BYTE dosReserved[ 21 ];		/* Reserved by DOS */
			   ATTR fAttr;					/* File attributes */
			   LONG fTime;					/* File modification datestamp */
			   LONG fSize;					/* File size */
			   char fName[ MAX_FILENAME ];	/* File name */
			   } FILEINFO;

/* Determine whether a found file is a directory or not */

#define isDirectory(fileInfo)	( fileInfo.fAttr & DIRECT )

/* The type of case conversion to perform on file and directory names */

#define caseConvert		toupper				/* Force uppercase */

/* Dummy routines for nonportable functions */

#define setDirecTime(x,y)	/* Virtually impossible to do under DOS */

/* Dummy routine not needed in MSDOS version */

#define findEnd(x)

/* Prototypes for get/setDrive() routines and isDevice() call */

void setDrive( const int driveNo );
int getDrive( void );
BOOLEAN isDevice( const FD theFD );

#endif /* __MSDOS__ */

/****************************************************************************
*																			*
*							Definitions for UNIX							*
*																			*
****************************************************************************/

#ifdef __UNIX__

#define ARCHIVE_OS		OS_UNIX

#include <sys/stat.h>
#if defined( POSIX ) || defined( ULTRIX ) || defined( IRIX )
  #include <unistd.h>
  #include <dirent.h>
#endif /* POSIX || ULTRIX || IRIX */

/* Maximum path length (x bytes + null terminator) and filename length
   (y bytes + null terminator) */

#if defined( BSD ) || defined( ULTRIX ) || defined( IRIX )
  #define MAX_PATH			( 256 + 1 )
  #define MAX_FILENAME		( 128 + 1 )
#elif defined( POSIX )
  #define MAX_PATH          ( _POSIX_PATH_MAX + 1 )
  #define MAX_FILENAME		( NAME_MAX + 1 )
#else /* SYSV */
  #define MAX_PATH			( 64 + 1 )
  #define MAX_FILENAME		( 14 + 1 )
#endif /* Various mutation-dependant defines */

/* The size of the directory buffer used by findFirst/findNext() */

#define DIRINFO_SIZE		sizeof( struct direct )
#ifndef POSIX
  #define DIRBUF_ENTRIES	20		/* No.entries in one buffer */
#else
  #define DIRBUF_ENTRIES	_DIRBUF	/* No.entries in one buffer */
#endif /* !POSIX */

/* The file attribute type and various useful attributes */

typedef WORD			ATTR;		/* Attribute data type */

#define CREAT_ATTR		0644		/* Bits to set for hcreat() */
#define MKDIR_ATTR		0744		/* Bits to set for hmkdir() */

/* The following pseudo-attributes must be sorted out in findFirst/Next().
   Since Unix doesn't distinguish between normal and special files these
   are treated identically */

#define FILES			1			/* Match normal files only */
#define ALLFILES		1			/* Match special files as well */
#define FILES_DIRS 		2			/* Match normal files and directories */
#define ALLFILES_DIRS	2			/* Match all files and directories */

/* The types of files findFirst() can match (when it's not matching a
   literal file or directory name) */

#define MATCH_ALL		"."			/* All files and directories */
#define SLASH_MATCH_ALL	"/."		/* As above with directory delimiter */
#define MATCH_ARCHIVE	"."			/* All archive files */

/* The data block used by findFirst()/findNext()/findEnd() */

typedef struct {
			   LONG fTime;			/* File modification datestamp */
			   LONG fSize;			/* File size */
			   char fName[ MAX_FILENAME ];	/* File name */
			   ATTR matchAttr;		/* File attributes to match on */
			   DIR *dirBuf;			/* Directory buffer. */
			   char dName[ MAX_PATH ];	/* Pathname for this dir. */
			   struct stat statInfo;/* Info returned by stat() */
			   } FILEINFO;

/* Determine whether a found file is a directory or not */

#define isDirectory(fileInfo)	( ( fileInfo.statInfo.st_mode & S_IFMT ) == S_IFDIR )

/* The type of case conversion to perform on file and directory names */

#define caseConvert(x)	x			/* No conversion */

/* Prototypes/defines for standard UNIX routines */

char *getcwd( const char *dirName, const int bufLen );

#define getCwd(pathBuf)				getcwd( pathBuf, MAX_PATH )
#define setDirecTime(dirName,time)	setFileTime( dirName, time )

/* Routines which some UNIX's don't have */

#if !defined( IRIX ) && !defined( ULTRIX )
  void rename( const char *srcName, const char *destName );
#endif /* !( IRIX || ULTRIX ) */
#if !defined( POSIX ) && !defined( IRIX ) && !defined( ULTRIX )
  void mkdir( const char *dirName, int mode );
#endif /* !( POSIX || IRIX || ULTRIX ) */

#endif /* __UNIX__ */

/****************************************************************************
*																			*
*							Definitions for Macintosh						*
*																			*
****************************************************************************/

#ifdef __MAC__

#define ARCHIVE_OS		OS_MAC

/* Maximum path length and filename length */

#define MAX_PATH		255
#define MAX_FILENAME	31

/* The file attribute type and various useful attributes */

typedef WORD			ATTR;		/* Attribute data type */

#define CREAT_ATTR		0			/* creat()'s mode parameter ignored by
									   UNIXIO.C */
#define MKDIR_ATTR		0			/* mkdir()'s mode parameter ignored */

/* The following pseudo-attributes must be sorted out in findFirst/Next().
   On the Mac invisible files are treated seperately */

#define FILES			1			/* Match normal files only */
#define ALLFILES		2			/* Match special files as well */
#define FILES_DIRS 		3			/* Match normal files and directories */
#define ALLFILES_DIRS	4			/* Match all files and directories */

/* The data block used by findFirst()/findNext()/findEnd() */

typedef struct {
			   LONG fTime;			/* File modification datestamp */
			   LONG fSize;			/* File size */
			   char fName[ MAX_FILENAME ];	/* File name */
			   ATTR fAttr;			/* File attributes */
			   /* Plus other Mac-specific information */
			   } FILEINFO;

/* Determine whether a found file is a directory or not (set to never match
   since the Mac handles directories differently) */

#define isDirectory(x)				FALSE

/* The type of case conversion to perform on file and directory names */

#define caseConvert(x)	x			/* No conversion */

/* Dummy routines for nonportable functions */

#define setFileTime(x,y)	hputs( "Need to implement setFileTime()" )
#define setDirecTime(x,y)	hputs( "Need to implement setDirTime()" )
#define getCwd(x)			hputs( "Need to implement getCwd()" )
#define getCountry()		hputs( "Need to implement getCountry()" )
#define getScreenSize()		hputs( "Need to implement getScreenSize()" )
#define findFirst(x,y,z)	hputs( "Need to implement findFirst()" )
#define findNext(x)			hputs( "Need to implement findNext()" )
#define findEnd(x)			hputs( "Need to implement findEnd()" )
#define isSameFile(x,y)		hputs( "Need to implement isSameFile()" )
#define htruncate(x)		hputs( "Need to implement htruncate() " )

#endif /* __MAC__ */

/****************************************************************************
*																			*
*							Definitions for OS/2							*
*																			*
****************************************************************************/

#ifdef __OS2__

#define ARCHIVE_OS		OS_OS2

/* Maximum OS/2 path length and filename length (For HPFS Max) */

#define MAX_PATH		254
#define MAX_FILENAME	254

/* File attributes */

typedef BYTE		ATTR;		/* Attribute data type */

#define RDONLY		0x01		/* Read only attribute */
#define HIDDEN		0x02		/* Hidden file */
#define SYSTEM		0x04		/* System file */
#define LABEL		0x08		/* Volume label */
#define DIRECT		0x10		/* Directory */
#define ARCH		0x20		/* Archive bit set */

/* Attributes as used by HPACK.  OS/2 distinguishes between normal files
   (DEFAULT and READONLY) and special files (RDONLY and SYSTEM) so there
   are two sets of attributes for matching, one for normal files and one
   for special files */

#define FILES			0		/* No attributes to match on (will still
								   match DEFAULT and RDONLY under OS/2) */
#define ALLFILES		( HIDDEN | SYSTEM )
								/* All useful file attribute types. Again
								   will also match DEFAULT and RDONLY */
#define FILES_DIRS		DIRECT	/* All normal files + directories */
#define ALLFILES_DIRS	( FILES | DIRECT )
								/* All useful file attribute types + dirs */

#define CREAT_ATTR		0		/* Bits to set for hcreat() */
#define MKDIR_ATTR		0		/* Attribute ignored by hmkdir() */

/* The data block used by findFirst()/findNext().  */

typedef struct {
			   char fName[ MAX_FILENAME ];	/* File name */
			   LONG fSize;					/* File size */
			   ATTR fAttr;					/* File attributes */
			   LONG fTime; 				    /* File modification datestamp */
			   LONG cTime;					/* File creation datestamp */
			   LONG aTime;					/* File access datestamp */
			   } FILEINFO;

/* Determine whether a found file is a directory or not */

#define isDirectory(fileInfo)	( fileInfo.fAttr == DIRECT )

/* Dummy routines for nonportable functions */

#define setDirecTime(dirName,time)	setFileTime( dirName, time )
#define isSameFile(x,y)				hputs( "Need to implement isSameFile()" )

/* Dummy routine not needed in OS2 version */

#define findEnd(x)

/* Prototypes for get/setDrive() routines */

void setDrive( const int driveNo );
int getDrive( void );

#endif /* __OS2__ */

/****************************************************************************
*																			*
*							Definitions for Archimedes						*
*																			*
****************************************************************************/

#ifdef __ARC__

#define ARCHIVE_OS		OS_ARC

/* Dummy routines nonportable functions */

#define setFileTime(x,y)	hputs( "Need to implement setFileTime()" )
#define setDirecTime(x,y)	hputs( "Need to implement setDirTime()" )
#define getCwd(x)			hputs( "Need to implement getCwd()" )
#define getCountry()		hputs( "Need to implement getCountry()" )
#define getScreenSize()		hputs( "Need to implement getScreenSize()" )
#define findFirst(x,y,z)	hputs( "Need to implement findFirst()" )
#define findNext(x)			hputs( "Need to implement findNext()" )
#define findEnd(x)			hputs( "Need to implement findEnd()" )
#define isSameFile(x,y)		hputs( "Need to implement isSameFile()" )
#define htruncate(x)		hputs( "Need to implement htruncate() " )

#endif /* __ARC__ */

/****************************************************************************
*																			*
*							Definitions for Amiga							*
*																			*
****************************************************************************/

#ifdef __AMIGA__

#define ARCHIVE_OS		OS_AMIGA

/* Maximum Amiga path length (?? bytes + null terminator) and filename length
   (105 chars + null delimiter) */

#define MAX_PATH		??
#define MAX_FILENAME	106

/* The file attribute type */

typedef BYTE			ATTR;	/* Attribute data type */

/* The following pseudo-attributes must be sorted out in findFirst/Next().
   Since the Amiga doesn't distinguish between normal and special files these
   are treated identically */

#define FILES			1			/* Match normal files only */
#define ALLFILES		1			/* Match special files as well */
#define FILES_DIRS 		2			/* Match normal files and directories */
#define ALLFILES_DIRS	2			/* Match all files and directories */

/* The type of case conversion to perform on file and directory names */

#define caseConvert(x)	x			/* No conversion */

/* Dummy routines for nonportable functions */

#define setFileTime(x,y)	hputs( "Need to implement setFileTime()" )
#define setDirecTime(x,y)	hputs( "Need to implement setDirTime()" )
#define getCwd(x)			hputs( "Need to implement getCwd()" )
#define getCountry()		hputs( "Need to implement getCountry()" )
#define getScreenSize()		hputs( "Need to implement getScreenSize()" )
#define findFirst(x,y,z)	hputs( "Need to implement findFirst()" )
#define findNext(x)			hputs( "Need to implement findNext()" )
#define findEnd(x)			hputs( "Need to implement findEnd()" )
#define isSameFile(x,y)		hputs( "Need to implement isSameFile()" )
#define htruncate(x)		hputs( "Need to implement htruncate() " )

#endif /* __AMIGA__ */

/****************************************************************************
*																			*
*							Definitions for Atari							*
*																			*
****************************************************************************/

#ifdef __ATARI__

#define ARCHIVE_OS		OS_ATARI

/* Dummy routines nonportable functions */

#define setFileTime(x,y)	hputs( "Need to implement setFileTime()" )
#define setDirecTime(x,y)	hputs( "Need to implement setDirTime()" )
#define getCwd(x)			hputs( "Need to implement getCwd()" )
#define getCountry()		hputs( "Need to implement getCountry()" )
#define getScreenSize()		hputs( "Need to implement getScreenSize()" )
#define findFirst(x,y,z)	hputs( "Need to implement findFirst()" )
#define findNext(x)			hputs( "Need to implement findNext()" )
#define findEnd(x)			hputs( "Need to implement findEnd()" )
#define isSameFile(x,y)		hputs( "Need to implement isSameFile()" )
#define htruncate(x)		hputs( "Need to implement htruncate() " )

#endif /* __ATARI__ */

/****************************************************************************
*																			*
*							Definitions for Apple IIgs						*
*																			*
****************************************************************************/

#ifdef __IIGS__

#define ARCHIVE_OS		OS_IIGS

/* Maximum path length and filename length */

#define MAX_PATH		255
#define MAX_FILENAME	15

/* File attributes */

typedef WORD			ATTR;		/* Attribute data type */

#define RDONLY			0x01		/* Read only attribute */
#define HIDDEN			0x02		/* Hidden file */
#define DIRECT			0x000F		/* Directories */

#define CREAT_ATTR	0 				/* creat()'s mode parameter ignored
									   by IIGSIO.C */
#define MKDIR_ATTR	0				/* mkdirs()'s mode parameter ignored */

/* The following pseudo-attributes must be sorted out in findFirst/Next().
   On the IIgs invisible files are treated seperately */

#define FILES			1			/* Match normal files only */
#define ALLFILES		2			/* Match special files as well */
#define FILES_DIRS 		3			/* Match normal files and directories */
#define ALLFILES_DIRS	4			/* Match all files and directories */

/* The data block used by findFirst()/findNext()/findEnd() */

typedef struct {
			   LONG fTime;			/* File modification datestamp */
			   LONG fSize;			/* File size */
			   char fName[ MAX_FILENAME ];	/* File name */
			   ATTR fAttr;			/* File attributes */

			   /* Apple IIgs-specific information */
			   WORD fType;			/* File type */
			   LONG fAuxType;		/* Auxiliary file type */
/*			   WORD fStorage;		// Storage type */
			   LONG fCrtDate;		/* First part of creation time and date */
			   LONG fCrtTime;		/* Second part of creation time and date */
/*			   LONG fModDate;		// First part of modification time and date */
/*			   LONG fModTime;		// Second part of modification time and date */
/*			   LONG fOptionList;	// Option list pointer for FST */
/*			   LONG fBlocks;		// Number of blocks used by file */
			   LONG fResSize;		/* Size of file's resource fork */
/*			   LONG fResBlocks;		// Number of blocks used by resource fork */
			   } FILEINFO;

/* Determine whether a found file is a directory or not */

#define isDirectory(fileInfo)		( fileInfo.fType == DIRECT )

/* Dummy routines for nonportable functions */

#define setFileTime(x,y)	hputs( "Need to implement setFileTime()" )
#define setDirecTime(x,y)	hputs( "Need to implement setDirTime()" )
#define getCwd(x)			hputs( "Need to implement getCwd()" )
#define getCountry()		hputs( "Need to implement getCountry()" )
#define getScreenSize()		hputs( "Need to implement getScreenSize()" )
#define findFirst(x,y,z)	hputs( "Need to implement findFirst()" )
#define findNext(x)			hputs( "Need to implement findNext()" )
#define findEnd(x)			hputs( "Need to implement findEnd()" )
#define realPath(x,y)		hputs( "Need to implement realPath()" )

#endif /* __IIGS__ */

/****************************************************************************
*																			*
* 					Prototypes for Nonportable Functions 					*
*																			*
****************************************************************************/

/* All the following are conditional since they may be defined as dummy
   functions */

#ifndef setFileTime
  void setFileTime( const char *fileName, const LONG fileTime );
#endif /* setFileTime */
#ifndef setDirecTime
  void setDirecTime( const char *dirName, const LONG dirTime );
#endif /* setDirecTime */
#ifndef getCwd
  void getCwd( const char *dirPath );
#endif /* getCwd */
#ifndef getCountry
  int getCountry( void );
#endif /* getCountry */
#ifndef getScreenSize
  void getScreenSize( void );
#endif /* getScreenSize */
#ifndef findFirst
  BOOLEAN findFirst( const char *filePath, const ATTR fileAttr, FILEINFO *fileInfo );
  BOOLEAN findNext( FILEINFO *fileInfo );
  void findEnd( const FILEINFO *fileInfo );
#endif /* findFirst */
#ifndef isSameFile
  BOOLEAN isSameFile( const char *pathName1, const char *pathName2 );
#endif /* isSameFile */

/* Default OS */

#ifndef ARCHIVE_OS
  #define ARCHIVE_OS	OS_UNKNOWN
#endif /* !ARCHIVE_OS */

#endif /* _SYSTEM_DEFINED */
