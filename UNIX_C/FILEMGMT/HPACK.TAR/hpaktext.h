/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*						  HPACK Messages Symbolic Defines					*
*							HPAKTEXT.H  Updated 31/12/91					*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*			Copyright 1991  Peter C.Gutmann.  All rights reserved			*
*																			*
****************************************************************************/

/* The following two procedures display the title message and help screen */

void showTitle( void );
void showHelp( void );

/* Below are the interface declarations for the messages in HPAKTEXT.C.
   Note that the message tags in these two files are automatically generated
   by a preprocessor from a text definition file and should not be relied
   upon to be consistent from one version to another - they serve merely as
   tags for the messages */

/****************************************************************************
*																			*
*									Warnings								*
*																			*
****************************************************************************/

#define RESPONSE_YES	'Y'
#define RESPONSE_NO		'N'
#define RESPONSE_ALL	'A'

extern char warn00[], warn01[], warn02[], warn03[], warn04[], warn05[], \
			warn06[], warn07[], warn08[], warn09[], warn10[], warn11[];

#define WARN_TRUNCATED_u_BYTES_EOF_PADDING		warn00
#define WARN_s_CONTINUE_YN						warn01
#define WARN_FILE_PROBABLY_CORRUPTED			warn02
#define WARN_CANT_FIND_PUBLIC_KEY				warn03
#define WARN_SEC_INFO_CORRUPTED					warn04
#define WARN_SECRET_KEY_COMPROMISED_FOR_s		warn05
#define WARN_ARCHIVE_SECTION_TOO_SHORT			warn06
#define WARN_UNKNOWN_SCRIPT_COMMAND_s			warn07

/****************************************************************************
*																			*
*								General Messages							*
*																			*
****************************************************************************/

extern char mesg00[], mesg01[], mesg02[], mesg03[], mesg04[], mesg05[], \
			mesg06[], mesg07[], mesg08[], mesg09[], mesg10[], mesg11[], \
			mesg12[], mesg13[], mesg14[], mesg15[], mesg16[], mesg17[], \
			mesg18[], mesg19[], mesg20[], mesg21[], mesg22[], mesg23[], \
			mesg24[], mesg25[], mesg26[], mesg27[], mesg28[], mesg29[], \
			mesg30[], mesg31[], mesg32[], mesg33[], mesg34[], mesg35[], \
			mesg36[], mesg37[], mesg38[], mesg39[], mesg40[], mesg41[], \
			mesg42[], mesg43[], mesg44[], mesg45[], mesg46[], mesg47[], \
			mesg48[], mesg49[], mesg50[], mesg51[], mesg52[], mesg53[], \
			mesg54[], mesg55[], mesg56[], mesg57[], mesg58[], mesg59[], \
			mesg60[], mesg61[], mesg62[], mesg63[], mesg64[], mesg65[];

#define MESG_VERIFY_SECURITY_INFO				mesg00
#define MESG_VERIFYING_ARCHIVE_AUTHENTICITY		mesg01
#define MESG_SECURITY_INFO_WILL_BE_DESTROYED	mesg02
#define MESG_ARCHIVE_DIRECTORY_CORRUPTED		mesg03
#define MESG_s_YN								mesg04
#define MESG_s_s_YNA							mesg05
#define MESG_SKIPPING_s							mesg06
#define MESG_DATA_IS_ENCRYPTED					mesg07
#define MESG_EXTRACTING							mesg08
#define MESG_s_AS								mesg09
#define MESG_UNKNOWN_ARCHIVING_METHOD			mesg10
#define MESG__SKIPPING_s						mesg11
#define MESG_WONT_OVERWRITE_EXISTING_s			mesg12
#define MESG_s_ALREADY_EXISTS_ENTER_NEW_NAME	mesg13
#define MESG_PATH_s__TOO_LONG					mesg14
#define MESG_ALREADY_EXISTS__OVERWRITE			mesg15
#define MESG_EXTRACT							mesg16
#define MESG_DISPLAY							mesg17
#define MESG_TEST								mesg18
#define MESG_FILE_TESTED_OK						mesg19
#define MESG_HIT_A_KEY							mesg20
#define MESG_ADDING								mesg21
#define MESG_ERROR								mesg22
#define MESG_ERROR_DURING_ERROR_RECOVERY		mesg23
#define MESG_CREATING_DIRECTORY_s				mesg24
#define MESG_PROCESSING_SCRIPTFILE_s			mesg25
#define MESG_PATH_s__TOO_LONG_LINE_d			mesg26
#define MESG_BAD_CHAR_IN_FILENAME_LINE_d		mesg27
#define MESG_MAXIMUM_LEVEL_OF					mesg28
#define MESG_ADDING_DIRECTORY_s					mesg29
#define MESG_CHECKING_DIRECTORY_s				mesg30
#define MESG_LEAVING_DIRECTORY_s				mesg31
#define MESG_FILE_s_ALREADY_IN_ARCH__SKIPPING	mesg32
#define MESG_ADD								mesg33
#define MESG_DELETE								mesg34
#define MESG_DELETING_s_FROM_ARCHIVE			mesg35
#define MESG_FRESHEN							mesg36
#define MESG_REPLACE							mesg37
#define MESG_ARCHIVE_IS_s						mesg38
#define MESG_DONE								mesg39
#define MESG_DIRECTORY							mesg40
#define MESG_DIRECTORY_TIME						mesg41
#define MESG_SUBDIRECTORY_TIME					mesg42
#define MESG_ARCHIVE_ROOT_DIRECTORY				mesg43
#define MESG_NO_FILES							mesg44
#define MESG_SINGULAR_FILES						mesg45
#define MESG_PLURAL_FILES						mesg46
#define MESG_KEY_INCORRECT_LENGTH				mesg47
#define MESG_ENTER_PASSWORD						mesg48
#define MESG_AGAIN								mesg49
#define MESG_PUBLIC_KEY_CANNOT_BE_USED			mesg50
#define MESG_BAD_SIGNATURE						mesg51
#define MESG_GOOD_SIGNATURE						mesg52
#define MESG_SIGNATURE_FROM_s_DATE_dddddd		mesg53
#define MESG_PART_d_OF_MULTIPART_ARCHIVE		mesg54
#define MESG_PLEASE_INSERT_THE					mesg55
#define MESG_NEXT_DISK							mesg56
#define MESG_DISK_CONTAINING					mesg57
#define MESG_PART_d								mesg58
#define MESG_THE_LAST_PART						mesg59
#define MESG_OF_THIS_ARCHIVE					mesg60
#define MESG_AND_PRESS_A_KEY					mesg61
#define MESG_CONTINUING							mesg62

/****************************************************************************
*																			*
*					Special Text Strings used in Viewfile.C					*
*																			*
****************************************************************************/

extern char vmsg00[], vmsg01[], vmsg02[], vmsg03[], vmsg04[], vmsg05[];

#define VIEWFILE_TITLE							vmsg00
#define VIEWFILE_MAIN_DISPLAY					vmsg01
#define VIEWFILE_TRAILER						vmsg02
#define VIEWFILE_GRAND_TOTAL					vmsg03

/****************************************************************************
*																			*
*								OS-Specific Messages						*
*																			*
****************************************************************************/

#ifdef __MSDOS__

extern char osmsg00[], osmsg01[], osmsg02[], osmsg03[], osmsg04[], osmsg05[];

#define OSMESG_FILE_SHARING_VIOLATION			osmsg00
#define OSMESG_FILE_LOCKING_VIOLATION			osmsg01
#define OSMESG_FILE_IS_DEVICEDRVR				osmsg02

#endif /* __MSDOS__ */
