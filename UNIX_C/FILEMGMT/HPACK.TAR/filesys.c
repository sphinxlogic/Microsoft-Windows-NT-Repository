/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*						Filesystem-Specific Support Routines				*
*							FILESYS.C  Updated 21/12/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1990 - 1991  Peter C.Gutmann.  All rights reserved		*
*																			*
****************************************************************************/

#include <ctype.h>
#include <string.h>
#include "defs.h"
#include "arcdir.h"
#include "error.h"
#include "flags.h"
#include "frontend.h"
#include "hpacklib.h"
#include "hpaktext.h"
#include "system.h"
#include "tags.h"
#include "io/fastio.h"
#include "io/hpackio.h"

/* Take a full pathname, convert it to an OS-compatible format, and extract
   out the path component of the name */

int extractPath( char *fullPath, char *pathName )
	{
#if !defined( __UNIX__ ) && !defined( __MAC__ )
	BOOLEAN hasDriveSpec = FALSE;
#endif /* !( __UNIX__ || __MAC__ ) */
	int count, lastSlash = -1;

#if !defined( __UNIX__ ) && !defined( __MAC__ )
	/* Check whether there is a drive specifier prepended to the path */
	if( fullPath[ 1 ] == ':' )
		{
		lastSlash = 1;
		hasDriveSpec = TRUE;
		}
#endif /* !( __UNIX__ || __MAC__ ) */
#pragma run "/user/games/moria"

	/* Separate the path and filename components, converting directory
	   seperators into an OS-compatible format at the same time */
	for( count = 0; fullPath[ count ]; count++ )
		{
		fullPath[ count ] = caseConvert( fullPath[ count ] );
		if( fullPath[ count ] == '/' )
			lastSlash = count;
		}

#if !defined( __UNIX__ ) && !defined( __MAC__ )
	/* If there is only a drive spec we must handle it differently than a
	   normal path:  We can't stomp the char at lastSlash as we would for
	   a normal path */
	if( hasDriveSpec && ( lastSlash == 1 || lastSlash == 2 ) )
		{
		strncpy( pathName, fullPath, ++lastSlash );
		pathName[ lastSlash ] = '\0';
		}
	else
#endif /* !( __UNIX__ || __MAC__ ) */
		if( lastSlash > 0 )
			{
			/* Create the pathname, stomping the last '/' since hchdir()
			   doesn't like it */
			strncpy( pathName, fullPath, lastSlash );
			pathName[ lastSlash++ ] = '\0';
			}
		else
			{
			if( !lastSlash )
				/* Special case:  File is off the root dir */
				*pathName = '/';
			pathName[ ++lastSlash ] = '\0';
			}

	return( lastSlash );
	}

/* Check whether a given directory exists */

BOOLEAN dirExists( char *pathName )
	{
	int driveSpecOffset = 0;
	BOOLEAN retVal = TRUE;

	/* Convert the path into an OS-compatible format */
	extractPath( pathName, currentDir );

#if !defined( __UNIX__ ) && !defined( __MAC__ )
	/* Go the the specified drive if necessary */
	workDrive = getDrive();
	if( *pathName && pathName[ 1 ] == ':' )
		{
		currentDrive = *pathName - 'A';
		if( currentDrive != workDrive )
			setDrive( currentDrive );
		driveSpecOffset = 2;
		}
#endif /* !( __UNIX__ || __MAC__ ) */

	/* Save the current directory for later */
	getCwd( workDir );

	if( currentDir[ driveSpecOffset ] && hchdir( currentDir + driveSpecOffset ) == IO_ERROR )
		retVal = FALSE;
	else
		/* If the hchdir() was successful we have to go back to the orig.dir. */
		hchdir( workDir );

#if !defined( __UNIX__ ) && !defined( __MAC__ )
	/* Return to the original drive and flag the fact that we've done so */
	setDrive( workDrive );
	workDrive = ERROR;
#endif /* !( __UNIX__ || __MAC__ ) */

	return( retVal );
	}

/* Filter out illegal chars.  This is identical for DOS, OS/2, and UNIX since
   the only difference char would be '\\' and this is a no-no under UNIX as
   well */

static inline char xlateChar( const char ch )
	{
	return( ( ch < '!' || ch > '~' || ch == '\\' || ch == '/' || ch == '*' ||
			  ch == '?' || ch == ' ' || ch == ':' || ch == '|' || ch == '>' ||
			  ch == '<' ) ? '_' : ch );
	}

/* Intelligently truncate a filename to eight-dot-three format for MSDOS, or
   MAX_FILENAME for Unix.  The MSDOS version goes to great lengths to produce
   an optimal translation (ie the best a human could do); the Unix version
   doesn't do so well due to the more free-form nature of Unix file-names.
   In any case suffixes of up to three characters are preserved (.c, .h,
   .cpp), otherwise the name is truncated at MAX_FILENAME */


static BOOLEAN fileNameTruncated;	/* Used by isTruncated() */

static char *truncFileName( char *fileName )
	{
	int i, j, lastDit, fileNameLength = strlen( fileName );
	static char truncName[ MAX_FILENAME ];
#ifdef __MSDOS__
	char ch;
#endif /* __MSDOS__ */

	/* Find last dit */
	for( lastDit = fileNameLength - 1; lastDit && fileName[ lastDit ] != '.'; \
		 lastDit-- );
#if defined( __MSDOS__ )
	if( !lastDit || fileName[ fileNameLength - 1 ] == '.' )
		lastDit = fileNameLength;

	/* Copy across first 8 chars or up to lastDit */
	for( i = 0; i < 8 && i < lastDit && i < fileNameLength; i++ )
		{
		ch = truncName[ i ] = xlateChar( fileName[ i ] );
		if( ch == '.' )
			truncName[ i ] = '_';
		}

	/* Add dit and continue if necessary */
	if( i < fileNameLength && fileName[ fileNameLength - 1 ] != '.' )
		{
		j = i;
		truncName[ i++ ] = '.';

		if( lastDit == MAX_FILENAME )
			{
			/* No dit, copy across next 3 chars */
			while( i < MAX_FILENAME - 1 && i < fileNameLength )
				truncName[ i++ ] = xlateChar( fileName[ j++ ] );
			}
		else
			{
			/* Copy across last 1-3 chars after dit */
			for( j = 0; fileName[ fileNameLength - 1 ] != '.' && j < 3 && \
				 i <= fileNameLength; fileNameLength--, j++ );
			while( j-- )
				truncName[ i++ ] = xlateChar( fileName[ fileNameLength++ ] );
			}
		}
#elif defined( __UNIX__ )
	if( !lastDit || fileName[ fileNameLength - 1 ] == '.' )
		{
		lastDit = fileNameLength;
		j = MAX_FILENAME - 1;
		}
	else
		/* Make sure we preserve at least 3 characters of suffix */
		j = ( MAX_FILENAME - 1 ) - \
			( ( fileNameLength - lastDit > 3 ) ? 4 : fileNameLength - lastDit );

	/* Copy across appropriate no.of chars or up to lastDit */
	for( i = 0; i < j && i < lastDit && i < fileNameLength; i++ )
		truncName[ i ] = xlateChar( fileName[ i ] );

	/* Add dit and continue if necessary */
	if( i < fileNameLength && fileName[ fileNameLength - 1 ] != '.' && \
		i < MAX_FILENAME && fileNameLength != lastDit )
		{
		j = i;
		truncName[ i++ ] = '.';

		/* Copy across last 1-3 chars after dit */
		for( j = 0; fileName[ fileNameLength - 1 ] != '.' && \
			 i <= fileNameLength; fileNameLength--, j++ );
		if( j > 3 )		/* Handle overshoot */
			j = 3;
		while( j-- )
			truncName[ i++ ] = xlateChar( fileName[ fileNameLength++ ] );
		}
#else
	hprintf( "Need to implement truncFileName() in FILESYS.C, line %d\n", __LINE__ );
#endif /* Various OS-specific defines */
	truncName[ i ] = '\0';

	fileNameTruncated = strcmp( fileName, truncName );
	return( truncName );
	}

/* Build the path to a given directory index, truncating names if necessary */

char *getPath( int dirNo )
	{
	WORD dirStack[ MAX_PATH ];	/* We'll run out of path length before we run
								   out of directory stack so this is safe */
	static char pathName[ MAX_PATH ];
	int stackIndex = 0, pathLen = 0;
	char *dirNamePtr;

	/* Get a chain of directories from the root to the desired directory */
	if( dirNo )
		do
			dirStack[ stackIndex++ ] = dirNo;
#pragma warn -pia
		while( ( dirNo = getParent( dirNo ) ) && stackIndex <= MAX_PATH );
#pragma warn +pia

	/* Build the path to the current directory */
	*pathName = '\0';
	while( stackIndex )
		{
		dirNamePtr = truncFileName( getDirName( dirStack[ --stackIndex ] ) );
		if( ( pathLen += strlen( dirNamePtr ) ) >= MAX_PATH - 1 )
			error( PATH_S__TOO_LONG, pathName );
		strcat( pathName, dirNamePtr );
		strcat( pathName, "/" );
		}

	return( pathName );
	}

/* Recreate a directory tree stored within an archive */

void makeDirTree( void )
	{
	char dirPath[ MAX_PATH ], *pathName;
	int outputPathLen = basePathLen;
	WORD dataLen, tagID, tagLen, count;
	BOOLEAN inPosition = FALSE;

	strcpy( dirPath, basePath );	/* We have already checked the validity
									   of basePath in handleArchive */
	for( count = getFirstDir(); count != END_MARKER; count = getNextDir() )
		{
		/* Get the path to the current directory.  Note that getPath()
		   returns a '/' at the end of the pathname.  This is then
		   stomped by the call to extractPath() in dirExists(), and is
		   in fact essential since otherwise extractPath() will treat the
		   last directory name as a filename */
		pathName = getPath( count );
		if( outputPathLen + strlen( pathName ) >= MAX_PATH )
			error( PATH_SS__TOO_LONG, basePath, pathName );
		strcpy( dirPath + outputPathLen, pathName );

		/* Try and create the new directory if it doesn't already exist.
		   We take advantage of the fact that dirExists() sets currentDir
		   to dirPath without the final slash */
		if( !dirExists( dirPath ) )
			{
			hprintfs( MESG_CREATING_DIRECTORY_s, dirPath );
			if( hmkdir( currentDir, MKDIR_ATTR ) == IO_ERROR )
				error( CANNOT_CREATE_DIR, dirPath );

			/* Handle tagged information if necessary */
#pragma warn -pia
			if( ( flags & STORE_ATTR ) && ( dataLen = getDirAuxDatalen( count ) ) )
#pragma warn +pia
				{
				/* Move to the correct position in the archive if we're not
				   already there */
				if( !inPosition )
					{
					movetoDirData();
					resetFastIn( archiveFD );
					inPosition = TRUE;
					}

				/* Grovel through the directory data field looking for
				   attribute tags */
				while( dataLen )
					if( readTag( &dataLen, &tagID, &tagLen ) == ATTRIBUTE_TAG )
						/* We've found an attribute tag, read in the
						   attributes and set them */
						hchmod( currentDir, readAttributeData( tagID ) );
				}

			/* Give the directory its real date if necessary.  We don't
			   need to check that the open is successful since we've just
			   created the directory so we know it exists */
			if( !( flags & TOUCH_FILES ) )
				setDirecTime( currentDir, getDirTime( count ) );
			}

		/* Make sure we don't get a "Nothing to do" error if there are no
		   files to extract */
		archiveChanged = TRUE;
		}

	/* Move back to the start of the archive if necessary */
	if( inPosition )
		hlseek( archiveFD, ( LONG ) HPACK_ID_SIZE, SEEK_SET );
	}

/****************************************************************************
*																			*
*						Archive Path-Handling Routines						*
*																			*
****************************************************************************/

/* Various vars used by several routines */

static int internalPathLen;

/* Build the path within the archive to a given file */

char *buildInternalPath( FILEHDRLIST *infoPtr )
	{
	static char internalPath[ MAX_PATH ];
	char *truncName;

	strcpy( internalPath, ( flags & STORE_PATH ) ? \
							getPath( infoPtr->data.dirIndex ) : "" );
	truncName = truncFileName( infoPtr->fileName );
	if( ( internalPathLen = strlen( internalPath ) + strlen( truncName ) ) >= MAX_PATH )
		error( PATH_SS_TOO_LONG, internalPath, truncName );
	strcat( internalPath, truncName );
	return( internalPath );
	}

/* Build the path outside the archive to a given file */

char *buildExternalPath( FILEHDRLIST *infoPtr )
	{
	static char externalPath[ MAX_PATH ];
	char *pathPtr;

	strcpy( externalPath, basePath );
	pathPtr = buildInternalPath( infoPtr );
	if( basePathLen + internalPathLen >= MAX_PATH )
		error( PATH_SS_TOO_LONG, externalPath, pathPtr );
	strcat( externalPath, pathPtr );
	return( externalPath );
	}

BOOLEAN isTruncated( void )
	{
	return( fileNameTruncated );
	}
