/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*							  UNIX-Specific Routines						*
*							 UNIX.C  Updated 11/01/92						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
* Copyright 1991-2 Stuart A.Woolford and Peter C.Gutmann.All rights reserved*
*																			*
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "defs.h"
#include "error.h"
#include "frontend.h"
#include "hpacklib.h"
#include "system.h"
#include "tags.h"
#include "io/hpackio.h"

/*	You press the keys with no effect,
	Your mode is not correct.
	The screen blurs, your fingers shake;
	You forgot to press escape.
	Can't insert, can't delete,
	Cursor keys won't repeat.
	You try to quit, but can't leave,
	An extra "bang" is all you need.

	You think it's neat to type an "a" or an "i"--
	Oh yeah?
	You won't look at emacs, no you'd just rather die
	You know you're gonna have to face it;
	You're addicted to vi!

	You edit files one at a time;
	That doesn't seem too out of line?
	You don't think of keys to bind--
	A meta key would blow your mind.
	H, J, K, L?  You're not annoyed?
	Expressions must be a Joy!
	Just press "f", or is it "t"?
	Maybe "n", or just "g"?

	Oh--You think it's neat to type an "a" or an "i"--
	Oh yeah?
	You won't look at emacs, no you'd just rather die
	You know you're gonna have to face it;
	You're addicted to vi!

	Might as well face it,
	You're addicted to vi!
	You press the keys without effect,
	Your life is now a wreck.
	What a waste!  Such a shame!
	And all you have is vi to blame.

	Oh--You think it's neat to type an "a" or an "i"--
	Oh yeah?
	You won't look at emacs, no you'd just rather die
	You know you're gonna have to face it;
	You're addicted to vi!

	Might as well face it,
	You're addicted to vi!

	- Chuck Musciano */

/* Get an input character.  Better versions are possible but they're
   eminently nonportable */

#ifdef POSIX

int hgetch( void )
	{
	char ch;

	system( "/bin/stty +raw" );
	ch = getchar();
	system( "/bin/stty +edit" );
	return( ch );
	}
#else

int hgetch( void )
	{
	char ch;

	system( "/bin/stty cbreak" );
	ch = getchar();
	system( "/bin/stty -cbreak" );
	return( ch );
	}
#endif /* POSIX */

/* Set a file's timestamp */

void setFileTime( const char *fileName, const LONG fileTime )
	{
	LONG tmp[ 2 ];

	tmp[ 0 ] = tmp[ 1 ] = fileTime;
	utime( fileName, tmp );
	}

#if !defined( IRIX ) && !defined( ULTRIX )

/* Rename a file */

void rename( const char *srcFile, const char *destFile )
	{
	link( srcFile, destFile );
	unlink( srcFile );
	}

#endif /* !( IRIX || ULTRIX ) */

#if !defined( POSIX ) && !defined( IRIX ) && !defined( ULTRIX )

/* Create a directory */

int mkdir( const char *dirName, const int mode )
	{
	char cmdStr[ MAX_PATH + 7 ];

	sprintf( cmdStr, "mkdir %s", dirName );
	return( ( system( cmdStr ) == -1 ) ? IO_ERROR : OK );
	}
#else

int hmkdir( const char *dirName, int mode )
	{
	int oldUmask = umask( mode ^ 0777 ), retVal;

	/* We have to be clever with umask here since if no x bits are set
	   noone will be able to access the directory, so we always give the
	   owner an x bit in MKDIR_ATTR.  Also if umask has group or other r
	   enabled we give them x as well */
	if( !( oldUmask & UNIX_ATTR_GROUP_R ) )
		mode |= UNIX_ATTR_GROUP_X;
	if( !( oldUmask & UNIX_ATTR_OTHER_R ) )
		mode |= UNIX_ATTR_OTHER_X;

	umask( mode ^ 0777 );			/* Make sure umask doesn't interfere */
	retVal = mkdir( dirName, mode );
	umask( oldUmask );				/* Restore original umask */

	return( retVal );
	}
#endif /* !( POSIX || IRIX || ULTRIX ) */

/* opendir(), readdir(), closedir() for those systems which don't have these
   functions.  If anyone ever uses this code let me know so I can open a
   bottle of champagne or something */

#if 0
#include <fcntl.h>
#include <sys/types.h>

#include <dir.h>

#define DIRBUFSIZE		512

typedef struct {
			   struct stat d_stat;		/* stat() info for dir */
			   char d_name[ MAX_FILENAME ];
			   } DIRECT;

typedef struct {
			   int dd_fd;				/* This directories' FD */
			   int dd_loc;				/* Index into buffer of dir info */
			   int dd_size;				/* No. of entries in buffer */
			   char dd_buf[ DIRBUFSIZE ];	/* Buffer of dir entries */
			   } DIR;

DIR *opendir( const char *dirName )
	{
	DIR *dirPtr;
	FD dirFD;

	/* Try and open directory corresponding to dirName */
	if( ( dirFD = hopen( dirName, O_RDONLY ) ) != FILE_ERROR )
		{
		/* Allocate room for directory information */
		if( ( dirPtr = ( DIR * ) hmalloc( sizeof( DIR ) ) ) != NULL )
			{
			/* Set up directory information */
			dirPtr->dd_fd = dirFD;
			dirPtr->dd_loc = 0;
			dirPtr->dd_size = 0;
			return( dirPtr );
			}
		hclose( dirFD );
		}
	return( NULL );
	}

/* Read out the next directory entry */

DIRECT *readdir( DIR *dirPtr )
	{
	static DIRECT dirInfo;			/* Dir.info as we want it set out */
	struct direct *diskDirInfo;		/* Dir.info as stored on disk */

	/* Grovel through dir.entries until we find a non-deleted file */
	do
		{
		/* Check if we need to read in more of dir */
		if( dirPtr->dd_loc >= dirPtr->dd_size )
			{
			/* Yes, read in next load of info */
			dirPtr->dd_loc = 0;
			if( ( dirPtr->dd_size = hread( dirPtr->dd_fd, dirPtr->dd_buf, DIRBUFSIZE ) ) == FILE_ERROR )
				/* Out of directory, return NULL dirinfo */
				return( NULL );
			}

		/* Extract this directory entry and point to next location in buffer */
		diskDirInfo = ( struct direct * ) ( dirPtr->dd_buf + dirPtr->dd_loc );
		dirPtr->dd_loc += sizeof( struct direct );
		}
	while( diskDirInfo->d_ino == 0 );

	/* Move info across to struct as we want it */
	strncpy( dirInfo.d_name, diskDirInfo->d_name, NAMEINDIR_LEN );
	dirInfo.d_name[ NAMEINDIR_LEN ] = '\0';
	stat( dirInfo.d_name, &dirInfo.d_stat );

	return( &dirInfo );
	}

/* End opendir() functions */

void closedir( DIR *dirPtr )
	{
	hclose( dirPtr->dd_fd );
	hfree( dirPtr );
	}
#endif /* 0 */

/* Find the first/next file in a directory */

BOOLEAN findFirst( const char *pathName, const ATTR fileAttr, FILEINFO *fileInfo )
	{
	char dirPath[ MAX_PATH ];
	int pos;

	/* Start at first entry in this directory */
	fileInfo->matchAttr = fileAttr;

	strcpy( dirPath, pathName );
	if( !*dirPath )
		{
		/* No pathname, search current directory */
		*dirPath = '.' ;
		dirPath[ 1 ] = '\0';
		}

	/* Check whether we want to match all files in a directory or one
	   particular file */
	if( dirPath[ strlen( dirPath ) - 1 ] == '.' )
		{
		/* Try and open directory */
		if( ( fileInfo->dirBuf = opendir( dirPath ) ) == NULL )
			return( FALSE );
		dirPath[ strlen( dirPath ) - 1 ] = '\0';	/* Zap '.' */
		strcpy( fileInfo->dName, dirPath );

		/* Pull file information out of directory */
		return( findNext( fileInfo ) );
		}
	else
		{
		/* Handling one particular file, just stat it */
		fileInfo->dirBuf=NULL;
		for( pos = strlen( dirPath ) - 1; pos != 0 && dirPath[ pos ] != '/'; \
			 pos-- );
		strcpy( fileInfo->fName, dirPath + pos );
		if( stat( dirPath, &fileInfo->statInfo ) != ERROR )
			{
			fileInfo->fTime = fileInfo->statInfo.st_mtime;
			fileInfo->fSize = fileInfo->statInfo.st_size;
			return TRUE;
			}
		else
			return FALSE;
		}
	}

BOOLEAN findNext( FILEINFO *fileInfo )
	{
	struct dirent *dirinfo;
	char dirPath[ MAX_PATH ];

	do
		{
		/* Grovel through the directory skipping deleted and non-matching files */
		if( ( dirinfo = readdir( fileInfo->dirBuf ) ) == NULL )
			return( FALSE );

		/* Fill out fileInfo fields.  Some systems may have the stat info
		   available after the readdir() call, but we have to assume the
		   worst for the portable version */
		strncpy( fileInfo->fName, dirinfo->d_name, MAX_FILENAME );
		fileInfo->fName[ MAX_FILENAME ] = 0;
		if( strlen( fileInfo->dName ) + strlen( fileInfo->fName ) > MAX_PATH )
			error( PATH_S__TOO_LONG, dirPath );
		strcpy( dirPath, fileInfo->dName );			/* Copy dirpath */
		strcat( dirPath, fileInfo->fName );			/* Add filename */
		stat( dirPath, &fileInfo->statInfo );
		fileInfo->fTime = fileInfo->statInfo.st_mtime;
		fileInfo->fSize = fileInfo->statInfo.st_size;
		}
	/* Sometimes we only want to match files, not directories */
	while( ( fileInfo->matchAttr == ALLFILES ) ? \
		   ( ( fileInfo->statInfo.st_mode & S_IFMT ) == S_IFDIR ) : 0 );

	return( TRUE );
	}

/* End findFirst/Next() for this directory */

void findEnd( const FILEINFO *fileInfo )
	{
	if( fileInfo->dirBuf != NULL )
		closedir( fileInfo->dirBuf );
	}

/* Get the screen size.  The environment variables $LINES and $COLUMNS will
   be used if they exist.  If not, then the TIOCGWINSZ call to ioctl() is
   used (if it is defined).  If not, then the TIOCGSIZE call to ioctl() is
   used (if it is defined).  If not, then the WIOCGETD call to ioctl() is
   used (if it is defined).  If not, then get the info from terminfo/termcap
   (if it is there).  Otherwise, assume we have a 24x80 model 33 */

#define DEFAULT_ROWS		24
#define DEFAULT_COLS		80

#ifdef POSIX

#error "Need to create a getScreenSize() for POSIX"

void getScreenSize( void )
	{
	screenWidth = DEFAULT_COLS;
	screenHeight = DEFAULT_ROWS;
	}
#else

/* Try to access terminfo through the termcap-interface in the curses library
   (which requires linking with -lcurses) or use termcap directly (which
   requires linking with -ltermcap) */

#ifndef USE_TERMCAP
  #if defined( USE_TERMINFO ) || defined( USE_CURSES )
	#define USE_TERMCAP
  #endif /* USE_TERMINFO || USE_CURSES */
#endif /* USE_TERMCAP */

#ifdef USE_TERMCAP
  #define TERMBUFSIZ    1024
  #define UNKNOWN_TERM  "unknown"
  #define DUMB_TERMBUF  "dumb:co#80:hc:"

  extern int  tgetent(), tgetnum();
#endif /* USE_TERMCAP */

/* Try to get TIOCGWINSZ from termios.h, then from sys/ioctl.h */

#include <termios.h>
#if !defined( TIOCGWINSZ ) && !defined( TIOCGSIZE ) && !defined( WIOCGETD )
  #include <sys/ioctl.h>
#endif /* !( TIOCGWINSIZ || TIOCGSIZE || WIOCGETD ) */

/* If we still don't have TIOCGWINSZ (or TIOCGSIZE) try for WIOCGETD */

#if !defined( TIOCGWINSZ ) && !defined( TIOCGSIZE ) && !defined( WIOCGETD )
  #include <sgtty.h>
#endif /* !( TIOCGWINSZ || TIOCGSIZE || WIOCGETD ) */

void getScreenSize( void )	/* Rot bilong kargo */
	{
	char *envLines, *envColumns;
	long rowTemp = 0, colTemp = 0;
#ifdef USE_TERMCAP
	char termBuffer[ TERMBUFSIZ ], *termInfo;
#endif /* USE_TERMCAP */
#ifdef TIOCGWINSZ
	struct winsize windowInfo;
#else
  #ifdef TIOCGSIZE
	struct ttysize windowInfo;
  #else
	#ifdef WIOCGETD
	  struct uwdata windowInfo;
	#endif /* WIOCGETD */
  #endif /* TIOCGSIZE */
#endif /* TIOCGSIZE */

	screenHeight = screenWidth = 0;

	/* Make sure that we're outputting to a terminal */
	if( !isatty( fileno( stderr ) ) )
		{
		screenHeight = DEFAULT_ROWS;
		screenWidth = DEFAULT_COLS;
		return;
		}

	/* LINES & COLUMNS environment variables override everything else */
	envLines = getenv( "LINES" );
	if( envLines != NULL && ( rowTemp = atol( envLines ) ) > 0 )
		screenHeight = ( int ) rowTemp;

	envColumns = getenv( "COLUMNS" );
	if( envColumns != NULL && ( colTemp = atol( envColumns ) ) > 0 )
		screenWidth = ( int ) colTemp;

#ifdef TIOCGWINSZ
	/* See what ioctl() has to say (overrides terminfo & termcap) */
	if( ( !screenHeight || !screenWidth ) && ioctl( fileno( stderr ), TIOCGWINSZ, &windowInfo ) != -1 )
		{
		if( !screenHeight && windowInfo.ws_row > 0 )
			screenHeight = ( int ) windowInfo.ws_row;

		if( !screenWidth && windowInfo.ws_col > 0 )
			screenWidth = ( int ) windowInfo.ws_col;
		}
#else
  #ifdef TIOCGSIZE
	/* See what ioctl() has to say (overrides terminfo & termcap) */
	if( ( !screenHeight || !screenWidth ) && ioctl( fileno( stderr ), TIOCGSIZE, &windowInfo ) != -1 )
		{
		if( !screenHeight && windowInfo.ts_lines > 0 )
			screenHeight = ( int ) windowInfo.ts_lines;

		if( !screenWidth && windowInfo.ts_cols > 0 )
			screenWidth = ( int ) windowInfo.ts_cols;
		}
  #else
	#ifdef WIOCGETD
	/* See what ioctl() has to say (overrides terminfo & termcap) */
	if( ( !screenHeight || !screenWidth ) && ioctl( fileno( stderr ), WIOCGETD, &windowInfo) != -1 )
		{
		if( !screenHeight && windowInfo.uw_height > 0 )
			screenHeight = ( int ) ( windowInfo.uw_height / windowInfo.uw_vs );

		if( !screenWidth && windowInfo.uw_width > 0 )
			screenWidth = ( int ) ( windowInfo.uw_width / windowInfo.uw_hs );
		}	/* You are in a twisty maze of standards, all different */
	#endif /* WIOCGETD */
  #endif /* TIOCGSIZE */
#endif /* TIOCGWINSZ */

#ifdef USE_TERMCAP
	/* See what terminfo/termcap has to say */
	if( !screenHeight || !screenWidth )
		{
		if( ( termInfo = getenv( "TERM" ) ) == NULL )
			termInfo = UNKNOWN_TERM;

		if( ( tgetent( termBuffer, termInfo ) <= 0 ) )
			strcpy( termBuffer, DUMB_TERMBUF );

		if( !screenHeight && ( rowTemp = tgetnum( "li" ) ) > 0 )
				screenHeight = ( int )rowTemp;

		if( !screenWidth && ( colTemp = tgetnum( "co" ) ) > 0 )
				screenWidth = ( int ) colTemp;
	}
#endif /* USE_TERMCAP */

	/* Use 80x24 if all else fails */
	if( !screenHeight )
		screenHeight = DEFAULT_ROWS;
	if( !screenWidth )
		screenWidth = DEFAULT_COLS;
	}
#endif /* POSIX */

int getCountry( void )
	{
	return( 0 );	/* Default to US - not very nice */
	}

#if defined( POSIX )

void htruncate( const FD theFD )
	{
	ltrunc( theFD, 0L, SEEK_CUR );
	}

#elif defined( IRIX ) || defined( ULTRIX )

void htruncate( const FD theFD )
	{
	ftruncate( theFD, tell( theFD ) );
	}

#else

/* No two htruncate()'s are the same, so we make sure everyone gets an error
   here so they must define one they can use */

#error "Need to implement/define htruncate in UNIX.C"

/* The worst-case htruncate() - open a new file, copy everything across to
   the truncation point, and delete the old file.  This only works because
   htruncate is almost never called, because this worst-case version will
   only be used on a few systems, and because the drive access speed is
   assumed to be fast */

void moveData( const FD _inFD, const FD destFD, const long noBytes );

void htruncate( const FD theFD )
	{
	FD newArchiveFD;
	char newArchiveName[ MAX_PATH ];
	long truncatePoint;

	/* Set up temporary filename to be the archive name with a ".TMP" suffix */
	strcpy( newArchiveName, errorFileName );
	strcpy( newArchiveName, strlen( newArchiveName ) - 3, "TMP" );

	if( ( newArchiveFD = hopen( newArchiveName, O_RDWR ) ) == FILE_ERROR )
		error( INTERNAL_ERROR );

	/* Use the moveData() routine to move all data up to the truncation point
	   to the new archive */
	truncatePoint = htell( archiveFD );
	hlseek( archiveFD, 0L, SEEK_SET );
	_outByteCount = 0;
	moveData( archiveFD, newArchiveFD, truncatePoint );

	/* Close and delete the old archive, and make the new archive the active
	   one */
	hclose( archiveFD );
	archiveFD = newArchiveFD;
	hunlink( errorFileName );
	hrename( newArchiveName, archiveName );
	}
#endif /* Various mutation-dependant truncate()'s */

/* Check whether two pathnames refer to the same file */

BOOLEAN isSameFile( const char *pathName1, const char *pathName2 )
	{
	struct stat statInfo1, statInfo2;

	stat( pathName1, &statInfo1 );
	stat( pathName2, &statInfo2 );
	return( statInfo1.st_ino == statInfo2.st_ino && \
			statInfo1.st_dev == statInfo2.st_dev );
	}

#if defined( IRIX ) || defined( ULTRIX )

void strlwr( char *string )
	{
	while( *string )
		{
		*string = tolower( *string );
		string++;
		}
	}
#endif /* IRIX || ULTRIX */

#if defined( IRIX )

/* memmove() for those systems which don't have it */

void memmove( char *dest, char *src, int len )
	{
	int itmp = ( len + 7 ) >> 3;

	if( dest > src )
		{
		dest += len;
		src += len;
		switch( len & 3 )
			{
			case 0:	do {	*--dest = *--src;
			case 7:			*--dest = *--src;
			case 6:			*--dest = *--src;
			case 5:			*--dest = *--src;
			case 4:			*--dest = *--src;
			case 3:			*--dest = *--src;
			case 2:			*--dest = *--src;
			case 1:			*--dest = *--src;
			 		} while( --itmp > 0 );
			}
		}
	else
		{
		switch( len & 3 )
			{
			case 0:	do {	*dest++ = *src++;
			case 7:			*dest++ = *src++;
			case 6:			*dest++ = *src++;
			case 5:			*dest++ = *src++;
			case 4:			*dest++ = *src++;
			case 3:			*dest++ = *src++;
			case 2:			*dest++ = *src++;
			case 1:			*dest++ = *src++;
				 	} while( --itmp > 0 );
			}
		}
	/* No it wasn't, it was just just to frighten you */
	}
#endif /* IRIX */
