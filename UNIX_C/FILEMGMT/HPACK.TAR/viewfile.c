/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*					   Display the Contents of an Archive					*
*						  VIEWFILE.C  Updated 16/12/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1989 - 1991  Peter C.Gutmann.  All rights reserved		*
*																			*
****************************************************************************/

#include <stdlib.h>
#include <string.h>
#include "defs.h"
#include "arcdir.h"
#include "choice.h"
#include "error.h"
#include "flags.h"
#include "frontend.h"
#include "hpacklib.h"
#include "hpaktext.h"
#include "system.h"
#include "wildcard.h"
#include "io/fastio.h"
#include "io/hpackio.h"
#include "tags.h"

/* Prototypes for functions in ARCHIVE.C */

void extractData( const FD dataFD, const WORD dataInfo, const LONG dataLen, \
				  const LONG fileLen, const BOOLEAN isFile );

#ifdef __MSDOS__

/* Prototypes for functions in MISC.ASM */

int getRatio( long dataLen, long compressedLen );
#endif /* __MSDOS__ */

/****************************************************************************
*																			*
*							Display Contents of Archive						*
*																			*
****************************************************************************/

/* The names of the OS's. */

const char *systemName[] = { "MSDOS", "UNIX ", "Amiga", " Mac ",
							 " Arc ", "OS/2 ", "IIgs ", "Atari",
							 " VMS ", "Prime", "?????" };

/* What format to print the date in */

enum { US, EUROPE, JAPAN };

int dateFormat;		/* Which of the above date formats to use */

/* Determine the format to print the date in */

inline void setDateFormat( void )
	{
	dateFormat = getCountry();
	}

#ifdef __MSDOS__
  void extractDate( const LONG time, int *time1, int *time2, int *time3, \
									 int *hours, int *minutes, int *seconds );
#else

/* Constants for time handling functions */

#define SECS_PER_DAY	86400L
#define DAYS_PER_YEAR	365
#define MONTHS_PER_YEAR	12

/* Lookup table for month lengths */

int monthLen[] = { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 };

/* Extract the date fields from the time value */

void extractDate( LONG time, int *time1, int *time2, int *time3, \
							 int *hours, int *minutes, int *seconds )
	{
	int days, months, years, leapYearOffset = 0;

	/* Extract date/time */
	days = ( int ) ( time / SECS_PER_DAY );
	time %= SECS_PER_DAY;

	/* Extract hours, minutes, seconds */
	*seconds = ( int ) ( time % 60 );
	time /= 60;
	*hours = ( int ) ( time / 60 );
	*minutes = ( int ) ( time % 60 );

	/* Extract days, months, years */
	years = days / DAYS_PER_YEAR;
	days = ( ( days % DAYS_PER_YEAR ) + 1 ) - ( years / 4 );

	/* Check for underflow due to leap years */
	if( days <= 0 )
		{
		/* Move back 1 year and adjust days to December */
		years--;
		days += DAYS_PER_YEAR;
		}

	/* Check for leap year extra day */
	if( !( years % 4 ) || ( years == 30 ) )
		{
		days--;				/* Subtract day for Feb.29 */
		leapYearOffset++;	/* Remeber extra day later on */
		}

	/* Evaluate month days */
	months = MONTHS_PER_YEAR - 1;
	while( days <= monthLen[ months ] )
		months--;
	days -= monthLen[ months ] + leapYearOffset;
	months++;		/* Convert offset from 0 -> 1 */
	years = ( years + 70 ) % 100;

	/* Reorder fields depending on country */
	switch( dateFormat )
		{
		case EUROPE:
			/* Use DD/MM/YY format */
			*time1 = days;
			*time2 = months;
			*time3 = years;
			break;

		case JAPAN:
			/* Use YY/MM/DD format */
			*time1 = years;
			*time2 = months;
			*time3 = days;
			break;

		default:
			/* Use MM/DD/YY format */
			*time1 = months;
			*time2 = days;
			*time3 = years;
		}
	}
#endif /* __MSDOS__ */

/* Display information on one file */

static inline void showFileInfo( const FILEHDRLIST *fileInfoPtr, LONG *totalLength, \
								 LONG *totalSize )
	{
	const FILEHDR *theHeader = &fileInfoPtr->data;
	int ratio, fileNameLen, maxFileNameLen;
	int fileNameFieldLen = screenWidth - 53;	/* Width of fileName field */
	int time1, time2, time3, hours, minutes, seconds;
	char fileName[ 256 ];
	WORD cryptInfo = theHeader->archiveInfo & ( ARCH_SECURED | ARCH_CRYPT );

	/* Handle file, data lengths and compression ratios.  The check for
	   fileLen > dataLen is necessary since we may end up expanding the
	   data when we append the checksum to the end */
	*totalLength += theHeader->fileLen;
	*totalSize += theHeader->dataLen;
#ifdef __MSDOS__
	ratio = getRatio( theHeader->fileLen, theHeader->dataLen );
#else
	if( theHeader->fileLen && theHeader->fileLen > theHeader->dataLen )
		ratio = 100 - ( int ) ( ( 100 * theHeader->dataLen ) / theHeader->fileLen );
	else
		ratio = 0;
#endif /* __MSDOS__ */

	/* Get filename, truncate if overly long, and add end marker */
	fileNameLen = strlen( fileInfoPtr->fileName );
	maxFileNameLen = ( fileNameLen > fileNameFieldLen ) ? fileNameFieldLen : fileNameLen;
	strncpy( fileName, fileInfoPtr->fileName, maxFileNameLen );
	fileName[ maxFileNameLen ] = '\0';
	if( fileNameLen > fileNameFieldLen )
		strcpy( &fileName[ fileNameFieldLen - 2 ], ".." );

	/* Set up the date fields */
	extractDate( theHeader->fileTime, &time1, &time2, &time3, \
									  &hours, &minutes, &seconds );

	hprintf( VIEWFILE_MAIN_DISPLAY, \
			 ( ( theHeader->archiveInfo & ARCH_SYSTEM ) >= OS_UNKNOWN ) ? \
				systemName[ OS_UNKNOWN ] : \
				systemName[ theHeader->archiveInfo & ARCH_SYSTEM ], \
			 theHeader->fileLen, theHeader->dataLen, ratio, \
			 time1, time2, time3, hours, minutes, seconds, \
			 ( cryptInfo == ( ARCH_CRYPT | ARCH_SECURED ) ) ? '#' : \
				( cryptInfo == ARCH_CRYPT ) ? '*' : \
				( cryptInfo == ARCH_SECURED ) ? '-' : ' ', \
			 fileName );
	}

/* The size of the directory stack.  We should never have more than 50
   directories in one pathname */

#define DIRSTACK_SIZE	50

/* Static vars for tracking totals when multiple archives are used */

static LONG grandTotalLength = 0L, grandTotalSize = 0L;
static int grandTotalFiles = 0, totalArchives = 0;

/* Display a directory of files within an archive */

void listFiles( void )
	{
	FILEHDRLIST *fileInfoPtr;
	DIRHDRLIST *dirInfoPtr;
	FILEPATHINFO *pathInfoPtr;
	FILENAMEINFO *fileNamePtr;
	FILEHDR theHeader;
	LONG totalLength = 0L, totalSize = 0L;
	int fileCount = 0, totalRatio = 0;
	int dirNo, stackIndex = 0;
	int time1, time2, time3, hours, minutes, seconds;
	WORD dirStack[ DIRSTACK_SIZE ], oldFlags, type, count;
	BOOLEAN showFile;
	char *dirName;

	/* Turn on stealth mode to disable printing of any extraneous noise
	   while extracting data.  This is safe since the view options don't
	   check for stealth mode */
	flags |= STEALTH_MODE;

	/* Print a newline if there is an archive listing preceding this one */
	if( totalArchives )
		hputchar( '\n' );

	hputs( VIEWFILE_TITLE );

	for( count = getFirstDir(); count != END_MARKER; count = getNextDir() )
		{
		/* First handle any special entries (if there are any and provided
		   it's not a multipart archive) */
		if( ( fileInfoPtr = getFirstFileEntry( count ) ) != NULL && \
			!( flags & MULTIPART_ARCH ) )
			do
				{
				/* Check whether this is an archive comment file, unless
				   we've been asked to diaply comment files only */
				if( !( flags & ARCH_COMMENT ) && \
					( type = fileInfoPtr->type & TYPE_MASK ) == TYPE_COMMENT_TEXT || \
					  type == TYPE_COMMENT_ANSI )
					{
					/* Display text comment via extractData() */
					setOutputIntercept( ( type == TYPE_COMMENT_TEXT ) ? \
										OUT_FMT_TEXT : OUT_DATA );
					theHeader = fileInfoPtr->data;
					hlseek( archiveFD, fileInfoPtr->offset, SEEK_SET );
					resetFastIn( archiveFD );
					oldFlags = flags;
					if( !( flags & XLATE_OUTPUT ) )
						{
						/* Turn on smart translation if none is specified */
						flags |= XLATE_OUTPUT;
						xlateFlags = XLATE_SMART;
						}
					extractData( NULL_STREAM, ( theHeader.archiveInfo & ~ARCH_STORAGE ) | \
								 setDataFormat( fileInfoPtr->type & FORMAT_MASK ), \
								 theHeader.dataLen, theHeader.fileLen, FALSE );
					flags = oldFlags;
					resetOutputIntercept();
					archiveChanged = TRUE;
					}
				}
			while( ( fileInfoPtr = getNextFileEntry() ) != NULL );

		if( !( viewFlags & VIEW_FILES ) )
			{
			/* Print the directory info first if necessary */
			if( count )
				{
				if( !( viewFlags & VIEW_DIRS ) )
					hputchar( '\n' );
				hprintf( MESG_DIRECTORY );

				/* Get chain of directories from root to current directory.
				   Some of this code is duplicated in getPath(), but we can't
				   use getPath() since it munges the pathName into an OS-
				   compatible format as it goes */
				dirNo = count;
				do
					dirStack[ stackIndex++ ] = dirNo;
#pragma warn -pia
				while( ( dirNo = getParent( dirNo ) ) && stackIndex <= DIRSTACK_SIZE );
#pragma warn +pia

				/* Now print full path to current directory */
				while( stackIndex )
					{
					dirName = getDirName( dirStack[ --stackIndex ] );
					hprintf( "/%s", dirName );
					}

				/* Finally, print the directory date */
				extractDate( getDirTime( count ), &time1, &time2, &time3, &hours, &minutes, &seconds );
				hprintf( MESG_DIRECTORY_TIME, time1, time2, time3, \
						 hours, minutes, seconds );
				}
			else
				if( ( getFirstFileEntry( ROOT_DIR ) == NULL ) && !( viewFlags & VIEW_FILES ) )
					/* If there are no files in the root directory and we want
					   to view directories, let the user know the root directory
					   exists */
					hputs( MESG_ARCHIVE_ROOT_DIRECTORY );

			/* Make sure we don't get a "Nothing to do" error if we elect to
			   view only (empty) directories */
			if( viewFlags & VIEW_DIRS )
				archiveChanged = TRUE;
			}

		/* Now print any subdirectories */
		if( viewFlags & VIEW_ALL )
			if( ( dirInfoPtr = getFirstDirEntry( count ) ) != NULL )
				do
					{
					extractDate( dirInfoPtr->data.dirTime, &time1, &time2, &time3, &hours, &minutes, &seconds );
					hprintf( MESG_SUBDIRECTORY_TIME, dirInfoPtr->dirName, \
							 time1, time2, time3, hours, minutes, seconds );
					}
				while( ( dirInfoPtr = getNextDirEntry() ) != NULL );

		/* Finally, print the files in the directory */
		if( !( viewFlags & VIEW_DIRS ) )
			{
			/* Sort the files if necessary */
			if( viewFlags & VIEW_SORTED )
				sortFiles( count );

			if( ( fileInfoPtr = getFirstFileEntry( count ) ) == NULL )
				{
				if( !( viewFlags & VIEW_FILES ) )
					hputs( MESG_NO_FILES );
				}
			else
				do
					{
					/* Exclude either special-format files by default, or non-comment
					   files if asked to display only comment files */
					if( flags & ARCH_COMMENT )
						showFile = ( type = fileInfoPtr->type & TYPE_MASK ) == TYPE_COMMENT_TEXT || \
									 type == TYPE_COMMENT_ANSI;
					else
						showFile = ( ( fileInfoPtr->data.archiveInfo & ARCH_STORAGE ) != FORMAT_SPECIAL );

					if( showFile )
						for( pathInfoPtr = filePathListStart; pathInfoPtr != NULL; \
							 pathInfoPtr = pathInfoPtr->next )
							for( fileNamePtr = pathInfoPtr->fileNames; fileNamePtr != NULL; \
								 fileNamePtr = fileNamePtr->next )
								if( matchString( fileNamePtr->fileName,
												 fileInfoPtr->fileName ) )
									{
									archiveChanged = TRUE;	/* We've accessed the archive */
									showFileInfo( fileInfoPtr, &totalLength, &totalSize );
									fileCount++;
									break;	/* Exit wildcard match loop */
									}
					}
				while( ( fileInfoPtr = getNextFileEntry() ) != NULL );
			}
		}

	/* Print summary of file info */
#ifdef __MSDOS__
	totalRatio = getRatio( totalLength, totalSize );
#else
	if( totalLength )
		totalRatio = 100 - ( int ) ( ( 100 * totalSize ) / totalLength );
	else
		totalRatio = 0;
#endif /* __MSDOS__ */

	hprintf( VIEWFILE_TRAILER, totalLength, totalSize, ( int ) totalRatio, \
			 fileCount, ( fileCount == 1 ) ? MESG_SINGULAR_FILES : \
			 								 MESG_PLURAL_FILES );

	/* Update grand totals */
	grandTotalLength += totalLength;
	grandTotalSize += totalSize;
	grandTotalFiles += fileCount;
	totalArchives++;
	}

/* Print summary of archives viewed if necessary */

void showTotals( void )
	{
	if( totalArchives > 1 )
		hprintf( VIEWFILE_GRAND_TOTAL, \
				 grandTotalLength, grandTotalSize, totalArchives, \
				 grandTotalFiles, \
				 ( grandTotalFiles == 1 ) ? MESG_SINGULAR_FILES : \
				 							MESG_PLURAL_FILES );
	}
