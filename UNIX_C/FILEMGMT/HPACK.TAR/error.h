/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*						  Error Handling Routines Header					*
*							ERROR.H  Updated 11/11/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1989 - 1991  Peter C.Gutmann.  All rights reserved		*
*																			*
****************************************************************************/

#ifdef SYSV
  #include "../io/hpackio.h"
#else
  #include "io/hpackio.h"
#endif /* SYSV */

/* The possible error messages.  When changing these remember to change
   the errors[] table in HPAKTEXT.C as well */

typedef struct {
			   int errorLevel;			/* The error exit level */
			   char *msg;				/* The error text itself */
			   } ERROR_INFO;

extern ERROR_INFO err00, err01, err02, err03, err04, err05, err06, err07, \
				  err08, err09, err10, err11, err12, err13, err14, err15, \
				  err16, err17, err18, err19, err20, err21, err22, err23, \
				  err24, err25, err26, err27, err28, err29, err30, err31, \
				  err32, err33, err34, err35, err36, err37, err38, err39;

#define INTERNAL_ERROR					&err00
#define OUT_OF_MEMORY					&err01
#define OUT_OF_DISK_SPACE				&err02
#define CANNOT_OPEN_ARCHFILE			&err03
#define CANNOT_OPEN_DATAFILE			&err04
#define CANNOT_OPEN_TEMPFILE			&err05
#define CANNOT_OPEN_SCRIPTFILE			&err06
#define PATH_NOT_FOUND					&err07
#define CANNOT_ACCESS_BASEDIR			&err08
#define CANNOT_CREATE_DIR				&err09
#define STOPPED_AT_USER_REQUEST			&err10
#define FILE_ERROR						&err11
#define ARCHIVE_DIRECTORY_CORRUPTED		&err12

#define PATH_S_TOO_LONG					&err13
#define PATH_S__TOO_LONG				&err14
#define PATH_SS_TOO_LONG				&err15
#define PATH_SS__TOO_LONG				&err16
#define PATH_S_S_TOO_LONG				&err17
#define CANNOT_OVERRIDE_BASEPATH		&err18
#define TOO_MANY_LEVELS_NESTING			&err19
#define TOO_MUCH_EXTRA_INFO				&err20
#define N_ERRORS_DETECTED_IN_SCRIPTFILE	&err21
#define NOT_HPACK_ARCHIVE				&err22
#define NOTHING_TO_DO					&err23
#define BAD_KEYFILE						&err24
#define UNKNOWN_COMMAND					&err25
#define UNKNOWN_DIR_OPTION				&err26
#define UNKNOWN_OVERWRITE_OPTION		&err27
#define UNKNOWN_VIEW_OPTION				&err28
#define UNKNOWN_OPTION					&err29

#define PASSWORDS_NOT_SAME				&err30
#define CANNOT_UPDATE_DEL_ARCH			&err31
#define CANNOT_CHANGE_MULTIPART_ARCH	&err32
#define LONG_ARG_NOT_SUPPORTED			&err33
#define BAD_WILDCARD_FORMAT				&err34
#define WILDCARD_TOO_COMPLEX			&err35
#define SECURITY_INFO_ERROR				&err36
#define CANNOT_READ_CRYPT_ARCH			&err37

/* Some global vars */

extern char errorFileName[];
extern FD errorFD;
extern char dirFileName[];
extern FD dirFileFD;
extern char secFileName[];
extern FD secFileFD;
extern int secInfoLen;
extern char startDrive, startDir[];
extern char workDrive, workDir[];
extern char currentDrive, currentDir[];
extern long oldArcEnd;
extern void *oldHdrlistEnd;				/* Actually FILEHDRLIST * */
extern int oldDirEnd;
extern unsigned int oldDirNameEnd;
extern FD archiveFD;
#ifdef __MSDOS__
  extern char archiveDrive;
#endif /* __MSDOS__ */

/* Prototypes for functions in ERROR.C */

void error( ERROR_INFO *errInfo, ... );
void fileError( void );
