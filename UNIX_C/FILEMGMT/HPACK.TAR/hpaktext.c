/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*						  		  HPACK Messages 							*
*							HPAKTEXT.C  Updated 31/12/91					*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*			Copyright 1991  Peter C.Gutmann.  All rights reserved			*
*																			*
****************************************************************************/

/* Generated: 23/01/92.  From file: HPAK_ENG.DEF */

/* The following are all the text messages (except for the hidden ones)
   contained in HPACK.  The error messages are stored in a special struct
   which also contains the error exit level.  Note that the messages are
   all stored as seperate strings instead of in one unified array to make
   automatic generation by a (currently experimental) preprocessing tool
   easier */

#include "defs.h"
#ifdef SYSV
  #include "../error.h"
  #include "../errorlvl.h"
  #include "../hpacklib.h"
#else
  #include "error.h"
  #include "errorlvl.h"
  #include "hpacklib.h"
#endif /* SYSV */

/****************************************************************************
*																			*
*									Errors									*
*																			*
****************************************************************************/

/* When changing the following remember to change the defines in ERROR.H
   as well */

#define ERR			ERROR_INFO

			/* Severe errors */
#ifdef __ARC__
ERR err00 =	{ EXIT_INT_ERR,		"Abort on data transfer" };	/* Blame the OS */
#else
ERR err00 =	{ EXIT_INT_ERR,		"Internal error" };
#endif /* __ARC__ */
ERR err01 =	{ EXIT_NO_MEM,		"Out of memory" };
ERR err02 =	{ EXIT_NO_DISK,		"Out of disk space" };
ERR err03 =	{ EXIT_NO_ARCH,		"Cannot open archive file %s" };
ERR err04 =	{ EXIT_NO_DATA,		"Cannot open data file %s" };
ERR err05 =	{ EXIT_NO_TEMP,		"Cannot open temp file" };
ERR err06 =	{ EXIT_NO_SCRIPT,	"Cannot open script file %s" };
ERR err07 =	{ EXIT_NO_PATH,		"Path %s not found" };
ERR err08 =	{ EXIT_NO_BASE,		"Cannot access base directory" };
ERR err09 =	{ EXIT_NO_MKDIR,	"Cannot create directory %s" };
ERR err10 =	{ EXIT_BREAK,		"Stopped at user request" };
#ifdef __MSDOS__
ERR err11 =	{ EXIT_FILE_ERR,	"File error type %02d" };
#else
ERR err11 =	{ EXIT_FILE_ERR,	"File error" };
#endif /* __MSDOS__ */
ERR err12 =	{ EXIT_DIR_CORRUPT,	"Archive directory corrupted" };

			/* Standard errors */
ERR err13 =	{ EXIT_LONG_PATH,	"Path %s too long" };
ERR err14 =	{ EXIT_LONG_PATH,	"Path %s... too long" };
ERR err15 =	{ EXIT_LONG_PATH,	"Path %s%s too long" };
ERR err16 =	{ EXIT_LONG_PATH,	"Path %s%s... too long" };
ERR err17 =	{ EXIT_LONG_PATH,	"Path %s/%s too long" };
ERR err18 =	{ EXIT_NO_OVERRIDE,	"Cannot override base path" };
ERR err19 =	{ EXIT_NEST,		"Too many levels of directory nesting" };
ERR err20 =	{ EXIT_EXTRAINFO_LEN,	"Too much auxiliary data" };
ERR err21 =	{ EXIT_SCRIPT_ERR,	"%s%d errors detected in script file" };
ERR err22 =	{ EXIT_NOT_ARCH,	"Not an HPACK archive" };
ERR err23 =	{ EXIT_NOTHING,		"Nothing to do" };
ERR err24 =	{ EXIT_BAD_KEYFILE,	"Bad keyfile" };
ERR err25 =	{ EXIT_COMMAND,		"Unknown command \'%s\'" };
ERR err26 =	{ EXIT_OPTION,		"Unknown directory option \'%c\'" };
ERR err27 =	{ EXIT_OPTION,		"Unknown overwrite option \'%c\'" };
ERR err28 =	{ EXIT_OPTION,		"Unknown view option \'%c\'" };
ERR err29 =	{ EXIT_OPTION,		"Unknown option \'%c\'" };

			/* Minor errors */
ERR err30 =	{ EXIT_PASS,		"Passwords not the same" };
ERR err31 =	{ EXIT_DELETE,		"Cannot update deleted archive" };
ERR err32 =	{ EXIT_MULTIPART,	"Cannot change multipart archive" };
ERR err33 =	{ EXIT_NOLONG,		"Long argument format not supported in this version" };
ERR err34 =	{ EXIT_BADWILD,		"Bad wildcard format in %s" };
ERR err35 =	{ EXIT_BADWILD,		"Wildcard expression too complex" };
ERR err36 =	{ EXIT_SECURITY,	"Bad security information" };
ERR err37 =	{ EXIT_NOCRYPT,		"Cannot read encrypted archive" };

/****************************************************************************
*																			*
*									Warnings								*
*																			*
****************************************************************************/

char warn00[] =	"Warning: Truncated %u bytes of EOF padding\n";
char warn01[] =	"Warning: %s. Continue [y/n] ";
char warn02[] =	"\nWarning: File checksum does not match computed checksum";
char warn03[] =	"Warning: Can't find public key -- cannot perform authentication check\n";
char warn04[] =	"Warning: Authentication data corrupted -- cannot perform authentication check\n";
char warn05[] =	"Warning: Secret key compromised for userid '%s'";
char warn06[] =	"\nWarning: Archive section too short, skipping...";
char warn07[] =	"Warning: Unknown script command '%s'\n";

/****************************************************************************
*																			*
*								General Messages							*
*																			*
****************************************************************************/

char mesg00[] =	"Verify multipart archive authenticity";
char mesg01[] =	"Verifying archive authenticity -- please wait\n";
char mesg02[] =	"Security information will be destroyed";
char mesg03[] =	"Archive directory corrupted";
char mesg04[] =	"%s [y/n] ";
char mesg05[] =	"%s %s [y/n/a] ";
char mesg06[] =	"Skipping %s\n";
char mesg07[] =	"Data is encrypted";
char mesg08[] =	"Extracting";
char mesg09[] =	" %s as";
char mesg10[] =	"Unknown archiving method";
char mesg11[] =	" - skipping %s\n";
char mesg12[] =	"Won't overwrite existing file %s\n";
char mesg13[] =	"%s already exists: Enter new filename ";
char mesg14[] =	"Path %s... too long\n";
char mesg15[] =	"already exists - overwrite";
char mesg16[] =	"Extract";
char mesg17[] =	"Display";
char mesg18[] =	"Test";
char mesg19[] =	"\n\tFile tested OK";
char mesg20[] =	"\nHit a key...";
char mesg21[] =	"Adding";
char mesg22[] =	"\nError: ";
char mesg23[] =	"Panic: Error during error recovery";
char mesg24[] =	"Creating directory %s\n";
char mesg25[] =	"\nProcessing script file %s\n";
char mesg26[] =	"Path %s... too long in line %d\n";
char mesg27[] =	"^ Bad character in filename in line %d\n";
char mesg28[] =	"Maximum level of ";
char mesg29[] =	"Adding directory %s\n";
char mesg30[] =	"Checking directory %s\n";
char mesg31[] =	"Leaving directory %s\n";
char mesg32[] =	"File %s already in archive - skipping\n";
char mesg33[] =	"Add";
char mesg34[] =	"Delete";
char mesg35[] =	"Deleting %s from archive\n";
char mesg36[] =	"Freshen";
char mesg37[] =	"Replace";
char mesg38[] =	"\nArchive is \'%s\'\n\n";
char mesg39[] =	"\nDone";
char mesg40[] =	"Directory: ";
char mesg41[] =	"\n\tCreated %02d/%02d/%02d, %02d:%02d:%02d\n";
char mesg42[] =	"Subdirectory %s, created %02d/%02d/%02d, %02d:%02d:%02d\n";
char mesg43[] =	"Archive root directory";
char mesg44[] =	"\tNo files";
char mesg45[] =	"file";
char mesg46[] =	"files";
char mesg47[] =	"\rKey must be between 5 and 50 characters long";
char mesg48[] =	"Password (5..50 characters): ";
char mesg49[] =	"Again: ";
char mesg50[] =	"This public key cannot be used.";
char mesg51[] =	"Warning: Signature doesn't match file contents!\nBad";
char mesg52[] =	"Good";
char mesg53[] =	" signature from: %s.\n\tSignature made on %02d/%02d/%02d, %02d:%02d:%02d\n\n";
char mesg54[] =	"This is part %u of a multipart archive\n";
char mesg55[] =	"Please insert the ";
char mesg56[] =	"next disk";
char mesg57[] =	"disk containing ";
char mesg58[] =	"part %u";
char mesg59[] =	"the last part";
char mesg60[] =	" of this archive";
char mesg61[] =	" and press a key";
char mesg62[] =	"Continuing... ";

/****************************************************************************
*																			*
*					Special Text Strings used in Viewfile.C					*
*																			*
****************************************************************************/

/* The following messages *must* have the various columns line up since they
   are used to display archive directory listings:

   System  Length   Size  Ratio   Date     Time    Name
   ------  ------  ------ -----   ----     ----    ----
	sssss ddddddd ddddddd  dd%  dd/mm/yy hh:mm:ss #sssssssssss...
		  ------- ------- -----					   ----
		  ddddddd ddddddd  dd%				       Total: dddd files

   Grand Total:
		  ddddddd ddddddd			         dd archives, dddd files */

char vmsg00[] =	"System  Length   Size  Ratio   Date     Time    Name\n" \
				"------  ------  ------ -----   ----     ----    ----";
char vmsg01[] =	" %s %7lu %7lu  %2d%%  %02d/%02d/%02d %02d:%02d:%02d %c%s\n";
char vmsg02[] =	"       ------- ------- -----                    ----\n" \
				"       %7lu %7lu  %2d%%                     Total: %u %s\n";
char vmsg03[] =	"\nGrand Total:\n" \
				"       %7lu %7lu                    %2d archives, %u %s\n";

/****************************************************************************
*																			*
*								OS-Specific Messages						*
*																			*
****************************************************************************/

#ifdef __MSDOS__

char osmsg00[] = "File sharing violation";
char osmsg01[] = "File locking violation";
char osmsg02[] = "File corresponds to device driver";

#endif /* __MSDOS__ */

/****************************************************************************
*																			*
*						Display Various (Long) Messages						*
*																			*
****************************************************************************/

#ifndef __MSDOS__

void showTitle( void )
	{
	hputs( "HPACK - The multi-system archiver Version 0.75c0.  Release date: 28/12/91" );
	hputs( "For MSDOS, OS/2, Apple IIgs, Macintosh, and UNIX" );
#if defined( __UNIX__ )
	hputs( "Copyright (c) Peter Gutmann 1989 - 1991.  Unix port by Stuart Woolford." );
#elif defined( __OS2__ )
	hputs( "Copyright (c) Peter Gutmann 1989 - 1991.  OS/2 port by Conrad Bullock." );
#else
	hputs( "Copyright (c) Peter Gutmann 1989 - 1991.  xxxx port by yyyy zzzz." );
#endif /* Various OS-dependant credits */
	}

void showHelp( void )
	{
	hputs( "\nUsage: HPACK command [options] archive [data files...][@scriptfiles... ]" );
	hputs( "\nValid HPACK commands are:" );
	hputs( " A - Add files          X - Extract files       V - Directory of files" );
	hputs( " P - View files         D - Delete files        F - Freshen files in archive" );
	hputs( " R - Replace files      U - Update files        T - Test archive integrity" );
	hputs( "\nValid HPACK options are:" );
	hputs( " -K - Overwrite existing archive       -T - Touch files on extraction" );
	hputs( " -R - Recurse through subdirectories   -P - Store directories recursed into" );
	hputs( " -S - Stealth mode                     -F - Store/restore file attributes" );
	hputs( " -I - Interactive mode                 -C - Encryption options: see HPACK.DOC" );
	hputs( " -W - Add archive comment              -E - Add error recovery info" );
	hputs( " -B<path>  - Specify base path         -D<*> - Directory options: see HPACK.DOC" );
	hputs( " -V<F,D,A> - View opts(Files,Dirs,All) -Z<*> - Sys-specific opts: see HPACK.DOC" );
	hputs( " -O<N,A,S,P>       - Overwrite options (None, All, Smart, Prompt)" );
#if defined( __MSDOS__ ) || defined( __OS2__ )
	hputs( " -X<R,Xxx,L,E,P,A> - Xlate opts (smart, CR, Hex lit, LF, EBCDIC, Prime, ASCII)" );
#elif defined( __MAC__ )
	hputs( " -X<C,Xxx,L,E,P,A> - Xlate opts (smart, CRLF, Hex lit, LF, EBCDIC,Prime,ASCII)" );
#elif defined( __UNIX__ ) || defined( __AMIGA__ )
	hputs( " -X<R,Xxx,C,E,P,A> - Xlate opts (smart, CR, Hex lit, CRLF, EBCDIC,Prime,ASCII)" );
#endif /* Various OS-specific defines */
	hputs( "\n\"archive\" is the HPACK archive, with a default extension of .HPK" );
	hputs( "\"data files\" are the files to archive, defaulting to all files if none are" );
	hputs( "             given.  Wildcards *, ?, [], ^/!, \\ can be used." );
	hputs( "         PROTOTYPE VERSION - SUPPLIED FOR EVALUATION PURPOSES ONLY" );
	exit( OK );
	}

#endif /* !__MSDOS__ */
