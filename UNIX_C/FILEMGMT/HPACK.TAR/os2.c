/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*							  OS/2-Specific Routines						*
*							  OS2.C  Updated 04/12/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*			Copyright 1991 Conrad Bullock.  All rights reserved				*
*																			*
****************************************************************************/

#define INCL_BASE
#include <os2.h>

#undef LONG

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "defs.h"
#include "system.h"
#include "io/hpackio.h"

/* Set a file's (or dir's) timestamp */

int setFileTime( const char *fileName, const LONG fileTime )
	{
	FILESTATUS info;
	FDATE date;
	FTIME time;
	struct tm *tmtime;
	HFILE hf;
	USHORT usAction;
	BOOLEAN Result;
	char tmpFileName[ 255 ];

	strcpy( tmpFileName, fileName );
    
    tmtime = localtime(&fileTime);
    
    time.twosecs = tmtime->tm_sec / 2;
    time.minutes = tmtime->tm_min;
    time.hours = tmtime->tm_hour;
    date.day = tmtime->tm_mday;
    date.month = tmtime->tm_mon;
    date.year = tmtime->tm_year;

    DosQPathInfo (tmpFileName, FIL_STANDARD, (PBYTE) &info, sizeof(info), 0L);

    info.fdateLastWrite = date;
    info.ftimeLastWrite = time;

    return (DosSetPathInfo(tmpFileName, FIL_STANDARD, &info, sizeof(info), 0, 0L) == 0);
	}

void setDrive( const int driveNo )
{
    DosSelectDisk( (USHORT) driveNo);
}
    
int getDrive( void )
{
    USHORT tmp;
    ULONG drive;
    
    DosQCurDisk(&tmp, &drive);
    
    return (drive);
}

int GetCountry(void)
{
    COUNTRYCODE CountCode;
    COUNTRYINFO CountInfo;
    USHORT retlen;
    USHORT res;
    
    CountCode.country = 0;
    CountCode.codepage = 0;
    
    res = DosGetCtryInfo ((USHORT) sizeof(CountInfo), &CountCode, &CountInfo,
                          &retlen);
                          
    if (res) return(1);
    
    return(CountInfo.fsDateFmt);
}

/* Find the first/next file in a directory */

time_t TimetoLong (FDATE FDate, FTIME FTime)
{
  time_t time;
  struct tm timebuf;

  timebuf.tm_sec = FTime.twosecs * 2;
  timebuf.tm_min = FTime.minutes;
  timebuf.tm_hour = FTime.hours;
  timebuf.tm_mday = FDate.day;
  timebuf.tm_mon = FDate.month;
  timebuf.tm_year = FDate.year;

  return (mktime(&timebuf));
}

BOOLEAN findFirst( char *filePath, const ATTR fileAttr, FILEINFO *fileInfo )
	{
  USHORT res;
  FILEFINDBUF FindBuffer;
  USHORT FindHandle, FindCount;

  FindHandle = 1;
  FindCount = 1;

  res = DosFindFirst(filePath, &FindHandle, fileAttr, &FindBuffer,
    sizeof (FindBuffer), &FindCount, 0L);

  if (res) return FALSE;

  strncpy(fileInfo->fName, FindBuffer.achName, FindBuffer.cchName);
  fileInfo->fName[FindBuffer.cchName] = 0;
  fileInfo->fSize = FindBuffer.cbFileAlloc;
  fileInfo->fAttr = FindBuffer.attrFile;
  fileInfo->fTime = TimetoLong (FindBuffer.fdateLastWrite,
                                FindBuffer.ftimeLastWrite);
  fileInfo->cTime = TimetoLong (FindBuffer.fdateCreation,
                                FindBuffer.ftimeCreation);
  fileInfo->aTime = TimetoLong (FindBuffer.fdateLastAccess,
                                FindBuffer.ftimeLastAccess);

  return TRUE;
  }

BOOLEAN findNext( FILEINFO *fileInfo )
	{
  USHORT res;
  FILEFINDBUF FindBuffer;
  USHORT FileCount;

  FileCount = 1;

  res = DosFindNext(1, &FindBuffer, sizeof (FindBuffer), &FileCount);

  if (res) return FALSE;

  strncpy(fileInfo->fName, FindBuffer.achName, FindBuffer.cchName);
  fileInfo->fName[FindBuffer.cchName] = 0;
  fileInfo->fSize = FindBuffer.cbFileAlloc;
  fileInfo->fAttr = FindBuffer.attrFile;
  fileInfo->fTime = TimetoLong (FindBuffer.fdateLastWrite,
                                FindBuffer.ftimeLastWrite);
  fileInfo->cTime = TimetoLong (FindBuffer.fdateCreation,
                                FindBuffer.ftimeCreation);
  fileInfo->aTime = TimetoLong (FindBuffer.fdateLastAccess,
                                FindBuffer.ftimeLastAccess);
  
  return TRUE;
}

int htruncate ( const FD theFile )
{
  ULONG FilePos;

  DosChgFilePtr ((HFILE) theFile, 0L, FILE_CURRENT, &FilePos);
  DosNewSize ((HFILE) theFile, FilePos);
}
