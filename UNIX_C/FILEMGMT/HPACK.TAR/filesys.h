/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*					Filesystem-Specific Support Routines Header				*
*							FILESYS.H  Updated 12/10/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1990, 1991 Peter C.Gutmann.  All rights reserved			*
*																			*
****************************************************************************/

#ifndef _FILESYS_DEFINED

#define _FILESYS_DEFINED

#include "arcdir.h"

char *buildInternalPath( FILEHDRLIST *fileInfoPtr );
char *buildExternalPath( FILEHDRLIST *fileInfoPtr );
BOOLEAN isTruncated( void );
char *getPath( WORD dirIndex );
int extractPath( char *fullPath, char * pathName );
BOOLEAN dirExists( char *pathName );
void makeDirTree( void );

#endif /* _FILESYS_DEFINED */
