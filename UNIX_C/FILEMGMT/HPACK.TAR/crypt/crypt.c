/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*						   Encryption Interface Routines					*
*							 CRYPT.C  Updated 03/10/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1990 - 1991  Peter C.Gutmann.  All rights reserved		*
*																			*
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "defs.h"
#ifdef SYSV
  #include "../choice.h"
  #include "../error.h"
  #include "../hpacklib.h"
  #include "../hpaktext.h"
  #include "../system.h"
  #include "../crypt/crypt.h"
  #include "../crypt/md5.h"
  #include "../crypt/pgp.h"
  #include "../crypt/rsa.h"
  #include "../io/fastio.h"
  #include "../io/hpackio.h"
#else
  #include "choice.h"
  #include "error.h"
  #include "hpacklib.h"
  #include "hpaktext.h"
  #include "system.h"
  #include "crypt/crypt.h"
  #include "crypt/md5.h"
  #include "crypt/pgp.h"
  #include "crypt/rsa.h"
  #include "io/fastio.h"
  #include "io/hpackio.h"
#endif /* SYSV */

/* Symbolic defines to indicate whether we should set globalPrecision when
   calling readMPI() or not */

#define SET_PRECISION		TRUE
#define NO_SET_PRECISION	FALSE

/* Minimum and maximum allowable key lengths.  Remember to change the prompt
   string in getPasswd() when changing these */

#define MIN_KEYLENGTH	5
#define MAX_KEYLENGTH	50

/* The number of levels of encryption to use */

int cryptLevel;

/* Whether a particular file needs en/decrypting.  When this flag is set,
   all calls to read() (on extraction) or write() (on adding) will call
   decryptInBuffer() or encryptOutBuffer() */

BOOLEAN doCrypt;

/* The S-Boxes used for encryption */

#define SBOX_SIZE	( 256 * sizeof( LONG ) )	/* 256 LONG's per S-Box */

int sBoxShift;				/* The index shift when addressing the S-Box array
							   as an array of BYTEs */
LONG *sBoxes = NULL;		/* The S-Boxes themselves */

/* The encryption password */

char key[ MAX_KEYLENGTH + 1 ];

/* The following are defined in FRONTEND.C */

extern char choice;

/* Prototypes for functions in VIEWFILE.C */

void extractDate( const LONG time, int *date1, int *date2, int *date3, \
								   int *hours, int *minutes, int *seconds );

/****************************************************************************
*																			*
* 						Initialise the Encryption System 					*
*																			*
****************************************************************************/

static char *getPasswd( char *passWord, const char *prompt )
	{
	int i;
	char ch;

	while( TRUE )
		{
		hprintf( prompt );

		/* Get a password string */
		i = 0;
		while( ( ch = hgetch() ) != '\r' && ch != '\n' )
			{
			/* Handle backspace key.  The way this is handled is somewhat
			   messy, since hitting BS at the last char position deletes
			   the previous char */
			if( ch == '\b' )
				{
				if( i )
					i--;
				else
					hputchar( '\a' );
				continue;
				}

			if( i == MAX_KEYLENGTH )
				hputchar( '\a' );
			else
				passWord[ i++ ] = ch;
			}

		/* Exit if format is valid */
		if( i >= MIN_KEYLENGTH )
			break;

		hputs( MESG_KEY_INCORRECT_LENGTH );
		}

	passWord[ i ] = '\0';

	/* Blank password prompt */
	hputchar( '\r' );
	for( i = 0; i < 40; i++ )
		hputchar( ' ' );
	hputchar( '\r' );

	return( passWord );
	}

/* Initialise the encryption system */

void initCrypt( void )
	{
	char key2[ MAX_KEYLENGTH + 1 ];
	BOOLEAN exitNow = FALSE;

	/* Allocate the S-Boxes */
	if( ( sBoxes = ( LONG * ) hmalloc( SBOX_SIZE * cryptLevel ) ) == NULL )
		error( OUT_OF_MEMORY );

	/* Set up the password */
	hputchar( '\n' );
	getPasswd( key, MESG_ENTER_PASSWORD );
	if( choice == ADD || choice == FRESHEN || choice == REPLACE || choice == UPDATE )
		exitNow = strcmp( key, getPasswd( key2, MESG_AGAIN ) );

	/* Scrub temporary password */
	memset( key2, 0, MAX_KEYLENGTH );

	if( exitNow )
		error( PASSWORDS_NOT_SAME );

/*	initSBoxes(); */
	}

/* Shut down the encryption system */

void endCrypt( void )
	{
	/* Scrub the password and S-Boxes so other users can't find it by
	   examining core after HPACK has run.  We have to check whether sBoxes
	   has been set up since we may be calling this from error() which may
	   have been called before initCrypt() has been called */
	memset( key, 0, MAX_KEYLENGTH + 1 );
	if( sBoxes != NULL )
		{
		memset( sBoxes, 0, SBOX_SIZE * cryptLevel );
		hfree( sBoxes );
		}
	}

/****************************************************************************
*																			*
*						Data Authentication Routines						*
*																			*
****************************************************************************/

/* Read a MPI in the form of a byte array preceded by a 16-bit bitcount from
   a file into a multiprecision register */

static int readMPI( MP_REG *mpReg, const FD keyFileFD, BOOLEAN doSetPrecision )
	{
	int count, byteCount;
	BYTE *regPtr = ( BYTE * ) mpReg;
	WORD bitCount;

	/* Read in the MPI itself from the file.  First, read in the bit count
	   and set the global precision accordingly */
	mp_init( mpReg, 0 );
	bitCount = fgetWord( keyFileFD );
	if( ( count = byteCount = bits2bytes( bitCount ) ) > MAX_BYTE_PRECISION )
		/* Impossibly long MPI value */
		return( ERROR );
	if( doSetPrecision && byteCount )
		/* Set the precision to that specified by the number read */
		setPrecision( bits2units( bitCount + SLOP_BITS ) );

	/* Read in the value */
	while( count-- )
		*regPtr++ = fgetByte( keyFileFD );

	/* Return number of bytes processed */
	return( byteCount + sizeof( WORD ) );
	}

/* Read in a key packet from a file.  It will return the ctb, timestamp,
   userid, and public key components n and e */

static BOOLEAN readKeyPacket( FD keyFileFD, LONG *timeStamp, char *userID, MP_REG *n, MP_REG *e )
	{
	int ctb;
	WORD certLength = 0;
	int count, i = 0, j;

	/*  Get key certificate CTB */
	if( ( ctb = fgetByte( keyFileFD ) ) == FEOF )
		return( FALSE );

	/* Get certificate length */
	if( ctbLength( ctb ) == sizeof( BYTE ) )
		certLength = ( WORD ) fgetByte( keyFileFD );
	else
		certLength = fgetWord( keyFileFD );

	/* Get timestamp */
	*timeStamp = fgetLong( keyFileFD );
	certLength -= sizeof( LONG );

	/* Get userID as Pascal string */
	count = fgetByte( keyFileFD );	/* Get length byte */
	certLength -= count + 1;		/* Adjust now for string length */
	while( count-- )
		userID[ i++ ] = fgetByte( keyFileFD );
	userID[ i ] = '\0';

	/* We're past certificate headers, now look at some key material */
	i = readMPI( n, keyFileFD, SET_PRECISION );
	j = readMPI( e, keyFileFD, NO_SET_PRECISION );
	certLength -= i + j;

	/* Check for possible problems in reading MPI's */
	if( i == ERROR || j == ERROR )
		error( BAD_KEYFILE );

	/* Skip rest of this key certificate */
	skipSeek( keyFileFD, ( LONG ) certLength );
	return( TRUE );
	}

/* Get the public key corresponding to a given keyID from the public key file */

static BOOLEAN getPublicKey( char *keyFileName, BYTE *keyID, LONG *timeStamp, \
							 char *userID, MP_REG *n, MP_REG *e )
	{
	FD keyFileFD;

	/* Open key file */
	if( ( keyFileFD = hopen( keyFileName, O_RDONLY | S_DENYWR ) ) == IO_ERROR )
		return( FALSE );
	resetFastIn( keyFileFD );

	/* Grovel through the file looking for the key */
	while( TRUE )
		{
		if( !readKeyPacket( keyFileFD, timeStamp, userID, n, e ) )
			break;

		/* keyID contains key fragment, check it against n from keyfile */
		if( !memcmp( keyID, n, KEYFRAGSIZE ) )
			{
			/* Found key matching ID */
			hclose( keyFileFD );
			return( TRUE );
			}
		}

    /* Couldn't find key */
	hclose( keyFileFD );
	return( FALSE );
	}

/* Calculate the MD5 message digest for a section of a file */

static void md5file( const FD inFD, const long startPos, long noBytes, MD5_CTX *mdContext )
	{
	int bytesToProcess;

	hlseek( inFD, startPos, SEEK_SET );
	MD5Init( mdContext );
	while( noBytes )
		{
		bytesToProcess = ( noBytes < _BUFSIZE ) ? \
						 ( int ) noBytes : _BUFSIZE;
		hread( inFD, _inBuffer, bytesToProcess );
		noBytes -= bytesToProcess;

		/* Calculate the MD5 checksum for the buffer contents */
		MD5Update( mdContext, _inBuffer, bytesToProcess );
		}
	MD5Final( mdContext );
	}

/* Check a block of data's signature */

void checkSignature( LONG startPos, LONG noBytes )
	{
	char *pgpPath, keyFileName[ MAX_PATH ];
	BYTE outBuffer[ MAX_BYTE_PRECISION ];
	BYTE keyID[ KEYFRAGSIZE ];
	LONG timeStamp;
	MP_REG signature[ MAX_UNIT_PRECISION ];	/* MP_REG is now long-aligned */
	MP_REG n[ MAX_UNIT_PRECISION ], e[ MAX_UNIT_PRECISION ];
	char userID[ 256 ];
	MD5_CTX mdContext;
	int i, time1, time2, time3, hours, minutes, seconds;
	BOOLEAN hasPath = FALSE;

	/* Build path to keyring file */
	*keyFileName = '\0';
	if( ( pgpPath = getenv( PGPPATH ) ) != NULL )
		{
		if( strlen( pgpPath ) + PUBLIC_KEYRING_FILELENGTH > MAX_PATH )
			error( PATH_SS_TOO_LONG, pgpPath, PUBLIC_KEYRING_FILENAME );
		strcpy( keyFileName, pgpPath );
		if( ( i = keyFileName[ strlen( keyFileName ) - 1 ] ) != '/' && i != '\\' )
			/* Add trailing slash if necessary */
			strcat( keyFileName, "/" );
		hasPath = TRUE;
		}
	strcat( keyFileName, PUBLIC_KEYRING_FILENAME );

	/* Skip CTB and length field */
	i = ctbLength( fgetByte( archiveFD ) );
	while( i-- )
		fgetByte( archiveFD );

	/* Copy rest of key fragment */
	for( i = 0; i < KEYFRAGSIZE; i++ )
		keyID[ i ] = fgetByte( archiveFD );

	/* Get signed message digest, first, setting precision to max.value to be
	   on the safe side */
	setPrecision( MAX_UNIT_PRECISION );
	if( readMPI( signature, archiveFD, NO_SET_PRECISION ) == ERROR )
		{
		/* Authentication information corrupted, complain and process file
		   anyway */
		hputs( WARN_SEC_INFO_CORRUPTED );
		return;
		}

	/* Use keyID prefix to get and validate public key from a key file.  Check
	   for the keyFile both on the PGPPATH (if it exists) and in the current
	   directory */
	if( !( getPublicKey( keyFileName, keyID, &timeStamp, userID, n, e ) || \
		 ( hasPath && getPublicKey( PUBLIC_KEYRING_FILENAME, keyID, &timeStamp, userID, n, e ) ) ) )
		{
		/* Can't get public key, complain and process file anyway */
		hputs( WARN_CANT_FIND_PUBLIC_KEY );
		return;
		}
	else
		{
		/* Got good public key, now use it to check signature */
		if( testEq( e, 0 ) )
			{
			/* Means secret key has been compromised */
			hprintf( WARN_SECRET_KEY_COMPROMISED_FOR_s, userID );
			hputs( MESG_PUBLIC_KEY_CANNOT_BE_USED );
			return;
			}

		/* Recover message digest via public key */
		mp_modexp( ( MP_REG * ) outBuffer, signature, e, n );

		/* Look at nested stuff within RSA block and make sure it's the
		   correct message digest algorithm */
		if( !ctbType( outBuffer[ 0 ], CTBTYPE_MD ) || outBuffer[ 2 ] != MD5_ALGORITHM_BYTE )
			goto badSig;	/* Bad RSA decrypt */

		/* Extract date (with endiannes conversion) by moving data into the
		   input buffer and doing an fgetLong() */
		memcpy( _inBuffer, outBuffer + 19, 4 );
		_inByteCount = 0;
		_inBytesRead = 4;
		timeStamp = fgetLong( archiveFD );

		/* Compute message digest for rest of file and compare */
		md5file( archiveFD, startPos, noBytes, &mdContext );
		if( memcmp( mdContext.digest, outBuffer + 3, 16 ) )
badSig:		hprintf( MESG_BAD_SIGNATURE );
		else
			hprintf( MESG_GOOD_SIGNATURE );
		extractDate( timeStamp, &time1, &time2, &time3, &hours, &minutes, &seconds );
		hprintf( MESG_SIGNATURE_FROM_s_DATE_dddddd, \
				 userID, time1, time2, time3, hours, minutes, seconds );
		}
	}

/****************************************************************************
*																			*
*						Parse Security Information							*
*																			*
****************************************************************************/

#ifdef UNIMPLEMENTED

/* Parse the supplied security information */

void parseSecInfo( const FD outFD, LONG startPos, LONG noBytes )
	{
	BYTE ctb = fgetByte( archiveFD );

	/* Pull apart the security info to see what we've got */
	if( !isCTB( ctb ) )
		error( SECURITY_INFO_ERROR );

	/* Process all nested parsable info */
	do
		{
		/* Check if PKE is Public Key Encryption */
		if( ctbType( ctb, CTBTYPE_PKE ) )
			{
			if( ( status = decryptFile( archiveFD, outFD, startPos, noBytes ) ) == ERROR )
				error( BAD_DECRYPT );
			if( !status )
				/* No nested parsable info, exit loop */
				break;

			/* Nested parsable info indicated, process it */
			wipefile( SCRATCH_CTX_FILENAME );
			remove( SCRATCH_CTX_FILENAME );
			rename( plainfile,  SCRATCH_CTX_FILENAME );
			strcpy( cipherfile, SCRATCH_CTX_FILENAME );
			continue;		/* Skip rest of loop */
			}

		if( ctbType( ctb, CTBTYPE_SKE ) )
			{
			if( !checkSignature( cipherfile, plainfile, startPos, noBytes ) )
				/* No nested parsable info, exit */
				break;

			/* Nested parsable info indicated, process it */
			wipefile( SCRATCH_CTX_FILENAME );
			remove( SCRATCH_CTX_FILENAME );
			rename( plainfile,  SCRATCH_CTX_FILENAME );
			strcpy( cipherfile, SCRATCH_CTX_FILENAME );
			continue;		/* Skip rest of loop */
			}

		if( ctb == CTB_CKE )
			{
			/* Conventional Key Encrypted ciphertext */
			if( ( status = secretDecryptFile( archiveFD, outFD, startPos, noBytes ) ) == ERROR )
				error( BAD_DECRYPT );
			if( !status )
				/* No nested parsable info, exit loop */
				break;

			/* Nested parsable info indicated, process it */
			wipefile( SCRATCH_CTX_FILENAME );
			remove( SCRATCH_CTX_FILENAME );
			rename( plainfile,  SCRATCH_CTX_FILENAME );
			strcpy( cipherfile, SCRATCH_CTX_FILENAME );
			continue;		/* Skip rest of loop */
			}

		/* Unknown packet type */
		error( SECURITY_INFO_ERROR );
		}
	while( TRUE );

	/* Destroy any sensitive information in scratchfile: */
	wipefile( SCRATCH_CTX_FILENAME );
	remove( SCRATCH_CTX_FILENAME );
	}

#endif /* UNIMPLEMENTED */
