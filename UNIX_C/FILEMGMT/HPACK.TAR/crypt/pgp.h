/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*								PGP Interface Header						*
*							  PGP.H  Updated 23/07/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*			Copyright 1991  Peter C.Gutmann.  All rights reserved			*
*																			*
****************************************************************************/

/* The following defines are from Phil Zimmermann's PGP encryption package */

/* Cipher Type Byte (CTB) definitions */

#define CTB_DESIGNATOR	0x80
#define CTB_TYPE		0x7C
#define CTB_LEN			0x03

#define isCTB(ctb)		( ( ( ctb ) & CTB_DESIGNATOR ) == CTB_DESIGNATOR )

/* Defines to extract information from the CTB */

#define ctbLength(ctb)		( ( int ) 1 << ( int ) ( ( ctb ) & CTB_LEN ) )
#define ctbType(ctb,type)	( ( ( ctb ) & CTB_TYPE ) == ( type << 2 ) )
#define isSecretKey(ctb)	ctbType( ctb, CTB_CERT_SECKEY_TYPE )

/* Magic values for the CTB.  Note that HPACK doesn't handle most of
   these */

#define CTBTYPE_PKE			1	/* Packet encrypted with RSA public key */
#define CTBTYPE_SKE			2	/* Packet signed with RSA secret key */
#define CTBTYPE_MD			3	/* Message digest packet */
#define CTBTYPE_CONKEY		4	/* Conventional key packet */
#define CTBTYPE_CERT_SECKEY	5	/* Secret key certificate */
#define CTBTYPE_CERT_PUBKEY	6	/* Public key certificate */
#define CTBTYPE_COMPRESSED	8	/* Compressed data packet */
#define CTBTYPE_CKE			9	/* Conventional-key-encrypted data */
#define CTBTYPE_LITERAL		12	/* Raw data */

/* Unimplemented CTB packet types.  PGP doesn't handle these either */

#define CTBTYPE_RAW1		13	/* Raw data, with filename, date, crc32 prefix */
#define CTBTYPE_PATTERN		14	/* unique file prefix autorecognition pattern */
#define CTBTYPE_EXTENDED	15	/* 2-byte CTB, 256 extra CTB types */

/* A set of mysterious defines to extract information from the CTB */

#define	CTB_BYTE(type,len)	( CTB_DESIGNATOR + ( type << 2 ) + len )

#define CTB_PKE 			CTB_BYTE( CTBTYPE_PKE, 1 )
#define CTB_SKE 			CTB_BYTE( CTBTYPE_SKE, 1 )
#define CTB_MD 				CTB_BYTE( CTBTYPE_MD, 0 )
#define CTB_CONKEY 			CTB_BYTE( CTBTYPE_CONKEY, 0 )
#define CTB_CERT_SECKEY 	CTB_BYTE( CTBTYPE_CERT_SECKEY, 1 )
#define CTB_CERT_PUBKEY 	CTB_BYTE( CTBTYPE_CERT_PUBKEY, 1 )
#define CTB_CKE				CTB_BYTE( CTBTYPE_CKE, 3 )
#define CTB_LITERAL			CTB_BYTE( CTBTYPE_LITERAL, 3 )
#define CTB_COMPRESSED		CTB_BYTE( CTBTYPE_COMPRESSED, 3 )
#define CTB_PATTERN			CTB_BYTE( CTBTYPE_PATTERN, 0 )

/* Conventional encryption algorithm selector bytes */

#define DES_ALGORITHM_BYTE	1	/* Use DES */
#define BASS_ALGORITHM_BYTE 2	/* Use BassOmatic */

/* Message digest algorithm selector bytes */

#define MD4_ALGORITHM_BYTE	1	/* MD4 message digest algorithm */
#define MD5_ALGORITHM_BYTE	2	/* MD5 message digest algorithm */

/* Data compression algorithm selector bytes */

#define LZH_ALGORITHM_BYTE	1	/* LZH compression algorithm */
#define LZA_ALGORITHM_BYTE	2	/* LZA compression algorithm */

/* Defines to handle signature certificates */

#define MAX_SIGCERT_LENGTH	( 1 + 2 + KEYFRAGSIZE + 2 + MAX_BYTE_PRECISION )
#define MAX_KEYCERT_LENGTH	( 1 + 2 + 4 + 256 + 5 * ( 2 + MAX_BYTE_PRECISION ) )

/* No.of bytes in key ID modulus fragment */

#define KEYFRAGSIZE 		8

/* Global filenames and system-wide file extensions used by PGP */

#if defined( __MSDOS__ ) && ( ARCHIVE_TYPE == 3 )
  #define PGPPATH					NULL		/* Figure this one out! */
#else
  #define PGPPATH					"PGPPATH"	/* Env.var for PGP path */
#endif /* __MSDOS__ */

/* These files use the environmental variable PGPPATH as a default path */

#define PUBLIC_KEYRING_FILENAME		"keyring.pub"
#define PUBLIC_KEYRING_FILELENGTH	( sizeof( PUBLIC_KEYRING_FILENAME ) - 1 )
#define SECRET_KEYRING_FILENAME		"keyring.sec"
#define SECRET_KEYRING_FILELENGTH	( sizeof( SECRET_KEYRING_FILENAME ) - 1 )
#define RANDSEED_FILENAME			"randseed.pgp"
