/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*							Encryption Interface Header						*
*							 CRYPT.H  Updated 22/07/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1990 - 1991  Peter C.Gutmann.  All rights reserved		*
*																			*
****************************************************************************/

/* The level of encryption used, and whether a particular file needs
   en/decryption */

extern int cryptLevel;
extern BOOLEAN doCrypt;

/* Prototypes for the encryption functions */

void initCrypt( void );
void endCrypt( void );
void checkSignature( LONG dataStartPos, LONG dataLength );
