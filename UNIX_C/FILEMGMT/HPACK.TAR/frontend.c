/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*								Main Archiver Code							*
*							FRONTEND.C  Updated 09/01/92					*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1989 - 1992  Peter C.Gutmann.  All rights reserved		*
*																			*
****************************************************************************/

#include <ctype.h>
#if !defined( __MSDOS__ ) && !defined( __MAC__ ) && !defined( __IIGS__ )
  #include <signal.h>
#endif /* !( __MSDOS__ || __MAC__ || __ IIGS__ ) */
#include <stdlib.h>
#include <string.h>
#include "defs.h"
#include "arcdir.h"
#include "choice.h"
#include "error.h"
#include "filesys.h"
#include "flags.h"
#include "frontend.h"
#include "hpacklib.h"
#include "hpaktext.h"
#include "system.h"
#include "tags.h"
#include "wildcard.h"
#include "crypt/crypt.h"
#include "io/fastio.h"
#include "io/hpackio.h"
#include "store/store.h"

/* Prototypes for functions in VIEWFILE.C */

void setDateFormat( void );
void listFiles( void );
void showTotals( void );

/* Prototypes for functions in ARCHIVE.C */

void addData( const FILEINFO *fileInfoPtr, const WORD dirIndex, const FD dataFD );
void retrieveData( FILEHDRLIST *fileInfo );

BOOLEAN confirmSkip( const char *str1, const char *str2, const BOOLEAN str1fileName );

/* Prototypes for functions in SCRIPT.C */

void addFilespec( char *fileSpec );
void freeFilespecs( void );
void processListFile( const char *listFileName );

/* Prototypes for compression functions */

void initPack( const BOOLEAN initAllBuffers );
void endPack( void );

#ifdef __MSDOS__
  void ndoc( const char **strPtr );
#endif /* __MSDOS__ */

/* The following are defined in ARCHIVE.C */

extern BOOLEAN overWriteEntry;	/* Whether we overwrite the existing file
								   entry or add a new one in addFileHeader()
								   - used by FRESHEN, REPLACE, UPDATE */

/* The extensions used for HPACK archives, and used to match HPACK archives */

#ifdef __MSDOS__
  char HPAK_EXT[] = ".HPK";
  #define HPAK_MATCH_EXT	HPAK_EXT
#else
  char HPAK_EXT[] = ".hpk";
  char HPAK_MATCH_EXT[] = ".[Hh][Pp][Kk]";
#endif /* __MSDOS__ */

/* The distance in bytes to the next piece of data to handle */

long skipDist;

/* Some general vars used throughout HPACK */

char choice;				/* The command to the archiver */
WORD flags = 0;				/* Various flags set by the user */
WORD dirFlags = 0;			/* Directory-handling flags set by the user */
WORD overwriteFlags = 0;	/* Overwrite-on-extract flags */
WORD viewFlags = 0;			/* Options for the View command */
WORD xlateFlags = 0;		/* Options for output translation */
WORD cryptFlags = 0;		/* Options for encryption/security */
WORD sysSpecFlags = 0;		/* System-specific options */
WORD commentType = TYPE_NORMAL;	/* The type of the archive comment */
BOOLEAN archiveChanged = FALSE;	/* Whether the archive has been changed */
char basePath[ MAX_PATH ];	/* The output directory given by the -b option */
int basePathLen = 0;		/* The length of the basePath */
int screenHeight, screenWidth;	/* The screen size */

/****************************************************************************
*																			*
*							Handle Command-line Switches					*
*																			*
****************************************************************************/

/* Handle the command for the archive.  This can also be done in a switch
   statement; however the compiler probably produces code equivalent to the
   following, and it is far more compact in source form */

#define NO_CMDS	9

static void doCommand( const char *theCommand )
	{
	int i;

	choice = toupper( *theCommand );
	for( i = 0; ( i < NO_CMDS ) && ( "ADFPVXRUT"[ i ] != choice ); i++ );
	if( i == NO_CMDS || theCommand[ 1 ] )
		error( UNKNOWN_COMMAND, theCommand );
	}

/* Get a byte as two hex digits - used by several sections of doArg() */

#ifdef __MSDOS__
  BYTE getHexByte( char **strPtr );
#else
BYTE getHexByte( char **strPtr )
	{
	char ch;
	BYTE retVal;

	retVal = toupper( **strPtr );
	retVal -= ( retVal >= 'A' ) ? 'A' - 10 : '0';
	*strPtr++;
	if( isxdigit( **strPtr ) )
		{
		retVal <<= 4;
		ch = toupper( **strPtr );
		ch -= ( ch >= 'A' ) ? ( 'A' - 10 ) : '0';
		*strPtr++;
		retVal |= ch;
		}
	return( retVal );
	}
#endif /* __MSDOS__ */

/* Get all switches and point at the next arg to process */

/* Flags used/not used:
   Used:     .BCDEF..I.K.MNOP.RST.VWX.Z
   Not used: A.....GH.J.L....Q...U...Y. */

static void doArg( const char *argv[], int *count )
	{
	char *strPtr, ch;
	BYTE lineEndChar;
	int length = 0;

	*basePath = '\0';	/* Default is no output directory */

	while( TRUE )
		{
		strPtr = ( char * ) argv[ *count ];
		if( *strPtr == '-' )
			{
			/* Process individual args */
			strPtr++;
			while( *strPtr )
				{
				ch = *strPtr++;				/* Avoid toupper() side-effects */
				switch( toupper( ch ) )
					{
					case 'B':
						/* Copy the argument across */
						while( *strPtr )
							{
							basePath[ length ] = caseConvert( *strPtr );
							strPtr++;
							if( ++length >= MAX_PATH - 1 )
								error( PATH_S__TOO_LONG, basePath );
							}
						basePath[ length ] = '\0';

						/* Append a '/' if necessary */
#ifdef __MSDOS__
						if( length && ( ch = basePath[ length - 1 ] ) != '/' && \
																   ch != ':' )
#else
						if( length && ( ch = basePath[ length - 1 ] ) != '/' )
#endif /* __MSDOS__ */
							{
							strcat( basePath, "/" );
							length++;
							}
						basePathLen = length;
						break;

					case 'C':
						flags |= CRYPT;
						cryptLevel = 1;		/* Set default level if none given */
						if( *strPtr == '1' || *strPtr == '2' )
							cryptLevel = *strPtr++ - '0';
						break;

					case 'D':
						ch = *strPtr++;
						switch( toupper( ch ) )
							{
							case 'A':
								dirFlags |= DIR_ALLPATHS;
								break;

							case 'M':
								dirFlags |= DIR_MKDIR;
								break;

							case 'N':
								dirFlags |= DIR_NOCREATE;
								break;

							case 'R':
								dirFlags |= DIR_RMDIR;
								break;

							case 'V':
								dirFlags |= DIR_MVDIR;
								break;

							default:
								error( UNKNOWN_DIR_OPTION, *--strPtr  );
							}
						break;

					case 'E':
						flags |= ERROR_RECOVER;
						break;

					case 'F':
						flags |= STORE_ATTR;
						break;

					case 'I':
						flags |= INTERACTIVE;
						break;

					case 'K':
						flags |= OVERWRITE_SRC;
						if( choice == FRESHEN || choice == REPLACE || choice == UPDATE )
							error( CANNOT_UPDATE_DEL_ARCH );
						break;

					case 'M':
						flags |= MULTIPART_ARCH;
						if( choice == DELETE || choice == FRESHEN || \
							choice == REPLACE || choice == UPDATE )
							error( CANNOT_CHANGE_MULTIPART_ARCH );
						break;

					case 'N':
#ifdef __MSDOS__
						ndoc( &strPtr );
#endif /* __MSDOS__ */
						break;

					case 'O':
						ch = *strPtr++;
						switch( toupper( ch ) )
							{
							case 'A':
								overwriteFlags |= OVERWRITE_ALL;
								break;

							case 'N':
								overwriteFlags |= OVERWRITE_NONE;
								break;

							case 'P':
								overwriteFlags |= OVERWRITE_PROMPT;
								break;

							case 'S':
								overwriteFlags |= OVERWRITE_SMART;
								break;

							default:
								error( UNKNOWN_OVERWRITE_OPTION, *--strPtr  );
							}
						break;

					case 'P':
						flags |= STORE_PATH;
						break;

					case 'R':
						flags |= RECURSE_SUBDIR;
						break;

					case 'S':
						/* Stu if you fclose( STDOUT ) to implement this I'll
						   dump ten thousand frogs on you */
						flags |= STEALTH_MODE;
						break;

					case 'T':
						flags |= TOUCH_FILES;
						break;

					case 'V':
						ch = *strPtr++;
						switch( toupper( ch ) )
							{
							case 'A':
								viewFlags |= VIEW_ALL;
								break;

							case 'D':
								viewFlags |= VIEW_DIRS;
								break;

							case 'F':
								viewFlags |= VIEW_FILES;
								break;

							case 'S':
								viewFlags |= VIEW_SORTED;
								break;

							default:
								error( UNKNOWN_VIEW_OPTION, *--strPtr  );
							}
						break;

					case 'W':
						flags |= ARCH_COMMENT;
						ch = *strPtr++;
						switch( toupper( ch ) )
							{
							case 'G':
								/* GIF graphics comment */
								commentType = TYPE_COMMENT_GIF;
								break;

							case 'N':
								/* ANSI text comment */
								commentType = TYPE_COMMENT_ANSI;
								break;

							default:
								/* Default: Text comment */
								commentType = TYPE_COMMENT_TEXT;
								strPtr--;	/* Correct strPtr value */
							}
						break;

					case 'X':
						/* Only apply outupt translation if it would make sense */
						if( choice == EXTRACT || choice == DISPLAY )
							flags |= XLATE_OUTPUT;

						/* Determine which kind of translation is required */
						ch = *strPtr++;
						switch( toupper( ch ) )
							{
							case 'A':
								xlateFlags |= XLATE_EOL;
								lineEndChar = '\0';
								break;

#if !defined( __MSDOS__ ) && !defined( __OS2__ )
							case 'C':
								xlateFlags |= XLATE_EOL;
								lineEndChar = '\r' | 0x80;
								break;
#endif /* !( __MSDOS__ || __OS2__ ) */

							case 'E':
								xlateFlags |= XLATE_EBCDIC;
								break;

#if !defined( __UNIX__ ) && !defined( __AMIGA__ )
							case 'L':
								xlateFlags |= XLATE_EOL;
								lineEndChar = '\n';
								break;
#endif /* !( __UNIX__ || __AMIGA__ ) */

							case 'P':
								xlateFlags |= XLATE_PRIME;
								break;

#ifndef __MAC__
							case 'R':
								xlateFlags |= XLATE_EOL;
								lineEndChar = '\r';
								break;
#endif /* !__MAC__ */

							case 'S':
								xlateFlags = XLATE_SMART;
								break;

							case 'X':
								/* Get line-end-char in hex */
								xlateFlags |= XLATE_EOL;
								lineEndChar = getHexByte( &strPtr );
								break;

							default:
								/* Default: Smart translate */
								xlateFlags = XLATE_SMART;
								strPtr--;	/* Correct strPtr value */
							}

						/* Set up the translation system if necessary */
						initTranslationSystem( lineEndChar );

						break;

					case 'Z':
#if defined( __MSDOS__ )
						if( toupper( *strPtr ) == 'S' )
							/* Check for device filenames on extract */
							sysSpecFlags |= SYSPEC_CHECKSAFE;
						else
							error( UNKNOWN_OPTION, *--strPtr );

						strPtr++;			/* Skip arg */
#elif defined( __UNIX__ )
						if( matchString( strPtr, "lower" ) )
							/* Force lower case on file and dir names */
							sysSpecFlags |= SYSPEC_FORCELOWER;
						else
							error( UNKNOWN_OPTION, *--strPtr );

						while( *strPtr )
							strPtr++;		/* Skip to end of arg */
#else
						error( LONG_ARG_NOT_SUPPORTED );
#endif /* Various system-specific options */
						break;

					default:
						error( UNKNOWN_OPTION, *--strPtr );
					}
				}
			( *count )++;
			}
		else
			break;
		}

#ifdef __UNIX__
	/* If we're running in the background, turn on stealth mode so we don't
	   swamp the (l)user with noise.  Checking STDIN is a pretty good 
	   indication of whether the (l)user will want output or not */
	if( !isatty( STDIN ) )
		flags |= STEALTH_MODE;
#endif /* __UNIX__ */
	}

/****************************************************************************
*																			*
*						Support Routines for the Main Code					*
*																			*
****************************************************************************/

/* Keep a record of every archive processed and don't do the same archive
   again.  This detail is necessary due to a combination of local OS file
   handling and HPACK file handling.  In the cases where HPACK works on
   a second file which it then renames as the original after deleting the
   original, the findNext() call may then match this newly-created archive
   and process it again, which results in either a "Nothing to do" error
   (for DELETE, FRESHEN, and UPDATE), or an endless loop as we keep matching
   the new archives (for REPLACE) */

typedef struct FL {
				  char name[ MAX_FILENAME ];	/* This archive's name */
				  struct FL *next;				/* Pointer to next record */
				  } FILEDATA;

static FILEDATA *archiveNameListHead = NULL;

static BOOLEAN addArchiveName( char *archiveName )
	{
	FILEDATA *namePtr, *prevPtr, *newRecord;

	for( namePtr = archiveNameListHead; namePtr != NULL; \
					prevPtr = namePtr, namePtr = namePtr->next )
		/* Check whether we've already processed an archive of this name */
		if( !strcmp( archiveName, namePtr->name ) )
			return( TRUE );

	/* We have reached the end of the list without a match, so we add this
	   archive name to the list */
	if( ( newRecord = ( FILEDATA * ) hmalloc( sizeof( FILEDATA ) ) ) == NULL )
		error( OUT_OF_MEMORY );
	strcpy( newRecord->name, archiveName );
	newRecord->next = NULL;
	if( archiveNameListHead == NULL )
		archiveNameListHead = newRecord;
	else
		prevPtr->next = newRecord;
	return( FALSE );
	}

#ifndef __MSDOS__

/* Free up the memory used by the list of archive names */

static void freeArchiveNames( void )
	{
	FILEDATA *namePtr = archiveNameListHead, *headerPtr;

	/* A simpler implementation of the following would be:
	   for( namePtr = archiveNameListHead; namePtr != NULL; namePtr = namePtr->next )
		   hfree( namePtr );
	   However this will fail on some systems since we will be trying to
	   read namePtr->next out of a record we have just free()'d */
	while( namePtr != NULL )
		{
		headerPtr = namePtr;
		namePtr = namePtr->next;
		hfree( headerPtr );
		}
	}
#endif /* !__MSDOS__ */

/* Add a series of directories to an archive (used by processDir()) */

static void addDirPath( char *pathName, const int currPathLen, const WORD dirIndex )
	{
	FILEINFO fileInfo;
	int matchLen, count;
	char ch;

	/* We shouldn't get here if the DIR_NOCREATE flags is set to specify that
	   no directories should be created if they don't already exist */
	if( dirFlags & DIR_NOCREATE )
		{
		pathName[ currPathLen ] = '\0';		/* Truncate to pure path */
		error( PATH_NOT_FOUND, pathName );
		}

	setArchiveCwd( dirIndex );

	/* Grovel through all directories in the path, adding them to the
	   archive directory tree as we go */
	matchLen = strlen( getPath( dirIndex ) );
	while( matchLen < currPathLen )
		{
		/* Get the next directories name */
		for( count = matchLen + 1; pathName[ count ] && pathName[ count ] != '/';
			 count++ );
		ch = pathName[ count ];
		pathName[ count ] = '\0';

		/* Try and add the new directory */
		if( findFirst( pathName, FILES_DIRS, &fileInfo ) && isDirectory( fileInfo ) )
			{
			hprintfs( MESG_ADDING_DIRECTORY_s, fileInfo.fName );
			addDirName( fileInfo.fName, fileInfo.fTime );
			if( flags & STORE_ATTR )
				{
#if defined( __MSDOS__ )
				addDirData( MSDOS_ATTR, 0 );
				fputDirByte( fileInfo.fAttr );
#elif defined( __UNIX__ )
				addDirData( UNIX_ATTR, 0 );
				fputDirWord( fileInfo.statInfo.st_mode );
				addDirData( FILE_TIME, 0 );
				fputDirLong( fileInfo.statInfo.st_ctime );	/* Save change time */
				fputDirLong( fileInfo.statInfo.st_atime );	/* Save access time */
#elif defined( __MAC__ )
				addDirData( MAC_ATTR, 0 );
				/* -- write attr's, dates, etc etc -- */
				hprintf( "Need to set up directory tag handling in FRONTEND.C, line %d\n", __LINE__ );
#elif defined( __AMIGA__ )
				addDirData( AMIGA_ATTR, 0 );
				/* -- write attr's, dates, etc etc -- */
				hprintf( "Need to set up directory tag handling in FRONTEND.C, line %d\n", __LINE__ );
#elif defined( __ATARI__ )
				addDirData( ATARI_ATTR, 0 );
				/* -- write attr's, dates, etc etc -- */
				hprintf( "Need to set up directory tag handling in FRONTEND.C, line %d\n", __LINE__ );
#elif defined( __ARC__ )
				addDirData( ARC_ATTR, 0 );
				/* -- write attr's, dates, etc etc -- */
				hprintf( "Need to set up directory tag handling in FRONTEND.C, line %d\n", __LINE__ );
#endif /* Various OS-dependant attribute writes */
				}
			pathName[ count ] = ch;
			matchLen = count;
			findEnd( &fileInfo );
			}
		else
			error( PATH_NOT_FOUND, pathName );
		}
	}

/* Process one directories worth of files */

#define MAX_LEVELS		15		/* Max.directory depth we will recurse to */

static void processDir( FILENAMEINFO *fileNameList, const char *filePath )
	{
	FILEINFO fileInfo, currentDir[ MAX_LEVELS ];
	FILENAMEINFO *fileNamePtr;
	int currentLevel = 0, i;
	int pathEnd[ MAX_LEVELS ];
	char pathName[ MAX_PATH ], ch;
	int currPathLen = strlen( filePath ), nameLen;
	BOOLEAN skipFind = FALSE, skipFile;
	WORD dirIndex = ROOT_DIR;	/* Default dir for no STORE_PATH option */
	ATTR matchAttr = ( flags & STORE_ATTR ) ? ALLFILES_DIRS : FILES_DIRS;
	FD workFD;

	/* Perform a depth-first search of all directories below the current
	   one.  Note that there is little advantage to be gained from an
	   explicit match rather than MATCH_ALL since we will at some point need
	   to match MATCH_ALL anyway to find directories; this also lets us use
	   extended wildcards when doing the string comparisons */
	strcpy( pathName, filePath );
	if( currPathLen && !( currPathLen == 1 && *pathName == '/' ) )
		/* Append a '/' if necessary */
		pathName[ currPathLen++ ] = '/';
	strcpy( pathName + currPathLen, MATCH_ALL );
	if( findFirst( pathName, matchAttr, &fileInfo ) )
		skipFind = TRUE;

	while( TRUE )
		if( skipFind || findNext( &fileInfo ) )
			{
			skipFind = FALSE;

			/* See if the file we have found is a directory */
			if( isDirectory( fileInfo ) )
				{
				/* Continue if we've hit "." or ".." */
				if( *fileInfo.fName == '.' && ( !fileInfo.fName[ 1 ] || \
							( fileInfo.fName[ 1 ] == '.' && !fileInfo.fName[ 2 ] ) ) )
					continue;

				if( flags & RECURSE_SUBDIR )
					{
					/* Check the path length (the +5 is for the later addition
					   of a '/' between the name and the path, and a "/*.*"
					   at the end */
					if( ( ( nameLen = strlen( fileInfo.fName ) ) + currPathLen + 4 ) >= MAX_PATH )
						error( PATH_S_S_TOO_LONG, pathName, fileInfo.fName );

					/* Set up the information for the new directory */
					pathEnd[ currentLevel ] = currPathLen;
					currentDir[ currentLevel++ ] = fileInfo;
					strcpy( pathName + currPathLen, fileInfo.fName );
					currPathLen += nameLen;
					if( flags & STORE_PATH )
						{
						/* Add the new directory if it isn't already in the archive */
						if( matchPath( pathName, currPathLen, &dirIndex ) != PATH_FULLMATCH )
							{
							/* Only add this path if we've been asked to add
							   all paths anyway regardless of whether they contain
							   any files */
							if( dirFlags & DIR_ALLPATHS )
								{
								addDirPath( pathName, currPathLen, dirIndex );
								archiveChanged = TRUE;
								}
							}
						else
							{
							/* Go to that directory and update its timestamp */
							setArchiveCwd( dirIndex );
							setDirTime( dirIndex, fileInfo.fTime );
							}
						}
					hprintfs( MESG_CHECKING_DIRECTORY_s, pathName );
					if( currentLevel >= MAX_LEVELS )
						error( TOO_MANY_LEVELS_NESTING );
					strcpy( pathName + currPathLen++, SLASH_MATCH_ALL );
					findFirst( pathName, matchAttr, &fileInfo );
							/* This findFirst can never fail since we always match "." */
					skipFind = TRUE;
					continue;
					}
				else
					/* Make sure we don't mistake directories for filenames */
					continue;
				}

			/* Try and match the filename */
			for( fileNamePtr = fileNameList; fileNamePtr != NULL; \
				 fileNamePtr = fileNamePtr->next )
				if( matchString( fileNamePtr->fileName, fileInfo.fName ) )
					if( !( flags & STORE_PATH ) || \
						( matchPath( pathName, ( currPathLen ) ? currPathLen - 1 : 0, \
												   &dirIndex ) ) == PATH_FULLMATCH )
						{
retry:
						strcpy( pathName + currPathLen, fileInfo.fName );

						/* Make sure we don't try to archive the archive */
						skipFile = FALSE;
						for( i = strlen( fileInfo.fName ) - 1; i; i-- )
							if( ( fileInfo.fName[ i ] == '.' ) && \
								( ( ch = fileInfo.fName[ i + 1 ] ) == '$' || \
									ch == 'H' || ch == 'h' ) )
								{
								/* First we perform a relatively cheap search
								   for the HPAK_MATCH_EXT or "$$x" suffix to
								   see if this is actually an archive file.
								   Only then will it be necessary to perform
								   the expensive call to check if the files
								   are identical */
								if( matchString( fileInfo.fName + i, HPAK_MATCH_EXT ) || \
									!strncmp( fileInfo.fName + i, ".$$", 3 ) )
									{
									/* We've found an HPACK-related file; check
									   them to see if they are identical. The
									   following [ i + 3 ] is safe since we can
									   only arrive at this point if there is a
									   valid suffix at [ i + 3 ] */
									if( dirFileFD && ( fileInfo.fName[ i + 3 ] == '1' ) )
										skipFile = isSameFile( dirFileName, pathName );
									else
										if( secFileFD && ( fileInfo.fName[ i + 3 ] == '2' ) )
											skipFile = isSameFile( secFileName, pathName );
										else
											skipFile = isSameFile( errorFileName, pathName );
									break;
									}
								break;	/* Stop looking after first '.' */
								}

						if( skipFile )
							/* The file is an HPACK-related one, skip it */
							break;

						/* Complain if the file is already in the archive and we
						   try to ADD it.  Don't complain otherwise, since it will
						   be replaced during pass 2 of the UPDATE command */
						if( addFileName( ( flags & STORE_PATH ) ? dirIndex : 0, \
										 commentType, fileInfo.fName, 0 ) == TRUE )
							{
							if( choice == ADD )
								hprintf( MESG_FILE_s_ALREADY_IN_ARCH__SKIPPING, \
												fileInfo.fName );
							break;	/* Exit the for loop */
							}

						/* Ask the user whether they want to handle this file */
						if( ( flags & INTERACTIVE ) && \
							  confirmSkip( MESG_ADD, fileInfo.fName, FALSE ) )
							{
							/* Remove the last filename entered from the name
							   table since we since we won't be adding this file */
							deleteLastFileName();
							break;	/* Exit the for loop */
							}

						if( ( workFD = hopen( pathName, O_RDONLY | S_DENYWR ) ) == IO_ERROR )
							error( CANNOT_OPEN_DATAFILE, pathName );
						addData( &fileInfo, dirIndex, workFD );
						hclose( workFD );

						break;	/* Exit the for loop */
						}
					else
						{
						/* Build the path to the file inside the archive.  The
						   currPathLen check is in case of a trailing '/' */
						addDirPath( pathName, ( currPathLen ) ? \
									currPathLen - 1 : 0, dirIndex );

						/* Restore the directory index and continue */
						dirIndex = currEntry;
						goto retry;
						}
			}
		else
			/* Go back up one level if we can and try again */
			if( currentLevel )
				{
				pathName[ currPathLen ? currPathLen - 1 : 0 ] = '\0';
				hprintfs( MESG_LEAVING_DIRECTORY_s, pathName );
				findEnd( &fileInfo );
				fileInfo = currentDir[ --currentLevel ];
				currPathLen = pathEnd[ currentLevel ];
				if( flags & STORE_PATH )
					popDir();
				}
			else
				break;
	}

/* Process a data file (with wildcards allowed) */

static void handleArchive( void )
	{
	FD workFD, freshenFD, tempFD;
	FILEHDRLIST *prevPtr;
	FILEINFO fileInfo;
	FILEPATHINFO *pathInfoPtr;
	FILENAMEINFO *fileInfoPtr;
	char archiveFileName[ MAX_PATH ], *filePath;
	FILEHDRLIST *list2currPtr, *list2startPtr = NULL;
	int driveSpecOffset = 0;
	BOOLEAN falseBasePath = FALSE;

	/* Reset the fast I/O subsystem */
	resetFastOut();

	/* Make sure the base path is valid */
	if( *basePath && !dirExists( basePath ) )
		error( CANNOT_ACCESS_BASEDIR, basePath );

	/* Options which perform no processing on an archive */
	if( choice == VIEW )
		{
		listFiles();
		return;
		}

	/* Options which add files to an archive */
	if( choice == ADD || choice == UPDATE )
		{
		/* Write ID string at start if necessary */
		if( !htell( archiveFD ) )
			{
			memcpy( _outBuffer, HPACK_ID, HPACK_ID_SIZE );
			_outByteCount += HPACK_ID_SIZE;
			}

		/* Convert the base path into a proper form */
		extractPath( basePath, currentDir );

		/* Go to the directory specified in the base path if necessary */
		workDrive = currentDrive = startDrive;
		*workDir = '\0';
		if( *basePath )
			{
#if !defined( __UNIX__ ) && !defined( __MAC__ )
			/* Set the base drive if necessary */
			if( basePath[ 1 ] == ':' )
				{
				if( ( workDrive = *basePath - 'A' ) != startDrive )
					setDrive( workDrive );
				driveSpecOffset = 2;
				}
#endif /* !( __UNIX__ || __MAC__ ) */

			/* Save the directory which the base path will override if
			   necessary.  We have already checked the validity of
			   basePath so we don't need to do it again here */
			if( basePath[ driveSpecOffset ] )
				{
				getCwd( workDir );
				hchdir( currentDir + driveSpecOffset );
				}
			driveSpecOffset = 0;
			}

		/* Process each group of specified file in subdirectories seperately.
		   We need to do things in this somewhat messy manner instead of
		   just passing <path>/<name> to findFirst in case we are asked to
		   do subdirectories as well */
		for( pathInfoPtr = filePathListStart; pathInfoPtr != NULL; \
			 pathInfoPtr = pathInfoPtr->next )
			{
#if !defined( __UNIX__ ) && !defined( __MAC__ )
			/* If there's no base path, go to the drive specified in the
			   file's pathname */
			if( !*basePath )
				{
				/* Go to a different drive if necessary */
				if( pathInfoPtr->drive == ERROR )
					{
					/* If there is no drive specified and we aren't on the
					   default drive, go to the default drive */
					if( workDrive != startDrive )
						{
						workDrive = startDrive;
						setDrive( workDrive );
						}
					}
				else
					if( workDrive != pathInfoPtr->drive )
						{
						/* Go to the specified drive if we aren't already
						   on it */
						workDrive = pathInfoPtr->drive;
						setDrive( workDrive );
						}
				driveSpecOffset = ( pathInfoPtr->drive == ERROR ) ? 0 : 2;
				}
#endif /* !( __UNIX__ || __MAC__ ) */

			processDir( pathInfoPtr->fileNames, pathInfoPtr->filePath + driveSpecOffset );
			}

		/* Go back to the original directory on this drive if necessary.
		   Since we can't have a workDir and drive change within the loop
		   we can safely assume that we are still in the same drive we set
		   at the start of the loop */
		if( *workDir )
			hchdir( workDir );

#if !defined( __UNIX__ ) && !defined( __MAC__ )
		/* Go back to the original drive if necessary */
		if( workDrive != startDrive )
			setDrive( currentDrive );
#endif /* !( __UNIX__ || __MAC__ ) */

		writeArcDir();

		/* Reset error status if necessary */
		if( archiveChanged )
			{
			errorFD = 0;
			oldArcEnd = 0;
			}

		return;
		}

	/* Options which extract/change files in an archive */
	if( choice == DELETE || choice == FRESHEN || choice == REPLACE )
		{
		/* Open a destination archive file.  Note that we can't use tmpnam()
		   since that would open a file in the current directory, which may
		   or may not be the same as the archive directory.  For the same
		   reason we can't make use of a preset directory for storing temporary
		   files (such as /tmp or getenv( "TMP" ) ).  So we open a file of the
		   form "archiveFileName." + TEMP_EXT */
		strcpy( archiveFileName, errorFileName );
		strcpy( errorFileName + strlen( errorFileName ) - 3, TEMP_EXT );
		if( ( workFD = hcreat( errorFileName, CREAT_ATTR ) ) == IO_ERROR )
			error( CANNOT_OPEN_TEMPFILE );
		memcpy( _outBuffer, HPACK_ID, HPACK_ID_SIZE );	/* Put ID at start */
		_outByteCount += HPACK_ID_SIZE;
		errorFD = workFD;
		}

	/* Recreate the directory tree in the archive if necessary */
	if( ( choice == EXTRACT ) && ( flags & STORE_PATH ) )
		makeDirTree();

	/* Flag the fact that we want to overwrite existing files headers rather
	   than add new ones when we call addData() */
	overWriteEntry = TRUE;

	/* Force a read the first time we call getByte() */
	forceRead();

	skipDist = 0L;
	prevPtr = fileHdrCurrPtr = fileHdrStartPtr;
again:
	while( fileHdrCurrPtr != NULL )
		{
		filePath = getPath( fileHdrCurrPtr->data.dirIndex );
		for( pathInfoPtr = filePathListStart; pathInfoPtr != NULL; \
			 pathInfoPtr = pathInfoPtr->next )
			for( fileInfoPtr = pathInfoPtr->fileNames; fileInfoPtr != NULL; \
				 fileInfoPtr = fileInfoPtr->next )
				if( matchString( fileInfoPtr->fileName, fileHdrCurrPtr->fileName ) && \
					( ( flags & RECURSE_SUBDIR ) || \
						!strncmp( pathInfoPtr->filePath, filePath,
							  /* Avoid final '/' on non-root dir */
							  ( fileHdrCurrPtr->data.dirIndex ) ? \
									strlen( filePath ) - 1 : 0 ) ) && \
					( fileHdrCurrPtr->type & TYPE_MASK ) == commentType )
					{
					if( choice == DELETE )
						{
						/* Ask for confirmation if necessary */
						if( flags & INTERACTIVE )
							if( confirmSkip( MESG_DELETE, buildInternalPath( fileHdrCurrPtr ), \
											 FALSE ) )
								goto skipData;

						archiveChanged = TRUE;
						hprintfs( MESG_DELETING_s_FROM_ARCHIVE, \
								  buildInternalPath( fileHdrCurrPtr ) );
						skipDist += fileHdrCurrPtr->data.dataLen + \
									fileHdrCurrPtr->data.auxDataLen;

						/* Remove the header for the skipped file from the
						   header list */
						if( fileHdrCurrPtr == fileHdrStartPtr )
							{
							/* Special case for first header */
							prevPtr = fileHdrCurrPtr = fileHdrStartPtr->next;
							deleteFileHeader( fileHdrStartPtr );
							fileHdrStartPtr = fileHdrCurrPtr;
							goto again;
							}
						else
							{
							prevPtr->next = fileHdrCurrPtr->next;
							deleteFileHeader( fileHdrCurrPtr );
							fileHdrCurrPtr = prevPtr;
							}
						}
					else
						if( choice == FRESHEN || choice == REPLACE )
							{
							/* Make sure the matched file is in the archive,
							   that there is another copy on disk to freshen
							   from, and that it's newer than the one in the
							   archive */
							if( addFileName( fileHdrCurrPtr->data.dirIndex, \
											 fileHdrCurrPtr->type, \
											 fileHdrCurrPtr->fileName, 0 ) == FALSE )
								goto endNestLoop;
							if( !( flags & STORE_PATH ) && !*basePath && \
								*pathInfoPtr->filePath )
								{
								/* Add base path if necessary */
								strcpy( basePath, pathInfoPtr->filePath );
								strcat( basePath, "/" );
								basePathLen = strlen( basePath );
								falseBasePath = TRUE;
								}
							if( !findFirst( ( filePath = buildExternalPath( fileHdrCurrPtr ) ), \
										   ( flags & STORE_ATTR ) ? ALLFILES : FILES, &fileInfo ) )
								{
								findEnd( &fileInfo );
								goto endNestLoop;
								}
							if( ( choice == FRESHEN ) && \
								( fileInfo.fTime <= fileHdrCurrPtr->data.fileTime ) )
								goto endNestLoop;

							/* Ask for confirmation if necessary */
							if( flags & INTERACTIVE )
								if( confirmSkip( ( choice == FRESHEN ) ? MESG_FRESHEN : \
																		 MESG_REPLACE, \
												 filePath, FALSE ) )
									goto endNestLoop;

							archiveChanged = TRUE;

							/* Add the new header data onto the end of list2 */
							if( list2startPtr == NULL )
								/* Set up list2 if it's not already set up */
								list2startPtr = fileHdrCurrPtr;
							else
#pragma warn -def
								list2currPtr->next = fileHdrCurrPtr;
#pragma warn +def
							list2currPtr = fileHdrCurrPtr;

							/* Add the new data to the archive */
							tempFD = archiveFD;
							archiveFD = workFD;
							freshenFD = hopen( filePath, O_RDONLY | S_DENYWR );
							addData( &fileInfo, fileHdrCurrPtr->data.dirIndex, freshenFD );
							hclose( freshenFD );
							archiveFD = tempFD;

							/* Unlink the header for the file to be updated */
							if( fileHdrCurrPtr == fileHdrStartPtr )
								{
								/* Special case for first header */
								prevPtr = fileHdrCurrPtr = fileHdrStartPtr->next;
								fileHdrStartPtr = fileHdrCurrPtr;
								goto again;
								}
							else
								{
								prevPtr->next = fileHdrCurrPtr->next;
								fileHdrCurrPtr = prevPtr;
								}
							}
						else
							{
							if( skipDist )
								{
								skipSeek( archiveFD, skipDist );
								skipDist = 0L;
								}
							retrieveData( fileHdrCurrPtr );
							}

					goto endNestLoop;	/* Make sure we exit the for loop */
					}

endNestLoop:
		/* Reset the false base path if necessary */
		if( falseBasePath )
			{
			*basePath = '\0';
			basePathLen = 0;
			falseBasePath = FALSE;
			}

		/* Check if there was a match for this file */
		if( pathInfoPtr == NULL )
			if( choice == DELETE )
				{
skipData:
				if( skipDist )
					{
					skipSeek( archiveFD, skipDist );
					skipDist = 0L;
					}
				moveData( archiveFD, workFD, fileHdrCurrPtr->data.dataLen + \
											 fileHdrCurrPtr->data.auxDataLen );
				}
			else
				/* Skip this archived file */
				skipDist += fileHdrCurrPtr->data.dataLen + \
							fileHdrCurrPtr->data.auxDataLen;

		/* Step to next node in list */
		prevPtr = fileHdrCurrPtr;
		fileHdrCurrPtr = fileHdrCurrPtr->next;
		}

	/* Handle the archive update commands by moving any remaining data across
	   to the new archive, concatenating the header list for this data onto
	   the end of the one for the new archive, and then calling writeArcDir() */
	if( choice == FRESHEN || choice == REPLACE )
		{
		/* Step through the list of headers copying the data across as we go */
		for( fileHdrCurrPtr = fileHdrStartPtr; fileHdrCurrPtr != NULL; \
			 fileHdrCurrPtr = fileHdrCurrPtr->next )
			{
			hlseek( archiveFD, fileHdrCurrPtr->offset, SEEK_SET );
			moveData( archiveFD, workFD, \
					  fileHdrCurrPtr->data.dataLen + fileHdrCurrPtr->data.auxDataLen );
			}

		/* Concatenate the header list onto the end of the header list for the
		   new archive if there is one */
		if( list2startPtr != NULL )
			{
			list2currPtr->next = fileHdrStartPtr;
			fileHdrStartPtr = list2startPtr;
			}
		}

	/* Perform cleanup for those functions that need it */
	if( choice == DELETE || choice == FRESHEN || choice == REPLACE )
		{
		/* Flush the data buffer */
		flush( workFD );

		/* Delete the old archive and rename the temp file to the archive name */
		hclose( archiveFD );
		archiveFD = workFD;
		writeArcDir();
		hclose( archiveFD );
		hunlink( archiveFileName );
		hrename( errorFileName, archiveFileName );

		/* Flag the fact that we no longer need to attempt any recovery in
		   case of an error */
		errorFD = 0;
		dirFileFD = 0;
		}
	}	/* "Real programmers can write five-page-long do loops
			without difficulty" - _Real_Men_Don't_Program_Pascal_ */

#if !defined( __MSDOS__ ) && !defined( __MAC__ ) && !defined( __IIGS__ )

/* Handle program interrupt */

static void progBreak( int dummyValue )
	{
	dummyValue = dummyValue;	/* Get rid of used but not defined warning */
	error( STOPPED_AT_USER_REQUEST );
	}
#endif /* !( __MSDOS__ || __MAC__ || __IIGS__ ) */

/****************************************************************************
*																			*
*								Main Program Code							*
*																			*
****************************************************************************/

/* The main program */

int main( const int argc, const char *argv[] )
	{
	int no, count = 1, lastSlash;
	FILEINFO archiveInfo;
	char archivePath[ MAX_PATH ], fileCode[ MATCH_DEST_LEN ], ch = DELETE;
	BOOLEAN createNew = FALSE, nothingDone = TRUE, hasFileSpec = FALSE;

	/* Spew forth some propaganda */
	showTitle();

#if !defined( __MSDOS__ ) && !defined( __MAC__ ) && !defined( __IIGS__ )
	/* Trap program break */
	signal( SIGINT, progBreak );
#endif /* !( __MSDOS__ || __MAC__ || __IIGS__ ) */

	/* Perform general initialization */
#if !defined( __UNIX__ ) && !defined( __MAC__ )
	startDrive = getDrive();
#endif /* !( __UNIX__ || __MAC__ ) */
	getCwd( startDir );		/* These must be set before any potential calls
							   to error() */
#ifdef __MSDOS__
	initMem();		/* Init mem.mgr. - must come before all other inits */
#endif /* __MSDOS__ */
	initFastIO();
	setDateFormat();
	getScreenSize();

	/* Only initialise the compressor/decompressor if we have to.
	   Unfortunately we need to initialise the decompressor for the VIEW
	   command since there may be compressed archive comments in the data */
	if( ( argc > 1 ) && ( ch = toupper( *argv[ 1 ] ) ) != DELETE )
		/* Only allocate the memory for the compressor if we have to */
		initPack( ch != EXTRACT && ch != TEST && ch != DISPLAY );

	initArcDir();	/* Must be last init in MSDOS version */

	/* If there are not enough command-line args, exit with a help message */
	if( argc < 3 )
		showHelp();

	/* First process command */
	doCommand( argv[ 1 ] );
	count++;
	doArg( argv, &count );
	createNew = ( choice == ADD && ( flags & OVERWRITE_SRC ) ) ? TRUE : FALSE;
										/* Common subexpr.elimination */

	/* Allow room in path for '.xxx\0' suffix */
	if( strlen( argv[ count ] ) > MAX_PATH - 5 )
		error( PATH_S_TOO_LONG, argv[ count ] );
	else
		strcpy( errorFileName, argv[ count++ ] );

	/* Extract the pathname and convert it into an OS-compatible format */
	lastSlash = extractPath( errorFileName, archivePath );
#ifdef __MSDOS__
	archiveDrive = ( errorFileName[ 1 ] == ':' ) ? *errorFileName - 'A' + 1 : 0;
#endif /* __MSDOS__ */

	/* Either append archive file suffix to the filespec or force the
	   existing suffix to HPAK_MATCH_EXT */
	for( no = lastSlash; errorFileName[ no ] && errorFileName[ no ] != '.'; no++ );
	if( errorFileName[ no ] != '.' )
		strcat( errorFileName, HPAK_MATCH_EXT );
	else
		strcpy( errorFileName + no, HPAK_MATCH_EXT );

	/* Compile the filespec into a form acceptable by the wildcard-matching
	   finite-state machine */
	compileString( errorFileName + lastSlash, fileCode );

	/* Now add names of files to be processed to the fileName list */
	while( count < argc )
		{
		if( *argv[ count ] == '@' )
			{
			/* Assemble the listFile name + path into the dirBuffer (we can't
			   use the mrglBuffer since processListFile() ovrewrites it) */
			strcpy( ( char * ) dirBuffer, argv[ count++ ] + 1 );
			lastSlash = extractPath( ( char * ) dirBuffer, ( char * ) dirBuffer + 80 );
			compileString( ( char * ) dirBuffer + lastSlash, ( char * ) dirBuffer + 80 );
#ifdef __MSDOS__
			if( lastSlash && ( ch = dirBuffer[ lastSlash - 1 ] ) != '/' && \
															  ch != ':' )
#else
			if( lastSlash && ( ch = dirBuffer[ lastSlash - 1 ] ) != '/' )
#endif /* __MSDOS__ */
				/* Add a slash if necessary */
				dirBuffer[ lastSlash - 1 ] = '/';
			strcpy( ( char * ) dirBuffer + lastSlash, MATCH_ALL );

			/* Check each file in the directory, passing those that match to
			   processListFile() */
			if( findFirst( ( char * ) dirBuffer, FILES, &archiveInfo ) )
				{
				do
					{
					strcpy( ( char * ) dirBuffer + lastSlash, archiveInfo.fName );
					if( matchString( ( char * ) dirBuffer + 80, archiveInfo.fName ) )
						processListFile( ( char * ) dirBuffer );
					}
				while( findNext( &archiveInfo ) );
				findEnd( &archiveInfo );
				}
			}
		else
			addFilespec( ( char * ) argv[ count++ ] );
		hasFileSpec = TRUE;
		}

	/* Default is all files if no name is given */
	if( !hasFileSpec )
		addFilespec( "*" );

	/* See if we can find a matching archive.  The only case where a non-
	   match is not an error is if we are using the ADD command:  In this
	   case we create a new archive */
#ifdef __MSDOS__
	if( lastSlash && ( ch = archivePath[ lastSlash - 1 ] ) != '/' && \
														ch != ':' )
#else
	if( lastSlash && ( ch = archivePath[ lastSlash - 1 ] ) != '/' )
#endif /* __MSDOS__ */
		/* Add a slash if necessary */
		archivePath[ lastSlash - 1 ] = '/';
	strcpy( archivePath + lastSlash, MATCH_ARCHIVE );
	if( !findFirst( archivePath, FILES, &archiveInfo ) )
		if( choice == ADD && !hasWildcards( errorFileName + lastSlash, no - lastSlash ) )
			/* No existing archive found, force the creation of a new one */
			createNew = TRUE;
		else
			error( NOTHING_TO_DO );

	/* Set up the encryption system if necessary */
	if( flags & CRYPT )
		initCrypt();

	/* Now process each archive which matches the given filespec */
again:
	do
		if( matchString( fileCode, archiveInfo.fName ) || createNew )
			{
			if( createNew )
				/* Set the extension to the proper form */
				strcpy( errorFileName + no, HPAK_EXT );
			else
				{
				/* Set archivePath as well as errorFileName to the archive's
				   name, since when processing multiple archives errorFileName
				   will be stomped */
				strcpy( archivePath + lastSlash, archiveInfo.fName );
				strcpy( errorFileName, archivePath );
				if( addArchiveName( archiveInfo.fName ) )
					/* Make sure we don't try to process the same archive
					   twice (see the comment for addArchiveName) */
					continue;
				}

			hprintfs( MESG_ARCHIVE_IS_s, errorFileName );

			/* Reset error stats and arcdir system */
			errorFD = 0;
			dirFileFD = 0;
			secFileFD = 0;
			oldArcEnd = 0L;
			resetArcDir();
			overWriteEntry = FALSE;

			/* Open archive file with various types of mungeing depending on the
			   command type */
			if( choice == ADD || choice == UPDATE )
				{
				/* We've found an archive to ADD things to, so signal the
				   fact that we don't need to make a second pass with the
				   createNew flag set */
				nothingDone = FALSE;

				/* Create a new archive if none exists or overwrite an existing
				   one if asked for */
				if( createNew )
					errorFD = archiveFD = hcreat( errorFileName, CREAT_ATTR );
				else
					if( ( archiveFD = hopen( errorFileName, O_RDWR | S_DENYRDWR ) ) != IO_ERROR )
						{
						readArcDir( SAVE_DIR_DATA );

						/* If we are adding to an existing archive and run out
						   of disk space, we must cut back to the size of the
						   old archive.  We do this by remembering the old state
						   of the archive and restoring it to this state if
						   necessary */
						if( fileHdrStartPtr != NULL )
							/* Only set oldArcEnd if there are files in the archive */
							oldArcEnd = fileHdrCurrPtr->offset + fileHdrCurrPtr->data.dataLen + \
										fileHdrCurrPtr->data.auxDataLen;
						getArcdirState( ( FILEHDRLIST ** ) &oldHdrlistEnd, &oldDirEnd );

						/* Move past existing data */
						hlseek( archiveFD, oldArcEnd, SEEK_SET );
						}
				}
			else
				{
				/* Try to open the archive for read/write (in case we need to
				   truncate X/Ymodem padding bytes.  If that fails, open it
				   for read-only */
				if( ( archiveFD = hopen( errorFileName, O_RDWR | S_DENYWR ) ) == IO_ERROR )
					archiveFD = hopen( errorFileName, O_RDONLY | S_DENYWR );
				if( archiveFD != IO_ERROR )
					readArcDir( choice != VIEW && choice != EXTRACT && \
								choice != TEST && choice != DISPLAY  );
				}

			/* Make sure the open was successful */
			if( archiveFD == IO_ERROR )
				error( CANNOT_OPEN_ARCHFILE, errorFileName );

			/* Now munge files to/from archive */
			handleArchive();

			/* The UPDATE command is just a combination of the ADD and FRESHEN
			   commands.  We handle it by first adding new files in one pass
			   (but not complaining when we strike duplicates like ADD does),
			   and then using the freshen command to update duplicates in a
			   second pass.  This leads to a slight problem in that when files
			   are added they will then subsequently match on the freshen pass;
			   hopefully the extra overhead from checking whether they should
			   be freshened will not be too great */
			if( choice == UPDATE )
				{
				choice = FRESHEN;
				oldArcEnd = 0L;	/* Make sure we don't try any ADD-style recovery
								   since errorFD is now the temp file FD */
				hlseek( archiveFD, 0L, SEEK_SET );	/* Go back to start of archive */
				handleArchive();
				}

			/* Perform cleanup functions for this file */
			if( choice != DELETE && choice != FRESHEN && choice != REPLACE )
				/* If DELETE, FRESHEN, or REPLACE, archive file is already closed */
				hclose( archiveFD );

#ifdef __MSDOS__
			/* Reset arcDir filesystem in memory */
			resetArcDirMem();
#endif /* __MSDOS__ */

			/* Only go through the loop once if we are creating a new archive */
			if( createNew )
				break;
			}
	while( findNext( &archiveInfo ) );

	/* There were no files found to ADD to, so we execute the above loop one
	   more time and create a new archive */
	if( choice == ADD && nothingDone )
		{
		createNew = TRUE;
		goto again;
		}

	/* Finish findFirst() functions */
	findEnd( &archiveInfo );

	/* Complain if we didn't end up doing anything */
	if( !archiveChanged )
		error( NOTHING_TO_DO );

	/* Clean up before exiting */
	if( choice == VIEW )
		showTotals();
	if( flags & CRYPT )
		endCrypt();
#ifdef __MSDOS__
	endMem();		/* The mem.mgr.takes care of all memory freeing */
#else
	if( choice != DELETE )
		endPack();
	endArcDir();
	endFastIO();
	freeFilespecs();
	freeArchiveNames();
#endif /* __MSDOS__ */
	
	/* Obesa Cantavit */
	hputs( MESG_DONE );
	return( OK );
	}
