/****************************************************************************
*                                                                           *
*                          HPACK Multi-System Archiver                 		*
*                          ===========================                      *
*                                                                           *
*                 High-Speed Data Movement Routines Header File             *
*							STORE.H   Updated 17/07/91						*
*                                                                           *
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*                                                                           *
* 		Copyright 1989 - 1991  Peter C.Gutmann.  All rights reserved       	*
*                                                                           *
****************************************************************************/

#ifndef _STORE_DEFINED

#define _STORE_DEFINED		/* Flag the fact that we've been included */

/* Prototypes for functions in STORE.C */

LONG store( BOOLEAN *isText, const FD inFD, const FD outFD );
BOOLEAN unstore( const FD inFD, const FD outFD, long noBytes );
void moveData( const FD inFD, const FD outFD, long noBytes );

#endif /* !_STORE_DEFINED */
