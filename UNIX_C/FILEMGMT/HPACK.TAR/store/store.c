/****************************************************************************
*                                                                           *
*                          HPACK Multi-System Archiver                 		*
*                          ===========================                      *
*                                                                           *
*                       High-Speed Data Movement Routines                   *
*							STORE.C  Updated 12/07/91						*
*                                                                           *
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*                                                                           *
* 		Copyright 1989 - 1991  Peter C.Gutmann.  All rights reserved       	*
*                                                                           *
****************************************************************************/

#include <ctype.h>
#include <string.h>
#include "defs.h"
#ifdef SYSV
  #include "../error.h"
  #include "../hpacklib.h"
  #include "../crc/crc16.h"
  #include "../io/fastio.h"
  #include "../io/hpackio.h"
  #include "../store/store.h"
#else
  #include "error.h"
  #include "hpacklib.h"
  #include "crc/crc16.h"
  #include "io/fastio.h"
  #include "io/hpackio.h"
  #include "store/store.h"
#endif /* SYSV */

/****************************************************************************
*																			*
*					Store Data in an Archive without Compression			*
*																			*
****************************************************************************/

/* Store data in an archive with no compression.  This routine must take
   care to correctly handle any data already in the buffer, unlike
   unstore() which assumes the buffer is empty when first called */

LONG store( BOOLEAN *isText, const FD _inFD, const FD destFD )
	{
	LONG byteCount;
	int bytesRead, bytesToRead = _BUFSIZE - _outByteCount, printCount;
	int sampleCount = 0, textByteCount = 0;
	BOOLEAN moreToDo = TRUE;
	BYTE ch;

	crc16 = 0;

	/* Read as much as we can into the remaining buffer space */
	byteCount = bytesRead = hread( _inFD, _outBuffer + _outByteCount, bytesToRead );

	/* Update CRC for the data read */
	crc16buffer( _outBuffer + _outByteCount, bytesRead );

	/* See if the file is text or binary */
	while( sampleCount < 50 && sampleCount <= bytesRead )
		{
		if( isprint( ch = _outBuffer[ _outByteCount + sampleCount ] ) || \
					 ch == '\r' || ch == '\n' || ch == '\t' )
			textByteCount++;
		sampleCount++;		/* isprint() has side effects - eek! */
		}

	if( _outByteCount + bytesRead == _BUFSIZE )
		{
		/* We've filled the buffer, so flush it */
		writeBuffer( destFD, _BUFSIZE );

		/* Check for special case of file size being exactly what we've just
		   read in */
		if( bytesRead == 0 )
			moreToDo = FALSE;
		}
	else
		{
		/* There's still room for more in the buffer */
		_outByteCount += bytesRead;
		moreToDo = FALSE;
		}

	/* Print a dit if necessary */
	printCount = bytesRead;
	while( printCount >= 4096 )
		{
		hputchars( 'O' );
		hflush( stdout );
		printCount -= 4096;
		}

	if( moreToDo )
		{
		/* Move the rest of the data a bufferful at a time */
		while( TRUE )
			{
			bytesRead = hread( _inFD, _outBuffer, _BUFSIZE );
			crc16buffer( _outBuffer, bytesRead );
			if( bytesRead == _BUFSIZE )
				/* We've filled the buffer, so flush it */
				writeBuffer( destFD, _BUFSIZE );
			byteCount += bytesRead;

			/* Finish the isText evaluation if necessary */
			while( sampleCount < 50 && sampleCount <= bytesRead )
				{
				if( isprint( ch = _outBuffer[ bytesRead + sampleCount ] ) || \
							 ch == '\r' || ch == '\n' || ch == '\t' )
					textByteCount++;
				sampleCount++;		/* isprint() has side effects - eek! */
				}

			/* Print a dit if necessary */
			printCount += bytesRead;
			while( printCount >= 4096 )
				{
				hputchars( 'O' );
				hflush( stdout );
				printCount -= 4096;
				}

			if( bytesRead < _BUFSIZE )
				break;
			}

		/* Make sure the I/O system knows there's still data in the buffer */
		if( bytesRead != _BUFSIZE )
			_outByteCount = bytesRead;
		}

	fputWord( destFD, crc16 );

	/* If at least 95% of the file's chars are text, we assume it's text.
	   This test uses absolute values rather than percentages since for
	   files smaller than 50 bytes it may be hard to reliably determine
	   whether it is text or not */
	*isText = ( textByteCount > 47 ) ? TRUE : FALSE;

	return( byteCount + sizeof( WORD ) );
	}

/****************************************************************************
*																			*
*					Unstore Uncompressed Data from an Archive				*
*																			*
****************************************************************************/

/* Retrieve uncompressed data from an archive.  In order to handle the stream
   buffering we can't just read data into the _outBuffer, but have to read it
   into the _inBuffer, copy it to the _outBuffer, and then write the
   _outBuffer */

BOOLEAN unstore( const FD srcFD, const FD destFD, long noBytes )
	{
	int bytesToProcess = _BUFSIZE - _inByteCount, printCount;
	WORD checkSum;

	crc16 = 0;

	noBytes -= sizeof( WORD );	/* Don't move the checksum at the end */
	_outByteCount = 0;
	if( bytesToProcess )
		{
		/* Don't move more data than necessary */
		if( bytesToProcess > noBytes )
			bytesToProcess = ( int ) noBytes;

		/* Write out any data still in the buffer */
		memcpy( _outBuffer, _inBuffer + _inByteCount, bytesToProcess );
		writeBuffer( destFD, bytesToProcess);
		noBytes -= bytesToProcess;
		_inByteCount += bytesToProcess;

		/* Update CRC for data in buffer */
		crc16buffer( _outBuffer, bytesToProcess );
		}

	/* Print a dit if necessary */
	printCount = bytesToProcess;
	while( printCount >= 4096 )
		{
		hputchars( 'O' );
		hflush( stdout );
		printCount -= 4096;
		}

	while( noBytes )
		{
		_inBytesRead = hread( srcFD, _inBuffer, _BUFSIZE );
		bytesToProcess = ( noBytes < _inBytesRead ) ? \
						 ( int ) noBytes : _inBytesRead;
		memcpy( _outBuffer, _inBuffer, bytesToProcess );
		writeBuffer( destFD, bytesToProcess);
		noBytes -= bytesToProcess;
		_inByteCount = bytesToProcess;

		/* Update CRC for data in buffer */
		crc16buffer( _outBuffer, bytesToProcess );

		/* Print a dit if necessary */
		printCount += bytesToProcess;
		while( printCount >= 4096 )
			{
			hputchars( 'O' );
			hflush( stdout );
			printCount -= 4096;
			}
		}

	checkSum = fgetWord( srcFD );
	return( crc16 == checkSum );
	}

/****************************************************************************
*																			*
*						High-speed Data Move Routine						*
*																			*
****************************************************************************/

/* Move data from one file to another without doing a CRC check.  This
   routine must take care to correctly handle any data already in the buffer */

void moveData( const FD _inFD, const FD destFD, long noBytes )
	{
	int bytesRead, bytesToRead = _BUFSIZE - _outByteCount;

	/* Read as much as we can into the remaining buffer space */
	bytesRead = hread( _inFD, _outBuffer + _outByteCount, ( ( int ) noBytes < bytesToRead ) ? \
														( int ) noBytes : bytesToRead );

	if( _outByteCount + bytesRead == _BUFSIZE )
		{
		/* We've filled the buffer, so flush it */
		writeBuffer( destFD, _BUFSIZE );
		noBytes -= bytesRead;
		}
	else
		{
		/* There's still room for more in the buffer */
		_outByteCount += bytesRead;
		noBytes = 0L;
		}

	/* Now blast the data through the buffer */
	while( noBytes )
		{
		bytesToRead = ( ( int ) noBytes < _BUFSIZE ) ? ( int ) noBytes : _BUFSIZE;
		_outByteCount = hread( _inFD, _outBuffer, bytesToRead );
		if( _outByteCount == _BUFSIZE )
			/* We've filled the buffer, so flush it */
			writeBuffer( destFD, bytesToRead );
		noBytes -= bytesToRead;
		}
	}
