/****************************************************************************
*																			*
*							HPACK Multi-System Archiver						*
*							===========================						*
*																			*
*				Header File for the Directory Handling Routines				*
*							ARCDIR.H  Updated 10/10/91						*
*																			*
*   This program is protected by copyright and as such if you use or copy	*
*   this code for your own purposes directly or indirectly your soul will	*
*   become the property of the author with the right to dispose of it as	*
* 									he wishes.								*
*																			*
*		Copyright 1989 - 1991  Peter C.Gutmann.  All rights reserved		*
*																			*
****************************************************************************/

#ifndef _ARCDIR_DEFINED

#define _ARCDIR_DEFINED

#ifdef SYSV
  #include "../filehdr.h"
  #include "../io/hpackio.h"
#else
  #include "filehdr.h"
  #include "io/hpackio.h"
#endif /* SYSV */

/* The size of a directory header as written to disk.  This must be defined
   in terms of its constituent fields since some compilers will pad the
   struct fields out for alignment reasons */

#define DIRHDRSIZE	( sizeof( LONG ) + sizeof( WORD ) + sizeof( WORD ) )

/* The data structure for the list of file headers */

typedef struct FH {
				  struct FH *next;		/* The next header in the list */
				  struct FH *nextFile;	/* Next file in this directory */
				  struct FH *prevFile;	/* Prev file in this directory */
				  FILEHDR data;			/* The file data itself */
				  char *fileName;		/* The filename */
				  LONG offset;			/* Offset of data from start of archive */
				  WORD type;			/* The type of the file */
				  } FILEHDRLIST;

/* The data structures for the list of directories */

typedef struct DH {
				  WORD dirIndex;		/* The index of this directory */
				  WORD next;			/* The next header in the list */
/*				  struct DH *next;		// The next header in the list */
				  struct DH *nextDir;	/* Next dir in this directory */
				  struct DH *prevDir;	/* Prev dir in this directory */
				  DIRHDR data;			/* The directory data */
				  char *dirName;		/* The directory name */
				  LONG offset;			/* Offset of data from start of dir
										   directory data area */
				  FILEHDRLIST *fileInDirListHead;	/* Start of the list of
										   files in this directory */
				  FILEHDRLIST *fileInDirListTail;	/* End of the list of
										   files in this directory */
				  struct DH *dirInDirListHead;		/* Start of the list of
										   dirs in this directory */
				  struct DH *dirInDirListTail;		/* End of the list of
										   dirs in this directory */
				  } DIRHDRLIST;

/* The data structure for the list of archive parts for a multi-part archive */

typedef struct PL {
				  struct PL *next;		/* The next header in the list */
				  long size;			/* Size of this archive section */
				  } PARTSIZELIST;

/* The end marker for various lists */

#define END_MARKER		0xFFFF

/* The directory index number for the root directory */

#define ROOT_DIR		0

/* The types of path match which matchPath() can return */

enum { PATH_NOMATCH, PATH_PARTIALMATCH, PATH_FULLMATCH };

/* Whether we want readArcDir() to save the directory data to a temporary
   file (this is necessary since it will be overwritten during an ADD) */

#define SAVE_DIR_DATA	TRUE

/* The magic ID and temporary name extensions for HPACK archives */

extern char HPACK_ID[];

#define HPACK_ID_SIZE	4			/* 'HPAK' */

extern char TEMP_EXT[], DIRTEMP_EXT[], SECTEMP_EXT[];

/* Bit masks for the fileKludge in the archive trailer */

#define SPECIAL_MULTIPART	0x01	/* Multipart archive */
#define SPECIAL_MULTIEND	0x02	/* Last part of multipart archive */
#define SPECIAL_SECURED		0x04	/* Secured archive */
#define SPECIAL_ENCRYPTED	0x08	/* Encrypted archive */

/* Some global vars, defined in ARCDIR.C */

extern FILEHDRLIST *fileHdrCurrPtr, *fileHdrStartPtr;
extern int currEntry, currPart, lastPart;

/* Prototypes for functions in ARCDIR.C */

void initArcDir( void );
void endArcDir( void );
void resetArcDir( void );
#ifdef __MSDOS__
  void resetArcDirMem( void );
#endif /* __MSDOS__ */
void readArcDir( const BOOLEAN doSaveDirData );
void writeArcDir( void );
void addFileHeader( FILEHDR *theHeader, WORD type );
void deleteFileHeader( FILEHDRLIST *theHeader );
int writeFileHeader( FILEHDR *theHeader, const WORD type );
BOOLEAN addFileName( const WORD dirIndex, const WORD type, const char *fileName, const FD inFD );
void deleteLastFileName( void );
void addDirName( char *dirName, const LONG dirTime );
void addDirData( const WORD tagID, WORD tagLength );
void movetoDirData( void );
void setArchiveCwd( const WORD dirIndex );
void popDir( void );
WORD getParent( const WORD dirIndex );
void sortFiles( const WORD dirIndex );
FILEHDRLIST *getFirstFileEntry( const WORD dirIndex );
FILEHDRLIST *getNextFileEntry( void );
DIRHDRLIST *getFirstDirEntry( const WORD dirIndex );
DIRHDRLIST *getNextDirEntry( void );
WORD getFirstDir( void );
WORD getNextDir( void );
int matchPath( const char *filePath, const int pathLen, WORD *dirIndex );
char *getDirName( const WORD dirIndex );
LONG getDirTime( const WORD dirIndex );
void setDirTime( const WORD dirIndex, const LONG time );
WORD getDirAuxDatalen( const WORD dirIndex );
void getArcdirState( FILEHDRLIST **hdrListEnd, int *dirListEnd );
void setArcdirState( FILEHDRLIST *hdrListEnd, const int dirListEnd );
int computeHeaderSize( const FILEHDR *theHeader );
void addPartSize( const long partSize );
int getPartNumber( const long offset );
void getPart( const int thePart );

#endif
