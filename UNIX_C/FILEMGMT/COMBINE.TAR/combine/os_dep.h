/*
 * The combine utility is a product of Harris, Inc. and is provided for
 * unrestricted use provided that this legend is included on all tape
 * media and as a part of the software program in whole or part.  Users
 * may copy, modify, license or distribute the combine utility without charge.
 * 
 * THE COMBINE UTILITY IS PROVIDED AS IS WITH NO WARRANTIES OF ANY KIND
 * INCLUDING THE WARRANTIES OF DESIGN, MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE, OR ARISING FROM A COURSE OF DEALING, USAGE OR TRADE
 * PRACTICE.
 * 
 * The combine utility is provided with no support and without any obligation
 * on the part of Harris, Inc. to assist in its use, correction,
 * modification or enhancement.
 * 
 * HARRIS, INC. SHALL HAVE NO LIABILITY WITH RESPECT TO THE
 * INFRINGEMENT OF COPYRIGHTS, TRADE SECRETS OR ANY PATENTS BY THE COMBINE
 * UTILITY OR ANY PART THEREOF.
 * 
 * In no event will Harris, Inc. be liable for any lost revenue
 * or profits or other special, indirect and consequential damages, even if
 * Harris has been advised of the possibility of such damages.
 * 
 * Harris Computer Systems Division
 * 2101 W Cypress Creek Rd
 * Fort Lauderdale, Florida 33309
 */
#define STS_type int
#define rfa_type int

#define SZ$_FILE_NAME 256
#ifdef VOS	/* 24-bit word */
#define HI7       077400000	/* Hi 7 bits of a word */
#else		/* 32-bit word */
#define HI7       0xFE000000	/* Hi 7 bits of a word */
#endif

#define SS_NORMAL                 1
#define SS_READ_ERR               2
#define SS_WRITE_ERR              3
#define SS_EOT                    4
#define SS_SEEK_ERR		  5

extern  STS_type os_dep_file_seek ();
extern  rfa_type os_dep_file_pos ();
extern int      os_dep_file_open ();
extern  STS_type os_dep_file_close ();
extern  STS_type os_dep_file_write ();
extern  STS_type os_dep_file_read ();
