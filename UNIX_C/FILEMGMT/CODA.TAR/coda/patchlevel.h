/*
**  Copyright 1989 BBN Systems and Technologies Corporation.
**  All Rights Reserved.
**  It is free software, and may be distributed under the terms of the
**  GNU Public License; see the file COPYING for more details.
**
**  Misteak recorder.
**  $Log:	patchlevel.h,v $
**  Revision 2.0  90/03/23  14:41:53  rsalz
**  Baseline for Usenet release.
**  
*/
#define PATCHLEVEL	0
