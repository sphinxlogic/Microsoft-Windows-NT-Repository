/*
**  Copyright 1989 BBN Systems and Technologies Corporation.
**  All Rights Reserved.
**  This is free software, and may be distributed under the terms of the
**  GNU Public License; see the file COPYING for more details.
**
**  Print copyright and version.
*/
#include <stdio.h>
#include "patchlevel.h"

#define LINE1	\
    "Copyright 1989 BBN Systems and Technologies Corporation."
#define LINE2	\
    "All Rights Reserved."
#define LINE3	\
    "This is free software, and may be distributed under the terms of the"
#define LINE4	\
    "GNU Public License; see the file COPYING for more details."

/*
**  Sigh, I wish I didn't have to do this stuff -- both the copyright,
**  and having to crack the RCS string are a pain in the neck.
*/
Copyright()
{
    static char	REVISION[] = "$Revision: 2.0 $";
    char	buff[sizeof REVISION + 2];
    char	*p;
    char	*q;

    /* Skip to the first space. */
    for (p = REVISION; *p && *p != ' '; p++)
	;

    /* If we found it, take everything up to the next space. */
    if (*p) {
	for (q = buff, p++; *p && *p != ' '; )
	    *q++ = *p++;
	*q = '\0';
    }
    else {
	buff[0] = '?';
	buff[1] = '\0';
    }

    (void)printf("This is CODA, Version %s.%d.\n", buff, PATCHLEVEL);
    (void)printf("%s\n%s\n%s\n%s\n", LINE1, LINE2, LINE3, LINE4);
}
