/*
**
** Patchlevel for VTREE
**
*/

#define PATCHLEVEL 	V1.2
#define	VERSION		"VTREE	1.2	9/17/88"
