/* ::[[ @(#) addbfcrc.c 1.10 89/07/08 10:34:48 ]]:: */
/* Adapted from zmodem source code, which contained Gary Brown's code */

#ifndef LINT
static char sccsid[]="::[[ @(#) addbfcrc.c 1.10 89/07/08 10:34:48 ]]::";
#endif

typedef unsigned long tcrc;      /* type of crc value -- same as in brik.c */
extern tcrc crccode;             /* holds all crc values */
extern tcrc crctab[];            /* the crc calculation table */

void addbfcrc (buf, size)
register char *buf;
register int size;
{
   int i;
   for (i = 0;  i < size;  i ++) {
      crccode = crctab[(int) ((crccode) ^ (buf[i])) & 0xff] ^
         (((crccode) >> 8) & 0x00FFFFFFL);
   }
}
