/*
 * $Header$
 *
 * trimlog.h - definitions for "trimlog"
 *
 * David A. Curry
 * Research Institute for Advanced Computer Science
 * Mail Stop 230-5
 * NASA Ames Research Center
 * Moffett Field, CA 94035
 * davy@riacs.edu
 *
 * $Log$
 */
#ifndef CONFIGFILE
#define CONFIGFILE	"trimlog.conf"		/* configuration file	*/
#endif

#define BIGBUFSIZE	8192			/* large buffer for i/o	*/

#define TRUNCATE	1			/* truncate to n bytes	*/
#define TRIMBYLINES	2			/* trim to n lines	*/
#define TRIMBYBYTES	3			/* trim to n bytes	*/

/*
 * A command read from the configuration file.
 */
typedef struct _TrimCommand {
	char	t_mode;				/* command to use	*/
	char	*t_filename;			/* file to do it to	*/
	int	t_parameter;			/* numeric cmd argument	*/
	struct	_TrimCommand *t_next;		/* ptr to next command	*/
} TrimCommand;
