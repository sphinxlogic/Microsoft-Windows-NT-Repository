/*	$Id: patchlevel.h,v 1.1 89/11/20 00:06:30 berliner Exp $	*/

#define	PATCHLEVEL	0
