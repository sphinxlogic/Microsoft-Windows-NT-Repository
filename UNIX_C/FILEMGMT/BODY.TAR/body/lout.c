#include <stdio.h>
#include "body.h"

char *fgets();

lskip(start,fd)
int start;
FILE * fd;
{
    char s[LINMAX];
    int i;
    (void) fseek(fd, 0L, 0);
    i = 0;
    while (i < start - 1) {
        if(fgets(s,LINMAX,fd) == NULL) return(0);
	i++;
    }
    return(1);
}

lprint(number,fd)
int number;
FILE * fd;
{
    int i;
    char s[LINMAX];
    if (number == DE_LAST) {	/* Print to end of file */
        while (fgets(s,LINMAX,fd) != NULL)
	    (void) fputs(s,stdout);
    } else {
	for (i = 0; i < number; i++) { /* Print n lines */
	    if (fgets(s,LINMAX,fd) == NULL) return(1);
	    (void) fputs(s,stdout);
	}
    }
}
