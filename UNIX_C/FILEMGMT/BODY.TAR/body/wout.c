#include <stdio.h>
#include <ctype.h>
#include "body.h"

wskip(start,fd)
int start;
FILE * fd;
{
    int i;
    int flag;
    int c;
    flag = IN_FIRS;	/* In 'white space' to begin with */
    i = 0;
    (void) fseek(fd, 0L, 0);
    if (start == 1) return(1);	/* Already at begining */
    while ((c = getc(fd)) != EOF) {
	switch (flag) {
	    case IN_FIRS:
	        if (isspace(c))
		    flag = IN_WHIT;
		else {
		    flag = IN_WORD;
		}
		break;
	    case IN_WHIT:
	         if (!isspace(c)) {
		     flag = IN_WORD;
		 }
		 break;
	    case IN_WORD:
	        if (isspace(c)) {
		    flag = IN_WHIT;
		    if (++i == (start - 1)) return(1);
		}
		break;
	}
    }
    return ((c == EOF) ? 0 : 1);
}

wprint(number,fd)
int number;
FILE * fd;
{
    int i;
    int c;
    int flag;
    if (number == DE_LAST) {	/* Print to end of file */
	while ((c = getc(fd)) != EOF)
	    (void) fputc(c,stdout);
    } else {
	i = 0;
	flag = IN_FIRS;
    while ((c = getc(fd)) != EOF) {
	if (c != EOF) (void) fputc(c,stdout);
	switch (flag) {
	    case IN_FIRS:
	        flag = isspace(c) ? IN_WHIT : IN_WORD;
		break;
	    case IN_WHIT:
	         if (!isspace(c)) flag = IN_WORD;
		 break;
	    case IN_WORD:
	        if (isspace(c)) {
		    flag = IN_WHIT;
		    if (++i == number) return(1);
		}
		break;
	}
    }
    }
    return(1);
}
