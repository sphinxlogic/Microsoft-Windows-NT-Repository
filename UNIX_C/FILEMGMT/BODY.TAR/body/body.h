/*
 * Global definitions for body
 */

#define IFDEBUG(x) if ((debug&(x)) == x)
#define D_ARGS	0x01
#define D_LIST  0x02
#define D_PFILE 0x04

#define L_FLAG  0x04
#define W_FLAG  0x02
#define C_FLAG  0x01

#define DE_FIRST  1
#define DE_LAST  -1
#define DE_NUMB  10
#define DE_FILE  (char *) 0

#define LINMAX 1024

#define IN_WHIT 0
#define IN_WORD 1
#define IN_FIRS 2
