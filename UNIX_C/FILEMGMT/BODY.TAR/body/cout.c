#include <stdio.h>
#include "body.h"

cskip(start,fd)
int start;
FILE * fd;
{
    return (fseek(fd,(long) (start-1), 0) == 0 ? 1 : 0);
}

cprint(number,fd)
int number;
FILE * fd;
{
    int i;
    int c;
    if (number == DE_LAST) {	/* Print to end of file */
	while ((c = getc(fd)) != EOF)
	    (void) fputc(c,stdout);
    } else {
    for (i = 0; i < number; i++) { /* Print n characters */
        if ((c = getc(fd)) == EOF) return(1);
	(void) fputc(c,stdout);
    }
    }
    return(1);
}
