/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*
 * $Header: vl.h[3.3] Thu Feb 23 18:14:45 1989 axel@coma published $
 *
 * Log for /u/shape/dist-tape/src/vc/vl.h[3.1]
 * 	Thu Feb 23 18:14:45 1989 axel@coma published $
 *  --- empty log message ---
 *  vl.h[3.2] Thu Feb 23 18:14:45 1989 axel@coma published $
 *  --- empty log message ---
 *  vl.h[3.3] Thu Feb 23 18:14:45 1989 axel@coma published $
 *  --- empty log message ---
 */


#include "afsapp.h"

#define VL_O_LONGOUTPUT		01L
#define VL_O_GROUPOUTPUT	02L
#define VL_O_VERSIONSTATE	04L
#define VL_O_LISTUDA		010L
#define VL_O_LISTUDALONG 	020L
#define VL_O_UDAGIVEN		040L
#define VL_O_VERSIONNUM		0100L
#define VL_O_STATEGIVEN		0200L
#define VL_O_BEQUIET		0400L
#define VL_O_LOGMSG		01000L
#define VL_O_HISTLOG		02000L
#define VL_O_HISTLOGPLUS	04000L
#define VL_O_ALL		010000L
#define VL_O_AUTHOR		020000L
#define VL_O_OWNER		040000L
#define VL_O_LISTHIDDENUDAS	0100000L
#define VL_O_LISTHIDDEN         0200000L
#define VL_O_LISTBINARY         0400000L
#define VL_O_LASTVERS           01000000L
#define NO_ID -1

/*
 * external definition from everywhere
 */
extern char *malloc();

/*
 * external definitions from vlopt.c
 */
extern int IsOptionSet ();
extern int IsOptionCleared ();
extern int SetOption ();
extern int ClearOption ();
extern int Usage ();
extern int LongUsage ();
extern int multicol_output_is_possible ();

/*
 * External definitions from vlmisc.c
 */
extern char *GetVersionState();
extern char *GetVersionId();
extern int VinfoCleanup();
extern char *GetMode();
extern char *GetUserInfo();
extern char *GetDate();
extern int HasPathName();
extern int HasExtension();
extern int IsDirectory();
extern int FileExists();
extern int CopyUdattrs();
extern int GetGenerationNumber();
extern int GetRevisionNumber();
extern int PutProgramName();
extern char *GetProgramName();
extern void PutVersionStates();
extern char *GetVersionStates();
extern void PutUdattrs();
extern char **GetUdattrs();
extern void PutVersionNumber();
extern char *GetVersionNumber();
extern void ScanVersionStates();
extern int MatchesVersionStates();
extern void PutAuthorIdentifications();
extern char *GetAuthoridFromAuthor();
extern void PutOnwerIdentifications();
extern char *GetOwneridFromOwner();
/*
 * External definitions from vldovl.c
 */
extern int ReportVersionInfo();
extern void FlushInfo();

