/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: mkattr.c[3.6] Thu Feb 23 18:13:34 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/mkattr.c[3.2]
 * 	Thu Feb 23 18:13:34 1989 axel@coma published $
 *  --- empty log message ---
 *  mkattr.c[3.5] Thu Feb 23 18:13:34 1989 axel@coma published $
 *  --- empty log message ---
 *  mkattr.c[3.6] Thu Feb 23 18:13:34 1989 axel@coma published $
 *  --- empty log message ---
 */

/*LINTLIBRARY*/

#include <strings.h>
#include "afs.h"
#include "retrv.h"

#ifdef lint
char *st_table[] = {
  "This is a fake definition. The real thing is in libutil (see 'misc')."
  };
#else
extern char *st_table[];
#endif lint

mkvno (vstring) char *vstring; {
  /*
   *  converts a string of the form 'gen.rev' (e.g. 12.23) into an
   *  integer value with the generation part stored in the hiword
   *  and the revision part in the loword. In case 'vstring'
   *  is a symbolic version name, which is assumed if the 'gen.rev'
   *  pattern does not match, a value of zero is returned (0.0 = no vers).
   */
  char *emsg, *re_comp();
  int genno, revno, rc;

  if (emsg = re_comp("[0-9][0-9]*\\.[0-9][0-9]*")) { /* quite liberal RE */
    logerr (emsg);
    return 0;
  }
  if (fail((rc=re_exec (vstring)))) {
    logerr ("internal error in matching RE (mkvno)");
  }
  if (rc) {
    (void)sscanf (vstring, "%d.%d", &genno, &revno);
    return (genno << 16) | (0x0000FFFF & revno);

  }
  else return 0;
}

BoundVersion (rawname, cookedname, vstring) 
     char *rawname, *cookedname, *vstring; {
/*
 *  This function returns nonzero if 'rawname' is of the form
 *  'foo[1.4]'. In this case 'foo' will be written into 'cookedname'
 *  and 'vstring' will become '1.4'. Otherwise, both are left unchanged
 *  and the funtion returns zero.
 */
       char *b1, *b2;
       int vno;

       if ((b1=rindex (rawname, '[')) && (b2 = rindex (rawname, ']'))
	   && (b1 < b2)) {
	 *b1 = *b2 = '\0'; /* make 'em separate strings */
	 if (mkvno (b1+1)) {
	   (void)strcpy (cookedname, rawname);
	   (void)strcpy (vstring, b1+1);
	   *b1 = '['; *b2 = ']';
	   return TRUE;
	 }
	 else {
	   if (vno=Symn2Vno (rawname, b1+1)) {
	     (void)sprintf (vstring, "%d.%d", gen(vno), rev(vno));
	     (void)strcpy (cookedname, rawname);
	     *b1 = '['; *b2 = ']';
	     return TRUE;
	   }
	   *b1 = '['; *b2 = ']';
	 }
       }
       return FALSE;
     }
       
mkgenno (gstring) char *gstring; {
  int genno;

  genno = atoi (gstring);
  if (genno < 0)
    return 0;
  else 
    return (genno < 1000) ? genno : 0;
}

int Symn2Vno (fname, sym) char *fname, *sym; {
  Af_attrs warrant;
  Af_set   hits;
  Af_key   key;
  char symname[256], messg[80], *p;
  int rc, vnum;

  af_initattrs (&warrant);
  (void)sprintf (symname, "%s=%s", SYMNAME, sym);
  warrant.af_udattrs[0] = symname;
  warrant.af_udattrs[1] = (char *)NULL;
  (void)strcpy (warrant.af_syspath, p=af_afpath(fname)); free (p);
  (void)strcpy (warrant.af_name, p=af_afname(fname)); free (p);
  (void)strcpy (warrant.af_type, p=af_aftype(fname)); free (p);
  if ((rc=af_find (&warrant, &hits)) > 1) { 
    /* this shouldn't happen, as symbolic names are supposed to be */
    /* within one ASO's history */
    af_dropset (&hits);
    (void)sprintf (messg, 
     "%s's history inconsistent.\nSymbolic name \"%s\" multiply assigned.",
	     fname, sym);
    logerr (messg);
    return FALSE;
  }
  else if (rc < 0) {
    af_perror ("af_find (in SymnameInUse)");
    return FALSE;
  }
  else if (rc == 0) {
    af_dropset (&hits);
    return FALSE;
  }
  else { /* rc must be 1 -- thats just fine */
    af_setgkey (&hits, 0, &key);
    af_dropset (&hits);
    vnum = ((af_rgen (&key) << 16) | (0x0000FFFF & af_rrev (&key)));
    return vnum;
  }
}

  
mkstate (sstring) char *sstring; {
  int i;
  register char *cp;

  cp = sstring;
  while (*cp ? (*cp++ |= ' ') : 0); /* convert to lowercase */
  for (i = AF_BUSY; i <= AF_FROZEN; i++)
    if (!strcmp (st_table[i], sstring))
      return i;
  return -1;
}

#define BOTIME 70        /* Beginning Of TIME for Unix */
#define DINYEAR 365      /* No. of days in a non-leapyear */
#define DINMONTH 31      /* No. of days in a 'canonical' month */
#define SINDAY 86400     /* No. of seconds in a day (24 * 60 * 60) */
#define SINHR 3600       /* No. of seconds in an hour */
#define SINMIN 60        /* ... guess! ... */

time_t mktime (tstring) char *tstring; {
  /*
   *  converts a YY/MM/DD[/HH:MM] string into a system time representation
   *  which by convention is the number of seconds since Jan. 1st 1970.
   */
  char *emsg, *re_comp();
  int yr, mo, dy, hr = 0, mint = 0, nfyrs, ndays, nsecs;

  if (emsg = re_comp((strlen (tstring) > 8) ? 
		     "[0-9][0-9]/[01][0-9]/[0-3][0-9]/[0-5][0-9]:[0-5][0-9]" :
		     "[0-9][0-9]/[01][0-9]/[0-3][0-9]")) {
    logerr (emsg);
    return 0;
  }
  if (re_exec (tstring)) {
    (void)sscanf (tstring, "%d/%d/%d/%d:%d", &yr, &mo, &dy, &hr, &mint);
    if ((chkyr (yr)) && (chkmo (yr, mo)) && (chkdy (yr, mo, dy)) && 
	(chkhr (dy, hr)) && (chkmin (hr, mint))) {
      nfyrs = yr - BOTIME;
      ndays = nfyrs * DINYEAR + nlyrs (yr, BOTIME) + 
	(mo-1)*DINMONTH - cordays (yr, mo-1) + (dy-1);
      nsecs = ndays * SINDAY + (hr-1) * SINHR + mint * SINMIN;
      return nsecs;       /* it ^^^^ shouldn't be hr-1 but hr - confused! */
    }
    else return 0;
  }
  else return 0;
}

chkyr (year) {
  struct tm *now, *localtime();
  struct timeval t;
  struct timezone tzone; 

  (void)gettimeofday (&t, &tzone);
  now = localtime (&t.tv_sec);
  return ((year >= 70) && (year <= now->tm_year));
}

chkmo (year, month) {
  struct tm *now, *localtime();
  struct timeval t;
  struct timezone tzone; 

  (void)gettimeofday (&t, &tzone);
  now = localtime (&t.tv_sec);
  if ((month <= 12) && (month >= 1))
    return (now->tm_year == year) ? (month <= now->tm_mon+1) : TRUE;
  else
    return FALSE;
}

int itstoday = FALSE;
    
chkdy (year, month, day) {
  struct tm *now, *localtime();
  struct timeval t;
  struct timezone tzone; 

  month--; /* only here: Jan is 0, Dec is 11 -- as is in struct tm */
  (void)gettimeofday (&t, &tzone);
  now = localtime (&t.tv_sec);
  itstoday = ((year == now->tm_year) && (month == now->tm_mon) &&
	      (day == now->tm_mday));
  if ((day <= 28) && ((year < now->tm_year) || (month < now->tm_mon)))
    return TRUE;
  else { /* some day in this month or a day at the end of some month */
    switch (month) {
    case 0:
    case 2:
    case 4:
    case 6:
    case 7:
    case 9:
    case 11:
      return ((day <= 31) && 
	      (((now->tm_year == year) && (now->tm_mon == month)) ?
	       (day <= now->tm_mday) : TRUE));
    case 3:
    case 5:
    case 8:
    case 10:
      return ((day <= 30) && 
	      (((now->tm_year == year) && (now->tm_mon == month)) ?
	       (day <= now->tm_mday) : TRUE));
    case 1:
      return (((isalyr (year)) ? (day <= 29) : (day <= 28)) && 
	      (((now->tm_year == year) && (now->tm_mon == month)) ?
	       (day <= now->tm_mday) : TRUE));
    default:
      logerr ("Heavens ! Our month-check doesn't work. (internal error)");
      return FALSE;
    }
  }
}
/*ARGSUSED*/
chkhr (day, hour) {
  struct tm *now, *localtime();
  struct timeval t;
  struct timezone tzone; 

  (void)gettimeofday (&t, &tzone);
  now = localtime (&t.tv_sec);
  if ((hour >= 0) && (hour <= 23))
    return (itstoday ? (hour <= now->tm_hour) : TRUE);
  else
    return FALSE;
}

chkmin (hour, mint) {
  struct tm *now, *localtime();
  struct timeval t;
  struct timezone tzone; 

  (void)gettimeofday (&t, &tzone);
  now = localtime (&t.tv_sec);
  if ((mint >= 0) && (mint <= 59))
    return ((itstoday && (hour == now->tm_hour)) ? 
	    (mint <= now->tm_min) : TRUE);
  else
    return FALSE;
}

isalyr (year) {
  /*
   *  assumes year to be a reasonable value
   *  checking is done according rules asked from K. Koester
   */
  if ((year % 2000) == 0)
    return FALSE;
  if ((year % 400) == 0)
    return TRUE;
  if ((year % 100) == 0)
    return FALSE;
  else
    return ((year % 4) == 0);
}

nlyrs (year, since) {
  /*
   *  returns number of leapyears from <since> to Jan. 1st <year>
   */
  register int i, lyrs=0;

  for (i = since; i < year; i++)
    if (isalyr(i)) lyrs++;
  return lyrs;
}

int dcorlist[] = { 0, 0, 3, 3, 4, 4, 5, 5, 5, 6, 6, 7, 7 };

cordays (year, month) {
  /*
   *  returns number of days to substract from the sum of <month>
   *  31-day months.
   */
  
  if (isalyr (year))
    return ((dcorlist[month]) ? (dcorlist[month] - 1) : 0);
  else 
    return dcorlist[month];
}
    
