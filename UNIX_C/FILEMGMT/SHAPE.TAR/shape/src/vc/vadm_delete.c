/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: vadm_delete.c[3.7] Thu Feb 23 18:14:09 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/vadm_delete.c[3.4]
 * 	Thu Feb 23 18:14:09 1989 axel@coma published $
 *  --- empty log message ---
 *  vadm_delete.c[3.5] Thu Feb 23 18:14:09 1989 axel@coma published $
 *  --- empty log message ---
 *  vadm_delete.c[3.6] Thu Feb 23 18:14:09 1989 axel@coma save $
 *  --- empty log message ---
 *  vadm_delete.c[3.7] Thu Feb 23 18:14:09 1989 axel@coma published $
 *  --- empty log message ---
 */

#include <stdio.h>
#include <strings.h>

#include "afs.h"
#include "afsapp.h"
#include "vadm.h"
#include "locks.h"

/* external */
extern char *malloc();
extern unsigned int options;
extern struct Transaction ThisTransaction;

/* locals */
static char buf[2048];

/**/
int DoDelete (vlist, ac, av)
     struct vc_vlist *vlist;
     int ac;
     char **av;
{
  Af_set set;
  Af_key *key;
  Af_user *vc_testlock(), *vc_lock();
  Uid_t lockeruid();
  char **erroneous, *lockerid();
  char version[1024];
  int state;
  int i;
  int errs = 0;

  errs = GetKeysByName (ac, av, vlist, &set, &erroneous);

  if (errs)
    print_erroneous (erroneous, errs);

  if (!set.af_nkeys) {
    logmsg ("Nothing appropriate found."); 
    return 1;
  }

  if (errs)
    if (IsOptionSet(Vopt_no_confirm) || IsOptionSet(Vopt_quiet) 
	|| !ask_confirm ("Continue", "yes"))
      return 1;

  ThisTransaction.tr_rc = 0;
  for (i = 0 ; i < set.af_nkeys; i++) {
    Af_user *thislock;
    ThisTransaction.tr_seqno = i;
    key = &set.af_klist[i];
    mkvstring (version, key);
    (void)strcpy (ThisTransaction.tr_fname, version);
    if (setjmp (ThisTransaction.tr_env)) continue;
    if ((state = af_rstate (key)) == -1) {
      (void) sprintf (buf, "DoDelete (%s): af_rstate", 
		      ThisTransaction.tr_fname);
      af_perror (buf);
      ThisTransaction.tr_rc++;
      continue;
    }

    if (state > AF_SAVED) {
      (void)sprintf (buf, "%s cannot be deleted. Version state must be \"saved\".",
	       version);
      logmsg (buf);
      ThisTransaction.tr_rc++;
      continue;
    }

    (void)sprintf (buf, "Delete %s ?", version);
    thislock = vc_testlock_v(key);
    if (locked(thislock)) {
      if (lockeruid (thislock) != (Uid_t)getuid ()) {
	/* locked ! ... but by somebody else */
	(void)sprintf (buf, "No permission to delete %s (locked by %s).",
		 version, lockerid (thislock));
	logmsg (buf); free ((char *)thislock);
	continue;
      }
    }
    else { /* the version is not locked. We must lock it to delete it. */
      Af_user *mylock = vc_lock_v(key, (Uid_t)getuid ());
      if (lockeruid (mylock) != (Uid_t)getuid ()) {
	(void)sprintf (buf, "can't lock %s. Not deleted.", version);
	logmsg (buf);
	free ((char *)mylock); free ((char *)thislock);
	continue;
      }
      free ((char *)mylock);
    }
    free ((char *)thislock);

    if (!(IsOptionSet(Vopt_no_confirm) || IsOptionSet(Vopt_quiet)))
      if (!ask_confirm (buf, "yes")) {
	(void)sprintf (buf, "%s not deleted.", version);
	logmsg (buf); free ((char *)thislock);
	continue;
      }
    if (af_rm (key) == -1) {
      (void)sprintf (buf, "DoDelete(): During deletion of %s.", version);
      af_perror (buf);
      return 1;
    }
    (void)sprintf (buf, "%s deleted.", version);
    logmsg (buf);
  }

  if (errs)
    return 1;
  else
    return 0;
}

