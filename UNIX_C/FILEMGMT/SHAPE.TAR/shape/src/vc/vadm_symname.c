/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: vadm_symname.c[3.8] Thu Feb 23 18:14:21 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/vadm_symname.c[3.2]
 * 	Thu Feb 23 18:14:22 1989 axel@coma published $
 *  --- empty log message ---
 *  vadm_symname.c[3.5] Thu Feb 23 18:14:22 1989 axel@coma published $
 *  --- empty log message ---
 *  vadm_symname.c[3.6] Thu Feb 23 18:14:22 1989 axel@coma save $
 *  --- empty log message ---
 *  vadm_symname.c[3.7] Thu Feb 23 18:14:22 1989 axel@coma save $
 *  --- empty log message ---
 *  vadm_symname.c[3.8] Thu Feb 23 18:14:22 1989 axel@coma published $
 *  --- empty log message ---
 */

#include <sys/types.h>
#include <sys/stat.h>

#include <stdio.h>
#include <strings.h>
#include <afs.h>

#include "vadm.h"
#include "project.h"
#include "afsapp.h"

extern unsigned options;
extern int def_vnum;
extern struct Transaction ThisTransaction;
/* locals */
static char buf[1024];

/**/
DoSymname (vlist, ac, av, sym)
     struct vc_vlist *vlist;
     int ac;
     char **av;
     char *sym;
{
  Af_set set;
  char **erroneous;
  int i, errs;
  char version[2048];
  char symname[2048];
  
  if (SymnameInUse (ac, av, sym)) {
    (void)sprintf (buf, "symbolic name %s already assigned to some other version.",
	     sym);
    logerr (buf);
    return 1;
  }
  if (IsOptionSet(Vopt_version)) {
    errs = GetKeysByGenRev
	(ac,av, gen(def_vnum), rev(def_vnum), &set, &erroneous);
  }
  else {
    if (!vlist->from_version_set || !vlist->to_version_set) {
      if (IsOptionSet (Vopt_binary))
	errs = GetKeysByGenRev 
	  (ac,av, AF_BUSYVERS, AF_BUSYVERS, &set, &erroneous);
      else
	errs = GetKeysByGenRev 
	  (ac,av, AF_LASTVERS, AF_LASTVERS, &set, &erroneous);
    }
    else
      errs = GetKeysByName (ac, av, vlist, &set, &erroneous);
  }

  if (errs)
    print_erroneous (erroneous, errs);

  if (!set.af_nkeys) {
    logmsg ("Nothing appropriate found.");
    return 1;
  }

  if (errs && !ask_confirm ("Continue ?", "yes"))
    return 1;

  (void)sprintf (symname, "%s=%s", SYMNAME, sym);
  
  for (i = 0; i < set.af_nkeys; i++) {
    mkvstring (version, &set.af_klist[i]);
    if (setjmp (ThisTransaction.tr_env)) continue; 
    if (af_sudattr (&set.af_klist[i], AF_ADD, symname) == -1) {
      af_perror ("DoSymname: af_sudattr");
      return 1;
    }
    (void)sprintf (buf, "Symbolic name %s attached to %s.", sym, version);
    logmsg (buf);
  }
  return 0;
}

DoSetCommentSymbol (ac, av, sym)
     int ac;
     char **av;
     char *sym;
{
  Af_set set;
  char **erroneous, c_symbol[CLEADMAXLEN];
  int i, errs;
  
  errs = GetKeysByName (ac, av, (struct vc_vlist *)NULL, &set, 
			&erroneous);

  if (errs)
    print_erroneous (erroneous, errs);

  if (!set.af_nkeys) {
    logmsg ("Nothing appropriate found.");
    return 1;
  }

  if (errs && !ask_confirm ("Continue ?", "yes"))
    return 1;

  (void)sprintf (c_symbol, "%s=%s", CLEAD, sym);
  
  for (i = 0; i < set.af_nkeys; i++) {

    if (setjmp (ThisTransaction.tr_env)) continue;
    if (af_sudattr (&set.af_klist[i], AF_REPLACE, c_symbol) == -1) {
      if (af_sudattr (&set.af_klist[i], AF_ADD, c_symbol) == -1) {
	af_perror ("DoSetCommentSymbol: af_suadttr");
	return 1;
      }
    }
  }
  return 0;
}

DoSetUda (vlist, ac, av)
     struct vc_vlist *vlist;
     int ac;
     char **av;
{
  extern char *TakeFromFile, udaname[], udaval[];

  Af_set set;
  char **erroneous;
  int i, errs, udamemlen;
  char version[128], *hook, *udamem, *cp, messg[80], *malloc();
  FILE *tff;
  struct stat sbuf;

  if (IsOptionSet(Vopt_version)) {
    errs = GetKeysByGenRev
	(ac,av, gen(def_vnum), rev(def_vnum), &set, &erroneous);
  }
  else {
    if (!vlist->from_version_set || !vlist->to_version_set)
      errs = GetKeysByGenRev 
	(ac,av, AF_BUSYVERS, AF_BUSYVERS, &set, &erroneous);
    else
      errs = GetKeysByName (ac, av, vlist, &set, &erroneous);
  }
  if (errs)
    print_erroneous (erroneous, errs);

  if (!set.af_nkeys) {
    logmsg ("Nothing appropriate found.");
    return 1;
  }

  if (errs && !ask_confirm ("Continue ?", "yes"))
    return 1;

  if (TakeFromFile) {
    if ((tff = fopen (TakeFromFile, "r")) == NULL) {
      (void)sprintf (messg, "can't open attribute value file %s.", TakeFromFile);
      logerr (messg);
      return 1;
    }
    if (fstat (fileno (tff), &sbuf) < 0) {
      perror ("fstat");
      return 1;
    }
    udamem = 
      malloc ((unsigned)(udamemlen=(strlen (udaname) + sbuf.st_size + 2)));
    if (udamem == NULL) {
      logerr ("Not enough memory to build attribute");
      return 1;
    }
    (void)sprintf (udamem, "%s=", udaname);
    cp = udamem + strlen (udamem);
    (void)fread (cp, sizeof (char), (Size_t)sbuf.st_size, tff); 
    (void)fclose (tff);
    udamem[udamemlen-1] = '\0';
  }
  else { /* udaval not taken from file */
    udamem = 
      malloc ((unsigned)(udamemlen=(strlen (udaname) + strlen (udaval) + 2)));
    if (udamem == NULL) {
      logerr ("Not enough memory to build attribute");
      return 1;
    }
    (void)sprintf (udamem, "%s=%s", udaname, udaval);
  }  
  for (i = 0; i < set.af_nkeys; i++) {
    if (setjmp (ThisTransaction.tr_env)) continue;
    mkvstring (version, &set.af_klist[i]);

    if (hook=af_rudattr (&set.af_klist[i], udaname)) {
      free (hook);
      if (af_sudattr (&set.af_klist[i], AF_REPLACE, udamem) == -1) {
	af_perror ("af_sudattr");
	return 1;
      }
    }
    else { /* attribute is newly introduced */
      if (af_sudattr (&set.af_klist[i], AF_ADD, udamem) == -1) {
	af_perror ("af_suadttr");
	return 1;
      }
    }
  }
  free (udamem);
  return 0;
}

DoUnsetUda (vlist, ac, av)
     struct vc_vlist *vlist;
     int ac;
     char **av;
{
  extern char udaname[];

  Af_set set;
  char **erroneous;
  int i, errs;
  char version[128], *hook;

  if (IsOptionSet(Vopt_version)) {
    errs = GetKeysByGenRev
	(ac,av, gen(def_vnum), rev(def_vnum), &set, &erroneous);
  }
  else {
    if (!vlist->from_version_set || !vlist->to_version_set)
      errs = GetKeysByGenRev 
	(ac,av, AF_BUSYVERS, AF_BUSYVERS, &set, &erroneous);
    else
      errs = GetKeysByName (ac, av, vlist, &set, &erroneous);
  }
  if (errs)
    print_erroneous (erroneous, errs);

  if (!set.af_nkeys) {
    logmsg ("Nothing appropriate found.");
    return 1;
  }

  if (errs && !ask_confirm ("Continue ?", "yes"))
    return 1;

  for (i = 0; i < set.af_nkeys; i++) {
    mkvstring (version, &set.af_klist[i]);
    if (setjmp (ThisTransaction.tr_env)) continue; 
    if (hook=af_rudattr (&set.af_klist[i], udaname)) {
      free (hook);
      if (af_sudattr (&set.af_klist[i], AF_REMOVE, udaname) == -1) {
	af_perror ("af_sudattr");
	return 1;
      }
    }
  }
  return 0;
}

int DoSetAttrs (vlist, ac, av)
     struct vc_vlist *vlist;
     int ac;
     char **av;
{
  extern char Attrfile[];

  char *as, **erroneous, *getattr(), version[128];
  Af_set set;
  register int i;
  int errs;

  if (IsOptionSet(Vopt_version)) {
    errs = GetKeysByGenRev
	(ac,av, gen(def_vnum), rev(def_vnum), &set, &erroneous);
  }
  else {
    if (!vlist->from_version_set || !vlist->to_version_set)
      errs = GetKeysByGenRev 
	(ac,av, AF_BUSYVERS, AF_BUSYVERS, &set, &erroneous);
    else
      errs = GetKeysByName (ac, av, vlist, &set, &erroneous);
  }
  if (errs)
    print_erroneous (erroneous, errs);

  if (!set.af_nkeys) {
    logmsg ("Nothing appropriate found.");
    return 1;
  }

  if (errs && !ask_confirm ("Continue ?", "yes"))
    return 1;

  for (i = 0; i < set.af_nkeys; i++) {
    mkvstring (version, &set.af_klist[i]);
    if (setjmp (ThisTransaction.tr_env)) continue; 
    as = getattr (Attrfile, (Project *)NULL, (char *)NULL, REWIND);
    af_sudattr (&set.af_klist[i], AF_ADD, as);
    while (as=getattr (Attrfile, (Project *)NULL, (char *)NULL, NEXT)) {
      af_sudattr (&set.af_klist[i], AF_ADD, as);
    }
  }
  return FALSE;
}

int SymnameInUse (ac, av, sym) int ac; char **av, *sym; {
  /*
   * Function yields TRUE, if any version of any object named in 'av'
   * has the name 'sym' assigned as value of the user-defined attribute
   * SYMNAME.
   */
  
  Af_attrs warrant;
  Af_set hits;
  int i, rc;
  char symname[2048], cname[MAXNAMLEN], vstring[80];

  (void)sprintf (symname, "%s=%s", SYMNAME, sym);
  af_initattrs (&warrant);
  warrant.af_udattrs[0] = symname;
  warrant.af_udattrs[1] = (char *)NULL;
  for (i = 0; i < ac; i++) {
    if (BoundVersion (av[i], cname, vstring))
      initwarrant (&warrant, cname);
    else
      initwarrant (&warrant, av[i]);
    if ((rc=af_find (&warrant, &hits) > 0)) { 
      af_dropset (&hits);
      return rc;
    }
    else if (rc < 0)
      af_perror ("af_find (in SymnameInUse)");
  }
  return FALSE;
}

initwarrant (warrant, fname) Af_attrs *warrant; char *fname; {
  (void)strcpy (warrant->af_syspath, af_afpath (fname));
  (void)strcpy (warrant->af_name, af_afname (fname));
  (void)strcpy (warrant->af_type, af_aftype (fname));
}

