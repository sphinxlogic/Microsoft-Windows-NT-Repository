/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: project.c[1.4] Thu Feb 23 18:13:39 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/project.c[1.2]
 * 	Thu Feb 23 18:13:39 1989 axel@coma published $
 *  --- empty log message ---
 *  project.c[1.3] Thu Feb 23 18:13:39 1989 axel@coma published $
 *  --- empty log message ---
 *  project.c[1.4] Thu Feb 23 18:13:39 1989 axel@coma published $
 *  --- empty log message ---
 */

/*LINTLIBRARY*/

#include "project.h"

/*ARGSUSED*/
GetProject (pname, pstruct) Project *pstruct; char *pname; {
/*
 * Try to find information about a project. If pname is anything but 
 * a NULL pointer, try to find information about a project of this name.
 * If pname is NULL, search the environment for variable "SHAPEPRJ"
 * (specified in project.h). If there isn't such a variable, look for
 * a ".Project"-file in the user's home directory.
 * GetProject returns an error indication, if pname was given but no
 * project data can be found. A NULL pointer is returned if no project
 * information could be found in the remaining cases (indicating local
 * or small operation).
 */
  return NULL;   /* This is yet a stub */
}
