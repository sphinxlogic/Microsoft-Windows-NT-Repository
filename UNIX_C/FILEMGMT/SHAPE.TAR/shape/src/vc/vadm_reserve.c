/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: vadm_reserve.c[3.13] Thu Feb 23 18:14:17 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/vadm_reserve.c[3.7]
 * 	Thu Feb 23 18:14:17 1989 axel@coma published $
 *  --- empty log message ---
 *  vadm_reserve.c[3.9] Thu Feb 23 18:14:18 1989 axel@coma published $
 *  --- empty log message ---
 *  vadm_reserve.c[3.11] Thu Feb 23 18:14:18 1989 axel@coma published $
 *  --- empty log message ---
 *  vadm_reserve.c[3.12] Thu Feb 23 18:14:18 1989 axel@coma save $
 *  --- empty log message ---
 *  vadm_reserve.c[3.13] Thu Feb 23 18:14:18 1989 axel@coma published $
 *  --- empty log message ---
 */

#include <sys/types.h>
#include <sys/stat.h>

#include <pwd.h>
#include <stdio.h>
#include <strings.h>

#include "afs.h"
#include "vadm.h"
#include "afsapp.h"
#include "locks.h"

/* externals */
extern char *malloc();
extern int newmode;
extern Af_user newauthor;
extern int def_vnum;
extern struct Transaction ThisTransaction;

/* forward */
char *uidname ();

/* locals */
static char buf[2048];

/**/
Uid_t af_MY_rouid (key) Af_key *key; {
  /*
   *  This function returns the userid of the owner of the AFS directory
   *  containing the AFS object identified by key.
   */
  char path[256];
  struct stat statbuf;

  (void)strcpy (path, af_rsyspath (key));
  if (strcmp (path, "/") == NULL)
    (void)strcpy (path, "");
  (void)strcat (path, "/AFS");
  if (stat (path, &statbuf) < 0) {
    perror (path);
    return -1;
  }
  return statbuf.st_uid;
}

int do_reserve (set)
     Af_set *set;
{
  register int i;
  Af_user *locker;
  int errs = 0;
  char version[1024], *fn, *mkfn(), *p, *lockerid();
  struct stat sbuf;

  if (af_sortset (set, AF_ATTHUMAN) == -1)
    vctl_abort ("do_reserve: af_sortset()");
      
  for (i = 0; i < set->af_nkeys; i++) {
    mkvstring (version, &set->af_klist[i]);
    if (setjmp (ThisTransaction.tr_env)) continue;
    /* if (locking == AF_GLOBALLOCK) { /* to be implemented */
    if (p=rindex(version, '[')) *p = '\0';
    
    if (!locked(locker = vc_testlock_g(&set->af_klist[i]))) {
      logmsg ("WARNING! Administrative locking may lose attribute citations.");
      if (vc_lock_g(&set->af_klist[i], (Uid_t)geteuid()) == (Af_user *)NULL) {
	af_perror ("af_lock");
	continue;
      }
      else {
	if (af_rstate (&set->af_klist[i]) == AF_BUSY) {
	  char *intent, *getintent();
	  extern unsigned int options;
	  if (!IsOptionSet (Vopt_quiet)) {
	    intent = getintent ("Describe intended changes ?", (char *)NULL);
	  }
	  else intent = (char *)NULL;
	  if (intent) {
	    char *intattr;
	    intattr = malloc ((unsigned)(strlen (intent) + 
					 strlen (INTENT) +1));
	    (void)sprintf (intattr, "%s%s", INTENT, intent);
	    if (fail(af_sudattr (&set->af_klist[i], AF_REPLACE, intattr)))
	       af_sudattr (&set->af_klist[i] , AF_ADD, intattr);
	    free (intattr);
	  }
	}
	(void)sprintf (buf, "%s reserved.", version);
	fn = mkfn (&set->af_klist[i]);
	if (stat (fn, &sbuf) == 0) {
	  (void)chmod (fn, (int)(sbuf.st_mode | 0200));
	}
	logmsg (buf);
      }
    }
    else { /* testlock returned something */
      if (lockeruid(locker) != (Uid_t)geteuid()) {
	(void)sprintf (buf, "%s is already locked by %s.", version, 
		 lockerid (locker));
	logmsg (buf);
	errs++;
	continue;
      }
      else {
	(void)sprintf (buf, "%s reserved.", version);
	fn = mkfn (&set->af_klist[i]);
	if (stat (fn, &sbuf) == 0) {
	  (void)chmod (fn, (int)(sbuf.st_mode | 0200));
	}
	logmsg (buf);
      }
    }
  }
  if (errs)
    return 1;
  else
    return 0;
}

int do_chmod (set)
     Af_set *set;
{
  int i;
  int errs = 0;
  char version[1024];
  
  if (af_sortset (set, AF_ATTHUMAN) == -1)
    vctl_abort ("do_chmod: af_sortset()");
      
  for (i = 0; i < set->af_nkeys; i++) {
    mkvstring (version, &set->af_klist[i]);
    if (setjmp (ThisTransaction.tr_env)) continue; 
    if (af_MY_rouid (&set->af_klist[i]) != (Uid_t)geteuid()) {
      (void)sprintf (buf, "%s not owned by %s.", version, 
	       uidname((Uid_t)geteuid()));
      logmsg (buf);
      errs++;
      continue;
    }
    else {
      if (af_chmod (&set->af_klist[i], newmode) < 0) {
	af_perror ("af_chmod");
	errs++;
	continue;
      }
      (void)sprintf (buf, "%s done.", version);
      logmsg (buf);
    }
  }
  if (errs)
    return 1;
  else
    return 0;
}

int do_chown (set)
     Af_set *set;
{
  int i;
  int errs = 0;
  char version[1024];
  
  if (af_sortset (set, AF_ATTHUMAN) == -1)
    vctl_abort ("do_chown: af_sortset()");
      
  for (i = 0; i < set->af_nkeys; i++) {
    mkvstring (version, &set->af_klist[i]);
    if (setjmp (ThisTransaction.tr_env)) continue; 
    if (lockeruid (af_rowner (&set->af_klist[i])) != geteuid()) {
      (void)sprintf (buf, "%s not owned by %s.", version, 
	       uidname (geteuid()));
      logmsg (buf);
      errs++;
      continue;
    }
    else {
      logmsg ("This function is not available under BSD.");
      errs++;
      continue;
    }
  }
  if (errs)
    return 1;
  else
    return 0;
}

int do_chaut (set)
     Af_set *set;
{
  int i;
  int errs = 0;
  char version[1024];
  
  if (af_sortset (set, AF_ATTHUMAN) == -1)
    vctl_abort ("do_chaut: af_sortset()");
      
  for (i = 0; i < set->af_nkeys; i++) {
    mkvstring (version, &set->af_klist[i]);
    if (setjmp (ThisTransaction.tr_env)) continue; 
    if (af_MY_rouid (&set->af_klist[i]) != (Uid_t)geteuid()) {
      (void)sprintf (buf, "%s not owned by %s.", version, 
	       uidname ((Uid_t)geteuid()));
      logmsg (buf);
      errs++;
      continue;
    }
    else {
      if (af_chauthor (&set->af_klist[i], &newauthor) < 0) {
	af_perror ("af_chaut");
	errs++;
	continue;
      }
      (void)sprintf (buf, "%s done.", version);
      logmsg (buf);
    }
  }
  if (errs)
    return 1;
  else
    return 0;
}

/**/
DoReserve (ac, av)
     int ac;
     char **av;
{
  Af_set set;
  int errs, errput = 0;
  char **erroneous;

  errs = GetKeysByGenRev (ac,av, AF_BUSYVERS, AF_BUSYVERS, &set, 
			  &erroneous);

  if (errs) {
    print_erroneous (erroneous, errs);
    errput++;
  }

  if (!set.af_nkeys && !errput) {
    logmsg ("Nothing appropriate found.");
    return 1;
  }

  if (errs && !ask_confirm ("Continue ?", "yes"))
    return 1;

  return do_reserve (&set);
}

int do_unreserve (set)
     Af_set *set;
{
  int i;
  Af_user *locker;
  int errs = 0;
  char version[1024];
  char *p;
  FILE *pip;

  if (af_sortset (set, AF_ATTHUMAN) == -1)
    vctl_abort ("do_promote: af_sortset()");
  for (i = 0; i < set->af_nkeys; i++) {
    mkvstring (version, &set->af_klist[i]);
    if (setjmp (ThisTransaction.tr_env)) continue;
    /* if (locking == AF_GLOBALLOCK) { /* to be implemented */
    if (p=rindex(version, '[')) *p = '\0';
    if (!locked(locker = af_testlock (&set->af_klist[i], AF_GLOBALLOCK))) {
      (void)sprintf (buf, "%s unlocked.", version);
      logmsg (buf);
      continue;
    }
    if (lockeruid (locker) == geteuid()) {
      (void)vc_unlock_g(&set->af_klist[i]);
      (void)sprintf (buf, "%s unlocked.", version);
      logmsg (buf);
      continue;
    }
    else { /* locked by somebody else */
      /* The following is an evil hack. BSD doesn't allow chmod(2)
       * for ordinary user processes. 
       */
      if (af_MY_rouid (&set->af_klist[i]) == geteuid()) { 
	/* we've got the power ... */
	(void)sprintf (buf, "%s currently locked by %s. Break the lock ?", version,
		 lockerid (locker));
	if (ask_confirm (buf, "yes")) {
	  if (vc_unlock_g(&set->af_klist[i]) == NULL) {
	    af_perror ("af_unlock");
	    continue;
	  }
	  (void)sprintf (buf, MAIL, version, uidname(geteuid()));
	  (void)strcat (buf, lockerid (locker));
	  if ((pip = popen (buf, "w")) == NULL) {
	    logmsg ("WARNING: couldn't notify lockholder...");
	  }
	  else {
	    fprintf (pip, "This message was issued automatically by ");
	    fprintf (pip, "the version control system.\n");
	    fprintf (pip, "Your lock on %s was broken by %s.\n",
		     version, uidname(geteuid()));
	    (void)pclose (pip);
	  }
	  (void)sprintf (buf, "%s unlocked.", version);
	  logmsg (buf);
	  continue;
	}
	else { /* we don't wanna break the lock */
	  (void)sprintf (buf, "%s remains locked by %s.", version, 
		   lockerid (locker));
	  logmsg (buf);
	  continue;
	}
      }
      else { /* we cannot unlock the required version */
	(void)sprintf (buf, "%s is locked by %s.", version, lockerid (locker));
	logmsg (buf);
	errs++;
	continue;
      }
    }
  }
  if (errs)
    return 1;
  else
    return 0;
}

/**/
DoUnreserve (ac, av)
     int ac;
     char **av;
{
  Af_set set;
  int errs;
  char **erroneous;

  errs = GetKeysByGenRev (ac,av, AF_BUSYVERS, AF_BUSYVERS, &set, 
			  &(erroneous));

  if (errs)
    print_erroneous (erroneous, errs);

  if (!set.af_nkeys) {
    logmsg ("Nothing appropriate found.");
    return 1;
  }

  if (errs && !ask_confirm ("Continue ?", "yes"))
    return 1;

  return do_unreserve (&set);
}

DoChmod (vlist, ac, av)
     struct vc_vlist *vlist;
     int ac;
     char **av;
{
  Af_set set;
  int errs;
  char **erroneous;

  if (IsOptionSet(Vopt_version)) {
    errs = GetKeysByGenRev
	(ac,av, gen(def_vnum), rev(def_vnum), &set, &erroneous);
  }
  else {
    if (!(vlist->from_version_set) || !(vlist->to_version_set))
      errs = GetKeysByGenRev 
	(ac,av, AF_BUSYVERS, AF_BUSYVERS, &set, &erroneous);
    else
      errs = GetKeysByName ( ac, av, vlist, &set, &erroneous);
  }
  if (errs)
    print_erroneous (erroneous, errs);

  if (!set.af_nkeys) {
    logmsg ("Nothing appropriate found.");
    return 1;
  }

  if (errs && !ask_confirm ("Continue ?", "yes"))
    return 1;

  return do_chmod (&set);
}

DoChown (ac, av)
     int ac;
     char **av;
{
  Af_set set;
  int errs;
  char **erroneous;

  errs = GetKeysByGenRev (ac,av, AF_BUSYVERS, AF_BUSYVERS, &set, 
			  &erroneous);

  if (errs)
    print_erroneous (erroneous, errs);

  if (!set.af_nkeys) {
    logmsg ("Nothing appropriate found.");
    return 1;
  }

  if (errs && !ask_confirm ("Continue ?", "yes"))
    return 1;

  return do_chown (&set);
}

DoChaut (vlist, ac, av)
     struct vc_vlist *vlist;
     int ac;
     char **av;
{
  Af_set set;
  int errs;
  char **erroneous;

  if (IsOptionSet(Vopt_version)) {
    errs = GetKeysByGenRev
	(ac,av, gen(def_vnum), rev(def_vnum), &set, &erroneous);
  }
  else {
    if (!(vlist->from_version_set) || !(vlist->to_version_set))
      errs = GetKeysByGenRev 
	(ac,av, AF_LASTVERS, AF_LASTVERS, &set, &erroneous);
    else
      errs = GetKeysByName ( ac, av, vlist, &set, &erroneous);
  }
  if (errs)
    print_erroneous (erroneous, errs);

  if (!set.af_nkeys) {
    logmsg ("Nothing appropriate found.");
    return 1;
  }

  if (errs && !ask_confirm ("Continue ?", "yes"))
    return 1;

  return do_chaut (&set);
}

char *mkfn (key) Af_key *key; {
  /* construct a unix (busy-)filename for object pointed to by key */
  static char name[128];
  char *n, *t;

  name[0] = '\0';
  t = af_rtype (key); t = *t ? t : NULL;
  (void)sprintf (name, "%s%s%s", n=af_rname (key), t ? "." : "", t ? t : "");
  free (n); free (t);
  return name;
}

char *uidname (uid) Uid_t uid; {
  struct passwd *pwent = getpwuid ((int)uid);
  char un[80];

  if (pwent == NULL) {
    (void)sprintf (un, "somebody (uid=%d)", uid);
    return un;
  }
  else return pwent->pw_name;
}

