/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: vadm_promote.c[3.7] Thu Feb 23 18:14:15 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/vadm_promote.c[3.3]
 * 	Thu Feb 23 18:14:15 1989 axel@coma published $
 *  --- empty log message ---
 *  vadm_promote.c[3.5] Thu Feb 23 18:14:15 1989 axel@coma published $
 *  --- empty log message ---
 *  vadm_promote.c[3.6] Thu Feb 23 18:14:15 1989 axel@coma save $
 *  --- empty log message ---
 *  vadm_promote.c[3.7] Thu Feb 23 18:14:15 1989 axel@coma published $
 *  --- empty log message ---
 */

#include <stdio.h>
#include <afs.h>

#include "afsapp.h"
#include "vadm.h"
#include "locks.h"

/* external */
extern char *malloc(), *st_table[];
extern unsigned int options;
extern int def_vnum;
extern struct Transaction ThisTransaction;

/* locals */
char buf[2048];

/**/
static
int do_promote (set)
     Af_set *set;
{
  int i, oldstate;
  int errs = 0;
  char version[1024];

  if (af_sortset (set, AF_ATTHUMAN) == -1)
    vctl_abort ("do_promote: af_sortset()");
      
  for (i = 0; i < set->af_nkeys; i++) {
    if (setjmp (ThisTransaction.tr_env)) continue;
    mkvstring (version, &set->af_klist[i]);
    if ((oldstate = af_rstate (&set->af_klist[i])) == -1) {
      af_perror ("do_promote()");
      return 1;
    }

    switch (oldstate) {
    case AF_BUSY:
      (void)sprintf (buf, "%s busy. Fatal", version);
      logmsg (buf);
      vctl_abort ("CONTACT LOCAL GURU"); /* no return */
      break;
    case AF_SAVED:
      if ((lockeruid(vc_lock_v(&set->af_klist[i], (Uid_t)getuid()))) != 
	  (Uid_t)getuid()) {
	logerr ("can't change state -- locked");
	return 1;
      }
      if (af_sstate (&set->af_klist[i], AF_PROPOSED) == -1) {
	af_perror ("af_sstate():");
	return 1;
      }
      (void)vc_unlock_v(&set->af_klist[i]);
      (void)sprintf (buf, "%s promoted to state \"%s\".", version,
	       st_table[AF_PROPOSED]);
      logmsg (buf);
      break;
    case AF_PROPOSED:
      if ((lockeruid(vc_lock_v(&set->af_klist[i],(Uid_t)getuid()))) != 
	  (Uid_t)getuid()) {
	logerr ("can't change state -- locked");
	return 1;
      }
      if (af_sstate (&set->af_klist[i], AF_PUBLISHED) == -1) {
	af_perror ("af_sstate():");
	return 1;
      }
      (void)vc_unlock_v(&set->af_klist[i]);
      (void)sprintf (buf, "%s promoted to state \"%s\".", version,
	       st_table[AF_PUBLISHED]);
      logmsg (buf);
      break;
    case AF_PUBLISHED:
      if ((lockeruid(vc_lock_v(&set->af_klist[i], (Uid_t)getuid()))) != 
	  (Uid_t)getuid()) {
	logerr ("can't change state -- locked");
	return 1;
      }
      if (af_sstate (&set->af_klist[i], AF_ACCESSED) == -1) {
	af_perror ("af_sstate():");
	return 1;
      }
      (void)vc_unlock_v(&set->af_klist[i]);
      (void)sprintf (buf, "%s promoted to state \"%s\".", version,
	       st_table[AF_ACCESSED]);
      logmsg (buf);
      break;
    case AF_ACCESSED:
      if ((lockeruid(vc_lock_v(&set->af_klist[i], (Uid_t)getuid()))) != 
	  (Uid_t)getuid()) {
	logerr ("can't change state -- locked");
	return 1;
      }
      if (af_sstate (&set->af_klist[i], AF_FROZEN) == -1) {
	af_perror ("af_sstate():");
	return 1;
      }
      (void)vc_unlock_v(&set->af_klist[i]);
      (void)sprintf (buf, "%s promoted to state \"%s\".", version,
	       st_table[AF_FROZEN]);
      logmsg (buf);
      break;
    case AF_FROZEN:
      (void)sprintf (buf, "%s already frozen. --- Not promoted.", version);
      logmsg (buf);
      errs++;
      break;
    default:
      (void)sprintf (buf, "%s has unknown version state %d.", version, oldstate);
      logmsg (buf);
      vctl_abort ("CONTACT LOCAL GURU.");
    }
  }
  if (errs)
    return 1;
  else
    return 0;
}

/**/
int DoPromote (vlist, ac, av)
     struct vc_vlist *vlist;
     int ac;
     char **av;
{
  Af_set set;
  int errs;
  char **erroneous;

  if (IsOptionSet(Vopt_version)) {
    errs = GetKeysByGenRev
	(ac,av, gen(def_vnum), rev(def_vnum), &set, &erroneous);
  }
  else {
    if (!(vlist->from_version_set) || !(vlist->to_version_set))
      errs = GetKeysByGenRev 
	(ac,av, AF_LASTVERS, AF_LASTVERS, &set, &erroneous);
    else
      errs = GetKeysByName ( ac, av, vlist, &set, &erroneous);
  }
  if (errs)
    print_erroneous (erroneous, errs);

  if (!set.af_nkeys) {
    logmsg ("Nothing appropriate found.");
    return 1;
  }

  if (errs && !ask_confirm ("Continue ?", "yes"))
    return 1;

  return do_promote (&set);
}

/**/
static
int do_unpromote (set)
     Af_set *set;
{
  int i, oldstate;
  int errs = 0;
  char version[1024];

  if (af_sortset (set, AF_ATTHUMAN) == -1)
    vctl_abort ("do_unpromote: af_sortset()");
      
  for (i = 0; i < set->af_nkeys; i++) {
    mkvstring (version, &set->af_klist[i]);
    if (setjmp (ThisTransaction.tr_env)) continue;
    if ((oldstate = af_rstate (&set->af_klist[i])) == -1) {
      af_perror ("do_promote()");
      return 1;
    }

    switch (oldstate) {
    case AF_BUSY:
      (void)sprintf (buf, "%s busy. Fatal", version);
      logmsg (buf);
      vctl_abort ("CONTACT LOCAL GURU"); /* no return */
      break;
    case AF_SAVED:
      (void)sprintf (buf, "%s already saved.", version);
      logmsg (buf);
      break;
    case AF_PROPOSED:
      if ((lockeruid(vc_lock_v(&set->af_klist[i], (Uid_t)getuid()))) != 
	  (Uid_t)getuid()) {
	logerr ("can't change state -- locked");
	return 1;
      }
      if (af_sstate (&set->af_klist[i], AF_SAVED) == -1) {
	af_perror ("af_sstate():");
	return 1;
      }
      (void)vc_unlock_v(&set->af_klist[i]);
      (void)sprintf (buf, "%s unpromoted to state \"%s\".", version, 
	       st_table[AF_SAVED]);
      logmsg (buf);
      break;
    case AF_PUBLISHED:
      if ((lockeruid(vc_lock_v(&set->af_klist[i], (Uid_t)getuid()))) != 
	  (Uid_t)getuid()) {
	logerr ("can't change state -- locked");
	return 1;
      }
      if (af_sstate (&set->af_klist[i], AF_PROPOSED) == -1) {
	af_perror ("af_sstate():");
	return 1;
      }
      (void)vc_unlock_v(&set->af_klist[i]);
      (void)sprintf (buf, "%s unpromoted to state \"%s\".", version,
	       st_table[AF_PROPOSED]);
      logmsg (buf);
      break;
    case AF_ACCESSED:
      if ((lockeruid(vc_lock_v(&set->af_klist[i], (Uid_t)getuid()))) != 
	  (Uid_t)getuid()) {
	logerr ("can't change state -- locked");
	return 1;
      }
      if (af_sstate (&set->af_klist[i], AF_PUBLISHED) == -1) {
	af_perror ("af_sstate():");
	return 1;
      }
      (void)vc_unlock_v(&set->af_klist[i]);
      (void)sprintf (buf, "%s unpromoted to state \"%s\".", version,
	       st_table[AF_PUBLISHED]);
      logmsg (buf);
      break;
    case AF_FROZEN:
      if ((lockeruid(vc_lock_v(&set->af_klist[i], (Uid_t)getuid()))) != 
	  (Uid_t)getuid()) {
	logerr ("can't change state -- locked");
	return 1;
      }
      if (af_sstate (&set->af_klist[i], AF_ACCESSED) == -1) {
	af_perror ("af_sstate():");
	return 1;
      }
      (void)vc_unlock_v(&set->af_klist[i]);
      (void)sprintf (buf, "%s unpromoted to state \"%s\".", version,
	       st_table[AF_ACCESSED]);
      logmsg (buf);
      break;
    default:
      (void)sprintf (buf, "%s has unknown version state %d.", version, oldstate);
      logmsg (buf);
      vctl_abort ("CONTACT LOCAL GURU.");
    }
  }
  if (errs)
    return 1;
  else
    return 0;
}

/**/
int DoUnpromote (vlist, ac, av)
     struct vc_vlist *vlist;
     int ac;
     char **av;
{
  Af_set set;
  int errs;
  char **erroneous;

  if (IsOptionSet(Vopt_version)) {
    errs = GetKeysByGenRev
	(ac,av, gen(def_vnum), rev(def_vnum), &set, &erroneous);
  }
  else {
    if (!(vlist->from_version_set) || !(vlist->to_version_set))
      errs = GetKeysByGenRev 
	(ac,av, AF_LASTVERS, AF_LASTVERS, &set, &erroneous);
    else
      errs = GetKeysByName (ac, av, vlist, &set, &erroneous);
  }
  if (errs)
    print_erroneous (erroneous, errs);

  if (!set.af_nkeys) {
    logmsg ("Nothing appropriate found.");
    return 1;
  }

  if (errs && !ask_confirm ("Continue ?", "yes"))
    return 1;

  return do_unpromote (&set);
}
