/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: vc_call.c[1.10] Thu Feb 23 18:14:28 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/vc_call.c[1.3]
 * 	Thu Feb 23 18:14:28 1989 axel@coma published $
 *  --- empty log message ---
 *  vc_call.c[1.6] Thu Feb 23 18:14:28 1989 axel@coma published $
 *  --- empty log message ---
 *  vc_call.c[1.7] Thu Feb 23 18:14:28 1989 axel@coma save $
 *  --- empty log message ---
 *  vc_call.c[1.8] Thu Feb 23 18:14:28 1989 axel@coma save $
 *  --- empty log message ---
 *  vc_call.c[1.9] Thu Feb 23 18:14:28 1989 axel@coma save $
 *  --- empty log message ---
 *  vc_call.c[1.10] Thu Feb 23 18:14:28 1989 axel@coma published $
 *  --- empty log message ---
 */

#include <stdio.h>
#include <strings.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#ifndef MAXNAMLEN
#include <sys/dir.h>
#endif MAXNAMLEN
#include "afsapp.h"
#include <sys/resource.h>

extern char *malloc();
extern char *FindProgram();

/**/
int call (status, this_program, argvec)
     union wait *status;
     char *this_program;
     char **argvec;
{
  int pid, offered_pid;
  extern char **environ;

  if (!rindex (this_program, '/')) {
    if ((this_program = FindProgram (this_program)) == NULL)
      return 0;
  }
  
  if (!FileExecutable (this_program))
    return 0;
  
  pid = vfork ();

  if (pid == -1) {
    logerr ("Can't fork");
    return 0;
  }

  if (!pid) {
    /* child */
    /* close open files ? */
    execve (this_program, argvec, environ);
    logerr ("Can't exec");
    _exit (1);
    return 1;			/* to make lint happy */
  }
  else {
    /* parent */
    /* here we must redefine actual interrupt handler. */
    while ( ((offered_pid = wait (status)) != pid) && (offered_pid != -1))
      ;				/* nothing to do */

    
    if (offered_pid == -1) {
      return 0;
    }
    /* here we must reconstruct old sighandl */
    if (status->w_status)
      return 0;
    else
      return 1;
  }
/*NOTREACHED*/
  return 1;
}

/**/
int call_editor (editor, file, contents, newcontents)
     char *editor, *file, *contents;
/*     unsigned long *newcontents; */
     char **newcontents;
{
  /*
   * Calls editor "editor" with file "file" and returns its
   * contents after the editor session in "newcontents".
   * Return value is the length of the new text.
   *
   * On failure, 0 is returned to indicate the error. newcontents
   * is *not* updated and points to nowhere. On error the file
   * will be removed.
   *
   * If "contents" points to a valid text, this text is put (not appended)
   * into the temporary file before editor starts. Text must be
   * NULL terminated, otherwise strange things will happen...
   */
  
  FILE *fid;
  char *new;
  char cmd[MAXNAMLEN];
  int length;
  union wait status;
  struct stat sbuf;
  char buf[100];
  char *argvec[10];

  *newcontents = NULL;		/* don't get confused on error. */

  Register (file, TYPEF);
  if ((fid = fopen (file, "w")) == NULL) { /* create a file */
    (void)sprintf (buf,"Can't open temporary file %s.", file);
    UnRegister (file, TYPEF);
    logerr (buf);
    return -1;
  }

  if (contents && *contents) {
    length = strlen (contents);
    
    if (fwrite (contents, sizeof (char), length, fid) != length) {
      (void)sprintf (buf, "lost bytes while writing to %s.", file);
      logerr (buf);
      (void)fclose (fid);
      RemoveFile (file);
      UnRegister (file, TYPEF);
      return -1;
    }
  }
  
  (void)fclose (fid);
  
  (void)sprintf (cmd, "%s %s", editor, file);
  (void)sprintf (buf, "starting up %s...", cmd);
  logmsg (buf);

  argvec[0] = editor;
  argvec[1] = file;
  argvec[2] = (char *) NULL;

  /*  if (retcode = system (cmd)) { */
  /*VARARGS2*/
  if (! call (&status, editor, argvec)) {
    (void)sprintf (buf, "Editor %s exited abnormally.", editor);
    logerr (buf);
    RemoveFile (file);
    UnRegister (file, TYPEF);
    return -1;
  }

  if (stat (file, &sbuf) == -1) {
    (void)sprintf (buf,"Can't stat temporary file %s.", file);
    logerr (buf);
    return -1;
  }
    
  if ((fid = fopen (file, "r")) == NULL) {
    (void)sprintf (buf,"Can't reopen temporary file %s.", file);
    logerr (buf);
    RemoveFile (file);
    UnRegister (file, TYPEF);
    return -1;
  }
  RemoveFile (file);
  UnRegister (file, TYPEF);
  length = sbuf.st_size;
  if ((new = malloc ((unsigned)(sizeof (char) * (length + 1)))) == NULL) {
    logerr ("Can't malloc for new");
    (void)fclose (fid);
    return -1;
  }
  
  if (!fread (new, sizeof (char), length, fid)) {
    (void)sprintf (buf, "lost bytes while reading from %s.", file);
    logerr (buf);
    (void)fclose (fid);
    return -1;
  }
  new[length] = NULL;

  (void)fclose (fid);
  *newcontents = new;
  return length;
}
