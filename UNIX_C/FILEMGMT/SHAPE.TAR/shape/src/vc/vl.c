/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: vl.c[3.6] Thu Feb 23 18:14:43 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/vl.c[3.1]
 * 	Thu Feb 23 18:14:43 1989 axel@coma published $
 *  --- empty log message ---
 *  vl.c[3.2] Thu Feb 23 18:14:43 1989 axel@coma published $
 *  --- empty log message ---
 *  vl.c[3.4] Thu Feb 23 18:14:43 1989 axel@coma published $
 *  --- empty log message ---
 *  vl.c[3.5] Thu Feb 23 18:14:43 1989 axel@coma save $
 *  --- empty log message ---
 *  vl.c[3.6] Thu Feb 23 18:14:43 1989 axel@coma published $
 *  --- empty log message ---
 */

#include <stdio.h>
#include <strings.h>

#include "ParseArgs.h"
#include "vl.h"

/*
 * global variables
 */
char vl_cwd[1024];			/* current working dir */

main (ac, av)
     int ac;
     char **av;
{
  register int i;
  int newac;
  char **newav;
  register char *cp;
  extern char *getwd();
  register int retcode;
  extern char **rearrange_args();

  retcode = 0;
  (void)getwd (vl_cwd);			/* get cur working dir */
  
  PutProgramName ((cp = rindex (av[0], '/')) ? ++cp : av[0]);

  CheckProgramName ((cp = rindex (av[0], '/')) ? ++cp : av[0]);	
  /* if I'm vlog set option -L */
  
  if (ac == 1) {
    InitReportVersion ();
    retcode = ReportVersionInfo ("");
  }
  else {
    extern OptDesc odesc[];
    
    ParseArgs (ac, av, &newac, &newav, odesc);

    InitReportVersion ();
    
    if (!newac) {
      if (IsOptionSet(VL_O_LOGMSG)) {
	fprintf (stderr, "%s: Option -L requires a version name\n",
		 GetProgramName());
	exit (1);
      }
      retcode = ReportVersionInfo ("");
    }
    else { 

      /*
       * if one argument is a directory and another argument
       * is a file then the non local filenames must be preceeded by
       * its pathnames on output. Also do files first and
       * then directories, separated by a string containing the
       * path.
       */
      if (a_dir_and_a_file (newac, newav)) {
	newav = rearrange_args (newac, newav); /* first files then dirs */
      }

      for (i = 0; i < newac; i++) {
	retcode = ReportVersionInfo (newav[i]);
      }
    }
  }
  
  FlushInfo();
  exit (retcode);
}

/*ARGSUSED*/
handle_R_option (o, a) char *o, *a; {
  extern char *version();

  printf ("This is %s version %s.\n", GetProgramName(), version ());
  printf ("AFS version %s.\n", af_version());
  exit (0);
}
