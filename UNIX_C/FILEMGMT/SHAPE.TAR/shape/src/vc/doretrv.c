/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: doretrv.c[3.12] Thu Feb 23 18:13:27 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/doretrv.c[3.6]
 * 	Thu Feb 23 18:13:27 1989 axel@coma published $
 *  --- empty log message ---
 *  doretrv.c[3.8] Thu Feb 23 18:13:27 1989 axel@coma published $
 *  --- empty log message ---
 *  doretrv.c[3.9] Thu Feb 23 18:13:27 1989 axel@coma save $
 *  --- empty log message ---
 *  doretrv.c[3.10] Thu Feb 23 18:13:27 1989 axel@coma save $
 *  --- empty log message ---
 *  doretrv.c[3.11] Thu Feb 23 18:13:27 1989 axel@coma published $
 *  --- empty log message ---
 *  doretrv.c[3.12] Thu Feb 23 18:13:27 1989 axel@coma published $
 *  --- empty log message ---
 */

#include <sys/file.h>
#include <pwd.h>
#include <stdio.h>
#include <strings.h>
#include "afs.h"
#include "retrv.h"
#include "project.h"
#include "locks.h"

extern struct Transaction ThisTransaction;
extern unsigned int options;

#ifndef ERROR
#define ERROR -1
#endif

RetrieveAFile (fname, vdesc, proj, destpath)
     char *fname, *destpath;
     struct Vdesc *vdesc;
     Project *proj; {
 /*
  *  NOTE: use of variant attribute in af_getkey is not yet functional.
  *        The parameter, however, is necessary to occupy the slot.
  *        Implementation of variant selection may make it necessary
  *        to add another parameter to this procedure.
  */
       char spath[MAXNAMLEN], origpath[MAXNAMLEN], name[MAXNAMLEN], *afname,
       *aftype, *afvariant = NULL, messg[80], vsymname[80], *lbuf, *busyloc,
       tname[MAXNAMLEN], *getattr(), *vnum(), *mktemp(), *malloc(),
       destname[256], lockdir[256], lockfn[256], *intent, *getintent(),
       *lockerid();
       FILE *vfil, *bfile, *tfil;
       Af_attrs reqattrs, fattrs;
       Af_set hits;
       Af_key busy, tkey, tmpkey, *busykey, *thiskey = &tkey;
       Af_user *locker;
       int nudattr = 0, nhits, nbytes;
       unsigned int pstat = 0;
       register int i;

       if (!fname) return;
       af_initattrs (&reqattrs);
       busykey = &busy;
       getsyspath (fname, proj, spath, origpath, name);
       afname = af_afname (name);
       aftype = af_aftype (name);
       /* start fill out the warrant -- first 3 items may differ */
       (void)strcpy (reqattrs.af_name, afname);
       (void)strcpy (reqattrs.af_type, aftype);
       (void)strcpy (reqattrs.af_syspath, spath);

       /* ... the following settings will remain constant */
       if (options & VSPECSET) {
	 if (vdesc->v_vno) {
	   reqattrs.af_gen = gen(vdesc->v_vno);
	   reqattrs.af_rev = rev(vdesc->v_vno);
	 }
	 else {
	   (void)sprintf (vsymname, "%s=%s", SYMNAME, vdesc->v_spec);
	   reqattrs.af_udattrs[nudattr] = vsymname;
	   nudattr++;
	 }
       }
       if (options & ATTRDEF) {
	 reqattrs.af_udattrs[nudattr] = 
	   getattr (vdesc->v_attrf, proj, aftype, REWIND);
	 if (reqattrs.af_udattrs[nudattr]) nudattr++;
	 while (reqattrs.af_udattrs[nudattr] = getattr (vdesc->v_attrf, 
							  proj, aftype, NEXT))
	   nudattr++;
       }
       if ((options & GENSET) && (!(options & VSPECSET))) {
	 reqattrs.af_gen = vdesc->v_genno;
       }
       if (options & AUNSET) {
	 (void)strcpy (reqattrs.af_author.af_username, vdesc->v_aunam);
	 (void)strcpy (reqattrs.af_author.af_userhost, vdesc->v_auhost);
       }
       if (options & STATSET) {
	 reqattrs.af_state = vdesc->v_state;
       }
       /* descriptive attributes are filled in now. 
	* lets try to find something 
	*/
       if (fail(af_find(&reqattrs, &hits))) {
	 af_perror (fname);
	 abort_this(TRUE);
       }
       Register ((char *)&hits, AFSET);
       
       /* Now lets see what kind of deed needs to be done */
       nhits = af_nrofkeys (&hits);
       if (nhits == 0) {
	 (void)sprintf (messg, "No appropriate version of %s.", fname);
	 logmsg (messg);
	 (void)sprintf (messg, NORESTORE, fname);
	 logmsg (messg);
	 abort_this(FALSE);
       }
       if (nhits == 1) {
	 if (af_setgkey (&hits, 0, &tkey) == ERROR) {
	   af_perror ("af_setgkey");
	   abort_this (TRUE);
	 }
       }
       else if (nhits > 1) {
	 if (fail(af_sortset(&hits, AF_ATTSTIME))) {
	   af_perror ("af_sortset");
	   abort_this (TRUE);
	 }
	 if (!(options & DATESET)) {
	   if (af_setgkey (&hits, nhits-1, &tkey) == ERROR) {
	     af_perror ("af_setgkey");
	     abort_this (TRUE);
	   }
	 }
	 else { /* some cutoff-date was specified */
	   /* Don't consider busy version here */
	   af_setgkey (&hits, 0, &tmpkey);
	   if (af_rstate (&tmpkey) == AF_BUSY) {
	     af_setrmkey (&hits, &tmpkey);
	     nhits--;
	   }
	   for (i = nhits; i > 0; i--) {
	     if (af_setgkey (&hits, i-1, &tkey) == ERROR) {
	       af_perror ("af_setgkey");
	       abort_this (TRUE);
	     }
	     if (fail(af_gattrs(thiskey, &fattrs))) {
	       af_perror ("af_gattrs");
	       abort_this (FALSE);
	     }
	     if (fattrs.af_stime >= vdesc->v_time) {
	       af_setrmkey (&hits, thiskey);
	       udafree (&fattrs);
	     }
	     else {
	       udafree (&fattrs);
	       break;
	     }
	   } /* end loop */
	   if ((nhits = af_nrofkeys (&hits)) == 0) {
	     (void)sprintf (messg, "No appropriate version of %s.", fname);
	     logmsg (messg);
	     abort_this (FALSE);
	   }
	 } /* end of else (some cut-off date) */
	 if ((options & XACT) && (nhits > 1)) {
	   (void)sprintf (messg, "No exact hit for %s. (got %d)", fname, nhits);
	   logmsg (messg);
	   (void)sprintf (messg, NORESTORE, fname);
	   logmsg (messg);
	   abort_this (FALSE);
	 }
       }
       else {
	 (void)sprintf (messg, "%d is an unreasonble number of hits.", nhits);
	 logerr (messg);
	 abort_this (TRUE);
       }

       if (fail(af_gattrs(thiskey, &fattrs))) {
	 af_perror ("af_gattrs");
	 abort_this (FALSE);
       }
       Register ((char *)&fattrs, AFATTRS);
       /* at this point we do have a single af_key and 'thiskey' points 
	* at it. now decide what 
	* to do with it. fattrs contains its attributes.
	*/
       switch (options & (TYPEOUT | COPY | LOCKIT)) {
       case TYPEOUT:
	 if (!(vfil = af_open (thiskey, "r"))) {
	   af_perror ("af_open");
	   abort_this (TRUE);
	 }
	 mkvstring (messg, thiskey);
	 logdiag (messg);
	 lbuf = malloc ((unsigned)fattrs.af_size);
	 nbytes=fread (lbuf, sizeof (*lbuf), (Size_t)fattrs.af_size, vfil);
	 WriteXPand (lbuf, nbytes, stdout, thiskey);
	 free (lbuf);
	 af_close (vfil);
	 UnRegister ((char *)&hits, AFSET);
	 af_dropset (&hits);
	 UnRegister ((char *)&fattrs, AFATTRS);
	 udafree (&fattrs);
	 return;
	 break;
       case COPY:
	 /* This option creates a plain UNIX file from the specified
	  * AFS file. The created copy is - in general - an object without
	  * history. If, however, the copy happens to go into the 
	  * history-directory (the one containing the archive) it will
	  * 'automatically' be considered the busy-version.
	  * If - in this case - a copy replaces a formerly locked busy-version,
	  * the lock will be released.
	  */
	 busyloc = destpath ? destpath : ".";
	 (void)sprintf (destname, "%s%s%s", destpath ? busyloc : "", 
		  destpath ? "/" : "", name);
	 if ((tfil = fopen (destname, "r")) == NULL) {
	   /* take this as test for presence */
	   if (access (busyloc, W_OK) == 0) { /* may we create ? */
	     pstat |= DOIT; /* No scruples if no busyvers current */
	   }
	   else {
	     (void)sprintf (messg, "write permission for directory %s denied.",
		      busyloc);
	     logerr (messg);
	     pstat |= DENIED;
	   }
	 }
	 else { /* file exists */
	   (void)fclose (tfil);
	   if (access (destname, W_OK) < 0) {
	     if (access (busyloc, W_OK) == 0) {
	       (void)sprintf (messg, "%s write-protected, re-create it ?",
			destname);
	       if (options & QUIETPLEASE) {
		 pstat |= (options & FORCE) ? (RECREATE | DOIT) : DENIED;
	       }
	       else {
		 if (ask_confirm (messg, "no")) {
		   pstat |= DENIED;
		 }
		 else {
		   pstat |= (RECREATE | DOIT);
		 }
	       }
	     }
	     else { 
	       (void)sprintf (messg, "no write permission for %s", destname);
	       logmsg (messg);
	       pstat |= DENIED;
	     }
	   }
	   else { /* write access on destfile */
	     if (strcmp (busyloc, ".")) {
	       (void)sprintf (messg, "%s exists and is writable. Overwrite it ?",
		      destname);
	       if (options & QUIETPLEASE) {
		 pstat |= (options & FORCE) ? DOIT : 0;
	       }
	       else {
		 if (!ask_confirm (messg, "no")) {
		   pstat |= DOIT;
		 }
	       }
	     }
	     else { /* current dir! - test for lock */
	       if (fail (af_getkey (spath, afname, aftype, AF_BUSYVERS,
				    AF_BUSYVERS, afvariant, &busy)))
		 { /* No busy-key -- no lock, this is impossible here */
		   pstat |= DOIT;
		 }
	       else {
		 if (lockeruid (vc_testlock_g(&busy)) == getuid ()) {
		   (void)sprintf (messg, "Give up lock on %s and overwrite it ?",
			    destname);
		   if (options & QUIETPLEASE) {
		     pstat |= (options & FORCE) ? DOIT : 0;
		   }
		   else {
		     if (!ask_confirm (messg, "no")) {
		       pstat |= DOIT;
		       (void)vc_unlock_g(&busy);
		     }
		     else {
		       pstat |= DENIED;
		     }
		   }
		 }
		 else {
		   pstat |= DOIT;
		 }
	       }
	     }
	   }
	 }
	 if (pstat & DOIT) {
	   if ((vfil=af_open(thiskey, "r")) == NULL) {
	     af_perror ("af_open");
	     abort_this (TRUE);
	   } 
	   (void)sprintf (tname, "%s%s%s", destpath ? destpath : "",
		    destpath ? "/" : "", mktemp("retrvXXXXXX"));
	   if ((bfile = fopen (tname, "w")) == NULL) {
	     (void)sprintf (messg, "cannot create tmp-file (%s) for writing.",
		      tname);
	     logerr (messg);
	     abort_this (TRUE);
	   }
	   Register (tname, TYPEF);
	   (void)sprintf (messg, "%s%s%s[%s] -> %s", spath[0] ? spath : "",
		    spath[0] ? "/" : "", name, vnum (thiskey), destname);
	   logdiag (messg);
	   lbuf = malloc ((unsigned)fattrs.af_size);
	   nbytes=fread (lbuf, sizeof (*lbuf), (Size_t)fattrs.af_size, vfil);
	   WriteXPand (lbuf, nbytes, bfile, thiskey);
	   free (lbuf);
	   (void)fclose (bfile); (void)fclose (vfil);
	   (void)unlink (destname);
	   if (link (tname, destname) < 0) {
	     perror (destname);
	     abort_this (TRUE);
	   }
	   (void)chmod (destname, 0444); 
	   UnRegister (tname, TYPEF);
	   (void)unlink (tname);
	 }
	 else {
	   (void)sprintf (messg, "%s not retrieved", fname);
	   logmsg (messg);
	 }
	 UnRegister ((char *)&hits, AFSET);
	 af_dropset (&hits);
	 UnRegister ((char *)&fattrs, AFATTRS);
	 udafree (&fattrs);
	 return;
	 break;
       case LOCKIT:
	 /*
	  *  Before a version is retrieved, set-busy, and locked, the
	  *  following preconditions must be fulfilled:
	  *  - the retrieve must go to the directory containing the 
	  *    archive directory. -> current directory
	  *  - the retrieved version must not be locked by anybody but
	  *    the calling user.
	  *  - the current directory must grant write access to the 
	  *    calling user.
	  *  - if some busy-version would be overwritten by the retrieve,
	  *    the user is asked if she wants that
	  */
	 if ((destpath) && (destpath[0])) {
	   (void)sprintf (messg, "can't checkout (with lock) to %s.", destpath);
	   logmsg (messg);
	   abort_this (FALSE);
	 }
	 (void)sprintf (lockfn, "%s%s%s", spath[0] ? spath : "", 
		  spath[0] ? "/" : "", name);
	 (void)sprintf (lockdir, "%s", spath[0] ? spath : ".");
	 /*
	  *  The following checks are based on the permission information
	  *  stored in the archive files. It is unclear how
	  *  to properly handle vanilla filesystem related inquiries.
	  */
	 if (fail (af_getkey (spath, afname, aftype, AF_LASTVERS,
			      AF_LASTVERS, afvariant, &busy))) {
	   /* well, this case seems to be impossible. If we get here, */
	   /* at least _*some*_ version should be present */

	   af_perror ("RetrieveAFile -- no version in sight.");
	   abort_this (TRUE);
	 }
	 else { /* there is a version */
	   if (((lockeruid (locker = af_testlock (&busy, AF_GLOBALLOCK))) 
		== getuid ()) || !(locked (locker))) {
#ifdef AFACCOK
	     if (af_access (spath[0] ? spath : ".", afname, 
			    aftype, W_OK) == 0) {
#else
	     if (access (fname, W_OK) == 0) {
#endif
	       (void)sprintf (messg, "Writable %s exists, overwrite it ?", lockfn);
	       if (options & QUIETPLEASE) {
		 pstat |= (options & FORCE) ? DOIT : DENIED;
	       }
	       else {
		 pstat |= (ask_confirm (messg, "no")) ? DENIED : DOIT;
	       }
	     }
	     else if (access (lockdir, W_OK) == 0) {
	       if (access (lockfn, F_OK) == 0) {
		 (void)sprintf (messg, 
			  "Write access on %s denied. Overwrite it anyway ?",
			  lockfn);
		 if (options & QUIETPLEASE) {
		   pstat |= (options & FORCE) ? DOIT : DENIED;
		 }
		 else {
		   pstat |= (ask_confirm (messg, "no")) ? DENIED : DOIT;
		 }
	       }
	       else pstat |= DOIT;
	     }
	     else { /* no write access on current dir */
	       (void)sprintf (messg, "Can't create in %s.", lockdir);
	       abort_this (TRUE);
	     }
	     if (!locked(locker)) {
	       if (!vc_lock_g(&busy, getuid())) {
		 af_perror ("af_lock");
		 abort_this (TRUE);
	       }
	     }
	   }
	   else { /* busy version locked by someone else */
	     pstat |= DENIED;
	     (void)sprintf (messg, "%s already locked by %s.", lockfn, 
		      lockerid(locker));
	     logmsg (messg);
	   }
	 } 
	 /* now all the checks are done. set retrieved version busy and 
	  * create it in lockdir.
	  */
	 if ((pstat & DOIT) && (!(pstat & DENIED))) {
	   if (! ((options & QUIETPLEASE) || (options & FORCE)))
	     intent = getintent ("Describe intended changes ?", (char *)NULL);
	   else intent = (char *)NULL;
	   /* setbusy sets just the attributes. data must be moved manually */
	   if ((vfil=af_open(thiskey, "r")) == NULL) {
	     af_perror ("af_open");
	     abort_this (TRUE);
	   } 
	   (void)sprintf (tname, "%s/%s", lockdir, mktemp("retrvXXXXXX"));
	   if ((bfile = fopen (tname, "w")) == NULL) {
	     (void)sprintf (messg, "cannot create tmp-file (%s) for writing.",
		    tname);
	     logerr (messg);
	     af_close (vfil);
	     abort_this (TRUE);
	   }
	   Register (tname, TYPEF);
	   (void)sprintf (messg, "%s%s%s[%s] -> %s%s%s", spath[0] ? spath : "", 
		    spath[0] ? "/" : "", name,
		    vnum (thiskey), spath[0] ? spath : "", 
		    spath[0] ? "/" : "",
		    name);
	   logdiag (messg);

	   /* there's no attribute citation for locked busy versions .... */
	   lbuf = malloc ((unsigned)fattrs.af_size);
	   nbytes=fread (lbuf, sizeof (*lbuf), (Size_t)fattrs.af_size, vfil);
	   if (fwrite (lbuf, sizeof (*lbuf), nbytes, bfile) != nbytes) {
	     logerr ("fatal: couldn't write busy file.");
	     abort_this (TRUE);
	   }
	   free (lbuf);
	   (void)fclose (bfile);
	   (void)chmod (tname, 0644);
	   af_close (vfil);
	   /* if no busyversion was present, busykey contains garbage */
	   /* this might be responsible for trouble here */
	   (void)unlink (fname);
	   (void)link (tname, fname);
	   ThisTransaction.tr_done = TRUE;
	   UnRegister (tname, TYPEF);
	   (void)unlink (tname);
	   if (af_crkey (spath, afname, aftype, busykey) < 0) {
	     af_perror ("af_crkey");
	     abort_this (TRUE);
	   }
	   if (fail(af_setbusy(busykey, thiskey))) {
	     af_perror ("af_setbusy");
	     abort_this (TRUE); /* check out what happens in abort_this */
	   }
	   (void)vc_lock_g(busykey, getuid());
	   if (intent) {
	     char *intattr;
	     intattr = malloc ((unsigned)(strlen (intent)+strlen (INTENT)+ 1));
	     (void)sprintf (intattr, "%s%s", INTENT, intent);
	     if (fail(af_sudattr (busykey, AF_REPLACE, intattr)))
	       af_sudattr (busykey, AF_ADD, intattr);
	     free (intattr);
	   }
	 }
	 else { /* denied or not doit */
	   (void)sprintf (messg, NORESTORE, ThisTransaction.tr_fname);
	   logmsg (messg);
	 }
	 UnRegister ((char *)&fattrs, AFATTRS);
	 udafree (&fattrs);
	 UnRegister ((char *)&hits, AFSET);
	 af_dropset (&hits);
	 break;
       default:
	 logerr ("fatal: illegal action switch in doretrv.c");
	 break;
       }
     }
