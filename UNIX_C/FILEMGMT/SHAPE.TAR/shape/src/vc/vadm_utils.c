/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: vadm_utils.c[3.3] Thu Feb 23 18:14:24 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/vadm_utils.c[3.0]
 * 	Thu Feb 23 18:14:24 1989 axel@coma published $
 *  --- empty log message ---
 *  vadm_utils.c[3.1] Thu Feb 23 18:14:24 1989 axel@coma published $
 *  --- empty log message ---
 *  vadm_utils.c[3.2] Thu Feb 23 18:14:24 1989 axel@coma save $
 *  --- empty log message ---
 *  vadm_utils.c[3.3] Thu Feb 23 18:14:24 1989 axel@coma published $
 *  --- empty log message ---
 */

#include <stdio.h>
#include <strings.h>
#include <afs.h>
  
#include "vadm.h"
#include "afsapp.h"
#include "vadmdefs.h"

extern char *malloc();

/**/
int GetGenerationNumber (version)
     char *version;
{
  /*
   * Returns the generation number (as an int) from a version specification
   * (as a string), e.g.: 2.1 ==> 2
   */
  register int i;
  char tmp[80];
    
  if ( (!version) || (! *version) || (*version == '.') ) return -1;

  i = 0;
  while (*version) {
    if (*version == '.') {
      tmp[i] = '\0';
      return atoi(tmp);
    }
    else {
      tmp[i] = *version;
      version++; i++;
    }
  }
  return atoi(tmp);
}

/**/
int GetRevisionNumber (version)
     char *version;
{
  /*
   * Returns the revision number (as an int) from a version specification
   * (as a string), e.g.: 2.1 ==> 2
   */
  register int i;
  char tmp[80];
  register char *cp;
  
  if ( (!version) || (! *version) ) return -1;

  if (! (cp = rindex (version, '.'))) return -1;

  cp++;

  if (!*cp) return -1;		/* version_num was: any.\0 */
  
  i = 0;
  while (*cp) {
    tmp[i] = *cp;
    cp++; i++;
  }
  tmp[i] = '\0';
  return atoi(tmp);
}

logmsg (msg) char *msg; {
  if (!IsOptionSet(Vopt_quiet)) {
    fprintf (stdout, "%s\n", msg);
  }
}

logwng (msg) char *msg; {
  if (!IsOptionSet(Vopt_quiet)) {
    fprintf (stdout, "Warning: %s\n", msg);
  }
}

logerr (msg) char *msg; {
  fprintf (stderr, "%s: %s\n", progname, msg);
}

Sfunc_t interrupt_action () { /* is executed by appropriate signal handler */

  if (ask_confirm ("\nDo you really want to quit this ?", "yes"))
    exit (1);
  else
    return;
}
