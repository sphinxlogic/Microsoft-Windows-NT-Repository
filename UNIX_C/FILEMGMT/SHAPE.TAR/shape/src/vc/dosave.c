/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: dosave.c[3.21] Thu Feb 23 18:13:30 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/dosave.c[3.8]
 * 	Thu Feb 23 18:13:30 1989 axel@coma save $
 *  Intention for change:
 *  This is still a test. A minute ago, I was able to set an intention
 *  but now I doubt, that I'll be allowed to set a user defined attribute
 *  to the bus
 *  dosave.c[3.9] Thu Feb 23 18:13:30 1989 axel@coma save $
 *  Intention for change:
 *  This is still a test. A minute ago, I was able to set an intention
 *  but now I doubt, that I'll be allowed to set a user defined attribute
 *  to the bus
 *  dosave.c[3.15] Thu Feb 23 18:13:30 1989 axel@coma published $
 *  --- empty log message ---
 *  dosave.c[3.19] Thu Feb 23 18:13:30 1989 axel@coma published $
 *  --- empty log message ---
 *  dosave.c[3.20] Thu Feb 23 18:13:30 1989 axel@coma save $
 *  --- empty log message ---
 *  dosave.c[3.21] Thu Feb 23 18:13:30 1989 axel@coma published $
 *  --- empty log message ---
 */

#include <strings.h>
#include <stdio.h>
#include <pwd.h>
#include "afs.h"
#include "save.h"
#include <sys/types.h>
#include <sys/stat.h>
#include "project.h"
#include "locks.h"

extern unsigned int options;
extern char tfname[], vcomment[], atr_fname[], symname[];
extern int newvnum;
extern struct Transaction ThisTransaction;

SaveAFile (fname, proj) char *fname; Project *proj; {
/*
 * Save working file with the given name in the project location (syspath)
 * determined by proj. Check for changes before saving.
 * Attributes are also derived from the proj-context.
 * Unless QUIETPLEASE is set, the user will be prompted for a note 
 * describing the changes to be saved.
 * On the locking strategy:
 * An author can save a busy version, only if he holds a lock (update
 * privilege) for the document history. When an archive is newly
 * created from a (busy) file, such a lock is assumed to be set.
 * Upon save operations - which are conceptually local to a user context -
 * the lock is kept. A lock can be released by submitting a version
 * to the project and explicitly giving up the lock (option). After that,
 * no more 'saves' are possible even though the user is in unix sense still
 * owner of his local archive-file. This is so because we guarantee object
 * consistency in a project among several databases.
 * Locks on certain documents can be obtained through means of 'reserve'
 * which is a User <--> Project transaction. Locally created documents
 * are placed under project discipline (or configuration control) the
 * first time they are submitted -- even if they have not been reserved
 * yet. Locks have token-character, i.e. they may be passed around, but
 * never ever be duplicated.
 */
 /*
  *  NOTE: use of variant attribute in af_getkey is not yet functional.
  *        The parameter, however, is necessary to occupy the slot.
  *        Implementation of variant selection may make it necessary
  *        to add another parameter to this procedure.
  */
  char spath[MAXNAMLEN], origpath[MAXNAMLEN], name[MAXNAMLEN], 
  *afname, *aftype, *afvariant = NULL, str[80], messg[80], *note, 
  *getnote(), *gettxt(), *vnum(), *getattr(), *as;
  int truth = TRUE;
  Af_attrs reqattrs, busyattrs, sattrs;
  Af_key busy, lastsave, skey, *newkey, ngkey, tmpkey;
  Af_set junkset;

  if (!fname) return;
  
  af_initattrs (&reqattrs);
  getsyspath (fname, proj, spath, origpath, name); 
               /* splits name and pathname prefix */

  afname = af_afname (name);
  aftype = af_aftype (name);
  /* give a little feedback ... */
  if (spath[0]) {
    (void)sprintf (messg, "[%s]%s:", spath, name);
  }
  else {
    (void)sprintf (messg, "%s:", name);
  }
  logmsg (messg);
  
  if (options & SYMNSET) {
    af_initattrs (&sattrs);
    (void)strcpy (sattrs.af_syspath, spath);
    (void)strcpy (sattrs.af_name, afname);
    (void)strcpy (sattrs.af_type, aftype);
    (void)sprintf (str, "%s=%s", SYMNAME, symname);
    sattrs.af_udattrs[0] = str;
    sattrs.af_udattrs[1] = NULL;
    af_find (&sattrs, &junkset);
    if (af_nrofkeys(&junkset)) {
      af_setgkey (&junkset, 0, &tmpkey);
      (void)sprintf (messg, "symbolic name %s already in use by %s[%s]", 
	       symname, fname, vnum(&tmpkey));
      logerr (messg);
      af_dropset (&junkset);
      af_dropkey (&tmpkey);
      abort_this (FALSE);
    }
    else {
      af_cleanup ();		/* ??? */
    }
  }
  if (fail(af_getkey (spath, afname, aftype, AF_BUSYVERS, 
		      AF_BUSYVERS, afvariant, &busy))) {
    (void)sprintf (messg, "%s[busy]", fname);
    af_perror (messg);
    abort_this (TRUE);
  }

  if (fail(af_gattrs (&busy, &busyattrs))) {
    (void)sprintf (messg, "Cannot access attributes of %s.", name);
    af_perror (messg);
    af_dropkey (&busy);
    abort_this(TRUE);
  }
  if (fail(af_getkey (spath, afname, aftype, AF_LASTVERS,
		      AF_LASTVERS, afvariant, &lastsave))) {
    logmsg ("creating archive");
    if (options & TXTFSET) {
      note = gettxt (tfname);
    }
    else {
      note = getnote ("How about describing the purpose of this document ?", 
		      truth, TRUE, (char *)NULL);
    }
    if (lockeruid(vc_lock_g(&busy, (Uid_t)getuid())) != (Uid_t)getuid()) {
      af_perror ("cannot lock archive");
      af_dropkey (&busy);
      abort_this (TRUE);
    }
    if (fail(af_saverev (&busy, &skey))) {
      af_perror (fname);
      af_dropkey (&busy);
      abort_this(TRUE);
    }
    newkey = &skey;
    ThisTransaction.tr_done = TRUE;
    if (options & SUBMIT) {
      af_sstate (newkey, AF_PROPOSED);
      af_sstate (newkey, AF_PUBLISHED);
    }
    (void)sprintf (messg, "saved version %s", vnum (newkey));
    logmsg (messg);
  }    /* This was handling of newly created archive */
  else {
#ifdef PROJIMPL
    if (!mylock (&busy, proj)) /* { */ /* -- emacs c-mode */
#else
      if (!mylock (&busy, (Project *)NULL)) {
#endif
	(void)sprintf (messg, "%s not saved.", fname);
	logmsg (messg);
	af_dropkey (&busy);
	abort_this (FALSE);
      }
    if (changed (&busy, &lastsave, &truth)) { 
      /* Version alias problem: copy or ref */
      if (options & TXTFSET) {
	note = gettxt (tfname);
      }
      else if (options & MSGSET) {
	note = vcomment;
      }
      else {
	char *intent = (char *)0;
	if (options & (LCKGIVEUP | SUBMIT))
	  intent = af_rudattr (&busy, INTENT);
	note = getnote ("Do you want to comment your modifications ?", truth, 
			FALSE, intent);
	if (intent) free (intent);
	af_sudattr (&busy, AF_REMOVE, INTENT);
      }
      if (fail(af_saverev (&busy, &skey))) {
	af_perror (fname);
	af_dropkey (&busy);
	abort_this(TRUE);
      }
      newkey = &skey;
      ThisTransaction.tr_done = TRUE;
      af_sudattr (newkey, AF_REMOVE, INTENT);
      if (options & NEWGEN) {
	if (myproject(proj)) {
	  af_newgen (newkey, &ngkey);
	  (void)sprintf (messg, 
		   "saved version %s (aliassed by ",
		   vnum (newkey));
	  (void)sprintf (messg, "%s%s due to new generation)", messg, vnum(&ngkey)); 
	  logmsg (messg);
	  af_dropkey (newkey);
	  newkey = &ngkey;
	  if (options & SUBMIT)
	    setpublished (newkey);
	}
	else {
	  logmsg ("You must be project-admin to increase generation number.");
	}
      }
      else {
	(void)sprintf (messg, "saved version %s", vnum (newkey));
	logmsg (messg);
	if (options & SUBMIT) 
	  setpublished (newkey);
      }
    }
    else {
      if (options & SUBMIT) {
	char *intent = (char *)0;
	intent = af_rudattr (&busy, INTENT);
	note = getnote ("Do you want to comment your modifications ?", truth,
			FALSE, intent);
	if (intent) free (intent);
	af_sudattr (&busy, AF_REMOVE, INTENT);
	setpublished (&lastsave);
	(void)sprintf 
	  (messg, "%s set to state \"published\" (no changes to be saved)",
	   fname);
	logmsg (messg);
	newkey = &lastsave;
      }
      else {
	(void)sprintf (messg, "%s not saved.", fname);
	logmsg (messg);
	af_dropkey (&busy);
	abort_this(FALSE);
      }
    }
  }
  /* If we get here, something has been saved -- set note */
  if (fail(af_snote (newkey, note))) {
    af_perror ("");
  }
  if (options & SYMNSET) {
    (void)sprintf (str, "%s=%s", SYMNAME, symname);
    as = str;
    af_sudattr (newkey, AF_ADD, as);
  }
  if (options & SETVNUM) {
    if (!(mkvno(vnum(newkey)) == newvnum)) { /* do nothing */
      if (af_svnum (newkey, gen(newvnum), rev(newvnum)) < 0) {
	(void)sprintf (messg, "version number %d.%d too small for %s.",
		 gen(newvnum), rev(newvnum), fname );
	logerr (messg);
      }
    }
  }
  if (options & ATTRDEF) {
    as = getattr (atr_fname, proj, aftype, REWIND);
    af_sudattr (newkey, AF_ADD, as);
    while (as=getattr (atr_fname, proj, aftype, NEXT)) {
      af_sudattr (newkey, AF_ADD, as);
    }
  }
  if (options & LCKGIVEUP) {
    if ((lockeruid(vc_unlock_g(&busy))) != (Uid_t)getuid()) {
      af_perror ("af_unlock: foul");
    }
  }
  /* right before we are done, release the version lock on new version */
  (void)vc_unlock_v(newkey);
  af_dropkey (newkey);
  af_dropkey (&busy);
}

changed (new, old, realtruth) Af_key *new, *old; int *realtruth; {
/*
 * Return true if new and old are actually different OR deposit is
 * forced OR if user says 'yes' when asked whether an unchanged version
 * shall be saved anyway.
 * As AFS is still in the tests, this is programmed very defensively.
 */
  FILE *newf, *oldf;
  Af_attrs newat, oldat;
  char *news, *olds, *malloc(), messg[80];

  *realtruth = TRUE;  /* initially assume that something has act. changed */
  if (fail(af_gattrs (new, &newat))) {
    af_perror ("busy-version");
  }
  if (fail(af_gattrs (old, &oldat))) {
    af_perror ("lastsaved-version");
  }
  if (newat.af_size != oldat.af_size) {
    return TRUE;
  }
  else { /* lets have a closer look at 'em */
    if ((news = malloc ((unsigned)newat.af_size)) == NULL) {
      (void)sprintf (messg, "Can't malloc %d bytes.", newat.af_size);
      logmsg (messg);
      abort_this(TRUE);
    }
    if ((olds = malloc ((unsigned)oldat.af_size)) == NULL) {
      (void)sprintf (messg, "Can't malloc %d bytes.", oldat.af_size);
      logmsg (messg);
      free (news);
      abort_this(TRUE);
    }
    if ((newf = af_open (new, "r")) == NULL) {
      af_perror ("busy-version");
      free (news);
      free (olds);
      abort_this(TRUE);
    }
    if ((oldf = af_open (old, "r")) == NULL) {
      af_perror ("lastsaved-version");
      free (news);
      free (olds);
      af_close (newf);
      abort_this(TRUE);
    }
#ifdef ULTRIX_2_0
    if (fread (news, sizeof (char), (unsigned)newat.af_size, newf) == NULL)
#else
    if (fread (news, sizeof (char), (int)newat.af_size, newf) == NULL) 
#endif
      {
      logmsg ("Couldn't read busy version.");
      free (news);
      free (olds);
      af_close (newf);
      af_close (oldf);
      abort_this (TRUE);
    }
#ifdef ULTRIX_2_0
    if (fread (olds, sizeof (char), (unsigned)oldat.af_size, oldf) == NULL) 
#else
    if (fread (olds, sizeof (char), (int)oldat.af_size, oldf) == NULL) 
#endif
      {
      logmsg ("Couldn't read lastsaved version.");
      free (news);
      free (olds);
      af_close (newf);
      af_close (oldf);
      abort_this (TRUE);
    }
    af_close (newf);
    af_close (oldf);
    free (news);
    free (olds);
    if (bcmp (olds, news, (int)newat.af_size)) {
      return TRUE;
    }
    else {  /* Hmmm, looks like nothing has changed ... */
      *realtruth = FALSE; /* return value may be a lie */
      if (options & FORCE) {
	return TRUE;
      }
      else {
	if (options & QUIETPLEASE) {
	  return FALSE;
	}
	if (isatty (fileno (stdin)) && isatty (fileno (stdout))) {
	  (void)sprintf (messg, "There are no changes with respect to the previously saved version.\nSave anyway ?");
	  return !ask_confirm (messg, "no");
	}
	else return FALSE;
      }
    }
  }
}

char *gettxt (fname) char *fname; {
  static char *txt = EMPTYNOTE;
  FILE *txtfil;
  struct stat statbuf;
  static int firsttime = TRUE;

  if (firsttime) {
    firsttime = FALSE;
    if ((txtfil = fopen (fname, "r")) == NULL) {
      logerr ("no descriptive text file");
    }
    else {
      if (fstat (fileno(txtfil), &statbuf) == -1) {
	perror ("couldn't stat");
      }
      else {
	txt = malloc ((unsigned)statbuf.st_size);
	if (!txt) {
	  logerr ("not enough memory for descriptive text.");
	  txt = EMPTYNOTE;
	}
	else {
	  (void)fread (txt, sizeof (char), (Size_t)statbuf.st_size, txtfil);
	  (void)fclose (txtfil);
	}
      }
    }
  }
  return txt;
}

char *getnote (prompt, changeflg, force, intent) char *prompt, *intent; {
  char *tmpname, *mktemp(), *edname, cmd[128], *getenv(), messg[80];
  static char *notetxt;
  FILE *tmpfil;
  struct stat statbuf;
  static int firsttime = TRUE;

  if ((options & QUIETPLEASE) ||
      (!(isatty(fileno(stdin))))) {
    if (intent) goto retintent;
    else return EMPTYNOTE;
  }
  if ((!force) && (!firsttime) && notetxt) {
    if (ask_confirm ("Use previous log message ?", "yes")) {
      return notetxt;
    }
    else {
      free (notetxt);
    }
  }
  firsttime = FALSE;
  if (changeflg) {
    if (!ask_confirm (prompt, "yes"))
      if (intent) goto retintent;
      else return EMPTYNOTE;
  }
  else {
    if (ask_confirm ("The new version is unmodified. Comment it anyway ?", 
		     "no"))
      if (intent) goto retintent;
      else return EMPTYNOTE;
  }
  tmpname = mktemp ("/tmp/afsXXXXXX");
  Register (tmpname, TYPEF);
  if (intent) {
    FILE *tfd;
    tfd = fopen (tmpname, "w");
    if (fwrite (intent, strlen (intent), sizeof (char), tfd) != 
	strlen (intent)) {
      logerr ("write failure on tmp-file");
    }
    (void)fclose (tfd);
  }
  if (edname = getenv ("EDITOR")) {
    (void)sprintf (cmd, "%s %s", edname, tmpname);
    (void)sprintf (messg, "starting up %s ...", edname);
    logmsg (messg);
    if (system (cmd) == NOSHELL) {
      logerr ("couldn't execute shell");
    }
    else {
      if ((tmpfil = fopen (tmpname, "r")) == NULL) {
	logerr ("empty logentry");
	return EMPTYNOTE;
      }
      else {
	(void)unlink (tmpname);
	UnRegister (tmpname, TYPEF);
	if (fstat (fileno(tmpfil), &statbuf) == -1) {
	  perror ("couldn't stat");
	}
	else {
	  notetxt = malloc ((unsigned)statbuf.st_size);
	  if (!notetxt) {
	    logerr ("not enough memory for note text.");
	  }
	  (void)fread (notetxt, sizeof (char), (Size_t)statbuf.st_size, 
		       tmpfil);
	  (void)fclose (tmpfil);
	  return notetxt;
	}
      }
    }
  }
  logerr ("You must set the EDITOR environment variable to write a note");
  return EMPTYNOTE;   /* maybe we should try to read from stdin */
 retintent:
  notetxt = malloc ((unsigned)(strlen (intent) + 1));
  (void)strcpy (notetxt, intent);
  return notetxt;
}

setpublished (key) Af_key *key; {
  /* set specified version to state 'published' */

  int sdiff, oldstate = af_rstate (key);
  register int i;

  if (sdiff = (AF_PUBLISHED - oldstate)) {
    if (sdiff > 0)
      for (i = 1; i <= sdiff; i++) {
	if ((lockeruid(vc_lock_v(key, (Uid_t)getuid()))) != (Uid_t)getuid()) {
	  logerr ("can't change state to published -- locked");
	  return;
	}
	af_sstate (key, oldstate+i);
	(void)vc_unlock_v(key);
      }
    else /* sdiff must be < 0 */
      for (i = 1; i <= abs(sdiff); i++) {
	if ((lockeruid(vc_lock_v(key, (Uid_t)getuid()))) != (Uid_t)getuid()) {
	  logerr ("can't change state to published -- locked");
	  return;
	}
	af_sstate (key, oldstate-i);
	(void)vc_unlock_v(key);
      }
  }
  /* else: state already is published */
}
