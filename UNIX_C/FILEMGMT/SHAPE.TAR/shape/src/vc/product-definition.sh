RULE = test
SYSTEM = bsd_4_3
QUALITY = debug
COMPILER = pcc

BASE = /u/axel/shape/apps
SRCDIR = $(BASE)
INTEGRATOR = shape

#
#  Configuration definition part
#

#CFLAGS = -g -I$(AFSINC) -DBSD43

#
#  Installation specific part
#

INSTALDIR = /u/shape/bin
MINCDIR = /u/shape/src/inc
INSTALTARGETS = isave iretrv ivl ivadm iafsapp.h

#
#  Product definition part
#

COMPONENTS = $(MANUALS) $(MODULES) $(DEFINES)

MODULES = \
	doretrv.c \
	dosave.c \
	mkattr.c \
	project.c \
	retrv.c \
	save.c \
	sighand.c \
	util.c \
	vl.c \
	vldovl.c \
	vlmisc.c \
	vlopt.c \
	vadm.c \
	vadm_utils.c  \
	vadm_note.c \
	vadm_delete.c \
	vadm_promote.c \
	vadm_reserve.c \
	vadm_symname.c \
	vadm_gkeys.c \
	vc_call.c \
	vc_files.c \
	vc_keyboardIo.c \
	vc_lock.c 

DEFINES = \
	afsapp.h \
	locks.h \
	project.h \
	retrv.h \
	save.h \
	typeconv.h \
	vl.h \
	vadm.h \
	vadmdefs.h \
	vc_sysdep.h

MANUALS = \
	retrv.1 \
	save.1 \
	vadm.1 \
	vcintro.1 \
	vl.1 

PRODUCT = vccommands
SUBPRODUCTS = \
	/u/shape/lib/libafs \
	/u/shape/lib/libutil 

AFSLIB = /u/shape/lib/libafs.a
UTLIB = /u/shape/lib/libutil.a

XPHFILES = afsapp.h

AFSINC = /u/shape/src/inc

PROGS = save retrv vl vadm
VERSIONPROTO = /u/shape/lib/version.c
VERSION = version
# busy version of 'version' file MUST be present !

MYINC = save.h
SAVESRC  = save.c dosave.c vc_lock.c mkattr.c $(COMMONSRC)
SAVEOBJS = save.o dosave.o vc_lock.o mkattr.o
RETRSRC = retrv.c doretrv.c mkattr.c vc_lock.c  $(COMMONSRC)
RETROBJS = retrv.o doretrv.o mkattr.o vc_lock.o
VLSRC = vl.c vlmisc.c vldovl.c vlopt.c mkattr.c $(VERSION).c
VLOBJS = vl.o vlmisc.o vldovl.o vlopt.o mkattr.o
VLINC = vl.h afs_huda.h
VADMOBJS = vadm.o vadm_utils.o vadm_note.o vadm_delete.o vadm_promote.o\
	   vadm_symname.o vadm_reserve.o vadm_gkeys.o vc_call.o vc_files.o\
	   vc_keyboardIo.o vc_lock.o util.o sighand.o mkattr.o
VADMSRC = vadm.c vadm_utils.c vadm_note.c vadm_delete.c vadm_promote.c\
	   vadm_symname.c vadm_reserve.c vadm_gkeys.c vc_call.c vc_files.c\
	   vc_keyboardIo.c vc_lock.c util.c sighand.c mkattr.c $(COMMONSRC)
VADMINC = vadm.h vadmdefs.h vc_sysdep.h
COMMON = project.o sighand.o util.o $(VERSION).o
COMMONSRC = project.c sighand.c util.c $(VERSION).c
ALLOBJS = $(SAVEOBJS) $(RETROBJS) $(VLOBJS) $(COMMON)

.BPOOL: $(ALLOBJS)
