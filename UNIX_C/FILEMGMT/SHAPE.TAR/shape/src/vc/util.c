/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: util.c[3.10] Thu Feb 23 18:14:00 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/util.c[3.5]
 * 	Thu Feb 23 18:14:00 1989 axel@coma published $
 *  --- empty log message ---
 *  util.c[3.8] Thu Feb 23 18:14:00 1989 axel@coma published $
 *  --- empty log message ---
 *  util.c[3.9] Thu Feb 23 18:14:00 1989 axel@coma save $
 *  --- empty log message ---
 *  util.c[3.10] Thu Feb 23 18:14:00 1989 axel@coma published $
 *  --- empty log message ---
 */

/*LINTLIBRARY*/
#include <strings.h>
#include <stdio.h>
#include <pwd.h>
#include "afs.h"
#include <sys/stat.h>
#include <sys/file.h>
#include "afsapp.h"
#include "project.h"
#include "locks.h"

extern unsigned int options;

jmp_buf here;

ask_confirm (s, def) char *s, *def; {
  /*
   *  returns true if the answer is equivalent to 'def' (assumption)
   */
  char strbuf[256], answer[10], *cp;

  if (s == (char *)NULL) return TRUE;
  if (!isatty (fileno (stdin))) return TRUE;
  (void)setjmp (here);
  CatchCont ();
  (void)fflush (stdin);
  printf ("%s [%s] ", s, def);
  strbuf[0] = '\0';
  answer[0] = '\0';
  (void)gets (strbuf);
  UnCatchCont ();
  (void)sscanf (strbuf, "%s", answer);
  if (answer[0] == '\0') return TRUE; /* assumption acknowledged */
  cp = answer;
  while (*cp ? (*cp++ |= ' ') : 0); /* make sure answer is lowercase */
  return !strncmp (def, answer, min(strlen(def), strlen(answer)));
}

/*ARGSUSED*/
getsyspath (path, proj, syspath, opath, name) 
     char *path, *syspath, *opath, *name; 
     Project *proj;
/*
 * Normally splits path-prefix and filename-part. If the project structure
 * specifies an explicit syspath (which could be different from the 
 * actual path-prefix) it will be returned in syspath. The path-prefix
 * will be returned in opath.
 */
{
  char *cpt;

  if (cpt = rindex (path, '/')) {
    (void)strncpy (opath, path, cpt - path);
    opath[cpt-path] = '\0';
    (void)strcpy (name, cpt+1);
  }
  else {
    opath[0] = '\0';
    (void)strcpy (name, path);
  }
  (void)strcpy (syspath, opath); /* this is going to be more complex */
}

#define nxt(s) (s = (*(s+strlen(s)+1) != '\0') ? s+strlen(s)+1 : NULL)

/*ARGSUSED*/
char *getattr (attrfile, proj, type, op) 
     char *attrfile, *type ; Project *proj; {
       /* 
	* in initial state, getattr parses all available attribute
	* information, i.e. a user supplied attribute file and the
	* common project specific attribute specifications. The information
	* is kept in static memory. Subsequent calls to getattr with
	* op = NEXT yields the next attribute for the specified document
	* type. If op is REWIND, the first attribute for the given type
	* is delivered. If no (more) attribute is found, getattr returns
	* a NULL pointer.
	*/
       static int isparsed = FALSE;
       static char *currattr, *attrbuf;
       char messg[80], *malloc();
       struct stat statbuf;
       register int i;
       FILE *atfil;
       
       if (isparsed) {
	 if (op == NEXT)
	   return (currattr) ? nxt(currattr) : currattr;
	 else if (op == REWIND) {
	   currattr = attrbuf;
	   return currattr;
	 }
       }
       else { /* we've to read the stuff first */
	 if ((atfil = fopen (attrfile, "r")) == NULL) {
	   (void)sprintf (messg, "No attribute file %s.", attrfile);
	   logerr (messg);
	   attrbuf = NULL;
	 }
	 else {
	   if (fstat (fileno(atfil), &statbuf) < 0) {
	     perror ("couldn't stat.");
	     return (char *)NULL;
	   }
	   attrbuf = malloc ((unsigned)statbuf.st_size+1); 
	   /* leave space for terminating nullbyte */
	   if (!attrbuf) {
	     logerr ("Not enough memory for attribute table");
	   }
	   else {
	     (void)fread (attrbuf, sizeof (char), 
			  (Size_t)statbuf.st_size, atfil);
	     for (i=0; i < statbuf.st_size; i++)
	       if (attrbuf[i] == '\n')
		 attrbuf[i] = '\0';
	     attrbuf[statbuf.st_size + 1] = '\0';
	   }
	 }
	 currattr = attrbuf;
	 isparsed = TRUE;
	 return currattr;
       }
       return FALSE;
     }

mylock (key, proj) Af_key *key; Project *proj; {
  Af_user *locker;
  Uid_t myuid;
  char messg[80], *lockerid();

  myuid = (Uid_t)getuid();
  if (!locked(locker = vc_testlock_g(key))) {
    if (firmlocking (proj)) {
      (void)sprintf (messg, 
	       "You must lock %s before saving (firm locking required).",
	       af_rname (key));
      logmsg (messg);
      return FALSE;
    }
    else { /* no firm locking */
      if (lockeruid (vc_lock_g(key, myuid)) != myuid) {
	af_perror ("cannot lock archive");
	return FALSE;
      }
      return TRUE;
    }
  }
  else { /* there was some lock set */
    if (lockeruid(locker) != myuid) {
      (void)sprintf (messg, "%s already locked by %s.", af_rname (key), 
	       lockerid (locker));
      logmsg (messg);
      return FALSE;
    }
    return TRUE;
  }
}

firmlocking (proj) Project *proj; {
  if (proj) {
    return TRUE;
  }
  else {
    return FALSE;
  }
}

#define owner(p) (0100 * p)
#define group(p) (010 * p)
#define world(p) (p)

afaccess (fkey, perm) Af_key *fkey; {
  short itisus;
  Af_attrs thisattrs;
  char thishost[MAXHOSTNAMELEN];

  if (!fkey) return FALSE;

  if (fail(af_gattrs (fkey, &thisattrs))) {
    af_perror ("af_gattrs (access determination failed).");
    return FALSE;
  }
  (void)gethostname (thishost, MAXHOSTNAMELEN);
  if (!strcmp (thishost, thisattrs.af_owner.af_userhost)) {
    itisus = !strcmp (getpwuid((int)getuid())->pw_name, 
		      thisattrs.af_owner.af_username);
  if ((thisattrs.af_state != AF_BUSY) && (perm & W_OK)) return FALSE;
  if (itisus) {
    return TRUE; /* there's no chmod for archived files. always grant acc. */
  }
  return thisattrs.af_mode & world(perm);
  }
  else return TRUE;
}

/*ARGSUSED*/
myproject (proj) Project *proj; {
  /*
   * returns TRUE if we are project administrator
   */
  return TRUE; /* until project support is implemented ... */
}

mkvstring (version, key) char *version; Af_key *key; {
  int g;
  char buf[16], *t, *n;

  t = af_rtype (key);
  (void)sprintf (version, "%s%s%s[",
	   n=af_rname (key),
	   t ? (t[0] ? "." : "") : "", t);
  free (n); free (t); 
  if ((g=af_rgen (key)) < 0) {
    (void)strcat (version, "busy]");
  }
  else {
    (void)sprintf (buf, "%d.%d]", g, af_rrev (key));
    (void)strcat (version, buf);
  }
}

char *vnum (key) Af_key *key; {
  int _gen, _rev;
  static char vstr[20];

  _gen = af_rgen (key);
  _rev = af_rrev (key);
  
  if (af_rstate (key) == AF_BUSY)
    (void)strcpy (vstr, "busy");
  else
    (void)sprintf (vstr, "%d.%d", _gen, _rev);
  return vstr;
}

udafree (attrbuf) Af_attrs *attrbuf; {
  register int i=0;

  while (attrbuf->af_udattrs[i])
    free (attrbuf->af_udattrs[i++]);
}
