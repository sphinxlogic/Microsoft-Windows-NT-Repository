/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*
 * $Header: retrv.h[3.2] Thu Feb 23 18:13:50 1989 axel@coma published $
 *
 * Log for /u/shape/dist-tape/src/vc/retrv.h[3.0]
 * 	Thu Feb 23 18:13:50 1989 axel@coma published $
 *  --- empty log message ---
 *  retrv.h[3.1] Thu Feb 23 18:13:50 1989 axel@coma published $
 *  --- empty log message ---
 *  retrv.h[3.2] Thu Feb 23 18:13:50 1989 axel@coma published $
 *  --- empty log message ---
 */


#ifndef _TYPES_
#include <sys/types.h>
#define _TYPES_
#endif
#ifndef _TIME_
#include <sys/time.h>
#define _TIME_
#endif
#ifndef MAXNAMLEN
#include <sys/dir.h>
#endif
#include "afsapp.h"

struct Vdesc {
  int  v_genno,
       v_state,
       v_vno;
  time_t v_time;
  char v_attrf[MAXNAMLEN], 
       v_spec[80], 
       v_pname[80],
       v_aunam[MAXNAMLEN],
       v_auhost[MAXHOSTNAMELEN];
};

#define ATTRDEF 01
#define QUIETPLEASE 02
#define FORCE 04
#define TYPEOUT 010
#define TONAME "vcat"
#define PROJCSET 020
#define VSPECSET 040
#define GENSET 0100
#define AUNSET 0200
#define STATSET 0400
#define XACT 01000
#define DATESET 02000
#define KEEPMODE 04000
#define LOCKIT 010000
#define COPY 020000

#define WDOVRBS "Date spec. disables selection of busy version. (warning)"
#define EINVALPROJ "No such project:"
#define NORESTORE "%s not restored"
#define RTRATTR "RTRATTRS"

/* permission statuus for doretrv */
#define DOIT 01
#define DENIED 02
#define RECREATE 04
