/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: vlmisc.c[3.11] Thu Feb 23 18:14:52 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/vlmisc.c[3.5]
 * 	Thu Feb 23 18:14:52 1989 axel@coma published $
 *  --- empty log message ---
 *  vlmisc.c[3.7] Thu Feb 23 18:14:52 1989 uli@coma published $
 *  --- empty log message ---
 *  vlmisc.c[3.9] Thu Feb 23 18:14:52 1989 axel@coma published $
 *  --- empty log message ---
 *  vlmisc.c[3.10] Thu Feb 23 18:14:52 1989 axel@coma save $
 *  --- empty log message ---
 *  vlmisc.c[3.11] Thu Feb 23 18:14:52 1989 axel@coma published $
 *  --- empty log message ---
 */

#include <stdio.h>
#include <pwd.h>
#include <grp.h>
#include <strings.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <afs.h>
#include <afsys.h>

#include "vl.h"

/*
 * Global, but not exported variables
 */
#define VL_MAX_OWNERNAME 7			/* in real life 8 chars */
#define VL_MAX_GROUPNAME 7			/* dito. */

static char *Progname;		                /* name of the called process*/
static char filemode[10];			/* visible file mode (ls(1)) */
static Af_user author, owner;
static char version_string[80];			/* e.g. -V1.0 */
static char error_string[80];			/* for {af_}perror */

char **udattrs;					/* Uda sorted */
int  version_number;				/* Version identification
						 * via option -V */
char *version_states;				/* Version states via
						 * option -s */

char *GetVersionState (state)
     int state;
{
  switch (state) {
  case AF_BUSY:
    return (IsOptionSet(VL_O_VERSIONSTATE) ? "[busy]" : "b");
  case AF_SAVED:
    return (IsOptionSet(VL_O_VERSIONSTATE) ? "[save]" : "s");
  case AF_PROPOSED:
    return (IsOptionSet(VL_O_VERSIONSTATE) ? "[prop]" : "p");
  case AF_PUBLISHED:
    return (IsOptionSet(VL_O_VERSIONSTATE) ? "[publ]" : "P");
  case AF_ACCESSED:
    return (IsOptionSet(VL_O_VERSIONSTATE) ? "[acce]" : "a");
  case AF_FROZEN:
    return (IsOptionSet(VL_O_VERSIONSTATE) ? "[froz]" : "f");
  default:
    return (IsOptionSet(VL_O_VERSIONSTATE) ? "[????]" : "?");
  }
}

char *GetVersionId (generation, revision)
     int generation, revision;
{
  if ( (generation != AF_BUSYVERS) || ( revision != AF_BUSYVERS)) {
    (void)sprintf (version_string, "[%d.%d]", generation, revision);
    return version_string;
  }
  else
    return "";
}

VinfoCleanup ()
{
  
}

char *GetMode (mode)
     u_short mode;
{
/* This function should return a capital 'L' in the file-class field */
/* to indicate a *locked* version. Maybe optional. Instead of Ownername */
/* the name of the locker is to be printed. */
  (void)sprintf (filemode, "%c%c%c%c%c%c%c%c%c%c",
	   (mode & S_IFDIR) ? 'd' : '-',
	   (mode & S_IREAD) ? 'r' : '-',
	   (mode & S_IWRITE) ? 'w' : '-',
	   (mode & S_IEXEC) ? 'x' : '-',
	   (mode & (S_IREAD >> 3)) ? 'r' : '-',
	   (mode & (S_IWRITE >> 3)) ? 'w' : '-',
	   (mode & (S_IEXEC >> 3)) ? 'x' : '-',
	   (mode & (S_IREAD >> 6)) ? 'r' : '-',
	   (mode & (S_IWRITE >> 6)) ? 'w' : '-',
	   (mode & (S_IEXEC >> 6)) ? 'x' : '-'
 	   );
    
  if (mode & S_ISUID)
    filemode[1] = 's';
  if (mode & S_ISGID)
    filemode[6] = 's';
  if (mode & S_ISVTX)
    filemode[9] = 't';

  return filemode;
}

extern char *GetUserInfo (userdesc)
     Af_user *userdesc;
{
  char *uinfo, *tmp;
  
  if ((tmp = malloc(MAXNAMLEN + MAXHOSTNAMELEN + 2)) == NULL) {
    fprintf (stderr, "in GetUserInfo: not enough memory\n");
    exit (1);
  }

  if ((uinfo = malloc(20)) == NULL) {
   fprintf (stderr, "in GetUserInfo: not enough memory\n");
    exit (1);
 }
  
  (void)sprintf 
    (tmp, "%s%s%s", userdesc->af_username, userdesc->af_userhost[0] ?
	   "@" : "", userdesc->af_userhost);
  (void)sprintf (uinfo, "%-16s", tmp);
  free (tmp);
  return uinfo;
}

char *GetDate (date)
     time_t date;
{
  char *tmp_time;
  extern char *ctime();

  tmp_time = ctime(&date);

  /* Format is "Sun Sep 16 01:03:52 1973\n\0" */
  tmp_time = tmp_time + 4;
  tmp_time[20] = '\0';
  return tmp_time;
}


IsDirectory (name)
     char *name;
{
  struct stat stbuf;

  if (stat(name, &stbuf)) {
    return 0;
  }

  return (stbuf.st_mode & S_IFDIR);
}

int FileExists (name)
     char *name;
{
  struct stat buf;

  return ((stat (name, &buf) == 0) ? 1 : 0);
}


int PutProgramName (name)
     char *name;
{
  Progname = ((Progname = rindex (name, '/')) ? ++Progname : name);
}

char *GetProgramName ()
{
  return Progname;
}

void PutVersionStates (states)
     char *states;
{
  version_states = states;
}

#define nxt(s) (s = (*(s+strlen(s)+1) != '\0') ? s+strlen(s)+1 : NULL)

CopyUdattrs (udaval, udattrs)
     char *udaval;
     char **udattrs;
{
  /* returns # of udattrs */
  register int i;

  register char *cp;
  char *temp;

  if ( (temp = malloc ((unsigned)(strlen (udaval) +2))) == NULL) {
    perror ("malloc");
    exit (1);
  }
  (void)strcpy (temp, udaval);
  temp[strlen(udaval)+1] = '\0';
  
  cp = temp;			/*  */
  while (temp && *temp) {
    if (*temp == ',') {
      *temp = '\0';
    }
    ++temp;
  }

  i = 0;
  while (cp && *cp) {
    udattrs[i] = cp;
    i++; nxt(cp);		/* nxt() is a macro !*/
  }
  udattrs[i] = NULL;

  /*
   * Now scan for "foo=bar<blank>bar1" and substitute <blank> by <Ctrl-A>.
   * Don't ask why.
   */

  for (i=0; udattrs[i]; i++) {
    cp = udattrs[i];
    for (cp = udattrs[i]; cp && *cp; cp++)
      if (*cp == ' ')
	*cp = AF_UDAVALDEL;		/* This is a Ctrl-A */
  }
  return i;			/* return # of udattrs */
}

int AddUdattrs (udas)
     char *udas;
{
  int i, length, na;
  char **cpp;

  if ( udas && (*udas == ':')) udas++;
  length = 0;
  /* determine length of current udattrs */
  if (udattrs && *udattrs) {
    for (i = 0 ; udattrs[i]; i++)
      length++;
  }

  length += strlen (udas) + 1;	/* plus the new udas */
  length++;
  if ((cpp = (char **) malloc ((unsigned)(sizeof (char **) * length))) 
      == (char **) NULL) {
    (void)sprintf (error_string, "%s: in AddUdattra(): malloc", Progname);
    perror (error_string);
    exit (1);
  }

  na = CopyUdattrs (udas, cpp);
  
  if (udattrs && *udattrs) {
    for (i = 0 ; udattrs[i]; i++) /* copy old into new array */
      cpp[na++] = udattrs[i];
  }
  
  cpp[na] = (char *) NULL;
  free ((char *)udattrs);
  
  udattrs = cpp;
}

AddHiddenUda (name, val)
     char *name, *val;
{
  int length;
  char *huda;
  
  length = strlen (name);
  length += strlen (val);

  if ((huda = malloc ((unsigned)(length+2*sizeof(char)))) == (char *) NULL) {
    (void)sprintf (error_string, "in AddHiddenUda(): malloc");
    perror (error_string);
    exit (1);
  }
  (void)sprintf (huda, "%s=%s", name, val);
  AddUdattrs (huda);
}

char **GetUdattrs ()
{
  return udattrs;
}

u_long vstates = 0;
#define VL_CHCK_BUSY 01
#define VL_CHCK_SAVE 02
#define VL_CHCK_PROPOSED 04
#define VL_CHCK_PUBLISHED 010
#define VL_CHCK_ACCESSED 020
#define VL_CHCK_FROZEN 040
#define VL_CHCK_ALL 077
#define VL_MAX_STATES 6

void ScanVersionStates ()

     /*
      * Scans strings of the form:
      * 	bspPaf
      *		c+ (c is a char)
      *		c-
      *		~c (not)
      *		!c (not)
      *		c-,c+
      *		c+c-
      */
{
  register last_state;
  
  if (! (*version_states)) {
    vstates  = VL_CHCK_ALL;
    return;
  }

  while (*version_states) {
    switch (*version_states) {
    case 'b':
      vstates |= VL_CHCK_BUSY;
      last_state = AF_BUSY;
      break;
    case 's':
      vstates |= VL_CHCK_SAVE;
      last_state = AF_SAVED;
      break;
    case 'p':
      vstates |= VL_CHCK_PROPOSED;
      last_state = AF_PROPOSED;
      break;
    case 'P':
      vstates |= VL_CHCK_PUBLISHED;
      last_state = AF_PUBLISHED;
      break;
    case 'a':
      vstates |= VL_CHCK_ACCESSED;
      last_state = AF_ACCESSED;
      break;
    case 'f':
      vstates |= VL_CHCK_FROZEN;
      last_state = AF_FROZEN;
      break;
    case '+':			/* -sb+ */
      switch (last_state) {
      case AF_BUSY:
	vstates |= VL_CHCK_BUSY;
      case AF_SAVED:
	vstates |= VL_CHCK_SAVE;
      case AF_PROPOSED:
	vstates |= VL_CHCK_PROPOSED;
      case AF_PUBLISHED:
	vstates |= VL_CHCK_PUBLISHED;
      case AF_ACCESSED:
	vstates |= VL_CHCK_ACCESSED;
      case AF_FROZEN:
	vstates |= VL_CHCK_FROZEN;
	break;
      default:
	fprintf (stderr, "%s: fatal error in ScanVersionStates\n", Progname);
	exit (1);
      }
      break;
    case '-':			/* -sb- */
      if ( !((*(version_states+1) == ',') ||
	     (!*(version_states+1)))) {	/* -sb-f */
	fprintf (stderr, "%s: subrange of states is not allowed\n",
		 Progname);
	exit (1);
      }
      else {
	switch (last_state) {
	case AF_FROZEN:
	  vstates |= VL_CHCK_FROZEN;
	case AF_ACCESSED:
	  vstates |= VL_CHCK_ACCESSED;
	case AF_PUBLISHED:
	  vstates |= VL_CHCK_PUBLISHED;
	case AF_PROPOSED:
	  vstates |= VL_CHCK_PROPOSED;
	case AF_SAVED:
	  vstates |= VL_CHCK_SAVE;
	case AF_BUSY:
	  vstates |= VL_CHCK_BUSY;
	  break;
	default:
	  fprintf (stderr, "%s: fatal error in ScanVersionStates\n", Progname);
	  exit (1);
	}
      }
      break;
    case ',':			/* skip this char */
      break;
    case '~':
    case '!':
      if (!*(version_states + 1)) {
	fprintf (stderr, "%s: missing version state after '%c'\n",
		 Progname, *version_states);
	exit (1);
      }
      vstates = VL_CHCK_ALL;
      switch (*(++version_states)) {
      case 'b':
	vstates &= ~VL_CHCK_BUSY;
	last_state = AF_BUSY;
	break;
      case 's':
	vstates &= ~VL_CHCK_SAVE;
	last_state = AF_SAVED;
	break;
      case 'p':
	vstates &= ~VL_CHCK_PROPOSED;
	last_state = AF_PROPOSED;
	break;
      case 'P':
	vstates &= ~VL_CHCK_PUBLISHED;
	last_state = AF_PUBLISHED;
	break;
      case 'a':
	vstates &= ~VL_CHCK_ACCESSED;
	last_state = AF_ACCESSED;
	break;
      case 'f':
	vstates &= ~VL_CHCK_FROZEN;
	last_state = AF_FROZEN;
	break;
      default:
	fprintf (stderr, "%s: unknown state '%c'. Ignored.\n",
		 Progname, *version_states);
	break;
      }
      break;
    default:
      fprintf (stderr, "%s: unknown state '%c'. Asume 'b+'\n",
	       Progname, *version_states);
      vstates = VL_CHCK_ALL;
      return;
    }
    version_states++;
  }
}

int MatchesVersionStates (attrbuf)
     Af_attrs *attrbuf;
{
  register int attrstate;
  register int state;

  state = vstates;
  attrstate = attrbuf->af_state;
  
  if (state == VL_CHCK_ALL) return 1;
  
  switch (attrstate) {
  case AF_BUSY:
    return (state & VL_CHCK_BUSY);
  case AF_SAVED:
    return (state & VL_CHCK_SAVE);
  case AF_PROPOSED:
    return (state & VL_CHCK_PROPOSED);
  case AF_PUBLISHED:
    return (state & VL_CHCK_PUBLISHED);
  case AF_ACCESSED:
    return (state & VL_CHCK_ACCESSED);
  case AF_FROZEN:
    return (state & VL_CHCK_FROZEN);
  default:
    return 0;
  }  
}

void PutAuthorIdentifications (author_id)
     char *author_id;
{
  char *cp;

  if (cp=index (author_id, '@')) {
    *cp++ = '\0';
    (void)strcpy (author.af_userhost, cp);
  }
  (void)strcpy (author.af_username, author_id);
}

char *GetAuthoridFromAuthor ()
{
    return author.af_username;
}

char *GetAuthorhostFromAuthor ()
{
    return author.af_userhost;
}


void PutOwnerIdentifications (owner_id)
     char *owner_id;
{
  char *cp;

  if (cp=index (owner_id, '@')) {
    *cp++ = '\0';
    (void)strcpy (owner.af_userhost, cp);
  }
  (void)strcpy (owner.af_username, owner_id);
}

char *GetOwneridFromOwner ()
{
    return owner.af_username;
}

char *GetOwnerhostFromOwner ()
{
    return owner.af_userhost;
}

/*ARGSUSED*/
int
a_dir_and_a_file (ac, av)
     int ac;
     char **av;
{
  /*
   * Return 1 iff av contains any directory name.
   */
  while (av && *av) {
    if (IsDirectory (*av))
      return 1;
    av++;
  }
  return 0;
}

char **
rearrange_args (ac, av)
     int ac;
     char **av;
{
  /*
   * Sorts av in the following order: first pure files, then directories.
   * Returns sorted av.
   */
  char **dirs;
  char **tdirs;
  char **files;
  char **tfiles;
  char **tav;

  tav = av;
  
  if ((dirs = (char **)
       malloc ((unsigned)((ac + 1) * sizeof(char *)))) == (char **)NULL) {
    perror ("malloc");
    exit (1);
  }
  tdirs = dirs;
  
  if ((files = (char **)
       malloc ((unsigned)((ac + 1) * sizeof(char *)))) == (char **)NULL) {
    perror ("malloc");
    exit (1);
  }
  tfiles = files;
  
  while (av && *av) {
    if (IsDirectory (*av)) {
      *dirs = *av;
      dirs++;
    }
    else {
      *files = *av;
      files++;
    }

    av++;
  }

  files = (char **) NULL;
  dirs = (char **) NULL;
  
  av = tav;
  while (tfiles && *tfiles) {
    *av = *tfiles;
    av++; tfiles++;
  }

  while (tdirs && *tdirs) {
    *av = *tdirs;
    av++; tdirs++;
  }

  return tav;
}

int IsHiddenUda (uda)
     char *uda;
{
  /*
   * A hidden Uda begins and ends with 2 '_'.
   */
  
  return (!strncmp (uda, "__", 2));
}

int IsHiddenFile(attrbuf)
     Af_attrs *attrbuf;
{
  /* Is file a hidden file ? */
  if ( (attrbuf->af_name[0] == '\0') || (attrbuf->af_name[0] == '.') )
    return 1;
  else
    return 0;
}

logerr (msg) char *msg; {
  fprintf (stderr, "%s: %s.\n", Progname, msg);
}
