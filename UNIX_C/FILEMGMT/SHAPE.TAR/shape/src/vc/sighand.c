/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: sighand.c[3.7] Thu Feb 23 18:13:57 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/sighand.c[3.3]
 * 	Thu Feb 23 18:13:57 1989 axel@coma published $
 *  --- empty log message ---
 *  sighand.c[3.4] Thu Feb 23 18:13:57 1989 axel@coma published $
 *  --- empty log message ---
 *  sighand.c[3.5] Thu Feb 23 18:13:57 1989 axel@coma save $
 *  --- empty log message ---
 *  sighand.c[3.6] Thu Feb 23 18:13:57 1989 axel@coma save $
 *  --- empty log message ---
 *  sighand.c[3.7] Thu Feb 23 18:13:57 1989 axel@coma published $
 *  --- empty log message ---
 */

/*LINTLIBRARY*/

#include <signal.h>
#include <strings.h>
#include "afs.h"
#include "afsapp.h"

extern struct Transaction ThisTransaction;
extern int nfnms;

CatchSigs () {
/*
 * Setup signal handlers for various signals. Previous handlers
 * are saved. On receipt of a signal, the 
 * original handler for this signal will be invoked after specified
 * action has been taken.
 */

extern Sfunc_t interrupt_action();

Sfunc_t    die1(), die2(), die3(), die4(), die5(), die6(), 
       die7(), die8(), die9(), die10(),
       die11(), die12(), die13(), die14(), die15();

  (void)signal (SIGINT, die2);
  (void)signal (SIGBUS, die10);
  (void)signal (SIGSEGV, die11);
  (void)signal (SIGFPE, die8);
  (void)signal (SIGTERM, die15);
}

extern jmp_buf here;

CatchCont () {
  Sfunc_t conthand();

  (void)signal (SIGCONT, conthand);
}

UnCatchCont () {
  (void)signal (SIGCONT, SIG_DFL);
}

Sfunc_t conthand () {
  char messg [80];

  (void)sprintf (messg, "%s:", ThisTransaction.tr_fname);
  logmsg (messg);
  longjmp (here, 1);
}
    
Sfunc_t die1 () {
}

Sfunc_t die2 () {
  /* do eventual cleanup and execute previously defined action */
  Sfunc_t interrupt_action();
  
  (void)sigblock (SIGINT);
  (void)signal (SIGINT, die2);
  af_cleanup ();
  kill_tmpfiles ();
  interrupt_action();
}

Sfunc_t die8 () {
  /* do eventual cleanup and execute previously defined action */
  int mask = sigblock (SIGFPE);
  logerr (" Oh! Oh! .... this was a floating exception -- goodbye."); 
  af_cleanup ();
  kill_tmpfiles ();
  (void)sigsetmask (mask);
  exit (1);
}

Sfunc_t die10 () {
  /* do eventual cleanup and execute previously defined action */
  
  (void)sigblock (SIGBUS);
  logerr ("Oh! Oh! .... this was a buserror -- goodbye.");
  logerr ("Dumping core.");
  af_cleanup ();
  kill_tmpfiles ();
  (void)kill (getpid(), SIGQUIT);
}

Sfunc_t die11 () {
  /* do eventual cleanup and execute previously defined action */

  (void)sigblock (SIGSEGV);
  logerr ("Oh! Oh! .... this was a segmentation violation -- goodbye.");
  logerr ("Dumping core.");
  af_cleanup ();
  kill_tmpfiles ();
  (void)kill (getpid(), SIGQUIT);
}

Sfunc_t die15 () {
  /* do eventual cleanup and restore previously saved context for */
  /* next transaction */
  int mask = sigblock (SIGTERM);

  (void)signal (SIGTERM, die15);
  kill_tmpfiles ();
  kill_afsets();
  kill_afkeys();
  kill_afattrbufs();
  ThisTransaction.tr_rc = 1; /* indicating that something went wrong */
  (void)sigsetmask (mask);
  longjmp (ThisTransaction.tr_env, 1);
}

#define sm(i) (1 << (i))

abort_this (domsg) {
  if (domsg)
    logmsg ("...aborting");
  (void)kill (getpid(), SIGTERM); 
  /* abort current execution phase and restore */
  /* a clean context for next phase */
}

/*
 *  Utilities for housekeeping with various allocated 
 *  system resources.
 */

char tmpnames[MAXTMPF][MAXNAMLEN];
Af_set *afsets[MAXSETS];
Af_key *afkeys[MAXKEYS];
Af_attrs *afattrbufs[MAXATTRBUFS];

Register (data, type) char *data; short type; {
  register int i, ok;

  if (!data) return; /* NULL pointers not registered */

  switch (type) {
  case TYPEF: /* temporary filenames */
    ok = FALSE;
    for (i=0; i < MAXTMPF; i++) {
      if (tmpnames[i][0]) continue;
      else {
	(void)strcpy (tmpnames[i], data);
	ok = TRUE;
	break;                      /* I admit: UGLY! */
      }
    }
    if (!ok) {
      logerr ("internal error in resource tables");
    }
    break;
  case AFSET:
    ok = FALSE;
    for (i = 0; i < MAXSETS; i++) {
      if (afsets[i]) continue;
      else {
	afsets[i] = (Af_set *)data;
	ok = TRUE;
	break;
      }
    }
    if (!ok) {
      logerr ("resource table error -- Af_set table overflow");
    }
    break;
  case AFKEY:
    ok = FALSE;
    for (i = 0; i < MAXSETS; i++) {
      if (afkeys[i]) continue;
      else {
	afkeys[i] = (Af_key *)data;
	ok = TRUE;
	break;
      }
    }
    if (!ok) {
      logerr ("resource table error -- Af_key table overflow");
    }
    break;
  case AFATTRS:
    ok = FALSE;
    for (i = 0; i < MAXATTRBUFS; i++) {
      if (afattrbufs[i]) continue;
      else {
	afattrbufs[i] = (Af_attrs *)data;
	ok = TRUE;
	break;
      }
    }
    if (!ok) {
      logerr ("resource table error -- Af_attrbuf table overflow");
    }
    break;
  default: /* shouldn't happen */
    logerr ("internal error in resource tables (types)");
  }
}

UnRegister (data, type) char *data; short type; {
  register int i;

  switch (type) {
  case TYPEF:
    for (i=0; i < MAXTMPF; i++) {
      if (tmpnames[i][0]) {
	if (!strcmp (tmpnames[i], data)) {
	  if (i < MAXTMPF-1) {
	    bcopy (tmpnames[i+1], tmpnames[i], MAXTMPF-(i+1));
	    if (tmpnames[MAXTMPF-1][0]) tmpnames[MAXTMPF-1][0] = '\0';
	  }
	  else {
	    tmpnames[i][0] = '\0';
	  }
	  break; /* bail out of for-loop */
	}
	else {
	  continue;
	}
      }
      else {
	break; /* no more entries in list */
      }
    }
    break;
  case AFSET:
    for (i = 0; i < MAXSETS; i++) {
      if (afsets[i] == (Af_set *)data) {
	afsets[i] = (Af_set *)NULL;
	break;
      }
    }
    break;
  case AFKEY:      
    for (i = 0; i < MAXKEYS; i++) {
      if (afkeys[i] == (Af_key *)data) {
	afkeys[i] = (Af_key *)NULL;
	break;
      }
    }
    break;
  case AFATTRS:
    for (i = 0; i < MAXATTRBUFS; i++) {
      if (afattrbufs[i] == (Af_attrs *)data) {
	afattrbufs[i] = (Af_attrs *)NULL;
	break;
      }
    }
    break;
  default: /* shouldn't happen */
    logerr ("internal error in resource tables (unregister)");
  }
}

kill_tmpfiles () { /* do this before exiting */
  register int i;

  for (i=0; i < MAXTMPF; i++) {
    if (tmpnames[i][0])
      (void)unlink (tmpnames[i]);
    else break;  /* save two or three nanoseconds */
  }
}

kill_afsets () { 
  register int i;

  for (i = 0; i < MAXSETS; i++) {
    if (afsets[i])
      af_dropset (afsets[i]);
  }
}

kill_afkeys () { 
  register int i;

  for (i = 0; i < MAXKEYS; i++) {
    if (afkeys[i])
      af_dropkey (afkeys[i]);
  }
}

kill_afattrbufs () {
  register int i;

  for (i = 0; i < MAXATTRBUFS; i++) {
    if (afattrbufs[i])
      udafree (afattrbufs[i]);
  }
}
