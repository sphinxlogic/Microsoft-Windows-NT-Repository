/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: save.c[3.15] Thu Feb 23 18:13:53 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/save.c[3.8]
 * 	Thu Feb 23 18:13:53 1989 axel@coma published $
 *  --- empty log message ---
 *  save.c[3.11] Thu Feb 23 18:13:53 1989 axel@coma published $
 *  --- empty log message ---
 *  save.c[3.12] Thu Feb 23 18:13:53 1989 axel@coma save $
 *  --- empty log message ---
 *  save.c[3.13] Thu Feb 23 18:13:53 1989 axel@coma save $
 *  --- empty log message ---
 *  save.c[3.14] Thu Feb 23 18:13:53 1989 axel@coma save $
 *  --- empty log message ---
 *  save.c[3.15] Thu Feb 23 18:13:53 1989 axel@coma published $
 *  --- empty log message ---
 */

#include <signal.h>
#include <stdio.h>
#include <ctype.h>
#include <strings.h>
#include "ParseArgs.h"
#include "save.h"
#include "project.h"

char *progname, vcomment[1024], tfname[MAXNAMLEN], atr_fname[MAXNAMLEN],
  symname[MAXNAMLEN], projname[80];
int newvnum;

/* forward decls for option handlers */
extern handle_R_switch ();
extern handle_f_switch ();
extern handle_q_switch ();
extern handle_u_switch ();
extern handle_a_opt ();
extern handle_m_opt ();
extern handle_n_opt ();
extern handle_p_opt ();
extern handle_svnum_opt ();
extern handle_t_opt ();
extern usage ();

unsigned int options;

OptDesc argdesc[] = {
  { "version", OPT_IS_SWITCH, handle_R_switch },
  { "f", OPT_IS_SWITCH, handle_f_switch },
  { "q", OPT_IS_SWITCH, handle_q_switch },
  { "u", OPT_IS_SWITCH, handle_u_switch },
  { "unlock", OPT_IS_SWITCH, handle_u_switch },
  { "a", OPT_HAS_ARG, handle_a_opt }, 
  { "m", OPT_HAS_ARG, handle_m_opt }, 
  { "n", OPT_HAS_ARG, handle_n_opt }, 
  { "p", OPT_HAS_ARG, handle_p_opt }, 
  { "setvnum", OPT_HAS_ARG, handle_svnum_opt },
  { "t", OPT_HAS_ARG, handle_t_opt },
  { "h", OPT_IS_SWITCH, usage },
  { "?", OPT_HAS_ARG, usage },
  { (char *)  NULL, NULL, NULL }
};

struct Transaction ThisTransaction;
int nfnms;

main (ac, av) char **av; {
  register int i;
  int nac, rc = 0;
  char projname[80], **nav, messg[80], *es, *getenv(), *version();
  Project pdesc;

  if (!rindex (av[0], '/')) progname = av[0];
  else progname = rindex (av[0], '/') + 1;
  /* make prog-name available to entire program */

  if (ac < 2) {
    usage ();
    exit (1);
  }

  if (isupper(progname[0])) options |= NEWGEN;
  if (strcmp (progname+1, SAVE)) /* check from 2nd char onwards */
    options |= SUBMIT;
  if (ParseArgs (ac, av, &nac, &nav, argdesc)) {
    usage ();
  }
    
  if (!(options & ATTRDEF)) {
    es = getenv (SVATTR);
    if ((es) && (es[0] != '\0')) {
      options |= ATTRDEF;
      (void)strcpy (atr_fname, es);
    }
  }

  if (GetProject (projname, &pdesc) < 0) {
    (void)sprintf (messg, "%s %s", EINVALPROJ, projname);
    logmsg (messg);
    exit (1);
  }

  CatchSigs ();
  nfnms = nac;
  ThisTransaction.tr_rc = 0;
  for (i = 0; i < nfnms; i++) {
    if (!setjmp (ThisTransaction.tr_env)) {
      ThisTransaction.tr_seqno = i;
      (void)strcpy (ThisTransaction.tr_fname, nav[i]);
      ThisTransaction.tr_done = FALSE;
      SaveAFile (nav[i], &pdesc);
    }
    else { /* ThisTransaction was aborted */
      rc += ThisTransaction.tr_rc;
    }
  }
  logmsg ("done.");
  return (rc);
}

Sfunc_t interrupt_action () { /* is executed by appropriate signal handler */
  char messg[80];
  int mask = sigblock (SIGINT);
  
  if ((nfnms - ThisTransaction.tr_seqno) > 1) { 
    (void)sprintf (messg, "\ncompletely stop saving (%d files unsaved) ?", 
	     nfnms - ThisTransaction.tr_seqno);
    if (ask_confirm (messg, "no")) {
      if (ThisTransaction.tr_done) {
	(void)sprintf (messg, "\ntoo late, %s already saved", 
		 ThisTransaction.tr_fname);
	logmsg (messg);
	return; /* continue where we've been interrupted */
      }
      (void)sprintf (messg, "%s not saved", ThisTransaction.tr_fname);
      logmsg (messg);
      (void)sigsetmask (mask);
      longjmp (ThisTransaction.tr_env, 1);
    }
    else {
      (void)sprintf (messg, "%s not saved", ThisTransaction.tr_fname);
      logmsg (messg);
      exit (1);
    }
  }
  else {
    (void)sprintf (messg, "\n%s not saved", ThisTransaction.tr_fname);
    logmsg (messg);
    exit (1);
  }
}

logmsg (msg) char *msg; {
  if (!(options & QUIETPLEASE)) {
    fprintf (stdout, "%s\n", msg);
  }
}

logerr (msg) char *msg; {
  fprintf (stderr, "%s: %s\n", progname, msg);
}

/*ARGSUSED*/
handle_R_switch (o, a) char *o, *a; {
  printf ("This is %s version %s.\n", progname, version());
  printf ("AFS version %s.\n", af_version());
  exit (0);
}

/*ARGSUSED*/
handle_a_opt (o, a) char *o, *a; {
  options |= ATTRDEF;
  (void)strcpy (atr_fname, a);
  return 0;
}

/*ARGSUSED*/
handle_f_switch (o, a) char *o, *a; {
  options |= FORCE;
  return 0;
}

/*ARGSUSED*/
handle_m_opt (o, a) char *o, *a; {
  if (!(options & TXTFSET)) {
    options |= MSGSET;
    (void)strcpy (vcomment, a);
    return 0;
  }
  return 0;
}

/*ARGSUSED*/
handle_n_opt (o, a) char *o, *a; {
  if (a && a[0]) {
    options |= SYMNSET;
    (void)strcpy (symname, a);
  }
  return 0;
}

/*ARGSUSED*/
handle_q_switch (o, a) char *o, *a; {
  options |= QUIETPLEASE;
  return 0;
}

/*ARGSUSED*/
handle_p_opt (o, a) char *o, *a; {
  options |= OTHERPROJ;
  (void)strcpy (projname, a);
  return 0;
}

/*ARGSUSED*/
handle_svnum_opt (o, a) char *o, *a; {
  char messg[80];
  if (!(newvnum = mkvno (a))) {
    (void)sprintf (messg, "bad version number \"%s\"", a);
    logerr (messg);
    return 1;
  }
  options |= SETVNUM;
  return 0;
}

/*ARGSUSED*/
handle_t_opt (o, a) char *o, *a; {
  if (options & MSGSET) {
    options &= ~MSGSET;
  }
  options |= TXTFSET;
  (void)strcpy (tfname, a);
  return 0;
}

/*ARGSUSED*/
handle_u_switch (o, a) char *o, *a; {
  options |= LCKGIVEUP;
  return 0;
}

usage () {
  pa_ShortUsage (progname, argdesc, "files ...");
  exit (1);
}

