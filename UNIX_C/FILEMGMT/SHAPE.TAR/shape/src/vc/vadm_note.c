/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: vadm_note.c[3.10] Thu Feb 23 18:14:13 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/vadm_note.c[3.4]
 * 	Thu Feb 23 18:14:13 1989 axel@coma published $
 *  --- empty log message ---
 *  vadm_note.c[3.6] Thu Feb 23 18:14:13 1989 axel@coma published $
 *  --- empty log message ---
 *  vadm_note.c[3.7] Thu Feb 23 18:14:13 1989 axel@coma save $
 *  --- empty log message ---
 *  vadm_note.c[3.8] Thu Feb 23 18:14:13 1989 axel@coma save $
 *  --- empty log message ---
 *  vadm_note.c[3.9] Thu Feb 23 18:14:13 1989 axel@coma save $
 *  --- empty log message ---
 *  vadm_note.c[3.10] Thu Feb 23 18:14:13 1989 axel@coma published $
 *  --- empty log message ---
 */

#include <stdio.h>
#include <strings.h>
#include <afs.h>
#include "vadm.h"
#include "afsapp.h"
#include "locks.h"
#include "vc_sysdep.h"

/* Externals */
extern int af_errno;
extern jmp_buf here;		/* reentrance point after we caught a sig */
extern char *malloc (), *getenv();
extern char **environment;	/* pointer to our environment */
extern struct Transaction ThisTransaction;
extern char *get_from_stdin();	/* read a text from stdin */
extern int call_editor();	/* returns a text */
extern char *FindProgram(), *FindFile();
extern unsigned int options;
extern int def_vnum;

/* locals */
static char buf[100];		/* buffer for error messages */
static char *editor;		/* user's favorite editor*/

/**/
static
int determine_defaults ()
{
  /*
   * Returns 0 on error (editor not found, editor not executable, and so).
   * 1 on success.
   */
  char *neweditor;
  int ask_default = 0;		/* if env-editor is not available */
				/* user if he/she want's default editor */

  /* examine user's favorite editor, if any */
  if ((editor = getenv (EDITOR_ENV_NAME)) == NULL)
    editor = DEFAULT_EDITOR;

  if (!index (editor, '/'))
    if ((neweditor = FindFile (editor)) == NULL) {
      (void)sprintf (buf, "Sorry, your favorite editor %s is not available on this machine.",
		     editor);
      logmsg (buf);
      ask_default++;
    }
    else
      editor = neweditor;
  
  /* is editor executable ? */
  if (!ask_default && !FileExecutable (editor)) {
   (void)sprintf (buf, "Sorry, your favorite editor %s is not executable.",
	     editor);
    logmsg (buf);
    ask_default++;
  }
  
  if (ask_default) {
    /* if default editor not available resign. */
    if (strcmp (editor, DEFAULT_EDITOR)) {
      (void)sprintf (buf, "Do you accept default editor %s ?", DEFAULT_EDITOR);
      if (ask_confirm (buf, "yes")) {
	editor = DEFAULT_EDITOR;
	if (!FileExecutable (editor)) {
	  logmsg ("Arrg, also default editor is not available. --- I resign.");
	  return 0;
	}
      }
      else
	return 0;		/* user doesn't want */
    }
    else
      return 0;			/* default editor is not available */
  }
  return 1;
}

/**/
static
int note_ok (newnote, oldnote)
     char *newnote, *oldnote;
{
  /*
   * returns 0 if no changes detected, 1 otherwise.
   */
    
  if (!newnote) {
    if (ask_confirm ("Description is empty. Save anyway ?", "no"))
      return 0;
    else
      return 1;
  }
      
  if (oldnote && !strcmp (newnote, oldnote)) {
    logmsg ("No changes detected.");
    return 0;
  }

  /* newnote contains only layout ? */
  while (*newnote) {
    switch (*newnote) {
    case ' ':
    case '\n':
    case '\t':
      break;
    default:
      return 1;
      break;
    }
    newnote++;
  }

  if (ask_confirm ("Description contains only layout. Save anyway?", "no"))
    return 0;
  else
    return 1;
}

/**/
static
int save_it (key, note)
     Af_key *key;
     char *note;
{
  af_snote (key, note);
  ThisTransaction.tr_done = 1;
}

/**/
static
int save_note_multiple (note, set)
     char *note;
     Af_set *set;
{
  int i, rc = 0;

  for (i = 0 ; i < set->af_nkeys; i++) {
    rc += af_snote (&(set->af_klist[i]), note);
  }
  if (note) free (note);
  return rc;
}

/**/
static
int process_notes (set, change_it)
     Af_set *set;
     int change_it;
{
  int i;
  char *note, *newnote, *mktemp();
  int retcode;			/* retcode from editor */
  char tmp_file[20];		/* tmp-file's name */
  char name[MAXNAMLEN], nametype[MAXTYPLEN];
  
  if (!determine_defaults ())	/* that is the editor */
    return -1;
  
  CatchSigs ();

  /* read description per file and save if changes. */
  for (i = 0; i < set->af_nkeys; i++) {

    /* remember this location */
    if (setjmp (ThisTransaction.tr_env)) {
      if ( i < set->af_nkeys )
	continue;
      else
	return 0;
    }

    /* construct file name */
    (void)sprintf (nametype, "%s", af_rtype(&set->af_klist[i]));
    (void)sprintf (name,  "%s%c%s", af_rname(&set->af_klist[i]),
	     nametype ? '.' : NULL,
	     nametype ? nametype : NULL);
    
    ThisTransaction.tr_seqno = i;
    (void)strcpy (ThisTransaction.tr_fname, name);
    ThisTransaction.tr_done = 0;
      
    /* print afsname and version */
    (void)sprintf (buf, "%s[%d.%d]:", name, af_rgen (&set->af_klist[i]),
	     af_rrev (&set->af_klist[i]));
    logmsg (buf);		/* this file */
    
    (void)strcpy (tmp_file, mktemp ("/tmp/vctlXXXXXX"));

    /* Do we change the old note ? */
    if (change_it) {		/* get old note */
      note = af_rnote (&set->af_klist[i]);

      /* Note "Empty log message" is an empty note  */
      if (!strcmp (note, EMPTYNOTE)) {
	free (note);
	note = NULL;
      }
    }
    else
      note = NULL;
    
    newnote = NULL;
    retcode = call_editor (editor, tmp_file, note, &newnote);
      
    if (retcode == -1) {	/* editor exited abnormally */
      if (i == (set->af_nkeys - 1)) {
	logmsg ("Description lost.");
	return 1;
      }
      
      if (ask_confirm ("Description lost. Continue ?", "no"))
	return 1;
      else
	continue;
    }
    
    if (note_ok (newnote, note)) { /* any changes ? */
      save_it (&set->af_klist[i], newnote);
      logmsg ("Description saved.");
    }
    else
      logmsg ("Description not saved.");
    
    if (note)
      free (note);
    
    if (newnote)
      free (newnote);
  }
  return 0;
}

/**/
print_erroneous (erroneous, errs)
     char **erroneous;
     int errs;
{
  int i, j;
  
  fprintf (stderr, "No saved versions of");
  j = 0;
  for (i = 0; i < errs; i++) {
    if (++j == errs)
      if (errs == 1)
	fprintf (stderr, " \"%s\"", erroneous[i]);
      else
	fprintf (stderr, " and \"%s\"", erroneous[i]);
    else
      fprintf (stderr, " \"%s\",", erroneous[i]);
  }
  fprintf (stderr, " found --- skipped\n");
}

/**/
static
int do_note (vlist, ac, av, change_it)
     struct vc_vlist *vlist;
     int ac;
     char **av;
     int change_it;
{
  Af_set set;
  int errs;
  char **erroneous;
  
  if (IsOptionSet(Vopt_version)) {
    errs = GetKeysByGenRev
	(ac,av, gen(def_vnum), rev(def_vnum), &set, 
	 &erroneous);
  }
  else {
    if (! ((vlist->from_version_set) || vlist->to_version_set))
      errs = GetKeysByGenRev 
	(ac,av, AF_BUSYVERS, AF_BUSYVERS, &set, &erroneous);
    else
      errs = GetKeysByName (ac,av, vlist, &set, &erroneous);
  }
  if (errs)
    print_erroneous (erroneous, errs);

  /* all given files do not exist ? */
  if (!set.af_nkeys) {
    logmsg ("Nothing appropriate found.");
    return 1;
  }

  if (af_sortset (&set, AF_ATTHUMAN) == -1) {
    af_perror ("Do_note: af_sortset AF_ATTHUMAN");
    return 1;
  }
      
  /* If stdin is redirected use text as description for *all* afs files. */
  if (!isatty (0)) {		/* 0 == stdin */
    /* do not append to old desc. Also we have no special term-char.
     * Read until EOF. */
    return save_note_multiple (get_from_stdin ((char *)NULL, -1), &set);
  }
  
  /* shall we go on if an error occurs? Ask user. */
  if (errs && (!ask_confirm ("Continue anyway ?", "yes")))
      return 1;
    
  return process_notes (&set, change_it);
}

/**/
int DoSetNote (vlist, ac, av)
     struct vc_vlist *vlist;
     int ac;
     char **av;
{
  return do_note (vlist, ac, av, 0); /* don't change existing note */
}

/**/
int DoChangeNote (vlist, ac, av)
     struct vc_vlist *vlist;
     int ac;
     char **av;
{
  return do_note (vlist, ac, av, 1); /* change existing note */
}

/**/
static
int do_description (vlist, ac, av, change_it)
     struct vc_vlist *vlist;
     int ac;
     char **av;
     int change_it;		/* if set, append to old note */
{
  /*
   * Changes an existing description note of the first version (i.e. 1.0)
   * of an AFS file. Returns 0 on success, otherwise 1 to indicate an error.
   */

  Af_set set;
  int errs = 0;			/* # of not found afs files */
  char **erroneous;
  
  /* A version list makes no sence. Ignore it, but display warning msg. */
  if (vlist->from_version_set || vlist->to_version_set)
    logwng ("version specification list ignored.");
  
  errs = GetKeysByGenRev (ac,av, AF_FIRSTVERS, AF_FIRSTVERS, &set, 
			  &erroneous);

  if (errs)
    print_erroneous (erroneous, errs);
  
  /* all given files do not exist ? */
  if (!set.af_nkeys) {
    logmsg ("Nothing appropriate found.");
    return 1;
  }
    
  if (af_sortset (&set, AF_ATTHUMAN) == -1) {
    af_perror ("Do_description: af_sortset AF_ATTHUMAN");
    return 1;
  }
      
  /* If stdin is redirected use text as description for *all* afs files. */
  if (!isatty (0)) {		/* 0 == stdin */
    /* do not append to old desc. Also we have no special term-char.
     * Read until EOF. */
    return save_note_multiple (get_from_stdin ((char *)NULL, -1), &set);
  }
    
  /* shall we go on if an error occurs? Ask user. */
  if (errs && (!ask_confirm ("Continue anyway ?", "yes")))
    return 1;

  return process_notes (&set, change_it);
}

/**/
int DoSetDescription (vlist, ac, av)
     struct vc_vlist *vlist;
     int ac;
     char **av;
{
  return do_description (vlist, ac, av, 0); /* don't change existing note */
}

/**/
int DoChangeDescription (vlist, ac, av)
     struct vc_vlist *vlist;
     int ac;
     char **av;
{
  return do_description (vlist, ac, av, 1); /* change to old note */
}

int DoSetIntent (ac, av) int ac; char **av; {
  /* We must hold the lock for the history, that we wanna change. */
  register int i;
  int rc, rcsum = 0;
  char fname[256], messg[80], *oldintent, *intent, *getintent(), *intattr,
       *lockerid();
  Af_key thiskey;
  Af_user *locker;


  for (i=0; i < ac; i++) {
    if (setjmp (ThisTransaction.tr_env)) continue;
    rc = af_getkey (af_afpath (av[i]), af_afname (av[i]), 
		    af_aftype (av[i]), AF_BUSYVERS, AF_BUSYVERS,
		    AF_NONAME, &thiskey);
    if (rc < 0) {
      (void)sprintf (messg, "can't find busy version for %s.", av[i]);
      logerr (messg);
      continue;
    }
    mkvstring (fname, &thiskey);
    if (locked(locker=vc_testlock_v(&thiskey))) {
      if (lockeruid (locker) == (Uid_t)getuid ()) {
	oldintent = af_rudattr (&thiskey, INTENT);
	intent = getintent ((char *)NULL, oldintent);
	if (oldintent) free (oldintent);
	intattr = malloc ((unsigned)(strlen (intent) + strlen (INTENT) +1));
	(void)sprintf (intattr, "%s%s", INTENT, intent);
	if (fail(af_sudattr (&thiskey, AF_REPLACE, intattr)))
	  af_sudattr (&thiskey, AF_ADD, intattr);
	free (intattr);
	af_dropkey (&thiskey);
      }
      else {
	(void)sprintf (messg, "Can't set intent on %s (locked by %s).",
		 fname, lockerid (locker));
	logerr (messg);
	af_dropkey (&thiskey);
	rcsum++;
	continue;
      }
    }
    else {
      (void)sprintf (messg, "You must have a lock on %s to set change intention.", 
	       fname);
      logerr (messg);
      af_dropkey (&thiskey);
      rcsum++;
      continue;
    }
  }
  return rcsum;
}    
	
