/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: vadm.c[3.12] Thu Feb 23 18:14:05 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/vadm.c[3.6]
 * 	Thu Feb 23 18:14:05 1989 axel@coma published $
 *  --- empty log message ---
 *  vadm.c[3.9] Thu Feb 23 18:14:05 1989 axel@coma published $
 *  --- empty log message ---
 *  vadm.c[3.10] Thu Feb 23 18:14:05 1989 axel@coma save $
 *  --- empty log message ---
 *  vadm.c[3.11] Thu Feb 23 18:14:05 1989 axel@coma save $
 *  --- empty log message ---
 *  vadm.c[3.12] Thu Feb 23 18:14:05 1989 axel@coma published $
 *  --- empty log message ---
 */

#include <pwd.h>
#include <stdio.h>
#include <signal.h>
#include <strings.h>

#include "afs.h"
#include "afsapp.h"
#include "vadm.h"
#include "ParseArgs.h"

extern char *malloc();

/* forward declarations */
/*
 * Options (e.g. -V, -from, or -to) and actions (-delete, -set, etc.)
 * are parse at the same time by calling function ParseArgs().
 */

/* option */
extern int handle_binary_option ();
extern int handle_help_option ();	    /* handler for option -h */
extern int handle_version_option ();	    /* handler for -V option */
extern int handle_from_option ();	    /* handler for -from option */
extern int handle_to_option ();		    /* handler for -to option */
extern int handle_no_option ();		    /* handler for -no option */
extern int handle_quiet_option ();
extern int handle_R_option ();
char debug_on = 0;
extern int handle_d_option ();

/* actions */
extern int handle_reserve_action ();
extern int handle_unreserve_action ();
extern int handle_symname_action ();
extern int handle_setc_action ();
extern int handle_delete_action ();
extern int handle_promote_action ();
extern int handle_unpromote_action ();
extern int handle_change_action ();
extern int handle_lock_action ();
extern int handle_unlock_action ();
extern int handle_chmod_action ();
extern int handle_chown_action ();
extern int handle_chaut_action ();
extern int handle_set_action ();
extern int handle_setuda_action ();
extern int handle_unsetuda_action ();
extern int handle_setattrs_action ();

/* Global variables */
OptDesc argdesc[] = {	/* known options,actions and its handler */
  { "version", OPT_IS_SWITCH, handle_R_option },
  { "b", OPT_IS_SWITCH, handle_binary_option },
  { "h", OPT_HAS_OPT_ARG, handle_help_option },
  { "V", OPT_HAS_ARG, handle_version_option},
  { "from", OPT_HAS_ARG, handle_from_option },
  { "to", OPT_HAS_ARG, handle_to_option },
  { "no", OPT_HAS_ARG, handle_no_option },
  { "q", OPT_IS_SWITCH, handle_quiet_option },
  { "debug", OPT_IS_SWITCH, handle_d_option },
  { "reserve", OPT_IS_SWITCH, handle_reserve_action},
  { "unreserve", OPT_IS_SWITCH, handle_unreserve_action},
  { "symbolic", OPT_HAS_ARG, handle_symname_action},
  { "setc", OPT_HAS_ARG, handle_setc_action},
  { "delete", OPT_IS_SWITCH, handle_delete_action},
  { "promote", OPT_IS_SWITCH, handle_promote_action },
  { "unpromote", OPT_IS_SWITCH, handle_unpromote_action },
  { "lock", OPT_IS_SWITCH, handle_lock_action },
  { "unlock", OPT_IS_SWITCH, handle_unlock_action },
  { "chmod", OPT_HAS_ARG, handle_chmod_action },
  { "chown", OPT_HAS_ARG, handle_chown_action },
  { "chaut", OPT_HAS_ARG, handle_chaut_action },
  { "set", OPT_HAS_ARG, handle_set_action },
  { "setuda", OPT_HAS_ARG, handle_setuda_action },
  { "unsetuda", OPT_HAS_ARG, handle_unsetuda_action },
  { "setattrs", OPT_HAS_ARG, handle_setattrs_action },
  { "change", OPT_HAS_ARG, handle_change_action },
  { (char *) NULL, NULL, NULL }
};

unsigned int options = 0;	/* given options */
unsigned int actions = 0;	/* given actions */
char *progname;			/* program's name */
struct vc_vlist *vlist = (struct vc_vlist*) NULL;
     /* versions to be processed */
struct vc_vlist *vcur = (struct vc_vlist*) NULL;
int def_vnum;
int to_option_pending = 0;	/* if -from is given, -to is expected later */
int from_option_pending = 0;	/* if -to is given before any -from, -from is
				 * pending. If -to is followed by -V, any
				 * from-pending is rejected.*/ 
char *symname = NULL;		/* symbolic name -symname arg */
char *csym =  NULL;             /* comment leader symbol */
int newmode;
Af_user newauthor; /* arguments of the resp. actions */
char *TakeFromFile = NULL;      /* Filename, where uda-val will be taken
				   from (see handle_setuda_action) */
char Attrfile[128];             /* Name of file where attribute definitions
				   will be taken from */
char udaname[AF_UDANAMLEN];     /* Name of uda to be set */
char udaval[256];               /* String val to which udaname will be set */
struct Transaction ThisTransaction;
static char buf[100];
char **environment;
jmp_buf here;

/**/
main (ac, av, ev)
     int ac;
     char **av, **ev;
{
  int nac;			/* ac after parsing */
  char **nav, *cp;		/* av after parsing */
  int retcode = 0;		/* return value */
  register int i, j;
  
  progname = (cp = rindex (av[0], '/')) ? ++cp : av[0];
  /* make prog-name available to entire program */
  environment = ev;		/*  */
  CatchSigs();
  if (setjmp (ThisTransaction.tr_env)) return 1; 
  InitVcontrol ();
  if (ParseArgs (ac, av, &nac, &nav, argdesc)) {
    (void)sprintf (buf, "BTW, try \"%s -h\" for more information or rtfm.",
	     progname);
    logmsg (buf);
    exit (1);			/* error detected  */
  }
  /* Look for identical arguments -- zero out twins */
  for ( i = 0; i < nac; i++)
    for (j = i+1; j < nac; j++)
      if (!strcmp (nav[i], nav[j])) nav[j][0] = '\0';

  if (debug_on)
    DumpVlist ();
  
  if (!nac) {
    if (actions)		/* if an action is given */
      logmsg ("Filenames missing.");
    else
      logmsg ("An action and filenames missing.");

    ShortUsage ();
    exit (1);
  }

  if (!ActionsPlausible ()) exit (1); /* no chance to do anything */

  switch (actions) {
  case Varg_set_note:
    retcode = DoSetNote (vlist, nac, nav);
    break;
  case Varg_change_note:
    retcode = DoChangeNote (vlist, nac, nav);
    break;
  case Varg_set_description:
    retcode = DoSetDescription (vlist, nac, nav);
    break;
  case Varg_change_description:
    retcode = DoChangeDescription (vlist, nac, nav);
    break;
  case Varg_set_intent:
    retcode = DoSetIntent (nac, nav);
    break;
  case Varg_setc_symbol:
    retcode = DoSetCommentSymbol (nac, nav, csym);
    break;
  case Varg_delete:
    retcode = DoDelete (vlist, nac, nav);
    break;
  case Varg_promote:
    retcode = DoPromote (vlist, nac, nav);
    break;
  case Varg_unpromote:
    retcode = DoUnpromote (vlist, nac, nav);
    break;
  case Varg_lock:
  case Varg_reserve:
    retcode = DoReserve (nac, nav);
    break;
  case Varg_unlock:
  case Varg_unreserve:
    retcode = DoUnreserve (nac, nav);
    break;
  case Varg_chmod:
    retcode = DoChmod (vlist, nac, nav);
    break;
  case Varg_chown:
    retcode = DoChown (nac, nav);
    break;
  case Varg_chaut:
    retcode = DoChaut (vlist, nac, nav);
    break;
  case Varg_symname:
    retcode = DoSymname (vlist, nac, nav, symname);
    break;
  case Varg_setuda:
    retcode = DoSetUda (vlist, nac, nav);
    break;
  case Varg_unsetuda:
    retcode =DoUnsetUda (vlist, nac, nav);
    break;
  case Varg_setattrs:
    retcode = DoSetAttrs (vlist, nac, nav);
    break;
  default:
    logerr ("Ooops, You have requested more than one action.\
 Please try again");
    logmsg ("with only *one* action at a time.");
    retcode = 1;
    break;
  }
  
  if (retcode)
    logmsg ("terminated.");
  else
    logmsg ("done.");
  return (retcode);
}

/**/
int ActionsPlausible ()
{
  if (actions) {
    return 1;
  }
  else {
    logmsg ("Action missing.");
    ShortUsage ();
    return 0;
  }
}

/**/
int InitVcontrol ()
{
  if ((vlist = (struct vc_vlist*) malloc (sizeof (struct vc_vlist))) == NULL) {
    vctl_abort ("malloc vc_vlist");
  }

  vlist->from_version_set = vlist->to_version_set = NULL;
  vlist->from_generation =  NULL;
  vlist->from_revision =  NULL;
  vlist->to_generation = NULL;
  vlist->to_revision = NULL;
  
  vlist->next = NULL;
  vcur = vlist;
}

/**************************
 *     Action handlers    *
 *************************/
/**/
/*ARGSUSED*/
int handle_reserve_action (act, arg)
     char *act, *arg;
{
  if (IsOptionSet (Vopt_binary)) {
    logerr ("Can't reserve or unreserve binary.");
    exit (1);
  }
  SetAction(Varg_reserve);	/* macro */
  if (IsActionSet(Varg_unreserve)) {
    logerr ("You already mentioned \"unreserve\", so what do you want ?");
    return 1;
  }
  return 0;
}

/*ARGSUSED*/
int handle_unreserve_action (act, arg)
     char *act, *arg;
{
  if (IsOptionSet (Vopt_binary)) {
    logerr ("Can't reserve or unreserve binary.");
    exit (1);
  }
  SetAction(Varg_unreserve);
  if (IsActionSet(Varg_reserve)) {
    logerr ("You already mentioned \"reserve\", so what do you want ?");
    return 1;
  }
  return 0;
}

/*ARGSUSED*/
int handle_symname_action (act, arg)
     char *act, *arg;
{
  SetAction(Varg_symname);
  symname = arg;
  return 0;
}

/*ARGSUSED*/
int handle_setc_action (act, arg)
     char *act, *arg;
{
  csym = arg;
  if (strlen (csym) > (CLEADMAXLEN-(strlen(CLEAD)+2))) {
    logerr ("Specified comment leader symbol is too long");
    return 1;
  }
  SetAction(Varg_setc_symbol);
  return 0;
}  

/*ARGSUSED*/
int handle_delete_action (act, arg)
     char *act, *arg;
{
  SetAction(Varg_delete);
  return 0;
}

/*ARGSUSED*/
int handle_promote_action (act, arg)
     char *act, *arg;
{
  if (IsOptionSet (Vopt_binary)) {
    logerr ("Can't promote status of binary.");
    exit (1);
  }
  SetAction(Varg_promote);
  if (IsActionSet(Varg_unpromote)) {
    logerr ("You already mentioned \"unpromote\", so what do you want ?");
    return 1;
  }
  return 0;
}

/*ARGSUSED*/
int handle_unpromote_action (act, arg)
     char *act, *arg;
{
  if (IsOptionSet (Vopt_binary)) {
    logerr ("Can't unpromote status of binary.");
    exit (1);
  }
  SetAction(Varg_unpromote);
  if (IsActionSet(Varg_promote)) {
    logerr ("You already mentioned \"promote\", so what do you want ?");
    return 1;
  }
  return 0;
}

/*ARGSUSED*/
int handle_change_action (act, arg)
     char *act, *arg;
{
  char messg[80];
  if (IsOptionSet (Vopt_binary)) {
    (void)sprintf (messg, "Can't change %s of binaries. Sorry.", 
	     arg ? arg : "note or description" );
    logerr (messg);
    exit (1);
  }
  if (!strcmp (arg, "note")) {
    SetAction(Varg_change_note);
    return 0;
  }
  if (!strcmp (arg, "description")) {
    SetAction(Varg_change_description);
    return 0; 
  }
  logerr ("Change what, eh? - Note or description?");
  return 1;
}

/*ARGSUSED*/
int handle_lock_action (act, arg) char *act, *arg; {
  if (IsOptionSet (Vopt_binary)) {
    logerr ("Can't lock or unlock binary.");
    exit (1);
  }
  if (IsActionSet (Varg_unlock)) {
    logerr ("Can't lock and unlock at the same time.");
    exit (1);
  }
  SetAction (Varg_lock);
  return 0;
}

/*ARGSUSED*/
int handle_unlock_action (act, arg) char *act, *arg; {
  if (IsOptionSet (Vopt_binary)) {
    logerr ("Can't lock or unlock binary.");
    exit (1);
  }
  if (IsActionSet (Varg_lock)) {
    logerr ("Can't lock and unlock at the same time.");
    exit (1);
  }
  SetAction (Varg_unlock);
  return 0;
}

/*ARGSUSED*/
int handle_chmod_action (act, arg) char *act, *arg; {
  register int mode = 0;
  char messg[80], ciph, err = 0;
  register char *cp = arg;

  if (strlen (arg) > 4) err++;
  else 
    while (ciph = *cp++) { 
      ciph -= '0';
      if ((ciph > 7) || (ciph < 0)) err++;
      else {
	mode <<= 3;  
	mode += ciph;
      }
    }
  if (err) {
    (void)sprintf (messg, "invalid mode \"%s\".", arg);
    logerr (messg);
    exit (1);
  }
  SetAction (Varg_chmod);
  newmode = mode;
  return 0;
}

/*ARGSUSED*/
int handle_chown_action (act, arg) char *act, *arg; {
  char messg[80];

  if (IsOptionSet (Vopt_binary)) {
    logerr ("Can't change owner of binary.");
    exit (1);
  }
  if (getpwnam (arg) == NULL) {
    (void)sprintf (messg, "%s is not a valid userid on this machine.", arg);
    logerr (messg);
    exit (1);
  }
  SetAction (Varg_chown);
/*  newowner = opw->pw_uid; */
  return 0;
}

/*ARGSUSED*/
int handle_chaut_action (act, arg) char *act, *arg; {
  char messg[80], hostname[MAXHOSTNAMELEN];
  
  if (IsOptionSet (Vopt_binary)) {
    logerr ("Can't change author of binary.");
    exit (1);
  }
  if (getpwnam (arg) == NULL ) {
    (void)sprintf (messg, "%s is not a valid userid on this machine.", arg);
    logerr (messg);
    exit (1);
  }
  SetAction (Varg_chaut);
  (void) strcpy (newauthor.af_username, arg);
  (void) gethostname (hostname, MAXHOSTNAMELEN);
  (void) strcpy (newauthor.af_userhost, hostname);
  return 0;
}

/*ARGSUSED*/
int handle_setuda_action (act, arg) char *act, *arg; {
  char *cp;
  register int i;

  if (cp=index(arg, '=')) {
    if (arg == cp) { /* No attribute name */
      logerr ("No attribute name given");
      exit (1);
    }
    if (*(cp+1) == '@') { /* the attribute value will be taken from file */
      TakeFromFile = malloc (128);
      if (TakeFromFile == NULL) {
	logerr ("Can't allocate memory for filename");
	exit (1);
      }
      (void)sscanf (cp+1, "@%s", TakeFromFile); /* ignore evtly. trailing junk */
      if (TakeFromFile ? TakeFromFile[0] ? 0 : 1 : 1) {
	/* condition holds if no filename specified */
	TakeFromFile = NULL;
	(void)strcpy (udaval, "@");
      }
    }
    else { /* attribute value will be taken literally */
      (void)strcpy (udaval, cp+1);
      for (i=0; udaval[i]; i++) {
	if (udaval[i] == 1) { /* cntl-A not allowed */
	  logerr ("Invalid char (cntl-A) in attribute value");
	  exit (1);
	}
      }
    }
    if ((cp-arg) > AF_UDANAMLEN) {
      logerr ("Attributename too long");
      exit (1);
    }
    (void)strncpy (udaname, arg, cp-arg);
    udaname[cp-arg] = '\0';
    SetAction (Varg_setuda);
  }
  else { /* No '=' in arg */
    logerr ("Illegal format of attribute expression");
    exit (1);
  }
  return 0; /* OK */
}

/*ARGSUSED*/
int handle_unsetuda_action (act, arg)
     char *act, *arg; {
       (void)strcpy (udaname, arg);
       SetAction (Varg_unsetuda);
       return 0;
     }

/*ARGSUSED*/
int handle_setattrs_action (act, arg)
     char *act, *arg; {

       SetAction (Varg_setattrs);
       (void)strcpy (Attrfile, arg);
       return 0;
     }

/*ARGSUSED*/
int handle_set_action (act, arg)
     char *act, *arg;
{
  char messg[80];

  if (IsOptionSet (Vopt_binary)) {
    (void)sprintf (messg, "Can't set %s on binaries. Sorry.", 
	     arg ? arg : "note or description" );
    logerr (messg);
    exit (1);
  }
  if (!strcmp (arg, "note")) {
    SetAction(Varg_set_note);
    return 0;
  }
  if (!strcmp (arg, "description")) {
    SetAction(Varg_set_description);
    return 0; 
  }
  if (!strcmp (arg, "intent")) {
    SetAction(Varg_set_intent);
    return 0;
  }
  logerr ("Set what, eh? - note, description, or intent ?");
  return 1;
}

/**************************
 *     Option handlers    *
 *************************/

/*ARGSUSED*/
int handle_binary_option (opt, arg) char *opt, *arg; {
  if (IsActionSet (Varg_reserve | Varg_unreserve | Varg_promote | 
		   Varg_unpromote | Varg_change_note | 
		   Varg_change_description | Varg_set_description | 
		   Varg_set_note | Varg_lock | Varg_unlock | Varg_chown | 
		   Varg_chaut)) {
    logerr ("This action request is not supported for binaries.");
    exit (1);
  }
  SetOption (Vopt_binary);
  return 0;
}

#ifdef NEVER_SET_THIS
int handle_version_option (opt, arg)
     char *opt, *arg;
{
  struct vc_vlist *vtmp;
  int generation = 0, revision = 0;
  
  if ((vcur->from_version_set) || (vcur->to_version_set)) {
    /* if any -to num pending, report error */
    if (to_option_pending) {
      (void)sprintf (buf, "\"-to <version number>\" expected. Got \"-%s %s\"",
	       opt, arg);
      logerr (buf);
      return 1;
    }

    if (from_option_pending) {
      from_option_pending = 0;	/* vctl -to 3.4 -from 5.6 -to 6.7 */
				/* means: from 1.0 to 3.4 and from 5.6 to */
				/* 6.7 */
    }
    if ((vtmp = (struct vc_vlist*)malloc (sizeof (struct vc_vlist))) == NULL)
      vctl_abort ("malloc,2 vc_vlist");

    vcur->next = vtmp;
    vcur = vtmp;
  }

  generation = GetGenerationNumber (arg);
  revision = GetRevisionNumber (arg);
  
  vcur->from_generation = generation;
  vcur->from_revision = revision;
  vcur->to_generation = generation;
  vcur->to_revision = revision;
  vcur->from_version_set = vcur->to_version_set = 1;
  vcur->next = NULL;

  if ((revision < 0) || (generation <= 0)) {
    (void)sprintf (buf, "%s version number %s.",
	     *arg ? "bad" : "missing",
	     *arg ? arg : "");
    logerr (buf);
    return 1;
  }
  return 0;
}
#endif

/*ARGSUSED*/
int handle_version_option (opt, arg)
     char *opt, *arg;
{
  def_vnum = mkvno (arg);
  if (IsOptionSet(Vopt_version) || 
      (vlist->from_generation + vlist->to_generation) ) {
    logerr ("Set only one default version or version range.");
    return 1;
  }
  SetOption(Vopt_version);
  return 0;
}

/**/
int handle_from_option (opt, arg)
     char *opt, *arg;
{
  struct vc_vlist *vtmp;
  
  if (IsOptionSet(Vopt_version)) {
    logerr ("Set only one default version or version range.");
    return 1;
  }
  if (vcur->from_version_set) {	/* need a new entry in vlist */
    if ((vtmp = (struct vc_vlist*)malloc (sizeof (struct vc_vlist))) == NULL)
      vctl_abort ("malloc,3 vc_vlist");
    
    vcur->next = vtmp;
    vcur = vtmp;
    vcur->to_generation = vcur->to_revision = NULL;
    vcur->to_version_set = NULL;
    vcur->next = NULL;
  }

  vcur->from_version_set = 1;
  vcur->from_generation = GetGenerationNumber (arg);
  vcur->from_revision = GetRevisionNumber (arg);

  if (to_option_pending) {
    (void)sprintf (buf, "\"-to <version number>\" expected. Got \"-%s %s\"",
	     opt, arg);
    logerr (buf);
    return 1;
  }
  else {
    if (!from_option_pending)
      /* e.g.: -to is followed by -from then no -to is pending */
      to_option_pending++;
  }

  if ((vcur->from_revision < 0) || (vcur->from_generation <= 0)) {
    (void)sprintf (buf, "%s version number %s.",
	     *arg ? "bad" : "missing",
	     *arg ? arg : "");
    logerr (buf);
    return 1;
  }

  from_option_pending = 0;
  return 0;
}

/**/
int handle_to_option (opt, arg)
     char *opt, *arg;
{
  struct vc_vlist *vtmp;
  
  if (IsOptionSet(Vopt_version)) {
    logerr ("Set only one default version or version range.");
    return 1;
  }
  if (vcur->to_version_set) {
    if ((vtmp = (struct vc_vlist*) malloc (sizeof (struct vc_vlist))) == NULL)
      vctl_abort ("malloc,4 vc_vlist");

    vcur->next = vtmp;
    vcur = vtmp;
    vcur->from_generation = vcur->from_revision = NULL;
    vcur->from_version_set = NULL;
    vcur->next = NULL;
  }

  vcur->to_generation = GetGenerationNumber (arg);
  vcur->to_revision = GetRevisionNumber (arg);
  vcur->to_version_set = 1;

  if (from_option_pending) {
    (void)sprintf (buf, "\"-from <version number>\" expected. Got \"-%s %s\"",
	     opt, arg);
    logerr (buf);
    return 1;
  }
  else {
    if (!to_option_pending)	/* -to followd by -from then no -from is
				 * pending */
      from_option_pending++;
  }
  
if ((vcur->to_revision < 0) || (vcur->to_generation <= 0)) {
    (void)sprintf (buf, "%s version number %s.",
	     *arg ? "bad" : "missing",
	     *arg ? arg : "");
    logerr (buf);
    return 1;
  }

  to_option_pending = 0; 
  return 0;
}

/**/
int handle_no_option (opt, arg)
     char *opt, *arg;
{
  if (*arg) {
    if (!strcmp ("confirm", arg)) {
      SetOption(Vopt_no_confirm);
      return 0;
    }
    else {
      (void)sprintf (buf, "Hmmm, I don't know that. What's up with \"-%s %s\"?", opt, arg);
      logerr (buf);
      return 1;
    }
  }
  else {
    (void)sprintf (buf, "Hey You, please tell me more about \"-%s\".\
 That sounds familiar to me.", opt);
    logerr (buf);
    return 1;
  }
}

/*ARGSUSED*/
int handle_quiet_option (o, a) char *o, *a; {
  SetOption(Vopt_quiet);
  return 0;
}

/**/
ShortUsage ()
{
  pa_ShortUsage (progname, argdesc, "files ...");
}

/*ARGSUSED*/
int handle_help_option (opt, arg)
     char *opt, *arg;
{
  if (*arg) {
    logerr ("long help not yet implemented.");
  }
  else {
    ShortUsage ();
  }

  exit (1);			/* no way to proceed */
}

/*ARGSUSED*/
handle_R_option (o, a) char *o, *a; {
  extern char *version();

  printf ("This is %s version %s.\n", progname, version ());
  printf ("AFS version %s.\n", af_version());
  exit (0);
}

/**/
vctl_abort (message)
     char *message;
{
  perror (message);
  exit (1);
}

/*ARGSUSED*/
int handle_d_option (opt, arg)
     char *opt, *arg;
{
  debug_on++;
}

DumpVlist ()
{
  struct vc_vlist *vtmp;
  int f_gen, f_rev, t_gen, t_rev;
  
  for (vtmp = vlist; vtmp; vtmp = vtmp->next) {
    f_gen = vtmp->from_generation;
    f_rev = vtmp->from_revision;
    t_gen = vtmp->to_generation;
    t_rev = vtmp->to_revision;

    if ( (f_gen == t_gen) && (f_rev == f_rev))
      fprintf (stderr, "-V%d.%d\n", f_gen, f_rev);
    else
      fprintf (stderr, "-from %d.%d -to %d.%d\n", f_gen, f_rev, t_gen, t_rev);
  }
}

