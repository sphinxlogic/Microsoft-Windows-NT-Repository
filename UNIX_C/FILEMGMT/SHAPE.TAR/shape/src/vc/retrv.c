/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: retrv.c[3.7] Thu Feb 23 18:13:45 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/retrv.c[3.2]
 * 	Thu Feb 23 18:13:46 1989 axel@coma save $
 *  --- empty log message ---
 *  retrv.c[3.3] Thu Feb 23 18:13:46 1989 axel@coma save $
 *  --- empty log message ---
 *  retrv.c[3.4] Thu Feb 23 18:13:46 1989 axel@coma published $
 *  --- empty log message ---
 *  retrv.c[3.5] Thu Feb 23 18:13:46 1989 axel@coma published $
 *  --- empty log message ---
 *  retrv.c[3.6] Thu Feb 23 18:13:46 1989 axel@coma save $
 *  --- empty log message ---
 *  retrv.c[3.7] Thu Feb 23 18:13:46 1989 axel@coma published $
 *  --- empty log message ---
 */

/*
 *  retrv [-fmqtx] [-V version] [-a attrs] [-d date] [-g generation]  
 *          [-n author] [-p pname] [-s state] [-lock] [-dest path] fn [fn1 ...]
 *
 *  Retrieve a previously saved version of a file. We orient us pretty much
 *  towards the check-out operation of RCS. Retrieve determines the
 *  archive name to be searched from the given file names. Unless otherwise
 *  specified by the project context (-p), the archive is expected to
 *  reside in the AFS subdirectory. The retrieved version will be created
 *  in the current directory. Retrieve tries to be careful if an
 *  attempt is made to overwrite an existing busy-version: unless -f
 *  is specified, retrv will ask the caller for permission.
 *  If no busy version exists, one is created with the modes of the
 *  formerly saved version. If one exists, it's modes are kept unless
 *  -m is given.
 *  There's a number of ways to specify which version should be retrieved.
 *  With -V an explicit version can be selected. Another argument to -V
 *  could be a symbolic name (hopefully unique). Alternatively, versions
 *  can be selected by supplying certain attribute values to retrv, such as
 *  the name of the author, the version state, a generation number or a 
 *  set of user defined attributes, possibly describing a variant. In case
 *  that more than one version fits the desired attributes, the newest
 *  of them is selected, unless -x (exact!) is specified. -V implies -x.
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <strings.h>
#include "ParseArgs.h"
#include "afs.h"
#include "retrv.h"
#include "project.h"

char *progname;

struct Transaction ThisTransaction;

/* forward decls for option handlers */
extern handle_R_switch ();
extern handle_f_switch ();
extern handle_l_switch ();
extern handle_m_switch ();
extern handle_q_switch ();
extern handle_t_switch ();
extern handle_x_switch ();
extern handle_V_opt ();
extern handle_a_opt ();
extern handle_d_opt ();
extern handle_dest_opt ();
extern handle_g_opt ();
extern handle_n_opt ();
extern handle_p_opt ();
extern handle_s_opt ();
extern usage ();

unsigned int options;

static OptDesc retrvargs[] = {
  { "version", OPT_IS_SWITCH, handle_R_switch },
  { "f", OPT_IS_SWITCH, handle_f_switch },
  { "l", OPT_IS_SWITCH, handle_l_switch },
  { "lock", OPT_IS_SWITCH, handle_l_switch },
  { "m", OPT_IS_SWITCH, handle_m_switch },
  { "q", OPT_IS_SWITCH, handle_q_switch },
  { "t", OPT_IS_SWITCH, handle_t_switch },
  { "x", OPT_IS_SWITCH, handle_x_switch },
  { "V", OPT_HAS_ARG, handle_V_opt }, 
  { "a", OPT_HAS_ARG, handle_a_opt }, 
  { "d", OPT_HAS_ARG, handle_d_opt }, 
  { "date", OPT_HAS_ARG, handle_d_opt }, 
  { "dest", OPT_HAS_ARG, handle_dest_opt },
  { "g", OPT_HAS_ARG, handle_g_opt }, 
  { "n", OPT_HAS_ARG, handle_n_opt }, 
  { "p", OPT_HAS_ARG, handle_p_opt }, 
  { "s", OPT_HAS_ARG, handle_s_opt }, 
  { "h", OPT_IS_SWITCH, usage },
/*  { "?", OPT_HAS_ARG, usage }, */
  { (char *)  NULL, NULL, NULL }
};
static OptDesc vcatargs[] = {
  { "version", OPT_IS_SWITCH, handle_R_switch },
  { "q", OPT_IS_SWITCH, handle_q_switch },
  { "t", OPT_IS_SWITCH, handle_t_switch },
  { "x", OPT_IS_SWITCH, handle_x_switch },
  { "V", OPT_HAS_ARG, handle_V_opt }, 
  { "a", OPT_HAS_ARG, handle_a_opt }, 
  { "d", OPT_HAS_ARG, handle_d_opt }, 
  { "date", OPT_HAS_ARG, handle_d_opt }, 
  { "g", OPT_HAS_ARG, handle_g_opt }, 
  { "n", OPT_HAS_ARG, handle_n_opt }, 
  { "p", OPT_HAS_ARG, handle_p_opt }, 
  { "s", OPT_HAS_ARG, handle_s_opt }, 
  { "h", OPT_IS_SWITCH, usage },
/*  { "?", OPT_HAS_ARG, usage }, */
  { (char *)  NULL, NULL, NULL }
};

static int nfnms;

static struct Vdesc dversion;

char *dp = NULL; /* nasty sideeffect here - see 'handle_dest_opt' */

main (ac, av) char **av; {
  register int i;
  int nac, bound_vid = 0, rc = 0;
  unsigned int options_bak = 0;
  char messg[80], *es, *getenv(), **nav, *version(), vstring[16], *cp;
  Project pdesc;
  struct Vdesc *vdescr = &dversion, alt_dversion;

  progname = (cp = rindex (av[0], '/')) ? ++cp : av[0];
  /* make prog-name available to entire program */

  if (ac < 2) {
    pa_ShortUsage (progname, vcatargs, "files ...");
  }

  if (!strcmp (progname, TONAME)) {
    options |= TYPEOUT;
    if (ParseArgs (ac, av, &nac, &nav, vcatargs)) {
      pa_ShortUsage (progname, vcatargs, "files...");
    }
  }
  else {
    if (ParseArgs (ac, av, &nac, &nav, retrvargs)) {
      pa_ShortUsage (progname, retrvargs, "files...");
    }
  }

  if (!(options & (TYPEOUT | COPY | LOCKIT))) options |= COPY;
    
  if (!(options & ATTRDEF)) {
    es = getenv (RTRATTR);
    if ((es) && (es[0] != '\0')) {
      options |= ATTRDEF;
      (void)strcpy (dversion.v_attrf, es);
    }
  }

  if ((options & PROJCSET) && fail(GetProject (dversion.v_pname, &pdesc))) {
    (void)sprintf (messg, "%s %s", EINVALPROJ, dversion.v_pname);
    logerr (messg);
    exit (1);
  }

  CatchSigs ();
  nfnms = nac;
  ThisTransaction.tr_rc = 0;
  for (i = 0, vdescr = &dversion; i < nfnms; i++) {
    if (!setjmp (ThisTransaction.tr_env)) {
      if (bound_vid) {
	bound_vid = FALSE;
	options = options_bak; /* restore original selection options */
	vdescr = &dversion;
      }
      ThisTransaction.tr_seqno = i;
      if (BoundVersion (nav[i], ThisTransaction.tr_fname, vstring)) {
	alt_dversion.v_vno = mkvno (vstring);
	options_bak = options; /* save original selection options */
	options |= (VSPECSET | XACT);
	options &= ~(ATTRDEF | GENSET | AUNSET | STATSET | DATESET);
	vdescr = &alt_dversion;
	bound_vid = TRUE;
      }
      else {
	(void)strcpy (ThisTransaction.tr_fname, nav[i]);
      }
      ThisTransaction.tr_done = FALSE;
      RetrieveAFile (ThisTransaction.tr_fname, vdescr, &pdesc, dp);
    }
    else { /* ThisTransaction was aborted */
      rc += ThisTransaction.tr_rc;
    }
  }
  logdiag ("done.");
  return (rc);
}

Sfunc_t interrupt_action () { /* is executed by appropriate signal handler */
  char messg[80];

  if ((nfnms - ThisTransaction.tr_seqno) > 1) { 
    (void)sprintf (messg, "\ncompletely stop retrieving (%d files pending) ?", 
	     nfnms - ThisTransaction.tr_seqno);
    if (ask_confirm (messg, "no")) {
      if (ThisTransaction.tr_done) {
	(void)sprintf (messg, "\ntoo late, %s already restored", 
		 ThisTransaction.tr_fname);
	logdiag (messg);
	return; /* continue where we've been interrupted */
      }
      (void)sprintf (messg, NORESTORE, ThisTransaction.tr_fname);
      logdiag (messg);
      longjmp (ThisTransaction.tr_env, 1);
    }
    else {
      (void)sprintf (messg, NORESTORE, ThisTransaction.tr_fname);
      logmsg (messg);
      exit (1);
    }
  }
  else {
    (void)sprintf (messg, "\n%s not restored", ThisTransaction.tr_fname);
    logdiag (messg);
    exit (1);
  }
}

logmsg (msg) char *msg; {
  if (!(options & QUIETPLEASE)) {
    fprintf (stdout, "%s\n", msg);
  }
}

logdiag (msg) char *msg; {
  if (!(options & QUIETPLEASE)) {
    fprintf (stderr, "%s\n", msg);
  }
}

logerr (msg) char *msg; {
  fprintf (stderr, "%s: %s\n", progname, msg);
}

/*ARGSUSED*/
handle_R_switch (o, a) char *o, *a; {
  printf ("This is %s version %s.\n", progname, version ());
  printf ("AFS version %s.\n", af_version());
  exit (0);
}

/*ARGSUSED*/
handle_f_switch (o, a) char *o, *a; {
  options |= FORCE;
  return 0;
}

/*ARGSUSED*/
handle_l_switch (o, a) char *o, *a; {
  char messg[128];

  if (options & TYPEOUT) {
    logerr ("Locking makes no sense in TYPEOUT mode of operation - ignored.");
    return 0;
  }
  if (options & COPY) {
    (void)sprintf (messg, "No checkout (with lock) to distant directory %s.", dp);
    logerr (messg);
    exit (1);
  }
  options |= LOCKIT;
  return 0;
}

/*ARGSUSED*/
handle_m_switch (o, a) char *o, *a; {
  options |= KEEPMODE;
  return 0;
}

/*ARGSUSED*/
handle_q_switch (o, a) char *o, *a; {
  options |= QUIETPLEASE;
  return 0;
}

/*ARGSUSED*/
handle_t_switch (o, a) char *o, *a; {
  if (options & LOCKIT) {
    logerr ("Locking makes no sense in TYPEOUT mode of operation - ignored.");
    options &= ~LOCKIT;
  }
  if (options & COPY) {
    logerr ("TYPEOUT mode of operation overrides COPY mode.");
    options &= ~COPY;
    dp = NULL;
  }
  options |= TYPEOUT;
  return 0;
}

/*ARGSUSED*/
handle_x_switch (o, a) char *o, *a; {
  options |= XACT;
  return 0;
}

/*ARGSUSED*/
handle_V_opt (o, a) char *o, *a; {
  dversion.v_vno = mkvno (a);
  (void)strcpy (dversion.v_spec, a);
  options |= VSPECSET;
  options |= XACT;
  return 0;
}

/*ARGSUSED*/
handle_a_opt (o, a) char *o, *a; {
  options |= ATTRDEF;
  (void)strcpy (dversion.v_attrf, a);
  return 0;
}

/*ARGSUSED*/
handle_d_opt (o, a) char *o, *a; {
  char messg[128];
  time_t mktime();

  if ((options & STATSET) && (dversion.v_state == AF_BUSY)) {
    logmsg (WDOVRBS);
    options &= ~STATSET;
  }
  if (dversion.v_time = mktime (a)) {
    options |= DATESET;
    return 0;
  }
  else {
    (void)sprintf (messg, "invalid date specification: %s.", a);
    logerr (messg);
    tusage ();
    return 1;
  }
}

/*ARGSUSED*/
handle_dest_opt (o, a) char *o, *a; {
  char messg[128];
  static char dpath[256];
  struct stat statbuf;

  if (!a) return 1;
  if (options & LOCKIT) {
    (void)sprintf (messg, "No checkout (with lock) to distant directory %s.", a);
    logerr (messg);
    exit (1);
  }
  if (options & TYPEOUT) {
    logerr ("Already TYPEOUT mode of operation selected.");
    return 0;
  }
  if (options & COPY) {
    (void)sprintf (messg, "Destination path already set to %s. %s ignored.", dpath,
	     a);
    logerr (messg);
    return 0;
  }
  options |= COPY;
  (void)strcpy (dpath, a);
  if (stat (dpath, &statbuf) < 0) {
    (void)sprintf (messg, "Destination path %s does not exist.", dpath);
    logerr (messg);
    exit (1);
  }
  if (!(statbuf.st_mode & S_IFDIR)) {
    (void)sprintf (messg, "Destination %s is not a directory.", dpath);
    logerr (messg);
    exit (1);
  }    
  dp = dpath;
  return 0;
}
  
/*ARGSUSED*/
handle_g_opt (o, a) char *o, *a; {
  char messg[128];

  if (dversion.v_genno = mkgenno (a)) {
    options |= GENSET;
    return 0;
  }
  else {
    (void)sprintf (messg, "'%s' is not a legal generation number.", a);
    logerr (messg);
    return 1;
  }
}

/*ARGSUSED*/
handle_n_opt (o, a) char *o, *a; {
  char *cp;

  options |= AUNSET;
  if (cp=index (a, '@')) {
    *cp = '\0';
    (void)strcpy (dversion.v_auhost, ++cp);
  }
  (void)strcpy (dversion.v_aunam, a);
  return 0;
}

/*ARGSUSED*/
handle_p_opt (o, a) char *o, *a; {
  options |= PROJCSET;
  (void)strcpy (dversion.v_pname, a);
  return 0;
}

/*ARGSUSED*/
handle_s_opt (o, a) char *o, *a; {
  char messg[128];

  if (!fail((dversion.v_state = mkstate (a)))) {
    if ((options & DATESET) && (dversion.v_state == AF_BUSY)) {
      logmsg (WDOVRBS);
    }
    else {
      options |= STATSET;
    }
  }
  else {
    (void)sprintf (messg, "unrecognized version state: %s.\n", a);
    logerr (messg);
    helpstates ();
    exit (1);
  }
  return 0;
}

tusage () {
  fputs ("specify time as yy/mm/dd[/hh:mm].\n", stderr);
}

helpstates () {
  fputs ("The following states are recognized:\n", stderr);
  fputs ("\tbusy, save, proposed, published, accessed, frozen\n", stderr);
}

usage () {
  if (strcmp (progname, "vcat"))
    pa_ShortUsage (progname, retrvargs, "files ...");
  else 
    pa_ShortUsage (progname, vcatargs, "files ...");
}
