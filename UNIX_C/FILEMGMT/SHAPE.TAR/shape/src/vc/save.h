/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*
 * $Header: save.h[3.6] Thu Feb 23 18:13:55 1989 axel@coma published $
 *
 * Log for /u/shape/dist-tape/src/vc/save.h[3.4]
 * 	Thu Feb 23 18:13:55 1989 axel@coma published $
 *  --- empty log message ---
 *  save.h[3.5] Thu Feb 23 18:13:55 1989 axel@coma published $
 *  --- empty log message ---
 *  save.h[3.6] Thu Feb 23 18:13:55 1989 axel@coma published $
 *  --- empty log message ---
 */


#include "afsapp.h"

#define ATTRDEF 01     /* -a fname */
#define QUIETPLEASE 02 /* -q */
#define FORCE 04       /* -f */
#define NEWGEN 010     /* uppercase commandname */
#define OTHERPROJ 020  /* -p name */
#define MSGSET 040     /* -m string */
#define TXTFSET 0100   /* -t fname */
#define SYMNSET 0200   /* -n name */
#define LCKGIVEUP 0400 /* -unlock */
#define SETVNUM   01000 /* -setvnum */
#define SUBMIT    02000 /* submit */

#define EINVALPROJ "No such project:"
#define SVATTR "SVATTRS"
#define SAVE "ave"  /* first char ignored */

