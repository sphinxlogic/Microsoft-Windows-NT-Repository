/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: vlopt.c[3.6] Thu Feb 23 18:14:54 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/vlopt.c[3.4]
 * 	Thu Feb 23 18:14:54 1989 axel@coma published $
 *  --- empty log message ---
 *  vlopt.c[3.5] Thu Feb 23 18:14:54 1989 axel@coma published $
 *  --- empty log message ---
 *  vlopt.c[3.6] Thu Feb 23 18:14:54 1989 axel@coma published $
 *  --- empty log message ---
 */

#include <stdio.h>
#include "ParseArgs.h"
#include "vl.h"

/*
 * Global variables
 */
extern int version_number;
unsigned int options = 0;	/* where the options goes */
int immediate_output = 0;	/* if output should be shipped immediatly */
char multicol_output_possible = 1; /* multi column output flag */

extern int handle_a_option ();
extern int handle_author_options ();
#ifdef DEBUGCOL
extern int handle_dc_option  ();
#endif DEBUGCOL

extern int handle_R_option  ();
extern int handle_b_option  ();
extern int handle_g_option  ();
extern int handle_h_option  ();
extern int handle_H_options ();
extern int handle_l_option  ();
extern int handle_L_option  ();
extern int handle_last_option ();
extern int handle_n_option  ();
extern int handle_owner_option  ();
extern int handle_author_options ();
extern int handle_q_option  ();
extern int handle_s_option  ();
extern int handle_S_option  ();
extern int handle_u_option  ();
extern int handle_ux_option ();
extern int handle_V_option  ();

OptDesc odesc[] = {
  { "version", OPT_IS_SWITCH,	handle_R_option },
  { "a", OPT_IS_SWITCH,		handle_a_option },
  { "author", OPT_HAS_OPT_ARG,	handle_author_options },
#ifdef DEBUGCOL
  { "dc", OPT_IS_SWITCH,	handle_dc_option },
#endif DEBUGCOL
  { "b", OPT_IS_SWITCH,         handle_b_option },
  { "g", OPT_IS_SWITCH,		handle_g_option },
  { "h", OPT_HAS_OPT_ARG, 	handle_h_option },
  { "H", OPT_HAS_OPT_ARG,	handle_H_options },
  { "l", OPT_IS_SWITCH, 	handle_l_option },
  { "L", OPT_IS_SWITCH, 	handle_L_option },
  { "y", OPT_IS_SWITCH, 	handle_last_option },
  { "n", OPT_HAS_ARG,		handle_n_option}, 
  { "owner", OPT_HAS_OPT_ARG, 	handle_owner_option },
  { "q", OPT_IS_SWITCH, 	handle_q_option },
  { "s", OPT_HAS_ARG, 		handle_s_option },
  { "S", OPT_IS_SWITCH, 	handle_S_option },
  { "ux", OPT_IS_SWITCH,	handle_ux_option }, 
  { "u", OPT_HAS_OPT_ARG, 	handle_u_option },
  { "U", OPT_HAS_OPT_ARG,	handle_u_option },
  { "V", OPT_HAS_OPT_ARG, 	handle_V_option },
  { (char *) NULL, NULL, NULL }
};

#define USAGE_OPT_STR "ablLhHgoqsuSUV"	/* Optstring for Usage() */

int IsOptionSet (x) unsigned long x; {
  return (options & (x));
};

/*ARGSUSED*/
handle_a_option (opt, arg) char *opt, *arg;
{
  options |= VL_O_LISTHIDDEN;
  return 0;
}

/*ARGSUSED*/
handle_author_options (opt, arg) char *opt, *arg;
{
  options |= VL_O_AUTHOR;
  PutAuthorIdentifications (arg);
  return 0;
}

/*ARGSUSED*/
handle_b_option (opt, arg) char *opt, *arg;
{
  options |= VL_O_LISTBINARY;
  return 0;
}

#ifdef DEBUGCOL
char debugcol = 0;
handle_dc_option (opt)
     char *opt;
{
  debugcol++;
  return 0;
}
#endif DEBUGCOL

/*ARGSUSED*/
handle_g_option  (opt, arg) char *opt, *arg;
{
  options |= VL_O_GROUPOUTPUT;
  return 0;
}

/*ARGSUSED*/
int handle_n_option (opt, arg)
     char *opt, *arg;
{
  options |= VL_O_UDAGIVEN;
  AddHiddenUda (SYMNAME, arg);
  return 0;
}

/*ARGSUSED*/
handle_h_option  (opt, arg) char *opt, *arg;
{
  LongUsage();
  exit (1);
}

/*ARGSUSED*/
handle_H_options (opt, arg) char *opt, *arg;
{
  options |= VL_O_HISTLOG;
  multicol_output_possible = 0;
  immediate_output++;
  
  if (*arg == '+')
    options |= VL_O_HISTLOGPLUS;

  return 0;
}

/*ARGSUSED*/
handle_l_option  (opt, arg) char *opt, *arg;
{
  options |= VL_O_LONGOUTPUT;
  multicol_output_possible = 0;
  return 0;
}

/*ARGSUSED*/
handle_L_option  (opt, arg) char *opt, *arg;
{
  options |= VL_O_LOGMSG;
  multicol_output_possible = 0;
  immediate_output++;
  return 0;
}

/*ARGSUSED*/
handle_last_option  (opt, arg) char *opt, *arg;
{
  options |= VL_O_LASTVERS;
  multicol_output_possible = 0;
  return 0;
}

/*ARGSUSED*/
handle_owner_option  (opt, arg) char *opt, *arg;
{
  extern void PutOwnerIdentifications();
  options |= VL_O_OWNER;
  PutOwnerIdentifications (arg);
  return 0;
}

/*ARGSUSED*/
handle_q_option  (opt, arg) char *opt, *arg;
{
  options |= VL_O_BEQUIET;
  return 0;
}

/*ARGSUSED*/
handle_s_option  (opt, arg) char *opt, *arg;
{
  options |= VL_O_STATEGIVEN;
  PutVersionStates (arg);
  ScanVersionStates ();
  return 0;
}

/*ARGSUSED*/
handle_S_option  (opt, arg) char *opt, *arg;
{
  options |= VL_O_VERSIONSTATE;
  return 0;
}

/*ARGSUSED*/
handle_ux_option (opt)
     char *opt;
{
  options |= VL_O_LISTHIDDENUDAS;
  return 0;
}

handle_u_option  (opt, arg) char *opt, *arg;
{
  if (!strcmp (opt, "U"))
      options |= VL_O_LISTUDALONG;
  
  options |= VL_O_LISTUDA;
  immediate_output++;
  
  if (*arg) {
    options |= VL_O_UDAGIVEN;
    /*    PutUdattrs (arg); */
    AddUdattrs (arg);
  }
  multicol_output_possible = 0;

  return 0;
}

/*ARGSUSED*/
handle_V_option (opt, arg) char *opt, *arg;
{
  options |= VL_O_VERSIONNUM;
  if (version_number = mkvno (arg)) return 0;
  fprintf (stderr, "\"%s\" is no appropriate argument to \'-V\' option.\n",
	   arg);
  return 1;
}	

LongUsage ()

     /*
      * Called via option -h. Long help.
      */
{
  fprintf (stderr, "vl lists the version informations of the given files.\n");
  fprintf (stderr, "When no argument is given, the current directory is checked.\n");
  fprintf (stderr, "Options are:\n");
  fprintf (stderr, " -A              list all information about Afs file.\n");
  fprintf (stderr, " -author authorspec   list Afs files matching author specifications.\n");
  fprintf (stderr, " -owner ownerspec    list Afs files matching owner specifications.\n");
  fprintf (stderr, "                 Author- and ownerspec can be of the form:\n");
  fprintf (stderr, "                   'user.group' || 'user.' || '.group' || '.'\n");
  fprintf (stderr, "                 the last form specifies any user and any group.\n");
  fprintf (stderr, " -l              list info in long format (as ls(1)).\n");
  fprintf (stderr, " -a              list also hidden file.\n");
  fprintf (stderr, " -n relspec      list all Afs files that are part of a release.\n");
  fprintf (stderr, "                 Relspec is a symbolic name given at save time.\n");
  fprintf (stderr, "                 If no relspec is given all Afs files that are\n");
  fprintf (stderr, "                 part of any release are printed.\n");
  fprintf (stderr, " -g              list also group name (only effective when -l given).\n");
  fprintf (stderr, " -s versstate    list version with specified version state set.\n");
  fprintf (stderr, " -q              Be quiet. Set only status on exit.\n");
  fprintf (stderr, " -S              list version state verbose.\n");
  fprintf (stderr, " -u[:udaspec]    list user defined attributes.\n");
  fprintf (stderr, " -U[:udaspec]    list user defined attributes and corresponding values.\n");
  fprintf (stderr, "                 When 'udaspec' is given all Afs files matching udaspec\n");
  fprintf (stderr, "                 are printed.\n");
  fprintf (stderr, "                 Udaspec can be of the form:\n");
  fprintf (stderr, "                 name[=value[ value [...]]][,value[...]]...\n");
  fprintf (stderr, "                 For more infomation see also af_retrieve(3)\n");
  fprintf (stderr, " -ux             list also hidden uda, iff -u or -U is given\n");
  fprintf (stderr, " -V versspec     list Afs files with version number versspec (e.g. -V1.19).\n");
  fprintf (stderr, "                 'Versspec' can be of the form:\n");
  fprintf (stderr, "                  'generation.revision' || 'generation.' || '.revision' || '.'\n");
  fprintf (stderr, "                 The last form represents all possible version numbers.\n");
  fprintf (stderr, " -L              cat log message of Afs files. Afs file name required.\n");
  fprintf (stderr, " -H              list history of log messages up to a specified version (-V).\n");
  fprintf (stderr, "                 When '-H+' is given the history is listed from the specified.\n");
  fprintf (stderr, "                 version upto the last version.\n");
}

#define STDOUT_FDESC 1

int multicol_output_is_possible ()
{
  return (multicol_output_possible && isatty (STDOUT_FDESC));
}

CheckProgramName (progname)
     char *progname;
{
  extern char *rindex();
  
  if (!strcmp (progname, "vlog")) {
    (void)handle_L_option ((char *)NULL, (char *)NULL);
  }
}
