/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*
 * $Header: vadm.h[3.6] Thu Feb 23 18:14:07 1989 axel@coma published $
 *
 * Log for /u/shape/dist-tape/src/vc/vadm.h[3.4]
 * 	Thu Feb 23 18:14:07 1989 axel@coma published $
 *  --- empty log message ---
 *  vadm.h[3.5] Thu Feb 23 18:14:07 1989 axel@coma published $
 *  --- empty log message ---
 *  vadm.h[3.6] Thu Feb 23 18:14:07 1989 axel@coma published $
 *  --- empty log message ---
 */


/* miscellaneous */
#define MAIL "/usr/ucb/mail -s 'Your lock on %s was broken by %s' "

/* options */
#define Vopt_help 01
#define Vopt_binary 02
#define Vopt_version 010000
#define Vopt_no_confirm 020000
#define Vopt_quiet 040000

/* actions */
#define Varg_reserve 01
#define Varg_unreserve 02
#define Varg_symname 04
#define Varg_delete 010
#define Varg_promote 020
#define Varg_unpromote 040
#define Varg_change_note 0100
#define Varg_change_description 0200
#define Varg_set_note 0400
#define Varg_set_description 01000
#define Varg_lock 02000
#define Varg_unlock 04000
#define Varg_chmod 010000
#define Varg_chown 020000
#define Varg_chaut 040000
#define Varg_setuda 0100000
#define Varg_unsetuda 0200000
#define Varg_setattrs 0400000
#define Varg_setc_symbol 01000000
#define Varg_set_intent 02000000

#define SetBit(x,b) ((x) |= (b))
#define ClearBit(x,b) ((x) &= ~(b))
#define IsBitSet(x,b) ((x) & (b))
#define IsBitCleared(x,b) !(IsBitSet((x),(b)))

#define SetOption(b) SetBit(options, (b))
#define ClearOption(b) ClearBit(options, (b))
#define IsOptionSet(b) IsBitSet (options, (b))
#define IsOptionCleared(b) IsBitCleared (options, (b))

#define SetAction(b) SetBit(actions, (b))
#define ClearAction(b) ClearBit(actions, (b))
#define IsActionSet(b) IsBitSet (actions, (b))
#define IsActionCleared(b) IsBitCleared (actions, (b))

struct vc_vlist {
  char from_version_set, to_version_set;
  int from_generation;
  int from_revision;
  int to_generation;
  int to_revision;
  struct vc_vlist *next;
};

