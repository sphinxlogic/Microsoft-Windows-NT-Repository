/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: vldovl.c[3.10] Thu Feb 23 18:14:47 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/vldovl.c[3.4]
 * 	Thu Feb 23 18:14:48 1989 axel@coma published $
 *  --- empty log message ---
 *  vldovl.c[3.6] Thu Feb 23 18:14:48 1989 uli@coma published $
 *  --- empty log message ---
 *  vldovl.c[3.8] Thu Feb 23 18:14:48 1989 axel@coma published $
 *  --- empty log message ---
 *  vldovl.c[3.9] Thu Feb 23 18:14:48 1989 axel@coma save $
 *  --- empty log message ---
 *  vldovl.c[3.10] Thu Feb 23 18:14:48 1989 axel@coma published $
 *  --- empty log message ---
 */

#include <stdio.h>
#include <strings.h>
#include <afs.h>
#include "vl.h"

extern int immediate_output;
extern int version_number;

/*
 * Global variables
 */

char pathname_required = 0;
extern char vl_cwd[];
char buf[1000];
char *pending_name;		/* Holds the name of a dir */
int dir_pending = 0;

Af_attrs AF_attrbuf;
Af_set AF_fileset;
char error_string[80];

void InitAttrs (AF_attrbuf, name)
     Af_attrs *AF_attrbuf;
     char *name;
     /*
      * Initializes the attribute buffer.
      */
     
{
  register int i;
  int vno;
  register char **udattrs;
  extern char *GetAuthoridFromAuthor(), *GetOwneridFromOwner(),
              *GetAuthorhostFromAuthor(), *GetOwnerhostFromOwner();
  char cstring[MAXNAMLEN], vstring[16];

  af_initattrs (AF_attrbuf);

  if (name && name[0] != '\0') {
    if (BoundVersion (name, cstring, vstring)) {
      /* This code kind of assumes, that directory names are not of */
      /* the kind 'dirname[2.9]' -- good luck! */
      vno = mkvno (vstring);
      AF_attrbuf->af_gen = gen(vno);
      AF_attrbuf->af_rev = rev(vno);
      (void)strcpy (AF_attrbuf->af_syspath, af_afpath (cstring));
      (void)strcpy (AF_attrbuf->af_name, af_afname (cstring));
      (void)strcpy (AF_attrbuf->af_type, af_aftype (cstring));
      /* No further options are considered in this case */
    }
    else {  /* no bound version notation (e.g. foo.c[4.3]) for 'name' */ 
      if (IsDirectory (name)) {
	(void)strcpy (AF_attrbuf->af_syspath, name);
      }
      else { /* 'name' is not a directory */
	(void)strcpy (AF_attrbuf->af_syspath, af_afpath (name));
	(void)strcpy (AF_attrbuf->af_name, af_afname (name));
	(void)strcpy (AF_attrbuf->af_type, af_aftype (name));
      }
    }
  }
  /* Invariant: syspath, name and type fields of AF_attrbuf initialized */

  if (IsOptionSet(VL_O_UDAGIVEN)) {
    udattrs = GetUdattrs ();
    for (i = 0 ; udattrs[i] ; i++) {
      AF_attrbuf->af_udattrs[i] = udattrs[i];
    }
  }

  if (IsOptionSet(VL_O_VERSIONNUM)) {
    if (! (IsOptionSet(VL_O_HISTLOG) || IsOptionSet(VL_O_LOGMSG))) {
      if ((i = gen(version_number)) >= 0) {
	AF_attrbuf->af_gen = i;
      }
      if ((i = rev(version_number)) >= 0) {
	AF_attrbuf->af_rev = i;
      }
    }
  }

  if (IsOptionSet(VL_O_AUTHOR)) {
    (void)strcpy (AF_attrbuf->af_author.af_username, GetAuthoridFromAuthor());
    (void)strcpy (AF_attrbuf->af_author.af_userhost, GetAuthorhostFromAuthor());
  }

  if (IsOptionSet(VL_O_OWNER)) {
    (void)strcpy (AF_attrbuf->af_owner.af_username, GetOwneridFromOwner());
    (void)strcpy (AF_attrbuf->af_owner.af_userhost, GetOwnerhostFromOwner());
  }
  return;
}

int PrintUDA (attrbuf)
     Af_attrs *attrbuf;
{
  register char *cp;
  register int i;
  register char Checkbyte;
  register first_uda_printed;
  
  if ( (attrbuf->af_udattrs == NULL) || (attrbuf->af_udattrs[0] == '\0'))
    return 0;			/* no user defined attributes */
  
  
  if (IsOptionSet(VL_O_LONGOUTPUT)) {
    PrintLongVinfo (attrbuf); printf (":\n");
  }
  else {
    PrintShortVinfo (attrbuf); printf (":");
  }

  if (IsOptionSet(VL_O_LISTUDALONG)) {
    Checkbyte = '\0';
  }
  else {
    Checkbyte = '=';
  }

  first_uda_printed = 0;	/* nothing yet printed */
  
  for (i = 0; attrbuf->af_udattrs[i]; i++){
    cp = attrbuf->af_udattrs[i];

    if (!IsOptionSet(VL_O_LISTHIDDENUDAS) && IsHiddenUda (cp))
	  continue;
    if (first_uda_printed) {
      (void)putchar (';');		/* seperate udas by ';' */
    }
    else {
      (void)putchar (' ');
      first_uda_printed = 1;
    }
    
    while (cp && *cp && *cp != Checkbyte) {
      if (*cp == AF_UDAVALDEL) {
	(void)putchar (',');		/* seperate values of uda by ','
				 */
      }
      else {
	(void)putchar (*cp);
      }
      cp++;
    }
  }
  (void)putchar ('\n');
  (void)fflush (stdout);
  return 1;
}

PrintVinfo (attrbuf)
     Af_attrs *attrbuf;
{
  if (IsOptionSet(VL_O_LISTUDA|VL_O_LISTUDALONG)) {
    return PrintUDA (attrbuf);
  }
  
  if (IsOptionSet(VL_O_LONGOUTPUT)) {
    PrintLongVinfo (attrbuf);
    return 1;
  }

  PrintShortVinfo (attrbuf);
  return 1;
}

PrintShortVinfo (attrbuf)
     Af_attrs *attrbuf;
{
  if (immediate_output) {	/* set during option scanning */
    if (dir_pending) {	/*  now we can print the pending dir name */
      printf ("\n%s:\n", pending_name ? pending_name : ""); 
      dir_pending = 0;
    }
    
    printf ("%s%s%s%s%s%s%s%s", 
	    (pathname_required) ? attrbuf->af_syspath : "",
	    (pathname_required) ? "/" : "",
	    attrbuf->af_name,
	    (attrbuf->af_type && (attrbuf->af_type[0] != '\0') ? "." : ""),
	    attrbuf->af_type,
	    GetVersionId (attrbuf->af_gen, attrbuf->af_rev),
	    (IsOptionSet(VL_O_VERSIONSTATE)) ? " -> " : "",
	    (IsOptionSet(VL_O_VERSIONSTATE)) ? GetVersionState (attrbuf->af_state)
	    : "");
  }
  else {
    (void)sprintf (buf, "%s%s%s%s%s%s%s%s", 
	     (pathname_required) ? attrbuf->af_syspath : "",
	     (pathname_required) ? "/" : "",
	     attrbuf->af_name,
	     (attrbuf->af_type && (attrbuf->af_type[0] != '\0') ? "." : ""),
	     attrbuf->af_type,
	     GetVersionId (attrbuf->af_gen, attrbuf->af_rev),
	     (IsOptionSet(VL_O_VERSIONSTATE)) ? " -> " : "",
	     (IsOptionSet(VL_O_VERSIONSTATE)) ? GetVersionState (attrbuf->af_state)
	     : "");
    
    AddEntry (buf);
  }
}

PrintLongVinfo (attrbuf)
     Af_attrs *attrbuf;
{
  if (immediate_output) {	/* set during option scanning */
    char *p1 = NULL, *p2 = NULL;
    if (dir_pending) {	/*  now we can print the pending dir name */
      printf ("\n%s:\n", pending_name ? pending_name : ""); 
      dir_pending = 0;
    }
/* This is the place to put out the name of eventual lockholders */
    printf ("%s %s %s %s %8d %s %s%s%s%s%s%s",
	    GetMode (attrbuf->af_mode),
	    GetVersionState (attrbuf->af_state),
	    p1=GetUserInfo (&(attrbuf->af_owner)),
	    (IsOptionSet(VL_O_AUTHOR))
	    ? p2=GetUserInfo (&(attrbuf->af_author)) : "",
	    attrbuf->af_size,
	    (attrbuf->af_state > AF_BUSY) ? GetDate (attrbuf->af_stime)
	    : GetDate (attrbuf->af_mtime),
	    (pathname_required) ? attrbuf->af_syspath : "",
	    (pathname_required) ? "/" : "",
	    attrbuf->af_name,
	    (attrbuf->af_type && (attrbuf->af_type[0] != '\0')) ?  "."
	    : "",
	    attrbuf->af_type,
	    GetVersionId (attrbuf->af_gen, attrbuf->af_rev));
    if (p1) free (p1);
    if (p2) free (p2);
  }
  else {
    (void)sprintf (buf, "%s %s %s %s %8d %s %s%s%s%s%s%s",
	     GetMode (attrbuf->af_mode),
	     GetVersionState (attrbuf->af_state),
	     GetUserInfo (&(attrbuf->af_owner)),
	     (IsOptionSet(VL_O_AUTHOR))
	     ? GetUserInfo (&(attrbuf->af_author))  : "",
	     attrbuf->af_size,
	     (attrbuf->af_state > AF_BUSY) ? GetDate (attrbuf->af_stime)
	     : GetDate (attrbuf->af_mtime),
	     (pathname_required) ? attrbuf->af_syspath : "",
	     (pathname_required) ? "/" : "",
	     attrbuf->af_name,
	     (attrbuf->af_type && (attrbuf->af_type[0] != '\0')) ?  "."
	     : "",
	     attrbuf->af_type,
	     GetVersionId (attrbuf->af_gen, attrbuf->af_rev));
    AddEntry (buf);
  }
}

ReportVersionInfo (name)
     char *name;

     /*
      * Returns 0 if no info for name found, otherwise 1;
      */
{
  register int i;
  int numhits, Bnumhits=0;
  int retcode = 1, rc;		/* assume failure */
  char *cp;
  Af_set AF_sfileset, AF_bfileset;
  Af_key fkey;

  af_initset (&AF_sfileset);
  af_initset (&AF_bfileset);
  if (name && *name) {
    cp = af_afpath(name);
    if ( (! IsDirectory (name))
	&& *cp
	&& strcmp (cp, vl_cwd)) {
      /*
       * name is a normal file and is not in current working dir
       * require pathname on output
       */
      pathname_required = 1;
    }
    else {
      pathname_required = 0;
    }
  }
  if (IsOptionSet(VL_O_LASTVERS)) {
    rc=af_getkey (af_afpath (name), af_afname (name), af_aftype (name),
	       AF_LASTVERS, AF_LASTVERS, "", &fkey);
    if (rc < 0) {
      numhits = 0;
    }
    else {
      af_setaddkey (&AF_sfileset, 0, &fkey);
      numhits = 1;
    }
  }
  else {
    InitAttrs (&AF_attrbuf, name);
    
    /* now go, and get some info.... */
    if ((numhits = af_find (&AF_attrbuf, &AF_sfileset)) == -1) {
      (void)sprintf (error_string,
	       "%s: in ReportVersionInfo(): af_find (%s)",
	       GetProgramName (), name);
      af_perror (error_string);
      return (1); /*exit (1);*/
    }
    if (IsOptionSet(VL_O_LISTBINARY)) {
      if ((Bnumhits = af_bpfind (&AF_attrbuf, &AF_bfileset)) == -1) {
	(void)sprintf (error_string,
		 "%s: in ReportVersionInfo(): af_find (%s)",
		 GetProgramName (), name);
	af_perror (error_string);
	return (1); /*exit (1);*/
      }
    }
  }
  if (af_union (&AF_sfileset, &AF_bfileset, &AF_fileset) < 0) {
    af_perror ("af_union");
    return 1;
  }
  numhits += Bnumhits;
  af_dropset (&AF_sfileset);
  af_dropset (&AF_bfileset);
  /* nothing found ? */
  if (numhits == 0) {
    if (!IsOptionSet(VL_O_BEQUIET)) {
      if (name && *name) {
	if (! FileExists (name)) {
	  printf ("%s: %s: nothing appropriate found\n", GetProgramName (), name);
	}
      }
    }
    VinfoCleanup ();
    return 1;			/* report failure */
  }

  if ((*name != '\0') && IsDirectory (name)) {
    if (immediate_output) {
      /*
       * dir name must be printed, iff
       * something is found. But we can determine
       * this not yet.
       */
      dir_pending = 1;
      pending_name = name;
    }
    else
      AddClist (name);
  }
  
  /*
   * sort by name and version number. Busy version first then
   * versions with increasing version numbers.
   */

  if (af_sortset (&AF_fileset, AF_ATTHUMAN) == -1) { 
    (void)sprintf (error_string,
	     "%s: in ReportVersionInfo(): af_sortset by AF_ATTHIMAN",
	     GetProgramName);
    af_perror (error_string);
    exit (1);
  }
  
  for (i = 0; i < AF_fileset.af_nkeys; i++) {
    if (af_gattrs (&(AF_fileset.af_klist[i]), &AF_attrbuf) == -1) {
      (void)sprintf (error_string, "%s: in ReportVersionInfo(): af_gattrs");
      af_perror (error_string);
      exit (1);
    }
    else {
      if (IsHiddenFile(&AF_attrbuf) && !IsOptionSet(VL_O_LISTHIDDEN))
	continue;

      if (IsOptionSet(VL_O_STATEGIVEN)) {
	if (!MatchesVersionStates (&AF_attrbuf))
	  continue;
      }
      
      if (!IsOptionSet(VL_O_BEQUIET)) {
	if (IsOptionSet(VL_O_LOGMSG)) {
	  if (IsInHistoryLogMsgList (&AF_attrbuf)) {
	    if (PrintVinfo (&AF_attrbuf)) {
	      (void)putchar (':'); (void)putchar ('\n');
	      PrintLogMsg (&(AF_fileset.af_klist[i]));
	      retcode = 0;	/* success */
	    }
	  }
	}
	else {
	  (void)PrintVinfo (&AF_attrbuf);
	  retcode = 0;	/* success */
	}
      }
    }
  }
/*  VinfoCleanup (); */
  return retcode;
}

InitReportVersion ()
{
  InitCList ();
}

int PrintLogMsg (key)
     Af_key *key;
{
  register char *logmsg;
  
  if ((logmsg = af_rnote (key)) == NULL) {
    (void)sprintf (error_string, "%s: af_rnote", GetProgramName ());
    af_perror (error_string);
    exit (1);
  }

  printf ("%s", logmsg);
  if (logmsg[strlen(logmsg)-1] != '\n') {
    (void)putchar ('\n');
    (void)fflush (stdout);
  }
  free (logmsg);

}

int IsInHistoryLogMsgList (attrbuf)
     Af_attrs *attrbuf;
{
  if (attrbuf->af_state == AF_BUSY)
    return 0; /* is busy version */
  if (IsOptionSet(VL_O_HISTLOG) &&
      ! IsOptionSet(VL_O_VERSIONNUM)) 
    return 1;

  if (!IsOptionSet(VL_O_HISTLOG|VL_O_VERSIONNUM))
    return 1;
  else {
    if (IsOptionSet(VL_O_HISTLOGPLUS)) {
      if (attrbuf->af_gen > gen(version_number))
	return 1;
      if ((gen(version_number) == attrbuf->af_gen) &&
	  (attrbuf->af_rev > rev(version_number)))
	return 1;
    }
    else {
      if (attrbuf->af_gen < gen(version_number))
	return 1;
      if ((gen(version_number) == attrbuf->af_gen) &&
	  (attrbuf->af_rev < rev(version_number)))
	return 1;
    }
    if ((gen(version_number) == attrbuf->af_gen) &&
	(rev(version_number) == attrbuf->af_rev)) return 1;
  }
  return 0;
}

struct entry {
  char *repr;
  struct entry *next;
};

struct clist {			/* column list */
  char *dir;			/* name of dir */
  struct entry *entry;
  struct clist *next;
};

struct clist *clistroot;
struct clist *curclist;
struct entry *curentry;

InitCList ()
{
  if ((clistroot = (struct clist*) malloc (sizeof (struct clist))) == NULL) {
    (void)strcpy (error_string, "in InitClist (): malloc,1");
    perror (error_string);
    exit (1);
  }

  clistroot->dir = NULL;	/* has never a name */

/*  if ((clistroot->next = (struct clist*) malloc (sizeof (struct clist)))
      == NULL) {
    (void)strcpy (error_string, "in InitClist (): malloc,2");
    perror (error_string);
    exit (1);
  }
  */  
  clistroot->next = NULL;
  curclist = clistroot;
  
  if ((curentry = (struct entry*) malloc (sizeof (struct entry))) == NULL) {
    (void)strcpy (error_string, "in InitClist (): malloc,3");
    perror (error_string);
    exit (1);
  }
  curentry->repr = NULL;
  curentry->next = NULL;

  clistroot->entry = curentry;
}

AddClist (name) 
     char *name;
{
  struct clist *this_clist;

  if ((this_clist = (struct clist*) malloc (sizeof (struct clist))) == NULL) {
    (void)strcpy (error_string, "in AddCList (): malloc,1");
    perror (error_string);
    exit (1);
  }

  if ((this_clist->dir = malloc ((unsigned)(strlen (name)+1))) == NULL) {
    (void)strcpy (error_string, "in AddCList (): malloc,2");
    perror (error_string);
    exit (1);
  }

  if ((this_clist->entry = (struct entry*) malloc (sizeof (struct entry)))
      == NULL) {
    (void)strcpy (error_string, "in AddCList (): malloc,2");
    perror (error_string);
    exit (1);
  }
      
  (void)strcpy (this_clist->dir, name);
  this_clist->next = NULL;
  curentry = this_clist->entry;
  curentry->repr = NULL;
  curentry->next = NULL;

  curclist->next = this_clist;
  curclist = this_clist;
  
}
  
AddEntry (str)
     char *str;
{
  struct entry* this_entry;

  if ((curentry->repr = malloc ((unsigned)(strlen (str)+1))) == NULL) {
    (void)strcpy (error_string, "in AddEntry (): malloc,2");
    perror (error_string);
    exit (1);
  }

  (void)strcpy (curentry->repr, str);

  if ((this_entry = (struct entry*) malloc (sizeof (struct entry))) == NULL) {
    (void)strcpy (error_string, "in AddEntry (): malloc,1");
    perror (error_string);
    exit (1);
  }

  this_entry->repr = NULL;
  this_entry->next = NULL;
  curentry->next = this_entry;
  curentry = this_entry;
}

int computemaxlength (root)
  struct entry *root;
{
  struct entry *this_entry;
  int length = 0, maxlength = 0;
  
  if (!root) return 0;

  for (this_entry = root;
       this_entry->repr && this_entry->next;
       this_entry = this_entry->next) {
    length = strlen (this_entry->repr);
    if (length > maxlength) {
      maxlength = length;
    }
  }
  return maxlength;
}

PrintList (root, wordsperline, colwidth, newline_required, group_it)
     struct clist *root;
     int wordsperline, colwidth, newline_required, group_it;
{
  struct entry *this_entry;
  int nwordsprinted = 0;	/* number of words per line yet printed */
  int ntabs = 0;
  int length;

  if (/*root->entry && */root->entry->repr) {
    if (root->dir) {
      if (newline_required) (void)putchar ('\n');
      
      printf ("%s:\n", root->dir);
    }
  }
  
  if (!group_it) {
    for (this_entry = root->entry;
	 this_entry->repr && this_entry->next;
	 this_entry = this_entry->next) {
      printf ("%s\n", this_entry->repr);
    }
  }
  else {
    for (this_entry = root->entry;
	 this_entry->repr && this_entry->next;
	 this_entry = this_entry->next) {
      nwordsprinted++;
      if (!(nwordsprinted % wordsperline)) { /* if last word in this line */
	printf ("%s\n", this_entry->repr);
      }
      else {
	printf ("%s", this_entry->repr);
	
	/* compute #tabs to get to the next word position */
	length = strlen (this_entry->repr);
	ntabs = (colwidth - length) / 8;
	if ((colwidth - length) % 8)
	  ntabs++;
	
	while (ntabs--) (void)putchar ('\t');	  
      }
    }
    if (nwordsprinted % wordsperline) printf ("\n");
  }
}

FlushIt (root)
     struct clist *root;
{
  struct clist *this_clist;
  int colwidth = 0, wordsperline = 0;
  int maxlength = 0, newline_required = 0;
  
  for (this_clist = root; this_clist; this_clist = this_clist->next) {

    if (this_clist->entry && (this_clist->entry->repr == (char *) NULL))
      continue;			/* skip empty list */

    if (multicol_output_is_possible ()) {
      /* compute length of longest word in this list */
      maxlength = computemaxlength (this_clist->entry);
      
      /* compute length to next tab stop */
      colwidth = (maxlength / 8) + 1;
      colwidth *= 8;
      
      /* compute # words that fit in a line */
#define maxcol 80
      if (!(wordsperline = maxcol / colwidth)) wordsperline++;
      
    }
    
    PrintList (this_clist, wordsperline, colwidth, newline_required,
	       multicol_output_is_possible ());
    newline_required++;
  }
}

void FlushInfo ()
{
  if (!immediate_output)
    FlushIt (clistroot); /* Print now */
}
