/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: vc_lock.c[3.7] Thu Feb 23 18:14:33 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/vc_lock.c[3.4]
 * 	Thu Feb 23 18:14:33 1989 axel@coma published $
 *  --- empty log message ---
 *  vc_lock.c[3.5] Thu Feb 23 18:14:33 1989 axel@coma published $
 *  --- empty log message ---
 *  vc_lock.c[3.6] Thu Feb 23 18:14:33 1989 axel@coma save $
 *  --- empty log message ---
 *  vc_lock.c[3.7] Thu Feb 23 18:14:33 1989 axel@coma published $
 *  --- empty log message ---
 */

/*LINTLIBRARY*/
#define _VC_LOCK_
#include <sys/types.h>
#include <sys/stat.h>
#include <pwd.h>
#include <strings.h>
#include "afs.h"
#include "afsapp.h"

Af_user *vc_testlock (key, mode) Af_key *key; {
  return af_testlock (key, mode);
}

Af_user *vc_lock (key, uid, mode) Af_key *key; Uid_t uid; {
  Af_user alock;
  struct passwd *pw;

  pw = getpwuid ((int)uid);
  if (pw) {
    (void)strcpy (alock.af_username, pw->pw_name);
    (void)gethostname (alock.af_userhost, MAXHOSTNAMELEN);
    return af_lock (key, &alock, mode);
  }
  else {
    return NULL;
  }
}

Af_user *vc_unlock (key, mode) Af_key *key; {
  Af_user *waslocker;
  
  waslocker = af_unlock (key, mode);
  if (waslocker) {
    if (af_rstate (key) == AF_BUSY)
      af_sudattr (key, AF_REMOVE, INTENT);
  }
  return waslocker;
}

char *lockerid (lock) Af_user *lock; {
  static char rst[256];

  rst[0] = '\0';
  if (lock) {
    (void)sprintf (rst, "%s@%s", lock->af_username, lock->af_userhost);
  }
  return rst;
}

Uid_t lockeruid (lock) Af_user *lock; {
  char hostname[256];
  struct passwd *pw;

  if (!lock) return -1;
  (void)gethostname (hostname, 256);

  if (strcmp (hostname, lock->af_userhost) == 0) {
    pw = getpwnam (lock->af_username);
    if (pw)
      return pw->pw_uid;
    else 
      return -1;
  }
  else 
    return -1;
}

int locked (lock) Af_user *lock; {
  if (!lock) return 1;
  return lock->af_username[0];
}

char *getintent (prompt, oldintent) char *prompt, *oldintent; {
  char *tmpname, *mktemp(), *edname, cmd[128], *getenv(), messg[80], *malloc();
  static char *notetxt;
  FILE *tmpfil;
  struct stat statbuf;
  static int firsttime = TRUE;

  if (!(isatty(fileno(stdin)))) {
    return oldintent ? oldintent : EMPTYINTENT;
  }
  if ((!firsttime) && notetxt) {
    if (ask_confirm ("Same intent as before ?", "yes")) {
      return notetxt;
    }
    else {
      free (notetxt);
    }
  }
  firsttime = FALSE;
  if (!ask_confirm (prompt, "yes"))
    return oldintent ? oldintent : EMPTYINTENT;
  tmpname = mktemp ("/tmp/afsXXXXXX");
  Register (tmpname, TYPEF);
  if (oldintent) {
    FILE *t = fopen (tmpname, "w");
    if (fwrite (oldintent, sizeof (char), (Size_t)strlen (oldintent), t) !=
	strlen (oldintent)) {
      logerr ("write failure on tmp-file");
    }
    (void)fclose (t);
  }
  if (edname = getenv ("EDITOR")) {
    (void)sprintf (cmd, "%s %s", edname, tmpname);
    (void)sprintf (messg, "starting up %s ...", edname);
    logmsg (messg);
    if (system (cmd) == NOSHELL) {
      logerr ("couldn't execute shell");
    }
    else {
      if ((tmpfil = fopen (tmpname, "r")) == NULL) {
	logerr ("empty intent description");
	return EMPTYINTENT;
      }
      else {
	if (fstat (fileno(tmpfil), &statbuf) == -1) {
	  perror ("couldn't stat");
	}
	else {
	  notetxt = malloc ((unsigned)statbuf.st_size);
	  if (!notetxt) {
	    logerr ("not enough memory for intent text.");
	  }
	  (void)fread (notetxt, sizeof (char), 
		       (Size_t)statbuf.st_size, tmpfil);
	  (void)fclose (tmpfil);
	  (void)unlink (tmpname);
	  UnRegister (tmpname, TYPEF);
	  return notetxt;
	}
      }
    }
  }
  logerr 
   ("You must set the EDITOR environment variable to write a note of intent.");
  return EMPTYINTENT;   /* maybe we should try to read from stdin */
}
