/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: vc_keyboardIo.c[1.5] Thu Feb 23 18:14:31 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/vc_keyboardIo.c[1.3]
 * 	Thu Feb 23 18:14:31 1989 axel@coma published $
 *  --- empty log message ---
 *  vc_keyboardIo.c[1.4] Thu Feb 23 18:14:31 1989 axel@coma published $
 *  --- empty log message ---
 *  vc_keyboardIo.c[1.5] Thu Feb 23 18:14:31 1989 axel@coma published $
 *  --- empty log message ---
 */

#include <stdio.h>
#include "afsapp.h"

extern char *malloc();

#define INPUTQUEUE 4000
#define PROMPT "> "

/*ARGSUSED*/
static
char *read_unbuffered (term_char)
     int term_char;
{
  char *frame, *nextframe;
  int this_char, last_char, last_last_char, curlen, maxlen;

  if ((frame = 
       malloc ((unsigned)(sizeof (char) * (INPUTQUEUE + 1)))) == NULL) {
    fprintf (stderr, "read_unbuffered: can't malloc frame");
    exit (1);
  }

  curlen = 0;
  maxlen = INPUTQUEUE;
  nextframe = NULL;
  last_char = last_last_char = -1;
  
  (void)fflush(stdin);
  printf (PROMPT);

  while ((this_char = getchar()) != EOF) {
    if (curlen == maxlen) {
     /* we need a new frame */
      nextframe = 
	malloc ((unsigned)(sizeof (char) * (maxlen + INPUTQUEUE + 1)));
      if (nextframe == NULL) {
	fprintf (stderr, "read_unbuffer: can't malloc new frame,2");
	exit (1);
      }

      bzero (nextframe, maxlen + INPUTQUEUE + 1);
      bcopy (frame, nextframe, maxlen);
      free (frame);
      maxlen += INPUTQUEUE;
      frame = nextframe;
    }
	
    frame[curlen++] = this_char;

    if (this_char == '\n') {
      if ((last_char == '.')
	  && ((last_last_char == '\n') || (last_last_char == -1))) {
	/* input is done */
	curlen -= 2;		/* forget "<term_char>\n"  */
	break;
      }
      else
	printf (PROMPT);		/* print prompt */
    }
    
    last_last_char = last_char;
    last_char = this_char;
  }
  frame[curlen] = NULL;
  return frame;
}

static
char *read_buffered ()
{
  /* hmmm, muss ich erstmal ueber eine geniale
   * Implementierung nachdenken. Also erstmal
   * read_unbuffered ().
   */

  return read_unbuffered (-1);	/* no special term_char */
}

char *get_from_stdin (contents, term_char)
     char *contents;
     int term_char;		/* char that indicates input termination */
{
  /*
   * Reads from stdin a text terminated by ^D or by a specified
   * single charcter "term_char" at the beginning of a new line.
   * If term_char is -1 text is terminated  by ^D.
   *
   * The text is appended to "contents", if "contents" is given.
   */
  char *tmp, *new;
  int ltmp, lcontents;		/* length of tmp and contents */
  
  if (!isatty (0))		/* 0 == stdin */
    tmp = read_buffered ();	/* ignore term_char */
  else
    tmp = read_unbuffered (term_char);

  if (contents && *contents) {
    ltmp = strlen (tmp);
    lcontents = strlen (contents);
    if ((new = 
	 malloc ((unsigned)(sizeof (char) * (ltmp+lcontents+1)))) == NULL) {
      fprintf (stderr, "Get_from_stdin: Can't malloc");
      exit (1);
    }

    (void)sprintf (new, "%s%s", contents, tmp);
    free (tmp);
    return new;
  }

  return tmp;
}
