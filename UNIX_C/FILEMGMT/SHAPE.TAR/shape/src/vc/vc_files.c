/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *AFSid = "$Header: vc_files.c[1.9] Thu Feb 23 18:14:30 1989 axel@coma published $";
#ifdef CFFLGS
static char *ConfFlg = CFFLGS;
	/* should be defined from within Makefile */
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vc/vc_files.c[1.6]
 * 	Thu Feb 23 18:14:30 1989 axel@coma published $
 *  --- empty log message ---
 *  vc_files.c[1.7] Thu Feb 23 18:14:30 1989 axel@coma published $
 *  --- empty log message ---
 *  vc_files.c[1.8] Thu Feb 23 18:14:30 1989 axel@coma save $
 *  --- empty log message ---
 *  vc_files.c[1.9] Thu Feb 23 18:14:30 1989 axel@coma published $
 *  --- empty log message ---
 */

/*
 *
 * Functions to find, check for permission, and remote files.
 * This functions are highly operation system dependend.
 *
 * Currently this function are BSD43- and Ultrix1.0-proof. 
 *
 * Exports:
 *
 *   All functions described below return 1 for success or
 *   0 on failure. If return type is not "int" then on failure
 *   "(type-cast) NULL" is returned. See also descriptions below.
 *
 *   int GroupMember (gid)     WARNING: NOT ULTRIX COMPATIBLE
 *       int gid;
 *
 *         Checks if user is member of group gid.
 *
 *   int FileExecutable (file)
 *       char *file;
 *
 *   char *FindFile (file)
 *        char *file;
 *
 *        Returns the full absolute path name of file "file", if
 *        "file" exists. NULL otherwise. Searches the directories
 *        given in environment variable PATH. If path is not set,
 *        current working directory and "/bin" are checked.
 *
 *   char *FindProgram (file)
 *        char *file;
 *
 *        Acts as function FindFile(), but file must also be
 *        executable for caller.
 *
 *   RemoveFile (file)
 *        char *file;
 *
 *   int FileExists (file)
 *       char *file;
 */

#include <sys/param.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <stdio.h>
#include <strings.h>
#include <afs.h>
#include "afsapp.h"
#include "locks.h"
#include "vc_sysdep.h"

extern char *malloc(), *getenv();

/**/
int FileExecutable (file)
     char *file;
{
  return access (file, (X_OK | F_OK)) == -1 ? 0 : 1;
}

/**/
char *FindFile (file)
     char *file;
{
  char *path;
  char *dir, *edir;
  char *this;
  int flen;			/* length of "file" */
  flen = strlen (file) + 1;	/* for the good old null byte */
  this = NULL;

  /* get path from enivronment */
  if (!(path = getenv (PATH_ENV_NAME)))
    path = DEFAULT_PATH;

  while (1) {
    
    if ((dir = path) == NULL)
      return NULL;

    /* find end of dir in string */
    if (edir = index(path, ':')) {
      *edir = '\0';		/* make "dir" null terminated */
      path = edir + 1;		/* path points to next dir */
    }
    else
      path = NULL;		/* end of path reached */

    if (this) free (this);	/* no longer needed */

    if ((this = malloc ((unsigned)(strlen (dir) + flen))) == NULL) {
      fprintf (stderr, "FindFile(): can't malloc\n");
      exit (1);
    }

    /* file found ? */
    (void)sprintf (this, "%s/%s", dir, file);	/* construct new filename */
    if (FileExists (this))
      return this;		/* found */
  }
}
  
char *FindProgram (program)
     char *program;
{
  /*
   * returns the full pathname of "program", iff program is found
   * and executable (for world). Otherwise NULL.
   */

  /* if program has already a '/' in it, asume existence */
  if (!index (program, '/'))
    if ((program = FindFile (program)) == NULL)
      return NULL;		/* not found */

  /* prg contains the absolute file name and file exists.*/
  if (FileExecutable (program))
    return program;
  else
    return NULL;
}

RemoveFile (file)
     char *file;
{
  (void)unlink (file);
}

FileExists (file)
     char *file;
{
  /*
   * Returns 1 iff file exists, 0 otherwise.
   */
  struct stat sbuf;
  
  return !stat (file, &sbuf);
}

