/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*  LAST EDIT: Mon Feb 20 14:15:16 1989 by Uli Pralle (coma!uli)  */
/*
 * vfind.c
 */
#ifndef lint
static char *AFSid = "$Header: vfind.c[1.6] Tue Feb 21 20:22:53 1989 uli@coma published $";
static char *Objfile = "vfind.c[1.6] published";
#ifdef CFFLGS
  static char *Cflags = CFFLGS;
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vfind/vfind.c[1.6]
 * 	Tue Feb 21 20:22:53 1989 uli@coma published $
 *  
 *    	* Vfind is the same as find(1) except that it has more afs
 *    	related primaries such as -eq, -le, -lt, -ge, -gt, -uda,
 *  	-symbolic, -locked, -locker, etc.
 *  
 *  	* vfind has problems with udas.
 *  
 *  	* vfind is part of the shape toolkit release for comp.sources.unix.
 *  
 *  
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/dir.h>
#include <sys/wait.h>
#include <stdio.h>
#include <strings.h>
#include <afs.h>
#include <afsapp.h>
#include <ParseArgs.h>

#include "atk.h"

typedef struct expr *Expr;	/* short hand */
struct expr {
  int (*eval)();		/* evaluator */
  Expr left;			/* left op */
  Expr right;			/* right op */
};

extern char *getwd();
extern char *malloc();
extern char *re_comp();

static char *progname;			/* av[0] w/o leading path */ 
static char startdir[MAXPATHLEN+1]; /* dir at beginning of process */
static char garbage[80];	/* for error messages */
static int nac;			/* ac after option parsing */
static char **nav;		/* av after option parsing */
static int npaths;		/* pathname list */
static struct expr *exprl;	/* expression list */
static int idx;			/*  */
static long now;		/* time in secs */
static Af_attrs attrs;		/* attr buf */
static Af_set set, bset;	/* attr set */
static int Bflag, Pflag, Fflag;

/* Options */
static int vf_prune_opt () {
  Pflag++;
  return 0;
}

static int vf_version_opt () {
  char *vfversion();
  
  (void) printf ("This is %s version %s.\n", progname, vfversion());
  (void) printf ("AFS version %s.\n", af_version());
  return 1;			/* force termination */
}

static int vf_b_opt () {
  Bflag++;
  return 0;
}

static int vf_f_opt () {
  Fflag++;
  return 0;
}

static int vf_help_opt () {
  extern OptDesc optdesc[];
  pa_ShortUsage(progname, optdesc, "path-list expression");

  return 1;
}

OptDesc optdesc[] = {
  { "version", OPT_IS_SWITCH, vf_version_opt },
  { "bpool", OPT_IS_SWITCH, vf_b_opt},
  { "h", OPT_IS_SWITCH, vf_help_opt},
  { "prune", OPT_IS_SWITCH, vf_prune_opt},
  { "force", OPT_IS_SWITCH, vf_f_opt},
  { (char *) NULL, NULL, NULL },
};

void byebye(i) {
  (void) chdir("/tmp");		/* in case of -pg. */
  exit(i);
}

void Usage() {
  (void) fprintf (stderr,"%s: usage: %s path-list expression.\n",
		  progname , progname);
  byebye(1);
}

/* primaries */
static int print () {
  puts(at_getbndvers(&attrs));
  return 1;
}

char *mkedpat(pat) char *pat; {
  char pattern[1024];
  char *cp;
  int i;

  if (pat && *(cp = pat) == '\0')
    return (char *) NULL;

  *pattern = '^';
  for (i = 1; *cp; cp++) {
    if (i >= 1024) {
      (void) fprintf (stderr, "%s: pattern to long.\n", progname);
      byebye(1);
    }
    
    switch (*cp) {
    case '?':
      pattern[i++] = '.';
      break;
    case '*':
      pattern[i++] = '.'; pattern[i++] = '*';
      break;
    default:
      pattern[i++] = *cp;
      break;
    }
  }
  pattern[i++] = '$'; pattern[i] = '\0';
  
  if ((cp = malloc ((unsigned) (strlen(pattern) + 1))) == (char *) NULL) {
    (void) fprintf (stderr, "%s: out of memory.\n", progname);
    byebye(1);
  }
  return strcpy(cp, pattern);
}

static int name (exp) Expr exp; {
  char *cp;
  
  if (cp = re_comp ((char *) exp->left)) {
    (void) fprintf (stderr, "%s: %s\n", progname, cp);
    byebye(1);
  }

  return re_exec(at_getfilename(&attrs));

}

static int state (exp) Expr exp; {
  return attrs.af_state == (int) exp->left;
}

static int uda (exp) Expr exp; {
  return (at_matchuda(&attrs, (char *) exp->left));
}

static int symname (exp) Expr exp; {
  char symnameuda[AF_UDANAMLEN+1];

  return at_matchuda(&attrs, sprintf(symnameuda, "%s=%s", SYMNAME,
				     (char *) exp->left));
}

static int perm (exp) Expr exp; {
  return (attrs.af_mode & (int) exp->right & 07777) == (int) exp->left;
}

static int user (exp) Expr exp; {
  return (!strcmp((char *)exp->left, attrs.af_owner.af_username)
	  && (exp->right ? !strcmp((char *)exp->right,
				  attrs.af_owner.af_userhost) : 1));
}

static int locked () {
  return (attrs.af_locker.af_username[0] != '\0');
}

static int locker (exp) Expr exp; {
  return (!strcmp((char *)exp->left, attrs.af_locker.af_username)
	  && (exp->right ? !strcmp((char *)exp->right,
				  attrs.af_locker.af_userhost) : 1));
}

static int type (exp) Expr exp; {
  return (attrs.af_mode&S_IFMT) == (int) exp->left;
}

static int vl () {
  printf ("%s %s %s %8d %s %s\n",
	  at_getmode(&attrs),
	  at_getversstate(&attrs, 0),
	  at_getuser(&(attrs.af_owner)),
	  attrs.af_size,
	  at_getdate(&attrs),
	  at_getbndvers(&attrs));
  return 1;
}

static int eq (exp) Expr exp; {
  return (attrs.af_gen == (int) exp->left) &&
    (attrs.af_rev == (int) exp->right);
}

static int lt (exp) Expr exp; {
  return (attrs.af_gen < (int) exp->left ||
	  (attrs.af_gen == (int) exp->left &&
	   attrs.af_rev < (int) exp->right));
}

static int le (exp) Expr exp; {
  return lt(exp) || eq(exp);
}

static int gt (exp) Expr exp; {
  return (attrs.af_gen > (int) exp->left ||
	  (attrs.af_gen == (int) exp->left &&
	   attrs.af_rev > (int) exp->right));
}

static int ge (exp) Expr exp; {
  return gt(exp) || eq(exp);
}


#define SECSPERDAY 86400L
static int comptime(secs, days, sign)
     time_t secs;
     int days;
     char sign;
{
  int d;
  
  d = (int) ((now - secs) / SECSPERDAY);
  switch (sign) {
  case '+': return (d>days);
  case '-': return (d < (days * -1));
  default: return (d==days);
  }
}

static int mtime (exp) Expr exp; {
  return comptime(attrs.af_mtime, (int) exp->left, *(char*)(exp->right));
}

static int atime (exp) Expr exp; {
  return comptime(attrs.af_atime, (int) exp->left, *(char*)(exp->right));
}

static int chngtime (exp) Expr exp; {
  return comptime(attrs.af_ctime, (int) exp->left, *(char*)(exp->right));
}

static int stime (exp) Expr exp; {
  return comptime(attrs.af_stime, (int) exp->left, *(char*)(exp->right));
}

static int ltime (exp) Expr exp; {
  return comptime(attrs.af_ltime, (int) exp->left, *(char*)(exp->right));
}

static int execute (exp) Expr exp; {
  char *pav[40], *arg;
  int i, j;
  int pid, wpid;
  union wait retcode;

  i = (int) exp->left;
  for (j = 0; strcmp((arg = nav[i++]), ";"); j++)
    if (!strcmp(arg, "{}"))
      pav[j] = at_getbndvers(&attrs);
    else
      pav[j] = arg;

  pav[j] = (char *) NULL;
  if (j == 0) return 1;
  
  (void) fflush(stdout);
  switch (pid = fork()) {
  case -1:
    perror (sprintf(garbage, "%s: fork failed\n", progname));
    byebye(1);
    break;
  case 0:
    (void) chdir(startdir);
    /*VARARGS*/
    (void) execvp(pav[0], pav);
    (void) perror("vfind: exec failed");
    (void) kill (getpid(), SIGHUP);
    _exit(127);
    break;
  default:
    while ((wpid = wait(&retcode)) != -1 && wpid != pid);
    if (retcode.w_status&0177) {
      (void) fprintf (stderr, "%s: execution terminated\n", progname);
      byebye(1);
    }
    return (!retcode.w_status);
    break;
  }
  /*NOTREACHED*/
}

static int not (exp) Expr exp; {
  return ! ((*exp->left->eval) (exp->left));
}

static int and (exp) Expr exp; {
  return ((*exp->left->eval) (exp->left) &&
	  (*exp->right->eval) (exp->right)) ? 1 : 0;
}

static int or (exp) Expr exp; {
  return ((*exp->left->eval) (exp->left) ||
	  (*exp->right->eval) (exp->right)) ? 1 : 0;
}

/* constructors */
static Expr build(func, l, r)
     int (*func)();
     Expr l, r;
{
  Expr this;
  if ((this = (Expr) malloc ((unsigned) sizeof (struct expr))) ==
      (Expr) NULL) {
    (void) fprintf (stderr, "%s: out of memory.\n", progname);
    byebye (1);
  }

  this->eval = func; this->left = l; this->right = r;
  return this;
}

static void skip() {
  if (nav[idx])
    idx++;
  else {
    (void) fprintf (stderr, "%s: parsing error\n", progname);
    byebye(1);
  }
}

static Expr primary () {
  char *prim, *val, *cp;
  char c;
  int i = 0;
  int mode = 0;
  int mask = 0;

  val = cp = (char *) NULL;
  
  if (!(prim = nav[idx])) {
    (void) fprintf (stderr, "%s: parsing error\n", progname);
    byebye(1);
  }
  
  if (*prim != '-') {
    (void) fprintf(stderr, "%s: %s is not a primary\n", progname, prim);
    byebye(1);
  }
  prim++;
  if (!strcmp (prim, "print"))
    return build(print, (Expr) NULL, (Expr) NULL);
  if (!strcmp(prim, "ls") || !strcmp(prim, "vl"))
    return build(vl, (Expr) NULL, (Expr) NULL);
  if (!strcmp(prim, "locked"))
    return build(locked, (Expr) NULL, (Expr) NULL);
  
  skip();
  if (!(val = nav[idx])) {
    (void) fprintf (stderr, "%s: parsing error\n", progname);
    byebye(1);
  }
  
  if (!strcmp (prim, "name"))
    return build(name, (Expr) mkedpat(val), (Expr) NULL);
  if (!strcmp(prim, "type")) {
    c = *val;
    i = (c=='b' ? S_IFBLK : c=='c' ? S_IFCHR :
	 c=='d' ? S_IFDIR : c=='f' ? S_IFREG :
	 c=='l' ? S_IFLNK : c=='s' ? S_IFSOCK : NULL);
      return build(type, (Expr) i, (Expr) NULL);
  }
  if (!strcmp(prim, "perm")) {
    while(c = *val++)
      if (c=='-') mask++;
      else {
	c -= '0'; mode <<= 3; mode += c;
      }
    return build(perm, (Expr) mode, (Expr) (mask ? mode : 07777));
  }
  if (!strcmp(prim, "atime"))
    return build(atime, (Expr) atoi(val), (Expr) val);
  if (!strcmp(prim, "ctime"))
    return build(chngtime, (Expr) atoi(val), (Expr) val);
  if (!strcmp(prim, "mtime"))
    return build(mtime, (Expr) atoi(val), (Expr) val);
  if (!strcmp(prim, "stime"))
    return build(stime, (Expr) atoi(val), (Expr) val);
  if (!strcmp(prim, "ltime"))
    return build(ltime, (Expr) atoi(val), (Expr) val);
  if (!strcmp(prim, "user")) {
    if (cp = rindex(val, '@')) *cp++ = '\0';
    return build(user, (Expr) val, (Expr) cp);
  }
  if (!strcmp(prim, "eq")) {
    if (cp = rindex(val, '.')) *cp++ = '\0';
    return build(eq, (Expr) atoi(val), (Expr) atoi(cp));
  }
  if (!strcmp(prim, "le")) {
    if (cp = rindex(val, '.')) *cp++ = '\0';
    return build(le, (Expr) atoi(val), (Expr) atoi(cp));
  }
  if (!strcmp(prim, "lt")) {
    if (cp = rindex(val, '.')) *cp++ = '\0';
    return build(lt, (Expr) atoi(val), (Expr) atoi(cp));
  }
  if (!strcmp(prim, "ge")) {
    if (cp = rindex(val, '.')) *cp++ = '\0';
    return build(ge, (Expr) atoi(val), (Expr) atoi(cp));
  }
  if (!strcmp(prim, "gt")) {
    if (cp = rindex(val, '.')) *cp++ = '\0';
    return build(gt, (Expr) atoi(val), (Expr) atoi(cp));
  }
  if (!strcmp(prim, "locker")) {
    if (cp = rindex(val, '@')) *cp++ = '\0';
    return build(locker, (Expr) val, (Expr) cp);
  }
  if (!strcmp(prim, "exec") || !strcmp(prim, "ok")) {
    i = idx;
    while(nav[++idx] && strcmp(nav[idx], ";"));
    return build(execute, (Expr) i, (Expr) prim);
  }
  if (!strcmp(prim, "state"))
    return build(state, (Expr) at_string2state(val), (Expr) NULL);
  if (!strcmp(prim,"uda"))
    return build(uda, (Expr) val, (Expr) NULL);
  if (!strcmp(prim,"symbolic"))    
    return build(symname, (Expr) val, (Expr) NULL);
  (void) fprintf (stderr,"%s: unknown primary %s.\n", progname, prim);
  byebye(1);
  /*NOTREACHED*/
}

static Expr alternation();	/* forward declaration */

static Expr grouping () {
  Expr expr;
  
  if (!strcmp(nav[idx], "(")){
    skip();
    expr = alternation();
    if (nav[idx] && !strcmp(nav[idx], ")")) {
      skip();
      return expr;
    }
    (void) fprintf (stderr, "%s: missing closing ')'.\n", progname);
    byebye(1);
  }
  else {
    expr = primary();
    skip();		/* primary() does not skip the */
				/* processed token, so we do it here. */
    return expr;
  }
  /*NOTREACHED*/
}

static Expr negation() {
  if (nav[idx] && !strcmp(nav[idx], "!")) {
    skip();
    return build(not, grouping(), (Expr) NULL);
  }
  else
    return grouping();
}

static Expr concatenation() {
  Expr left;
  char *this;
  
  left = negation ();
  this = nav[idx];
  if (this && (!strcmp(this, "-a") || !strcmp(this, "!") ||
	       !strcmp(this,"(") || (*this == '-' && strcmp(this, "-o")))){
    if (!strcmp(this,"-a")) skip();
    return build(and, left, concatenation());
  }
  else
    return left;
}

static Expr alternation() {
  Expr left;
  
  left = concatenation();
  if (nav[idx] && !strcmp(nav[idx], "-o")) {
    skip();
    return build(or, left, concatenation());
  }
  else
    return left;
}

static Expr expression() {
  return alternation();
}

static int dselect (d)
     struct direct *d;
{
  char *name = d->d_name;
  
  if ((name[0] == '.' && name[1] == '\0') ||
       (name[0] == '.' && name[1] == '.' && name[2] == '\0'))
    return 0;
  return 1;
}

static int adselect (d)
     struct direct *d;
{
  char *name = d->d_name;
  
  if (d->d_name[d->d_namlen -1] == AF_ARCHEXT)
    return 1;
  return 0;
}

static int indp (dp, dpentr, name, len)
     struct direct **dp;
     char *name;
     int len, dpentr;
{
  int i;
  for (i = 0; i < dpentr; i++)
    if (dp[i]->d_namlen == len && !strcmp(dp[i]->d_name, name))
      return 1;
  return 0;
}

static void traverse (name, afs_is_dir)
     char *name;
     int afs_is_dir;		/* 1 if symbolic link */
{
  struct stat buf, abuf;
  struct direct **dp, **adp;
  int nhits, ahits, i;
  static int ncalls;
  char *cp;

  (void) af_initattrs(&attrs); (void) af_initset(&set);
  (void) strcpy(attrs.af_syspath, af_afpath(name));
  (void) strcpy(attrs.af_name, af_afname(name));
  (void) strcpy(attrs.af_type, af_aftype(name));

  if (!afs_is_dir)		/* afs dir is symbolic link */
    attrs.af_state = AF_BUSY;

  if (af_find(&attrs, &set) == -1) {
    (void) af_perror(sprintf(garbage, "%s: af_find(%s)", progname, name));
    return;
  }
  if (Bflag) {
    (void) af_initset(&bset);
    if (af_bpfind(&attrs, &bset) == -1) {
      (void) af_perror(sprintf(garbage, "%s: bp_find(%s)", progname, name));
      (void) af_dropset(&set);
      return;
    }
    (void) af_union(&set, &bset, &set); (void) af_dropset(&bset);
  }
	
  nhits = af_nrofkeys(&set);
  (void) af_sortset(&set, AF_ATTHUMAN);
  for (i = 0; i < nhits; i++) {
    if (af_gattrs(&(set.af_klist[i]),&attrs) == -1) {
      (void) af_perror(sprintf(garbage,"%s: af_gattrs():",progname));
      continue;
    }
    (*exprl->eval)(exprl);
  }
  (void) af_dropset(&set);
  
  if ((lstat(name, &buf) == -1) ||
      ((buf.st_mode&S_IFMT) != S_IFDIR) ||
      (Pflag && ncalls) || 
      !strcmp(name, AF_SUBDIR))
    return;

  if (chdir(name) == -1)
    return;
  
  if ((nhits = scandir(".", &dp, dselect, NULL)) == -1) {
    fprintf (stderr, "%s: can't open dir %s.\n", progname, name);
    return;
  }
  afs_is_dir = (lstat(AF_SUBDIR, &abuf) != -1 &&
		(((abuf.st_mode&S_IFMT) == S_IFDIR) || Fflag));
  if (afs_is_dir &&
      ((ahits = scandir(AF_SUBDIR, &adp, adselect, NULL)) != -1)) {
    for (i = 0; i < ahits; i++) {
      cp = adp[i]->d_name + 2;
      cp[adp[i]->d_namlen -3] = '\0';
      if ((cp && *cp) && !indp(dp, nhits, cp, adp[i]->d_namlen - 3)) {
	ncalls++; traverse(cp, afs_is_dir); ncalls--;
      }
      (void) free((char *)adp[i]);
    }
    (void) free((char *)adp);
  }
  for (i = 0; i < nhits; i++){
    ncalls++; traverse(dp[i]->d_name, afs_is_dir); ncalls--;
    (void) free((char *)dp[i]);
  }
  (void) free((char *)dp);

  (void) chdir("..");
  return;
}

main (ac, av)
     int ac;
     char *av[];
{
  char *cp;
  struct stat buf;
  int afs_is_dir;
  
  progname = (cp = rindex(av[0], '/')) ? ++cp : av[0];
  if (ParseArgs(ac, av, &nac, &nav, optdesc)) byebye(1);
  (void) getwd(startdir); (void) time(&now);
  
  if (nac < 2) Usage();
  for (idx = 0; idx < nac; idx++) /* find path list */
    if (*nav[idx] == '-' ||  *nav[idx] == '!' || *nav[idx] == '(') break;
  if (!(npaths = idx)){
    (void) fprintf (stderr, "%s: no path list.\n", progname); Usage();
  }
  if (idx == nac) {
    (void) fprintf (stderr, "%s: no expression.\n", progname); Usage();
  }

  if ((exprl = expression()) == (Expr) NULL) byebye(1);
  
  for (idx = 0 ; idx < npaths; idx++) {	/* for all directories */
    (void) chdir(startdir);	/* back to normal */
    afs_is_dir = (lstat(sprintf(garbage, "%s/%s", cp = nav[idx], AF_SUBDIR),
			&buf) != -1 &&
		  (((buf.st_mode&S_IFMT) == S_IFDIR) || Fflag));
    traverse(cp, afs_is_dir);
  }

  byebye(0);
}
