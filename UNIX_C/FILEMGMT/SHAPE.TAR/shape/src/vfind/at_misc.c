/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*  LAST EDIT: Mon Feb 20 15:43:04 1989 by Uli Pralle (coma!uli)  */
/*
 * at_misc.c
 */
#ifndef lint
static char *AFSid = "$Header: at_misc.c[1.2] Tue Feb 21 20:22:58 1989 uli@coma published $";
static char *Objfile = "at_misc.c[1.2] published";
#ifdef CFFLGS
  static char *Cflags = CFFLGS;
#endif
#endif
/*
 * Log for /u/shape/dist-tape/src/vfind/at_misc.c[1.2]
 * 	Tue Feb 21 20:22:58 1989 uli@coma published $
 *  	* This file contains many AFS utilities that makes life easier.
 *  	  This comes with atk.h.
 *  
 *  
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <time.h>
#include <strings.h>

#include <afs.h>

extern char *malloc();
static char at_filemode[12];

char *at_getmode (attr)
     Af_attrs *attr;
{
  /* This function should return a capital 'L' in the file-class field */
  /* to indicate a *locked* version. Maybe optional. Instead of Ownername */
  /* the name of the locker is to be printed. */
  ushort mode;

  mode = attr->af_mode;
  (void) sprintf (at_filemode, " %c%c%c%c%c%c%c%c%c",
		  (mode & S_IREAD) ? 'r' : '-',
		  (mode & S_IWRITE) ? 'w' : '-',
		  (mode & S_IEXEC) ? 'x' : '-',
		  (mode & (S_IREAD >> 3)) ? 'r' : '-',
		  (mode & (S_IWRITE >> 3)) ? 'w' : '-',
		  (mode & (S_IEXEC >> 3)) ? 'x' : '-',
		  (mode & (S_IREAD >> 6)) ? 'r' : '-',
		  (mode & (S_IWRITE >> 6)) ? 'w' : '-',
		  (mode & (S_IEXEC >> 6)) ? 'x' : '-'
		  );

  switch (mode & S_IFMT) {
  case S_IFDIR:
    at_filemode[0] =  'd';
    break;
  case S_IFCHR:
    at_filemode[0] = 'c';
    break;
  case S_IFBLK:
    at_filemode[0] = 'b';
    break;
  case S_IFREG:
    at_filemode[0] = '-';
    break;
  case S_IFLNK:
    at_filemode[0] = 'l';
    break;
  case S_IFSOCK:
    at_filemode[0] = 's';
    break;
  }
  
  if (mode & S_ISUID)
    at_filemode[1] = 's';
  if (mode & S_ISGID)
    at_filemode[6] = 's';
  if (mode & S_ISVTX)
    at_filemode[9] = 't';

  return at_filemode;
}

char *
#ifdef __STDC__
  at_symbfiletype (u_short mode, int afstate)
#else
symbfiletype (mode, afstate) u_short mode; int afstate;
#endif
{
  if (afstate == AF_NOSTATE) return "$"; /* derived object */
  switch (mode & S_IFMT) {
  case S_IFDIR:
    return "/";
  case S_IFLNK:
    return "@";
  case S_IFSOCK:
    return "=";
  default:
    if ((mode & S_IEXEC) || (mode & (S_IEXEC >> 3)) || (mode & (S_IEXEC >> 6)))
      return "*";
    else
      return "";
  }
}

int at_string2state (string)
     char *string;
{
  if (!strcmp(string,"busy"))
    return AF_BUSY;
  else if (!strcmp(string,"save"))
    return AF_SAVED;
  else if (!strcmp(string,"proposed"))
    return AF_PROPOSED;
  else if (!strcmp(string,"published"))
    return AF_PUBLISHED;
  else if (!strcmp(string,"accessed"))
    return AF_ACCESSED;
  else if (!strcmp(string,"frozen"))
    return AF_FROZEN;
  else return AF_NOSTATE;
}

char *at_getversstate (attr, verbose) Af_attrs *attr; int verbose;
{
  int state;

  state = attr->af_state;
  
  switch (state) {
  case AF_BUSY:
    return verbose ? "[busy]" : "b";
  case AF_SAVED:
    return verbose ? "[save]" : "s";
  case AF_PROPOSED:
    return verbose ? "[prop]" : "p";
  case AF_PUBLISHED:
    return verbose ? "[publ]" : "P";
  case AF_ACCESSED:
    return verbose ? "[acce]" : "a";
  case AF_FROZEN:
    return verbose ? "[froz]" : "f";
  default:
    return verbose ? "[drvd]" : "$"; /* binary pool ? */
  }
}

static char boundversion[2*MAXNAMLEN];

char *at_getbndvers (attr)
     Af_attrs *attr;     
{
  char *path, *name, *type;
  int gen, rev;
  
  path = attr->af_syspath;
  name = attr->af_name;
  type = attr->af_type;
  gen = attr->af_gen;
  rev = attr->af_rev;
  
  if (gen == AF_BUSYVERS && rev == AF_BUSYVERS) {
    (void) sprintf (boundversion, "%s%s%s%s%s",
		    (path[0]) ? path : "",
		    (path[0]) ? "/" : "",
		    name,
		    (type[0]) ? "." : "",
		    (type[0]) ? type : "");
  }
  else {
    (void) sprintf (boundversion, "%s%s%s%s%s[%d.%d]",
		    (path[0]) ? path : "",
		    (path[0]) ? "/" : "",
		    name,
		    (type[0]) ? "." : "",
		    (type[0]) ? type : "",
		    gen, rev);
  }

  return boundversion;
}

static char at_filename[MAXNAMLEN+1];

char *at_getfilename (attr)
     Af_attrs *attr;     
{
  (void) sprintf (at_filename, "%s%s%s", attr->af_name,
		  attr->af_type[0] ? "." : "",
		  attr->af_type[0] ? attr->af_type : "" );
  
  return at_filename;
}
    
char *at_getdate (attr)
     Af_attrs *attr;
{
  time_t date;
  char *tmp_time;
  extern char *ctime();

  date = (attr->af_state == AF_BUSY ? attr->af_mtime : attr->af_stime);
  tmp_time = ctime(&date);

  /* Format is "Sun Sep 16 01:03:52 1973\n\0" */
  tmp_time = tmp_time + 4;
  tmp_time[20] = '\0';
  return tmp_time;
}

static char at_userandhost[20];

char *at_getuser(user) 
     Af_user *user;
{
  char tmp[20];
  
  tmp[0] = '\0';
  (void) strncat (tmp, user->af_username, 8);
  (void) strcat (tmp, "@");
  (void) strncat (tmp, user->af_userhost, 8);
  (void) sprintf (at_userandhost, "%-16s", tmp);
  return at_userandhost;
}

int at_matchuda (attrbuf, uda)
     Af_attrs *attrbuf;
     char *uda;
{
  /* Returns 1 if attrbuf has an uda uda, otherwise 0. */

  char *v, *cp;
  char **udattrs = attrbuf->af_udattrs;
  int ul, vl = 0;

  if (!uda) return 0;

  if (v = index(uda, '='))
    vl = strlen(++v);
    
  ul = strlen(uda) - vl - 1;

  while (udattrs && *udattrs)
    if (!strncmp(uda, *udattrs, ul)) {
      cp = (*udattrs)+ul;
      if (*cp == '\0' && !v) return 1;
      if (*cp == '=' && !v)
	return 1;
      else cp++;
      
      while (cp) {
	if (*cp == '\n')
	  cp++;
	if (!strncmp(cp, v, vl))
	  return 1;
	else
	  if (cp = index(cp , '\n'))
	    cp++;
	  else
	    return 0;
      }
    }
    else
      udattrs++;

  return 0;
}
