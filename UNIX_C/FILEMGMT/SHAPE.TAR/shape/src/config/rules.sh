#% RULE-SECTION

test:
	version.c, attrge (state, saved), attrmax (version);
	*, attr (state, busy);
	*, attrge (state, saved), attrmax (version), \
	msg (used archived version of $+.).

vsave:
	*, attrmax (version);
	*.a, attr (state, busy).

rel:
	$(AFSINC)/*, attr (state, busy);
	*.a, attr (state, busy);
	*, attrge (state, published), attrmax (version).

#% END-RULE-SECTION

#% VARIANT-SECTION

vclass system ::= (bsd_4_3, sunos_3_4, sunos_4_0, ultrix_2_0)
vclass quality ::= (test, test_profiling, trace, final)
vclass compiler ::= (gnu, pcc)

bsd_4_3:
	SWITCHES = -I$(AFSINC) -DBSD_4_3 -DBSD43
	CFLAGS = $(SWITCHES)

sunos_3_4:
	CLIBS = -ldbm
	SWITCHES = -I$(AFSINC) -DSUNOS_3_4 -DOLDDBM
	CFLAGS = $(SWITCHES)

sunos_4_0:
	SWITCHES = -I$(AFSINC) -DSUNOS_4_0 -DSYSLOG
	CFLAGS = $(SWITCHES)

ultrix_2_0:
	CLIBS = -ldbm
	SWITCHES = -I$(AFSINC) -DULTRIX_2_0 -DOLDDBM
	CFLAGS = $(SWITCHES)

debug:
	CFLAGS = -g
	LDFLAGS = -g

test_profiling:
	OPT = -pg -g
	CFLAGS = $(OPT)
	LDFLAGS = $(OPT)

trace:
	OPT = -g
	SWITCHES = -DMEMDEBUG  -DTMPDEBUG  -DHASHDEBUG
	CFLAGS = $(OPT) $(SWITCHES)

final:
	OPT = -g
	CFLAGS = $(OPT)
	LDFLAGS = -s

gnu:
	CC = gcc -DCFFLGS='"$(CFLAGS) $(vflags)"'
	CFLAGS = -O -g -finline-functions -fkeep-inline-functions \
	-fcombine-regs

pcc:
	CC = cc -DCFFLGS='"$(CFLAGS) $(vflags)"'

#% END-VARIANT-SECTION
