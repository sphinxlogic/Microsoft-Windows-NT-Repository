/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
static char *AFSid = "$Header: ParseArgs.c[2.1] Thu Feb 23 21:24:12 1989 axel@coma published $";

/*
 * Log for /u/shape/dist-tape/src/misc/ParseArgs.c[1.1]
 * 	Thu Feb 23 21:24:12 1989 axel@coma save $
 *  --- empty log message ---
 *  ParseArgs.c[2.0] Thu Feb 23 21:24:12 1989 axel@coma published $
 *  --- empty log message ---
 *  ParseArgs.c[2.1] Thu Feb 23 21:24:12 1989 axel@coma published $
 *  --- empty log message ---
 */

#include <stdio.h>
#include <strings.h>

#include "ParseArgs.h"

static char *RCSid = "$Header: ParseArgs.c,v 2.0 88/06/29 16:14:32 axel Stable $";
#ifdef CFFLGS
static char *Cflags = CFFLGS;
#endif CFFLGS

/*
 * $Log:	ParseArgs.c,v $
 * Revision 2.0  88/06/29  16:14:32  axel
 * New System Generation
 * 
 * Revision 1.1  88/06/07  17:10:01  axel
 * This version is part of a release
 * 
 * Revision 1.8  88/03/12  20:34:34  uli
 * *** empty log message ***
 * 
 * Revision 1.7  88/03/10  14:06:47  uli
 * ParseArgs returns now the number of error encountered during parse.
 * A return value of 0 means no error. This is incompatible to the previous
 * versions. Is this a so called "variant" ? Should i release the previous
 * version ?
 * 						Uli
 * 
 * Revision 1.6  88/03/08  20:48:53  uli
 * blabla.
 * 
 * Revision 1.5  88/03/08  20:03:01  uli
 * pa_ShortUsage added. If called, builds a usage.
 * 
 * Revision 1.4  88/03/08  15:34:58  uli
 * Order of options is no longer important. Options are rearrange in
 * longest first order.
 * 
 * Revision 1.3  88/03/04  15:36:23  uli
 * Some bugs fixed.
 * 
 * 
 * Revision 1.2  88/02/23  13:53:34  uli
 * Error in ParseArguments fixed: newav is now (unsigned long*).
 * 
 * Revision 1.1  88/02/23  12:42:27  uli
 * Initial revision
 * 
 * Revision 1.2  88/02/18  14:33:52  uli
 * *** empty log message ***
 * 
 */

/*
 * Exports:
 *
 * Type: OptDesc;
 * Function: ParseArgs (ac, av, newac, newav, optdesc)
 * 	          int ac;
 *                char **av;
 *                int newac;
 *                char **newav;
 *                OptDesc *optdesc;
 *
 *           ParseArgs returns 1 on success, 0 on failure.
 *
 */

/*
 * Description:
 * 
 * ParseArgs scans and tokenizes the argument string in its components.
 * Components are the name of the called program, the options, the
 * arguments of options, and the pure arguments (i.e.  non options).
 *
 * An Option is specified by its name, kind, and a function, that
 * handles this option. Name is a (possible multi character) string.
 * The kind specifies iff the option is an ordinary switch,
 * an options with an optional argument,  * or an option that
 * requires an argument. The function is called whenever the options
 * is detected in the argument string. The number of the function
 * parameters depends on the options' kind. The detected option
 * is passed everytime as the first parameter. If this option
 * has a (possible optional) argument, it is passed to the handler as the
 * second parameter. If the argument is missed in the argument string,
 * then a string which contains only a null byte is passed to the handler.
 *
 * Example:
 *
 * OptDesc odesc[] = {
 *	{ "l", OPT_IS_SWITCH, handle_i_option },
 *	{ "f", OPT_HAS_ARG, handle_f_options },
 *      { "o", OPT_HAS_OPT_ARG, handle_o_option}
 * }
 *
 * In this example we have declared 'l', 'f', and 'o' to be options.
 * 'l' is a ordinary switch, 'f' requires an argument, and 'o' may
 * have an argument. Handle_i_options, handle_f_option, and
 * and handle_o_option are the option handlers called. The handler
 * are declared:
 *
 *	int handle_i_option (option)
 *		char *option;
 *
 *      int handle_f_option (option, options_argument);
 *		char *option, *options_argument;
 *
 *	int handle_o_option (option, options_argument);
 *		char *option, *options_argument;
 *
 * Everytime '-i' is detected, handle_i_option is called
 *		handle_i_option ("i");
 * handle_f_option is called
 *		handle_f_option ("f", argument);
 * and handle_o_option is called
 *		handle_o_option ("o", argument);
 *
 * If the argument of the options 'f' or 'o' are missed,
 * the handler are called with
 *		handler ("<options name>", "");
 *
 *
 * BUGS:
 *	The longest options is matched. If you have declared
 *	'o' as an options with an argument and 'op' as a
 *      switch, the option 'o' is never detected, because
 *      'op' is longer.
 */
  
/*
 * Externals
 */
extern char *malloc();

#define MINUS_CHAR_REQUIRED 1

/*
 * Variables
 */

#ifdef DEBUG_PARSE
static int debug_parse = 0;
#endif DEBUG_PARSE

static
int GetNextOption (str, odesc, minus_char_required)
     char *str;
     OptDesc odesc[];
     int minus_char_required;
{
  int i, j;

  if (!str) return -1;

  if (minus_char_required) {
    if (*str != '-')
      return -1;
  }
  
  if (*str == '-') {
    str++;
  }
  
  for (i = 0; odesc[i].opt_name; i++) {
    if (!(j = strncmp (odesc[i].opt_name,
		       str, strlen (odesc[i].opt_name))))
      return i;
  }
  return -1;
}


static
int IsOption (str, odesc, minus_char_required)
     char *str;
     OptDesc odesc[];
     int minus_char_required;
{
  return (GetNextOption (str, odesc, minus_char_required) >= 0 ? 1 : 0);
}

static
char *SkipThisOption (str, length)
     char *str;
     int length;
{
  if (*str == '-') str++;
  return (str + length);
}

static
int cmp_length (left, right)
     OptDesc *left, *right;
{
  return (strlen (right->opt_name) - strlen (left->opt_name));
}

static
int cmp_alpha (left, right)
     OptDesc *left, *right;
{
  return (strcmp (left->opt_name, right->opt_name));
}

static
int RearrangeOptDesc (odesc, cmp_function)
     OptDesc *odesc;
     int (*cmp_function)();	/* function that compares */
{
  int nelem;

  for (nelem = 0; odesc[nelem].opt_name; nelem++) ;
  
  qsort (odesc, nelem, sizeof (struct optdesc), cmp_function);
}

int ParseArgs (pac, pav, newac, newav, odesc)
     int pac;			/* number arguments */
     char **pav;		/* the arguments itself */
     int *newac;		/* number arguments after parsing */
     unsigned long *newav;	/* the arguments after parsing */
     OptDesc odesc[];		/* the options descriptions */
{

  char **cpp;			/* temporary points to pav */
  char **ArgV;
  char *this_arg;		/* points to the current argument */
  int option, minus_char_required, opterr = 0;
  char *optrepr;
  int optkind;
  int (*opthandler)();
    
  /*
   * inititialization phase
   */
  *newac = 0;

  /* allocate some memory for newav */
  if ((ArgV = (char **) malloc (sizeof (char **) * (pac + 1))) == (char **) NULL) {
    perror ("malloc");
    exit (1);
  }

  RearrangeOptDesc (odesc, cmp_length);	/* sort by length */
  
#ifdef DEBUG_PARSE
  if (!strcmp (pav[1], "\001\002")) { /* ^A^B */
    debug_parse++; 
    fprintf (stderr, "ParseArgs: debugging enabled.\n");
  }
#endif DEBUG_PARSE

  /*
   * scanning phase
   */
  pav++;		/* skip program name */

#ifdef DEBUG_PARSE
  if (debug_parse) pav++;
#endif DEBUG_PARSE
  
  while (pav && *pav) {
    this_arg = *pav;		/* beginning of next argument */
    minus_char_required = 1;	/* require a '-' if argument is a option */
    
    while (this_arg && *this_arg) {
      if ((option = GetNextOption (this_arg, odesc, minus_char_required)) >= 0) {
	optrepr = odesc[option].opt_name; /* option's name */
	optkind = odesc[option].opt_kind; /* option's kind */
	opthandler = odesc[option].opt_handler;	/* option's handler */
	
	this_arg = SkipThisOption (this_arg, strlen (optrepr));
	minus_char_required = 0; /* -fe  f AND e are options */
	
	switch (optkind) {
	case OPT_IS_SWITCH:
	  opterr += opthandler (optrepr);
	  break;
	case OPT_HAS_OPT_ARG:
	  /*
	   * at this point, this_arg points to the next char after
	   * the detected option or this_arg has reached the end.
	   */
	  if (!*this_arg) { /* *this_arg == '\0' */
	    if (*++pav) { /* next arg exists */
	      this_arg = *pav;
	      if (IsOption (this_arg, odesc, MINUS_CHAR_REQUIRED)) { /* always '-' required */
		opterr += opthandler (optrepr, "");
		this_arg = NULL;
		pav--;
	      }
	      else {
		opterr += opthandler (optrepr, this_arg);
		this_arg = NULL;
	      }
	    }
	    else { /* end of pav reached */
	      opterr += opthandler (optrepr, "");
	      this_arg = NULL;
	      pav--;
	    }
	  }
	  else {
	    if (! IsOption (this_arg, odesc, (! MINUS_CHAR_REQUIRED))) { /* rest of this_arg contains arg */
	      opterr += opthandler (optrepr, this_arg);
	      this_arg = NULL;
	    }
	    else {
	      opterr += opthandler (optrepr, "");
	    }
	  }
	  break;
	case OPT_HAS_ARG:
	  if (!*this_arg) { /* end of this arg reached */
	    pav++;
	    this_arg = *pav;
	    if (!this_arg) { /* end of pav reached */
	      opterr += opthandler (optrepr, "");
	      this_arg = NULL;
	      pav--;
	    }
	    else {
	      opterr += opthandler (optrepr, this_arg);
	      this_arg = NULL;
	    }
	  }
	  else {
	    opterr += opthandler (optrepr, this_arg);
	    this_arg = NULL;
	  }
	  break;
	default:
	  fprintf (stderr, "ParseOpt: Non option detected as option: %s.\n",
		   odesc[option].opt_name);
	  exit (1);
	  break;
	} /* end switch */
      } /* end then */
      else {			/* argument is not a options */
	ArgV[*newac] = this_arg;
	(*newac)++;
	this_arg = NULL;
      }
    }
    pav++;			/* select next argument */
  }
    
  /* finalization phase  */
  ArgV[*newac] = (char *) NULL;

#ifdef DEBUG_PARSE
  if (debug_parse) {
    int j;
    fprintf (stderr, "ParseArgs: Pure Arguments are:\nParseArgs:\t");

    if (!*ArgV) fprintf (stderr, "<none>\n");
    else {
      for (j = 0; ArgV[j]; j++) {
	fprintf (stderr, "%s ", ArgV[j]);
      }
      fprintf (stderr, "\n");
    }
    debug_parse = 0;
    fprintf (stderr, "ParseArgs: Debugging disabled.\n");
  }
#endif DEBUG_PARSE

  *newav = (unsigned long) ArgV;
  return opterr;		/* return # of errors. 0 means no error */
}

pa_ShortUsage (progname, odesc, extra_text)
     char *progname;
     struct optdesc odesc[];
     char *extra_text;
{
  int i;
  int twidth = 80;
  int c_printed = 6;
  int length = 0;
  int nextlineoff;
  char buf[80];
  
  RearrangeOptDesc (odesc, cmp_alpha);

#define GetTerminalWidth(x) 80
  twidth = GetTerminalWidth();
  
  fprintf (stderr, "usage:");
  
  if (progname && *progname) {
    fprintf (stderr, " %s:", progname);
    c_printed += strlen (progname) + 2;
  }

  nextlineoff = c_printed + 3;
  
  /* first switches than option requiring an agrument */
  fprintf (stderr, " [-");
  c_printed += 3;
  
  for (i = 0; odesc[i].opt_name; i++) {
    if (odesc[i].opt_kind == OPT_IS_SWITCH) {
      length = strlen (odesc[i].opt_name); length++;
      if (c_printed + length > twidth) {
	c_printed = length + nextlineoff;
	sprintf (buf, "\n%%%dc", nextlineoff);
	fprintf (stderr, buf, ' ');
      }
      else {
	c_printed += length;
      }
      
      fprintf (stderr, " %s", odesc[i].opt_name);
    }
  }

  fprintf (stderr, "]"); c_printed++;
  nextlineoff -= 3;
  
  for (i = 0; odesc[i].opt_name; i++) {
    length = strlen (odesc[i].opt_name);
    
    switch (odesc[i].opt_kind) {
    case OPT_IS_SWITCH:
        break;
    case OPT_HAS_OPT_ARG:
	if ((c_printed + 14 + length) > 80) {
	  c_printed = length + nextlineoff + 14;
	  sprintf (buf, "\n%%%dc", nextlineoff);
	  fprintf (stderr, buf, ' ');
	}
	else {
	  c_printed += length + 14;
	}
	    
	fprintf (stderr, " [-%s <opt arg>]", odesc[i].opt_name);
      break;
    case OPT_HAS_ARG:
	if ((c_printed + 10 + length) > 80) {
	  c_printed = length + nextlineoff + 10;
	  sprintf (buf, "\n%%%dc", nextlineoff);
	  fprintf (stderr, buf, ' ');
	}
	else {
	  c_printed += length + 10;
	}
	    
      fprintf (stderr, " [-%s <arg>]", odesc[i].opt_name);
      break;
    default:
      break;
    }
  }

  if ((strlen (extra_text) + c_printed + 1) > twidth) {
    sprintf (buf, "\n%%%dc", nextlineoff);
    fprintf (stderr, buf, ' ');
  }
  
  fprintf (stderr, " %s\n", extra_text);
}
