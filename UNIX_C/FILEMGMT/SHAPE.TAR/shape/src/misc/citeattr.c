/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
static char *AFSid = "$Header: citeattr.c[1.6] Thu Feb 23 21:24:18 1989 axel@coma published $";

/*
 * Log for /u/shape/dist-tape/src/misc/citeattr.c[1.1]
 * 	Thu Feb 23 21:24:18 1989 axel@coma save $
 *  --- empty log message ---
 *  citeattr.c[1.2] Thu Feb 23 21:24:18 1989 axel@coma save $
 *  --- empty log message ---
 *  citeattr.c[1.3] Thu Feb 23 21:24:18 1989 axel@coma save $
 *  --- empty log message ---
 *  citeattr.c[1.4] Thu Feb 23 21:24:18 1989 axel@coma published $
 *  Threw out silly #ifdef BSD43 s.
 *  I think there are also other changes concerning attribute citations.
 *  
 *  citeattr.c[1.5] Thu Feb 23 21:24:18 1989 axel@coma published $
 *  --- empty log message ---
 *  citeattr.c[1.6] Thu Feb 23 21:24:18 1989 axel@coma published $
 *  --- empty log message ---
 */

#include <pwd.h>
#include <grp.h>
#include <stdio.h>
#include <strings.h>
#include "afs.h"
#include "afsapp.h"
#include "anames.h"

char *st_table[] = {
  "busy", "save", "proposed", 
  "published", "accessed", "frozen", 
  (char *)0 
  };

WriteXPand (buf, bufcnt, dest, curkey) 
     char *buf; int bufcnt; FILE *dest; Af_key *curkey; {
/*
 *  WriteXPand scans the char buffer 'buf' to the extent of bufcnt
 *  for strings of the form '$__attribute_name'. If such a string
 *  is found, the buffer contents up to the character preceding the
 *  first '$' will be sent to the destination output 'dest'.
 *  If an attribute with name 'atttribute_name' is set for the current
 *  attribute file, the citation-string will be substituted by the value
 *  of that attribute. Output of 'buf' contents resumes with the first 
 *  character after the blank delimiting the 'attribute_name'.
 *  There are two built-in pseudo-attributes, 'Header' and 'Log' which
 *  are substituted by a version header in RCS style or a log-history
 *  respectively. Lines of the log-history are preceded by a 'comment
 *  leader' symbol, defined as user-defined attribute CLEAD.
 *  Header and Log are ended by newline characters.
 */
       short stat=0, incite=0, gotattrs=0;
       char attrcitebuf[128];
       Af_attrs allattrs;
       register int i, j, k;
       char *bufp = buf, *attrname = attrcitebuf+3,
       *spt, *ept;

       i = 0;

       spt = ept = buf;

       while (i < bufcnt) {

	 switch (buf[i]) {
	 /* scan attribute citation marker */
	 case '$':
	   if (stat) ept = &(buf[i]);
	   stat = 1;
	   attrcitebuf[0] = '$';
	   break;
	 case '_':
	   switch (stat) {
	   case 0:
	     ept++;
	     break;
	   case 1: 
	   case 2:
	     attrcitebuf[stat++] = '_';
	     break;
	   }
	   break;
	 default:
	   if (stat) 
	     ept = &(buf[i+1]);
	   else 
	     ept++;
	   stat = 0;
	   break;
	 }

	 if (stat == 3) { /* lets see if there's an attribute citation */
	   /* assertion: i is index of 2nd '_' */
	   if ((i < bufcnt-1) && (buf[i+1] != ' ')) { 
	     stat = 0; 
	     /* ... yes, there seems to be one */
	     i++; incite = 0;
	     if (af_gattrs (curkey, &allattrs) < 0) {
	       af_perror ("af_gattrs");
	       return;
	     }
	     gotattrs = 1;
	     while ((!index (" \n\t$", buf[i])) && (i < bufcnt))
	       attrname[incite++] = buf[i++];
	     if (i < bufcnt) {
	       /* i points to first char after attribute name */
	       if (buf[i] == '$') { /* consider '$' part of attr-name */
		 attrname[incite++] = '$'; i++;
	       }
	       attrname[incite] = '\0';
	       /* write out everything up to beginning of cite_mark */
	       fwrite (spt, sizeof (*buf), ept - spt, dest);
	       spt = ept = &(buf[i]);
	       if (!substitute (attrname, curkey, &allattrs, dest))
		 fputs (attrcitebuf, dest);
	       incite = 0;
	     }
	     else {
	       attrname[incite] = '\0';
	       fwrite (spt, sizeof (*buf), ept - spt, dest);
	       spt = ept = &(buf[i]);
	       if (!substitute (attrname, curkey, &allattrs, dest))
		 fputs (attrcitebuf, dest);
	     }
	   }
	   else { /* blank after citemark or buffer exceeded */
	     fputs ("$__", dest);
	   }
	   i--;
	 }
	 i++;
       }
       /* Ok, we've had it -- send remaining chars to dest */
       fwrite (spt, sizeof (*buf), ept - spt, dest);
       if (gotattrs) {
	 i = 0;
	 while (allattrs.af_udattrs[i]) free (allattrs.af_udattrs[i++]);
       }
     }


static substitute (attrname, afkey, afattrs, dest) 
     char *attrname; Af_key *afkey; Af_attrs *afattrs; FILE *dest; {
       /* 
	* This procedure tries to substitute the occurrence of the 
	* given attribute name by the corresponding value stored with the 
	* attribute file version denoted by afkey. The substituted 
	* value is printed on dest. If 'attrname' actually is the name
	* of an attribute and the last character in the name is '$'
	* it will be deleted. In case that attrname is not a known
	* attributename, nothing happens and a value of 0, indicating
	* that no substitution took place, will be returned. Nonzero
	* return means successful substitution.
	*/
       char *ap, *p, clead[32], *note, *IsAStdAttr();
       register char *lp, *ep, *l;
       Af_attrs retbuf;
       Af_set kset;
       Af_key thiskey;
       int cgen, crev, tgen, setsz, title_printed = FALSE;
       register int k;

       if (l = index (attrname, '$')) *l = '\0';
       if (ap = IsAStdAttr (attrname, afattrs)) {
	 fputs (ap, dest);
	 return TRUE;
       }
       if (strcmp (attrname, HEADER)) {
	 if (strcmp (attrname, LOG)) {
	   ap = af_rudattr (afkey, attrname);
	   if (ap > 0) {
	     fputs (ap, dest);
	     free (ap);
	     return TRUE;
	   }
	   if (l) *l = '$'; /* restore '$' if 'attrname' unknown */
	   return FALSE;
	 }
	 else { /* fill in the logs */
	   /* we've got to find all preceding versions */
	   
	   af_initattrs (&retbuf);    
	   strcpy (retbuf.af_syspath, p=af_rsyspath (afkey));
	   free (p);
	   strcpy (retbuf.af_name, p=af_rname (afkey));
	   free (p);
	   strcpy (retbuf.af_type, p=af_rtype (afkey));
	   free (p);
	   af_find (&retbuf, &kset);
	   af_sortset (&kset, AF_ATTVERSION);
	   cgen = af_rgen (afkey);
	   crev = af_rrev (afkey);
	   setsz = af_nrofkeys (&kset);
	   
	   /* determine comment leader sym to prepend it to loglines */
	   p = af_rudattr (afkey, CLEAD);
	   if (p) {
	     strcpy (clead, p);
	   }
	   else clead[0] = '\0';
	   free (p);
	   
	   /* write log for each version up to current on dest file */
	   for (k = 0 ; k < setsz; k++) {
	     af_setgkey (&kset, k, &thiskey);
	     if (af_rstate (&thiskey) == AF_BUSY)
	       continue; /* don't consider busy version */
	     if ((tgen = af_rgen (&thiskey)) > cgen)
	       break;
	     if ((tgen == cgen) && (af_rrev(&thiskey) > crev))
	       break;
	     if (!title_printed) {
	       fprintf (dest, "Log for ");
	       putlongheader (&thiskey, dest, clead);
	       title_printed = TRUE;
	     }
	     else {    /* each log preceded by version header */
	       fprintf (dest, "%s%s", (clead && clead[0]) ? clead : "",
			(clead && clead[0]) ? " " : "");
	       putshortheader (&thiskey, dest, TRUE);

	     }
	     note = af_rnote (&thiskey);
	     lp = note; 
	     /* break log text into separate strings */
	     /* assertion: lp == 0 if no log or log is printed */
	     while (lp) {
	       ep = lp;
	       while ((*ep != '\n') && (*ep != '\0'))
		 ep++;
	       if (*ep == '\n') {
		 *ep++ = '\0'; /* make it end of an ordinary string */
		 fprintf (dest, "%s %s\n", clead, lp);
		 /* ...and let it point to next string segment */
	       }
	       else {
		 ep = NULL; /* we're ready */
		 if (k < setsz-1) /* handle 'last-newline' problem */
		   fprintf (dest, "%s %s\n", clead, lp);
		 else
		   fprintf (dest, "%s %s", clead, lp);
	       }
	       lp = ep;
	     }
	     free (note);
	     /* aw rite --- lets go for the next log entry */
	   }
	   af_dropset (&kset);
	 }
       }
       else { /* print standard version header -- do it RCS-style */
	 fprintf (dest, "%cHeader: ", '$');
	 putshortheader (afkey, dest, FALSE);
       }
       return TRUE;
     }

static char *vnum (key) Af_key *key; {
  int _gen, _rev;
  static char vstr[20];

  _gen = af_rgen (key);
  _rev = af_rrev (key);
  
  if (af_rstate (key) == AF_BUSY)
    strcpy (vstr, "busy");
  else
    sprintf (vstr, "%d.%d", _gen, _rev);
  return vstr;
}


static putlongheader (afkey, dest, clead) 
     Af_key *afkey; FILE *dest; char *clead; {
  char *spath, *name, *type, *systime(), *UidString(), *csym;
  extern char *st_table[];
  register int i;
  Af_attrs allattrs;

  spath = af_rsyspath (afkey);
  name = af_rname  (afkey);
  type = af_rtype (afkey);
  af_gattrs (afkey, &allattrs);
  csym = (clead && clead[0]) ? clead : "";
  for (i = 0; allattrs.af_udattrs[i]; i++) free (allattrs.af_udattrs[i]);

  fprintf (dest, "%s/%s%s%s[%s]\n%s\t%s %s %s $\n", spath, name, 
	   type[0] ? "." : "", type, vnum(afkey), csym,
	   systime(), UidString (&(allattrs.af_author)),
	   st_table[af_rstate(afkey)]);
  free (spath); free (name); free (type);
}

static putshortheader (afkey, dest, nl) 
     Af_key *afkey; FILE *dest; int nl; {
  char *spath, *name, *type, *systime(), *UidString();
  extern char *st_table[];
  register int i;
  Af_attrs allattrs;

  spath = af_rsyspath (afkey);
  name = af_rname  (afkey);
  type = af_rtype (afkey);
  af_gattrs (afkey, &allattrs);
  for (i = 0; allattrs.af_udattrs[i]; i++) free (allattrs.af_udattrs[i]);

  fprintf (dest, "%s%s%s[%s] %s %s %s $%s", name, 
	   type[0] ? "." : "",type, vnum(afkey),
	   systime(), UidString (&(allattrs.af_author)),
	   st_table[af_rstate(afkey)], nl ? "\n" : "");
  free (spath); free (name); free (type);
}

static struct {
  char *name;
  short code;
} an_tab[] = {
  { "atime", ATIME },  /* 0 */
  { "auuid", AUUID },
  { "ctime", CTIME },
  { "generation", GEN },
  { "host", HOST },
  { "lock",  LOCK },
  { "ltime", LTIME },
  { "mode", MODE },
  { "mtime", MTIME },
  { "name",  NAME },
  { "ownuid", OWNUID },
  { "revision", REV },
  { "size", SIZE },
  { "stime", STIME },
  { "syspath", SYSPATH },
  { "type", TYPE },
  { "variant", VAR },
  { "version", VERSION },
  { "state", STATE }       /* 18 */
};

static char *IsAStdAttr (attrname, afattrs) 
     char *attrname; Af_attrs *afattrs; {
  extern char *st_table[];
  char messg[80], *UidString();
  static char rets[32];
  register int i;
  int anc = 0;

  for (i = 0; i < AN_TABSIZ; i++) {
    if (!(strcmp (attrname, an_tab[i].name))) {
      anc = an_tab[i].code;
      break;
    }
  }
  if (anc) {
    switch (anc) {
    case HOST:
      return afattrs->af_host;
      break;
    case SYSPATH:
      return afattrs->af_syspath;
      break;
    case NAME:
      return afattrs->af_name;
      break;
    case TYPE:
      return afattrs->af_type;
      break;
    case GEN:
      if (afattrs->af_state == AF_BUSY) return "nogen";
      else {
	sprintf (rets, "%d", afattrs->af_gen);
	return rets;
      }
      break;
    case REV:
      if (afattrs->af_state == AF_BUSY) return "nogen";
      else {
	sprintf (rets, "%d", afattrs->af_rev);
	return rets;
      }
      break;
    case VERSION:
      if (afattrs->af_state == AF_BUSY) return "busy";
      else {
	sprintf (rets, "%d.%d", afattrs->af_gen, afattrs->af_rev);
	return rets;
      }
      break;
    case VAR:
      return (afattrs->af_variant);
      break;
    case STATE:
      return st_table[afattrs->af_state];
      break;
    case OWNUID:
      return UidString (&(afattrs->af_owner));
      break;
    case AUUID:
      return UidString (&(afattrs->af_author));
      break;
    case SIZE:
      sprintf (rets, "%d", afattrs->af_size);
      return rets;
      break;
    case MODE:
      sprintf (rets, "%o", afattrs->af_mode);
      return rets;
      break;
    case LOCK:
      if (strcmp (afattrs->af_locker.af_username, "")) {
	sprintf (rets, "%s@%s", afattrs->af_locker.af_username, 
		 afattrs->af_locker.af_userhost);
	return rets;
      }
      return "nobody";
      break;
    case MTIME:
      strcpy (rets, asctime(localtime(&afattrs->af_mtime)));
      rets[strlen(rets) - 1] = '\0';
      return rets;
      break;
    case ATIME:
      strcpy (rets, asctime(localtime(&afattrs->af_atime)));
      rets[strlen(rets) - 1] = '\0';
      return rets;
      break;
    case CTIME:
      strcpy (rets, asctime(localtime(&afattrs->af_ctime)));
      rets[strlen(rets) - 1] = '\0';
      return rets;
      break;
    case STIME:
      if (afattrs->af_state == AF_BUSY) return "no_date";
      else {
	strcpy (rets, asctime(localtime(&afattrs->af_stime)));
	rets[strlen(rets) - 1] = '\0';
	return rets;
      }
      break;
      case LTIME:
      strcpy (rets, asctime(localtime(&afattrs->af_ltime)));
      rets[strlen(rets) - 1] = '\0';
      return rets;
      break;
    default: /* shouldn't happen ! */
      sprintf (messg, "illegal standard attribute code %d.", anc);
      logerr (anc);
    }
  }
  else return NULL; /* no standard attribute */
}

char *UidString (user) Af_user *user; {
  static char rst[256];

  rst[0] = '\0';
  if (user) {
    sprintf (rst, "%s@%s", user->af_username, user->af_userhost);
  }
  return rst;
}

static char *systime () {
  char *asctime();  
  register char *ts;
  struct timeval tm;
  struct timezone tz;

  gettimeofday (&tm, &tz);
  ts = asctime (localtime (&tm));
  ts[strlen(ts)-1] = '\0';
  return ts;
}
