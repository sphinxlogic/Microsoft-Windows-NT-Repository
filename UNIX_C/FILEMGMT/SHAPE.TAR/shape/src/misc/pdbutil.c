
/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
static char *AFSid = "$Header: pdbutil.c[2.2] Thu Feb 23 21:24:23 1989 axel@coma published $";

/*
 * Log for /u/shape/dist-tape/src/misc/pdbutil.c[1.1]
 * 	Thu Feb 23 21:24:23 1989 axel@coma save $
 *  --- empty log message ---
 *  pdbutil.c[2.0] Thu Feb 23 21:24:23 1989 axel@coma published $
 *  --- empty log message ---
 *  pdbutil.c[2.1] Thu Feb 23 21:24:23 1989 axel@coma published $
 *  --- empty log message ---
 *  pdbutil.c[2.2] Thu Feb 23 21:24:23 1989 axel@coma published $
 *  --- empty log message ---
 */

#ifdef CFFLGS
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	pdbutil.c,v $
 * Revision 2.0  88/06/29  16:14:41  axel
 * New System Generation
 * 
 * Revision 1.1  88/06/07  17:10:04  axel
 * This version is part of a release
 * 
 * Revision 2.0  88/05/26  00:50:51  axel
 * This version is part of the first working configuration of the
 * project description database compiler.
 * 
 */

#include <stdio.h>
char *zeroit (c, l) char *c; { 
  /* only because bzero's no function, damn! */
  bzero (c, l);
  return c;
}
