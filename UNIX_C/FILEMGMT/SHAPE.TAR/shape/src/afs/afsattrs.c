/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*LINTLIBRARY*/
/*
 *	Shape/AFS
 *
 *	afsattrs.c - reading and writing simple attributes
 *
 *	Author: Andreas Lampen, TU-Berlin (andy@coma.UUCP
 *					   andy@db0tui62.BITNET)
 *
 *	$Header: afsattrs.c[1.5] Wed Feb 22 16:27:54 1989 andy@coma published $
 *
 *	EXPORT:
 *	af_rname -- get name
 *	af_rtype -- get type
 *	af_rsyspath -- get system pathname
 *	af_rgen -- return generation number
 *	af_rrev -- return revision number
 *      af_rowner -- return owner
 *      af_chowner -- change owner
 *      af_rauthor -- return author
 *      af_chauthor -- return author
 *	af_chmod -- change mode
 *	af_gattrs -- get attribute buffer
 *
 *      OBSOLETE:
 *	af_rouid -- return user id of owner
 *	af_rogid -- return group id of owner
 *	af_chown -- change uid and gid of owner
 *	af_rauid -- return user id of author
 *	af_ragid -- return group id of author
 *	af_chaut -- change uid and gid of author
 */

#include <stdio.h>
#include <string.h>
#ifdef SUNOS_4_0
#include <strings.h>
#endif

#include "typeconv.h"
#include "afsys.h"
#include "afs.h"

char *malloc();

/*====================================================================
 *    af_rname -- return name
 *
 *====================================================================*/

EXPORT char *af_rname (key)
     Af_key *key;
{
  char *name;

  if (af_keytest (key))
    SFAIL ("rname", "", AF_EINVKEY, (char *)0);

  if ((name = malloc ((unsigned) (strlen (VATTR(key).af_name) + sizeof (char)))) == (char *)0)
    FAIL ("rname", "malloc", AF_ESYSERR, (char *)0);
  (void) strcpy (name, VATTR(key).af_name);
  return (name);
}


/*====================================================================
 *    af_rtype -- return type
 *
 *====================================================================*/

EXPORT char *af_rtype (key)
     Af_key *key;
{
  char *type;

  if (af_keytest (key))
    SFAIL ("rtype", "", AF_EINVKEY, (char *)0);
  if (!VATTR(key).af_type)
    return ((char *)0);

  if ((type = malloc ((unsigned) (strlen (VATTR(key).af_type) + sizeof (char)))) == (char *)0)
    FAIL ("rtype", "malloc", AF_ESYSERR, (char *)0);
  (void) strcpy (type, VATTR(key).af_type);
  return (type);
}


/*====================================================================
 *    af_rsyspath -- return system pathname
 *
 *====================================================================*/

EXPORT char *af_rsyspath (key)
     Af_key *key;
{
  char   *syspath;

  if (af_keytest (key))
    SFAIL ("rsyspath", "", AF_EINVKEY, (char *)0);

  if ((syspath = malloc ((unsigned) (strlen (CATTR(key).af_syspath) + sizeof (char)))) == (char *)0)
    FAIL ("rsyspath", "malloc", AF_ESYSERR, (char *)0);
  (void) strcpy (syspath, CATTR(key).af_syspath);
  return (syspath);
}


/*====================================================================
 *    af_rgen -- return generation number
 *
 *====================================================================*/

EXPORT af_rgen (key)
     Af_key *key;
{
  if (af_keytest (key))
    SFAIL ("rgen", "", AF_EINVKEY, ERROR);
  return (VATTR(key).af_gen);
}


/*====================================================================
 *    af_rrev -- return revision number
 *
 *====================================================================*/

EXPORT af_rrev (key)
     Af_key *key;
{
  if (af_keytest (key))
    SFAIL ("rrev", "", AF_EINVKEY, ERROR);
  return (VATTR(key).af_rev);
}

/*====================================================================
 *      af_rowner -- return owner
 *
 *====================================================================*/

EXPORT Af_user *af_rowner (key)
     Af_key *key;
{
  static Af_user owner;

  if (af_keytest (key))
    SFAIL ("rowner", "", AF_EINVKEY, (Af_user *)0);

  (void) strcpy (owner.af_username, CATTR(key).af_ownname);
  (void) strcpy (owner.af_userhost, CATTR(key).af_ownhost);
  return (&owner);
}

/*====================================================================
 *      af_chowner -- change owner
 *
 *====================================================================*/

EXPORT af_chowner (key, owner)
     /*ARGSUSED*/
     Af_key  *key;
     Af_user *owner;
{
  /* not yet implemented (chowner) */
  SFAIL ("chowner", "", AF_EACCES, ERROR);
}

/*====================================================================
 *      af_rauthor -- return author
 *
 *====================================================================*/

EXPORT Af_user *af_rauthor (key)
     Af_key *key;
{
  static Af_user author;

  if (af_keytest (key))
    SFAIL ("rauthor", "", AF_EINVKEY, (Af_user *)0);

  (void) strcpy (author.af_username, VATTR(key).af_auname);
  (void) strcpy (author.af_userhost, VATTR(key).af_auhost);
  return (&author);
}

/*====================================================================
 *      af_chauthor -- return author
 *
 *====================================================================*/

EXPORT af_chauthor (key, author)
     Af_key  *key;
     Af_user *author;
{
  Uid_t uid;
  Gid_t gid;

  if (af_keytest (key))
    SFAIL ("chauthor", "", AF_EINVKEY, ERROR);
  if (af_checkperm (key, AF_OWNER) == ERROR)
    return (ERROR);

  if (VATTR(key).af_state == AF_BUSY)
    {
      if ((uid = af_getuid (author->af_username, author->af_userhost))
	  == (Uid_t) -1)
	SFAIL ("chauthor", "", AF_EINVUSER, ERROR);
      if ((gid = af_getgid (author->af_username, author->af_userhost))
	  == (Gid_t) -1)
	SFAIL ("chauthor", "", AF_EINVUSER, ERROR);
      if (af_uchown (key->af_ldes->af_busyfilename, (int) uid, (int) gid) == ERROR)
	FAIL ("chauthor", "chown", AF_ESYSERR, ERROR);
    }
  else
    {
      VATTR(key).af_auname = af_entersym (author->af_username);
      VATTR(key).af_auhost = af_enterhost (author->af_userhost);
    }
  if (af_updtvers (key, AF_CHANGE) == ERROR)
    return (ERROR);
  return (AF_OK);
}

/*====================================================================
 *    af_chmod -- change mode
 *
 *====================================================================*/

EXPORT af_chmod (key, mode)
     Af_key *key;
     int    mode;
{
  if (af_keytest (key))
    SFAIL ("chmod", "", AF_EINVKEY, ERROR);

  if (af_checkperm (key, AF_OWNER | AF_AUTHOR) == ERROR)
    return (ERROR);

  if (VATTR(key).af_state == AF_BUSY)
    {
      if (af_uchmod (key->af_ldes->af_busyfilename, mode) == ERROR)
	FAIL ("chmod", "chmod", AF_ESYSERR, ERROR);
    }
  else
    VATTR(key).af_mode = mode;
 
  if (af_updtvers (key, AF_CHANGE) == ERROR)
	return (ERROR);

  return (AF_OK);
}


/*====================================================================
 *    af_gattrs -- get attribute buffer
 *
 *====================================================================*/

EXPORT af_gattrs (key, attrbuf)
     Af_key   *key;
     Af_attrs *attrbuf;
{
  int i=0, size;
  char *udalist[AF_MAXUDAS], *udattrs, *valptr;

  if (af_keytest (key))
    SFAIL ("gattrs", "", AF_EINVKEY, ERROR);

  (void) strcpy (attrbuf->af_host, CATTR(key).af_host);
  (void) strcpy (attrbuf->af_name, VATTR(key).af_name);
  (void) strcpy (attrbuf->af_type, NOTNIL(VATTR(key).af_type));
  (void) strcpy (attrbuf->af_syspath, CATTR(key).af_syspath);

  attrbuf->af_gen = VATTR(key).af_gen;
  attrbuf->af_rev = VATTR(key).af_rev;
  (void) strcpy (attrbuf->af_variant, NOTNIL(VATTR(key).af_variant));
  attrbuf->af_state = (int) VATTR(key).af_state;
  (void) strcpy (attrbuf->af_owner.af_username, CATTR(key).af_ownname);
  (void) strcpy (attrbuf->af_owner.af_userhost, CATTR(key).af_ownhost);
  (void) strcpy (attrbuf->af_author.af_username, VATTR(key).af_auname);
  (void) strcpy (attrbuf->af_author.af_userhost, VATTR(key).af_auhost);
  attrbuf->af_size = VATTR(key).af_fsize;
  attrbuf->af_mode = VATTR(key).af_mode;
  (void) strcpy (attrbuf->af_locker.af_username, NOTNIL(VATTR(key).af_lckname));
  (void) strcpy (attrbuf->af_locker.af_userhost, NOTNIL(VATTR(key).af_lckhost));
  attrbuf->af_mtime = VATTR(key).af_mtime;
  attrbuf->af_atime = VATTR(key).af_atime;
  attrbuf->af_ctime = VATTR(key).af_ctime;
  attrbuf->af_stime = VATTR(key).af_stime;
  attrbuf->af_ltime = VATTR(key).af_ltime;

  /* copy user defined attributes */
  if (VATTR(key).af_udanum > 0)
    {
      size = af_lhashsyms (&(VATTR(key).af_uhtab), udalist);
      if ((udattrs = malloc ((unsigned) size)) == (char *)0)
	FAIL ("gattrs", "malloc", AF_ESYSERR, ERROR);
      while (udalist[i] != (char *)0)
	{
	  (void) strcpy (udattrs, udalist[i]);
	  /* replace delimiters by '\n' */
	  valptr = index (udattrs, AF_UDANAMDEL);
	  while ((valptr = index (valptr, AF_UDAVALDEL)) != (char *)0)
	    valptr[0] = '\n';
	  attrbuf->af_udattrs[i] = udattrs;
	  udattrs = udattrs + (strlen(udalist[i])+1);
	  i++;
	}
      attrbuf->af_udattrs[i] = (char *)0; /* finish list */
    }
  else
    attrbuf->af_udattrs[0] = (char *)0;

  return (AF_OK);
}
