/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*LINTLIBRARY*/
/*
 *	Shape/AFS
 *
 *	afstates.c - operations on version states
 *
 *	Author: Andreas Lampen, TU-Berlin (andy@coma.UUCP
 *					   andy@db0tui62.BITNET)
 *
 *	$Header: afstates.c[1.3] Wed Feb 22 16:28:10 1989 andy@coma published $
 *
 *	EXPORT:
 *	af_rstate -- return version state
 *	af_sstate -- set revision state
 */

#include <stdio.h>

#include "typeconv.h"
#include "afsys.h"
#include "afs.h"

/*====================================================================
 *    af_rstate -- return version state
 *
 *====================================================================*/

EXPORT af_rstate (key)
     Af_key *key;
{
  if (af_keytest (key))
    SFAIL ("rstate", "", AF_EINVKEY, ERROR);
  if (VATTR(key).af_class & AF_DERIVED)
    SFAIL ("rstate", "", AF_EDERIVED, ERROR);

  return ((int) VATTR(key).af_state);
}

/*====================================================================
 *    af_sstate -- set version state
 *
 *====================================================================*/

EXPORT af_sstate (key, state)
     Af_key 	*key;
     int        state;
{
  if (af_keytest (key))
    SFAIL ("sstate", "", AF_EINVKEY, ERROR);
  if (VATTR(key).af_class & AF_DERIVED)
    SFAIL ("sstate", "", AF_EDERIVED, ERROR);

  if (af_checkperm (key, AF_OWNER | AF_AUTHOR | AF_LOCKHOLDER) == ERROR)
    return (ERROR);

  if ((state < AF_SAVED) || (state > AF_FROZEN) ||
      (abs(VATTR(key).af_state - state) == 1))
    {
      VATTR(key).af_state = state;
    }
  else
    SFAIL ("sstate", "", AF_ESTATE, ERROR);
  /* save changes */
  if (af_updtvers (key, AF_CHANGE) == ERROR)
    return (ERROR);
  
  return (AF_OK);
} /* af_sstate */
