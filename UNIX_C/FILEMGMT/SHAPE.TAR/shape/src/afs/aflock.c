/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*LINTLIBRARY*/
/*
 *	Shape/AFS
 *
 *	aflock.c -- Version locking
 *
 *	Author: Andreas Lampen, TU-Berlin (andy@coma.UUCP)
 *					  (andy@db0tui62.BITNET)
 *
 *	$Header: aflock.c[1.4] Wed Feb 22 16:27:44 1989 andy@coma published $
 *
 *	EXPORT:
 *	af_lock -- lock busy version
 *	af_unlock -- unlock version
 *	af_testlock -- test if version is locked
 */

#include <stdio.h>
#include <string.h>
#ifdef SUNOS_4_0
#include <strings.h>
#endif
#include <sys/types.h>
#include <sys/stat.h>

#include "typeconv.h"
#include "afsys.h"
#include "afs.h"
#include "afarchive.h"

/*================================================================
 *	af_lock
 *
 *================================================================*/

EXPORT Af_user *af_lock (key, locker, mode)
     Af_key  *key;
     Af_user *locker;
     int     mode;
{
  int oldlockeruid, newlockeruid, calleruid;
  Af_key lkey, *lkp;

  if (af_keytest (key))
    SFAIL ("lock", "", AF_EINVKEY, (Af_user *)0);
  
  if ((VATTR(key).af_mode & S_IFMT) != S_IFREG)
    SFAIL ("lock", "", AF_ENOTREGULAR, (Af_user *)0);

  if (VATTR(key).af_class & AF_DERIVED)
    SFAIL ("lock", "", AF_EDERIVED, (Af_user *)0);

  /* if caller == locker, everyone who has write access may set a lock, */
  /*                      if the object is not locked by someone else */
  /* else (caller != locker), only the owner may set a lock for someone else */

  newlockeruid = af_getuid (locker->af_username, locker->af_userhost);
  calleruid = getuid ();

  if (calleruid == newlockeruid)
    {
      if (af_checkperm (key, AF_WORLD) == ERROR)
	return ((Af_user *)0);
    }
  else
    {
      if (af_checkperm (key, AF_OWNER) == ERROR)
	return ((Af_user *)0);
    }

  lkp = &lkey;
  lkp->af_ldes = key->af_ldes;
  if (mode == AF_VERSIONLOCK)
    lkp->af_lpos = key->af_lpos;
  else
    lkp->af_lpos = 0;

  /* if version is not locked or already locked by caller */
  oldlockeruid = af_getuid (VATTR(lkp).af_lckname, VATTR(lkp).af_lckhost);

  if ((oldlockeruid == (Uid_t) ERROR) || (oldlockeruid == calleruid))
    {
      VATTR(lkp).af_lckname = af_entersym (locker->af_username);
      VATTR(lkp).af_lckhost = af_enterhost (locker->af_userhost);
      VATTR(lkp).af_ltime = (time_t) af_acttime();
      if (af_updtvers (lkp, AF_CHANGE) == ERROR)
	return ((Af_user *)0);
      return (locker);
    }
  else
    SFAIL ("lock", "", AF_ENOTLOCKED, (Af_user *)0);
}

/*================================================================
 *	af_unlock
 *
 *================================================================*/

EXPORT Af_user *af_unlock (key, mode)
     Af_key *key;
     int    mode;
{
  static Af_user locker;
  Af_key lkey, *lkp;

  if (af_keytest (key))
    SFAIL ("unlock", "", AF_EINVKEY, (Af_user *)0);

  if (af_checkperm (key, AF_OWNER | AF_LOCKHOLDER) == ERROR)
    return ((Af_user *)0);

  lkp = &lkey;
  lkp->af_ldes = key->af_ldes;
  if (mode == AF_VERSIONLOCK)
    lkp->af_lpos = key->af_lpos;
  else
    lkp->af_lpos = 0;

  if (VATTR(lkp).af_lckname != (char *)0)
    {
      (void) strcpy (locker.af_username, VATTR(lkp).af_lckname);
      (void) strcpy (locker.af_userhost, VATTR(lkp).af_lckhost);
      VATTR(lkp).af_lckname = (char *)0;
      VATTR(lkp).af_lckhost = (char *)0;
      VATTR(lkp).af_ltime = (time_t) af_acttime();
      if (af_updtvers (lkp, AF_CHANGE) == ERROR)
	return ((Af_user *)0);
    }
  else
    {
      locker.af_username[0] = '\0';
      locker.af_userhost[0] = '\0';
    }
  return (&locker);
}

/*================================================================
 *	af_testlock
 *
 *================================================================*/

EXPORT Af_user *af_testlock (key, mode)
     Af_key *key;
     int    mode;
{
  static Af_user locker;
  Af_key lkey, *lkp;

  if (af_keytest (key))
    SFAIL ("testlock", "", AF_EINVKEY, (Af_user *)0);

  lkp = &lkey;
  lkp->af_ldes = key->af_ldes;
  if (mode == AF_VERSIONLOCK)
    lkp->af_lpos = key->af_lpos;
  else
    lkp->af_lpos = 0;

  if (VATTR(lkp).af_lckname != (char *)0)
    {
      (void) strcpy (locker.af_username, VATTR(lkp).af_lckname);
      (void) strcpy (locker.af_userhost, VATTR(lkp).af_lckhost);
    }
  else
    {
      locker.af_username[0] = '\0';
      locker.af_userhost[0] = '\0';
    }
  return (&locker);
}


