/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*LINTLIBRARY*/
/*
 *	Shape/AFS
 *
 *	afenviron.c -- communication with the UNIX-Filesystem
 *
 *	Author: Andreas Lampen, TU-Berlin (andy@coma.UUCP)
 *					  (andy@db0tui62.BITNET)
 *
 *	$Header: afenviron.c[1.6] Wed Feb 22 16:27:29 1989 andy@coma published $
 *
 *	EXPORT:
 *      af_uniqpath -- build unified pathname
 *	af_setarchpath -- name directory where archives shall be stored
 *      af_isarchive -- test if a given file is an archive
 *	af_garname -- build name for archive file
 *	af_garown -- get owner of archive file
 *	af_gbpname -- build name for binary pool db-file
 *	af_gtmpname -- build name for tmp file
 *	af_gbusname -- build name of busy version
 *	af_afpath -- build af-syspath from UNIX-filename
 *	af_afname -- build af-filename from UNIX-filename
 *	af_aftype -- build af-filetype from UNIX-filename
 *	af_unixname -- build UNIX-filename from af-filename/type
 *      af_gmaxbpsize -- get max. number of files in binary pool
 *      af_bpfilename -- return filename for binary pool file
 *      af_rbphashname -- get unique filename for file in binary pool
 *	af_getuid -- returns uid of user if from local host
 *	af_getgid -- returns gid of user if from local host
 *	af_getuser -- returns name and host of caller
 */

#include <stdio.h>
#include <pwd.h>
#include <string.h>
#ifdef SUNOS_4_0
#include <strings.h>
#endif
#include <sys/file.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "typeconv.h"
#include "afsys.h"
#include "afs.h"
#include "afarchive.h"

char  *malloc();

/*================================================================
 *	af_uniqpath -- build unified pathname
 *
 *================================================================*/

EXPORT char *af_uniqpath (path)
     char *path;
{
  static char uniqpath[4*MAXNAMLEN], tmppath[4*MAXNAMLEN];
  char        *p, *u, *getwd();

  if ((path == (char *)0) || (path[0] == '\0') || ((path[0] == '.' && path[1] == '\0')))
    return (getwd (uniqpath));

  /* build absolute pathname if only a relative one is given */
  if (path[0] != '/')
    {
      if (!strcmp (path, ".."))
	{
	  (void) getwd (uniqpath);
	  if ((p = rindex (uniqpath, '/')) == uniqpath)
	    uniqpath[1] = '\0';
	  else
	    *p = '\0';
	  return (uniqpath);
	}
      (void) getwd (tmppath);
      (void) strcat (tmppath, "/");
      (void) strcat (tmppath, path);
      p = tmppath;
    }
  else
    p = path;

  /* eliminate things like "/usr/./bin" and "/usr/../usr/bin" */
  u = uniqpath;
  *u = '/';
  while (*p)
    {
      if ((p[0] == '/') && (p[1] == '.'))
	{
	  if ((p[2] == '/') || (p[2] == '\0'))
	    {
	      p = &p[2];
	      continue;
	    }
	  else
	    if ((p[2] == '.') && ((p[3] == '/') || (p[3] == '\0')))
	      {
		if (u != uniqpath)
		  do { *u = '\0'; u--; } while (*u != '/');
		p = &p[3];
		continue;
	      }
	}
      u++;
      *u = p[1];
      p++;
    }
  
  /* cut slash if present at the end */
  u--;
  if ((u != uniqpath) && (*u == '/'))
    *u = '\0';
  else
    u[1] = '\0';

  return (uniqpath);
}

static char archpath[4*MAXNAMLEN] = "\0";

/*================================================================
 *	af_setarchpath
 *
 *================================================================*/

EXPORT af_setarchpath (pathname)
     char *pathname;
{
  if (pathname == (char *)0)
    archpath[0] = '\0';
  else
    (void) strcpy (archpath, af_uniqpath (pathname));
}


/*====================================================================
 * af_isarchive -- test if a given file is an archive
 *
 *====================================================================*/

EXPORT af_isarchive (name)
     char *name;
{
  char ext;

  if (!name || strncmp (name, AF_AFSFILEID, AF_IDSTRLEN))
    return (FALSE);

  ext = name[strlen (name) - sizeof (char)];
  if ((ext != AF_ARCHEXT) && (ext != AF_DATAEXT))
    return (FALSE);

  return (TRUE);
}


/*================================================================
 *	af_garname
 *
 *================================================================*/

EXPORT char *af_garname (pathname, name, type)
     char *pathname;
     char *name, *type;
{
  char arname[MAXNAMLEN*4];

  /* see if there is an explicit pathname where archives shall be stored */
  if (archpath[0])
    (void) strcpy (arname, archpath);
  else
    (void) sprintf (arname, "%s/%s\0", NOTNIL(pathname), AF_SUBDIR);

  if ((type != (char *)0) && (type[0] != '\0'))
    (void) sprintf (&arname[strlen (arname)], "/%s%s.%s%c\0",
	     AF_AFSFILEID, NOTNIL(name), NOTNIL(type), AF_ARCHEXT);
  else
    (void) sprintf (&arname[strlen (arname)], "/%s%s%c\0",
	     AF_AFSFILEID, NOTNIL(name), AF_ARCHEXT);

  return (af_entersym (arname));
} /* af_garname */ 


/*================================================================
 *	af_garown
 *
 *================================================================*/

EXPORT Af_user *af_garown (archname, writeok)
     char    *archname;
     bool    *writeok; /* out */
{
  char ardirname[MAXNAMLEN*4], *namptr;
  struct stat ibuf;

  /* build name of directory, where the archive is located */
  (void) strcpy (ardirname, archname);

  /* cut name */
  namptr = rindex (ardirname, '/');
  *namptr = '\0';

  *writeok = FALSE;
  if (stat (ardirname, &ibuf) == ERROR)
    return ((Af_user *)0);
  else
    if (!af_sysaccess (ardirname, W_OK))
      *writeok = TRUE;

  return (af_getuser (ibuf.st_uid));
} /* af_garown */ 


/*================================================================
 *	af_gbpname
 *
 *================================================================*/

EXPORT char *af_gbpname (pathname)
     char *pathname;
{
  char bpname[MAXNAMLEN*4];

  /* see if there is an explicit pathname where archives shall be stored */
  if (archpath[0])
    (void) strcpy (bpname, archpath);
  else
    (void) sprintf (bpname, "%s/%s/\0", pathname, AF_SUBDIR);

  if (af_sysaccess (bpname, R_OK))
    return ((char *)0);

  (void) strcat (bpname, AF_BPOOLNAME);

  return (af_entersym (bpname));
} /* af_garname */ 


/*================================================================
 *	af_gtmpname
 *
 *================================================================*/

static int count=0;

EXPORT char *af_gtmpname (pathname, filename)
     /*ARGSUSED*/
     char *pathname; /* unused up to now */
     char *filename;
{
  char tmpname[MAXNAMLEN*4];
  
  (void) sprintf (tmpname, "%s/%s%d%d\0", AF_TMPDIR, filename, getpid(), count++);
  return (af_entersym (tmpname));
} /* af_gtmpname */


/*================================================================
 *	af_gbusname
 *
 *================================================================*/

EXPORT char *af_gbusname (pathname, name, type)
     char *pathname;
     char *name, *type;
{
  char busyname[MAXNAMLEN*4];
   
  (void) sprintf (busyname, "%s/%s", pathname, name);
  if ((type != (char *)0) && (type[0] != '\0'))
      {
	(void) strcat (busyname, ".");
	(void) strcat (busyname, type);
      }
  return (af_entersym (busyname));
} /* af_gbusname */ 



/*================================================================
 *	af_afpath
 *
 *================================================================*/

EXPORT char *af_afpath (unixname)
     char *unixname;
{
  char *nameptr;
  static char afpath[MAXNAMLEN];

  if (unixname)
    (void) strcpy (afpath, unixname);
  else
    afpath[0] = '\0';

  /* cut name */
  if ((nameptr = rindex (afpath, '/')) != (char *)0)
    nameptr[0] = '\0';
  else
    {
      afpath[0] = '\0';
      return (afpath);
    }

  /* cut AFS subdirectory name if present */
  if (((nameptr = rindex (afpath, '/')) != (char *)0) && 
       !strcmp (AF_SUBDIR, nameptr+1))
    nameptr[0] = '\0';
  else
    if (!strcmp (AF_SUBDIR, afpath))
      afpath[0] = '\0';

  return (afpath);
}

/*================================================================
 *	af_afname
 *
 *================================================================*/

EXPORT char *af_afname (unixname)
     char *unixname;
{
  char *typeptr, *nameptr;
  static char afname[MAXNAMLEN];

  if (!unixname)
    {
      afname[0] = '\0';
      return (afname);
    }

  /* set nameptr to beginning of name */
  if ((nameptr = rindex (unixname, '/')) == (char *)0)
    nameptr = unixname;
  else
    nameptr++;

  if (af_isarchive (nameptr))
    {
      (void) strcpy (afname, nameptr + strlen (AF_AFSFILEID));
      afname[strlen (afname) - sizeof (char)] = '\0';
    }
  else
    (void) strcpy (afname, nameptr);

  /* special handling for "." and ".." */
  if (!strcmp (afname, ".") || !strcmp (afname, ".."))
    return (afname);

  /* if a UNIX type-extension is given -- cut it, except the dot is */
  /*                                      at position 0 (e.g. .cshrc) */
  if ((typeptr = rindex (afname, '.')) != (char *)0)
    if (typeptr != afname)
      typeptr[0] = '\0';

  return (afname);
}

/*================================================================
 *	af_aftype
 *
 *================================================================*/

EXPORT char *af_aftype (unixname)
     char *unixname;
{
  char *typeptr, *nameptr;
  static char aftype[MAXTYPLEN];
  bool isarch = FALSE;

  if (!unixname)
    {
      aftype[0] = '\0';
      return (aftype);
    }

  /* set nameptr to beginning of name */
  if ((nameptr = rindex (unixname, '/')) == (char *)0)
    nameptr = unixname;
  else
    nameptr++;

  if (af_isarchive (nameptr))
    {
      nameptr += strlen (AF_AFSFILEID);
      isarch = TRUE;
    }

  /* if there is no UNIX type-extension */
  if ((typeptr = rindex (nameptr, '.')) == (char *)0)
    aftype[0] = '\0';
  else
    {
      /* if the found dot indicates a "hidden file" (eg. .cshrc) */
      if (typeptr == nameptr)
	aftype[0] = '\0';
      else
	{
	  (void) strcpy (aftype, typeptr + sizeof(char));
	  /* if the named file is an archive, cut the name-extension */
	  if (isarch)
	    aftype [strlen (aftype) - sizeof (char)] = '\0';
	}
    }
  return (aftype);
}


/*================================================================
 *	af_unixname
 *
 *================================================================*/

EXPORT char *af_unixname (path, name, type)
     char *path, *name, *type;
{
  static char unixname[4*MAXNAMLEN];

  if ((path == (char *)0) || (path[0] == '\0'))
    (void) strcpy (unixname, NOTNIL(name));
  else
    (void) sprintf (unixname, "%s/%s\0", path, name);

  if ((type != (char *)0) && (type[0] != '\0'))
    {
      (void) strcat (unixname, ".");
      (void) strcat (unixname, type);
    }
  return (unixname);
}


/*================================================================
 *      af_gmaxbpsize -- get max. number of files in binary pool
 *
 *================================================================*/

EXPORT int af_gmaxbpsize (name)
     /*ARGSUSED*/
     char *name; /* unused up to now */
{
  char *envval, *getenv();

  if (envval = getenv (AF_ENVBPSIZE))
    return (atoi (envval));
  else
    return AF_MAXBPSIZE;
}


/*================================================================
 *	af_bpfilename
 *
 *================================================================*/

EXPORT char *af_bpfilename (pathname, name)
     char *pathname, *name;
{
  static char bpname[MAXNAMLEN];

  (void) sprintf (bpname, "%s/%s/%s\0", pathname, AF_SUBDIR, name);
  return (bpname);
}

/*================================================================
 * af_rbphashname -- get unique filename for file in binary pool
 *
 *================================================================*/

EXPORT char *af_rbphashname (name, type, gen, rev, variant, list, count)
     char *name, *type, *variant;
     int  gen, rev;
     /*ARGSUSED*/
     Af_revlist *list; /* unused up to now */
     int count;
{
  char hashname[MAXNAMLEN];

  (void) sprintf (hashname, "%s%s.%s[%d.%d]%s%d\0", AF_BPFILEID, 
	   name, type, gen, rev, variant, count);

  return (af_entersym (hashname));
}


/*========================================================================
 *	af_getuid - returns uid of user if from local host
 *                  AF_ERROR if user is unknown
 *                  AF_REMOTE if user is not local
 *
 *========================================================================*/

EXPORT Uid_t af_getuid (name, host)
     char *name, *host;
{
  struct passwd *pwent;

  if (name == (char *)0) /* in this case, name and host are null pointers */
    return ((Uid_t) ERROR);

  if (strcmp (af_gethostname(), host))
    return ((Uid_t) AF_REMOTE);

  if ((pwent = getpwnam (name)) == (struct passwd *)0)
    FAIL ("getuid", "cannot get user ID", AF_EINTERNAL, (Uid_t) ERROR);

  return (pwent->pw_uid);
}


/*========================================================================
 *	af_getgid - returns gid of user if from local host
 *                  AF_ERROR if user is unknown
 *                  AF_REMOTE if user is not local
 *
 *========================================================================*/

EXPORT Gid_t af_getgid (name, host)
     char *name, *host;
{
  struct passwd *pwent;

  if (name == (char *)0) /* in this case, name and host are null pointers */
    return ((Gid_t) ERROR);

  if (strcmp (af_gethostname(), host))
    return ((Gid_t) AF_REMOTE);

  if ((pwent = getpwnam (name)) == (struct passwd *)0)
    FAIL ("getgid", "cannot get group ID", AF_EINTERNAL, (Gid_t) ERROR);

  return (pwent->pw_gid);
}


/*========================================================================
 *	af_getuser - returns name and host of caller
 *
 *========================================================================*/

static Uid_t   calleruid;
static Af_user caller;
static bool    initcaller = FALSE;

EXPORT Af_user *af_getuser (uid)
     Uid_t uid;
{
  static Af_user result;
  struct passwd *pwent;
 
  if (!initcaller) /* if caller struct is not yet initialized */
    {
      calleruid = getuid();
      (void) strcpy (caller.af_userhost, af_gethostname ()); 
      if ((pwent = getpwuid ((int) calleruid)) == (struct passwd *)0)
	SFAIL ("getuser", "", AF_EINVUSER, (Af_user *)0);
      (void) strcpy (caller.af_username, pwent->pw_name);
      initcaller = TRUE;
    }
  if (uid == calleruid)
    return (&caller);

  (void) strcpy (result.af_userhost, af_gethostname ()); 
  if ((pwent = getpwuid ((int) uid)) == (struct passwd *)0)
    SFAIL ("getuser", "", AF_EINVUSER, (Af_user *)0);
  (void) strcpy (result.af_username, pwent->pw_name);

  return (&result);
}
