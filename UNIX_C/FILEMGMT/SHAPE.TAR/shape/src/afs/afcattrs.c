/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*LINTLIBRARY*/
/*
 *	Shape/AFS
 *
 *	afcattrs.c - read and write complex attributes
 *
 *	Author: Andreas Lampen, TU-Berlin (andy@coma.UUCP
 *					   andy@db0tui62.BITNET)
 *
 *	$Header: afcattrs.c[1.5] Wed Feb 22 16:27:20 1989 andy@coma published $
 *
 *	EXPORT:
 *	af_snote -- set note (write note text)
 *	af_rnote -- return note
 *	af_svariant -- set variant attribute
 *	af_rvariant -- return variant
 *	af_sudattr -- set or modify user defined attribute
 *	af_rudattr -- return user defined attributes
 */

#include <stdio.h>
#include <string.h>
#ifdef SUNOS_4_0
#include <strings.h>
#endif

#include "typeconv.h"
#include "afsys.h"
#include "afs.h"

#ifdef MEMDEBUG
extern FILE *memprot;
#endif

char *malloc();

/*====================================================================
 *    af_snote -- set note (write note text)
 *
 *====================================================================*/

EXPORT af_snote (key, buf)
     Af_key *key;
     char   *buf;
{
  int  len;
  char internalbuf[1];

  internalbuf[0] = '\0';

  if (af_keytest (key))
    SFAIL ("snote", "", AF_EINVKEY, ERROR);
  if (VATTR(key).af_state == AF_BUSY)
    SFAIL ("snote", "", AF_EBUSY, ERROR);
  if (VATTR(key).af_class & AF_DERIVED)
    SFAIL ("snote", "", AF_EDERIVED, ERROR);
  if (af_checkperm (key, AF_LOCKHOLDER | AF_AUTHOR | AF_OWNER) == ERROR)
    SFAIL ("snote", "", AF_EACCES, ERROR);

  if (af_readdata (key->af_ldes) == ERROR)
    return (ERROR);

  if (!buf) /* if buf is a nil pointer */
    buf = internalbuf;

  len = strlen(buf) + sizeof (char); /* length of string plus nullbyte */
  if (len > VATTR(key).af_notesize)
    {
      if ((VATTR(key).af_note = af_malloc (key->af_ldes, (unsigned) (len * sizeof (char)))) == (char *)0)
	FAIL ("snote", "malloc", AF_ESYSERR, ERROR);
    }
  /* change datasize in header */
  key->af_ldes->af_datasize -= VATTR(key).af_notesize;
  key->af_ldes->af_datasize += len;

  (void) strncpy (VATTR(key).af_note, buf, len);
  VATTR(key).af_notesize = len;

  /* save changes */
  if (af_updtvers (key, AF_CHANGE) == ERROR)
    return (ERROR);
  return (AF_OK);
}



/*====================================================================
 *    af_rnote -- get pointer to note (read only)
 *
 *====================================================================*/

EXPORT char *af_rnote (key)
     Af_key *key;
{
  char *note;

  if (af_keytest (key))
    SFAIL ("rnote", "", AF_EINVKEY, (char *)0);
  if (VATTR(key).af_state == AF_BUSY)
    SFAIL ("rnote", "", AF_EBUSY, (char *)0);
  if (VATTR(key).af_class & AF_DERIVED)
    SFAIL ("rnote", "", AF_EDERIVED, (char *)0);

  if (af_readdata (key->af_ldes) == ERROR)
    return ((char *)0);

  if (VATTR(key).af_notesize != 0)
    {
      if ((note = malloc ((unsigned) VATTR(key).af_notesize)) == (char *)0)
	FAIL ("rnote", "malloc", AF_ESYSERR, (char *)0);
      (void) strcpy (note, VATTR(key).af_note);
      /* replace newline by nullbyte */
      note[VATTR(key).af_notesize-1] = '\0';
    }
  else
    {
      if ((note = malloc ((unsigned) sizeof (char))) == (char *)0)
	FAIL ("rnote", "malloc", AF_ESYSERR, (char *)0);
      note[0] = '\0';
    }

  return (note);
}



/*====================================================================
 *    af_svariant -- set variant attribute
 *
 *====================================================================*/

EXPORT af_svariant (key, buf)
     Af_key *key;
     char   *buf;
{
  if (af_keytest (key))
    SFAIL ("svariant", "", AF_EINVKEY, ERROR);
  if (buf)
    if (strlen (buf) >= MAXVARLEN)
      SFAIL ("svariant", "", AF_ETOOLONG, ERROR);
  if (VATTR(key).af_class & AF_DERIVED)
    SFAIL ("svariant", "", AF_EDERIVED, ERROR);
  if (af_checkperm (key, AF_OWNER | AF_AUTHOR) == ERROR)
    return (ERROR);

  VATTR(key).af_variant = af_entersym (buf);

  /* save changes */
  if (af_updtvers (key, AF_CHANGE) == ERROR)
    return (ERROR);
  return (AF_OK);
}



/*====================================================================
 *    af_rvariant -- return variant attribute
 *
 *====================================================================*/

EXPORT char *af_rvariant (key)
     Af_key *key;
{
  char *variant;

  if (af_keytest (key))
    SFAIL ("rvariant", "", AF_EINVKEY, (char *)0);
  if (VATTR(key).af_class & AF_DERIVED)
    SFAIL ("rvariant", "", AF_EDERIVED, (char *)0);

  if (VATTR(key).af_variant)
    {
      if ((variant = malloc ((unsigned) strlen (VATTR(key).af_variant) + sizeof (char))) == (char *)0)
	FAIL ("rvariant", "malloc", AF_ESYSERR, (char *)0);
      (void) strcpy (variant, VATTR(key).af_variant);
    }
  else
    {
      if ((variant = malloc ((unsigned) sizeof (char))) == (char *)0)
	FAIL ("rvariant", "malloc", AF_ESYSERR, (char *)0);
      variant[0] = '\0';
    }

  return (variant);
}

/*====================================================================
 *    af_sudattr -- set or modify user defined attribute
 *               User defined attributes are strings of the following form:
 *                 name=value
 *               For manipulating user defined attributes you have three
 *               modes:
 *               AF_ADD -- add value to attribute if name is present or
 *                         add user defined attribute otherwise
 *               AF_REMOVE -- remove attribute
 *               AF_REPLACE -- replace attribute
 *
 *               Returns AF_OK on successful execution, otherwise ERROR
 *
 *               Caution: the string "attr" must not contain '\n' !!
 *
 *====================================================================*/

EXPORT af_sudattr (key, mode, attr)
     Af_key *key;
     int    mode;
     char   *attr;
{
  char *udaptr, *tmpuda, *valptr;
  int  tail;

  if (af_keytest (key))
    SFAIL ("sudattr", "", AF_EINVKEY, ERROR);
  if (VATTR(key).af_state == AF_FROZEN)
    SFAIL ("sudattr", "", AF_EWRONGSTATE, ERROR);

  /* look for delimiter character in attribute string */
  if (!attr || (index (attr, AF_UDAVALDEL) != (char *)0))
    SFAIL ("sudattr", "", AF_EFORMAT, ERROR);

  if (af_checkperm (key, AF_WORLD) == ERROR)
    return (ERROR);

  /* search entry */
  udaptr = af_symlookup (&(VATTR(key).af_uhtab), attr,
			 (Af_revlist *)0, (Af_revlist **)0); 

  switch (mode)
    {
    case AF_ADD: if (udaptr != (char *)0)
                   {
		     /* build new entry and replace old one */
		     valptr = index (attr, '=') + sizeof (char);
		     if ((tmpuda = malloc ((unsigned) ((strlen (udaptr) + strlen (valptr) +2) * sizeof (char)))) == (char *)0)
		       FAIL ("sudattr", "malloc", AF_ESYSERR, ERROR);

		     (void) strcpy (tmpuda, udaptr);
		     tail = strlen (tmpuda);
		     tmpuda[tail] = AF_UDAVALDEL;
		     tmpuda[tail+1] = '\0';
		     (void) strcat (tmpuda, valptr);
		     (void) af_replsym (&(VATTR(key).af_uhtab), tmpuda, (Af_revlist *)0);
		     free (tmpuda);
 		   }    
                 else
		   {
		     /* add new entry */
		     if (VATTR(key).af_udanum == AF_MAXUDAS-1)
		       SFAIL ("sudattr", "", AF_EUDASNUM, ERROR);
		     (void) af_hashsym (&(VATTR(key).af_uhtab), attr,(Af_revlist *)0);
#ifdef MEMDEBUG
		     fprintf (memprot, "UdaCattr (%s)\n", attr);
#endif
		     VATTR(key).af_udanum++;
		   }
                 break;

    case AF_REMOVE: if (udaptr == (char *)0)
                      SFAIL ("sudattr", "", AF_ENOUDA, ERROR);
		    (void) af_delsym (&(VATTR(key).af_uhtab), udaptr,(Af_revlist *)0);
		    VATTR(key).af_udanum--;
                    break;

    case AF_REPLACE: if (udaptr == (char *)0)
                       SFAIL ("sudattr", "", AF_ENOUDA, ERROR);
                     (void) af_replsym (&(VATTR(key).af_uhtab), attr, (Af_revlist *)0);
                     break;
    default: SFAIL ("sudattr", "", AF_EMODE, ERROR);
    }

  /* save changes */
  if (af_updtvers (key, AF_CHANGE) == ERROR)
    return (ERROR);
  return (AF_OK);
}



/*====================================================================
 *    af_rudattr -- return user defined attributes
 *
 *====================================================================*/

EXPORT char *af_rudattr (key, name)
     Af_key *key;
     char   *name;
{
  char *udattr, *entry, *valptr;

  if (af_keytest (key))
    SFAIL ("rudattr", "", AF_EINVKEY, (char *)0);
  if (!name)
    SFAIL ("rudattr", "no attribute name given", AF_EMISC, (char *)0);

  if ((entry = af_symlookup (&(VATTR(key).af_uhtab), name,
			     (Af_revlist *)0, (Af_revlist **)0)) == (char *)0)
    return (char *)0;

  if ((valptr = index (entry, AF_UDANAMDEL)) != (char *)0)
    {
      if ((udattr = malloc ((unsigned) strlen(valptr) + sizeof(char))) == (char *)0)
	FAIL ("rudattr", "malloc", AF_ESYSERR, (char *)0);
      /* replace delimiters by '\n' */
      (void) strcpy (udattr, valptr+1);
      valptr = udattr;
      while ((valptr = index (valptr, AF_UDAVALDEL)) != (char *)0)
	valptr[0] = '\n';
    }
  else
    {
      if ((udattr = malloc ((unsigned) sizeof(char))) == (char *)0)
	FAIL ("rudattr", "malloc", AF_ESYSERR, (char *)0);
      udattr[0] = '\0';
    }
  
  return (udattr);
}

