/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*
 * $Header: typeconv.h[1.1] Thu Feb 23 18:13:59 1989 axel@coma published $
 *
 * Log for /u/shape/dist-tape/src/vc/typeconv.h[1.0]
 * 	Thu Feb 23 18:13:59 1989 axel@coma published $
 *  --- empty log message ---
 *  typeconv.h[1.1] Thu Feb 23 18:13:59 1989 axel@coma published $
 *  --- empty log message ---
 */


#ifndef _TYPECONV_
#define _TYPECONV_
#if !(defined (ULTRIX_2_0) | defined (BSD_4_3) | defined (SUNOS_4_0)) 
#define BSD_4_3
#endif

#ifdef ULTRIX_2_0
#ifndef Sfunc_t
#define Sfunc_t void        /* type of function argument to signal call */
#endif
#ifndef Size_t
#define Size_t unsigned      /* used for args to malloc(), fread() etc. */
#endif
#ifndef Uid_t
#define Uid_t int            /* used for user-id types */
#endif
#ifndef Gid_t
#define Gid_t int            /* used for user-id types */
#endif
#endif

#ifdef BSD_4_3
#ifndef Sfunc_t
#define Sfunc_t int
#endif Sfunc_t
#ifndef Size_t
#define Size_t int
#endif Size_t
#ifndef Uid_t
#define Uid_t uid_t
#endif Uid_t
#ifndef Gid_t
#define Gid_t gid_t
#endif Gid_t
#endif

#ifdef SUNOS_4_0
#ifndef Sfunc_t
#define Sfunc_t int
#endif Sfunc_t
#ifndef Size_t
#define Size_t int
#endif Size_t
#ifndef Uid_t
#define Uid_t uid_t
#endif Uid_t
#ifndef Gid_t
#define Gid_t gid_t
#endif Gid_t
#endif
#endif _TYPECONV_
