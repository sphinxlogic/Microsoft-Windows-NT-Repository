/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*
 *	Shape/AFS
 *
 *	afbpool.c -- read/write binary-pool control files (ndbm version)
 *
 *	Author: Andreas Lampen, TU-Berlin (andy@coma.UUCP)
 *					  (andy@db0tui62.BITNET)
 *
 *	$Header: afbpool.c[1.5] Wed Feb 22 16:27:14 1989 andy@coma published $
 *
 *	EXPORT:
 *      af_rbplist -- read list of files in binary pool
 *      af_delbpentry -- delete file entry in binary pool
 *      af_rplbpentry -- replace file entry in binary pool
 *      af_isbpfile -- see if a given file belongs to binary pool
 *      af_detbpool -- detach binary pool
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/dir.h>
#include <sys/file.h>
#include <sys/time.h>
#include <string.h>
#ifdef SUNOS_4_0
#include <strings.h>
#endif
#ifdef OLDDBM
#undef NULL
#include <dbm.h>
#undef NULL
#else
#include <ndbm.h>
#endif

#include "typeconv.h"
#include "afsys.h"
#include "afs.h"
#include "afarchive.h"

#ifdef MEMDEBUG
extern FILE *memprot;
#endif

/*==========================================================================
 *	definition of binary pool revision list
 *      plus hashtable for faster access
 *
 *==========================================================================*/

LOCAL Af_revlist bplst;
     /* base address of all binary pool list descriptors */
LOCAL Af_revlist *bplists = (Af_revlist *)0;  
     /* base address of freelist for binary pool list descriptors */
LOCAL Af_revlist *bpfreelist = &bplst;  /* beginning of freelist */

LOCAL Af_hash bphash;

LOCAL Af_revlist *initlist (path, mode)
     char *path;
     int  mode;
{
  static bool hinit = FALSE; /* indicate if hashtable is yet initialized */
  int         af_fhash();
  register    i;
  Af_revlist  *list, *oldlist, **oldptr, *tail;
  char        *malloc(), *pathsym, *arname;

  oldptr = &oldlist;
  /* init hashtable if it is not yet done */
  if (!hinit)
    {
      (void) af_hashinit (&bphash, AF_MAXLISTS, af_fhash);
      hinit = TRUE;
    }

  pathsym = af_entersym (path);

  /* if there are open archives check if desired archive is loaded yet */
  if (bplists != (Af_revlist *)0)
    {
      if (af_symlookup (&bphash, path, (Af_revlist *)0, oldptr))
	{
	  /* found something */
	  /* if it is the right list */
	  if (oldlist->af_cattrs.af_syspath == pathsym)
	    return (oldlist);
	  /* else continue the search as long as there are entries */
	  while (af_symlookup (&bphash, path, oldlist, oldptr))
	    {
	      if (oldlist->af_cattrs.af_syspath == pathsym)
		return (oldlist);
	    }
	}
    }

  /* check if AFS subdirectory exists */
  if ((arname = af_gbpname (path)) == (char *)0)
    {
      if (mode == AF_READ)
	SFAIL ("initlist", "", AF_ENOAFSDIR, (Af_revlist *)0)
      else
	FAIL ("initlist", "", AF_ENOAFSDIR, (Af_revlist *)0);
    }
  
  /* if there are no more descriptors available - allocate new space */
  if (bpfreelist == (Af_revlist *)0)
    {
      if ((bpfreelist = (Af_revlist *) malloc ((unsigned) (AF_LISTSEG * sizeof (Af_revlist)))) == (Af_revlist *)0)
	FAIL ("initlist", "malloc(i)", AF_ESYSERR, (Af_revlist *)0);

      /* build up new freelist */
      for (i=1; i<AF_LISTSEG; i++)
	bpfreelist[i-1].af_next = &(bpfreelist[i]);
      bpfreelist[AF_LISTSEG-1].af_next = (Af_revlist *)0;
    }

  if (bplists != (Af_revlist *)0)
    {
      tail = bplists->af_next;
      bplists->af_next = bpfreelist;
      bpfreelist = bpfreelist->af_next;
      list = bplists->af_next;
      bzero ((char *)list, sizeof (*list));

      list->af_next = tail;
    }
  else
    {
      list = bpfreelist;
      bpfreelist = bpfreelist->af_next;
      /* initialize whole struct (i.e. set af_next to "nil") */
      bzero ((char *)list, sizeof (*list));
      bplists = list;
    }

  list->af_mem = (char *)0;

  /* initialize list structure */
  list->af_cattrs.af_host = af_gethostname ();
  list->af_cattrs.af_syspath = pathsym;
  list->af_arfilename = arname;
  list->af_busyfilename = af_entersym ("");

  list->af_listlen = af_gmaxbpsize (list->af_arfilename);
  if ((list->af_list = (Af_vattrs *)af_malloc (list, (unsigned) (list->af_listlen * sizeof(Af_vattrs)))) == (Af_vattrs *)0)
    FAIL ("initlist", "malloc", AF_ESYSERR, (Af_revlist *)0);

  bzero ((char *)list->af_list, list->af_listlen * sizeof (Af_vattrs));

  list->af_extent |= AF_BPOOL;
  list->af_extent |= AF_UXWRITE;
  list->af_nrevs = 0;

  /* add list to hashtable */
  (void) af_hashsym (&bphash, path, list);
#ifdef MEMDEBUG
  fprintf (memprot, "InitBP (%s)\n", path);
#endif

  return (list);
}

/*==========================================================================
 * af_dbmstring -- build dbm string from attrbuf
 *
 *==========================================================================*/

LOCAL datum af_dbmstring (key, size)
     Af_key *key;
     int    size; /* size of dbm key element */
{
  static datum data;
  static char  string[MAXDBMLEN];
  char *ptrlist[AF_MAXUDAS], *udaptr;
  register i;
  int  maxstrlen;

  data.dptr = string;

  /* enter all relevant attributes */
#ifdef ULTRIX_2_0
  (void) sprintf (string, "%s %s %s %s %d %d %s %s \0",
	   CATTR(key).af_host, CATTR(key).af_syspath, VATTR(key).af_name, 
	   NOTMT (VATTR(key).af_type), VATTR(key).af_gen, VATTR(key).af_rev, 
	   NOTMT (VATTR(key).af_variant), VATTR(key).af_auname);
  (void) sprintf (&string[strlen(string)], "%s %o %d %d %d %d \0",
	   VATTR(key).af_auhost, VATTR(key).af_mode, VATTR(key).af_fsize,
	   VATTR(key).af_mtime, VATTR(key).af_atime, VATTR(key).af_ctime);
#else
  (void) sprintf (string, "%s %s %s %s %d %d %s %s %s %o %d %d %d %d \0",
	   CATTR(key).af_host, CATTR(key).af_syspath, VATTR(key).af_name, 
	   NOTMT (VATTR(key).af_type), VATTR(key).af_gen, VATTR(key).af_rev, 
	   NOTMT (VATTR(key).af_variant), VATTR(key).af_auname, 
	   VATTR(key).af_auhost, VATTR(key).af_mode, VATTR(key).af_fsize,
	   VATTR(key).af_mtime, VATTR(key).af_atime, VATTR(key).af_ctime);
#endif
  (void) strcat (string, AF_UDAID);
  data.dsize = strlen (data.dptr) + sizeof (char);

  /* add user defined attributes */ 
  (void) af_lhashsyms (&(VATTR(key).af_uhtab), ptrlist);
  i=0;
  udaptr = string;
  maxstrlen = (MAXDBMLEN - DBMLOSS) - size;
  while (ptrlist[i])
    {
      if ((data.dsize += ((strlen (ptrlist[i])) + sizeof (char))) >= maxstrlen)
	{
	  data.dptr = (char *)0;
	  FAIL ("dbmstring", "", AF_ETOOLONG, data);
	}
      udaptr = &udaptr[strlen(udaptr)+1];
      (void) strcpy (udaptr, ptrlist[i]);
      i++;
    }

  udaptr[strlen(udaptr)+1] = '\0';
  data.dsize++;

  return (data);
} /* end af_dbmstring */

/*===================================================================
 * af_dbmkey -- build attrbuf from dbm entry
 *===================================================================*/

LOCAL af_dbmkey (data, dbmkey, afkey)
     datum *data, *dbmkey;
     Af_key *afkey;
{
  char name[MAXNAMLEN], type[MAXTYPLEN], variant[MAXVARLEN], *udaptr;
  char host[MAXHOSTNAMELEN], syspath[MAXNAMLEN*4];
  char auhost[MAXHOSTNAMELEN], auname[MAXNAMLEN];
  int  af_fhash();

  /* do initializations */
  VATTR(afkey).af_state = AF_NOSTATE;
  VATTR(afkey).af_class = AF_DERIVED | AF_VALID;
  VATTR(afkey).af_stime = AF_NOTIME;
  VATTR(afkey).af_lckname = (char *)0;
  VATTR(afkey).af_lckhost = (char *)0;
  VATTR(afkey).af_ltime = AF_NOTIME;
  VATTR(afkey).af_notesize = 0;
  VATTR(afkey).af_note = (char *)0;
  VATTR(afkey).af_repr = AF_FILE;
  VATTR(afkey).af_dsize = 0;
  VATTR(afkey).af_data = (char *)0;
  VATTR(afkey).af_nlinks = 0;
  VATTR(afkey).af_succgen = AF_NOVNUM;
  VATTR(afkey).af_succrev = AF_NOVNUM;
  VATTR(afkey).af_predgen = AF_NOVNUM;
  VATTR(afkey).af_predrev = AF_NOVNUM;

  (void) sscanf (data->dptr, "%s%s%s%s%ld%ld%s%s%s%ho%ld%ld%ld%ld",
	  host, syspath, name, type,
	  &(VATTR(afkey).af_gen), &(VATTR(afkey).af_rev), 
	  variant, auname, auhost, &(VATTR(afkey).af_mode), 
	  &(VATTR(afkey).af_fsize), &(VATTR(afkey).af_mtime), 
	  &(VATTR(afkey).af_atime),&(VATTR(afkey).af_ctime));

  /* check plausibility of host and syspath */
  if (strcmp (host, CATTR(afkey).af_host) || 
      strcmp (syspath, CATTR(afkey).af_syspath))
    af_wng ("dbmkey", "location of bpool possibly not correct");

  if (!strcmp (type, AF_NOSTRING))
    type[0] = '\0';
  if (!strcmp (variant, AF_NOSTRING))
    variant[0] = '\0';

  VATTR(afkey).af_name = af_entersym (name);

  if (type[0])
    VATTR(afkey).af_type = af_entersym (type);
  else
    VATTR(afkey).af_type = (char *)0;

  if (variant[0])
    VATTR(afkey).af_variant = af_entersym (variant);
  else
    VATTR(afkey).af_variant = (char *)0;
  
  VATTR(afkey).af_auname = af_entersym (auname);
  VATTR(afkey).af_auhost = af_enterhost (auhost);
  VATTR(afkey).af_hashname = af_entersym (dbmkey->dptr);

  /* read user defined attributes */

  udaptr = rindex (data->dptr, AF_UDAID[0]);
  if (strcmp (udaptr, AF_UDAID))
    {
      /* this should not happen very often */
      udaptr = index (data->dptr, AF_UDAID[0]);
      while ((udaptr) && (!strcmp (udaptr, AF_UDAID)))
	udaptr = index (udaptr, AF_UDAID[0]);
      if (!udaptr)
	FAIL ("dbmkey", "cannot find udas", AF_EINCONSIST, ERROR);
    }

  /* build up hashlist and read user defined attributes */
  if (af_hashinit (&(VATTR(afkey).af_uhtab), AF_MAXUDAS, af_fhash) == ERROR)
    return (ERROR);

  udaptr += (AF_IDSTRLEN + sizeof (char));
  while (udaptr[0])
    {
      (void) af_hashsym (&(VATTR(afkey).af_uhtab), udaptr, (Af_revlist *)0);
#ifdef MEMDEBUG
      fprintf (memprot, "UdaBP (%s)\n", udaptr);
#endif
      VATTR(afkey).af_udanum++;
      udaptr = (index (udaptr, '\0') + sizeof (char));
    }
  return (AF_OK);
} /* end af_dbmkey */

/*===================================================================
 * gbpsize -- get binary pool size and owner
 *===================================================================*/

#ifdef OLDDBM
LOCAL Af_user *gbpsize (size)
#else
LOCAL Af_user *gbpsize (db, size)
     DBM *db;
#endif
     short *size;
{
  static Af_user owner;
  datum data, dbkey;
  
  static char *stdentryname = AF_BPSTDENTRY;

  dbkey.dptr = stdentryname;
  dbkey.dsize = strlen (AF_BPSTDENTRY);

#ifdef OLDDBM
  data = fetch (dbkey);
#else
  data = dbm_fetch (db, dbkey);
#endif
  if (data.dptr == (char *)0)
    {
      *size = 0;
      return (af_getuser (getuid()));
    }
  else
    {
      (void) sscanf (data.dptr, "%hd%s%s", size, owner.af_username,owner.af_userhost);
      return (&owner);
    }
}

/*===================================================================
 * pbpsize -- put binary pool size and owner
 *===================================================================*/

#ifdef OLDDBM
LOCAL pbpsize (size, owner)
#else
LOCAL pbpsize (db, size, owner)
     DBM     *db;
#endif
     int     size;
     Af_user *owner;
{
  datum data, dbkey;
  static char str[32], *stdentryname = AF_BPSTDENTRY;

  dbkey.dptr = stdentryname;
  dbkey.dsize = strlen (AF_BPSTDENTRY);

  (void) sprintf (str, "%d %s %s\0", size, owner->af_username, owner->af_userhost);
  data.dptr = str;
  data.dsize = strlen (str) + sizeof (char);

#ifdef OLDDBM
  store (dbkey, data);
#else
  (void) dbm_store (db, dbkey, data, DBM_REPLACE);
#endif
  return (AF_OK);
}

/*================================================================
 * af_lookupbpentry -- see if bpentry is loaded yet
 *                     returns position in list
 *
 *================================================================*/

LOCAL af_lookupbpentry (list, hashname)
     Af_revlist *list;
     char *hashname;
{
  int i=0, j=0;

  for (; i < list->af_listlen; i++)
    {
      /* if entry is not valid */
      if (!(list->af_list[i].af_class & AF_VALID))
	continue;
      if (!strcmp (list->af_list[i].af_hashname, hashname))
	return (i);
      j++;
      if (j >= list->af_nrevs)
	return (ERROR);
    }
  FAIL ("lookupbpentry", "cannot find binary pool entry", AF_EINTERNAL, ERROR);
}

#ifdef OLDDBM
static char *bpool;
static bool bpwrite = FALSE;
#endif

/*==========================================================================
 *	af_rbplist -- read all binary pool entries
 *
 *==========================================================================*/

EXPORT Af_revlist *af_rbplist (path)
     char *path;
{
  datum  dbkey, data;
#ifndef OLDDBM
  DBM    *db;
#endif
  int    i=0, count=0;
  Af_key     entrykey;
  Af_revlist *list;
  Af_user    *owner;

  if ((list = initlist (path, AF_READ)) == (Af_revlist *)0)
    return ((Af_revlist *)0);
 
  if (list->af_extent & AF_COMPLETE)
    return (list);

#ifdef OLDDBM
  if (list->af_arfilename != bpool)
    {
      char bpfilename[MAXNAMLEN+1];
      FILE *tmpfdes;
      /* test existence of binary pool files */
      (void) sprintf (bpfilename, "%s.dir\0", list->af_arfilename);
      if (af_sysaccess (bpfilename, 0) == -1)
	{
	  if (bpwrite)
	    {
	      /* create bpool files */
	      tmpfdes = fopen (bpfilename, "w");
	      (void) fclose (tmpfdes);
	      (void) sprintf (bpfilename, "%s.pag\0", list->af_arfilename);
	      tmpfdes = fopen (bpfilename, "w");
	      (void) fclose (tmpfdes);
	    }
	  else
	    SFAIL ("rbplist", "dbm_open", AF_ENOAFSDIR, (Af_revlist *)0);
	}
      if (dbminit (list->af_arfilename) != AF_OK)
	{
	  (void) af_detbpool (list);
	  SFAIL ("rbplist", "dbm_open", AF_ENOAFSDIR, (Af_revlist *)0);
	}
      bpool = list->af_arfilename;
    }
#else
  if ((db = dbm_open (list->af_arfilename, O_RDONLY, 0664)) == (DBM *)0)
    {
      (void) af_detbpool (list);
      SFAIL ("rbplist", "dbm_open", AF_ENOAFSDIR, (Af_revlist *)0);
    }
#endif

  /* if list was empty up to now */
  if (list->af_nrevs == 0)
    {
#ifdef OLDDBM
      owner = gbpsize (&list->af_nrevs);
#else
      owner = gbpsize (db, &list->af_nrevs);
#endif
      list->af_cattrs.af_ownname = af_entersym (owner->af_username);
      list->af_cattrs.af_ownhost = af_enterhost (owner->af_userhost);
    }
  else
    /* if there are no references to the list, delete all entries and read */
    /* the whole binary pool. This is (hopefully) faster than updating */
    {
      if (list->af_refcount == 0)
	{
	  for (i = 0; i < list->af_listlen; i++)
	    {
	      if (list->af_list[i].af_class & AF_VALID)
		{
		  af_hashfree (&(list->af_list[i].af_uhtab));
		  list->af_list[i].af_class &= ~AF_VALID;
		}
	    }
	  af_frmemlist (list);
	}
    }

  i=0;
#ifdef OLDDBM
  for (dbkey = firstkey(); dbkey.dptr != NULL; dbkey = nextkey(dbkey))
#else
  for (dbkey = dbm_firstkey(db); dbkey.dptr != NULL; dbkey = dbm_nextkey(db))
#endif
    {
      if (!strncmp (dbkey.dptr, AF_BPSTDENTRY, AF_IDSTRLEN))
	continue;
      /* if there are existing references to binary pool preserve all */
      /* attribute buffers that are aleady read in and skip used places */
      if (i == list->af_listlen) /* if list is full */
	{
	  if (af_lookupbpentry (list, dbkey.dptr) != ERROR)
	    count++;
	  else /* delete all additional entries in bpool has shrunk */
	    {
#ifdef OLDDBM
	      delete (dbkey);
#else
	      (void) dbm_delete (db, dbkey);
#endif
	      (void) af_unlink (af_bpfilename (path, dbkey.dptr));
	    }
	  continue;
	}
      count++;
      if (list->af_refcount > 0)
 	{
	  while (list->af_list[i].af_class & AF_VALID)
	    i++;
	  if (af_lookupbpentry (list, dbkey.dptr) != ERROR)
	      continue;
	}
#ifdef OLDDBM
      data = fetch (dbkey);
#else
      data = dbm_fetch (db, dbkey);
#endif
      /* check if file exists. If not, ignore this entry */
      /* this check may be omitted in further releases */
      if (af_sysaccess (af_bpfilename (path, dbkey.dptr), 0) == AF_OK)
	{
	  entrykey.af_ldes = list;
	  entrykey.af_lpos = i;
	  (void) af_dbmkey (&data, &dbkey, &entrykey);
	  i++;
	}
      else
	count--;
    }

  list->af_nrevs = count;

  /* clear "incomplete" bit */
  list->af_extent |= AF_COMPLETE;

#ifndef OLDDBM
  dbm_close (db);
#endif
  return (list);
}


/*==========================================================================
 *	af_delbpentry -- delete binary pool entry
 *
 *==========================================================================*/

EXPORT af_delbpentry (key)
     Af_key *key;
{
  datum  dbkey;
#ifndef OLDDBM
  DBM    *db;
#endif
  short  listsize;
  Af_revlist *list;
  Af_user    *owner;

  if ((list = initlist (CATTR(key).af_syspath, AF_RDWR)) == (Af_revlist *)0)
    return (ERROR);

  if (key->af_ldes != list)
    FAIL ("delbpentry", "", AF_EINVKEY, ERROR);

#ifdef OLDDBM
  if (list->af_arfilename != bpool)
    {
      char bpfilename[MAXNAMLEN+1];
      FILE *tmpfdes;
      /* test existence of binary pool files */
      (void) sprintf (bpfilename, "%s.dir\0", list->af_arfilename);
      if (af_sysaccess (bpfilename, 0) == -1)
	{
	  /* create bpool files */
	  tmpfdes = fopen (bpfilename, "w");
	  (void) fclose (tmpfdes);
	  (void) sprintf (bpfilename, "%s.pag\0", list->af_arfilename);
	  tmpfdes = fopen (bpfilename, "w");
	  (void) fclose (tmpfdes);
	}
      if (dbminit (list->af_arfilename) != AF_OK)
	{
	  (void) af_detbpool (list);
	  FAIL ("delbpentry", "dbm_open", AF_ESYSERR, ERROR);
	}
      bpool = list->af_arfilename;
    }
#else
  if ((db = dbm_open (list->af_arfilename, O_RDWR|O_CREAT, 0664)) == (DBM *)0)
    {
      (void) af_detbpool (list);
      FAIL ("delbpentry", "dbm_open", AF_ESYSERR, ERROR);
    }
#endif

  dbkey.dptr = VATTR(key).af_hashname;
  dbkey.dsize = strlen (dbkey.dptr) + sizeof (char);
#ifdef OLDDBM
  delete (dbkey);
#else
  (void) dbm_delete (db, dbkey);
#endif
  (void) af_unlink (af_bpfilename (CATTR(key).af_syspath, VATTR(key).af_hashname));
#ifdef OLDDBM
  owner = gbpsize (&listsize);
#else
  owner = gbpsize (db, &listsize);
#endif
  list->af_cattrs.af_ownname = af_entersym (owner->af_username);
  list->af_cattrs.af_ownhost = af_enterhost (owner->af_userhost);
  listsize--;
  list->af_nrevs--;
#ifdef OLDDBM
  (void) pbpsize (list->af_nrevs, owner);
#else
  (void) pbpsize (db, list->af_nrevs, owner);
#endif

  /* clear "valid" bit in attribute buffer and free allocated memory */
  af_hashfree (&(VATTR(key).af_uhtab));
  VATTR(key).af_class &= ~AF_VALID;

#ifndef OLDDBM
  dbm_close (db);
#endif
  return (AF_OK);
}


/*==========================================================================
 *	af_rplbpentry -- replace binary pool entry
 *
 *==========================================================================*/

EXPORT af_rplbpentry (oldkey, newkey, bpkey)
     Af_key *oldkey, *newkey, *bpkey;
{
  datum  dbkey, data;
#ifndef OLDDBM
  DBM    *db;
#else
  datum  exdata;
#endif
  bool   add = FALSE, found = FALSE;
  short  freepos, listsize, i;
  Af_revlist *list;
  Af_user    *owner;
  time_t lastacc;
  struct timeval tvp[2];
  char   *bpname;
  int    af_fhash();

  if ((list = initlist (CATTR(newkey).af_syspath, AF_RDWR)) == (Af_revlist *)0)
    return (ERROR);

  if ((oldkey != (Af_key *)0) && (oldkey->af_ldes != list))
    FAIL ("rplbpentry", "", AF_EINVKEY, ERROR);

#ifdef OLDDBM
  if (list->af_arfilename != bpool)
    {
      char bpfilename[MAXNAMLEN+1];
      FILE *tmpfdes;
      /* test existence of binary pool files */
      (void) sprintf (bpfilename, "%s.dir\0", list->af_arfilename);
      if (af_sysaccess (bpfilename, 0) == -1)
	{
	  /* create bpool files */
	  tmpfdes = fopen (bpfilename, "w");
	  (void) fclose (tmpfdes);
	  (void) sprintf (bpfilename, "%s.pag\0", list->af_arfilename);
	  tmpfdes = fopen (bpfilename, "w");
	  (void) fclose (tmpfdes);
	}
      if (dbminit (list->af_arfilename) != AF_OK)
	{
	  (void) af_detbpool (list);
	  FAIL ("rplbpentry", "dbm_open", AF_ESYSERR, ERROR);
	}
      bpool = list->af_arfilename;
    }
#else
  if ((db = dbm_open (list->af_arfilename, O_RDWR|O_CREAT, 0664)) == (DBM *)0)
    {
      (void) af_detbpool (list);
      FAIL ("rplbpentry", "dbm_open", AF_ESYSERR, ERROR);
    }
#endif

  if (oldkey == (Af_key *)0)
    {
      /* if we actually have to "add" a file */
#ifdef OLDDBM
      owner = gbpsize (&listsize);
#else
      owner = gbpsize (db, &listsize);
#endif
      list->af_cattrs.af_ownname = af_entersym (owner->af_username);
      list->af_cattrs.af_ownhost = af_enterhost (owner->af_userhost);
      if (listsize < list->af_listlen)
	{
	  add = TRUE;
	  /* look for free attribute buffer in bplist */
	  freepos = list->af_listlen-1;
	  while ((list->af_list[freepos].af_class & AF_VALID) && (freepos >=0))
	    freepos--;
	  if (freepos == -1)
	    {
#ifndef OLDDBM	     
	      dbm_close (db);
#endif
	      FAIL ("rplbpentry", "no free entry in binary pool", AF_EINCONSIST, ERROR);
	    }
	}
      else
	{
	  /* remove the oldest (->af_atime) file */
	  /* read in whole list of bpfiles */
#ifdef OLDDBM
	  bpwrite = TRUE;
#endif
	  if ((list = af_rbplist (list->af_cattrs.af_syspath))
	      == (Af_revlist *)0)
	    return (ERROR);
#ifdef OLDDBM
	  bpwrite = FALSE;
#endif
	      
	  lastacc = (time_t)af_acttime ();
	  
	  for (i=0; i < list->af_nrevs; i++)
	    {
	      if ((!list->af_list[i].af_nlinks) && 
		  (list->af_list[i].af_atime < lastacc))
		{
		  freepos = i;
		  lastacc = list->af_list[freepos].af_atime;
		  dbkey.dptr = list->af_list[freepos].af_hashname;
		  found = TRUE;
		}
	    }

	  if (!found)
	    FAIL ("rplbpentry", "", AF_EBPFULL, ERROR);

	  dbkey.dsize = strlen (dbkey.dptr) + sizeof (char);
#ifdef OLDDBM
	  delete (dbkey);
#else
	  (void) dbm_delete (db, dbkey);
#endif
	  if (oldkey != newkey)
	    (void) af_unlink (af_bpfilename (list->af_cattrs.af_syspath, dbkey.dptr));
	}
    } /* if (oldkey == (Af_key *)0) then ... */
  else
    {
      if (oldkey != newkey)
	{
	  dbkey.dptr = VATTR(oldkey).af_hashname;
	  dbkey.dsize = strlen (dbkey.dptr) + sizeof (char);
#ifdef OLDDBM
	  delete (dbkey);
#else
	  (void) dbm_delete (db, dbkey);
#endif
	  (void) af_unlink (af_bpfilename (CATTR(oldkey).af_syspath, dbkey.dptr));
	}
      freepos = oldkey->af_lpos;
    }

  /* enter new entry */
  if (oldkey != newkey)
    {
      i = 0;
      do
	{
	  if (++i > list->af_listlen)
	    FAIL ("rplbpentry",
		  "cannot build unique hashname", AF_EINTERNAL, ERROR);
	  dbkey.dptr =
	    af_rbphashname (VATTR(newkey).af_name,VATTR(newkey).af_type,
			    VATTR(newkey).af_gen, VATTR(newkey).af_rev,
			    VATTR(newkey).af_variant, newkey->af_ldes, i);
	  dbkey.dsize = strlen (dbkey.dptr) + sizeof (char);
	  data = af_dbmstring (newkey, dbkey.dsize);
	  if (data.dptr == (char *)0)
	    return (ERROR);
#ifdef OLDDBM
	  exdata = fetch (dbkey);
#endif
	}
      /* as long as key is not unique, try another one */
#ifdef OLDDBM
      while (exdata.dptr);
      store (dbkey, data);
#else
      while (dbm_store (db, dbkey, data, DBM_INSERT));
#endif
      
      VATTR(newkey).af_hashname = dbkey.dptr;

      /*** copy file ***/
      bpname = af_bpfilename (CATTR(newkey).af_syspath, VATTR(newkey).af_hashname);
      if (af_cpfile (newkey->af_ldes->af_busyfilename, VATTR(newkey).af_fsize, bpname) == ERROR)
	FAIL ("rplbpentry", "cpfile", AF_ESYSERR, ERROR);
      /*** set modification and access date (not necessary) ***/
      tvp[0].tv_sec = VATTR(newkey).af_atime;
      tvp[0].tv_usec = 0; 
      tvp[1].tv_sec = VATTR(newkey).af_mtime;
      tvp[1].tv_usec = 0;
      if (utimes (bpname, tvp) == ERROR)
	FAIL ("rplbpentry", "utimes", AF_ESYSERR, ERROR);
      (void) af_uchmod (bpname, (int) VATTR(newkey).af_mode);
    }
  else
    {
      dbkey.dptr = VATTR(newkey).af_hashname;
      dbkey.dsize = strlen (dbkey.dptr) + sizeof (char);
      data = af_dbmstring (newkey, dbkey.dsize);
      if (data.dptr == (char *)0)
	return (ERROR);
#ifdef OLDDBM
      store (dbkey, data);
#else
      (void) dbm_store (db, dbkey, data, DBM_REPLACE);
#endif
    }

  /* build key for new entry */
  bpkey->af_ldes = list;
  bpkey->af_lpos = freepos;

  if (oldkey != newkey)
    {
      /* copy attribute buffers */
      VATTR(bpkey) = VATTR(newkey);
      /* copy hash table */
      (void) af_hashinit (&(VATTR(newkey).af_uhtab), AF_MAXUDAS, af_fhash);
      (void) af_hashcopy (&(VATTR(bpkey).af_uhtab), &(VATTR(newkey).af_uhtab));
    }

  /* if an "add" was performed -- update bplist in database */
  if (add)
    {
      listsize++;
      list->af_nrevs++;
#ifdef OLDDBM
      (void) pbpsize (list->af_nrevs, owner);
#else
      (void) pbpsize (db, list->af_nrevs, owner);
#endif
    }
  
#ifndef OLDDBM
  dbm_close (db);
#endif
  return (AF_OK);
} /* af_rplbpentry */


/*==========================================================================
 *	af_isbpfile
 *
 *==========================================================================*/

EXPORT af_isbpfile (name)
     char *name;
{
  return (!strncmp (name, AF_BPFILEID, AF_IDSTRLEN));
}



/*==========================================================================
 *	af_detbpool
 *
 *==========================================================================*/

EXPORT af_detbpool (list)
     Af_revlist *list;
{
  register int i;
  Af_revlist *tmplist;

  /* if first list descriptor should be deleted - the base (af_lists) */
  /* has to be preserved */
  if (list == bplists)
    bplists = bplists->af_next;
  else
    {
      /* if archive list has more than one entry -- close gap in list */
      if ((tmplist = bplists) != (Af_revlist *)0)
	{
	  while (tmplist->af_next != list)
	    if ((tmplist = tmplist->af_next) == (Af_revlist *)0)
	      FAIL ("detbpool", "binary pool lost", AF_EINTERNAL, ERROR);
	  tmplist->af_next = list->af_next;
	}
    }

  /* remove list from hash table */
  (void) af_delsym (&bphash, list->af_cattrs.af_syspath, list);

  /* hang free entry at the beginning of freelist */
  list->af_next = bpfreelist;
  bpfreelist = list;

  /* free all allocated memory */
  for (i = 0; i < list->af_listlen; i++)
    {
      if (list->af_list[i].af_class & AF_VALID)
	af_hashfree (&(list->af_list[i].af_uhtab));
    }
  af_frmemlist (list);

  return (AF_OK);
}

