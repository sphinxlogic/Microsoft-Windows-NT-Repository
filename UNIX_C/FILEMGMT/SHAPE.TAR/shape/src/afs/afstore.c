/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*
 *	Shape/AFS
 *
 *	afstore.c -- interface to archives and binary pools
 *
 *	Author: Andreas Lampen, TU-Berlin (andy@coma.UUCP)
 *					  (andy@db0tui62.BITNET)
 *
 *	$Header: afstore.c[1.5] Wed Feb 22 16:28:15 1989 andy@coma published $
 *
 *	EXPORT:
 *      af_bldfile -- build file containing data of version 
 *      af_newvers -- get attribute buffer for new version
 *      af_delvers -- delete version
 *      af_addvers -- add version
 *      af_updtvers -- update attribute buffer of version
 *      af_detlist -- detach archive or binary pool
 */

#include <stdio.h>
#include <string.h>
#ifdef SUNOS_4_0
#include <strings.h>
#endif
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "typeconv.h"
#include "afsys.h"
#include "afs.h"
#include "afarchive.h"

/*=========================================================================
 * af_arlock -- lock archive
 *
 *=========================================================================*/

LOCAL af_arlock (list)
     Af_revlist *list;
{
  struct stat ibuf;
  char lckfilename [MAXNAMLEN*4];
  FILE *lckfd;

  if (stat (list->af_arfilename, &ibuf) == ERROR) /* no archive file present */
    {
      /* if there should be an archive file */
      if (list->af_lastmod != (time_t) 0)
	FAIL ("arlock", "archive file lost", AF_EINTERNAL, ERROR);
    }
  else
    {
      /* if archive has changed since last read */
      if (list->af_lastmod != (time_t) af_cvttime (ibuf.st_mtime))
	FAIL ("arlock", "", AF_EARCHANGED, ERROR);
    }

  (void) strcpy (lckfilename, list->af_arfilename);
  lckfilename [strlen (lckfilename) - sizeof (char)] = AF_LCKEXT;
  if (stat (lckfilename, &ibuf) == ERROR) /* no lock file present */
    {
      /* create lockfile */
      if ((lckfd = fopen (lckfilename, "w")) == (FILE *)0)
	SFAIL ("arlock", "fopen (lockfile)", AF_ESYSERR, ERROR);
      (void) fclose (lckfd);
      af_reglckfile (lckfilename);
      return (AF_OK);
    }

  sleep (AF_LOCKTIMEOUT);
  
  if (stat (lckfilename, &ibuf) == ERROR) /* no lock file present */
    {
      if ((lckfd = fopen (lckfilename, "w")) == (FILE *)0)
	SFAIL ("arlock", "fopen (lockfile)", AF_ESYSERR, ERROR);
      (void) fclose (lckfd);
      af_reglckfile (lckfilename);
      return (AF_OK);
    }
  else
    FAIL ("arlock", "", AF_EARLOCKED, ERROR);
}

/*=========================================================================
 * af_arunlock -- unlock archive
 *
 *=========================================================================*/

LOCAL af_arunlock (list)
     Af_revlist *list;
{
  char lckfilename [MAXNAMLEN*4];
  struct stat ibuf;

  (void) strcpy (lckfilename, list->af_arfilename);
  lckfilename [strlen (lckfilename) - sizeof (char)] = AF_LCKEXT;

  /* update list descriptor */
  if (stat (list->af_arfilename, &ibuf) != ERROR)
    list->af_lastmod = (time_t) af_cvttime (ibuf.st_mtime);

  if (af_unlink (lckfilename) == ERROR)
    FAIL ("af_arunlock", "lock file lost", AF_EINTERNAL, ERROR);
  return (AF_OK);
}

/*=========================================================================
 * af_bldfile
 *
 *=========================================================================*/

EXPORT af_bldfile (key, name)
     Af_key *key;
     char   *name;
{
  struct timeval tvp[2];

  if (key->af_ldes->af_extent & AF_BPOOL)
    {
      /* get file from binary pool */
      if (af_cpfile (af_bpfilename (CATTR(key).af_syspath, VATTR(key).af_hashname), VATTR(key).af_fsize, name) == ERROR)
	FAIL ("bldfile", "cpfile", AF_ESYSERR, ERROR);
      /*** set modification and access date ***/
      tvp[0].tv_sec = VATTR(key).af_atime;
      tvp[0].tv_usec = 0; 
      tvp[1].tv_sec = VATTR(key).af_mtime;
      tvp[1].tv_usec = 0;
      if (utimes (name, tvp) == ERROR)
	FAIL ("bldfile", "utimes", AF_ESYSERR, ERROR);
      (void) af_uchmod (name, (int) VATTR(key).af_mode);
    }
  else
    {
      /* get data from archive file */
      if (af_readdata (key->af_ldes) == ERROR)
	return (ERROR);
      
      if (af_undodelta (key, name) == ERROR)
	return (ERROR);
    }
  return (AF_OK);
}


/*=========================================================================
 * af_newvers
 *
 *=========================================================================*/

EXPORT af_newvers (list, key, mode)
     Af_revlist *list;
     Af_key     *key;
     int        mode;
{
  if (mode != AF_SOURCE)
    FAIL ("newvers", "invalid mode", AF_EINTERNAL, ERROR);

  key->af_ldes = list;
  /* if revision list is full */
  if ((key->af_lpos = af_gfreepos (list)) == ERROR)
    FAIL ("newvers", "too many new revisions", AF_EINTERNAL, ERROR);
  
  /* get data from archive */
  if (af_readdata (list) == ERROR)
    return (ERROR);

  return (AF_OK);
}
  


/*=========================================================================
 * af_delvers -- delete version
 *
 *=========================================================================*/

EXPORT af_delvers (key)
     Af_key *key;
{
  char *busyname;

  /* if key points to a file in a binary pool */
  if (key->af_ldes->af_extent & AF_BPOOL)
    return (af_delbpentry (key));

  /* if "key" points to a busy version */
  if (af_arlock (key->af_ldes) == ERROR)
    return (ERROR);

  if (VATTR(key).af_state == AF_BUSY)
    {
      VATTR(key).af_predgen = AF_NOVNUM;
      VATTR(key).af_predrev = AF_NOVNUM;
      VATTR(key).af_lckname = (char *)0;
      VATTR(key).af_lckhost = (char *)0;
      VATTR(key).af_ltime = AF_NOTIME;
      /* remove busy file */
      busyname = af_gbusname (CATTR(key).af_syspath, VATTR(key).af_name, VATTR(key).af_type);
      (void) af_unlink (busyname);
      af_hashfree (&(VATTR(key).af_uhtab));
    }
  else
    /* remove delta */
    {
      /* read data section of archive */
      if (af_readdata (key->af_ldes) == ERROR)
	return (ERROR);
      
      key->af_ldes->af_datasize -= VATTR(key).af_notesize;
      if (VATTR(key).af_repr == AF_DELTA)
	key->af_ldes->af_datasize -= VATTR(key).af_dsize;
      else
	key->af_ldes->af_datasize -= VATTR(key).af_fsize;

      (void) af_rmdelta (key);
    }

  /* clear "valid" bit */
  VATTR(key).af_class &= ~AF_VALID;

  key->af_ldes->af_nrevs--;

  if (af_writearchive (key->af_ldes) == ERROR)
    {
      (void) af_arunlock (key->af_ldes);
      return (ERROR);
    }
  else
    return (af_arunlock (key->af_ldes));
}

/*=========================================================================
 * af_addvers -- add version
 *
 *=========================================================================*/

EXPORT af_addvers (key)
     Af_key *key;
{
  /* this function should only be used for archives (not for bpools */
  /* I know, it is not very well-designed but ... */
  if (key->af_ldes->af_extent & AF_BPOOL)
    FAIL ("addvers", "cannot apply on binary pools", AF_EINTERNAL, ERROR);
  if (af_arlock (key->af_ldes) == ERROR)
    return (ERROR); 
  if (af_writearchive (key->af_ldes) == ERROR)
    {
      (void) af_arunlock (key->af_ldes);
      return (ERROR);
    }
  else
    return (af_arunlock (key->af_ldes));
}

/*=========================================================================
 * af_updtvers -- update attribute buffer of version
 *
 *=========================================================================*/

EXPORT af_updtvers (key, mode)
     Af_key *key;
     int    mode;
{
  if (mode & (AF_ALLVERS | AF_CHANGE))
    {
      /* update time of last status change (ctime) for all versions */
      /* not yet implemented (update ctime) */
    }
  else 
    {
      if (mode & AF_CHANGE) /* update ctime only for this version */
	VATTR(key).af_ctime = (time_t) af_acttime ();
    }

  if (key->af_ldes->af_extent & AF_BPOOL)
    return (af_rplbpentry (key, key, key));
  else
    {
      if (af_arlock (key->af_ldes) == ERROR)
	return (ERROR); 
      if (af_writearchive (key->af_ldes) == ERROR)
	{
	  (void) af_arunlock (key->af_ldes);
	  return (ERROR);
	}
      else
	return (af_arunlock (key->af_ldes));
    }
}

/*=========================================================================
 * af_detlist -- detach archive or binary pool
 *
 *=========================================================================*/

EXPORT af_detlist (list)
     Af_revlist *list;
{
  if (list->af_extent & AF_BPOOL)
    return (af_detbpool (list));
  else
    return (af_detarchive (list));
}

