/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*LINTLIBRARY*/
/*
 *	Shape/AFS
 *
 *	afversions.c - operations on revisions
 *
 *	Author: Andreas Lampen, TU-Berlin (andy@coma.UUCP
 *					   andy@db0tui62.BITNET)
 *
 *	$Header: afvers.c[1.3] Wed Feb 22 16:28:25 1989 andy@coma published $
 *
 *	EXPORT:
 *	af_savebinary -- save derived file
 *	af_saverev -- save busy version
 *	af_newgen -- increase gen number and reset rev number
 *	af_setbusy -- set revision busy
 *	af_svnum -- set version number
 */

#include <stdio.h>
#include <string.h>
#ifdef SUNOS_4_0
#include <strings.h>
#endif
#include <sys/types.h>
#include <sys/stat.h>

#include "typeconv.h"
#include "afsys.h"
#include "afs.h"

/*====================================================================
 *    af_savebinary
 *
 *====================================================================*/

EXPORT af_savebinary (busykey, savekey)
     Af_key *busykey;
     Af_key *savekey; /* out */
{
  int    oldpredgen, oldpredrev;
  short  oldnlinks;
  time_t oldatime;

  if (af_keytest (busykey))
    SFAIL ("savebinary", "", AF_EINVKEY, ERROR);
  
  if (VATTR(busykey).af_state != AF_BUSY)
    SFAIL ("savebinary", "", AF_ENOTBUSY, ERROR);

  if ((VATTR(busykey).af_mode & S_IFMT) != S_IFREG)
    SFAIL ("savebinary", "", AF_ENOTREGULAR, ERROR);

  if (VATTR(busykey).af_nlinks > 1)
    af_wng ("savebinary", "busykey has more than one reference");

  if (af_checkperm (busykey, AF_WORLD) == ERROR)
    return (ERROR);

  /* this then part is a little bit "hacked", it should better look like:
   * 
   * get key for new bp entry
   * modify attributes
   * add new file to binary pool
   */
  
  /* modify some attributes for saving */
  VATTR(busykey).af_state = AF_NOSTATE;
  VATTR(busykey).af_class |= AF_DERIVED;
  oldatime = VATTR(busykey).af_atime;
  VATTR(busykey).af_atime = (time_t) af_acttime ();
  oldpredgen = VATTR(busykey).af_predgen;
  VATTR(busykey).af_predgen = AF_NOVNUM;
  oldpredrev = VATTR(busykey).af_predrev;
  VATTR(busykey).af_predrev = AF_NOVNUM;
  oldnlinks = VATTR(busykey).af_nlinks;
  VATTR(busykey).af_nlinks = 1;
  
  if (af_rplbpentry ((Af_key *)0, busykey, savekey) == ERROR)
    return (ERROR);

  /* restore attributes */
  VATTR(busykey).af_state = AF_BUSY;
  VATTR(busykey).af_class &= ~AF_DERIVED;
  VATTR(busykey).af_atime = oldatime;
  VATTR(busykey).af_predgen = oldpredgen;
  VATTR(busykey).af_predrev = oldpredrev;
  VATTR(busykey).af_nlinks = oldnlinks;

  /* update binary pool descriptor */
  savekey->af_ldes->af_refcount++;
  
  return (AF_OK);
}


/*====================================================================
 *    af_saverev
 *
 *====================================================================*/

EXPORT af_saverev (busykey, savekey)

     Af_key *busykey;
     Af_key *savekey; /* out */
{
  Af_key *lastkey, predkey, *af_glastkey();
  Af_user *author;
  struct stat ibuf;
  int af_fhash();
  
  if (af_keytest (busykey))
    SFAIL ("saverev", "", AF_EINVKEY, ERROR);
  
  if (VATTR(busykey).af_state != AF_BUSY)
    SFAIL ("saverev", "", AF_ENOTBUSY, ERROR);

  if ((VATTR(busykey).af_mode & S_IFMT) != S_IFREG)
    SFAIL ("saverev", "", AF_ENOTREGULAR, ERROR);

  if (af_checkperm (busykey, AF_LOCKHOLDER) == ERROR)
    SFAIL ("saverev", "", AF_ENOTLOCKED, ERROR);

  /* get attribute buffer (pointed to by "savekey") for new version */
  if (af_newvers (busykey->af_ldes, savekey, AF_SOURCE) == ERROR)
    return (ERROR);

  /* set key and attributes of new version */
  VATTR(savekey).af_name = VATTR(busykey).af_name;
  VATTR(savekey).af_type = VATTR(busykey).af_type;
  VATTR(savekey).af_lckname = VATTR(busykey).af_lckname;
  VATTR(savekey).af_lckhost = VATTR(busykey).af_lckhost;
  VATTR(savekey).af_ltime = (time_t) af_acttime ();
  
  /* if there is only one (the busy-) revision (..nrevs == 1) */
     /* then do initial save */
  if (busykey->af_ldes->af_nrevs == 1)
    {
      VATTR(savekey).af_gen = AF_INITGEN;
      VATTR(savekey).af_rev = AF_INITREV;
      VATTR(savekey).af_predgen = AF_NOVNUM;
      VATTR(savekey).af_predrev = AF_NOVNUM;
      VATTR(busykey).af_predgen = AF_INITGEN;
      VATTR(busykey).af_predrev = AF_INITREV;
      (void) af_nodelta (busykey, savekey);
    }
  else /* get some attributes from preceding revision */
    {
      lastkey = af_glastkey (busykey->af_ldes);
      VATTR(savekey).af_gen = VATTR(lastkey).af_gen; 
      VATTR(savekey).af_rev = VATTR(lastkey).af_rev+1;
      VATTR(savekey).af_predgen = VATTR(busykey).af_predgen;
      VATTR(savekey).af_predrev = VATTR(busykey).af_predrev;
      VATTR(busykey).af_predgen = VATTR(savekey).af_gen;
      VATTR(busykey).af_predrev = VATTR(savekey).af_rev;
      if (af_buildkey (busykey->af_ldes, VATTR(savekey).af_predgen, VATTR(savekey).af_predrev, &predkey) == ERROR)
	predkey.af_ldes = (Af_revlist *)0;
      (void) af_dodelta (busykey, &predkey, savekey);
    }

  if (VATTR(busykey).af_variant)
    VATTR(savekey).af_variant = VATTR(busykey).af_variant;
  else
    VATTR(savekey).af_variant = (char *)0;

  VATTR(savekey).af_state = AF_SAVED;
  VATTR(savekey).af_class = VATTR(busykey).af_class;
  author = af_getuser (getuid());
  VATTR(savekey).af_auname = af_entersym (author->af_username);
  VATTR(savekey).af_auhost = af_enterhost (author->af_userhost);
  (void) lstat (busykey->af_ldes->af_busyfilename, &ibuf);	
  VATTR(savekey).af_mode = ibuf.st_mode;
  VATTR(savekey).af_mtime = (time_t) af_cvttime (ibuf.st_mtime);
  VATTR(savekey).af_atime = (time_t) af_acttime ();
  VATTR(savekey).af_ctime = (time_t) af_cvttime (ibuf.st_mtime);
  VATTR(savekey).af_stime = (time_t) af_acttime ();
  VATTR(savekey).af_notesize = 1;
  VATTR(savekey).af_note = (char *)0;
  VATTR(savekey).af_nlinks = 1;

  VATTR(savekey).af_udanum = VATTR(busykey).af_udanum;
  (void) af_hashinit (&(VATTR(savekey).af_uhtab), AF_MAXUDAS, af_fhash);
  (void) af_hashcopy (&(VATTR(busykey).af_uhtab), &(VATTR(savekey).af_uhtab));
  
  VATTR(savekey).af_hashname = (char *)0;
  VATTR(savekey).af_succgen = AF_NOVNUM;
  VATTR(savekey).af_succrev = AF_NOVNUM;
  
  /* update list descriptor */
  busykey->af_ldes->af_nrevs++;
  busykey->af_ldes->af_datasize += VATTR(savekey).af_notesize;
  busykey->af_ldes->af_refcount++;
  
  /* save changes */
  if (af_addvers (savekey) == ERROR)
    return (ERROR);
  
  return (AF_OK);
} /* af_saverev */



/*====================================================================
 *    af_newgen
 *
 *====================================================================*/

EXPORT af_newgen (key, newkey)
     Af_key *key;
     Af_key *newkey; /* out */
{
  Af_key *lastkey, *busykey, *af_gbuskey(), *af_glastkey();
  int    af_fhash();

  if (af_keytest (key))
    SFAIL ("newgen", "", AF_EINVKEY, ERROR);

  if (key->af_ldes->af_nrevs == 1)
    SFAIL ("newgen", "", AF_ENOTVERS, ERROR);

  if (VATTR(key).af_class & AF_DERIVED)
    SFAIL ("newgen", "", AF_EDERIVED, ERROR);

  if ((VATTR(key).af_mode & S_IFMT) != S_IFREG)
    SFAIL ("newgen", "", AF_ENOTREGULAR, ERROR);

  busykey = af_gbuskey (key->af_ldes);
  if (af_checkperm (busykey, AF_LOCKHOLDER) == ERROR)
    SFAIL ("newgen", "", AF_ENOTLOCKED, ERROR);

  if (af_newvers (key->af_ldes, newkey, AF_SOURCE) == ERROR)
    return (ERROR);

  lastkey = af_glastkey (key->af_ldes);

  if ((VATTR(key).af_predgen == VATTR(lastkey).af_gen) && 
      (VATTR(key).af_predrev == VATTR(lastkey).af_rev))
    {
      VATTR(key).af_predgen++;
      VATTR(key).af_predrev = 0;
    }

  /* duplicate last revision */

  VATTR(newkey).af_gen = VATTR(lastkey).af_gen+1; 
  VATTR(newkey).af_rev = 0;
  VATTR(newkey).af_variant = VATTR(lastkey).af_variant;
  VATTR(newkey).af_predgen = VATTR(lastkey).af_gen;
  VATTR(newkey).af_predrev = VATTR(lastkey).af_rev;

  (void) af_dodelta ((Af_key *)0, lastkey, newkey);

  VATTR(newkey).af_name = VATTR(lastkey).af_name;
  VATTR(newkey).af_type = VATTR(lastkey).af_type;
  VATTR(newkey).af_variant = VATTR(lastkey).af_variant;
  VATTR(newkey).af_state = VATTR(lastkey).af_state;
  VATTR(newkey).af_class = VATTR(lastkey).af_class;
  VATTR(newkey).af_auname = VATTR(lastkey).af_auname;
  VATTR(newkey).af_auhost = VATTR(lastkey).af_auhost;
  VATTR(newkey).af_mode = VATTR(lastkey).af_mode;
  VATTR(newkey).af_mtime = VATTR(lastkey).af_mtime;
  VATTR(newkey).af_atime = VATTR(lastkey).af_atime;
  VATTR(newkey).af_ctime = VATTR(lastkey).af_ctime;
  VATTR(newkey).af_stime = VATTR(lastkey).af_stime;
  VATTR(newkey).af_notesize = VATTR(lastkey).af_notesize;
  VATTR(newkey).af_note = VATTR(lastkey).af_note;
  VATTR(newkey).af_lckname = (char *)0;
  VATTR(newkey).af_lckhost = (char *)0;
  VATTR(newkey).af_nlinks = 1;

  VATTR(newkey).af_udanum = VATTR(lastkey).af_udanum;
  (void) af_hashinit (&(VATTR(newkey).af_uhtab), AF_MAXUDAS, af_fhash);
  (void) af_hashcopy (&(VATTR(lastkey).af_uhtab), &(VATTR(newkey).af_uhtab));

  VATTR(newkey).af_succgen = AF_NOVNUM;
  VATTR(newkey).af_succrev = AF_NOVNUM;

  /* update list descriptor */
  key->af_ldes->af_nrevs++;
  key->af_ldes->af_datasize += VATTR(newkey).af_notesize;

  /* update predecessor of busy version */
  if  ((VATTR(busykey).af_predgen == VATTR(lastkey).af_gen) && 
       (VATTR(busykey).af_predrev == VATTR(lastkey).af_rev))
    {
      VATTR(busykey).af_predgen = VATTR(newkey).af_gen;
      VATTR(busykey).af_predrev = VATTR(newkey).af_rev;
    }

  if (af_addvers (newkey) == ERROR)
    return (ERROR);

  key->af_ldes->af_refcount++;
  return (AF_OK);
}


/*====================================================================
 *    af_setbusy
 *
 *====================================================================*/

EXPORT af_setbusy (busykey, newkey)
     Af_key *busykey, *newkey;
{
  Af_key *af_gbuskey();

  if (af_keytest (newkey))
    SFAIL ("setbusy", "", AF_EINVKEY, ERROR);

  if (busykey != (Af_key *)0)
    {
      if (af_keytest (busykey))
	SFAIL ("setbusy", "", AF_EINVKEY, ERROR);
      if (VATTR(busykey).af_state != AF_BUSY)
	SFAIL ("setbusy", "", AF_ENOTBUSY, ERROR);
      if (VATTR(busykey).af_class & AF_DERIVED)
	SFAIL ("setbusy", "", AF_EDERIVED, ERROR);
    }
  else
    {
      busykey = af_gbuskey (newkey->af_ldes);
    }

  if (af_checkperm (busykey, AF_LOCKHOLDER) == ERROR)
    SFAIL ("setbusy", "", AF_ENOTLOCKED, ERROR);

  /* if the two versions belong to one line of development */
  if (busykey->af_ldes->af_busyfilename == newkey->af_ldes->af_busyfilename)
    {
      VATTR(busykey).af_predgen = VATTR(newkey).af_gen;
      VATTR(busykey).af_predrev = VATTR(newkey).af_rev;
    }
  else
    {
      VATTR(busykey).af_predgen = AF_NOVNUM;
      VATTR(busykey).af_predrev = AF_NOVNUM;
    }
  if (af_updtvers (busykey, AF_CHANGE) == ERROR)
    return (ERROR);

  return (AF_OK);
}


/*====================================================================
 *    af_svnum
 *
 *====================================================================*/

EXPORT af_svnum (key, gen, rev)
     Af_key *key;
     int gen, rev;
{
  Af_key predkey, *lastkey, *af_glastkey();

  if (af_keytest (key))
    SFAIL ("svnum", "", AF_EINVKEY, ERROR);

  if ((VATTR(key).af_state == AF_BUSY) || (VATTR(key).af_state > AF_PROPOSED))
    SFAIL ("svnum", "", AF_EWRONGSTATE, ERROR);

  if (!(VATTR(key).af_class & AF_DERIVED)) /* derived files can get any vnum */
    {
      if (af_checkperm (key, AF_LOCKHOLDER) == ERROR)
	SFAIL ("svnum", "", AF_ENOTLOCKED, ERROR);

      /* only the version number of the last saved version can be modified */
      lastkey = af_glastkey (key->af_ldes);
      if (af_keycmp (key, lastkey))
	SFAIL ("svnum", "can set version number only for last saved version",
	       AF_EMISC, ERROR);

      /* if new version number is smaller than the old one */
      if (gen < VATTR(key).af_gen)
	SFAIL ("svnum", "", AF_EINVVNUM, ERROR);
      if (gen == VATTR(key).af_gen)
	{
	  if (rev < VATTR(key).af_rev)
	    SFAIL ("svnum", "", AF_EINVVNUM, ERROR);
	}
      /* read data file in order to get it updated */
      if (af_readdata (key->af_ldes) == ERROR)
	return (ERROR);
    }

  VATTR(key).af_gen = (short)gen;
  VATTR(key).af_rev = (short)rev;

  /* if a predecessor exists, update its successor field */
  if (af_buildkey (key->af_ldes, VATTR(key).af_predgen,
		   VATTR(key).af_predrev, &predkey) == AF_OK)
    {
      VATTR((&predkey)).af_succgen = (short)gen;
      VATTR((&predkey)).af_succrev = (short)rev;
    }

  /* the predecessor is updated implicitely by af_updtvers (key) */
  if (af_updtvers (key, AF_CHANGE) == ERROR)
    return (ERROR);

  return (AF_OK);
}

