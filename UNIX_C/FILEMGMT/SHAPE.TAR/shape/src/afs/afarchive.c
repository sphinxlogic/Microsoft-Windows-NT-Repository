/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*
 *	Shape/AFS
 *
 *	afarchive.c -- read/write archives of attribute filesystem
 *
 *	Author: Andreas Lampen, TU-Berlin (andy@coma.UUCP)
 *					  (andy@db0tui62.BITNET)
 *
 *	$Header: afarchive.c[1.6] Wed Feb 22 16:27:01 1989 andy@coma published $
 *
 *	EXPORT:
 *	af_detarchive -- free descriptor for archive
 *      af_readdata -- read data from archive
 *	af_readattrs -- read attributes from archive
 *	af_writearchive -- write it
 */

#include <stdio.h>
#include <string.h>
#ifdef SUNOS_4_0
#include <strings.h>
#endif
#include <sys/types.h>
#include <sys/stat.h>

#include "typeconv.h"
#include "afsys.h"
#include "afs.h"
#include "afarchive.h"

#ifdef MEMDEBUG
extern FILE *memprot;
#endif

int     af_fhash();
Uid_t   getuid();

/*==========================================================================
 * List of list-descriptors + hash table for faster access
 *
 * Allocated memory will never be freed up to now
 *
 *==========================================================================*/

/* these two pointers should be local -- EXPORT only for debugging */
LOCAL Af_revlist lst;
EXPORT Af_revlist *af_lists = (Af_revlist *)0;  
                                    /* base address of all list descriptors */

EXPORT Af_revlist *af_freelist = &lst;  /* beginning of freelist */

LOCAL Af_hash af_arhash;
bool  hinit = FALSE; /* indicate if hashtable is yet initialized */

/*======================== init_ldes =======================================*/

LOCAL Af_revlist *init_ldes (path, name, type)
     char *path, *name, *type;
{
  register   i;
  Af_revlist *list, *oldlist, **oldptr, *tail;
  char       hashsymbol[MAXNAMLEN], *malloc(), *pathsym;

  oldptr = &oldlist;
  /* init hashtable if it is not yet done */
  if (!hinit)
    {
      (void) af_hashinit (&af_arhash, AF_MAXLISTS, af_fhash);
      hinit = TRUE;
    }

  pathsym = af_entersym (path);

  (void) strcpy (hashsymbol, name);
  if (type)
    if (type[0])
      {
	(void) strcat (hashsymbol, ".");
	(void) strcat (hashsymbol, type);
      }
    
  /* if there are open archives check if desired archive is loaded yet */
  if (af_lists != (Af_revlist *)0)
    {
      if (af_symlookup (&af_arhash, hashsymbol, (Af_revlist *)0, oldptr))
	{
	  /* found something */
	  /* if it is the right list */
	  if (oldlist->af_cattrs.af_syspath == pathsym)
	    return (oldlist);
	  /* else continue the search as long as there are entries */
	  while (af_symlookup (&af_arhash, hashsymbol, oldlist, oldptr))
	    {
	      if (oldlist->af_cattrs.af_syspath == pathsym)
		return (oldlist);
	    }
	}
    }

  /* if there are no more descriptors available - allocate new space */
  if (af_freelist == (Af_revlist *)0)
    {
      if ((af_freelist = (Af_revlist *) malloc ((unsigned) (AF_LISTSEG * sizeof (Af_revlist)))) == (Af_revlist *)0)
	FAIL ("readattrs", "malloc(i)", AF_ESYSERR, (Af_revlist *)0);

      /* build up new freelist */
      for (i=1; i<AF_LISTSEG; i++)
	af_freelist[i-1].af_next = &(af_freelist[i]);
      af_freelist[AF_LISTSEG-1].af_next = (Af_revlist *)0;
    }

  if (af_lists != (Af_revlist *)0)
    {
      tail = af_lists->af_next;
      af_lists->af_next = af_freelist;
      af_freelist = af_freelist->af_next;
      list = af_lists->af_next;
      bzero ((char *)list, sizeof (*list));

      list->af_next = tail;
    }
  else
    {
      list = af_freelist;
      af_freelist = af_freelist->af_next;
      /* initialize whole struct (i.e. set af_next to "nil") */
      bzero ((char *)list, sizeof (*list));
      af_lists = list;
    }

  list->af_mem = (char *)0;
  list->af_cattrs.af_host = af_gethostname ();
  list->af_cattrs.af_syspath = pathsym;
  list->af_lastmod = (time_t) 0;

  /* add list to hashtable */
  (void) af_hashsym (&af_arhash, hashsymbol, list);
#ifdef MEMDEBUG
  fprintf (memprot, "InitArch (%s)\n", hashsymbol);
#endif

  return (list);
}


/*==========================================================================
 *	af_detarchive -- free descriptor for archive
 *
 *
 *==========================================================================*/

EXPORT af_detarchive (archive)
     Af_revlist *archive;
{
  register int i;
  Af_revlist *list;
  char hashsymbol[MAXNAMLEN], *type;

  /* if first list descriptor should be deleted - the base (af_lists) */
  /* has to be preserved */
  if (archive == af_lists)
    af_lists = af_lists->af_next;
  else
    {
      /* if archive list has more than one entry -- close gap in list */
      if ((list = af_lists) != (Af_revlist *)0)
	{
	  while (list->af_next != archive)
	    if ((list = list->af_next) == (Af_revlist *)0)
	      FAIL ("detarchive", "archive lost", AF_EINTERNAL, ERROR);
	  list->af_next = archive->af_next;
	}
    }

  /* remove list from hash table */
  type = af_aftype (archive->af_arfilename);
  (void) strcpy (hashsymbol, af_afname (archive->af_arfilename));
  if (type)
    if (type[0])
      {
	(void) strcat (hashsymbol, ".");
	(void) strcat (hashsymbol, type);
      }
  (void) af_delsym (&af_arhash, hashsymbol, archive);

  /* hang free entry at the beginning of freelist */
  archive->af_next = af_freelist;
  af_freelist = archive;

  /* free all allocated memory */
  for (i=0; i<archive->af_listlen; i++)
    {
      if (archive->af_list[i].af_class & AF_VALID)
	af_hashfree (&(archive->af_list[i].af_uhtab));
    }
  af_frmemlist (archive);

  return (AF_OK);
}

/*==========================================================================
 *	firstitem, nextitem -- isolate items in input line
 *==========================================================================*/

LOCAL char *firstitem (line)
     char *line;
{
  char *sptr;

  /* skip leading blank */
  if ((sptr = index (&line[1], ' ')) == (char *)0)
    sptr = index (&line[1], '\n');

  *sptr = '\0';
  return (&line[1]);
}

LOCAL char *nextitem (line)
     char *line;
{
  char *sptr, *finptr;

  sptr = &line[strlen(line)]+1; /* move to next entry */
  if ((finptr = index (sptr, ' ')) == (char *)0)
    finptr = index (sptr, '\n');
  *finptr = '\0';

  return (sptr);
}
  
/*======================= rddata ====================================*/

LOCAL af_rddata (file, dbuf, list)
     FILE   *file;
     char   *dbuf;
     Af_revlist *list;
{
  char	idstr[AF_IDSTRLEN+1], *itemptr, line[AF_LINESIZ];
  int   i, gen, rev, maxindex;
  off_t	size, dpos = 0;

  /* if there is a valid busy version */
  if (list->af_list[0].af_class & AF_VALID)
    maxindex = list->af_nrevs;
  else
    maxindex = list->af_nrevs+1;

  idstr[AF_IDSTRLEN] = '\0';
  /* skip busy version */
  for (i=1; i < maxindex; i++)
    {
      (void) fgets (idstr, AF_IDSTRLEN+1, file);
      if (strcmp (idstr, AF_NOTEID))
	FAIL ("rddata", "wrong note-ID in datafile", AF_EINCONSIST, ERROR);
      (void) fgets (line, AF_LINESIZ, file);
      itemptr = firstitem (line);
      gen = atoi (itemptr);
      itemptr = nextitem (itemptr);
      rev = atoi (itemptr);
      itemptr = nextitem (itemptr);
      size = (off_t) atoi (itemptr);

      if ((list->af_list[i].af_gen != gen) || (list->af_list[i].af_rev != rev))
	FAIL ("rddata", "wrong version in datafile", AF_EINCONSIST, ERROR);

      /* read note */
      (void) fread (&(dbuf[dpos]), sizeof(char), (Size_t) size, file);
      list->af_list[i].af_notesize = size;
      list->af_list[i].af_note = &(dbuf[dpos]);
      /* replace newline by nullbyte */
      list->af_list[i].af_note[size-sizeof(char)] = '\0';
      dpos = dpos+size;

      (void) fgets (idstr, AF_IDSTRLEN+1, file);
      if (strcmp (idstr, AF_DATAID))
	FAIL ("rddata", "wrong data-ID in datafile", AF_EINCONSIST, ERROR);
      (void) fgets (line, AF_LINESIZ, file);
      itemptr = firstitem (line);
      gen = atoi (itemptr);
      itemptr = nextitem (itemptr);
      rev = atoi (itemptr);
      itemptr = nextitem (itemptr);
      itemptr = nextitem (itemptr);
      size = (off_t) atoi (itemptr);

      if ((list->af_list[i].af_gen != gen) || (list->af_list[i].af_rev != rev))
	FAIL ("rddata", "wrong version in datafile", AF_EINCONSIST, ERROR);

      /* read data */
      (void) fread (&(dbuf[dpos]), sizeof(char), (Size_t) size, file);
      list->af_list[i].af_data = &(dbuf[dpos]);
      dpos = dpos+size;
    }
  return (AF_OK);
} /* af_rddata */

/*==========================================================================
 *	af_readdata -- read notes and data section of archive file
 *
 *
 *==========================================================================*/

EXPORT af_readdata (list)
     Af_revlist *list;
{
  char *data, idstr[AF_SEGSTRLEN+1], archname[MAXNAMLEN], line[AF_LINESIZ];
  FILE *archfile;
  short version;

  /* if notes are already loaded */
  if ((list->af_extent & AF_DATA) == AF_DATA)
    return (AF_OK);

  (void) strcpy (archname, list->af_arfilename);
  archname[strlen(archname)-sizeof(char)] = AF_DATAEXT;
  if ((archfile = fopen (archname, "r")) == (FILE *)0)
    FAIL ("readdata", "", AF_ENOAFSFILE, ERROR);

  idstr[AF_SEGSTRLEN] = '\0';
  (void) fgets (idstr, AF_SEGSTRLEN+1, archfile);
  if (strncmp (idstr, AF_DATAHEADER, AF_SEGSTRLEN))
    FAIL ("readdata", "wrong header in datafile", AF_EINCONSIST, ERROR);

  (void) fgets (line, AF_LINESIZ, archfile);
  version = atoi (line);
  if (version != AF_ARCURVERS)
    FAIL ("readdata", "unknown archive format version", AF_EINCONSIST, ERROR);

  /* allocate memory for data */
  if ((data = af_malloc (list, (unsigned) list->af_datasize)) == (char *)0)
    FAIL ("readdata", "malloc", AF_ESYSERR, ERROR);

  if (af_rddata (archfile, data, list) != AF_OK)
    return (ERROR);

  list->af_extent |= AF_DATA;
  (void) fclose (archfile);
  return (AF_OK);
}

/*======================= rdattrs ====================================*/

LOCAL af_rdattrs (file, list, bibufptr)
     FILE	 *file;
     Af_revlist  *list;
     struct stat *bibufptr;
{
  char idstr[AF_IDSTRLEN+1], *itemptr, line[AF_LINESIZ];
  int  i;
  bool writeok;
  Af_user *user, *owner, *af_garown();

  /* skip idstring */
  idstr[AF_IDSTRLEN] = '\0';
  (void) fgets (idstr, AF_IDSTRLEN+1, file);
  
  /* read constant attributes and variant of busy version */
  (void) fgets (line, AF_LINESIZ, file);

  /* check location (only host is checked up to now) */
  /* path, name and type could be checked too */

  itemptr = firstitem (line); /* host */
  if (strcmp (list->af_cattrs.af_host, itemptr))
    {
      /* FAIL ("rdattrs", "", AF_ELOC, ERROR); -- replaced by: */
      af_wng ("readattrs", "wrong hostname in archive file");
      list->af_cattrs.af_host = af_entersym (itemptr);
    }
  itemptr = nextitem (itemptr); /* path - skipped ... */
  itemptr = nextitem (itemptr); /* name - skipped ... */
  itemptr = nextitem (itemptr); /* type - skipped ... */

  itemptr = nextitem (itemptr); /* variant */
  if (strcmp (itemptr, AF_NOSTRING))
    list->af_list[0].af_variant = af_entersym (itemptr);
  else
    list->af_list[0].af_variant = (char *)0;

  /* get owner of archive directory */
  if ((owner = af_garown (list->af_arfilename, &writeok)) == (Af_user *)0)
    FAIL ("rdattrs", "cannot get owner of archive", AF_EINTERNAL, ERROR);
  list->af_cattrs.af_ownname = af_entersym (owner->af_username);
  list->af_cattrs.af_ownhost = af_enterhost (owner->af_userhost);

  if (writeok)
    list->af_extent |= AF_UXWRITE;
  
  /* read owner from archive */
  (void) fgets (idstr, AF_IDSTRLEN+1, file);
  (void) fgets (line, AF_LINESIZ, file); /* name and host of owner */
  /* plausibility of owner should be checked here */

  (void) fgets (idstr, AF_IDSTRLEN+1, file);
  (void) fgets (line, AF_LINESIZ, file); /* predecessor of busy object */
  itemptr = firstitem (line);
  list->af_list[0].af_predgen = atoi (itemptr);
  itemptr = nextitem (itemptr);
  list->af_list[0].af_predrev = atoi (itemptr);

  (void) fgets (idstr, AF_IDSTRLEN+1, file);
  (void) fgets (line, AF_LINESIZ, file); /* locker */
  itemptr = firstitem (line);
  if (strcmp (itemptr, AF_NOSTRING))
    {
      list->af_list[0].af_lckname = af_entersym (itemptr);
      itemptr = nextitem (itemptr);
      list->af_list[0].af_lckhost = af_enterhost (itemptr);
    }
  else
    {
      list->af_list[0].af_lckname = (char *)0;
      itemptr = nextitem (itemptr);
      list->af_list[0].af_lckhost = (char *)0;
    }
  itemptr = nextitem (itemptr);
  list->af_list[0].af_ltime = (time_t)atoi(itemptr);

  /* initialize and attributes for busy version */
  list->af_list[0].af_gen = AF_BUSYVERS;
  list->af_list[0].af_rev = AF_BUSYVERS;
  list->af_list[0].af_state = AF_BUSY;
  list->af_list[0].af_stime = AF_NOTIME;
  list->af_list[0].af_udanum = 0;
  list->af_list[0].af_repr = AF_FILE;
  list->af_list[0].af_dsize = (off_t) 0;
  list->af_list[0].af_data = (char *)0;
  list->af_list[0].af_hashname = (char *)0;
  list->af_list[0].af_nlinks = 0;
  list->af_list[0].af_succgen = AF_NOVNUM;
  list->af_list[0].af_succrev = AF_NOVNUM;

  if (bibufptr->st_ino) /* if there is a busy version */
    {
      list->af_list[0].af_class = AF_VALID;
      if ((user = af_getuser (bibufptr->st_uid)) == (Af_user *)0)
	{
	  af_wng ("rdattrs", "invalid userID in inode of busy file");
	  user = af_getuser (getuid());
	}
      list->af_list[0].af_auname = af_entersym (user->af_username);
      list->af_list[0].af_auhost = af_enterhost (user->af_userhost);
      list->af_list[0].af_mode = (u_short) bibufptr->st_mode;
      list->af_list[0].af_mtime = (time_t) af_cvttime (bibufptr->st_mtime);
      list->af_list[0].af_atime = (time_t) af_cvttime (bibufptr->st_atime);
      list->af_list[0].af_ctime = (time_t) af_cvttime (bibufptr->st_ctime);
      list->af_list[0].af_fsize = (off_t) bibufptr->st_size;
    }
  else
    {
      list->af_list[0].af_class = 0;
      list->af_list[0].af_auname = (char *)0;
      list->af_list[0].af_auhost = (char *)0;
      list->af_list[0].af_mode = AF_NOMODE;
      list->af_list[0].af_mtime = AF_NOTIME;
      list->af_list[0].af_atime = AF_NOTIME;
      list->af_list[0].af_ctime = AF_NOTIME;
      list->af_list[0].af_fsize = AF_NOTIME;
    }
      
  /* read list */
  for (i=1; i < list->af_nrevs; i++)
    {
      /* do initializations */
      list->af_list[i].af_class = AF_VALID;
      list->af_list[i].af_notesize = 0;
      list->af_list[i].af_note = (char *)0;
      list->af_list[i].af_data = (char *)0;
      list->af_list[i].af_nlinks = 0;
      list->af_list[i].af_hashname = (char *)0;

      /* enter name (set a pointer to the name-field of af_list[0]) */
      /* skip position 0 */
      if (i != 0)
	{
	  list->af_list[i].af_name = list->af_list[0].af_name;
	  list->af_list[i].af_type = list->af_list[0].af_type;
	}

      /* read revision ID */
      (void) fgets (idstr, AF_IDSTRLEN+1, file);
      if (strcmp (idstr, AF_REVID)) /* could be done for every field */
	FAIL ("rdattrs", 
	      "wrong revision-ID in archive file", AF_EINCONSIST, ERROR);
      (void) fgets (line, AF_LINESIZ, file);
      itemptr = firstitem (line);
      list->af_list[i].af_gen = atoi (itemptr);
      itemptr = nextitem (itemptr);
      list->af_list[i].af_rev = atoi (itemptr);
      itemptr = nextitem (itemptr);
      list->af_list[i].af_state = (short) atoi (itemptr);
      itemptr = nextitem (itemptr);
      (void) sscanf (itemptr, "%ho", &(list->af_list[i].af_mode));
      itemptr = nextitem (itemptr);
      if (strcmp (itemptr, AF_NOSTRING))
	list->af_list[i].af_variant = af_entersym (itemptr);
      else
	list->af_list[i].af_variant = (char *)0;
      
      /* read author*/
      (void) fgetc (file); /* skip tab */
      (void) fgets (idstr, AF_IDSTRLEN+1, file);
      (void) fgets (line, AF_LINESIZ, file); /* predecessor of busy object */
      itemptr = firstitem (line);
      list->af_list[i].af_auname = af_entersym (itemptr);
      itemptr = nextitem (itemptr);
      list->af_list[i].af_auhost = af_enterhost (itemptr);
      itemptr = nextitem (itemptr);
      if (strcmp (itemptr, AF_NOSTRING))
      	{
	  list->af_list[i].af_lckname = af_entersym (itemptr);
	  itemptr = nextitem (itemptr);
	  list->af_list[i].af_lckhost = af_enterhost (itemptr);
	}
      else
	{
	  list->af_list[i].af_lckname = (char *)0;
	  itemptr = nextitem (itemptr);
	  list->af_list[i].af_lckhost = (char *)0;
	}

      /* read dates */
      (void) fgetc (file); /* skip tab */
      (void) fgets (idstr, AF_IDSTRLEN+1, file);
      (void) fgets (line, AF_LINESIZ, file);
      itemptr = firstitem (line);
      list->af_list[i].af_mtime = (time_t) atoi (itemptr);
      itemptr = nextitem (itemptr);
      list->af_list[i].af_atime = (time_t) atoi (itemptr);
      itemptr = nextitem (itemptr);
      list->af_list[i].af_ctime = (time_t) atoi (itemptr);
      itemptr = nextitem (itemptr);
      list->af_list[i].af_stime = (time_t) atoi (itemptr);
      itemptr = nextitem (itemptr);
      list->af_list[i].af_ltime = (time_t) atoi (itemptr);

      /* read kind of representation */
      (void) fgetc (file); /* skip tab */
      (void) fgets (idstr, AF_IDSTRLEN+1, file);
      (void) fgets (line, AF_LINESIZ, file);
      itemptr = firstitem (line);
      list->af_list[i].af_repr = (short) atoi (itemptr);
      itemptr = nextitem (itemptr);
      list->af_list[i].af_fsize = (off_t) atoi (itemptr);
      itemptr = nextitem (itemptr);
      list->af_list[i].af_dsize = (off_t) atoi (itemptr);
      itemptr = nextitem (itemptr);
      list->af_list[i].af_succgen = atoi (itemptr);
      itemptr = nextitem (itemptr);
      list->af_list[i].af_succrev = atoi (itemptr);
      itemptr = nextitem (itemptr);
      list->af_list[i].af_predgen = atoi (itemptr);
      itemptr = nextitem (itemptr);
      list->af_list[i].af_predrev = atoi (itemptr);
    }
  if (!(bibufptr->st_ino)) /* if there is no busy version */
    list->af_nrevs--;
  
  return (AF_OK);
} /* af_rdattrs */

/*======================= rdudas ====================================*/

#define AF_UDASEGSIZ 8

LOCAL af_rdudas (file, list)
     FILE       *file;
     Af_revlist *list;
{
  char	idstr[AF_IDSTRLEN+1], *udabuf, *malloc(), *realloc();
  char  *itemptr, line[AF_LINESIZ];
  int	c, i, j, gen, rev, maxindex;

  /* if there is a valid busy version */
  if (list->af_list[0].af_class & AF_VALID)
    maxindex = list->af_nrevs;
  else
    maxindex = list->af_nrevs+1;

  (void) getc (file); /* skip newline */
  idstr[AF_IDSTRLEN] = '\0';
  for (i=0; i < maxindex; i++)
    {
      (void) fgets (idstr, AF_IDSTRLEN+1, file);
      if (strcmp (idstr, AF_UDAID))
	FAIL ("rdudas", "wrong uda-ID in archive file", AF_EINCONSIST, ERROR);
      (void) fgets (line, AF_LINESIZ, file);
      itemptr = firstitem (line);
      gen = atoi (itemptr);
      itemptr = nextitem (itemptr);
      rev = atoi (itemptr);

      if ((list->af_list[i].af_gen != gen) || (list->af_list[i].af_rev != rev))
	FAIL ("rdudas", "wrong version in archive file", AF_EINCONSIST, ERROR);
      
      /* build up hashlist and read user define attributes */
      if (af_hashinit (&list->af_list[i].af_uhtab, AF_MAXUDAS, af_fhash)
	                                                         == ERROR)
	return (ERROR);

      if (i == 0) /* initalize only once */
	{
	  if ((udabuf = malloc ((unsigned) (AF_UDASEGSIZ * sizeof (char)))) == (char *)0)
	    FAIL ("rdudas", "malloc", AF_ESYSERR, ERROR);
	}

      /* if there is *no* valid busy version, skip the user defined */
      /* attributes for the busy version */
      if ((i==0) && !(list->af_list[0].af_class & AF_VALID))
	{
	  while (TRUE)
	    {
	      if ((c = getc (file)) == '\0')
		{
		  if ((c = getc (file)) == '\0')
		    break;
		}
	    }
	  (void) getc (file); /* skip trailing newline char */
	  continue;
	}

      j = 0;
      while (TRUE)
	{
	  if ((udabuf[j] = getc (file)) == '\0')
	    { 
	      if (j != 0)
		{
		  (void) af_hashsym (&list->af_list[i].af_uhtab, udabuf, (Af_revlist *)0);
#ifdef MEMDEBUG
		  fprintf (memprot, "Uda (%s)\n", udabuf);
#endif
		  list->af_list[i].af_udanum++;
		}
	      /* a second nullbyte indicates the end of the list of udas */
	      if ((c = getc (file)) == '\0')
		break;
	      udabuf[0] = c;
	      j = 1;
	    }
	  else
	    {
	      j++;
	      if ((j % AF_UDASEGSIZ) == 0) /* if segment is full */
		{
		  if ((udabuf = realloc (udabuf, (unsigned) ((j + AF_UDASEGSIZ) * sizeof (char)))) == (char *)0) 
		    FAIL ("rdudas", "realloc", AF_ESYSERR, ERROR);
		}
	    }
	}
      (void) getc (file); /* skip trailing newline char */
    }
  free (udabuf);
  return (AF_OK);
} /* af_rdudas */

/*==========================================================================
 *	af_readattrs -- read attributes from archive file
 *                      
 *
 *==========================================================================*/

EXPORT Af_revlist *af_readattrs (path, name, type, mode)
     char *path, *name, *type;
     bool *mode;
{
  char	  idstr[AF_SEGSTRLEN+1], line[AF_LINESIZ], *itemptr;
  FILE	  *archfile;
  struct stat bibuf, aibuf;
  Af_revlist *list, *init_ldes();
  short   version;
  bool    writeok;
  Af_user *user, *owner, *af_garown();

  if ((list = init_ldes (path, name, type)) == (Af_revlist *)0)
    return ((Af_revlist *)0);

  /* if attributes are already loaded */
  if ((list->af_extent & AF_ATTRS) == AF_ATTRS)
    {
      if (*mode == FALSE)
	{
	  /* see if busy version has changed */
	  if (lstat (list->af_busyfilename, &bibuf) == ERROR)
	    bibuf.st_ctime = AF_NOTIME;
	  if (bibuf.st_ctime != list->af_list[0].af_ctime)
	    {
	      /* update busy version */
	      if (!(list->af_list[0].af_class & AF_VALID))
		{
		  list->af_nrevs++;
		  if (af_hashinit (&list->af_list[0].af_uhtab,
				   AF_MAXUDAS, af_fhash) == ERROR)
		    return ((Af_revlist *)0);
		  list->af_list[0].af_class = AF_VALID;
		}
	      if ((user = af_getuser (bibuf.st_uid)) == (Af_user *)0)
		{
		  af_wng ("readattrs", "invalid userID in inode of busy file");
		  user = af_getuser (getuid());
		}
	      list->af_list[0].af_auname = af_entersym (user->af_username);
	      list->af_list[0].af_auhost = af_enterhost (user->af_userhost);
	      list->af_list[0].af_mode = (u_short) bibuf.st_mode;
	      list->af_list[0].af_mtime = (time_t) af_cvttime (bibuf.st_mtime);
	      list->af_list[0].af_atime = (time_t) af_cvttime (bibuf.st_atime);
	      list->af_list[0].af_ctime = (time_t) af_cvttime (bibuf.st_ctime);
	      list->af_list[0].af_fsize = (off_t) bibuf.st_size;
	    }
	}
      *mode = TRUE;
      return (list);
    }
  else
    {
      *mode = FALSE;
    }

  if ((list->af_busyfilename = af_gbusname (list->af_cattrs.af_syspath,
					     name, type)) == (char *)0)
    return ((Af_revlist *)0);
  
  list->af_arfilename = af_garname (list->af_cattrs.af_syspath, name, type);
  list->af_extent |= AF_ARCHIVE;

  if (lstat (list->af_busyfilename, &bibuf) == ERROR)
    bibuf.st_ino = 0;

  /* open archive */
  if ((list->af_arfilename == (char *)0) ||
      ((archfile = fopen (list->af_arfilename, "r")) == (FILE *)0))
    {
      if (bibuf.st_ino == 0) /* no busy file */
	{
	  (void) af_detarchive (list);
	  SFAIL ("readattrs", "", AF_ENOAFSFILE, (Af_revlist *)0);
	}
      list->af_nrevs = 1;
      list->af_listlen = AF_NEWREVS;
      list->af_extent |= AF_ALLSEGS;
      list->af_datasize = 0;

      /* determine author of busy file */
      if ((user = af_getuser (bibuf.st_uid)) == (Af_user *)0)
	{
	  af_wng ("readattrs", "invalid userID in inode of busy file");
	  user = af_getuser (getuid());
	}

      /* if an archive-directory exists, get its owner */
      if ((owner = af_garown (list->af_arfilename, &writeok)) == (Af_user *)0)
	{
	  list->af_cattrs.af_ownname = af_entersym (user->af_username);
	  list->af_cattrs.af_ownhost = af_enterhost (user->af_userhost);
	}
      else
	{
	  list->af_cattrs.af_ownname = af_entersym (owner->af_username);
	  list->af_cattrs.af_ownhost = af_enterhost (owner->af_userhost);
	}
      if (writeok)
	list->af_extent |= AF_UXWRITE;
      
      if ((list->af_list = (Af_vattrs *)af_malloc (list, (unsigned) (list->af_listlen * sizeof(Af_vattrs)))) == (Af_vattrs *)0)
	FAIL ("readattrs", "malloc,1", AF_ESYSERR, (Af_revlist *)0);
      
      bzero ((char *)list->af_list, list->af_listlen * sizeof (Af_vattrs));
      /* init attrbuf for busy version  (relevant attrs only) */
      list->af_list[0].af_name = af_entersym (name);
      list->af_list[0].af_type = af_entersym (type);
      list->af_list[0].af_gen = AF_BUSYVERS;
      list->af_list[0].af_rev = AF_BUSYVERS;
      list->af_list[0].af_variant = (char *)0;
      list->af_list[0].af_state = AF_BUSY;
      list->af_list[0].af_class = AF_VALID;
      list->af_list[0].af_auname = af_entersym (user->af_username);
      list->af_list[0].af_auhost = af_enterhost (user->af_userhost);
      list->af_list[0].af_mode = (u_short) bibuf.st_mode;
      list->af_list[0].af_lckname = (char *)0;
      list->af_list[0].af_lckhost = (char *)0;
      list->af_list[0].af_mtime = (time_t) af_cvttime (bibuf.st_mtime);
      list->af_list[0].af_atime = (time_t) af_cvttime (bibuf.st_atime);
      list->af_list[0].af_ctime = (time_t) af_cvttime (bibuf.st_ctime);
      list->af_list[0].af_stime = AF_NOTIME;
      list->af_list[0].af_ltime = AF_NOTIME;
      list->af_list[0].af_notesize = 1;
      list->af_list[0].af_note = (char *)0;
      list->af_list[0].af_udanum = 0;
      if (af_hashinit (&list->af_list[0].af_uhtab, AF_MAXUDAS, af_fhash)
	                                                         == ERROR)
	return ((Af_revlist *)0);
      list->af_list[0].af_repr = AF_FILE;
      list->af_list[0].af_fsize = (off_t) bibuf.st_size;
      list->af_list[0].af_dsize = 0;
      list->af_list[0].af_data = (char *)0;
      list->af_list[0].af_hashname = (char *)0;
      list->af_list[0].af_nlinks = 0;
      list->af_list[0].af_succgen = AF_NOVNUM;
      list->af_list[0].af_succrev = AF_NOVNUM;
      list->af_list[0].af_predgen = AF_NOVNUM;
      list->af_list[0].af_predrev = AF_NOVNUM;
      return (list);
    }
  
  /* record date of last modification */
  (void) lstat (list->af_arfilename, &aibuf);
  list->af_lastmod = (time_t) af_cvttime (aibuf.st_mtime);

  /* archive file ??? */
  idstr[AF_SEGSTRLEN] = '\0';
  (void) fgets (idstr, AF_SEGSTRLEN+1, archfile);
  if (strncmp (idstr, AF_ARHEADER, AF_SEGSTRLEN))
    FAIL ("readattrs",
	  "wrong header in archive file", AF_EINCONSIST, (Af_revlist *)0);
  
  /* read header */
  (void) fgets (line, AF_LINESIZ, archfile);
  itemptr = firstitem (line);
  version = atoi (itemptr);
  if (version != AF_ARCURVERS)
    FAIL ("readattrs", 
	  "unknown archive format version", AF_EINCONSIST, (Af_revlist *)0);
  itemptr = nextitem (itemptr);
  list->af_nrevs = atoi (itemptr);
  itemptr = nextitem (itemptr);
  list->af_datasize = atoi (itemptr);

  /* alloc memory for revision list (plus space for new revs) */
  list->af_listlen = list->af_nrevs + AF_NEWREVS;
  if ((list->af_list = (Af_vattrs *)af_malloc (list, (unsigned) (list->af_listlen * sizeof(Af_vattrs)))) == (Af_vattrs *)0)
    FAIL ("readattrs", "malloc,2", AF_ESYSERR, (Af_revlist *)0);

  bzero ((char *) list->af_list, list->af_listlen * sizeof (Af_vattrs));

  /* enter name and type */
  list->af_list[0].af_name = af_entersym (name);
  list->af_list[0].af_type = af_entersym (type);

  if (af_rdattrs (archfile, list, &bibuf) != AF_OK)
    return ((Af_revlist *)0);

  /* read id string for user defined attributes section*/
  (void) fgets (idstr, AF_SEGSTRLEN+1, archfile);
  if (strncmp (idstr, AF_UDASEG, AF_SEGSTRLEN))
    FAIL ("readattrs",
	  "wrong udaseg-ID in archive file", AF_EINCONSIST, (Af_revlist *)0);

  if (af_rdudas (archfile, list) != AF_OK)
    return ((Af_revlist *)0);

  list->af_extent |= (AF_ATTRS | AF_COMPLETE);
  (void) fclose (archfile);
  return (list);
} /* af_readattrs */


/*==========================================================================
 *	writearchive -- write archive file
 *
 *
 *==========================================================================*/

EXPORT af_writearchive (list)
     Af_revlist *list;
{
  int   i, j, maxindex;
  FILE	*tmpfile, *datafile;
  char  tmpname[MAXNAMLEN], dataname[MAXNAMLEN], *ptrlist[AF_MAXUDAS];
  char  archname[MAXNAMLEN];
  off_t	datasize;
  Af_key *busyptr, *af_gbuskey();

  /* File locking mechanism should be inserted here */

  /* if all revisions have been removed */
  if (list->af_nrevs == 0)
    {
      (void) af_unlink (list->af_arfilename);
      (void) strcpy (archname, list->af_arfilename);
      archname[strlen(archname)-sizeof(char)] = AF_DATAEXT;
      (void) af_unlink (archname);
      return (AF_OK);
    }

  (void) strcpy (tmpname, list->af_arfilename); 
  tmpname[strlen(tmpname) - sizeof(char)] = AF_ARCHTMP;
  af_regtmpfile (tmpname);
  /* open tmpfile */
  if ((tmpfile = fopen (tmpname, "w")) == (FILE *)0)
    FAIL ("writearchive", "fopen", AF_ESYSERR, ERROR);

  /* if there is no busy version - increase "nrevs" temporarily */
  busyptr = af_gbuskey (list);
  if (!(VATTR(busyptr).af_class & AF_VALID))
    list->af_nrevs++;

  /* write header */
  fprintf (tmpfile, "%s %d %d %ld\n", AF_ARHEADER, AF_ARCURVERS,
	   list->af_nrevs, list->af_datasize);

  /* write constant attributes */
  fprintf (tmpfile, "%s %s %s %s %s %s\n", AF_NAMEID, 
	   list->af_cattrs.af_host,
	   list->af_cattrs.af_syspath,
	   list->af_list[0].af_name,
	   NOTMT (list->af_list[0].af_type),
	   NOTMT (list->af_list[0].af_variant));

  /* write owner */
  fprintf (tmpfile, "%s %s %s\n", AF_OWNID,
	   list->af_cattrs.af_ownname,
	   list->af_cattrs.af_ownhost);


  /* write predecessor and locker of busy version */
  fprintf (tmpfile, "%s %d %d\n%s %s %s %d\n", AF_PRDID,
	   VATTR(busyptr).af_predgen,
	   VATTR(busyptr).af_predrev, AF_LOCKID,
	   NOTMT (VATTR(busyptr).af_lckname),
	   NOTMT (VATTR(busyptr).af_lckhost),
	   VATTR(busyptr).af_ltime);

  /* write list of version attributes */
  maxindex = list->af_nrevs;
  for (i=1; i < maxindex; i++)
    {
      /* skip deleted versions */
      if (!(list->af_list[i].af_class & AF_VALID))
	{
	  maxindex++;
	  continue;
	}

      /* write revision ID */
      fprintf (tmpfile, "%s %d %d %d %o %s\n", AF_REVID, 
	       list->af_list[i].af_gen,
	       list->af_list[i].af_rev,
	       list->af_list[i].af_state,
	       list->af_list[i].af_mode,
	       NOTMT (list->af_list[i].af_variant));

      /* write author */
      fprintf (tmpfile, "\t%s %s %s %s %s\n", AF_AUTHORID,
	       list->af_list[i].af_auname,
	       list->af_list[i].af_auhost,
	       NOTMT (list->af_list[i].af_lckname),
	       NOTMT (list->af_list[i].af_lckhost));

      /* write dates */
      fprintf (tmpfile, "\t%s %ld %ld %ld %ld %ld\n", AF_DATEID,
	       list->af_list[i].af_mtime,
	       list->af_list[i].af_atime,
	       list->af_list[i].af_ctime,
	       list->af_list[i].af_stime,
	       list->af_list[i].af_ltime);

      /* write kind of representation and tree connects */
      fprintf (tmpfile, "\t%s %d %ld %ld %d %d %d %d\n", AF_REPRID,
	       list->af_list[i].af_repr,
	       list->af_list[i].af_fsize,
	       list->af_list[i].af_dsize,
	       list->af_list[i].af_succgen,
	       list->af_list[i].af_succrev,
	       list->af_list[i].af_predgen,
	       list->af_list[i].af_predrev);
    }

  /* write user defined attributes */
  fprintf (tmpfile, "%s\n", AF_UDASEG);
  maxindex = list->af_nrevs;
  for (i=0; i < maxindex; i++)
    {
      /* skip deleted versions but not the busy version */
      if (!(list->af_list[i].af_class & AF_VALID) && 
	  (list->af_list[i].af_state != AF_BUSY))
	{ maxindex++; continue;	}

      fprintf (tmpfile, "%s %d %d\n", AF_UDAID,
	       list->af_list[i].af_gen,
	       list->af_list[i].af_rev);
      (void) af_lhashsyms (&list->af_list[i].af_uhtab, ptrlist);
      j=0;
      while (ptrlist[j])
	fprintf (tmpfile, "%s%c", ptrlist[j++], '\0');
      if (j==0) /* if no user defined attribute has been written */
	(void) putc ('\0', tmpfile);
      (void) putc ('\0', tmpfile);
      (void) putc ('\n', tmpfile);
    }
  (void) fclose (tmpfile);

  /* if data have been manipulated - write data file */
  if ((list->af_extent & AF_DATA) == AF_DATA)
    {
      (void) strcpy (dataname, list->af_arfilename);
      dataname[strlen(dataname) - sizeof(char)] = AF_DATATMP;
      af_regtmpfile (dataname);
      /* open tmpfile for data */
      if ((datafile = fopen (dataname, "w")) == (FILE *)0)
	FAIL ("writearchive", "fopen", AF_ESYSERR, ERROR);

      /* write notes and data */
      fprintf (datafile, "%s %d\n", AF_DATAHEADER, AF_ARCURVERS);
      
      maxindex = list->af_nrevs;
      for (i=1; i < maxindex; i++)
	{
	  /* skip deleted versions */
	  if (!(list->af_list[i].af_class & AF_VALID))
	    { maxindex++; continue; }
	  
	  fprintf (datafile, "%s %d %d %ld\n", AF_NOTEID,
		   list->af_list[i].af_gen,
		   list->af_list[i].af_rev,
		   list->af_list[i].af_notesize);
	  (void) fwrite (list->af_list[i].af_note, sizeof(char), (Size_t) list->af_list[i].af_notesize - sizeof(char), datafile);
	  (void) putc ('\n', datafile);

	  if (list->af_list[i].af_repr == AF_CHUNK)
	    datasize = list->af_list[i].af_fsize;
	  else datasize = list->af_list[i].af_dsize;
	  fprintf (datafile, "%s %d %d %d %ld\n", AF_DATAID,
		   list->af_list[i].af_gen,
		   list->af_list[i].af_rev,
		   list->af_list[i].af_repr, datasize);

	  (void) fwrite (list->af_list[i].af_data, sizeof(char), (Size_t) datasize, datafile);
	}
      (void) fclose (datafile);
    }

  af_unregtmpfile (tmpname);
  (void) af_unlink (list->af_arfilename);
  if (af_syslink (tmpname, list->af_arfilename) == ERROR)
    FAIL ("writearchive", "link", AF_ESYSERR, ERROR);

  (void) af_uchmod (list->af_arfilename, AF_ARCHMODE);
  (void) af_unlink (tmpname);

  /* if the data file has been written */
  if ((list->af_extent & AF_DATA) == AF_DATA)
    {
      (void) strcpy (archname, list->af_arfilename);
      archname[strlen(archname)-sizeof(char)] = AF_DATAEXT;
      af_unregtmpfile (dataname);
      (void) af_unlink (archname);
      if (af_syslink (dataname, archname) == ERROR)
	FAIL ("writearchive", "link", AF_ESYSERR, ERROR);
      (void) af_uchmod (archname, AF_ARCHMODE);
      (void) af_unlink (dataname);
    }

  /* decrease "nrevs" again (see beginning of procedure */
  if (!(VATTR(busyptr).af_class & AF_VALID))
    list->af_nrevs--;
  
  return (AF_OK);
} /* af_writearchive */

