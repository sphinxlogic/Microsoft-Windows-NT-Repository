/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*LINTLIBRARY*/
/*
 *	Shape/AFS
 *
 *	affiles.c -- UNIX-files in AFS
 *
 *	Author: Andreas Lampen, TU-Berlin (andy@coma.UUCP)
 *					  (andy@db0tui62.BITNET)
 *
 *	$Header: affiles.c[1.6] Wed Feb 22 16:27:34 1989 andy@coma published $
 *
 *	EXPORT:
 *      af_access -- see if any version of named file exists
 *	af_crkey -- create filekey
 *	af_open -- open AFS-file
 *	af_close -- close AFS-file
 *      af_link -- create a link to a AFS-file
 *	af_rm -- remove AFS-file
 *	af_restore -- restore derived file
 */

#include <stdio.h>
#include <sys/param.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "typeconv.h"
#include "afsys.h"
#include "afs.h"

/*================================================================
 *	af_access -- see if any version of named file exists
 *
 *================================================================*/

EXPORT af_access (path, name, type, mode)
     char *path, *name, *type;
     int  mode;
{
  char *unixname, *arnamptr, *pathname, *nameptr, *typeptr;
  Af_revlist *list, *af_rbplist(), *af_readattrs();
  short maxindex, i;
  bool loaded = FALSE;
  
  pathname = af_uniqpath (path);

  if (mode & AF_DERIVED) /* look in binary pool */
    {
      /* lookup in binary pool */
      
      if ((list = af_rbplist (pathname)) == (Af_revlist *)0)
	return (ERROR);
      
      nameptr = af_entersym (name);
      typeptr = af_entersym (type);
      maxindex = list->af_nrevs;
      for (i = 0; i < maxindex; i++)
	{
	  /* skip holes in the list */
	  if (!(list->af_list[i].af_class & AF_VALID))
	    {
	      maxindex++;
	      continue;
	    }
	  if ((nameptr == list->af_list[i].af_name) &&
	      (typeptr == list->af_list[i].af_type))
	    return (AF_OK);
	}
    }
  else /* look in directory */
    {
      unixname = af_unixname (pathname, name, type);
      /* if a named unix file exists */
      if (!af_sysaccess (unixname, F_OK))
	return (AF_OK);
      /* look for archive */
      arnamptr = af_garname (pathname, name, type);
      if (!af_sysaccess (arnamptr, F_OK))
	{
	  /* look if there are versions in archive file */
	  list = af_readattrs (pathname, name, type, &loaded);
	  if (list->af_nrevs > 0)
	    return (AF_OK);
	}
    }
  return (ERROR);
}

/*================================================================
 *	af_crkey
 *
 *================================================================*/

EXPORT af_crkey (path, name, type, key)
     char *path;
     char *name, *type;
     Af_key *key;
{
  char *busyname, *uniqpath;
  FILE *busyfile;
  Af_revlist *af_readattrs();
  bool loaded = FALSE;
  Af_key *busykey, *af_gbuskey();
  Af_user *author;
  struct stat bibuf;
  
  uniqpath = af_uniqpath (path);
  busyname = af_gbusname (uniqpath, name, type);
  
  /* if file does not exist -- create it */
  if ((lstat (busyname, &bibuf)) == ERROR)
    {
      if ((busyfile = fopen (busyname, "w")) == (FILE *)0)
	FAIL ("crkey", "fopen", AF_ESYSERR, ERROR);
      (void) fclose (busyfile);
      (void) stat (busyname, &bibuf);
    }
  
  key->af_ldes = af_readattrs (uniqpath, name, type, &loaded);
  
  /* select busy version if present */
  if ((busykey = af_gbuskey (key->af_ldes)) == (Af_key *)0)
    FAIL ("crkey", "no space for busy version", AF_EINTERNAL, ERROR);
  key->af_lpos = busykey->af_lpos;

  if (af_checkperm (busykey, AF_WORLD) == ERROR)
    return (ERROR);

  /* if busy version was invalid up to now, initialize it */
  if (!(VATTR(key).af_class & AF_VALID))
    {
      key->af_ldes->af_nrevs += 1;
      VATTR(key).af_class = AF_VALID;
      if ((author = af_getuser (bibuf.st_uid)) == (Af_user *)0)
	{
	  af_wng ("crkey", "invalid userID in inode of busy file");
	  author = af_getuser (getuid());
	}
      VATTR(key).af_auname = af_entersym (author->af_username);
      VATTR(key).af_auhost = af_enterhost (author->af_userhost);
      VATTR(key).af_mode = (u_short) bibuf.st_mode;
      VATTR(key).af_lckname = (char *)0;
      VATTR(key).af_lckhost = (char *)0;
      VATTR(key).af_mtime = (time_t) af_cvttime (bibuf.st_mtime);
      VATTR(key).af_atime = (time_t) af_cvttime (bibuf.st_atime);
      VATTR(key).af_ctime = (time_t) af_cvttime (bibuf.st_ctime);
      VATTR(key).af_stime = AF_NOTIME;
      VATTR(key).af_ltime = AF_NOTIME;
      VATTR(key).af_fsize = (off_t) bibuf.st_size;
    }

  key->af_ldes->af_refcount++;
  VATTR(key).af_nlinks++;

/* possibly the date of last access is *not* set properly */
/* instead of */
  (void) af_updtvers (key, 0);
/* this should be */
/* if (af_updtvers (key, 0) == ERROR) */
/*    return (ERROR); */

  return (AF_OK);
}

/*================================================================
 *	af_open
 *
 *================================================================*/

EXPORT FILE *af_open (key, mode)
     Af_key *key;
     char   *mode;
{
  FILE   *file;
  char   *tmpname;
  
  if (af_keytest (key))
    SFAIL ("open", "", AF_EINVKEY, (FILE *)0);
  
  /* if file is present as busy version */
  if (VATTR(key).af_state == AF_BUSY)
    {
      if ((file = fopen (key->af_ldes->af_busyfilename, mode)) == (FILE *)0)
	FAIL ("open", "fopen", AF_ESYSERR, (FILE *)0);
      return (file);
    }
  
  /* saved versions can be opened only for reading */
  if (mode[0] != 'r')
    SFAIL ("open", "", AF_ESAVED, (FILE *)0);
  
  /* see if file is readable */
  if (af_checkread (key) == ERROR)
    SFAIL ("open", "", AF_EACCES, (FILE *)0);

  /* build name for temporary file */
  tmpname = af_gtmpname (CATTR(key).af_syspath, VATTR(key).af_name);
  af_regtmpfile (tmpname);

  if (af_bldfile (key, tmpname) == ERROR)
    return ((FILE *)0);

  if ((file = fopen (tmpname, mode)) == (FILE *)0)
    FAIL ("open", "fopen", AF_ESYSERR, (FILE *)0);

  (void) af_unlink (tmpname); /* this causes the tmp file to be removed on closing */
  af_unregtmpfile (tmpname);

  VATTR(key).af_atime = (time_t)af_acttime ();
/* possibly the date of last access is *not* set properly */
/* instead of */
  (void) af_updtvers (key, 0);
/* this should be */
/* if (af_updtvers (key, 0) == ERROR) */
/*    return ((FILE *)0); */

  return (file);
}


/*================================================================
 *	af_close
 *
 *================================================================*/

EXPORT af_close (file)
     FILE *file;
{
  return (fclose (file));
}

/*================================================================
 *	af_link
 *
 *================================================================*/

EXPORT af_link (oldkey, newkey)
     /*ARGSUSED*/
     Af_key *oldkey, *newkey;
{
  /* not yet implemented (af_link) */
}

/*================================================================
 *	af_rm
 *
 *================================================================*/

EXPORT af_rm (key)
     Af_key *key;
{
  Af_user *locker;
  if (af_keytest (key))
    SFAIL ("rm", "", AF_EINVKEY, ERROR);

  /* if object is a derived object or not locked */
  locker = af_testlock (key, AF_VERSIONLOCK);
  if (!((VATTR(key).af_class & AF_DERIVED) || (locker->af_username[0]=='\0')))
    {
      if (af_checkperm (key, AF_LOCKHOLDER) == ERROR)
	SFAIL ("rm", "", AF_ENOTLOCKED, ERROR);
    }

  if (af_delvers (key) == ERROR)
    return (ERROR);

  if (VATTR(key).af_nlinks > 1)
    af_wng ("af_rm", "deleted object has more than one reference");

  /* decrease reference count for corresponding archive */
  if ((key->af_ldes->af_refcount -= VATTR(key).af_nlinks) <= 0)
    {
      VATTR(key).af_class &= ~AF_VALID;
      VATTR(key).af_nlinks = 0;
      (void) af_detlist (key->af_ldes);
    }
  else
    {
      VATTR(key).af_class &= ~AF_VALID;
      VATTR(key).af_nlinks = 0;
    }
  
  return (AF_OK);
}

/*================================================================
 *	af_restore
 *
 *================================================================*/

EXPORT af_restore (key, restkey)
     Af_key *key, *restkey;
{
  char *busyname;
  bool loaded = FALSE;
  int  af_fhash ();
  Af_revlist *list;

  if (af_keytest (key))
    SFAIL ("restore", "", AF_EINVKEY, ERROR);

  if (!(VATTR(key).af_class & AF_DERIVED))
    SFAIL ("restore", "", AF_ENOTDERIVED, ERROR);

  /* see if file is readable */
  if (af_checkread (key) == ERROR)
    SFAIL ("restore", "", AF_EACCES, ERROR);

  busyname = af_gbusname (CATTR(key).af_syspath,
			   VATTR(key).af_name, VATTR(key).af_type);
  if (af_bldfile (key, busyname) == ERROR)
    return (ERROR);

  /* build key for restored file */
  if ((list = af_readattrs (CATTR(key).af_syspath, VATTR(key).af_name,
			    VATTR(key).af_type, &loaded)) == (Af_revlist *)0)
    FAIL ("restore", "cannot access restored file", AF_EINTERNAL, ERROR);
  if (af_buildkey (list, AF_BUSYVERS, AF_BUSYVERS, restkey) == ERROR)
    FAIL ("restore", "cannot access restored file", AF_EINTERNAL, ERROR);
  restkey->af_ldes->af_refcount++;
  VATTR(restkey).af_nlinks++;

  /* if key is in use, an error message should be generated */

  /* restore user defined attributes from binary pool */
  af_hashfree (&(VATTR(restkey).af_uhtab));
  (void) af_hashinit (&(VATTR(restkey).af_uhtab), AF_MAXUDAS, af_fhash);
  VATTR(restkey).af_udanum = VATTR(key).af_udanum;
  (void) af_hashcopy (&(VATTR(key).af_uhtab), &(VATTR(restkey).af_uhtab));

  VATTR(key).af_atime = (time_t)af_acttime ();
  /* possibly the date of last access is *not* set properly */
  /* instead of */
  (void) af_updtvers (key, 0);
  (void) af_updtvers (restkey, 0);
  /* this should be */
  /* if (af_updtvers (key, 0) == ERROR) */
  /*    return ((FILE *)0); */
  
  return (AF_OK);
}


