/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*
 *	Shape/AFS
 *
 *	afsysc.c -- Isolate syscalls for portability 
 *
 *	Author: Andreas Lampen, TU-Berlin (andy@coma.UUCP)
 *					  (andy@db0tui62.BITNET)
 *
 *	$Header: afsysc.c[1.3] Wed Feb 22 16:28:23 1989 andy@coma published $
 *
 *	EXPORT:
 *	af_syslink -- create a link to a file
 *      af_sysaccess -- determine accessibility of file
 *	af_unlink -- remove file
 *      af_retfsize -- return file size
 *      af_uchown -- change owner
 *      af_uchmod -- change mode
 *      af_gethostname -- get host name
 *      af_asctime -- get time as ascii string
 *      af_acttime -- get actual time
 *      af_cvttime -- convert time
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <sys/time.h>

#include "typeconv.h"
#include "afsys.h"
#include "afs.h"

/*================================================================
 *	af_syslink
 *
 *================================================================*/

EXPORT af_syslink (existfile, newfile)
     char *existfile, *newfile;
{
  if (link (existfile, newfile) == ERROR)
    return (ERROR);
  return (AF_OK);
} /* af_syslink */ 

/*================================================================
 *	af_sysaccess
 *
 *================================================================*/

EXPORT af_sysaccess (path, mode)
     char *path;
     int  mode;
{
  return (access (path, mode));
} /* af_syslink */ 

/*================================================================
 *	af_unlink
 *
 *================================================================*/

EXPORT af_unlink (file)
     char *file;
{
  return (unlink (file));
} /* af_unlink */ 

/*================================================================
 *	af_retfsize
 *
 *================================================================*/

EXPORT off_t af_retfsize (file)
     char *file;
{
  struct stat ibuf;
  
  (void) lstat (file, &ibuf);
  return (ibuf.st_size);
} /* af_retfsize */ 

/*================================================================
 *	af_uchown
 *
 *================================================================*/

EXPORT af_uchown (file, uid, gid)
     char *file;
     int uid, gid;
{
  if (chown (file, uid, gid) == ERROR)
    return (ERROR);
  return (AF_OK);
} /* af_uchown */


/*================================================================
 *	af_uchmod
 *
 *================================================================*/

EXPORT af_uchmod (file, mode)
     char *file;
     int  mode;
{
  if (chmod (file, mode) == ERROR)
    return (ERROR);
  return (AF_OK);
} /* af_uchmod */


/*================================================================
 *	af_gethostname
 *
 *================================================================*/

static char *hostsym = (char *)0;

EXPORT char *af_gethostname ()
{
  char hostname[MAXHOSTNAMELEN];

  if (!hostsym)
    {
      (void) gethostname (hostname, MAXHOSTNAMELEN);
      hostsym =  af_entersym (hostname);
    }
  return (hostsym);
} /* af_uchmod */

/*================================================================
 *	af_asctime
 *
 *================================================================*/

EXPORT char *af_asctime ()
{
  char *asctime();  
  long seconds, time();

  seconds = time ((long *)0);
  return (asctime (localtime (&seconds)));
}

/*================================================================
 *	af_acttime -- return actual time (in seconds after ...)
 *
 *================================================================*/

EXPORT af_acttime ()
{
  struct timeval tm;
  struct timezone tz;

  (void) gettimeofday (&tm, &tz);

  return (tm.tv_sec);
}

/*================================================================
 *	af_cvttime -- convert time from inode
 *
 *================================================================*/

EXPORT af_cvttime (time)
     time_t time;
{
  return (time);
}
