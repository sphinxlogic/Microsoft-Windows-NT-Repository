/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*
 *	Shape/AFS
 *
 *	afkeys.c -- handle revision keys
 *
 *	Author: Andreas Lampen, TU-Berlin (andy@coma.UUCP)
 *					  (andy@db0tui62.BITNET)
 *
 *	$Header: afkeys.c[1.3] Wed Feb 22 16:27:39 1989 andy@coma published $
 *
 *	EXPORT:
 *	af_buildkey -- build key from generation and revision
 *      af_gbuskey -- get key of busy version
 *      af_glastkey -- get key of last saved version
 *      af_gfreepos -- search free position in revlist
 *	af_keytest -- check plausibility of key
 */

#include <stdio.h>

#include "typeconv.h"
#include "afsys.h"
#include "afs.h"

/*================================================================
 *	af_buildkey
 *
 *================================================================*/

EXPORT af_buildkey (list, gen, rev, key)
     Af_revlist *list;
     int 	gen;
     int	rev;
     Af_key	*key; /* out */
{
  int i;
  
  key->af_ldes = list;
  if (list->af_list[0].af_class & AF_VALID)
    i = list->af_nrevs-1;
  else
    i = list->af_nrevs;

  while (!((list->af_list[i].af_gen == gen) && (list->af_list[i].af_rev == rev)
	 && (list->af_list[i].af_class & AF_VALID)))
    {
      if (i == 0)
	SFAIL ("buildkey", "", AF_ENOREV, ERROR);
      i--;
    }
  key->af_lpos = i;
  return (AF_OK);
}

/*================================================================
 *	af_gbuskey
 *
 *================================================================*/

EXPORT Af_key *af_gbuskey (list)
     Af_revlist *list;
{
  static Af_key busykey;

  busykey.af_ldes = list;
  busykey.af_lpos = 0;
  return (&busykey);
}


/*================================================================
 *	af_glastkey
 *
 *================================================================*/

EXPORT Af_key *af_glastkey (list)
     Af_revlist *list;
{
  int i;
  static Af_key lastkey;

  lastkey.af_ldes = list;
  i = list->af_listlen-1;
  while (!(list->af_list[i].af_class & AF_VALID))
    {
      if (i-- == 1)
	return ((Af_key *)0);
    }
  lastkey.af_lpos = i;
  return (&lastkey);
}

/*================================================================
 * af_gfreepos -- search space for new list entry
 *                preserve increasing order
 *
 *================================================================*/

EXPORT af_gfreepos (list)
     Af_revlist *list;
{
  int i;

  i = list->af_listlen-1;
  while (!(list->af_list[i].af_class & AF_VALID) && (i >= 0))
    i--;

  if (i == list->af_listlen-1)
    return (ERROR);

  if (!(list->af_list[i].af_class & AF_VALID) && (i == 0))
    return (0);

  return (i+1);
}

 
/*================================================================
 *	af_keytest -- test plausibility of filekey
 *                    returnes TRUE (ERROR) if key is invalid,
 *                    otherwise FALSE (AF_OK).
 *
 *================================================================*/

EXPORT af_keytest (key)
     Af_key *key;
{
  if (key == (Af_key *)0)
    return (ERROR);
  if ((key->af_lpos < 0) || (key->af_lpos >= key->af_ldes->af_listlen))
    return (ERROR);
  if (VATTR(key).af_nlinks < 1)
    return (ERROR);

  return (AF_OK);
}

