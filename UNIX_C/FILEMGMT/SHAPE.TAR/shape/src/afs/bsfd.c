/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/* ================================================== */
/* ================================================== */
/*                                                    */
/* MODULE-NAME: bsfd        KEY : bs                  */
/*              = build string from delta             */
/*                                                    */
/* ORIGINAL                                           */
/* AUTHOR : sibylle         DATE: 15/06/87            */
/*                                                    */
/* LAST UPDATE                                        */
/* AUTHOR :                 DATE:                     */
/*                                                    */
/* VERSION: 1.6.1                                     */
/*                                                    */
/* ================================================== */
/*                                                    */
/* PURPOSE:                                           */
/*                building a string from a delta      */
/*                and writing it into a targetfile    */
/*                                                    */
/* SPECIALITIES:                                      */
/*                none                                */
/*                                                    */
/* EXCEPTIONS, ERRORS:                                */
/*                none                                */
/*                                                    */
/* ================================================== */
/*                                                    */
/*
 * $Header: bsfd.c[1.0] Wed Feb 22 16:14:33 1989 shape@coma save $
 */


# include "predef.h"
# include <stdio.h>
# include "edcmd.h"
# include "typeconv.h"

extern char *malloc();
extern char *calloc();
extern int free();
extern int fwrite();
extern int fclose();
extern FILE *fopen();


LOCAL char *src_str = NIL;
LOCAL long src_size = (long) 0;
LOCAL char *dlt_str = NIL;
LOCAL char *dlt_pnt = NIL;
LOCAL long dlt_size = (long) 0;

	      

LOCAL void move_to_target (cmd, indx, ftrg)
     struct ed_cmd *cmd;
     long indx;
     FILE *ftrg;
{
  char *str_addr = src_str;

  (void) fwrite ((str_addr = (str_addr + indx)), sizeof(char), (Size_t)cmd->length, ftrg);
  return;
}


LOCAL void add_to_target (cmd, ftrg)
     struct ed_cmd *cmd;
     FILE *ftrg;
{
  (void) fwrite (dlt_pnt, sizeof(char), (Size_t)cmd->length, ftrg);
  dlt_pnt += cmd->length;
  return;
}


LOCAL Bool build_string (trg_fn)
     char *trg_fn;
{
  FILE *ftarg;
  struct ed_cmd cmd;
  long indx;

  if ((ftarg = fopen(trg_fn, "w")) == (FILE *) NIL)
    return (FALSE);

  if (dlt_size == (long) 0)
    {
      cmd.cmd = MV;
      cmd.length = src_size;
      indx = (long) 0;
      move_to_target (&cmd, indx, ftarg);
      (void) fclose (ftarg);
      
      return (TRUE);
     }

  while (dlt_pnt < (dlt_str + dlt_size))
    {
      bcopy (dlt_pnt, (char *)&cmd, sizeof (cmd));
      dlt_pnt += sizeof (cmd);
      if (cmd.cmd == MV)
	{
	  bcopy (dlt_pnt, (char*)&indx, sizeof (indx));
	  dlt_pnt += sizeof (indx);
	  move_to_target (&cmd, indx, ftarg);
	}
      else 
	{
	  if (cmd.cmd == AD)
	    add_to_target (&cmd, ftarg);
	  else
	    return (FALSE);
	}
    }
  
  (void) fclose(ftarg);
  return(TRUE);
}
      

EXPORT bsfd (sourcestr, deltastr, sourcesize, deltasize, targetfn)
     char *sourcestr, *deltastr;
     long sourcesize, deltasize;
     char *targetfn;
{
  src_str = sourcestr;
  src_size = sourcesize;
  dlt_str = deltastr;
  dlt_size = deltasize;
  dlt_pnt = dlt_str;

  if (!(build_string(targetfn)))
    return (-1);

  return (0);
}
