/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*LINTLIBRARY*/
/*
 *	Shape/AFS
 *
 *	afretr.c - retrieve interface 
 *
 *	Author: Andreas Lampen, TU-Berlin (andy@coma.UUCP
 *					   andy@db0tui62.BITNET)
 *
 *	$Header: afretr.c[1.4] Wed Feb 22 16:27:50 1989 andy@coma published $
 *
 *	EXPORT:
 *	af_bpfind -- find derived files by attributes
 *	af_find -- find source files by attributes
 *	af_getkey -- find single file by unique attributes
 *	af_dropkey -- release memory associated with filekey 
 *	af_initattrs -- initialize attribute buffer
 */

#include <stdio.h>
#include <string.h>
#ifdef SUNOS_4_0
#include <strings.h>
#endif
#include <sys/types.h>
#include <sys/stat.h>
/* #include <sys/dir.h> */

#include "typeconv.h"
#include "afsys.h"
#include "afs.h"
#include "afarchive.h"

extern int af_errno;

extern Af_hashent af_hashentry;

/*================= collect_lists ====================================*/

LOCAL Af_revlist **collect_lists (pathname, name, type, revlist, nlists)
     char       *pathname, *name, *type;
     Af_revlist **revlist;
     int        *nlists; /* out */
{
  DIR           *dirp;
  struct direct *dirent;
  char          *afpath, *afname, *aftype, dirpath[MAXNAMLEN*4];
  char          fullname[MAXNAMLEN*4], *realloc();
  bool          seconddir = FALSE, mode;
  int           listsiz, i;
  Af_revlist    *af_readattrs();

  listsiz = AF_SEGLEN;
  *nlists = 0;

  /* open named directory  */
  if ((dirp = opendir (pathname)) == (DIR *)0)
    FAIL ("collect_lists", "opendir", AF_ESYSERR, (Af_revlist **)0);

  (void) strcpy (dirpath, pathname);

loop:
  /* lookup all files */
  while ((dirent = readdir (dirp)) != (struct direct *)0)
    {
      (void) sprintf (fullname, "%s/%s\0", dirpath, dirent->d_name);

      /* if entry belongs to binary pool */
      if (af_isbpfile (dirent->d_name))
	continue;

      afname = af_entersym (af_afname (fullname));
      aftype = af_entersym (af_aftype (fullname));

      /* if ((no name given || name equal) && (no type || type equal)) */
      if ( ((name[0] == '*') || !strcmp (name, afname)) &&
	   ((type[0] == '*') || !strcmp (type, aftype))    )
	{
	  (*nlists)++;
	  if (*nlists >= listsiz)
	    {
	      /* realloc memory for revlist */
	      if ((revlist = (Af_revlist **)realloc ((char *)revlist, (unsigned) (sizeof((Af_revlist *)0)*(listsiz + AF_SEGLEN)))) == (Af_revlist **)0)
		FAIL ("collect_lists","realloc", AF_ESYSERR, (Af_revlist **)0);
	      listsiz += AF_SEGLEN;
	    }
	  afpath = af_entersym (af_afpath (fullname));
	  mode = TRUE;
	  if ((revlist[(*nlists)-1] = 
	       af_readattrs (afpath, afname, aftype, &mode))
	                                            == (Af_revlist *)0)
	    {
	      if (af_errno == AF_ENOAFSFILE)
		{
		  (*nlists)--;
		  continue;
		}
	      else
		return ((Af_revlist **)0);
	    }
	  if (mode)
	    {
	      /* see if list is already in "revlists" */
	      /* this loop may be time-consuming */
	      i = 0;
	      while (i < (*nlists)-1)
		{
		  if ((revlist[i]->af_list[0].af_name == afname) &&
		      (revlist[i]->af_cattrs.af_syspath == afpath) &&
		      (revlist[i]->af_list[0].af_type == aftype))
		    {
		      (*nlists)--;
		      break;
		    }
		  i++;
		}
	    }
	}
    }
  closedir (dirp);

  if (!seconddir)
    {
      (void) sprintf (dirpath, "%s%c%s\0", pathname, '/', AF_SUBDIR);
      /* open AFS subdirectory if it exists */
      if ((dirp = opendir (dirpath)) != (DIR *)0)
	{
	  seconddir = TRUE;
	  goto loop;
	}
    }
return (revlist);
}

/*====================================================================
 *    af_abufcmp -- compare attrbuf with version attributes
 *                  returns TRUE if attrs do not match
 *
 *====================================================================*/

LOCAL af_abufcmp (attrbuf, key)
     Af_attrs *attrbuf;
     Af_key   *key;
{
  int match, j;

  /* if (attribute is set && attributes does not match) -- return ERROR */
  
  /*** generation number ***/
  if ((attrbuf->af_gen != AF_NOVNUM) && (attrbuf->af_gen != VATTR(key).af_gen))
    return (ERROR);
  
  /*** revision number ***/
  if ((attrbuf->af_rev != AF_NOVNUM) && (attrbuf->af_rev != VATTR(key).af_rev))
    return (ERROR);

  /*** variant attribute ***/
  if ((attrbuf->af_variant[0]) &&
      (strcmp (attrbuf->af_variant, NOTNIL(VATTR(key).af_variant))))
    return (ERROR);

  /*** state ***/
  if ((attrbuf->af_state != AF_NOSTATE) &&
      (attrbuf->af_state != VATTR(key).af_state))
    return (ERROR);

  /*** owner ***/
  if ( (attrbuf->af_owner.af_username[0]) &&
       (strcmp (attrbuf->af_owner.af_username, CATTR(key).af_ownname)) )
    return (ERROR);
  if ( (attrbuf->af_owner.af_userhost[0]) &&
       (strcmp (attrbuf->af_owner.af_userhost, CATTR(key).af_ownhost)) )
    return (ERROR);
  
  /*** author ***/
  if ( (attrbuf->af_author.af_username[0]) &&
       (strcmp (attrbuf->af_author.af_username, VATTR(key).af_auname)) )
    return (ERROR);
  if ( (attrbuf->af_author.af_userhost[0]) &&
       (strcmp (attrbuf->af_author.af_userhost, VATTR(key).af_auhost)) )
    return (ERROR);
  
  /*** size ***/
  if ((attrbuf->af_size != AF_NOSIZE) &&
      (attrbuf->af_size != VATTR(key).af_fsize) )
    return (ERROR);

  /*** mode ***/
  if ((attrbuf->af_mode != AF_NOMODE) &&
      (attrbuf->af_mode != VATTR(key).af_mode))
    return (ERROR);

  /*** locker ***/
  if ( (attrbuf->af_locker.af_username[0]) &&
       (strcmp (attrbuf->af_locker.af_username,
		NOTNIL(VATTR(key).af_lckname))) )
    return (ERROR);
  if ( (attrbuf->af_locker.af_userhost[0]) &&
       (strcmp (attrbuf->af_locker.af_userhost,
		NOTNIL(VATTR(key).af_lckhost))) )
    return (ERROR);
  
  /*** date of last modification ***/
  if ((attrbuf->af_mtime != AF_NOTIME) &&
      (attrbuf->af_mtime != VATTR(key).af_mtime) )
    return (ERROR);

  /*** date of last access ***/
  if ((attrbuf->af_atime != AF_NOTIME) &&
      (attrbuf->af_atime != VATTR(key).af_atime) )
    return (ERROR);

  /*** date of last status change ***/
  if ((attrbuf->af_ctime != AF_NOTIME) &&
      (attrbuf->af_ctime != VATTR(key).af_ctime) )
    return (ERROR);

  /*** saving date ***/
  if ((attrbuf->af_stime != AF_NOTIME) &&
      (attrbuf->af_stime != VATTR(key).af_stime) )
    return (ERROR);
  
  /*** date of last lock change ***/
  if ((attrbuf->af_stime != AF_NOTIME) &&
      (attrbuf->af_stime != VATTR(key).af_stime) )
    return (ERROR);
  
  /*** user defined attributes ***/
  if (attrbuf->af_udattrs[0] != (char *)0)
    {
      /* if list of user defined attributes is not empty or there */
                                                /* are attributes */
      match = TRUE;
      if ((attrbuf->af_udattrs[0][0] != '\0') || (VATTR(key).af_udanum != 0))
	{
	  /* test all given entries */
	  j=0;
	  while ((attrbuf->af_udattrs[j] != (char *)0) 
		 && (match = !af_match (attrbuf->af_udattrs[j],
					&(VATTR(key).af_uhtab))))
	    j++;
	} /* if */
      if (match == FALSE)
	return (ERROR);
    } /* if */
return (AF_OK);
}


/*====================================================================
 *    af_bpfind
 *
 *====================================================================*/

EXPORT af_bpfind (attrbuf, set)
     Af_attrs *attrbuf;
     Af_set   *set;     /* out */
{
  Af_revlist *bplist, *af_rbplist();
  int        i, maxindex;
  char       *pathname, *getwd(), *malloc();
  Af_key     key;

  /* init set */
  set->af_nkeys = 0;
  set->af_setlen = 0;
  set->af_klist = (Af_key *)0;

  /* build pathname (default is current directory) */
  pathname = af_uniqpath (attrbuf->af_syspath);

  if ((bplist = af_rbplist (pathname)) == (Af_revlist *)0)
    if (af_errno == AF_ENOAFSDIR)
      return (0);
    else
      return (ERROR);

  /* alloacte memory for set */
  if ((set->af_klist = (Af_key *)malloc ((unsigned) (sizeof (Af_key) * bplist->af_nrevs))) == (Af_key *)0)
    FAIL ("bpfind", "malloc", AF_ESYSERR, ERROR);
  set->af_setlen = bplist->af_nrevs;

  /* add all desired bpfiles to set */
  maxindex = bplist->af_nrevs;
  for (i=0; i < maxindex; i++)
    {
      /* skip invalid bpfiles */
      if (!(bplist->af_list[i].af_class & AF_VALID))
	{
	  maxindex++;
	  continue;
	}
      if (((attrbuf->af_name[0] != '*') &&
	   (strcmp (attrbuf->af_name, bplist->af_list[i].af_name))) ||
	  ((attrbuf->af_type[0] != '*') &&
	   (strcmp (attrbuf->af_type, NOTNIL(bplist->af_list[i].af_type)))))
	continue;

      key.af_ldes = bplist;
      key.af_lpos = i;
      if (af_abufcmp (attrbuf, &key))
	continue;
      
      /* else add bpfile to set */
      set->af_klist[set->af_nkeys].af_ldes = bplist;
      set->af_klist[set->af_nkeys].af_lpos = i;
      set->af_nkeys++;
      bplist->af_refcount++;
      bplist->af_list[i].af_nlinks++;
    }
  /* if set is empty */
  if (set->af_nkeys == 0)
    {
      free ((char *)set->af_klist);
      set->af_setlen = 0;
    }

  if (bplist->af_refcount <= 0)
    (void) af_detlist (bplist);

  return (set->af_nkeys);
}


/*====================================================================
 *    af_find
 *
 *====================================================================*/

EXPORT af_find (attrbuf, set)
     Af_attrs *attrbuf;
     Af_set   *set;     /* out */
{
  char          *pathname, *getwd(), *malloc();
  register int  i;
  int           nlists, maxindex;
  Af_revlist    *af_readattrs(), **revlist;
  Af_key        key;
  bool          mode = FALSE;

  /* alloc memory for revlist */
  if ((revlist = (Af_revlist **)malloc ((unsigned) (sizeof((Af_revlist *)0)*AF_SEGLEN))) == (Af_revlist **)0)
    FAIL ("find", "malloc", AF_ESYSERR, ERROR);

  /* init set */
  set->af_nkeys = 0;
  set->af_setlen = 0;
  set->af_klist = (Af_key *)0;

  /* build pathname (default is current directory) */
  pathname = af_uniqpath (attrbuf->af_syspath);

  if ((attrbuf->af_name[0] == '*') || (attrbuf->af_type[0] == '*'))
    {
      if ((revlist = collect_lists (pathname, attrbuf->af_name,
				    attrbuf->af_type, revlist, &nlists))
	  == (Af_revlist **)0)
	return (ERROR);
    }
  else
    {
      if (!attrbuf->af_name[0] && !attrbuf->af_type[0])
	{
	  free ((char *)revlist);
	  return (set->af_nkeys); /* no Af-files found */
	}
      if ((revlist[0] =
	   af_readattrs (pathname, attrbuf->af_name,
			 attrbuf->af_type, &mode)) == (Af_revlist *)0)
	{
	  free ((char *)revlist);
	  if (af_errno == AF_ENOAFSFILE)
	    nlists = 0;
	  else
	    return (ERROR);
	}
      else
	nlists = 1;
    }

  if (nlists == 0)
    return (set->af_nkeys); /* no Af-files found */

  /* alloacte memory for set */
  if ((set->af_klist = (Af_key *)malloc ((unsigned) (sizeof (Af_key) * AF_SEGLEN))) == (Af_key *)0)
    FAIL ("find", "malloc", AF_ESYSERR, ERROR);
  set->af_setlen = AF_SEGLEN;

  /* lookup all revisions in all lists */
  /* this part is implemented quite dull up to now */
  /*     -- the number of "if"'s should be reduced */
  for (;nlists > 0; nlists--)
    {
      maxindex = revlist[nlists-1]->af_nrevs;
      for (i = 0; i < maxindex; i++)
	{
	  /* skip holes in the list */
	  if (!(revlist[nlists-1]->af_list[i].af_class & AF_VALID))
	    {
	      maxindex++;
	      continue;
	    }

	  /* test all attributes -- returnes true if attrs do not match */
	  key.af_ldes = revlist[nlists-1];
	  key.af_lpos = i;
	  if (af_abufcmp (attrbuf, &key))
	    continue;

	  /********************************************/
	  /********** put AF-file into set ************/
	  /********************************************/

	  /* if set is full, enlarge it */
	  if (set->af_nkeys == set->af_setlen)
	    {
	      if ((set->af_klist = 
		   (Af_key *)realloc ((char *)set->af_klist, (unsigned) (sizeof(Af_key) * (set->af_setlen + AF_SEGLEN)))) == (Af_key *)0)
		FAIL ("find", "realloc", AF_ESYSERR, ERROR);
	      set->af_setlen += AF_SEGLEN;
	    }

	  /* add revision to key-set */
	  set->af_klist[set->af_nkeys].af_ldes = revlist[nlists-1];
	  set->af_klist[set->af_nkeys].af_lpos = i;
	  set->af_nkeys++;
	  revlist[nlists-1]->af_refcount++;
	  revlist[nlists-1]->af_list[i].af_nlinks++;
	} /* for all revisions in archive */

      /* if revlist does not contribute to hit set */
      if (revlist[nlists-1]->af_refcount <= 0)
	(void) af_detlist (revlist[nlists-1]);

    } /* for all archives */

  /* if set is empty */
  if (set->af_nkeys == 0)
    {
      free ((char *)set->af_klist);
      set->af_setlen = 0;
    }

  free ((char *)revlist);
  return (set->af_nkeys);
}


/*====================================================================
 *    af_getkey
 *
 *====================================================================*/

EXPORT af_getkey (syspath, name, type, gen, rev, variant, key)
     char   *syspath, *name, *type;
     int    gen, rev;
     /*ARGSUSED*/
     char   *variant; /* unused */
     Af_key *key;
{
  Af_revlist *list, *af_readattrs();
  char *path;
  bool mode = FALSE;

  /* build pathname (default is current directory) */
  path = af_uniqpath (syspath);

  if ((list = af_readattrs (path, name, type, &mode)) == (Af_revlist *)0)
    SFAIL ("getkey", "", AF_ENOREV, ERROR);
  key->af_ldes = list;
 
  /* handle special cases */
  if ((gen < 0) || (rev < 0))
    {
      switch (gen)
	{
	case AF_BUSYVERS: if (af_buildkey (list, gen, rev, key) == ERROR)
	                    SFAIL ("getkey", "", AF_ENOREV, ERROR);
	                  break;
	case AF_LASTVERS: if ((rev != AF_LASTVERS) || (list->af_nrevs == 0))
	                     SFAIL ("getkey", "", AF_ENOREV, ERROR);
	                  /* if busy version is valid */
	                  key->af_lpos = list->af_listlen-1;
			  while (!(VATTR(key).af_class & AF_VALID) || 
				 (VATTR(key).af_state == AF_BUSY))
			    {
			      if (key->af_lpos-- == 0)
				SFAIL ("getkey", "", AF_ENOREV, ERROR);
			    }
			  break;
	case AF_FIRSTVERS: if ((rev != AF_FIRSTVERS) || (list->af_nrevs == 0))
	                     SFAIL ("getkey", "", AF_ENOREV, ERROR);
			   key->af_lpos = 0;
			   while ((VATTR(key).af_state == AF_BUSY) ||
				  (!(VATTR(key).af_class & AF_VALID)))
			     {
			       if (key->af_lpos++ == list->af_listlen-1)
				 SFAIL ("getkey", "", AF_ENOREV, ERROR);
			     }
			   break;
	default: SFAIL ("getkey", "", AF_ENOREV, ERROR);
	}
    }
  else
    {
      if (af_buildkey (list, gen, rev, key) == ERROR)
	SFAIL ("getkey", "", AF_ENOREV, ERROR);
    }

  list->af_refcount++;
  VATTR(key).af_nlinks++;
  return (AF_OK);
}


/*====================================================================
 *    af_dropkey
 *
 *====================================================================*/

EXPORT af_dropkey (key)
     Af_key *key;
{
  if (af_keytest (key))
    SFAIL ("dropkey", "", AF_EINVKEY, ERROR);

  /* decrease reference count in corresponding archive and in attrbuf */
  if (--(key->af_ldes)->af_refcount <= 0)
    (void) af_detlist (key->af_ldes);
  else
    VATTR(key).af_nlinks--;
  return (AF_OK);
}


/*====================================================================
 *    af_initattrs
 *
 *====================================================================*/

EXPORT af_initattrs (attrs)
     Af_attrs *attrs;
{
  attrs->af_host[0] = '\0';
  attrs->af_syspath[0] = '\0';
  attrs->af_name[0] = '*';
  attrs->af_name[1] = '\0';
  attrs->af_type[0] = '*';
  attrs->af_type[1] = '\0';
  attrs->af_gen = AF_NOVNUM;
  attrs->af_rev = AF_NOVNUM;
  attrs->af_variant[0] = '\0';
  attrs->af_state = AF_NOSTATE;
  attrs->af_owner.af_username[0] = '\0';
  attrs->af_owner.af_userhost[0] = '\0';
  attrs->af_author.af_username[0] = '\0';
  attrs->af_author.af_userhost[0] = '\0';
  attrs->af_size = AF_NOSIZE;
  attrs->af_mode = AF_NOMODE;
  attrs->af_locker.af_username[0] = '\0';
  attrs->af_locker.af_userhost[0] = '\0';
  attrs->af_mtime = AF_NOTIME;
  attrs->af_atime = AF_NOTIME;
  attrs->af_ctime = AF_NOTIME;
  attrs->af_stime = AF_NOTIME;
  attrs->af_ltime = AF_NOTIME;
  attrs->af_udattrs[0] = (char *)0;
}

