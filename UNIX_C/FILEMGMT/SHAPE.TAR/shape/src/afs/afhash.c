/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*LINTLIBRARY*/
/*
 *	Shape/AFS
 *
 *	afhash.c -- manage hashtable for user defined attributes
 *
 *	Author: Axel Mahler, TU-Berlin
 *
 *      adapted by: Andreas Lampen, TU-Berlin (andy@coma.UUCP)
 *					      (andy@db0tui62.BITNET)
 *
 *	$Header: afhash.c[1.4] Wed Feb 22 16:27:37 1989 andy@coma published $
 *
 *	EXPORT:
 *	af_hashinit -- initialize hash table
 *      af_hashfree -- detach hash table (free allocated memory)
 *      af_hashsym -- put entry into hashtable
 *      af_fhash -- get hash value
 *      af_replsym -- replace symbol in hashtable
 *      af_delsym -- delete symbol from hashtable
 *      af_symlookup -- look for symbol in hashtable
 *      af_vallookup -- look for single value
 *      af_lhashsyms -- create a list of all symbols in hashtable
 *      af_hashcopy -- copy hashtable
 *	af_match -- test match of user defined attributes
 *      af_dumphtb -- dump hash table
 */
 
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#ifdef SUNOS_4_0
#include <strings.h>
#endif

#include "typeconv.h"
#include "afsys.h"
#include "afs.h"

#ifdef CCOLL
int af_collcnt = 0;
int af_symcount = 0;
#endif

#ifdef MEMDEBUG
extern FILE *memprot;
#endif
#ifdef HASHDEBUG
extern FILE *hashprot;
#endif

Af_hashent af_hashentry; /* hashtable entry that was found during last */
                         /* retrieve operation */

/*=====================================================================
 * af_hashinit -- initialize hash table
 *
 *=====================================================================*/ 

EXPORT af_hashinit (htab, hsize, af_fhash) 
     Af_hash *htab; 
     int hsize, (*af_fhash)();
{
  char *malloc();

  /* initialize Hash - structure */
  htab->hsize = hsize;
  if ((htab->hashtb = (Af_hashent *)malloc ((unsigned) (htab->hsize*sizeof (Af_hashent)))) == NULL)
    FAIL ("hashinit", "malloc", AF_ESYSERR, ERROR);
  htab->fhash = af_fhash;

  /* set hashlist all zeros */
  bzero ((char *)htab->hashtb, htab->hsize*sizeof (Af_hashent));
  return (AF_OK);
}


/*=====================================================================
 * af_hashfree -- detach hash table (free allocated memory)
 *
 * may be slow; perhaps a memory management with af_malloc would be 
 * better.
 *=====================================================================*/ 

EXPORT af_hashfree (htab)
     Af_hash *htab;
{
  register int  i;
  Af_hashent    *entry;

  for (i=0; i<htab->hsize; i++)
    {
      if (htab->hashtb[i].next)
	{
	  entry = htab->hashtb[i].next;
	  do
	    {
#ifdef MEMDEBUG
	      fprintf (memprot, "%x(sym-fr)\n", entry->symbol);
#endif
	      free (entry->symbol);
#ifdef MEMDEBUG
	      fprintf (memprot, "%x(e-fr)\n", entry);
#endif
	      free ((char *)entry); 
	    }
	  while (entry = entry->next);
	}
      if (htab->hashtb[i].symbol)
	{
#ifdef MEMDEBUG
	  fprintf (memprot, "%x(sym-fr)\n", entry->symbol);
#endif
	  free (htab->hashtb[i].symbol);
	}
    }
  free ((char *)htab->hashtb);
  htab->hashtb = (Af_hashent *)0;
}


/*=====================================================================
 * af_hashsym -- put entry into hashtable
 *
 *=====================================================================*/ 

EXPORT char *af_hashsym (htab, symbol, list)
     Af_hash    *htab; 
     char       *symbol;
     Af_revlist *list;
{
  /*
   * put entry into hashtable. Only called, if symbol hasn't been found in 
   * hashtable. Function returns pointer to the symbol-string.
   */
  int symindex;
  Af_hashent *new, *curptr;
  char *retptr, *malloc();

#ifdef HASHDEBUG
  fprintf (hashprot, "HASHSYM: %s\n", symbol);
#endif
  symindex = htab->fhash (htab->hsize, symbol);
  if (!htab->hashtb[symindex].symbol)  /* found entry is not used yet */
    {
      if ((htab->hashtb[symindex].symbol = malloc ((unsigned) (strlen (symbol) + sizeof (char)))) == (char *)0)
	FAIL ("hashsym", "malloc", AF_ESYSERR, (char *)0);
#ifdef MEMDEBUG
      fprintf (memprot, "%x(sym-al) %d bytes ", htab->hashtb[symindex].symbol,
	       strlen (symbol) + sizeof (char));
#endif
      (void) strcpy (htab->hashtb[symindex].symbol, symbol);
      htab->hashtb[symindex].revlist = list;
      htab->hashtb[symindex].next = NULL;
      retptr = htab->hashtb[symindex].symbol;
      curptr = &(htab->hashtb[symindex]);
    }
  else /* oh boy - a collision! */
    {
#ifdef CCOLL
      af_collcnt++;
      fprintf (stderr, "%d'th hash-collision (symbol).\n", af_collcnt);
#endif
      if ((new = (Af_hashent*)malloc ((unsigned) sizeof (Af_hashent))) == (Af_hashent*)0)
	FAIL ("hashsym", "malloc", AF_ESYSERR, (char *)0);
#ifdef MEMDEBUG
      fprintf (memprot, "%x(e-al) %d bytes ", new, sizeof (Af_hashent));
#endif
      if ((new->symbol = malloc ((unsigned) (strlen (symbol) + sizeof (char)))) == (char *)0)
	FAIL ("hashsym", "malloc", AF_ESYSERR, (char *)0);
#ifdef MEMDEBUG
      fprintf (memprot, "%x(sym-al) %d bytes ", new->symbol,
	       strlen (symbol) + sizeof (char));
#endif
      (void) strcpy (new->symbol, symbol);
      new->revlist = list;
      new->next = NULL;
      curptr = &htab->hashtb[symindex];
      while (curptr->next)
	curptr = curptr->next;
      curptr->next = new;
      curptr = curptr->next; /* points to new entry */
      retptr =  new->symbol;
    } /* endif */

  /* filter out double values if list == *0 */
  /* not yet implemented (filter out double values) */

  return (retptr);
} /* end af_hashsym */


EXPORT int af_fhash (htabsiz, hstr) /* from Aho/Ullman */
     int  htabsiz; 
     char *hstr;
{
  register char *p;
  register unsigned long hval, g;

  hval = 0;
  for (p = hstr; (*p!=AF_UDANAMDEL) && (*p!=AF_UDAVALDEL) && (*p!='\0'); p++)
    {
      hval = (hval << 4) ^ (*p);
      if (g = hval & 0xf0000000)
	{
	  hval = hval ^ (g >> 24);
	  hval = hval ^ g;
	}
    }
  return (hval % htabsiz);
}

/*=====================================================================
 * af_replsym -- replace symbol in hashtable
 *
 *=====================================================================*/ 

EXPORT char *af_replsym (htab, symbol, list)
     Af_hash    *htab; 
     char       *symbol;
     Af_revlist *list;
{
  int symindex;
  Af_hashent *entry;
  char *realloc();

#ifdef HASHDEBUG
  fprintf (hashprot, "REPLSYM: %s\n", symbol);
#endif
  symindex = htab->fhash (htab->hsize, symbol);
  if (htab->hashtb[symindex].symbol)  /* found something */
    {
      if (!af_symcmp (&htab->hashtb[symindex], symbol, list))  /* found it ? */
	{ 
	  if ((htab->hashtb[symindex].symbol =
	       realloc (htab->hashtb[symindex].symbol, (unsigned) (strlen (symbol) + sizeof (char)))) == (char *)0)
	    FAIL ("replsym", "realloc", AF_ESYSERR, (char *)0);
	  (void) strcpy (htab->hashtb[symindex].symbol, symbol);
	  htab->hashtb[symindex].revlist = list;
	  return (htab->hashtb[symindex].symbol);
	}
      else /* maybe it is somewhere down the gully */ 
	{ 
	  entry = &htab->hashtb[symindex];
	  while (entry->next)
	    {
	      entry = entry->next;
	      if (!af_symcmp (entry, symbol, list))
		{
		  if ((entry->symbol = 
		       realloc (entry->symbol, (unsigned) (strlen (symbol) + sizeof (char)))) == (char *)0)
		    FAIL ("replsym", "realloc", AF_ESYSERR, (char *)0);
		  (void) strcpy (entry->symbol, symbol);
		  entry->revlist = list;
		  return (entry->symbol);
		}
	    }
	}
    }
  /* when we reach this point, the symbol hasn't been known */

  /* this should never occur */
  FAIL ("replsym", "symbol not found", AF_EINTERNAL, (char *)0);
} /* end af_replsym */

/*=====================================================================
 * af_delsym -- delete symbol from hashtable
 *
 *=====================================================================*/ 

EXPORT af_delsym (htab, symbol, list)
     Af_hash    *htab; 
     char       *symbol;
     Af_revlist *list;
{
  int  symindex;
  Af_hashent *del, *succ;
  char *malloc();

#ifdef HASHDEBUG
  fprintf (hashprot, "DELSYM: %s\n", symbol);
#endif
  symindex = htab->fhash (htab->hsize, symbol);
  if (!htab->hashtb[symindex].symbol) /* no entry found (should never occur) */
    FAIL ("delsym", "symbol not found", AF_EINTERNAL, ERROR); 

  del = &htab->hashtb[symindex];
  if (!af_symcmp (del, symbol, list))  /* found it ? */
    {
#ifdef MEMDEBUG
      fprintf (memprot, "%x(sym-fr)\n", del->symbol);
#endif
      free (del->symbol);

      if (del->next) /* if there are more entries */
	{
#ifdef HASHDEBUG
  fprintf (hashprot, "NEXT: %s\n", del->next->symbol);
#endif
	  del->symbol = del->next->symbol;
          del->revlist = del->next->revlist;
	  succ = del->next->next;
#ifdef MEMDEBUG
  fprintf (memprot, "%x(e-fr)\n", del->next);
#endif
	  free ((char *)del->next);
	  del->next = succ;
	}
      else
	{
	  del->symbol = (char *)0;
          del->revlist = (Af_revlist *)0;
	  del->next = (Af_hashent *)0;
	}
      return (AF_OK);
    }
  else /* search for entry in gully */
    {
      while (del->next)
	{
	  if (!af_symcmp (del->next, symbol, list))
	    {	  
#ifdef MEMDEBUG
	      fprintf (memprot, "%x(sym-fr)\n", del->next->symbol);
#endif
	      free (del->next->symbol);
	      succ = del->next->next;
#ifdef MEMDEBUG
  fprintf (memprot, "%x(e-fr)\n", del->next);
#endif
	      free ((char *)del->next);
	      del->next = succ;
	      return (AF_OK);
	    }
	  del = del->next;
	}
      FAIL ("delsym", "symbol not found (in gully)", AF_EINTERNAL, ERROR);
    }
}

/*=====================================================================
 * af_symlookup -- look for symbol in hashtable
 *
 *=====================================================================*/ 

EXPORT char *af_symlookup (htab, symbol, listin, listout)
     Af_hash    *htab; 
     char       *symbol; 
     Af_revlist *listin, **listout;
{
  /* 
   * Function searches htab for an entry with the given name symbol.
   * If such an entry exists, a pointer to the symbol string is returned
   * and the external variable af_cursymval is set to the corresponding
   * symbolvalue
   */
  int where;
  Af_hashent *targ;
  bool delivernext = FALSE;

  where = htab->fhash (htab->hsize, symbol);
  if (htab->hashtb[where].symbol)  /* well, we found at least something */
    {
      /* if we search a specific revlist in the gully */
      if (listin)
	{
	  if (!af_symcmp (&htab->hashtb[where], symbol, listin))
	    delivernext = TRUE;

	  targ = &htab->hashtb[where];
	  while (targ = targ->next)
	    {
	      if (!af_symcmp (targ, symbol, (Af_revlist *)0))
		{
		  if (delivernext)
		    {
		      af_hashentry = *targ;
		      *listout = targ->revlist;
		      return (targ->symbol);
		    }
		  else
		    if (targ->revlist == listin)
		      delivernext = TRUE;
		}
	    }
	}
      else /* normal case */
	{
	  if (!af_symcmp (&htab->hashtb[where], symbol, (Af_revlist *)0))
	    { 
	      af_hashentry = htab->hashtb[where];
	      if (listout != (Af_revlist **)0)
		*listout = htab->hashtb[where].revlist;
	      return htab->hashtb[where].symbol;
	    }
	  else /* maybe it is somewhere down the gully */ 
	    { 
	      targ = &htab->hashtb[where];
	      while (targ->next)
		{
		  targ = targ->next;
		  if (!af_symcmp (targ, symbol, (Af_revlist *)0))
		    {
		      af_hashentry = *targ;
		      if (listout != (Af_revlist **)0)
			*listout = targ->revlist;
		      return (targ->symbol);
		    }
		}
	    }
	}
    }
  /* when we come to this point, the symbol hasn't been known */
  if (listout != (Af_revlist **)0)
    *listout = (Af_revlist *)0;
  return ((char *)0);
}

/*=====================================================================
 * af_vallookup -- look for single value
 *
 *=====================================================================*/ 

EXPORT char *af_vallookup (entry, value)
     Af_hashent *entry;
     char *value; 
{
  char *valptr;

  if (valptr = index (entry->symbol, AF_UDANAMDEL))
    valptr += sizeof (char);

  /* search until value is found */
  while (af_valcmp (valptr, value))
    {
      if ((valptr = index (valptr, AF_UDAVALDEL)) == (char *)0) 
	return (char *)0;
      valptr += sizeof (char);
    }

  return (valptr);
}

/*=====================================================================
 * af_lhashsyms -- create a list of all symbols in hashtable.
 *                 A (char *)0 terminated pointerlist, listing all
 *                 symbols in the hashtable is created.
 *
 *=====================================================================*/ 

EXPORT af_lhashsyms (htab, symbollist)
     Af_hash *htab;
     char    **symbollist;
{
  register int i, j=0, size=0;
  register Af_hashent *h;
  
  if (htab->hashtb != (Af_hashent *)0)
    {
      for (i = 0; i < htab->hsize; i++)
	if (htab->hashtb[i].symbol != (char *)0)
	  {
	    h = &htab->hashtb[i];
	    while (h) 
	      {
		symbollist[j] = h->symbol;
		size = size + (strlen (h->symbol)+1);
		j++;
		h = h->next;
	      }
	  }
    }
  symbollist[j] = (char *)0;
  return (size);
}


/*=====================================================================
 * af_hashcopy -- copy hash table
 *
 *=====================================================================*/ 

EXPORT af_hashcopy (oldhtab, newhtab) 
     Af_hash *oldhtab, *newhtab;
{
  register i;
  char *af_hashsysm(), *list[AF_MAXUDAS];


  /* initialize new hashtable */
  newhtab->hsize = oldhtab->hsize;
  newhtab->fhash = oldhtab->fhash;

  /* copy hashtable */
  (void) af_lhashsyms (oldhtab, list);
  i=0;
  while (list[i] != (char *)0)
    {
      (void) af_hashsym (newhtab, list[i], (Af_revlist *)0);
      i++;
    }

  return (AF_OK);
}


/*===============================================================
 * af_symcmp -- compare contents of hashtable entry
 *              either of the form name=[value ...]
 *              or                 name; listptr;
 *           Return values like strcmp.
 *
 *==============================================================*/

LOCAL af_symcmp (entry, str, listptr)
     Af_hashent *entry;
     char       *str;
     Af_revlist *listptr;
{
  char *str1;

  /* if a listpointer is given */
  if (listptr)
    {
      if (entry->revlist == listptr)
	return (strcmp (entry->symbol, str));
      else
	return (1);
    }
  else
    {
      str1 = entry->symbol;
      while (*str1 == *str)
	{
	  if ((*str1 == AF_UDANAMDEL) || (*str1 == '\0'))
	    return (0);
	  str1++;
	  str++;
	}
      if (((*str1 == AF_UDANAMDEL) && (*str =='\0')) ||
	  ((*str1 =='\0') && (*str == AF_UDANAMDEL)))
	return (0);
      else
	
return (*str1 - *str);
    }
}

/*===============================================================
 * af_valcmp -- compare single values in a string of the form
 *                          name=[value1 value2 ...]
 *           Return values like strcmp.
 *
 *==============================================================*/

LOCAL af_valcmp (str1, str2)
     char *str1, *str2;
{
  while (*str1 == *str2)
    {
      if ((*str1 == AF_UDAVALDEL) || (*str1 == '\0'))
	return (0);
      str1++;
      str2++;
    }
  if (((*str1 == AF_UDAVALDEL) && (*str2 =='\0')) ||
      ((*str1 =='\0') && (*str2 == AF_UDAVALDEL)))
    return (0);
  else
    return (*str1 - *str2);
}

/*====================================================================
 *    af_match
 *    returnes FALSE if entry matches, else TRUE
 *
 *====================================================================*/

EXPORT af_match (entry, hashtab)
     char    *entry;
     Af_hash *hashtab;
{
  char *valptr, *af_symlookup(), *af_vallookup();

  /* if user defined attribute does not exist */
  if ((af_symlookup (hashtab, entry, (Af_revlist *)0, (Af_revlist **)0))
                                                              == (char*)0)
      return (ERROR);

  /* else compare values */
  if (valptr = index (entry, AF_UDANAMDEL))
    {
      do
	{
	  valptr = valptr + sizeof (char);
	  if ((af_vallookup (&af_hashentry, valptr) == (char *)0)
	      && (*valptr != '\0'))
	    return (ERROR);
	}
      while (valptr = index (valptr, AF_UDAVALDEL));
    }
  return (AF_OK);
}

/**** DEBUG **** DEBUG **** DEBUG **** DEBUG **** DEBUG **** DEBUG ****/

/*=====================================================================
 * af_dumphtb -- dump hashtable
 *
 *=====================================================================*/ 

EXPORT af_dumphtb (htab) /* for debug purposes */
     Af_hash *htab;
{
  register int i;
  register Af_hashent *h;

#ifdef CCOLL
  fprintf (stderr, "Hash-collision statistics:\n");
  fprintf (stderr, "Table-size: %d\tNo. of symbols: %d\tCollisions: %d\n",
	   htab->hsize, af_symcount, af_collcnt);
#endif

  for (i = 0; i < htab->hsize; i++)
    {
      if (htab->hashtb[i].symbol[0])
	{
	  h = &htab->hashtb[i];
	  while (h) 
	    {
	      fprintf (stderr, "\nsymbol: (%d) %s -- list: %x", 
		       i, h->symbol, h->revlist);
	      h = h->next;
	    }
	}
      else fprintf (stderr, ".");
    }
}


