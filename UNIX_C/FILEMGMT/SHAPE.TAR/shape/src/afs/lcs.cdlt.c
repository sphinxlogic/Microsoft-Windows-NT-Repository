/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */

/* ================================================== */
/* ================================================== */
/*                                                    */
/* MODULE-NAME: cdlt        KEY : cd                  */
/*              = compute delta                       */
/* ORIGINAL                                           */
/* AUTHOR : sibylle         DATE: 28/07/87            */
/*                                                    */
/* LAST UPDATE                                        */
/* AUTHOR :                 DATE:                     */
/*                                                    */
/* VERSION: 1.9.2                                     */
/*                                                    */
/* ================================================== */
/*                                                    */
/* PURPOSE:                                           */
/*                computation of the delta;           */
/*                generation of a suffix tree         */
/*                                                    */
/* SPECIALITIES:                                      */
/*                binary files can be handled;        */
/*                usage of register variables;        */
/*                hash-offset computed with           */
/*                shift operations                    */
/*                                                    */
/* EXCEPTIONS, ERRORS:                                */
/*                none                                */
/*                                                    */
/* ================================================== */
/*                                                    */
/*
 * $Header: lcs.cdlt.c[1.0] Wed Feb 22 16:14:17 1989 shape@coma save $
 */


# include "predef.h"
# include <stdio.h>
# include "suffix.h"  

#define HASH(STRING,OFFSET)\
        STRING[OFFSET] +\
        (STRING[OFFSET + 4] << 1) +\
        (STRING[OFFSET + 7] << 2) +\
        (STRING[OFFSET + 11] << 3) +\
        (STRING[OFFSET + 15] << 4) +\
        (STRING[OFFSET + 17] << 5)

extern void ge_add();
extern void ge_move();
extern void ge_init();
extern void ge_finit(); 
extern char *malloc();
extern char *calloc();
extern int bcmp();

LOCAL long src_size = (long) 0;
LOCAL long trg_size = (long) 0;
LOCAL char *src_str = NIL;
LOCAL char *trg_str = NIL;
LOCAL struct suffixes *suff_array = (struct suffixes *) NIL;


LOCAL Bool identical (str1, str2, length1, length2)
     char *str1, *str2;
     long length1, length2;
{
  if (length1 != length2)
    return (FALSE);
  else
    {
      if ((bcmp (str1, str2, (int) length1)) == 0)
	return (TRUE);
      else 
	return (FALSE);
    }
}

LOCAL Bool build_suffix_tree (string,length)
     register char *string;
     long length;
{
  register struct indices *current;
  register int i = 0;
  register int hash;

  suff_array = (struct suffixes *) malloc(TREESIZE * sizeof (struct suffixes));
  if (suff_array == (struct suffixes *) NIL)
    return (FALSE);

  bzero((char *)suff_array, TREESIZE * sizeof(struct suffixes));

  hash =abs(HASH( string, 0));
  if ((suff_array[hash].next  = (struct indices *) malloc( sizeof (struct indices)))== 0)
    return (FALSE);

;
  suff_array[hash].last = suff_array[hash].next;
  suff_array[hash].next->index = 0;
  suff_array[hash].next->next = (struct indices *) NIL;

  for (i = 1; i < (length - (MINBLENG - 1)); i++) 
    {
      hash = abs(HASH(string,i));
      if (suff_array[hash].last != (struct indices *) NIL )
	{
	  if ((current = suff_array[hash].last->next =
	       (struct indices *) malloc( sizeof (struct indices))) == 0)
	    return (FALSE);
	  current->next = (struct indices *) 0;
	  current->index = 0;
/*	  suff_array[hash].last->next = (struct indices * ) 0;
	  suff_array[hash].last->index = 0; */
	}
      else
	{
	  if ((current = suff_array[hash].next =
	  (struct indices *) malloc( sizeof (struct indices))) == 0)
	    return(FALSE);
	  current->next = (struct indices *) 0;
	  current->index = 0;
/*	  suff_array[hash].next->next = (struct indices * ) 0;
	  suff_array[hash].next->index = 0; */
	}
      suff_array[hash].last = current;
  
      current->index = i;
    }
  return (TRUE);
}


LOCAL void find_max_bm(t_str, s_str, t_offset, s_offset, leng)
     register char *t_str, *s_str;
     long t_offset;
     long *s_offset, *leng;
{
  register struct indices *current;
  register int i,j;
  register int hash;
  int off;
  int max;
  
  hash = abs(HASH(t_str, t_offset));
  if (suff_array[hash].next == (struct indices *) NIL)
    *leng = 0;
  else
    {
      max = 0;
      off = 0;
      current = suff_array[hash].next;
      while (current != (struct indices *) NIL)
	{
	  i = current->index;
	  j = t_offset;
	  while ((i < src_size) && (j < trg_size) && 
		 (t_str[j] == s_str[i])) 
	    {
	      j++;
	      i++;
	    }
	  if ((i - current->index > max) &&
	      (t_str[t_offset] == s_str[current->index]) &&
	      (t_str[t_offset + 1] == s_str[current->index + 1]))
	    {
	      max = i - current->index;
	      off = current->index;
	    }
	  current = current->next;
	  if (current != (struct indices *) NIL)
	    {
	      while (((t_offset + max) < trg_size) &&
		     ((current->index + max) < src_size) &&
		     (t_str[t_offset + max] !=
		      s_str[current->index + max]) &&
		     (current->next != (struct indices *) NIL))
		current = current->next;
	    }
	}
      *s_offset = off;
    if(max >= MINBLENG )
      *leng = max;
    else
      *leng = 0;
    }
  return;
}



EXPORT Bool cd_init_delta(sourcestr, targetstr, sourcesz, targetsz)
     char *sourcestr, *targetstr;
     long sourcesz, targetsz;
{
  src_size = sourcesz;
  trg_size = targetsz;
  src_str = sourcestr;
  trg_str = targetstr;

  return(TRUE);

}


EXPORT void cd_finit_delta()
{
  int i;
  struct indices *curind;
  struct indices *delind;
  for(i = 0; i < TREESIZE; i++)
    {
      if(suff_array[i].next != (struct indices *) NIL)
	{
	  curind = suff_array[i].next;
	  while(curind != suff_array[i].last)
	    {
	      delind = curind;
	      curind = curind->next;
	      free((char *)delind);
	    }
	  free((char *)curind);
	}
    }
  free ((char *)suff_array);
  return;
}


EXPORT Bool cd_comp_delta (deltafile)
     char *deltafile;
{
  register long trg_index = 0;
  long src_index, matchlength;
  register long nomtch_trg_index = 0, nomtchlength = 0;

  Bool nomatch = FALSE;

  ge_init (deltafile, trg_str);

  if (identical (src_str, trg_str, src_size, trg_size))
    {
      ge_finit();
      return (TRUE);
    }

  if ((src_size <= MINBLENG) || (trg_size <= MINBLENG))
    {
      ge_add ((long)0, trg_size);
      ge_finit();
      return(TRUE);
    }
  (void) build_suffix_tree (src_str, src_size);
  while (trg_index < (trg_size - (MINBLENG - 1)))
    {
      find_max_bm (trg_str, src_str, trg_index, &src_index, &matchlength);
      if (matchlength > 0)
	{
	  if (nomatch)
	    {
	      ge_add (nomtch_trg_index, nomtchlength); 
	      nomtch_trg_index = 0;
	      nomtchlength = 0;
	      nomatch = FALSE;
	    }
	  ge_move (src_index, matchlength);
	  trg_index = trg_index + matchlength;
	}
      else
	{
	  if (nomatch)
	    nomtchlength++;
	  else
	    {
	      nomatch = TRUE;
	      nomtch_trg_index = trg_index;
	      nomtchlength = 1;
	    }
	  trg_index++;
	  if (trg_index >= trg_size)
	    ge_add (nomtch_trg_index, nomtchlength);
	}
    }
  if (trg_index <= (trg_size - 1))
    {
      if (nomatch)
	ge_add (nomtch_trg_index, (nomtchlength + (trg_size - trg_index)));
      else
	ge_add (trg_index, (trg_size - trg_index));
    }
  ge_finit();
  cd_finit_delta();
  return(TRUE);
}



		  

