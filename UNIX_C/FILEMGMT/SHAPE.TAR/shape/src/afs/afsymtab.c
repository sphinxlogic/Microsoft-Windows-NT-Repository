/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*
 *	Shape/AFS
 *
 *	afsymtab.c -- manage symbol table for AFS
 *
 *	Author: Andreas Lampen, TU-Berlin (andy@coma.UUCP)
 *					  (andy@db0tui62.BITNET)
 *
 *	$Header: afsymtab.c[1.3] Wed Feb 22 16:28:20 1989 andy@coma published $
 *
 *	EXPORT:
 *      af_entersym - add symbol to symtable
 *      af_enterhost - add hostname to symtable
 */

#include <stdio.h>
#include <string.h>
#ifdef SUNOS_4_0
#include <strings.h>
#endif

#include "typeconv.h"
#include "afsys.h"
#include "afs.h"
#include "afarchive.h"

#ifdef MEMDEBUG
extern FILE *memprot;
#endif

/*==========================================================================
 *	definition of hashtable for symbols
 *
 *==========================================================================*/

/* af_symhash should be local; "EXPORT" only for debugging reasons */
EXPORT Af_hash af_symhash;

EXPORT char *af_entersym (symbol)
     char *symbol;
{
  static bool hinit = FALSE; /* indicate if hashtable is yet initialized */
  int af_fhash ();
  char *foundsym;
#ifdef MEMDEBUG
  char *retsym;
#endif

  if (symbol == (char *)0)
    return (symbol);

  if (!hinit)
    {
      /* the reserves symbols could be added to the hashtable here */
      /* but I don't think that it's worthwhile */
      (void) af_hashinit (&af_symhash, AF_MAXSYMS, af_fhash);
      hinit = TRUE;
    }

  /* if symbol is known */
  if ((foundsym = af_symlookup (&af_symhash, symbol, (Af_revlist *)0,
				(Af_revlist **)0)) != (char *)0)
    return (foundsym);

#ifdef MEMDEBUG
  retsym = af_hashsym (&af_symhash, symbol, (Af_revlist *)0);
  fprintf (memprot, "SymTab (%s)\n", symbol);
  return (retsym);
#else
  return (af_hashsym (&af_symhash, symbol, (Af_revlist *)0));
#endif
}

EXPORT char *af_enterhost (hostname)
     char *hostname;
{
  char *hostsym;

  hostsym = af_gethostname();

  if (strcmp (hostname, hostsym))
    return (af_entersym (hostname));
  else
    return (hostsym);
}
