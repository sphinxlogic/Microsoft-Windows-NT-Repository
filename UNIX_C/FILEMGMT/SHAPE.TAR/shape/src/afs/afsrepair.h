/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*
 * AFS-test -- type definitions for archive repair tool
 *
 *	Author:	Andreas Lampen (andy@coma.UUCP
 *				andy@db0tui62.BITNET)
 *
 *	$Header: afsrepair.h[1.2] Wed Feb 22 16:28:06 1989 andy@coma published $
 */

/*** levels ***/
#define SILENT     0
#define NORMAL     1
#define VERBOSE    2
#define EVERYTHING 3

#define MAXREVS 256
#define MAXUDAS 256

typedef struct {
  char    *string;
  int     curPos;
  int     length;
} Input;

typedef struct {
  off_t   datasize;
  int     noOfRevisions;
  char    *host;
  char    *syspath;
  char    *name;
  char    *type;
  char    *ownerName;
  char    *ownerHost;
} ConstAttrs;

typedef struct {
  int     generation;
  int     revision;
  int     state;
  u_short mode;
  char    *variant;
  char    *authorName;
  char    *authorHost;
  char    *lockerName;
  char    *lockerHost;
  time_t  lockTime;
  time_t  modTime;
  time_t  accessTime;
  time_t  statChangeTime;
  time_t  saveTime;
  int     representation;
  off_t   fileSize;
  off_t   deltaSize;
  int     succGen;
  int     succRev;
  int     predGen;
  int     predRev;
} Revision;

typedef struct {
  int     generation;
  int     revision;
  int     size;
  char    *uda[MAXUDAS];
} Udas;

typedef struct {
  int     generation;
  int     revision;
  off_t   size;
  char    *contents;
} Note;

typedef struct {
  int     generation;
  int     revision;
  int     representation;
  off_t   size;
  char    *contents;
} Data;


