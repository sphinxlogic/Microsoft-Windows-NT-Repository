/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*LINTLIBRARY*/
/*
 *	Shape/AFS
 *
 *	aflib.c -- Miscellaneous functions
 *
 *	Author: Andreas Lampen, TU-Berlin (andy@coma.UUCP)
 *					  (andy@db0tui62.BITNET)
 *
 *	$Header: aflib.c[1.6] Wed Feb 22 16:27:41 1989 andy@coma published $
 *
 *	EXPORT:
 *
 *      af_errno -- global variable holding the actual error code
 *	af_serr -- report error without writing error protocol
 *	af_err -- write error protocol
 *	af_wng -- print out warning message
 *      af_perror -- print AFS-error
 *      af_regtmpfile -- register tmp file
 *      af_unregtmpfile -- unregister tmp file
 *      af_reglckfile -- register lock file
 *      af_cpfile -- copy files
 *      af_cleanup -- do cleanup (e.g. upon signal)
 *      af_malloc -- allocate memory
 *      af_realloc -- reallocate memoty
 *      af_free -- free allocated memory segment
 *      af_frmemlist -- free list of allocated memory segments
 *      af_bsearch -- binary search on ordered list of strings
 *      af_checkread -- check read permissions of AF-file
 *      af_checkperm -- check access permissions for AF-file
 */

#include <stdio.h>
#include <string.h>
#ifdef SUNOS_4_0
#include <strings.h>
#endif
#ifdef SYSLOG
#include <syslog.h>
#endif

#include "typeconv.h"
#include "afsys.h"
#include "afs.h"
#include "afarchive.h"

#ifdef MEMDEBUG
extern FILE *memprot;
#endif
#ifdef TMPDEBUG
extern FILE *tmpprot;
#endif

char  *getlogin();

/*=========================================================================
 *     af_serr -- report error without writing error protocol
 *
 *=========================================================================*/

extern int errno;

EXPORT int af_errno, af_nodiag = FALSE;

EXPORT void af_serr (routine, called, errcd)
     char  *routine;
     char  *called;
     int   errcd;
{
  af_nodiag = TRUE;
  af_err (routine, called, errcd);
  af_nodiag = FALSE;
}    

/*=========================================================================
 *     af_err -- write error protocol
 *
 *=========================================================================*/

static char diagstr[265]; /* for diagnistics of AF_EMISC */

static char *errors[] = 
  {
    "", "", "",
    "permission denied",				/*  3 */
    "archive file has changed since last read",		/*  4 */
    "archive file is locked for writing",		/*  5 */
    "no additional space in binary pool",		/*  6 */
    "specified revision must not be a busy version",	/*  7 */
    "specified revision is a derived object",		/*  8 */
    "illegal format of var or uda string",		/*  9 */
    "invalid key",					/* 10 */
    "invalid set",					/* 11 */
    "invalid user",					/* 12 */
    "bad version number",				/* 13 */
    "invalid location of archive",			/* 14 */
    "miscellaneous errors",				/* 15 */
    "invalid mode",					/* 16 */
    "AFS subdirectory missing or not writable",		/* 17 */
    "key does not exist in set",			/* 18 */
    "invalid position in set",				/* 19 */
    "specified revision does not exist",		/* 20 */
    "specified object is no busy version",		/* 21 */
    "specified object is no derived object",		/* 22 */
    "version is not locked or locked by someone else",	/* 23 */
    "specified object is no regular file",		/* 24 */
    "specified object has no versions",			/* 25 */
    "user defined attribute does not exist",		/* 26 */
    "saved versions cannot be modified",		/* 27 */
    "invalid state transition",				/* 28 */
    "string too long",					/* 29 */
    "too many user defined attributes",			/* 30 */
    "wrong state",					/* 31 */
    "error during delta operation",			/* 32 */
    "Archive file inconsistent",			/* 33 */
    "internal error",					/* 34 */
    "no AFS file",					/* 35 */
  };


EXPORT void af_err (routine, called, errcd)
     char  *routine;
     char  *called;
     int   errcd;
{
#ifndef SYSLOG
  FILE *errfile;
  char *af_asctime();
#endif

  if (af_nodiag)
    {
      af_errno = errcd;
      if (af_errno == AF_EMISC)
	(void) strcpy (diagstr, called);
      return; /* do nothing */
    }

#ifdef SYSLOG
  if (!openlog ("AFS", LOG_PID, LOG_LOCAL1))
#else
  if ((errfile = fopen (AF_ERRLOG, "a")) == (FILE *)0)
#endif
    {
      fprintf (stderr, "AFS: cannot open Error-logfile\n");
      return;
    }
  (void) chmod (AF_ERRLOG, 0666);

#ifdef SYSLOG
  switch (errcd)
    {
    case AF_ESYSERR: syslog (LOG_ERR, "%s called af_%s: %s error in %s (%m)", 
			     getlogin(), routine, errors [abs(errcd)], called);
                     break;
    case AF_EINCONSIST:
    case AF_ENOAFSFILE:
    case AF_EINTERNAL: syslog (LOG_ERR, "%s called af_%s: %s (%s)", getlogin(),
			       routine, errors [abs(errcd)], called);
                      break;
    case AF_EMISC: syslog (LOG_ERR, "%s called af_%s: %s ", getlogin(),
			   routine, called);
                   (void) strcpy (diagstr, called);
                   break;
    default: syslog (LOG_ERR, "%s called af_%s: %s", getlogin(), 
		     routine, errors [abs(errcd)]);
    }
#else
  fprintf (errfile, "%s pid[%d] %s",af_gethostname(),getpid (), af_asctime ());
  switch (errcd)
    {
    case AF_ESYSERR: fprintf (errfile, "\t%s called af_%s: %s error in %s\n", 
			     (char *) getlogin(), routine, errors [abs(errcd)], called);
                     break;
    case AF_EINCONSIST:
    case AF_ENOAFSFILE:
    case AF_EINTERNAL: fprintf (errfile, "\t%s called af_%s: %s (%s)\n", (char *) getlogin(), routine, errors [abs(errcd)], called);
                       break;
    case AF_EMISC: fprintf (errfile, "\t%s called af_%s: %s\n", (char *) getlogin(), routine, called);
                   (void) strcpy (diagstr, called);
                   break;
    default: fprintf (errfile, "\t%s called af_%s: %s\n", (char *) getlogin(), routine, errors [abs(errcd)]);
    }
#endif

#ifdef SYSLOG
  closelog ();
#else
  (void) fclose (errfile);
#endif

  af_errno = errcd;
  return;
}

/*=========================================================================
 *     af_wng -- write warning to error protocol
 *
 *=========================================================================*/

EXPORT void af_wng (routine, comment)
     char  *routine, *comment;
{
#ifndef SYSLOG
  FILE *errfile;
  char *af_asctime();
#endif

#ifdef SYSLOG
  if (!openlog ("AFS", LOG_PID, LOG_LOCAL1))
#else
  if ((errfile = fopen (AF_ERRLOG, "a")) == (FILE *)0)
#endif
    {
      fprintf (stderr, "AFS: cannot open Error-logfile\n");
      return;
    }
  (void) chmod (AF_ERRLOG, 0666);

#ifdef SYSLOG
  syslog (LOG_WARNING, "%s called af_%s: %s", getlogin(), routine, comment);
#else
  fprintf (errfile, "%s pid[%d] %s", af_gethostname(), getpid (), af_asctime ());
  fprintf (errfile, "\t%s called af_%s: %s\n", (char *) getlogin(), routine, comment);
#endif

#ifdef SYSLOG
  closelog ();
#else
  (void) fclose (errfile);
#endif
  return;
}


/*=========================================================================
 *     af_perror -- print AFS-error message
 *
 *=========================================================================*/

EXPORT void af_perror (string)
     char  *string;
{
  switch (af_errno)
    {
    case AF_ESYSERR: perror (string);
                     break;
    case AF_EMISC: fprintf (stderr, "%s: %s\n", string, diagstr);
                  break;
    default: fprintf (stderr, "%s: %s\n", string, errors [abs(af_errno)]);
    }
}

/**************************************************************************/

/*================================================================
 *      list of tmp files
 *
 *================================================================*/

static char *tmpfilelist[NOFILE];

LOCAL void rmtmpfiles ()
{
  register i;

  for (i=0; i < NOFILE; i++)
    if (tmpfilelist[i] != (char *)0)
      (void) af_unlink (tmpfilelist[i]);
}

EXPORT void af_regtmpfile (name) /* registrate tmp file */
     char *name;
{
  register int i;

#ifdef TMPDEBUG
  fprintf (tmpprot, "TMP: register %s\n", name);
#endif
  /* look for free space in list */
  for (i=0; i < NOFILE; i++)
    if (tmpfilelist[i] == (char *)0)
      {
	tmpfilelist[i] = name;
	break;
      }
  if (i == NOFILE) /* list is full */
    af_wng ("regtmpfile", "tmpfile list is full -- couldn't register");
}

EXPORT void af_unregtmpfile (name) /* remove tmp file entry */
     char *name;
{
  register i;
#ifdef TMPDEBUG
  fprintf (tmpprot, "TMP: unregister %s\n", name);
#endif
  for (i=0; i < NOFILE; i++)
    if (tmpfilelist[i] == name)
      {
	tmpfilelist[i] = (char *)0;
	break;
      }
  if (i == NOFILE) /* name not found */
    af_wng ("unregtmpfile", "name of tmpfile has not been registered before");
}  

/*=========================================================================
 *     af_reglckfile -- register lock file
 *
 *=========================================================================*/

static char *lckfilename;

EXPORT af_reglckfile (name)
     char *name;
{
  lckfilename = af_entersym (name);
}

LOCAL rmlckfiles ()
{
  (void) unlink (lckfilename);
}

/*=========================================================================
 *     af_cpfile -- copy files
 *
 *=========================================================================*/

EXPORT af_cpfile (source, size, dest)
     char *source;
     off_t size;
     char *dest;
{
  char   cont[BUFSIZ];
  int    bufsiz = BUFSIZ;
  FILE   *sfile, *dfile;
  
  if ((sfile = fopen (source, "r")) == (FILE *)0)
    {
      free (cont);
      return (ERROR);
    }
  if ((dfile = fopen (dest, "w")) == (FILE *) 0)
    {
      free (cont);
      (void) fclose (sfile);
      return (ERROR);
    }

  while (size > 0)
    {
      if (size >= BUFSIZ)
	size -= BUFSIZ;
      else
	{
	  bufsiz = size;
	  size = 0;
	}
      if (!fread (cont, sizeof(char), bufsiz, sfile))
	{
	  (void) fclose (sfile);
	  (void) fclose (dfile);
	  return (ERROR);
	}
      if (!fwrite (cont, sizeof(char), bufsiz, dfile))
	{
	  (void) fclose (sfile);
	  (void) fclose (dfile);
	  return (ERROR);
	}
    }

  (void) fclose (sfile);
  (void) fclose (dfile);
  return (AF_OK);
}


/**************************************************************************/

/*=========================================================================
 *     af_cleanup -- do cleanup
 *
 *=========================================================================*/

EXPORT af_cleanup ()
{
  /* remove tmp files */
  rmtmpfiles ();
  rmlckfiles ();
}

/*=========================================================================
 *     af_malloc -- allocate memory and registrate it
 *     af_realloc -- reallocate memory and registrate it
 *
 * all memory allocated for data in an archive is preceeded by a pointer
 * pointing to the prevoiusly allocated memory segment.
 * So we get a chain of allocated memory segments.
 * ( probably not portable )
 *
 *=========================================================================*/

EXPORT char *af_malloc (list, size)
     Af_revlist *list;
     unsigned   size;
{
  char **mem, *malloc();

  if ((mem = (char **)malloc ((unsigned) (size + sizeof (mem)))) == (char **)0)
    return (char *)0;
#ifdef MEMDEBUG
      fprintf (memprot, "%x (alloc) %d bytes\n", mem, size + sizeof (mem));
#endif

  *mem = list->af_mem;
  list->af_mem = (char *)mem;

  mem++; /* increment by sizeof ptr */

  return ((char *)mem);
}


EXPORT char *af_realloc (list, ptr, size)
     Af_revlist *list;
     char       *ptr;
     unsigned   size;
{
  char **mem, **segptr, **nextptr, *realloc();

  if ((mem = (char **)realloc (ptr, (unsigned) (size + sizeof (mem)))) == (char **)0)
    return (char *)0;
#ifdef MEMDEBUG
      fprintf (memprot, "realloc: old - %x , new - %x %d bytes\n", ptr, mem, size + sizeof (mem));
#endif

  if ((char *)mem == ptr - sizeof ((char *)0)) /* no registration necessary */
    return ((char *)mem);

  segptr = &(list->af_mem); /* remove the implicitely freed memory segment */
  while (*segptr != ptr - sizeof ((char *)0))
    segptr = (char **)*segptr;
  nextptr = (char **)*segptr;
  *segptr = *nextptr;

  *mem = list->af_mem; /* registrate new segment */
  list->af_mem = (char *)mem;

  mem++; /* increment by sizeof ptr */

  return ((char *)mem);
}

EXPORT void af_free (list, ptr)
     Af_revlist *list;
     char       *ptr;
{
  char **segptr, **nextptr;

#ifdef MEMDEBUG
      fprintf (memprot, "%x (free)\n", ptr - sizeof ((char *)0));
#endif
  free (ptr - sizeof ((char *)0));

  segptr = &(list->af_mem); /* remove memory segment from registration list */
  while (*segptr != ptr - sizeof ((char *)0))
    segptr = (char **)*segptr;
  nextptr = (char **)*segptr;
  *segptr = *nextptr;
}


EXPORT void af_frmemlist (list)
     Af_revlist *list;
{
  char **ptr;

  ptr = &(list->af_mem);
  while ((char *)*ptr)
    {
#ifdef MEMDEBUG
      fprintf (memprot, "%x (free)\n", *ptr);
#endif
      free (*ptr);
      ptr = (char **)*ptr;
    }
  list->af_mem = (char *)0;
}

/*========================================================================
 * af_bsearch -- do binary search on ordered list of strings
 *               returns position (-1 if target not found)
 *
 *========================================================================*/

EXPORT af_bsearch (list, size, target)
     char **list;
     int  size;
     char *target;
{
  int hi = size-1, lo=0, pos, res;

  pos = (hi+lo)/2;
  while (hi >= lo)
    {
      if ((res = strcmp (target, list[pos])) == 0)
	return (pos);
      else
	{	  
	  if (res < 0)
	    hi = pos - 1;
	  else /* res > 0 */
	    lo = pos + 1;
	  pos = (hi+lo)/2;
	}
    }
  /* the target string was not found */
  return (ERROR);
}


/*====================================================================
 *   af_checkread -- see if AF-file is readable
 *
 *====================================================================*/

EXPORT af_checkread (key)
     Af_key *key;
{
  Uid_t uid, auuid, ownuid;
  Gid_t augid, owngid;
  int   i, ngroups, gidset[NGROUPS];

  if ((VATTR(key).af_mode & 0004) == 0004) /* readable for world */
    return (AF_OK);

  if ((VATTR(key).af_mode & 0040) == 0040) /* readable for group */
    {
      /* this then part is BSD specific */
      ngroups = getgroups (NGROUPS, gidset);
      augid = af_getgid (VATTR(key).af_auname, VATTR(key).af_auhost);
      owngid = af_getgid (CATTR(key).af_ownname, CATTR(key).af_ownhost);
      for (i=0; i < ngroups; i++)
	{
	  if ((augid == (Gid_t)gidset[i]) || (owngid == (Gid_t)gidset[i]))
	    return (AF_OK);
	}
    }

  if ((VATTR(key).af_mode & 0400) == 0400) /* readable by owner */
    {
      uid = getuid();
      auuid = af_getuid (VATTR(key).af_auname, VATTR(key).af_auhost);
      ownuid = af_getuid (CATTR(key).af_ownname, CATTR(key).af_ownhost);
      if ((auuid == uid) || (ownuid == uid))
	return (AF_OK);
    }

  return (ERROR);
}


/*====================================================================
 *   af_checkperm -- check access permissions for AF-file
 *
 *====================================================================*/

EXPORT af_checkperm (key, mode)
     Af_key *key;
     int    mode;
{
  Uid_t uid = getuid(), lockeruid;
  bool ok = FALSE;

  if (mode & AF_OWNER)
    {
      if (uid == af_getuid (CATTR(key).af_ownname, CATTR(key).af_ownhost))
	ok = TRUE;
    }
  if (!ok && (mode & AF_LOCKHOLDER))
    {
      if ((lockeruid = af_getuid (VATTR(key).af_lckname, 
				  VATTR(key).af_lckhost)) == uid)
	ok = TRUE;
      else
	{
	  /* if object is locked by someone else */
	  if (lockeruid != (Uid_t) ERROR) 
	    goto exit;
	}
    }
  if (!ok && (mode & AF_AUTHOR))
    {
      if (uid == af_getuid (VATTR(key).af_auname, VATTR(key).af_auhost))
	ok = TRUE;
    }
  if (!ok && (mode & AF_WORLD))
    {
      ok = TRUE;
    }
  
 exit:
  /* if access is not ok, or AFS subdir is not writable */
  if (!ok)
    SFAIL ("checkperm", "", AF_EACCES, ERROR);
  if (!(key->af_ldes->af_extent & AF_UXWRITE))
    SFAIL ("checkperm", "", AF_ENOAFSDIR, ERROR);
  return (AF_OK);
}
