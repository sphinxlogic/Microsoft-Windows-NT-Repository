/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*
 *	Shape/AFS
 *
 *	afsys.h - Internal type and Constant-Definitions for the 
 *		  Attribute-Filesystem
 *
 *	Author:	Andreas Lampen (andy@coma.UUCP
 *				andy@db0tui62.BITNET)
 *
 *	$Header: afsys.h[1.5] Wed Feb 22 16:29:46 1989 andy@coma published $
 */

#ifndef _AFSYS_
#define _AFSYS_

/*=========================================================================
 * Installation dependent constants 
 *=========================================================================*/

#include <stdio.h>
#include <sys/types.h>
#ifndef MAXNAMLEN
#include <sys/dir.h>
#endif
#include <sys/param.h>

#ifndef _TYPECONV_
#  ifdef ULTRIX_2_0
#    define Uid_t int
#    define Gid_t int
#  else
#    define Uid_t uid_t
#    define Gid_t gid_t
#  endif
#endif

#ifdef ULTRIX_2_0
#define MAXHOSTNAMELEN 64
#endif

/*=========================================================================
 * general constants 
 *=========================================================================*/

#ifndef TRUE
#define TRUE		1
#endif
#ifndef FALSE
#define FALSE		0
#endif

#define ERROR		-1
#define LOCAL		static
#define EXPORT
#define bool		short

/*=========================================================================
 * Hash stuff
 *=========================================================================*/

typedef struct Af_hshent Af_hashent;

typedef struct Af_hsh Af_hash;

struct Af_hsh { int        hsize,       /* No. of slots in hashtable */
		           (*fhash)();  /* Pointer to hash-function */
		Af_hashent *hashtb;     /* Anchor of hashtable */
	      };

/*=========================================================================
 * Internal Type Definitions
 *=========================================================================*/

/**** buffer for version-independent attributes ****/
typedef struct {
		char	*af_host;               /* hostname */  
		char	*af_syspath;    	/* system path (incl. host) */
		char	*af_ownname;		/* name of owner */
		char	*af_ownhost;		/* host of owner */
	       } Af_cattrs;

/**** buffer for version-dependent attributes ****/
typedef struct {
		char	*af_name;	        /* filename */
		char	*af_type;	        /* filename extension (type) */
		int	af_gen;			/* generation number */
		int	af_rev;			/* revision number */
		char    *af_variant;            /* variant string */
		short	af_state;		/* version state (see below) */
		short   af_class;               /* file class */
		char 	*af_auname;		/* name of author */
		char    *af_auhost;		/* host of author */
		u_short af_mode;		/* protection (from inode) */
		char    *af_lckname;            /* name of locker */
		char    *af_lckhost;            /* host of locker */
		time_t	af_mtime;		/* date of last modification */
		time_t	af_atime;		/* date of last access */
		time_t	af_ctime;		/* date of last status change*/
		time_t	af_stime;		/* save date */
		time_t	af_ltime;		/* date of last lock change */
		off_t	af_notesize;		/* size of note */
		char	*af_note;		/* modification note */
		int     af_udanum;              /* number of uda entries */
		Af_hash af_uhtab;               /* hash table for udefattrs */
		short	af_repr;		/* kind of representation */
		off_t	af_fsize;		/* size of file */
		off_t	af_dsize;		/* size of delta */
		char	*af_data;		/* ptr to chunk or delta */
		char    *af_hashname;           /* name of associated file */
		short   af_nlinks;              /* # of links to attrbuf */
		int	af_succgen,		/* physical 	  */
			af_succrev;		/*	successor */
		int	af_predgen,		/* physical 	    */
			af_predrev;		/*	predecessor */
	       } Af_vattrs;

/**** Descriptor for revision list ****/
typedef struct rvlist Af_revlist;

struct rvlist {
                char	  *af_arfilename;    /* filename of archive */
		time_t    af_lastmod;        /* last mod. of archive file */
		char	  *af_busyfilename;  /* filename of busy version */
		short	  af_nrevs;	     /* number of revs in list */
		short	  af_listlen;	     /* total length of list */
		off_t	  af_datasize;	     /* size of data-segment */
		short	  af_extent;	     /* extent of revision list */
		Af_cattrs af_cattrs;	     /* version-independent attrs */
		Af_vattrs *af_list;	     /* pointer to revision list */
		int       af_refcount;       /* number of keys in use */
		char      *af_mem;           /* list of ptrs to alloc. mem. */
		Af_revlist *af_next;         /* index of next freelist entry */
	      };

/*=========================================================================
 * More Hash stuff
 *=========================================================================*/

struct Af_hshent { char          *symbol;
		   Af_revlist    *revlist;
		   Af_hashent    *next;
		 };
 
/*=========================================================================
 * Internal Installation dependent constants
 *=========================================================================*/

#define AF_MAXSYMS    211       /* size of hashtable for symbols */
#define AF_MAXUDAS     61       /* size of hashtable for user defined attrs */
#define AF_SEGLEN      32       /* size of segment for (re-)allocation */

/**** "syntactical sugar" for user defined attributes ****/
#define AF_UDANAMDEL    '='		/* Delimiter for UDA name in archive */
#define AF_UDAVALDEL	'\01'		/* Delimiter for UDA values in arch. */

/**** UNIX Environment ****/
#define AF_TMPDIR	"/tmp"		/* location of archive files */
#define AF_SUBDIR	"AFS"		/* subdirectory for archives */
#define AF_ARCHEXT	'A'		/* extension for archive names */
#define AF_DATAEXT	'D'		/* extension for datafile names */
#define AF_LCKEXT	'L'		/* extension for lock files */
#define AF_ARCHTMP	'T'		/* extension for temp archive names */
#define AF_DATATMP	'U'		/* extension for temp datafile names */
#define AF_ERRLOG	"/tmp/AFSerrlog" /* Error Log file */

/**** file locking ****/
#define AF_LOCKTIMEOUT  (unsigned) 1    /* wait 1 sec when archive is locked */

/*=========================================================================
 * Internal Constant Definitions
 *=========================================================================*/

/**** general ****/

#define AF_READ         0
#define AF_WRITE        1
#define AF_RDWR         2

/**** representation types ****/

#define AF_CHUNK	0
#define AF_DELTA	1
#define AF_FILE         2 /* version resides in an own file (busy version) */

/**** Version numbering ****/

#define AF_INITGEN	1
#define AF_INITREV	0

/**** Modes for archive manipulation ****/

#define AF_CHANGE      01
#define AF_ALLVERS     02

/**** Environment interaction ****/

#define AF_ENVBPSIZE    "AFSBPSIZ" /* name of environment variable defining */
                                   /* max. number of files in bin. pool */
#define AF_MAXBPSIZE    64         /* max # of files in binary pool if no */
                                   /* environment variable is present */

/**** Permissions for checkperm ****/

#define AF_OWNER        0001
#define AF_AUTHOR       0002
#define AF_LOCKHOLDER   0004
#define AF_WORLD        0010

#define AF_REMOTE       -2

/*=========================================================================
 * Useful macros
 *=========================================================================*/

#define CATTR(keyp)      keyp->af_ldes->af_cattrs
#define VATTR(keyp)      keyp->af_ldes->af_list[keyp->af_lpos]

/* compare filekeys -- returnes 0 if equal (like strcmp) */
#define af_keycmp(key1,key2) (((key1)->af_ldes != (key2)->af_ldes) || ((key1)->af_lpos != (key2)->af_lpos))

/* report error and return */
#define FAIL(msg1,msg2,errcd,retcd) { af_err (msg1, msg2, errcd); return (retcd); }
#define SFAIL(msg1,msg2,errcd,retcd) { af_serr (msg1, msg2, errcd); return (retcd); }

/* convert nil pointer to empty string */
#define NOTNIL(str) (str ? str : "")

/*=========================================================================
 * Declarations
 *=========================================================================*/

char *af_malloc(), *af_realloc(), *af_gtmpname(), *af_gethostname();
char *af_entersym(), *af_replsym(), *af_garname(), *af_gbusname();
char *af_bpfilename();
char *af_rbphashname(), *af_unixname(), *af_gbpname(), *af_uniqpath();
char *af_hashsym(), *af_symlookup(), *af_vallookup(), *af_enterhost();
void af_frmemlist(), af_serr(), af_err(), af_wng();
void af_free(), af_frmemlist(), af_regtmpfile(), af_unregtmpfile();
off_t af_retfsize();
Uid_t af_getuid(), getuid();
Gid_t af_getgid();
#endif
