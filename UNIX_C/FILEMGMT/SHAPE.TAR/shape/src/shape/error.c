/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *RCSid = "$Header: error.c,v 3.1 89/02/20 16:23:18 wolfgang Exp $";
#endif
#ifndef lint
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	error.c,v $
 * Revision 3.1  89/02/20  16:23:18  wolfgang
 * NET-RELEASE
 * 
 * Revision 3.0  89/01/24  11:34:55  wolfgang
 * New System Generation
 * 
 * Revision 2.21  89/01/18  14:43:57  wolfgang
 * changes for lint
 * 
 * Revision 2.20  88/12/22  12:35:49  wolfgang
 * warning 2 added.
 * 
 * Revision 2.19  88/12/21  15:17:54  wolfgang
 * little bug fixed
 * 
 * Revision 2.18  88/12/21  15:02:18  wolfgang
 * changes done for lint
 * 
 * Revision 2.17  88/12/19  13:23:29  wolfgang
 * message 36 added.
 * 
 * Revision 2.16  88/11/24  12:07:23  wolfgang
 * Argument for -confid *must* now be a target name.
 * 
 * Revision 2.15  88/11/23  15:03:39  wolfgang
 * msg 20 changed.
 * 
 * Revision 2.14  88/11/08  19:17:40  wolfgang
 * error 34 added.
 * 
 * Revision 2.13  88/11/07  16:29:06  wolfgang
 * bug fixed. cleanup was done after detecting first syntax error.
 * 
 * Revision 2.12  88/10/26  13:14:12  wolfgang
 * message 30 changed.
 * 
 * Revision 2.11  88/10/14  11:41:17  wolfgang
 * error 33 added.
 * 
 * Revision 2.10  88/10/06  15:35:57  wolfgang
 * orthographic bugs fixed.
 * 
 * Revision 2.9  88/10/03  11:35:36  wolfgang
 * error exit 32 added: if an unknown selection rule is passed to shape
 * via the -R option, shape now stops.
 * 
 * Revision 2.8  88/09/22  16:17:19  wolfgang
 * shape_cleanup() added.
 * 
 * Revision 2.7  88/09/16  19:38:44  wolfgang
 * message 31 added.
 * 
 * Revision 2.6  88/09/15  18:47:01  wolfgang
 * error msg 30 added.
 * 
 * Revision 2.5  88/09/14  12:45:00  wolfgang
 * funny change.
 * 
 * Revision 2.4  88/08/30  14:33:34  wolfgang
 * Little bug fixed in enterprise().
 * 
 * Revision 2.3  88/08/30  14:09:08  wolfgang
 * Added enterprise, spock, and startrek.
 * 
 * Revision 2.2  88/08/22  09:40:47  wolfgang
 * error message 11 changed.
 * 
 * Revision 2.1  88/08/19  10:17:15  wolfgang
 * This version is part of a release
 * 
 */

#include <stdio.h>
#include "shape.h"

extern int cleanup_links();
extern struct linkreg *link_reg;
extern int af_cleanup();
extern char *template;

int errexit(err, mess)
     int err;
     char *mess;
{
if (err != 14)
  {
    cleanup_links(link_reg);
    af_cleanup();
  }
switch (err)
  {
  case 1: /* ???? */
    fprintf(stderr, "shape - multilple defined action for: %s\n", mess);
    exit(1);
  case 2:
    fprintf(stderr, "shape - unknown option: %s\n", mess);
    exit(1);
  case 3:
    if (!strcmp(mess,"enterprise"))
      {
	enterprise(mess);
	exit(1);
      }

    if (!strcmp(mess,"spock"))
      {
	enterprise(mess);
	exit(1);
      }

    if (!strcmp(mess,"startrek"))
      {
	enterprise(mess);
	exit(1);
      }

    if (!strcmp(mess,"love"))
      {
	fprintf(stderr,"Oh, what was it?");
	sleep(2);
	fprintf(stderr," .");
	sleep(2);
	fprintf(stderr,".");
	sleep(2);
	fprintf(stderr,". ");
	fprintf(stderr,"I should remember it");
	sleep(2);
	fprintf(stderr," .");
	sleep(2);
	fprintf(stderr,".");
	sleep(2);
	fprintf(stderr,". ");
	fprintf(stderr,"memory fault. coeur dumped.");
	exit(1);
      }

    if (!strcmp(mess,"future"))
      {
	fprintf(stderr,"Let me think ");
	sleep(2);
	fprintf(stderr,".");
	sleep(2);
	fprintf(stderr,".");
	sleep(2);
	fprintf(stderr,".");
	sleep(2);
	fprintf(stderr," No future ");
	sleep(2);
	fprintf(stderr,".");
	sleep(2);
	fprintf(stderr,".");
	sleep(2);
	fprintf(stderr,".");
	sleep(2);
	fprintf(stderr," definitely!!!\n");
	exit(1);
      }

    if (!strcmp(mess,"me"))
      {
	fprintf(stderr,"shape - don't know how to shape you\n");
	exit(1);
      }

    if (!strcmp(mess,"you"))
      {
	fprintf(stderr,"shape yourself!\n");
	exit(1);
      }

    if (!strcmp(mess,"god"))
      {
	fprintf(stderr,"Don't know how to shave God\n");
	exit(1);
      }
    if (!strcmp(mess,"the queen"))
      {
	fprintf(stderr,"Don't know how to shave the queen\n");
	exit(1);
      }
    if (!strcmp(mess,"panic"))
      {
	fprintf(stderr,"MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n");
	fprintf(stderr,"MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM  MM''MMMMM\n");
	fprintf(stderr,"MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM  M'  MMMMM\n");
	fprintf(stderr,"MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM!\" \'\'\' \"!MMMMMMMMMMMMMMMMMMMMM  M  MM\"'MM\n");
        fprintf(stderr,"MMMMM\'\"M\' MMMMMMMMMMMMMMMV\'                \'\"MMMMMMMMMM.  'MM  M  M' .MM\n");
	fprintf(stderr,"MMM'M :M ;MV MMMMMMMMMM'                      \"MMMMMMMMMM.  \": M .! .MMM\n");
	fprintf(stderr,"MM; M  M :M' AMMMMMMV'                          \"MMMMMMMMM.  .'''. AMMMM\n");
        fprintf(stderr,"MMM ;  ; M:  MMMMMM'                              'MMMMMMM'        MMMMM\n");
        fprintf(stderr,"MMM. ; . M  AMMMMV      @@                 @@      'MMMM\"\" ' '.   .MMMMM\n");
        fprintf(stderr,"MMMM  .    MMMMMV      @''@               @''@       '. ..    ;  .MMMMMM\n");
        fprintf(stderr,"MMM  '\"@\"  MMMMV        @@                 @@         MMMMMM.'   MMMMMMM\n");
        fprintf(stderr,"MMM.  ;        '                                      'MMMMMM.   MMMMMMM\n");
        fprintf(stderr,"MMMM..'.   .MM'                                        MMMMMMM    VMMMMM\n");
        fprintf(stderr,"MMMMM  AMMMMMV                                         'MMMMMM.    MMMMM\n");
        fprintf(stderr,"MMMM'  MMMMMM:                                     ..   MMMMMMM     MMMM\n");
        fprintf(stderr,"MMMM   MMMMMM: @@.                              .'  @@  : 'MMMM.     MMM\n");
        fprintf(stderr,"MMM'   MMM''': :@: '.                         .' ..@@@  :            .MM\n");
        fprintf(stderr,"MMV   ''     : '@@@@: '.                    .'  .@@@@@  ........./MMMMMM\n");
        fprintf(stderr,"MM           :  @@@@@. .' .              .' A. .@@@@@'  MMMMMMMMMMMMMMMM\n");
        fprintf(stderr,"MM:..........:  '@@@@@@@.  ! '. - - - . '.  .@@@@@@@@   MMMMMMMMMMMMMMMM\n");
        fprintf(stderr,"MMMMMMMMMMMMMM   '@@@@@@@@@@@@.    !    .@@@@@@@@@@@@'  MMMMMMMMMMMMMMMM\n");
        fprintf(stderr,"MMMMMMMMMMMMMMM   '@@@@@@@@@@@@@...@@'..@@@@@@@@@@@@'  AMMMMMMMMMMMMMMMM\n");
        fprintf(stderr,"MMMMMMMMMMMMMMMA   '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@   .MMMMMMMMMMMMMMMMM\n");
        fprintf(stderr,"MMMMMMMMMMMMMMMMA    @@@@@@@@@@@@\"'O'OOOO'@@@@@@@'   .MMMMMMMMMMMMMMMMMM\n");
        fprintf(stderr,"MMMMMMMMMMMMMMMMMA    '@@@@@@@VOOOOOOO.OOO @@@V     AMMMMMMMMMMMMMMMMMMM\n");
        fprintf(stderr,"MMMMMMMMMMMMMMMMMMMA     '@@@@OOOOOOOOO.OOO@'     .MMMMMMMMMMMMMMMMMMMMM\n");
        fprintf(stderr,"MMMMMMMMMMMMMMMMMMMMMA        '.@@.OOOOO.OO     .AMMMMMMMMMMMMMMMMMMMMMM\n");
        fprintf(stderr,"MMMMMMMMMMMMMMMMMMMMMMMA.          OOOOO OOOO .MMMMMMMMMMMMMMMMMMMMMMMMM\n");
        fprintf(stderr,"MMMMMMMMMMMMMMMMMMMMMMMMMMA..      OOOOOOOOOOOMMMMMMMMMMMMMMMMMMMMMMMMMM\n");
        fprintf(stderr,"MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMOOOOOOOOOO.MMMMMMMMMMMMMMMMMMMMMMMMMM\n");
        fprintf(stderr,"MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM OOOOOOO.MMMMMMMMMMMMMMMMMMMMMMMMMMMM\n");
        fprintf(stderr,"MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM---MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n");
        fprintf(stderr,"MMMMMM DON'T PANIC MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n");
        fprintf(stderr,"MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n");
        exit(1);
     }
    fprintf(stderr, "shape - don't know how to shape - %s\n", mess);
    exit(1);
  case 4:
    fprintf(stderr, "shape - unknown special macro in cmd: %s\n", mess);
    exit(1);
  case 5:
    fprintf(stderr, "shape - multiply defined selection rule: %s\n", mess);
    exit(1);
  case 6:
    fprintf(stderr, "shape - unknown standard predicate: %s\n", mess);
    exit(1);
  case 7:
    fprintf(stderr, "shape - error in variant section %s\n", mess);
    exit(1);
  case 8:
    fprintf(stderr, "shape - file not found: %s\n", mess);
    exit(1);
  case 9:
    fprintf(stderr, "shape - invalid gen/rev specifikation: %s\n", mess);
    exit(1);
  case 10:
    fprintf(stderr, "shape - error in: %s (please contact guru)\n",mess);
    if (af_errno != 0)
      af_perror("AFS reports");
    exit(1);
  case 11:
    fprintf(stderr, "shape - no description file and no arguments\n");
    exit(1);
  case 12:
    fprintf(stderr, "shape - cannot open file: %s\n", mess);
    exit(1);
  case 13:
    fprintf(stderr, "shape - error during execution; retcode: %s\n", mess);
    exit(1);
  case 14:
    fprintf(stderr, "shape - syntax error: %s\n", mess);
    break;
  case 15:
    fprintf(stderr, "shape - aborted due to syntactical error(s)\n");
    exit(1);
  case 16:
    fprintf(stderr, "shape - invalid state: %s\n", mess);
    exit(1);
  case 17:
    fprintf(stderr, "shape - couldn't find appropriate version of %s.\n", mess);
    exit(1);
  case 18:
    /* not used */
    fprintf(stderr, "shape - aborted!!!\n", mess);
    exit(1);
  case 19:
    fprintf(stderr, "shape - variant name not defined: %s\n", mess);
    exit(1);
  case 20:
    fprintf(stderr, "shape - can't link %s\n", mess);
    fprintf(stderr, "please consult guru\n");
    exit(1);
  case 21:
    fprintf(stderr, "shape - can't unlink %s\n", mess);
    fprintf(stderr, "please consult guru\n");
    exit(1);
  case 22:
    fprintf(stderr, "shape - can't link %s to tmpfile\n", mess);
    fprintf(stderr, "please consult guru\n");
    exit(1);
  case 23:
    fprintf(stderr, "shape - interrupted \n");
    exit(1);
  case 24:
    fprintf(stderr, "shape - can't open include file: %s\n", mess);
    exit(1);
  case 25:
    fprintf(stderr, "shape - infinitely recursive macro caused by line: %s?\n", mess);
    exit(1);
  case 26:
    fprintf(stderr, "shape - invalid macrocitation within heritage field: %s\n",mess);
    exit(1);
  case 27:
    fprintf(stderr, "shape - too many %s\n", mess);
    exit(1);
  case 28:
    fprintf(stderr, "shape - forced stop :-(; couldn't find appropriate version for: %s\n", mess);
    exit(1);
  case 29:
    fprintf(stderr, "shape - attribute too long");
    exit(1);
  case 30:
    fprintf(stderr, "shape - invalid combination of variants (vclass error): %s\n", mess);
    exit(1);
  case 31:
    fprintf(stderr, "shape - syntax error in rule section (delimiter missing)\n");
    exit(1);
  case 32:
    fprintf(stderr, "shape - unknown selection rule name: %s\n", mess);
    exit(1);
  case 33:
    fprintf(stderr, "shape - multiply defined variant name: %s\n", mess);
    exit(1);
  case 34:
    fprintf(stderr, "shape - choose -expandall *or* -expandnothing!\n");
    exit(1);
  case 35:
    fprintf(stderr, "shape - argument %s for -confid is no target name\n",mess);
    exit(1);
  case 36:
    fprintf(stderr, "shape - too many arguments for -force\n");
    exit(1);
  case 37:
    fprintf(stderr, "shape - too many variant definitions\n");
    exit(1);
  case 99:
    fprintf(stderr, "shape - not yet implemented: %s\n", mess);
    exit(1);
  default:
    fprintf(stderr, "shape - impossible error\n");
    exit(1);
  }
}


logerr(string)
     char *string;
{
  errexit(10,string);
}

void warning(no,mess)
     int no;
     char *mess;
{
  switch (no)
    {
    case 1:
      fprintf(stderr,"shape - warning: derived object not saved into bpool; no AFS subdirectory\n");
      return;
    case 2:
      fprintf(stderr," shape -warning: target `%s' not remade because of errors\n", mess);
      return;
    default:
      fprintf(stderr,"shape - impossible warning\n");
      return;
    }
}

      
enterprise(mess)
     char *mess;
{
extern char *getenv();

if((!strcmp("vt100",getenv("TERM"))) || (!strcmp("vt220",getenv("TERM"))) ||
   (!strcmp("vt320",getenv("TERM"))))
  {
printf("\n");
printf("\033[2J\n");
printf("\033[8;20H\033(0lqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqk\n");
printf("\033[9;20Hx                                                x\n");
printf("\033[10;20Hx\033(B Sixteen years ago, the NBC Television Network, \033(0x\n");
printf("\033[11;20Hx\033(B a subsidiary of RCA Corporation, cancelled the \033(0x\n");
printf("\033[12;20Hx\033(B  television series \"Star Trek.\"  Now the time  \033(0x\n");
printf("\033[13;20Hx\033(B has come for the crew of the USS ENTERPRISE to \033(0x\n");
printf("\033[14;20Hx\033(B      taste the sweet fruits of revenge...      \033(0x\n");
printf("\033[15;20Hx                                                x\n");
printf("\033[16;20Hmqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqj\033(B\n");
printf("\033[7;27H \033[7;28H \033[7;29H \033[7;30H \033[7;31H \033[7;32H \n");
printf("\033[7;33H \033[7;34H \033[7;35H \033[7;36H \033[7;37H \033[7;38H\n");
printf("\033[7;39H \033[7;40H \033[7;41H \033[7;42H \033[7;43H \033[7;44H \n");
printf("\033[7;45H \033[7;46H \033[7;47H \033[7;48H \033[7;49H \033[7;50H \n");
printf("\033[7;51H \033[7;52H \033[7;53H \033[7;54H \033[7;55H \033[7;56H \n");
printf("\033[7;57H \033[7;58H \033[7;59H \033[7;60H \033[7;61H \033[7;62H \n");
printf("\033[7;63H \033[7;64H \033[7;65H \033[7;66H \033[7;67H \033[7;68H \n");
printf("\033[7;69H \033[7;70H \033[7;71H \033[7;72H \033[7;73H \033[7;74H \n");
printf("\033[7;27H \033[7;28H \033[7;29H \033[7;30H \033[7;31H \033[7;32H \n");
printf("\033[7;33H \033[7;34H \033[7;35H \033[7;36H \033[7;37H \033[7;38H\n");
printf("\033[7;39H \033[7;40H \033[7;41H \033[7;42H \033[7;43H \033[7;44H \n");
printf("\033[7;45H \033[7;46H \033[7;47H \033[7;48H \033[7;49H \033[7;50H \n");
printf("\033[7;51H \033[7;52H \033[7;53H \033[7;54H \033[7;55H \033[7;56H \n");
printf("\033[7;57H \033[7;58H \033[7;59H \033[7;60H \033[7;61H \033[7;62H \n");
printf("\033[7;63H \033[7;64H \033[7;65H \033[7;66H \033[7;67H \033[7;68H \n");
printf("\033[7;69H \033[7;70H \033[7;71H \033[7;72H \033[7;73H \033[7;74H \n");
printf("\033[7;27H \033[7;28H \033[7;29H \033[7;30H \033[7;31H \033[7;32H \n");
printf("\033[7;33H \033[7;34H \033[7;35H \033[7;36H \033[7;37H \033[7;38H\n");
printf("\033[7;39H \033[7;40H \033[7;41H \033[7;42H \033[7;43H \033[7;44H \n");
printf("\033[7;45H \033[7;46H \033[7;47H \033[7;48H \033[7;49H \033[7;50H \n");
printf("\033[7;51H \033[7;52H \033[7;53H \033[7;54H \033[7;55H \033[7;56H \n");
printf("\033[7;57H \033[7;58H \033[7;59H \033[7;60H \033[7;61H \033[7;62H \n");
printf("\033[7;63H \033[7;64H \033[7;65H \033[7;66H \033[7;67H \033[7;68H \n");
printf("\033[7;69H \033[7;70H \033[7;71H \033[7;72H \033[7;73H \033[7;74H \n");
printf("\033[7;27H \033[7;28H \033[7;29H \033[7;30H \033[7;31H \033[7;32H \n");
printf("\033[7;33H \033[7;34H \033[7;35H \033[7;36H \033[7;37H \033[7;38H\n");
printf("\033[7;39H \033[7;40H \033[7;41H \033[7;42H \033[7;43H \033[7;44H \n");
printf("\033[7;45H \033[7;46H \033[7;47H \033[7;48H \033[7;49H \033[7;50H \n");
printf("\033[7;51H \033[7;52H \033[7;53H \033[7;54H \033[7;55H \033[7;56H \n");
printf("\033[7;57H \033[7;58H \033[7;59H \033[7;60H \033[7;61H \033[7;62H \n");
printf("\033[7;63H \033[7;64H \033[7;65H \033[7;66H \033[7;67H \033[7;68H \n");
printf("\033[7;69H \033[7;70H \033[7;71H \033[7;72H \033[7;73H \033[7;74H \n");
printf("\033[7;27H \033[7;28H \033[7;29H \033[7;30H \033[7;31H \033[7;32H \n");
printf("\033[7;33H \033[7;34H \033[7;35H \033[7;36H \033[7;37H \033[7;38H\n");
printf("\033[7;39H \033[7;40H \033[7;41H \033[7;42H \033[7;43H \033[7;44H \n");
printf("\033[7;45H \033[7;46H \033[7;47H \033[7;48H \033[7;49H \033[7;50H \n");
printf("\033[7;51H \033[7;52H \033[7;53H \033[7;54H \033[7;55H \033[7;56H \n");
printf("\033[7;57H \033[7;58H \033[7;59H \033[7;60H \033[7;61H \033[7;62H \n");
printf("\033[7;63H \033[7;64H \033[7;65H \033[7;66H \033[7;67H \033[7;68H \n");
printf("\033[7;69H \033[7;70H \033[7;71H \033[7;72H \033[7;73H \033[7;74H \n");
printf("\033[7;27H \033[7;28H \033[7;29H \033[7;30H \033[7;31H \033[7;32H \n");
printf("\033[7;33H \033[7;34H \033[7;35H \033[7;36H \033[7;37H \033[7;38H\n");
printf("\033[7;39H \033[7;40H \033[7;41H \033[7;42H \033[7;43H \033[7;44H \n");
printf("\033[7;45H \033[7;46H \033[7;47H \033[7;48H \033[7;49H \033[7;50H \n");
printf("\033[7;51H \033[7;52H \033[7;53H \033[7;54H \033[7;55H \033[7;56H \n");
printf("\033[7;57H \033[7;58H \033[7;59H \033[7;60H \033[7;61H \033[7;62H \n");
printf("\033[7;63H \033[7;64H \033[7;65H \033[7;66H \033[7;67H \033[7;68H \n");
printf("\033[7;69H \033[7;70H \033[7;71H \033[7;72H \033[7;73H \033[7;74H \n");
printf("\033[7;27H \033[7;28H \033[7;29H \033[7;30H \033[7;31H \033[7;32H \n");
printf("\033[7;33H \033[7;34H \033[7;35H \033[7;36H \033[7;37H \033[7;38H\n");
printf("\033[7;39H \033[7;40H \033[7;41H \033[7;42H \033[7;43H \033[7;44H \n");
printf("\033[7;45H \033[7;46H \033[7;47H \033[7;48H \033[7;49H \033[7;50H \n");
printf("\033[7;51H \033[7;52H \033[7;53H \033[7;54H \033[7;55H \033[7;56H \n");
printf("\033[7;57H \033[7;58H \033[7;59H \033[7;60H \033[7;61H \033[7;62H \n");
printf("\033[7;63H \033[7;64H \033[7;65H \033[7;66H \033[7;67H \033[7;68H \n");
printf("\033[7;69H \033[7;70H \033[7;71H \033[7;72H \033[7;73H \033[7;74H \n");
printf("\033[7;27H \033[7;28H \033[7;29H \033[7;30H \033[7;31H \033[7;32H \n");
printf("\033[7;33H \033[7;34H \033[7;35H \033[7;36H \033[7;37H \033[7;38H\n");
printf("\033[7;39H \033[7;40H \033[7;41H \033[7;42H \033[7;43H \033[7;44H \n");
printf("\033[7;45H \033[7;46H \033[7;47H \033[7;48H \033[7;49H \033[7;50H \n");
printf("\033[7;51H \033[7;52H \033[7;53H \033[7;54H \033[7;55H \033[7;56H \n");
printf("\033[7;57H \033[7;58H \033[7;59H \033[7;60H \033[7;61H \033[7;62H \n");
printf("\033[7;63H \033[7;64H \033[7;65H \033[7;66H \033[7;67H \033[7;68H \n");
printf("\033[7;69H \033[7;70H \033[7;71H \033[7;72H \033[7;73H \033[7;74H \n");
printf("\033[7;27H \033[7;28H \033[7;29H \033[7;30H \033[7;31H \033[7;32H \n");
printf("\033[7;33H \033[7;34H \033[7;35H \033[7;36H \033[7;37H \033[7;38H\n");
printf("\033[7;39H \033[7;40H \033[7;41H \033[7;42H \033[7;43H \033[7;44H \n");
printf("\033[7;45H \033[7;46H \033[7;47H \033[7;48H \033[7;49H \033[7;50H \n");
printf("\033[7;51H \033[7;52H \033[7;53H \033[7;54H \033[7;55H \033[7;56H \n");
printf("\033[7;57H \033[7;58H \033[7;59H \033[7;60H \033[7;61H \033[7;62H \n");
printf("\033[7;63H \033[7;64H \033[7;65H \033[7;66H \033[7;67H \033[7;68H \n");
printf("\033[7;69H \033[7;70H \033[7;71H \033[7;72H \033[7;73H \033[7;74H \n");
printf("\033[7;27H \033[7;28H \033[7;29H \033[7;30H \033[7;31H \033[7;32H \n");
printf("\033[7;33H \033[7;34H \033[7;35H \033[7;36H \033[7;37H \033[7;38H\n");
printf("\033[7;39H \033[7;40H \033[7;41H \033[7;42H \033[7;43H \033[7;44H \n");
printf("\033[7;45H \033[7;46H \033[7;47H \033[7;48H \033[7;49H \033[7;50H \n");
printf("\033[7;51H \033[7;52H \033[7;53H \033[7;54H \033[7;55H \033[7;56H \n");
printf("\033[7;57H \033[7;58H \033[7;59H \033[7;60H \033[7;61H \033[7;62H \n");
printf("\033[7;63H \033[7;64H \033[7;65H \033[7;66H \033[7;67H \033[7;68H \n");
printf("\033[7;69H \033[7;70H \033[7;71H \033[7;72H \033[7;73H \033[7;74H \n");
printf("\n");
printf("\033[2J\n");
printf("\033[3;12H\033[1m\033(0~\033(B\033[m\n");
printf("\033[1;2H\033[1m\033(0~\033(B\033[m\n");
printf("\033[2;36H\033[1m.\033[m\n");
printf("\033[4;72H\033[1m\033(0~\033(B\033[m\n");
printf("\033[1;60H\033[1m\033(0~\033(B\033[m\n");
printf("\033[7;40H\033(0~\033(B\n");
printf("\033[8;3H\033(0~\033(B\n");
printf("\033[8;63H\033(0~\033(B\n");
printf("\033[9;75H\033[1m\033(0~\033(B\033[m\n");
printf("\033[13;49H\033[1m\033(0~\033(B\033[m\n");
printf("\033[21;3H\033[1m\033(0~\033(B\033[m\n");
printf("\033[14;67H\033[1m\033(0~\033(B\033[m\n");
printf("\033[13;7H\033[1m\033(0~\033(B\033[m\n");
printf("\033[12;11H\033(0~\033(B\n");
printf("\033[12;12H\033[1m.\033[m\n");
printf("\033[13;17H\033[1m\033(0~\033(B\033[m\n");
printf("\033[14;23H\033[1m\033(0~\033(B\033[m\n");
printf("\033[16;24H\033[1m\033(0~\033(B\033[m\n");
printf("\033[14;32H\033[1m.\033[m\n");
printf("\033[16;31H\033[1m.\033[m\n");
printf("\033[17;15H\033(0~\033(B\n");
printf("\033[6;12H\033[1m\033(0~\033(B\033[m\n");
printf("\033[19;32H\033[1m\033(0~\033(B\033[m\n");
printf("\033[20;79H\033[1m\033(0~\033(B\033[m\n");
printf("\033[10;25H\033[1m\033(0~\033(B\033[m\n");
printf("\033[11;41H\033(0~\033(B\n");
printf("\033[12;42H\033(0~\033(B\n");
printf("\033[7;30H\033(0~\033(B\n");
printf("\033[5;29H\033[1m.\033[m\n");
printf("\033[18;55H\033[1m.\033[m\n");
printf("\033[22;25H\033(0~\033(B\n");
printf("\033[22;68H\033(0~\033(B\033(0\n");
printf("\n");
printf("\033[5;68Hx\n");
printf("\033[6;67Hqnq\n");
printf("\033[7;65H(ooooo)\n");
printf("\033[8;65H( \033[1mRCA\033[m )\n");
printf("\033[9;65H(\033[4m     \033[m)\n");
printf("\033[10;67Hqnq\n");
printf("\033[11;68Hx\n");
printf("\n");
printf("\033[7;1H\033[4m  \033[m\n");
printf("\033[7;1H\033[4m.   \033[m\n");
printf("\033[7;1H\033[4m  .   \033[m\n");
printf("\033[8;1H\033[4m/\033[m\n");
printf("\033[7;1H \033[4m   .   \033[m\n");
printf("\033[8;1H\033[4m //\033[m\n");
printf("\033[9;1Hqq\n");
printf("\033[7;1H\033[4mq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;1H\033[4m  ~//\033[m\n");
printf("\033[9;1Hqqqq\n");
printf("\033[7;1H\033[4mqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;1H\033[4m x~  //\033[m\n");
printf("\033[9;1Hqqqqqq\n");
printf("\033[7;1H\033[4mqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;1H \033[4m ~x   //\033[m\n");
printf("\033[9;1H  qqqqqq\n");
printf("\033[7;1H\033[4mqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;2H ~\033[4m  x   //\033[m\n");
printf("\033[9;3H  qqqqqq\n");
printf("\033[7;1H\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;4H  \033[4m  x   //\033[m\n");
printf("\033[9;5H  qqqqqq\n");
printf("\033[7;1H q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;6H  \033[4m  x   //\033[m\n");
printf("\033[9;7H  qqqqqq\n");
printf("\033[7;2H  q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;8H  \033[4m  x   //\033[m\n");
printf("\033[9;9H  qqqqqq\n");
printf("\033[7;4H  q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;10H  \033[4m  x   //\033[m\n");
printf("\033[9;11H  qqqqqq\n");
printf("\033[7;5H  q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;11H  \033[4m  x   //\033[m\n");
printf("\033[9;12H  qqqqqq\n");
printf("\033[7;6H  q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;12H  \033[4m  x   //\033[m\n");
printf("\033[9;13H  qqqqqq\n");
printf("\033[7;7H  q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;13H  \033[4m  x   //\033[m\n");
printf("\033[9;14H  qqqqqq\n");
printf("\n");
printf("\033[2;14H \033(BRCA now in\n");
printf("\033[3;14Hfiring range,\n");
printf("\033[4;14H  Captain.\033(0\n");
printf("\033[5;23H\\\n");
printf("\033[6;24H\\\n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[2;14H             \033[3;14H             \033[4;14H            \033[4;26H\n");
printf("\033[5;23H \033[6;24H \n");
printf("\n");
printf("\033[2;14H\033(BVery good, Mr. Spock.\n");
printf("\033[3;13HMr. Chekov, fire photon\n");
printf("\033[4;14H     torpedoes!\033(0\n");
printf("\033[5;25Hx\n");
printf("\033[6;25Hx\n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[2;14H                     \033[2;35H\n");
printf("\033[3;13H                       \033[3;35H\n");
printf("\033[4;19H          \033[4;29H\n");
printf("\033[5;25H \033[5;26H\n");
printf("\033[6;25H \033[6;26H\n");
printf("\n");
printf("\033[8;26H\\\n");
printf("\033[9;26H \033(BAye, Keptin!\033(0\n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;26H \033[8;27H\n");
printf("\033[9;26H             \033[9;38H\n");
printf("\n");
printf("\033[8;25H\033[1mf\033[m\n");
printf("\033[8;25H  \033[1mf\033[m\n");
printf("\033[8;27H  \033[1mf\033[m\n");
printf("\033[8;29H  \033[1mf\033[m\n");
printf("\033[8;31H  \033[1mf\033[m\n");
printf("\033[8;33H  \033[1mf\033[m\n");
printf("\033[8;35H  \033[1mf\033[m\n");
printf("\033[8;37H  \033[1mf\033[m\n");
printf("\033[8;39H  \033[1mf\033[m\n");
printf("\033[8;41H  \033[1mf\033[m\n");
printf("\033[8;43H  \033[1mf\033[m\n");
printf("\033[8;45H  \033[1mf\033[m\n");
printf("\033[8;47H  \033[1mf\033[m\n");
printf("\033[8;49H  \033[1mf\033[m\n");
printf("\033[8;51H  \033[1mf\033[m\n");
printf("\033[8;53H  \033[1mf\033[m\n");
printf("\033[8;25H\033[1mf\033[m\n");
printf("\033[8;55H  \033[1mf\033[m\n");
printf("\033[8;25H  \033[1mf\033[m\n");
printf("\033[8;57H  \033[1mf\033[m\n");
printf("\033[8;27H  \033[1mf\033[m\n");
printf("\033[8;59H  \033[1mf\033[m\n");
printf("\033[8;29H  \033[1mf\033[m\n");
printf("\033[8;61H  \033[1mf\033[m\n");
printf("\033[8;31H  \033[1mf\033[m\n");
printf("\033[8;63H~ \033[1mf\033[m\n");
printf("\033[7;64H\033[1m\\x/\n");
printf("\033[8;64H/x\\\033[m\n");
printf("\033[7;64H (o\n");
printf("\033[8;64H ( \033[8;67H\n");
printf("\n");
printf("\033[8;33H  \033[1mf\033[m\n");
printf("\033[8;35H  \033[1mf\033[m\n");
printf("\033[8;37H  \033[1mf\033[m\n");
printf("\033[8;39H  \033[1mf\033[m\n");
printf("\033[8;41H  \033[1mf\033[m\n");
printf("\033[8;43H  \033[1mf\033[m\n");
printf("\033[8;45H  \033[1mf\033[m\n");
printf("\033[8;47H  \033[1mf\033[m\n");
printf("\033[8;49H  \033[1mf\033[m\n");
printf("\033[8;51H  \033[1mf\033[m\n");
printf("\033[8;25H\033[1mf\033[m\n");
printf("\033[8;53H  \033[1mf\033[m\n");
printf("\033[8;25H  \033[1mf\033[m\n");
printf("\033[8;55H  \033[1mf\033[m\n");
printf("\033[8;27H  \033[1mf\033[m\n");
printf("\033[8;57H  \033[1mf\033[m\n");
printf("\033[8;29H  \033[1mf\033[m\n");
printf("\033[8;59H  \033[1mf\033[m\n");
printf("\033[8;31H  \033[1mf\033[m\n");
printf("\033[8;61H  \033[1mf\033[m\n");
printf("\033[8;33H  \033[1mf\033[m\n");
printf("\033[8;63H~ \033[1mf\033[m\n");
printf("\033[8;64H\033[1m\\x/\n");
printf("\033[9;64H/x\\033[m\n");
printf("\033[8;64H ( \033[8;67H\n");
printf("\033[9;64H (\033[4m \033[m\n");
printf("\n");
printf("\033[8;35H  \033[1mf\033[m\n");
printf("\033[8;37H  \033[1mf\033[m\n");
printf("\033[8;39H  \033[1mf\033[m\n");
printf("\033[8;41H  \033[1mf\033[m\n");
printf("\033[8;43H  \033[1mf\033[m\n");
printf("\033[8;45H  \033[1mf\033[m\n");
printf("\033[8;47H  \033[1mf\033[m\n");
printf("\033[8;49H  \033[1mf\033[m\n");
printf("\033[8;51H  \033[1mf\033[m\n");
printf("\033[8;53H  \033[1mf\033[m\n");
printf("\033[8;55H  \033[1mf\033[m\n");
printf("\033[8;57H  \033[1mf\033[m\n");
printf("\033[8;59H  \033[1mf\033[m\n");
printf("\033[8;61H  \033[1mf\033[m\n");
printf("\033[8;63H~ \033[1ma\033[8;64H \033[m\n");
printf("\n");
printf("\033[?5h\033[?5l\033[7m\n");
printf("\033[?5h\033[8;65H \033[8;66H \033[7;66H \033[9;65H \033[7;64H  \033[?5l\n");
printf("\033[?5h\033[6;65H \033[8;63H  \033[9;66H \033[10;67H \033[?5l\n");
printf("\033[5m\033[9;67H \033[0;7m\033[9;64H \033[6;63H \033[8;68H \n");
printf("\033[5m\033[5;67H \033[0;7m\033[8;68H \033[10;71H \033[11;64H \033[8;58H\n");
printf("\033[5m\033[11;68H \033[0;7m\033[?5h\033[m\033[6;68H \033[1m\033[5;66H\n");
printf("\n");
printf("\033[?5l\033[7;1m\033[8;66H  \033[7;67H \033[9;66H  \033[6;66H \033[7;66H\n");
printf("\033[8;65H  \033[10;67H  \033[9;69H \033[7;68H \033[7;70H \033[8;71H \033[8;71H\n");
printf("\033[9;70H  \033[10;70H \033[11;68H \033[10;65H  \033[5;68H \033[7;68H \033[6;65H\n");
printf("\033[9;63H \033[5;65H \033[9;68H \033[6;69H \033[11;67H \033[10;72H \033[11;66H\n");
printf("\033[?5l\033[11;75H \033[8;68H \033[12;67H \033[5;65H \033[7;70H  \033[6;71H \033[7;66H\n");
printf("\033[8;71H  \033[11;71H \033[10;69H \033[11;64H \033[12;72H \033[8;72H \033[8;72H\n");
printf("\033[13;67H  \033[3;69H \033[4;64H \033[8;74H  \033[4;73H \033[15;67H \033[6;65H\n");
printf("\033[12;63H \033[6;73H \033[7;64H \033[12;65H \033[14;69H \033[12;54H \033[11;66H\n");
printf("\n");
printf("\033[0;1m\033[13;51Ha\033[8;77Ha\033[17;67Ha\033[3;63Ha\033[13;73a\n");
printf("\033[14;48Ha\033[2;75a\033[19;67H.\n");
printf("\033[?5h\033[?5l\n");
printf("\033[?5h\033[13;61H.\033[5;56H.\033[?5l\033[2;62H.\033[1;77H.\033[21;67H.\n");
printf("\033[15;45.\033[14;74H.\033[m\033[5l\033[8;79H.\033[16;42H\033[17;39H~\n");
printf("\033[6;75H*\033[9;58H*\033[?5h\033[6;70H\n");
printf("\033[m\033[8;68H \033[7;67H \033[?5l\033[6;68H \033[6;71H \033[8;74H  \033[8;69H \n");
printf("\033[?5h\033[9;64H \033[6;63H \033[4;73H \033[7;68H \033[8;79H \033[10;71H \n");
printf("\033[9;63H \033[8;65H \033[5;65H \033[6;73H \033[8;74H \033[?5l\n");
printf("\033[?5h\033[9;66H  \033[10;67H  \033[5;68H \033[6;69H  \033[9;69H \033[9;58H\n");
printf("\033[7;70H  \033[6;60H \033[7;65H \033[9;68H \033[6;47H\033[?5l\n");
printf("\033[8;63H  \033[7;64H   \033[8;69H  \033[11;67H  \033[6;65H   \033[1;1H\n");
printf("\033[?5h\033[?5l\n");
printf("\033[10;60H \033[10;65H   \033[11;71H \033[9;58H \033[7;64H \033[1;1H\n");
printf("\033[?5h\033[?5l\n");
printf("\033[11;64H \033[11;57H \033[12;67H  \033[3;69H \033[10;69H  \033[1;1H\n");
printf("\033[12;54H \033[12;63H   \033[11;71H \033[9;70H  \033[12;72H \033[1;1H\n");
printf("\033[?5h\033[?5l\n");
printf("\033[13;67H  \033[8;71H  \033[7;69H \033[13;51H \033[13;62H \033[1;1H \n");
printf("\033[8;66H  \033[14;69H \033[5;67H \033[9;65H \033[8;77H \033[1;1H\n");
printf("\033[13;73H \033[15;67H \033[17;67H \033[10;72H \033[3;63H \033[1;1H\n");
printf("\033[14;48H \033[2;75H \033[2;62H \033[14;74H \033[19;67H \033[1;1H\n");
printf("\033[5;75H \033[15;75H \033[19;67H \033[15;45H \033[16;42H \033[1;1H\n");
printf("\033[21;67H \033[4;64H \033[17;39H \033[11;75H \033[6;75H \033[1;1H\n");
printf("\033[1;77H \033[13;61H \033[5;56H \033[1;1H\n");
printf("\n");
printf("\033[8;63H\033(0~\033(B\033[m\n");
printf("\033[4;72H\033[1m\033(0~\033(B\033[m\n");
printf("\n");
printf("\033[3;14H\033(BThey're toast,\n");
printf("\033[4;14H  Captain.\033(0\n");
printf("\033[5;23H\\\n");
printf("\033[6;24H\\\n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[2;14H             \033[3;14H             \033[4;14H            \033[4;26H\n");
printf("\033[5;23H \033[6;24H \n");
printf("\n");
printf("\033[2;14H\033(BExcellent, Mr. Spock.\n");
printf("\033[3;14HAhead warp factor 6,\n");
printf("\033[4;14H     Mr. Sulu.\033(0\n");
printf("\033[5;25Hx\n");
printf("\033[6;25Hx\n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[2;14H                     \033[2;35H\n");
printf("\033[3;14H                     \033[3;35H\n");
printf("\033[4;19H          \033[4;29H\n");
printf("\033[5;25H \033[5;26H\n");
printf("\033[6;25H \033[6;26H\n");
printf("\n");
printf("\033[8;26H\\\n");
printf("\033[9;26H\033(BAye aye, Sir\033(0\n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;27H \033[8;28H \033[8;29H \033[8;30H \033[8;31H \033[8;32H \n");
printf("\033[8;33H \033[8;34H \033[8;35H \033[8;36H \033[8;37H \033[8;38H\n");
printf("\033[8;39H \033[8;40H \033[8;41H \033[8;42H \033[8;43H \033[8;44H \n");
printf("\033[8;45H \033[8;46H \033[8;47H \033[8;48H \033[8;49H \033[8;50H \n");
printf("\033[8;51H \033[8;52H \033[8;53H \033[8;54H \033[8;55H \033[8;56H \n");
printf("\033[8;57H \033[8;58H \033[8;59H \033[8;60H \033[8;61H \033[8;62H \n");
printf("\033[8;26H \033[8;27H\n");
printf("\033[9;26H             \033[9;38H\n");
printf("\n");
printf("\033[7;9H  q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;15H  \033[4m  x   //\033[m\n");
printf("\033[9;16H  qqqqqq\n");
printf("\033[7;10H  q\033[4mqqqqqqqqq\033[m  \033[4m   .  ~\033[m\n");
printf("\033[8;16H  \033[4m  x   //\033[m\n");
printf("\033[9;17H  qqqqqq\n");
printf("\033[7;11H  q\033[4mqqqqqqqqq\033[m  \033[4m   . ~ \033[m\n");
printf("\033[8;17H  \033[4m  x   //\033[m\n");
printf("\033[9;19H  qqqqqq\n");
printf("\033[7;12H  q\033[4mqqqqqqqqq\033[m  \033[4m   .~  \033[m\n");
printf("\033[8;18H  \033[4m  x   //\033[m\n");
printf("\033[9;19H  qqqqqq\n");
printf("\033[7;14H  q\033[4mqqqqqqqqq\033[m  \033[4m  ~.   \033[m\n");
printf("\033[8;20H  \033[4m  x   //\033[m\n");
printf("\033[9;21H  qqqqqq\n");
printf("\033[7;16H  q\033[4mqqqqqqqqq\033[m  \033[4m~  .   \033[m\n");
printf("\033[8;22H  \033[4m  x   //\033[m\n");
printf("\033[9;23H  qqqqqq\n");
printf("\033[7;18H  q\033[4mqqqqqqqqq\033[m~ \033[4m   .   \033[m\n");
printf("\033[8;24H  \033[4m  x   //\033[m\n");
printf("\033[9;25H  qqqqqq\n");
printf("\033[7;20H  q\033[4mqqqqqqqqq\033[m  \033[4m   .  ~\033[m\n");
printf("\033[8;26H  \033[4m  x   //\033[m\n");
printf("\033[9;27H  qqqqqq\n");
printf("\033[7;22H  q\033[4mqqqqqqqqq\033[m  \033[4m   .~  \033[m\n");
printf("\033[8;28H  \033[4m  x   //\033[m\n");
printf("\033[9;29H  qqqqqq\n");
printf("\033[7;24H  q\033[4mqqqqqqqqq\033[m  \033[4m  ~.   \033[m\n");
printf("\033[8;30H  \033[4m  x   //\033[m\n");
printf("\033[9;31H  qqqqqq\n");
printf("\033[7;26H  q\033[4mqqqqqqqqq\033[m  \033[4m~  .   \033[m\n");
printf("\033[8;32H  \033[4m  x   //\033[m\n");
printf("\033[9;33H  qqqqqq\n");
printf("\033[7;28H  q\033[4mqqqqqqqqq\033[m~ \033[4m   .   \033[m\n");
printf("\033[8;34H  \033[4m  x   //\033[m\n");
printf("\033[9;35H  qqqqqq\n");
printf("\033[7;30H  q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[7;30H~\n");
printf("\033[8;36H  \033[4m  x   //\033[m\n");
printf("\033[9;37H  qqqqqq\n");
printf("\033[7;32H  q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;38H  \033[4m  x   //\033[m\n");
printf("\033[9;39H  qqqqqq\n");
printf("\033[7;34H  q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;40H  \033[4m  x   //\033[m\n");
printf("\033[9;41H  qqqqqq\n");
printf("\033[7;36H  q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;42H  \033[4m  x   //\033[m\n");
printf("\033[9;43H  qqqqqq\n");
printf("\033[7;38H  q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;44H  \033[4m  x   //\033[m\n");
printf("\033[9;45H  qqqqqq\n");
printf("\033[7;40H~  q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;46H   \033[4m  x   //\033[m\n");
printf("\033[9;47H   qqqqqq\n");
printf("\033[7;43H   q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;49H   \033[4m  x   //\033[m\n");
printf("\033[9;50H   qqqqqq\n");
printf("\033[7;46H   q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;52H   \033[4m  x   //\033[m\n");
printf("\033[9;53H   qqqqqq\n");
printf("\033[7;49H   q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;55H   \033[4m  x  ~//\033[m\n");
printf("\033[9;56H   qqqqqq\n");
printf("\033[7;52H   q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;58H   \033[4m  x   //\033[m\n");
printf("\033[9;59H   qqqqqq\n");
printf("\033[7;55H   q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;61H  ~\033[4m  x   //\033[m\n");
printf("\033[9;62H   qqqqqq\n");
printf("\033[7;58H   q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;64H   \033[4m  x   //\033[m\n");
printf("\033[8;63H~\n");
printf("\033[9;65H   qqqqqq\n");
printf("\033[7;61H   q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;67H   \033[4m  x   //\033[m\n");
printf("\033[9;68H   qqqqqq\n");
printf("\033[7;64H   q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;70H   \033[4m  x   //\033[m\n");
printf("\033[9;71H   qqqqqq\n");
printf("\033[7;67H   q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;73H   \033[4m  x   //\033[m\n");
printf("\033[9;74H   qqqqqq\n");
printf("\033[9;75H\033[1m~\033[m\n");
printf("\033[7;70H   q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;76H   \033[4m  x   //\033[m\n");
printf("\033[9;77H   qqqqqq\n");
printf("\033[7;73H   q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[8;79H   \033[4m  x   //\033[m\n");
printf("\033[7;76H   q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[7;79H   q\033[4mqqqqqqqqq\033[m  \033[4m   .   \033[m\n");
printf("\033[7;80H  \033[8;80H  \033[9;80H  \033[10;80H\n");
printf("\n");
printf("\033(B\033[23;1H\n");
printf("\n");
printf("\n");
  }
else
  {
  printf("shape - know how to shape %s only on vt110, vt220, or vt320 terminals\n", mess);
  exit(1);
}
}


