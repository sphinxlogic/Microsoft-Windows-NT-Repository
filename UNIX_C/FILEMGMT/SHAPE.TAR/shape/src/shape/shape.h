/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
/*
 * $Log:	shape.h,v $
 * Revision 3.0  89/01/24  11:36:09  wolfgang
 * New System Generation
 * 
 * Revision 2.14  88/12/21  15:11:02  wolfgang
 * changes done for lint
 * 
 * Revision 2.13  88/12/19  13:22:04  wolfgang
 * bpoolflg, nobpoolflg, forceflg added.
 * 
 * Revision 2.12  88/11/08  11:02:39  wolfgang
 * explg & noexpflg added.
 * 
 * Revision 2.11  88/11/02  13:30:20  wolfgang
 * This version is part of a release
 * 
 * Revision 2.10  88/10/14  17:12:12  wolfgang
 * changes don for new handling of variants: struct vardefs.
 * 
 * Revision 2.9  88/09/22  16:15:45  wolfgang
 * struct linkreg changed: member newfn added.
 * 
 * Revision 2.8  88/09/15  17:25:27  wolfgang
 * struct varclass changed: int active added.
 * 
 * Revision 2.7  88/08/23  15:34:53  wolfgang
 * rebuildflg added.
 * 
 * Revision 2.6  88/08/22  10:16:40  wolfgang
 * Added constant: nostdfile (indicates that no standard input file has been
 * found).
 * 
 * Revision 2.5  88/08/19  14:09:46  wolfgang
 * *** empty log message ***
 * 
 * Revision 2.4  88/08/18  10:25:55  wolfgang
 * This version is part of a release
 * 
 * Revision 2.3  88/08/12  08:58:17  wolfgang
 * This version is part of a release
 * 
 */


typedef int Bool;

#define TRUE 1
#define FALSE 0
#define VOID int
#define EOL '\n'
#define EOS '\0'
#define NIL ((char *) 0)

#include "afs.h"
#include <strings.h>

#define SMILEY -1
#define GRIMMY -2

extern int af_errno;

extern char *rindex();
extern char *index();
extern char *malloc();
extern char *realloc();

extern int errexit();

extern Bool pattern();
extern Bool attr();
extern Bool attrnot();
extern Bool attrvar();
extern Bool attrnotvar();
extern Bool attrlt();
extern Bool attrgt();
extern Bool attrle();
extern Bool attrge();
extern Bool attrmin();
extern Bool attrmax();
extern Bool getfromcid();
extern Bool msg();
extern Bool stopit();
extern Bool tunix();

#define ATTRNAME "__ATTRS__="
#define MAXATTRLENGTH 10000

#define MAX_ATTR 10000
#define MAXDEPTH 10

#define MAXPATHLIST 256
extern char *pathlist[MAXPATHLIST][2];
extern int lastpath;

extern char *curvpath[];

extern char rbrule[];
extern char rbfile[];

Bool debugflg;
Bool envflg;
Bool fileflg;
Bool nostdfile;
Bool ignoreflg;
Bool goflg;
Bool noexflg;
Bool printflg;
Bool questflg;
Bool ruleflg;
Bool silentflg;
Bool touchflg;
Bool stdinflg;
Bool confid;
Bool rebuildflg;
Bool stopflg;
Bool tunixflg;
Bool logflg;
Bool expflg;
Bool noexpflg;

Bool bpoolflg;
Bool nobpoolflg;
Bool forceflg;

FILE *cid;
FILE *logfd;

Bool doublecolon;
extern Bool suffs_deleted;

struct linked_list {
  char *string;
  struct linked_list *nextstring;
};

struct hash
{
  char *name;
  char *entry;
  struct hash *next;
};

extern struct hash *hashtab[];

struct cmds
{
  char *command;
  struct cmds *nextcmd;
};

#define MAXTARGS 128
#define MAXHERIT 32
#define MAXDEPS 256
#define MAXCMDS 32
struct rules
{
  char *name;
  Af_set date;
  Bool done;
  Bool doublecolon;
  char *firstdep;                 /* possibly selection rule name */
  char *deplist[MAXDEPS];
  char *heritage[MAXHERIT];
  char *targetlist[MAXHERIT];
  struct cmds *cmdlist;
  struct rules *nextrule;
};

extern struct rules *ruletab[];
extern struct rules *stdruletab[];
extern int lastrule;    /* index of last std rule */

struct list
{
  int (*selfunc)();
  char *parn;
  char *parv;
  int i;
  struct list *cont;
};

extern struct selection_rules *sels[];


struct linkreg {
  char *fn;
  char *newfn;
  Bool busy_exist;
  struct linkreg *next;
};

#define MAXVARIANTS 32
#define MAXVMACROS 32 

struct vardef {
  char *name;
  char *vmacros[MAXVMACROS];
  char *vflags;
  char *vpath;
};

struct varclass {
  char *name;
  int active;
  char *variants[MAXVARIANTS];
};

#define MAXPREDS 32

struct selection_rules
{
  char *name;
  struct list *predlist[MAXPREDS];
  struct selection_rules *next;
};

