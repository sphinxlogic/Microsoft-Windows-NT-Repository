/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *RCSid = "$Header: attr.c,v 3.1 89/02/08 12:45:55 wolfgang Exp $";
#endif
#ifndef lint
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	attr.c,v $
 * Revision 3.1  89/02/08  12:45:55  wolfgang
 * performance improved.
 * 
 * Revision 3.0  89/01/24  11:34:30  wolfgang
 * New System Generation
 * 
 * Revision 2.15  89/01/03  12:59:57  wolfgang
 * changes done for lint
 * 
 * Revision 2.14  88/12/21  14:57:30  wolfgang
 * changes done for lint
 * 
 * Revision 2.13  88/11/22  17:25:17  wolfgang
 * bug fixed in pattern().
 * 
 * Revision 2.11  88/11/21  15:51:50  wolfgang
 * return code of all malloc's checked
 * 
 * Revision 2.10  88/10/27  16:39:03  wolfgang
 * bug fixed (new variant handling).
 * 
 * Revision 2.9  88/09/20  10:05:30  wolfgang
 * biug fixed. the offset of 'real' vpath's wasn't correct, if 2 attrvars
 * occured.
 * 
 * Revision 2.8  88/09/19  18:10:19  wolfgang
 * concatenation of vflags added (if more than 1 attrvar occurs).
 * 
 * Revision 2.7  88/09/16  13:29:36  wolfgang
 * minor bug fixed in msg()
 * 
 * Revision 2.6  88/09/16  11:04:11  wolfgang
 * bug fixed in msg.
 * 
 * Revision 2.5  88/09/15  18:42:51  wolfgang
 * bugs in attrvar fixed.
 * 
 * Revision 2.4  88/09/15  12:43:12  wolfgang
 * bug fixed in attrvar.
 * 
 * Revision 2.3  88/09/14  14:04:46  wolfgang
 * new global variable introduced. decomposition of vpath added.
 * 
 * Revision 2.2  88/08/22  15:31:40  wolfgang
 * Handling of two types added: syspath & host; are necessary for the
 * production of confid's.
 * 
 * Revision 2.1  88/08/19  10:16:41  wolfgang
 * This version is part of a release
 * 
 */

#include <stdio.h>

#include "shape.h"
#include "attr.h"

extern struct vardef *vardefs[];
extern char dollarplus[];

int err;
int pathi;
extern char *re_comp();
extern int re_exec();
extern char *replace();
extern char *malloc();
extern char *strcpy();

extern int errexit();
extern Bool check_vclass();
extern int get_attr_type();
extern int get_state_no();

Bool pattern(string, patt)
     char *string;
     char *patt;
{
char *retcode;
char *pat;

if (string == NIL)
  return(FALSE);

pat = replace(patt);

if ((retcode = re_comp(pat)) != 0)
  {
    (void) strcat(retcode, ": re_comp");
    errexit(10, "re_comp");
  }

#ifdef DEBUG_ATTR
printf("pattern: string = #%s#; pattern = #%s# ", string, pat);
#endif DEBUG_ATTR

if (re_exec(string) == 1)
    return (TRUE);
else
  return(FALSE);
}

Bool msg(name, value, set)
     char *name;
     char *value;
     /*ARGSUSED*/
     Af_set *set;
{
  char *p;
  char message2[256];
  char *message;
  int len;
  (void) strcpy(message2,name);
  if (strcmp(value,""))
    {
      (void) strcat(message2,", ");
      (void) strcat(message2,value);
    }
  message = &message2[0];

  len = strlen(message) - 1;
  
  if (((message[0] == '\'') && (message[len] == '\'')) ||
      ((message[0] == '\"') && (message[len] == '\"')))
    {
      message[len] = '\0';
      message++;
    }

  if (((p = index(message,'$')) != NIL) && (*(p+1) == '+'))
    {
      *p = '\0';
      printf("%s%s%s", message, dollarplus, p+2);
    }
  else
    {
      if (strcmp(message,""))
	printf("%s", message);
    }
  printf("\n");

  (void) strcpy(dollarplus,"");

  return(TRUE);
}

Bool tunix(name, value, set)
     /*ARGSUSED*/
     char *name;
     char *value;
     Af_set *set;
{
  tunixflg = TRUE;
  return (TRUE);
}

Bool stopit(name, value, set)
     /*ARGSUSED*/
     char *name;
     char *value;
     Af_set *set;
{
  stopflg = TRUE;
  return(TRUE);
}

Bool attr(name, value, set)
     char *name;
     char *value;
     Af_set *set;
{
int attr_type;
int nrofkeys;
int cur_pos;
int pos1;
int i;

Af_key cur_key;

Af_attrs cur_attrbuf;

Bool last_match;
Bool found;
Bool attr_found;

char val1[256];
char *val2;
char *val3;

#ifdef DEBUG_ATTR
printf("attr(): name = #%s#,  value = #%s#\n", name,value);
#endif DEBUG_ATTR


attr_type = get_attr_type(name);

if ((nrofkeys = af_nrofkeys(set)) == -1)
  errexit(10, "af_nrofkeys");

#ifdef DEBUG_ATTR
printf("nrofkeys = %d\n", nrofkeys);
#endif DEBUG_ATTR

switch (attr_type)
  {
  case 0 :
    if ((af_sortset(set,AF_ATTGEN)) == -1)
      errexit(10,"af_sortset");
    break;
  case 1 :
    if ((af_sortset(set,AF_ATTREV)) == -1)
      errexit(10,"af_sortset");
    break;
  case 2 :
    if ((af_sortset(set,AF_ATTSTATE)) == -1)
      errexit(10,"af_sortset");
    break;
  case 3 :
    if ((af_sortset(set,AF_ATTAUTHOR)) == -1)
      errexit(10,"af_sortset");
    break;
  case 4 :
    errexit(10,"group id");
    break;
  case 5 :
    if ((af_sortset(set,AF_ATTVERSION)) == -1)
      errexit(10,"af_sortset");
    break;
  case 6 :
    if ((af_sortset(set,AF_ATTVARIANT)) == -1)
      errexit(10,"af_sortset");
    break;
  case 7:
    if ((af_sortset(set,AF_ATTSPATH)) == -1)
      errexit(10,"af_sortset");
    break;
  case 8:
    if ((af_sortset(set,AF_ATTHOST)) == -1)
      errexit(10,"af_sortset");
    break;
  default :
    if ((af_sortset(set,name)) == -1)
      errexit(10,"af_sortset");
  }

cur_pos = 0;
last_match = FALSE;
found = FALSE;

while ((cur_pos < nrofkeys) && (!(last_match)))
  {
    if ((err = af_setgkey(set, cur_pos, &cur_key)) == -1)
      errexit(10, "af_setgkey");
    
    if (af_gattrs(&cur_key, &cur_attrbuf) == -1)
      errexit(10, "af_gattrs");

    switch (attr_type)
      {
      case 0 :
	if (cur_attrbuf.af_gen != atoi(value))
	  {
	    if (found)
	      last_match = TRUE;
	    else
	      cur_pos++;    /* here probably better : */
           /* if (cur_attrbuf.af_gen > atoi(value)) */
           /*   cur_pos = nrofkeys;                  */
           /* else                                   */
           /*   cur_pos++;                           */
	  }
	else
	  {
	    if (!(found))
	      {
		found = TRUE;
		pos1 = cur_pos;
	      }
	    cur_pos++;
	  }
	break;
      case 1 :
	if (cur_attrbuf.af_rev != atoi(value))
	  {
	    if (found)
	      last_match = TRUE;
	    else
	      cur_pos++;
	  }
	else
	  {
	    if (!(found))
	      {
		found = TRUE;
		pos1 = cur_pos;
	      }
	    cur_pos++;
	  }
	break;
      case 2 :
	if ((int) cur_attrbuf.af_state != get_state_no(value))
	  {
	    if (found)
	      last_match = TRUE;
	    else
	      cur_pos++;
	  }
	else
	  {
	    if (!(found))
	      {
		found = TRUE;
		pos1 = cur_pos;
	      }
	    cur_pos++;
	  }
	break;
      case 3 :
	if (strcmp(cur_attrbuf.af_author.af_username,value))
	  {
	    if (found)
	      last_match = TRUE;
	    else
	      cur_pos++;
	  }
	else
	  {
	    if (!(found))
	      {
		found = TRUE;
		pos1 = cur_pos;
	      }
	    cur_pos++;
	  }
	break;
      case 4 :
	errexit(10,"group id");
	break;
      case 5 :
	(void) strcpy(val1, value);
	if ((val2 = index(val1,'.')) == 0)
	  errexit(9, value);
	val2[0] = '\0';
	val2++;
	if ((atoi(val1) == cur_attrbuf.af_gen)
	    && (atoi(val2) == cur_attrbuf.af_rev))
	  {
	    if (!(found))
	      {
		found = TRUE;
		pos1 = cur_pos;
	      }
	    cur_pos++;
	  }
	else
	  {
	    if (found)
	      last_match = TRUE;
	    else
	      cur_pos++;
	  }
	break;
      case 6:
	/* Variants */
	if ((strcmp(cur_attrbuf.af_variant,value)) != 0)
	  {
	    if (found)
	      last_match = TRUE;
	    else
	      cur_pos++;
	  }
	else
	  {
	    if (!(found))
	      {
		found = TRUE;
		pos1 = cur_pos;
	      }
	    cur_pos++;
	  }
	break;
      case 7 :
	if (strcmp(cur_attrbuf.af_syspath,value))
	  {
	    if (found)
	      last_match = TRUE;
	    else
	      cur_pos++;
	  }
	else
	  {
	    if (!(found))
	      {
		found = TRUE;
		pos1 = cur_pos;
	      }
	    cur_pos++;
	  }
	break;
      case 8 :
	if (strcmp(cur_attrbuf.af_host,value))
	  {
	    if (found)
	      last_match = TRUE;
	    else
	      cur_pos++;
	  }
	else
	  {
	    if (!(found))
	      {
		found = TRUE;
		pos1 = cur_pos;
	      }
	    cur_pos++;
	  }
	break;
      default :
/* af_udattrs must contain a '=', even if they don't contain a value */
/* currently only the first value (if existing) in the string is     */
/* considered */
	i = 0;
	attr_found = FALSE;
/* find name in list of udattrs */
	while ((!(attr_found)) && (i < AF_MAXUDAS) &&
	       (cur_attrbuf.af_udattrs[i] != NIL))
	  {
	    (void) strcpy(val1, cur_attrbuf.af_udattrs[i]);
	    if ((val2 = index(val1, '=')) == 0)
	      errexit(10, "attr");
	    val2[0] = '\0';
	    if (strcmp(name, val1) != 0)
	      i++;
	    else
	      attr_found = TRUE;
	  }
/* name should be found now */
	if (!(attr_found))
	  errexit(10, "attr");

/* value comparison */
	val2++;
	if (*val2 == '\0')        /* no value given is considered as != */
	  {
	    if (found)
	      last_match = TRUE;
	    else
	      cur_pos++;
	  }
	else
	  {
	    if ((val3 = index(val2, AF_UDAVALDEL)) != 0) 
	      val3[0] = '\0';     /* only first value in attrbuf is     */
                                  /* considered; parameter value should */
                                  /* contain only one value             */
	    if (strcmp(value, val2) == 0)
	      {
		if (!(found))
		  {
		    found = TRUE;
		    pos1 = cur_pos;
		  }
		cur_pos++;
	      }
	    else
	      {
		if (found)
		  last_match = TRUE;
		else
		  cur_pos++;
	      }
	  }
      }
  }

if (!(found))
  cur_pos = 0;
else
  {
    i = pos1;
    while (i > 0)
      {
	if (af_setposrmkey(set, 0) == -1)
	  errexit(10, "af_setposrmkey");
	i--;
	cur_pos--;
	nrofkeys--;
      }
  }

while (cur_pos < nrofkeys)
  {
    if (af_setposrmkey(set, cur_pos) == -1)
      errexit(10, "af_setposrmkey");
    nrofkeys--;
  }
if (nrofkeys == 0)
  {
#ifdef DEBUG_ATTR
    printf("no matches\n");
#endif DEBUG_ATTR
    return (FALSE);
  }
else
  {
#ifdef DEBUG_ATTR
    printf("matches:\n");
    nrofkeys = af_nrofkeys(set);
    i = 0;
    while (i < nrofkeys)
      {
	af_setgkey(set, i, &cur_key);
	af_gattrs(&cur_key, &cur_attrbuf);
	printf("version %d.%d\n", cur_attrbuf.af_gen, cur_attrbuf.af_rev);
	i++;
      }
#endif DEBUG_ATTR
    return (TRUE);
  }
}

Bool attrnot(name, value, set)
     char *name;
     char *value;
     Af_set *set;
{
int attr_type;
int nrofkeys;
int cur_pos;
int pos1;
int i;

Af_key cur_key;

Af_attrs cur_attrbuf;

Bool last_match;
Bool found;
Bool attr_found;

char val1[256];
char *val2;
char *val3;

#ifdef DEBUG_ATTR
printf("attrnot(): name = #%s#,  value = #%s#\n", name,value);
#endif DEBUG_ATTR


attr_type = get_attr_type(name);

if ((nrofkeys = af_nrofkeys(set)) == -1)
  errexit(10, "af_nrofkeys");

#ifdef DEBUG_ATTR
printf("nrofkeys = %d\n", nrofkeys);
#endif DEBUG_ATTR

switch (attr_type)
  {
  case 0 :
    if ((af_sortset(set,AF_ATTGEN)) == -1)
      errexit(10,"af_sortset");
    break;
  case 1 :
    if ((af_sortset(set,AF_ATTREV)) == -1)
      errexit(10,"af_sortset");
    break;
  case 2 :
    if ((af_sortset(set,AF_ATTSTATE)) == -1)
      errexit(10,"af_sortset");
    break;
  case 3 :
    if ((af_sortset(set,AF_ATTAUTHOR)) == -1)
      errexit(10,"af_sortset");
    break;
  case 4 :
    errexit(10,"group id");
    break;
  case 5 :
    if ((af_sortset(set,AF_ATTVERSION)) == -1)
      errexit(10,"af_sortset");
    break;
  case 6 :
    if ((af_sortset(set,AF_ATTVARIANT)) == -1)
      errexit(10,"af_sortset");
    break;
  case 7:
    if ((af_sortset(set,AF_ATTSPATH)) == -1)
      errexit(10,"af_sortset");
    break;
  case 8:
    if ((af_sortset(set,AF_ATTHOST)) == -1)
      errexit(10,"af_sortset");
    break;
  default :
    if ((af_sortset(set,name)) == -1)
      errexit(10,"af_sortset");
  }

cur_pos = 0;
last_match = FALSE;
found = FALSE;

while ((cur_pos < nrofkeys) && (!(last_match)))
  {
    if ((err = af_setgkey(set, cur_pos, &cur_key) == -1))
      errexit(10, "af_setgkey");
    
    if (af_gattrs(&cur_key, &cur_attrbuf) == -1)
      errexit(10, "af_gattrs");

#ifdef DEBUG_ATTR
    printf("key[%d] -> version %d.%d\n", cur_pos, cur_attrbuf.af_gen, cur_attrbuf.af_rev);
#endif DEBUG_ATTR

    switch (attr_type)
      {
      case 0 :
	if (cur_attrbuf.af_gen != atoi(value))
	  {
	    if (found)
	      last_match = TRUE;
	    else
	      cur_pos++;    /* here probably better : */
           /* if (cur_attrbuf.af_gen > atoi(value)) */
           /*   cur_pos = nrofkeys;                  */
           /* else                                   */
           /*   cur_pos++;                           */
	  }
	else
	  {
	    if (!(found))
	      {
		found = TRUE;
		pos1 = cur_pos;
	      }
	    cur_pos++;
	  }
	break;
      case 1 :
	if (cur_attrbuf.af_rev != atoi(value))
	  {
	    if (found)
	      last_match = TRUE;
	    else
	      cur_pos++;
	  }
	else
	  {
	    if (!(found))
	      {
		found = TRUE;
		pos1 = cur_pos;
	      }
	    cur_pos++;
	  }
	break;
      case 2 :
	if ((int) cur_attrbuf.af_state != atoi(value))
	  {
	    if (found)
	      last_match = TRUE;
	    else
	      cur_pos++;
	  }
	else
	  {
	    if (!(found))
	      {
		found = TRUE;
		pos1 = cur_pos;
	      }
	    cur_pos++;
	  }
	break;
      case 3 :
	if (strcmp(cur_attrbuf.af_author.af_username,value))
	  {
	    if (found)
	      last_match = TRUE;
	    else
	      cur_pos++;
	  }
	else
	  {
	    if (!(found))
	      {
		found = TRUE;
		pos1 = cur_pos;
	      }
	    cur_pos++;
	  }
	break;
      case 4 :
	errexit(10,"group id");
	break;
      case 5 :
	(void) strcpy(val1, value);
	if ((val2 = index(val1,'.')) == 0)
	  errexit(9, value);
	val2[0] = '\0';
	val2++;
	if ((atoi(val1) == cur_attrbuf.af_gen)
	    && (atoi(val2) == cur_attrbuf.af_rev))
	  {
	    if (!(found))
	      {
		found = TRUE;
		pos1 = cur_pos;
	      }
	    cur_pos++;
	  }
	else
	  {
	    if (found)
	      last_match = TRUE;
	    else
	      cur_pos++;
	  }
	break;
      case 6:
	/* Variants */
	if ((strcmp(cur_attrbuf.af_variant,value)) != 0)
	  {
	    if (found)
	      last_match = TRUE;
	    else
	      cur_pos++;
	  }
	else
	  {
	    if (!(found))
	      {
		found = TRUE;
		pos1 = cur_pos;
	      }
	    cur_pos++;
	  }
	break;
      case 7 :
	if (strcmp(cur_attrbuf.af_syspath,value))
	  {
	    if (found)
	      last_match = TRUE;
	    else
	      cur_pos++;
	  }
	else
	  {
	    if (!(found))
	      {
		found = TRUE;
		pos1 = cur_pos;
	      }
	    cur_pos++;
	  }
	break;
      case 8 :
	if (strcmp(cur_attrbuf.af_host,value))
	  {
	    if (found)
	      last_match = TRUE;
	    else
	      cur_pos++;
	  }
	else
	  {
	    if (!(found))
	      {
		found = TRUE;
		pos1 = cur_pos;
	      }
	    cur_pos++;
	  }
	break;
      default :
/* af_udattrs must contain a '=', even if they don't contain a value */
/* currently only the first value (if existing) in the string is     */
/* considered */
	i = 0;
	attr_found = FALSE;
/* find name in list of udattrs */
	while ((!(attr_found)) && (i < AF_MAXUDAS) &&
	       (cur_attrbuf.af_udattrs[i] != NIL))
	  {
	    (void) strcpy(val1, cur_attrbuf.af_udattrs[i]);
	    if ((val2 = index(val1, '=')) == 0)
	      errexit(10, "attrnot");
	    val2[0] = '\0';
	    if (strcmp(name, val1) != 0)
	      i++;
	    else
	      attr_found = TRUE;
	  }
/* name should be found now */
	if (!(attr_found))
	  errexit(10, "attrnot");

/* value comparison */
	val2++;
	if (*val2 == '\0')        /* no value given is considered as != */
	  {
	    if (found)
	      last_match = TRUE;
	    else
	      cur_pos++;
	  }
	else
	  {
	    if ((val3 = index(val2, AF_UDAVALDEL)) != 0) 
	      val3[0] = '\0';     /* only first value in attrbuf is     */
                                  /* considered; parameter value should */
                                  /* contain only one value             */
	    if (strcmp(value, val2) == 0)
	      {
		if (!(found))
		  {
		    found = TRUE;
		    pos1 = cur_pos;
		  }
		cur_pos++;
	      }
	    else
	      {
		if (found)
		  last_match = TRUE;
		else
		  cur_pos++;
	      }
	  }
      }
  }

if (!(found))
  {
#ifdef DEBUG_ATTR
    printf("matches:\n");
    i = 0;
    while (i < nrofkeys)
      {
	af_setgkey(set, i, &cur_key);
	af_gattrs(&cur_key, &cur_attrbuf);
	printf("version %d.%d\n", cur_attrbuf.af_gen, cur_attrbuf.af_rev);
	i++;
      }
#endif DEBUG_ATTR

    return (TRUE);
  }
else
  {
    i = (cur_pos - pos1);
    while (i > 0)
      {
	if (af_setposrmkey(set, pos1) == -1)
	  errexit(10, "af_setposrmkey");
	i--;
	nrofkeys--;
      }
    if (nrofkeys == 0)
      {
#ifdef DEBUG_ATTR
	printf("no match\n");
#endif DEBUG_ATTR
	return (FALSE);
      }
    else
      {
#ifdef DEBUG_ATTR
	printf("matches:\n");
	nrofkeys = af_nrofkeys(set);
	i = 0;
	while (i < nrofkeys)
	  {
	    af_setgkey(set, i, &cur_key);
	    af_gattrs(&cur_key, &cur_attrbuf);
	    printf("version %d.%d\n", cur_attrbuf.af_gen, cur_attrbuf.af_rev);
	    i++;
	  }
#endif DEBUG_ATTR

	return (TRUE);
      }
  }
}

Bool attrlt(name, value, set)
     char *name;
     char *value;
     Af_set *set;
{
int attr_type;
int nrofkeys;
int cur_pos;
int i;

Af_key cur_key;

Af_attrs cur_attrbuf;

Bool match;
Bool found;

char val1[256];
char *val2;
char *val3;

#ifdef DEBUG_ATTR
printf("attrlt(): name = #%s#,  value = #%s#\n", name,value);
#endif DEBUG_ATTR


attr_type = get_attr_type(name);

if ((nrofkeys = af_nrofkeys(set)) == -1)
  errexit(10, "af_nrofkeys");

#ifdef DEBUG_ATTR
printf("nrofkeys = %d\n", nrofkeys);
#endif DEBUG_ATTR

switch (attr_type)
  {
  case 0 :
    if ((af_sortset(set,AF_ATTGEN)) == -1)
      errexit(10,"af_sortset");
    break;
  case 1 :
    if ((af_sortset(set,AF_ATTREV)) == -1)
      errexit(10,"af_sortset");
    break;
  case 2 :
    if ((af_sortset(set,AF_ATTSTATE)) == -1)
      errexit(10,"af_sortset");
    break;
  case 3 :
    if ((af_sortset(set,AF_ATTAUTHOR)) == -1)
      errexit(10,"af_sortset");
    break;
  case 4 :
    errexit(10,"group id");
    break;
  case 5 :
    if ((af_sortset(set,AF_ATTVERSION)) == -1)
      errexit(10,"af_sortset");
    break;
  case 6 :
    if ((af_sortset(set,AF_ATTVARIANT)) == -1)
      errexit(10,"af_sortset");
    break;
  case 7:
    if ((af_sortset(set,AF_ATTSPATH)) == -1)
      errexit(10,"af_sortset");
    break;
  case 8:
    if ((af_sortset(set,AF_ATTHOST)) == -1)
      errexit(10,"af_sortset");
    break;
  default :
    if ((af_sortset(set,name)) == -1)
      errexit(10,"af_sortset");
  }

cur_pos = 0;
match = TRUE;

while ((cur_pos < nrofkeys) && match)
  {
    if ((err = af_setgkey(set, cur_pos, &cur_key)) == -1)
      errexit(10, "af_setgkey");
    
    if (af_gattrs(&cur_key, &cur_attrbuf) == -1)
      errexit(10, "af_gattrs");

#ifdef DEBUG_ATTR
    printf("key[%d] -> version %d.%d\n", cur_pos, cur_attrbuf.af_gen, cur_attrbuf.af_rev);
#endif DEBUG_ATTR

    switch (attr_type)
      {
      case 0 :
	if (cur_attrbuf.af_gen < atoi(value))
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 1 :
	if (cur_attrbuf.af_rev < atoi(value))
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 2 :
	if ((int) cur_attrbuf.af_state < atoi(value))
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 3 :
	if ((strcmp(cur_attrbuf.af_author.af_username,value)) < 0)
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 4 :
	errexit(10,"group id");
	break;
      case 5 :
	(void) strcpy(val1, value);
	if ((val2 = index(val1,'.')) == 0)
	  errexit(9, value);
	val2[0] = '\0';
	val2++;
	if (atoi(val1) < cur_attrbuf.af_gen)
	  match = FALSE;
	else
	  {
	    if ((atoi(val1) == cur_attrbuf.af_gen) &&
		(atoi(val2) <= cur_attrbuf.af_rev))
	      match = FALSE;
	    else
	      cur_pos++;
	  }
	break;
      case 6:
	/* Variants */
	if ((strcmp(cur_attrbuf.af_variant,value)) < 0)
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 7 :
	if ((strcmp(cur_attrbuf.af_syspath,value)) < 0)
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 8 :
	if ((strcmp(cur_attrbuf.af_host,value)) < 0 )
	  cur_pos++;
	else
	  match = FALSE;
	break;
      default :
/* af_udattrs must contain a '=', even if they don't contain a value */
/* currently only the first value (if existing) in the string is     */
/* considered */
	i = 0;
	found = FALSE;
/* find name in list of udattrs */
	while ((!(found)) && (i < AF_MAXUDAS) &&
	       (cur_attrbuf.af_udattrs[i] != NIL))
	  {
	    (void) strcpy(val1, cur_attrbuf.af_udattrs[i]);
	    if ((val2 = index(val1, '=')) == 0)
	      errexit(10, "attrlt");
	    val2[0] = '\0';
	    if (strcmp(name, val1) != 0)
	      i++;
	    else
	      found = TRUE;
	  }
/* name should be found now */
	if (!(found))
	  errexit(10, "attrlt");

/* value comparison */
	val2++;
	if (*val2 == '\0')        /* no value given is considered as != */
	  cur_pos++;
	else
	  {
	    if ((val3 = index(val2, AF_UDAVALDEL)) != 0) 
	      val3[0] = '\0';     /* only first value in attrbuf is     */
                                  /* considered; parameter value should */
                                  /* contain only one value             */
	    if (strcmp(value, val2) <= 0)
	      match = FALSE;
	    else
	      cur_pos++;
	  }
      }
  }  
if (match)
  {
#ifdef DEBUG_ATTR
    printf("matches:\n");
    i = 0;
    while (i < nrofkeys)
      {
	af_setgkey(set, i, &cur_key);
	af_gattrs(&cur_key, &cur_attrbuf);
	printf("version %d.%d\n", cur_attrbuf.af_gen, cur_attrbuf.af_rev);
	i++;
      }
#endif DEBUG_ATTR

    return (TRUE);
  }
else                             /* remove keys from set if necessary */
  {
    while (cur_pos < nrofkeys)
      {
	if (af_setposrmkey(set, cur_pos) == -1)
	  errexit(10, "af_setposrmkey");
	nrofkeys--;
      }
    if (nrofkeys == 0)
      {
#ifdef DEBUG_ATTR
	printf("no matches\n");
#endif DEBUG_ATTR

	return (FALSE);
      }
    else
      {
#ifdef DEBUG_ATTR
	printf("matches:\n");
	nrofkeys = af_nrofkeys(set);
	i = 0;
	while (i < nrofkeys)
	  {
	    af_setgkey(set, i, &cur_key);
	    af_gattrs(&cur_key, &cur_attrbuf);
	    printf("version %d.%d\n", cur_attrbuf.af_gen, cur_attrbuf.af_rev);
	    i++;
	  }
#endif DEBUG_ATTR

	return (TRUE);
      }
  }

}

Bool attrgt(name, value, set)
     char *name;
     char *value;
     Af_set *set;
{
int attr_type;
int nrofkeys;
int cur_pos;
int i;

Af_key cur_key;

Af_attrs cur_attrbuf;

Bool match;
Bool found;

char val1[256];
char *val2;
char *val3;

#ifdef DEBUG_ATTR
printf("attrgt(): name = #%s#,  value = #%s#\n", name,value);
#endif DEBUG_ATTR

attr_type = get_attr_type(name);

if ((nrofkeys = af_nrofkeys(set)) == -1)
  errexit(10, "af_nrofkeys");

#ifdef DEBUG_ATTR
printf("nrofkeys = %d\n", nrofkeys);
#endif DEBUG_ATTR

switch (attr_type)
  {
  case 0 :
    if ((af_sortset(set,AF_ATTGEN)) == -1)
      errexit(10,"af_sortset");
    break;
  case 1 :
    if ((af_sortset(set,AF_ATTREV)) == -1)
      errexit(10,"af_sortset");
    break;
  case 2 :
    if ((af_sortset(set,AF_ATTSTATE)) == -1)
      errexit(10,"af_sortset");
    break;
  case 3 :
    if ((af_sortset(set,AF_ATTAUTHOR)) == -1)
      errexit(10,"af_sortset");
    break;
  case 4 :
    errexit(10,"group id");
    break;
  case 5 :
    if ((af_sortset(set,AF_ATTVERSION)) == -1)
      errexit(10,"af_sortset");
    break;
  case 6 :
    if ((af_sortset(set,AF_ATTVARIANT)) == -1)
      errexit(10,"af_sortset");
    break;
  case 7:
    if ((af_sortset(set,AF_ATTSPATH)) == -1)
      errexit(10,"af_sortset");
    break;
  case 8:
    if ((af_sortset(set,AF_ATTHOST)) == -1)
      errexit(10,"af_sortset");
    break;
  default :
    if ((af_sortset(set,name)) == -1)
      errexit(10,"af_sortset");
  }

cur_pos = (nrofkeys - 1);
match = TRUE;

while ((cur_pos >= 0) && match)
  {
    if ((err = af_setgkey(set, cur_pos, &cur_key)) == -1)
      errexit(10, "af_setgkey");
    
    if (af_gattrs(&cur_key, &cur_attrbuf) == -1)
      errexit(10, "af_gattrs");

#ifdef DEBUG_ATTR
    printf("key[%d] -> version %d.%d\n", cur_pos, cur_attrbuf.af_gen, cur_attrbuf.af_rev);
#endif DEBUG_ATTR

    switch (attr_type)
      {
      case 0 :
	if (cur_attrbuf.af_gen > atoi(value))
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 1 :
	if (cur_attrbuf.af_rev > atoi(value))
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 2 :
	if ((int) cur_attrbuf.af_state > atoi(value))
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 3 :
	if ((strcmp(cur_attrbuf.af_author.af_username,value)) > 0)
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 4 :
	errexit(10,"group id");
	break;
      case 5 :
	(void) strcpy(val1, value);
	if ((val2 = index(val1,'.')) == 0)
	  errexit(9, value);
	val2[0] = '\0';
	val2++;
	if (atoi(val1) > cur_attrbuf.af_gen)
	  match = FALSE;
	else
	  {
	    if ((atoi(val1) == cur_attrbuf.af_gen) &&
		(atoi(val2) >= cur_attrbuf.af_rev))
	      match = FALSE;
	    else
	      cur_pos--;
	  }
	break;
      case 6:
	/* Variants */
	if ((strcmp(cur_attrbuf.af_variant,value))  > 0)
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 7 :
	if ((strcmp(cur_attrbuf.af_syspath,value)) > 0)
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 8 :
	if ((strcmp(cur_attrbuf.af_host,value)) > 0)
	  cur_pos--;
	else
	  match = FALSE;
	break;
      default :
/* af_udattrs must contain a '=', even if they don't contain a value */
/* currently only the first value (if existing) in the string is     */
/* considered */
	i = 0;
	found = FALSE;
/* find name in list of udattrs */
	while ((!(found)) && (i < AF_MAXUDAS) &&
	       (cur_attrbuf.af_udattrs[i] != NIL))
	  {
	    (void) strcpy(val1, cur_attrbuf.af_udattrs[i]);
	    if ((val2 = index(val1, '=')) == 0)
	      errexit(10, "attrgt");
	    val2[0] = '\0';
	    if (strcmp(name, val1) != 0)
	      i++;
	    else
	      found = TRUE;
	  }
/* name should be found now */
	if (!(found))
	  errexit(10, "attrgt");

/* value comparison */
	val2++;
	if (*val2 == '\0')        /* no value given is considered as < */
	  match = FALSE;
	else
	  {
	    if ((val3 = index(val2, AF_UDAVALDEL)) != 0) 
	      val3[0] = '\0';     /* only first value is considered */
	    if (strcmp(value, val2) >= 0)
	      match = FALSE;
	    else
	      cur_pos--;
	  }
      }
  }
if (match)
  {
#ifdef DEBUG_ATTR
    printf("matches:\n");
    i = 0;
    while (i < nrofkeys)
      {
	af_setgkey(set, i, &cur_key);
	af_gattrs(&cur_key, &cur_attrbuf);
	printf("version %d.%d\n", cur_attrbuf.af_gen, cur_attrbuf.af_rev);
	i++;
      }
#endif DEBUG_ATTR

    return (TRUE);
  }
else                             /* remove keys from set if necessary */
  {
    while (cur_pos >= 0)
      {
	if (af_setposrmkey(set, cur_pos) == -1)
	  errexit(10, "af_setposrmkey");
	cur_pos--;
	nrofkeys--;
      }
    if (nrofkeys == 0)
      {
#ifdef DEBUG_ATTR
	printf("no matches\n");
#endif DEBUG_ATTR

	return (FALSE);
      }
    else
      {
#ifdef DEBUG_ATTR
	printf("matches:\n");
	nrofkeys = af_nrofkeys(set);
	i = 0;
	while (i < nrofkeys)
	  {
	    af_setgkey(set, i, &cur_key);
	    af_gattrs(&cur_key, &cur_attrbuf);
	    printf("version %d.%d\n", cur_attrbuf.af_gen, cur_attrbuf.af_rev);
	    i++;
	  }
#endif DEBUG_ATTR

	return (TRUE);
      }
  }
}

Bool attrle(name, value, set)
     char *name;
     char *value;
     Af_set *set;
{
int attr_type;
int nrofkeys;
int cur_pos;
int i;

Af_key cur_key;

Af_attrs cur_attrbuf;

Bool match;
Bool found;

char val1[256];
char *val2;
char *val3;

#ifdef DEBUG_ATTR
printf("attrle(): name = #%s#,  value = #%s#\n", name,value);
#endif DEBUG_ATTR

attr_type = get_attr_type(name);

if ((nrofkeys = af_nrofkeys(set)) == -1)
  errexit(10, "af_nrofkeys");

#ifdef DEBUG_ATTR
printf("nrofkeys = %d\n", nrofkeys);
#endif DEBUG_ATTR

switch (attr_type)
  {
  case 0 :
    if ((af_sortset(set,AF_ATTGEN)) == -1)
      errexit(10,"af_sortset");
    break;
  case 1 :
    if ((af_sortset(set,AF_ATTREV)) == -1)
      errexit(10,"af_sortset");
    break;
  case 2 :
    if ((af_sortset(set,AF_ATTSTATE)) == -1)
      errexit(10,"af_sortset");
    break;
  case 3 :
    if ((af_sortset(set,AF_ATTAUTHOR)) == -1)
      errexit(10,"af_sortset");
    break;
  case 4 :
    errexit(10,"group id");
    break;
  case 5 :
    if ((af_sortset(set,AF_ATTVERSION)) == -1)
      errexit(10,"af_sortset");
    break;
  case 6 :
    if ((af_sortset(set,AF_ATTVARIANT)) == -1)
      errexit(10,"af_sortset");
    break;
  case 7:
    if ((af_sortset(set,AF_ATTSPATH)) == -1)
      errexit(10,"af_sortset");
    break;
  case 8:
    if ((af_sortset(set,AF_ATTHOST)) == -1)
      errexit(10,"af_sortset");
    break;
  default :
    if ((af_sortset(set,name)) == -1)
      errexit(10,"af_sortset");
  }

cur_pos = 0;
match = TRUE;

while ((cur_pos < nrofkeys) && match)
  {
    if ((err = af_setgkey(set, cur_pos, &cur_key)) == -1)
      errexit(10, "af_setgkey");
    
    if (af_gattrs(&cur_key, &cur_attrbuf) == -1)
      errexit(10, "af_gattrs");

#ifdef DEBUG_ATTR
    printf("key[%d] -> version %d.%d\n", cur_pos, cur_attrbuf.af_gen, cur_attrbuf.af_rev);
#endif DEBUG_ATTR

    switch (attr_type)
      {
      case 0 :
	if (cur_attrbuf.af_gen <= atoi(value))
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 1 :
	if (cur_attrbuf.af_rev <= atoi(value))
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 2 :
	if ((int) cur_attrbuf.af_state <= atoi(value))
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 3 :
	if ((strcmp(cur_attrbuf.af_author.af_username,value)) <= 0)
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 4 :
	errexit(10,"group id");
	break;
      case 5 :
	(void) strcpy(val1, value);
	if ((val2 = index(val1,'.')) == 0)
	  errexit(9, value);
	val2[0] = '\0';
	val2++;
	if (atoi(val1) < cur_attrbuf.af_gen)
	  match = FALSE;
	else
	  {
	    if ((atoi(val1) == cur_attrbuf.af_gen) &&
		(atoi(val2) < cur_attrbuf.af_rev))
	      match = FALSE;
	    else
	      cur_pos++;
	  }
	break;
      case 6:
	/* Variants */
	if ((strcmp(cur_attrbuf.af_variant,value)) <= 0)
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 7 :
	if ((strcmp(cur_attrbuf.af_syspath,value)) <= 0)
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 8 :
	if ((strcmp(cur_attrbuf.af_host,value)) <= 0)
	  cur_pos++;
	else
	  match = FALSE;
	break;
      default :
/* af_udattrs must contain a '=', even if they don't contain a value */
/* currently only the first value (if existing) in the string is     */
/* considered */
	i = 0;
	found = FALSE;
/* find name in list of udattrs */
	while ((!(found)) && (i < AF_MAXUDAS) &&
	       (cur_attrbuf.af_udattrs[i] != NIL))
	  {
	    (void) strcpy(val1, cur_attrbuf.af_udattrs[i]);
	    if ((val2 = index(val1, '=')) == 0)
	      errexit(10, "attrle");
	    val2[0] = '\0';
	    if (strcmp(name, val1) != 0)
	      i++;
	    else
	      found = TRUE;
	  }
/* name should be found now */
	if (!(found))
	  errexit(10, "attrle");

/* value comparison */
	val2++;
	if (*val2 == '\0')        /* no value given is considered as <= */
	  cur_pos++;
	else
	  {
	    if ((val3 = index(val2, AF_UDAVALDEL)) != 0) 
	      val3[0] = '\0';     /* only first value is considered */
	    if (strcmp(value, val2) < 0)
	      match = FALSE;
	    else
	      cur_pos++;
	  }
      }
  }  
if (match)
  {
#ifdef DEBUG_ATTR
    printf("matches:\n");
    i = 0;
    while (i < nrofkeys)
      {
	af_setgkey(set, i, &cur_key);
	af_gattrs(&cur_key, &cur_attrbuf);
	printf("version %d.%d\n", cur_attrbuf.af_gen, cur_attrbuf.af_rev);
	i++;
      }
#endif DEBUG_ATTR
    return (TRUE);
  }
else                             /* remove keys from set if necessary */
  {
    while (cur_pos < nrofkeys)
      {
	if (af_setposrmkey(set, cur_pos) == -1)
	  errexit(10, "af_setposrmkey");
	nrofkeys--;
      }
    if (nrofkeys == 0)
      {
#ifdef DEBUG_ATTR
	printf("no matches\n");
#endif DEBUG_ATTR

	return (FALSE);
      }
    else
      {
#ifdef DEBUG_ATTR
	printf("matches:\n");
	nrofkeys = af_nrofkeys(set);
	i = 0;
	while (i < nrofkeys)
	  {
	    af_setgkey(set, i, &cur_key);
	    af_gattrs(&cur_key, &cur_attrbuf);
	    printf("version %d.%d\n", cur_attrbuf.af_gen, cur_attrbuf.af_rev);
	    i++;
	  }
#endif DEBUG_ATTR

	return (TRUE);
      }
  }
	    
}


Bool attrge(name , value, set)
     char *name;
     char *value;
     Af_set *set;
{
int attr_type;
int nrofkeys;
int cur_pos;
int i;

Af_key cur_key;

Af_attrs cur_attrbuf;

Bool match;
Bool found;

char val1[256];
char *val2;
char *val3;

#ifdef DEBUG_ATTR
printf("attrge(): name = #%s#,  value = #%s#\n", name,value);
#endif DEBUG_ATTR

attr_type = get_attr_type(name);

if ((nrofkeys = af_nrofkeys(set)) == -1)
  errexit(10, "af_nrofkeys");

#ifdef DEBUG_ATTR
printf("nrofkeys = %d\n", nrofkeys);
#endif DEBUG_ATTR

switch (attr_type)
  {
  case 0 :
    if ((af_sortset(set,AF_ATTGEN)) == -1)
      errexit(10,"af_sortset");
    break;
  case 1 :
    if ((af_sortset(set,AF_ATTREV)) == -1)
      errexit(10,"af_sortset");
    break;
  case 2 :
    if ((af_sortset(set,AF_ATTSTATE)) == -1)
      errexit(10,"af_sortset");
    break;
  case 3 :
    if ((af_sortset(set,AF_ATTAUTHOR)) == -1)
      errexit(10,"af_sortset");
    break;
  case 4 :
    errexit(10,"group id");
    break;
  case 5 :
    if ((af_sortset(set,AF_ATTVERSION)) == -1)
      errexit(10,"af_sortset");
    break;
  case 6 :
    if ((af_sortset(set,AF_ATTVARIANT)) == -1)
      errexit(10,"af_sortset");
    break;
  case 7:
    if ((af_sortset(set,AF_ATTSPATH)) == -1)
      errexit(10,"af_sortset");
    break;
  case 8:
    if ((af_sortset(set,AF_ATTHOST)) == -1)
      errexit(10,"af_sortset");
    break;
  default :
    if ((af_sortset(set,name)) == -1)
      errexit(10,"af_sortset");
  }

cur_pos = (nrofkeys - 1);
match = TRUE;

while ((cur_pos >= 0) && match)
  {
    if ((err = af_setgkey(set, cur_pos, &cur_key)) == -1)
      errexit(10, "af_setgkey");
    
    if (af_gattrs(&cur_key, &cur_attrbuf) == -1)
      errexit(10, "af_gattrs");

#ifdef DEBUG_ATTR
    printf("key[%d] -> version %d.%d\n", cur_pos, cur_attrbuf.af_gen, cur_attrbuf.af_rev);
#endif DEBUG_ATTR

    switch (attr_type)
      {
      case 0 :
	if (cur_attrbuf.af_gen >= atoi(value))
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 1 :
	if (cur_attrbuf.af_rev >= atoi(value))
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 2 :
	if ((int) cur_attrbuf.af_state >= get_state_no(value))
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 3 :
	if ((strcmp(cur_attrbuf.af_author.af_username,value)) >= 0)
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 4 :
	errexit(10,"group id");
	break;
      case 5 :
	(void) strcpy(val1, value);
	if ((val2 = index(val1,'.')) == 0)
	  errexit(9, value);
	val2[0] = '\0';
	val2++;
	if (atoi(val1) > cur_attrbuf.af_gen)
	  match = FALSE;
	else
	  {
	    if ((atoi(val1) == cur_attrbuf.af_gen) &&
		(atoi(val2) > cur_attrbuf.af_rev))
	      match = FALSE;
	    else
	      cur_pos--;
	  }
	break;
      case 6:
	/* Variants */
	if ((strcmp(cur_attrbuf.af_variant,value)) >= 0)
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 7 :
	if ((strcmp(cur_attrbuf.af_syspath,value)) >= 0)
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 8 :
	if ((strcmp(cur_attrbuf.af_host,value)) >= 0)
	  cur_pos--;
	else
	  match = FALSE;
	break;
      default :
/* af_udattrs must contain a '=', even if they don't contain a value */
/* currently only the first value (if existing) in the string is     */
/* considered */
	i = 0;
	found = FALSE;
/* find name in list of udattrs */
	while ((!(found)) && (i < AF_MAXUDAS) &&
	       (cur_attrbuf.af_udattrs[i] != NIL))
	  {
	    (void) strcpy(val1, cur_attrbuf.af_udattrs[i]);
	    if ((val2 = index(val1, '=')) == 0)
	      errexit(10, "attrge");
	    val2[0] = '\0';
	    if (strcmp(name, val1) != 0)
	      i++;
	    else
	      found = TRUE;
	  }
/* name should be found now */
	if (!(found))
	  errexit(10, "attrge");

/* value comparison */
	val2++;
	if (*val2 == '\0')        /* no value given is considered as < */
	  match = FALSE;
	else
	  {
	    if ((val3 = index(val2, AF_UDAVALDEL)) != 0) 
	      val3[0] = '\0';     /* only first value is considered */
	    if (strcmp(value, val2) > 0)
	      match = FALSE;
	    else
	      cur_pos--;
	  }
      }
  }
if (match)
  {
#ifdef DEBUG_ATTR
    printf("matches:\n");
    i = 0;
    while (i < nrofkeys)
      {
	af_setgkey(set, i, &cur_key);
	af_gattrs(&cur_key, &cur_attrbuf);
	printf("version %d.%d\n", cur_attrbuf.af_gen, cur_attrbuf.af_rev);
	i++;
      }
#endif DEBUG_ATTR

    return (TRUE);
  }
else                             /* remove keys from set if necessary */
  {
    while (cur_pos >= 0)
      {
	if (af_setposrmkey(set, cur_pos) == -1)
	  errexit(10, "af_setposrmkey");
	cur_pos--;
	nrofkeys--;
      }
    if (nrofkeys == 0)
      {
#ifdef DEBUG_ATTR
	printf("no matches\n");
#endif DEBUG_ATTR

	return (FALSE);
      }
    else
      {
#ifdef DEBUG_ATTR
	printf("matches:\n");
	nrofkeys = af_nrofkeys(set);
	i = 0;
	while (i < nrofkeys)
	  {
	    af_setgkey(set, i, &cur_key);
	    af_gattrs(&cur_key, &cur_attrbuf);
	    printf("version %d.%d\n", cur_attrbuf.af_gen, cur_attrbuf.af_rev);
	    i++;
	  }
#endif DEBUG_ATTR

	return (TRUE);
      }
  }

}



Bool attrmax(name, value, set)
     char *name;
     char *value;
     Af_set *set;
{
int attr_type;
int nrofkeys;
int cur_pos;
int i;
int udattr_pos;

Af_key cur_key;

Af_attrs cur_attrbuf;
Af_attrs max_attrbuf;

Bool match;
Bool found;

char val1[256];
char *val2;

#ifdef DEBUG_ATTR
printf("attrmax(): name = #%s#\n", name);
#endif DEBUG_ATTR

attr_type = get_attr_type(name);

if ((nrofkeys = af_nrofkeys(set)) == -1)
  errexit(10, "af_nrofkeys");

#ifdef DEBUG_ATTR
printf("nrofkeys = %d\n", nrofkeys);
#endif DEBUG_ATTR

switch (attr_type)
  {
  case 0 :
    if ((af_sortset(set,AF_ATTGEN)) == -1)
      errexit(10,"af_sortset");
    break;
  case 1 :
    if ((af_sortset(set,AF_ATTREV)) == -1)
      errexit(10,"af_sortset");
    break;
  case 2 :
    if ((af_sortset(set,AF_ATTSTATE)) == -1)
      errexit(10,"af_sortset");
    break;
  case 3 :
    if ((af_sortset(set,AF_ATTAUTHOR)) == -1)
      errexit(10,"af_sortset");
    break;
  case 4 :
    errexit(10,"group id");
    break;
  case 5 :
    if ((af_sortset(set,AF_ATTVERSION)) == -1)
      errexit(10,"af_sortset");
    break;
  case 6 :
    if ((af_sortset(set,AF_ATTVARIANT)) == -1)
      errexit(10,"af_sortset");
    break;
  case 7:
    if ((af_sortset(set,AF_ATTSPATH)) == -1)
      errexit(10,"af_sortset");
    break;
  case 8:
    if ((af_sortset(set,AF_ATTHOST)) == -1)
      errexit(10,"af_sortset");
    break;
  default :
    if ((af_sortset(set,name)) == -1)
      errexit(10,"af_sortset");
  }

if (nrofkeys == 1)
  {
#ifdef DEBUG_ATTR
    printf("one match :\n");
    af_setgkey(set, 0, &cur_key);
    af_gattrs(&cur_key, &cur_attrbuf);
    printf("version %d.%d\n", cur_attrbuf.af_gen, cur_attrbuf.af_rev);
#endif DEBUG_ATTR

    return (TRUE);
  }
else
  {
    if (nrofkeys == 0)
      {
#ifdef DEBUG_ATTR
	printf("no match\n");
#endif DEBUG_ATTR
	return (FALSE);
      }
  }

cur_pos = (nrofkeys - 1);
match = TRUE;

if ((err = af_setgkey(set, cur_pos, &cur_key)) == -1)
  errexit(10, "af_setgkey");
if (af_gattrs(&cur_key, &max_attrbuf) == -1)
  errexit(10, "af_gattrs");
cur_pos--;

if (attr_type > STD_ATTRS)  /* if looking for udattrs  */
/* name has to be found in list of udattrs     */
  {
    udattr_pos = 0;
    found = FALSE;
/* find name in list of udattrs */
    while ((!(found)) && (udattr_pos < AF_MAXUDAS) &&
	   (max_attrbuf.af_udattrs[udattr_pos] != NIL))
      {
	(void) strcpy(val1, max_attrbuf.af_udattrs[udattr_pos]);
	if ((val2 = index(val1, '=')) == 0)
	  errexit(10, "attrmax");
	val2[0] = '\0';
	if (strcmp(name, val1) != 0)
	  udattr_pos++;
	else
	  found = TRUE;
      }
/* name should be found now */
    if (!(found))
      errexit(10, "attrmax");
  }

while ((cur_pos >= 0) && match)
  {
    if ((err = af_setgkey(set, cur_pos, &cur_key)) == -1)
      errexit(10, "af_setgkey");
    
    if (af_gattrs(&cur_key, &cur_attrbuf) == -1)
      errexit(10, "af_gattrs");

#ifdef DEBUG_ATTR
    printf("key[%d] -> version %d.%d\n", cur_pos, cur_attrbuf.af_gen, cur_attrbuf.af_rev);
#endif DEBUG_ATTR

    switch (attr_type)
      {
      case 0 :
	if (cur_attrbuf.af_gen == max_attrbuf.af_gen)
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 1 :
	if (cur_attrbuf.af_rev == max_attrbuf.af_rev)
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 2 :
	if (cur_attrbuf.af_state == max_attrbuf.af_state)
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 3 :
	if(!strcmp(cur_attrbuf.af_author.af_username,max_attrbuf.af_author.af_username))
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 4 :
	errexit(10,"group id");
	break;
      case 5 :
	if ((cur_attrbuf.af_gen == max_attrbuf.af_gen) &&
	    (cur_attrbuf.af_rev == max_attrbuf.af_rev))
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 6:
	/* Variants */
	if ((strcmp(cur_attrbuf.af_variant,max_attrbuf.af_variant) == 0))
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 7 :
	if ((strcmp(cur_attrbuf.af_syspath,value)) == 0)
	  cur_pos--;
	else
	  match = FALSE;
	break;
      case 8 :
	if ((strcmp(cur_attrbuf.af_host,value)) == 0)
	  cur_pos--;
	else
	  match = FALSE;
	break;
      default :
/* af_udattrs must contain a '=', even if they don't contain a value */
/* currently only the first value (if existing) in the string is     */
/* considered */
	i = 0;
	found = FALSE;
/* find name in list of udattrs */
	while ((!(found)) && (i < AF_MAXUDAS) &&
	       (cur_attrbuf.af_udattrs[i] != NIL))
	  {
	    (void) strcpy(val1, cur_attrbuf.af_udattrs[i]);
	    if ((val2 = index(val1, '=')) == 0)
	      errexit(10, "attrle");
	    val2[0] = '\0';
	    if (strcmp(name, val1) != 0)
	      i++;
	    else
	      found = TRUE;
	  }
/* name should be found now */
	if (!(found))
	  errexit(10, "attrmax");

/* value comparison */
	if (strcmp(cur_attrbuf.af_udattrs[i], 
		   max_attrbuf.af_udattrs[udattr_pos]) != 0)
	  match = FALSE;
	else
	  cur_pos--;
     
      }
  }

/* remove keys from set if necessary */
i = cur_pos + 1;
while (i > 0)
  {
    if (af_setposrmkey(set, 0) == -1)
      errexit(10, "af_setposrmkey");
    i--;
  }

#ifdef DEBUG_ATTR
printf("matches:\n");
nrofkeys = af_nrofkeys(set);
i = 0;
while (i < nrofkeys)
  {
    af_setgkey(set, i, &cur_key);
    af_gattrs(&cur_key, &cur_attrbuf);
    printf("version %d.%d\n", cur_attrbuf.af_gen, cur_attrbuf.af_rev);
    i++;
   }
#endif DEBUG_ATTR
  
return (TRUE);

}

Bool attrmin(name, value, set)
     char *name;
     char *value;
     Af_set *set;
{
int attr_type;
int nrofkeys;
int cur_pos;
int i;
int udattr_pos;

Af_key cur_key;

Af_attrs cur_attrbuf;
Af_attrs max_attrbuf;

Bool match;
Bool found;

char val1[256];
char *val2;

#ifdef DEBUG_ATTR
printf("attrmin(): name = #%s#\n", name);
#endif DEBUG_ATTR

attr_type = get_attr_type(name);

if ((nrofkeys = af_nrofkeys(set)) == -1)
  errexit(10, "af_nrofkeys");

#ifdef DEBUG_ATTR
printf("nrofkeys = %d\n", nrofkeys);
#endif DEBUG_ATTR

if (nrofkeys == 1)
  {
#ifdef DEBUG_ATTR
    printf("one match :\n");
    af_setgkey(set, 0, &cur_key);
    af_gattrs(&cur_key, &cur_attrbuf);
    printf("version %d.%d\n", cur_attrbuf.af_gen, cur_attrbuf.af_rev);
#endif DEBUG_ATTR

    return (TRUE);
  }

switch (attr_type)
  {
  case 0 :
    if ((af_sortset(set,AF_ATTGEN)) == -1)
      errexit(10,"af_sortset");
    break;
  case 1 :
    if ((af_sortset(set,AF_ATTREV)) == -1)
      errexit(10,"af_sortset");
    break;
  case 2 :
    if ((af_sortset(set,AF_ATTSTATE)) == -1)
      errexit(10,"af_sortset");
    break;
  case 3 :
    if ((af_sortset(set,AF_ATTAUTHOR)) == -1)
      errexit(10,"af_sortset");
    break;
  case 4 :
    errexit(10,"group id");
    break;
  case 5 :
    if ((af_sortset(set,AF_ATTVERSION)) == -1)
      errexit(10,"af_sortset");
    break;
  case 6 :
    if ((af_sortset(set,AF_ATTVARIANT)) == -1)
      errexit(10,"af_sortset");
    break;
  case 7:
    if ((af_sortset(set,AF_ATTSPATH)) == -1)
      errexit(10,"af_sortset");
    break;
  case 8:
    if ((af_sortset(set,AF_ATTHOST)) == -1)
      errexit(10,"af_sortset");
    break;
  default :
    if ((af_sortset(set,name)) == -1)
      errexit(10,"af_sortset");
  }

cur_pos = (0);
match = TRUE;

if ((err = af_setgkey(set, cur_pos, &cur_key)) == -1)
  errexit(10, "af_setgkey");
if (af_gattrs(&cur_key, &max_attrbuf) == -1)
  errexit(10, "af_gattrs");
cur_pos++;

if (attr_type > STD_ATTRS)  /* if looking for udattrs  */
/* name has to be found in list of udattrs     */
  {
    udattr_pos = 0;
    found = FALSE;
/* find name in list of udattrs */
    while ((!(found)) && (udattr_pos < AF_MAXUDAS) &&
	   (max_attrbuf.af_udattrs[udattr_pos] != NIL))
      {
	(void) strcpy(val1, max_attrbuf.af_udattrs[udattr_pos]);
	if ((val2 = index(val1, '=')) == 0)
	  errexit(10, "attrmin");
	val2[0] = '\0';
	if (strcmp(name, val1) != 0)
	  udattr_pos++;
	else
	  found = TRUE;
      }
/* name should be found now */
    if (!(found))
      errexit(10, "attrmin");
  }

while ((cur_pos < nrofkeys) && match)
  {
    if ((err = af_setgkey(set, cur_pos, &cur_key)) == -1)
      errexit(10, "af_setgkey");
    
    if (af_gattrs(&cur_key, &cur_attrbuf) == -1)
      errexit(10, "af_gattrs");

#ifdef DEBUG_ATTR
    printf("key[%d] -> version %d.%d\n", cur_pos, cur_attrbuf.af_gen, cur_attrbuf.af_rev);
#endif DEBUG_ATTR

    switch (attr_type)
      {
      case 0 :
	if (cur_attrbuf.af_gen == max_attrbuf.af_gen)
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 1 :
	if (cur_attrbuf.af_rev == max_attrbuf.af_rev)
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 2 :
	if (cur_attrbuf.af_state == max_attrbuf.af_state)
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 3 :
	if (!strcmp(cur_attrbuf.af_author.af_username,max_attrbuf.af_author.af_username))
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 4 :
	errexit(10,"group id");
	break;
      case 5 :
	if ((cur_attrbuf.af_gen == max_attrbuf.af_gen) &&
	    (cur_attrbuf.af_rev == max_attrbuf.af_rev))
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 6:
	/* Variants */
	if ((strcmp(cur_attrbuf.af_variant,max_attrbuf.af_variant) == 0))
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 7 :
	if ((strcmp(cur_attrbuf.af_syspath,value)) == 0)
	  cur_pos++;
	else
	  match = FALSE;
	break;
      case 8 :
	if ((strcmp(cur_attrbuf.af_host,value)) == 0)
	  cur_pos++;
	else
	  match = FALSE;
	break;
      default :
/* af_udattrs must contain a '=', even if they don't contain a value */
/* currently only the first value (if existing) in the string is     */
/* considered */
	i = 0;
	found = FALSE;
/* find name in list of udattrs */
	while ((!(found)) && (i < AF_MAXUDAS) &&
	       (cur_attrbuf.af_udattrs[i] != NIL))
	  {
	    (void) strcpy(val1, cur_attrbuf.af_udattrs[i]);
	    if ((val2 = index(val1, '=')) == 0)
	      errexit(10, "attrle");
	    val2[0] = '\0';
	    if (strcmp(name, val1) != 0)
	      i++;
	    else
	      found = TRUE;
	  }	
/* name should be found now */
	if (!(found))
	  errexit(10, "attrmax");

/* value comparison */
	if (strcmp(cur_attrbuf.af_udattrs[i], 
		   max_attrbuf.af_udattrs[udattr_pos]) != 0)
	  match = FALSE;
	else
	  cur_pos++;
     
      }
  }

/* remove keys from set if necessary */
while (cur_pos < nrofkeys)
  {
    if (af_setposrmkey(set, cur_pos) == -1)
      errexit(10, "af_setposrmkey");
    nrofkeys--;
  }

#ifdef DEBUG_ATTR
printf("matches:\n");
nrofkeys = af_nrofkeys(set);
i = 0;
while (i < nrofkeys)
  {
    af_setgkey(set, i, &cur_key);
    af_gattrs(&cur_key, &cur_attrbuf);
    printf("version %d.%d\n", cur_attrbuf.af_gen, cur_attrbuf.af_rev);
    i++;
   }
#endif DEBUG_ATTR

return (TRUE);

}


Bool getfromcid()
{
/* not yet implemented */
;
}

Bool attrvar(name, value, set)
     char *name;
     /*ARGSUSED*/
     char *value;
     Af_set *set;
{
/* set variant path & variant flags */
int k = 0;
int i = 0;
char *ind;
char pathlist[256];

if (check_vclass(name) != TRUE)
  errexit(30,name);

while( vardefs[k] != (struct vardef *) NIL)
  {
    if (strcmp (vardefs[k]->name, name) != 0)
      k++;
    else
      {
	while(curvpath[i] != NIL)
	  i++;
	if (vardefs[k]->vpath != NIL)
	  {
	    (void) strcpy(pathlist,vardefs[k]->vpath);
	
	    while(( ind = index(pathlist,':')) != NIL)
	      {
		*ind = '\0';
		if ((curvpath[i] = malloc((unsigned) (strlen(pathlist) + sizeof(char)))) == NIL)
		  errexit(10,"malloc");
		(void) strcpy(curvpath[i],pathlist);
		ind++;
		(void) strcpy(pathlist,ind);
		i++;
	      }
	    if ((curvpath[i] = malloc((unsigned) (strlen(pathlist) + sizeof(char)))) == NIL)
	      errexit(10,"malloc");
	    (void) strcpy(curvpath[i],pathlist);
	  }
/*	strcpy(p,"vflags=");
	(void) strcat(p,expandmacro("$(vflags)"));
	(void) strcat(p," ");
	(void) strcat(p,vardefs[k]->vflags);
	macrodef(p);
	free(p); */
	break;
      }
  }

if (vardefs[k] != (struct vardef *) NIL)
  {
    if (strcmp(vardefs[k]->name, name) == 0)
      return (TRUE);
  }
else
  errexit(19,name);
/*NOTREACHED*/
}



char *replace(patt)
     char *patt;
{

/* converts shell-like pattern to ex-like pattern */
/* not yet complete ???? */
/* a{bc,d,e}f mactches abcf adf & aef not implemented */
  int i,j;
  char result[128];
  char tmp_result[64];

  static char rechars[] = "^.$?*[]{}";

  j = 0;
  
  for(i = 0; i < strlen(patt); i++)
    {
      switch (patt[i])
	{
	case '?':
	  tmp_result[j++]='.';
	  break;
	case '*':
	  tmp_result[j++]='.';
  	  tmp_result[j++]='*'; 
	  break;
	case '.':
	  tmp_result[j++]='\\';
	  tmp_result[j++]='.';
	  break;
	default:
	  tmp_result[j++]=patt[i];
      }
  }
tmp_result[j]='\0';

(void) sprintf(result,"%s%s%s",(!(index(rechars,tmp_result[0]))) ? "^" : "",
	tmp_result, (!(index(rechars,tmp_result[strlen(tmp_result) - 1]))) ? 
	"$" : "");
  
return(result);
}

