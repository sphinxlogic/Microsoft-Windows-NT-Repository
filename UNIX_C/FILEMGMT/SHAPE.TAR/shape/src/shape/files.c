/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *RCSid = "$Header: files.c,v 3.3 89/02/20 16:23:45 wolfgang Exp $";
#endif
#ifndef lint
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	files.c,v $
 * Revision 3.3  89/02/20  16:23:45  wolfgang
 * NET-RELEASE
 * 
 * Revision 3.2  89/02/13  19:35:15  wolfgang
 * performance improved
 * 
 * Revision 3.1  89/02/08  12:45:42  wolfgang
 * performance improved.
 * 
 * Revision 3.0  89/01/24  11:35:24  wolfgang
 * New System Generation
 * 
 * Revision 2.30  89/01/03  13:09:44  wolfgang
 * changes done for lint
 * 
 * Revision 2.29  88/12/21  15:02:45  wolfgang
 * changes done for lint
 * 
 * Revision 2.28  88/12/12  13:15:58  wolfgang
 * bug fixed (something for sun).
 * 
 * Revision 2.27  88/11/24  14:30:36  wolfgang
 * derived object no longer inherit uda's .
 * 
 * Revision 2.26  88/11/23  15:19:39  wolfgang
 * hidden attrs are no longer part of confid.
 * 
 * Revision 2.25  88/11/23  15:02:57  wolfgang
 * bug fixed.
 * 
 * Revision 2.24  88/11/22  17:27:33  wolfgang
 * bug fixed (strncmp).
 * 
 * Revision 2.22  88/11/21  15:51:11  wolfgang
 * return code of all malloc's checked
 * 
 * Revision 2.21  88/11/08  18:06:04  wolfgang
 * bug fixed: retcode wasn't correct initialized (in exists_file()).
 * 
 * Revision 2.20  88/11/08  11:01:23  wolfgang
 * bug fixed in evtl_set_busy: selction rules are now not applied to
 * derived objects.
 * 
 * Revision 2.19  88/11/05  14:35:51  wolfgang
 * bug fixed. full filenames (including path) were destroyed sometimes.
 * 
 * Revision 2.18  88/11/03  17:28:59  wolfgang
 * bug fixed in exists_file
 * 
 * Revision 2.17  88/10/24  16:19:30  wolfgang
 * bug fixed in exists_file.
 * 
 * Revision 2.16  88/10/18  20:33:48  wolfgang
 * bugs fixed. pathlist wasn't correct. set busy of name including
 * full path didn't work.
 * 
 * Revision 2.15  88/10/10  17:02:34  wolfgang
 * This version is part of a release
 * 
 * Revision 2.14  88/09/22  16:14:06  wolfgang
 * changes done to set busy the same file more than once.
 * 
 * Revision 2.13  88/09/15  18:42:14  wolfgang
 * call of reset_vclass added.
 * 
 * Revision 2.12  88/08/30  12:20:44  wolfgang
 * minor bug fixed.,
 * 
 * Revision 2.11  88/08/25  16:10:55  wolfgang
 * This version is part of a release
 * 
 * Revision 2.10  88/08/25  10:29:31  wolfgang
 * Now a warning is produced, if a confid contains non-frozen versions
 * of a component.
 * 
 * Revision 2.9  88/08/23  16:35:40  wolfgang
 * The handling of author@host is now correct.
 * 
 * Revision 2.8  88/08/23  15:35:45  wolfgang
 * Genarating of confid's has been changed. The name of the selection
 * rule starts now with '@'.
 * 
 * Revision 2.7  88/08/23  14:06:47  wolfgang
 * Minor bug fixed. The dummy predicate SMILEY was followed by ":"
 * instead of ",".
 * 
 * Revision 2.6  88/08/23  11:22:37  wolfgang
 * vardump(fd) added to finish_confid.
 * 
 * Revision 2.5  88/08/23  10:27:01  wolfgang
 * ruledump() added to finish_confid; little bug fix in write_confid.
 * 
 * Revision 2.4  88/08/22  17:13:31  wolfgang
 * Two procedures added:
 * init_confid: to initialize the confid
 * finish_confid: dumps the macrodefinitions.
 * write_confid changed; only the relevant predicates are written to the
 * confid now.
 * Furthermore handling of syspath & host added to evtl_set_busy().
 * 
 * Revision 2.3  88/08/22  11:13:41  wolfgang
 * Minor bug fixed. attr(author,<name>) wasn't evaluated correctly.
 * 
 * Revision 2.2  88/08/19  12:25:02  wolfgang
 * Minor bug fixed. Pathlist contained '/' in filename.
 * 
 * Revision 2.1  88/08/19  10:17:18  wolfgang
 * This version is part of a release
 * 
 */

#include "shape.h"
#include "files.h"

#include <pwd.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <errno.h>

extern int errno;

extern register_link();

extern FILE *af_open();

extern struct passwd *getpwnam();
extern char *mktemp();

extern int af_setgkey();
extern int af_gattrs();
extern int WriteXPand();
extern int logerr();
extern int append_attrs();
extern int append_mtime();
extern Bool stopit();
extern Bool tunix();
extern struct rules *get_target();
extern int dump();
extern int ruledump();
extern int vardump();
extern int reset_vclass();

Af_attrs buft;
extern char *macrostr;
extern char cursr[];
char actpath[MAXNAMLEN];
extern char *states[];
extern struct selection_rules *currule;

extern Bool busy_done;
extern int depth;
extern int pathi;
char *pathlist[MAXPATHLIST][2];
int lastpath = 0;
char dollarplus[MAXNAMLEN];

get_date_of(anything,set,path)
     char *anything;
     Af_set *set;
     char *path;
     {
       /* attrs of busy version */
Af_attrs buf;

char bname[MAXNAMLEN];
char *p;
char *d;
char sysp[MAXNAMLEN];

sysp[0] = '\0';

(void) strcpy(bname,anything);
if ((p = rindex(bname,'.')) == NIL)
  ;
else
  {
    p[0] = '\0';
    *p++;
  }

if ((d = rindex(bname,'/')) != 0)
  {
    (void) strcpy(sysp, bname);
    d = rindex(sysp, '/');
    d[0] = '\0';
    *d++;
    (void) strcpy(bname,d);
  }
af_initattrs(&buf);

buf.af_gen = AF_BUSYVERS;
buf.af_rev = AF_BUSYVERS;

(void) strcpy(buf.af_name,bname);
if (p != NIL)
     (void) strcpy(buf.af_type,p);
else
  (void) strcpy(buf.af_type,"");

if(path != NIL)
     (void) strcpy(buf.af_syspath, path);

/* if ((retcode = af_bpfind(&buf,&bset)) == -1) 
  errexit(10,"af_bpfind"); */

if (af_find(&buf,set) == -1) /* &aset */
  errexit(10,"af_find");

/* if ((retcode = af_union(&aset,&bset,set)) == -1 )
  errexit(10,"af_union"); */
} 


Bool exists_file(name,mode)
     char *name;
     int mode;
{

char bname[MAXNAMLEN];
char type[64];
char *p;
char *d;

int retcode = -1;
int retcodex;
int retcodey;
int i;
int ii = 1;
char sysp[MAXNAMLEN];
char lname[MAXNAMLEN];
char *px;
Af_attrs buf;

sysp[0] = '\0';
if (name == NIL)
  return (FALSE);

(void) strcpy(lname,name);
if((px = rindex(lname,'/')) != NIL)
  {
    *px = '\0';
    px++;
  }
else
  px = &lname[0];

if (mode != BINARY) 
    {
      for(i = lastpath - 1; i >= 0; i--)
	/* looking in pathlist if file already exists */
	{
	  if(!strcmp(px,pathlist[i][0]))
	    {
	      if (!strcmp(pathlist[i][1],"&$"))
		(void) strcpy(actpath,curvpath[0]);
	      else
		{
		  if(pathlist[i][1][0] != '/')
		    {
		      (void) strcpy(actpath,curvpath[0]);
		      (void) strcat(actpath,"/");
		      (void) strcat(actpath,pathlist[i][1]);
		    }
		  else
		    {
		      (void) strcpy(actpath,pathlist[i][1]);
		    }
		  if ((px = rindex(actpath,'/')) != NIL)
		    *px = '\0';
		}
	      return(TRUE);
	    }
	}
    }

(void) strcpy(bname,name);
if ((p = rindex(bname,'.')) == 0)
  {
    type[0] = '\0';
  }
else
  {
    p[0] = '\0';
    *p++;
    (void) strcpy(type,p);
  }
if ((d = rindex(bname,'/')) != 0)
  {
    (void) strcpy(sysp, bname);
    d = rindex(sysp, '/');
    d[0] = '\0';
    *d++;
    (void) strcpy(bname,d);
  }
af_initattrs(&buf);

buf.af_gen = AF_NOVNUM;
buf.af_rev = AF_NOVNUM;

(void) strcpy(buf.af_name,bname);

(void) strcpy(buf.af_type,type);

while(curvpath[ii] != NIL)
  ii++;

i = ii - 1;

while ( i >= 1 )
  {
    (void) strcpy(buf.af_syspath, curvpath[i]);

    if (mode == ALL)
      {
	retcodex = af_access(buf.af_syspath, buf.af_name, buf.af_type, AF_SOURCE);
	retcodey = af_access(buf.af_syspath, buf.af_name, buf.af_type, AF_DERIVED);
	if((retcodex == 0) || (retcodey == 0))
	  retcode = 0;
	else
	  retcode = -1;
      }

    if (mode == SOURCE)
      retcode = af_access(buf.af_syspath, buf.af_name, buf.af_type, AF_SOURCE);

    if (mode == BINARY)
      retcode = af_access(buf.af_syspath, buf.af_name, buf.af_type, AF_DERIVED);

    if ((retcode == 0)) /*  && (strcmp(buf.af_syspath,curvpath[0]))) */
      {
	(void) strcpy(actpath,curvpath[i]);
	if ((pathlist[lastpath][0] = malloc(MAXNAMLEN)) == NIL)
	  errexit(10,"malloc");
	(void) strcpy(pathlist[lastpath][0],buf.af_name);
	if (buf.af_type[0] != '\0')
	  {
	    (void) strcat(pathlist[lastpath][0],".");
	    (void) strcat(pathlist[lastpath][0],buf.af_type);
	  }
	if (!strcmp(buf.af_syspath,curvpath[0]))
	  {
	    if((pathlist[lastpath][1] = malloc(3)) == NIL)
	      errexit(10,"malloc");
	    (void) strcpy(pathlist[lastpath][1],"&$");
#ifdef DEBUG_FILES
printf("%d:%s:%s\n", lastpath,pathlist[lastpath][0], pathlist[lastpath][1]);
#endif DEBUG_FILES
	    lastpath++;
	  }
	else
	  {
	    if((pathlist[lastpath][1] = malloc(MAXNAMLEN)) == NIL)
	      errexit(10,"malloc");
	    (void) strcpy(pathlist[lastpath][1],buf.af_syspath);
	    (void) strcat(pathlist[lastpath][1],"/");
	    (void) strcat(pathlist[lastpath][1],pathlist[lastpath][0]);
#ifdef DEBUG_FILES
printf("%d:%s:%s\n", lastpath,pathlist[lastpath][0], pathlist[lastpath][1]);
#endif DEBUG_FILES
	    lastpath++;
	    break;
	  }
      }
    i--;
    }
if (retcode == 0)
  {
    (void) strcpy(actpath,curvpath[i]);
    return(TRUE);
  }

if (sysp[0] != '\0')
     (void) strcpy(buf.af_syspath, sysp);
else
  (void) strcpy(buf.af_syspath, curvpath[0]);


if (mode == ALL)
  {
    retcodex = af_access(buf.af_syspath, buf.af_name, buf.af_type, AF_SOURCE);
    retcodey = af_access(buf.af_syspath, buf.af_name, buf.af_type, AF_DERIVED);
    if((retcodex == 0) || (retcodey == 0))
      retcode = 0;
    else
      retcode = -1;
  }

if (mode == SOURCE)
  retcode = af_access(buf.af_syspath, buf.af_name, buf.af_type, AF_SOURCE);

if (mode == BINARY)
  retcode = af_access(buf.af_syspath, buf.af_name, buf.af_type, AF_DERIVED);

if (retcode == 0) /*  && (strcmp(buf.af_syspath,curvpath[0]))) */
  {
    (void) strcpy(actpath,buf.af_syspath);
    if ((pathlist[lastpath][0] = malloc(MAXNAMLEN)) == NIL)
      errexit(10,"malloc");
    (void) strcpy(pathlist[lastpath][0],buf.af_name);
    if (buf.af_type[0] != '\0')
      {
	(void) strcat(pathlist[lastpath][0],".");
	(void) strcat(pathlist[lastpath][0],buf.af_type);
      }
    if (!strcmp(buf.af_syspath,curvpath[0]))
      {
	if((pathlist[lastpath][1] = malloc(3)) == NIL)
	  errexit(10,"malloc");
	(void) strcpy(pathlist[lastpath][1],"&$");
#ifdef DEBUG_FILES
printf("%d:%s:%s\n", lastpath,pathlist[lastpath][0], pathlist[lastpath][1]);
#endif DEBUG_FILES
	lastpath++;
      }
    else
      {
	if ((pathlist[lastpath][1] = malloc(MAXNAMLEN)) == NIL)
	  errexit(10,"malloc");
	(void) strcpy(pathlist[lastpath][1],buf.af_syspath);
	(void) strcat(pathlist[lastpath][1],"/");
	(void) strcat(pathlist[lastpath][1],pathlist[lastpath][0]);
#ifdef DEBUG_FILES
printf("%d:%s:%s\n", lastpath,pathlist[lastpath][0], pathlist[lastpath][1]);
#endif DEBUG_FILES
	lastpath++;
	return(TRUE);
      }
  }

if(retcode == 0)
  {
    (void) strcpy(actpath,buf.af_syspath);
    return(TRUE);
  }

if (retcode == -1)
  return (FALSE);
else
  return (TRUE);
}


FILE *vmfopen( filename, mode, gen,rev)
     char *filename;
     char *mode;
     int gen;
     int rev;
{
  char syspath[MAXNAMLEN];
  char *name = NIL;
  char *type = NIL;
  
  Af_key key;

  char *ind;
  char *ind2;
  char *basename;
  FILE *fp;
  char fname[MAXNAMLEN];
  (void) strcpy(fname, filename);

  if ((ind = rindex(fname,'/')) == NIL)
    {
      (void) strcpy(syspath,curvpath[0]);
      basename = fname;
    }
  else
    {
      ind[0] = '\0';
      ind++;
      basename = ind;
      (void) strcpy(syspath,fname);
    }
  
  if ((ind2 = rindex(basename,'.')) == NIL)
    {
      name = basename;
    }
  else
    {
      ind2[0] = '\0';
      ind2++;
      type = ind2;
      name = basename;
    }
  if(af_getkey(syspath, name, type, gen, rev,NIL, &key) == -1)
    return ((FILE *) NIL);
  else
    {
      fp = af_open(&key, mode);
      return (fp);
    }
}


get_set(anything,set)
     char *anything;
     Af_set *set;
     {

Af_attrs buf;

char bname[MAXNAMLEN];
char *p;
char *d;
char sysp[MAXNAMLEN];

sysp[0] = '\0';

(void) strcpy(bname,anything);
if ((p = rindex(bname,'.')) == NIL)
  ;
else
  {
    p[0] = '\0';
    *p++;
  }

if ((d = rindex(bname,'/')) != 0)
  {
    (void) strcpy(sysp, bname);
    d = rindex(sysp, '/');
    d[0] = '\0';
    *d++;
    (void) strcpy(bname,d);
  }
af_initattrs(&buf);

(void) strcpy(buf.af_name,bname);
if (p != NIL)
     (void) strcpy(buf.af_type,p);
if(sysp[0] != '\0')
     (void) strcpy(buf.af_syspath, sysp);
else
  (void) strcpy(buf.af_syspath, curvpath[0]);
if (af_find(&buf,set) == -1)
  errexit(10,"af_find");
}



Bool evtl_set_busy(dep, test)
     char *dep;
     Bool test;
{
  struct list *sellist;
  FILE *tmp_fp;
  FILE *afs_fp;
  Af_attrs buf1;
  Af_attrs buf2;

  Af_key key2;
  Af_key keyt;
  
  Af_set set2;
  Af_set sett;

  Bool t1;
  Bool match = FALSE;
  Bool full;
  Bool has_attr = FALSE;
  Bool busy_exist;
  int ii = 0;
  int tt = 0;
  int uda = 0;
  int pathind = 0;
  char *pp;
  char *ppp;
  char *zzz;
  char *pauth;
  char dep2[MAXNAMLEN];
  char *testdep;
  char testpath[MAXNAMLEN];
  char *testtype = NIL;
  Af_attrs testbuf;
  char *xxx;
  int testi = 0;
  int pathj;
  Af_key testkey;
  char *buf;
  char tmpname[MAXNAMLEN];
  char afsname[MAXNAMLEN];
  char afslinkname[MAXNAMLEN];

  (void) strcpy(afsname,dep);
  stopflg = FALSE;

  af_initattrs(&buf1);
  af_initattrs(&buf2);
  (void) strcpy(dep2,dep);

  if (exists_file(dep2, 2))
    return(FALSE);

  t1 = exists_file(dep2,1);
  if(t1)
    {
      if ((testdep = malloc(MAXNAMLEN)) == NIL)
	errexit(10,"malloc");
      (void) strcpy(testdep,dep2);
      if ((xxx = rindex(testdep,'/')) != NIL)
	{
	  *xxx = '\0';
	  (void) strcpy(testpath,testdep);
	  xxx++;
	  testdep = xxx;
	}
      else
	(void) strcpy(testpath,actpath);

      if ((xxx = rindex(testdep,'.')) != NIL)
	{
	  *xxx = '\0';
	  xxx++;
	  testtype = xxx;
	}
      else
	testtype = NIL;

      if(af_getkey(testpath, testdep, testtype, AF_BUSYVERS, AF_BUSYVERS, NIL, &testkey) == -1)
	{
	  if(af_getkey(testpath, testdep, testtype, AF_LASTVERS, AF_LASTVERS, NIL, &testkey) == -1)
	errexit(10,"af_getkey");
	}
      if(af_gattrs(&testkey,&testbuf) == -1)
	errexit(10,"af_gattrs");
      while(testbuf.af_udattrs[testi] != NIL)
	{
	  if(!strncmp(testbuf.af_udattrs[testi],ATTRNAME,10))
	    {
	      has_attr = TRUE;
	      break;
	    }
	  testi++;
	}

      if((!has_attr) && (get_target(dep) == (struct rules *) NIL))
	{
	  append_mtime(&testbuf,depth);
	  if((af_dropkey(&testkey)) == -1)
	    errexit(10,"af_dropkey");
	  free(testdep);
	}
      (void) strcpy(actpath, testpath);
      if(has_attr)
	{
	  if((af_dropkey(&testkey)) == -1)
	    errexit(10,"af_dropkey");
	  free(testdep);
	  return(FALSE);
	}
    }
      
  if (t1)
    {
      /* dep name matches? */
      ii = 0;
      while ((currule->predlist[ii] != (struct list *) NIL) && (match == FALSE))
	{
	  if((currule->predlist[ii]->selfunc(dep,currule->predlist[ii]->parv)) == TRUE)
	    {
	      match = TRUE;
	      if (match == FALSE)
		ii++;
	    }
	  if (match == TRUE)
	    {
	      if(currule->predlist[ii]->i == SMILEY)
		{
		  (void) tunix(NIL,NIL,(Af_set *) NIL);
		}
	      if(currule->predlist[ii]->i == GRIMMY)
		{
		  (void) stopit(NIL,NIL,(Af_set *) NIL);
		}
	      
	      (void) strcpy(dollarplus, dep);

	      if (index(dep,'/') == NIL)
		{
		  if(strcmp(actpath,""))
		    (void) strcpy(testpath,actpath);
		  else
		    (void) strcpy(testpath,curvpath[0]);
		  (void) strcat(testpath,"/");
		  (void) strcat(testpath,dep);
		  get_set(testpath,&set2);
		}
	      else
		get_set(dep,&set2);

	      if (set2.af_setlen == 0)
		return(TRUE);

	      /* generate buffer */
	      af_initattrs(&buft);
	      /* insert unique attrs */
	    
	      if (af_setgkey(&set2,0, &key2) == -1)
		errexit(10,"af_setgkey");

	      if (af_dropset(&set2) == -1)
		errexit(10,"af_dropset");

	      if (af_gattrs(&key2,&buf2) == -1)
		errexit(10,"af_gattrs");
	      
	      (void) strcpy(buft.af_name,buf2.af_name);
	      (void) strcpy(buft.af_type,buf2.af_type);
	      (void) strcpy(buft.af_syspath,buf2.af_syspath);
	      sellist = currule->predlist[ii];
	      while (sellist != (struct list *) NIL)
		{
		  if((sellist->i == 0) && (test))
		    sellist->selfunc(sellist->parn,sellist->parv, (Af_set *) NIL);
		  sellist = sellist->cont;
		}
	      sellist = currule->predlist[ii];
	      while (sellist != (struct list *) NIL)
		{
		  tt = get_attr_type(sellist->parn);
		  if (sellist->i == 1)
		    {
		      switch (tt)
			{
			case 0:
			  buft.af_gen = atoi(sellist->parv);
			  break;
			case 1:
			  buft.af_rev = atoi(sellist->parv);
			  break;
			case 2:
			  buft.af_state = (short) get_state_no(sellist->parv);
			  if (buft.af_state == 99)
			    errexit(16, sellist->parv);
			  break;
			case 3:
			  (void) strcpy(buft.af_author.af_username,sellist->parv);
			  if ((pauth = index(buft.af_author.af_username,'@')) != NIL)
			    {
			      *pauth = '\0';
			      pauth++;
			      (void) strcpy(buft.af_author.af_userhost, pauth);
			    }
			  break;
			case 4:
			  errexit(10,"group id");
			  break;
			case 5:
			  if ((ppp = malloc((unsigned) (strlen(sellist->parv) + 1))) == NIL)
			    errexit(10,"malloc");
			  (void) strcpy(ppp,sellist->parv);
			  if (( pp = index(ppp,'.')) == 0)
			    errexit(9,sellist->parv);
			  else
			    {
			      pp[0] = '\0';
			      buft.af_gen = atoi(ppp);
			      pp++;
			      buft.af_rev = atoi(pp);
			    }
			  break;
			case 6:
			  /* variant */
			  break; /* evtl. set path & flags ???? */
			case 7:
			  (void) strcpy(buft.af_syspath,sellist->parv);
			  break;
			case 8:
			  (void) strcpy(buft.af_host,sellist->parv);
			  break;
			default:
			  if ((buft.af_udattrs[uda] =
			       malloc((unsigned) (strlen(sellist->parv) + 1 + strlen(sellist->parn) + 1 + 1))) == NIL)
			    errexit(10,"malloc");
			  (void) strcpy(buft.af_udattrs[uda],sellist->parn);
			  (void) strcat(buft.af_udattrs[uda],"=");
			  (void) strcat(buft.af_udattrs[uda],sellist->parv);
			  uda++;
			  break;
			}
		    }
/* else part by Sibylle */
		  else
		    {
		      if ((sellist->i == 2) && (tt > 5))
                      /* if sellist->selfunc is attrnot, attrlt, attrgt,    */
                      /* attrle, attrge, attrmax or attrmin and parameter   */
                      /* type is uda then it's more efficient to perform    */
                      /* af_find on said uda. Hence parn is copied to buft. */
			{
			  if ((buft.af_udattrs[uda] =
			       malloc((unsigned) (strlen(sellist->parn) + 1))) == NIL)
			    errexit(10,"malloc");
			  (void) strcpy(buft.af_udattrs[uda],sellist->parn);
			  uda++;
			  break;
			}
		    }
			  
		  sellist = sellist->cont;
		}
	      /* af_find with this buffer */

	      pathj = pathi;
	      while(curvpath[pathj] == NIL)
		pathj--;

	      for(pathind = pathj; pathind >= 0; pathind--)
		{
		  if ((zzz = rindex(dep,'/')) == NIL)
		    {
		      (void) strcpy(buft.af_syspath,curvpath[pathind]);
		    }
		  else
		    {
		      (void) strcpy(buft.af_syspath,dep);
		      zzz = rindex(buft.af_syspath,'/');
		      *zzz = '\0';
		    }
		  if (af_find(&buft,&sett) == -1)
		    errexit(10,"af_find");
		  if (sett.af_nkeys != 0)
		    {
		      sellist = currule->predlist[ii];
		      full = TRUE;
		      while((sellist != (struct list *) NIL) && (full))
			{
			  if (sellist->i == 2)
			    {
			      full = sellist->selfunc(sellist->parn, sellist->parv, &sett);
			    }
			  sellist = sellist->cont;
			}
		    }
		  if (sett.af_nkeys == 1)
		    {
		  /* ==> successful */
		      if (test == FALSE)
			return(TRUE);
		      if (af_setgkey(&sett,0,&keyt) ==  -1)
			errexit(10,"af_setgkey");
		      if(af_gattrs(&keyt,&buft) == -1)
			errexit(10,"af_gattrs");
		      if(confid == TRUE)
			write_confid(&buft);

		      append_attrs(&buft,depth);

		      if ((buft.af_state != AF_BUSY ) || (expflg))
			{
		      /* link, unlink, set busy */
			  if ((afs_fp = af_open(&keyt,"r")) == NULL)
			    errexit(10,"af_open");

		      /* creation of a temporary file for the old revision */
			  (void) strcpy(tmpname,mktemp("shapeXXXXXX"));
			  if ((tmp_fp = fopen(tmpname, "w")) == NULL)
			    errexit(10,"could not create tmpfile");

		      /* copy old revision into temp. file */
			  if ((buf  = malloc((unsigned) buft.af_size)) == NIL)
			    errexit(10,"malloc");
			  (void) fread(buf,sizeof(char),(int) buft.af_size,afs_fp);
			  
			  if(noexpflg)
			    (void) fwrite(buf,sizeof(char),(int) buft.af_size,tmp_fp);
			  else
			    WriteXPand(buf,buft.af_size,tmp_fp,&keyt);
			  free(buf);
			  af_close(afs_fp);
			  (void) fclose(tmp_fp);
			  if (buft.af_syspath == NIL)
			    {
			      (void) strcpy(afsname,curvpath[0]);
			      (void) strcat(afsname,"/");
			    }
			  else
			    {
			      (void) strcpy(afsname,buft.af_syspath);
			      (void) strcat(afsname,"/");
			    }
			  (void) strcat(afsname,buft.af_name);
			  (void) strcat(afsname,".");
			  (void) strcat(afsname,buft.af_type);
			  if(buft.af_syspath == NIL)
			    {
			      (void) strcpy(afslinkname,curvpath[0]);
			      (void) strcat(afslinkname,"/AFS/");
			    }
			  else
			    {
			      (void) strcpy(afslinkname,buft.af_syspath);
			      (void) strcat(afslinkname,"/AFS/");
			    }
			  (void) strcat(afslinkname,buft.af_name);
			  (void) strcat(afslinkname,".");
			  (void) strcat(afslinkname,buft.af_type);
			  (void) strcat(afslinkname,"XXXXXX");
			  (void) strcpy(afslinkname, mktemp(afslinkname));

			  /* save busy version into AFS directory */
			  (void) link(afsname,afsname);
			  if (errno == EEXIST)
			    {
			      busy_exist = TRUE;
			      if (link(afsname,afslinkname) != 0)
				errexit(20, dep);
			      if (unlink(afsname) != 0)
				errexit(21, afsname);
			    }
			  else
			    busy_exist = FALSE;
			  if (link(tmpname,afsname) != 0)
			    errexit(22, afsname);
			  if (unlink(tmpname) != 0)
			    errexit(21, tmpname);
			  register_link(afsname,afslinkname,busy_exist);
			  if (buft.af_state != AF_BUSY)
			    busy_done = TRUE;
			  return (TRUE);
			}
		      else
			return(TRUE);
		    }
		}
	      if ((sett.af_nkeys == 0) && (currule->predlist[ii+1] == (struct list *) NIL) && (!tunixflg))
		{
		  if ((get_target(dep2)) != (struct rules *) NIL)
		    return(TRUE);
		  else
		    errexit(17,dep2);
		}
	      else
		/* next predicate */
		{
		  if (stopflg)
		    errexit(28,dep);
		  if(tunixflg)
		    {
		      tunixflg = FALSE;
		      return(FALSE);
		    }
		  if (af_dropset(&sett) == -1)
		    errexit(10,"af_dropset");
		  
		}
	    }
	  ii++;
	  stopflg = FALSE;
	  match = FALSE;
	  reset_vclass();
	} /* end while */

/*      if (buft.af_syspath != NIL)
	{
	  (void) strcpy(afsname,buft.af_syspath);
	  (void) strcat(afsname,"/");
	  (void) strcat(afsname,dep);
	}
	(void) link(afsname,afsname);
      if ((buft.af_state == AF_BUSY) && (errno == EEXIST))
	return(TRUE);
*/
      if ((match == FALSE) && (currule->predlist[ii] == (struct list *) NIL))
	{
	  if ((get_target(dep)) != (struct rules *) NIL)
	    return(TRUE);
	  else
	    errexit(17,dep);
	}
    }
  /*NOTREACHED*/
  return(FALSE);
}



int init_confid(name)
     char *name;
{
  fprintf(cid,"###### CONFID for %s ######\n", name);
  fprintf(cid,"\n");
  fprintf(cid,"#%% RULE-SECTION\n");
  fprintf(cid,"@%s:\n", name);
}



int write_confid(buf)
     Af_attrs *buf;
{
  fprintf(cid,"\t%s.%s,\n", buf->af_name, buf->af_type);
  
  fprintf(cid,"\tattr(host,%s),\n", buf->af_host);

  fprintf(cid,"\tattr(syspath,%s),\n", buf->af_syspath);

/*  fprintf(cid,"\tattr(type,%s),\n", buf->af_type); */

  if(buf->af_gen != AF_BUSYVERS)
    {
      fprintf(cid,"\tattr(generation,%d),\n", buf->af_gen);

      fprintf(cid,"\tattr(revision,%d),\n", buf->af_rev);
    }

  if (strcmp(buf->af_variant,""))
    fprintf(cid,"\tattr(variant,%s),\n", buf->af_variant);

  if (buf->af_state != AF_FROZEN)
    {
      fprintf(cid,"\tmsg(warning: confid contains %s version for %s.%s),\n",
	      states[buf->af_state], buf->af_name, buf->af_type);
      fprintf(stderr,"shape - warning: confid contains %s version for %s.%s\n",
	      states[buf->af_state], buf->af_name, buf->af_type);
    }

  fprintf(cid,"\tattr(state,%s),\n", states[buf->af_state]);
/*  fprintf(cid,"\tattr(owner,%s@%s),\n",
	  buf->af_owner.af_username, buf->af_owner.af_userhost); */

  fprintf(cid,"\tattr(author,%s@%s)",
	  buf->af_author.af_username, buf->af_author.af_userhost);

/*  fprintf(cid,"\tattr(size,%d),\n", buf->af_size); */

/*  fprintf(cid,"\tattr(mode,%d),\n", buf->af_mode); */

/*  if(strcmp(buf->af_locker.af_username,""))
    fprintf(cid,"\tattr(locker,%s@%s),\n",
	    buf->af_locker.af_username, buf->af_locker.af_userhost); */

/*  fprintf(cid,"\tattr(mtime,%d),\n", buf->af_mtime); */

/*  fprintf(cid,"\tattr(atime,%d),\n", buf->af_atime); */

/*  fprintf(cid,"\tattr(ctime,%d),\n", buf->af_ctime); */

/*  fprintf(cid,"\tattr(stime,%d),\n", buf->af_stime); */

/*  fprintf(cid,"\tattr(ltime,%d)", buf->af_ltime); */
  
    fprintf(cid,";\n");

  fprintf(cid,"\n");
  (void) fflush(cid);
}

int finish_confid()

{
  fprintf(cid,"\t:-\) SMILEY,\n\tmsg\(\"Just to get a . to the end of the rule\"\).\n\n");
  fprintf(cid,"#%% END-RULE-SECTION\n");
  fprintf(cid,"\n");
  dump(cid);
  ruledump(cid);
  vardump(cid);
}


FILE *cmfopen( filename, mode, gen,rev)
     char *filename;
     char *mode;
     /*ARGSUSED*/
     int gen;
     int rev;
{
  char syspath[MAXNAMLEN];
  char *name = NIL;
  char *type = NIL;
  
  Af_key key;

  char *ind;
  char *ind2;
  char *basename;
  FILE *fp;
  char fname[MAXNAMLEN];
  (void) strcpy(fname, filename);

  if ((ind = rindex(fname,'/')) == NIL)
    {
      (void) strcpy(syspath,curvpath[0]);
      basename = fname;
    }
  else
    {
      ind[0] = '\0';
      ind++;
      basename = ind;
      (void) strcpy(syspath,fname);
    }
  
  if ((ind2 = rindex(basename,'.')) == NIL)
    {
      name = basename;
    }
  else
    {
      ind2[0] = '\0';
      ind2++;
      type = ind2;
      name = basename;
    }
  if(af_crkey(syspath, name, type,&key) == -1)
    errexit(10,"af_crkey");
  else
    {
      fp = af_open(&key, mode);
      return (fp);
    }
  return((FILE *) NIL);
}
