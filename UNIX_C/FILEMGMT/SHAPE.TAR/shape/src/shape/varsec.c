/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *RCSid = "$Header: varsec.c,v 3.0 89/01/24 11:37:15 wolfgang Stable $";
#endif
#ifndef lint
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	varsec.c,v $
 * Revision 3.0  89/01/24  11:37:15  wolfgang
 * New System Generation
 * 
 * Revision 2.18  89/01/03  13:14:14  wolfgang
 * changes done for lint
 * 
 * Revision 2.17  88/12/21  15:13:22  wolfgang
 * changes done for lint
 * 
 * Revision 2.16  88/11/22  18:32:17  wolfgang
 * bug fixed: missing initialisation.
 * 
 * Revision 2.15  88/11/21  15:48:20  wolfgang
 * return code of all malloc's checked
 * 
 * Revision 2.14  88/11/03  17:30:22  wolfgang
 * bug fixed in is_varname().
 * 
 * Revision 2.13  88/10/27  16:37:34  wolfgang
 * bugs fixed (new variant handling).
 * 
 * Revision 2.12  88/10/26  13:13:36  wolfgang
 * changes done for new syntax of variant deps
 * 
 * Revision 2.11  88/10/24  16:21:56  wolfgang
 * another segmentation violation fixed in is_varname().
 * 
 * Revision 2.10  88/10/21  11:36:37  wolfgang
 * bug fixed in is_varname: produced a segmentation violation ($(RULE)+.
 * 
 * Revision 2.9  88/10/20  13:20:16  wolfgang
 * 
 * bug fixed in is_varname: string = "+" caused segmentation violation.
 * 
 * Revision 2.8  88/10/18  17:41:56  wolfgang
 * nearly newly written (for new variant handling)
 * 
 * Revision 2.7  88/10/14  17:15:05  wolfgang
 * varsecname() & varmacrodef() added. vardump() changed.
 * 
 * Revision 2.6  88/09/19  18:40:29  wolfgang
 * Bug fixes. Second endless loop in check_vclass. Shit!!!!
 * 
 * Revision 2.5  88/09/19  18:11:36  wolfgang
 * bug fixed (endless loop in check_vclass).
 * 
 * Revision 2.4  88/09/15  18:41:05  wolfgang
 * check_vclass & reset_vclass added.
 * 
 * Revision 2.3  88/09/15  12:42:54  wolfgang
 * bug fixed.
 * 
 * Revision 2.2  88/08/23  11:23:40  wolfgang
 * New procedure added: vardump(fd). To be used for the generation of
 * confid's. Dumps the variant section.
 * 
 * Revision 2.1  88/08/19  10:18:16  wolfgang
 * This version is part of a release
 * 
 */

#include <sys/types.h>
#include <sys/dir.h>

#include "shape.h"
#include "varsec.h"

varsec_name(string)
     char *string;
{
  char *p;
  int k = 0;

  if (( p = index(string,':')) == 0)
    errexit(14, string);

  *p = '\0';
  while((vardefs[k] != (struct vardef *) NIL))
    {
      if (!strcmp(vardefs[k]->name,string))
	errexit(33, string);
      k++;
    }
  if ((vardefs[k] = (struct vardef *) malloc (sizeof (struct vardef))) == (struct vardef *) NIL)
    errexit(10,"malloc");
  if ((vardefs[k]->name = malloc((unsigned) (strlen(string) + sizeof(char)))) == NIL)
    errexit(10,"malloc");
  (void) strcpy(vardefs[k]->name, string);

  lastvardef = k;
  vardefs[k+1] = (struct vardef *) NIL;

  vardefs[k]->vpath = NIL;
  vardefs[k]->vflags = NIL;
  
  for(k = 0; k < MAXVMACROS; k++)
    vardefs[lastvardef]->vmacros[k] = NIL;
}


varmacrodef(string)
     char *string;
{
  char *p;
  int k = 0;

  if (string[strlen(string) - 1] == '\n')
    string[strlen(string) - 1] = '\0';

  while((*string == '\t') || (*string == ' '))
    string++;

  if(!strncmp(string,"vpath",5))
    {
      if ((p = index(string,'=')) == NIL)
	errexit(7, string);
      p++;
      while((*p == ' ') || (*p == '\t'))
	p++;
      
      if ((vardefs[lastvardef]->vpath = malloc((unsigned) (strlen(p)+sizeof(char)))) == NIL)
	errexit(10,"malloc");
      (void) strcpy(vardefs[lastvardef]->vpath,p);
      return;
    }

  if(!strncmp(string,"vflags",6))
    {
      if ((p = index(string,'=')) == NIL)
	errexit(7, string);
      p++;
      while((*p == ' ') || (*p == '\t'))
	p++;
      
      if ((vardefs[lastvardef]->vflags = malloc((unsigned) (strlen(p)+sizeof(char)))) == NIL)
	errexit(10,"malloc");
      (void) strcpy(vardefs[lastvardef]->vflags,p);
      return;
    }

  while(vardefs[lastvardef]->vmacros[k] != NIL)
    k++;
  
  if ((vardefs[lastvardef]->vmacros[k] = malloc((unsigned) (strlen(string) + sizeof(char)))) == NIL)
    errexit(10,"malloc");
  (void) strcpy(vardefs[lastvardef]->vmacros[k],string);
}
  


int vardump(fd)
     FILE *fd;
{
int i = 0;
int k = 0;

if (vardefs[i] != (struct vardef *) NIL)
  {

    fprintf(fd,"#%% VARIANT-SECTION\n");

    for(i = 0; vardefs[i] != (struct vardef *) NIL; i++)
      {
	fprintf(fd,"\n");

	fprintf(fd,"%s:\n", vardefs[i]->name);

	if(vardefs[i]->vflags != NIL)
	  fprintf(fd,"\tvflags = %s\n", vardefs[i]->vflags);

	if(vardefs[i]->vpath != NIL)
	  fprintf(fd,"\tvpath = %s\n", vardefs[i]->vpath);

	while(vardefs[i]->vmacros[k] != NIL)
	  {
	    fprintf(fd,"\t%s\n",vardefs[i]->vmacros[k]);
	    k++;
	  }
	k = 0;
      }
    fprintf(fd,"\n");

    fprintf(fd,"#%% END-VARIANT-SECTION\n");
    
    (void) fflush(fd);
  }
}

	    
vclassdef(string)
     char *string;
{
char *p;
char *vname;
int k = 0;
int l = 0;
int j = 0;
char vc[32];

if ((p = index(string,' ')) == NIL)
  errexit(14,string);
else
  {
    *p = '\0';
    p++;
    vname = p;
    string = p;
    if ((p = index(string,':')) == NIL)
      errexit(14,string);
    *p = '\0';
    string++;
    if ((p = index(vname,' ')) != NIL)
      *p = '\0';
    while(vclass[k] != (struct varclass *) NIL)
      k++;
    if((vclass[k] = (struct varclass *) malloc( sizeof (struct varclass))) == (struct varclass *) NIL)
      errexit(10,"malloc");
    if ((vclass[k]->name = malloc((unsigned) (strlen(vname) + sizeof(char)))) == NIL)
      errexit(10,"malloc");
    (void) strcpy(vclass[k]->name,vname);
    vclass[k]->active = -1;
  }

while(*string != '(')
  string++;

string++;

while(*string != ')')
  {
    while((*string == ' ') || (*string == '\t'))
      string++;

    while((*string != ',') && (*string != ')'))
      {
	vc[j] = *string;
	string++;
	j++;
      }
    if (*string == ',')
      string++;

    vc[j] = '\0';
    if ((vclass[k]->variants[l] = malloc((unsigned) (strlen(vc) + sizeof(char)))) == NIL)
      errexit(10,"malloc");
    (void) strcpy(vclass[k]->variants[l],vc);
    l++;
    vclass[k]->variants[l] = NIL;
    j = 0;
    while((*string == ' ') || (*string == '\t'))
      string++;
  }
}

	
Bool check_vclass(varname)
     char *varname;
{
  int i = 0;
  int j = 0;
  
  while(vclass[i] != (struct varclass *) NIL)
    {
      j = 0;
      while(vclass[i]->variants[j] != NIL)
	{
	  if(strcmp(vclass[i]->variants[j],varname) == 0)
	    {
	      if((vclass[i]->active != -1) && (vclass[i]->active != j))
		return(FALSE);
	      vclass[i]->active = j;
	      return(TRUE);
	    }
	  j++;
	}
      i++;
    }
  if(vclass[i] == (struct varclass *) NIL)
    return(TRUE);
/*NOTREACHED*/
return(FALSE);
}

reset_vclass()
{
  int i = 0;

  while( vclass[i] != (struct varclass *) NIL)
    {
      vclass[i]->active = -1;
      i++;
    }
}


    
Bool is_varname(string)
     char *string;
{
  char *p;
  int k = 0;

  if(string == NIL)
    return(FALSE);

  if(string[0] != '+')
    return(FALSE);

  p = index(string,'+');
  p++;

  while(vardefs[k] != (struct vardef *) NIL)
    {
      if(!strcmp(vardefs[k]->name,p))
	return(TRUE);
      k++;
    }
  return(FALSE);
}
