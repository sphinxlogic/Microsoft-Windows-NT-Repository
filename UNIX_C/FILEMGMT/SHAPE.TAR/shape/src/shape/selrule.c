/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *RCSid = "$Header: selrule.c,v 3.1 89/02/20 18:55:14 wolfgang Exp $";
#endif
#ifndef lint
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	selrule.c,v $
 * Revision 3.1  89/02/20  18:55:14  wolfgang
 * inititialisation of ->cont added.
 * 
 * Revision 3.0  89/01/24  11:36:48  wolfgang
 * New System Generation
 * 
 * Revision 2.12  89/01/18  13:42:05  wolfgang
 * init_selruletab() added.
 * 
 * Revision 2.11  89/01/03  13:13:27  wolfgang
 * changes done for lint
 * 
 * Revision 2.10  88/12/21  15:12:40  wolfgang
 * changes done for lint
 * 
 * Revision 2.9  88/11/21  15:48:33  wolfgang
 * return code of all malloc's checked
 * 
 * Revision 2.8  88/11/02  13:30:40  wolfgang
 * This version is part of a release
 * 
 * Revision 2.7  88/10/18  17:43:20  wolfgang
 * new variant handling
 * 
 * Revision 2.6  88/10/10  17:03:06  wolfgang
 * This version is part of a release
 * 
 * Revision 2.5  88/09/16  19:58:35  wolfgang
 * bug fixed.
 * 
 * Revision 2.4  88/09/16  19:39:24  wolfgang
 * syntactic analysis of rule section improved.
 * 
 * Revision 2.3  88/09/16  11:04:44  wolfgang
 * bug fixed.
 * 
 * Revision 2.2  88/08/23  14:40:15  wolfgang
 * Minor bug fixed. Still the syntactical analysis is a hack.
 * 
 * Revision 2.1  88/08/19  10:18:00  wolfgang
 * This version is part of a release
 * 
 */

#include "shape.h"
#include "selrule.h"

  char *stdattr[]  = { "attr",
		       "attrnot",
		       "attrlt",
		       "attrgt",
		       "attrle",
		       "attrge",
		       "attrmin",
		       "attrmax",
		       "getfromcid",
		       "attrvar",
		       "msg",
		       "0"
		       };



extern int hashval();
extern int errexit();
extern struct selection_rules *currule;

struct selection_rules *sels[SELTABSIZE];

int selruledef(string)
     char *string;
{
  char rulename[MAXNAMELENGTH];
  char pred[MAXPREDLENGTH];
  char name[MAXNAMELENGTH];
  char value[MAXVALLENGTH];
  struct selection_rules *cursec;
  struct list *curlist;
  char *predptr;
  int what = 0;
  int hashr;
  int i = 0;
  int j = 0;
  int l = 0;
  int k = 0;
  int kla = 0;
  while (string[i] != '\n')
    i++;
  i++;
  
  while((string[i] != '#') && (string[i+1] != '%'))
    {
      l = 0;
      while((string[i] == '\t') || (string[i] == ' ') || (string[i] == '\n'))
	i++;

      if ((string[i] == '#') && (string[i+1] == '%'))
	errexit(31,NIL);

      /* rule name */
      j = 0;
      while ((string[i] != ' ') && (string[i] != '\t') && (string[i] != ':'))
	{
	  if (string[i] == '\n')
	    errexit(31,NIL);
	  if ((string[i] == '#') && (string[i+1] == '%'))
	    errexit(31,NIL);
	  rulename[j] = string[i];
	  j++;
	  i++;
	}
      rulename[j] = '\0';
#ifdef DEBUG_SELRULE
printf("selrulename:###%s###\n", rulename);
#endif DEBUG_SELRULE
      hashr = hashval(rulename);
      if (sels[hashr] == (struct selection_rules*) NIL)
	{
	  if((cursec = sels[hashr] = (struct selection_rules *) malloc( sizeof( struct selection_rules))) == (struct selection_rules *) NIL)
	    errexit(10,"malloc");
	}
      else
	{
	  cursec = sels[hashr];
	  while((strcmp(cursec->name, rulename) != 0) && (cursec->next != (struct selection_rules *) NIL))
	    cursec = cursec->next;
	  if( strcmp(cursec->name, rulename) == 0)
	    errexit(5, rulename);
	  else
	    {
	      if((cursec = cursec->next = (struct selection_rules *) malloc ( sizeof( struct selection_rules))) == (struct selection_rules *) NIL)
		errexit(10,"malloc");
	    }
	}
      if ((cursec->name = malloc((unsigned) (strlen(rulename) + 1 ))) == NIL)
	errexit(10,"malloc");
      (void) strcpy(cursec->name, rulename);

      while((string[i] == ' ') || (string[i] == '\t') || (string[i] == '\n') || (string[i] == ':'))
	i++;

      if((string[i] == '#') && (string[i+1] == '%'))
	errexit(31,NIL);

      while((string[i] != '.'))
	{
	  if ((string[i] == '#') && (string[i+1] == '%'))
	    errexit(31,NIL);

	  if (string[i] == ';')
	    {
	      if((string[i] == '#') && (string[i+1] == '%'))
		errexit(31,NIL);
	      k++;
	      i++;
	      if((string[i] == '#') && (string[i+1] == '%'))
		errexit(31,NIL);
	      l = 0;
	    }
	  while((string[i] == '\n') || (string[i] == ' ') || (string[i] == '\t'))
	    i++;

	  if ((string[i] == '#') && (string[i+1] == '%'))
	    errexit(31,NIL);

	  while((string[i] != ';') || (kla != 0))
	    {
	      if ((string[i] == '#') && (string[i+1] == '%'))
		errexit(31,NIL);
	      if (string[i] == '.')
		break;
	      j = 0;
	      while((string[i] != ',') && (string[i] != ';') && (string[i] != '('))
		{
		  if ((string[i] == '#') && (string[i+1] == '%'))
		    errexit(31,NIL);
		  if ((string[i] != ' ') && (string[i] != '\t') &&
		      (string[i] != '\n'))
		    {
		      pred[j] = string[i];
		      j++;
		    }
		  if (((string[i] == '-') && (string[i+1] == ')')) ||
		      ((string[i] == '-') && (string[i+1] == '(')))
		    {
		      pred[j] = string[i+1];
		      j++;
		      i++;
		    }
		  if ((string[i] == '#') && (string[i+1] == '%'))
		    errexit(31,NIL);
		  i++;
		  if ((string[i] == '#') && (string[i+1] == '%'))
		    errexit(31,NIL);
		}
	      pred[j]='\0';
#ifdef DEBUG_SELRULE
printf("predicate found:###%s###\n", pred);
#endif DEBUG_SELRULE

	      while(string[i] == '(')
		i++;

	      if ((string[i] == '#') && (string[i+1] == '%'))
		errexit(31,NIL);

	      j  = 0;

	      while((string[i] != ',') && (string[i] != ')') && (l != 0))
		{
		  if ((string[i] == '#') && (string[i+1] == '%'))
		    errexit(31,NIL);
/*		  if ((string[i] != ' ') && (string[i] != '\t')) 
		    { */
		      name[j] = string[i];
		      j++;
/*		    } */
		  i++;

		  if ((string[i] == '#') && (string[i+1] == '%'))
		    errexit(31,NIL);

		}
	      name[j] = '\0';
	  
	      if (string[i] == ',')
		i++;

	      if ((string[i] == '#') && (string[i+1] == '%'))
		errexit(31,NIL);
	      
	      while((string[i] == '\t') || (string[i] == ' '))
		i++;

	      if ((string[i] == '#') && (string[i+1] == '%'))
		errexit(31,NIL);

	      j = 0;
	      while((string[i] != ')') && ( l != 0))
		{
		  if((string[i] == '#') && (string[i+1] == '%'))
		    errexit(31,NIL);
/*		  if((string[i] != ' ') && (string[i] != '\t'))
		    { */
		      value[j] = string[i];
		      j++;
/*		    } */
		  i++;
		}
	      value[j] = '\0';

	      while((string[i] == ')') || (string[i] == ','))
		i++;


	      while((string[i] == ' ') || (string[i] == '\t'))
		i++;

	      if ((string[i] == '#') && (string[i+1] == '%'))
		errexit(31,NIL);
	    
#ifdef DEBUG_SELRULE
if (l != 0)
  printf("name: ###%s###\nvalue: ###%s###\n", name, value);
#endif DEBUG_SELRULE

	      if (l == 0)
		{
		  if((curlist = cursec->predlist[k] = (struct list *) malloc( sizeof (struct list))) == (struct list *) NIL)
		    errexit(10,"malloc");
		  cursec->predlist[k+1] = (struct list *) NIL;
		  curlist->selfunc = pattern;
		  curlist->parn = NIL;
		  curlist->cont = (struct list *) NIL;

		  predptr = &pred[0];
		  predptr = predptr + specials(predptr, &what);

		  if ((curlist->parv = malloc ((unsigned) (strlen(predptr) + sizeof(char)))) == NIL)
		    errexit(10,"malloc");
		  (void) strcpy(curlist->parv, predptr);
		  curlist->i = what;
		  l++;
		  what = 0;
		}
	      else
		{
		  j = 0;
		  while ((strcmp(pred, stdattr[j]) != 0) && (strcmp(stdattr[j],"0")!= 0))
		    j++;
		  if (strcmp(pred,stdattr[j]) != 0 )
		    errexit(6, pred);
		  else
		    {
		      if((curlist = curlist->cont = (struct list *) malloc( sizeof (struct list))) == (struct list *) NIL)
			errexit(10,"malloc");
		      curlist->cont = (struct list *) NIL;
		      if((curlist->parn = malloc((unsigned) (strlen(name) + 1))) == NIL)
			errexit(10,"malloc");
		      (void) strcpy(curlist->parn, name);
		      if ((curlist->parv = malloc((unsigned) (strlen(value) + 1))) == NIL)
			errexit(10,"malloc");
		      (void) strcpy(curlist->parv, value);
			
		      switch (j)
			{
			case 0:
			  curlist->selfunc = attr;
			  curlist->i = 1;
			  break;
			case 1:
			  curlist->selfunc = attrnot;
			  curlist->i = 2;
			  break;
			case 2:
			  curlist->selfunc = attrlt;
			  curlist->i = 2;
			  break;
			case 3:
			  curlist->selfunc = attrgt;
			  curlist->i = 2;
			  break;
			case 4:
			  curlist->selfunc = attrle;
			  curlist->i = 2;
			  break;
			case 5:
			  curlist->selfunc = attrge;
			  curlist->i = 2;
			  break;
			case 6:
			  curlist->selfunc = attrmin;
			  curlist->i = 2;
			  break;
			case 7:
			  curlist->selfunc = attrmax;
			  curlist->i = 2;
			  break;
			case 8:
			  curlist->selfunc = getfromcid;
			  curlist->i = 1;
			  break;
			case 9:
			  curlist->selfunc = attrvar;
			  curlist->i = 0;
			  break;
			case 10:
			  curlist->selfunc = msg;
			  curlist->i = 0;
			  break;
			}
		      pred[0] = '\0';
		      j = 0;
		    }
		}
	    }
	}

      while((string[i] == ' ') || (string[i+1] == '\t'))
	i++;

      if (string[i] == '.')
	{
	  i++;
	  k = 0;
	}
      while ((string[i] == ' ') || (string[i] == '\n') || (string[i] == '\t'))
	i++;
    }
}


#ifdef DEBUG_SELRULE
int seldump()
{
  int i = 0;
  for (i = 0; i < SELTABSIZE; i++)
    {
      if (sels[i] != (struct selection_rules *) NIL)
	{
	  printf("i = %d, name = %s\n",i, sels[i]->name);
	}
    }
}
#endif


Bool is_selrule_name(name)
     char *name;
{
  int hash;
  struct selection_rules *current;

  hash = hashval(name);
  
  if (sels[hash] == (struct selection_rules *) NIL)
    return (FALSE);
  else
    current = sels[hash];

  while (current != (struct selection_rules *) NIL)
    {
      if ((strcmp(current->name, name)) == 0)
	{
	  currule = current;
	  return(TRUE);
	}
      else
	current = current->next;
    }
  
  if ( current == (struct selection_rules *) NIL)
    return(FALSE);

  /*NOTREACHED*/
  return(FALSE);
}


int specials(ptr, what)
     char *ptr;
     int *what;
{
  if(*ptr == '+')
    {
      *what = SMILEY;
      return(1);
    }

  if(*ptr == '-')
    {
      *what = GRIMMY;
      return(1);
    }

  if (!strncmp(ptr,":-)",3))
    {
      *what = SMILEY;
      return(3);
    }

  if (!strncmp(ptr,":-(",3))
    {
      *what = GRIMMY;
      return(3);
    }
  
  what = 0;
  return(0);

}
  
init_selruletab()
{
  bzero((char *) sels, SELTABSIZE * sizeof(struct rules *));
}
