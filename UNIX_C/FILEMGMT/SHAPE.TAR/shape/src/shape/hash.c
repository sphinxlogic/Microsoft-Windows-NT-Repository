/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *RCSid = "$Header: hash.c,v 3.0 89/01/24 11:35:41 wolfgang Stable $";
#endif
#ifndef lint
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	hash.c,v $
 * Revision 3.0  89/01/24  11:35:41  wolfgang
 * New System Generation
 * 
 * Revision 2.7  89/01/03  13:10:39  wolfgang
 * changes done for lint
 * 
 * Revision 2.6  88/12/21  15:03:22  wolfgang
 * changes done for lint
 * 
 * Revision 2.5  88/11/21  15:49:16  wolfgang
 * return code of all malloc's checked
 * 
 * Revision 2.4  88/08/23  16:40:12  wolfgang
 * This version is part of a release
 * 
 * Revision 2.3  88/08/23  14:39:29  wolfgang
 * In dump(fd) the printing of special macros is now suppressed.
 * 
 * Revision 2.2  88/08/22  17:00:57  wolfgang
 * Procedure dump() change to dump(fd) to be able to use it for the
 * construction of confid's.
 * 
 * Revision 2.1  88/08/19  10:17:28  wolfgang
 * This version is part of a release
 * 
 */

#include "hash.h"
#include "shape.h"

#include <stdio.h>

hashval(name)
     char *name;
{
int hash = 0;
int i = 0;

for(; name[i] != '\0'; i++)
  hash = hash + name[i];
return(hash % HASHSIZE);
} /* end hashval */


void addhash(hashv, name, value)
     int hashv;
     char *name;
     char *value;
{

struct hash *current;
  
if (hashtab[hashv] == (struct hash *) NIL)
  {
    if ((current = hashtab[hashv] = (struct hash *) malloc(sizeof(struct hash))) == (struct hash *) NIL)
      errexit(10,"malloc");
    current->name = NIL;
    current->entry = NIL;
    current->next = (struct hash *)NIL;
  }
else
  current = hashtab[hashv];

if (current->name == NIL)
  {
    if ((current->entry = malloc ( (unsigned) strlen(value) + sizeof(char))) == NIL)
      errexit(10,"malloc");
    if((current->name = malloc ( (unsigned) strlen(name) + sizeof(char))) == NIL)
      errexit(10,"malloc");
    (void) strcpy(current->entry, value);
    (void) strcpy(current->name, name);
    return;
  }
else
  {
    while ((strcmp (current->name, name) != 0) &&
	   (current->next != (struct hash *)NIL))
      current = current->next;

    if(strcmp (current->name, name) == 0)
      {
	current->entry = realloc (current->entry,
				  (unsigned) (strlen(value) + sizeof(char)));
	(void) strcpy(current->entry, value);
	return;
      }

    if(current->next == (struct hash *)NIL)
      {
	if ((current = current->next = (struct hash *) malloc(sizeof (struct hash))) == (struct hash *) NIL)
	  errexit(10,"malloc");
	if((current->entry = malloc ( (unsigned) strlen (value) + sizeof(char))) == NIL)
	  errexit(10,"malloc");
	if((current->name = malloc ((unsigned) strlen (name) + sizeof(char))) == NIL)
	  errexit(10,"malloc");
	current->next = (struct hash *) NIL;
	(void) strcpy(current->name, name);
	(void) strcpy(current->entry, value);
	return;
      }
  }
return;
} /* end addhash */


dump(fd)
     FILE *fd;
{
int i;
struct hash *current;

fprintf(fd,"# Macros:\n");

for(i = 0; i < HASHSIZE; i++)
  {
    if (hashtab[i] != (struct hash *) NIL)
      {
	current = hashtab[i];
	while(current != (struct hash *) NIL)
	  {

	    if((current->name[0] != '$') &&
	       (current->name[0] != '*') &&
	       (current->name[0] != '+') &&
	       (current->name[0] != '<') &&
	       (current->name[0] != '?') &&
	       (current->name[0] != '@'))
	      {
		if(fd != stdout)
		  {
		    fprintf(fd,"%s = %s\n", current->name, current->entry);
		  }
		else
		  {
		    fprintf(fd,"\t%s = %s\n", current->name, current->entry);
		  }
	      }
	    current = current->next;

	  }
      }
  }
} /* end dump */
