/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *RCSid = "$Header: select.c,v 3.1 89/02/20 16:26:38 wolfgang Exp $";
#endif
#ifndef lint
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	select.c,v $
 * Revision 3.1  89/02/20  16:26:38  wolfgang
 * NET-RELEASE
 * 
 * Revision 3.0  89/01/24  11:36:45  wolfgang
 * New System Generation
 * 
 * Revision 2.5  89/01/03  13:13:21  wolfgang
 * changes done for lint
 * 
 * Revision 2.4  88/12/21  15:12:33  wolfgang
 * changes done for lint
 * 
 * Revision 2.3  88/11/22  17:37:42  wolfgang
 * This version is part of a release
 * 
 * Revision 2.2  88/08/31  12:12:53  wolfgang
 * Bugs fixed.
 * 
 * Revision 2.1  88/08/19  10:17:57  wolfgang
 * This version is part of a release
 * 
 */

#include <pwd.h>

#include "shape.h"

extern struct passwd *getpwnam();
extern char *mktemp();

extern int get_set();
extern int af_setgkey();
extern int af_gattrs();

extern char current_dep[];
extern Af_attrs buft;
extern int depth;
extern char actpath[];

char cursr[64]; /* name of active selection rule */
struct selection_rules *currule; /* active selection rule */

Bool Sselect(targ, path, ttt, fdep, dep)
     char *targ;
     char *path;
     Bool ttt;
     /*ARGSUSED*/
     char *fdep;
     char *dep;
{

Af_attrs buf1;
/* Af_attrs buft; */

Af_key key1;
Af_key key2;

Af_set set1;
Af_set set2;
Bool t1;
Bool t2;
char path1[MAXNAMLEN];
char path2[MAXNAMLEN];
Bool appflg = TRUE;
char apptest[MAXNAMLEN];

/* if (strcmp(cursr,"-STD-"))
 return(TRUE); */

if (buft.af_name[0] == targ[0])
  {
    (void) strcpy(apptest,buft.af_name);
    (void) strcat(apptest,".");
    (void) strcat(apptest,buft.af_type);
    if (!strcmp(apptest,targ))
      appflg = FALSE;
  }

path1[0] = '\0';
path2[0] = '\0';

af_initattrs(&buf1);
af_initattrs(&buft);

/* no selection rule is active or dep didn't match */
t1 = ttt; /* exists_file(targ,0);  */
(void) strcpy(path1,path); /* actpath); */
t2 = exists_file(dep,0);
(void) strcpy(path2,actpath);
(void) strcpy(actpath,"");
if ((t1) && (t2))
  {

    get_date_of(targ,&set1,path1);
    if (set1.af_setlen == 0)
      return(TRUE);   /* targ only in bpool */

    get_date_of(dep,&set2,path2);
    
    if (af_setgkey(&set1,0,&key1) == -1)
      errexit(10,"af_setgkey");
    if (af_setgkey(&set2,0,&key2) == -1)
      errexit(10,"af_setgkey");
    
    if (af_gattrs(&key1,&buf1) == -1)
      errexit(10,"af_gattrs");
    if (af_gattrs(&key2,&buft) == -1)
      errexit(10,"af_gattrs");
	
    if (af_dropset(&set1) == -1)
      errexit(10, "af_dropset");

    if (af_dropset(&set2) == -1)
      errexit(10, "af_dropset");
    

    if ((buf1.af_mtime < buft.af_mtime) || ((buf1.af_mtime == -1) && (buft.af_mtime == -1)))
      {
	if(appflg)
	  append_attrs(&buft,depth);
	(void) strcpy(current_dep,dep);
	return(TRUE);
      }
    else
      return(FALSE);
  }
else
  {
    (void) strcpy(current_dep,dep);
    if ((!t1) && (t2))
      {
	if (appflg)
	  {
	    /* get attrs for inheritage */
	    get_date_of(dep,&set2,path2);
	    if (af_setgkey(&set2,0,&key2) == -1)
	      errexit(10,"af_setgkey");
	    if (af_gattrs(&key2,&buft) == -1)
	      errexit(10,"af_gattrs");
	    if (af_dropset(&set2) == -1)
	      errexit(10, "af_dropset");
	    append_attrs(&buft,depth);
	  }
	return(TRUE);
      }
    if ((!t1) && (!t2))
      return(TRUE);
    if ((t1) && (!t2))
      return(TRUE);
  }
/*NOTREACHED*/
}

