/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *RCSid = "$Header: produce.c,v 3.4 89/02/21 17:11:28 wolfgang Exp $";
#endif
#ifndef lint
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	produce.c,v $
 * Revision 3.4  89/02/21  17:11:28  wolfgang
 * bug fixed
 * 
 * Revision 3.3  89/02/20  16:26:17  wolfgang
 * NET-RELEASE
 * 
 * Revision 3.2  89/02/14  21:20:51  wolfgang
 * bug fixed.
 * 
 * Revision 3.1  89/02/08  12:45:15  wolfgang
 * performance improved.
 * 
 * Revision 3.0  89/01/24  11:36:19  wolfgang
 * New System Generation
 * 
 * Revision 2.39  89/01/19  12:37:14  wolfgang
 * .DEFAULT added.
 * 
 * Revision 2.38  89/01/18  13:40:59  wolfgang
 * bug fixed: if -n specified the message 'target is up to date' was printed out
 * 
 * Revision 2.37  89/01/13  12:38:37  wolfgang
 * bug fixed. -k option doesn't work correct.
 * 
 * Revision 2.36  89/01/03  13:12:35  wolfgang
 * changes done for lint
 * 
 * Revision 2.35  88/12/22  13:23:38  wolfgang
 * error_occ added.
 * 
 * Revision 2.34  88/12/22  12:33:40  wolfgang
 * bug fixed. handling of -k option has not been correct.
 * call of cleanup_links added.
 * 
 * Revision 2.33  88/12/21  15:11:21  wolfgang
 * changes done for lint
 * 
 * Revision 2.32  88/12/12  13:15:07  wolfgang
 * bug fixed. single suffix rules didn't work
 * 
 * Revision 2.31  88/11/24  12:08:05  wolfgang
 * Argument for -confid *must* now be a target name.
 * 
 * Revision 2.30  88/11/21  20:54:56  wolfgang
 * changes done for sun
 * 
 * Revision 2.29  88/11/21  15:50:07  wolfgang
 * return code of all malloc's checked
 * 
 * Revision 2.28  88/11/09  16:27:05  wolfgang
 * inheritage changed.
 * 
 * Revision 2.27  88/10/27  16:37:04  wolfgang
 * bugs fixed (new variant handling).
 * 
 * Revision 2.26  88/10/26  13:12:45  wolfgang
 * changes done for new syntax of variant deps.
 * 
 * Revision 2.25  88/10/24  16:20:25  wolfgang
 * calls of reduce_path_and_flags() deleted
 * 
 * Revision 2.24  88/10/21  14:56:42  wolfgang
 * calls of attrvar added.
 * 
 * Revision 2.23  88/10/18  17:40:24  wolfgang
 * changes done for new variant handling
 * 
 * Revision 2.22  88/10/10  16:53:24  wolfgang
 * changes for option -t
 * 
 * Revision 2.21  88/10/03  12:54:19  wolfgang
 * if via the -R option an unknown selection rule name is passed to shape, shape
 * now stops (correctly!!).
 * 
 * Revision 2.20  88/09/26  14:15:40  wolfgang
 * strange bug fixed in reduce_vpath_and_vflags (perhaps a malloc problem).
 * 
 * Revision 2.19  88/09/22  18:57:09  wolfgang
 * bug fixed. activ selection rule is now correct (hopefully).
 * 
 * Revision 2.18  88/09/22  16:13:35  wolfgang
 * bugs fixed.
 * 
 * Revision 2.17  88/09/22  10:04:04  wolfgang
 * bugs fixed. ruleset & reset vflags.
 * 
 * Revision 2.16  88/09/20  10:24:53  wolfgang
 * bug fixed. segmentation violation in set_pathi due to non-initialization 
 * of i.
 * 
 * Revision 2.15  88/09/20  10:03:21  wolfgang
 * set_pathi() added.
 * 
 * Revision 2.14  88/09/19  15:23:32  wolfgang
 * This version is part of a release
 * 
 * Revision 2.13  88/09/19  14:41:42  wolfgang
 * Bugs fixed. Single suffix rules weren't evaluated corectly
 * 
 * Revision 2.12  88/09/15  18:41:40  wolfgang
 * calls of set_path_and_flags deleted.
 * 
 * Revision 2.11  88/09/14  14:00:26  wolfgang
 * bug fixed. variant path & flags have not been reset correctly.
 * 
 * Revision 2.10  88/09/14  12:15:27  wolfgang
 * minor bug fixed.
 * 
 * Revision 2.9  88/09/14  10:52:46  wolfgang
 * undone last changes
 * 
 * Revision 2.8  88/09/13  09:56:29  wolfgang
 * Changes done to allow overloading of imlpicit standard rules.
 * 
 * Revision 2.7  88/09/07  11:25:29  wolfgang
 * This version is part of a release
 * 
 * Revision 2.6  88/08/31  12:04:00  wolfgang
 * Bugs fixed.
 * 
 * Revision 2.5  88/08/25  16:03:37  wolfgang
 * Little but effectful change (the procedure select gets more and more
 * unnecessary).
 * 
 * Revision 2.4  88/08/23  16:39:02  wolfgang
 * Rebuild feature added (to rebuild something from a confid).
 * 
 * Revision 2.3  88/08/22  10:14:15  wolfgang
 * Changed produce(), so that it is no longer necessary to have a descrition
 * file. It's enaugh to have the name of a target to produce on the command
 * line.
 * 
 * Revision 2.2  88/08/19  17:02:31  wolfgang
 * little bug fix.
 * 
 * Revision 2.1  88/08/19  10:17:42  wolfgang
 * This version is part of a release
 * 
 */

/* $? neu machen !!!! ????? */


#include "shape.h"
#define MAXCMDLENGTH 1024
extern char *rindex();

Bool error_happened = FALSE;
Bool error_occ = FALSE;

extern int cleanup_links();
extern struct linkreg *link_reg;
extern int free_linklist();
extern void warning();
extern int errexit();
extern int hashval();
extern char *expandmacro();
extern char *repl_string();
extern char *get_src_name();
extern char *build_attrstring();
extern Bool compare_attrstring();
extern Bool exists_file();
extern Bool Sselect();
extern Bool evtl_set_busy();
extern Bool is_selrule_name();
extern Bool is_varname();
extern Bool attrvar();
extern int save_targets();
extern char cfname[];
extern struct rules *ruletab[];
extern int implicit_suffs[];
extern int pathi;
extern char *cmdtargets[];
extern char *firsttarget;
extern char actpath[];
extern char cursr[];
extern char *curvar[];
extern char *longattrs[];
extern char *stdselrule;
extern struct selection_rules *std_selrule;
extern struct selection_rules *currule;
extern int variants_active;

char rbrule[64];
char rbtarg[64];
char ruleset[32];
char lastcurdep[MAXNAMLEN];

char current_dep[MAXNAMLEN];
Bool busy_done = FALSE;
Bool reallydone = FALSE;
int depth;
char *default_targets = ".DEFAULT";


char *expand_command (cmd, cur, rel_dep)
     char *cmd;
     struct rules *cur;
     char *rel_dep;
{
  char *curdep;
  char *comm;
  int i = 0;
  int j = 0;
  int k = 0;
  char *common_prefix;
  char *p;
  char *hhhp, *hhh2p;
  char hhh[64];
  char hhh2[64];
  Bool ttt = FALSE;
  char path1[MAXNAMLEN];
  if((comm = malloc(MAXCMDLENGTH * sizeof(char))) == NIL)
    errexit(10,"malloc");
  
  while(cmd[i] != '\0')
    {
      if((cmd[i] != '$') && (cmd[i] != '%'))
	{
	  comm[j] =  cmd[i];
	  i++;
	  j++;
	}
      else
	{
	  switch (cmd[i+1])
	    {
	    case '@':
	      if (cur->name[0] != '%')
		{
		  comm[j] = '\0';
		  (void) strcat(comm, cur->name);
		  (void) strcat(comm," ");
		  j = j + strlen(cur->name) + 1;
		  i = i + 2;
		}
	      else
		{
		  comm[j] = '\0';
		  (void) strcpy(hhh,rel_dep);
		  hhhp = rindex(hhh,'.');
		  if (hhhp != NIL)
		    {
		      hhhp[0] = '\0';
		    }
		  (void) strcpy(hhh2, cur->name);
		  hhh2p = rindex(hhh2,'.');
		  (void) strcat(hhh,hhh2p);
		  (void) strcat(comm, hhh);
		  (void) strcat(comm, " ");
		  j = j + strlen(hhh) + 1;
		  i = i + 2;
		}
	      
	      break;
	    case '?':
	      if (cur->deplist[0] != NIL)
		{
		  k = 1;
		  curdep = cur->deplist[0];
		  ttt = exists_file(cur->name,0);
		  (void) strcpy(path1,actpath);
		  /*		  strcpy(actpath,"");  */
		  while(curdep != NIL)
		    {
		      if (Sselect(cur->name, path1, ttt, cur->deplist[0],curdep))
			/* if (cur->date < curdep->date)  ????? */
			{
			  comm[j] = '\0';
			  (void) strcat(comm, curdep);
			  (void) strcat(comm," ");
			  j = j + strlen(curdep) + 1;
			}
		      k++;
		      curdep = cur->deplist[k];
		    }
		}
	      i = i + 2;
	      break;
	    case '<':
	      comm[j] = '\0';
	      if (strcmp(actpath,"") != 0)
		{
		  (void) strcat(comm,actpath);
		  (void) strcat(comm,"/");
		  j = j + strlen(actpath) + 1;
		}
	      (void) strcat(comm, rel_dep);
	      (void) strcat(comm, " ");
	      j = j + strlen(rel_dep) + 1;
	      i = i + 2;
	      break;
	    case '*':
	    case '.':
	    case ' ':
	      if (cur->name[0] != '%')
		{
		  if ((common_prefix = malloc((unsigned) (strlen(cur->name) + 1))) == NIL)
		    errexit(10,"malloc");
		  (void) strcpy(common_prefix, cur->name);
		  if ((p = rindex(common_prefix,'.')) != NIL)
		    {
		      p[0] = '\0';
		    }
		  comm[j] = '\0';
		  (void) strcat(comm, common_prefix);
		  j = j + strlen(common_prefix);
		  if (cmd[i+1] == '*')
		    i = i + 2;
		  else
		    i++;
		}
	      else
		{
		  comm[j] = '\0';
		  (void) strcpy(hhh,rel_dep);
		  hhhp = rindex(hhh,'.');
		  if(hhhp != NIL)
		    {
		      hhhp[1] = '\0';
		    }
		  (void) strcat(comm, hhh);
		  j = j + strlen(hhh);
		  if (cur->name[1] == '.')
		    i = i + 2;
		  else
		    i = i+1;
		}
	      
	      break;
	    case '(':
	      errexit(99,"output tarnslation $(name:str1=str2)");
	      /* ???? output translation, not yet implemented */
	      break;
	    case '$':
	      comm[j] = '$';
	      j++;
	      i = i+2;
	      break;
	    default:
	      if(cmd[i] == '%')
		/* single suffix rule */
		{
		  comm[j] = '\0';
		  (void) strcpy(hhh,rel_dep);
		  hhhp = rindex(hhh,'.');
		  if(hhhp != NIL)
		    {
		      hhhp[1] = '\0';
		    }
		  (void) strcat(comm, hhh);
		  j = j + strlen(hhh);
		  i = i+1;
		}
	      else
		{
		  comm[j] = cmd[i];
		  j++;
		  i++;
		}
	      break;
	    }
	}
    }
  comm[j] = '\0';
  if (comm[0] == '\0')
    (void) strcpy(comm,cmd);
  return(comm);
}


struct rules *get_target(targ)
     char *targ;
{
  int hasht;
  struct rules *current = (struct rules *) NIL;
  char *p = NIL;
  char fname[MAXNAMLEN];
  char fnames[10][MAXNAMLEN];
  char targrulename[MAXNAMLEN];
  int i;
  int j;
  Bool ttt = FALSE;
  Bool tttt = TRUE;
  Bool xxx = TRUE;
  char path1[MAXNAMLEN];
  
  if (targ == NIL)
    return((struct rules *) NIL);
  
  hasht = hashval(targ);
  
  if ( ruletab[hasht] != (struct rules *) NIL)
    {
      current = ruletab[hasht];
      while((current != (struct rules *) NIL ) && (strcmp(targ, current->name) != 0))
	{
	  current = current->nextrule;
	}
    }
  if (current != (struct rules *) NIL)
    {
      if (strcmp(targ, current->name) == 0)
	return(current);
    }
  if ((ruletab[hasht] == (struct rules *) NIL) || ((current == (struct rules *) NIL)) || (strcmp(targ,current->name) != 0))
    {
      /* look for std rule */

      if (TRUE)
	{
	  p = rindex(fname,'.');
	  ttt = exists_file(targ,0);
	  (void) strcpy(path1, actpath);
	  (void) strcpy(actpath,"");
	  for(i = 0; implicit_suffs[i] != -1; i++)
	    {
	      (void) strcpy(fname,targ);
	      p = rindex(fname,'.');
  
	      tttt = TRUE;
	      /* build source name */
	      if (p != NIL)
		*p = '\0';   /* p = suffix of target */
	      if (p != NIL)
		(void) strcpy(targrulename,"%.");
	      else
		(void) strcpy(targrulename,"%");
	      if (p != NIL)
		(void) strcat(targrulename,p + 1);
	      if (strcmp(targrulename, stdruletab[implicit_suffs[i]]->name) == 0)
		{
		  /* several dependents may be necessary */

		  for (j = 0; j < 10; j++)
		    {
		      fnames[j][0] = '\0';
		    }
		  
		  for (j = 0; stdruletab[implicit_suffs[i]]->deplist[j] != NIL; j++)
		    {
		      (void) strcat(fname,stdruletab[implicit_suffs[i]]->deplist[j]+1);
		      tttt = tttt && exists_file(fname,0);
		      if (tttt)
			(void) strcpy(fnames[j],fname);
		      if (p != NIL)
			*p = '\0';
		      else
			(void) strcpy(fname,targ);
		    }
		  if(tttt)
		    {
		      
		      if (TRUE)
			{
			  j = 0;
			  xxx = TRUE;
			  while((fnames[j][0] != '\0') && (xxx))
			    {
			      xxx = xxx && evtl_set_busy(fnames[j], FALSE);
			      if (!xxx)
				break;
			      j++;
			    }
			  if (xxx)
			    {
			      for (j = 0; fnames[j][0] != '\0'; j++)
				(void) evtl_set_busy(fnames[j], TRUE);
			      (void) strcpy(current_dep,targ);
			      return(stdruletab[implicit_suffs[i]]);
			    }
			}
		      
		      if(!ttt)
			{
			  /* to get the attrs .... */
			  (void) Sselect(targ, path1, ttt, NIL, fnames[0]);/* ???? */
			  
			  (void) strcpy(current_dep,targ);
			  return(stdruletab[implicit_suffs[i]]);
			}
		      
		      if(Sselect(targ, path1, ttt, NIL, fnames[0])) /* ??? */
			{
			  (void) strcpy(current_dep,targ);
			  return(stdruletab[implicit_suffs[i]]);
			}
		      else
			return (struct rules *) NIL;
		    }
		}
	    }
	  if(implicit_suffs[i] == -1)
	    return (struct rules *) NIL;
	}
    }
  /*NOTREACHED*/
  return (struct rules *) NIL;
}


produce()
{
  int k = 0;
  char *comm;

  if(confid)
    {
      if((get_target(cfname) == (struct rules *) NIL))
	errexit(35,cfname);
    }
      
  set_pathi();

  (void) strcpy(cursr,"-STD-");

  if (cmdtargets[0] == NIL) /* no targets on commandline */
    {
      if((get_target(".DEFAULT") != (struct rules *) NIL))
	comm = default_targets;
      else
	comm = firsttarget;
    }
  else
    comm = cmdtargets[k++];

  if((nostdfile == TRUE) && (fileflg == FALSE) && (cmdtargets[0] == NIL))
    errexit(11,NIL);
  
  if (!rebuildflg)
    {
      if (ruleflg)
	{
	  if (is_selrule_name(ruleset))
	    (void) strcpy(cursr,ruleset);
	  else
	    errexit(32,ruleset);
	}
      else
	(void) strcpy(cursr,"-STD-");
    }
  else
    (void) strcpy(cursr,rbrule);
  
  if (!rebuildflg)
    {
      while (comm != NIL)
	{
	  depth = 0;
	  (void) make_target(comm,cursr,curvar[0]);
      
	  if (!reallydone)
	    printf("shape - `%s' is up to date\n", comm);
      
	  if (comm != firsttarget)
	    comm = cmdtargets[k++];
	  else
	    comm = NIL;
	}
    }
  else
    {
      depth = 0;
      (void) make_target(rbtarg,cursr,curvar[0]);
      if (!reallydone)
	printf("shape - `%s' is up to date\n");
    }
}



Bool make_target(targ, sr, vname)
     char *targ;
     char *sr;
     /*ARGSUSED*/
     char *vname;
{
  struct rules *current;
  char *curdep;
  char *point = NIL;
  char *srcname;
  char dep2[MAXNAMLEN];
  Bool err_happ = FALSE;
  Bool todo = FALSE;
  Bool test = FALSE;
  Bool t1 = FALSE;
  char lselrule[64];
  char lvar[64];
  char lvarname[64];
  char *xxx;
  Bool lbusy_done = FALSE;
  char path1[MAXNAMLEN];
  int dep = 0;
  int curi = 0;

  depth++;

  (void) is_selrule_name(sr);

  (void) strcpy(lselrule,sr);
  
  if ((current = get_target(targ)) == (struct rules *) NIL)
    {
      if (!exists_file(targ,0))
	errexit(3,targ);
      else
	{
	  if(strcmp(targ,lastcurdep))
	    {
	      if(evtl_set_busy(targ,TRUE))
		{
		  (void) strcpy(lastcurdep,targ);
		  (void) strcpy(sr,lselrule);
		  return(TRUE);
		}
	    }
	  else
	    return (FALSE);
	}
    }

  if (current->done)
    {
      (void) strcpy(sr,lselrule);
      return(FALSE);
    }
  
  if ((current->deplist[dep] == NIL) && (exists_file(current->name,0)))
    {
      (void) strcpy(sr,lselrule);
      return(FALSE);
    }

  lbusy_done = busy_done;
  
  if (current->deplist[dep] != NIL)
    {
      if (is_selrule_name(current->deplist[dep]))
	{
	  (void) strcpy(lselrule,current->deplist[dep]);
	  if ((xxx = index(lselrule,'+')) != NIL)
	    *xxx = '\0';
	  (void) strcpy(sr,lselrule);
	  (void) strcpy(cursr,sr);
	  dep++;
	}
      while(is_varname(current->deplist[dep]))
	{
	  (void) strcpy(lvarname,current->deplist[dep]);
	  if ((xxx = index(lvarname,'+')) != NIL)
	    {
	      xxx++;
	      (void) strcpy(lvarname,xxx);
	    }
	  (void) strcpy(lvar,lvarname);
	  curi = 0;
	  while(strcmp(curvar[curi],""))
	    curi++;
	  if(curi == 32)
	    errexit(37,NIL);
	  if ((curvar[curi] = malloc((unsigned) (strlen(lvarname)+sizeof(char)))) == NIL)
	    errexit(10,"malloc");
	  variants_active = curi;
	  (void) strcpy(curvar[curi],lvarname);
	  (void) attrvar(lvar, NIL, (Af_set *) NIL);
	  dep++;
	}
    }
  else
    todo = TRUE;
  
  curdep = current->deplist[dep++];

  if(curdep != NIL)
    {
      if(!strcmp(curdep,"+"))
	curdep = current->deplist[dep++];
    }
  
  if (current->name[0] != '%')
    {
      if (curdep == NIL)
	todo = TRUE;

      while (curdep != NIL)
	{
	  t1 = exists_file(curdep,0);

	  if ((t1) && (strcmp(curdep,lastcurdep)))
	    {
	      (void) strcpy(lastcurdep,curdep);
	      (void) evtl_set_busy(curdep,TRUE);
	    }

	  test = make_target(curdep,sr,NIL);
	  if (error_happened)
	    {
	      err_happ = TRUE;
	      error_happened = FALSE;
	    }
	  depth--;
	  (void) strcat(longattrs[depth], longattrs[depth+1]);
	  (void) strcpy(longattrs[depth+1],"");

	  if (is_selrule_name(current->firstdep))
	    {
	      (void) strcpy(lselrule,current->firstdep);
	      (void) strcpy(cursr,lselrule);
	      (void) strcpy(sr,lselrule);
	    }
	  while(is_varname(current->deplist[dep]))
	    {
	      (void) strcpy(lvarname,current->deplist[dep]);
	      if ((xxx = index(lvarname,'+')) != NIL)
		{
		  xxx++;
		  (void) strcpy(lvarname,xxx);
		}
	      (void) strcpy(lvar,lvarname);
	      curi = 0;
	      while(strcmp(curvar[curi],""))
		curi++;
	      if(curi == 32)
		errexit(37,NIL);
	      if ((curvar[curi] = malloc((unsigned) (strlen(lvarname)+sizeof(char)))) == NIL)
		errexit(10,"malloc");
	      variants_active = curi;
	      (void) strcpy(curvar[curi],lvarname);
	      (void) attrvar(lvarname, NIL, (Af_set *) NIL);
	    }

	  if (test)
	    todo = TRUE;
	  t1 = exists_file(current->name,0);
	  (void) strcpy(path1,actpath);
	  (void) strcpy(actpath,"");
	  if (!t1)
	    todo = TRUE;
	  if (!todo)
	    {
	      (void) strcpy(lselrule,cursr);
	      (void) strcpy(cursr,"-STD-");
/*	      if (Sselect(current->name, path1, t1, current->deplist[0],curdep))
		todo = TRUE; */
	      todo = TRUE;
	      (void) is_selrule_name(lselrule);
	      (void) strcpy(cursr,lselrule);
	    }
	  curdep = current->deplist[dep++];

	}
      current->done = TRUE;
      
      if ((!todo) && (current->cmdlist == (struct cmds *) NIL))
	{
	  srcname = get_src_name(current->name);
	  if (srcname != NIL)
	    {
/*	      if (Sselect(current->name, path1, t1, current->deplist[0],srcname)) */
		todo = TRUE;
	      if (TRUE) /* (strcmp(sr,"-STD-")) */
		{
		  if (evtl_set_busy(srcname,TRUE))
		    {
		      todo = TRUE;
		      lbusy_done = busy_done;
		    }
		} 
	    }
	}
    }
  
  if(current->name[0] == '%')
    {
/*      if(strcmp(cursr,"-STD-"))
	{
	(void) strcpy(dep2,current_dep);
	  if((evtl_set_busy(dep2) != TRUE)) 
	    ;
	  else
	    errexit(17,current_dep);
	} */
      
      (void) strcpy(dep2, current_dep);
      point = rindex(dep2,'.');
      if(point != NIL)
	*point = '\0';
      (void) strcat(dep2,current->deplist[0]+1);
      
      t1 = exists_file(current_dep,0);
      if(t1)
	{
	  if(lbusy_done) /* ((strcmp(cursr,"-STD-")) && (lbusy_done)) */
	    {
	      if (exists_file(dep2,0))
		{
		  if (err_happ)
		    {
		      warning(2,current->name);
		      err_happ = FALSE;
		    }
		  else
		    test = execute_commands(current, current_dep, todo);
		}
	      busy_done = FALSE;
	    }
	  else
	    {
/*	      if (Sselect(current_dep, actpath, t1, NIL, dep2)) */
	      if (TRUE)
		{
		  if (exists_file(dep2,0))
		    {
		      if (err_happ)
			{
			  warning(2, current->name);
			  err_happ = FALSE;
			}
		      else
			test = execute_commands(current, current_dep, todo);
		    }
		}
	    }
	}
      else
	{
	  if (exists_file(dep2,0))
	    {
	      if (err_happ)
		{
		  warning(2, current->name);
		  err_happ = FALSE;
		}
	      else
		test = execute_commands(current, current_dep, todo);
	    }
	}
      (void) strcpy(current_dep,"");
    }
  
  if (todo)
    {
      if (err_happ)
	{
	  warning(2, current->name);
	  err_happ = FALSE;
	}
      else
	test = execute_commands(current, NIL, todo);
      /* if((!test) && (!noexflg) && (!exists_file(current->name,1)))
	errexit(3,current->name);
      
      if((!test) && (noexflg) && (current->cmdlist == (struct cmds *) NIL))
	errexit(3,current->name); */

      if(strcmp(lselrule,""))
	(void) strcpy(sr,lselrule);
      return(TRUE);
    }
  
  if (test || todo)
    {
      if(strcmp(lselrule,""))
	(void) strcpy(sr,lselrule);
      return(TRUE);
    }
  else
    {
      if(strcmp(lselrule,""))
	(void) strcpy(sr,lselrule);
      return(FALSE);
    }
}



Bool execute_commands(current, rel_dep, doit)
     struct rules *current;
     char *rel_dep;
     Bool doit;
{
  struct cmds *curcmd;
  char *expcmd;
  char *p;
  char *pp;
  char targrulename[MAXNAMLEN];
  char file[MAXNAMLEN];
  struct rules *cursuf;
  Bool exists = FALSE;
  Bool tx;
  int retcode;
  char *mist;
  char fname[MAXNAMLEN];
  int i;
  char attr[MAXATTRLENGTH];
  
  attr[0] = '\0';
  fname[0] = '\0';

  if (rel_dep != NIL)
    (void) strcpy(file, rel_dep);
  else
    (void) strcpy(file, current->name);

  if (current->name[0] == '%')
    {
      (void) strcpy(fname, rel_dep);
      if ((p = rindex(fname,'.')) != NIL)
	{
	  *p = '\0';
	  (void) strcat(fname,current->deplist[0]+1);
	}
    }

  if ((current != (struct rules *) NIL) && (current->cmdlist != (struct cmds *) NIL))
    {
      /* figure out if derived object already exists */
#ifndef NOBPOOL
      tx = exists_file(rel_dep,0);
      if (!tx)
	tx = exists_file(current->name,0);
      if (tx)
	{
	  if (rel_dep == NIL)
	    rel_dep = current->name;
	  (void) strcpy(attr,build_attrstring(current,rel_dep,(struct rules *) NIL));
	  retcode = compare_attrstring(attr, current, rel_dep, (struct rules *) NIL);
	  if ((retcode == 0)) /*  && (!doit)) */
	    {
/*	      if(Sselect(rel_dep,actpath,tx,current->deplist[0],fname)) */
	      return(TRUE); /* FALSE */
	    }
	  if ((retcode == 1) && (!doit))
	    {
	      return (TRUE);
	    }
	}
#endif NOBPOOL
      curcmd = current->cmdlist;
      while (curcmd != (struct cmds *) NIL)
	{
	  if (curcmd->command != NIL)
	    {
	      if ((mist = malloc(2048)) == NIL)
		errexit(10,"malloc");
	      (void) strcpy(mist,expandmacro(curcmd->command));
	      if ((expcmd = malloc(2048)) == NIL)
		errexit(10,"malloc");
	      (void) strcpy(expcmd,expand_command(mist, current, fname));
	      execute(expcmd);
	      free(expcmd);
	      free(mist);
	    }
	  else
	    break;
	  curcmd = curcmd->nextcmd;
	}
      if (current->cmdlist != (struct cmds *) NIL)
	{
	  cleanup_links(link_reg);
	  free_linklist();
	  link_reg = (struct linkreg *) NIL;
	}

      if (current->name[0] == '%')
	{
	  (void) strcpy(fname, rel_dep);
	  if ((p = rindex(fname,'.')) != NIL)
	    {
	      *p = '\0';
	      (void) strcat(fname,current->deplist[0]+1);
	    }
	  save_targets(current,fname,(struct rules *) NIL,attr);  /* rel_dep */
	}
      else
	{
	  if (exists_file(current->name,0))
	    save_targets(current,current->name, (struct rules *) NIL,attr);
	}
    } 
  else
    { /* execute stdrule or default commands */
      if ((pp = rindex(current->name,'.')) != NIL)
	{
	  (void) strcpy(fname, current->name);
	  pp = rindex(fname,'.');
	  *pp = '\0';   /* pp = suffix of target */
	  (void) strcpy(targrulename,"%.");
	  (void) strcat(targrulename,pp + 1);
	  for(i = 0; implicit_suffs[i] != -1; i++)
	    {
	      (void) strcpy(fname,current->name);
	      if ((pp = rindex(fname,'.')) != NIL)
		*pp = '\0';
	      /* build source name */
	      if (strcmp(targrulename, stdruletab[implicit_suffs[i]]->name) == 0)
		{
		  /* several dependents may be necessary ???? */
		  (void) strcat(fname,stdruletab[implicit_suffs[i]]->deplist[0]+1);
		  
		  /* source file exists ? */
		  if(exists_file(fname,0))
		    {
		      exists = TRUE;
		      cursuf = stdruletab[implicit_suffs[i]];
		      break;
		    }
		  else
		    cursuf = (struct rules *) NIL;
		}
	    }
	  if (exists)
	    {
	      /* but first figure out if derived object(s) already exist */
#ifndef NOBPOOL
	      tx = exists_file(current->name,0);
	      if (tx)
		{
		  (void) strcpy(attr,build_attrstring(cursuf,fname,current));
/*		  retcode = compare_attrstring(attr, cursuf, fname, current); */
		  retcode = compare_attrstring(attr, cursuf, current->name, current);
		  if((retcode == 0)) /* && (!doit)) */
		    {
		      /* if (Sselect(rel_dep,actpath,tx,current->deplist[0],fname)) */
			return (TRUE); /* FALSE */
		    }
		  if ((retcode == 1) && (!doit))
		    return(TRUE);
		}
#endif NOBPOOL

/*	      if (strcmp(cursr,"-STD-"))
	      (void) evtl_set_busy(fname,TRUE); */

	      (void) strcpy(attr,build_attrstring(cursuf,fname,current));
	      retcode = compare_attrstring(attr, cursuf, current->name, current);
	      if (retcode == 0)
		return(TRUE); /*FALSE */

	      curcmd = cursuf->cmdlist;
	      while(curcmd != (struct cmds *) NIL)
		{
		  if (curcmd->command != NIL)
		    {
		      if ((expcmd = malloc(2048)) == NIL)
			errexit(10,"malloc");
		      (void) strcpy(expcmd,expandmacro(curcmd->command));
		      (void) strcpy(expcmd,expand_command(expcmd, current, fname)); /* file */
		      execute(expcmd);
		      free(expcmd);
		    }
		  else
		    break;
		  curcmd = curcmd->nextcmd;
		}
	      if (cursuf->cmdlist != (struct cmds *) NIL)
		{
		  cleanup_links(link_reg);
		  free_linklist();
		  link_reg = (struct linkreg *) NIL;
		}
	      save_targets(cursuf,fname,current,attr);

	      /* put derived objects into bpool */
	      /* and save special attributes */

	    }
	}
    }
  if (cursuf != (struct rules *) NIL)
    return(TRUE);
  else
    return (FALSE);
}

  

int execute(cmd)
     char *cmd;
{
  int retcode = 0;
  Bool ignflg = FALSE;
  char *rc;
  Bool silflg;

  cmd = repl_string(cmd);
  
  silflg = silentflg;

  while((cmd[0] == '\t') || (cmd[0] == ' ') || (cmd[0] == '\n'))
    *cmd++;

  if (noexflg)
    {
      printf("%s\n", cmd);
      (void) fflush(stdout);
      reallydone = TRUE;
    }
  else
    {
      if (cmd[0] == '@')
	{
	  cmd[0] = ' ';
	  silflg = TRUE;
	  if (cmd[1] == '-')
	    {
	      cmd[1] = ' ';
	      ignflg = TRUE;
	    }
	}
      if (!silflg)
	{
	  printf("shape - executing: %s\n", cmd);
	  (void) fflush(stdout);
	}
      if (!touchflg)
	{
	  reallydone = TRUE;
	  retcode = system(cmd);
/*	  cleanup_links(link_reg);
	  free_linklist();
	  link_reg = (struct linkreg *) NIL; */
	  if (retcode != 0)
	    {
	      error_happened = TRUE;
	      error_occ = TRUE;
	      if ((rc = malloc(10 * sizeof(char))) == NIL)
		errexit(10,"malloc");
	      (void) sprintf(rc, "%d", retcode); 
	      if ((ignflg == FALSE) && (goflg == FALSE))
		errexit(13,rc);
	      if (goflg == FALSE)
		errexit(13,rc);
	    }
	}
    }
  free(cmd);
}


char *get_src_name(name)
     char *name;
{
  int i;
  char fname[MAXNAMLEN];
  char *p;
  (void) strcpy(fname,name);
  if ((p = rindex(fname,'.')) != NIL)
    {
      for (i = 0; implicit_suffs[i] != -1; i++)
	{
	  *p = '\0';
	  if (!strcmp(stdruletab[implicit_suffs[i]]->name+2,p+1))
	    {
	      (void) strcat(fname,stdruletab[implicit_suffs[i]]->deplist[0]+1);
	      if (exists_file(fname,0))
		return(fname);
	    }
	}
      if(implicit_suffs[i] == -1)
	return(NIL);
    }
  /*NOTREACHED*/
  return(NIL);
}
       

set_pathi()
{
  int i = 0;
  while(curvpath[i] != NIL)
    i++;
  pathi = i;
}
