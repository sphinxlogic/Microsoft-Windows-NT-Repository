/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *RCSid = "$Header: misc.c,v 3.5 89/02/21 17:11:54 wolfgang Exp $";
#endif
#ifndef lint
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	misc.c,v $
 * Revision 3.5  89/02/21  17:11:54  wolfgang
 * append_mtime changed
 * 
 * Revision 3.4  89/02/20  16:26:08  wolfgang
 * NET-RELEASE
 * 
 * Revision 3.3  89/02/08  16:19:55  wolfgang
 * one comment added for lint.
 * ..
 * 
 * Revision 3.2  89/02/08  12:46:32  wolfgang
 * performance improved.
 * 
 * Revision 3.1  89/02/06  14:26:41  wolfgang
 * bug fixed.
 * 
 * Revision 3.0  89/01/24  11:36:12  wolfgang
 * New System Generation
 * 
 * Revision 2.19  89/01/23  16:14:42  wolfgang
 * inheritance of uda's is now suppressed
 * 
 * Revision 2.18  89/01/03  13:12:23  wolfgang
 * changes done for lint
 * 
 * Revision 2.17  88/12/22  12:36:39  wolfgang
 * dummy procedure free_linklist()m added.
 * 
 * Revision 2.16  88/12/21  15:11:10  wolfgang
 * changes done for lint
 * 
 * Revision 2.15  88/12/19  13:21:27  wolfgang
 * is_in_forcelist added().
 * 
 * Revision 2.14  88/11/23  12:35:48  wolfgang
 * Another dorpkey added.
 * 
 * Revision 2.13  88/11/21  20:55:10  wolfgang
 * changes done for sun
 * 
 * Revision 2.12  88/11/09  16:25:59  wolfgang
 * bugs fixed
 * 
 * Revision 2.11  88/11/08  11:05:02  wolfgang
 * This version is part of a release
 * 
 * Revision 2.10  88/11/03  17:29:46  wolfgang
 * calls of af_dropset added in compare_attrstring().
 * 
 * Revision 2.9  88/10/10  16:54:43  wolfgang
 * changed for the -t option. if (touchflg) nothing is restored.
 * 
 * Revision 2.8  88/09/23  15:54:20  wolfgang
 * bug fixed in get_attr_type (retrn values).
 * 
 * Revision 2.7  88/09/22  16:15:06  wolfgang
 * clleanup_links() changed (now recursive).
 * 
 * Revision 2.6  88/09/07  11:23:30  wolfgang
 * unlinking of tmp file added to cleanup_links().
 * 
 * Revision 2.5  88/08/25  16:09:07  wolfgang
 * Message: ... restored from bpool changed; [busy] is supreesed and if
 * type = "" the "." is supressed.
 * 
 * Revision 2.4  88/08/22  15:30:43  wolfgang
 * Two types added: syspath & host; are necessary for confid.
 * 
 * Revision 2.3  88/08/22  11:24:06  wolfgang
 * Attribute string changed: added "." between name & type.
 * 
 * Revision 2.2  88/08/19  10:05:59  wolfgang
 * bug fixed; if attrs were too long for bpool file, the identification
 * of the busy version had not been correct.
 * Furthermore the format of the string "... version restored ..." has
 * been changed, so that -2 .-2 for busy Version is supressed.
 * 
 * Revision 2.1  88/08/18  13:19:41  wolfgang
 * minor bug fixes; mtime added to identification string of derived objects
 * 
 */

#include <sys/types.h>
#include <sys/dir.h>
#include "shape.h"

extern char *forcelist[];
extern Bool is_in_forcelist();
extern char *template;
extern int af_cleanup();

/* Struct for registering links */
struct linkreg *link_reg = (struct linkreg *) NIL;
struct linkreg *last_link;

char *longattrs[MAXDEPTH];

char *types[] = { "generation",          /*  0  int */
		  "revision",            /*  1  int */
		  "state",               /*  2  short */
		  "author",              /*  3  short */
		  "group",               /*  4  short */
		  "version",             /*  5  char * */
		  "variant",             /*  6  char * */
		  "syspath",             /*  7  char * */
		  "host",                /*  8  char * */
		  "0"};                  /* 99  default = char *
					    (for userdefined attributes */


char *states[] = { "busy",
		   "saved",
		   "proposed",
		   "published",
		   "accessed",
		   "frozen",
		   "0"};
  

int get_attr_type(name)
     char *name;
{
  int i = 0;

  if (name == NIL)
    return(99);

  while(strcmp(types[i],"0") != 0)
    {
      if((strcmp(types[i],name) == 0))
	return(i);
      i++;
    }
  return(99);
}

int get_state_no(state)
     char *state;
{
  int i = 0;
  while(strcmp(states[i],"0") != 0)
    {
      if((strcmp(states[i],state) == 0))
	return(i);
      i++;
    }
  return(99);
}


struct linkreg *init_linkreg()
{
  struct linkreg *lreg = (struct linkreg *) NIL;

  if ((lreg = (struct linkreg *) malloc(sizeof(struct linkreg))) ==
      (struct linkreg *) NIL)
    errexit(10,"malloc");
  if((lreg->fn = malloc(MAXNAMLEN)) == NIL)
    errexit(10,"malloc");
  if((lreg->newfn = malloc(MAXNAMLEN)) == NIL)
    errexit(10,"malloc");
  lreg->fn[0] = '\0';
  lreg->newfn[0] = '\0';
  lreg->next = (struct linkreg *) NIL;

  return(lreg);
}


register_link(fn, newfn, busy_exist)
     char *fn;
     char *newfn;
     Bool busy_exist;
{
  if (link_reg == (struct linkreg *) NIL)
    {
      link_reg = init_linkreg();
      (void) strcpy(link_reg->fn, fn);
      (void) strcpy(link_reg->newfn, newfn);
      link_reg->busy_exist = busy_exist;
      last_link = link_reg;
    }
  else
    {
      last_link->next = init_linkreg();
      last_link = last_link->next;
      (void) strcpy(last_link->fn, fn);
      (void) strcpy(last_link->newfn, newfn);
      last_link->busy_exist = busy_exist;
    }
}

cleanup_links(cur_link)
     struct linkreg *cur_link;
{
  char filename[MAXNAMLEN];
  char afsname[MAXNAMLEN];
  if(cur_link != (struct linkreg *) NIL)
    {
      cleanup_links(cur_link->next);
    }
  if(cur_link != (struct linkreg *) NIL)
    {
      if(rindex(cur_link->fn,'/') == 0)
	{
	  (void) strcpy(filename, "./");
	  (void) strcat(filename, cur_link->fn);
	  (void) strcpy(afsname, "./");
	  (void) strcat(afsname, cur_link->newfn);
	}
      else
	{
	  (void) strcpy(filename, cur_link->fn);
	  (void) strcpy(afsname, cur_link->newfn);
	}
      if (unlink(filename) != 0)
	{
	  fprintf(stderr, "shape - Aaaaaaaaaaaaaaaaargh !!!!!\n");
	  fprintf(stderr, "error while cleaning up links :\n");
	  fprintf(stderr, "can't unlink %s\n", filename);
	  fprintf(stderr, "contact guru immediately !\n");
	  af_cleanup();
	  exit(1);
	}
      if (cur_link->busy_exist)
	{
	  if (link(afsname,filename) != 0)
	    {
	      fprintf(stderr, "shape - Aaaaaaaaaaaaaaaaargh !!!!!\n");
	      fprintf(stderr, "error while cleaning up links :\n");
	      fprintf(stderr, "can't link %s to %s\n", filename, afsname);
	      fprintf(stderr, "contact guru immediately !\n");
	      af_cleanup();
	      exit(1);
	    }
	  if (unlink(afsname) != 0)
	    {
	      fprintf(stderr, "shape - Aaaaaaaaaaaaaaaaargh !!!!!\n");
	      fprintf(stderr, "error while cleaning up links :\n");
	      fprintf(stderr, "can't unlink %s\n", filename);
	      fprintf(stderr, "contact guru immediately !\n");
	      af_cleanup();
	      exit(1);
	    }
	}
    }
}

int free_linklist()
{
/* not yet implemented */
/* should free memory of linklist */
  ;
}
  
Bool compare_attrstring(attr, rulename, name, objrulename)
     /*ARGSUSED*/
     char *attr;
     struct rules *rulename;
     char *name;
     struct rules *objrulename;
{
  Af_set aset;
  Af_set bset;
  Af_attrs buf;
  Af_attrs buf1;
  Af_attrs buf2;
  Af_key akey;
  Af_key bkey;
  Af_key key1;
  Af_key key2;
  Af_key restorekey;

  int retcode;
  int retcode1;
  char bname[MAXNAMLEN];
  char *type;
  char *p;
  char *d;
  char sysp[MAXNAMLEN];

  if (touchflg)
    return(0);
  
  sysp[0] = '\0';

  (void) strcpy(bname,name);
  if ((p = rindex(bname,'.')) == 0)
    {
      type = NIL;
    }
  else
    {
      p[0] = '\0';
      *p++;
      type = p;
    }

  if ((d = rindex(bname,'/')) != 0)
    {
      (void) strcpy(sysp, bname);
      d = rindex(sysp, '/');
      d[0] = '\0';
      *d++;
      (void) strcpy(bname,d);
    }
  af_initattrs(&buf);
  
  buf.af_gen = AF_BUSYVERS;
  buf.af_rev = AF_BUSYVERS;

  if(sysp[0] != '\0')
    (void) strcpy(buf.af_syspath,sysp);
  else
    (void) strcpy(buf.af_syspath,curvpath[0]);

  (void) strcpy(buf.af_name,bname);
  if (p != NIL)
    (void) strcpy(buf.af_type,p);
  else
    (void) strcpy(buf.af_type,"");

  if (forceflg)
    {
      if (is_in_forcelist(name,type))
	return(3);
    }

  if ((retcode1 = af_find(&buf, &aset)) == -1)
    errexit(10,"af_find");

  buf.af_gen = AF_NOVNUM;
  buf.af_rev = AF_NOVNUM;

  buf.af_udattrs[0] = attr;
  buf.af_udattrs[1] = NIL;

  if ((retcode = af_bpfind(&buf,&bset)) == -1) 
    errexit(10,"af_bpfind");

  if ((retcode1 == 1) && (retcode == 0))
    /* derived object is not in binary pool (attr had been too long */
    {
      if((retcode = af_find(&buf, &bset)) == -1)
	{
	  errexit(10,"af_find");
	}
      else
	{
	  if (af_dropset(&bset) == -1)
	    errexit(10,"af_dropset");
	  if (af_dropset(&aset) == -1)
	    errexit(10,"af_dropset");
	  
	  if (retcode == 1)
	    /* busy version owns the correct attribute */
	    return (0);
	  else
	    return(3);
	}
    }
  
  if ((retcode1 == 1) && (retcode == 1))
    {
      if(af_setgkey(&aset,0,&key1) == -1)
	errexit(10,"af_setgkey");
      if(af_setgkey(&bset,0,&key2) == -1)
	errexit(10,"af_setgkey");
      if(af_gattrs(&key1,&buf1) == -1)
	 errexit(10,"af_gattrs");
      if(af_gattrs(&key2,&buf2) == -1)
	 errexit(10,"af_gattrs");
      if(buf1.af_mtime == buf2.af_mtime)
	{
	  if (af_dropset(&bset) == -1)
	    errexit(10,"af_dropset");
	  if (af_dropset(&aset) == -1)
	    errexit(10,"af_dropset");
	  return (0);
	}
    }
  if (retcode == 0)
    {
      if (af_dropset(&bset) == -1)
	errexit(10,"af_dropset");
      if (af_dropset(&aset) == -1)
	  errexit(10,"af_dropset");
      return (3);
    }
  else
    {
      if (af_setgkey(&bset,0,&bkey) == -1)
	errexit(10,"af_setgkey");
      if (retcode1 == 1)
	{
	  if (af_setgkey(&aset,0,&akey) == -1)
	    errexit(10,"af_setgkey");
	  if (af_dropkey(&akey) == -1)
	    errexit(10,"af_dropkey");
	} 
      if (af_restore(&bkey,&restorekey) == -1)
	errexit(10,"af_restore");

      if (af_sudattr(&restorekey,AF_REPLACE,attr) == -1)
	errexit(10,"af_sudattr");

      if (af_gattrs(&bkey,&buf) == -1)
	errexit(10,"af_gattrs");

      if (af_dropkey(&bkey) == -1)
	errexit(10,"af_dropkey");

      if (buf.af_gen != AF_BUSYVERS)
	{
	  printf ("... %s.%s[%d.%d] restored from bpool\n",
		  buf.af_name, buf.af_type, buf.af_gen, buf.af_rev);
	}
      else
	{
	  if (strcmp(buf.af_type,""))
	    printf ("... %s.%s restored from bpool\n",
		    buf.af_name, buf.af_type);
	  else
	    printf ("... %s restored from bpool\n",
		    buf.af_name);
	}
      if (af_dropset(&bset) == -1)
	errexit(10,"af_dropset");
      if (af_dropset(&aset) == -1)
	errexit(10,"af_dropset");
      return(0);
    }
}


int append_attrs(buf,recdepth)
     Af_attrs *buf;
     int recdepth;
{
  char attributes[MAX_ATTR];

  (void) sprintf(attributes,"%s%s%s%s%s%d%d%d%d",
	  buf->af_name,
	  ".",
	  buf->af_type,
	  buf->af_host,
	  buf->af_syspath,
	  buf->af_gen,
	  buf->af_rev,
	  buf->af_state,
	  buf->af_mtime /* ,
	  buf->af_owner.af_username,
	  buf->af_owner.af_userhost,
	  buf->af_author.af_username,
	  buf->af_author.af_userhost,
	  buf->af_locker.af_username,
	  buf->af_locker.af_userhost,
 	  buf->af_size,
	  buf->af_mode,
	  buf->af_atime,
	  buf->af_ctime,
 	  buf->af_stime,
	  buf->af_ltime */
	  );

/*  i = 0;
  while(buf->af_udattrs[i] != NIL)
    {
      if ((strlen(attributes) + strlen(buf->af_udattrs[i])) >= MAX_ATTR)
	errexit(29,NIL);
      (void) strcat(attributes,buf->af_udattrs[i]);
      i++;
    }
*/
  if ((strlen(attributes) + strlen(longattrs[recdepth])) >= MAX_ATTR)
    errexit(29,NIL);

  (void) strcat(longattrs[recdepth],attributes);

#ifdef DEBUG_MISC
printf("depth=%d;longattr=%s\n", recdepth, longattrs[recdepth]);
#endif DEBUG_MISC

}

append_mtime(testbuf,recdepth)
     Af_attrs *testbuf;
     /*ARGSUSED*/
     int recdepth;
{
  char time[64];
  /* (void) sprintf(time,"%d",testbuf->af_mtime);
  (void) strcat(longattrs[recdepth],time); */
}


Bool is_in_forcelist(name,type)
     char *name;
     char *type;
{
  char fullname[MAXNAMLEN];
  int i = 0;
  fullname[0] = '\0';
  (void) strcpy(fullname,name);
  if (strcmp(type,""))
    {
      (void) strcat(fullname,".");
      (void) strcat(fullname,type);
    }

  while(forcelist[i] != NIL)
    {
      if (!strcmp(forcelist[i],fullname))
	return(TRUE);
      i++;
    }
  return(FALSE);
}

  
