/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *RCSid = "$Header: vpath.c,v 3.2 89/02/20 16:26:55 wolfgang Exp $";
#endif
#ifndef lint
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	vpath.c,v $
 * Revision 3.2  89/02/20  16:26:55  wolfgang
 * NET-RELEASE
 * 
 * Revision 3.1  89/02/08  12:44:58  wolfgang
 * performance improved.
 * 
 * Revision 3.0  89/01/24  11:37:26  wolfgang
 * New System Generation
 * 
 * Revision 2.6  89/01/03  13:14:30  wolfgang
 * changes done for lint
 * 
 * Revision 2.5  88/12/21  15:13:37  wolfgang
 * changes done for lint
 * 
 * Revision 2.4  88/11/21  20:54:15  wolfgang
 * changes done for sun
 * 
 * Revision 2.3  88/11/21  15:49:32  wolfgang
 * return code of all malloc's checked
 * 
 * Revision 2.2  88/11/18  15:03:21  wolfgang
 * is_vpath_dir added.
 * 
 * Revision 2.1  88/08/19  10:18:19  wolfgang
 * This version is part of a release
 * 
 */

#include "shape.h"

insertvpath(string)
     char *string;
{
  char *p;
  int i;
  for(i = 1; (p = index(string,':')) != NIL; i++)
    {
      *p = '\0';
      if(*string != '/')
	{
	  if ((curvpath[i] = malloc((unsigned) (strlen(string) + strlen(curvpath[0])
			     + 3 * sizeof(char)))) == NIL)
	    errexit(10,"malloc");
	  (void) strcpy(curvpath[i],curvpath[0]);
	  (void) strcat(curvpath[i],"/");
	  if ((*string == '.') && (*string+1 == '/'))
	    {
	      string++;
	      string++;
	    }
	  else
	    {
	      if ((*string == '.') && (*string+1 == '.') && (*string+2 == '/'))
		{
		  *string++;
		  *string++;
		  *string++;
		}
	    }
	  (void) strcat(curvpath[i],string);
	}
      else
	{
	  if ((curvpath[i] = malloc((unsigned) (strlen(string) + sizeof(char)))) == NIL)
	    errexit(10,"malloc");
	  (void) strcpy(curvpath[i],string);
	  p++;
	  string = p;
	}
    }
  if((p == NIL) && (string != NIL))
    {
      if(*string != '/')
	{
	  if((curvpath[i] = malloc((unsigned) (strlen(string) + strlen(curvpath[0])
			     + 2 * sizeof(char)))) == NIL)
	    errexit(10,"malloc");
	  (void) strcpy(curvpath[i],curvpath[0]);
	  (void) strcat(curvpath[i],"/");
	  if ((*string == '.') && (*string+1 == '/'))
	    {
	      string++;
	      string++;
	    }
	  else
	    {
	      if ((*string == '.') && (*string+1 == '.') && (*string+2 == '/'))
		{
		  *string++;
		  *string++;
		  *string++;
		}
	    }
	  (void) strcat(curvpath[i],string);
	}
      else
	{
	  if((curvpath[i] = malloc((unsigned) (strlen(string) + sizeof(char)))) == NIL)
	    errexit(10,"malloc");
	  (void) strcpy(curvpath[i],string);
	}
    }
}

