/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *RCSid = "$Header: rule.c,v 3.0 89/01/24 11:36:35 wolfgang Stable $";
#endif
#ifndef lint
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	rule.c,v $
 * Revision 3.0  89/01/24  11:36:35  wolfgang
 * New System Generation
 * 
 * Revision 2.16  89/01/19  12:38:05  wolfgang
 * check for .IGNORE added
 * 
 * Revision 2.15  89/01/03  13:13:00  wolfgang
 * changes done for lint
 * 
 * Revision 2.14  88/12/21  15:11:59  wolfgang
 * changes done for lint
 * 
 * Revision 2.13  88/12/19  13:24:06  wolfgang
 * things for special targets .BPOOL & .NOBPOOL added.
 * 
 * Revision 2.12  88/12/12  13:16:40  wolfgang
 * bug fixed (something for sun).
 * 
 * Revision 2.11  88/11/22  17:17:14  wolfgang
 * changes done for sun & bugs fixed.
 * 
 * Revision 2.10  88/11/21  15:48:55  wolfgang
 * return code of all malloc's checked
 * 
 * Revision 2.9  88/11/08  11:05:13  wolfgang
 * This version is part of a release
 * 
 * Revision 2.8  88/09/16  12:59:29  wolfgang
 * overload_stdrules() added.
 * 
 * Revision 2.7  88/09/14  10:52:06  wolfgang
 * undone last changes
 * 
 * Revision 2.6  88/09/13  14:41:03  wolfgang
 * Because of bad performance: get_src_name deleted.
 * 
 * Revision 2.5  88/09/09  11:57:33  wolfgang
 * Performance improved. get_src_name has been called to often.
 * 
 * Revision 2.4  88/08/31  12:03:20  wolfgang
 * Standard dependent added to depency list.
 * 
 * Revision 2.3  88/08/23  15:37:13  wolfgang
 * ruledump() has been changed. In dependncy lines the first dependent
 * is supressed if it is a name of a selection rule and we are generating
 * a confid.
 * 
 * Revision 2.2  88/08/23  10:25:36  wolfgang
 * Changed ruledump; now it can be used both to generate confid's
 * and for the -d option.
 * 
 * Revision 2.1  88/08/19  10:17:50  wolfgang
 * This version is part of a release
 * 
 */

/* allow a:b   ?????? geht noch nicht ....
         a:c
	 a:d  etc. if only one action is defined !!!!! */

/* :: still not yet implememnted */
/* intermixing of implicit "." rules and normal targets is *not* allowed */

#include "shape.h"
#include "rule.h"

extern int hashval();
extern int errexit();
extern char *expandmacro();
extern char *get_src_name();
extern struct rules *stdruletab[];
extern int implicit_suffs[];
extern Bool is_old_rule();
struct rules *ruletab[RULETABSIZE];
char *firsttarget;
Bool oldrule;

int depnr;
int targnr;
int cmdnr;
int heritnr;
char *targfield[MAXTARGS];
char *depfield[MAXDEPS];
char *cmdfield[MAXCMDS];
char *heritfield[MAXHERIT];


ruledef(string)
     char *string;
{
int i = 0;
int k = 0;
char klazu;
char *t;

targnr = 0;
depnr = 0;
cmdnr = 0;
heritnr = 0;

if ((t = malloc( (unsigned) strlen(string) + 1)) == NIL)
  errexit(10,"malloc");

string = expandmacro(string);

while(string[i] != ':')
  {
    while((string[i] != ' ') && (string[i] != '\t') && (string[i] != ':'))
      {
	t[k] = string[i];
	i++;
	k++;
      }
    t[k] = '\0';
    targnr++;
    if (targnr > MAXTARGS)
      errexit(27, "targets");
    if ((targfield[targnr] = malloc((unsigned) strlen(t) + 1)) == NIL)
      errexit(10,"malloc");
    (void) strcpy(targfield[targnr], t);
#ifdef DEBUG_RULE
printf("target no. %d = #%s#\n", targnr, targfield[targnr]);
#endif DEBUG_RULE
    k = 0;
    while((string[i] == ' ') || (string[i] == '\t'))
      i++;
  }
if (string[i+1] == ':')
  {
    doublecolon = TRUE;
    i = i + 2;
  }
else
  i++;

while((string[i] != '\0') && (string[i] != ';') && (string[i] != ':'))
  {
    while((string[i] == ' ') || (string[i] == '\t') ||
	  (string[i] == '\\'))
      {
	if ((string[i] == '\\') && (string[i+1] == '\n'))
	  i = i+2;
	else
	  i++;
      }
    while((string[i] != ' ') && (string[i] != '\t') &&
	  (string[i] != ';') && (string[i] != '\0') &&
	  (string[i] != ':') && (string[i] != '\\'))
      {
	t[k] = string[i];
	i++;
	k++;
      }
    t[k] = '\0';
    if (k != 0)
      {
	depnr++;
	if (depnr > MAXDEPS)
	  errexit(27, "dependents");
	if ((depfield[depnr] = malloc((unsigned) strlen(t) + 1)) == NIL)
	  errexit(10,"malloc");
	(void) strcpy(depfield[depnr],t);
#ifdef DEBUG_RULE
printf("dependent no. %d=#%s#\n", depnr , depfield[depnr]);
#endif DEBUG_RULE
      }
    k = 0;
  }


while((string[i] == ' ') || (string[i] == '\t'))
  i++;

/* heritage */

k = 0;
if (string[i] == ':')
  {
    i++;
    while( (string[i] != '\0') )
      {
	while((string[i] == ' ') || (string[i] == '\t'))
	  i++;
	if (string[i] != '+')
	  errexit(26, &string[i]);
	if (string[i+1] == '(')
	  klazu = ')';
	else
	  {
	    if (string[i+1] == '{')
	      klazu = '}';
	    else
	      klazu = ' ';
	  }

	while (string[i] != klazu)
	  {
	    t[k] = string[i];
	    i++;
	    k++;
	    if (string[i] == '\0')
	      errexit(26,&string[i]);
	  }
	t[k] = string[i];
	k++;
	i++;
	t[k] = '\0';
	heritnr++;
	if (heritnr > MAXHERIT)
	  errexit(27, "iherits");
	if ((heritfield[heritnr] = malloc((unsigned) strlen(t) + 1)) == NIL)
	  errexit(10,"malloc");
	(void) strcpy(heritfield[heritnr],t);
	k = 0;
      }
  }

/* commands on ruledef line */
if( string[i] == ';')
  {
    i++;
    while( (string[i] != '\0'))
      {
	t[k] = string[i];
	i++;
	k++;
      }
    t[k] = '\0';
    cmdnr++;
    if (cmdnr > MAXCMDS)
      errexit(27, "commands");
    if ((cmdfield[cmdnr] = malloc((unsigned) strlen(t) + 1)) == NIL)
      errexit(10,"malloc");
    if (t[strlen(t)-1] == '\n')
      t[strlen(t)-1] = '\0';
    (void) strcpy(cmdfield[cmdnr], t);
#ifdef DEBUG_RULE
printf("command[%d] = #%s#\n", cmdnr, cmdfield[cmdnr]);
#endif DEBUG_RULE
  }
}

rulecont(string)
     char *string;
{
/* only commands have been found */
cmdnr++;
if(cmdnr > MAXCMDS)
  errexit(27, "commands");
if ((cmdfield[cmdnr] = malloc ((unsigned) strlen(string) + 1)) == NIL)
  errexit(10,"malloc");
if (string[strlen(string)-1] == '\n')
  string[strlen(string)-1] = '\0';
(void) strcpy(cmdfield[cmdnr], string);
#ifdef DEBUG_RULE
printf("command[%d] = #%s#\n", cmdnr, cmdfield[cmdnr]);
#endif DEBUG_RULE
}

ruleend()
{
  struct rules *current;
  struct cmds *curcmd;
  int i = 0;
  int j = 0;
  int jjj = 0;
  int kkk = 0;
  int xx = 0;
  int ss = 0;
  int minus = 0;
  Bool src_found = FALSE;
  int hasht = 0;
  char *p;
  char *srcname;
  Bool std_rule = FALSE;
  Bool found = FALSE;
  int targs = 0;
  
  if(targnr == 0)
    return;

  if(!strcmp(targfield[1],".BPOOL"))
    bpoolflg = TRUE;

  if(!strcmp(targfield[1],".NOBPOOL"))
    nobpoolflg = TRUE;

  if(!strcmp(targfield[1],".IGNORE"))
    ignoreflg = TRUE;
  
  if ((is_old_rule(targfield[1])) && (strcmp(targfield[1],".SUFFIXES") != 0))
    {
      oldrule = TRUE;
      targs = targnr;
      for(i = 1; i <= targs; i++)
	{
	  if (is_old_rule(targfield[i]))
	    {
	      if (targfield[i] != NIL)
		convertrule(i);
	    }
	      ruleend();
	}
      oldrule = FALSE;
      return;
    }

  for(i = 1; i <= targnr; i++)
    {
      p = index(targfield[i],'%');
      if ((p != NIL) && ((*(p+1) == '\0') || (*(p+1) == '.')))
	{
	  std_rule = TRUE;
	  break;
	}
    }

  for(i = 1; i <= targnr; i++)
    {
      found = FALSE;
      if(!std_rule)
	{
	  hasht = hashval(targfield[i]);
#ifdef DEBUG_RULE
printf("targfield[i] = %s; i = %d\n", targfield[i], i);
#endif DEBUG_RULE
	  if ( ruletab[hasht] == (struct rules *) NIL)
	    {
	      if((current = ruletab[hasht] = (struct rules *) malloc( sizeof(struct rules))) == (struct rules *)NIL)
		errexit(10,"malloc");
	    }
	  else
	  {
	    current = ruletab[hasht];
	    if ((!strcmp(ruletab[hasht]->name, targfield[i])) &&
		(strcmp(ruletab[hasht]->name, ".SUFFIXES")) &&
		(current->doublecolon == FALSE) &&
		(doublecolon == FALSE) &&
		(ruletab[hasht]->cmdlist != (struct cmds *) NIL) &&
		(cmdfield[0] != NIL))
	      errexit(1, targfield[i]);

	    if((!strcmp(current->name,targfield[i])) &&
	       ((cmdfield[0] == NIL) ||
		(current->cmdlist == (struct cmds *) NIL)))
	      {
		found = TRUE;
	      }

	    while((current->nextrule != (struct rules *) NIL) && (!found))
	      {
		if((strcmp(current->name,targfield[i]) == 0) &&
		   ((cmdfield[0] == NIL) ||
		    (current->cmdlist == (struct cmds *) NIL)))
		  {
		    found = TRUE;
		    break;
		  }
		else
		  current = current->nextrule;
		if ((strcmp(current->name, targfield[i]) == 0) &&
		    (strcmp(ruletab[hasht]->name, ".SUFFIXES") != 0) &&
		    (ruletab[hasht]->cmdlist != (struct cmds *) NIL) &&
		    (current->doublecolon == FALSE) &&
		    (doublecolon == FALSE) &&
		    (cmdfield[0] != NIL))
		  errexit(1, targfield[i]);
		if ((strcmp(current->name, ".SUFFIXES")) == 0)
		  {
		    if (depnr == 0) /* delete suffix list */
		      {
			current->deplist[0] = NIL;
		      }
		    else
		      {
			while (current->deplist[jjj] != NIL)
			  jjj++;
		        for (kkk = 1; kkk <= depnr; kkk++)
			  {
			    if ((current->deplist[jjj + kkk - 1] =
				 malloc((unsigned) (strlen(depfield[kkk]) + 1))) == NIL)
			      errexit(10,"malloc");
			    (void) strcpy(current->deplist[jjj + kkk - 1], depfield[kkk]);
			  }
		      }
		  }
	      }
	    if (!found)
	      {
		if((current = current->nextrule = (struct rules *) malloc( sizeof(struct rules))) == (struct rules *)NIL)
		  errexit(10,"malloc");
	      }
	  }
	}
      else
	{
	  if((current = stdruletab[lastrule] = (struct rules *) malloc( sizeof(struct rules))) == (struct rules *) NIL)
	    errexit(10,"malloc");
	  overload_stdrule();
	  implicit_suffs[lastrule] = lastrule;
	  lastrule++;
	  implicit_suffs[lastrule] = -1;
	  stdruletab[lastrule] = (struct rules *) NIL;
	}
      if (!found)
	{
	  if((current->name = malloc( (unsigned) strlen( targfield[i] ) + 1)) == NIL)
	    errexit(10,"malloc");
	  (void) strcpy(current->name, targfield[i]);
	}
      current->done = FALSE;
      if (doublecolon)
	current->doublecolon = TRUE;
      else
	current->doublecolon = FALSE;
      if((i == 1) && (firsttarget == NIL) && (current->name[0] != '%') &&
	 (current->name[0] != '.'))
	 firsttarget = current->name;
      if(!found)
	{
	  current->deplist[0] = NIL;
	  current->cmdlist = (struct cmds *) NIL;
	  current->nextrule = (struct rules *) NIL;
	}
      if ((depnr > 0) && (!found))
	{
	  if ((current->firstdep = malloc((unsigned) (strlen(depfield[1]) + sizeof(char)))) == NIL)
	    errexit(10,"malloc");
	  (void) strcpy(current->firstdep, depfield[1]);
	}
      
      if (found)
	{
	  for(xx = 0; current->deplist[xx] != NIL; xx++)
	    ;
	}	  
      minus = 0;
      for(j = xx+1; j <= xx+depnr; j++)
	{
	  for(ss = 0; current->deplist[ss] != NIL; ss++)
	    {
	      if (!strcmp(current->deplist[ss],depfield[j-xx]))
		{
		  src_found = TRUE;
		  minus = 1;
		  break;
		}
	    }
	  if(!src_found)
	    {
	      if ((current->deplist[j-1-minus] =
		   malloc((unsigned) (strlen(depfield[j-xx]) + sizeof(char)))) == NIL)
		errexit(10,"malloc");
	      (void) strcpy(current->deplist[j-1-minus], depfield[j-xx]);
	    }
	}
      current->deplist[j-1] = NIL;
      src_found = FALSE;
	
      /* get standard dependent */

      if(current->name[0] != '%')
	{
	  if((srcname = get_src_name(current->name)) != NIL)
	    {
	      for(ss = 0; ss <= j-2; ss++)
		{
		  if(!strcmp(srcname,current->deplist[ss]))
		    {
		      src_found = TRUE;
		      break;
		    }
		}
	      if (!src_found)
		{
		  if((current->deplist[j-1] =
		      malloc((unsigned) (strlen(srcname) + 1))) == NIL)
		    errexit(10,"malloc");
		  (void) strcpy(current->deplist[j-1],srcname);
		  current->deplist[j] = NIL;
		}
	      src_found = FALSE;
	    }
	}

      if (heritnr > 0)
	{
	  for (j = 1; j <= heritnr; j++)
	    {
	      if((current->heritage[j-1] =
		  malloc((unsigned) (strlen(heritfield[j]) + sizeof(char)))) == NIL)
		errexit(10,"malloc");
	      (void) strcpy(current->heritage[j-1], heritfield[j]);
	    }
	  current->heritage[j-1] = NIL;
	}
      else
	current->heritage[0] = NIL;

      if(std_rule)
	{
	  for (j = 1; j <= targnr; j++)
	    {
	      if((current->targetlist[j-1] =
		  malloc((unsigned) (strlen(targfield[j]) + 1))) == NIL)
		errexit(10,"malloc");
	      (void) strcpy(current->targetlist[j-1],targfield[j]);
	    }
	  current->targetlist[j-1] = NIL;
	}
      if (cmdnr > 0)
	{
	  if ((curcmd = current->cmdlist = (struct cmds *) malloc( sizeof( struct cmds))) == (struct cmds *) NIL)
	    errexit(10,"malloc");
	  for (j = 1; j <= cmdnr; j++)
	    {
	      if((curcmd->command = malloc( (unsigned) strlen (cmdfield[j]) + 1)) == NIL)
		errexit(10,"malloc");
	      (void) strcpy(curcmd->command, cmdfield[j]);
	      if (j != cmdnr)
		{
		  if((curcmd = curcmd->nextcmd = (struct cmds *) malloc( sizeof( struct cmds))) == (struct cmds *) NIL)
		    errexit(10,"malloc");
		}
	      else
		curcmd->nextcmd = (struct cmds *) NIL;
	    }
	}
    }

doublecolon = FALSE;

if (!oldrule)
  {
    targnr = 0;
    targfield[1] = NIL;
    depnr =  0;
    depfield[1] = NIL;
    cmdnr = 0;
    cmdfield[1] = NIL;
    heritnr = 0;
    heritfield[1] = NIL;
  }
} /* end ruleend */

convertrule(i)
     int i;
{
  char *p;
  p = rindex(targfield[i],'.');
  *p = '\0';
  p++;
  if ((depfield[1] = malloc((unsigned) (strlen(targfield[i]) + 3))) == NIL)
    errexit(10,"malloc");
  (void) strcpy(depfield[1],"%");
  (void) strcat(depfield[1],targfield[i]);
  if((targfield[1] = malloc((unsigned) (strlen(p) + 3))) == NIL)
    errexit(10,"malloc");
  (void) strcpy(targfield[1],"%.");
  (void) strcat(targfield[1],p);
  targnr = 1;
  depnr = 1;
}

ruledump(fd)
     FILE *fd;
{
struct rules *cur;
struct cmds *ccmd;
int i;
int k = 0;
for(i = 0; i< RULETABSIZE; i++)
  {
    if (ruletab[i] != (struct rules *) NIL)
      {
	k = 0;
	cur = ruletab[i];
	while( cur != (struct rules *) NIL)
	  {
	    if(fd == stdout)
	      fprintf(fd,"%s\n", cur->name);
	    else
	      fprintf(fd,"%s", cur->name);

	    if (fd == stdout)
	      fprintf(fd," depends on:");
	    else
	      fprintf(fd,":");

	    while (cur->deplist[k] != NIL)
	      {
		if (fd != stdout)
		  {
		    if(!is_selrule_name(cur->deplist[k]))
		      fprintf(fd," %s",cur->deplist[k]);
		    k++;
		  }
		else
		  {
		    fprintf(fd," %s",cur->deplist[k]);
		    k++;
		  }
	      }
	    fprintf(fd,"\n");

	    ccmd = cur->cmdlist;

	    if(fd == stdout)
	      fprintf(fd," commands:\n");
	      
	    while (ccmd != (struct cmds *) NIL)
	      {
		fprintf(fd,"%s\n", ccmd->command);
		ccmd = ccmd->nextcmd;
	      }
	    fprintf(fd,"\n");
	    cur = cur->nextrule;
	  }
      }
  }


for(i = 0; i < lastrule; i++)
  {
    k = 0;
    cur = stdruletab[i];

    if(fd == stdout)
      fprintf(fd,"%s\n", cur->name);
    else
      fprintf(fd,"%s", cur->name);

    if (fd == stdout)
      fprintf(fd," depends on:");
    else
      fprintf(fd," :");

    while (cur->deplist[k] != NIL)
      {
	fprintf(fd," %s",cur->deplist[k]);
	k++;
      }

    if (fd == stdout)
      fprintf(fd,"\n");

    k = 0;
    
    if (fd == stdout)
      fprintf(fd," inherits:");
    else
      fprintf(fd," :");

    while (cur->heritage[k] != NIL)
      {
	fprintf(fd," %s", cur->heritage[k]);
	k++;
      }
    fprintf(fd,"\n");

    ccmd = cur->cmdlist;
    
    if (fd == stdout)
      fprintf(fd," commands:\n");

    while (ccmd != (struct cmds *) NIL)
      {
	fprintf(fd,"%s\n", ccmd->command);
	ccmd = ccmd->nextcmd;
	if (ccmd->command == NIL)
	  break;
      }
    fprintf(fd,"\n");
  }

(void) fflush(fd);

} /* end ruledump */


adjust_stdrules(suffs)
     /*ARGSUSED*/
     char *suffs;
{

;
}
      
Bool is_old_rule(string)
     char *string;
{
  char *p1,*p2;
  if (index(string,'/') != NIL)
    return(FALSE);
  if (((p1 = index(string,'.')) != NIL) &&
      ((p2 = index(string+2,'.')) != NIL) &&
      (p1 < p2))
    return(TRUE);
  else
    return(FALSE);
}
      
   
overload_stdrule()
{
  int i;
  
  for(i = 0; i < lastrule; i++)
    {
      if((strcmp(stdruletab[implicit_suffs[i]]->name,targfield[1]) == 0) &&
	 (strcmp(stdruletab[implicit_suffs[i]]->deplist[0], depfield[1]) == 0))
	{
	  implicit_suffs[i] = lastrule;
	  return;
	}
    }
}
	
	
	
init_ruletab()
{
  bzero((char *) ruletab, 257 * sizeof(struct rules *));
}

