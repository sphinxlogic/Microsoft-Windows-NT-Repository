/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *RCSid = "$Header: macro.c,v 3.2 89/02/20 16:25:49 wolfgang Exp $";
#endif
#ifndef lint
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	macro.c,v $
 * Revision 3.2  89/02/20  16:25:49  wolfgang
 * NET-RELEASE
 * 
 * Revision 3.1  89/02/08  12:45:34  wolfgang
 * performance improved.
 * 
 * Revision 3.0  89/01/24  11:35:54  wolfgang
 * New System Generation
 * 
 * Revision 2.19  89/01/03  13:11:05  wolfgang
 * changes done for lint
 * 
 * Revision 2.18  88/12/21  15:03:44  wolfgang
 * changes done for lint
 * 
 * Revision 2.17  88/12/15  16:16:23  wolfgang
 * bug fixed in get_macros (segmantation violation on sissy (SUN))
 * 
 * Revision 2.16  88/11/21  20:56:56  wolfgang
 * changes done for sun
 * 
 * Revision 2.15  88/11/18  15:01:18  wolfgang
 * bug fixed: ::= indicates no longer a macrodef.
 * 
 * Revision 2.14  88/11/04  16:41:58  wolfgang
 * variant macros no are accumulated.
 * 
 * Revision 2.13  88/10/27  16:37:40  wolfgang
 * bugs fixed (new variant handling).
 * 
 * Revision 2.12  88/10/20  13:20:56  wolfgang
 * bug fixed in get_variant_macro.
 * 
 * Revision 2.11  88/10/18  17:41:12  wolfgang
 * new handling for variants implemented. macro expansion changed.
 * 
 * Revision 2.10  88/10/14  17:14:10  wolfgang
 * new procedure: get_variant_macro added and changes don for new
 * handling of variants.
 * 
 * Revision 2.9  88/10/13  12:03:24  wolfgang
 * handle_comments changed: white space is now required after #%.
 * 
 * Revision 2.8  88/09/16  13:30:57  wolfgang
 * getlin changed. In continuation lines one leading TAB is now suppressd.
 * 
 * Revision 2.7  88/09/09  11:40:31  wolfgang
 * little bug fixed.
 * 
 * Revision 2.6  88/09/08  11:57:51  wolfgang
 * handle_comments(line) improved: # are allowed in quotes.
 * 
 * Revision 2.5  88/09/08  11:48:29  wolfgang
 * handle_comments improved: kills commenmts if there are no quotes.
 * 
 * Revision 2.4  88/09/08  10:32:55  wolfgang
 * handle_comments(line) added. Now comments are allowed in rule- and
 * variant-section, respectively.
 * 
 * Revision 2.3  88/09/07  11:22:38  wolfgang
 * get_macros changed; the files are copied into a tmp file which is
 * the input file for yylex.
 * 
 * Revision 2.2  88/08/23  16:33:21  wolfgang
 * In dump() now \t is supressed for generating confid's (im macrodefinitions
 * \t is not allowed as first char.
 * 
 * Revision 2.1  88/08/19  10:17:33  wolfgang
 * This version is part of a release
 * 
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/dir.h>
#include "macro.h"
#include "shape.h"

extern FILE *mkstemp();
extern void addhash();
extern char *get_variant_macro();
extern char *curvar[];
extern struct vardef *vardefs[];
char *template = "/tmp/shapeXXXXXX";
FILE *temp;


char *curvpath[8] = {NIL,NIL,NIL,NIL,NIL,NIL,NIL,NIL};
char *errstring;
int macdepth;
int variants_active = 0;

char *get_next_item(string)
     char *string;
{
  char *p1;

  if ((p1 = index(string,' ')) != NIL)
    {
      *p1 = '\0';
      return string;
    }
  else
    return string;
}


char *getlin(file)
     FILE *file;
{
  char line[MAXLINELENGTH];
  char line2[MAXLINELENGTH];
  int len = 0;
  while (fgets(line, MAXLINELENGTH, file))   /* getc ?????  */
    {
      len = strlen(line);
      while ((line[len-2] == '\\') && (line[len-1] == '\n'))
	{
	  line[len-2] = ' ';
	  line[len-1] = '\0';
	  (void) fgets(line2, MAXLINELENGTH, file);
	  if(line2[0] == '\t')
	    (void) strcat(line,&line2[1]);
	  else
	    (void) strcat(line,line2);
	  len = strlen(line);
	}
      len = strlen(line);
      line[len-1] = '\0';
      return (line);
    }
/*NOTREACHED*/
}


get_macros(file)
     FILE *file;
{
  FILE *incfile;
  char *line;
  char *incp;
  int inck;
  char incfilename[MAXNAMLEN];
  extern char *expandmacro();

  while((line = getlin(file)) != NIL)
    {

      if((strncmp(line,INCLUDE,7)) == 0)
	{
	  inck = 7;
	  while ((line[inck] == '\t') || (line[inck] == ' '))
	    inck++;
	  if ((incp = rindex(line+inck,' ')) != NIL)
	    *incp = '\0';
	  if ((incp = rindex(line+inck,'\t')) != NIL)
	    *incp = '\0';
	  if (index(line+inck,'$') != NIL)
	    (void) strcpy(incfilename,expandmacro(line+inck));
	  else
	    (void) strcpy(incfilename,line+inck);
	  if ((incfile = fopen(incfilename,"r")) == NULL)
	    errexit(24,incfilename);
	  else
	    {
	      get_macros(incfile);
	      (void) fclose(incfile);
	    }
	}
      else
	{
	  handle_comments(line);
	  fputs(line,temp);
	  fputs("\n",temp);

	  macrodef(line);
	}
    }
}


macrodef(line)
     char *line;
{
  char *name;
  char *value;
  int hashv;
  char *p1, *p2;
  char *enventry;
  char *line2;

  if (!line)
    return;

  if ((name = malloc(MACRONAM)) == NIL)
    errexit(10,"malloc");
  if((value = malloc(MACROVAL)) == NIL)
    errexit(10,"malloc");
  if((line2 = malloc(MAXLINELENGTH)) == NIL)
    errexit(10,"malloc");
  if (*line != '\t')
    {
      p1 = index(line,'=');
      p2 = index(line,':');
      
      if ((p1 != NIL) && (*(p1-1) != ':') && (*(p1-2) != ':'))
	{
	  if ((p2 == NIL) || (p1 < p2))
	    {
	      *p1 = '\0';
	      p2 = p1;
	      p2--;
	      while((*line == '\t') || (*line == ' '))
		line++;
	      while((*p2 == ' ') || (*p2 == '\t'))
		*p2-- = '\0';
	      name = line;
	    }
	  p1++;
	  while((*p1 == '\t') || (*p1 == ' '))
	    p1++;
	  value = p1;
	  if (strcmp(name,IMPORT) != 0)
	    {
#ifdef DEBUG_MACRO
printf("name=#%s#\nvalue=#%s#\n\n", name, value);
#endif DEBUG_MACRO
	      hashv = hashval(name);
	      addhash(hashv,name,value);
              if (strcmp(name,"VPATH") == 0)
		{
		  insertvpath(value);
		}
            }
	  else
	    { 
	      /* get environment variables */
	      while((name = get_next_item(value)) != NIL)
		{
		  if (strcmp(value,"") == 0)
		    break;
		  value = index(value,'\0');
		  value++;
		  if ((enventry = getenv(name)) != NIL)
		    {
		      (void) strcpy(line2,name);
		      (void) strcat(line2,"=");
		      (void) strcat(line2,enventry);
		      macrodef(line2);
		    }
		}
	    }
	}
    }
  free(name);
  free(line2);
  free(value);
}

char *expandmacro(inpstring)
     char *inpstring;
{

char name[64];
int hashv;
char *p;
struct hash *current = (struct hash *) NIL;
int j = 0;
int ii = 0;
char *list[100];
char klazu;
char *start;
char newstr[MAXLINELENGTH];
char *string;
char *mist;
char *variant_macro = NIL;
Bool dollar;
dollar = FALSE;
if (macdepth == 0)
    errstring = inpstring;

macdepth++;

if (macdepth == 50)
  errexit(25, errstring);

newstr[0] = '\0';
if ((string = malloc((unsigned) (strlen(inpstring) + sizeof(char)))) == NIL)
  errexit(10,"malloc");
(void) strcpy(string,inpstring);
p = string;

while (*p != '\0')
  {
    if (*p != '$')
      {
	if (dollar == FALSE)
	  {
	    list[ii] = p;
	    ii++;
	    dollar = FALSE;
	  }
  	if (ii > 100)
	  errexit(25, errstring);
      }
    while ((*p != '$') && (*p != '\0'))
      p++;
    if ( *p == '\0')
      break;
    else
      {
	if ((*(p+1) == '(') || (*(p+1) == '{'))
	  {
	    klazu = ((*(p+1) == '(') ? ')':'}');
	    *p = '\0';
	    p = p + 2;
	    start = p;

	    while(*p != klazu)
	      {
		p++;
	      }
	    *p = '\0';
	    (void) strcpy(name,start);
	    p++;
	  }
	else
	  {
	    if ((*(p+1) != '@') && (*(p+1) != '?') &&
		(*(p+1) != '<') && (*(p+1) != '*') &&
		(*(p+1) != '$') && (*(p+1) != '+'))
	      {
		name[0] = *(p+1);
		name[1] = '\0';
		*p = '\0';
		p = p + 2;
	      }
	    else
	      {
		name[0] = '\0';
		dollar = TRUE; 
		p = p + 2;
	      }
	  }
	if (name[0] != '\0')
	  {
	    dollar = FALSE;

	    if(strcmp(curvar[0],""))
	      {
		variant_macro = get_variant_macro(name);
		if (strcmp(variant_macro,BLUMENKOHL))
		  {
		    mist = expandmacro(variant_macro);
		    if ((list[ii] =
			 malloc((unsigned)
				(strlen(mist) + sizeof(char)))) == NIL)
		      errexit(10,"malloc");
		    (void) strcpy(list[ii],mist);
		    ii++;
		    if (ii > 100)
		      errexit(25, errstring);
		  }
	      }
	    if((variant_macro == NIL) || (!strcmp(variant_macro,BLUMENKOHL)))
	      {
		variant_macro = NIL;
		hashv = hashval(name);
		if (hashtab[hashv] != (struct hash *) NIL)
		  {
		    current = hashtab[hashv];
		    while (((strcmp (current->name, name)) != 0) && (current->next != (struct hash *) NIL))
		      current = current->next;
		    
		    if ((strcmp(current->name, name) == 0))
		      {
			mist = expandmacro(current->entry);
			if ((list[ii] =
			     malloc((unsigned) 
				    (strlen(mist) + sizeof(char)))) == NIL)
			  errexit(10,"malloc");
			(void) strcpy(list[ii],mist);
			ii++;
			if (ii > 100)
			  errexit(25, errstring);
		      }
		  }
	      }
	  }
      }
  }
for (j = 0; j < ii; j++)
     (void) strcat(newstr,list[j]);
macdepth = 0;
return newstr;
} /*end expandmacro */



handle_comments(line)
     char *line;
{
  char *p;
  int i;
  int q = 0;
  int dq = 0;

  if (( p = index(line,'#')) == NIL)
    /* no comment */
    return;
  
  if ((line[0] == '#') && (line[1] != '%'))
    {
      /* comment, starting at beginning of line */
      line[0] = '\0';
      return;
    }

  if (((line[0] == '#') && (line[1] == '%')) &&
      ((line[2] == ' ') || (line[2] == '\t')))
    return;
  
  if (p != NIL)
    {
      if((index(line,'\'') == NIL) && (index(line,'\"') == NIL))
	/* the # is not in quotes */
	{
	  *p = '\0';
	  return;
	}
      else
	/* maybe no comment */
	{
	  for(i = 0; line[i] != '\0'; i++)
	    {
	      if(line[i] == '\'')
		q++;
	      if(line[i] == '\"')
		dq++;
	      if((line[i] == '#') && ((q % 2) == 0) && ((dq % 2) == 0))
		{
		  line[i] = '\0';
		  return;
		}
	    }
	}
    }
}


char *get_variant_macro(name)
     char *name;

     /* get macro value for variant */
{
int i = 0;
int k = 0;
int j = 0;

char *p;
char *p1;
char *p2;
char *p3;

char macro[2048];
char retval[1024];

retval[0] = '\0';

while(strcmp(curvar[i],""))
  {
    k = 0;
    while (vardefs[k] != (struct vardef *) NIL)
      {
	if (strcmp(vardefs[k]->name,curvar[i]))
	  k++;
	else
	  break;
      }

    if (vardefs[k] != (struct vardef *) NIL)
      {
	if ((!strcmp(name,"vpath")) && (vardefs[k]->vpath != NIL))
	  {
	    if (retval[0] == '\0')
	      (void) strcat(retval, vardefs[k]->vpath);
	    else
	      {
		(void) strcat(retval," ");
		(void) strcat(retval, vardefs[k]->vpath);
	      }
	  }
    
	if ((!strcmp(name,"vflags")) && (vardefs[k]->vflags != NIL))
	  {
	    if (retval[0] == '\0')
	      (void) strcat(retval,vardefs[k]->vflags);
	    else
	      {
		(void) strcat(retval," ");
		(void) strcat(retval,vardefs[k]->vflags);
	      }
	  }

	for(j = 0; j < MAXVMACROS; j++)
	  {
	    if (vardefs[k]->vmacros[j] == NIL)
	      {
		i++;
		break;
	      }
	    (void) strcpy(macro,vardefs[k]->vmacros[j]);
	    if (!strcmp(macro,""))
	      {
		i++;
		break;
	      }
	    p1 = index(macro,'=');
	    p2 = index(macro,' ');
	    p3 = index(macro,'\t');
    
	    if (p2 == NIL)
	      p2 = p1 + 1;
    
	    if (p3 == NIL)
	      p3 = p1 + 1;

	    if (( p1 < p2) && (p1 < p3))
	      p = p1;
	    if (( p2 < p1) && (p2 < p3))
	      p = p2;
	    if (( p3 < p2) && (p3 < p1))
	      p = p3;

	    *p = '\0';
	    p1++;
	    
	    if (!strcmp(name,macro))
	      {
		while((*p1 == ' ') || (*p1 == '\t') || (*p1 == '='))
		  p1++;
		if(retval[0] == '\0')
		  (void) strcat(retval,p1);
		else
		  {
		    (void) strcat(retval," ");
		    (void) strcat(retval,p1);
		  }
	      }
	  }
      }
    else
      i++;
  }
if(retval[0] != '\0')
  return(retval);
else
  return(BLUMENKOHL);
}
