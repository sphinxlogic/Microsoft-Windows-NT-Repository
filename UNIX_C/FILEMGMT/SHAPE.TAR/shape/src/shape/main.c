/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *RCSid = "$Header: main.c,v 3.1 89/02/20 16:25:58 wolfgang Exp $";
#endif
#ifndef lint
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	main.c,v $
 * Revision 3.1  89/02/20  16:25:58  wolfgang
 * NET-RELEASE
 * 
 * Revision 3.0  89/01/24  11:36:03  wolfgang
 * New System Generation
 * 
 * Revision 2.16  89/01/18  13:42:29  wolfgang
 * call of init_selruletab() added.
 * 
 * Revision 2.15  89/01/03  13:11:31  wolfgang
 * changes done for lint
 * 
 * Revision 2.14  88/12/22  13:22:33  wolfgang
 * initializarion of bpoolflg added.
 * 
 * Revision 2.13  88/12/21  15:10:52  wolfgang
 * changes done for lint
 * 
 * Revision 2.12  88/11/22  17:37:23  wolfgang
 * This version is part of a release
 * 
 * Revision 2.11  88/11/21  15:50:36  wolfgang
 * return code of all malloc's checked
 * 
 * Revision 2.10  88/10/10  14:16:58  wolfgang
 * feature for -p option added.
 * 
 * Revision 2.9  88/09/22  16:16:24  wolfgang
 * call of cleanup_links changed. call of shape_cleanup added.
 * 
 * Revision 2.8  88/09/22  10:02:17  wolfgang
 * declaration of ruleset changed.
 * 
 * Revision 2.7  88/09/07  11:21:13  wolfgang
 * changes for include mechanism: now a tmp file is produced which
 * contains all input files for shape.
 * 
 * Revision 2.6  88/08/25  15:17:19  wolfgang
 * stdmacros changed: the macros for sccs replaced by two macros
 * for shape: SHAPEFLAGS & SHAPE.
 * 
 * Revision 2.5  88/08/23  16:38:06  wolfgang
 * Rebuild feature added (to rebuild something from a confid).
 * 
 * Revision 2.4  88/08/23  10:24:28  wolfgang
 * Changed ruledump() to ruledump(fd) to be able to use it for
 * generating confid's.
 * 
 * Revision 2.3  88/08/22  17:02:12  wolfgang
 * dump() changed to dump(fd).
 * finis_confid added.
 * 
 * Revision 2.2  88/08/22  10:12:15  wolfgang
 * Changed main.c, so that it is no longer necessary to have a description
 * file. It's enaugh to have the name of a target to produce on the command
 * line
 * 
 * Revision 2.1  88/08/19  10:17:37  wolfgang
 * This version is part of a release
 * 
 */

#include "shape.h"
#include "ParseArgs.h"

#include <stdio.h>

#define MAXCMDTARGETS 32

extern char *getwd();
extern char *mktemp();

extern int hashval();
extern void addhash();
extern int adjust_stdrules();
extern int dump();
extern int ruleend();
extern int ruledump();
extern int errexit();
extern int init_ruletab();
extern int init_selruletab();
extern int seldump();
extern int selruledef();
extern int stdrules();
extern Bool is_selrule_name();
extern int catch_sigs();

extern int yylex();
extern FILE *yyin;
extern FILE *vmfopen();

extern int cleanup_links();
extern int af_cleanup();

extern struct linkreg *link_reg;

extern char *firsttarget;
extern char ruleset[];
extern char *stdsuff;

extern struct selection_rules *currule;
extern char *busy_rule;
extern char *longattrs[];
extern char *template;
extern FILE *temp;
char rbfile[MAXNAMLEN];

char *filenames[] = {"Shapefile", "shapefile", "Makefile", "makefile"};

#define STDMACROS 29

char *stdmacros[] = { "SHAPEFLAGS=","SHAPE=shape","ASFLAGS=","AS=as",
			"RFLAGS=","FFLAGS=","FC=f77","M2FLAGS=",
			"M2C=m2c","PFLAGS=","PC=pc","CFLAGS=",
			"CC=cc","LDFLAGS=","LD=ld","LFLAGS=",
			"LEX=lex","YFLAGS=","YACC=yacc","MAKE=make",
			"$=$$","MFLAGS=-b","MAKEFLAGS=b",
		        "@=$@", "?=$?", "<=$<", "*=$*",
			"+=$+"};

struct linked_list *shapefiles = (struct linked_list *) NIL;
     /* list of names of files from
	command line via the -f option */
struct linked_list *shfiles;

char *cmdtargets[MAXCMDTARGETS];
     /* list of target form the	command line */


Bool synterrflg = FALSE;
Bool Oldsuffs = FALSE;
Bool Newsuffs = FALSE;
char *suffs;
#ifdef MEMDEBUG
FILE *memprot;
#endif

main(argc, argv)
     int argc;
     char **argv;
     
{
int newac = 0;
char **newav;

int i;
int k = 0;
int gen = AF_BUSYVERS;
int rev = AF_BUSYVERS;
char macrostr[2048];
extern OptDesc odesc[];

#ifdef MEMDEBUG
memprot = fopen ("memprot", "w");
#endif

rebuildflg = FALSE;
bpoolflg = TRUE;

catch_sigs(); 

if (argc != 1)
  {
    if(ParseArgs (argc, argv, &newac, &newav, odesc))
      {
	pa_ShortUsage(argv[0], odesc, "\n\t      rtfm! (read the manual)");
	exit(1);
      }
  }

if ((curvpath[0] = malloc(MAXNAMLEN)) == NIL)
  errexit(10,"malloc");
(void) getwd(curvpath[0]);
init_ruletab();
init_selruletab();
(void) mktemp(template);
temp = fopen(template,"w");
if(logflg)
  {
    logfd = fopen("SHAPE.LOGFILE","a");
    for (i = 0; i<argc; i++)
      fprintf(logfd,"%s ", argv[i]);
    fprintf(logfd,"\n");
    (void) fclose(logfd);
  }

for(i = 0; i < newac; i++)
  {
    if (index(newav[i],'=') != NIL)
      {
	(void) strcpy(macrostr,newav[i]);
	macrodef(macrostr);
      }
  }

for (i = 0; i < STDMACROS; i++)
     macrodef(stdmacros[i]);


if  (!rebuildflg)
  {

    if (fileflg)
      {
	shfiles = shapefiles;
	while(shfiles != (struct linked_list *) NIL)
	  {
	    if ((yyin = vmfopen(shfiles->string,"r", gen, rev)) == (FILE *)NIL)
	      errexit(12,shfiles->string);
	    else
	      {
		get_macros(yyin);
		(void) fclose(yyin);
	      }
	    shfiles = shfiles->nextstring;
	  }
	if (stdinflg == TRUE)
	  get_macros(stdin);
      }
    else
      {
	for ( i = 0; i <= 3; i++)
	  {
	    if ((yyin = vmfopen (filenames[i], "r", gen, rev)) != (FILE *)NIL) 
	      break;
	  }
	if (yyin == (FILE *)NIL)
	  nostdfile = TRUE;
	else
	  {
	    nostdfile = FALSE;
	    get_macros(yyin);
	    (void) fclose(yyin);
	  }
      }
  }

else
  {
    if(( yyin = vmfopen(rbfile, "r", gen, rev)) == (FILE *) NIL)
      errexit(12, rbfile);
    get_macros(yyin);
    (void) fclose(yyin);
  }

(void) fclose(temp);

for(i = 0; i < newac; i++)
  {
    if (index(newav[i],'=') != NIL)
      macrodef(newav[i]);
    else
      {
	if ((cmdtargets[k] = malloc((unsigned) (strlen(newav[i]) + sizeof(char)))) == NIL)
	  errexit(10,"malloc");
	(void) strcpy(cmdtargets[k++],newav[i]);
	cmdtargets[k] = NIL;
      }
  }

add_stdrules();
firsttarget = NIL;

if ((yyin = fopen(template,"r")) == (FILE *)NIL)
  errexit(12,template);
else
  {
    (void) unlink(template);
    (void) yylex();
    (void) fclose(yyin);
  }


if (synterrflg == TRUE)
  errexit(15,NIL);

ruleend(); /* just for security ????  */

adjust_stdrules(suffs);

/* add busy rule */

selruledef(busy_rule);
(void) is_selrule_name("-STD-");

initattrfield();

produce();
/*
#ifdef DEBUG_HASH
dump();
#endif DEBUG_HASH
#ifdef DEBUG_RULE
ruledump(stdout);
#endif DEBUG_RULE
#ifdef DEBUG_SELRULE
seldump();
#endif DEBUG_SELRULE */
(void) fclose(yyin);
if (confid)
  {
    finish_confid();
    af_close(cid);
  }
if (debugflg)
  {
    if (suffs_deleted)
      printf("no suffix list");
    dump(stdout);  /* dumping macros */
    ruledump(stdout); /* dumping targets, dependents & commands, resp. */
  }

if (printflg)
  {
    if (suffs_deleted)
      printf("no suffix list");
    dump(stdout);  /* dumping macros */
    ruledump(stdout); /* dumping targets, dependents & commands, resp. */
  }

cleanup_links(link_reg);
af_cleanup();
exit(0);
}

int initattrfield()
{
  int i;
  for(i = 0; i < MAXDEPTH; i++)
    {
      if((longattrs[i] = malloc(MAX_ATTR)) == NIL)
	errexit(10,"malloc");
      (void) strcpy(longattrs[i],"");
    }
}

	
