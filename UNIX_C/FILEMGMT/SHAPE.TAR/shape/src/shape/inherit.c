/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *RCSid = "$Header: inherit.c,v 3.2 89/02/15 16:24:39 wolfgang Exp $";
#endif
#ifndef lint
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	inherit.c,v $
 * Revision 3.2  89/02/15  16:24:39  wolfgang
 * bug fixed.
 * 
 * Revision 3.1  89/02/06  14:25:20  wolfgang
 * calls of forbidden() cahnged
 * 
 * Revision 3.0  89/01/24  11:35:46  wolfgang
 * New System Generation
 * 
 * Revision 1.15  89/01/03  13:10:48  wolfgang
 * changes done for lint
 * 
 * Revision 1.14  88/12/22  13:23:16  wolfgang
 * minor bug fixed.
 * 
 * Revision 1.13  88/12/21  15:03:29  wolfgang
 * changes done for lint
 * 
 * Revision 1.12  88/12/19  13:22:59  wolfgang
 * forbidden() & finddep() added.
 * 
 * Revision 1.9  88/11/21  15:51:01  wolfgang
 * return code of all malloc's checked
 * 
 * Revision 1.8  88/11/09  16:26:30  wolfgang
 * bug fixed in comapare_attrstring(). dropset was located wrong
 * 
 * Revision 1.7  88/11/08  19:28:33  wolfgang
 * expandall or expandnothing added to ATTR-string
 * 
 * Revision 1.6  88/11/08  18:07:07  wolfgang
 * inheritance changed: attributes should now be correct.
 * 
 * Revision 1.5  88/11/04  16:43:50  wolfgang
 * This version is part of a release
 * 
 * Revision 1.4  88/09/20  10:03:54  wolfgang
 * bug fixed. concatenation of vflags was not correct.
 * 
 * Revision 1.3  88/08/18  10:25:49  wolfgang
 * This version is part of a release
 * 
 * Revision 1.2  88/08/12  08:58:09  wolfgang
 * This version is part of a release
 * 
 */

#include "shape.h"

extern char *expandmacro();
extern char *build_attrstring();
extern int error();
extern void warning();
extern Af_attrs buft;
extern char *longattrs[];
extern int depth;
extern Bool error_occ;
extern Bool finddep();
extern Bool forbidden();
extern struct rules *get_target();

save_targets(rulename, srcname, objrulename,attrstr)
     struct rules *rulename;
     char *srcname;
     struct rules *objrulename;
     char *attrstr;
{
  Af_key busykey, savekey;
  char *syspath;
  char *name;
  char *type;
  int gen = AF_BUSYVERS;
  int rev = AF_BUSYVERS;
  char attr[MAXATTRLENGTH];
  char *p;
  int retcode;
  char savepath[MAXNAMLEN];

#ifdef NOBPOOL
  return;
#endif NOBPOOL

  if(error_occ)
    {
      error_occ = FALSE;
      return;
    }

  if(noexflg)
    return;

  if ((rindex(srcname,'/')) != NIL)
    {
      (void) strcpy(savepath,srcname);
      p = rindex(savepath,'/');
      *p = '\0';
      p++;
      srcname = p;
      syspath = &savepath[0];
    }
  else
    syspath = curvpath[0];

  if(objrulename != (struct rules *) NIL)
    {
      if((name = malloc((unsigned) (strlen(objrulename->name) + 1))) == NIL)
	errexit(10,"malloc");
      (void) strcpy(name, objrulename->name);
    }
  else
    {
      if((name = malloc((unsigned) (strlen(srcname) + 1))) == NIL)
	 errexit(10,"malloc");
      (void) strcpy(name,srcname);
    }

  if (rulename->name[0] == '%')
    {
      if((p = rindex(name,'.')) != NIL)
	{
	  *p = '\0';
	  (void) strcat(name, rulename->name+1);
	}
    }

  if ((p = rindex(name,'.')) != NIL)
    {
      *p = '\0';
      type = p+1;
    }
  else
    type = NIL;


  if ((af_getkey(syspath,name,type,gen,rev,NIL,&busykey)) == -1)
    errexit(10, "af_getkey");

  af_errno = 0; /* sollte nocht sein */

  retcode = af_sudattr(&busykey,AF_REMOVE,ATTRNAME);

  if ((retcode == -1) && (af_errno == AF_ENOAFSDIR))
    {
      af_initattrs(&buft);
      af_dropkey(&busykey);
      return;
    }
  
  if ((retcode == -1) && (af_errno != AF_ENOUDA) &&
      (af_errno != AF_ENOAFSDIR))
    errexit(10,"af_sudattr");

  if ((bpoolflg) || (nobpoolflg))
    {
      if(!forbidden(syspath,name,type))
	{
	  if ((af_savebinary(&busykey,&savekey)) == -1)
	    {
	      if(af_errno == AF_ENOAFSDIR)
		warning(1,NIL);
	      else
		errexit(10, "af_savebinary");
	    }
	}
    }

  if(attrstr[0] == '\0')
    (void) strcpy(attr,build_attrstring(rulename,srcname,objrulename));
  else
    (void) strcpy(attr,attrstr);

  if ((bpoolflg) || (nobpoolflg))
    {
      if(!forbidden(syspath,name,type))
	{
	  retcode = af_sudattr(&savekey,AF_REPLACE,attr);
	  if (retcode == -1)
	    {
	      retcode = af_sudattr(&savekey,AF_ADD,attr);
	      if ((retcode == -1) && (af_errno != AF_ETOOLONG) &&
		  (af_errno != AF_ENOAFSDIR))
		errexit(10,"af_sudattr");
	      if (af_errno == AF_ETOOLONG)
		{
		  retcode = af_errno;
		  /* attrs are too long */
		  if ((af_rm(&savekey)) == -1)
		    errexit(10,"af_rm");
		}
	    }
	  if (retcode != AF_ETOOLONG)
	    {
	      if (buft.af_gen != -1)
		{
		  if ((af_svnum(&savekey,buft.af_gen,buft.af_rev)) == -1)
		    errexit(10,"af_svnum");
		}
	      else
		{
		  if ((af_svnum(&savekey,AF_BUSYVERS,AF_BUSYVERS)) == -1)
		    errexit(10,"af_svnum");
		}
	    }
	  af_dropkey(&savekey);
	}
    }

  if ((af_sudattr(&busykey,AF_REPLACE,attr)) == -1)
    {
      if ((af_sudattr(&busykey,AF_ADD,attr)) == -1)
	errexit(10,"af_sudattr");
    }
  af_initattrs(&buft);
}
 

char *build_attrstring(rulename,srcname,objrulename)
     struct rules *rulename;
     /*ARGSUSED*/
     char *srcname;
     struct rules *objrulename;

{
  char attr[MAXATTRLENGTH];
  int i = 0;
  char *p;

  attr[0] = '\0';
  (void) strcpy(attr,ATTRNAME);
  
  if(expflg)
    (void) strcat(attr,"expandall");
  if(noexpflg)
    (void) strcat(attr,"expandnothing");

  for( i = 0; rulename->targetlist[i] != NIL; i++)
    {
      (void) strcat(attr,rulename->targetlist[i] + 1);
    }
  for(i = 0; rulename->heritage[i] != NIL; i++)
    {
      (void) strcat(attr, rulename->heritage[i]);
      (void) strcat(attr,"=");
      (void) strcat(attr,rulename->heritage[i]);
      p = rindex(attr,'+');
      *p = '$';
      (void) strcpy(attr,expandmacro(attr));
    }

/*  if (buft.af_gen != -1)
    {
       (void) sprintf(attr,"%sversion=%d.%d",attr,buft.af_gen,buft.af_rev);
    }
    else
    (void) sprintf(attr,"%sversion=%d.%d",attr,AF_BUSYVERS,AF_BUSYVERS); */
  (void) strcat(attr, longattrs[depth]);
  (void) strcpy(longattrs[depth],attr);
  return(attr);
}


Bool forbidden(syspath,name,type)
     char *syspath;
     char *name;
     char *type;
{
  char fullname[MAXNAMLEN];
  Bool bp = FALSE;
  Bool nobp = FALSE;
  struct rules *bpool;
  struct rules *nobpool;
  
  fullname[0] = '\0';
  if (strcmp(syspath,curvpath[0]))
    {
      (void) strcpy(fullname,syspath);
      (void) strcat(fullname,"/");
      (void) strcat(fullname,name);
    }
  else
    {
      (void) strcpy(fullname,name);
    }

  if (type != NIL)
    {
      (void) strcat(fullname,".");
      (void) strcat(fullname,type);
    }

  bpool = get_target(".BPOOL");
  nobpool = get_target(".NOBPOOL");

  if (bpool != (struct rules *) NIL)
    {
      bp = finddep(bpool,fullname);
    }
  else
    bp = TRUE;
  
  if (nobpool != (struct rules *) NIL)
    {
      nobp = finddep(nobpool,fullname);
    }

  if (bp && nobp)
    return(TRUE);

  if (bp && (!nobp))
    return(FALSE);

  if ((!bp) && nobp)
    return(TRUE);
  
  if ((!bp) && (!nobp))
    return(TRUE);
/*NOTREACHED*/
return(FALSE);
}

Bool finddep(rule,name)
     struct rules *rule;
     char *name;
{
  int i = 0;
  while(rule->deplist[i] != NIL)
    {
      if (!strcmp(rule->deplist[i],name))
	return(TRUE);
      i++;
    }
  return(FALSE);
}
