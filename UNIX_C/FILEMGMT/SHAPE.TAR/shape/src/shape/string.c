/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *RCSid = "$Header: string.c,v 3.1 89/02/14 21:20:31 wolfgang Exp $";
#endif
#ifndef lint
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	string.c,v $
 * Revision 3.1  89/02/14  21:20:31  wolfgang
 * bug fixed in repl_string
 * 
 * Revision 3.0  89/01/24  11:37:12  wolfgang
 * New System Generation
 * 
 * Revision 1.4  89/01/03  13:14:09  wolfgang
 * changes done for lint
 * 
 * Revision 1.3  88/11/18  15:04:02  wolfgang
 * modul names are only expanded if dir is a vpath dir
 * 
 * Revision 1.2  88/08/12  08:58:29  wolfgang
 * This version is part of a release
 * 
 */

#include "shape.h"

extern Bool is_vpath_dir();

char *pathlist[MAXPATHLIST][2];
int lastpath;


char *repl_string(inpstring)
     char *inpstring;
{
  /* replaces "[ \t]<file>[ \t\0" with "[ \t]<dir/file>[ \t\0] */

  int i;
  int j;
  int k;
  int l;
  int xx;
  char *l1;
  char l2[2048];

  if ((l1 = malloc(2048)) == NIL)
    errexit(10,"malloc");

  l1[0] = '\0';
  l2[0] = '\0';

  if (lastpath == 0)
    return(inpstring);

  k = strlen(inpstring);

  (void) strcpy(l1,inpstring);

  for ( i = lastpath-1; i >= 0; i--)
    {
      if (strcmp(pathlist[i][1],"&$"))
	{
	  l = strlen(pathlist[i][0]);
	  for(j = 0; j <= k; j++)
	    {
	      if(((l1[j - 1] == ' ') || (l1[j - 1] == '\t')) &&
		 ((l1[j + l]) == ' '|| (l1[j + l] == '\t') ||
		  (l1[j + l] == '\0')))
		{
		  if(!strncmp(&l1[j],pathlist[i][0],l))
		    {
		      for (xx = 0; xx < j; xx++)
			l2[xx] = l1[xx];
		      l2[j] = '\0';
		      (void) strcat(l2,pathlist[i][1]);
		      (void) strcat(l2,&l1[j+l]);
		      l2[strlen(l2)] = '\0';
		      (void) strcpy(l1,l2);
		      l2[0] = '\0';
		    }
		}
	      k = strlen(l1);
	    }
	}
    }
  return(l1);
}
