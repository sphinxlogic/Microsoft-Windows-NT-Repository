/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *RCSid = "$Header: std.c,v 3.0 89/01/24 11:37:03 wolfgang Stable $";
#endif
#ifndef lint
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	std.c,v $
 * Revision 3.0  89/01/24  11:37:03  wolfgang
 * New System Generation
 * 
 * Revision 2.10  88/12/21  15:13:06  wolfgang
 * changes done for lint
 * 
 * Revision 2.9  88/11/22  18:56:06  wolfgang
 * bug fixed: missing initialization.
 * 
 * Revision 2.7  88/11/21  15:48:45  wolfgang
 * return code of all malloc's checked
 * 
 * Revision 2.6  88/10/10  17:03:38  wolfgang
 * This version is part of a release
 * 
 * Revision 2.5  88/09/19  14:41:23  wolfgang
 * little bug fixed
 * 
 * Revision 2.4  88/09/19  11:47:34  wolfgang
 * added +(CC) & +(CFLAGS) in .l.o rule.
 * 
 * Revision 2.3  88/09/14  10:52:28  wolfgang
 * undone last changes
 * 
 * Revision 2.2  88/09/13  09:55:29  wolfgang
 * It's now possible to overload implicit standard rules.
 * 
 * Revision 2.1  88/08/19  10:18:11  wolfgang
 * This version is part of a release
 * 
 */

/* reearrangement of suffixes ??? */
/* implicit predefined rules with more than one target ??? */

#include "std.h"
#include "shape.h"
struct rules *stdruletab[STDRULETABSIZE];
int lastrule;

/* char *stdsuff = ".o .c .c~ .mod .mod~ .sym .def .def~ .p .p~ .f .f~ .F .F~ .r .r~ .y .y~ .l .l~ .s .s~ .sh .sh~ .h .h~ "; */

/* .x~ suffixes are not supportet */

char *stdsuff = ".o .c .mod .sym .def .a .p .f .F .r .y .l .s .sh .h";

char *shaperules = "%.o:%.c %.o:%.l %.o:%.y %.o:%.s %.o:%.r %.o:%.F %.o:%.f %.o:%.mod %.o:%.p %.c:%.l %.c:%.y %.sym:%.def %.a:%.c %:%.sh %:%.r %:%.F %:%.f %:%.p %:%.mod %:%.c ";

int implicit_suffs[MAXIMPLICIT] = {12, /*  0   .c.o     */ 
				    3, /*  1   .l.o     */ 
				    4, /*  2   .y.o     */ 
				    5, /*  3   .s.o     */ 
				    6, /*  4   .r.o     */ 
				    7, /*  5   .F.o     */ 
				    8, /*  6   .f.o     */ 
				   10, /*  7   .mod.o   */ 
				   11, /*  8   .p.o     */ 
				    1, /*  9   .l.c     */ 
				    2, /* 10   .y.c     */ 
				    9, /* 11   .def.sym */ 
				    0, /* 12   .c.a     */ 
				   13, /* 13   .sh      */ 
				   14, /* 14   .r       */ 
				   15, /* 15   .F       */ 
				   16, /* 16   .f       */ 
				   17, /* 17   .p       */ 
				   18, /* 18   .mod     */ 
				   19, /* 19   .c       */ 
				   -1 };


char *stdrules[] = {

/* ".c.a",
"\t$(CC) -c $(CFLAGS) $(vflags) $<",
"\tar rv $@ $*.o",
"\trm -f $*.o", */

  "%.a",  /* 0 */
  "%.c",
  "+(CC)",
  "+(CFLAGS)",
  "+(vflags)",
  "\t$(CC) -c $(CFLAGS) $(vflags) %.c",
  "\tar rv %.a %.o",
  "\trm -f %.o",

/* ".l.c",
"\t$(LEX) $(LFLAGS) $<",
"\tmv lex.yy.c $@", */

  "%.c",  /* 1 */
  "%.l",
  "+(LEX)",
  "+(LFLAGS)",
  "\t$(LEX) $(LFLAGS) %.l",
  "\tmv lex.yy.c %.c",

/* ".y.c",
"\t$(YACC) $(YFLAGS) $<",
"\tmv y.tab.c $@", */

  "%.c",  /* 2 */
  "%.y",
  "+(YACC)",
  "+(YFLAGS)",
  "\t$(YACC) $(YFLAGS) %.y",
  "\tmv y.tab.c %.c",

/* ".l.o",
"\t$(LEX) $(LFLAGS) $<",
"\t$(CC) $(CFLAGS) $(vflags) -c lex.yy.c",
"\trm lex.yy.c",
"\tmv lex.yy.o $@", */

  "%.o",  /* 3 */
  "%.l",
  "+(LEX)",
  "+(LFLAGS)",
  "+(CC)",
  "+(CFLAGS)",
  "+(vflags)",
  "\t$(LEX) $(LFLAGS) %.l",
  "\t$(CC) $(CFLAGS) $(vflags) -c lex.yy.c",
  "\trm lex.yy.c",
  "\tmv lex.yy.o %.o",

/* ".y.o",
"\t$(YACC) $(YFLAGS) $<",
"\t$(CC) $(CFLAGS) $(vflags) -c y.tab.c",
"\trm y.tab.c",
"\tmv y.tab.o $@", */

  "%.o",  /* 4 */
  "%.y",
  "+(YACC)",
  "+(YFLAGS)",
  "+(CC)",
  "+(CFLAGS)",
  "+(vflags)",
  "\t$(YACC) $(YFLAGS) %.y",
  "\t$(CC) $(CFLAGS) $(vflags) -c y.tab.c",
  "\trm y.tab.c",
  "\tmv y.tab.o %.o",

/* ".s.o",
"\t$(AS) $(ASFLAGS) -o $@ $<", */

  "%.o",  /* 5 */
  "%.s",
  "+(AS)",
  "+(ASFLAGS)",
  "\t$(AS) $(ASFLAGS) -o %.o %.s",

/* ".r.o",
"\t$(FC) $(RFLAGS) $(FFLAGS) -c $<", */

  "%.o",  /* 6 */
  "%.r",
  "+(FC)",
  "+(RFLAGS)",
  "+(FFLAGS)",
  "\t$(FC) $(RFLAGS) $(FFLAGS) -c %.r",

/* ".F.o",
"\t$(FC) $(FFLAGS) -c $<", */

  "%.o",  /* 7 */
  "%.F",
  "+(FC)",
  "+(FFLAGS)",
  "\t$(FC) $(FFLAGS) -c %.F",

/* ".f.o",
"\t$(FC) $(FFLAGS) -c $<", */

  "%.o",  /* 8 * */
  "%.f",
  "+(FC)",
  "+(FFLAGS)",
  "\t$(FC) $(FFLAGS) -c %.f",

/* ".def.sym",
"\t$(M2C) $(M2FLAGS) $<", */

  "%.sym",  /* 9 */
  "%.def",
  "+(M2C)",
  "+(M2FLAGS)",
  "\t$(M2C) $(M2FLAGS) %.def",

/* ".mod.o",
"\t$(M2C) $(M2FLAGS) $<", */

  "%.o",  /* 10 */
  "%.mod",
  "+(M2C)",
  "+(M2FLAGS)",
  "\t$(M2C) $(M2FLAGS) %.o",

/* ".p.o",
"\t$(PC) $(PFLAGS) -c $<", */

  "%.o",  /* 11 */
  "%.p",
  "+(PC)",
  "+(PFLAGS)",
  "\t$(PC) $(PFLAGS) -c %.o",

/* ".c.o",
"\t$(CC) $(CFLAGS) $(vflags) -c $<", */

  "%.o",  /* 12 */
  "%.c",
  "+(CC)",
  "+(CFLAGS)",
  "+(vflags)",
  "\t$(CC) $(CFLAGS) $(vflags) -c %.c",

/* ".sh",
"\tcat $< >$@; chmod +x $@", */

  "%",  /* 13 */
  "%.sh",
  "\tcat %.sh >%; chmod +x %",

/* ".r",
"\t$(FC) $(RFLAGS) $(FFLAGS) $(LDFLAGS) $< -o $@", */

  "%",  /* 14 */
  "%.r",
  "+(FC)",
  "+(RFLAGS)",
  "+(FFLAGS)",
  "+(LDFLAGS)",
  "\t$(FC) $(RFLAGS) $(FFLAGS) $(LDFLAGS) %.r -o %",

/* ".F",
"\t$(FC) $(FFLAGS) $(LDFLAGS) $< -o $@", */

  "%",  /* 15 */
  "%.F",
  "+(FC)",
  "+(FFLAGS)",
  "+(LDFLAGS)",
  "\t$(FC) $(FFLAGS) $(LDFLAGS) %.F -o %",

/* ".f",
"\t$(FC) $(FFLAGS) $(LDFLAGS) $< -o $@", */

  "%",  /* 16 */
  "%.f",
  "+(FC)",
  "+(FFLAGS)",
  "+(LDFLAGS)",
  "\t$(FC) $(FFLAGS) $(LDFLAGS) %.f -o %",

/* ".p",
"\t$(PC) $(PFLAGS) $(LDFLAGS) $< -o $@", */

  "%",  /* 17 */
  "%.p",
  "+(PC)",
  "+(PFLAGS)",
  "+(LDFLAGS)",
  "\t$(PC) $(PFLAGS) $(LDFLAGS) %.p -o %",

/* ".mod",
"\t$(M2C) $(M2FLAGS) $(LDFLAGS) $< -e $@ -o $@", */

  "%",  /* 18 */
  "%.mod",
  "+(M2C)",
  "+(M2FLAGS)",
  "+(LDFLAGS)",
  "\t$(M2C) $(M2FLAGS) $(LDFLAGS) %.mod -e % -o %",

/* ".c",
"\t$(CC) $(CFLAGS) $(LDFLAGS) $< -o $@", */

  "%",  /* 19 */
  "%.c",
  "+(CC)",
  "+(CFLAGS)",
  "+(LDFLAGS)",
  "+(vflags)",
  "\t$(CC) $(CFLAGS) $(vflags) $(LDFLAGS) %.c -o %",

/* ".SUFFIXES:",
".o",".c",".c~",".mod",".mod~",".sym",".def",".def~",".p",".p~",".f",".f~",".F",".F~",".r",".r~",".y",".y~",".l",".l~",".s",".s~",".sh",".sh~",".h",".h~",
*/

"0"

};


add_stdrules()
{
  int i = 0;
  int j = 0;
  int k = 0;
  
  struct cmds *comm;

  while(strcmp(stdrules[i],"0") != 0)
      {
	if(stdrules[i][0] == '%')
	  {
	    if((stdruletab[k] = (struct rules *) malloc( sizeof(struct rules))) == (struct rules *) NIL)
	      errexit(10,"malloc");
	    stdruletab[k]->name = stdrules[i];
	    i++;
	  }
	if(stdrules[i][0] != '\t')
	  {
	    j = 0;
	    while ((stdrules[i][0] != '\t') &&
		   (stdrules[i][0] != '+') &&
		   (strcmp(stdrules[i],"0") != 0))
	      {
		stdruletab[k]->deplist[j] = stdrules[i];
		i++;
		j++;
	      }
	    stdruletab[k]->deplist[j] = NIL;
	  }
	if (stdrules[i][0] == '+')
	  {
	    j = 0;
	    while (stdrules[i][0] == '+')
	      {
		stdruletab[k]->heritage[j] = stdrules[i];
		i++;
		j++;
	      }
	    stdruletab[k]->heritage[j] = NIL;
	  }
	else
	  stdruletab[k]->heritage[0] = NIL;

	if (stdrules[i][0] == '\t')
	  {
	    if ((stdruletab[k]->cmdlist = (struct cmds *) malloc( sizeof (struct cmds))) == (struct cmds *) NIL)
	      errexit(10,"malloc");
	    comm = stdruletab[k]->cmdlist;
	    while (stdrules[i][0] == '\t')
	      {
		comm->command = stdrules[i];
		if ((comm = comm->nextcmd = (struct cmds *) malloc( sizeof (struct cmds *))) == (struct cmds *) NIL)
		  errexit(10,"malloc");
		i++;
	      }
	    stdruletab[k]->targetlist[0] = stdruletab[k]->name;
	    stdruletab[k]->targetlist[1] = NIL;
	  }
	k++;
      }
  stdruletab[k] = (struct rules *) NIL;
  lastrule = k - 1;
}

