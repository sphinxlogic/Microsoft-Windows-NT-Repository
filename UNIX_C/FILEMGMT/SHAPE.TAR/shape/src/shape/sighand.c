/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *RCSid = "$Header: sighand.c,v 3.1 89/02/20 16:26:46 wolfgang Exp $";
#endif
#ifndef lint
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	sighand.c,v $
 * Revision 3.1  89/02/20  16:26:46  wolfgang
 * NET-RELEASE
 * 
 * Revision 3.0  89/01/24  11:37:00  wolfgang
 * New System Generation
 * 
 * Revision 1.6  89/01/18  14:43:22  wolfgang
 * changes for lint
 * 
 * Revision 1.5  89/01/03  13:13:54  wolfgang
 * changes done for lint
 * 
 * Revision 1.4  88/12/21  15:13:02  wolfgang
 * changes done for lint
 * 
 * Revision 1.3  88/09/22  16:18:01  wolfgang
 * calls of shape_cleanup() added.
 * 
 * Revision 1.2  88/08/19  10:18:09  wolfgang
 * This version is part of a release
 * 
 */

#include <signal.h>
#include <stdio.h>
#include "shape.h"

extern int cleanup_links();
extern struct linkreg *link_reg;
extern int errexit();

catch_sigs () {
/*
 * Setup signal handlers for various signals. Previous handlers
 * are saved. On receipt of a signal, the 
 * original handler for this signal will be invoked after specified
 * action has been taken.
 */
#ifdef ULTRIX_2_0
void
#else
int
#endif
die1(), die2(), die3(), die4(), die5(), die6(), 
       die7(), die8(), die9(), die10(),
       die11(), die12(), die13(), die14(), die15();

  (void) signal (SIGINT, die2);
  (void) signal (SIGBUS, die10);
  (void) signal (SIGSEGV, die11);
  (void) signal (SIGFPE, die8);
  (void) signal (SIGTERM, die15);
}

#ifdef ULTRIX_2_0    
void
#endif
die2 () {
  (void) signal(SIGINT,SIG_IGN);
  errexit(23,"\0");
}

#ifdef ULTRIX_2_0    
void
#endif
die8 () {
  (void) signal(SIGINT,SIG_IGN);
  fprintf(stderr, "Oh! Oh! .... this was a floating exception -- goodbye.\n"); 
  af_cleanup ();
  cleanup_links(link_reg);
  exit (1);
}

#ifdef ULTRIX_2_0    
void
#endif
die10 () {
  fprintf(stderr, "Oh! Oh! .... this was a buserror -- goodbye.\n");
  fprintf(stderr, "Dumping core.\n");
  af_cleanup ();
  cleanup_links(link_reg);
  (void) kill (getpid(), SIGQUIT);
}

#ifdef ULTRIX_2_0    
void
#endif
die11 () {
  (void) signal(SIGINT,SIG_IGN);
  fprintf(stderr, 
	  "Oh! Oh! .... this was a segmentation violation -- goodbye.\n");
  fprintf(stderr, "Dumping core.\n");
  af_cleanup ();
  cleanup_links(link_reg);
  (void) kill (getpid(), SIGQUIT);
}

#ifdef ULTRIX_2_0    
void
#endif
die15 () {
  (void) signal(SIGINT,SIG_IGN);
  af_cleanup();
  cleanup_links(link_reg);
  exit(1);
}

