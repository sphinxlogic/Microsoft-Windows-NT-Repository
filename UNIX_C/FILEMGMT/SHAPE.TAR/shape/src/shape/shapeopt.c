/*
 * Copyright (C) 1989, 1990 W. Koch, A. Lampen, A. Mahler, W. Obst,
 *  and U. Pralle
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. We do not accept any liability for any kind of damage
 * caused by use of this software, such as loss of data, time, money, or 
 * effort.
 * 
 * Permission is granted to use, copy, modify, or distribute any part of
 * this software as long as this is done without asking for charge, and
 * provided that this copyright notice is retained as part of the source
 * files. You may charge a distribution fee for the physical act of
 * transferring a copy, and you may at your option offer warranty
 * protection in exchange for a fee.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 		     Wilfried Koch
 * 		     Sekr. FR 5-6 
 * 		     Franklinstr. 28/29
 * 		     D-1000 Berlin 10, West Germany
 * 
 * 		     Tel: +49-30-314-22972
 * 		     E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
#ifndef lint
static char *RCSid = "$Header: shapeopt.c,v 3.0 89/01/24 11:36:54 wolfgang Stable $";
#endif
#ifndef lint
static char *ConfFlg = CFFLGS;	/* should be defined from within Makefile */
#endif
/*
 * $Log:	shapeopt.c,v $
 * Revision 3.0  89/01/24  11:36:54  wolfgang
 * New System Generation
 * 
 * Revision 2.17  89/01/03  13:13:43  wolfgang
 * changes done for lint
 * 
 * Revision 2.16  88/12/19  13:20:51  wolfgang
 * h_force_option added.
 * 
 * Revision 2.15  88/11/24  12:08:31  wolfgang
 * Argument for -confid *must* now be a target name.
 * 
 * Revision 2.14  88/11/21  15:47:34  wolfgang
 * return code of all malloc's checked
 * 
 * Revision 2.13  88/11/08  19:26:24  wolfgang
 * -expandall & -expandnothing are not allowed at the same time
 * 
 * Revision 2.12  88/11/08  11:03:00  wolfgang
 * h_expandall_option & h_expandnothing_option added.
 * 
 * Revision 2.11  88/10/20  12:03:11  wolfgang
 * This version is part of a release
 * 
 * Revision 2.10  88/10/10  16:55:38  wolfgang
 * handling of -t option activated
 * 
 * Revision 2.9  88/10/03  12:53:54  wolfgang
 * undone last changes.
 * 
 * Revision 2.8  88/10/03  11:37:10  wolfgang
 * handling of the -R option changed: if an  unknown selection rule is
 * passed to shape, shape now stops.
 * 
 * Revision 2.7  88/09/22  10:03:18  wolfgang
 * bug fixed: -R option.
 * 
 * Revision 2.6  88/09/19  15:07:38  wolfgang
 * h_r_option changed to h_R_option.
 * 
 * Revision 2.5  88/08/23  16:36:57  wolfgang
 * To rebuild something from a confid the option -rebuild is added.
 * 
 * Revision 2.4  88/08/23  10:28:21  wolfgang
 * Changed the -Z option to -confid.
 * 
 * Revision 2.3  88/08/22  17:00:26  wolfgang
 * Initialization of confid added.
 * 
 * Revision 2.2  88/08/12  08:58:25  wolfgang
 * This version is part of a release
 * 
 */

#include "shape.h"
#include "ParseArgs.h"
char *version();
char *af_version();
char cfname[MAXNAMLEN];
char *forcelist[10];

extern int init_confid();
extern struct linked_list *shapefiles;
extern char ruleset[];
extern char rbtarg[];
extern int implicit_suffs[];

extern int h_d_option();
extern int h_e_option();
extern int h_f_option();
extern int h_force_option();
extern int h_h_option();
extern int h_i_option();
extern int h_k_option();
extern int h_log_option();
extern int h_m_option();
extern int h_n_option();
extern int h_p_option();
extern int h_q_option();
extern int h_r_option();
extern int h_R_option();
extern int h_s_option();
extern int h_S_option();
extern int h_t_option();
extern int h_v_option();
extern int h_b_option();
extern int h_V_option();
extern int h_confid_option();
extern int h_version_option();
extern int h_rebuild_option();
extern int h_expandall_option();
extern int h_expandnothing_option();
extern FILE *cmfopen();

OptDesc odesc[] = {
  { "d", OPT_IS_SWITCH,	h_d_option },
  { "e", OPT_IS_SWITCH,	h_e_option },
  { "f", OPT_HAS_ARG, h_f_option },
  { "force", OPT_HAS_ARG, h_force_option },
  { "h", OPT_IS_SWITCH,	h_h_option },
  { "i", OPT_IS_SWITCH,	h_i_option },
  { "k", OPT_IS_SWITCH,	h_k_option },
  { "log", OPT_IS_SWITCH, h_log_option },
  { "m", OPT_IS_SWITCH,	h_m_option },
  { "n", OPT_IS_SWITCH,	h_n_option },
  { "p", OPT_IS_SWITCH,	h_p_option },
  { "q", OPT_IS_SWITCH,	h_q_option },
  { "r", OPT_IS_SWITCH, h_r_option },
  { "R", OPT_HAS_ARG, h_R_option },
  { "s", OPT_IS_SWITCH,	h_s_option },
  { "S", OPT_IS_SWITCH,	h_S_option },
  { "t", OPT_IS_SWITCH,	h_t_option }, 
  { "v", OPT_HAS_ARG, h_v_option },
  { "V", OPT_HAS_ARG, h_V_option },
  { "version", OPT_IS_SWITCH, h_version_option },
  { "confid", OPT_HAS_ARG, h_confid_option },
  { "rebuild", OPT_HAS_ARG, h_rebuild_option },
  { "expandall", OPT_IS_SWITCH, h_expandall_option },
  { "expandnothing", OPT_IS_SWITCH, h_expandnothing_option },
  { "b", OPT_IS_SWITCH, h_b_option },
  { (char *) NULL, NULL, NULL }
};


int h_d_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  debugflg = TRUE;
  return(0);
}

int h_e_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  envflg = TRUE;
  return(0);
}

int h_f_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{

struct linked_list *shfiles;
if (!strcmp(arg,""))
  return(1);
fileflg = TRUE;
if (strcmp(arg,"-") == 0)
  stdinflg = TRUE;
else
  {
    if (shapefiles == (struct linked_list *) NIL)
      {
	if ((shapefiles = (struct linked_list *) malloc(sizeof(struct linked_list))) == (struct linked_list *) NIL)
	  errexit(10,"malloc");
	if ((shapefiles->string = malloc((unsigned) strlen(arg) + sizeof(char))) == NIL)
	  errexit(10,"malloc");
	(void) strcpy(shapefiles->string,arg);
	shapefiles->nextstring = (struct linked_list *) NIL;
      }
    else
      {
	shfiles = shapefiles;
	while( shfiles->nextstring != (struct linked_list *) NIL)
	  shfiles = shfiles->nextstring;
	
	if((shfiles->nextstring  = (struct linked_list *) malloc(sizeof(struct linked_list))) == (struct linked_list *) NIL)
	  errexit(10,"malloc");
	shfiles = shfiles->nextstring;
	if ((shfiles->string = malloc((unsigned) strlen(arg) + sizeof(char))) == NIL)
	  errexit(10,"malloc");
	(void) strcpy(shfiles->string, arg);
	shfiles->nextstring = (struct linked_list *) NIL;
      }
  }
  return(0);
}


int h_force_option(opt,arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  int i = 0;
  forceflg = TRUE;
  while(forcelist[i] != NIL)
    {
      if (i == 10)
	errexit(36, NIL);
      i++;
    }
  if ((forcelist[i] = malloc((unsigned) (strlen(arg) + sizeof(char)))) == NIL)
    errexit(10,"malloc");
  (void) strcpy(forcelist[i],arg);
  return (0);
}

int h_h_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  return(1);
}

int h_i_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  ignoreflg = TRUE;
  return(0);
}

int h_k_option(opt, arg)
     /*ARGSUSED*/
     char *opt; 
     char *arg;
{
  goflg = TRUE;
  return(0);
}

int h_log_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  logflg = TRUE;
  return(0);
}

int h_m_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  /* weiss ich nich */
  return(0);
}

int h_n_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  noexflg = TRUE;
  return(0);
}

int h_p_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  printflg = TRUE;
  return(0);
}

int h_q_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  questflg = TRUE;
  return(0);
}

int h_r_option(opt,arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  implicit_suffs[0] = -1;
  return(0);
}


int h_R_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  ruleflg = TRUE;
  (void) strcpy(ruleset,arg);
  return(0);
}

int h_s_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  silentflg = TRUE;
  return(0);
}

int h_S_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  goflg = FALSE;
  return(0);
}

int h_t_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  touchflg = TRUE;
  return(0);
}

int h_v_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
/*  variant = arg  ???? */;
  return(0);
}

int h_version_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  printf("shape - Version %s\n", version());
  printf("uses AFS: Version %s\n", af_version());
  exit(0);
}

int h_expandall_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  if (noexpflg)
    errexit(34,NIL);
  expflg = TRUE;
  return(0);
}

int h_expandnothing_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  if(expflg)
    errexit(34,NIL);
  noexpflg = TRUE;
  return(0);
}


int h_b_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
; /* because of compatibility; does nothing (i hope so ...) */
  return(0);
}

int h_V_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  /* set generation and revision (for shapefile) */


/*      case 'V':
	if ((ccc = index(optarg,'.')) == 0)
	  errexit(9, optarg);
	else
	  {
	    ccc[0] = '\0';
	    gen = atoi(optarg);
	    *ccc++;
	    rev = atoi(ccc);
	  }
	break;
      default:
	h[0] = c;
	h[1] = '\0';
	errexit( 2, h);  */
  return(0);

}

int h_confid_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
  if (!strcmp(arg,""))
    return(1);

  confid = TRUE;
  (void) strcpy(cfname,arg);
  (void) strcat(cfname,".cid");
  if ((cid = cmfopen(cfname,"w",AF_BUSYVERS, AF_BUSYVERS)) == (FILE *) NIL)
    errexit(12, cfname);
  init_confid(arg);
  (void) strcpy(cfname,arg);
  return(0);
}

int h_rebuild_option(opt, arg)
     /*ARGSUSED*/
     char *opt;
     char *arg;
{
char *p;
char fname[MAXNAMLEN];
(void) strcpy(fname,arg);

if((p = rindex(fname,'.')) == NIL)
  {
    (void) strcpy(rbrule,"@");
    (void) strcat(rbrule,fname);
    (void) strcpy(rbtarg,fname);
    (void) strcat(fname,".cid");
    (void) strcpy(rbfile,fname);
  }
else
  {
    (void) strcpy(rbfile,fname);
    *p = '\0';
    (void) strcpy(rbtarg,fname);
    (void) strcpy(rbrule,"@");
    (void) strcat(rbrule,fname);
  }

rebuildflg = TRUE;

return(0);

}
