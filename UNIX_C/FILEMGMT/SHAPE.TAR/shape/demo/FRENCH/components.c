/*
 * Copyright (C) 1988 Technische Universitaet Berlin
 * 
 * This is a pre-release !
 * 
 * This software is published on an as-is basis. There is ABSOLUTELY NO
 * WARRANTY for any part of this software to work correctly or as described
 * in the manuals. No responsibility or liability for any damage caused
 * by using this software.
 * 
 * No part of this software may be redistributed or used commercially by 
 * any means or in any form.
 * 
 * Direct questions to: Tech. Univ. Berlin
 * 			Wilfried Koch
 * 			Sekr. FR 5-6 
 * 			Franklinstr. 28/29
 * 			D-1000 Berlin 10, West Germany
 * 
 * 			Tel: +49-30-314-22972
 * 			E-mail: shape@coma.uucp or shape@db0tui62.bitnet
 */
components()
{
#ifdef DEBUG
printf("components avec DEBUG\n");
#endif DEBUG

printf("$__name$.$__type$[$__version$]\n\n");  
printf("\n");
printf("Fonctions du shape-toolkit\n");
printf("\n");
printf(" - Controle des versions\n");
printf("      save, Save / retrv\n");
printf("      vl, vcat, vinfo, vlog, vadm\n");
printf(" - Soutien de projet\n");
printf("      reserve / submit\n");
printf("      accept / reject\n");
printf(" - Composition des systeme\n");
printf("      shape\n");
}

