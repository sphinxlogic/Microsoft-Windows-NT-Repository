/*
 *  Prototype version procedure
 */
char *$__name () { 
  static char ConfID[] =  "$__version ($__stime by $__auuid$)";
  return ConfID;
}
