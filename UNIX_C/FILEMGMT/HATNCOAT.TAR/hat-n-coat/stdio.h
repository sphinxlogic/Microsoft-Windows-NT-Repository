/*
** Little trick to get token codes into lex.  lex.yy.c includes "stdio.h".
** in here we define everything needed that can't be indented ahead of the
** lex script %%, and pick up the "real" stdio.h via <stdio.h>
*/

#include <stdio.h>
#include "y.tab.h"
#include "config.h"

#define MYPUTS(S) if (Outflag) fputs(S,stdout)

#define SQRET(X) if (!Squelch) return(Verbosity > 4 ? tok_out(X) : X)
