#include <stdio.h>

/*
** strtok() is a routine present in SYSV and some BSD runtime libraries.
** Use this if it isn't in yours.
*/

static char *Save=NULL;

char *index ();
static char *first_ch (), *last_ch();

char *
strtok(str,delim)
char *str, *delim;
{
	register char *tokstart, *tokend;

	if (str != NULL)
		Save = str;

	if (Save == NULL)
		return (NULL);

	tokstart = first_ch (Save, delim);
	tokend = last_ch (tokstart, delim);
	Save = first_ch (tokend, delim);
	*tokend = '\0';

	if (*tokstart == '\0')
		return (NULL);

	return (tokstart);
}

static char *
first_ch (str,delim)
char *str;
register char *delim;
{
	register char *f;

	for (f = str; *f != '\0' && index(delim,*f) != NULL; ++f)
		;

	return (f);
}

static char *
last_ch (str,delim)
char *str;
register char *delim;
{
	register char *f;

	for (f = str; *f != '\0' && index(delim,*f) == NULL; ++f)
		;

	return (f);
}
