/*
**  This file records official patches.  RCS records the edit log.
**
**  $Log:	patchlevel.h,v $
**  Revision 2.0  88/05/27  13:32:13  rsalz
**  First comp.sources.unix release
**  
**  
*/
#define PATCHLEVEL 0
