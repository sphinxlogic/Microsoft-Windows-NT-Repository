/* CHK=0x4BC6 */
/*+-----------------------------------------------------------------------
	libuxlst.h
------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:10-28-1988-14:47-afterlint-creation */

#ifndef BUILDING_LINT_ARGS
#ifdef LINT_ARGS

/* libuxlst.c */
void uxlst_error(int );
void uxlst_read(void);

#else		/* compiler doesn't know about prototyping */

/* libuxlst.c */
void uxlst_error();
void uxlst_read();

#endif /* LINT_ARGS */
#endif /* BUILDING_LINT_ARGS */

/* end of libuxlst.h */
