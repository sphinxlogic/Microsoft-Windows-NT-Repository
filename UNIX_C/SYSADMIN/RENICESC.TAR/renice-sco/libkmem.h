/* CHK=0x3FE9 */
/*+-----------------------------------------------------------------------
	libkmem.h
------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:10-28-1988-14:46-afterlint-creation */

#ifndef BUILDING_LINT_ARGS
#ifdef LINT_ARGS

/* libkmem.c */
void kinit(int );
void kread(char  *,long ,long );
void kwrite(long ,char  *,long );

#else		/* compiler doesn't know about prototyping */

/* libkmem.c */
void kinit();
void kread();
void kwrite();

#endif /* LINT_ARGS */
#endif /* BUILDING_LINT_ARGS */

/* end of libkmem.h */
