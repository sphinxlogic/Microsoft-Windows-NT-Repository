/*
 * csh_hog.c: intercept "csh" and check for diskhog tags first
 */
 
#include "diskhog.h"
#include <sys/types.h>
#include <sys/stat.h>
char *getenv();

main(argc, argv)
char **argv;
{
	char *who = getenv(LOGNAME), cmd[64], fname[64];
	struct stat s;
	argv[argc] = 0;
	sprintf(fname, "%s/hogs/%s", DQUOTAS, who);
	sprintf(cmd, "%s/diskhog", BIN);
	if(stat(fname, &s) != -1) system(cmd);
	execv("/etc/csh", argv);
}
	
