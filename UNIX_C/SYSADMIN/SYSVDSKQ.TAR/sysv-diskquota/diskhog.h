#define DQUOTAS "/usr/local/lib/disk"
#define BIN "/usr/local/bin"
