/*
 * nohog.c: remove diskhog tag from /etc/hogs directory
 *
 * find out who the user is, and then remove the tag from the hogs directory.
 *
 * It's supposed to be proof against fraud, though I wouldn't care to put
 * any money on it.
 *
 * runs suid root, so that the user can't just 'rm' the file.
 *
 * This program should NOT be accessible to diskhogs running the "diskhog"
 * shell - i.e. don't link it to /diskhog or /usr/diskhog
 */
#include <sys/types.h> 
#include <utmp.h>
#include <stdio.h>

#include "diskhog.h"
char *ttyname(); 
struct utmp *getutline();

main(){
	char *p;
	struct utmp *utmp, mine;
	int prefix = sizeof "/dev/";
	chdir(DQUOTAS);
	chdir("hogs");
	p = ttyname(fileno(stderr));		/* find tty device */
	strcpy(mine.ut_line, p + 5);
	if(utmp = getutline(&mine))
		unlink(utmp->ut_user);
	else printf("who are you?\n");
	return(0);
}
