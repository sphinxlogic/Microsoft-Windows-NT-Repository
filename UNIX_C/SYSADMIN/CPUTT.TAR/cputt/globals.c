# include       "cputt.h"
# include       "kvm.h"

struct info                     Info ; /* System Addresses and Info */

kvm_t                          *Flkvm; /* Descriptor for Kernel Memory */

union  userstate                User;  /* Structure to Hold Upages */

struct symbol   Symbollist[] =         /* Symbols to Lookup */
{
     { "_proc",      1,  (caddr_t*)&Info.i_proc0,    (char*)0        },
     { "_nproc",     1,  (caddr_t*)&Info.i_nproc,    (char*)0        },
     { "_maxmem",    1,  (caddr_t*)&Info.i_ecmx,     (char*)0        },
     { (char*)0,     0,  (caddr_t*)0,                (char*)0        }
};
