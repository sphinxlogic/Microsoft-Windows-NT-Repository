# include     <sys/param.h>
# include     <sys/user.h>
# include     <sys/proc.h>

# define MAXUSERS       300 /* set this to (length of /etc/passwd * 2) */
# define MAXACTIVE       50 /* max cpu-positive processes per interval */
# define MAXOUT          10 /* output is limitted to this many processes */
# define COMMAND_SIZE    51 /* set this to (width of your window - 29) */
# define UNAMELEN         8 /* max length for username */

/*
   cputt attempts to truncate unused slots at the end of the process
   table.  This usually reduces its runtime size considerably.  If the
   process table grows or shrinks by a significant amount, cputt will
   restart itself and resize its internal data structures accordingly.
*/

# define GROWTH_BUF      40 /* growth buffer, use 0 to disable truncation */
# define MAX_GROW        20 /* restart after proc table grows this much */
# define MAX_SHRINK      10 /* restart after proc table shrinks this much */

/* info concerning a symbol table entry */

struct symbol
{
     char          *s_kname;      /* kernel symbol name */
     char           s_indirect;   /* value requires indirection */
     caddr_t       *s_info;       /* corresponding info address */
     char          *s_wait;       /* reason for wait, if any */
};

/* single hash table entry for mapping uid's to usernames */

struct hashtab
{
     short          h_uid ;               /* uid of user entry */
     char           h_uname[ UNAMELEN ] ; /* corresponding name */
};

/* critical system info */

struct info
{
     struct proc   *i_proc0;               /* address of process table */
     int            i_nproc;               /* length of process table */
     int            i_sproc;               /* size of process table */
     int            i_ecmx;                /* max physical memory address*/
     struct hashtab i_hnames[MAXUSERS];    /* hash table for usernames */
};

/* for reading process upages from kernel memory */

union userstate
{
     struct user     u_us ;
     char            u_pg[ UPAGES ][ NBPG ] ;
};

/* summary info for processes with positive cpu utilization */

struct procdata
{
     struct proc    *proc;         /* proc structure */
     long            pctcpu;       /* cpu usage */
     int             pr_cmd;       /* command string index */
};
