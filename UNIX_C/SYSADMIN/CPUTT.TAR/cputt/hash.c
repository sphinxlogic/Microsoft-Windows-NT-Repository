# include       "cputt.h"
# include       <pwd.h>

# define        HASHFN1( a ) (((unsigned)(a)*91 + 17) % MAXUSERS)

/*
   HASHUID - Returns a pointer to a slot in the hash table that corresponds
   to the hash table entry for `uid'. It returns a null pointer if there is
   no such slot.
*/

struct hashtab  *hashuid ( uid )

int    uid ;

{
     struct hashtab *hp ;
     extern struct info      Info ;

     hp = &Info.i_hnames[ HASHFN1( uid ) ];
     if ( hp->h_uid == uid )
          return ( hp ) ;
     return ( (struct hashtab*)0 ) ;
}

/*
   INITUSERS - builds the uid hash table.
*/

initusers ()
{
     struct passwd  *pw ;
     struct hashtab *hp ;
     struct passwd  *getpwent() ;

     while ( pw = getpwent() )
     {
          /* Try to find a free slot in the hash table and fill it. */

          hp = &Info.i_hnames[ HASHFN1(pw->pw_uid) ];
          if ( !hp->h_uname[0] )
          {
               hp->h_uid = pw->pw_uid ;
               strncpy( hp->h_uname, pw->pw_name, UNAMELEN );
          }
     }
     endpwent() ;
}
