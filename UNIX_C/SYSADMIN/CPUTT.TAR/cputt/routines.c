# include       "cputt.h"
# include       <varargs.h>
# include       <kvm.h>
# include       <stdio.h>

/*
   GETUPAGE - Reads the upage for the specified process as well as sufficient
   page tables entries for reading the command arguments. The pte's are read
   into the argument `p'. The upage is read into the external variable
   `User'. Returns 1 if the upage was successfully read.
*/

getupage ( p )

register struct proc        *p ;

{
     struct user            *upage ;
     extern union userstate  User ;
     extern kvm_t           *Flkvm ;

     if (upage = kvm_getu( Flkvm, p ))
     {
          bcopy( (char *)upage, User.u_pg[0], sizeof( struct user ) ) ;
          return ( 1 ) ;
     }
/*
     fprintf( stderr, "cputt - Can't read upage of process %d s= %o f= %o\n",
              p->p_pid, p->p_stat, p->p_flag ) ;
*/
     return ( 0 ) ;
}

/* READSTATUS - Reads process table from kernel memory */

readstatus ( ptable )

struct proc *ptable;

{
     extern struct info      Info ;

     if (getkmem((long)Info.i_proc0,(char*)ptable,Info.i_sproc) != Info.i_sproc)
     {
          fprintf(stderr,"cputt - Can't read system process table\n" ) ;
          exit();
     }
}

/* PERCENTMEM - Returns the percentage of real memory used by this process */

double  percentmem ( p )

struct proc         *p ;

{
     double                  fracmem ;
     extern struct info      Info ;

     if ( !(p->p_flag & SLOAD) )
          return ( 0.0 ) ;
     fracmem = ( (double)p->p_rssize + UPAGES ) ;
     return ( 100.0 * fracmem / (double)Info.i_ecmx ) ;
}

/* GETKMEM - read kernel memory */

getkmem ( addr, buf, bufsize )

long                            addr ;
char                            *buf ;
int                             bufsize ;
{
     extern kvm_t            *Flkvm ;

     return( kvm_read( Flkvm, (long)addr, buf, bufsize ) ) ;
}

/* SYSPERROR - Reports a system defined error msg and then exits gracefully */

sysperror ()
{
     extern int              errno ;
     extern int              sys_nerr ;
     extern char             *sys_errlist[] ;

     if ( 0 < errno && errno < sys_nerr )
          fprintf( stderr, " : %s", sys_errlist[errno] ) ;
     (void)fputc( '\n', stderr ) ;
     exit( 1 ) ;
}

/* GETCORE - Allocate and return a pointer to the asked for amount of core */

char    *getcore ( size )

register int                    size ;

{
     register char           *chp ;
     char                    *malloc() ;

     if ( chp = malloc( (unsigned)size ) )
          return ( chp ) ;
     fprintf( stderr, "cputt - Out of core" ) ;
     sysperror() ;
}

/* CMP - used by qsort() to perform comparisons */

int cmp(p1,p2)

register struct procdata *p1, *p2;

{
     return (p1->pctcpu - p2->pctcpu);
}   
