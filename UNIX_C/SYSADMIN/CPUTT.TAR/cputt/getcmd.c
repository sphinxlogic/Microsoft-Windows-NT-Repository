# include       "cputt.h"
# include       <kvm.h>

/* GETCMD - gets the command string for process p and copies it to argbuf */

getcmd ( p, argbuf )

struct   proc      *p;
register char      *argbuf;

{
     register char           *cp,**ap ;
     char                    **argv ;
     register int            sp=-1;
     extern kvm_t            *Flkvm ;
     extern union userstate  User ;

     if (!p->p_pid)
        { strcpy(&argbuf[0],"Swapper"); return; }
     if (p->p_pid == 2)
        { strcpy(&argbuf[0],"Pager"); return; }

     if (kvm_getcmd(Flkvm,p,&User.u_us,&argv,(char ***)NULL)<0||argv==NULL)
     {
         argbuf[0] = '(';
         strncpy(&argbuf[1],User.u_us.u_comm,sizeof(User.u_us.u_comm));
         argbuf[sizeof(User.u_us.u_comm)+1] = '\0';
         strcat(argbuf, ")" ) ;
     }
     else
     {
         ap = argv;
         while (*ap && sp < COMMAND_SIZE-1)
         {
             for (cp = *ap++; *cp && sp < COMMAND_SIZE-2;)
                  argbuf[++sp] = *cp++;
             argbuf[++sp] = ' ';
         }
         argbuf[sp] = '\0';
         free(argv);
     }
}
