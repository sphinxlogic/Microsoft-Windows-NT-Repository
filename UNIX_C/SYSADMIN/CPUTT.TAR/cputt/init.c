# include       "cputt.h"
# include       <sys/file.h>
# include       <kvm.h>
# include       <nlist.h>
# include       <stdio.h>

/*
   INIT - Reads the kernel's symbol table for critical system
   information and stores this information in the Symbollist array.
*/

init ()
{
     register struct nlist   *np ;
     register struct symbol  *s ;
     register struct nlist   *np0 ;
     extern kvm_t            *Flkvm ;
     extern struct symbol     Symbollist[] ;
     extern struct info       Info ;
     char                    *getcore() ;

     /* find length of the list of desired symbols */

     for ( s = Symbollist ; s->s_kname ; s++ )
          ;
     /* allocate core for nlist array */

     np0 = (struct nlist*)getcore( (s-Symbollist+1)*sizeof( struct nlist ));

     /* initialize nlist array */

     for ( s = Symbollist, np = np0 ; s->s_kname ; s++, np++ )
     {
          np->n_name = s->s_kname ;
          np[1].n_name = (char*)0 ;
          np->n_value = 0 ;
     }

     /* read symbols from symbol table into nlist array */

     if ( kvm_nlist( Flkvm, np0 ) == -1 )
     {
          fprintf( stderr, "sps - Can't read symbol file \n");
          sysperror() ;
     }

     /* derive system info from nlist and store in Symbollist */

     for ( s = Symbollist, np = np0 ; s->s_kname ; s++, np++ )
     {                                       
          if ( !np->n_value )             
          {
              fprintf( stderr, "sps - Can't find symbol %s in %s", np->n_name);
              *s->s_info = (caddr_t)0 ;
              continue ;
          }

          /* If no indirection is required, just copy the obtained value
             into the `Info' structure. */

          if ( !s->s_indirect )           
          {                               
               *s->s_info = (caddr_t)np->n_value ;
               continue ;              
          }                               

          /* Otherwise one level of indirection is required. Using the
             obtained address, look again in the kernel for the value */

          (void)getkmem((long)np->n_value, (char*)s->s_info, sizeof(caddr_t));
     }
     free( (char*)np0 ) ;
}
