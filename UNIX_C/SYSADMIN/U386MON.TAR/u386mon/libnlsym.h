/*+-----------------------------------------------------------------------
	libnlsym.h
	...!{gatech,emory}!n4hgf!wht
------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:06-27-1990-01:57-wht@n4hgf-1.10-incorporate suggestions from alpha testers */
/*:06-25-1990-04:14-wht@n4hgf-1.02-better error handling */
/*:06-24-1990-20:53-wht@n4hgf-v1.01-add ISC support thanks to peter@radig.de */
/*:06-21-1990-14:26-r@n4hgf-version x0.12 seems bug free */
/*:10-28-1988-14:47-afterlint-creation */

#ifndef BUILDING_LINT_ARGS
#ifdef LINT_ARGS

/* libnlsym.c */
void nlsym_error(char * );
void nlsym_read(void);

#else		/* compiler doesn't know about prototyping */

/* libnlsym.c */
void nlsym_error();
void nlsym_read();

#endif /* LINT_ARGS */
#endif /* BUILDING_LINT_ARGS */

/* end of libnlsym.h */
