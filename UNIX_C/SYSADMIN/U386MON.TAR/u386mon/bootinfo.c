/*+-------------------------------------------------------------------------
	bootinfo.c - u386mon bootinfo struct display

  Defined functions:
	bmemf_text(flags)
	display_bootinfo(win,y,x)

We try to be dynamic with memory block counts, but if the sum of
memavailcnt and memusedcnt ever exceeds 7, we will lose in 24 line
sessions (8 in 25 line, 9 in 43 line)


--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:35-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:07-11-1990-17:19-root@n4hgf-more input from trb@ima.ima.isc.com */
/*:07-04-1990-01:28-root@n4hgf-alan@cms2.lonestar.org reported missing M_ */
/*:06-27-1990-01:57-wht@n4hgf-1.10-incorporate suggestions from alpha testers */
/*:06-25-1990-04:14-wht@n4hgf-1.02-better error handling */
/*:06-25-1990-03:18-wht@n4hgf-ODT/3.2.1 has B_MEM_CANTDMA not B_MEM_NODMA */
/*:06-24-1990-20:53-wht@n4hgf-v1.01-add ISC support thanks to peter@radig.de */
/*:06-21-1990-14:26-r@n4hgf-version x0.12 seems bug free */
/*:06-17-1990-14:59-wht-creation */

#include "config.h"
#if defined(HAS_BOOTINFO)
#define M_TERMINFO
#include <curses.h>
#undef timeout /* conflict in curses.h and bootinfo.h per trb@ima.ima.isc.com */
#undef reg     /* per nba@sysware.sysware.dk */
#ifdef NATIVE_PANELS
# include <panel.h>
#else
# include "libpanel.h"
#endif
#include <sys/types.h>
#include <sys/bootinfo.h>
#include "u386mon.h"

/*+-------------------------------------------------------------------------
	bmemf_text(flags)
--------------------------------------------------------------------------*/
char *
bmemf_text(flags)
ulong flags;
{
static char hex_errant[16];
ulong orig_flags = flags;

#if defined(B_MEM_DOWN)		/* SCO only */
	flags &= ~B_MEM_DOWN;
#endif
#if defined(B_MEM_BASE)		/* ISC only (or is it SVR3.2.2?) */
	flags &= ~B_MEM_BASE;
#endif
#if defined(B_MEM_EXPANS)	/* ISC */
	flags &= ~B_MEM_EXPANS;
#endif
#if defined(B_MEM_SHADOW)	/* ISC */
	flags &= ~B_MEM_SHADOW;
#endif
#if defined(B_MEM_TREV)		/* ISC */
	flags &= ~B_MEM_TREV;
#endif

	if(!flags)
		return("    ");
	switch(flags)
	{
#if defined(B_MEM_RSRVD)
		case B_MEM_RSRVD: return("RSVD");
#endif
#if defined(B_MEM_KBSS)
		case B_MEM_KBSS:  return("KBSS");
#endif
#if defined(B_MEM_KTEXT)
		case B_MEM_KTEXT: return("KTXT");
#endif
#if defined(B_MEM_KDATA)
		case B_MEM_KDATA: return("KDTA");
#endif
#if defined(B_MEM_NODMA)
		case B_MEM_NODMA: return("NODM");
#endif
#if defined(B_MEM_CANTDMA)
		case B_MEM_CANTDMA: return("NODM");
#endif
	}
	sprintf(hex_errant,"%04x",(ushort)orig_flags);
	return(hex_errant);
}	/* end of bmemf_text */

/*+-------------------------------------------------------------------------
	ISC_machinetype_text(machine)
--------------------------------------------------------------------------*/
#if defined(ME_COMPAQVGA)	/* ISC machdep.h */
char *
ISC_machinetype_text(machine)
unsigned char machine;
{
	switch(machine)
	{
#if defined(M_UNKNOWN)	/* some ISC bootinfo.h do not have these */
		case M_UNKNOWN:
			return("");
			break;
#endif
#if defined(M_COMPAQ)
		case M_COMPAQ:
			return("Compaq");
			break;
#endif
#if defined(M_PS2)
		case M_PS2:
			return("PS/2");
			break;
#endif
#if defined(M_AT)
		case M_AT:
			return("Generic 386");
			break;
#endif
#if defined(M_ATT)
		case M_ATT:
			return("AT&T 6386");
			break;
#endif
#if defined(M_ATT5)
		case M_ATT5:
			return("AT&T 6386");
			break;
#endif
#if defined(M_M380)
		case M_M380:
			return("Olivetti M380");
			break;
#endif
#if defined(M_DELL)
		case M_DELL:
			return("Dell 386");
			break;
#endif
#if defined(M_D325)
		case M_D325:
			return("Dell 325");
			break;
#endif
#if defined(M_ALR)
		case M_ALR:
			return("Adv Logic Res");
			break;
#endif
#if defined(M_ZDS)
		case M_ZDS:
			return("Zenith Data");
			break;
#endif
	}
	return("i386");
}	/* end of ISC_machinetype_text */
#endif

/*+-------------------------------------------------------------------------
	ISC_displaytype_text(adapter)
--------------------------------------------------------------------------*/
#if defined(ME_COMPAQVGA)	/* ISC machdep.h */
char *
ISC_displaytype_text(adapter)
unsigned char adapter;
{

	switch(adapter)
	{
		case ME_UNKNOWN:
			return("unknown to sys");
			break;
		case ME_EGA:
			return("EGA");
			break;
		case ME_CGA80:
			return("CGA");
			break;
		case ME_MONO:
			return("MONO");
			break;
		case ME_COMPAQHR:
			return("Compaq mono");
			break;
		case ME_Z449:
			return("Zenith Z449");
			break;
		case ME_T5100:
			return("Toshiba T5100");
			break;
		case ME_COMPAQVGA:
			return("Compaq VGA");
			break;
		case ME_OTHERVGA:
			return("VGA");
			break;
#if defined(ME_PVGA1)
		case ME_PVGA1:
			return("Paradise VGA1");
			break;
#endif /*ME_PVGA1*/
#if defined(ME_V7VGA)
		case ME_V7VGA:
			return("Video 7 VGA");
			break;
#endif /*ME_V7VGA*/
	}
	return("???");
}	/* end of ISC_displaytype_text */
#endif

/*+-------------------------------------------------------------------------
	display_bootinfo(win,y,x)
--------------------------------------------------------------------------*/
void
display_bootinfo(win,y,x)
WINDOW *win;
int y;
int x;
{
register itmp;
register struct bootmem *bmem;

	use_cp(win,cpBANNER);
	wmove(win,y++,x);
	waddstr(win,"-- Bootinfo ----------");
#if defined(M_UNIX)	/* ISC doesn't have this in struct */
	wmove(win,y++,x);
	disp_static_long(win,"basemem  ","%7ldk     ",bootinfo.basemem / 1024);
	wmove(win,y++,x);
	disp_static_long(win,"extmem   ","%7ldk     ",bootinfo.extmem / 1024);
#endif
#if defined(ME_COMPAQVGA)	/* ISC machdep.h */
	wmove(win,y++,x);
	wprintw(win,"machine %14.14s",
		ISC_machinetype_text(bootinfo.machenv.machine));
	wmove(win,y++,x);
	wprintw(win,"disp %17.17s",
		ISC_displaytype_text(bootinfo.machenv.adapter));
#endif
	wmove(win,y++,x);
	disp_static_long(win,"bflags   ","%08lx     ",bootinfo.bootflags);

	wmove(win,y++,x); waddstr(win,"memory available      ");
	for(itmp = 0; itmp < bootinfo.memavailcnt; itmp++)
	{
		bmem = &bootinfo.memavail[itmp];
#if defined(B_MEM_DOWN)
		if(bmem->flags & B_MEM_DOWN)
		{
			bmem->base -= bmem->extent;
			bmem->flags &= ~B_MEM_DOWN;
		}
#endif
		wmove(win,y++,x);
		wprintw(win,"%08lx %08lx %s",bmem->base,bmem->extent,
			bmemf_text(bmem->flags));
	}

	wmove(win,y++,x); waddstr(win,"memory used           ");
	for(itmp = 0; itmp < bootinfo.memusedcnt; itmp++)
	{
		bmem = &bootinfo.memused[itmp];
#if defined(B_MEM_DOWN)
		if(bmem->flags & B_MEM_DOWN)
		{
			bmem->base -= bmem->extent;
			bmem->flags &= ~B_MEM_DOWN;
		}
#endif
		wmove(win,y++,x);
		wprintw(win,"%08lx %08lx %s",bmem->base,bmem->extent,
			bmemf_text(bmem->flags));
	}

}	/* end of display_bootinfo */

#endif /* HAS_BOOTINFO */
/* vi: set tabstop=4 shiftwidth=4: */
/* end of bootinfo.c */
