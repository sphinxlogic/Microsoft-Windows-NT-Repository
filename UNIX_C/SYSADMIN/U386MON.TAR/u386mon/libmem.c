/*LINTLIBRARY*/
/*+-------------------------------------------------------------------------
	libmem.c -- /dev/mem routines for SCO UNIX/386 (maybe other *NIX)
	...!{gatech,emory}!n4hgf!wht

  Defined functions:
	minit(write_needed)
	mread(caddr,maddr,len)
	mwrite(maddr,caddr,len)

 routines were originally written by Mike "Ford" Ditto: kudos!!!
--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:06-27-1990-01:57-wht@n4hgf-1.10-incorporate suggestions from alpha testers */
/*:06-25-1990-04:14-wht@n4hgf-1.02-better error handling */
/*:06-24-1990-20:53-wht@n4hgf-v1.01-add ISC support thanks to peter@radig.de */
/*:06-21-1990-14:26-r@n4hgf-version x0.12 seems bug free */
/*:12-07-1988-22:06-wht-put in test for initialized fdmem */
/*:10-27-1988-22:44-wht-creation of file */

#include <sys/types.h>
#include <fcntl.h>
#include "libmem.h"

void leave_text();

extern int errno;

static int fdmem = -2;
daddr_t lseek();

/*+-------------------------------------------------------------------------
	minit(write_needed)
--------------------------------------------------------------------------*/
void
minit(write_needed)
int write_needed;
{
	if(fdmem >= 0)
		return;
	if((fdmem=open("/dev/mem",(write_needed) ? O_RDWR : O_RDONLY,0)) < 0)
		leave_text("can't open /dev/mem",255);

}	/* end of minit */

/*+-------------------------------------------------------------------------
	mread(caddr,maddr,len)
--------------------------------------------------------------------------*/
void
mread(caddr,maddr,len)
caddr_t caddr;
daddr_t maddr;
int len;
{
char s80[80];
extern daddr_t myreadlen;
extern int myreadcnt;

#if defined(M_I286)
	maddr &= 0xFFFFL;
#endif

	if(fdmem == -2)
		leave_text("minit() not called",1);

	if(lseek(fdmem,maddr,0) == -1L)
	{
		(void)sprintf(s80,"mem seek err (%08lx)",maddr);
		leave_text(s80,1);
	}

	if(read(fdmem,caddr,len) != len)
	{
		(void)sprintf(s80,
			"mem read errno %d len %d addr %08lx",errno,len,maddr);
		leave_text(s80,1);
	}
	myreadlen += len;
	myreadcnt++;
}	/* end of mread */

/*+-------------------------------------------------------------------------
	mwrite(maddr,caddr,len)
--------------------------------------------------------------------------*/
#ifdef MWRITE_NEEDED
void
mwrite(maddr,caddr,len)
daddr_t maddr;
caddr_t caddr;
int len;
{
char s80[80];

#if defined(M_I286)
	maddr &= 0xFFFFL;
#endif

	if(fdmem == -2)
		leave_text("minit() not called",1);

	if(lseek(fdkmem,kaddr,0) == -1L)
	{
		(void)sprintf(s80,
			"/dev/kmem seek error addr %08lx",kaddr);
		leave_text(s80,255);
	}
	if(write(fdkmem,caddr,len) != len)
	{
		(void)sprintf(s80,
			"/dev/kmem write error addr %08lx len %08lx",kaddr,len);
		leave_text(s80,255);
	}
}	/* end of mwrite */
#endif /* MWRITE_NEEDED */

/* vi: set tabstop=4 shiftwidth=4: */
