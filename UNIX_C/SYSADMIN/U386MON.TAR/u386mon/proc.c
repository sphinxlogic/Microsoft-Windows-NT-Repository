/*+-------------------------------------------------------------------------
	proc.c - u386mon proc table functions

  Defined functions:
	display_proc(win,y,x)
	grok_proc()
	pstat_text(pstat)

--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:07-11-1990-03:45-root@n4hgf-faster proc table manipulation */
/*:06-27-1990-01:57-wht@n4hgf-1.10-incorporate suggestions from alpha testers */
/*:06-25-1990-04:14-wht@n4hgf-1.02-better error handling */
/*:06-24-1990-20:53-wht@n4hgf-v1.01-add ISC support thanks to peter@radig.de */
/*:06-21-1990-14:26-r@n4hgf-version x0.12 seems bug free */
/*:06-17-1990-16:46-wht-creation */

#include "config.h"
#define M_TERMINFO
#include <curses.h>
#undef reg     /* per nba@sysware.sysware.dk */
#ifdef NATIVE_PANELS
# include <panel.h>
#else
# include "libpanel.h"
#endif
#include <sys/types.h>
#undef NGROUPS_MAX
#undef NULL
#include <sys/param.h>
#include <sys/immu.h>
#include <sys/region.h>
#if defined(mips)
#include <sys/sbd.h>
#endif
#include <sys/proc.h>
#include <sys/var.h>
#include <nlist.h>
#include "nlsym.h"
#include "libkmem.h"
#include "libnlsym.h"
#include "u386mon.h"

extern struct var v;

struct proc *procs = (struct proc *)0;
struct proc *oldprocs = (struct proc *)0;
struct proc **pprocs = (struct proc **)0;
struct proc **poldprocs = (struct proc **)0;

int procs_per_pstat[SXBRK + 1];
int procs_in_core;
int procs_alive;

/*+-------------------------------------------------------------------------
	pstat_text(pstat)
--------------------------------------------------------------------------*/
char *
pstat_text(pstat)
char pstat;
{
static char errant[10];

	switch(pstat)
	{
		case SSLEEP:   return("sleep ");
		case SRUN:     return("run   ");
		case SZOMB:    return("zombie");
		case SSTOP:    return("stop  ");
		case SIDL:     return("idle  ");
		case SONPROC:  return("onproc");
		case SXBRK:    return("xbrk  ");
	}
	(void)sprintf(errant,"%06u?",(unsigned char)pstat);
	return(errant);

}	/* end of pstat_text */

/*+-------------------------------------------------------------------------
	grok_proc() - read and examine kernel process table
--------------------------------------------------------------------------*/
void
grok_proc()
{
register iproc;
register struct proc *tproc;
static char *memfail = "cannot alloc memory for proc table";

	if(!procs)
	{
		if(!(procs = (struct proc *)malloc(sizeof(struct proc) * v.v_proc)))
			leave_text(memfail,1);
		if(!(oldprocs = (struct proc *)malloc(sizeof(struct proc) * v.v_proc)))
			leave_text(memfail,1);
		if(!(pprocs = (struct proc **)malloc(sizeof(struct proc *) * v.v_proc)))
			leave_text(memfail,1);
		if(!(poldprocs=(struct proc **)malloc(sizeof(struct proc *)*v.v_proc)))
			leave_text(memfail,1);
	}
	kread((caddr_t)procs,procaddr,sizeof(struct proc) * v.v_proc);
	for(iproc = 0; iproc < SXBRK + 1; iproc++)
		procs_per_pstat[iproc] = 0;
	procs_in_core = 0;
	procs_alive = 0;

	for(iproc = 0; iproc < v.v_proc; iproc++)
	{
		tproc = pprocs[iproc] = (procs + iproc);

		if(tproc->p_stat)
			procs_alive++;

		procs_per_pstat[tproc->p_stat]++;	/* count # procs in each state */

		if(tproc->p_flag & SLOAD)			/* count # procs in memory */
			procs_in_core++;
	}

}	/* end of grok_proc */

/*+-------------------------------------------------------------------------
	display_proc(win,y,x)
--------------------------------------------------------------------------*/
void
display_proc(win,y,x)
WINDOW *win;
int y;
int x;
{
register istat;

	grok_proc();

	use_cp(win,cpBANNER);
	wmove(win,y++,x);
	waddstr(win,"-- Proc ---");
	for(istat = SSLEEP; istat <= SXBRK; istat++)
	{
		wmove(win,y++,x);
		disp_info_int(win,pstat_text(istat),"  %3d",procs_per_pstat[istat]);
	}
	wmove(win,y++,x);
	disp_info_int(win,"total ","  %3d",procs_alive);
	wmove(win,y++,x);
	disp_info_int(win,"in mem","  %3d",procs_in_core);
}	/* end of display_proc */

/* vi: set tabstop=4 shiftwidth=4: */
/* end of proc.c */
