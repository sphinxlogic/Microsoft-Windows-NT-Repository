/*+-------------------------------------------------------------------------
	nlsym.c -- utility nlist - fast access to kernel /dev/kmem offsets
	...!{gatech,emory}!n4hgf!wht

  Defined functions:
	main(argc,argv,envp)
	nlsym_write_error(code)

--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:06-27-1990-01:57-wht@n4hgf-1.10-incorporate suggestions from alpha testers */
/*:06-27-1990-01:55-wht@n4hgf-use 64 bits of unique check */
/*:06-25-1990-04:14-wht@n4hgf-1.02-better error handling */
/*:06-24-1990-20:53-wht@n4hgf-v1.01-add ISC support thanks to peter@radig.de */
/*:06-21-1990-14:26-r@n4hgf-version x0.12 seems bug free */
/*:05-12-1989-18:27-wht-fix endless loop error on cannot nlist */
/*:10-27-1988-10:58-wht-creation */

#include "config.h"
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <nlist.h>
#if defined(mips)
#define n_sclass n_type
#endif

#define DEFINE_NLSYM
#include "nlsym.h"

/*+-------------------------------------------------------------------------
	nlsym_write_error(code)
--------------------------------------------------------------------------*/
void
nlsym_write_error(code)
int code;
{
	(void)fprintf(stderr,"code %d: ",code);
	perror(UNIX_NLSYM);
	exit(1);
}	/* end of nlsym_write_error */

/*+-------------------------------------------------------------------------
	main(argc,argv,envp)
--------------------------------------------------------------------------*/
/*ARGSUSED*/
main(argc,argv,envp)
int argc;
char **argv;
char **envp;
{
register int itmp;
register struct nlist *nn;
struct stat unixstat;		/* /unix status at nlsym run (void)time */
int fdnlsym;
int nlist_error = 0;
long unique;
FILE *kludge;

	(void)nlist(UNIX_KERNEL,nlsym);

	nn = nlsym;
	while(nn->n_name)
	{
		if(!nn->n_sclass)
		{
#if !defined(mips)
			(void)printf("%s: can't nlist\n", nn->n_name);
			nlist_error = 1;
#endif
			nn++;
			continue;
		}
		(void)printf("%-12.12s  storage class: %04x value: %08lx\n",
			nn->n_name,
			nn->n_sclass,
			nn->n_value);
		nn++;
	}

	if(nlist_error > 1)
	{
		(void)fprintf(stderr,"%s NOT produced\n",UNIX_NLSYM);
		exit(1);
	}

	if((kludge = fopen(UNIX_NLSYM,"w")) == NULL)	/* scratch/create */
		nlsym_write_error(-1);
	(void)fclose(kludge);

	if((fdnlsym = open(UNIX_NLSYM,O_WRONLY,0)) < 0)
		nlsym_write_error(fdnlsym);

	if(stat(UNIX_KERNEL,&unixstat) < 0)
	{
		(void)fputs("cannot stat ",stderr);
		perror(UNIX_KERNEL);
		exit(1);
	}

	if((itmp = write(fdnlsym,&unixstat,sizeof(unixstat))) != sizeof(unixstat))
		nlsym_write_error(itmp);

	if((itmp = write(fdnlsym,nlsym,sizeof(nlsym))) != sizeof(nlsym))
		nlsym_write_error(itmp);

	unique = NLSYM_UNIQUE1;
	if((itmp = write(fdnlsym,&unique,sizeof(unique))) != sizeof(unique))
		nlsym_write_error(itmp);

	unique = NLSYM_UNIQUE2;
	if((itmp = write(fdnlsym,&unique,sizeof(unique))) != sizeof(unique))
		nlsym_write_error(itmp);

	(void)close(fdnlsym);
	exit(0);
	/*NOTREACHED*/
}	/* end of main */

/* vi: set tabstop=4 shiftwidth=4: */
