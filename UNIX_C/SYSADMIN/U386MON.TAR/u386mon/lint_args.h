/*+-----------------------------------------------------------------------
	lint_args.h
------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:07-21-1990-16:01-afterlint-creation */

#ifndef BUILDING_LINT_ARGS
#ifdef LINT_ARGS

/* bootinfo.c */
extern  char *bmemf_text(unsigned long flags);
extern  void display_bootinfo(struct _win_st *win,int y,int x);
/* det_proc.c */
extern  char *get_cpu_time_str(long ticks);
extern  char *pgrp_to_ttyname(int pgrp);
extern  char *uid_to_name(unsigned short uid);
extern  int det_proc_init(void );
extern  int get_user(struct proc *tproc,struct user *tuser);
extern  int getpwent_and_enter(unsigned short uid);
extern  int ppproc_pid_compare(struct proc * *ppp1,struct proc * *ppp2);
extern  int uid_name_enter(unsigned short uid,char *name);
extern  struct utmp *find_utmp_for_pgrp(int pgrp);
extern  void display_proc_stat(struct _win_st *win,int iproc,int initial);
extern  void display_proc_stats(struct _win_st *win,int initial);
extern  void init_uid_name_hash(void );
extern  void read_and_sort_procs(int initial);
extern  void read_utmp(void );
/* det_sio.c */
extern  char *B_to_baud_rate(int code);
extern  char *cflag_to_baud_d_p_s(int cflag);
extern  int display_sio_summary(struct _win_st *win,int initial);
extern  int tty_slot_compare(struct tty *sio1,struct tty *sio2);
extern  void display_siofull_init(struct _win_st *win,int tly,int tlx,int show_flag);
extern  void display_siofull_update(struct _win_st *win,int tly,int tlx,struct tty *tsio);
extern  void display_siosum_update(struct _win_st *win,int y,struct tty *tsio);
extern  void grok_sio_tty(void );
/* detail.c */
extern  void detail_init(void );
extern  void detail_panel_cmd(unsigned long cmd);
extern  void detail_panel_update(void );
extern  void detpanel_destroy(void );
extern  void detpanel_extra_init(void );
extern  void detpanel_extra_update(void );
extern  void detpanel_ps_init(int full43);
extern  void detpanel_ps_update(void );
extern  void detpanel_sio_init(void );
extern  void detpanel_sio_update(void );
/* disputil.c */
extern  PANEL *mkpanel(int rows,int cols,int tly,int tlx,char *userp);
extern  void clear_area(struct _win_st *win,int y,int x,int len);
extern  void clear_area_char(struct _win_st *win,int y,int x,int len,unsigned char fillchar);
extern  void disp_info_int(struct _win_st *win,char *label,char *fmt,int value);
extern  void disp_info_long(struct _win_st *win,char *label,char *fmt,long value);
extern  void disp_msg(unsigned long cp,char *msg);
extern  void disp_static_int(struct _win_st *win,char *label,char *fmt,int value);
extern  void disp_static_long(struct _win_st *win,char *label,char *fmt,long value);
extern  void pflush(void );
extern  void wperror(struct _win_st *win,char *desc);
/* libkmem.c */
extern  void kinit(int write_needed);
extern  void kread(char *caddr,long kaddr,int len);
/* libmem.c */
extern  void minit(int write_needed);
extern  void mread(char *caddr,long maddr,int len);
/* libnlsym.c */
extern  void nlsym_error(char *text);
extern  void nlsym_read(void );
/* libswap.c */
extern  void sinit(void );
extern  void sread(char *caddr,long maddr,int len);
/* nlsym.c */
extern  int main(int argc,char * *argv,char * *envp);
extern  void nlsym_write_error(int code);
/* proc.c */
extern  char *pstat_text(char pstat);
extern  void display_proc(struct _win_st *win,int y,int x);
extern  void grok_proc(void );
/* tune.c */
extern  void display_tune(struct _win_st *win,int y,int x);
/* u386mon.c */
extern  char *get_elapsed_time(long elapsed_seconds);
extern  int get_cpu_avg(long *cpu_ticks,int period);
extern  int get_wait_avg(long *wait_ticks,int period);
extern  int main(int argc,char * *argv,char * *envp);
extern  long update_cpuscale(struct _win_st *win,int y,int x,int width,long *per_state);
extern  long update_waitscale(struct _win_st *win,int y,int x,int width,long *per_state,long total_ticks);
extern  void calc_cpu_avg(long *per_state);
extern  void calc_wait_avg(long *per_state);
extern  void caught_signal(int sig);
extern  void draw_cpuscale_literals(struct _win_st *win,int y,int x);
extern  void draw_per_sec_literals(struct _win_st *win,int y,int x);
extern  void draw_waitscale_literals(struct _win_st *win,int y,int x);
extern  void extra_info_stuff(void );
extern  void extra_static_stuff(void );
extern  void leave(int exit_code);
extern  void leave_text(char *text,int exit_code);
extern  void leaving(void );
extern  void read_sysinfo_and_minfo(void );
/* var.c */
extern  void display_var(struct _win_st *win,int y,int x);

#else		/* compiler doesn't know about prototyping */

/* bootinfo.c */
extern  char *bmemf_text();
extern  void display_bootinfo();
/* det_proc.c */
extern  char *get_cpu_time_str();
extern  char *pgrp_to_ttyname();
extern  char *uid_to_name();
extern  int det_proc_init();
extern  int get_user();
extern  int getpwent_and_enter();
extern  int ppproc_pid_compare();
extern  int uid_name_enter();
extern  struct utmp *find_utmp_for_pgrp();
extern  void display_proc_stat();
extern  void display_proc_stats();
extern  void init_uid_name_hash();
extern  void read_and_sort_procs();
extern  void read_utmp();
/* det_sio.c */
extern  char *B_to_baud_rate();
extern  char *cflag_to_baud_d_p_s();
extern  int display_sio_summary();
extern  int tty_slot_compare();
extern  void display_siofull_init();
extern  void display_siofull_update();
extern  void display_siosum_update();
extern  void grok_sio_tty();
/* detail.c */
extern  void detail_init();
extern  void detail_panel_cmd();
extern  void detail_panel_update();
extern  void detpanel_destroy();
extern  void detpanel_extra_init();
extern  void detpanel_extra_update();
extern  void detpanel_ps_init();
extern  void detpanel_ps_update();
extern  void detpanel_sio_init();
extern  void detpanel_sio_update();
/* disputil.c */
extern  PANEL *mkpanel();
extern  void clear_area();
extern  void clear_area_char();
extern  void disp_info_int();
extern  void disp_info_long();
extern  void disp_msg();
extern  void disp_static_int();
extern  void disp_static_long();
extern  void pflush();
extern  void wperror();
/* libkmem.c */
extern  void kinit();
extern  void kread();
/* libmem.c */
extern  void minit();
extern  void mread();
/* libnlsym.c */
extern  void nlsym_error();
extern  void nlsym_read();
/* libswap.c */
extern  void sinit();
extern  void sread();
/* nlsym.c */
extern  int main();
extern  void nlsym_write_error();
/* proc.c */
extern  char *pstat_text();
extern  void display_proc();
extern  void grok_proc();
/* tune.c */
extern  void display_tune();
/* u386mon.c */
extern  char *get_elapsed_time();
extern  int get_cpu_avg();
extern  int get_wait_avg();
extern  int main();
extern  long update_cpuscale();
extern  long update_waitscale();
extern  void calc_cpu_avg();
extern  void calc_wait_avg();
extern  void caught_signal();
extern  void draw_cpuscale_literals();
extern  void draw_per_sec_literals();
extern  void draw_waitscale_literals();
extern  void extra_info_stuff();
extern  void extra_static_stuff();
extern  void leave();
extern  void leave_text();
extern  void leaving();
extern  void read_sysinfo_and_minfo();
/* var.c */
extern  void display_var();

#endif /* LINT_ARGS */
#endif /* BUILDING_LINT_ARGS */

/* end of lint_args.h */
