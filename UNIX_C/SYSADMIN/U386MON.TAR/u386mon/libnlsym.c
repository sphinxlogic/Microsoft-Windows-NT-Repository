/*LINTLIBRARY*/
/*+-------------------------------------------------------------------------
	libnlsym.c -- common runtime for nlsym users
	...!{gatech,emory}!n4hgf!wht

  Defined functions:
	nlsym_error(text)
	nlsym_read()

--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:07-15-1990-01:41-wht@n4hgf-keep indicator nlsym has been read */
/*:06-27-1990-01:57-wht@n4hgf-1.10-incorporate suggestions from alpha testers */
/*:06-27-1990-01:55-wht@n4hgf-use 64 bits of unique check */
/*:06-25-1990-04:14-wht@n4hgf-1.02-better error handling */
/*:06-24-1990-20:53-wht@n4hgf-v1.01-add ISC support thanks to peter@radig.de */
/*:06-21-1990-14:26-r@n4hgf-version x0.12 seems bug free */
/*:10-27-1988-11:44-wht-creation */

#include "config.h"
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <nlist.h>
#if defined(mips)
#define n_sclass n_type
#endif

void leave_text();

#define DEFINE_NLSYM
#include "nlsym.h"
#include "libnlsym.h"

extern int errno;
extern char *sys_errlist[];

int nlsym_has_been_read = 0;

/*+-------------------------------------------------------------------------
	nlsym_error(text)
--------------------------------------------------------------------------*/
void
nlsym_error(text)
char *text;
{
char s128[128];

	(void)strcpy(s128,text);
	(void)strcat(s128,": run nlsym");
	leave_text(s128,(errno) ? 255 : 1);
}	/* end of nlsym_error */

/*+-------------------------------------------------------------------------
	nlsym_read()
--------------------------------------------------------------------------*/
void
nlsym_read()
{
char s80[80];
int itmp;
int fdnlsym;
struct stat curstat;	/* current /unix status */
struct stat unixstat;		/* /unix status at nlsym run (void)time */
long unique1 = 0;
long unique2 = 0;

	if(nlsym_has_been_read)
		return;

	if(stat(UNIX_KERNEL,&curstat) < 0)
	{
		(void)sprintf(s80,"cannot stat %s",UNIX_KERNEL);
		nlsym_error(s80);
	}

	errno = 0;
	if((fdnlsym = open(UNIX_NLSYM,O_RDONLY,0)) < 0)
	{
		(void)sprintf(s80,"%s open error\n",UNIX_NLSYM);
		nlsym_error(s80);
	}

	if(read(fdnlsym,(char *)&unixstat,sizeof(unixstat)) != sizeof(unixstat))
		nlsym_error("nlsym_read: /unix stat read error");

	if(read(fdnlsym,(char *)nlsym,sizeof(nlsym)) != sizeof(nlsym))
		nlsym_error("nlsym_read: nlsym read error");

	if(read(fdnlsym,(char *)&unique1,sizeof(unique1)) != sizeof(unique1))
		nlsym_error("nlsym_read: `unique' read error");

	if(read(fdnlsym,(char *)&unique2,sizeof(unique2)) != sizeof(unique2))
		nlsym_error("nlsym_read: `unique' read error");

	(void)close(fdnlsym);

	if( (unique1 != NLSYM_UNIQUE1) ||
		(unique2 != NLSYM_UNIQUE2) ||
		(unixstat.st_ino != curstat.st_ino) ||
		(unixstat.st_mtime != curstat.st_mtime) ||
		(unixstat.st_size != curstat.st_size))
	{
		(void)sprintf(s80,"%s out of date",UNIX_NLSYM);
		nlsym_error(s80);
	}
	nlsym_has_been_read = 1;

}	/* end of nlsym_read */
