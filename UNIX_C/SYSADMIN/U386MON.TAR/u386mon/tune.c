/*+-------------------------------------------------------------------------
	tune.c - u386mon tune struct display

  Defined functions:
	display_tune(win,y,x)

--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:06-27-1990-01:57-wht@n4hgf-1.10-incorporate suggestions from alpha testers */
/*:06-25-1990-17:33-wht@n4hgf-alpha sort identifiers */
/*:06-25-1990-04:14-wht@n4hgf-1.02-better error handling */
/*:06-24-1990-20:53-wht@n4hgf-v1.01-add ISC support thanks to peter@radig.de */
/*:06-21-1990-14:26-r@n4hgf-version x0.12 seems bug free */
/*:06-17-1990-14:59-wht-creation */

#include "config.h"
#define M_TERMINFO
#include <curses.h>
#undef reg     /* per nba@sysware.sysware.dk */
#ifdef NATIVE_PANELS
# include <panel.h>
#else
# include "libpanel.h"
#endif
#include <sys/types.h>
#include <sys/tuneable.h>
#if defined(mips)
#define t_gpgsmsk  t_gpgslmsk
#endif
#include "u386mon.h"

/*+-------------------------------------------------------------------------
	display_tune(win,y,x)
--------------------------------------------------------------------------*/
void
display_tune(win,y,x)
WINDOW *win;
int y;
int x;
{

	use_cp(win,cpBANNER);
	wmove(win,y++,x);
	waddstr(win,"-- Tune ---------");
#ifdef	SVR32
	wmove(win,y++,x);
	disp_static_int(win,"t_ageintvl  ","%5d",tune.t_ageinterval);
#endif
	wmove(win,y++,x);
	disp_static_int(win,"t_bdflushr  ","%5d",tune.t_bdflushr);
	wmove(win,y++,x);
	disp_static_int(win,"t_gpgshi    ","%5d",tune.t_gpgshi);
	wmove(win,y++,x);
	disp_static_int(win,"t_gpgslo    ","%5d",tune.t_gpgslo);
	wmove(win,y++,x);
	disp_static_int(win,"t_gpgsmsk   ","0x%03lx",tune.t_gpgsmsk);
	wmove(win,y++,x);
	disp_static_int(win,"t_maxfc     ","%5d",tune.t_maxfc);
	wmove(win,y++,x);
	disp_static_int(win,"t_maxsc     ","%5d",tune.t_maxsc);
	wmove(win,y++,x);
	disp_static_int(win,"t_maxumem   ","%5d",tune.t_maxumem);
	wmove(win,y++,x);
	disp_static_int(win,"t_minarmem  ","%5d",tune.t_minarmem);
	wmove(win,y++,x);
	disp_static_int(win,"t_minasmem  ","%5d",tune.t_minasmem);

}	/* end of display_tune */

/* vi: set tabstop=4 shiftwidth=4: */
/* end of tune.c */
