/*+-------------------------------------------------------------------------
	config.h - u386mon system monitor configuration

Hopefully, we will hide most of the Machiavellian version-hackery
--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:35-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:08-01-1990-19:24-jdc@dell.com-add DELL config */
/*:08-01-1990-12:24-wht@n4hgf-2.11-try to support ISC 1.x.x */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:07-26-1990-17:51-wht-creation */

#define U386MON

#if defined(M_UNIX)
#define HAS_RDCHK
#define HAS_NAP
#if !defined(SVR32)
#define SVR32
#endif
/* The next two lines may speed up other True S5R3 versions, but I can't say */
#define PERFORMANCE /* see u386mon.c, kludge.c, /usr/include/tinfo.h */
#define CURSES_MACROS
#endif

#if defined(DELL)
#define ISC
#if !defined(SVR32)
#define SVR32
#endif
#endif

#ifdef ISC_1
#define ISC
#if !defined(SVR31)
#define SVR31
#endif
#ifndef NO_ISTOUCH
#define NO_ISTOUCH
#endif
#else /* !ISC 1.x.x */
#if defined(ISC)
#define HAS_RDCHK
#define HAS_NAP
#if !defined(SVR32)
#define SVR32
#endif
#endif
#endif

#if defined(SVR32)
#define NATIVE_PANELS
#define HAS_BOOTINFO
#define HAS_TIMEB
#endif

/*
 * some old curses do not have is_wintouched() or is_linetouched()
 * ... sigh ... This makes our homebrew panel object severely
 * disappointed, maybe useless ... but define NO_ISTOUCH to try
 * it if you get undefined externs for these two work saver functions.
 */
#ifdef SVR31
#ifndef NO_ISTOUCH
/* #define NO_ISTOUCH */
#endif
#endif

#if defined(mips)
#if !defined(SVR31)
#define SVR31
#endif
#if !defined(NO_ISTOUCH)
#define NO_ISTOUCH
#endif
#endif

/* vi: set tabstop=4 shiftwidth=4: */
/* end of config.h */
