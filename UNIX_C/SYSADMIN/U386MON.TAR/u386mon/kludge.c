
/*+-------------------------------------------------------------------------
	kludge.c - u386mon KLUDGE

We want S5R3 curses #define PERFORMANCE because it has several macro
replacements for functions, but one of the macros has a bug in it.  The
macro has_colors() refers to an undefined 'max_pairs' ...  in the interest
of speed, we do the has_colors() call here and get the function
has_colors() without the bogus extern reference.
--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-03-1990-05:04-wht-creation */

#define M_TERMINFO
#include <curses.h>

/*+-------------------------------------------------------------------------
	has_colors_kludge() - don't ask
--------------------------------------------------------------------------*/
#if defined(COLOR_PAIR)
void
has_colors_kludge()
{
extern int color_avail;
	color_avail = has_colors();
}	/* end of has_colors_kludge */
#endif

/* vi: set tabstop=4 shiftwidth=4: */
/* end of kludge.c */
