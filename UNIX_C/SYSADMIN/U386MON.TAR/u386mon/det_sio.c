/*+-------------------------------------------------------------------------
	det_sio.c - UNIX V/386 system monitor serial I/O detail
	...!{gatech,emory}!n4hgf!wht

  Defined functions:
	B_to_baud_rate(code)
	cflag_to_baud_d_p_s(cflag)
	grok_sio_tty()
	display_siofull_init(win,tly,tlx,show_flag)
	display_siofull_update(win,tly,tlx,tsio)
	display_siosum_update(win,y,tsio)
	tty_slot_compare(sio1,sio2)

--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:06-27-1990-17:33-wht@n4hgf-fix bug during 24-line display */
/*:06-27-1990-01:57-wht@n4hgf-1.10-incorporate suggestions from alpha testers */
/*:06-26-1990-03:17-wht@n4hgf-creation */

#include "config.h"
#if defined(M_UNIX) /* SCO */
#define M_TERMINFO
#include <curses.h>
#undef reg     /* per nba@sysware.sysware.dk */
#ifdef NATIVE_PANELS
# include <panel.h>
#else
# include "libpanel.h"
#endif
#include <string.h>
#include <nlist.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ascii.h>
#undef NGROUPS_MAX
#undef NULL
#include <sys/param.h>
#include <sys/tty.h>

#include "nlsym.h"
#include "libkmem.h"
#include "libmem.h"
#include "libswap.h"
#include "libnlsym.h"
#include "u386mon.h"

extern int errno;
extern int sys_nerr;
extern char *sys_errlist[];

#define SIO_NTTY 16	/* for now */
struct tty sio[SIO_NTTY];

#define t_slot	t_delct

int nsio;	/* number of sios open */

typedef struct slabel
{
	int y,x;
	char *label;
} SLABEL;

SLABEL tty_slabels[] =
{
    {  0,  0, "iflag:" },
    {  2,  0, "oflag:" },
    {  3,  0, "cflag:" },
    {  4,  0, "lflag:" },
    {  5,  7, "INTR QUIT ERASE KILL EOF/VMIN  EOL/VTIME EOL2 SWTCH" },
    {  6,  0, "cc:" },
    {  7,  0, "state:" },
    {  -1,-1, (char *)0}
};

typedef struct bitfld
{
	int y,x;
	char *label;
	int flag_num;
	int mask;
} BITFLD;

#define IFLAG 1
#define OFLAG 2
#define LFLAG 3
#define CFLAG 4
#define STATE 5

BITFLD ttybitflds[] =
{
    {  0,  7, "IGNBRK", IFLAG, IGNBRK },
    {  0, 15, "BRKINT", IFLAG, BRKINT },
    {  0, 23, "IGNPAR", IFLAG, IGNPAR },
    {  0, 31, "PARMRK", IFLAG, PARMRK },
    {  0, 39, "INPCK",  IFLAG, INPCK },
    {  0, 46, "ISTRIP", IFLAG, ISTRIP },
    {  0, 53, "INLCR",  IFLAG, INLCR },
    {  0, 60, "IGNCR",  IFLAG, IGNCR },
    {  0, 68, "ICRNL",  IFLAG, ICRNL },
    {  1,  7, "IUCLC",  IFLAG, IUCLC },
    {  1, 15, "IXON",   IFLAG, IXON },
    {  1, 23, "IXOFF",  IFLAG, IXOFF },
    {  1, 31, "IXANY",  IFLAG, IXANY },
    {  2,  7, "OPOST",  OFLAG, OPOST },
    {  2, 15, "OLCUC",  OFLAG, OLCUC },
    {  2, 23, "ONLCR",  OFLAG, ONLCR },
    {  2, 31, "OCRNL",  OFLAG, OCRNL },
    {  2, 39, "ONOCR",  OFLAG, ONOCR },
    {  2, 46, "ONLRET", OFLAG, ONLRET },
    {  2, 53, "OFDEL",  OFLAG, OFDEL },
    {  3, 23, "CREAD",  CFLAG, CREAD },
    {  3, 31, "HUPCL",  CFLAG, HUPCL },
    {  3, 39, "CLOCAL", CFLAG, CLOCAL },
#ifdef RTSFLOW
    {  3, 46, "RTSFLO", CFLAG, RTSFLOW },
#endif
#ifdef CTSFLOW
    {  3, 53, "CTSFLO", CFLAG, CTSFLOW },
#endif
    {  4,  7, "ISIG",   LFLAG, ISIG },
    {  4, 15, "ICANON", LFLAG, ICANON },
    {  4, 23, "XCASE",  LFLAG, XCASE },
    {  4, 31, "ECHO",   LFLAG, ECHO },
    {  4, 39, "ECHOE",  LFLAG, ECHOE },
    {  4, 46, "ECHOK",  LFLAG, ECHOK },
    {  4, 53, "ECHONL", LFLAG, ECHONL },
    {  4, 60, "NOFLSH", LFLAG, NOFLSH },
    {  4, 68, "XCLUDE", LFLAG, XCLUDE },
	{  7,  7, "TO",     STATE, TIMEOUT },
	{  7, 10, "WO",     STATE, WOPEN },
	{  7, 13, "O",      STATE, ISOPEN },
	{  7, 15, "TB",     STATE, TBLOCK },
	{  7, 18, "CD",     STATE, CARR_ON },
	{  7, 21, "BY",     STATE, BUSY },
	{  7, 24, "OSLP",   STATE, OASLP },
	{  7, 29, "ISLP",   STATE, IASLP },
	{  7, 34, "STOP",   STATE, TTSTOP },
	{  7, 39, "EXT",    STATE, EXTPROC },
	{  7, 43, "TACT",   STATE, TACT },
	{  7, 48, "ESC",    STATE, CLESC },
	{  7, 52, "RTO",    STATE, RTO },
	{  7, 56, "IOW",    STATE, TTIOW },
	{  7, 60, "XON",    STATE, TTXON },
	{  7, 64, "XOFF",   STATE, TTXOFF },
    {  -1,-1, (char *)0,    -1,    -1 }
};

typedef struct valyx
{
	int y,x;
} VALYX;

VALYX ttyvalyx[] =
{
#define Fc_intr       0
	{  6,  8 },
#define Fcc_quit      1
	{  6, 13 },
#define Fcc_erase     2
	{  6, 18 },
#define Fcc_kill      3
	{  6, 24 },
#define Fcc_eof       4
	{  6, 30 },
#define Fcc_eol       5
	{  6, 40 },
#define Fcc_eol2      6
	{  6, 49 },
#define Fcc_swtch     7
	{  6, 54 },
#define Fbaud_b_p_s   8
	{  3,  7 }
};

typedef struct b_to_br
{
	char *baud_rate;
	int B_code;
} B_TO_BR;

B_TO_BR speeds[] = 	/* ordered to put less common rates later in table */
{					/* and the vagaries of baud rates above 9600 "handled" */
	" 2400",	B2400,
	" 1200",	B1200,
	" 9600",	B9600,
#if defined(B19200)
	"19200",	B19200,
#endif
#if defined(B38400)
	"38400",	B38400,
#endif
	" 4800",	B4800,
	"  300",	B300,
	"  110",	B110,
	"  600",	B600,
	"   75",	B75,
	"   50",	B50,
	"  HUP",	B0,
	" EXTA",	EXTA,
	" EXTB",	EXTB,

	(char *)0,0
};

/*+-------------------------------------------------------------------------
	tty_slot_compare(sio1,sio2)
--------------------------------------------------------------------------*/
int
tty_slot_compare(sio1,sio2)
struct tty *sio1;
struct tty *sio2;
{
	return(sio1->t_slot - sio2->t_slot);
}	/* end of tty_slot_compare */

/*+-------------------------------------------------------------------------
	grok_sio_tty()
--------------------------------------------------------------------------*/
void
grok_sio_tty()
{
register isio;
register struct tty *tsio;

	nsio = 0;
	kread((caddr_t)sio,sio_ttyaddr,sizeof(struct tty) * SIO_NTTY);
	for(isio = 0; isio < SIO_NTTY; isio++)
	{
		tsio = &sio[isio];
		if(tsio->t_state & (WOPEN | ISOPEN))
		{
			tsio->t_slot = (ushort)isio;
			nsio++;
			continue;
		}
		tsio->t_slot = 127;
	}
	(void)qsort((char *)sio,(unsigned)SIO_NTTY,
		sizeof(struct tty),tty_slot_compare);

}	/* end of grok_sio_tty */

/*+-------------------------------------------------------------------------
	B_to_baud_rate(code) - convert CBAUD B_ code to baud rate string
--------------------------------------------------------------------------*/
char *
B_to_baud_rate(code)
{
register int n;

	for(n=0; speeds[n].baud_rate; n++)
		if(speeds[n].B_code == code)
			return(speeds[n].baud_rate);
	return("-----");
}	/* end of B_to_baud_rate */

/*+-------------------------------------------------------------------------
	cflag_to_baud_d_p_s(cflag)
--------------------------------------------------------------------------*/
char *
cflag_to_baud_d_p_s(cflag)
int cflag;
{
register char *cptr;
static char rtnstr[16];

	strcpy(rtnstr,B_to_baud_rate(cflag & CBAUD));
	cptr = rtnstr + strlen(rtnstr);
	*cptr++ = '-';
	switch(cflag & CSIZE)
	{
		case CS5: *cptr++ = '5'; break;
		case CS6: *cptr++ = '6'; break;
		case CS7: *cptr++ = '7'; break;
		case CS8: *cptr++ = '8'; break;
	}
	*cptr++ = '-';
	*cptr++ = (cflag & PARENB) ? ((cflag & PARODD) ? 'O' : 'E') : 'N';
	*cptr++ = '-';
	*cptr++ = (cflag & CSTOPB) ? '2' : '1';
	*cptr = 0;
	return(rtnstr);

}	/* end of cflag_to_baud_d_p_s */

/*+-----------------------------------------------------------------------
	display_siofull_update(win,tly,tlx,tsio)

000000000011111111112222222222333333333344444444445555555555666666666677777
012345678901234567890123456789012345678901234567890123456789012345678901234
iflag: IGNBRK  BRKINT  IGNPAR  PARMRK  INPCK  ISTRIP INLCR  IGNCR   ICRNL
       IUCLC   IXON    IXOFF   IXANY
oflag: OPOST   OLCUC   ONLCR   OCRNL   ONOCR  ONLRET OFDEL
cflag: 09600-8-N-1     CREAD   HUPCL   CLOCAL
lflag: ISIG    ICANON  XCASE   ECHO    ECHOE  ECHOK  ECHONL NOFLSH  XCLUDE
       INTR QUIT ERASE KILL EOF/VMIN  EOL/VTIME EOL2 SWTCH 
cc:     03   1c   08    15    01        00       00   00   

------------------------------------------------------------------------*/
void
display_siofull_update(win,tly,tlx,tsio)
WINDOW *win;
int tly;
int tlx;
struct tty *tsio;
{
register flag;
register i_cc;
register char *cptr;
BITFLD *bfptr = ttybitflds;
VALYX *vptr = ttyvalyx;

	use_cp(win,cpLOW);
	while(bfptr->y >= 0)
	{
		switch(bfptr->flag_num)
		{
			case IFLAG: flag = tsio->t_iflag; break;
			case OFLAG: flag = tsio->t_oflag; break;
			case LFLAG: flag = tsio->t_lflag; break;
			case CFLAG: flag = tsio->t_cflag; break;
			case STATE: flag = tsio->t_state; break;
		}
		flag &= bfptr->mask;
		wmove(win,bfptr->y + tly,bfptr->x + tlx);
		if(flag)
			use_cp(win,cpREVERSE);
		waddstr(win,bfptr->label);
		if(flag)
			use_cp(win,cpLOW);
		bfptr++;
	}
	for(i_cc = 0; i_cc < NCC; i_cc++)
	{
		wmove(win,vptr->y + tly,vptr->x + tlx);
		wprintw(win,"%02x",tsio->t_cc[i_cc]);
		vptr++;
	}

	vptr = &ttyvalyx[Fbaud_b_p_s];
	clear_area(win,vptr->y + tly,vptr->x + tlx,12);
	waddstr(win,cflag_to_baud_d_p_s(tsio->t_cflag));

}	/* end of display_siofull_update */

/*+-------------------------------------------------------------------------
	display_siofull_init(win,tly,tlx,show_flag)
--------------------------------------------------------------------------*/
void
display_siofull_init(win,tly,tlx,show_flag)
WINDOW *win;
int tly;
int tlx;
int show_flag;
{
register y;
SLABEL *sptr = tty_slabels;

	use_cp(win,cpLIT);
	for(y = 0; y < 7; y++)
		clear_area(win,y,0,getmaxy(win));
	if(show_flag)
	{
		while(sptr->y >= 0)
		{
			wmove(win,sptr->y + tly,sptr->x + tlx);
			waddstr(win,sptr->label);
			sptr++;
		}
	}

}	/* end of display_siofull_init */

/*+-------------------------------------------------------------------------
	display_siosum_update(win,y,tsio)
--------------------------------------------------------------------------*/
void
display_siosum_update(win,y,tsio)
register WINDOW *win;
int y;
register struct tty *tsio;
{
register unsigned int itmp;
register opened = tsio->t_state & (ISOPEN | WOPEN);
char s8[8];

#define TX 1
#define RX 6
#define CX 11
#define OX 16
#define SX 23
#define FX 30

	wmove(win,y,TX);
#ifdef M_UNIX
	waddch(win,(tsio->t_slot < 8) ? '1' : '2');
	waddch(win,(tsio->t_slot % 8) + 'a');
#else
	wprintw(win,"%02d",tsio->slot);
#endif

	if(!opened)
	{
		use_cp(win,cpINFO);
		clear_area(win,y,TX,COLS - TX);
		waddstr(win,"closed");
		return;
	}

	wmove(win,y,RX);
	if((itmp = (unsigned)tsio->t_rawq.c_cc) > 999)
		itmp = 999;
	if(itmp > 10)
		use_cp(win,cpHIGH);
	else if(itmp > 3)
		use_cp(win,cpMED);
	else
		use_cp(win,cpLOW);
	wprintw(win,"%3d",itmp);

	if((itmp = (unsigned)tsio->t_canq.c_cc) > 999)
		itmp = 999;
	if(itmp > 20)
		use_cp(win,cpHIGH);
	else if(itmp > 10)
		use_cp(win,cpMED);
	else
		use_cp(win,cpLOW);
	wmove(win,y,CX);
	wprintw(win,"%3d",itmp);

	if((itmp = (unsigned)tsio->t_outq.c_cc + tsio->t_tbuf.c_count) > 99999)
		itmp = 99999;
	if(itmp > 75)
		use_cp(win,cpHIGH);
	else if(itmp > 20)
		use_cp(win,cpMED);
	else
		use_cp(win,cpLOW);
	wmove(win,y,OX);
	wprintw(win,"%5d",itmp);

	use_cp(win,cpINFO);
	wmove(win,y,SX);
	waddstr(win,B_to_baud_rate(tsio->t_cflag & CBAUD));

	strcpy(s8,".....");
	if(tsio->t_state & WOPEN)
		s8[0] = 'W';
	else if(tsio->t_state & ISOPEN)
		s8[0] = 'O';
	if(tsio->t_state & CARR_ON)
		s8[1] = 'C';
	if(tsio->t_state & BUSY)
		s8[2] = 'B';
	if(tsio->t_state & TTSTOP)
		s8[3] = 'S';
	if(tsio->t_state & TIMEOUT)
		s8[4] = 'D';
	wmove(win,y,FX);
	waddstr(win,s8);

	wprintw(win,"%7o",tsio->t_iflag);
	wprintw(win,"%7o",tsio->t_oflag);
	wprintw(win,"%7o",tsio->t_cflag);
	wprintw(win,"%7o",tsio->t_lflag);
	if(tsio->t_pgrp)
		wprintw(win,"%6d",tsio->t_pgrp);
	else
		waddstr(win,"      ");

}	/* end of display_siosum_update */

/*+-------------------------------------------------------------------------
	display_sio_summary(win,initial)
--------------------------------------------------------------------------*/
display_sio_summary(win,initial)
register WINDOW *win;
int initial;
{
register int isio;
int max_displayable_sios = getmaxy(win) - 2;
static char *header  = 
" tty  raw  can    out  speed  state  iflag  oflag  cflag  lflag  pgrp";
static char *legend =
"W=wait for open  O=open C=carrier on  B=output busy  S=stopped  T=timeout";
static couldnt_display_all = 0;

	if(initial)
	{
		use_cp(win,cpBANNER);
		clear_area(win,0,0,getmaxx(win));
		waddstr(win,header);
		use_cp(win,cpLIT);
		clear_area(win,getmaxy(win)-1,0,getmaxx(win));
		waddstr(win,legend);
		couldnt_display_all = 1;
	}
	grok_sio_tty();
	for(isio = 0; (isio < nsio); isio++)
	{
		if(isio > max_displayable_sios)
		{
			wmove(win,getmaxy(win)-2);
			use_cp(win,cpMED);
			waddstr(win,"cannot display all active serial ports");
			couldnt_display_all = 1;
			return;
		}
		display_siosum_update(win,isio + 1,&sio[isio]);
	}

	for(; isio < getmaxy(win)-2; isio++);
		clear_area(win,isio + 1,0,getmaxx(win));

	if(couldnt_display_all)
	{
		use_cp(win,cpINFO);
		clear_area(win,getmaxy(win)-2,0,getmaxx(win));
		couldnt_display_all = 0;
	}

}	/* end of display_sio_summary */

#endif /* M_UNIX / SCO */
/* vi: set tabstop=4 shiftwidth=4: */
/* end of det_sio.c */
