/*+-------------------------------------------------------------------------
	u386mon.h - UNIX 386 system monitor definitions
	wht@n4hgf.Mt-Park.GA.US
--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:07-10-1990-19:06-root@n4hgf-redesign attributes/color pairs */
/*:07-10-1990-18:33-root@n4hgf-move pio wait to medium alert */
/*:07-03-1990-03:21-root@n4hgf-add cpBANWARN and renumber */
/*:06-27-1990-01:57-wht@n4hgf-1.10-incorporate suggestions from alpha testers */
/*:06-25-1990-04:14-wht@n4hgf-1.02-better error handling */
/*:06-24-1990-20:53-wht@n4hgf-v1.01-add ISC support thanks to peter@radig.de */
/*:06-21-1990-14:27-r@n4hgf-version x0.12 seems bug free */
/*:06-20-1990-03:03-root@n4hgf-trick use_cp into making bright fgnd colors */
/*:06-19-1990-21:35-wht-get ready for release */

#ifndef M_SYSV	/* for ISC */
#define u_char unsigned char
#define u_long unsigned long
#endif

char *getenv();
char *strchr();
char *strrchr();
#ifdef __STDC__
void *malloc();
#else
char *malloc();
#endif

#define pW(pan) panel_window(pan)
#define W WINDOW
#define P PANEL

/* color numbers for EGA/VGA */
#ifdef COLOR_16_TERMINFO	/* wht 16-color fgnd/bgnd terminfo */
#define cHIBIT	8
#define cBLK	0
#define cBLU	1
#define cGRN	2
#define cCYN	3
#define cRED	4
#define cMAG	5
#define cBRN	6
#define cWHT	7
#define cGRY	(cBLK | cHIBIT)
#define cLTB	(cBLU | cHIBIT)
#define cLTG	(cGRN | cHIBIT)
#define cLTC	(cCYN | cHIBIT)
#define cLTR	(cRED | cHIBIT)
#define cLTM	(cMAG | cHIBIT)
#define cYEL	(cBRN | cHIBIT)
#define cHIW	(cWHT | cHIBIT)
#else
#ifdef	COLOR_BLACK
#define cBLK	COLOR_BLACK
#define cBLU	COLOR_BLUE
#define cGRN	COLOR_GREEN
#define cCYN	COLOR_CYAN
#define cRED	COLOR_RED
#define cMAG	COLOR_MAGENTA
#define cBRN	COLOR_YELLOW
#define cWHT	COLOR_WHITE
#define cGRY	COLOR_BLACK
#define cLTB	COLOR_BLUE
#define cLTG	COLOR_GREEN
#define cLTC	COLOR_CYAN
#define cLTR	COLOR_RED
#define cLTM	COLOR_MAGENTA
#define cYEL	COLOR_YELLOW
#define cHIW	COLOR_WHITE
#endif
#endif

#define sTL		0xDA
#define sTR		0xBF
#define sBL		0xC0
#define sBR		0xD9
#define sLT		0xC3	/* left hand T */
#define sRT		0xB4	/* right hand T */
#define sVR		0xB3	/* vertical rule */
#define sHR		0xC4	/* horizontal rule */

/* color pairs */
#ifdef COLOR_16_TERMINFO	/* wht 16-color fgnd/bgnd terminfo */
#define use_cp(win,cp) wattrset(win,COLOR_PAIR(cp))
#else
#ifdef COLOR_PAIR
#define use_cp(win,cp) wattrset(win,\
	(color_avail) ? color_attr[cp] : mono_attr[cp])
#else
#define use_cp(win,cp) wattrset(win,mono_attr[cp])
#endif
#endif

/*
 * for SVR31
 */
#ifndef getcury
#define getcury(win)        ((win)->_cury)
#endif
#ifndef getcurx
#define getcurx(win)        ((win)->_curx)
#endif
#ifndef getbegy
#define getbegy(win)        ((win)->_begy)
#endif
#ifndef getbegx
#define getbegx(win)        ((win)->_begx)
#endif
#ifndef getbegyx
#define getbegyx(win,y,x)   ((y)=getbegy(win),(x)=getbegx(win))
#endif
#ifndef getmaxy
#define getmaxy(win)        ((win)->_maxy)
#endif
#ifndef getmaxx
#define getmaxx(win)        ((win)->_maxx)
#endif
#ifndef getmaxyx
#define getmaxyx(win,y,x)   ((y)=getmaxy(win),(x)=getmaxx(win))
#endif

/* 
 * if color par numbers are changed, disputil.c
 * color_attr and mono_attr tables
 * must also be changed
 */

#define cpINFO		1	/* information field */
#define cpREVERSE	2	/* "reverse video" */
#define cpBANWARN	3	/* banner warning */
#define cpLOW		4	/* low/user/io */
#define cpMED		5	/* medium/kernel/pio */
#define cpHIGH		6	/* high/brk/swp */
#define cpBANNER	7	/* banner */
#define cpLIT		8	/* field literals */
extern int color_avail;
#ifdef COLOR_PAIR
extern long color_attr[];
#endif
extern long mono_attr[];

#define MSG_TLY		(LINES - 2)
#define CMD_TLY		(LINES - 1)
#define LVMSG_Y		MSG_TLY
#define LVMSG_X		0

#define CPUSCALE_TLY		1
#define CPUSCALE_SX			13
#define CPUSCALE_WIDTH		50

#define WAITSCALE_TLY		5
#define WAITSCALE_SX		13
#define WAITSCALE_WIDTH		50

/* Sysinfo/Minfo per second area */
#define PER_SEC_TLY			9
#define PER_SEC1_TLX		0
#define PER_SEC2_TLX		18
#define PER_SEC3_TLX		35
#define PER_SEC4_TLX		51
#define PER_SEC5_TLX		66

/* extra info area */
#define EXTRA_TLY			26
#define EXTRA1_TLX			0
#define EXTRA2_TLX			18
#define EXTRA3_TLX			43
#define EXTRA4_TLX			62

#include "lint_args.h"

/* vi: set tabstop=4 shiftwidth=4: */
/* end of u386mon.h */
