char *revision = "2.20";
/*+-------------------------------------------------------------------------
	u386mon.c - UNIX 386 (and other) system monitor
	...!{gatech,emory}!n4hgf!wht

  Defined functions:
	adb_trap()
	calc_cpu_avg(per_state)
	calc_wait_avg(per_state)
	caught_signal(sig)
	draw_cpuscale_literals(win,y,x)
	draw_per_sec_literals(win,y,x)
	draw_waitscale_literals(win,y,x)
	extra_info_stuff()
	extra_static_stuff()
	get_cpu_avg(cpu_ticks,period)
	get_elapsed_time(elapsed_seconds)
	get_wait_avg(wait_ticks,period)
	leave(exit_code)
	leave_text(text,exit_code)
	leaving(exit_code)
	main(argc,argv,envp)
	update_cpuscale(win,y,x,width,per_state)
	update_waitscale(win,y,x,width,per_state,total_ticks)

00000000001111111111222222222233333333334444444444555555555566666666667777777777
01234567890123456789012345678901234567890123456789012345678901234567890123456789
 u386mon xxx.xxx                       PLOCK     INVALID      hh:mm:ss wht@n4hgf

---- CPU --- tot usr ker brk ---------------------------------------------------
 Instant %   ### ### ### ### xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
 5 Sec Avg % ### ### ### ### xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
10 Sec Avg % ### ### ### ### xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
---- Wait -- tot  io pio swp ---------------------------------------------------
 Instant %   ### ### ### ### xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
 5 Sec Avg % ### ### ### ### xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
10 Sec Avg % ### ### ### ### xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:08-01-1990-19:24-jdc@dell.com-add DELL config */
/*:08-01-1990-17:25-wht@n4hgf-fix sysi86 swap calculations */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:07-28-1990-15:05-wht@n4hgf-make CYCLEmsec variable */
/*:07-11-1990-03:45-root@n4hgf-faster proc table manipulation */
/*:07-10-1990-19:06-root@n4hgf-redesign attributes/color pairs */
/*:07-10-1990-18:33-root@n4hgf-move pio wait to medium alert */
/*:07-10-1990-18:01-root@n4hgf-"improvement" didnt do much, but leave for now */
/*:07-10-1990-13:54-root@n4hgf-improve nap heuristics and catch signals */
/*:07-08-1990-20:31-root@n4hgf-make room for phread/phwrite */
/*:07-03-1990-02:48-root@n4hgf-more accurate timing using ftime calculations */
/*:06-27-1990-01:57-wht@n4hgf-1.10-incorporate suggestions from alpha testers */
/*:06-27-1990-01:07-wht@n4hgf-add ^R and ^L refresh */
/*:06-25-1990-17:34-wht@n4hgf-add detail extra for 25 line tubes */
/*:06-25-1990-04:14-wht@n4hgf-1.02-better error handling */
/*:06-24-1990-20:53-wht@n4hgf-v1.01-add ISC support thanks to peter@radig.de */
/*:06-21-1990-14:26-r@n4hgf-version x0.12 seems bug free */
/*:06-15-1990-18:32-wht@n4hgf-creation */

#include "config.h"
#define M_TERMINFO
#include <curses.h>
#undef timeout /* conflict in curses.h and bootinfo.h per trb@ima.ima.isc.com */
#undef reg     /* per nba@sysware.sysware.dk */
#include "libpanel.h"
#include <signal.h>
#include <string.h>
#include <fcntl.h>
#include <nlist.h>
#include <errno.h>
#include <time.h>
#include <sys/types.h>
#if defined(HAS_TIMEB)
# include <sys/timeb.h>
#endif
#include <sys/lock.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#if defined(HAS_ASCII)
# include <sys/ascii.h>
#else
#define A_ESC	'\033'
#endif
#undef NGROUPS_MAX
#undef NULL
#include <sys/param.h>
#if defined(HAS_BOOTINFO)
# include <sys/bootinfo.h>
#endif
#include <sys/tuneable.h>
#include <sys/sysinfo.h>
#include <sys/sysmacros.h>
#include <sys/immu.h>
#include <sys/region.h>
#if defined(mips)
#include <sys/sbd.h>
#endif
#include <sys/proc.h>
#include <sys/var.h>
#if defined(i386) || defined(i486)
# include <sys/sysi86.h>
#endif
#if defined(mips)
# include <sys/sysmips.h>
#endif
#include <sys/swap.h>
#if !defined(mips)
# include <sys/trap.h>
#endif
#include "nlsym.h"
#include "libkmem.h"
#include "libmem.h"
#include "libswap.h"
#include "libnlsym.h"
#include "u386mon.h"

long nap();
PANEL *mkpanel();

#if defined(HAS_TIMEB)
#define delta_msec(t,t0) ((( t.time * 1000L) +  t.millitm) - \
                          ((t0.time * 1000L) + t0.millitm))
#endif

#define INEXACT_STATE	2
#define INVALID_STATE	5

#if defined(mips)
#define CYCLEmsecDef 5000L
#define CYCLEmsecMax 9000L
#else
#define CYCLEmsecDef 2000L
#define CYCLEmsecMax 4000L
#endif

long CYCLEmsec = CYCLEmsecDef;

struct sysinfo sysinfo;
struct sysinfo sysinfo_last;
#define sysidelta(x) (sysinfo.x - sysinfo_last.x)

struct minfo minfo;
struct minfo minfo_last;
#define midelta(x) (minfo.x - minfo_last.x)

#if defined(HAS_BOOTINFO)
struct bootinfo bootinfo;
#endif

swpt_t swaptab [MSFILES];
swpi_t swapint = {SI_LIST, (char *)swaptab};
struct tune tune;
struct utsname utsname;
struct var v;

#if defined(HAS_TIMEB)
struct timeb timeb_cycle_start;
struct timeb timeb_cycle_end;
struct timeb timeb_info_read;
struct timeb timeb_last_info_read;
#endif

int hz;
int nswap;	/* seems to be in units of NBPSCTR bytes */
int maxmem;
int freemem;
daddr_t myreadlen = 0L;
int myreadcnt = 0;
int stat_period_msec_y = -1;
int stat_period_msec_x = -1;
int color_avail = 0;
int invalidity = 0;

PANEL *pscr;
WINDOW *wscr;
extern WINDOW *wdet;

#define CPU_AVG_MAX		10
int cpu_avg_init = 0;
time_t *cpu_avg[CPU_AVG_MAX];
time_t cpu_ticks[5];

#define WAIT_AVG_MAX	10
int wait_avg_init = 0;
time_t *wait_avg[WAIT_AVG_MAX];
time_t wait_ticks[5];

/*+-------------------------------------------------------------------------
	leaving() - perform leave() basic processing and return
--------------------------------------------------------------------------*/
void
leaving()
{
	wmove(wscr,CMD_TLY,0);
	use_cp(wscr,cpLIT);
	wclrtoeol(wscr);
	pflush();
	endwin();
}	/* end of leaving */

/*+-------------------------------------------------------------------------
	leave(exit_code) - leave program with exit code
--------------------------------------------------------------------------*/
void
leave(exit_code)
int exit_code;
{
	leaving();
	exit(exit_code);
}	/* end of leave */

/*+-------------------------------------------------------------------------
	leave_text(text,exit_code) - leave program with message and exit code
If exit_code == 255, do wperror
--------------------------------------------------------------------------*/
void
leave_text(text,exit_code)
char *text;
int exit_code;
{
	if(exit_code == 255)
	{
	int y;
	register x;
	extern int errno;
	extern int sys_nerr;
	extern char *sys_errlist[];

		top_panel(pscr);
		wmove(wscr,MSG_TLY - 2,0);
		use_cp(wscr,cpHIGH);
		x = 0;
		while(x++ < COLS)
			waddch(wscr,(chtype)' ');
		wmove(wscr,MSG_TLY - 1,0);
		wprintw(wscr,"errno %d",errno);
		if(errno < sys_nerr)
			wprintw(wscr,": %s",sys_errlist[errno]);
		getyx(wscr,y,x);
		while(x++ < COLS)
			waddch(wscr,(chtype)' ');
	}
	if (text && *text) disp_msg(cpHIGH,text);
	leave(exit_code);
}	/* end of leave_text */

/*+-------------------------------------------------------------------------
	adb_trap() - convenient trap for catching abort

  Get a look at stack before abort() botches it
--------------------------------------------------------------------------*/
#if defined(ADB_DEBUG)
void
adb_trap()
{
	printf("too bad .... goodbye\n");
}	/* end of adb_trap */
#endif

/*+-------------------------------------------------------------------------
	caught_signal(sig) - SIGHUP thru SIGSYS: leave with possible abort
--------------------------------------------------------------------------*/
void
caught_signal(sig)
int sig;
{
	leaving();
	switch(sig)
	{
		case SIGQUIT:
		case SIGILL:
		case SIGTRAP:
		case SIGIOT:
		case SIGEMT:
		case SIGFPE:
		case SIGBUS:
		case SIGSEGV:
		case SIGSYS:
#if defined(ADB_DEBUG)
			adb_trap();	/* if debugging, stop at convenient breakpoint */
#endif
			abort();
	}
	exit(200);
}	/* end of caught_signal */

/*+-----------------------------------------------------------------------
	char *get_elapsed_time(elapsed_seconds) - "ddd+hh:mm:ss" returned
  static string address is returned
------------------------------------------------------------------------*/
char *
get_elapsed_time(elapsed_seconds)
time_t elapsed_seconds;
{
static char elapsed_time_str[32];
time_t dd,hh,mm,ss;

	dd = 0;
	hh = elapsed_seconds / 3600;
	if(hh > 24)
	{
		dd = hh / 24;
		elapsed_seconds -= dd * 3600 * 24;
		hh %= 24;
	}
	elapsed_seconds -= hh * 3600;
	mm = elapsed_seconds / 60L;
	elapsed_seconds -= mm * 60L;
	ss = elapsed_seconds;

	if(dd)
		(void)sprintf(elapsed_time_str,"%3ld+%02ld:%02ld:%02ld",dd,hh,mm,ss);
	else
		(void)sprintf(elapsed_time_str,"    %2ld:%02ld:%02ld",hh,mm,ss);
	return(elapsed_time_str);
}	/* end of get_elapsed_time */

/*+-------------------------------------------------------------------------
	draw_cpuscale_literals(win)
--------------------------------------------------------------------------*/
void
draw_cpuscale_literals(win,y,x)
WINDOW *win;
int y;
int x;
{
int x2 = x;

	wmove(win,y,x);
	use_cp(wscr,cpBANNER);
	waddstr(win,"---- CPU --- tot usr ker brk ");
	getyx(win,y,x2);
	while(x2 < COLS)
		waddch(win,(chtype)'-'),x2++;
	use_cp(wscr,cpLIT);
	wmove(win,y + 1,x);
	if(CYCLEmsec == 1000L)
		waddstr(win," Instant %  ");
	else
		wprintw(win,"%2d Sec Avg %%",(int)(CYCLEmsec / 1000L));
	wmove(win,y + 2,x);
  	wprintw(win,"%2d Sec Avg %%",(int)(CYCLEmsec * 5 / 1000L));
	wmove(win,y + 3,x);
  	wprintw(win,"%2d Sec Avg %%",(int)(CYCLEmsec * 10 / 1000L));

}	/* end of draw_cpuscale_literals */

/*+-------------------------------------------------------------------------
	update_cpuscale(win,y,width,per_state)

000000000011111111112222222222333333333344444444445555555555666666
012345678901234567890123456789012345678901234567890123456789012345
tot usr ker misc 
### ### ### ### xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
--------------------------------------------------------------------------*/
#define _CPUSCALE_TX	0
#define _CPUSCALE_UX	4
#define _CPUSCALE_KX	8
#define _CPUSCALE_BX	12
#define _CPUSCALE_SX	16

time_t
update_cpuscale(win,y,x,width,per_state)
WINDOW *win;
int y;
int x;
register width;
time_t *per_state;
{
register itmp;
int accum = 0;
time_t idle = per_state[CPU_IDLE] + per_state[CPU_WAIT];
time_t cpu_ticks_total = idle + per_state[CPU_SXBRK] + 
                         per_state[CPU_KERNEL] + per_state[CPU_USER];
time_t percent_user    = (per_state[CPU_USER]   * 100) / cpu_ticks_total;
time_t percent_kernel  = (per_state[CPU_KERNEL] * 100) / cpu_ticks_total;
time_t percent_break   = (per_state[CPU_SXBRK]  * 100) / cpu_ticks_total;
time_t percent_busy    = percent_user + percent_kernel + percent_break;

	if(!idle)			/* take care of integer div truncation */
		percent_busy = 100;

	wmove(win,y, x + _CPUSCALE_TX);
	if(percent_busy < 70)
		use_cp(wscr,cpLOW);
	else if(percent_busy < 90)
		use_cp(wscr,cpMED);
	else
		use_cp(wscr,cpHIGH);
	wprintw(win,"%3ld",percent_busy);

	wmove(win,y, x + _CPUSCALE_UX);
	use_cp(wscr,cpINFO);
	wprintw(win,"%3ld",percent_user);
	
	wmove(win,y, x + _CPUSCALE_KX);
	wprintw(win,"%3ld",percent_kernel);
	
	wmove(win,y, x + _CPUSCALE_BX);
	wprintw(win,"%3ld",percent_break);
	
	wmove(win,y, x + _CPUSCALE_SX);
	use_cp(wscr,cpLOW);
	itmp = (width * percent_user) / 100;
	accum += itmp;
	while(itmp--)
		waddch(win,(chtype)'u');

	use_cp(wscr,cpMED);
	itmp = (width * percent_kernel) / 100;
	accum += itmp;
	while(itmp--)
		waddch(win,(chtype)'k');

	use_cp(wscr,cpHIGH);
	itmp = (width * percent_break) / 100;
	accum += itmp;
	while(itmp--)
		waddch(win,(chtype)'b');

	if((percent_busy > 98) && ((width - accum) > 0))
	{
		waddch(win,(chtype)'*');
		accum++;
	}

	if((itmp = (width - accum)) > 0)
	{
		use_cp(wscr,cpLIT);
		while(itmp--)
			waddch(win,(chtype)' ');
	}
	return(cpu_ticks_total);
}	/* end of update_cpuscale */

/*+-------------------------------------------------------------------------
	calc_cpu_avg(per_state) - add per_state array to avg array
--------------------------------------------------------------------------*/
void
calc_cpu_avg(per_state)
time_t per_state[];
{
register itmp;

	if(!cpu_avg_init)
	{
		for(itmp = 0; itmp < CPU_AVG_MAX; itmp++)
			(void)memcpy(cpu_avg[itmp],per_state,sizeof(time_t) * 5);
		cpu_avg_init = 1;
	}
	else
	{
		for(itmp = 0; itmp < CPU_AVG_MAX - 1; itmp++)
			(void)memcpy(cpu_avg[itmp],cpu_avg[itmp + 1],sizeof(time_t) * 5);
		(void)memcpy(cpu_avg[itmp],per_state,sizeof(time_t) * 5);
	}

}	/* end of calc_cpu_avg */

/*+-------------------------------------------------------------------------
	get_cpu_avg(cpu_ticks,period)
--------------------------------------------------------------------------*/
get_cpu_avg(cpu_ticks,period)
time_t cpu_ticks[];
int period;
{
register iperiod = CPU_AVG_MAX;
register istate;
register count = period;

	for(istate = 0; istate < 5; istate++)
		cpu_ticks[istate] = 0;

	while(count--)
	{
		iperiod--;
		for(istate = 0; istate < 5; istate++)
		{
			cpu_ticks[istate] += (cpu_avg[iperiod])[istate];
		}
	}

	for(istate = 0; istate < 5; istate++)
		cpu_ticks[istate] /= period;

}	/* end of get_cpu_avg */

/*+-------------------------------------------------------------------------
	draw_waitscale_literals(win)
--------------------------------------------------------------------------*/
void
draw_waitscale_literals(win,y,x)
WINDOW *win;
int y;
int x;
{
int x2 = x;

	wmove(win,y,x);
	use_cp(wscr,cpBANNER);
	waddstr(win,"---- Wait -- tot  io pio swp -- (% of real time) ");
	getyx(win,y,x2);
	while(x2 < COLS)
		waddch(win,(chtype)'-'),x2++;
	use_cp(wscr,cpLIT);
	wmove(win,y + 1,x);
	if(CYCLEmsec == 1000L)
		waddstr(win," Instant %  ");
	else
		wprintw(win,"%2d Sec Avg %%",(int)(CYCLEmsec / 1000L));
	wmove(win,y + 2,x);
  	wprintw(win,"%2d Sec Avg %%",(int)(CYCLEmsec * 5 / 1000L));
	wmove(win,y + 3,x);
  	wprintw(win,"%2d Sec Avg %%",(int)(CYCLEmsec * 10 / 1000L));

}	/* end of draw_waitscale_literals */

/*+-------------------------------------------------------------------------
	draw_per_sec_literals(win)
--------------------------------------------------------------------------*/
void
draw_per_sec_literals(win,y,x)
WINDOW *win;
int y;
int x;
{

	wmove(win,y,x);
	use_cp(wscr,cpBANNER);
	waddstr(win,"---- Sysinfo/Minfo --- (last ");
	getyx(win,stat_period_msec_y,stat_period_msec_x);
 	wprintw(win," %4ld msec activity) ",CYCLEmsec);
	getyx(win,y,x);
	while(x < getmaxx(win))
		waddch(win,(chtype)'-'),x++;

}	/* end of draw_per_sec_literals */

/*+-------------------------------------------------------------------------
	update_waitscale(win,y,width,per_state)

000000000011111111112222222222333333333344444444445555555555666666
012345678901234567890123456789012345678901234567890123456789012345
tot  io pio swp  
### ### ### ### xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
--------------------------------------------------------------------------*/
#define _WAITSCALE_TX	0
#define _WAITSCALE_IX	4
#define _WAITSCALE_PX	8
#define _WAITSCALE_WX	12
#define _WAITSCALE_SX	16

time_t
update_waitscale(win,y,x,width,per_state,total_ticks)
WINDOW *win;
int y;
int x;
register width;
time_t *per_state;
time_t total_ticks;
{
register itmp;
int accum = 0;
time_t percent_io = 0L;
time_t percent_swap = 0L;
time_t percent_pio = 0L;
time_t percent_total_wait;
time_t total_wait;

/* crock: because of latency, total_ticks < all wait ticks sometimes */
	total_wait = per_state[W_IO] + per_state[W_SWAP] + per_state[W_PIO];
	if(total_ticks < total_wait)
		total_ticks = total_wait;

	if(total_ticks)
	{
		percent_io    = (per_state[W_IO]   * 100) / total_ticks;
		percent_pio   = (per_state[W_PIO]  * 100) / total_ticks;
		percent_swap  = (per_state[W_SWAP] * 100) / total_ticks;
	}

	wmove(win,y, x + _WAITSCALE_TX);
	percent_total_wait = percent_io + percent_swap + percent_pio;
	if(percent_total_wait < 30)
		use_cp(wscr,cpLOW);
	else if(percent_total_wait < 50)
		use_cp(wscr,cpMED);
	else
		use_cp(wscr,cpHIGH);
	wprintw(win,"%3ld",percent_total_wait);

	use_cp(wscr,cpINFO);
	wmove(win,y, x + _WAITSCALE_IX);
	wprintw(win,"%3ld",percent_io);
	
	wmove(win,y, x + _WAITSCALE_PX);
	wprintw(win,"%3ld",percent_pio);
	
	wmove(win,y, x + _WAITSCALE_WX);
	wprintw(win,"%3ld",percent_swap);
	
	wmove(win,y, x + _WAITSCALE_SX);
	use_cp(wscr,cpLOW);
	itmp = (width * percent_io) / 100;
	accum += itmp;
	while(itmp--)
		waddch(win,(chtype)'i');

	use_cp(wscr,cpMED);
	itmp = (width * percent_pio) / 100;
	accum += itmp;
	while(itmp--)
		waddch(win,(chtype)'p');

	use_cp(wscr,cpHIGH);
	itmp = (width * percent_swap) / 100;
	accum += itmp;
	while(itmp--)
		waddch(win,(chtype)'s');

	if((itmp = (width - accum)) > 0)
	{
		use_cp(wscr,cpLIT);
		while(itmp--)
			waddch(win,(chtype)' ');
	}

}	/* end of update_waitscale */

/*+-------------------------------------------------------------------------
	calc_wait_avg(per_state) - add per_state array to avg array
--------------------------------------------------------------------------*/
void
calc_wait_avg(per_state)
time_t per_state[];
{
register itmp;

	if(!wait_avg_init)
	{
		for(itmp = 0; itmp < WAIT_AVG_MAX; itmp++)
			(void)memcpy(wait_avg[itmp],per_state,sizeof(time_t) * 3);
		wait_avg_init = 1;
	}
	else
	{
		for(itmp = 0; itmp < WAIT_AVG_MAX - 1; itmp++)
			(void)memcpy(wait_avg[itmp],wait_avg[itmp + 1],sizeof(time_t) * 3);
		(void)memcpy(wait_avg[itmp],per_state,sizeof(time_t) * 3);
	}

}	/* end of calc_wait_avg */

/*+-------------------------------------------------------------------------
	get_wait_avg(wait_ticks,period)
--------------------------------------------------------------------------*/
get_wait_avg(wait_ticks,period)
time_t wait_ticks[];
int period;
{
register iperiod = WAIT_AVG_MAX;
register istate;
register count = period;

	for(istate = 0; istate < 3; istate++)
		wait_ticks[istate] = 0;

	while(count--)
	{
		iperiod--;
		for(istate = 0; istate < 3; istate++)
		{
			wait_ticks[istate] += (wait_avg[iperiod])[istate];
		}
	}

	for(istate = 0; istate < 3; istate++)
		wait_ticks[istate] /= period;

}	/* end of get_wait_avg */

/*+-------------------------------------------------------------------------
	extra_static_stuff()/extra_info_stuff() - for 43 line display
--------------------------------------------------------------------------*/
void
extra_static_stuff()
{
	display_var(wscr,EXTRA_TLY,EXTRA1_TLX);
#if defined(HAS_BOOTINFO)
	display_bootinfo(wscr,EXTRA_TLY,EXTRA2_TLX);
#endif
	display_tune(wscr,EXTRA_TLY,EXTRA3_TLX);
}	/* end of extra_static_stuff */

void
extra_info_stuff()
{
	display_proc(wscr,EXTRA_TLY,EXTRA4_TLX);
}	/* end of extra_info_stuff */

/*+-------------------------------------------------------------------------
	read_sysinfo_and_minfo()
--------------------------------------------------------------------------*/
void
read_sysinfo_and_minfo()
{
#if defined(HAS_TIMEB)
	timeb_last_info_read = timeb_info_read;
	(void)ftime(&timeb_info_read);
#endif
	kread((caddr_t)&sysinfo,sysinfoaddr,sizeof(sysinfo));
	kread((caddr_t)&minfo,minfoaddr,sizeof(minfo));
}	/* end of read_sysinfo_and_minfo */

/*+-------------------------------------------------------------------------
	main(argc,argv,envp)
--------------------------------------------------------------------------*/
/*ARGSUSED*/
main(argc,argv,envp)
int argc;
char **argv;
char **envp;
{
register itmp;
register char *cptr;
register chtype cmd;
register chtype initial_cmd = 0;
int errflg = 0;
int plock_indicator = 0;
time_t total_ticks;
long stat_period_msec;
long nap_msec;
int y,x;
int banner_free_x;
long ltmp, now, then;
struct tm *lt;
static char stdoutbuf[2048];
char s80[80];
extern char *optarg;
extern int optind;

/*
 * curses works better if standard output is fully buffered
 */
	(void)setvbuf(stdout,stdoutbuf,_IOFBF,sizeof(stdoutbuf));

/*
 * check out command line
 */
	while((itmp = getopt(argc,argv,"lPps")) != -1)
	{
		switch(itmp)
		{
			case 'P':
			case 'p':
#if defined(M_UNIX)
			case 's':
#endif
				initial_cmd = (chtype) itmp;
				break;
			case 'l':
				plock_indicator = 1;
				break;
			case '?':
				errflg++;
		}
	}
	if(errflg || (optind != argc))
	{
		static char *usage_str[]=
		{
			"-l lock process into memory (if root)",
			"-p begin with short ps display",
			"-P begin with long ps display (if 43 line screen)",
			(char *)0
		};
		char **cpptr = usage_str;
		fprintf(stderr,"usage: %s [-l] [-p | -P]\n",**argv);
		while(*cpptr)
			(void)fprintf(stderr,"%s\n",*(cpptr++));
		exit(1);
	}

/*
 * if man wants to plock() try it; fail silently if non-root
 */
	if(plock_indicator && plock(PROCLOCK))
	{
		nice(-5);
		plock_indicator = 0;
	}

/*
 * Real(tm) performance monitor users will have done a kernel link
 * and won't need to rely on /etc/systemid
 */
	if(uname(&utsname))
	{
		leave_text("uname failed",255);
		exit(1);
	}

/*
 * allocate memory for cpu time array averaging buckets
 */
	for(itmp = 0; itmp < CPU_AVG_MAX; itmp++)
	{
		if(!(cpu_avg[itmp] = (time_t *)malloc(sizeof(time_t) * 5)))
			leave_text("cannot alloc memory for cpu avg arrays",1);
	}

/*
 * allocate memory for wait time array averaging buckets
 */
	for(itmp = 0; itmp < WAIT_AVG_MAX; itmp++)
	{
		if(!(wait_avg[itmp] = (time_t *)malloc(sizeof(time_t) * 3)))
			leave_text("cannot alloc memory for wait avg arrays",1);
	}

/*
 * initialize curses environment
 */
	if(!initscr())
	{
		(void)printf("curses init failed\n");
		exit(1);
	}
#if defined(COLOR_PAIR)
	has_colors_kludge();
#endif
	clear();
	refresh();

	if((LINES < 24) || (COLS < 80))
	{
		waddstr(stdscr,"\n\n\nNeed at least 80x24 screen\n\n");
		refresh();
		endwin();
		exit(1);
	}

	noecho();
	keypad(stdscr,TRUE);
	typeahead(-1);
#if !defined(HAS_RDCHK)
	cbreak ();
#endif

/*
 * see u386mon.h cXXX definitons for A_BOLD requirements for bright colors
 */
#if defined(COLOR_PAIR)
	if(color_avail)
	{
		start_color();
		init_pair(cpLIT,cBLU,cBLK);
		init_pair(cpINFO,cGRN,cBLK);
		init_pair(cpLOW,cLTG,cBLK);
		init_pair(cpMED,cYEL,cBLK);
		init_pair(cpHIGH,cRED,cBLK);
		init_pair(cpBANNER,cBLK,cWHT);
		init_pair(cpREVERSE,cRED,cWHT);
		init_pair(cpBANWARN,cBLU,cWHT);
	}
#endif

#if (defined(i386) || defined(i486)) && defined(HI_BIT_CAN_BE_SET)
	/* a hack for now -- assuming AT char set */
	/* This does NOT work with SCO ... rumours are it does work somewhere */
	acs_map['l'] = A_ALTCHARSET | sTL;	
	acs_map['m'] = A_ALTCHARSET | sTR;	
	acs_map['j'] = A_ALTCHARSET | sBL;	
	acs_map['k'] = A_ALTCHARSET | sBR;	
	acs_map['x'] = A_ALTCHARSET | sVR;		/* vertical rule */
	acs_map['q'] = A_ALTCHARSET | sHR;		/* horizontal rule */
	acs_map['t'] = A_ALTCHARSET | sLT;		/* left hand T */
	acs_map['u'] = A_ALTCHARSET | sRT;		/* right hand T */
#endif

	if(!(pscr = mkpanel(LINES,COLS,0,0,"main")))
	{
		addstr("cannot make screen panel");
		refresh();
		endwin();
		exit(1);
	}
	wscr = panel_window(pscr);
	top_panel(pscr);
#if !defined(HAS_RDCHK)
	nodelay (wscr, TRUE);
#endif

/*
 * catch signals that can leave our tty in disarray
 */
	for(itmp = SIGHUP; itmp < SIGSYS; itmp++)
		signal(itmp,caught_signal);

/*
 * read nlist symbols, open /dev/kmem, /dev/mem, /dev/swap,
 * initialize detail environment
 * (all of these must occur after curses init)
 * drop euid and egid (after opening privileged mem/devices)
 * initialize process status uid->name hasher
 */
	nlsym_read();
	kinit(0);	/* /dev/kmem, read access only */
	minit(0);	/* /dev/mem,  read access only */
	sinit();	/* /dev/swap, only read access available */
	(void)setuid(getuid());	/* some people run us setuid, so clen that up */
	(void)setgid(getgid());	/* now that we have the fds open, drop egid */
	kread((caddr_t)&v,vaddr,sizeof(v));
	detail_init();

/*
 * start fireworks
 */
	wmove(wscr,0,0);
	use_cp(wscr,cpBANNER);
	waddch(wscr,(chtype)' ');
	waddstr(wscr,**argv);
	waddch(wscr,(chtype)' ');
	waddstr(wscr,revision);

#if defined(mips)
	waddstr(wscr,"/Tandem");
#else
#if defined(M_UNIX)
	waddstr(wscr,"/SCO");
#else
#if defined(ISC)
#if defined(DELL)
	waddstr(wscr,"/Dell");
#else
	waddstr(wscr,"/ISC");
#endif
#endif
#endif
#endif
	
#if defined(DELL)
	wprintw(wscr," Rel %s Ver %s - Node %s ",
		utsname.release,utsname.version,utsname.nodename);
#else
#if defined(m68k)
	wprintw(wscr," %s %s - %s ",
		utsname.release,utsname.version,utsname.nodename);
#else
	/* utsname.release and utsname.version are practcally redundant here */
	wprintw(wscr," %s - %s ",utsname.release,utsname.nodename);
#endif
#endif
	getyx(wscr,y,x);
	banner_free_x = x+2;
	while(x < getmaxx(wscr))
		waddch(wscr,(chtype)' '),x++;
	wmove(wscr,0,71);
	waddstr(wscr,"wht@n4hgf");
	if(plock_indicator)
	{
		wmove(wscr,0,banner_free_x);
		use_cp(wscr,cpMED);
		waddstr(wscr," PLOCK ");
		use_cp(wscr,cpBANNER);
	}
	wmove(wscr,3,0);
	use_cp(wscr,cpMED);
	waddstr(wscr,"WAIT");
	pflush();

	wmove(wscr,CMD_TLY,0);
	use_cp(wscr,cpBANNER);
	if(LINES >= 43)
		waddstr(wscr," ESC=quit  P,p= ps  m=main ");
	else
		waddstr(wscr," ESC=quit  p=ps  e=extra  m=main ");
#if defined(M_UNIX)
	waddstr(wscr," s=sio ");
#endif

	if(getuid() == 0)	/* root can launch fireworks very predictably */
		waddstr(wscr," l/u=lock/unlock ");
	waddstr(wscr," +/-=update rate");
	getyx(wscr,y,x);
	while(x < getmaxx(wscr))
		waddch(wscr,(chtype)' '),x++;
	use_cp(wscr,cpLIT);

/*
 * make initial kmem readings
 */
	hz = (cptr = getenv("HZ")) ? atoi(cptr) : HZ;
	kread((caddr_t)&maxmem,maxmemaddr,sizeof(maxmem));
	kread((caddr_t)&tune,tuneaddr,sizeof(tune));
	kread((caddr_t)&v,vaddr,sizeof(v));

	kread((caddr_t)&nswap,nswapaddr,sizeof(nswap));
	itmp = -1;
#if defined(S3BSWPI)	/* 68000 handled here, not AT&T 3B */
	itmp = _sysm68k (S3BSWPI,&swapint);	/* per nba@sysware.sysware.dk */
#endif
#if defined(SI86SWPI)
	itmp = sysi86(SI86SWPI,&swapint);
#endif
#if defined(SMIPSSWPI)
	itmp = sysmips(SMIPSSWPI,&swapint);
#endif
	if(!itmp)
	{
		nswap = 0;
		for (itmp = 0; itmp < MSFILES; itmp++)
			nswap += swaptab[itmp].st_npgs * NBPP / NBPSCTR;
	}

#if defined(HAS_BOOTINFO)
	kread((caddr_t)&bootinfo,bootinfoaddr,sizeof(bootinfo));
#endif

	read_sysinfo_and_minfo();
	sysinfo_last = sysinfo;
	minfo_last = minfo;

#if defined(HAS_TIMEB)
	timeb_last_info_read = timeb_info_read;
#else
	(void)time (&now);
#endif

/*
 * initialize static display (literals)
 */
	draw_cpuscale_literals(wscr,CPUSCALE_TLY,0);
	draw_waitscale_literals(wscr,WAITSCALE_TLY,0);
	draw_per_sec_literals(wscr,PER_SEC_TLY,0);

	if(LINES >= 43)
		extra_static_stuff();

/*
 * while(user_not_bored) entertain_and_inform_user();
 */
#ifdef HAS_NAP
	nap(CYCLEmsec);
#else
	napms(CYCLEmsec);
#endif
	while(1)
	{

#if defined(HAS_TIMEB)
		ftime(&timeb_cycle_start);
		stat_period_msec = delta_msec(timeb_info_read,timeb_last_info_read);
		(void)time(&now);
#else
		then = now;
		(void)time(&now);
		stat_period_msec = (now - then) * 1000L;
#endif

		lt = localtime(&now);
		wmove(wscr,0,62);
		use_cp(wscr,cpBANNER);
		wprintw(wscr,"%02d:%02d:%02d",lt->tm_hour,lt->tm_min,lt->tm_sec);

		kread((caddr_t)&freemem,freememaddr,sizeof(freemem));
		read_sysinfo_and_minfo();

		/* heuristic validity determination */
		wmove(wscr,0,banner_free_x + 8);
		if((itmp = stat_period_msec > (CYCLEmsec + 3000L)) ||
			(invalidity > INVALID_STATE))
		{
			use_cp(wscr,cpHIGH);
			waddstr(wscr," INVALID ");
			if(itmp)
			{	/* gack - a hack */
				itmp = (stat_period_msec - CYCLEmsec) / 1000;
				if(itmp > 4)
					itmp = 4;
				invalidity += INVALID_STATE + itmp;
			}
		}
		else if((itmp = (stat_period_msec > (CYCLEmsec + 1500L))) ||
				(invalidity > INEXACT_STATE))
		{
			use_cp(wscr,cpMED);
			waddstr(wscr," INEXACT ");
			if(itmp)
				invalidity += INEXACT_STATE;
		}
		if(invalidity && !(--invalidity))
		{
			use_cp(wscr,cpBANNER);
			waddstr(wscr,"         ");
		}
		if(stat_period_msec > (CYCLEmsec + 1000L))
			use_cp(wscr,cpREVERSE);
		else if(stat_period_msec > (CYCLEmsec + 500L))
			use_cp(wscr,cpBANWARN);
		else
			use_cp(wscr,cpBANNER);
		wmove(wscr,stat_period_msec_y,stat_period_msec_x);
		wprintw(wscr,"%5ld",stat_period_msec);


#if defined(FIRST_TRY)
		/* going this way seems to get cpu+wait ticks > real time */
		for (itmp = 0; itmp < 5; itmp++)
			cpu_ticks[itmp] = sysidelta(cpu[itmp]);
		for (itmp = 0; itmp < 3; itmp++)
			wait_ticks[itmp] = sysidelta(wait[itmp]);
#else
		for (itmp = 0; itmp < 5; itmp++)
		{
			if(itmp != CPU_WAIT)
				cpu_ticks[itmp] = sysidelta(cpu[itmp]);
		}
		cpu_ticks[CPU_WAIT] = 0;
		for (itmp = 0; itmp < 3; itmp++)
			cpu_ticks[CPU_WAIT] += (wait_ticks[itmp] = sysidelta(wait[itmp]));
#endif

		total_ticks = update_cpuscale(wscr,CPUSCALE_TLY + 1,CPUSCALE_SX,
			CPUSCALE_WIDTH,cpu_ticks);

		update_waitscale(wscr,WAITSCALE_TLY + 1,WAITSCALE_SX,
			WAITSCALE_WIDTH,wait_ticks,total_ticks);

		calc_cpu_avg(cpu_ticks);
		calc_wait_avg(wait_ticks);

		get_cpu_avg(cpu_ticks,5);
		total_ticks = update_cpuscale(wscr,CPUSCALE_TLY + 2,CPUSCALE_SX,
			CPUSCALE_WIDTH,cpu_ticks);

		get_wait_avg(wait_ticks,5);
		update_waitscale(wscr,WAITSCALE_TLY + 2,WAITSCALE_SX,
			WAITSCALE_WIDTH,wait_ticks,total_ticks);

		get_cpu_avg(cpu_ticks,10);
		total_ticks = update_cpuscale(wscr,CPUSCALE_TLY + 3,CPUSCALE_SX,
			CPUSCALE_WIDTH,cpu_ticks);

		get_wait_avg(wait_ticks,10);
		update_waitscale(wscr,WAITSCALE_TLY + 3,WAITSCALE_SX,
			WAITSCALE_WIDTH,wait_ticks,total_ticks);

		use_cp(wscr,cpINFO);
		y = PER_SEC_TLY + 1;
		wmove(wscr,y++,PER_SEC1_TLX);
		disp_info_long(wscr,"bread    ","%7ld",sysidelta(bread));
		wmove(wscr,y++,PER_SEC1_TLX);
		disp_info_long(wscr,"bwrite   ","%7ld",sysidelta(bwrite));
		wmove(wscr,y++,PER_SEC1_TLX);
		if((ltmp = sysidelta(lread) - myreadcnt) < 0)
			ltmp = 0;
		disp_info_long(wscr,"lread    ","%7ld",ltmp);
		myreadcnt = 0;	/* reset /dev/{mem,kmem,swap} read count */
		wmove(wscr,y++,PER_SEC1_TLX);
		disp_info_long(wscr,"lwrite   ","%7ld",sysidelta(lwrite));
		wmove(wscr,y++,PER_SEC1_TLX);
		disp_info_long(wscr,"phread   ","%7ld",sysidelta(phread));
		wmove(wscr,y++,PER_SEC1_TLX);
		disp_info_long(wscr,"phwrite  ","%7ld",sysidelta(phwrite));
		wmove(wscr,y++,PER_SEC1_TLX);
		disp_info_long(wscr,"swapin   ","%7ld",sysidelta(swapin));
		wmove(wscr,y++,PER_SEC1_TLX);
		disp_info_long(wscr,"swapout  ","%7ld",sysidelta(swapout));
		wmove(wscr,y++,PER_SEC1_TLX);
		disp_info_long(wscr,"bswapin  ","%7ld",sysidelta(bswapin));
		wmove(wscr,y++,PER_SEC1_TLX);
		disp_info_long(wscr,"bswapout ","%7ld",sysidelta(bswapout));
		wmove(wscr,y++,PER_SEC1_TLX);
		disp_info_long(wscr,"iget     ","%7ld",sysidelta(iget));
		wmove(wscr,y++,PER_SEC1_TLX);
		disp_info_long(wscr,"namei    ","%7ld",sysidelta(namei));
		wmove(wscr,y++,PER_SEC1_TLX);
		disp_info_long(wscr,"dirblk   ","%7ld",sysidelta(dirblk));

		y = PER_SEC_TLY + 1;
		wmove(wscr,y++,PER_SEC2_TLX);
		if((ltmp = sysidelta(readch) - myreadlen) < 0)
			ltmp = 0;
		disp_info_long(wscr,"readch  ","%7ld",ltmp);
		myreadlen = 0;	/* reset /dev/{mem,kmem,swap} read count */

		wmove(wscr,y++,PER_SEC2_TLX);
		disp_info_long(wscr,"writch  ","%7ld",sysidelta(writech));

		wmove(wscr,y++,PER_SEC2_TLX);
		disp_info_long(wscr,"rawch   ","%7ld",sysidelta(rawch));
		wmove(wscr,y++,PER_SEC2_TLX);
		disp_info_long(wscr,"canch   ","%7ld",sysidelta(canch));
		wmove(wscr,y++,PER_SEC2_TLX);
		disp_info_long(wscr,"outch   ","%7ld",sysidelta(outch));

		wmove(wscr,y++,PER_SEC2_TLX);
		disp_info_long(wscr,"msg     ","%7ld",sysidelta(msg));
		wmove(wscr,y++,PER_SEC2_TLX);
		disp_info_long(wscr,"sema    ","%7ld",sysidelta(sema));

		wmove(wscr,y++,PER_SEC2_TLX);
		disp_static_long(wscr, "maxmem  ","%6ldk",(long)maxmem * NBPP / 1024);
		wmove(wscr,y++,PER_SEC2_TLX);
		disp_info_long(wscr,   "frmem   ","%6ldk",(long)freemem * NBPP / 1024);
		wmove(wscr,y++,PER_SEC2_TLX);
		disp_info_int (wscr,   "mem used","%6d%%",
			100 - (int)((freemem * 100) / maxmem));

		wmove(wscr,y++,PER_SEC2_TLX);
		disp_static_int(wscr, "nswap   ","%6ldk",nswap * NBPSCTR / 1024);
		wmove(wscr,y++,PER_SEC2_TLX);
		disp_info_long(wscr,  "frswp   ","%6ldk",minfo.freeswap* NBPSCTR/1024);
		wmove(wscr,y++,PER_SEC2_TLX);
		disp_info_int(wscr,   "swp used","%6d%%",
			100 - (int)((minfo.freeswap * 100) / nswap));

		y = PER_SEC_TLY + 1;
		wmove(wscr,y++,PER_SEC3_TLX);
		disp_info_long(wscr,"pswitch ","%5ld",sysidelta(pswitch));
		wmove(wscr,y++,PER_SEC3_TLX);
		disp_info_long(wscr,"syscall ","%5ld",sysidelta(syscall));
		wmove(wscr,y++,PER_SEC3_TLX);
		disp_info_long(wscr,"sysread ","%5ld",sysidelta(sysread));
		wmove(wscr,y++,PER_SEC3_TLX);
		disp_info_long(wscr,"syswrit ","%5ld",sysidelta(syswrite));
		wmove(wscr,y++,PER_SEC3_TLX);
		disp_info_long(wscr,"sysfork ","%5ld",sysidelta(sysfork));
		wmove(wscr,y++,PER_SEC3_TLX);
		disp_info_long(wscr,"sysexec ","%5ld",sysidelta(sysexec));

		y++;
		wmove(wscr,y++,PER_SEC3_TLX);
		disp_info_long(wscr,"runque  ","%5ld",sysidelta(runque));
		wmove(wscr,y++,PER_SEC3_TLX);
		disp_info_long(wscr,"runocc  ","%5ld",sysidelta(runocc));
		wmove(wscr,y++,PER_SEC3_TLX);
		disp_info_long(wscr,"swpque  ","%5ld",sysidelta(swpque));
		wmove(wscr,y++,PER_SEC3_TLX);
		disp_info_long(wscr,"swpocc  ","%5ld",sysidelta(swpocc));

		y = PER_SEC_TLY + 1;
		wmove(wscr,y++,PER_SEC4_TLX);
		disp_info_long(wscr,"vfault  ","%3ld",midelta(vfault));
		wmove(wscr,y++,PER_SEC4_TLX);
		disp_info_long(wscr,"demand  ","%3ld",midelta(demand));
		wmove(wscr,y++,PER_SEC4_TLX);
		disp_info_long(wscr,"pfault  ","%3ld",midelta(pfault));
		wmove(wscr,y++,PER_SEC4_TLX);
		disp_info_long(wscr,"cw      ","%3ld",midelta(cw));
		wmove(wscr,y++,PER_SEC4_TLX);
		disp_info_long(wscr,"steal   ","%3ld",midelta(steal));
		wmove(wscr,y++,PER_SEC4_TLX);
		disp_info_long(wscr,"frdpgs  ","%3ld",midelta(freedpgs));
#if defined(SVR32)
		wmove(wscr,y++,PER_SEC4_TLX);
		disp_info_long(wscr,"vfpg    ","%3ld",midelta(vfpg));
		wmove(wscr,y++,PER_SEC4_TLX);
		disp_info_long(wscr,"sfpg    ","%3ld",midelta(sfpg));
		wmove(wscr,y++,PER_SEC4_TLX);
		disp_info_long(wscr,"vspg    ","%3ld",midelta(vspg));
		wmove(wscr,y++,PER_SEC4_TLX);
		disp_info_long(wscr,"sspg    ","%3ld",midelta(sspg));
		wmove(wscr,y++,PER_SEC4_TLX);
		disp_info_long(wscr,"pnpfault","%3ld",sysidelta(pnpfault));
		wmove(wscr,y++,PER_SEC4_TLX);
		disp_info_long(wscr,"wrtfault","%3ld",sysidelta(wrtfault));
#endif

		y = PER_SEC_TLY + 1;
		wmove(wscr,y++,PER_SEC5_TLX);
		disp_info_long(wscr,"unmodsw ","%3ld",midelta(unmodsw));
		wmove(wscr,y++,PER_SEC5_TLX);
		disp_info_long(wscr,"unmodfl ","%3ld",midelta(unmodfl));
#if defined(SVR32)
		wmove(wscr,y++,PER_SEC5_TLX);
		disp_info_long(wscr,"psoutok ","%3ld",midelta(psoutok));
		wmove(wscr,y++,PER_SEC5_TLX);
		disp_info_long(wscr,"psinfai ","%3ld",midelta(psinfail));
		wmove(wscr,y++,PER_SEC5_TLX);
		disp_info_long(wscr,"psinok  ","%3ld",midelta(psinok));
		wmove(wscr,y++,PER_SEC5_TLX);
		disp_info_long(wscr,"rsout   ","%3ld",midelta(rsout));
		wmove(wscr,y++,PER_SEC5_TLX);
		disp_info_long(wscr,"rsin    ","%3ld",midelta(rsin));
#endif

		y++;
		wmove(wscr,y++,PER_SEC5_TLX);
		use_cp(wscr,cpLIT);
		waddstr(wscr,"pages on   ");
		wmove(wscr,y++,PER_SEC5_TLX);
		disp_info_long(wscr,"swap  ","%5ld",midelta(swap));
		wmove(wscr,y++,PER_SEC5_TLX);
		disp_info_long(wscr,"cache ","%5ld",midelta(cache));
		wmove(wscr,y++,PER_SEC5_TLX);
		disp_info_long(wscr,"file  ","%5ld",midelta(file));

		if(LINES >= 43)
			extra_info_stuff();

		detail_panel_update();

		if(initial_cmd)
		{
			detail_panel_cmd(initial_cmd);
			initial_cmd = 0;
		}

		pflush();

		cmd = 0;
#if defined(HAS_RDCHK)
		while(rdchk(0))
#endif
		{
			switch(cmd = wgetch(wscr))
			{
				case 'L' & 0x1F:		/* ^L */
				case 'R' & 0x1F:		/* ^R */
					clearok (wscr, TRUE);
					touchwin(wscr);
					wrefresh(wscr);
					if(wdet)
					{
						touchwin(wdet);
						wrefresh(wscr);
					}
					break;

				case 'q':
				case A_ESC:
					goto GOOD_BYE;
#if defined(M_UNIX)
				case 'b':
					if(bootinfo.bootstrlen > 79)
						itmp = 79;
					else
						itmp = bootinfo.bootstrlen;
					kread(s80,bootinfoaddr +
						(bootinfo.bootstr - (caddr_t)&bootinfo),itmp);
					s80[itmp] = 0;
					disp_msg(cpMED,s80);
					break;
#endif
				case 'e':
				case 'P':
				case 'p':
				case 'm':
#if defined(M_UNIX)
				case 's':
#endif
					detail_panel_cmd(cmd);
					break;
				case 'l':
					if(!plock_indicator)
					{
						if(!plock(PROCLOCK))
						{
							plock_indicator = 1;
							wmove(wscr,0,banner_free_x);
							use_cp(wscr,cpMED);
							waddstr(wscr," PLOCK ");
							nice(-5);
						}
					}
					break;
				case 'u':
					if(plock_indicator)
					{
						if(!plock(UNLOCK))
						{
							plock_indicator = 0;
							wmove(wscr,0,banner_free_x);
							use_cp(wscr,cpBANNER);
							waddstr(wscr,"       ");
							nice(5);
						}
					}
					break;
				case '+':
					if(CYCLEmsec < CYCLEmsecMax)
					{
						invalidity += (INEXACT_STATE * (CYCLEmsec + 1000L)) /
											CYCLEmsec;
						CYCLEmsec += 1000L;
						draw_cpuscale_literals(wscr,CPUSCALE_TLY,0);
						draw_waitscale_literals(wscr,WAITSCALE_TLY,0);
					}
					else beep();
					break;
				case '-':
					if(CYCLEmsec > 1000L)
					{
						CYCLEmsec -= 1000L;
						draw_cpuscale_literals(wscr,CPUSCALE_TLY,0);
						draw_waitscale_literals(wscr,WAITSCALE_TLY,0);
					}
					else beep();
					break;
				case 0:
				case -1:
					break;
				default:
					beep();
					break;
			}
		}

		/* remember previous statistics for next delta */
		sysinfo_last = sysinfo;
		minfo_last = minfo;

		/* ex-lax: all in the name of regularity */
#if defined(HAS_TIMEB)
		ftime(&timeb_cycle_end);
		nap_msec = CYCLEmsec - delta_msec(timeb_cycle_end,timeb_cycle_start);
		if(nap_msec < (CYCLEmsec - 300L))
			nap_msec = (CYCLEmsec - 300L);
#else
		nap_msec = (CYCLEmsec - 300L);
#endif
#ifdef HAS_NAP
		(void)nap(nap_msec);
#else
		napms(nap_msec);	/* curses call: most round UP to nearest second */
#endif
	}

GOOD_BYE:
	leave_text("",0);
	/*NOTREACHED*/
}	/* end of main */

/* vi: set tabstop=4 shiftwidth=4: */
/* end of u386mon.c */
