/*LINTLIBRARY*/
/*+-------------------------------------------------------------------------
	libkmem.c -- /dev/kmem routines for SCO UNIX/386 (maybe other *NIX)
	...!{gatech,emory}!n4hgf!wht

  Defined functions:
	kinit(write_needed)
	kread(caddr,kaddr,len)
	kwrite(kaddr,caddr,len)

 routines were originally written by Mike "Ford" Ditto: kudos!!!
--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:08-01-1990-19:33-jdc@dell.com-add more error text */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:06-27-1990-01:57-wht@n4hgf-1.10-incorporate suggestions from alpha testers */
/*:06-25-1990-04:14-wht@n4hgf-1.02-better error handling */
/*:06-24-1990-20:53-wht@n4hgf-v1.01-add ISC support thanks to peter@radig.de */
/*:06-21-1990-14:26-r@n4hgf-version x0.12 seems bug free */
/*:12-07-1988-22:06-wht-put in test for initialized fdkmem */
/*:10-27-1988-22:44-wht-creation of file */

#include <sys/types.h>
#include <sys/errno.h>
#include <fcntl.h>
#include "libkmem.h"

void leave_text();

extern int errno;

static int fdkmem = -2;
daddr_t lseek();

/*+-------------------------------------------------------------------------
	kinit(write_needed)
--------------------------------------------------------------------------*/
void
kinit(write_needed)
int write_needed;
{
	if(fdkmem >= 0)
		return;
	if((fdkmem=open("/dev/kmem",(write_needed) ? O_RDWR : O_RDONLY,0)) < 0)
	{
		if (write_needed)
		{
			leave_text("can't open /dev/kmem for read/write access",255);
		}
		else
		{
			leave_text("can't open /dev/kmem for read access",255);
		}
	}

}	/* end of kinit */

/*+-------------------------------------------------------------------------
	kread(caddr,kaddr,len)
--------------------------------------------------------------------------*/
void
kread(caddr,kaddr,len)
caddr_t caddr;
daddr_t kaddr;
int len;
{
char s80[80];
extern daddr_t myreadlen;
extern int myreadcnt;

#if defined(M_I286)
	kaddr &= 0xFFFFL;
#endif
#if defined(mips)
	kaddr &= 0x7FFFFFFFL;
#endif

	if(fdkmem == -2)
		leave_text("kinit() not called",1);

	if(lseek(fdkmem,kaddr,0) == -1L)
	{
		(void)sprintf(s80,"kmem read seek error addr %08lx",kaddr);
		leave_text(s80,255);
	}

	if(read(fdkmem,caddr,len) != len)
	{
		(void)sprintf(s80,"kmem read error len %d addr %08lx",len,kaddr);
		leave_text(s80,255);
	}
	myreadlen += len;
	myreadcnt++;
}	/* end of kread */

/*+-------------------------------------------------------------------------
	kwrite(kaddr,caddr,len)
--------------------------------------------------------------------------*/
#ifdef KWRITE_NEEDED
void
kwrite(kaddr,caddr,len)
daddr_t kaddr;
caddr_t caddr;
int len;
{
char s80[80];

#if defined(M_I286)
	kaddr &= 0xFFFFL;
#endif

	if(fdkmem == -2)
		leave_text("kinit() not called",1);

	if(lseek(fdkmem,kaddr,0) == -1L)
	{
		(void)sprintf(s80,
			"/dev/kmem write seek error addr %08lx",kaddr);
		leave_text(s80,255);
	}
	if(write(fdkmem,caddr,len) != len)
	{
		(void)sprintf(s80,
			"/dev/kmem write error addr %08lx len %08lx",kaddr,len);
		leave_text(s80,255);
	}
}	/* end of kwrite */
#endif

/* vi: set tabstop=4 shiftwidth=4: */
