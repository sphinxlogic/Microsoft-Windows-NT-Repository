/*+-------------------------------------------------------------------------
	det_proc.c - UNIX V/386 system monitor proc status detail
	...!{gatech,emory}!n4hgf!wht

  Defined functions:
	det_proc_init()
	display_proc_stat(win,iproc,initial)
	display_proc_stats(win,initial)
	find_utmp_for_pgrp(pgrp)
	get_cpu_time_str(ticks)
	get_user(tproc,tuser)
	getpwent_and_enter(uid)
	init_uid_name_hash()
	pgrp_to_ttyname(pgrp)
	ppproc_pid_compare(ppp1,ppp2)
	read_and_sort_procs(initial)
	read_utmp()
	uid_name_enter(uid,name)
	uid_to_name(uid)

--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:08-01-1990-12:26-wht@n4hgf-2.11-try to support ISC 1.x.x */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:07-11-1990-03:45-root@n4hgf-faster proc table manipulation */
/*:06-27-1990-01:57-wht@n4hgf-1.10-incorporate suggestions from alpha testers */
/*:06-25-1990-04:14-wht@n4hgf-1.02-better error handling */
/*:06-24-1990-20:53-wht@n4hgf-v1.01-add ISC support thanks to peter@radig.de */
/*:06-21-1990-14:26-r@n4hgf-version x0.12 seems bug free */
/*:01-05-1989-13:27-wht-creation */

#include "config.h"
#define M_TERMINFO
#include <curses.h>
#undef timeout /* conflict in curses.h and bootinfo.h per trb@ima.ima.isc.com */
#undef reg     /* per nba@sysware.sysware.dk */
#ifdef NATIVE_PANELS
# include <panel.h>
#else
# include "libpanel.h"
#endif
#include <signal.h>
#include <string.h>
#include <fcntl.h>
#include <nlist.h>
#include <errno.h>
#include <time.h>
#include <pwd.h>
#include <sys/types.h>
#include <utmp.h>
#include <sys/stat.h>
#undef NGROUPS_MAX
#undef NULL
#include <sys/param.h>
#include <sys/tuneable.h>
#include <sys/sysinfo.h>
#include <sys/sysmacros.h>
#include <sys/immu.h>
#include <sys/region.h>
#if defined(mips)
#define pg_pres pg_sv /* alias: MIPS pg_sv==page valid */
#include <sys/sbd.h>
#include <sys/pcb.h>
#endif
#include <sys/proc.h>
#include <sys/fs/s5dir.h>
#include <sys/user.h>
#include <sys/var.h>
#if defined(M_UNIX) && (defined(i386) || defined(i486)) && SYSI86_RDUBLK_WANTED
/* maybe someday, but not now */
# include <sys/sysi86.h>
#endif

#include "nlsym.h"
#include "libkmem.h"
#include "libmem.h"
#include "libswap.h"
#include "libnlsym.h"
#include "u386mon.h"

extern int errno;

extern int nprocs;
extern struct var v;
extern struct proc *procs;
extern struct proc *oldprocs;
extern struct proc **pprocs;
extern struct proc **poldprocs;

int mypid;
int noldprocs = 0;
int nprocs = 0;
int max_procs_to_display;

struct user user;

#define min(a,b) (((a) > (b)) ? (b) : (a))

#define MAX_UTMP 64
int nutmps = 0;
struct utmp utmps[MAX_UTMP];

/*+-------------------------------------------------------------------------
	ppproc_pid_compare(ppp1,ppp2)
--------------------------------------------------------------------------*/
ppproc_pid_compare(ppp1,ppp2)
register struct proc **ppp1;
register struct proc **ppp2;
{
	return((*ppp1)->p_pid - (*ppp2)->p_pid);
}	/* end of ppproc_pid_compare */

/*+-------------------------------------------------------------------------
	read_and_sort_procs(initial)
--------------------------------------------------------------------------*/
void
read_and_sort_procs(initial)
int initial;
{
int iproc;
register char *cptr;
register struct proc *tproc;
int omitted_one;
char omitted[80];

	omitted[0] = 0;
	disp_msg(cpINFO,"");
	if(!initial)
	{
		(void)memcpy((char *)oldprocs,(char *)procs,
			v.v_proc * sizeof(struct proc));
		noldprocs = nprocs;
		(void)memcpy((char *)poldprocs,(char *)pprocs,
			noldprocs * sizeof(struct proc *));
	}

/* read current procs */
	grok_proc();

/* if slot not in use, force to end when sorting */
	nprocs = 0;
	for(iproc = 0; iproc < v.v_proc; iproc++)
	{
		tproc = pprocs[iproc];
		if(	(tproc->p_stat == 0) ||		/* if slot not in use, ... */
			(tproc->p_pid == 1)  ||		/* ... or proc is init, ... */
			(tproc->p_flag & SSYS))		/* ... or proc is system process */
		{							/* eliminate from consideration */
			tproc->p_pid = 32767;	/* force below selected procs in qsort */
			continue;
		}
		nprocs++;
	}

/* if too many procs, whittle zombies */
	if(nprocs > max_procs_to_display)
	{
		nprocs = 0;
		omitted_one = 0;
		for(iproc = 0; iproc < v.v_proc; iproc++)
		{
			tproc = pprocs[iproc];
			if(tproc->p_pid == 32767)	/* previously eliminated? */
				continue;
			else if(tproc->p_stat == SZOMB)
			{
				tproc->p_pid = 32767;
				omitted_one = 1;
				continue;
			}
			nprocs++;
		}
		if(omitted_one)
		{
			if(omitted[0])
				strcat(omitted,"/");
			strcat(omitted,"zombie");
		}
	}

/* if still too many procs, whittle shells and gettys */
	if(nprocs > max_procs_to_display)
	{
		nprocs = 0;
		omitted_one = 0;
		for(iproc = 0; iproc < v.v_proc; iproc++)
		{
			tproc = pprocs[iproc];
			if(tproc->p_pid == 32767)	/* previously eliminated? */
				continue;
			else if(get_user(tproc,&user))
			{
				if( !strcmp(cptr = user.u_comm,"csh") ||
					!strcmp(cptr,"sh")		||
					!strcmp(cptr,"ksh")		||
					!strcmp(cptr,"bash")	||
					!strcmp(cptr,"cron")	||
					!strcmp(cptr,"errdemon")||
					!strcmp(cptr,"lpsched") ||
					!strcmp(cptr,"logger")	||
					!strcmp(cptr,"getty")	||
					!strcmp(cptr,"uugetty")		)
				{
					tproc->p_pid = 32767;
					omitted_one = 1;
					continue;
				}
			}
			nprocs++;
		}
		if(omitted_one)
		{
			if(omitted[0])
				strcat(omitted,"/");
			strcat(omitted,"shell/getty");
		}
	}

/* if still too many procs, whittle swapped */
	if(nprocs > max_procs_to_display)
	{
		nprocs = 0;
		omitted_one = 0;
		for(iproc = 0; iproc < v.v_proc; iproc++)
		{
			tproc = pprocs[iproc];
			if(tproc->p_pid == 32767)	/* previously eliminated? */
				continue;
			else if(!(tproc->p_flag & SLOAD) && (tproc->p_stat != SRUN))
			{
				tproc->p_pid = 32767;
				omitted_one = 1;
				continue;
			}
			nprocs++;
		}
		if(omitted_one)
		{
			if(omitted[0])
				strcat(omitted,"/");
			strcat(omitted,"swapped");
		}
	}

/* if still too many procs, whittle hard */
	if(nprocs > max_procs_to_display)
	{
		nprocs = 0;
		omitted_one = 0;
		for(iproc = 0; iproc < v.v_proc; iproc++)
		{
			tproc = pprocs[iproc];
			if(tproc->p_pid == 32767)	/* previously eliminated? */
				continue;
			else if(tproc->p_stat == SSLEEP)
			{
				tproc->p_pid = 32767;
				omitted_one = 1;
				continue;
			}
			nprocs++;
		}
		if(omitted_one)
		{
			if(omitted[0])
				strcat(omitted,"/");
			strcat(omitted,"sleeping");
		}
	}

/* if still too many procs, truncate */
	if(nprocs > max_procs_to_display)
	{
		nprocs = max_procs_to_display;
		disp_msg(cpMED,"display size too small for all processes");
		omitted[0] = 0;
	}
	if(omitted[0])
	{
		strcat(omitted," procs omitted");
		disp_msg(cpLIT,omitted);
	}

/* sort new procs array */
	(void)qsort((char *)pprocs,(unsigned)v.v_proc,
		sizeof(struct proc *),ppproc_pid_compare);

	if(initial)
	{
		(void)memcpy((char *)oldprocs,(char *)procs,
			v.v_proc * sizeof(struct proc));
		noldprocs = nprocs;
		(void)memcpy((char *)poldprocs,(char *)pprocs,
			noldprocs * sizeof(struct proc *));
	}

}	/* end of read_and_sort_procs */

/*+-------------------------------------------------------------------------
	read_utmp()
--------------------------------------------------------------------------*/
void
read_utmp()
{
int utmpfd;
register struct utmp *tutmp = utmps;

	nutmps = 0;
	if((utmpfd = open("/etc/utmp",O_RDONLY,755)) < 0)
		leave_text("/etc/utmp open error",255);

	while(read(utmpfd,(char *)(tutmp++),sizeof(struct utmp)) > 0)
	{
		/* ensure null termination
		 * (clobbers 1st byte of ut_line, but we don't use it)
		 */
		tutmp->ut_id[sizeof(tutmp->ut_id)] = 0;
		if(++nutmps == MAX_UTMP)
			leave_text("too many utmp entries for me to handle",1);
	}
	(void)close(utmpfd);
}	/* end of read_utmp */

/*+-------------------------------------------------------------------------
	find_utmp_for_pgrp(pgrp)
--------------------------------------------------------------------------*/
struct utmp *
find_utmp_for_pgrp(pgrp)
int pgrp;
{
struct utmp *tutmp = utmps;
register int count = nutmps;

	while(count--)
	{
		if(tutmp->ut_pid == pgrp)
			return(tutmp);
		tutmp++;
	}
	return((struct utmp *)0);
}	/* end of find_utmp_for_pgrp */

/*+-------------------------------------------------------------------------
	pgrp_to_ttyname(pgrp)
--------------------------------------------------------------------------*/
char *
pgrp_to_ttyname(pgrp)
int pgrp;
{
register itmp;
struct utmp *tutmp;

	if(!(tutmp = find_utmp_for_pgrp(pgrp)))
	{
		read_utmp();
		tutmp = find_utmp_for_pgrp(pgrp);
	}
	if(!tutmp)
		return("??");
	else
	{
		itmp = strlen(tutmp->ut_id);
		return(&tutmp->ut_id[(itmp >= 2) ? (itmp - 2) : 0]);
	}
}	/* end of pgrp_to_ttyname */

/*+-------------------------------------------------------------------------
	get_user(tproc,tuser) - read user struct for pid
return 1 if successful, else 0 if not available
--------------------------------------------------------------------------*/
int
get_user(tproc,tuser)
struct proc *tproc;
struct user *tuser;
{
#if defined(RDUBLK)	/* see sysi86.h #include above */
	/* this system call is not returning 0 on success ?!? */
	return(!!sysi86(RDUBLK,tproc->p_pid,(char *)tuser,sizeof(*tuser)));
#else /* RDUBLK */
	register caddr_t uptr = (caddr_t)tuser;
	register int ubrdcount = sizeof(struct user);
	int ipde;
	paddr_t mptr;

#if !defined(ISC_1) && !defined(mips)
	if(tproc->p_flag & SULOAD)
	{
		for(ipde = 0;
#if defined(SVR31)
			ipde < USIZE;
#else
			ipde < tproc->p_usize;
#endif
			ipde++)
		{
			if(!tproc->p_ubptbl[ipde].pgm.pg_pres)	/* if not resident */
				return(0);
			mptr = tproc->p_ubptbl[ipde].pgm.pg_pfn * NBPP;
			mread(uptr,(daddr_t)mptr,min(ubrdcount,NBPP));
			uptr += NBPP;
			if((ubrdcount -= NBPP) <= 0)
				break;
		}
	}
	else
	{
#if defined(SVR31)
		mptr = tproc->p_ubdbd [0].dbd_blkno * NBPSCTR;
#else
		mptr = tproc->p_ubdbd.dbd_blkno * NBPSCTR;
#endif
		sread(uptr,mptr,ubrdcount);
	}
#else /* ISC_1: a compromise first-attempt */
	for(ipde = 0; ipde < USIZE; ipde++)
	{
		if(!tproc->p_ubptbl[ipde].pgm.pg_pres)	/* if not resident */
			return(0);
		mptr = tproc->p_ubptbl[ipde].pgm.pg_pfn * NBPP;
		mread(uptr,(daddr_t)mptr,min(ubrdcount,NBPP));
		uptr += NBPP;
		if((ubrdcount -= NBPP) <= 0)
			break;
	}
#endif /* ISC_1 */

	/*
	 * we can get crap from swap if things change after we get
	 * an address to read from, so validate user as best we can
	 */
	return( (tuser->u_ruid == tproc->p_uid) ||
			(tuser->u_ruid == tproc->p_suid));

#endif /* RDUBLK */
}	/* end of get_user */

/*+-------------------------------------------------------------------------
uid to username conversion; thanks for the idea to William LeFebvre
--------------------------------------------------------------------------*/
#define UID_NAME_HASH_SIZE	127	/* prime */
#define HASH_EMPTY			32767
#define HASHIT(i)			((i) % UID_NAME_HASH_SIZE)

struct uid_name_hash_entry {
	ushort uid;
	char name[10];
};

struct uid_name_hash_entry uid_name_table[UID_NAME_HASH_SIZE];
int uid_count = 0;

/*+-------------------------------------------------------------------------
	init_uid_name_hash()
--------------------------------------------------------------------------*/
void
init_uid_name_hash()
{
register int ihash = 0;
register struct uid_name_hash_entry *hashent = uid_name_table;

	while(ihash++ < UID_NAME_HASH_SIZE)
	{
		hashent->uid = HASH_EMPTY;
		hashent++;
	}
}	/* end of init_uid_name_hash */

/*+-------------------------------------------------------------------------
	uid_name_enter(uid,name)
--------------------------------------------------------------------------*/
int
uid_name_enter(uid,name)
register ushort uid;
register char *name;
{
register ushort table_uid;
register int hashval;

	if(++uid_count >= UID_NAME_HASH_SIZE - 1)
		leave_text("too many user names for me to handle",1);

	hashval = HASHIT(uid);
	while((table_uid = uid_name_table[hashval].uid) != HASH_EMPTY)
	{
		if(table_uid == uid)
			return(hashval);
		hashval = (hashval + 1) % UID_NAME_HASH_SIZE;
	}

	uid_name_table[hashval].uid = uid;
	(void)strncpy(uid_name_table[hashval].name,name,
		sizeof(uid_name_table[0].name));

	return(hashval);

}	/* end of uid_name_enter */

/*+-------------------------------------------------------------------------
	getpwent_and_enter(uid)
--------------------------------------------------------------------------*/
getpwent_and_enter(uid)
register ushort uid;
{
register int hashval;
register struct passwd *pwd;
char errant[10];
struct passwd *getpwuid();

	pwd = getpwuid(uid);
	endpwent();
	if(pwd)
	{
		hashval = uid_name_enter(pwd->pw_uid,pwd->pw_name);
		return(hashval);
	}
	(void)sprintf(errant,"%u",uid);
	return(uid_name_enter(uid,errant));
}	/* end of getpwent_and_enter */

/*+-------------------------------------------------------------------------
	uid_to_name(uid)
--------------------------------------------------------------------------*/
char *
uid_to_name(uid)
register ushort uid;
{
register int uid_hash;
register ushort table_uid;

	uid_hash = HASHIT(uid);
	while((table_uid = uid_name_table[uid_hash].uid) != uid)
	{
		if(table_uid == HASH_EMPTY)
		{
			/* not in hash table */
			uid_hash = getpwent_and_enter(uid);
			break;		/* out of while */
		}
		uid_hash = (uid_hash + 1) % UID_NAME_HASH_SIZE;
	}
	return(uid_name_table[uid_hash].name);
}	/* end of uid_to_name */

/*+-----------------------------------------------------------------------
	char *get_cpu_time_str(ticks)
  6-char static string address is returned
------------------------------------------------------------------------*/
char *
get_cpu_time_str(ticks)
time_t ticks;
{
static char timestr[10];
time_t mm,ss;
extern int hz;

	ticks /= hz;
	mm = ticks / 60L;
	ticks -= mm * 60L;
	ss = ticks;

	if(mm > 9999)
		(void)strcpy(timestr,">9999m");
	else if(mm > 999)
		(void)sprintf(timestr,"%5ldm",mm);
	else
		(void)sprintf(timestr,"%3lu:%02lu",mm,ss);

	return(timestr);

}	/* end of get_cpu_time_str */

#define PROC_Y		1
#define PROC_X		0
#define UID_X		2
#define PID_X		12
#define CPU_X		18
#define PRI_X		22
#define NICE_X		26
#define UTIME_X		29
#define STIME_X		36
#define SIZE_X		43
#define TTY_X		48
#define CMD_X		52

/*+-------------------------------------------------------------------------
	display_proc_stat(win,iproc,initial)
00000000001111111111222222222233333333334444444444555555555566666666667777777777
01234567890123456789012345678901234567890123456789012345678901234567890123456789
S     USER   PID  CPU PRI NI  UCPU   SCPU  SIZE TTY CMD
#!########X ##### ### ### ## ###### ###### #### ### ########
--------------------------------------------------------------------------*/
void
display_proc_stat(win,iproc,initial)
WINDOW *win;
register int iproc;
register int initial;
{
register int positioned = 0;
register struct proc *tproc = pprocs[iproc];
struct proc          *oproc = poldprocs[iproc];
int got_user;
static char *p_stat_str = " sRzdipx";	/* dependent on values of SSLEEP etc */
char buf[20];

	use_cp(win,cpINFO);
	if((tproc->p_stat == SRUN) && !(tproc->p_flag & SLOAD))
		use_cp(win,cpHIGH);
	else if(tproc->p_stat == SRUN)
		use_cp(win,cpMED);
	if(tproc->p_pid != tproc->p_pid)
		initial = 1;

	wmove(win,PROC_Y + iproc,PROC_X);
	waddch(win,(chtype)p_stat_str[tproc->p_stat]);
	waddch(win,(tproc->p_flag & SLOAD) ? (chtype)' ' : (chtype)'S');
	positioned = 1;

	if(initial)
	{
		if(!positioned)
			wmove(win,PROC_Y + iproc,PROC_X + UID_X);
		(void)sprintf(buf,"%8s",uid_to_name(tproc->p_uid));
		waddstr(win,buf);
		waddch(win,(tproc->p_uid != tproc->p_suid) ? '#' : ' ');
		waddch(win,' ');
		positioned = 1;
	}
	else
		positioned = 0;

	if(initial)
	{
		if(!positioned)
			wmove(win,PROC_Y + iproc,PROC_X + PID_X);
		(void)sprintf(buf,"%5d ",tproc->p_pid);
		waddstr(win,buf);
		positioned = 1;
	}
	else
		positioned = 0;

	if(initial || (tproc->p_cpu != oproc->p_cpu))
	{
		if(!positioned)
			wmove(win,PROC_Y + iproc,PROC_X + CPU_X);
		(void)sprintf(buf,"%3u ",tproc->p_cpu);
		waddstr(win,buf);
		positioned = 1;
	}
	else
		positioned = 0;

	if(initial || (tproc->p_pri != oproc->p_pri))
	{
		if(!positioned)
			wmove(win,PROC_Y + iproc,PROC_X + PRI_X);
		(void)sprintf(buf,"%3u ",tproc->p_pri);
		waddstr(win,buf);
		positioned = 1;
	}
	else
		positioned = 0;

	if(initial || (tproc->p_nice != oproc->p_nice))
	{
		if(!positioned)
			wmove(win,PROC_Y + iproc,PROC_X + NICE_X);
		(void)sprintf(buf,"%2d ",tproc->p_nice);
		waddstr(win,buf);
		positioned = 1;
	}
	else
		positioned = 0;

/* since not saving user area, always update fields from it */
	if(!positioned)
		wmove(win,PROC_Y + iproc,PROC_X + UTIME_X);
	if(got_user = get_user(tproc,&user))
	{
		waddstr(win,get_cpu_time_str(user.u_utime));
		waddch(win,' ');
		waddstr(win,get_cpu_time_str(user.u_stime));
		waddch(win,' ');
/*
 * process size:
 *
 * There are ways that seem right to a man, but the end of them is death.
 * u_tsize and friends are not clicks, but in bytes.
 * I thought this would have been:
 *		(ctob((u_long)user.u_tsize + user.u_dsize + user.u_ssize)) / 1024);
 * At least this makes numbers agree with /bin/ps, although I cannot
 * figure out why there is one extra page charged by ps (user is 2 pages).
 *
 *
 * This was evidentally wrong in SCO UNIX 3.2.0 and fixed in 3.2.1.
 * If you get lots of processes who size is reported as 4, define
 * USIZE_FIXED
 */
		(void)sprintf(buf,"%4lu ",
#if !defined(M_UNIX) /* !SCO */
	/*
    ** For ISC:
	** Reports exactly the same value as ps.  The values in the user
	** area seem totally bogus (u_tsize is always 0, from observation)
	** so this size, the program swap size, seems the best measure.
	** Without USIZE_FIXED, on ISC2.02/Dell UNIX 1.1 I get zeroes.
	** With USIZE_FIXED I get values, but they're way out (e.g. vpix
	** and cron shown as the same size....).
	*/
			(u_long)tproc->p_size
#else /* SCO */
#if defined(USIZE_FIXED)	/* SCO UNIX 3.2.1 (and later?) */
			(ctob((u_long)user.u_tsize + user.u_dsize + user.u_ssize)) / 1024
#else				/* SCO UNIX 3.2.0 */
			(((u_long)user.u_tsize + 511) / 1024) +
			(((u_long)user.u_dsize + 511) / 1024) +
			(((u_long)user.u_ssize + 511) / 1024) +
			(((u_long)((user.u_tsize)?1:0) * NBPP) / 1024)
#endif
#endif /* SCO */
		);
		waddstr(win,buf);
	}
	else
		waddstr(win,"------ ------ ---- ");

/*
	positioned = 1;
	if(!positioned)
		wmove(win,PROC_Y + iproc,PROC_X + TTY_X);
*/
	(void)sprintf(buf,"%3.3s ",pgrp_to_ttyname(tproc->p_pgrp));
	waddstr(win,buf);
	positioned = 1;

/*
	if(!positioned)
		wmove(win,PROC_Y + iproc,PROC_X + CMD_X);
*/
	if(got_user)
	{
	register char *cptr = user.u_psargs;
	int y,x,maxx = getmaxx(win);
		getyx(win,y,x);
		while(*cptr && (x < maxx))
		{
			*cptr &= 0x7F;
			if(*cptr < 0x20)
				*cptr = 0x20;
			waddch(win,*cptr);
			cptr++,x++;
		}
	}
	else
	{
		switch(tproc->p_stat)
		{
			case SZOMB:
				waddstr(win,"<zombie>");
				break;
			case SXBRK:
				waddstr(win,"<xbreak>");
				break;
			case SIDL:
				waddstr(win,"<in creation>");
				break;
			default:
				waddstr(win,"<swapping>");
		}
	}

	wclrtoeol(win);

}	/* end of display_proc_stat */

/*+-------------------------------------------------------------------------
	display_proc_stats(win,initial)
--------------------------------------------------------------------------*/
void
display_proc_stats(win,initial)
WINDOW *win;
int initial;
{
register int iproc;
int y,x;

	touchwin (win);
	if(initial)
	{
		use_cp(win,cpBANNER);
		wmove(win,0,0);
		waddstr(win,
			"S     USER   PID  CPU PRI NI  UCPU   SCPU  SIZE TTY CMD");
		getyx(win,y,x);
		while(x < getmaxx(win))
			waddch(win,(chtype)' '),x++;
	}
	mypid = getpid();
	max_procs_to_display = getmaxy(win) - PROC_Y;
	read_and_sort_procs(initial);
	max_procs_to_display = min(nprocs,max_procs_to_display);
	for(iproc = 0; iproc < max_procs_to_display; iproc++)
		display_proc_stat(win,iproc,1);
	wclrtobot(win);
}	/* end of display_proc_stats */

/*+-------------------------------------------------------------------------
	det_proc_init()
--------------------------------------------------------------------------*/
det_proc_init()
{
	init_uid_name_hash();	/* see det_proc.c */
}	/* end of det_proc_init */
/* vi: set tabstop=4 shiftwidth=4: */
/* end of det_proc.c */
