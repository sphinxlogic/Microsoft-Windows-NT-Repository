/* CHK=0xE998 */
/*+-------------------------------------------------------------------------
	renice.c - UNIX 386 renice

 * This program was written by me, Mike "Ford" Ditto, and
 * I hereby release it into the public domain in the interest
 * of promoting the development of free, quality software
 * for the hackers and users of the world.
 *
 * Feel free to use, copy, modify, improve, and redistribute
 * this program, but keep in mind the spirit of this
 * contribution; always provide source, and always allow
 * free redistribution (shareware is fine with me).  If
 * you use a significant part of this code in a program of
 * yours, I would appreciate being given the appropriate
 * amount of credit.
 *				-=] Ford [=-
 *
--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:06-26-1990-15:09-wht@n4hgf-adapt Ford's work to UNIX 386 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#undef NGROUPS_MAX
#undef NULL
#include <sys/param.h>
#include <sys/immu.h>
#include <sys/region.h>
#include <sys/proc.h>
#include <sys/var.h>
#include <nlist.h>
#include "../nlsym.h"
#include "../libkmem.h"
#include "../libnlsym.h"

struct var v;
struct proc tproc;
int myuid;
char *progname;
char s128[128];
int myreadcnt = 0;			/* see libkmem.c, libmem.c, libswap.c */
daddr_t myreadlen = 0;

/*+-------------------------------------------------------------------------
	leave_text(text,exit_code)
If exit_code == 255, do perror
--------------------------------------------------------------------------*/
void
leave_text(text,exit_code)
char *text;
int exit_code;
{
	if(exit_code == 255)
		perror(text);
	else
	{
		fputs(text,stderr);
		fputs("\n",stderr);
	}
	exit(exit_code);
}	/* end of leave_text */

/*+-------------------------------------------------------------------------
	renice(pid,value,relative) - change nice of process `pid'
based on 'value' and 'relative'
--------------------------------------------------------------------------*/
renice(pid,value,relative)
int pid;
int value;
int relative;
{
	register i;
	int tmpnice;

	for(i = 0; i < v.v_proc; i++)
	{
		kread((caddr_t)&tproc,(daddr_t)((struct proc *)procaddr + i),
		    sizeof(struct proc));
		if(tproc.p_pid == pid)
		{
#ifdef DEBUG
			fprintf(stderr,"Found it!  proc[%d], p_uid is %d\n",
			    i,tproc.p_uid);

			fprintf(stderr,"Old p_nice was %d\n",tproc.p_nice);
#endif /* DEBUG */

			tmpnice = tproc.p_nice;

			if(relative)
				tmpnice += value;
			else
				tmpnice = value;

			if(tmpnice >= 40)
				tmpnice = 40;
			if(tmpnice < 0)
				tmpnice = 0;

#ifdef DEBUG
			fprintf(stderr,"New p_nice is %d\n",tmpnice);
#endif /* DEBUG */

			if( 
#ifdef WHT
				(myuid && (myuid != 201))
#else
				myuid
#endif
			 	&& ((myuid != tproc.p_uid) || (tmpnice < tproc.p_nice)))
			{
				errno = EACCES;
				sprintf(s128,"%s: can't renice process %d",progname,pid);
				perror(s128);
				return 1;
			}

			tproc.p_nice = tmpnice;

			kwrite((daddr_t)&((struct proc *)procaddr)[i]
			    + ( ((caddr_t)&tproc.p_nice) - (caddr_t)&tproc ),
			    (caddr_t)&tproc.p_nice,sizeof(tproc.p_nice));
			return(0);
		}
	}
	fprintf(stderr,"%s: process %d not found.\n",progname,pid);

	return(1);
}	/* end of renice */

/*+-------------------------------------------------------------------------
	usage()
--------------------------------------------------------------------------*/
void
usage()
{
    fprintf(stderr,"usage: %s [{+-}inc] [=prio] pid ...\n",progname);
    exit(-1);
}	/* end of usage */

/*+-------------------------------------------------------------------------
	main(argc,argv)
--------------------------------------------------------------------------*/
main(argc,argv)
int argc;
char **argv;
{
	int status=0;
	int pid;
	int relative = 1;
	int value = 0;

	progname = *argv;
	if(argc < 2)
		usage();

	myuid = getuid();
	nlsym_read();
	kinit(1);
	kread((caddr_t)&v,vaddr,sizeof(v));

	while(++argv,--argc)
	{
		switch(**argv)
		{
		case '-':
			if(sscanf(*argv+1,"%d",&value) != 1)
				usage();
			relative = 1;
			break;
		case '+':
			if(sscanf(*argv+1,"%d",&value) != 1)
				usage();
			value = -value;
			relative = 1;
			break;
		case '=':
			if(sscanf(*argv+1,"%d",&value) != 1)
				usage();
			relative = 0;
			break;
		default:
			if(sscanf(*argv,"%d",&pid) != 1)
				usage();
			status += renice(pid,value,relative);
		}
	}

	exit(status);
}	/* end of main */

/* vi: set tabstop=4 shiftwidth=4: */
/* end of renice.c */
