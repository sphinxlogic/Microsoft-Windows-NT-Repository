/*+-------------------------------------------------------------------------
	detail.c - UNIX 386 system monitor detail window

  Defined functions:
	detail_init()
	detail_panel_cmd(cmd)
	detail_panel_update()
	detpanel_destroy()
	detpanel_extra_init()
	detpanel_extra_update()
	detpanel_ps_init(full43)
	detpanel_ps_update()
	detpanel_sio_init()
	detpanel_sio_update()

--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:07-10-1990-14:53-root@n4hgf-clear msg line on detail cmd - fix 24-line bug */
/*:06-27-1990-01:57-wht@n4hgf-1.10-incorporate suggestions from alpha testers */
/*:06-25-1990-17:34-wht@n4hgf-add detail extra for 25 line tubes */
/*:06-25-1990-04:14-wht@n4hgf-1.02-better error handling */
/*:06-24-1990-20:53-wht@n4hgf-v1.01-add ISC support thanks to peter@radig.de */
/*:06-21-1990-14:26-r@n4hgf-version x0.12 seems bug free */
/*:06-15-1990-18:32-wht@n4hgf-creation */

#include "config.h"
#define M_TERMINFO
#include <curses.h>
#undef timeout /* conflict in curses.h and bootinfo.h per trb@ima.ima.isc.com */
#undef reg     /* per nba@sysware.sysware.dk */
#ifdef NATIVE_PANELS
# include <panel.h>
#else
# include "libpanel.h"
#endif
#include <signal.h>
#include <string.h>
#include <fcntl.h>
#include <nlist.h>
#include <errno.h>
#include <time.h>
#include <pwd.h>
#include <sys/types.h>
#include <utmp.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#undef NGROUPS_MAX
#undef NULL
#include <sys/param.h>
#include <sys/tuneable.h>
#include <sys/sysinfo.h>
#include <sys/sysmacros.h>
#include <sys/immu.h>
#include <sys/region.h>
#if defined(mips)
#include <sys/sbd.h>
#endif
#include <sys/proc.h>
#include <sys/var.h>

#include "nlsym.h"
#include "libkmem.h"
#include "libnlsym.h"
#include "u386mon.h"

#define DPT_NONE		0
#define DPT_PS			1
#define DPT_PS_LONG		2
#define DPT_EXTRA		3
#define DPT_SIO			4

PANEL *mkpanel();

extern PANEL *pscr;
extern WINDOW *wscr;

PANEL *pdet;
WINDOW *wdet = (WINDOW *)0;
u_char detpanel_type = DPT_NONE;
int detpanel_length;
int detpanel_cols;

/*+-------------------------------------------------------------------------
	detpanel_ps_init(full43)
--------------------------------------------------------------------------*/
void
detpanel_ps_init(full43)
int full43;
{
/*
#define DETAIL_PS_COLS ((LINES >= 43) ? EXTRA4_TLX - 1 : PER_SEC4_TLX)
detpanel_cols = DETAIL_PS_COLS;
*/

#define DETAIL_PS_TLY ((LINES >= 43) ? ((full43)?PER_SEC_TLY:PER_SEC_TLY+14)\
                                     : PER_SEC_TLY)

#define DETAIL_PS_LENGTH		(MSG_TLY - DETAIL_PS_TLY)

	detpanel_length = DETAIL_PS_LENGTH;
	detpanel_cols = COLS;
	if(!(pdet = mkpanel(detpanel_length,detpanel_cols,DETAIL_PS_TLY,0,"ps")))
	{
		leave_text("cannot make detail panel",1);
	}
	show_panel(pdet);
	top_panel(pdet);
	wdet = panel_window(pdet);
	display_proc_stats(wdet,1);

}	/* end of detpanel_ps_init */

/*+-------------------------------------------------------------------------
	detpanel_ps_update()
--------------------------------------------------------------------------*/
void
detpanel_ps_update()
{
	display_proc_stats(wdet,0);
}	/* end of detpanel_ps_update */

/*+-------------------------------------------------------------------------
	detpanel_extra_init()
--------------------------------------------------------------------------*/
void
detpanel_extra_init()
{
#define DETAIL_EXTRA_TLY		PER_SEC_TLY
#define DETAIL_EXTRA_LENGTH		(MSG_TLY - DETAIL_EXTRA_TLY)

	detpanel_length = DETAIL_EXTRA_LENGTH;
	detpanel_cols = COLS;
	if(!(pdet = mkpanel(detpanel_length,detpanel_cols,DETAIL_EXTRA_TLY,0,"ex")))
	{
		leave_text("cannot make detail panel",1);
	}
	show_panel(pdet);
	top_panel(pdet);
	wdet = panel_window(pdet);
	display_var(wdet,0,EXTRA1_TLX);
#if defined(HAS_BOOTINFO)
	display_bootinfo(wdet,0,EXTRA2_TLX);
#endif
	display_tune(wdet,0,EXTRA3_TLX);
	display_proc(wdet,0,EXTRA4_TLX);

}	/* end of detpanel_extra_init */

/*+-------------------------------------------------------------------------
	detpanel_extra_update()
--------------------------------------------------------------------------*/
void
detpanel_extra_update()
{
	display_proc(wdet,0,EXTRA4_TLX);
}	/* end of detpanel_extra_update */

/*+-------------------------------------------------------------------------
	detpanel_sio_init() - SCO only serial I/O display
--------------------------------------------------------------------------*/
#if defined(M_UNIX)
void
detpanel_sio_init()
{
#define DETAIL_SIO_TLY ((LINES >= 43) ? (PER_SEC_TLY+14) : PER_SEC_TLY)
#define DETAIL_SIO_LENGTH		(CMD_TLY - DETAIL_SIO_TLY)

	detpanel_length = DETAIL_SIO_LENGTH;
	detpanel_cols = COLS;
	if(!(pdet = mkpanel(detpanel_length,detpanel_cols,DETAIL_SIO_TLY,0,"sio")))
	{
		leave_text("cannot make detail panel",1);
	}
	show_panel(pdet);
	top_panel(pdet);
	wdet = panel_window(pdet);
	display_sio_summary(wdet,1);
}	/* end of detpanel_sio_init */
#endif

/*+-------------------------------------------------------------------------
	detpanel_sio_update()
--------------------------------------------------------------------------*/
#if defined(M_UNIX)
void
detpanel_sio_update()
{
	display_sio_summary(wdet,0);
}	/* end of detpanel_sio_update */
#endif

/*+-------------------------------------------------------------------------
	detpanel_destroy()
--------------------------------------------------------------------------*/
void
detpanel_destroy()
{
	hide_panel(pdet);
	delwin(wdet);
	wdet = (WINDOW *)0;
	del_panel(pdet);
	top_panel(pscr);
	disp_msg(cpINFO,"");
	detpanel_type = DPT_NONE;
}	/* end of detpanel_destroy */

/*+-------------------------------------------------------------------------
	detail_panel_cmd(cmd)

  command: m main screen
           p proc status
--------------------------------------------------------------------------*/
void
detail_panel_cmd(cmd)
chtype cmd;
{
	disp_msg(cpINFO,"");
	switch(cmd)
	{
		case 'm':
			if(detpanel_type != DPT_NONE)
				detpanel_destroy();
			break;

		case 'P':
			if(detpanel_type == DPT_PS_LONG)
				break;
			if(detpanel_type != DPT_NONE)
				detpanel_destroy();
			detpanel_ps_init(1);
			detpanel_type = DPT_PS_LONG;
			break;

		case 'p':
			if(detpanel_type == DPT_PS)
				break;
			if(detpanel_type != DPT_NONE)
				detpanel_destroy();
			detpanel_ps_init(0);
			detpanel_type = DPT_PS;
			break;

		case 'e':
			if(LINES >= 43)
				break;
			if(detpanel_type == DPT_EXTRA)
				break;
			if(detpanel_type != DPT_NONE)
				detpanel_destroy();
			detpanel_extra_init();
			detpanel_type = DPT_EXTRA;
			break;

#if defined(M_UNIX)
		case 's':
			if(detpanel_type == DPT_SIO)
				break;
			if(detpanel_type != DPT_NONE)
				detpanel_destroy();
			detpanel_sio_init();
			detpanel_type = DPT_SIO;
			break;
#endif

	}
}	/* end of detail_panel_cmd */

/*+-------------------------------------------------------------------------
	detail_panel_update()
--------------------------------------------------------------------------*/
void
detail_panel_update()
{
	switch(detpanel_type)
	{
		case DPT_PS:
		case DPT_PS_LONG:
			detpanel_ps_update();
			break;
		case DPT_EXTRA:
			detpanel_extra_update();
			break;
#if defined(M_UNIX)
		case DPT_SIO:
			detpanel_sio_update();
			break;
#endif
	}
}	/* end of detail_panel_update */

/*+-------------------------------------------------------------------------
	detail_init()
--------------------------------------------------------------------------*/
void
detail_init()
{
	det_proc_init();	/* see det_proc.c */
}	/* end of detail_init */

/* vi: set tabstop=4 shiftwidth=4: */
/* end of detail.c */
