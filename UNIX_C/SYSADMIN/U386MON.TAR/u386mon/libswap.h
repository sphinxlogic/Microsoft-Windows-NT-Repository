/*+-----------------------------------------------------------------------
	libswap.h
	...!{gatech,emory}!n4hgf!wht
------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:06-27-1990-01:57-wht@n4hgf-1.10-incorporate suggestions from alpha testers */
/*:06-25-1990-04:14-wht@n4hgf-1.02-better error handling */
/*:06-24-1990-20:53-wht@n4hgf-v1.01-add ISC support thanks to peter@radig.de */
/*:06-22-1990-02:03-root@n4hgf-creation from libmem */

#ifndef BUILDING_LINT_ARGS
#ifdef LINT_ARGS

/* libswap.c */
void sinit(void );
void sread(char  *,long ,int );

#else		/* compiler doesn't mnow about prototyping */

/* libswap.c */
void sinit();
void sread();
void swrite();

#endif /* LINT_ARGS */
#endif /* BUILDING_LINT_ARGS */

/* end of libswap.h */
