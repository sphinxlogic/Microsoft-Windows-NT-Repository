/*LINTLIBRARY*/
/*+-------------------------------------------------------------------------
	libswap.c -- /dev/swap routines for SCO UNIX/386 (maybe other *NIX)
	...!{gatech,emory}!n4hgf!wht

  Defined functions:
	sinit()
	sread(caddr,maddr,len)

 routines were originally written by Mike "Ford" Ditto: kudos!!!
--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:06-27-1990-01:57-wht@n4hgf-1.10-incorporate suggestions from alpha testers */
/*:06-25-1990-04:14-wht@n4hgf-1.02-better error handling */
/*:06-24-1990-20:53-wht@n4hgf-v1.01-add ISC support thanks to peter@radig.de */
/*:06-22-1990-02:00-root@n4hgf-creation from libmem */

#include <sys/types.h>
#include <fcntl.h>
#include "libswap.h"

void leave_text();

extern int errno;

static int fdswap = -2;
daddr_t lseek();

/*+-------------------------------------------------------------------------
	sinit()
--------------------------------------------------------------------------*/
void
sinit()
{
	if(fdswap >= 0)
		return;
	if((fdswap=open("/dev/swap",O_RDONLY)) < 0)
#ifdef M_SYS5
		leave_text("can't open /dev/swap (chgrp mem /dev/swap)",1);
#else
		leave_text("can't open /dev/swap (chgrp sys /dev/swap)",1);
#endif

}	/* end of sinit */

/*+-------------------------------------------------------------------------
	sread(caddr,maddr,len)
--------------------------------------------------------------------------*/
void
sread(caddr,maddr,len)
caddr_t caddr;
daddr_t maddr;
int len;
{
char s80[80];
extern daddr_t myreadlen;
extern int myreadcnt;

#if defined(M_I286)
	maddr &= 0xFFFFL;
#endif

	if(fdswap == -2)
		leave_text("sinit() not called",1);

	if(lseek(fdswap,maddr,0) == -1L)
	{
		(void)sprintf(s80,"swap seek error addr %08lx",maddr);
		leave_text(s80,1);
	}

	if(read(fdswap,caddr,len) != len)
	{
		(void)sprintf(s80,"swap read error len %d addr %08lx",len,maddr);
		leave_text(s80,255);
	}
	myreadlen += len;
	myreadcnt++;
}	/* end of sread */

/* vi: set tabstop=4 shiftwidth=4: */
