/*+-------------------------------------------------------------------------
	nlsym.h -- utility nlist - fast access to kernel /dev/kmem offsets
	...!{gatech,emory}!n4hgf!wht

The nlsym file contains three records:
1.  struct stat unixstat - stat buffer from /unix at file creation time
2.  struct nlist nlsym - the structure of nlist'd information
3.  long unique - a unique identifier to help ensure correct nlsym length

--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:06-27-1990-01:57-wht@n4hgf-1.10-incorporate suggestions from alpha testers */
/*:06-27-1990-01:55-wht@n4hgf-use 64 bits of unique check */
/*:06-25-1990-04:14-wht@n4hgf-1.02-better error handling */
/*:06-24-1990-20:53-wht@n4hgf-v1.01-add ISC support thanks to peter@radig.de */
/*:06-21-1990-14:26-r@n4hgf-version x0.12 seems bug free */
/*:10-27-1988-11:07-wht-creation */

#define UNIX_KERNEL		"/unix"
#define UNIX_NLSYM		"/unix.nlsym"
#define NLSYM_UNIQUE1	0x1BADD00DL
#define NLSYM_UNIQUE2	0xDEADB1FFL

#define Nindex_AVAILRMEM            0
#define Nindex_AVAILSMEM            1
#define Nindex_BDEVCNT              2
#define Nindex_BDEVSW               3
#if defined(HAS_BOOTINFO)
#define Nindex_BOOTINFO             4
#else
#endif
#define Nindex_CDEVCNT              5
#define Nindex_CDEVSW               6
#define Nindex_CFREE                7
#define Nindex_CFREECNT             8
#define Nindex_CFREELIST            9
#define Nindex_CONSSW              10
#define Nindex_CURPROC             11
#define Nindex_DINFO               12
#define Nindex_DSTFLAG             13
#define Nindex_DUMPDEV             14
#define Nindex_EMAP                15
#define Nindex_FFREELIST           16
#define Nindex_FILE                17
#define Nindex_FMODCNT             18
#define Nindex_FMODSW              19
#define Nindex_FREEMEM             20
#define Nindex_FSINFO              21
#define Nindex_FSTYPSW             22
#define Nindex_HZ                  23
#define Nindex_IDLESERVER          24
#define Nindex_IFREELIST           25
#define Nindex_INODE               26
#define Nindex_KPTBL               27
#define Nindex_LBOLT               28
#define Nindex_LINECNT             29
#define Nindex_LINESW              30
#define Nindex_MAXCLICK            31
#define Nindex_MAXMEM              32
#define Nindex_MINFO               33
#define Nindex_MOUNT               34
#define Nindex_MSGLISTCNT          35
#define Nindex_NFSTYP              36
#define Nindex_NPTALLOCED          37
#define Nindex_NPTFREE             38
#define Nindex_NSERVERS            39
#define Nindex_NSWAP               40
#define Nindex_NSYSENT             41
#define Nindex_OLDPROC             42
#define Nindex_OLD_CURPROC         43
#define Nindex_PANICSTR            44
#define Nindex_PHYSMEM             45
#define Nindex_PIPEDEV             46
#define Nindex_PROC                47
#define Nindex_RCINFO              48
#define Nindex_ROOTDEV             49
#define Nindex_RUNQ                50
#define Nindex_SHLBINFO            51
#define Nindex_SWAPDEV             52
#define Nindex_SWPLO               53
#define Nindex_SYSERR              54
#define Nindex_SYSINFO             55
#define Nindex_SYSSEGS             56
#define Nindex_SYSWAIT             57
#define Nindex_TIME                58
#define Nindex_TIMEZONE            59
#define Nindex_TTHIWAT             60
#define Nindex_TTLOWAT             61
#define Nindex_TUNE                62
#define Nindex_U                   63
#define Nindex_USERTABLE           64
#define Nindex_V                   65
#define Nindex_WIN_UBLK            66
#define Nindex_REGION              67
#ifdef M_UNIX
#define Nindex_SIO_TTY             68
#endif

#if defined(HAS_BOOTINFO)
#define bootinfoaddr (nlsym[Nindex_BOOTINFO].n_value)
#endif
#define freememaddr (nlsym[Nindex_FREEMEM].n_value)
#define lboltaddr (nlsym[Nindex_LBOLT].n_value)
#define maxmemaddr (nlsym[Nindex_MAXMEM].n_value)
#define minfoaddr (nlsym[Nindex_MINFO].n_value)
#define nswapaddr (nlsym[Nindex_NSWAP].n_value)
#define physmemaddr (nlsym[Nindex_PHYSMEM].n_value)
#define procaddr (nlsym[Nindex_PROC].n_value)
#define regionaddr (nlsym[Nindex_REGION].n_regionalue)
#define sysinfoaddr (nlsym[Nindex_SYSINFO].n_value)
#define tuneaddr (nlsym[Nindex_TUNE].n_value)
#define vaddr (nlsym[Nindex_V].n_value)
#ifdef M_UNIX
#define sio_ttyaddr (nlsym[Nindex_SIO_TTY].n_value)
#endif

#ifdef DEFINE_NLSYM
struct nlist nlsym[] =
{
	{ "availrmem" },
	{ "availsmem" },
	{ "bdevcnt" },
	{ "bdevsw" },
#if defined(HAS_BOOTINFO)
	{ "bootinfo" },
#else
	{ "spl" },	/*
				 * dummy argument: unique text symbol present in all
				 * implimenations (function name helps ensure uniqueness
				 * since we don't "do" text)
				 */
#endif
	{ "cdevcnt" },
	{ "cdevsw" },
	{ "cfree" },
	{ "cfreecnt" },
	{ "cfreelist" },
	{ "conssw" },
	{ "curproc" },
	{ "dinfo" },
	{ "Dstflag" },
	{ "dumpdev" },
	{ "emap" },
	{ "ffreelist" },
	{ "file" },
	{ "fmodcnt" },
	{ "fmodsw" },
	{ "freemem" },
	{ "fsinfo" },
	{ "fstypsw" },
	{ "Hz" },
	{ "idleserver" },
	{ "ifreelist" },
	{ "inode" },
	{ "kptbl" },
	{ "lbolt" },
	{ "linecnt" },
	{ "linesw" },
	{ "maxclick" },
	{ "maxmem" },
	{ "minfo" },
	{ "mount" },
	{ "msglistcnt" },
	{ "nfstyp" },
	{ "nptalloced" },
	{ "nptfree" },
	{ "nservers" },
	{ "nswap" },
	{ "nsysent" },
	{ "oldproc" },
	{ "old_curproc" },
	{ "panicstr" },
	{ "physmem" },
	{ "pipedev" },
	{ "proc" },
	{ "rcinfo" },
	{ "rootdev" },
	{ "runq" },
	{ "shlbinfo" },
	{ "swapdev" },
	{ "swplo" },
	{ "syserr" },
	{ "sysinfo" },
	{ "syssegs" },
	{ "syswait" },
	{ "time" },
	{ "Timezone" },
	{ "tthiwat" },
	{ "ttlowat" },
	{ "tune" },
	{ "u" },
	{ "usertable" },
	{ "v" },
	{ "win_ublk" },
	{ "region" },
#ifdef M_UNIX
	{ "sio_tty" },
#endif
	{ (char *)0 }
};
#else
extern struct nlist nlsym[];
#endif

/* vi: set tabstop=4 shiftwidth=4: */
