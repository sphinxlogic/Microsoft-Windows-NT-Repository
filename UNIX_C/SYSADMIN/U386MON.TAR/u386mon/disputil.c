/*+-------------------------------------------------------------------------
	disputil.c - u386mon display utilities

  Defined functions:
	clear_area(win,y,x,len)
	clear_area_char(win,y,x,len,fillchar)
	disp_info_int(win,label,fmt,value)
	disp_info_long(win,label,fmt,value)
	disp_msg(cp,msg)
	disp_static_int(win,label,fmt,value)
	disp_static_long(win,label,fmt,value)
	mkpanel(rows,cols,tly,tlx,userp)
	pflush()
	wperror(win,desc)

--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:07-10-1990-19:06-root@n4hgf-redesign attributes/color pairs */
/*:06-27-1990-01:57-wht@n4hgf-1.10-incorporate suggestions from alpha testers */
/*:06-25-1990-04:14-wht@n4hgf-1.02-better error handling */
/*:06-24-1990-20:53-wht@n4hgf-v1.01-add ISC support thanks to peter@radig.de */
/*:06-21-1990-14:26-r@n4hgf-version x0.12 seems bug free */
/*:06-17-1990-15:15-wht-creation */

#include "config.h"
#define M_TERMINFO
#include <curses.h>
#undef timeout
#undef reg     /* per nba@sysware.sysware.dk */
#ifdef NATIVE_PANELS
# include <panel.h>
#else
# include "libpanel.h"
#endif
#include <sys/types.h>
#include "u386mon.h"

#ifdef COLOR_PAIR
long color_attr[] =
{
	COLOR_PAIR(0),
	COLOR_PAIR(cpINFO),
	COLOR_PAIR(cpREVERSE),
	COLOR_PAIR(cpBANWARN),
	COLOR_PAIR(cpLOW) | A_BOLD,
	COLOR_PAIR(cpMED) | A_BOLD,
	COLOR_PAIR(cpHIGH),
	COLOR_PAIR(cpBANNER),
	COLOR_PAIR(cpLIT),
	0
};
#endif

long mono_attr[] =
{
	0,						/* 0 */
	0,						/* cpINFO */
	A_REVERSE,				/* cpREVERSE */
	A_BOLD,			 		/* cpBANWARN */
	0,						/* cpLOW */
	A_UNDERLINE,			/* cpMED */
	A_BLINK,				/* cpHIGH */
	A_REVERSE,				/* cpBANNER */
	A_DIM,					/* cpLIT */
};

extern WINDOW *wdet, *wscr;

/*+-------------------------------------------------------------------------
	clear_area_char(win,y,x,len,fillchar)
--------------------------------------------------------------------------*/
void
clear_area_char(win,y,x,len,fillchar)
WINDOW *win;
int y;
int x;
int len;
u_char fillchar;
{
	wmove(win,y,x);
	while(len-- > 0)
		waddch(win,(chtype)fillchar);
	wmove(win,y,x);

}	/* end of clear_area_char */

/*+-------------------------------------------------------------------------
	clear_area(win,y,x,len)
--------------------------------------------------------------------------*/
void
clear_area(win,y,x,len)
WINDOW *win;
int y;
int x;
int len;
{
	clear_area_char(win,y,x,len,' ');
}	/* end of clear_area_char */

/*+-------------------------------------------------------------------------
	pflush() - do update_panels() and doupdate()
--------------------------------------------------------------------------*/
void
pflush()
{
	update_panels();
	curs_set(0);
	doupdate();
	curs_set(1);
}	/* end of pflush */

/*+-------------------------------------------------------------------------
	wperror(win,desc)
--------------------------------------------------------------------------*/
void
wperror(win,desc)
WINDOW *win;
char *desc;
{
extern int errno;
extern int sys_nerr;
extern char *sys_errlist[];

	waddstr(win,desc);
	waddstr(win,": ");
	if(errno < sys_nerr)
		waddstr(win,sys_errlist[errno]);
	else
		wprintw(win,"error %u",errno);

}	/* end of wperror */

/*+-------------------------------------------------------------------------
	mkpanel(rows,cols,tly,tlx,userp) - alloc win and pan and associate them
--------------------------------------------------------------------------*/
PANEL *
mkpanel(rows,cols,tly,tlx,userp)
int rows;
int cols;
int tly;
int tlx;
char *userp;
{
WINDOW *win = newwin(rows,cols,tly,tlx);
PANEL *pan;

	if(!win)
		return((PANEL *)0);
	if(pan = new_panel(win))
	{
		set_panel_userptr(pan,userp);
		return(pan);
	}
	delwin(win);
	return((PANEL *)0);
}	/* end of mkpanel */

/*+-------------------------------------------------------------------------
	disp_info_long(win,label,fmt,value)
--------------------------------------------------------------------------*/
void
disp_info_long(win,label,fmt,value)
WINDOW *win;
char *label;
char *fmt;
long value;
{
	use_cp(win,cpLIT);
	waddstr(win,label);
	use_cp(win,cpINFO);
	wprintw(win,fmt,value);
}	/* end of disp_info_long */

/*+-------------------------------------------------------------------------
	disp_info_int(win,label,fmt,value)
--------------------------------------------------------------------------*/
void
disp_info_int(win,label,fmt,value)
WINDOW *win;
char *label;
char *fmt;
int value;
{
	use_cp(win,cpLIT);
	waddstr(win,label);
	use_cp(win,cpINFO);
	wprintw(win,fmt,value);
}	/* end of disp_info_int */

/*+-------------------------------------------------------------------------
	disp_static_long(win,label,fmt,value)
--------------------------------------------------------------------------*/
void
disp_static_long(win,label,fmt,value)
WINDOW *win;
char *label;
char *fmt;
long value;
{
	use_cp(win,cpLIT);
	waddstr(win,label);
	wprintw(win,fmt,value);
}	/* end of disp_static_long */

/*+-------------------------------------------------------------------------
	disp_static_int(win,label,fmt,value)
--------------------------------------------------------------------------*/
void
disp_static_int(win,label,fmt,value)
WINDOW *win;
char *label;
char *fmt;
int value;
{
	use_cp(win,cpLIT);
	waddstr(win,label);
	wprintw(win,fmt,value);
}	/* end of disp_static_int */

/*+-------------------------------------------------------------------------
	disp_msg(cp,msg)
--------------------------------------------------------------------------*/
void
disp_msg(cp,msg)
chtype cp;
char *msg;
{
extern WINDOW *wscr;
int y;
register int x;

	wmove(wscr,MSG_TLY,0);
	use_cp(wscr,cp);
	waddstr(wscr,msg);
	getyx(wscr,y,x);
	while(x < getmaxx(wscr))
		waddch(wscr,(chtype)' '),x++;
}	/* end of disp_msg */

/* vi: set tabstop=4 shiftwidth=4: */
/* end of disputil.c */
