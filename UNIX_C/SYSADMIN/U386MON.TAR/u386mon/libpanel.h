
/*+-------------------------------------------------------------------------
	libpanel.h - libpanel.c <panel.h> surrogate
	wht@n4hgf.Mt-Park.GA.US
--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:12-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:07-31-1990-08:18-wht@n4hgf-some cpps wont take #error even in untrue ifdef */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:07-23-1990-00:56-wht@n4hgf-full library working */
/*:07-21-1990-15:42-wht-creation */

#ifdef NATIVE_PANELS
# include <panel.h>
#else

typedef struct panelobs
{
	struct panelobs *above;
	struct panel *pan;
} PANELOBS;

typedef struct panel
{
	WINDOW *win;
	int wstarty;
	int wendy;
	int wstartx;
	int wendx;
	struct panel *below;
	struct panel *above;
	char *user;
	struct panelobs *obscure;
} PANEL;

#ifndef BUILDING_LINT_ARGS
#ifdef LINT_ARGS

extern  WINDOW *panel_window(PANEL *pan);
extern  void update_panels(void );
extern  int hide_panel(PANEL *pan);
extern  int show_panel(PANEL *pan);
extern  int del_panel(PANEL *pan);
extern  int top_panel(PANEL *pan);
extern  int bottom_panel(PANEL *pan);
extern  PANEL *new_panel(WINDOW *win);
extern  PANEL *panel_above(PANEL *pan);
extern  PANEL *panel_below(PANEL *pan);
extern  int set_panel_userptr(PANEL *pan,char *uptr);
extern  char *panel_userptr(PANEL *pan);
extern  int move_panel(PANEL *pan,int starty,int startx);
extern  int replace_panel(PANEL *pan,WINDOW *win);

#else		/* compiler doesn't know about prototyping */

extern  WINDOW *panel_window();
extern  void update_panels();
extern  int hide_panel();
extern  int show_panel();
extern  int del_panel();
extern  int top_panel();
extern  int bottom_panel();
extern  PANEL *new_panel();
extern  PANEL *panel_above();
extern  PANEL *panel_below();
extern  int set_panel_userptr();
extern  char *panel_userptr();
extern  int move_panel();
extern  int replace_panel();

#endif /* LINT_ARGS */
#endif /* BUILDING_LINT_ARGS */

#endif	/* NATIVE_PANELS */

/* end of function declarations */
/* vi: set tabstop=4 shiftwidth=4: */
/* end of libpanel.h */
