/*+-------------------------------------------------------------------------
	var.c - u386mon var struct display

  Defined functions:
	display_var(win,y,x)

--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:08-10-1990-14:13-jmd@p1so/wht@n4hgf-2.20-add Tandem Integrity S2 */
/*:08-07-1990-14:24-wht@n4hgf-nba@sysware.sysware.dk S5R31 updates */
/*:08-02-1990-15:36-wht@n4hgf-2.12-old curses hacks+minor 3.2 formalizations */
/*:07-28-1990-18:06-wht@n4hgf-2.10 release */
/*:06-27-1990-01:57-wht@n4hgf-1.10-incorporate suggestions from alpha testers */
/*:06-25-1990-17:33-wht@n4hgf-alpha sort identifiers */
/*:06-25-1990-04:14-wht@n4hgf-1.02-better error handling */
/*:06-24-1990-20:53-wht@n4hgf-v1.01-add ISC support thanks to peter@radig.de */
/*:06-21-1990-14:27-r@n4hgf-version x0.12 seems bug free */
/*:06-17-1990-14:59-wht-creation */

#include "config.h"
#define M_TERMINFO
#include <curses.h>
#undef reg     /* per nba@sysware.sysware.dk */
#ifdef NATIVE_PANELS
# include <panel.h>
#else
# include "libpanel.h"
#endif
#include <sys/types.h>
#include <sys/var.h>
#include "u386mon.h"

/*+-------------------------------------------------------------------------
	display_var(win,y,x)
--------------------------------------------------------------------------*/
void
display_var(win,y,x)
WINDOW *win;
int y;
int x;
{
	use_cp(win,cpBANNER);
	wmove(win,y++,x);
	waddstr(win,"-- Var ---------");
	wmove(win,y++,x);
	disp_static_int(win,"v_autoup   ","%5d",v.v_autoup);
	wmove(win,y++,x);
	disp_static_int(win,"v_buf      ","%5d",v.v_buf);
	wmove(win,y++,x);
	disp_static_int(win,"v_clist    ","%5d",v.v_clist);
	wmove(win,y++,x);
	disp_static_int(win,"v_file     ","%5d",v.v_file);
	wmove(win,y++,x);
	disp_static_int(win,"v_hbuf     ","%5d",v.v_hbuf);
	wmove(win,y++,x);
	disp_static_int(win,"v_inode    ","%5d",v.v_inode);
	wmove(win,y++,x);
	disp_static_int(win,"v_maxpmem  ","%5d",v.v_maxpmem);
	wmove(win,y++,x);
	disp_static_int(win,"v_maxup    ","%5d",v.v_maxup);
	wmove(win,y++,x);
	disp_static_int(win,"v_mount    ","%5d",v.v_mount);
	wmove(win,y++,x);
	disp_static_int(win,"v_pbuf     ","%5d",v.v_pbuf);
	wmove(win,y++,x);
	disp_static_int(win,"v_proc     ","%5d",v.v_proc);
	wmove(win,y++,x);
	disp_static_int(win,"v_region   ","%5d",v.v_region);
	wmove(win,y++,x);
	disp_static_int(win,"v_vhndfrac ","%5d",v.v_vhndfrac);

}	/* end of display_var */

/* vi: set tabstop=4 shiftwidth=4: */
/* end of var.c */
