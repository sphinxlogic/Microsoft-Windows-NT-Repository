/*
 * Structure of a remote load packet (on top of UDP).
 * We use longs with 24 bits of resolution before the
 * decimal point, and 8 bits of resolution after the
 * decimal point.  This way, too, I don't have to worry
 * about whether or not a double is in some funny byte
 * order.  We also return a long representing our
 * relative cpu power (again, in fixed-point format).
 */

struct rload {
	long	avgs[3];
	long	cpuumph;	/* relative power of cpu */
};
