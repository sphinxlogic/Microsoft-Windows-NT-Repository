extern	int	memfd;
extern	int	kmemfd;
extern	int	swapfd;

#define	NM_V	0
#define	NM_FILE	1
#define	NM_INODE	2
#define	NM_PROC	3
#define	NM_TEXT	4
#define	NM_MOUNT	5
#define	NM_BUFFER	6
#define	NM_SWPLO	7
#define	NM_TIME		8
#define	NM_LBOLT	9
#define	NM_UTSNAME	10
#define	NM_USER		11
#define	NM_NAMES	12

extern	struct	xlist	namelist[];
extern	struct	var	v;
extern	struct	file	*files;
extern	struct	inode	*inodes;
extern	struct	text	*texts;
extern	struct	proc	*procs;
extern	struct	mount	*mounts;
extern	struct	buf	*bufs;
extern	struct	buf	*bufstart;
extern	struct	user	user;
extern	daddr_t	swplo;
extern	time_t	ktime;
extern	time_t	klbolt;
extern	struct	utsname	utsname;
