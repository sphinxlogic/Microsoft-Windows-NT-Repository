/*
 *
 * sec.c
 *
 * Grudgingly give out root shells to authorized users.
 *
 * Usage: sec
 *
 */

#include <stdio.h>
#include <syslog.h>
#include <strings.h>
#include "config.h"

int getline(file,s)
FILE *file;
char *s;
{
  while (((*s=getc(file))!=EOF) && (*s!='\n')) s++;
  if ((*s)==EOF) return 0;
  *s=0;
  return 1;
}

extern char *crypt();

char ckpw(b)
char *b;
{
  char *a,*encr,input[10];
  int f;

  if (!strlen(b))
  {
    printf("Null PW. Please use 'secpw' and add one.\n");
    return 1;
  }
  strcpy(input,getpass("Password:"));
  encr=crypt(input,b);
  return(!strcmp(encr,b));
}

main()
{
  FILE* f;
  char str[80],ok=0;

  f=fopen(FILENAME,"r");
  if (f!=NULL)
  {
    while(getline(f,str))
    {
      char b[16],*c;
      c=index(str,':');
      if (c==NULL) continue;
      strcpy(b,c+1);
      *c='\0';
      if (!strcmp(str,getlogin()))
        if (ckpw(b))
          ok=1;
    }
    fclose(f);
  }
  else
  {
    printf("Error reading file.\n");
    exit(1);
  }

  openlog("sec",0,LOG_FACILITY);

  if (ok)
  {
    syslog(LOG_OK_PRI,"security access: %s",getlogin());
    seteuid(0);
    setegid(0);
    setuid(0);
    setgid(0);
    execl("/bin/csh"," SEC",(char*)0);
  }
  else
  {
    syslog(LOG_FAIL_PRI,"security access DENIED: %s",getlogin());
    printf("Not Authorized.\n");
  }
}
