/*
 *
 * config.h for sec/secpw
 *
 */

/*

The first three definitions are for syslog. The first is the logging
facility code to use. LOG_FAIL_PRI is the priority to use when logging
a failure in authorization message. I.e. mistyped password, unauthorized
user, etc. LOG_OK_PRI is the priority to use when logging a successful
attempt.

*/

#define LOG_FACILITY LOG_AUTH
#define LOG_FAIL_PRI LOG_WARNING
#define LOG_OK_PRI LOG_NOTICE

/*

The next definition is the location of the security file, and the temporary
file for secpw to use. the temp file MUST be on the same file system as
the real file. rename() is used to move the temp to the real one when
the change is done. Just like vipw.

*/

#define FILENAME "/usr/adm/security"
#define TEMPNAME "/usr/adm/security.tmp"
#include <stdio.h>
