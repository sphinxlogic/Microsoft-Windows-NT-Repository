char *rcsversion=
"$Header: rman.c,v 1.3 88/10/03 11:58:23 reggers Exp $";

/*
 $Author: reggers $
 $Date: 88/10/03 11:58:23 $
 $Header: rman.c,v 1.3 88/10/03 11:58:23 reggers Exp $
 $Locker:  $
 $Revision: 1.3 $
 $Source: /usrs/guru/reggers/rman/RCS/rman.c,v $
 $State: Exp $

 This looks a lot like the rsh code (I'd bet) but we're only going to
 hit either man, or apropos, via the rsh sequence. And we're going to
 hit a particular user.
*/

#define	PAGER	"/usr/ucb/more"
#define	MANUSER	"man"
#define	MANHOST	"manhost"
#define	RSHPORT 514

#include	<stdio.h>
#include	<sysexits.h>
#include	<strings.h>

main(argc,argv)
int	argc;
char	*argv[];
{
	char	*cmd,*p,c;
	int	i,n,rem;

	if (p=rindex(argv[0],'/')) ++p;
	else	p= argv[0];

	cmd=(char *)malloc(n=(strlen(p)+1));	strcpy(cmd,p);

	if (strcmp(cmd,"man") && strcmp(cmd, "apropos"))
	{
		fprintf(stderr,"Usage: man topic\nor: apropos topic\n");
		exit(EX_USAGE);
	}

	for (i=1; argv[i]; i++)
	{
		cmd=(char *)realloc(cmd,n+=strlen(argv[i])+1);
		strcat(cmd," ");
		strcat(cmd,argv[i]);
	}

	p=MANHOST;

	if ((rem=rcmd(&p,RSHPORT,MANUSER,MANUSER,cmd,0)) < 0)
	{
		fprintf(stderr,"Oops... cannot connect to man server\n");
		exit(EX_UNAVAILABLE);
	}

	if (isatty(0) && isatty(1))
	{
		close(0);	dup(rem);
		execl(PAGER,PAGER,0);
		fprintf(stderr,"\"%s\" not found!\n",PAGER);
		exit(EX_UNAVAILABLE);
	}
    	while (read(rem,&c,1) == 1) fputc(c,stdout);
	exit(0);
}
