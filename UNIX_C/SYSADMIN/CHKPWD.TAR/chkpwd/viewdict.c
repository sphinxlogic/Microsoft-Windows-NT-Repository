/*
 *	viewdict - View DBM version of a password dictionary
 */

#include <sys/file.h>
#include <ndbm.h>

main(argc, argv)
char	*argv[];
{
	DBM	*dp;
	datum	k;
	char	t[128];

	if ((dp = dbm_open(argv[1], O_RDONLY, 0)) == 0) {
		perror(argv[1]);
		exit(1);
	}
	for (k = dbm_firstkey(dp); k.dptr != 0; k = dbm_nextkey(dp)) {
		strncpy(t, k.dptr, k.dsize);
		t[k.dsize] = 0;
		printf("%s\n", t);
	}
	exit(0);
}
