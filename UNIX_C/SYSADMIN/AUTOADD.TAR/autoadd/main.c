#define MAIN
#include "autoadd.h"

main(argc,argv)
int argc;
char *argv[];
{
	char systemline[100],profilename[100],directory[100],shellname[100];
	char answer[9];
	int i,j,k,how,nextu,unum,maxunum,groupnumber,firstalias,cshell;
	extern int geteuid();
	FILE *fp1,*fp2,*fp3,*fp4,*fopen();
	long time();
	void srand(); /*to make lint shut up*/

/*some executable initializations:*/
	euid=geteuid(); /*should be first executable stmt*/
	initfiles(); /*executably set sensitive filenames*/
	strcpy(groupname,GROUP); /*100 our default group*/
	strcpy(diskname,DISK);   /* /usr our default disk*/
	strcpy(shellname,SHELL);
	strcpy(aliasname,ALIAS); 
	strcpy(firstprog,FIRSTPROG);
	strcpy(profname,PROFESSOR);
	strcpy(passwordname,PASSWD);
	strcpy(dislist,DISLIST);
	firstalias=cshell=0; 
	for(i=0;i<MAXNU;++i)user[i]=NULL;
	srand((unsigned int)time(0L));

/*open the password file in read mode to see who's already there */
	fp1=fopen("/etc/passwd","r");
	if(fp1==NULL)quit("/etc/passwd");
	j=0;
	maxunum= -1;
	while(fgets(line,120,fp1)==line){
		i=kindex(line,":");
		line[i]='\0';
		k=i+1;
		while(line[k]!=':')k++;
		sscanf(&line[k+1],"%d",&unum);
		if(unum>maxunum)maxunum=unum;
		user[j]=malloc((unsigned)i+1);
		strcpy(user[j],line);
		j++;
	}
	nextu=j;
	if(fclose(fp1)<0)quit("/etc/passwd");
/* thru reading /etc/passwd */
	if(argc>=2)
		strcpy(infile,argv[1]);
	else{
		printf("input filename:");
		scanf("%s",infile);
	}
/* open the input file in read mode */
	fp1=fopen(infile,"r");
	if(fp1==NULL)quit(infile);
/* open /etc/passwd in append mode */
	fp2=fopen(passwd,"a");
	if(fp2==NULL)quit(passwd);
#ifdef ACCESS
/* open /etc/accesstab in append mode */
	fp3=fopen(proffile,"a");
	if(fp3==NULL)quit(proffile);
#endif
	profname[0]=null;
/* open mailrc in append mode */
	fp4=fopen(dislist,"a");
	if(fp4==NULL)quit(dislist);
/* process input file */
	while(fgets(line,120,fp1)==line){
		if(*line==' ' || *line=='#' || *line=='\n' || *line==null)
			continue;
		for(i=0;line[i];i++)if(line[i]<' '){
			line[i]='\0';
			break;
		}
#ifdef ACCESS
		if((i=kindex(line,"prof:"))>=0){
			strcpy(profname,&line[i+strlen("prof:")]);
		}
		else
#endif

		 if((i=kindex(line,"disk:"))>=0){
			strcpy(diskname,&line[i+strlen("disk:")]);
			if(diskname[0]!='/'){
				strcpy(diskname,"/");
				strcat(diskname,&line[i+strlen("disk:")]);}
			if(euid!=ROOT){
				strcpy(parentdir,".");
				strcat(parentdir,diskname);} 
			else 
				strcpy(parentdir,diskname);
			if(!exists(parentdir)){
				/*if not root, don't bother asking, just do it */
				if(euid==ROOT){
					printf(
					"%s doesn't seem to exist, shall I mkdir it?(y/n): "
						,parentdir);
					scanf("%s",answer);
					if(kindex(answer,"y")!=0)quit(parentdir);
				}
				/*else{*/
					strcpy(systemline,"mkdir ");
					strcat(systemline,parentdir);
					system(systemline);
					if(!exists(parentdir))quit(parentdir);
				/*}*/
			}
		}

		else if((i=kindex(line,"firstprog:"))>=0){
			strcpy(firstprog,&line[i+strlen("firstprog:")]);
		}
		else if((i=kindex(line,"alias:"))>=0){
			strcpy(aliasname,&line[i+strlen("alias:")]);
			if(aliasname[0]!='0'){
				fprintf(fp4,
				    firstalias?"\nalias %s ":"alias %s ",aliasname);
				firstalias=1;
			}
		}


		else if((i=kindex(line,"group:"))>=0){
			strcpy(groupname,&line[i+strlen("group:")]);
			sscanf(groupname,"%d",&groupnumber);
		}

		else if((i=kindex(line,"shell:"))>=0){
			strcpy(shellname,&line[i+strlen("shell:")]);
			if(kindex(shellname,"csh")>0)cshell=1;else cshell=0;
		}

		else if((i=kindex(line,"passwd:"))>=0){
			strcpy(passwordname,&line[i+strlen("passwd:")]);
		}

		else if((i=kindex(line,"password:"))>=0){
			strcpy(passwordname,&line[i+strlen("password:")]);
		}
		else{
			if(kindex(line,":")>=0){
				printf("IGNORED:%s\n",line);continue;}
			parse();
			strcpy(username,lastname);
			how=0;
for(;;){
			strcpy(directory,parentdir);
			strcat(directory,"/");
			strcat(directory,username);
			if(exists(directory) || already(username))
			{
				tryagain(how);
				username[ML]=null;
				how++;
			}
			else
				break;
}
				strcpy(systemline,"mkdir ");
				strcat(systemline,directory);
				system(systemline);
				if(!exists(directory))quit(directory);/*failed*/
			
			
			user[nextu]=malloc((unsigned)strlen(username)+1);
			strcpy(user[nextu],username);
			nextu++;

			if(passwordname[0]=='0' || passwordname[0]==null)
				ecptex[0]=null;
			else if (passwordname[0] == '1')
				ecpw(username);
			else
				ecpw(passwordname); 

			fprintf(fp2,"%s:%s:%d:%s:%s:%s/%s:%s\n"
			    ,username,ecptex,++maxunum,groupname,line,
			    diskname,username,shellname[0]!='0'?shellname:"");
			if(aliasname[0]!='0')
				fprintf(fp4,"\\\n%s ",username);/*for dislist*/

			unum=maxunum;
#ifdef ACCESS
			if(*profname&&*profname!='0')
				fprintf(fp3,"%s:%s\n",profname,username);
#endif

			strcpy(profilename,directory);
			strcat(profilename,cshell?LOGIN:PROFILE);
			if(!exists(profilename)){
			strcpy(systemline,"cp ");
			strcat(systemline,STDPROFILE /*"/etc/stdprofile "*/);
			strcat(systemline," "); /*just in case*/
			strcat(systemline,profilename);
			system(systemline);
				if(firstprog[0]!='0'){
					strcpy(systemline,"echo ");
					strcat(systemline,firstprog);
					strcat(systemline," >> ");
					strcat(systemline,profilename);
					system(systemline);
				}
			}
			if(euid==ROOT){
			/*do the chowns only if running as root (effective uid)*/
				if(chown(directory,unum,groupnumber)<0)quit(directory);
				if(chown(profilename,unum,3 /*3=="sys"*/)<0)
					quit(profilename);
			}


		}
	} /*end of file on input file */
	if(firstalias)
		fprintf(fp4,"\n");/*close out the last line of dislist*/
	return 0; /* lint */
}
