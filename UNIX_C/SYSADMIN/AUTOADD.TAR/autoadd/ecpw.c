
char salts[63]= /*must be 63 to leave room for the null*/
"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
/*1234567890123456789012345678901234567890123456789012345678901*/
/*0000000001111111111222222222233333333334444444444555555555566*/
/* don't use / or . because one manual says one thing, and the other
  manual says another thing.  stick with letters and digits for salt.
*/

ecpw(pwd)
char *pwd;
{
	/*side effect: modifies ecptex*/
	extern char ecptex[];
	void extern exit();
	char *result,*crypt();
	char salt[3];
	salt[0]=salts[rand()%62];
	salt[1]=salts[rand()%62];
	salt[2]='\0';

	result=crypt(pwd,salt);
	(void) strcpy(ecptex,result);
}
