#include "autoadd.h"
initfiles()
{
	extern int euid;
	extern char passwd[], proffile[];
	if(euid==ROOT){
		strcpy(passwd,"/etc/passwd");
		strcpy(proffile,"/etc/accesstab");}
	else{
		strcpy(passwd,"passwd");
		strcpy(proffile,"accesstab");}
}
