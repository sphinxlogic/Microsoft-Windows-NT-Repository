#include "autoadd.h"
tryagain(how)
{
	extern char fi[],lastname[],mi[],username[];
	char temp[49];
switch(how){
case 0:
	strcpy(temp,fi);
	strcat(temp,lastname);
	break;
case 1:
	strncpy(temp,lastname,ML-1);
	temp[ML-1]='\0';
	strcat(temp,fi);
	break;
case 2:
	strncpy(temp,lastname,ML-2);
	temp[ML-2]='\0';
	strcat(temp,fi);
	strcat(temp,mi);
	break;
case 3:
	strcpy(temp,fi);
	strcat(temp,mi);
	strcat(temp,lastname);
	break;
case 4:
	strcpy(temp,fi);
	strncat(temp,lastname,ML-2);
	temp[ML-1]='\0';
	strcat(temp,mi);
	break;
default:
	sprintf(temp,"%d%s",how>4?how-4+1:how /*this 4 is dangerous*/
	,lastname);
	break;
}
/*	temp[ML]='\0';*/ /* let main do it!*/
	strcpy(username,temp);
}
