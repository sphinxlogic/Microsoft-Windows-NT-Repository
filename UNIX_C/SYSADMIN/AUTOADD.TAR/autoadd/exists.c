
#ifndef ENOENT
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#endif
exists(filename)
char *filename;
{
	extern int errno;
	struct stat buf;
	if(stat(filename,&buf)== -1 && errno==ENOENT)return 0;
	return 1;
}
