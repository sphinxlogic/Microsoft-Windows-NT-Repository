
#ifndef NULL
#include <stdio.h>
#endif
already(p)
char *p;
{
	int i;
	extern char *user[];
	i=0;
	/*printf("in already, looking for ...%s...",p);*/
	while(user[i]!=NULL){
		if(strcmp(p,user[i])==0){/*printf("found at %d...",i);*/
		return 1;}
		i++;
	}
	/*printf("not found, i=%d...",i);*/
	return 0;
}
