kindex(s,t) 
char s[],t[];
{
	extern void exit();
/* slightly beefed up version of "index" from the middle
of p. 67 K&R */
	int c,i,j,k;
	c=s[0];
	if(c==0){i=puts("in kindex ... dummy, s[0] is zero");j=i;
		puts(t);
		if(i==j)exit(1);}
	c=t[0];
	if(c==0){i=puts("in kindex ... dummy, t[0] is zero");j=i;
		puts(s);
		if(j==i)exit(1);}
	for(i=0;s[i] !='\0'; i++){
		for(j=i,k=0;t[k] !='\0' && s[j]==t[k];j++,k++)
				;
		if(t[k]=='\0')return (i);
	}
		return(-1);
} 

