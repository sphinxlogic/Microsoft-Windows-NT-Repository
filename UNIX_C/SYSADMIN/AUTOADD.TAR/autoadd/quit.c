quit(p)
char *p;
{
	extern void exit();
	puts(
"******* something went wrong here that I can't figure out********"
	);
	puts(p);
	puts("I'm outta here...");
	exit(1);
}
