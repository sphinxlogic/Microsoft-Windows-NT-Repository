


#include "autoadd.h"
parse()
{
	int i=0;
	int j;
	extern char lastname[],fi[],mi[],line[];
	lastname[0]=mi[0]=fi[0]='1';
	lastname[ML]=fi[1]=mi[1]=null;
	j=strlen(line);
	while(line[i]==' ' && i<j)i++;
	while(line[i] && line[i]!=' ' && i<ML && i<j)
		{lastname[i]=line[i];i++;}
	lastname[i]=lastname[ML]='\0';
	if(i>=j)return;
	while(line[i]!=' ' && i<j)i++;
	while(line[i]==' ' && i<j)i++;
	if(i>=j)return;
	fi[0]=line[i++];
	fi[1]='\0';
	if(i>=j)return;
	while(line[i]!=' ' && i<j)i++;
	while(line[i]==' ' && i<j)i++;
	if(line[i])mi[0]=line[i];
	mi[1]='\0';
}

