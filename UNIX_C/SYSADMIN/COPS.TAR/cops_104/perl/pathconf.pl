$YPCAT = '/usr/bin/ypcat';
$STRINGS = '/usr/ucb/strings';
$TFTP = '/usr/ucb/tftp';
$UUDECODE = '/usr/bin/uudecode';
$CMP = '/bin/cmp';
$LS = '/bin/ls';

# end of perl needed programs

$AWK = '/bin/awk';
$CAT = '/bin/cat';
$CC = '/bin/cc';
$CHMOD = '/bin/chmod';
$COMM = '/usr/bin/comm';
$CP = '/bin/cp';
$DATE = '/bin/date';
$DIFF = '/bin/diff';
$ECHO = '/bin/echo';
$EGREP = '/usr/bin/egrep';
$EXPR = '/bin/expr';
$FIND = '/usr/bin/find';
$GREP = '/bin/grep';
$MAIL = '/bin/mail';
$MKDIR = '/bin/mkdir';
$MV = '/bin/mv';
$RM = '/bin/rm';
$SED = '/bin/sed';
$SH = '/bin/sh';
$SORT = '/usr/bin/sort';
$TEST = '/bin/test';
$TOUCH = '/usr/bin/touch';
$UNIQ = '/usr/bin/uniq';

1;
