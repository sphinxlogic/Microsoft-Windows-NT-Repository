#ifndef lint
static char *RCSid = "$Header: /ecn1/src/ecn/statsrv/RCS/getuserstats.c,v 1.4 88/04/12 10:21:16 davy Exp $";
#endif
/*
 * getuserstats - get user statistics
 *
 * David A. Curry
 * Purdue University
 * Engineering Computer Network
 * davy@intrepid.ecn.purdue.edu
 * October, 1987
 *
 * $Log:	getuserstats.c,v $
 * Revision 1.4  88/04/12  10:21:16  davy
 * Added code for "actwho" statistic.
 * 
 * Revision 1.3  87/12/08  14:39:06  davy
 * Added code for the "who" statistic.
 * 
 * Revision 1.2  87/10/29  14:24:36  davy
 * Modified to use UTMP instead of hard-coded path.
 * 
 * Revision 1.1  87/10/17  21:01:40  davy
 * Initial revision
 * 
 */
#include <sys/param.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <syslog.h>
#include <stdio.h>
#include <utmp.h>

#define WHO		0
#define USERS		1
#define ACTWHO		2
#define ACTUSERS	3

#define UTMP		"/etc/utmp"
#define USERBUFSIZE	2048		/* 256 8-char logins		*/

extern	int (*fn_recv)(), (*fn_send)();	/* send/recv functions		*/

/*
 * getuserstats - get user statistics
 */
getuserstats(name)
char *name;
{
	FILE *fp;
	char buf[32];
	struct utmp ut;
	struct stat st;
	struct timeval tv;
	register int cnt, mode;
	char userbuf[USERBUFSIZE];

	/*
	 * "actusers" means we only want active users.
	 * "who" means we want user names.
	 */
	if (!strcmp(name, "actusers"))
		mode = ACTUSERS;
	else if (!strcmp(name, "users"))
		mode = USERS;
	else if (!strcmp(name, "who"))
		mode = WHO;
	else
		mode = ACTWHO;

	if ((fp = fopen(UTMP, "r")) == NULL) {
		syslog(LOG_ERR, "cannot open %s", UTMP);
		exit(1);
	}

	*userbuf = NULL;
	gettimeofday(&tv, (struct timeval *) 0);

	/*
	 * For each user...
	 */
	cnt = 0;
	while (fread(&ut, sizeof(struct utmp), 1, fp) == 1) {
		/*
		 * Not logged in.
		 */
		if (ut.ut_name[0] == NULL)
			continue;

		/*
		 * For active users, see how long he's been idle.
		 */
		if ((mode == ACTUSERS) || (mode == ACTWHO)) {
			sprintf(buf, "/dev/%.8s", ut.ut_line);

			if (stat(buf, &st) < 0)
				continue;

			/*
			 * If idle less than 1 hour, he's active.
			 */
			if ((tv.tv_sec - st.st_atime) < 3600) {
				if (mode == ACTWHO) {
					sprintf(buf, "%.8s ", ut.ut_name);
					strcat(userbuf, buf);
				}

				cnt++;
			}
		}
		else {
			/*
			 * Copy the login name if needed.
			 */
			if (mode == WHO) {
				sprintf(buf, "%.8s ", ut.ut_name);
				strcat(userbuf, buf);
			}

			cnt++;
		}
	}

	/*
	 * Send the appropriate buffer.
	 */
	if ((mode == WHO) || (mode == ACTWHO)) {
		strcat(userbuf, "\n");
		(*fn_send)(0, userbuf);
	}
	else {
		sprintf(buf, "%d\n", cnt);
		(*fn_send)(0, buf);
	}

	fclose(fp);
}
