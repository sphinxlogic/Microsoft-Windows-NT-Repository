#ifndef lint
static char *RCSid = "$Header: /ecn1/src/ecn/statsrv/RCS/st_sendrecv.c,v 1.2 87/10/19 08:37:02 davy Exp $";
#endif
/*
 * st_sendrecv.c - stream send/recv functions
 *
 * David A. Curry
 * Purdue University
 * Engineering Computer Network
 * davy@intrepid.ecn.purdue.edu
 * October, 1987
 *
 * $Log:	st_sendrecv.c,v $
 * Revision 1.2  87/10/19  08:37:02  davy
 * Fixed to catch end of file on socket.
 * 
 * Revision 1.1  87/10/17  21:01:46  davy
 * Initial revision
 * 
 */
#include <sys/param.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <syslog.h>
#include <stdio.h>

#include "stats.h"

extern char	*pname;
extern short	server;

/*
 * st_send - send buf on the socket s.
 */
st_send(s, buf)
char *buf;
int s;
{
	register int cnt;

	/*
	 * We want the length including the null.
	 */
	cnt = strlen(buf) + 1;

	/*
	 * Send the buffer.
	 */
	if (send(s, buf, cnt, 0) < 0) {
		if (server)
			syslog(LOG_ERR, "send: %m");
		else
			error("send");
		exit(1);
	}
}

/*
 * st_recv - receive data of maximum length cnt into the buffer buf on
 *	     socket s.  err describes what we're expecting for the error
 *	     message.
 */
st_recv(s, buf, cnt, err)
char *buf, *err;
int s, cnt;
{
	char c;
	register int n;

	/*
	 * Receive a character at a time up to a null.
	 */
	do {
		if ((n = recv(s, &c, sizeof(char), 0)) < 0) {
			if (server)
				syslog(LOG_ERR, "recv: %m");
			else
				error("recv");
			exit(1);
		}

		/*
		 * End of file.
		 */
		if (n == 0)
			exit(0);

		if (--cnt < 0) {
			if (server)
				syslog(LOG_ERR, "%s too long", err);
			else
				fprintf(stderr, "%s: %s too long.\n", pname, err);
			exit(1);
		}

		*buf++ = c;
	} while (c != '\0');
}
