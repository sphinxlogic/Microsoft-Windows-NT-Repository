/*
 * $Header: /ecn1/src/ecn/statsrv/RCS/stats.h,v 1.2 87/12/17 14:54:27 davy Exp $
 *
 * stats.h - definitions for statistics server
 *
 * David A. Curry
 * Purdue University
 * Engineering Computer Network
 * davy@intrepid.ecn.purdue.edu
 * October, 1987
 *
 * $Log:	stats.h,v $
 * Revision 1.2  87/12/17  14:54:27  davy
 * Added defines for VMUNIX and KMEM.
 * 
 * Revision 1.1  87/10/17  21:01:03  davy
 * Initial revision
 * 
 */

#define SERVNAME	"statsrv"	/* name of our service		*/
#define MAXDGRAM	576		/* maximum size of a datagram	*/

#define KMEM		"/dev/kmem"	/* path to kernel memory	*/

#if vax || sun || gould || tahoe
#define VMUNIX		"/vmunix"	/* path to kernel		*/
#endif
#if sequent
#define VMUNIX		"/dynix"
#endif

/*
 * For 4.2BSD syslogs.
 */
#ifndef LOG_DAEMON
#define LOG_DAEMON	(3<<3)
#endif

extern int st_send(), st_recv();	/* stream send/recv functions	*/
extern int dg_send(), dg_recv();	/* datagram send/recv functions	*/
