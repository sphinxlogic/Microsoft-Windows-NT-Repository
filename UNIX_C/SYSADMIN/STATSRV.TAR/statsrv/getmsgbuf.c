#ifndef lint
static char *RCSid = "$Header: /u5/davy/system/statsrv/RCS/getmsgbuf.c,v 1.4 88/10/06 10:55:14 davy Exp $";
#endif
/*
 * getmsgbuf - get the message buffer from the kernel
 *
 * David A. Curry
 * Purdue University
 * Engineering Computer Network
 * davy@intrepid.ecn.purdue.edu
 * January, 1988
 *
 * $Log:	getmsgbuf.c,v $
 * Revision 1.4  88/10/06  10:55:14  davy
 * Modified for Sun 4.0.
 * 
 * Revision 1.3  88/01/02  15:20:52  davy
 * Modified to work on Sequents.
 * 
 * Revision 1.2  88/01/02  13:31:23  davy
 * Fixes for stupid vendors like Gould who can't leave Berkeley well
 * enough alone.
 * 
 * Revision 1.1  88/01/02  12:45:57  davy
 * Initial revision
 * 
 */
#include <sys/param.h>
#if sequent
#include <sys/ioctl.h>
#include <sec/sec.h>
#else
#include <sys/msgbuf.h>
#endif
#include <sys/file.h>
#include <syslog.h>
#if SUN4_0
#include <kvm.h>
#include <fcntl.h>
#endif
#include <nlist.h>
#include <stdio.h>
#include "stats.h"

static struct nlist nl[] = {
#define X_MSGBUF	0
#if vax || sun || tahoe
	{	"_msgbuf"	},
#endif
#if GOULD_PN
	{	"_cmsgbuf"	},
#endif
#if GOULD_NP1
	{	"_cmsgbufloc"	},
#endif
	{	0		}
};

extern int (*fn_recv)(), (*fn_send)(); /* send/recv functions		*/

/*
 * getmsgbuf - get the message buffer from the kernel
 */
getmsgbuf(name)
char *name;
{
#if SUN4_0
	kvm_t *kd;
#else
	int kmem;
#endif
	int sawnl, ignore;
	register char *s, *t;
#if sequent
	int len;
	char *malloc();
	struct sec_mem sm;
	char *buf, *tmpbuf, *bufstart;
#else
#if SUN4_0
	int msgbufsize;
	struct msgbuf *msgbuf;
	struct msgbuf_hd msgbuf_hd;
#else
	struct msgbuf msgbuf;
#endif
	char buf[MSG_BSIZE+1];
#endif
#if GOULD_NP1
	struct msgbuf *cmsgbufloc;
#endif

#if sequent
	/*
	 * Sequent doesn't use a message buffer; instead they
	 * read stuff out of the SCSI console device.  Yuck.
	 */
	if ((kmem = open("/dev/smemco", O_RDONLY)) < 0) {
		syslog(LOG_ERR, "open: /dev/smemco: %m");
		exit(1);
	}

	/*
	 * Find out the size of stuff.
	 */
	if (ioctl(kmem, SMIOGETLOG, &sm) < 0) {
		syslog(LOG_ERR, "ioctl: SMIOGETLOG: %m");
		exit(1);
	}

	/*
	 * Get some memory.
	 */
	if ((tmpbuf = malloc(sm.mm_size)) == NULL) {
		syslog(LOG_ERR, "cannot allocate %d bytes of memory.", sm.mm_size);
		exit(1);
	}

	if ((buf = malloc(sm.mm_size+2)) == NULL) {
		syslog(LOG_ERR, "cannot allocate %d bytes of memory.", sm.mm_size);
		exit(1);
	}

	/*
	 * Read the console information.
	 */
	lseek(kmem, (long) sm.mm_buffer, L_SET);
	read(kmem, (char *) tmpbuf, sm.mm_size);

	bufstart = &tmpbuf[(int) sm.mm_nextchar - (int) sm.mm_buffer];
	s = bufstart;
	t = buf;

	sawnl = 1;
	ignore = 0;

	/*
	 * Copy the info.  It's a circular buffer, hence all
	 * this stuff.
	 */
	do {
		if ((sawnl == 1) && (*s == '<'))
			ignore = 1;
		if ((*s != NULL) && ((*s & 0200) == 0) && (ignore == 0))
			*t++ = *s;
		if ((ignore == 1) && (*s == '>'))
			ignore = 0;

		sawnl = (*s++ == '\n');

		if (s >= &tmpbuf[sm.mm_size])
			s = tmpbuf;
	} while (s != bufstart);

	*t = NULL;

#else sequent
#if SUN4_0
	/*
	 * Open kmem.
	 */
	if ((kd = kvm_open(VMUNIX, NULL, NULL, O_RDONLY, NULL)) == NULL) {
		syslog(LOG_ERR, "open: %s: %m", KMEM);
		exit(1);
	}

	/* 
	 * Read kernel namelist.
	 */
	if ((kvm_nlist(kd, nl) < 0) || (nl[0].n_type == 0)) {
		syslog(LOG_ERR, "%s: no namelist", VMUNIX);
		exit(1);
	}

	kvm_read(kd, (long) nl[X_MSGBUF].n_value, (char *) &msgbuf_hd, sizeof(msgbuf_hd));

	if (msgbuf_hd.msgh_magic != MSG_MAGIC) {
		syslog(LOG_ERR, "msgbuf magic number mismatch.");
		exit(1);
	}

	msgbufsize = sizeof(struct msgbuf_hd) + msgbuf_hd.msgh_size;

	if ((msgbuf = (struct msgbuf *) malloc(msgbufsize)) == NULL) {
		syslog(LOG_ERR, "cannot allocate %d bytes of msgbuf memory.", msgbufsize);
		exit(1);
	}

	kvm_read(kd, (long) nl[X_MSGBUF].n_value, (char *) msgbuf, msgbufsize);

	if ((msgbuf->msg_bufx < 0) || (msgbuf->msg_bufx >= msgbuf_hd.msgh_size))
		msgbuf->msg_bufx = 0;

	s = &msgbuf->msg_bufc[msgbuf->msg_bufx];
	t = buf;

	sawnl = 1;
	ignore = 0;

	/*
	 * Copy the message buffer.  It's a circular buffer,
	 * hence all this.
	 */
	do {
		if ((sawnl == 1) && (*s == '<'))
			ignore = 1;
		if ((*s != NULL) && ((*s & 0200) == 0) && (ignore == 0))
			*t++ = *s;
		if ((ignore == 1) && (*s == '>'))
			ignore = 0;

		sawnl = (*s++ == '\n');

		if (s >= &msgbuf->msg_bufc[msgbuf_hd.msgh_size])
			s = msgbuf->msg_bufc;
	} while (s != &msgbuf->msg_bufc[msgbuf->msg_bufx]);

	*t = NULL;
#else SUN4_0
	/*
	 * Open kmem.
	 */
	if ((kmem = open(KMEM, O_RDONLY)) < 0) {
		syslog(LOG_ERR, "open: %s: %m", KMEM);
		exit(1);
	}

	/* 
	 * Read kernel namelist.
	 */
	if ((nlist(VMUNIX, nl) < 0) || (nl[0].n_type == 0)) {
		syslog(LOG_ERR, "%s: no namelist", VMUNIX);
		exit(1);
	}

	lseek(kmem, (long) nl[X_MSGBUF].n_value, L_SET);

#if GOULD_NP1
	/*
	 * For some reason, Gould has made _cmsgbufloc a pointer
	 * to msgbuf.  Yeeesh.
	 */
	read(kmem, (char *) &cmsgbufloc, sizeof(cmsgbufloc));
	lseek(kmem, (long) cmsgbufloc, L_SET);
#endif GOULD_NP1

	read(kmem, (char *) &msgbuf, sizeof(msgbuf));

	if (msgbuf.msg_magic != MSG_MAGIC) {
		syslog(LOG_ERR, "msgbuf magic number mismatch.");
		exit(1);
	}

	if ((msgbuf.msg_bufx < 0) || (msgbuf.msg_bufx >= MSG_BSIZE))
		msgbuf.msg_bufx = 0;

	s = &msgbuf.msg_bufc[msgbuf.msg_bufx];
	t = buf;

	sawnl = 1;
	ignore = 0;

	/*
	 * Copy the message buffer.  It's a circular buffer,
	 * hence all this.
	 */
	do {
		if ((sawnl == 1) && (*s == '<'))
			ignore = 1;
		if ((*s != NULL) && ((*s & 0200) == 0) && (ignore == 0))
			*t++ = *s;
		if ((ignore == 1) && (*s == '>'))
			ignore = 0;

		sawnl = (*s++ == '\n');

		if (s >= &msgbuf.msg_bufc[MSG_BSIZE])
			s = msgbuf.msg_bufc;
	} while (s != &msgbuf.msg_bufc[msgbuf.msg_bufx]);

	*t = NULL;
#endif SUN4_0
#endif sequent

	/*
	 * If they asked for "msgtail" then only give them
	 * the last fifteen lines of the message buffer.
	 * Otherwise, give them the whole thing.
	 */
	if (!strcmp(name, "msgtail")) {
		for (sawnl = 0; (t >= buf) && (sawnl < 16); t--) {
			if (*t == '\n')
				sawnl++;
		}

		t += 2;
	}
	else {
#if sequent
		/*
		 * Sequents save HUGE amounts of stuff!
		 */
		len = strlen(buf);

		if (len > 4096) {
			t = &buf[len - 4096];
			while ((*t != NULL) && (*t != '\n'))
				t++;
			t++;
		}
		else
#endif
		t = buf;
	}

	(*fn_send)(0, t);
#if SUN4_0
	kvm_close(kd);
#else
	close(kmem);
#endif

#if SUN4_0
	free(msgbuf);
#endif
#if sequent
	free(tmpbuf);
	free(buf);
#endif
}
