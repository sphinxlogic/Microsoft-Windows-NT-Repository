#ifndef lint
static char *RCSid = "$Header: /ecn1/src/ecn/statsrv/RCS/dg_sendrecv.c,v 1.1 87/10/17 21:01:12 davy Exp $";
#endif
/*
 * dg_sendrecv.c - datagram send/recv functions
 *
 * David A. Curry
 * Purdue University
 * Engineering Computer Network
 * davy@intrepid.ecn.purdue.edu
 * October, 1987
 *
 * $Log:	dg_sendrecv.c,v $
 * Revision 1.1  87/10/17  21:01:12  davy
 * Initial revision
 * 
 */
#include <sys/param.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <syslog.h>
#include <stdio.h>

#include "stats.h"

extern char	*pname;			/* program name			*/
extern short	server;			/* 1 if server, 0 if client	*/
extern struct 	sockaddr_in sin;	/* address of remote host	*/

/*
 * dg_send - send buf as a datagram to the address in sin~r on socket s.
 */
dg_send(s, buf)
char *buf;
int s;
{
	register int cnt;

	/*
	 * We want the length including the null.
	 */
	cnt = strlen(buf) + 1;

	/*
	 * According to RFC996, can be no larger than MAXDGRAM.
	 */
	if (cnt > MAXDGRAM) {
		if (server) {
			strcpy(buf, "output length too long for datagram.\n");
			cnt = strlen(buf) + 1;
		}
		else {
			fprintf(stderr, "%s: string too long for datagram.\n", pname);
			exit(1);
		}
	}

	/*
	 * Send the datagram.
	 */
	if (sendto(s, buf, cnt, 0, &sin, sizeof(struct sockaddr_in)) < 0) {
		if (server)
			syslog(LOG_ERR, "sendto: %m");
		else
			error("sendto");
		exit(1);
	}
}

/*
 * dg_recv - receive a datagram of maximum size cnt into buf from the address
 *	     in sin on socket s.
 */
dg_recv(s, buf, cnt)
int s, cnt;
char *buf;
{
	int len;

	len = sizeof(struct sockaddr_in);

	/*
	 * Receive the datagram.
	 */
	if (recvfrom(s, buf, cnt, 0, &sin, &len) < 0) {
		if (server)
			syslog(LOG_ERR, "recvfrom: %m");
		else
			error("recvfrom");
		exit(1);
	}
}
