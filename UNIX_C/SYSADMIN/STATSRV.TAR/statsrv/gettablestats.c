#ifndef lint
static char *RCSid = "$Header: /ecn1/src/ecn/statsrv/RCS/gettablestats.c,v 1.1 87/12/08 14:40:03 davy Exp $";
#endif
/*
 * gettablestats - get internal table statistics
 *
 * David A. Curry
 * Purdue University
 * Engineering Computer Network
 * davy@intrepid.ecn.purdue.edu
 * December, 1987
 *
 * $Log:	gettablestats.c,v $
 * Revision 1.1  87/12/08  14:40:03  davy
 * Initial revision
 * 
 */
#include <sys/param.h>
#include <syslog.h>
#include <stdio.h>

#define PSTAT		"/etc/pstat"

extern	int (*fn_recv)(), (*fn_send)();	/* send/recv functions		*/

/*
 * gettablestats - get internal table statistics
 */
gettablestats(name)
char *name;
{
	int pid;
	int pf[2];
	char *flag;
	register int cnt;
	char buf[10 * BUFSIZ];
	register char *s, *ebuf;

	/*
	 * Different stats get different flags.
	 */
	if (!strcmp(name, "tables"))
		flag = "-T";

	if (pipe(pf) < 0) {
		syslog(LOG_ERR, "pipe: %m");
		exit(1);
	}

	/*
	 * Start a child.
	 */
	if ((pid = vfork()) < 0) {
		syslog(LOG_ERR, "fork: %m");
		exit(1);
	}

	/*
	 * Run the command.
	 */
	if (pid == 0) {
		close(pf[0]);

		dup2(pf[1], 1);
		close(pf[1]);

		execl(PSTAT, "pstat", flag, 0);
		syslog(LOG_ERR, "exec: %m");
		exit(1);
	}

	close(pf[1]);

	/*
	 * Read from the pipe.
	 */
	s = buf;
	ebuf = &buf[sizeof(buf) - 1];
	while ((cnt = read(pf[0], s, (int) (ebuf - s))) > 0) {
		s += cnt;

		if (s > ebuf) {
			syslog(LOG_ERR, "output from %s %s too big", PSTAT, flag);
			s = ebuf;
			break;
		}
	}

	*s = '\0';
	(*fn_send)(0, buf);

	close(pf[0]);

	/*
	 * Pick up the child.
	 */
	while (wait((int *) 0) >= 0)
		;
}
