#ifndef lint
static char *RCSid = "$Header: /u5/davy/system/statsrv/RCS/gettimestats.c,v 1.4 88/10/06 10:55:18 davy Exp $";
#endif
/*
 * gettimestats - get time-related statistics
 *
 * David A. Curry
 * Purdue University
 * Engineering Computer Network
 * davy@intrepid.ecn.purdue.edu
 * October, 1987
 *
 * $Log:	gettimestats.c,v $
 * Revision 1.4  88/10/06  10:55:18  davy
 * Modified for Sun 4.0.
 * 
 * Revision 1.3  87/10/29  15:03:57  davy
 * Fixed bug with timezone printing.
 * 
 * Revision 1.2  87/10/29  14:25:03  davy
 * Modified to use VMUNIX and KMEM instead of hard-coded paths.
 * 
 * Revision 1.1  87/10/17  21:01:34  davy
 * Initial revision
 * 
 */
#include <sys/param.h>
#include <sys/file.h>
#include <sys/time.h>
#include <syslog.h>
#if SUN4_0
#include <kvm.h>
#include <fcntl.h>
#endif
#include <nlist.h>
#include <stdio.h>
#include "stats.h"

static struct nlist nl[] = {
#define X_BOOTTIME	0
	{	"_boottime"	},
	{	0		}
};

extern	int (*fn_recv)(), (*fn_send)();	/* send/recv functions		*/

/*
 * gettimestats - get time-related statistics
 */
gettimestats(name)
char *name;
{
#if SUN4_0
	kvm_t *kd;
#else
	int kmem;
#endif
	struct timezone tz;
	struct timeval curtime, boottime;

	/*
	 * Get current date and time.
	 */
	gettimeofday(&curtime, &tz);

	/*
	 * If we're doing "date" or "time", we just print
	 * out the current date and time.
	 */
	if (!strcmp(name, "date") || !strcmp(name, "time")) {
		prdate(&curtime, &tz);
		return;
	}

	/*
	 * Open kernel memory.
	 */
#if SUN4_0
	if ((kd = kvm_open(VMUNIX, NULL, NULL, O_RDONLY, NULL)) == NULL) {
#else
	if ((kmem = open(KMEM, O_RDONLY)) < 0) {
#endif
		syslog(LOG_ERR, "open: %s: %m", KMEM);
		exit(1);
	}

	/*
	 * Read kernel namelist.
	 */
#if SUN4_0
	if ((kvm_nlist(kd, nl) < 0) || (nl[0].n_type == 0)) {
#else
	if ((nlist(VMUNIX, nl) < 0) || (nl[0].n_type == 0)) {
#endif
		syslog(LOG_ERR, "%s: no namelist", VMUNIX);
		exit(1);
	}

	/*
	 * Read the boot time.
	 */
#if SUN4_0
	kvm_read(kd, (long) nl[X_BOOTTIME].n_value, (char *) &boottime, sizeof(boottime));
#else
	lseek(kmem, (long) nl[X_BOOTTIME].n_value, L_SET);
	read(kmem, (char *) &boottime, sizeof(boottime));
#endif

	/*
	 * For "boottime" we just print the boot time, for
	 * "uptime" we print the time up.
	 */
	if (!strcmp(name, "boottime")) {
		prdate(&boottime, &tz);
	}
	else {
		curtime.tv_sec -= boottime.tv_sec;
		prtime(&curtime);
	}

#if SUN4_0
	kvm_close(kd);
#else
	close(kmem);
#endif
}

/*
 * prdate - print date and time
 */
static prdate(tv, tz)
struct timezone *tz;
struct timeval *tv;
{
	char buf[64];
	struct tm *tm;
	struct tm *localtime();
	register char *ap, *tzn;
	char *asctime(), *timezone();

	tm = localtime(&tv->tv_sec);

	ap = asctime(tm);
	tzn = timezone(tz->tz_minuteswest, tm->tm_isdst);

	/*
	 * Date and time.
	 */
	strncpy(buf, ap, 20);
	buf[20] = '\0';

	/*
	 * Timezone.
	 */
	if (tzn)
		strcat(buf, tzn);

	/*
	 * Year.
	 */
	strcat(buf, ap+19);

	(*fn_send)(0, buf);
}

/*
 * prtime - print time as days, hours, minutes, seconds.
 */
static prtime(tv)
struct timeval *tv;
{
	char tmp[32], buf[128];

	*buf = '\0';

	if (tv->tv_sec >= 86400) {
		sprintf(tmp, "%d days ", tv->tv_sec / 86400);
		tv->tv_sec %= 86400;
		strcat(buf, tmp);
	}

	if (tv->tv_sec >= 3600) {
		sprintf(tmp, "%d hours ", tv->tv_sec / 3600);
		tv->tv_sec %= 3600;
		strcat(buf, tmp);
	}

	if (tv->tv_sec >= 60) {
		sprintf(tmp, "%d minutes ", tv->tv_sec / 60);
		tv->tv_sec %= 60;
		strcat(buf, tmp);
	}

	if (tv->tv_sec) {
		sprintf(tmp, "%d seconds", tv->tv_sec);
		strcat(buf, tmp);
	}

	strcat(buf, "\n");
	(*fn_send)(0, buf);
}
