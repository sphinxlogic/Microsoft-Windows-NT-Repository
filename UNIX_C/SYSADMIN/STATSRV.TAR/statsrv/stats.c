#ifndef lint
static char *RCSid = "$Header: /ecn1/src/ecn/statsrv/RCS/stats.c,v 1.1 87/10/17 21:01:52 davy Exp $";
#endif
/*
 * stats - retrieve statistics from the statistics server
 *
 * Usage:	stats [-d] host statname [statname...]
 *
 * The STATSRV protocol is described in RFC996, "Statistics Server",
 * D.L. Mills, February 1987.
 *
 * David A. Curry
 * Purdue University
 * Engineering Computer Network
 * davy@intrepid.ecn.purdue.edu
 * October, 1987
 *
 * $Log:	stats.c,v $
 * Revision 1.1  87/10/17  21:01:52  davy
 * Initial revision
 * 
 */
#include <sys/param.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>

#include "stats.h"

char	*pname;				/* program name			*/
short	server = 0;			/* indicates we aren't server	*/
struct	sockaddr_in sin;		/* address of remote host	*/
int	(*fn_send)(), (*fn_recv)();	/* send/recv functions		*/

main(argc, argv)
int argc;
char **argv;
{
	int socktype;
	register int s;
	char buf[10240];
	struct hostent *hp;
	struct servent *sp;
	char *host, *servtype;
	struct hostent *gethostbyname();
	struct servent *getservbyname();

	pname = *argv;

	/*
	 * Set up to use TCP stream sockets.
	 */
	servtype = "tcp";
	fn_recv = st_recv;
	fn_send = st_send;
	socktype = SOCK_STREAM;

	/*
	 * Check arguments.
	 */
argchk:	if (argc < 3) {
		fprintf(stderr, "Usage: %s [-d] host statname [statname...]\n", pname);
		fprintf(stderr, "    use the \"help\" statistic for more info.\n");
		exit(1);
	}

	/*
	 * -d indicates use datagrams; set up to use
	 * datagram sockets and then go recheck the
	 * argument list.
	 */
	if (!strcmp(*++argv, "-d")) {
		socktype = SOCK_DGRAM;
		fn_recv = dg_recv;
		fn_send = dg_send;
		servtype = "udp";
		argc--;

		goto argchk;
	}

	/*
	 * Host is first argument.
	 */
	argc--;
	host = *argv;

	/*
	 * Get a socket.
	 */
	if ((s = socket(AF_INET, socktype, 0)) < 0) {
		error("socket");
		exit(1);
	}

	/*
	 * Look up the host's address.
	 */
	if ((hp = gethostbyname(host)) == NULL) {
		fprintf(stderr, "%s: %s: host unknown.\n", pname, host);
		exit(1);
	}

	/*
	 * Look up the port the server lives on.
	 */
	if ((sp = getservbyname(SERVNAME, servtype)) == NULL) {
		fprintf(stderr, "%s: %s/%s: service unknown.\n", pname, SERVNAME, servtype);
		exit(1);
	}

	/*
	 * Build the server's address.
	 */
	sin.sin_port = sp->s_port;
	sin.sin_family = hp->h_addrtype;
	bcopy(hp->h_addr, &sin.sin_addr, sizeof(sin.sin_addr));

	/*
	 * If we're using a stream socket, connect to
	 * the remote host.
	 */
	if (socktype == SOCK_STREAM) {
		if (connect(s, &sin, sizeof(struct sockaddr_in)) < 0) {
			error("connect");
			exit(1);
		}
	}

	/*
	 * For each statistic requested...
	 */
	while (--argc) {
		/*
		 * Send the name of the statistic to the
		 * server.
		 */
		(*fn_send)(s, *++argv);

		/*
		 * Wait for a response.
		 */
		(*fn_recv)(s, buf, sizeof(buf), "response");

		/*
		 * Print what we got.
		 */
		fputs(buf, stdout);
	}

	exit(0);
}

/*
 * error - print program name and error message.
 */
error(s)
{
	fprintf(stderr, "%s: ", pname);
	perror(s);
}
