#ifndef lint
static char *RCSid = "$Header: /u5/davy/system/statsrv/RCS/getloadstats.c,v 1.4 88/10/06 10:55:03 davy Exp $";
#endif
/*
 * getloadstats - get load average statistics
 *
 * David A. Curry
 * Purdue University
 * Engineering Computer Network
 * davy@intrepid.ecn.purdue.edu
 * October, 1987
 *
 * $Log:	getloadstats.c,v $
 * Revision 1.4  88/10/06  10:55:03  davy
 * Modified for Sun 4.0.
 * 
 * Revision 1.3  88/01/02  14:09:10  davy
 * Changes for Sequent support.
 * 
 * Revision 1.2  87/10/29  14:24:54  davy
 * Modified to use VMUNIX and KMEM instead of hard-coded paths.
 * 
 * Revision 1.1  87/10/17  21:01:23  davy
 * Initial revision
 * 
 */
#include <sys/param.h>
#include <sys/file.h>
#include <syslog.h>
#if SUN4_0
#include <kvm.h>
#include <fcntl.h>
#endif
#include <nlist.h>
#include <stdio.h>
#include "stats.h"

static struct nlist nl[] = {
#define X_AVENRUN	0
	{	"_avenrun"	},
	{	0		}
};

extern	int (*fn_recv)(), (*fn_send)();	/* send/recv functions		*/

/*
 * getloadstats - get load average statistics
 */
getloadstats(name)
char *name;
{
#if SUN4_0
	kvm_t *kd;
#else
	int kmem;
#endif
	char buf[BUFSIZ];
#if sun || sequent
	long avenrun[3];
#else
	double avenrun[3];
#endif

	/*
	 * Open kernel memory.
	 */
#if SUN4_0
	if ((kd = kvm_open(VMUNIX, NULL, NULL, O_RDONLY, NULL)) == NULL) {
#else
	if ((kmem = open(KMEM, O_RDONLY)) < 0) {
#endif
		syslog(LOG_ERR, "open: %s: %m", KMEM);
		exit(1);
	}

	/*
	 * Read kernel namelist.
	 */
#if SUN4_0
	if ((kvm_nlist(kd, nl) < 0) || (nl[0].n_type == 0)) {
#else
	if ((nlist(VMUNIX, nl) < 0) || (nl[0].n_type == 0)) {
#endif
		syslog(LOG_ERR, "%s: no namelist", VMUNIX);
		exit(1);
	}

	/*
	 * Read the load averages.
	 */
#if SUN4_0
	kvm_read(kd, (long) nl[X_AVENRUN].n_value, (char *) avenrun, sizeof(avenrun));
#else
	lseek(kmem, (long) nl[X_AVENRUN].n_value, L_SET);
	read(kmem, (char *) avenrun, sizeof(avenrun));
#endif

	/*
	 * Return the one-minute load average.
	 */
#if sun
	sprintf(buf, "%.2f\n", (double) avenrun[0] / FSCALE);
#endif
#if sequent
	sprintf(buf, "%.2f\n", (double) avenrun[0] / 1000.0);
#endif
#if !(sun || sequent)
	sprintf(buf, "%.2f\n", avenrun[0]);
#endif

	(*fn_send)(0, buf);
#if SUN4_0
	kvm_close(kd);
#else
	close(kmem);
#endif
}
