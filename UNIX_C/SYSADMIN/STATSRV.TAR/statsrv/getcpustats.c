#ifndef lint
static char *RCSid = "$Header: /u5/davy/system/statsrv/RCS/getcpustats.c,v 1.5 88/10/06 10:54:50 davy Exp $";
#endif
/*
 * getcpustats - get cpu usage statistics
 *
 * David A. Curry
 * Purdue University
 * Engineering Computer Network
 * davy@intrepid.ecn.purdue.edu
 * October, 1987
 *
 * $Log:	getcpustats.c,v $
 * Revision 1.5  88/10/06  10:54:50  davy
 * Modified for Sun 4.0.
 * 
 * Revision 1.4  88/01/02  14:09:57  davy
 * Changes to support Sequents.
 * 
 * Revision 1.3  88/01/02  13:41:56  davy
 * Changed dk.h to dkstat.h for the CCI, which has newer 4.3BSD.
 * 
 * Revision 1.2  87/10/29  14:24:02  davy
 * Modified to use VMUNIX and KMEM instead of hard-coded paths.
 * 
 * Revision 1.1  87/10/17  21:01:18  davy
 * Initial revision
 * 
 */
#include <sys/param.h>
#include <sys/file.h>
#if sequent
#include <sys/time.h>
#include <sys/vmmeter.h>
#endif
#if tahoe
#include <sys/dkstat.h>
#else
#include <sys/dk.h>
#endif
#include <syslog.h>
#if SUN4_0
#include <kvm.h>
#include <fcntl.h>
#endif
#include <nlist.h>
#include <stdio.h>
#include "stats.h"

static struct nlist nl[] = {
#define X_CPTIME	0
	{	"_cp_time"	},
	{	0		}
};

extern	int (*fn_recv)(), (*fn_send)();	/* send/recv functions		*/

/*
 * getcpustats - get cpu usage statistics
 */
getcpustats(name)
char *name;
{
#if SUN4_0
	kvm_t *kd;
#else
	int kmem;
#endif
	double f;
	register int i;
	double percent();
	char buf[BUFSIZ];
	int user, nice, sys, idle;
	long times1[CPUSTATES], times2[CPUSTATES];

	/*
	 * Open kernel memory.
	 */
#if SUN4_0
	if ((kd = kvm_open(VMUNIX, NULL, NULL, O_RDONLY, NULL)) == NULL) {
#else
	if ((kmem = open(KMEM, O_RDONLY)) < 0) {
#endif
		syslog(LOG_ERR, "open: %s: %m", KMEM);
		exit(1);
	}

	/*
	 * Read kernel namelist.
	 */
#if SUN4_0
	if ((kvm_nlist(kd, nl) < 0) || (nl[0].n_type == 0)) {
#else
	if ((nlist(VMUNIX, nl) < 0) || (nl[0].n_type == 0)) {
#endif
		syslog(LOG_ERR, "%s: no namelist", VMUNIX);
		exit(1);
	}

	/*
	 * Read the first set of usage stats.
	 */
#if SUN4_0
	kvm_read(kd, (long) nl[X_CPTIME].n_value, (char *) times1, sizeof(times1));
#else
	lseek(kmem, (long) nl[X_CPTIME].n_value, L_SET);
	read(kmem, (char *) times1, sizeof(times1));
#endif

	/*
	 * Give it a time interval.
	 */
	sleep(1);

	/*
	 * Read the second set of usage stats.
	 */
#if SUN4_0
	kvm_read(kd, (long) nl[X_CPTIME].n_value, (char *) times2, sizeof(times2));
#else
	lseek(kmem, (long) nl[X_CPTIME].n_value, L_SET);
	read(kmem, (char *) times2, sizeof(times2));
#endif

	/*
	 * Calculate change.
	 */
	for (i=0; i < CPUSTATES; i++)
		times2[i] -= times1[i];

	/*
	 * Calculate times.
	 */
	for (i=0; i < CPUSTATES; i++) {
		f = percent(i, times2);

		/*
		 * Save results.  This is risky, and assumes the order
		 * is as given.  Check sys/dk.h if you think it's wrong
		 * on your system.
		 */
		switch (i) {
		case 0:
			user = (int) f;
			break;
		case 1:
			nice = (int) f;
			break;
		case 2:
			sys = (int) f;
			break;
		case 3:
			idle = (int) f;
			break;
		}
	}

	sprintf(buf, "user %d%% nice %d%% sys %d%% idle %d%%\n", user, nice, sys, idle);
	(*fn_send)(0, buf);
#if SUN4_0
	kvm_close(kd);
#else
	close(kmem);
#endif
}

/*
 * percent - figure what percentage of time is used by row.
 */
static double percent(row, times)
long *times;
int row;
{
	double t;
	register int i;

	t = 0.0;
	for (i=0; i < CPUSTATES; i++)
		t += times[i];

	if (t == 0.0)
		t = 1.0;

	return(times[row] * 100.0 / t);
}
