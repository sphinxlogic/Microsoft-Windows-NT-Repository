#ifndef lint
static char *RCSid = "$Header: /ecn1/src/ecn/statsrv/RCS/statsrv.c,v 1.4 88/04/12 10:10:25 davy Exp $";
#endif
/*
 * statsrv - statistics server
 *
 * Statsrv is invoked via inetd(8).  Place the following lines in your
 * inetd.conf file (statsrv is port 133 for both udp and tcp):
 *
 * statsrv	stream	tcp	nowait	root	/etc/statsrv	statsrv
 * statsrv	dgram	udp	wait	root	/etc/statsrv	statsrv
 *
 * The STATSRV protocol is described in RFC996, "Statistics Server",
 * D.L. Mills, February 1987.
 *
 * David A. Curry
 * Purdue University
 * Engineering Computer Network
 * davy@intrepid.ecn.purdue.edu
 * October, 1987
 *
 * $Log:	statsrv.c,v $
 * Revision 1.4  88/04/12  10:10:25  davy
 * Added "actwho" statistic.
 * 
 * Revision 1.3  88/01/02  12:46:07  davy
 * Added "msgbuf" and "msgtail" statistics.
 * 
 * Revision 1.2  87/12/08  14:39:23  davy
 * Added lines for the "tables" and "who" commands.
 * 
 * Revision 1.1  87/10/17  21:01:57  davy
 * Initial revision
 * 
 */
#include <sys/param.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <syslog.h>
#include <errno.h>
#include <ctype.h>
#include <stdio.h>

#include "stats.h"

/*
 * One of these for each statistic we understand.
 */
struct statistic {
	char	*st_name;
	int	(*st_func)();
};

/*
 * Functions which do the statistics.
 */
extern int liststats();
extern int getmsgbuf();
extern int getcpustats();
extern int getnetstats();
extern int getloadstats();
extern int getuserstats();
extern int gettimestats();
extern int gettablestats();

/*
 * Statistics we understand.
 */
static struct statistic stats[] = {
	{	"actusers",	getuserstats	},
	{	"actwho",	getuserstats	},
	{	"boottime",	gettimestats	},
	{	"cpu",		getcpustats	},
	{	"date",		gettimestats	},
	{	"help",		liststats	},
	{	"loadav",	getloadstats	},
	{	"mbufs",	getnetstats	},
	{	"msgbuf",	getmsgbuf	},
	{	"msgtail",	getmsgbuf	},
	{	"packets",	getnetstats	},
	{	"proto",	getnetstats	},
	{	"tables",	gettablestats	},
	{	"time",		gettimestats	},
	{	"uptime",	gettimestats	},
	{	"users",	getuserstats	},
	{	"who",		getuserstats	},
	{	0,		0		}
};
	
char	*pname;				/* program name			*/
short	server = 1;			/* indicates we're the server	*/
struct	sockaddr_in sin;		/* address of remote host	*/
int	(*fn_recv)(), (*fn_send)();	/* send/recv functions		*/

extern	int errno;

main(argc, argv)
int argc;
char **argv;
{
	char *rindex();
	char buf[BUFSIZ];
	register char *s;
	int len, socktype;
	register struct statistic *st;

	/*
	 * Get program name.
	 */
	if ((pname = rindex(*argv, '/')) == NULL)
		pname = *argv;
	else
		pname++;

	/*
	 * Set up syslog.
	 */
	openlog(pname, LOG_PID, LOG_DAEMON);

	/*
	 * Set up to run on stream sockets.
	 */
	fn_recv = st_recv;
	fn_send = st_send;
	socktype = SOCK_STREAM;

	/*
	 * Figure out if we're on a stream or datagram socket.  If
	 * we are on a datagram socket, we have no peer, and we
	 * will get an ENOTCONN error.
	 */
	len = sizeof(struct sockaddr_in);
	if (getpeername(0, &sin, &len) < 0) {
		/*
		 * Datagram socket.
		 */
		if (errno == ENOTCONN) {
			socktype = SOCK_DGRAM;
			fn_recv = dg_recv;
			fn_send = dg_send;
		}
		else {
			syslog(LOG_ERR, "getpeername: %m");
			exit(1);
		}
	}

	/*
	 * Forever...
	 */
top:	for (;;) {
		/*
		 * Get a statistic request from the remote host.
		 */
		(*fn_recv)(0, buf, sizeof(buf), "statname");

		/*
		 * Convert to lower case.
		 */
		for (s = buf; *s; s++) {
			if (isupper(*s))
				*s = tolower(*s);
		}

		/*
		 * Look up the statistic and run the
		 * function.
		 */
		for (st = stats; st->st_name; st++) {
			if (!strcmp(st->st_name, buf)) {
				(*(st->st_func))(buf);

				/*
				 * Only one statistic per datagram.
				 */
				if (socktype == SOCK_DGRAM)
					exit(0);

				goto top;
			}
		}

		/*
		 * Unknown statistic.
		 */
		(*fn_send)(0, "unknown command - use \"help\" for list.\n");
		exit(1);
	}
}

/*
 * liststats - list statistics we know about.
 */
liststats(name)
char *name;
{
	char buf[BUFSIZ];
	register struct statistic *st;

	*buf = '\0';

	for (st = stats; st->st_name; st++) {
		strcat(buf, st->st_name);
		strcat(buf, "\n");
	}

	(*fn_send)(0, buf);
}

/*
 * error - print program name and error message.
 */
error(s)
{
	fprintf(stderr, "%s: ", pname);
	perror(s);
}
