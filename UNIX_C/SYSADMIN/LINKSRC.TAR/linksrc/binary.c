/*
 * See if a file is Ascii or not.
 *
 * Keyword: binary file status
 */

#include <stdio.h>
main()
{
int ii, jj, kk;

kk = 0;

for (ii=0; ii < 100; ii++)
{
if ( (jj = getchar()) == EOF )
	{
	break;
	}

if (jj == 0 || jj > '~')
	{
	kk = 1;
	break;
	}
}

printf("%d\n",kk);
}
