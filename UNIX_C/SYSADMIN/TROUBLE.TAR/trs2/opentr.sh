:
#
# Package	: (Trs2)
# Module	: opentr
# Programmer	: R. Stolfa (rjs@a.cs.okstate.edu)
# SCCSid	: @(#) opentr.sh 1.2 89/12/19
#
# Purpose :	To list all open trouble report ticket numbers
#		in the TRS database.
#
# Modification History:
#   04/15/88	Created
#   10/25/88	Added a user configurable "ROOT" to allow more than
#		one TRS on a system.
#
#   10/16/89	Release 2 started.
#

###
###	Copyright (c) 1989, Roland J. Stolfa,  Right to copy is
###	granted so long as it is not for monetary gain and this
###	message and all headers in all files remain in tact.
###
###	THE AUTHOR DOES NOT MAKE ANY WARRANTIES, EITHER EXPRESS
###	OR IMPLIED, AS TO ANY MATTER WHATSOEVER, INCLUDING WITHOUT
###	LIMITATION, THE CONDITION OF THIS DISTRIBUTION, ITS
###	MERCHANTABILITY OR ITS FITNESS FOR ANY PARTICULAR PURPOSE.
###

#
# Get configured.
#
if [ "${TRSROOT}" != "" ]
then
	ROOT = ${TRSROOT}
else
ROOT=/u/rjs/lib/Trs
fi
Entry=${ROOT}/Entry

BIN=/u/rjs/bin
PATH=${BIN}:/bin:/usr/bin
export PATH
umask 022

if [ `ls ${Entry} | wc -l` -gt 0 ]
then
	for i in ${Entry}/*
	do
		if [ `grep "^needle=" $i | wc -l` -eq 0 ]
		then
			echo `basename $i`
		fi
	done
fi
