/*
 * Package	: LIBRARY (lockp)
 * Module	: lockp.h
 * Programmer	: R. Stolfa (rjs@a.cs.okstate.edu)
 * SCCSid	: @(#) lockp.h 1.1 89/10/30
 *
 * Modification History:
 *   10/30/89	Created
 */

/**
***	Copyright (c) 1989, Roland J. Stolfa,  Right to copy is
***	granted so long as it is not for monetary gain and this
***	message and all headers in all files remain in tact.
***
***	THE AUTHOR DOES NOT MAKE ANY WARRANTIES, EITHER EXPRESS
***	OR IMPLIED, AS TO ANY MATTER WHATSOEVER, INCLUDING WITHOUT
***	LIMITATION, THE CONDITION OF THIS DISTRIBUTION, ITS
***	MERCHANTABILITY OR ITS FITNESS FOR ANY PARTICULAR PURPOSE.
**/

#define		LOCKP_BADF	-1
#define		LOCKP_EMPTY	-2
#define		LOCKP_BADPID	-3

#define		unlockp(fn)	unlockpp((fn),getpid())
