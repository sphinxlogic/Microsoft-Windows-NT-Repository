/*
 * Package	: (Trs2)
 * Module	: print.c
 * Functions	: main
 * Programmer	: R. Stolfa (rjs@a.cs.okstate.edu)
 * SCCSid	: @(#) print.c 1.2 89/12/19
 *
 * Purpose :	To provide a portable way of printing a string
 *		of text on stdout without having a newline at the
 *		end.
 *
 * Modification History:
 *   04/01/88	Created
 *
 *   10/16/89	Rewrote for release 2
 *		Added check to make sure no newlines ever get out.
 */

/**
***	Copyright (c) 1989, Roland J. Stolfa,  Right to copy is
***	granted so long as it is not for monetary gain and this
***	message and all headers in all files remain in tact.
***
***	THE AUTHOR DOES NOT MAKE ANY WARRANTIES, EITHER EXPRESS
***	OR IMPLIED, AS TO ANY MATTER WHATSOEVER, INCLUDING WITHOUT
***	LIMITATION, THE CONDITION OF THIS DISTRIBUTION, ITS
***	MERCHANTABILITY OR ITS FITNESS FOR ANY PARTICULAR PURPOSE.
**/

static char	*sccsid = "@(#) print.c 1.2 89/12/19";

#include	<stdio.h>

main (argc, argv)
int	argc;
char	*argv[];
{
	int	i;

	if (argc > 1) {
		for (i = 1; i < argc - 1 ; i ++) {
			p (argv[i]);
			p (' ');
		}

		p (argv[argc-1]);
	}
}

p (s)
	char	*s;
{
	while ((*s != '\n') && (*s != '\0')) {
		putchar (*s);
		s ++;
	}
}
