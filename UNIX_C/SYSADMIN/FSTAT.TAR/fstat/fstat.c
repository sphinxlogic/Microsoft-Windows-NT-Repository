/*
 * Copyright (c) 1987 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that the above copyright notice and this paragraph are
 * duplicated in all such forms and that any documentation,
 * advertising materials, and other materials related to such
 * distribution and use acknowledge that the software was developed
 * by the University of California, Berkeley.  The name of the
 * University may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */

#ifndef lint
char copyright[] =
"@(#) Copyright (c) 1987 Regents of the University of California.\n\
 All rights reserved.\n";
#endif /* not lint */

#ifndef lint
static char sccsid[] = "@(#)fstat.c	5.13 (Berkeley) 6/18/88";
#endif /* not lint */

/*
 *  fstat 
 */
#include <machine/pte.h>

#include <sys/param.h>
#include <sys/dir.h>
#include <sys/user.h>
#include <sys/proc.h>
#ifndef	sun
#include <sys/text.h>
#endif
#include <sys/stat.h>
#ifdef	DYNIX
#define	KERNEL
#include <sys/vnode.h>
#endif
#ifndef	sun
#include <sys/inode.h>
#endif
#ifdef	DYNIX
#undef	KERNEL
#endif
#include <sys/socket.h>
#include <sys/socketvar.h>
#include <sys/domain.h>
#include <sys/protosw.h>
#include <sys/unpcb.h>
#include <sys/vmmac.h>
#define	KERNEL
#include <sys/file.h>
#undef	KERNEL
#include <net/route.h>
#include <netinet/in.h>
#include <netinet/in_pcb.h>
#include <stdio.h>
#include <ctype.h>
#include <nlist.h>
#include <pwd.h>

#ifdef sun
#include <sys/vnode.h>
#include <ufs/inode.h>
#include "/usr/share/sys/specfs/snode.h"
#include <kvm.h>
kvm_t	*kd;
struct user *kvm_getu();
#endif

#ifdef	ULTRIX
		/* UFS -> GFS */
#    define	inode	gnode
#    define	x_iptr	x_gptr
#    define	i_dev	g_dev
#    define	i_number g_number
#    define	i_mode	g_mode
#    define	i_size	g_size
void exit(), nlist(), perror();
#endif

#ifdef	ULTRIX
#define	ls_t	long
#else
#define ls_t	off_t
#endif

#if	defined(DYNIX) || defined(sun)
#define DTYPE_INODE	DTYPE_VNODE
#endif

#define	N_KMEM	"/dev/kmem"
#define	N_MEM	"/dev/mem"
#define	N_SWAP	"/dev/drum"
#ifdef	DYNIX
#define	N_UNIX	"/dynix"
#else
#define	N_UNIX	"/vmunix"
#endif

#define	TEXT	-2
#define	WD	-1

typedef struct devs {
	struct devs *next;
	dev_t dev;
	int inum;
	char *name;
} DEVS;
DEVS *devs;

static struct nlist nl[] = {
	{ "_proc" },
#define	X_PROC		0
	{ "_nproc" },
#define	X_NPROC		1
	{ "_Sysmap"},
#define	X_SYSMAP	2
#ifdef	sun
	{ "_inode"},
#define X_INODE		3
	{ "_ninode"},
#define X_NINODE	4
#else
	{ "_Usrptmap" },
#define	X_USRPTMA	3
	{ "_usrpt" },
#define	X_USRPT		4
#endif
	{ "" },
};

struct proc *mproc;
#if	!defined(DYNIX) && !defined(sun)
struct pte *Usrptma, *usrpt;
#endif

#ifdef	sun
struct inode *inodef = NULL;
struct inode *inodel;
int ninode = 0;
#endif

#ifndef	DYNIX
union {
	struct user user;
	char upages[UPAGES][NBPG];
} user;
#endif
struct user *u;

extern int errno;
extern char *sys_errlist[];
static int fflg, vflg;
static int kmem, mem, nproc, swap;
static char *pname, *uname;

ls_t lseek();
#ifdef	DYNIX
ls_t vtophys();
#endif

main(argc, argv)
	int argc;
	char **argv;
{
	extern char *optarg;
	extern int optind;
	register struct passwd *passwd;
	register int pflg, pid, uflg, uid;
	int ch, size;
	struct passwd *getpwnam(), *getpwuid();
	long lgetw();
	char *malloc(), *rindex(), *valloc();

#ifdef	lint
/*
 * The following code satisfies lint for KERNEL symbols.
 * This program is lint-free under 4.3BSD, DYNIX 3.0.1[24], SunOS 4.0
 * and ULTRIX 2.2, using the lint libraries of the systems at the
 * Purdue University Computing Center.
 */
#if	!defined(DYNIX) && !defined(ULTRIX)
	struct file *lintfp;

	file = fileNFILE = NULL;
	lintfp = file;
	lintfp = fileNFILE;
	file = lintfp;
	nfile = 0;
	size = nfile;
#endif
#ifdef	DYNIX
	char *optarg = NULL;	/* DYNIX lint misses the extern  */
	int optind = 0;		/* DYNIX lint misses the extern  */
#endif
#ifdef	ULTRIX
	struct file *lintfp;
	struct nch *lintnch;

	file = fileNFILE = NULL;
	lintfp = file;
	lintfp = fileNFILE;
	file = lintfp;
	nfile = 0;
	size = nfile;
	nch = NULL;
	lintnch = nch;
	nch = lintnch;
	nchsize = 0;
	size = nchsize;
#endif
#endif	/* lint */

	if ((pname = rindex(argv[0], '/')) != NULL)
		pname++;
	else
		pname = argv[0];
	pflg = uflg = 0;
	while ((ch = getopt(argc, argv, "p:u:v")) != EOF)
		switch((char)ch) {
		case 'p':
			if (pflg++)
				(void) usage();
			if (!isdigit(*optarg)) {
				(void) fprintf(stderr,
				    "%s: -p option requires a process id.\n",
				    pname);
				(void) usage();
			}
			pid = atoi(optarg);
			break;
		case 'u':
			if (uflg++)
				(void) usage();
			if (!(passwd = getpwnam(optarg))) {
				(void) fprintf(stderr,
					"%s: %s is unknown uid\n",
					pname, optarg);
				exit(1);
			}
			uid = passwd->pw_uid;
			uname = passwd->pw_name;
			break;
		case 'v':	/* undocumented: print read error messages */
			vflg++;
			break;
		case '?':
		default:
			(void) usage();
		}

	if (*(argv += optind)) {
		for (; *argv; ++argv) {
			if (getfname(*argv))
				fflg = 1;
		}
		if (!fflg)	/* file(s) specified, but none accessible */
			exit(1);
	}

#ifdef	DYNIX
	if ((u = (struct user *) valloc(ctob(UPAGES))) == NULL) {
		(void) fprintf(stderr,
			"%s: can't allocate space for user structure\n",
			pname);
		exit(1);
	}
#else
	u = &user.user;
#endif
	openfiles();

#ifdef	ULTRIX
	(void) nlist(N_UNIX, nl);
	if (!nl[0].n_type)
#else
	if (nlist(N_UNIX, nl) == -1 || !nl[0].n_type)
#endif
	{
		(void) fprintf(stderr, "%s: %s has no namelist\n",
			pname, N_UNIX);
		exit(1);
	}
#ifdef	sun
	if (nl[X_INODE].n_value == (u_long)0) {
		(void) fprintf(stderr, "%s: can't read inode pointer)\n",
			pname);
		exit(1);
	}
	inodef = (struct inode *)lgetw((ls_t)nl[X_INODE].n_value);
	ninode = (int)lgetw((ls_t)nl[X_NINODE].n_value);
	if (!inodef || !ninode) {
		(void) fprintf(stderr,
			"%s: no inodes (Is this a diskless Sun client?)\n",
			pname);
		exit(1);
	}
	inodel = inodef + (ninode - 1);
#endif
#if	!defined(DYNIX) && !defined(sun)
	Usrptma = (struct pte *)nl[X_USRPTMA].n_value;
	usrpt = (struct pte *) nl[X_USRPT].n_value;
#endif
	nproc = (int)lgetw((ls_t)nl[X_NPROC].n_value);

	size = nproc * sizeof(struct proc);
	if ((mproc = (struct proc *)malloc((u_int)size)) == NULL) {
		(void) fprintf(stderr, "%s: out of space\n", pname);
		exit(1);
	}
	if (kread((ls_t)lgetw((ls_t)nl[X_PROC].n_value), (char *)mproc, size)
	!= size)
		rerr1("proc table", N_KMEM);

	(void) printf("%-8.8s %-10.10s %5s %4s %-6.6s %6s %7s %-5.5s %s\n",
		"USER", "CMD", "PID", "FD", "DEVICE", "INODE", "SIZE", "TYPE",
		fflg ? "NAME" : "");
	for (; nproc--; ++mproc) {
		if (mproc->p_stat == 0)
			continue;
		if (pflg && mproc->p_pid != pid)
			continue;
		if (uflg)  {
			if (mproc->p_uid != uid)
				continue;
		}
		else
			uname = (passwd = getpwuid((int)mproc->p_uid)) ?
			    passwd->pw_name : "unknown";
		if (mproc->p_stat == SZOMB)
			continue;
#ifdef	sun
		if ((u = kvm_getu(kd, mproc)) == NULL)
#else
		if (getu() == 0)
#endif
			continue;
		dotext();
		readf();
	}
	exit(0);
}

#ifndef	sun
#ifdef	DYNIX
getu()
{
	int btr;

	if ((mproc->p_flag & SLOAD) == 0) {
		if (swap < 0)
			return(0);
		(void) lseek(swap, (ls_t)dtob(mproc->p_swaddr), L_SET);
		btr = ctob(UPAGES);
		if (read(swap, (char *)u, btr) != btr)
			return(0);
	} else {
		(void) lseek(kmem, (ls_t)mproc->p_uarea, L_SET);
		if (read(kmem, (char *)u, sizeof(struct user))
		!= sizeof(struct user))
			return(0);
	}
	return(1);
}
#else	/* DYNIX */
static
getu()
{
	struct pte *pteaddr, apte;
	struct pte arguutl[UPAGES+CLSIZE];
	register int i;
	int ncl;

	if ((mproc->p_flag & SLOAD) == 0) {
		if (swap < 0)
			return(0);
		(void)lseek(swap, (ls_t)dtob(mproc->p_swaddr), L_SET);
		if (read(swap, (char *)u, sizeof(struct user))
		    != sizeof(struct user)) {
			(void) fprintf(stderr,
				"%s: can't read u for pid %d from %s\n",
				pname, mproc->p_pid, N_SWAP);
			return(0);
		}
		return(1);
	}
	pteaddr = &Usrptma[btokmx(mproc->p_p0br) + mproc->p_szpt - 1];
	(void)lseek(kmem, (ls_t)pteaddr, L_SET);
	if (read(kmem, (char *)&apte, sizeof(apte)) != sizeof(apte)) {
		(void) printf(
		  "%s: can't read indir pte to get u for pid %d from %s\n",
		  pname, mproc->p_pid, N_SWAP);
		return(0);
	}
	(void)lseek(mem, (ls_t)(ctob(apte.pg_pfnum+1) - (UPAGES+CLSIZE)
	    * sizeof(struct pte)), L_SET);
	if (read(mem, (char *)arguutl, sizeof(arguutl)) != sizeof(arguutl)) {
		(void) printf(
		  "%s: can't read page table for u of pid %d from %s\n",
		  pname, mproc->p_pid, N_KMEM);
		return(0);
	}
	ncl = (sizeof(struct user) + NBPG*CLSIZE - 1) / (NBPG*CLSIZE);
	while (--ncl >= 0) {
		i = ncl * CLSIZE;
		(void)lseek(mem, (ls_t)ctob(arguutl[CLSIZE+i].pg_pfnum), L_SET);
		if (read(mem, user.upages[i], CLSIZE*NBPG) != CLSIZE*NBPG) {
			(void) printf(
			  "%s: can't read page %u of u of pid %d from %s\n",
			  pname,
			  arguutl[CLSIZE+i].pg_pfnum, mproc->p_pid, N_MEM);
			return(0);
		}
	}
	return(1);
}
#endif	/* DYNIX */
#endif	/* not sun */

static
dotext()
{
#if	!defined(DYNIX) && !defined(sun)
	struct text text;

	(void)lseek(kmem, (ls_t)mproc->p_textp, L_SET);
	if (read(kmem, (char *) &text, sizeof(text)) != sizeof(text)) {
		rerr1("text table", N_KMEM);
		return;
	}
	if (text.x_flag)
		itrans(DTYPE_INODE, (char *)text.x_iptr, TEXT);
#endif
}

static
itrans(ftype, g, fno)
	int ftype, fno;
	char *g;			/* if ftype is inode/vnode */
{
	struct inode inode;
	dev_t idev;
	char *comm, *itype();
	char *name = (char *)NULL;	/* set by devmatch() on a match */
	int noinode = 0;
#if	defined(DYNIX) || defined(sun)
	struct vnode v;
#ifdef	sun
	struct snode s;
	char *vntype();
#endif
#endif

	if ((g && (ftype & DTYPE_INODE)) || fflg) {
#if	defined(DYNIX) || defined(sun)
/*
 * The file structure points to:
 *
 *	DYNIX	vnode, and the vnode points to the inode
 *	BSD	inode
 *	SunOS	vnode, and the vode points to an snode if the vnode type
 *		is VBLK, VCHR or VFIFO; and to an inode otherwise; the
 *		snode may point to the real vnode or to a stream
 *		
 *	ULTRIX	gnode
 */
		if (kread((ls_t)g, (char *)&v, sizeof(v)) != sizeof(v)) {
			rerr2(errno, (int)g, "vnode");
			return;
		}
#ifdef	sun
		if (v.v_type == VCHR || v.v_type == VBLK || v.v_type == VFIFO) {
			if (kread((ls_t)v.v_data, (char *)&s, sizeof(s))
			!= sizeof(s)) {
				rerr2(errno, (int)v.v_data, "snode");
				return;
			}
			if (s.s_realvp || s.s_bdevvp) {
				if (kread( s.s_realvp ? (ls_t)s.s_realvp
						      : (ls_t)s.s_bdevvp,
					 (char *)&v, sizeof(v))
				!= sizeof(v)) {
					rerr2(errno, (int)s.s_realvp,
						"read vnode");
					return;
				}
			}
		}
		/*
		 * The following test weeds out Sun streams that are
		 * represented by "clone" snodes whose s_realvp pointer
		 * has not been properly NULLed in the kernel.
		 */
		if ((struct inode *)v.v_data < inodef
		||  (struct inode *)v.v_data > inodel)
			noinode = 1;
		else	
			if (kread((ls_t)v.v_data, (char *)&inode, sizeof(inode))
#else	/* DYNIX && not sun */
		if (kread((ls_t)v.v_data, (char *)&inode, sizeof(inode))
#endif	/* sun */
#else	/* not DYNIX && not sun */
		if (kread((ls_t)g, (char *)&inode, sizeof(inode))
#endif	/* DYNIX || sun */
		!= sizeof(inode)) {
			rerr2(errno, (int)g, "inode");
			return;
		}
		idev = inode.i_dev;
		if (fflg && (noinode || !devmatch(idev, inode.i_number, &name)))
			return;
	}
	if (mproc->p_pid == 0)
		comm = "swapper";
	else if (mproc->p_pid == 2)
		comm = "pagedaemon";
	else
		comm = u->u_comm;
	(void) printf("%-8.8s %-10.10s %5d ", uname, comm, mproc->p_pid);

	switch(fno) {
	case WD:
		(void) printf("  wd");
		break;
	case TEXT:
		(void) printf("text");
		break;
	default:
		(void) printf("%4d", fno);
	}

	if (g == NULL) {
		(void) printf("* (deallocated)\n");
		return;
	}

	switch(ftype) {
	case DTYPE_INODE:
#ifndef	sun
		(void) printf(" %2d, %2d %6lu %7ld %-5.5s %s\n",
		    major(inode.i_dev), minor(inode.i_dev),
		    inode.i_number,
		    inode.i_mode == IFSOCK ? 0 : inode.i_size,
		    itype(inode.i_mode),
		    name ? name : "");
#else
		if (noinode)
			(void) printf(" %2d, %2d %6s %7s %-5.5s %s\n",
				major(v.v_rdev), minor(v.v_rdev),
				"none", "", vntype(v.v_type),
				name ? name: "");
		else
			(void) printf(" %2d, %2d %6lu %7ld %-5.5s %s\n",
			    major(inode.i_dev), minor(inode.i_dev),
			    inode.i_number,
		    	    inode.i_mode == IFSOCK ? 0 : inode.i_size,
			    itype(inode.i_mode), name ? name : "");
#endif
		break;
	case DTYPE_SOCKET:
		socktrans((struct socket *)g);
		break;
#ifdef DTYPE_PORT
	case DTYPE_PORT:
		(void) printf("* (fifo / named pipe)\n");
		break;
#endif
	default:
		(void) printf("* (unknown file type)\n");
	}
}

static char *
itype(mode)
	u_short mode;
{
	switch(mode & IFMT) {
#ifdef	IFIFO
	case IFIFO:
		return("fifo");
#endif
	case IFCHR:
		return("chr");
	case IFDIR:
		return("dir");
	case IFBLK:
		return("blk");
	case IFREG:
		return("reg");
	case IFLNK:
		return("link");
	case IFSOCK:
		return("sock");
	default:
		return("unk");
	}
	/*NOTREACHED*/
}

#ifdef	sun
static char *
vntype(v)
	enum vtype v;
{
	switch (v) {
	case VNON:
		return("vnon");
	case VREG:
		return("vreg");
	case VDIR:
		return("vdir");
	case VBLK:
		return("vblk");
	case VCHR:
		return("vchr");
	case VLNK:
		return("vlnk");
	case VSOCK:
		return("vsock");
	case VBAD:
		return("vbad");
	case VFIFO:
		return("vfifo");
	default:
		return("vunk");
	}
	/* NOTREACHED */
}
#endif

static
socktrans(sock)
	struct socket *sock;
{
	static char *stypename[] = {
		"unused",	/* 0 */
		"stream", 	/* 1 */
		"dgram",	/* 2 */
		"raw",		/* 3 */
		"rdm",		/* 4 */
		"seqpak"	/* 5 */
	};
#define	STYPEMAX 5
	struct socket	so;
	struct protosw	proto;
	struct domain	dom;
	struct inpcb	inpcb;
	struct unpcb	unpcb;
	int len;
	char dname[32], *strcpy();

	/* fill in socket */
	if (kread((ls_t)sock, (char *)&so, sizeof(so)) != sizeof(so)) {
		rerr2(errno, (int)sock, "socket");
		return;
	}

	/* fill in protosw entry */
	if (kread((ls_t)so.so_proto, (char *)&proto, sizeof(proto))
	!= sizeof(proto)) {
		rerr2(errno, (int)so.so_proto, "protosw");
		return;
	}

	/* fill in domain */
	if (kread((ls_t)proto.pr_domain, (char *)&dom, sizeof(dom))
	!= sizeof(dom)) {
		rerr2(errno, (int)proto.pr_domain, "domain");
		return;
	}

	/*
	 * grab domain name
	 * kludge "internet" --> "inet" for brevity
	 */
	if (dom.dom_family == AF_INET)
		(void)strcpy(dname, "inet");
	else {
		if ((len = kread((ls_t)dom.dom_name, dname, sizeof(dname) -1))
		< 0) {
			rerr2(errno, (int)dom.dom_name, "char");
			dname[0] = '\0';
		}
		else
			dname[len] = '\0';
	}

	if ((u_short)so.so_type > STYPEMAX)
		(void) printf("* (%s unk%d %x", dname, so.so_type, so.so_state);
	else
		(void) printf("* (%s %s %x", dname, stypename[so.so_type],
		    so.so_state);

	/* 
	 * protocol specific formatting
	 *
	 * Try to find interesting things to print.  For tcp, the interesting
	 * thing is the address of the tcpcb, for udp and others, just the
	 * inpcb (socket pcb).  For unix domain, its the address of the socket
	 * pcb and the address of the connected pcb (if connected).  Otherwise
	 * just print the protocol number and address of the socket itself.
	 * The idea is not to duplicate netstat, but to make available enough
	 * information for further analysis.
	 */
	switch(dom.dom_family) {
	case AF_INET:
		getinetproto(proto.pr_protocol);
		if (proto.pr_protocol == IPPROTO_TCP ) {
			if (so.so_pcb) {
				if (kread((ls_t)so.so_pcb, (char *)&inpcb,
					sizeof(inpcb))
				!= sizeof(inpcb)) {
					rerr2(errno, (int)so.so_pcb, "inpcb");
					return;
				}
				(void) printf(" %x", (int)inpcb.inp_ppcb);
			}
		}
		else if (so.so_pcb)
			(void) printf(" %x", (int)so.so_pcb);
		break;
	case AF_UNIX:
		/* print address of pcb and connected pcb */
		if (so.so_pcb) {
			(void) printf(" %x", (int)so.so_pcb);
			if (kread((ls_t)so.so_pcb, (char *)&unpcb,
				sizeof(unpcb))
			!= sizeof(struct unpcb)) {
				rerr2(errno, (int)so.so_pcb, "unpcb");
				return;
			}
			if (unpcb.unp_conn) {
				char shoconn[4], *cp;

				cp = shoconn;
				if (!(so.so_state & SS_CANTRCVMORE))
					*cp++ = '<';
				*cp++ = '-';
				if (!(so.so_state & SS_CANTSENDMORE))
					*cp++ = '>';
				*cp = '\0';
				(void) printf(" %s %x", shoconn,
					(int)unpcb.unp_conn);
			}
		}
		break;
	default:
		/* print protocol number and socket address */
		(void) printf(" %d %x", proto.pr_protocol, (int)sock);
	}
	(void) printf(")\n");
}

/*
 * getinetproto --
 *	print name of protocol number
 */
static
getinetproto(number)
	int number;
{
	char *cp;

	switch(number) {
	case IPPROTO_IP:
		cp = "ip";
		break;
	case IPPROTO_ICMP:
		cp ="icmp";
		break;
	case IPPROTO_GGP:
		cp ="ggp";
		break;
	case IPPROTO_TCP:
		cp ="tcp";
		break;
	case IPPROTO_EGP:
		cp ="egp";
		break;
	case IPPROTO_PUP:
		cp ="pup";
		break;
	case IPPROTO_UDP:
		cp ="udp";
		break;
#ifdef	IPPROTO_IDP
	case IPPROTO_IDP:
		cp ="idp";
		break;
#endif
	case IPPROTO_RAW:
		cp ="raw";
		break;
	default:
		(void) printf(" %d", number);
		return;
	}
	(void) printf(" %s", cp);
}

static
readf()
{
	struct file lfile;
	int i;

	itrans(DTYPE_INODE, (char *)u->u_cdir, WD);
	for (i = 0; i < NOFILE; i++) {
#ifdef	DYNIX
		if (u->u_lofile[i].of_file == NULL)
			continue;
		if (kread((ls_t)vtophys((ls_t)u->u_lofile[i].of_file),
#else
		if (u->u_ofile[i] == 0)
			continue;
		if (kread((ls_t)u->u_ofile[i],
#endif
			(char *)&lfile, sizeof(lfile)) != sizeof(lfile))
		{
			rerr1("file", N_KMEM);
			continue;
		}
		itrans(lfile.f_type, (char *)lfile.f_data, i);
	}
}

static
devmatch(idev, inum, name)
	dev_t idev;
	ino_t inum;
	char  **name;
{
	register DEVS *d;

	for (d = devs; d; d = d->next)
		if (d->dev == idev && (d->inum == 0 || d->inum == inum)) {
			*name = d->name;
			return(1);
		}
	return(0);
}

static
getfname(filename)
	char *filename;
{
	struct stat statbuf;
	DEVS *cur;
	char *malloc();

	if (stat(filename, &statbuf)) {
		perror(filename);
		return(0);
	}
	if ((cur = (DEVS *)malloc(sizeof(DEVS))) == NULL) {
		(void) fprintf(stderr, "%s: out of space\n", pname);
		exit(1);
	}
	cur->next = devs;
	devs = cur;

	/* if file is block special, look for open files on it */
	if ((statbuf.st_mode & S_IFMT) != S_IFBLK) {
		cur->inum = statbuf.st_ino;
		cur->dev = statbuf.st_dev;
	}
	else {
		cur->inum = 0;
		cur->dev = statbuf.st_rdev;
	}
	cur->name = filename;
	return(1);
}

static
openfiles()
{
#ifdef sun
    	if ((kd = kvm_open (NULL, NULL, NULL, O_RDONLY)) == 0) {
        	perror ("kvm");
		exit(1);
	}
#endif
	if ((kmem = open(N_KMEM, O_RDONLY, 0)) < 0) {
		perror(N_KMEM);
		exit(1);
	}
	if ((mem = open(N_MEM, O_RDONLY, 0)) < 0) {
		perror(N_MEM);
		exit(1);
	}
	if ((swap = open(N_SWAP, O_RDONLY, 0)) < 0) {
		perror(N_SWAP);
		exit(1);
	}
}

static
kread(addr, buf, len)
	ls_t addr;
	char *buf;
	int len;
{
#ifdef sun
	return(kvm_read(kd, (u_long)addr, buf, len));
#else
	(void) lseek(kmem, addr, L_SET);
	return(read(kmem, buf, len));
#endif
}

static
rerr1(what, fromwhat)
	char *what, *fromwhat;
{
	if (vflg)
		(void) printf("%s: error reading %s from %s",
			pname, what, fromwhat);
}

static
rerr2(err, address, what)
	int err, address;
	char *what;
{
	if (vflg)
		(void) printf("%s: error reading %s at %x from kmem: %s\n",
			pname, what, address, sys_errlist[err]);
}

static long
lgetw(loc)
	ls_t loc;
{
	long word;

	if (kread((ls_t)loc, (char *)&word, sizeof(word)) != sizeof(word))
		rerr2(errno, (int)loc, "word");
	return(word);
}

static
usage()
{
	(void) fprintf(stderr,
		"usage: %s [-v] [-u user] [-p pid] [filename ...]\n", pname);
	exit(1);
}

#ifdef	DYNIX
static ls_t
vtophys(vaddr)
	ls_t vaddr;
{
	u_int paddr;
	
#ifdef	i386
	if (vaddr < 8192)
		return vaddr;
#endif
	paddr = nl[X_SYSMAP].n_value;
	(void) lseek(kmem, (ls_t)paddr, 0);
	(void) read(kmem, (char *)&paddr, sizeof paddr);
	paddr = (int)((int *)paddr + (vaddr / NBPG));
	(void) lseek(kmem, (ls_t)paddr, 0);
	(void) read(kmem, (char *)&paddr, sizeof paddr);
#ifndef	i386
# define	PTBITS	0x1ff	/* 512 byte pages */
#else
# define	PTBITS	0xfff	/* 4096 byte pages */
#endif

	return ((ls_t)(paddr & ~PTBITS) | (vaddr & PTBITS));
}
#endif	/* DYNIX  */
