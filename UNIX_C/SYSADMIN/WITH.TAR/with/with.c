/*
 *      with --- a program to do simple device locking.
 */
/*
 * format of working file (lockfiles)
 * full_name_of_lock_file name_of_device minor0 minor1 ...
 * full name of files must include path (in great detail /.../.../...)
 * there may be as many as MAXPDEV minor devices associated with name_of_device
 * note that name_of_device need not be the same as any minor device
 * example
 * /etc/tape0.lock tape0 /dev/mt0 /dev/mt4 /dev/rmt0 /dev/rmt4
 * /usr/spool/uucp/LCK..cul0 cul0 /dev/cul0
 *
 * $Log:	with.c,v $
 * Revision 2.0  87/10/26  09:32:15  cudcv
 * "Stable"
 * 
 * Revision 1.11  87/10/26  09:19:37  cudcv
 * Cleanup comments, lint
 * 
 * Revision 1.10  86/09/17  09:01:42  cudcv
 * 'waiting for confirmation' message wasn't getting out if stderr buffered.
 * 
 * Revision 1.9  86/08/06  10:34:33  cudcv
 * Make handling of null resource cleaner, allow - as null request.
 * 
 * Revision 1.8  86/06/17  13:14:44  cudcv
 * Allow further arguments to be passed to the shell
 * Return status from shell
 * 
 * Revision 1.7  86/06/17  12:28:45  cudcv
 * Slip of the editor
 * 
 * Revision 1.6  86/01/24  15:01:36  cudcv
 * Restart shell when with is restarted
 * 
 * Revision 1.5  86/01/24  12:09:59  cudcv
 * With would hang if shell was stopped
 * 
 * Revision 1.4  86/01/23  09:38:23  cudcv
 * Was ignoring last device
 * 
 * Revision 1.3  86/01/23  09:02:20  cudcv
 * Make more portable for Gould
 * 
 * Revision 1.2  86/01/21  15:04:35  cudcv
 * Allow second argument with request to operators
 * Record usercode of requester
 * With no arguments lists current locks
 * 
 * Revision 1.1  85/10/07  10:31:25  cudcv
 * Initial revision
 * 
 */
static char RCSid[] = "$Header: with.c,v 2.0 87/10/26 09:32:15 cudcv Exp $";
#include <ctype.h>
#include <pwd.h>
#include <signal.h>
#include <stdio.h>
#include <strings.h>
#include <syslog.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/dir.h>
#include <sys/file.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/wait.h>

#ifndef	PW_NAMEL
#define	PW_NAMEL	8
#endif

#ifndef LOCKSFILE
#define	LOCKSDIR	"/etc/locks"
#define LOCKSFILE	"/etc/locks/lockfiles"
#endif
#define MAXSTLEN        40      /*much more than necessary*/
#define NLOCKS          10      /* "    "     "      "  */
#define MAXPDEV         16	/* max # phys. devices associate with a name*/
#define OWNERONLY       0600    /*protection mode for the devices*/
#define	LOGLEVEL	LOG_CRIT	/* level for syslog's */

#define subdev(LP,n)     (& ( (LP)->physdev[n][0]))         /*all dave's fault*/
#define	mask(i)	(1 << (i-1))	/* for signals */

FILE *fopen();

#ifdef	RLIMIT_INTACT
struct rlimit intact = {1, 1};		/* make ourselves interactive */
#endif

typedef struct {
	char	lok[MAXSTLEN],		/* lock (flock) */
        	dev[MAXSTLEN],		/* what the user calls it (with dev) */
        	physdev[MAXPDEV][MAXSTLEN];	/* /dev/dev */
	int	locked;			/*got lock on this*/
} dev_lk;

dev_lk	locks[NLOCKS];
dev_lk	nolok;

char	*progname;
extern	int	optind;
char	*malloc(), *sprintf();
struct passwd *getpwuid();
extern	char	*sys_siglist[];
extern	char	*sys_errlist[];
extern	int	errno;

int 	silent = 0;
int 	nowait = 0;		/* don't wait until available */
int 	nerrs = 0;
int	nlock = 0;
int	Rootuid = 0, Rootgid = 3; 	/* magic numbers */
int 	uuid, ugid;
char 	*resource;
int	needrequest = 0;	/* got resource, need extra request */
int	requested = 0;		/* have warned of need, while waiting */
int	fulfilled = 0;		/* request fulfilled */
struct passwd *pw;
char	buf[BUFSIZ];
char	**shellargs;

void	print_locks();

main(argc,argv)
int argc;
char *argv[];
{
        register int 	i, pdev;
        register dev_lk *lkp;
	char	*request = NULL;
        int 	c, lockfile, omask;
	int 	mypid = getpid();
	int	cleanup(), fulfil();

	uuid = getuid();
	ugid = getgid();
	if ((pw = getpwuid(uuid)) == (struct passwd *)NULL) {
	    Printf("Who are you ?\n");
	    exit(1);
	}
	(void) endpwent();
	progname = argv[0];
	while ((c = getopt(argc, argv, "sn")) != EOF)
	    switch (c) {
		case 's':	silent++; break;
		case 'n':	nowait++; break;
		case '?':	nerrs++;  break;
	    }
        if (nerrs){
	    Printf("usage: %s [-sn] device [request [parameters]]\n",
		progname);
	    Printf("eg:    %s tape \"cudcv's tape for read, please\"",
		progname);
	    Printf(" -c dd if=/dev/rmt8 ...\n");
	    exit(1);
	}
        if((nlock = read_loks(LOCKSFILE, locks)) < 0){
	    Printf("%s:%s unopenable or messed up.\n",progname,LOCKSFILE);
	    exit(1);
	}
        /* locks have been read-in */

	if (argc == optind) {
	    print_locks();
	    exit(0);
	}

        /*can't be interrupted once we start linking things so ...*/
	omask = sigsetmask((int)0x7fffffff);
        for(i = 1; i < NSIG; i++) {
		/* allow stopping */
		if (i == SIGTSTP || i == SIGTTIN || i == SIGTTOU) continue;
		/* don't catch those normally ignored */
		if (i == SIGURG  || i == SIGCONT ||
		    i == SIGCHLD || i == SIGIO
#ifdef	SIGENQ
			         || i == SIGENQ
#endif
			) continue;
		/* don't catch those currently ignored */
		if (signal(i, cleanup) == SIG_IGN)
			(void) signal(i, SIG_IGN);
	}
	(void) sigsetmask(omask);
	/* don't want to get clobbered by XCPU either */
#ifdef	RLIMIT_INTACT
	if (setrlimit(RLIMIT_INTACT, &intact)) {
		perror("setrlimit");
		exit(1);
	}
#endif
        /*now get resource*/
	resource = argv[optind++];
	if (argc > optind) {
	    request = argv[optind++];
	    if (!*request || !strcmp(request, "-"))
		request = NULL;
	    (void) sprintf(buf, "(%s) with", pw->pw_name);
	    openlog(buf, LOG_PID);
	}
	shellargs = &argv[optind-1];
	if (!strcmp(resource, "-")) {
		resource = NULL;
		lkp = &nolok;
		(void) sprintf(lkp->lok, "%s/%d", LOCKSDIR, getpid());
		(void) strcpy(lkp->dev, "request");
	} else {
		for (i = 0;i < nlock; i++)
	    		if (strcmp(locks[i].dev, resource) == 0) break;
        	if(i >= nlock){
			Printf("I don't know how to get %s.\n", resource);
			nerrs++;
			cleanup(0);
		}
		lkp = &locks[i];
	}

	if ((lockfile = open(lkp->lok, O_WRONLY|O_CREAT, 0644)) < 0) {
	    Printf("%s : cannot open %s : %s\n",
		progname, lkp->lok, sys_errlist[errno]);
	    nerrs++;
	    cleanup(0);
	}
	if (flock(lockfile, LOCK_EX|LOCK_NB) < 0) {
	    if (!resource) {
		Printf("%s: cannot lock %s : %s\n",
		    progname, lkp->lok, sys_errlist[errno]);
		nerrs++;
		cleanup(0);
	    }
	    Printf("%s is in use", lkp->dev);
	    if (nowait) {
		Printf(" - try again later.\n");
		nerrs++;
		cleanup(0);
	    } else {
		Printf(" ... waiting");
		(void) fflush(stderr);
		if (request)
		    syslog(LOGLEVEL, "will need %s, when %s is available",
			request, resource);
		requested++;
		if (flock(lockfile, LOCK_EX) < 0) {
		    Printf("\n%s : cannot lock : %s\n",
			progname, sys_errlist[errno]);
		    nerrs++;
		    cleanup(0);
		} else
		    Printf("\n");
	    }
	}
	(void) write(lockfile, (char *)&mypid, sizeof(int));
	(void) write(lockfile, pw->pw_name, PW_NAMEL);
	(void) ftruncate(lockfile, sizeof(int) + PW_NAMEL);
	lkp->locked++;
	for(pdev = 0;pdev < MAXPDEV && (*subdev(lkp,pdev));pdev++){
	    (void) chown( subdev(lkp,pdev),uuid,ugid );
	    (void) chmod( subdev(lkp,pdev),OWNERONLY);
	}
	if (resource)
		Printf("%s is yours", lkp->dev);
	if (request) {
	    if (resource)
		Printf(" - ");
	    Printf("waiting for confirmation of request");
	    (void) fflush(stderr);
	    omask = sigblock(SIGEMT);
	    (void) signal(SIGEMT, fulfil);
	    needrequest++; requested = 0;
	    (void) write(lockfile, request, strlen(request));
	    if (resource)
		syslog(LOGLEVEL, "have %s, need %s", resource, request);
	    else
		syslog(LOGLEVEL, "need %s", request);
	    syslog(LOGLEVEL, "`kill -EMT %d' or `kill -TERM %d'",
		getpid(), getpid());
	    do {
	        sigpause(omask & ~mask(SIGEMT));
	    } while (!fulfilled);
	    (void) ftruncate(lockfile, sizeof(int) + PW_NAMEL);
	    Printf(" - going");
	    syslog(LOGLEVEL, "going");
	}
	Printf("\n");

	if (resource) shell();

	cleanup(0);
}


int
read_loks(lf, lks)
char *lf;
register dev_lk lks[];
{
        register FILE *lfp;
        register dev_lk *dp;
        register int i;
        int n;
        char line[BUFSIZ];

        lfp = fopen(lf, "r");
        if(lfp == NULL)
                return -1;      /*error*/

        /*now read in the entries*/
        for(dp = lks,i=0; i < NLOCKS ;dp++, i++){
                if( fgets(line,sizeof(line),lfp) == NULL)       /* if EOF*/
                        break;
                                /*read at most 2 + MAXPDEV entries from line*/
                n = sscanf(line,"%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s",
				dp->lok, dp->dev,
                                subdev(dp,0),subdev(dp,1),
                                subdev(dp,2),subdev(dp,3),
                                subdev(dp,4),subdev(dp,5),
                                subdev(dp,6),subdev(dp,7),
                                subdev(dp,8),subdev(dp,9),
                                subdev(dp,10),subdev(dp,11),
                                subdev(dp,12),subdev(dp,13),
                                subdev(dp,14),subdev(dp,15));
                if(n < 3){      /*if line was bad format or blank ...*/
                        dp--;i--;                               /*try again*/
                        continue;}
                if(n < MAXPDEV + 2)
                        *subdev(dp, n - 2) = '\0';              /*no string*/
		dp->locked = 0;
                }
	(void) fclose(lfp);
        return i;       /*'i' is the # of lines read successfully*/
}

void
print_locks()
{
	register dev_lk *lkp;
	int nent;
	struct direct **dp, **names;
	int pids(), numsort();

	for (lkp = &locks[0]; lkp < &locks[nlock]; lkp++) {
		print_lock(lkp->lok, lkp->dev);
	}
	if (chdir(LOCKSDIR)) {
		perror(LOCKSDIR);
		return;
	}
	if ((nent = scandir(".", &names, pids, numsort)) < 0) {
		perror("scandir");
		return;
	}
	for (dp = &names[0]; dp < &names[nent]; dp++) {
		print_lock((*dp)->d_name, (char *)NULL);
	}
}

print_lock(lok, dev)
	char *lok, *dev;
{
	int i, lockfile, pid;

	if ((lockfile = open(lok, O_RDONLY)) < 0)
		return;
	if (flock(lockfile, LOCK_SH|LOCK_NB) < 0) {
		(void) read(lockfile, (char *)&pid, sizeof(int));
		(void) read(lockfile, buf, PW_NAMEL);
		buf[PW_NAMEL] = '\0';
		if (dev)
			Printf("%s in use by ", dev);
		Printf("%u (%s)", pid, buf);
		if ((i = read(lockfile, buf, BUFSIZ)) > 0) {
			buf[i] = '\0';
			Printf(": needs %s", buf);
		}
		Printf("\n");
	}
	(void) close(lockfile);
}

int
pids(dp)
	struct direct *dp;
{
	register char *p = dp->d_name;
	while (*p)
		if (!isdigit(*p++))
			return(0);
	return(1);
}

int
numsort(d1, d2)
	struct direct **d1, **d2;
{
	int p1, p2;

	p1 = atoi((*d1)->d_name);
	p2 = atoi((*d2)->d_name);
	return p1 - p2;
}

static int child;

sigcont()
{
	(void) kill(child, SIGCONT);
}

shell()
{
	register i;
	char *myshell, *shellt;
	union wait status;
	char *getenv(), *rindex();
	int omask;

	if (!(myshell = getenv("SHELL")))
		myshell = "/bin/sh";
	if (shellt = rindex(myshell, '/'))
		shellt++;
	else
		shellt = myshell;

	/* ignore keyboard generated signals now - could manipulate process
	 * groups I suppose, but I'm lazy
	 * First block them over the fork
	 */
	omask = sigblock(mask(SIGINT)|mask(SIGQUIT));
	(void) fflush(stderr);
	if ((child = vfork()) == 0) {
		/* normal keyboard signals in shell */
		(void) sigsetmask(omask);
		child = getpid();
		(void) setuid(uuid);
		(void) setgid(ugid);
		for(i = getdtablesize(); i > 3; )
			(void) close(--i);
		shellargs[0] = shellt;
		execv(myshell, shellargs);
		Printf("%s : couldn't execute %s : %s\n",
			progname, myshell, sys_errlist[errno]);
		_exit(1);
	} else if (child < 0) {
		Printf("%s : couldn't fork : %s\n",
			progname, sys_errlist[errno]);
	} else {
		/* ignore keyboard signals in parent */
		(void) signal(SIGINT, SIG_IGN);
		(void) signal(SIGQUIT, SIG_IGN);
		(void) signal(SIGCONT, sigcont);
		(void) sigsetmask(omask);
		do {
			while((i = wait3(&status,
					WUNTRACED,
					(struct rusage *)NULL)) > 0
				&& i != child);
			if (status.w_stopval == WSTOPPED)
				(void) kill(0, (int)status.w_stopsig);
			else
				nerrs = status.w_retcode;
		} while (status.w_stopval == WSTOPPED);
	}
}

restore(lkp)    /*restores ownership and protections for resources unlocked*/
register dev_lk *lkp;
{
        register int pdev;

        for(pdev = 0;pdev < MAXPDEV && (*subdev(lkp,pdev));pdev++){
                (void) chown( subdev(lkp,pdev),Rootuid,Rootgid );
                (void) chmod( subdev(lkp,pdev),OWNERONLY);
		}
}

/* VARARGS1 */
Printf(f, a, b, c, d) char *f;
{
	if (!silent) (void) fprintf(stderr, f, a, b, c, d);
}

fulfil() { fulfilled = 1; }

cleanup(sig)
{
	register dev_lk *lkp;

	/* wait for child to finish before we go ourselves */
	if (!nerrs || sig) Printf("\n");
	if (sig) Printf("%s\n", sys_siglist[sig]);
	if (requested) syslog(LOGLEVEL, "request withdrawn");
	if (needrequest) {
		if (sig) {
			Printf("Request denied\n");
			syslog(LOGLEVEL, "request denied");
		} else if (resource) {
			syslog(LOGLEVEL, "done with %s", resource);
		}
	}
	/* check if there's anything to wait for */
	if (!wait3((union wait *)NULL, WNOHANG, (struct rusage *)NULL))
		Printf("waiting for shell to exit\n");
	(void) fflush(stderr);
	while (wait((union wait *)NULL) > 0);
	for (lkp = &locks[0]; lkp < &locks[nlock]; lkp++)
	    if (lkp->locked) {
		restore(lkp);
		Printf("%s released.\n", lkp->dev);
	    }
	if (!resource)
		(void) unlink(nolok.lok);
        exit(sig ? -1 : nerrs);
}
