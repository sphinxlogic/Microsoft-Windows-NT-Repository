 
/*  @(#)patchlevel.h 1.12 89/12/21
 *
 *  This is the current patch level for this version of calctool.
 *
 *  Copyright (c) Rich Burridge.
 *		Sun Microsystems, Australia - All rights reserved.
 *
 *  Permission is given to distribute these sources, as long as the
 *  copyright messages are not removed, and no monies are exchanged.
 *
 *  No responsibility is taken for any errors or inaccuracies inherent
 *  either to the comments or the code of this program, but if
 *  reported to me then an attempt will be made to fix them.
 */

#define  PATCHLEVEL  4
