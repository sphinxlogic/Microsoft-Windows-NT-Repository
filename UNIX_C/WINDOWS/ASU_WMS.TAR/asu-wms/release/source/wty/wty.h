/****************************************************************************\
 * Copyright 1985 by George Nelan, Arizona State University.                *
 * All rights reserved.  Permission to use, modify, and copy these programs *
 * and documentation is granted, provided that the copy is not sold and     *
 * that this copyright and permission notice appear on all copies.          *
\****************************************************************************/

/* Command Sequence Introducer */
#define W_CSI	"\033@"	/* ESC @ */

/*
 * ANSI function compatible TERMCAP entries for wty_.
 * Note: Capabilities marked with [*] are optional in the host definition.
 * 	 Capabilities marked with (*) are optional only if the corresponding
 *	 wty_ TERMCAP capabilities are edited out of the wty_ entry.
 */

#define	W_AL	"A"	/* Add Line 			(*)	*/
			/* AM (Automatic Margin)	(*)	*/
#define	W_BC	"B"	/* Backspace Character 		[*]	*/
#define W_CD	"C"	/* Clear to end of Display 	(*)	*/
#define W_CE	"D"	/* Clear to End of line 	(*)	*/
#define W_CL	"E"	/* CLear display 		(*)	*/
#define W_CM	"F"	/* Cursor Motion 			*/
			/* CO# (# COlumns)		[*]	*/
#define W_CR	"G"	/* Carriage Return 		[*]	*/
#define	W_DC	"H"	/* Delete Character 		(*)	*/
#define	W_DL	"I"	/* Delete Line 			(*)	*/
#define W_DO	"J"	/* DOwn line 			[*]	*/
#define W_HO	"K"	/* HOme cursor 			(*)	*/
#define W_IC	"L"	/* Insert Character 		(*)	*/
#define W_IS	"M"	/* Initialization String 	[*]	*/
#define W_KE	"N"	/* Keypad End 			[*]	*/
#define W_KS	"O"	/* Keypad Start 		[*]	*/
			/* LI# (# LInes)		[*]	*/
#define W_ND	"P"	/* NonDestructive space 	(*)	*/
#define W_NL	"Q"	/* NewLine 			[*]	*/
#define W_SE	"R"	/* Standout End 		(*)	*/
#define W_SF	"S"	/* Scroll Forwards (up) 	(*)	*/
			/* SG# 				[*]	*/
#define W_SO	"T"	/* StandOut start 		(*)	*/
#define	W_SR	"U"	/* Scroll Reverse (down) 	(*)	*/
#define W_UE	"V"	/* Underscore End 		(*)	*/
			/* UG# 				[*]	*/
#define W_UP	"W"	/* UP Line			(*)	*/
#define W_US	"X"	/* Underscore Start		(*)	*/
#define W_VE	"Y"	/* Visual End 			[*]	*/
#define W_VS	"Z"	/* Visual Start 		[*]	*/
#define W_WE	"a"	/* Wty End	 		[*]	*/
#define W_WS	"b"	/* Wty Start	 		[*]	*/

