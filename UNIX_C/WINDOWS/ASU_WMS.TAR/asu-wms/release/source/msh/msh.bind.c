/****************************************************************************\
 * Copyright 1985 by George Nelan, Arizona State University.                *
 * All rights reserved.  Permission to use, modify, and copy these programs *
 * and documentation is granted, provided that the copy is not sold and     *
 * that this copyright and permission notice appear on all copies.          *
\****************************************************************************/

/* AUTHOR: GEORGE NELAN */
/* discreet version msh binder */

#include <stdio.h>

extern	init_msh();
extern	slave_driver();

#include <sys/ioctl.h>


/****************************************************************************/
main (argc,argv) 
int argc;
char *argv[];
{
	init_msh();
	for (;;) {
		slave_driver();
	}
} /* main */


/****************************************************************************/
int get_master(chp)
register char *chp;
/* return > 0 if std input ready, 
 * else return <= 0 if not ready or error.
 */
 {
	int tlen;

	if (ioctl(0,FIONREAD,&tlen) == (-1))
		return(-1);
	if ((tlen > 0) && ((tlen = read(0,chp,1)) == (-1)))
		return(-1);
	return(tlen);
} /* get_master */


/****************************************************************************/
put_master(chp,len) 
register char *chp;
register int len;
{
	write(1,chp,len);
} /* put_master */

