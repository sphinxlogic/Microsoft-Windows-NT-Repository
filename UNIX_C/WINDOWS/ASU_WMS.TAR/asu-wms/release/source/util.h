/****************************************************************************\
 * Copyright 1985 by George Nelan, Arizona State University.                *
 * All rights reserved.  Permission to use, modify, and copy these programs *
 * and documentation is granted, provided that the copy is not sold and     *
 * that this copyright and permission notice appear on all copies.          *
\****************************************************************************/

#define STDIN  0
#define STDOUT 1
#define STDERR 2

#define reg register

typedef char bool;

#define TRUE 1
#define FALSE 0

#define NIL (-1)

#define fail(x) ((x)==(-1))

#define public

