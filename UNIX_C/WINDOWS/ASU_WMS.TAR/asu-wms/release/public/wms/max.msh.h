/****************************************************************************\
 * Copyright 1985 by George Nelan, Arizona State University.                *
 * All rights reserved.  Permission to use, modify, and copy these programs *
 * and documentation is granted, provided that the copy is not sold and     *
 * that this copyright and permission notice appear on all copies.          *
\****************************************************************************/

/************************************************************************/
/*		THIS FILE IS SUPPOSED TO BE READ-ONLY			*/
/************************************************************************/

/* all absolute maximums for adjustable max parameters are here */

#define		AMAXSLAVES	9
#define		AMAXNOPOLLS	1024
#define		AMAXSHELL	128
#define		AMAXTCODE	128
#define		AMAXCBUF	512

/* see "max.msh.c" for declarations of following... */

extern	int	MAXSLAVES;
extern	int	MAXNOPOLLS;
extern	int	MAXSHELL;
extern	int	MAXTCODE;
extern	int	MAXCBUF;

