/****************************************************************************\
 * Copyright 1985 by George Nelan, Arizona State University.                *
 * All rights reserved.  Permission to use, modify, and copy these programs *
 * and documentation is granted, provided that the copy is not sold and     *
 * that this copyright and permission notice appear on all copies.          *
\****************************************************************************/

/************************************************************************/
/*		THIS FILE IS SUPPOSED TO BE READ-ONLY			*/
/************************************************************************/

/* all absolute maximums for adjustable max parameters are here */

#include "max.msh.h"

#define		AMAXWINDOWS 	AMAXSLAVES
#define		AMAXLABEL	(AMAXSLAVES + '0')
#define		AMAXQBUF	(AMAXCBUF << 2)

/* see "max.wty.c" for declarations of following... */

extern	int	MAXWINDOWS;
extern	char	MAXLABEL;
extern	int	MAXQBUF;

