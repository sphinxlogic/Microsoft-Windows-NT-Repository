/****************************************************************************\
 * Copyright 1985 by George Nelan, Arizona State University.                *
 * All rights reserved.  Permission to use, modify, and copy these programs *
 * and documentation is granted, provided that the copy is not sold and     *
 * that this copyright and permission notice appear on all copies.          *
\****************************************************************************/

/* all wty adjustable max parameters are here */
/* note that they all must be <= maximums as defined in "max.wty.h" */

#include "max.msh.c"

int	MAXWINDOWS 	= 4;		/* == MAXSLAVES */
char	MAXLABEL	= 4 + '0';	/* == MAXSLAVES + '0' */
/* be sure to update max.msh.c !! (MAXSLAVES) */

int	MAXQBUF		= 256;		/* MAXCBUF << 2 */
