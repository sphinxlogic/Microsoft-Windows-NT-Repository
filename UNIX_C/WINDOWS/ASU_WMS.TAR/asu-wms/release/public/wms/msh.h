/****************************************************************************\
 * Copyright 1985 by George Nelan, Arizona State University.                *
 * All rights reserved.  Permission to use, modify, and copy these programs *
 * and documentation is granted, provided that the copy is not sold and     *
 * that this copyright and permission notice appear on all copies.          *
\****************************************************************************/

/* command sequence introducer for msh input */
#define M_CSI	"\0@"

/* commands */
#define M_QX	"A"	/* quit execution */
#define M_SS	"B"	/* set shell */
#define M_CC	"C"	/* create csh shell */
#define M_CU	"D"	/* create user shell */
#define M_RS	"E"	/* reset shell size */
#define M_DS	"F"	/* delete shell */
#define M_SX	"G"	/* stop execution (4.2bsd only) */

/* msh output windowing operation: (atomic command) */
#define W_WG	"\027"	/* ^W: Window: Goto window */

