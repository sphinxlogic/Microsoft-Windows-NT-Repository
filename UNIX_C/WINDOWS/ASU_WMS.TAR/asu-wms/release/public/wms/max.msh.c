/****************************************************************************\
 * Copyright 1985 by George Nelan, Arizona State University.                *
 * All rights reserved.  Permission to use, modify, and copy these programs *
 * and documentation is granted, provided that the copy is not sold and     *
 * that this copyright and permission notice appear on all copies.          *
\****************************************************************************/

/* all msh adjustable max parameters are here */
/* note that they all must be <= maximums as defined in "max.msh.h" */

int	MAXSLAVES	= 4;		/* whatever */
int	MAXNOPOLLS	= 64;		/* tuned! */
int	MAXSHELL	= 64;		/* whatever */
int	MAXTCODE	= 64;		/* whatever */
int	MAXCBUF		= 128;		/* tuned! */
