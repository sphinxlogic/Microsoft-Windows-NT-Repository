#include <termio.h>
#include <sys/window.h>
#include <stdio.h>

extern int maxw,maxh;
extern int invert;
extern int transpose;
extern int iconopen;
extern int normal;
extern int new_wind;
extern int Wn;
extern char **environ;
