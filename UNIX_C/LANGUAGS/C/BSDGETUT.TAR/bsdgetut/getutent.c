/**
 **  Simulate SysV getutent(3) calls, as best as can be done in
 **  a System III environment, at least.
 **
 **  Author: Paul Sutcliffe, Jr.  <paul@devon.uucp>
 **
 **  I hereby place this in the public domain.
 **  No warranties expressed or implied.
 **/

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <utmp.h>

static char *utmpfil = "/etc/utmp";	/* default utmp file */
static FILE *ufp = NULL;		/* file pointer to utmp file */
					/* NULL = no utmp file open  */
static struct utmp ut;			/* buffer for utmp record */

struct utmp *getutent(), *getutline();
void pututline(), setutent(), endutent(), utmpname();

struct utmp *
getutent()
{
	FILE *fopen();

	if (ufp == NULL) {
		if ((ufp = fopen(utmpfil, "r+")) == NULL) {
			return((struct utmp *)NULL);
		}
	}
	do {
		if (fread((char *)&ut, sizeof(ut), 1, ufp) != 1) {
			return((struct utmp *)NULL);
		}
	} while (ut.ut_name[0] == 0);		/* valid entry? */

	return(&ut);
}

struct utmp *
getutline(line)
struct utmp *line;
{
	do {
		if (strcmp(ut.ut_line, line->ut_line) == 0) {
			return(&ut);
		}
	} while (getutent() != (struct utmp *)NULL);

	return((struct utmp *)NULL);
}

void
setutent()
{
	if (ufp != NULL) rewind(ufp);
}
	
void
endutent()
{
	if (ufp != NULL) fclose(ufp);
}

void
utmpname(file)
char *file;
{
	utmpfil = file;
}
