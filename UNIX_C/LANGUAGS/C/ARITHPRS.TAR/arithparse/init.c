/*
 * Aho, A. V., R Sethi, and J. D. Ullman [1986]
 * Compilers Principles, Techniques, and Tools
 * pages 73 - 78
 */

#include "global.h"

struct entry keywords[] = {
    "div", DIV,
    "mod", MOD,
    0, 0
};

init()			/* loads keywords into symtable */
{
    struct entry *p;
    for (p = keywords; p->token; p++)
	insert(p->lexptr, p->token);
}
