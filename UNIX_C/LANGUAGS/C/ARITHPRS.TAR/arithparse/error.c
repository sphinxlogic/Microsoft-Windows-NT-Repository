/*
 * Aho, A. V., R Sethi, and J. D. Ullman [1986]
 * Compilers Principles, Techniques, and Tools
 * pages 73 - 78
 */

#include "global.h"

error(m)		/* generates all error messages */
    char *m;
{
    fprintf(stderr, "line %d: %s\n", lineno, m);
    exit(1);		/* unsuccessful termination */
}
