/*
 * Aho, A. V., R Sethi, and J. D. Ullman [1986]
 * Compilers Principles, Techniques, and Tools
 * pages 73 - 78
 */

#include "global.h"

main()
{
    init();
    parse();
    exit(0);		/* successful termination */
}
