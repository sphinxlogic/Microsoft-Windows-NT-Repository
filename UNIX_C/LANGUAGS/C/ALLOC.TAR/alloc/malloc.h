extern char		*malloc(/* unsigned */);
extern char		*realloc(/* char *,unsigned */);
extern void		free(/* char * */);

extern char		*calloc(/* unsigned,unsigned */);
extern void		cfree(/* char * */);

extern int		mallopt();
#   define M_MXFAST	    1		/* Core allocation watermarks	*/
#   define M_LBLKS	    2		/* Blocks in a chunk		*/
#   define M_GRAIN	    3		/* Small blocks rounded to this	*/
#   define M_KEEP	    3		/* free() must not deallocate	*/

struct mallinfo
{
    int			    arena;
    int			    ordblks;
    int			    smblks;
    int			    hblks;
    int			    hblkhd;
    int			    usmblks;
    int			    fsmblks;
    int			    uordblks;
    int			    fordblks;
    int			    keepcost;
};

extern struct mallinfo	mallinfo();
