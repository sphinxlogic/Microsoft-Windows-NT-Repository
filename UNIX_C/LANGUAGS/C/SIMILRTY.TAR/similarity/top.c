/*	This file is part of the software similarity tester SIM.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
*/

#include	"text.h"
#include	"top.p"
#include	"top.h"

#ifndef	lint		/* lint won't take this define ?!?!?! */
#define	longer(r0,r1)	(r0->rn_quality > r1->rn_quality)

#else
static int
longer(r0, r1) struct run *r0, *r1;	{
	return r0->rn_quality > r1->rn_quality;
}
#endif	lint

/* Instantiate top.g  */
#include	"top.g"
