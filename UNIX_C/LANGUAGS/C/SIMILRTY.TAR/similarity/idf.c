/*	This file is part of the software similarity tester SIM.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
*/

#include	"idf.h"

int
findidf(str, list, size)
	char *str;
	struct idf list[];
{
	int first = 0;
	int last = size - 1;

	while (first < last)	{
		int middle = (first + last) / 2;

		if (strcmp(str, list[middle].id_tag) > 0)
			first = middle + 1;
		else	last = middle;
	}
	return strcmp(str, list[first].id_tag) == 0 ? list[first].id_tr : -1;
}
