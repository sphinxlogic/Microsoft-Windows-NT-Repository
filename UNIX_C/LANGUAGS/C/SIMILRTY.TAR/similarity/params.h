/*	This file is part of the software similarity tester SIM.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
*/

#define	MIN_RUN		24		/*	default minimum size
						of interesting run
					*/
#define	PAGE_WIDTH	80
