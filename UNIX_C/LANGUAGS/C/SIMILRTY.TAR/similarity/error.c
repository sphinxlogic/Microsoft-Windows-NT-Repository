/*	This file is part of the software similarity tester SIM.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
*/

#include	<stdio.h>

error(msg)
	char *msg;
{
	fprintf(stderr, "sim: %s\n", msg);
	exit(1);
}
