/*	This file is part of the software similarity tester SIM.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
*/

/* This is the public interface of top.g, a generic package for keeping
/* a top-10 list of objects of formal type.
/*
/* The application of this file must be preceded by
/* #include "top.p", which defines the parameters of the instantiation.
*/

extern InitTop();
extern InsertTop();
typedef int TopGen;
extern OpenTop();
extern TTTYPE *NextTop();
#define	NoObject	((TTTYPE*)0)
extern CloseTop();
