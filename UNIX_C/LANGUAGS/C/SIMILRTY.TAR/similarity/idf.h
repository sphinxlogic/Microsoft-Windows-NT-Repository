/*	This file is part of the software similarity tester SIM.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
*/

/* the struct for keywords etc. */
struct idf	{
	char *id_tag;	/* an interesting identifier */
	char id_tr;	/* with its one-character translation */
};

#define idf2char(s,l)	findidf(s, l, sizeof l / sizeof l[0])
