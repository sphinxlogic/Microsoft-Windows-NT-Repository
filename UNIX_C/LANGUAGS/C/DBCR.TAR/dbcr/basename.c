/* Copyright (c) 1986, Greg McGary */
static char sccsid[] = "@(#)basename.c	1.1 86/10/09";

#include	<string.h>

char *basename();
char *dirname();

char *
basename(path)
	char		*path;
{
	char		*base;

	if ((base = strrchr(path, '/')) == 0)
		return path;
	else
		return ++base;
}

char *
dirname(path)
	char		*path;
{
	char		*base;

	if ((base = strrchr(path, '/')) == 0)
		return ".";
	else
		return strnsav(path, base - path);
}
