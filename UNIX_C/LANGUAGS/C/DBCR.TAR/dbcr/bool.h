/* Copyright (c) 1986, Greg McGary */
/* @(#)bool.h	1.1 86/10/09 */

typedef	int	bool;
#define	TRUE	(0==0)
#define	FALSE	(0!=0)
