/*	abs (num) return absolute value */
abs(num) int num;{
	if (num < 0) return (-num);
	else	     return (num);
	}
