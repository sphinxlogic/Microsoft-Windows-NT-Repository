#include <stdio.h>
putchar(c) char c; {
	return fputc(c, stdout);
}
