static char S_ttestc[]=
	"@(#)ttest.c, 1.1 - Gregg Wonderly@a.cs.okstate.edu  -  16:55:50, 3/1/88";

#include <signal.h>

extern exit(), sub1(), sub2(), sub3(), catch();

main (argc, argv)
	int argc;
	char **argv;
{

	if (set_timer (8, sub1, (char *)8)) {
		perror ("set_timer");
		exit (1);
	}
	if (set_timer (1, sub1, (char *)1)) {
		perror ("set_timer");
		exit (1);
	}
	if (set_timer (3, sub1, (char *)3)) {
		perror ("set_timer");
		exit (1);
	}
	if (set_timer (6, sub1, (char *)6)) {
		perror ("set_timer");
		exit (1);
	}
	if (set_timer (5, sub1, (char *)5)) {
		perror ("set_timer");
		exit (1);
	}

	if (set_timer (26, exit, (char *)0)) {
		perror ("set_timer");
		exit (1);
	}

	signal (SIGINT, catch);
	while (1) {
		pause ();
		if (!did_timer())
			perror ("pause");
		if (did_timer())
			perror ("set_timer");
	}
}

sub1(i)
	char *i;
{
	printf ("%d\n", (int)i);
	set_timer ((int)i, sub2, (char *) ((int)i*2));
}

sub2 (i)
	char *i;
{
	printf ("*%d\n", (int)i);
	set_timer ((int)i/2, sub3, (char *)((int)i+((int)i/2)));
	if ((int)i < 10)
		can_timer (sub3, (char *)((int)i+((int)i/2)));
}

sub3(i)
	char *i;
{
	printf ("**%d\n", (int)i);
}

catch (i)
	int i;
{
	signal (i, catch);
}
