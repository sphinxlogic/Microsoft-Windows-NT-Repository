/*
 * Copyright (C) 1988, Marcus J. Ranum, William Welch Medical Library
 * $Author: mjr $
 */

#ifndef lint
static char *RCSid="$Header: treedump.c,v 1.1 88/06/01 21:35:46 mjr Rel $: treedump.c";
#endif

/*
 * $Log:	treedump.c,v $
 * Revision 1.1  88/06/01  21:35:46  mjr
 * Initial revision
 * 
 */


/* dump a tree to the standard output */

#ifdef BSD
#include <sys/file.h>
#endif
#ifdef SYSV
#include <sys/fcntl.h>
#endif
#include <stdio.h>
#include "btree.h"

main(ac,av)
int	ac;
char	*av[];
{

	BTREE	*bt;
	BTNODE	cnode;
	long	nbr =0L;

	if(ac < 2) {
		(void)fprintf(stderr,"usage: %s <file>\n",av[0]);
		exit(1);
	}

	if((bt = btopen(av[1],O_RDWR,0600)) == NULL) {
		btperror(av[1]);
		exit(1);
	}

	/* if btnext is called with nbr = 0, it automatically winds to the */
	/* front of the file - as in this example */
	while (1) {
		switch (btnext(&nbr, &cnode, bt)) {
		case (-1):
			btperror("btnext");
			(void)btclose(bt);
			exit(1);

		case (0):
			(void)printf("%s\n",cnode.key);
			break;

		case (BT_EOF):
			(void)btclose(bt);
			exit(0);
		}
	}
}
