/*
 * Copyright (C) 1988, Marcus J. Ranum, William Welch Medical Library
 * $Author: mjr $
 */

/*
 * $Header: recio.h,v 1.1 88/06/01 21:28:06 mjr rel $: recio.h
 *
 * $Log:	recio.h,v $
 * Revision 1.1  88/06/01  21:28:06  mjr
 * Initial revision
 * 
 */

#ifndef	_INCL_RECIO_H


/* this is actually highly dependent on a few major assumptions: */
/* 1) you can lseek() past EOF and extend with 'holes' */
/* (which fails under MSDOS, I think, but who cares about DOS) */
/* 2) when you read data from a 'hole' in a file, it will */
/* come back zeros - hence we can check the flags to */
/* see if it is free based on that. If your system does */
/* not work in this way, you're out of luck, or you have */
/* to construct large blank databases beforehand */
/* this indicates a node deleted */
#define	RI_DELETED	0
#define	RI_ACTIVE	-1L

/* as a result of using 0L as an indicator of being a free block or a */
/* null block, we have a left-over page at page #0. This can be used to */
/* store invariant information */

/* our magic number - just to be safe */
#define	RI_MAGIC	0x72252

/* record file superblock (one at head of map file) */
struct	risuper	{
	long	magic;		/* magic number */
	int	reclen;		/* record chunk length (variable) */
	long	free;		/* head of free chain */
	long	last;		/* last page in file (alternate free list) */
};


/* an individual record header - one per record in map file */
/* the map file consists of nothing but the superblock and one */
/* of these critters per record */
struct	rimap	{
	long	page;		/* assigned page if any, else 0L for free */
	long	tail;		/* tail of assigned page list */
};


/* a page header - one at the head of each page in page file. */
/* for now, quite rudimentary - room for more data if needed */
/* otherwise it would not be worth defining a structure */
/* - note - the use of longs here is a bit unecessary, but this */
/* way its 4 longs, and there are no alignment problems between */
/* my Sun and my VAX. Its a pain - feel free to fix it */
struct	ripag	{
	long	recno;		/* extra to help reconstruct crashes */
	long	next;		/* next page pointer 0L = no next */
	long	deleted;	/* 0 is free, anything else is not */
	long	high;		/* this page highwater mark (EOF) */
};


/* the actual control structure. Includes a buffer for reading pages */
/* and a few other handy buffers for map entries, etc */
struct	rifd	{
	int	fd;		/* record file descriptor */
	int	mfd;		/* free map file descriptor */
	struct	risuper	sblk;	/* superblock */
				/* all used to emulate stdio, sort of */
	char	*dat;		/* page record buffer (malloced in riopen()) */
	long	curpag;		/* used to simulate consecutive reads */
	long	currec;		/* used to simulate consecutive reads */
	int	pagoff;		/* offset within current page */
};
#define	RIFD	struct	rifd

extern	struct	rifd	*riopen();
extern	long	riseek();
extern	char	*rigets();

#define	_INCL_RECIO_H
#endif
