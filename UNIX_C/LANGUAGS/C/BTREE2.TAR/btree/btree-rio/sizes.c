/*
 * Copyright (C) 1988, Marcus J. Ranum, William Welch Medical Library
 * $Author: mjr $
 */

#ifndef lint
static char *RCSid="$Header: sizes.c,v 1.1 88/06/01 21:27:31 mjr Rel $: sizes.c";
#endif

/*
 * $Log:	sizes.c,v $
 * Revision 1.1  88/06/01  21:27:31  mjr
 * Initial revision
 * 
 */

/* provides some minimally useful info about how big your */
/* data structures are */

#include "recio.h"

main()
{
	(void)printf("a record I/O control structure is %d bytes\n",sizeof(RIFD));
	(void)printf("(that is without the dynamically allocated page buffer)\n");
	(void)printf("\na map block is %d bytes\n",sizeof(struct rimap));
	(void)printf("\na page header is %d bytes\n",sizeof(struct ripag));
	(void)printf("make sure these sizes match, if you're running on\n");
	(void)printf("several different types of CPUs.\n");
}
