/*
 * Copyright (C) 1988, Marcus J. Ranum, William Welch Medical Library
 * $Author: mjr $
 */

#ifndef lint
static char *RCSid="$Header: recio.c,v 1.4 88/06/06 13:44:58 mjr Exp $: recio.c";
#endif

/*
 * $Log:	recio.c,v $
 * Revision 1.4  88/06/06  13:44:58  mjr
 * fixed the drop of occasional chars in rigets()
 * 
 * Revision 1.3  88/06/06  09:58:58  mjr
 * *** empty log message ***
 * 
 * Revision 1.2  88/06/02  15:35:32  mjr
 * added rigetcurpag and risetcurpag
 * 
 * Revision 1.1  88/06/01  21:27:20  mjr
 * Initial revision
 * 
 */

#include	<stdio.h>
#include	"recio.h"

/* if we wish to store our disk data in network byte order */
#ifdef	BYTEORDER
#include	<sys/types.h>
#include	<netinet/in.h>
#endif

/* size of a page header (without buffer) */
#define	RI_PHSIZ	sizeof(struct ripag)

/* size of a page (with buffer) */
#define	RI_PSIZ(rf)	(sizeof(struct ripag) + (rf)->sblk.reclen)

/* size of a rifd superblock */
#define	RI_SSIZ		(sizeof(struct risuper))

/* size of a map file entry */
#define	RI_MSIZ		(sizeof(struct rimap))

/* write the rifd mapfile superblock to disk */
static int
wsuper(rf)
struct	rifd	*rf;
{
	extern	long	lseek();
#ifdef	BYTEORDER
	struct	risuper boge;
#endif


	if (lseek(rf->mfd, 0L, 0) < 0)
		return (-1);

#ifdef	BYTEORDER
	boge.magic = htonl(rf->sblk.magic);
	boge.reclen = htonl(rf->sblk.reclen);
	boge.free = htonl(rf->sblk.free);
	boge.last = htonl(rf->sblk.last);

	if (write(rf->mfd, (char *) &boge, RI_SSIZ) != RI_SSIZ)
		return (-1);
#else
	if (write(rf->mfd, (char *) &rf->sblk, RI_SSIZ) != RI_SSIZ)
		return (-1);
#endif


	return (0);
}



/* read the rifd mapfile superblock from disk */
static int
rsuper(rf)
struct	rifd	*rf;
{
	extern	long	lseek();
#ifdef	BYTEORDER
	struct	 risuper boge;
#endif

	if (lseek(rf->mfd, 0L, 0) < 0)
		return (-1);

#ifdef	BYTEORDER
	if (read(rf->mfd, (char *) &boge, RI_SSIZ) != RI_SSIZ)
	return (-1);

	rf->sblk.magic = ntohl(boge.magic);
	rf->sblk.reclen = ntohl(boge.reclen);
	rf->sblk.free = ntohl(boge.free);
	rf->sblk.last = ntohl(boge.last);
#else
	if (read(rf->mfd, (char *) &rf->sblk, RI_SSIZ) != RI_SSIZ)
		return (-1);
#endif

	return (0);
}



/* dynamically allocate a control structure for an open rifd */
/* including opening and checking the mapfile and textfile */
struct rifd	*
riopen(path, flags, mode, reclen)
char	*path[2];
int	flags;
int	mode;
int	reclen;
{
	struct	rifd	*rf;
	int	r;
	extern	char	*malloc();

	/* lets be dynamic, shall we ? */
#ifndef lint
	/* this to avoid the possible pointer alignment lint message */
	if ((rf = (struct rifd *) malloc(sizeof(struct rifd))) == NULL)
		return (NULL);
#else
	rf = (struct rifd *)0;
#endif

	/* open and check the mapfile - the long part */
	if ((rf->mfd = open(path[0], flags, mode)) > -1) {

		r = read(rf->mfd, (char *) &rf->sblk, RI_SSIZ);

		/* if read nothing, must be a new guy, right ? */
		if (r == 0) {
			rf->sblk.magic = RI_MAGIC;
			if(reclen == 0)
				rf->sblk.reclen = BUFSIZ - sizeof(struct rimap);
			else
				rf->sblk.reclen = reclen;
			rf->sblk.free = 0L;

			/* this keeps page 0 as a comment page */
			rf->sblk.last = 1L;

			if (wsuper(rf) == 0)
				r = RI_SSIZ;
		}
#ifdef	BYTEORDER
		else {
			/* read something, decode the numbers */
			rf->sblk.magic = ntohl(rf->sblk.magic);
			rf->sblk.reclen = ntohl(rf->sblk.reclen);
			rf->sblk.free = ntohl(rf->sblk.free);
			rf->sblk.last = ntohl(rf->sblk.last);
		}
#endif


		/* cleverly check ret value from either read or write */
		if (r != RI_SSIZ) {
			(void) close(rf->mfd);
			(void) free((char *) rf);
			return (NULL);
		}

		/* check that ole magic number */
		if (rf->sblk.magic != RI_MAGIC) {
			(void) close(rf->mfd);
			(void) free((char *) rf);
			return (NULL);
		}
	} else {
		/* couldnt even open the bloody file */
		(void) free((char *) rf);
		return (NULL);
	}

	/* allocate buffer memory */
	if((rf->dat = malloc((unsigned)rf->sblk.reclen)) == NULL) {
		(void) close(rf->mfd);
		(void) free((char *) rf);
		return (NULL);
	}

	/* now open the text file */
	if ((rf->fd = open(path[1], flags, mode)) < 0) {
		(void) close(rf->mfd);
		(void) free((char *) rf->dat);
		(void) free((char *) rf);
		return (NULL);
	}
	
	rf->pagoff = 0;
	rf->curpag = 0L;

	return (rf);
}



/* close and deallocate the control structure */
riclose(rf)
struct	rifd	*rf;
{
	int	t;

	t = wsuper(rf);
	(void) close(rf->fd);
	(void) close(rf->mfd);
	(void) free((char *) rf->dat);
	(void) free((char *) rf);
	return (t);
}



/* allocate a page block, either by using the free page chain or */
/* by creating a new page at the end of the file */
static	long
pagalloc(rf,rec)
struct	rifd	*rf;
long	rec;
{
	struct	ripag	pag;
	long	nfree;
	extern	long	lseek();


	/* read superblock in case someone else has changed it */
	/* this is not totally bulletproof, but doubtless helps */
	if(rsuper(rf) < 0)
		return(-1);

	/* if there are free blocks, use them, otherwise use the end of file */
	if(rf->sblk.free != 0L) {
		/* allocate the block, and then reset the free pointer */
		if(rpaghed(rf,rf->sblk.free,&pag) < 0)
			return(-1);

		/* should never happen ! this block is marked as in */
		/* use but is on the free list ! */
		/* (the other alternative is to just eat through the */
		/* file, using allocated blocks instead of the free */
		/* list :-)) */
		if(pag.deleted != RI_DELETED) {
			/* AIIIEEEEEE!!!! */
			return(-1);
		}

		/* remember it */
		nfree = rf->sblk.free;

		/* the new free pointer is the free block successor */
		rf->sblk.free = pag.next;
	} else {
		/* use page after current highest page in file */
		/* this is dependent on your OS being UNIX-like */
		/* in that 'holes' in files are filled with 0s */
		/* rather than something else - hence we expect */
		/* that data blocks in a 'hole' will read as all 0 */
		/* this should blow up MS-DOS */
		nfree = rf->sblk.last++;
	}
	
	/* all is OK - rewrite our superblock - new free head */
	if(wsuper(rf) < 0)
		return(-1);
		
	/* we now have removed the free entry from the list */
	/* and mark it as active */
	pag.deleted = RI_ACTIVE;
	pag.next = 0L;
	pag.recno = rec;
	pag.high = 0;
	if(wpaghed(rf,nfree,&pag) < 0)
		return(-1);

	return(nfree);
}



/* write a map block from the given struct */
static	int
wmapblk(rf,rec,blk)
struct	rifd	*rf;
long	rec;
struct	rimap	*blk;
{
	extern	long	lseek();
#ifdef	BYTEORDER
	struct	rimap boge;
#endif


	if(lseek(rf->mfd,(rec * RI_MSIZ) + RI_SSIZ,0) < 0)
		return(-1);

#ifdef	BYTEORDER
	boge.page = htonl(blk->page);
	boge.tail = htonl(blk->tail);

	if (write(rf->mfd, (char *) &boge, RI_MSIZ) != RI_MSIZ)
		return (-1);
#else
	if(write(rf->mfd,(char *)blk, RI_MSIZ) != RI_MSIZ)
		return(-1);
#endif
	return(0);
}



/* read a map block into the given struct */
static	int
rmapblk(rf,rec,blk)
struct	rifd	*rf;
long	rec;
struct	rimap	*blk;
{
	int	ret;
	extern	long	lseek();
#ifdef	BYTEORDER
	struct	rimap	boge;
#endif

	if(lseek(rf->mfd,(rec * RI_MSIZ) + RI_SSIZ,0) <0)
		return(-1);

#ifdef	BYTEORDER
	ret = read(rf->mfd,(char *)&boge, RI_MSIZ);
	blk->page = ntohl(boge.page);
	blk->tail = ntohl(boge.tail);
#else
	ret = read(rf->mfd,(char *)blk, RI_MSIZ);
#endif

	/* if we EOFfed we are still (maybe) OK */
	if(ret == 0) {
		blk->page = 0L;
		blk->tail = 0L;
		ret = RI_MSIZ;	/* kluge */
	}

	if(ret != RI_MSIZ)
		return(-1);

	return(0);
}



/* read a page header into the given struct */
static	int
rpaghed(rf,rec,blk)
struct	rifd	*rf;
long	rec;
struct	ripag	*blk;
{
	int	r;
	extern	long	lseek();
#ifdef	BYTEORDER
	struct	ripag	boge;
#endif

	/* seek the distance, and read a page header */
	if(lseek(rf->fd,(rec * RI_PSIZ(rf)),0) < 0)
		return(-1);

#ifdef	BYTEORDER
	r = read(rf->fd,(char *)&boge, RI_PHSIZ);
	blk->recno = ntohl(boge.recno);
	blk->next = ntohl(boge.next);
	blk->high = ntohl(boge.high);
	blk->deleted = ntohl(boge.deleted);
#else
	/* try to read a page */
	r = read(rf->fd,(char *)blk, RI_PHSIZ);
#endif

	/* if we EOFfed, we are still (maybe) OK */
	if(r == 0) {
		blk->recno = rec;
		blk->next = 0L;
		blk->high = 0;
		blk->deleted = RI_DELETED;
		r = RI_PHSIZ;	/* kluge */
	}

	if(r != RI_PHSIZ)
		return(-1);

	return(0);
}



/* write a page header from the given struct */
static	int
wpaghed(rf,rec,blk)
struct	rifd	*rf;
long	rec;
struct	ripag	*blk;
{
	extern	long	lseek();
#ifdef	BYTEORDER
	struct	ripag	boge;
#endif

	if(lseek(rf->fd,(rec * RI_PSIZ(rf)),0) < 0)
		return(-1);
#ifdef	BYTEORDER
	boge.recno = htonl(blk->recno);
	boge.next = htonl(blk->next);
	boge.high = htonl(blk->high);
	boge.deleted = htonl(blk->deleted);
	if(write(rf->fd,(char *)&boge, RI_PHSIZ) != RI_PHSIZ)
		return(-1);
#else
	if(write(rf->fd,(char *)blk, RI_PHSIZ) != RI_PHSIZ)
		return(-1);
#endif
	return(0);
}



riwrite(rf,rec,buf,num,appen)
struct	rifd	*rf;
long	rec;
char	*buf;
int	num;
int	appen;
{
	long	j;		/* junk */
	int	k;		/* junk */
	int	wrote =0;	/* number of char written */
	long	this =0L;	/* current page */
	struct	rimap	map;	/* buffer for map entries */
	struct	ripag	pag;	/* buffer for page entries */
	extern	long	lseek();

	/* no matter what, we will need our map block */
	if(rmapblk(rf,rec,&map) < 0)
		return(-1);

	/* turn off read continuation for this record */
	rf->curpag = -1L;

	/* if no page at start, write map to disk now - new page */
	if(map.page == 0L) {
		map.page = pagalloc(rf,rec);
		if(map.page == -1L)
			return(-1);
		if(wmapblk(rf,rec,&map) < 0)
			return(-1);
	}


	/* if we are appending, we start at the last page and continue */
	if(appen) {
		if(map.tail != 0)
			this = map.tail;
		else
			this = map.page;
	} else {
		/* start at the first page */
		this = map.page;
	}


	/* main loop, in which we spit the bytes to disk */
	while(num > 0 ) {
		
		/* read our page header */
		if(rpaghed(rf,this,&pag) < 0)
			return(-1);

		/* seek to head of page data segment possibly */
		/* skipping over previously written bytes */
		if(appen)
			j = (this * (long)RI_PSIZ(rf))+RI_PHSIZ+pag.high;
		else
			j = (this * (long)RI_PSIZ(rf))+RI_PHSIZ;

		/* actually do the thing */
		if(lseek(rf->fd,j,0) <0)
			return(-1);

		/* figure how much to write */
		/* is this devo ?? - my head hurtz */
		if(appen) {
			if(num > rf->sblk.reclen - pag.high)
				k = rf->sblk.reclen - pag.high;
			else
				k = num;
		} else {
			if(num > rf->sblk.reclen)
				k = rf->sblk.reclen;
			else
				k = num;
		}

		/* actually do the thing */
		if(write(rf->fd,&buf[wrote],k) != k)
			return(-1);

		/* adjust our notion of where we are and so on */
		wrote += k;
		num -= k;

		if(appen) {
			pag.high += k;
		} else {
			/* this prevents us from accidentally losing the */
			/* rest of the page in overwrites */
			if( k > pag.high)
				pag.high = k;
		}

		/* remember our new last page in chain is this one */
		map.tail = this;

		if( num > 0 ) {
			/* the current block has no associated page */
			if(pag.next == 0L) {
				pag.next = pagalloc(rf,rec);
				if(pag.next == -1L)
					return(-1);
			}
		
			/* write our page header with next pointer */
			if(wpaghed(rf,this,&pag) < 0)
				return(-1);
	
			/* move along to next page */
			this = pag.next;
		}
	}

	/* write our page header */
	if(wpaghed(rf,this,&pag) < 0)
		return(-1);

	/* write our map block */
	if(wmapblk(rf,rec,&map) < 0)
		return(-1);

	return(wrote);
}



/* drop a list of pages, and pop them onto the free list */
riunlink(rf,rec)
struct	rifd	*rf;
long	rec;
{
	long	head =0L;	/* first page - we build a chain */
	long	this =0L;	/* current page */
	struct	rimap	map;	/* buffer for map entries */
	struct	ripag	pag;	/* buffer for page entries */
	extern	long	lseek();

	/* read superblock in case someone else has changed it */
	if(rsuper(rf) < 0)
		return(-1);
	
	/* turn off read continuation if this record */
	if(rec == rf->currec)
		rf->curpag = -1L;

	/* now read the mapblock to be deleted */
	if(rmapblk(rf,rec,&map) < 0)
		return(-1);

	/* the map block has no associated page block - life is easy */
	if(map.page == 0L)
		return(0);

	/* remember our page */
	this = map.page;
	head = map.page;

	map.page = 0L;
	map.tail = 0L;

	/* first off, mark the thing as gone */
	if(wmapblk(rf,rec,&map) < 0)
		return(-1);
	
	while(1) {
		/* read our page header */
		if(rpaghed(rf,this,&pag) < 0)
			return(-1);

		/* if no next page, we are mostly done */
		/* drop to bottom, which links us into the free chain */
		if(pag.next == 0L)
			break;

		/* mark it and go to next */
		pag.deleted = RI_DELETED;
		if(wpaghed(rf,this,&pag) < 0)
			return(-1);

		this = pag.next;
	}

	/* this now points at the end of our list */
	/* head points at the first one. so we: */

	/* make the superblock next free block pointer the next of our */
	/* last node - if we crash here we lose our free list - they just */
	/* sit there */
	pag.next = rf->sblk.free;

	pag.deleted = RI_DELETED;
	if(wpaghed(rf,this,&pag) < 0)
		return(-1);

	/* now the superblock free list points to our list head */
	rf->sblk.free = head;
	if(wsuper(rf) < 0)
		return(-1);

	return(0);
}

riread(rf,rec,buf,num,cont)
struct	rifd	*rf;
long	rec;
char	*buf;
int	num;
int	cont;
{
	long	j;		/* junk */
	int	k;		/* junk */
	long	this;
	int	nread =0;	/* number of char read */
	struct	rimap	map;	/* buffer for map entries */
	struct	ripag	pag;	/* buffer for page entries */
	extern	long	lseek();

	/* these check to make sure our current record and such are */
	/* all still more or less valid - a kludge, but it works... */
	if(rec != rf->currec) {
		cont = 0;
		rf->currec = rec;
	}

	if(cont) {
		if(rf->curpag != -1L)
			this = rf->curpag;
		else
			cont = 0;
	}

	if(!cont) {
		/* we are starting a new record - read the map block */
		if(rmapblk(rf,rec,&map) < 0)
			return(-1);

		this = map.page;
		rf->curpag = 0L;
		rf->pagoff = 0;
	}
	
	while(num > 0 ) {

		/* we have run out of pages to read */
		if(this == 0L)
			break;

		/* read our page header */
		if(rpaghed(rf,this,&pag) < 0)
			return(-1);

		/* seek to head of page data segment */
		if(cont)
			j = (this * (long)RI_PSIZ(rf))+RI_PHSIZ + rf->pagoff;
		else
			j = (this * (long)RI_PSIZ(rf))+RI_PHSIZ;

		if(lseek(rf->fd,j,0) <0)
			return(-1);

		/* read a page worth OR whatever is left in that page */
		if(cont) {
			if(num >= (pag.high - rf->pagoff)) {
				/* read rest of page, go to next */
				k = pag.high - rf->pagoff;
				this = pag.next;
				rf->curpag = this;
			} else {
				k = num;
			}
		} else {
			if(num < pag.high) {
				k = num;
			} else {
				this = pag.next;
				rf->curpag = this;
				k = pag.high;
			}
		}

		if(read(rf->fd,&buf[nread],k) < 0)
			return(-1);		

		/* adjust our notion of where we are */
		nread += k;
		num -= k;
		rf->pagoff += k;
		if(rf->pagoff >= rf->sblk.reclen) {
			rf->pagoff -= rf->sblk.reclen;
		} 
	}

	rf->curpag = this;
	buf[nread] ='\0';

	return(nread);
}

/* set the record file label (page 0) from the contents of buf */
risetlab(rf,buf,num)
struct	rifd	*rf;
char	*buf;
int	num;
{
	extern	long	lseek();

	/* will it fit ? */
	if(num > rf->sblk.reclen)
		return(-1);

	if(lseek(rf->fd,(long)RI_PHSIZ,0) <0)
		return(-1);
	if(write(rf->fd,buf,num) != num)
		return(-1);

	return(0);
}


/* get the record file label (page 0) into buf */
rigetlab(rf,buf,num)
struct	rifd	*rf;
char	*buf;
int	num;
{
	extern	long	lseek();

	if(lseek(rf->fd,(long)RI_PHSIZ,0) <0)
		return(-1);

	if(read(rf->fd,buf,num) < 0)
		return(-1);

	buf[rf->sblk.reclen] = '\0';

	return(0);
}

char	*
rigets(rf,rec,buf)
struct	rifd	*rf;
long	rec;
char	*buf;
{
	char	*bptr = buf;
	static	int	cont;
	static	char	*rptr = NULL;

	/* this is kind of wasteful, but necessary */
	/* we re-check to make sure that the record has not changed */
	/* in riread() - but have to do it here, too, to make sure */
	/* that we can take from our buffer, instead of reading */
	cont = rec == rf->currec;
	
	/* if the record number has changed, or the buffer is empty */
	/* we must needs fill us a buffer */
	if(!cont || rptr == 0 || *rptr == '\0') {
		if(riread(rf,rec,rf->dat,rf->sblk.reclen,1) == 0)
			return(NULL);
		rptr = rf->dat;
	}

	while(1) {
		switch(*rptr) {

		case '\0':
				/* out of stuff, load another buffer */
				if(riread(rf,rec,rf->dat,rf->sblk.reclen,1) == 0) {
					/* record empty, finish buffer */
					*bptr = '\0';
					return(buf);
				}
				rptr = rf->dat;
				*bptr++ = *rptr;
				break;

			case '\n':
				*bptr = '\0';
				rptr++;
				return(buf);
		
			default:
				*bptr++ = *rptr;

		}
		rptr++;
	}
}



riputs(rf,rec,buf)
struct	rifd	*rf;
long	rec;
char	*buf;
{
	char	wbuf[BUFSIZ];
	char	*bptr = wbuf;
	char	*rptr = buf;
	int	count =0;
	
	/* combined strcpy() and strlen() */
	while(rptr && *rptr) {
		*bptr++ = *rptr++;
		count++;
	}
	*bptr++ = '\n';
	count++;

	*bptr = '\0';
	if(riwrite(rf,rec,wbuf,count,1) != count)
		return(EOF);
	
	return(0);
}



rigetcurpag(rf,buf)
struct	rifd	*rf;
char	*buf;
{
	if(rf->curpag <= 0L)
		return(-1);
	if(lseek(rf->fd,(rf->curpag * (long)RI_PSIZ(rf))+RI_PHSIZ,0) < 0)
		return(-1);
	if(read(rf->fd,buf,rf->sblk.reclen) != rf->sblk.reclen)
		return(-1);
	return(0);
}



risetcurpag(rf,buf)
struct	rifd	*rf;
char	*buf;
{
	if(rf->curpag <= 0L)
		return(-1);
	if(lseek(rf->fd,(rf->curpag * (long)RI_PSIZ(rf))+RI_PHSIZ,0) < 0)
		return(-1);
	if(write(rf->fd,buf,rf->sblk.reclen) != rf->sblk.reclen)
		return(-1);
	return(0);
}
