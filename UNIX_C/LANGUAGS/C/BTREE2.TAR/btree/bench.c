/*
 * Copyright (C) 1988, Marcus J. Ranum, William Welch Medical Library
 * $Author: mjr $
 */

#ifndef lint
static char *RCSid="$Header: bench.c,v 1.1 88/06/01 21:34:55 mjr Rel $: bench.c";
#endif

/*
 * $Log:	bench.c,v $
 * Revision 1.1  88/06/01  21:34:55  mjr
 * Initial revision
 * 
 */


/* grosso hack to load a database and perform a bunch of */
/* operations on it - a sort of benchmark, but not in any */
/* real sense of the word */

#ifdef BSD
#include <sys/file.h>
#endif
#ifdef SYSV
#include <sys/fcntl.h>
#endif
#include <stdio.h>
#include "btree.h"

main(ac,av)
int	ac;
char	*av[];
{
	BTREE	*bt;
	BTNODE	cnod;
	int	fo;
	int	xo;
	long	nbr;
	long	time();
	long	random();
	long	start;
	long	end;
	char	buf[120];

	if(ac < 2) {
		(void)fprintf(stderr,"usage: %s <file>\n",av[0]);
		exit(1);
	}

	(void)srandom(getpid());
	if((bt = btopen(av[1],O_CREAT|O_TRUNC,0600)) == NULL) {
		btperror(av[1]);
		exit(1);
	}

	(void)time(&start);

	(void)fprintf(stderr,"insert 5000\n");
	/* insert 5000 random records */
	for(fo = 0; fo < 5000; fo++) {
		for(xo = 0; xo < ((int)random()%15)+1; xo++)
			buf[xo] = (int)((random()%25)+97);
		buf[xo] = '\0';
		if(btinsert(buf, bt->sblk.free, bt)<0) {
			btperror("insert");
			exit(1);
		}
	}

	(void)fprintf(stderr,"find 5000\n");
	/* find 5000 random records */
	for(fo = 0; fo < 5000; fo++) {
		for(xo = 0; xo < ((int)random()%15)+1; xo++)
			buf[xo] = (int)((random()%25)+97);
		buf[xo] = '\0';
		if(btfind(buf, &nbr, &cnod, bt)<0) {
			btperror("find");
			exit(1);
		}
	}

	(void)fprintf(stderr,"delete 500\n");
	for(fo = 0; fo < 500; fo++) {
		for(xo = 0; xo < ((int)random()%15)+1; xo++)
			buf[xo] = (int)(random()%25)+97;
		buf[xo] = '\0';
		if(btfind(buf, &nbr, &cnod, bt)<0) {
			btperror("find");
			exit(1);
		}
		if(nbr != 0L && btdelete(nbr, bt)<0) {
			btperror("delete");
			(void)fprintf(stderr,"node=%d\n",nbr);
			exit(1);
		}
	}

	(void)btclose(bt);
	(void)time(&end);
	(void)fprintf(stderr,"total secs:%ld\n",end-start);
	exit(0);
}
