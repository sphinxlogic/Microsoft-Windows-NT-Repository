/*
 * Copyright (C) 1988, Marcus J. Ranum, William Welch Medical Library
 * $Author: mjr $
 */

#ifndef lint
static char *RCSid="$Header: sizes.c,v 1.1 88/06/01 21:35:34 mjr Rel $: sizes.c";
#endif

/*
 * $Log:	sizes.c,v $
 * Revision 1.1  88/06/01  21:35:34  mjr
 * Initial revision
 * 
 */


/* provides some minimally useful info about how big your */
/* data structures are */

#include "btree.h"

main()
{
	(void)printf("a btree control structure is %d bytes",sizeof(BTREE));
	(void)printf(" (cache of %d nodes)\n",BT_CSIZ);
	(void)printf("a btree node is %d bytes\n",sizeof(BTNODE));
}
