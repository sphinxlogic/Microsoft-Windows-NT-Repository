/*
 * $Header: cproto1.c,v 1.1 89/03/14 20:59:21 cthuang Exp $
 *
 * C prototype generator
 * This filter reads C source code and outputs ANSI C function prototypes.
 */
#ifndef lint
static char *rcsid = "$Header: cproto1.c,v 1.1 89/03/14 20:59:21 cthuang Exp $";
#endif
#include <stdio.h>
#include "cproto.h"

/* getopt declarations */
extern int getopt();
extern char *optarg;
extern int optind;

/* Name of the program */
static char *progname = "cproto";

/* Program options */

/* TRUE when "extern" should appear to external declarations. */
boolean extern_out = FALSE;

/* TRUE when only external declarations will be generated. */
boolean globals_only = FALSE;

/* This variable controls the style of function prototype. */
int proto_style = 2;

/* TRUE when variable declarations are printed also. */
boolean variables_out = FALSE;

/* Output an error message along with the line number where it was found.
 */
void
print_error (msg)
char *msg;
{
    fprintf(stderr, "%s: line %d: %s\n", progname, line_num, msg);
}

main (argc, argv)
int argc;
char **argv;
{
    int		c;
    boolean	error_flag;

    error_flag = FALSE;
    while ((c = getopt(argc, argv, "egp:v")) != EOF) {
	switch (c) {
	case 'e':
	    extern_out = TRUE;
	    break;
	case 'g':
	    globals_only = TRUE;
	    break;
	case 'p':
	    proto_style = atoi(optarg);
	    break;
	case 'v':
	    variables_out = TRUE;
	    break;
	case '?':
	default:
	    error_flag = TRUE;
	}
    }

    if (optind == argc-1) {
	if (freopen(argv[optind], "r", stdin) == NULL) {
	    fprintf(stderr, "%s: cannot open file %s\n", progname,
	    	    argv[optind]);
	    exit(1);
	}
    } else {
	error_flag = (boolean)(optind < argc-1);
    }

    if (error_flag) {
	fprintf(stderr, "usage: %s [ -egv ] [ -p n ] [ file ]\n", progname);
	exit(1);
    }

    parse_file();
}
