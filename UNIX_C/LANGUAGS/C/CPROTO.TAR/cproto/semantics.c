/*
 * $Header: semantics.c,v 1.1 89/03/14 20:59:22 cthuang Exp $
 *
 * C prototype generator
 * These routines implement the semantic actions executed by the yacc parser.
 * 
 */
#include <stdio.h>
#include <strings.h>
#include "cproto.h"
#include "semantics.h"

/* Create a new string by joining two strings with a space between them.
 * Return a pointer to the resultant string or NULL if an error occurred.
 */
static char *
concat_string (a, b)
char	*a, *b;
{
    char	*result;

    if ((result = malloc((unsigned)(strlen(a) + strlen(b) + 2))) != NULL) {
	strcpy(result, a);
	strcat(result, " ");
	strcat(result, b);
    }
    return result;
}

/* Delete the first occurence of a substring from a string.
 * Return a pointer to a static buffer containing the result.
 * If the substring is not found, then return the entire string.
 */
static char *
delete_string (src, key)
char	*src, *key;
{
    static char buf[MAX_TEXT_LENGTH];
    char	*s;
    int		n;

    if ((s = strstr(src, key)) == NULL) {
	strcpy(buf, src);
    } else {
	strcpy(buf, "");
	n = s - src;
	if (n > 0) strncat(buf, src, n);
	n = strlen(src) - n - strlen(key);
	if (n > 0) strncat(buf, s+strlen(key), n);
    }
    return buf;
}

/* Check if the given identifier is really a typedef name by searching the
 * symbol table.
 * Return TRUE if it is a typedef name.
 */
boolean
is_typedef_name (name)
char *name;
{
    return (boolean)(find_symbol(typedef_names, name) != NULL);
}

/* Initialize a new declaration specifier part.
 */
void
new_decl_spec (decl_spec, text, flags)
DeclSpec	*decl_spec;
char		*text;
unsigned short	flags;
{
    decl_spec->text = strdup(text);
    decl_spec->flags = flags;
}

/* Append two declaration specifier parts together.
 */
void
join_decl_specs (result, a, b)
DeclSpec	*result, *a, *b;
{
    result->text = concat_string(a->text, b->text);
    result->flags = a->flags | b->flags;
    free(a->text);
    free(b->text);
}

/* Free storage used by a declaration specifier part.
 */
void
free_decl_spec (decl_spec)
DeclSpec	*decl_spec;
{
    if (decl_spec->text != NULL)
	free(decl_spec->text);
}

/* Initialize the parameter structure.
 */
void
new_parameter (param, decl_spec, declarator, name)
Parameter	*param;
char		*decl_spec, *declarator, *name;
{
    param->decl_spec = strdup(decl_spec);
    param->declarator = strdup(delete_string(declarator, "%s"));
    param->name = strdup(name);
}

/* Free the storage used by the parameter.
 */
void
free_parameter (param)
Parameter	*param;
{
    if (param->decl_spec != NULL)
	free(param->decl_spec);
    if (param->declarator != NULL)
	free(param->declarator);
    free(param->name);
}

/* Initialize an empty list of function parameters.
 */
void
new_param_list (param_list, param)
ParameterList	*param_list;
Parameter	*param;
{
    Parameter	*p;

    p = (Parameter *)malloc(sizeof(Parameter));
    *p = *param;
    
    param_list->first = param_list->last = p;
    p->next = NULL;
}

/* Add the function parameter declaration to the list.
 */
void
add_param_list (to, from, param)
ParameterList	*to, *from;
Parameter	*param;
{
    Parameter	*p;

    p = (Parameter *)malloc(sizeof(Parameter));
    *p = *param;

    to->first = from->first;
    from->last->next = p;
    to->last = p;
    p->next = NULL;
}

/* Free storage used by the elements in the function parameter list.
 */
void
free_param_list (param_list)
ParameterList	*param_list;
{
    Parameter	*p, *next;

    p = param_list->first;
    while (p != NULL) {
	next = p->next;
	free_parameter(p);
	free((char *)p);
	p = next;
    }
}

/* Initialize an empty list of function parameter names.
 * This is just a list of function parameter declarations with
 * only the name field set.
 */
void
new_ident_list (param_list)
ParameterList	*param_list;
{
    param_list->first = param_list->last = NULL;
}

/* Add an item to the list of function parameter declarations but set only
 * the parameter name field.
 */
void
add_ident_list (to, from, name)
ParameterList	*to, *from;
char		*name;
{
    Parameter	*p;

    p = (Parameter *)malloc(sizeof(Parameter));
    p->decl_spec = NULL;
    p->declarator = NULL;
    p->name = strdup(name);

    to->first = from->first;
    if (to->first == NULL) {
	to->first = p;
    } else {
	from->last->next = p;
    }
    to->last = p;
    p->next = NULL;
}

/* Initialize a declarator.
 */
void
new_declarator (d, name, text)
Declarator	*d;
char		*name, *text;
{
    d->name = strdup(name);
    d->text = strdup(text);
    d->func_def = FUNC_DEF_NONE;
    d->params.first = d->params.last = NULL;
}

/* Free storage used by a declarator.
 */
void
free_declarator (d)
Declarator	*d;
{
    if (d->name != NULL)
	free(d->name);
    if (d->text != NULL)
	free(d->text);
    free_param_list(&(d->params));
}

/* Initialize a declarator list and add the given declarator to it.
 */
void
new_decl_list (decl_list, declarator)
DeclaratorList	*decl_list;
Declarator	*declarator;
{
    Declarator	*d;

    d = (Declarator *)malloc(sizeof(Declarator));
    *d = *declarator;

    decl_list->first = decl_list->last = d;
    d->next = NULL;
}

/* Add the declarator to the declarator list.
 */
void
add_decl_list (to, from, declarator)
DeclaratorList	*to, *from;
Declarator	*declarator;
{
    Declarator	*d;

    d = (Declarator *)malloc(sizeof(Declarator));
    *d = *declarator;

    to->first = from->first;
    from->last->next = d;
    to->last = d;
    to->last->next = NULL;
}

/* Free storage used by the declarators in the declarator list.
 */
void
free_decl_list (decl_list)
DeclaratorList	*decl_list;
{
    Declarator	*d, *next;

    d = decl_list->first;
    while (d != NULL) {
	next = d->next;
	free_declarator(d);
	free((char *)d);
	d = next;
    }
}

/* Search the list of parameters for a matching parameter name.
 * Return a pointer to the matching parameter or NULL if not found.
 */
static Parameter *
search_parameter_list (params, name)
ParameterList	*params;
char		*name;
{
    Parameter	*p;

    for (p = params->first; p != NULL; p = p->next) {
	if (strcmp(p->name, name) == 0)
	    return p;
    }
    return (Parameter *)NULL;
}

/* For each declared variable name in the declarator list,
 * set the declaration specifier and declarator for the parameter
 * with the same name.
 */
void
set_param_types (params, decl_spec, declarators)
ParameterList	*params;
DeclSpec	*decl_spec;
DeclaratorList	*declarators;
{
    Declarator	*d;
    Parameter	*p;
    char	buf[MAX_TEXT_LENGTH];

    for (d = declarators->first; d != NULL; d = d->next) {
	/* Search the parameter list for a matching name. */
	p = search_parameter_list(params, d->name);
	if (p == NULL) {
	    sprintf(buf, "declared argument \"%s\" is missing", d->name);
	    print_error(buf);
	} else {
	    p->decl_spec = strdup(decl_spec->text);
	    p->declarator = strdup(delete_string(d->text, "%s"));
	}
    }
}

/* Output a declaration specifier for an external declaration.
 */
static void
output_decl_spec (decl_spec)
DeclSpec	*decl_spec;
{
    if (extern_out && (decl_spec->flags & DE_STATIC) == 0) {
	if (strstr(decl_spec->text, "extern") == NULL) {
	    printf("extern ");
	}
    }
    printf("%s ", decl_spec->text);
}

/* Output a function parameter type and variable declaration.
 */
static void
output_parameter (p)
Parameter	*p;
{
    char	*s;

    if (proto_style == 1) {
	s = strstr(p->declarator, p->name);
	*s = '\0';
	printf("%s %s/*%s*/%s", p->decl_spec, p->declarator, p->name,
	       s+strlen(p->name));
	*s = *(p->name);
    } else {
	printf("%s %s", p->decl_spec, p->declarator);
    }
}

/* Output the list of function parameters.
 */
static void
output_parameters (params)
ParameterList	*params;
{
    Parameter	*p;

    if (proto_style == 0)
	printf("/*");

    p = params->first;
    if (p == NULL) {
	printf("void");
    } else {
	output_parameter(p);
	p = p->next;
	while (p != NULL) {
	    printf(", ");
	    output_parameter(p);
	    p = p->next;
	}
    }

    if (proto_style == 0)
	printf("*/");
}

/* Output a declarator.
 */
static void
output_declarator (d)
Declarator	*d;
{
    char	*s;

    if (d->func_def == FUNC_DEF_NONE) {
	printf("%s", d->text);
    } else {
	if ((s = strstr(d->text, "%s")) != NULL) {
	    *s = '\0';
	    printf("%s", d->text);
	    output_parameters(&(d->params));
	    printf("%s", s+2);
	    *s = '%';
	}
    }
}

/* Output variable declarations.
 */
void
output_declarations (decl_spec, decl_list)
DeclSpec	*decl_spec;	/* declaration specifier */
DeclaratorList	*decl_list;	/* list of declared variables */
{
    Declarator	*d;

    if (variables_out == FALSE)
	return;
    if (globals_only && (decl_spec->flags & DE_STATIC))
	return;

    for (d = decl_list->first; d != NULL; d = d->next) {
	if (d->func_def == FUNC_DEF_NONE) {
	    if (strstr(decl_spec->text, "extern") == NULL) {
		output_decl_spec(decl_spec);
		output_declarator(d);
		printf(";\n");
	    }
	}
    }
}

/* Output the prototype for the function definition.
 */
void
output_prototype (decl_spec, declarator)
DeclSpec	*decl_spec;
Declarator	*declarator;
{
    Parameter	*p;

    if (globals_only && (decl_spec->flags & DE_STATIC))
	return;

    /* Check for function parameters for which no type has been specified.
     * This happens when a parameter name appears in the function
     * declaration but does not appear in the parameter declaration part.
     * The default type in this cause is "int".
     */
    for (p = declarator->params.first; p != NULL; p = p->next) {
	if (p->decl_spec == NULL) {
	    p->decl_spec = strdup("int");
	    p->declarator = strdup(p->name);
	}
    }

    output_decl_spec(decl_spec);
    output_declarator(declarator);
    printf(";\n");
}
