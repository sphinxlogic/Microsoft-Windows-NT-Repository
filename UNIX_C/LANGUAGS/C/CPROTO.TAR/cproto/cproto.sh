#!/bin/sh
# $Header$
#
cpp_opt="-I."
cproto_opt=""
source=""
for opt do
    case $opt in
    -D*|-U*|-I*)
	cpp_opt="$cpp_opt $opt"
	;;
    -*)
	cproto_opt="$cproto_opt $opt"
	;;
    *)
	source=$opt
	;;
    esac
done
/lib/cpp $cpp_opt $source | cproto1 $cproto_opt
