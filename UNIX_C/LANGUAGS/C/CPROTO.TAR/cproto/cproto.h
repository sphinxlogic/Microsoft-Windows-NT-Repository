/*
 * $Header: cproto.h,v 1.1 89/03/14 20:59:12 cthuang Exp $
 *
 * Definitions for C language prototype generator
 */
#include "symbol.h"

/* Boolean type */
typedef char boolean;
#define FALSE	0
#define TRUE	1

/* maximum number of characters in a text buffer */
#define MAX_TEXT_LENGTH	512

/* Declaration specifier flags */
#define DE_EXTERN	0	/* default: declaration has global scope */
#define DE_STATIC	1	/* visible only in current file */
#define DE_JUNK		2	/* we're not interested in this declaration */

/* This structure stores information about a declaration specifier. */
typedef struct _decl_spec {
    unsigned short	flags;	/* flags defined above */
    char		*text;	/* source text */
} DeclSpec;

/* Types of function definitions
 *
 * FUNC_DEF_OLD		traditional style function definition
 * FUNC_DEF_NEW		ANSI style
 */
typedef enum { FUNC_DEF_NONE, FUNC_DEF_OLD, FUNC_DEF_NEW } FuncDefType;

/* This structure stores information about a function parameter. */
typedef struct _parameter {
    char		*decl_spec;	/* declaration specifier text */
    char		*declarator;	/* declarator text */
    char		*name;		/* parameter name */
    struct _parameter	*next;		/* next parameter in list */
} Parameter;

/* This is a list of function parameters. */
typedef struct _parameter_list {
    Parameter		*first;	/* pointer to first parameter in list */
    Parameter		*last;  /* pointer to last parameter in list */  
} ParameterList;

/* This structure stores information about a declarator. */
typedef struct _declarator {
    char		*name;	/* name of declared variable or function */
    char		*text;	/* source text */
    FuncDefType		func_def;	/* style of function definition */
    ParameterList	params;	/* list of parameters if this is a function */
    struct _declarator	*next;	/* next declarator in list */
} Declarator;

/* This is a list of declarators. */
typedef struct _declarator_list {
    Declarator		*first;	/* pointer to first declarator in list */
    Declarator		*last;  /* pointer to last declarator in list */  
} DeclaratorList;

/* parser stack entry type */
typedef union {
    char		text[MAX_TEXT_LENGTH];
    DeclSpec		decl_spec;
    Parameter		parameter;
    ParameterList	param_list;
    Declarator		declarator;
    DeclaratorList	decl_list;
} YYSTYPE;

/* Program options */
extern boolean extern_out;
extern boolean globals_only;
extern int proto_style;
extern boolean variables_out;

/* Global declarations */
extern int line_num;
extern SymbolTable *typedef_names;
extern void print_error();
extern void parse_file();

extern char *strdup(), *strstr();
extern char *malloc();
