/*
 * $Header: symbol.h,v 1.1 89/03/14 20:59:18 cthuang Exp $
 *
 * Definitions for a symbol table
 */
#ifndef _SYMBOL_H
#define _SYMBOL_H

/* maximum length of symbols */
#define SYM_MAX_LENGTH 64

typedef struct _symbol {
	struct _symbol	*next;			/* next symbol in list */
	char		name[SYM_MAX_LENGTH];	/* name of symbol */
} Symbol;

/* hash table length */
#define SYM_MAX_HASH 256

typedef struct _symbol_table {
	Symbol		*bucket[SYM_MAX_HASH];	/* hash buckets */
} SymbolTable;

extern SymbolTable	*create_symbol_table();	/* Create symbol table */
extern Symbol		*find_symbol();		/* Lookup symbol name */
extern Symbol		*new_symbol();		/* Define new symbol */

#endif
