/*
 * $Header: string.c,v 1.1 89/03/14 20:59:24 cthuang Exp $
 *
 * Some are string handling routines
 */
#include <stdio.h>
#include <strings.h>

extern char	*malloc();

/* Copy the string into an allocated memory block.
 * Return a pointer to the copy.
 */
char *
strdup (s)
char	*s;
{
    char	*dest;

    if ((dest = malloc((unsigned)(strlen(s)+1))) != NULL)
	strcpy(dest, s);
    return dest;
}

/* Return a pointer to the first occurence of the substring 
 * within the string, or NULL if not found.
 */
char *
strstr (src, key)
char	*src, *key;
{
    char	*s;
    int		keylen;

    keylen = strlen(key);
    s = index(src, *key);
    while (s != NULL) {
	if (strncmp(s, key, keylen) == 0)
	    return s;
	s = index(s+1, *key);
    }
    return NULL;
}
