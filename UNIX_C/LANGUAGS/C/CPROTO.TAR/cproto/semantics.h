/*
 * $Header: semantics.h,v 1.1 89/03/14 20:59:16 cthuang Exp $
 *
 * Declarations for semantics action routines
 */

extern boolean	is_typedef_name();

extern void	new_decl_spec();
extern void	join_decl_specs();
extern void	free_decl_spec();

extern void	new_parameter();
extern void	free_parameter();

extern void	new_param_list();
extern void	add_param_list();
extern void	free_param_list();

extern void	new_ident_list();
extern void	add_ident_list();

extern void	new_declarator();
extern void	free_declarator();

extern void	new_decl_list();
extern void	add_decl_list();
extern void	free_decl_list();

extern void	set_param_types();
extern void	output_declarations();
extern void	output_prototype();
