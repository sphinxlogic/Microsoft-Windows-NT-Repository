/* totri - convert all "funny" characters to ANSI C trigraph sequences.
 *         currently implemented as a filter, but a rewritten main
 *         could allow a more sophisticated interface.
 *
 *  This source donated to the public domain by John P. Nelson 1988
 */

#include <stdio.h>
#include <strings.h>

char *trichar = "=(/)'<!>-";
char *translate = "#[\\]^{|}~";
main()
    {
    process(stdin, stdout);
    }

process(in, out)
FILE *in, *out;
    {
    int c;
    char *ptr;

    while ((c = getchar(in)) != EOF)
	{
	if (ptr = strchr(translate, c))
	    {
	    putc('?', out);
	    putc('?', out);
	    putc(trichar[ptr - translate], out);
	    }
	else
	    putc(c, out);
	}
    }
