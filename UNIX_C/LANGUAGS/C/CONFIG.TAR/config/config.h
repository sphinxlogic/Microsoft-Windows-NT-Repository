/*==================================================================*/
/*	CONFIG Version 1.0  <August 21, 1988>			    */
/*								    */
/*	Written by Conrad Kwok, Division of Computer Science, UCD   */
/*								    */
/*	Permission is granted for freely distribution of this file  */
/*		provided that this message is included.		    */
/*==================================================================*/

#define cfgDefault (-1)
#define FALSE 0
#define TRUE 1
#define cfgPreset 2

#define V_byte  1
#define V_ubyte 2
#define V_short 3
#define V_ushort 4
#define V_int   5
#define V_uint  6
#define V_long  7
#define V_ulong 8
#define V_float 9
#define V_double 10
#define V_string 11
#define V_charptr 12
#define V_char 13
#define V_intkw 14
#define V_usertype0 20
#define V_usertype1 21

#ifdef OldFashion
#define void char
#endif

struct kr_struct {
    char *keystr;
    void *addr;
    int vtype;
    int val_set;
    int arraysize;
    double lower, upper;
    int userflag;
    void *userdata;
    int (*hook)();
};

typedef struct kr_struct KeyRec;

extern int (*UTypeHook[])();
extern int (*UserDefHook)();
extern int cfgVerbose;
extern int KeyCaseSensitive;
extern int cfgScan;

extern KeyRec KeyTable[];
