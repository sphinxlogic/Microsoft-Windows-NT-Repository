/*
 * sortgrp(str) - returns the appropriate gid for group name str
 */

#include <stdio.h>
#include <grp.h>

struct group	*gr;

sortgrp(str)
char	str[20];
{
	lockgrfile();
	setgrent();
	
	while ((gr = getgrent()) != NULL) {
		if (strcmp(gr->gr_name, str) == 0) { /* Compare gname */
			endgrent();
			unlockgrfile();
			return(gr->gr_gid);	/* return gid */
		}
	}
	unlockgrfile();
	endgrent();
	return(-1);
}
