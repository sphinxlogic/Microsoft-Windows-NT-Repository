/*
 * unlockgrfile - unlink GTMP to free up group file
 */

#include "defs.h"

unlockgrfile()
{
	unlink(GTMP);
}
