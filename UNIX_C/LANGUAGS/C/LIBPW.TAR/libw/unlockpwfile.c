/*
 * unlockpwfile - unlink the lockfile for passwd
 */

#include "defs.h"

unlockpwfile()
{
	unlink(PTMP);
}
