/*
 * sortuser(uname) - look for uname in /etc/passwd.  TRUE=1, FALSE=0
 */

#include <stdio.h>
#include <pwd.h>

struct passwd *tmp;

sortuser(uname)
char	uname[10];
{
	lockpwfile();
	setpwent();

	while ((tmp = getpwent()) != NULL) {
		if (strcmp(tmp->pw_name, uname) == 0) {
			endpwent();
			unlockpwfile();
			return(1);
		}
	}
	unlockpwfile();
	endpwent();
	return(0);
}
