/*
 * lockgrfile - check for GTMP, create it when available to
 */

#include <stdio.h>
#include "defs.h"

lockgrfile()
{
	FILE	*grp;

	while ((grp = fopen(GTMP, "r")) != NULL) {
		fclose(grp);
/*		printf("Group file is locked.  Please wait...\n"); */
		sleep(5);
	}

	creat(GTMP, 022);
}
