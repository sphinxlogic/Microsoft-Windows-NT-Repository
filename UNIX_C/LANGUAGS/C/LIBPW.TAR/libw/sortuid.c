/*
 * sortuid(d) - check for next available uid after d
 */

#include <stdio.h>
#include <pwd.h>

struct passwd	*tmp;

int sortuid(d)
int	d;
{
	int	i = d-1;

	lockpwfile();
	setpwent();

	for (;;) {
		if ((tmp = getpwent()) == NULL) {
			unlockpwfile();
			endpwent();
			return 65534;
		}
		if (tmp->pw_uid < d)
			continue;
		if (tmp->pw_uid == i+1) {
			i++;
			continue;
		} else {
			unlockpwfile();
			endpwent();
			return(++i);
		}
	}
}
