/*
 * isuidused(x) - if uid x is used, return 1 else 0
 */

#include <stdio.h>
#include <pwd.h>

struct passwd	*tmp;

isuidused(x)
int	x;
{
	lockpwfile();
	setpwent();

	while ((tmp = getpwent()) != NULL) {
		if (tmp->pw_uid == x) {
			unlockpwfile();
			endpwent();
			return(1);
		}
	}
	unlockpwfile();
	endpwent();
	return(0);
}
