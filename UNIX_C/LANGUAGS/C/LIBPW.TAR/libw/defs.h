/*
 * defs - lockfile defines
 */

#define GTMP	"/etc/gtmp"
#define PTMP	"/etc/ptmp"

