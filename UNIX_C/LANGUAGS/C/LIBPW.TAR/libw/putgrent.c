/*
 * putgrent(fp, ent) - since there is no putgrent I'm making one.
 */

#include <stdio.h>
#include <grp.h>

putgrent(fp, grp)
FILE	*fp;
struct group	*grp;
{
	int	i;

	fprintf(fp, "%s:*:%d:%s", grp->gr_name, grp->gr_gid, grp->gr_mem[0]);
	for (i = 1; grp->gr_mem[i][0] != NULL; i++)
		fprintf(fp, ",%s", grp->gr_mem[i]);
	fprintf(fp, "\n");
	fflush(fp);
}
