/*
 * lockpwfile - check for lockfile PTMP, when free, create it.
 */

#include <stdio.h>
#include "defs.h"

lockpwfile()
{
	FILE	*pwd;

	while ((pwd = fopen(PTMP, "r")) != NULL) {
		fclose(pwd);
/*		printf("Password file locked.  Please wait...\n"); */
		sleep(5);
	}

	creat(PTMP, 022);
}
