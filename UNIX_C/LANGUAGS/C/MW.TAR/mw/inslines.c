#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Insert n lines above cursor in window w */
Winslines (w, n)
register Win *w;
int n;
{
	register Buf *b;
	register Ch *cp, *ct;
	register j;
	int i, blank, ndown;

	if (n < 0)
		return -1;
	if (n == 0)
		return 0;
	blank = ' ' | (w -> w_mode << NBPB);
	b = w -> w_textbuf;
	if (n + w -> w_cursor.row > w -> IYE)
		n = w -> IYE - w -> w_cursor.row;
	ndown = w -> IYE - n - w -> w_cursor.row;

	/* First, w -> w_winbuf */
	ct = w -> w_winbuf +
		(w -> IYO + w -> IYE - 1) * w -> OXE + w -> IXO;
	cp = ct - n * w -> OXE;
	for (i = 0; i < ndown; i++) {
		for (j = 0; j < w -> IXE; j++) {
			ct -> Char = cp -> Char;
			ct -> Mode &= WINVIS;
			ct++ -> Mode |= cp++ -> Mode & ~WINVIS;
		}
		ct -= w -> OXE + j;
		cp -= w -> OXE + j;
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < w -> IXE; j++) {
			ct -> Char = ' ';
			ct -> Mode &= WINVIS;
			ct++ -> Mode |= WBUF;
		}
		ct -= w -> OXE + j;
	}

	/* Now, w -> w_textbuf */
	ct = b -> b_contents +
		(w -> IYO + w -> IYE + w -> w_bstart.row - 1) * b -> b_ncols +
		w -> IXO + w -> w_bstart.col;
	cp = ct - n * b -> b_ncols;
	for (i = 0; i < ndown; i++) {
		for (j = 0; j < w -> IXE; j++)
			ct++ -> ch_all = cp++ -> ch_all;
		ct -= b -> b_ncols + j;
		cp -= b -> b_ncols + j;
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < w -> IXE; j++)
			ct++ -> ch_all = blank;
		ct -= b -> b_ncols + j;
	}
	w -> w_status |= WDUMP;
	b -> b_nmodw = -1;
	MajorUpdate = 1;
	return 0;
}
