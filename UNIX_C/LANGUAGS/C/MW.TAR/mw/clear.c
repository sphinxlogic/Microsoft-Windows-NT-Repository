#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Clear inside of window w, and corresponding portion of text buffer */
Wclear (w, howto)
register Win *w;
int howto;
{
	register Ch *cp, *bp;
	register Buf *b = w -> w_textbuf;
	register i, j;
	int i2;

	switch (howto) {
	case 0:			/* Clear from cursor to end */
	default:
		Wclearline (w, 0);/* Clr ln from cursor */
		cp = w -> w_winbuf +
			(w -> w_cursor.row + 1 + w -> IYO) * w -> OXE +
			w -> IXO;
		bp = b -> b_contents +
			(w->w_cursor.row+1+w->IYO+w->w_bstart.row)*b->b_ncols +
			w -> w_bstart.col + w -> IXO;
		i2 = w -> IYE - w -> w_cursor.row - 1;
		break;
	case 1:			/* Clear from beginning to cursor */
		Wclearline (w, 1);/* Clr ln to cursor */
		cp = w -> w_winbuf + w -> IYO * w -> OXE + w -> IXO;
		bp = b -> b_contents +
			(w -> w_bstart.row + w -> IYO) * b -> b_ncols +
			w -> w_bstart.col + w -> IXO;
		i2 = w -> w_cursor.row;
		break;
	case 2:			/* Clear all of window */
		cp = w -> w_winbuf + w -> IYO * w -> OXE + w -> IXO;
		bp = b -> b_contents +
			(w -> w_bstart.row + w -> IYO) * b -> b_ncols +
			(w -> w_bstart.col + w -> IXO);
		i2 = w -> IYE;
		break;
	}
	for (i = 0; i < i2; i++) {
		for (j = 0; j < w -> IXE; j++) {
			cp -> Mode &= ~MODEMASK;
			cp -> Mode |= WBUF;
			cp++ -> Char = ' ';
			bp++ -> ch_all = ' ' | (w -> w_mode << NBPB);
		}
		cp += w -> OXE - j;
		bp += b -> b_ncols - j;
	}
	w -> w_status |= WDUMP;
	b -> b_nmodw = -1;
}
