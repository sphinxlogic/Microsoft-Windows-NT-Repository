#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Find the first which window the box is "in" (on) and make it the current
   one [note: box considered to be a point at its origin] */
Win *
Wboxfind ()
{
	register Win *w;

	for (w = WinList; w; w = w -> w_next) {
		if (w -> w_status & WHIDDEN) continue;
		if (w -> OXO <= WBox.xorigin &&
			w -> OYO <= WBox.yorigin &&
			w -> OXO + w -> OXE > WBox.xorigin &&
			w -> OYO + w -> OYE > WBox.yorigin)
				return CurWin = w;
	}
	return 0;
}
