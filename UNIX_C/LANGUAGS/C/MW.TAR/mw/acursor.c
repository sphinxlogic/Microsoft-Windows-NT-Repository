#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Position the window cursor, absolute (buffer) */
WAcursor (w, row, col)
register Win *w;
register row, col;
{
	register Buf *b = w -> w_textbuf;

	if (row < 0)
		row = 0;
	else if (row >= b -> b_nrows - (w -> OYE - w -> IYE))
		row = b -> b_nrows - (w -> OYE - w -> IYE) - 1;
	if (col < 0)
		col = 0;
	else if (col >= b -> b_ncols - (w -> OXE - w -> IXE))
		col = b -> b_ncols - (w -> OXE - w -> IXE) - 1;
	row -= w -> w_bstart.row;
	col -= w -> w_bstart.col;
	if (row < 0) {
		w -> w_bstart.row += row;
		w -> w_cursor.row = 0;
		MajorUpdate = 1;
	}
	else if (row < w -> IYE)
		w -> w_cursor.row = row;
	else {
		w -> w_bstart.row += row - w -> IYE + 1;
		w -> w_cursor.row = w -> IYE - 1;
		MajorUpdate = 1;
	}
	if (col < 0) {
		w -> w_bstart.col += col;
		w -> w_cursor.col = 0;
		MajorUpdate = 1;
	}
	else if (col < w -> IXE)
		w -> w_cursor.col = col;
	else {
		w -> w_bstart.col += col - w -> IXE + 1;
		w -> w_cursor.col = w -> IXE - 1;
		MajorUpdate = 1;
	}
	WFixCursor (w);
	if ((w -> w_status & WCURSOR) == 0)
		w -> w_status |= WDUMP;
	return 0;
}
