#include "win.h"
#include "display.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Make a "link" to another window (i.e. both have same buffer) */
Win *
Wlink (ew, id, xorg, yorg, xext, yext, bcols, brows)
register Win *ew;
int id, xorg, yorg, xext, yext, bcols, brows;
{
	register Win *w;
	register Buf *b;
	register Ch *c;

	if (xorg < 0 || xext < 1 || xorg+xext > ScreenWidth)
		return 0;
	if (yorg < 0 || yext < 1 || yorg+yext > ScreenLength)
		return 0;
	if (brows < 0 || bcols < 0)
		return 0;
	if (brows < yext) brows = yext;
	if (bcols < xext) bcols = xext;
	w = (Win *) malloc (sizeof (Win));
	if (w == 0)
		return 0;
	w -> w_winbuf = (Ch *) malloc (sizeof (Ch) * xext * yext);
	if (w -> w_winbuf == 0) {
		free (w);
		return 0;
	}
	b = ew -> w_textbuf;
	if (b -> b_nrows < brows || b -> b_ncols < bcols)
		if (Wsetbuf (ew, bcols, brows)) {
			free (w -> w_winbuf);
			free (w);
			return 0;
		}
	b -> b_nwins++;
/*	if (b -> b_nmodw && b -> b_nmodw != -1)
		b -> b_nmodw++;	/* Not needed: w -> w_status = WDUMP */
	w -> w_next = WinList;
	w -> w_id = id;
	w -> w_outside.xorigin = xorg;
	w -> w_outside.xextent = xext;
	w -> w_outside.yorigin = yorg;
	w -> w_outside.yextent = yext;
	w -> w_inside.xorigin = 0;
	w -> w_inside.xextent = xext;
	w -> w_inside.yorigin = 0;
	w -> w_inside.yextent = yext;
	w -> w_textbuf = b;
	w -> w_bstart.row = 0;
	w -> w_bstart.col = 0;
	w -> w_cursor.row = 0;
	w -> w_cursor.col = 0;
	w -> w_auxcursor.row = 0;
	w -> w_auxcursor.col = 0;
	w -> w_bcursor = b -> b_contents;
	w -> w_wcursor = w -> w_winbuf;
	w -> w_popup = 1;
	w -> w_mode = 0;
	w -> w_status = WDUMP;
	for (c = w -> w_winbuf + xext * yext; c > w -> w_winbuf;)
		(--c) -> ch_all = ' ' | (WBUF<<NBPB);
	WinList = CurWin = w;
	WComputeCover (w);
	return w;
}
