#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Insert n columns in buffer at cursor */
WBinscols (w, n)
Win *w;
int n;
{
	register Buf *b;
	register Ch *cp, *ct;
	register j;
	int i, blank, nm;

	if (n < 0)
		return -1;
	if (n == 0)
		return 0;
	b = w -> w_textbuf;
	if (n > b -> b_ncols - b -> b_cursor.col)
		n = b -> b_ncols - b -> b_cursor.col;
	nm = b -> b_ncols - b -> b_cursor.col - n;
	blank = ' ' | (w -> w_mode << NBPB);
	ct = b -> b_contents + b -> b_ncols;
	cp = ct - n;
	for (i = 0; i < b -> b_nrows; i++) {
		for (j = 0; j < nm; j++)
			(--ct) -> ch_all = (--cp) -> ch_all;
		cp += b -> b_ncols + j;
		for (j = 0; j < n; j++)
			(--ct) -> ch_all = blank;
		ct += b -> b_ncols + j + nm;
	}
	b -> b_nmodw = -1;
	return 0;
}
