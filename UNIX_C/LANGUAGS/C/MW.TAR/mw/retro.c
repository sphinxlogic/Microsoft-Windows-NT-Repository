#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Retroactively set modes in a window line (just modes!!) */
/* Operates in buffer at buffer cursor unless inwin is nonzero */
Wretroline (w, mode, inwin)
register Win *w;
register mode;
int inwin;
{
	register Ch *cp, *cend;

	if (inwin) {
		cp = w -> w_winbuf +
			(w -> w_cursor.row + w -> IYO) * w -> OXE + w -> IXO;
		cend = cp + w -> IXE;
		w -> w_status |= WDUMP;
	}
	else {
		register Buf *b = w -> w_textbuf;

		cp = b -> b_contents + b -> b_cursor.row * b -> b_ncols;
		cend = cp + b -> b_ncols;
		b -> b_nmodw = -1;
	}
	mode &= MODEMASK;
	while (cp < cend) {
		cp -> Mode &= ~MODEMASK;
		cp++ -> Mode |= mode;
	}
}
