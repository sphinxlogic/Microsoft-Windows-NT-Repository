#include "win.h"
#include <signal.h>

/* Copyright (c) 1983 University of Maryland Computer Science Department */

#ifndef SIGVTALRM
/* not 4.2BSD */
int	(*sigset())();
#else SIGVTALRM
/* 4.2BSD */
#define sigset(s,d)	signal(s,d)
#define sighold(s)	sigblock(1<<((s)-1))
#define sigrelse(s)	sigsetmask(sigblock(0)&~(1<<((s)-1)))
#endif SIGVTALRM

/* Suspend window system (called on ^Z) */
/* NOTE: if SigMagic is not set user must make sure that SIGTSTP does what he
   wants */
Wsuspend () {
    int (*oldtstp) (), (*oldint) ();
    static nest, restart;	/* Dont want to recurse */
    if (nest)
	return restart++, 0;
    nest = 1;
top:
    if (SigMagic) {		/* Then save signal definitions */
	sigrelse (SIGTSTP);
	sigrelse (SIGINT);	/* Make sure they arent held */
	/* NOTE: if sigrelse calls Wsuspend "nest" gets us back */
	oldtstp = sigset (SIGTSTP, SIG_IGN);
	oldint = sigset (SIGINT, SIG_IGN);
    }
    restart = 0;
    Wcleanup ();		/* If SigMagic, resets sigs to SIG_DFL */
#ifdef this_does_not_seem_to_work_as_well
    kill (0, SIGTSTP);		/* SCREECHing halt */
#else
    kill (getpid (), SIGTSTP);
#endif
    if (SigMagic) {
	sighold (SIGTSTP);
	sighold (SIGINT);	/* Hold these for Winit to do its stuff, */
	sigset (SIGTSTP, oldtstp);
	sigset (SIGINT, oldint);/* putting them back where they were */
    }
    /* (void) */ Winit (1, 1);	/* (void) breaks some compilers */
    if (SigMagic) {
	sigrelse (SIGTSTP);
	sigrelse (SIGINT);
	if (restart)		/* If TSTP signal occurred during Winit */
	    goto top;		/* Note: the oldxxx=sigset() is OK because we
				   have already restored the settings */
	Wrefresh ();
	if (restart)		/* If the Wrefresh was suspended */
	    goto top;
    }
    return nest = 0;
}
