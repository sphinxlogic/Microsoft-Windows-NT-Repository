/* Copyright (c) 1983 University of Maryland Computer Science Department */
/* terminal control module for HP 26??'s */

#include <stdio.h>
#include "Trm.h"
#include "cm.h"
#include "win.h"

/* modemap keeps a map of all the display mode attributes in the HP.
   StrongMode is set on those attributes which are really set; others
   are merely because of some earlier StrongMode attribute. */
#define	StrongMode	0x10
static char modemap[24][80];

static int	DesMode, CurIns, Text[24], MayBeJunkBelow;

static insmode (d) register d; {
    if (d == CurIns)
	return;
    printf (d ? "\033Q" : "\033R");
    CurIns = d;
}

static modes (m) register m; {
    register c = 0;

    if (m & WBLINK)	c |= 1;	/* 1,2,4,8 are magic HP codes */
    if (m & WINVERSE)	c |= 2;
    if (m & WULINE)	c |= 4;
    if (m & WBOLD)	c |= 8;
    DesMode = c;
}

static inslines (n) register n; {
    register i, j;
    register char *p1, *p2;

    p1 = &modemap[24][0];
    i = 24 - n;
    p2 = &modemap[i][0];
    while (--i >= curY) {
	for (j = 80; --j >= 0; )
	 /* modemap[i+n][j] = modemap[i][j]; */
	    *--p1 = *--p2;
	Text[i+n] = Text[i];
    }
    i = curY + n;
    p1 = &modemap[i][0];
    while (--i >= curY) {
	for (j = 80; --j >= 0; )
	 /* modemap[i][j] = 0; */
	    *--p1 = 0;
	Text[i] = 0;
	putchar (033);
	putchar ('L');
    }
    cmpad (n, 2.0);
    MayBeJunkBelow++;
}

static dellines (n) register n; {
    register i, j;
    register char *p1, *p2;

    p1 = &modemap[curY][0];
    i = curY + n;
    p2 = &modemap[i][0];
    for (; i < 24; i++) {
	for (j = 0; j < 80; j++)
	 /* modemap[i-n][j] = modemap[i][j]; */
	    *p1++ = *p2++;
	Text[i-n] = Text[i];
    }
    i = 24 - n;
    p1 = &modemap[i][0];
    for (; i < 24; i++) {
	for (j = 0; j < 80; j++)
	 /* modemap[i][j] = 0; */
	    *p1++ = 0;
	Text[i] = 0;
	putchar (033);
	putchar ('M');
    }
    cmpad (n, 2.0);
    /* Clear new lines (delete line brings up stuff that was held below) */
    if (MayBeJunkBelow) {
	MayBeJunkBelow = 0;
	cmgoto (24-n, 0);
	putchar (033), putchar ('J');
	cmpad (25-n, 2.0);
    }
}

/* Macros to get around HP oddities */

/* When overwriting text, must pad */
#define	PadText(n)	if (!CurIns && curX <= Text[curY]) {		\
				register zz = Text[curY] - curX;	\
				cmpad (Min (zz, n), 1.0);		\
			} else
#define	SetText()	if (curX > Text[curY])				\
				Text[curY] = curX;			\
			else

static writechars (start, end)
register char *start, *end; {
    register k, m, n;
    register char *p;

    n = end-start+1;
    PadText (n);
    p = modemap[curY];
    if (CurIns) {			/* push attributes over */
	for (m = 80 - n; --m >= curX; )
	    p[m + n] = p[m];
	m += n;
	k= p[curX] & ~StrongMode;
	while (--m >= curX)
	    p[m] = k;
    }
    p += curX;
    m = -1;
    cmplus (n);
    while (start <= end) {
	if (m >= 0)			/* Applying old attribute? */
	    if (*p & StrongMode)	/* stop; have hit strong mode */
		m = -1;
	    else
		*p = m;			/* continue applying */
	if ((*p & ~StrongMode) != DesMode) {/* not right mode */
	    printf ("\033&d%c", DesMode + '@');
	    *p = DesMode | StrongMode;
	    m = DesMode;		/* begin applying weak mode */
	}
	putchar (*start++);
	p++;
    }
    if (CurIns) {
	Text[curY] += n;
	cmpad (n, 3.0);
    }
    else
	SetText ();
    rstmodes (m, p);
}

static blanks (n) register n; {
    register k, m;
    register char *p;

    p = modemap[curY];
    if (CurIns) {			/* push attributes over */
	for (m = 80 - n; --m >= curX; )
	    p[m + n] = p[m];
	m += n;
	k = p[curX] & ~StrongMode;
	while (--m >= curX)
	    p[m] = k;
    }
    p += curX;
    m = -1;
    cmplus (n);
    while (--n >= 0) {
	if (m >= 0)			/* Applying old attribute? */
	    if (*p & StrongMode)	/* stop; have hit strong mode */
		m = -1;
	    else
		*p = m;			/* continue applying */
	if ((*p & ~StrongMode) != DesMode) {/* not right mode */
	    printf ("\033&d%c", DesMode + '@');
	    *p = DesMode | StrongMode;
	    m = DesMode;		/* begin applying weak mode */
	}
	putchar (' ');
	p++;
    }
    if (CurIns) {
	Text[curY] += n;
	cmpad (n, 3.0);
    }
    else
	SetText ();
    rstmodes (m, p);
}

static rstmodes (m, p)
register m;
register char *p;
{
    extern Ch *WDCharAt ();
    register c, d;

    if (curX == 0) {		/* cursor has wrapped */
	if (curY >= 24) {	/* screen scrolled, home cursor to fix */
	    printf ("\033H");
	    curY = 0;
	}
	return;			/* nothing to fix */
    }
    /* Determine desired mode of following character */
    d = WDCharAt (curY + 1, curX + 1) -> Mode & MODEMASK;
    c = 0;
    if (d & WBLINK)	c |= 1;	/* Convert to magic HP codes */
    if (d & WINVERSE)	c |= 2;
    if (d & WULINE)	c |= 4;
    if (d & WBOLD)	c |= 8;

    /* First check the mode there now */
    if (c != ((m < 0 || (*p & StrongMode)) ? (*p & ~StrongMode) : m)) {
	/* Was wrong mode, so set right one */
	printf ("\033&d%c", c + '@');
	/* ... and apply that mode to rest of line */
	*p++ = (m=c) | StrongMode;
	d = curX + 1;
    }
    else if (m >= 0)		/* apply mode m to rest of line */
	d = curX;
    else			/* All is well */
	return;

    /* Apply mode m to rest of line */
    while (d < 80) {
	if (*p & StrongMode)	/* Found a strong mode; done */
	    break;
	else
	    *p++ = m;
	d++;
    }
}

static topos (row, col) {
    cmgoto (row-1, col-1);
    cmpad (1, 1.0);
}

#include <sgtty.h>
static init (BaudRate, tabok) {
    float BaudFactor = BaudRate / 10000.;

    W_tt.t_ILmf = 2 + BaudFactor*2.0;
    W_tt.t_ILov = 0;
    W_tt.t_ICmf = BaudFactor*3.0;
    W_tt.t_ICov = 2;
    W_tt.t_DCmf = 2 + BaudFactor*4.0;
    W_tt.t_DCov = 0;
#if 0
    UseTabs = tabok;
#else
    {extern struct sgttyb WOld; UseTabs=(WOld.sg_flags&TBDELAY)==TAB0;}
#endif
    cmcostinit ();
    return 0;
}

static reset () {
    register char *p;

    printf ("\033H\033J\033R");
    p = &modemap[24][0];
    while (p > &modemap[0][0])
	*--p = 0;
    cmat (0, 0);
    CurIns = 0;
    MayBeJunkBelow = 0;
    cmpad (1, 20.);
}

static cleanup () {
    printf ("\033&d@\033R");
    MayBeJunkBelow = 0;
}

static delchars (n) register n; {
    register char *p;
    register m;

    p = &modemap[curY][0];
    for (m = curX+n; m < 80; m++)
	p[m-n] = p[m];
    m = p[79-n] & ~StrongMode;	/* m == mode of last char (was at col 79,
				   now at col 79-n) */
    p += 80;
    while (--n >= 0) {
	putchar (033);
	putchar ('P');
	*--p = m;		/* fill newly blank modes with (weak) m */
    }
    Text[curY] -= n;
    cmpad (n, 4.0);
}

static wipeline () {
    register char *p1, *p2;

    putchar (033);
    putchar ('K');
    /* First take away [zero] all StrongModes at cursor & beyond */
    p1 = &modemap[curY][0];
    p2 = p1 + 80;
    p1 += curX;
    while (p1 < p2)
	*p1++ = 0;
    if (curX == 0)	/* all done */
	return;
    /* Must apply the mode at curY, curX-1 to the rest of the line */
    p1 = &modemap[curY][curX];
    rstmodes (p1[-1] & ~StrongMode, p1);
}

static wipescreen () {
    register char *p;

    printf ("\033H\033J");
    p = &modemap[24][0];	/* ... or &modemap[23][80] */
    while (p > &modemap[0][0])
	*--p = 0;		/* everybody is weak mode 0 */
}

TrmHP () {
	W_tt.t_INSmode = insmode;
	W_tt.t_modes = modes;
	W_tt.t_inslines = inslines;
	W_tt.t_dellines = dellines;
	W_tt.t_blanks = blanks;
	W_tt.t_init = init;
	W_tt.t_cleanup = cleanup;
	W_tt.t_wipeline = wipeline;
	W_tt.t_wipescreen = wipescreen;
	W_tt.t_topos = topos;
	W_tt.t_reset = reset;
	W_tt.t_delchars = delchars;
	W_tt.t_writechars = writechars;
	W_tt.t_length = 24;
	W_tt.t_width = 80;
	Up = "\033A";
	Down = "\n";
	Left = "\b";
	Right = "\033C";
	Home = "\033H";		/* wonder if all HPs have this? */
	CR = "\r";
	Tab = "\t";
	TabWidth = 8;
	AbsPosition = "\033&a%dr%dC";
	ColPosition = "\033&a%dC";
	RowPosition = "\033&a%dR";
	AutoWrap = 1;
	ScreenRows = W_tt.t_length;
	ScreenCols = W_tt.t_width;
	Wcm_init (0);
	return 0;
}
