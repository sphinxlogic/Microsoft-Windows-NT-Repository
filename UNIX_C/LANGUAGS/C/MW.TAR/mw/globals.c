#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Definition of global variables -- see win.h */

Win	*WinList;
Win	*CurWin;
Cov	*WCovList;
Rect	WBox;
int	MajorUpdate;
int	SigMagic;
int	InputPending;
int	LastRedisplayPaused;
int	WBoxActive;
int	WSetRealCursor;
int	WRCurRow;
int	WRCurCol;
int	WindowsActive;
