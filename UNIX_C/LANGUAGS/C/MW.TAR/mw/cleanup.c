/* Initialize, suspend, resume, and exit routines */

/* Copyright (c) 1983 University of Maryland Computer Science Department */
/*	Original code copyright (c) 1981,1980 James Gosling	*/

/* ACT 11-Nov-1982 modified for window package */

#include "win.h"
#include "display.h"
#include <sys/ioctl.h>
#include <sgtty.h>
#include <stdio.h>
#include <signal.h>

extern struct sgttyb WOld;	/* The initial tty mode bits */
extern	WTtyFd;			/* File descriptor for stty/gtty */
extern	WIgnoreTSTP;		/* True => ignore SIGTSTP */
#ifndef SIGVTALRM
int	(*sigset())();
#else
#define sigset signal
#endif
extern	Wexit (), Wsuspend ();

Wcleanup () {
    if (SigMagic) {
	sigset (SIGTSTP, SIG_IGN);
	sigset (SIGINT, SIG_IGN);
    }
    if (W_tt.t_window) (*W_tt.t_window) (0);
    (*W_tt.t_topos) (ScreenLength, 1);
    (*W_tt.t_wipeline) (0, ScreenWidth);
    (*W_tt.t_cleanup) ();
    fflush (stdout);
    ioctl (WTtyFd, TIOCSETN, &WOld);
    if (SigMagic) {
	if (!WIgnoreTSTP)
	    sigset (SIGTSTP, SIG_DFL);
	sigset (SIGINT, SIG_DFL);
    }
    WindowsActive = 0;
    return 0;
}
