#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Clear cursor line of window and corresponding portion of buffer */
Wclearline (w, howto)
register Win *w;
int howto;
{
	register Ch *cp, *bp;
	register Buf *b = w -> w_textbuf;
	register i, i2;

	cp = w -> w_winbuf +
		(w -> w_cursor.row + w -> IYO) * w -> OXE + w -> IXO;
	bp = b -> b_contents +
		(w->w_cursor.row + w->IYO + w->w_bstart.row) * b->b_ncols +
		w -> IXO + w -> w_bstart.col;
	switch (howto) {
	case 0:			/* Cursor to end of line */
	default:
		cp += w -> w_cursor.col;
		bp += w -> w_cursor.col;
		i2 = w -> IXE - w -> w_cursor.col;
		break;
	case 1:			/* Cursor to begin. of line */
		i2 = w -> w_cursor.col;
		break;
	case 2:			/* Entire line */
		i2 = w -> IXE;
		break;
	}
	for (i = 0; i < i2; i++) {
		cp -> Mode &= ~MODEMASK;
		cp -> Mode |= WBUF;
		cp++ -> Char = ' ';
		bp++ -> ch_all = ' ' | (w -> w_mode << NBPB);
	}
	w -> w_status |= WDUMP;
	b -> b_nmodw = -1;
}
