#include "Trm.h"
#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Get frame chars */
/* This routine exists because users should only need to include "win.h" */
Wgetframe (ulc, top, urc, left, right, llc, bottom, lrc)
char *ulc, *top, *urc, *left, *right, *llc, *bottom, *lrc;
{
	*ulc = W_tt.t_frames[0];
	*top = W_tt.t_frames[1];
	*urc = W_tt.t_frames[2];
	*left = W_tt.t_frames[3];
	*right = W_tt.t_frames[4];
	*llc = W_tt.t_frames[5];
	*bottom = W_tt.t_frames[6];
	*lrc = W_tt.t_frames[7];
	return 0;
}
