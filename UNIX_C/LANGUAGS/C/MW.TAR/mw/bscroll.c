#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Relative scroll buffer w->w_textbuf by rows */
/* NOTE THAT THIS ALWAYS LOSES rows LINES OF TEXT */
WBscroll (w, rows)
register Win *w;
register rows;
{
    register Buf *b = w -> w_textbuf;
    register Ch *cp, *ct;

    if (rows < 0) {		/* Open lines at top */
	cp = b -> b_contents + (b -> b_nrows + rows) * b -> b_ncols;
	ct = b -> b_contents + b -> b_nrows * b -> b_ncols;
	while (cp > b -> b_contents)
	    (--ct) -> ch_all = (--cp) -> ch_all;
	while (ct > b -> b_contents)
	    (--ct) -> ch_all = ' ' | (w -> w_mode << NBPB);
    }
    else if (rows > 0) {	/* Open lines at bottom */
	register Ch *end;
	ct = b -> b_contents;
	cp = b -> b_contents + rows * b -> b_ncols;
	end = b -> b_contents + b -> b_nrows * b -> b_ncols;
	while (cp < end)
	    ct++ -> ch_all = cp++ -> ch_all;
	while (ct < end)
	    ct++ -> ch_all = ' ' | (w -> w_mode << NBPB);
    }
    else
	return 0;
    b -> b_cursor.row -= rows;
    if (b -> b_cursor.row < 0)
	b -> b_cursor.row = 0;
    else if (b -> b_cursor.row >= b -> b_nrows)
	b -> b_cursor.row = b -> b_nrows - 1;
    b -> b_nmodw = -1;
    MajorUpdate = 1;
    return 0;
}
