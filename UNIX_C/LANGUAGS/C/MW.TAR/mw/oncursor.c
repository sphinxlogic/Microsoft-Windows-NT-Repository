#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Turn the cursor on or off */
Woncursor (w, on)
register Win *w;
int on;
{
	if ((w -> w_status & WCURSOR) == (on ? 0 : WCURSOR))
		return 0;		/* Already set correctly */
	w -> w_status ^= WCURSOR;
	w -> w_status |= WDUMP;
	return 0;
}
