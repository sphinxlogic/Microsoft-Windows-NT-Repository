#include "Trm.h"
#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Set frame chars */
Wsetframe (ulc, top, urc, left, right, llc, bottom, lrc)
{
	W_tt.t_frames[0] = ulc;
	W_tt.t_frames[1] = top;
	W_tt.t_frames[2] = urc;
	W_tt.t_frames[3] = left;
	W_tt.t_frames[4] = right;
	W_tt.t_frames[5] = llc;
	W_tt.t_frames[6] = bottom;
	W_tt.t_frames[7] = lrc;
	return 0;
}
