/* Copyright (c) 1983 University of Maryland Computer Science Department */
/* 	Original code copyright (c) 1981,1980 James Gosling	*/

/* ACT 11-Nov-1982 modified for window package */
/* ACT 14-Jul-1983 changed to default to homing cursor */
/* ACT 1-Aug-1983 compatibility for /bin/sh: WIgnoreTSTP */

#include "win.h"
#include "display.h"
#include <sys/ioctl.h>
#include <sgtty.h>
#include <stdio.h>
#include <signal.h>

struct sgttyb WOld;		/* The initial tty mode bits */
int	WTtyFd;			/* File descriptor for stty/gtty */
int	WIgnoreTSTP;		/* Set if SIGTSTP is SIG_IGN */
#ifndef SIGVTALRM
/* not 4.2BSD */
int	(*sigset())();
#else SIGVTALRM
/* 4.2BSD */
#define sigset(s,d)	signal(s,d)
#define sighold(s)	sigblock(1<<((s)-1))
#define sigrelse(s)	sigsetmask(sigblock(0)&~(1<<((s)-1)))
#endif SIGVTALRM
extern	Wexit (), Wsuspend ();

char	_sobuf[BUFSIZ];	/* shared with stdio on most Unixes */

/* Init window system.  If settings == 1, use previous settings.  If
   settings == 0, use default settings.  Otherwise use "settings" settings.
   If nomagic != 0, don't catch stop, interrupt, and terminate signals.
   RETURNS: 0 if OK to continue using window system, anything else to
   indicate that the CRT is unusable. */
Winit (settings, nomagic)
struct sgttyb *settings;
{
    static struct sgttyb   sg;
    int rv;
    static int beenhere;

    WTtyFd = 0;

    /* I dont know how system specific this is, but here goes: */
    if ((stdout->_flag & (_IOLBF|_IONBF)) == 0 && stdout->_base == NULL)
	setbuf (stdout, _sobuf);

    /* I should use isatty, but it just does a gtty anyway, so why bother? */
    /* Note: if both of these fail then "we ain't talkin' to no terminal" */
    /* NOTE: STRUCTURE ASSIGNMENT */

    if (gtty (0, &WOld) < 0)
	gtty (WTtyFd = 1, &WOld);
    if (settings) {
	if (settings != (struct sgttyb *) 1)
	    sg = *settings;
	sg.sg_ispeed = WOld.sg_ispeed;/* My, how suspicious we are */
	sg.sg_ospeed = WOld.sg_ospeed;
    }
    else
	sg = WOld;
    sg.sg_flags = (sg.sg_flags & ~(ECHO | CRMOD | XTABS)) | CBREAK;
    ioctl (WTtyFd, TIOCSETN, &sg);
    if (!nomagic /*|| SigMagic*/) {
	SigMagic = 1;
	sigset (SIGINT, Wexit);
	WIgnoreTSTP = sigset (SIGTSTP, Wsuspend) == SIG_IGN;
	sigset (SIGTERM, Wexit);
    }
    ScreenGarbaged = 1;

    /* I wish I didn't have to set everything up yet, but since WDterm_init()
       expects to be in un-user-usable mode I have to.  Oh well. */
    /* NOTE: WDterm_init () may only fail on first attempts! */
    if (rv = WDterm_init ()) {	/* Then we cant run on this terminal */
	if (SigMagic) {		/* Wonder if this is really necessary? */
	    sigset (SIGTSTP, SIG_IGN);
	    sigset (SIGINT, SIG_IGN);
	}
	ioctl (WTtyFd, TIOCSETN, &WOld);
	if (SigMagic) {
	    if (!WIgnoreTSTP)
		sigset (SIGTSTP, SIG_DFL);
	    sigset (SIGINT, SIG_DFL);
	}
	return rv;
    }
    if (W_tt.t_window) (*W_tt.t_window) (0);
    WindowsActive++;
    if (!beenhere) {		/* New!! (Be the first on your block!) */
	beenhere++;
	if (!WSetRealCursor && !WRCurRow && !WRCurCol)
	    WSetRealCursor++;	/* Default to homing the cursor.  The idea
				   here is to get that nasty real cursor
				   out of the way. */
    }
    return 0;
}
