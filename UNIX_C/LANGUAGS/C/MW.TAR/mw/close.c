#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Close a window */
Wclose (w)
register Win *w;
{
	register Win *p;

	WErase (w);		/* Clean it off screen */
	WRemoveCoverList (w);	/* Uncover all other windows */

	/* Unlink window & free space */

	if (WinList == w)
		WinList = w -> w_next;
	else {
		for (p = WinList; p -> w_next != w; p = p -> w_next)
			;
		p -> w_next = w -> w_next;
	}
	free (w -> w_winbuf);
	if (--(w -> w_textbuf -> b_nwins) <= 0) {
		free (w -> w_textbuf -> b_contents);
		free (w -> w_textbuf);
	}
	free (w);
	if (w == CurWin)
		CurWin = WinList;
	return 0;
}
