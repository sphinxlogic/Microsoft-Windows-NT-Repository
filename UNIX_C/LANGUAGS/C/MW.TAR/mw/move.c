#include "win.h"
#include "display.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Move window w */
Wmove (w, xorg, yorg)
register Win *w;
register xorg, yorg;
{
	if (xorg < 0 || xorg + w -> OXE > ScreenWidth)
		return -1;
	if (yorg < 0 || yorg + w -> OYE > ScreenLength)
		return -1;
	if (w -> OXO == xorg && w -> OYO == yorg)
		return 0;
	if ((w -> w_status & WHIDDEN) == 0) {
		WErase (w);		/* Erase visible portions */
		WRemoveCoverList (w);	/* Uncover all other windows */
	}
	w -> w_outside.xorigin = xorg;
	w -> w_outside.yorigin = yorg;
	if ((w -> w_status & WHIDDEN) == 0) {
		WComputeCover (w);	/* Recompute cover for new position */
		w -> w_status |= WDUMP;
		MajorUpdate = 1;	/* May be able to delete/insert lines */
	}
	return 0;
}
