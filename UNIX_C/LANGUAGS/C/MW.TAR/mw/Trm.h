/* Copyright (c) 1983 University of Maryland Computer Science Department */
/* terminal control module header file */

/*	Original code copyright (c) 1981,1980 James Gosling	*/

/* ACT 10-Nov-1982 Modified for Window Package */

struct TrmControl {
    int     (*t_topos) ();	/* move the cursor to the indicated
				   (row,column); (1,1) is the upper left */
    int     (*t_reset) ();	/* reset terminal (screen is in unkown state,
				   convert it to a known one) */
    int     (*t_INSmode) ();	/* set or reset character insert mode */
    int     (*t_modes) ();	/* (re)set highlight, blink, bold, underln */
    int     (*t_inslines) ();	/* insert n lines */
    int     (*t_dellines) ();	/* delete n lines */
    int     (*t_blanks) ();	/* print n blanks */
    int     (*t_init) ();	/* initialize terminal settings */
    int     (*t_cleanup) ();	/* clean up terminal settings */
    int     (*t_wipeline) ();	/* erase to the end of the line */
    int     (*t_wipescreen) ();	/* erase the entire screen */
    int     (*t_delchars) ();	/* delete n characters */
    int     (*t_writechars) ();	/* write characters; either inserting or
				   overwriting according to the current
				   character insert mode. */
    int     (*t_window) ();	/* set the screen window so that IDline
				   operations only affect the first n
				   lines of the screen */
    int     (*t_flash) ();	/* Flash the screen -- not set if this
				   terminal type won't support it. */
/* This is a hack for VT100s with cute graphics chars */
    int     (*t_donerefresh) ();/* A Wrefresh() is done.  Not set if not
				   needed. */
/* costs are expressed as number_affected*mf + ov
	cost to insert/delete 1 line: (number of lines left)*ILmf+ILov
	cost to insert one character: (number of chars left on line)*ICmf+ICov
	cost to delete n characters:  n*DCmf+DCov */
    float   t_ILmf;		/* insert lines multiply factor */
    int     t_ILov;		/* insert lines overhead */
    float   t_ICmf;		/* insert character multiply factor */
    int     t_ICov;		/* insert character overhead */
    float   t_DCmf;		/* delete character multiply factor */
    int     t_DCov;		/* delete character overhead */
    int     t_length;		/* screen length */
    int     t_width;		/* screen width */
    int     t_needspaces;	/* set true iff the terminal needs to have
				   real spaces in the middle of lines in
				   order to have character insertion work --
				   this only matters on terminals that
				   distinguish between real and imaginary
				   blanks. */
    char    t_padc;		/* Pad character (default ^@) */
    char    t_frames[8];	/* Window frame chars (default +-+||+-+) */
};

#define MissingFeature 99999	/* IC and IL overheads should be set to this
				   value if the corresponding feature is
				   missing */
struct TrmControl W_tt;		/* terminal specific information for the
				   current display */

int	InverseVideo,		/* Use inverse video if terminal supports it */
	NoOperation ();		/* Global no-op function */
