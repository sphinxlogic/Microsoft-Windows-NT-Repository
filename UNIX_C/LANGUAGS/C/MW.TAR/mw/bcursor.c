#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Set the buffer cursor */
WBcursor (w, row, col)
Win *w;
register row, col;
{
	register Buf *b = w -> w_textbuf;

	b -> b_cursor.row = Min (Max (row, 0), b -> b_nrows - 1);
	b -> b_cursor.col = Min (Max (col, 0), b -> b_ncols - 1);
	return 0;
}
