#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Close all windows (for "resetting") */
Wcloseall () {
	register Win *w;

	for (w = WinList; w; w = w -> w_next)
		Wclose (w);
	return 0;
}
