#include "Trm.h"
#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Frame a window (using default frame chars) */
Wframe (w)
Win *w;
{
	return Wborder (w, W_tt.t_frames[0], W_tt.t_frames[1],
			   W_tt.t_frames[2], W_tt.t_frames[3],
			   W_tt.t_frames[4], W_tt.t_frames[5],
			   W_tt.t_frames[6], W_tt.t_frames[7]);
}
