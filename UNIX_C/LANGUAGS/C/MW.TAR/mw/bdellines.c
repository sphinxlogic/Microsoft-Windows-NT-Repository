#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Delete n lines from buffer at cursor */
WBdellines (w, n)
Win *w;
int n;
{
	register Buf *b;
	register Ch *cp, *ct, *end;
	int blank;

	if (n < 0)
		return -1;
	if (n == 0)
		return 0;
	blank = ' ' | (w -> w_mode << NBPB);
	b = w -> w_textbuf;
	ct = b -> b_contents + b -> b_cursor.row * b -> b_ncols;
	cp = ct + n * b -> b_ncols;
	end = b -> b_contents + b -> b_nrows * b -> b_ncols;
	while (cp < end)
		ct++ -> ch_all = cp++ -> ch_all;
	while (ct < end)
		ct++ -> ch_all = blank;
	b -> b_nmodw = -1;
	return 0;
}
