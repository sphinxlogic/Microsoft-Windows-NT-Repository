#ifndef lint
static char sccsid[]=
"@(#)Window Library 1.11\tU of Maryland (ACT) 6-Jun-1985 (Released)";
#endif

/* Copyright (c) 1983 University of Maryland Computer Science Department */

#include "win.h"
#include "display.h"

/* Open a new window */
Win *
Wopen (id, xorg, yorg, xext, yext, bcols, brows)
register id;
int xorg, yorg, xext, yext, bcols, brows;
{
	register Win *w;
	register Buf *b;
	register Ch *c;

	if (xorg < 0 || xext < 1 || xorg+xext > ScreenWidth)
		return 0;
	if (yorg < 0 || yext < 1 || yorg+yext > ScreenLength)
		return 0;
	if (brows < 0 || bcols < 0)
		return 0;
	if (brows < yext) brows = yext;
	if (bcols < xext) bcols = xext;
	w = (Win *) malloc (sizeof (Win));
	if (w == 0)
		return 0;
	w -> w_winbuf = (Ch *) malloc (sizeof (Ch) * xext * yext);
	if (w -> w_winbuf == 0) {
		free (w);
		return 0;
	}
	b = (Buf *) malloc (sizeof (Buf));
	if (b == 0) {
		free (w -> w_winbuf);
		free (w);
		return 0;
	}
	b -> b_contents = (Ch *) malloc (sizeof (Ch) * brows * bcols);
	if (b -> b_contents == 0) {
		free (b);
		free (w -> w_winbuf);
		free (w);
		return 0;
	}
	b -> b_nrows = brows;
	b -> b_ncols = bcols;
	b -> b_nwins = 1;
	b -> b_nmodw = 0;
	b -> b_cursor.row = 0;
	b -> b_cursor.col = 0;
	w -> w_next = WinList;
	w -> w_id = id;
	w -> w_outside.xorigin = xorg;
	w -> w_outside.xextent = xext;
	w -> w_outside.yorigin = yorg;
	w -> w_outside.yextent = yext;
	w -> w_inside.xorigin = 0;
	w -> w_inside.xextent = xext;
	w -> w_inside.yorigin = 0;
	w -> w_inside.yextent = yext;
	w -> w_textbuf = b;
	w -> w_bstart.row = 0;
	w -> w_bstart.col = 0;
	w -> w_cursor.row = 0;
	w -> w_cursor.col = 0;
	w -> w_auxcursor.row = 0;
	w -> w_auxcursor.col = 0;
	w -> w_bcursor = b -> b_contents;
	w -> w_wcursor = w -> w_winbuf;
	w -> w_popup = 1;
	w -> w_mode = 0;
	w -> w_status = WDUMP;
	for (c = w -> w_winbuf + xext * yext; c > w -> w_winbuf;)
		(--c) -> ch_all = ' ' | (WBUF<<NBPB);
	for (c = b -> b_contents + brows * bcols; c > b -> b_contents;)
		(--c) -> ch_all = ' ';
	WinList = CurWin = w;
	WComputeCover (w);
	return w;
}
