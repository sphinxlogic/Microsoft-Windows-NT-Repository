#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Set the window's inside area (margins) */
/* AFTER THIS ROUTINE SUCCEEDS,
   ALL CHARS INSIDE COME FROM w->w_textbuf; AND
   ALL CHARS OUTSIDE COME FROM w->w_winbuf */
/* SETTING MARGINS TO ZERO TURNS OFF WBORDERED STATUS BIT */
Wsetmargins (w, inxorg, inyorg, inxext, inyext)
register Win *w;
int inxorg, inyorg, inxext, inyext;
{
	register Ch *c = w -> w_winbuf;
	register i, j;
	int inx, iny, orow, ocol;

	if (w -> OXE < inxorg+inxext || inxorg < 0 || inxext < 1)
		return -1;
	if (w -> OYE < inyorg+inyext || inyorg < 0 || inyext < 1)
		return -1;

	for (i = 0; i < inyorg; i++) for (j = 0; j < w -> OXE; j++)
		c++ -> Mode &= MODEMASK|WINVIS;
	inx = inxorg + inxext;
	iny = inyorg + inyext;
	for (; i < iny; i++) {
		for (j = 0; j < inxorg; j++)
			c++ -> Mode &= MODEMASK|WINVIS;
		for (; j < inx; j++) {
			c -> Mode &= MODEMASK|WINVIS;
			c++ -> Mode |= WBUF;
		}
		for (; j < w -> OXE; j++)
			c++ -> Mode &= MODEMASK|WINVIS;
	}
	for (; i < w -> OYE; i++) for (j = 0; j < w -> OXE; j++)
		c++ -> Mode &= MODEMASK|WINVIS;
	orow = w -> w_inside.yorigin + w -> w_cursor.row;
	ocol = w -> w_inside.xorigin + w -> w_cursor.col;
	w -> w_inside.xorigin = inxorg;
	w -> w_inside.yorigin = inyorg;
	w -> w_inside.xextent = inxext;
	w -> w_inside.yextent = inyext;
	/* Move cursor to be within (new) margins */
	w -> w_cursor.row =
		orow >= w -> w_inside.yextent ? w -> w_inside.yextent - 1 :
		orow <  w -> w_inside.yorigin ? 0			  :
						orow - w -> w_inside.yorigin;
	w -> w_cursor.col =
		ocol >= w -> w_inside.xextent ? w -> w_inside.xextent - 1 :
		ocol <  w -> w_inside.xorigin ? 0			  :
						ocol - w -> w_inside.xorigin;
	WFixCursor (w);
	w -> w_status |= WDUMP;
	/* Clear bordered bit if borders are gone */
	if (inxorg < 1 || inxorg + inxext == w -> OXE ||
	    inyorg < 1 || inyorg + inyext == w -> OYE)
		w -> w_status &= ~WBORDERED;
	return 0;
}
