/* Copyright (c) 1983 University of Maryland Computer Science Department */

#include "win.h"

#define	Wwrap(w,on)	((w)->w_status &= ~WWRAPOFF,	\
			 (w)->w_status |= (on)?0:WWRAPOFF, 0)
#define	Wnewline(w,on)	((w)->w_status &= ~WNEWLINE,	\
			 (w)->w_status |= (on)?WNEWLINE:0, 0)
#define	Wsetmode(w,m)	((w)->w_mode &= ~MODEMASK,	\
			 (w)->w_mode |= (m) & MODEMASK, 0)
#define	Wsetpopup(w,p)	((w)->w_popup = (p), 0)
#define	Wcurup(w,n)	(WAcursor (w,			\
			 (w)->w_cursor.row+(w)->w_bstart.row-(n),\
			 (w)->w_cursor.col+(w)->w_bstart.col))
#define	Wcurdown(w,n)	(WAcursor (w,			\
			 (w)->w_cursor.row+(w)->w_bstart.row+(n),\
			 (w)->w_cursor.col+(w)->w_bstart.col))
#define	Wcurleft(w,n)	(WAcursor (w,			\
			 (w)->w_cursor.row+(w)->w_bstart.row,\
			 (w)->w_cursor.col+(w)->w_bstart.col-(n)))
#define	Wcurright(w,n)	(WAcursor (w,			\
			 (w)->w_cursor.row+(w)->w_bstart.row,\
			 (w)->w_cursor.col+(w)->w_bstart.col+(n)))
#define	WWtoBcursor(w)	(WAcursor (w,			\
			 (w)->w_textbuf->b_cursor.row-(w)->IYO,\
			 (w)->w_textbuf->b_cursor.col-(w)->IXO))

/* NOTE: THESE MACROS MAY BE SYSTEM DEPENDENT */
#define	WCHAROF(c)	((c)&0377)
#define	WMODEOF(c)	((c)>>NBPB)

/* Function types for non-integer functions */
Win *Wopen (), *Wlink (), *Wfind (), *Wboxfind ();
