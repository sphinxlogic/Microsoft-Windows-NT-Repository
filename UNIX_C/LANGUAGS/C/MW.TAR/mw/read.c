#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Read back from window at cursor, and advance cursor */
/* If charonly set returns only char (not mode<<NBPB | char) */
/* If winonly set returns only char from window (even if not visible) */
Wread (w, charonly, winonly)
register Win *w;
int charonly, winonly;
{
	register Ch *c = w -> w_winbuf +
		(w -> w_cursor.row + w -> IYO) * w -> OXE +
		w -> w_cursor.col + w -> IXO;
	int rv;

	if (!winonly && (c -> Mode & WBUF))
		c = w -> w_bcursor;
	rv = charonly ? c -> Char : c -> ch_all;
	w -> w_cursor.col++;
	w -> w_bcursor++;
	if (w -> w_cursor.col >= w -> IXE) {
		w -> w_cursor.col = 0;
		w -> w_cursor.row++;
		if (w -> w_cursor.row >= w -> IYE)
			w -> w_cursor.row = 0;
		WFixCursor (w);
	}
	if ((w -> w_status & WCURSOR) == 0)
		w -> w_status |= WDUMP;
	return rv;
}
