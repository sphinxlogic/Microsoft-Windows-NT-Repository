#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Insert n blanks at cursor in window w */
Winschars (w, n)
register Win *w;
int n;
{
	register Buf *b;
	register Ch *cp, *ct, *start;
	int blank;

	if (n < 0)
		return -1;
	if (n == 0)
		return 0;
	if (n + w -> w_cursor.col > w -> IXE)
		n = w -> IXE - w -> w_cursor.col;
	blank = ' ' | (w -> w_mode << NBPB);
	b = w -> w_textbuf;

	/* w->w_winbuf */
	ct = w -> w_winbuf + (w -> IYO + w -> w_cursor.row) * w -> OXE +
		w -> IXO;
	start = ct + w -> w_cursor.col;
	ct += w -> IXE;
	cp = ct - n;
	while (cp > start) {
		(--ct) -> Char = (--cp) -> Char;
		ct -> Mode &= WINVIS;
		ct -> Mode |= cp -> Mode & ~WINVIS;
	}
	while (ct > start) {
		(--ct) -> Char = (--cp) -> Char;
		ct -> Mode &= WINVIS;
		ct -> Mode |= WBUF;
	}
	/* w->w_textbuf */
	ct = b -> b_contents +
	  (w -> IYO + w -> w_bstart.row + w -> w_cursor.row) * b -> b_ncols +
	  w -> w_bstart.col + w -> IXO;
	start = ct + w -> w_cursor.col;
	ct += w -> IXE;
	cp = ct - n;
	while (cp > start)
		(--ct) -> ch_all = (--cp) -> ch_all;
	while (ct > start)
		(--ct) -> ch_all = blank;
	w -> w_status |= WDUMP;
	b -> b_nmodw = -1;
	return 0;
}
