#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Position the aux cursor */
Wauxcursor (w, row, col)
register Win *w;
register row, col;
{
	w -> w_auxcursor.row = Min (Max (row, 0), w -> OYE - 1);
	w -> w_auxcursor.col = Min (Max (col, 0), w -> OXE - 1);
	WFixCursor (w);
	return 0;
}
