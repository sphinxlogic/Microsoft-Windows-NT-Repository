#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Return char from buffer at buffer cursor, and advance cursor */
/* If charonly set returns only char, otherwise mode<<NBPB | char */
WBread (w, charonly)
Win *w;
{
	register Buf *b = w -> w_textbuf;
	register Ch *c;
	int rv;

	c = b -> b_contents + b -> b_cursor.row * b -> b_ncols +
		b -> b_cursor.col;
	rv = charonly ? c -> Char : c -> ch_all;
	b -> b_cursor.col++;
	if (b -> b_cursor.col >= b -> b_ncols) {
		b -> b_cursor.col = 0;
		b -> b_cursor.row++;
		if (b -> b_cursor.row >= b -> b_nrows)
			b -> b_cursor.row = 0;
	}
	return rv;
}
