#include "window.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Print C style string to buffer */
WBputs (s, w)
register char *s;
register Win *w;
{
	while (*s)
		WBputc (*s++, w);
	return 0;
}

/* Put a char into buffer */
WBputc (c, w)
register c;
register Win *w;
{
	register Buf *b = w -> w_textbuf;
	register Ch *cp;

	switch (c &= 0x7f) {
	case '\n':		/* Newline */
nl:
		b -> b_cursor.row++;
		if (b -> b_cursor.row >= b -> b_nrows)
			WBscroll (w, 1);
		if (w -> w_status & WNEWLINE)
			goto cr;
		break;
	case '\r':		/* Carriage return */
		if (w -> w_status & WNEWLINE)
			goto nl;
cr:
		b -> b_cursor.col = 0;
		break;
	case '\b':		/* Backspace */
		if (b -> b_cursor.col)
			b -> b_cursor.col--;
		break;
	case '\t':		/* Tab */
		c = (b -> b_cursor.col / 8 + 1) * 8;
		if (c < b -> b_ncols)
			b -> b_cursor.col = c;
		break;
	case '\7':		/* Bell */
		Ding ();
		break;
	default:
		if (c < 0x20 || c == 0x7f)/* Control char or DEL */
			break;
		cp = b -> b_contents + b -> b_cursor.row * b -> b_ncols +
			b -> b_cursor.col++;
		cp -> Mode &= ~MODEMASK;/* Clear mode bits */
		cp -> ch_all = c | (w -> w_mode << NBPB);
		if (b -> b_cursor.col >= b -> b_ncols)
			if (w -> w_status & WWRAPOFF)
				b -> b_cursor.col--;
			else {
				b -> b_cursor.col = 0;
				b -> b_cursor.row++;
				if (b -> b_cursor.row >= b -> b_nrows)
					WBscroll (w, 1);
			}
		b -> b_nmodw = -1;
		break;
	}
	return 0;
}
