#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Find window given ID, and make it the current one */
Win *
Wfind (id)
register id;
{
	register Win *w;

	for (w = WinList; w; w = w -> w_next) {
		if (w -> w_id == id)
			return CurWin = w;
	}
	return 0;
}
