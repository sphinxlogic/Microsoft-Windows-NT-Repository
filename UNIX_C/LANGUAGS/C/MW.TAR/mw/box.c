#include "win.h"
#include "display.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Create the box at the given coordinates, clipping to fit screen */

Wbox (xorg, yorg, xext, yext)
register xorg, yorg, xext, yext;
{
	WBox.xorigin = Min (Max (xorg, 0), ScreenWidth - 1);
	WBox.yorigin = Min (Max (yorg, 0), ScreenLength - 1);
	WBox.xextent = xext > 1 ?
		(xorg + xext < ScreenWidth ? xext : ScreenWidth - xorg) : 1;
	WBox.yextent = yext > 1 ?
		(yorg + yext < ScreenLength? yext : ScreenLength- yorg) : 1;
	if (WBoxActive)
		MajorUpdate = 1;
	WBoxActive = 1;
	return 0;
}
