#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Label a window */
Wlabel (w, label, bottom, center)
register Win *w;
register char *label;
int bottom, center;
{
	int		len, maxlen, mode;
	register Ch	*cp;
	register	pos;

	/* Make sure there is room, by calling setmargins if necessary */
	if (bottom == 0)
	    if (w -> IYO == 0 && Wsetmargins (w, w->IXO, 1, w->IXE, w->IYE-1))
		return -1;
	    else
		cp = w -> w_winbuf;
	else
	    if (w -> IYO + w -> IYE == w -> OYE &&
			Wsetmargins (w, w->IXO, w->IYO, w->IXE, w->IYE-1))
		return -1;/* No room at bottom */
	    else
		cp = w -> w_winbuf + (w -> OYE - 1) * w -> OXE;
	{
		register char *s = label;

		while (*s++)	
			;
		len = s - label - 1;
	}
	maxlen = w -> OXE;
	if (w -> w_status & WBORDERED) {
		maxlen -= 2;
		cp++;
	}
	if (len > maxlen)
		len = maxlen;
	mode = w -> w_mode ^ WINVERSE;
	pos = 0;
	if (center && len < maxlen) {
		register i = (maxlen - len) >> 1;/* / 2 but faster */

		pos += i;
		while (--i >= 0) {
			cp -> Mode &= WINVIS;
			cp -> Mode |= mode;
			cp++ -> Char = ' ';
		}
	}
	pos += len;
	while (--len >= 0) {
		cp -> Mode &= WINVIS;
		cp -> Mode |= mode;
		cp++ -> Char = *label++;
	}
	while (pos < maxlen) {
		cp -> Mode &= WINVIS;
		cp -> Mode |= mode;
		cp++ -> Char = ' ';
		pos++;
	}
	w -> w_status |= WDUMP;
	return 0;
}
