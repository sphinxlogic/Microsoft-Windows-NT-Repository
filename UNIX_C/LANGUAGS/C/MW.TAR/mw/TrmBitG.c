/* Copyright (c) 1983 University of Maryland Computer Science Department */
/* terminal control module for BBN BitGraph
 *
 * ACT 24-Jul-1982 Modified from Ann Arbor Ambassador driver
 * The thing needs padding only at 19200 baud.
 */

#include <stdio.h>
#include "Trm.h"

static
int	curX, curY;

static int   Baud;

static CurGraph;

static
enum IDmode { m_insert = 1, m_overwrite = 0}
	DesiredMode;

#define	PAD(n,f)	if(Baud>9600)pad(n,f)

static
INSmode (new)
enum IDmode new; {
	DesiredMode = new;
};

static
Curmodes, Desmodes;

static
modes (new) {
	Desmodes = new;
}

static
Setmodes (OverRide) {
	register LDes = OverRide ? 0 : Desmodes;
	static char *mds[16] = { "0", "0;1", "0;4", "0;1;4", "0;5",
		"0;1;5", "0;4;5", "0;1;4;5", "0;7", "0;1;7", "0;4;7",
		"0;1;4;7", "0;5;7", "0;1;5;7", "0;4;5;7", "1;4;5;7" };

	if (LDes == Curmodes)
		return;
	printf ("\033[%sm", mds[LDes]);
	Curmodes = LDes;
}

static
inslines (n) {
	Setmodes (1);
	printf (n <= 1 ? "\033[L" : "\033[%dL", n);
	PAD (64-curY-n, 3.0);
};

static
dellines (n) {
	Setmodes (1);
	printf (n <= 1 ? "\033[M" : "\033[%dM", n);
	PAD (64-curY, 3.0);
};

static
writechars (start, end)
register char *start,
	      *end; {
	register p = end-start+1;
	Setmodes (0);
	if (DesiredMode == m_insert) {
		printf ("\033[%d@", p);
		PAD (1, 3.0);
	}
	curX += p;
	while (start <= end) {
		if (*start & 0x80) {
			if (CurGraph == 0) {
				printf ("\033(0");
				CurGraph++;
			}
			putchar (*start++ & 0x7f);
		}
		else {
			if (CurGraph) {
				printf ("\033(B");
				CurGraph = 0;
			}
			putchar (*start++);
		}
	}
	PAD (p, .6);
};

static
blanks (n) {
	if (n > 0) {
		Setmodes (0);
		if (DesiredMode == m_insert) {
			printf ("\033[%d@", n);
			PAD (1, 3.0);
		}
		curX += n;
		while (--n >= 0) putchar (' ');
	}
	PAD (n, .6);
};

static float BaudFactor;

static pad(n,f)
float   f; {
	register k;

	k = n * f * BaudFactor;
	while (--k >= 0)
	putchar (0);
};

static
topos (row, column) {
	if (curY == row) {
		if (curX == column)
			return;
		if (curX == column + 1) {
			putchar ('\b');
			goto done;
		}
	}
	if (curY+1 == row && (column == 1 || column == curX)) {
		if (column != curX) putchar (015);
		putchar (012);
		goto done;
	}
	if (curY == row+1 && column == curX) {
		printf ("\033M");
		goto done;
	}
	if (row == 1 && column == 1) {
		printf ("\033[H");
		goto done;
	}
	if (column == 1) {
		printf ("\033[%dH", row);
		goto done;
	}
	printf ("\033[%d;%dH", row, column);
done: 
	curX = column;
	curY = row;
};

static
init (BaudRate) {
	Baud = BaudRate;
	BaudFactor = ((float) BaudRate) / 10000.;
	return 0;
};

static
reset () {
	printf ("\033[?50l");		/* Turn off auto XON XOFF */
	printf ("\033[H\033[2J\033[0m");/* Home, clear, no modes */
	printf ("\017\033(B");		/* Funny graphics off */
	curX = curY = 1;
	Curmodes = 0;
	CurGraph = 0;
	DesiredMode = m_overwrite;
};

static
cleanup () {
	Setmodes (1);
	if (CurGraph) {
		printf ("\033(B");
		CurGraph = 0;
	}
	topos (64, 1);
	printf("\033[?50h");		/* Turn auto XON XOFF back on */
};

static
wipeline () {
	Setmodes (1);
	printf ("\033[K");
	PAD (1, 6.0);
};

static
wipescreen () {
	Setmodes (1);
	printf("\033[2J");
	PAD (1, 10.0);
};

static
delchars (n) {
	if (n<=0) return;
	Setmodes (1);
	printf(n == 1 ? "\033[P" : "\033[%dP", n);
	PAD (1, 3.0);
};

static
flash () {
	printf ("\033[?5%c", InverseVideo ? 'h' : 'l');
	pad (1, 100.0);

/* (ACT) This one's more fun, but takes too long: */
/*	printf ("\033:0;0;13;2000;0;0;0;0;0;0;31;7;16;16;16;0;64;0P");*/

	printf ("\033[?5%c", InverseVideo ? 'l' : 'h');
	pad (1, 100.0);		/* this is REALLY slow!! */
}

/* Turn off graphics mode */
static donerefresh () {
    if (CurGraph) {
	printf ("\033(B");
	CurGraph = 0;
    }
}

TrmBitG () {
	register char *t;
	int f_height, f_width;
	char *getenv();

	t = getenv ("FONTHEIGHT");
	f_height = t && *t ? atoi (t) : 16;
	t = getenv ("FONTWIDTH");
	f_width = t && *t ? atoi (t) : 9;

	W_tt.t_length = 1024 / f_height;
	W_tt.t_width = 768 / f_width;

	W_tt.t_INSmode = INSmode;
	W_tt.t_modes = modes;
	W_tt.t_inslines = inslines;
	W_tt.t_dellines = dellines;
	W_tt.t_blanks = blanks;
	W_tt.t_init = init;
	W_tt.t_cleanup = cleanup;
	W_tt.t_wipeline = wipeline;
	W_tt.t_wipescreen = wipescreen;
	W_tt.t_topos = topos;
	W_tt.t_reset = reset;
	W_tt.t_delchars = delchars;
	W_tt.t_writechars = writechars;
	W_tt.t_flash = flash;
	W_tt.t_donerefresh = donerefresh;
	W_tt.t_window = 0;
	W_tt.t_ILmf = 0;		/* well, only below 19200 */
	W_tt.t_ILov = 5;
	W_tt.t_ICmf = 0;		/* same */
	W_tt.t_ICov = 5;
	W_tt.t_DCmf = 0;		/* ditto */
	W_tt.t_DCov = 5;
	W_tt.t_frames[0] = 'l' | 0x80;	/* ulc */
	W_tt.t_frames[1] =
	W_tt.t_frames[6] = 'q' | 0x80;	/* top, bottom */
	W_tt.t_frames[2] = 'k' | 0x80;	/* urc */
	W_tt.t_frames[3] =
	W_tt.t_frames[4] = 'x' | 0x80;	/* left, right sides */
	W_tt.t_frames[5] = 'm' | 0x80;	/* llc */
	W_tt.t_frames[7] = 'j' | 0x80;	/* lrc */
	return 0;
};
