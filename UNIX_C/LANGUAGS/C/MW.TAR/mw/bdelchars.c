#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Delete n chars from buffer at cursor */
WBdelchars (w, n)
Win *w;
int n;
{
	register Buf *b;
	register Ch *cp, *ct, *cend;
	int blank;

	if (n < 0)
		return -1;
	if (n == 0)
		return 0;
	b = w -> w_textbuf;
	if (n + b -> b_cursor.col > b -> b_ncols)
		n = b -> b_ncols - b -> b_cursor.col;
	blank = ' ' | (w -> w_mode << NBPB);

	ct = b -> b_contents + b -> b_cursor.row * b -> b_ncols;
	cend = ct + b -> b_ncols;
	ct += b -> b_cursor.col;
	cp = ct + n;
	while (cp < cend)
		ct++ -> ch_all = cp++ -> ch_all;
	while (ct < cend)
		ct++ -> ch_all = blank;
	b -> b_nmodw = -1;
	return 0;
}
