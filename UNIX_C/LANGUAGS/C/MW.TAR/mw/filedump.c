#include "win.h"
#include "display.h"
#include <stdio.h>

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Dump current screen (as it would look if it were refreshed) to a file */
/* File format is: two hex digits (= 1 byte) of screen width, two hex digits
   of screen length, newline, screen length lines of screen width * 4
   characters each, which are the characters/mode values for that position.
   0000 (mode 0, char null) is an empty position.  (First 2 are mode.) */

Wfiledump (file)
char *file;
{
	static Ch *disp;
	register Ch *c;
	register Win *w;
	register j, i;
	FILE *f;

	if ((f = fopen (file, "w")) == NULL)
		return -1;
	if (disp == 0) {
		disp = (Ch *)
			malloc (sizeof (Ch) * ScreenLength * ScreenWidth);
		if (disp == 0)
			return -1;
	}
	for (c = disp + ScreenLength * ScreenWidth; c > disp; )
		(--c) -> ch_all = 0;	/* Fake empty position */
	for (w = WinList; w; w = w -> w_next) {
		if ((w -> w_status & WHIDDEN) == 0)
			WFDump (w, disp);
	}
	if (WBoxActive)
		WFBox (disp);
	fprintf (f, "%02x%02x\n", ScreenWidth, ScreenLength);
	c = disp;
	for (i = 0; i < ScreenLength; i++, fprintf (f, "\n"))
		for (j = 0; j < ScreenWidth; j++, c++)
			fprintf (f, "%02x%02x", ((int) c -> Mode) & 0xff,
				((int) c -> Char) & 0xff);
			c++;
	fclose (f);
	return 0;
}

/* Dump visible portions of window w to display d */
static
WFDump (w, d)
register Win *w;
Ch *d;
{
	register Ch *wt, *ww, *dp;
	register i, j;
	register Buf *b = w -> w_textbuf;

	wt = b -> b_contents + w -> w_bstart.row * b -> b_ncols +
		w -> w_bstart.col;
	ww = w -> w_winbuf;
	for (i = 0; i < w -> OYE; i++) {
		dp = d + (w -> OYO + i) * ScreenWidth + w -> OXO;
		for (j = 0; j < w -> OXE; j++) {
			if (ww -> Mode & WINVIS)
				dp++;
			else if (ww -> Mode & WBUF) {
				dp -> Mode = wt -> Mode ^ ww -> Mode;
				dp++ -> Char = wt -> Char;
			} else
				dp++ -> ch_all = ww -> ch_all;
			wt++, ww++;
		}
		wt += b -> b_ncols - w -> OXE;
	}
	if ((w -> w_status & WCURSOR) == 0) {
		i = w -> IYO + w -> w_cursor.row;
		j = w -> IXO + w -> w_cursor.col;
		if (((w->w_winbuf + i * w->OXE + j)->Mode & WINVIS) == 0) {
			dp = d + (w -> OYO + i) * ScreenWidth + w -> OXO + j;
			dp -> Mode ^= WBLINK|WINVERSE;
		}
	}
}

/* Draw the box on display d */
static
WFBox (d)
register Ch *d;
{
	register i, j;
	register Ch *dp;

	j = WBox.yorigin;
	dp = d + j * ScreenWidth + WBox.xorigin;
	for (i = 0; i < WBox.xextent; i++)
		dp++ -> Mode ^= WINVERSE;
	for (i = 2; i < WBox.yextent; i++) {
		dp = d + (++j) * ScreenWidth + WBox.xorigin;
		dp -> Mode ^= WINVERSE;
		if (WBox.xextent > 1) {
			dp += WBox.xextent - 1;
			dp -> Mode ^= WINVERSE;
		}
	}
	if (WBox.yextent > 1) {
		dp = d + (++j) * ScreenWidth + WBox.xorigin;
		for (i = 0; i < WBox.xextent; i++)
			dp++ -> Mode ^= WINVERSE;
	}
}
