#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Tie the buffer cursor to the (current) window cursor */
WBtoWcursor (w)
register Win *w;
{
	register Buf *b = w -> w_textbuf;

	b -> b_cursor.row = w -> w_cursor.row + w -> IYO + w -> w_bstart.row;
	b -> b_cursor.col = w -> w_cursor.col + w -> IXO + w -> w_bstart.col;
}
