#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Insert n blanks in buffer at cursor */
WBinschars (w, n)
Win *w;
int n;
{
	register Buf *b;
	register Ch *cp, *ct, *start;
	int blank;

	if (n < 0)
		return -1;
	if (n == 0)
		return 0;
	b = w -> w_textbuf;
	if (n + b -> b_cursor.col > b -> b_ncols)
		n = b -> b_ncols - b -> b_cursor.col;
	blank = ' ' | (w -> w_mode << NBPB);

	ct = b -> b_contents + b -> b_cursor.row * b -> b_ncols;
	start = ct + b -> b_cursor.col;
	ct += b -> b_ncols;
	cp = ct - n;
	while (cp > start)
		(--ct) -> ch_all = (--cp) -> ch_all;
	while (ct > start)
		(--ct) -> ch_all = blank;
	b -> b_nmodw = -1;
	return 0;
}
