#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Clear buffer (w->w_winbuf not involved) */
WBclear (w, howto)
Win *w;
int howto;
{
	register Buf *b = w -> w_textbuf;
	register Ch *c, *end;
	register blank = ' ' | (w -> w_mode << NBPB);

	switch (howto) {
	case 0:			/* cursor to end of buffer */
	default:
		c = b -> b_contents + b -> b_cursor.row * b -> b_ncols +
			b -> b_cursor.col;
		end = b -> b_contents + b -> b_nrows * b -> b_ncols;
		break;
	case 1:			/* Beginning of buffer to cursor */
		c = b -> b_contents;
		end = b -> b_contents + b -> b_cursor.row * b -> b_ncols +
			b -> b_cursor.col;
		break;
	case 2:			/* Entire buffer */
		c = b -> b_contents;
		end = c + b -> b_nrows * b -> b_ncols;
		break;
	}
	while (c < end)
		c++ -> ch_all = blank;
	b -> b_nmodw = -1;
	return 0;
}
