#include <stdio.h>

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Exit after cleaning up */
Wexit (code) {
    Wcleanup ();
    fflush (stdout);
    exit (code);
}
