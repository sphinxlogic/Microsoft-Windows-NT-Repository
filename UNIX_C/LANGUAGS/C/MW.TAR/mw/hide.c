#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Routines dealing with hiding windows */

/* Hide window w */
Whide (w)
register Win *w;
{
	if (w -> w_status & WHIDDEN)/* Already hidden */
		return 0;
	WErase (w);		/* Erase from display */
	w -> w_status |= WHIDDEN;
	WRemoveCoverList (w);	/* Uncover all windows w covered */
	return 0;
}

/* Unhide window w */
Wunhide (w)
register Win *w;
{
	if ((w -> w_status & WHIDDEN) == 0)/* Not hidden */
		return 0;
	w -> w_status &= ~WHIDDEN;
	WComputeCover (w);
	w -> w_status |= WDUMP;
	return 0;
}
