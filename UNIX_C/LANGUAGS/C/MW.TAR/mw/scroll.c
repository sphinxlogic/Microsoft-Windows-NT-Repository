#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Scroll window w according to its w->w_popup */
Wscroll (w)
register Win *w;
{
    if (w -> w_popup == 0) {/* Means, wrap cursor to top & clr line */
	w -> w_cursor.row = 0;
	w -> w_cursor.col = 0;
	WFixCursor (w);
	return Wclearline (w, 2);/* Clear line containing cursor */
    }
    return Wrelscroll (w, w -> w_popup, 0, 0);
}

/* Relative scroll window w by rows, cols */
/* If cwin is set cursor sticks to window rather than buffer */
Wrelscroll (w, rows, cols, cwin)
register Win *w;
int rows, cols, cwin;
{
    register Buf *b;
    register Ch *cp, *ct;

    if (rows == 0 && cols == 0)
	return 0;
    b = w -> w_textbuf;
    w -> w_bstart.row += rows;
    w -> w_bstart.col += cols;
    if (w -> w_bstart.row < 0) {
	/* Window has moved above buffer; "create space" at top */
	cp = b -> b_contents +
	    (b -> b_nrows + w -> w_bstart.row) * b -> b_ncols;
	ct = b -> b_contents +
	    b -> b_nrows * b -> b_ncols;
	while (cp > b -> b_contents)
	    (--ct) -> ch_all = (--cp) -> ch_all;
	while (ct > b -> b_contents)
	    (--ct) -> ch_all = ' ' | (w -> w_mode << NBPB);
	w -> w_bstart.row = 0;
	b -> b_nmodw = -1;
    }
    else if (w -> w_bstart.row + w -> OYE > b -> b_nrows) {
	/* Window has moved below buffer; "create space" at bottom */
	register Ch *end;
	register n = w -> w_bstart.row + w -> OYE - b -> b_nrows;
	ct = b -> b_contents;
	cp = b -> b_contents + n * b -> b_ncols;
	end = b -> b_contents + b -> b_nrows * b -> b_ncols;
	while (cp < end)
	    ct++ -> ch_all = cp++ -> ch_all;
	while (ct < end)
	    ct++ -> ch_all = ' ' | (w -> w_mode << NBPB);
	w -> w_bstart.row = b -> b_nrows - w -> OYE;
	b -> b_nmodw = -1;
    }
    if (w -> w_bstart.col < 0) {
	cols -= w -> w_bstart.col;
	w -> w_bstart.col = 0;	/* CHEAP! */
    }
    if (w -> w_bstart.col + w -> OXE > b -> b_ncols) {
	cols += b -> b_ncols - w -> w_bstart.col - w -> OXE;
	w -> w_bstart.col = b -> b_ncols - w -> OXE;
    }
    if (!cwin) {		/* Then make cursor stick to buffer */
	w -> w_cursor.row -= rows;
	w -> w_cursor.col -= cols;
	if (w -> w_cursor.row < 0)
	    w -> w_cursor.row = 0;
	else if (w -> w_cursor.row >= w -> IYE)
	    w -> w_cursor.row = w -> IYE - 1;
	if (w -> w_cursor.col < 0)
	    w -> w_cursor.col = 0;
	else if (w -> w_cursor.col >= w -> IXE)
	    w -> w_cursor.col = w -> IXE - 1;
    }
    WFixCursor (w);
    w -> w_status |= WDUMP;
    MajorUpdate = 1;
    return 0;
}
