#include "win.h"
#include "display.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Change the size of an existing window */
Wsize (w, xext, yext)
register Win *w;
register xext, yext;
{
	register Buf *b;
	register Ch *c;

	if (xext < 1 || yext < 1)
		return -1;
	if (w -> OXO + xext > ScreenWidth || w -> OYO + yext > ScreenLength)
		return -1;
	b = w -> w_textbuf;
	if (b -> b_ncols < xext || b -> b_nrows < yext) {
		if (Wsetbuf (w, xext, yext))
			return -1;
	}
	if ((w -> w_status & WHIDDEN) == 0) {
		WErase (w);		/* Erase visible portions */
		WRemoveCoverList (w);	/* Uncover everything */
	}

	/* Get new winbuf */
	c = (Ch *) malloc (sizeof (Ch) * xext * yext);
	if (c == 0) {
		if ((w -> w_status & WHIDDEN) == 0)
			WComputeCover (w);
		return -1;
	}
	free (w -> w_winbuf);
	w -> w_winbuf = c;
	w -> w_outside.xextent = xext;	/* Change size */
	w -> w_outside.yextent = yext;

	/* If the window has grown such that the bottom of the winbuf sticks
	   out over the bottom of the textbuf, it must be moved upward.  The
	   distance to be moved is [real_bstart - max_bstart], or, in the y
	   direction, [w -> w_bstart.row - (b -> b_nrows - yext)]. */
	if (w -> w_bstart.row + yext > b -> b_nrows) {
		/* Want cursor to stick to buffer, so must move down
		   relative to window */
		w -> w_cursor.row += w -> w_bstart.row - b -> b_nrows + yext;
		w -> w_bstart.row =  b -> b_nrows - yext;/* max_bstart.row */
		MajorUpdate = 1;
	}
	/* Similarly for the x direction */
	if (w -> w_bstart.col + xext > b -> b_ncols) {
		w -> w_cursor.col += w -> w_bstart.col - b -> b_ncols + xext;
		w -> w_bstart.col =  b -> b_ncols - xext;/* max_bstart.col */
	}

	/* Make inside whole thing (sigh) */
	for (c = w -> w_winbuf + xext * yext; c > w -> w_winbuf;)
		(--c) -> ch_all = ' ' | (WBUF<<NBPB);
	WFixCursor (w);
	if ((w -> w_status & WHIDDEN) == 0)
		WComputeCover (w);	/* Recompute cover with new size */
	return Wsetmargins (w, 0, 0, xext, yext);
}
