/* Copyright (c) 1983 University of Maryland Computer Science Department */
/* Terminal control module for Tektronix 4025 */

/*	Tektronix makes great scopes, but their terminals are another thing */
/*	entirely.  This was written so no one else will have to waste their */
/*	time on it.	-- TVR/Feb81					    */
/*	Rewritten from Concept-100 driver (which was copyright 1981,1980 by */
/*	James Gosling)							    */
/* Modified: 26 Feb 81 (JCMogul) - defines null HLmode rather than as zero */
/* Major bug fixes sometime 1982 Chris Torek */

#include <stdio.h>
#include "Trm.h"

static
int	curX, curY;

static
char	tekesc;

static
enum IDmode { m_insert = 1, m_overwrite = 0 }
	CurMode;

static
INSmode (new)
enum IDmode new; {
	CurMode = new;
};

static
inslines (n) register n; {
    /* Stupid TEK4025 does insert AFTER cursor.  Can't insert at line 1!!! */
    /* We compensate by putting line 1 offscreen. Sigh...  See 'topos'     */
    /* Worse yet: the cursor is left on the LAST of the inserted lines! ACT*/
    putchar (013);
    tek ("ILI", n);
    if (curY == 1) printf ("%cRUP\r", tekesc);
    curY += n-1;
};

static
dellines (n) register n; {
    tek ("DLI", n);
/* ACT Now must clear any display that might have come up from below */
    topos (35 - n, 1);
    tek ("DLI", 50);
};

static
writechars (start, end)
register char	*start,
		*end; {
    if (CurMode == m_insert) {
	printf ("%cICH\r",tekesc);
    }
    while (start <= end) {
	putchar (*start++);
	curX++;
    }
    if (CurMode == m_insert) {
	printf("%cICH\r",tekesc);
    }
};

static
blanks (n) {
    /* See 'writechars' for remarks about insert mode. */
    if (CurMode == m_insert) {
	printf ("%cICH\r",tekesc);
    }
    while (--n >=0) {
	putchar (' ');
	curX++;
    }
    if (CurMode == m_insert) {
	printf("%cICH\r", tekesc);
    }
};

static
topos (row, column) register row, column; {
    /* CAUTION: Because Insert Line won't work on the top line, display is */
    /*		used with screen rolled up one line, so logical line 1 is  */
    /*		the terminal's line 2.  But either due to a firmware bug   */
    /*		(or brain damage in the microprogrammer), it can't do abs. */
    /*		cursor positioning anyway.  However, it can go move the    */
    /*		cursor by a numeric amount.				   */
    if (curX > 80) {
	curX = curX - 80;
	curY++;
    }
    if (curY == row && curX == column) return;

    /* I couldn't get LF to do the right thing, although i'm not sure	*/
    /* why.  Maybe you know more than i.  TVR/Feb81			*/
    if (row < curY) {
	if (row < curY - 7) tek ("UP", curY-row);
	else while (row < curY) putchar (013), --curY;
    }
    if (row > curY) tek ("DOW", row-curY);

    if (column > curX) tek ("RIG", column-curX);
    else if (column == 1) putchar ('\r');
    else if (column < curX - 7) tek ("LEF", curX-column);
    else while (column < curX) putchar(010), curX--;
    curX = column;
    curY = row;
};

static
init () {
    return 0;
};

static
reset () {
	if (tekesc != 28) {
		tekesc = 28;
		printf("\033COM 28\r");	/* Init cmd char */
	}
	printf(
"\34LEA P7 26\34LEA P8 16\34LEA P4 2\34LEA P6 6\34LEA P1 27 90\34LEA P2 14\r"
	);			/* Teach it some pad keys */
	wipescreen();
	CurMode = m_overwrite;
};

static
cleanup () {
    if (tekesc == 28) {
	tekesc = 27;
	printf("\34COM 27\r");	/* Restore cmd char -ACT */
	printf("\33LEA P7\33LEA P8\33LEA P4\33LEA P6\33LEA P1\33LEA P2\r");
    }
};

static
wipeline (i,j) register j; {
    register cnt = j - curX + 1;
    if (cnt < 1) return;
    if (curX == 1) {
	tek ("DLI", 1);
	inslines (1);
    }
    else {
	register oldcol = curX;
        while (--cnt >= 0) { putchar(' '); ++curX; };
        topos (curY, oldcol);
    }
};

static
wipescreen () {
    printf ("%cERA%cDOW 35%cUP 34\r",tekesc,tekesc,tekesc);
    curX = curY = 1;
};

static
delchars (n) {
    tek ("DCH", n);
};

static
tek (str, cnt) char *str; {
    printf ("%c%s", tekesc, str);
    if (cnt != 1) printf (" %d", cnt);
    putchar ('\r');
};

TrmTEK4025 () {
    W_tt.t_INSmode = INSmode;
    W_tt.t_modes = NoOperation;
    W_tt.t_inslines = inslines;
    W_tt.t_dellines = dellines;
    W_tt.t_blanks = blanks;
    W_tt.t_init = init;
    W_tt.t_cleanup = cleanup;
    W_tt.t_wipeline = wipeline;
    W_tt.t_wipescreen = wipescreen;
    W_tt.t_topos = topos;
    W_tt.t_reset = reset;
    W_tt.t_delchars = delchars;
    W_tt.t_writechars = writechars;
    W_tt.t_window = 0;
    W_tt.t_ILmf = 1;
    W_tt.t_ILov = 9;
    W_tt.t_ICmf = 1;
    W_tt.t_ICov = 4;
    W_tt.t_DCmf = 2;
    W_tt.t_DCov = 0;
    W_tt.t_length = 34;
    W_tt.t_width = 80;
    return 0;
};
