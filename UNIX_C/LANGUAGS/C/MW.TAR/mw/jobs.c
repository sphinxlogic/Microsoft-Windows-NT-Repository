#include <signal.h>

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/*
 * Jobs library emulator using old signal mechanism
 *
 * 26 March 1983 ACT
 *
 * held_sigs	  == the signals held via sighold()
 * executing_sigs == the signals held because the signal handler is already
 *		     running
 * pending_sigs   == the signals pending, for sigrelse() or whatever
 *
 * 25 May 1985 ACT: installed fixes from zinfandel!ed: sigset returns
 * bogus value on first call (or after calls to signal); sigignore was
 * missing a "return".  Also wrote sigpause, for what it's worth (very
 * little).
 */

static long held_sigs, pending_sigs, executing_sigs;
static int (*sigfuncs[32])();
int sigcatch();

int (*sigset (signo, f))()
register int signo;
register int (*f)();
{
	int (*rv)() = sigfuncs[signo];
	int (*oldsig)();

	if (f == SIG_DFL || f == SIG_IGN) {	/* these are just zap-em-ins */
		sigfuncs[signo] = f;
		oldsig = signal (signo, f);
		pending_sigs &= ~(1<<signo);
	}
	else {
		sigfuncs[signo] = f;
		oldsig = signal (signo, sigcatch);
				/* sigcatch() does the real work */
	}
	if (oldsig != sigcatch)	/* rv invalid, someone changed things */
		return oldsig;	/* (or first time through) */
	return rv;
}

int (*sigignore (signo))()
int signo;
{
	return sigset (signo, SIG_IGN);
}

/* This is easy too ... */
sighold (signo)
int signo;
{
	held_sigs |= 1 << signo;
}

sigrelse (signo)
int signo;
{
	register int sigbit = 1 << signo;

	held_sigs &= ~sigbit;
	if (pending_sigs & sigbit)
		sigcatch (signo);	/* sigcatch() does the real work */
}

/* RACE CONDITIONS ABOUND! */
/* This code assumes that if a second signal occurs it will be during
   the user's function.  That isn't quite true, but... that's the way
   it goes. */
static
sigcatch (signo)
register int signo;
{
	register int sigbit;

	signal (signo, sigcatch);
	sigbit = 1 << signo;
resig:
	/* If it's already executing, or if the user asked to hold it,
	   then don't call the function yet. */
	if ((executing_sigs|held_sigs) & sigbit) {
		pending_sigs |= sigbit;
		return;
	}
	pending_sigs &= ~sigbit;	/* Clear pending signals */
	executing_sigs |= sigbit;	/* Say this one is executing */
	(*sigfuncs[signo]) (signo);	/* Call user function */
	executing_sigs &= ~sigbit;	/* Not executing anymore */
	if (pending_sigs & sigbit)
		goto resig;
}

/* Atomically release signal signo and wait for (any) signal.  We can't
   really do this, but we'll pretend.... */
sigpause (signo)
int signo;
{
	register int sigbit = 1 << signo;

	held_sigs &= ~sigbit;
	if (pending_sigs & sigbit) {
		sigcatch (signo);
		return;
	}
	pause ();
}
