#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Move window w to back (bottom), i.e., make it covered by all other
   windows.  If hidden, remains hidden. */
Wback (w)
register Win *w;
{
	register Win *p, *pp;

	if (w -> w_next == 0)	/* Then already in back */
		return 0;

	/* Find the back window */
	for (p = w; p -> w_next; p = p -> w_next)
		;

	/* Find the window just before w, and unlink w */
	if (w == WinList)
		WinList = w -> w_next;
	else {
		for (pp = WinList; pp -> w_next != w; pp = pp -> w_next)
			;
		pp -> w_next = w -> w_next;
	}

	/* Now link w in at end of window list */
	w -> w_next = 0;
	p -> w_next = w;

	/* Recompute covering relationships if necessary */
	if ((w -> w_status & WHIDDEN) || (w -> w_status & WCOVERING) == 0)
		return 0;
	WRemoveCoverList (w);	/* Unmark w */
	WComputeCover (w);	/* Compute windows covering w */
	return 0;
}
