#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Bring window w to front (top), i.e., completely uncover it */
/* If hidden, remains hidden */
Wfront (w)
register Win *w;
{
	register Win *p;

	/* Is w already front? */
	if (WinList == w)
		return 0;

	/* Move w to top of window list */
	for (p = WinList; p -> w_next != w; p = p -> w_next)
		;
	p -> w_next = w -> w_next;
	w -> w_next = WinList;
	WinList = w;

	/* If hidden, or not covered, then our work is done */
	if ((w -> w_status & WHIDDEN) || (w -> w_status & WCOVERED) == 0)
		return 0;
	WRemoveCoverList (w);	/* Unmark w, plus some extra work... */
	WComputeCover (w);	/* Compute windows w covers */
	w -> w_status |= WDUMP;
	return 0;
}
