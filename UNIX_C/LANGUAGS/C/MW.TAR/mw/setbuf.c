#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Set the amount of buffering on a window */
Wsetbuf (w, bcols, brows)
Win *w;
{
	register Buf *b = w -> w_textbuf;
	register Ch *c, *cp, *ct;
	register i, j;

	if (b -> b_nrows > brows)
		brows = b -> b_nrows;/* Never shrink a buffer */
	if (b -> b_ncols > bcols)
		bcols = b -> b_ncols;
	if (b -> b_nrows == brows && b -> b_ncols == bcols)
		return 0;	/* Nothing to do */
	c = (Ch *) malloc (sizeof (Ch) * brows * bcols);
	if (c == 0)
		return -1;

	/* Copy old contents to new buffer */
	cp = b -> b_contents;
	ct = c;
	for (j = 0; j < b -> b_nrows; j++) {
		for (i = 0; i < b -> b_ncols; i++)
			ct++ -> ch_all = cp++ -> ch_all;
		cp += b -> b_ncols - i;
		for (; i < bcols; i++)
			ct++ -> ch_all = ' ';
	}
	for (; j < brows; j++)
		for (i = 0; i < bcols; i++)
			ct++ -> ch_all = ' ';

	free (b -> b_contents);	/* Discard old buffer */
	b -> b_contents = c;
	b -> b_nrows = brows;
	b -> b_ncols = bcols;
	WFixCursor (w);
	return 0;
}
