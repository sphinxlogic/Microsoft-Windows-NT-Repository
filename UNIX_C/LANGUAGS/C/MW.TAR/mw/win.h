/* Copyright (c) 1983 University of Maryland Computer Science Department */

#define	NBPB	8		/* Number of bits per byte */

/* N.B.: this works in Reiser CPP even if "pyr" not defined... what about
   others? */
#if pyr || sun || mc68000 || mc68000a
/* this one is the "Big-Endian" byte order version */
union chr {
	struct {
		char mode;
		char ch;	/* NOTE: this is known to be low byte */
	} ch_two;
	short ch_all;
};

#else
#if vax
/* this one is the "Little-Endian" byte order version */
union chr {
	struct {
		char ch;	/* NOTE: this is known to be low byte */
		char mode;
	} ch_two;
	short	ch_all;
};

#else vax
Sorry, I don't know about this machine.  Please fix win.h.
#endif vax

#endif pyr || sun || mc68000 || mc68000a

/* ch_all is set to ' ' or (' '|(WBUF<<NBPB)) so Char must be low byte, and
   Mode must be high byte. */

#define	Char	ch_two.ch
#define	Mode	ch_two.mode

typedef struct {
	int	row, col;
} Pos;

typedef struct {
	int	xorigin, yorigin;
	int	xextent, yextent;
} Rect;

struct coverlist {
	struct coverlist *c_next;
	struct window *c_top,	/* Window on top */
		      *c_bot;	/* Window on bottom */
	Rect	c_area;		/* Area of intersection */
};

typedef union chr		Ch;

struct buffer {
	Ch	*b_contents;
	int	b_nwins;	/* Number of windows using this buffer */
	int	b_nrows,	/* Number of rows of text */
		b_ncols;	/* Number of cols */
	Pos	b_cursor;	/* Buffer cursor (WBputc ()) */
	int	b_nmodw;	/* If zero buffer not modified [see disp.c] */
};

typedef struct coverlist	Cov;
typedef struct buffer		Buf;
typedef struct window		Win;

struct window {
	Win	*w_next;	/* Next window in list */
	int	w_id;		/* Window ID */
	Rect	w_outside;	/* Describes whole window */
	Rect	w_inside;	/* Describes inner part of window */
	Buf	*w_textbuf;	/* Pointer to buffer containing text */
	Ch	*w_winbuf;	/* Pointer to window chars */
	Pos	w_bstart;	/* Coordinates of win projection on w_buf */
	Pos	w_cursor;	/* Coordinates of cursor */
	Pos	w_auxcursor;	/* Coordinates of aux cursor */
	Ch	*w_bcursor;	/* Cursor ptr into text [w_textbuf] */
	Ch	*w_wcursor;	/* Cursor ptr into window [w_auxcursor] */
	int	w_popup;	/* Number of lines to scroll */
	char	w_mode;		/* Current text-writing mode */
	char	w_status;	/* Status bits */
};

#define	OXO	w_outside.xorigin
#define	OXE	w_outside.xextent
#define	OYO	w_outside.yorigin
#define	OYE	w_outside.yextent

#define	IXO	w_inside.xorigin
#define	IXE	w_inside.xextent
#define	IYO	w_inside.yorigin
#define	IYE	w_inside.yextent

/* Mode bits (w_mode, ch_two.mode) */
#define	WBOLD	0x01		/* Bold */
#define	WULINE	0x02		/* Underlined */
#define	WBLINK	0x04		/* Blinking */
#define	WINVERSE 0x08		/* Inverse video */
#define	MODEMASK (WBOLD|WULINE|WBLINK|WINVERSE)  /* [all chars] */
#define	WINVIS	0x10		/* Invisible [windows only] */
#define	WBUF	0x20		/* From buffer [windows only] */

/* Status bits (w_status) */
#define	WWRAPOFF 0x01		/* Auto-wrap is off */
#define	WHIDDEN  0x02		/* Window is hidden */
#define	WNEWLINE 0x04		/* \r, \n act like \r\n */
#define	WCURSOR  0x08		/* Cursor is hidden */
#define	WDUMP	 0x10		/* Window contents need dumping to screen */
#define	WCOVERED 0x20		/* Window is covered */
#define	WCOVERING 0x40		/* Window is covering others */
#define	WBORDERED 0x80		/* Window has been bordered (framed) */

extern Win *WinList;		/* Base of window list */
extern Win *CurWin;		/* Current window */
extern Cov *WCovList;		/* Base of coverings list */
extern Rect WBox;		/* Information on the (single) box */
extern int MajorUpdate;		/* True iff maximum optimization wanted */
extern int SigMagic;		/* True iff sigset() magic is wanted */
extern long InputPending;	/* True iff keyboard input is pending */
extern int LastRedisplayPaused;	/* True iff last redisplay paused */
extern int ScreenGarbaged;	/* True iff screen contents uncertain */
extern int WBoxActive;		/* True iff box is active */
extern int WSetRealCursor;	/* True iff want terminal cursor positioning */
extern int WRCurRow;		/* Set real cursor to this row, */
extern int WRCurCol;		/* ... this col [both 0 origin] */
extern int VisibleBell;		/* True iff want ^G to flash */
extern int WindowsActive;	/* Set while windows (stty settings) active */

#define	Max(a,b)	((a)>(b)?(a):(b))
#define	Min(a,b)	((a)<(b)?(a):(b))
