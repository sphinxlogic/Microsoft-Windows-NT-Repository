#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Insert n columns before cursor in window w */
Winscols (w, n)
register Win *w;
int n;
{
	register Buf *b;
	register Ch *cp, *ct;
	register j;
	int i, blank, nm;

	if (n < 0)
		return -1;
	if (n == 0)
		return 0;
	if (n + w -> w_cursor.col > w -> IXE)
		n = w -> IXE - w -> w_cursor.col;
	blank = ' ' | (w -> w_mode << NBPB);
	b = w -> w_textbuf;
	nm = w -> IXE - n - w -> w_cursor.col;

	/* w->w_winbuf */
	ct = w -> w_winbuf + w -> IYO * w -> OXE + w -> IXO + w -> IXE;
	cp = ct - n;
	for (i = 0; i < w -> IYE; i++) {
		for (j = 0; j < nm; j++) {
			(--ct) -> Char = (--cp) -> Char;
			ct -> Mode &= WINVIS;
			ct -> Mode |= cp -> Mode & ~WINVIS;
		}
		ct += w -> OXE + j;
		cp += w -> OXE + j;
	}
	ct = w -> w_winbuf + w -> IYO * w -> OXE +
		w -> IXO + w -> w_cursor.col;
	for (i = 0; i < w -> IYE; i++) {
		for (j = 0; j < n; j++) {
			ct -> Char = ' ';
			ct -> Mode &= WINVIS;
			ct++ -> Mode |= WBUF;
		}
		ct += w -> OXE - j;
	}
	/* w->w_textbuf */
	ct = b -> b_contents +
		(w -> IYO + w -> w_bstart.row) * b -> b_ncols +
		w -> IXO + w -> w_bstart.col + w -> IXE;
	cp = ct - n;
	for (i = 0; i < w -> IYE; i++) {
		for (j = 0; j < nm; j++)
			(--ct) -> ch_all = (--cp) -> ch_all;
		ct += b -> b_ncols + j;
		cp += b -> b_ncols + j;
	}
	ct = b -> b_contents +
		(w -> IYO + w -> w_bstart.row) * b -> b_ncols +
		w -> IXO + w -> w_bstart.col + w -> w_cursor.col;
	for (i = 0; i < w -> IYE; i++) {
		for (j = 0; j < n; j++)
			ct++ -> ch_all = blank;
		ct += b -> b_ncols - j;
	}
	w -> w_status |= WDUMP;
	b -> b_nmodw = -1;
	return 0;
}
