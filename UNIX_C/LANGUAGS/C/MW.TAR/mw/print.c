#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Print C style string into window w */
/* PRINTS TO w->w_textbuf */
Wputs (s, w)
register char *s;
register Win *w;
{
	while (*s)
		Wputc (*s++, w);
	return 0;
}

/* Put a char into window w. */
/* CHAR c REALLY GOES INTO w->w_textbuf */
Wputc (c, w)
register c;
register Win *w;
{
	int orow = w -> w_cursor.row + w -> IYO,
	    ocol = w -> w_cursor.col + w -> IXO;

	switch (c &= 0x7f) {
	case '\n':		/* Newline */
nl:
		w -> w_cursor.row++;
		if (w -> w_cursor.row >= w -> w_inside.yextent)
			Wscroll (w);
		else {
			w -> w_bcursor += w -> w_textbuf -> b_ncols;
			if (w -> w_popup == 0)
				Wclearline (w, 2);
		}
		if (w -> w_status & WNEWLINE)
			goto cr;
		break;
	case '\r':		/* Carriage return */
		if (w -> w_status & WNEWLINE)
			goto nl;
cr:
		w -> w_bcursor -= w -> w_cursor.col;
		w -> w_cursor.col = 0;
		break;
	case '\b':		/* Backspace */
		if (w -> w_cursor.col) {
			w -> w_cursor.col--;
			w -> w_bcursor--;
		}
		break;
	case '\t':		/* Tab */
		c = (w -> w_cursor.col / 8 + 1) * 8;
		if (c >= w -> w_inside.xextent)
			c = w -> w_inside.xextent - 1;
		w -> w_bcursor += c - w -> w_cursor.col;
		w -> w_cursor.col = c;
		break;
	case '\7':		/* Bell */
		Ding ();
		return 0;
	default:
		if (c < 0x20 || c == 0x7f)/* Control char or DEL */
			return 0;
		w -> w_bcursor++ -> ch_all = c | (w -> w_mode << NBPB);
		orow = w -> w_cursor.row + w -> IYO;
		ocol = w -> w_cursor.col + w -> IXO;
		w -> w_cursor.col++;
		if (w -> w_cursor.col >= w -> w_inside.xextent)
			if (w -> w_status & WWRAPOFF) {
				w -> w_cursor.col--;
				w -> w_bcursor--;
			} else {
				w -> w_cursor.col = 0;
				w -> w_cursor.row++;
				if (w -> w_cursor.row >= w -> IYE)
					Wscroll (w);
				else {
					WFixCursor (w);
					if (w -> w_popup == 0)
						Wclearline (w, 2);
				}
			}
		break;
	}
	if (c == 0 || w -> w_status & (WDUMP|WHIDDEN)
			|| w -> w_textbuf -> b_nwins > 1) {
		w -> w_status |= WDUMP;
		w -> w_textbuf -> b_nmodw = -1;
	}
	else {
		WDispPut (w, orow, ocol, 0);
		WDispPut (w, w -> w_cursor.row + w -> IYO,
			     w -> w_cursor.col + w -> IXO,
			     w -> w_status & WCURSOR ? 0 : 1);
	}
	return 0;
}

/* Fix cursor pointers (w_bcursor, w_wcursor) */
WFixCursor (w)
register Win *w;
{
    register Buf *b = w -> w_textbuf;

    w -> w_bcursor =
	b -> b_contents +
	(w -> w_cursor.row + w -> w_bstart.row + w -> IYO) * b -> b_ncols +
	(w -> w_cursor.col + w -> w_bstart.col + w -> IXO);
    w -> w_wcursor =
	w -> w_winbuf + w -> w_auxcursor.row * w -> OXE +
	w -> w_auxcursor.col;
}
