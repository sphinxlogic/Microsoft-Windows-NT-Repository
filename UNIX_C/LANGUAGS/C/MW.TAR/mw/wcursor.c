#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Position the window cursor, within the window */
WWcursor (w, row, col)
register Win *w;
register row, col;
{
	w -> w_cursor.row = Min (Max (row, 0), w -> IYE - 1);
	w -> w_cursor.col = Min (Max (col, 0), w -> IXE - 1);
	WFixCursor (w);
	if ((w -> w_status & WCURSOR) == 0)
		w -> w_status |= WDUMP;
	return 0;
}
