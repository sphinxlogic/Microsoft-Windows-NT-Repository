/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Ultra-hot screen management package
 *		James Gosling, January 1980
 * ACT 11-Nov-1982 modified for window package
 */

#include "Trm.h"

#define ScreenLength (W_tt.t_length)
#define ScreenWidth (W_tt.t_width)

int	ScreenGarbaged,		/* true => screen content is uncertain. */
	WDCurrentLine,		/* current line for writing to the virtual
				 * screen. */
#ifdef	DEBUG
	IDdebug,		/* line insertion/deletion debug switch */
	RDdebug,		/* line redraw debug switch */
#endif	DEBUG
	WDleft;			/* number of columns left on the current
				 * line of the virtual screen. */
Ch
	*WDcursor;		/* pointer into a line object, indicates
				 * where to put the next character */

/* 'dsputc' places a character at the current position on the display,
 * the character must be a simple one, taking up EXACTLY one position on
 * the screen.  ie. tabs and \n's shouldn't be passed to dsputc. */
#define dsputc(c,m) (WDleft--,\
		     WDcursor++ -> ch_all = (((m)&MODEMASK)<<NBPB) | ((c)&0377))

/* 'dspxor' exclusive-or's a mode at the current postion on the display */
#define	dspxor(m)   (WDleft--, WDcursor++ -> Mode ^= m)

/* 'dspskip' skips over n characters on the display */
#define	dspskip(n)  (WDleft -= (n), WDcursor += (n))

/* 'setpos' positions the cursor at position (row,col) in the virtual
 * screen
setpos(row,col);

/* 'WDUpdateScreen' updates the physical screen, assuming that it looks
 * like the 'CurrentScreen', making it look like the 'DesiredScreen'.
 * If 'hard' is true then the difficult line I/D algorithm will be used;
 * otherwise no line I/D will be performed.
WDUpdateScreen(hard);

 */
