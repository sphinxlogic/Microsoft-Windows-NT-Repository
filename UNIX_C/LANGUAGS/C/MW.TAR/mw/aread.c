#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Return char from winbuf at aux cursor, advancing aux cursor */
/* If charonly set returns only char (not mode<<NBPB | char) */
WAread (w, charonly)
register Win *w;
int charonly;
{
	int rv = charonly ? w -> w_wcursor -> Char : w -> w_wcursor -> ch_all;
	w -> w_wcursor++;
	w -> w_auxcursor.col++;
	if (w -> w_auxcursor.col >= w -> OXE) {
		w -> w_auxcursor.col = 0;
		w -> w_auxcursor.row++;
		if (w -> w_auxcursor.row >= w -> OYE) {
			w -> w_auxcursor.row = 0;
			w -> w_wcursor = w -> w_winbuf;
		}
	}
	return rv;
}
