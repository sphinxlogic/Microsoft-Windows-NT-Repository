#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Clear one line of buffer (w->w_winbuf not involved) */
WBclearline (w, howto)
Win *w;
int howto;
{
	register Buf *b = w -> w_textbuf;
	register Ch *c, *end;
	register blank = ' ' | (w -> w_mode << NBPB);

	c = b -> b_contents + b -> b_cursor.row * b -> b_ncols;
	switch (howto) {
	case 0:			/* Cursor to end of line */
	default:
		end = c + b -> b_ncols;
		c += b -> b_cursor.col;
		break;
	case 1:			/* Beginning of line to cursor */
		end = c + b -> b_cursor.col;
		break;
	case 2:			/* Entire line */
		end = c + b -> b_ncols;
		break;
	}
	while (c < end)
		c++ -> ch_all = blank;
	b -> b_nmodw = -1;
	return 0;
}
