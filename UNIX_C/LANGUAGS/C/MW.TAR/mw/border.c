#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Border a window with specified chars */
Wborder (w, ulc, top, urc, left, right, llc, bottom, lrc)
register Win *w;
{
	register Ch *c = w -> w_winbuf;
	register i;

	/* Make sure there's room at the edges for the border chars; if not,
	   use setmargins to make 'em */
	if (w -> IXO < 1 || w -> IXO + w -> IXE == w -> OXE ||
	    w -> IYO < 1 || w -> IYO + w -> IYE == w -> OYE)
		if (Wsetmargins (w, 1, 1, w -> OXE - 2, w -> OYE - 2))
			return -1;

	/* Upper left corner */
	c -> Mode &= ~(MODEMASK|WBUF);
	c -> Mode |= w -> w_mode;
	c++ -> Char = ulc;

	/* Top */
	for (i = 2; i < w -> w_outside.xextent; i++) {
		c -> Mode &= ~(MODEMASK|WBUF);
		c -> Mode |= w -> w_mode;
		c++ -> Char = top;
	}

	/* Upper right corner */
	c -> Mode &= ~(MODEMASK|WBUF);
	c -> Mode |= w -> w_mode;
	c++ -> Char = urc;

	/* Left and right sides */
	for (i = 2; i < w -> w_outside.yextent; i++) {
		c -> Mode &= ~(MODEMASK|WBUF);
		c -> Mode |= w -> w_mode;
		c -> Char = left;
		c += w -> w_outside.xextent - 1;
		c -> Mode &= ~(MODEMASK|WBUF);
		c -> Mode |= w -> w_mode;
		c++ -> Char = right;
	}

	/* Lower left corner */
	c -> Mode &= ~(MODEMASK|WBUF);
	c -> Mode |= w -> w_mode;
	c++ -> Char = llc;

	/* Bottom */
	for (i = 2; i < w -> w_outside.xextent; i++) {
		c -> Mode &= ~(MODEMASK|WBUF);
		c -> Mode |= w -> w_mode;
		c++ -> Char = bottom;
	}

	/* Lower right corner */
	c -> Mode &= ~(MODEMASK|WBUF);
	c -> Mode |= w -> w_mode;
	c -> Char = lrc;
	w -> w_status |= WDUMP|WBORDERED;
	return 0;
}
