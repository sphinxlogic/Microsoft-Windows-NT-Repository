/* Block copy from from to to, count bytes */
/* N.B.: THIS FILE SHOULD NOT BE USED IN 4.2BSD */

/* Copyright (c) 1983 University of Maryland Computer Science Department */

#if vax

/* ARGSUSED */
bcopy (from, to, count)
char *from, *to;
int count;
{
	asm("	movc3	12(ap),*4(ap),*8(ap)");
}

#else

bcopy (from, to, count)
register char *from, *to;
register count;
{
	while (--count>=0) *to++ = *from++;
}

#endif vax
