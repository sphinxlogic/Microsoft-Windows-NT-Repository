/* Copyright (c) 1983 University of Maryland Computer Science Department */
/* terminal control module for Ann Arbor Ambassadors */

/* ACT 16-Oct-1982: Combined Gosling's version and mine to write this one */

/* ACT 10-Nov-1982 modified for windows */

#include <stdio.h>
#include "Trm.h"

static
int	curX, curY, Baud, CurModes, DesModes, Tcap;

static
float	BaudFactor;

static
enum IDmode { m_insert = 1, m_overwrite = 0} DesiredMode;

static
INSmode (new)
enum IDmode new; {
	DesiredMode = new;
}

static
modes (des) {
	DesModes = des;
}

static
Setmodes (OverRide) {
	register Des = OverRide ? 0 : DesModes;
	static char *mds[16] = { "0", "0;1", "0;4", "0;1;4", "0;5",
		"0;1;5", "0;4;5", "0;1;4;5", "0;7", "0;1;7", "0;4;7",
		"0;1;4;7", "0;5;7", "0;1;5;7", "0;4;5;7", "1;4;5;7" };

	if (Des == CurModes)
		return;
	printf ("\033[%sm", mds[Des]);
	CurModes = Des;
}

static
inslines (n) {
    Setmodes (1);
    printf (n <= 1 ? "\033[L" : "\033[%dL", n);
    pad (60-curY, 0.80);
}

static
dellines (n) {
    Setmodes (1);
    printf (n <= 1 ? "\033[M" : "\033[%dM", n);
    pad (60-curY, 0.80);
    if (W_tt.t_length == 60)
	return;
    if (Baud < 4800) {		/* yeesh! */
	topos (W_tt.t_length-n+1, 1);
	printf ("\033[J");
	pad (60-curY, 8.00);
    }
    else {
	register i;
	for (i=W_tt.t_length-n+1; i<=W_tt.t_length; i++) {
	    topos (i, 1);
	    wipeline ();
	}
    }
}

static
writechars (start, end)
register char *start, *end; {
    register char *p;
    register runlen;

    Setmodes (0);
    if (DesiredMode == m_insert) {
	printf ("\033[%d@", end - start + 1);
	pad (80-curX, 0.16);
    }
    while (start <= end) {
	if (start+5 < end && *start == start[1]) {
	    runlen = 0;
	    p = start;
	    do runlen++; while (*++start == *p && start <= end);
	    if (runlen > 5) {
		putchar (*p);
		printf ("\033[%db", runlen - 1);
		pad (runlen-1, 1.00);
		curX += runlen;
	    }
	    else {
		start = p;
		goto normal;
	    }
	}
	else {
normal:
	    putchar (*start++);
	    curX++;
	}
    }
}

static
blanks (n) register n; {
    if (n > 0) {
	Setmodes (0);
	curX += n;
	if (DesiredMode == m_insert) {
	    printf ("\033[%d@", n);
	    pad (80-curX, 0.16);
	}
	if (n > 5) {
	    printf (" \033[%db", n-1);
	    pad (n-1, 1.00);
	}
	else while (--n >= 0) putchar (' ');
    }
}

static
pad (n, f)
float f; {
    register	k = n * f * BaudFactor;
    while (--k >= 0)
	putchar (0);
}

static
topos (row, column) register row, column; {
    if (curY == row) {
	if (curX == column)
	    return;
	if (curX == column + 1) {
	    putchar (010);
	    goto done;
	}
	printf ("\033[%d`", column);
	goto done;
    }
    if (curY+1 == row && (column == 1 || column == curX)) {
	if (column != curX) putchar (015);
	putchar (012);
	goto done;
    }
    if (row == 1 && column == 1) {
	printf ("\033[f");
	goto done;
    }
    if (column == 1) {
	printf ("\033[%df", row);
	goto done;
    }
    if (row == 1) {
	printf ("\033[;%df", column);
	goto done;
    }
    printf ("\033[%d;%df", row, column);
done:
    curX = column;
    curY = row;
    pad (1, 1.00);
}

static
init (BaudRate) {
    BaudFactor = BaudRate / 10000.;
    Baud = BaudRate;
    return 0;
}

static
reset () {
    printf ("\033[>30;33;37;38;39l\033[>52h");	/* RM(ZDBM,ZWFM,ZAXM,ZAPM,
						      ZSSM) */
		    				/* SM(ZMKM) */
    if (!Tcap)
	printf ("\033[60;0;0;%dp", W_tt.t_length);/* ZSDP */
    printf ("\033[1Q\033[m");			/* SEE, SGR */
    printf ("\033[f\033[2J");			/* HVP, ED */
    curX = curY = 1;
    CurModes = 0;
    DesiredMode = m_overwrite;
    pad (1, 250.00);
}

static
cleanup () {
    Setmodes (1);
    topos (W_tt.t_length, 1);
    printf ("\033[J");
    pad (1, 150.);
    printf ("\033[>33;37h\033[>52l");		/* SM(ZWFM,ZAXM) RM(ZMKM) */
}

static
wipeline () {
    Setmodes (1);
    printf ("\033[K");
    pad (80-curX, 0.14);
}

static
wipescreen () {
    Setmodes (1);
    printf ("\033[2J");
    pad (1, 200.);
}

static
delchars (n) {
    if (n <= 0) return;
    Setmodes (1);
    printf (n == 1 ? "\033[P" : "\033[%dP", n);
    pad (80-curX, 0.20);
}

TrmAmb () {
	static int ppl[]={18,20,22,24,26,28,30,36,40,48,60,0};
	int pl, i;		/* get preferred page length from */
	char *p = (char *) getenv ("PL");/* environment - DCL */

	W_tt.t_length = 60;
	Tcap = 0;
	if (p == 0) {
	    static char tbuf[1024];
	    if (tgetent (tbuf, getenv ("TERM")) > 0) {
		W_tt.t_length = tgetnum ("li");
		++Tcap;
	    }
	}
	if (Tcap == 0) {
		pl = p == 0 ? 60 : atoi (p);
		for (i=0; ppl[i]; i++)
			if (pl==ppl[i]) { W_tt.t_length = pl; break; }
	}
	W_tt.t_INSmode = INSmode;
	W_tt.t_modes = modes;
	W_tt.t_inslines = inslines;
	W_tt.t_dellines = dellines;
	W_tt.t_blanks = blanks;
	W_tt.t_init = init;
	W_tt.t_cleanup = cleanup;
	W_tt.t_wipeline = wipeline;
	W_tt.t_wipescreen = wipescreen;
	W_tt.t_topos = topos;
	W_tt.t_reset = reset;
	W_tt.t_delchars = delchars;
	W_tt.t_writechars = writechars;
	W_tt.t_window = 0;
	W_tt.t_ILmf = 0;
	W_tt.t_ILov = 4;
	W_tt.t_ICmf = 1;
	W_tt.t_ICov = 4;
	W_tt.t_DCmf = 0;
	W_tt.t_DCov = 5;
	W_tt.t_width = 80;
	return 0;
}
