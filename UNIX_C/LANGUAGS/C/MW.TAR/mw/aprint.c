#include "win.h"

/* Copyright (c) 1983 University of Maryland Computer Science Department */

/* Print C style string with mode m into window w at aux cursor */
/* MODE m MAY HAVE "WBUF" BIT ON */
/* PRINTS TO w->w_winbuf */
Waputs (s, m, w)
register char *s;
register m;
register Win *w;
{
	while (*s)
		Waputc (*s++, m, w);
	return 0;
}

/* Put a char into window w with mode m at aux cursor. */
/* CHAR c REALLY GOES INTO w->w_winbuf AND IS NOT INTERPRETED */
/* MODE m MAY HAVE "WBUF" BIT ON, CHAR c MAY HAVE HIGH BIT ON */
Waputc (c, m, w)
register c, m;
register Win *w;
{
	w -> w_wcursor -> Mode =
		(w -> w_wcursor -> Mode & ~(WBUF|MODEMASK)) |
		(m & (WBUF|MODEMASK));
	w -> w_wcursor -> Char = c;
	if (w -> w_status & WHIDDEN)
		w -> w_status |= WDUMP;
	else
		WDispPut (w, w -> w_auxcursor.row, w -> w_auxcursor.col, 0);
	w -> w_wcursor++;
	w -> w_auxcursor.col++;
	if (w -> w_auxcursor.col >= w -> OXE) {
		w -> w_auxcursor.col = 0;
		w -> w_auxcursor.row++;
		if (w -> w_auxcursor.row >= w -> OYE) {
			w -> w_auxcursor.row = 0;
			w -> w_wcursor = w -> w_winbuf;
		}
	}
	return 0;
}
