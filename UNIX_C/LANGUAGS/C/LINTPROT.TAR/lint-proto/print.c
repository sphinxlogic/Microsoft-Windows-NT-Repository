/* print.c - C-style output functions for lint pass 1
 *
 *			   COPYRIGHT NOTICE
 *
 * Copyright 1988 Jonathan P. Leech
 *
 * Permission is granted to reproduce and distribute this
 *  software by any means so long as this notice is always retained
 *  in the copies and so long as no fee is charged for copying.
 *
 * All other rights are reserved except as explicitly granted
 *  by written permission of the author.
 *
 */
#include <stdio.h>
#include <ctype.h>
#include "pass1.h"
#include "lmanifest.h"

extern char *malloc();
char *atype_name(),
     *type_name(),
     *flag_name(),
     *Arg[MAX_ARG] = { NULL };
int   ArgLine = -1;
extern int FuncMode, PrintVars;

rec_print(rec, size, d, s)
union rec *rec;
{
    int i;

    switch (rec->l.decflag) {
	case LST:    /* static */
	case LDI:    /* initialized */
	case LIB:    /* library */
	case LDC:    /* global */
	case LDX:    /* global: if ! pflag, same as LDI     */
	    {
		char *tname = atype_name(&rec->l.type, d, s, rec->l.name);

		/* Store function name for later use by func_decl() */
		if (ISFTN(rec->l.type.aty)) {
		    if (!(Arg[0] = malloc(strlen(tname) + 10))) {
			fprintf(stderr, "out of memory in rec_print()\n");
			exit(1);
		    }
		    if (rec->l.decflag == LST)
			sprintf(Arg[0], "static %s", tname);
		    else
			strcpy(Arg[0], tname);
		    /* Save line on which function was defined */
		    ArgLine = rec->l.fline;
		} else if (PrintVars) {
		    /* Variable, just print its declaration */
		    if (rec->l.decflag == LST)
			printf("static ");

		    fputs(tname, stdout);
		    fputs(";\n", stdout);
		}
	    }
	    break;
	case LFN:   /* library name */
	case LRV:   /* function returning a value */
	case LUV:   /* function/value context */
	case LUE:   /* function/effects context */
	case LUM:   /* mentioned somewhere other than at the declaration */
	default:    /* combinations of flags, don't seem to happen */
	    break;
    }
}

#define NTYPE 40
/* Get a string from the static pool (will not be reused for NTYPE calls) */
char *buf_next() {
    /* Allow up to NTYPE different strings */
    static char buf[NTYPE][100];
    static int	bufptr = 0;

    char *tmp = buf[bufptr];
    bufptr = (bufptr + 1) % NTYPE;
    *tmp = '\0';
    return tmp;
}

/* Print a type t in canonical (C) format
 *  d & s are the dimoff & sizoff members from the corresponding
 *  symbol table entry for the type member.
 */
char *type_name(t, d, s, var_name, struct_name)
TWORD t;	    /* Type in PCC internal form */
int   d,	    /* symtab->dimoff */
      s;	    /* symtab->sizoff */
char *var_name;     /* Name of variable of this type (usually '%s' for printf) */
char *struct_name;  /* Name of structure/union/enum(?) of base type */
{
    static char *tnames[] = {
	"undef",
	"farg",
	"char",
	"short",
	"int",
	"long",
	"float",
	"double",
	"struct",
	"union",
	"enum",
	"moety",    /* member of enum. type? */
	"unsigned char",
	"unsigned short",
	"unsigned",
	"unsigned long",
	"?", "?"
    };
    char *buf = buf_next(),
	 *altbuf = buf_next(),
	 *this = buf,
	 *next;
    int   i, sptr = 0, stack[100];  /* Stack of type modifiers for type t */
#define VOID 0200   /* See "pcclocal.h"; this should not clash */

    /* Stack type modifiers up for easy access */
    do {
	if (ISPTR(t))
	    stack[sptr++] = PTR;
	else if (ISFTN(t))
	    stack[sptr++] = FTN;
	else if (ISARY(t))
	    stack[sptr++] = ARY;
	else {
	/* Watch out for void modifiers, no base type (?) */
	    stack[sptr++] = t;
	    break;
	}
    } while ((t = DECREF(t)));

    /* If no base type is supplied, must be a void (heuristic) */
    if (sptr && (stack[sptr-1] == PTR ||
		 stack[sptr-1] == FTN ||
		 stack[sptr-1] == ARY))
	stack[sptr++] = VOID;

    /* Nonsense type on stack to indicate an identifier */
    stack[sptr] = 0;

    /* Initialize buffer with variable name */
    strcpy(this, var_name);

    if (struct_name == NULL)
	struct_name = "<Unknown tag>";

    /* For each layer of type, wrap the C-style declaration
     *	of the type around it.
     */
    for (i = 0; i < sptr; i++) {
	/* Where to build next buffer */
	next = (this == buf) ? altbuf : buf;
	switch (stack[i]) {
	    case PTR:
		/*	*(*x)	-> **x
		 *	(*x)[]	-> (*x)[]
		 *	(*x)()	-> (*x)()
		 */
		if (stack[i+1] == FTN || stack[i+1] == ARY) {
		    strcpy(next, "(*");
		    strcat(next, this);
		    strcat(next, ")");
		} else {
		    strcpy(next, "*");
		    strcat(next, this);
		}
		break;
	    case FTN:
		/*	*(x())	-> *x()
		 *	(x())[] -> x()[]    // illegal
		 *	(x())() -> x()()    // illegal
		 */
		strcpy(next, this);
		strcat(next, "()");
		break;
	    case ARY:
		/*	*(x[])	-> *x[]
		 *	(x[])[] -> x[][]
		 *	(x[])() -> x[]())   // illegal
		 */
		if (dimtab[d]) {
		    sprintf(next, "%s[%d]", this, dimtab[d]);
		} else {
		    /* Unknown dimension */
		    strcpy(next, this);
		    strcat(next, "[]");
		}
		d++;
		break;
	    case STRTY:
		sprintf(next, "struct %s %s", struct_name, this);
		break;
	    case UNIONTY:
		sprintf(next, "union %s %s", struct_name, this);
		break;
	    case ENUMTY:
		sprintf(next, "enum %s %s", struct_name, this);
		break;
	    case MOETY:
		sprintf(next, "(enum member ?%s?) %s", struct_name, this);
		break;
	    case VOID:
		sprintf(next, "void %s", this);
		break;
	    default:
		/* Scalar type */
		if (this[0] != '\0')
		    sprintf(next, "%s %s", tnames[t], this);
		else
		    strcpy(next, tnames[t]);
		break;
	}
	/* Swap buffers */
	this = next;
    }

    /* Return the formed type string */
    return next;
}

/* Routine to form symbolic name of a type.
 *  t - type
 *  d - dimoff from symbol table
 *  s - sizoff from symbol table
 *  varname - variable name to generate (can use "" for none)
 */
char *atype_name(t, d, s, varname)
ATYPE *t;
int    d, s;
char  *varname;
{
    char *ptr = buf_next();

    /* Size of type is in t->extra, if it's nonzero */
    strcpy(ptr, type_name(t->aty, d, s, varname, t->extra1));

    return ptr;
}

/* Return a new copy of a string */
char *str_copy(s)
char *s;
{
    char *t = malloc(strlen(s) + 1);

    if (!t) {
	fprintf(stderr, "Out of memory in print.c:str_copy()\n");
	exit(1);
    }

    strcpy(t, s);
    return t;
}

/* Print out a function declaration using information on function
 *  arguments stored away earlier in parsing.
 * Comment out arguments in the prototype if Comment is true.
 */
void func_decl(nargs)
int nargs;
{
    int i;
    char *fname = Arg[0];

    /* Write function name */
    if (!fname)
	fname = "<Unknown function>";
    else
	fname[strlen(fname)-2] = '\0';	/* Dispose of trailing () */

    switch (FuncMode) {
	case OLD_C:
	    printf("%s(/* ", fname);
	    break;
	case MIXED:
	    printf("DECL(%s,(", fname);
	    break;
	case C_PLUSPLUS:
	    printf("%s(", fname);
	    break;
    }

    if (Arg[0] != NULL) {
	free(Arg[0]);		/* Free it */
	Arg[0] = NULL;		/* Mark empty slot for future calls */
    }

    /* Write out each argument type & free associated space */
    /* Note argument indices are 1-based */

    for (i = 1; i <= nargs; i++) {
	fputs(Arg[i], stdout);
	free(Arg[i]);
	if (i < nargs) {
	    fputs(", ", stdout);
	}
    }

    switch (FuncMode) {
	case OLD_C:
	    fputs(" */);\n", stdout);
	    break;
	case MIXED:
	    fputs("));\n", stdout);
	    break;
	case C_PLUSPLUS:
	    fputs(");\n", stdout);
	    break;
    }
}
