/*
 * Arrayalloc.c -- routines to provide dynamic memory allocation for 2
 * dimensional arrays.  The idea is to implement vectored arrays in such a
 * way that they are compatible with normal multi-dimension arrays as far
 * as syntax goes.
 *
 * $Log:	arrayalloc.c,v $
 * Revision 1.4  85/08/12  12:36:27  roy
 * Random commenting and de-lintifying.
 * 
 * Revision 1.3  85/08/12  12:12:51  roy
 * Added random comments in preperation for distribution.
 * 
 * Revision 1.2  85/08/06  18:30:27  roy
 * Added debugging statments in arrayalloc().
 * 
 * Revision 1.1  85/08/05  18:45:20  roy
 * Initial revision
 * 
 */

# include <stdio.h>

static char *rcsid = "$Header: arrayalloc.c,v 1.4 85/08/12 12:36:27 roy Rel $";

/*
 * Arrayalloc () -- allocate an imax by jmax vectored array of "size" byte
 * elements.  If memory can't be allocated, either for the main array or for
 * the row address vector, we return NULL.  See accompanying documentation
 * for more details.
 */
char **arrayalloc (imax, jmax, size)
unsigned imax, jmax, size;
{
	char *malloc();
	register char **vector, *array;
	register int k, stride;

	/*
	 * Get memory for main array.
	 */
	if ((array = malloc (imax * jmax * size)) == NULL)
		return (NULL);

# ifdef DEBUG
	printf ("array = %x\n", array);
# endif

	/*
	 * Get memory for intermediate row address vector.
	 */
	if ((vector = (char **) malloc (imax * sizeof (char *))) == NULL)
		return (NULL);

	/*
	 * Initialize the address vector so each element points to the
	 * first element in the corresponding row in the main array.
	 */
	for (k = 0; k < imax; k++)
	{
		stride = jmax * size;
		vector [k] = &array [k*stride];
# ifdef DEBUG
		printf ("vector [%d] = %x\n", k, vector[k]);
# endif
	}

	return (vector);
}

/*
 * Arrayfree () -- free the memory acquired from arrayalloc ().  No checks
 * are made to make sure things are as they should be, so it is the user's
 * responsibility to make sure that you don't arrayfree() anything that you
 * didn't arrayalloc() in the first place.  Eventually, checks will be added
 * to make sure the user hasn't screwed things up.  We have to first free the
 * real array memory, and then free the intermediate vector.  This sounds
 * more complicated than it really is.
 */
arrayfree (v)
char **v;
{
	free (v[0]);
	free ((char *) v);
}
