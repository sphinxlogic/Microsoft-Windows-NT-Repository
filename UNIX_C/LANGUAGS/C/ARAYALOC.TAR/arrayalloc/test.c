/*
 * Arraytest.c -- driver program to exercise array allocation routine.
 * All this does is get an array, fill it with numbers, print it all
 * again, and then free the array.  This is as much a demo of how to use
 * the routines as a test of how well they work.
 *
 * $Log:	test.c,v $
 * Revision 1.3  85/08/12  19:21:06  roy
 * Fixed trivial little typo in comment.  Of course, I only noticed the typo
 * *after* I had already checked out the last version, marked it for release,
 * built the sharchive, and was all ready to mail it off.  Grrrrrrrr.....
 * 
 * Revision 1.2  85/08/12  17:23:58  roy
 * fixed botch in the " $ H e a d e r $ " line.
 * 
 * Revision 1.1  85/08/12  12:37:16  roy
 * Initial revision
 * 
 */

static char *rcsid = "$Header: test.c,v 1.3 85/08/12 19:21:06 roy Rel $";

# include <stdio.h>
# define MAX	5
main ()
{
	char **arrayalloc();
	int **x, i, j;

	if ((x = (int **) arrayalloc (MAX, MAX, sizeof (**x))) == NULL)
	{
		perror ("error in makearray: ");
		exit (1);
	}

	for (i = 0; i < MAX; i++)
		for (j = 0; j < MAX; j++)
			x[i][j] = 10*i + j;

	for (i = 0; i < MAX; i++)
		for (j = 0; j < MAX; j++)
			printf ("%d%c", x[i][j], j == MAX-1 ? '\n' : '\t');

	arrayfree ((char **) x);
}
