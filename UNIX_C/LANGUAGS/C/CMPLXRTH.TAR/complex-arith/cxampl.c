/*
	CxAmpl -- amplitude (magnitude, modulus, norm) of a complex

	CxAmpl( &c )	returns  |c|

	last edit:	86/01/04	D A Gwyn

	SCCS ID:	@(#)cxampl.c	1.1
*/

#include	<math.h>

#include	<complex.h>

double
CxAmpl( cp )
	register complex	*cp;
	{
	return hypot( cp->re, cp->im );
	}
