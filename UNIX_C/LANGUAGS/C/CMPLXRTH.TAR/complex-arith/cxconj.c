/*
	CxConj -- conjugate a complex

	CxConj( &c )	conjugates  c  and returns  &c

	last edit:	86/01/04	D A Gwyn

	SCCS ID:	@(#)cxconj.c	1.1
*/

#include	<complex.h>

complex *
CxConj( cp )
	register complex	*cp;
	{
	/* (real part unchanged) */
	cp->im = -cp->im;

	return cp;
	}
