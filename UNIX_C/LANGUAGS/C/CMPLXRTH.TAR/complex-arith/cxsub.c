/*
	CxSub -- subtract one complex from another

	CxSub( &a, &b )	subtracts  b  from  a  and returns  &a

	last edit:	86/01/04	D A Gwyn

	SCCS ID:	@(#)cxsub.c	1.1
*/

#include	<complex.h>

complex *
CxSub( ap, bp )
	register complex	*ap, *bp;	/* (may coincide) */
	{
	ap->re -= bp->re;
	ap->im -= bp->im;

	return ap;
	}
