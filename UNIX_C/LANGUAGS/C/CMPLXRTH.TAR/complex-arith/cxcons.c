/*
	CxCons -- construct a complex from real and imaginary parts

	CxCons( &c, re, im )	makes  c = re + i im  and returns  &c

	last edit:	86/01/04	D A Gwyn

	SCCS ID:	@(#)cxcons.c	1.1
*/

#include	<complex.h>

complex *
CxCons( cp, re, im )
	register complex	*cp;
	double			re, im;
	{
	cp->re = re;
	cp->im = im;

	return cp;
	}
