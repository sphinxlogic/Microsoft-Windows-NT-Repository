/*
	CxPhsr -- construct a complex "phasor" from amplitude and phase

	CxPhsr( &c, amp, phs )	makes  c = amp exp(i phs)
					and returns  &c

	last edit:	86/01/04	D A Gwyn

	SCCS ID:	@(#)cxphsr.c	1.1
*/

#include	<math.h>

#include	<complex.h>

complex *
CxPhsr( cp, amp, phs )
	register complex	*cp;
	double			amp, phs;
	{
	cp->re = amp * cos( phs );
	cp->im = amp * sin( phs );

	return cp;
	}
