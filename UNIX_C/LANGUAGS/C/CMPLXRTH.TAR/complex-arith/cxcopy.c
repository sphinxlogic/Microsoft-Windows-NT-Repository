/*
	CxCopy -- copy a complex

	last edit:	86/01/04	D A Gwyn

	SCCS ID:	@(#)cxcopy.c	1.1

	CxCopy( &a, &b )	copies  b  to  a  and returns  &a
*/

#include	<complex.h>

complex *
CxCopy( ap, bp )
	complex	*ap, *bp;		/* may coincide */
	{
	*ap = *bp;

	return ap;
	}
