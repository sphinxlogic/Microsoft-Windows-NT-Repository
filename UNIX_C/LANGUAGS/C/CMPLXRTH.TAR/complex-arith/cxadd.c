/*
	CxAdd -- add one complex to another

	last edit:	86/01/04	D A Gwyn

	SCCS ID:	@(#)cxadd.c	1.1

	CxAdd( &a, &b )	adds  b  to  a  and returns  &a
*/

#include	<complex.h>

complex *
CxAdd( ap, bp )
	register complex	*ap, *bp;	/* may coincide */
	{
	ap->re += bp->re;
	ap->im += bp->im;

	return ap;
	}
