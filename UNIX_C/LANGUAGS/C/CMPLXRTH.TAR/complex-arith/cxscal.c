/*
	CxScal -- multiply a complex by a scalar

	CxScal( &c, s )	scales  c  by  s  and returns  &c

	last edit:	86/01/04	D A Gwyn

	SCCS ID:	@(#)cxscal.c	1.1
*/

#include	<complex.h>

complex *
CxScal( cp, s )
	register complex	*cp;
	double			s;
	{
	cp->re *= s;
	cp->im *= s;

	return cp;
	}
