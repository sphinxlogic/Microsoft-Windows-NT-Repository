/*
	CxMul -- multiply one complex by another

	CxMul( &a, &b )	multiplies  a  by  b  and returns  &a

	last edit:	86/01/04	D A Gwyn

	SCCS ID:	@(#)cxmul.c	1.1
*/

#include	<complex.h>

complex *
CxMul( ap, bp )
	register complex	*ap, *bp;	/* (may coincide) */
	{
	double			ap__re = ap->re;
	double			bp__re = bp->re;

	ap->re = ap__re * bp__re - ap->im * bp->im;
	ap->im = ap__re * bp->im + ap->im * bp__re;

	return ap;
	}
