/*  File   : _str2set.h
    Updated: 10 April 1984
    Purpose: External declarations for strprbk, strspn, strcspn &c
    Copyright (C) 1984 Richard A. O'Keefe.
*/

extern	int	_set_ctr;
extern	char	_set_vec[];
extern	void	_str2set(/*char^*/);

