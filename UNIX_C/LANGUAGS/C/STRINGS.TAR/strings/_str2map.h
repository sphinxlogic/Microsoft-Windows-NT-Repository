/*  File   : _str2map.h
    Author : Richard A. O'Keefe.
    Updated: 11 April 1984
    Purpose: Definitions from _str2map.c
*/

extern	char	_map_vec[_AlphabetSize+1];
extern	void	_str2map(/*int,_char_^,char^*/);

