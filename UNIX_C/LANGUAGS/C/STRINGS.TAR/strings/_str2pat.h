/*  File   : _str2pat.h
    Author : Richard A. O'Keefe.
    Updated: 20 April 1984
    Purpose: Definitions from _str2pat.c
*/

extern	int	_pat_lim;
extern	int	_pat_vec[];
extern	_char_	*_str2pat(/*_char_^*/);

