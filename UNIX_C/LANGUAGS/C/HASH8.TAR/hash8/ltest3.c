int VeryLongIdentifierNumber4 ();
    {
    printf ("VeryLongIdentifierNumber4 VerylongIdentifierNumber5\n");
    }
