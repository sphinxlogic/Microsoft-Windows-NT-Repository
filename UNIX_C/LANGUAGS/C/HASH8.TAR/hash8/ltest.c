#include <stdio.h>

/*
 * Test the lcc script
 */

int VeryLongIdentifierNumber1 = 1;
int VeryLongIdentifierNumber2 = 2;

void VeryLongIdentifierNumber3 ();
/*
 * The following should generate a lint complaint, because it actually
 * returns an int.
 */
extern void VeryLongIdentifierNumber4 ();

/*
 * The following will generate a loader error.  On some loaders, this is
 * ok;  on others it will keep you from getting an output file.  If so,
 * you will need to remove the reference below.
 */
extern int VeryLongIdentifierNumber5 ();

int main (argc, argv)
    register int		argc;		/* Argument count */
    register char *		argv[];		/* Argument vector */
    {

    /*
     * Generate a C compiler warning message.  Argv is char **, not char *.
     */
    argv = (char *) argc;
    VeryLongIdentifierNumber3 ();
    /*
     * The following is in a second file
     */
    VeryLongIdentifierNumber4 ();
    return 0;
    }

void VeryLongIdentifierNumber3 ()
    {
    int i = 0;

    printf ("should print 1 2:  %d %d\n", VeryLongIdentifierNumber1,
      VeryLongIdentifierNumber2);
    if (i)				/* Never executed - undefined ref */
	VeryLongIdentifierNumber5 ();
    }
