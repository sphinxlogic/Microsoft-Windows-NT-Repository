#include <stdio.h>
#include "smap.h"

main()
{
	char	*ptr;
	char	*ign;

	_blkstart();
	_blkstart();
	if ((ptr = (char *) malloc(10)) == (char *) NULL)
		(void) fprintf(stderr, "malloc failure\n");
	(void) free(ptr);
	_blkend();
	if ((ptr = (char *) malloc(10)) == (char *) NULL)
		(void) fprintf(stderr, "malloc failure\n");
	if ((ign = (char *) malloc(20)) == (char *) NULL)
		(void) fprintf(stderr, "malloc failure\n");
	_blkignore(ign);
	(void) free(ptr);
	_blkend();
	_blkend();
	(void) free(ptr);
}

