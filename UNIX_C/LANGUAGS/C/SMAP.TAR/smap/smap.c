/*
 *	@(#)smap.c	1.2	30/08/88	16:28:19	agc
 *
 *	Copyright 1988, Joypace Ltd., UK. This product is "careware".
 *	If you find it useful, I suggest that you send what you think
 *	it is worth to the charity of your choice.
 *
 *	Alistair G. Crooks,				+44 5805 3114
 *	Joypace Ltd.,
 *	2 Vale Road,
 *	Hawkhurst,
 *	Kent TN18 4BU,
 *	UK.
 *
 *	UUCP Europe                 ...!mcvax!unido!nixpbe!nixbln!agc
 *	UUCP everywhere else ...!uunet!linus!nixbur!nixpbe!nixbln!agc
 *
 *	smap.c - source file for debugging aids.
 */
#ifndef lint
char	*nsccsid = "@(#)smap.c	1.2 30/08/88 16:28:19	agc";
#endif /* lint */

#include <stdio.h>
#include <signal.h>

typedef struct _slotstr {
	char		*s_ptr;		/* the allocated area */
	unsigned int	s_size;		/* its size */
	char		s_freed;	/* whether it's been freed yet */
	char		s_blkno;	/* program block reference number */
} SLOT;

#ifndef MAXSLOTS
#define MAXSLOTS	4096
#endif /* MAXSLOTS */

static SLOT	slots[MAXSLOTS];
static int	slotc;
static int	blkno;

#define WARNING(s1, s2)		(void) fprintf(stderr, s1, s2)

extern char	*malloc();
extern char	*calloc();
extern char	*realloc();


/*
 *	abort - print a warning on stderr, and send a SIGQUIT to ourself
 */
static void
abort(s1, s2)
char	*s1;
char	*s2;
{
	WARNING(s1, s2);
	(void) kill(getpid(), SIGQUIT);	/* core dump here */
}


/*
 *	_malloc - wrapper around malloc. Warns if unusual size given, or the
 *	real malloc returns a NULL pointer. Returns a pointer to the
 *	malloc'd area
 */
char *
_malloc(size)
unsigned int	size;
{
	SLOT	*sp;
	char	*ptr;
	int	i;

	if (size == 0)
		WARNING("_malloc: unusual size %d bytes\n", size);
	if ((ptr = (char *) malloc(size)) == (char *) NULL)
		WARNING("_malloc: unable to malloc %d bytes\n", size);
	for (i = 0, sp = slots ; i < slotc ; i++, sp++)
		if (sp->s_ptr == ptr)
			break;
	if (i == slotc) {
		if (slotc == MAXSLOTS - 1)
			abort("_malloc: run out of slots\n", (char *) NULL);
		sp = &slots[slotc++];
	} else if (!sp->s_freed)
		WARNING("_malloc: malloc returned a non-freed pointer\n", NULL);
	sp->s_size = size;
	sp->s_freed = 0;
	sp->s_ptr = ptr;
	sp->s_blkno = blkno;
	return(sp->s_ptr);
}


/*
 *	_calloc - wrapper for calloc. Calls _malloc to allocate the area, and
 *	then sets the contents of the area to NUL bytes. Returns its address.
 */
char *
_calloc(nel, size)
int		nel;
unsigned int	size;
{
	unsigned int	tot;
	char		*ptr;
	char		*cp;

	tot = nel * size;
	ptr = _malloc(tot);
	if ((cp = ptr) == (char *) NULL)
		return((char *) NULL);
	while (tot--)
		*cp++ = 0;
	return(ptr);
}


/*
 *	_realloc - wrapper for realloc. Checks area already alloc'd and
 *	not freed. Returns its address
 */
char *
_realloc(ptr, size)
char		*ptr;
unsigned int	size;
{
	SLOT	*sp;
	int	i;

	for (i = 0, sp = slots ; i < slotc ; i++, sp++)
		if (sp->s_ptr == ptr)
			break;
	if (i == slotc)
		abort("_realloc: realloc on unallocated area\n", (char *) NULL);
	if (sp->s_freed)
		WARNING("_realloc: realloc on freed area\n", (char *) NULL);
	if ((sp->s_ptr = (char *) realloc(ptr, size)) == (char *) NULL)
		WARNING("_realloc: realloc failure %d bytes\n", size);
	sp->s_size = size;
	sp->s_blkno = blkno;
	return(sp->s_ptr);
}


/*
 *	_free - wrapper for free. Loop through allocated slots, until you
 *	find the one corresponding to pointer. If none, then it's an attempt
 *	to free an unallocated area. If it's already freed, then tell user.
 */
void
_free(ptr)
char	*ptr;
{
	SLOT	*sp;
	int	i;

	for (i = 0, sp = slots ; i < slotc ; i++, sp++)
		if (sp->s_ptr == ptr)
			break;
	if (i == slotc)
		abort("_free: free not previously malloc'd\n", (char *) NULL);
	if (sp->s_freed)
		abort("_free: free after previous freeing\n", (char *) NULL);
	(void) free(sp->s_ptr);
	sp->s_freed = 1;
}


/*
 *	_blkstart - start of a program block. Increase the block reference
 *	number by one.
 */
void
_blkstart()
{
	blkno += 1;
}


/*
 *	_blkend - end of a program block. Check all areas allocated in this
 *	block have been freed. Decrease the block number by one.
 */
void
_blkend()
{
	SLOT	*sp;
	int	i;

	if (blkno == 0) {
		WARNING("_blkend: unmatched call to _blkend\n", NULL);
		return;
	}
	for (i = 0, sp = slots ; i < slotc ; i++, sp++)
		if (sp->s_blkno == blkno && !sp->s_freed)
			WARNING("_blkend: %d bytes unfreed\n", sp->s_size);
	blkno -= 1;
}


/*
 *	_blkignore - find the slot corresponding to ptr, and set its block
 *	number to zero, to avoid _blkend picking it up when checking.
 */
void
_blkignore(ptr)
char	*ptr;
{
	SLOT	*sp;
	int	i;

	for (i = 0, sp = slots ; i < slotc ; i++, sp++)
		if (sp->s_ptr == ptr)
			break;
	if (i == slotc)
		WARNING("_blkignore: pointer has not been allocated\n", NULL);
	else
		sp->s_blkno = 0;
}
