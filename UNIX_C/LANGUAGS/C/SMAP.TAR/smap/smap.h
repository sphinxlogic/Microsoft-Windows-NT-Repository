/*
 *	@(#)smap.h	1.1	30/08/88	16:07:36	agc
 *
 *	Copyright 1988, Joypace Ltd., UK. This product is "careware".
 *	If you find it useful, I suggest that you send what you think
 *	it is worth to the charity of your choice.
 *
 *	Alistair G. Crooks,				+44 5805 3114
 *	Joypace Ltd.,
 *	2 Vale Road,
 *	Hawkhurst,
 *	Kent TN18 4BU,
 *	UK.
 *
 *	UUCP Europe                 ...!mcvax!unido!nixpbe!nixbln!agc
 *	UUCP everywhere else ...!uunet!linus!nixbur!nixpbe!nixbln!agc
 *
 *	smap.h - include file for debugging aids. This file must be included,
 *	before any calls, in any source file that calls malloc, calloc,
 *	realloc, or free. (Note alloca is not included in this list).
 */
#ifdef NOMEMCHECK
#define	_blkstart()
#define _blkend()
#define _blkignore(p)
#else /* not NOMEMCHECK */
#ifndef malloc
#define malloc	_malloc
#define calloc	_calloc
#define realloc	_realloc
#define free	_free
#endif /* not malloc */
extern void	_blkstart();
extern void	_blkend();
extern void	_blkignore();
#endif /* not NOMEMCHECK */
