/* Include file for users of argproc(). */
#include "boolean.h"
#include "lose.h"

long argproc();
