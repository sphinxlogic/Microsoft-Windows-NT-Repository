#include <stdio.h>

extern char	*malloc();
extern char	*realloc();

#define ISIZE 100

char *
alo_getline(f)

FILE	*f;

{
  int	l = 0;
  char	*r = 0;
  char	*p = 0;
  char	*ep;
  int	c;
  int	e = 0;

  for(;;) {
    c = getc(f);
    if (c == EOF || c == '\n') {
      if (c == EOF && !p)
	return 0;
      e = 1;
    } else if (c == 0) {
      c = '\n';
    }
    if (r == 0) {
      l = ISIZE;
      if (!(r = malloc(l)))
	return 0;
      p = r;
      ep = r+l-3;
    }
    if (p >= ep) {
      int	o;
      l += ISIZE;
      o = p - r;
      if (!(r = realloc(r,l)))
	return 0;
      p = r + o;
      ep = r+l-3;
    }
    if (e) {
      *p++ = 0;
      *p = c;
      return r;
    }
    *p++ = c;
  }
}
