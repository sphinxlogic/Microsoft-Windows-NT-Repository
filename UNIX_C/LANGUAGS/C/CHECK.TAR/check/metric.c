/*----------------------------------------------------------------------*/
/*									*/
/*	This module will do software metrics one day...			*/
/*									*/
/*----------------------------------------------------------------------*/


#include	<stdio.h>
#include	"check.h"
#include	"y.tab.h"

typedef	struct	Metric {
	int	sep_nouns;
	int	sep_verbs;
	int	tot_nouns;
	int	tot_verbs;
	int	stmts;
	int	comments;
	int	lines;
	int	decisions;
	int	knots;
}	Metric;

Metric	total, local;


void swm (m)
Metric	*m;
{
	/*  This procedure will print the Software Metrics  */

/*  Commented out until Lex & Grammar re-written to increment counts ...
	extern	double	log();

	double	vocab, length, volume, diff, effort, lang;
	double	decid, comms, layout;
	double	mccabe, knots;

	vocab	= m->sep_verbs + m->sep_nouns;
	length	= m->tot_verbs + m->tot_nouns;
	volume	= length * log(vocab) / log(2.0);
	diff	= (m->sep_verbs*m->tot_nouns)/(2.0*m->sep_nouns);
	effort	= volume * diff;
	lang	= volume / (diff * diff);

	decid	= m->decisions / m->stmts;
	comms	= m->comments / m->stmts;
	layout	= (m->stmts + m->comments) / m->lines;

	mccabe	= m->decisions + 1;
	knots	= m->knots;

	Printf ("%8.2g %8.2g %8.2g %8.2g %8.2g %8.2g %8.2g\n",
		volume, diff, effort, lang,
		decid, comms, layout,
		mccabe, knots
	);
............................................................ */
}


void metrics (this_proc)
char	*this_proc;
{
	/*  Report on the Software Metrics for current procedure, or  */
	/*  report on the total for the file if this_proc is null.    */

/*  Commented out until Lex re-written to increment counts ...
	if	(this_proc)
	{
		Printf ("%12.10s ", this_proc);
		swm (&local);
	}
	else
	{
		Printf ("%12.10s ", "Total:");
		swm (&total);
	}
............................................................ */
}


void proc_start ()
{
	/*  Initialise the counts for a procedure  */

	local.sep_nouns	= 1;
	local.sep_verbs	= 1;
	local.tot_nouns	= 1;
	local.tot_verbs	= 1;
	local.stmts	= 1;
	local.comments	= 1;
	local.lines	= 1;
	local.decisions	= 1;
	local.knots	= 1;
}


void met_init ()
{
	/*  Initialise the counts for a file  */

	proc_start ();

	total.sep_nouns	= 1;
	total.sep_verbs	= 1;
	total.tot_nouns	= 1;
	total.tot_verbs	= 1;
	total.stmts	= 1;
	total.comments	= 1;
	total.lines	= 1;
	total.decisions	= 1;
	total.knots	= 1;
}
