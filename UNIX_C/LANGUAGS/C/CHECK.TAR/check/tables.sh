
#	Make tables.h from check.h and y.xxx.h

(
sed <check.h -n -e '/	Parse/,$ s/^#define[ 	][ 	]*//p'
sed <y.xxx.h -n -e 's/^#[ 	]*define[ 	][ 	]*//p'
) |
awk -e '
BEGIN	{
		printf "typedef struct NodeName {\n"
		printf "\tint val;\n"
		printf "\tchar *str;\n"
		printf "} NodeName;\n\n"
		printf "NodeName\tnodenames[] = {\n"
	}
	{
		printf "\t%d, \"%s\",\n", $2, $1
	}
END	{
		printf "	0, 0\n};\n"
	}' >tables.h
