/* emitc - as the name implies, emitc is the opposite of ctime(3).
 .  ctime(3) eats a long integer which represents the number of seconds
 .  since Jan 01 00:00:00 1970 and spits out the corresponding day, date
 .  and time in ascii. emitc ingests an ascii string (formatted as per
 .  ctime's output) and gives back the appropriate number of seconds.
 .     
 .  Anyone is free to use emitc anyway they please, but if you do deem
 .  it worthwhile, leave the following credit line somewhere in the code:
 .
 .  AUTHOR - Mike Marshall    hubcap@hubcap.clemson.edu      4/20/88
 . 
 .  SYSTEM CALLS USED - none
 .
 .  LIBRARY FUNCTIONS USED - localtime(3)
 */
#include <time.h>
#define MONTH_OFFSET 4
#define DAY_OFFSET 8
#define HOUR_OFFSET 11
#define MINUTE_OFFSET 14
#define SECOND_OFFSET 17
#define YEAR_OFFSET 20
#define MONTH_LENGTH 3
#define MONTHS "JanFebMarAprMayJunJulAugSepOctNovDec"
#define SECONDS_PER_YEAR 31536000
#define SECONDS_PER_DAY 86400
#define SECONDS_PER_HOUR 3600
#define SECONDS_PER_MINUTE 60
#define FEB 1
#define TIMEZONE 5     /* You gotta change this, depending on where you
                        . are located geographically. I equated TIMEZONE
                        . to 5 since I am in the Eastern Standard Time Zone,
                        . which is five hours west of Greenwich.
                        */

long emitc(string)
char *string;
{
  struct tm *time;
  long fudge_days;
  long month_num;
  long clock;
  static char *months = MONTHS;
  static long days_so_far[11] = {31,59,90,120,151,181,212,243,273,304,334};
  /* determine month number */
  for (month_num=0;
       strncmp(string+MONTH_OFFSET,months+month_num*MONTH_LENGTH,MONTH_LENGTH);
       month_num++);
  /* determine the number of seconds since the beginning of the universe */
  clock = (atoi(string+YEAR_OFFSET)-1970) * SECONDS_PER_YEAR;
  if (month_num > 0) 
     clock = clock + days_so_far[month_num-1] * SECONDS_PER_DAY;
  clock = clock + (atoi(string+DAY_OFFSET)-1) * SECONDS_PER_DAY;
  clock = clock + atoi(string+HOUR_OFFSET) * SECONDS_PER_HOUR;
  clock = clock + atoi(string+MINUTE_OFFSET) * SECONDS_PER_MINUTE;
  clock = clock + atoi(string+SECOND_OFFSET);
  /* calculate in the leap year fudge factors */
  if (atoi(string+YEAR_OFFSET) > 1971) {
     fudge_days=0;
     fudge_days = (atoi(string+YEAR_OFFSET)-1971)/4;
     if (!(atoi(string+YEAR_OFFSET)%4) && (month_num > FEB)) fudge_days++;
     clock = clock + fudge_days*SECONDS_PER_DAY;
  }
  /* calculate in the time shift westward from Greenwich */
  clock = clock + TIMEZONE*SECONDS_PER_HOUR;
  /* worry about daylight savings time */
  time = localtime(&clock);
  if (time->tm_isdst) clock = clock - SECONDS_PER_HOUR;
  return(clock);
} 
