#ifndef INCLUDED_LINTOK

/* $Header: memlintok.h,v 1.3 89/05/02 15:01:43 bobl Locked $ */

/*
 *	These definitions stop lint from complaining about malloc, calloc,
 *	realloc, and free while at the same time performing checks of
 *	their arguments.  See the memlintok(3) man page for more details.
 *
 *	Bob Lewis (bobl@tessi.uucp) produced these macros using his own
 *	resources and hereby releases them to the public domain.
 *	The author will not be held responsible for their use, misuse,
 *	abuse, or any damages arising from same.
 */

#ifndef NULL
#include <stdio.h>
#endif

extern char *calloc();
#ifdef lint
#define CALLOC_LINTOK(ptr, nelem, type) \
	calloc((ptr = (type *) NULL, (unsigned) (nelem)), (unsigned) sizeof(type))
#else
#define CALLOC_LINTOK(ptr, nelem, type) \
	(ptr = (type *) calloc((unsigned) (nelem), (unsigned) sizeof(type)))
#endif

extern char *malloc();
#ifdef lint
#define MALLOC_LINTOK(ptr, nelem, type) \
	malloc((ptr = (type *) NULL, (unsigned) ((nelem) * sizeof(type))))
#else
#define MALLOC_LINTOK(ptr, nelem, type) \
	(ptr = (type *) malloc((unsigned) ((nelem) * sizeof(type))))
#endif

extern char *realloc();
#ifdef lint
#define REALLOC_LINTOK(ptr, nelem, type) \
	realloc( \
		(ptr = (type *) NULL, (char *) NULL), \
		(unsigned) ((nelem) * sizeof(type)))
#else
#define REALLOC_LINTOK(ptr, nelem, type) \
	(ptr = (type *) realloc( \
		(char *) ptr, \
		(unsigned) ((nelem) * sizeof(type))))
#endif

/* common use of malloc/realloc -- use it or don't use it */
#define MR_ALLOC_LINTOK(ptr, nelem, type) \
	( (ptr) == NULL \
		? MALLOC_LINTOK(ptr, (nelem), type) \
		: REALLOC_LINTOK(ptr, (nelem), type) )

/*
 *	These next macros invoke CALLOC_LINTOK, MALLOC_LINTOK, REALLOC_LINTOK,
 *	and MR_ALLOC_LINTOK with an error exit if they fail.
 *
 *	If you want to handle your own memory allocation errors, just
 *	"#undef ERROR_EXIT_LINTOK" and define your own.
 */
#define ERROR_EXIT_LINTOK(nelem, size) \
	{ \
		(void) fprintf(stderr, \
			"Memory allocation of %d * %d bytes on line %d of \"%s\" failed.\n", \
			(nelem), (size), __LINE__, __FILE__); \
		exit(1); \
	}

#define CALLOC_OR_ELSE_LINTOK(ptr, nelem, type) \
	{ \
		if (CALLOC_LINTOK(ptr, (nelem), type) == NULL) \
			ERROR_EXIT_LINTOK((nelem), sizeof(type)); \
	}

#define MALLOC_OR_ELSE_LINTOK(ptr, nelem, type) \
	{ \
		if (MALLOC_LINTOK(ptr, (nelem), type) == NULL) \
			ERROR_EXIT_LINTOK((nelem), sizeof(type)); \
	}

#define REALLOC_OR_ELSE_LINTOK(ptr, nelem, type) \
	{ \
		if (REALLOC_LINTOK(ptr, (nelem), type) == NULL) \
			ERROR_EXIT_LINTOK((nelem), sizeof(type)); \
	}

#define MR_ALLOC_OR_ELSE_LINTOK(ptr, nelem, type) \
	{ \
		if (MR_ALLOC_LINTOK(ptr, (nelem), type) == NULL) \
			ERROR_EXIT_LINTOK((nelem), sizeof(type)); \
	}

extern free();
#ifdef lint
#define FREE_LINTOK(ptr) \
	free((ptr = NULL, (char *) NULL))
#else
#define FREE_LINTOK(ptr) \
	free((char *) ptr)
#endif

/* We could have a "CFREE_LINTOK", but what's the point? */

#define INCLUDED_LINTOK
#endif

