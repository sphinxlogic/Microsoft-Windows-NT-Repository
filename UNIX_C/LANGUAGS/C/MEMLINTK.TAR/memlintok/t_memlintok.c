/* $Header: t_memlintok.c,v 1.3 89/05/02 15:07:08 bobl Exp $ */

#include <stdio.h>

#include "memlintok.h"

main()
{
	int *p, *q;

	if (MALLOC_LINTOK(p, 100, int) == NULL)
		fail("can't malloc 100 ints\n");
	else
		succeed("100 ints malloc'd\n");

	(void) REALLOC_LINTOK(p, 200, int);
	if (p == NULL)
		fail("can't realloc 200 ints\n");
	else
		succeed("200 ints realloc'd\n");

	if (MR_ALLOC_LINTOK(p, 25, int) == NULL)
		fail("can't mr_alloc (realloc) 25 ints\n");
	else
		succeed("25 ints mr_alloc'd (realloc'd)\n");

	if (CALLOC_LINTOK(q, 500, int) == NULL)
		fail("can't calloc 500 ints\n");
	else
		succeed("500 ints calloc'd\n");
	q[0] = 0;
	FREE_LINTOK(q);

	FREE_LINTOK(p);
	p = NULL;
	if (MR_ALLOC_LINTOK(p, 1000, int) == NULL)
		fail("can't mr_alloc (malloc) 1000 ints\n");
	else
		succeed("1000 ints mr_alloc'd (malloc'd)\n");

	CALLOC_OR_ELSE_LINTOK(p, 50, int);
	succeed("50 ints calloc'd (or else)\n");
	MALLOC_OR_ELSE_LINTOK(p, 100, int);
	succeed("100 ints malloc'd (or else)\n");
	REALLOC_OR_ELSE_LINTOK(p, 200, int);
	succeed("200 ints realloc'd (or else)\n");

#undef ERROR_EXIT_LINTOK
#define ERROR_EXIT_LINTOK(nelem, size) \
	fail("memory allocation failed\n");

	MR_ALLOC_OR_ELSE_LINTOK(p, 400, int);
	succeed("400 ints mr_alloc'd (realloc'd) (or else)\n");

	exit(0);
	return 0;	/* shuts up HP-UX lint */
}

fail(s)
	char *s;
{
	fputs(s, stdout);
	exit(1);
}

succeed(s)
	char *s;
{
	fputs(s, stdout);
	return;
}
