#include "scanaux.h"

int input_echo = 0;

main(argc, argv)
int argc;
char **argv;
{
	int yyparse();

	if ((argc >=2) && (strcmp (argv[1], "-L") == 0)) {
		input_echo = 1;
	}
	init_scanner();
	return(yyparse());
}
