extern int fum(const char *);
typedef int FOO;
int BAR;

FOO junk;

func1()
{
    char *FOO;
    typedef char *BAR;
    BAR junk;

    FOO = 0;
}

struct {
    int FOO;
    int BAR;
    struct {
	FOO junk;
    } junk;
} xxx;

struct {
    FOO BAR;
} yyy;

func2()
{
    FOO junk;

    BAR = 0;
}
