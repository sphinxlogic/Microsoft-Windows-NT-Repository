struct foo {int a;};
typedef int foo;
struct foo bar;
foo fum;
int foo();
foo bar;
