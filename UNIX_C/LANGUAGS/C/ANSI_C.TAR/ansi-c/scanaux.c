#include <assert.h>
#include <stdio.h>
#include "misctypes.h"

#define TYPEDEF_UNKNOWN	-1
#define TYPEDEF_FALSE	0
#define TYPEDEF_TRUE	1

static int in_typedef = FALSE;
static int typedef_recognition = TRUE;
static int in_memberlist = FALSE;

extern char *malloc();
extern char *realloc();
extern char *calloc();

/* TSS types */

#define TSS_INCR 16
static struct typedef_state_stack {
    int TOS;
    int MAX;
    int *values;
} TSS, RDS;
/*
 * TSS is used to push values of state variables like in_typedef and
 *      typedef_recognition
 *
 * RDS is used to keep track of identifiers re-defined in inner scopes.
 */

/* Typedef Table types */
static struct TypedefTable {
    char **tab;
    int cur;
    int max;
} TDT;

/* ID Hash Tbl types */

#define IDHASH_INCR 32
#define HASHSIZE 509

struct hashbucket {
    int nxt_entry;
    int max_entry;
    int entry[1];
};

static struct hashbucket *HTBL [HASHSIZE];	/* hopefully zeros? */

/* Char pool */

#define CHARBLOCKSIZE 1024
struct charpool_block {
    int next_ch;
    char chars[CHARBLOCKSIZE];
};

#define CHARPOOL_INCR 128
static struct charpool {
    struct charpool_block **char_pool;
    int maxind;
    int curind;
} CP;

static char *recalloc (ptr, oldnumelems, newnumelems, elemsize)
char *ptr;
int oldnumelems;
int newnumelems;
int elemsize;
{
    char *t = calloc (newnumelems, elemsize);
    memcpy (t, ptr, oldnumelems * elemsize);
    free (ptr);
    return t;
}

void init_scanner()
{
    TSS.TOS = -1;
    TSS.MAX = TSS_INCR;
    TSS.values = (int *)malloc (TSS_INCR * sizeof(int *));

    RDS.TOS = -1;
    RDS.MAX = TSS_INCR;
    RDS.values = (int *)malloc (TSS_INCR * sizeof(int *));

    CP.char_pool = (struct charpool_block **)
		    malloc (CHARPOOL_INCR * sizeof (struct charpool_block *));
    CP.char_pool[0] = (struct charpool_block *)
				      malloc (sizeof (struct charpool_block));
    CP.char_pool[0]->next_ch = 0;
    CP.maxind = CHARPOOL_INCR;
    CP.curind = 0;

    TDT.tab = (char **) calloc (CHARPOOL_INCR, sizeof (char *));
    TDT.cur = -1;
    TDT.max = CHARPOOL_INCR;
}

static void push_TSS (val)
int val;
{
    if (++TSS.TOS > TSS.MAX) {
	TSS.MAX += TSS_INCR;
	TSS.values = (int *) realloc (TSS.values, TSS.MAX * sizeof(int *));
	if (! TSS.values) {
	    fprintf (stderr, "realloc failed in push_TSS\n");
	    exit(1);
	}
    }
    TSS.values[TSS.TOS] = val;
}

static int pop_TSS ()
{
    if (TSS.TOS < 0) {
	fprintf (stderr, "TSS underflow\n");
	exit(1);
    }
    return (TSS.values[TSS.TOS--]);
}

static void push_RDS (val)
int val;
{
    if (++RDS.TOS > RDS.MAX) {
	RDS.MAX += TSS_INCR;
	RDS.values = (int *) realloc (RDS.values, RDS.MAX * sizeof(int *));
	if (! RDS.values) {
	    fprintf (stderr, "realloc failed in push_RDS\n");
	    exit(1);
	}
    }
    RDS.values[RDS.TOS] = val;
}

static int pop_RDS ()
{
    if (RDS.TOS < 0) {
	fprintf (stderr, "RDS underflow\n");
	exit(1);
    }
    return (RDS.values[RDS.TOS--]);
}

int IDhash (text, leng)
char *text;
int leng;
{
    short sum = 0, temp;

    while (leng > 0) {
	temp = *text++;
	temp <<= 8;
	temp |= *text++;
	leng -= 2;
	sum ^= temp;
    }
    return (sum %= HASHSIZE);
}

static int add_charpool (text, leng)
{
    int start;
    struct charpool_block *tcpb;

    if ((CHARBLOCKSIZE - CP.char_pool[CP.curind]->next_ch) < (leng+1)) {
	if (CP.curind++ > CP.maxind) {
	    CP.maxind += CHARPOOL_INCR;
	    CP.char_pool = (struct charpool_block **) realloc (CP.char_pool,
			      CP.maxind * sizeof (struct charpool_block *));
	}
	CP.char_pool[CP.curind] = (struct charpool_block *)
				      malloc (sizeof (struct charpool_block));
	CP.char_pool[CP.curind]->next_ch = 0;
    }

    tcpb = CP.char_pool[CP.curind];
    start = CP.curind * CHARBLOCKSIZE + tcpb->next_ch;
    memcpy (tcpb->chars + tcpb->next_ch, text, leng);
    tcpb->next_ch += (leng + 1);
    tcpb->chars[tcpb->next_ch - 1] = '\0';
    return start;
}

static int cpcmp (text, leng, index)
char *text;
int leng;
int index;
{
    int high = index / CHARBLOCKSIZE;
    int low = index % CHARBLOCKSIZE;
    char *start = CP.char_pool[high]->chars + low;

    return (memcmp (text, start, leng));
}

static int enterIDhash (text, leng)
char *text;
int leng;
{
    int i;
    int hval = IDhash (text, leng);
    struct hashbucket *htmp;

    /* search in hash tbl */
    if (!HTBL[hval]) {
	HTBL[hval] = (struct hashbucket *)
				     malloc ((IDHASH_INCR + 2) * sizeof(int));
	HTBL[hval]->nxt_entry = 0;
	HTBL[hval]->max_entry = IDHASH_INCR;
    }

    htmp = HTBL[hval];
    for (i = 0; i < htmp->nxt_entry; i++) {
	if (!cpcmp (text, leng, htmp->entry[i])) {
	    return htmp->entry[i];
	}
    }
    
    if (htmp->nxt_entry > htmp->max_entry) {
	htmp->max_entry += IDHASH_INCR;
	HTBL[hval] = (struct hashbucket *)
			realloc (htmp, (htmp->max_entry + 2) * sizeof(int));
	htmp = HTBL[hval];
    }
    htmp->entry[htmp->nxt_entry++] = add_charpool (text, leng);
}

static void set_typedef (index, val)
int index;
int val;
{
    int low, high;

    high = index / CHARBLOCKSIZE;
    low = index % CHARBLOCKSIZE;

    if (high >  TDT.cur) {
	assert (high == (TDT.cur + 1));
	if (++TDT.cur > TDT.max) {
	    TDT.tab = (char **) recalloc (TDT.tab, TDT.max,
				    TDT.max+CHARPOOL_INCR, sizeof (char *));
	    TDT.max += CHARPOOL_INCR;
	}
    }
    if (! TDT.tab[high]) {
	TDT.tab[high] = (char *) malloc (CHARBLOCKSIZE * sizeof(char));
	memset (TDT.tab[high], TYPEDEF_UNKNOWN, CHARBLOCKSIZE);
    }

    TDT.tab[high][low] = val;
}

static int lookup_typedef (index)
int index;
{
    int low, high;

    high = index / CHARBLOCKSIZE;
    low = index % CHARBLOCKSIZE;
    return (TDT.tab[high] ? TDT.tab[high][low] : TYPEDEF_UNKNOWN);
}

int lookup_tdname(text, leng)
char *text;
int leng;
{
    int IDindex;

    if (typedef_recognition) {
	IDindex = enterIDhash (text, leng);
	return (lookup_typedef(IDindex) == TYPEDEF_TRUE);
    } else {
	return FALSE;
    }
}

void enter_tdname(text, leng)
char *text;
int leng;
{
    int IDindex, oldval;

    IDindex = enterIDhash (text, leng);
    oldval = lookup_typedef (IDindex);
    if (in_typedef) {
	if (RDS.TOS >= 0 && oldval == TYPEDEF_FALSE)
		push_RDS (IDindex);
	set_typedef (IDindex, TYPEDEF_TRUE);
    } else if (! in_memberlist) {
	if (RDS.TOS >= 0 && oldval == TYPEDEF_TRUE)
		push_RDS (IDindex);
	set_typedef (IDindex, TYPEDEF_FALSE);
    }
}

void enter_TD_scope()
{
    push_RDS (-1);
}

void exit_TD_scope()
{
    int k;

    while ((k = pop_RDS()) != -1) {
	if (lookup_typedef(k)) {
	    set_typedef (k, FALSE);
	} else {
	    set_typedef (k, TRUE);
	}
    }
}

void set_in_memberlist()
{
    in_memberlist = TRUE;
}

void reset_in_memberlist()
{
    in_memberlist = FALSE;
}

void push_in_memberlist()
{
    push_TSS(in_memberlist);
}

void pop_in_memberlist()
{
    in_memberlist = pop_TSS();
}

void set_in_typedef()
{
    in_typedef = TRUE;
}

void reset_in_typedef()
{
    in_typedef = FALSE;
}

void push_in_typedef()
{
    push_TSS(in_typedef);
}

void pop_in_typedef()
{
    in_typedef = pop_TSS();
}

void set_typedef_recognition()
{
    typedef_recognition = TRUE;
}

void reset_typedef_recognition()
{
    typedef_recognition = FALSE;
}
