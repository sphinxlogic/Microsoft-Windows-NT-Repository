void init_scanner();
void push_TSS ();
int pop_TSS ();

extern void set_in_memberlist(),
	    reset_in_memberlist(),
	    push_in_memberlist(),
	    pop_in_memberlist(),
	    set_in_typedef(),
	    reset_in_typedef(),
	    push_in_typedef(),
	    pop_in_typedef(),
	    set_typedef_recognition(),
	    reset_typedef_recognition();

extern int  lookup_tdname();

extern int  input_echo;
