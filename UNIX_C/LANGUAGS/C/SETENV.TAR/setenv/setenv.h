/*
 * setenv.h
 */

#ifndef	SETENV_H
#define		SETENV_H

#define		MAX_ENV		256

extern	char	**environ, *setenv();
extern	int	unsetenv(), _envc;

#endif	!SETENV_H
