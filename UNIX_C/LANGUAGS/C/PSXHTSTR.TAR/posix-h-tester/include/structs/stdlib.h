div_t
ldiv_t
