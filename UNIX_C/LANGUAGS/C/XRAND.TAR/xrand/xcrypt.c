/*
 * xcrypt: a Encryption / Decryption program.
 *
 * xcrypt is loosely based on an idea that was proposed by M.Mauldin @ CMU
 * (and potentially many other): use a pseudo-random number generator (RNG)
 * to produce one-time pads.
 *
 * So, the basic approach is simply to initialize the RNG with the
 * encryption key and then decide what part of the RNG output is
 * used to encrypt the message. In xcrypt, a high quality RNG is
 * employed that was extensively tested for uniform distribution
 * and independence. This is expected to yield a rather strong encryption.
 *
 * Selecting the starting point of the random number sequence is based on a
 * seed that is derived from the unix time()-call and the process ID.
 * This seed (4 bytes) is prefixed to the ciphertext (similar to the typical
 * unix password encoding scheme). You may consider transmitting the seed
 * by an other channel.
 *
 * Actually, both the seed and the key are used to determine the initial
 * state of the RNG, which is less computationally expensive than letting
 * the RNG run for value-of(seed) iterations.
 *
 * This particular RNG has 9990bits of state (yes, more than 1Kbyte!), so
 * so keys of 1000 char are still meaningful (albeit cumbersome).
 *
 * In order to thwart a key-guessing, brute force attack, the RNG is
 * run for 60000 to 120000 iterations before the output is used for
 * encryption. The RNG output of this initialization phase is used to
 * construct 2 sets of 256 permutations of [0,1,...,255], that will
 * be used later. Thus, any shortcut of these iterations (the actual
 * number depends on the key and is not known to the attacker) would
 * also have to produce all the intermediate results. Given the low
 * complexity of an iteration, it's non-linearity and the intermediate
 * result requirement, it appears to me that it is provable that no
 * dramatic shortcut exists.
 *
 * The RNG delivers 32bit random numbers. All 32 bits are
 * used to encrypt an 8bit character:
 *    1. use 8bit to XOR the plaintext character
 *    2. use 8bit to select a random permutation (from set 1, see above)
 *    3. use 8bit to XOR the result of step 2
 *    4. use 8bit to select a random permutation (set 2)
 * Every bit of the RNG output will change the plain-to-cipher text
 * character mapping, but unlike the simple XOR case, it is not possible
 * to reconstruct the RNG output from a plain/cipher text pair (you
 * would have to guess about 24bits!).
 *
 * The strength of xcrypt is based on:
 *   1. a high quality RNG with plenty of state information.
 *   2. a computation intensive initialization phase
 *   3. 'information loss' in the encryption phase that
 *      prevents the reconstruction of the 'PAD' even in the
 *      known plain text case.
 *
 * Note: 'xcrypt' is a small just-for-fun program, but the underlying
 *       RNG was written and extensively tested as part of a serious
 *       research project.
 *
 * April, 1988  A. Nowatzyk
 *
 */

#include <stdio.h>
#include <sys/file.h>

char perm_tab1[0x10000];	/* permutation tables		*/
char perm_tab2[0x10000];

#include "xrand.c"

main(argc, argv)
int	argc;
char	*argv[];
{
    unsigned	    seed;
    char            buf[4];
    int             ifd, ofd;

    if (argc != 3 || 0 > (ifd = open(argv[1], O_RDONLY)) || 
        0 > (ofd = open(argv[2], O_WRONLY | O_CREAT, 0600))) {
	fprintf(stderr, "en/decrypt <input-file> <output-file>\n");
	exit(1);
    }

    if (*argv[0] == 'e' || *argv[0] == 'E') {	/** encryption **/

	seed = time(0l);	/* get an arbitrary seed	*/
	seed ^= getpid();

	get_key(seed);		/* get the key			*/

	buf[0] = seed;		/* write out the seed		*/
	buf[1] = seed >> 8;
	buf[2] = seed >> 16;
	buf[3] = seed >> 24;
	write(ofd, buf, 4);

	encrypt(ifd, ofd);
	
    } else {			/** decryption ******************/

	if (4 != read(ifd, buf, 4)) {	/* retrieve seed	*/
	    fprintf(stderr, "Can't read '%s'\n", argv[1]);
	    exit(1);
	}
	seed  =  buf[0]        & 0x000000ff;
	seed |= (buf[1] << 8)  & 0x0000ff00;
	seed |= (buf[2] << 16) & 0x00ff0000;
	seed |= (buf[3] << 24) & 0xff000000;

	get_key(seed);		/* get the key			*/

	inv_tab(perm_tab1);	/* invert permutation tables	*/
	inv_tab(perm_tab2);
	
	decrypt(ifd, ofd);
    }

    close(ifd);
    close(ofd);
    exit(0);
}

get_key(seed)
    unsigned seed;
{
    char            buf[1024];
    register int    i, j, k;
    static char    *key_chars = 
	"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    register char   t;

    rnd_init(seed);

    printf("Key:");		/* I know, there are better ways */
    gets(buf);

    for (i = 0, j = 0; buf[i] && i < 1024; i++)
	for (k = 0; key_chars[k]; k++)
	    if (buf[i] == key_chars[k]) {
		j++;
		Fib[(7 * k) % 55] ^= 625111 * k + rnd_u();
		buf[i] = '?';	/* munch key over		*/
		break;
	    }

    if (j < 10)
	fprintf(stderr, "Warning: your key is rather short\n");

    i = rnd_u();		/* initial permutation table 1	*/
    for (j = 0; j < 256; j++) {
	for (k = 0; k < 256; k++)
	    perm_tab1[j * 256 + k] = i + k;
	i++;
    }
    for (j = 30000 + rnd_ri(30000l); j--;) {	/* shuffle pt 1 */
	i = rnd_u();
	k = (i & 0xff00) | ((i >> 24) & 0xff);
	i &= 0xffff;
				/* the random number is broken into
				 * 3 parts, n1, n2, n3 of 1 byte each.
				 * the n1-th and n2-th elements of
                                 * the n3-th permutation are transposed.
                                 */
	t = perm_tab1[k];
	perm_tab1[k] = perm_tab1[i];
	perm_tab1[i] = t;
    }

    i = rnd_u();		/* initial permutation table 2	*/
    for (j = 0; j < 256; j++) {
	for (k = 0; k < 256; k++)
	    perm_tab2[j * 256 + k] = i + k;
	i++;
    }
    for (j = 30000 + rnd_ri(30000l); j--;) {	/* shuffle pt 2 */
	i = rnd_u();
	k = (i & 0xff00) | ((i >> 24) & 0xff);
	i &= 0xffff;
	t = perm_tab2[k];
	perm_tab2[k] = perm_tab2[i];
	perm_tab2[i] = t;
    }
}

inv_tab(pt)			/* compute inverse permutations */
    char *pt;
{
    register int i, j;
    char t[256];

    for (i = 0; i < 256; i++) {
	for (j = 0; j < 256; j++)
	    t[pt[i * 256 + j] & 0xff] = j;
	for (j = 0; j < 256; j++)
	    pt[i * 256 + j] = t[j];
    }
}

encrypt (ifd, ofd)		/* encrypt stuff		*/
    int ifd, ofd;
{
    register int i, j, k;
    register unsigned long u;
    register char *p;
    char buf[1024];

    while (0 < (i = read(ifd, buf, 1024))) {
	for (p = buf, j = i; j--; p++) {

	    u = rnd_u();		/* draw a random number */

	    k = *p & 0xff;		/* get char to encrypt	*/

	    k ^= u & 0xffff;		/* step 1		*/
	    k = perm_tab1[k] & 0xff;

	    k ^= (u >> 16) & 0xffff;	/* step 2		*/
	    *p = perm_tab2[k];
	}
	write(ofd, buf, i);
    }
}

decrypt (ifd, ofd)		/* decrypt stuff		*/
    int ifd, ofd;
{
    register int i, j, k;
    register unsigned long u;
    register char *p;
    char buf[1024];

    while (0 < (i = read(ifd, buf, 1024))) {
	for (p = buf, j = i; j--; p++) {

	    u = rnd_u();		/* draw a random number */

	    k = *p & 0xff;		/* get char to decrypt	*/

	    k |= (u >> 16) & 0xff00;	/* undo step 2		*/
	    k = (perm_tab2[k] ^ (u >> 16)) & 0xff;

	    k |= u & 0xff00;		/* undo step 1		*/
	    *p = perm_tab1[k] ^ u;
	}
	write(ofd, buf, i);
    }
}
