#include <stdio.h>

int	merrno;

char	*_merr_list[] = {
	"No error",
	"Interrupt occurred",
	"Dialer Hung",
	"No answer",
	"Illegal baud rate",
	"ACU Problem",
	"Line Problem",
	"Can't open LDEVS file",
	"Requested device not available",
	"Requested device not known",
	"No device available at requested baud",
	"No device known at requested baud"
};

int	_msys_nerr = (sizeof (_merr_list) / sizeof (char *));

merror (s)
char	*s;
{
	int	i = - merrno;

	if (0 <= i && i < _msys_nerr)
		fprintf (stderr, "%s: %s\n", s, _merr_list[i]);
	else
		fprintf (stderr, "%s: Error %d\n", s, merrno);
}
