static char error[] = "Out of memory\n";

int*
smalloc(size) /* "Safe" alloc */
{  int* retval = (int*)calloc(1,size);

   if (retval == 0)
	{ write(2, error, sizeof(error));
	  exit(-1);
	}
   else return retval;
}



sfree(ptr)
{
  if (ptr != 0) free(ptr);
}
