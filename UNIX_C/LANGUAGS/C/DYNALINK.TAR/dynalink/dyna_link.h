
typedef int ((*func_ptr)());

#define lk_undefd 1
#define lk_bad_format 2
#define lk_ok 0
#define lk_perror -1

extern char** lk_undefined;

func_ptr dynaload();

assoc_mem
lk_sym_hash();

struct nlist *
lk_get_symbols();

func_ptr
lk_dynaload();

func_ptr
lk_dynaload_fd();
