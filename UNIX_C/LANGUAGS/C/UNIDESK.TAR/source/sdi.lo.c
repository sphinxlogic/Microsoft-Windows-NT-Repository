/*
 *sdi.lo.c -- Simplified Desktop Interface environment -- low-level routines
 *(C) 1988 Ben Koning [556498717 408/738-1763 ben@ucscf.ucsc.edu]
 */





#include "unidesk.h"		/* Our own define's, plus external decs */





/******************* SDI LO-LEVEL DESKTOP ROUTINES ******************/
/* These routines are intended for internal SDI use only.  They im- */
/* plement some basic Apple Macintosh-like behavior out of the ADD  */
/* primitives, such as the implementation of a "menu bar", stacked  */
/* windows, etc.  These routines are used extensively by the high-  */
/* level SDI routines.                                              */
/********************************************************************/





SDIWindowInput (Object,String,Limit)

ADDObjectRecord	**Object;	/* Input:  ObjectRecordPtr of window  */
char		*String;	/* Output: Complete string as entered */
int		Limit;		/* Input:  Maximum number of charctrs */

/* This routine represents a first attempt to get input from inside a
   window.  Unfortunately, it blocks until a carriage return is recieved.
   WARNING: It is assumed that the tty driver is currently in CBREAK mode
   with ~ECHO, as it will be if the locator startup routine was called.
   The carriage return is not included within the output string.
   USAGE: SDIWindowInput (&FrontMostWindow,MyStrPtr) */

{
	extern 	int	ADDPutChar ();	/* Defined elsewhere */
	int		tx,ty;		/* Temporary curs X and Y store  */
	int		scroll = 0;	/* Number of scrolls occurred    */
	int		pos = 0;	/* Position within output string */
	char		echostr [2];	/* String for echoing input char */
	struct	sgttyb	tty;		/* For getting erase/kill chars  */
	ADDObjectRecord	*Top;		/* Are we on top? */

	ADDListFindObjectTop (&Top);
	if ( (Top != *Object) || ((*Object)->Type != ADDTYPEWINDOW) )
		return (-1);

	echostr [0] = echostr [1] = '\0';	/* Initialize */
	ioctl (0,TIOCGETP,&tty);		/* Get stdin tty record */
	while (echostr [0] != '\n')	/* Grab chars until carriage return */
	{
		/* Position cursor: */
		tx = (*Object)->X1 + (*Object)->CX+1;
		ty = (*Object)->Y1 + (*Object)->CY+1;
		tputs (tgoto (ADDTcapCursorMotion,tx,ty),1,ADDPutChar);
		ADDFlushChar ();

		/* Get stdin char and act upon it: */
		echostr [0] = getchar ();
		if (echostr [0] == tty.sg_erase) /* Backspace */
		{
			if (!pos) continue;		/* If start pos */
			echostr [0] = ADDSPACE;		/* Initialize   */
			if (--(*Object)->CX == -1)	/* Unwraparound... */
			{
				(*Object)->CX = (*Object)->X2 -
						(*Object)->X1 - 2;
				if (--scroll < 0) scroll = 0;
				if (--(*Object)->CY == -1)
					(*Object)->CY = 0;
			}
			tx = (*Object)->CX;		/* Save bs'ed pos */
			ty = (*Object)->CY;
			ADDWindowOutput (Object,echostr);  /* Erase char */
			(*Object)->CX = tx;
			(*Object)->CY = ty;		/* Rest bs'ed pos */
			pos--;				/* Dec out pos  */
		}

		else if (echostr [0] == tty.sg_kill) /* Kill (ctrl-U) */
		{
			if (!pos) continue;		/* If start pos */
			echostr [0] = ADDSPACE;		/* Initialize   */
			while (pos > 0)	      /* Do whole bunch of bs's */
			{
				if (--(*Object)->CX == -1)  /* Unwraparound */
				{
					(*Object)->CX = (*Object)->X2 -
							(*Object)->X1 - 2;
					if (--scroll < 0) scroll = 0;
					if (--(*Object)->CY == -1)
						(*Object)->CY = 0;
				}
				tx = (*Object)->CX;
				ty = (*Object)->CY;
				ADDWindowOutput (Object,echostr);
				(*Object)->CX = tx;
				(*Object)->CY = ty;
				pos--;
			}
		}

		else /* Not a special char */
		if ( (pos < Limit) || (echostr [0] == '\n') )  /* Buff full? */ 
		{
			scroll += ( ((*Object)->CY == 
				    ((*Object)->Y2-(*Object)->Y1-2)) &&
			            ( (echostr [0] == '\n') || 
			            ((*Object)->CX == 
				    ((*Object)->X2-(*Object)->X1-2)) ) );
							  /* About to scrl? */
			ADDWindowOutput (Object,echostr); /* Echo to window */
			String [pos++] = echostr [0];	  /* Add to outstr  */
		}
	}
	String [pos-1] = '\0';		/* Put EOS marker on top of newline */
	return (0);
}





SDISetNewObjectPosition (Object)

ADDObjectRecord	**Object;

/* This routine finds the "best" place to put the presumably just-created-
   but-still-not-visible object on the desktop.  It puts different objects
   at different places, and modifies the X1Y1X2Y2 fields of the object
   directly.  WARNING: The numerical constants hardcoded in this routine are
   rather subjective.  The current policy is to stack windows from near
   the UL corner, to build menus from UL corner to the right, and to
   build icons near the LL corner to the right and then up.  The assigned
   size for windows, for example, is 1/2 of screen size; they are
   spaced apart by 4 positions across and 2 positions down.
   USAGE: SDISetNewObjectPosition (&ObjectJustCreatedButStillHidden) */

{
	/* Subjective starting coordinates for drawing many of these obj: */
	if (SDIWindowNextX == -1)
		{ SDIWindowNextX = 7; SDIWindowNextY = 2; }
	if (SDIMenuNextX == -1)
		{ SDIMenuNextX = 0; SDIMenuNextY = 0; }
	if (SDIIconNextX == -1)
		{ SDIIconNextX = 0; SDIIconNextY = ADDScreenSizeY - 6; }

	switch ((*Object)->Type)
	{
		case ADDTYPEWINDOW :
			(*Object)->X1 = SDIWindowNextX;
			(*Object)->Y1 = SDIWindowNextY;
			(*Object)->X2 = SDIWindowNextX +
				(ADDScreenSizeX / 2);
			(*Object)->Y2 = SDIWindowNextY +
				(ADDScreenSizeY / 3);
			SDIWindowNextX += 4;   SDIWindowNextY += 2;
			if ( (ADDScreenSizeX - (*Object)->X2 < 10) ||
			     (ADDScreenSizeY - (*Object)->Y2 < 6) )
				SDIWindowNextX = -1;
		break;
		case ADDTYPEMENU :
			(*Object)->X1 = SDIMenuNextX;
			(*Object)->Y1 = SDIMenuNextY;
			SDIMenuNextX += (strlen ((*Object)->Name) + 4);
			if (ADDScreenSizeX - SDIMenuNextX < 10)
			{
				SDIMenuNextX = 0;
				if (ADDScreenSizeY - (SDIMenuNextY++) < 6)
					SDIMenuNextX = -1;
			}
		break;
		case ADDTYPEICON :
			(*Object)->X1 = SDIIconNextX;
			(*Object)->Y1 = SDIIconNextY;
			SDIIconNextX += (ADDScreenSizeX / 6);
			if (ADDScreenSizeX - SDIIconNextX < 10)
			{
				SDIIconNextX = 0;
				SDIIconNextY -= (ADDScreenSizeY / 6);
				if (ADDScreenSizeY - SDIIconNextY < 6)
					SDIIconNextX = -1;
			}
		break;
	}
}





SDIOpenShowMenuTitle (Object)

ADDObjectRecord	**Object;	/* Input: Should be just-created menu */

/* This routine opens and makes visible an icon with a null image
   string at the position of the menu title, as if adding a new
   menu to the "menu bar" on top of the screen. */

{
	ADDObjectRecord	*TheIcon;

	if ((*Object)->Type != ADDTYPEMENU)
		return (-1);
	ADDOpenObject ((*Object)->Name,(*Object)->DefProc,ADDTYPEICON,
		       NULL,(*Object)->X1-1,(*Object)->Y1-2,0,0,&TheIcon);
	/* Have the menu remember icon ptr so we can close it later: */
	(*Object)->MenuTitleIcon = TheIcon;
	/* Have the icon remember menu ptr so we know which menu if sel: */
	TheIcon->MenuTitleIcon = *Object;
	ADDShowObject (&TheIcon);
	return (0);
}





SDICloseHideMenuTitle (Object)

ADDObjectRecord	**Object;	/* Input: Should be just-created menu */

/* This routine hides and closes the icon with a null image string
   which was created by ADDOpenInstallMenuTitle, above. */

{
	if ((*Object)->Type != ADDTYPEMENU)
		return (-1);
	ADDCloseObject (&((*Object)->MenuTitleIcon));  /* Hide & Close */
	return (0);
}





/********************** CURSOR TRACKING ROUTINES *********************/
/* These routines track the current locator device with their own    */
/* respective cursors, sometimes dragging with them the "drag frame" */
/* to provide feedback on where the new position will be.  Most of   */
/* these routines block until something happens.  Most of these rou- */
/* tines will return new coordinates with which to call ADD hi-level */
/* movement and resizing routines.                                   */
/*********************************************************************/





SDITrackCursor (UpDown)

/* This routine tracks a standard crosshair cursor around the desktop,
   until the button goes up or down.  This routine is nonblocking; it returns
   immediately.  This routine will aways return with the cursor showing,
   unless the locator button went up or down.  However, it is not necessary
   to have the cursor showing before calling it for the first time.  This
   routine need not be the exclusive caller of ADDLocatorUpdate; that is
   why this routine maintains its own static variables for last position.
   However, it must have exclusive access to ADD/Show/Hide/Cursor.
   The parameter should be 1 if waiting for the button to go down; it
   should be 0 if waiting for the button to come up.  If the parameter is
   -1, then the only effect of calling this routine will be to make sure
   that the cursor is removed from the screen.  This should be done
   before outputting text to the frontmost window, for example.
   USAGE: if (SDITrackCursor (1)) { button went down... } */

{
	static int	CursorVisible;
	static int	OldX,OldY;
	int		Button;

	if (UpDown == -1)
	{
		if (CursorVisible)
		{
			ADDHideCursor (ADDCURSORICONPOINT,OldX,OldY);
			CursorVisible = 0;
		}
		return (0);
	}

	if (!CursorVisible)
	{
		OldX = ADDLocatorX; OldY = ADDLocatorY;
		ADDShowCursor (ADDCURSORICONPOINT,OldX,OldY);
		CursorVisible = 1;
	}
	Button = ADDLocatorUpdate ();
	if ( (OldX != ADDLocatorX) || (OldY != ADDLocatorY) )
	{
		ADDHideCursor (ADDCURSORICONPOINT,OldX,OldY);
		ADDShowCursor (ADDCURSORICONPOINT,ADDLocatorX,ADDLocatorY);
		OldX = ADDLocatorX; OldY = ADDLocatorY;
	}
	if ((!!Button) == UpDown)
	{
		ADDHideCursor (ADDCURSORICONPOINT,OldX,OldY);
		CursorVisible = 0;
		return (1);
	}
	else
		return (0);
}





SDITrackObjectMove (Object,NewX1,NewY1)

ADDObjectRecord	**Object;	/* Input:  Object to move    */
int		*NewX1;		/* Output: New X1 coordinate */
int		*NewY1;		/* Output: New Y1 coordinate */

/* This routine tracks the movement of any object around the desktop,
   using a special cursor and the drag frame.  It blocks until the user has
   selected a new size, and then returns new X1 and Y1 coordinates, ready
   to be handed to ADDMoveObject.  The object must be visible and frontmost,
   and the locator position should be close to or on top of the object.
   USAGE: if (move_event) button = SDITrackObjectMove (&ObjectToMove,&nx,&ny)
          ADDMoveObject (&ObjectToMove,nx,ny) */

/* Clip macro implementing "Mac" drag frame mvmnt w/o restricting curs mvmnt: */
#define SDIClipTrackObjectMove						       \
	ax1 = ox+dx1; ay1 = oy+dy1; ax2 = ox+dx2; ay2 = oy+dy2; 	       \
	if (ax1 < 0) {ax2 -= ax1; ax1 = 0;}				       \
	if (ay1 < 0) {ay2 -= ay1; ay1 = 0;}				       \
	if (ax2>ADDScreenSizeX){ax1-=(ax2-ADDScreenSizeX);ax2=ADDScreenSizeX;} \
	if (ay2>ADDScreenSizeY){ay1-=(ay2-ADDScreenSizeY);ay2=ADDScreenSizeY;}

{
	int		dx1,dy1,dx2,dy2;  /* Dragframe coords rltive to curs */
	int		ax1,ay1,ax2,ay2;  /* Actual clipped dragframe coords */
	int		ox,oy;		  /* For tracking cursor             */
	int		Button;		  /* Locator device button return    */
	ADDObjectRecord	*Top;		  /* Are we on top and visible?      */

	/* Make sure we're on top and visible: */
	ADDListFindObjectTop (&Top);
	if (Top != *Object)
		return (-1);

	/* Set initial oldx,y; get rel coords for frame; init curs limits: */
	ox  = ADDLocatorX;		oy  = ADDLocatorY;
	dx1 = (*Object)->X1 - ox;	dy1 = (*Object)->Y1 - oy;
	dx2 = (*Object)->X2 - ox;	dy2 = (*Object)->Y2 - oy;
	if ((dx2 - dx1) < 5)
		dx2 = dx1 + 5;
	if ((dy2 - dy1) < 3)
		dy2 = dy1 + 3;

	/* Draw initial graphics; always cursor on top of frame: */
	SDIClipTrackObjectMove;
	ADDShowDragFrame (ax1,ay1,ax2,ay2);
	ADDShowCursor (ADDCURSORICONMOVE,ox,oy);

	/* Track with our cursor and dragframe until button down: */
	do
	{
		Button = ADDLocatorUpdate ();
		if ( (ox != ADDLocatorX) || (oy != ADDLocatorY) || Button )
		{
			SDIClipTrackObjectMove;
			ADDHideCursor (ADDCURSORICONMOVE,ox,oy);
			ADDHideDragFrame (ax1,ay1,ax2,ay2);
			if (!Button)
			{
				ox = ADDLocatorX; oy = ADDLocatorY;
				SDIClipTrackObjectMove;
				ADDShowDragFrame (ax1,ay1,ax2,ay2);
				ADDShowCursor (ADDCURSORICONMOVE,ox,oy);
			}
		}
	}
	while (!Button);

	/* Return values: */
	*NewX1 = ax1;
	*NewY1 = ay1;
	return (Button);
}





SDITrackWindowResize (Object,NewX2,NewY2)

ADDObjectRecord	**Object;	/* Input:  Window to resize  */
int		*NewX2;		/* Output: New X2 coordinate */
int		*NewY2;		/* Output: New Y2 coordinate */

/* This routine tracks the resizing of a window.  It blocks until the
   resize is done, returning new X2 and Y2 coordinates ready to be
   handed to ADDWindowResize.  It uses a special cursor icon.  The
   given window must be frontmost and visible. 
   USAGE: if (resize_event) button = SDITrackWindowResize (&ObjWind,&nx,&ny)
          ADDWindowResize (&ObjWind,nx,ny) */

/* Clip macro implementing "Mac" drag frame mvmnt w/o restricting curs mvmnt: */
#define SDIClipTrackWindowResize					       \
	ax1 = (*Object)->X1; ay1 = (*Object)->Y1; ax2 = ox+rx2; ay2 = oy+ry2;  \
	if (ax2>ADDScreenSizeX) ax2 = ADDScreenSizeX; 			       \
	if (ay2>ADDScreenSizeY) ay2 = ADDScreenSizeY; 			       \
	if ((ax2-ax1)<8) ax2 = ax1+8; if ((ay2-ay1)<4) ay2 = ay1+4;

{
	int		ox,oy,rx2,ry2;	  /* For tracking cursor             */
	int		ax1,ay1,ax2,ay2;  /* Actual clipped dragframe coords */
	int		Button;		  /* Locator device button return    */
	ADDObjectRecord	*Top;		  /* Are we on top and visible?      */

	/* Make sure we're on top and visible and a window: */
	ADDListFindObjectTop (&Top);
	if ( (Top != *Object) || ((*Object)->Type != ADDTYPEWINDOW) )
		return (-1);

	/* Set initial old x,y; initialize relative x2,y2: */
	ox  = ADDLocatorX;		oy  = ADDLocatorY;
	rx2 = (*Object)->X2 - ox; 	ry2 = (*Object)->Y2 - oy;

	/* Draw initial graphics; always cursor on top of frame: */
	SDIClipTrackWindowResize;
	ADDShowDragFrame (ax1,ay1,ax2,ay2);
	ADDShowCursor (ADDCURSORICONRESIZE,ox,oy);

	/* Track with our cursor and dragframe until button down: */
	do
	{
		Button = ADDLocatorUpdate ();
		if ( (ox != ADDLocatorX) || (oy != ADDLocatorY) || Button )
		{
			SDIClipTrackWindowResize;
			ADDHideCursor (ADDCURSORICONRESIZE,ox,oy);
			ADDHideDragFrame (ax1,ay1,ax2,ay2);
			if (!Button)
			{
				ox = ADDLocatorX; oy = ADDLocatorY;
				SDIClipTrackWindowResize;
				ADDShowDragFrame (ax1,ay1,ax2,ay2);
				ADDShowCursor (ADDCURSORICONRESIZE,ox,oy);
			}
		}
	}
	while (!Button);

	/* Return values: */
	*NewX2 = ax2;
	*NewY2 = ay2;
	return (Button);
}





int	(*SDITrackMenuSelect (Object,OptionalName)) ()

ADDObjectRecord	**Object;	/* Input:  Menu (title) that was selected */
char		**OptionalName;	/* Output: Name string of item selected   */

/* This routine tracks the menu item selection procedure, blocking,
   drawing the menu body underneath the menu title, using a special
   cursor, and undrawing the menu body before returning.  During the
   selection process the menu item underneath the cursor at any time
   is highlighted.  If an item is selected, it is blinked a few times
   using (un)highlighting, in order to confirm the choice.  If the object
   isn't a menu, an error is returned.  If nothing is selected,
   then NULL is returned; else the approriate DefProc is returned.
   USAGE: menu_item_defproc = SDITrackMenuSelect (&MenuObjectRecord) */

{
	int		ox,oy;			/* Old XY for tracking   */
	int		Button;			/* Is button down yet?   */
	ADDItemRecord	*TheItem;		/* Item we now on top of */
	ADDItemRecord	*LastItem = NULL;	/* Item we were on tp of */

	/* Set default: */
	*OptionalName = NULL;

	/* Make sure we're a menu.  Of course, it won't yet be frontmost */
	/* (Currently only menu title icon is shown): */
	if ((*Object)->Type != ADDTYPEMENU)
		return ((int (*) ()) -1);

	/* Step one: Show full menu object (ie, "pull it down") */
	ADDShowObject (Object);

	/* Step two: Track with cursor until button; erase cursor when done */
	/* (Highlighting each menu item as we cross over it): */
	ox = ADDLocatorX; oy = ADDLocatorY;
	ADDListFindItemByLoc (Object,&TheItem,ox,oy);
	if (TheItem != NULL)
	{
		ADDShowItemHilite (&TheItem);
		LastItem = TheItem;
	}
	ADDShowCursor (ADDCURSORICONSELECT,ox,oy);
	do
	{
		Button = ADDLocatorUpdate ();
		if ( (ox != ADDLocatorX) || (oy != ADDLocatorY) || Button )
		{
			ADDHideCursor (ADDCURSORICONSELECT,ox,oy);
			if (!Button)
			{
				ox = ADDLocatorX; oy = ADDLocatorY;
				ADDListFindItemByLoc (Object,&TheItem,ox,oy);
				if (TheItem != LastItem)
				{
					if (LastItem != NULL)
						ADDHideItemHilite (&LastItem);
					if (TheItem != NULL)
						ADDShowItemHilite (&TheItem);
					LastItem = TheItem;
				}
				ADDShowCursor (ADDCURSORICONSELECT,ox,oy);
			}
		}
	}
	while (!Button);

	/* Step three: do blinking to confirm user's choice, if any: */
	if (TheItem != NULL)
		for (ox = 0;   ox < SDINUMBLINK;   ox++)
		{
			ADDHideItemHilite (&TheItem);
			ADDShowItemHilite (&TheItem);
		}

	/* Step four: Hide full menu, re-revealing menu title underneath: */
	ADDHideObject (Object);

	/* Step five: Return either DefProc or NULL: */
	*OptionalName = ( (TheItem == NULL) ? NULL : TheItem->Name );
	return ( (TheItem == NULL) ? (int (*) ()) NULL : TheItem->DefProc );
}





int	(*SDIDesktopManager (OptionalName)) ()

char	**OptionalName;		/* Optional output: Name of selection */

/* This routine is usually nonblocking, normally returning immediately
   with NULL.  It should be called very frequently; the responsiveness of
   the user interface depends on it.  This routine tracks the cursor, and
   blocks while calling the tracking routines above to handle any movement
   or resizing of objects.  Thus, all aspects of (non- opening/closing)
   desktop management is taken care of.  If a selection event occurred, then
   the selected object/item's DefProc is returned instead of NULL.
   If this routine returns with a DefProc, then the cursor is removed before
   exiting; else it is left on the screen.  The decisions governing the
   calling of the tracking routines above are in the following hierarchy:

	(1) If hit in X1Y1X2Y2 or NX1X2Y then bring to front and hilite.
	(2) If hit in NX1X2Y then move.
	(3) If hit in box 25% big around X2Y2 then resize.

   USAGE: if (ProcPtr = SDIDesktopManager()) { Call the user's DefProc } or
          if (SDIDesktopManager (String)) { String now contains sel. name ) */

{ 
	int		HitX,HitY;	/* Where locator went down */
	int		NewX,NewY;	/* Output from tracking    */
	int		IsMenu;		/* Is it a menu/menu_icon? */
	int		(*HitProc) ();	/* Return from menu select */
	ADDObjectRecord	*HitObject;	/* Object hit, if any      */
	ADDObjectRecord	*Top;		/* Current topmost object  */

	/* Set default: */
	*OptionalName = NULL;

	/* Track cursor for normal motion without anything happening: */
	if (!SDITrackCursor (1))
		return ((int (*) ()) NULL);

	/* Wait for button-up again, blocking; save old coordinates: */
	HitX = ADDLocatorX; HitY = ADDLocatorY;
	while (!SDITrackCursor (0));

	/* Ascertain what object has been hit, if any: */
	ADDListFindObjectByLoc (&HitObject,HitX,HitY);
	if (HitObject == NULL)
		return ((int (*) ()) NULL);
	IsMenu = ( (HitObject->Type == ADDTYPEMENU) ||
		  ((HitObject->Type == ADDTYPEICON) &&
		   (HitObject->MenuTitleIcon != NULL)) );

	/* If object not menu_icon and not topmost, then BRINGTOFRONT EVENT: */
	if (!IsMenu)
	{
		ADDListFindObjectTop (&Top);
		if (HitObject != Top)
		{
			ADDBringObjectToFront (&HitObject);
			return ((int (*) ()) NULL);
		}
	}

	/* If hit in name area, and not a menu then MOVE EVENT: */
	if ( (HitX >= HitObject->NX1) 	&& 
	     (HitX <= HitObject->NX2) 	&&
	     (HitY == HitObject->NY)  	&& 
	     (!IsMenu) )
	{
		ADDShowObjectHilite	(&HitObject);
		SDITrackObjectMove	(&HitObject,&NewX,&NewY);
		ADDHideObjectHilite	(&HitObject);
		ADDMoveObject		(&HitObject,NewX,NewY);
		while (!SDITrackCursor (0));
		return ((int (*) ()) NULL);
	}

	/* If in name area, and a menu/menu_icon, MENU SELECT EVENT: */
	if ( (HitX >= HitObject->NX1) 			&& 
	     (HitX <= HitObject->NX2) 			&&
	     (HitY == HitObject->NY)  			&& 
	     (IsMenu) )
	{
		if (HitObject->Type == ADDTYPEMENU)
			HitProc = SDITrackMenuSelect
				  (&HitObject,
				  OptionalName);
		else
			HitProc = SDITrackMenuSelect 
				  (&(HitObject->MenuTitleIcon),
				  OptionalName);
		while (!SDITrackCursor (0));
		return (HitProc);
	}

	/* If topmost and hit in resize area and a window then RESIZE EVENT: */
	if ( (HitObject->Type == ADDTYPEWINDOW)			&& 
	     (HitX >= (HitObject->X2 - SDIHITWINDOWRESIZEX))	&&
	     (HitX <= (HitObject->X2))				&&
	     (HitY >= (HitObject->Y2 - SDIHITWINDOWRESIZEY))	&&
	     (HitY <= (HitObject->Y2)) )
	{
		ADDShowObjectHilite	(&HitObject);
		SDITrackWindowResize	(&HitObject,&NewX,&NewY);
		ADDHideObjectHilite	(&HitObject);
		ADDWindowResize		(&HitObject,NewX,NewY);
		while (!SDITrackCursor (0));
		return ((int (*) ()) NULL);
	}

	/* If topmost and we're still here then OBJECT SELECT EVENT: */
	if (HitObject->Type != ADDTYPEMENU)
		for (NewX = 0;   NewX < SDINUMBLINK;   NewX++)
		{
			ADDShowObjectHilite (&HitObject);
			ADDHideObjectHilite (&HitObject);
		}
	/* Leave it unhilited... */
	while (!SDITrackCursor (0));
	*OptionalName = HitObject->Name;
	return (HitObject->DefProc);
}



