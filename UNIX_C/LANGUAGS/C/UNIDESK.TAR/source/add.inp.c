/*
 *add.inp.c -- Position input ("locator"), cursor/hilite/move-action routines
 *(C) 1988 Ben Koning [556498717 408/738-1763 ben@ucscf.ucsc.edu]
 */





#include "unidesk.h"		/* Our own define's, plus external decs */





/****************** GENERALIZED LOCATOR INPUT ROUTINES *******************/
/*                                                                       */
/* These routines provide an easy-to-use, device-independent means of    */
/* gathering analog positional input from the user.  They exploit spec-  */
/* ialized hardware such as a mouse or a bitpad/tablet when available,   */
/* but can also automatically revert to a simple keyboard interface,     */
/* which is able to take advantage of special moving keys if available.  */
/* The globals ADDLocatorDevice, ADDLocatorX, and ADDLocatorY are set by */
/* these routines.                                                       */
/*                                                                       */
/* In order to support a NEW input device, do the following:  (1) Add    */
/* a new #define'd ID number in the file unidesk.h.  (2) Add a new case  */
/* for the device in ADDLocatorStartUp.  (3) Add a new case for the de-  */
/* vice in ADDLocatorShutDown.  (4) Add a new case in ADDLocatorUpdate.  */
/* (5) Add a new startup routine for the device.  (6) Add a new shutdown */
/* routine for the device.  (7) Add a new status/coordinate update rou-  */
/* tine.  The latter three should be placed in the section immediately   */
/* following the next three routines.                                    */
/*                                                                       */
/*************************************************************************/





ADDLocatorStartUp (DeviceRequest)

/* Explicit Input Parameter:	Locator-ID of dev desired or 0 for autoscan */
/* Implicit Output Parameter:	Global ADDLocatorDevice updated if success  */
/* Return Value:		-1 Error if locator could not be found      */

/* This routine attempts to initialize the locator user-input device whose
   ID number is given.  If successful, then the cursor coordinate globals
   ADDLocatorX and ADDLocatorY will be reset to somewhere on the desktop,
   and the global ADDLocatorDevice set to the ID of the new device.  If
   "0" is given for the device ID, then this routine will attempt to
   initialize devices with successively higher ID's until successful (thus
   if the system does not have a mouse, it will try to initialize for a
   bitpad/tablet, then for a keyboard, and so on).
   If the routine cannot find a default or requested input device, then it
   will return with an error, leaving the global ADDLocatorDevice, as
   well as the globals ADDLocatorX and ADDLocatorY, unchanged.
   This routine is called by ADDStartUp with a "0" parameter, so it should
   be called afterward only to select a nondefault input device.
   Warning: This routine may cause a few garbage characters to be output
   while initializing some devices; refresh the screen after calling.  Also,
   it is not advisable to startup several input devices without shutting
   them down first, although this is not prevented.
   USAGE EXAMPLES: ADDLocatorStartUp (0)
                   ADDLocatorStartUp (ADDLOCATORTABLET) */

{
	int	DeviceTry = 1;	/* Device currently trying to start up   */
	int	Success   = 0;	/* Started up a device successfully yet? */

	/* Start the scan either at device 1, or the requested device: */
	if (DeviceRequest)
		DeviceTry = DeviceRequest;

	/* Scan until device found, or do the following only once: */
	do
	{
		switch (DeviceTry)
		{
			case ADDLOCATORMOUSE :
				Success = (ADDLocator_mousestartup_() != -1);
				break;
			case ADDLOCATORBITPAD :
				Success = (ADDLocator_bitpadstartup_() != -1);
				break;
			case ADDLOCATORTABLET :
				Success = (ADDLocator_tabletstartup_() != -1);
				break;
			case ADDLOCATORKEYBOARD :
				Success = (ADDLocator_keyboardstartup_() != -1);
				break;
			default:;
		}
		DeviceTry++;
	}
	while ( (!Success) && (!DeviceRequest) && (DeviceTry < 256) );

	/* Finish up according to how things went: */
	if (Success)
	{
		ADDLocatorDevice = DeviceTry - 1;
		if (ADDLocatorDevice != ADDLOCATORKEYBOARD)
			ADDLocator_keyboardstartup_();   /* Keybd always on */
		ADDLocatorX = 5;
		ADDLocatorY = 2;
		return (0);
	}
	else
		return (-1);
}





ADDLocatorShutDown ()

/* This routine attempts to shut down the current locator-input device,
   deallocating any resources used or returning them to a sane state
   (as is the case with the keyboard).  This routine should be called
   before attempting to start up another input device.  This routine
   is called by ADDShutDown.
   USAGE:  ADDLocatorShutDown () */

{
	if (ADDLocatorDevice != ADDLOCATORKEYBOARD)
		ADDLocator_keyboardshutdown_();   /* Keybd always on */
	switch (ADDLocatorDevice)
	{
		case ADDLOCATORMOUSE : 
			return (ADDLocator_mouseshutdown_());
		case ADDLOCATORBITPAD :
			return (ADDLocator_bitpadshutdown_());
		case ADDLOCATORTABLET :
			return (ADDLocator_tabletshutdown_());
		case ADDLOCATORKEYBOARD :
			return (ADDLocator_keyboardshutdown_());
		default : return (-1);
	}
}





ADDLocatorUpdate ()

/* Implicit Input Parameter:	ADDLocatorDevice global for selecting device */
/* Implicit Output Parameter:	ADDLocatorX global variable is set to nw pos */
/* Implicit Output Parameter:	ADDLocatorY global variable is set to nw pos */
/* Return Value (Output): 	Integer	containing the bits of the button(s) */

/* This routine reads the locator device given by the ADDLocatorDevice
   global variable.  The globals ADDLocatorX and ADDLocatorY are updated
   with new absolute positions on the desktop scaled to the range
   0..ADDScreenSizeX and 0..ADDScreenSizeY, respectively.  The return
   value contains the state(s) of any buttons(s) on the locator in
   positive-logic bitwise format; hence the (usual) return value of zero
   indicates no button-push event occurred, and nonzero indicates otherwise.
   This routine returns immediately; it must be called repeatedly for
   cursor tracking, etc.
   USAGE: if (ADDLocatorUpdate ()) { Button down; check coordinates... } */

{
	int	rc;

	switch (ADDLocatorDevice)
	{
		case ADDLOCATORMOUSE :
			rc = ADDLocator_mouseupdate_();
			break;
		case ADDLOCATORBITPAD:
			rc = ADDLocator_bitpadupdate_();
			break;
		case ADDLOCATORTABLET :
			rc = ADDLocator_tabletupdate_();
			break;
		case ADDLOCATORKEYBOARD :
			rc = ADDLocator_keyboardupdate_();
			break;
		default : 
			rc = -1;  /* Should never happen */
			break;
	}

	if (ADDLocatorX > ADDScreenSizeX)
		ADDLocatorX = ADDScreenSizeX;
	if (ADDLocatorX < 0)
		ADDLocatorX = 0;
	if (ADDLocatorY > ADDScreenSizeY)
		ADDLocatorY = ADDScreenSizeY;
	if (ADDLocatorY < 0)
		ADDLocatorY = 0;

	return (rc);
}





/**************** LOW-LEVEL LOCATOR INPUT DEVICE DRIVERS: *****************/
/*                                                                        */
/* These routines are for private use only, and are called by the three   */
/* locator-input interface routines above.  This is where the "startup",  */
/* "shutdown", and "update" device driver routines for a new locator de-  */
/* vice should go.  Each "startup" routine MUST return -1 on error, and   */
/* set any globals its "update" routine may need later on, such as        */
/* ADDLocatorFDS.  Each "update" routine MUST return -1 on error, and if  */
/* successful it MUST update ADDLocatorX and ADDLocatorY, scaling them to */
/* the current screen dimensions, and it MUST return the status of its    */
/* button(s).  However, it should not make sure that the new coordinates  */
/* be within screen range; that is done elsewhere (it is done this way    */
/* for possible future reasons).  The "shutdown" routine should deallo-   */
/* cate/return to normal any resources allocated/altered while starting   */
/* up the device.                                                         */
/*                                                                        */
/* Some of these device drivers are based on those written by Jim Murphy; */
/* some of them were written by the author; all of them exhibit awful     */
/* coding style.  But they work :-).                                      */
/*                                                                        */
/**************************************************************************/





ADDLocator_mousestartup_ ()

/* Device: Logitech serial PC-Mouse */

{
	struct sgttyb 	tty;
	char 		buf [10], *puff;
	int		FFlags, nbytes, bytes_read, tryread, time, fd;

	if ((fd = open ("/dev/tty1a", O_RDWR | O_NDELAY)) == -1)
		return (-1);   /* I/O Error */
	ADDLocatorFDS = fd;

	ioctl (ADDLocatorFDS,TIOCGETP,&tty);
	tty.sg_ispeed = tty.sg_ospeed = B1200;
	ioctl (ADDLocatorFDS,TIOCSETP,&tty);
	buf[0]='*'; 
	buf[1]='q';
	write(fd,buf,2);
	tty.sg_ispeed = tty.sg_ospeed = B9600;
	ioctl (ADDLocatorFDS,TIOCSETP,&tty);
	sleep (1);
	tty.sg_flags |= RAW;
	ioctl (ADDLocatorFDS,TIOCSETP,&tty);

	buf[0] = 'D';
	write (ADDLocatorFDS,buf,1); /* Sample or prompt mode */
	buf[0] = 'T';
	write (ADDLocatorFDS,buf,1); /* Three binary bytes mode: button X Y */

	/* Done init; now make sure it's not comatose and really a mouse */
	FFlags = fcntl (ADDLocatorFDS,F_GETFL,0);
	buf [0] = 'P';
	write (ADDLocatorFDS,buf,1);
	tryread = 3;
	puff = buf;
	bytes_read = time = 0;
	while (bytes_read < tryread)
	{
		fcntl (ADDLocatorFDS,F_SETFL,FFlags | O_NDELAY);
		for (time = ADDTIMEOUT;   time > 0;   time--)
			if ( (nbytes = read (ADDLocatorFDS,puff,
		 	     (tryread-bytes_read))) > 0 )
				break;
		fcntl (ADDLocatorFDS,F_SETFL,FFlags);
		if (!time)
			return (-1);   /* Timeout; not a mouse */
		puff += nbytes;
		bytes_read += nbytes;
	}
	if ( (int)buf[0]<8 && (int)buf[0]>-1 && (int)buf[1]<16 && 
	     (int)buf[1]>-16 && (int)buf[2]<16 && (int)buf[2]>-16 )
		return (0); 	/* Successful */
	else
		return (-1);	/* Not a mouse */
}





ADDLocator_mouseshutdown_ ()

/* Device: Logitech serial PC-Mouse */

{
	return (close (ADDLocatorFDS));
}





ADDLocator_mouseupdate_ ()

/* Device: Logitech serial PC-Mouse */

{
	char 	buf [256];
	char 	*puff;
	int 	nbytes, bytes_read, tryread, time;
	int 	FFlags;

	FFlags = fcntl (ADDLocatorFDS,F_GETFL,0);
	buf [0] = 'P';
	write (ADDLocatorFDS,buf,1);
	tryread = 3;
	puff = buf;
	bytes_read = time = 0;
	while (bytes_read < tryread)
	{
		fcntl (ADDLocatorFDS,F_SETFL,FFlags | O_NDELAY);
		for (time = ADDTIMEOUT;   time > 0;   time--)
			if ( (nbytes = read (ADDLocatorFDS,puff,
		 	     (tryread-bytes_read))) > 0 )
				break;
		fcntl (ADDLocatorFDS,F_SETFL,FFlags);
		if (!time)
			return (0);   /* Timeout */
		puff += nbytes;
		bytes_read += nbytes;
	}
	ADDLocatorX += ((int)buf[1] * ADDScreenSizeX) / 500;
	ADDLocatorY -= ((int)buf[2] * ADDScreenSizeY) / 500;
	return ((int) buf[0]);
}





ADDLocator_bitpadstartup_ ()

/* Device: Summagraphics Bitpad One */

{
	struct	sgttyb	tty;
	char 	buf [256], *puff;
	int 	FFlags, nbytes, bytes_read, tryread, time, fd;

	if ((fd = open ("/dev/tty1a", O_RDWR | O_NDELAY)) == -1) 
		return (-1);  /* I/O Error */
	ADDLocatorFDS = fd;

	ioctl (ADDLocatorFDS,TIOCGETP,&tty);
	tty.sg_ispeed = B9600;
	tty.sg_ospeed = B9600;
	tty.sg_flags |= RAW;
	ioctl (ADDLocatorFDS,TIOCSETP,&tty);

	/* Done init; now make sure it's not comatose and really a bitpad: */
	FFlags = fcntl (ADDLocatorFDS,F_GETFL,0);
	tryread = 26;
	puff = buf;
	bytes_read = time = 0;
	while (bytes_read < tryread)
	{
		fcntl (ADDLocatorFDS,F_SETFL,FFlags | O_NDELAY);
		for (time = ADDTIMEOUT;   time > 0;   time--)
			if ( (nbytes = read (ADDLocatorFDS,puff,
		 	     (tryread-bytes_read))) > 0 )
				break;
		fcntl (ADDLocatorFDS,F_SETFL,FFlags);
		if (!time)
			return (-1);   /* Timeout: no bitpad connected */
		puff += nbytes;
		bytes_read += nbytes;
	}
	for (time = 0;   time < 26;   time++)
		if (buf [time] == '\12')
			return (0);			/* Successful */
	return (-1);   /* Not a bitpad */
}





ADDLocator_bitpadshutdown_ ()

/* Device: Summagraphics Bitpad One */

{
	return (close (ADDLocatorFDS));
}





ADDLocator_bitpadupdate_ ()

/* Device: Summagraphics Bitpad One */

{
	char 	buf [256];
	char 	*puff;
	int 	nbytes, bytes_read, tryread, start, ct, time;
	int	FFlags;

	FFlags = fcntl (ADDLocatorFDS,F_GETFL,0);
	tryread = 26;
	puff = buf;
	bytes_read = time = 0;
	while (bytes_read < tryread)
	{
		fcntl (ADDLocatorFDS,F_SETFL,FFlags | O_NDELAY);
		for (time = ADDTIMEOUT;   time > 0;   time--)
			if ( (nbytes = read (ADDLocatorFDS,puff,
		 	     (tryread-bytes_read))) > 0 )
				break;
		fcntl (ADDLocatorFDS,F_SETFL,FFlags);
		if (!time)
			return (0);   /* Timeout */
		puff += nbytes;
		bytes_read += nbytes;
	}
	start = 0;
	while (buf [start++] != '\12');
	if (start == 13)
		start = 0;
	for (ct = start;   ct < start+12;   ct++)
		buf [ct] = buf [ct] & 0x7f;
	buf [start+9] = 0;
	ADDLocatorY = ADDScreenSizeY - 
		      (((atoi(buf+start+5)-700)*ADDScreenSizeY) / 1300);
	buf [start+4] = 0;
	ADDLocatorX = ((atoi(buf+start)-75) * ADDScreenSizeX) / 1700;
	ct = buf [start+10];
	if (ct < 58)
		return (ct - '0');
	else
		return (ct - 'A' + 10);
}





ADDLocator_tabletstartup_ ()

/* Device: GTCO DigiPad 5 */

{
	char 	buff [256];
	int	twice, FFlags, time, fd;

	if ((fd = open ("/dev/tty2a", O_RDWR | O_NDELAY)) == -1)
		return (-1);  /* I/O Error */
	ADDLocatorFDS = fd;

	FFlags = fcntl (ADDLocatorFDS,F_GETFL,0);
	for (twice = 1;   twice != 3;   twice++)
	{
		buff [0] = '\33';   buff [1] = '\1';   buff [2] = '\15';
		write (ADDLocatorFDS,buff,3);
		fcntl (ADDLocatorFDS,F_SETFL,FFlags | O_NDELAY);

		time = 0;
		while ((buff [0] != '\15') && (++time < ADDTIMEOUT))
			read (ADDLocatorFDS,buff,1);
		if (time == ADDTIMEOUT) goto timeout;

		buff [0] = '\1';
		time = 0;
		while ((buff [0] != '\15') && (++time < ADDTIMEOUT))
			read (ADDLocatorFDS,buff,1);
		if (time == ADDTIMEOUT) goto timeout;

		if (twice == 1) { buff [0] = 'R'; buff [1] = 'S'; }
		if (twice == 2) { buff [0] = 'C'; buff [1] = 'N'; }
		buff [3] = '\15';
		write (ADDLocatorFDS,buff,3);

		time = 0;
		while ((buff [0] != '\15') && (++time < ADDTIMEOUT))
			read (ADDLocatorFDS,buff,1);
		if (time == ADDTIMEOUT) goto timeout;

		buff [0] = '\1';
		time = 0;
		while ((buff [0] != '\15') && (++time < ADDTIMEOUT))
			read (ADDLocatorFDS,buff,1);
		if (time == ADDTIMEOUT) goto timeout;

		fcntl (ADDLocatorFDS,F_SETFL,FFlags);
		sleep (1);
		buff [0] = '\33';
		write (ADDLocatorFDS,buff,1);
		ioctl (ADDLocatorFDS,21511/*TCFLSH*/,0);
	}
	
	/* Enough action above; need not test if comatose */
	return (0);				/* Successful */

	/* Do timeout cases: */
	timeout:
	fcntl (ADDLocatorFDS,F_SETFL,FFlags);
	return (-1);
}





ADDLocator_tabletshutdown_ ()

/* Device: GTCO DigiPad 5 */

{
	return (close (ADDLocatorFDS));
}





ADDLocator_tabletupdate_ ()

/* Device: GTCO DigiPad 5 */

{
	char 	buf [256];
	char 	*puff;
	int 	nbytes, bytes_read, tryread, time;
	int	FFlags;

	FFlags = fcntl (ADDLocatorFDS,F_GETFL,0);
	tryread = 11;
	puff = buf;
	bytes_read = time = 0;
	while (bytes_read < tryread)
	{
		fcntl (ADDLocatorFDS,F_SETFL,FFlags | O_NDELAY);
		for (time = ADDTIMEOUT;   time > 0;   time--)
			if ( (nbytes = read (ADDLocatorFDS,puff,
		 	     (tryread-bytes_read))) > 0 )
				break;
		fcntl (ADDLocatorFDS,F_SETFL,FFlags);
		if (!time)
			return (0);   /* Timeout */
		puff += nbytes;
		bytes_read += nbytes;
	}
	buf[10] = 0;
	ADDLocatorY = ADDScreenSizeY - ((atoi(buf+5)*ADDScreenSizeY) / 1024);
	buf[5]=0;
	ADDLocatorX = (atoi(buf+1) * ADDScreenSizeX) / 1024;
	return (buf[0] - '0');
}





ADDLocator_keyboardstartup_ ()

/* Device: Stdin keyboard, using termcap */

{
	struct sgttyb	tty;		/* Modifying stdin tty parameters */

	/* Save old parameters for shutdown: */
	ioctl (0,TIOCGETP,&ADDLocatorIFL);

	/* Set stdin tty to be nonechoeing and nonwaiting: */
	ioctl (0,TIOCGETP,&tty);
	tty.sg_flags |= CBREAK;
	tty.sg_flags &= ~ECHO;
	return (ioctl (0,TIOCSETP,&tty));
}





ADDLocator_keyboardshutdown_ ()

/* Device: Stdin keyboard, using termcap */

{
	int	FFlags;

	/* Restore old flags from startup: */
	FFlags = fcntl (0,F_GETFL,0);
	fcntl (0,F_SETFL,FFlags & ~O_NDELAY);
	return (ioctl (0,TIOCSETP,&ADDLocatorIFL));
}





ADDLocator_keyboardupdate_ ()

/* Device: Stdin keyboard, using termcap */

{
	char		Buffer [9];	/* Input character buffer      */
	int		Index;		/* Position within Buffer      */
	int		EventKey = 0;	/* Key hit after we've decoded */
	int		FFlags;		/* File control flags on stdin */
	int		RR;		/* Result from read ()         */
	int		Timer;		/* Timeout on wait 2nd+ chars  */

	/* Try to read a movement command (may be more than 1 char);   */
	/* throw away all keyboard characters that we can't recognize: */
	/* Note that the termcap kX string pointers can also be NULL!  */
	FFlags = fcntl (0,F_GETFL,0);
	fcntl (0,F_SETFL,FFlags | O_NDELAY);
	for (Index = 0;   Index <= 7;   Index++)
	{
		Buffer [Index + 1] = '\0';

		/* Waste time waiting until input without using a timer... */
		if (!Index)
			RR = read (0,&(Buffer[Index]),1);
		else
			for (Timer = ADDTIMEOUT;   Timer > 0;   Timer--)
				if ( (RR = read (0,&(Buffer[Index]),1)) > 0 )
					break;
		if (RR < 1)
			break;
		else
		{
			if (!Index)
			{
				if (Buffer [0] == ADDKEYUP)
					{ EventKey = 1;  break; }
				if (Buffer [0] == ADDKEYUPFAST)
					{ EventKey = -1; break; }
				if (Buffer [0] == ADDKEYRIGHT)
					{ EventKey = 2;  break; }
				if (Buffer [0] == ADDKEYRIGHTFAST)
					{ EventKey = -2; break; }
				if (Buffer [0] == ADDKEYDOWN)
					{ EventKey = 3;  break; }
				if (Buffer [0] == ADDKEYDOWNFAST)
					{ EventKey = -3; break; }
				if (Buffer [0] == ADDKEYLEFT)
					{ EventKey = 4;  break; }
				if (Buffer [0] == ADDKEYLEFTFAST)
					{ EventKey = -4; break; }
				if (Buffer [0] == ADDKEYBUTTON)
					{ EventKey = 5;  break; }
			}
			if ( (ADDTcapKeyUp    == NULL) 	&& 
			     (ADDTcapKeyRight == NULL)	&&
			     (ADDTcapKeyDown  == NULL)	&&
			     (ADDTcapKeyLeft  == NULL) )
				break;
			if (ADDTcapKeyUp != NULL)
				if (!strcmp (ADDTcapKeyUp,Buffer))
				{
					EventKey = 1;
					break;
				}
			if (ADDTcapKeyRight != NULL)
				if (!strcmp (ADDTcapKeyRight,Buffer))
				{
					EventKey = 2;
					break;
				}
			if (ADDTcapKeyDown != NULL)
				if (!strcmp (ADDTcapKeyDown,Buffer))
				{
					EventKey = 3;
					break;
				}
			if (ADDTcapKeyLeft != NULL)
				if (!strcmp (ADDTcapKeyLeft,Buffer))
				{
					EventKey = 4;
					break;
				}
		}
	}
	fcntl (0,F_SETFL,FFlags);

	/* Update locator status globals: */
	switch (EventKey)
	{
		case  0 :				/* Nothing, as usual */
			   break;
		case  1 :  ADDLocatorY--;		/* Key up */
			   break;
		case -1 :  ADDLocatorY -= ADDNUMFASTY;	/* Fast key up */
			   break;
		case  2 :  ADDLocatorX++;		/* Key right */
			   break;
		case -2 :  ADDLocatorX += ADDNUMFASTX;	/* Fast key right */
			   break;
		case  3 :  ADDLocatorY++;		/* Key down */
			   break;
		case -3 :  ADDLocatorY += ADDNUMFASTY;	/* Fast key down */
			   break;
		case  4 :  ADDLocatorX--;		/* Key left */
			   break;
		case -4 :  ADDLocatorX -= ADDNUMFASTX;	/* Fast key left */
			   break;
		case  5 :  return (1);			/* Button */
			   break;
	}
	return (0);
}





/************ INPUT-EVENT - RELATED HILEVEL DRAWING ROUTINES *************/
/* The following routines draw things on or about objects, to be used in */
/* response to user input events in order to provide ergonomic feedback. */
/* Some of these should only be done to frontmost objects; for example,  */
/* highlighting simply involves drawing characters to either side of the */
/* "Name" (title) string given in the appropriate Item- or Object-       */
/* Record (This is why, by convention, all title strings are bordered by */
/* spaces in the medium-level drawing routines).  WARNING: Although it   */
/* is safe to call these routines at any time, they should not be inter- */
/* spersed between other hi-level calls.  This is because all of these   */
/* operations act on top of everything else without regard for the list  */
/* of objects.  Thus, if the cursor is currently on the screen, it       */
/* should be hidden before resizing a window underneath it, for example. */
/*************************************************************************/





ADDShowObjectHilite (Object)

ADDObjectRecord **Object;	/* This is where we get necessary info */

/* This routine uses information in the given ObjectRecord to change the
   highlighting status of an active image on the screen.  NOTE: It
   presently does not make any sense to (un)highlight a menu title. 
   USAGE: ADDShowObjectHilite (&ObjectRecord) */

{
	ADDObjectRecord	*CurrentTopmost;
	int		Index;
	int		x1,x2,y;

	ADDListFindObjectTop (&CurrentTopmost);
	if (CurrentTopmost != *Object || (*Object)->Type == ADDTYPEMENU)
		return (-1);

	(*Object)->Hilite = 1;
	x1 = (*Object)->NX1;
	x2 = (*Object)->NX2;
	y  = (*Object)->NY;
	if (y < 0 || y > ADDScreenSizeY)
		return (0);
	if (x1 >= 0 && x1 <= ADDScreenSizeX)
		ADDScreenBuffer [x1][y] = ADDCHARHILITELEFT;
	if (x2 >= 0 && x2 <= ADDScreenSizeX)
		ADDScreenBuffer [x2][y] = ADDCHARHILITERIGHT;
	for (Index = 0; Index <= (x2-x1-2); Index++)
	   if ( ((x1+Index+1) >= 0) && ((x1+Index+1) <= ADDScreenSizeX) )
		if ( (isalpha (ADDScreenBuffer [x1+Index+1][y])) &&
		     (islower (ADDScreenBuffer [x1+Index+1][y])) )
			ADDScreenBuffer [x1+Index+1][y] =
				toupper (ADDScreenBuffer [x1+Index+1][y]);
	ADDScreenRefresh (x1,y,x2,y);
	return (0);
}





ADDHideObjectHilite (Object)

ADDObjectRecord **Object;	/* This is where we get necessary info */

/* This routine uses information in the given ObjectRecord to change the
   highlighting status of an active image on the screen.  NOTE: It
   presently does not make any sense to (un)highlight a menu title. 
   USAGE: ADDHideObjectHilite (&ObjectRecord) */

{
	ADDObjectRecord	*CurrentTopmost;
	int		Index;
	int		x1,x2,y;

	ADDListFindObjectTop (&CurrentTopmost);
	if (CurrentTopmost != *Object || (*Object)->Type == ADDTYPEMENU)
		return (-1);

	(*Object)->Hilite = 0;
	x1 = (*Object)->NX1;
	x2 = (*Object)->NX2;
	y  = (*Object)->NY;
	if (y < 0 || y > ADDScreenSizeY)
		return (0);
	if (x1 >= 0 && x1 <= ADDScreenSizeX)
		ADDScreenBuffer [x1][y] = ADDSPACE;
	if (x2 >= 0 && x2 <= ADDScreenSizeX)
		ADDScreenBuffer [x2][y] = ADDSPACE;
	for (Index = 0; Index <= (x2-x1-2); Index++)
		if ( ((x1+Index+1) >= 0) && ((x1+Index+1) <= ADDScreenSizeX) )
		{
			if ((*Object)->Name [Index] == '\0')
				break;
			ADDScreenBuffer[x1+Index+1][y]=(*Object)->Name[Index];
		}
	ADDScreenRefresh (x1,y,x2,y);
	return (0);
}





ADDShowItemHilite (Item)

ADDItemRecord	**Item;		/* This is where we get our info */

/* This routine uses information in the given ItemRecord to change the
   highlighting status of an active item line on the screen.
   USAGE: ADDShowItemHilite (&ItemRecord) */

{
	int	Index;
	int	x1,x2,y;

	(*Item)->Hilite = 1;
	x1 = (*Item)->X1;
	x2 = (*Item)->X2;
	y  = (*Item)->Y;
	if (y < 0 || y > ADDScreenSizeY)
		return (0);
	if (x1 >= 0 && x1 <= ADDScreenSizeX)
		ADDScreenBuffer [x1][y] = ADDCHARHILITELEFT;
	if (x2 >= 0 && x2 <= ADDScreenSizeX)
		ADDScreenBuffer [x2][y] = ADDCHARHILITERIGHT;
	for (Index = 0; Index <= (x2-x1-2); Index++)
	   if ( ((x1+Index+1) >= 0) && ((x1+Index+1) <= ADDScreenSizeX) )
		if ( (isalpha (ADDScreenBuffer [x1+Index+1][y])) &&
		     (islower (ADDScreenBuffer [x1+Index+1][y])) )
			ADDScreenBuffer [x1+Index+1][y] =
				toupper (ADDScreenBuffer [x1+Index+1][y]);
	ADDScreenRefresh (x1,y,x2,y);
	return (0);
}





ADDHideItemHilite (Item)

ADDItemRecord	**Item;		/* This is where we get our info */

/* This routine uses information in the given ItemRecord to change the
   highlighting status of an active item line on the screen.
   USAGE: ADDHideItemHilite (&ItemRecord) */

{
	int	Index;
	int	x1,x2,y;

	(*Item)->Hilite = 0;
	x1 = (*Item)->X1;
	x2 = (*Item)->X2;
	y  = (*Item)->Y;
	if (y < 0 || y > ADDScreenSizeY)
		return (0);
	if (x1 >= 0 && x1 <= ADDScreenSizeX)
		ADDScreenBuffer [x1][y] = ADDSPACE;
	if (x2 >= 0 && x2 <= ADDScreenSizeX)
		ADDScreenBuffer [x2][y] = ADDSPACE;
	for (Index = 0; Index <= (x2-x1-2); Index++)
		if ( ((x1+Index+1) >= 0) && ((x1+Index+1) <= ADDScreenSizeX) )
		{
			if ((*Item)->Name [Index] == '\0')
				break;
			ADDScreenBuffer [x1+Index+1][y] = (*Item)->Name [Index];
		}
	ADDScreenRefresh (x1,y,x2,y);
	return (0);
}





ADDShowDragFrame (X1,Y1,X2,Y2)

/* This routine draws a "drag frame" with the given coordinates on
   top of everything else.  Drag frames should be used to provide
   ergonomic feedback while moving or resizing objects.  The
   drag frame should be hidden before doing any other desktop 
   operations.  This routine does not do any clipping whatsoever.
   USAGE: ADDShowDragFrame (3,3,30,30) */

{
	int	i;

	/* Save screen area underneath while drawing drag frame in memory: */
	for (i = 0; i <= 2; i++)
	{
		ADDDragFrameSave [0][i] = ADDScreenBuffer [X1+i][Y1];
		ADDScreenBuffer [X1+i][Y1] = ADDCHARDRAGFRAME;
		ADDDragFrameSave [1][i] = ADDScreenBuffer [X2-i][Y1];
		ADDScreenBuffer [X2-i][Y1] = ADDCHARDRAGFRAME;
		ADDDragFrameSave [2][i] = ADDScreenBuffer [X1+i][Y2];
		ADDScreenBuffer [X1+i][Y2] = ADDCHARDRAGFRAME;
		ADDDragFrameSave [3][i] = ADDScreenBuffer [X2-i][Y2];
		ADDScreenBuffer [X2-i][Y2] = ADDCHARDRAGFRAME;
	}
	ADDDragFrameSave [0][3] = ADDScreenBuffer [X1][Y1+1];
	ADDScreenBuffer [X1][Y1+1] = ADDCHARDRAGFRAME;
	ADDDragFrameSave [1][3] = ADDScreenBuffer [X2][Y1+1];
	ADDScreenBuffer [X2][Y1+1] = ADDCHARDRAGFRAME;
	ADDDragFrameSave [2][3] = ADDScreenBuffer [X1][Y2-1];
	ADDScreenBuffer [X1][Y2-1] = ADDCHARDRAGFRAME;
	ADDDragFrameSave [3][3] = ADDScreenBuffer [X2][Y2-1];
	ADDScreenBuffer [X2][Y2-1] = ADDCHARDRAGFRAME;

	/* Update the four screen areas to the terminal: */
	ADDScreenRefresh (X1,Y1,X1+2,Y1+1);
	ADDScreenRefresh (X2-2,Y1,X2,Y1+1);
	ADDScreenRefresh (X1,Y2-1,X1+2,Y2);
	ADDScreenRefresh (X2-2,Y2-1,X2,Y2);
}





ADDHideDragFrame (X1,Y1,X2,Y2)

/* This routine hides the drag frame drawn by an earlier call to
   ADDShowDragFrame.  This routine should be given the same parameters
   as were given to the ADDShowDragFrame call.
   USAGE: ADDHideDragFrame (3,3,30,30) */

{
	int	i;

	for (i = 0; i <= 2; i++)
	{
		ADDScreenBuffer [X1+i][Y1] = ADDDragFrameSave [0][i];
		ADDScreenBuffer [X2-i][Y1] = ADDDragFrameSave [1][i];
		ADDScreenBuffer [X1+i][Y2] = ADDDragFrameSave [2][i];
		ADDScreenBuffer [X2-i][Y2] = ADDDragFrameSave [3][i];
	}
	ADDScreenBuffer [X1][Y1+1] = ADDDragFrameSave [0][3];
	ADDScreenBuffer [X2][Y1+1] = ADDDragFrameSave [1][3];
	ADDScreenBuffer [X1][Y2-1] = ADDDragFrameSave [2][3];
	ADDScreenBuffer [X2][Y2-1] = ADDDragFrameSave [3][3];

	/* Update the four screen areas to the terminal: */
	ADDScreenRefresh (X1,Y1,X1+2,Y1+1);
	ADDScreenRefresh (X2-2,Y1,X2,Y1+1);
	ADDScreenRefresh (X1,Y2-1,X1+2,Y2);
	ADDScreenRefresh (X2-2,Y2-1,X2,Y2);
}





ADDShowCursor (CursorImage,X,Y)

char	*CursorImage;	/* Input: IconString that is the cursor to be drawn  */
int 	X,Y;		/* Input: Coordinates where center of cursor will be */

/* This routine displays the given cursor image (which should be in
   IconString format) and draws it on top of everything else.  The
   cursor should be hidden before doing other desktop activity.
   The cursor is drawn such that the given X,Y coordinates will
   coincide with the *center* of the cursor image, clipping off the
   screen if necessary.  After drawing the cursor image, the terminal
   cursor is positioned to its center.
   USAGE: ADDShowCursor (0,0,ADDCURSORICONPOINT) */

{
	int		sx,sy;		/* Size of icon to be drawn */
	int		ox,oy;		/* Our computed origin      */
	int		x,y;		/* Looping thru arrays      */
	extern int	ADDPutChar ();	/* Defined elsewhere        */

	/* Find out where to draw the cursor, but don't draw it yet: */
	ADDDrawIconToBufferOnly (CursorImage,X,Y,&sx,&sy,1);
	ox = X - ((sx+1) / 2);
	oy = Y - ((sy+1) / 2);

	/* Save screen area underneath, while clipping: */
	for (y = 0;   y <= sy;  y++)
		for (x = 0;   x <= sx;  x++)
			if ( ((ox+x) >= 0) && ((ox+x) <= ADDScreenSizeX) &&
			     ((oy+y) >= 0) && ((oy+y) <= ADDScreenSizeY) )
				ADDCursorSave [x][y] = 
					ADDScreenBuffer [ox + x][oy + y];

	/* Now actually draw the cursor, while clipping: */
	ADDDrawIcon (CursorImage,ox,oy);

	/* Put the terminal's cursor in the middle of the icon image: */
	tputs (tgoto (ADDTcapCursorMotion,X,Y),1,ADDPutChar);
	ADDFlushChar ();
}





ADDHideCursor (CursorImage,X,Y)

char	*CursorImage;	/* Input: IconString that is the cursor to be erased */
int 	X,Y;		/* Input: Coordinates where center of cursor is      */

/* This routine hides the cursor that was drawn by an earlier call
   to ADDShowCursor.  This routine must be given the same parameters
   as were given to the ADDShowCursor call.
   USAGE: ADDHideCursor (0,0,ADDCURSORICONPOINT) */

{
	int	sx,sy;		/* Size of icon to be undrawn */
	int	ox,oy;		/* Our computed origin        */
	int	x,y;		/* Looping thru arrays        */

	/* Find out where the cursor is; don't draw it: */
	ADDDrawIconToBufferOnly (CursorImage,X,Y,&sx,&sy,1);
	ox = X - ((sx+1) / 2);
	oy = Y - ((sy+1) / 2);

	/* Restore screen area underneath, while clipping: */
	for (y = 0;   y <= sy;  y++)
		for (x = 0;   x <= sx;  x++)
			if ( ((ox+x) >= 0) && ((ox+x) <= ADDScreenSizeX) &&
			     ((oy+y) >= 0) && ((oy+y) <= ADDScreenSizeY) )
				ADDScreenBuffer [ox + x][oy + y] =
					ADDCursorSave [x][y];
	ADDScreenRefresh (ox,oy,ox+sx,oy+sy);
}



