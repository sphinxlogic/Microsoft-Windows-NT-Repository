/*
 *add.med.c -- Medium-level routines: primitive desktop object drawing
 *(C) 1988 Ben Koning [556498717 408/738-1763 ben@ucscf.ucsc.edu]
 */





#include "unidesk.h"		/* Our own define's, plus external decs */





/****************** MEDIUM-LEVEL SCREEN IMAGE DRAWING ******************/
/* These routines use the low-level ADD routines to draw icons, custom */
/* text strings, etc., to the screen.  These are in turn used by the   */
/* other ADD calls in this file as they draw actual desktop objects to */
/* the screen with their inherent style.                               */
/***********************************************************************/





ADDDrawCustomStrings (String,X1,Y1,X2,Y2)

char *String;			/* Encoded CustomStrings */
int  X1,Y1,X2,Y2;		/* Bounding rectangle    */

/* This routine draws the given CustomStrings-format text on the
   screen/buffer.  The format is assumed to be: Xrelative, Comma, 
   Yrelative, Comma, Text; Null to terminate or Comma followed 
   by another such sequence.  Coordinates in the CustomStrings string 
   must be in the range 0-100 to indicate a percentage between the
   upper left and the bottom right corners of the given bounding
   rectangle for the origin of each individual string.  In order to
   place a comma within a text sequence, use two commas in a row.
   CustomStrings are used to optionally customize desktop objects;
   for example, to add "scroll buttons" to windows, etc.
   USAGE: ADDDrawCustomStrings ("0,0,Hi,, there!,50,50,Center",0,0,19,19) */

{
	int i = 0;		/* Index through string                     */
	int x,y;		/* Computing screen posn of a text sequence */
	int numcommas;		/* For advancing index through string       */
	char text [256];	/* For passing text to ADDScreenOutput      */
	int tp;			/* Index through "text" string above        */

	while (String [i] != '\0')   /* Do this until std string termination */
	{
		/* Get x,y-relative from string (0-100, but don't enforce): */
		sscanf (&(String [i]),"%d,%d",&x,&y);

		/* Advance the string index until just past 2nd comma: */
		numcommas = 0;  /* Start at zero each time */
		while (String [i] != '\0')
		{
			numcommas += (String [i++] == ADDCOMMA);
			if (numcommas == 2)
				break;
		}

		/* Copy portion of text until comma reached, then skip over: */
		tp = 0;
		while (String [i] != '\0')
		{
			text [tp] = String [i++];       /* Advance str index */
			if (String [i-1] == ADDCOMMA)   /* Currently a comma? */
				if (String [i] == ADDCOMMA) /* Nxt one comma? */
					i++;    /* Yes, treat pair as single */
				else
					break;   /* Comma + OtherJunk: stop! */
			tp++;
		}
		text [tp] = '\0';	    /* Overwrite Null over comma */

		/* Compute the proper origin for the piece of text: */
		x = X1 + (   (x * (X2-X1)) / 100   );
		y = Y1 + (   (y * (Y2-Y1)) / 100   );

		/* Now output the text while clipping, etc.: */
		ADDScreenOutput (text,x,y);
	}
}





ADDDrawIconToBufferOnly (String,X,Y,DimensionX,DimensionY,Inhibit)

char *String;			/* Input:  Encoded icon string       */
int  X,Y;			/* Input:  Where on screen to put it */
int  *DimensionX,*DimensionY;	/* Output: Dimensions of icon image  */
int  Inhibit;			/* Input:  1=Don't even draw buffer  */

/* This routine is used by several routines, some of which need to draw
   many icons to the buffer before updating the screen.  This routine
   does the most of the actual work for ADDDrawIcon.  If the Inhibit
   parameter is set, then only the size calculations are done and the
   screen buffer is left untouched.
   USAGE: ADDDrawIconToBufferOnly (str,x,y,&sizeX,&sizeY,0) */

{
	int dimx,dimy;		/* Dimensions recovered from String    */
	int pos;  	 	/* Points to index in String           */
	int x,y;		/* Position on screen while drawing    */
	int numcommas = 0;	/* Number of commas encountered so far */

	/* Recover X and Y dimensions and find start of icon-data: */
	sscanf (String,"%d,%d",&dimx,&dimy);
	*DimensionX = dimx - 1;
	*DimensionY = dimy - 1;

	/* If Inhibit parameter set then exit this routine now: */
	if (Inhibit)
		return (1);

	for (pos = 0;   String [pos] != '\0';   pos++)
	{
		numcommas += (String [pos] == ADDCOMMA);
		if (numcommas == 2)
			break;
	}

	/* Compute where we should stop: */
	dimx += (X - 1);
	dimy += (Y - 1);

	/* Draw the icon to the buffer only, while clipping: */
	for (y = Y; y <= dimy; y++)
		for (x = X; x <= dimx; x++)
		{
			++pos;
			if ( (x >= 0) && (y >= 0) &&
			     (x <= ADDScreenSizeX) && (y <= ADDScreenSizeY) &&
			     (String [pos] != '\t') )
				ADDScreenBuffer [x][y] = String [pos];
		}
	return (0);
}





ADDDrawIcon (String,X,Y)

char *String;
int  X,Y;

/* This routine draws the given icon at the given coordinates, clipping to
   the screen boundaries.  The format of an icon-string is as follows:
   X and Y dimensions (in counting numbers; a 2x4 image has dimensions 2 and
   4, not 1 and 3), followed by the characters of the string in left-to-
   right, top-to-bottom raster-scanned format.  These are separated by
   commas.  Commas may appear in the icon-data string without an escape
   character.  The tab character ('\t') denotes a transparent pixel.
   USAGE: ADDDrawIcon ("5,3,+===+|,,,|+===+",x,y)  */

{
	int sizeX,sizeY;

	ADDDrawIconToBufferOnly (String,X,Y,&sizeX,&sizeY,0);
	ADDScreenRefresh (X,Y,X+sizeX,Y+sizeY);
}





ADDDrawDesktop (String)

char *String;

/* This routine draws a repeating pattern on the screen, by filling it
   with a repeating mosaic of icons decoded from the given icon string. 
   USAGE: ADDDrawDesktop ("2,2,:  :") */

{
	int x,y,sizeX,sizeY;

	/* Ascertain the size of the icon: */
	ADDDrawIconToBufferOnly (String,0,0,&sizeX,&sizeY,1);

	/* First, draw to screen buffer memory: */
	for (x = 0; x <= ADDScreenSizeX; x += (sizeX+1))
		for (y = 0; y <= ADDScreenSizeY; y += (sizeY+1))
			ADDDrawIconToBufferOnly (String,x,y,&sizeX,&sizeY,0);

	/* Next, update the terminal screen: */
	ADDScreenRefresh (0,0,ADDScreenSizeX,ADDScreenSizeY);
}





/************************ OBJECT DRAWING ROUTINES ************************/
/* These routines actually draw the images of desktop objects to the     */
/* screen for when they are presented for the first time.  They use some */
/* of the medium-level routines (above) as well as some of the lower-    */
/* level routines.  It is in these calls that the standard UniDesk       */
/* "look" is defined (other than in the modifiable characters in each    */
/* ObjectRecord).  These calls are used directly by the high-level ADD   */
/* routines which "open", "close", "move", etc., objects.                */
/* All of the calls in this section use information in the given         */
/* ObjectRecords.  The horizontal, vertical, and corner characters in    */
/* the ObjectRecord are used, as are its bounding rectangle coordinates. */
/* The inside area of the object is cleared to spaces, if appropriate.   */
/* For highlighting, all Name-strings are flanked by spaces.             */
/* These routines call ADDScreenBlockSave to save the screen area under- */
/* neath before drawing.  In most cases, some of the given object's      */
/* coordinate data fields in the Object or Item -Records are set to      */
/* useful values (see especially ADDDrawNewMenu).  For example, the      */
/* name position fields (NX1,NX2,NY) and lower-right corner position     */
/* fields (X2,Y2) are set, because they are calculated by these calls.   */
/* Note, however, that the custom-strings are not drawn on the objects   */
/* by these routines; nor are layer numbers or object-types assigned.    */
/* This is done by the high-level routines.                              */
/*************************************************************************/





ADDDrawNewWindow (Object)

ADDObjectRecord **Object;	/* This is where we get necessary info */

/* This routine uses information in the given ObjectRecord to draw a new
   image on the screen.  Please see the comment header for this section.
   The name position fields (NX1,NX2,NY) ARE SET by this routine.  The
   TextContent field in the given object record is drawn to the window
   and is thus assumed to contain sane values.  The screen area over-
   written by this routine is saved first.
   USAGE: ADDDrawNewWindow (&ObjectRecord) */

{
	int x,y,i;	/* Iterators for manipulating screen memory */
	int S,L;	/* Calc area around title: S)tart & L)ength */

	/* Calculate all bounds (we already know X1Y1X2Y2): */
	L = strlen ((*Object)->Name);
	if ( (L + 7) >= ((*Object)->X2 - (*Object)->X1) )  /* Too big? Chop! */
		L = (*Object)->X2 - (*Object)->X1 - 7;
	S = (*Object)->X1 + (( ((*Object)->X2 - (*Object)->X1) -L-4) / 2) + 1;
	(*Object)->NX1 = S+1;       	/* Where the title is */
	(*Object)->NX2 = S+L+2;	
	(*Object)->NY  = (*Object)->Y1;

	/* Save the current desktop area before drawing: */
	ADDScreenBlockSave (Object);

	/* Build the image in memory first: */
	/* Start by drawing TextContent text in the rectangular region: */
	i = 0;
	for (y = (*Object)->Y1 + 1;  y < (*Object)->Y2;  y++)
		for (x = (*Object)->X1 + 1;  x < (*Object)->X2;  x++)
			ADDScreenBuffer [x][y] = (*Object)->TextContent [i++];

	/* Next, paint top and bottom borders: */
	for (x = (*Object)->X1 + 1;  x < (*Object)->X2;  x++)
	{
		ADDScreenBuffer [x][(*Object)->Y1] = (*Object)->CharHorizontal;
		ADDScreenBuffer [x][(*Object)->Y2] = (*Object)->CharHorizontal;
	}

	/* Next, paint left and right borders: */
	for (y = (*Object)->Y1 + 1;  y < (*Object)->Y2;  y++)
	{
		ADDScreenBuffer [(*Object)->X1][y] = (*Object)->CharVertical;
		ADDScreenBuffer [(*Object)->X2][y] = (*Object)->CharVertical;
	}

	/* Install the four corners: UL, UR, LL, LR */
	ADDScreenBuffer [(*Object)->X1][(*Object)->Y1] = (*Object)->CharCorner;
	ADDScreenBuffer [(*Object)->X2][(*Object)->Y1] = (*Object)->CharCorner;
	ADDScreenBuffer [(*Object)->X1][(*Object)->Y2] = (*Object)->CharCorner;
	ADDScreenBuffer [(*Object)->X2][(*Object)->Y2] = (*Object)->CharCorner;

	/* Install the title, centered on the top line and with verticals: */
	ADDScreenBuffer [S]    [(*Object)->Y1] = (*Object)->CharVertical;
	ADDScreenBuffer [S+1]  [(*Object)->Y1] = ADDSPACE;
	ADDScreenBuffer [S+L+2][(*Object)->Y1] = ADDSPACE;
	ADDScreenBuffer [S+L+3][(*Object)->Y1] = (*Object)->CharVertical;
	for (L--; L >= 0; L--)
		ADDScreenBuffer [S+L+2][(*Object)->Y1] = (*Object)->Name [L];

	/* Now update the screen in raster fashion: */
	ADDScreenRefresh ( (*Object)->X1,
			   (*Object)->Y1,
			   (*Object)->X2,
			   (*Object)->Y2 );
}





ADDDrawNewMenu (Object)

ADDObjectRecord **Object;	/* This is where we get necessary info */

/* This routine uses information in the given ObjectRecord to draw a new
   image on the screen.  Please see the comment header for this section.
   This routine creates a menu with all items in the ItemList, if any,
   including the menu title at top.  It reads the X1Y1 fields of the
   ObjectRecord to determine the origin, AND IT WRITES to the X2Y2 fields
   the lower-right corner coordinates of the menu box, since its size is
   usually unknown until calling this procedure.  IT ALSO WRITES to the
   X1X2Y fields in each ItemRecord, since the coordinates of the individual
   item strings is also unknown before calling this routine.  This routine
   also sets the NX1,NX2,Y fields.  The screen area overwritten by this
   routine is saved by it first.
   USAGE: ADDDrawNewMenu (&ObjectRecord) */

{
	ADDItemRecord	*ItemChaser;	/* Searching thru menu items     */
	int		itemlen = 0;	/* Length of longest item string */
	int		itemnum = 0;	/* Total number of items present */
	int		i;		/* Iterator through screen mem   */
	int		stillok;	/* Still ok to copy an item str? */

	/* Find length of the longest item and number of items; set X2Y2: */
	ItemChaser = (*Object)->ItemListHead;
	while (ItemChaser != NULL)
	{
		itemnum++;
		if (strlen (ItemChaser->Name) > itemlen)
			itemlen = strlen (ItemChaser->Name);
		ItemChaser = ItemChaser->Link;
	}
	(*Object)->X2 = (*Object)->X1 + 3 + itemlen;
	(*Object)->Y2 = (*Object)->Y1 + 2 + itemnum;

	/* If the menu won't fit on the screen, quit & return error: */
	if (  ((*Object)->X2 >  ADDScreenSizeX) ||
	      ((*Object)->Y2 >  ADDScreenSizeY) ||
	     (((*Object)->X2 == ADDScreenSizeX) && 
	      ((*Object)->Y2 == ADDScreenSizeY))     ) return (-1);

	/* Find title location as well: */
	(*Object)->NX1 = (*Object)->X1;  /* Just don't hilite menu-title! */
	(*Object)->NX2 = (*Object)->X1 + strlen ((*Object)->Name)-1;
	(*Object)->NY  = (*Object)->Y1;

	/* Save screen area now that coordinates are known: */
	ADDScreenBlockSave (Object);

	/* Display title to terminal and memory: */
	ADDScreenOutput ((*Object)->Name,(*Object)->X1,(*Object)->Y1);

	/* Display the menu box to memory first; no corner characters: */
	/* First, draw the horizontals: */
	ADDScreenBuffer[(*Object)->X2][(*Object)->Y1+1] = ADDSPACE;
	for (i = (*Object)->X1 + 1;   i < (*Object)->X2;   i++)
	{
		ADDScreenBuffer[i][(*Object)->Y1+1] = (*Object)->CharHorizontal;
		ADDScreenBuffer[i][(*Object)-> Y2 ] = (*Object)->CharHorizontal;
	}

	/* Next, draw the verticals; left one longer than the right: */
	ADDScreenBuffer [(*Object)->X1][(*Object)->Y1 + 1] = 
		(*Object)->CharVertical;
	for (i = (*Object)->Y1 + 2;   i <= (*Object)->Y2;   i++)
	{
		ADDScreenBuffer[(*Object)->X1][i] = (*Object)->CharVertical;
		ADDScreenBuffer[(*Object)->X2][i] = (*Object)->CharVertical;
	}

	/* Finally, draw the strings inside the menu box: */
	/* While doing this, set X1X2Y fields inside the ItemRecord: */
	itemnum = (*Object)->Y1 + 2;   /* Reusing itemnum */
	ItemChaser = (*Object)->ItemListHead;
	while (ItemChaser != NULL)
	{
		ADDScreenBuffer [(*Object)->X1 + 1][itemnum] = ADDSPACE;
		ADDScreenBuffer [(*Object)->X2 - 1][itemnum] = ADDSPACE;
		stillok = 1;
		for (i = 0; i < itemlen; i++)
		{
			if (ItemChaser->Name [i] == '\0')
				stillok = 0;
			if (stillok)
				ADDScreenBuffer [(*Object)->X1+2+i][itemnum] = 
					ItemChaser->Name [i];
			else
				ADDScreenBuffer [(*Object)->X1+2+i][itemnum] =
					ADDSPACE;
		}
		ItemChaser->X1 = (*Object)->X1 + 1;  /* Set these fields     */
		ItemChaser->X2 = (*Object)->X2 - 1;  /* to make highlighting */
		ItemChaser->Y  = itemnum++;          /* much easier...       */
		ItemChaser = ItemChaser->Link;
	}

	/* Refresh terminal screen; needn't bother with the menu title: */
	ADDScreenRefresh ( (*Object)->X1,
			   (*Object)->Y1 + 1,
			   (*Object)->X2,
			   (*Object)->Y2 );
	return (0);
}





ADDDrawNewIcon (Object)

ADDObjectRecord **Object;	/* This is where we get necessary info */

/* This routine uses information in the given ObjectRecord to draw a new
   icon image on the screen.  Please see the comment header for this section.
   The IconString field in the given ObjectRecord is used and must be set up.
   The title is centered and drawn underneath the icon image, with one
   blank space to either side to allow highlighting.  This routine WRITES
   to the X2Y2 fields of the given ObjectRecord, setting them to the
   lower-right corner coordinates of the image.  It also WRITES to the
   NX1,NX2,NY fields, setting them to the bounds of the title string.
   The screen area overwritten by this routine is saved by it first.  If an
   empty string or NULL is passed as the icon image, then no icon is drawn
   and the title is put at the X1+1,Y1+2 coordinates.  This is useful
   for implementing a menu bar.
   USAGE: ADDDrawNewIcon (&ObjectRecord) */

{
	static char ni [] = "2,2,\t\t\t\t";  /* Allowing null image strings */
	char onespace [2];		     /* String with one space in it */
	int  centerpos;			     /* Center x coordinate         */
	int  dimx,dimy;			     /* Decoded icon dimensions     */
	int  nocenter = 0;		     /* Flag: Do centering?         */

	/* Allow NULL or nullstring icon images: */
	if ((*Object)->Image == NULL)
	{
		(*Object)->Image = ni;
		nocenter = 1;
	}
	if ((*Object)->Image [0] == '\0')
	{
		(*Object)->Image = ni;
		nocenter = 1;
	}
		
	/* Calculate X2,Y2, as well as title location fields NX1,NX2,NY: */
	ADDDrawIconToBufferOnly ((*Object)->Image,(*Object)->X1,(*Object)->Y1,
				 &dimx,&dimy,1);  /* Inhibit flag set! */
	(*Object)->X2  = (*Object)->X1 + dimx;
	(*Object)->Y2  = (*Object)->Y1 + dimy;
	centerpos      = (((*Object)->X1 + (*Object)->X2) / 2);
	centerpos     -= ((strlen ((*Object)->Name)+2) / 2);
	if (nocenter)
		centerpos = (*Object)->X1;
	(*Object)->NX1 = centerpos;
	(*Object)->NX2 = centerpos + strlen ((*Object)->Name) + 1;
	(*Object)->NY  = (*Object)->Y2 + 1;
	/* (Note that title positions NX1X2Y may be off the screen) */

	/* Save screen area first: */
	ADDScreenBlockSave (Object);

	/* Now draw the stuff to screen and buffer: */
	ADDDrawIcon ((*Object)->Image,
		     (*Object)->X1,(*Object)->Y1);  /* For real this time */
	ADDScreenOutput ( (*Object)->Name, centerpos + 1, (*Object)->Y2 + 1 );
	onespace [0] = ADDSPACE;
	onespace [1] = '\0';
	ADDScreenOutput (onespace,centerpos,
			 (*Object)->Y2 + 1);
	ADDScreenOutput (onespace,centerpos + 1 + strlen ((*Object)->Name),
			 (*Object)->Y2 + 1);
}



