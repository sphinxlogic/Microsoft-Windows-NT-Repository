/*
 *sdi.hi.c -- Simplified Desktop Interface environment -- high-level routines
 *(C) 1988 Ben Koning [556498717 408/738-1763 ben@ucscf.ucsc.edu]
 */





#include "unidesk.h"		/* Our own define's, plus external decs */





/**************** EASY DESKTOP CALLS SUPPORT ROUTINES *****************/
/* These routines are used by the easy-to-use desktop interface rou-  */
/* tines below.  They are for internal use only.                      */
/**********************************************************************/





SDI_shutdown_ ()

/* This routine is for internal use only.  It is an emergency shutdown
   which is called when a signal is caught, etc. */

{
	/* Re-set the signals for XENIX: */
	signal (SIGINT,SDI_shutdown_);		/* ^C Interrupt */
	signal (SIGQUIT,SDI_shutdown_);		/* ^\ Hard kill */
	signal (SIGTERM,SDI_shutdown_);		/* Soft termination */
	ADDScreenClear ();
	ADDScreenOutput (SDISignalMessage,
			 (ADDScreenSizeX - strlen (SDISignalMessage)) / 2,
			  ADDScreenSizeY / 2);
	sleep (2);
	ADDShutDown ();
	exit (100);
}





SDI_daselected_ (String)

char	*String;

/* This routine is for internal use only.  It handles the execution of a
   desk accessory.  WARNING: The stdin handling is somewhat of a kludge;
   it works for now (ADD V1.0) but may require changing later. */

{
	extern int	ADDPutChar ();
	char		CmdLine [ADDMAXX];

	/* FD's for stdout/stderr are both intact (ADD V1.0); fix up stdin: */
	ADDLocator_keyboardshutdown_ ();

	/* Clear the screen and try to execute the given program: */
	tputs (ADDTcapClear,1,ADDPutChar);
	ADDFlushChar ();
	CmdLine [0] = '\0';
	strcat (CmdLine,SDIDAPATH);
	strcat (CmdLine,"/");
	strcat (CmdLine,String);
	system (CmdLine);

	/* Set file descriptor for stdin back to previous state: */
	ADDLocator_keyboardstartup_ ();

	/* Wait for keypress so stuff won't flash off the screen: */
	getchar ();

	/* Restore the screen: */
	ADDRedraw ();
}





SDI_quitselected_ ()

/* This routine is for internal use only.  It is a dummy placeholder
   routine for identifying when the standard quit option is selected. */

{
}





SDI_stopjob_ ()

/* This procedure is called when a stopjob signal has been issued under
   BSD unix. It sets the keyboard back to normal and then sends the stopjob
   signal to ourselves.  Again, this works only with ADD V1.0. */

{
	extern int	ADDPutChar ();

	tputs (ADDTcapClear,1,ADDPutChar);	/* Clear ...            */
	ADDFlushChar ();			/* ... the screen.      */
	ADDLocator_keyboardshutdown_ ();	/* Sane terminal I/O    */
#ifdef SIGTSTP
	signal (SIGTSTP,SIG_DFL);		/* Default ^Z handling  */
	kill (getpid (),SIGTSTP);		/* Send ^Z to ourselves */
#endif
}





SDI_contjob_ ()

/* This procedure is called when a continuejob signal has been issued under
   BSD unix.  It restarts our keyboard handler and resets our signal
   handling vector.  Again, this works only with ADD V1.0. */

{
#ifdef SIGTSTP
	signal (SIGTSTP,SDI_stopjob_);   	/* Back to our handler */
#endif
	ADDLocator_keyboardstartup_ ();		/* Back to our term IO */
	ADDRedraw ();				/* Redraw the desktop  */
}





/************* THE BIG TEN: EASY DESKTOP INTERFACE CALLS **************/
/*                                                                    */
/* These are the ONLY calls which the *casual* UniDesk user will ever */
/* have to make.  They take care of everything, including all event   */
/* handling and the location of objects.  The names of all of these   */
/* calls is of the form "SDIEasy___".  In order to use UniDesk with   */
/* these calls, do the following:                                     */
/*                                                                    */
/* (0) The program which uses UniDesk must be compiled as follows:    */
/*     cc [options] [files] UniDesk.o [libraries] -ltermcap           */
/*                                                                    */
/* (1) Call SDIEasyReady.  Everything is initialized and standard     */
/*     objects are drawn on the desktop.  A standard "UniDesk" menu   */
/*     with desk accessories from the user's ".unideskrc" directory   */
/*     and a standard "Quit" option is installed, over a standard     */
/*     desktop pattern.  This routine must be called first; after     */
/*     calling this routine, any of the other "SDIEasy___" routines   */
/*     may be called.                                                 */
/*                                                                    */
/* (2) Call any number of "SDIEasy___" routines to setup the desktop  */
/*     before event handling starts, if it is so desired.  These      */
/*     calls open and close objects and may be called to close stan-  */
/*     dard objects, if desired.  They may also be called during      */
/*     execution of the program as appropriate.  They associate       */
/*     user-procedures with the objects opened, so that they may be   */
/*     called if the appropriate object is selected.  Duplicate pro-  */
/*     cedure associations are not allowed; that is, every object on  */
/*     the desktop must have its own associated procedure.            */
/*                                                                    */
/* (3) Call SDIEasyGo, to initiate totally automatic event handling.  */
/*     SDIEasyGo takes total control, and should be the last call be- */
/*     fore the user's own shutdown code, if any.  The user's program */
/*     will regain control again (hopefully only momentarily) when an */
/*     object is selected.  If desired, a procedure given by the user */
/*     is executed every few times this routine does its main loop.   */
/*     Both the latter user procedure and the user procedure that is  */
/*     called when an object is selected should return as soon as     */
/*     possible.  SDIEasyGo returns only if the standard.  "Quit"     */
/*     option in the standard "UniDesk" menu is selected.             */
/*                                                                    */
/* (4) During user program execution, call SDIEasyOutput to output    */
/*     strings to windows, and call SDIEasyInput to get strings from  */
/*     windows.                                                       */
/*                                                                    */
/*  These routines are designed to be quite robust against bogus pa-  */
/*  rameters.  There are, in all, ten easy-to-use routines which      */
/*  completely control the desktop user interface:                    */
/*                                                                    */
/*  CONTROL:     WINDOWS:           MENUS:           ICONS:           */
/*  ------------ ------------------ ---------------- ---------------  */
/*  SDIEasyReady SDIEasyOpenWindow  SDIEasyOpenMenu  SDIEasyOpenIcon  */
/*  SDIEasyGo    SDIEasyCloseWindow SDIEasyCloseMenu SDIEasyCloseIcon */
/*               SDIEasyInput                                         */
/*               SDIEasyOutput                                        */
/*                                                                    */
/**********************************************************************/





SDIEasyReady ()

/* This routine initializes everything.  If it fails, it terminates program
   execution.  It sets up signal-catching functions so interrupts, etc.,
   will hopefully be handled cleanly.  This routine draws a clean desktop,
   and installs a standard menu with desk accessories and a "Quit" option.
   It must be the first call made, or else bad things will happen.  WARNING:
   Desk Accessory titles must be less than ~80 characters, else crash.
   USAGE: SDIEasyReady () */

{
	FILE			*TempPtr;
	static char		TempName [80] = SDITEMPPATH;
	char			CmdLine  [80];
	static char		DaNames	 [ADDMAXY][ADDMAXX];
	char			InpName  [512];
	int			i;
	ADDObjectRecord		*DummyObject;
	ADDItemRecord		*DummyItem;

	/* Arrange to handle some common signals cleanly: */
	signal (SIGINT,SDI_shutdown_);			/* ^C Interrupt */
	signal (SIGQUIT,SDI_shutdown_);			/* ^\ Hard kill */
	signal (SIGTERM,SDI_shutdown_);			/* Soft termination */
#ifdef SIGTSTP
	signal (SIGTSTP,SDI_stopjob_);			/* BSD: ^Z Stop Job */
	signal (SIGCONT,SDI_contjob_);			/* BSD: fg Cont job */
#endif

	/* Initialize desktop routines; terminate if error: */
	if (ADDStartUp () < 1)  /* Must use V1.0+ */
	{
		printf ("%s\n",SDIStartupMessage);
		exit (1);
	}

	/* Draw standard desktop: */
	ADDDrawDesktop (ADDDESKTOPICON);

	/* Build a list of desk accessories in a temporary file: */
	mktemp (TempName);
	CmdLine [0] = '\0';
	strcat (CmdLine,"ls -1 ");
	strcat (CmdLine,SDIDAPATH);
	strcat (CmdLine," 2> /dev/null 1> ");
	strcat (CmdLine,TempName);
	system (CmdLine);  /* ls ~/.unideskrc > /tmp/unideskXXXXXX */

	/* Install the standard menu with standard Quit option: */
	SDIEasyOpenMenu (SDI_quitselected_,SDISTDMENUNAME,SDISTDQUITNAME);
	DummyObject = ADDObjectRecordListHead->Link;  /* Risky... */

	/* Now fill the standard menu with desk accessories: */
	TempPtr = fopen (TempName,"r");
	i = 0;
	while ( (fscanf (TempPtr,"%s",InpName) != EOF) &&
	        (i <= ADDScreenSizeY - 4) )
		if (strlen (InpName) > ADDScreenSizeX - 4)
			SDI_shutdown_ ();
		else
		{
			strcpy (DaNames [i],InpName);
			ADDOpenItem (&DummyObject,
				     DaNames [i],
				     SDI_daselected_,
				     &DummyItem);
			i++;
		}

	/* Finally, remove the temporary file: */
	CmdLine [0] = '\0';
	strcat (CmdLine,"rm -f ");
	strcat (CmdLine,TempName);
	strcat (CmdLine," 2> /dev/null 1> /dev/null");
	system (CmdLine);  /* rm -f /tmp/unideskXXXXXX */
}





SDIEasyGo (ConcurrentDefProc)

int	(*ConcurrentDefProc) ();   /* Input: User proc to run concurrently */

/* This routine takes control of the calling process by handling desktop
   events.  If the user selects an object, then the procedure in the
   user's code that has been bound to it by an "SDIEasy___" routine (see
   below) is called.  If the standard "Quit" option from the standard
   menu is selected, then everything will be shut down cleanly, and this
   routine will just return (it won't terminate the calling process).  If
   a desk accessory is selected, then it is handled as well.  Every few
   times through the loop, the given user procedure is called, unless
   the NULL procedure is given.  WARNING: If the user program is to execute
   on a slow (ie, < 9600 baud) terminal, it is NOT recommended that the
   given user procedure perform desktop input or outut, as it can be
   quite a nuisance; the best use of this facility is for computation only.
   USAGE: SDIEasyGo (NULL) or SDIEasyGo (realtimeproc) */

{
	int	(*HitProc) ();
	char	*HitName;
	int	LoopCount;

	while (1)
	{
		/* Handle desktop moving, resizing, etc. events for a while: */
		for (LoopCount = SDIEASYGOLOOP;   LoopCount > 0;   LoopCount--)
		   if ( (HitProc = (int (*) ()) SDIDesktopManager (&HitName))
			!= (int (*) ()) NULL )   break;

		/* If we got a desk accessory selection, handle it: */
		if (HitProc == SDI_daselected_)
		{
			SDI_daselected_ (HitName);
			continue;
		}

		/* If we got a quit selection, handle it gracefully: */
		if (HitProc == SDI_quitselected_)
		{
			ADDCloseAllObjects ();
			sleep (2);
			ADDShutDown ();
			signal (SIGINT,SIG_DFL);	/* ^C Interrupt */
			signal (SIGQUIT,SIG_DFL);	/* ^\ Hard kill */
			signal (SIGTERM,SIG_DFL);	/* Soft termination */
#ifdef SIGTSTP
			signal (SIGTSTP,SIG_DFL);	/* BSD: ^Z Stop Job */
			signal (SIGCONT,SIG_DFL);	/* BSD: fg Cont job */
#endif
			return (0);
		}

		/* If we got some other (user) selection, handle it: */
		if (HitProc != (int (*) ()) NULL)
			(*HitProc) ();

		/* If desired, do the user's concurrent procedure: */
		if ( (!LoopCount) && (ConcurrentDefProc != (int (*) ()) NULL) )
			(*ConcurrentDefProc) ();
	}
}





SDIEasyOpenWindow (DefProc,Name)

int	(*DefProc) ();		/* Input: Associated procedure */
char	*Name;			/* Input: Window title string  */

/* This routine opens a window with the given name and binds the given
   procedure in the user's code to it.  All details pertaining to initial
   location on the desktop, etc., are taken care of.  The given name need
   not be unique, but the given procedure must be.  In other words, each
   window must have its own procedure in the caller's code.  Like the
   window input/output routines (below), the cursor is hidden first.
   USAGE: SDIEasyOpenWindow ("Window Title",main) */

{
	ADDObjectRecord		*TheObject;

	ADDListFindObjectByDefProc (&TheObject,DefProc);
	if (TheObject != NULL)
		return (-1);
	SDITrackCursor (-1);
	ADDOpenObject (Name,DefProc,ADDTYPEWINDOW,NULL,0,0,0,0,&TheObject);
	SDISetNewObjectPosition (&TheObject);
	return (ADDShowObject (&TheObject));
}





SDIEasyCloseWindow (DefProc)

int	(*DefProc) ();		/* Input: Associated procedure */

/* The window that was bound to the given procedure is closed by this
   routine, with all housekeeping taken care of.  Like the window
   input/output routines (below), the cursor is hidden first.
   USAGE: SDIEasyCloseWindow (main) */

{
	ADDObjectRecord		*TheObject;

	ADDListFindObjectByDefProc (&TheObject,DefProc);
	if (TheObject == NULL)
		return (-1);
	if (TheObject->Type != ADDTYPEWINDOW)
		return (-1);
	SDITrackCursor (-1);
	ADDHideObject (&TheObject);
	ADDCloseObject (&TheObject);
	return (0);
}





SDIEasyOpenMenu (DefProc,TitleName,ItemName)

int	(*DefProc) ();		/* Input: Associated procedure */
char	*TitleName;		/* Input: Menu title name      */
char	*ItemName;		/* Input: Menu item name       */

/* This routine handles the opening of a new menu and new menu items
   (The menu title is actually implemented on the screen as an icon
   with a null image string).  The given menu item associated with the
   given menu title is bound to the user's procedure.  If the given menu
   title exists, then the given item is added to that menu.  Otherwise,
   the given (ie., new) menu title is added to the menu bar.  All details
   pertaining to initial location on the desktop, etc., are taken care of.
   The given name(s) need not be unique, but the given procedure must be.
   Like the window input/output routines (below), the cursor is hidden first.
   USAGE: SDIEasyOpenMenu (main,"Menu 1","Item 1") */

{
	ADDObjectRecord		*TheMenu;
	ADDItemRecord		*TheItem;
	ADDObjectRecord		*Chaser;

	/* See if there already is a *menu* with the given title ...  */
	/* Also, make sure nothing is bound to the given DefProc yet: */
	TheMenu = NULL;
	Chaser  = ADDObjectRecordListHead;
	while (Chaser != NULL)
	{
		if (Chaser->DefProc == DefProc)
			return (-1);
		if (Chaser->Type == ADDTYPEMENU)
		{
			ADDListFindItemByDefProc (&Chaser,&TheItem,DefProc);
			if (TheItem != NULL)
				return (-1);
			if (!strcmp (Chaser->Name,TitleName))
			{
				TheMenu = Chaser;
				break;
			}
		}
		Chaser = Chaser->Link;
	}

	/* If there isn't a menu title for this item yet, create one: */
	if (TheMenu == NULL)
	{
		ADDOpenObject (TitleName, (int (*) ()) NULL, ADDTYPEMENU,
			       NULL, 0, 0, 0, 0, &TheMenu);
		SDISetNewObjectPosition (&TheMenu);
		SDITrackCursor (-1);  /* Turn the cursor off */
		SDIOpenShowMenuTitle (&TheMenu);
	}

	/* Now install the given menu item: */
	ADDOpenItem (&TheMenu,ItemName,DefProc,&TheItem);
	return (0);
}





SDIEasyCloseMenu (DefProc)

int	(*DefProc) ();		/* Input: Associated procedure */

/* This routine handles the closing of the menu item bound to the
   given procedure.  If the menu title associated with the closed
   item then has no more items in it, then it too is removed from
   the desktop.  Like the window input/output routines (below), the
   cursor is hidden first.
   USAGE: SDIEasyCloseMenu (main) */

{
	ADDItemRecord		*TheItem;
	ADDObjectRecord		*Chaser;
	ADDObjectRecord		*TheMenu;

	/* Search all menus' item lists for the given DefProc: */
	Chaser  = ADDObjectRecordListHead;
	TheMenu = NULL;
	while (Chaser != NULL)
	{
		if (Chaser->Type == ADDTYPEMENU)
		{
			ADDListFindItemByDefProc (&Chaser,&TheItem,DefProc);
			if (TheItem != NULL)
			{
				TheMenu = Chaser;
				break;
			}
		}
		Chaser = Chaser->Link;
	}

	/* If the DefProc was never found above, return with error: */
	if (TheMenu == NULL)
		return (-1);

	/* Close the correct item: */
	ADDCloseItem (&TheMenu,&TheItem);

	/* If the menu object is now empty, remove it from the desktop: */
	if (TheMenu->ItemListHead == NULL)
	{
		SDITrackCursor (-1);		   /* Hide cursor       */
		SDICloseHideMenuTitle (&TheMenu);  /* Remove title_icon */
		ADDCloseObject (&TheMenu);	   /* Close menu object */
	}
	return (0);
}





SDIEasyOpenIcon (DefProc,Name,Image)

int	(*DefProc) ();		/* Input: Associated procedure         */
char	*Name;			/* Input: Icon title                   */
char	*Image;			/* Input: IconString-format icon image */

/* This routine opens an icon with the given name and binds the given
   procedure in the user's code to it.  All details pertaining to initial
   location on the desktop, etc., are taken care of.  The given name need
   not be unique, but the given procedure must be.  Like the window 
   input/output routines (below), the cursor is hidden first.
   USAGE: SDIEasyOpenIcon (main,"Icon Title","3,3,+-+|i|+-+") */

{
	ADDObjectRecord		*TheObject;

	ADDListFindObjectByDefProc (&TheObject,DefProc);
	if (TheObject != NULL)
		return (-1);
	SDITrackCursor (-1);
	ADDOpenObject (Name,DefProc,ADDTYPEICON,Image,0,0,0,0,&TheObject);
	SDISetNewObjectPosition (&TheObject);
	return (ADDShowObject (&TheObject));
}





SDIEasyCloseIcon (DefProc)

int	(*DefProc) ();		/* Input: Associated procedure */

/* The icon that was bound to the given procedure is closed by this
   routine, with all housekeeping taken care of.  Like the window
   input/output routines (below), the cursor is hidden first.
   USAGE: SDIEasyCloseIcon (main) */

{
	ADDObjectRecord		*TheObject;

	ADDListFindObjectByDefProc (&TheObject,DefProc);
	if (TheObject == NULL)
		return (-1);
	if (TheObject->Type != ADDTYPEICON)
		return (-1);
	SDITrackCursor (-1);
	ADDHideObject (&TheObject);
	ADDCloseObject (&TheObject);
	return (0);
}





SDIEasyInput (DefProc,String,Limit)

int	(*DefProc);		/* Input:  Associated procedure */
char	*String;		/* Output: String typed by user */
int	Limit;			/* Input:  Maximum # characters */

/* This routine gets a string of input from the window bound to the given
   procedure.  The routine will return unsuccessfully if the given pro-
   cedure does not belong to a window.  If the window is not frontmost,
   then it is first made frontmost before input occurs.  The "Limit" para-
   meter specifies the maximum number of characters that may be entered;
   this will usually be the length of the caller's string character-array.
   The cursor is hidden before input occurs, and is kept hidden until the
   cursor is tracked again (usually immediately).
   USAGE: SDIEasyInput (main,MyString,80) */

{
	ADDObjectRecord		*TheObject;

	ADDListFindObjectByDefProc (&TheObject,DefProc);
	if ((TheObject == NULL) || (Limit < 1))
		return (-1);
	if (TheObject->Type != ADDTYPEWINDOW)
		return (-1);
	SDITrackCursor (-1);
	ADDBringObjectToFront (&TheObject);
	return (SDIWindowInput (&TheObject,String,Limit));
}





SDIEasyOutput (DefProc,String)

int	(*DefProc) ();		/* Input: Associated procedure */
char	*String;		/* Input: String to print      */

/* This routine prints the given string to the window bound to the given
   procedure.  The routine will return unsuccessfully if the given pro-
   cedure does not belong to a window.  If the window is not frontmost,
   then it is first made frontmost before output occurs.  The cursor is
   hidden before output occurs, and is kept hidden until the cursor is
   tracked again (usually immediately).
   USAGE: SDIEasyOutput (main,"Hello, World!!\n\n\n") */

{
	ADDObjectRecord		*TheObject;

	ADDListFindObjectByDefProc (&TheObject,DefProc);
	if (TheObject == NULL)
		return (-1);
	if (TheObject->Type != ADDTYPEWINDOW)
		return (-1);
	SDITrackCursor (-1);
	ADDBringObjectToFront (&TheObject);
	return (ADDWindowOutput (&TheObject,String));
}



