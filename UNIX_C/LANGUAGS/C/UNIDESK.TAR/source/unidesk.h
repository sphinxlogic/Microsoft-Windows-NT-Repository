/*
 * unidesk.h -- External declarations of globals in add.hi.c, typedefs, includes
 * (C) 1988 Ben Koning [556498717 408/738-1763 ben@ucscf.ucsc.edu]
 */





/* Make sure the following include files are present: */
#ifndef  BUFSIZ
#include <stdio.h>		/* Stdin/stdout/stderr I/O package headers */
#endif

#ifndef  isalpha
#include <ctype.h>		/* Character manipulation macros */
#endif

#ifndef  SIGHUP
#include <signal.h>		/* Signal (interrupt trap) package headers */
#endif

#ifndef  CBREAK
#include <sgtty.h>		/* Low-level terminal I/O package headers */
#endif

#ifndef  TIOCGETP
#include <sys/ioctl.h>		/* I/O Control headers */
#endif

#ifndef  O_NDELAY
#include <fcntl.h>		/* File Control headers */
#endif





/*************************** ADD DEFAULT DEFINITIONS ***********************/
/* These define style and limitations of the ADD package.                  */
/***************************************************************************/





/* Maximum allowable display screen size: */

#define 	ADDMAXX		132
#define		ADDMAXY		48





/* Desktop object "Type" classifications defined so far: */

#define		ADDTYPEWINDOW		1
#define		ADDTYPEMENU		2
#define		ADDTYPEICON		3





/* Locator device ordering; numerical order determines order of priority: */

#define		ADDLOCATORMOUSE		1
#define		ADDLOCATORBITPAD	2
#define		ADDLOCATORTABLET	3
#define		ADDLOCATORKEYBOARD	4





/* Some critical characters: */

#define		ADDCOMMA	','	/* Searched for in formatted strings */
#define		ADDSPACE	' '	/* Drawn to clear windows, etc.      */
#define		ADDKEYUP	'k'	/* Nondedicated locator-up key       */
#define		ADDKEYUPFAST	'K'	/* Nondedicated locator-up key       */
#define		ADDKEYDOWN	'j'	/* Nondedicated locator-down key     */
#define		ADDKEYDOWNFAST	'J'	/* Nondedicated locator-down key     */
#define		ADDKEYLEFT	'h'	/* Nondedicated locator-left key     */
#define		ADDKEYLEFTFAST	'H'	/* Nondedicated locator-left key     */
#define		ADDKEYRIGHT	'l'	/* Nondedicated locator-right key    */
#define		ADDKEYRIGHTFAST	'L'	/* Nondedicated locator-right key    */
#define		ADDKEYBUTTON	' '	/* (Non)dedicated locator-button key */

#define		ADDTIMEOUT	350	/* Locator-driver routine constant   */
#define		ADDNUMFASTX	15	/* For fast cursor-motion keys above */
#define		ADDNUMFASTY	5	/* For fast cursor-motion keys above */





/* Some "look" defaults: */

#define		ADDCHARHORIZONTAL		'-'
#define		ADDCHARVERTICAL			'|'
#define		ADDCHARCORNER			'+'

#define	     	ADDCHARHORIZONTALWINDOW		'='
#define	     	ADDCHARHORIZONTALMENU		'_'

#define		ADDCHARHILITELEFT		'>'
#define		ADDCHARHILITERIGHT		'<'

#define		ADDCHARDRAGFRAME		'#'

#define		ADDCURSORICONPOINT		"5,3,\t\t|\t\t--+--\t\t|\t\t"
#define		ADDCURSORICONSELECT		"5,3,\t\t|\t\t\t-X-\t\t\t|\t\t"
#define		ADDCURSORICONMOVE		"5,3,\t\t|\t\t<-+->\t\t|\t\t"
#define		ADDCURSORICONRESIZE		"5,3,\t\t|\t\t->+<-\t\t|\t\t"

#define		ADDDESKTOPICON 			"2,2,.  ."

#define		SDINUMBLINK			25
#define		SDIHITWINDOWRESIZEX		4
#define		SDIHITWINDOWRESIZEY		2

#define		SDITEMPPATH			"/tmp/unideskXXXXXX"
#define		SDIDAPATH			"$HOME/.unideskrc"

#define		SDISTDMENUNAME			"UniDesk"
#define		SDISTDQUITNAME			"Quit"

#define		SDIEASYGOLOOP			12





/********************** ADD DATA STRUCTURE DEFINITIONS ***********************/
/*                                                                           */
/* The following data structures are used by ADD routines to communicate     */
/* information about desktop objects.  Most of the data fields declared      */
/* below are self-explanatory; however, some of the strings are understood   */
/* to have certain implicit formats.  Some of the implicit types of data     */
/* structures used by ADD are:                                               */
/*                                                                           */
/*	* IconString -- A string representing a two-dimensional picture made */
/*			of characters.  Used by icon, cursor, background,    */
/*			etc., drawing routines.  Format: string, containing  */
/*			Xdimension, Comma, Ydimension, Comma, Data, Null.    */
/*			The data is in left-to-right, top-to-bottom raster-  */
/*			scanned format and may contain commas.  Dimensions   */
/*			are in numbers counted starting at one, not zero.    */
/*                      Commas may freely appear in the data text.  If the   */
/*                      tab character ('\t') appears anywhere within the     */
/*                      string, then that position will be transparent with  */
/*                      respect to what was on the desktop before the icon   */
/*                      was drawn.                                           */
/*                                                                           */
/*	* CustomStrings -- A string used to place user-defined text in       */
/*                         the vicinity of a desktop object, using relative  */
/*                         coordinates in the range 0-100 which indicate a   */
/*                         percentage displacement between the upper left    */
/*                         lower right corners of object.  Format: string:   */
/*                         Xcoordinate, Comma, Ycoordinate, Comma, Text;     */
/*                         followed either by Null or another comma and      */
/*                         another such x,y,text sequence.  Commas are       */
/*                         allowed within text sequences like this: ",,".    */
/*                                                                           */
/*****************************************************************************/





/* Desktop object/item record data structures: */

typedef struct ADDObjectRecord
	{
		int	Dummy;

		/* For all objects: */
		char	*Name;             		/* Title of object   */
		int	(*DefProc) ();			/* Assoc user proc   */
		int 	Hilite;				/* Highlighted?      */

		/* For specific objects: */
		int 	Type;				/* Wnd/Menu/Icon ?!! */
		int	CX,CY;				/* Rel cur pos. wndw */
		char	TextContent[(ADDMAXX*ADDMAXY)]; /* Text in window    */
		struct	ADDItemRecord	*ItemListHead;	/* Item list in menu */
		struct	ADDObjectRecord	*MenuTitleIcon;	/* Menu bar entry    */
		char	*Image;				/* Image str in icon */

		/* For maintaining desktop integrity: */
		int	Layer;				/* For ID & overlap  */
		int	Visible;			/* Visible?          */
		int	X1,Y1,X2,Y2;			/* Current pos/size  */
		char	ScreenSave [ADDMAXX][ADDMAXY];	/* Chars underneath  */
		int	NX1,NX2,NY;			/* Pos of name strng */
		char	ScreenSaveName [ADDMAXX];	/* Chars underneath  */

		/* For custom appearances: */
		char	*CustomStrings;			/* Customizing chars */
		char	CharHorizontal;			/* Horiz border char */
		char	CharVertical;			/* Verti border char */
		char	CharCorner;			/* Cornr border char */

		struct	ADDObjectRecord	*Link;		/* Next ObjectRecord */
	} ADDObjectRecord;

typedef struct ADDItemRecord
	{
		int	X1,X2,Y;			/* Current pos/size  */

		char	*Name;				/* Item title        */
		int	(*DefProc) ();			/* Assoc user proc   */
		int	Hilite;				/* Highlighted?      */

		struct	ADDItemRecord	*Link;		/* Next ItemRecord   */
	} ADDItemRecord;





/**************************** ADD GLOBAL VARIABLES ***************************/
/* The following external global variable declarations refer to declarations */
/* in the ADD source code file "add.hi.c":                                   */
/*****************************************************************************/





/* Text message strings: */

extern	char	ADDCreditMessage	[512];
extern	char	SDISignalMessage	[80];
extern	char	SDIStartupMessage	[80];





/* Desktop frame buffer -- always contains screen contents: */

extern	char	ADDScreenBuffer [ADDMAXX][ADDMAXY];
extern	int	ADDScreenSizeX;
extern	int	ADDScreenSizeY;





/* Global variables pertaining to desktop object record management: */

extern	int			ADDNextLayer;	    	  /* Next layer asgn */
extern	struct ADDObjectRecord	*ADDObjectRecordListHead; /* Head of objlist */





/* Global variables pertaining to cursor/dragframe drawing: */

extern	char		ADDCursorSave [ADDMAXX][ADDMAXY];  /* ScreenSave */
extern	char		ADDDragFrameSave [4][4];	   /* ScreenSave */





/* Global variables pertaining to locator-motion input: */

extern	int		ADDLocatorX;		/* X; scaled 0..ScreenSize */
extern	int		ADDLocatorY;		/* Y; scaled 0..ScreenSize */
extern	int		ADDLocatorDevice;	/* ID of current input dev */

extern	int		ADDLocatorFDS;		/* File descriptor for dev */
extern	struct sgttyb	ADDLocatorIFL;		/* Ioctl original flags    */

 



/* Global variables pertaining to TERMCAP usage: */

extern char ADDTcapBuff [1024];	  /* This is where tgetent() stores data */
extern char ADDTcapArea [1024];	  /* This is where our own tgetstr strings go */
extern char *ADDTcapAreaPtr;	  /* Ptr into area array for next tgetent() */
extern char *ADDTcapClear;	  /* Where in area array the cls string is */
extern char *ADDTcapCursorMotion; /* Where in area array curs motion str is */
extern char *ADDTcapKeyUp;	  /* Where in area array key-up str is */
extern char *ADDTcapKeyDown;	  /* Where in area array key-down str is */
extern char *ADDTcapKeyLeft;	  /* Where in area array key-left str is */
extern char *ADDTcapKeyRight;	  /* Where in area array key-right str is */





/* Global file stream pointer for output to terminal that is not stdout: */

extern FILE	*ADDTtyPtr;	/* Stream pointer of our file "/dev/tty?" */





/* Globals to keep track of next positions for auto object placement: */

extern	int	SDIWindowNextX;		/* Next window position */
extern	int	SDIWindowNextY;
extern	int	SDIMenuNextX;		/* Next menu position */
extern	int	SDIMenuNextY;
extern	int	SDIIconNextX;		/* Next icon position */
extern	int	SDIIconNextY;



