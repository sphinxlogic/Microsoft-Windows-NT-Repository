/* tmain.c -- testbed for developing UniDesk calls.
   (C) 1988 Ben Koning [556498717 408/738-1763 ben@ucscf.ucsc.edu]
   ALL these procedures are to REMAIN here or at least be saved away! */

#include <stdio.h>	/* Redundant--test ifndefs in unidesk.h */
#include "unidesk.h"

int sl = 1;

TestSleep (s)
{
	if (sl) sleep (s);
}

main (argc)
{
if (argc==3) {SDIEasyReady (); SDIEasyGo (NULL);}
if (argc==2) sl=0;
printf ("UniDesk Test Suite -- RUNNING\n\n");
printf ("%s\n\n",ADDCreditMessage);
TestSleep (2);
if (ADDStartUp () == -1)
{
	printf ("Error starting up UniDesk.\n");
	exit (1);
}
else
	ADDShutDown ();
TestList ();
TestEasy ();
TestDeskMgrAndMenuTrack ();
TestAutoObjPosAndMenuTitle ();
TestTracking ();
TestWindowInput ();
TestAnalogInput ();
TestActionDrawing ();
TestHiLevelUse ();
TestHiLevelCreate ();
TestHilite ();
TestObjectDrawing ();
TestCustomStrings ();
TestIconAndScroll ();
TestOverlapPrimitives ();
TestScreenPrimitives ();
}



TestList ()
{
ADDObjectRecord *toy;
ADDItemRecord *item;

printf ("Testing ADD list operations (14)\n");
ADDObjectRecordListHead = NULL;
ADDListInsertObject (&toy);
if (toy==NULL) printf ("NULLLLLL\n");
toy->Hilite = 100; toy->Layer=1; toy->Name ="Alpha";
toy->X1 =0; toy->X2=999; toy->Y1=0; toy->Y2=999;
ADDListInsertObject (&toy);
toy->Hilite = 200; toy->Layer=5; toy->Name="Beta"; toy->Visible = 1;
toy->Type=ADDTYPEWINDOW;
toy->X1 =0; toy->X2=1  ; toy->Y1=0; toy->Y2=2;
ADDListInsertObject (&toy);
toy->Hilite = 300; toy->Layer=3; toy->Name="Gamma"; toy->Visible = 1;
toy->X1 =1000; toy->X2=1999; toy->Y1=1000; toy->Y2=1999;
ADDListFindObjectByName (&toy,"Prancer");
if (toy==NULL) printf ("Pass1\n");
ADDListFindObjectByLoc (&toy,0,0);
if (toy->Hilite==200) printf ("Pass2\n");
ADDListFindObjectByName (&toy,"Beta");
if (toy->Hilite==200) printf ("Pass3\n");
ADDListFindObjectTop(&toy);
if (toy->Hilite==200) printf ("Pass4\n");
ADDListDeleteObject (&toy);
ADDListFindObjectByName (&toy,"Gamma");
if (toy->Hilite==300) printf ("Pass5\n");
ADDListInsertObject (&toy);
toy->Hilite = 400; toy->Layer=2; toy->Name="FFFFF";
toy->X1 =0; toy->X2=999; toy->Y1=0; toy->Y2=999;
ADDListFindObjectTop (&toy);
if (toy->Hilite==300) printf ("Pass6\n");


toy->ItemListHead = NULL;
ADDListInsertItem (&toy,&item);
item->X1=50; item->X2=100; item->Y=5;
item->Name="Item Number One";

ADDListInsertItem (&toy,&item);
item->X1=5000; item->X2=10000; item->Y=5;
item->Name="Item Number Two";

ADDListInsertItem (&toy,&item);
item->X1=5000; item->X2=10000; item->Y=6;
item->Name="Item Number Three";
item->DefProc=TestList;

ADDListFindItemByName (&toy,&item,"Threash");
if (item == NULL) printf ("Pass 7\n");

ADDListFindItemByName (&toy,&item,"Item Number Two");
if ((item->Y==5)&&(item->X1==5000)) printf ("Pass 8\n");

ADDListDeleteItem (&toy,&item);
ADDListFindItemByLoc (&toy,&item,5005,5);
if (item == NULL) printf ("Pass 9\n");

ADDListFindItemByLoc (&toy,&item,55,5);
if ((item->X1 == 50)&&(item->X2==100)) printf ("Pass 10\n");

ADDListDeleteItem (&toy,&item);
ADDListFindItemByName (&toy,&item,"Item Number One");
if (item == NULL) printf ("Pass 11\n");

ADDListFindObjectByName (&toy,"Alpha");
ADDListDeleteObject (&toy);
ADDListFindObjectByName (&toy,"Alpha");
if (toy==NULL) printf ("Pass 12\n");

ADDListInsertObject (&toy);
toy->Hilite = 1234;
toy->DefProc = TestList;
ADDListFindObjectByDefProc (&toy,TestList);
if (toy->Hilite==1234) printf ("Pass  13\n");

ADDListFindObjectByName (&toy,"Gamma");
ADDListFindItemByDefProc (&toy,&item,TestList);
if (strcmp (item->Name,"Item Number Three")==0) printf ("Pass  14\n");

TestSleep (4); ADDShutDown ();
TestSleep (2);
}


TestScreenPrimitives ()
{
printf ("Testing screen output primitives...\n");
ADDStartUp();
printf ("\n\n\n\n\n\n\n\n\nTHIS WILL DISAPPEAR\n");
ADDScreenRefresh (0,0,ADDScreenSizeX,ADDScreenSizeY);
printf ("\n\n\n\n\n\n\n\n\nTHIS WILL NOT DISAPPEAR YET\n");
ADDScreenRefresh (10,1,50,6);
ADDScreenOutput ("Authorized Output At 2,2",2,2);
ADDScreenOutput ("Authorized Output At 50,20",50,20);
ADDScreenOutput ("Authorized Output At 0,7",0,7);
ADDScreenOutput ("Authorized Output At -5,23",-5,23);
ADDScreenOutput ("Authorized Output At 25,23",25,23);
ADDScreenOutput ("Authorized Output At 73,22",73,22);
ADDScreenOutput ("Authorized Output At 73,23",73,23);
TestSleep(5);
ADDScreenRefresh (0,0,ADDScreenSizeX,ADDScreenSizeY);

TestSleep (4); ADDShutDown ();
}

TestOverlapPrimitives()
{
int i,j;
ADDObjectRecord *obj1, *obj2, *obj3;

ADDStartUp();
ADDScreenOutput ("Testing overlap primitives",0,0);
for (i=1; i<=21; i++) 
	ADDScreenOutput (". . . . . . . . . . . . . . . . . . . . . . . .",i,i);
ADDListInsertObject (&obj1);  obj1->Layer = 1;
obj1->X1=0; obj1->Y1=0; obj1->X2=8; obj1->Y2=8;
obj1->NX1=obj1->X1; obj1->NX2=obj1->X2; obj1->NY=obj1->Y1;
obj1->Visible=1;
ADDScreenBlockSave (&obj1);
for (i=obj1->Y1; i<=obj1->Y2; i++)
	for (j=obj1->X1; j<=obj1->X2; j++)
		ADDScreenOutput ("1",i,j);
ADDScreenOutput ("Obj1Top",0,0);

ADDListInsertObject (&obj2);  obj2->Layer = 2;
obj2->X1=5; obj2->Y1=5; obj2->X2=15; obj2->Y2=15;
obj2->NX1=obj2->X1; obj2->NX2=obj2->X2; obj2->NY=obj2->Y1;
obj2->Visible=1;
ADDScreenBlockSave (&obj2);
for (i=obj2->Y1; i<=obj2->Y2; i++)
	for (j=obj2->X1; j<=obj2->X2; j++)
		ADDScreenOutput ("2",i,j);
ADDScreenOutput ("Obj2Top",5,5);

ADDListInsertObject (&obj3);  obj3->Layer = 3;
obj3->X1=10; obj3->Y1=10; obj3->X2=20; obj3->Y2=20;
obj3->NX1=obj3->X1; obj3->NX2=obj3->X2; obj3->NY=obj3->Y1;
obj3->Visible=1;
ADDScreenBlockSave (&obj3);
for (i=obj3->Y1; i<=obj3->Y2; i++)
	for (j=obj3->X1; j<=obj3->X2; j++)
		ADDScreenOutput ("3",i,j);
ADDScreenOutput ("Obj3Top",10,10);
TestSleep(3);

ADDScreenBlockRestore (&obj2); obj2->Visible=0;
TestSleep (1);
ADDScreenBlockRestore (&obj1); obj1->Visible=0;
TestSleep (1);
ADDScreenBlockRestore (&obj3); obj1->Visible=0;

TestSleep (4); ADDShutDown ();
}



TestIconAndScroll ()
{ int i;
ADDStartUp ();
ADDScreenOutput ("> Testing Icon stuff and Scrolling <",25,0);
ADDScreenOutput ("TestTestTestTestTest",74,23);
ADDDrawIcon ("5,3,+===+| , |+-=-+",10,5);
ADDDrawIcon ("5,3,+===+| , |+-=-+",78,5);
ADDDrawIcon ("5,3,+===+| , |+-=-+",78,24);
TestSleep (5);
ADDDrawDesktop ("5,3,+===+| , |+-=-+");
ADDDrawDesktop ("2,2,/\\\\/");
TestSleep (2);
for (i=0; i<26; i++)
	ADDScreenScrollUp (40,5,56,17);
ADDDrawDesktop (ADDDESKTOPICON);
ADDScreenClear ();
ADDScreenOutput ("This is a line of text!",0,3);
ADDScreenOutput ("This is a line",0,5);
ADDScreenOutput ("And another li",0,6);
ADDScreenOutput ("This is a much much much longer llllllline line of text!",0,7);
ADDScreenOutput ("This is a line of text!",0,12);
ADDScreenOutput ("This is lllla line of text!",0,14);
ADDScreenOutput ("This is a line of text!",0,15);
ADDScreenOutput ("This is a text!",0,16);
ADDScreenOutput ("This is a line of text!",0,21);
TestSleep(4);
for (i=0; i<26; i++)
	ADDScreenScrollUp (1,0,79,21);

TestSleep (4); ADDShutDown ();
}

TestCustomStrings ()
{
ADDStartUp (); 
ADDDrawDesktop (ADDDESKTOPICON);
ADDScreenOutput ("Testing ADDDrawCustomStrings",0,23);
ADDDrawCustomStrings ("0,0,Hi,,Corner1,100,100,Hi,,Corner2",0,0,10,10);
ADDDrawCustomStrings ("0,0,A,100,100,B,50,50,c,25,50,>,75,50,<",1,1,78,22);
ADDDrawCustomStrings ("88,88,",0,0,79,23);
ADDDrawCustomStrings ("77,56,,,,,,,3commas,",0,0,79,23);
ADDDrawCustomStrings ("",0,0,79,23);
TestSleep (4); ADDShutDown ();
}

TestObjectDrawing ()
{
ADDObjectRecord *toy;
ADDItemRecord *item;

ADDStartUp (); 
ADDDrawDesktop (ADDDESKTOPICON);
ADDScreenOutput ("Testing Desktop Object Drawing",0,23);
ADDListInsertObject (&toy);
toy->Name="Window Title";
toy->X1=5; toy->Y1=5; toy->X2=75; toy->Y2=10;
toy->CharHorizontal=ADDCHARHORIZONTALWINDOW;
toy->CharVertical=ADDCHARVERTICAL;
toy->CharCorner=ADDCHARCORNER;
ADDDrawNewWindow (&toy);
toy->X1=0; toy->Y1=0; toy->X2=19; toy->Y2=4;
ADDDrawNewWindow (&toy);
toy->X1=40; toy->Y1=0; toy->X2=48; toy->Y2=4;
ADDDrawNewWindow (&toy);
toy->X1=50; toy->Y1=0; toy->X2=62; toy->Y2=4;
ADDDrawNewWindow (&toy);
toy->Name="";
toy->X1=40; toy->Y1=15; toy->X2=62; toy->Y2=20;
ADDDrawNewWindow (&toy);
TestSleep (4);


ADDDrawDesktop (ADDDESKTOPICON);
ADDScreenOutput ("You should see 3 YES:",0,23);
ADDListInsertObject (&toy);
toy->ItemListHead = NULL;
toy->Name="Menu_Title";
toy->X1=5; toy->Y1=5; toy->X2=0; toy->Y2=0;
toy->CharHorizontal = ADDCHARHORIZONTALMENU;
toy->CharVertical = ADDCHARVERTICAL;
ADDDrawNewMenu (&toy);

toy->X1=40; toy->Y1=0; toy->X2=0; toy->Y2=0;
ADDListInsertItem (&toy,&item);
item->Name="You Should Not see this";
ADDListDeleteItem (&toy,&item);
ADDListInsertItem (&toy,&item);
item->Name="Item Number 1";
ADDListInsertItem (&toy,&item);
item->Name="Item Number 2";
ADDListInsertItem (&toy,&item);
item->Name="Calculator";
ADDListInsertItem (&toy,&item);
item->Name="The looooongest line";
ADDListInsertItem (&toy,&item);
item->Name="II";
ADDDrawNewMenu (&toy);
if ((toy->X2==63) && (toy->Y2==7))  ADDScreenOutput ("Yes",30,23);
if (item->X1==41)   ADDScreenOutput ("Yes",34,23);
toy->Y1=20;
if (ADDDrawNewMenu (&toy) == -1)    ADDScreenOutput ("Yes",38,23);

toy->X1=40; toy->Y1=10; toy->Name="Icon_Title";
toy->Image = "3,3,****,****";
ADDDrawNewIcon (&toy);

TestSleep (4); ADDShutDown ();
}


TestHilite ()
{
ADDObjectRecord *obj;
ADDItemRecord *item;

ADDStartUp ();
ADDDrawDesktop (ADDDESKTOPICON);
ADDScreenOutput ("Testing Highlighting & Unhighlighting",0,23);
ADDListInsertObject (&obj); obj->Visible =1;
obj->CharHorizontal='-'; obj->CharVertical='!'; obj->CharCorner='*';

obj->X1=1; obj->Y1=1; obj->X2=50; obj->Y2=7; obj->Name="A Window!";
ADDDrawNewWindow (&obj);
TestSleep (2); ADDShowObjectHilite (&obj);  if (!obj->Hilite) printf ("BUG\n");
TestSleep (2); ADDHideObjectHilite (&obj);  if (obj->Hilite) printf ("BUG\n");

obj->X1=55; obj->Y1=1; obj->Name="An Icon!";
obj->Image = "3,3,---- ----";
ADDDrawNewIcon (&obj);
TestSleep (2); ADDShowObjectHilite (&obj); if (!obj->Hilite) printf ("BUG\n");
TestSleep (2); ADDHideObjectHilite (&obj); if (obj->Hilite)  printf ("BUG\n");

obj->ItemListHead = NULL;
ADDListInsertItem (&obj,&item);
item->Name="Item One Two Three";
ADDListInsertItem (&obj,&item);
item->Name="Item 2";
ADDListInsertItem (&obj,&item);
item->Name="Hilite Me!";

obj->X1=40; obj->Y1=10; obj->Name="A Menu!";
ADDDrawNewMenu (&obj);
TestSleep (2); ADDShowItemHilite (&item);
TestSleep (2); ADDHideItemHilite (&item);

TestSleep (4); printf  ("This simulates messing up of screen... calling ADDRedraw\n\n\n\n\n\n\n\n\n\n\n\n\n");
TestSleep (3);
ADDRedraw ();
TestSleep (4); ADDShutDown ();
}



TestHiLevelCreate ()
{
ADDObjectRecord *obj;
ADDItemRecord *item;

ADDStartUp ();
ADDDrawDesktop (ADDDESKTOPICON);
ADDScreenOutput ("Testing HiLevel open/close routines",0,23);

ADDOpenObject ("Window 0",main,ADDTYPEWINDOW,"",1,1,78,19,&obj);
ADDShowObject (&obj);

ADDOpenObject ("Huge Window 1",main,ADDTYPEWINDOW,"",2,2,78,19,&obj);
ADDShowObject (&obj);

ADDOpenObject ("NOT AN OBJ",main,ADDTYPEICON,"3,3,BUGBUGBUG",33,4,0,0,&obj);
ADDCloseObject (&obj);

ADDOpenObject ("Window Two",main,ADDTYPEWINDOW,"",45,18,75,20,&obj);
ADDShowObject (&obj);

TestSleep (6);
ADDScreenOutput (">  NOW REMOVING Huge Window 1  <",0,21);
TestSleep (2);
ADDListFindObjectByName (&obj,"Huge Window 1");
ADDCloseObject (&obj);

ADDOpenObject ("Menu Three",main,ADDTYPEMENU,"",0,0,0,0,&obj);

ADDOpenObject ("Icon Four",main,ADDTYPEICON,"3,3,****4****",33,4,0,0,&obj);
ADDShowObject (&obj);

ADDOpenObject ("Icon Five",main,ADDTYPEICON,"3,3,****5****",44,4,0,0,&obj);
ADDShowObject (&obj);

ADDListFindObjectByName (&obj,"Menu Three");
ADDOpenItem (&obj,"Menu Three, Item 1",main,&item);
ADDOpenItem (&obj,"Item 2",main,&item);
ADDOpenItem (&obj,"BUG IF YOU SEE THIS1",main,&item);
ADDCloseItem (&obj,&item);
ADDOpenItem (&obj,"Item No. 3",main,&item);
ADDOpenItem (&obj,"4th & last Item",main,&item);
ADDOpenItem (&obj,"BUG IF YOU SEE THIS2",main,&item);
ADDCloseItem (&obj,&item);
ADDShowObject (&obj);

ADDScreenOutput ("Two YES:",0,22);
if (ADDShowObject (&obj) == -1)  ADDScreenOutput ("Yes",12,22);
ADDListFindObjectByName (&obj,"Icon Five");
ADDHideObject (&obj);
if (ADDHideObject (&obj) == -1)  ADDScreenOutput ("Yes",16,22);

ADDScreenOutput ("Visible Now: Window 0, Window Two, Menu Three, Icon Four",0,21);
TestSleep (6);

ADDScreenOutput (">  NOW REMOVING Window 0                                    <",0,21);
TestSleep (2);
ADDListFindObjectByName (&obj,"Window 0");
ADDCloseObject (&obj);
TestSleep (4);

ADDScreenOutput (">  Icon Five appears                                        <",0,21);
TestSleep (2);
ADDListFindObjectByName (&obj,"Icon Five");
ADDShowObject (&obj);

ADDScreenOutput (">  NOW CHANGING Menu Three, Item 2                          <",0,21);
TestSleep (2);
ADDListFindObjectByName (&obj,"Menu Three");
ADDListFindItemByName (&obj,&item,"Item 2");
ADDListDeleteItem (&obj,&item);
ADDHideObject (&obj);
ADDShowObject (&obj);
TestSleep (4);

ADDScreenOutput (">  NOW CALLING CloseAll                                     <",0,21);
TestSleep (2);
ADDCloseAllObjects ();
TestSleep (4); ADDShutDown ();
}



TestHiLevelUse ()
{
ADDObjectRecord *o1,*o2,*o3,*o4,*o5;
ADDItemRecord *i1,*i2;
int a,b;

ADDStartUp ();
ADDDrawDesktop (ADDDESKTOPICON);
ADDScreenOutput ("Testing HiLevel usage/manipulation routines",0,23);
ADDScreenOutput ("C Tests:",0,22);

ADDOpenObject ("Window One",main,ADDTYPEWINDOW,"",2,2,42,12,&o1);
ADDShowObject (&o1);
ADDOpenObject ("Window Two",main,ADDTYPEWINDOW,"",6,4,46,14,&o2);
ADDShowObject (&o2);
ADDOpenObject ("Window Three",main,ADDTYPEWINDOW,"",10,6,50,16,&o3);
ADDShowObject (&o3);
ADDOpenObject ("Window Four",main,ADDTYPEWINDOW,"",14,8,54,18,&o4);
ADDShowObject (&o4);
ADDOpenObject ("Le Menu",main,ADDTYPEMENU,"",0,0,0,0,&o5);
ADDOpenItem (&o5,"Cook's Choice",main,&i1);
ADDOpenItem (&o5,"Bean Delight",main,&i2);
ADDShowObject (&o5);
o5->Hilite = 1; o5->Type=ADDTYPEWINDOW;
ADDShowObjectHilite (&o5);  o5->Type =ADDTYPEMENU;
TestSleep (1);
if (ADDBringObjectToFront (&o5) < 0) 		ADDScreenOutput ("1",11,22);
if (ADDMoveObject (&o1,22,2) < 0) 		ADDScreenOutput ("2",12,22);
if (ADDMoveObject (&o5,75,2) < 0) 		ADDScreenOutput ("3",13,22);
if (ADDWindowOutput (&o1,"BUG1") < 0) 		ADDScreenOutput ("4",14,22);
if (ADDWindowResize (&o1,40,10) < 0) 		ADDScreenOutput ("5",15,22);
ADDHideObject (&o5);
if (ADDBringObjectToFront (&o4) < 0) 		ADDScreenOutput ("6",16,22);
if (ADDWindowResize (&o4,99,18) < 0) 		ADDScreenOutput ("7",17,22);
if (ADDWindowResize (&o4,79,23) < 0) 		ADDScreenOutput ("8",18,22);
if (ADDWindowResize (&o4,1,1) < 0) 		ADDScreenOutput ("9",19,22);
if (ADDMoveObject (&o4,39,13) < 0) 		ADDScreenOutput ("A",20,22);
ADDShowObject (&o5);
if (ADDWindowResize (&o5,20,20) < 0) 		ADDScreenOutput ("B",21,22);
if (ADDWindowOutput (&o5,"BUG2") < 0) 		ADDScreenOutput ("C",22,22);
TestSleep (7);

ADDBringObjectToFront (&o2);
ADDWindowOutput (&o2,"Simple output to Window2");
ADDWindowOutput (&o1,"BUG BUG BUG");
ADDWindowOutput (&o2,"\nOne Line\nAnother Line\nThird Line!\nFourth\n\n\nFive");
TestSleep (3);
ADDWindowOutput (&o2,"\nApples\nOranges\nBananas\nPeaches\nGrapes\nLemons\nPears");
TestSleep (3);

ADDBringObjectToFront (&o3);
for (a=0;a<=13;a++) {
ADDWindowOutput (&o3,"Output To Window Three              ");
}
TestSleep (3);

ADDBringObjectToFront (&o2); TestSleep (2);
ADDWindowResize (&o2,46,14); TestSleep (3);
ADDWindowResize (&o2,46,13); TestSleep (3);
ADDWindowResize (&o2,26,20); TestSleep (3);
ADDWindowResize (&o2,65,15);
TestSleep (7);

ADDBringObjectToFront (&o1); TestSleep (4);

ADDBringObjectToFront (&o5);
ADDMoveObject (&o5,33,7);
TestSleep (4);

ADDCloseObject (&o1);
TestSleep (2);

ADDCloseAllObjects ();

TestSleep (4); ADDShutDown ();
}

TestActionDrawing ()
{
int i;
ADDStartUp ();
ADDDrawDesktop ("3,2,_-~-_~");
ADDScreenOutput ("Testing event-action ergonomic feedback drawing routines",0,23);
ADDScreenOutput ("Object/Icon Show/Hide is tested elsewhere",0,22);
TestSleep (3);
for (i=28; i>=0; i=i-4)
{
	ADDShowDragFrame (i,i/3,79-i,23-i/3);
	TestSleep (1);
	ADDHideDragFrame (i,i/3,79-i,23-i/3);
}
TestSleep (3);

ADDDrawDesktop (ADDDESKTOPICON);
ADDShowCursor (ADDCURSORICONPOINT,0,0);
TestSleep (5);
ADDHideCursor (ADDCURSORICONPOINT,0,0);
TestSleep (3);
ADDShowCursor (ADDCURSORICONPOINT,20,20);
TestSleep (5);
ADDHideCursor (ADDCURSORICONPOINT,20,20);
TestSleep (3);
ADDShowCursor (ADDCURSORICONPOINT,78,23);
TestSleep (5);
ADDHideCursor (ADDCURSORICONPOINT,78,23);
TestSleep (3);

ADDShowCursor (ADDCURSORICONPOINT,10,8);
ADDShowCursor (ADDCURSORICONSELECT,20,8);
ADDShowCursor (ADDCURSORICONMOVE,30,8);
ADDShowCursor (ADDCURSORICONRESIZE,40,8);

TestSleep (5);
ADDShutDown ();
}



TestAnalogInput ()
{
int d,i,oldx,oldy;
ADDStartUp ();
ADDDrawDesktop (ADDDESKTOPICON);
ADDScreenOutput (">   Successful forced options:  ? ? ? ?     <",0,20);
ADDScreenOutput (">   3 Tests:                                <",0,21);
ADDScreenOutput (">   Move cursor around until button-press   <",0,22);

if (ADDLocatorDevice == ADDLOCATORMOUSE)
	ADDScreenOutput (">   Default device is MOUSE                 <",0,23);
if (ADDLocatorDevice == ADDLOCATORBITPAD)
	ADDScreenOutput (">   Default device is BITPAD                <",0,23);
if (ADDLocatorDevice == ADDLOCATORTABLET)
	ADDScreenOutput (">   Default device is TABLET                <",0,23);
if (ADDLocatorDevice == ADDLOCATORKEYBOARD)
	ADDScreenOutput (">   Default device is KEYBOARD              <",0,23);

if (ADDLocatorStartUp (999) == -1)
	ADDScreenOutput ("1",21,21);
if ((ADDLocatorX != 0)&&(ADDLocatorY != 0))
	ADDScreenOutput ("2",22,21);
ADDLocatorUpdate (); /* should return immediately */
ADDScreenOutput ("3",23,21);

ADDLocatorShutDown ();

if ((ADDLocatorStartUp (ADDLOCATORMOUSE) == 0) && 
    (ADDLocatorDevice == ADDLOCATORMOUSE))
	ADDScreenOutput ("M",32,20);
else if (ADDLocatorStartUp (ADDLOCATORMOUSE) == -1)
	ADDScreenOutput ("-",32,20);
ADDLocatorShutDown ();

if ((ADDLocatorStartUp (ADDLOCATORBITPAD) == 0) && 
    (ADDLocatorDevice == ADDLOCATORBITPAD))
	ADDScreenOutput ("B",34,20);
else if (ADDLocatorStartUp (ADDLOCATORBITPAD) == -1)
	ADDScreenOutput ("-",34,20);
ADDLocatorShutDown ();

if ((ADDLocatorStartUp (ADDLOCATORTABLET) == 0) && 
    (ADDLocatorDevice == ADDLOCATORTABLET))
	ADDScreenOutput ("T",36,20);
else if (ADDLocatorStartUp (ADDLOCATORTABLET) == -1)
	ADDScreenOutput ("-",36,20);
ADDLocatorShutDown ();

if ((ADDLocatorStartUp (ADDLOCATORKEYBOARD) == 0) && 
    (ADDLocatorDevice == ADDLOCATORKEYBOARD))
	ADDScreenOutput ("K",38,20);
else if (ADDLocatorStartUp (ADDLOCATORKEYBOARD) == -1)
	ADDScreenOutput ("-",38,20);
ADDLocatorShutDown ();

if (ADDLocatorStartUp (0) == -1)  printf ("BUG\n");

TestSleep (5); i=0; d= 1;

ADDShowCursor (ADDCURSORICONPOINT,ADDLocatorX,ADDLocatorY);
oldx = ADDLocatorX; oldy = ADDLocatorY;
while (ADDLocatorUpdate () == 0)
{
	i += d;
	if ((i>15) || (i< -15))  { d = -1 * d; 
	if (i>0) ADDScreenOutput ("<",70,23); else
	ADDScreenOutput (">",70,23);  }
	if ((oldx != ADDLocatorX) || (oldy != ADDLocatorY))
	{
		ADDHideCursor (ADDCURSORICONPOINT,oldx,oldy);
		ADDShowCursor (ADDCURSORICONPOINT,ADDLocatorX,ADDLocatorY);
		oldx = ADDLocatorX; oldy = ADDLocatorY;
	}
}

ADDShutDown ();
}


TestWindowInput ()
{
char str [256];
ADDObjectRecord *o1;

ADDStartUp ();
ADDScreenOutput ("Testing SDIWindowInput",0,23);
ADDScreenOutput ("Type text in this window; 'exit' quits.",0,22);

ADDOpenObject ("Input Window",main,ADDTYPEWINDOW,"",2,2,22,7,&o1);
ADDShowObject (&o1);

while (strcmp (str,"exit") != 0) {
	SDIWindowInput (&o1,str,64);
	ADDWindowOutput (&o1,"T:");
	ADDWindowOutput (&o1,str);
	ADDWindowOutput (&o1,":T");
	}
ADDShutDown ();
}



TestTracking ()
{
ADDObjectRecord *o1,*o2,*o3;
int x,y;

ADDStartUp ();
ADDScreenOutput ("Testing SDITrackCursor/ObjectMove/WindowResize",0,23);

ADDScreenOutput("Track cursor until button, TWICE; curs should disappear",0,22);
SDITrackCursor (1); SDITrackCursor (1); SDITrackCursor (1); /* Vfy nonblocking */
while (!SDITrackCursor(1)); TestSleep (1); while (!SDITrackCursor(1));

ADDScreenOutput("Resize this window; move cursor ALL OVER THE PLACE!!!  ",0,21);
ADDScreenOutput("Resize activated & terminated by button press NOW.     ",0,22);
ADDOpenObject ("Resize Test Window",main,ADDTYPEWINDOW,"",2,2,22,7,&o1);
ADDShowObject (&o1);
while (!SDITrackCursor(0));
SDITrackWindowResize (&o1,&x,&y);
ADDWindowResize (&o1,x,y);

ADDScreenOutput("Move this window; move cursor ALL OVER THE PLACE!!!    ",0,21);
ADDScreenOutput("Move activated & terminated by button press NOW.       ",0,22);
while (!SDITrackCursor(0));
SDITrackObjectMove (&o1,&x,&y);
ADDMoveObject (&o1,x,y);

ADDOpenObject ("Move Test Menu",main,ADDTYPEMENU,"",2,2,22,7,&o2);
ADDShowObject (&o2); ADDScreenOutput("Move this menu; move cursor ALL OVER THE PLACE!!!    ",0,21);
while (!SDITrackCursor(0));
SDITrackObjectMove (&o2,&x,&y);
ADDMoveObject (&o2,x,y);

ADDOpenObject ("abcdefghijklmnopqrstuvwxyz",main,ADDTYPEICON,"3,3,****I****",2,13,22,7,&o3);
ADDShowObject (&o3); TestSleep (2);
ADDShowObjectHilite (&o3); TestSleep (2); ADDHideObjectHilite (&o3);
ADDScreenOutput("Move this icon; move cursor ALL OVER THE PLACE!!!    ",0,21);
while (!SDITrackCursor(0));
SDITrackObjectMove (&o3,&x,&y);
ADDMoveObject (&o3,x,y);
TestSleep (3);

ADDShutDown ();
}



TestAutoObjPosAndMenuTitle ()
{
ADDObjectRecord *o1,*o2,*o3;
ADDItemRecord *item;
int a,b;

ADDStartUp ();

ADDOpenObject ("Window",main,ADDTYPEWINDOW,"",2,2,12,5,&o1);
ADDShowObject (&o1);
if (SDIOpenShowMenuTitle (&o1) != -1) printf ("BUG\n");

ADDOpenObject ("Menu",main,ADDTYPEMENU,"",0,0,0,0,&o2);
ADDOpenItem (&o2,"Item One",main,&item);
ADDOpenItem (&o2,"Item Two",main,&item);
ADDOpenItem (&o2,"Item Three",main,&item);
ADDOpenItem (&o2,"Item Four",main,&item);
ADDOpenItem (&o2,"Item Five",main,&item);
SDIOpenShowMenuTitle (&o2);
TestSleep (2);
ADDShowObject (&o2);
TestSleep (2);
ADDHideObject (&o2);
TestSleep (2);
SDICloseHideMenuTitle (&o2);
TestSleep (3);

ADDCloseAllObjects ();
for (a=0; a<20; a++)
	{
		ADDOpenObject ("Window",main,ADDTYPEWINDOW,"",0,0,0,0,&o1);
		SDISetNewObjectPosition (&o1);
		ADDShowObject (&o1); TestSleep (1);

		ADDOpenObject ("Menu",main,ADDTYPEMENU,"",0,0,0,0,&o1);
		SDISetNewObjectPosition (&o1);
		ADDShowObject (&o1); TestSleep (1);

		ADDOpenObject ("Icon",main,ADDTYPEICON,"3,3,****I****",0,0,0,0,&o1);
		SDISetNewObjectPosition (&o1);
		ADDShowObject (&o1); TestSleep (1);
	}
ADDCloseAllObjects ();

ADDShutDown ();
}

Teststop () {}


TestDeskMgrAndMenuTrack ()
{
int	(*dp)();
int	i=0;
ADDObjectRecord *win,*obj;
ADDItemRecord *item;

ADDStartUp ();

ADDOpenObject ("Le Menu",main,ADDTYPEMENU,"",0,0,0,0,&obj);
ADDOpenItem (&obj,"Cook's Choice",main,&item);
ADDOpenItem (&obj,"Bean Delight",main,&item);
ADDOpenItem (&obj,"Fried Slug",main,&item);
SDISetNewObjectPosition (&obj);
SDIOpenShowMenuTitle (&obj);

ADDOpenObject ("Exit Menu",main,ADDTYPEMENU,"",0,0,0,0,&obj);
ADDOpenItem (&obj,"Item One",main,&item);
ADDOpenItem (&obj,"Item Two",main,&item);
ADDOpenItem (&obj,"Exit This Demo",Teststop,&item);
SDISetNewObjectPosition (&obj);
SDIOpenShowMenuTitle (&obj);

ADDOpenObject ("Icon 1",main,ADDTYPEICON,"3,3,****1****",0,0,0,0,&obj);
SDISetNewObjectPosition (&obj);
ADDShowObject (&obj);

ADDOpenObject ("Long-Titled Icon Number Two",main,ADDTYPEICON,"3,3,+-+|2|+-+",0,0,0,0,&obj);
SDISetNewObjectPosition (&obj);
ADDShowObject (&obj);

ADDOpenObject ("Window 1",main,ADDTYPEWINDOW,"",0,0,0,0,&obj);
SDISetNewObjectPosition (&obj);
ADDShowObject (&obj);
ADDWindowOutput (&obj,"This is text in Window 1.\n");

ADDOpenObject ("Window 2",main,ADDTYPEWINDOW,"",0,0,0,0,&obj);
SDISetNewObjectPosition (&obj);
ADDShowObject (&obj);
win=obj;

while ((dp= (int(*)()) SDIDesktopManager()) != Teststop)
	if (i++ > 15) {
		i=0;
		ADDWindowOutput (&win,"Hi ");
	}
ADDShutDown ();
}


TestP1 (a,b,c)
{
	SDIEasyOutput (TestP1,"Hello, world!  Inside TestP1, with output \n\
destined for the window belonging to TestP1.\n");

}
TestP2 ()
{
	SDIEasyOutput (TestP2,"testp2");
}
TestP3 ()
{
	SDIEasyOutput (TestP3,"testp3");
}
TestP4 ()
{
	char str [44];
	SDIEasyOutput (TestP4,"Hi there.  Enter Data:\n");
	SDIEasyInput (TestP4,str,40);
	SDIEasyOutput (TestP4,"\nThe data you just entered:\n");
	SDIEasyOutput (TestP4,str);
}
TestPConc ()
{
	static int w=0;
	if (w++ > 45) { w=0;
	SDIEasyOutput (TestP1,"c!"); }
}
TestI1 ()
{ SDIEasyOutput (TestP2,"TestI1 to P2"); }
TestI2 ()
{ SDIEasyOutput (TestP2,"TestI2 to P2"); }
TestI3 ()
{ SDIEasyOutput (TestP2,"TestI3 to P2"); }
TestI4 ()
{ SDIEasyOutput (TestP2,"TestI4 to P2"); }
TestI5 ()
{ SDIEasyOutput (TestP2,"TestI5 to P2"); }



TestEasy ()
{
	char str [256];

	SDIEasyReady ();
	SDIEasyOpenWindow (TestP3,"Window for TestP3");
	SDIEasyOutput (TestP3,"Do Quit Option to see More.");
	SDIEasyOutput (TestP3,"There is no reatime proc now.");
	SDIEasyGo (NULL);

	SDIEasyReady ();
	SDIEasyOpenMenu (TestP4,"Menu One","item");
	SDIEasyOutput (TestP1,"BUG BUG BUG"); /*bug test*/
	SDIEasyOutput (TestP1,str,10); /*bug test */
	SDIEasyOpenWindow (TestP1,"Window P1");
	SDIEasyOpenWindow (TestP2,"Window P2");
	SDIEasyOpenWindow (TestP3,"Window P3");
	SDIEasyGo (TestPConc);

	SDIEasyReady ();
	SDIEasyOpenWindow (TestP1,"Temporary Window");
	SDIEasyOpenMenu   (TestP2,"Temporary Menu","temp");
	SDIEasyOpenIcon   (TestP3,"Temporary Icon","5,2,1234554321");
	if (SDIEasyCloseWindow (TestP2)+  /* bug test */
	SDIEasyCloseMenu (TestP1)+ /* bug test */
	SDIEasyCloseIcon (TestP1)/*bug test*/ != -3)
		ADDScreenOutput ("BUG",0,0);
	sleep (2);
	SDIEasyCloseWindow (TestP1);
	SDIEasyCloseMenu (TestP2);
	SDIEasyCloseIcon (TestP3);
	sleep (2);
	SDIEasyOpenWindow (TestP1,"Window P1");
	SDIEasyOpenWindow (TestP2,"Window P2");
	SDIEasyOpenWindow (TestP3,"Window P3");
	SDIEasyOpenWindow (TestP4,"Window P4 [with input]");
	SDIEasyOpenWindow (TestP3,"BUG"); /* bug test*/
	SDIEasyOpenMenu (TestI1,"Menu One","TestI1");
	SDIEasyOpenMenu (TestI1,"Menu One","ITEMBUG"); /* bug test */
	SDIEasyOpenMenu (TestI2,"Menu One","TestI2");
	SDIEasyOpenMenu (TestI3,"Menu Two","TestI3");
	SDIEasyOpenMenu (TestI4,"Menu Two","TestI4");
	SDIEasyOpenIcon (TestI5,"Icon TestI5","3,3,```'''```");
	SDIEasyOpenIcon (TestI5,"BUG","3,3,``BUG'```"); /*bug test*/
	SDIEasyGo (TestPConc);
}



