/*
 *add.lo.c -- Lo-level routines: screen manipulation and recordkeeping
 *(C) 1988 Ben Koning [556498717 408/738-1763 ben@ucscf.ucsc.edu]
 */





#include "unidesk.h"		/* Our own define's, plus external decs */





/********************* LOWEST-LEVEL OUTPUT ROUTINES: **********************/
/* These routines output text to the screen in a cartesian coordinate     */
/* environment, while always maintaining or using the global character    */
/* buffer, which is at all times identical to screen contents.  Only      */
/* these routines should be used for screen manipulation.                 */
/**************************************************************************/





ADDPutChar (c)

char c;

/* This routine does nothing more than make the putchar macro into a call. 
   This makes it easier to use the termcap "tput" call, and since all 
   low-level ADD calls use it, all ADD output goes here.

   WARNING:  Characters are output only when this routine is called many
   times or if the output buffer is flushed.  See ADDFlushChar, below.
   It is done this way to optimize performance. */

{
	putc (c,ADDTtyPtr);
}





ADDFlushChar ()

/* This routine should be called after performing a few calls to ADDPutChar,
   to insure that enqueued characters are output.  Typically, this routine
   should be called after loops containing ADDPutChar calls or just before
   exitting a routine which produces output. */

{
	fflush (ADDTtyPtr);
}





ADDScreenClear ()

/* This routine quickly clears the entire screen and frame buffer to 
   all SPACES.  Should be used to initialize the frame buffer at first. */

{
	int x,y;

	/* Clear physical terminal screen to spaces: */
	tputs (ADDTcapClear,1,ADDPutChar);
	ADDFlushChar ();

	/* Clear our parallel frame buffer array to spaces: */
	for (y = 0; y <= ADDScreenSizeY; y++)
		for (x = 0; x <= ADDScreenSizeX; x++)
			ADDScreenBuffer [x][y] = ADDSPACE;
}





ADDScreenRefresh (X1,Y1,X2,Y2)

/* This routine redraws the screen from the frame buffer within the
   given bounding rectange, clipping if out of range.  
   USAGE:  ADDScreenRefresh (0,0,ADDScreenSizeX,ADDScreenSizeY) */

{
	int x,y;

	for (y = Y1; y <= Y2; y++)
		/* Clip to Y bounds: */
		if ((y >= 0) && (y <= ADDScreenSizeY))
		{
			/* For every vertical line reposition cursor: */
			tputs (tgoto (ADDTcapCursorMotion,
				(X1<0) ? 0 : X1 ,y),1,ADDPutChar);

			/* Now draw a line from frame buffer to screen: */
			/* Avoid drawing last character to avoid scrolling */
			for (x = X1; x <= X2; x++)
				/* Clip to X bounds: */
				if ((x >= 0) && (x <= ADDScreenSizeX))
					if ( (x != ADDScreenSizeX) || 
				             (y != ADDScreenSizeY) )
					   ADDPutChar (ADDScreenBuffer [x][y]);
		}
	ADDFlushChar ();
}





ADDScreenOutput (String,PosX,PosY)

char *String;
int  PosX,PosY;

/* This routine draws the given string to buffer and screen starting with
   the first character at the given coordinate.  The string should only
   be one line; displaying multiple lines requires repetitive calling
   of this routine.  It clips to the terminal bounds, rather than wrapping 
   text around.  It is the caller's responsibility to insert numbers, etc.,
   into the string by using sprintf, for example.  Control characters are
   reduced to spaces.
   USAGE: ADDScreenOutput ("(Clipped) Hello, world!",-10,10) */

{
	int	i = 0;
	char	c;

	/* Don't waste unnecessary time: */
	if ( (PosY > ADDScreenSizeY) || (PosY < 0) || (PosX > ADDScreenSizeX) )
		return (0);

	/* Place terminal cursor at the correct position: */
	tputs (tgoto (ADDTcapCursorMotion,
	       (PosX < 0) ? 0 : PosX,PosY),1,ADDPutChar);

	/* Read characters from given string until end or out of bounds: */
	/* Avoid drawing the last character to avoid scrolling */
	while (String [i] != '\0')
	{
		if ( ((PosX+i) >= 0) && ((PosX+i) <= ADDScreenSizeX) && 
		     (((PosX+i)!=ADDScreenSizeX) || (PosY!=ADDScreenSizeY)) )
		{
			c = (iscntrl (String [i])) ? ' ' : String [i];
			ADDPutChar (c); 			/* To screen */
			ADDScreenBuffer [PosX+i][PosY] = c;	/* To buffer */
		}
		i++;
	}
	ADDFlushChar ();
	return (0);
}





ADDScreenScrollUp (X1,Y1,X2,Y2)

/* This routine takes the given region of text on the screen and scrolls
   it up one line.  The freed-up line is then cleared to spaces.  This
   routine is heavily optimized for minimum-screen-output performance:
   For every line, the contents are manipulated in memory first.  Then,
   only the lines which actually need updating are drawn to the terminal
   screen, and even those lines are right-truncated if possible. */

{
	int x,y;	/* Iterators through screen and buffer, as usual  */
	int update; 	/* Flag: Where can we get away with not updating? */

	for (y = Y1; y <= Y2; y++)   /* Do the following for every line: */
	{
		update = -1;  /* Start with this, which indicates update all */

		/* First, scroll the current line in the buffer, while    */
		/* setting "update" if we're not moving spaces to spaces: */
		if (y == Y2)   /* Last line, so clear it: */
			for (x = X2; x >= X1; x--)
			{
				if ( (ADDScreenBuffer[x][y] != ADDSPACE) &&
				     (update == -1) )
					update = x;
				ADDScreenBuffer[x][y] = ADDSPACE;
			}
		else   /* Not last line, so move text up from line below: */
			for (x = X2; x >= X1; x--)
			{
				if ( ((ADDScreenBuffer[x][ y ] != ADDSPACE) ||
				      (ADDScreenBuffer[x][y+1] != ADDSPACE)) &&
				     (update == -1) )
					update = x;
				ADDScreenBuffer[x][y] = ADDScreenBuffer[x][y+1];
			}

		/* Second, change current terminal line if "update" set: */
		if (update != -1)
		{
			tputs (tgoto (ADDTcapCursorMotion,X1,y),1,ADDPutChar);
			for (x = X1; x <= update; x++)
				ADDPutChar (ADDScreenBuffer [x][y]);
		}
	}
	ADDFlushChar ();
}





/************ OBJECT/ITEM-RECORD LINKED LIST OPERATIONS ***************/
/* The following calls manipulate the global linked list of object    */
/* records, providing various general "abstract data type" insert,    */
/* delete, and search operations.                                     */
/**********************************************************************/





ADDListInsertObject (Object)

ADDObjectRecord  **Object; /* Output parameter */

/* Allocates storage for an object record, inserts it into the list, and
   returns a pointer to the new record.  This routine should be called FIRST,
   and then the record can be filled with data by the caller. 
   USAGE: ADDListInsertObject (&var), where var is pointer to record. */

{
	/* Allocate storage and provide caller with its location: */
	*Object = (ADDObjectRecord*) (malloc (sizeof (ADDObjectRecord)));

	/* Now insert it into the top of the list: */
	(*Object)->Link	  = ADDObjectRecordListHead;
	ADDObjectRecordListHead = *Object;
}





ADDListDeleteObject (Object)

ADDObjectRecord  **Object; /* Input parameter */

/* Removes the pointed-to object record from the linked list.  Warning:
   The object to be deleted must actually exist in the list!
   USAGE: ADDListDeleteObject (&var), where var is pointer to record. */

{
	ADDObjectRecord		*Chaser;

	/* Chase down list to find the object just before our target object: */
	Chaser = ADDObjectRecordListHead;

	if (Chaser == *Object)
		ADDObjectRecordListHead = (*Object)->Link;
	else
	{
		while (Chaser->Link != *Object)
			Chaser = Chaser->Link;
		Chaser->Link = Chaser->Link->Link;
	}

	/* Deallocate the memory space: */
	free (*Object);
}





ADDListFindObjectTop (Object)

ADDObjectRecord  **Object; 	/* Output: Topmost visible object if found */

/* Searches for the TOPMOST object that is VISIBLE and returns a pointer to
   its ObjectRecord or NULL.
   USAGE: ADDListFindObjectTop (&var), where var is pointer to record. */

{
	ADDObjectRecord		*Chaser;
	int			TopMostSoFar;

	/* Chase down list searching for target, assuming at first not found: */
	*Object      = NULL;
	TopMostSoFar = -1;
	Chaser       = ADDObjectRecordListHead;
	while (Chaser != NULL)
	{
		if ( (Chaser->Layer >= TopMostSoFar) && (Chaser->Visible) )
		{
			TopMostSoFar = Chaser->Layer;
			*Object      = Chaser;
		}
		Chaser = Chaser->Link;
	}
}





ADDListFindObjectByName (Object,NameString)

ADDObjectRecord	    **Object; 		/* Output parameter */
char		    *NameString; 	/* Input  parameter */

/* Finds the FIRST object in the list with the given name or NULL. 
   USAGE: ADDListFindObjectByName (&var,str), where var is pointer to record. */

{
	ADDObjectRecord		*Chaser;

	/* Chase down list searching for target, assuming at first not found: */
	*Object = NULL;
	Chaser  = ADDObjectRecordListHead;
	while (Chaser != NULL)
		if (strcmp (Chaser->Name,NameString) == 0)
		{
			*Object = Chaser;
			break;
		}
		else
			Chaser = Chaser->Link;
}





ADDListFindObjectByDefProc (Object,TheDefProc)

ADDObjectRecord	    **Object; 		/* Output parameter */
int		    (*TheDefProc) (); 	/* Input  parameter */

/* Finds the FIRST object in the list with the given DefProc or NULL. 
   USAGE: ADDListFindObjectByDefProc (&Object,main) */

{
	ADDObjectRecord		*Chaser;

	/* Chase down list searching for target, assuming at first not found: */
	*Object = NULL;
	Chaser  = ADDObjectRecordListHead;
	while (Chaser != NULL)
		if (Chaser->DefProc == TheDefProc)
		{
			*Object = Chaser;
			break;
		}
		else
			Chaser = Chaser->Link;
}





ADDListFindObjectByLoc (Object,x,y)

ADDObjectRecord     **Object; 		/* Output parameter */
int		    x,y;		/* Input parameters */

/* Finds the TOPMOST, VISIBLE object in the list, IN WHICH the given
   coordinate point is CONTAINED; or NULL if not found.  This works
   even if the given point is inside the bounds of the object's "Name"
   field.  This routine is of great importance to event handling and
   screen area restore routines.
   USAGE: ADDListFindObjectByLoc (&ObjectIfFound,x,y) */

{
	ADDObjectRecord		*Chaser;
	int			TopMostSoFar;

	/* Chase down list searching for target, assuming at first not found: */
	*Object      = NULL;
	TopMostSoFar = -1;
	Chaser       = ADDObjectRecordListHead;
	while (Chaser != NULL)
	{
		if ( 
		   	(Chaser->Layer >= TopMostSoFar)		/* Topmost! */
		&&
		   	(Chaser->Visible)			/* Visible! */
		&&
		   	( 
				  (x >= Chaser->X1 	/* Either in Bounds, */
				&& x <= Chaser->X2 
				&& y >= (Chaser->Y1+(Chaser->Type==ADDTYPEMENU))
				&& y <= Chaser->Y2)
	 		||
		   		  (x >= Chaser->NX1	/* , or in the Name! */
				&& x <= Chaser->NX2
				&& y == Chaser->NY)
	 		) 
		   )
		{
			TopMostSoFar = Chaser->Layer;
			*Object      = Chaser;
		}
		Chaser = Chaser->Link;
	}
}





ADDListInsertItem (Object,Item)

ADDObjectRecord	**Object;	/* Input:  Object that is to have this item */
ADDItemRecord	**Item;		/* Output: The item ready to be filled data */

/* This call inserts a new item in the list of items associated with the
   given object.  This routine should be called FIRST, and then the
   record can be filled with data by the caller.  Note that this routine
   inserts the new item at the END of the item list.  This is done so
   that menus, etc., turn out to look as expected.
   USAGE: ADDListInsertItem (&ExistingObjectRecord,&NewItemRecord) */

{
	ADDItemRecord	*Chaser;

	/* Allocate storage and provide caller with its location: */
	*Item = (ADDItemRecord*) (malloc (sizeof (ADDItemRecord)));
	(*Item)->Link = NULL;   /* Since this will be last one */

	/* Find the bottom of the list and insert our new item: */
	Chaser = (*Object)->ItemListHead;
	if (Chaser == NULL)
		(*Object)->ItemListHead = *Item;
	else
	{
		while (Chaser->Link != NULL)
			Chaser = Chaser->Link;
		Chaser->Link = *Item;
	}
}





ADDListDeleteItem (Object,Item)

ADDObjectRecord	**Object;	/* Input: ObjectRecord our item belongs to */
ADDItemRecord	**Item;		/* Input: The ill-fated item to be deleted */

/* Removes the pointed-to ItemRecord from its linked list.  Warning:  The
   item to be removed must actually exist in the list!
   USAGE: ADDListDeleteItem (&ObjectRecord,&ItemRecord) */

{
	ADDItemRecord	*Chaser;

	/* Chase down list to find the item just before our target item: */
	Chaser = (*Object)->ItemListHead;

	if (Chaser == *Item)
		(*Object)->ItemListHead = (*Item)->Link;
	else
	{
		while (Chaser->Link != *Item)
			Chaser = Chaser->Link;
		Chaser->Link = Chaser->Link->Link;
	}

	/* Deallocate memory space: */
	free (*Item);
}





ADDListFindItemByName (Object,Item,NameString)

ADDObjectRecord	**Object;	/* Input:  ObjectRecord with item list */
ADDItemRecord	**Item;		/* Output: ItemRecord being searched   */
char		*NameString;	/* Input:  The name string             */

/* Finds the FIRST item in the list with the given name or NULL.
   USAGE: ADDListFindItemByName (&ObjectRecord,&TheItem,"SearchKey") */

{
	ADDItemRecord	*Chaser;

	/* Chase down list searching for target, assuming at first not found: */
	*Item = NULL;
	Chaser = (*Object)->ItemListHead;
	while (Chaser != NULL)
		if (strcmp (Chaser->Name,NameString) == 0)
		{
			*Item = Chaser;
			break;
		}
		else
			Chaser = Chaser->Link;
}





ADDListFindItemByDefProc (Object,Item,TheDefProc)

ADDObjectRecord	**Object;		/* Input:  ObjectRec with item list */
ADDItemRecord	**Item;			/* Output: ItemRec being searched   */
int		(*TheDefProc) ();	/* Input:  The definition procedure */

/* Finds the FIRST item in the list with the given DefProc or NULL.
   USAGE: ADDListFindItemByDefProc (&ObjectRecord,&TheItem,main) */

{
	ADDItemRecord	*Chaser;

	/* Chase down list searching for target, assuming at first not found: */
	*Item = NULL;
	Chaser = (*Object)->ItemListHead;
	while (Chaser != NULL)
		if (Chaser->DefProc == TheDefProc)
		{
			*Item = Chaser;
			break;
		}
		else
			Chaser = Chaser->Link;
}





ADDListFindItemByLoc (Object,Item,X,Y)

ADDObjectRecord	**Object;	/* Input:  The object record with item list */
ADDItemRecord	**Item;		/* Output: The item record we want or NULL  */
int		X,Y;		/* Input:  Coordinates as search key        */

/* Finds the FIRST item in the list belonging to the given object 
   IN WHICH the given coordinate point is CONTAINED or NULL if not found.
   USAGE: ADDListFindItemByLoc (&ObjectRecord,&TheItem,5,5) */

{
	ADDItemRecord	*Chaser;

	/* Chase down list searching for target, assuming at first not found: */
	*Item = NULL;
	Chaser = (*Object)->ItemListHead;
	while (Chaser != NULL)
	{
		if ((Chaser->X1 <= X) && (Chaser->X2 >= X) && (Chaser->Y == Y))
		{
			*Item = Chaser;
			break;
		}
		Chaser = Chaser->Link;
	}
}





/************* OVERLAPPING SCREEN AREA SUPPORT ROUTINES: *************/
/* These calls implement the "overlapping papers" model of the       */
/* "desktop", by saving or restoring patches of the screen about to  */
/* be, or previously obscured by, other display activity.            */
/*********************************************************************/





ADDScreenBlockSave (Object)

ADDObjectRecord **Object;

/* This routine saves the screen area inside the rectangle given inside the
   given ObjectRecord from the screen buffer into the buffer contained inside
   the given ObjectRecord.  Unlike ADDScreenBlockRestore, it does not pay any 
   attention to whatever layer number might be inside the ObjectRecord; so the
   object whose image is being saved should be topmost.  Usually, this routine
   will be called while drawing a new object, so that the new object's 
   ObjectRecord contains an image of the screen area it is obscuring, so that
   it may later be restored when the object is removed.  In addition to the
   given rectange, the object title line is also saved.
   USAGE:  ADDSaveScreenArea (&ObjectRecordPointer) */

{
	int x,y;

	/* Save the object contents: */
	for (y = (*Object)->Y1 + ((*Object)->Type == ADDTYPEMENU); 
	     y <= (*Object)->Y2; y++)
		for (x = (*Object)->X1; x <= (*Object)->X2; x++)
			if (x >= 0 && y >= 0 && 
			    x <= ADDScreenSizeX && y <= ADDScreenSizeY)
				(*Object)->ScreenSave [x][y] =
				ADDScreenBuffer [x][y];

	/* Save the object title line: */
	for (x = (*Object)->NX1; x <= (*Object)->NX2; x++)
		if (x >= 0 && (*Object)->NY >= 0 && 
		    x <= ADDScreenSizeX && (*Object)->NY <= ADDScreenSizeY)
			(*Object)->ScreenSaveName [x] = 
			ADDScreenBuffer [x][(*Object)->NY];
}





ADDScreenBlockRestore (Object)

ADDObjectRecord **Object;

/* This routine restores the screen area previously obscured by the
   given object after calling ADDScreenBlockSave (see description above). 
   This routine takes into account the object's layer number, so that it 
   works correctly even if the object being deleted is not currently topmost,
   and is possibly partially obscured.  Usually, this routine is called
   while either closing an object or resizing or moving an object.  In
   addition to the object contents, the screen area previously obscured
   by its title line is also restored.  WARNING: The object whose area
   underneath is being restored by this routine should currently be visible.
   And no, the author is *not* proud of the complexity of this routine.
   USAGE:  ADDRRestoreScreenArea (&ObjectRecordPointer) */

{
	int 		x,y;		/* Scanning through block            */
	int		leastdiff;	/* Searching for next highest object */
	ADDObjectRecord *NextHighest;	/* Searching for next highest object */
	ADDObjectRecord *Chaser;	/* Searching for next highest object */

	/* Job 1: Restore the screen area taken up by the title line: */
	/* Copy pixels from ObjectRec only if no frontmore objects in front: */
	y = (*Object)->NY;
	x = (*Object)->NX1;
	tputs (tgoto (ADDTcapCursorMotion,
		(x < 0 || x > ADDScreenSizeX) ? 0 : x,
		(y < 0 || y > ADDScreenSizeY) ? 0 : y),1,ADDPutChar);
	for (; x <= (*Object)->NX2; x++)
	   if (x >= 0 && y >= 0 && x <= ADDScreenSizeX && y <= ADDScreenSizeY
	      && (x != ADDScreenSizeX || y != ADDScreenSizeY))
	{
		/* First, update screen/buffer only where necessary: */
		ADDListFindObjectByLoc (&NextHighest,x,y);
		if (NextHighest == *Object)  /* OK-restore */
		{
		   ADDPutChar ((*Object)->ScreenSaveName[x]);
		   ADDScreenBuffer[x][y] = 
			(*Object)->ScreenSaveName[x];
		}
		else  /* Not ok-skip by doing nondestructive space */
		   ADDPutChar (ADDScreenBuffer[x][y]);

		/* Second, update other ObjectRecords if necessary: */
		/* The ObjRec with the next-higher layer than us    */
		/* gets their ScreenSaveName or ScreenSave set to   */
		/* our ScreenSaveName at the current point.         */
		Chaser      = ADDObjectRecordListHead;
		leastdiff   = -1;
		NextHighest = NULL;
		while (Chaser != NULL)
		{
			if ( (Chaser->Layer > (*Object)->Layer) 
				&&
			     (Chaser->Visible) 
				&&
			     ( (x >= Chaser->X1 && x <= Chaser->X2  &&
				y >= Chaser->Y1 && y <= Chaser->Y2) ||
			       (x >= Chaser->NX1 && x <= Chaser->NX2 &&
				y == Chaser->NY) ) 
				&&
			     (((Chaser->Layer - (*Object)->Layer) < 
				leastdiff) || (leastdiff == -1)) )
			{
				leastdiff = Chaser->Layer -
					    (*Object)->Layer;
				NextHighest = Chaser;
			}
			Chaser = Chaser->Link;
		}
		if (leastdiff > 0)
		{
			if ( (x >= NextHighest->NX1) &&
			     (x <= NextHighest->NX2) &&
			     (y == NextHighest->NY) )
				NextHighest->ScreenSaveName[x]
				= (*Object)->ScreenSaveName[x];
			if ( (x >= NextHighest->X1) &&
			     (x <= NextHighest->X2) &&
			     (y >= NextHighest->Y1) &&
			     (y <= NextHighest->Y2) )
				NextHighest->ScreenSave[x][y]
				= (*Object)->ScreenSaveName[x];
		}
	}

	/* Job 2: Restore the screen area taken up by the object contents: */
	/* Copy pixels from ObjectRec only if no frontmore objects in front: */
	for (y = (*Object)->Y1 + ((*Object)->Type == ADDTYPEMENU);
	     y <= (*Object)->Y2; y++)
	{
		tputs (tgoto (ADDTcapCursorMotion,
		      ((*Object)->X1 < 0 || (*Object)->X1 > ADDScreenSizeX) ?
			0 : (*Object)->X1,
			(y < 0 || y > ADDScreenSizeY) ? 0 : y),1,ADDPutChar);
		for (x = (*Object)->X1; x <= (*Object)->X2; x++)
	   	   if (x >= 0 && y >= 0 && 
		       x <= ADDScreenSizeX && y <= ADDScreenSizeY
		       && (x != ADDScreenSizeX || y != ADDScreenSizeY))
		{
			/* First, update screen/buffer only where necessary: */
			ADDListFindObjectByLoc (&NextHighest,x,y);
			if (NextHighest == *Object)  /* Ok-do update */
			{
			   ADDPutChar ((*Object)->ScreenSave[x][y]);
			   ADDScreenBuffer[x][y] = (*Object)->ScreenSave[x][y];
			}
			else  /* Not ok-skip by doing nondestructive space */
			   ADDPutChar (ADDScreenBuffer[x][y]);

			/* Second, update other ObjectRecords if necessary: */
			/* The ObjRec with the next-higher layer# than us   */
			/* gets their ScreenSave or ScreenSaveName set to   */
			/* our ScreenSave at the current point.             */
			Chaser      = ADDObjectRecordListHead;
			leastdiff   = -1;
			NextHighest = NULL;
			while (Chaser != NULL)
			{
				if ( (Chaser->Layer > (*Object)->Layer) 
					&&
				     (Chaser->Visible) 
					&&
				     ( (x >= Chaser->X1 && x <= Chaser->X2  &&
					y >= Chaser->Y1 && y <= Chaser->Y2) ||
				       (x >= Chaser->NX1 && x <= Chaser->NX2 &&
					y == Chaser->NY) ) 
					&&
				     (((Chaser->Layer - (*Object)->Layer) < 
					leastdiff) || (leastdiff == -1)) )
				{
					leastdiff = Chaser->Layer -
						    (*Object)->Layer;
					NextHighest = Chaser;
				}
				Chaser = Chaser->Link;
			}
			if (leastdiff > 0)
			{
				if ( (x >= NextHighest->NX1) &&
				     (x <= NextHighest->NX2) &&
			   	     (y == NextHighest->NY) )
					NextHighest->ScreenSaveName[x]
					= (*Object)->ScreenSave[x][y];
				if ( (x >= NextHighest->X1) &&
			     	     (x <= NextHighest->X2) &&
			     	     (y >= NextHighest->Y1) &&
			     	     (y <= NextHighest->Y2) )
					NextHighest->ScreenSave[x][y]
					= (*Object)->ScreenSave[x][y];
			}
		}
	}

	/* Make sure all characters go out to the terminal at this time: */
	ADDFlushChar ();
}



