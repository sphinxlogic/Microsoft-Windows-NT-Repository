/*
 *add.hi.c -- Hi-level routines: high level desktop model, cursor, globals
 *(C) 1988 Ben Koning [556498717 408/738-1763 ben@ucscf.ucsc.edu]
 */





#include "unidesk.h"		/* Our own define's, plus external decs */





/************************** GLOBAL VARIABLES ***************************/
/* These global variables must be maintained throughout all ADD calls. */
/* They are all declared as "external" in the file "unidesk.h".        */
/***********************************************************************/





/* Text message strings: */

char	ADDCreditMessage [512] = "\n\
UniDesk -- (C) 1988 Ben Koning [556498717 ben@ucscf.UCSC.EDU 408/738-1763]\n\
University of California, Santa Cruz, CA, 95064\n\
1360 Flicker Way, Sunnyvale, CA, 94087-3407\n\
ADD (Ascii-Terminal Desktop Driver)    V1.0\n\
SDI (Simplified Desktop Interface)     V1.0\n\
";
char	SDISignalMessage  [80] = "UniDesk: Abnormal Termination.";
char	SDIStartupMessage [80] = "UniDesk: Insufficient Resources.";





/* Desktop frame buffer: */

char	ADDScreenBuffer [ADDMAXX][ADDMAXY];
int	ADDScreenSizeX;
int	ADDScreenSizeY;





/* Global variables pertaining to desktop object record management: */

int			ADDNextLayer;	    	  /* Next available layer */
struct ADDObjectRecord	*ADDObjectRecordListHead; /* Head of linked list  */





/* Global variables pertaining to cursor/dragframe drawing: */

char		ADDCursorSave [ADDMAXX][ADDMAXY];   /* ScreenSave */
char		ADDDragFrameSave [4][4];	    /* ScreenSave */





/* Global variables pertaining to locator input device handling: */

int		ADDLocatorX;		/* X (0..ScreenSize) after update */
int		ADDLocatorY;		/* Y (0..ScreenSize) after update */
int		ADDLocatorDevice;	/* Currently selected lctr device */

int		ADDLocatorFDS;		/* File descriptor for input dev  */
struct sgttyb	ADDLocatorIFL;		/* Original ioctl flag save       */





/* Global variables pertaining to TERMCAP usage: */

char	 ADDTcapBuff [1024];	/* This is where tgetent() stores data */
char	 ADDTcapArea [1024];	/* This is where our own tgetstr strings go */
char	*ADDTcapAreaPtr;	/* Pointer into area array for next tgetent() */
char	*ADDTcapClear;		/* Where in area array the cls string is */
char	*ADDTcapCursorMotion;	/* Where in area array curs motion string is */
char	*ADDTcapKeyUp;		/* Where in area array key-up string is */
char	*ADDTcapKeyDown;	/* Where in area array key-down string is */
char	*ADDTcapKeyLeft;	/* Where in area array key-left string is */
char	*ADDTcapKeyRight;	/* Where in area array key-right string is */





/* Global file stream pointer for output terminal that is not stdout: */

FILE	*ADDTtyPtr;		/* Stream pointer of our file "/dev/tty?" */





/* Globals to keep track of next positions for auto object placement: */

int	SDIWindowNextX;		/* Next window position */
int	SDIWindowNextY;
int	SDIMenuNextX;		/* Next menu position */
int	SDIMenuNextY;
int	SDIIconNextX;		/* Next icon position */
int	SDIIconNextY;





/************************ HOUSEKEEPING ROUTINES **************************/
/* The startup routine below should be called before any other ADD       */
/* routine is called; it performs important initialization tasks.  Like- */
/* wise, the shutdown routine below should be called before exiting a    */
/* process that has been using ADD; it deallocates resources used.  The  */
/* redraw routine should be called when the integrity of the terminal    */
/* screen is uncertain; ie, if the user types control-L.                 */
/*************************************************************************/





ADDStartUp ()

/* Main initialization routine for ADD.  Must be called before any other
   ADD routine is called.  This routine returns the ADD version ID number,
   or -1 if error.  If an error occurs, other ADD routines should not
   be called. */

{
	/* Initialize some global variables: */
	ADDObjectRecordListHead = NULL;		/* ObjectRecord linked list */
	ADDNextLayer = 1;			/* Next available layer ID  */

	/* Start up TERMCAP, setup screen/keyboard globals: */
	ADDTcapAreaPtr = ADDTcapArea;
	if (tgetent (ADDTcapBuff,getenv ("TERM")) != 1)
		return (-1);  /* We must have these capabilities! */
	ADDTcapClear        = (char *) tgetstr ("cl",&ADDTcapAreaPtr);
	ADDTcapCursorMotion = (char *) tgetstr ("cm",&ADDTcapAreaPtr);
	ADDTcapKeyUp	    = (char *) tgetstr ("ku",&ADDTcapAreaPtr);
	ADDTcapKeyDown	    = (char *) tgetstr ("kd",&ADDTcapAreaPtr);
	ADDTcapKeyLeft	    = (char *) tgetstr ("kl",&ADDTcapAreaPtr);
	ADDTcapKeyRight	    = (char *) tgetstr ("kr",&ADDTcapAreaPtr);
	ADDScreenSizeX      =          tgetnum ("co") - 1;
	ADDScreenSizeY      =          tgetnum ("li") - 1;
	if ( (ADDTcapClear == NULL) || (ADDTcapCursorMotion == NULL) ||
	     (ADDScreenSizeX < 15)  || (ADDScreenSizeY < 3) )
		return (-1);  /* We can't hack such situations! */

	/* If output device too big, just use a part of it: */
	if (ADDScreenSizeX > (ADDMAXX-1))
		ADDScreenSizeX = (ADDMAXX-1);
	if (ADDScreenSizeY > (ADDMAXY-1))
		ADDScreenSizeY = (ADDMAXY-1);

	/* Open our own stream for tty I/O so we can circumvent stdout/err: */
	if ((ADDTtyPtr = (FILE *) fopen (ttyname (1),"a+")) == NULL)
		return (-1);

	/* Initialize with the best locator device available: */
	if (ADDLocatorStartUp (0) == -1)
		return (-1);

	/* Allow the auto object positon routine to work correctly: */
	SDIWindowNextX = -1;
	SDIWindowNextY = -1;
	SDIMenuNextX   = -1;
	SDIMenuNextY   = -1;
	SDIIconNextX   = -1;
	SDIIconNextY   = -1;

	/* Initialize buffer and clear screen: */
	ADDScreenClear ();

	return (1);  /* Version ID number */
}





ADDRedraw ()

/* This routine is mainly provided as a total-screen refresh for use in
   case the integrity of the terminal screen has been violated.  Should
   be called on a control-L keypress, or after executing a "desk accessory"
   process, etc. */

{
	extern int	ADDPutChar ();

	/* Clear the terminal screen (but not our buffer): */
	tputs (ADDTcapClear,1,ADDPutChar);

	/* Refresh screen (also does ADDFlushChar): */
	ADDScreenRefresh (0,0,ADDScreenSizeX,ADDScreenSizeY);
}





ADDShutDown ()

/* This routine reallocates dynamic resources.  Must be the last ADD
   routine called. */

{
	ADDObjectRecord	*ObjectChaser;
	ADDItemRecord	*ItemChaser;
	extern int	ADDPutChar ();

	/* Delete entire 2-level nested linked list of Object/Item-Records: */
	ObjectChaser = ADDObjectRecordListHead;
	while (ObjectChaser != NULL)
	{
		ItemChaser = ObjectChaser->ItemListHead;
		while (ItemChaser != NULL)
		{
			free (ItemChaser);
			ItemChaser = ItemChaser->Link;  /* OK to do this */
		}
		free (ObjectChaser);
		ObjectChaser = ObjectChaser->Link;  /* OK to do this */
	}

	/* Shut down locator-input device: */
	ADDLocatorShutDown ();

	/* Clear screen before exiting, to be neat: */
	tputs (ADDTcapClear,1,ADDPutChar);
	ADDFlushChar ();

	/* Close our tty stream: */
	fclose (ADDTtyPtr);
}





/************** HIGH-LEVEL OBJECT MANIPULATION ROUTINES ***************/
/*                                                                    */
/* These calls allow the ADD-user to dynamically create new objects,  */
/* manipulate them at a fairly high level of abstraction by adding    */
/* and removing items to them, etc., and finally to delete them.      */
/* While calling these operations, the integrity of the desktop is    */
/* fully maintainted.  The usage of these routines is as follows:     */
/*                                                                    */
/*  *  Call ADDOpenObject to identify the object-type and provide     */
/*     necessary information.  At this time, a new ObjectRecord will  */
/*     be set up in the global linked list and it will be filled      */
/*     with default style characters, etc.                            */
/*                                                                    */
/*  *  Optionally, modify some of the fields in the new object's      */
/*     ObjectRecord, by dereferencing the ObjectRecord pointer        */
/*     provided by ADDOpenObject.                                     */
/*                                                                    */
/*  *  Optionally, call ADDOpenItem to add items, for example, if     */
/*     the object is a menu.                                          */
/*                                                                    */
/*  *  Optionally, call ADDCloseItem to remove items, for example, if */
/*     the object is a menu.                                          */
/*                                                                    */
/*  *  Call ADDShowObject to actually cause the object to appear on   */
/*     the desktop.  It will be the new topmost object, overlaying    */
/*     whatever was fully or partially underneath.                    */
/*                                                                    */
/*  *  Optionally, call ADDHideObject to restore the desktop contents */
/*     underneath the object and to cause it to disappear.  Since     */
/*     its ObjectRecord (with all its customizations and/or items)    */
/*     still exists, however, calling ADDShowObject will cause it to  */
/*     appear again (on top of everything else, thus bringing it      */
/*     to the top).                                                   */
/*                                                                    */
/*  *  Call ADDCloseObject to remove the object from the desktop and  */
/*     from the object list.  This works correctly whether or not     */
/*     the object is currently visible on the desktop.                */
/*                                                                    */
/*  While the object is open and visible on the desktop, routines in  */
/*  next section can be called for movement, resizing, output, etc.   */
/*                                                                    */
/**********************************************************************/





ADDOpenObject (Name,DefProc,Type,Image,X1,Y1,X2,Y2,Object)

char		*Name;		/* Input:  Title string of object (for all) */
int		(*DefProc) ();	/* Input:  Assoc user-procedure   (for all) */
int		Type;		/* Input:  Window/Menu/Icon/etc?  (for all) */
char		*Image;		/* Input:  IconString-format str (for icon) */
int		X1,Y1;		/* Input:  Upper-Left boundary    (for all) */
int		X2,Y2;		/* Input:  Lower-Right boundary  (for wndw) */
ADDObjectRecord	**Object;	/* Output: ObjectRecord of new object       */

/* This routine does the internal bookkeeping for creating a new object
   on the desktop.  It adds a new ObjectRecord to the global linked list,
   and stuffs it with the given information, plus default information
   for all types of objects and specific default information based on
   the type of object being opened.  The object is set up as invisible
   (since this routine doesn't actually draw it yet).  NOTE:  Some of the
   input parameters will not make sense for all objects, such as X2Y2 for an
   icon, for example, or the DefProc, in some cases.  If so, they should
   be given dummy values or null strings when calling this routine.
   The output ObjectRecord parameter retured by this routine may be dis-
   carded by the caller, if desired; the new ObjectRecord is now in the
   linked list and can be found by the ADD- linked list search operations.
   USAGE EXAMPLES: 
	ADDOpenObject ("Window Title",main,ADDTYPEWINDOW,"",5,1,50,6,&Obj)
	ADDOpenObject ("Menu Title",main,ADDTYPEMENU,"",5,1,0,0,&Obj)
	ADDOpenObject ("Icon Title,main,ADDTYPEICON,"2,2,#%%#",5,1,0,0,&Obj) */

{
	int	i;		/* Iterator thru array */

	/* Add new ObjectRecord to the global list; pass address to caller: */
	ADDListInsertObject (Object);

	/* Fill record fields with given pointers to the caller's data: */
	(*Object)->Name    = Name;
	(*Object)->DefProc = DefProc;
	(*Object)->Type    = Type;
	(*Object)->Image   = Image;
	(*Object)->X1      = X1;
	(*Object)->Y1      = Y1;
	(*Object)->X2      = X2;
	(*Object)->Y2      = Y2;

	/* Fill remaining fields with default data: */
	/* ScreenSave, NX1, NX2, NY, ScreenSaveName fields aren't set here  */
	(*Object)->Hilite        = 0;		/* Not highlighted          */
	(*Object)->CX            = 0;		/* Relative position cursor */
	(*Object)->CY            = 0;		/* position in window home  */
	(*Object)->ItemListHead  = NULL;	/* So list insert works ok  */
	(*Object)->MenuTitleIcon = NULL;	/* For menu bar entry       */
	(*Object)->Layer         = -1;		/* Not assigned here; bogus */
	(*Object)->Visible       = 0;		/* Invisible just now       */
	if (Type == ADDTYPEWINDOW)		/* Fill text area w spaces  */
		for (i = 0;   i <= (ADDScreenSizeX*ADDScreenSizeY);   i++)
			(*Object)->TextContent [i] = ADDSPACE;

	/* Fill style-control fields depending on the type of object: */
	(*Object)->CharHorizontal = ADDCHARHORIZONTAL;
	(*Object)->CharVertical   = ADDCHARVERTICAL;
	(*Object)->CharCorner     = ADDCHARCORNER;
	(*Object)->CustomStrings  = "";
	if (Type == ADDTYPEWINDOW)
		(*Object)->CharHorizontal = ADDCHARHORIZONTALWINDOW;
	if (Type == ADDTYPEMENU)
		(*Object)->CharHorizontal = ADDCHARHORIZONTALMENU;
}





ADDOpenItem (Object,Name,DefProc,Item)

ADDObjectRecord	**Object;	/* Input:  Object to which item is added */
char		*Name;		/* Input:  Title string of new item      */
int		(*DefProc) ();	/* Input:  Associated user-procedure     */
ADDItemRecord	**Item;		/* Output: Newly created ItemRecord      */

/* This routine attributes a new item to the given object.  The newly
   created ItemRecord is stuffed with the given- and default-
   information.  NOTE: If this is done to an item whose object is currently
   visible on the desktop, then the effects will not be seen until
   the item is hidden and then shown again.  This routine is normally
   used to add items to objects which are menus.  As with ADDOpenObject,
   not all of the parameters must be given nondummy values.
   USAGE: ADDOpenItem (&MyMenuObjectRecord,"Item Title 1",main,&ItemRecord) */

{
	/* Add new ItemRecord to the object's linked list; pass address: */
	ADDListInsertItem (Object,Item);

	/* Fill ItemRecord fields with given pointers to the caller's data: */
	(*Item)->Name    = Name;
	(*Item)->DefProc = DefProc;

	/* Fill remaining fields with default data: */
	(*Item)->Hilite  = 0;  /* Not highlighted */
	/* X1, X2, Y fields aren't set here */
}





ADDShowObject (Object)

ADDObjectRecord	**Object;	/* Input: Object to display */

/* This routine actually displays the given object, which must be
   currently open.  The object drawn will be the new topmost object;
   hence a new layer number is assigned here.  This routine can be 
   used freely in conjunction with ADDHideObject, and can be called
   safely on *any* open object. */

{  
	/* The object MUST be currently hidden, else return with error: */
	if ((*Object)->Visible)
		return (-1);

	/* Assign a new, unique, highest (topmost) layer number: */
	(*Object)->Layer = ADDNextLayer++;

	/* Call correct drawing routine which saves the screen area under-  */
	/* neath, draws object, and fills useful Object-Item-Record fields: */
	switch ((*Object)->Type)
	{
		case ADDTYPEWINDOW : ADDDrawNewWindow (Object);
		break;

		case ADDTYPEMENU   : ADDDrawNewMenu (Object);
		break;

		case ADDTYPEICON   : ADDDrawNewIcon (Object);
		break;

		default            : return (-2);  /* What type is it?!! */
	}

	/* Flag the object as now being visible: */
	(*Object)->Visible = 1;
	return (0);
}





ADDHideObject (Object)

ADDObjectRecord	**Object;	/* Input: Object to undisplay */

/* This routine actually un-displays the given object, restoring
   what was underneath the object when ADDShowObject was called on
   it.  This routine can be used freely in conjunction with
   ADDShowObject, can be called safely on *any* open object, and
   even works correctly if the given object is not frontmost. */

{
	/* The object MUST be currently shown, else return with error: */
	if (!(*Object)->Visible)
		return (-1);

	/* Restore screen underneath object, but only where we can see it: */
	ADDScreenBlockRestore (Object);

	/* Flag the object as now being hidden: */
	(*Object)->Visible = 0;
	return (0);
}





ADDCloseItem (Object,Item)

ADDObjectRecord	**Object;	/* Input: Object from which to remove item */
ADDItemRecord	**Item;		/* Input: Item to close                    */

/* This routine removes the given item from the given object.  NOTE: If this
   is done to an item whose object is currently visible on the desktop, then
   the effects will not be seen until the item is hidden and then shown again.
   This routine is normally used to remove items from objects which are menus.
   USAGE: ADDCloseItem (&MyMenuObjectRecord,&IllFatedItemRecord) */

{
	ADDListDeleteItem (Object,Item);  /* This call is simply an alias */
}





ADDCloseObject (Object)

ADDObjectRecord	**Object;	/* Input: Object to close */

/* This does the internal bookkeeping for permanently removing an object
   from the desktop.  This routine may be called with the given object
   either as visible or hidden on the desktop; if it is visible, then it
   is hidden before ObjectRecord removal. */

{
	ADDItemRecord	*Chaser;

 	/* If object is currently visible, hide it first: */
	if ((*Object)->Visible)
		ADDHideObject (Object);

	/* Deallocate storage for all its ItemRecords, if any: */
	Chaser = (*Object)->ItemListHead;
	while (Chaser != NULL)
	{
		free (Chaser);
		Chaser = Chaser->Link;  /* OK to do this */
	}

	/* Deallocate the ObjectRecord itself: */
	ADDListDeleteObject (Object);
}





/************** (VISIBLE)-OBJECT OUTPUT/ACTION ROUTINES ***************/
/* These routines perform vital miscellaneous and ergonomic functions */
/* such as object movement, window resizing, and "rubber-banding".    */
/* A text-to-window output routine is provided, as well as some       */
/* global object manipulation calls.  Some of these routines should   */
/* be called only on objects that are both visible and frontmost.     */
/**********************************************************************/





ADDBringObjectToFront (Object)

ADDObjectRecord	**Object;	/* Input: Object to bring to front */

/* This routine brings the given object to the front of the desktop,
   so that it can be manipulated by the routines below.  This routine
   should be called if the user selects an object, for example. */

{
	ADDObjectRecord	*CurrentTopmost;

	/* If this object is on top & visible already, error: */
	ADDListFindObjectTop (&CurrentTopmost);
	if ( (CurrentTopmost == *Object) || (*Object == NULL) )
		return (-1);

	/* Hide us, from somewhere underneath, then draw us on top: */
	ADDHideObject (Object);
	ADDShowObject (Object);
	return (0);
}





ADDMoveObject (Object,NewX1,NewY1)

ADDObjectRecord	**Object;	/* Input: Object to move to new location */
int		NewX1,NewY1;	/* Input: New origin coordinates         */

/* This routine moves the given object to a new location on the desktop,
   provided that the object is currently frontmost and visible and that
   the object will fit in its new location.
   USAGE: ADDMoveObject (&ObjectRecord,15,6) */

{
	ADDObjectRecord	*CurrentTopmost;	/* Are we on top? */
	int		nx2,ny2;		/* Potential X2Y2 */

	/* If this object is not on top and visible, return error: */
	ADDListFindObjectTop (&CurrentTopmost);
	if (CurrentTopmost != *Object)
		return (-1);

	/* Figure out what X2Y2 would be: */
	nx2 = (*Object)->X2  +  (NewX1 - (*Object)->X1);
	ny2 = (*Object)->Y2  +  (NewY1 - (*Object)->Y1);

	/* Is the caller asking for an impossible new location? */
	if ( (nx2 > ADDScreenSizeX) || 
	     (ny2 > ADDScreenSizeY) || 
	     ((nx2 == ADDScreenSizeX) && (ny2 == ADDScreenSizeY)) )
		return (-2);

	/* Go do the actual relocation: */
	ADDHideObject (Object);
	(*Object)->X1 = NewX1;
	(*Object)->Y1 = NewY1;
	(*Object)->X2 = nx2;
	(*Object)->Y2 = ny2;
	ADDShowObject (Object);
	return (0);
}





ADDCloseAllObjects ()

/* This routine simply closes every single object on the desktop.
   This routine should be used to start fresh without having to
   shut the ADD package down first, or, alternatively, before calling
   the shutdown routine if one desires to *watch* everything close. */

{
	ADDObjectRecord		*Chaser;

	Chaser = ADDObjectRecordListHead;
	while (Chaser != NULL)
	{
		ADDCloseObject (&Chaser);
		Chaser = ADDObjectRecordListHead;
	}
}





ADDWindowOutput (Object,String)

ADDObjectRecord	**Object;	/* Input: Window to clip output to */
char		*String;	/* Input: Output character string  */

/* This routine should be used for all text output to a window.  The given
   object should be a window that is currently topmost and visible.
   The given text string is clipped to within the X1Y1X2Y2 bounds given
   in the ObjectRecord, minus one character in all directions.  This is 
   done to preserve a window border.  The CXCY fields in the ObjectRecord
   are used and updated to maintain the current relative character positions
   within the window, and are expected to contain sane values upon entry.
   When the character position is at the bottom right limit and this routine 
   is called with a non-null string, the window contents are scrolled 
   up as necessary.  If the newline character ('\n') is encountered, then
   the following characters will be forced to the next line in the window.
   Nonprintable (control) characters are currently output as spaces.
   This routine also updates the object's TextContent field.
   USAGE: ADDWindowOutput (&ObjectRecordOfWindow,"TextTextText") */

{
	ADDObjectRecord	*CurrentTopmost;	/* Checking if we're top */
	char		c;			/* Temporary storage     */
	int		Index = 0;		/* Iterator thru string  */
	int		x,y;			/* For saving TextContnt */
	extern int	ADDPutChar ();		/* Defined elsewhere     */

	/* If this object is not topmost, visible, and a window, then error: */
	ADDListFindObjectTop (&CurrentTopmost);
	if ( (CurrentTopmost != *Object) || ((*Object)->Type != ADDTYPEWINDOW) )
		return (-1);

	/* Initially position the cursor at next available character: */
	tputs (tgoto (ADDTcapCursorMotion,
		(*Object)->X1 + (*Object)->CX + 1,
		(*Object)->Y1 + (*Object)->CY + 1
  		),1,ADDPutChar);
	
	/* Output characters to window until end of string: */
	while (String [Index] != '\0')
	{
		/* Do we have a newline in the string? */
		if (String [Index] == '\n')
		{
			Index++;
			goto newline;
		}

		/* We can't handle control characters here: */
		c = (iscntrl (String [Index])) ? ' ' : String [Index]; 

		/* Output to screen/buffer; increment CX and Index: */
		ADDPutChar (c);
		ADDScreenBuffer [(*Object)->X1 + ((*Object)->CX) + 1]
				[(*Object)->Y1 + ((*Object)->CY) + 1] = c;
		(*Object)->CX++;
		Index++;

		/* Do clipping and scrolling as necessary: */
		if ( ((*Object)->X1 + (*Object)->CX + 1) == (*Object)->X2 )
		{
			/* Go to new line; CX back to the left: */
			newline:
			(*Object)->CX = 0;
			if ( ((*Object)->Y1 + (++(*Object)->CY) + 1) == 
			      (*Object)->Y2 )
			{
				/* Scroll up a line, CY stays on same line: */
				(*Object)->CY--;
				ADDScreenScrollUp ( (*Object)->X1 + 1,
						    (*Object)->Y1 + 1,
						    (*Object)->X2 - 1,
						    (*Object)->Y2 - 1 );
			}
			/* Make sure terminal is on new line as well: */
			tputs (tgoto (ADDTcapCursorMotion,
				(*Object)->X1 + (*Object)->CX + 1,
				(*Object)->Y1 + (*Object)->CY + 1
  				),1,ADDPutChar);
		}
	}

	/* Update TextContent: */
	Index = 0;
	for (y = (*Object)->Y1 + 1;   y < (*Object)->Y2;   y++)
		for (x = (*Object)->X1 + 1;   x < (*Object)->X2;   x++)
			(*Object)->TextContent [Index++] = 
				ADDScreenBuffer [x][y];

	/* Output all: */
	ADDFlushChar ();
	return (0);
}





ADDWindowResize (Object,NewX2,NewY2)

ADDObjectRecord **Object;	/* Input: Window object to resize  */
int		NewX2,NewY2;	/* Input: New coordinates for X2Y2 */

/* This routine allows the resizing of a window, provided it is visible
   and frontmost, by the specification of new X2Y2 coordinates.  These
   coordinates must be right/below the current X1Y1 coordinates, and must
   not go off the desktop.  NOTE: The window contents, which are saved in
   the object's TextContent field will be redrawn in rasterscanned format
   but will look funny due to the new aspect ratio; if the new window's 
   area is smaller, then some of the contents will be lost.
   USAGE: ADDWindowResize (&ObjRecOfWindow_0_0_55_15_Coords,56,16) */

{ 
	ADDObjectRecord	*CurrentTopmost;		/* Are we on top?  */
	int		i;				/* For TextContent */

	/* If this object is not topmost, visible, and a window, then error: */
	ADDListFindObjectTop (&CurrentTopmost);
	if ( (CurrentTopmost != *Object) || ((*Object)->Type != ADDTYPEWINDOW) )
		return (-1);

	/* Is the caller asking for an impossible resizing? */
	if ( ((NewX2 - (*Object)->X1) < 8) || 
	     ((NewY2 - (*Object)->Y1) < 3) ||
	     (NewX2 > ADDScreenSizeX)      ||
	     (NewY2 > ADDScreenSizeY)      ||
	     ((NewX2 == ADDScreenSizeX) && (NewY2 == ADDScreenSizeY)) )
		return (-2);

	/* Clear the excess TextContent array to spaces: */
	for (i = ((*Object)->X2 - (*Object)->X1 - 1) *
		 ((*Object)->Y2 - (*Object)->Y1 - 1);   
		i < ADDScreenSizeX*ADDScreenSizeY;
		i++)
			(*Object)->TextContent [i] = ADDSPACE;

	/* Hide the window, and redraw it in its new size: */
	ADDHideObject (Object);
	(*Object)->X2 = NewX2;
	(*Object)->Y2 = NewY2;
	(*Object)->CX = 0;
	(*Object)->CY = (*Object)->Y2 - (*Object)->Y1 - 2;
	ADDShowObject (Object);
	return (0);
}



