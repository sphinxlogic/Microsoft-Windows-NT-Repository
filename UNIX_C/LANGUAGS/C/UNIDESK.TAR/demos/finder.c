/*
 * Finder -- UniDesk-based file loauncher application
 *
 * (C) 11/24/88 Ben Koning 408/738-1763
 *
 * cc -o Finder finder.c UniDesk.o -ltermcap
 *
 */



#include <sys/types.h>
#include <sys/timeb.h>
#include <time.h>





DoLook ()

/* Read file with default or selected program (cat, vi, more, etc.).  If
   more than one file selected, do dialog. */

{
}





DoExecute ()

/* Try to launch file as executable.  If more than one file selected,
   do dialog. */

{
}





DoEdit ()

/* Try to edit files using default or selected editor.  If more than
   one file selected, do dialog. */

{
}





DoDir ()

/* Change into new directory and refresh screen.  If more than one file
   selected, do dialog. */

{
}





DoCopy ()

/* Copy selected file.  If more than one file selected, do dialog. */

{
}





DoRename ()

/* Rename selected file.  If more than one file selected, do dialog. */

{
}





DoDelete ()

/* Remove selected files.  Do confirmation dialog. */

{
}





DoMode ()

/* Do chmod on selected files */

{
}





DoNewDir ()

/* Make new directory, and put selected files in it. */

{
}





DoOldDir ()

/* Move files in directory one level up, then delete directory. */

{
}





DoSetLook ()

/* Set standard look program (cat, more, view, etc.) */

{
}





DoSetEdit ()

/* Set standard edit program (ed, ex, vi, etc.) */

{
}





DoLogout ()

/* Log the user out. */

{
	ADDScreenClear ();
	sleep (4);
	system ("stty 0");
}





OurIdleProc ()

/* Called periodically; print time, etc. */

{
	struct tm	*TimeStructPtr;
	struct timeb	TimeBasePtr;
	char		Str [80];
	static int	last_time = -1;
	extern int	ADDScreenSizeX;

	ftime (&TimeBasePtr);
	TimeStructPtr = localtime (&(TimeBasePtr.time));
	if (TimeStructPtr->tm_min != last_time)
	{
		last_time = TimeStructPtr->tm_min;
		sprintf (Str,"Time: %2d:%02d",
			TimeStructPtr->tm_hour % 12,
			TimeStructPtr->tm_min);
		ADDScreenOutput (Str,ADDScreenSizeX-10,0);
	}
}





LaunchApplication ()

/* Does what's appropriate with the given application: run it,
   vi/more it, etc.  Sets up normal enviroment, then forks
   to run the application and waits for it to terminate. */

{
}





main ()

/* Set up globals, desktop, and install calls to our procedures. */

{
	SDIEasyReady ();

	SDIEasyOpenMenu (DoLook,"File","Look");
	SDIEasyOpenMenu (DoExecute,"File","Execute");
	SDIEasyOpenMenu (DoEdit,"File","Edit");
	SDIEasyOpenMenu (DoDir,"File","Change Directory");

	SDIEasyOpenMenu (DoCopy,"Manipulate","Copy");
	SDIEasyOpenMenu (DoRename,"Manipulate","Rename");
	SDIEasyOpenMenu (DoDelete,"Manipulate","Delete");
	SDIEasyOpenMenu (DoMode,"Manipulate","Change Mode");

	SDIEasyOpenMenu (DoNewDir,"Directory","Push files > New directory");
	SDIEasyOpenMenu (DoOldDir,"Directory","Pop files  < Old directory");

	SDIEasyOpenMenu (DoSetLook,"Special","Set Look Method");
	SDIEasyOpenMenu (DoSetEdit,"Special","Set Edit Method");
	SDIEasyOpenMenu (DoLogout,"Special","Logout");

	SDIEasyGo (OurIdleProc);
}


