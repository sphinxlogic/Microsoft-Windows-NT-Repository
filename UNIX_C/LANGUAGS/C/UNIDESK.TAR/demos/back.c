
#include "unidesk.h"

main (argc,argv)
int argc;
char **argv;
{
	ADDStartUp ();
	ADDDrawDesktop (argv[1]);
	ADDShutDown ();
}
