#include <time.h>

main ()
{
	time_t myt;
	myt =time();
}
