
#include <stdio.h>
#include <fcntl.h>
int sleeptime=120;
int defproc=1;
int groupid;
int listen[80]; /*array of fds to listen to*/
static char titles [10][80];
static char cmds [10][80];

wind (titlestr,cmdstr)
char *cmdstr,*titlestr;
{
	int pid;
	char title [80];
	int fds [2];
	char buff [1024];
	FILE *fp;
	int numread;

#define OUT 0
#define IN  1

	/* Open window */
	SDIEasyOpenWindow (defproc,titlestr);

	/* Make pipe for redirecting output */
	pipe (fds);
	close (1);
	dup (fds[IN]);

	/* fork off the process */
	pid=fork();
	if (!pid) 
		/* Child executes here */
		{
			setpgrp (0,groupid); /* So it will get signals */
			setbuf (stdout,0);
			for (;;) 
			{
				system (cmdstr);
				sleep (sleeptime);
			}
		}

	/* Return filedes for reading from above child: */
	listen [defproc] = fds[OUT];
	defproc++;
}


listener ()
{
int i,n;
char buff[1024];
int flags;

	for (i=1; i<defproc; i++)
	{
		flags = fcntl (listen[i],F_GETFL,0);
		fcntl (listen[i],F_SETFL,flags | FNDELAY);
		if ( (n=read (listen[i],buff,1024)) > 0 ) 
		{
			buff [n] = '\0';
			SDIEasyOutput (i,buff); 
		}
	}
}




main (argv,argc)
char **argv;
int argc;
{
	if (argc==2)
		sscanf ("%d",argv[1],&sleeptime);

	groupid = getpgrp (0);

	SDIEasyReady ();

	strcpy (titles[0],"Remote Uptime");
	strcpy (cmds[0],"ruptime");
	wind (titles[0],cmds[0]);

	strcpy (titles[1],"Who Is On");
	strcpy (cmds[1],"w");
	wind (titles[1],cmds[1]);

	strcpy (titles[2],"Fortune");
	strcpy (cmds[2],"fortune");
	wind (titles[2],cmds[2]);

	SDIEasyGo (listener);
}
