
/* This program demonstrates a minimum use of UniDesk         */
/* It is intentionally boring so you pay attention to UniDesk */
/* Ben Koning 3/88                                            */
/* cc democount.c UniDesk.o -ltermcap                         */


#define UNHAPPY_FACE_IMAGE "14,6,\
\t\t\t********\t\t\t\t*          *\t*    ^  ^    **    ____    *\t*  /\
    \\  *\t\t\t\t********\t\t\t"

#define HAPPY_FACE_IMAGE "14,6,\
\t\t\t********\t\t\t\t*          *\t*    ^  ^    **   \\____/   *\t*\
          *\t\t\t\t********\t\t\t"



float Count,Rate;					/* Globals */



junk1(){} junk2(){} junk3(){} junk4(){} junk5(){}	/* Problem */



docount ()					/* Concurrent procedure */
{
	Count += Rate;
}
showstraight ()					/* Menu item "Straight" */
{
	static char str [256];
	SDIEasyOpenWindow (junk2,"Showing Count Value");
	sprintf (str,"The current value of Count is:\n%f\n",Count);
	SDIEasyOutput (junk2,str);
}
showabsolute ()					/* Menu item "Absolute" */
{
	static char str [256];
	SDIEasyOpenWindow (junk3,"Absolute Count Value");
	sprintf (str,"The current value of |Count| is:\n%f\n",
		 (Count < 0.0) ? -1.0*Count : Count);
	SDIEasyOutput (junk3,str);
}
showsquared ()					/* Menu item "Squared" */
{
	static char str [256];
	SDIEasyOpenWindow (junk4,"Count Value Squared");
	sprintf (str,"The current value of Count^2 is:\n%f\n",Count*Count);
	SDIEasyOutput (junk4,str);
}
alterrate ()					/* Menu item "Rate" */
{
	static char str [256];
	SDIEasyOpenWindow (junk5,"Alter Count Rate");
	sprintf       (str,"Old count rate is %f.\n",Rate);
	SDIEasyOutput (junk5,str);
	SDIEasyOutput (junk5,"\nNew Rate: ");
	SDIEasyInput (junk5,str,8);
	sscanf (str,"%f",&Rate);
	SDIEasyCloseWindow (junk5);
}
altervalue ()					/* Menu item "Value" */
{
	static char str [256];
	SDIEasyOpenWindow (junk5,"Alter Count Value");
	sprintf       (str,"Old count value is %f.\n",Count);
	SDIEasyOutput (junk5,str);
	SDIEasyOutput (junk5,"\nNew Value: ");
	SDIEasyInput (junk5,str,8);
	sscanf (str,"%f",&Count);
	SDIEasyCloseWindow (junk5);
}
frownproc ()					/* Icon of frownieface */
{
	extern int smileproc ();
	SDIEasyCloseIcon (frownproc);
	SDIEasyOpenIcon (smileproc,"Please click on me!!",UNHAPPY_FACE_IMAGE);
}
smileproc ()					/* Icon of smilieface */
{
	SDIEasyCloseIcon (smileproc);
	SDIEasyOpenIcon (frownproc,"Don't click on me, Please!",
			 HAPPY_FACE_IMAGE);
}



main ()
{
	Count = 0;				/* Initialization */
	Rate  = 0.1;

	SDIEasyReady ();

	SDIEasyOpenMenu (showstraight,"Show Count","Straight");
	SDIEasyOpenMenu (showabsolute,"Show Count","Absolute");
	SDIEasyOpenMenu (showsquared, "Show Count","Squared");

	SDIEasyOpenMenu (alterrate, "Alter Count","Change Count Rate");
	SDIEasyOpenMenu (altervalue,"Alter Count","Change Counter Value");

	SDIEasyOpenWindow (junk1,"Counting Program");
	SDIEasyOutput (junk1,"\nThis program is very boring.\n");
	SDIEasyOutput (junk1,"It counts numbers up or down, and\n");
	SDIEasyOutput (junk1,"at different rates.  Note that the\n");
	SDIEasyOutput (junk1,"counting is done concurrently!\n");

	frownproc ();

	SDIEasyGo (docount);

	Count = 0;
	Rate  = 0;				/* Shutdown */
}
