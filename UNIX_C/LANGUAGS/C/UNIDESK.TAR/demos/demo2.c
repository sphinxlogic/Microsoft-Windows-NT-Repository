int i = 0;

wproc1 () {}
wproc2 () {}
wproc3 () {  char str [256]; sprintf (str,"Current Value of i = %d.\n",i);
 SDIEasyOutput (wproc3,str); }

menuproc1 () { SDIEasyOpenWindow (wproc1,"Window One"); }
menuproc2 () { SDIEasyOpenWindow (wproc2,"Window Two"); }
menuproc3 () { SDIEasyOpenWindow (wproc3,"Window Three -- Shows 'i'"); }


comp ()
{
i++;
}

main ()
{
	SDIEasyReady ();
	SDIEasyOpenMenu (menuproc1,"Windows","open window 1");
	SDIEasyOpenMenu (menuproc2,"Windows","open window 2");
	SDIEasyOpenMenu (menuproc3,"Windows","open window 3");
	SDIEasyGo (comp);

}
