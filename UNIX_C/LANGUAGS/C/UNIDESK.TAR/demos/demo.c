
main ()

{
	SDIEasyReady ();
	SDIEasyGo (0);
}
