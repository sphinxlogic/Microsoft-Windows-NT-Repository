/*******************************************************************
 *  Detab - converrts tabs to appropriate number of spaces
 *  (  transcribed from Kernighan & Plauger's Software tools.
 *******************************************************************
 */

#include	<stdio.h>
#define		MAXLINE 132

main()
{
	int	c, i, tabs[MAXLINE], col=1;

	set_tabs (tabs);
	while (( c = getchar()) != EOF )
		if ( c== '\t' )
			do {putchar (' '); col++;}
			while ( !tab_pos (col, tabs));
		else if ( c== '\n' )
			{putchar( '\n' ); col = 1;}
		else
			{putchar( c ); col++; }
}

/* set up tab positions */
set_tabs( tabs )
int	tabs[MAXLINE];
{
	int i;

	for ( i = 1; i <= MAXLINE; i++ )
		tabs[i] = (( i % 8) == 1 ? 1: 0);
}

/* see if we are at a tab position */
tab_pos( col, tabs )
int 	col, tabs[MAXLINE];
{
	return (( col > MAXLINE ) ? 1 : tabs[col] );
}
