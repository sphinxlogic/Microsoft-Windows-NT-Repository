		/************************/
		/* Analys style metrics */
		/************************/

#define		PARAMS 11

main()
{
	static int
		max[]	= {  9, 12, 12, 11,  8, 15,  6, 14, -20,  5,  8},

			/*  ch  cl  in  bl  sp  ml  rw  id   go  if  df  */
		
		L[]	= {  8,  8,  8,  8,  1,  4,  4,  4,   1,  0, 10 },
		S[]	= { 12, 15, 24, 15,  4, 10, 16,  5,   3,  3, 15 },
		F[]	= { 25, 25, 48, 30, 10, 25, 30, 10, 199,  3, 25 },
		H[]	= { 30, 35, 60, 35, 12, 35, 36, 14, 200,  4, 30};
	
	float param[PARAMS];

	static char
		*ident[] = { "  chars per line		",	/* ch */
			     "% comment lines		",	/* cl */
			     "% indentation		",	/* in */
			     "% blank lines		",	/* bl */
			     "  spaces per line		",	/* sp */
			     "  module length		",	/* ml */
			     "  reserved words		",	/* rw */
			     "  identifier length	", 	/* id */
			     "  goto's			",	/* go */
			     "  include files		",	/* if */
			     "% define's			" };	/* df */
	int i;

	float	blank, non_blank, comments, includes, defines,
		indented, embedded, modules, jumps, ids,
		name_length, score, old_score, fact, total_chars,
		word_count, line_count, total_lines, lines, f;
	char	s[8];

	/* Read in the metrics. */

	for ( i = 0; i < 16; i++ )
	{
		scanf ( "%s %f", s, &f );

		     if ( strcmp(s, "IF") == 0) includes = f;
		else if ( strcmp(s, "DF") == 0) defines = f;
		else if ( strcmp(s, "NR") == 0) lines = f;
		else if ( strcmp(s, "NL") == 0) name_length = f;
		else if ( strcmp(s, "ID") == 0) ids = f;
		else if ( strcmp(s, "RW") == 0) word_count = f;
		else if ( strcmp(s, "CL") == 0) comments = f;
		else if ( strcmp(s, "TL") == 0) total_lines = f;
		else if ( strcmp(s, "LC") == 0) line_count = f;
		else if ( strcmp(s, "NB") == 0) non_blank = f;
		else if ( strcmp(s, "IN") == 0) indented = f;
		else if ( strcmp(s, "TC") == 0) total_chars = f;
		else if ( strcmp(s, "BL") == 0) blank = f;
		else if ( strcmp(s, "IM") == 0) embedded = f;
		else if ( strcmp(s, "MO") == 0) modules = f;
		else if ( strcmp(s, "JU") == 0) jumps = f;
	}

	/*  Perform Analysis */

				line_count	 = lines - blank;
	if (line_count)		non_blank	/= line_count;
	if (total_lines)	comments	/= total_lines / 100;
	if (total_chars)	indented	/= total_chars / 100;
	if (lines)		blank		/= lines / 100;
	if (line_count)		embedded	/= line_count;
	if (modules)		modules	 	 = line_count / modules;
	if (ids)		defines		/= ids / 100;

	param[0]  = non_blank;
	param[1]  = comments;
	param[2]  = indented;
	param[3]  = blank;
	param[4]  = embedded;
	param[5]  = modules;
	param[6]  = word_count;
	param[7]  = name_length;
	param[8]  = jumps;
	param[9]  = includes;
	param[10] = defines;

	old_score = 0;

	for ( i = 0; i < PARAMS; i++ )
	{
		if( S[i] <= param[i] && param[i] <= F[i] )
			score += max[i];
		else if ( L[i] <= param[i] && param[i] < S[i] )
		{
			fact = (param[i] - L[i]) / (S[i] - L[i]);
			score += max[i] * fact;
		}
		else if ( F[i] < param[i] && param[i] <= H[i])
		{
			fact = ( H[i] - param[i] ) / ( H[i] - F[i] );
			score += max[i] * fact;
		}
		printf("\n%5.1f%s : %5.1f\t(max %3d)",
			param[i], ident[i], score-old_score, max[i]);
		old_score = score;
	}
	printf("\n\nScore %5.1f\n",score);
}
