/*
    Splay Tree Compression

    from: "Application Of Splay Trees To Data Compression"
          by Douglas W. Jones, Communications of the ACM, August 1988

    implemented in C by Bodo Rueskamp, <br@unido.uucp>
*/

/*  splay tree uncompress  */

#include <stdio.h>

int left[257], right[257], up[514];

int bit_input()
{
	static int bitnum = 0;
	static int byte;

	if (bitnum == 0) {
		if ((byte = getchar()) == -1) {
			fprintf(stderr, "unexpected end of input\n");
			exit(1);
		}
		bitnum = 8;
	}
	byte <<= 1;
	--bitnum;
	return((byte >> 8) & 1);
}

void initialize()
{
	int i;

	for (i=0; i<514; ++i)
		up[i] = i / 2;
	for (i=0; i<257; ++i) {
		left[i] = i * 2;
		right[i] = i * 2 + 1;
	}
}

void splay(plain)
int plain;
{
	int a, b, c, d;

	a = plain + 257;
	while (a) {  /*  walk up the tree semi-rotating pairs  */
		c = up[a];
		if (c) {  /*  a pair remains  */
			d = up[c];
			/*  exchange children of pair  */
			b = left[d];
			if (c == b) {
				b = right[d];
				right[d] = a;
			} else {
				left[d] = a;
			}
			if (a == left[c]) {
				left[c] = b;
			} else {
				right[c] = b;
			}
			up[a] = d;
			up[b] = c;
			a = d;
		} else {  /*  handle odd node at end  */
			a = c;
		}
	}
}

int uncompress()
{
	int a;

	a = 0;
	while (a < 257)
		a = bit_input() ? right[a] : left[a];
	a -= 257;
	splay(a);
	return(a);
}

main()
{
	int c;

	if ((getchar() != 0x1f) || (getchar() != 'S')) {
		fprintf(stderr, "stdin not in compressed format\n");
		exit(1);
	}
	initialize();
	while ((c = uncompress()) != 256)
		putchar(c);
	return(0);
}
