/*
    Splay Tree Compression

    from: "Application Of Splay Trees To Data Compression"
          by Douglas W. Jones, Communications of the ACM, August 1988

    implemented in C by Bodo Rueskamp, <br@unido.uucp>
*/

/*  splay tree compress  */

#include <stdio.h>

int left[257], right[257], up[514];

static int bitnum = 0;

void bit_output(bit)
int bit;
{
	static int byte = 0;

	byte = (byte << 1) | bit;
	++bitnum;
	if (bitnum == 8) {
		putchar(byte);
		byte = 0;
		bitnum = 0;
	}
}

void initialize()
{
	int i;

	for (i=0; i<514; ++i)
		up[i] = i / 2;
	for (i=0; i<257; ++i) {
		left[i] = i * 2;
		right[i] = i * 2 + 1;
	}
}

void splay(plain)
int plain;
{
	int a, b, c, d;

	a = plain + 257;
	while (a) {  /*  walk up the tree semi-rotating pairs  */
		c = up[a];
		if (c) {  /*  a pair remains  */
			d = up[c];
			/*  exchange children of pair  */
			b = left[d];
			if (c == b) {
				b = right[d];
				right[d] = a;
			} else {
				left[d] = a;
			}
			if (a == left[c]) {
				left[c] = b;
			} else {
				right[c] = b;
			}
			up[a] = d;
			up[b] = c;
			a = d;
		} else {  /*  handle odd node at end  */
			a = c;
		}
	}
}

void compress(plain)
int plain;
{
	int sp;
	char stack[514];
	int a;

	a = plain + 257;
	sp = 0;
	while (a) {
		stack[sp++] = a == right[up[a]];
		a = up[a];
	}
	while (sp--)
		bit_output(stack[sp]);
	splay(plain);
}

main()
{
	int c;

	putchar(0x1f);
	putchar('S');
	initialize();
	while ((c = getchar()) != -1)
		compress(c);
	compress(256);
	while (bitnum)
		bit_output(0);
	return(0);
}
