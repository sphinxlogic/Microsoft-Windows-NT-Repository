/*
 * (c) Copyright 1990 Conor P. Cahill (uunet!virtech!cpcahil).  
 * You may copy, distribute, and use this software as long as this
 * copyright statement is not removed.
 */
/*
 * $Id: tostring.h,v 1.2 90/05/11 00:13:11 cpcahil Exp $
 */
#define B_BIN	 2
#define B_DEC	10
#define B_HEX	16
#define B_OCTAL	 8

/* 
 * $Log:	tostring.h,v $
 * Revision 1.2  90/05/11  00:13:11  cpcahil
 * added copyright statment
 * 
 * Revision 1.1  90/02/23  07:09:05  cpcahil
 * Initial revision
 * 
 */
