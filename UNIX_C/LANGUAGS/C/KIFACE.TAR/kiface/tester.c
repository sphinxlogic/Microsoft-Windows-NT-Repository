/*
 * Copyright (C) 1988, Marcus J. Ranum, William Welch Medical Library
 * $Author: mjr $
 */

#ifndef lint
static char *RCSid="$Header: tester.c,v 1.2 88/06/10 22:46:12 mjr rel $: tester.c";
#endif

/*
 * $Log:	tester.c,v $
 * Revision 1.2  88/06/10  22:46:12  mjr
 * added example of function calling, buffer edit.
 * 
 * Revision 1.1  88/06/10  17:01:51  mjr
 * Initial revision
 * 
 */

#include <stdio.h>
#include <sys/ioctl.h>
#include "iface.h"

#define EDBUFSIZ	100

/* for the sake of example - a decent way to use this library */
/* obviously, you really should build a structure with pointers to */
/* functions and everything - then call the iface. exercise for the */
/* reader */
#define	TEST_DOTHIS	1
extern	void	dothis();
#define	TEST_DOTHAT	2
extern	void	dothat();
#define	TEST_DONADA	3
extern	void	donada();

main()
{
	char	instr[BUFSIZ];
	int	c;
	char	buf[BUFSIZ];
	char	edbuf[EDBUFSIZ];
	int	ret;
	struct	ifmap	keymap;
	struct	ifkey	*keyp;
	struct	sgttyb	ttybuf;
	extern	void	igets();
	extern	char	*strcpy();

	ifinitmap(&keymap);
	ifdfltmap(&keymap);

	/* for edit demo */
	(void)strcpy(edbuf,"Edit This !:");


	/* install dothis, dothat, donada - to "1", "2" and "3" */
	if(ifinstall(&keymap,"1",TEST_DOTHIS) != 0)
		(void)printf("error!\n");
	if(ifinstall(&keymap,"2",TEST_DOTHAT) != 0)
		(void)printf("error!\n");
	if(ifinstall(&keymap,"3",TEST_DONADA) != 0)
		(void)printf("error!\n");

	/* you have to handle putting the terminal is noecho cbreak */
	if(ioctl(0,TIOCGETP,(char *)&ttybuf) < 0)
		perror("ioctl - GETP");
	ttybuf.sg_flags |= CBREAK;
	ttybuf.sg_flags &= ~ECHO;
	if(ioctl(0,TIOCSETP,(char *)&ttybuf) <0)
		perror("ioctl - SETP");


	/* main demo loop */
	while (1) {
		(void)printf("\nEdit  Run  Install  Search  Delete  GetKey   Line   Quit:");
		if((c = getchar()) == NULL) {
			(void)printf("\n");
			exit(0);
		}

		switch (c) {

		/* quit */
		case 'q':
		case 'Q':
			ttybuf.sg_flags &= ~CBREAK;
			ttybuf.sg_flags |= ECHO;
			if(ioctl(0,TIOCSETP,(char *)&ttybuf) <0)
				perror("ioctl - SETP");
			(void)printf("\n");
			exit(0);
			

		/* edit a string */
		case 'e':
		case 'E':
			(void)printf("\n%s",edbuf);
			ret = ifgetstr(&keymap,edbuf,EDBUFSIZ,EDBUFSIZ);
			switch(ret) {
				case IF_UPWRMOVE:
					(void)printf("\n(up)got:\"%s\"\n",edbuf);
					break;

				case IF_DWNWMOVE:
					(void)printf("\n(down)got:\"%s\"\n",edbuf);
					break;

				case IF_CRETURN:
					(void)printf("\n(return)got:\"%s\"\n",edbuf);
					break;

				case IF_ABORTKEY:
					(void)printf("\n(abort)got:\"%s\"\n",edbuf);
					break;

				default:
					(void)printf("\n(err)got:\"%s\"\n",edbuf);
					break;
			}
			break;
			

		case 'r':
		case 'R':
			(void)printf("\ncommand ? (press 1, 2, or 3):");
			ret = ifgetkey(&keymap);
			switch(ret) {
				case TEST_DOTHIS:
						dothis();
						break;
				case TEST_DOTHAT:
						dothat();
						break;
				case TEST_DONADA:
						donada();
						break;
				case IF_NOTFOUND:
						(void)printf("\nI said, 1, 2, or 3\n");
						break;
				default:
						(void)printf("\nwhassat ?\n");
			}
			break;


		/* search for a mapping entry */
		case 's':
		case 'S':
			(void)printf("\nSearch for:");
			(void)igets(buf,&ttybuf);
			keyp = iflookup(&keymap,buf);
			if(keyp == NULL)
				(void)printf("\nnot found\n");
			else
				(void)printf("\nKval:%d\n",keyp->rhs);
			break;


		/* install a mapping entry */
		case 'i':
		case 'I':
			(void)printf("\nNumber:");
			(void)igets(buf,&ttybuf);
			ret = atoi(buf);
			(void)printf("Install string:");
			(void)igets(buf,&ttybuf);
			if(ifinstall(&keymap,buf,ret) != 0)
				(void)printf("error!\n");
			break;
			

		/* enter a line of junk */
		case 'L':
		case 'l':
			(void)printf("\nEnter Stuff:");
			ret = ifgetstr(&keymap,instr,BUFSIZ,0);
			if(ret != 0)
				(void)printf("\nabort..\n");
			else
				(void)printf("\ngot:\"%s\"\n",instr);
			break;
			
		/* get a key in "raw" mode */
		case 'g':
		case 'G':
			ifclearhold(keymap);
			(void)printf("\ngo:\n",ret);
			while((ret = ifgetkey(&keymap)) != IF_NOTFOUND)		
				(void)printf("\n%d",ret);
			(void)printf("\n(done)\n",ret);
			break;


		/* delete a map entry */
		case 'd':
		case 'D':
			(void)printf("\nDelete string:");
			(void)igets(buf,&ttybuf);
			if(ifdelete(&keymap,buf) != 0)
				(void)printf("error!\n");
			break;

		default:
			(void)printf("\nhuh?\n");
		}
	}
}

void
igets(buf,ttybuf)
char	buf[];
struct	sgttyb	*ttybuf;
{
	ttybuf->sg_flags &= ~CBREAK;
	ttybuf->sg_flags |= ECHO;
	if(ioctl(0,TIOCSETP,(char *)ttybuf) <0)
		perror("ioctl - SETP");
	(void)gets(buf);
	ttybuf->sg_flags |= CBREAK;
	ttybuf->sg_flags &= ~ECHO;
	if(ioctl(0,TIOCSETP,(char *)ttybuf) <0)
		perror("ioctl - SETP");
}

void
dothis()
{
	(void)printf("\ndothis called");
}

void
dothat()
{
	(void)printf("\ndothat called");
}

void
donada()
{
	(void)printf("\ndonada called");
}
