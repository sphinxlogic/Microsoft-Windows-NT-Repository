/*
 * Copyright (C) 1988, Marcus J. Ranum, William Welch Medical Library
 * $Author: mjr $
 */

/*
 * $Header: iface.h,v 1.3 88/06/11 15:58:53 mjr rel $: iface.h
 *
 * $Log:	iface.h,v $
 * Revision 1.3  88/06/11  15:58:53  mjr
 * added possibly useful macros. moved input buffer into map structure
 * 
 * Revision 1.2  88/06/10  22:45:43  mjr
 * improved readability of some comments.
 * 
 * Revision 1.1  88/06/10  17:02:00  mjr
 * Initial revision
 * 
 */

#ifndef _INCL_IFACE_H

/* size to hash key mappings into - a key mapping is stored in lexical */
/* order, hashed based on the first character (hell of a hash, eh ?) */
/* this really does not have to be a very big number */
#define	IF_HSIZE	10

/* size of input buffer */
#define IF_INBUFSIZ	300

/* a key mapping element */
struct	ifkey	{
	char	*lhs;
	int	rhs;
	struct	ifkey	*next;
};

/* a command/key map */
struct	ifmap	{
	struct	ifkey	*htab[IF_HSIZE];	/* key mapping entries */
	int	hold;				/* holdover key */
						/* usually the key that */
						/* caused an error, or 0 */
	int	lastret;			/* last recognized key */
						/* reset during getkey() */
						/* each time called */
	int	lastbuf;			/* usable in ifgetstr() */
						/* - last position of curs */
						/* use at own risk */
	char	inbuf[IF_INBUFSIZ];		/* input buffer - whatever */
						/* we currently have read */
						/* cleared in each call to */
						/* ifgetkey - may be long */
};

/* can be used to flush a pending character */
#define	ifclearhold(map)	((map).hold = '\0')
#define	iflastch(map)		((map).hold)
#define	iflastret(map)		((map).lastret)

/* these are expected to be builtins - if you intend to use ifgetstr */
/* these must be defined, at a minimum. (more can be). - to set up a */
/* more or less "standard" set, you can use ifdfltmap() - which uses */
/* some reasonable assumptions from termcap */
#define	IF_NOTFOUND	-1	/* this one does not need to be bound ! */
				/* since it is what we return when we are */
				/* unable to find something interesting */
#define	IF_DELCHAR	-2	/* we want to delete a character */
#define	IF_BACKMOVE	-3	/* go backwards a char (nondestructive) */
#define	IF_FORWMOVE	-4	/* go forward a char (nondestructive) */
#define	IF_UPWRMOVE	-5	/* go up a char - sometimes can mean EOL */
#define	IF_DWNWMOVE	-6	/* go down a char - sometimes can mean EOL */
#define	IF_CRETURN	-7	/* return from input normally */
#define	IF_ABORTKEY	-8	/* return from input with cancel */


extern	void	ifinitmap();
extern	void	ifdfltmap();
extern	void	iffreemap();
extern	struct	ifkey	*iflookup();

#define _INCL_IFACE_H
#endif
