/*
 * Copyright (C) 1988, Marcus J. Ranum, William Welch Medical Library
 * $Author: mjr $
 */

#ifndef lint
static char *RCSid="$Header: iface.c,v 1.3 88/06/11 15:58:32 mjr rel $: iface.c";
#endif

/*
 * $Log:	iface.c,v $
 * Revision 1.3  88/06/11  15:58:32  mjr
 * added better initializations to ifinitmap
 * 
 * Revision 1.2  88/06/10  22:45:14  mjr
 * added option to edit a buffer from an arbitrary point in the buffer.
 * 
 * Revision 1.1  88/06/10  17:01:40  mjr
 * Initial revision
 * 
 */

#include	<stdio.h>
#include	"iface.h"



/* free a key map table - this zaps all mappings totally */
void
iffreemap(kmap)
struct	ifmap	*kmap;
{
	int	x;
	struct	ifkey	*kp;
	struct	ifkey	*xp;
	
	for(x = 0; x < IF_HSIZE; x++) {
		kp = kmap->htab[x]; 
		while(kp != NULL) {
			xp = kp->next;
			(void)free(kp->lhs);
			(void)free((char *)kp);
			kp = xp;
		}
		kmap->htab[x] = NULL;
	}
}



/* clear a key map table - this prepares the table for adding mappings */
void
ifinitmap(kmap)
struct	ifmap	*kmap;
{
	int	x;
	
	/* all we do here is set the hash entries to NULL */
	/* THIS IS NOT THE SAME AS FREEING ALL THE MAP ENTRIES */
	/* call this when a map table is first created, call iffreemap() */
	/* if you want to deallocate a mapping table */
	for(x = 0; x < IF_HSIZE; x++)
		kmap->htab[x] = NULL;

	/* set these, too */
	kmap->hold = '\0';
	kmap->lastret = -1;
	kmap->lastbuf = 0;
	kmap->inbuf[0] = '\0';
}


/* install a default key map table - or most of one */
void
ifdfltmap(kmap)
struct	ifmap	*kmap;
{
	char	tbuf[1024];
	char	fill[1024];
	char	*fptr = fill;
	char	*forch;
	char	*uprch;
	char	*bwrch;
	char	*dnrch;
	char	*crch;
	static	char	hbuf[2];
	static	char	*dforch = "\33[C";
	static	char	*duprch = "\33[A";
	static	char	*dbwrch = "\33[D";
	static	char	*ddnrch = "\33[B";
	static	char	*dcrch = "\n";
	extern	char	*getenv();
	extern	char	*tgetstr();

	if(((forch = getenv("TERM")) != NULL) && (tgetent(tbuf,forch) == 1)) {
		if((forch = tgetstr("kr",&fptr)) == 0)
			forch = dforch;
		if((uprch = tgetstr("ku",&fptr)) == 0)
			uprch = duprch;
		if((bwrch = tgetstr("kl",&fptr)) == 0)
			bwrch = dbwrch;
		if((dnrch = tgetstr("kd",&fptr)) == 0)
			dnrch = ddnrch;
		if((crch = tgetstr("cr",&fptr)) == 0)
			crch = dcrch;
	} else {
		/* could get terminal entry - use whatever */
		forch = dforch;
		uprch = duprch;
		bwrch = dbwrch;
		dnrch = ddnrch;
		crch = dcrch;
	}

	/* install the foogers */
	hbuf[0] = 127;
	hbuf[1] = '\0';
	(void)ifinstall(kmap,hbuf,IF_DELCHAR);
	(void)ifinstall(kmap,"\b",IF_DELCHAR);
	(void)ifinstall(kmap,bwrch,IF_BACKMOVE);
	(void)ifinstall(kmap,forch,IF_FORWMOVE);
	(void)ifinstall(kmap,uprch,IF_UPWRMOVE);
	(void)ifinstall(kmap,dnrch,IF_DWNWMOVE);
	(void)ifinstall(kmap,crch,IF_CRETURN);
	return;
}



/* look the bad boy up */
struct	ifkey	*
iflookup(kmap,s)
struct	ifmap	*kmap;
char	*s;
{
	struct	ifkey	*kp;
	for(kp = kmap->htab[*s % IF_HSIZE]; kp != NULL; kp = kp->next)
		if(strcmp(s,kp->lhs) == 0)
			return(kp);
	return(NULL);
}
	


/* install a key mapping, hashed, and in lexical order */
ifinstall(kmap,lh,rh)
struct	ifmap	*kmap;
char	*lh;
int	rh;
{
	struct	ifkey	*kp;
	struct	ifkey	*after;
	extern	char	*malloc();
	extern	char	*strcpy();
	
	/* not found - install anew */
	if((kp = iflookup(kmap,lh)) == NULL) {

		/* figure out where to put it */
		kp = kmap->htab[*lh % IF_HSIZE];
		after = NULL;
		while(kp != NULL) {
			if(strcmp(lh,kp->lhs) < 0)
				break;
			after = kp;
			kp = kp->next;
		}

/* avoid the possible pointer alignment problem message */
#ifndef lint
		/* allocate it */
		kp = (struct ifkey *)malloc(sizeof(struct ifkey));
#else
		kp = NULL;
#endif
		if(kp == NULL)
			return(-1);
		kp->lhs = malloc((unsigned)strlen(lh));
		if(kp->lhs == NULL)
			return(-1);
		kp->rhs = rh;
		(void)strcpy(kp->lhs,lh);

		/* fixup sibling pointers */
		if(after != NULL) {
				kp->next = after->next;
				after->next = kp;
		} else {
			if(kmap->htab[*lh % IF_HSIZE] != NULL) {
				kp->next = kmap->htab[*lh % IF_HSIZE];
				kmap->htab[*lh % IF_HSIZE] = kp;
			} else {
				kmap->htab[*lh % IF_HSIZE] = kp;
				kp->next = NULL;
			}
		}
	} else {
		/* just change the return value */
		kp->rhs = rh;
	}

	return(0);
}
	


/* de-install a key mapping (by key string) */
ifdelete(kmap,s)
struct	ifmap	*kmap;
char	*s;
{
	struct	ifkey	*kp;
	struct	ifkey	*lptr = NULL;
	extern	char	*strcpy();
	
	for(kp = kmap->htab[*s % IF_HSIZE]; kp != NULL; kp = kp->next) {
		if(strcmp(s,kp->lhs) == 0) {
			if(lptr != NULL) {
				/* last node next points to the next one */
				lptr->next = kp->next;
			} else {
				/* root node next points to the next one */
				kmap->htab[*s % IF_HSIZE] = kp->next;
			}
			(void)free(kp->lhs);
			(void)free((char *)kp);
			return(0);
		}
		lptr = kp;
	}
	return(-1);
}



ifgetkey(kmap)
struct	ifmap	*kmap;
{
	int	c =0;
	int	nfound;	
	int	nclose;	
	char	*i;
	char	*o;
	int	cnt =0;
	int	xcnt;
	struct	ifkey	*kp;		/* current key pointer */
	struct	ifkey	*bp = NULL;	/* bottom closest match pointer */
	struct	ifkey	*ret = NULL;	/* our match */


	while(1) {
		if((c = getchar()) == EOF) {
			kmap->lastret = IF_NOTFOUND;
			kmap->hold = c;
			return(IF_NOTFOUND);
		}

		/* should happen once and only once per call */
		/* we set the bottom pointer to point to just before */
		/* the first char of our input stream */
		if(bp == NULL) {
			bp = kmap->htab[c % IF_HSIZE]; 

			/* nothing in this hash chain to find */
			if(bp == NULL) {
				kmap->lastret = IF_NOTFOUND;
				kmap->hold = c;
				return(IF_NOTFOUND);
			}
			
			/* otherwise skate or die */
			while(bp->next != NULL && c > *bp->lhs)
				bp = bp->next;
		}


		nfound = 0;
		nclose = 0;
		kp = bp;

		if(cnt + 1 > IF_INBUFSIZ)
			return(-1);

		kmap->inbuf[cnt++] = c;
		kmap->inbuf[cnt] = '\0';

		while(kp != NULL) {

			xcnt = 0;
			o = kp->lhs;
			i = kmap->inbuf;

			if(*o != *i)
				break;

			/* a mix of strcmp and strncmp */
			for(; *o == *i; o++, i++, xcnt++) {
				if(*o == '\0') {
					nfound++;
					ret = kp;
					break;
				}
			}
			if(xcnt == cnt)
				nclose++;
			kp = kp->next;
		}

		/* didn't find any !! - unmapped key */
		if(nfound == 0 && nclose == 0) {
			kmap->hold = c;
			kmap->lastret = IF_NOTFOUND;
			return(IF_NOTFOUND);
		}

		/* only found one - great! */
		if(nfound) {
			kmap->hold = '\0';
			kmap->lastret = ret->rhs;
			return(ret->rhs);
		}
	}
}



ifgetstr(kmap,buf,max,bpos)
struct	ifmap	*kmap;
char	buf[];
int	max;
int	bpos;
{
	int	c =0;		/* input returned char */
	int	high =0;	/* line high water mark */
	int	cnt =0;		/* current position/count */

	high = strlen(buf);
	if(bpos > high)
		cnt = high;
	else
		cnt = bpos;

	while(1) {

		/* get a key from the map */
		switch(c = ifgetkey(kmap)) {

				/* delete a character */
			case IF_DELCHAR:
				/* if at current high water mark */

				/* if at beginning of line */
				if(cnt - 1 < 0) {
					(void)fputc(07,stderr);
				} else {
					if(cnt == high) {
						high = --cnt;
						buf[cnt] = 0;
					} else {
						buf[--cnt] = ' ';
					}
					(void)fprintf(stderr,"\b \b");
				}
				break;


				/* NON-DESTRUCTIVE backwards move */
			case IF_BACKMOVE:
				if(cnt - 1 < 0) {
					(void)fputc(07,stderr);
				} else {
					cnt--;
					(void)fprintf(stderr,"\b");
				}
				break;


				/* NON-DESTRUCTIVE forward move */
			case IF_FORWMOVE:
				if(cnt + 1 > max) {
					(void)fputc(07,stderr);
				} else {
					if(high == cnt) {
						buf[cnt] = ' ';
						high = ++cnt;
					} else {
						++cnt;
					}
					(void)fputc(buf[cnt - 1],stderr);
				}
				break;


				/* FINISHED */
			case IF_CRETURN:
				buf[high] = '\0';
				kmap->lastbuf = cnt;
				return(IF_CRETURN);


				/* DOWN */
			case IF_DWNWMOVE:
				buf[high] = '\0';
				kmap->lastbuf = cnt;
				return(IF_DWNWMOVE);


				/* UP */
			case IF_UPWRMOVE:
				buf[high] = '\0';
				kmap->lastbuf = cnt;
				return(IF_UPWRMOVE);


				/* abort */
			case IF_ABORTKEY:
				buf[0] = '\0';
				kmap->lastbuf = cnt;
				return(IF_ABORTKEY);


				/* must be a character insert */
			case IF_NOTFOUND:
				c = kmap->hold;
				kmap->hold = '\0';
				if(cnt + 1 > max) {
					(void)fputc(07,stderr);
					buf[cnt] = '\0';
				} else {
					buf[cnt] = c;
					(void)fputc(c,stderr);
					if(high == cnt)
						high = ++cnt;
					else
						++cnt;
				}
				break;
		}
	}
}
