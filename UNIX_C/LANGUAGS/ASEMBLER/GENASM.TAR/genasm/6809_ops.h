#define BYTESPERLINE 5  /* # bytes per line on the listing */

#define SIGNED YES
#define SWAPPED YES
#define RELATIVE YES

opdclass o_reg   = { 1, NO    , NO     , NO      , 0};
opdclass o_smem  = { 8, NO    , NO     , NO      , 0};
opdclass o_rmem  = { 8, SIGNED, NO     , RELATIVE, -2};
opdclass o_mem   = {16, NO    , NO     , NO      , 0};
opdclass o_off   = { 8, SIGNED, NO     , NO      , 0};
opdclass o_data  = { 8, SIGNED, NO     , NO      , 0};
opdclass o_data2 = {16, SIGNED, NO     , NO      , 0};
opdclass o_cond  = { 4, NO    , NO     , NO      , 0};
opdclass o_rsp   = { 4, NO    , NO     , NO      , 0};

insclass i_reg   = {1, 1, &o_reg , &o_none, -4, 0};
insclass i_regp  = {1, 1, &o_reg , &o_none,  0, 0};
insclass i_rr    = {2, 2, &o_rsp , &o_rsp ,  4, 8};
insclass i_rimed = {2, 2, &o_reg , &o_data, -6, 8};
insclass i_rimd2 = {3, 2, &o_reg , &o_data2,-6, 16};
insclass i_rdir  = {2, 2, &o_reg , &o_smem, -6, 8};
insclass i_rx0   = {2, 2, &o_reg , &o_off , -6, 8};
insclass i_rx5   = {2, 2, &o_reg , &o_off , -6, 8};
insclass i_rx8   = {2, 2, &o_reg , &o_off , -6, 16};
insclass i_rx16  = {2, 2, &o_reg , &o_off , -6, 24};
insclass i_rxtd  = {3, 2, &o_reg , &o_mem , -6, 16};
insclass i_imed  = {2, 1, &o_data, &o_none,  8, 0};
insclass i_imd2  = {3, 1, &o_data2,&o_none, 16, 0};
insclass i_dir   = {2, 1, &o_smem, &o_none,  8, 0};
insclass i_x0    = {2, 1, &o_off , &o_none,  8, 0};
insclass i_x5    = {2, 1, &o_off , &o_none,  8, 0};
insclass i_x8    = {2, 1, &o_off , &o_none, 16, 0};
insclass i_x16   = {2, 1, &o_off , &o_none, 24, 0};
insclass i_xtd   = {3, 1, &o_mem , &o_none, 16, 0};
insclass i_imd22 = {4, 1, &o_data2,&o_none, 24, 0};
insclass i_dir2  = {3, 1, &o_smem, &o_none, 16, 0};
insclass i_x02   = {3, 1, &o_off , &o_none, 16, 0};
insclass i_x52   = {3, 1, &o_off , &o_none, 16, 0};
insclass i_x82   = {3, 1, &o_off , &o_none, 24, 0};
insclass i_x162  = {3, 1, &o_off , &o_none, 32, 0};
insclass i_xtd2  = {4, 1, &o_mem , &o_none, 24, 0};
insclass i_rel   = {2, 1, &o_rmem, &o_none,  8, 0};
insclass i_cond  = {2, 2, &o_cond, &o_rmem,  0, 8};
insclass i_nopd2 = {2, 0, &o_none, &o_none,  0, 0};

beginpattern c_cx
choicedef c_~1   = {"~1s" , "~1z"  , ~2, 0, 0xff, NO};
choicedef c_~1x  = {"~1x0", "~1xa" , ~2, 0, 0x00, NO};
choicedef c_~1xa = {"~1x5", "~1xb" , ~2, 0, 0x1f, NO};
choicedef c_~1xb = {"~1x8", "~1x16", ~2, 0, 0xff, NO};
endpattern

pattern c_cx,adc,2
pattern c_cx,add,2
pattern c_cx,and,2
pattern c_cx,bit,2
pattern c_cx,cma,2
pattern c_cx,eor,2
pattern c_cx,lda,2
pattern c_cx,ldr,2
pattern c_cx,ora,2
pattern c_cx,sbc,2
pattern c_cx,sub,2
pattern c_cx,addd,1
pattern c_cx,ldd,1
pattern c_cx,std,1
pattern c_cx,sta,1
pattern c_cx,str,1
pattern c_cx,subd,1
pattern c_cx,jsr,1
pattern c_cx,cpx,1
pattern c_cx,asl,1
pattern c_cx,asr,1
pattern c_cx,clr,1
pattern c_cx,com,1
pattern c_cx,dec,1
pattern c_cx,inc,1
pattern c_cx,lsl,1
pattern c_cx,lsr,1
pattern c_cx,neg,1
pattern c_cx,rol,1
pattern c_cx,ror,1
pattern c_cx,tst,1
pattern c_cx,jmp,1
pattern c_cx,cmpd,1
pattern c_cx,cmpy,1
pattern c_cx,ldy,1
pattern c_cx,sty,1
pattern c_cx,lds,1
pattern c_cx,sts,1
pattern c_cx,cmpu,1
pattern c_cx,cmps,1

beginpattern x_mem
	"~1m"  , (insclass *)&c_~1,   0, choiceinstr,
	"~1"   , (insclass *)&c_~1x,  0, choiceinstr,
	"~1xa" , (insclass *)&c_~1xa, 0, choiceinstr,
	"~1xb" , (insclass *)&c_~1xb, 0, choiceinstr,
	"~1i"  , &i_rimed, 0x~2000000|0x80000000, geninstr,
	"~1s"  , &i_rdir , 0x~2000000|0x90000000, geninstr,
	"~1x0" , &i_rx0  , 0x~2000000|0xa0840000, geninstr,
	"~1x5" , &i_rx5  , 0x~2000000|0xa0000000, geninstr,
	"~1x8" , &i_rx8  , 0x~2000000|0xa0880000, geninstr,
	"~1x16", &i_rx16 , 0x~2000000|0xa0890000, geninstr,
	"~1z"  , &i_rxtd , 0x~2000000|0xb0000000, geninstr,
endpattern

beginpattern x_xreg
	"~1m"  , (insclass *)&c_~1,   0, choiceinstr,
	"~1"   , (insclass *)&c_~1x,  0, choiceinstr,
	"~1xa" , (insclass *)&c_~1xa, 0, choiceinstr,
	"~1xb" , (insclass *)&c_~1xb, 0, choiceinstr,
	"~1i"  , &i_rimd2, 0x~2000000|0x80000000, geninstr,
	"~1s"  , &i_rdir , 0x~2000000|0x90000000, geninstr,
	"~1x0" , &i_rx0  , 0x~2000000|0xa0840000, geninstr,
	"~1x5" , &i_rx5  , 0x~2000000|0xa0000000, geninstr,
	"~1x8" , &i_rx8  , 0x~2000000|0xa0880000, geninstr,
	"~1x16", &i_rx16 , 0x~2000000|0xa0890000, geninstr,
	"~1z"  , &i_rxtd , 0x~2000000|0xb0000000, geninstr,
endpattern

beginpattern x_dou
	"~1m"  , (insclass *)&c_~1  , 0, choiceinstr,
	"~1"   , (insclass *)&c_~1x , 0, choiceinstr,
	"~1xa" , (insclass *)&c_~1xa, 0, choiceinstr,
	"~1xb" , (insclass *)&c_~1xb, 0, choiceinstr,
	"~1i"  , &i_imd2 , 0x~2000000|0x80000000, geninstr,
	"~1s"  , &i_dir  , 0x~2000000|0x90000000, geninstr,
	"~1x0" , &i_x0   , 0x~2000000|0xa0840000, geninstr,
	"~1x5" , &i_x5   , 0x~2000000|0xa0000000, geninstr,
	"~1x8" , &i_x8   , 0x~2000000|0xa0880000, geninstr,
	"~1x16", &i_x16  , 0x~2000000|0xa0890000, geninstr,
	"~1z"  , &i_xtd  , 0x~2000000|0xb0000000, geninstr,
endpattern

beginpattern x_reg
	"~1m"  , (insclass *)&c_~1  , 0, choiceinstr,
	"~1"   , (insclass *)&c_~1x , 0, choiceinstr,
	"~1xa" , (insclass *)&c_~1xa, 0, choiceinstr,
	"~1xb" , (insclass *)&c_~1xb, 0, choiceinstr,
	"~1s"  , &i_dir  , 0x~2000000|0x00000000, geninstr,
	"~1a"  , &i_reg  , 0x~2000000|0x40000000, geninstr,
	"~1x0" , &i_x0   , 0x~2000000|0x60840000, geninstr,
	"~1x5" , &i_x5   , 0x~2000000|0x60000000, geninstr,
	"~1x8" , &i_x8   , 0x~2000000|0x60880000, geninstr,
	"~1x16", &i_x16  , 0x~2000000|0x60890000, geninstr,
	"~1z"  , &i_xtd  , 0x~2000000|0x70000000, geninstr,
endpattern

beginpattern x_reg2
	"~1m"  , (insclass *)&c_~1  , 0, choiceinstr,
	"~1"   , (insclass *)&c_~1x , 0, choiceinstr,
	"~1xa" , (insclass *)&c_~1xa, 0, choiceinstr,
	"~1xb" , (insclass *)&c_~1xb, 0, choiceinstr,
	"~1i"   , &i_imd22, 0x~20000|0x10800000, geninstr,
	"~1s"   , &i_dir2 , 0x~20000|0x10900000, geninstr,
	"~1x0"  , &i_x02  , 0x~20000|0x10a08400, geninstr,
	"~1x5"  , &i_x52  , 0x~20000|0x10a00000, geninstr,
	"~1x8"  , &i_x82  , 0x~20000|0x10a08800, geninstr,
	"~1x16" , &i_x162 , 0x~20000|0x10a08900, geninstr,
	"~1z"   , &i_xtd2 , 0x~20000|0x10b00000, geninstr,
endpattern

opdef optab[] = {
	"abx"    , &i_noopd, 0x3a000000, geninstr,
pattern x_mem,adc,9
pattern x_mem,add,b
pattern x_dou,addd,43
pattern x_mem,and,4
	"andcc"  , &i_imed , 0x1c000000, geninstr,
pattern x_reg,asl,8
pattern x_reg,asr,7
	"bc"     , &i_cond , 0x20000000, geninstr,
pattern x_mem,bit,5
	"bra"    , &i_rel  , 0x20000000, geninstr,
	"bsr"    , &i_rel  , 0x8d000000, geninstr,
pattern x_reg,clr,f
pattern x_mem,cma,1
pattern x_reg2,cmpd,3
pattern x_reg2,cmps,10c
pattern x_reg2,cmpu,103
pattern x_reg2,cmpy,c
pattern x_reg,com,3
pattern x_dou,cpx,c
	"cwai"   , &i_noopd, 0x3c000000, geninstr,
	"daa"    , &i_noopd, 0x19000000, geninstr,
pattern x_reg,dec,a
pattern x_mem,eor,8
	"exg"    , &i_rr   , 0x1e000000, geninstr,
pattern x_reg,inc,c
pattern x_reg,jmp,e
pattern x_dou,jsr,d
	"lbra"   , &i_xtd  , 0x16000000, geninstr,
	"lbsr"   , &i_xtd  , 0x17000000, geninstr,
pattern x_mem,lda,6
pattern x_dou,ldd,4c
pattern x_xreg,ldr,e
pattern x_reg2,lds,43
pattern x_reg2,ldy,e
	"leax"   , &i_xtd  , 0x30000000, geninstr,
	"leay"   , &i_xtd  , 0x31000000, geninstr,
	"leas"   , &i_xtd  , 0x32000000, geninstr,
	"leau"   , &i_xtd  , 0x33000000, geninstr,
pattern x_reg,lsl,8
pattern x_reg,lsr,4
	"mul"    , &i_noopd, 0x3d000000, geninstr,
pattern x_reg,neg,0
	"nop"    , &i_noopd, 0x12000000, geninstr,
pattern x_mem,ora,a
	"orcc"   , &i_imed , 0x1a000000, geninstr,
	"pshs"   , &i_noopd, 0x34000000, geninstr,
	"pshu"   , &i_noopd, 0x36000000, geninstr,
	"puls"   , &i_noopd, 0x35000000, geninstr,
	"pulu"   , &i_noopd, 0x37000000, geninstr,
pattern x_reg,rol,9
pattern x_reg,ror,6
	"rti"    , &i_noopd, 0x3b000000, geninstr,
	"rts"    , &i_noopd, 0x39000000, geninstr,
pattern x_mem,sbc,2
	"sei"    , &i_noopd, 0x0f000000, geninstr,
	"sex"    , &i_rr   , 0x1d000000, geninstr,
pattern x_mem,sta,7
pattern x_dou,std,4d
pattern x_xreg,str,f
pattern x_reg2,sts,4f
pattern x_reg2,sty,f
pattern x_mem,sub,0
pattern x_dou,subd,3
	"swi"    , &i_noopd, 0x3f000000, geninstr,
	"swi2"   , &i_nopd2, 0x10000000, geninstr,
	"swi3"   , &i_nopd2, 0x11000000, geninstr,
	"sync"   , &i_noopd, 0x13000000, geninstr,
	"tfr"    , &i_rr   , 0x1f000000, geninstr,
pattern x_reg,tst,d
	""       , &i_noopd, 0L, geninstr
};

symbol predef[] = {
	{"ra" , 0x0, &o_reg , (segmnt *)0 },
	{"rb" , 0x1, &o_reg , (segmnt *)0 },
	{"rx" , 0x1, &o_reg , (segmnt *)0 },
	{"sp" , 0x0, &o_reg , (segmnt *)0 },
	{"nz" , 0x6, &o_cond, (segmnt *)0 },
	{"z"  , 0x7, &o_cond, (segmnt *)0 },
	{"ne" , 0x6, &o_cond, (segmnt *)0 },
	{"eq" , 0x7, &o_cond, (segmnt *)0 },
	{"nc" , 0x4, &o_cond, (segmnt *)0 },
	{"c"  , 0x5, &o_cond, (segmnt *)0 },
	{"gez", 0xc, &o_cond, (segmnt *)0 },
	{"gz" , 0xe, &o_cond, (segmnt *)0 },
	{"gt" , 0x2, &o_cond, (segmnt *)0 },
	{"lez", 0xf, &o_cond, (segmnt *)0 },
	{"le" , 0x3, &o_cond, (segmnt *)0 },
	{"lz" , 0xd, &o_cond, (segmnt *)0 },
	{"m"  , 0xb, &o_cond, (segmnt *)0 },
	{"ov" , 0x9, &o_cond, (segmnt *)0 },
	{"nov", 0x8, &o_cond, (segmnt *)0 },
	{"p"  , 0xa, &o_cond, (segmnt *)0 },
	{"ge" , 0x4, &o_cond, (segmnt *)0 },
	{"lt" , 0x5, &o_cond, (segmnt *)0 },
	{"D"  , 0x0, &o_rsp , (segmnt *)0 },
	{"X"  , 0x1, &o_rsp , (segmnt *)0 },
	{"Y"  , 0x2, &o_rsp , (segmnt *)0 },
	{"U"  , 0x3, &o_rsp , (segmnt *)0 },
	{"S"  , 0x4, &o_rsp , (segmnt *)0 },
	{"PC" , 0x5, &o_rsp , (segmnt *)0 },
	{"A"  , 0x8, &o_rsp , (segmnt *)0 },
	{"B"  , 0x9, &o_rsp , (segmnt *)0 },
	{"CC" , 0xa, &o_rsp , (segmnt *)0 },
	{"DPR", 0xb, &o_rsp , (segmnt *)0 },
	{""   , 0x0, &o_none, (segmnt *)0 },
};

/* Partial decoding of the indexing occurs here. Differences in coding due
 * to size of offset constants is ored in through extended opcode masks.
 */

#define has(x) index(str,'x')

void optional (str, obuf)
	char *str;
	Word *obuf;
{
	static struct {
		unsigned char value;
		char *str;
	} *xpt, stuff[] = {
		0x8c, "P"     , 0x9c, "*P"    , 0x9f, "*"     ,
		0x80, "+X"    , 0x81, "#X"    , 0x82, "-X"    ,
		0x83, "=X"    , 0x84, "X"     , 0x85, "BX"    ,
		0x86, "AX"    , 0x8b, "DX"    , 0x91, "#*X"   ,
		0x93, "*=X"   , 0x94, "*X"    , 0x95, "*BX"   ,
		0x96, "*AX"   , 0x9b, "*DX"   ,
		0xa0, "+Y"    , 0xa1, "#Y"    , 0xa2, "-Y"    ,
		0xa3, "*=Y"   , 0xa3, "=Y"    , 0xa4, "Y"     ,
		0xa5, "BY"    , 0xa6, "AY"    , 0xab, "DY"    ,
		0xb1, "#*Y"   , 0xb4, "*Y"    , 0xb5, "*BY"   ,
		0xb6, "*AY"   , 0xbb, "*DY"   ,
		0xc0, "+U"    , 0xc1, "#U"    , 0xc2, "-U"    ,
		0xc3, "=U"    , 0xc4, "U"     , 0xc5, "BU"    ,
		0xc6, "AU"    , 0xcb, "DU"    , 0xd1, "#*U"   ,
		0xd3, "*=U"   , 0xd4, "*U"    , 0xd5, "*BU"   ,
		0xd6, "*AU"   , 0xdb, "*DU"   ,
		0xe0, "+S"    , 0xe1, "#S"    , 0xe2, "-S"    ,
		0xe3, "=S"    , 0xe4, "S"     , 0xe5, "BS"    ,
		0xe6, "AS"    , 0xeb, "DS"    , 0xf1, "#*S"   ,
		0xf3, "*=S"   , 0xf4, "*S"    , 0xf5, "*BS"   ,
		0xf6, "*AS"   , 0xfb, "*DS"   ,
		0x00, ""      ,
	};
	char t, *pt;

start:  for (pt = str; pt[1]; pt++) {   /* sort the bytes into order */
		if (*(pt-1) > *pt) {
			t = *(pt+1);
			*(pt+1) = *pt;
			*pt = t;
			goto start;
		}
	}
	for (xpt = stuff; xpt->value; xpt++) {   /* then look 'em up. */
		if (strcmp (xpt->str, str) == 0) {
			obuf[*obuf == 0x10 || *obuf == 0x11 ? 2 : 1] |=
			    xpt->value;
			return;
		}
	}
	reporterr (E_BADOPT);
	return;
}
