#define BYTESPERLINE 3  /* # bytes per line on the listing */

#define SIGNED YES
#define SWAPPED YES
#define RELATIVE YES

opdclass o_reg   = { 1, NO    , NO, NO      , 0};
opdclass o_smem  = { 8, NO    , NO, NO      , 0};
opdclass o_rmem  = { 8, SIGNED, NO, RELATIVE, -2};
opdclass o_mem   = {16, NO    , NO, NO      , 0};
opdclass o_off   = { 8, SIGNED, NO, NO      , 0};
opdclass o_data  = { 8, SIGNED, NO, NO      , 0};
opdclass o_data2 = {16, SIGNED, NO, NO      , 0};
opdclass o_cond  = { 4, NO    , NO, NO      , 0};

insclass i_reg   = {1, 1, &o_reg , &o_none, -4, 0};
insclass i_regp  = {1, 1, &o_reg , &o_none,  0, 0};
insclass i_rimed = {2, 2, &o_reg , &o_data, -6, 8};
insclass i_rimd2 = {3, 2, &o_reg , &o_data2,-6, 16};
insclass i_rdir  = {2, 2, &o_reg , &o_smem, -6, 8};
insclass i_rindx = {2, 2, &o_reg , &o_off , -6, 8};
insclass i_rxtd  = {3, 2, &o_reg , &o_mem , -6,16};
insclass i_imed  = {3, 1, &o_data2,&o_none, 16, 0};
insclass i_dir   = {2, 1, &o_smem, &o_none,  8, 0};
insclass i_indx  = {2, 1, &o_off , &o_none,  8, 0};
insclass i_xtd   = {3, 1, &o_mem , &o_none, 16, 0};
insclass i_rel   = {2, 1, &o_rmem, &o_none,  8, 0};
insclass i_cond  = {2, 2, &o_cond, &o_rmem,  0, 8};

beginpattern c_cx
choicedef c_~1 = {"~1s", "~1z", ~2, 0, 0xff, NO};
endpattern
pattern c_cx,adc,2
pattern c_cx,add,2
pattern c_cx,and,2
pattern c_cx,bit,2
pattern c_cx,cmp,2
pattern c_cx,eor,2
pattern c_cx,lda,2
pattern c_cx,ldr,2
pattern c_cx,ora,2
pattern c_cx,sbc,2
pattern c_cx,sub,2
pattern c_cx,addd,1
pattern c_cx,ldd,1
pattern c_cx,std,1
pattern c_cx,sta,1
pattern c_cx,str,1
pattern c_cx,subd,1
pattern c_cx,jsr,1
pattern c_cx,cpx,1

beginpattern x_mem
	"~1"    , (insclass *)&c_~1, 0x00, choiceinstr,
	"~1s"   , &i_rdir , 0x90+0x~2, geninstr,
	"~1i"   , &i_rimed, 0x80+0x~2, geninstr,
	"~1x"   , &i_rindx, 0xa0+0x~2, geninstr,
	"~1z"   , &i_rxtd , 0xb0+0x~2, geninstr,
endpattern

beginpattern x_dou
	"~1"   , (insclass *)&c_~1, 0x00, choiceinstr,
	"~1s"  , &i_dir  , 0x90+0x~2, geninstr,
	"~1i"  , &i_imed , 0x80+0x~2, geninstr,
	"~1x"  , &i_indx , 0xa0+0x~2, geninstr,
	"~1z"  , &i_xtd  , 0xb0+0x~2, geninstr,
endpattern

beginpattern x_xreg
	"~1"    , (insclass *)&c_~1, 0x00, choiceinstr,
	"~1s"   , &i_rdir , 0x90+0x~2, geninstr,
	"~1i"   , &i_rimd2, 0x80+0x~2, geninstr,
	"~1x"   , &i_rindx, 0xa0+0x~2, geninstr,
	"~1z"   , &i_rxtd , 0xb0+0x~2, geninstr,
endpattern

beginpattern x_reg
	"~1"    , &i_xtd  , 0x70+0x~2, geninstr,
	"~1a"   , &i_reg  , 0x40+0x~2, geninstr,
	"~1x"   , &i_indx , 0x60+0x~2, geninstr,
endpattern

opdef optab[] = {
	"abx"    , &i_noopd, 0x3a, geninstr,
pattern x_mem,adc,9
pattern x_mem,add,b
pattern x_dou,addd,43
pattern x_mem,and,4
pattern x_reg,asl,8
pattern x_reg,asr,7
	"bc"     , &i_cond , 0x20, geninstr,
pattern x_mem,bit,5
	"bra"    , &i_rel  , 0x20, geninstr,
	"bsr"    , &i_rel  , 0x8d, geninstr,
	"cli"    , &i_noopd, 0x0e, geninstr,
pattern x_reg,clr,f
pattern x_mem,cmp,1
pattern x_reg,com,3
pattern x_dou,cpx,c
	"daa"    , &i_noopd, 0x19, geninstr,
pattern x_reg,dec,a
pattern x_mem,eor,8
pattern x_reg,inc,c
	"jmpx"   , &i_indx , 0x6e, geninstr,
	"jmp"    , &i_xtd  , 0x7e, geninstr,
pattern x_dou,jsr,d
pattern x_mem,lda,6
pattern x_dou,ldd,4c
pattern x_xreg,ldr,e
pattern x_reg,lsl,5
pattern x_reg,lsr,4
	"mul"    , &i_noopd, 0x3d, geninstr,
pattern x_reg,neg,0
pattern x_mem,ora,a
pattern x_reg,rol,9
pattern x_reg,ror,6
	"rti"    , &i_noopd, 0x3b, geninstr,
	"rts"    , &i_noopd, 0x39, geninstr,
pattern x_mem,sbc,2
	"sei"    , &i_noopd, 0x0f, geninstr,
pattern x_mem,sta,7
pattern x_dou,std,4d
pattern x_xreg,str,f
pattern x_mem,sub,0
pattern x_dou,subd,3
	"swi"    , &i_noopd, 0x3f, geninstr,
pattern x_reg,tst,d
	""       , &i_noopd, 0x00, geninstr
};

symbol predef[] = {
	{"ra" , 0x0, &o_reg , (segmnt *)0 },
	{"rb" , 0x1, &o_reg , (segmnt *)0 },
	{"rx" , 0x1, &o_reg , (segmnt *)0 },
	{"sp" , 0x0, &o_reg , (segmnt *)0 },
	{"nz" , 0x6, &o_cond, (segmnt *)0 },
	{"z"  , 0x7, &o_cond, (segmnt *)0 },
	{"ne" , 0x6, &o_cond, (segmnt *)0 },
	{"eq" , 0x7, &o_cond, (segmnt *)0 },
	{"nc" , 0x4, &o_cond, (segmnt *)0 },
	{"c"  , 0x5, &o_cond, (segmnt *)0 },
	{"gez", 0xc, &o_cond, (segmnt *)0 },
	{"gz" , 0xe, &o_cond, (segmnt *)0 },
	{"gt" , 0x2, &o_cond, (segmnt *)0 },
	{"lez", 0xf, &o_cond, (segmnt *)0 },
	{"le" , 0x3, &o_cond, (segmnt *)0 },
	{"lz" , 0xd, &o_cond, (segmnt *)0 },
	{"m"  , 0xb, &o_cond, (segmnt *)0 },
	{"ov" , 0x9, &o_cond, (segmnt *)0 },
	{"nov", 0x8, &o_cond, (segmnt *)0 },
	{"p"  , 0xa, &o_cond, (segmnt *)0 },
	{"ge" , 0x4, &o_cond, (segmnt *)0 },
	{"lt" , 0x5, &o_cond, (segmnt *)0 },
	{""   , 0x0, &o_none, (segmnt *)0 },
};

void optional () {}
