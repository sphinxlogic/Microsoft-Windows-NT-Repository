#include <stdio.h>
#include <ctype.h>

#define iswhite(x) (x)==' '||(x)=='\t'||(x)==','
#define skipword  while(isalnum(*pt)||*pt=='_')pt++;
#define skipwhite while(iswhite(*pt))pt++;

struct {
	char *name, *str;
} entry[100];

int ep, entryn = 0;
char buf[140], hold[2048];
char *pt, *pt2, *name, *arg1, *arg2;

extern int strncmp(), strcmp();

main ()
{
    while (gets (buf) > 0) {
	if (strncmp (buf, "beginpattern", 12) == 0) {
	    pt = buf;
	    skipword;
	    skipwhite;
	    entry[entryn].name = (char *) malloc (strlen (pt) + 1);
	    strcpy (entry[entryn].name, pt);
	    pt = hold;
	    while (gets (buf) > 0 && strncmp (buf, "endpattern", 10) != 0) {
		strcpy (pt, buf);
		pt += strlen (pt);
		*pt++ = '\n';
	    }
	    *pt = '\0';
	    entry[entryn].str = (char *) malloc (strlen (hold) + 1);
	    strcpy (entry[entryn].str, hold);
	    entryn++;
	} else if (strncmp (buf, "pattern", 7) == 0) {
	    pt = buf;
	    skipword;
	    skipwhite; name = pt; skipword; *pt++ = 0;
	    skipwhite; arg1 = pt; skipword; *pt++ = 0;
	    skipwhite; arg2 = pt; skipword; *pt = 0;
	    for (ep = 0; ep < entryn; ep++) {
		if (strcmp (name, entry[ep].name) == 0) {
		    for (pt = entry[ep].str; *pt; pt++) {
			if (*pt == '~') {
			    switch (*(++pt)) {
			    case '1':
				pt2 = arg1;
				goto argout;
			    case '2':
				pt2 = arg2;
       argout:                  while (*pt2) {
				    putchar (*pt2++);
				}
				break;
			    default:
				putchar ('~');
				putchar (*pt);
			    }
			} else {
			    putchar (*pt);
			}
		    }
		    goto nextch;
		}
	    }
	    fprintf (stderr, "makeops: can't find macro %s\n", name);
nextch:     ;
	} else {
	    puts (buf);
	}
    }
    exit (0);
}
