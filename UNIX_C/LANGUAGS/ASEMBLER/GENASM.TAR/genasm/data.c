#include "asm.h"

opdclass o_none  = {0, 0, 0, 0};
insclass i_noopd = {1, 0, &o_none, &o_none, 0, 0};
opdef pseudotab[] = {
	"bss"    , &i_noopd, 0x00, do_bss   ,
	"data"   , &i_noopd, 0x00, do_data  ,
	"data2"  , &i_noopd, 0x00, do_data2 ,
	"end"    , &i_noopd, 0x00, do_end   ,
	"equ"    , &i_noopd, 0x00, do_equ   ,
	"include", &i_noopd, 0x00, do_incl  ,
	"listoff", &i_noopd, 0x00, do_loff  ,
	"liston" , &i_noopd, 0x00, do_lon   ,
	"org"    , &i_noopd, 0x00, do_org   ,
	"seg"    , &i_noopd, 0x00, do_seg   ,
	"set"    , &i_noopd, 0x00, do_set   ,
	"string" , &i_noopd, 0x00, do_string,
	""       , &i_noopd, 0x00, 0
};

FILE *input[INCLSTACK], *output, *list = (FILE *)0, *srcin, *binout;
char *name, *label, *op, *opd, *optop;
char buf[LINEBUFLEN], linecopy[LINEBUFLEN], *filename[INCLSTACK];
int lineno[INCLSTACK], ignerr, end_found;
int errorstat=0, currinput=0, pass=0, liston=YES, listing=0, binary=0, xref=0;
symbol *symtab; Memad lc; Word *dummy;
segmnt segmain={0, 0, "", 0};
segmnt *seghd = &segmain, *curseg = &segmain, *exprseg;

#include "ops.h"

int listlen = BYTESPERLINE;
int pseudolen = sizeof (pseudotab) / sizeof (opdef);
int instrlen = sizeof (optab) / sizeof (opdef);
