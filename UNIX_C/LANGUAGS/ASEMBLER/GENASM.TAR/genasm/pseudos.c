#include "asm.h"

int do_incl ()
{
	if (pass == 1) {
		char *ip;

		if (++currinput > INCLSTACK)
			reporterr (E_INCL);
		opd++;
		if ((ip = index (opd, '"')) == 0)
			reporterr (E_INCLSYN);
		*ip = 0;
		if ((input[currinput] = fopen (opd, "r")) == NULL)
			reporterr (E_INPUT);
		filename[currinput] = strcpy (malloc ((unsigned) strlen (opd) + 1), opd);
		lineno[currinput] = 0;
	}
	return (0);
}


int do_org ()
{
	if (label && *label)
		insert (label, (long) lc, &o_none, curseg, NO);
	if (pass == 2)
		listit (linecopy, lc, dummy, 0);
	lc = (Memad) expr (&opd, &ignerr, NO);
	return (0);
}


int do_loff ()
{
	liston = NO;
	return (0);
}


int do_lon ()
{
	liston = YES;
	return (0);
}


int do_equ ()
{
	long eqtemp;

	eqtemp = expr (&opd, &ignerr, NO);
	if (label && *label)
		insert (label, eqtemp, &o_none, exprseg, NO);
	if (pass == 2)
		listit (linecopy, eqtemp, dummy, 0);
	return (0);
}


int do_seg ()
{
	segmnt *sp, *osp;

	curseg->lc = lc;
	if (opd && *opd) {
		for (sp = seghd; sp; osp = sp, sp = sp->next) {
			if (strcmp (sp->name, opd) == 0) {
				lc = sp->lc;
				curseg = sp;
				goto fin_seg;
			}
		}
	} else {
		lc = seghd->lc;
		curseg = seghd;
	}
	curseg = osp->next = (segmnt *) malloc ((unsigned) sizeof (segmnt));
	curseg->name = strcpy (malloc ((unsigned) strlen (opd) + 1), opd);
	curseg->lc = lc = 0;
	curseg->next = (segmnt *) 0;
fin_seg:
	if (pass == 2)
		listit (linecopy, lc, dummy, 0);
	return (0);
}


int do_set ()
{
	long eqtemp;

	eqtemp = expr (&opd, &ignerr, NO);
	if (label && *label)
		insert (label, eqtemp, &o_none, exprseg, YES);
	if (pass == 2)
		listit (linecopy, eqtemp, dummy, 0);
	return (0);
}


int do_bss ()
{
	if (label && *label)
		insert (label, (long) lc, &o_none, curseg, NO);
	if (pass == 2)
		listit (linecopy, lc, dummy, 0);
	lc += (Memad) expr (&opd, &ignerr, NO);
	return (0);
}


int do_end ()
{
	end_found ++;
	curseg->lc = lc;
	if (pass == 2) {
		listit (linecopy, lc, dummy, 0);
		lc = 0xffff;
		putoutbin (dummy, 0);
	}
	curseg = seghd;
	return (1);
}


int do_data ()
{
	Word temp, templist[MAXBYTPERINS];
	char *tp;
	int count;

	if (label && *label)
		insert (label, (long) lc, &o_none, curseg, NO);
	tp = opd;
	count = 1;
	if (*opd == ':') {
		++opd;
		count = expr (&opd, &ignerr, NO);
		if (*opd == ':') {
			opd ++;
		} else {
			reporterr (E_EXPR);
			count = 1;
			opd = tp;
		}
	}
	if (pass == 2) {
		int i, j;

		temp = (Word) expr (&opd, &ignerr, NO);
		for (i = 0; i < MAXBYTPERINS; i++)
		       templist[i] = temp;
		listit (linecopy, lc, templist, count);
		for (i = 0; i < count; i++)
			putoutbin (&temp, 1);
	}
	lc += count;
	return (0);
}


int do_data2 ()
{
	Long temp;
	char *tp;
	int count;

	if (label && *label)
		insert (label, (long) lc, &o_none, curseg, NO);
	tp = opd;
	count = 1;
	if (*opd == ':') {
		++opd;
		count = expr (&opd, &ignerr, NO);
		if (*opd == ':') {
			opd ++;
		} else {
			reporterr (E_EXPR);
			count = 1;
			opd = tp;
		}
	}
	if (pass == 2) {
		int i;

		temp = (Long) expr (&opd, &ignerr, NO);
		listit (linecopy, lc, (Word *)&temp, 2*count);
		for (i = 0; i < count; i++) {
			putoutbin ((Word *)&temp, 1);
		}
	}
	lc += (2 * count);
	return (0);
}


int do_string ()
{
	Word buf[120], *bp;
	Word delim;
	int len, i;

	if (label && *label)
		insert (label, (long) lc, &o_none, curseg, NO);
	delim = *opd++;
	bp = buf;
	while (*opd != delim) {
		if (*opd != '\\')
			*bp++ = *opd;
		else {
			++opd;
			*bp++ = escape (&opd);
		}
		opd++;
	}
	*bp++ = '\0';
	len = bp - buf;
	if (pass == 2) {
		listit (linecopy, lc, buf, len);
		putoutbin (buf, len);
	}
	lc += len;
	return (0);
}


