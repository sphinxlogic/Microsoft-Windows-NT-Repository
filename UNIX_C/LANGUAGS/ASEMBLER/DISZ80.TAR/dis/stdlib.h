/*
 * stdlib.h - dummy <stdlib.h> to satisfy non-ANSI compilers
 *
 */

char *strstr();

