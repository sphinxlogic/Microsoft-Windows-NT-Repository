/*
 * disas - simple Z80/Z280 disassembler
 *
 * Copyright 1989 by Luc Rooijakkers <lwj@cs.kun.nl>
 * Permission is hereby granted to use and modify this code for
 * non-commercial use, provided this copyright is retained.
 *
 * usage: disas file
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "dis.h"

/*
 * change log
 *
 * ../../88	Created
 * 16/12/89	Fixed JR/JP address bug
 * 26/12/89	Cut down for public release
 *
 */

char DisasId[] = "@(#) DISAS 26/12/89";

/*
 *	0	0	1	2	3	4	4	5
 * 	0.......8.......6.......4.......2.......0.......8.......6
 *
 * 	XXXX xxxxxxxx+	CALL	(IX+XXH),XXH		....
 *
 */

#define	OPCODE	16
#define	OPERAND	24
#define	ASCII	48

/*
 * prototypes
 *
 */

#ifdef PROTO

void main(int argc,char **argv);
int instr(word addr,byte *buf,int len);
void leader(word addr,byte *buf,int len);
void trailer(byte *buf,int len);
int get(byte *buf,int size,word addr);
void clear(void);
void outs(char *s);
void flush(void);
void tab(int pos);
void outval(word value,int out);

#else /* !PROTO */

void main();
int instr();
void leader();
void trailer();
int get();
void clear();
void outs();
void flush();
void tab();
void outval();

#endif /* PROTO */

/*
 * variables
 *
 */

FILE *file;
char *name;
word address;

int col;

char line[80];
char *linep;

/*
 * main function
 *
 */

void main(argc,argv)
int argc;
char **argv;
{
	word addr;
	int len;
	byte buf[16];

	if(argc!=2) {
		fprintf(stderr,"Usage: disas file\n");
		exit(1);
	}

	name=argv[1];

	if((file=fopen(name,"rb"))==NULL) {
		perror(name);
		exit(1);
	}

	for(addr=0x100;(len=get(buf,16,addr))>0;addr+=len) {
		jumped=0;
		len=instr(addr,buf,len);
		if(jumped)
			putchar('\n');
	}

	fclose(file);

	exit(0);
}

int instr(addr,buf,size)
word addr;
byte *buf;
int size;
{
	int len;
	char linebuf[80], *sep;

	if(size<=0)
		return(0);

	linep=linebuf;
	col=OPCODE;
	address=addr;

	len=dis(buf);

	*linep='\0';

	if(len>size) {
		linep=linebuf;
		col=OPCODE;

		outs("DEFB\t");
		for(sep="",len=0;len<size;len++) {
			outs(sep);
			outval(buf[len],OUT_N);
			sep=",";
		}

		*linep='\0';
	}

	leader(addr,buf,len);
	outs(linebuf);
	trailer(buf,len);

	return(len);
}

void leader(addr,buf,len)
word addr;
byte *buf;
int len;
{
	col=0;

	col+=printf("%04X ",addr);

	for(;len>0 && col+3<OPCODE;len--,buf++)
		col+=printf("%02X",*buf);

	if(len>0)
		col+=printf("+");

	clear();
	tab(OPCODE);
	flush();
}

void trailer(buf,len)
byte *buf;
int len;
{
	tab(ASCII);
	flush();

	for(;len>0;len--,buf++) {
		if(isascii(*buf) && isprint(*buf))
			putchar((char)(*buf));
		else
			putchar('.');
		col++;
	}

	putchar('\n');
}

int get(buf,size,addr)
byte *buf;
int size;
word addr;
{
	char getbuf[16];
	int len,i;

	if(fseek(file,(long)addr-0x100,0)!=0) {
		fprintf(stderr,"%s: Can't seek to address %04X\n",name,addr);
		exit(1);
	}

	len=fread(getbuf,1,size,file);

	for(i=0;i<len;i++)
		buf[i]=(getbuf[i]&0xFF);

	return(len);
}

void clear()
{
	linep=line;
}

void outs(s)
char *s;
{
	while(*s) {
		if(*s=='\t')
			col=(col+8)&~7;
		else
			col++;
		*linep++=*s++;
	}
}

void flush()
{
	*linep='\0';
	fputs(line,stdout);
	linep=line;
}

void tab(pos)
int pos;
{
	while(((col+8)&~7)<=pos) {
		*linep++='\t';
		col=(col+8)&~7;
	}

	while(col<pos) {
		*linep++=' ';
		col++;
	}
}

void outval(value,out)
word value;
int out;
{
	outhex(value,out,address);
}

