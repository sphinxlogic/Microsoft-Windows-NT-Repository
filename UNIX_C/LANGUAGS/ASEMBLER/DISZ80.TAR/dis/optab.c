/*
 * optab - generate opcode table for Z80/Z280 disassembler
 *
 * Copyright 1989 by Luc Rooijakkers <lwj@cs.kun.nl>
 * Permission is hereby granted to use and modify this code for
 * non-commercial use, provided this copyright is retained.
 *
 * Usage: optab [-] [byte...]
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "dis.h"

/*
 * change log
 *
 * 23/12/89	Split off from dis.c
 * 26/12/89	Added debugging option
 *
 */

char OpTabId[] = "@(#) OPTAB 26/12/89";

/*
 * graphic characters
 *
 */

#ifdef __MSDOS__

/* Only MS-DOS has those nice graphic characters... */

#define CH_B3		0xB3
#define CH_B6		0xB6
#define CH_BA		0xBA
#define CH_BB		0xBB
#define CH_BC		0xBC
#define CH_C4		0xC4
#define CH_C5		0xC5
#define CH_C7		0xC7
#define CH_C8		0xC8
#define CH_C9		0xC9
#define CH_CD		0xCD
#define CH_CF		0xCF
#define CH_D1		0xD1

#else /* !__MSDOS__ */

#define CH_B3		'|'
#define CH_B6		'+'
#define CH_BA		'|'
#define CH_BB		'+'
#define CH_BC		'+'
#define CH_C4		'-'
#define CH_C5		'+'
#define CH_C7		'+'
#define CH_C8		'+'
#define CH_C9		'+'
#define CH_CD		'-'
#define CH_CF		'+'
#define CH_D1		'+'

#endif /* __MSDOS__ */

/*
 * prototypes
 *
 */

#ifdef PROTO

void tab(int nbytes,byte *bytes);
int outins(int nbytes,byte *bytes);

#else /* !PROTO*/

void tab();
int outins();

#endif /* PROTO */

/*
 * variables
 *
 */

int debug;
char outbuf[50];
char *outbufp;

/*
 * main program
 *
 */

void main(argc,argv)
int argc;
char **argv;
{
	byte bytes[10];
	int i,arg,nbytes = 0;

	for(i=1;i<argc;i++) {
		if(strcmp(argv[i],"-")==0) {
			debug=1;
			continue;
		}
		if(sscanf(argv[i],"%x",&arg)!=1 || arg<0 || arg>255) {
			fprintf(stderr,"\nUsage: optab [-] [byte...]\n");
			exit(1);
		}
		bytes[nbytes++]=arg;
	}

	tab(nbytes,bytes);

	exit(0);
}

/*
 * generate opcode table
 *
 */

void tab(nbytes,bytes)
int nbytes;
byte *bytes;
{
	char line[200],dline[200];
	int special,i,row,col;
	word op;

	for(i=0;i<nbytes;i++)
		printf("%02X ",bytes[i]);

	printf("XX opcodes\n\n");

	special=(nbytes==2 && (bytes[0]==0xDD || bytes[0]==0xFD)
			   && bytes[1]==0xCB
		);

	memset(line,CH_C4,200);
	memset(dline,CH_CD,200);

	printf("%c%.6s",CH_C9,dline);
	for(col=0;col<=7;col++)
		printf("%c%.18s",CH_D1,dline);
	printf("%c\n",CH_BB);

	printf("%c%6s",CH_BA,"");
	for(col=0;col<=7;col++)
		printf("%c%7s%X/%X%8s",CH_B3,"",col,col+0x08,"");
	printf("%c\n",CH_BA);

	printf("%c%.6s",CH_C7,line);
	for(col=0;col<=7;col++)
		printf("%c%.18s",CH_C5,line);
	printf("%c\n",CH_B6);

	for(row=0x00;row<=0xF8;row+=0x08) {

		if ((row&0x08)==0)
			printf("%c%2s%02X%2s",CH_BA,"",row,"");
		else
			printf("%c%6s",CH_BA,"");

		for(col=0;col<=7;col++) {
			op=row|col;

			bytes[nbytes+special]=op;

			outbufp=outbuf;
			outins(nbytes,bytes);
			*outbufp='\0';

			printf("%c %-17.17s",CH_B3,outbuf);
        	}
		printf("%c\n",CH_BA);
        }

	printf("%c%.6s",CH_C8,dline);
	for(col=0;col<=7;col++)
		printf("%c%.18s",CH_CF,dline);
	printf("%c\n",CH_BC);
}

/*
 * output an instruction
 *
 */

int outins(nbytes,bytes)
int nbytes;
byte *bytes;
{
	/* make sure things like "CB" and "DD ED" do not come out funny */

	if ( nbytes==0 || ( bytes[0]==0xDD || bytes[0]==0xFD ) ) {
		if ( nbytes<2 &&
		     ( bytes[nbytes]==0xCB || bytes[nbytes]==0xDD ||
		       bytes[nbytes]==0xED || bytes[nbytes]==0xFD ) )
		{
			outs("?");
			return(nbytes+1);
		}
	}

	return(dis(bytes));
}

/*
 * output a string
 *
 */

void outs(s)
char *s;
{
	for(;*s!='\0';s++)
		*outbufp++= (*s=='\t') ? ' ' : *s;
}

/*
 * output a value
 *
 */

void outval(value,out)
word value;
int out;
{
	if(debug)
		outdebug(value,out);
	else if(out==OUT_EPU)
		outbufp--;
	else
		outsym(value,out);
}

