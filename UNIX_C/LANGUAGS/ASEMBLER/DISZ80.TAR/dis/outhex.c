/*
 * outhex - hexadecimal output routine for Z80/Z280 disassembler
 *
 * Copyright 1989 by Luc Rooijakkers <lwj@cs.kun.nl>
 * Permission is hereby granted to use and modify this code for
 * non-commercial use, provided this copyright is retained.
 *
 */

#include <stdio.h>
#include <ctype.h>

#include "dis.h"

/*
 * change log
 *
 * 12/08/89	Split off from dis.c
 * 01/10/89	Split OUT_IO into OUT_INP, OUT_OUTP
 * 23/12/89	Cleaned up for public release
 *
 */

char OutHexId[] = "@(#) OUTHEX 23/12/89";

/*
 * hexadecimal output routine
 *
 */

void outhex(value,out,addr)
word value;
int out;
word addr;
{
	char buf[11]; /* (PC+xxxxH) is the longest */

	switch(out) {

	case OUT_N:
	case OUT_INP:
	case OUT_OUTP:
	case OUT_EPU:
		sprintf(buf,"%02XH",value);
		break;

	case OUT_NN:
	case OUT_JP:
	case OUT_CALL:
		sprintf(buf,"%04XH",value);
		break;

	case OUT_D:
		if(value<0x80)
			sprintf(buf,"+%02XH",value);
		else
			sprintf(buf,"-%02XH",0x100-value);
		break;

	case OUT_DD:
		if(value<0x8000)
			sprintf(buf,"+%04XH",value);
		else
			sprintf(buf,"-%04XH",-value);
		break;

	case OUT_PC:
		if(value<0x8000)
			sprintf(buf,"(PC+%04XH)",value);
		else
			sprintf(buf,"(PC-%04XH)",-value);
		break;

	case OUT_JR:
		sprintf(buf,"%04XH",addr+value);
		break;

	case OUT_RST:
		if(value<0x10)
			sprintf(buf,"%X",value);
		else
			sprintf(buf,"%02XH",value);
		break;

	default:
		sprintf(buf,"?",value);
		break;
	}

	if(isalpha(buf[0]))
		outs("0");

	outs(buf);
}

