/*
 * outdebug - debugging output routine for Z80/Z280 disassembler
 *
 * Copyright 1989 by Luc Rooijakkers <lwj@cs.kun.nl>
 * Permission is hereby granted to use and modify this code for
 * non-commercial use, provided this copyright is retained.
 *
 */

#include <stdio.h>

#include "dis.h"

/*
 * change log
 *
 * 23/12/89	Split off from dis.c
 *
 */

char OutDebugId[] = "@(#) OUTDEBUG 23/12/89";

/*
 * debugging output routine
 *
 */

void outdebug(value,out)
word value;
int out;
{
	char buf[4]; /* xxH is the longest */
	char *str;

	switch(out) {

	case OUT_N:
		str="n";
		break;

	case OUT_NN:
		str="nn";
		break;

	case OUT_D:
		str="+d";
		break;

	case OUT_DD:
		str="+dd";
		break;

	case OUT_PC:
		str="pc";
		break;

	case OUT_INP:
		str="in";
		break;

	case OUT_OUTP:
		str="out";
		break;

	case OUT_EPU:
		str="epu";
		break;

	case OUT_JR:
		str="jr";
		break;

	case OUT_JP:
		str="jp";
		break;

	case OUT_CALL:
		str="call";
		break;

	case OUT_RST:
		if(value<0x10)
			sprintf(buf,"%X",value);
		else
			sprintf(buf,"%02XH",value);
		str=buf;
		break;

	default:
		str="?";
		break;
	}

	outs(str);
}


