/*
 * oplist - generate opcode list for Z80/Z280 disassembler
 *
 * Copyright 1989 by Luc Rooijakkers <lwj@cs.kun.nl>
 * Permission is hereby granted to use and modify this code for
 * non-commercial use, provided this copyright is retained.
 *
 * Usage: oplist [-] [byte...]
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "dis.h"

/*
 * change log
 *
 * 23/12/89	Split off from dis.c
 * 26/12/89	Added debugging option
 *
 */

char OpListId[] = "@(#) OPLIST 26/12/89";

/*
 * prototypes
 *
 */

#ifdef PROTO

void list(int nbytes,byte *bytes);
int outins(int nbytes,byte *bytes);

#else /* !PROTO*/

void list();
int outins();

#endif /* PROTO */

/*
 * variables
 *
 */

int debug;
char outbuf[50];
char *outbufp;

/*
 * main program
 *
 */

void main(argc,argv)
int argc;
char **argv;
{
	byte bytes[10];
	int i,arg,nbytes = 0;

	for(i=1;i<argc;i++) {
		if(strcmp(argv[i],"-")==0) {
			debug=1;
			continue;
		}
		if(sscanf(argv[i],"%x",&arg)!=1 || arg<0 || arg>255) {
			fprintf(stderr,"\nUsage: oplist [-] [byte...]\n");
			exit(1);
		}
		bytes[nbytes++]=arg;
	}

	list(nbytes,bytes);

	exit(0);
}

/*
 * generate opcode list
 *
 */

void list(nbytes,bytes)
int nbytes;
byte *bytes;
{
	int special,len,i;
	word op;

	for(i=0;i<nbytes;i++)
		printf("%02X ",bytes[i]);

	printf("XX opcodes\n\n");

	special=(nbytes==2 && (bytes[0]==0xDD || bytes[0]==0xFD)
			   && bytes[1]==0xCB
		);

	for(op=0x00;op<=0xFF;op++) {

		bytes[nbytes+special]=op;

		outbufp=outbuf;
		len=outins(nbytes,bytes);
		*outbufp='\0';

		for(i=0;i<len && i<7;i++) {
			if(i<nbytes || i==nbytes+special)
				printf("%02X",bytes[i]);
			else
				printf("**");
		}

		if(len>7) {
			printf("+ ");
			i++;
		}

		for(;i<8;i++)
			printf("  ");

		printf("%s\n",outbuf);
        }
}

/*
 * output an instruction
 *
 */

int outins(nbytes,bytes)
int nbytes;
byte *bytes;
{
	/* make sure things like "CB" and "DD ED" do not come out funny */

	if ( nbytes==0 || ( bytes[0]==0xDD || bytes[0]==0xFD ) ) {
		if ( nbytes<2 &&
		     ( bytes[nbytes]==0xCB || bytes[nbytes]==0xDD ||
		       bytes[nbytes]==0xED || bytes[nbytes]==0xFD ) )
		{
			outs("?");
			return(nbytes+1);
		}
	}

	return(dis(bytes));
}

/*
 * output a string
 *
 */

void outs(s)
char *s;
{
	while(*s)
		*outbufp++=*s++;
}

/*
 * output a value
 *
 */

void outval(value,out)
word value;
int out;
{
	if(debug)
		outdebug(value,out);
	else if(out==OUT_EPU)
		outbufp--;
	else
		outsym(value,out);
}

