/*
 * dis - generic Z80/Z280 disassembler
 *
 * Copyright 1989 by Luc Rooijakkers <lwj@cs.kun.nl>
 * Permission is hereby granted to use and modify this code for
 * non-commercial use, provided this copyright is retained.
 *
 */

#include <stdio.h>
#include <string.h>

#include "dis.h"

/*
 * Use compiler options to define either Z80 or Z280.
 * If none is defined, Z80 is the default.
 *
 */

#ifndef Z80
#ifndef Z280
#define	Z80
#endif
#endif

/*
 * change log
 *
 * ../../88	Created as symbolic Z280 disassembler
 * ../../88	Extended to non-symbolic Z280 disassembler
 * ../../88	Added #if's for Z80 disassembler
 * 07/07/88	First final version
 * 12/08/89	Split off output routines
 * 01/10/89	Split OUT_IO into OUT_INP,OUT_OUTP
 * 23/12/89	Split off more output routines
 * 24/12/89	Cleaned up for public release
 * 27/12/89	Use strchr() instead of strstr()
 *
 */

#ifdef Z280
	char DisId[] = "@(#) DIS (Z280) 27/12/89";
#else
	char DisId[] = "@(#) DIS (Z80) 27/12/89";
#endif

/*
 * prototypes
 *
 */

#ifdef PROTO

static void outsp(char *s,char *sp);
static void outjrt(int len);
static void outjpt(int out);
static void expand(char *s);
static void dis_CB(void);
static void dis_ED(void);

#else /* !PROTO */

static void outsp();
static void outjrt();
static void outjpt();
static void expand();
static void dis_CB();
static void dis_ED();

#endif /* PROTO */

/*
 * byte/word get routines
 *
 */

static byte *getptr;

#define	onebyte(disp)	( (word) ( (unsigned)getptr[disp]&0xFF ) )

#define	getbyte()	( getptr+=1, onebyte(-1) )

#define	getword()	( getptr+=2, onebyte(-2)+(onebyte(-1)<<8) )

/*
 * disassembler output routines
 *
 */

static int am_code;	/* addressing mode code */

#define	AM_NULL		0
#define	AM_DD		1
#define	AM_FD		2

#define outop(s)	( outs(s), outs("\t") )

#define	outn(out)	outval(getbyte(),out)

#define	outnn(out)	outval(getword(),out)

static void outsp(s,sp)
char *s;
char *sp;
{
	char buf[5];	/* "(RR+" is the longest */
	char *bp;

	for(bp=buf;s<sp;)
		*bp++=*s++;

	*bp='\0';

	outs(buf);
}

#define	outepu(s)	( \
	outs(s), \
	outn(OUT_EPU), \
	outs(","), \
	outn(OUT_EPU), \
	outs(","), \
	outn(OUT_EPU), \
	outs(","), \
	outn(OUT_EPU) \
)

static char *tab_xr[]={

/* AM_NULL */
	"B",		"C",		"D",		"E",
	"H",		"L",		"(HL)",		"A",

/* AM_DD */
	"(SP+dd)",	"(HL+IX)",	"(HL+IY)",	"(IX+IY)",
	"IXH",		"IXL",		"(IX+d)",	"(nn)",

/* AM_FD */
	"(PC+dd)",	"(IX+dd)",	"(IY+dd)",	"(HL+dd)",
	"IYH",		"IYL",		"(IY+d)",	"n"

};

#define outxr(xr)	expand(tab_xr[am_code*8+(xr)])
#define outr(r)		outs(tab_xr[(r)])
#define outir(ir)	( (4<=(ir) && (ir)<=6) ? outxr(ir) : outr(ir) )
#define outim()		outxr(6)

static char *tab_xrp[]={

/* AM_NULL */
	"BC",		"DE",		"HL",		"SP",

/* AM_DD*/
	"(HL)",		"(nn)",		"IX",		"(PC+dd)",

/* AM_FD */
	"(IX+dd)",	"(IY+dd)",	"IY",		"nn"

};

#define outxrp(xrp)	expand(tab_xrp[am_code*4+(xrp)])

#define outprp(prp)	( (am_code==AM_NULL && (prp)==3) ? outs("AF") \
							 : outxrp(prp) \
			)

#define outrp(rp)	outs(tab_xrp[(rp)])

static char *tab_irp[]={

/* AM_NULL */
	"BC",		"DE",		"HL",		"SP",

/* AM_DD */
	"BC",		"DE",		"IX",		"SP",

/* AM_FD */
	"BC",		"DE",		"IY",		"SP"

};

#define outirp(irp)	outs(tab_irp[am_code*4+(irp)])
#define outihl()	outirp(2)

#ifdef Z280

static char *tab_ea[]={
	"(SP+dd)",	"(HL+IX)",	"(HL+IY)",	"(IX+IY)",
	"(PC+dd)",	"(IX+dd)",	"(IY+dd)",	"(HL+dd)"
};

#define	outea(ea)	expand(tab_ea[(ea)])

#endif

static char *tab_cc[]={
#ifdef Z280
	"NZ",	"Z",	"NC",	"C",	"NV",	"V",	"P",	"M"
#else
	"NZ",	"Z",	"NC",	"C",	"PO",	"PE",	"P",	"M"
#endif
};

#define	outcc(cc)	outs(tab_cc[(cc)])

#ifdef Z280
#define	W	"W"
#else
#define	W	/*empty*/
#endif

static char *tab_op1[]={
	"ADD",	"ADC",	"SUB",	"SBC",	"AND",	"XOR",	"OR",	"CP"
};

#define	outop1(op)	outop(tab_op1[((op)>>3)&0x07])

#ifdef Z80

static char *tab_a[]={
	"A,",	"A,",	"",	"A,",	"",	"",	"",	""
};

#define outa(op)	outs(tab_a[((op)>>3)&0x07])

#else /* Z280 */

#define	outa(op)	outs("A,")

#endif /* Z80 */

static char *tab_op2[]={
	"RLCA",	"RRCA",	"RLA",	"RRA",	"DAA",	"CPL",	"SCF",	"CCF"
};

#define	outop2(op)	outop(tab_op2[((op)>>3)&0x07])

static void outjrt(len)
int len;
{
	word disp = getbyte();

	if(disp>=0x80)
		disp+=-0x100;	/* cryptic but portable */

	outval(len+disp,OUT_JR);
}

static void outjpt(out)
int out;
{
	switch(am_code) {

	case AM_NULL:
		outnn(out);
		break;

	case AM_DD:
		outs("(HL)");
		break;

	case AM_FD:
		outnn(OUT_PC);
		break;

	}
}

static void expand(s)
char *s;
{
	char *sp;

	if (strcmp(s,"(PC+dd)")==0) {
		outnn(OUT_PC);
	} else if ((sp=strchr(s,'n'))!=NULL) {
		if(sp[1]=='n') { /* nn */
			outsp(s,sp);
			outnn(OUT_NN);
			outs(sp+2);
		} else { /* n */
			outsp(s,sp);
			outn(OUT_N);
			outs(sp+1);
		}
	} else if ((sp=strchr(s,'+'))!=NULL && sp[1]=='d') {
		if(sp[2]=='d') { /* +dd */
			outsp(s,sp);
			outnn(OUT_DD);
			outs(sp+3);
		} else { /* +d */
			outsp(s,sp);
			outn(OUT_D);
			outs(sp+2);
		}
	} else
		outs(s);
}

/*
 * disassembler functions
 *
 */

int jumped;	/* unconditional JR, JP, RET flag */

int dis(bytes)
byte *bytes;
{
	word op;

	getptr=bytes;
	am_code=AM_NULL;
	jumped=0;

dis_op:
	op=getbyte();

	switch (op&0xC0) {

	case 0x00:
		switch (op&0xC7) {

		case 0x00:
			switch (am_code) {

			case AM_NULL:
				if (op==0x00)
					outs("NOP");
				else if (op==0x08) {
					outop("EX");
					outs("AF,AF'");
				} else {
					outop( (op==0x10) ? "DJNZ" : "JR" );
					if( op>=0x20 ) {
						outcc((op>>3)&0x03);
						outs(",");
					}
					outjrt(2);
					if(op==0x18)
						jumped=1;
				}
				break;

			case AM_DD:
#ifdef Z280
				if ((op&0x37)==0x20) {
					outop( (op==0x20) ? "JAR" : "JAF" );
					outjrt(3);
					break;
				}
#endif
				/* fall-trough */

			case AM_FD:
				outs("?");

			}
			break;

		case 0x01:
			if (op&0x08) {
				outop("ADD");
				outihl();
				outs(",");
				outirp((op>>4)&0x03);
#ifdef Z280
			} else if(am_code!=AM_FD || op==0x21) {
#else
			} else if(am_code==AM_NULL || op==0x21) {
#endif
				outop("LD"W);
				outxrp((op>>4)&0x03);
				outs(",");
				outnn(OUT_NN);
			} else
				outs("?");
			break;

		case 0x02:
			if ((op&0x37)==0x22) {
				outop("LD"W);
				if (op==0x22) {
					outs("(");
					outnn(OUT_NN);
					outs("),");
					outihl();
				} else {
					outihl();
					outs(",(");
					outnn(OUT_NN);
					outs(")");
				}
			} else if (am_code==AM_NULL) {
				static char *tab[]={
					"(BC),A",	"A,(BC)",
					"(DE),A",	"A,(DE)",
					NULL,		NULL,
					"(nn),A",	"A,(nn)"
				};
				outop("LD");
				expand(tab[(op>>3)&0x07]);
			} else
				outs("?");
			break;

		case 0x03:
#ifdef Z280
			if(am_code!=AM_FD || op<0x30) {
#else
			if(am_code==AM_NULL || (op&0x37)==0x23) {
#endif
				outop( (op&0x08) ? "DEC"W : "INC"W );
				outxrp((op>>4)&0x03);
			} else
				outs("?");
			break;

		case 0x04:
#ifdef Z280
			if(am_code!=AM_FD || op!=0x3C) {
#else
			if(am_code==AM_NULL || op==0x34) {
#endif
				outop("INC");
				outxr((op>>3)&0x07);
			} else
				outs("?");
			break;

		case 0x05:
#ifdef Z280
			if(am_code!=AM_FD || op!=0x3D) {
#else
			if(am_code==AM_NULL || op==0x35) {
#endif
				outop("DEC");
				outxr((op>>3)&0x07);
			} else
				outs("?");
			break;

		case 0x06:
#ifdef Z280
			if(am_code!=AM_FD || op!=0x3E) {
#else
			if(am_code==AM_NULL || op==0x36) {
#endif
				outop("LD");
				outxr((op>>3)&0x07);
				outs(",");
				outn(OUT_N);
			} else
				outs("?");
			break;

		case 0x07:
			if (am_code==AM_NULL) {
				outop2(op);
#ifdef Z280
				if(op==0x2F)
					outs("A");
#endif
			} else
				outs("?");
			break;
		}
		break;

	case 0x40:
		if ( op==0x76 )
			if (am_code==AM_NULL)
				outs("HALT");
			else
				outs("?");
#ifdef Z280
		else if ( am_code==AM_NULL || op>=0x60 && op!=0x7F ||
			0x04<=(op&0x07) && (op&0x07)<=0x06 )
#else
		else if ( am_code==AM_NULL || (op&0xF8)==0x70 ||
				(op&0x07)==0x06 )
#endif
		{
			outop("LD");
			if (op==0x66 || op==0x6E)
				outr((op>>3)&0x07);
			else
				outir((op>>3)&0x07);
			outs(",");
			if (op==0x74 || op==0x75 )
				outr(op&0x07);
			else if (op>=0x78)
				outxr(op&0x07);
			else
				outir(op&0x07);
		} else
			outs("?");
		break;

	case 0x80:
#ifdef Z280
		if(am_code!=AM_FD || (op&0x07)!=0x07) {
#else
		if(am_code==AM_NULL || (op&0x07)==0x06) {
#endif
			outop1(op);
			outa(op);
			outxr(op&0x07);
		} else
			outs("?");
		break;

	case 0xC0:
		switch (op&0xC7) {

		case 0xC0:
			if (am_code==AM_NULL) {
				outop("RET");
				outcc((op>>3)&0x07);
			} else
				outs("?");
			break;

		case 0xC1:
			if ((op&0xEF)!=0xC9 || am_code==AM_NULL) {
				if (op&0x08) {
        				if (op==0xC9) {
						outs("RET");
        					jumped=1;
        				} else if (op==0xD9)
        					outop("EXX");
	        			else if (op==0xE9) {
        					outop("JP");
						outs("(");
        					outihl();
						outs(")");
						jumped=1;
	        			} else {
        					outop("LD"W);
        					outs("SP,");
        					outihl();
        				}
#ifdef Z280
				} else if(am_code!=AM_FD || op==0xE1) {
#else
				} else if(am_code==AM_NULL || op==0xE1) {
#endif
					outop("POP");
					outprp((op>>4)&0x03);
				} else
					outs("?");
			} else
				outs("?");
			break;

		case 0xC2:
#ifdef Z80
			if(am_code==AM_NULL) {
#endif
				outop("JP");
				outcc((op>>3)&0x07);
				outs(",");
				outjpt(OUT_JP);
#ifdef Z80
			} else
				outs("?");
#endif
			break;

		case 0xC3:
			switch (op) {

			case 0xC3:
#ifdef Z280
				if(am_code!=AM_DD) {
#else
				if(am_code==NULL) {
#endif
					outop("JP");
					outjpt(OUT_JP);
					jumped=1;
				} else
					outs("?");
				break;

			case 0xCB:
				dis_CB();
				break;

			case 0xD3:
				if (am_code==AM_NULL) {
					outop("OUT");
					outs("(");
					outn(OUT_OUTP);
					outs("),A");
				} else
					outs("?");
				break;

			case 0xDB:
				if (am_code==AM_NULL) {
					outop("IN");
					outs("A,(");
					outn(OUT_INP);
					outs(")");
				} else
					outs("?");
				break;


			case 0xE3:
				outop("EX");
				outs("(SP),");
				outihl();
				break;

			case 0xEB:
#ifdef Z280
				outop("EX");
				if (am_code==AM_NULL)
					outs("DE");
				else
					outihl();
				outs(",HL");
#else /* Z80 */
				if(am_code==AM_NULL) {
					outop("EX");
					outs("DE,HL");
				} else
					outs("?");
#endif /* Z280 */
				break;

			case 0xF3:
				if (am_code==AM_NULL)
					outs("DI");
				else
					outs("?");
				break;

			case 0xFB:
				if (am_code==AM_NULL)
					outs("EI");
				else
					outs("?");
				break;

			}
			break;

		case 0xC4:
#ifdef Z80
			if(am_code==NULL) {
#endif
				outop("CALL");
				outcc((op>>3)&0x07);
				outs(",");
				outjpt(OUT_CALL);
#ifdef Z80
			} else
				outs("?");
#endif
			break;

		case 0xC5:
#ifdef Z280
			if (op&0x08) {
#else
			if ((op&0x08) && am_code==AM_NULL) {
#endif
				if (op==0xCD) {
					outop("CALL");
					outjpt(OUT_CALL);
				} else if (op==0xED) {
					dis_ED();
				} else {
					if(am_code==AM_NULL) {
						if (op==0xDD)
							am_code=AM_DD;
						else
							am_code=AM_FD;
						goto dis_op;
					} else
						outs("?");
				}
#ifdef Z280
			} else if (am_code!=AM_FD || op>=0xE0) {
#else
			} else if (am_code==AM_NULL || op==0xE5) {
#endif
				outop("PUSH");
				outprp((op>>4)&0x03);
			} else
				outs("?");
			break;

		case 0xC6:
			if (am_code==AM_NULL) {
				outop1(op);
				outa(op);
				outn(OUT_N);
			} else
				outs("?");
			break;

		case 0xC7:
			if (am_code==AM_NULL) {
				outop("RST");
				outval(op&0x38,OUT_RST);
			} else
				outs("?");
			break;

		}
		break;

	}
	return(getptr-bytes);
}

static char *tab_CB1[]={
	"RLC",	"RRC",	"RL",	"RR",	"SLA",	"SRA",	"TSET",	"SRL"
};

static char *tab_CB2[]={
	NULL,	"BIT",	"RES",	"SET"
};

static void dis_CB()
{
	word op, off;
	char bit[2];

	if (am_code==AM_NULL)
		op=getbyte();
	else {
		off=getbyte();
		op=getbyte();
		if ((op&0x07)!=6) {
			outs("?");
			return;
		}
	}

#ifdef Z80
	if ((op&0xF8)==0x30) {
		outs("?");
		return;
	}
#endif

	if ((op&0xC0)==0x00)
		outop(tab_CB1[op>>3]);
	else {
		outop(tab_CB2[op>>6]);
		bit[0]='0'+((op>>3)&0x07);
		bit[1]='\0';
		outs(bit);
		outs(",");
	}

	if (am_code==AM_NULL)
		outr(op&0x07);
	else {
		outs("(");
		outihl();
		outval(off,OUT_D);
		outs(")");
	}
}

static void dis_ED()
{
	word op;

	op=getbyte();

	switch (op&0xC7) {

#ifdef Z280

	case 0x02:
		outop("LDA");
		outihl();
		outs(",");
		outea((op>>3)&0x07);
		break;

	case 0x03:
		if (am_code==AM_NULL) {
			outop("LD");
			outea((op>>3)&0x07);
			outs(",A");
		} else
			outs("?");
		break;

	case 0x04:
		outop("LD"W);
		outihl();
		outs(",");
		outea((op>>3)&0x07);
		break;

	case 0x05:
		outop("LD"W);
		outea((op>>3)&0x07);
		outs(",");
		outihl();
		break;

	case 0x06:
		if (op&0x08) {
			outop("LD"W);
			outrp((op>>4)&0x03);
			outs(",");
			outim();
		} else {
			outop("LD"W);
			outim();
			outs(",");
			outrp((op>>4)&0x03);
		}
		break;

	case 0x07:
		if(am_code!=AM_FD || op!=0x3F) {
			outop("EX");
			outs("A,");
			outxr((op>>3)&0x07);
		} else
			outs("?");
		break;

#endif /* Z280 */

	case 0x40:
		if (op==0x70) {
			if (am_code==AM_NULL) {
#ifdef Z280
				outop("TSTI");
				outs("(C)");
#else /* Z80 */
				outop("IN");
				outs("F,(C)");
#endif /* Z280 */
			} else
				outs("?");
		} else if (am_code!=AM_FD || op!=0x78) {
			outop("IN");
			outxr((op>>3)&0x07);
			outs(",(C)");
		} else
			outs("?");
		break;

	case 0x41:
#ifdef Z280
		if (op==0x71) {
			if (am_code==AM_NULL) {
				outop("SC");
				outnn(OUT_NN);
			} else
				outs("?");
		} else if (am_code!=AM_FD || op!=0x79) {
#else /* Z80 */
		if (am_code==AM_NULL && op!=0x71) {
#endif /* Z280 */
			outop("OUT");
			outs("(C),");
			outxr((op>>3)&0x07);
		} else
			outs("?");
		break;

	case 0x42:
		outop( (op&0x08) ? "ADC" : "SBC" );
		outihl();
		outs(",");
		outirp((op>>4)&0x03);
		break;

	case 0x43:
		if (am_code==AM_NULL && (op&0xF7)!=0x63) {
			if (op&0x08) {
				outop("LD"W);
				outrp((op>>4)&0x03);
				outs(",(");
				outnn(OUT_NN);
				outs(")");
			} else {
  				outop("LD"W);
				outs("(");
				outnn(OUT_NN);
				outs("),");
				outrp((op>>4)&0x03);
			}
		} else
			outs("?");
		break;

	case 0x44:
#ifdef Z280
		if (am_code==AM_NULL) {
			switch (op) {

			case 0x44:
				outop("NEG");
				outs("A");
				break;

			case 0x4C:
				outop("NEG");
				outs("HL");
				break;

			case 0x64:
				outop("EXTS");
				outs("A");
				break;

			case 0x6C:
				outop("EXTS");
				outs("HL");
				break;

			default:
				outs("?");
				break;
			
			}
#else /* Z80 */
		if (am_code==AM_NULL && op==0x44) {
			outs("NEG");
#endif /* Z280 */
		} else
			outs("?");
		break;

	case 0x45:
#ifdef Z280
		if (op==0x6D) {
			outop("ADD");
			outihl();
			outs(",A");
		} else {
			if (am_code==AM_NULL) {
				static char *tab[]={
					"RETN",		"RETI",
					"RETIL",	"?",
					"PCACHE",	NULL,
					"?",		"?"
				};
				outop(tab[(op>>3)&0x07]);
			} else
				outs("?");
		}
#else /* Z80 */
		if (am_code==AM_NULL && op==0x45)
			outs("RETN");
		else if (am_code==AM_NULL && op==0x4D)
			outs("RETI");
		else
			outs("?");
#endif /* Z280 */
		break;

	case 0x46:
#ifdef Z280
		if (am_code==AM_NULL && op<0x60 ) {
#else
		if (am_code==AM_NULL && op<0x60 && op!=0x4E) {
#endif
			static char *tab[]={
				"0",	"3",	"1",	"2"
			};
			outop("IM");
			outs(tab[(op>>3)&0x07]);
#ifdef Z280
		} else if (op==0x66) {
			outop("LDCTL");
			outihl();
			outs(",(C)");
		} else if (op==0x6E) {
			outop("LDCTL");
			outs("(C),");
			outihl();
#endif /* Z280 */
		} else
			outs("?");
		break;

	case 0x47:
#ifdef Z280
		if (am_code==AM_NULL) {
#else
		if (am_code==AM_NULL && op<0x70) {
#endif
			static char *tab1[]={
				"LD",	"LD",	"LD",	"LD",
				"RRD",	"RLD",	"DI",	"EI"
			};
			static char *tab2[]={
				"I,A",	"R,A",	"A,I",	"A,R",
				"",	"",	"n",	"n"
			};
			outop(tab1[(op>>3)&0x07]);
			expand(tab2[(op>>3)&0x07]);
		} else
			outs("?");
		break;

	case 0x80:
		if (am_code==AM_NULL) {
			static char *tab[]={
				"?",	"?",	"?",	"?",
				"LDI",	"LDD",	"LDIR",	"LDDR"
			};
			outop(tab[(op>>3)&0x07]);
		} else
			outs("?");
		break;

	case 0x81:
		if (am_code==AM_NULL) {
			static char *tab[]={
				"?",	"?",	"?",	"?",
				"CPI",	"CPD",	"CPIR",	"CPDR"
			};
			outop(tab[(op>>3)&0x07]);
		} else
			outs("?");
		break;

	case 0x82:
		if (am_code==AM_NULL) {
			static char *tab[]={
#ifdef Z280
				"INIW",		"INDW",
				"INIRW",	"INDRW",
#else
				"?",		"?",
				"?",		"?",
#endif
				"INI",		"IND",
				"INIR",		"INDR"
			};
			outop(tab[(op>>3)&0x07]);
		} else
			outs("?");
		break;

	case 0x83:
		if (am_code==AM_NULL) {
			static char *tab[]={
#ifdef Z280
				"OUTIW",	"OUTDW",
				"OTIRW",	"OTDRW",
#else
				"?",		"?",
				"?",		"?",
#endif
				"OUTI",		"OUTD",
				"OTIR",		"OTDR"
			};
			outop(tab[(op>>3)&0x07]);
		} else
			outs("?");
		break;

#ifdef Z280

	case 0x84:
	case 0x85:
		if (am_code==AM_NULL) {
			outop( ((op&0xC7)==0x84) ? "EPUM" : "MEPU" );
			outea((op>>3)&0x07);
			outepu(",");
		} else
			outs("?");
		break;

	case 0x86:
		if (op<0xA0) {
			outop( (op<0x90) ? "LDUD" : "LDUP" );
			if (op&0x08) {
				outim();
				outs(",A");
			} else {
				outs("A,");
				outim();
			}
		} else if (am_code==AM_NULL && (op&0xF7)==0xA6) {
			outop( (op&0x08) ? "MEPU" : "EPUM" );
			outs("(HL)");
			outepu(",");
		} else
			outs("?");
		break;

	case 0x87:
		switch (op) {

		case 0x87:
			outop("LDCTL");
			outihl();
			outs(",USP");
			break;

		case 0x8F:
			outop("LDCTL");
			outs("USP,");
			outihl();
			break;

		case 0x97:
		case 0x9F:
			if (am_code==NULL) {
				outop( (op==0x97) ? "EPUF" : "EPUI" );
				outepu("");
			} else
				outs("?");
			break;

		case 0xA7:
		case 0xAF:
			if (am_code==NULL) {
				outop( (op==0xA7) ? "EPUM" : "MEPU" );
				outs("(");
				outnn(OUT_NN);
				outs(")");
				outepu(",");
			} else
				outs("?");
			break;

		case 0xB7:
			if (am_code==NULL) {
				outop("INW");
				outs("HL,(C)");
			} else
				outs("?");
			break;

		case 0xBF:
			if (am_code==NULL) {
				outop("OUTW");
				outs("(C),HL");
			} else
				outs("?");
			break;

		}
		break;

	case 0xC0:
		outop("MULT");
		outs("A,");
		outxr((op>>3)&0x07);
		break;
			
	case 0xC1:
		outop("MULTU");
		outs("A,");
		outxr((op>>3)&0x07);
		break;

	case 0xC2:
		if (op&0x08) {
			outop("DIVW");
			outs("DEHL,");
		} else {
			outop("MULTW");
			outs("HL,");
		}
		outxrp((op>>4)&0x03);
		break;
			
	case 0xC3:
		if (op&0x08) {
			outop("DIVUW");
			outs("DEHL,");
		} else {
			outop("MULTUW");
			outs("HL,");
		}
		outxrp((op>>4)&0x03);
		break;
			
	case 0xC4:
		outop("DIV");
		outs("HL,");
		outxr((op>>3)&0x07);
		break;
			
	case 0xC5:
		outop("DIVU");
		outs("HL,");
		outxr((op>>3)&0x07);
		break;
			
	case 0xC6:
		outop( (op&0x08) ? "SUBW" : "ADDW" );
		outs("HL,");
		outxrp((op>>4)&0x03);
		break;

	case 0xC7:
		if (am_code==AM_NULL && op==0xEF) {
			outop("EX");
			outs("H,L");
		} else if (op&0x08)
			outs("?");
		else {
			outop("CPW");
			outs("HL,");
			outxrp((op>>4)&0x03);
		}
		break;

#endif /* Z280 */

	default:
		outs("?");
		break;

	}
}

