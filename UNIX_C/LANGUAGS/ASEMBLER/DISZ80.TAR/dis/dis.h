/*
 * dis.h - header file for generic Z80/Z280 disassembler
 *
 * Copyright 1989 by Luc Rooijakkers <lwj@cs.kun.nl>
 * Permission is hereby granted to use and modify this code for
 * non-commercial use, provided this copyright is retained.
 *
 */

/*
 * type definitions
 *
 * word should be at least 16 bits unsigned,
 * byte should be at least 8 bits unsigned
 *
 */

typedef unsigned int word;
typedef unsigned int byte;

/*
 * declarations
 *
 */

#ifdef PROTO

extern int dis(byte *bytes);
extern int jumped;

extern void outs(char *s);
extern void outval(word value,int out);

extern void outsym(word value,int out);
extern void outhex(word value,int out,word addr);
extern void outdebug(word value,int out);

#else /* !PROTO */

extern int dis();
extern int jumped;

extern void outs();
extern void outval();

extern void outsym();
extern void outhex();
extern void outdebug();

#endif /* PROTO */

/*
 * output kinds
 *
 */

#define OUT_N		0	/* 8-bit operand */
#define OUT_NN		1	/* 16-bit operand */
#define OUT_D		2	/* 8-bit IX/IY offset */
#define OUT_DD		3	/* 16-bit HL/SP/IX/IY offset */
#define OUT_PC		4	/* 16-bit PC offset */
#define OUT_INP		5	/* 8-bit input port */
#define OUT_OUTP 	6	/* 8-bit output port */
#define OUT_EPU		7	/* 8-bit EPU operand */
#define OUT_JR		8	/* 16-bit JR offset */
#define OUT_JP		9	/* 16-bit JP target */
#define OUT_CALL	10	/* 16-bit CALL target */
#define OUT_RST		11	/* 16-bit RST target */

