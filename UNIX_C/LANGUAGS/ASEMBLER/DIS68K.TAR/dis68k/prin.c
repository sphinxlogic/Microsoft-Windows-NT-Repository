/*
 *	SCCS:	@(#)prin.c	1.2	11/2/84	14:19:47
 *	Print stuff.
 *
 ***********************************************************************
 *	This software is copyright of
 *
 *		John M Collins
 *		47 Cedarwood Drive
 *		St Albans
 *		Herts, AL4 0DN
 *		England			+44 727 57267
 *
 *	and is released into the public domain on the following conditions:
 *
 *		1.  No free maintenance will be guaranteed.
 *		2.  Nothing may be based on this software without
 *		    acknowledgement, including incorporation of this
 *		    notice.
 *
 *	Notwithstanding the above, the author welcomes correspondence and bug
 *	fixes.
 ***********************************************************************
 */

#include <stdio.h>
#include <a.out.h>
#include "unc.h"

#define	LINELNG	70

void	gette(), getde();
long	gettw(), getdw();
void	prinst();

char	noabs;			/*  No non-global absolutes  */
int	rel;			/*  File being analysed is relocatable  */
int	lpos;

struct	commit	abstab, comtab;

/*
 *	Print absolute and common values.
 */

void	pabs()
{
	register  int	i;
	register  symbol  cs;

	for  (i = 0;  i < abstab.c_int;  i++)
	
	for  (i = 0;  i < abstab.c_int;  i++)  {
		cs = abstab.c_symb[i];
		if  (cs->s_glob)
			(void) printf("\t.globl\t%s\n", cs->s_name);
		else  if  (noabs)
			continue;
		(void) printf("%s\t=\t0x%lx\n", cs->s_name, cs->s_value);
	}
	for  (i = 0;  i < comtab.c_int;  i++)  {
		cs = comtab.c_symb[i];
		(void) printf("\t.comm\t%s,%d\n", cs->s_name, cs->s_value);
	}
}

/*
 *	Print out labels.
 */

void	plabs(ls, seg)
register  symbol  ls;
int	seg;
{
	for  (; ls != NULL;  ls = ls->s_link)  {
		if  (ls->s_type != seg)
			continue;
		if  (ls->s_lsymb)  {
			(void) printf("%u$:\n", ls->s_lsymb);
			return;		/*  Set last  */
		}
		if  (ls->s_glob)
			(void) printf("\n\t.globl\t%s", ls->s_name);
		(void) printf("\n%s:\n", ls->s_name);
	}
}

/*
 *	Print out text.
 */

void	ptext(fid)
register  ef_fid  fid;
{
	register  long	tpos, endt;
	t_entry	tstr;

	(void) printf(".text\n");
	
	tpos = fid->ef_tbase;
	endt = tpos + fid->ef_tsize;
contin:	
	for  (;  tpos < endt;  tpos += tstr.t_lng * 2)  {
		gette(fid, tpos, &tstr);
		plabs(tstr.t_lab, TEXT);
		if  (tstr.t_type == T_BEGIN)
			prinst(&tstr, tpos);
		else  if  (tstr.t_relsymb != NULL)  {
			(void) printf("\t.long\t%s", tstr.t_relsymb->s_name);
			if  (tstr.t_relsymb->s_type!=TEXT &&
				tstr.t_relsymb->s_type!=DATA)
				(void) printf("+0x%x", gettw(fid, tpos, R_LONG));
			putchar('\n');
			tpos += 4;
			goto  contin;
		}
		else
			(void) printf("\t.word\t0x%x\n", tstr.t_contents);
	}

	/*
	 *	Print out any trailing label.
	 */
	
	gette(fid, tpos, &tstr);
	plabs(tstr.t_lab, TEXT);
}

/*
 *	Print out data.
 */

void	pdata(fid)
register  ef_fid  fid;
{
	register  long	dpos, endd;
	register  int	lng;
	unsigned  ctyp;
	int	had, par, inc;
	char	*msg;
	d_entry	dstr;
	
	(void) printf("\n.data\n");
	
	dpos = fid->ef_dbase;
	endd = dpos + fid->ef_dsize;

	while  (dpos < endd)  {
		
		getde(fid, dpos, &dstr);
		plabs(dstr.d_lab, DATA);
			
		switch  (dstr.d_type)  {
		case  D_CONT:
			(void) fprintf(stderr, "Data sync error\n");
			exit(200);
			
		case  D_ASC:
		case  D_ASCZ:
			ctyp = dstr.d_type;
			lng = dstr.d_lng;
			(void) printf("\t.asci");
			if  (ctyp == D_ASC)
				(void) printf("i\t\"");
			else  {
				(void) printf("z\t\"");
				lng--;
			}
				
			while  (lng > 0)  {
				getde(fid, dpos, &dstr);
				switch  (dstr.d_contents)  {
				default:
					if  (dstr.d_contents < ' ' ||
						dstr.d_contents > '~')
						(void) printf("\\%.3o", dstr.d_contents);
					else
						putchar(dstr.d_contents);
					break;
				case  '\"':
				case  '\'':
				case  '\\':
				case  '|':
					(void) printf("\\%c", dstr.d_contents);
					break;
				case  '\b':
					(void) printf("\\b");
					break;
				case  '\n':
					(void) printf("\\n");
					break;
				case  '\r':
					(void) printf("\\r");
					break;
				}
				
				lng--;
				dpos++;
			}
			(void) printf("\"\n");
			if  (ctyp == D_ASCZ)
				dpos++;
			break;

		case  D_BYTE:
			msg = "byte";
			par = R_BYTE;
			inc = 1;
			goto  wrest;
			
		case  D_WORD:
			msg = "word";
			par = R_WORD;
			inc = 2;
			goto  wrest;
			
		case  D_LONG:
			msg = "long";
			par = R_LONG;
			inc = 4;
		wrest:
			(void) printf("\t.%s\t", msg);
			lng = dstr.d_lng;
			lpos = 16;
			had = 0;
			while  (lng > 0)  {
				if  (lpos > LINELNG)  {
					(void) printf("\n\t.%s\t", msg);
					lpos = 16;
				}
				else  if  (had)
					lpos += printf(", ");

				lpos += printf("0x%x", getdw(fid, dpos, par));
				lng -= inc;
				dpos += inc;
				had++;
			}
			putchar('\n');
			break;

		case  D_ADDR:
			(void) printf("\t.long\t");
			lng = dstr.d_lng;
			lpos = 16;
			had = 0;
			while  (lng > 0)  {
				if  (lpos > LINELNG)  {
					(void) printf("\n\t.long\t");
					lpos = 16;
				}
				else  if  (had)
					lpos += printf(", ");

				getde(fid, dpos, &dstr);
				lpos += printf("%s", dstr.d_relsymb->s_name);
				lng -= sizeof(long);
				dpos += sizeof(long);
				had++;
			}
			putchar('\n');
			break;
		}
	}
	
	/*
	 *	Print trailing label.
	 */
	
	getde(fid, dpos, &dstr);
	plabs(dstr.d_lab, DATA);
}

void	pbss(fid)
register  ef_fid  fid;
{
	register  long	bpos = fid->ef_bbase;
	long	endb = fid->ef_end;
	d_entry	bstr;
	
	(void) printf("\n.bss\n");
	
	while  (bpos < endb)  {
		getde(fid, bpos, &bstr);
		plabs(bstr.d_lab, BSS);
		(void) printf("\t.space\t%d\n", bstr.d_lng);
		bpos += bstr.d_lng;
	}
	
	getde(fid, endb, &bstr);
	plabs(bstr.d_lab, BSS);
}
