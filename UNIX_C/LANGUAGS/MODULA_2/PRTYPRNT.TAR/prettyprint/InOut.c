#include	<stdio.h>

int InOut_Done	= 0;

InOut__init()
{
	InOut_Done = 0;
}

InOut_Read(c)
	char	*c;
{
	register char	ch;

	if ((ch = getchar()) == EOF)
		InOut_Done = 1;
	else
		*c = ch & 0177;
}

InOut_Write(c)
	char	c;
{
	putchar(c);
}

InOut_WriteLn()
{
	putchar('\n');
}

InOut_WriteString(s, l)
	char	*s;
	int	l;
{
	while (l-- > 0)
		putchar(*s++);
}
