/* messages for help screen */

char	*helpmsg[] = {
	"Key Commands:\n",
	"i\tmove north",
	"j\t     west",
	"k\t     east",
	"m\t     south\n",
	"I\tplace Karel facing north",
	"J\t                   west",
	"K\t                   east",
	"M\t                   south\n",
	"o\tplace wall section",
	"q\tquit",
	"s\tsave screen",
	"S\tsave snapshot\n",
	"*\tplace beeper",
	"?\tprint this screen",
	"return\trun program",
	"space\terase an object\n",
	0
};
