/*
	Little Smalltalk, version 2
	Written by Tim Budd, Oregon State University, July 1987

	unix specific driver (front-end) for bytecode interpreter.
*/
# include <stdio.h>

# include "env.h"
# include "memory.h"
# include "names.h"
# include "interp.h"
# include "process.h"

# ifdef STRING
# include <string.h>
# endif
# ifdef STRINGS
# include <strings.h>
# endif
# ifdef SIGNALS
# include <signal.h>
# include <setjmp.h>
jmp_buf intenv;
# endif
# ifdef SSIGNALS
# include <signal.h>
# include <setjmp.h>
jmp_buf intenv;
# endif

extern int processStackTop;
extern object processStack[];

# ifdef SIGNALS
brkfun() { longjmp(intenv, 1); }
# endif
# ifdef SSIGNALS
brkfun() { longjmp(intenv, 1); }
# endif

main(argc, argv) 
int argc;
char **argv;
{
FILE *fp;
char fileName[120];

initMemoryManager();

if ((argc == 1) || ((argc > 1) && streq(argv[1],"-"))){
# ifdef BINREADWRITE
	fp = fopen(INITIALIMAGE,"rb");
# endif
# ifndef BINREADWRITE
	fp = fopen(INITIALIMAGE,"r");
# endif
	if (fp == NULL)
		sysError("cannot read image file",INITIALIMAGE);
	}
else {
# ifdef BINREADWRITE
	fp = fopen(argv[1], "rb");
# endif
# ifndef BINREADWRITE
	fp = fopen(argv[1], "r");
# endif
	if (fp == NULL)
		sysError("cannot read image file", argv[1]);
	}
imageRead(fp);
ignore fclose(fp);

initCommonSymbols();

ignore fprintf(stderr,"initially %d objects\n", objcount());

/* now we are ready to start */

# ifdef SIGNALS
ignore signal(SIGINT, brkfun);
ignore setjmp(intenv);
# endif
# ifdef SSIGNALS
ignore ssignal(SIGINT, brkfun);
ignore setjmp(intenv);
# endif

prpush(smallobj);
sendMessage(newSymbol("commandLoop"), getClass(smallobj), 0);
flushstack();

ignore fprintf(stderr,"finally %d objects\n", objcount());

if (argc > 2) {
	if (streq(argv[2],"-"))
		ignore strcpy(fileName, INITIALIMAGE);
	else
		ignore strcpy(fileName, argv[2]);
# ifdef BINREADWRITE
	fp = fopen(fileName,"wb");
# endif
# ifndef BINREADWRITE
	fp = fopen(fileName,"w");
# endif
	if (fp == NULL)
		sysError("cannot write image file",fileName);
	else {
		ignore fprintf(stderr,"creating image file %s\n", fileName);
		imageWrite(fp);
		ignore fclose(fp);
		}
	}
exit(0);
}
