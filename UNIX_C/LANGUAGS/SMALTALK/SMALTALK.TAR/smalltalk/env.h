/*
	Little Smalltalk, version two
	Written by Tim Budd, Oregon State University, July 1987

	environmental factors

	This include file gathers together environmental factors that
	are likely to change from one C compiler to another, or from
	one system to another.  Please refer to the installation 
	notes for more information.
*/

/* ### the following two define statements should be edit to conform
to your specific system, and should be the only changes most installations
need to make ### */

/*============= define the kind of system you are on ===========*/

# define B42

# define INITIALIMAGE "imageFile"
 
/*=============== rules for various systems ====================*/

# ifdef B42
	/* Berkeley 4.2, 4.3 and compatible, which include: */
		/* sequent balance */
		/* Harris HCX-7 */
		/* sun workstations */

typedef unsigned char byte;

# define byteToInt(b) (b)

# define longCanBeInt(l) (l == (l & 037777))

# define STRINGS
# define SIGNALS

# endif

# ifdef SYSV
	/* system V systems including: */
	/*	HP-UX for the HP-9000 series */
	/* 	TEK 4404 with some modifications (see install.ms) */

typedef unsigned char byte;

# define byteToInt(b) (b)

# define longCanBeInt(l) (l == (l & 037777))

# define STRING
# define SIGNALS

# endif

# ifdef TURBOC
	/* IBM PC and compatiables using the TURBO C compiler */
	
	/* there are also changes that have to be made to the 
		smalltalk source; see installation notes for
		details */

typedef unsigned char byte;

# define byteToInt(b) (b)

# define longCanBeInt(l) (l == (l & 037777))

# define STRING
# define SSIGNALS
# define ALLOC
# define BINREADWRITE
# define PROTO

#endif

/* ======== various defines that should work on all systems ==== */

# define true 1
# define false 0

	/* define the datatype boolean */
# ifdef NOTYPEDEF
# define boolean int
# endif
# ifndef NOTYPEDEF
typedef int boolean;
# endif

	/* define a bit of lint silencing */
	/*  ignore means ``i know this function returns something,
		but I really, really do mean to ignore it */
# ifdef NOVOID
# define ignore
# define noreturn
# define void int
# endif
# ifndef NOVOID
# define ignore (void)
# define noreturn void
# endif

/* prototypes are another problem.  If they are available, they should be
used; but if they are not available their use will cause compiler errors.
To get around this we define a lot of symbols which become nothing if
prototypes aren't available */
# ifdef PROTO

# define X ,
# define OBJ object
# define OBJP object *
# define INT int
# define BOOL boolean
# define STR char *
# define FLOAT double
# define NOARGS void
# define FILEP FILE *

# endif

# ifndef PROTO

# define X
# define OBJ
# define OBJP
# define INT
# define BOOL
# define STR
# define FLOAT
# define NOARGS
# define FILEP

# endif
