/*
	Little Smalltalk, version 2
	Written by Tim Budd, Oregon State University, July 1987

	Unix specific front end for the initial object image maker
	(parse utility)
*/

# include <stdio.h>
# include "env.h"
# include "memory.h"
# include "names.h"

main(argc, argv) 
int argc;
char **argv;
{ FILE *fp;
	int i;
	boolean printit = true;

	initMemoryManager();

	buildInitialNameTables();

	if (argc == 1)
		readFile(stdin, printit);
	else
		for (i = 1; i < argc; i++) {
			if (argv[i][0] == '-') {
				switch(argv[i][1]) {
					case 's': printit = false; break;
					case 'v': printit = true; break;
					}
				}
			else {
				fp = fopen(argv[i], "r");
				if (fp == NULL) {
					ignore fprintf(stderr,
						"can't open file %s", argv[i]);
					exit(1);
					}
				else {
					readFile(fp, printit);
					ignore fclose(fp);
					}
				}
			}

# ifndef BINREADWRITE
	fp = fopen(INITIALIMAGE, "w");
# endif
# ifdef BINREADWRITE
	fp = fopen(INITIALIMAGE, "wb");
# endif
	if (fp == NULL) sysError("error during image file open",INITIALIMAGE);
	imageWrite(fp);
	ignore fclose(fp);
	exit(0);
}
