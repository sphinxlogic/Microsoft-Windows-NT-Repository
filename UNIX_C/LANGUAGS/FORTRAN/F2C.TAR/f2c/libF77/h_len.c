#include "f2c.h"

extern integer s_cmp();

shortint h_len(s, n)
char *s;
long int n;
{
return(n);
}
