#include "f2c.h"

double erfc_(x)
real *x;
{
double erfc();

return( erfc(*x) );
}
