#include "f2c.h"

double d_prod(x,y)
real *x, *y;
{
return( (*x) * (*y) );
}
