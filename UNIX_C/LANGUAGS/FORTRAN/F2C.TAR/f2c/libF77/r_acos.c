#include "f2c.h"

double r_acos(x)
real *x;
{
double acos();
return( acos(*x) );
}
