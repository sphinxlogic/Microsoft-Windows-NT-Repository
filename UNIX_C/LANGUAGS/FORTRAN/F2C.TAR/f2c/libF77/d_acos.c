#include "f2c.h"

double d_acos(x)
doublereal *x;
{
double acos();
return( acos(*x) );
}
