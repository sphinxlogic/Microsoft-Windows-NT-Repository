#include "f2c.h"

integer i_mod(a,b)
integer *a, *b;
{
return( *a % *b);
}
