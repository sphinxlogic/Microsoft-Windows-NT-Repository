char F2C_version[] = "15 October 1990  19:58:17";
char xxxvers[] = "\n@(#) FORTRAN 77 to C Translator, VERSION 15 October 1990  19:58:17\n";
