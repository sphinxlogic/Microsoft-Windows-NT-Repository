*IF DEF,NEVER   
*-----------------------------------------------------------------------
*   NGCON   = number of variables in all COMMON blocks all ROUTINES 
*   NGCOT   = number of COMMON block titles all ROUTINES
*   SGCNAM  = name of variable I
*   SGCTIT  = name of COMMON block J
*   IGCNAM  = pointer to J for name I   
*   IGCTIT  = -(pointer to start of names in SGCNAM for COMMON block J) 
*-----------------------------------------------------------------------
*EI 
