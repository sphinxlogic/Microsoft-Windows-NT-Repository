      COMMON/TYPDEF/KVTYPE(26)  
*IF DEF,NEVER   
*-----------------------------------------------------------------------
*   
*   KVTYPE(I)          current default type for starting character no. I
*-----------------------------------------------------------------------
*EI 
