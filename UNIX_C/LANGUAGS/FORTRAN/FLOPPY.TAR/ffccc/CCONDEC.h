*IF DEF,NEVER   
*-----------------------------------------------------------------------
*---  SBASE   = list of all ccharacters recognized by FLOP. 
*+++ warning +++ : '{', and '}' are forbidden for users.
*---  SPCHAR  = list of string replacement characters in flop.  
*-----------------------------------------------------------------------
*EI 
