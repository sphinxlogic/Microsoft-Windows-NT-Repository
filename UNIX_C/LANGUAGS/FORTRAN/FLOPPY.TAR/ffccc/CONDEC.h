      LOGICAL SPECCH,NUMCH,ALPHCH,ANUMCH,STRGCH 
      CHARACTER SBASE*91,SPCHAR*7,SPILL*2,SDUMMY*1  
*IF DEF,NEVER   
*-----------------------------------------------------------------------
*---  SBASE   = list of all ccharacters recognized by FLOP. 
*+++ warning +++ : '{', and '}' are forbidden for users.
*---  SPCHAR  = list of string replacement characters in flop.  
*-----------------------------------------------------------------------
*EI 
