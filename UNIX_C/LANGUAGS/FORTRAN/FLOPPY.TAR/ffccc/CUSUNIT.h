*IF DEF,NEVER   
*-----------------------------------------------------------------------
*   MZUNIT  = logical unit of scratch file  
*   MJUNIT  = logical unit for customized TREE output   
*   MSUNIT  = logical unit for specification of rules   
*-----------------------------------------------------------------------
*EI 
