      COMMON/FLWORK/IWS(MXNAME) 
*IF DEF,NEVER   
*--- IWS    = working space 
*EI 
