*IF DEF,NEVER   
*-----------------------------------------------------------------------
*   
*   CALLER             calling routiine, or entry in it 
*   CALLED             called routine or function   
*   CERARG             argument types of caller 
*   CEDARG             argument types of called 
*   KODE               type of caller or entry (S/R = blank)
*   NCALLR             # of callers in this routine 
*   NCALLD             # of called in this routine  
*   ICALLR             statement number of CALL 
*-----------------------------------------------------------------------
*EI 
