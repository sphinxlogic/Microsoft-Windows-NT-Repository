*IF DEF,NEVER   
C                            FLOPPY 
C                            ------ 
C Implementation in FLOP of Fortran Coding Convention Checking  
C   
C J.J.Bunn December 1985
C Version 5 December 1986 for general release   
C   
*EI 
