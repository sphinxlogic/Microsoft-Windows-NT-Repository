*IF DEF,NEVER   
*-----------------------------------------------------------------------
*   NARGS   = number of arguments passed to current module  
*   CARGNMi = name of argument i
*   CARGTYi = type of argument i (EG CHAR80, INTE2) 
*   NARGDIi = number of dimensions of argument i
*   CARGDIji= 1) lower bound for jth. dimension of argument i   
*             2) upper bound for jth. dimension of argument i   
*   NKALL   = number of CALL statements in module   
*   CKALLNi = name of subroutine ith. CALLed
*   KALLIFi = IF level of ith. subroutine CALLed
*   KALLDOi = DO level of ith. subroutine CALLed
*-----------------------------------------------------------------------
*EI 
