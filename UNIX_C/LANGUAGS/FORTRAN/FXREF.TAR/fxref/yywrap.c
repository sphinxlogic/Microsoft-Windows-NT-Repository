yywrap() {		/* required for all LEX programs without -ll */
	return(1);	/* cf. section 9 of Lesk & Schmidt */
}			/* if -ll is available, this comes later */
