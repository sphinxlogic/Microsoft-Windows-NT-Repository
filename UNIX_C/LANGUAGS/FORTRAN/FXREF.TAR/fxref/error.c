#include <stdio.h>
#include <ctype.h>
extern char *progname;
#define PROG	if(progname)fprintf(stderr,"%s: ",progname)
/* This is the original version:
extern int errno, sys_nerr;
extern char *sys_errlist[];
#define DIE	if(errno>0&&errno<sys_nerr)fprintf(stderr," (%s)",sys_errlist[errno]);fprintf(stderr,"\n");exit(1)
*/
#define DIE	fprintf(stderr,"\007\n");exit(1)

error_(s) /* print error message and die -- from K&P p. 207 */
char *s;
{
	PROG;
	fprintf(stderr, s);
	DIE;
}
errord(s, d)
char *s;
int d;
{
	PROG;
	fprintf(stderr, s, d);
	DIE;
}
errors(s1, s2)
char *s1, *s2;
{
	PROG;
	fprintf(stderr, s1, s2);
	DIE;
}
