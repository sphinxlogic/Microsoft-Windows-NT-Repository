/* second part of f77 xref program.  Developed from Bourne p. 207 */
#include <stdio.h>
static char SCCSID[] = "@(#)fxrefb.c	Ver. 2.4, 88/08/08 15:53:37";
#define MAXW 256
char	lastw[MAXW]; /* last word read */
char	lastc;

main(argc,argv)
	int argc;
	char *argv[];
{
	char f1[MAXW], f2[MAXW];
	char first=0;
	int width, col=0;

	switch(argc) {
	case 1:
		width=80; /* default */
		break;
	case 2:
		if(sscanf(argv[1], "-w%d", &width) == 1) {
			width = 5 * (width / 5);
			break;
		}
	default:
		printf("%s: illegal argument\n", argv[0]);
		exit(1);
	}
	f1[0]=0;
	f2[0]=0;

	printf("\t\t\tFlags mean:\n");
	printf("h\tprogram unit header  \t");
	printf("p\tPARAMETER definition \n");
	printf("c\tCOMMON statement     \t");
	printf("~\tEQUIVALENCE          \n");
	printf("d\tDIMENSION statement  \t");
	printf("$\tCHARACTER declaration\n");
	printf("L\tLOGICAL declaration  \t");
	printf("%%\tINTEGER declaration  \n");
	printf("!\tREAL declaration     \t");
	printf("#\tDOUBLE PRECISION declaration\n");
	printf("C\tCOMPLEX declaration  \t");
	printf("i\tDATA initialization  \n");
	printf("x\tEXTERNAL             \t");
	printf("@\tCALL                 \n");
	printf("D\tDO loop control      \t");
	printf("?\tIF test              \n");
	printf("=\tassignment statement \t");
	printf("o\tOPEN statement       \n");
	printf("<\tinput                \t");
	printf(">\toutput               \n");

	while(word() != EOF) {
		if(lastw[0] != first) {
			first = lastw[0];
			printf("\n");
			col=0;
		}
		if(col >= width) {
			printf("\n                    ");
			col=20;
		}
		if(strcmp(lastw, f1) == 0) {
			word();
			if( ! strcmp(lastw, f2) == 0) {
				printf("\n          %-10s", lastw);
				col=20;
				strcpy(f2, lastw);
			}
		}
		else {
			strcpy(f1, lastw);
			printf("\n%-10s", f1);
			col=10;
			word();
			strcpy(f2, lastw);
			printf("%-10s", f2);
			col += 10;
		}
		if(lastc != '\n') {
			word();
			printf("%5s", lastw);
			col += 5;
		}
		lastc = 0;
	}
	printf("\n");
	exit(0);
}

int word()
{
	register char *p=lastw;
	register int c;

	if(lastc != '\n') {
		while((c = getchar()) != '\t' && c != '\n' && c != EOF) {
			if(p < &lastw[MAXW])
				*p++ = c;
		}
		lastc=c;
	}
	*p++ = 0;
	return(lastc);
}
