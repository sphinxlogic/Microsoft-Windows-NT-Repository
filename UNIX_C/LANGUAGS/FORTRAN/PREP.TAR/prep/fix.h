: .eq.		==;	file for imbedding a few macros in a fortran program
: .ge.		>=;
: .gt.		>;	to use do:  prep -m -i fix.h <file >output
: .lt.		<;
: .le.		<=;
: .ne.		!=;
: **		^;
: .and.		&;
: .or.		|;
: .not.		!;
: .true.	TRUE;
: .false.	FALSE;

