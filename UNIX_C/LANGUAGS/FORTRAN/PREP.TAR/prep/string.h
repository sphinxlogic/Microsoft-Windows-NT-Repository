/*	@(#)strings.h 1.1 85/12/18 SMI; from UCB 4.1 83/05/26	*/

/*
 * External function definitions
 * for routines described in string(3).
 */
char	*strcat();
char	*strncat();
int	strcmp();
int	strncmp();
char	*strcpy();
char	*strncpy();
int	strlen();
char	*index();
char	*rindex();
char	*strchr();
int	strspn();
int	strcspn();
