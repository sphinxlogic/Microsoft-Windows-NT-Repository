/* macro related stuff */

#include "prep.h"

#define	MAX_MACROS		1000
#define MAX_CALLS		100	/* if exceeded, assume recursive */


/* macro structure */
struct mac {
	char	*name ;
	char	*text ;
	int	parmcount ;
	int	callcount ;
} macro[MAX_MACROS], *macrop ;

int	defined_macros = 0 ;	/* number of defined macros */


/* function types */
char	*expand_macros(), *mac_expand(), *strmatch() ;
int	define_macro() ;

