c Some standard macros for prep.

c logical stuff
: ==	.eq. ;
: >=	.ge. ;
: >	.gt. ;
: <	.lt. ;
: <=	.le. ;
: !=	.ne. ;
: <>	.ne. ;
: !	.not. ;
: |	.or. ;
: &	.and. ;
: TRUE	.true. ;
: FALSE	.false. ;
: ^	** ;

c flow control redefinitions
: enddo		end_do ;
: ->begin	continue ;
: ->case	continue_case ;
: ->do		continue_do ;
