#ifdef	MAIN
/*
	Included stuff for main routine of program PREP
*/

#include "stdio.h"
#include "string.h"
#include "prepdf.h"

/* global pointers & storage */
char	*in_buff, *out_buff ;		/* text buffer pointers */
char	*phys_ibuff ;			/* physical input buffer */
char	*phys_obuff ;			/* physical output buffer */
char	*mem_store[STORE_SIZE] ;	/* pointers to malloc areas */
char	*initial_name[NESTING] ;	/* do loop initial values */
char	*limit_name[NESTING] ;		/* do loop limits */
char	*increment_name[NESTING] ;	/* do loop increments */
char	*case_exp[NESTING] ;		/* case expression storage */
char	*exp ;				/* general expression storage pointer */
char	*first_nonblank ;		/* first nb char in in_buff */
char	label[NESTING][6] ;		/* label storage (vector loops) */
char	alabel[NESTING][6] ;		/* again label storage */
char	blabel[NESTING][6] ;		/* begin label storage */
char	clabel[NESTING][6] ;		/* case label storage */
char	dlabel[NESTING][6] ;		/* do/end_do label storage */
char	elabel[NESTING][6] ;		/* leave_do label storage */
char	var_name[NESTING][6] ;		/* do counter names */
char	dataf[DEF_BUFFSIZE] ;		/* data file name */
char	errline[2*DEF_BUFFSIZE] ;	/* error message line */

long	allocation ;          /* current size of in_buff */
int	of_count[NESTING] ;   /* counters for of statements */
int	leave_do_flag[NESTING] ;   /* marks if leave_do in current loop */
int	var_count = 0 ;       /* number of variables used in do loops */
int	label_count = 0 ;     /* label = label_count + 10000 */
int	alabel_count = 0 ;    /* alabel = alabel_count + 15000 */
int	blabel_count = 0 ;    /* blabel = blabel_count + 17500 */
int	clabel_count = 0 ;    /* clabel = clabel_count + 20000 */
int	dlabel_count = 0 ;    /* dlabel = dlabel_count + 12500 */
int	elabel_count = 0 ;    /* elabel = elabel_count + 22500 */
int	do_count = 0 ;        /* nesting counter for do/end_do */
int	begin_count = 0 ;     /* nesting counter for begin ... loops */
int	case_count = 0 ;      /* case nesting level */
int	tab_size = 7 ;        /* size of the tab in blanks */
int	unroll_depth = 0 ;    /* do loop unroll depth, 0 for no unrolling */
int	line_limit = 1000 ;   /* unroll loops if # lines <= line_limit */
int	mem_count = 0 ;       /* mem_store external counter */
int	include_count = 0 ;   /* index of filestack (for includes) */
int	name_length = 0 ;     /* current command name length */
int	vec_flag = FALSE ;    /* TRUE if in vector loop */
int	com_keep = FALSE ;    /* TRUE to keep comments */
int	underline_keep=FALSE; /* TRUE to keep underline characters */
int	macro_only = FALSE ;  /* TRUE to do only macro expansion */

FILE	*in, *out, *filestack[NESTING] ;

/* function declarations */
char	*get_rec(), *mac_proc(), *malloc(), *realloc() ;


#else

/* Header file for the functions of program PREP */

#include "stdio.h"
#include "string.h"
#include "prepdf.h"

/* global pointers & storage */
extern char	*in_buff, *out_buff, *phys_ibuff, *phys_obuff,
		*mem_store[],
		*initial_name[], *limit_name[], *increment_name[],
		*case_exp[], *exp, *first_nonblank,
		label[][6],
		alabel[][6], blabel[][6], clabel[][6], dlabel[][6], elabel[][6],
		var_name[][6],
		dataf[], errline[] ;

extern int	var_count, tab_size, unroll_depth, line_limit,
		com_keep, vec_flag, label_count,
		alabel_count, blabel_count, clabel_count,
		dlabel_count, elabel_count,
		case_count, of_count[], do_count, begin_count,
		mem_count, underline_keep, include_count, macro_only,
		name_length, leave_do_flag[] ;

extern long	allocation ;

extern	FILE	*in, *out, *filestack[] ;

/* function type declarations */
char		*mat_del(), *line_end(), *get_rec(), get_a_char(),
		*malloc(), *calloc(), *realloc(), *strtokp(),
		*mac_proc(), *strupr() ;

#endif

