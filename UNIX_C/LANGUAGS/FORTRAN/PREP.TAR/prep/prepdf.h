/* #define CRAY			1 */

#define BLANK			' '
#define TAB			'\t'
#define TRUE			1
#define FALSE			0
#define	NOT			!
#define	DEF_UNROLL_DEPTH	8
#define	DEF_LINE_LIMIT		1
#define DEF_BUFFSIZE		200
#define PHYS_IBUFF_SIZE		10000
#define PHYS_OBUFF_SIZE		0	/* not used, uses sys output buffer */
#define	STORE_SIZE		1000
#define	NESTING			10
#define	MAX_TOKENS		2*NESTING	/* tokens and macro args */
#define exp			expression	/* used exp as a variable */

#define	IN_BUFF_DONE		in_buff[0] = NULL ;

#define IN_BUFF_FULL		line_end( in_buff ) != NULL

#define	UNROLLING		( ( unroll_depth >  1          ) && \
				  ( mem_count    <= line_limit ) && \
				  ( var_count    >  1          ) )

#define	GET_MEM(S,A)\
if ( NULL == (S = malloc(A+1)) ) {\
	abort( "Memory allocation failed") ; }

#define MATCH(S)	( strncmp( combuff, S, (name_length=strlen(S)) ) == 0 )

#define put_string(s)	fputs( s, out ) ; putc( '\n', out ) ;


/* enumeration of command types, by hand because of svs c enum bug */
#define	type_begin	 0
#define	type_again	 1
#define	type_while	 2
#define	type_until	 3
#define	type_leave	 4
#define	type_case	 5
#define	type_of		 6
#define	type_default	 7
#define	type_end_case	 8
#define	type_do_limits	 9
#define	type_do		 10
#define	type_end_do	 11
#define	type_osqb	 12
#define	type_csqb	 13
#define	type_vec	 14
#define	type_unroll	 15
#define	type_continue	 16
#define	type_leave_do	 17
#define	type_continue_do 18
#define type_continue_case 19
#define	normal		 20
#define type_include     21
#define	unknown		 22 


 
#ifdef CRAY

/* the cray considers characters to be unsigned */
#undef	EOF
#define EOF	255

/* a few macros to adapt to cray namelength limitations */
#define continue_proc		cont_proc
#define continue_do_proc	cont_do_proc
#define leave_do_proc		le_do_proc
#define include_proc		inc_proc

#endif
