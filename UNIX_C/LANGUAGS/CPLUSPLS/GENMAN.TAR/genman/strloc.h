//------------------------------------------------------------
//
//			strloc.h
//
// Purpose:
//	Defines the strloc class.

// .NAME strloc - class to manage strings
// .LIBRARY Base
// .HEADER base utilities
// .INCLUDE base/strloc.h
// .FILE strloc.cxx
// .FILE strloc.h

#ifndef UTIL_STRLOC_H
#define UTIL_STRLOC_H

#ifndef STRINGS_HXX
#include <strings.hxx>
#endif

struct strloc_data {
    char *std_ptr;      // pointer to string
    int   std_refcnt;   // reference count
};

class strloc
    {
private:
    strloc_data *st_com;
    // Pointer to character string struct.

public:
    strloc( const char *str= 0 );
    strloc( strloc & );
    ~strloc();
    strloc & operator=( strloc & );
    strloc & operator=( const char * );
    void operator+=( const char * );
    const char *ptr();
    int len();
    friend int operator==( const strloc &x, const char *s );
    friend int operator==( const char *s, const strloc &x );
    friend int operator==( const strloc &x, const strloc &y );
    friend int operator!=( const strloc &x, const char *s );
    friend int operator!=( const char *s, const strloc &x );
    friend int operator!=( const strloc &x, const strloc &y );
    };

// .SECTION Description
// The strloc class is a class for managing strings.
// It uses reference counts on copy operations.

// .SECTION See Also
// strings(3)

// Description:
//  Returns the pointer to the string.
inline const char *strloc::ptr()
    { return st_com->std_ptr; }

// Description:
//  Returns the length of the string.
inline int strloc::len()
    { return strlen( st_com->std_ptr ); }

inline int operator==( const strloc &x, const char *s )
    { return strcmp( x.st_com->std_ptr, s ) == 0; }

inline int operator==( const char *s, const strloc &x )
    { return strcmp( x.st_com->std_ptr, s ) == 0; }

// Description:
// Returns 1 if the two strings are equal, 0 if not.
inline int operator==( const strloc &x, const strloc &y )
    { return strcmp( x.st_com->std_ptr, y.st_com->std_ptr ) == 0; }

inline int operator!=( const strloc &x, const char *s )
    { return strcmp( x.st_com->std_ptr, s ) != 0; }

inline int operator!=( const char *s, const strloc &x )
    { return strcmp( x.st_com->std_ptr, s ) != 0; }

// Description:
// Returns 1 if the two strings are not equal, 0 if equal.
inline int operator!=( const strloc &x, const strloc &y )
    { return strcmp( x.st_com->std_ptr, y.st_com->std_ptr ) != 0; }

#endif /* UTIL_STRLOC_H */
