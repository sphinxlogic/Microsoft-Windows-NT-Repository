//------------------------------------------------------------
//
//			strloc.cxx
//
// Purpose:
//	Implements the strloc class

#include <string.h>
#include <util/list.h>
#include <util/strloc.h>

//------------------------------------------------------------
//
//            strloc
//
// Description:
//    Normal constructor.
// Arguments:
//    Passed a pointer to a character string it copies it
//    to new memory and sets the reference count to 1.

strloc::strloc( const char *newstr )
    {
    // get a structure to hold the string pointer and ref count
    st_com= new strloc_data;
    st_com->std_refcnt= 1;

    if( newstr == 0 )
        newstr= "";

    // get the length of the string
    int len= strlen( newstr ) +1;

    // get some space for the string
    st_com->std_ptr= new char[len];

    // copy the data
    strcpy( st_com->std_ptr, newstr );
    }

//------------------------------------------------------------
//
//            strloc
//
// Description:
//    Constructor called when strloc a= b.
// Arguments:
//    "this" is "a" and "orig" is a pointer to "b".

strloc::strloc( strloc &orig )
    {
    // have "a" point to the same string structure as "b"
    st_com= orig.st_com;

    // update the reference count
    st_com->std_refcnt += 1;
    }

//------------------------------------------------------------
//
//            ~strloc
//
// Description:
//    Destructor for the strloc class.
//    The refernce count is decrimented and when it goes to
//    zero the string is deleted.

strloc::~strloc()
    {
    // decriment the reference count
    st_com->std_refcnt -= 1;

    // see if nothing else pointing to the string
    if( st_com->std_refcnt == 0 )
        {
        delete st_com->std_ptr;    // delete the string
        delete st_com;             // delete the string structure
        }
    }

//------------------------------------------------------------
//
//            operator=
//
// Description:
//    Implements copy function.
//    Frees up old string and copies a pointer to the new one.
// Arguments:

strloc & strloc::operator=( strloc &rvalue )
    {
    // incriment the source string reference count
    rvalue.st_com->std_refcnt += 1;

    // decriment the orig reference count
    st_com->std_refcnt -= 1;

    // see if nothing else pointing to the string
    if( st_com->std_refcnt == 0 )
        {
        delete st_com->std_ptr;    // delete the string
        delete st_com;             // delete the string structure
        }

    // point this to the rvalue string structure
    st_com= rvalue.st_com;

    return *this;
    }

//------------------------------------------------------------
//
//            operator=
//
// Description:
//    Implements set function: strloc a; a= "foo";
//    Frees up old string and copies a pointer to the new one.

strloc & strloc::operator=( const char *newstr )
    {
    // decriment the orig reference count
    st_com->std_refcnt -= 1;

    // see if nothing else pointing to the string
    if( st_com->std_refcnt == 0 )
        {
        delete st_com->std_ptr;    // delete the string
        delete st_com;             // delete the string structure
        }

    // get a structure to hold the string pointer and ref count
    st_com= new strloc_data;
    st_com->std_refcnt= 1;

    if( newstr == 0 )
        newstr= "";

    // get the length of the string
    int len= strlen( newstr ) +1;

    // get some space for the string
    st_com->std_ptr= new char[len];

    // copy the data
    strcpy( st_com->std_ptr, newstr );

    return *this;
    }

//-----------------------------------------------------------
//
//                    operator+=
//
// Description:
//  Appends the specified string onto the end of the current string.

void strloc::operator+=( const char *string )
    {
    // just return if no string specified
    if( (string == NULL) || (*string == '\0') )
        return;

    // determine the length of the new string
    int len= strlen( st_com->std_ptr ) + strlen( string ) +1;

    // get some space for the string
    char *ptr= new char[len];

    // copy the data
    strcpy( ptr, st_com->std_ptr );
    strcat( ptr, string );

    // delete the original data
    delete st_com->std_ptr;

    // save the pointer to the new data
    st_com->std_ptr= ptr;
    }
