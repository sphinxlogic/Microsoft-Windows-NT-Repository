#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>

main( argc, argv )
int argc;
char **argv;
    {
    struct stat st;
    char *pc;
    char buf[30];

    if( argc != 2 )
	{
        printf( "usage\n" );
	exit(-1);
	}
    if( stat( argv[1], &st ) != 0 )
	{
	perror( argv[1] );
	exit(-1);
	}
    pc= asctime( localtime( &st.st_mtime ) );
    if( pc != NULL )
	{
	strcpy( &buf[0], pc+4 );
	buf[6]= ',';
	strcpy( &buf[7], pc+19 );
	printf( "%s", buf );
	}
    else
        printf( "asctime" );
    fflush( stdout );
    exit(0);
    }
