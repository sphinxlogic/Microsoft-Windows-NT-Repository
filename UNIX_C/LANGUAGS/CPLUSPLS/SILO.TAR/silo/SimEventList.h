/* $Author: ecsv38 $ $Date: 90/08/21 14:46:43 $ $Revision: 1.1 $ */
/* (c) S. Manoharan  sam@lfcs.edinburgh.ac.uk */

#ifndef SimEventList_H
#define SimEventList_H

#include "Event.h"

class SimEventList;

class SimEventItem {
   friend class SimEventList;
private:
   SimEventItem *next;
   SimEventItem *prev;
   Event * event;

   SimEventItem(Event *const v = 0)
		{ event = v; next = prev = 0; }
};

class SimEventList {
private:
   SimEventItem *head;
   SimEventItem *tail;
   char *listname;
public:
   SimEventList(char *const s = 0)
		{ head = tail = 0; listname = s; }
   SimEventList(Event *const event, char *const s)
		{ head = new SimEventItem(event); listname = s; }
   virtual ~SimEventList();

   void name(char *const s)	{ listname = s; }
   char *name() const		{ return listname; }
   short is_empty()		{ return head == 0; }
   void print();

   int min_event_id();
   int max_event_id();

   Event *get()			{ return remove(min_event_id()); }
   Event *remove(const int eid);
   Event *remove(Entity *const ent);

   void insert(Event *const);
   void append(Event *const);
};



#endif SimEventList_H
