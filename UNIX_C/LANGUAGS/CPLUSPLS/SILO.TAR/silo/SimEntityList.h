/* $Author: ecsv38 $ $Date: 90/08/21 14:46:36 $ $Revision: 1.1 $ */
/* (c) S. Manoharan  sam@lfcs.edinburgh.ac.uk */

#ifndef SimEntityList_H
#define SimEntityList_H

#include "Entity.h"

class SimEntityList;

class SimEntityItem {
   friend class SimEntityList;
private:
   SimEntityItem *next;
   SimEntityItem *prev;
   Entity * entity;

   SimEntityItem(Entity *const v = 0)
		{ entity = v; next = prev = 0; }
};

class SimEntityList {
private:
   SimEntityItem *head;
   SimEntityItem *tail;
   char *listname;
public:
   SimEntityList(char *const s = 0)
		{ head = tail = 0; listname = s; }
   SimEntityList(Entity *const entity, char *const s)
		{ head = new SimEntityItem(entity); listname = s; }
   virtual ~SimEntityList();

   void name(char *const s)	{ listname = s; }
   char *name() const		{ return listname; }
   short is_empty()		{ return head == 0; }
   void print();

   int min_entity_id();
   int max_entity_id();

   Entity *get()		{ return remove(max_entity_id()); }
   Entity *remove(const int eid);

   void insert(Entity *const);
   void append(Entity *const);
};



#endif SimEntityList_H
