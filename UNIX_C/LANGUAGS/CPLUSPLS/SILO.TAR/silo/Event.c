/* $Author: ecsv38 $ $Date: 90/08/21 14:45:53 $ $Revision: 1.1 $ */
/* (c) S. Manoharan  sam@lfcs.edinburgh.ac.uk */

#include "Event.h"

Event::Event(const int ev_type)
{
   static int e_id = 0;

   event_type = ev_type; event_id = e_id++;
}

