/* $Author: ecsv38 $ $Date: 90/08/21 14:46:03 $ $Revision: 1.1 $ */
/* (c) S. Manoharan  sam@lfcs.edinburgh.ac.uk */

#include <stream.h>

#include "SimEntityList.h"


SimEntityList::~SimEntityList()
{
   SimEntityItem *listnode = head;

   while ( listnode ) {
      SimEntityItem *temp = listnode;

      listnode = listnode->next;
      delete temp;
   }
   head = tail = 0;
}

void
SimEntityList::insert(Entity *const entity)
{
   SimEntityItem *listnode = new SimEntityItem(entity);
   listnode->next = head;
   if ( head ) head->prev = listnode;
   else tail = listnode;
   head = listnode;
}

void
SimEntityList::append(Entity *const entity)
{
   SimEntityItem *listnode = new SimEntityItem(entity);
   listnode->prev = tail;
   if ( tail ) tail->next = listnode;
   else head = listnode;
   tail = listnode;
}

Entity *
SimEntityList::remove(const int eid)
{
   SimEntityItem *listnode = head;
   SimEntityItem *temp;
   Entity * gotcha = 0;

   while ( listnode ) {
      if ( (listnode->entity)->id() == eid ) {
	 gotcha = listnode->entity;
	 temp = listnode;
         if ( listnode->prev != 0 )
            (listnode->prev)->next = listnode->next;
         else head = listnode->next;
         if ( listnode->next != 0 )
            (listnode->next)->prev = listnode->prev;
	 else tail = listnode->prev;
         listnode = listnode->next;
         delete temp;
	 break;
      }
      else listnode = listnode->next;
   }
   return gotcha;
}

int
SimEntityList::max_entity_id()
{
   SimEntityItem *listnode = head;

   if ( head == 0 ) return 0;

   int max = (head->entity)->priority();
   int eid = (head->entity)->id();
   while ( listnode ) {
      if ( (listnode->entity)->priority() > max ) {
	 max = (listnode->entity)->priority();
	 eid = (listnode->entity)->id();
      }
      listnode = listnode->next;
   }
   return eid;
}

int
SimEntityList::min_entity_id()
{
   SimEntityItem *listnode = head;

   if ( head == 0 ) return 0;

   int min = (head->entity)->priority();
   int eid = (head->entity)->id();
   while ( listnode ) {
      if ( (listnode->entity)->priority() < min ) {
	 min = (listnode->entity)->priority();
	 eid = (listnode->entity)->id();
      }
      listnode = listnode->next;
   }
   return eid;
}

void
SimEntityList::print()
{
   if ( listname != 0 ) cout << listname << ":\n";

   if ( head == 0 ) {
      cout << "[ empty ]\n";
      return;
   }

   cout << "[ ";

   SimEntityItem *listnode = head;
   const int lineLength = 16;
   int cnt = 0;
   while ( listnode != 0 ) {
      if ( ++cnt % lineLength == 1 && cnt != 1 )
	 cout << "\n  ";
      /* print list->entry at this point */
      cout << form("0x%x (%g) ",
	 (listnode->entity)->id(), (listnode->entity)->priority());
      listnode = listnode->next;
   }
   cout << "]\n";
}

