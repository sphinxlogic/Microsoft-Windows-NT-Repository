/* $Author: ecsv38 $ $Date: 90/08/21 14:46:21 $ $Revision: 1.1 $ */
/* (c) S. Manoharan  sam@lfcs.edinburgh.ac.uk */

#ifndef Debug_H
#define Debug_H

#include <std.h>
#include <stream.h>

extern int debug_flag; /* global debug flag */

inline int
debug_level(const int level)
{
   return ( ::debug_flag > 0 && ::debug_flag <= level );
}

extern void freeStoreException();

#endif Debug_H
