/* $Author: ecsv38 $ $Date: 90/08/21 14:46:17 $ $Revision: 1.1 $ */
/* (c) S. Manoharan  sam@lfcs.edinburgh.ac.uk */

#ifndef Bin_H
#define Bin_H

#include "Entity.h"
#include "SimEntityList.h"

class Bin {
private:
   char *bin_name;
   int available;
   short bin_used;
   SimEntityList blockedQ;
public:
   Bin(const int = 0, char *const s = 0);
   virtual ~Bin()	{ }

   virtual void set(const int sz);
   virtual short status()	{ return available == 0; }

   virtual short take(Entity *const bywho, const int event_type);
   virtual void give();
};

inline
Bin::Bin(const int sz, char *const s)
{
   available = sz;
   bin_name = s;
   bin_used = 0;
}

#endif Bin_H
