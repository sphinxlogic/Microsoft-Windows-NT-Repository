/* $Author: ecsv38 $ $Date: 90/08/21 14:46:06 $ $Revision: 1.1 $ */
/* (c) S. Manoharan  sam@lfcs.edinburgh.ac.uk */

#include <stream.h>

#include "SimEventList.h"


SimEventList::~SimEventList()
{
   SimEventItem *listnode = head;

   while ( listnode ) {
      SimEventItem *temp = listnode;

      listnode = listnode->next;
      delete temp;
   }
   head = tail = 0;
}

void
SimEventList::insert(Event *const event)
{
   SimEventItem *listnode = new SimEventItem(event);
   listnode->next = head;
   if ( head ) head->prev = listnode;
   else tail = listnode;
   head = listnode;
}

void
SimEventList::append(Event *const event)
{
   SimEventItem *listnode = new SimEventItem(event);
   listnode->prev = tail;
   if ( tail ) tail->next = listnode;
   else head = listnode;
   tail = listnode;
}

Event *
SimEventList::remove(const int eid)
{
   SimEventItem *listnode = head;
   SimEventItem *temp;
   Event * gotcha = 0;

   while ( listnode ) {
      if ( (listnode->event)->id() == eid ) {
	 gotcha = listnode->event;
	 temp = listnode;
         if ( listnode->prev != 0 )
            (listnode->prev)->next = listnode->next;
         else head = listnode->next;
         if ( listnode->next != 0 )
            (listnode->next)->prev = listnode->prev;
	 else tail = listnode->prev;
         listnode = listnode->next;
         delete temp;
	 break;
      }
      else listnode = listnode->next;
   }
   return gotcha;
}

Event *
SimEventList::remove(Entity *const ent)
{
   SimEventItem *listnode = head;
   SimEventItem *temp;
   Event * gotcha = 0;

   while ( listnode ) {
      if ( (listnode->event)->scheduled_by() == ent ) {
	 gotcha = listnode->event;
	 temp = listnode;
         if ( listnode->prev != 0 )
            (listnode->prev)->next = listnode->next;
         else head = listnode->next;
         if ( listnode->next != 0 )
            (listnode->next)->prev = listnode->prev;
	 else tail = listnode->prev;
         listnode = listnode->next;
         delete temp;
	 break;
      }
      else listnode = listnode->next;
   }
   return gotcha;
}

int
SimEventList::min_event_id()
{
   SimEventItem *listnode = head;

   if ( head == 0 ) return 0;

   double min = (head->event)->eventTime();
   int eid = (head->event)->id();
   while ( listnode ) {
      if ( (listnode->event)->eventTime() < min ) {
	 min = (listnode->event)->eventTime();
	 eid = (listnode->event)->id();
      }
      listnode = listnode->next;
   }
   return eid;
}

int
SimEventList::max_event_id()
{
   SimEventItem *listnode = head;

   if ( head == 0 ) return 0;

   double max = (head->event)->eventTime();
   int eid = (head->event)->id();
   while ( listnode ) {
      if ( (listnode->event)->eventTime() > max ) {
	 max = (listnode->event)->eventTime();
	 eid = (listnode->event)->id();
      }
      listnode = listnode->next;
   }
   return eid;
}

void
SimEventList::print()
{
   if ( listname != 0 ) cout << listname << ":\n";

   if ( head == 0 ) {
      cout << "[ empty ]\n";
      return;
   }

   cout << "[ ";

   SimEventItem *listnode = head;
   const int lineLength = 16;
   int cnt = 0;
   while ( listnode != 0 ) {
      if ( ++cnt % lineLength == 1 && cnt != 1 )
	 cout << "\n  ";
      /* print list->entry at this point */
      cout << form("0x%x (%g) ",
	 (listnode->event)->id(), (listnode->event)->eventTime());
      listnode = listnode->next;
   }
   cout << "]\n";
}

