/* $Author: sam $ $Date: 90/07/11 13:31:58 $ $Revision: 1.1 $ */

#ifndef Counter_H
#define Counter_H

class Counter {
private:
   double current;
   double cycle;
public:
   Counter(double init = 0, double tck = 1);

   void set(const double t)		{ current = t; }
   void tick(const double t)		{ cycle = t; }

   double operator () () const		{ return current; }
   void operator += (const double inc)	{ current += inc; }
   void operator -= (const double dec)	{ current -= dec; }
   void operator -- ()			{ current -= cycle; }
   void operator ++ ()			{ current += cycle; }

   double tick() const			{ return cycle; }
};

inline
Counter::Counter(double init, double tck)
{
   current = init, cycle = tck;
}

#endif Counter_H

