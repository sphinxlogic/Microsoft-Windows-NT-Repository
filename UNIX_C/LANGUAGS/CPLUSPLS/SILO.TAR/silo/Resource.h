/* $Author: ecsv38 $ $Date: 90/08/21 14:46:29 $ $Revision: 1.1 $ */
/* (c) S. Manoharan  sam@lfcs.edinburgh.ac.uk */

#ifndef Resource_H
#define Resource_H

//
// An entity can reserve a resource for an event of type event_type.
// Reserved or preempted resources can later be released. Reserve,
// if unsuccessful, places the entity in blockedQ and returns 0.
// A release examines the blockedQ for blocked entities, removes
// the head of the Q and re-schedules the event during which the entity
// got blocked.
//

#include "Entity.h"
#include "SimEntityList.h"

class Resource {
private:
   char *resource_name;
   int available;
   short resource_used;
   SimEntityList blockedQ, servedQ;
public:
   Resource(const int = 1, char *const s = 0);
   virtual ~Resource()	{ }

   virtual void set(const int sz);
   virtual short status()	{ return available == 0; }

   virtual short reserve(Entity *const bywho, const int event_type);
   virtual short preempt(Entity *const bywho, const int event_type);
   virtual void release(Entity *const bywho);
};

inline
Resource::Resource(const int sz, char *const s)
{
   available = sz;
   resource_name = s;
   resource_used = 0;
}

#endif Resource_H
