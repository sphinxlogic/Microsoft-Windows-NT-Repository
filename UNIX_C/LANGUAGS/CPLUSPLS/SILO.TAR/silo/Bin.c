/* $Author: ecsv38 $ $Date: 90/08/21 14:45:38 $ $Revision: 1.1 $ */
/* (c) S. Manoharan  sam@lfcs.edinburgh.ac.uk */

#include "Bin.h"
#include "Sim.h"


short
Bin::take(Entity *bywho, const int event_type)
{
   bin_used = 1;

   if ( bywho == 0 )
      cout << form("** Error: take by null entity\n");

   if ( available > 0 ) {
      --available;
      bywho->currentEvent(event_type);
      return 1;
   }
   else {
      bywho->currentEvent(event_type);
      blockedQ.append(bywho);
      return 0;
   }
}

void
Bin::give()
{
   Entity *entity;

   if ( debug_level(1) ) {
      cout << form("Releasing bin %s\n", bin_name);
      cout << "\n---Begin{blockedQ}\n";
      blockedQ.print();
      cout << "\n---End{blockedQ}\n";
   }

   if ( ( entity = blockedQ.get() ) != 0 ) {
      Event *event = new Event(entity->currentEvent());
      entity->schedule(0, event);
   }
   ++available;
}

void
Bin::set(const int sz)
{
   if ( bin_used ) {
      cout << form("%s: bin already used. cannot set size\n",
	 bin_name);
      exit(-1);
   }
   available = sz;
}

