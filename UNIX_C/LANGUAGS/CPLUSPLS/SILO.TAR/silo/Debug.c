/* $Author: ecsv38 $ $Date: 90/08/21 14:45:43 $ $Revision: 1.1 $ */
/* (c) S. Manoharan  sam@lfcs.edinburgh.ac.uk */

#include <std.h>
#include <stream.h>

#include "Debug.h"

int debug_flag = 0;		/* global debug flag */

void
freeStoreException()
{
   cout << form("Baby, You're cored.\n");
   exit(-1);
}

