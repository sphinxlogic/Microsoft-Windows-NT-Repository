/* $Author: ecsv38 $ $Date: 90/08/21 14:46:23 $ $Revision: 1.1 $ */
/* (c) S. Manoharan  sam@lfcs.edinburgh.ac.uk */

#ifndef Entity_H
#define Entity_H

class Event; class Entity;

class Entity {
friend class Resource;
private:
   int entity_id;
   int prio;
   char *entity_name;
   int current_event;
   double afterTime;
protected:
public:
   Entity(char *const s = 0);
   virtual ~Entity()			{ }

   int id() const			{ return entity_id; }
   virtual void name(char *const s)	{ entity_name = s; }
   virtual char *name() const		{ return entity_name; }

   virtual void currentEvent(const int e)	{ current_event = e; }
   virtual int currentEvent() const	{ return current_event; }
   virtual void priority(const int p)	{ prio = p; }
   virtual int priority() const		{ return prio; }

   virtual void schedule(const double delay, Event *const ev);
};

#endif  Entity_H
