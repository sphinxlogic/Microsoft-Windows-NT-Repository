/* $Author: ecsv38 $ $Date: 90/08/21 14:46:11 $ $Revision: 1.2 $ */
/* (c) S. Manoharan  sam@lfcs.edinburgh.ac.uk */

/* Reference --
@book{MacDo87,
   author =	"M H MacDougall",
   year =	"1987",
   publisher =	"MIT Press",
   title =	"Simulating Computer Systems: Techniques and Tools"
}
-- */


#include "Sim.h"

#include <std.h>
#include <new.h>
#include <MLCG.h>
#include <DiscreteUniform.h>


int main(int argc, char **argv)
{
   MLCG gen;
   DiscreteUniform sample(0, 20, &gen);

   int Debug_flag = 0;


   set_new_handler(freeStoreException);

   const double MAXTIME = 500;

   Resource server(1, "Server");
   Entity customer("Customer");
   const int ARRIVAL = 1;
   const int DEPART  = 2;
   const int RESERVE = 3;

   double delay, inst; Event *event;

   Event *ev = new Event(ARRIVAL);
   customer.schedule(0, ev);
   while ( simtime() < MAXTIME ) {
      event = cause(); inst = simtime();
      if ( event == 0 ) {
	 cout << form("%s: no more events to process\n", argv[0]);
	 exit(0);
      }
      else cout << form("[%g]\t** event %d (id %d) caused\n",
	 inst, event->type(), event->id());

      switch ( event->type() ) {
      case ARRIVAL :
	 cout << form("[%g]\tArrival\n", inst);

	 ev = new Event(RESERVE);
	 cout << form("[%g]\tscheduling a RESERVE\n", inst);
	 customer.schedule(0, ev);

	 ev = new Event(ARRIVAL);
	 delay = sample();
	 cout << form("[%g]\tscheduling an ARRIVAL after %g\n",
	    inst, delay);
	 customer.schedule(delay, ev);

	 break;
      case RESERVE :
	 cout << form("[%g]\tReserve\n", inst);
	 if ( server.reserve(&customer, event->type()) ) {
	    ev = new Event(DEPART);
	    delay = sample();
	    cout << form("[%g]\tscheduling a DEPART after %g\n",
	       inst, delay);
	    customer.schedule(delay, ev);
	 }
	 else
	    cout << form("[%g]\tserver busy now\n", inst);
	 break;
      case DEPART :
	 cout << form("[%g]\tDepart\n", inst);
	 server.release(&customer);
	 break;
      default :
	 cout << form("%s: invalid event %d detected\n",
	    argv[0], event->type());
	 break;
      }

      delete event;
   }

   return 0;
}
