/* $Author: ecsv38 $ $Date: 90/08/21 14:46:26 $ $Revision: 1.1 $ */
/* (c) S. Manoharan  sam@lfcs.edinburgh.ac.uk */

#ifndef Event_H
#define Event_H

class Event; class Entity;

class Event {
private:
   int event_id;
   int event_type;
   double etime;
   Entity *bywho;
protected:
public:
   Event(const int ev_type = 0);
   virtual ~Event()	{ }

   virtual int id() const			{ return event_id; }
   virtual void type(const int n)		{ event_type = n; }
   virtual int type() const			{ return event_type; }
   virtual void eventTime(const double t)	{ etime = t; }
   virtual double eventTime() const		{ return etime; }
   virtual void scheduled_by(Entity *const who)	{ bywho = who; }
   virtual Entity *scheduled_by() const		{ return bywho; }
};

#endif  Event_H
