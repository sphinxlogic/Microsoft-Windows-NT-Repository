/* $Author: ecsv38 $ $Date: 90/08/21 14:46:32 $ $Revision: 1.1 $ */
/* (c) S. Manoharan  sam@lfcs.edinburgh.ac.uk */

#ifndef Sim_H
#define Sim_H

#include <std.h>
#include <stream.h>

#include "Debug.h"
#include "Event.h"
#include "Entity.h"
#include "Resource.h"
#include "Bin.h"

Event *cause ( void );
short cancel ( const int eid );
double simtime ( void );


#endif Sim_H

