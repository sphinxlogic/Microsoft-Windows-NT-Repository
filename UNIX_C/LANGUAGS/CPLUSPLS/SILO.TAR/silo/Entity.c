/* $Author: ecsv38 $ $Date: 90/08/21 14:45:49 $ $Revision: 1.1 $ */
/* (c) S. Manoharan  sam@lfcs.edinburgh.ac.uk */

#include "Entity.h"
#include "SimEventList.h"
#include "Debug.h"

#include "Counter.h"

static Counter timer;
SimEventList eventlist;

Event *cause()
{
   if ( debug_level(1) ) {
      cout << "\n---Begin{eventlist}\n";
      ::eventlist.print();
      cout << "\n---End{eventlist}\n";
   }


   Event *ev = ::eventlist.get();
   if ( ev == 0 ) return 0;

   if ( ev->eventTime() > ::timer() ) 
      ::timer.set(ev->eventTime());

   return ev;
}

short cancel(const int eid)
{
   Event *ev = ::eventlist.remove(eid);

   if ( ev == 0 ) return 0;
   else {
      delete ev;
      return 1;
   }
}

double simtime()
{
   return timer();
}

Entity::Entity(char *const s)
{
   static int eid = 0;

   entity_name = s, entity_id = eid++;
}

void
Entity::schedule(const double delay, Event *const ev)
{
   if ( delay < 0 ) {
      cout << form("%s: invalid delay %g\n", entity_name, delay);
      exit(-1);
   }
   ev->scheduled_by(this);
   ev->eventTime(::timer() + delay);

   ::eventlist.append(ev);
}

