
/*  This provides the outermost framework of LOGO, calling the parser to
 *	begin with, and then thereafter whenever an interrupt or error occurs.
 *	Copyright (C) 1979, The Children's Museum, Boston, Mass.
 *	Written by Douglas B. Klunder.
 */

#include "logo.h"

char editfile[30];
extern char *getbpt;
#ifndef NOTURTLE
extern int turtdes;
extern struct display *mydpy;
#endif
#ifdef SETCURSOR
#include <sgtty.h>
struct sgttyb tty;
#endif

main(argc,argv)
int argc;
char *argv[];
{
	int i[2];
	char tbuff[BUFSIZ];

	setbuf(stdout,tbuff);
	time(i);
	SRAND(i[1]+i[0]);
	sprintf(editfile,"/tmp/logo%u",(short)getpid());
#ifdef SETCURSOR
	gtty(1,&tty);
#endif
	if (argc>1)
		getbpt = argv[1];
	else
		printf("\nWelcome to Children's Museum/LSRHS LOGO\n?");
	fflush(stdout);
	while (enter()==1) {
		yyprompt(1);
	}
	cboff();
#ifdef SETCURSOR
	stty(1,&tty);
#endif
#ifndef NOTURTLE
#ifdef FLOOR
	if (turtdes>0)
		printf("Please\007 unplug the turtle\007 and put it\007 away.\n");
#endif
	if (turtdes<0) {
		printf(mydpy->finish);
		(*mydpy->outfn)();
	}
#endif
	unlink(editfile);
}

