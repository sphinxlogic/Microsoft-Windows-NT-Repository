# define Def 257
# define Symbol 258
# define Sel 259
# define Rsel 260
# define Then 261
# define Else 262
# define Compose 263
# define Alpha 264
# define Insert 265
# define Rinsert 266
# define Tree 267
# define Bu 268
# define Bur 269
# define While 270
# define  _ 95
# define Div 271
# define Geq 272
# define Leq 273
# define Noteq 274
# define TrueConst 275
# define FalseConst 276
# define String 277
# define CharConst 278
# define Float 279
#define yyclearin yychar = -1
#define yyerrok yyerrflag = 0
extern int yychar;
extern short yyerrflag;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif
#ifndef YYSTYPE
#define YYSTYPE int
#endif
YYSTYPE yylval, yyval;
# define YYERRCODE 256

# line 157 "fpg.y"


#include "lex.yy.c"

#undef YYMAXDEPTH
#define YYMAXDEPTH 2048

void parsefnstart ();
void parsefnend ();
void parsethen ();
void parseelse ();
void parseendif ();
void parsebustart ();
void parsebufun ();
void parsebuobj ();
void whilestart ();
void whilepred ();
void whilefun ();
void parsecomp ();
void startcomp ();
void endcomp ();
void parseaa ();
void parseconstr ();
void constrnext ();
void endconstr ();
void parseinsert ();
void endinsert ();
void parsesel ();
void parsefncall ();
void parsenil ();
void consttrue ();
void constfalse ();
void constnum ();
void constsym ();
void conststr ();
void constchr ();
void constreal ();
void liststart ();
void listnext ();
void listend ();

short yyexca[] ={
-1, 1,
	0, -1,
	-2, 0,
	};
# define YYNPROD 70
# define YYLAST 275
short yyact[]={

  13,  37,  25,  23,  84,  24,  33,   5,   3,  81,
  45,   7,  40,   8,  91,  72,  88,   2,  82,   4,
  28,  27,  29,  73,  12,  89,  44,  43,  42,  67,
  41,  79,  90,  38,  65,  77,  36,  76,  53,  39,
  13,  35,  25,  23,  75,  24,  62,  63,  64,  34,
  66,  15,  92,  68,  61,  19,   6,   1,  80,   0,
  28,  27,  29,   0,   0,   0,   0,  69,  70,  71,
   0,   0,   0,  74,   0,   0,   0,   0,   0,  78,
   0,   0,   0,   0,  83,   0,  85,  86,   0,  87,
   0,  15,   0,   0,   0,  19,   0,   0,   0,   0,
   0,  93,  94,   0,  95,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,  22,  20,
  21,   0,   0,   0,  14,  16,  17,  18,   9,  10,
  11,  26,  30,  31,  32,  54,  49,  48,   0,   0,
   0,  56,  55,   0,   0,   0,  58,  59,  60,  57,
   0,   0,   0,  46,  47,  50,  51,  52,  22,  20,
  21,   0,   0,   0,  14,  16,  17,  18,   0,   0,
   0,  26,  30,  31,  32 };
short yypact[]={

-249,-249,-1000,-251,-1000,-1000, -40,-1000,-255,-1000,
-1000,-1000,-262,-1000,   0, -81,-1000,-1000,-1000, -22,
-1000,-1000,-1000,-1000,-1000,-1000,-1000,-1000,-1000,-1000,
-1000,-1000,-1000,-1000, -40, -40, -40,-1000, -40,-1000,
-1000, -40,   0,   0,   0,-1000,-1000,-1000,-1000,-1000,
-1000,-1000,-1000, -47,-1000,-1000,-1000,-1000,-1000,-1000,
-1000, -40,-1000,-1000,-1000,   0,-1000, -35,-1000,-1000,
-1000,-1000,-1000, -22,-258, -22, -22, -40,-1000, -25,
-1000,-1000, -30,-1000,-1000,-1000,-1000,-1000,-1000, -40,
-1000, -22, -40,-1000,-1000,-1000 };
short yypgo[]={

   0,  57,  17,  56,  11,  13,  54,  52,  49,  44,
  10,  41,  37,  36,  35,  24,  34,  33,  31,  30,
  29,  28,  27,  26,  25,  23,  18 };
short yyr1[]={

   0,   1,   1,   3,   2,   6,   7,   4,   8,   9,
   4,  11,  12,   4,  13,  14,   4,   4,   5,  16,
   5,  17,  18,  15,  15,  15,  19,  15,  21,  15,
  22,  15,  23,  15,  15,  15,  15,  15,  15,  15,
  15,  15,  15,  15,  15,  15,  15,  15,  20,  24,
  20,  10,  10,  10,  10,  10,  10,  10,  10,  25,
  10,  10,  10,  10,  10,  10,  10,  10,  26,  26 };
short yyr2[]={

   0,   1,   2,   0,   4,   0,   0,   7,   0,   0,
   5,   0,   0,   5,   0,   0,   5,   1,   1,   0,
   4,   0,   0,   5,   2,   2,   0,   4,   0,   3,
   0,   3,   0,   3,   2,   1,   1,   1,   1,   1,
   1,   1,   1,   1,   1,   1,   1,   1,   1,   0,
   4,   1,   1,   1,   1,   1,   1,   1,   2,   0,
   4,   1,   1,   1,   1,   1,   1,   1,   1,   3 };
short yychk[]={

-1000,  -1,  -2, 257,  -2, 258,  -3,  -4,  -5, 268,
 269, 270, -15,  40, 264,  91, 265, 266, 267,  95,
 259, 260, 258,  43,  45,  42, 271,  61,  60,  62,
 272, 273, 274, 261,  -8, -11, -13, 263, -17, -15,
  93, -19, -21, -22, -23, -10, 275, 276, 259, 258,
 277, 278, 279,  60, 257, 264, 263, 271, 268, 269,
 270,  -6,  -4,  -4,  -4, -16,  -4, -20,  -4, -15,
 -15, -15,  62, -25,  -4,  -9, -12, -14,  -5, -18,
  93,  44, -26, -10, 262, -10, -10,  -4,  41, -24,
  62,  44,  -7,  -4, -10,  -4 };
short yydef[]={

   0,  -2,   1,   0,   2,   3,   0,   4,  17,   8,
  11,  14,  18,  21,   0,  26,  28,  30,  32,   0,
  35,  36,  37,  38,  39,  40,  41,  42,  43,  44,
  45,  46,  47,   5,   0,   0,   0,  19,   0,  24,
  25,   0,   0,   0,   0,  34,  51,  52,  53,  54,
  55,  56,  57,  59,  61,  62,  63,  64,  65,  66,
  67,   0,   9,  12,  15,   0,  22,   0,  48,  29,
  31,  33,  58,   0,   0,   0,   0,   0,  20,   0,
  27,  49,   0,  68,   6,  10,  13,  16,  23,   0,
  60,   0,   0,  50,  69,   7 };
#ifndef lint
static char yaccpar_sccsid[] = "@(#)yaccpar	4.1	(Berkeley)	2/11/83";
#endif not lint

#
# define YYFLAG -1000
# define YYERROR goto yyerrlab
# define YYACCEPT return(0)
# define YYABORT return(1)

/*	parser for yacc output	*/

#ifdef YYDEBUG
int yydebug = 0; /* 1 for debugging */
#endif
YYSTYPE yyv[YYMAXDEPTH]; /* where the values are stored */
int yychar = -1; /* current input token number */
int yynerrs = 0;  /* number of errors */
short yyerrflag = 0;  /* error recovery flag */

yyparse() {

	short yys[YYMAXDEPTH];
	short yyj, yym;
	register YYSTYPE *yypvt;
	register short yystate, *yyps, yyn;
	register YYSTYPE *yypv;
	register short *yyxi;

	yystate = 0;
	yychar = -1;
	yynerrs = 0;
	yyerrflag = 0;
	yyps= &yys[-1];
	yypv= &yyv[-1];

 yystack:    /* put a state and value onto the stack */

#ifdef YYDEBUG
	if( yydebug  ) printf( "state %d, char 0%o\n", yystate, yychar );
#endif
		if( ++yyps> &yys[YYMAXDEPTH] ) { yyerror( "yacc stack overflow" ); return(1); }
		*yyps = yystate;
		++yypv;
		*yypv = yyval;

 yynewstate:

	yyn = yypact[yystate];

	if( yyn<= YYFLAG ) goto yydefault; /* simple state */

	if( yychar<0 ) if( (yychar=yylex())<0 ) yychar=0;
	if( (yyn += yychar)<0 || yyn >= YYLAST ) goto yydefault;

	if( yychk[ yyn=yyact[ yyn ] ] == yychar ){ /* valid shift */
		yychar = -1;
		yyval = yylval;
		yystate = yyn;
		if( yyerrflag > 0 ) --yyerrflag;
		goto yystack;
		}

 yydefault:
	/* default state action */

	if( (yyn=yydef[yystate]) == -2 ) {
		if( yychar<0 ) if( (yychar=yylex())<0 ) yychar = 0;
		/* look through exception table */

		for( yyxi=yyexca; (*yyxi!= (-1)) || (yyxi[1]!=yystate) ; yyxi += 2 ) ; /* VOID */

		while( *(yyxi+=2) >= 0 ){
			if( *yyxi == yychar ) break;
			}
		if( (yyn = yyxi[1]) < 0 ) return(0);   /* accept */
		}

	if( yyn == 0 ){ /* error */
		/* error ... attempt to resume parsing */

		switch( yyerrflag ){

		case 0:   /* brand new error */

			yyerror( "syntax error" );
		yyerrlab:
			++yynerrs;

		case 1:
		case 2: /* incompletely recovered error ... try again */

			yyerrflag = 3;

			/* find a state where "error" is a legal shift action */

			while ( yyps >= yys ) {
			   yyn = yypact[*yyps] + YYERRCODE;
			   if( yyn>= 0 && yyn < YYLAST && yychk[yyact[yyn]] == YYERRCODE ){
			      yystate = yyact[yyn];  /* simulate a shift of "error" */
			      goto yystack;
			      }
			   yyn = yypact[*yyps];

			   /* the current yyps has no shift onn "error", pop stack */

#ifdef YYDEBUG
			   if( yydebug ) printf( "error recovery pops state %d, uncovers %d\n", *yyps, yyps[-1] );
#endif
			   --yyps;
			   --yypv;
			   }

			/* there is no state on the stack with an error shift ... abort */

	yyabort:
			return(1);


		case 3:  /* no shift yet; clobber input char */

#ifdef YYDEBUG
			if( yydebug ) printf( "error recovery discards char %d\n", yychar );
#endif

			if( yychar == 0 ) goto yyabort; /* don't discard EOF, quit */
			yychar = -1;
			goto yynewstate;   /* try again in the same state */

			}

		}

	/* reduction by production yyn */

#ifdef YYDEBUG
		if( yydebug ) printf("reduce %d\n",yyn);
#endif
		yyps -= yyr2[yyn];
		yypvt = yypv;
		yypv -= yyr2[yyn];
		yyval = yypv[1];
		yym=yyn;
			/* consult goto table to find next state */
		yyn = yyr1[yyn];
		yyj = yypgo[yyn] + *yyps + 1;
		if( yyj>=YYLAST || yychk[ yystate = yyact[yyj] ] != -yyn ) yystate = yyact[yypgo[yyn]];
		switch(yym){
			
case 3:
# line 13 "fpg.y"
{ parsefnstart (yytext); } break;
case 4:
# line 14 "fpg.y"
{ parsefnend (); } break;
case 5:
# line 19 "fpg.y"
{ parsethen (); } break;
case 6:
# line 22 "fpg.y"
{ parseelse (); } break;
case 7:
# line 24 "fpg.y"
{ parseendif (); } break;
case 8:
# line 26 "fpg.y"
{ parsebustart (0); } break;
case 9:
# line 28 "fpg.y"
{ parsebufun (); } break;
case 10:
# line 30 "fpg.y"
{ parsebuobj (); } break;
case 11:
# line 32 "fpg.y"
{ parsebustart (1); } break;
case 12:
# line 34 "fpg.y"
{ parsebufun (); } break;
case 13:
# line 36 "fpg.y"
{ parsebuobj (); } break;
case 14:
# line 38 "fpg.y"
{ whilestart (); } break;
case 15:
# line 40 "fpg.y"
{ whilepred (); } break;
case 16:
# line 42 "fpg.y"
{ whilefun (); } break;
case 19:
# line 49 "fpg.y"
{ parsecomp (); } break;
case 21:
# line 54 "fpg.y"
{ startcomp (); } break;
case 22:
# line 56 "fpg.y"
{ endcomp (); } break;
case 24:
# line 60 "fpg.y"
{ parseaa (); } break;
case 25:
# line 62 "fpg.y"
{ parsenil (); } break;
case 26:
# line 64 "fpg.y"
{ parseconstr (); } break;
case 27:
# line 67 "fpg.y"
{ constrnext (); endconstr (); } break;
case 28:
# line 69 "fpg.y"
{ parseinsert (0); } break;
case 29:
# line 71 "fpg.y"
{ endinsert (); } break;
case 30:
# line 73 "fpg.y"
{ parseinsert (1); } break;
case 31:
# line 75 "fpg.y"
{ endinsert (); } break;
case 32:
# line 77 "fpg.y"
{ parseinsert (2); } break;
case 33:
# line 79 "fpg.y"
{ endinsert (); } break;
case 35:
# line 82 "fpg.y"
{ parsesel (yytext, 0); } break;
case 36:
# line 84 "fpg.y"
{ parsesel (yytext, 1); } break;
case 37:
# line 86 "fpg.y"
{ parsefncall (yytext); } break;
case 38:
# line 88 "fpg.y"
{ parsefncall ("plus"); } break;
case 39:
# line 90 "fpg.y"
{ parsefncall ("minus"); } break;
case 40:
# line 92 "fpg.y"
{ parsefncall ("times"); } break;
case 41:
# line 94 "fpg.y"
{ parsefncall ("div"); } break;
case 42:
# line 96 "fpg.y"
{ parsefncall ("eq"); } break;
case 43:
# line 98 "fpg.y"
{ parsefncall ("less"); } break;
case 44:
# line 100 "fpg.y"
{ parsefncall ("greater"); } break;
case 45:
# line 102 "fpg.y"
{ parsefncall ("gequal"); } break;
case 46:
# line 104 "fpg.y"
{ parsefncall ("lequal"); } break;
case 47:
# line 106 "fpg.y"
{ parsefncall ("notequal"); } break;
case 49:
# line 111 "fpg.y"
{ constrnext (); } break;
case 51:
# line 115 "fpg.y"
{ consttrue (); } break;
case 52:
# line 117 "fpg.y"
{ constfalse (); } break;
case 53:
# line 119 "fpg.y"
{ constnum (yytext); } break;
case 54:
# line 121 "fpg.y"
{ constsym (yytext); } break;
case 55:
# line 123 "fpg.y"
{ conststr (yytext); } break;
case 56:
# line 125 "fpg.y"
{ constchr (yytext); } break;
case 57:
# line 127 "fpg.y"
{ constreal (yytext); } break;
case 58:
# line 129 "fpg.y"
{ parsenil (); } break;
case 59:
# line 131 "fpg.y"
{ liststart (); } break;
case 60:
# line 134 "fpg.y"
{ listend (); } break;
case 61:
# line 136 "fpg.y"
{ constsym ("Def"); } break;
case 62:
# line 138 "fpg.y"
{ constsym ("aa"); } break;
case 63:
# line 140 "fpg.y"
{ constsym ("o"); } break;
case 64:
# line 142 "fpg.y"
{ constsym ("div"); } break;
case 65:
# line 144 "fpg.y"
{ constsym ("bu"); } break;
case 66:
# line 146 "fpg.y"
{ constsym ("bur"); } break;
case 67:
# line 148 "fpg.y"
{ constsym ("while"); } break;
case 68:
# line 152 "fpg.y"
{ listnext (); } break;
case 69:
# line 155 "fpg.y"
{ listnext (); } break; 
		}
		goto yystack;  /* stack new state and value */

	}
