# include "stdio.h"
# define U(x) x
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX 200
# define output(c) (void) putc(c,yyout)
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
# define ECHO (void) fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin ={stdin}, *yyout ={stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;
# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:
	{ return (Def); }
break;
case 2:
	{ return (Then); }
break;
case 3:
	{ return (Else); }
break;
case 4:
	{ return (Compose); }
break;
case 5:
	{ return (Alpha); }
break;
case 6:
	{ return (Tree); }
break;
case 7:
	{ return (Insert); }
break;
case 8:
	{ return (Rinsert); }
break;
case 9:
	{ return (','); }
break;
case 10:
	{ return ('['); }
break;
case 11:
	{ return (']'); }
break;
case 12:
	{ return ('('); }
break;
case 13:
	{ return (')'); }
break;
case 14:
	{ return ('<'); }
break;
case 15:
	{ return ('>'); }
break;
case 16:
	{ return ('_'); }
break;
case 17:
	{ return (Bu); }
break;
case 18:
	{ return (Bur); }
break;
case 19:
	{ return (While); }
break;
case 20:
	{ return ('+'); }
break;
case 21:
	{ return ('*'); }
break;
case 22:
	{ return (Div); }
break;
case 23:
	{ return ('='); }
break;
case 24:
	{ return (Leq); }
break;
case 25:
	{ return (Geq); }
break;
case 26:
	{ return (Noteq); }
break;
case 27:
	{ return (TrueConst); }
break;
case 28:
	{ return (FalseConst); }
break;
case 29:
{ return (Symbol); }
break;
case 30:
	{ return (Rsel); }
break;
case 31:
{ return (Float); }
break;
case 32:
{ return (Float); }
break;
case 33:
{ return (Sel); }
break;
case 34:
	{ return (Sel); }
break;
case 35:
	{ return ('-'); }
break;
case 36:
{ return (String); }
break;
case 37:
	{ return (CharConst); }
break;
case 38:
	{ return (CharConst); }
break;
case 39:
{ set_line (yytext); }
break;
case 40:
	{ inc_line (); }
break;
case 41:
	{ inc_line (); }
break;
case 42:
	;
break;
case -1:
break;
default:
(void) fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */
int yyvstop[] ={
0,

42,
0,

41,
0,

42,
0,

42,
0,

42,
0,

42,
0,

12,
42,
0,

13,
42,
0,

21,
42,
0,

20,
42,
0,

9,
42,
0,

35,
42,
0,

7,
42,
0,

34,
42,
0,

3,
42,
0,

14,
42,
0,

23,
42,
0,

15,
42,
0,

29,
42,
0,

29,
42,
0,

28,
29,
42,
0,

27,
29,
42,
0,

10,
42,
0,

8,
42,
0,

11,
42,
0,

16,
42,
0,

29,
42,
0,

29,
42,
0,

29,
42,
0,

4,
29,
42,
0,

29,
42,
0,

42,
0,

26,
0,

36,
0,

40,
0,

38,
0,

38,
0,

33,
0,

2,
0,

32,
0,

34,
0,

30,
0,

24,
0,

25,
0,

29,
0,

29,
0,

6,
0,

5,
29,
0,

17,
29,
0,

29,
0,

29,
0,

37,
0,

31,
0,

1,
29,
0,

18,
29,
0,

22,
29,
0,

29,
0,

29,
0,

19,
29,
0,

39,
0,
0};
# define YYTYPE char
struct yywork { YYTYPE verify, advance; } yycrank[] ={
0,0,	0,0,	1,3,	0,0,	
6,36,	0,0,	7,38,	0,0,	
0,0,	0,0,	0,0,	1,4,	
0,0,	6,36,	0,0,	7,39,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	34,56,	1,5,	1,6,	
1,7,	6,37,	63,65,	7,38,	
1,8,	1,9,	1,10,	1,11,	
1,12,	1,13,	1,14,	65,67,	
1,15,	1,16,	26,51,	6,36,	
56,63,	7,38,	63,63,	0,0,	
0,0,	0,0,	8,40,	0,0,	
1,17,	1,18,	1,19,	1,20,	
5,35,	18,47,	1,21,	8,0,	
6,36,	1,22,	7,38,	1,23,	
14,42,	14,42,	14,42,	14,42,	
14,42,	14,42,	14,42,	14,42,	
14,42,	14,42,	20,48,	0,0,	
0,0,	1,24,	14,43,	0,0,	
0,0,	0,0,	0,0,	8,40,	
1,25,	1,26,	1,27,	0,0,	
1,28,	0,0,	1,29,	1,30,	
29,52,	1,31,	22,50,	50,59,	
64,66,	8,40,	31,54,	2,5,	
33,55,	2,34,	55,62,	62,64,	
1,32,	2,8,	2,9,	2,10,	
2,11,	2,12,	2,13,	2,14,	
1,33,	2,15,	8,40,	30,53,	
53,60,	54,61,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	2,17,	2,18,	2,19,	
2,20,	0,0,	0,0,	0,0,	
0,0,	0,0,	2,22,	0,0,	
2,23,	0,0,	0,0,	0,0,	
0,0,	8,41,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	2,24,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	2,25,	2,26,	2,27,	
0,0,	2,28,	0,0,	2,29,	
2,30,	16,44,	2,31,	16,45,	
16,45,	16,45,	16,45,	16,45,	
16,45,	16,45,	16,45,	16,45,	
16,45,	2,32,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	2,33,	21,49,	21,49,	
21,49,	21,49,	21,49,	21,49,	
21,49,	21,49,	21,49,	21,49,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	21,49,	
21,49,	21,49,	21,49,	21,49,	
21,49,	21,49,	21,49,	21,49,	
21,49,	21,49,	21,49,	21,49,	
21,49,	21,49,	21,49,	21,49,	
21,49,	21,49,	21,49,	21,49,	
21,49,	21,49,	21,49,	21,49,	
21,49,	0,0,	0,0,	0,0,	
0,0,	16,46,	0,0,	21,49,	
21,49,	21,49,	21,49,	21,49,	
21,49,	21,49,	21,49,	21,49,	
21,49,	21,49,	21,49,	21,49,	
21,49,	21,49,	21,49,	21,49,	
21,49,	21,49,	21,49,	21,49,	
21,49,	21,49,	21,49,	21,49,	
21,49,	41,57,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	42,58,	41,0,	42,42,	
42,42,	42,42,	42,42,	42,42,	
42,42,	42,42,	42,42,	42,42,	
42,42,	44,44,	44,44,	44,44,	
44,44,	44,44,	44,44,	44,44,	
44,44,	44,44,	44,44,	67,67,	
0,0,	68,67,	41,57,	58,58,	
58,58,	58,58,	58,58,	58,58,	
58,58,	58,58,	58,58,	58,58,	
58,58,	0,0,	0,0,	0,0,	
41,57,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
67,68,	41,57,	68,68,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	67,67,	0,0,	
68,67,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	67,67,	
0,0,	68,67,	0,0,	0,0,	
0,0};
struct yysvf yysvec[] ={
0,	0,	0,
yycrank+-1,	0,		0,	
yycrank+-74,	yysvec+1,	0,	
yycrank+0,	0,		yyvstop+1,
yycrank+0,	0,		yyvstop+3,
yycrank+3,	0,		yyvstop+5,
yycrank+-3,	0,		yyvstop+7,
yycrank+-5,	0,		yyvstop+9,
yycrank+-57,	0,		yyvstop+11,
yycrank+0,	0,		yyvstop+13,
yycrank+0,	0,		yyvstop+16,
yycrank+0,	0,		yyvstop+19,
yycrank+0,	0,		yyvstop+22,
yycrank+0,	0,		yyvstop+25,
yycrank+24,	0,		yyvstop+28,
yycrank+0,	0,		yyvstop+31,
yycrank+127,	0,		yyvstop+34,
yycrank+0,	0,		yyvstop+37,
yycrank+4,	0,		yyvstop+40,
yycrank+0,	0,		yyvstop+43,
yycrank+21,	0,		yyvstop+46,
yycrank+146,	0,		yyvstop+49,
yycrank+1,	yysvec+21,	yyvstop+52,
yycrank+0,	yysvec+21,	yyvstop+55,
yycrank+0,	yysvec+21,	yyvstop+59,
yycrank+0,	0,		yyvstop+63,
yycrank+3,	0,		yyvstop+66,
yycrank+0,	0,		yyvstop+69,
yycrank+0,	0,		yyvstop+72,
yycrank+3,	yysvec+21,	yyvstop+75,
yycrank+6,	yysvec+21,	yyvstop+78,
yycrank+1,	yysvec+21,	yyvstop+81,
yycrank+0,	yysvec+21,	yyvstop+84,
yycrank+4,	yysvec+21,	yyvstop+88,
yycrank+-1,	yysvec+7,	yyvstop+91,
yycrank+0,	0,		yyvstop+93,
yycrank+0,	yysvec+6,	0,	
yycrank+0,	0,		yyvstop+95,
yycrank+0,	yysvec+7,	0,	
yycrank+0,	0,		yyvstop+97,
yycrank+0,	0,		yyvstop+99,
yycrank+-268,	0,		yyvstop+101,
yycrank+231,	0,		yyvstop+103,
yycrank+0,	0,		yyvstop+105,
yycrank+241,	0,		yyvstop+107,
yycrank+0,	yysvec+16,	yyvstop+109,
yycrank+0,	0,		yyvstop+111,
yycrank+0,	0,		yyvstop+113,
yycrank+0,	0,		yyvstop+115,
yycrank+0,	yysvec+21,	yyvstop+117,
yycrank+1,	yysvec+21,	yyvstop+119,
yycrank+0,	0,		yyvstop+121,
yycrank+0,	yysvec+21,	yyvstop+123,
yycrank+10,	yysvec+21,	yyvstop+126,
yycrank+7,	yysvec+21,	yyvstop+129,
yycrank+5,	yysvec+21,	yyvstop+131,
yycrank+-4,	yysvec+7,	0,	
yycrank+0,	0,		yyvstop+133,
yycrank+255,	0,		yyvstop+135,
yycrank+0,	yysvec+21,	yyvstop+137,
yycrank+0,	yysvec+21,	yyvstop+140,
yycrank+0,	yysvec+21,	yyvstop+143,
yycrank+3,	yysvec+21,	yyvstop+146,
yycrank+-6,	yysvec+7,	0,	
yycrank+3,	yysvec+21,	yyvstop+148,
yycrank+-13,	yysvec+7,	0,	
yycrank+0,	yysvec+21,	yyvstop+150,
yycrank+-298,	yysvec+7,	0,	
yycrank+-300,	yysvec+7,	yyvstop+153,
0,	0,	0};
struct yywork *yytop = yycrank+365;
struct yysvf *yybgin = yysvec+1;
char yymatch[] ={
00  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,012 ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,'"' ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,
'0' ,'0' ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,01  ,01  ,01  ,01  ,01  ,
01  ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,01  ,01  ,01  ,01  ,01  ,
0};
char yyextra[] ={
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
/*	ncform	4.1	83/08/11	*/

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
yylook(){
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)(void) fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank){		/* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
			*yylastch++ = yych = input();
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				(void) fprintf(yyout,"char ");
				allprint(yych);
				(void) putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)(void) fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					(void) fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					(void) putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)(void) fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				(void) fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				(void) putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			(void) fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			(void) putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					(void) fprintf(yyout,"\nmatch ");
					sprint(yytext);
					(void) fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)(void) putchar('\n');
# endif
		}
	}
yyback(p, m)
	int *p;
{
if (p==0) return(0);
while (*p)
	{
	if (*p++ == m)
		return(1);
	}
return(0);
}
	/* the following are only used in the lex library */
yyinput(){
	return(input());
	}
yyoutput(c)
  int c; {
	output(c);
	}
yyunput(c)
   int c; {
	unput(c);
	}
