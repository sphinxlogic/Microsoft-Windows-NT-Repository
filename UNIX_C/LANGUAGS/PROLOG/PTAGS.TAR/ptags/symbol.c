#include <stdio.h>
#include "ptags.h"

/*
 * ptags - creates entries in a tags file for Prolog predicates
 * 
 * Usage: ptags [-w] [-l] [-a] [-p] file1 ... filen
 * 
 * This program code may be freely distributed provided
 * 
 *     a) it, or any part of it, is not sold for profit; and
 * 
 *     b) this entire comment remains intact.
 * 
 * Copyright (c) 1988, Chris Tweed & Bob Kemp, EdCAAD,
 * University of Edinburgh
 * 
 * Please mail us any changes, enhancements, or bug fixes.
 * 
 * Chris Tweed
 * chris@caad.ed.ac.uk
 * ...!mcvax!ukc!edcaad!chris
 * 
 * or
 * 
 * Bob Kemp
 * bob@caad.ed.ac.uk
 * ...!mcvax!ukc!edcaad!bob
 * 
 */

extern	BOOL	warnings;
local	int	nsym = 0;
local	SYMBOL	symbol[MAXSYM];

/*
 * global SYMBOL *
 * install(name, file)
 *
 * Installs a symbol in the symbol table.  NOTE: it doesn't check
 * if the symbol has already been entered.
 *
 */

global SYMBOL *
install(name, file)
char *name;				/* predicate name */
char *file;				/* name of file where pred is defined */
{
	extern	SYMBOL	*new_sym();
	extern	char	*strcpy();
	SYMBOL *sym;

	if ((sym = new_sym()) == NOSYM)
	    return NOSYM;
	VOID strcpy(sym->name, name);
	sym->file = file;

	return sym;
}

/*
 * local SYMBOL *
 * new_sym()
 *
 * Returns a pointer to a new symbol, or NOSYM (NULL) if no
 * space is available.
 *
 */

local SYMBOL *
new_sym()
{
	extern char *progname;

	if (nsym < MAXSYM)
	    return &symbol[nsym++];
	else {
	    fprintf(stderr, "%s: too many symbols\n", progname);
	    return NOSYM;
	}
}

/*
 * global SYMBOL *
 * lookup(name)
 *
 * Returns pointer to symbol if it is in the symbol table; otherwise
 * it returns NOSYM (NULL).
 *
 */

global SYMBOL *
lookup(name)
REG char *name;
{
	extern	int	nsym;
	REG int i;

	for (i = 0; i < nsym; i++)
	    if (STREQ(name, symbol[i].name))
		return &symbol[i];

	return NOSYM;
}
