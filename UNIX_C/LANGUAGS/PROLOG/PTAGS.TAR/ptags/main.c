#include <stdio.h>
#include <sys/param.h>
#include <sys/stat.h>
#include "ptags.h"

/*
 * ptags - creates entries in a tags file for Prolog predicates
 * 
 * Usage: ptags [-w] [-l] [-a] [-p] file1 ... filen
 * 
 * This program code may be freely distributed provided
 * 
 *     a) it, or any part of it, is not sold for profit; and
 * 
 *     b) this entire comment remains intact.
 * 
 * Copyright (c) 1988, Chris Tweed & Bob Kemp, EdCAAD,
 * University of Edinburgh
 * 
 * Please mail us any changes, enhancements, or bug fixes.
 * 
 * Chris Tweed
 * chris@caad.ed.ac.uk
 * ...!mcvax!ukc!edcaad!chris
 * 
 * or
 * 
 * Bob Kemp
 * bob@caad.ed.ac.uk
 * ...!mcvax!ukc!edcaad!bob
 * 
 */

#define TEMPLATE	"/tmp/ptXXXXXXXX"

/* shorthand for usage messages */
#define USE(mesg)	VOID fprintf(stderr, mesg)

global	char	*progname;		/* name of this program */
global	BOOL	warnings = TRUE;	/* warns of defs across files if TRUE */
global	BOOL	lines = FALSE;		/* TRUE for line numbers in tags file */
global	BOOL	appending = FALSE;	/* append to existing tags if TRUE */
global	BOOL	piping = FALSE;		/* send output to stdout if TRUE */
global	char	*cfile;			/* current input filename */
global	char	*filename[MAXFILE];	/* list of filenames to be processed */
global	int	nf = 0;			/* number of files to be processed */
global	FILE	*tags;			/* pointer to the tags file */

local	void	usage();		/* displays usage and EXITS */

main(argc, argv)
int argc;
char *argv[];
{
	extern	char	*strcpy();
	extern	char	*mktemp();
	extern	FILE	*fopen();
	extern	BOOL	process_file();
        int i;
	char *p;
	FILE *ifp;
	char tagfile[MAXPATHLEN];
	char cmd[MAXPATHLEN];
	struct stat stbuf;

#if BSD4_2
	setlinebuf(stderr);
#endif
 
        progname = argv[0];
	/* process arguments */
	while (--argc) {
	    if (argv[1][0] == '-') {
		p = argv[1] + 1;
		if (p == NOSTR)
		    usage(progname);			/* EXITS */
		while(*p) {
		    switch(*p) {
			case 'w':
			    warnings = FALSE;
			    break;
			case 'l':
			    lines = TRUE;
			    break;
			case 'a':
			    appending = TRUE;
			    break;
			case 'p':		/* send output to stdout */
			    piping = TRUE;
			    break;
			default:
			    VOID usage(progname);	/* EXITS */
			    break;
		    }
		    p++;
		}
	    } else if (nf < MAXFILE)
		filename[nf++] = argv[1];
	    else {
		VOID fprintf(stderr, "%s: too many files\n", progname);
		exit(1);
	    }
	    argv++;
	}

	if (nf == 0)
	    usage(progname);	/* EXITS */

	/* open temporary tags file */
	VOID strcpy(tagfile, TEMPLATE);
	VOID mktemp(tagfile);
	/* if appending, copy existing tags file */
	if (appending && stat("./tags", &stbuf) == 0) {
	    VOID sprintf(cmd, "cp tags %s", tagfile);
	    if (system(cmd) != 0) {
		VOID fprintf(stderr, "%s: error copying existing tags file\n",
			tagfile);
	    }
	    tags = fopen(tagfile, "a");
	} else
	    tags = fopen(tagfile, "w");

	if (tags == NULL) {
	    VOID fprintf(stderr, "%s: can't open tags file\n", progname);
	    exit(1);
	}

	for(i=0; i<nf; i++) {
	    cfile = filename[i];
	    /* open input file */
	    ifp = fopen(cfile, "r");
	    if (ifp == NULL) {
		VOID fprintf(stderr, "%s: can't open %s\n", progname, cfile);
		continue;
	    }
	    /* process the file */
	    VOID process_file(ifp);
	    VOID fclose(ifp);
	}
	VOID fclose(tags);
	if (piping == TRUE)
	    VOID sprintf(cmd, "sort %s", tagfile);
	else
	    VOID sprintf(cmd, "sort %s > tags", tagfile);
	if (system(cmd) == 0)
	    VOID unlink(tagfile);
	else {
	    VOID fprintf(stderr, "%s: error copying temp file (%s)\n",
				 progname,
				 tagfile);
	    exit(1);
	}
}

/*
 * local void
 * usage(s)
 *
 * Prints usage and EXITS.
 *
 */

local void
usage(s)
char *s;
{
	VOID fprintf(stderr, "usage: %s\n", s);
	USE("\t\t[-w]\t/* suppress warnings about multiple defs */\n");
	USE("\t\t[-l]\t/* use line numbers instead of search strings */\n");
	USE("\t\t[-a]\t/* append to tags file */\n");
	USE("\t\t[-p]\t/* send output to stdout */\n");
	USE("\t\tfile1 ... filen\n");
	exit(1);
}
