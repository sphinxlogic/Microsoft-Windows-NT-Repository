/* header file to define system dependent things */

/*
 * ptags - creates entries in a tags file for Prolog predicates
 * 
 * Usage: ptags [-w] [-l] [-a] [-p] file1 ... filen
 * 
 * This program code may be freely distributed provided
 * 
 *     a) it, or any part of it, is not sold for profit; and
 * 
 *     b) this entire comment remains intact.
 * 
 * Copyright (c) 1988, Chris Tweed & Bob Kemp, EdCAAD,
 * University of Edinburgh
 * 
 * Please mail us any changes, enhancements, or bug fixes.
 * 
 * Chris Tweed
 * chris@caad.ed.ac.uk
 * ...!mcvax!ukc!edcaad!chris
 * 
 * or
 * 
 * Bob Kemp
 * bob@caad.ed.ac.uk
 * ...!mcvax!ukc!edcaad!bob
 * 
 */


#if SYSV
#    define INDEX	strchr
#else BSD4_2
#    define INDEX	index
#endif

/*
 * According to "Programming in Prolog", Clocksin and Mellish,
 * Springer-Verlag, 1981, Prolog has two types of atom: one
 * composed of letters and digits, and one composed of symbols.
 * In ptags we need to recognise both and distinguish between them
 * because they determine the valid characters in predicate names.
 *
 * The definitions used below are those used in C-Prolog 1.5+, but
 * your Prolog may be different.  C-Prolog differs from Clocksin
 * and Mellish in that '$' has the same status as alphanumeric
 * characters and is not, therefore, a symbol.  Check your Prolog
 * and edit these definitions if necessary.
 *
 * Also defined is a line comment character which may be different
 * in your Prolog.
 *
 */

/* valid symbol characters - NOTE '$' is not one of these */
#define SYM_CHRS	"+-*/\\^<>=`~:.?@#&"

/* test for valid symbol characters */
#define IS_SYM(c)	(INDEX(SYM_CHRS, c) != NULL)

/* test for valid character at start of predicate name */
#define BEGIN_NAME(c)	(islower(c) || c == '\'' || c == '$')

/* test for valid characters within predicate name */
#define IN_NAME(c)	(isalnum(c) || c == '_' || c == '$')

#define L_COMMENT_CHR	'%'
