a(b) :- true.
/**/
c(b) :- true.
d(b).
