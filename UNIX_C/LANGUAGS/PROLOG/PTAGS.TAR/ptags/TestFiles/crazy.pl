/* crazy program layout */

c(A, B)
:-
			a(A),




b(B).

d(a(_),D) :-
    b(D).
