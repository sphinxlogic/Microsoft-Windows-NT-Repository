:- b, c, d.

a.

/* hello .
x.
*/

/**
m.
**/

/***
n.
**/

b(x,
	y) :-
	c(x),
	d(y,z).

c
	(x, a) :-
	zxc(a).

d :- true.	% hi!

e% .
zzz.

f/* . */ x .

