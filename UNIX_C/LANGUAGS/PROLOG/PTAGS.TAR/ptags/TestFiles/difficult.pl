:- b, c, d.

a.

/* hello .
x.
*/

:- op(500, xfx, '.').

b(n.n,
	y) :-
	c(x),
	d(y,z).

c(
	x, a) :-
	zxc(a).

'a b c'(A,1.2) :-
    a(A),
    b(B).

d("a dot. followed by white space", "", "and a quote in a string""") :-
  it_works(ok).

e :- true.	% hi!

:- op(300, fx, f).
/* below should be interpretable as 'f yyy.' */
f% .
yyy.

'z & () . zz'.

:- op(300, fx, g).
g/* . */ x .

h(a).

/* symbolic atoms as predicate names */

++(X).
+.+(X).
&+`(X).
~*\/#?```=(X).

/* some really tricky ones ;-) */
x/*******/y(X).
*/**/*(X).
/*******/y(X).
/**/*(X).
x/***//****/y(X).
