/*
 * ptags - creates entries in a tags file for Prolog predicates
 * 
 * Usage: ptags [-w] [-l] [-a] [-p] file1 ... filen
 * 
 * This program code may be freely distributed provided
 * 
 *     a) it, or any part of it, is not sold for profit; and
 * 
 *     b) this entire comment remains intact.
 * 
 * Copyright (c) 1988, Chris Tweed & Bob Kemp, EdCAAD,
 * University of Edinburgh
 * 
 * Please mail us any changes, enhancements, or bug fixes.
 * 
 * Chris Tweed
 * chris@caad.ed.ac.uk
 * ...!mcvax!ukc!edcaad!chris
 * 
 * or
 * 
 * Bob Kemp
 * bob@caad.ed.ac.uk
 * ...!mcvax!ukc!edcaad!bob
 * 
 */

#define local			static
#define global
#define VOID			(void)
#define REG			register
#define BOOL			int

#define MAXFILE			128
#define MAXSYM			1024
#define MAXSTR			256
#define MAXBUF			MAXSTR

#define TRUE			1
#define FALSE			0

#define FSEP			'\t'

typedef struct symbol {
    char name[MAXSTR];
    char *file;
} SYMBOL;

/* NULLS etc. */

#define NOSYM		(SYMBOL *)0
#define NOSTR		(char *)0
#define NOOP		0

/* MISC */
#define	EOSTR		'\0'

/* MACROS */
#define STREQ(s1, s2)	(strcmp((s1), (s2))==0)		/* string compare */

