#include <stdio.h>
#include <ctype.h>
#include "config.h"
#include "ptags.h"

/*
 * ptags - creates entries in a tags file for Prolog predicates
 * 
 * Usage: ptags [-w] [-l] [-a] [-p] file1 ... filen
 * 
 * This program code may be freely distributed provided
 * 
 *     a) it, or any part of it, is not sold for profit; and
 * 
 *     b) this entire comment remains intact.
 * 
 * Copyright (c) 1988, Chris Tweed & Bob Kemp, EdCAAD,
 * University of Edinburgh
 * 
 * Please mail us any changes, enhancements, or bug fixes.
 * 
 * Chris Tweed
 * chris@caad.ed.ac.uk
 * ...!mcvax!ukc!edcaad!chris
 * 
 * or
 * 
 * Bob Kemp
 * bob@caad.ed.ac.uk
 * ...!mcvax!ukc!edcaad!bob
 * 
 */

/* lexical states */

#define	S_SPACE		1
#define	S_NAME		2
#define	S_SYM		3
#define	S_CLAUSE	4
#define	S_DOT		5
#define	S_STR		6
#define	S_QUOTE		7

/* define characters that must be escaped in regular expressions */
#define ESC_CHRS	".\\$*%&^/[]"

/* print character - with escape if necessary */
#define PRINTC(ch, fp)	if (INDEX(ESC_CHRS, ch) != NULL) { \
			    VOID fprintf(fp, "\\%c", ch); \
			} else VOID putc(ch, fp)

extern	char	*INDEX();
extern	SYMBOL	*lookup();
local	void	skip_comment();		/* skips comments in source */
local	int	skip_to_chr();		/* move read pointer to chr */
local	BOOL	print_tag();		/* print the tag */
local	void	print_search();		/* print search string */

local	int	lineno = 1;		/* line number in input file */

/*
 * global BOOL
 * process_file(fp)
 *
 * Main processing routine.
 *
 */

global BOOL
process_file(fp)
FILE *fp;				/* pointer to current file */
{
	extern	char	*strcpy();
	extern	char	*progname;	/* name of this program */
	extern	char	*cfile;		/* name of current file */
	char buff[MAXSTR];		/* buffer */
	REG int chno = 0;		/* current position in buff */
	REG int state = S_SPACE;	/* state of the parser */
	int pstate = S_SPACE;		/* previous state */
	REG int ch;			/* current character */
	REG int lastch = EOSTR;		/* previous character */
	int c;				/* temporary character store */
	int startno;
	BOOL inquote = FALSE;

	lineno = 1;

	for (chno = 0; chno < MAXSTR; chno++)
	    buff[chno] = EOSTR;

	while ((ch = getc(fp)) != EOF ) {

	    if (ch == '\n')
		lineno++;

	    switch (state) {
	    case S_SPACE:		/* in whitespace preceding clause */
		if (!isspace(ch)) {	/* usually will be space */
		    if (ch == L_COMMENT_CHR)
			skip_comment(ch, fp);
		    else if (ch == '\'') {
			state = S_QUOTE;
		    } else if (ch == '"' && ! inquote) {
			pstate = state;
			state = S_STR;
		    } else if (BEGIN_NAME(ch)) {
			state = S_NAME;
			buff[0] = ch;
			chno = 1;
		    /* look for comments */
		    } else if (ch == '/') {
			if ((c=getc(fp)) == '*') {
			    skip_comment(c, fp);
			} else {
			    ungetc(c, fp);
			    state = S_SYM;
			    buff[0] = ch;
			    chno = 1;
			}
		    } else if (IS_SYM(ch)) {
			state = S_SYM;
			buff[0] = ch;
			chno = 1;
		    } else if (ch != '/') /* skip "rubbish" */
			state = S_CLAUSE;
		}
		break;
	    case S_NAME:		/* in predicate name */
		/* FALLS THROUGH */
	    case S_SYM:
		/* weed out directives and queries */
		if (chno == 1 && ch == '-' &&
				(lastch == ':' || lastch == '?')) {
		    state = S_CLAUSE;
		    break;
		}
			
		if (chno == MAXSTR) {
		    VOID fprintf(stderr,
			    "%s: predicate name too long at line %d\n",
			    progname, lineno);
		    return FALSE;
		}
		buff[chno++] = ch;
		if (ch == '\'') {
		    state = S_QUOTE;
		} else if (inquote) {
		    break;
		} else if (state == S_NAME && ch == '.') {
		    state = S_DOT;
		} else if (ch == '/') {		/* comment in symbol or name */
		    /* weed comments out */
		    if ((c=getc(fp)) == '*') {
			skip_comment(c, fp);
			chno--;
			break;
		    } else {
			ungetc(c, fp);
			if (state == S_NAME)
			    state = S_CLAUSE;
		    }
		} else if ((state == S_NAME && ! IN_NAME(ch)) ||
				    (state == S_SYM && !IS_SYM(ch)))
		    state = S_CLAUSE;

		if (state != S_NAME && state != S_SYM) {
		    buff[--chno] = EOSTR;
		    if (print_tag(buff, ch, lineno) == FALSE)
			exit(1);
		}
		if (ch == L_COMMENT_CHR)
		    skip_comment(ch, fp);
		break;
	    case S_CLAUSE:		/* in the clause text */
		if (ch == '\'') {
		    inquote = (! inquote);
		} else if (inquote)
		    break;
		else if (ch == L_COMMENT_CHR) {
		    skip_comment(ch, fp);
		} else if (ch == '"') {
		    pstate = state;
		    state = S_STR;
		} else if (ch == '.')
		    state = S_DOT;
		else if (ch == '*' && lastch == '/')
		    skip_comment(ch, fp);
		break;
	    case S_DOT:
		if (isspace(ch))
		    state = S_SPACE;
		else
		    state = S_CLAUSE;
		break;
	    case S_STR:
	    /* we're not really interested in strings, but we want to
	     * get them out of the way as soon as possible because they
	     * may contain nasty things like a dot (.) followed by
	     * white space which would otherwise throw the states off.
	     * Note that we must also allow for "" within a string as
	     * this is used to put a single " into the string.
	     */
		startno = lineno;
		do {
		    if (skip_to_chr(fp, ch, '"') == EOF) {
			fprintf(stderr,
			"%s: can't find end of string on line %d in %s\n",
			progname, startno, cfile);
			exit(1);
		    }
		} while((ch = getc(fp)) == '"');
		state = pstate;
		break;
	    case S_QUOTE:
		inquote = ( ! inquote);
		if (inquote) {
		    state = S_NAME;
		    buff[0] = '\'';
		    buff[1] = ch;
		    chno = 2;
		} else
		    state = S_CLAUSE;
		break;
	    }
	    lastch = ch;
	}
	return TRUE;
}

/*
 * local void
 * skip_comment(ch, fp)
 *
 * Move reading position to beyond end of comment.
 *
 */

local void
skip_comment(ch, fp)
FILE *fp;				/* pointer to current file */
REG int ch;				/* current input character */
{
	extern	char	*progname;
	extern	char	*cfile;
	int startno = lineno;

	if (ch == L_COMMENT_CHR) { /* rest-of-line comment */
	    while ((ch = getc(fp)) != '\n')
		if (ch == EOF)
			return;
	    lineno++;
	} else {	/* this style of comment (slash-star star-slash) */
	    do {
		if (skip_to_chr(fp, ch, '*') == EOF) {
		    fprintf(stderr,
			"%s: can't find end of comment, from line %d in %s\n",
			progname, startno, cfile);
		    exit(1);
		}
		while ((ch = getc(fp)) == '*')
		    ;
	    } while (ch != '/');
	}
}

/*
 * local BOOL
 * print_tag(fn_name, followch, lno)
 *
 * Process the predicate name, removing initial quotes if necessary.
 * Quotes must be retained in the search string.
 *
 */

local BOOL
print_tag(fn_name, followch, lno)
char *fn_name;					/* predicate name */
char followch;					/* char immediately after it */
int lno;					/* current line number */
{
	extern	SYMBOL	*install();
	extern	char	*progname;	/* program name */
	extern	char	*cfile;		/* current source filename */
	extern	FILE	*tags;		/* pointer to tags file */
	extern	BOOL	lines;		/* TRUE if line numbers are requested */
	extern	BOOL	warnings;	/* warn about multiple defs? */
	REG SYMBOL *sym;		/* symbol table entry */
	REG char *p;

	/* skip initial quote if necessary */
	p = (*fn_name == '\'') ? fn_name+1 : fn_name;

	if ((sym = lookup(p)) == NOSYM) {
#if DEBUG
	    VOID printf("process_head: installing %s\n", s);
#endif
	    if (install(p, cfile) == NOSYM)
		return FALSE;
	} else if (warnings && sym->file != cfile) {
	    VOID fprintf(stderr,
		    "%s: warning - '%s' is defined in more than one file\n",
		    progname, p);
	    sym->file = cfile;	/* no more warnings for this file */
	} else	/* already recorded for this file */
	    return TRUE;

	if (lines == TRUE)	/* use line numbers */
	    VOID fprintf(tags, "%s\t%s\t%d\n", p, cfile, lno);
	else {	/* use search string */
	    VOID fprintf(tags, "%s\t%s\t", p, cfile);
	    VOID print_search(tags, fn_name, followch);
	}

	return TRUE;
}

/*
 * local void
 * print_search(fp, s, c)
 *
 * Construct a vi/ex regular expression as a search string, escaping
 * special characters if necessary.
 *
 */

local void
print_search(fp, s, c)
FILE *fp;
REG char *s;				/* string to search for */
char c;					/* trailing context character */
{
	/* The definition is assumed to start on a line of its own
	 * flush with the left margin.
	 */
	VOID fprintf(fp, "/^");
	for ( ; *s != EOSTR; s++)
	    PRINTC(*s, fp);
	/* Can't put these in search string */
	if (c != '\n' && c != '\r' && c != '\f')
	    PRINTC(c, fp);	/* print char following name */
	VOID fprintf(fp, "/\n");
}

/*
 * local int
 * skip_to_chr(fp, ch, match)
 *
 * Skips input up to match character.  Leaves ch at match.
 * Returns match or EOF on end-of-file.
 *
 */

local int
skip_to_chr(fp, ch, match)
FILE *fp;				/* pointer to current input file */
int ch;					/* current character */
char match;				/* character to match */
{
	extern	int	lineno;
	extern	char	*progname;	/* program name */
	extern	char	*cfile;		/* current input filename */

	while (ch != match) {
	    if (ch == '\n')
		lineno++;
	    else if (ch == EOF) {
		fprintf(stderr, "%s: character (%c) not matched in %s\n",
			progname, match, cfile);
		return EOF;
	    }
	    ch = getc(fp);
	}
	return ch;
}
