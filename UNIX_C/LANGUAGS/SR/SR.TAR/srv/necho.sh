: necho -- echo args without newline, for SYSV shells
echo "$@" '\c'
