/*  funcs.h -- declarations of all external C functions  */

extern	void	check_main ();		/* check.c */
extern	void	check_object ();	/* check.c */
extern	void	gen_config ();		/* gen.c */
extern	void	gen_exe ();		/* gen.c */
extern	int	main ();		/* main.c */
extern	void	make_obj_name ();	/* check.c */
extern	resp	res_search ();		/* bodies.c */
extern	void	setlimit ();		/* main.c */
extern	void	showlimits ();		/* main.c */
extern	void	srl_error ();		/* main.c */
extern	void	srl_warn ();		/* main.c */
extern	void	up_to_date ();		/* check.c */

#include "../util.h"
#include "../libc.h"
