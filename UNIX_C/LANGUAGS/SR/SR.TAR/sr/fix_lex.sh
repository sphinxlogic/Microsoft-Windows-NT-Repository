: edit lex output to diagnose overly long tokens.
: if this causes problems building, you can just skip this step.

/bin/ed lex.yy.c <<"==END=="
/\*yylastch++ = yych = input();/i
if (yylastch >= yytext+YYLMAX) {
    strcpy(yytext+30,"...");
    errmsg(E_FATAL,"token too long: %s",yytext);
    exit(1);
}
.
w
q
==END==
