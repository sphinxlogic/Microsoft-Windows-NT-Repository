: extract function definitions from files given as arguments
: [assumes coding style is "\ntype\nfuncname(args)" ]

awk	'/^[a-z_]* *\(.*\)/ { print prev"\t"$0"\t"FILENAME; prev=""; next }
	/^[a-zA-Z]/	{ prev = $0; next }
			{ prev = ""; next }'  $*   \
    | tee xxx \
    |  sed -e '/^static/d' -e 's/(.*)/()/' -e 's/ \*/*/' \
	-e '/;/d' -e '/if[^a-z_]/d' -e '/while[^a-z_]/d' \
	-e 's;	.*	;&	/* ;' -e 's;$; */;'
