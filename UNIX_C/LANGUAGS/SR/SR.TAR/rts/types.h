/*
 *  SR Run-Time Support.  Type Definitions.
 */

enum pr_type { INITIAL, FINAL, PROC };
enum st_type { OK, FAIL };
enum io_type { INPUT, OUTPUT };

typedef enum st_type status;	/* status for create, invoke, etc. */

typedef char *daddr;		/* address of data */
typedef int (*paddr)();		/* program address */

typedef struct class_st *class;	/* operation class */
typedef struct crb_st *crb;	/* create request block */
typedef struct memh_st *memh;	/* memory block header */
typedef struct oper_st *oper;	/* operation entry */
