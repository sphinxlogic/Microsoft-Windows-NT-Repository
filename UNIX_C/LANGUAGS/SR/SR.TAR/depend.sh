: add dependencies of C files to the Makefile
set -ev
sed '1,/^# >>DO NOT DELETE THIS LINE<< #/!d' Makefile		>Makefile.new
echo '#   "make depend" was last run:  '`date`			>> Makefile.new
cc -M *.c | sed -e '/usr.include/d' -e '/:$/d' -e 's|: ./|: |'	>> Makefile.new
mv Makefile Makefile.bak
mv Makefile.new Makefile
