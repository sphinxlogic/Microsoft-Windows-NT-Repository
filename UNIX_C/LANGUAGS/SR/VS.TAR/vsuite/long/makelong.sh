: makelong headfile prefix repstring tailfile - make file with long token

long="$3$3$3$3$3$3$3$3$3$3"
cat $1
$NECHO "$2$long$long$long$long$long$long$long$long$long$long$long$long"
cat $4
