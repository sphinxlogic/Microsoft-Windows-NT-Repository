#define	abort(x)	{ fprintf (stderr, "%s\n", (x)); exit (-1); }
#define	index	int
#define	bool	int
#define	TRUE	1
#define	FALSE	0
