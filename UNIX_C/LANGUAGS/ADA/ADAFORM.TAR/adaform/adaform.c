
main()

{
	printf("@comment(formatted with adaform v 1.3)\n");
	printf("@define(AdaResWord=B)\n");
	printf("@define(AdaComment=I)\n");
	printf("@define(AdaCommentWord=P)\n");
printf("@define(AdaCode=example, FaceCode R, LeftMargin 0, RightMargin 0,\n");
	printf("\t font SmallBodyFont, blanklines=hingekeep)\n");
	printf("@begin(AdaCode)\n");
	printf("@TabClear\n@TabDivide(10)\n");
	yylex();
	printf("@end(AdaCode)\n");
}

