typedef Object (*PFO)();

extern Object Find_Object ();
