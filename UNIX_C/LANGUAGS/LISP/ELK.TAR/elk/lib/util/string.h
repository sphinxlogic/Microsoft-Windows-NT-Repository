#define Make_C_String(from,to) {\
    register _n_;\
    if (TYPE(from) == T_Symbol)\
	from = SYMBOL(from)->name;\
    else if (TYPE(from) != T_String)\
	Wrong_Type_Combination (from, "string or symbol");\
    _n_ = STRING(from)->size;\
    to = alloca (_n_+1);\
    bcopy (STRING(from)->data, to, _n_);\
    to[_n_] = '\0';\
}
