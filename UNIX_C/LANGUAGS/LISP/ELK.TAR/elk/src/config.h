#ifndef CONFIG_H
#define CONFIG_H
/* Machine/compiler dependencies
 */

#ifdef mips
#  define VFORK
#  define TIME_H              <sys/time.h>
#  define VPRINTF
#  ifdef MIPSEB
#    define BIG_ENDIAN
#  endif
#  define TERMIO
#endif

#ifdef is68k
#  define VFORK
#  define BIG_ENDIAN
#  define CAN_LOAD_OBJ
#  define CAN_DUMP
#    define SEGMENT_SIZE      0x20000
#    define FILE_TEXT_START   sizeof(struct exec)
#    define MEM_TEXT_START    sizeof(struct exec)
#    define TEXT_LENGTH_ADJ   sizeof(struct exec)
#  define TIME_H              <sys/time.h>
#endif

#ifdef sun
#  define VFORK
#  define VPRINTF
#  define DIRENT              /* Remove this for SunOS 3.4 */
#  define BIG_ENDIAN
#  define CAN_LOAD_OBJ
#  define CAN_DUMP
#    define SEGMENT_SIZE      0x20000
#    define FILE_TEXT_START   sizeof(struct exec)
#    define MEM_TEXT_START    (PAGSIZ+sizeof(struct exec))
#    define TEXT_LENGTH_ADJ   sizeof(struct exec)
#    define XFLAG_BROKEN
#  define TIME_H              <sys/time.h>
#  define TERMIO              /* Remove this for SunOS 3.4 */
#endif

#ifdef vax
#  define VFORK
#  define CAN_LOAD_OBJ
#  define CAN_DUMP
#    define SEGMENT_SIZE      1024
#    define FILE_TEXT_START   1024
#    define MEM_TEXT_START    0
#    define TEXT_LENGTH_ADJ   0
#  define TIME_H              <sys/time.h>
#endif

#ifdef i386
#  define UNISTD
#  define DIRENT
#  define VPRINTF
#  define FCHMOD_BROKEN       /* It isn't there */
#  define USE_SIGNAL
#  define INIT_OBJECTS
#  define STACK_SIZE          (1024*512)
#  define random              rand
#  define srandom             srand
#  define MAX_OFILES          20
#  define bcopy(from,to,len)  memcpy(to,from,len)
#  define bzero(p,len)        memset(p,0,len)
#  define bcmp                memcmp
#  define TIME_H              <time.h>
#  define CAN_DUMP
#  define COFF
#    define PAGESIZE          4096
#  define TERMIO
#endif

#ifndef MAXPATHLEN
#  define MAXPATHLEN 1024
#endif


/* Constant definitions
 */

#define HEAP_SIZE            512       /* in KBytes */

#define OBARRAY_SIZE         1009

#define GLOBAL_GC_OBJ        100

#define AFTER_GC_FUNCS       50

#define STACK_MARGIN         (48*1024)  /* approx. stack_start - stkbase */

#define HEAP_MARGIN          (HEAP_SIZE/10*1024)

#define MAX_SYMBOL_LEN       1024

#define MAX_STRING_LEN       1024

#define MAX_MAX_OPEN_FILES   64

#define STRING_GROW_SIZE     64

#define DEF_PRINT_DEPTH      20
#define DEF_PRINT_LEN        1000

#define MAX_TYPE             128

#ifdef CAN_DUMP
#  define INITIAL_STK_OFFSET   (20*1024)       /* 2*NCARGS */
#endif

#endif
