#include <stdio.h>

#include "config.h"
#include "object.h"
#include "extern.h"
#include "macros.h"
