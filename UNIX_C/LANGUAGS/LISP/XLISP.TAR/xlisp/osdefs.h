/* osdefs.h - system specific function declarations */

extern LVAL xsystem(),xgetkey();

