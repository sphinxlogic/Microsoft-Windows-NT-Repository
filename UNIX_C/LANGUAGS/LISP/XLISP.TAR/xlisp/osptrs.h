/* osptrs.h - system specific function pointers */

{	"SYSTEM",	S,	xsystem	},
{	"GET-KEY",	S,	xgetkey	},


