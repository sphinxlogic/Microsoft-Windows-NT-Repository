#include "itran/tree.h"
#include <stdio.h>

#define N_SUBSTR(x) (Type((x)) == N_Binop ? Val2((x)) : 1)

/* q - convert a string into a list of one element */
nodeptr q(s)
char *s;
{
    return StrNode(s, strlen(s));
} 

/* concatinate n string lists using a binary tree representation */
nodeptr cat(n, slist)
int n;
nodeptr slist;
{
    nodeptr *p;
    nodeptr catstr;
    int size;

    catstr = slist;
    size = N_SUBSTR(catstr);
    for (p = &slist + 1; --n; ++p) {
	size += N_SUBSTR(*p);
	catstr = tree5(N_Binop, *p, catstr, *p, size);
	}
    return catstr;
}

/* item - return the nth item in the given list */
nodeptr item(slist, n)
nodeptr slist;
int n;
{
    int lsize;

    if (Type(slist) == N_Binop) {
	if ((lsize  = N_SUBSTR(Tree0(slist))) >= n)
	    return item(Tree0(slist), n);
	else
	    return item(Tree1(slist), n - lsize);
	}
    else {
	if (n == 1)
	    return slist;
	else
	    return NULL;
	}
}

treeprt(x)
nodeptr x;
{
    if (Type(x) == N_Binop) {
	treeprt(Tree0(x));
	treeprt(Tree1(x));
	}
    else
	printf("%s", Str0(x));
}
