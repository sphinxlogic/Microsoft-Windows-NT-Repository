/* empty file of C functions for variant translator */
