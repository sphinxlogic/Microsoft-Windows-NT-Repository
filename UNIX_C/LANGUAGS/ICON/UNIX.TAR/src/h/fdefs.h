
/*
 * Definitions of functions.
 */

/*
 * If this is a personalized interpreter, include definitions from the
 *  pi directory.
 */

#ifdef PersInterp
#include "../pi/fdefs.h"
#endif					/* PersInterp */

/*
 * These are the functions in the standard repertoire.
 */

FncDef(abs)
FncDef(any)
FncDef(bal)
FncDef(center)
FncDef(char)
FncDef(close)
FncDef(collect)
FncDef(copy)
FncDef(cset)
FncDef(delete)
FncDef(detab)
FncDef(display)
FncDef(entab)
FncDef(errorclear)
FncDef(exit)
FncDef(find)
FncDef(get)
FncDef(getenv)
FncDef(iand)
FncDef(icom)
FncDef(image)
FncDef(insert)
FncDef(integer)
FncDef(ior)
FncDef(ishift)
FncDef(ixor)
FncDef(left)
FncDef(list)
FncDef(many)
FncDef(map)
FncDef(match)
FncDef(member)
FncDef(move)
FncDef(numeric)
FncDef(open)
FncDef(ord)
FncDef(pop)
FncDef(pos)
FncDef(proc)
FncDef(pull)
FncDef(push)
FncDef(put)
FncDef(read)
FncDef(reads)
FncDef(real)
FncDef(remove)
FncDef(rename)
FncDef(repl)
FncDef(reverse)
FncDef(right)
FncDef(runerr)
FncDef(seek)
FncDef(seq)
FncDef(set)
FncDef(sort)
FncDef(stop)
FncDef(string)
FncDef(system)
FncDef(tab)
FncDef(table)
FncDef(trim)
FncDef(type)
FncDef(upto)
FncDef(where)
FncDef(write)
FncDef(writes)
#ifdef ExecImages
FncDef(save)
#endif					/* ExecImages */

/*
 * "System" functions.
 */

#ifdef SysFncs
FncDef(fsize)
#endif					/* SysFncs */

/*
 * Math functions.
 */

#ifdef MathFncs
FncDef(acos)
FncDef(asin)
FncDef(atan)
FncDef(atan2)
FncDef(cos)
FncDef(dtor)
FncDef(exp)
FncDef(log)
FncDef(log10)
FncDef(rtod)
FncDef(sin)
FncDef(sqrt)
FncDef(tan)
#endif					/* MathFncs */

/*
 * Functions for MS-DOS.
 */


#ifdef DosFncs
FncDef(getch)
FncDef(getche)
FncDef(kbhit)
FncDef(Int86)
FncDef(Peek)
FncDef(Poke)
FncDef(GetSpace)
FncDef(FreeSpace)
FncDef(InPort)
FncDef(OutPort)
#endif					/* DosFncs */

/*
 * "Iscope" functions.
 */

#ifdef ScopeFncs
FncDef(Descr)
FncDef(Dword)
FncDef(Indir)
FncDef(Ivar)
FncDef(Symbol)
FncDef(Vword)
#endif					/* ScopeFncs */

/*
 * Memory monitoring functions.
 */

#ifdef MMFncs
FncDef(mmpause)
FncDef(mmshow)
#endif					/* MMFncs */

/*
 * Instrumentation functions.
 */

#ifdef InstrFncs
FncDef(runstats)
#endif					/* InstrFncs */
