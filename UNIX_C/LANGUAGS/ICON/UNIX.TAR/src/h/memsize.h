/*
 * Memory sizing.  This should be redone to handle the various cases
 *  more coherently.
 */
#ifdef FixedRegions
#undef IconAlloc
#endif					/* FixedRegions */

/*
 * Constants for computers with a large amount of memory.
 */

#ifndef FixedRegions

/*
 * Expandable regions.
 */
#define MaxAbrSize		51200	/* size of the block region in bytes */
#define MaxStrSpace		51200	/* size of the string space in bytes */
#ifdef NoCoexpr
#define MaxStatSize		  500	/* size of static region in bytes */
#define ActStkBlkEnts		    1	/* number of entries in an astkblk */
#else					/* NoCoexpr */
#define MaxStatSize		20480	/* size of the static region in bytes*/
#define ActStkBlkEnts		  100	/* number of entries in an astkblk */
#endif					/* NoCoexpr */
#define MStackSize		10000	/* size of the main stack in words */
#define StackSize		 2000	/* words in co-expression stack */

#else					/* FixedRegions */

/*
 * Fixed regions.
 */
#define MaxAbrSize		64000	/* size of block region in bytes */
#define MaxStrSpace		64000	/* size of string space in bytes */
#ifdef NoCoexpr
#define MaxStatSize		  500	/* size of static region in bytes */
#define ActStkBlkEnts		    1	/* number of entries in an astkblk */
#else					/* NoCoexpr */
#define MaxStatSize		 2200	/* size of static region in bytes */
#define ActStkBlkEnts		  100  /* number of entries in an astkblk */
#endif					/* NoCoexpr */
#define QualLstSize		 5000	/* size of qualifier pointer region */
#define MStackSize		 5000	/* size of the main stack in words */
#define StackSize		 2000	/* size of co-expression stack */
#endif					/* FixedRegions */

/*
 * The following code is operating-system dependent. Override
 *  memory sizing if necessary
 */

#if PORT
   /* nothing to do */
#endif					/* PORT */

#if AMIGA
#endif					/* AMIGA */

#if ATARI_ST
/*
 * Sizes needed to run reasonable icon programs on Atari 520 using ash
 */
#undef QualLstSize
#undef MaxAbrSize
#undef MaxStrSpace
#undef MaxStatSize
#undef MStackSize
#undef StackSize
#define QualLstSize		10000	/* size of qualifier pointer region */
#define MaxAbrSize		37500	/* size of the block region in bytes */
#define MaxStrSpace		37500	/* size of the string space in bytes */
#define MaxStatSize		  100	/* size of the static region in bytes*/
#define MStackSize		 9500	/* size of the main stack in words */
#define StackSize		   50	/* words in co-expression stack */
#endif					/* ATARI_ST */

#if MSDOS
#ifndef FixedRegions
/*
 * MS-DOS has only 640k of address space.
 */
#undef QualLstSize
#undef MaxAbrSize
#undef MaxStrSpace
#undef MaxStatSize
#undef MStackSize
#undef StackSize
#undef SSlots
#undef TSlots
#undef ActStkBlkEnts

#define MaxAbrSize		10240	/* size of the block region in bytes */
#define MaxStrSpace		10240	/* size of the string space in bytes */
#ifdef NoCoexpr
#define MaxStatSize		  500	/* size of static region in bytes */
#define ActStkBlkEnts		    1	/* number of entries in an astkblk */
#else					/* NoCoexpr */
#define MaxStatSize		 4096	/* size of the static region in bytes*/
#define ActStkBlkEnts		  100	/* number of entries in an astkblk */
#endif					/* NoCoexpr */
#define MStackSize		 3000	/* size of the main stack in words */
#define StackSize		 1000	/* words in co-expression stack */
#endif					/* FixedRegions */
#endif					/* MSDOS */

#if MACINTOSH || UNIX || VMS
   /* nothing to do */
#endif					/* MACINTOSH || UNIX || VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */
