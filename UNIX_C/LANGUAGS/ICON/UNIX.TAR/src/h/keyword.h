/*
 * Keyword definitions.
 */

#define K_ASCII		 1
#define K_CLOCK		 2
#define K_COLLECTIONS	 3
#define K_CSET		 4
#define K_CURRENT	 5
#define K_DATE		 6
#define K_DATELINE	 7
#define K_DIGITS	 8
#define K_ERROR		 9
#define K_ERRORNUMBER	10
#define K_ERRORTEXT	11
#define K_ERRORVALUE	12
#define K_ERROUT	13
#define K_FAIL		14
#define K_FEATURES	15
#define K_FILE		16
#define K_HOST		17
#define K_INPUT		18
#define K_LCASE		19
#define K_LEVEL		20
#define K_LINE		21
#define K_MAIN		22
#define K_NULL		23
#define K_OUTPUT	24
#define K_POS		25
#define K_RANDOM	26
#define K_REGIONS	27
#define K_SOURCE	28
#define K_STORAGE	29
#define K_SUBJECT	30
#define K_TIME		31
#define K_TRACE		32
#define K_UCASE		33
#define K_VERSION	34
