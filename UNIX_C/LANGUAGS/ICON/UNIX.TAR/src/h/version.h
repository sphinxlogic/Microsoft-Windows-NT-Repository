
/*
 * Value of &version
 */
#define VERSION	"Icon Version 7.0.  February 21, 1988."

/*
 * Version numbers to be sure ucode is compatible with the linker
 * and icode is compatible with the run-time system.
 */

#define UVersion "U7.0.000"

#define IVersion "I7.0.000"
