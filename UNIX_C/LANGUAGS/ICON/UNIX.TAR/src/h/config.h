/*
 *  Icon configuration. This file is produced when the Icon system is
 *  set up.
 */

/*
 *  A number of symbols are defined here.  Some are specific to individual
 *  to operating systems.  Examples are:
 *
 *	MSDOS		MS-DOS for PCs
 *	UNIX		any UNIX system
 *	VMS		VMS for the VAX
 *
 *  These are defined to be 1 or 0 depending on which operating system
 *  the installation is being done under.  They are all defined and only
 *  one is defined to be 1.  (They are used in the form #if VAX || MSDOS.)
 *
 *  There also are definitions of symbols for specific computers and
 *  versions of operating systems.  These include:
 *
 *	SUN		code specific to the Sun Workstation
 *	LATTICE		code specific to the Lattice C compiler for MS-DOS
 *
 *  Other definitions may occur for special configurations. These include:
 *
 *	DeBug		debugging code
 *	MemMon		color-graphics memory monitoring
 *	RunStats	run-time statistics gathering
 *	TranStats	translator statistics gathering
 *
 *  Other definitions perform configurations that are common to several
 *  systems. Examples are:
 *
 *	Double		align reals at double-word boundaries
 *	ZeroDivide	enable C code to test for division by real zero.
 *
 */

/*
 *  The following definitions are system-specific.
 */
#include "../h/define.h"

/*
 * Set up typedefs and related definitions depending on whether or not
 * ints and pointers are the same size.
 */

#ifndef ErrorExit
#define ErrorExit 1
#endif					/* ErrorExit */

#ifndef NormalExit
#define NormalExit 0
#endif					/* NormalExit */

#ifndef Hz
#define Hz 60
#endif					/* Hz */

#ifndef MaxHdr
#define MaxHdr 4096
#endif					/* MaxHdr */

#ifndef SysTime
#define SysTime <time.h>
#endif					/* SysTime */

#ifndef Fork
#define Fork fork
#endif					/* Fork */

#ifndef WordBits
#define WordBits 32
#endif					/* WordBits */

#ifndef IntBits
#define IntBits WordBits
#endif					/* IntBits */

#if IntBits == 16
typedef long int word;
typedef unsigned long int uword;
#else					/* WordBits != IntBits */
typedef int word;
typedef unsigned int uword;
#endif					/* WordBits != IntBits */

#define WordSize sizeof(word)

#ifndef ByteBits
#define ByteBits 8
#endif					/* ByteBits */

/*
 * Change the name of gcvt() if we're supplying our own version,
 * to avoid complaints under VMS and maybe others with shared libraries.
 */

#ifdef IconGcvt
#define gcvt icon_gcvt
#endif					/* IconGcvt */


/*
 *  The following definitions depend on whether or not the ANSI C standard
 *  is supported.
 */

#ifdef Standard
#define Cat(x,y) x##y
#define Lit(x) #x
typedef void *pointer;
#else					/* Standard */
#define Ident(x) x
#define Cat(x,y) Ident(x)y
#define Lit(x) "x"
typedef char *pointer;
#endif					/* Standard */

/*
 * The following definitions insure that all the symbols for operating
 * systems that are not relevant are defined to be 0 -- so that they
 * can be used in logical expressions in #if directives.
 */

#ifndef PORT
#define PORT 0
#endif					/* PORT */

#ifndef AMIGA
#define AMIGA 0
#endif					/* AMIGA */

#ifndef ATARI_ST
#define ATARI_ST 0
#endif					/* ATARI_ST */

#ifndef MACINTOSH
#define MACINTOSH 0
#endif					/* MACINTOSH */

#ifndef MSDOS
#define MSDOS 0
#endif					/* MSDOS */

#ifndef MVS
#define MVS 0
#endif					/* MVS */

#ifndef UNIX
#define UNIX 0
#endif					/* UNIX */

#ifndef VM
#define VM 0
#endif					/* VM */

#ifndef VMS
#define VMS 0
#endif					/* VMS */

/*
 * Functions prototypes.
 */

#include "../h/proto.h"
