/*
 *  Configuration parameters that depend on computer architecture.
 *  Some depend on values defined in config.h, which is always
 *  included before this file.
 */

#ifndef CStateSize
#define CStateSize 15			/* size of C state for co-expressions */
#endif					/* CStateSize */

/*
 * The following definitions depend on the sizes of ints and pointers.
 */

/*
 * Most of the present implementations use 32-bit "words".  The section
 *  for 64-bit words is tentative and untested.  16-bit words are no
 *  longer supported.  Note that WordBits is the number of bits in an Icon
 *  integer, not necessarily the number of bits in an int (given by IntBits).
 *  For example, in MS-DOS an Icon integer is a long, not an int.
 */

/*
 * 64-bit words.  NOTE:  This section is under construction!
 */

#if WordBits == 64

#define MinLong	 ((long int)020000000000L) /* smallest long integer */
#define MaxLong  ((long int)017777777777L) /* largest long integer */
#define MaxStrLen	 07777777777L	/* maximum string length */

#define F_Nqual 0x8000000000000000	/* set if NOT string qualifier */
#define F_Var	0x4000000000000000	/* set if variable */
#define F_Tvar	0x2000000000000000	/* set if trapped variable */
#define F_Ptr	0x1000000000000000	/* set if value field is pointer */

#endif					/* WordBits == 64 */

/*
 * 32-bit words.
 */

#if WordBits == 32

#define MinLong  ((long int)020000000000L)   /* smallest long integer */
#define MaxLong  ((long int)017777777777L)   /* largest long integer */

#define MaxStrLen	     07777777	/* maximum string length */

#define F_Nqual 0x80000000		/* set if NOT string qualifier */
#define F_Var	0x40000000		/* set if variable */
#define F_Tvar	0x20000000		/* set if trapped variable */
#define F_Ptr	0x10000000		/* set if value field is pointer */
#endif					/* WordBits == 32 */

/* Values that depend on the number of bits in an int (not necessarily
 * the same as the number of bits in a word).
 */

#if IntBits == 64
#define LogIntBits		    6	/* log of IntBits */
#define MaxUnsigned 01777777777777777777777L /* largest unsigned integer */
#define MaxWord     0777777777777777777777L /* largest signed integer in word */
/*
 * Cset initialization macros.
 */
#define fwd(w0, w1, w2, w3)	((w0)&0xffff | (w1)<<16 | (w2)<<32 | (w3)<<48)
#define cset_display(w0,w1,w2,w3,w4,w5,w6,w7,w8,w9,wa,wb,wc,wd,we,wf) \
	{fwd(w0,w1,w2,w3),fwd(w4,w5,w6,w7),fwd(w8,w9,wa,wb),fwd(wc,wd,we,wf)}
#endif					/* IntBits == 64 */

#if IntBits == 32
#define LogIntBits		    5	/* log of IntBits */
#define MaxUnsigned 	 037777777777	/* largest unsigned integer */
#define MaxWord		 017777777777	/* largest signed integer in word */
/*
 * Cset initialization macros.
 */
#define twd(w0, w1)	((w0)&0xffff | (w1)<<16)
#define cset_display(w0,w1,w2,w3,w4,w5,w6,w7,w8,w9,wa,wb,wc,wd,we,wf) \
	{twd(w0,w1),twd(w2,w3),twd(w4,w5),twd(w6,w7), \
	 twd(w8,w9),twd(wa,wb),twd(wc,wd),twd(we,wf)}
#endif					/* IntBits == 32 */

#if IntBits == 16
#define LogIntBits	            4	/* log of IntBits */
#define MaxUnsigned ((unsigned int)0177777)	/* largest unsigned integer */
#define MaxWord ((long int)0x7fffffffL)	/* largest signed integer in word */
/*
 * Cset initialization macro.
 */
#define cset_display(w0,w1,w2,w3,w4,w5,w6,w7,w8,w9,wa,wb,wc,wd,we,wf) \
	{w0,w1,w2,w3,w4,w5,w6,w7,w8,w9,wa,wb,wc,wd,we,wf}
#endif					/* IntBits == 16 */

#ifndef LogHuge
#define LogHuge 309			/* maximum base-10 exp+1 of real */
#endif					/* LogHuge */

#ifndef Big
#define Big 9007199254740992.		/* larger than 2^53 lose precision */
#endif					/* Big */

#ifndef Precision
#define Precision 10			/* digits in string from real */
#endif					/* Precision */
