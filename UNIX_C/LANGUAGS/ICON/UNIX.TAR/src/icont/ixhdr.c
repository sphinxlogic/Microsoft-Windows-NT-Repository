#ifndef NoHeader
#include "../h/config.h"
#include "../h/cpuconf.h"
#include "../h/header.h"
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "../h/paths.h"

#ifdef MinHeader
#define syserr(x) _exit(ErrorExit)
#endif					/* MinHeader */

#ifndef Iconx
#define Iconx IconxPath
#endif					/* Iconx */

char *pptr;

main(argc,argv)
int argc;
#ifdef MaxArgs
char *argv[MaxArgs];
#else					/* MaxArgs */
char **argv;
#endif					/* MaxArgs */

   {
#ifndef NoEnvVars
   char *path, *getenv(), *sbrk();
#endif					/* NoEnvVars */

   char file[256];
   char *name;
   char **argvx;
   char *index();
   
#ifndef MaxArgs
   argvx = (char **)sbrk((argc + 2) * sizeof(char *));
   if (argvx < 0)
      syserr("iconx: inadequate space for arguments\n");
#endif					/* MaxArgs */

   name = argv[0];			/* name of icode file */
   do 
      argvx[argc+1] = argv[argc];
   while (argc--);
   argv = argvx;

   /*
    * If the name contains any slashes we skip the path search and
    *  just try to run the file.
    */
   if (index(name,'/'))
      doiconx(argv,name);
   
#ifndef NoEnvVars
   pptr = path = getenv("PATH");
   if (index(path,'.') == 0) {
      if (canrun(name))
         doiconx(argv,name);
      }
   while (trypath(name,file)) {
      if (canrun(file))
         doiconx(argv,file);
      }
#endif					/* NoEnvVars */

   /*
    * If we can't find it, we assume that it must exist somewhere
    *  and infer that it's in the current directory.
    */
   if (canrun(name))
      doiconx(argv,name);
   syserr("iconx: icode file not found\n");
   }

canrun(file)
char *file;
   {
   struct stat statb;
   if (access(file,5) == 0) {
      stat(file,&statb);
      if (statb.st_mode & S_IFREG)
         return 1;
      }
   return 0;
   }

doiconx(av,file)
char **av; char *file;
   {
   char *name;

   av[0] = "-iconx";
   av[1] = file;

#ifndef NoEnvVars
   name = getenv("ICONX");
   if ((name != NULL) && *name != '\0') {
      execv(name,av);
      syserr("iconx: can't execute\n");
      }
#endif					/* NoEnvVars */

   execv(Iconx,av);
   syserr("iconx: can't execute\n");
   }

trypath(name,file)
char *name, *file;
   {
   char c;
   
   while (*pptr == ':')
      pptr++;
   if (!*pptr)
      return 0;
   do {
      c = (*file++ = *pptr++);
      } while (c != ':' && c);
   pptr--;
   file--;
   
   *file++ = '/';
   while (*file++ = *name++);
   *file = 0;
   return 1;
   }

#ifndef MinHeader
syserr(s)
char *s;
   {
   write(2,s,strlen(s));
   _exit(ErrorExit);
   }
#endif					/* MinHeader */

#else					/* NoHeader */
char *junk;				/* avoid empty module */
#endif					/* NoHeader */
