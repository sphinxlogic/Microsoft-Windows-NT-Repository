#include <stdio.h>
#include "../h/config.h"
#include "../h/paths.h"

#ifdef strlen
#undef strlen				/* pre-defined in some contexts */
#endif					/* strlen */

/*
 * The following code is operating-system dependent.  Include
 *  system-dependent files and declarations.
 */

#if PORT
   /* nothing to do */
#endif					/* PORT */

#if AMIGA
#include <dos.h>
#endif					/* AMIGA */

#if ATARI_ST
int _mneed = 4096;			/* leave enough memory for exec */
int _stack = 2048;
#endif					/* ATARI_ST */

#if MACINTOSH || MSDOS || VMS
   /* nothing to do */
#endif					/* MACINTOSH || MSDOS || VMS */

#if UNIX
#include <sys/types.h>
#include <sys/stat.h>
#endif 					/* UNIX */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

#define MaxFlags 30
#define PathSize 100	/* maximum length of a fully qualified file name */

#ifndef Itran
#define Itran TranPath
#endif					/* Itran */

#ifndef Ilink
#define Ilink LinkPath
#endif					/* Ilink */

#ifndef Iconx
#define Iconx IconxPath
#endif					/* Iconx */

char **rfiles;
extern pointer calloc(), malloc();



/*
 * The following code is operating-system dependent.  Declaration of
 *  main() may vary.
 */

#if PORT
main(argc,argv,envp)
int argc;
char **argv, **envp;
   {
#endif					/* PORT */

#if AMIGA
main(argc,argv)
int argc;
char **argv;
   {
   static char *env = 0;
   static char **envp = env;
#endif					/* AMIGA */

#if ATARI_ST || MACINTOSH || MSDOS || UNIX || VMS
main(argc,argv,envp)
int argc;
char **argv, **envp;
   {
#endif					/* ATARI_ST || MACINTOSH || MSDOS ... */ 
#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */
   char **tfiles;
   char **lfiles;
   char **execlist;
   char *tflags[MaxFlags];
   char *lflags[MaxFlags];
   char **xargs;
   char *eflag;
   char *efile;
   int ntf, nlf, nrf, ntflags, nlflags, cflag, quiet;
   char **arg;
   char *base, *getbase();
   char *u1, *u2, *xfile;
   char *rindex(), *mkname();

   ntf = nlf = nrf = ntflags = nlflags = cflag = quiet = 0;
   xargs = NULL;
   eflag = NULL;
   efile = NULL;
   /*
    * Allocate space for lists.
    */
   rfiles = (char **)calloc((unsigned)2*(argc+10), sizeof(char **));
   tfiles = (char **)calloc((unsigned)argc+10, sizeof(char **));
   lfiles = (char **)calloc((unsigned)argc+10, sizeof(char **));
   execlist = (char **)calloc((unsigned)2*(argc+10), sizeof(char **));
   /*
    * Make sure the space was obtained.
    */
   if (rfiles == NULL || tfiles == NULL || lfiles == NULL || execlist == NULL) {
      fprintf(stderr, "icont: not enough memory\n");
      exit(ErrorExit);
      }

   tflags[ntflags++] = "itran";		/* translator arguments */
   lflags[nlflags++] = "ilink";		/* linker arguments */
   lflags[nlflags++] = "-i";
   lflags[nlflags++] = Iconx;
   xfile = "";

   for (arg = &argv[1]; arg <= &argv[argc-1]; arg++) {
      if ((*arg)[0] == '-') switch ((*arg)[1]) {
         case '\0': /* "-" */
            tfiles[ntf++] = *arg;
            lfiles[nlf++] = rfiles[nrf++]
              = "stdin.u1";
            rfiles[nrf++] = "stdin.u2";
            break;
         case 's':
            tflags[ntflags++] = "-s";
            quiet++;
            break;
         case 'o':
            lfiles[nlf++] = "-o";
            xfile = lfiles[nlf++] = *++arg;
            break;
         case 'x':
            xargs = ++arg;
            goto argsdone;
         case 'c':
            cflag++;
            break;
         case 'e':
            eflag = *arg;
            if (eflag[2] == '\0' && arg < &argv[argc-1])
               efile = *++arg;
            else
               efile = NULL;
            break;
         default:
            lflags[nlflags++] = tflags[ntflags++] = *arg;
            break;
            }
      else if (index(*arg,'.') == 0) {
         base = *arg;
         tfiles[ntf++] = mkname(base,".icn");
         goto ufiles;
         }
      else if (suffix(*arg,".icn")) {
         tfiles[ntf++] = *arg;
         base = getbase(*arg);
ufiles:
         u1 = mkname(base,".u1");
         u2 = mkname(base,".u2");
         lfiles[nlf++] = rfiles[nrf++] = u1;
         rfiles[nrf++] = u2;
         }
      else if (suffix(*arg,".u1")) {
         lfiles[nlf++] = *arg;
         }
      else if (suffix(*arg,".u"))
         lfiles[nlf++] = mkname(*arg,"1");
      else {
         fprintf(stderr,"icont: bad argument '%s'\n",*arg);
         exit(ErrorExit);
         }
      }
argsdone:
   if (nlf == 0)
      usage("icont");
   if (!xfile[0])
      xfile = getbase(lfiles[0]);

   if (ntf != 0) {
      tflags[ntflags] = NULL;
      tfiles[ntf] = NULL;
      lcat(execlist,tflags,tfiles);
      if (!quiet)
         report("Translating");
      runit(Itran,execlist,(char **)envp);
      }
   if (cflag) {
      exit(NormalExit);
      }
   if (!quiet) {
      report("Linking");
   }
   execlist[0] = 0;
   lflags[nlflags] = NULL;
   lfiles[nlf] = NULL;
   lcat(execlist,lflags,lfiles);
   runit(Ilink,execlist,(char **)envp);
   rmfiles();

/*
 * The following code is operating-system dependent.  It changes the
 *  mode of executable file so that it can be executed by anyone.
 *  Also can amend icode file name here.
 */

#if PORT
   /* something is needed */
#endif					/* PORT */

#if AMIGA
   /* not necessary */
#endif					/* AMIGA */

#if ATARI_ST || MSDOS || VMS
   strcat(xfile,".icx");
#endif					/* ATARI_ST || MSDOS || VMS */

#if MACINTOSH
#if MPW
      {
      static char *arg[] = {"SetFile","-t","TEXT","-c","Icon",0,0};
      arg[5] = xfile;
      docmd(arg[0],arg,envp);
      }
#endif					/* MPW */
#endif					/* MACINTOSH */

#if MSDOS
   chmod(xfile,0755);
#endif					/* MSDOS */

#if UNIX
      {
      struct stat stbuf;
      int u, r;

      /* Set each of the three execute bits (owner,group,other) if allowed by
         the current umask and if the corresponding read bit is set; otherwise
         preserve existing values */
      umask(u = umask(0));		/* get and restore umask */
      if (stat(xfile,&stbuf) == 0)  {	/* must first read existing mode */
         r = (stbuf.st_mode & 0444) >> 2;	/* get & position read bits */
         chmod(xfile,stbuf.st_mode | (r & ~u)); /* set execute bits */
         }
      }
#endif					/* UNIX */

#if VM || MVS
#endif					/* VM || MVS */

#if VMS
   /* nothing here because VMS Icon files aren't directly executable */
#endif					/* VMS */

/*
 * End of operating-system specific code.
 */

   if (xargs) {
      /*
       * Execute the program using part of the argument list for icont.
       */
      if (!quiet)
         report("Executing");
      *--xargs = xfile;
      if (efile != NULL)
         *--xargs = efile;
      if (eflag != NULL)
         *--xargs = eflag;
      execlist[0] = "iconx";
      execlist[1] = 0;
      lcat(execlist,xargs,(char **)NULL);

/*
 * The following code is operating-system dependent. It calls iconx on
 * the way out.
 */

#if PORT
   /* something is needed */
#endif					/* PORT */

#if AMIGA || ATARI_ST || VMS
      docmd(Iconx,execlist,envp);
#endif					/* AMIGA || ATARI_ST || VMS */

#if MACINTOSH
#if MPW
      docmd(Iconx,execlist,envp);
#endif					/* MPW */
#endif					/* MACINTOSH */

#if MSDOS
      execvp(Iconx,execlist);  /* execute with path search */
#endif					/* MSDOS */

#if UNIX
      execv(Iconx,execlist);
#endif					/* UNIX */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

      }
   exit(NormalExit);
   }

runit(c,a,e)
char *c; char **a, **e;
   {
   if (docmd(c,a,e) != 0) {
      rmfiles();
      exit(ErrorExit);
      }
   }

rmfiles()
   {
   char **p;
   for (p = rfiles;  *p;  p++)

/*
 * The following code is operating-system dependent.  It deletes files
 *  created by icont.
 */

#if PORT
   /* something is needed */
#endif					/* PORT */

#if AMIGA || MSDOS || VMS
      remove(*p);
#endif					/* AMIGA || MSDOS || VMS*/

#if ATARI_ST || UNIX
      unlink(*p);
#endif					/* ATARI_ST || UNIX */

#if MACINTOSH
#if MPW
      /* why not unlink??? */
      if (rfiles[0]) docmd("Delete", rfiles - 1);
      break;
#endif					/* MPW */
#endif					/* MACINTOSH */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   }

suffix(name,suf)
char *name,*suf;
   {
   char *rindex(), *x;

   if (x = rindex(name,'.'))

/*
 * The following code is operating-system dependent.  It returns the
 *  suffix, which may be "ICN" as well as "icn", if that is desired.
 */

#if PORT
      return !strcmp(suf,x);
#endif					/* PORT */

#if ATARI_ST || MSDOS
      return !stricmp(suf,x);
#endif					/* MSDOS */

#if AMIGA || MACINTOSH || UNIX || VMS
      return !strcmp(suf,x);
#endif					/* AMIGA || MACINTOSH || UNIX || VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   else
      return 0;
   }

char *mkname(name,suf)
char *name,*suf;
   {
   char *p;

   p = malloc(PathSize);
   if (p == NULL) {
      fprintf(stderr, "icont: not enough memory\n");
      exit(ErrorExit);
      }
   strcpy(p,name);
   strcat(p,suf);
   return p;
   }

char *getbase(name)
char *name;
   {
   char *f, *e, *rindex(), *p;

/*
 * The following code is operating-system dependent.  It gets the base
 *  name of a file specification.
 */

#if PORT
   /* something is needed */
#endif					/* PORT */

#if AMIGA
   if ((f = rindex(name,'/')) || (f = rindex(name,':')))
      f++;
   else
      f = name;
#endif					/* AMIGA */

#if MACINTOSH
#if MPW
   if (f = rindex(name,':'))
      f++;
   else
      f = name;
#endif					/* MPW */
#endif					/* MACINTOSH */

#if ATARI_ST || MSDOS
   /*
    * Can't use rindex, as someone could pass the string: c:\a/b\a/xyz
    */
   for( f = name + strlen(name); f!=name; f--)
       if(*f == ':' || *f == '/' || *f == '\\') {
           f++;
           break;
       }
#endif					/* ATARI_ST || MSDOS */

#if UNIX
   if (f = rindex(name,'/'))
      f++;
   else
      f = name;
#endif					/* UNIX */

#if VMS
   if ((f = rindex(name,'/')) || (f = rindex(name,']')) ||
      (f = rindex(name,':')))
         f++;
   else
      f = name;
#endif					/* VMS */

#if VM || MVS
#endif					/* VM || MVS */
/*
 * End of operating-system specific code.
 */

   e = rindex(f,'.');
   p = (char *)calloc(PathSize,1);
   if (p == NULL) {
      fprintf(stderr, "icont: not enough memory\n");
      exit(ErrorExit);
      }
   strncpy(p,f,e-f);
   p[e-f] = '\0';
   return p;
   }

lcat(c,a,b)
char *c[],*a[],*b[];
   {
   int cp, p;

   cp = p = 0;
   while (c[cp])
      cp++;
   while (c[cp] = a[p++])
      cp++;
   p = 0;
   if (b)
      while (c[cp++] = b[p++]);
   }

usage(p)
char *p;
   {

/*
 * The following code is operating-system dependent.  It prints an error
 *  message in case icont is called incorrectly.  The message depends on
 *  the options supported by icont.
 */

#if PORT
   fprintf(stderr,"usage: %s [-c] [-t] [-u] file ... [-x args]\n",p);
#endif					/* PORT */

#if AMIGA || ATARI_ST || MACINTOSH || MSDOS || VMS
   fprintf(stderr,"usage: %s [-c] [-t] [-u] file ... [-x args]\n",p);
#endif					/* AMIGA || ATARI_ST || MACINTOSH ... */

#if UNIX
   fprintf(stderr,"usage: %s [-c] [-m] [-t] [-u] file ... [-x args]\n",p);
#endif					/* UNIX */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   exit(ErrorExit);
   }

docmd(cmd,argv,envp)
char *cmd, **argv, **envp;
   {
   int rc, status;

/*
 * The following code is operating-system dependent.  It forks a
 *  process to run itran and ilink.
 */

#if PORT
   /* something is needed */
#endif					/* PORT */

#if AMIGA
   struct ProcID procid;
   if (forkv(cmd,argv,NULL,&procid)) {
      fprintf(stderr,"icont: fork failed for %s\n",cmd);
      return -1;
      }
   return wait(&procid);
#endif					/* AMIGA */

#if ATARI_ST
   if (status = (int)texec(cmd,argv)) {
      fprintf(stderr,"icont: exec failed on %s\n",cmd);
      exit(255);
      }
   return status;
#endif					/* ATARI_ST */

#if MACINTOSH
#if MPW
   char **p;
   fputs(cmd,stdout);
   for (p = argv + 1;*p;++p) {
      putchar(' ');
      fputs(*p,stdout);
      }
   putchar('\n');
   return 0;
#endif					/* MPW */
#endif					/* MACINTOSH */

#if MSDOS
#if MICROSOFT || TURBO
#include <process.h>
   if ((rc = spawnvp(P_WAIT, cmd, argv)) == -1) {
      fprintf(stderr, "exec failed on %s\n",cmd);
      return 255;
      }
   return rc;
#endif					/* MICROSOFT || TURBO */
#if LATTICE
   if (forkvp(cmd, argv)) {
      fprintf(stderr,"icont: exec failed on %s\n",cmd);
      return 255;
      }
   return wait();
#endif					/* LATTICE */
#endif					/* MSDOS */

#if UNIX
   rc = Fork();
   if (rc == -1) {
      fprintf(stderr,"icont: No more processes\n");
      return 255;
      }
   if (rc == 0) {
      execve(cmd,argv,envp);
      fprintf(stderr,"icont: exec failed on %s\n",cmd);
      _exit(ErrorExit);
      }
   while (rc != wait(&status));
   return ((status>>8) & 0xff);
#endif					/* UNIX */

#if VMS
   rc = Fork();
   if (rc == -1) {
      fprintf(stderr,"icont: No more processes\n");
      return 255;
      }
   if (rc == 0) {
      execve(cmd,argv,envp);
      fprintf(stderr,"icont: exec failed on %s\n",cmd);
      _exit(ErrorExit);
      }
   while (rc != wait(&status));
   return !(status&1);
#endif					/* VMS */

#if VM || MVS
#endif					/* VM || MVS */
/*
 * End of operating-system specific code.
 */

   }

report(s)
char *s;
   {

/*
 * The following code is operating-system dependent.  Report
 *  phase.
 */

#if PORT
   fprintf(stderr,"%s:\n",s);
#endif					/* PORT */

#if AMIGA || ATARI_ST || MSDOS || UNIX || VMS
   fprintf(stderr,"%s:\n",s);
#endif					/* AMIGA || ATARI_ST || MSDOS ... */

#if MACINTOSH
#if MPW
   printf("Echo %s:\n",s);
#endif					/* MPW */	
#endif					/* MACINTOSH */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   }
