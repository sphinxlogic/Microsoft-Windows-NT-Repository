/*
 *  Contents: collate, decollate, rotate
 */

/*
 * collate(s1,s2) - collate characters of s1 and s2
 */

FncDcl(collate,2)
   {
   register char *s1, *s2, *s;
   int slen, hlen;
   char *sbuf, sbuf1[MaxCvtLen], sbuf2[MaxCvtLen];
   extern char *alcstr();

   /*
    * s1 and s2 must be a strings.
    */
   if (cvstr(&Arg1, sbuf1) == NULL) 
      RunErr(103, &Arg1);
   if (cvstr(&Arg2, sbuf2) == NULL) 
      RunErr(103, &Arg2);

   /*
    * the result is twice the length of the shorter string
    */
   hlen = (StrLen(Arg1) < StrLen(Arg2) ? StrLen(Arg1) : StrLen(Arg2));
   slen = 2 * hlen;
   if (strreq(slen) == Error) 
      RunErr(0, NULL);
   sbuf = alcstr(NULL, slen);

   /*
    * collate the first hlen characters from s1 and from s2 into new string
    */
   s = sbuf;
   s1 = StrLoc(Arg1);
   s2 = StrLoc(Arg2);
   while (hlen-- > 0) {
      *s++ = *s1++;
      *s++ = *s2++;
      }

   /*
    * Return the new string.
    */
   StrLen(Arg0) = slen;
   StrLoc(Arg0) = sbuf;
   Return;
   }

/*
 * decollate(s,i) - produce every other charactor of s: even numbered ones if
 *                  i is even and odd numbered ones if i is odd
 */

FncDcl(decollate,2)
   {
   register char *s, *s1;
   int slen, n;
   char *sbuf, sbuf1[MaxCvtLen];
   extern char *alcstr();

   /*
    * s must be a string.  i must be an integer and defaults to 1.
    */
   if (cvstr(&Arg1, sbuf1) == NULL) 
      RunErr(103, &Arg1);
   if (defshort(&Arg2, 1) == Error) 
      RunErr(0, NULL);

   if (strreq((StrLen(Arg1) + 1) / 2) == Error) 
      RunErr(0, NULL);

   /*
    * if i is odd extract odd numbered characters otherwise extract even
    * numbered characters
    */
   if (IntVal(Arg2) % 2 == 1) {
      slen = (StrLen(Arg1) + 1) / 2;
      s1 = StrLoc(Arg1);
   } else {
      slen = StrLen(Arg1) / 2;
      s1 = StrLoc(Arg1) + 1;
      }

   sbuf = alcstr(NULL, slen);
   s = sbuf;
   n = slen;
   while (n-- > 0) {
      *s++ = *s1;
      s1 += 2;
      }

   /*
    * Return the new string.
    */
   StrLen(Arg0) = slen;
   StrLoc(Arg0) = sbuf;
   Return;
   }

/*
 * rotate(s,i) - rotate s by i positions
 */

FncDcl(rotate,2)
   {
   register int slen;
   char sbuf[MaxCvtLen];
   extern char *alcstr();
   long i;

   /*
    * Make sure that s is a string.
    */
   if (cvstr(&Arg1, sbuf) == NULL) 
      RunErr(103, &Arg1);

   /*
    * Convert i to a positive value no lArger than the size of s.
    */
   if (cvint(&Arg2, &i) == CvtFail) 
      RunErr(101, &Arg2);
   if ((slen = StrLen(Arg1)) == 0) i = 0;
   else if (i < 0) i = slen - (-i % slen);
   else i = i % slen;

   /*
    * Ensure that there is enough room.  Then allocate and copy the two
    *  parts of s.
    */
   if (strreq(slen) == Error) 
      RunErr(0, NULL);
   StrLen(Arg0) = slen;
   StrLoc(Arg0) = alcstr(StrLoc(Arg1) + i, slen - i);
   alcstr(StrLoc(Arg1), i);
   Return;
   }

FncDcl(StringCopy,1)
   {
   register int slen;
   char sbuf[MaxCvtLen];
   extern char *alcstr();
   if (cvstr(&Arg1,sbuf) == NULL) 
      RunErr(103, &Arg1);
   slen = StrLen(Arg1);
   if (strreq(slen) == Error) 
      RunErr(0, NULL);
   StrLen(Arg0) = slen;
   StrLoc(Arg0) = alcstr(StrLoc(Arg1),slen);
   Return;
   }
