/*
 * File: rmemexp.c - memory managemnt functions for expandable regions
 *  Contents: initalloc, reclaim, malloc, calloc, free
 */

/*
 * initalloc - initialization routine to allocate memory regions
 */

initalloc(codesize)
word codesize;
   {

/*
 * The following code is operating-system dependent.  Make declarations
 *  that are system-dependent.
 */

#if PORT
#endif					/* PORT */

#if AMIGA || ATARI_ST ||MSDOS
#endif					/* AMIGA || ATART_ST || MSDOS */

#if MACINTOSH
#if MPW
   extern char *brk(), *sbrk();
#endif					/* MPW */
#endif					/* MACINTOSH */

#if UNIX || VMS
   extern char *brk(), *sbrk();
#endif					/* UNIX || VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   /*
    * Establish icode region
    */
   code = (char *)sbrk((word)0);

   /*
    * Set up allocated memory.	The regions are:
    *
    *	Static memory region
    *	Allocated string region
    *	Allocate block region
    *	Qualifier list
    */

   statfree = statbase = (char *)((uword)(code + codesize + 3)  & ~03);

/*
 * The following code is operating-system dependent. Set end of static
 *  region, rounding up if necessary.
 */

#if PORT
   statend = (char *)(((uword)statbase) + mstksize + statsize);
#endif					/* PORT */

#if AMIGA
   /* uses FixedRegions */
#endif					/* AMIGA */

#if MSDOS
   statend =
      (char *)(((uword)statbase) + (((mstksize + statsize + 511)/512) * 512));
#endif					/* MSDOS */

#if ATARI_ST || MACINTOSH || UNIX || VMS
   statend = (char *)(((uword)statbase) + mstksize + statsize);
#endif					/* ATARI_ST || MACINTOSH || UNIX ... */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   strfree = strbase = (char *)((uword)(statend + 63) & ~077);
   blkfree = blkbase = strend = (char *)((((uword)strbase) + ssize +
      63) & ~077);
   equallist = (struct descrip **)(blkend =
      (char *)((((uword)(blkbase) + abrsize + 63)) & ~077));

   /*
    * Try to move the break back to the end of memory to allocate (the
    *  end of the string qualifier list) and die if the space isn't
    *  available.
    */
   if ((int)brk((char *)equallist) == -1)
      error("insufficient memory");
   currend = (char *)sbrk((word)0);			/* keep track of end of memory */
   return;
   }

/*
 * reclaim - reclaim space in the allocated memory regions. The marking
 *  phase has already been completed.
 */

static reclaim(region)
int region;
{
   register word stat_extra, str_extra, blk_extra;
   register char *newend;

   stat_extra = 0;
   str_extra = 0;
   blk_extra = 0;

   /*
    * Collect available co-expression blocks.
    */
   cofree();

   /*
    * If there was no room to construct the qualifier list, the string
    *  region cannot be collected and the static region cannot be expanded.
    */
   if (!qualfail) {
      /*
       * Check whether the static region needs to be expanded. Regions cannot
       *  be expanded if someone else has moved the end of allocated storage.
       */
      if (statneed && currend == sbrk((word)0)) {
         /*
          * Make sure there is space for the requested static region expansion.
          *  The check involving equallist and newend appears to only be
          *  required on machines where the above addition of statneed might
          *  overflow.
          */
         newend = (char *)equallist + statneed;
         if ((uword)newend >= (uword)(char *)equallist &&
             (int)brk(newend) != -1) {
               stat_extra = statneed;
               statneed = 0;
               statend += stat_extra;
               equallist = (struct descrip **)newend;
               currend = sbrk((word)0);
               }
         }
   
      /*
       * Collect the string space, indicating that it must be moved back
       *  extra bytes.
       */
      scollect(stat_extra);
   
      if (region == Strings && currend == sbrk((word)0)) {
         /*
          * Calculate a value for extra space.  The value is (the larger of
          *  (twice the string space needed) or (a quarter of the string space))
          *  minus the unallocated string space.
          */
         str_extra = (Max(2*strneed, ((uword)strend - (uword)strbase)/4) -
               ((uword)strend - (uword)strfree) + (GranSize-1)) & ~(GranSize-1);
         while (str_extra > 0) {
            /*
             * Try to get str_extra more bytes of storage.  If it can't be
             *  gotten, decrease the value by GranSize and try again.  If
             *  it's gotten, move back equallist.
             */
            newend = (char *)equallist + str_extra;
            if ((uword)newend >= (uword)(char *)equallist &&
                (int)brk(newend) != -1) {
                   equallist = (struct descrip **) newend;
                   currend = sbrk((word)0);
                   break;
                   }
            str_extra -= GranSize;
            }
         if (str_extra < 0)
            str_extra = 0;
         }
      }

   /*
    * Adjust the pointers in the block region.
    */
   adjust(blkbase, blkbase + stat_extra + str_extra);

   /*
    * Compact the block region.
    */
   compact(blkbase);

   if (region == Blocks && currend == sbrk((word)0)) {
      /*
       * Calculate a value for extra space.  The value is (the larger of
       *  (twice the block region space needed) or (one quarter of the
       *  block region)) plus the unallocated block space.
       */
      blk_extra = (Max(2*blkneed, ((uword)blkend - (uword)blkbase)/4) +
               (uword)blkfree - (uword)blkend + (GranSize-1)) & ~(GranSize-1);
      while (blk_extra > 0) {
         /*
          * Try to get blk_extra more bytes of storage.  If it can't be gotten,
          *  decrease the value by GranSize and try again.  If it's gotten,
          *  move back equallist.
          */
         newend = (char *)equallist + blk_extra;
         if ((uword)newend >= (uword)(char *)equallist &&
             (int)brk(newend) != -1) {
                equallist = (struct descrip **) newend;
                currend = sbrk((word)0);
                break;
                }
         blk_extra -= GranSize;
         }
      if (blk_extra < 0)
         blk_extra = 0;
   }
                
   if (stat_extra + str_extra > 0) {
      /*
       * The block region must be moved.  There is an assumption here that the
       *  block region always moves up in memory, i.e., the static and
       *  string regions never shrink.	With this assumption in hand,
       *  the block region must be moved before the string space lest the
       *  string space overwrite block data.  The assumption is valid,
       *  but beware if shrinking regions are ever implemented.
       */
      mvc((uword)blkfree - (uword)blkbase, blkbase, blkbase + stat_extra +
         str_extra);
      blkbase += stat_extra + str_extra;
      blkfree += stat_extra + str_extra;
      }
   blkend += stat_extra + str_extra + blk_extra;

   if (stat_extra > 0) {
      /*
       * The string space must be moved up in memory.
       */
      mvc((uword)strfree - (uword)strbase, strbase, strbase + stat_extra);
      strbase += stat_extra;
      strfree += stat_extra;
      }
   strend += stat_extra + str_extra;

   return;
   }

/*
 * These are Icon's own versions of the allocation routines.  They are
 *  not used for the fixed-regions versions of memory management.  They
 *  normally overload the corresponding library routines. If this is not
 *  possible, they are re-named and calls to them are renamed.
 */
typedef int ALIGN;		/* pick most stringent type for alignment */

union bhead {			/* header of free block */
   struct {
      union bhead *ptr; 	/* pointer to next free block */
      uword bsize;		/* free block size */
      } s;
   ALIGN x;			/* force block alignment */
   };

typedef union bhead HEADER;
#define NALLOC 64		/* units to request at one time */

#define FREEMAGIC 0x807F	/* magic flag for free blocks (MemMon only) */

static HEADER base;		/* start with empty list */
static HEADER *allocp = NULL;	/* last allocated block */

pointer malloc(nbytes)
unsigned int nbytes;
   {
   register HEADER *p, *q;
   register uword nunits;
   int attempts;

   if (statbase == NULL)
      syserr("malloc: static region not initialized");

   nunits = 1 + (nbytes + sizeof(HEADER) - 1) / sizeof(HEADER);

   if ((q = allocp) == NULL) {	/* no free list yet */
      base.s.ptr = allocp = q = &base;
      base.s.bsize = 0;
      }

   for (attempts = 2; attempts--; q = allocp) {
      for (p = q->s.ptr;; q = p, p = p->s.ptr) {
         if (p->s.bsize >= nunits) {	/* block is big enough */
            if (p->s.bsize == nunits)	/* exactly right */
               q->s.ptr = p->s.ptr;
            else {			/* allocate tail end */
               p->s.bsize -= nunits;
               p += p->s.bsize;
               p->s.bsize = nunits;
               }
            allocp = q;

#ifdef MemMon
            if (nunits > 1)   {
               MMPaint((char *)(p + 1), nbytes, 1);
               *(int *)(p + 1) = 0;	/* clear FREEMAGIC flag */
               }
#endif					/* MemMon */

            return (char *)(p + 1);
            }
         if (p == allocp) {	/* wrap around */
            moremem(nunits);	/* garbage collect and expand if needed */
            break;
            }
         }
      }

      return NULL;
   }

#define FREESIZE 2	/* units sizeof(HEADER) that justify free() */

/*
 *  realloc() allocates a block of memory of a requested size (amount) to
 *  contain the contents of the current block (curmem) or as much as will
 *  fit.  Blocks are allocated in units of sizeof(HEADER)
 */

pointer realloc(curmem,newsiz)
register pointer curmem;		/* the current memory pointer */
unsigned int newsiz;		/* bytes needed for new allocation */
   {
   register int cunits;		/* currently allocated units */
   register int nunits;		/* new units required */
   char *newmem;		/* the new memory pointer */
   register HEADER *head;	/* all blocks used or free have a header */

   /*
    * First establish the unit sizes involved.
    */

   nunits = 1 + (newsiz + sizeof(HEADER) - 1) / sizeof(HEADER);
   head = ((HEADER *)curmem) - 1;	/* move back a block header */
   cunits = head->s.bsize;

   /*
    * Now allocate or free space as required.
    */

   if (nunits <= cunits) {	/* we already have the space */
      if (cunits - nunits < FREESIZE)
         return curmem;
      else {			/* free space at end of current block */
         head->s.bsize = nunits;	/* reduce space used */
         head += nunits;		/* move to free space */
         head->s.bsize = cunits - nunits;
         free((pointer)(++head));	/* free this new block */
         return curmem;
         }
      }
   else {				/* more space needed */
      if ((newmem = malloc(newsiz)) != NULL) {
         memcpy(newmem,curmem,(cunits - 1) * sizeof(HEADER));
         free(curmem);
         return newmem;
         }
      }
   return NULL;
   }

/*
 * calloc() allocates ecnt number of esiz-sized chunks of zero-initialized
 * memory for an array of ecnt elements.
 */

pointer calloc(ecnt,esiz)
   register unsigned int ecnt, esiz;
   {
   register char *mem;			/* the memory pointer */
   register unsigned int amount;	/* the amount of memory needed */

   amount = ecnt * esiz;
   if ((mem = malloc(amount)) != NULL) {
      memset(mem,0,amount);		/* initialize it to zero */
      return mem;
      }
   return NULL;
   }

static moremem(nunits)
uword nunits;
   {
   register HEADER *up;
   register word rnu;
   word n;

   rnu = NALLOC * ((nunits + NALLOC - 1) / NALLOC);
   n = rnu * sizeof(HEADER);
   if (((uword)statfree) + n > (uword)statend) {
      statneed = ((n / statincr) + 1) * statincr;
      coll_stat++;
      collect(Static);
      }
   /*
    * See if there is any room left.
    */
   if ((uword)statend - (uword)statfree > sizeof(HEADER)) {
      up = (HEADER *) statfree;
      up->s.bsize = ((uword)statend - (uword)statfree) / sizeof(HEADER);
      statfree = (char *) (up + up->s.bsize);
      free((pointer) (up + 1));	/* add block to free memory */
      }
   }

#if MSDOS
#if MICROSOFT || TURBO
void
#endif					/* MICROSOFT || TURBO */
#endif					 /* MSDOS */
free(ap)		/* return block pointed to by ap to free list */
pointer ap;
   {
   register HEADER *p, *q;

   p = (HEADER *)ap - 1;	/* point to header */
#ifdef MemMon
   if (p->s.bsize > 1)	{
      if (*(int *)(p + 1) != T_Coexpr)
         MMPaint(ap, (p->s.bsize - 1) * sizeof(HEADER), 0);
      *(int *)(p + 1) = FREEMAGIC;
      }
#endif					/* MemMon */
   if (p->s.bsize * sizeof(HEADER) >= statneed)
     statneed = 0;
   for (q = allocp; !((uword)p > (uword)q && (uword)p < (uword)q->s.ptr);
      q = q->s.ptr)
         if ((uword)q >= (uword)q->s.ptr && ((uword)p > (uword)q ||
            (uword)p < (uword)q->s.ptr))
               break; 		/* at one end or the other */
   if ((uword)p + sizeof(HEADER) * p->s.bsize
      == (uword)q->s.ptr) {	/* join to upper */
      p->s.bsize += q->s.ptr->s.bsize;
      if (p->s.bsize * sizeof(HEADER) >= statneed)
         statneed = 0;
      p->s.ptr = q->s.ptr->s.ptr;
      }
   else
      p->s.ptr = q->s.ptr;
   if ((uword)q + sizeof(HEADER) * q->s.bsize ==
      (uword)p) {		/* join to lower */
         q->s.bsize += p->s.bsize;
         if (q->s.bsize * sizeof(HEADER) >= statneed)
            statneed = 0;
         q->s.ptr = p->s.ptr;
         }
   else
      q->s.ptr = p;
   allocp = q;
   }
