/*
 * File: fstruct.c
 *  Contents: delete, get, insert, list, member, pop, pull, push, put, set,
 *  table
 */

#include "../h/rt.h"

extern word hash();

/*
 * delete(S,x) - delete element x from set or table S if it is there
 *  (always succeeds and returns S).
 */

FncDcl(delete,2)
   {
   register struct descrip *pd;
   register word hn;
   int res;
   extern struct descrip *memb();
   extern struct descrip *memb_tbl();

   if (Qual(Arg1))
      RunErr(122, &Arg1);

   /*
   * The technique and philosophy here are the same
   *  as used in insert - see comment there.
   */
   switch (Type(Arg1)) {
      case T_Set:
         hn = hash(&Arg2);
         pd = memb((struct b_set *)BlkLoc(Arg1),&Arg2,hn,&res);
         if (res == 1) {
            /*
            * The element is there so delete it.
            */
            *pd = BlkLoc(*pd)->selem.clink;
            (BlkLoc(Arg1)->set.size)--;
            }
         break;

      case T_Table:
         hn = hash(&Arg2);
         pd = memb_tbl((struct b_table *)BlkLoc(Arg1),&Arg2,hn,&res);
         if (res == 1) {
            /*
            * The element is there so delete it.
            */
            *pd = BlkLoc(*pd)->telem.clink;
            (BlkLoc(Arg1)->table.size)--;
            }
         break;

      default:
         RunErr(122, &Arg1);
      }

   Arg0 = Arg1;
   Return;
   }


/*
 * get(x) - get an element from end of list x.
 *  Identical to pop(x).
 */

FncDcl(get,1)
   {
   register word i;
   register struct b_list *hp;
   register struct b_lelem *bp;
   extern struct b_lelem *alclstb();

   /*
    * Arg1 must be a list.
    */
   if (Arg1.dword != D_List) 
      RunErr(108, &Arg1);

   /*
    * Fail if the list is empty.
    */
   hp = (struct b_list *)BlkLoc(Arg1);
   if (hp->size <= 0)
      Fail;

   /*
    * Point bp at the first list block.  If the first block has no
    *  elements in use, point bp at the next list block.
    */
   bp = (struct b_lelem *)BlkLoc(hp->listhead);
   if (bp->nused <= 0) {
      bp = (struct b_lelem *)BlkLoc(bp->listnext);
      BlkLoc(hp->listhead) = (union block *) bp;
      bp->listprev = nulldesc;
      }
   /*
    * Locate first element and assign it to Arg0 for return.
    */
   i = bp->first;
   Arg0 = bp->lslots[i];
   /*
    * Set bp->first to new first element, or 0 if the block is now
    *  empty.  Decrement the usage count for the block and the size
    *  of the list.
    */
   if (++i >= bp->nslots)
      i = 0;
   bp->first = i;
   bp->nused--;
   hp->size--;
   Return;
   }


/*
 * insert(S,x) - insert element x into set or table S if not already there
 *  (always succeeds and returns S).
 */

FncDcl(insert,3)
   {
   register union block *bp;
   register struct descrip *pd;
   register struct b_telem *pe;
   register word hn;
   int res;
   extern struct b_selem *alcselem();
   extern struct b_telem *alctelem();
   extern struct descrip *memb();
   extern struct descrip *memb_tbl();

   if (Qual(Arg1))
      RunErr(122, &Arg1);

   switch (Type(Arg1)) {
      case T_Set:

         /*
         * We may need at most one new element.
         */
         if (blkreq((word)sizeof(struct b_selem)) == Error) 
            RunErr(0, NULL);
         bp = BlkLoc(Arg1);
         hn = hash(&Arg2);
         /*
          * If Arg2 is a member of set Arg1 then res will have the
          *  value 1 and pd will have a pointer to the descriptor
          *  that points to that member.
          *  If Arg2 is not a member of the set then res will have
          *  the value 0 and pd will point to the descriptor
          *  which should point to the member - thus we know where
          *  to link in the new element without having to do any
          *  repetitive looking.
          */
         pd = memb((struct b_set *)bp,&Arg2,hn,&res);
         if (res == 0)
            /*
            * The element is not in the set - insert it.
            */
            addmem((struct b_set *)bp,alcselem(&Arg2,hn),pd);
         break;

      case T_Table:
         if (blkreq((word)sizeof(struct b_telem)) == Error) 
            RunErr(0, NULL);
         bp = BlkLoc(Arg1);
         hn = hash(&Arg2);
         pd = memb_tbl((struct b_table *)bp,&Arg2,hn,&res);
         if (res == 0) {
            /*
            * The element is not in the set - insert it.
            */
            bp->table.size++;
            pe = alctelem();
            pe->clink = *pd;
            BlkLoc(*pd) = (union block *) pe;
            pd->dword = D_Telem;
            pe->hashnum = hn;
            pe->tref = Arg2;
            }
         else
            pe = (struct b_telem *)BlkLoc(*pd);
         pe->tval = Arg3;
         break;

      default:
         RunErr(122, &Arg1);
      }

   Arg0 = Arg1;
   Return;
   }

/*
 * list(n,x) - create a list of size n, with initial value x.
 */

/* >list */
FncDcl(list,2)
   {
   register word i, size;
   word nslots;
   register struct b_lelem *bp;
   register struct b_list *hp;
   extern struct b_list *alclist();
   extern struct b_lelem *alclstb();

   if (defshort(&Arg1, 0) == Error) 
      RunErr(0, NULL);

   nslots = size = IntVal(Arg1);


   /*
    * Ensure that the size is positive and that the list-element block 
    *  has at least MinListSlots slots.
    */
   if (size < 0) 
      RunErr(205, &Arg1);
   if (nslots < MinListSlots)
      nslots = MinListSlots;

   /*
    * Ensure space for a list-header block, and a list-element block
    * with nslots slots.
    */
   if (blkreq(sizeof(struct b_list) + sizeof(struct b_lelem) +
         nslots * sizeof(struct descrip)) == Error) 
      RunErr(0, NULL);

   /*
    * Allocate the list-header block and a list-element block.
    *  Note that nslots is the number of slots in the list-element
    *  block while size is the number of elements in the list.
    */
   hp = alclist(size);
   bp = alclstb(nslots, (word)0, size);
   hp->listhead.dword = hp->listtail.dword = D_Lelem;
   BlkLoc(hp->listhead) = BlkLoc(hp->listtail) = (union block *)bp;

   /*
    * Initialize each slot.
    */
   for (i = 0; i < size; i++)
      bp->lslots[i] = Arg2;

   /*
    * Return the new list.
    */
   Arg0.dword = D_List;
   BlkLoc(Arg0) = (union block *)hp;
   Return;
   }
/* <list */

/*
 * member(S,x) - returns x if x is a member of set or table S otherwise fails.
 */

FncDcl(member,2)
   {
   int res;
   register word hn;
   extern struct descrip *memb();
   extern struct descrip *memb_tbl();

   if (Qual(Arg1))
      RunErr(122, &Arg1);

   switch (Type(Arg1)) {
      case T_Set:
         hn = hash(&Arg2);
         memb((struct b_set *)BlkLoc(Arg1),&Arg2,hn,&res);
         break;

      case T_Table:
         hn = hash(&Arg2);
         memb_tbl((struct b_table *)BlkLoc(Arg1),&Arg2,hn,&res);
         break;

      default:
         RunErr(122, &Arg1);
      }

   /* If Arg2 is a member of Arg1 then "res" will have the
    * value 1 otherwise it will have the value 0.
    */
   if (res == 1) {		/* It is a member. */
      Arg0 = Arg2;		/* Return the member if it is in Arg1. */
      Return;
      }
   Fail;
   }


/*
 * pop(x) - pop an element from beginning of list x.
 */

/* >pop */
FncDcl(pop,1)
   {
   register word i;
   register struct b_list *hp;
   register struct b_lelem *bp;
   extern struct b_lelem *alclstb();

   /*
    * Arg1 must be a list.
    */
   if (Arg1.dword != D_List) 
      RunErr(108, &Arg1);

   /*
    * Fail if the list is empty.
    */
   hp = (struct b_list *)BlkLoc(Arg1);
   if (hp->size <= 0)
      Fail;

   /*
    * Point bp to the first list-element block.  If the first block has
    *  no slots in use, point bp at the next list-element block.
    */
   bp = (struct b_lelem *)BlkLoc(hp->listhead);
   if (bp->nused <= 0) {
      bp = (struct b_lelem *)BlkLoc(bp->listnext);
      BlkLoc(hp->listhead) = (union block *) bp;
      bp->listprev = nulldesc;
      }
   /*
    * Locate first element and assign it to Arg0 for return.
    */
   i = bp->first;
   Arg0 = bp->lslots[i];

   /*
    * Set bp->first to new first element, or 0 if the block is now
    *  empty.  Decrement the usage count for the block and the size
    *  of the list.
    */
   if (++i >= bp->nslots)
      i = 0;
   bp->first = i;
   bp->nused--;
   hp->size--;
   Return;
   }
/* <pop */


/*
 * pull(x) - pull an element from end of list x.
 */

FncDcl(pull,1)
   {
   register word i;
   register struct b_list *hp;
   register struct b_lelem *bp;
   extern struct b_lelem *alclstb();

   /*
    * Arg1 must be a list.
    */
   if (Arg1.dword != D_List) 
      RunErr(108, &Arg1);

   /*
    * Point at list header block and fail if the list is empty.
    */
   hp = (struct b_list *)BlkLoc(Arg1);
   if (hp->size <= 0)
      Fail;
   /*
    * Point bp at the last list element block.  If the last block has no
    *  elements in use, point bp at the previous list element block.
    */
   bp = (struct b_lelem *)BlkLoc(hp->listtail);
   if (bp->nused <= 0) {
      bp = (struct b_lelem *)BlkLoc(bp->listprev);
      BlkLoc(hp->listtail) = (union block *) bp;
      bp->listnext = nulldesc;
      }
   /*
    * Set i to position of last element and assign the element to
    *  Arg0 for return.  Decrement the usage count for the block
    *  and the size of the list.
    */
   i = bp->first + bp->nused - 1;
   if (i >= bp->nslots)
      i -= bp->nslots;
   Arg0 = bp->lslots[i];
   bp->nused--;
   hp->size--;
   Return;
   }


/*
 * push(x,val) - push val onto beginning of list x.
 */
FncDcl(push,2)
   {
   register word i;
   register struct b_list *hp;
   register struct b_lelem *bp;
   extern struct b_lelem *alclstb();

   /*
    * Arg1 must be a list.
    */
   if (Arg1.dword != D_List) 
      RunErr(108, &Arg1);

   /*
    * Point hp at the list-header block and bp at the first
    *  list-element block.
    */
   hp = (struct b_list *)BlkLoc(Arg1);
   bp = (struct b_lelem *)BlkLoc(hp->listhead);

   /*
    * If the first list-element block is full, allocate a new
    *  list-element block, make it the first list-element block,
    *  and make it the previous block of the former first list-element
    *  block.
    */
   if (bp->nused >= bp->nslots) {
      /*
       * Set i to the size of block to allocate.
       */
      i = hp->size / 2;
      if (i < MinListSlots) i = MinListSlots;

      /*
       * Ensure space for a new list element block.  If the block can't
       *  be allocated, try smaller blocks.
       */
      while (blkreq((word)sizeof(struct b_lelem) +
		    i * sizeof(struct descrip)) == Error) {
	    i /= 4;
	    if (i < MinListSlots)
	       RunErr(0, NULL);
	    }
      /*
       * Reset hp in case there was a garbage collection.
       */
      hp = (struct b_list *)BlkLoc(Arg1);

      bp = alclstb(i, (word)0, (word)0);
      BlkLoc(hp->listhead)->lelem.listprev.dword = D_Lelem;
      BlkLoc(BlkLoc(hp->listhead)->lelem.listprev) = (union block *)bp;
      bp->listnext = hp->listhead;
      BlkLoc(hp->listhead) = (union block *)bp;
      }

   /*
    * Set i to position of new first element and assign val (Arg2) to
    *  that element.
    */
   i = bp->first - 1;
   if (i < 0)
      i = bp->nslots - 1;
   bp->lslots[i] = Arg2;
   /*
    * Adjust value of location of first element, block usage count,
    *  and current list size.
    */
   bp->first = i;
   bp->nused++;
   hp->size++;
   /*
    * Return the list.
    */
   Arg0 = Arg1;
   Return;
   }


/*
 * put(x,val) - put val onto end of list x.
 */

FncDcl(put,2)
   {
   register word i;
   register struct b_list *hp;
   register struct b_lelem *bp;
   extern struct b_lelem *alclstb();

   /*
    * Arg1 must be a list.
    */
   if (Arg1.dword != D_List) 
      RunErr(108, &Arg1);

   /*
    * Point hp at the list-header block and bp at the last
    *  list-element block.
    */
   hp = (struct b_list *)BlkLoc(Arg1);
   bp = (struct b_lelem *)BlkLoc(hp->listtail);

   /*
    * If the last list-element block is full, allocate a new
    *  list-element block, make it the first list-element block,
    *  and make it the next block of the former last list-element
    *  block.
    */
   if (bp->nused >= bp->nslots) {
      /*
       * Set i to the size of block to allocate.
       */
      i = hp->size / 2;
      if (i < MinListSlots) i = MinListSlots;

      /*
       * Ensure space for a new list element block.  If the block can't
       *  be allocated, try smaller blocks.
       */
      while (blkreq((word)sizeof(struct b_lelem) +
		    i * sizeof(struct descrip)) == Error) {
	    i /= 4;
	    if (i < MinListSlots)
	       RunErr(0, NULL);
	    }
      /*
       * Reset hp in case there was a garbage collection.
       */
      hp = (struct b_list *)BlkLoc(Arg1);

      bp = alclstb(i, (word)0, (word)0);
      BlkLoc(hp->listtail)->lelem.listnext.dword = D_Lelem;
      BlkLoc(BlkLoc(hp->listtail)->lelem.listnext) = (union block *)bp;
      bp->listprev = hp->listtail;
      BlkLoc(hp->listtail) = (union block *)bp;
      }

   /*
    * Set i to position of new last element and assign Arg2 to
    *  that element.
    */
   i = bp->first + bp->nused;
   if (i >= bp->nslots)
      i -= bp->nslots;
   bp->lslots[i] = Arg2;

   /*
    * Adjust block usage count and current list size.
    */
   bp->nused++;
   hp->size++;

   /*
    * Return the list.
    */
   Arg0 = Arg1;
   Return;
   }

/*
 * set(list) - create a set with members in list.
 *  The members are linked into hash chains which are
 *  arranged in increasing order by hash number.
 */
FncDcl(set,1)
   {
   register word hn;
   register struct descrip *pd;
   register struct b_set *ps;
   union block *pb;
   struct b_selem *ne;
   struct descrip *pe;
   int res;
   word i, j;
   extern struct descrip *memb();
   extern struct b_set *alcset();
   extern struct b_selem *alcselem();

   if (ChkNull(Arg1)) {		/* Create empty set */
      if (blkreq((word)sizeof(struct b_set)) == Error)
         RunErr(0,NULL);
      Arg0.dword = D_Set;
      BlkLoc(Arg0) = (union block *)alcset();
      Return;
      }

   if (Arg1.dword != D_List) 
      RunErr(108, &Arg1);

   if (blkreq(sizeof(struct b_set) + (BlkLoc(Arg1)->list.size *
      sizeof(struct b_selem))) == Error) 
      RunErr(0, NULL);

   pb = BlkLoc(Arg1);
   Arg0.dword = D_Set;
   ps = alcset();
   BlkLoc(Arg0) = (union block *)ps;
   /*
    * Chain through each list block and for
    *  each element contained in the block
    *  insert the element into the set if not there.
    */
   for (Arg1 = pb->list.listhead; Arg1.dword == D_Lelem;
      Arg1 = BlkLoc(Arg1)->lelem.listnext) {
         pb = BlkLoc(Arg1);
         for (i = 0; i < pb->lelem.nused; i++) {
            j = pb->lelem.first + i;
            if (j >= pb->lelem.nslots)
               j -= pb->lelem.nslots;
            pd = &pb->lelem.lslots[j];
            pe = memb(ps, pd, hn = hash(pd), &res);
            if (res == 0) {
               ne = alcselem(pd,hn);
                addmem(ps,ne,pe);
                }
            }
      }
   Return;
   }

/*
 * table(x) - create a table with default value x.
 */
FncDcl(table,1)
   {
   extern struct b_table *alctable();

   if (blkreq((word)sizeof(struct b_table)) == Error) 
      RunErr(0, NULL);
   Arg0.dword = D_Table;
   BlkLoc(Arg0) = (union block *) alctable(&Arg1);
   Return;
   }
