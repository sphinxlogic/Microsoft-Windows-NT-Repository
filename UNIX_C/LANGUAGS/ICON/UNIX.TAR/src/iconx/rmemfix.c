/*
 * File: rmemfix.c - memory managemnt functions for fixed regions
 *  Contents: initalloc, reclaim
 */

/*
 * initalloc - initialization routine to allocate memory regions
 */

initalloc(codesize)
word codesize;
   {
   extern pointer malloc();
   static char dummy[1];	/* dummy static region */

#if IntBits == 16
   if (codesize > MaxUnsigned)
      error("insufficient memory");
   if (ssize > MaxUnsigned)
      error("insufficient memory");
   if (abrsize > MaxUnsigned)
      error("insufficient memory");
   if (qualsize > MaxUnsigned)
      error("insufficient memory");
#endif					/* IntBits == 16 */

   /*
    * Allocate icode region
    */
   if ((code = (char *)malloc((unsigned)codesize)) == NULL)
      error("insufficient memory");

   /*
    * Set up allocated memory.	The regions are:
    *
    *	Static memory region (not used)
    *	Allocated string region
    *	Allocate block region
    *	Qualifier list
    */

   statend = statfree = statbase = dummy;
   if ((strfree = strbase = (char *)malloc((unsigned)ssize)) == NULL)
      error("insufficient memory");
   strend = strbase + ssize;
   if ((blkfree = blkbase = (char *)malloc((unsigned)abrsize)) == NULL)
      error("insufficient memory");
   blkend = blkbase + abrsize;
   if ((quallist = (struct descrip **)malloc((unsigned)qualsize)) == NULL)
      error("insufficient memory");
   equallist = quallist + qualsize;
   return;
   }

/*
 * reclaim - reclaim space in the allocated memory regions. The marking
 *   phase has already been completed.
 */

static reclaim(region)
int region;
   {
   /*
    * Collect available co-expression blocks.
    */
   cofree();

   /*
    * Collect the string space leaving it where it is.
    */
   if (!qualfail)
      scollect((word)0);

   /*
    * Adjust the blocks in the block region in place.
    */
   adjust(blkbase,blkbase);

   /*
    * Compact the block region.
    */
   compact(blkbase);
   return;
   }
