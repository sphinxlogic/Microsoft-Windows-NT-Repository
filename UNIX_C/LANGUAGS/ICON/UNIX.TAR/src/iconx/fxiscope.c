/*
 * Vword(x) - return second word of descriptor as integer
 */

FncDcl(Vword,1)
   {
   Arg0.dword = D_Integer;
   Arg0.vword.integr = Arg1.vword.integr;
   Return;
   }

/*
 * Dword(x) - return first word of descriptor as integer.
 */

FncDcl(Dword,1)
   {
   Arg0.dword = D_Integer;
   Arg0.vword.integr = Arg1.dword;
   Return;
   }

/*
 * Descr(x,y) - construct descriptor from integer values of x and y
 */

FncDcl(Descr,2)
   {
   if (defshort(&Arg1, 0) == Error) 
      RunErr(0, NULL);
   if (defshort(&Arg2, 0) == Error) 
      RunErr(0, NULL);
   Arg0.dword = Arg1.vword.integr;
   Arg0.vword.integr = Arg2.vword.integr;
   Return;
   }

/*
 * Indir(x) - return integer to where x points.
 */

FncDcl(Indir,1)
   {
   Arg0.dword = D_Integer;
   Arg0.vword.integr = *((int *) Arg1.vword.integr);
   Return;
   }

/*
 * Symbol(x) - get address of Icon symbol.
 */

FncDcl(Symbol,1)
   {
   extern globals, eglobals, gnames;
   char sbuf[MaxCvtLen];
   struct descrip arg;
   char *sym;

   /*
    * Make a C-style string out of the argument.
    */
   arg = Arg1;
   switch (cvstr(&arg, sbuf)) {

      case Cvt:   /* Already converted to a C-style string */
         break;

      case NoCvt:
 	 qtos(&arg, sbuf);
	 break;

      default:
         RunErr(103, &arg);
      }
   sym = StrLoc(arg);

   ((Arg0).dword) = D_Integer;
   if (strcmp(sym, "globals") == 0)
      IntVal(Arg0) = (int) &globals;
   else if (strcmp(sym, "eglobals") == 0)
      IntVal(Arg0) = (int) &eglobals;
   else if (strcmp(sym, "gnames") == 0)
      IntVal(Arg0) = (int) &gnames;
   else if (strcmp(sym, "strbase") == 0)
      IntVal(Arg0) = (int) strbase;
   else if (strcmp(sym, "strfree") == 0)
      IntVal(Arg0) = (int) strfree;
   else if (strcmp(sym, "blkbase") == 0)
      IntVal(Arg0) = (int) blkbase;
   else if (strcmp(sym, "blkfree") == 0)
      IntVal(Arg0) = (int) blkfree;
   else
      RunErr(205, &Arg1);
   Return;
   }

/*
 * Ivar(x) - get value of interpreter state variable
 */

FncDcl(Ivar,1)
   {
   char sbuf[MaxCvtLen];
   struct descrip arg;
   char *sym;

   /*
    * Make a C-style string out of the argument.
    */
   arg = Arg1;
   switch (cvstr(&arg, sbuf)) {

      case Cvt:   /* Already converted to a C-style string */
         break;

      case NoCvt:
 	 qtos(&arg, sbuf);
	 break;

      default:
         RunErr(103, &arg);
      }
   sym = StrLoc(arg);

   ((Arg0).dword) = D_Integer;
   if (strcmp(sym, "sp") == 0)
      IntVal(Arg0) = (int)sp;
   else if (strcmp(sym, "efp") == 0)
      IntVal(Arg0) = (int)efp;
   else if (strcmp(sym, "gfp") == 0)
      IntVal(Arg0) = (int)gfp;
   else if (strcmp(sym, "argp") == 0)
      IntVal(Arg0) = (int)argp;
   else if (strcmp(sym, "pfp") == 0)
      IntVal(Arg0) = (int)pfp;
   else if (strcmp(sym, "ilevel") == 0)
      IntVal(Arg0) = (int)ilevel;
   else
      RunErr(205, &Arg1);
   Return;
   }
