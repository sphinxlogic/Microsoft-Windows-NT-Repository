/*
 * Various interpreter data tables.
 */

#include "../h/rt.h"

/*
 * External declarations for blocks of built-in procedures.
 */
extern struct b_proc
#define FncDef(p) Cat(B,p),
#include "../h/fdefs.h"
   Xnoproc; /* Hack to avoid ,; at end */
#undef FncDef
struct b_proc Xnoproc;

/*
 * Array of addresses of blocks for built-in procedures.  It is important
 *  that this table and the one in ../link/builtin.c agree; the linker
 *  supplies iconx with indices into this array.
 */
struct b_proc *functab[] = {
#define FncDef(p) Cat(&B,p),
#include "../h/fdefs.h"
#undef FncDef
   0
   };

int ftsize = sizeof(functab) / sizeof(struct b_proc *);
 
asgn(), bang(), bscan(), cat(), compl(), create(),
diff(), divide(), eqv(), err(), escan(), field(), inter(), lconcat(),
lexeq(), lexge(), lexgt(), lexle(), lexlt(), lexne(),
minus(), mod(), mult(), neg(), neqv(), nonnull(), null(), number(),
numeq(), numge(), numgt(), numle(), numlt(), numne(), plus(), power(),
random(), rasgn(), refresh(), rswap(), sect(), size(),
subsc(), swap(), tabmat(), toby(), unions(), value();
/*
 * When an opcode n has a subroutine call associated with it, the
 *  nth word here is the routine to call.
 */
int (*optab[])() = {
	err,		asgn,		bang,		cat,
	compl,		diff,		divide,		eqv,
	inter,		lconcat,	lexeq,		lexge,
	lexgt,		lexle,		lexlt,		lexne,
	minus,		mod,		mult,		neg,
	neqv,		nonnull,	null,		number,
	numeq,		numge,		numgt,		numle,
	numlt,		numne,		plus,		power,
	random,		rasgn,		refresh,	rswap,
	sect,		size,		subsc,		swap,
	tabmat,		toby,		unions,		value,
	bscan,		err,		err,		err,
	err,		err,		create,		err,
	err,		err,		err,		escan,
	err,		field,		err,		err
	};


#ifndef NoTraceBack
extern struct b_proc Basgn, Bbang, Bbscan, Bcat, Bcompl,
Bcreate, Bdiff, Bdivide, Beqv, Bescan, Bfield, Binter, Blconcat, Blexeq,
Blexge, Blexgt, Blexle, Blexlt, Blexne, Blimit, Bllist, Bminus, Bmod, Bmult,
Bneg, Bneqv, Bnonnull, Bnull, Bnumber, Bnumeq, Bnumge, Bnumgt, Bnumle, Bnumlt,
Bnumne, Bplus, Bpower, Brandom, Brasgn, Brefresh, Brswap, Bsect, Bsize, Bsubsc,
Bswap, Btabmat, Btoby, Bunions, Bvalue;

struct b_proc *opblks[] = {
	NULL,		&Basgn,		&Bbang,		&Bcat,
	&Bcompl,	&Bdiff,		&Bdivide,	&Beqv,
	&Binter,	&Blconcat,	&Blexeq,	&Blexge,
	&Blexgt,	&Blexle,	&Blexlt,	&Blexne,
	&Bminus,	&Bmod,		&Bmult,		&Bneg,
	&Bneqv,		&Bnonnull,	&Bnull,		&Bnumber,
	&Bnumeq,	&Bnumge,	&Bnumgt,	&Bnumle,
	&Bnumlt,	&Bnumne,	&Bplus,		&Bpower,
	&Brandom,	&Brasgn,	&Brefresh,	&Brswap,
	&Bsect,		&Bsize,		&Bsubsc,	&Bswap,
	&Btabmat,	&Btoby,		&Bunions,	&Bvalue,
	&Bbscan,	NULL,		NULL,		NULL,
	NULL,		NULL,		&Bcreate,	NULL,
	NULL,		NULL,		NULL,		&Bescan,
	NULL,		&Bfield,	NULL,		NULL,
	NULL,		NULL,		NULL,		&Blimit,
	&Bllist,	NULL,		NULL,		NULL
	};
#endif					/* NoTraceBack */
