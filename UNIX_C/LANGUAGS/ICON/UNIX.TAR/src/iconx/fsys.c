/*
 * File: fsys.c
 *  Contents: close, exit, getenv, open, read, reads, remove, rename, [save],
 *   seek, stop, system, where, write, writes
 */

#include "../h/rt.h"

#if MICROSOFT
#define BadCode
#endif					/* MICROSOFT */

#ifdef SCO_XENIX
#define BadCode
#endif					/* SCO_XENIX */

/*
 * The following code is operating-system dependent. Include system-dependent
 *  files.
 */

#if PORT
   /* nothing to do */
#endif					/* PORT */

#if MACINTOSH
#if MPW
#include <IOCtl.h>
#define isatty(fd) (!ioctl((fd), FIOINTERACTIVE))
#endif					/* MPW */
#endif					/* MACINTOSH */

#if AMIGA || ATARI_ST || MSDOS || UNIX || VMS
   /* nothing to do */
#endif					/* AMIGA || ATARI_ST || MSDOS || ... */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */



extern char *alcstr();


/*
 * close(f) - close file f.
 */

FncDcl(close,1)
   {
   FILE *f;

   /*
    * Arg1 must be a file.
    */
   if (Arg1.dword != D_File) 
      RunErr(105, &Arg1);

   /*
    * Close Arg1, using fclose or pclose as appropriate.
    */

/*
 * The following code is operating-system dependent. Close pipe if
 *  pipes are supported.
 */

#if PORT
   /* not supported */
#endif					/* PORT */

#if AMIGA || ATARI_ST || MACINTOSH || MSDOS
   /* not supported */
#endif					/* AMIGA || ATARI_ST || MACINTOSH ... */

#if UNIX || VMS
   if (BlkLoc(Arg1)->file.status & Fs_Pipe) {
      BlkLoc(Arg1)->file.status = 0;
      MkIntT((long)((pclose(BlkLoc(Arg1)->file.fd) >> 8) & 0377), &Arg0);
      Return;
      }
   else
#endif					/* UNIX || VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   f = BlkLoc(Arg1)->file.fd;

/*
 * The following code is operating-system dependent.
 */

#if PORT
#endif					/* PORT */

#if AMIGA || ATARI_ST || MACINTOSH
   /* do nothing */
#endif					/* AMIGA || ATARI_ST || MACINTOSH */

#if MSDOS
#if LATTICE
   {   char *p;
       if (f->_flag & _IOMYBUF && f->_base) {
	  fflush(f);
	  p = f->_base;
	  setbuf(f,NULL);
	  free(p);
       }
   }
#endif					/* LATTICE */
#endif					/* MSDOS */

#if UNIX || VM || MVS || VMS
   /* do nothing */
#endif					/* UNIX || VM || MVS || VMS */

/*
 * End of operating-system specific code.
 */

   fclose(f);
   BlkLoc(Arg1)->file.status = 0;

   /*
    * Return the closed file.
    */
   Arg0 = Arg1;
   Return;
   }

/*
 * exit(status) - exit process with specified status, defaults to 0.
 */

FncDcl(exit,1)
   {
   if (defshort(&Arg1, NormalExit) == Error) 
      RunErr(0, NULL);
   c_exit((int)IntVal(Arg1));
   }

/*
 * getenv(s) - return contents of environment variable s
 */

FncDcl(getenv,1)
   {

#ifdef NoEnvVars
   RunErr(-121, NULL);
#else					/* NoEnvVars */

   register char *p;
   register word len;
   char sbuf[256];
   extern char *getenv();
   extern char *alcstr();


   /*
    * Make a C-style string out of Arg1
    */
   switch (cvstr(&Arg1, sbuf)) {

      case Cvt:   /* Already converted to a C-style string */
         break;

      case NoCvt:
         qtos(&Arg1, sbuf);
         break;

      default:
         RunErr(103, &Arg1);
      }

   if ((p = getenv(StrLoc(Arg1))) != NULL) {	/* get environment variable */
      len = strlen(p);
      if (strreq(len) == Error) 
         RunErr(0, NULL);
      StrLen(Arg0) = len;
      StrLoc(Arg0) = alcstr(p, len);
      Return;
      }
   else 				/* fail if not in environment */
      Fail;
#endif					/* NoEnvVars */
   }

/*
 * open(s1,s2) - open file s1 with specification s2.
 */
FncDcl(open,2)
   {
   register word slen;
   register int i;
   register char *s;
   int status;

/*
 * The following code is operating-system dependent. Make declarations as
 *  needed for opening files.
 */

#if PORT
   char mode[3];
   extern FILE *fopen();
#endif					/* PORT */

#if AMIGA
   char mode[3];
   extern FILE *fopen();
#endif					/* AMIGA */

#if ATARI_ST || MSDOS
   char mode[4];
   char untranslated;
   extern FILE *fopen();
#endif					/* ATARI_ST || MSDOS */

#if MACINTOSH || UNIX || VMS
   char mode[3];
   extern FILE *fopen(), *popen();
#endif					/* MACINTOSH || UNIX || VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   char sbuf1[MaxCvtLen], sbuf2[MaxCvtLen];
   char *openstring;
   FILE *f;
   extern struct b_file *alcfile();

   /*
    * Arg1 must be a string and a C string copy of it is also needed.
    *  Make it a string if it is not one; make a C string if Arg1 is
    *  a string.
    */
   switch (cvstr(&Arg1, sbuf1)) {

      case Cvt:
         openstring = StrLoc(Arg1);
         if (strreq(StrLen(Arg1)) == Error) 
            RunErr(0, NULL);
         StrLoc(Arg1) = alcstr(StrLoc(Arg1), StrLen(Arg1));
         break;

      case NoCvt:
         tended[1] = Arg1;
         ntended = 1;
         qtos(&tended[1], sbuf1);
         openstring = StrLoc(tended[1]);
         break;

      default:
         RunErr(103, &Arg1);
      }
   /*
    * s2 defaults to "r".
    */
   if (defstr(&Arg2, sbuf2, &letr) == Error) 
      RunErr(0, NULL);

   if (blkreq((word)sizeof(struct b_file)) == Error) 
      RunErr(0, NULL);
   status = 0;

/*
 * The following code is operating-system dependent. Provide declaration
 *  for untranslated line-termination mode, if supported.
 */

#if PORT
   /* nothing to do */
#endif					/* PORT */

#if AMIGA
   /* translated mode could be supported, but is not now */
#endif					/* AMIGA */

#if ATARI_ST || MSDOS
   untranslated = 0;
#endif					/* ATARI_ST || MSDOS */

#if MACINTOSH || UNIX || VMS
   /* nothing to do */
#endif					/* MACINTOSH || UNIX || VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   /*
    * Scan Arg2, setting appropriate bits in status.  Produce a run-time error
    *  if an unknown character is encountered.
    */
   s = StrLoc(Arg2);
   slen = StrLen(Arg2);
   for (i = 0; i < slen; i++) {
      switch (*s++) {
         case 'a': case 'A':
            status |= Fs_Write|Fs_Append;
            continue;
         case 'b': case 'B':
            status |= Fs_Read|Fs_Write;
            continue;
         case 'c': case 'C':
            status |= Fs_Create|Fs_Write;
            continue;

/*
 * The following code is operating-system dependent. Handle untranslated
 *  line-terminator mode and pipes, if supported.
 */

#if PORT
   /* not supported */
#endif					/* PORT */

#if AMIGA || MACINTOSH
   /* not supported */
#endif					/* AMIGA || MACINTOSH */

#if ATARI_ST || MSDOS
         case 't': case 'T':   /* Add a translated (default) */
            untranslated = 0;
            continue;
         case 'u': case 'U':   /* Add a translated (default) */
            untranslated = 1;
            continue;
#endif					/* ATARI_ST || MSDOS */

#if UNIX || VMS
         case 'p': case 'P':
            status |= Fs_Pipe;
            continue;
#endif					/* UNIX || VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */
         case 'r': case 'R':
            status |= Fs_Read;
            continue;
         case 'w': case 'W':
            status |= Fs_Write;
            continue;
         default:
            RunErr(209, &Arg2);
         }
      }

   /*
    * Construct a mode field for fopen/popen.
    */
   mode[0] = '\0';
   mode[1] = '\0';
   mode[2] = '\0';

/*
 * The following code is operating-system dependent. Set mode[3] if used.
 */

#if PORT
   /* nothing to do */
#endif					/* PORT */

#if ATARI_ST || MSDOS
   mode[3] = '\0';
#endif					/* ATARI_ST || MSDOS */

#if AMIGA || MACINTOSH || UNIX || VMS
   /* nothing to do */
#endif					/* AMIGA || MACINTOSH || UNIX || VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   if ((status & (Fs_Read|Fs_Write)) == 0)   /* default: read only */
      status |= Fs_Read;
   if (status & Fs_Create)
      mode[0] = 'w';
   else if (status & Fs_Append)
      mode[0] = 'a';
   else if (status & Fs_Read)
      mode[0] = 'r';
   else
      mode[0] = 'w';

/*
 * The following code is operating-system dependent. Handle open modes.
 */

#if PORT
   if ((status & (Fs_Read|Fs_Write)) == (Fs_Read|Fs_Write))
      mode[1] = '+';
#endif					/* PORT */

#if ATARI_ST
   if ((status & (Fs_Read|Fs_Write)) == (Fs_Read|Fs_Write)) {
      mode[1] = '+';
      mode[2] = untranslated ? 'b' : 'a';
      }
   else mode[1] = untranslated ? 'b' : 'a';
#endif					/* ATARI_ST */

#if MSDOS
   if ((status & (Fs_Read|Fs_Write)) == (Fs_Read|Fs_Write)) {
      mode[1] = '+';
      mode[2] = untranslated ? 'b' : 't';
      }
   else mode[1] = untranslated ? 'b' : 't';
#endif					/* MSDOS */

#if AMIGA || MACINTOSH || UNIX || VMS
   if ((status & (Fs_Read|Fs_Write)) == (Fs_Read|Fs_Write))
      mode[1] = '+';
#endif					/* AMIGA || MACINTOSH || UNIX || VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   /*
    * Open the file with fopen or popen.
    */

/*
 * The following code is operating-system dependent. Handle opening pipes
 * if supported.
 */

#if PORT
   /* not supported */
#endif					/* PORT */

#if AMIGA || ATARI_ST || MACINTOSH || MSDOS
   /* not supported */
#endif					/* AMIGA || ATARI_ST || MACINTOSH ... */

#if UNIX || VMS
   if (status & Fs_Pipe) {
      if (status != (Fs_Read|Fs_Pipe) && status != (Fs_Write|Fs_Pipe)) 
         RunErr(209, &Arg2);
      f = popen(openstring, mode);
      }
   else
#endif					/* UNIX || VMS */

#if VM || MVS
#endif					/* VM || MVS */


/*
 * End of operating-system specific code.
 */

      f = fopen(openstring, mode);
   /*
    * Fail if the file cannot be opened.
    */
   if (f == NULL)
      Fail;
/*
 * The following code is operating-system dependent. Problem with
 *  run-time systems that do an sbrk to allocate buffers and
 *  block Icon's region expansion in the expandable-regions mode.
 */

#if PORT
#endif					/* PORT */

#if AMIGA || ATARI_ST || MACINTOSH
   /* do nothing */
#endif					/* AMIGA || ATARI_ST || MACINTOSH */

#if MSDOS
#if LATTICE
  {
    /*
     * Prevent Lattice from doing its own buffer allocation - it uses
     *  low-level storage management.
     */
    char *buf;
    buf = malloc(BUFSIZ);
    if (buf == NULL)
      RunErr(-305, NULL);
    setbuf(f,buf);
  }
#endif					/* LATTICE */
#endif					/* MSDOS */

#if UNIX || VM || MVS || VMS
   /* do nothing */
#endif					/* UNIX || VM || MVS || VMS */

/*
 * End of operating-system specific code.
 */

   /*
    * Return the resulting file value.
    */
   Arg0.dword = D_File;
   BlkLoc(Arg0) = (union block *) alcfile(f, status, &Arg1);
   ntended = 0;
   Return;
   }

/*
 * read(f) - read line on file f.
 */
FncDcl(read,1)
   {
   register word slen, rlen;
   register char *sp;
   int status;
   static char sbuf[MaxReadStr];
   FILE *f;
   extern char *alcstr();

   /*
    * Default Arg1 to &input.
    */
   if (deffile(&Arg1, &input) == Error) 
      RunErr(0, NULL);

   /*
    * Get a pointer to the file and be sure that it is open for reading.
    */
   f = BlkLoc(Arg1)->file.fd;
   status = BlkLoc(Arg1)->file.status;
   if ((status & Fs_Read) == 0) 
      RunErr(212, &Arg1);

   /*
    * Use getstr to read a line from the file, failing if getstr
    *  encounters end of file.
    */
   StrLen(Arg0) = 0;
   do {
      if ((slen = getstr(sbuf,MaxReadStr,f)) == -1)
         Fail;
      /*
       * Allocate the string read and make Arg0 a descriptor for it.
       */
      rlen = slen < 0 ? MaxReadStr : slen;
      if (strreq(rlen) == Error) 
         RunErr(0, NULL);
      sp = alcstr(sbuf,rlen);
      if (StrLen(Arg0) == 0) StrLoc(Arg0) = sp;
      StrLen(Arg0) += rlen;
      } while (slen < 0);
   Return;
   }

/*
 * reads(f,i) - read i characters on file f.
 */
FncDcl(reads,2)
   {
   register word cnt;
   long tally, n;
   char *s;
   int status;
   FILE *f;

   /*
    * Arg1 defaults to &input and Arg2 defaults to 1 (character).
    */
   if ((deffile(&Arg1, &input) == Error) ||
       (defshort(&Arg2, 1) == Error)) 
      RunErr(0, NULL);

   /*
    * Get a pointer to the file and be sure that it is open for reading.
    */
   f = BlkLoc(Arg1)->file.fd;
   status = BlkLoc(Arg1)->file.status;
   if ((status & Fs_Read) == 0) 
      RunErr(212, &Arg1);

   /*
    * Be sure that a positive number of bytes is to be read.
    */
   if ((cnt = IntVal(Arg2)) <= 0) 
      RunErr(205, &Arg2);

   /*
    * Ensure that enough space for the string exists and read it directly
    *  into the string space.  (By reading directly into the string space,
    *  no arbitrary restrictions are placed on the size of the string that
    *  can be read.)  Make Arg0 a descriptor for the string and return it.
    */
   if (strreq(cnt) == Error) 
      RunErr(0, NULL);
   if (strfree + cnt > strend)
      syserr("string allocation botch");
   StrLoc(Arg0) = strfree;

/*
 * The following code is operating-system dependent. Interactive files
 *  may need special handling.
 */

#if PORT
   /* probably nothing to do */
#endif					/* PORT */

#if AMIGA
   if (IsInteractive(fileno(f))) {
      if ((cnt = longread(fileno(f),StrLoc(Arg0),cnt)) <= 0)
         Fail;
      StrLen(Arg0) = cnt;
      strfree += cnt;
      Return;
      }
#endif					/* AMIGA */

#if ATARI_ST || MACINTOSH || MSDOS || UNIX || VMS
   /* nothing to do */
#endif					/* ATARI_ST || MACINTOSH || MSDOS ... */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */
 
   tally = 0;
   s = StrLoc(Arg0);
   while (cnt > 0) {
      n = fread(s, sizeof(char), (int)((cnt < MaxIn) ? cnt: MaxIn), f);
      if (n <= 0)
         break;
      tally += n;
      s += n;
      cnt -= n;
      }  
   if (tally == 0)
      Fail;
   StrLen(Arg0) = tally;
   strfree += tally;
   Return;
   }

/*
 * remove(s) - remove the file named s.
 */

FncDcl(remove,1)
   {
   char sbuf[MaxCvtLen];

   /*
    * Make a C-style string out of Arg1
    */
   switch (cvstr(&Arg1, sbuf)) {

      case Cvt:   /* Already converted to a C-style string */
         break;

      case NoCvt:
         qtos(&Arg1, sbuf);
         break;

      default:
         RunErr(103, &Arg1);
      }

/*
 * The following code is operating-system dependent. Remove the file, and
 *  fail if unsuccessful.
 */

#if PORT
   /* need something */
#endif					/* PORT */

#if AMIGA || ATARI_ST || MSDOS || VMS
   if (remove(StrLoc(Arg1)) != 0)
      Fail;
#endif					/* AMIGA || || ATARI_ST || MSDOS ... */

#if MACINTOSH || UNIX
   if (unlink(StrLoc(Arg1)) != 0)
      Fail;
#endif					/* MACINTOSH || UNIX */

#if VM || MVS
   /* need something */
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   Arg0 = nulldesc;
   Return;
   }

/*
 * rename(s1,s2) - rename the file named s1 to have the name s2.
 */

FncDcl(rename,2)
   {
   char sbuf1[MaxCvtLen], sbuf2[MaxCvtLen];

   /*
    * Make a C-style string out of Arg1
    */
   switch (cvstr(&Arg1, sbuf1)) {

      case Cvt:   /* Already converted to a C-style string */
         break;

      case NoCvt:
         qtos(&Arg1, sbuf1);
         break;

      default:
         RunErr(103, &Arg1);
      }

   /*
    * Make a C-style string out of Arg2
    */
   switch (cvstr(&Arg2, sbuf2)) {

      case Cvt:   /* Already converted to a C-style string */
         break;

      case NoCvt:
         qtos(&Arg2, sbuf2);
         break;

      default:
         RunErr(103, &Arg2);
      }

/*
 * The following code is operating-system dependent. Rename the file, and
 *  fail if unsuccessful.
 */

#if PORT
   /* need something */
#endif					/* PORT */

#if ATARI_ST || MACINTOSH
   Fail;			/* no can do */
#endif					/* ATARI_ST || MACINTOSH */

#if AMIGA || MSDOS || VMS
   {
   int i;
   if ((i = rename(StrLoc(Arg1),StrLoc(Arg2)) != 0)) {
#ifdef DeBug
      fprintf(stderr,"rename error code %d\n",i);
      fflush(stderr);
#endif					/* DeBug */
      Fail;
      }
   }
#endif					/* AMIGA || MSDOS || VMS */

#if UNIX
   if (link(StrLoc(Arg1),StrLoc(Arg2)) != 0)
      Fail;
   if (unlink(StrLoc(Arg1)) != 0) {
      unlink(StrLoc(Arg2));	/* try to undo partial rename */
      Fail;
      }
#endif					/* UNIX */

#if VM || MVS
   /* need something */
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   Arg0 = nulldesc;
   Return;
   }

#ifdef ExecImages
/*
 * save(s) - save the run-time system in file s
 */

FncDcl(save,1)
   {
   char sbuf[MaxCvtLen];
   int f, fsz;

   dumped = 1;

   /* if (ChkNull(Arg1)) { abort(); } */

   /*
    * Make a C-style string out of Arg1.
    */
   switch (cvstr(&Arg1, sbuf)) {

      case Cvt:   /* Already converted to a C-style string */
         break;

      case NoCvt:
         qtos(&Arg1, sbuf);
         break;

      default:
         RunErr(103, &Arg1);
      }


   /*
    * Open the file for the executable image.
    */
   f = creat(StrLoc(Arg1), 0777);
   if (f == -1)
      Fail;
   fsz = wrtexec(f);
   /*
    * It happens that most wrtexecs don't check the system call return
    *  codes and thus they'll never return -1.  Nonetheless...
    */
   if (fsz == -1)
      Fail;
   /*
    * Return the size of the data space.
    */
   MkIntT(fsz, &Arg0);
   Return;
   }

#endif					/* ExecImages */

/*
 * seek(file,position) - seek to byte byte position in file.
 */

FncDcl(seek,2)
   {
   long l1;
   FILE *fd;

   if (Arg1.dword != D_File) 
      RunErr(-105, NULL);

   if (defint(&Arg2, &l1, 1L) == Error)
      RunErr(0, NULL);

   fd = BlkLoc(Arg1)->file.fd;

   if (BlkLoc(Arg1)->file.status == 0)
      Fail;
    if (l1 > 0) {
       if (fseek(fd, l1 - 1, 0) == -1)
          Fail;
       }
    else {
       if (fseek(fd, l1, 2) == -1)
          Fail;
       }
   Arg0 = Arg1;
   Return;
   }

/*
 * stop(a,b,...) - write arguments (starting on error output) and stop.
 */

FncDclV(stop)
    {
   register word n;
   char sbuf[MaxCvtLen];
   FILE *f;
#ifdef BadCode
   struct descrip temp;
#endif					/* BadCode */

   f = stderr;
   ntended = 0;
   /*
    * Loop through arguments.
    */

   for (n = 1; n <= nargs; n++) {
#ifdef BadCode 
      temp = Arg(n);			/* workaround for Microsoft C bug */
      tended[1] = temp;
#else					/* BadCode */
      tended[1] = Arg(n);
#endif					/* BadCode */
      if (tended[1].dword == D_File) {
         if (n > 1)
            putc('\n', f);
         if ((BlkLoc(tended[1])->file.status & Fs_Write) == 0) 
            RunErr(213, &tended[1]);
         f = BlkLoc(tended[1])->file.fd;
         }
      else {
         if (n == 1 && (k_output.status & Fs_Write) == 0) 
            RunErr(-213, NULL);
         if (ChkNull(tended[1]))
            tended[1] = emptystr;
         if (cvstr(&tended[1], sbuf) == CvtFail) 
            RunErr(109, &tended[1]);
         putstr(f, &tended[1]);
         }
      }

   putc('\n', f);
   c_exit(ErrorExit);
   }

/*
 * system(s) - execute string s as a system command.
 */

FncDcl(system,1)
   {
   char sbuf[MaxCvtLen];
   char *systemstring;

   /*
    * Make a C-style string out of Arg1
    */
   switch (cvstr(&Arg1, sbuf)) {

      case Cvt:   /* Already converted to a C-style string */
         break;

      case NoCvt:
         qtos(&Arg1, sbuf);
         break;

      default:
         RunErr(103, &Arg1);
      }
      systemstring = StrLoc(Arg1);

   /*
    * Pass the C string to the system() function and return the exit code
    *  of the command as the result of system().
    */

/*
 * The following code is operating-system dependent. Perform system call.
 *  Should be RunErr(-121, NULL) if not supported.

#if PORT
   RunErr(-121, NULL);
#endif					/* PORT */

#if ATARI_ST
   MkIntT(system(systemstring), &Arg0);
#endif					/* ATARI_ST */

#if MACINTOSH
#if MPW
   RunErr(-121, NULL);
#endif					/* MPW */
#endif					/* MACINTOSH */

#if AMIGA || UNIX || MSDOS
   MkIntT((long)((system(systemstring) >> 8) & 0377), &Arg0);
   Return;
#endif					/* AMIGA || UNIX || MSDOS */

#if VM || MVS
#endif					/* VM || MVS */

#if VMS
   MkIntT((long)system(systemstring), &Arg0);
   Return;
#endif					/* VMS */

/*
 * End of operating-system specific code.
 */
   }

/*
 * where(file) - return current offset position in file.
 */

FncDcl(where,1)
   {
   FILE *fd;
   long ftell();

   if (Arg1.dword != D_File) 
      RunErr(-105, NULL);

   fd = BlkLoc(Arg1)->file.fd;

   if ((BlkLoc(Arg1)->file.status == 0))
      Fail;

   MkIntT(ftell(fd) + 1, &Arg0);
   Return;
   }

/*
 * write(a,b,...) - write arguments.
 */
FncDclV(write)
   {
   register word n;
   char sbuf[MaxCvtLen];
   FILE *f;
   extern char *alcstr();
#ifdef BadCode
   struct descrip temp;
#endif					/* BadCode */

   f = stdout;
   ntended = 1;
   tended[1] = emptystr;

   /*
    * Loop through the arguments.
    */
   for (n = 1; n <= nargs; n++) {
#ifdef BadCode
      temp = Arg(n);			/* workaround for Microsoft bug */
      tended[1] = temp;
#else					/* BadCode */
      tended[1] = Arg(n);
#endif					/* BadCode */
      if (tended[1].dword == D_File)	{	/* Current argument is a file */
         /*
          * If this is not the first argument, output a newline to the current
          *  file and flush it.
          */
         if (n > 1) {
            putc('\n', f);
            fflush(f);
            }
         /*
          * Switch the current file to the file named by the current argument
          *  providing it is a file.  tended[1] is made to be a empty string to
          *  avoid a special case.
          */
         if ((BlkLoc(tended[1])->file.status & Fs_Write) == 0) 
            RunErr(213, &tended[1]);
         f = BlkLoc(tended[1])->file.fd;
         tended[1] = emptystr;
         }
      else {	/* Current argument is a string */
         /*
          * On first argument, check to be sure that &output is open
          *  for output.
          */
         if (n == 1 && (k_output.status & Fs_Write) == 0) 
            RunErr(-213, NULL);

         /*
          * Convert the argument to a string, defaulting to a empty string.
          */
         if (ChkNull(tended[1]))
            tended[1] = emptystr;
         if (cvstr(&tended[1], sbuf) == CvtFail) 
            RunErr(109, &tended[1]);

         /*
          * Output the string.
          */
         if (putstr(f, &tended[1]) == Failure) 
            RunErr(-214, NULL);
         }
      }
   /*
    * Append a newline to the file and flush it.
    */
   putc('\n', f);
   if (ferror(f)) 
      RunErr(-214, NULL);

   fflush(f);

   /*
    * Return the last argument.
    */
   ntended = 0;
   Arg(0) = Arg(n - 1);
   Return;
   }

/*
 * writes(a,b,...) - write arguments without newline terminator.
 */

FncDclV(writes)
   {
   register word n;
   char sbuf[MaxCvtLen];
   FILE *f;
   extern char *alcstr();
#ifdef BadCode
   struct descrip temp;
#endif					/* BadCode */

   f = stdout;
   ntended = 1;
   tended[1] = emptystr;

   /*
    * Loop through the arguments.
    */
   for (n = 1; n <= nargs; n++) {
#ifdef BadCode
      temp = Arg(n);			/* workaround for Microsoft bug */
      tended[1] = temp;
#else					/* BadCode */
      tended[1] = Arg(n);
#endif					/* BadCode */
      if (tended[1].dword == D_File)	{	/* Current argument is a file */
         /*
          * Switch the current file to the file named by the current argument
          *  providing it is a file.  tended[1] is made to be a empty string to
          *  avoid a special case.
          */
         if ((BlkLoc(tended[1])->file.status & Fs_Write) == 0) 
            RunErr(213, &tended[1]);
         f = BlkLoc(tended[1])->file.fd;
         tended[1] = emptystr;
         }
      else {	/* Current argument is a string */
         /*
          * On first argument, check to be sure that &output is open
          *  for output.
          */
         if (n == 1 && (k_output.status & Fs_Write) == 0) 
            RunErr(-213, NULL);

         /*
          * Convert the argument to a string, defaulting to a empty string.
          */
         if (ChkNull(tended[1]))
            tended[1] = emptystr;
         if (cvstr(&tended[1], sbuf) == CvtFail) 
            RunErr(109, &tended[1]);
         /*
          * Output the string and flush the file.
          */
         if (putstr(f, &tended[1]) == Failure) 
            RunErr(-214, NULL);
         fflush(f);
         }
      }
   /*
    * Return the last argument.
    */
   ntended = 0;
   Arg(0) = Arg(n - 1);
   Return;
   }
