/*
	Blocks() - generate the blocks in the heap
 */
FncDcl(Blocks,0)
   {
   register char *bp;
   bp = blkbase;
   while (bp < blkfree) {
      BlkLoc(Arg0) = (union block *)bp;
      Arg0.dword = *(int *)bp | F_Ptr | F_Nqual;
      Suspend;
      bp = (char *)BlkLoc(Arg0);
      bp += BlkSize(bp);
      }
   Fail;
   }

FncDcl(descr,1)
   {
   descr(&Arg1);
   Arg0 = nulldesc;
   Return;
   }

FncDcl(blkdump,0)
   {
   blkdump();
   Arg0 = nulldesc;
   Return;
   }

char *ftable[] = {
#define FncDef(p) Lit(p)
#include "../h/fdefs.h"
   };

FncDcl(functions,0)
   {
   register int i;

   for (i = 0; i < (sizeof(ftable)/sizeof(char *)); i++) {
      StrLen(Arg0) = strlen(ftable[i]);
      StrLoc(Arg0) = ftable[i];
      Suspend;
      }
   Fail;
   }

/*
 * hash(x) - return hash number for x
 */

FncDcl(hash,1)
   {
   MkIntT(hash(&Arg1), &Arg0);
   Return;
   }

/*
 * inheap(x)
 */

FncDcl(inheap,1)
   {
   if (Pointer(Arg1) && (char *)BlkLoc(Arg1) >= blkbase &&
      (char *)BlkLoc(Arg1) < blkfree) {
      Arg0 = Arg1;
      Return;
      }
   else Fail;
   }

/*
 * Strings() - produce the entire allocated string region.
 */
FncDcl(Strings,0)
   {
   StrLoc(Arg0) = strbase;
   StrLen(Arg0) = (int)strfree - (int)strbase;
   Return;
   }

FncDcl(Args,0)
   {
   MkIntT(pfp->pf_nargs,&Arg0);
   Return;
   }

FncDcl(Arg,1)
   {
   int i;
   struct descrip *dp;

   if (cvint(&Arg1,&i) == CvtFail) 
      RunErr(101, &Arg1);
   if (i < 0) 
      RunErr(205, &Arg1);
   if (i > pfp->pf_nargs)
      Fail;
   dp = (struct descrip *)argp;
   dp += i;
   Arg0 = *dp;
   Return;
   }

/*
 * globalnames() - generate the names of the global variables
 */

FncDcl(globalnames,0)
   {
   struct descrip *np;
   extern struct descrip *gnames, *egnames;

   for (np = gnames; np < egnames; np++) {
      Arg0 = *np;
      Suspend;
      }
   Fail;

   }
/*
 * globalvar(s) - find the global variable with name s and return a
 *    variable descriptor that points to its value.
 */

FncDcl(globalvar,1)
   {
   register struct descrip *dp;
   register struct descrip *np;
   extern struct descrip *globals, *eglobals;
   extern struct descrip *gnames;
   dp = globals;
   np = gnames;
   while (dp < eglobals) {
      if (eq(&Arg1, np) == 1) {
        Arg0.dword    =  D_Var;
	VarLoc(Arg0) =  (struct descrip *)(dp);
	Return;
	}
      np++;
      dp++;
      }
   Fail;		/* fail if no such variable was found */

   }

/* eq - compare two Icon strings for equality */
eq(d1, d2)
struct descrip *d1, *d2;
{
	char *s1, *s2;
	int i;

	if (StrLen(*d1) != StrLen(*d2))
	   return(0);
	s1 = StrLoc(*d1);
	s2 = StrLoc(*d2);
	for (i = 0; i <= StrLen(*d1); i++)
	   if (*s1++ != *s2++) 
	      return 0;
	return 1;
}

