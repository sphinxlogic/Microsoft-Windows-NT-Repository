/*
 * File: rdefault.c
 *  Contents: defcset, deffile, defint, defshort, defstr
 */

#include "../h/rt.h"

/*
 * defcset(dp,cp,buf,def) - if dp is null, default to def;
 *  otherwise, convert to cset or die trying.
 */

defcset(dp, cp, buf, def)
struct descrip *dp;
int **cp;
int *buf, *def;
   {
   if (ChkNull(*dp)) {
      *cp = def;
      return Defaulted;
      }
   if (cvcset(dp, cp, buf) == CvtFail) 
      RetError(104, *dp);
   return Success;
   }

/*
 * deffile - if dp is null, default to def; otherwise, make sure it's a file.
 */

deffile(dp, def)
struct descrip *dp, *def;
   {
   if (ChkNull(*dp)) {
      *dp = *def;
      return Defaulted;
      }
   if (Qual(*dp) || (*dp).dword != D_File)
      RetError(105, *dp);
   return Success;
   }

/*
 * defint - if dp is null, default to def; otherwise, convert to integer.
 *  Note that *lp gets the value.
 */

defint(dp, lp, def)
struct descrip *dp;
long *lp;
word def;
   {
   if (ChkNull(*dp)) {
      *lp = (long)def;
      return Defaulted;
      }
   if (cvint(dp, lp) == CvtFail)
      RetError(101, *dp);
   return Success;
   }

/*
 * defshort - if dp is null, default to def; otherwise, convert to short
 *  integer.  The result is an integer value in *dp.
 */

defshort(dp, def)
struct descrip *dp;
int def;
   {
   long l;

   if (ChkNull(*dp)) {
      MkIntR((int)def, dp);
      return Defaulted;
      }
   switch (cvint(dp, &l)) {

      case T_Integer:
         MkIntR(l, dp);
	 return Success;

      default:
	 RetError(101, *dp);
      }
   }

/*
 * defstr - if dp is null, default to def; otherwise, convert to string.
 *  *dp gets a descriptor for the resulting string.  buf is used as
 *  a scratch buffer for the conversion (if necessary).
 */

defstr(dp, buf, def)
struct descrip *dp;
char *buf;
struct descrip *def;
   {
   int retcode;

   if (ChkNull(*dp)) {
      *dp = *def;
      return Defaulted;
      }

   retcode = cvstr(dp, buf);
   if (retcode == CvtFail)
      RetError(103, *dp)
   else
      return retcode;
   }
