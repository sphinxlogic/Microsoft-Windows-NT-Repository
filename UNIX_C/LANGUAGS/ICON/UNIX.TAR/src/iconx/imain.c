/*
 * Initialization and error routines.
 */

#include "../h/rt.h"
#include "../h/version.h"
#include "gc.h"
#include "../h/header.h"
#include "../h/opdefs.h"
#include <ctype.h>

#ifdef MemMon
#define IconInit MMInit
#define IconTerm MMTerm
#else						/* MemMon */
#define IconInit()
#define IconTerm()
#endif						/* MemMon */

/*
 * The following code is operating-system dependent. Include files and
 *  declarations that are are system-dependent.
 */

#if PORT
#include <signal.h>
   /* probably needs something more */
#endif					/* PORT */

#if AMIGA
#include <signal.h>
#include <time.h>
#include <fcntl.h>

int chkbreak;				/* if nonzero, check for ^C */
#endif					/* AMIGA */

#if ATARI_ST
#include "fcntl.h"			/* locally provided version */
struct tms {
   unsigned int tms_utime;		/* user time */
   int tm_year;
   int tm_mon;
   int tm_mday;
   int tm_hour;
   int tm_min;
   int tm_sec;
   };
struct tms *tbuf;
#endif					/* ATARI_ST */

#if MACINTOSH
#include <signal.h>
#if MPW
#include <Types.h>
#include <Events.h>
#include <FCntl.h>
#include <SANE.h>
#include SysTime
#endif					/* MPW */
#endif					/* MACINTOSH */

#if MSDOS
#include <fcntl.h>
#include <signal.h>
#include <time.h>
#if MICROSOFT
#include <sys/types.h>
#endif					/* MICROSOFT */
#endif					/* MSDOS */

#if UNIX
#include <signal.h>
#include <sys/types.h>
#include <sys/times.h>
#endif					/* UNIX */

#if VM || MVS
#endif					/* VM || MVS */

#if VMS
#include <signal.h>
#include <types.h>
struct tms {
   time_t tms_utime;		/* user time */
   time_t tms_stime;		/* system time */
   time_t tms_cutime;		/* user time, children */
   time_t tms_cstime;		/* system time, children */
   };
#endif					/* VMS */

/*
 * End of operating-system specific code.
 */

#ifdef IconAlloc
#define malloc mem_alloc
#endif					/* IconAlloc */

#ifndef MaxHeader
#define MaxHeader MaxHdr
#endif					/* MaxHeader */

/*
 * A number of important variables follow.
 */

#ifndef NoTraceBack
extern struct b_proc *opblks[];
extern word lastop;
extern struct descrip *xargp;
extern word xnargs;
#endif					/* NoTraceBack */

extern putpos();			/* assignment function for &pos */
extern putran();			/* assignment function for &random */
extern putsub();			/* assignment function for &subject */
extern puttrc();			/* assignment function for &trace */
extern puterr();			/* assignment function for &error */

word *stack;				/* interpreter stack */
int k_level = 0;			/* &level */
int k_errornumber = 0;			/* &errornumber */
char *k_errortext = "";			/* &errortext */
struct descrip k_errorvalue;		/* &errorvalue */
struct descrip k_main;			/* &main */
char *code;				/* interpreter code buffer */
word *records;				/* pointer to record procedure blocks */
word *ftab;				/* pointer to record/field table */
struct descrip *fnames, *efnames;       /* pointer to field names */
struct descrip *globals, *eglobals;	/* pointer to global variables */
struct descrip *gnames, *egnames;	/* pointer to global variable names */
struct descrip *statics, *estatics;	/* pointer to static variables */
char *strcons;				/* pointer to string constant table */
struct ipc_fname *filenms, *efilenms;	/* pointer to ipc/file name table */
struct ipc_line *ilines, *elines;	/* pointer to ipc/line number table */

#ifdef TallyOpt
word tallybin[16];			/* counters for tallying */
int tallyopt = 0;			/* want tally results output? */
#endif					/* TallyOpt */

word mstksize = MStackSize;		/* initial size of main stack */
word stksize = StackSize;		/* co-expression stack size */
struct b_coexpr *stklist;		/* base of co-expression block list */

word statsize = MaxStatSize;		/* size of static region */
word statincr = MaxStatSize/4;		/* increment for static region */
char *statbase = NULL;			/* start of static space */
char *statend;				/* end of static space */
char *statfree;				/* static space free pointer */

word ssize = MaxStrSpace;		/* initial string space size (bytes) */
char *strbase;				/* start of string space */
char *strend;				/* end of string space */
char *strfree;				/* string space free pointer */
char *currend = NULL;			/* current end of memory region */

word abrsize = MaxAbrSize;		/* initial size of allocated block
						region (bytes) */
char *blkbase;				/* start of block region */
char *blkend;				/* end of allocated blocks */
char *blkfree;				/* block region free pointer */

#ifdef FixedRegions
word qualsize = QualLstSize;		/* size of quallist for fixed regions */
#endif					/* FixedRegions */

uword statneed;				/* stated need for static space */
uword strneed;				/* stated need for string space */
uword blkneed;				/* stated need for block space */

int dodump;				/* if nonzero, core dump on error */
int noerrbuf;				/* if nonzero, do not buffer stderr */

struct descrip k_current;		/* current expression stack pointer */
struct descrip maps2;			/* second cached argument of map */
struct descrip maps3;			/* third cached argument of map */

int ntended = 0;			/* number of active tended descrips */
long starttime;				/* start time of job in milliseconds */

#ifdef ExecImages
int dumped = 0;				/* non-zero if reloaded from dump */
#endif					/* ExecImages */

/*
 * Run-time error numbers and text.
 */
struct errtab {
   int errno;
   char *errmsg;
   } errtab[] = {
   101, "integer expected",
   102, "numeric expected",
   103, "string expected",
   104, "cset expected",
   105, "file expected",
   106, "procedure or integer expected",
   107, "record expected",
   108, "list expected",
   109, "string or file expected",
   110, "string or list expected",
   111, "variable expected",
   112, "invalid type to size operation",
   113, "invalid type to random operation",
   114, "invalid type to subscript operation",
   115, "list or table expected",
   116, "invalid type to element generator",
   117, "missing main procedure",
   118, "co-expression expected",
   119, "set expected",
   120, "cset or set expected",
   121, "function not supported",
   122, "set or table expected",

   201, "division by zero",
   202, "remaindering by zero",
   203, "integer overflow",
   204, "real overflow, underflow, or division by zero",
   205, "value out of range",
   206, "negative first operand to real exponentiation",
   207, "invalid field name",
   208, "second and third arguments to map of unequal length",
   209, "invalid second argument to open",
   210, "non-ascending arguments to detab/entab",
   211, "by clause equal to zero",
   212, "attempt to read file not open for reading",
   213, "attempt to write file not open for writing",
   214, "input/output error",

   301, "interpreter stack overflow",
   302, "C stack overflow",
   303, "inadequate space for interpreter stack",
   305, "inadequate space in static region",
   306, "inadequate space in string region",
   307, "inadequate space in block region",

#ifdef FixedRegions
   304, "inadequate space in qualifier list",
#endif					/* FixedRegions */

#ifdef NoCoexpr
   401, "co-expressions not implemented",
#endif					/* NoCoexpr */

   500, "program malfunction",		/* for use by runerr() */

/*
 * The following code is operating-system dependent.  Define additional error
 *  codes and messages.
 */

#if PORT
   /* none here */
#endif					/* PORT */

#if AMIGA  || ATARI_ST || MACINTOSH || MSDOS || UNIX
   /* none here */
#endif					/* AMIGA || ATARI_ST || MACINTOSH ... */

#if VMS
   351, "insufficient MAXMEM limit",
#endif					/* VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   0,	0
   };

/*
 * Structures for built-in values.  Parts of some of these structures are
 *  initialized later. Since some C compilers cannot handle any partial
 *  initializations, all parts are initialized later if any have to be.
 */

/*
 * Built-in csets
 */

/*
 * &ascii; 128 bits on, second 128 bits off.
 */
struct b_cset  k_ascii = {
   T_Cset,
   128,
   cset_display(~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0,
                 0,  0,  0,  0,  0,  0,  0,  0)
   };

/*
 * &cset; all 256 bits on.
 */
struct b_cset  k_cset = {
   T_Cset,
   256,
   cset_display(~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0,
		~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0)
   };

/*
 * &digits; bits corrosponding to 0-9 are on.
 */
struct b_cset  k_digits = {
   T_Cset,
   10,
#ifndef EBCDIC
   cset_display(0,  0,	0,  0x3ff, 0,  0, 0,  0,
		0,  0,	0,  0,	 0,  0,	 0,  0)
#else					/* EBCDIC */
   cset_display(0,  0,	0,  0,	0,  0,	0,  0,
		0,  0,	0,  0,  0,  0,  0,  0x3ff)
#endif					/* EBCDIC */
   };

/*
 * Cset for &lcase; bits corresponding to lowercase letters are on.
 */
struct b_cset  k_lcase = {
   T_Cset,
   26,
#ifndef EBCDIC
   cset_display(0,  0,	0,  0,	0,  0,	~01,  03777,
		0,  0,	0,  0,	0,  0,	0,  0)
#else					/* EBCDIC */
   cset_display(0,  0,	0,  0,	0,  0,	0,  0,
		0x3fe,	0x3fe,	0x3fc,	0,  0,	0,  0,	0)
#endif					/* EBCDIC */
   };

/*
 * &ucase; bits corresponding to uppercase characters are on.
 */
struct b_cset  k_ucase = {
   T_Cset,
   26,
#ifndef EBCDIC
   cset_display(0,  0,	0,  0,	~01,  03777, 0, 0,
		0,  0,	0,  0,	0,  0,	0,  0)
#else					/* EBCDIC */
   cset_display(0,  0,	0,  0,	0,  0,	0,  0,
		0,  0,	0,  0,	0x3fe,	0x3fe,	0x3fc,	0)
#endif					/* EBCDIC */
   };

/*
 * Built-in files.
 */

struct b_file  k_errout = {T_File, NULL, Fs_Write};	/* &errout */
struct b_file  k_input = {T_File, NULL, Fs_Read};	/* &input */
struct b_file  k_output = {T_File, NULL, Fs_Write};	/* &outout */

/*
 * Keyword trapped variables.
 */

struct b_tvkywd tvky_pos = {T_Tvkywd, putpos, {D_Integer}};	/* &pos */
struct b_tvkywd tvky_ran = {T_Tvkywd, putran, {D_Integer}};	/* &random */
struct b_tvkywd tvky_sub = {T_Tvkywd, putsub}; 			/* &subject */
struct b_tvkywd tvky_trc = {T_Tvkywd, puttrc, {D_Integer}};	/* &trace */
struct b_tvkywd tvky_err = {T_Tvkywd, puterr, {D_Integer}};	/* &error */

/*
 * Co-expression block header for &main.
 */

static struct b_coexpr *mainhead;

/*
 * Various constant descriptors.
 */

struct descrip blank; 			/* one-character blank string */
struct descrip emptystr; 		/* zero-length empty string */
struct descrip errout = {D_File};	/* &errout */
struct descrip input = {D_File};	/* &input */
struct descrip lcase;			/* string of lowercase letters */
struct descrip letr;			/* "r" */
struct descrip nulldesc = {D_Null};	/* null value */
struct descrip onedesc = {D_Integer};	/* integer 1 */
struct descrip ucase;			/* string of uppercase letters */
struct descrip zerodesc = {D_Integer};	/* integer 0 */

/*
 * init - initialize memory and prepare for Icon execution.
 */

#ifdef SCO_XENIX
extern unsigned int read();		/* not very portable ... */
#endif					/* SCO_XENIX */

init(name)
char *name;
   {
   word cbread, longread();
   int f, n;
   struct header hdr;
   int code_open();
   extern pointer malloc();
   extern struct astkblk *alcactiv();

/*
 * The following code is operating-system dependent.  Make declarations
 *  that are system-dependent.
 */

#if PORT
   /* probably needs something */
#endif					/* PORT */

#if AMIGA || MACINTOSH || MSDOS
#endif					/* AMIGA || MACINTOSH || MSDOS */

#if ATARI_ST
   struct tms tp;
   extern *strchr();
#endif					/* ATARI_ST */

#if UNIX || VMS
   struct tms tp;
#endif					/* UNIX || VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   extern fpetrap(), segvtrap();

   /*
    * Catch floating point traps and memory faults.
    */

/*
 * The following code is operating-system dependent. Set traps.
 */

#if PORT
   /* probably needs something */
#endif					/* PORT */

#if AMIGA
   signal(SIGFPE,fpetrap);
#endif					/* AMIGA */

#if ATARI_ST
#endif					/* ATARI_ST */

#if MACINTOSH
#if MPW
   /* This is equivalent to SIGFPE signal in the Standard Apple
      Numeric Environment (SANE) */
   {
   environment e;
   getenvironment(&e);
   setenvironment(e |
	(environment)(INVALID|UNDERFLOW|OVERFLOW|DIVBYZERO));
   sethaltvector(fpetrap);
   }
#endif					/* MPW */
#endif					/* MACINTOSH */

#if MSDOS
#if LATTICE
   signal(SIGFPE, fpetrap);
#endif					/* LATTICE */
#endif					/* MSDOS */

#if UNIX || VMS
#ifndef SCO_XENIX_SMM
   signal(SIGSEGV, segvtrap);
#endif					/* SCO_XENIX_SMM */
#ifdef PYRAMID
   {
   struct sigvec a;

   a.sv_handler = fpetrap;
   a.sv_mask = 0;
   a.sv_onstack = 0;
   sigvec(SIGFPE, &a, 0);
   sigsetmask(1 << SIGFPE);
   }
#else					/* PYRAMID */
   signal(SIGFPE, fpetrap);
#endif					/* PYRAMID */
#endif					/* UNIX || VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

#ifdef ExecImages
   /*
    * If reloading from a dumped out executable, skip most of init and
    *  just set up the buffer for stderr and do the timing initializations.
    */
   if (dumped)
   	goto btinit;
#endif					/* ExecImages */

   /*
    * Initialize data that can't be intialized statically.
    */

   datainit();

   /*
    * Open the icode file and read the header.		[[I?]]
    */

   if (!name)
      error("no interpreter file supplied");

   f = -1;

   /* try adding .icx if the file name doesn't end in .icx or .ICX */
   n = strlen(name);
   if (n <= 4 || (strcmp(name+n-4,".icx")!=0 && strcmp(name+n-4,".ICX")!=0)) {
      char tname[100];
      if (strlen(name) + 5 > 100)
         error("code file name too long");
      strcpy(tname,name);
      strcat(tname,".icx");
      f = code_open(tname);
      }

   if (f < 0)				/* try the name as given */
      f = code_open(name);

   if (f < 0)
      error("can't open interpreter file");

#ifndef NoHeader
   if (lseek(f, (long)MaxHeader, 0) == -1)
      error("can't read interpreter file header");
#endif					/* NoHeader */

   if (read(f, (char *)&hdr, sizeof(hdr)) != sizeof(hdr))
      error("can't read interpreter file header");
    
   k_trace = hdr.trace;

#ifndef NoEnvVars
   /*
    * Examine the environment and make appropriate settings.	[[I?]]
    */
   envset();
#endif					/* NoEnvVars */

   /*
    * Convert stack sizes from words to bytes.
    */

#ifndef SCO_XENIX
   stksize *= WordSize;
   mstksize *= WordSize;
#else					/* SCO_XENIX */
   /*
    * This is a work-around for bad generated code for *= (as above)
    *  produced by the SCO XENIX C Compiler for the large memory model.
    *  It relies on the fact that WordSize is 4.
    */
   stksize += stksize;
   stksize += stksize;
   mstksize += mstksize;
   mstksize += mstksize;
#endif					/* SCO_XENIX */

#if IntBits == 16
   if (mstksize > MaxUnsigned)
      fatalerr(-316, NULL);
   if (stksize > MaxUnsigned)
      fatalerr(-318, NULL);
#endif					/* IntBits == 16 */

   /*
    * Allocate memory for various regions.
    */
   initalloc(hdr.hsize);

   /*
    * Establish pointers to icode data regions.		[[I?]]
    */

   records = (word *)(uword)(code + hdr.records);
   ftab = (word *)(uword)(code + hdr.ftab);
   fnames = (struct descrip *) (code + hdr.fnames);
   globals = efnames = (struct descrip *)(code + hdr.globals);
   gnames = eglobals = (struct descrip *)(code + hdr.gnames);
   statics = egnames = (struct descrip *)(code + hdr.statics);
   estatics = (struct descrip *)(code + hdr.filenms);
   filenms = (struct ipc_fname *)estatics;
   efilenms = (struct ipc_fname *)(code + hdr.linenums);
   ilines = (struct ipc_line *)efilenms;
   elines = (struct ipc_line *)(code + hdr.strcons);
   strcons = (char *)elines;

/*
 * The following code is operating-system dependent.
 */

#if PORT
#endif					/* PORT */

#if AMIGA || ATARI_ST || MACINTOSH
   /* do nothing */
#endif					/* AMIGA || ATARI_ST || MACINTOSH */

#if MSDOS
#if LATTICE
  {
    /*
     * Prevent Lattice from doing its own buffer allocation - it uses
     *   low level storage management.
     */
    char *buf;
    buf = malloc(BUFSIZ);
    if (buf == NULL)
      RunErr(-305, NULL);
    setbuf(stdout,buf);
    buf = malloc(BUFSIZ);
    if (buf == NULL)
      RunErr(-305, NULL);
    setbuf(stdin,buf);
  }
#endif					/* LATTICE */
#endif					/* MSDOS */

#if UNIX || VM || MVS || VMS
   /* do nothing */
#endif					/* UNIX || VM || MVS || VMS */

/*
 * End of operating-system specific code.
 */

   /*
    * Allocate stack and initialize &main.
    */

   stack = (word *)malloc((unsigned int)mstksize);
   if (stack == NULL)
      fatalerr(-303, NULL);
   mainhead = (struct b_coexpr *)stack;
   mainhead->title = T_Coexpr;

#ifndef NoCoexpr
   mainhead->es_actstk = alcactiv();
   if (mainhead->es_actstk == NULL)
      fatalerr(0, NULL);
   if (pushact(mainhead, mainhead) == Error)
      fatalerr(0, NULL);
   mainhead->id = 1;
   mainhead->size = 0;
#endif					/* NoCoexpr */

   mainhead->freshblk = nulldesc;	/* &main has no refresh block. */
					/*  This really is a bug. */

   /*
    * Point &main at the co-expression block for the main procedure and set
    *  k_current, the pointer to the current co-expression, to &main.
    */
   k_main.dword = D_Coexpr;
   BlkLoc(k_main) = (union block *) mainhead;
   k_current = k_main;
   
   /*
    * Read the interpretable code and data into memory.
    */

   if ((cbread = longread(f, code, (long)hdr.hsize)) != hdr.hsize) {
      fprintf(stderr,"Tried to read %ld bytes of code, got %ld\n",
	(long)hdr.hsize,(long)cbread);
      error("can't read interpreter code");
      }
   close(f);

/*
 * Make sure the version number of the icode matches the interpreter version.
 */

   if (strcmp((char *)hdr.config,IVersion)) {
      fprintf(stderr,"icode version mismatch\n");
      fprintf(stderr,"\ticode version: %s\n",(char *)hdr.config);
      fprintf(stderr,"\texpected version: %s\n",IVersion);
      fflush(stderr);
      if (dodump)
         abort();
      c_exit(ErrorExit);
      }

   /*
    * Resolve references from icode to run-time system.
    */
   resolve();

btinit:

/*
 * The following code is operating-system dependent.  Allocate and assign a
 *  buffer to stderr if possible.
 */

#if PORT
#endif					/* PORT */

#if AMIGA
#endif					/* AMIGA */

#if ATARI_ST || MACINTOSH || UNIX || MSDOS || VMS
   if (noerrbuf)
      setbuf(stderr, NULL);
   else {
      char *buf;
      
      buf = (char *)malloc(BUFSIZ);
      if (buf == NULL)
        RunErr(-305, NULL);
      setbuf(stderr, buf);
      }
#endif					/* ATARI_ST || MACINTOSH || UNIX ... */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   /*
    * Perform any special initialization. Normally, it is defined to
    *  be nothing.
    */
   IconInit();

/*
 * The following code is operating-system dependent. Get start time.
 */

#if PORT
   /* needs something */
#endif					/* PORT */

#if AMIGA || MSDOS
   time(&starttime);	/* note: this only obtains time in seconds */
#endif					/* AMIGA || MSDOS */

#if ATARI_ST
   gettime(&tbuf);
   starttime = tbuf->tms_utime;
#endif					/* ATARI_ST */

#if MACINTOSH
#if MPW
   starttime = TickCount();	/* 60 ticks / second */
#endif					/* MPW */
#endif					/* MACINTOSH */

#if UNIX || VMS
   times(&tp);
   starttime = tp.tms_utime;
#endif					/* UNIX || VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   }

/*
 * Service routines related to getting things started.
 */

/*
 * code_open - open icode file.
 */
int code_open(name)
char *name;
   {
/*
 * The following code is operating-system dependent.
 */

#if PORT
   return open(name, 0);
#endif					/* PORT */

#if AMIGA
   return open(name, O_RDONLY);
#endif					/* AMIGA */

#if ATARI_ST
   return open(name,O_RDONLY | O_RAW);
#endif					/* ATARI_ST */

#if MACINTOSH
#if MPW
   return open(name, 0);
#endif					/* MPW */
#endif					/* MACINTOSH */

#if MSDOS
#if LATTICE
   return open(name,O_RDONLY | O_RAW);
#endif					/* LATTICE */

#if MICROSOFT || TURBO
   return open(name,O_RDONLY | O_BINARY);
#endif					/* MICROSOFT || TURBO */
#endif					/* MSDOS */

#if UNIX || VMS
   return open(name, 0);
#endif					/* UNIX || VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   }

/*
 * resolve - perform various fix-ups on the data read from the icode
 *  file.
 */
resolve()
   {
   register word i;
   register struct b_proc *pp;
   register struct descrip *dp;
   extern mkrec();
   extern struct b_proc *functab[];
   extern int ftsize;

   /*
    * Scan the global variable array for procedures and fill in appropriate
    *  addresses.
    */
   for (dp = globals; dp < eglobals; dp++) {
      if ((*dp).dword != D_Proc)
         continue;

      /*
       * The second word of the descriptor for procedure variables tells
       *  where the procedure is.  Negative values are used for built-in
       *  procedures and positive values are used for Icon procedures.
       */
      i = IntVal(*dp);
      if (i < 0) {
         /*
          * *dp names a built-in function, negate i and use it as an index
          *  into functab to get the location of the procedure block.
          */
         i = -i;
         if (i > ftsize - 1) {
            *dp = nulldesc;		/* undefined, set to &null */
            continue;
            }
         BlkLoc(*dp) = (union block *)functab[i-1];
         }
      else {
         /*
          * *dp names an Icon procedure or a record.  i is an offset to
          *  location of the procedure block in the code section.  Point
          *  pp at the block and replace BlkLoc(*dp).
          */
         pp = (struct b_proc *)(code + i);
         BlkLoc(*dp) = (union block *)pp;

         /*
          * Relocate the address of the name of the procedure.
          */
         StrLoc(pp->pname) = strcons + (uword)StrLoc(pp->pname);
         if (pp->ndynam == -2)
            /*
             * This procedure is a record constructor.	Make its entry point
             *	be the entry point of mkrec().
             */
            pp->entryp.ccode = mkrec;
         else {
            /*
             * This is an Icon procedure.  Relocate the entry point and
             *	the names of the parameters, locals, and static variables.
             */
            pp->entryp.icode = code + pp->entryp.ioff;
            for (i = 0; i < abs(pp->nparam)+pp->ndynam+pp->nstatic; i++)
               StrLoc(pp->lnames[i]) = strcons + (uword)StrLoc(pp->lnames[i]);
            }
         }
      }

   /*
    * Relocate the names of the fields.
    */

   for (dp = fnames; dp < efnames; dp++)
      StrLoc(*dp) = strcons + (uword)StrLoc(*dp);

   /*
    * Relocate the names of the global variables.
    */
   for (dp = gnames; dp < egnames; dp++)
      StrLoc(*dp) = strcons + (uword)StrLoc(*dp);
   }

#ifndef NoEnvVars
/*
 * Check for environment variables that Icon uses and set system
 *  values as is appropriate.
 */
envset()
   {
   register char *p;
   extern char *getenv();

   if ((p = getenv("NOERRBUF")) != NULL)
      noerrbuf++;
   env_int("TRACE", &k_trace, 0);
   env_int("COEXPSIZE", &stksize, 1);
   env_int("STRSIZE", &ssize, 1);
   env_int("HEAPSIZE", &abrsize, 1);
   env_int("STATSIZE", &statsize, 1);
   env_int("STATINCR", &statincr, 1);
   env_int("MSTKSIZE", &mstksize, 1);

#ifdef FixedRegions
   env_int("QLSIZE", &qualsize, 1);
#endif					/* FixedRegions */

/*
 * The following code is operating-system dependent. Check any
 *  system-dependent environment variables.
 */

#if PORT
   /* nothing to do */
#endif					/* PORT */

#if AMIGA
   if ((p = getenv("CHECKBREAK")) != NULL)
      chkbreak++;
#endif					/* AMIGA */

#if ATARI_ST || MACINTOSH || MSDOS || UNIX
   /* nothing to do */
#endif					/* ATARI_ST || MACINTOSH || MSDOS ... */

#if VM || MVS
#endif					/* VM || MVS */

#if VMS
   {
      extern word memsize;
      env_int("MAXMEM", &memsize, 1);
   }
#endif					/* VMS */

/*
 * End of operating-system specific code.
 */

   if ((p = getenv("ICONCORE")) != NULL && *p != '\0') {

/*
 * The following code is operating-system dependent. Set trap to give
 *  dump on abnormal termination if ICONCORE is set.
 */

#if PORT
   /* can't handle */
#endif					/* PORT */

#if AMIGA || ATARI_ST || MACINTOSH
   /* can't handle */
#endif					/* AMIGA || ATARI_ST || MACINTOSH */

#if MSDOS
#if LATTICE
      signal(SIGFPE, SIG_DFL);
#endif					/* LATTICE */

#if TURBO
      ssignal(SIGFPE, SIG_DFL);
#endif					/* TURBO */
#endif					/* MSDOS */

#if UNIX || VMS
      signal(SIGSEGV, SIG_DFL);
#endif					/* UNIX || VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */
      dodump++;
      }
   }

static env_err(msg, name, val)
char *msg;
char *name;
char *val;
{
   char msg_buf[100];

   strncpy(msg_buf, msg, 99);
   strncat(msg_buf, ": ", 99 - strlen(msg_buf));
   strncat(msg_buf, name, 99 - strlen(msg_buf));
   strncat(msg_buf, "=", 99 - strlen(msg_buf));
   strncat(msg_buf, val, 99 - strlen(msg_buf));
   error(msg_buf);
}

/*
 * env_int - get the value of an integer valued envirionment variable.
 */
env_int(name, variable, non_neg)
char *name;
word *variable;
int non_neg;
{
   char *value;
   char *s;
   register word n = 0;
   register int d;
   int sign = 1;
   extern char *getenv();

   if ((value = getenv(name)) == NULL || *value == '\0')
      return;

   s = value;
   if (*s == '-') {
      if (non_neg)
         env_err("environment variable out of range", name, value);
      sign = -1;
      ++s;
      }
   else if (*s == '+')
      ++s;
   while (isdigit(*s)) {
      d = *s++ - '0';
      /*
       * See if 10 * n + d > MaxWord, but do it so there can be no overflow.
       */
      if (d > (MaxWord / 10 - n) * 10 + MaxWord % 10)
	 env_err("environment variable out of range", name, value);
      n = n * 10 + d;
      }
   if (*s != '\0')
      env_err("environment variable not numeric", name, value);
   *variable = sign * n;
   return;
}
#endif					/* NoEnvVars */

/*
 * Termination routines.
 */

/*
 * Produce run-time error 204 on floating point traps.
 */
#ifdef PYRAMID
fpetrap(code, subcode, sp)
int code, subcode, sp;
   {
   fatalerr(subcode == FPE_INTOVF_EXC ? -203 : -204, NULL);
   }
#else					/* PYRAMID */
fpetrap()
   {
   fatalerr(-204, NULL);
   }
#endif					/* PYRAMID */

/*
 * Produce run-time error 302 on segmentation faults.
 */
segvtrap()
   {
   fatalerr(-302, NULL);
   }

/*
 * error - print error message s; used only in startup code.
 */
error(s)
char *s;
   {
   fprintf(stderr, "error in startup code\n%s\n", s);
   fflush(stderr);
   if (dodump)
      abort();
   c_exit(ErrorExit);
   }

extern int findline();
extern char *findfile();

/*
 * syserr - print s as a system error.
 */
syserr(s)
char *s;
   {
   if (pfp != 0)
      fprintf(stderr, "System error at line %ld in %s\n%s\n",
         (long)findline(ipc.opnd), findfile(ipc.opnd), s);
   else
      fprintf(stderr, "System error in startup code\n%s\n", s);
   fflush(stderr);
   if (dodump)
      abort();
   c_exit(ErrorExit);
   }

/*
 * runerr - print message corresponding to error |n|;  if n > 0,
 *  print it as the offending value.
 */

runerr(n, v)

register int n;
struct descrip *v;
   {
   register struct errtab *p;

   if (n != 0) {
      k_errornumber = n;
      if (n > 0)
         k_errorvalue = *v;
      else
         k_errorvalue = nulldesc;
      }

   /*
    * Take absolute value of error number
    */
   n = (k_errornumber > 0 ? k_errornumber : -k_errornumber);

   k_errortext = "";
   for (p = errtab; p->errno > 0; p++)
      if (p->errno == n) {
         k_errortext = p->errmsg;
         break;
         }

   if (pfp != 0) {
      if (k_error == 0) {
         fprintf(stderr, "Run-time error %d\nFile %s; Line %ld\n",
            n, findfile(ipc.opnd), (long)findline(ipc.opnd));
         }
      else {
         k_error--;
         return;
         }
      }
   else
      fprintf(stderr, "Run-time error %d in startup code\n", n);
      fprintf(stderr, "%s\n", k_errortext);
   if (k_errornumber > 0) {
      fprintf(stderr, "offending value: ");
      outimage(stderr, &k_errorvalue, 0);
      putc('\n', stderr);
      }
   fflush(stderr);

#ifndef NoTraceBack
   if (pfp == 0) {		/* skip if start-up problem */
      if (dodump)
         abort();
      c_exit(ErrorExit);
      }

   {
   struct pf_marker *origpfp = pfp;
   struct descrip *arg;
   struct b_proc *cproc;
   inst cipc;

   fprintf(stderr, "Traceback:\n");

   /*
    * Chain back through the procedure frame markers, looking for the
    *  first one, while building a foward chain of pointers through
    *  the expression frame pointers.
    */

   for (pfp->pf_efp = NULL; pfp->pf_pfp != NULL; pfp = pfp->pf_pfp) {
      (pfp->pf_pfp)->pf_efp = (struct ef_marker *)pfp;
      }

   /* Now start from the base procedure frame marker, producing a listing
    *  of the procedure calls up through the last one.
    */

   while (pfp) {
      arg = &((struct descrip *)pfp)[-(pfp->pf_nargs) - 1];
      cproc = (struct b_proc *)BlkLoc(arg[0]);    
      /*
       * The ipc in the procedure frame points after the "invoke n".
       */
      cipc = pfp->pf_ipc;
      --cipc.opnd;
      --cipc.op;

      xtrace(cproc, pfp->pf_nargs, &arg[0], findline(cipc.opnd),
         findfile(cipc.opnd));

      /*
       * On the last call, show both the call and the offending expression.
       */
      if (pfp == origpfp) {
         ttrace();
         break;
         }
 
      pfp = (struct pf_marker *)(pfp->pf_efp);
      }
   }

#endif 					/* NoTraceBack */
   if (dodump)
      abort();
   c_exit(ErrorExit);
   }

#ifndef NoTraceBack
/*
 * ttrace - show offending expression.
 */
ttrace()
   {
   struct b_proc *bp;
   word nargs;

   fprintf(stderr, "   ");

   switch ((int)lastop) {

      case Op_Invoke:
         bp = (struct b_proc *)BlkLoc(*xargp);
         nargs = xnargs;
         if (xargp[0].dword == D_Proc)
            putstr(stderr, &(bp->pname));
         else
            outimage(stderr, xargp, 0);
         putc('(', stderr);
         while (nargs--) {
            outimage(stderr, ++xargp, 0);
            if (nargs)
               putc(',', stderr);
            }
         putc(')', stderr);
         break;

      case Op_Toby:
         putc('{', stderr);
         outimage(stderr, ++xargp, 0);
         fprintf(stderr, " to ");
         outimage(stderr, ++xargp, 0);
         fprintf(stderr, " by ");
         outimage(stderr, ++xargp, 0);
         putc('}', stderr);
         break;

      case Op_Subsc:
         putc('{', stderr);
         outimage(stderr, ++xargp, 0);
         putc('[', stderr);
         outimage(stderr, ++xargp, 0);
         putc(']', stderr);
         putc('}', stderr);
         break;

      case Op_Sect:
         putc('{', stderr);
         outimage(stderr, ++xargp, 0);
         putc('[', stderr);
         outimage(stderr, ++xargp, 0);
         putc(':', stderr);
         outimage(stderr, ++xargp, 0);
         putc(']', stderr);
         putc('}', stderr);
         break;

      case Op_Bscan:
         putc('{', stderr);
         outimage(stderr, xargp, 0);
         fputs(" ? ..}", stderr);
         break;

      case Op_Coact:
         putc('{', stderr);
         outimage(stderr, ++xargp, 0);
         fprintf(stderr, " @ ");
         outimage(stderr, ++xargp, 0);
         putc('}', stderr);
         break;

      case Op_Create:
         fprintf(stderr,"{create ..}");
         break;

      case Op_Field:
         putc('{', stderr);
         outimage(stderr, ++xargp, 0);
         fprintf(stderr, " . ");
         fprintf(stderr, "%s", StrLoc(fnames[IntVal(*++xargp)]));
         putc('}', stderr);
         break;


      case Op_Limit:
         fprintf(stderr, "limit counter: ");
         outimage(stderr, xargp, 0);
         break;
   
      default:
         bp = opblks[lastop];
         nargs = abs(bp->nparam);
         putc('{', stderr);
         if (lastop == Op_Bang || lastop == Op_Random)
            goto oneop;
         if (abs(bp->nparam) >= 2) {
            outimage(stderr, ++xargp, 0);
            putc(' ', stderr);
            putstr(stderr, &(bp->pname));
            putc(' ', stderr);
   	    }
         else
oneop:
            putstr(stderr, &(bp->pname));
         outimage(stderr, ++xargp, 0);
         putc('}', stderr);
      }
	 
   if (ipc.opnd != NULL)
      fprintf(stderr, " from line %d in %s", findline(ipc.opnd),
         findfile(ipc.opnd));
   putc('\n', stderr);
   fflush(stderr);
   }
/*
 * xtrace - procedure *bp is being called with nargs arguments, the first
 *  of which is at arg; produce a trace message.
 */
xtrace(bp, nargs, arg, pline, pfile)
struct b_proc *bp;
word nargs;
struct descrip *arg;
int pline;
char *pfile;
   {

   fprintf(stderr, "   ");
   if (bp == NULL)
      fprintf(stderr, "????");

   else {
         if (arg[0].dword == D_Proc)
            putstr(stderr, &(bp->pname));
         else
            outimage(stderr, arg, 0);
         arg++;
         putc('(', stderr);
         while (nargs--) {
            outimage(stderr, arg++, 0);
            if (nargs)
               putc(',', stderr);
            }
         putc(')', stderr);
      }
	 
   if (pline != 0)
      fprintf(stderr, " from line %d in %s", pline, pfile);
   putc('\n', stderr);
   fflush(stderr);
   }
#endif 					/* NoTraceBack */

/*
 * c_exit(i) - flush all buffers and exit with status i.
 */
c_exit(i)
int i;
{

   /*
    * Preform any special termination functions. Normally, it is defined
    *  to be empty.
    */
   IconTerm();

#ifdef TallyOpt
   {
   int j;

   if (tallyopt) {
      fprintf(stderr,"tallies: ");
      for (j=0; j<16; j++)
         fprintf(stderr," %ld", (long)tallybin[j]);
         fprintf(stderr,"\n");
         }
      }
#endif					/* TallyOpt */

   exit(i);
}

err()
{
   syserr("call to 'err'\n");
}

/*
 * Read a long string in shorter parts. (Some systems can't handle large reads.)
 */
word longread(fd,s,len)
int fd;
char *s;
long len;
{
   long tally, n;
 
   tally = 0;
   while (len > 0) {
      n = read(fd, s, (int)((len < MaxIn) ? len : MaxIn));
      if (n <= 0)
         return tally;
      tally += n;
      s += n;
      len -= n;
      }  
   return tally;
   }

fatalerr(n, v)
int n;
struct descrip *v;
   {
   k_error = 0;
   runerr(n, v);
   }

datainit()
   {

   /*
    * Initializations that cannot be performed statically (at least for
    * some compilers).					[[I?]]
    */

   k_errout.fd = stderr;
   k_errout.fname.dword = 7;
   StrLoc(k_errout.fname) = "&errout";

   k_input.fd = stdin;
   k_input.fname.dword = 6;
   StrLoc(k_input.fname) = "&input";

   k_output.fd = stdout;
   k_output.fname.dword = 7;
   StrLoc(k_output.fname) = "&output";

   IntVal(tvky_pos.kyval) = 1;
   StrLen(tvky_pos.kyname) = 4;
   StrLoc(tvky_pos.kyname) = "&pos";

   IntVal(tvky_ran.kyval) = 0;
   StrLen(tvky_ran.kyname) = 7;
   StrLoc(tvky_ran.kyname) = "&random";

   StrLen(tvky_sub.kyval) = 0;
   StrLoc(tvky_sub.kyval) = "";
   StrLen(tvky_sub.kyname) = 8;
   StrLoc(tvky_sub.kyname) = "&subject";

   IntVal(tvky_trc.kyval) = 0;
   StrLen(tvky_trc.kyname) = 6;
   StrLoc(tvky_trc.kyname) = "&trace";

   IntVal(tvky_err.kyval) = 0;
   StrLen(tvky_err.kyname) = 6;
   StrLoc(tvky_err.kyname) = "&error";

   StrLen(blank) = 1;
   StrLoc(blank) = " ";
   StrLen(emptystr) = 0;
   StrLoc(emptystr) = "";
   BlkLoc(errout) = (union block *) &k_errout;
   BlkLoc(input) = (union block *) &k_input;
   StrLen(lcase) = 26;
   StrLoc(lcase) = "abcdefghijklmnopqrstuvwxyz";
   StrLen(letr) = 1;
   StrLoc(letr) = "r";
   IntVal(nulldesc) = 0;
   k_errorvalue = nulldesc;
   IntVal(onedesc) = 1;
   StrLen(ucase) = 26;
   StrLoc(ucase) = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
   IntVal(zerodesc) = 0;

   maps2 = nulldesc;
   maps3 = nulldesc;
   }
