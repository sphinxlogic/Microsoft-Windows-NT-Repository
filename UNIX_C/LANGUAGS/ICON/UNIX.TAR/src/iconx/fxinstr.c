/*
 * The following code is operating-system dependent. It includes files
 *  needed on a system-specific basis.
 */

#if PORT
   /* something probably is needed */
#endif					/* PORT */

#if AMIGA
   /* something is needed if runstats() is used */
#endif					/* AMIGA */

#if ATARI_ST
   /* something is needed if runstats() is used */
#endif					/* ATARI_ST */

#if MACINTOSH
#if MPW
#include <types.h>
#include SysTime
#include <OSUtils.h>
#include <Events.h>
#endif					/* MPW */
#endif					/* MACINTOSH */

#if UNIX || MSDOS
#include <sys/types.h>
#include <sys/times.h>
#endif					/* UNIX || MSDOS */

#if VM || MVS
#endif					/* VM || MVS */

#if VMS
#include <types.h>
struct tms {
    time_t    tms_utime;	/* user time */
    time_t    tms_stime;	/* system time */
    time_t    tms_cutime;	/* user time, children */
    time_t    tms_cstime;	/* system time, children */
};
#endif					/* VMS */

/*
 * End of operating-system specific code.
 */

/*
 * runstats - produce a string of run-time statistics.
 *  Note:  this is a relic of an earlier version of Icon; it
 *  is being kept in anticipation of bringing it up to date
 *  or replacing it with something similar.  It does not
 *  work properly with Version 6.
 */
FncDcl(runstats,0)
   {
   extern char *alcstr();
   char fmt[500],*p,*q;
   int i;
   struct tms tp;
   long time(), clock, runtim;
   times(&tp);

/*
 * The following code is operating-system dependent. It gets the elapsed
 * run time.
 */

#if PORT
   /* something probably is needed */
#endif					/* PORT */

#if AMIGA
   /* something is needed if runstats() is used */
#endif					/* AMIGA */

#if ATARI_ST
   /* something is needed if runstats() is used */
#endif					/* ATARI_ST */

#if MACINTOSH
#if MPW
   runtim = 1000 * ((extended)(TickCount() - starttime) / (extended)Hz);
#endif					/* MPW */
#endif					/* MACINTOSH */

#if MSDOS
   runtim = time(NULL) - starttime;
#endif					/* MSDOS */

#if UNIX || VMS
   runtim = 1000 * ((tp.tms_utime - starttime) / (double)Hz);
#endif					/* UNIX || VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

#define NValues1  47
   for ((i = 1,p=fmt); i <= NValues1; i++) {
   	q = "%s\t%d\n";
         while (*p++ = *q++);
         --p;
         }

   if (strreq(3000) == Error)  /* just a guess */
      RunErr(0, NULL);
   sprintf(strfree,fmt,
         "Opcodes executed/ex",ex_n_opcodes,
         "Total time/ex",runtim,
         "Invocations/ex",ex_n_invoke,
         "Procedure invocations/ex",ex_n_ipinvoke,
         "Functions invocations/ex",ex_n_bpinvoke,
         "Argument list adjustments/ex",ex_n_argadjust,
         "Operator invocations/ex",ex_n_opinvoke,
         "Goal-directed invocations/ex",ex_n_mdge,
         "String invocations/ex",ex_n_stinvoke,
         "Keyword references/ex",ex_n_keywd,
         "Local variable references/ex",ex_n_locref,
         "Global variable references/ex",ex_n_globref,
         "Static variable references/ex",ex_n_statref,

         "Expression suspensions/gde",gde_n_esusp,
         "Esusp bytes copied/gde",gde_bc_esusp,
         "Procedure suspensions/gde",gde_n_psusp,
         "Psusp bytes copied/gde",gde_bc_psusp,
         "Operator & function suspensions/gde",gde_n_susp,
         "Susp bytes copied/gde",gde_bc_susp,

         "Expression failures/gde",gde_n_efail,
         "Procedure failures/gde",gde_n_pfail,
         "Operator & Function failures/gde",gde_n_fail,
         "Evaluation resumptions/gde",gde_n_resume,
         "Expression returns/gde",gde_n_eret,
         "Procedure returns/gde",gde_n_pret,

   	 "Block Region Size/gc",blkend-blkbase,
         "Block Region Usage/gc",blkfree-blkbase,
         "String Region Size/gc",strend-strbase,
         "String Region Usage/gc",strfree-strbase,

         "Garbage collections/gc",gc_n_total,
         "String-triggered collections/gc",gc_n_string,
         "Block-triggered collections/gc",gc_n_blk,
         "Co-expression-triggered collections/gc",gc_n_coexpr,

         "Total garbage collection time/gc",gc_t_total,
         "Last garbage collection time/gc",gc_t_last,

         "Dereferences/ev",ev_n_deref,
         "No-op dereferences/ev",ev_n_redunderef,
         "Substring trapped-variable dereferences/ev",ev_n_tsderef,
         "Table element trapped-variable dereferences/ev",ev_n_ttderef,

         "Cvint operations/cv",cv_n_int,
         "No-op cvint operations/cv",cv_n_rint,
         "Cvreal operations/cv",cv_n_real,
         "No-op cvreal operations/cv",cv_n_rreal,
         "Cvnum operations/cv",cv_n_num,
         "No-op cvnum operations/cv",cv_n_rnum,
         "Cvstr operations/cv",cv_n_str,
         "No-op cvstr operations/cv",cv_n_rstr,
         "Cvcset operations/cv",cv_n_cset,
         "No-op cvcset operations/cv",cv_n_rcset,
         0,0,0,0);

#define NValues2  15
   for ((i = 1,p=fmt); i <= NValues2; i++) {
   	q = "%s\t%d\n";
         while (*p++ = *q++);
         --p;
         }

   sprintf(strfree+strlen(strfree),fmt,
         "Block region allocations/al",al_n_total,
         "Total block space allocated/al",al_bc_btotal,
         "String allocations/al",al_n_str,
         "Total string space allocated/al",al_bc_stotal,
         "Substring trapped-varibale allocations/al",al_n_subs,
         "Cset allocations/al",al_n_cset,
         "Real block allocations/al",al_n_real,
         "List block allocations/al",al_n_list,
         "List-element block allocations/al",al_n_lstb,
         "Table block allocations/al",al_n_table,
         "Table-element block allocations/al",al_n_telem,
         "Table-element trapped-variable allocations/al",al_n_tvtbl,
         "File block allocations/al",al_n_file,
         "Refresh block allocations/al",al_n_eblk,
         "Co-expression block allocations/al",al_n_estk,

         0,0,0,0 /* who can count? */
         );
   StrLoc(Arg0) = alcstr(strfree,(word)strlen(strfree));
   StrLen(Arg0) = strlen(StrLoc(Arg0));
   Return;
   }
