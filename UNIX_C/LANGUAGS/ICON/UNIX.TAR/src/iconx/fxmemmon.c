/*
 * mmpause(s) - pause MemMon displaying string s.
 */

FncDcl(mmpause,1)
   {
   char sbuf[MaxCvtLen];
   int t;

   if ((t = defstr(&Arg1,sbuf,&emptystr)) == Error) 
      RunErr(0, NULL);
   if (StrLen(Arg1) == 0)
      MMPause("programmed pause");
   else {
      /*
       * Make sure Arg1 is a C-style string.
       */
      if (t == NoCvt)
    	 qtos(&Arg1, sbuf);
      MMPause(StrLoc(Arg1));
      }
   Arg0 = nulldesc;
   Return;
   }

/*
 * mmshow(x,s) - alter MemMon display of x depending on s.
 */

FncDcl(mmshow,2)
   {
   char sbuf[MaxCvtLen];

   /*
    * Default Arg2 to the empty string and make sure it is a C-style string.
    */
   switch (defstr(&Arg2,sbuf,&emptystr)) {

      case Cvt:   /* Already converted to a C-style string */
         break;

      case Defaulted:
      case NoCvt:
 	 qtos(&Arg2, sbuf);
	 break;

      Error:
         RunErr(0, NULL);
      }

   MMShow(&Arg1,StrLoc(Arg2));
   Arg0 = nulldesc;
   Return;
   }
