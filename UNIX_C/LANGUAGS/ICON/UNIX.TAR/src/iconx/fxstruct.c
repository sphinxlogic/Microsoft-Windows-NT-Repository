/*
 * keys(t) - generate successive keys (entry values) from table t.
 */

FncDcl(keys,1)
   {
   register int i;
   register union block *bp, *ep;
   register struct descrip *dp;
   struct descrip tbl;

   if (Qual(Arg1) || Type(Arg1) != T_Table) 
      RunErr(120, &Arg1);
   for (i = 0; i < TSlots; i++) {
      bp = BlkLoc(Arg1);
      for (tbl = bp->table.buckets[i]; tbl.dword == D_Telem;
           tbl = BlkLoc(tbl)->telem.clink) {
         ep = BlkLoc(tbl);
         dp = &ep->telem.tref;
         Arg0.dword = D_Var + ((int *)dp - (int *)bp);
         VarLoc(Arg0) = dp;
         Suspend;
         bp = BlkLoc(Arg1);   /* bp is untended, must reset */
         }
      }
   Fail;
   }
