#if MICROSOFT || TURBO
#include <sys/types.h>
#include <sys/stat.h>
#endif					/* MICROSOFT || TURBO */

/*
 * getpid() - return pid of process via UNIX getpid call
 */

FncDcl(getpid,0)
   {
   MkIntT((long)getpid(),&Arg0);
   }

/*
 * fsize(arg) - get file size of arg (either pathname of file descriptor)
 */

FncDcl(fsize,1)
   {
    register int i;
    struct descrip arg;
    char sbuf[MaxCvtLen];

#if MICROSOFT || TURBO
    struct stat file_info;    /* structure defined in sys/stats.h */
    extern int stat(), fstat(); /* get file information */
#endif					/* MICROSOFT || TURBO */

    long file_size;
    extern char *alcstr();

    arg = Arg1;

   /*
    *  If arg is a file desciptor than we use fstat to get file size.
    *  Default arg to &input (ie if arg is null).
    */

    if ChkNull(arg) arg = input;  /* set to &input descriptor */

    if (arg.dword == D_File)   /* argument is a file */
     {
       i = (int) fileno(BlkLoc(arg)->file.fd);  /* UNIX file number */

       if (isatty(i)) Fail;     /* Fail if it is a terminal */

#if MICROSOFT || TURBO
       if (fstat(i,&file_info))
           Fail;                   /* failed to get file information */

       file_size = (long)file_info.st_size;
#else					/* MICROSOFT || TURBO */
       { long int pos;
	 long int tell(), lseek();
	 pos = tell(i);
	 file_size = lseek(i,0l,2);    /* Seek to end of file.. */
	 lseek(i,pos,1);
	 if (file_size == -1L) Fail;
       }
#endif					/* MICROSOFT || TURBO */

      }
    else
   /*
    *  Otherwise Arg1 should give the name of the file.  We need a C
    *  string, either as a by product of conversion or if it is already a
    *  string then explicitly.
    */
      {
        switch (cvstr(&Arg1, sbuf)) {

           case Cvt:
              break;    /* converted and sbuf holds C string */

           case NoCvt:
              qtos(&Arg1, sbuf);  /* string so make C string */
              break;

           default:
              RunErr(109, &Arg1);  /* file or string expected */
           }
        /*
         * Get file information with stat
         */

#if MICROSOFT || TURBO
         if (stat(StrLoc(Arg1),&file_info))
           Fail;                   /* failed to get file information */

         else   file_size = (long)file_info.st_size;
#else					/* MICROSOFT || TURBO */
       { int i;
	 i = open(StrLoc(Arg1),0);
	 if (i < 0) Fail;
	 file_size = lseek(i,0l,2);    /* Seek to end of file.. */
	 close(i);
	 if (file_size == -1L)
            Fail;
       }
#endif					/* MICROSOFT || TURBO */

       } /* end of section handling path names

   /*
    *  Finally we return the size of the file
    */

   MkIntT(file_size, &Arg0);
    Return;
}

/*
 * readc(f) - read a character from file f
 */

FncDcl(readc,1)
   {
   register int slen;
   int status;
   char sbuf[MaxReadStr];
   FILE *f;
   extern char *alcstr();

   if (deffile(&Arg1, &input) == Error) 
      RunErr(0, NULL);
   f = BlkLoc(Arg1)->file.fd;
   status = BlkLoc(Arg1)->file.status;
   if ((status & Fs_Read) == 0) 
      RunErr(212, &Arg1);

   if ((sbuf[0] = getc(f)) == EOF)
      Fail;
   if (strreq(1) == Error) 
      RunErr(0, NULL);
   StrLen(Arg0) = 1;
   StrLoc(Arg0) = alcstr(sbuf,1);
   Return;
   }

/*
 * tmpnam() - return a temporary file name.
 */

FncDcl(tmpnam,0)
   {
   register char *p;
   register int len;
   extern char *tmpnam();
   extern char *alcstr();

   p = tmpnam();			/* get temp file name */
   len = strlen(p);
   if (strreq(len) == Error) 
      RunErr(0, NULL);
   StrLoc(Arg0) = alcstr(p, len);
   StrLen(Arg0) = len;
   Return;
   }
