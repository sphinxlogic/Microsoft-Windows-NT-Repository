/*
 * File: ovalue.c
 *  Contents: nonnull, null, value
 */

#include "../h/rt.h"

/*
 * \x - test x for nonnull value.
 */

OpDcl(nonnull,1,"\\")
   {

   /*
    * If Arg1 is not null, it is returned, otherwise, the function fails.
    *  Because the pre-dereference value of Arg1 is the return value (if
    *  any), Arg1 is copied into Arg0.
    */
   Arg0 = Arg1;
   if (DeRef(Arg1) == Error) 
      RunErr(0, NULL);
   if (ChkNull(Arg1))
      Fail;
   Return;
   }

/*
 * /x - test x for null value.
 */

OpDcl(null,1,"/")
   {

   /*
    * If Arg1 is null, it is returned, otherwise, the function fails.
    *  Because the pre-dereference value of Arg1 is the return value (if
    *  any), Arg1 is copied into Arg0.
    */
   Arg0 = Arg1;
   if (DeRef(Arg1) == Error) 
      RunErr(0, NULL);
   if (!ChkNull(Arg1))
      Fail;
   Return;
   }

/*
 * .x - produce value of x.
 */

OpDcl(value,1,".")
   {

   if (DeRef(Arg1) == Error) 
      RunErr(0, NULL);
   Arg0 = Arg1;
   Return;
   }
