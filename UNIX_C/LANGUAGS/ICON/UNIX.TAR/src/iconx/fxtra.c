/*
 * File: fxtra.c
 *  Contents: additional functions to extend the standard Icon repertoire.
 *  This files contains several collections of functions:
 *
 *	System-interface functions (SysFncs)
 *	Mathematical functions (MathFncs)
 *	Functions specific to MS-DOS (DosFncs)
 *	Memory monitor functions (MMFncs)
 *	Instrumentation functions (InstrFncs)
 *	Internals functions (IntrnlFncs)
 *	"Iscope" functions (ScopeFncs)
 *
 *  These collections are under the control of conditional compilation
 *  as indicated by the symbols in parentheses. To enable a set of functions,
 *  define the corresponding symbol in ../h/config.h.  The functions themselves
 *  are in separate files, included according to the defined symbols.
 *
 *  CAVEAT:  Most of these functions have not yet been tested.  In
 *           addition, there are operating-system dependencies that
 *           are not noted.
 *
 *  The following persons contributed functions: Bob Alexander,Ralph Griswold,
 *  Andy Heron, Bill Mitchell, Gregg Townsend, Steve Wampler, and Cheyenne
 *  Wills.
 */

#include "../h/rt.h"
#include "gc.h"

#ifdef SysFncs
#include "fxsys.c"
#endif					/* SysFncs */

#ifdef MathFncs
#include "fxmath.c"
#endif					/* MathFncs */

#ifdef DosFncs
#include "fxmsdos.c"
#endif					/* DosFncs */

#ifdef MMFncs
#include "fxmemmon.c"
#endif					/* MMFncs */

#ifdef InstrFncs
#include "fxinstr.c"
#endif					/* InstrFncs */

#ifdef IntrnlFncs
#include "fxintrnl.c"
#endif					/* IntrnlFncs */

#ifdef ScopeFncs
#include "fxiscope.c"
#endif					/* ScopeFncs */

char fx_junk;				/* prevent empty module */
