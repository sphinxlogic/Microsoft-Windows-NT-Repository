/*
 *  File: rmemmon.c
 *
 *  This file contains memory monitoring code and is compiled only if
 *  MemMon is defined.
 *
 *  The first section of this file contains device-independent code.  When
 *  MemMon is undefined, gc.h defines these entrypoints as null macros.
 *
 *  Subsequent sections contain device drivers, called only from the
 *  device-independent code.  Just one of these is built, with selection
 *  controlled by the value of MemMon.
 */

#include "../h/rt.h"
#include "gc.h"

#ifdef MemMon

#include <sgtty.h>
#include <varargs.h>

/*
 * Color list, indexed by block type or defined symbol.
 *  Every entry has 3 bits each (left to right) for red, green, blue.
 *  White is used for types not expected in the block region.
 */

static int clist[] = {
		/* these entries also have "marked" and "unmarked" variants */
    0777,	/*  0. T_Null     white    null value  */
    0777,	/*  1. T_Integer  white    integer  */
    0777,	/*  2. not used   white    */
    0007,	/*  3. T_Real     blue     real number  */
    0540,	/*  4. T_Cset     brown    cset  */
    0405,	/*  5. T_File     purple   file block  */
    0777,	/*  6. T_Proc     white    procedure block  */
    0060,	/*  7. T_List     green    list header block  */
    0770,	/*  8. T_Table    yellow   table header block  */
    0077,	/*  9. T_Record   cyan     record block  */
    0773,	/* 10. T_Telem    lt yel   table element block  */
    0272,	/* 11. T_Lelem    lt grn   list element block  */
    0756,	/* 12. T_Tvsubs   pink     substring trapped variable  */
    0777,	/* 13. T_Tvkywd   white    keyword trapped variable  */
    0751,	/* 14. T_Tvtbl    orange   table elem trapped variable  */
    0600,	/* 15. T_Set      red      set header block  */
    0700,	/* 16. T_Selem    brt red  set element block  */
    0004,	/* 17. T_Refresh  navy     refresh block  */
    0433,	/* 18. T_Coexpr   mauve     co-expression block */
#define UNcolr 19   /* UNcolr     white    unknown type  */
    0777,	
#define STcolr 20   /* STcolr     ivory    unbroken string  */
    0776,
#define STBcolr 21  /* STBcolr    blue     string separator  */
    0344,
#define MColors 22  /* number of markable colors (all those above) */

		/* these entries remain constant always */
#define Black 22    /* Black      black    */
   0000,
#define DkGray 23   /* DkGray     dk gray  */
   0111,
#define Gray 24     /* Gray       gray     */
   0222,
#define LtGray 25   /* LtGray     lt gray  */
   0444,
#define White 26    /* White      white    */
   0777,
#define Aqua 27	    /* Aqua       aqua     */
   0475,
#define HLcolr 28   /* HLcolr     blink    highlighting entry */
   0777,
   };
#define TColors 29  /* total number of colors */


#define BGcolr Black		/* background color */
#define RGNcolr STcolr		/* region sizes */
#define AVcolr Gray		/* available space */
#define BKBcolr Black		/* block border */
#define MKcolr DkGray		/* marked block  */
#define UMcolr Black		/* unmarked block  */
#define Alien LtGray		/* alien block in static region */

#define PAUSEcolr Aqua		/* mmpause() call */
#define GCBcolr T_Tvtbl		/* garbage collection due to blk region full */
#define GCScolr STcolr		/* ... string region */
#define GCCcolr T_Coexpr	/* ... static region, presumably coexpr */
#define GCUcolr T_Selem		/* ... collect() call */
#define GARcolr T_Telem		/* screen contents are garbage */
#define VALcolr T_Record	/* screen contents are valid data */
#define GOcolr T_Lelem		/* ready to go after garb coll */


/*
 * Color map buffer.  The first Tcolors entries are identical to clist, above;
 *  these are followed by 2*Mcolors entries representing the unmarked and
 *  marked versions of the markable colors.
 */

#define MapSize (TColors+2*MColors)
static int cbuff [MapSize];

#define Marked TColors
#define Unmarked (TColors+MColors)




/*
 * Miscellaney.
 */

static char *mmdev;		/* name of monitoring device, if used */
static int scale;		/* current scaling;  may decrease  */
static char *membase;		/* base of the region we will display */
static int nstatic, nstring, nblock, nexplicit;	/* collect counts by region */

#define TextLength 98		/* prompt/legend line size */
#define TextLines 2		/* number of such lines */

#if MemMon == 2
#define Gran 2			/* granularity of display (in bytes) */
#define MaxScale 20		/* maximum vertical scaling */
#else					/* MemMon == 2 */
#define Gran 4
#define MaxScale 16
#endif					/* MemMon == 2 */

#define PaintMem(addr,size,color,b)  \
    gdpaint(((addr)-membase)/Gran,(size)/Gran,color,b)

/*
 * MMInit() - initialization.
 */

MMInit()
   {
   int i;

#ifndef NoEnvVars
   extern char *getenv();
#endif					/* NoEnvVars */

   char *p;

#ifndef NoEnvVars
   if (!(p = getenv("MEMMON")))	/* check if monitoring wanted */
#endif					/* NoEnvVars */

      return;
   membase = statbase;		/* set base for memory display */
   for (i=0; i<TColors; i++)	/* init base portion of color buffer */
      cbuff[i] = clist[i];
   gdinit(p);			/* first open files, etc. */
   mmdev = p;			/* now set flag we're open for business */
   refresh();			/* draw first screenful showing curr status */
   gdflush();			/* force it out */
   }

/*
 * MMAlc(n,t) - show allocation of n block bytes of type t at blkfree.
 */

MMAlc(n,t)
int n, t;
   {
   if (!mmdev)
      return;
   PaintMem(blkfree,n,Unmarked+t,BKBcolr);
   }

/*
 * MMStr(n) - show allocation of n string bytes at strfree.
 *  Each pixel on the display represents multiple bytes.  A pixel in which any
 *  string ends will be STBcolr;  pixels corresponding to nonterminal
 *  characters of one string will be STcolr.  This method makes long strings
 *  individually distinguishable from each other and from runs of short
 *  strings, and allows continuous output with no backtracking as the string
 *  space is allocated.
 */

MMStr(slen)
int slen;
   {
   int s, e;

   if (!mmdev)
      return;
   s = (strfree-membase+Gran-1) / Gran;	/* start (first pixel wholly owned) */
   e = (strfree-membase+slen-1) / Gran;	/* end pixel */
   if (e < s)				/* if no new pixels, return */
      return;
   gdpaint(s,e-s+1,Unmarked+STcolr,Unmarked+STBcolr);
   }

/*
 * MMPaint(addr,length,type) - paint screen the unmarked color of type t.
 * If t == 0, paint free space color.  If t == 1, paint as alien malloc block.
 * If t < 0, paint as a marked blk of type (-t).
 */

MMPaint(addr,length,type)
char *addr;
int length, type;
   {
   if (!mmdev)
      return;
   if (type == 0)
      type = AVcolr;
   else if (type == 1)
      type = Alien;
   else if (type < 0)
      type = Marked - type;
   else
      type += Unmarked;
   PaintMem(addr,length,type,-1);
   }

/*
 * MMShow(d,s) - redraw block indicated by descriptor d according to flags
 *  in s.
 */

MMShow(d,s)
struct descrip *d;
char *s;
   {
   int color;
   union block *b;

   if (!mmdev)
      return;
   switch (*s)  {
      case 'b':  color = Black;  break;
      case 'g':  color = Gray;   break;
      case 'h':  color = HLcolr; break;
      case 'r':  color = Unmarked + (Qual(*d) ? STcolr : Type(*d));  break;
      case 'w':  color = White;  break;
      default:   color = HLcolr; break;
      }
   if (Qual(*d))
      PaintMem(StrLoc(*d), StrLen(*d), color, STBcolr);
   else if (Pointer(*d))  {
      b = BlkLoc(*d);
      PaintMem((char *) b, BlkSize(b), color, BKBcolr);
      }
   /* else ignore */
   }

/*
 * MMPause(msg) - pause with a message.
 * (once EOF or "g" is the reply, there are no further pauses.)
 */

MMPause(msg)
char *msg;
   {
   static r = 0;

   if (r != EOF && r != 'g' && r != 'G')
      r = gdpause(msg,PAUSEcolr);
   }

/*
 * MMBGC() - begin garbage collection.
 */

MMBGC()
   {
   char *s;
   int c;

   if (!mmdev)
      return;
   if (statneed)
      s="begin garbage collection -- need static space", c=GCCcolr, nstatic++;
   else if (strneed > strend - strfree)
      s="begin garbage collection -- need string space", c=GCScolr, nstring++;
   else if (blkneed > blkend - blkfree)
      s="begin garbage collection -- need block space", c=GCBcolr, nblock++;
   else
      s="begin garbage collection -- explicit call", c=GCUcolr, nexplicit++;
   gcwait(s,c);
   }

/*
 * MMMark(block,type) - mark indicated block during garbage collection.
 */

MMMark(block,type)
char *block;
int type;
   {
   if (mmdev)
      PaintMem(block,BlkSize(block),Marked+type,BKBcolr);
   }

/*
 * MMSMark - Mark String.
 */

MMSMark(saddr,slen)
char *saddr;
int slen;
   {
   int s, e;

   if (!mmdev)
      return;
   s = (saddr-membase+Gran-1) / Gran;	/* start (first pixel wholly owned) */
   e = (saddr-membase+slen-1) / Gran;	/* end pixel */
   if (e >= s)				/* if anything to paint... */
      gdpaint(s,e-s+1,Marked+STcolr,Marked+STBcolr);
   }

/*
 * MMEGC() - end garbage collection.
 */

MMEGC()
   {
   if (!mmdev)
      return;
   if (gcwait("marking done, garbage remains",GARcolr) != EOF)  {
      setmap(Unmarked,UMcolr);
      }
   while (gcwait("valid data before compaction",VALcolr) == '-')  {
      setmap(Marked,MKcolr);
      gcwait("marking done, garbage remains",GARcolr);
      setmap(Unmarked,UMcolr);
      }
   refresh();
   gcwait("end garbage collection",GOcolr);
   }

/*
 * MMTerm() - terminate memory monitoring.
 */

MMTerm()
   {
   if (!mmdev)
      return;
   gdtext("done",0,White,AVcolr);
   gdterm();
   }

/*
 * gcwait(msg,color) - pause with garbage collection message.
 * After one EOF or 'G', never pauses again.  Returns whatever gdpause returns.
 */

static gcwait(msg,color)
char *msg;
int color;
   {
   static r = 0;

   if (r != EOF && r != 'g' && r != 'G')
      r = gdpause(msg,color);
   return r;
   }

/*
 * refresh() - redraw screen, initially or after garbage collection.
 */

static refresh()
   {
   char *p;
   int n;
   char sbuf[50];

   if (layout())  {					/* if layout changed, */
      gdflood(BGcolr);					/* clear screen */
      legend();						/* replace legend */
      }
   else
      PaintMem(blkbase,blkfree-blkbase,AVcolr,-1);
   sprintf(sbuf,"%d + %d + %d  (%d+%d+%d+%d)",
      strbase - statbase, blkbase - strbase, blkend - blkbase,
      nstatic, nstring, nblock, nexplicit);
   gdtext(sbuf,TextLength-strlen(sbuf),RGNcolr,BGcolr);	/* sizes & gc counts */
   PaintMem(strfree,strend-strfree,AVcolr,-1);		/* avail string space */
   PaintMem(blkfree,blkend-blkfree,AVcolr,-1);		/* avail blk space*/
   setmap(Marked,MKcolr);				/* set norml colr map */
   show_alloc();	/* show malloc blks (stack, coexprs, aliens, free) */
   PaintMem(strbase,strfree-strbase,Unmarked+STcolr,BKBcolr);	/* string spc */
   for (p = blkbase; p < blkfree; p += n)
      PaintMem(p,n=BlkSize(p),Unmarked+BlkType(p),BKBcolr);	/* blocks */
   }

/*
 * layout - determine screen layout.  Return NZ iff different from previous.
 */

static layout()
   {
   int npixels;
   static int oldscale;

   npixels = (blkend - membase) / Gran + 1;
   if (!scale)
      scale = MaxScale;
   while (scale > 1 && npixels > gdsize(scale))
      --scale;
   if (scale != oldscale)  {
      gdscale(scale);
      oldscale = scale;
      return 1;
      }
   else
      return 0;
   }

/*
 * legend() - display legend
 */

static legend()
   {
   static struct { int b, f; char *s; } *p, a[] = {
      {T_Coexpr,  White,   "coexpr"},
      {Alien,     White,   "alien"},
      {Black,     Black,   " "},
      {STcolr,    Black,   "string"},
      {Black,     Black,   " "},
      {T_Tvsubs,  Black,   "subs"},
      {T_File,    White,   "file"},
      {T_Refresh, White,   "refresh"},
      {T_Real,    White,   "real"},
      {T_Record,  Black,   "record"},
      {T_Set,     White,   "set"},
      {T_Selem,   White,   "selem"},
      {T_List,    Black,   "list"},
      {T_Lelem,   Black,   "lelem"},
      {T_Table,   Black,   "table"},
      {T_Telem,   Black,   "telem"},
      {T_Tvtbl,   Black,   "tvtbl"},
      {T_Cset,    Black,   "cset"},
      {0,         0,       0}};
   int addr;

   addr = TextLength;
   for (p = a; p->s; p++)  {
      gdtext(p->s,addr,p->f,p->b);
      addr += strlen(p->s) + 1;
      }
   }

/*
 * setmap(m,c) - set {Marked | Unmarked} colors to c, and others back to
 *  normal.
 */

static setmap(m,c)
   int m, c;
   {
   int i, n;
   
   n = m ^ Marked ^ Unmarked;		/* n is opposite of m (Marked or Un) */
   for (i = 0; i < MColors; i++)  {	/* alter map buffer */
      cbuff[m+i] = clist[c];
      cbuff[n+i] = clist[i];
      }
   gdmap(cbuff,MapSize);		/* load map into device */
   }
   

/*
 * litio(fd) - set literal i/o mode on tty file
 */

static litio(fd)
int fd;
{
   struct sgttyb ttyb;			/* for setting tty attributes */
   static ldisc = NTTYDISC;
   static lbits = LLITOUT;

   if (ioctl(fd, TIOCSETD, &ldisc))
      error("can't select new tty driver");
   if (ioctl(fd, TIOCGETP, &ttyb))
      error("can't get sgtty block");
   if (ioctl(fd, TIOCLBIS, &lbits))
      error("can't set LLITOUT");
   ttyb.sg_flags &= ~(RAW+ECHO);
   ttyb.sg_flags |= CRMOD;
   if (ttyb.sg_ispeed < B1200)			/* if speed obviously bogus, */
      ttyb.sg_ispeed = ttyb.sg_ospeed = B9600;	/* try 9600 as a better guess */
   if (ioctl(fd, TIOCSETN, &ttyb))
      error("can't set tty attributes");
}

#if MemMon == 1
#define AED
AED /*
AED  *  graphics driver for AED 1024 (MemMon == 1).
AED  *
AED  *  These functions provide a ONE-DIMENSIONAL interface to the AED.
AED  */
AED 
AED 

#define Height 768			/* screen height */
#define Width 1024			/* screen width */
#define PromptArea 50			/* pixels to reserve for prompting */
#define PromptSize 40			/* size of prompt block proper */
#define MaxColors 256			/* maximum number of distinct colors */
#define EndRun() if(runaddr)putc(runaddr=0,ofile);  /* end a run of pixels */

AED static FILE *ifile = 0;		/* AED input file */
AED static FILE *ofile = 0;		/* AED output file */
AED static int yscale = 1;		/* vertical scaling factor */
AED static int npixels = Height * Width - PromptArea; /* scaled screen size */
AED static runaddr = 0;			/* curr addr if pixel run in progress */
AED static int bgcolor;			/* current background color */
AED 
AED /*
AED  * gdinit(filename) - initialize for graphics output.
AED  */
AED 
AED static gdinit(fname)
AED char *fname;
AED    {
AED    FILE *newf;
AED    int ofd;
AED    struct sgttyb ttyb;
AED    static int ldisc = NTTYDISC;
AED    static int lbits = LLITOUT;
AED    static char obuf[BUFSIZ];
AED 
AED    if ((newf = fopen(fname,"w")) == NULL)
AED       error("can't open MEMMON file");
AED    if (isatty(ofd = fileno(newf)))  {
AED       litio(ofd);
AED       if (ifile = fopen(fname,"r")) {
AED          setbuf(ifile,NULL);
AED          }
AED       else {
AED          fprintf(stderr, "can't read MEMMON file;  will not pause\n");
AED          fflush(stderr);
AED          }
AED       }
AED    ofile = newf;
AED    setbuf(ofile,obuf);
AED    fputs("\033SEN18D88",ofile);	/* set encoding mode to binary */
AED    aedout("gii",0,767);		/* set normal window boundaries */
AED    aedout("4bbbbbb",HLcolr,0,0,0,20,20);	/* make HLcolr blink */
AED }
AED 
AED /*
AED  * gdmap(array,n) - set color map.  Each entry of array (of size n) has
AED  *  three bits each of red, green, blue values in least signifigant bits.
AED  *  The constants in the table below were determined empirically.
AED  */
AED 
AED static gdmap(a,n)
AED int a[], n;
AED    {
AED    unsigned char buf[3*MaxColors+4];
AED    unsigned char *p;
AED    static unsigned char rmap[] = { 0, 20, 45, 70, 100, 140, 190, 255};
AED    static unsigned char gmap[] = { 0, 40, 60, 80, 110, 150, 195, 255};
AED    static unsigned char bmap[] = { 0, 40, 60, 80, 110, 150, 195, 255};
AED 
AED    EndRun();
AED    p = buf;
AED    *p++ = 'K';
AED    *p++ = 0;
AED    *p++ = n;
AED    while (n--)  {
AED       *p++ = rmap [ *a >> 6 ];
AED       *p++ = gmap [ (*a >> 3) & 7 ];
AED       *p++ = bmap [ *a++ & 7 ];
AED       }
AED    fwrite(buf,1,p-buf,ofile);
AED    }
AED 
AED /*
AED  * gdflood(c) - fill screen with color c.
AED  */
AED 
AED static gdflood(c)
AED int c;
AED    {
AED    EndRun();
AED    aedout("[b",c);			/* set background color */
AED    aedout("~");			/* erase screen (kills scaling) */
AED    aedout("Ebb",1,yscale);		/* reset scaling */
AED    bgcolor = c;			/* save background color */
AED    }
AED 
AED /*
AED  * gdscale(n) - set vertical scaling factor.
AED  */
AED 
AED static gdscale(n)
AED int n;
AED    {
AED    EndRun();
AED    if (n > MaxScale)
AED       n = MaxScale;
AED    yscale = n;
AED    npixels = (Height / n) * Width - PromptArea;
AED    aedout("Ebb",1,n);		/* set zoom for y scaling (only!) */
AED    }
AED 
AED /*
AED  * gdsize(n) - return size of display with scaling factor n;
AED  */
AED 
AED static gdsize(n)
AED int n;
AED    {
AED    if (n > MaxScale)
AED       n = MaxScale;
AED    return (Height / n) * Width - PromptArea;
AED    }
AED 
AED /*
AED  * gdpaint(start,n,color,b) - paint n pixels in given color.
AED  *  If b >= 0, the last pixel is to be that color instead (for a border)
AED  */
AED 
AED static gdpaint(s,n,c,b)
AED int s, n, c, b;
AED    {
AED    if (s < 0 || s >= npixels || n <= 0)
AED       return;
AED    if (s + n > npixels)
AED       n = npixels - s;
AED    if (runaddr && runaddr != s)
AED       putc(runaddr=0,ofile);
AED    if (!runaddr)  {
AED       aedout("Qx", s % Width, Height - 1 - s / Width);
AED       aedout("s");
AED       }
AED    runaddr = s + n;
AED    if (b >= 0)
AED       n--;
AED    while (n > 254)  {
AED       putc(254,ofile);
AED       putc(c,ofile);
AED       n -= 254;
AED       }
AED    if (n > 0)  {
AED       putc(n,ofile);
AED       putc(c,ofile);
AED       }
AED    if (b >= 0)  {
AED       putc(1,ofile);
AED       putc(b,ofile);
AED       }
AED    }
AED 
AED /*
AED  * gdtext(string,addr,fgcolr,bgcolr) - don't output text.
AED  */
AED 
AED static gdtext(s,a,f,b)
AED char *s;
AED int a, f, b;
AED    {
AED    }
AED 
AED /*
AED  * gdflush() - flush output.
AED  */
AED 
AED static gdflush()
AED    {
AED    fflush(ofile);
AED    }
AED 
AED /*
AED  * gdpause(msg,color) - pause for ack, showing color to hint at reason.
AED  * (Message is ignored here because we can't write text to the screen.)
AED  * Return last character before '\n', 0 if none, or EOF if not interactive.
AED  */
AED 
AED static gdpause(msg,color)
AED char *msg;
AED int color;
AED    {
AED    int c1, c2, pline;
AED 
AED    if (!ifile)
AED       return EOF;
AED    EndRun();
AED    fputs("\r\007\033",ofile);		/* ring bell */
AED    pline = Height - Height / yscale;
AED    aedout("Qx",Width-PromptSize,pline);
AED    aedout("sbbb",PromptSize,color,0);
AED    fflush(ofile);
AED    c1 = 0;
AED    while ((c2 = getc(ifile)) != '\n')
AED       if (c2 == EOF)  {
AED          ifile = 0;
AED          c1 = EOF;
AED          break;
AED          }
AED       else
AED          c1 = c2;
AED    aedout("Qx",Width-PromptSize,pline);
AED    aedout("sbbb",PromptSize,bgcolor,0);
AED    return c1;
AED    }
AED 
AED /*
AED  * gdterm() - terminate graphics
AED  */
AED 
AED static gdterm()
AED    {
AED    if (!ofile)
AED       return;			/* if no file, just return */
AED    EndRun();
AED    aedout("Gs","3DNNN");		/* reset encoding */
AED    aedout("\r");			/* exit graphics mode */
AED    }
AED 
AED /*
AED  * aedout(s,args) - output command to the AED.
AED  *  s is a string specifying the command format a la printf.  The first
AED  *  character (or two chars if first is '+') are the AED command.
AED  *  Additional characters specify formats for outputting additional
AED  *  arguments (see below).
AED  */
AED 
AED /*VARARGS1*/
AED static aedout (s, va_alist)
AED char *s;
AED va_dcl
AED    {
AED    va_list ap;
AED    char c;
AED    unsigned int n, x, y;
AED 
AED    va_start(ap);
AED    if (putc(*s++,ofile) == '+')
AED       putc(*s++,ofile);
AED    while (c = *s++)
AED       switch (c)  {			/* Output formats for add'l args:  */
AED          case 'b':			/* b - single byte unaltered */
AED          case 'c':			/* c - single char unaltered */
AED             n = va_arg(ap,int);
AED             putc(n, ofile);
AED             break;
AED          case 'i':			/* i - 16-bit integer as two bytes */
AED             n = va_arg(ap,int);
AED             putc(n>>8, ofile);
AED             putc(n, ofile);
AED             break;
AED          case 's':			/* s - string terminated by '\0' */
AED             fputs(va_arg(ap,int),ofile);
AED             break;
AED          case 'x':			/* x - two args give x and y coords */
AED             x = va_arg(ap,int);
AED             y = va_arg(ap,int);
AED             putc(((x>>4)&0xF0) | (y>>8), ofile);
AED             putc(x, ofile);
AED             putc(y, ofile);
AED             break;
AED          default:			/* unrecognized - just echoed */
AED             putc(c, ofile);
AED          }
AED    va_end(ap);
AED    }
#endif					/* MemMon == 1 */

#if MemMon == 2

/*
 *  graphics driver for Raster Tech One/80  (MemMon == 2).
 *
 *  These functions provide a ONE-DIMENSIONAL interface to the Raster Tech.
 */

#define DMAport "/dev/rt0"		/* DMA port*/
#define SerialPort "/dev/ttyrt"		/* serial line */
#define TextHeight 20			/* text height (matter of taste) */
#define TextSep 6			/* PIXELS between text and mem map */
#define CTAddr 0xFC00			/* color table address in raster tech */

#define Width 1280			/* screen width */
#define Xbase (-Width/2)		/* horizontal addressing base */
#define Height 1024			/* screen height */
#define Ybase (-Height/2)		/* vertical addressing base */
#define CharSizeX (3400/TextLength)	/* empirical constant */
#define CharSizeY ((int)(1.6*TextHeight))/* empirical constant */
#define CharWidth (Width/(float)TextLength)/* chr width in pixels & fraction */

/* raster tech command bytes and formats */
#define SGPX	"\004"			/* enter graphics (standard) */
#define EGPX	"\005"			/* enter graphics (redef from \004) */
#define BLINKC	"\043"
#define BLINKE	"\040bbbb"
#define BLINKR	"\042b"
#define CLEAR	"\207"
#define CONFIG	"\044wwwwwwww"
#define DRW3R	"\203bb"
#define LUT8	"\034bbbb"
#define MOVABS	"\001xy"
#define PIXFUN	"\073b"
#define POKE	"\276ww"
#define PRMFIL	"\037b"
#define QUIT	"\377"
#define RECREL	"\211xy"
#define RGBTRU	"\116b"
#define SCRORG	"\066xy"
#define SPCHAR	"\262bbb"
#define TEXTN	"\251bbww"
#define TEXT1	"\220b"
#define VAL8	"\206b"
#define VECPAT	"\056w"
#define WINDOW	"\072xyxy"
#define WMSK16	"\104w"
#define ZOOM	"\064b"

#define byte(c) putc(c,ofile);				/* output byte */
#define word(c) putc((c)>>8,ofile); putc(c,ofile)	/* output word */

static FILE *ofile = 0;			/* raster tech output file */
static FILE *ifile = 0;			/* raster tech input file */
static int yscale;			/* vertical scaling factor */
static int npixels;			/* screen size (scaled) */

/*
 * gdinit(filename) - initialize for graphics output.
 */

static gdinit(fname)
char *fname;
   {
   static char obuf[BUFSIZ];
   int dma = 0;

   if ((ofile = fopen(fname,"w")) == NULL)
      error("can't open MEMMON file");

   if (isatty(fileno(ofile)))
      litio(fileno(ofile));		/* set literal I/O mode if tty line */
   else if (!strcmp(fname,DMAport))  {
      fname = SerialPort;		/* with DMA output force serial input */
      dma = 1;
      }
   else
      fname = 0;

   if (fname)				/* open input file, if any */
      if (ifile = fopen(fname,"r"))  {
	 if (dma)
            litio(fileno(ifile));	/* serving dma, stty not done above */
	 }
      else  {
         fprintf(stderr, "can't read MEMMON file;  will not pause\n");
         fflush(stderr);
         ifile = 0;
         }

   if (ifile)
      setbuf(ifile,NULL);		/* not much input -- no buffer needed */
   setbuf(ofile,obuf);			/* use small buffer -- less jerky */

   word(0);				/* try to flush incomplete commands */
   word(0);
   rtcmd(QUIT);				/* exit graphics mode */

   rtcmd(SGPX);				/* enter gpx mode, if not yet redef */
   rtcmd(SPCHAR,0,1,*EGPX);		/* redefine from \04 to \05 */
   rtcmd(QUIT);				/* exit graphics mode */

   rtcmd(EGPX);				/* enter graphics mode (for sure) */
   rtcmd(CONFIG,0x2000,0x400,0x800,0x1000,0x400,0,0,0);	/* configure mem */
   rtcmd(RGBTRU,1);			/* use 24-bit mode */
   rtcmd(ZOOM,1);			/* reset zoom */
   rtcmd(SCRORG,0,0);			/* set screen origin */
   rtcmd(WINDOW,Xbase,Ybase,Xbase+Width-1,Ybase+Height-1);/* clipping window */
   rtcmd(PRMFIL,1);			/* set filled primitives */
   rtcmd(VECPAT,0xFFFF);		/* set solid lines */
   rtcmd(PIXFUN,0);			/* set opaque mode */
   rtcmd(WMSK16,0xFFFF);		/* enable all bit planes */
   rtcmd(TEXTN,CharSizeX,CharSizeY,0,0);/* set text parameters */
   rtcmd(BLINKC);			/* clear blink table */
   rtcmd(BLINKR,20);			/* set blink rate (1.5 Hz) */
   rtcmd(BLINKE,7,HLcolr,0,255);	/* blink HLcolr black/white */
}

/*
 * gdmap(array,n) - set color map.  Also write a shadow copy of the map in high
 *  Raster Tech memory for use by rtscreen(1).  Each entry of array (of size n)
 *  has three bits each of red, green, blue values in least signifigant bits.
 */

static gdmap(a,n)
int a[], n;
   {
   unsigned char ra[MapSize+1], ga[MapSize+1], ba[MapSize+1];
   int i;

/* make 8-bit color value from 3-bit value */
#define val8(n) (((n)<<5)+((n)<<2)+((n)>>1))

   for (i = 0; i < n; i++, a++)  {
      ra[i] = val8((*a&0700)>>6);
      ga[i] = val8((*a&0070)>>3);
      ba[i] = val8((*a&0007));
      rtcmd(LUT8,i,ra[i],ga[i],ba[i]);	/* load color map entry */
      }
   for (i = 0; i < n; i += 2)  {	/* save copy for rtscreen(1) */
      rtcmd(POKE,CTAddr+i,(ra[i]<<8)|ra[i+1]);
      rtcmd(POKE,CTAddr+i+256,(ga[i]<<8)|ga[i+1]);
      rtcmd(POKE,CTAddr+i+512,(ba[i]<<8)|ba[i+1]);
      }
   }

/*
 * gdflood(c) - fill screen with color c.
 */

static gdflood(c)
int c;
   {
   rtcmd(VAL8,c);			/* set color for clear */
   rtcmd(CLEAR);			/* clear screen */
   }

/*
 * gdscale(n) - set vertical scaling factor.
 */

static gdscale(n)
int n;
   {
   if (n > MaxScale)
      n = MaxScale;
   yscale = n;
   npixels = gdsize(n);
   }

/*
 * gdsize(n) - return size of display with scaling factor n;
 */

static gdsize(n)
int n;
   {
   if (n > MaxScale)
      n = MaxScale;
   return ((Height - TextLines * TextHeight - TextSep + 1) / n) * Width;
   }

/*
 * gdpaint(start,n,color,b) - paint n pixels in given color.
 *  If b >= 0, the last pixel is to be that color instead (for a border)
 */

static gdpaint(s,n,c,b)
int s, n, c, b;
   {
   int x, y;

   if (s < 0 || s >= npixels || n <= 0)	/* if out of range, return */
      return;
   if (s + n > npixels)			/* if too long, truncate */
      n = npixels - s;
   if (b >= 0)				/* if border, decr total count */
      n--;
   x = s % Width;			/* where on row,  which row? */
   y = Height - TextLines * TextHeight - TextSep + 1 - yscale *
      (1 + s / Width);
   rtcmd(VAL8,c);			/* set color */
   while (x + n >= Width)  {		/* draw all rows but last */
      rtcmd(MOVABS,Xbase+x,Ybase+y);		/* position to LL corner */
      rtcmd(RECREL,Width-1-x,yscale-1-1);	/* draw to UR corner */
      n -= Width - x;				/* decr count */
      x = 0;					/* move to start of next row */
      y -= yscale;
      }
   if (n) {				/* last row */
      rtcmd(MOVABS,Xbase+x,Ybase+y);		/* position */
      rtcmd(RECREL,n-1,yscale-1-1);		/* draw */
      x += n;
      }
   if (b >= 0)  {			/* border */
      rtcmd(VAL8,b);				/* color */
      rtcmd(MOVABS,Xbase+x,Ybase+y);		/* position */
      rtcmd(DRW3R,0,yscale-1-1);		/* draw */
      }
   }

/*
 * gdtext(string,addr,fgcolr,bgcolr) - output text.
 */

static gdtext(s,a,f,b)
char *s;
int a, f, b;
   {
   int x, y, n;

   n = strlen(s);
   x = (a % TextLength) * CharWidth;			/* where on line? */
   y = Height - TextHeight * (1 + a / TextLength) + 1;	/* which line? */
   rtcmd(VAL8,b);					/* set bkground color */
   rtcmd(MOVABS,Xbase+x,Ybase+y);			/* position */
   rtcmd(RECREL,(int)(CharWidth*(n+1))-2,TextHeight-2);	/* draw background */
   if (f == b || n == 0)				/* if no text */
      return;
   rtcmd(VAL8,f);					/* set text color */
   rtcmd(MOVABS,Xbase+x+(int)(.45*CharWidth),Ybase+y+(int)(.25*TextHeight));
   rtcmd(TEXT1,n);					/* issue text func */
   while (*s)
      byte(*s++);					/* send the chars */
   }

/*
 * gdflush() - flush output.
 */

static gdflush()
   {
   if (ofile->_cnt & 1)			/* ugh! */
      byte(0);				/* make byte count even */
   fflush(ofile);
   }

/*
 * gdpause(msg,color) - pause for ack, showing message describing the reason.
 * Return last character before '\n', 0 if none, or EOF if not interactive.
 */

static gdpause(msg,color)
char *msg;
int color;
   {
   int c1, c2;

   if (!ifile)
      return EOF;
   gdtext(msg,0,BGcolr,color);		/* output the prompt */
   rtcmd(QUIT);				/* exit graphics mode */
   gdflush();
   c1 = 0;
   while ((c2 = getc(ifile)) != '\n' && c2 != '\r')	/* get char up to CR */
      if (c2 == EOF || c2 == '\04')  {			/* handle eof */
         ifile = 0;
         c1 = EOF;
         break;
         }
      else
         c1 = c2;					/* save previous char */
   rtcmd(EGPX);				/* reenter graphics mode */
   gdtext(msg,0,BGcolr,BGcolr);		/* clear the prompt */
   return c1;				/* return char before CR */
   }

/*
 * gdterm() - terminate graphics
 */

static gdterm()
   {
   if (!ofile)
      return;				/* if no file, just return */
   rtcmd(SPCHAR,0,1,*SGPX);		/* reset "enter graphics" character */
   rtcmd(QUIT);				/* exit graphics mode */
   word(0);				/* dma driver requires "some" nulls */
   word(0);
   word(0);
   gdflush();				/* flush output */
   }

/*
 * rtcmd(s,args) - output command to raster tech.
 *  s is a string specifying the command format.  The first character is a
 *  raster tech function code.  Each additional character specifies the format
 *  for outputting one more argument (see below).
 */

/*VARARGS*/
static rtcmd (va_alist)
va_dcl
{
    va_list ap;
    char c, *s;
    unsigned int n;

    va_start(ap);				/* set up varargs stuff */
    s = va_arg(ap, char *);
    putc(*s++,ofile);				/* output function byte */
    while (c = *s++)
	switch (c) {				/* format characters are: */
	    case 'b':				/* b - output byte */
		n = va_arg(ap,unsigned int);
		byte(n);
		break;
	    case 'w':				/* w - output word */
	    case 'x':				/* x - output x-coordinate */
	    case 'y':				/* y - output y-coordinate */
		n = va_arg(ap,unsigned int);
		word(n);
		break;
	}
}
#endif					/* MemMon == 2 */


#else					/* MemMon */
static int x;		/* prevent null module when MemMon not defined */
#endif					/* MemMon */
