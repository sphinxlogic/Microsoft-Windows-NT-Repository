#include <errno.h>

int errno;

/*
 * sin(x), x in radians
 */

FncDcl(sin,1)
   {
   int t;
   union numeric r;
   double sin();

   if ((t = cvreal(&Arg1, &r)) == NULL) 
     RunErr(102, &Arg1);
   if (mkreal(sin(r.real),&Arg0) == Error) 
      RunErr(0, NULL);
   Return;
   }

/*
 * cos(x), x in radians
 */

FncDcl(cos,1)
   {
   int t;
   union numeric r;
   double cos();

   if ((t = cvreal(&Arg1, &r)) == NULL) 
      RunErr(102, &Arg1);
   if (mkreal(cos(r.real),&Arg0) == Error) 
      RunErr(0, NULL);
   Return;
   }

/*
 * tan(x), x in radians
 */

FncDcl(tan,1)
   {
   int t;
   double y;
   union numeric r;
   double tan();

   if ((t = cvreal(&Arg1, &r)) == NULL) 
      RunErr(102, &Arg1);
   y = tan(r.real);
   if (errno == ERANGE) 
      RunErr(-252, NULL);
   if (mkreal(y,&Arg0) == Error) 
      RunErr(0, NULL);
   Return;
   }

/*
 * acos(x), x in radians
 */
FncDcl(acos,1)
   {
   int t;
   double y;
   union numeric r;
   double acos();

   if ((t = cvreal(&Arg1, &r)) == NULL) 
      RunErr(102, &Arg1);
   y = acos(r.real);
   if (errno == EDOM) 
      RunErr(-251, NULL);
   if (mkreal(y,&Arg0) == Error) 
      RunErr(0, NULL);
   Return;
   }

/*
 * asin(x), x in radians
 */
FncDcl(asin,1)
   {
   int t;
   double y;
   union numeric r;
   double asin();

   if ((t = cvreal(&Arg1, &r)) == NULL) 
      RunErr(102, &Arg1);
   y = asin(r.real);
   if (errno == EDOM) 
      RunErr(-251, NULL);
   if (mkreal(y,&Arg0) == Error) 
      RunErr(0, NULL);
   Return;
   }

/*
 * atan(x), x in radians
 */
FncDcl(atan,1)
   {
   int t;
   union numeric r;
   double atan();

   if ((t = cvreal(&Arg1, &r)) == NULL) 
      RunErr(102, &Arg1);
   if (mkreal(atan(r.real),&Arg0) == Error) 
      RunErr(0, NULL);
   Return;
   }

/*
 * atan2(x,y), x, y in radians
 */
FncDcl(atan2,2)
   {
   int t;
   union numeric r1, r2;
   double atan2();

   if ((t = cvreal(&Arg2, &r2)) == NULL) 
      RunErr(102, &Arg2);
   if ((t = cvreal(&Arg1, &r1)) == NULL) 
      RunErr(102, &Arg1);
   if (mkreal(atan2(r1.real,r2.real),&Arg0) == Error) 
      RunErr(0, NULL);
   Return;
   }

#define PI 3.14159

/*
 * dtor(x), x in degrees
 */

FncDcl(dtor,1)
   {
   union numeric r;

   if (cvreal(&Arg1, &r) == NULL) 
      RunErr(102, &Arg1);
   if (mkreal(r.real * PI / 180, &Arg0) == Error) 
      RunErr(0, NULL);
   Return;
   }

/*
 * rtod(x), x in radians
 */
FncDcl(rtod,1)
   {
   union numeric r;

   if (cvreal(&Arg1, &r) == NULL) 
      RunErr(102, &Arg1);
   if (mkreal(r.real * 180 / PI, &Arg0) == Error) 
      RunErr(0, NULL);
   Return;
   }

/*
 * exp(x)
 */

FncDcl(exp,1)
   {
   int t;
   double y;
   union numeric r;
   double exp();

   if ((t = cvreal(&Arg1, &r)) == NULL) 
      RunErr(102, &Arg1);
   y = exp(r.real);
   if (errno == ERANGE) 
      RunErr(-252, NULL);
   if (mkreal(y,&Arg0) == Error) 
      RunErr(0, NULL);
   Return;
   }

/*
 * log(x)
 */

FncDcl(log,1)
   {
   int t;
   double y;
   union numeric r;
   double log();

   if ((t = cvreal(&Arg1, &r)) == NULL) 
      RunErr(102, &Arg1);
   y = log(r.real);
   if (errno == EDOM) 
      RunErr(-251, NULL);
   if (mkreal(y,&Arg0) == Error) 
      RunErr(0, NULL);
   Return;
   }

/*
 * log10(x)
 */

FncDcl(log10,1)
   {
   int t;
   double y;
   union numeric r;
   double log10();

   if ((t = cvreal(&Arg1, &r)) == NULL) 
      RunErr(102, &Arg1);
   y = log10(r.real);
   if (errno == EDOM) 
      RunErr(-251, NULL);
   if (mkreal(y,&Arg0) == Error) 
      RunErr(0, NULL);
   Return;
   }

/*
 * sqrt(x)
 */

FncDcl(sqrt,1)
   {
   int t;
   double y;
   union numeric r;
   double sqrt();

   if ((t = cvreal(&Arg1, &r)) == NULL) 
      RunErr(102, &Arg1);
   y = sqrt(r.real);
   if (errno == EDOM) 
      RunErr(-251, NULL);
   if (mkreal(y,&Arg0) == Error) 
      RunErr(0, NULL);
   Return;
   }
