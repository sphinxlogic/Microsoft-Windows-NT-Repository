
/*
 * The following code is operating-system dependent. Include files that
 *  are system-dependent.
 */

#if PORT
   /* probably needs something */
#endif					/* PORT */

#if AMIGA || ATARI_ST
   /* needed only for runstats */
#endif					/* AMIGA  || ATARI_ST */

#if MACINTOSH
#if MPW
#include <types.h>
#include SysTime
#include <OSUtils.h>
#include <Events.h>
#endif					/* MPW */
#endif					/* MACINTOSH */

#if MSDOS
   /* needs something */
#endif					/* MS-DOS */

#if UNIX 
#include <sys/types.h>
#include <sys/times.h>
#endif					/* UNIX || MSDOS */

#if VMS
#include <types.h>
struct tms {
    time_t    tms_utime;	/* user time */
    time_t    tms_stime;	/* system time */
    time_t    tms_cutime;	 /* user time, children */
    time_t    tms_cstime;	 /* system time, children */
};
#endif					/* VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

