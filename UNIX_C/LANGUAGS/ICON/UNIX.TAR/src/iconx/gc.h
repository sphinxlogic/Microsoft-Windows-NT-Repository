/*
 * Definitions and declarations used for storage management.
 */

#define F_Mark		0100000 	/* bit for marking blocks */

#define GranSize	     64		/* storage allocation granule size */

#define Sqlinc		    128 	/* qualifier pointer list increment */

#define Blocks	1			/* collection is for blocks */
#define Strings	2			/* collection is for strings */
#define Static 3			/* collection is for static region */

/*
 * External definitions.
 */

extern char *currend;			/* current end of memory region */
extern uword blkneed;			/* stated need for block space */
extern uword strneed;			/* stated need for string space */
extern uword statneed;
extern struct descrip *globals; 	/* start of global variables */
extern struct descrip *eglobals;	/* end of global variables */
extern struct descrip *gnames;		/* start of global variable names */
extern struct descrip *egnames; 	/* end of global variable names */
extern struct descrip *statics; 	/* start of static variables */
extern struct descrip *estatics;	/* end of static variables */

extern word qualsize;

/*
 * Get type of block pointed at by x.
 */
#define BlkType(x)   (*(word *)x)

/*
 * BlkSize(x) takes the block pointed to by x and if the size of
 *  the block as indicated by bsizes[] is nonzero it returns the
 *  indicated size; otherwise it returns the second word in the
 *  block contains the size.
 */
#define BlkSize(x) (bsizes[*(word *)x & ~F_Mark] ? \
		     bsizes[*(word *)x & ~F_Mark] : *((word *)x + 1))

/*
 * If memory monitoring is not enabled, redefine function calls
 * to do nothing.
 */
#ifndef MemMon
#define MMAlc(n,t)
#define MMBGC()
#define MMEGC()
#define MMMark(b,t)
#define MMPaint(a,l,t)
#define MMPause(s)
#define MMShow(x,c)
#define MMStr(n)
#define MMSMark(a,n)
#endif					/* MemMon */
