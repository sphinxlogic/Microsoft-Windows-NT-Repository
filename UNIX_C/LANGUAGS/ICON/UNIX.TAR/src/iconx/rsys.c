/*
 * File: rsys.c
 *  Contents: getstr, host, putstr
 */

#include "../h/rt.h"

/*
 * getstr - read a line into buf from file fd.  At most maxi characters
 *  are read.  getstr returns the length of the line, not counting
 *  the newline.  Returns -1 if EOF and -2 if length was limited by
 *  maxi.
 */

getstr(buf, maxi, fd)
register char *buf;
int maxi;
FILE *fd;
   {
   register int c, l;

/*
 * The following code is operating-system dependent.  Interactive
 *  files may require special handling.
 */

#if PORT
   /* probably nothing to do */
#endif					/* PORT */

#if AMIGA
   if (IsInteractive(fileno(fd)))
      return read(fileno(fd),buf,maxi);
#endif					/* AMIGA */

#if ATARI_ST || MACINTOSH || MSDOS || UNIX || VMS
   /* nothing to do */
#endif					/* ATARI_ST || MACINTOSH || MSDOS ... */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */
   l = 0;
   while ((c = getc(fd)) != '\n') {
      if (c == EOF)
	 if (l > 0) return l;
	 else return -1;
      if (++l > maxi) {
	 ungetc(c, fd);
	 return -2;
	 }
      *buf++ = c;
      }
   return l;
   }

#ifdef UtsName
#include <sys/utsname.h>
#endif					/* UtsName */

/*
 * iconhost - return some sort of host name into the buffer pointed at
 *  by hostname.  This code accommodates several different host name
 *  fetching schemes.
 */
iconhost(hostname)
char *hostname;
   {
#ifdef WhoHost
   /*
    * The host name is in /usr/include/whoami.h. (V7, 4.[01]bsd)
    */
   whohost(hostname);
#endif					/* WhoHost */

#ifdef UtsName
   {
   /*
    * Use the uname system call.  (System III & V)
    */
   struct utsname utsn;
   uname(&utsn);
   strcpy(hostname,utsn.nodename);
   }
#endif					/* UtsName */

#ifdef GetHost
   /*
    * Use the gethostname system call.  (4.2bsd)
    */
   gethostname(hostname,MaxCvtLen);
#endif					/* GetHost */

/*
 * The following code is operating-system dependent. Get host, if
 *  this facility is used.
 */

#if PORT
   /* nothing to do */
#endif					/* PORT */

#if AMIGA  || ATARI_ST || MACINTOSH || MSDOS || UNIX
   /* nothing to do -- uses HostStr */
#endif					/* AMIGA || ATARI_ST || MACINTOSH ... */

#if VMS
   /*
    * VMS has its own special logic.
    */
   char *h;
   if (!(h = getenv("ICON$HOST")) && !(h = getenv("SYS$NODE")))
      h = "VAX/VMS";
   strcpy(hostname,h);
#endif					/* VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

#ifdef HostStr
   /*
    * The string constant HostStr contains the host name.
    */
   strcpy(hostname,HostStr);
#endif					/* HostStr */
   }

#ifdef WhoHost
#define HdrFile "/usr/include/whoami.h"
/*
 * whohost - look for a line of the form
 *  #define sysname "name"
 * in HdrFile and return the name.
 */
whohost(hostname)
char *hostname;
   {
   char buf[BUFSIZ];
   FILE *fd;

   fd = fopen(HdrFile, "r");
   if (fd == NULL) {
      sprintf(buf, "Cannot open %s, no value for &host\n", HdrFile);
      syserr(buf);
   }

   for (;;) {   /* each line in the file */
      if (fgets(buf, sizeof buf, fd) == NULL) {
         sprintf(buf, "No #define for sysname in %s, no value for &host\n",
            HdrFile);
         syserr(buf);
      }
      if (sscanf(buf,"#define sysname \"%[^\"]\"", hostname) == 1) {
         fclose(fd);
         return;
      }
   }
   }
#endif					/* WhoHost */

/*
 * Print string referenced by descriptor d. Note, d must not move during
 *   a garbage collection.
 */

putstr(f, d)
register FILE *f;
struct descrip *d;
   {
   register char *s;
   register word l;

   l = StrLen(*d);
   s = StrLoc(*d);
   if (l == 0)
      return  Success;
   putc(*s, f);

   /*
    * A garbage collection could have been triggered by buffer allocation,
    *  so reload s.
    */
   s = StrLoc(*d) + 1;
   while (--l)
      putc(*s++, f);
   if (ferror(f))
      return Failure;
   else
      return Success;
   }
