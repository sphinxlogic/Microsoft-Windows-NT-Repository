#include <stdio.h>
#include "../h/keyword.h"
#include "../h/config.h"
#include "sym.h"

/*
 * Keyword table.
 */

struct keyent keytab[] = {
   "ascii",	K_ASCII,
   "clock",	K_CLOCK,
   "collections",	K_COLLECTIONS,
   "cset",	K_CSET,
   "current",	K_CURRENT,
   "date",	K_DATE,
   "dateline",	K_DATELINE,
   "digits",	K_DIGITS,
   "error",	K_ERROR,
   "errornumber",	K_ERRORNUMBER,
   "errortext",	K_ERRORTEXT,
   "errorvalue",	K_ERRORVALUE,
   "errout",	K_ERROUT,
   "fail",	K_FAIL,
   "features",	K_FEATURES,
   "file",	K_FILE,
   "host",	K_HOST,
   "input",	K_INPUT,
   "lcase",	K_LCASE,
   "level",	K_LEVEL,
   "line",	K_LINE,
   "main",	K_MAIN,
   "null",	K_NULL,
   "output",	K_OUTPUT,
   "pos",	K_POS,
   "random",	K_RANDOM,
   "regions",	K_REGIONS,
   "source",	K_SOURCE,
   "storage",	K_STORAGE,
   "subject",	K_SUBJECT,
   "time",	K_TIME,
   "trace",	K_TRACE,
   "ucase",	K_UCASE,
   "version",	K_VERSION,
   "",		-1
   };
