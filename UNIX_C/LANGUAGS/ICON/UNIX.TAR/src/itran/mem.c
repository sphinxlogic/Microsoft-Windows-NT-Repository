/*
 * Memory initialization and allocation for the translator.
 */

#include "itran.h"
#include "../h/memsize.h"
#include "sym.h"
#include "tree.h"

struct lentry **lhash;		/* hash area for local table */
struct gentry **ghash;		/* hash area for global table */
struct centry **chash;		/* hash area for constant table */
struct ientry **ihash;		/* hash area for identifier table */

nodeptr tree;			/* parse tree space */
nodeptr tend;			/* end of parse tree space */
struct lentry *ltable;		/* local table */
struct gentry *gtable;		/* global table */
struct centry *ctable;		/* constant table */
struct ientry *itable;		/* identifier table */

char *strings;			/* string space */
char *strend;			/* end of string space */

nodeptr tfree;			/* free pointer for parse tree space */
struct lentry *lfree;		/* free pointer for local table */
struct gentry *gfree;		/* free pointer for global table */
struct centry *ctfree;		/* free pointer to constant table */
struct ientry *ifree;		/* free pointer for identifier table */
char *strfree;			/* free pointer for string space */

int tsize = TSize;		/* initial size of parse tree space */
int lsize = LSize;		/* initial size of local table */
int gsize = GSize;		/* initial size of global table */
int csize = CSize;		/* initial size of constant table */
int isize = ISize;		/* initial size of identifier table */
int lhsize = LhSize;		/* initial size of local hash table */
int ghsize = GhSize;		/* initial size of global hash table */
int chsize = ChSize;		/* initial size of constant hash table */
int ihsize = IhSize;		/* initial size of identifier hash table */
int lmask;			/* mask for local table hash */
int gmask;			/* mask for global table hash */
int cmask;			/* mask for constant table hash */
int imask;			/* mask for identifier table hash */
unsigned int ssize = SSize;	/* initial size of string space */

int memsetd = 0;		/* memory initialization switch */

/*
 * tcalloc - calloc that tests for allocation success, and terminates if fails.
 */
char *tcalloc(number,size)
unsigned number, size;
   {
   pointer ptr, calloc();

   ptr = calloc(number,size);

   if (ptr == NULL) {
     fprintf(stderr, "mem: can't get enough memory\n");
     exit(ErrorExit);
     }
   return ptr;
}

/*
 * meminit does per-file initialization of various data structures used
 *  by the translator.
 */
meminit()
   {
   register int *p;

   if (!memsetd) {
      memalloc();		/* allocate data regions for first file */
      memsetd = 1;
      }
   /*
    * Reset the free pointer for each region.
    */
   lfree = ltable;
   gfree = gtable;
   ctfree = ctable;
   ifree = itable;
   strfree = strings;
   tfree = tree;
   /*
    * Zero out the hash tables.
    */
   for (p = (int *)lhash; p < (int *)&lhash[lhsize]; p++)
      *p = NULL;
   for (p = (int *)ghash; p < (int *)&ghash[ghsize]; p++)
      *p = NULL;
   for (p = (int *)chash; p < (int *)&chash[chsize]; p++)
      *p = NULL;
   for (p = (int *)ihash; p < (int *)&ihash[ihsize]; p++)
      *p = NULL;

   /*
    * Vestigial structures - these flags are only incremented after
    *  a call to syserr.  Idea was apparently to count number of
    *  entries in an overflowing table, but wasn't completely
    *  implemented.
    */
   alclflg = 0;
   alcgflg = 0;
   alccflg = 0;
   }

/*
 * memalloc computes sizes of data regions needed by the translator
 * obtains space for them, and initializes pointers to them
 */

memalloc()
{
   register int i;

   /*
    * Round sizes of hash tables for locals, globals, constants, and
    *  identifiers to next larger power of two.  The corresponding
    *  mask values are set to one less than the hash table size so that
    *  an integer value can be &'d with the mask to produce a hash value.
    *  (See [lgc]hasher in sym.h.)
    */
   for (i = 1; i < lhsize; i <<= 1) ;
   lhsize = i;
   lmask = i - 1;
   for (i = 1; i < ghsize; i <<= 1) ;
   ghsize = i;
   gmask = i - 1;
   for (i = 1; i < chsize; i <<= 1) ;
   chsize = i;
   cmask = i - 1;
   for (i = 1; i < ihsize; i <<= 1) ;
   ihsize = i;
   imask = i - 1;

   /*
    * Allocate the various data structures.
    */
   lhash = (struct lentry **)tcalloc((unsigned)lhsize, sizeof(struct lentry *));
   ghash = (struct gentry **)tcalloc((unsigned)ghsize, sizeof(struct gentry *));
   chash = (struct centry **)tcalloc((unsigned)chsize, sizeof(struct centry *));
   ihash = (struct ientry **)tcalloc((unsigned)ihsize, sizeof(struct ientry *));
   ltable = (struct lentry *)tcalloc((unsigned)lsize, sizeof(struct lentry));
   gtable = (struct gentry *)tcalloc((unsigned)gsize, sizeof(struct gentry));
   ctable = (struct centry *)tcalloc((unsigned)csize, sizeof(struct centry));
   itable = (struct ientry *)tcalloc((unsigned)isize, sizeof(struct ientry));
   tree = (nodeptr)tcalloc((unsigned)tsize, sizeof(word));
   strings = (char *)tcalloc((unsigned)ssize, sizeof(char));
   tend = (nodeptr)((word *)tree + tsize);
   strend = strings + ssize;
   }
