/*
 * Main program that controls the translation of Icon programs.
 */

#include "itran.h"
#include "sym.h"
#include "tree.h"
#include "token.h"

#ifndef VarTran
#include "../h/version.h"
#endif					/* VarTran */

#define MaxFiles 64		/* maximum number of file names */
#define MaxName  40		/* maximum length of file name */
#define MaxPpCmd 100		/* maximum length of preprocessor command */

char *strcat();
char *strcpy();

int fatalerrs	= 0;		/* total number of fatal errors */
int warnings	= 0;		/* total number of warnings */
int nocode	= 0;		/* non-zero to suppress code generation */
int inline	= 1;		/* current input line number */
int incol	= 0;		/* current input column number */
int peekc	= 0;		/* one-character look ahead */
int implicit	= LOCAL;	/* implicit scope for undeclared identifiers */
int silence	= 0;		/* don't be silent (default) */
int trace	= 0;		/* initial setting of &trace */

FILE *infile;			/* current input file */
FILE *codefile; 		/* current ucode output file */
FILE *globfile; 		/* current global table output file */
char codename[MaxName]; 	/* name of ucode output file */
char globname[MaxName]; 	/* name of global table output file */

char *filelist[MaxFiles];	/* list of input file names */
char **filep;			/* pointer to current input file name */

main(argc,argv)
int argc;
char **argv;
   {
   int aval;
   int mflag = 0;		/* flag to invoke preprocessor */
   char *progname;
   char fnbuf[MaxName];		/* buffer for constructing file names */
   char pp_cmd[MaxPpCmd];	/* preprocessor command string */
   char *cmd_p;			/* pointer into command string */
   char *s;
   register char **fp;		/* indexes filelist while scanning args */

/*
 * The following code is operating-system dependent.  It declares popen()
 *  if pipes are supported.
 */

#if PORT
   /* pipes generally not supported */
#endif					/* PORT */

#if AMIGA || ATARI_ST || MACINTOSH || MSDOS
   /* pipes not supported */
#endif					/* AMIGA || ATARI_ST || MACINTOSH ... */

#if UNIX || VMS
   extern FILE *popen();
#endif					/* UNIX || VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   progname = "itran";
   filep = fp = filelist;
   strcpy(pp_cmd, "m4 ");
   cmd_p = pp_cmd + strlen(pp_cmd);
   while (--argc) {
      if (**++argv == '-') {    /* argument starts with a '-' */
	 switch ((*argv)[1]) {
	    case '\0':          /* read standard input */
	       *fp++ = *argv;
	       continue;
	    case 'm':
		mflag++;
		continue;
	    case 'u':           /* tell ilink to note undeclared identifiers*/
		implicit = 0;
		continue;
	    case 't':           /* tell ilink to turn on tracing */
		trace++;
		continue;
	    case 's':           /* don't produce informative messages */
		silence++;
		continue;
	    case 'L':           /* debug flag for ilink, ignored by itran */
		continue;
	    case 'S':
	       if ((*argv)[3] == 'h') { /* change hash table size */
		  aval = atoi(&(*argv)[4]);
		  if (aval <= 0)
		     goto badarg;
		  switch ((*argv)[2]) {
		     case 'i': ihsize = aval; continue;
		     case 'g': ghsize = aval; continue;
		     case 'c': chsize = aval; continue;
		     case 'l': lhsize = aval; continue;
		     case 'f': continue;
		     }
		  }
	       else {			/* change symbol table size */
		  aval = atoi(&(*argv)[3]);
		  if (aval <= 0)
		     goto badarg;
		  switch ((*argv)[2]) {
		     case 'c': csize = aval; continue;
		     case 'i': isize = aval; continue;
		     case 'g': gsize = aval; continue;
		     case 'l': lsize = aval; continue;
		     case 's': ssize = aval; continue;
		     case 't': tsize = aval; continue;
		     case 'f': continue;
		     case 'F': continue;
		     case 'n': continue;
		     case 'r': continue;
		     case 'L': continue;
		     case 'C': continue;
		     }
		  }
	    default:
	    badarg:
	       fprintf(stderr, "bad argument: %s\n", *argv);
	       continue;
	    }
	 }
      else	/* argument doesn't start with a '-', assume it's a file */
	 *fp++ = *argv;
      }
   *fp++ = 0;	/* terminate list of files with a NULL */

   /*
    * Process each input file in turn.	If preprocessing is to be done (mflag
    *  is set), a pipe is opened to m4 with the current file name,
    *  otherwise, the input file is opened.  infile is the file pointer for
    *  the current input file and filep is the name of the file.
    */
   for ( ; *filep; filep++) {
      if (!mflag) {
	 if (*filep[0] == '-')
	    infile = stdin;
	 else

            /*
             * Find last character.
             */
            {
	    char   *cp, lastch = 0;

	    cp = *filep;
	    while( *cp )
	    {
               if (

/*
 * The following code is operating-system dependent. This code finds last
 *  special character in file name.
 */

#if PORT
   /* something is needed to test *cp for special characters in file names */
#endif					/* PORT */

#if AMIGA
                 *cp == '.' || *cp == '/' || *cp == ':'
#endif					/* AMIGA */

#if MACINTOSH
#if MPW
                  *cp == '.' || *cp == ':'
#endif					/* MPW */
#endif					/* MACINTOSH */

#if ATARI_ST || MSDOS
                  *cp == '.'  || *cp == '\\' || *cp == '/'  || *cp == ':'
#endif					/* ATARI_ST || MSDOS */

#if UNIX
                  *cp == '.' || *cp == '/'
#endif					/* UNIX */

#if VM || MVS
#endif					/* VM || MVS */

#if VMS
                  *cp == '.' || *cp == ']' || *cp == ':'
#endif					/* VMS */

/*
 * End of operating-system specific code.
 */

                     )
                  lastch = *cp;
	       cp++;
	    }
	    if (lastch != '.')
	    {
               if (((uword)cp - (uword)filep + 5) > MaxName) {
	          fprintf(stderr, "%s: file name %s too long\n", progname,
                     *filep);
	          fatalerrs++;
                  continue;
                  }
               else {
                  strcpy(fnbuf,*filep);
                  strcat(fnbuf,".icn");
                  *filep = fnbuf;
                  }
	    }
	    infile = fopen(*filep,"r");
	 }
      }
      else {

/*
 * The following code is operating-system dependent. This code does
 *  processing or notes error if it is not supported through -m flag.
 */

#if PORT
	 fprintf(stderr, "-m option not supported\n");
	 exit(ErrorExit);
#endif					/* PORT */

#if AMIGA || ATARI_ST || MACINTOSH || MSDOS || VMS
	 fprintf(stderr, "-m option not supported\n");
	 exit(ErrorExit);
#endif					/* AMIGA || ATARI_ST || MACINTOSH ... */

#if UNIX
         if ((uword)cmd_p + strlen(*filep) >= (uword)pp_cmd + MaxPpCmd) {
	    fprintf(stderr, "%s: preprocessor command line too long\n",
               progname);
	    fatalerrs++;
            continue;
            }
	 strcpy(cmd_p, *filep);
	 infile = popen(pp_cmd, "r");
#endif					/* UNIX */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

	 }
      if (*filep[0] == '-')
	 *filep = "stdin";
      if (infile == NULL) {
	 fprintf(stderr, "%s: cannot open %s\n", progname, *filep);
	 fatalerrs++;
	 continue;
	 }

      if (!silence)
	 fprintf(stderr, "%s:\n", *filep);

#ifndef VarTran
      /*
       * Form names for the .u1 and .u2 files and open them.
       */
      maknam(codename, *filep, ".u1");
      maknam(globname, *filep, ".u2");
      codefile = fopen(codename, "w");
      if (codefile == NULL) {
	 fprintf(stderr, "%s: cannot create %s\n", progname, codename);
	 fatalerrs++;
	 continue;
	 }
      globfile = fopen(globname, "w");
      if (globfile == NULL) {
	 fprintf(stderr, "%s: cannot create %s\n", progname, globname);
	 fatalerrs++;
	 continue;
	 }

      /*
       * ucode serial number
       */
      writecheck(fprintf(globfile,"version\t%s\n",UVersion));
#endif					/* VarTran */
      tok_loc.n_file = *filep;
      inline = 1;
      meminit();	/* Initialize data structures */

      yyparse();	/* Parse the input */

#ifdef DeBug
      gdump();
#endif					/* DeBug */

      /*
       * Close the input file and the .u1 and .u2 files.
       */
      if (!mflag) 
         fclose(infile);

/*
 * The following code is operating-system dependent.  This code closes
 *  the pipe for the preprocessor if processing was done.
 */

#if PORT
   /* nothing to do */
#endif					/* PORT */

#if AMIGA || ATARI_ST || MACINTOSH || MSDOS || VMS
   /* nothing to do */
#endif					/* AMIGA || ATARI_ST || MACINTOSH ... */

#if UNIX
      else {
	 if (pclose(infile) != 0) {
	    fprintf(stderr, "%s: m4 terminated abnormally\n", progname);
	    fatalerrs++;
	    }
	 }
#endif					/* UNIX */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

#ifndef VarTran
      if (fclose(codefile) != 0 || fclose(globfile) != 0) {
         fprintf(stderr, "%s: unable to close ucode file\n", progname);
	 fatalerrs++;
         }
#endif					/* VarTran */
      }

   /*
    * Produce information about errors and warnings and be correct about it.
    */
   if (fatalerrs == 1)
      fprintf(stderr, "1 error; ");
   else if (fatalerrs > 1)
      fprintf(stderr, "%d errors; ", fatalerrs);
   else if (!silence)
      fprintf(stderr, "No errors; ");
   if (warnings == 1)
      fprintf(stderr, "1 warning\n");
   else if (warnings > 1)
      fprintf(stderr, "%d warnings\n", warnings);
   else if (!silence)
      fprintf(stderr, "no warnings\n");
   else if (fatalerrs > 0)
      fprintf(stderr, "\n");
   if (fatalerrs > 0)
      exit(ErrorExit);
#ifdef TranStats
   tokdump();
#endif					/* TranStats */
   exit(NormalExit);
   }

#ifndef VarTran
/*
 * maknam - makes a file name from prefix and suffix.
 *
 * Uses only the last file specification if name is a path,
 * replaces suffix of name with suffix argument.
 */

maknam(dest, name, suffix)
char *dest, *name, *suffix;
   {
   register char *d, *pre, *suf;
   char *mark;

   d = dest;
   pre = name;
   suf = suffix;
   mark = pre;
   while (*pre) 		/* find last delimiter */

/*
 * The following code is operating-system dependent. Find the last path
 *  delimiter.
 */

#if PORT
   /* some test of *pre is needed for special characters in path names */
#endif					/* PORT */

#if AMIGA
      if (*pre == ':' || *pre == '/')
         mark = ++pre;
      else
         ++pre;
#endif					/* AMIGA */

#if MACINTOSH
#if MPW
      if (*pre++ == ':')
         mark = pre;
#endif					/* MPW */
#endif					/* MACINTOSH */

#if ATARI_ST || MSDOS
      if (*pre == ':' || *pre == '/' || *pre == '\\')
	 mark = ++pre;
      else
	 ++pre;
#endif					/* ATARI_ST || MSDOS */

#if UNIX
      if (*pre++ == '/')
	 mark = pre;
#endif					/* UNIX */

#if VMS
      if (*pre == ']'  ||  *pre == ':' )
	 mark = ++pre;
      else
	 ++pre;
#endif					/* VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   pre = mark;
   mark = 0;
   while (*d = *pre++)		/* copy from last slash into dest */
      if (*d++ == '.')          /*   look for last dot, too */
	 mark = d - 1;
   if (mark)			/* if no dot, just append suffix */
      d = mark;
   while (*d++ = *suf++) ;	/* copy suffix into dest */
   }
#endif					/* VarTran */

writecheck(rc)
   {
   if (rc == EOF) {
      fprintf(stderr, "itran: unable to write to icode file\n");
      exit(ErrorExit);
      }
   }
