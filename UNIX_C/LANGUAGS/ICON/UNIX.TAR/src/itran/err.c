/*
 * Routines for producing error messages.
 */

#include "itran.h"
#include "token.h"
#include "tree.h"
#include "lex.h"

struct errmsg {
   int	e_state;		/* parser state number */
   char *e_mesg;		/* message text */
   } errtab[] = {
/*
 * Initialization of table that maps error states to messages.
 */

     1, "end of file expected",
     2, "global, record, or procedure declaration expected",
    11, "missing semicolon",
    13, "link list expected",
    15, "global, record, or procedure declaration expected",
    16, "missing record name",
    19, "invalid global declaration",
    24, "missing procedure name",
    26, "missing field list in record declaration",
    28, "missing end",
    29, "missing semicolon or operator",
    44, "invalid operand for unary operator",
    45, "invalid operand for unary operator",
    46, "invalid operand for unary operator",
    47, "invalid operand for unary operator",
    48, "invalid operand for unary operator",
    49, "invalid operand for unary operator",
    50, "invalid operand for unary operator",
    51, "invalid operand for unary operator",
    52, "invalid operand for unary operator",
    53, "invalid operand for unary operator",
    54, "invalid operand for unary operator",
    55, "invalid operand for unary operator",
    56, "invalid operand for unary operator",
    57, "invalid operand for unary operator",
    58, "invalid operand for unary operator",
    59, "invalid operand for unary operator",
    60, "invalid operand for unary operator",
    61, "invalid operand for unary operator",
    62, "invalid operand for unary operator",
    63, "invalid operand for unary operator",
    64, "invalid operand for unary operator",
    65, "invalid operand for unary operator",
    66, "invalid operand for unary operator",
    67, "invalid operand for unary operator",
    77, "invalid create expression",
    84, "invalid keyword construction",
    92, "invalid if control expression",
    93, "invalid case control expression",
    94, "invalid while control expression",
    95, "invalid until control expression",
    96, "invalid every control expression",
    97, "invalid repeat expression",
   100, "missing link file name",
   101, "missing parameter list in procedure declaration",
   104, "invalid local declaration",
   105, "invalid initial expression",
   111, "invalid operand",
   112, "invalid operand",
   113, "invalid operand in assignment",
   114, "invalid operand in assignment",
   115, "invalid operand in assignment",
   116, "invalid operand in assignment",
   117, "invalid operand in augmented assignment",
   118, "invalid operand in augmented assignment",
   119, "invalid operand in augmented assignment",
   120, "invalid operand in augmented assignment",
   121, "invalid operand in augmented assignment",
   122, "invalid operand in augmented assignment",
   123, "invalid operand in augmented assignment",
   124, "invalid operand in augmented assignment",
   125, "invalid operand in augmented assignment",
   126, "invalid operand in augmented assignment",
   127, "invalid operand in augmented assignment",
   128, "invalid operand in augmented assignment",
   129, "invalid operand in augmented assignment",
   130, "invalid operand in augmented assignment",
   131, "invalid operand in augmented assignment",
   132, "invalid operand in augmented assignment",
   133, "invalid operand in augmented assignment",
   134, "invalid operand in augmented assignment",
   135, "invalid operand in augmented assignment",
   136, "invalid operand in augmented assignment",
   137, "invalid operand in augmented assignment",
   138, "invalid operand in augmented assignment",
   139, "invalid operand in augmented assignment",
   140, "invalid operand in augmented assignment",
   141, "invalid operand in augmented assignment",
   142, "invalid operand in augmented assignment",
   143, "invalid operand in augmented assignment",
   144, "invalid operand in augmented assignment",
   145, "invalid to clause",
   146, "invalid operand in alternation",
   147, "invalid operand",
   148, "invalid operand",
   149, "invalid operand",
   150, "invalid operand",
   151, "invalid operand",
   152, "invalid operand",
   153, "invalid operand",
   154, "invalid operand",
   155, "invalid operand",
   156, "invalid operand",
   157, "invalid operand",
   158, "invalid operand",
   159, "invalid operand",
   160, "invalid operand",
   161, "invalid operand",
   162, "invalid operand",
   163, "invalid operand",
   164, "invalid operand",
   165, "invalid operand",
   166, "invalid operand",
   167, "invalid operand",
   168, "invalid operand",
   169, "invalid operand",
   170, "invalid operand",
   171, "invalid operand",
   172, "invalid operand",
   173, "invalid operand",
   177, "invalid field name",
   204, "missing right parenthesis",
   206, "missing right brace",
   208, "missing right bracket",
   214, "missing then",
   215, "missing of",
   220, "missing identifier",
   223, "missing right parenthesis",
   225, "missing end",
   226, "invalid declaration",
   227, "missing semicolon or operator",
   292, "missing right bracket",
   295, "missing right brace",
   297, "missing right parenthesis",
   304, "invalid do clause",
   305, "invalid then clause",
   306, "missing left brace",
   307, "invalid do clause",
   308, "invalid do clause",
   309, "invalid do clause",
   311, "invalid argument list",
   317, "invalid by clause",
   319, "invalid section",
   330, "invalid case clause",
   335, "missing right bracket",
   337, "missing right bracket or ampersand",
   339, "invalid else clause",
   340, "missing right brace or semicolon",
   342, "missing colon",
   343, "missing colon or ampersand",
   348, "invalid case clause",
   349, "invalid default clause",
   350, "invalid case clause",
    -1,  "syntax error"
   };

/*
 * yyerror produces syntax error messages.  tok is the offending token
 *  (yychar), lval is yylval, and state is the parser's state.
 *
 * errtab is searched for the state, if it is found, the associated
 *  message is produced; if the state isn't found, "syntax error"
 *  is produced.
 */
yyerror(tok, lval, state)
int tok, state;
nodeptr lval;
   {
   register struct errmsg *p;
   char *mapterm();

   if (tok_loc.n_file)
      fprintf(stderr, "File %s; ", tok_loc.n_file);
   if (tok == EOFX)   /* special case end of file */
      fprintf(stderr, "unexpected end of file\n");
   else {
      fprintf(stderr, "Line %d # ", Line(lval));
      if (Col(lval))
         fprintf(stderr, "\"%s\": ", mapterm(tok,lval));
      for (p = errtab; p->e_state != state && p->e_state >= 0; p++) ;
      fprintf(stderr, "%s\n", p->e_mesg);
      }
   fatalerrs++;
   nocode++;
   }
/*
 * err produces the error messages s1 and s2 (if nonnull).  The
 *  location of the error is found in tok_loc.
 */
err(s1, s2)
char *s1, *s2;
   {
   if (tok_loc.n_file)
      fprintf(stderr, "File %s; ", tok_loc.n_file);
   fprintf(stderr, "Line %d # ", tok_loc.n_line);
   if (s2)
      fprintf(stderr, "\"%s\": ", s2);
   fprintf(stderr, "%s\n", s1);
   fatalerrs++;
   nocode++;
   }

/*
 * lerr produces the error message s and associates it with source location
 *  of node.
 */
lerr(n, s)
nodeptr n;
char *s;
   {
   fprintf(stderr, "File %s; ", File(n));
   fprintf(stderr, "Line %d # ", Line(n));
   fprintf(stderr, "%s\n", s);
   fatalerrs++;
   nocode++;
   }

/*
 * warn produces s1 and s2 (if nonnull) as warning messages.  The
 *  location of the error is found in tok_loc.
 */
warn(s1, s2)
char *s1, *s2;
   {
   if (tok_loc.n_file)
      fprintf(stderr, "File %s; ", tok_loc.n_file);
   fprintf(stderr, "Line %d # ", tok_loc.n_line);
   if (s2)
      fprintf(stderr, "\"%s\": ", s2);
   fprintf(stderr, "%s\n", s1);
   warnings++;
   }

/*
 * syserr is called for fatal errors.  The message s is produced and the
 *  translator exits.
 */
syserr(s)
char *s;
   {
   if (tok_loc.n_file)
      fprintf(stderr, "FIle %s; ", tok_loc.n_file);
   fprintf(stderr, "Line %d # %s\n", inline, s);
   exit(ErrorExit);
   }

/*
 * mapterm finds a printable string for the given token type
 *  and value.
 */
char *mapterm(typ,val)
int typ;
nodeptr val;
   {
   register struct toktab *t;
   register int i;

   i = typ;
   if (i == IDENT || i == INTLIT || i == REALLIT || i == STRINGLIT ||
      i == CSETLIT)
         return Str0(val);
   for (t = toktab; t->t_type != i; t++)
      if (t->t_type == 0)
         return "???";
   return (t->t_word);
   }
