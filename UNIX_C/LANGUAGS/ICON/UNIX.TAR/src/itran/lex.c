/*
 * The lexical analyzer.
 */

#include "itran.h"
#include "token.h"
#include "lex.h"
#include "tree.h"
#include <ctype.h>

extern char *putident();

#define isletter(s)	(isupper(c) | islower(c))

#ifndef EBCDIC
#define tonum(c)	(isdigit(c) ? (c - '0') : ((c & 037) + 9))
#else					/* EBCDIC */
   /*
    *  The following needs to be fixed for EBCDIC to handle letters for
    *	radix literals.  Right now it treats them as zero.
    */
#define tonum(c)	(isdigit(c) ? (c - '0') : '0')
#endif					/* EBCDIC */

#ifndef EBCDIC
/*
 * esctab - translates single-character escapes in string literals.
 */

char esctab[] = {
   000,   001,	 002,	003,   004,   005,   006,   007,   /* NUL-BEL */
   010,   011,	 012,	013,   014,   015,   016,   017,   /* BS -SI */
   020,   021,	 022,	023,   024,   025,   026,   027,   /* DLE-ETB */
   030,   031,	 032,	033,   034,   035,   036,   037,   /* CAN-US */
   ' ',   '!',   '"',   '#',   '$',   '%',   '&',   '\'',  /* !"#$%&' */
   '(',   ')',   '*',   '+',   ',',   '-',   '.',   '/',   /* ()*+,-./ */
   000,   001,	 002,	003,   004,   005,   006,   007,   /* 01234567 */
   010,   011,	 ':',   ';',   '<',   '=',   '>',   '?',   /* 89:;<=>? */
   '@',   'A',   '\b',  'C',   0177,  033,   014,   'G',   /* @ABCDEFG */
   'H',   'I',   'J',   'K',   '\n',  'M',  '\n',   'O',   /* HIJKLMNO */
   'P',   'Q',   '\r',  'S',   '\t',  'U',   013,   'W',   /* PQRSTUVW */
   'X',   'Y',   'Z',   '[',   '\\',  ']',   '^',   '_',   /* XYZ[\]^_ */
   '`',   'a',   '\b',  'c',   0177,  033,   014,   'g',   /* `abcdefg */
   'h',   'i',   'j',   'k',   '\n',  'm',   '\n',  'o',   /* hijklmno */
   'p',   'q',   '\r',  's',   '\t',  'u',   013,   'w',   /* pqrstuvw */
   'x',   'y',   'z',   '{',   '|',   '}',   '~',   0177,  /* xyz{|}~ */
   0200,  0201,  0202,	0203,  0204,  0205,  0206,  0207,
   0210,  0211,  0212,	0213,  0214,  0215,  0216,  0217,
   0220,  0221,  0222,	0223,  0224,  0225,  0226,  0227,
   0230,  0231,  0232,	0233,  0234,  0235,  0236,  0237,
   0240,  0241,  0242,	0243,  0244,  0245,  0246,  0247,
   0250,  0251,  0252,	0253,  0254,  0255,  0256,  0257,
   0260,  0261,  0262,	0263,  0264,  0265,  0266,  0267,
   0270,  0271,  0272,	0273,  0274,  0275,  0276,  0277,
   0300,  0301,  0302,	0303,  0304,  0305,  0306,  0307,
   0310,  0311,  0312,	0313,  0314,  0315,  0316,  0317,
   0320,  0321,  0322,	0323,  0324,  0325,  0326,  0327,
   0330,  0331,  0332,	0333,  0334,  0335,  0336,  0337,
   0340,  0341,  0342,	0343,  0344,  0345,  0346,  0347,
   0350,  0351,  0352,	0353,  0354,  0355,  0356,  0357,
   0360,  0361,  0362,	0363,  0364,  0365,  0366,  0367,
   0370,  0371,  0372,	0373,  0374,  0375,  0376,  0377,
  };
#else					/* EBCDIC */
/*
 *  This is the EBCDIC table for handling escapes.  It needs filling
 *   in, using the ASCII one above as a model.
 */
char esctab[] = {
   0x00,  0x01,  0x02,	0x03,  0x04,  0x05,  0x06,  0x07,
   0x08,  0x09,  0x0a,	0x0b,  0x0c,  0x0d,  0x0e,  0x0f,
   0x10,  0x11,  0x12,	0x13,  0x14,  0x15,  0x16,  0x17,
   0x18,  0x19,  0x1a,	0x1b,  0x1c,  0x1d,  0x1e,  0x1f,
   0x20,  0x21,  0x22,	0x23,  0x24,  0x25,  0x26,  0x27,
   0x28,  0x29,  0x2a,	0x2b,  0x2c,  0x2d,  0x2e,  0x2f,
   0x30,  0x31,  0x32,	0x33,  0x34,  0x35,  0x36,  0x37,
   0x38,  0x39,  0x3a,	0x3b,  0x3c,  0x3d,  0x3e,  0x3f,
   0x40,  0x41,  0x42,	0x43,  0x44,  0x45,  0x46,  0x47,
   0x48,  0x49,  0x4a,	0x4b,  0x4c,  0x4d,  0x4e,  0x4f,
   0x50,  0x51,  0x52,	0x53,  0x54,  0x55,  0x56,  0x57,
   0x58,  0x59,  0x5a,	0x5b,  0x5c,  0x5d,  0x5e,  0x5f,
   0x60,  0x61,  0x62,	0x63,  0x64,  0x65,  0x66,  0x67,
   0x68,  0x69,  0x6a,	0x6b,  0x6c,  0x6d,  0x6e,  0x6f,
   0x70,  0x71,  0x72,	0x73,  0x74,  0x75,  0x76,  0x77,
   0x78,  0x79,  0x7a,	0x7b,  0x7c,  0x7d,  0x7e,  0x7f,
   0x80,  0x81,  0x82,	0x83,  0x84,  0x85,  0x86,  0x87,
   0x88,  0x89,  0x8a,	0x8b,  0x8c,  0x8d,  0x8e,  0x8f,
   0x90,  0x91,  0x92,	0x93,  0x94,  0x95,  0x96,  0x97,
   0x98,  0x99,  0x9a,	0x9b,  0x9c,  0x9d,  0x9e,  0x9f,
   0xa0,  0xa1,  0xa2,	0xa3,  0xa4,  0xa5,  0xa6,  0xa7,
   0xa8,  0xa9,  0xaa,	0xab,  0xac,  0xad,  0xae,  0xaf,
   0xb0,  0xb1,  0xb2,	0xb3,  0xb4,  0xb5,  0xb6,  0xb7,
   0xb8,  0xb9,  0xba,	0xbb,  0xbc,  0xbd,  0xbe,  0xbf,
   0xc0,  0xc1,  0xc2,	0xc3,  0xc4,  0xc5,  0xc6,  0xc7,
   0xc8,  0xc9,  0xca,	0xcb,  0xcc,  0xcd,  0xce,  0xcf,
   0xd0,  0xd1,  0xd2,	0xd3,  0xd4,  0xd5,  0xd6,  0xd7,
   0xd8,  0xd9,  0xda,	0xdb,  0xdc,  0xdd,  0xde,  0xdf,
   0xe0,  0xe1,  0xe2,	0xe3,  0xe4,  0xe5,  0xe6,  0xe7,
   0xe8,  0xe9,  0xea,	0xeb,  0xec,  0xed,  0xee,  0xef,
   0xf0,  0xf1,  0xf2,	0xf3,  0xf4,  0xf5,  0xf6,  0xf7,
   0xf8,  0xf9,  0xfa,	0xfb,  0xfc,  0xfd,  0xfe,  0xff,
   };
#endif					/* EBCDIC */

struct node tok_loc =
   {0, NULL, 0, 0};	/* "model" node containing location of current token */

/*
 * yylex - find the next token in the input stream, and return its token
 *  type and value to the parser.
 *
 * Variables of interest:
 *
 *  cc - character following last token.
 *  comflag - set if in a comment.
 *  nlflag - set if a newline was between the last token and the current token
 *  lastend - set if the last token was an Ender.
 *  lastval - when a semicolon is inserted and returned, lastval gets the
 *   token value that would have been returned if the semicolon hadn't
 *   been inserted.
 */

yylex()
   {
   register struct toktab *t;
   register int c;
   int nlflag;
   int comflag;
   static struct toktab *lasttok = NULL;
   static nodeptr lastval;
   static int lastend = 0;
   static int eofflag = 0;
   static struct node semi_loc;
   static int cc = '\n';
   extern struct toktab *getident(), *getnum(), *getstring(), *getop();
   extern char setlineno(), setfilenm();

   if (lasttok != NULL) {
      /*
       * A semicolon was inserted and returned on the last call to yylex,
       *  instead of going to the input, return lasttok and set the
       *  appropriate variables.
       */
      yylval = lastval;
      tok_loc = *lastval;
      t = lasttok;
      goto ret;
      }
   nlflag = 0;
   comflag = 0;
loop:
   c = cc;
   /*
    * Remember where a semicolon will go if we insert one.
    */
   semi_loc.n_file = tok_loc.n_file;
   semi_loc.n_line = inline;
   semi_loc.n_col = incol;
   /*
    * Skip whitespace and comments and process $line directives.
    */
   while (c != EOF && (comflag || c == Comment || isspace(c))) {
      if (c == '\n') {
	 nlflag++;
	 comflag = 0;
	 c = NextChar;
	 if (c == '$') {
	    /*
	     * Set line number in case an error is found in $line directive.
	     */
	    tok_loc.n_line = inline;
	    if (('l' == NextChar) &&
		('i' == NextChar) &&
		('n' == NextChar) &&
		('e' == NextChar)) {
	       c = setlineno();
	       if (c != EOF && c != '\n')
		  c = setfilenm(c);
	       }
	    else {
	       err("$line expected", "");
	       while (c != EOF && !isspace(c))
		  c = NextChar;
	       }
	    }
	 }
      else {
	 if (c == Comment)
	    comflag++;
	 c = NextChar;
	 }
      }
   /*
    * A token is the next thing in the input.  Set token location to
    *  the current line and column.
    */
   tok_loc.n_line = inline;
   tok_loc.n_col = incol;

   if (c == EOF) {
      /*
       * End of file has been reached.	Set eofflag, return T_Eof, and
       *  set cc to EOF so that any subsequent scans also return T_Eof.
       */
      if (eofflag++) {
	 eofflag = 0;
	 cc = '\n';
	 yylval = NULL;
	 return 0;
	 }
      cc = EOF;
      t = T_Eof;
      yylval = NULL;
      goto ret;
      }

   /*
    * Look at current input character to determine what class of token
    *  is next and take the appropriate action.  Note that the various
    *  token gathering routines write a value into cc.
    */
   if (isalpha(c) || (c == '_')) {   /* gather ident or reserved word */
      if ((t = getident(c, &cc)) == NULL)
	 goto loop;
      }
   else if (isdigit(c)) {		/* gather numeric literal */
      if ((t = getnum(c, &cc)) == NULL)
	 goto loop;
      }
   else if (c == '"' || c == '\'') {    /* gather string or cset literal */
      if ((t = getstring(c, &cc)) == NULL)
	 goto loop;
      }
   else {			/* gather longest legal operator */
      if ((t = getop(c, &cc)) == NULL)
	 goto loop;
      yylval = OpNode(t->t_type);
      }
   if (nlflag && lastend && (t->t_flags & Beginner)) {
      /*
       * A newline was encountered between the current token and the last,
       *  the last token was an Ender, and the current token is a Beginner.
       *  Return a semicolon and save the current token in lastval.
       */
      lastval = yylval;
      lasttok = t;
      tok_loc = semi_loc;
      yylval = OpNode(SEMICOL);
      return SEMICOL;
      }
ret:
   /*
    * Clear lasttok, set lastend if the token being returned is an
    *  Ender, and return the token.
    */
   lasttok = 0;
   lastend = t->t_flags & Ender;
   return (t->t_type);
   }

/*
 * getident - gather an identifier beginning with ac.  The character
 *  following identifier goes in cc.
 */

struct toktab *getident(ac, cc)
char ac;
int *cc;
   {
   register int c;
   register char *p;
   register struct toktab *t;
   extern struct toktab *findres();

   c = ac;
   p = strfree;
   /*
    * Copy characters into string space until a non-alphanumeric character
    *  is found.
    */
   do {
      if (p >= strend)
	 syserr("out of string space");
      *p++ = c;
      c = NextChar;
      } while (isalnum(c) || (c == '_'));
   if (p >= strend)
      syserr("out of string space");
   *p++ = 0;
   *cc = c;
   /*
    * If the identifier is a reserved word, make a ResNode for it and return
    *  the token value.  Otherwise, install it with putident, make an
    *  IdNode for it, and return.
    */
   if ((t = findres()) != NULL) {
      yylval = ResNode(t->t_type);
      return t;
      }
   else {
      yylval = IdNode(putident(p-strfree));
      return T_Ident;
      }
   }

/*
 * findres - if the string just copied into the string space by getident
 *  is a reserved word, return a pointer to its entry in the token table.
 *  Return NULL if the string isn't a reserved word.
 */

struct toktab *findres()
   {
   register struct toktab *t;
   register char c, *p;

   p = strfree;
   c = *p;
   if (!islower(c))
      return NULL;
   /*
    * Point t at first reserved word that starts with c (if any).
    */
   if ((t = restab[c - 'a']) == NULL)
      return NULL;
   /*
    * Search through reserved words, stopping when a match is found
    *  or when the current reserved word doesn't start with c.
    */
   while (t->t_word[0] == c) {
      if (strcmp(t->t_word, p) == 0)
	 return t;
      t++;
      }
   return NULL;
   }

/*
 * getnum - gather a numeric literal starting with ac and put the
 *  character following the literal into *cc.
 */

struct toktab *getnum(ac, cc)
char ac;
int *cc;
   {
   register int c, r, state;
   char *p;
   int realflag;

   c = ac;
   r = tonum(c);
   p = strfree;
   state = 0;
   realflag = 0;
   for (;;) {
      if (p >= strend)
	 syserr("out of string space");
      *p++ = c;
      c = NextChar;
      switch (state) {
	 case 0:		/* integer part */
	    if (isdigit(c))	    { r = r * 10 + tonum(c); continue; }
	    if (c == '.')           { state = 1; realflag++; continue; }
	    if (c == 'e' || c == 'E')  { state = 2; realflag++; continue; }
	    if (c == 'r' || c == 'R')  {
	       state = 5;
	       if (r < 2 || r > 36)
		  err("invalid radix for integer literal", "");
	       continue;
	       }
	    break;
	 case 1:		/* fractional part */
	    if (isdigit(c))   continue;
	    if (c == 'e' || c == 'E')   { state = 2; continue; }
	    break;
	 case 2:		/* optional exponent sign */
	    if (c == '+' || c == '-') { state = 3; continue; }
	 case 3:		/* first digit after e, e+, or e- */
	    if (isdigit(c)) { state = 4; continue; }
	    err("invalid real literal", "");
	    break;
	 case 4:		/* remaining digits after e */
	    if (isdigit(c))   continue;
	    break;
	 case 5:		/* first digit after r */
	    if ((isdigit(c) || isletter(c)) && tonum(c) < r)
	       { state = 6; continue; }
	    err("invalid integer literal", "");
	    break;
	 case 6:		/* remaining digits after r */
	    if (isdigit(c) || isletter(c)) {
	       if (tonum(c) >= r) {	/* illegal digit for radix r */
		  err("invalid digit in integer literal", "");
		  r = tonum('z');       /* prevent more messages */
		  }
	       continue;
	       }
	    break;
	 }
      break;
      }
   if (p >= strend)
      syserr("out of string space");
   *p++ = 0;
   *cc = c;
   if (realflag) {
      yylval = RealNode(putident(p-strfree));
      return T_Real;
      }
   yylval = IntNode(putident(p-strfree));
   return T_Int;
   }

/*
 * getstring - gather a string literal starting with ac and place the
 *  character following the literal in *cc.
 */

struct toktab *getstring(ac, cc)
char ac;
int *cc;
   {
   register int c, sc;
   register char *p;
   char *lc;
   int len;

   sc = c = ac;
   p = strfree;
   lc = 0;
   while ((c = NextChar) != sc && c != '\n' && c != EOF) {
   contin:
      if (c == '_')
	 lc = p;
      else if (!isspace(c))
	 lc = 0;
      if (c == Escape) {
	 c = NextChar;
#ifdef VarTran
	 *p++ = Escape;
#else					/* VarTran */
	 if (isoctal(c))
	    c = octesc(c);
	 else if (c == 'x')
	    c = hexesc();
	 else if (c == '^')
	    c = ctlesc();
	 else
	    c = esctab[c];
#endif					/* VarTran */
	 if (c == EOF)
	    goto noquote;
	 }
      if (p >= strend)
	 syserr("out of string space");
      *p++ = c;
      }
   if (p >= strend)
      syserr("out of string space");
   *p++ = 0;
   if (c == sc)
      *cc = ' ';
   else {
      if (c == '\n' && lc) {
	 p = lc;
	 while ((c = NextChar) != EOF && isspace(c)) ;
	 if (c != EOF)
	    goto contin;
	 }
noquote:
      err("unclosed quote", "");
      *cc = c;
      }
   if (ac == '"') {     /* a string literal */
      len = p - strfree;
      yylval = StrNode(putident(len), len);
      return T_String;
      }
   else {		/* a cset literal */
      len = p - strfree;
      yylval = CsetNode(putident(len), len);
      return T_Cset;
      }
   }

#ifndef VarTran

/*
 * ctlesc - translate a control escape -- backslash followed by
 *  caret and one character.
 */

ctlesc()
   {
   register int c;

   c = NextChar;
   if (c == EOF)
      return EOF;
   return (c & 037);
   }

/*
 * octesc - translate an octal escape -- backslash followed by
 *  one, two, or three octal digits.
 */

octesc(ac)
char ac;
   {
   register int c, nc, i;

   c = 0;
   nc = ac;
   i = 1;
   do {
      c = (c << 3) | (nc - '0');
      nc = NextChar;
      if (nc == EOF)
	 return EOF;
      } while (isoctal(nc) && i++ < 3);
   PushChar(nc);
   return (c & 0377);
   }

/*
 * hexesc - translate a hexadecimal escape -- backslash-x
 *  followed by one or two hexadecimal digits.
 */

hexesc()
   {
   register int c, nc, i;

   c = 0;
   i = 0;
   while (i++ < 2) {
      nc = NextChar;
      if (nc == EOF)
	 return EOF;
      if (nc >= 'a' && nc <= 'f')
	 nc -= 'a' - 10;
      else if (nc >= 'A' && nc <= 'F')
	 nc -= 'A' - 10;
      else if (isdigit(nc))
	 nc -= '0';
      else {
	 PushChar(nc);
	 break;
	 }
      c = (c << 4) | nc;
      }
   return c;
   }

#endif					/* VarTran */

/*
 * getop - find the longest legal operator and return a pointer
 *  to its entry in the token table.
 */

struct toktab *getop(ac, cc)
char ac;
int *cc;
   {
   register struct optab *state;
   register char c, i;

   state = state0;
   c = ac;
   for (;;) {
      while ((i = state->o_input) && c != i)
	 state++;
      switch (state->o_action) {
	 case A_Goto:
	    state = (struct optab *) state->o_val;
	    c = NextChar;
	    continue;
	 case A_Error:
	    err("invalid character", "");
	    *cc = ' ';
	    return NULL;
	 case A_Return:
	    *cc = c;
	    return (struct toktab *) (state->o_val);
	 case A_Immret:
	    *cc = ' ';
	    return (struct toktab *) (state->o_val);
	 }
      }
   }

/*
 * setlineno - set line number from $line directive, return following char.
 */

char setlineno()
   {
   register c;

   while ((c = NextChar) == ' ' || c == '\t')
      ;
   if (c < '0' || c > '9') {
      err("no line number in $line directive", "");
      while (c != EOF && c != '\n')
	 c = NextChar;
      return c;
      }
   inline = 0;
   while (c >= '0' && c <= '9') {
      inline = inline * 10 + (c - '0');
      c = NextChar;
      }
   return c;
   }

/*
 * setfilenm -	set file name from $line directive, return following char.
 */

char setfilenm(c)
register int c;
   {
   register char *p;

   while (c == ' ' || c == '\t')
      c = NextChar;
   if (c != '"') {
      err("'\"' missing from file name in $line directive", "");
      while (c != EOF && c != '\n')
	 c = NextChar;
      return c;
      }
   p = strfree;
   while ((c = NextChar) != '"' && c != EOF && c != '\n') {
      if (p >= strend)
	 syserr("out of string space");
      *p++ = c;
      }
   *p++ = '\0';
   if (c == '"') {
      tok_loc.n_file = putident(p-strfree);
      return NextChar;
      }
   else {
      err("'\"' missing from file name in $line directive", "");
      return c;
      }
   }

/*
 * nextchar - return the next character in the input.
 */

nextchar()
   {
   register int c;

   if (c = peekc) {
      peekc = 0;
      return c;
      }
   c = getc(infile);
   switch (c) {
      case EOF:
	 if (incol) {
	    c = '\n';
	    inline++;
	    incol = 0;
	    peekc = EOF;
	    break;
	    }
	 else {
	    inline = 0;
	    incol = 0;
	    break;
	    }
      case '\n':
	 inline++;
	 incol = 0;
	 break;
      case '\t':
	 incol = (incol | 7) + 1;
	 break;
      case '\b':
	 if (incol)
	    incol--;
	 break;
      default:
	 incol++;
      }
   return c;
   }
