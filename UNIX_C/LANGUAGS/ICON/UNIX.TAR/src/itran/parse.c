# define CSETLIT 257
# define EOFX 258
# define IDENT 259
# define INTLIT 260
# define REALLIT 261
# define STRINGLIT 262
# define BREAK 263
# define BY 264
# define CASE 265
# define CREATE 266
# define DEFAULT 267
# define DO 268
# define DYNAMIC 269
# define ELSE 270
# define END 271
# define EVERY 272
# define FAIL 273
# define GLOBAL 274
# define IF 275
# define INITIAL 276
# define LINK 277
# define LOCAL 278
# define NEXT 279
# define NOT 280
# define OF 281
# define PROCEDURE 282
# define RECORD 283
# define REPEAT 284
# define RETURN 285
# define STATIC 286
# define SUSPEND 287
# define THEN 288
# define TO 289
# define UNTIL 290
# define WHILE 291
# define ASSIGN 292
# define AT 293
# define AUGACT 294
# define AUGAND 295
# define AUGEQ 296
# define AUGEQV 297
# define AUGGE 298
# define AUGGT 299
# define AUGLE 300
# define AUGLT 301
# define AUGNE 302
# define AUGNEQV 303
# define AUGSEQ 304
# define AUGSGE 305
# define AUGSGT 306
# define AUGSLE 307
# define AUGSLT 308
# define AUGSNE 309
# define BACKSLASH 310
# define BANG 311
# define BAR 312
# define CARET 313
# define CARETASGN 314
# define COLON 315
# define COMMA 316
# define CONCAT 317
# define CONCATASGN 318
# define CONJUNC 319
# define DIFF 320
# define DIFFASGN 321
# define DOT 322
# define EQUIV 323
# define INTER 324
# define INTERASGN 325
# define LBRACE 326
# define LBRACK 327
# define LCONCAT 328
# define LCONCATASGN 329
# define LEXEQ 330
# define LEXGE 331
# define LEXGT 332
# define LEXLE 333
# define LEXLT 334
# define LEXNE 335
# define LPAREN 336
# define MCOLON 337
# define MINUS 338
# define MINUSASGN 339
# define MOD 340
# define MODASGN 341
# define NOTEQUIV 342
# define NUMEQ 343
# define NUMGE 344
# define NUMGT 345
# define NUMLE 346
# define NUMLT 347
# define NUMNE 348
# define PCOLON 349
# define PLUS 350
# define PLUSASGN 351
# define QMARK 352
# define RBRACE 353
# define RBRACK 354
# define REVASSIGN 355
# define REVSWAP 356
# define RPAREN 357
# define SCANASGN 358
# define SEMICOL 359
# define SLASH 360
# define SLASHASGN 361
# define STAR 362
# define STARASGN 363
# define SWAP 364
# define TILDE 365
# define UNION 366
# define UNIONASGN 367

# line 135 "expanded.g"
#include "itran.h"
#include "sym.h"
#include "tree.h"
#include "../h/keyword.h"
#define YYSTYPE nodeptr
#define YYMAXDEPTH 500

int idflag;
int key_num;



#define yyclearin yychar = -1
#define yyerrok yyerrflag = 0
extern int yychar;
extern short yyerrflag;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif
#ifndef YYSTYPE
#define YYSTYPE int
#endif
YYSTYPE yylval, yyval;
# define YYERRCODE 256

# line 421 "expanded.g"

short yyexca[] ={
-1, 1,
	0, -1,
	-2, 0,
-1, 18,
	359, 36,
	-2, 34,
-1, 103,
	359, 36,
	-2, 34,
-1, 110,
	359, 36,
	-2, 34,
	};
# define YYNPROD 196
# define YYLAST 787
short yyact[]={

  32,  88, 164,  78,  85,  86,  87,  80, 220,  93,
  77, 342, 347, 111, 168, 302,  96,  89, 348,  92,
 166,  18, 110,  79,  45, 334, 313, 111,  97,  90,
 170,  91, 163, 344,  95,  94, 300,  44, 300, 318,
 300, 324, 301, 112, 330, 341, 222, 102, 165, 161,
 169, 315, 167, 316,  67,  50,  46,  55, 339, 111,
 162,  47, 345,  84,  51,  35,  49,  63,  56, 320,
  82,  83,  48, 111,  61, 309, 303, 325, 323,  62,
  81, 299,  58, 220, 177, 308,  66,  59, 175, 174,
 220, 322,  60, 350,  52, 306,  65, 111, 176, 307,
 305, 335, 304, 321,  54, 100,  53, 111, 349,  57,
  64,  32,  88, 206,  78,  85,  86,  87,  80, 314,
  93,  77, 109, 210,  17, 317, 111,  96,  89,  99,
  92, 111, 173, 111,  79,  45, 111, 209,  22,  97,
  90,  23,  91, 310, 298,  95,  94, 108,  44, 172,
 111, 101, 171, 111, 105,  26, 106,   3,  98,  38,
  31,  21,  28, 204, 107,  67,  50,  46,  55,   2,
  25, 319,  47,  15,  84,  51, 340,  49,  63,  56,
  39,  82,  83,  48, 295,  61,  12,  76,  75,  13,
  62,  81,  74,  58,  14,  10,  73,  66,  59,  72,
  71,  70,  40,  60,  69,  52,  68,  65, 294,  43,
  41, 263, 264,  36,  34,  54, 104,  53,   4, 311,
  57,  64,  32,  88,  24,  78,  85,  86,  87,  80,
 103,  93,  77,  27,  12,  11, 223,  13,  96,  89,
  16,  92,  14,  10,  19,  79,  45, 208,  20,   9,
  97,  90,   8,  91,   7,   6,  95,  94,   5,  44,
   1, 224, 221, 226,   0,   0, 225,   0,   0,   0,
   0,   0, 229, 228,   0,   0,  67,  50,  46,  55,
   0,   0,   0,  47,   0,  84,  51,   0,  49,  63,
  56,   0,  82,  83,  48,   0,  61,   0,   0,   0,
   0,  62,  81,   0,  58,   0,   0,   0,  66,  59,
   0,   0,   0,   0,  60,   0,  52,   0,  65,   0,
   0, 279, 280,   0,   0,   0,  54,   0,  53,   0,
   0,  57,  64,  88,   0,  78,  85,  86,  87,  80,
 297,  93,  77,   0, 281, 282, 283, 284,  96,  89,
   0,  92,   0,   0,   0,  79,  45,   0,   0,   0,
  97,  90,   0,  91,   0,   0,  95,  94,   0,  44,
 285, 286, 287, 288, 289,   0,   0,   0,   0,   0,
   0, 312,   0, 336,   0,   0,  67,  50,  46,  55,
  30,   0,   0,  47, 351,  84,  51,   0,  49,  63,
  56,   0,  82,  83,  48,   0,  61,   0,   0,   0,
   0,  62,  81,   0,  58,   0, 327,   0,  66,  59,
   0,   0,   0,   0,  60,   0,  52,   0,  65,   0,
   0,   0,   0,   0,   0,   0,  54,   0,  53,   0,
 145,  57,  64, 114,   0, 144, 143, 128, 129, 130,
 131, 132, 133, 134, 135, 136, 137, 138, 139, 140,
 141,  29,   0,   0,   0, 127,   0,   0, 202, 117,
   0,   0, 119,   0,   0,   0, 124,   0,   0,   0,
 118,   0, 213, 214, 215, 216, 217, 218, 219,  33,
 122,  37, 126,   0,   0,   0, 227,   0,   0,   0,
   0,   0, 121,   0,   0, 146, 116, 115,   0, 142,
   0,   0, 125,   0, 123, 113, 159,   0, 120,   0,
   0,   0,   0, 147, 148, 149, 150, 151, 152,  42,
   0,   0,   0,   0,   0, 160, 153, 154, 155, 156,
 157, 158, 203, 205, 207, 205,   0,   0,   0,   0,
   0,   0, 211, 212,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0, 293,   0,   0,   0,   0,
   0,   0,   0,   0, 178, 179, 180, 181, 182, 183,
 184, 185, 186, 187, 188, 189, 190, 191, 192, 193,
 194, 195, 196, 197, 198, 199, 200, 201,   0,   0,
   0,   0, 230, 231, 232, 233, 234, 235, 236, 237,
 238, 239, 240, 241, 242, 243, 244, 245, 246, 247,
 248, 249, 250, 251, 252, 253, 254, 255, 256, 257,
 258, 259, 260, 261, 262,   0, 292, 296, 205, 265,
 266, 267, 268, 269, 270, 271, 272, 273, 274, 275,
 276, 277, 278,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0, 328, 329,   0, 331, 332,
 333,   0, 290, 291,   0,   0,   0,   0,   0,   0,
 337,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0, 343,   0,   0,   0,   0,   0,   0,   0,   0,
 346,   0,   0,   0,   0,   0,   0,   0,   0, 343,
 352, 353,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0, 326,   0, 207,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0, 338 };
short yypact[]={

 -99,-1000, -40,-1000,-1000,-1000,-1000,-1000,-1000,-1000,
-1000,-235,-1000,-121,-1000, -88,-104,-1000, -34,-130,
-211,-1000,-1000,-1000,-108,-1000,-289,-122,-149,-337,
-260,-309,-1000,-1000, 151,-1000, 193,-268,-318,-310,
-1000,-161,-1000,-238,  76,  76,  76,  76,  76,  76,
  76,  76,  76,  76,  76,  76,  76,  76,  76,  76,
  76,  76,  76,  76,  76,  76,  76,  76,-1000,-1000,
-1000,-1000,-1000,-1000,-1000,-1000,-1000, -34,-1000,-1000,
 -34, -34, -34, -34,-136,-1000,-1000,-1000,-1000,-1000,
 -34, -34, -34, -34, -34, -34, -34, -34,-233,-1000,
-121,-290,-130, -34,-130, -34,-1000,-1000,-1000,-1000,
 -34,  76,  76,  76,  76,  76,  76,  76,  76,  76,
  76,  76,  76,  76,  76,  76,  76,  76,  76,  76,
  76,  76,  76,  76,  76,  76,  76,  76,  76,  76,
  76,  76,  76,  76,  76,  76,  76,  76,  76,  76,
  76,  76,  76,  76,  76,  76,  76,  76,  76,  76,
  76,  76,  76,  76,  76,  76,  76,  76,  76,  76,
  76,  76,  76,  76, -34,-145, -34,-115,-1000,-1000,
-1000,-1000,-1000,-1000,-1000,-1000,-1000,-1000,-1000,-1000,
-1000,-1000,-1000,-1000,-1000,-1000,-1000,-1000,-1000,-1000,
-1000,-1000,-260,-1000,-276,-1000,-311,-344,-278,-1000,
-1000,-1000,-1000,-166,-188,-186,-169,-183,-193,-260,
-116,-1000,-130,-331,-233,-152,-308,-306,-1000,-309,
-1000,-1000,-1000,-1000,-1000,-1000,-1000,-1000,-1000,-1000,
-1000,-1000,-1000,-1000,-1000,-1000,-1000,-1000,-1000,-1000,
-1000,-1000,-1000,-1000,-1000,-1000,-1000,-1000,-1000,-1000,
-1000,-1000,-1000,-139,-1000,-268,-268,-268,-268,-268,
-268,-268,-268,-268,-268,-268,-268,-268,-268,-318,
-318,-310,-310,-310,-310,-1000,-1000,-1000,-1000,-1000,
-1000,-1000,-315,-246,-1000,-275,-1000,-280,-1000,-1000,
 -34,-1000, -34,-1000, -34, -34,-282, -34, -34, -34,
-1000,-332,-226,-1000,-1000,-1000,-1000,  76,-1000, -34,
-1000,-1000,-1000,-1000, -34,-1000,-1000,-1000,-260,-212,
-256,-260,-260,-260,-1000,-321,-1000,-292,-1000, -34,
-341,-1000,-207,-222,-1000,-1000,-260,-1000,-256, -34,
 -34,-1000,-260,-260 };
short yypgo[]={

   0, 260, 169, 258, 255, 254, 252, 249, 248, 161,
 244, 158, 240, 236, 235, 233, 230, 162, 224, 219,
 216, 390, 461, 160, 489, 214,  65, 213, 491, 159,
 180, 202, 210, 529, 209, 206, 204, 201, 200, 199,
 196, 192, 188, 187, 163, 113, 184, 176,  45, 171 };
short yyr1[]={

   0,   1,   2,   2,   3,   3,   3,   3,   7,   8,
   8,   9,   9,  10,   6,  12,   4,  13,  13,   5,
  18,  14,  19,  19,  19,  11,  11,  15,  15,  20,
  20,  20,  16,  16,  17,  17,  22,  22,  21,  21,
  23,  23,  24,  24,  24,  24,  24,  24,  24,  24,
  24,  24,  24,  24,  24,  24,  24,  24,  24,  24,
  24,  24,  24,  24,  24,  24,  24,  24,  24,  24,
  24,  24,  24,  24,  24,  25,  25,  25,  26,  26,
  27,  27,  27,  27,  27,  27,  27,  27,  27,  27,
  27,  27,  27,  27,  27,  28,  28,  28,  29,  29,
  29,  29,  29,  30,  30,  30,  30,  30,  31,  31,
  32,  32,  32,  33,  33,  33,  33,  33,  33,  33,
  33,  33,  33,  33,  33,  33,  33,  33,  33,  33,
  33,  33,  33,  33,  33,  33,  33,  33,  34,  34,
  34,  34,  34,  34,  34,  34,  34,  34,  34,  34,
  34,  34,  34,  34,  34,  34,  34,  34,  34,  34,
  34,  40,  40,  41,  41,  42,  42,  43,  37,  37,
  37,  37,  38,  38,  39,  47,  47,  48,  48,  44,
  44,  46,  46,  35,  35,  35,  35,  36,  49,  49,
  49,  45,  45,   1,   5,  21 };
short yyr2[]={

   0,   2,   0,   2,   1,   1,   1,   1,   2,   1,
   3,   1,   1,   0,   3,   0,   6,   0,   1,   6,
   0,   6,   0,   1,   3,   1,   3,   0,   4,   1,
   1,   1,   0,   3,   0,   3,   0,   1,   1,   3,
   1,   3,   1,   3,   3,   3,   3,   3,   3,   3,
   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,
   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,
   3,   3,   3,   3,   3,   1,   3,   5,   1,   3,
   1,   3,   3,   3,   3,   3,   3,   3,   3,   3,
   3,   3,   3,   3,   3,   1,   3,   3,   1,   3,
   3,   3,   3,   1,   3,   3,   3,   3,   1,   3,
   1,   3,   3,   1,   2,   2,   2,   2,   2,   2,
   2,   2,   2,   2,   2,   2,   2,   2,   2,   2,
   2,   2,   2,   2,   2,   2,   2,   2,   1,   1,
   1,   1,   1,   1,   1,   1,   1,   2,   1,   1,
   2,   3,   3,   3,   4,   3,   4,   4,   3,   2,
   2,   2,   4,   2,   4,   2,   4,   2,   1,   2,
   2,   4,   4,   6,   6,   1,   3,   3,   3,   1,
   3,   1,   3,   1,   1,   1,   1,   6,   1,   1,
   1,   1,   3,   3,   4,   1 };
short yychk[]={

-1000,  -1,  -2, 256, 258,  -3,  -4,  -5,  -6,  -7,
 283, -14, 274, 277, 282,  -2, -12, 359, 256, -10,
  -8,  -9, 259, 262, -18, 258, 259, -15, -17, -22,
 -21, -23, 256, -24, -25, -26, -27, -28, -29, -30,
 -31, -32, -33, -34, 293, 280, 312, 317, 328, 322,
 311, 320, 350, 362, 360, 313, 324, 365, 338, 343,
 348, 330, 335, 323, 366, 352, 342, 310, -35, -36,
 -37, -38, -39, -40, -41, -42, -43, 266, 259, 279,
 263, 336, 326, 327, 319, 260, 261, 262, 257, 273,
 285, 287, 275, 265, 291, 290, 272, 284, -11, 259,
 316, 259, 336, -16, -20, 276, 278, 286, 269, 271,
 359, 319, 352, 364, 292, 356, 355, 318, 329, 321,
 367, 351, 339, 363, 325, 361, 341, 314, 296, 297,
 298, 299, 300, 301, 302, 303, 304, 305, 306, 307,
 308, 309, 358, 295, 294, 289, 312, 330, 331, 332,
 333, 334, 335, 343, 344, 345, 346, 347, 348, 323,
 342, 317, 328, 350, 320, 366, 338, 362, 324, 360,
 340, 313, 310, 293, 327, 326, 336, 322, -33, -33,
 -33, -33, -33, -33, -33, -33, -33, -33, -33, -33,
 -33, -33, -33, -33, -33, -33, -33, -33, -33, -33,
 -33, -33, -21, -22, -44, -22, -45, -22, -44, 273,
 259, -22, -22, -21, -21, -21, -21, -21, -21, -21,
 316,  -9, 336, -13, -11, -17, -11, -21, -17, -23,
 -24, -24, -24, -24, -24, -24, -24, -24, -24, -24,
 -24, -24, -24, -24, -24, -24, -24, -24, -24, -24,
 -24, -24, -24, -24, -24, -24, -24, -24, -24, -24,
 -24, -24, -24, -26, -26, -28, -28, -28, -28, -28,
 -28, -28, -28, -28, -28, -28, -28, -28, -28, -29,
 -29, -30, -30, -30, -30, -31, -31, -31, -31, -31,
 -33, -33, -22, -21, 353, -46, -22, -44, 259, 357,
 316, 353, 359, 354, 268, 288, 281, 268, 268, 268,
 259, -19, -11, 357, 271, 359, 359, 264, 354, -49,
 315, 349, 337, 353, 316, 357, -22, -45, -21, -21,
 326, -21, -21, -21, 357, 327, -26, -21, -22, 270,
 -47, -48, 267, -21, 354, 354, -21, 353, 359, 315,
 315, -48, -21, -21 };
short yydef[]={

   2,  -2,   0,   2,   1,   3,   4,   5,   6,   7,
  15,   0,  13,   0,  20,   0,   0,  27,  -2,   0,
   8,   9,  11,  12,   0, 193,   0,  32,   0,   0,
  37,  38, 195,  40,  42,  75,  78,  80,  95,  98,
 103, 108, 110, 113,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0, 138, 139,
 140, 141, 142, 143, 144, 145, 146,   0, 148, 149,
  36,  36,  36,  36,   0, 183, 184, 185, 186, 168,
  36,  36,   0,   0,   0,   0,   0,   0,  14,  25,
   0,   0,  17,  -2,   0,   0,  29,  30,  31, 194,
  -2,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,  36,  36,  36,   0, 114, 115,
 116, 117, 118, 119, 120, 121, 122, 123, 124, 125,
 126, 127, 128, 129, 130, 131, 132, 133, 134, 135,
 136, 137, 147, 150,   0, 179,   0, 191,   0, 159,
 160, 169, 170,  37,   0,   0, 161, 163, 165, 167,
   0,  10,  22,   0,  18,   0,   0,   0,  35,  39,
  41,  43,  44,  45,  46,  47,  48,  49,  50,  51,
  52,  53,  54,  55,  56,  57,  58,  59,  60,  61,
  62,  63,  64,  65,  66,  67,  68,  69,  70,  71,
  72,  73,  74,  76,  79,  81,  82,  83,  84,  85,
  86,  87,  88,  89,  90,  91,  92,  93,  94,  96,
  97,  99, 100, 101, 102, 104, 105, 106, 107, 109,
 111, 112,   0,  37, 155,   0, 181,   0, 158, 151,
  36, 152,  36, 153,   0,   0,   0,   0,   0,   0,
  26,   0,  23,  16,  19,  28,  33,   0, 154,   0,
 188, 189, 190, 156,  36, 157, 180, 192, 171, 172,
   0, 162, 164, 166,  21,   0,  77,   0, 182,   0,
   0, 175,   0,   0,  24, 187, 173, 174,   0,   0,
   0, 176, 177, 178 };
#ifndef lint
static char yaccpar_sccsid[] = "@(#)yaccpar	4.1	(Berkeley)	2/11/83";
#endif

# define YYFLAG -1000
# define YYERROR goto yyerrlab
# define YYACCEPT return(0)
# define YYABORT return(1)

/*	parser for yacc output	*/

#ifdef YYDEBUG
int yydebug = 0; /* 1 for debugging */
#endif
YYSTYPE yyv[YYMAXDEPTH]; /* where the values are stored */
int yychar = -1; /* current input token number */
int yynerrs = 0;  /* number of errors */
short yyerrflag = 0;  /* error recovery flag */

yyparse() {

	short yys[YYMAXDEPTH];
	short yyj, yym;
	register YYSTYPE *yypvt;
	register short yystate, *yyps, yyn;
	register YYSTYPE *yypv;
	register short *yyxi;

	yystate = 0;
	yychar = -1;
	yynerrs = 0;
	yyerrflag = 0;
	yyps= &yys[-1];
	yypv= &yyv[-1];

 yystack:    /* put a state and value onto the stack */

#ifdef YYDEBUG
	if( yydebug  ) printf( "state %d, char 0%o\n", yystate, yychar );
#endif
		if( ++yyps> &yys[YYMAXDEPTH] ) { syserr( "yacc stack overflow" ); return(1); }
		*yyps = yystate;
		++yypv;
		*yypv = yyval;

 yynewstate:

	yyn = yypact[yystate];

	if( yyn<= YYFLAG ) goto yydefault; /* simple state */

	if( yychar<0 ) if( (yychar=yylex())<0 ) yychar=0;
	if( (yyn += yychar)<0 || yyn >= YYLAST ) goto yydefault;

	if( yychk[ yyn=yyact[ yyn ] ] == yychar ){ /* valid shift */
		yychar = -1;
		yyval = yylval;
		yystate = yyn;
		if( yyerrflag > 0 ) --yyerrflag;
		goto yystack;
		}

 yydefault:
	/* default state action */

	if( (yyn=yydef[yystate]) == -2 ) {
		if( yychar<0 ) if( (yychar=yylex())<0 ) yychar = 0;
		/* look through exception table */

		for( yyxi=yyexca; (*yyxi!= (-1)) || (yyxi[1]!=yystate) ; yyxi += 2 ) ; /* VOID */

		while( *(yyxi+=2) >= 0 ){
			if( *yyxi == yychar ) break;
			}
		if( (yyn = yyxi[1]) < 0 ) return(0);   /* accept */
		}

	if( yyn == 0 ){ /* error */
		/* error ... attempt to resume parsing */

		switch( yyerrflag ){

		case 0:   /* brand new error */

			yyerror( yychar, yylval, yystate );
		yyerrlab:
			++yynerrs;

		case 1:
		case 2: /* incompletely recovered error ... try again */

			yyerrflag = 3;

			/* find a state where "error" is a legal shift action */

			while ( yyps >= yys ) {
			   yyn = yypact[*yyps] + YYERRCODE;
			   if( yyn>= 0 && yyn < YYLAST && yychk[yyact[yyn]] == YYERRCODE ){
			      yystate = yyact[yyn];  /* simulate a shift of "error" */
			      goto yystack;
			      }
			   yyn = yypact[*yyps];

			   /* the current yyps has no shift onn "error", pop stack */

#ifdef YYDEBUG
			   if( yydebug ) printf( "error recovery pops state %d, uncovers %d\n", *yyps, yyps[-1] );
#endif
			   --yyps;
			   --yypv;
			   }

			/* there is no state on the stack with an error shift ... abort */

	yyabort:
			return(1);


		case 3:  /* no shift yet; clobber input char */

#ifdef YYDEBUG
			if( yydebug ) printf( "error recovery discards char %d\n", yychar );
#endif

			if( yychar == 0 ) goto yyabort; /* don't discard EOF, quit */
			yychar = -1;
			goto yynewstate;   /* try again in the same state */

			}

		}

	/* reduction by production yyn */

#ifdef YYDEBUG
		if( yydebug ) printf("reduce %d\n",yyn);
#endif
		yyps -= yyr2[yyn];
		yypvt = yypv;
		yypv -= yyr2[yyn];
		yyval = yypv[1];
		yym=yyn;
			/* consult goto table to find next state */
		yyn = yyr1[yyn];
		yyj = yypgo[yyn] + *yyps + 1;
		if( yyj>=YYLAST || yychk[ yystate = yyact[yyj] ] != -yyn ) yystate = yyact[yypgo[yyn]];
		switch(yym){
			
case 1:
# line 151 "expanded.g"
{gout(globfile);} break;
case 4:
# line 156 "expanded.g"
{if (!nocode)
		   rout(globfile, Str0(yypvt[-0]));
		nocode = 0;
		loc_init();} break;
case 5:
# line 160 "expanded.g"
{if (!nocode)
		   codegen(yypvt[-0]);
		nocode = 0;
		treeinit();
		loc_init();} break;
case 6:
# line 165 "expanded.g"
{;} break;
case 7:
# line 166 "expanded.g"
{;} break;
case 8:
# line 168 "expanded.g"
{;} break;
case 10:
# line 171 "expanded.g"
{;} break;
case 11:
# line 173 "expanded.g"
{addlfile(Str0(yypvt[-0]));} break;
case 12:
# line 174 "expanded.g"
{addlfile(Str0(yypvt[-0]));} break;
case 13:
# line 176 "expanded.g"
{idflag = F_Global;} break;
case 14:
# line 176 "expanded.g"
{;} break;
case 15:
# line 178 "expanded.g"
{idflag = F_Argument;} break;
case 16:
# line 178 "expanded.g"
{
		 install(Str0(yypvt[-3]),F_Record|F_Global,
		   (int)yypvt[-1]); yyval = yypvt[-3];
		} break;
case 17:
# line 183 "expanded.g"
{yyval = (int)0;} break;
case 18:
# line 184 "expanded.g"
{yyval = (nodeptr)(yypvt[-0]);} break;
case 19:
# line 186 "expanded.g"
{
		 yyval = tree6(N_Proc,yypvt[-5],yypvt[-5],yypvt[-2],yypvt[-1],yypvt[-0]);
		} break;
case 20:
# line 190 "expanded.g"
{idflag = F_Argument;} break;
case 21:
# line 190 "expanded.g"
{
		yyval = yypvt[-3];
		install(Str0(yypvt[-3]),F_Proc|F_Global,(int)yypvt[-1]);
		} break;
case 22:
# line 195 "expanded.g"
{yyval = (int)0;} break;
case 23:
# line 196 "expanded.g"
{yyval = (nodeptr)(yypvt[-0]);} break;
case 24:
# line 197 "expanded.g"
{yyval = (nodeptr) -(int)(yypvt[-2]);} break;
case 25:
# line 200 "expanded.g"
{
		install(Str0(yypvt[-0]),idflag,0);
		yyval = (nodeptr)1;
		} break;
case 26:
# line 204 "expanded.g"
{
		install(Str0(yypvt[-0]),idflag,0);
		yyval = (nodeptr)((word)(yypvt[-2]) + 1);
		} break;
case 27:
# line 209 "expanded.g"
{;} break;
case 28:
# line 210 "expanded.g"
{;} break;
case 29:
# line 212 "expanded.g"
{idflag = F_Dynamic;} break;
case 30:
# line 213 "expanded.g"
{idflag = F_Static;} break;
case 31:
# line 214 "expanded.g"
{idflag = F_Dynamic;} break;
case 32:
# line 216 "expanded.g"
{yyval = tree1(N_Empty) ;} break;
case 33:
# line 217 "expanded.g"
{yyval = yypvt[-1];} break;
case 34:
# line 219 "expanded.g"
{yyval = tree1(N_Empty) ;} break;
case 35:
# line 220 "expanded.g"
{yyval = tree4(N_Slist,yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 36:
# line 222 "expanded.g"
{yyval = tree1(N_Empty) ;} break;
case 39:
# line 226 "expanded.g"
{yyval = tree5(N_Conj,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 41:
# line 229 "expanded.g"
{yyval = tree5(N_Scan,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 43:
# line 232 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 44:
# line 233 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 45:
# line 234 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 46:
# line 235 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 47:
# line 236 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 48:
# line 237 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 49:
# line 238 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 50:
# line 239 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 51:
# line 240 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 52:
# line 241 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 53:
# line 242 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 54:
# line 243 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 55:
# line 244 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 56:
# line 245 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 57:
# line 246 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 58:
# line 247 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 59:
# line 248 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 60:
# line 249 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 61:
# line 250 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 62:
# line 251 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 63:
# line 252 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 64:
# line 253 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 65:
# line 254 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 66:
# line 255 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 67:
# line 256 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 68:
# line 257 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 69:
# line 258 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 70:
# line 259 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 71:
# line 260 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 72:
# line 261 "expanded.g"
{yyval = tree5(N_Scan,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 73:
# line 262 "expanded.g"
{yyval = tree5(N_Conj,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 74:
# line 263 "expanded.g"
{yyval = tree5(N_Activat,yypvt[-1],yypvt[-1],yypvt[-0],yypvt[-2]) ;} break;
case 76:
# line 266 "expanded.g"
{yyval = tree4(N_To,yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 77:
# line 267 "expanded.g"
{yyval = tree5(N_ToBy,yypvt[-3],yypvt[-4],yypvt[-2],yypvt[-0]) ;} break;
case 79:
# line 270 "expanded.g"
{yyval = tree4(N_Alt,yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 81:
# line 273 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 82:
# line 274 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 83:
# line 275 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 84:
# line 276 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 85:
# line 277 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 86:
# line 278 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 87:
# line 279 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 88:
# line 280 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 89:
# line 281 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 90:
# line 282 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 91:
# line 283 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 92:
# line 284 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 93:
# line 285 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 94:
# line 286 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 96:
# line 289 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 97:
# line 290 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 99:
# line 293 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 100:
# line 294 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 101:
# line 295 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 102:
# line 296 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 104:
# line 299 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 105:
# line 300 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 106:
# line 301 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 107:
# line 302 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 109:
# line 305 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 111:
# line 308 "expanded.g"
{yyval = tree4(N_Limit,yypvt[-2],yypvt[-2],yypvt[-0]) ;} break;
case 112:
# line 309 "expanded.g"
{yyval = tree5(N_Activat,yypvt[-1],yypvt[-1],yypvt[-0],yypvt[-2]) ;} break;
case 114:
# line 312 "expanded.g"
{yyval = tree5(N_Activat,yypvt[-1],yypvt[-1],yypvt[-0],tree1(N_Empty) ) ;} break;
case 115:
# line 313 "expanded.g"
{yyval = tree3(N_Not,yypvt[-0],yypvt[-0]) ;} break;
case 116:
# line 314 "expanded.g"
{yyval = tree3(N_Bar,yypvt[-0],yypvt[-0]) ;} break;
case 117:
# line 315 "expanded.g"
{yyval = tree3(N_Bar,yypvt[-0],yypvt[-0]) ;} break;
case 118:
# line 316 "expanded.g"
{yyval = tree3(N_Bar,yypvt[-0],yypvt[-0]) ;} break;
case 119:
# line 317 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 120:
# line 318 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 121:
# line 319 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 122:
# line 320 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 123:
# line 321 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 124:
# line 322 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 125:
# line 323 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 126:
# line 324 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 127:
# line 325 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 128:
# line 326 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 129:
# line 327 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 130:
# line 328 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 131:
# line 329 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 132:
# line 330 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 133:
# line 331 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 134:
# line 332 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 135:
# line 333 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 136:
# line 334 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 137:
# line 335 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]);} break;
case 147:
# line 346 "expanded.g"
{yyval = tree3(N_Create,yypvt[-1],yypvt[-0]) ;} break;
case 148:
# line 347 "expanded.g"
{Val0(yypvt[-0]) = putloc(Str0(yypvt[-0]),0);} break;
case 149:
# line 348 "expanded.g"
{yyval = tree2(N_Next,yypvt[-0]) ;} break;
case 150:
# line 349 "expanded.g"
{yyval = tree3(N_Break,yypvt[-1],yypvt[-0]) ;} break;
case 151:
# line 350 "expanded.g"
{if ((yypvt[-1])->n_type == N_Elist) 
		   yyval = tree4(N_Invok,yypvt[-2],tree1(N_Empty) ,yypvt[-1]); 
		else 
		   yyval = yypvt[-1];} break;
case 152:
# line 354 "expanded.g"
{yyval = yypvt[-1];} break;
case 153:
# line 355 "expanded.g"
{yyval = tree3(N_List,yypvt[-2],yypvt[-1]) ;} break;
case 154:
# line 356 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-2],yypvt[-2],yypvt[-3],yypvt[-1]);} break;
case 155:
# line 357 "expanded.g"
{yyval = tree4(N_Invok,yypvt[-1],yypvt[-2],
		      tree3(N_List,yypvt[-1],tree1(N_Empty) )) ;} break;
case 156:
# line 359 "expanded.g"
{yyval = tree4(N_Invok,yypvt[-2],yypvt[-3],tree3(N_List,yypvt[-2],yypvt[-1])) ;} break;
case 157:
# line 360 "expanded.g"
{yyval = tree4(N_Invok,yypvt[-2],yypvt[-3],yypvt[-1]) ;} break;
case 158:
# line 361 "expanded.g"
{yyval = tree4(N_Field,yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 159:
# line 362 "expanded.g"
{yyval = tree3(N_Key,yypvt[-1],(nodeptr)K_FAIL) ;} break;
case 160:
# line 363 "expanded.g"
{if ((key_num = klocate(Str0(yypvt[-0]))) == NULL)
		   err("invalid keyword",Str0(yypvt[-0]));
		yyval = tree3(N_Key,yypvt[-1],(nodeptr)key_num);} break;
case 161:
# line 367 "expanded.g"
{yyval = tree5(N_Loop,yypvt[-1],yypvt[-1],yypvt[-0],tree1(N_Empty) );} break;
case 162:
# line 368 "expanded.g"
{yyval = tree5(N_Loop,yypvt[-3],yypvt[-3],yypvt[-2],yypvt[-0]) ;} break;
case 163:
# line 370 "expanded.g"
{yyval = tree5(N_Loop,yypvt[-1],yypvt[-1],yypvt[-0],tree1(N_Empty) ) ;} break;
case 164:
# line 371 "expanded.g"
{yyval = tree5(N_Loop,yypvt[-3],yypvt[-3],yypvt[-2],yypvt[-0]) ;} break;
case 165:
# line 373 "expanded.g"
{yyval = tree5(N_Loop,yypvt[-1],yypvt[-1],yypvt[-0],tree1(N_Empty) ) ;} break;
case 166:
# line 374 "expanded.g"
{yyval = tree5(N_Loop,yypvt[-3],yypvt[-3],yypvt[-2],yypvt[-0]) ;} break;
case 167:
# line 376 "expanded.g"
{yyval = tree5(N_Loop,yypvt[-1],yypvt[-1],yypvt[-0],tree1(N_Empty) ) ;} break;
case 168:
# line 378 "expanded.g"
{yyval = tree4(N_Ret,yypvt[-0],yypvt[-0],tree1(N_Empty) ) ;} break;
case 169:
# line 379 "expanded.g"
{yyval = tree4(N_Ret,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 170:
# line 380 "expanded.g"
{yyval = tree5(N_Loop,yypvt[-1],yypvt[-1],yypvt[-0],tree1(N_Empty) ) ;} break;
case 171:
# line 381 "expanded.g"
{yyval = tree5(N_Loop,yypvt[-3],yypvt[-3],yypvt[-2],yypvt[-0]) ;} break;
case 172:
# line 383 "expanded.g"
{yyval = tree5(N_If,yypvt[-3],yypvt[-2],yypvt[-0],tree1(N_Empty) ) ;} break;
case 173:
# line 384 "expanded.g"
{yyval = tree5(N_If,yypvt[-5],yypvt[-4],yypvt[-2],yypvt[-0]) ;} break;
case 174:
# line 386 "expanded.g"
{yyval = tree4(N_Case,yypvt[-5],yypvt[-4],yypvt[-1]) ;} break;
case 176:
# line 389 "expanded.g"
{yyval = tree4(N_Clist,yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 177:
# line 391 "expanded.g"
{yyval = tree4(N_Ccls,yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 178:
# line 392 "expanded.g"
{yyval = tree4(N_Ccls,yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 180:
# line 395 "expanded.g"
{yyval = tree4(N_Elist,yypvt[-1],yypvt[-2],yypvt[-0]);} break;
case 181:
# line 397 "expanded.g"
{
		yyval = tree3(N_Create,yypvt[-0],yypvt[-0]) ;
		} break;
case 182:
# line 400 "expanded.g"
{
		yyval = tree4(N_Elist,yypvt[-1],yypvt[-2],tree3(N_Create,yypvt[-1],yypvt[-0]));
		} break;
case 183:
# line 404 "expanded.g"
{Val0(yypvt[-0]) = putlit(Str0(yypvt[-0]),F_IntLit,0);} break;
case 184:
# line 405 "expanded.g"
{Val0(yypvt[-0]) = putlit(Str0(yypvt[-0]),F_RealLit,0);} break;
case 185:
# line 406 "expanded.g"
{Val0(yypvt[-0]) = putlit(Str0(yypvt[-0]),F_StrLit,Val1(yypvt[-0]));} break;
case 186:
# line 407 "expanded.g"
{Val0(yypvt[-0]) = putlit(Str0(yypvt[-0]),F_CsetLit,Val1(yypvt[-0]));} break;
case 187:
# line 409 "expanded.g"
{yyval = tree6(N_Sect,yypvt[-2],yypvt[-2],yypvt[-5],yypvt[-3],yypvt[-1]) ;} break;
case 188:
# line 411 "expanded.g"
{yyval = yypvt[-0];} break;
case 189:
# line 412 "expanded.g"
{yyval = yypvt[-0];} break;
case 190:
# line 413 "expanded.g"
{yyval = yypvt[-0];} break;
case 192:
# line 416 "expanded.g"
{yyval = tree4(N_Slist,yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
		}
		goto yystack;  /* stack new state and value */

	}
