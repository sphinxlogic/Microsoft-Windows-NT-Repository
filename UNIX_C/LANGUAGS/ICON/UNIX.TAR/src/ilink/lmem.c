/*
 * Memory initialization and allocation; also parses arguments.
 */

#include "ilink.h"

char *strcpy();

/*
 * The following code is operating-system dependent. It includes files
 *  that are system dependent.
 */

#if PORT
   /* nothing is needed */
#endif					/* PORT */

#if AMIGA || ATARI_ST || MACINTOSH || VMS
   /* nothing is needed */
#endif					/* AMIGA ||ATARI_AT || MACINTOSH ... */

#if MSDOS
#if MICROSOFT
#include <sys/types.h>
#include <sys/stat.h>
#endif					/* MICROSOFT */
#endif					/* MSDOS */

#if UNIX
#ifndef ATT3B
#include <sys/types.h>
#include <sys/stat.h>
#endif					/* ATT3B */
#endif					/* UNIX */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */


pointer calloc();
extern char *instalid();
extern char *getenv();
#ifndef NoEnvVars
extern struct gentry *putglob();
#endif					/* NoEnvVars */


/*
 * Memory initialization
 */

struct gentry **ghash;		/* hash area for global table */
struct ientry **ihash;		/* hash area for identifier table */
struct fentry **fhash;		/* hash area for field table */

struct lentry *ltable;		/* local table */
struct gentry *gtable;		/* global table */
struct centry *ctable;		/* constant table */
struct ientry *itable;		/* identifier table */
struct fentry *ftable;		/* field table headers */
struct rentry *rtable;		/* field table record lists */
struct ipc_fname *fnmtbl;	/* table associating ipc with file name */
struct ipc_line *ntable;	/* table associating ipc with line number */

char *strings;			/* string space */
word *labels;			/* label table */
char *code;			/* generated code space */

struct gentry *gfree;		/* free pointer for global table */
struct ientry *ifree;		/* free pointer for identifier table */
struct fentry *ffree;		/* free pointer for field table headers */
struct rentry *rfree;		/* free pointer for field table record lists */
struct ipc_fname *fnmfree;	/* free pointer for ipc/file name table */
struct ipc_line *nfree;		/* free pointer for ipc/line number table */
char *strfree; 			/* free pointer for string space */
char *codep;			/* free pointer for code space */

int lsize = Lsize;		/* size of local table */
int gsize = GSize;		/* size of global table */
int csize = CSize;		/* size of constant table */
int isize = ISize;		/* size of identifier table */
int fsize = FSize;		/* size of field table headers */
int fnmsize = FnmSize;		/* size of ipc/file name assoc. table */
int nsize = NSize;		/* size of ipc/line number assoc. table */
int rsize = RSize;		/* size of field table record lists */
int ghsize = GhSize;		/* size of global hash table */
int ihsize = IhSize;		/* size of identifier hash table */
int fhsize = FhSize;		/* size of field hash table */
unsigned int stsize = StrSize;	/* size of string space */
int maxlabels = MaxLabels;	/* maximum number of labels per procedure */
unsigned int maxcode = MaxCode;	/* maximum amount of code per procedure */
char *strend; 			/* pointer to end of string space */
int gmask;			/* mask for global table hash */
int imask;			/* mask for identifier table hash */
int fmask;			/* mask for field table hash */

char *ipath;

/*
 * The following code is operating-system dependent. It declares a local string
 *  name for access().
 */

#if PORT
#define MaxName 256
char lclname[MaxName];
#endif					/* PORT */

#if MACINTOSH || UNIX
   /* nothing is needed */
#endif					/* MACINTOSH || UNIX */

#if AMIGA || ATARI_ST || MSDOS || VMS
#define MaxName 256
char lclname[MaxName];
#endif					/* AMIGA || ATARI_ST || MSDOS || VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

char *maknam();
char *maknam2();

/*
 * meminit - scan the command line arguments and initialize data structures.
 */
meminit(argc,argv)
int argc;
char **argv;
   {
   int aval;
   register int i;
   union {
      struct gentry **gp;
      struct ientry **ip;
      struct fentry **fp;
      } p;

   lfiles = NULL;		/* Zero queue of files to link. */

#ifndef NoEnvVars
   ipath = getenv("IPATH");
#else					/* NoEnvVars */
   ipath = NULL;
#endif					/* NoEnvVars */

   if (ipath == NULL)

/*
 * The following code is operating-system dependent. Set default for IPATH.
 */

#if PORT
   /* something is needed */
#endif					/* PORT */

#if AMIGA
   /*
    * There is no environment, so set ipath to the null string. The
    *  current directory is searched anyway and there is no symbol
    *  to force current path search.
    */
      ipath = "";
#endif					/* AMIGA */

#if MACINTOSH
#if MPW
      ipath = ":";
#endif					/* MPW */
#endif					/* MACINTOSH */

#if MSDOS
      ipath = ";";
#endif					/* MSDOS */

#if ATARI_ST || UNIX
      ipath = ".";
#endif					/* ATARI_ST || UNIX */

#if VM || MVS
#endif					/* VM || MVS */

#if VMS
      ipath = "[]";
#endif					/* VMS */

/*
 * End of operating-system specific code.
 */

   /*
    * Process the command line arguments.
    */
   while (--argc) {
      if (**++argv == '-') {
         switch ((*argv)[1]) {
            case 'm':		 /* -m and -u are for the translator. */
            case 'u':
		continue;
            case 't':		 /* Set &trace to -1 when Icon starts up. */
		trace = -1;
		continue;
            case 'L':		 /* Produce a .ux file, which is a readable
					version of the icode file produced. */
		Dflag++;
		continue;
            case 'o':		 /* Output file is next argument. */
		strcpy(outname,*++argv);
		argc--;
		continue;
            case 'S':		 /* Change some table size. */
		if ((*argv)[3] == 'h') { /* Change hash table size. */
                  aval = atoi(&(*argv)[4]);
                  if (aval <= 0)
                     goto badarg;
                  switch ((*argv)[2]) {
                     case 'i': ihsize = aval; continue;
                     case 'g': ghsize = aval; continue;
                     case 'c': continue;
                     case 'f': fhsize = aval; continue;
                     case 'l': continue;
                     }
                  }
		else {		/* Change symbol table size. */
                  aval = atoi(&(*argv)[3]);
                  if (aval <= 0)
                     goto badarg;
                  switch ((*argv)[2]) {
                     case 'c': csize = aval; continue;
                     case 'i': isize = aval; continue;
                     case 'g': gsize = aval; continue;
                     case 'l': lsize = aval; continue;
                     case 's': stsize = aval; continue;
                     case 't': continue;
                     case 'f': fsize = aval; continue;
                     case 'F': fnmsize = aval; continue;
                     case 'n': nsize = aval; continue;
                     case 'r': rsize = aval; continue;
                     case 'L': maxlabels = aval; continue;
                     case 'C': maxcode = aval; continue;
                     }
                  }
            case 'i': {
		iconx = *++argv;
		argc--;
		continue;
		}
            default:
            badarg:
		printf("bad argument: %s\n", *argv);
		continue;
            }
         }
      else {		/* If not an argument, assume it's an input file. */

         addlfile(*argv);
         }
      }

   /*
    * Round sizes of hash tables for locals, globals, constants, and
    *  identifiers to next larger power of two.  The corresponding
    *  mask values are set to one less than the hash table size so that
    *  an integer value can be &'d with the mask to produce a hash value.
    *  (See [lgc]hasher in sym.h.)
    */
   for (i = 1; i < ghsize; i <<= 1) ;
   ghsize = i;
   gmask = i - 1;
   for (i = 1; i < ihsize; i <<= 1) ;
   ihsize = i;
   imask = i - 1;
   for (i = 1; i < fhsize; i <<= 1) ;
   fhsize = i;
   fmask = i - 1;
   /*
    * Allocate the various data structures that are made on a per-file
    *  basis.
    */
   ghash   = (struct gentry **)calloc((unsigned)ghsize,sizeof(struct gentry *));
   ihash   = (struct ientry **)calloc((unsigned)ihsize,sizeof(struct ientry *));
   fhash   = (struct fentry **)calloc((unsigned)fhsize,sizeof(struct fentry *));
   ltable  = (struct lentry *)calloc((unsigned)lsize,sizeof(struct lentry));
   gtable  = (struct gentry *)calloc((unsigned)gsize,sizeof(struct gentry));
   ctable  = (struct centry *)calloc((unsigned)csize,sizeof(struct centry));
   itable  = (struct ientry *)calloc((unsigned)isize,sizeof(struct ientry ));
   ftable  = (struct fentry *)calloc((unsigned)fsize,sizeof(struct fentry));
   rtable  = (struct rentry *)calloc((unsigned)rsize,sizeof(struct rentry));
   strings = (char *)calloc((unsigned)stsize,sizeof(char));
   fnmtbl  = (struct ipc_fname *)calloc((unsigned)fnmsize,
      sizeof(struct ipc_fname));
   ntable  = (struct ipc_line *)calloc((unsigned)nsize,sizeof(struct ipc_line));
   labels  = (word *)calloc((unsigned)maxlabels,sizeof(word));
   code    = (char *)calloc((unsigned)maxcode,sizeof(char));

   /*
    * Check to see if there was enough memory.
    */
   if (ghash == NULL || ihash == NULL || fhash == NULL || ltable == NULL ||
       gtable == NULL || ctable == NULL || itable == NULL || ftable == NULL ||
       rtable == NULL || strings == NULL || fnmtbl == NULL || ntable == NULL ||
       labels == NULL || code == NULL)
      syserr("meminit: can't get enough memory");

   /*
    * Reset the free pointer for each region.
    */
   gfree = gtable;
   ifree = itable;
   ffree = ftable;
   rfree = rtable;
   fnmfree = fnmtbl;
   nfree = ntable;
   strfree = strings;
   strend = strings + stsize - 1;
   codep = code;
   /*
    * Zero out the hash tables.
    */
   for (p.gp = ghash; p.gp < &ghash[ghsize]; p.gp++)
      *p.gp = NULL;
   for (p.ip = ihash; p.ip < &ihash[ihsize]; p.ip++)
      *p.ip = NULL;
   for (p.fp = fhash; p.fp < &fhash[fhsize]; p.fp++)
      *p.fp = NULL;
   /*
    * Install "main" as a global variable in order to insure that it
    *  is the first global variable.  iconx/start.s depends on main
    *  being global number 0.
    */
   putglob(instalid("main"), F_Global, 0, 0);
   }

/*
 * alclfile - allocate an lfile structure for the named file, fill
 *  in the name and return a pointer to it.
 */
struct lfile *alclfile(name)
char *name;
   {
   struct lfile *p;
   char *np;
   int l;

   p = (struct lfile *)calloc(1,sizeof(struct lfile));
   if (!p)
      syserr("lfile: not enough memory for file list");
   p->lf_link = NULL;
   l = strlen(name);
   np = calloc(1,(unsigned)(l+1+sizeof(int *)) & ~(sizeof(int *)-1));
   if (!np)
      syserr("lfile: not enough memory for file list");
   strcpy(np,name);
   p->lf_name = np;
   return p;
   }

#ifdef DeBug
/*
 * dumplfiles - print the list of files to link.  Used for debugging only.
 */

dumplfiles()
   {
   struct lfile *p,*lfls;

   printf("lfiles:\n");
   lfls = lfiles;
   while (p = getlfile(&lfls))
       printf("'%s'\n",p->lf_name);
   }
#endif					/* DeBug */
/*
 * addlfile - create an lfile structure for the named file and add it to the
 *  end of the list of files (lfiles) to generate link instructions for.
 */
char *pptr;
addlfile(name)
char *name;
   {
   struct lfile *nlf, *p;
   char file[256], ok;
      ok = 0;
      if ( canread(name)) {
         ok++;
         strcpy(file, name);
         }
      else {
         /*
          * Can't find name in current directory so try paths in
          *   ipath if there are any. (ipath cannot override the
          *   current directory first strategy so there is probably
          *   no reason to initialize ipath to the various current
          *   directory markers as is done above, since this will
          *   only result in a duplicate failed search. Note that
          *   the access test which is done above in some systems
          *   will have already caused ilink to exit if name is
          *   not found in the current directory anyway so ipath
          *   was never able to search other paths first in any case.)
          */
         pptr = ipath;
         while ( trypath(name, file)) {
            if ( canread(file)) {
               ok++;
               break;
               }
            }
         }

      if (!ok) {
        fprintf(stderr, "Can't resolve reference to file '%s'\n",name);
        exit(ErrorExit);
        }

   nlf = alclfile(file);
   if (lfiles == NULL) {
      lfiles = nlf;
      }
   else {
      p = lfiles;
      while (p->lf_link != NULL) {
        if (strcmp(p->lf_name,file) == 0)
           return;
        p = p->lf_link;
        }
      if (strcmp(p->lf_name,file) == 0)
        return;
      p->lf_link = nlf;
      }
   }

/*
 * getlfile - return a pointer (p) to the lfile structure pointed at by lptr
 *  and move lptr to the lfile structure that p points at.  That is, getlfile
 *  returns a pointer to the current (wrt. lptr) lfile and advances lptr.
 */
struct lfile *
getlfile(lptr)
struct lfile **lptr;
   {
   struct lfile *p;

   if (*lptr == NULL)
      return NULL;
   else {
      p = *lptr;
      *lptr = p->lf_link;
      return p;
      }
   }

/*
 * canread - see if file can be read and be sure that it's just an
 *  ordinary file.
 */
canread(file)
char *file;
   {

/*
 * The following code is operating-system dependent. Declare structure for
 *  file status.
 */

#if PORT
   /* nothing is needed */
#endif					/* PORT */

#if AMIGA || ATARI_ST || MACINTOSH || VMS
   /* nothing is needed */
#endif					/* AMIGA || ATARI_ST || MACINTOSH ... */

#if MSDOS
#if MICROSOFT || TURBO
   struct stat statb;
#endif					/* MICROSOFT || TURBO */
#endif					/* MSDOS */

#if UNIX
   struct stat statb;
#endif					/* UNIX */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */


/*
 * The following code is operating-system dependent. Check to see if
 *  .u1 file can be read.
 */

#if PORT
   /* something is needed */
#endif					/* PORT */

#if AMIGA
   if (access(maknam2(lclname,file,".u1"),4) == 0)
      if (getfa(lclname) == -1)
         return 1;
#endif					/* AMIGA */

#if ATARI_ST
   {
   FILE *fd;
   if ((fd = fopen(maknam2(lclname,file,".u1"), "r")) == 0)
      return 0;
   else {
      fclose(fd);
      return 1;
      }
   }
#endif					/* ATARI_ST */

#if MACINTOSH
#if MPW
   {
   int fd;
   if ((fd = open(file,0)) >= 0) {
      close(fd);
      return 1;
      }
   }
#endif					/* MPW */
#endif					/* MACINTOSH */

#if MSDOS
#if MICROSOFT || TURBO
   if (access(file,4) == 0) {
      stat(file,&statb);
      if (statb.st_mode & S_IFREG)
         return 1;
      }
#else					/* MICROSOFT || TURBO */
   if (access( maknam2(lclname,file,".u1"), 4 ) == 0 )
      return 1;
#endif					/* MICROSOFT || TURBO */
#endif					/* MSDOS */

#if UNIX
   if (access(file,4) == 0) {
      stat(file,&statb);
      if (statb.st_mode & S_IFREG)
         return 1;
      }
#endif					/* UNIX */

#if VM || MVS
#endif					/* VM || MVS */

#if VMS
   if (access( maknam2(lclname,file,".u1"), 4 ) == 0 )
      return 1;
#endif					/* VMS */

/*
 * End of operating-system specific code.
 */


   return 0;
   }

/*
 * trypath - form a file name in file by concatenating name onto the
 *  next path element.
 */
trypath(name,file)
char *name, *file;
   {
   char c;

   while (*pptr == ' ')
      pptr++;
   if (!*pptr)
      return 0;
   do {
      c = (*file++ = *pptr++);
      }
      while (c != ' ' && c);
   pptr--;
   file--;

/*
 * The following code is operating-system dependent. Append path character.
 */

#if PORT
   /* nothing is needed */
#endif					/* PORT */

#if AMIGA
   file--;
   switch (*file) {

      case ':':
      case '/':
                 file++;
                 break;       /* add nothing, delimiter already there */
      default:
                 *file++ = '/';
      }
#endif					/* AMIGA */

#if ATARI_ST || MACINTOSH || VMS
   /* nothing is needed */
#endif					/* ATARI_ST || MACINTOSH */

#if UNIX || MSDOS
   *file++ = '/';			/* should check for delimiter */
#endif					/* UNIX || MSDOS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   while (*file++ = *name++);
   *file = 0;
   return(1);
   }
