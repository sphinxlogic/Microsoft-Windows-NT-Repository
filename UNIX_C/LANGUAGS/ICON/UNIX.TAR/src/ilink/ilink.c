/*
 * Linker main program that controls the linking process.
 */

#include "ilink.h"
#include "../h/paths.h"
#include "../h/header.h"

#ifndef NoHeader
#ifndef MaxHeader
#define MaxHeader MaxHdr
#endif					/* MaxHeader */

#ifndef Header
#define Header HeaderPath
#endif					/* Header */
#endif					/* NoHeader */

#define MaxName  256		/* maximum length of file name */

FILE *infile;			/* input file (.u1 or .u2) */
FILE *outfile;			/* interpreter code output file */
FILE *dbgfile;			/* debug file */
char inname[MaxName];		/* input file name */
char outname[MaxName];		/* output file name */
char icnname[MaxName];		/* icon source file name */
char dbgname[MaxName];		/* debug file name */

/*
 * The following code is operating-system dependent. Set path name in
 *  case iconx is not found.
 */

#if PORT
   /* need to set *iconx to something; probably irrelevant what */
#endif					/* PORT */

#if AMIGA
char *iconx = "AmigaDos ICONX";
#endif					/* AMIGA */

#if ATARI_ST
char *iconx = "ATARI_TOS ICONX";
#endif					/* ATARI_ST */

#if MACINTOSH
#if MPW
char *iconx = "/bin/echo iconx path not in; exit(1)\n";
#endif					/* MPW */
#endif					/* MACINTOSH */

#if MSDOS
char *iconx = "MS-DOS ICONX";
#endif					/* MSDOS */

#if UNIX
char *iconx = "/bin/echo iconx path not in";
#endif					/* UNIX */

#if VMS
char *iconx = "VMS ICONX";
#endif					/* VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

struct lfile *lfiles;		/* List of files to link */

int line = 0;			/* current source program line number */
int fatalerrs = 0;		/* number of errors encountered */
int Dflag = 0;			/* debug flag */

char *pname;			/* name of program that is running */
char **filep;			/* name of current input file */
extern char *maknam2();
extern char *maknam();

main(argc, argv)
int argc;
char **argv;
   {
   int hfile;
   struct lfile *lf,*lfls;

   pname = "ilink";
   meminit(argc, argv); /* Note that meminit also processes arguments. */

   /*
    * Phase I: load global information contained in .u2 files into
    *  data structures.
    *
    * The list of files to link is maintained as a queue with lfiles
    *  as the base.  lf moves along the list.  Each file is processed
    *  in turn by forming .u2 and .icn names from each file name, each
    *  of which ends in .u1.  The .u2 file is opened and globals is called
    *  to process it.  When the end of the list is reached, lf becomes
    *  NULL and the loop is terminated, completing phase I.  Note that
    *  link instructions in the .u2 file cause files to be added to list
    *  of files to link.
    */
   if (!(lf = lfiles))
      exit(NormalExit);
   while (lf) {
      filep = &(lf->lf_name);
      maknam2(inname, *filep, ".u2");
      maknam(icnname, *filep, ".icn");
      infile = fopen(inname, "r");
      if (infile == NULL) {
	 fprintf(stderr, "%s: cannot open %s\n", pname, inname);
	 exit(ErrorExit);
	 }
      globals();
      fclose(infile);
      lf = lf->lf_link;
      }

   /* Phase II: resolve undeclared variables and generate code. */

   /*
    * Open the output file.  If no file was named with -o, form the
    *  name from that of the first input file named.
    */
   if (!outname[0]) {

/*
 * The following code is operating-system dependent.  Make name for
 *  icode file.
 */

#if PORT
      maknam(outname, lfiles->lf_name, "");
#endif					/* PORT */

#if ATARI_ST || MSDOS || VMS
      maknam(outname, lfiles->lf_name, ".icx");
#endif					/* ATARI_ST || MSDOS || VMS */

#if AMIGA || MACINTOSH || UNIX
      maknam(outname, lfiles->lf_name, "");
#endif					/* AMIGA || MACINTOSH || UNIX */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

      }

/*
 * The following code is operating-system dependent.  It opens the icode file.
 */

#if PORT
   outfile = fopen(outname, "w");
#endif					/* PORT */

#if ATARI_ST
   outfile = fopen(outname, "wb");
#endif					/* ATARI_ST */

#if AMIGA || MACINTOSH || MSDOS || UNIX || VMS
   outfile = fopen(outname, "w");
#endif					/* AMIGA || MACINTOSH || MSDOS ... */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

/*
 * The following code is operating-system dependent. Handle
 *  untranslated mode.
 */

#if PORT
   /* nothing to do */
#endif					/* PORT */

#if AMIGA || ATARI_ST || MACINTOSH || UNIX || VMS
   /* nothing to do */
#endif					/* AMIGA || ATARI_ST || MACINTOSH ... */

#if MSDOS
#if LATTICE
   fmode(outfile,1);			/* set for untranslated mode */
#endif					/* LATTICE */
#if MICROSOFT
   setmode(fileno(outfile),0x8000);	/* set for untranslated mode */
#endif					/* MICROSOFT */
#endif					/* MSDOS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */
 
   if (outfile == NULL) {
      fprintf(stderr, "%s: cannot create %s\n", pname, outname);
      exit(ErrorExit);
      }
#ifndef NoHeader
   /*
    * Open Header, which contains the start-up program and copy it to the
    *  output file.  Then, write out null bytes to past the end of the
    *  start-up program.
    */
   {
   int hsize;
   char hdrdat[MaxHeader];

/*
 * The following code is operating-system dependent. Open header file.
 */

#if PORT
   /* no header; irrelevant */
#endif					/* PORT */

#if AMIGA || ATARI_ST || MSDOS || VMS
   /* no header; irrelevant */
#endif					/* AMIGA || ATARI_ST || MSDOS || VMS */

#if MACINTOSH
#if MPW
      {  /* Look for header in same directory as the linker */
      char hname[65], *p, *rindex();
      char *p;

      p = (char *)getenv("Command");
      if (p) {
        strcpy(hname,p);
	p = rindex(hname,':') + 1;
      }
      else p = hname;
      strcpy(p,Header);
      hfile = open(hname,0);
      if (hfile == -1) {
         fprintf(stderr,"Can't open linker header file %s\n",hfile);
         exit(ErrorExit);
         }
      }
#endif					/* MPW */
#endif					/* MACINTOSH */

#if UNIX
   hfile = open(Header,0);
   if (hfile == -1) {
      fprintf(stderr,"Can't open linker header file %s\n",Header);
      exit(ErrorExit);
      }
#endif					/* UNIX */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */
   hsize = read(hfile,hdrdat,MaxHeader);
   close(hfile);
   fwrite(hdrdat,sizeof(char),hsize,outfile);
   for (hfile = MaxHeader - hsize + sizeof(struct header); hfile--;)
      putc(0, outfile);
   }
#else					/* NoHeader */
   for (hfile = sizeof(struct header); hfile--;)
      putc(0, outfile);
#endif					/* NoHeader */
   if (fflush(outfile) == EOF) {
      fprintf(stderr, "%s: unable to write to icode file\n", pname);
      exit(ErrorExit);
      }

   /*
    * Open the .ux file if debugging is on.
    */
   if (Dflag) {
      maknam(dbgname, lfiles->lf_name, ".ux");
      dbgfile = fopen(dbgname, "w");
      if (dbgfile == NULL) {
	 fprintf(stderr, "%s: cannot create %s\n", pname, dbgname);
	 exit(ErrorExit);
	 }
      }

   /*
    * Loop through input files and generate code for each.
    */
   lfls = lfiles;
   while (lf = getlfile(&lfls)) {
      filep = &(lf->lf_name);
      maknam2(inname, *filep, ".u1");
      maknam(icnname, *filep, ".icn");
      infile = fopen(inname, "r");
      if (infile == NULL) {
	 fprintf(stderr, "%s: cannot open %s\n", pname, inname);
	 exit(ErrorExit);
	 }
      gencode();
      fclose(infile);
      }
   gentables(); 	/* Generate record, field, global, global names,
			   static, and identifier tables. */
   if (fatalerrs > 0)
      exit(ErrorExit);
   exit(NormalExit);
   }

/*
 * maknam - makes a file name from prefix and suffix.
 *
 * Uses only the last file specification if name is a path,
 * replaces suffix of name with suffix argument.
 */
char *maknam(dest, name, suffix)
char *dest, *name, *suffix;
   {
   register char *d, *pre, *suf;
   char *mark;

   d = dest;
   pre = name;
   suf = suffix;
   mark = pre;
   while (*pre) 		/* find last delimiter */

/*
 * The following code is operating-system dependent. Find last delimiter in
 *  path name.
 */

#if PORT
   /* something testing *pre for special characters is needed */
#endif					/* PORT */

#if AMIGA
      if (*pre == '/' || *pre == ':')
         mark = ++pre;
      else
         ++pre;
#endif					/* AMIGA */

#if MACINTOSH
#if MPW
      if (*pre++ == ':')
         mark = pre;
#endif					/* MPW */
#endif					/* MACINTOSH */

#if ATARI_ST || MSDOS
      if (*pre == '/' || *pre == '\\' || *pre == ':')
	 mark = ++pre;
      else
	 ++pre;
#endif					/* ATARI_ST || MSDOS */

#if UNIX
      if (*pre++ == '/')
	 mark = pre;
#endif					/* UNIX */

#if VMS
      if (*pre == ']' || *pre == ':')
	 mark = ++pre;
      else
	 ++pre;
#endif					/* VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

   pre = mark;
   mark = 0;
   while (*d = *pre++)		/* copy from last slash into dest */
      if (*d++ == '.')          /*   look for last dot, too */
	 mark = d - 1;
   if (mark)			/* if no dot, just append suffix */
      d = mark;
   while (*d++ = *suf++);	/* copy suffix into dest */
   }

/*
 * maknam2 - makes a file name from prefix and suffix.
 *
 * Like maknam, but leaves initial pathname component intact.
 */
char *maknam2(dest, name, suffix)
char *dest, *name, *suffix;
   {
   register char *d, *pre, *suf;
   char *mark;

   d = dest;
   pre = name;
   suf = suffix;
   mark = 0;
   while (*d = *pre++) {

/*
 * The following code is operating-system dependent.  Find last delimiter.
 */

#if PORT
   /* something test on *d for special characters is needed */
#endif					/* PORT */

#if AMIGA
      if(*d == ':' || *d == '/')
         mark = 0;
#endif					/* AMIGA */

#if MACINTOSH
#if MPW
      if (*d == ':')
         mark = 0;
#endif					/* MPW */
#endif					/* MACINTOSH */

#if ATARI_ST || MSDOS
      if (*d == ':' || *d == '/' || *d == '\\')
	 mark = 0;
#endif					/* ATARI_ST || MSDOS */

#if UNIX
      if (*d == '/')
	 mark = 0;
#endif					/* UNIX */

#if VMS
      if (*d == ']' || *d == ':')
	 mark = 0;
#endif					/* VMS */

#if VM || MVS
#endif					/* VM || MVS */

/*
 * End of operating-system specific code.
 */

      if (*d++ == '.')          /*   look for last dot, too */
	 mark = d - 1;
      }
   if (mark)			/* if no dot, just append suffix */
      d = mark;
   while (*d++ = *suf++) ;	/* copy suffix into dest */
   return dest;
   }

/*
 * syserr - issue error message and die.
 */
syserr(s)
char *s;
   {
   fprintf(stderr, "%s\n", s);
   exit(ErrorExit);
   }

/*
 * warn - issue a warning message.
 */
warn(s1, s2, s3)
char *s1, *s2, *s3;
   {
   fprintf(stderr, "%s: ", icnname);
   if (line)
      fprintf(stderr, "%d: ", line);
   if (s1)
      fprintf(stderr, "\"%s\": ", s1);
   if (s2)
      fprintf(stderr, "%s", s2);
   if (s3)
      fprintf(stderr, "%s", s3);
   fprintf(stderr, "\n");
   }

/*
 * err - issue an error message.
 */

err(s1, s2, s3)
char *s1, *s2, *s3;
   {
   fprintf(stderr, "%s: ", icnname);
   if (line)
      fprintf(stderr, "%d: ", line);
   if (s1)
      fprintf(stderr, "\"%s\": ", s1);
   if (s2)
      fprintf(stderr, "%s", s2);
   if (s3)
      fprintf(stderr, "%s", s3);
   fprintf(stderr, "\n");
   fatalerrs++;
   }
