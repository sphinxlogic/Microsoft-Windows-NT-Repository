#define Double
#define GetHost 1
#define MaxHdr  16384
#define NoOver
#define SysTime <sys/time.h>

#define UNIX 1
