/*
 * This file is a placeholder.  If any local C routines are needed, this is
 * the place to put them.
 */

char junk;			/* prevent empty module */
