#define Fork vfork
#define GetHost 1
#define MaxHdr	2048
#define NoOver
#define RTACIS
#define SysTime <sys/time.h>
#define ZeroDivide

#define UNIX 1
