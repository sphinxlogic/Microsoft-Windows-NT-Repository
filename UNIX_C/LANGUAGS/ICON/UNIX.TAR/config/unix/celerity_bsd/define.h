#define Fork vfork
#define GetHost
#define MaxHdr 13500
#define NoOver
#define SysTime <sys/time.h>

#define UNIX 1
