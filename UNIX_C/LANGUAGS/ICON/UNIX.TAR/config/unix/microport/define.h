#define FixedRegions
#define HostStr "Microport V/AT"
#define NoOver
#define index	strchr
#define rindex	strrchr

#define UNIX 1
