#define Fork vfork
#define GetHost
#define NoOver
#define SysTime <sys/time.h>

#define UNIX 1
