/*
 * This file is a placeholder.  If NoOver is defined, addition, subtraction,
 * and multiplication are performed in C without arithmetic overflow checks.
 * This file keeps the configuration system simple by avoiding a change
 * in the iconx/Makefile (ROVER=rover.c).  If NoOver is not defined,
 * addition, subtraction, and multiplication are performed in assembly
 * language with overflow checks and this file is not compiled (ROVER=rover.s).
 */

char junk;			/* prevent empty module */
