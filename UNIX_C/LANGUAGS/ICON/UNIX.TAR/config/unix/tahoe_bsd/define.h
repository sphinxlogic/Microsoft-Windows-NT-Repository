#define Fork vfork
#define GetHost 1
#define MaxHdr	1200
#define SysTime <sys/time.h>

#define UNIX 1
