#define MaxHdr  1536
#define UtsName
#define index strchr
#define rindex strrchr

#define UNIX 1
