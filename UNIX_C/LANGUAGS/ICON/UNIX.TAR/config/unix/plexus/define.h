
#define MaxHdr	1536
#define UtsName
#define index strchr 
#define rindex strrchr 
/* fix names of string routines */

#define UNIX 1
