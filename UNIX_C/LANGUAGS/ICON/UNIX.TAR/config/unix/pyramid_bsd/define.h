#define Fork vfork
#define GetHost 1
#define MaxHdr  2000
#define NoOver
#define SysTime <sys/time.h>

#define UNIX 1
