#define Double
#define MaxHdr  3080
#define SysMem
#define UpStack
#define UtsName
#define index strchr
#define rindex strrchr

#define UNIX 1
