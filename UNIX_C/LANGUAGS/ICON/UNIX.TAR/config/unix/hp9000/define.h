#define HostStr "HP 9000; HP-UX"
#define MaxHdr  2048
#define NoOver
#define index strchr
#define rindex strrchr

#define UNIX 1
