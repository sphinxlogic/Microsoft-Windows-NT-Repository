/*
 * This is the co-expression context switch for the HP 9000 operating
 * under HP/UX.
 */


/*
 * coswitch
 */
coswitch(old_cs, new_cs, first)
int *old_cs, *new_cs;
int first;
{
   syserr("co-expression context switch not implemented");
}
