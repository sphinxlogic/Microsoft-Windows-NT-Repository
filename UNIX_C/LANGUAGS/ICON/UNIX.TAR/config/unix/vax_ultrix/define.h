#define Big 72057594037927936.		/* larger than 2^56 lose precision */
#define ExecImages
#define Fork vfork
#define GetHost 1
#define LogHuge 39
#define MaxHdr  1500
#define Precision 16
#define SysTime <sys/time.h>

#define UNIX 1
