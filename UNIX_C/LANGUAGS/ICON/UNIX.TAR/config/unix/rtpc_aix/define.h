#define AIX
#define CStateSize 19
#define MaxHdr	3136
#define NoOver
#define UtsName
#define index strchr
#define rindex strrchr

#define UNIX 1
