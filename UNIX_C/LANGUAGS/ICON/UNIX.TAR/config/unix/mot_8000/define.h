#define HostStr "m8000"
#define NoCoexpr
#define NoOver
#define UtsName
#define index strchr
#define rindex strrchr

#define UNIX 1
