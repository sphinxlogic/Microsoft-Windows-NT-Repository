#define FixedRegions
#define HostStr "SCO XENIX V"
#define IntBits 16
#define MaxHdr  6500
#define NoOver
#define SCO_XENIX
#define ZeroDivide	1
#define index strchr
#define rindex strrchr

#define UNIX 1
