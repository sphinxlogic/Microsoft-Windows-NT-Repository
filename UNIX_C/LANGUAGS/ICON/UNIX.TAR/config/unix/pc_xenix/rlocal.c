/* qsort(base,nel,width,compar) - quicksort routine
 *
 * A Unix-compatible public domain quicksort.
 * Based on Bentley, CACM 28,7 (July, 1985), p. 675.
 */
     
qsort (base, nel, w, compar)
char *base;
int nel, w;
int (*compar)();
   {
   int i, lastlow;
    
   if (nel < 2)
      return;
   qswap(base, base + w * (rand() % nel), w);
   lastlow = 0;
   for (i = 1; i < nel; i++)
      if ((*compar) (base + w * i, base) < 0)
         qswap(base + w * i, base + w * (++lastlow), w);
   qswap(base, base + w * lastlow, w);
   qsort(base, lastlow, w, compar);
   qsort(base + w * (lastlow+1), nel-lastlow-1, w, compar);
   }
    
static qswap (a, b, w)        /* swap *a and *b of width w for qsort*/
char *a, *b;
int w;
   {
   register t;
    
   while (w--)  {
      t = *a;
      *a++ = *b;
      *b++ = t;
      }
   }
