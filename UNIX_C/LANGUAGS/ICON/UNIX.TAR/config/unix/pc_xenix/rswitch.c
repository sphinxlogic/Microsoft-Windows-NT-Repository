#include "../h/rt.h"

/*
 * coswitch
 */
coswitch(old_cs, new_cs, first)
int *old_cs, *new_cs;
int first;
{
   runerr(401, NULL);
}
