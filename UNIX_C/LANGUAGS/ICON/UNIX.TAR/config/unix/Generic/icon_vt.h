Root=RootPath
echo Setting up structure for variant translator...
BaseDir=`pwd`
TranDir=$BaseDir/itran
HDir=$BaseDir/h
rm -rf $TranDir $HDir
mkdir $TranDir $HDir
echo Copying files ...
cp $Root/vt/vtfiles/"*" $BaseDir
cp $Root/Vtmake1 $BaseDir/Makefile
cp $Root/Vtmake2 $TranDir/Makefile
for j in err.c fixgram.icn icon_g.c itran.c itran.h lex.c lex.h\
	 mem.c mktoktab.icn optab pscript sym.c sym.h tokens tree.c tree.h
do
   cp $Root/src/itran/$j $TranDir
done
for j in config.h define.h keyword.h memsize.h proto.h
do
   cp $Root/src/h/$j $HDir
done
echo variant translator is complete.
