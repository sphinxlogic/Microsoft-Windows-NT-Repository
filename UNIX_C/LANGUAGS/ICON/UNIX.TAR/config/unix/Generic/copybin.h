cp src/itran/itran TranPath
cp src/ilink/ilink LinkPath
cp src/iconx/iconx IconxPath
cp src/icont/icont IcontPath
cp src/icont/iconx.hdr HeaderPath
strip TranPath LinkPath IconxPath IcontPath
