#define HostStr "ATT 3B5"
#define IconAlloc
#define MaxHdr  2048
#define UpStack 1
#define index strchr
#define rindex strrchr

#define UNIX 1
