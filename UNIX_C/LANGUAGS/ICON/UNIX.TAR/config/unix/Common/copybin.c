#include "paths.h"
#include "../Generic/copybin.h"
