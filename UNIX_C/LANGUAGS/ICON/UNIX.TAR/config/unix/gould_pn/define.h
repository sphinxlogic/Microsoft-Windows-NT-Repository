#define Double
#define Fork vfork
#define GetHost
#define IconAlloc
#define SysTime <sys/time.h>
#define ZeroDivide

#define UNIX 1
