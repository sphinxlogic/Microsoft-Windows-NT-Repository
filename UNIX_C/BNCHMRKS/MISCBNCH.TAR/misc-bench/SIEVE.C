#define TRUE 1
#define FALSE 0
#define SIZE 8190
#define REG	register

char	flags[SIZE+1];

main()
{
	REG int		i, prime, k, count, iter;

/*	printf("10 iterations\n");*/
	for (iter = 1; iter <= 10; ++iter)
	{
		count = 0;
		for (i = 0; i <= SIZE; ++i)
			flags[i] = TRUE;
		for (i = 0; i <= SIZE; ++i)
		{
			if (flags[i])
			{
				prime = i + i + 3;
				for (k = i + prime; k <= SIZE; k+= prime)
					flags[k] = FALSE;
				++count;
			}
		}
	}
/*	printf("%d primes\n", count);*/
	exit(0);
}
