#define NTIMES	10
#define	NUMBER	24
#define	REG	register

main()
{
	REG int		i;
	REG unsigned	value;
	unsigned	fib();

	printf("%d iterations: ", NTIMES);

	for (i = 1; i <= NTIMES; ++i)
		value = fib(NUMBER);

	printf("fibonacci(%d) = %u.\n", NUMBER, value);
	exit(0);
}

unsigned fib(x)
int	x;
{
	if (x > 2)
		return (fib(x-1) + fib(x-2));
	else
		return (1);
}
