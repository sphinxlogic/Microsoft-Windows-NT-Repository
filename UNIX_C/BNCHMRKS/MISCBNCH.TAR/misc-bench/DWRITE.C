#include <stdio.h>
#define BLOCKS 256
main()
{
	char buffer[512];
	char	*filename = "a_large_file";
	register int i;
	int	fildes;
	if ((fildes = creat(filename, 0640)) < 0) {
		printf("Cannot create file\n");
		exit(1);
	} else {
		close(fildes);
		if ((fildes = open(filename, 1)) < 0) {
			printf("Cannot open file\n");
			exit(1);
		}
	}
	for (i = 0; i < BLOCKS; ++i)
		if (write(fildes, buffer, 512) < 0) {
			printf("Error writing block %d\n", i);
			exit (1);
		}
	close(fildes);
	exit(0);
}
