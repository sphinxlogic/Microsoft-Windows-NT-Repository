/* iocall.c:
 *
 *	Author: 	Jan Stubbs, NCR, ..!sdcsvax!ncr-sd!stubbs
 *	Results:	Send results to the above author.
 *	Version:	improved to eliminate real disk writes
 *
 * This benchmark tests speed of Unix system call interface
 * and speed of cpu doing common Unix io system calls.
 *
 * Under normal circumstances, this benchmark will not actually
 * cause any physical disk activity, but will just cause system
 * buffer activity.
 */

char buf[512];
int fd,count,i,j;

main()
{
	fd = creat("/tmp/testfile",0777);
	close(fd);
	fd = open("/tmp/testfile",2);
	unlink("/tmp/testfile");
	for (i=0;i<=1000;i++) {
		lseek(fd,0,0);
		count = write(fd,buf,500);
		lseek(fd,0,0);
		for (j=0;j<=3;j++) 
			count = read(fd,buf,100);
	}
	exit(0);
}
