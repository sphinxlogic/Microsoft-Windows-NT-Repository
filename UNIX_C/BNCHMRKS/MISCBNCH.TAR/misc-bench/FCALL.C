#define TIMES 50000
main()
#ifdef EMPTY
{
	register unsigned int i,j;
	for (i = 0; i < TIMES; ++i)
		j = empty(i);
	exit(0);
}
empty(k)
register unsigned int k;
{
	return (k);
}
#endif
#ifdef ASSIGN
{
	register unsigned int i,j;
	for (i = 0; i < TIMES; ++i)
		j = i;
	exit(0);
}
#endif
