#define TIMES 25000

main()
{
	register int i;
	for (i = 0; i < TIMES; ++i)
		getpid();
	exit(0);
}
