#include <stdio.h>
#define BLOCKS 256
long lseek();

main()
{
	char buffer[512];
	char	*filename = "a_large_file";
	register int i;
	int	fildes;
	long	int offset;
	if ((fildes = open(filename, 0)) < 0) {
		printf("Cannot find '%s'. Run 'dwrite' first.\n", filename);
		exit(1);
	}
	for (i = 0; i < BLOCKS; ++i)
	{
#ifdef SIXTEEN
		offset = (long) rand() * 4L;
#endif
#ifdef THIRTYTWO
		offset = (long) rand() / 16384L;
#endif
		if (lseek(fildes, offset, 0) < 0) {
			printf("Lseek to %ld failed i=%d\n", offset, i);
			exit (1);
		}
		if (read(fildes, buffer, 512) < 0) {
			printf("Error reading block at byte %ld\n", offset);
			exit (1);
		}
	}
	unlink(filename);
	exit(0);
}
