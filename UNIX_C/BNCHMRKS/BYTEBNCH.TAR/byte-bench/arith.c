
/*******************************************************************************
 *  The BYTE UNIX Benchmarks - Release 2
 *          Module: arith.c   SID: 2.4 4/17/90 16:45:31
 *          
 *******************************************************************************
 * Bug reports, patches, comments, suggestions should be sent to:
 *
 *	Ben Smith or Rick Grehan at BYTE Magazine
 *	bensmith@bixpb.UUCP    rick_g@bixpb.UUCP
 *
 *******************************************************************************
 *  Modification Log:
 *  May 12, 1989 - modified empty loops to avoid nullifying by optimizing
 *                 compilers
 *
 ******************************************************************************/

char SCCSid[] = "@(#) @(#)arith.c:2.4 -- 4/17/90 16:45:31";
/*
 *  arithmetic test
 *
 */

main(argc, argv)
int	argc;
char	*argv[];
{
	int	iter;
	int	i;
	int result;

	if (argc != 2) {
		printf("Usage: %s count\n", argv[0]);
		exit(1);
	}

	iter = atoi(argv[1]);

	while (iter-- > 0) 
	{
	/* the loop calls a function to insure that something is done */
	/* the results of the function are thrown away. But a loop with */
	/* unused assignments may get optimized out of existence */
	result = dumb_stuff(i);
	}
	exit(0);
}


/************************** dumb_stuff *******************/
dumb_stuff(i)
int i;
{
#ifndef arithoh
	datum	x, y, z;
		z = 0;
#endif
		/*
		 *     101
		 * sum       i*i/(i*i-1)
		 *     i=2
		 */
		for (i=2; i<=101; i++) 
			{
#ifndef arithoh
			x = i;
			y = x*x;
			z += y/(y-1);
			}
return(x+y+z);
#else
			}
return(0);
#endif
}
