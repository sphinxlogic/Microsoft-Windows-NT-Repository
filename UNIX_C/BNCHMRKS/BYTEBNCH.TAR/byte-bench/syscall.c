/*******************************************************************************
 *  The BYTE UNIX Benchmarks - Release 2
 *          Module: syscall.c   SID: 2.4 4/17/90 16:45:36
 *          
 *******************************************************************************
 * Bug reports, patches, comments, suggestions should be sent to:
 *
 *	Ben Smith or Rick Grehan at BYTE Magazine
 *	bensmith@bixpb.UUCP    rick_g@bixpb.UUCP
 *
 *******************************************************************************
 *  Modification Log:
 *  $Header: syscall.c,v 3.4 87/06/22 14:32:54 kjmcdonell Beta $
 *
 ******************************************************************************/
char SCCSid[] = "@(#) @(#)syscall.c:2.4 -- 4/17/90 16:45:36";
/*
 *  syscall  -- sit in a loop calling the system
 *
 */

main(argc, argv)
int	argc;
char	*argv[];
{
	int	iter;
	int	i;

	if (argc != 2) {
		printf("Usage: %s count\n", argv[0]);
		exit(1);
	}

	iter = atoi(argv[1]);

	while (iter-- > 0) {
		close(dup(0));
		getpid();
		getuid();
		umask(022);
	}
	exit(0);
}
