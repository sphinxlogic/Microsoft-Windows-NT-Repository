/*******************************************************************************
 *  The BYTE UNIX Benchmarks - Release 2
 *          Module: mkperm.c   SID: 2.4 4/17/90 16:45:35
 *          
 *******************************************************************************
 * Bug reports, patches, comments, suggestions should be sent to:
 *
 *	Ben Smith or Rick Grehan at BYTE Magazine
 *	bensmith@bixpb.UUCP    rick_g@bixpb.UUCP
 *
 *******************************************************************************
 *  Modification Log:
 *  $Header: mkperm.c,v 1.2 87/06/22 14:32:26 kjmcdonell Beta $
 *
 ******************************************************************************/
char SCCSid[] = "@(#) @(#)mkperm.c:2.4 -- 4/17/90 16:45:35";
#include <stdio.h>
#ifndef lint
#endif

/* define rand and srand if you have random() from USENET */
/* #define rand random */
/* #define srand srandom */

main(argc, argv)
int	argc;
char	*argv[];
{
	int	n;	/* generate a permutation of {1,2,3,...,n} */
	int	i;
	int	t;
	char	*mask;

	if (argc > 2 && strcmp(argv[1], "-s") == 0) {
		t = atoi(argv[2]);
		if (t < 16)
			t = 1 << t;
		srand(t);
		argv++;
		argv++;
	}
	n = atoi(argv[1]);
	mask = (char *)malloc(n);

	for (i=0; i<n; i++)
		mask[i] = '\0';
	for (i=0; i<n; i++) {
		do {
			t = rand() % n;
		} while (mask[t]);
		mask[t] = '\1';
		printf("%d ", t+1);
	}
	putchar('\n');
	exit(0);
}
