#! /bin/sh
###############################################################################
#  The BYTE UNIX Benchmarks - Release 2
#          Module: multi.sh   SID: 2.3 4/17/90 16:45:41
#          
###############################################################################
# Bug reports, patches, comments, suggestions should be sent to:
#
#	Ben Smith or Rick Grehan at BYTE Magazine
#	ben@bytepb.UUCP    rick_g@bytepb.UUCP
#
###############################################################################
#  Modification Log:
#
###############################################################################
ID="@(#)multi.sh:2.3 -- 4/17/90 16:45:41";
for i
do
	/bin/sh $BINDIR/tst.sh &
done
wait

