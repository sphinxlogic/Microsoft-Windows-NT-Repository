#include "makework.h"
#ifndef lint
static char RCSid[] = "$Header: getwork.c,v 1.3 87/06/23 17:01:47 kjmcdonell Beta $";
#endif

/*
 * Build data structures (work[0] ... work[want-1]) for the next set
 * of job streams.
 */

stream work[MAXSTREAM];

typedef struct st_cmd {
    char	*name;		/* pathname of the command */
    char	**argv;		/* command argv[] vector */
    struct st_cmd	*next;
} cmd;

typedef struct st_scr {
    char	*name;		/* name of the script file */
    char	*buf;		/* the text of the script */
    int		blen;		/* size of buf[] */
    struct st_scr	*next;
} scr;

static cmd	*cmd_head = (cmd *)0, *cmdp;
static scr	*scr_head = (scr *)0, *scrp;

getwork(want)
int	want;
{
    int		i;
    int		f;
    int		ac;
    char	*lp;
    char	*q;
    stream	*w;
    char	line[512];
    char	c;
    int		nwork = 0;
    int		new;
    char	*malloc(), *realloc();

    while (nwork < want) {
	if (gets(line) == NULL) {
	    fprintf(stderr, "Insufficient job streams in the workload file\n");
	    fflush(stderr);
	    exit(4);
	}
	if (nwork >= MAXSTREAM) {
	    fprintf(stderr, "makework: internal snark -- code is broken!\n");
	    fflush(stderr);
	    exit(4);
	}
	w = &work[nwork];
	q = lp = line;
	i = 1;
	while (*q && *q != ' ') {
	    i++;
	    q++;
	}
	*q = '\0';
	if (w->home != (char *)0)
	    free(w->home);
	w->home = (char *)malloc(strlen(lp)+1);
	strcpy(w->home, lp);

	lp = ++q;
	i = 1;
	while (*q && *q != ' ') {
	    i++;
	    q++;
	}
	*q++ = '\0';
	new = 0;
	for (cmdp = cmd_head; cmdp != (cmd *)0; cmdp = cmdp->next) {
	    if (strcmp(cmdp->name, lp) == 0)
		break;
	}
	if (cmdp == (cmd *)0) {
	    cmdp = (cmd *)malloc(sizeof(*cmdp));
	    cmdp->next = cmd_head;
	    cmd_head = cmdp;
	    cmdp->name = (char *)malloc(strlen(lp)+1);
	    strcpy(cmdp->name, lp);
	    new = 1;
	    lp = q;
	    /* start to build arg list */
	    ac = 2;
	    cmdp->argv = (char **)malloc(2*sizeof(char *));
	    q = cmdp->name;
	    while (*q) q++;
	    q--;
	    while (q >= cmdp->name) {
		if (*q == '/') {
		    q++;
		    break;
		}
		q--;
	    }
	    cmdp->argv[0] = q;
	}
	else
	    lp = q;
	w->cmd = cmdp->name;
	w->av = cmdp->argv;
	w->blen = 0;
	w->buf = "";
	w->tty = "";

	while (*lp) {
	    if (*lp == ' ') {
		/* space */
		lp++;
		continue;
	    }
	    else if (*lp == '>') {
		/* standard output for this job */
		q = ++lp;
		while (*q && *q != ' ')
		    q++;
		c = *q;
		*q = '\0';
		if (w->tty != (char *)0)
		    free(w->tty);
		w->tty = (char *)malloc(strlen(lp)+1);
		strcpy(w->tty, lp);
		*q = c;
		lp = q;
	    }
	    else if (*lp == '<') {
		/* standard input for this job */
		q = ++lp;
		while (*q && *q != ' ') q++;
		c = *q;
		*q = '\0';
		for (scrp = scr_head; scrp != (scr *)0; scrp = scrp->next) {
		    if (strcmp(scrp->name, lp) == 0)
			break;
		}
		if (scrp == (scr *)0) {
		    scrp = (scr *)malloc(sizeof(*scrp));
		    scrp->next = scr_head;
		    scr_head = scrp;
		    scrp->name = (char *)malloc(strlen(lp)+1);
		    strcpy(scrp->name, lp);
		    if ((f = open(lp, 0)) == -1) {
			fprintf(stderr, "cannot open input file \"%s\"\n", lp);
			fflush(stderr);
			exit(4);
		    }
		    /* gobble input */
		    scrp->buf = (char *)malloc(512);
		    while ((i = read(f, &scrp->buf[scrp->blen], 512)) > 0) {
			scrp->blen += i;
			scrp->buf = (char *)realloc(scrp->buf, scrp->blen+512);
		    }
		    scrp->buf = (char *)realloc(scrp->buf, scrp->blen);
		    close(f);
		}
		w->buf = scrp->buf;
		w->blen = scrp->blen;
		*q = c;
		lp = q;
	    }
	    else {
		/* a command option */
		q = lp;
		i = 1;
		while (*q && *q != ' ') {
		    q++;
		    i++;
		}
		if (new) {
		    ac++;
		    cmdp->argv = (char **)realloc(cmdp->argv, ac*sizeof(char *));
		    cmdp->argv[ac-2] = (char *)malloc(i);
		    strncpy(cmdp->argv[ac-2], lp, i-1);
		    cmdp->argv[ac-2][i-1] = '\0';
		}
		lp = q;
	    }
	}
	if (new)
	    cmdp->argv[ac-1] = (char *)0;
	    w->av = cmdp->argv;
	nwork++;
    }
}
