/*
 *  syscall  -- sit in a loop calling the system
 *
 *  $Header: syscall.c,v 3.4 87/06/22 14:32:54 kjmcdonell Beta $
 */

main(argc, argv)
int	argc;
char	*argv[];
{
	int	iter;
	int	i;

	if (argc != 2) {
		printf("Usage: %s count\n", argv[0]);
		exit(1);
	}

	iter = atoi(argv[1]);

	while (iter-- > 0) {
		close(dup(0));
		getpid();
		getuid();
		umask(022);
	}
	exit(0);
}
