/*
 *
 * Checks for tty accessability and bandwidth saturation.
 *
 * $Header: ttychk.c,v 3.6 87/06/22 14:32:58 kjmcdonell Beta $
 */

#include <stdio.h>
#include <sgtty.h>
#include <signal.h>

struct {
	int	baud;	/* baud rate */
	int	symb;	/* symbolic constant for baud rate */
} bmap[] = {
	{  300,  B300 },
	{ 1200, B1200 },
	{ 2400, B2400 },
	{ 4800, B4800 },
	{ 9600, B9600 },
	{    0,     0 }
};
int		status = 0;	/* exit() status */

main(argc, argv)
int	argc;
char	*argv[];
{
	struct sgttyb	ttyb;
	int		nusers;		/* number of simulated users */
	int		nscript;	/* number of script files */
	int		baud = 0;	/* aggregate baud rate across
					   active ttys */
	int		br;
	int		nttys;		/* number of active ttys */
	int		i;
	int		fd;
	int		l;
	float		orate;		/* estimated output rate per user */
        int		onalarm();

	if (argc < 5) {
		fprintf(stderr, "Usage: ttychk nusers orate nscript ttydev ... \n");
		exit(1);
	}
	nusers = atoi(argv[1]);
	if (nusers < 1) {
		fprintf(stderr, "ttychk: nusers must be > 0\n");
		status |= 1;
	}
	sscanf(argv[2], "%f", &orate);
	nscript = atoi(argv[3]);
	if (nscript < 1) {
		fprintf(stderr, "ttychk: nscript must be > 0\n");
		status |= 1;
	}

	nttys = nusers <= nscript ? nusers : nscript;

	signal(SIGALRM, onalarm);
	for (i = 4; i < argc && nttys; i++, nttys--) {
		alarm(3);
		if ((fd = open(argv[i], 1)) < 0) {
			fprintf(stderr, "ttychk: cannot open %s for writing\n",
				argv[i]);
			perror("");
			status |= 1;
			continue;
		}
		alarm(0);
		if (ioctl(fd, TIOCGETP, &ttyb) < 0) {
			fprintf(stderr, "ttychk: cannot stat %s\n",
				argv[i]);
			perror("");
			status |= 1;
			close(fd);
			continue;
		}
		close(fd);
		br = 0;
		for (l = 0; bmap[l].baud; l++) {
			if (bmap[l].symb == ttyb.sg_ospeed) {
				br = bmap[l].baud;
				break;
			}
		}
#ifdef DEBUG
		fprintf(stderr, "%s: %d baud\n", argv[i], br);
#endif
		if (br != 9600)
			fprintf(stderr, "ttychk: Warning - baud rate at %d for %s\n",
				br, argv[i]);
		baud += br;
	}
	nttys = nusers <= nscript ? nusers : nscript;
#ifdef DEBUG
	fprintf(stderr, "aggregate tty bandwidth: %d baud\n", baud);
	fprintf(stderr, "aggregate tty output rate: %d chars/sec (for %d ttys)\n", (int)(orate*nusers), nttys);
#endif

	/* assume 10 bits per character, and the 50% figure is arbitrary! */
	if (nusers*orate > 0.5*(baud/10)) {
		fprintf(stderr, "ttychk panic: Total tty output rate (%d chars/sec) exceeds 50%% of\n              total tty bandwidth (%d chars/sec)\n",
			(int)(nusers*orate), baud/10);
		status |= 1;
	}

	exit(status);
}

onalarm()
{
	status |= 1;
}
