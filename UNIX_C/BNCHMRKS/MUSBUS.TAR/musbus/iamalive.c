/*
 * echo argv[1] without \n, to tell user we are still alive
 *
 *  $Header: iamalive.c,v 3.4 87/06/22 14:23:22 kjmcdonell Beta $
 */
main(argc, argv)
int	argc;
char	*argv[];
{
	if (argc == 2)
		printf("%s ", argv[1]);
	exit(0);
}
