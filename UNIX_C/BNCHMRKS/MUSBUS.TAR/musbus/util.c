#include "makework.h"
#ifndef lint
static char RCSid[] = "$Header: util.c,v 1.3 87/06/23 15:56:41 kjmcdonell Beta $";
#endif

fatal(s)
char *s;
{
    int	i;
    fprintf(stderr, s);
    fflush(stderr);
    perror("Reason?");
    fflush(stderr);
    for (i = 0; i < nstream; i++) {
	if (work[i].pid > 0 && kill(work[i].pid, SIGKILL) != -1) {
	    fprintf(stderr, "pid %d killed off\n", work[i].pid);
	    fflush(stderr);
	}
    }
    exit_status = 4;
    return;
}

#ifdef DEBUG
dumpwork()
{
    int		i;
    int		j;

    for (i = 0; i < nstream; i++) {
	fprintf(stderr, "job %d: cmd: %s home: %s tty: %s\n",
		i, work[i].cmd, work[i].home, work[i].tty);
	j = 0;
	while (work[i].av[j]) {
		fprintf(stderr, "argv[%d]: %s\n", j, work[i].av[j]);
		j++;
	}
	fprintf(stderr, "input: %d chars text: ", work[i].blen);
	if (work[i].buf == (char *)0)
		fprintf(stderr, "<NULL>\n");
	else {
	        register char	*pend;
	        char		*p;
		char		c;
		p = work[i].buf;
		while (*p) {
			pend = p;
			while (*pend && *pend != '\n')
				pend++;
			c = *pend;
			*pend = '\0';
			fprintf(stderr, "%s\n", p);
			*pend = c;
			p = &pend[1];
		}
	}
    }
}
#endif
