/*
 *  pipe  -- test single process pipe throughput (no context switching)
 *
 *  $Header: pipe.c,v 3.5 87/06/22 14:32:36 kjmcdonell Beta $
 */

main(argc, argv)
int	argc;
char	*argv[];
{
	char	buf[512];
	int	iter = 2048;	/* 1M byte */
	int	pvec[2];

	pipe(pvec);
	close(0); dup(pvec[0]); close(pvec[0]);
	close(1); dup(pvec[1]); close(pvec[1]);

	while (iter-- > 0) {
		if (write(1, buf, sizeof(buf)) != sizeof(buf))
			perror("write failed");
		if (read(0, buf, sizeof(buf)) != sizeof(buf))
			perror("read failed");
	}
	exit(0);
}
