/*
 *  Execing
 *
 *  $Header: execl.c,v 3.5 87/06/22 15:37:08 kjmcdonell Beta $
 */

char	bss[8*1024];	/* something worthwhile */

#define main dummy
			/* some reasonable code etc. */
#include "big.c"

#undef main

main(argc, argv)	/* the real program */
int	argc;
char	*argv[];
{
	int	iter;
	char	count[6];

	if (argc != 2) {
		printf("Usage: %s count\n", argv[0]);
		exit(1);
	}

	iter = atoi(argv[1]);

	if (iter) {
		sprintf(count, "%d", --iter);
		execl("./execl", "execl", count, 0);
		printf("Exec failed at iteration %d\n", iter);
		perror("Reason");
		exit(1);
	}
	exit(0);
}
