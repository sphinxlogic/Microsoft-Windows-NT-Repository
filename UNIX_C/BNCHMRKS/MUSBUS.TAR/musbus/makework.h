#include <stdio.h>
#include <signal.h>
/* $Header: makework.h,v 1.4 87/06/24 08:33:56 kjmcdonell Beta $ */

#define MAXSTREAM	12

typedef struct st_stream {
	char	*home;		/* home dir for job stream */
	char	*cmd;		/* name of command to run */
	char	**av;		/* arguments to command */
	char	*buf;		/* standard input buffer */
	int	blen;		/* size of standard input buffer */
	int	xmit;		/* # characters sent */
	char	*bp;		/* std input buffer pointer */
	char	*tty;		/* standard output (filename) */
	int	fd;		/* stdin to command */
	int	pid;		/* PID of stream command */
	char	*line;		/* start of input line */ 
} stream;

extern stream work[];

extern int	nstream;	/* number of concurrent streams to be
				 * simulated by this process */
extern int	exit_status;	/* returned to parent */
