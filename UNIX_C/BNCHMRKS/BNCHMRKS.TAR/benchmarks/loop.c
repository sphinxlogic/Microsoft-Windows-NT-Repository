main()
{
	long i;
	for (i=0; i <1000000L; ++i)
		;
	exit(0);
}
