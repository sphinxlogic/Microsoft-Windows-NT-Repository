#define BLOCKS 1024
char buffer[512];
int	fid[2];
main()
{
	register int i;
	pipe(fid);
	if (fork()){
		for (i = 0; i < BLOCKS; ++i)
			if (write(fid[1], buffer, 512) < 0)
				printf("Error in writing; i=%d\n", i);
		if (close(fid[1]) != 0)
			printf("Error in parent closing\n");
	}
	else {
		if (close(fid[1]) != 0)
			printf("Error in child closing\n");
		for(;;)
			if (read(fid[0], buffer, 512) == 0) {
				break;
			}
	}
	exit(0);
}
