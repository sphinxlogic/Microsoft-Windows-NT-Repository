#define CONST1	3.141597E0
#define CONST2	1.7839032E4
#define	COUNT	10000
#define REG	

main()
{
	double	a, b, c;
	REG int	i;

	a = CONST1;
	b = CONST2;
	for (i = 0; i < COUNT; ++i)
	{
		c = a * b;
		c = c / a;
		c = a * b;
		c = c / a;
		c = a * b;
		c = c / a;
		c = a * b;
		c = c / a;
		c = a * b;
		c = c / a;
		c = a * b;
		c = c / a;
		c = a * b;
		c = c / a;
	}
	printf("Done\n");
	exit(0);
}
