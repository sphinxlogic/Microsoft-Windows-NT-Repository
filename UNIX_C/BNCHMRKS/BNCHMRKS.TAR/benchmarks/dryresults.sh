#
#	Pick out just the results lines from the dry.c source file
#
sed -e '1,/RESULTS BEGIN/d' -e '/RESULTS END/,$d' <dry.c >dry.results
