/* do_allbench - run all the benchmark programs */
#include <stdio.h>
#define NBENCHES 6
#define TIME_FMT "Current time is %lf:%lf:%lf"
#define CPUTIME_MIN 10000.
static struct timing
	{
	double cputime; char *fname; char *title1; char *title2;
	} timings[NBENCHES] =
	{
	0., "benchreg",	"register",	"int",
	0., "benchsho",	"auto",		"short",
	0., "benchlng",	"auto",		"long",
	0., "benchmul",	"integer",	"multiply",
	0., "benchfn",	"function",	"call",
	0., "benchdbl",	"auto",		"double",
	};
static char cc_cmd[BUFSIZ] = {0};
static char command[BUFSIZ] = {0};
int compile(fname)
	char *fname;
	{
	sprintf(command, cc_cmd, fname);
	return (system(command));
	}
int mk_crlf()
	{
	FILE *crlf;

	crlf = fopen("cr-lf", "w");
	if (crlf == NULL)
		{
		fprintf(stderr, "unable to create file  crlf\n");
		exit(2);
		}
	putc('\n', crlf);
	fclose(crlf);
	}
double rd_time(tmpname)
	char *tmpname;
	{
	FILE *fp;
	double hrs, mins, secs;

	fp = fopen(tmpname, "r");
	fgets(buf, sizeof(buf), fp);
	sscanf(buf, TIME_FMT, &hrs, &mins, &secs);
	fclose(fp);
	return (1000 * (secs + 60 * (mins + 60 * hrs));
	}
double time_it(fname, iterations)
	char *fname;
	long iterations;
	{
	double t0, t1;

	sprintf(command, "time <cr-lf >t0");
	system(command);
	t0 = rd_time("t0");
	sprintf(command, "%s %ld", fname, iterations);
	system(command);
	sprintf(command, "time <cr-lf >t1");
	system(command);
	t1 = rd_time("t1");
	return (t1 - t0);
	}
double run(fname, major)
	char *fname;
	long major;
	{
	double t_empty, t_major;

	t_empty = time_it(fname, 0L);
	t_major = time_it(fname, major);
	return (t_major - t_empty);
	}
double do_all(fname)
	char *fname;
	{
	double cputime;
	long major;

	compile(fname);
	major = MAJOR_MIN;
	do {
		cputime = run(fname, major);
		major *= 10;
		} while (cputime < CPUTIME_MIN);
	return (cputime / major);
	}
main(ac, av)
	int ac;
	char *av[];
	{
	int i;

	strcpy(cc_cmd, av[1]);
	for (i = 0; i <= NBENCHES; ++i)
		timings[i].cputime = do_all(timings[i].fname);
	printf("\n\n\nRESULTS:\n\n");
	for (i = 0; i <= NBENCHES; ++i)
		printf("%10s  ", timings[i].title1;
	printf(\n");
	for (i = 0; i <= NBENCHES; ++i)
		printf("%10s  ", timings[i].title2;
	printf(\n");
	for (i = 0; i <= NBENCHES; ++i)
		printf("%10.4f  ", timings[i].cputime);
	printf("\n\n(All times are in microseconds\n");
	}
