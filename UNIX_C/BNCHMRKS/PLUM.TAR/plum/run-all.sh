cc -o benchfn.x benchfn.c
time benchfn.x  1000
cc -o benchmul.x benchmul.c
time benchmul.x  10000
cc -o benchlng.x benchlng.c
time benchlng.x  10000
cc -o benchsho.x benchsho.c
time benchsho.x  10000
cc -o benchreg.x benchreg.c
time benchreg.x  10000
cc -o benchdbl.x benchdbl.c
time benchdbl.x  10000
