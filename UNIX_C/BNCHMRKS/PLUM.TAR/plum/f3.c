/* f3 - lowest level function
 * Put this in separate source file if compiler detects and optimizes
 * useless code
 */
f3() { }
