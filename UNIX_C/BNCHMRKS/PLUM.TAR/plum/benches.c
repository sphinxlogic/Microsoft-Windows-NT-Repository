/* benches - driver for Plum Hall benchmarks */
#include <stdio.h>
#include <time.h>

int benchreg(), benchsho(), benchlng();
int benchmul(), benchfn(), benchdbl();

void tabulate();
char *fround();
main(argc, argv)
	int argc;
	char *argv[];
	{
	char result[6][10];
	int i;

	if (argv[1][0] != '1')
		printf("argv[1] must be   1   !\n");
	if (argc < 3)
		{
		fprintf(stderr, "usage: benches 1 'compiler-id'\n");
		exit(2);
		}
	tabulate(benchreg, result[0]);
	tabulate(benchsho, result[1]);
	tabulate(benchlng, result[2]);
	tabulate(benchmul, result[3]);
	tabulate(benchfn,  result[4]);
	tabulate(benchdbl, result[5]);
	printf("\n\n");
	printf("%20.20s %9s %9s %9s %9s %9s %9s\n",
		"", "register", "auto", "auto", "int", "function", "auto");
	printf("%20.20s %9s %9s %9s %9s %9s %9s\n",
		"", "int", "short", "long", "multiply", "call+ret", "double");
	printf("%22.22s ",
		argv[2]);
	for (i = 0; i <= 5; ++i)
		printf("%9.9s ", result[i]);
	printf("\n");
	exit(0);
	}
void tabulate(fn, s)
	void (*fn)();
	char *s;
	{
	static char arg1[20];
	static char *arga[3] = { "x", &arg1[0], 0 };
	double before, after, microsec;
	long major, major_next;

	major_next = 1;
	do  {
		major = major_next;
		sprintf(arg1, "%ld", major);
		before = (double)clock();
		(*fn)(2, arga);
		after = (double)clock();
		major_next *= 10;
		} while (after-before < 100);
	microsec = 1e3 * (after - before) / CLOCKS_PER_SEC / major;
	sprintf(s, "%9s ", fround(microsec, 5, 3));
	}

/* fround - round double x to precision p, n significant digits
 * uses static string for result - not re-entrant
 * fround is an accomodation for K+R-level printf which lacks %.*e or %g
 * slow, fat version - uses sprintf
 */
#include <stdio.h>
char *fround(x, p, n)
    double x;
    short p;
    short n;
    {
    double y;
    double log10();
    short digs;
    short nlog;
    static char s[40] = {0};
    char fmt[20];

    sprintf(fmt, "%%.%de", n-1);
    sprintf(s, fmt, x);
    sscanf(s, "%lf", &y);
    if (y == 0)
        nlog = 0;
    else
        nlog = log10(y);
    if (nlog < 0)
        --nlog;
    digs = n - nlog - 1;
    if (digs < 0)
        digs = 0;
    else if (digs > p)
        digs = p;
    sprintf(fmt, "%%.%df", digs);
    sprintf(s, fmt, y);
    if (digs == 0)
        strcat(s, ".");
    while (digs++ < p)
        strcat(s, " ");
    return (s);
    }




#define main benchreg
#include "benchreg.c"

#undef main
#undef STOR_CL
#undef TYPE
#define main benchsho
#include "benchsho.c"

#undef main
#undef STOR_CL
#undef TYPE
#define main benchlng
#include "benchlng.c"

#undef main
#undef STOR_CL
#undef TYPE
#define main benchmul
#include "benchmul.c"

#undef main
#undef STOR_CL
#undef TYPE
#define main benchfn
#include "benchfn.c"

#undef main
#undef STOR_CL
#undef TYPE
#define main benchdbl
#include "benchdbl.c"
