/* benchreg - benchmark for  register  integers 
 * Thomas Plum, Plum Hall Inc, 609-927-3770
 * If machine traps overflow, use an  unsigned  type 
 * Let  T  be the execution time in milliseconds
 * Then  average time per operator  =  T/major  usec
 * (Because the inner loop has exactly 1000 operations)
 */
#define STOR_CL register
#define TYPE int
#include <stdio.h>
main(ac, av)
        int ac;
        char *av[];
        {
        STOR_CL TYPE a, b, c;
        long d, major, atol();
        static TYPE m[10] = {0};

        major = atol(av[1]);
        printf("executing %ld iterations\n", major);
        a = b = (av[1][0] - '0');
        for (d = 1; d <= major; ++d)
                {
                /* inner loop executes 1000 selected operations */
                for (c = 1; c <= 40; ++c)
                        {
                        a = a + b + c;
                        b = a >> 1;
                        a = b % 10;
                        m[a] = a;
                        b = m[a] - b - c;
                        a = b == c;
                        b = a | c;
                        a = !b;
                        b = a + c;
                        a = b > c;
                        }
                }
        printf("a=%d\n", a);
        }
