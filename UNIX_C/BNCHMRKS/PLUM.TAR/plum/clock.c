/* clock - primitive version of ANSI 'clock' function for UNIX */
long clock()
	{
	struct tbuff { long pu; long ps; long cu; long cs; } tbuff;

	times(&tbuff);
	return(tbuff.pu + tbuff.ps);
	}
