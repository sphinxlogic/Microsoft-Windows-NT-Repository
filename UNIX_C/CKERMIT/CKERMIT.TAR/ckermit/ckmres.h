/* Version 0.8(35) - Jim Noble at Planning Research Corporation, June 1987. */
/* Ported to Megamax native Macintosh C compiler. */

/* ckmres.h - MAC C Kermit resource file equates */

#define RCMDBOXID 1000
#define RCMDHSCROLL 1001
#define RCMDVSCROLL 1000

#define ALERT_ERROR 1			/* error aler */
#define ALERT_DEBUG 2			/* debug alert */
#define ALERT_ABORT 3			/* abort protocol */
#define ALERT_FEXIST 4			/* alert: file exists */

/* MENUS */

#define MIN_MENU 1			/* first menu resource ID  */

#define APPL_MENU 1			/* APPLE: */
#define  ABOUT_APL 1			/*  about kermit */

#define FILE_MENU 2			/* FILE: */
#define  LOAD_FIL 1			/*  load settings */
#define  SAVE_FIL 2			/*  save settings */
					/*  (- (leave a space) */
#define  GETS_FIL 4			/*  get a file from server */
#define  SEND_FIL 5			/*  send a file */
#define  RECV_FIL 6			/*  receive a file */
					/*  (- (leave a space) */
#define  QUIT_FIL 8			/*  quit this program */

#define SETG_MENU 3			/* SETTINGS: */
#define  FILE_SETG 1			/*  file settings */
#define  COMM_SETG 2			/*  communications settings */
#define  PROT_SETG 3			/*  protocol settings */
					/* (- (leave a space) */
#define  SCRD_SETG 5			/*  screen dumping... */

#define REMO_MENU 4			/* REMOTE: */
#define  RESP_REMO 1			/*  show/hide response window */
					/* (- (leave a space) */
#define  FIN_REMO 3			/*  finish, exit remote server */
#define  BYE_REMO 4			/*  bye (log out server) */
					/* (- (leave a space) */
#define  CWD_REMO 6			/*  cwd - change working directory */
#define  DEL_REMO 7			/*  delete remote file */
#define  DIR_REMO 8			/*  remote directory */
#define  HELP_REMO 9			/*  remote help */
#define  HOST_REMO 10			/*  arbitrary command */
#define  SPAC_REMO 11			/*  disk usage */
#define  TYPE_REMO 12			/*  type a file */
#define  WHO_REMO 13			/*  who is logged in */
					/* (- */
#define  SERV_REMO 15			/* be a server */

#define LAU_MENU 5			/* LAUNCH: */
#define  TOAP_LAU 1			/*  run application */

#define MAX_MENU LAU_MENU		/* last menu resource id */

/* DLOG 257 - About Kermit */

#define ABOUTID 257			/* ID of dialog in resource file */

/* DLOG 230 - Status display (during transfer) */

#define SCRBOXID 230			/* resource ID for status display */

#define SRES_UNDEF 1			/* do nothing guy */
#define  SRES_CANF 1			/* cancel xmit of single file */
#define  SRES_CANG 2			/* cancel xmit of entire group */
#define  SRES_DIR 3			/* "receiving" or "sending" */
#define  SRES_FILN 4			/* filename goes here */
#define  SRES_AS 5			/* "as" or blank */
#define  SRES_AFILN 6			/* as filename or blank */
#define  SRES_KXFER 8			/* numeric for "Kbytes" */
#define  SRES_NPKT 10			/* numeric for "Packets" */
#define  SRES_NRTY 12   		/* numeric for "Retries" */
#define  SRES_FFORK 13			/* "RSRC FORK" or "DATA FORK" */
#define  SRES_FMODE 14			/* "TEXT MODE" or "BINARY MODE" */
#define  SRES_BTEXT 15			/* arbitrary big text */

/* DLOG 1001 - Communications setup dialog */

#define COMMBOXID 1001			/* resource ID for comm setup */
#define CR_BAUD300 5
#define CR_BAUD600 6
#define CR_BAUD1200 7
#define CR_BAUD1800 8
#define CR_BAUD2400 9
#define CR_BAUD4800 10
#define CR_BAUD7200 11
#define CR_BAUD9600 12
#define CR_BAUD19200 13
#define CR_BAUD57600 14

#define CR_WRAPON 16
#define CR_WRAPOFF 17

#define CR_PARMARK 19
#define CR_PARSPACE 20
#define CR_PAREVEN 21
#define CR_PARODD 22
#define CR_PARNONE 23

#define CR_ECHOLCL 25			/* local echo - full duplex */
#define CR_ECHOREM 26			/* local echo - half duplex */

/* DLOG 1002 - Protocol setup dialog */

#define PROTOBOXID 1002

#define PR_BLK1 5			/* block check types */
#define PR_BLK2 6
#define PR_BLK3 7

#define PR_HSBELL 9			/* hand shake character */
#define PR_HSCR 10
#define PR_HSESC 11
#define PR_HSLF 12
#define PR_HSNONE 13
#define PR_HSXON 14
#define PR_HSXOFF 15

#define PR_INSOP 19			/* start of packet edit text */
#define PR_INEOP 21			/* end of packet edit text */
#define PR_INPADC 23			/* pad character edit text */
#define PR_INPADN 25			/* pad count edit text */
#define PR_INTIMEO 27			/* seconds timeout edit text */
#define PR_INPKTLEN 29			/* packet length edit text */

#define PR_OUTSOP 30			/* start of packet edit text */
#define PR_OUTEOP 31			/* end of packet edit text */
#define PR_OUTPADC 32			/* pad character edit text */
#define PR_OUTPADN 33			/* pad count edit text */
#define PR_OUTTIMEO 34			/* seconds timeout edit text */
#define PR_OUTPKTLEN 35			/* packet length edit text */

/* DLOG 1003 - remote dialog */

#define REMOTEBOXID 1003
#define RRES_ARG1 5
#define RRES_ARG2 7

