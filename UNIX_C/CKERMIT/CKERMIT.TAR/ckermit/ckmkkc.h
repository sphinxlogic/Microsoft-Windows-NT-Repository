/* CKMKER version 0.8(35)/CKMKEY version 0.8(7) - Jim Noble at Planning */
/* Research Corporation, June 1987.  Ported to Megamax native Macintosh C */
/* compiler. */

/*
 * CKMKKC.H 
 *
 * This file contains common definitions for keyboard configuration
 * used between CKMKEY and CKMKER.
 *
 * Bill Schilit, May 1985
 *
 *
 * Copyright (C) 1985, Trustees of Columbia University in the City of
 * New York.  Permission is granted to any individual or institution to
 * use, copy, or redistribute this software so long as it is not sold
 * for profit, provided this copyright notice is retained.
 *
 */

#define KSVER 2				/* current version number */

/* KSET is the KSET structure present in settings files */
/* FSET is the indexed string type holding function key definitions */
/* MSET is the simple (pascal) string with the meta prefix string */

extern char KSET_TYPE[],FSET_TYPE[],MSET_TYPE[];

#define MAX_SCODE 127			/* max scan code */

typedef struct {
    LONGINT
	ctrlmods,			/* modifiers which cause control */
	metamods,			/* modifiers which cause meta */
	caplmods;			/* modifiers which cause caps */
    CHAR
	normmap[2][MAX_SCODE],		/* lower/upper normal map */
	caplmap[2][MAX_SCODE],		/* lower/upper shift lock map  */
	ctrlmap[2][MAX_SCODE];		/* lower/upper control map */
    Handle
	fcnshdl,			/* handle to functions */
	metahdl;			/* handle to meta string */
    BOOLEAN
	meta8bit;			/* use 8-bit for meta */
} KSET;

typedef KSET **KSHDL;

extern KSHDL kshdl;			/* handle on key set */

#define FKEYBIT 0200			/* high bit means function key */
#define METABIT 0200			/* turned on for meta */

  					/* special functions: */
#define SPFSBRK 0176			/*  short break */
#define SPFLBRK 0177			/*  long break */

/* number of user programmable functions, which is 0-0175, 0-125. 
 * thats 0177 less specials defined above.
 */

#define NFKEYS (0177-2+1)

#define LC_IDX 0			/* use lower case map */
#define UC_IDX 1			/* use upper case map */
#define MOD_MASK (alphaLock | cmdKey | optionKey | shiftKey)  /* modifers */

/*
 * ScrDmpEnb is a flag byte used by the toolbox event manager to say
 * whether command-shift-1 through command-shift-9 do anything special
 * like dump the screen, eject the diskettes, etc.  This byte is used in
 * INIT0, the keyboard mapping routine (see IM index under scrdmpenb).
 *
 * N.B: The location of this value may change if MAC comes out with a
 * new SYSTEM.
 *
 */

#define ScrDmpEnb (*(unsigned char *) 0x2f8)
#define scrdmpenabled ((unsigned char) 0xff)
#define scrdmpdisabled ((unsigned char) 0x00)

