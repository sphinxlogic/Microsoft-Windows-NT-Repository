/* Version 0.8(35) - Jim Noble at Planning Research Corporation, June 1987. */
/* Initial version of this file. */

/*
 * CKMSYS.H
 * 
 * This file is for #define's, typedef's, etc. that are used in the code to hide
 * differences among Macintosh C compilers. 
 * 
 * This file is used by both MacKermit and the Macintosh keyboard configuration
 * utility.  As such, it should not contain anything which is specific to either
 * program (e.g. extern's, etc.), only those definitions which are used to hide
 * differences among Macintosh C compilers. 
 */

/*
 * This section is used to compensate for differences in definitions between
 * Inside Macintosh and the .h files provided with a development system.
 * Definitions should be removed from this section as they are corrected in or
 * added to the development system's .h files.  Eventually, this section should
 * not be necessary at all. 
 */

#if MEGAMAX
/* These symbols are not defined in the Megamax V3.0 .h files. */ 

#define dirFulErr 	-33
#define dskFulErr 	-34
#define dupFNErr 	-48
#define eofErr 		-39
#define fBsyErr 	-47
#define fDesktop 	-2
#define fLckdErr 	-45
#define fnfErr 		-43
#define nsvErr 		-35
#define opWrErr 	-49
#define vLckdErr 	-46
#define wPrErr 		-44
#endif

#ifdef SUMACC
/* These symbols are not defined in the SUMACC .h files. */ 

#define bold		1
#define italic		2
#define underline	4
#define outline		8
#define shadow		16
#define condense	32
#define extend		64

/* 
 * This corrects the SUMACC definition of AppFile which declares fName as
 * fName[1] instead of fName[256].  A #define is used instead of a typedef to
 * avoid a duplicate type definition and to allow use of "AppFile" instead of
 * "myAppFile" or some other new name. 
 */

#define AppFile struct {	\
	INTEGER	vRefNum;	\
	OsType	fType;		\
	INTEGER	versNum;	\
	char	fName[256];	\
}
#endif

/*
 * The following typedefs should be defined with the appropriate size data type
 * so that LONGINT, INTEGER and BOOLEAN match the size of the Pascal types of
 * the same names that are used in Inside Macintosh. 
 */

#if MEGAMAX
typedef long	LONGINT;		/* Pascal LONGINT	*/
typedef int	INTEGER;		/* Pascal INTEGER	*/
typedef short	BOOLEAN;		/* Pascal BOOLEAN	*/
#endif

#ifdef SUMACC
typedef long	LONGINT;		/* Pascal LONGINT	*/
typedef short	INTEGER;		/* Pascal INTEGER	*/
typedef char	BOOLEAN;		/* Pascal BOOLEAN	*/
#endif

/* SYM for debugging, place at end of subroutine AFTER return */

#if MEGAMAX
#define SYM(x)	{}
#endif

#ifdef SUMACC
#define SYM(x) { \
   asm("unlk a6"); \
   asm("rts"); \
   asm(".asciz 'x'"); \
   asm(".even"); }
#endif

/*
 * C string to Pascal string (CTOPSTR) and Pascal string to C string (PTOCSTR)
 * conversion routines.  Both routines are assumed to take the address of a
 * string as an argument and convert the string in place. 
 */

#if MEGAMAX
#define CTOPSTR(string)	ctopstr (string)
#define PTOCSTR(string)	ptocstr (string)
#endif

#ifdef SUMACC
#define CTOPSTR(string)	c2pstr (string)
#define PTOCSTR(string)	p2cstr (string)
#endif

/*
 * This section is for symbols to hide implementation differences where C
 * doesn't map well to the Pascal data type definitions.  In particular, where C
 * structs and unions don't map exactly to Pascal variant records. 
 */

#if MEGAMAX
/* Point components: */
#define V		a.v
#define H		a.h

/* Rect components: */
#define TOP		a.top
#define LEFT		a.left
#define BOTTOM		a.bottom
#define RIGHT		a.right
#define TOPLEFT		b.topLeft
#define BOTRIGHT	b.botRight

/* QuickDraw global variables: */
#define THEPORT		thePort		/* 'thePort' */
#define WHITE		white		/* Address of 'white' */
#define BLACK		black		/* Address of 'black' */
#define GRAY		gray		/* Address of 'gray' */
#define LTGRAY		ltGray		/* Address of 'ltGray' */
#define DKGRAY		dkGray		/* Address of 'dkGray' */
#define ARROW		&arrow		/* Address of 'arrow' */
#define SCREENBITS	&screenBits	/* Address of 'screenBits' */
#define RANDSEED	randSeed	/* 'randSeed' */

/* Prefix necessary to pass OsType and ResType variables by address */
#define TYPE_ADDR			/* Nothing; OsType and ResType are arrays */

/* fileParam variant of ParamBlockRec and components: */
typedef ParamBlockRec	FILEPARAM;
#define IOFREFNUM	paramunion.fileParam.ioFRefNum 
#define IOFVERSNUM	paramunion.fileParam.ioFVersNum 
#define FILLER1		paramunion.fileParam.filler1 
#define IOFDIRINDEX	paramunion.fileParam.ioFDirIndex 
#define IOFLATTRIB	paramunion.fileParam.ioFlAttrib 
#define IOFLVERSNUM	paramunion.fileParam.ioFlVersNum 
#define IOFLFNDRINFO	paramunion.fileParam.ioFlFndrInfo 
#define IOFLNUM		paramunion.fileParam.ioFlNum 
#define IOFLSTBLK	paramunion.fileParam.ioFlStBlk 
#define IOFLLGLEN	paramunion.fileParam.ioFlLgLen 
#define IOFLPYLEN	paramunion.fileParam.ioFlPyLen 
#define IOFLRSTBLK	paramunion.fileParam.ioFlRStBlk 
#define IOFLRLGLEN	paramunion.fileParam.ioFlRLgLen 
#define IOFLRPYLEN	paramunion.fileParam.ioFlRPyLen 
#define IOFLCRDAT	paramunion.fileParam.ioFlCrDat 
#define IOFLMDDAT	paramunion.fileParam.ioFlMdDat 

/* ioParam variant of ParamBlockRec and components: */
typedef ParamBlockRec	IOPARAM;
#define IOREFNUM	paramunion.ioParam.ioRefNum
#define IOVERSNUM	paramunion.ioParam.ioVersNum
#define IOPERMSSN	paramunion.ioParam.ioPermssn
#define IOMISC		paramunion.ioParam.ioMisc
#define IOBUFFER	paramunion.ioParam.ioBuffer
#define IOREQCOUNT	paramunion.ioParam.ioReqCount
#define IOACTCOUNT	paramunion.ioParam.ioActCount
#define IOPOSMODE	paramunion.ioParam.ioPosMode
#define IOPOSOFFSET	paramunion.ioParam.ioPosOffset

/* volumeParam variant of ParamBlockRec and components: */
typedef ParamBlockRec	VOLUMEPARAM;
#define FILLER2		paramunion.volumeParam.filler2
#define IOVOLINDEX	paramunion.volumeParam.ioVolIndex
#define IOVCRDATE	paramunion.volumeParam.ioVCrDate
#define IOVLSBKUP	paramunion.volumeParam.ioVLsBkUp
#define IOVATRB		paramunion.volumeParam.ioVAtrb
#define IOVNMFLS	paramunion.volumeParam.ioVNmFls
#define IOVDIRST	paramunion.volumeParam.ioVDirSt
#define IOVBLLN		paramunion.volumeParam.ioVBlLn
#define IOVNMALBLKS	paramunion.volumeParam.ioVNmAlBlks
#define IOVALBLKSIZ	paramunion.volumeParam.ioVAlBLkSiz
#define IOVCLPSIZ	paramunion.volumeParam.ioVClpSiz
#define IOALBLST	paramunion.volumeParam.ioAlBlSt
#define IOVNXTFNUM	paramunion.volumeParam.ioVNxtFNum
#define IOVFRBLK	paramunion.volumeParam.ioVFrBlk
#endif

#ifdef SUMACC
/* Point components: */
#define V		v
#define H		h

/* Rect components: */
#define TOP		top
#define LEFT		left
#define BOTTOM		bottom
#define RIGHT		right
#define TOPLEFT		topLeft
#define BOTRIGHT	botRight

/* QuickDraw global variables: */
#define THEPORT		thePort		/* 'thePort' */
#define WHITE		&QD->white	/* Address of 'white' */
#define BLACK		&QD->black	/* Address of 'black' */
#define GRAY		&QD->gray	/* Address of 'gray' */
#define LTGRAY		&QD->ltGray	/* Address of 'ltGray' */
#define DKGRAY		&QD->dkGray	/* Address of 'dkGray' */
#define ARROW		&QD->arrow	/* Address of 'arrow' */
#define SCREENBITS	&QD->screenBits	/* Address of 'screenBits' */
#define RANDSEED	QD->randSeed	/* 'randSeed' */

/* Prefix necessary to pass OsType and ResType variables by address */
#define TYPE_ADDR	&		/* "&"; OsType and ResType are struct's */

/* fileParam variant of ParamBlockRec and components: */
typedef FileParam	FILEPARAM;
#define IOFREFNUM	ioFRefNum 
#define IOFVERSNUM	ioFVersNum 
#define FILLER1		filler1 
#define IOFDIRINDEX	ioFDirIndex 
#define IOFLATTRIB	ioFlAttrib 
#define IOFLVERSNUM	ioFlVersNum 
#define IOFLFNDRINFO	ioFlFndrInfo 
#define IOFLNUM		ioFlNum 
#define IOFLSTBLK	ioFlStBlk 
#define IOFLLGLEN	ioFlLgLen 
#define IOFLPYLEN	ioFlPyLen 
#define IOFLRSTBLK	ioFlRStBlk 
#define IOFLRLGLEN	ioFlRLgLen 
#define IOFLRPYLEN	ioFlRPyLen 
#define IOFLCRDAT	ioFlCrDat 
#define IOFLMDDAT	ioFlMdDat 

/* ioParam variant of ParamBlockRec and components: */
typedef IOParam		IOPARAM;
#define IOREFNUM	ioRefNum
#define IOVERSNUM	ioVersNum
#define IOPERMSSN	ioPermssn
#define IOMISC		ioMisc
#define IOBUFFER	ioBuffer
#define IOREQCOUNT	ioReqCount
#define IOACTCOUNT	ioActCount
#define IOPOSMODE	ioPosMode
#define IOPOSOFFSET	ioPosOffset

/* volumeParam variant of ParamBlockRec and components: */
typedef VolumeParam	VOLUMEPARAM;
#define FILLER2		filler2
#define IOVOLINDEX	ioVolIndex
#define IOVCRDATE	ioVCrDate
#define IOVLSBKUP	ioVLsBkUp
#define IOVATRB		ioVAtrb
#define IOVNMFLS	ioVNmFls
#define IOVDIRST	ioVDirSt
#define IOVBLLN		ioVBlLn
#define IOVNMALBLKS	ioVNmAlBlks
#define IOVALBLKSIZ	ioVAlBLkSiz
#define IOVCLPSIZ	ioVClpSiz
#define IOALBLST	ioAlBlSt
#define IOVNXTFNUM	ioVNxtFNum
#define IOVFRBLK	ioVFrBlk
#endif

