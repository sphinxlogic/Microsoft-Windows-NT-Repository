/* Version 0.8(7) - Jim Noble at Planning Research Corporation, June 1987. */
/* Ported to Megamax native Macintosh C compiler. */

/*
 * CKMKE2.C
 *
 * Key-Config is a keyboard configurator program for use with Columbia's
 * MacKermit.
 *
 * Bill Schilit, April 1985
 *
 *
 * Copyright (C) 1985, Trustees of Columbia University in the City of
 * New York.  Permission is granted to any individual or institution to
 * use, copy, or redistribute this software so long as it is not sold
 * for profit, provided this copyright notice is retained.
 *
 */

#include <ctype.h>
#include "ckcsym.h"

#if MEGAMAX
#include <control.h>
#include <dialog.h>
#include <event.h>
#include <font.h>
#include <mem.h>
#include <os.h>
#endif

#ifdef SUMACC
#include "mac/quickdraw.h"		/* order does matter */
#include "mac/osintf.h"			/*  on these... */
#include "mac/toolintf.h"
#include "mac/packintf.h"
#endif

#include "ckmsys.h"			/* Compiler specific definitions */
#include "ckmkey.h"
#include "ckmkkc.h"

extern CHAR mapkey();

Rect kbbox,smallbox;

INTEGER
    keymods = 0,			/* current modifiers from keyboard  */
    butmods = 0;			/* current modifiers from button */
CHAR
    keysel = KC_NUN;			/* selected key */
BOOLEAN
    kbselected = TRUE;			/* kb or text is active */

struct KEYCODE {
    CHAR	kcode;			/* key code */
    INTEGER	krow;			/* row and column on keyboard */
    INTEGER	kcol;
    INTEGER	ksize;			/* horizontal key size */
    INTEGER	khpos;			/* horizontal position */
    char	*kname;			/* key name */
    Rect	krect;
} keycodes[] =
{
  {0x32,1, 1,R1,0,	"`"},	{0x12,1, 2,R1,R1,	"1"},	/* `1 */
  {0x13,1, 3,R1,2*R1,	"2"},	{0x14,1, 4,R1,3*R1,	"3"},	/* 23 */
  {0x15,1, 5,R1,4*R1,	"4"},	{0x17,1, 6,R1,5*R1,	"5"},	/* 45 */
  {0x16,1, 7,R1,6*R1,	"6"},	{0x1A,1, 8,R1,7*R1,	"7"},	/* 67 */
  {0x1C,1, 9,R1,8*R1,	"8"},	{0x19,1,10,R1,9*R1,	"9"},	/* 89 */
  {0x1D,1,11,R1,10*R1,	"0"},	{0x1B,1,12,R1,11*R1,	"-"},	/* 0- */
  {0x18,1,13,R1,12*R1,	"="},	{0x33,1,14,R2,13*R1,	"Backspace"}, /* =<BS> */

  {0x30,2, 1,R2,0,	"Tab"},	{0x0C,2, 2,R1,R2,	"Q"},	/* <TAB>Q */
  {0x0D,2, 3,R1,R1+R2,	"W"},	{0x0E,2, 4,R1,2*R1+R2,	"E"},	/* WE */
  {0x0F,2, 5,R1,3*R1+R2,"R"},	{0x11,2, 6,R1,4*R1+R2,	"T"},	/* RT */
  {0x10,2, 7,R1,5*R1+R2,"Y"},	{0x20,2, 8,R1,6*R1+R2,	"U"},	/* YU */
  {0x22,2, 9,R1,7*R1+R2,"I"},	{0x1F,2,10,R1,8*R1+R2,	"O"},	/* IO */
  {0x23,2,11,R1,9*R1+R2,"P"},	{0x21,2,12,R1,10*R1+R2,	"["},	/* P[ */
  {0x1E,2,13,R1,11*R1+R2,"]"},	{0x2A,2,14,R1,12*R1+R2,	"\\"},	/* ]\ */

  {KC_KLK,3, 1,R3,0,	"Caps lock"},				/* <CAPS LOCK> */
  {0x00,3, 2,R1,R3,	"A"},	{0x01,3, 3,R1,R1+R3,	"S"},	/* AS */
  {0x02,3, 4,R1,2*R1+R3,"D"},	{0x03,3, 5,R1,3*R1+R3,	"F"},	/* DF */
  {0x05,3, 6,R1,4*R1+R3,"G"},	{0x04,3, 7,R1,5*R1+R3,	"H"},	/* GH */
  {0x26,3, 8,R1,6*R1+R3,"J"},	{0x28,3, 9,R1,7*R1+R3,	"K"},	/* JK */
  {0x25,3,10,R1,8*R1+R3,"L"},	{0x29,3,11,R1,9*R1+R3,	";"},	/* L; */
  {0x27,3,12,R1,10*R1+R3,"'"},	{0x24,3,13,R3,11*R1+R3,	"Return"}, /* '<RET> */

  {KC_SHF,4, 1,R4,0,	"Shift"},				/* <SHIFT> */
  {0x06,4, 2,R1,R4,	"Z"},	{0x07,4, 3,R1,R1+R4,	"X"},	/* ZX */
  {0x08,4, 4,R1,2*R1+R4,"C"},	{0x09,4, 5,R1,3*R1+R4,	"V"},	/* CV */
  {0x0B,4, 6,R1,4*R1+R4,"B"},	{0x2D,4, 7,R1,5*R1+R4,	"N"},	/* BN */
  {0x2E,4, 8,R1,6*R1+R4,"M"},	{0x2B,4, 9,R1,7*R1+R4,	","},	/* M, */
  {0x2F,4,10,R1,8*R1+R4,"."},	{0x2C,4,11,R1,9*R1+R4,	"/"},	/* ./ */
  {KC_SHF,4,12,R4,10*R1+R4,"Shift"},				/* <SHIFT> */
  
  {KC_OPT,5,1,R1,R1,		"Option"},			/* <OPTION> */
  {KC_CMD,5,2,R2,2*R1,		"Command"},			/* <CMD> */
  {0x31,5,3,R5,2*R1+R2,		"Space"},			/* <SPACE> */
  {0x34,5,4,R2,2*R1+R2+R5,	"Enter"},			/* <ENTER> */
  {KC_OPT,5,5,R1,2*R1+2*R2+R5,	"Option"}			/* <OPTION> */
};

#define NKEYS (sizeof(keycodes)/sizeof(struct KEYCODE))

Rect scoderects[MAX_SCODE+1];		/* rectanges for scan codes */


/* myfilter - filter events */

#if MEGAMAX
pascal BOOLEAN
myfilter(THEDIALOG,THEEVENT,ITEMHIT)
DialogPtr THEDIALOG;
EventRecord *THEEVENT;
INTEGER *ITEMHIT;
#endif

#ifdef SUMACC
myfilter()
#endif

{
  INTEGER newmods;
  CHAR newkey = KC_NUN;
  Point localpt;

#if MEGAMAX
  BOOLEAN RETVAL; 
#endif

#ifdef SUMACC
  struct {
    INTEGER *itemhit;			/* (in stack order) */
    EventRecord *theevent;    
    DialogPtr thedialog;
  } args;
  BOOLEAN *retval; 

#define THEDIALOG		args.thedialog
#define THEEVENT		args.theevent
#define ITEMHIT			args.itemhit
#define RETVAL			*retval

  retval = (BOOLEAN *) getpargs(&args,sizeof(args));
#endif

  RETVAL = FALSE;			/* modal can deal with it */   
 
/* check for events which we do updates on */
 
  newmods = keymapmods();		/* set from modifiers from key map */

  switch (THEEVENT->what) {
    
    case mouseDown:			/* check for mouse in KB */
      localpt = THEEVENT->where;	/* copy the point */
      GlobalToLocal(&localpt);		/* make it local */  
      if (PtInRect(&localpt,&kbbox))	/* in our KB picture? */
	newkey = mousekb(&localpt,	/* yes set butmod and newkey */   
	      THEEVENT->when); 	
      break;
 
    case keyDown:			/* key down event */
      if (kbselected)			/* do we want to handle it? */
      {					/* yes, KB is selected */
	RETVAL = TRUE;			/* so do not let modal do it */
	*ITEMHIT = SETKD_KEYB;		/* ... */
	newmods = 			/* get key modifiers */       
	    THEEVENT->modifiers & 
	    (alphaLock | cmdKey | optionKey | shiftKey);
	newkey = (THEEVENT->message & keyCodeMask) >> 8;  /* and key */
      }
      break;
  }    

  newmods |= butmods;			/* include those set by button */

/* check for ambigous key stroke */
 
  if ((newmods & (*kshdl)->ctrlmods) &&	/* both ctrl and */
      (newmods & (*kshdl)->caplmods))	/*  caps lock? */
  { 
   SysBeep(1);				/* yes... */
   butmods = 0;				/* clear these out */
   *ITEMHIT = 0;			/* ignore it... */
#if MEGAMAX
   return RETVAL;
#endif

#ifdef SUMACC
   return;
#endif
  }
  
  if (keymods != newmods)		/* change in modifiers? */
  {
    keymods = newmods;			/* set new mod flags */
    drawkeychars(keymods);		/* do update on character set */
    hilitemods(keymods);		/* draw highlighted mod keys */
    if (keysel != KC_NUN)		/* something to keep hi-lited? */
     hilitekey(keysel);			/* yes... do it */
  }

  if (newkey != keysel && 		/* change in selected key? */
      newkey != KC_NUN)			/* and something selected? */
  {
    if (keysel != KC_NUN)		/* was there a previous? */
     hilitekey(keysel);			/* yes, so de-hilite it */
    keysel = newkey;			/* set current key */
    if (keysel != KC_NUN)		/* selected something good? */
     hilitekey(keysel);			/* yes, so hilite it */
  }
#if MEGAMAX
  return RETVAL;
#endif
}


LONGINT lastwhen = 0;
CHAR lastkeyc = KC_NUN;


/* mousekb - mouse down occured inside our KB item */

CHAR
mousekb(pt,when)
Point *pt;
LONGINT when;
{
  INTEGER doubletime;
  int twoclick;
  CHAR keyc = KC_NUN;
  INTEGER modv;
  int k;
  
#ifdef SUMACC
  doubletime = (SysPPtr->volClik >> 4) & 0x0f;
#else
  doubletime = (GetSysPPtr()->volClik >> 4) & 0x0f;
#endif
  doubletime *= 4;
  twoclick = ((when - lastwhen) <= doubletime);
  lastwhen = when;			/* remember last time */
  
  for (k = 0; k<NKEYS; k++)
    if (PtInRect(pt,&keycodes[k].krect)) /* found the KB key? */
    {
     keyc = keycodes[k].kcode;		/* here is the key code */
     break;				/* yes, it's in k */
    }

  if (keyc == KC_NUN)			/* not inside a key */
  {
    SysBeep(1);
    return(KC_NUN);
  }
  
  if (twoclick && (lastkeyc == keyc))	/* double click on it? */
   switch (keyc)			/* yes... maybe enter dlog */
   {
     case KC_CMD:
     case KC_SHF:
     case KC_KLK:
     case KC_OPT:
       dosetmkdialog();			/* enter the setup dialog */
       InvalRect(&kbbox);		/* cause entire update */
       return(KC_NUN);
     default:
       SysBeep(1);			/* can't open others */
       return(KC_NUN);
   }

   lastkeyc = keyc;			/* remember the key */   
   modv = keycodemods(keyc);		/* get modifier value if any */
   if (modv == 0)
    return(keyc);			/* return the key */
   butmods ^= modv;			/* toggle the button modifiers */
   return(KC_NUN);
}


initkeyrects()
{
  int k;
  Rect *kr;

  for (k=0; k < NKEYS; k++)
  {
    kr = &scoderects[keycodes[k].kcode];
    keyrect(&keycodes[k],kr,0);
    keyrect(&keycodes[k],&keycodes[k].krect,3);
  }
}
    
keyrect(k,kr,inset)
struct KEYCODE *k;
Rect *kr;
INTEGER inset;
{
 SetRect(kr,0,0,k->ksize,K_HEIGHT);	    /* form key size */
 OffsetRect(kr,k->khpos,(k->krow-1)*K_HEIGHT); /* offset */
 InsetRect(kr,inset,inset);		/* make it fit per caller var */
 OffsetRect(kr,kbbox.LEFT,kbbox.TOP); 	/* offset to our region */
} 

/*
 * Bittest returns the setting of an element in a Pascal PACKED ARRAY [0..n]
 * OF BOOLEAN such as the KeyMap argument returned by GetKeys(). 
 */

BOOLEAN
bittest (bitmap, bitnum)
  char	bitmap[];
  int	bitnum;
{
  return (0x01 & (bitmap[bitnum/8] >> (bitnum%8)));
}

INTEGER keymapmods() 
{
  INTEGER km[8];				/* Used as KeyMap */
  register INTEGER mods;

  GetKeys(km);
  mods = 0;  
  if (bittest (km, KC_SHF))
    mods |= shiftKey;
  if (bittest (km, KC_OPT))
    mods |= optionKey;
  if (bittest (km, KC_CMD))
    mods |= cmdKey;
  if (bittest (km, KC_KLK))
    mods |= alphaLock;
  return(mods);
}


drawkeychars(mods)
INTEGER mods;
{
  FontInfo fi;  
  char *kn,*namekey(),*namefkey();
  BOOLEAN ismeta,isfkey;
  int k,vs,hs;
  CHAR kval;
  Rect *kr;

  TextFont(geneva);			/* has ok 9 pt system font */
  TextSize(9);				/* small font */
  GetFontInfo(&fi);			/* info for descent+ascent */
  
  vs = (fi.descent+fi.ascent-K_HEIGHT)/2; /* vertical space for centering */

  for (k=0; k<NKEYS; k++)
  {
    kr = &keycodes[k].krect;
    EraseRect(kr);			/* clean out old value */
    TextFace(bold);      
    switch (keycodes[k].kcode)
    {
      case KC_CMD: kn = "Cmd"; break;	/* apple key */
      case KC_OPT: kn = "Opt"; break;
      case KC_SHF: kn = "Shift"; break;
      case KC_KLK: kn = "Cap Lock"; break;
      default:
      	kval = mapkey(keycodes[k].kcode,mods,&ismeta,&isfkey);
	if (!isfkey)			/* is it a function key? */
	 TextFace(0);			/* no, use normal font */
      	kn = namekey(kval,ismeta,isfkey,FALSE); /* give it a name */
	break;
    }
    hs = (keycodes[k].ksize - StringWidth(kn))/2; /* leading space */
    MoveTo(kr->LEFT+hs-2,kr->BOTTOM+vs); /* position the pen */
    DrawString(kn);				  /* draw it */
  }
  TextSize(0);				/* back to default */
  TextFace(0);
  TextFont(0);
}

PicHandle kbpic = NULL;

drawkeyboard(r)
Rect *r;
{
  int k;
  Rect kr;

  if (kbpic == NULL)
  {
    kbpic = OpenPicture(&kbbox);	/* open a picture */
    for (k=0; k<NKEYS; k++)		/* for all keys */
    {
      keyrect(&keycodes[k],&kr,1);
      FrameRoundRect(&kr,6,6);
    }
    ClosePicture();			/* all done */
  }
  HLock((Handle) kbpic);
  DrawPicture(kbpic,r);			/* draw the picture */
  HUnlock((Handle) kbpic);
}

hilitekey(kcode)
CHAR kcode;
{
 int k;
 Rect kr;

 for (k=0; k<NKEYS; k++)
  if (keycodes[k].kcode == kcode)
  {
    keyrect(&keycodes[k],&kr,3);
    InvertRect(&kr);
    if (keycodes[k].kcode != KC_SHF &&	/* want to hilite another? */
      	keycodes[k].kcode != KC_OPT)	/* shift and option are two keys */
    return;
  }
}

hilitemods(mods)
INTEGER mods;
{
 if (mods & optionKey)
   hilitekey(KC_OPT);
 if (mods & cmdKey)
   hilitekey(KC_CMD);
 if (mods & alphaLock)
   hilitekey(KC_KLK);
 if (mods & shiftKey)
   hilitekey(KC_SHF);
}

/* namekey - Given an 8 bit character value returns a string containing
 *    	     the name for the key. If lform is TRUE names are returned as:
 *
 *    	      Control-Meta-X, or Control-X, or X
 *
 *    	     if lform is FALSE, names are returned in the shorter form:
 *
 *    	      C-M-X, or C-X, or X.
 */

char *namekey(key,ismeta,isfkey,lform)
CHAR key;
BOOLEAN ismeta,isfkey;
int lform;
{
  static char keyname[100];
  char *keyp = keyname,
       keyc[2];

  keyname[0] = keyc[1] = 0;		/* start with empty strings */

  if (isfkey) {				/* is this a function def? */
    strcat(keyp,(lform) ? "Function-" : "F");
    NumToString((LONGINT) key,keyp+strlen(keyp));
    return(keyname);
  }

  if (key < 040)			/* a control character? */
  {
   strcat(keyp,(lform) ? "Control-" : "^"); /* yes, indicate control */
   key += 0100;				/* normalize */
  }

  if (ismeta)				/* a meta character? */
   strcat(keyp,(lform) ? "Meta-" : "M-"); /* yes, indicate meta typed */
  
  keyc[0] = key;

  if (key == 0177)			/* delete? */
   strcat(keyp,(lform) ? "Delete" : "DEL"); /* yes, use this name */
  else strcat(keyp,keyc);		/* else put printable key in */
    
  return(keyname);			/* return the name */
}

/* namescode - given a scan code and modifier bits, return a string
 *    	       describing this set of depressed keys in Mac language.
 *
 */

char *namescode(scode,mod) 
CHAR scode;
INTEGER mod;
{
 static char scodename[100];
 char *scodep;
 int k;

 scodep = scodename;
 scodename[0] = 0;
 
 if (mod & optionKey) strcat(scodep,"Option ");
 if (mod & cmdKey) strcat(scodep,"Command ");
 if (mod & alphaLock) strcat(scodep,"Caps Lock ");
 if (mod & shiftKey) strcat(scodep,"Shift "); 
 for (k=0; k < NKEYS; k++)
  if (keycodes[k].kcode == scode) 
  { strcat(scodep,keycodes[k].kname); break; }
 return(scodename);
}

setnum(hdl,val)
Handle hdl;
CHAR val;
{
 char numbuf[20];

 NumToString((LONGINT) val,numbuf);
 SetIText(hdl,numbuf);
}
 
getnum(hdl,cell)
CHAR *cell;
Handle hdl;
{
 char numbuf[20],c;
 int i;
 LONGINT value;

 GetIText(hdl,numbuf);
 for (i=0; (c = numbuf[i]) != 0; i++)
 if (!isdigit(c))
 {
  printerr("Field contains a non numeric ", c);
  return(FALSE);
 }
 StringToNum(numbuf,&value);
 if (value > 0177 || value < 0)
 {
  printerr("Not in 7 bit range: ", (int) value);
  return(FALSE);
 }
 *cell = value;
 return(TRUE);
}

/* drawkb - called by modal dialog to update KB.
 *
 * This is the only procedure that draws or updates the KB picture.  It
 * is called by ModalDialog for normal reasons (an overlapping window
 * has gone away) or the call can be caused by our code issuing an
 * InvalRect.  In order to do things quickly we control the amount to
 * be redrawn with 3 flags:
 *
 *    ourupdate - if FALSE then an entire redraw needs to be done.
 *    updatemods - if TRUE then characters within the keys need redrawing.
 *    updatekeys - if TRUE then selected (hi-lighted) keys have changed.
 *
 */

#if MEGAMAX
pascal
drawkb(W,ITEM)
WindowPtr W;
INTEGER ITEM;
#endif

#ifdef SUMACC
drawkb()
#endif

{
#ifdef SUMACC
  struct {
    INTEGER item;
    WindowPtr w;
  } args;

#define W		args.w
#define ITEM		args.item
 
  getpargs(&args,sizeof(args));
#endif

  EraseRect(&kbbox);			/* start with a clean slate */
  drawkeyboard(&kbbox);			/* draw the KB outline */
  drawkeychars(keymods);		/* do update on characters */
  hilitemods(keymods);			/* draw highlighted mod keys */  
  if (keysel != KC_NUN)			/* do the current key */
   hilitekey(keysel);			/* ... */  
}

INTEGER keycodemods(keyc)
CHAR keyc;
{
  switch(keyc)
  {
    case KC_OPT: return(optionKey);
    case KC_CMD: return(cmdKey);
    case KC_KLK: return(alphaLock);
    case KC_SHF: return(shiftKey);
    default: return(0);
  }
}

setkeydialog()
{  
  WindowPtr w;
  BOOLEAN ismeta,isfkey;
  INTEGER itype,itemhit;
  CHAR kval;
  ControlHandle setkeyhdl,setfkeyhdl;
  Handle ihdl,kvalhdl,mkeyhdl;
  char nambuf[256];

  w = GetNewDialog(DLOG_SETK,NILPTR,(WindowPtr) -1);
  SetPort(w);				/* set the port */

  GetDItem(w,SETKD_KEYB,&itype,&ihdl,&kbbox);
  SetDItem(w,SETKD_KEYB,itype,(Handle ) drawkb,&kbbox);
   
  initkeyrects();			/* now that kbbox is set */
  
  mkeyhdl = gethdl(SETKD_KEYT,w);
  kvalhdl = gethdl(SETKD_KVAL,w);
  setkeyhdl = getctlhdl(SETKD_SET,w);
  setfkeyhdl = getctlhdl(SETKD_SETFK,w);

  HiliteControl(setkeyhdl,dimHilite); 	/* these are not allowed */  
  HiliteControl(setfkeyhdl,dimHilite); 	/* these are not allowed */  
  SelIText(w,SETKD_ITXT,0,0); 		/* select invisible text */  

  keymods = 0;				/* current modifiers from keyboard  */
  butmods = 0;				/* current modifiers from button */
  keysel = KC_NUN;			/* selected key */
  kbselected = TRUE;			/* kb or text is active */  
  
  ShowWindow(w);  

  for (;;) {				/* begin dialog loop */
    ModalDialog(myfilter,&itemhit);	/* do modal dialog */
    
    switch (itemhit) {
      
      case SETKD_KEYB:			/* mouse down in keyboard */
	if (keysel == KC_NUN)
      	 break;				/* nothing to do */
      	kbselected = TRUE;		/* KB is selected */
	SelIText(w,SETKD_ITXT,0,0); 	/* select invisible text */
	kval = mapkey(keysel,keymods,&ismeta,&isfkey);
	setnum(kvalhdl,kval);
	strcpy(nambuf,namescode(keysel,keymods));
	strcat(nambuf," is mapped to ");
	strcat(nambuf,namekey(kval,ismeta,isfkey,TRUE));
	strcat(nambuf,".   Enter new value: ");
	SetIText(mkeyhdl,nambuf);	
	HiliteControl(setfkeyhdl,noHilite);	/* these are now allowed */
	HiliteControl(setkeyhdl,noHilite);	/* these are now allowed */
	break;

      case SETKD_KVAL:
      	kbselected = FALSE;		/* deselect KB */
      	if (getnum(kvalhdl,&kval)) 	/* get the number */
	{
	  strcpy(nambuf,namescode(keysel,keymods));
	  strcat(nambuf," is mapped to ");
	  strcat(nambuf,namekey(kval,ismeta,isfkey,TRUE));
	  strcat(nambuf,".   Enter new value: ");
	  SetIText(mkeyhdl,nambuf);	
	}
	else				/* badly formed -- so reset it */
	  setnum(kvalhdl,mapkey(keysel,keymods,&ismeta,&isfkey));
	break;
	  
      case SETKD_SETFK:
      case SETKD_SET:
      	if (getnum(kvalhdl,&kval))
	{
	  modified = TRUE;		/* things have changed */
	  if (itemhit == SETKD_SETFK)
	    kval |= FKEYBIT;		/* turn on function key bit */
      	  setmapkey(kval,keysel,keymods);
	  drawkeychars(keymods);	/* do update on characters */
	  hilitemods(keymods);		/* draw highlighted mod keys */
	  if (keysel != KC_NUN)		/* something to keep hi-lited? */
	    hilitekey(keysel);		/* yes... do it */
	  kbselected = TRUE;		/* keyboard is active */
	  SelIText(w,SETKD_ITXT,0,0); 	/* select invisible text */  	    
	}
	break;

      case SETKD_QUIT:
      	DisposDialog(w);
	return;
     }
  }
}
 


