/* stuff common to all language scripts */

#include "mesgnums.h"

#define BLANKS_30 '                              '
#define BLANKS_35 '                                   '
#define BLANKS_40 '                                        '
#define BLANKS_50 '                                                  '
#define BLANKS_60 '                                                            '
#define BLANKS_80 '                                                                                '
#define GENERAL_MGR	16
#define SALES_MGR	4
#define PREVIOUS_FIELD	3
#define ADD_UPDATE	31
