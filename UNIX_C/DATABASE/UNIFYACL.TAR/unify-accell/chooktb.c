/**********************************************************************
*
*	chooktb.c - ACCELL/C-Language function hook tables
*
**********************************************************************/

#include <chookincl.h>

extern int display_txt();
extern int edit_txt();
extern int to_upper();
extern int show_txt();
extern int text_size();
extern int week_day();
extern int day_of_week();
#ifdef CP
extern int get_txt();
extern int put_txt();
#endif

CHOOK chooktb[] = 
    {
        { "display_txt", display_txt },
        { "edit_txt", edit_txt },
        { "to_upper", to_upper },
        { "show_txt", show_txt },
        { "text_size", text_size },
        { "week_day", week_day },
        { "day_of_week", day_of_week }
#ifdef CP
       ,{ "get_txt", get_txt },
        { "put_txt", put_txt }
#endif
    };                        

/*** # elements in chook table DO NOT MODIFY ***/;

int nhooks = (sizeof(chooktb)/sizeof(*chooktb)); 
