/*
 * This file is the general header file for all parts
 * of the MicroEMACS display editor. It contains all of the
 * general definitions and macros. It also contains some
 * conditional compilation flags. All of the per-system and
 * per-terminal definitions are in special header files.
 * The most common reason to edit this file would be to zap
 * the definition of CVMVAS or BACKUP.
 */
#include	"sysdef.h"		/* Order is critical.		*/
#include	"ttydef.h"
#include	<stdio.h>

/*
 * If your system and/or compiler does not support the "void" type
 * then define NO_VOID_TYPE in sysdef.h.  In the absence of some
 * other definition for VOID, the default in that case will be to
 * turn it into an int, which works with most compilers that don't
 * support void.  In the absence of any definition of VOID or
 * NO_VOID_TYPE, the default is to assume void is supported, which
 * should be the case for most modern C compilers.
 */

#ifdef NO_VOID_TYPE
#  undef VOID
#  define VOID int			/* Default for no void is int */
#else
#ifndef	VOID
#  define VOID void			/* Just use normal void */
#endif /* VOID */
#endif /* NO_VOID_TYPE */

/*
 * Table sizes, etc.
 */
#ifdef	HASH
#define	NSHASH	31			/* Symbol table hash size.	*/
#endif
#define	NFILEN	80			/* Length, file name.		*/
#define	NBUFN	24			/* Length, buffer name.		*/
#ifndef NLINE			/* allow it to be defined in makefile */
#define	NLINE	256			/* Length, line.		*/
#endif
#define	NKBDM	256			/* Length, keyboard macro.	*/
#define	NPAT	80			/* Length, pattern.		*/
#define	HUGE	1000			/* A rather large number.	*/
#define NSRCH	128			/* Undoable search commands.	*/
#define	NXNAME	64			/* Length, extended command.	*/
#define	NKNAME	20			/* Length, key names		*/
/*
 * Universal.
 */
#define	FALSE	0			/* False, no, bad, etc.		*/
#define	TRUE	1			/* True, yes, good, etc.	*/
#define	ABORT	2			/* Death, ^G, abort, etc.	*/

/*
 * These flag bits keep track of
 * some aspects of the last command. The CFCPCN
 * flag controls goal column setting. The CFKILL
 * flag controls the clearing versus appending
 * of data in the kill buffer.
 */
#define	CFCPCN	0x0001			/* Last command was C-P, C-N	*/
#define	CFKILL	0x0002			/* Last command was a kill	*/

/*
 * File I/O.
 */
#define	FIOSUC	0			/* Success.			*/
#define	FIOFNF	1			/* File not found.		*/
#define	FIOEOF	2			/* End of file.			*/
#define	FIOERR	3			/* Error.			*/

/*
 * Directory I/O.
 */
#define	DIOSUC	0			/* Success.			*/
#define	DIOEOF	1			/* End of file.			*/
#define	DIOERR	2			/* Error.			*/

/*
 * Display colors.
 */
#define	CNONE	0			/* Unknown color.		*/
#define	CTEXT	1			/* Text color.			*/
#define	CMODE	2			/* Mode line color.		*/

/*
 * global mode
 */
#define	MBSMAP	0x0001			/* Map bs<->del			*/
#define MFLOW	0x0002			/* Use ^^ for ^Q and ^/ for ^S	*/
#define	MINDENT	0x0004			/* autoindent			*/
#define	MFILL	0x0008			/* fill mode			*/
#ifdef	NOTAB
#define MNOTAB	0x0010			/* no tab mode			*/
#endif
#define MOVRSTK	0x0020			/* insert / over-strike mode	*/

/*
 * Flags for "eread".
 */
#define	EFFUNC	0x0001			/* Autocomplete functions.	*/
#define EFBUF	0x0002			/* Autocomplete buffers.	*/
#define EFFILE	0x0004			/* " files (maybe someday)	*/
#define	EFAUTO	0x0007			/* Some autocompleteion on	*/
#define	EFNEW	0x0008			/* New prompt.			*/
#define	EFCR	0x0010			/* Echo CR at end; last read.	*/

/*
 * Flags for "getkey".
 */
#define KQUOTE	0x0001			/* Get raw character		*/
#define	KNOMAC	0x0002			/* Don't record for macros	*/
#define	KPROMPT 0x0004			/* do delayed prompting		*/

/*
 * Flags for "ldelete"/"kinsert"
 */

#define KNONE	0
#define KFORW	1
#define KBACK	2

/*
 * Keys are represented inside using an 11 bit
 * keyboard code. The transformation between the keys on
 * the keyboard and 11 bit code is done by terminal specific
 * code in the "kbd.c" file. The actual character is stored
 * in 8 bits (DEC multinationals work); there is also a control
 * flag KCTRL, a meta flag KMETA, and a control-X flag KCTLX.
 * ASCII control characters are always represented using the
 * KCTRL form. Although the C0 control set is free, it is
 * reserved for C0 controls because it makes the communication
 * between "getkey" and "getkbd" easier. The funny keys get
 * mapped into the C1 control area. The KEY type is typedefed in
 * sysdef.h, as it may depeond on compiler/machine.
 */
#define	NKEYS	2048			/* 11 bit code.			*/

#define	METACH	0x1B			/* M- prefix,   Control-[, ESC	*/
#define	CTMECH	0x1C			/* C-M- prefix, Control-\	*/
#define	EXITCH	0x1D			/* Exit level,  Control-]	*/
#define	CTRLCH	0x1E			/* C- prefix,	Control-^	*/
#define	HELPCH	0x1F			/* Help key,    Control-_	*/

#define	KCHAR	0x00FF			/* The basic character code.	*/
#define	KCTRL	0x0100			/* Control flag.		*/
#define	KMETA	0x0200			/* Meta flag.			*/
#define	KCTLX	0x0400			/* Control-X flag.		*/

#define	KFIRST	0x0080			/* First special.		*/
#define	KLAST	0x009F			/* Last special.		*/

#define	KRANDOM	0x0080			/* A "no key" code.		*/
#define	K01	0x0081			/* Use these names to define	*/
#define	K02	0x0082			/* the special keys on your	*/
#define	K03	0x0083			/* terminal.			*/
#define	K04	0x0084
#define	K05	0x0085
#define	K06	0x0086
#define	K07	0x0087
#define	K08	0x0088
#define	K09	0x0089
#define	K0A	0x008A
#define	K0B	0x008B
#define	K0C	0x008C
#define	K0D	0x008D
#define	K0E	0x008E
#define	K0F	0x008F
#define	K10	0x0090
#define	K11	0x0091
#define	K12	0x0092
#define	K13	0x0093
#define	K14	0x0094
#define	K15	0x0095
#define	K16	0x0096
#define	K17	0x0097
#define	K18	0x0098
#define	K19	0x0099
#define	K1A	0x009A
#define	K1B	0x009B
#define	K1C	0x009C
#define	K1D	0x009D
#define	K1E	0x009E
#define	K1F	0x009F

#ifndef SEOL		/* needed for OSK, where '\r' == '\n' */
#  define SEOL '\n'
#endif

/*
 * These flags, and the macros below them,
 * make up a do-it-yourself set of "ctype" macros that
 * understand the DEC multinational set, and let me ask
 * a slightly different set of questions.
 */
#define	_W	0x01			/* Word.			*/
#define	_U	0x02			/* Upper case letter.		*/
#define	_L	0x04			/* Lower case letter.		*/
#define	_C	0x08			/* Control.			*/
#define _P	0x10			/* end of sentence punctuation	*/

#define	ISWORD(c)	((cinfo[(c)]&_W)!=0)
#define	ISCTRL(c)	((cinfo[(c)]&_C)!=0)
#define	ISUPPER(c)	((cinfo[(c)]&_U)!=0)
#define	ISLOWER(c)	((cinfo[(c)]&_L)!=0)
#define	ISEOSP(c)	((cinfo[(c)]&_P)!=0)
#define	TOUPPER(c)	((c)-0x20)
#define	TOLOWER(c)	((c)+0x20)

/*
 * generally useful thing for chars
 */
#define CCHR(x)		((x)-'@')

/*
 * All repeated structures are kept as linked lists of structures.
 * All of these start with a LIST structure (except lines, which
 * have their own abstraction). This will allow for
 * later conversion to generic list manipulation routines should
 * I decide to do that. it does mean that there are four extra
 * bytes per window. I feel that this is an acceptable price,
 * considering that there are usually only one or two windows.
 */
typedef struct LIST {
	union {
		struct SYMBOL	*l_sp;
		struct WINDOW	*l_wp;
		struct BUFFER	*l_bp;
		struct LIST	*l_nxt;
	} l_p;
	char	*l_name;
} LIST;
/*
 * Usual hack - to keep from uglifying the code with lotsa
 * references through the union, we #define something for it.
 */
#define	l_next	l_p.l_nxt

/*
 * The symbol table links editing functions
 * to names. Entries in the key map point at the symbol
 * table entry.
 */
typedef	struct	SYMBOL {
	LIST	s_list;			/* List chain.			*/
	int	(*s_funcp)();		/* Function.			*/
#ifdef	HASH
	short	s_flags;		/* Flags for this symbol	*/
#endif
}	SYMBOL;
#define	s_symp	s_list.l_p.l_sp
#define s_name	s_list.l_name
#ifdef	HASH
#define SFEND	0x001			/* End of has list		*/
#endif

/*
 * There is a window structure allocated for
 * every active display window. The windows are kept in a
 * big list, in top to bottom screen order, with the listhead at
 * "wheadp". Each window contains its own values of dot and mark.
 * The flag field contains some bits that are set by commands
 * to guide redisplay; although this is a bit of a compromise in
 * terms of decoupling, the full blown redisplay is just too
 * expensive to run for every input character. 
 */
typedef	struct	WINDOW {
	LIST	w_list;			/* List header		       */
	struct	BUFFER *w_bufp;		/* Buffer displayed in window	*/
	struct	LINE *w_linep;		/* Top line in the window	*/
	struct	LINE *w_dotp;		/* Line containing "."		*/
	struct	LINE *w_markp;		/* Line containing "mark"	*/
	short	w_doto;			/* Byte offset for "."		*/
	short	w_marko;		/* Byte offset for "mark"	*/
	char	w_toprow;		/* Origin 0 top row of window	*/
	char	w_ntrows;		/* # of rows of text in window	*/
	char	w_force;		/* If NZ, forcing row.		*/
	char	w_flag;			/* Flags.			*/
}	WINDOW;
#define	w_wndp	w_list.l_p.l_wp
#define w_name	w_list.l_name

/*
 * Window flags are set by command processors to
 * tell the display system what has happened to the buffer
 * mapped by the window. Setting "WFHARD" is always a safe thing
 * to do, but it may do more work than is necessary. Always try
 * to set the simplest action that achieves the required update.
 * Because commands set bits in the "w_flag", update will see
 * all change flags, and do the most general one.
 */
#define	WFFORCE	0x01			/* Force reframe.		*/
#define	WFMOVE	0x02			/* Movement from line to line.	*/
#define	WFEDIT	0x04			/* Editing within a line.	*/
#define	WFHARD	0x08			/* Better to a full display.	*/
#define	WFMODE	0x10			/* Update mode line.		*/

/*
 * Text is kept in buffers. A buffer header, described
 * below, exists for every buffer in the system. The buffers are
 * kept in a big list, so that commands that search for a buffer by
 * name can find the buffer header. There is a safe store for the
 * dot and mark in the header, but this is only valid if the buffer
 * is not being displayed (that is, if "b_nwnd" is 0). The text for
 * the buffer is kept in a circularly linked list of lines, with
 * a pointer to the header line in "b_linep".
 */
typedef	struct	BUFFER {
	LIST	b_list;			/* buffer list pointer		*/
	struct	BUFFER *b_altb;		/* Link to alternate buffer	*/
	struct	LINE *b_dotp;		/* Link to "." LINE structure	*/
	struct	LINE *b_markp;		/* The same as the above two,	*/
	struct	LINE *b_linep;		/* Link to the header LINE	*/
	short	b_doto;			/* Offset of "." in above LINE	*/
	short	b_marko;		/* but for the "mark"		*/
	char	b_nwnd;			/* Count of windows on buffer	*/
	char	b_flag;			/* Flags			*/
	char	b_fname[NFILEN];	/* File name			*/
}	BUFFER;
#define	b_bufp	b_list.l_p.l_bp
#define b_bname	b_list.l_name

#define	BFCHG	0x01			/* Changed.			*/
#define	BFBAK	0x02			/* Need to make a backup.	*/

/*
 * This structure holds the starting position
 * (as a line/offset pair) and the number of characters in a
 * region of a buffer. This makes passing the specification
 * of a region around a little bit easier.
 */
typedef	struct	{
	struct	LINE *r_linep;		/* Origin LINE address.		*/
	short	r_offset;		/* Origin LINE offset.		*/
	RSIZE	r_size;			/* Length in characters.	*/
}	REGION;

/*
 * All text is kept in circularly linked
 * lists of "LINE" structures. These begin at the
 * header line (which is the blank line beyond the
 * end of the buffer). This line is pointed to by
 * the "BUFFER". Each line contains a the number of
 * bytes in the line (the "used" size), the size
 * of the text array, and the text. The end of line
 * is not stored as a byte; it's implied. Future
 * additions will include update hints, and a
 * list of marks into the line.
 */
typedef	struct	LINE {
	struct	LINE *l_fp;		/* Link to the next line	*/
	struct	LINE *l_bp;		/* Link to the previous line	*/
	short	l_size;			/* Allocated size		*/
	short	l_used;			/* Used size			*/
#ifdef	PCC
	char	l_text[1];		/* A bunch of characters.	*/
#else
	char	l_text[];		/* A bunch of characters.	*/
#endif
}	LINE;

/*
 * The rationale behind these macros is that you
 * could (with some editing, like changing the type of a line
 * link from a "LINE *" to a "REFLINE", and fixing the commands
 * like file reading that break the rules) change the actual
 * storage representation of lines to use something fancy on
 * machines with small address spaces.
 */
#define	lforw(lp)	((lp)->l_fp)
#define	lback(lp)	((lp)->l_bp)
#define	lgetc(lp, n)	((lp)->l_text[(n)]&0xFF)
#define	lputc(lp, n, c)	((lp)->l_text[(n)]=(c))
#define	llength(lp)	((lp)->l_used)
#define	ltext(lp)	((lp)->l_text)

/*
 * Externals.
 */
extern	int	thisflag;
extern	int	lastflag;
extern	int	curgoal;
extern	int	epresf;
extern	int	sgarbf;
extern	int	mode;
extern	WINDOW	*curwp;
extern	BUFFER	*curbp;
extern	WINDOW	*wheadp;
extern	BUFFER	*bheadp;
extern	KEY	kbdm[];
extern	KEY	*kbdmip;
extern	KEY	*kbdmop;
extern	KEY	getkey();
extern	char	pat[];
extern	SYMBOL	*symbol[];
extern	SYMBOL	*binding[];
extern	BUFFER	*bfind();
extern	WINDOW	*popbuf();
extern	WINDOW	*wpopup();
extern	LINE	*lalloc();
extern  int	nrow;
extern  int	ncol;
extern	char	*version;
extern	int	ttrow;
extern	int	ttcol;
extern	int	tceeol;
extern	int	tcinsl;
extern	int	tcdell;
extern	char	cinfo[];
extern	char	*keystrings[];
extern	SYMBOL	*symlookup();
VOID		update();
VOID		keyname();
/*
 * Standard I/O.
 */
extern	char	*strcpy();
extern	char	*strcat();
extern	char	*malloc();
