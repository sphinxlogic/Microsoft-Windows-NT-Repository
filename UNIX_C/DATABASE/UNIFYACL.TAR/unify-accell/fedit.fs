/******************************************************************************
*  $Header: fedit.fs,v 2.1 88/01/13 09:30:36 scotth Exp $
*
*  FORM       :  fedit
*  DESCRIPTION:  text editor interface for Accell using c-hooks
*                in the customized AMGR
*
*  AUTHOR     :  Mark Hargrove  
*  DATE       :  11/11/87  
*
******************************************************************************/
#include "extern.h"

FORM fedit

#include "common.h"

/*****************************  FIELD SECTION ********************************/

FIELD s_text

	BEFORE FIELD
		display 'Loading Editor...' for fyi_message
		set $rc to edit_txt($glob_text_field)
		repaint screen
		if $rc < 0 then 
		begin
			display 'edit_txt returned error: ' + val_to_str$($rc) for fyi_message wait
		end
		next action is previous form

/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$Log:	fedit.fs,v $
Revision 2.1  88/01/13  09:30:36  scotth
Frozen for 1.0 Release

Revision 2.0  87/12/18  12:04:00  scotth
first release

Revision 1.7  87/11/25  08:45:52  scotth
Alpha-1 release

Revision 1.5  87/11/23  14:08:25  scotth
frozen for Alpha test

Revision 1.1  87/11/11  16:14:50  scotth
mostly working state

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
