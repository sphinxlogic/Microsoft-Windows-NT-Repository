/*************************************************************************
*
*  newlog - set up a header for a new log entry
*
**************************************************************************/

#ifdef MISLOG
#include "def.h"
#include <stdio.h>
#include <pwd.h>
#include <time.h>

int newlog( f, n, k)
   int f, n, k;
{

   FILE *fp, *fopen(); 
   struct passwd *pw_entry, *getpwnam();
   char *fs_file, basename[80], author[80], date[80],
        *getlogin(), *asctime(), *login_name, buf[80],
        *tmpnam();
   struct tm *timenow, *localtime();
   long clock, time();
   int n;

   login_name = getlogin();
   pw_entry = getpwnam(login_name);
   strcpy(author, pw_entry->pw_gecos);

   clock = time((long *) 0);
   timenow = localtime(&clock);

   fs_file = tmpnam();
   fp = fopen(fs_file, "w");
   sprintf(date, "%s", asctime(timenow));
   fprintf(fp,
    "----------------------------------------------------------------------\n");
   date[strlen(date) - 1] = '\0';
   fprintf(fp, "%s         %s\n\n", date, author);

   fclose(fp);
   gotoeob( FALSE, 0, 0);
   insertfile( fs_file, (char *)0);
   unlink( fs_file);
   gotoeob( FALSE, 0, 0);

   return TRUE;
}
#endif
