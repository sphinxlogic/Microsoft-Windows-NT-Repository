#ifndef lint
static char Sccsid[] = "@(#)extract.c	3.1    DeltaDate 8/3/90    ExtrDate 10/6/90";
#endif

/*      EXTRACT.C       */
/*      This subroutine is used to write selected records from the
 *      database on to another disk file.
 */

#include "stdio.h"
#include "cardfile.h"
#include "ascii.h"

FILE    *ext_fp;
char    ext_fname[FNSIZE];
int     rec_cnt;
struct Sdata    fn_screen[] = {
		    {"File Name", FNSIZE, ext_fname, NULL},
		    {0, 0, 0, 0}
		};

extract(fields, dbname)
struct  Fdata   *fields;
char    *dbname;
{
    char	first[SWIDTH+1];
    int 	write_rcd();

    sprintf(first, "Select records from the %s Data Base to be extracted",
	dbname);
    screen(first, fn_screen, "Enter File Name of Extract File", NULL, FALSE);
    if (ext_fname[0] == '\0') {
	msg("No file name entered, using temp.ext");
	strcpy(ext_fname, "temp.ext");
    }
    if ((ext_fp = fopen(ext_fname, "w")) == NULL) {
	sprintf(first, "Unable to open file %s for output", ext_fname);
	msg(first);
	return(1);
    }
    rec_cnt = 0;
    findrcds(fields, dbname, write_rcd, first);
    fclose(ext_fp);
    sprintf(first, "%d records written to %s", rec_cnt, ext_fname);
    msg("");
    fputs(first, stdout);	/* this works because msg() leaves the cursor */
    sleep(5);
    return(0);
}


/*ARGSUSED*/
int
write_rcd(dummy1, rcd, dummy2, dummy3)
char    *rcd;
char    *dummy1, *dummy2, *dummy3;
{
    ++rec_cnt;
    return(fputs(rcd, ext_fp));
}
