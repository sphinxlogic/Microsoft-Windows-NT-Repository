#ifndef lint
static char Sccsid[] = "@(#)common.c	3.1    DeltaDate 8/3/90    ExtrDate 10/6/90";
#endif

/*      COMMON.C        */
#include "stdio.h"
#include "ascii.h"
#include "cardfile.h"
#ifdef TERMCAP
#define tparm(a, line, col)	tgoto(a, col, line)
#define	putp(a)		tputs(a, 12, mputc)
#else	/* TERMINFO */
#include <curses.h>
#include <term.h>
#endif

#ifdef TERMCAP
extern char
	*clear_screen,
	*clr_eol,
	*enter_dim_mode,
	*enter_blink_mode,
	*exit_attribute_mode,
	*keypad_xmit,
	*keypad_local,
	*cursor_address,
	*cursor_left,
	*cursor_right;
int	mputc();
#endif

msg(str)        /* put a blinking message on the 23'th line of the crt */
char    *str;
{
    putp(tparm(cursor_address, MSGLINE, 9));
    putp(clr_eol);			/* erase line */
    if (str != NULL && *str != '\0') {
	putp(enter_blink_mode);		/* blink */
	fputs(str, stdout);
	putp(exit_attribute_mode);		/* back to normal */
	sleep(4);
    }
}


char *
getfield(string, sepset)        /* like strtok except contiguous seps */
char    *string, *sepset;       /* result in a null field */
{
    register char *p, *r;
    static char *savept;
    char	*strpbrk();
    
    p = (string == NULL)? savept : string;
    if (p == 0)
        return(NULL);
    if (*p == '\0')
        return(NULL);
    if ((r = strpbrk(p, sepset)) == NULL)       /* move past token */
        savept = 0;     /* indicate this is the last token */
    else {
        *r = '\0';
        savept = ++r;
    }
    return(p);
}


help(help_msg)
char    *help_msg;
{
    putp(clear_screen);              /* clear screen */
    puts("\n");
    fputs(help_msg, stdout);
    putp(tparm(cursor_address, MSGLINE, 9));
    fputs("Enter any character to continue.", stdout);
    rawgetchar();
    putp(clear_screen);              /* clear screen */
}


#ifdef TERMCAP
mputc(c)
char	c;
{
    putchar(c);
}
#endif
