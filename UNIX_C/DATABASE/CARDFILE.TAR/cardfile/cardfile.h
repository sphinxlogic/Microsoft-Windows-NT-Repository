#ifndef lint
static char ID_cardfile[] = "@(#)cardfile.h	3.1   DeltaDate 8/3/90    ExtrDate 10/6/90";
#endif

/*	CARDFILE.h	*/
#include	"string.h"

#define SWIDTH	80	/* width of screen line */
#define	SLENGTH	24	/* length of screen */
#define PWIDTH	80	/* width of printer line */
#define	MSGLINE	(SLENGTH-2) /* screen message line */
#define DBSIZE	1024	/* max size of record in DB file */
#define AKSIZE	270	/* max size of record in AK file */
#define MAXFLDS	15	/* max number of fields in record */
#define FNSIZE	128	/* max size of a file name */
#define PLENGTH	66	/* number of lines per page on printer */
#define MAXAK	15	/* max number of AK files */
#define FLDLEN	256	/* max length of one field */
#define TSIZE	20	/* max length of field title */
#define BUFSIZE	(2*1024) /* size of buffer used to build AK files */
#define MAXKEYS	500	/* maximium keys on one find screen */
#define	MAXFMT	128	/* maximum length of a format string */
#ifndef TRUE
# define TRUE	1
# define FALSE	0
#endif

typedef long	diskptr;

struct Sdata	{	/* structure to describe a screen field */
    char	*S_title;
    int		S_length;
    char	*S_result;
    char	*S_dfault;
    int		S_page;
    int		S_Lrow;
    int		S_Lcol;
    int		S_Drow;
    int		S_Dcol;
    char	*S_Dfmt;
};

struct Fdata	{	/* structure to define a data-base field */
    char	F_title[TSIZE+1];
    char	F_required;
    int		F_length;
    char	F_key;
    char	F_seps[6];
    char	F_page;		/* What screen page this field will appear on */
    int		F_Lrow;		/* The screen field label row address */
    int		F_Lcol;		/* The screen field label column address */
    int		F_Drow;		/* The screen field data row address */
    int		F_Dcol;		/* The screen field data column address */
    char	F_Dfmt[MAXFMT+1];	/* The screen field data format (fmt_chk) */
};

struct AKdata	{	/* structure to hold Alternate Key file info */
    int		A_fldnum;
    char	A_akname[FNSIZE+1];
};

struct	cchar {		/* strings received from terminal */
    char	ch;
    int		(*action)();
    struct	cchar *next;
    struct	cchar *alt;
};

extern char	datadir[];
SIGRTN		getout();
void		exit(), free();
unsigned	sleep();
char		*tparm();
