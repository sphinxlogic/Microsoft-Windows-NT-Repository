#ifndef lint
static char Sccsid[] = "@(#)rawio.c	3.1    DeltaDate 8/3/90    ExtrDate 10/6/90";
#endif

/*	RAWIO.C		*/

#include "ascii.h"
#include "cardfile.h"

static int	echo_f = 1;

int
rawgetchar()
{
    int		ch;
    
    ch = getchar();
    if (ch == DEL) {
	msg("Again to quit");
	if ((ch = getchar()) == DEL)
	    getout();
	msg("");
	resetcursor();
    }
    if (echo_f)
	rawputchar(ch);
    return (ch);
}

rawputchar(ch)
char    ch;
{
    putchar(ch);
}

echo()
{
    echo_f = 1;
}

noecho()
{
    echo_f = 0;
}
