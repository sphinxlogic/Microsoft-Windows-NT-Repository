#ifndef lint
static char Sccsid[] = "@(#)menu.c	3.1    DeltaDate 8/3/90    ExtrDate 10/6/90";
#endif

/*	MENU.C		*/
/*	This subroutine is used to display a menu of commands
**	and wait for the user to select one.
**	It returns the number of the command selected.
**/
#include "cardfile.h"

menu(dbname, functs)
char    *dbname;
char    **functs;
{
    int         func;
    char        dummy[2];
    struct      Sdata   *sp, *mscreen;
    char	*malloc();

    mscreen = (struct Sdata*)malloc((MAXFLDS+1) * sizeof(struct Sdata));
    sp = mscreen;
    do {
        sp->S_title = *functs;
        sp->S_length = 1;
        sp->S_result = dummy;
        sp->S_dfault = 0;
	sp->S_page = -1;
	sp->S_Lrow = -1;
	sp->S_Lcol = -1;
	sp->S_Drow = -1;
	sp->S_Dcol = -1;
	sp->S_Dfmt = "";
        ++sp;
    } while (*++functs);
    sp->S_title = 0;
    screen(dbname, mscreen, 0, &func, FALSE);
    free((char*)mscreen);
    return (func);
}
