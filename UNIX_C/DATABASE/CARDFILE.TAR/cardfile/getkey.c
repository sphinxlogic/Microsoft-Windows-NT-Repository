#ifndef lint
static char Sccsid[] = "@(#)getkey.c	3.1    DeltaDate 8/3/90    ExtrDate 10/6/90";
#endif

/*      GETKEY.C        */
/*      This subroutine is used to search an alternate key file
        to find records matching the input value. It returns the
        offset of the record in the DB file if found, or -1 if
        no match was found.
*/
#include "stdio.h"
#include "cardfile.h"
#include "ascii.h"

diskptr
getkey(file, val)
FILE    *file;
char    *val;
{
    static char *match;
    char        rcd[AKSIZE];
    long        atol();
    char        *fgets();
    int	rc;
    
    if (val != 0) {     /* first time */
        match = val;
        fseek(file, 0L, 0);
    }
    while (fgets(rcd, AKSIZE, file) != NULL) {
        if ((rc = keymatch(rcd, match)) == -1) {
	    break;
	} else if (rc == 1) {
            return (atol(strchr(rcd, ':')+1));
        }
    }
    return (-1L);
}
