#ifndef lint
static char Sccsid[] = "@(#)maint.c	3.1    DeltaDate 8/3/90    ExtrDate 10/6/90";
#endif

/*      MAINT.C         */
/*      This module is displays the maintenance menu and
        controls the execution of the associated routines
*/
#include "stdio.h"
#include "cardfile.h"

char    *mfuncts[]   = {"EXIT        ",
                        "DUMP        ",
                        "COMPRESS    ",
                        "REBUILD AK's",
                        "EXTRACT     ",
                        0
                        };
#define DUMP    1
#define COMPRES 2
#define RBUILD  3
#define EXTRACT 4
#define EXIT    0


maint(fields, dbname, ak_data)
struct  Fdata   *fields;
char    *dbname;
struct  AKdata  *ak_data;
{
    char        first[SWIDTH];
    int         func;
    
    sprintf(first, "Maintenance functions for %s", dbname);
    while ((func = menu(first, mfuncts)) != EXIT) {
        switch (func) {
        case DUMP:
            dumpdb(dbname, ak_data, fields);
            continue;
        case COMPRES:
            compress(dbname);
            rbuildak(dbname, ak_data, fields);
            continue;
        case RBUILD:
            rbuildak(dbname, ak_data, fields);
            continue;
        case EXTRACT:
            extract(fields, dbname);
            continue;
        default:
            msg("Illegal function chosen");
        }
    }
}
