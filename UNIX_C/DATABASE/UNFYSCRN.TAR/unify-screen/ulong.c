/*
 * $Header: ulong.c,v 1.5 87/06/09 11:53:15 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	ulong.c,v $
 * Revision 1.5  87/06/09  11:53:15  brandon
 * Right-justified buffer display; repositioned cursor after conversion errors.
 * 
 * Revision 1.4  87/06/01  08:37:43  brandon
 * Added ^V (view) capability for related records.
 * 
 * Revision 1.3  87/05/27  14:42:56  brandon
 * Made sure buffer was padded with spaces.
 * 
 * Revision 1.2  87/05/26  15:44:20  brandon
 * Forgot to cast sprintf().
 * 
 * Revision 1.1  87/05/26  13:34:07  brandon
 * Initial revision
 * 
 * Revision 1.3  87/05/12  12:04:03  brandon
 * Changed to pass FWD, BACK, GO without checking the data buffer
 * 
 * Revision 1.2  87/04/29  11:30:39  brandon
 * Added RCS header information
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * Input an item of type (long).
 */

int ulong(len, buf)
long *buf; {
	char ibuf[10];
	int rc, cnt, sign, y, x;

	setraw();
	if (len > 9)
		len = 9;	/* (long)'s are max len = 9 */
	(void) sprintf(ibuf, "%*ld", len, *buf);
	getyx(stdscr, y, x);
	for (;;) {
		(void) move(y, x);
		if ((rc = inl(ibuf, len, 0)) == BACK || rc == FWD || rc == GO || rc == LOOK)
			return rc;
		for (cnt = 0; cnt < len && ibuf[cnt] == ' '; cnt++)
			;
		if (cnt == len) {
			prtmsg(1, 23, "Invalid number");
			continue;
		}
		*buf = 0L;
		sign = 0;
		if (ibuf[cnt] == '-') {
			sign = 1;
			if (++cnt == len) {
				prtmsg(1, 23, "Invalid number");
				continue;
			}
		}
		for (; cnt < len && isdigit(ibuf[cnt]); cnt++) {
			*buf *= 10;
			*buf += ibuf[cnt] - '0';
		}
		for (; cnt < len && ibuf[cnt] == ' '; cnt++)
			;
		if (cnt == len)
 			break;
		prtmsg(1, 23, "Invalid number");
	}
	if (sign)
		*buf = - *buf;
	return rc;
}
