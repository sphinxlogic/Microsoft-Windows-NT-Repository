/*
 * $Header: pshort.c,v 1.1 87/04/29 12:47:33 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	pshort.c,v $
 * Revision 1.1  87/04/29  12:47:33  brandon
 * Initial revision
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * Display a value of type INT.
 */

void pshort(len, buf)
short *buf; {
	(void) setraw();
	(void) attron(A_UNDERLINE);
	(void) printw("%*d", len, *buf);
	(void) attroff(A_UNDERLINE);
}
