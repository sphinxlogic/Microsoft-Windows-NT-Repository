/*
 * $Header: pamt.c,v 1.1 87/04/29 12:18:40 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	pamt.c,v $
 * Revision 1.1  87/04/29  12:18:40  brandon
 * Initial revision
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * Display a value of type AMT.
 */

void pamt(len, buf)
long *buf; {
	(void) setraw();
	if (len < 4)
		return;
	(void) attron(A_UNDERLINE);
	(void) printw("%*ld.%02d", len - 3, *buf / 100L, *buf % 100L);
	(void) attroff(A_UNDERLINE);
}
