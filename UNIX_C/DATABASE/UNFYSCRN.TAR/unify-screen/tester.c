#include <curses.h>
#include <signal.h>

bye() {
	setcook();
	abort();
	abort();
}

main() {
	signal(SIGQUIT, bye);
	putenv("DBPATH=/proj/e_u");
	setxrc(4);
	addrec(4, "TEST#001");
	gdata(0, 5, 11);
	delete(4);
	setcook();
	exit(0);
}

error(s,ier){setcook();printf("%s(%d)\n",s,ier);abort();abort();}
