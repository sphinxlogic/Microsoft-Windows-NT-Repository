/*
 * $Header: ptime.c,v 1.2 87/04/29 12:57:34 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	ptime.c,v $
 * Revision 1.2  87/04/29  12:57:34  brandon
 * DUMB!!!  Forgot to deref the buffer
 * 
 * Revision 1.1  87/04/29  12:49:31  brandon
 * Initial revision
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * Display a value of type HR.
 */

void ptime(buf)
short *buf; {
	(void) setraw();
	(void) attron(A_UNDERLINE);
	(void) printw("%02d:%02d", *buf / 100, *buf % 100);
	(void) attroff(A_UNDERLINE);
}
