/*LINTLIBRARY*/

/*
 * UNITRIEVE(r) lint library
 */

#include <fdesc.h>

char langtp[2] = {'A', 'M'};
int logacl = 0;
static char __v_p_buf[128] = "unknown";
char *V_prgnm = __v_p_buf;

int pfield(fld, buf) char *buf; { return 0; }
int accsfld(fld, pass, rwf) char *pass; { return 0; }
int fldesc(fld, buf) FLDESC *buf; { return 0; }
short kday(date) int date[3]; { return 0; }
void kdate(day, date) short day; int date[3]; {}
int ivcmp(v1, v2, l) char *v1, *v2; { return 0; }
void cfill(c, v, l) char *v; {}
int gfield(fld, buf) char *buf; { return 0; }
#ifdef UNIFY32
void dspdt(d, buf) short d; char *buf; {}
char *getdoms(fld, typ) { return (char *) 0; }
int domchk(fld, buf) char *buf; { return 0; }
int numflds() { return 0; }
char *fldsyn(f) { return ""; }
int reckey(r) { return 0; }
int seqacc(r, t) { return 0; }
int loc(r, tp) long *tp; { return 0; }
int setloc(r, t) long t; { return 0; }
#endif
