/*
 * $Header: ishort.c,v 1.6 87/06/09 11:45:35 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	ishort.c,v $
 * Revision 1.6  87/06/09  11:45:35  brandon
 * Added code to relocate cursor after conversion error message.
 * 
 * Revision 1.5  87/06/01  08:30:29  brandon
 * Added ^V (view) capability for related records.
 * 
 * Revision 1.4  87/05/26  13:32:29  brandon
 * Changed for new inl() (forces no-update mode).
 * 
 * Revision 1.3  87/05/12  12:03:40  brandon
 * Changed to pass FWD, BACK, GO without checking the data buffer
 * 
 * Revision 1.2  87/04/29  11:30:48  brandon
 * Added RCS header information
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * Input an item of type (short).
 */

int ishort(len, buf)
short *buf; {
	char ibuf[4];
	int rc, cnt, sign, y, x;

	setraw();
	if (len > 4)
		len = 4;	/* (short)'s are max len = 4 */
	getyx(stdscr, y, x);
	for (;;) {
		(void) move(y, x);
		if ((rc = inl(ibuf, len, 1)) == BACK || rc == FWD || rc == GO || rc == LOOK)
			return rc;
		for (cnt = 0; cnt < len && ibuf[cnt] == ' '; cnt++)
			;
		if (cnt == len) {
			prtmsg(1, 23, "Invalid number");
			continue;
		}
		*buf = 0;
		sign = 0;
		if (ibuf[cnt] == '-') {
			sign = 1;
			if (++cnt == len) {
				prtmsg(1, 23, "Invalid number");
				continue;
			}
		}
		for (; cnt < len && isdigit(ibuf[cnt]); cnt++) {
			*buf *= 10;
			*buf += ibuf[cnt] - '0';
		}
		for (; cnt < len && ibuf[cnt] == ' '; cnt++)
			;
		if (cnt == len)
 			break;
		prtmsg(1, 23, "Invalid number");
	}
	if (sign)
		*buf = - *buf;
	return rc;
}
