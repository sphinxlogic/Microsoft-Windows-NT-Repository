/*
 * $Header: plong.c,v 1.1 87/04/29 12:47:21 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	plong.c,v $
 * Revision 1.1  87/04/29  12:47:21  brandon
 * Initial revision
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * Display a value of type LONG.
 */

void plong(len, buf)
long *buf; {
	(void) setraw();
	(void) attron(A_UNDERLINE);
	(void) printw("%*ld", len, *buf);
	(void) attroff(A_UNDERLINE);
}
