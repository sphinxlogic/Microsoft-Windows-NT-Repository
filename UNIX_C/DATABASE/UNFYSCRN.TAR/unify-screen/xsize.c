/*
 * $Header: xsize.c,v 1.1 87/05/12 10:49:42 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	xsize.c,v $
 * Revision 1.1  87/05/12  10:49:42  brandon
 * Initial revision
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * The "xsize" function returns the external size of a screen field.
 */

int xsize(typ, len) {
	switch (typ) {
	case INT:
	case LONG:
	case STRNG:
		return len;
	case DATE:
		return 8;
	case HR:
		return 5;
	case AMT:
	case HAMT:
		return len + 3;
	case FLT:
		return len / 10;
	default:
		xerror(typ, "xsize", "Unknown internal type");
		/*NOTREACHED*/
	}
}
