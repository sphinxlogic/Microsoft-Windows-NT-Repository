/*
 * $Header: ptct_crt.c,v 1.2 87/04/29 11:31:17 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	ptct_crt.c,v $
 * Revision 1.2  87/04/29  11:31:17  brandon
 * Added RCS header information
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * ENTRY POINT:  ptct_crt() -- turn on terminal write protection
 *
 * DIFFERENCE FROM UNIFY:  All we do is check fd == 1, since curses handles the
 * screen itself.
 */

void ptct_crt(fd, flg) {
	if (fd != 1)
		xerror(-1, "ptct_crt", "Multi-terminal operation on fd %d not supported", fd);
}
