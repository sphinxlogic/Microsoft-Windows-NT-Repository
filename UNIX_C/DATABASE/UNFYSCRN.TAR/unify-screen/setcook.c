/*
 * $Header: setcook.c,v 1.2 87/04/29 11:31:20 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	setcook.c,v $
 * Revision 1.2  87/04/29  11:31:20  brandon
 * Added RCS header information
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * Leave curses mode.  Again, an assumption is made -- most UNIFY programs
 * under pre-3.2 UNIFY DO NOT FOLLOW THE ASSUMPTION!!! so don't recompile
 * UNIFY stuff unless you don't mind the program not cleaing up after itself.
 */

void setcook() {
	if (stdscr != (WINDOW *) 0) {
		(void) endwin();
		stdscr = (WINDOW *) 0;
	}
}
