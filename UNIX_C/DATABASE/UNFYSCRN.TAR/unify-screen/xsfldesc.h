/*
 * The internal screen field structure.  xsfldesc() return a POINTER to the
 * actual struct, so be careful!!!  Only one update operation is defined:  to
 * OR the flag UPCASE (below) with it to tell USC to force input to be upper
 * case on the field.
 */

struct xsfldesc {
	char xsf_nam[8];
	char xsf_dbfld[44];
	short xsf_fld;
	short xsf_typ;
	short xsf_len;
	short xsf_col;
	short xsf_lin;
	char xsf_prmp[40];
	short xsf_pcol;
	short xsf_plin;
};

#define XSFLDESC	struct xsfldesc
#define UPCASE		0x80

extern XSFLDESC *xsfldesc();
