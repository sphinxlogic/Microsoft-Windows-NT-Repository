/*
 * $Header: dbherr.c,v 1.1 87/04/29 14:57:38 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	dbherr.c,v $
 * Revision 1.1  87/04/29  14:57:38  brandon
 * Initial revision
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * ENTRY POINT:  dbherr() -- Print a data dictionary error message and exit
 *
 * DIFFERENCE FROM UNIFY:  *Always* uses the error log, even in pre-3.2
 * versions.  Also, my idea of what an error should log seems to differ from
 * that of Unify Corp.
 */

void dbherr(s)
char *s; {
	(void) strcpy(errcall, "dbherr");
	xerror(0, "Data Dictionary error -- see Notes", "%s", s);
}
