/*LINTLIBRARY*/

/*
 * Curses(3x) routines (llib-lcurses is empty!!!?)
 */

#define NOMACROS
#include <curses.h>

#ifndef TERMCAP

/* curses.h defines struct screen, never declares structure */

struct screen { char dummy; };

#endif

WINDOW *stdscr = (WINDOW *) 0;
WINDOW *curscr = (WINDOW *) 0;
int LINES = 0, COLS = 0;
char *Def_term = "unknown";
char ttytype[128] = "unknown";

int echo() {return 0;}
int noecho() {return 0;}
int cbreak() {return 0;}
int nocbreak() {return 0;}
int nl() {return 0;}
int nonl() {return 0;}
int waddch(win, ch) WINDOW *win; {return 0;}
int wgetch(win) WINDOW *win; {return 0;}
int waddstr(win, s) WINDOW *win; char *s; {return 0;}
int wgetstr(win, s) WINDOW *win; char *s; {return 0;}
int wmove(win, y, x) WINDOW *win; {return 0;}
int wclear(win) WINDOW *win; {return 0;}
int werase(win) WINDOW *win; {return 0;}
int wclrtobot(win) WINDOW *win; {return 0;}
int wclrtoeol(win) WINDOW *win; {return 0;}
int winsertln(win) WINDOW *win; {return 0;}
int wdeleteln(win) WINDOW *win; {return 0;}
int wrefresh(win) WINDOW *win; {return 0;}
int winsch(win, ch) WINDOW *win; {return 0;}
int wdelch(win) WINDOW *win; {return 0;}
int wstandout(win) WINDOW *win; {return 0;}
int wstandend(win) WINDOW *win; {return 0;}
#ifndef TERMCAP
int flushinp() {return 0;}
int wattron(win, at) WINDOW *win; {return 0;}
int wattroff(win, at) WINDOW *win; {return 0;}
int wattrset(win, at) WINDOW *win; {return 0;}
int beep() { return 0; }
#endif TERMCAP
/* AARGH! ! ! ! !  Why is initscr() defined as (WINDOW *) ????? */
WINDOW *initscr() { return (WINDOW *) 0; }
int endwin() { return 0; }
/*VARARGS1 PRINTFLIKE1*/
int printw(s) char *s; { return 0; }
/*VARARGS2 PRINTFLIKE2*/
int wprintw(win, s) WINDOW *win; char *s; { return 0; }
/*VARARGS3 PRINTFLIKE3*/
int mvprintw(y, x, s) char *s; { return 0; }
/*VARARGS4 PRINTFLIKE4*/
int mvwprintw(win, y, x, s) WINDOW *win; char *s; { return 0; }
int winch(win) WINDOW *win; { return 0; }
int wsetscrreg(win, t, b) WINDOW *win; { return 0; }
int mvwaddch(win, y, x, ch) WINDOW *win; { return 0; }
int mvwgetch(win, y, x) WINDOW *win; { return 0; }
int mvwaddstr(win, y, x, s) char *s; WINDOW *win; { return 0; }
int mvwgetstr(win, y, x, s) char *s; WINDOW *win; { return 0; }
int mvwinch(win, y, x) WINDOW *win; { return 0; }
int mvwdelch(win, y, x) WINDOW *win; { return 0; }
int mvwinsch(win, y, x, c) WINDOW *win; { return 0; }
int mvaddch(y, x, c) { return 0; }
int mvgetch(y, x) { return 0; }
int mvaddstr(y, x, s) char *s; { return 0; }
int mvgetstr(y, x, s) char *s; { return 0; }
int mvinch(y, x) { return 0; }
int mvdelch(y, x) { return 0; }
int mvinsch(y, x, c) { return 0; }
int refresh() { return 0; }
int move(y, x) { return 0; }
int clrtoeol() { return 0; }
int addch(c) { return 0; }
int addstr(s) char *s; { return 0; }
int attron(a) { return 0; }
int attroff(a) { return 0; }
int erase() { return 0; }
int attrset(a) { return 0; }
int clearok(win) WINDOW *win; { return 0; }
int clear() { return 0; }
int standout() { return 0; }
int standend() { return 0; }
int clrtobot() { return 0; }
WINDOW *newwin(x, y, x1, y1) { return (WINDOW *) 0; }
int delwin(w) WINDOW *w; { return 0; }
int touchwin(w) WINDOW *w; { return 0; }
int box(w, v, h) WINDOW *w; { return 0; }
#ifdef TG
void wgraph(w, s) WINDOW *w; char *s; {}
#include "tgraph.h"
struct __g__ch_ __graph[25];
#endif
