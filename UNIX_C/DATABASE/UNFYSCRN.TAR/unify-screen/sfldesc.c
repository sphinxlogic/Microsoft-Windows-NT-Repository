/*
 * $Header: sfldesc.c,v 1.2 87/04/29 11:31:25 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	sfldesc.c,v $
 * Revision 1.2  87/04/29  11:31:25  brandon
 * Added RCS header information
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * ENTRY POINT:  sfldesc() -- Return screen field description
 *
 * DIFFERENCE FROM UNIFY:  None.  However, see xsfldesc().
 */

sfldesc(sfld, buf)
SFLDESC *buf; {
	if (sfld < 0 || sfld >= __nsf)
		return 0;
	buf->sf_fld = __scf[sfld].q_fld;
	buf->sf_col = __scf[sfld].q_fx;
	buf->sf_lin = __scf[sfld].q_fy;
	return 1;
}
