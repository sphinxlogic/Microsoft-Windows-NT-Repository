/*
 * $Header: clearscr.c,v 1.3 87/04/29 17:06:53 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	clearscr.c,v $
 * Revision 1.3  87/04/29  17:06:53  brandon
 * Now retains top 2 lines AFTER curses.  You can roll your own screen, but
 * you still can't use the menu handler's heading.
 * 
 * Revision 1.2  87/04/29  11:30:09  brandon
 * Added RCS header information
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * ENTRY POINT:  clearscr() -- Clear the screen preparatory to loading a new
 * screen form.
 *
 * DIFFERENCE FROM UNIFY:  Curses can't save the first three lines of the
 * screen.  (Two for UNIFY 3.2.)
 */

void clearscr() {
	(void) move(2, 0);
	(void) clrtobot();
}
