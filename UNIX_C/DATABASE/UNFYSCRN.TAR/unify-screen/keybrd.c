/*
 * $Header: keybrd.c,v 1.2 87/04/29 11:30:55 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	keybrd.c,v $
 * Revision 1.2  87/04/29  11:30:55  brandon
 * Added RCS header information
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * ENTRY POINT:  keybrd() -- lock or unlock the terminal keyboard
 *
 * DIFFERENCE FROM UNIFY:  I don't know if UNIFY uses this (it doesn't mention
 * termcap support for it), but here it's a no-op except for checking fd = 1
 * as usual.
 */

void keybrd(fd, flg) {
	if (fd != 1)
		xerror(-1, "eras_ln", "Multi-terminal operation on fd %d not supported", fd);
}
