/*
 * $Header: phamt.c,v 1.1 87/04/29 12:35:58 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	phamt.c,v $
 * Revision 1.1  87/04/29  12:35:58  brandon
 * Initial revision
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * Print a value of type HAMT.
 */

void phamt(len, buf)
double *buf; {
	(void) setraw();
	(void) attron(A_UNDERLINE);
	(void) printw("%*.2f", len, *buf / 100.0);
	(void) attroff(A_UNDERLINE);
}
