/*
 * $Header: setxrc.c,v 1.2 87/04/29 11:31:23 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	setxrc.c,v $
 * Revision 1.2  87/04/29  11:31:23  brandon
 * Added RCS header information
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * Set the extended-return-code flag to the specified value.
 */

int setxrc(f) {
	int of;

	of = __ext_rcodes;
	__ext_rcodes = f;
	return of;
}
