/*
 * $Header: eras_pg.c,v 1.1 87/05/11 12:26:53 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	eras_pg.c,v $
 * Revision 1.1  87/05/11  12:26:53  brandon
 * Initial revision
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * Groping in the dark, trying to prevent the loading of the original Unify
 * code, which conflicts with the curses echo() function (terminfo only)
 */

void eras_pg(fd) {
	if (fd != 1)
		xerror(-1, "eras_pg", "Multi-terminal operation on fd %d not supported", fd);
	(void) clrtobot();
}
