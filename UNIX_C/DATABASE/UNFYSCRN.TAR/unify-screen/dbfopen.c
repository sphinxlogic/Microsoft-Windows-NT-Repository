/*
 * $Header: dbfopen.c,v 1.3 87/04/29 15:00:47 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	dbfopen.c,v $
 * Revision 1.3  87/04/29  15:00:47  brandon
 * Since xerror() calls dbfopen(), dbfopen() cannot call xerror().
 * 
 * Revision 1.2  87/04/29  11:30:19  brandon
 * Added RCS header information
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * Open a file associated with a database.
 */

FILE *_dbfopen(fn, mode)
char *fn, *mode; {
	char *dbf;

	if ((dbf = dbfile(fn, (char *) 0)) == (char *) 0)
		return (FILE *) 0;	/* xerror() calls us */
	return fopen(dbf, mode);
}
