/*
 * $Header: prmp.c,v 1.2 87/04/29 11:31:10 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	prmp.c,v $
 * Revision 1.2  87/04/29  11:31:10  brandon
 * Added RCS header information
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * ENTRY POINT:  prmp() -- Display a string
 *
 * DIFFERENCE FROM UNIFY:  Rather than dim/normal, uses regular output vs.
 * data fields underlined (if supported).
 */

void prmp(x, y, str)
char *str; {
	(void) mvaddstr(y, x, str);
}
