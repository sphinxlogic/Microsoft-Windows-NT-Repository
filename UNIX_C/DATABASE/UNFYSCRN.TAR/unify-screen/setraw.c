/*
 * $Header: setraw.c,v 1.2 87/04/29 11:31:22 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	setraw.c,v $
 * Revision 1.2  87/04/29  11:31:22  brandon
 * Added RCS header information
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * Set up curses, if necessary.  Called by all USC I/O routines.  This routine
 * is based on an assumption of how setraw() is used.
 */

void setraw() {
	if (stdscr == (WINDOW *) 0) {
		(void) initscr();
		(void) noecho();
		(void) cbreak();
		(void) nonl();
	}
}
