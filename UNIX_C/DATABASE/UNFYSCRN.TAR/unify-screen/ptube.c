/*
 * $Header: ptube.c,v 1.1 87/04/29 13:37:02 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	ptube.c,v $
 * Revision 1.1  87/04/29  13:37:02  brandon
 * Initial revision
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * ENTRY POINT:  ptube() -- Display data from a buffer in the format of a
 * database field
 *
 * DIFFERENCE FROM UNIFY:  FLT ends up being printed with %g.  See pflt()
 * for the gory details.
 */

void ptube(x, y, fld, buf)
char *buf; {
	FLDESC fd;

	if (!fldesc(fld, &fd))
		xerror(-1, "ptube", "Invalid database field %d", fld);
	outscrf(x, y, fd.f_typ, fd.f_len, buf);
}
