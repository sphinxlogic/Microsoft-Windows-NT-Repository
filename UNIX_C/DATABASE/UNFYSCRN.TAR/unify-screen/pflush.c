/*
 * $Header: pflush.c,v 1.1 87/06/01 15:32:07 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	pflush.c,v $
 * Revision 1.1  87/06/01  15:32:07  brandon
 * Initial revision
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * The pflush() function does a refresh() without having to include the
 * curses header file in a user program not otherwise using curses.
 */

void pflush() {
	(void) refresh();
}
