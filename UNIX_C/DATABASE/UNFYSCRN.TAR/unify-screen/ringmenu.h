struct ringmenu {
	char c_key;
	char *c_title;
	char *c_desc;
};

#define EOM		'\0'	/* end of ring menu */
#define INVIS		""	/* invisible menu entry */
