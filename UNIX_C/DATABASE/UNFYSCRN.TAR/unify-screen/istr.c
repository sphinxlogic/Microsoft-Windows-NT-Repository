/*
 * $Header: istr.c,v 1.3 87/05/26 13:32:49 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	istr.c,v $
 * Revision 1.3  87/05/26  13:32:49  brandon
 * Changed for new inl() (forces no-update mode).
 * 
 * Revision 1.2  87/04/29  11:30:50  brandon
 * Added RCS header information
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * Get a string.  Very easy, since no checking is needed.
 */

int istr(len, buf)
char *buf; {
	setraw();
	return inl(buf, len, 1);
}
