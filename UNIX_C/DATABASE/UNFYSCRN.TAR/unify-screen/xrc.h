extern int setxrc();

#define XRC_GO	1	/* allow new return code -5 (also -6 if XRC_XOK) */
#define XRC_XOK	2	/* allow new return code -7 (also -6 if XRC_GO)  */
#define XRC_LOOK 4	/* allow new return code -8 (internal) */
