/*
 * $Header: prmprv.c,v 1.2 87/04/29 11:31:14 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	prmprv.c,v $
 * Revision 1.2  87/04/29  11:31:14  brandon
 * Added RCS header information
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * ENTRY POINT:  prmprv() -- Display a string in reverse video
 *
 * DIFFERENCE FROM UNIFY:  None (!)
 */

void prmprv(x, y, str)
char *str; {
	(void) attron(A_REVERSE);
	(void) mvaddstr(y, x, str);
	(void) attroff(A_REVERSE);
}
