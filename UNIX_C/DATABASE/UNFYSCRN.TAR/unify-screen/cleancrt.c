/*
 * $Header: cleancrt.c,v 1.2 87/04/29 11:29:57 brandon Exp $
 *
 * ``USC'' -- UNIFY(r) Screens using Curses
 * UNIFY(r) is a registered trademark of Unify Corporation.
 *
 * THIS PROGRAM IS NOT BASED ON COPYRIGHTED CODE OF UNIFY CORPORATION, AND
 * IS HEREBY PLACED IN THE PUBLIC DOMAIN.
 *
 * $Log:	cleancrt.c,v $
 * Revision 1.2  87/04/29  11:29:57  brandon
 * Added RCS header information
 * 
 */

/*LINTLIBRARY*/

#include "usc.h"

/*
 * ENTRY POINT:  cleancrt() -- Clear the foreground (data prompts) on the
 * screen.
 *
 * DIFFERENCE FROM UNIFY:  Curses doesn't know about clear foreground, and
 * if it did it'd do it iteself anyway.  We always call erasprmp() and let
 * curses optimize the result.
 */

void cleancrt() {
	erasprmp(0, __nsf - 1);
}
