/*
 * Program: ls_archive
 *
 * Program functional details are provided in the README file and the man page.
 * Operational details are provided by reading the source code (there are even
 * a few comments scattered throughout).
 *
 * Copyright 1992 David H. Brierley, All Rights Reserved
 */

#include <stdio.h>
#include <sys/types.h>

#ifdef	TYPE_DIRENT
# include <dirent.h>
  typedef struct dirent DIRENT;
#endif

#ifdef	TYPE_DIRECT
# include <sys/dir.h>
  typedef struct direct DIRENT;
#endif

#include <sys/stat.h>
#ifdef	BSD
#include <strings.h>
#else
#include <string.h>
#include <malloc.h>
#endif
#include <time.h>
#include <unistd.h>
#include <pwd.h>


extern int      optind;
extern char    *optarg;
extern int      getopt (int argc, char *argv[], char *key);

static char    *mode_vals[] = {
    "---", "--x", "-w-", "-wx",
    "r--", "r-x", "rw-", "rwx"
};

struct ulist {
    int             nl_uid;
    char            nl_username[16];
    struct ulist   *nl_next;
};
typedef struct ulist ULIST;


/* ls_archive.c */
int             main (int argc, char *argv[]);
void            list_directory (char *dir_name, int aflg, int tsort, char *fmt);
int             time_sort (DIRENT ** d1, DIRENT ** d2);
void            show_owner (struct stat buf);
/* scandir.c */
int             scandir (char *d, DIRENT * (*n[]), int (*s) (), int (*c) ());
int             alphasort (DIRENT ** d1, DIRENT ** d2);

#ifndef	S_IFLNK
# define	lstat(f,p)	stat((f),(p))
#endif

static char    *SccsId = "@(#) ls_archive.c: version 1.9 3/28/92 23:05:10";

int
main (int argc, char *argv[])
{
    int             all_flag = 0;
    int             time_order = 0;
    int             show_dir = 0;
    char            fmt_string[32];
    int             optc;

    all_flag = time_order = show_dir = 0;
    (void) strcpy (fmt_string, "dsn");

    while ((optc = getopt (argc, argv, "tsaf:")) != EOF) {
	switch (optc) {
	case 'a':
	    all_flag = 1;
	    break;
	case 't':
	    ++time_order;
	    break;
	case 's':
	    show_dir = 1;
	    break;
	case 'f':
	    (void) strncpy (fmt_string, optarg, sizeof (fmt_string));
	    break;
	}
    }

    if (optind < argc) {
	if (chdir (argv[optind]) == -1) {
	    perror (argv[0]);
	    fprintf (stderr,
		     "Unable to change directory to '%s'\n",
		     argv[optind]);
	    exit (1);
	}
    }

    if ((show_dir == 0) || (argv[optind] == NULL)) {
	argv[optind] = "";
    }

    list_directory (argv[optind], all_flag, time_order, fmt_string);

    return (0);

}

/*
 * Procedure: list_directory
 * 
 * This procedure is called recursively to list out the contents of a directory.
 * Before calling the routine the caller should execute a chdir() to the
 * requested directory.  The directory name that is passed to this routine
 * should be the complete name relative to the start of the program.
 */
void
list_directory (char *dir_name, int aflg, int tsort, char *fmt)
{
    struct stat     sbuf;
    DIRENT         *dp;
    DIRENT        **dp_list;
    int             nitems;
    int             xitem;
    char            filename[1024];
#ifdef	S_IFLNK
    char            link[1024];
    int             len;
#endif
    char            sep_char[2];
    char           *fmt_opt;
    struct tm      *tm;
    int             m1;
    int             m2;
    int             m3;

    if (tsort == 0) {
	nitems = scandir (".", &dp_list, NULL, alphasort);
    }
    else {
	nitems = scandir (".", &dp_list, NULL, time_sort);
    }
    if (nitems == -1) {
	return;
    }

    if (*dir_name != '\0') {
	(void) strcpy (sep_char, "/");
    }
    else {
	sep_char[0] = '\0';
    }

    /*
     * First we scan for regular files.
     */
    for (xitem = 0; xitem < nitems; ++xitem) {
	dp = dp_list[xitem];
	if (strcmp (dp -> d_name, ".") == 0) {
	    continue;
	}
	if (strcmp (dp -> d_name, "..") == 0) {
	    continue;
	}
	if ((aflg == 0) && (*dp -> d_name == '.')) {
	    continue;
	}
	if (lstat (dp -> d_name, &sbuf) == -1) {
	    continue;
	}
	if ((sbuf.st_mode & S_IFMT) == S_IFDIR) {
	    continue;
	}

	/*
	 * Print out each of the items requested in the format string
	 */
	fmt_opt = fmt;
	while (*fmt_opt) {
	    switch (*fmt_opt) {
	    case 'd':		/* date and time */
		tm = localtime (&sbuf.st_mtime);
		printf ("%02d/%02d/%02d %02d:%02d",
			tm -> tm_year, tm -> tm_mon + 1, tm -> tm_mday,
			tm -> tm_hour, tm -> tm_min);
		break;
	    case 's':		/* size */
		printf ("%8d", sbuf.st_size);
		break;
	    case 'm':		/* modes (permissions) */
		m1 = (sbuf.st_mode >> 6) & 07;
		m2 = (sbuf.st_mode >> 3) & 07;
		m3 = (sbuf.st_mode) & 07;
		printf ("-%s%s%s",
			mode_vals[m1], mode_vals[m2], mode_vals[m3]);
		break;
	    case 'o':		/* owner */
		show_owner (sbuf);
		break;
	    case 'n':		/* name */
		printf ("%s%s%s",
			dir_name, sep_char, dp -> d_name);
#ifdef		S_IFLNK
		if ((sbuf.st_mode & S_IFMT) == S_IFLNK) {
		    len = readlink (dp -> d_name, link, sizeof (link));
		    if (len == -1) {
			(void) strcpy (link, "[unable to read link]");
		    }
		    else {
			link[len] = '\0';
		    }
		    printf (" -> %s", link);
		}
#endif
		break;
	    }

	    /*
	     * If there are more items in the format string print a space and
	     * then loop back
	     */
	    if (*++fmt_opt) {
		printf (" ");
	    }
	}
	printf ("\n");
    }

    /*
     * And then we scan for directories
     */
    if (tsort == 1) {
	nitems = scandir (".", &dp_list, NULL, alphasort);
    }
    for (xitem = 0; xitem < nitems; ++xitem) {
	dp = dp_list[xitem];
	if (strcmp (dp -> d_name, ".") == 0) {
	    continue;
	}
	if (strcmp (dp -> d_name, "..") == 0) {
	    continue;
	}
	if ((aflg == 0) && (*dp -> d_name == '.')) {
	    continue;
	}
	if (lstat (dp -> d_name, &sbuf) == -1) {
	    continue;
	}
	if ((sbuf.st_mode & S_IFMT) != S_IFDIR) {
	    continue;
	}
	if (chdir (dp -> d_name) == -1) {
	    perror (dp -> d_name);
	    fprintf (stderr,
		     "Unable to change directory to '%s%s%s'\n",
		     dir_name, sep_char, dp -> d_name);
	    continue;
	}
	(void) sprintf (filename, "%s%s%s", dir_name, sep_char, dp -> d_name);
	list_directory (filename, aflg, tsort, fmt);
	if (chdir ("..") == -1) {
	    perror (dp -> d_name);
	    fprintf (stderr, "Unable to change directory back to '..'\n");
	    fprintf (stderr, "Program terminated\n");
	    exit (1);
	}
    }

    (void) free (dp_list);

}

/*
 * Procedure: time_sort
 * 
 * This procedure is called from qsort if a time order sort has been requested.
 * The two files are "stat"ed and the time stamps compared.  If either file
 * cannot be "stat"ed, a value of 0 is returned.  This is not really a
 * correct value but the stat should never fail.
 */
int
time_sort (DIRENT ** d1, DIRENT ** d2)
{
    struct stat     s1;
    struct stat     s2;

    if (lstat ((*d1) -> d_name, &s1) == -1) {
	return (0);
    }
    if (lstat ((*d2) -> d_name, &s2) == -1) {
	return (0);
    }

    return (s1.st_mtime - s2.st_mtime);

}

/*
 * Procedure: show_owner
 * 
 * This procedure prints out the username associated with a numeric uid value.
 * It keeps a linked list of uid/username matchings to avoid having to scan
 * the passwd file repeatedly.
 */
void
show_owner (struct stat buf)
{
    static ULIST   *head = NULL;
    ULIST          *ptr;
    ULIST          *old;
    struct passwd  *pw;

    old = NULL;
    for (ptr = head; ptr != NULL; ptr = ptr -> nl_next) {
	if (ptr -> nl_uid == buf.st_uid) {
	    printf ("%-8.8s", ptr -> nl_username);
	    return;
	}
	old = ptr;
    }

    pw = getpwuid (buf.st_uid);
    ptr = (ULIST *) malloc (sizeof (ULIST));
    if (pw == NULL) {
	(void) sprintf (ptr -> nl_username, "%d", buf.st_uid);
    }
    else {
	(void) strcpy (ptr -> nl_username, pw -> pw_name);
    }
    ptr -> nl_uid = buf.st_uid;
    ptr -> nl_next = NULL;

    if (head == NULL) {
	head = ptr;
    }
    else {
	old -> nl_next = ptr;
    }

    printf ("%-8.8s", ptr -> nl_username);

}
