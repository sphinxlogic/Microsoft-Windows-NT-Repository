#include	<curses.h>
#include	"ils.h"
#include	"get.h"

extern	int	syms;	/* number of symbols on symbol table */
extern	struct	symbol	*symtab[];
extern	char	*pnam;
extern	int	a_num;	/* number of arguments in list */
extern	int	a_ind;	/* index into current argument */
extern	char	*args[ILS_MAX_ARGS];
extern	char	cur_path[];		/* pointer to active path */
extern	int	modes;	/* what special flags might be set */

process_input(c,list,entry,entries,p,x,y,rx)
struct	d_entry	*list[];
int	entry, entries,x,y,rx;
char	p[],c;
{
	struct	value	*v;
	char	line[256];

	int	i=0;

	if(c==ILS_FORCE_KEYBOARD) {
		evaluate_line(line,p,list,entry,entries,x,y,rx);
		ils_doit(line);		/* execute the statement */
	}
	else {
		for(i=0;i<syms;i++)
			if(strcmp(symtab[i]->name,p)==0){/* found the command */
				perform_command(!c,symtab[i]->val,list,entry,entries,x,y,rx);
				break;		/* get out of loop */
			}
		if(i==syms)
			flash();
	}
}

perform_command(c,v,list,entry,entries,x,y,rx)
struct	value	*v;
struct	d_entry	*list[];
int	entry, entries,x,y,rx;
{
	char	line[256];
	int	i;

	while(v != (struct value *) NULL) {
		evaluate_line(line,v->v,list,entry,entries,x,y,rx);
		ils_doit(line);		/* execute the statement */
		v = v->next;
	}
	dealloc(args);
}

ils_doit(line)
char	*line;
{
	noraw();
	echo();
	clear();
	if(modes & ILS_ECHO_COMS)
		printw("%s\n",line);
	refresh();
#ifdef BSD
	endwin();
#endif

	system(line);		/* execute the statement */
#ifdef BSD
	printf("PRESS RETURN TO RETURN TO %s\n",pnam);
	getchar();
	initscr();
	scrollok(stdscr,TRUE);
	raw();
	noecho();
#endif

#ifdef SYSTEMV
	raw();
	noecho();
	standout();
	printw("Press any key to return to %s",pnam);
	standend();
	refresh();
	getch();
#endif SYSTEMV
}	

evaluate_line(line,s,list,entry,entries,x,y,rx)
char	s[], line[];
struct	d_entry	*list[];
int	entry, entries,x,y,rx;
{
	char		c, lable[160], arg[160], new_line[256];
	register	int	k;
	int		l, a=0, j, white=0, d, ln=0, i, line_ind=0;

	l = strlen(s);
	for(i=0;i<l;i++) {
		switch(c=s[i]) {
			case ILS_METACHAR:
				i++;
				for(k=d=0;i<l && d==0;i++) {
					switch(c=s[i]) {
						case META1:  /* possible delimeters */	
						case META2:	
						case META3:	
						case META4:	
						case META5:	
						case META6:	
						case META7:	
						case META8:	
						case META9:	
						case META10:	
						case META11:	
						case META12:	
						case META13:	
						case META14:	
						case META15:	
						case META16:	
						case META17:	
						case META18:	
						case ' ':
						case '\T':
							i--;
							d=1;
							break;
						default:
							lable[k++]=c;
							break;
					}
				}
				lable[k]='\0';
				insert_value(new_line,lable,list,entry,entries,s,&i,x,y,rx);
				i--;
				for(j=0;new_line[j]!='\0';j++,line_ind++)
					line[line_ind] = new_line[j];
				white=0;
				break;
			case ' ':
			case '\t':
				if(white)
					break;
				white=1;
				line[line_ind++]=' ';
				break;
			default:
				white=0;
				line[line_ind++]=c;
				break;
		}
	}
	line[line_ind]='\0';
}

dealloc(args)
char	*args[];
{
	register int	i;

	for(i=0;i<ILS_MAX_ARGS && args[i]!=(char *)NULL;i++)
		free(args[i]);
}

insert_value(line,lable,list,entry,entries,s,ii,x,y,rx)
char	line[],lable[], s[];
int	*ii,x,y,rx;
struct	d_entry	*list[];
int	entry, entries;
{
	char	*c, prompt[256], new_prompt[256];
	register	int	i, parens, k;
	int	l;

	if(strcmp(lable,CURRENT_FILE)==0)
		strcpy(line,list[entry]->name);
	else if(strcmp(lable,PREFIX)==0) {
		for(i=0;i<strlen(list[entry]->name) && list[entry]->name[i]!='.';i++)
			line[i] = list[entry]->name[i];
		line[i]='\0';
	}
	else if(strcmp(lable,PWD_PATH)==0) {
		for(i=0;cur_path[i]!='\0';i++)
			line[i] = cur_path[i];
		line[i]='\0';
	}
	else if(strcmp(lable,INPUT)==0) {
		(*ii)++;
		for(parens=1,k=0;parens && s[*ii]!='\0';(*ii)++)
			switch(s[*ii]) {
				case ')':
					parens--;
					if(parens)
						prompt[k++]=s[*ii];
					break;
				case '(':
					parens++;
				default:
					prompt[k++]=s[*ii];
					break;
			}
		if(parens)
			return(1);
		prompt[k]='\0';

		move(y,x);
		
		evaluate_line(new_prompt,prompt,list,entry,entries,x,y,rx);
		l=strlen(new_prompt);
		printw(new_prompt);
		line[0]='\0';
		if(getst(rx-x-l-1,x+l,y,line,rx-x-l,&l,ALL_ALPHA,NULL)!=GET_RETURN)
			return(1);
	}
#ifdef SYSTEMV
	else if((c=(char *)getenv(lable))!=NULL)
		strcpy(line,c);
#endif SYSTEMV
}

/* add to the argument list */
/* c is for passing a single character, str is for passing a string,
 * type==0 for char, 1 for string */
add_to_args(c,str,type)
char	c, str[];
int	type;
{
	int	l,i;

	if(type) {
		l=strlen(str);
		for(i=0;i<l;i++)
			add_char_to_args(str[i]);
	}
	else
		add_char_to_args(c);
}

add_char_to_args(c)
char	c;
{
	static	char	line[256];
	static	int	line_ind=0;

	switch(c) {
		case ' ':
		case '\t':
			line[line_ind]='\0';
			args[a_num] = (char *) malloc(strlen(line)+1);
			strcpy(args[a_num],line);
			a_num++;
			a_ind=0;
			line_ind=0;
			break;
		default:
			line[line_ind++]=c;
			if(line_ind>254)
				line_ind=254;
			break;
	}
}
