/* includes for ils program */
#ifndef ushort
#include	<sys/types.h>
#endif

#ifndef stat_h
#include	<sys/stat.h>
#endif

#define ILS_MAX_ENTRIES		1000
#define ILS_MAX_PATS		256	/* max search patterns */
#define MAX_SYMBOLS		256	/* max symbol table size */

/* types of display modes (can be ored if appropriate) */
#define ILS_LONG	1	/* long format */
#define ILS_ALL		8	/* list ALL files (even . and ..) */
#define ILS_F_TYPE	0x10	/* directories end with '/', executables '*' */
#define ILS_ECHO_COMS	0x20	/* echo commands as executed */

#define ILS_ESCAPE	0x1b	/* hard-coded ESCAPE key */
#define ILS_ENTER	'\n'	/* hard-coded RETURN oe ENTER key */
#define ILS_RETURN	'\r'	/* hard-coded RETURN or ENTER key */
#define ILS_DOWN	'j'	/* hard-coded DOWN */
#define ILS_UP		'k'	/* hard-coded UP */
#define ILS_LEFT	'h'	/* hard-coded LEFT */
#define ILS_RIGHT	'l'	/* hard-coded RIGHT */
#define ILS_REDRAW	18	/* control-r */
#define ILS_REDRAW_ALT	12	/* control-l */
#define ILS_ENV		'?'	/* display symbol table */
#define ILS_FORCE_KEYBOARD ':'	/* force keyboard input */
#define ILS_EXIT_KEY	4	/* control-d */

#define ILS_FILE	".ils"	/* ils definition file (per user) */

#define ILS_INITIAL	-3	/* initial state (only done once) */
#define ILS_INITIAL2	-2
#define ILS_TOTAL_DRAW	-1	/* redraw path, title, and contents */
#define ILS_DRAW	0	/* display directory content */
#define ILS_KEYBOARD	1	/* get input from keyboard */
#define ILS_MOVE_CURSOR 2	/* erase last cursor, show new */
#define ILS_SHOW_CURSOR 3	/* redraw the cursor */
#define ILS_EXIT	4	/* exit this level of edit_directory */
#define ILS_SHOW_PATH	5	/* print the path on the top line */
#define ILS_ASCEND	6	/* go up into a new directory */
#define ILS_FIND_CURSOR 7	/* figure out best place to put cursor */

#ifdef BSD
#define flash() addch('\007')
#endif

#define ILS_METACHAR	'$'	/* Preceeds all ils variables */
#define META1		'/'	/* List of sh metacharacters that can be used */
#define META2		'<'	/* as delimeters. */
#define META3		'>'
#define META4		'('
#define META5		')'
#define META6		'['
#define META7		']'
#define META8		'&'
#define META9		'|'
#define META10		'`'
#define META11		'\"'
#define META12		'!'
#define META13		'~'
#define META14		'$'
#define META15		'\''
#define META16		'?'
#define META17		';'
#define META18		'.'

#define ILS_MAX_ARGS	256	/* max arguments per single command line */
#define MAXPATH		128
#define PWD		"/bin/pwd"

#define BOTTOM	0
#define TOP	1

typedef struct d_entry {
	char	*name;
	int	inode;
	struct	stat	stat;		/* stat for this file touched */
	struct	d_entry *next;		/* next entry in this directory */
	struct	d_entry *prev;		/* previous entry in this directory */
	struct	d_entry *contents;	/* if a directory, it's contents */
	long	touched;		/* flag for last time touched */
};

typedef struct	value {
	char	*v;
	struct	value	*next;
};

#define ILS_KEY_SEQUENCE	1
#define ILS_VARIABLE		2

typedef	struct	symbol {
	char	*name;			/* name of this symbol */
	int	type;			/* symbol type */
	struct	value	*val;		/* pointer to symbol value */
};

#define CURRENT_FILE	"file"		/* insert this file */
#define ALL_FILES	"all_files"	/* insert all files in directory */
#define INPUT		"input"		/* input from keyboard command */
#define PREFIX		"prefix"	/* insert the prefix (before .) */
#define PWD_PATH	"path"		/* insert the path (ala `pwd`) */
