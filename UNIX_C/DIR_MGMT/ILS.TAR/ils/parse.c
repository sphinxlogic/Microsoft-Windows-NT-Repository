#include	<stdio.h>
#include	<curses.h>
#include	"ils.h"

#define NUETRAL		0	/* states used in parse */
#define IN_OP		1

extern	char	*pnam;			/* program name */
extern	struct	symbol	*symtab[];	/* symbol table */
extern	int	syms;			/* number of symbols on table */

parse_line(line,lnum)
char	line[];
int	lnum;
{
	static	int	state=NUETRAL,o,no;
	char	ops[2][160];

	o=get_opts(ops,line);	/* Get the 2 possible parts */

	if(!o)
		return(0);		/* line was just white space */
	switch(state) {
		case NUETRAL:
			if(o==1) {
				printw("%s: error on line %d of '%s' file\n",pnam,lnum,ILS_FILE);
				refresh();
				return(1);
			}
			no=new_op(ops,ILS_KEY_SEQUENCE);
			state=IN_OP;
			break;
		case IN_OP:
			if(o==2)
				no=new_op(ops,ILS_KEY_SEQUENCE);
			else
				add_op(no,ops);
			break;
		default:
			printw("%s: bad state in parse_line()\n",pnam);
			refresh();
			return(1);
			break;
	}
	return(0);
}

#define ESC		1
#define COLON		2
#define NEWLINE		3
#define SKIP_WHITE	4

get_opts(s,line)
char	s[2][160], line[];
{
	int	i,j,k,l,nonwhite=0,state=0,colons=0;
	char	c;

	l=strlen(line);
	s[0][0]=s[1][0]='\0';

	for(i=j=k=0;i<l;i++) {
		switch(c=line[i]){
			case '\\':
				state=ESC;
				continue;
			case '\n':
				state=NEWLINE;
				break;
			case ':':
				state=COLON;
				colons++;
				if(colons==1)
					break;
				else
					state=0;
			default:
				if(c==' '||c=='\t')
					break;
				nonwhite=1;
				break;
		}
		switch(state) {
			case ESC:
				s[j][k]=c;
				break;
			case COLON:
				s[j][k]='\0';
				j=1;
				k=0;
				state=SKIP_WHITE;
				break;
			case NEWLINE:
				s[j][k]='\0';
				k=0;
				break;
			case SKIP_WHITE:
				if(c==' '||c=='\t')
					break;
				else
					state=0;
			default:
				if(!nonwhite)	/* skip leading white space */
					continue;
				s[j][k++]=c;
				break;
		}
	}
	if(nonwhite)
		return(j+1);	/* j=0 if one field, j=1 if two fields */
	else
		return(0);	/* line was all white space */
}

new_op(s,type)
char	s[2][160];
int	type;
{
	struct	symbol	*t;
	struct	value	*v;

	if(syms==MAX_SYMBOLS) {
		fprintf(stderr,"%s: symbol table size exceeded\n",pnam);
		return;
	}
	t = symtab[syms] = (struct symbol *) malloc(sizeof(struct d_entry));
	if(t == NULL) {
		fprintf(stderr,"%s: out of memory\n",pnam);
		return;
	}
	t->name = (char *)malloc(strlen(s[0])+1);
	strcpy(t->name,s[0]);
	t->type = type;

	if(s[1][0]=='\0')
		t->val = (struct value *)NULL;
	else {
		v = t->val = (struct value *) malloc(sizeof(struct value));
		v->v = (char *)malloc(strlen(s[1])+1);
		strcpy(v->v,s[1]);
		v->next =(struct value *) NULL;
	}

	return(syms++);
}

add_op(op,s)
int	op;
char	s[2][160];
{
	struct	value	*v;

	v = symtab[op]->val;
	
	if(v==(struct value *)NULL) {
		v = symtab[op]->val = (struct value *) malloc(sizeof(struct value));
		v->next =(struct value *) NULL;
	}
	else {
		while(v->next != (struct value *)NULL)
			v = v->next;
		v->next = (struct value *) malloc(sizeof(struct value));
		v->next->next = (struct value *) NULL;
		v = v->next;
	}
	v->v = (char *)malloc(strlen(s[0])+1);
	strcpy(v->v,s[0]);
}

display_symtab()
{
	int	i, over=0;
	struct	value	*v;

	for(i=0;i<syms;i++) {
		clear();
		standout();
		printw("Symbol %d: %s\n",i+1,symtab[i]->name);
		standend();
		v = symtab[i]->val;
		while(v!=NULL && over++ != MAX_SYMBOLS) {
			printw("	%s\n",v->v);
			v = v->next;
		}
		standout();
		printw("Press RETURN next symbol, %c for previous, ESC to exit",
			ILS_LEFT);
		standend();
		refresh();
		switch(getch()&0x7f) {
			case ILS_ENTER:
			case ILS_RETURN:
				break;
			case ILS_LEFT:
				if(i!=0)
					i -= 2;
				else
					i--;
				break;
			case ILS_ESCAPE:
				return;
		}
	}
}
