/**************************************************************************
** main() routine for ils.
**
** ils (c) copyright 1991 by Jack Alexander
**
** NO WARRANTY OF ANY KIND IS ASSOCIATED WITH THIS PROGRAM, NOT EVEN
** FOR FITNESS OF PURPOSE
**
**/
#include	<curses.h>
#include	<stdio.h>
#include	"ils.h"

char	*pnam;
char	*patterns[ILS_MAX_PATS];

main(argc,argv)
int	argc;
char	*argv[];
{
	int	rows=0, cols=0, i, j, pats, modes=0,errs=0,skip,l;
	char	curdir[MAXPATH], *title, c;

	pnam = argv[0];		/* globnal pointer to program name */
	title = (char *) NULL;	/* no title, yet */

	/* extract any modes that may be part of a default dure to filename */
	switch(argv[0][strlen(argv[0])-1]) {
		case 'a':
			modes |= ILS_ALL;
			break;
		case 'f':
			modes |= ILS_F_TYPE;
			break;
		case 'l':
			modes |= ILS_LONG;
			break;
	}
	for(i=1,pats=0;i<argc;i++) {	/* look at all arguments passed */
		skip=0;
		switch(argv[i][0]) {
			case '-':	/* handle the option */
				l = strlen(argv[i]);
				for(j=1;j<l;j++) {
					switch(argv[i][j]) {
						case 'r':
						/* change number of rows */
							j++;
							c = argv[i][j];
							while(c>='0' && c<='9' && j<l) {
								rows *= 10;
								rows += c-'0';
								j++;
								c = argv[i][j];
							}
							j--;
							break;
						case 'c':
						/* change number of columns */
							j++;
							c = argv[i][j];
							while(c>='0' && c<='9' && j<l) {
								cols *= 10;
								cols += c-'0';
								j++;
								c = argv[i][j];
							}
							j--;
							break;
						case 'a':
						/* list ALL mode (. files) */
							modes |= ILS_ALL;
							break;
						case 'F':
						/* show * and / */
							modes |= ILS_F_TYPE;
							break;
						case 'l':
						/* long listing format */
							modes |= ILS_LONG;
							break;
						case 'e':
						/* echo commands */
							modes |= ILS_ECHO_COMS;
							break;
						case 'T':
						/* window to have title */
							if((i+1)>=argc) {
								fprintf(stderr,"%s: -T option must be followed with a title\n",pnam);
								fprintf(stderr,"	example: %s -T \"This is a title\"\n",pnam);
								errs++;
							}
							else {
								title = argv[i+1];
								skip=1;
							}
							break;
					}
				}
				break;
			default:
				patterns[pats++] = argv[i];
		}
		i+=skip;
		skip=0;
	}
	if(errs) {
		fprintf(stderr,"%s: errors in parameters\n",pnam);
		exit(0);
	}
	patterns[pats] = (char *) NULL;

	initscr();		/* init curses */
	scrollok(stdscr,TRUE);
	if(!rows)
		rows = LINES;
	if(!cols)
		cols = COLS;

	if(get_curdir(curdir)) {
		endwin();
		exit(0);
	}
	ils(patterns,curdir,0,0,cols,rows,modes,title);
#ifdef BSD
	clear();
	printw("Leaving %s...\n",pnam);
	refresh();
#endif
	endwin();		/* end curses */
}

get_curdir(path)
char	path[];
{
	FILE	*fp;

	if((fp=popen(PWD,"r"))==NULL) {
		fprintf(stderr,"%s: popen returns error\n",pnam);
		return(1);
	};
	fscanf(fp,"%s",path);
	pclose(fp);
	return(0);
}
