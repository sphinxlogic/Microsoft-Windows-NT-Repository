/* defines for my getstring routine */
/* %W% */

#define INITIAL	0
#define GET_CLEAR	0x03	/* control c */
#define	GET_UP		0x0b	/* control k */
#define GET_DOWN	0x0a	/* control j */
#define GET_LEFT	0x08	/* control h */
#define GET_RIGHT	0x0c	/* control l */
#define GET_TAB		0x09	/* control i */
#define GET_RETURN	0x0d	/* control m */
#define GET_DELETE  	24	/* control x */
#define GET_DELETE2	0x7f	/* delete key on most terminals */
#define GET_ESCAPE	0x1b	/* escape */

/* types of characters that can be specified for getstring input */
#define SHOW		0 /* only show the string, don't ask for input */
#define NUM_ONLY	1 /* only numeric characters 0-9 */
#define LETTER_ONLY	2 /* only letters a-z, A-Z and space (' ') */
#define ALL_ALPHA	3 /* all printable ascii characters are permitted */
