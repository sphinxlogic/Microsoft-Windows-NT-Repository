/* %W% general getstring routine		   		  */
/* author: Jack Alexander - this routine may be freely distibuted */
#include	<curses.h>
#include	"get.h"

get_num(x,y,digits,low,high,number)
int	x,y,digits,low,high,*number;
{
	char	buf[80];
	int	retval;

	buf[0]='\0';
	noecho();
	raw();
	while(1)
		switch(getst(digits,x,y,buf,digits+1,NULL,NUM_ONLY,NULL)) {
			case GET_ESCAPE:
				return(GET_ESCAPE);
			case GET_DOWN:
			case GET_RETURN:
				retval=atoi(buf);
				if(retval < low || retval>high)
					break;
				*number = retval;
				echo();
				noraw();
				return(0);
			default:
				break;
		}
}

/* a few hints...	*/
/* idx = current index into string */
/* cx = current screen x position */
/* cy = current screen y position */
/* ix = initial screen x (upon call, where cursor is requested to be placed) */
/* iy = initial screen y " " " ... */
/* fw = field width */
/* mx = max length of string */
/* sl = string length */
/* valid = string of acceptable characters within the type passed in gettype */
/*         if NULL, then all type of characters passed in gettype are allowed */

int	idx, cx, cy, ix, iy, fw, mx, sl, rcode;

getst(len,sx,sy,str,fl,retlen,gettype,valid)
int	len, sx, sy, fl, *retlen, gettype;
char	*str, *valid;
{
	int	c;


	rcode = INITIAL;
	idx=0;
	cx=ix=sx;
	cy=iy=sy;
	mx = len;
	fw = fl;
	str[mx]='\0';
	sl=strlen(str);
	if(sl!=0) {
		idx =sl;		/* place cursor at string's end */
		cx +=sl;
	}
#ifdef undef
	init();
#endif
	while(1) {
		if(gettype==SHOW) {	/* want only to display the string */
			drawstr(str,0);	/* draw the string */
#ifdef undef
			de_init();
#endif
			return;
		}
		drawstr(str,1);	/* draw the string */
		c=getch()&0x7f;
		switch(c) {
			case GET_CLEAR:
				clearall(str);
				break;
			case GET_ESCAPE:
				rcode=GET_ESCAPE;
				break;
			case GET_UP:
				rcode=dec_y_pos();
				break;
			case GET_DOWN:
				rcode=inc_y_pos();
				break;
			case GET_LEFT:
				rcode=dec_x_pos();
				break;
			case GET_RIGHT:
				rcode=inc_x_pos(1);
				break;
			case GET_DELETE:
			case GET_DELETE2:
				remove_char(str);
				break;
			case GET_TAB:
			case GET_RETURN:
				rcode = GET_RETURN;
				break;
			default:
				switch(gettype) {
					case NUM_ONLY: /* numbers only (0-9) */
						if(c>='0' && c<='9')
							if(in(c,valid))
								add_char(str,c);
						break;
					case LETTER_ONLY:
					/* letters a-z and A-Z, and ' ' only */
						if(c==' ' || (c>='a' && c<='z') || (c>='A' && c<='Z'))
							if(in(c,valid))
								add_char(str,c);
						break;
					case ALL_ALPHA:/* any printable chars */
						if(c>=' ' && c<=0x7f)
							if(in(c,valid))
								add_char(str,c);
						break;
					default:
						if(c>=' ' && c<=0x7f)
							add_char(str,c);
						break;
				}
				break;
		}
		if(rcode != INITIAL) {
#ifdef undef
			de_init();
#endif
			if(retlen != NULL)
				*retlen = sl;
			return(rcode);
		}
	}
}

dec_y_pos()
{
	if(!idx)
		return(GET_UP);
	if(iy >= cy) {
		idx = 0;
		cx = ix;
		return(INITIAL);
	}
	idx -= fw;
	cy--;
	return(INITIAL);
}

inc_y_pos()
{
	if(idx>=mx-1 || idx==sl)
		return(GET_DOWN);
	if(idx+fw >=  mx) {
		cx += mx-idx - (mx-sl);
		idx += mx-idx - (mx-sl);
#ifdef undef
		cx += (mx - idx -fw);
		idx += (mx - idx - fw);
#endif
		return(INITIAL);
	}
	if(idx+fw > sl) {
		cx += sl - idx;
		idx += sl - idx;
		return(INITIAL);
	}
	idx += fw;
	cy++;
	return(INITIAL);
}

inc_x_pos(flag)
int	flag;
{
	if(flag && idx==sl)
		return(GET_RIGHT);
	if(idx == mx)
		return(GET_RIGHT);
	cx++;
	idx++;
	if(cx >= (ix+fw)) {
		cx = ix;
		cy++;
	}
	return(INITIAL);
}

dec_x_pos()
{
	if(idx==0)
		return(GET_LEFT);
	idx--;
	cx--;
	if(cx < ix) {
		cx = fw+ix-1;
		cy--;
	}
	return(INITIAL);
}

add_char(str, c)
char	*str;
char	c;
{
	register	int	i;

	if(inc_x_pos(0)!=INITIAL)
		return;
	for(i=mx-1;i>=idx;i--)
		str[i]=str[i-1];
	str[idx - 1] = c;
	if(sl!=mx)
		sl++;
}

remove_char(str)
char	*str;
{
	register int i;

	if(idx >= sl) {		/* remove char behind cursor */
		if(dec_x_pos()!=INITIAL)
			return;
		str[sl-1]='\0';
	}
	else 
		for(i=idx;i<mx;i++)
			str[i]=str[i+1];
	sl--;
}

drawstr(str,refr)
char	str[];
int	refr;
{
	int	i, j, s, yo;

	s=sl;
	move(iy,ix);
	for(i=0,yo=1;i<mx;) {
		if(i>=s) {
			addch('.');
			i++;
		}
		else if((s-i) < fw) {
			printw("%s",&str[i]);
			i += s-i;
		}
		else {
			for(j=0;j<fw;j++)
				addch(str[i++]);
		}
		if((i % fw)==0) {
			move(iy + yo,ix);
			yo++;
		}
	}
	move(cy,cx);
	if(refr)
		refresh();
}

init()
{
	noecho();
	raw();
}

de_init()
{
	noraw();
	echo();
}

in(ch,allow)
char	ch, allow[];
{
	register int	i;

	if(allow == NULL)
		return(1);
	for(i=0;i<strlen(allow);i++)
		if(ch==allow[i])
			return(1);
	return(0);
}

clearall(str)
char	str[];
{
	sl=idx=0;
	cx=ix;
	cy=iy;
	str[0]='\0';
}
