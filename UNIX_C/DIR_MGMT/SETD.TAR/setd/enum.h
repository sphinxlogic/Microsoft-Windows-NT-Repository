/*
 *  enum.h
 *
 *  Enumerated Types File for both Mark and Set Directory
 *
 *  Sunil William Savkar
 *  sunil@hal.com
 *  Copyright (c) 1991
 *  All Rights Reserved
 *
 *  DISCLOSURE
 *
 *  This source may be modified or copied freely.  The intent
 *  is the free distribution of a useful utility used for moving
 *  between directories.  Any modifications and additions, along
 *  with bug reports should be sent to the author, so all might
 *  benefit!
 *
 *  DESCRIPTION
 * 
 *  This module contains the enumerated type definitions for
 *  the command line arguments.  Inclusive are a set of enumerations
 *  for such commands as the version, removal, inclusion, etcetera
 *  of marks and of set directory commands.  The same file is included
 *  by both setd and mark.
 */

/*
 *  typedef enum T_COMM
 *
 *  The enumerated command arguments for mark.
 */

#ifdef MARK
typedef enum T_COMM {

  K_VERSION,
  K_HELP,
  K_MARK_DIR,
  K_REMOVE_MARK,
  K_REFRESH_MARKS,
  K_LIST_MARKS,
  K_RESET_MARKS,
  K_NULL
} T_COMM;
#endif

/*
 *  typedef enum T_COMM
 *
 *  The enumerated command arguments for setd.
 */

#ifdef SETD
typedef enum T_COMM {

  K_SETD_DIR,
  K_MAX_QUEUE,
  K_SETD_HOME,
  K_LIST_QUEUE,
  K_POS_QUEUE,
  K_BACK_QUEUE,
  K_VERSION,
  K_HELP,
  K_NULL
} T_COMM;
#endif

