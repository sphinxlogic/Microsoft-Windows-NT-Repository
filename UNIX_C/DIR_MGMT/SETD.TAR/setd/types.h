/*
 *  types.h
 *
 *  Types File for both Mark and Set Directory
 *
 *  Sunil William Savkar
 *  sunil@hal.com
 *  Copyright (c) 1991
 *  All Rights Reserved
 *
 *  DISCLOSURE
 *
 *  This source may be modified or copied freely.  The intent
 *  is the free distribution of a useful utility used for moving
 *  between directories.  Any modifications and additions, along
 *  with bug reports should be sent to the author, so all might
 *  benefit!
 *
 *  DESCRIPTION
 * 
 *  This module contains all typed structures used by both
 *  setd and mark for changing directories or adding and/or
 *  deleting marks.
 */

/*
 *  typedef int boolean
 *
 *  Type booleans to just be integers (TRUE or FALSE).
 */

typedef int boolean;

/*
 *  typedef struct COMMAND_NODE
 *
 *  Structure used to store a string command and its enumerated
 *  equivalent.  The enumerated equivalents can be found in enum.h
 */

typedef struct COMMAND_NODE {

  T_COMM type;
  char   *text;
} COMMAND_NODE;

/*
 *  typedef struct LIST_NODE
 *
 *  This structure stores the list of marks, with the original
 *  mark, the path expansion for the mark, and a pointer to the
 *  next mark.
 */

typedef struct LIST_NODE {

  int unset_flag;
  char *mark;
  char *path;
  struct LIST_NODE *next;
} LIST_NODE;




