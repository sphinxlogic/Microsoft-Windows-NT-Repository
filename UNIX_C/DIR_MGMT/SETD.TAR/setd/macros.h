/*
 *  macros.h
 *
 *  Macros File for both Mark and Set Directory
 *
 *  Sunil William Savkar
 *  sunil@hal.com
 *  Copyright (c) 1991
 *  All Rights Reserved
 *
 *  DISCLOSURE
 *
 *  This source may be modified or copied freely.  The intent
 *  is the free distribution of a useful utility used for moving
 *  between directories.  Any modifications and additions, along
 *  with bug reports should be sent to the author, so all might
 *  benefit!
 *
 *  DESCRIPTION
 * 
 *  This module contains all typed structures used by both
 *  setd and mark for changing directories or adding and/or
 *  deleting marks.
 */

#define MAX_LINE 255
#define FALSE 0
#define TRUE 1
#define STREQU(a, b) (strcmp( a, b) == 0)
