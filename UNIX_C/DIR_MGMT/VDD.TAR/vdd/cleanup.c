/*
 * vdd - visual directory display (C) 1988 (pulsar@lsrhs) Jim King
 *
 * cleanup.c - contains the cleanup subroutine cleanup()
 *             contains the cleanup routine without clear cleanupwoc()
 */

#include "vars.h"

cleanup(x)
int	x;
{
	clear();
	refresh();
	echo();
	nocrmode();
	endwin();
	fflush(stdout);
	exit(x);
}

cleanupwoc(x)
int	x;
{
	refresh();
	echo();
	nocrmode();
	endwin();
	fflush(stdout);
	exit(x);
}
