/*
 * vdd - visual directory display (C) 1988 (pulsar@lsrhs) Jim King
 *
 * stopme.c - contains stopme for ^Z
 */

#include "vars.h"

stopme()
{
	char	*sh;
	move(24, 0);
	refresh();
	endwin();
	fflush(stdout);
	sh = (char *)getenv("SHELL");
	if (sh == NULL)
		sh = "/bin/sh";
	system(sh);
	signal(SIGTSTP, stopme);
	crmode();
	noecho();
	clear();
	redraw();
}
