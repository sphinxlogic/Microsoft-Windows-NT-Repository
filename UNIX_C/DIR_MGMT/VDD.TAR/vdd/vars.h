/*
 * vdd - visual diectory display (C) 1988 pulsar@lsrhs
 *
 * vars.h - general include file for all of vdd
 */

/* Include Files */

#include <sys/types.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <stdio.h>
#include <errno.h>
#include <stdio.h>
#include <signal.h>
#include <curses.h>

/* Some defines */

#define NO		0 /* Used mostly in posy() */
#define YES		1 /* Ditto */

#define MAXDSIZE	10000	/* Max number of files that can be read
				   before munging */ /* Tunable */

#define VERSION		1.0 /* version # */

/* Windows */

WINDOW	*err, *hlp, *fils, *fst, *dnm, *w;

/* Structures */

/* structure listing is where all directory listings are held */
struct listing {
	char	name[50]; /* Name of file */
	int	dir; /* YES or NO */
	struct	stat	f; /* contains the stat(name) information */
};

extern struct direct	*readdir();

struct listing	l[MAXDSIZE]; /* Make sure we have enough room */
struct direct	*ent; /* Used when reading in directory lists */

/* Global definitions */

char	str[80],	/* Randomly used string */
	dname[255],	/* Original (argv[1]) Dirname */
	c;		/* Used with getchar() */

int	i,
	j,		/* for loop ints */
	total,		/* used in readin() to read in dirs */
	level,		/* used in disp() for screen display */
	xpos,
	ypos,
	lastx,
	lasty;		/* screen display info */


DIR	*dir;		/* Used when reading dname */

