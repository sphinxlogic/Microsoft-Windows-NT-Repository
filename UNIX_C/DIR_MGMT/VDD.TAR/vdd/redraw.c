/*
 * vdd - visual directory display (C) 1988 (pulsar@lsrhs) Jim King
 *
 * redraw.c - redraw utility
 */

#include "vars.h"

redraw()
{
	clear();
	wclear(err);
	wclear(dnm);
	wclear(fils);

	wmove(dnm, 0, 0);
	wprintw(dnm, dname);

	wmove(hlp, 0, 0);
	wprintw(hlp, "UP ARROW- Up");
	wmove(hlp, 1, 0);
	wprintw(hlp, "DN ARROW- Down");
	wmove(hlp, 2, 0);
	wprintw(hlp, "ENTER   - Status");
	wmove(hlp, 3, 0);
	wprintw(hlp, "q, ^C   - Quit");
	wmove(hlp, 4, 0);
	wprintw(hlp, "^Z      - Suspend");
	wmove(hlp, 5, 0);
	wprintw(hlp, "d       - Dir Dive");
	wmove(hlp, 6, 0);
	wprintw(hlp, "s       - Dir Search");
	wmove(hlp, 7, 0);
	wprintw(hlp, ">       - + page");
	wmove(hlp, 8, 0);
	wprintw(hlp, "<       - - page");
	wmove(hlp, 9, 0);
	wprintw(hlp, "VDD V%1.1f (C) 1988 Oct", VERSION);

	touchwin(hlp);
	touchwin(fst);
	refresh();
	wrefresh(err);
	wrefresh(hlp);
	wrefresh(dnm);
	dlev();
}
