/*
 * vdd - visual diectory display (C) 1988 (pulsar@lsrhs) Jim King
 *
 * req.c - contains program to tell you how much memory
 *	   you need to make use of the full capability
 *	   of this program.
 */

#include "vars.h"

main()
{
	int	kb;

	kb = ((sizeof(l) + 1023) / 1024) + 112;
	printf("In order to use the visual directory display utility at present,\n");
	printf("you will need %d bytes of memory.  This amounts to app. %d KB of memory.\n", sizeof(l), (sizeof(l)+1023)/1024);
	printf("This means you will need a good %d KB of memory to run safely w/o munging.\n", kb);
	if (kb / 1024)
		printf("Another perspective: %3d MB\n", kb / 1024);
	printf("If you would like to cut this down, change the MAXDSIZE definition\n");
	printf("in vars.h.  Then recompile and run this program again.\n");
}
