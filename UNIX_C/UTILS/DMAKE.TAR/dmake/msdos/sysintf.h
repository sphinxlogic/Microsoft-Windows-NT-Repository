/*
** assorted bits of system interface
*/
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>

#define STAT stat
#define VOID_LCACHE(l,m)
extern char * tempnam();
extern char * getcwd();

/*
** standard C items
*/

/*
** DOS interface standard items
*/
#define	chdir(p) _chdir(p)

/*
** make parameters
*/
#define	MAX_PATH_LEN	64

