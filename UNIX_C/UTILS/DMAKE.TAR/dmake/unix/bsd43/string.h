/*
** BSD does this wrong
*/
#include <strings.h>

#define	strchr(str,c)	index(str,c)
#define	strrchr(str,c)	rindex(str,c)

#include "stdmacs.h"
extern	char*	strpbrk ANSI((char* src, char* any));

