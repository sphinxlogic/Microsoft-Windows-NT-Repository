/*
** assorted bits of system interface, for common routines inside dmake.
** System specific code can be found in the config.h files for each
** of the system specifications.
*/
#include <sys/stat.h>
#include <signal.h>

#define STAT stat
#define VOID_LCACHE(l,m) (void) void_lcache(l,m)

/*
** standard C items
*/
#include "stdmacs.h"

/*
** DOS interface standard items
*/
#define	getswitchar()	'-'

/*
** make parameters
*/
#define	MAX_PATH_LEN	1024
