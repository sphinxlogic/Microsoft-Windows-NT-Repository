#define PORTAR 1
#include "/usr/include/ar.h"
