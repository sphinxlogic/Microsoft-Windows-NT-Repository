/*
** Berkeley get this wrong!
*/
#ifndef	TIME_h
#define	TIME_h

typedef	long	time_t;	/* this is the thing we use */

#endif	TIME_h

