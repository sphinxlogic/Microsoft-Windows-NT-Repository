/* dmake version number.  */

#define VERSION "3.60"
