/* RCS      -- $Header: /u2/dvadura/src/generic/dmake/src/RCS/parse.c,v 1.1 90/10/06 12:04:01 dvadura Exp $
-- SYNOPSIS -- parse the input, and perform semantic analysis
-- 
-- DESCRIPTION
-- 	This file contains the routines that parse the input makefile and
--	call the appropriate routines to perform the semantic analysis and
--	build the internal dag.
--
-- AUTHOR
--      Dennis Vadura, dvadura@watdragon.uwaterloo.ca
--      CS DEPT, University of Waterloo, Waterloo, Ont., Canada
--
-- COPYRIGHT
--      Copyright (c) 1990 by Dennis Vadura.  All rights reserved.
-- 
--      This program is free software; you can redistribute it and/or
--      modify it under the terms of the GNU General Public License
--      (version 1), as published by the Free Software Foundation, and
--      found in the file 'LICENSE' included with this distribution.
-- 
--      This program is distributed in the hope that it will be useful,
--      but WITHOUT ANY WARRANTY; without even the implied warrant of
--      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--      GNU General Public License for more details.
-- 
--      You should have received a copy of the GNU General Public License
--      along with this program;  if not, write to the Free Software
--      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
--
-- LOG
--     $Log:	parse.c,v $
 * Revision 1.1  90/10/06  12:04:01  dvadura
 * dmake Release, Version 3.6
 * 
*/

#include <ctype.h>
#include "extern.h"
#include "alloc.h"
#include "db.h"


void
Parse( fil )/*
==============  Parse the makefile input */
FILE *fil;
{
   int	state = NORMAL_SCAN;           /* indicates current parser state */
   int  group = FALSE;                 /* true if scanning a group rcpe  */
   int  rule  = FALSE;                 /* have seen a recipe line        */
   char *p;			       /* termporary pointer into Buffer */

   DB_ENTER( "Parse" );

   while( TRUE ) {
      if( Get_line( Buffer, fil ) ) {
	 if( fil != NIL( FILE ) )               /* end of parsable input */
	    Closefile();

	 Bind_rules_to_targets( F_DEFAULT );
         if( group )  Fatal( "Incomplete rule recipe group detected" );

	 DB_VOID_RETURN;
      }
      else
         switch( state ) {
	    case RULE_SCAN:

	       /* Check for the `[' that starts off a group rule definition.  It
	        * must appear as the first non-white space
		* character in the line. */

	       p = _strspn( Buffer, " \t" );
               if( Set_group_attributes( p ) ) {
                  if( rule  && group )
                     Fatal( "Cannot mix single and group recipe lines" );
                  else
                     group = TRUE;

                  rule = TRUE;

                  break;                     /* ignore the group start  */
               }

               if( group ) {
                  if( *p != ']' ) {
                     Add_recipe_to_list( Buffer, TRUE, TRUE );
                     rule = TRUE;
                  }
                  else
                     state = NORMAL_SCAN;
               }
               else {
                  if( *Buffer == '\t' ) {
                     Add_recipe_to_list( Buffer, FALSE, FALSE );
                     rule = TRUE;
                  }
                  else if( *p == ']' )
                     Fatal( "Found unmatched ']'" );
                  else if( *Buffer )
		     state = NORMAL_SCAN;
               }
 
               if( state == RULE_SCAN ) break;     /* ie. keep going    */
               
	       Bind_rules_to_targets( (group) ? F_GROUP: F_DEFAULT );

               rule = FALSE;
               if( group ) {
                  group = FALSE;
                  break;
               }
	       /*FALLTRHOUGH*/

               /* In this case we broke out of the rule scan because we do not
                * have a recipe line that begins with a <TAB>, so lets
		* try to scan the thing as a macro or rule definition. */
               

	    case NORMAL_SCAN:
	       if( !*Buffer ) continue;         /* we have null input line */

	       /* STUPID AUGMAKE uses "include" at the start of a line as
	        * a signal to include a new file, so let's look for it.
		* if we see it replace it by .INCLUDE: and stick this back
		* into the buffer. */
	       if( !strncmp( "include", Buffer, 7 ) &&
		   (Buffer[7] == ' ' || Buffer[7] == '\t') )
	       {
		  char *tmp;

		  tmp = _strjoin( ".INCLUDE:", Buffer+7, -1, FALSE );
		  strcpy( Buffer, tmp );
		  FREE( tmp );
	       }

               /* look for a macro definition, they all contain an = sign
	        * if we fail to recognize it as a legal macro op then try to
		* parse the same line as a rule definition, it's one or the
		* other */
		
	       if( Parse_macro(Buffer, M_DEFAULT) ) break;/* it's a macro def */
	       if( Parse_rule_def( &state ) ) 	    break;/* it's a rule def  */

	       /* if just blank line then ignore it */
	       if( *_strspn( Buffer, " \t" ) == '\0' ) break;
	       
	       /* otherwise assume it was a line of unrecognized input, or a
	        * recipe line out of place so print a message */
		
	       Fatal( "Expecting macro or rule defn, found neither" );
	       break;

	    default:
	       Fatal( "Internal -- UNKNOWN Parser state %d", state );
	 }
   }
}

