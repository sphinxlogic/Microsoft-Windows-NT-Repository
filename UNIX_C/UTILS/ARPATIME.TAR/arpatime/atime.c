#include <stdio.h>

main()
{

printf("%s\n",dtimenow());

}
