sub rcsargs {
    local($result) = '';
    local($_);
    while ($_ = shift(@_)) {
	if ($_ =~ /^-/) {
	    $result .= $_ . ' ';
	}
	elsif ($#_ >= 0 && do equiv($_,$_[0])) {
	    $result .= $_ . ' ' . $_[0] . ' ';
	    shift(@_);
	}
	else {
	    $result .= $_ . ' ' . do other($_) . ' ';
	}
    }
    $result;
}

sub equiv {
    local($s1, $s2) = @_;
    $s1 =~ s|.*/||;
    $s2 =~ s|.*/||;
    if ($s1 eq $s2) {
	0;
    }
    elsif ($s1 =~ s/$RCSEXT$// || $s2 =~ s/$RCSEXT$//) {
	$s1 eq $s2;
    }
    else {
	0;
    }
}

sub other {
    local($s1) = @_;
    ($dir,$file) = ('./',$s1) unless local($dir,$file) = ($s1 =~ m|(.*/)(.*)|);
    local($wasrcs) = ($file =~ s/$RCSEXT$//);
    if ($wasrcs) {
	`mkdir $dir` unless -d $dir;
	$dir =~ s|RCS/||;
    }
    else {
	$dir .= 'RCS/';
	`mkdir $dir` unless -d $dir;
	$file .= $RCSEXT;
    }
    "$dir$file";
}

