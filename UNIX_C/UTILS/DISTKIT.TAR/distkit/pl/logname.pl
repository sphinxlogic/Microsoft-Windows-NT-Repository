sub getlogname {
    local($logname) = $ENV{'USER'};
    $logname = $ENV{'LOGNAME'} unless $logname;
    chop($logname = `who am i`) unless $logname;
    $logname =~ s/\s.*//;
    $logname =~ s/.*!//;
    $logname;
}

