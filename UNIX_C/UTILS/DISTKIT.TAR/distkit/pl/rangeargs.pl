sub rangeargs {
    local($result) = '';
    local($min,$max,$_);
    open(PL,"patchlevel.h") || die "Can't open patchlevel.h\n";
    while (<PL>) {
        $maxspec = $1 if /^#define\s+PATCHLEVEL\s+(\d+)/;
    }
    close PL;
    die "Malformed patchlevel.h file.\n" if $maxspec eq '';
    while ($#_ >= 0) {
	$_ = shift(@_);
	while (/^\s*\d/) {
	    s/^\s*(\d+)//;
	    $min = $1;
	    if (s/^,//) {
		$max = $min;
	    }
	    elsif (s/^-(\d*)//) {
		$max = $1;
		if ($max == 0 && $maxspec) {
		    $max = $maxspec;
		}
		s/^[^,],?//;
	    }
	    else {
		$max = $min;
	    }
	    for ($i = $min; $i <= $max; ++$i) {
		$result .= $i . ' ';
	    }
	}
    }
    $result;
}
