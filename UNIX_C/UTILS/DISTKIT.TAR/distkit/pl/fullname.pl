sub getfullname {
    local($logname) = @_;
    local($foo,$bar);
    if ($ENV{'NAME'}) {
	$ENV{'NAME'};
    }
    else {
	open(PASSWD,'/etc/passwd') || die "Can't open /etc/passwd";
	while (<PASSWD>) {
	    /(\w+):/;
	    last if $1 eq $logname;
	}
	close PASSWD;
	local($login,$passwd,$uid,$gid,$gcos,$home,$shell) = split(/:/);
	if (-f "$home/.fullname") {
	    open(FN,"$home/.fullname");
	    chop($foo = <FN>);
	    close FN;
	    $foo;
	}
	elsif ($nametype eq 'bsd') {
	    $gcos =~ s/[,;].*//;
	    if ($gcos =~ /&/) {		# oh crud
		($foo,$bar) = ($logname =~ /(.)(.*)/);
		$foo =~ y/a-z/A-Z/;
		$gcos =~ s/&/$foo$bar/;
	    }
	    $gcos;
	}
	else {
	    $gcos =~ s/[(].*//;
	    $gcos =~ s/.*-//;
	    $gcos;
	}
    }
}
