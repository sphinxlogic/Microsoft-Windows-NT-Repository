sub rcscomment {
    local($file) = @_;
    local($comment) = '';
    open(FILE,$file);
    while (<FILE>) {
	if (/^(.*)\$Log[:\$]/) {		# they know better than us (hopefully)
	    $comment = $1;
	    last;
	}
    }
    close FILE;
    unless ($comment) {
	if ($file =~ /\.SH$|[Mm]akefile/) {
	    $comment = '# ';
	}
	elsif ($file =~ /\.U$/) {
	    $comment = '?RCS: ';
	}
	elsif ($file =~ /\.man$/) {
	    $comment = "''' ";
	}
    }
    $comment;
}

