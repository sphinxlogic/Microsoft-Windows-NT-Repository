
/*
 * rev 10-2-86 Added command save on error, !, ?
 * rev 7-28-85 select array, command prompt, -f flag
 * rev 10-8-80 CAF cbreak & backup
 * rev 10-4-80 CAF for stdio
 *  Based on the "pic" program Copyright (c) 1976 Thomas S. Duff
 */

/*% cc -O -K -DDUP2 -o choos % -lx
 */

/*#define DUP2	/* use the dup2 call */

#include <stdio.h>
#include <sgtty.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>

struct sgttyb oldtty, newtty;
int Filesonly = 0;
int Nathan = 0;
int Selcount = 0;
char Tempname[] = "/tmp/choosXXXXXX";
char Command[256];

onintr()
{
	ioctl(0,TIOCSETP,&oldtty);
	exit(1);
}
main(argc, argv)
char *argv[];
{
	register i, c;
	register char *s;
	register FILE *fout;
	register char *select;
	char *calloc();
	struct stat e;
	char *shell = "/bin/sh";
	char *getenv();

	if ((select = calloc(argc+1, 1)) == (char *) 0) {
		fprintf(stderr, "choos: can't alloc memory!");
		exit(1);
	}
	if ( !strcmp(argv[1], "-f")) {
		--argc; ++argv; ++Filesonly;
	}
	if (argc < 2) {
		prompt(); exit(1);
	}
	if ((s = getenv("SHELL")) && *s)
		shell = s;

	signal(SIGINT, onintr);
	signal(SIGQUIT, onintr);
	signal(SIGTERM, onintr);
	signal(SIGPIPE, onintr);
	ioctl(0,TIOCGETP,&oldtty);
	newtty = oldtty;
	newtty.sg_flags |= CBREAK;
	ioctl(0,TIOCSETP,&newtty);


	fprintf(stderr, "Choos called with %d arguments\n", argc -1);
	for (i=1;;) {
		s = argv[i];
		fprintf(stderr,"%3d %14s %c? ", i, s, select[i]?'*':' ');
		if(Nathan)
			putc(Nathan,stderr);
		else
			c=getchar();


