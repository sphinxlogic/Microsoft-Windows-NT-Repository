/* onlay.c */
/**********************************************************************
*    File Name     : onlay.c
*    Function      : draw initial pac screen
*    Author        : Istvan Mohos, 1987
***********************************************************************/

#define SO standout()
#define SE standend()
#define uw 48
#define re 78
#define se 58
#define sp " "

#include "defs.h"

onlay()
{
    register int i = TOP + 1, j = LBOUND;
    static char *fid = "onlay";

    _TR
 mvaddstr(UTOP,     ATOIX, "^A  asc");
 mvaddstr(UTOP + 1, ATOIX, "^D  dec");
 mvaddstr(UTOP + 2, ATOIX, "^O  oct");
 mvaddstr(UTOP + 3, ATOIX, "^X  hex");

 SO;
 mvaddstr(TOP, j, "  ");
 mvaddstr(TOP, ULEFT, Titlq[0]);
 SE;SO;
 mvaddstr(i,j,sp);mvaddstr(i,uw,sp);mvaddstr(i,se,sp);mvaddstr(i++,re,sp);SE;SO;
 mvaddstr(i,j,sp);mvaddstr(i,uw,sp);mvaddstr(i,se,sp);mvaddstr(i++,re,sp);SE;SO;
 mvaddstr(i,j,sp);mvaddstr(i,uw,sp);mvaddstr(i,se,sp);mvaddstr(i++,re,sp);SE;SO;
 mvaddstr(i,j,sp);mvaddstr(i,uw,sp);mvaddstr(i,se,sp);mvaddstr(i++,re,sp);SE;SO;
 mvaddstr(i,j, "                                               LOAN      ");
        mvaddstr(i,se,sp);mvaddstr(i++,re,sp);SE;SO;

    SO; mvaddstr(STATY - 1, STATMSG - 1, "    GLOBALS     "); SE;

    i = STACKTOP;
    SO;
    mvaddstr(i,j,"h");SE;addstr("   0");SO;mvaddstr(i,40,"amt");
        mvaddstr(i,se,sp);mvaddstr(i++,re,sp);
    mvaddstr(i,j,"i");SE;addstr("   0");SO;mvaddstr(i,40," % ");
        mvaddstr(i,se,sp);mvaddstr(i++,re,sp);
    mvaddstr(i,j,"j");SE;addstr("   0");SO;mvaddstr(i,40,"yrs");
        mvaddstr(i,se,sp);mvaddstr(i++,re,sp);
    mvaddstr(i,j,"k");SE;addstr("   0");SO;mvaddstr(i,40,"pay");
        mvaddstr(i,se,sp);mvaddstr(i++,re,sp);
    mvaddstr(i,j,"l");SE;addstr("   0");SO;mvaddstr(i,40,"^B ");
        mvaddstr(i,se,sp);mvaddstr(i++,re,sp);
    mvaddstr(i,j,"m");SE;addstr("   0");SO;mvaddstr(i,40,"   ");
        mvaddstr(i,se,sp);mvaddstr(i++,re,sp);
    mvaddstr(i,j,"n");SE;addstr("   0");SO;mvaddstr(i,40,"[le");
        mvaddstr(i,se,sp);mvaddstr(i++,re,sp);
    mvaddstr(i,j,"o");SE;addstr("   0");SO;mvaddstr(i,40,"]ri");
        mvaddstr(i,se,sp);mvaddstr(i++,re,sp);
    mvaddstr(i,j,"p");SE;addstr("   0");SO;mvaddstr(i,40,"{up");
        mvaddstr(i,se,sp);mvaddstr(i++,re,sp);
    mvaddstr(i,j,"q");SE;addstr("   0");SO;mvaddstr(i,40,"}dn");
        mvaddstr(i,se,sp);mvaddstr(i++,re,sp);
    mvaddstr(i,j,"r");SE;addstr("   0");SO;mvaddstr(i,40,"|cr");
        mvaddstr(i,se,sp);mvaddstr(i++,re,sp);
    mvaddstr(i,j,"s");SE;addstr("   0");SO;mvaddstr(i,40,"^Cl");
        mvaddstr(i,se,sp);mvaddstr(i++,re,sp);
    mvaddstr(i,j,"t");SE;addstr("   0");SO;mvaddstr(i,40," BS");
        mvaddstr(i,se,sp);mvaddstr(i++,re,sp);
    mvaddstr(i,j,"u");SE;addstr("   0");SO;mvaddstr(i,40,"DEL");
        mvaddstr(i,se,sp);mvaddstr(i++,re,sp);
    mvaddstr(i,j,"v");SE;addstr("   0");SO;mvaddstr(i,40,">im");
        mvaddstr(i,se,sp);mvaddstr(i++,re,sp);
    mvaddstr(i,j,"w");SE;addstr("   0");SO;mvaddstr(i,40,"<ei");
        mvaddstr(i,se,sp);mvaddstr(i++,re,sp);
    mvaddstr(i, j, "  ");
    mvaddstr(i, ULEFT, Basq[0]); SE;
TR_
}

update()
{
    register int ri;
    int pyp, pxp;
    static char *fid = "update";

    _TR
    CYX;
    for (ri = TREQ; --ri >= 0;) {
        if (Titlq[ri] != ZERO)  {
            standout();
            mvaddstr(TOP, ULEFT, Titlq[ri]);
            break;
        }
    }

    for (ri = BREQ; --ri >= 0;) {
        if (Basq[ri] != ZERO)  {
            mvaddstr(BOT, ULEFT, Basq[ri]);
            standend();
            break;
        }
    }

    PYX;
TR_
}
