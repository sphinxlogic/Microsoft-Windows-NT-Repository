/* atoi.c */
/**********************************************************************
*    File Name     : atoi.c
*    Function      : ascii/decimal/octal/hex converter of pac
*    Author        : Istvan Mohos, 1987
***********************************************************************/

#include "defs.h"
#define ATOIMAP
#include "maps.h"
#undef ATOIMAP

byte_conv(from)
int from;
{
    char c, bbuf[10], *bb;
    int pyp, pxp;
    int ri, ffd, value;
    static char *fid = "byte_conv";

    _TR
    CYX;
    switch(from) {
        case 4:
            mvaddstr(UTOP + 1, ATOIX, "ENTER 3");
            mvaddstr(UTOP + 2, ATOIX, "DECIMAL");
            mvaddstr(UTOP + 3, ATOIX, "DIGITS ");
            value = -1;
            while(value == -1) {
                mvaddstr(UTOP, ATOIX, "dec    ");

                ledit(bbuf, a_ed_map, UTOP, ATOIX+4, ATOIX+6, 0, 1, 1);
                if (!*bbuf)
                    continue;
                value = 0;
                upcase(bbuf);
                bb = bbuf;
                for (ri = strlen(bbuf); --ri >= 0; bb++) {
                    value *= 10;
                    value += (*bb > 57) ? (*bb - 55) : (*bb - 48);
                }
                if (value < 0 || value > 127) {
                    value = -1;
                    continue;
                }
            }
            move(UTOP, ATOIX);
            printw("dec %3d", value);

            move(UTOP + 1, ATOIX);
            if (value == 127)
                printw("asc DEL");
            else if (value < 33)
                printw("%s",lotab[value]);
            else
                printw("asc   %c",value);

            move(UTOP + 2, ATOIX);
            printw("oct %.3o", value);

            move(UTOP + 3, ATOIX);
            printw("hex  %.2x", value);
            break;
        case 1:
        default:
            ri = 0;
#ifdef sun
            signal(SIGHUP,  Save_sig[ri++]);
            signal(SIGINT,  Save_sig[ri++]);
            signal(SIGQUIT, Save_sig[ri++]);
            signal(SIGTERM, Save_sig[ri++]);
#else
            Save_sig[ri++] = signal(SIGHUP,  SIG_IGN);
            Save_sig[ri++] = signal(SIGINT,  SIG_IGN);
            Save_sig[ri++] = signal(SIGQUIT, SIG_IGN);
            Save_sig[ri++] = signal(SIGTERM, SIG_IGN);
#endif /* sun */

#ifndef REALUNIX
#ifdef sun
            signal(SIGTSTP, Save_sig[ri++]);
            signal(SIGCONT, Save_sig[ri++]);
#else
            Save_sig[ri++] = signal(SIGTSTP, SIG_IGN);
            Save_sig[ri++] = signal(SIGCONT, SIG_IGN);
#endif /* sun */
#endif /* !REALUNIX */

            mvaddstr(UTOP + 1, ATOIX, "    HIT");
            mvaddstr(UTOP + 2, ATOIX, "    ANY");
            mvaddstr(UTOP + 3, ATOIX, "    KEY");
            mvaddstr(UTOP, ATOIX, "asc    ");
            move(UTOP, ATOIX + 6);
            pfresh();
            ffd = dup(0);
            close(0);
            read(ffd, &c, 1);
            dup(ffd);
            close(ffd);
            value = c & 127;

            move(UTOP, ATOIX);
            if (value == 127)
                printw("asc DEL");
            else if (value < 33)
                printw("%s",lotab[value]);
            else
                printw("asc   %c",value);
            move(UTOP + 1, ATOIX);
            printw("dec %3d", value);
            move(UTOP + 2, ATOIX);
            printw("oct %.3o", value);
            move(UTOP + 3, ATOIX);
            printw("hex  %.2x", value);

            ri = 0;
            signal(SIGHUP,  Save_sig[ri++]);
            signal(SIGINT,  Save_sig[ri++]);
            signal(SIGQUIT, Save_sig[ri++]);
            signal(SIGTERM, Save_sig[ri++]);

#ifndef REALUNIX
            signal(SIGTSTP, Save_sig[ri++]);
            signal(SIGCONT, Save_sig[ri++]);
#endif
            break;
        case 15:
            mvaddstr(UTOP + 1, ATOIX, "ENTER 3");
            mvaddstr(UTOP + 2, ATOIX, "OCTAL  ");
            mvaddstr(UTOP + 3, ATOIX, "DIGITS ");
            value = -1;
            while(value == -1) {
                mvaddstr(UTOP, ATOIX, "oct    ");

                ledit(bbuf, a_ed_map, UTOP, ATOIX+4, ATOIX+6, 0, 1, 1);
                if (!*bbuf)
                    continue;
                value = 0;
                upcase(bbuf);
                bb = bbuf;
                for (ri = strlen(bbuf); --ri >= 0; bb++) {
                    value <<= 3;
                    value += (*bb > 57) ? (*bb - 55) : (*bb - 48);
                }
                if (value < 0 || value > 127) {
                    value = -1;
                    continue;
                }
            }
            move(UTOP, ATOIX);
            printw("oct %.3o", value);

            move(UTOP + 1, ATOIX);
            if (value == 127)
                printw("asc DEL");
            else if (value < 33)
                printw("%s",lotab[value]);
            else
                printw("asc   %c",value);
            move(UTOP + 2, ATOIX);
            printw("dec %3d", value);
            move(UTOP + 3, ATOIX);
            printw("hex  %.2x", value);
            break;
        case 24:
            mvaddstr(UTOP + 1, ATOIX, "ENTER 2");
            mvaddstr(UTOP + 2, ATOIX, "HEX    ");
            mvaddstr(UTOP + 3, ATOIX, "DIGITS ");
            value = -1;
            while(value == -1) {
                mvaddstr(UTOP, ATOIX, "hex    ");

                ledit(bbuf, a_ed_map, UTOP, ATOIX+4, ATOIX+6, 0, 1, 1);
                if (!*bbuf)
                    continue;
                value = 0;
                upcase(bbuf);
                bb = bbuf;
                for (ri = strlen(bbuf); --ri >= 0; bb++) {
                    value <<= 4;
                    value += (*bb > 57) ? (*bb - 55) : (*bb - 48);
                }
                if (value < 0 || value > 127) {
                    value = -1;
                    continue;
                }
            }
            move(UTOP, ATOIX);
            printw("hex  %.2x", value);

            move(UTOP + 1, ATOIX);
            if (value == 127)
                printw("asc DEL");
            else if (value < 33)
                printw("%s",lotab[value]);
            else
                printw("asc   %c",value);

            move(UTOP + 2, ATOIX);
            printw("dec %3d", value);
            move(UTOP + 3, ATOIX);
            printw("oct %.3o", value);
            break;
    }
    PYX;
    pfresh();
TR_
}

