char *version = "Wed Feb 21 16:39:20 EST 1990";
