/*
 * lock.c - lock a tty until owner returns
 *
 * cc lock.c -O -s -o lock
 *
 * Toby Harness		3/18/84
 */

#include <stdio.h>
#include <signal.h>
#include <pwd.h>

#define MASTER "lock"

extern	char *crypt(), *getpass();
extern	struct passwd *getpwuid(), *getpwnam();

main(argc, argv)
int argc;
char **argv;
{
        register int i;
	char salt[3], MasterSalt[3], *in_string;
	struct passwd *pw, *Masterpw;

	if((pw = getpwuid(getuid())) == NULL) {
		fprintf(stderr, "%s:  Who are you?\n", *argv);
		exit(1);
	}
	if((Masterpw = getpwnam(MASTER)) == NULL) {
		fprintf(stderr, "%s:  can`t find passwd entry for %s\n",
			*argv, MASTER);
		exit(1);
	}

	while(i < 19)
                signal(i++, SIG_IGN);

        in_string = getpass("LOCKED\nPassword:  ");

	strncpy(salt, pw->pw_passwd, 2);
	strncpy(MasterSalt, Masterpw->pw_passwd, 2);

        for (;;) {
                if(*in_string &&
		   (!strcmp(pw->pw_passwd, crypt(in_string, salt)) ||
		    !strcmp(Masterpw->pw_passwd, crypt(in_string, MasterSalt))))
                        break;
        	in_string = getpass("Password:  ");
        }
}
