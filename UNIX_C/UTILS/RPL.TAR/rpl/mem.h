/*
	mem.h

*/

#define memmove(dst, src, cnt) bcopy(src, dst, cnt)
