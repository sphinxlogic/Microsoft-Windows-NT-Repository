/*
 * cscript - record a terminal session
 * Author:	Grant Dorman
 * Modified by Ray Swartz
 * Modified by Kent Forschmiedt 20jun88
 */
#ifndef lint
static char *sccsid = "@(#)cscript.c	2.2  6/20/88";
#endif

#include <stdio.h>
#include <signal.h>
#include <fcntl.h>

#define SHELL		"/bin/sh"
#define SCRIPTOUT	"typescript"
#define SHFLAGS		"-i"

void exit(), perror();

char *getenv(), *ctime();

int fd;				/* record file */
char buf[BUFSIZ];
char *fname;
char *shell;
int qflg;
int ipd[2], opd[2];	/* pipes */

main(argc, argv)
int argc; char **argv;
{
	int getopt();
	extern char *optarg;
	extern int optind;

	int c, oflags;

	oflags = O_WRONLY + O_CREAT + O_TRUNC;
	shell = (char *)0;

	while ((c = getopt(argc, argv, "aqs:")) != EOF)
		switch(c) {
			case 'a':	/* append mode */
				oflags = O_WRONLY + O_CREAT + O_APPEND;
				break;
			case 'q':	/* quiet mode */
				qflg++;
				break;
			case 's':
				shell = optarg;
				break;
			default:
				fprintf(stderr, "Usage: cscript [-aq] [ -s shell ] [file]\n");
				exit(3);
		}

	if (!shell && (shell = getenv("SHELL")) == (char *)0)
		shell = SHELL;

	fname = (optind < argc) ? argv[optind] : SCRIPTOUT;
	if ( (fd = open(fname, oflags, 0666)) < 0) {
		perror("cscript: open");
		exit(4);
	}

	if (pipe(ipd) == -1) {
		perror("cscript: pipe");
		exit(2);
	}
	if (pipe(opd) == -1) {
		perror("cscript: pipe");
		exit(2);
	}

	switch(fork()) {
		case -1: perror("cscript: fork 1"); exit(1);

		case 0: switch(fork()) {
			case -1:	perror("cscript: fork 2"); exit(1);

			case 0:		do_stdin(); exit(6);
			default:	do_shell(); exit(6);
		}
		default:	do_stdout(); exit(6);
	}

	/* NOTREACHED */
}


do_stdout()
{
	unsigned nread;
	long time(), tloc;

	/* this process will exit when the pipe closes */
	signal(SIGHUP, SIG_IGN); /* */
	signal(SIGINT, SIG_IGN); /* */
	signal(SIGQUIT, SIG_IGN); /* */

	close(ipd[0]); close(ipd[1]);

	close(0); dup(opd[0]);
	close(opd[0]); close(opd[1]);

	fprintf(stderr, "Recording...\nExit shell to stop\n");

	while((nread = read(0, buf, sizeof buf)) != 0) {
		write(1, buf, nread);
		write(fd, buf, nread);
	}

	if (!qflg) {
		time(&tloc);
		fprintf(stderr, "Script done, file is %s\n", fname);
		sprintf(buf, "\nScript done %s", ctime(&tloc));
		write(fd, buf, (unsigned) strlen(buf));
	}

	exit(0);
}

do_stdin()
{
	unsigned nread;

	close(opd[0]); close(opd[1]);
	close(1); dup(ipd[1]);
	close(ipd[0]); close(ipd[1]);

	while((nread = read(0, buf, sizeof buf)) != 0) {
		write(fd, buf, nread);
		write(1, buf, nread);
	}

	exit(0);
}

do_shell()
{
	long time(), tloc;

	close(0); dup(ipd[0]);
	close(1); dup(opd[1]);
	/* mush stderr into stdout pipe */
	close(2); dup(opd[1]);

	close(opd[0]); close(opd[1]);
	close(ipd[0]); close(ipd[1]);
	close(fd);

	if (!qflg) {
		time(&tloc);
		fprintf(stderr, "Script started %s", ctime(&tloc));
	}

	execl(shell, shell, SHFLAGS, 0);
	perror("cscript: execl");
	exit(5);
}
