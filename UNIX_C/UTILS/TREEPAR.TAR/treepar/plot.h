/* plot.h - plot package stuff
 *
 * 30.Jul.87  jimmc  Initial defintion
 * 17.Aug.87  jimmc  Add textsize function
 * 27.Aug.87  jimmc  Remove box function
 */

typedef struct _PDevInfo {	/* device descriptor */
	struct _PDevInfo *next;	/* linked list of device descriptors */
	char *name;
	int (*init)();
	int (*done)();
	int (*line)();
	int (*text)();
	int (*textsize)();
} PDevInfo;

extern PDevInfo *Pnew();

/* positions for text */
#define N 0
#define S 1
#define E 2
#define W 3
#define NE 4
#define NW 5
#define SE 6
#define SW 7
#define C 8	/* center */

/* end */
