/* misc.c - random small routines.
 *
 *  5.Feb.88  jimmc  Created by collecting routines from other files
 */

#include <stdio.h>
#include "xalloc.h"

extern char *Progname;
extern char *treeparVersion;
extern char Tflag[];

/* VARARGS1 */
fatalerr(fmt,arg0)
char *fmt;
char *arg0;
{
char buf[2000];

	sprintf(buf,fmt,arg0);
	fprintf(stderr,"%s: %s\n", Progname,buf);
	exit(1);
}

char *
strsav(str)
char *str;
{
char *newstr;

	newstr = XALLOC(char,strlen(str)+1);
	strcpy(newstr,str);
	return newstr;
}

tfree(p)
char *p;
{
	if (!Tflag['m'])
		XFREE(p);
}

char *
TVersion()
{
	return treeparVersion;
}

/* end */
