/* djberr.h, 11/1/89. */

#ifndef __DJBERRH_
#define __DJBERRH_

extern int errno;

#define errn(s) (((void) fputs(s,stderr)), putc('\n',stderr))
#define err(s) (fputs(s,stderr))
#define errn2(s,t) (((void) fprintf(stderr,s,t)), putc('\n',stderr))
#define errn3(s,t,u) (((void) fprintf(stderr,s,t,u)), putc('\n',stderr))
#define perrn2(s,t) { int dummyerrno = errno; (void) fprintf(stderr,s,t); \
		      (void) fputs(": ",stderr); errno = dummyerrno; \
		      (void) perror(""); }

#endif
