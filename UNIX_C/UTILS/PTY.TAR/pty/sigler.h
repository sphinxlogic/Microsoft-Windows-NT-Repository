/* Copyright 1990, Daniel J. Bernstein. All rights reserved. */

#ifndef PTY_SIGLER_H
#define PTY_SIGLER_H

extern void sigler();

#endif
