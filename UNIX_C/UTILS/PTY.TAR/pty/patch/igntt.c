#include <signal.h>

main(argc,argv)
int argc;
char *argv[];
{
 switch (fork())
  {
   case -1: exit(1);
   case 0: break;
   default: exit(0);
  }
 (void) signal(SIGTTOU,SIG_IGN);
 (void) signal(SIGTTIN,SIG_IGN);
 (void) sleep(1);
 (void) execvp(argv[1],argv + 1);
 (void) exit(1);
}
