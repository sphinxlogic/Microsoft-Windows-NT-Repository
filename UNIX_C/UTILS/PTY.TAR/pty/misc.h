/* Copyright 1990, Daniel J. Bernstein. All rights reserved. */

#ifndef PTY_MISC_H
#define PTY_MISC_H

extern int sessdir();
extern char *real_ttyname();
extern void setusername();

#endif
