/* Copyright 1990, Daniel J. Bernstein. All rights reserved. */

#ifndef PTY_SLAVE_H
#define PTY_SLAVE_H

extern void slave();

#endif
