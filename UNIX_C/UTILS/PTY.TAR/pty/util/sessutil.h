#ifndef SESSUTIL_H
#define SESSUTIL_H

struct pty_session
 {
  char ext1;
  char ext2;
  int uid;
  int siglerpid;
  int masterpid;
  int slavepid;
 }
;

int pty_sessdir();
int pty_get_sess();
int pty_get_sessbyext();
int pty_set_sess();
int pty_get_sessname();
int pty_set_sessname();
int pty_get_rebyext();
int pty_set_sig();
int pty_unset_sig();

#endif
