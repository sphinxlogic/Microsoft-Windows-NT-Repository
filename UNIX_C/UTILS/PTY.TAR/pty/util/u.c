/* Public domain. */
#include <stdio.h>
#include <utmp.h>
#include <strings.h>
extern char *malloc();
#define PTYUTMP_FILE "/etc/utmp"

int compar(s,t)
char (**s)[8];
char (**t)[8];
{
 return -strncmp(&(**s)[0],&(**t)[0],8);
}

main()
{
 register FILE *fi;
 struct utmp ut;
 char (*us)[8];
 char (**up)[8];
 int lines = 0;
 int i = 0;
 
 if (fi = fopen(PTYUTMP_FILE,"r"))
   while (fread((char *) &ut,sizeof(ut),1,fi))
     if (ut.ut_name[0])
       lines++;
 (void) fclose(fi);
 us = malloc(sizeof(*us) * (lines + 50));
 up = malloc(sizeof(*up) * (lines + 50));
 if (fi = fopen(PTYUTMP_FILE,"r"))
   while (fread((char *) &ut,sizeof(ut),1,fi))
     if ((ut.ut_name[0]) && (i < lines + 50))
      {
       (void) strncpy(us[i],ut.ut_name,8);
       up[i] = us + i;
       i++;
      }
 (void) fclose(fi);
 (void) qsort(up,i,sizeof(*up),compar);

 while (i-- > 0)
   (void) printf((i ? "%.8s " : "%.8s\n"),up[i]);

 (void) exit(0);
}
