/* Public domain. */

#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include "sessutil.h"
extern unsigned short getuid();

#define FOO (void) fstat(0,&st); \
if (which) (void) fchmod(0,(int) (st.st_mode | 0020)); \
else (void) fchmod(0,(int) (st.st_mode & ~0020));

main(argc,argv)
int argc;
char *argv[];
{
 struct stat st;
 struct pty_session ps;
 int uid;
 int which;

 uid = getuid();

 if (argc == 1)
  {
   (void) setreuid(uid,uid);
   (void) fstat(0,&st);
   if (which = st.st_mode & 0020)
     (void) printf("is y\n");
   else
     (void) printf("is n\n");
   (void) exit(1 - which);
  }
 else
  {
   switch(argv[1][0])
    {
     case 'y': which = 1; break;
     case 'n': which = 0; break;
     default: (void) fprintf(stderr,"mesg: usage: mesg [y] [n]\n"); exit(1);
    }
   if (pty_get_sess(0,uid,&ps) == -1)
    {
     (void) setreuid(uid,uid);
     FOO
    }
   else
     if (ps.uid != uid)
       (void) fprintf(stderr,"not your session\n");
     else
      {
       FOO
       (void) setreuid(uid,uid);
       FOO
      }
  }
 (void) exit(0);
}
