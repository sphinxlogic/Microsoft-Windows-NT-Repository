/* Public domain. */

extern char *ttyname();

main(argc,argv)
int argc;
char *argv[];
{
 char *s;

 s = ttyname(0);

 if ((argc != 2)
   ||(argv[1][0] != '-') || (argv[1][1] != 's') || (argv[1][2] != '\0'))
   if (s)
     (void) puts(s);
   else
     (void) puts("not a tty");
 (void) exit(!s);
}
