/* Public domain. */
#include <curses.h>
#include <signal.h>
#include <strings.h>

main()
{
 char key[100];
 char key2[100];
 struct sigvec vec;
 int i;

 vec.sv_handler = SIG_IGN;
 vec.sv_mask = 0;
 for (i = 31;i > 0;i--)
   (void) sigvec(i,&vec,(struct sigvec *) 0);
 (void) savetty();
 (void) crmode();
 (void) noecho();
 (void) printf("Key: ");
 if (fgets(key,sizeof(key) - 2,stdin))
  {
   (void) printf("\nAgain: ");
   if (fgets(key2,sizeof(key2) - 2,stdin))
    {
     if (!strcmp(key,key2))
      {
       (void) printf("\n");
       while ((fgets(key2,sizeof(key2),stdin) == NULL) || strcmp(key,key2))
	{
	 (void) printf("Bad password!\n");
	 (void) sleep(1);
	}
      }
     else (void) printf("\n");
    }
   else (void) printf("\n");
  }
 else (void) printf("\n");
 (void) resetty();
 (void) exit(0);
 /*NOTREACHED*/
}
