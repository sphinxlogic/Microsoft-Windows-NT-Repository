/* Copyright 1990, Daniel J. Bernstein. All rights reserved. */

#ifndef PTY_SOCK_H
#define PTY_SOCK_H

extern int pty_readsock();
extern int pty_writesock();
extern int pty_acceptsock();

/* -1 fail, 0 success */
extern int pty_putgetstr();
extern int pty_putgetfd();
extern int pty_putgetonefd();
extern int pty_putgetint();
extern int pty_putgettty();
extern int pty_getch();

/* -1 fail, 0 success, 1 refused */
extern int pty_sendstr();
extern int pty_sendfd();
extern int pty_sendonefd();
extern int pty_sendint();
extern int pty_sendtty();
extern int pty_putch();

#endif
