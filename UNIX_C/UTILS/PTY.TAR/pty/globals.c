/* Copyright 1990, Daniel J. Bernstein. All rights reserved. */

#include "config.h"
#include "pty.h"

int uid;
int euid;
int pid;
int pgrp;
long date;
char *username;

int fdin = -1;
int fdout = -1;
int fdmty = -1;
int fdsty = -1;
int fdtty = -1;
int fdre = -1;
int fdpass = -1;

int flagquiet = 0;
int flagdetached = 0;
int flagjobctrl = 1;
int flagttymodes = 1;
int flagsameerr = 0;
int flagfdpass = 0;
int flagsession = 0;
int flagverbose = 0;

int flagxchown = 0;
int flagxutmp = 0;
int flagxwtmp = 0;
int flagxexcl = 0; /* should be 1, but that would break write & friends */
int flagxerrwo = 0; /* should be 1, but that would break csh & more */
int flagxchkopen = 1;
int flagxskipopen = 0;
int flagxrandom = 1; /* random pty searching: worth the effort */
int flagxsetuid = 1;

#include "tty.h"

struct ttymodes tmotty; /* original tty modes */
struct ttymodes tmochartty; /* tty in character mode */
struct ttymodes tmopty; /* original pty modes */
