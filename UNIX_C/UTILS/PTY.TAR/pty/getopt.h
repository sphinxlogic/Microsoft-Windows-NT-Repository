/* Copyright 1990, Daniel J. Bernstein. All rights reserved. */

#ifndef PTY_GETOPT_H
#define PTY_GETOPT_H

/* The following should be in /usr/include/getopt.h but often aren't. */
extern int getopt();
extern char *optarg;
extern int optind;

#endif
