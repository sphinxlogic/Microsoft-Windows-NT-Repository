/* Copyright 1990, Daniel J. Bernstein. All rights reserved. */

#ifndef PTY_FILE_H
#define PTY_FILE_H

#include <sys/file.h>
#ifdef BSD
#include <limits.h>
#endif
#include <fcntl.h>
extern long lseek(); /* sigh. */

#endif
