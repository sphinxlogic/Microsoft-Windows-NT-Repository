/* Copyright 1990, Daniel J. Bernstein. All rights reserved. */

#ifndef PTY_LOGS_H
#define PTY_LOGS_H

extern long now();
extern int utmp();
extern int wtmp();

#endif
