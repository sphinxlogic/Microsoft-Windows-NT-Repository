/* Copyright 1990, Daniel J. Bernstein. All rights reserved. */

#ifndef PTY_TEXTS_H
#define PTY_TEXTS_H

extern char *ptyauthor[];
extern char *ptyversion[];
extern char *ptycopyright[];
extern char *ptywarranty[];
extern char *ptyusage[];
extern char *ptyhelp[];

#endif
