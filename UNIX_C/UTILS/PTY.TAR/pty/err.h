/* Copyright 1990, Daniel J. Bernstein. All rights reserved. */

#ifndef PTY_ERR_H
#define PTY_ERR_H

#include <errno.h>
extern int errno; /* not always defined in errno.h, grrrr */
extern int sys_nerr;
extern char *sys_errlist[];

extern void fatal();
extern void fatalinfo();
extern void fatalerr();
extern void fatalerr2p();
extern void fatalerrp();
extern void warnerr2();

#endif
