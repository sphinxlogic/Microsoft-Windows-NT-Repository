
#include <stdio.h>

static char buf[256];
int	argc_copy;
char	**argv_copy;

main(argc, argv)
    int  argc;
    char **argv;
{
    int x1,y1,x2,y2,x3,y3;
    int r;
    char c;

    argc_copy = argc;
    argv_copy = argv;

    openpl();

    while ((c = getc(stdin)) != EOF) {

	switch (c) {
	    case 'm': 			/* move */
		x1 = getint();
		y1 = getint();
		move(x1,y1);
		break;

 	    case 'n':			/* cont */
                x1 = getint();
                y1 = getint();
		cont(x1,y1); 
		break;
                	    
	    case 'p':			/* point */
		x1 = getint();
		y1 = getint();
		point(x1,y1);
		break;

	    case 'l': 			/* line */
		x1 = getint();
		y1 = getint();
		x2 = getint();
		y2 = getint();
		line(x1,y1,x2,y2);
		break;

	    case 't': 			/* text */
		string(buf);
		label(buf);
		break;

	    case 'e': 			/* erase */
		erase();
		break;

	    case 's': 			/* space */
		x1 = getint();
		y1 = getint();
		x2 = getint();
		y2 = getint();
		space(x1,y1,x2,y2);
		break;

	    case 'a': 			/* arc */
		x1 = getint();
		y1 = getint();
		x2 = getint();
		y2 = getint();
		x3 = getint();
		y3 = getint();
		arc(x1,y1,x2,y3,x3,y3);
		break;

	    case 'c': 			/* circle */
		x1 = getint();
		y1 = getint();
		r  = getint();
		circle(x1,y1,r);
		break;

	    case 'f': 			/* linemod */
		string(buf);
		linemod(buf);
		break;

	    case 'r': 			/* homemade labelrotation*/
		string(buf);
		labelrotation(buf);
		break;

	    case 'u': 			/* homemade labelplace*/
		string(buf);
		labelplace(buf);
		break;

	    case 'z': 			/* homemade colorfunction*/
		string(buf);
		selectcolor(buf);
		break;

	    default: 
		fprintf(stderr, "%s: unknown command 0x%x", argv[0], c & 0xff);
		if (c >= ' ')
		      fprintf(stderr, " '%c'\n", c);
		  else
		      fprintf(stderr, " '^%c'\n", c + '@');
	}
    }
    closepl();
}

getint()
{	
    /* get an integer stored in 2 ascii bytes. */
    short   b1,
            b2;
    if ((b1 = getchar()) == EOF)
	return (EOF);

    if ((b2 = getchar()) == EOF)
	return (EOF);

    b2 = b2 << 8;
    return (b2 | b1);
}

string(s)
    char *s;
{
    for (; *s = getchar(); s++) {
	if (*s == '\n')
	    break;
	}
    *s = '\0';
    return;
}
