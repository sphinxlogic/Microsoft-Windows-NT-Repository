#include <sgtty.h>
#include <stdio.h>
#include <math.h>

/* HP-GL plot(5) library				*/
/* - does NOT do line locking				*/
/* - aspect ratio is not maintained			*/
/* Jim Constantine	               	 		*/
/* Copyright 1985 Sun Microsystems Inc.			*/
/* Extensions by ingi@hafro.is (June, 1989) 		*/
/* Prepared for redistribution by gunnar@hafro.is	*/
/* Notable features: This program is to be used to
   create troff files.  It can be used to print to a 
   device without putting the statements through a file.
   just use scat < file | graplot | lprenta8		*/

static char stre[15];
static char just[10];
static char jus1[10];
static char tex1[10];
openpl()
{
    struct sgttyb   sgarg;
    int local;
    printf("\\!! rasterize=300\n");
    printf(".G1\n");

    printf("frame invis ht 4 wid 6.2\n");
    printf("X=1\nY=0\n");
    printf("draw solid\n");
}
move(X, Y)
{
    /* printf("move from X,Y to %d,%d\n",X,Y);*/
    printf("X=%d\n",X);
    printf("Y=%d\n",Y);
}

line(X1, Y1, X2, Y2)
{
    printf("line %s from %d,%d to %d,%d\n", stre,X1, Y1, X2, Y2);
}

label(s)
    char   *s;
{
    printf("\"%s\" %s at X%s,Y%s\n",s,tex1,just,jus1);
}

erase()
{
    printf("\n");		/* feed page if paper has been writen on */
}

point(X, Y)
{
    printf("line %s from %d,%d to %d,%d\n",stre, X,Y,X, Y);
}

cont(X, Y)
{
    printf("line %s from X,Y to %d,%d\n", stre,X, Y);
    printf("X=%d\n",X);
    printf("Y=%d\n",Y);
}

space(X1, Y1, X2, Y2)
{
    printf("ticks bot out .0001i from %d to %d by %d \"\"\n",X1,X2,X2);
    printf("ticks left out .0001i from %d to %d by %d \"\"\n",X1,X2,X2);
}

arc(Xc, Yc, X1, Y1, X2, Y2)
{
    /* args are:  center, start, end */
 }

circle(X, Y, r)
{
}

linemod(s)			/* line stYle */
    char *s;
{
    switch(s[3]) {

    case 't': /* dotTed */
	printf("new dotted\n");
	strcpy(stre,"dotted");
	break;

    case 'i': /* solId */
    default:
	printf("new solid\n");
	strcpy(stre,"solid");
	break;
 
    case 'g': /* lonGdashed */
	printf("new dashed\n");
	strcpy(stre,"dashed");
	break;

    case 'r': /* shoRtdashed */
	printf("new dashed .5i\n");
	strcpy(stre,"dashed .1i");
	break;

    case 'd': /* dotDashed */
	printf("new dashed .05i\n");
	strcpy(stre,"dashed .05i");
	break;
    }
}

labelrotation(s)
    char *s;
{

 /*   switch(s[1]) {

    case 'h': 
	printf("DI 1,0\n");
	

    case 'v': 
	printf("DI 0,1\n");
	
    } 
*/}


labelplace(s)
    char *s;
{

    switch(s[1]) {

    case 'u': /* center the label under the point */
	strcpy(just,"-0");
	strcpy(jus1,"-15");
        strcpy(tex1,"");
	break;

    case 'o': /* center the label over the point */
	strcpy(just,"-0");
	strcpy(jus1,"+15");
        strcpy(tex1,"");
	break;

    case 'l': /* center the label left at the point */
	strcpy(jus1,"-0");
	strcpy(just,"-0");
	strcpy(tex1,"rjust");
	break;

    case 'r': /* center the label right at the point */
	strcpy(jus1,"-0");
	strcpy(just,"+0");
	strcpy(tex1,"ljust");
	break;

    case 'c': /* center the label at the point */
	strcpy(just,"-0");
	strcpy(jus1,"-0");
        strcpy(tex1,"");
	break;

    default: /* center the label at the point */
	strcpy(just,"-0");
	strcpy(jus1,"-0");
        strcpy(tex1,"");
	break;
    } 
}

selectcolor(s)
    char *s;
{

    /* switch(s[1]) {

    case '1': /* select pen 1 
	printf("SP 1\n");
	break;

    case '2': /* select pen 2 
	printf("SP 2\n");
	break;

    case '3': /* select pen 3 
	printf("SP 3\n");
	break;

    case '4': /* select pen 4 
	printf("SP 4\n");
	break;

    case '5': /* select pen 5 
	printf("SP 5\n");
	break;

    case '6': /* select pen 6 
	printf("SP 6\n");
	break;

    case '7': /* select pen 7 
	printf("SP 7\n");
	break;

    case '8': /* select pen 8 
	printf("SP 8\n");
	break;

    default: /* select pen 1 
	printf("SP 1\n");
	break;
    } */ 
}

closepl()
{
    printf (".G2\n");
}









