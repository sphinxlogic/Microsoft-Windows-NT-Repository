read x y
read dum
dataplot -n x$x -n y$y
