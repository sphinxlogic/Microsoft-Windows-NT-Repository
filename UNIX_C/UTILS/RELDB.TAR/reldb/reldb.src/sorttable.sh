#!/bin/sh
#
# sorttable -- sort a reldb table

trap "rm tmp$$ tmp1$$" 15 2 1 
opt="-t	"
col=""
file=""
sortcol=""
for i
do
case $1 in
	'-n')
		opt="$opt -n"
		shift
		;;
	'-f')
		file=$2
		shift
		shift
		;;
	*)
		col="$col $1"
		shift
		;;
esac
done

sed -n "1,2p
3,\$w tmp$$" < $1  | tee tmp1$$

read columns < tmp1$$

for i in $col
do
	colnr=0
	for j in $columns
	do
		if [ X$i  = X$j ]
		then
			sortcol="$sortcol +$colnr"
		fi
		colnr=`expr $colnr + 1`
	done	
done
sort $opt $sortcol tmp$$
rm tmp$$ tmp1$$


