awk 'BEGIN{FS="	"}
NR==1{for(i=1;i<=NF;i++){
	ind[i]=$(i)
	lengd[i]=length($(i))
	}
	svidafj=NF;
     }
NR>2{for(i=1;i<=NF;i++)
	if(length($(i))>lengd[i])lengd[i]=length($(i));
    }
END{	print "Atridi	Lengd"
	print "------	-----"
	for(i=1;i<=svidafj;i++)
		print ind[i]"	"lengd[i]
   }' 
