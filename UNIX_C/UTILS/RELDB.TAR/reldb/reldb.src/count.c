/*
	Program to count the number of identical lines
						 */ 
#include <stdio.h>
#define MAXLIN 500
main(){
	int count;			/* counter for equal lines */
	char line[MAXLIN],prev[MAXLIN];	/* current and previous lines */

	fgets(line,MAXLIN,stdin);	/* get 2 reldb header lines */
	printf("count\t%s",line);	/* and prepend count header */
	fgets(line,MAXLIN,stdin);
	printf("-----\t%s",line);
	count=1;			/* initialize counter */
	fgets(prev,MAXLIN,stdin);
	while(fgets(line,MAXLIN,stdin)!=NULL){
		if(strcmp(line,prev)){	/* 1 = not same as before */
			printf("%d\t%s",count,prev);
			strcpy(prev,line);
			count=1;
		} else
			count++;
	}
	printf("%d\t%s",count,prev);
}
