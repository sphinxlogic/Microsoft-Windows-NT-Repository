#!/bin/sh
#
# flattotable - convert files with tabs and spaces to reldb table,
#               where only one tab separates columns.
#
# Eliminates tabs/spaces at beginning and end of lines.

sed -e 's/^[ 	]*//' \
    -e 's/[ 	]*$//' \
    -e 's/[ 	][ 	]*/	/g'
