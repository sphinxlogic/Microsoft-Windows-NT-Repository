trap "rm tmp$$ haus$$" 2 14 15
opt=""
case $1 in
	'-n'|'-a1'|'-a2')
		opt=$1
		shift
		;;
esac
sed 1q < $1 | tr '\012' '	'  >haus$$
sed 's/^[^	]*	//
1q' < $2 >>haus$$
sed 'p
s/[^	]/-/g' < haus$$
sed '1,2d' < $2 >tmp$$
sed '1,2d' < $1 | join $opt -t"	" - tmp$$ 
rm tmp$$ haus$$

