#!/bin/sh
#
# neat little script for interfacing with |Stat's dataplot.
read x y
read dum
dataplot -n x$x -n y$y$ $*
