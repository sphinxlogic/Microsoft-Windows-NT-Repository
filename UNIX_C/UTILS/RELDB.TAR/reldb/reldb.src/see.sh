#!/bin/sh
#
# Trivial implementation of "see"
#
cat -vte $1
