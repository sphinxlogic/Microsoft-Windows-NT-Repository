:
# Reldb version of unixstat's (|Stat) pair
read x y
read dum
pair -p -x $y -y $y
