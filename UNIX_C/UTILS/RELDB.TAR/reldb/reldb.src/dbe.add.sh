:
#
# dbe.add
#
# Usage: dbe.add file
#
# Type ctrl-C to quit
#
# Method:
#
# First read the reldb header fro the file
#
# Then go into an everlasting loop, reading each field from the
# terminal. After a record has been read, it is echo-ed to the end of the file.
#
read x < $1
while(true)
do
	record=""
	tput clear
	for fld in $x
	do
		echo "$fld : \c"
		read temp
		record="$record	$temp"
	done
	record=`echo "$record"|sed 's/^	//'`
	echo "$record" >> $1
done
