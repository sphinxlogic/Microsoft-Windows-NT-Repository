#!/bin/sh
#
# number -- add a number column
awk '
NR == 1	{print "nr	"$0}
NR == 2	{print "--	"$0}
NR > 2	{print NR-2"	"$0}' < $1
