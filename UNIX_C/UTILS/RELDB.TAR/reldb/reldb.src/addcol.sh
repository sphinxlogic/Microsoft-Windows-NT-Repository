#!/bin/sh
#
# addcol - add columns to a table
#
# Usage: addcol columns < data
#
# Author: gunnar@hafro.is
# Revisions: none yet ?
#
# NOTE: This seems to generate an invalid table -- extra tabs
#       should be added in the data part.

add=
for i 
do
	add=$add'	'$i
done
sed '1{
s/$/'"$add"'/
p
s/[^	]/-/g
}
2d' 
