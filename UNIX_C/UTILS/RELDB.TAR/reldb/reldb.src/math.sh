#!/bin/sh
#
# math -- compute some statistics on a table.
#
# BUG: <tab><tab> is used as a zero -- should be missing

awk 'BEGIN {FS="	";OFS="	"}
NR==1	{print $0"	Type";totf=NF}
     NR==2	{print $0"	----";
	 	 for(i=1;i<=NF;i++){
				max[i]= -1e64;
				min[i]=1e64;
		}}
     NR>2	{for(i=1;i<=NF;i++){
			if($(i)!=""){
				sum[i]+=$(i);
				sum2[i]+=$(i)*$(i);
				freq[i]++;
				if($(i)>max[i])
					max[i]=$(i);
				if($(i)<min[i])
					min[i]=$(i);
			}
		}}
      END	{for(i=1;i<=totf;i++)
			printf("%d\t",freq[i]);
		 printf("Freq\n");
      		 for(i=1;i<=totf;i++)
		 	if(sum[i]==int(sum[i]))
				printf("%d\t",sum[i]);
			else
				printf("%f\t",sum[i]);
		 printf("Sum\n");
      		 for(i=1;i<=totf;i++){
			mean=sum[i]/freq[i]
			if(mean=int(mean))
				printf("%d\t",sum[i]/freq[i]);
			else
				printf("%f\t",sum[i]/freq[i]);
		 }
		 printf("Mean\n");
      		 for(i=1;i<=totf;i++){
			stdev=sqrt((sum2[i]-sum[i]*sum[i]/freq[i])/(freq[i]-1));
			if(stdev>1&&stdev<10)
				printf("%.5f\t",stdev);
			else
				printf("%f\t",stdev);
		 }
		 printf("Stddev\n");
      		 for(i=1;i<=totf;i++)
			if(max[i]==int(max[i]))
				printf("%d\t",max[i]);
			else
				printf("%f\t",max[i]);
		 printf("Maximum\n");
      		 for(i=1;i<=totf;i++)
			if(min[i]==int(min[i]))
				printf("%d\t",min[i]);
			else
				printf("%f\t",min[i]);
		 printf("Minimum\n");
		}
'
