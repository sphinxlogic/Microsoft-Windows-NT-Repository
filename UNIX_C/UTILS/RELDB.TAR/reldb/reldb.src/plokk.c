/* 
	Program to select lines according to values in the first column
	of each line.

	Usage : plokk fnam < file

	file = name of data file

	fnam = name of file containing values to be selected
							*/
#include <stdio.h>

main(argc,argv)
int argc;
char *argv[];
{
	char lina[1000];	/* input line*/
	int n;			/* first value in a data line */
	
	int select[5000];	/* 1=values to select 0=skip*/
	int nsel;		/* running value to select */

	FILE *fp,*fopen();

	if((fp=fopen(argv[1],"r"))==NULL){	/* open selection file */
		fprintf(stderr,"Usage : plokk selfil < datfil\n");
		exit(-1);
	}

	nsel=0;					/* initialize selection */
	while(nsel<5000)
		select[nsel++]=0;

	fgets(lina,1000,fp);			/* read selection file */
	fgets(lina,1000,fp);
	while(fgets(lina,1000,fp)!=NULL){
		sscanf(lina,"%d",&nsel);
		if(nsel< -1 || nsel> 5000){
			fprintf(stderr,"plokk : index in selection file out of bounds %d\n",nsel);
			exit(1);
		}
		select[nsel+1]=1;
	}
	fclose(fp);

	fgets(lina,1000,stdin);
	printf("%s",lina);
	fgets(lina,1000,stdin);
	printf("%s",lina);
	while(fgets(lina,1000,stdin)!=NULL){	/* perform selection */
		sscanf(lina,"%d",&n);
		if(n< -1 || n > 5000){
			fprintf(stderr,"plokk : index in data file out of bounds %d\n",n);
			exit(1);
		}
		if(select[n+1])
			printf("%s",lina);
	}
}
