#!/bin/sh
# dbe.change
#
# Useage : dbe.add file
#
# Control-C is used to quit
#
# Method:
#
# First read the Prelude header from the file
#
# Loop over all records in the file.
#     Within each record, loop over all items in the record and 
#     ask whether this item should be modified.
#

# Exactly one of the following should be set:
#  TERMINATOR='\c'
INITIATOR='-n'
# Also set one of the following:
CLEAR=clear
#CLEAR=tput clear

trap "rm -f tempedit$$ tempoutput$$" 15 2 1 
cp $1 tempedit$$
lines=`wc -l < $1`
header=`sed '1{
s/ /_/g
q
}' < $1`
(

read dumline
echo "$dumline" > tempoutput$$
read dumline
echo "$dumline" >> tempoutput$$
line=2
while [ $line -lt $lines ]
do
	read inrec
	record=""
	$CLEAR
	for fld in $header
	do
		infield=`echo "$inrec" | sed 's/	.*//'`
		echo $INITIATOR "$fld (was $infield) : $TERMINATOR"
		read temp < /dev/tty
		if [ X"$temp" = X ]
		then
			record="$record	$infield"
		else
			record="$record	$temp"
		fi
		inrec=`echo "$inrec" | sed 's/^[^	]*	//'`
	done
	record=`echo "$record"|sed 's/^	//'`
	echo "$record" >> tempoutput$$
	line=`expr $line + 1`
done
) < tempedit$$ 
mv tempoutput$$ $1
rm -f tempedit$$
