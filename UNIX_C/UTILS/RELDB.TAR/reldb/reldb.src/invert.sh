#!/bin/sh
#
# invert -- inverse of matrix command.
#
awk 'NR==1{for(i=1;i<=NF;i++)name[i]=$(i)}
NR==2{print name[1]"	col	data" ; print "----	---	----"}
NR>2{for(i=2;i<=NF;i++){OFS="	";print $1,name[i],$(i)}}'
