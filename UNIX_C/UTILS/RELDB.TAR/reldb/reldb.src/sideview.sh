#!/bin/sh
#
# sideview -- put a table on its "side" and view a record at a time

awk 'BEGIN{FS="	"}
NR==1{for(i=1;i<=NF;i++){
	ind[i]=$(i)
	}
     }
NR>2{      print "";print "Faersla nr : ",NR-2
 for(i=1;i<=NF;i++)
	printf("%10s  %s\n", ind[i],$(i))
    }' < $1
