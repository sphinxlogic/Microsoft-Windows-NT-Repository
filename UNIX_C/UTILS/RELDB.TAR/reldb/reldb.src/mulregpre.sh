#!/bin/sh
#
# neat little script for interfacing with |Stat's "regress"
read x
read dummy
/usr/stat/bin/regress -p $x
