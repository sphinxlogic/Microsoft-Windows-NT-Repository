/* 
	compute.c -- implements the compute and select commands

	Pretty trivial program -- just reads the name-line and
	generates an awk-script saying 'name1=$1;name2=$2;...' and
	then the compute- or select-statement.

Author: gunnar@hafro (way back then; probably 1987)
	1989: I guess I shouldn't be writing to a string, but plead
	ignorance at the time...

*/
#include <stdio.h>
#include <signal.h>
#define MAXLINE 1000
char	*skrarnafn="tmp.......";	/* temporary file for awk-command */
main(argc,argv)
int	argc;
char	*argv[];
{
	char	inpline[MAXLINE];	/* input line */
	char	*ptr;			/* pointer into input line */
	int	select;			/* =0 if compute, =1 if select */
	int	i=1;			/* field number */
	int	die();			/* procedure to deal with exit */
	FILE	*fp,*fopen(),*popen();

	signal(SIGINT,die);
	if(strcmp(argv[0],"select"))
		select=0;
	else
		select=1;
	sprintf(&skrarnafn[3],"%07d",getpid());
	if((fp=fopen(skrarnafn,"w"))==NULL)
		errlog("Cannot open temporary file\n");
	gets(inpline);
	puts(inpline);			/* echo 1st header line */
	fprintf(fp,"awk 'BEGIN {FS=\"	\";OFS=\"	\"}\n{");
	ptr=inpline;
	do {
		while(*ptr!='\t'&&*ptr!='\0'&&*ptr!='\n')
			putc(*ptr++,fp);
		fprintf(fp,"=$(%d);",i);
		if(*ptr=='\t')
			*ptr++;
		i++;
	} while(*ptr!='\n'&&*ptr!='\0');
	if(select)
		fprintf(fp,"if(%s)print ",argv[1]);	/* select stmnt */
	else
		fprintf(fp,"%s;print ",argv[1]);	/* compute stmnt */
	ptr=inpline;
	do {
		if(*ptr=='\t')
			putc(',',fp);
		else
			putc(*ptr,fp);
		ptr++;
	} while(*ptr!='\n'&&*ptr!='\0');
	fprintf(fp,"}'\n");
	fclose(fp);
	chmod(skrarnafn,0777);		/* make file executable */
	gets(inpline);
	puts(inpline);			/* echo 2nd header line */
	fflush(stdout);
	if((fp=popen(skrarnafn,"w"))==NULL)		/* start up awk */
		errlog("Cannot start up awk\n");
	while(gets(inpline)!=NULL){
		fputs(inpline,fp);
		fputc('\n',fp);
	}
	pclose(fp);
	wait(0);			/* wait for awk to finish */
	die();
}
errlog(s)
char *s;
{
	fprintf(stderr,"%s",s);
	exit(1);
}
die(){
	unlink(skrarnafn);
	exit(0);
}
