#!/bin/sh
#
# columnlist.sh
#
# trivial sed-command to list column names of a table.
#
sed '1s/	/\
/g
1q'
