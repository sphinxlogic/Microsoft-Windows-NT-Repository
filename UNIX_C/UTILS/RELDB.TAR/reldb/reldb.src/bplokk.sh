#!/bin/sh
#
# Simple jointable -- first file must be sufficiently short so that
# a grep command can be set up from the whole file
GREP=`awk '
BEGIN {printf("egrep ")}
NR==3{FS="	";printf("^%s",$1)}
NR>3{FS="	";printf("|^%s",$1)}
END{print ""}'  < $1 `

# uncomment the following if you want to see what is going on
#echo $GREP

head -2 < $2
$GREP < $2
