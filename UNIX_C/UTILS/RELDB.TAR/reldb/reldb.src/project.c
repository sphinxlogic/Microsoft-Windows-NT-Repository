/*
	project:

	Author; johanna@hafro.is (1987?)
*/
#include <stdio.h>
#define MAXLINE 4096
main(argc,argv)
    int argc;
    char *argv[];
{
       int i;
       int h;
       int a;
       char line[MAXLINE];
       char tabv[1000][100];
       int posv[1000];

       i=0;

       argc--;

       header_lines(argc,argv);
       getline(line,MAXLINE,h,a);
       velja_dalka(tabv,line,&h,&a);
       gera_dalka(argc,argv,tabv,&h);
       cal_pos_val(argc,argv,tabv,posv);
       getline(line,MAXLINE,h,a);
       while((i = getline(line,MAXLINE,h,a)) > 0)
       {
          project_dalka(argc,posv,line);
       }

       exit(0);
}


header_lines(argc,argv)
int argc;
char *argv[];
{
int i;
int l;
int s;
int j;

i=j=s=l=0;

for(i=1;i <= argc;i++)
   {
    printf("%s",argv[i]);
    if(i==argc)
      printf("\n");
    else
      printf("\t");
   }
for(j=1;j <= argc;j++)
   {
    l=strlen(argv[j]);
    for(s=1;s <= l;s++)
        printf("-");
    if(j==argc)
       printf("\n");
    else
       printf("\t");
   }
}


velja_dalka(tabv,line,h,a)
char tabv[1000][100];
char line[MAXLINE];
int *h;
int *a;
{
    int i;
    int j;

    *h=0;
    i=0;

    do
    {
       j=0;
       while((line[i] != '\t') && (line[i] != '\n'))
       {
            tabv[*h][j]=line[i];
            j++;
            i++;
       }
       tabv[*h][j]='\0';
       (*h)++;
    }
    while(line[++i] != '\0');
    tabv[*h][0]='\0';
    --h;
    (*a)=(*h);
}



gera_dalka(argc,argv,tabv,h)
int argc;
char *argv[];
char tabv[1000][100];
int *h;
{
     int x;
     int y;
     char *strcpy();

     x=y=0;
     for(x=1;x <= argc;x++)
        {
          y=0;
          while((tabv[y][0] != '\0') && (strcmp(argv[x],tabv[y]) != 0))y++;
          if (strcmp(argv[x],tabv[y]) == 0)
          {
          }
          else
          {
             strcpy(tabv[y],argv[x]);
             (*h)++;
          }
        }
}



cal_pos_val(argc,argv,tabv,posv)
int argc;
char *argv[];
char tabv[1000][100];
int posv[1000];
{
    int k;
    int l;

    for(k=1;k <= argc;k++)
       {
         l=0;

         while((strcmp(argv[k],tabv[l]) != 0) && (l < 1000))l++;

         l++;
         posv[k]=l;
       }
}


project_dalka(argc,posv,line)
int argc;
int posv[1000];
char line[MAXLINE];
{
  int d;
  int t;
  int l;
  
  for (d=1;d <= argc;d++)
  {
      l=0;
      for (t=1;t < posv[d];t++)
      {
           while ((line[l] != '\t') && (line[l] != '\0')) l++;
                 l++;
      }
      while ((line[l] != '\t') && (line[l] != '\n'))
            putchar(line[l++]);
      if (d < argc)
          putchar('\t');
      else
          putchar('\n'); 
              
   }
}


getline(s,lim,h,a)
char s[];
int lim;
int h;
int a;
{
  int c;
  int i;
  int j;
  char *strcat();

  j=0;
  c=0;
  i=0;

  while (--lim > 0 && (c=getchar()) != EOF && c != '\n')
      s[i++]=c;

  if (c == '\n')
      s[i++] = c;
  s[i] = '\0';
  for(j=a;j < h;j++)
     {
     strcat(s,"\t");
     }

  return(i);
}
