#!/bin/sh
#
# Now this has to be one of the most trivial commands in the world:
#
# union -- concatanate two reldb tables, using Unix tools.
#
cat $1
shift
for i
do
	tail +3 <$i
done

