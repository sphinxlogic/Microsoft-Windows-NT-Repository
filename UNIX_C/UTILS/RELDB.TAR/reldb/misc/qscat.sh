#!/bin/sh
#
# qscat : a quick-and-dirty shell script for turning
#         Reldb files into files which can be run through grap(1)
#         to produce reasonable plots.
#         (I didn't say production-quality, but these are certainly a good
#         start - just edit the output)
echo '
\!! rasterize=300
.DF
.ce
\fB'$*'\fR
.G1
frame ht 2 wid 5
'
awk '
NR==1{for(i=1;i<=NF;i++){
	name[i]=$(i)
	}
	print "label bot ","\"",name[1],"\""
      }
NR==3{for(i=1;i<=NF;i++){
		prev[i]=$(i)
		if(i>1)print "\""name[i]"\" ljust at "$1","$(i)
		if(i==2)print "bullet at "$1","$(i)
		if(i==3)print "circle at "$1","$(i)
		if(i==4)print "plus at "$1","$(i)
		if(i==5)print "delta at "$1","$(i)
		if(i==6)print "box at "$1","$(i)
		if(i==7)print "star at "$1","$(i)
		if(i>=8)print "plus at "$1","$(i)
	  }
          }
	NR>3{for(i=2;i<=NF;i++){
		if(i==2){
			print "line from "prev[1]","prev[i]" to "$1","$(i)
			print "bullet at "$1","$(i)
		}
		if(i==3){
			print "line dashed from "prev[1]","prev[i]" to "$1","$(i)
			print "circle at "$1","$(i)
		}
		if(i==4){
			print "line dotted from "prev[1]","prev[i]" to "$1","$(i)
			print "plus at "$1","$(i)
		}
		if(i==5){
			print "delta at "$1","$(i)
			print "line dashed 0.1i from "prev[1]","prev[i]" to "$1","$(i)
		}
		if(i==6){
			print "box at "$1","$(i)
			print "line from "prev[1]","prev[i]" to "$1","$(i)
		}
		if(i==7){
			print "star at "$1","$(i)
			print "line from "prev[1]","prev[i]" to "$1","$(i)
		}
		if(i>=8){
			print "plus at "$1","$(i)
			print "line from "prev[1]","prev[i]" to "$1","$(i)
		}
		prev[i]=$(i)
	     }
	     prev[1]=$1
	   }'

echo '.G2
.DE'
