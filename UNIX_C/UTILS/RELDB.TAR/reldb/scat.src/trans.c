#include <stdio.h>
extern int debuglevel;
extern double spaceconst;
extern double wx1;
extern double wx2;
extern double wy1;
extern double wy2;


transf_data(wxmin,wymin,wxmax,wymax,inx,iny,outx,outy)
double wxmin,wymin,wxmax,wymax,inx,iny;
int   *outx,*outy;
{
  *outx=(int)((wx2-wx1)*(inx-wxmin)/(wxmax-wxmin)+wx1);
  *outy=(int)((wy2-wy1)*(iny-wymin)/(wymax-wymin)+wy1);
  if(debuglevel){
    fprintf(stderr,"inx= %lf iny= %lf\n",inx,iny);
    fprintf(stderr,"outx= %d & outy= %d\n",*outx,*outy);
  }
}

