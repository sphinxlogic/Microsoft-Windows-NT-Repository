#include <memory.h>
#include <string.h>
#include <strings.h>
#include "defs.h"

int     readline[]={1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
/* 1=data, 0=label-data */
extern int debuglevel;

read_data(numcols,numpts,names,pnames,pcol,lnames,lcol,drawline,data
,labeldata,missingvalue)

char	names[MAXCOLS][MAXTXT];	/* input : names of columns */
char    labeldata[MAXCOLS][MAXPTS][10];  /* input : label-data in columns */
char    *pnames[MAXCOLS];             /* don't draw lines for columns
                                        with this name */
char    *lnames[MAXCOLS];             /* name of column, which has
					label-data */
int	drawline[MAXCOLS];
int	pcol;
int	lcol;
int	*numcols;
int	*numpts;
int	missingvalue[MAXCOLS][MAXPTS];	/* 0=value is not missing from
					   input file, 1=value is missing 
					   from input file */
double	data[MAXCOLS][MAXPTS];	/* input : data in columns */
{
	int	c;		/* input character */
	int	i,ii;	
	int	jj;
	int	col= -1;	/* running column index */
	int	ldcol;	/* running column labeldata index */
	int	dcol;	/* running column data index */
	int	tmpcols;
	int	eol=0;
	int	fieldcount;
	char	inputline[1024];
	char	field[512];
	register char	*ip;
	register char	*ep;
	register int	n;

	double atof();

	if (debuglevel) fprintf(stderr,"In read_data\n");
	do{
		i=0;
		col++;
		while((c=getchar())!='\t'&&c!=' '&&c!='\n'&&c!=EOF)
			names[col][i++]=c;
		names[col][i]='\0';
	} while(c!='\n' && c!= EOF);
	if(c==EOF)exit(-1);
	*numcols= ++col;		/* store number of cols */
	while((c=getchar())!='\n');	/* skip line of minuses */

/* put 0 in drawline, if not to draw line for this column. */
	if(pcol > 0){
		for(i=0; i < pcol; i++)
			 for(col=1;col < *numcols;col++)
                                if(!strcmp(pnames[i],names[col]))
                                        drawline[col]=0;
	}

	if (debuglevel) {
		fprintf(stderr,"drawline after pcol\n");
		for (i=0; i < *numcols; i++)
			fprintf(stderr,"%d ",drawline[i]);
		fprintf(stderr,"\n");
	}

/* if label-column read the data in data- and labeldata-vectors */
	tmpcols= *numcols;

	if(lcol > 0){
		for(i=0; i < lcol; i++)
			 for(col=1;col < tmpcols;col++)
                                if(!strcmp(lnames[i],names[col])){
					drawline[col-1]=2;
					drawline[col]=2;
					readline[col]=0;
				}
	if (debuglevel) {
		fprintf(stderr,"drawline after lcol\n");
		for (i=0; i < *numcols; i++)
			fprintf(stderr,"%d ",drawline[i]);
		fprintf(stderr,"\nreadline after lcol\n");
		for (i=0; i < *numcols; i++)
			fprintf(stderr,"%d ",readline[i]);
		fprintf(stderr,"\n");
	}

/* fix the drawline vector */
		 for(col=1;col<tmpcols-1;col++)
			if(drawline[col] == 2 && drawline[col+1] == 2){
				for(jj=col+1; jj < tmpcols-1;jj++)
				    drawline[jj]=drawline[jj+1];
				}

	if (debuglevel) {
		fprintf(stderr,"drawline after fix\n");
		for (i=0; i < *numcols; i++)
			fprintf(stderr,"%d ",drawline[i]);
		fprintf(stderr,"\n");
	}
		*numcols=tmpcols-lcol;
		if (debuglevel) fprintf(stderr,"numcols= %d\n",*numcols);

	}
	i=0;

	while(gets(inputline)) {
	    ip = inputline;
	    fieldcount = 0;
            dcol=0;
            ldcol=0;
	    col = -1;

	    do {
		col++;
		ep = index(ip, '\t');
		if (ep == 0)
		    n = strlen(ip);
		else
		    n = ep - ip;
		if (n > 0) {
		    memcpy(field, ip, n);
		    field[n] = '\0';

                    if(readline[col]){
                        data[dcol][i]= atof(field);
			missingvalue[dcol][i]=0;
                        dcol++;
                        }
                    else{
                        strcpy(labeldata[ldcol][i],field);
                        ldcol++;
                        }

		    }
		else{
                    if(readline[col]){
			missingvalue[dcol][i]=1;
			dcol++;
		        }
		}
		ip = ep + 1;
	    } while(ep);
	i++;
	*numpts = i;
	}
}
