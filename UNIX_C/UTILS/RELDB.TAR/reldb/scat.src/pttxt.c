#include <stdio.h>
#include "defs.h"
extern int debuglevel;
extern double spacekonst;

plot_texts(header,xlabel,ylabel,wxmin,wxmax,wymin,wymax,xmin,ymin,ymax)
char	*header;		/* figure caption */
char	*xlabel;		/* label for x axis */
char	*ylabel;		/* --------- y ---- */
double	xmin;		/* min of all x-values */
double	ymin,ymax;		/* min of all y-values */
double	wxmin,wxmax,wymin,wymax;/* window bounds */
{
	int outx, outy;
	
	if(debuglevel)fprintf(stderr,"In plot_texts\n");

	transf_data(wxmin,wymin,wxmax,wymax,(wxmin+wxmax)/2.,(wymax+ymax)/2.,&outx,&outy);
	labelplace("c");
	text(outx,outy,header);

	transf_data(wxmin,wymin,wxmax,wymax,(wxmin+wxmax)/2.,(wymin+ymin)/2.,&outx,&outy);
	labelplace("u");
	text(outx,outy,xlabel);

/*	transf_data(wxmin,wymin,wxmax,wymax,(wxmin+wxmin+wxmin+wxmin+xmin)/5.,(wymin+wymax)/2.,&outx,&outy);
*/
	transf_data(wxmin,wymin,wxmax,wymax,(wxmin+wxmin+xmin)/3.,(wymin+wymax)/2.,&outx,&outy);
	labelrotation(90);
	labelplace("o");
	text(outx,outy,ylabel);
	labelrotation(0);
}
