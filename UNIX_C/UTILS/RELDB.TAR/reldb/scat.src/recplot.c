/* recplot.c -- some general routines for plotting 

Currently this is quite poor - only rectangle and text.
Someone should add higher-level routines, but of course these
can only be allowed to call the plot(3)-library (possibly with
extensions, which should then be placed in extplotlib.c, and
device-specific versions should be placed in the device-specific filters
(such as the enclosed hpglplot.c and xplot.c)

*/
#include <stdio.h>
extern int debuglevel;
extern int extended_plot;


rectangle(x,y,u,w)
int x,y,u,w;
{
	move(x,y);
	cont(x,w);
	cont(u,w);
	cont(u,y);
	cont(x,y);
}
text(x,y,labl)
int x,y;
char *labl;
{
	move(x,y);
	label(labl);
}
