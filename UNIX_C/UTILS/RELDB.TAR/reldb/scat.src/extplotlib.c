/* extplotlib.c -- extensions to the plot-library
                   these routine generate plot(5) output
                   When linking directly to a device library (e.g. hpglplot.o),
                   which has the device-dependent version of
		   these routines, this should not be included.
*/
#include <stdio.h>
extern int debuglevel;
extern int extended_plot;


labelrotation(x)
int x;
{
	if(extended_plot){
		if (x == 90)
			printf("r v\n");  	/* vertical */
		else
			printf("r h\n");	/* horizontal */
	}
}
labelplace(s)
char *s;
{
	if(extended_plot){
		printf("u %s\n",s);
	}
}
selectcolor(x)
int x;
{
	if(extended_plot){
		printf("z %d\n",x);
	}
}

