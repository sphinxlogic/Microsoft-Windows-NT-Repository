#include <stdio.h>

#define MAXPTS	1500	/* max no of data points (lines in file) */
#define MAXCOLS	25	/* max no of data columns */
#define MAXTXT	100	/* max length of name of column */
