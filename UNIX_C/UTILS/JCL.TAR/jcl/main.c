#include <stdio.h>
#include "yaccun.h"

YYSTYPE yylval,yyval;
int verbose = 0;

main(ac,av)
int ac;
char *av[];
{
   if(ac > 1) {
      sscanf(av[1],"-v=%d",&verbose);
   }

   while(yyparse());
}
