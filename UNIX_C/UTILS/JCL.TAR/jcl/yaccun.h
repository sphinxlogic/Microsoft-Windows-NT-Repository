/*
 * these are the typedefs for the yacc union 
 */
#define CHARMAX 80			/* maximum size of word */

typedef union {				/* union for yacc variable stack */
   char charval[CHARMAX];
   int intval;
} YYSTYPE;

extern YYSTYPE yyval,yylval;
