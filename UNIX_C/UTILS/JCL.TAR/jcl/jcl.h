/*
 * Parameters defined for the `scheduler'
 */
#define PSIZE 60			/* size of parm */
#define UNKNOWN 0			/* DISP parameters */
#define DELETE 1
#define KEEP 2
#define NEW 3
#define OLD 4

extern char parm[];			/* parameters for EXEC */
extern FILE *msgout;			/* output from `scheduler' */
extern int msglevel1,			/* MSGLEVEL=(msglevel1,msglevel2) */
	   msglevel2;
