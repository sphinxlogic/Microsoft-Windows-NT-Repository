#include <stdio.h>

main()
{
  char word[257];
  static char prev[257]="";
  char outword[258];

  while (gets(word)!=NULL) {
    trunc(word,prev);
  }
exit(0);
}

trunc(word,prev) 
char *word;
char *prev;
{
  unsigned char same_count;
  char *wordp;
  char *prevp;

  wordp=word;
  prevp=prev;
  for (same_count=0;*wordp==*prevp++;++wordp,++same_count);
  if (same_count>255) {
    fprintf(stderr,"same count exceeded 255 characters, aborted");
    exit(1);
  }
  fwrite(&same_count,1,1,stdout);
  puts(wordp);
  strcpy(prev,word);
  return;
}

