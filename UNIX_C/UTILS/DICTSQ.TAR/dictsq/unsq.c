#include <stdio.h>

main()
{
  char word[257];
  static char prev[257]="";
  unsigned char count;
  char outword[258];

  while (!expand(word,prev)) {
    puts(word);
  }
exit(0);
}

expand(word,prev) 
char *word;
char *prev;
{
  unsigned char same_count;
  char *wordp;
  char *prevp;

  fread(&same_count,1,1,stdin);
  prevp=prev;
  wordp=word;
  while (same_count--)
    *wordp++=(*prevp++);
  if (gets(wordp)==NULL) return(1);
  strcpy(prev,word);
  return(0);
}

