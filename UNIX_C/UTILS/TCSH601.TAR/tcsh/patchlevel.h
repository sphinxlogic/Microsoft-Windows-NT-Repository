/* $Header: /home/hyperion/mu/christos/src/sys/tcsh-6.01/RCS/patchlevel.h,v 3.23 1991/12/19 21:40:06 christos Exp $ */
/*
 * patchlevel.h: Our life story.
 */
#ifndef _h_patchlevel
#define _h_patchlevel

#define ORIGIN "Cornell"
#define REV 6
#define VERS 1
#define PATCHLEVEL 0
#define DATE "12/19/91"

#endif /* _h_patchlevel */
