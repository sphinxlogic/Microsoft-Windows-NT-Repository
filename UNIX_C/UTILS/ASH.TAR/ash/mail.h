#ifdef __STDC__
void chkmail(int);
#else
void chkmail();
#endif
