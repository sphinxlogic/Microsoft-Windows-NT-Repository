#!/bin/sh
while true
  do
    starsunv -u
  done
