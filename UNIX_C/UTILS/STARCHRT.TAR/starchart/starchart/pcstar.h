#define CONSTFILE "./cons.loc"
#define RCFILE "./star.rc"
