char *_bbfile = "prof.out";
