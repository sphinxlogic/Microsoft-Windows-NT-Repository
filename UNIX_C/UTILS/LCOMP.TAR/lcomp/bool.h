/* bool.h -- boolean type */

typedef int bool;
#define	FALSE	0
#define	TRUE	1

#define	strbool(t)	((t) ? "TRUE" : "FALSE")
