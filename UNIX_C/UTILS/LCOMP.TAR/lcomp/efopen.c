/* efopen.c -- open stdio file, check for errors */

#include <stdio.h>

extern char *progname;

FILE *efopen(file, mode)
	char *file, *mode;
{
	FILE *fp = fopen(file, mode);
	if (fp == NULL) {
		fprintf(stderr, "%s: can't open file %s, mode %s\n",
			progname, file, mode);
		exit(1);
	}
	return fp;
}
