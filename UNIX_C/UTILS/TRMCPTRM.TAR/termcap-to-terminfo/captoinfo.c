/*
 * captoinfo:
 *	Translate termcap terminal database to terminfo source
 *	format.
 *
 *	Captoinfo reads standard input, which is assumed to be
 *	a termcap file and writes the equivalent to standard
 *	output in terminfo source format.
 *
 * This code is copyrighted and may not be sold without due compensation
 * to both Georgia Tech and myself.  Since I refuse to go through all the
 * legal hassles involved, good luck.  Oh yeah... don't remove this
 * paragraph either.
 *
 * Robert Viduya - Georgia Institute of Technology.
 *
 *	{gitpyr,gt-oscar,gt-felix}!robert
 */
#include <stdio.h>

#define	bool	char
#define	TRUE	1
#define	FALSE	0

char    buffer[2048];


main ()
{
    int		c;

    while ((c = getchar ()) != EOF) {
	if (c == '#') {
	    (void) putchar (c);
	    do {
		c = getchar ();
		(void) putchar (c);
	    } while (c != '\n');
	}
	else {
	    if (ungetc (c, stdin) == EOF) {
		fprintf (stderr, "ungetc failed.\n");
		exit (1);
	    }
	    get_termcap ();
	    print_name ();
	    print_bools ();
	    print_nums ();
	    print_strs ();
	}
    }
    exit (0);
}
