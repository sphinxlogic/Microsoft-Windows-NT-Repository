/*
 * chemtab - a periodic table data base 1990 Jim King (pulsar@lsrhs)
 *
 * tune.h	Site Specifics
 */

/* PRINTER is the printer program or shell script you use to print on
   the desired printer for Chemtab output.  Preferably, when using lpr,
   you want to add the '-h' function to skip the header page. */
#define PRINTER		"/usr/local/bin/letter -h"

/* PERTABLE is the path up to and including the list of elements, elist */
#define PERTABLE	"/usr/local/lib/chemtab/elist"

/* MAXLM is the number of elements in PERTABLE + 1 */
#define MAXLM		108

/* TABLE is the path up to and including the periodic table outline, pertab */
#define TABLE		"/usr/local/lib/chemtab/pertab"

/* TRANSCRIPT is the path to the logfile which lists who uses the program.
              if it is not defined, then no log is made. */
#define TRANSCRIPT	"/usr/local/lib/chemtab/logfile"
