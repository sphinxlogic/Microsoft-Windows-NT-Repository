/*
 * chemtab - a periodic table data base (C) 1990 by Jim King (pulsar@lsrhs)
 *
 * graph.h	Contains stuff for graphing
 */

#include "undefs.h"

float	xmax,		/* X axis maximum value */
	xmin,		/* X axis minimum value */
	ymax,		/* Y axis maximum value */
	ymin,		/* Y axis minimum value */
	scale,		/* used to determine spots */
	xaxis[70],	/* each spot on x axis is given a defined number */
	yaxis[21];	/* each spot on y axis is given a defined number */
char	c1,		/* letter of choice, x axis */
	c2;		/* letter of choice, y axis */
int	xspot,		/* x axis line to plot on */
	yspot;		/* y axis line to plot on */

char	*gname[] = {	/* Top line, 'x' vs. 'y' */
	0,"Atomic Number","Atomic Mass","Melting Temp.","Boiling Temp.",
	"Ionization energy","Electronegativity","Specific Heat",
	"Density","Atomic Radius","Discovery Year",0
};
