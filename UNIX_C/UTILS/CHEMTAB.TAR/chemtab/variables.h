/*
 * chemtab - a periodic table data base (C) 1990 Jim King (pulsar@lsrhs)
 *
 * variables.h	Include file - basically a global file
 */

#include <stdio.h>
#include "tune.h"

int	hlp;					/* Help flag */

int	trans;		/* Puts lists, graphs, and table in file for print */

FILE	*fp;		/* File pointer for the above flag */

int	sub1[MAXLM], gtot;		/* sorted elements stored here */

char	foo[160], str[80];		/* Random input */

char	lnm[80];			/* User's last name for transcript */

int	i, j, k;			/* Random ints */

float	x;				/* Random floater */

struct dung {				/* Sorting structure */
	int	wch,
		sgn;
	float	amt;
} dosort[3];

static char	*mopts[] = {		/* Main menu options */
	0,
	"List information regarding one element",
	"Choose element's characteristics",
	"List information on all selected elements",
	"View periodic table showing positions of selected elements",
	"Use the graphing module",
	"Save your transcripts, Print them, and Quit",
	0
};

static struct op {
	char	chst[30],
		upline[20],
		dnline[20];
	int	dnum;
} sopts[] = {			/* Selecting options */
	"0",			"0",		"0",		0,
	"Atomic Number",	"Greater Than",	"Less Than",	0,
	"Atomic Mass",		"Greater Than",	"Less Than",	0,
	"Family (going up-dn)",	"Greater Than",	"Less Than",	0,
	"Row (going left-rt)",	"Greater Than",	"Less Than",	0,
	"Valence Electrons",	"More Than",	"Less Than",	0,
	"Melting Temperature",	"Greater Than",	"Less Than",	0,
	"Boiling Temperature",	"Greater Than",	"Less Than",	0,
	"Ionization Energy",	"Greater Than",	"Less Than",	0,
	"Discovery Year",	"After",	"Before",	0,
	"Electronegativity",	"Greater Than",	"Less Than",	1,
	"Specific Heat",	"Greater Than",	"Less Than",	2,
	"Density",		"Greater Than",	"Less Than",	2,
	"Atomic Radius",	"Greater Than",	"Smaller Than",	2,
	"Return to Main Menu",	"0",		"0",		0,
	"Clear ALL Characteristics",	"0",	"0",		0,
	"0",			"0",		"0",		0
};

#define	EQUAL	0		/* Constants */
#define GREATER	1
#define LESS	2
#define	CLOSE	3

int	sort_list[MAXLM];			/* Sort final list */
