/*
 * chemtab - a periodic table data base 1990 Jim King (puslar@lsrhs)
 *
 * undefs.h - carries all the numbers for undefined vars throughout
 */

static int	VAL = 9,
		MEL = -273,
		BOI = -273,
		FIO = -1,
		YEA = -1;
static float	ENG = -1.5,
		SPHT = -1.5,
		DENS = -1.5,
		ARD = -1.5;
	
/* Close values */
static float	close[15] = {
	0.00, 5.00, 10.00, 1.00, 1.00, 1.00, 100.00, 100.00, 25.00, 50.00,
	0.20, 0.05, 0.20, 0.05, 0.00
};
