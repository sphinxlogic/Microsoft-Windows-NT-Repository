header2()
{
char outline[80];
outline[0]=0;
insertx("signal",outline,1);
insertx("pin",outline,14);
insertx("inner wire",outline,18);
insertx("outer wire",outline,39);
printf("%s\n",outline);
outline[0]=0;
insertx("name ",outline,1);
insertx("num",outline,14);
printf("%s\n",outline);
}
