/*******************************************
* initialize - initialize global variables *
*******************************************/

#include "wirewrap.h"

initialize()
{
chipleader = 0;
siglistleader = 0;
nextfree = 0;
linenum = 67;
inputline=1;
}
