/*
** namecmp2 - compare two names.  Works like strcmp()
**            This is the same as namecmp except that
**	      namecmp2 ignores case.
*/
#include "wirewrap.h"
namecmp2(a,b)
char a[NAMELENGTH],b[NAMELENGTH];
{
int i;
for(i=0;i<NAMELENGTH;i++)
  {
  if(tolower(a[i])<tolower(b[i]))return(-1);
  else if (tolower(a[i])>tolower(b[i]))return(1);
  }
return(0);
}
