#include "wirewrap.h"

mywrite(outline)
char *outline;
{
if(linenum > 60)
  {
  printf("");
  header1();
  linenum=3;
  }
  printf("%s\n",outline);
  linenum++;
}
