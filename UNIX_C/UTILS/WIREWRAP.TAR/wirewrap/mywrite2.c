#include "wirewrap.h"

mywrite2(outline)
char *outline;
{
if(linenum > 60)
  {
  printf("");
  header2();
  linenum=3;
  }
  printf("%s\n",outline);
  linenum++;
}
