/*
** namecmp - compare two names.  Works like strcmp()
*/
#include "wirewrap.h"
namecmp(a,b)
char a[NAMELENGTH],b[NAMELENGTH];
{
int i;
for(i=0;i<NAMELENGTH;i++)
  {
  if(a[i]<b[i])return(-1);
  else if (a[i]>b[i])return(1);
  }
return(0);
}
