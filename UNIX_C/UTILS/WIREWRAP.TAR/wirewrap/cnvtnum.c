#include <ctype.h>
char *cnvtnump; /* Pointer to next character to process. */
int cnvtnumv;   /* 1 if valid number, 0 otherwise. */
/*************************************/
/*  cnvtnum - convert ascii to int.  */
/*  Works like atoi() except that it */
/*  leaves the externel variables set*/
/*  to help in error recovery.       */
/*************************************/
cnvtnum(str)
char *str;
{
int sign=1;
int result=0;
cnvtnump = str;
cnvtnumv=0;

/* Skip leading blanks. */

while(*cnvtnump == ' ' || *cnvtnump == '\t')cnvtnump++;

/* Pick up leading sign. */

if(*cnvtnump == '+')
  {
  sign = 1;
  *cnvtnump++;
  }
else if(*cnvtnump == '-')
  {
  sign = -1;
  *cnvtnump++;
  }

/* Pick up digits. */

while(isdigit(*cnvtnump))
  {
  result=10*result+ (*cnvtnump-'0');
  cnvtnump++;
  cnvtnumv=1;
  }

return(sign*result);
}
