insertx(from,to,pos)
char *from, *to;
int pos;
{
char *p;
int l;

/* Pad with trailing blanks. */

l=strlen(to);
while(l<(pos-1))
  {
  to[l]=' ';
  l++;
  }
to[l]=0;

/* Append the from string to the to string. */

l=pos-1;
for(p=from; *p != 0; p++)
  {
  to[l] = *p;
  l++;
  }
to[l]=0;
}
