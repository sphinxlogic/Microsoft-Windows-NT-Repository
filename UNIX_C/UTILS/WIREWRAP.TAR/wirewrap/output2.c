#include "wirewrap.h"

output2()
{
int oldrow,oldcol,runflag,count,already,specialsig;
int innerptr,innerwrap,outerptr,outerwrap;
char tempstr[80],outline[80];
double wlength,getwirelength();
printf("");
header2();
oldrow = -100;
oldcol = -100;
linenum = 3;
runflag = 0;
for(count=0;count<nextfree;count++)
  {
  outline[0]=0;
  if((pinarray[count].row == oldrow) &&
   (pinarray[count].col == (oldcol + 1)))
    runflag = 1;
  else
    {
    if(runflag != 0)
      {
      mywrite2(" ");
      runflag=0;
      }
    }
  oldrow = pinarray[count].row;
  oldcol = pinarray[count].col;

  /* SET UP THE SIGNAL NAME AND PIN NUMBER */

  insertname(pinarray[count].signalname->signalname,outline,1);
  sprintf(tempstr,"%d",pinarray[count].pinnum);
  insertx(tempstr,outline,14);

  /* FIGURE SOME STUFF OUT FOR THE INNER WRAP */

  innerptr = pinarray[count].inner;
  innerwrap = (pinarray[count].inner != -1);
  if(innerwrap)
    already = (pinarray[count].inner < count);
  else
    already = 0;
  specialsig = pinarray[count].signalname->special;

  /* SET UP LENGTH OF INNER WIRE */

  if(specialsig)
    insertx("SPEC",outline,18);
  if(already && (! specialsig))
    insertx("TEST",outline,18);
  if(innerwrap && (! already) && (! specialsig))
    {
    wlength=getwirelength(pinarray[count].row,pinarray[count].col,
                  pinarray[innerptr].row,pinarray[innerptr].col);
    wlength = (double) ( (int) (wlength * 10) ) / 10;
    sprintf(tempstr,"%.1f",wlength);
    insertx(tempstr,outline,18);
    }

  /* SET UP ROW1 AND COL1 */

  sprintf(tempstr,"%d",pinarray[count].row);
  insertx(tempstr,outline,23);
  insertx(",",outline,strlen(outline)+1);
  sprintf(tempstr,"%d",pinarray[count].col);
  insertx(tempstr,outline,strlen(outline)+1);

  /* SET UP ROW2 AND COL2 */

  if((!specialsig) && innerwrap)
    {
    insertx(" ",outline,strlen(outline)+1);
    sprintf(tempstr,"%d",pinarray[innerptr].row);
    insertx(tempstr,outline,strlen(outline)+1);
    insertx(",",outline,strlen(outline)+1);
    sprintf(tempstr,"%d",pinarray[innerptr].col);
    insertx(tempstr,outline,strlen(outline)+1);
    }

  /* FIGURE SOME STUFF OUT FOR THE OUTER WRAP */

  outerptr = pinarray[count].outer;
  outerwrap =(pinarray[count].outer != -1);
  if(outerwrap)
    already=(pinarray[count].outer < count);
  else
    already=0;
  specialsig = pinarray[count].signalname->special;

  /* SET UP LENGTH OF OUTER WIRE */

  if(specialsig)
    insertx("SPEC",outline,39);
  if(already && (!specialsig))
    insertx("TEST",outline,39);
  if(outerwrap && (!already) && (!specialsig))
    {
    wlength=getwirelength(pinarray[count].row,pinarray[count].col,
                  pinarray[outerptr].row,pinarray[outerptr].col);
    wlength = (double) ( (int) (wlength * 10) ) / 10;
    sprintf(tempstr,"%.1f",wlength);
    insertx(tempstr,outline,39);
    }

  /* SET UP ROW1 AND COL1 */

  sprintf(tempstr,"%d",pinarray[count].row);
  insertx(tempstr,outline,44);
  insertx(",",outline,strlen(outline)+1);
  sprintf(tempstr,"%d",pinarray[count].col);
  insertx(tempstr,outline,strlen(outline)+1);

  /* SET UP ROW2 AND COL2 */

  if((!specialsig) && outerwrap)
    {
    insertx(" ",outline,strlen(outline)+1);
    sprintf(tempstr,"%d",pinarray[outerptr].row);
    insertx(tempstr,outline,strlen(outline)+1);
    insertx(",",outline,strlen(outline)+1);
    sprintf(tempstr,"%d",pinarray[outerptr].col);
    insertx(tempstr,outline,strlen(outline)+1);
    }

  /* SET UP EMPTY/FULL FLAG */

  if((!specialsig) && outerwrap)
    {
    insertx(" ",outline,strlen(outline)+1);
    if(pinarray[outerptr].inner == -1)
      insertx("E",outline,strlen(outline)+1);
    else
      insertx("F",outline,strlen(outline)+1);
    }
  mywrite2(outline);
  }
}
