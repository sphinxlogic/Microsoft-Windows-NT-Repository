#define sqr(a) ( (a)*(a) )
#include <math.h>
#include "wirewrap.h"
double getwirelength(row1,col1,row2,col2)
int row1,col1,row2,col2;
{
double wlength;

/* Compute straight line distance. */

wlength = .1 * sqrt((double) sqr(row1-row2)+sqr(col1-col2));

/* Apply linear regression coefficients */

wlength = wlength * lengthfactor + pinpart;

/* Round up to the nearest larger .5 inch */

wlength = wlength * 2 + 1;
wlength = (int) wlength;
wlength = wlength/2.0;

/* Make sure that it is at least as long as the minimum length. */

if(wlength < minlength) wlength = minlength;
return(wlength);
}
