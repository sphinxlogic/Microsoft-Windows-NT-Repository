#include "wirewrap.h"
main()
{
initialize();
readin();	/* Read the input file. */

#ifdef DEBUG
  printf("Dump of pin array after inputting data\n");
  test();
#endif

sort1();                 /* Sort by signal name. */

#ifdef DEBUG
  printf("Dump of pin array after sort by signal name\n");
  test();
#endif

getwired();              /* Wire the pins togther. */

#ifdef DEBUG
  printf("Dump of pin array after doing the wiring.\n");
  test();
#endif

output1();              /* Output the first printout. (Chip side view) */

sort2();                /* Sort by (row,col). */

#ifdef DEBUG
  printf("Dump of pin array after sorting by (row,col)\n");
  test();
#endif

output2();             /* Output the second printout. (Pin side view) */

output3();             /* Output the third printout. (Wire lengths) */
}
