/***********************************************************
*  setptr - Converts from a signal name to a pointer	   *
*           to an entry in the signallist.  If the	   *
*           signal name isn't already in the signallist,   *
*           then an entry for it is added.	           *
***********************************************************/

#include "wirewrap.h"

struct signallist *setptr(signalname)
char *signalname;
{
int i;
struct signallist *localptr;

localptr = siglistleader;
while (localptr != 0)
  {
  if(namecmp(localptr->signalname,signalname))
    localptr = localptr->succ;
  else
    break;
  }
if(localptr==0)
  {
  localptr=(struct signallist *)malloc(sizeof(struct signallist));
  for(i=0;i<12;i++)localptr->signalname[i]=signalname[i];
  localptr->succ = siglistleader;
  localptr->special = 0;
  siglistleader = localptr;
  }
 return(localptr);
}
