#include "wirewrap.h"
output1()
{
char currentsig[12],outline[80], sig[12], wrap, newstring[80];
int count, i;

currentsig[0] = 0;
count = 0;
outline[0] = 0;
while(count < nextfree)
  {
  for(i=0;i<12;i++)sig[i] = pinarray[count].signalname->signalname[i];
  if(namecmp(sig,currentsig))
    {
    insertname(sig,outline,1);
    if((pinarray[count].signalname->special) != 0)
      insertx("Special",outline,2+NAMELENGTH);
    mywrite(outline);
    outline[0]=0;
    for(i=0;i<12;i++)currentsig[i]=sig[i];
    wrap='T';
    }
  if(wrap == 'T')wrap='B'; else wrap='T';
  newstring[0]=0;
  insertname(pinarray[count].mychip->name,outline,10);
  sprintf(newstring,"%d",pinarray[count].pinnum);
  insertx(newstring,outline,12+NAMELENGTH);
  insertname(pinarray[count].mychip->position,outline,17+NAMELENGTH);
  sprintf(newstring,"(%d,%d)",pinarray[count].row, pinarray[count].col);
  insertx(newstring,outline,30+NAMELENGTH);
  if(namecmp(sig,NULLSIGNAL) && (!pinarray[count].signalname->special))
    insertx(wrap,outline,39+NAMELENGTH);
  mywrite(outline);
  outline[0] = 0;
  count++;
  }
}
