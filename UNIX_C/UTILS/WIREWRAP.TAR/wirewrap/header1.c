header1()
{
char outline[80];

outline[0]=0;
insertx("chip",outline,10);
insertx("pin",outline,23);
insertx("chip",outline,28);
printf("%s\n",outline);
outline[0]=0;
insertx("name",outline,10);
insertx("num",outline,23);
insertx("position",outline,28);
insertx("row col",outline,42);
printf("%s\n",outline);
}
