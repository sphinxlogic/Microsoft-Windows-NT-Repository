#include "wirewrap.h"
#ifdef DEBUG

test()
{
int i;
for(i=0; i<nextfree;i++)
  {
  printf("Printing pin %d\n",i);
  printf(" Location: (%d,%d) Inner: %d Outer: %d %s\n",pinarray[i].row,
         pinarray[i].col, pinarray[i].inner, pinarray[i].outer,
         pinarray[i].signalname->signalname);
  }
}
#endif
