static char * sccsid = "@(#)  limits.c  (v6.2 5/19/89)";

# include "strings.h"

# ifdef I_SPECIAL

#	ifdef sun
#		include <sys/exec.h>
#	endif sun
#	include <a.out.h>

get_limits (fd, first, last)
int fd;
LSEEK_TYPE * first, * last;
/*
 * Have a look into the input file open under fd.
 * If we think it is an object file, than get the start and
 * size of initialized data and set
 * *first : address where examination of file will start
 * *last  : first address which will not be examined.
 */
{
	register int i;
	struct exec e;
	LSEEK_TYPE l;

	*first = (LSEEK_TYPE)0;
	*last = (LSEEK_TYPE)(-1);
	if (lseek (fd, (LSEEK_TYPE)0, 0) != (LSEEK_TYPE)0) {
# ifdef DEBUG
		fprintf (prot, "Input not seekable\n");
# endif
		return;
	}
	i = read (fd, (char*)(&e), sizeof (e));
	if (i != sizeof(e)) {
# ifdef DEBUG
		fprintf (prot, "file too small\n");
# endif
		return;
	}
	if (N_BADMAG(e)) {
# ifdef DEBUG
		fprintf (prot, "bad magic\n");
# endif
		return;
	}
	l = N_TXTOFF(e) + e.a_text;
# ifdef DEBUG
	fprintf (prot, "start of initialized data at %ld\n", (long)i);
	fprintf (prot, "length = %1ld\n", (long)(e.a_data));
# endif
	*first = l;
	*last = l + e.a_data;
}

# endif I_SPECIAL
