/*
 * Copyright (C) 1989 by Kenneth Almquist.  All rights reserved.
 * This file is part of atty, which is distributed under the terms specified
 * by the Atty General Public License.  See the file named LICENSE.
 */

struct tty {			/* structure containing terminal modes */
      int ldisc;		/* line discipline */
      struct sgttyb sgtty;	/* stty modes */
      int lmode;		/* local mode */
      struct tchars tchars;	/* special characters */
      struct ltchars ltchars;	/* more special characters */
      /* window size omitted */
};
