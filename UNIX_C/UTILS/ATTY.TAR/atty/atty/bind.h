/*
 * Copyright (C) 1989 by Kenneth Almquist.  All rights reserved.
 * This file is part of atty, which is distributed under the terms specified
 * by the Atty General Public License.  See the file named LICENSE.
 */

#define BINDMAGIC 300		/* magic number at start of .bindc file */

#define C_FUNC 0		/* start of functions */
#define C_PFXTBL 1		/* prefix table */
#define C_INSERT 2		/* insert string */
#define C_UNDEF 3		/* not defined */

#define NSYNTAX 3		/* number of syntax classes */
