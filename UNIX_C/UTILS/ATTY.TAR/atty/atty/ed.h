/*
 * Stuff shared between ed.c and update.c.
 *
 * Copyright (C) 1989 by Kenneth Almquist.  All rights reserved.
 * This file is part of atty, which is distributed under the terms specified
 * by the Atty General Public License.  See the file named LICENSE.
 */

extern char curline[MAXLLEN+1];	/* line being edited */
extern char *point;		/* cursor location within line */
extern char *endcurline;	/* end of current line */
extern int needbeep;		/* set to request beep */
extern char editprompt;		/* prompt for recursive edit */


#ifdef __STDC__
void gettermcap(void);
void movetoend(void);
#else
void gettermcap();
void movetoend();
#endif
