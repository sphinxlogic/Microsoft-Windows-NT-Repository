/************************************************************************\
*                                                                        *
*  GS: A Generalized, stochastic petri net Simulator                     *
*      V0.01      March 1989      Andreas Nowatzyk (agn@unh.cs.cmu.edu)  *
*      Carnegie-Mellon Univerity, School of Computer Science             *
*      Schenley Park, Pittsburgh, PA 15213                               *
*                                                                        *
\************************************************************************/

/* GSPN simulator, main part:
 *
 * This module has only the net-specific componnets:
 *    - the place-structures
 *    - the transition structures
 *    - the fire-functions
 *    - all statically allocated storrage
 *
 */

#include <stdio.h>
#define mainpgm
#include "gs.h"
#include "sim.h"

unsigned long n_places	    = N_PLACES;		/* pass size info to other modules */
unsigned long n_transitions = N_TRANSITIONS;
unsigned long n_results	    = N_RESULTS;
unsigned long n_parameters  = N_PARAMETERS;

struct transition *TBUF[N_TRANSITIONS];
