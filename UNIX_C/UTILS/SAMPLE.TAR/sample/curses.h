#ifndef TC_H

#include <stdio.h>

#define	addch(c) putchar(c)
#define	addstr(s) fputs(s, stdout)
#define	printw printf
#define	getch() getchar()
#define	getstr(s) gets(s)

extern	int 	LINES;    /* number of lines in display */
extern	int 	COLS;     /* number of columns in display */

#define TC_H
#endif
