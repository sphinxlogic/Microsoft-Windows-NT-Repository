/*
  tps.c -- Tree-structured ps program. It works by reading in the output
  of a 'ps' command and reordering it so that the parent-son relation-
  ships of the processes are displayed.

  The maximum width of the terminal is honored. Link with -ltermcap
  (or -ltermlib).

  Author: Arndt Jonasson, Zyx.
*/

/*
  Do error checking in various placesf (sscanf, malloc..)
  Fix vararg for pfield.

  Foo! Linking curses adds 60K to the code size.

  New ideas:
   Make 'tps -u root' only show root-owned processes.
   -p pid: show only the subtree with the pid p in it.
*/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <pwd.h>

#include "options.h"

extern char *getenv ();
extern struct passwd *getpwuid ();

#ifdef hpux
#define MAX_PROC	200
#define PS_COM		"ps -efl"
#else
#ifdef apollo
#define MAX_PROC	200
#define PS_COM		"ps -ef"
#else
#ifdef pyr
#define MAX_PROC	536
#define PS_COM		"ps -agxlw"
#else
#define MAX_PROC	100
#define PS_COM		"ps -agxlw"
#endif
#endif
#endif

#define LEFT	1
#define RIGHT	2
#define CENTER	4
#define LAST	8

#define LINMAX	400

#ifdef hpux

#if 0
#define OWNER	0
#define PID	9
#define PPID	15
#define JUNK1	21
#define TTY	33
#define JUNK2	(TTY+8)
#define CPU	41
#define INFO	47
#else
#define OWNER	6
#define PID	14
#define PPID	20
#define JUNK1	26
#define WAITCH	47
#define TTY	65
#define JUNK2	(TTY+8)
#define CPU	73
#define INFO	79
#endif

#else

#ifdef apollo
#define OWNER	0
#define PID	9
#define PPID	15
#define JUNK1	21
#define TTY	33
#define JUNK2	(TTY+9)
#define CPU	42
#define INFO	48
#else

#ifdef ultrix
#define OWNER	0
#define PID	4
#define PPID	10
#define JUNK1	16
#define INFO	60
#define TTY	50
#define CPU	54
#define JUNK2	54
#else

#ifdef sun
#define OWNER	7
#define PID	12
#define PPID	18
#define JUNK1	24
#define INFO	70
#define TTY	61
#define CPU	65
#define JUNK2	65
#else

#define OWNER	7
#define PID	12
#define PPID	18
#define JUNK1	24
#ifdef pyr
#define INFO	73
#define TTY	63
#define JUNK2	(TTY+4)
#else
#ifdef sony
#define INFO	75
#define TTY	65
#define JUNK2	(TTY+4)
#define CPU	69
#else
#define INFO	69
#define TTY	60
#define JUNK2	(TTY+4)
#endif
#endif
#endif
#endif
#endif
#endif

struct process
{
   int pid, ppid;
   char *owner, *info, *tty;
   int printed;
   int cputime;
   long channel;
};

struct process *proc[MAX_PROC];
int maxproc = 0;

int hmax, hpos;
int maxlevel = 0;
int show_tty = 0;
int indentation = 2;
int show_all = 0;
int cpu_diff = 0;
char *my_name = 0;

#ifdef WAITCH
typedef struct
{
   long adr;
   char name[20];
} Symbol;

int show_waitchan = 0;
Symbol *table;
int symbol_n;
#endif

char *newstr (str)
char *str;
{
   char *cp;
   while (*str++ == ' ');
   str--;
   cp = (char *) malloc (strlen (str) + 1);
   strcpy (cp, str);
   return cp;
}

newline ()
{
   hpos = 0;
   printf ("\n");
}

#ifdef WAITCH
Symbol *lookup (adr)
long adr;
{
   int i1 = 0, i2 = symbol_n;
   int i;

   for (;;)
   {
      i = (i1 + i2) / 2;
      if (table[i].adr == adr)
	 return &table[i];
      else if (table[i].adr > adr)
	 i2 = i;
      else
	 i1 = i;
      if (i1 > i2 - 2)
	 break;
   }
   if (table[i].adr > adr)
      i -= 1;
   return &table[i];
}

slurp_channel_data ()
{
   int d;
   struct stat s_buf;

   maybe_rebuild_tps_data ();

   d = open ("/tmp/tps_data", O_RDONLY);
   fstat (d, &s_buf);
   table = (Symbol *) malloc (s_buf.st_size);
   read (d, table, s_buf.st_size);
   symbol_n = s_buf.st_size / sizeof (Symbol);
}

char *addr_to_name (a)
long a;
{
   static char buf[80];
   long diff;
   Symbol *sym;

   if (a == 0)
      return "";

   sym = lookup (a);

   if (sym == &table[symbol_n - 1])
      return "?";

   diff = a - sym->adr;
   if (diff > 0x100000)
      return "?";

   if (diff == 0)
      sprintf (buf, "%s", sym->name);
   else
      sprintf (buf, "%s+%#x", sym->name, diff);

   if (buf[0] == '_')
      return buf+1;
   else
      return buf;
}

maybe_rebuild_tps_data ()
{
   int s;
   FILE *fi, *fo;
   char buf[80];
   long adr;
   char type[5], name[80];
   Symbol block;
   struct stat b1, b2;

   s = stat ("/hp-ux", &b1);
   s = stat ("/tmp/tps_data", &b2);
   if (s == 0 && b1.st_mtime <= b2.st_mtime)
      return;

   fprintf (stderr, "Rebuilding kernel symbol table ...\n");

#ifdef hp9000s800
   s = system ("nm -vp /hp-ux >/tmp/tps_data_x");
#else
   s = system ("nm -n /hp-ux >/tmp/tps_data_x");
#endif
   fi = fopen ("/tmp/tps_data_x", "r");
   fo = fopen ("/tmp/tps_data", "w");

   for (;;)
   {
      fgets (buf, 80, fi);
      if (feof (fi))
	 break;
#ifdef hp9000s800
      sscanf (buf, "%x %s %s\n", &adr, type, name);
#else
      sscanf (buf, "0x%x %s %s\n", &adr, type, name);
#endif
      block.adr = adr;
      strcpy (block.name, name);
      fwrite ((char *) &block, sizeof (block), 1, fo);
   }
   fclose (fi);
   fclose (fo);
}
#endif /* WAITCH */

pfield (len, align, format, a1, a2, a3, a4, a5)
int len, align;
char *format;
{
   char *text;
   char buf[200];
   int l, i, pre, post, o_hpos;

   o_hpos = hpos;
   hpos += len;
   if (hpos > hmax)
   {
      len -= hpos - hmax;
      hpos = hmax;
   }

   sprintf (buf, format, a1, a2, a3, a4, a5);
   l = strlen (buf);

   if (align & LEFT)
   {
      pre = 0;
      post = len - l;
   }
   else if (align & RIGHT)
   {
      pre = len - l;
      post = 0;
   }
   else if (align & CENTER)
   {
      pre = len - l;
      post = pre >> 1;
      pre = pre - post;
   }

   text = buf;

   for (;;)
   {
      for (i = 0; i < pre; i++) putchar (' ');
      if (len < l)
      {
	 printf ("%.*s", len, text);
	 newline ();
	 for (i = 0; i < o_hpos - 2; i++) putchar (' ');
	 putchar ('+'); putchar (' ');
	 text += len;
	 l -= len;
      }
      else
      {
	 printf ("%.*s", l, text);
	 hpos = o_hpos + len;
	 break;
      }
   }

   if (!(align & LAST))
      for (i = 0; i < post; i++) putchar (' ');
}

int maxlev (n, level, me_above)
int n, level, me_above;
{
   int i;
   int pid = proc[n]->pid;
   int me_below = 0;

   if (level > maxlevel) maxlevel = level;

   if (strcmp (proc[n]->owner, my_name) == 0)
      me_above = 1;

   for (i = 0; i < maxproc; i++)
      if (proc[i]->ppid == pid && proc[i]->pid != 0)
      {
	 if (maxlev (i, level + 1, me_above))
	    me_below = 1;
      }

   me_above |= me_below;
   if (!me_above && !show_all)
      proc[n]->printed = 1;
   return me_above;
}

print_pp (n, level)
int n, level;
{
   int i;
   int pid = proc[n]->pid;

   if (proc[n]->printed) return;

   print_p (n, level);

   for (i = 0; i<maxproc; i++)
      if (proc[i]->ppid == pid)
	 print_pp (i, level+1);
}

#ifdef hpux
#define TTY_WIDTH	10
#else
#define TTY_WIDTH	5
#endif

print_p (n, level)
int n, level;
{
   proc[n]->printed = 1;

   pfield (indentation * maxlevel + 6,
	   LEFT,
	   "%*.*s%d",
	   indentation * level,
	   indentation * level,
	   " ",
	   proc[n]->pid);
   pfield (7, LEFT, "%s", proc[n]->owner);
   if (show_tty)
      pfield (TTY_WIDTH, LEFT, "%s", proc[n]->tty);
#ifdef WAITCH
   if (show_waitchan)
      pfield (25, LEFT, "%s ", addr_to_name (proc[n]->channel));
#endif
   if (cpu_diff > 0)
   {
      if (proc[n]->cputime < 0)
	 pfield (3, LEFT, "%d", -proc[n]->cputime);
      else
	 pfield (3, LEFT, "");
   }
   pfield (100, LEFT+LAST, "%s", proc[n]->info);
   newline ();
}

int to_seconds (str)
char *str;
{
   int min, sec, n;

   n = sscanf (str, "%d:%d", &min, &sec);
   if (n == 2)
      return 60*min+sec;
   else
      return atoi (str);
}

sort ()
{
   int i, j, k, pid;
   struct process *sav;

   for (i = 0; i<maxproc; i++)
   {
      pid = 100000;

      for (j = i; j<maxproc; j++)
      {
	 if (proc[j]->pid < pid)
	 {
	    k = j;
	    pid = proc[j]->pid;
	 }
      }
      sav = proc[i];
      proc[i] = proc[k];
      proc[k] = sav;
   }
}

#define warning(x, arg)		sprintf (wbuf, x, arg), warn (wbuf)

warn (msg)
char *msg;
{
   fprintf (stderr, "tps: %s, assuming width 80\n", msg);
}

int find_width ()
{
   char wbuf[200];
   char buffer[1024];
   char *name;
   int s;
   int width = 80;

   name = getenv ("TERM");
   if (name == 0)
      warning ("terminal type not set", 0);
   else
   {
      s = tgetent (buffer, name);
      switch (s)
      {
       case 1:
	 s = tgetnum ("co");
	 if (s == -1)
	    warning ("width not given for type \"%s\"", name);
	 else
	    width = s;
	 break;
       case -1:
	 warning ("can't access terminal database", 0);
	 break;
       case 0:
	 warning ("can't find type %s in the terminal database", name);
	 break;
       default:
	 warning ("weird return value from tgetent (%d)", s);
	 break;
      }
   }
   return width;
}

#ifdef ultrix
zap_flags (buf)
char *buf;
{
   char c;
   char *p=buf, *q;

   while (*p++ != ' ');
   q = buf;
   while ((c = *p++) != '\0')
      *q++ = c;
   *q = '\0';
}
#endif

main (argc, argv)
int argc;
char *argv[];
{
   FILE *f;
   char buf[LINMAX];
   struct process *p;
   int i, pid;

   static Option desc[] = {
      O_flg ('t', show_tty),
      O_flg ('a', show_all),
#ifdef WAITCH
      O_flg ('w', show_waitchan),
#endif
      O_int ('i', indentation),
      O_int ('c', cpu_diff),
      O_str ('u', my_name),
      O_directive ("remaining: 0"),
#ifdef WAITCH
      O_directive
	 ("usage: [-wat] [-u user] [-i indentation] [-c time]"),
#else
      O_directive
	 ("usage: [-at] [-u user] [-i indentation] [-c time]"),
#endif
      O_end,
   };

   O_parse_options (desc, argc, argv);

   if (indentation < 1)
      indentation = 1;

   if (my_name == 0)
      my_name = getenv ("LOGNAME");
   if (my_name == 0)
      my_name = getpwuid (getuid ())->pw_name;
   if (my_name == 0)
   {
      fprintf (stderr, "%s: couldn't obtain user name\n", O_programname);
      my_name = "";
   }
   else
      my_name = newstr (my_name);

   hpos = 0;
   hmax = find_width () - 1;

#ifdef WAITCH
   if (show_waitchan)
      slurp_channel_data ();
#endif

   sprintf (buf, "exec %s", PS_COM);
   f = popen (buf, "r");
   if (f == 0)
   {
      fprintf (stderr, "%s: couldn't run ps\n", O_programname);
      exit (1);
   }

   fgets (buf, LINMAX, f);

   for (;;)
   {
      fgets (buf, LINMAX, f);
      if (feof (f)) break;

#ifdef ultrix
      zap_flags (buf);
#endif

      buf[strlen (buf) - 1] = 0;

      buf[PID-1] = 0;
      buf[PPID-1] = 0;
      buf[JUNK1-1] = 0;
      buf[JUNK2-1] = 0;
#ifdef WAITCH
      buf[WAITCH+9] = 0;
#endif

      p = (struct process *) malloc (sizeof (struct process));
#ifdef hpux
      p->owner = newstr (&buf[OWNER]);
#else
#ifdef apollo
      p->owner = newstr (&buf[OWNER]);
#else
      {
	 int uid;
	 uid = atoi (&buf[OWNER]);
	 p->owner = newstr (getpwuid (uid)->pw_name);
      }
#endif
#endif
      p->pid = atoi (&buf[PID]);
      p->ppid = atoi (&buf[PPID]);

      p->tty = newstr(&buf[TTY]);
      if (*p->tty == '?')
	 *p->tty = '\0';

      p->info = newstr (&buf[INFO]);
      p->printed = 0;

#ifdef CPU
      p->cputime = to_seconds (&buf[CPU]);
#endif
#ifdef WAITCH
      if (sscanf (&buf[WAITCH], "%x", &p->channel) != 1)
	 p->channel = 0;
#endif

#if 0
      if (p->pid != 1 && p->ppid == 1 && strncmp(p->info, "/etc/init", 9) == 0)
 	  continue;
       else
 	  proc[maxproc++] = p;
#else
      proc[maxproc++] = p;
#endif       
   }
   pclose (f);

#ifdef CPU
   if (cpu_diff > 0)
   {
      sleep (cpu_diff);

      sprintf (buf, "exec %s", PS_COM);
      f = popen (buf, "r");
      if (f == 0)
      {
	 fprintf (stderr, "%s: couldn't run ps\n", O_programname);
	 exit (1);
      }

      fgets (buf, LINMAX, f);
      for (;;)
      {
	 fgets (buf, LINMAX, f);
	 if (feof (f)) break;
#ifdef ultrix
	 zap_flags (buf);
#endif
	 pid = atoi (&buf[PID]);
	 for (i = 0; i < maxproc; i++)
	    if (proc[i]->pid == pid)
	       proc[i]->cputime -= to_seconds (&buf[CPU]);
      }
      pclose (f);
   }
#endif

   sort ();
   (void) maxlev (0, 0, 0);

   for (i = 0; i < maxproc; i++)
      print_pp (i, 0);
   return 0;
}
