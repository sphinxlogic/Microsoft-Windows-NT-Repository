/*------------------------------------------------------------------------------

Title:	Prim's MST Algorithm for INTEL Hybercube Simulator 
File:	prim.h
Dscrp:	Header file for Cube Simulator program.
Author:	Felix E. Quevedo
Date:	Oct. 1989

------------------------------------------------------------------------------*/
#include <math.h>

#define HPID	1
#define NPID	2
#define HNODE	-1
#define HTYPE	10
#define NTYPE	20
#define NHTYPE	30
#define INF 	0x7fffffff
#define NN  	32

#define min(X,Y) X<Y?X:Y

lg2(x)
int x;
{
	int i, j;
	if(!x) return 0;
	for(i=x, j=0; i!=1; i=i>>1, j++);
	return j;
}

pw2(x)
int x;
{
	return 1<<x;
}
