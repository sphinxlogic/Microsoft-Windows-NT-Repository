/* max.h
 * CRCW Parallel Algorithm for Finding Maximum of a set of numbers.
 * Header file for source codes
 * Felix E. Quevedo
 * November 10, 1989.
 */

typedef
    struct {
		short flg,			/* sinchronization semaphore */
	          ij[15][2],	/* compare indexes */
	          lst[6];		/* lost vector */
		int vec[6],			/* data vector */
	        max;			/* maximum value */
    } SMSeg;




