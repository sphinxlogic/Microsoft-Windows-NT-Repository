/* ------------------------------------------------------------------------------
 * hih.c
 * Nice test program
 * Allocates SHM segment and sends messages to processors.
 * Felix E. Quevedo Stuva
 * Oct 11, 1989
 * --------------------------------------------------------------------------- */
main()
{
	int i,j, l, t, f;
	char txt[10];
	double *mt;

	printf("HOST: running\n");

	load("hi",-1);

	mt = (double*)crtshm(20*sizeof(double));

	printf("HOST: send message to 0\n");
	send(0, "Howdy!", 7, 1);

	j=mpdim()+1;
	printf("HOST: waiting message type %d\n", j);

	recv(&f, txt, 7, &t, j);

	printf("HOST: received msg type %d from %d\n", t, f);

	printf("Shared Memory content:\n");
	for(i=0; i<t-1; printf("%f ", mt[i++]));
	printf("\n");
}





