/* ------------------------------------------------------------------------------
 * hi.c
 * Nice test program
 * Uses SHM segment and sends messages to processor i+1.
 * Felix E. Quevedo Stuva
 * Oct 11, 1989
 * --------------------------------------------------------------------------- */
main()
{
	int i,j, l, t, f;
	char txt[50];
	double *mt;

	i=mynode();
	j=mpdim();
	printf("Hi there!, I'm NODE %d\n",i);

	recv(&f, txt, 7, &t, 0);
	printf("NODE %d: recv %s, len %d, type %d, from %d\n", i, txt, l, t, f);

	mt=(double*)attshm();
	mt[i]=i;
	printf("NODE %d: attached shm seg and update index %d\n",i, i);

	if((i+1)%j) {
		printf("NODE %d: sending to %d\n",i, (i+1)%j);
		send((i+1)%j, txt, 7, t+1);
	}

	printf("NODE %d: sending to the host!\n", i);
	if(send(-1, txt, 7, t+1)<0)
		printf("NODE %d, Message not delivered!\n", i);
	else
		printf("NODE %d, Message delivered!\n", i);
}
