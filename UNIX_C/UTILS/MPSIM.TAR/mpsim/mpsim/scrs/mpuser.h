#include <math.h>

#define lg2(X) X!=8?log((double)X)/log(2.):3.;
#define pw2(X) pow(2.,(double)X);
#define NIL -1
