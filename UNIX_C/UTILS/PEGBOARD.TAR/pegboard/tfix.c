/*
	tfix.c
*/

#include "peg.h"

/*
	Convert two longs representing a target hour and minute into seconds
	from the day boundary, and update the running count for that time.

*/
long fixhm( h, m )
long h;	/* Hours	*/
long m;	/* Minutes	*/
{
	extern struct tm today;
	extern long duback;

	while( m >= 60 )	{
		h += 1;
		m -= 60;
	}
	/*
		If the specified time has gone by assume invoker means tomorrow
	*/
	if(( today.tm_year == localtime( &duback )->tm_year )
	&& ( today.tm_yday == localtime( &duback )->tm_yday )
	&& ( today.tm_hour > h ))
		h += 24;

	dround( &duback );
	return(( duback += (( m * 60 ) + ( h * 3600 ))));
}

void dround( t )
long *t;
{
	while( (*t) % 3600 )	/* Round back to hour	*/
		(*t)--;
	while( localtime( t )->tm_hour )	/* Then to the day	*/
		(*t) -= 3600;
}

/*
	Convert 3 arguments (yy/mm/dd) into an offset in seconds from
	the current date, and update the running count.

	Bugs: Ignores leap seconds
*/
long fixymd( y, m, d )
long y;	/* Year	*/
long m;	/* Month	*/
long d;	/* Day	*/
{
	extern struct tm today;
	extern long duback;
	static int modays[] = { 31, 28, 31, 30,  31,  30,  31,  31,  30,  31,
		30,  31 };
	int i;

	/*
		Deal with months from 0-11 (caller passes 1-12), check against bounds.
	*/
	if( --m < 0 || m > 11 )
		specerr( "illegal month" );
	/*
		Check if date gone by
	*/
	if( y < today.tm_year
	|| ( y == today.tm_year && (( m == today.tm_mon && d < today.tm_mday ) ||
	   ( m < today.tm_mon))))
		specerr( "illegal date" );
	/*
		Check day against bounds
	*/
	if(((( ! ( y % 4 )) && ( y % 100 )) || ( ! ( y % 400 ))))
			modays[1] = 29;
	if( d < 0 || d > modays[m] )
			specerr( "illegal day" );
	/*
		Convert mm/yy for target year into tm_yday
	*/
	if((( ! ( y % 4 )) && ( y % 100 ))
	|| ( ! ( y % 400 )))
		modays[1] = 29;
	else
		modays[1] = 28;
	for( i = 0 ; i < m ; i++ )
		d += modays[i];
	d -= today.tm_yday + 1 ;

	/*
		Count number of leap years between next year and the
		target year.
	*/
	for( i = today.tm_year + 1 ; i < y ; i++ )	{
		if((( ! ( i % 4 )) && ( i % 100 )) || ( ! ( i % 400 )))
			++d;
	}
	/*
		Get the years offset
	*/
	y=(long)abs((int)( today.tm_year - y ));

	/*
		If this is a leap year and the target year is not this year
		then we need another day...
	*/
	if(((( ! ( today.tm_year % 4 )) &&
	( today.tm_year % 100 )) || ( ! ( today.tm_year % 400 ))) && y )
		++d;
	/*
		Convert it to days then seconds
	*/
	return( fixday((long)( y * 365 ) + d ));
}

/*
	Return some number of days converted to seconds, added to the
	running total in duback.

	Externals: duback
	Returns: duback
*/
long fixday( d )
long d;
{
	extern long duback;

	return( duback += ( d * 86400 ));
}

/*
	Check see if string starts with a valid month name.  Return
	0 if not,  1-12 if so.
*/
ismonth( s )
char *s;
{
	extern int eod;
	static char *months[] = { "jan", "feb", "mar", "apr", "may", "jun",
							  "jul", "aug", "sep", "oct", "nov", "dec", "" };
	int i;

	for( i = 0 ; *months[i] ; i++ )	{
		if( ! strncmp( s, months[i], 3 ))
			return( ++i );
	}
	return( 0 );
}

/*
	Check see if string starts with a valid day name.  Return
	-1 if not, day of week (0 = sun) if so.
*/
isday( s )
char * s;
{
	static char *days[] = { "sun", "mon", "tue", "wed", "thu",
		"fri", "sat", "" };
	int i;

	for( i = 0 ; *days[i] ; i++ )	{
		if( ! strncmp( s, days[i], 3 ))
			return( i );
	}
	return( -1 );
}

void copytime( t, n )
struct tm *t;
struct tm *n;
{
	n->tm_sec	= t->tm_sec;
	n->tm_min	= t->tm_min;
	n->tm_hour	= t->tm_hour;
	n->tm_mday	= t->tm_mday;
	n->tm_mon	= t->tm_mon;
	n->tm_year	= t->tm_year;
	n->tm_wday	= t->tm_wday;
	n->tm_yday	= t->tm_yday;
	n->tm_isdst	= t->tm_isdst;
#ifndef	BSD
	n->tm_tzadj	= t->tm_tzadj;
	strcpy( n->tm_name, t->tm_name );
#endif	/* BSD */
}

showtime( t )
long *t;
{
	printf( "%s", ctime( t ) );
}

