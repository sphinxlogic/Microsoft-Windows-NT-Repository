#include <stdio.h>
#include <string.h>
#include <pwd.h>
#include <time.h>
#include <signal.h>
#include <fcntl.h>
#include <ctype.h>
#include <errno.h>

#define HOMENV	"HOME"
#define PEGRCFN	".pegrc"
#define PBFNM	"pegboard"
#define RCFNAM	"/etc/default/peg"

#define PBDIR	"/usr/spool"
#define TMPLATE	"PEGCOPY.XXXXXX"
#define PEGBOARD	"/usr/spool/pegboard"
#define PEGLOCK	"/tmp/LCK.pegboard"
#define OKCS	\
 " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ +,~@0123456789"

typedef void int;

void	use	( );
void	copytime( );
void	dround	( );
void	faterr	( );
void	finit	( );
void	specerr	( );
char	*igets	( );
char	*lows	( );
char	*getenv	( );
char	*ttyname( );
char	*fixargs( );
char	*malloc	( );
char	*mktemp	( );
int	cleanup	( );
int	chkpeg	( );
long	fixstrt	( );
long	fixday	( );
long	fixday	( );
long	fixhm	( );
long	fixymd	( );
long	time	( );
long	lseek	( );
struct	passwd	*getpwuid( );
struct	passwd	*getpwnam( );
struct	tm *localtime	( );

extern int	opterr;
extern int	optind;
extern int	eod;
extern int	admupd;
extern int	quiet;
extern int	vrbose;
extern int	normpeg;
extern char	lb[];
extern char	*invkst;
extern char	*pegfnm;
extern char	*pegdir;
extern char	*optarg;
extern char	*sys_errlist[];
extern int	sys_nerr;
extern int	errno;
extern long	duback;
extern long	starts[];
extern struct	tm today;

