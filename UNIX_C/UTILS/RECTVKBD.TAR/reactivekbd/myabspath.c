/* Mark James 89/5/24*/


#include "myabspath.h"
#include <pwd.h>
#include <stdio.h>
#include <ctype.h>
#include <strings.h>


/* returns 0 on success, NO_HOME if getenv("HOME") fails, NO_USER if ~user does not exist */

myabspath(path,buff)
char *path;
char *buff;
{
	char *homedir;
	char *getenv();
	char username[MAX_USER_NAME];
	int i;
	struct passwd *pwd;

	while (isspace(path[0])&&path[0])
		path++;
	if(path[0]=='~'){
		path++;
		if((path[0]=='/') || (path[0]==0)){
			if((homedir=getenv("HOME"))==0)
				return(NO_HOME);
			strcpy(buff,homedir);
			strcat(buff,path);
			return(0);
		}
		else
		{
			for(i=0;(path[0]!='/')&&(path[0]!=0);i++,path++)
				username[i]=path[0];
			username[i]=0;
			if((pwd=getpwnam(username))==0)
				return(NO_USER);
			strcpy(buff,pwd->pw_dir);
			strcat(buff,path);		
		}
	}
	else
	{
		strcpy(buff,path);
		return(0);
	}
}




