#include <sys/param.h>	    /* JJD 3-89 added to get MAXPATHLEN and CANBSIZ */
char *strcpy(), *strcat();			    /* JJD 3-89 for lint */
char *gets(), *sprintf(), *malloc();		    /* JJD 3-89 for lint */
char *sprintf();				    /* JJD 3-89 for lint */
char *index();

#define OK                0
#define FINISHED_EDITING -1
#define FINISHED_BUT_DONT_ADD_CTRL_M -2
#define HAVE_CHAR -3
#define UNIVERSAL_ARGUMENT_MAXIMUM 256
#define MAX_CMD_LINE_LENGTH CANBSIZ
#define VERSION "1.0 August 21st 1989" 
#define RK_VERSION " 1.0 August 21st 1989"	
#define ONE_LINE (int)1			/* JJD 3-89 was int dummy for tputs */


struct ed_buffs {
    char string[MAX_CMD_LINE_LENGTH + 1];
    char *dot;
    char *mark;						/* JJD 3-89 added */
    struct ed_buffs *next_ptr;
    struct ed_buffs *prev_ptr;
    };

typedef struct _ed_struct {
    char current_input_char;
    int  universal_argument;
    char *current_buffer;
    char *dot;
    char *mark;
    char kill_buffer[MAX_CMD_LINE_LENGTH + 1];
    struct ed_buffs *current_ed_buff_ptr;
    } ED_STRUCT;

#define MAXEXTENSIONS 12

