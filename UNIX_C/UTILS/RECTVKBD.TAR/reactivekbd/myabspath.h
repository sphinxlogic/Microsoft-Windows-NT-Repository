#define NO_HOME -1
#define NO_USER -2

#define MAX_USER_NAME 40
