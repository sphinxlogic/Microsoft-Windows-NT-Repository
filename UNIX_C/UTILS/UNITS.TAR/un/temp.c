
/* temperature - G.R.Simpson */

#include "un.h"

temperature()
{
static char *scale[4] = { "Fahrenheit", "Celsius", "Rankine", "Kelvin" };
double fahrenheit, celsius, rankine, kelvin;
double temp;
char c[2];
int    choice, tempagain;

        tempagain = 1;

        while(tempagain) {
              Clear;
              printf("                     Unit Selection\n");
              printf("-------------------------------------------------------------\n");
                     printf("1. Fahrenheit                    2. Celsius \n");
                     printf("3. Rankine                       4. Kelvin \n");
              printf("-------------------------------------------------------------\n");

        printf("Your Temperature Scale? ");
        getinteger(&choice,3);
        printf("\n How many degrees %s? ", scale[choice-1]);
        getnumber(&temp);
        switch(choice) {
              case 1 :
                    fahrenheit = temp;
                    break;
              case 2 :
                    fahrenheit = temp*(9.0/5.0) + 32.0;
                    break;
              case 3 :
                    fahrenheit = temp - 459.67;
                    break;
              case 4 :
                    fahrenheit = ((temp-273.15)*(9.0/5.0)) + 32.0;
                    break;
        }
        celsius = (fahrenheit - 32) * (5.0/9.0);
        rankine = fahrenheit + 459.67;
        kelvin  = celsius + 273.15;

        Clear;
        printf("     %16.8g degrees %s is equivalent to:\n",
                     temp,scale[choice-1]);
        printf("                  ------------------------------------\n");
        if (choice != 1) printf("                  %16.8g degrees Fahrenheit\n", fahrenheit);
        if (choice != 2) printf("                  %16.8g degrees Celsius\n",    celsius);
        if (choice != 3) printf("                  %16.8g degrees Rankine\n",    rankine);
        if (choice != 4) printf("                  %16.8g degrees Kelvin\n",     kelvin);

        printf("                  ------------------------------------\n");
        printf("\n (R)erun Unit type, (N)ew Unit type, or (Q)uit: ");
        scanf("%s",c);
        if ( c[0] == 'Q' || c[0] == 'q' ) {
           quit_it();
        } 
        else if ( c[0] == 'R' || c[0] == 'r' ) {
           tempagain = 1;
        } 
        else if ( c[0] == 'N' || c[0] == 'n' ) {
           tempagain = 0;
        } 
  } /* end while(tempagain) */
        c[0] = '\0';
        return;
}
