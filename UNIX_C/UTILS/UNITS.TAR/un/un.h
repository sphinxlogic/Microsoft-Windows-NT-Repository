/* un.h - 1/17/87 */

#include <stdio.h>

#define ESC '\033'
#define True 1

/* Definition for clearing Screen */

#ifdef MSDOS
#define Clear printf("%c[2J%c[1;1f",ESC,ESC)
#else
#define Clear printf("\n\n");
#endif
