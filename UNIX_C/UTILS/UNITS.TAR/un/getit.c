
/* getinteger - Get Positive Integer Routine - G.R.Simpson */

#include "un.h"

int getinteger(choice, max)

int *choice;
int max;
{
       char quit[80];
       char junk[80];
       int status, c;
       while(1) { 
              scanf("%s",quit);
	      if ( quit[0] == 'Q' || quit[0] == 'q' ) {
                   quit_it();
	      }
	      status = sscanf(quit, "%d", choice);
              if (status == 0)
              {
		     scanf("%*s",junk);
		     printf("Please Use Positive Integers,\n");
                     printf("or 'q' to (Q)uit; try again: ");
              }
              else if (status == 1)
              {
                     while ((c = getchar()) != '\n' && c != EOF)
                            ;
                     if ( c == EOF )
                     {
                            ungetc(c, stdin);
                     }
                     if ( *choice > 0 && *choice <= max+1 ) 
                     {
                             return status;
                     }
                     printf("Please use a number from 1 to %d : ", max+1);
              }
              else  /* status is -1 */
              {
              printf("End of file encountered... \n");
              *choice = 1;
              return status;
              }
}
}

/* getdouble - Get Double Precision Number - G.R.Simpson */

getnumber(fchoice)

double *fchoice;
{
       char quit[80];
       char junk[80];
       int status, c;
       while(1) {
              scanf("%s",quit);
	      if ( quit[0] == 'Q' || quit[0] == 'q' ) {
                   quit_it();
              }
	      status = sscanf(quit, "%lf", fchoice);
       if (status == 0)
       {
              scanf("%*s",junk);
              printf("Please Use Numeric Input,\n");
              printf("or 'q' to (Q)uit; try again: ");
       } 
       else if (status == 1)
       {
              while ((c = getchar()) != '\n' && c != EOF)
                     ;
              if ( c == EOF )
                     ungetc(c, stdin);
       }
       else  /* status is -1 */
       printf("End of file encountered... \n");
       return status;
       }
}

