
/* constants - G.R.Simpson */

#include "un.h"

constants()
{
        char c[10];

        Clear;         
        printf("\npi                      =  3.141592653589793238462643\n");
        printf("e                       =  2.718281828459045235360287\n");
        printf("atomic mass unit        =  1.66053 e-27 kg, e-24 gm \n");
        printf("Avogadro's number N     =  6.02217 e23 mole^-1 \n");
        printf("Boltzmann's constant    =  R/N = 1.3806 e-23 J/K, e-16 erg/K = 8.61708 e-5 eV/K \n");
        printf("gas constant            =  8.3143 J/mole-K = 0.082054 l-atm/mole-K\n");
        printf("gravitational constant  =  6.673 e-11 N-m^2/kg^2, J-m/kg^2, \n");
        printf("mass of electron        =  9.10956 e-31 kg, e-28 gm =  5.48593 e-4 amu \n");
        printf("mass of proton          =  1.67261 e-27 kg, e-24 gm =  1.0072766 amu \n");
        printf("Planck's constant       =  h =  6.62620 e-34 J-sec,  e-27 erg-sec \n");
        printf("h bar                   =  h/2*pi = 1.05459 e-34 J-sec, e-27 erg-sec \n");
        printf("speed of light          =  2.997925 e8 m/sec, e10 cm/sec \n");
        printf("Stefan-Boltzmann constant =  5.670 e-8 W/m^2-K^4 \n");
        printf("\n      <CR> to continue or (Q)uit: ");
        gets(c);
        if ( c[0] == 'Q' || c[0] == 'q' ) {
           quit_it();
        } else {
        c[0] = '\0';
        return;
        }
}


/* prefix - G.R.Simpson */

prefix()
{
        char c[10];

        Clear;         
        printf("tera   =  1,000,000,000,000 = 10e12\n");
        printf("giga   =      1,000,000,000 = 10e09\n");
        printf("mega   =          1,000,000 = 10e06\n");
        printf("kilo   =              1,000 = 10e03\n");
        printf("centi  =               0.01 = 10e-02\n");
        printf("milli  =              0.001 = 10e-03\n");
        printf("micro  =           0.000001 = 10e-06\n");
        printf("nano   =        0.000000001 = 10e-09\n");
        printf("pico   =     0.000000000001 = 10e-12\n");
        printf("\n      <CR> to continue or (Q)uit: ");
        gets(c);
        if ( c[0] == 'Q' || c[0] == 'q' ) {
           quit_it();
        } else {
        c[0] = '\0';
        return;
        }
}
