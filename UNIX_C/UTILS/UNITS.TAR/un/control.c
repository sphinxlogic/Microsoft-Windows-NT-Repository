
/* usage - Print a usage message - G.R.Simpson */

#include "un.h"

usage()
{
        printf("\nusage: u [-c] \n");
        printf("-c : unit chart option \n\n");
        printf("Un... Unit conversions; Copyright, Gregory R. Simpson 1987,1988,1989\n");
        exit(0);
}

/* action - G.R.Simpson */

action(sameu,charts)
int *sameu, *charts;
{
     char c[10];
     int tryagain = 1;

     while (tryagain) {
	if (*charts != 1) {
           printf("\n      (R)erun Unit type, (N)ew Unit type, (Q)uit, or (C)hart: ");
        } else {
	   printf("\n (R)erun Unit type, (N)ew Unit type, (Q)uit, or (S)tandard Conversions: ");
        }
	scanf("%s",c);
        if ( c[0] == 'Q' || c[0] == 'q' ) {
             quit_it();
        } 
        else if ( c[0] == 'R' || c[0] == 'r' ) {
             *sameu = 1;
	     tryagain = 0;
        } 
        else if ( c[0] == 'N' || c[0] == 'n' ) {
             *sameu = 0;
	     tryagain = 0;
        } 
        else if ( c[0] == 'C' || c[0] == 'c' ) {
	     *charts = 1;
             *sameu = 0;
	     tryagain = 0;
        }
	else if ( c[0] == 'S' || c[0] == 's' ) {
	     *charts = 0;
             *sameu = 0;
	     tryagain = 0;
        }
        else {
	     printf("\n             Invalid Response, please try again: \n");
        }
   }
	return;
}

/* quit_it - G.R.Simpson */

quit_it()
{
	printf("\n Un... Unit Conversion, by Gregory R. Simpson - Copyright 1987,1988,1989 \n");
        exit(0);
}
