#ifndef DOS	/*	Definition of complex not needed for MSC	*/
#ifndef MSDOS	/*	Already in <math.h>	*/

struct complex {
	double x, y;
};

#endif
#endif

struct fcomplex {
	float x, y;
};
