/* $Header: sccsid.h,v 1.1 85/05/17 08:53:55 nicklin Exp $ */

/*
 * Release identification
 *
 * Author: Peter J. Nicklin
 */
static char *sccsid = "@(#)V4BSDRel2";
