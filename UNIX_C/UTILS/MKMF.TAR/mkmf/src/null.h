/* $Header: null.h,v 1.1 85/03/14 15:33:08 nicklin Exp $ */

/*
 * NULL constant definition
 *
 * Author: Peter J. Nicklin
 */

#define CNULL		(char *) 0
#ifndef NULL
#define NULL		0
#endif
