/* $Header: yesno.h,v 1.1 85/03/14 15:34:01 nicklin Exp $ */

/*
 * YES/NO constant definitions
 *
 * Author: Peter J. Nicklin
 */

#define YES 1
#define NO  0
