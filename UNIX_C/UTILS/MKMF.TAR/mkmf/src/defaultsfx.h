".c", SFXSRC, INCLUDE_C,	/* C */
".e", SFXSRC, INCLUDE_FORTRAN,	/* Efl */
".F", SFXSRC, INCLUDE_FORTRAN,	/* Fortran */
".f", SFXSRC, INCLUDE_FORTRAN,	/* Fortran */
".h", SFXHEAD, INCLUDE_NONE,	/* header */
".i", SFXHEAD, INCLUDE_NONE,	/* Pascal include */
".l", SFXSRC, INCLUDE_C,	/* Lex */
".o", SFXOBJ, INCLUDE_NONE,	/* object */
".p", SFXSRC, INCLUDE_PASCAL,	/* Pascal */
".r", SFXSRC, INCLUDE_FORTRAN,	/* Ratfor */
".s", SFXSRC, INCLUDE_NONE,	/* Assembler */
".y", SFXSRC, INCLUDE_C,	/* Yacc */
