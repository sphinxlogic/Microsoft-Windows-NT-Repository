/*
 * unculry -- uncurly expand a list of parameters			(ksb)
 *
 * Copyright 1988, All Rights Reserved
 *	Kevin S Braunsdorf
 *	ksb@j.cc.purdue.edu, pur-ee!ksb
 *	Math/Sci Building, Purdue Univ
 *	West Lafayette, IN
 *
 *  `You may redistibute this code as long as you don't claim to have
 *   written it. -- ksb'
 *
 * The command
 *	$ uncurly c1.c c2.c c3.c c4.c c5.c
 * outputs
 *	c{1,2,3,4,5}.c
 *
 * So one might pipe the ouptut of a find to uncurly to compress the filenames
 * like:
 *	$ find . -type f -print | uncurly | compress > /tmp/${USER}files.Z
 *	# later on we need the list again...
 *	$ zcat /tmp/${USER}files.Z | curly | xargs do_something
 *
 * Improvments:
 *
 * This code could be mixed with other globbing code to fully emulate
 * an `arcglob' function, however this assumes the files exist in there
 * present form and is therefore less useful (to me).
 *
 * We could free more memory, if we were more carefull with our bookkeeping.
 *
 * The READSTDIN flag could be stired with the code for main to get something
 * that allocate less memory before UnCulry was called, free'd it and went
 * back to reading... if you run out of memory you can try it and send me
 * a patch :-).
 *
 * $Compile: ${CC-cc} ${DEBUG--O} ${SYS--Dbsd} -DREADSTDIN %f -o %F
 * $Compile: ${CC-cc} ${DEBUG--O} ${SYS--Dbsd} %f -o %F
 * $Lint: lint -abhxp ${SYS--Dbsd} -DREADSTDIN %f
 * $Lint: lint -abhxp ${SYS--Dbsd} %f
 */
#include <stdio.h>
#include <sys/param.h>
#include <sys/types.h>

static char *progname =
	"$Id: uncurly.c,v 2.0 88/07/30 17:10:50 ksb Exp $";

/*
 * If your compiler doesn't allow `register' as a parameter storage class
 * define PREG as empty, and don't worry about it.
 */
#define PREG	register	/* make arguments faster access		*/
/* #define PREG			/* no register arguments		*/

#if defined(bsd)
#define strrchr rindex		/* I must be on bsd, us rindex		*/
#endif

#if !defined(MAXPATHLEN)
#define MAXPATHLEN	1024
#endif

extern char *malloc(), *calloc(), *strrchr(), *strcat();
static char acNoMem[] = "%s: out of memory\n";

/*
 * find a matching close char for the open we just ate, or (char *)0	(ksb)
 *	pc = FindMatch("test(a,b))+f(d)", '(', ')', 1);
 *			         ^ pc points here
 */
char *
FindMatch(pcBuf, cOpen, cClose, iLevel)
PREG char *pcBuf;
char cOpen, cClose;
int iLevel;
{
	while ('\000' != *pcBuf) {
		if (cClose == *pcBuf) {
			--iLevel;
		} else if (cOpen == *pcBuf) {
			++iLevel;
		}
		if (0 == iLevel)
			return pcBuf;
		++pcBuf;
	}
	return (char *)0;
}

/*
 * save a string in malloc space					(ksb)
 */
char *
strsave(pc)
char *pc;
{
	extern char *strcpy();
	extern int strlen();
	register char *pcMem;

	pcMem = malloc((unsigned int) strlen(pc)+1);
	if ((char *)0 == pcMem) {
		fprintf(stderr, acNoMem, progname);
		exit(1);
	}
	return strcpy(pcMem, pc);
}

#if defined(READSTDIN)
#define FIRST_GUESS	8192	/* initial number of input files	*/
#define NEXT_GUESS	2048	/* add this many if too few		*/

/*
 * Joe wants us to turn a piped list of files into a big glob list	(ksb)
 * we return the number of files (he gave us) and a vector of them.
 */
unsigned int
GetFiles(pppcArgv)
char ***pppcArgv;
{
	extern char *realloc();
	register unsigned int uCount, uLeft;
	register char **ppcVector;
	auto char acFile[MAXPATHLEN];

	ppcVector = (char **) calloc(FIRST_GUESS, sizeof(char *));
	uCount = 0;
	uLeft = FIRST_GUESS;
	while (NULL != gets(acFile)) {
		if (0 == uLeft) {
			uLeft = (uCount+NEXT_GUESS) * sizeof(char *);
			ppcVector = (char **) realloc((char *)ppcVector, uLeft);
			uLeft = NEXT_GUESS;
		}
		ppcVector[uCount] = strsave(acFile);
		++uCount;
		--uLeft;
	}

	*pppcArgv = ppcVector;
	return uCount;
}
#endif	/* find files from stdin	*/

/*
 * longest common prefix of more than one string			(ksb)
 * Note that the prefix must have balanced '{'..'}' in it.
 */
int
Prefix(n, ppcList, puiLen)
unsigned int n;
char **ppcList;
unsigned *puiLen;
{
	register int cCmp, cCur, iBal;
	auto unsigned int j, i, uArea, uLen, uSpan, uCurlen;

	*puiLen = 0;

	iBal = 0;
	for (j = 0; j < n; ++j) {
		if ('\000' == ppcList[j][0]) {
			break;
		}
	}

	/* trivial case either first or second sring is empty
	 */
	if (j < 2) {
		return 0;
	}

	uCurlen = uArea = uLen = uSpan = 0;
	while ('\000' != (cCur = ppcList[0][uCurlen])) {
		if ('{' == cCur)
			++iBal;
		else if ('}' == cCur)
			--iBal;
		for (i = 1; i < j; ++i) {
			cCmp = ppcList[i][uCurlen];
			if ('\000' == cCmp || cCur != cCmp) {
				j = i;
				break;
			}
		}
		++uCurlen;
		if (0 == iBal && uCurlen * j > uArea) {
			uArea = uCurlen*j;
			uLen = uCurlen;
			uSpan = j;
		}
	}
	*puiLen = uLen;
	return uSpan;
}

/*
 * longest common suffix of more than one string			(ksb)
 *  1) find the ends of all the strings
 *  2) back off until we find a non-match, but keep looking
 *  3) return the one with most characters in it
 * Note that the suffix must have balanced '{'..'}' in it.
 */
int
Suffix(n, ppcList, puiLen)
unsigned int n;
char **ppcList;
unsigned *puiLen;
{
	register char **ppcLast, *pcTemp;
	register unsigned int j, i, uCurlen;
	auto unsigned uArea, uLen, uSpan, iStopAt;
	auto int cCur, iBal;

	*puiLen = 0;

	ppcLast = (char **)calloc(n, sizeof(char *));
	if ((char **)0 == ppcLast) {
		fprintf(stderr, acNoMem, progname);
		exit(1);
	}
	for (j = 0; j < n; ++j) {
		ppcLast[j] = strrchr(ppcList[j], '\000');
		if (ppcLast[j] == ppcList[j]) {
			break;
		}
	}

	iBal = uCurlen = uArea = uLen = uSpan = 0;
	while (ppcLast[0] != ppcList[0]) {
		cCur = ppcLast[0][-1];
		if ('{' == cCur)
			++iBal;
		else if ('}' == cCur)
			--iBal;
		iStopAt = -1;
		for (i = 0; i < j; ++i) {
			pcTemp = --ppcLast[i];
			if (cCur != pcTemp[0]) {
				j = i;
				break;
			}
			if (ppcList[i] == pcTemp && -1 == iStopAt) {
				iStopAt = i;
			}
		}
		++uCurlen;
		if (0 == iBal && uCurlen * j > uArea) {
			uArea = uCurlen*j;
			uLen = uCurlen;
			uSpan = j;
		}
		if (-1 != iStopAt) {
			j = iStopAt;
		}
	}
	*puiLen = uLen;
	free((char *)ppcLast);
	return uSpan;
}

/*
 * determine context for a list ppcList[0..n-1]				(ksb)
 *	left { ... } right
 *
 * If the longest common prefix will eat more character then
 * we should use that, else try the longest common suffix.
 * If both are 0 chars just return the list (0).
 */
unsigned int
Split(n, ppcList, ppcLeft, ppcRight)
unsigned int n;
char **ppcList, **ppcLeft, **ppcRight;
{
	register unsigned int i, iLcs, iLcp;
	register char *pcEnd;
	auto unsigned int iLcsLen, iLcpLen;
	auto int cKeep;

	*ppcLeft = (char *)0;
	*ppcRight = (char *)0;
	if (n == 1) {
		return 1 ;
	}

	iLcp = Prefix(n, ppcList, & iLcpLen);
	if (iLcp * iLcpLen < 2 + iLcpLen) {
		iLcp = 0;
	}

	iLcs = Suffix(n, ppcList, & iLcsLen);
	if (iLcs * iLcsLen < 2 + iLcsLen) {
		iLcs = 0;
	}

	if (iLcp * iLcpLen < iLcs * iLcsLen) {
		pcEnd = strrchr(ppcList[0], '\000') - iLcsLen;
		*ppcRight = strsave(pcEnd);
		for (i = 0; i < iLcs; ++i) {
			pcEnd = strrchr(ppcList[i], '\000') - iLcsLen;
			*pcEnd = '\000';
		}
		iLcp = Prefix(iLcs, ppcList, & iLcpLen);
		if (iLcp == iLcs) {
			pcEnd = ppcList[0] + iLcpLen;
			cKeep = *pcEnd;
			*pcEnd = '\000';
			*ppcLeft = strsave(ppcList[0]);
			*pcEnd = cKeep;
			for (i = 0; i < iLcp; ++i) {
				ppcList[i] += iLcpLen;
			}
		}
		return iLcs;
	} else if (0 != iLcpLen && 0 != iLcp) {
		pcEnd = ppcList[0] + iLcpLen;
		cKeep = *pcEnd;
		*pcEnd = '\000';
		*ppcLeft = strsave(ppcList[0]);
		*pcEnd = cKeep;
		for (i = 0; i < iLcp; ++i) {
			ppcList[i] += iLcpLen;
		}
		iLcs = Suffix(iLcp, ppcList, & iLcsLen);
		if (iLcs == iLcp) {
			pcEnd = strrchr(ppcList[0], '\000') - iLcsLen;
			*ppcRight = strsave(pcEnd);
			for (i = 0; i < iLcs; ++i) {
				pcEnd = strrchr(ppcList[i], '\000') - iLcsLen;
				*pcEnd = '\000';
			}
		}
		return iLcp;
	}
	return 0;
}
/* If there are matched curlies around a
 * member of the list we can remove them.
 * uLen may be (a few chars) too big, who cares?
 */
void
mcat(pcAccum, pcElement)
PREG char *pcAccum, *pcElement;
{
	extern int strlen();
	register char *pcMatch;
	register unsigned int uLen;

	if ('{' == pcElement[0]) {
		uLen = strlen(pcElement)-1;
		pcMatch = FindMatch(pcElement, '{', '}', 0);
		if (pcMatch == & pcElement[uLen]) {
			*pcMatch = '\000';
			strcat(pcAccum, pcElement+1);
			*pcMatch = '}';
		} else {
			strcat(pcAccum, pcElement);
		}
	} else {
		strcat(pcAccum, pcElement);
	}
}

/*
 * undo what a {...} does in csh					(ksb)
 * We make passes over the list until we can make no more reductions.
 * I think this works -- that is it does as good a job as I would.
 */
unsigned int
UnCurly(n, ppcWhole)
unsigned int n;
char **ppcWhole;
{
	register unsigned int m, i;
	register char **ppcList;
	auto unsigned int uInside, uLen, uEnd, uSquish;
	auto char *pcLeft, *pcRight;
	auto char *pcTemp, *pcSep;

	ppcList = ppcWhole;
	m = n;
	while (m > 0) {
		uInside = Split(m, ppcList, & pcLeft, & pcRight);
		switch (uInside) {
		case 0:
		case 1:
			/* skip boring files for next pass
			 */
			--m;
			++ppcList;
			break;
		default:
			/* Left "{" List[0] "," List[uInside-1] "}" Right
			 */
			n -= m;
			uSquish = UnCurly(uInside, ppcList);
			uLen = 2;	/* close curly and "\000" */
			if ((char *)0 != pcLeft) {
				uLen += strlen(pcLeft);
			}
			for (i = 0; i < uSquish; ++i) {
				uLen += 1 + strlen(ppcList[i]);
			}
			if ((char *)0 != pcRight) {
				uLen += strlen(pcRight);
			}
			pcTemp = malloc(uLen);
			if ((char *)0 == pcTemp) {
				fprintf(stderr, acNoMem, progname);
				exit(1);
			}

			pcTemp[0] = '\000';
			if ((char *)0 != pcLeft) {
				(void) strcat(pcTemp, pcLeft);
				free(pcLeft);
			}
			if (1 == uSquish) {
				mcat(pcTemp, ppcList[0]);
			} else {
				pcSep = "{";
				for (i = 0; i < uSquish; ++i) {
					register char *pcMatch;

					strcat(pcTemp, pcSep);

					mcat(pcTemp, ppcList[i]);
					pcSep = ",";
				}
				strcat(pcTemp, "}");
			}
			if ((char *)0 != pcRight) {
				(void) strcat(pcTemp, pcRight);
				free(pcRight);
			}

			uEnd = UnCurly(m-uInside, ppcList+uInside);
			n += 1 + uEnd;
			ppcList[0] = pcTemp;
			for (i = 0 ; i < uEnd; /* update below */) {
				ppcList[++i] = ppcList[uInside++];
			}
			ppcList = ppcWhole;
			m = n;
			break;
		}
	}
	return n;
}

/*
 * do the opposite of csh(1) {...}					(ksb)
 * we cannot process files with a comma in them, but as a special
 * case we will remove ",EXT" from the end of a list of files...
 * and process those if it is the only comma in each of the files.
 *  1) output UnCulry of files with no commas
 *  2) output UnCulry of files with `,EXT' (only) on the end
 *  3) output files with random commas in them (bletch)
 *  4) loop until all files have been done
 */
int
main(argc, argv)
unsigned int argc;
char **argv;
{
	register unsigned int i, uReplace, uCommon;
	register char *pcExt;

	progname = *argv++;
	--argc;

#if defined(READSTDIN)
	if (argc == 0) {
		argc = GetFiles(& argv);
	}
#endif
	while (0 < argc) {
		for (uCommon = 0; uCommon < argc; ++uCommon) {
			if ((char *)0 != strrchr(argv[uCommon], ',')) {
				break;
			}
		}
		if (0 != uCommon) {
			uReplace = UnCurly(uCommon, argv);
			argc -= uCommon;
			for (i = 0; i < uReplace; ++i) {
				puts(argv[i]);
			}
			argv += uCommon;
		}
		do {
			pcExt = (char *)0;
			for (uCommon = 0; uCommon < argc; ++uCommon) {
				register char *pcComma;
				if ((char *)0 == (pcComma = strrchr(argv[uCommon], ','))) {
					break;
				}
				if ((char *)0 == pcExt) {
					*pcComma ='\000';
					pcExt = pcComma+1;
				} else if (0 != strcmp(pcExt, pcComma+1)) {
					break;
				} else {
					*pcComma = '\000';
				}
				if ((char *)0 != strrchr(argv[uCommon], ',')) {
					*pcComma = ',';
					break;
				}
			}
			if (0 != uCommon) {
				uReplace = UnCurly(uCommon, argv);
				argc -= uCommon;
				for (i = 0; i < uReplace; ++i) {
					fputs(argv[i], stdout);
					putchar(',');
					puts(pcExt);
				}
				argv += uCommon;
			}
			if ((char *)0 != strrchr(argv[0], ',')) {
				puts(argv[0]);
				argc -= 1;
				argv += 1;
				uCommon = 1;
			}
		} while (0 != uCommon);
	}
	exit(0);
}
