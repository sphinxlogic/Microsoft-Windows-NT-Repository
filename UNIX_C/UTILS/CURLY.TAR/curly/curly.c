/*
 * curly -- expand {...} as csh(1)					(ksb)
 *
 * Copyright 1988, All Rights Reserved
 *	Kevin S Braunsdorf
 *	ksb@j.cc.purdue.edu, pur-ee!ksb
 *	Math/Sci Building, Purdue Univ
 *	West Lafayette, IN
 *
 *  `You may redistibute this code as long as you don't claim to have
 *   written it. -- ksb'
 *
 * We are limited to not eating backslash escapes because that would be
 * very confusing to the user.  If you need a file name {a}.c don't call
 * this routine.  Simple.  (If we did use \ as special, then \.c would
 * need to be quoted from us... it never ends, so we let the shells worry
 * about \ quoting for us.)
 *
 * We don't expand other globbing characters, because ksh will expand
 * those for us when it reads our output in `quotes`.
 *
 * The command
 *	$ curly c{1,2,3,4,5}.c
 * outputs
 *	c1.c c2.c c3.c c4.c c5.c
 *
 * So use you might use
 *	$ tar xv `curly c{1,2,3,4,5}.c`
 * to extract them from tape.
 *
 * If we are given no arguments we can read stdin for strings to glob.
 * The READSTDIN switch controls this feature.
 *
 * Improvments:
 *
 * This code could be mixed with other globbing code to fully emulate
 * csh(1) globbing in a few minutes,  I have no need of this (yet).
 *
 * We can avoid the malloc/strcpy/strcat in DoExpr if we build right
 * context right to left in a large buffer; this buffer could limit the
 * size of the glob expression, but other factors limit it already.
 *
 * $Compile: ${CC-cc} ${DEBUG--O} ${SYS--Dbsd} -DREADSTDIN %f -o %F
 * $Compile: ${CC-cc} ${DEBUG--O} ${SYS--Dbsd} %f -o %F
 * $Lint: lint -abhxp ${SYS--Dbsd} -DREADSTDIN %f
 * $Lint: lint -abhxp ${SYS--Dbsd} %f
 */
#include <stdio.h>
#include <sys/param.h>
#include <sys/types.h>

static char *progname =
	"$Id: curly.c,v 2.0 88/07/30 17:10:38 ksb Exp $";

/*
 * If your compiler doesn't allow `register' as a parameter storage class
 * define PREG as empty, and don't worry about it.
 */
#define PREG	register	/* make arguments faster access		*/
/* #define PREG			/* no register arguments		*/

#if defined(bsd)
#define strrchr rindex		/* I must be on bsd, us rindex		*/
#endif

#if !defined(MAXPATHLEN)
#define MAXPATHLEN	1024
#endif

extern char *malloc(), *realloc(), *strcpy();

/* static int iMatch = 0; 	*/
static char acName[MAXPATHLEN];
extern void DoExpr(), DoList();

#if defined(READSTDIN)
#define FIRST_GUESS	8	/* be get on MAXPATHLEN * this		*/
#define NEXT_GUESS	2	/* we hedge with MAXPATHLEN * this	*/
#define GRAB		2	/* size chunk to read (<= NEXT_GUESS)	*/

static char acNoMem[] = "%s: out of memory\n";

/*
 * Here we call gets() to read a glob expression to do.			(ksb)
 * Repeat until end of file.
 */
void
DoStdin(pcAccum)
PREG char *pcAccum;
{
	extern char *strrchr();
	auto char acLine[MAXPATHLEN*GRAB];
	static char *pcLine = (char *)0;
	static unsigned uBufLen = 0;
	register unsigned uPos;
	register char *pcNewLine;

	acLine[MAXPATHLEN*GRAB-1] = '\000';
	if ((char *)0 == pcLine) {
		uBufLen = MAXPATHLEN*FIRST_GUESS;
		pcLine = malloc(uBufLen);
		if ((char *)0 == pcLine) {
			fprintf(stderr, acNoMem, progname);
			exit(1);
		}
	}
	uPos = 0;
	while (NULL != fgets(acLine, MAXPATHLEN*GRAB-1, stdin)) {
		pcNewLine = strrchr(acLine, '\n');
		if (0 == uPos && (char *)0 != pcNewLine) {
			*pcNewLine = '\000';
			DoExpr(pcAccum, acLine, "\n");
			continue;
		}
		if ((char *)0 != pcNewLine) {
			*pcNewLine = '\000';
		}
		if (uPos + MAXPATHLEN*GRAB-1 > uBufLen) {
			uBufLen += MAXPATHLEN*NEXT_GUESS;
			pcLine = realloc(pcLine, uBufLen);
		}
		strcpy(pcLine+uPos, acLine);
		if ((char *)0 == pcNewLine) {	/* we got chars, no end yet */
			uPos += MAXPATHLEN*GRAB-2;
			continue;
		}
		/* we have a line */
		DoExpr(pcAccum, pcLine, "\n");
		uPos = 0;
	}
}
#endif	/* we can read stdin for a list of patterns */

/*
 * find a matching close char for the open we just ate, or (char *)0	(ksb)
 *	pc = FindMatch("test(a,b))+f(d)", '(', ')', 1);
 *			         ^ pc points here
 */
char *
FindMatch(pcBuf, cOpen, cClose, iLevel)
char *pcBuf;
char cOpen, cClose;
int iLevel;
{
	while ('\000' != *pcBuf) {
		if (cClose == *pcBuf) {
			--iLevel;
		} else if (cOpen == *pcBuf) {
			++iLevel;
		}
		if (0 == iLevel)
			return pcBuf;
		++pcBuf;
	}
	return (char *)0;
}

/*
 * if we can locate a curly expression in our expression if the form:	(ksb)
 *	 	left { list } right
 *	1) copy left side to pcAccum,
 *	2) add right to our right context (malloc a new buffer if needed)
 *	3) call DoList(pcAccum, list, right)
 * or if we find no such curly expression
 *	1) copy all nonspecial chars to pcAccum
 *	2) recurse with DoExpr(pcAccum, pcRight, "")
 */
void
DoExpr(pcAccum, pcExpr, pcRight)
PREG char *pcAccum;
char *pcExpr, *pcRight;
{
	extern void DoList();
	extern char *malloc(), *strcat(), *strcpy();
	register char *pcClose;
	register char *pcComma;
	register char *pcTemp;
	register unsigned int uLen;

	while ('{' != *pcExpr && '\000' != *pcExpr) {	/*}*/
		*pcAccum++ = *pcExpr++;
	}

	switch (*pcExpr) {
	case '\000':
		if (*pcRight == '\000') {	/* no right context	*/
			if (pcAccum != acName) {
				*pcAccum = '\000';
				fputs(acName, stdout);
				/* ++iMatch; */
			}
		} else {
			DoExpr(pcAccum, pcRight, "");
		}
		break;
	case '{':
		pcClose = FindMatch(pcExpr, '{', '}', 0);
		/*
		 * if an open is unbalanced we ignore it.
		 */
		if ((char *)0 == pcClose) {
			*pcAccum++ = *pcExpr++;
			DoExpr(pcAccum, pcExpr, pcRight);
			break;
		}
		*pcClose++ = '\000';
		pcComma = pcExpr+1;

		/*
		 * Now that the expr is cracked we can optimize if the
		 * additional right context is empty.  If it is not we
		 * have to compute a new right context.
		 */
		uLen = strlen(pcClose);
		if (0 == uLen) {
			DoList(pcAccum, pcComma, pcRight);
		} else {
			uLen += strlen(pcRight);
			pcTemp = malloc(uLen+1);
			(void) strcpy(pcTemp, pcClose);
			(void) strcat(pcTemp, pcRight);
			DoList(pcAccum, pcComma, pcTemp);
			free(pcTemp);
		}
		*--pcClose = '}';
		break;
	}
}

/*
 * do a comma separated list of terms with known right context		(ksb)
 *	1) loop through exprs at this level
 *	2) call DoExpr(pcAccum, SubExpr, Right)
 */
void
DoList(pcAccum, pcList, pcRight)
PREG char *pcAccum;
char *pcList, *pcRight;
{
	extern void DoExpr();
	register char *pcThis;
	register int iLevel;

	iLevel = 0;

	for (pcThis = pcList; '\000' != *pcList; ++pcList) {
		switch (*pcList) {
		case '{':
			++iLevel;
			break;
		case '}':
			--iLevel;
			break;
		default:
			break;
		case ',':
			if (0 == iLevel) {
				*pcList = '\000';
				DoExpr(pcAccum, pcThis, pcRight);
				*pcList = ',';
				pcThis = pcList+1;
			}
			break;
		}
	}
	DoExpr(pcAccum, pcThis, pcRight);
}

/*
 * Special case "{}" as csh(1) does for find (YUCK!)			(ksb)
 * We take no options so that they won't conflict with anything.
 * Count option exprs so we can output a blank line if we come up empty
 * (I've forgotten why we do this...)
 */
int
main(argc, argv)
int argc;
char **argv;
{
	register char *pcPat;

	progname = *argv++;
	--argc;

#if defined(READSTDIN)
	if (0 == argc) {
		DoStdin(acName);
	}
#endif
	while (argc > 0) {
		pcPat = *argv++;
		--argc;
		/*
		 * this kludge keeps us more csh(1) compatible
		 */
		if ('{' == pcPat[0] && '}' == pcPat[1] && '\000' == pcPat[2]) {
			fputs("{}\n", stdout);
			/* ++iMatch; */
			continue;
		}
		DoExpr(acName, pcPat, "\n");
	}

	exit(0);
}
