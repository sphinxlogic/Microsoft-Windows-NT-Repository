/*
** hgrep - a front end to grep that highlights the string found
**
** version of 23oct88
**
** Copyright (C) 1988 by Jef Poskanzer.
**
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted, provided
** that the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation.  This software is provided "as is" without express or
** implied warranty.
*/

#include <stdio.h>
#include <string.h>

#define TBUFSIZE 1024
#define BIGBUFSIZE 20000

extern char *getenv();
extern char *tgetstr();
void putch();

main( argc, argv )
int argc;
char *argv[];
    {
    char *term, *strptr, *soptr, *septr;
    int dumb = 0;
    int iflag = 0;
    char buf[TBUFSIZE];
    static char strbuf[TBUFSIZE];
    char bigbuf[BIGBUFSIZE];
    char *grepword = NULL;
    FILE *grepstream;
    int i, j, soon, somap[BIGBUFSIZE], grepwordlen;

    /* Initialize termcap stuff. */
    if ( ! isatty( fileno( stdout ) ) )
	dumb = 1;
    else
	{
	term = getenv( "TERM" );
	if ( term == 0 )
	    dumb = 1;
	else if ( tgetent( buf, term ) <= 0 )
	    dumb = 1;
	else
	    {
	    strptr = strbuf;
	    soptr = tgetstr( "so", &strptr );
	    septr = tgetstr( "se", &strptr );
	    if ( soptr == NULL || septr == NULL )
		dumb = 1;
	    }
	}

    /* Construct grep command. */
    strcpy( bigbuf, "grep" );
    for ( i = 1; i < argc; i++ )
	{
	strcat( bigbuf, " " );
	/* (Should do some kind of quoting here.) */
	strcat( bigbuf, argv[i] );

	/* Check for -i flag. */
	if ( argv[i][0] == '-' && strchr( argv[i], 'i' ) != NULL )
	    iflag = 1;

	/* Save pointer to word we are grepping for - first non-flag arg. */
	if ( grepword == NULL && argv[i][0] != '-' )
	    {
	    grepword = argv[i];
	    grepwordlen = strlen( grepword );
	    }
	}

    /* Spawn a grep. */
    grepstream = popen( bigbuf, "r" );
    if ( grepstream == NULL )
	{
	fprintf( stderr, "%s: can't spawn grep\n", argv[0] );
	exit( 1 );
	}

    /* Now read and handle results of grep. */
    soon = 0;
    while ( fgets( bigbuf, BIGBUFSIZE, grepstream ) != NULL )
	{
	if ( dumb )
	    fputs( bigbuf, stdout );
	else
	    {
	    /* Figure out what to highlight.  This is fairly inefficient,
	    ** but since we are operating on the output of grep and not
	    ** the input, it's ok. */
	    for ( i = 0; bigbuf[i] != '\0'; i++ )
		somap[i] = 0;
	    for ( i = 0; bigbuf[i] != '\0'; i++ )
		if ( iflag )
		    {
		    if ( cistrncmp( &(bigbuf[i]), grepword, grepwordlen ) == 0 )
			for ( j = i; j < i + grepwordlen; j++ )
			    somap[j] = 1;
		    }
		else
		    {
		    if ( strncmp( &(bigbuf[i]), grepword, grepwordlen ) == 0 )
			for ( j = i; j < i + grepwordlen; j++ )
			    somap[j] = 1;
		    }

	    /* And now do the highlighting. */
	    for ( i = 0; bigbuf[i] != '\0'; i++ )
		{
		if ( somap[i] )
		    {
		    if ( ! soon )
			{
			tputs( soptr, 1, putch );
			soon = 1;
			}
		    }
		else
		    {
		    if ( soon )
			{
			tputs( septr, 1, putch );
			soon = 0;
			}
		    }
		putchar( bigbuf[i] );
		}
	    }
	}

    /* Bye. */
    if ( soon )
	tputs( septr, 1, putch );
    exit( pclose( grepstream ) );
    }

void
putch( ch )
char ch;
    {
    putchar( ch );
    }


/* cistrncmp - case-insensitive version of strncmp */

#include <ctype.h>

cistrncmp( s1, s2, n )
char *s1, *s2;
int n;
    {
    while ( --n >= 0 && (isupper(*s1)?tolower(*s1):*s1) == (isupper(*s2)?tolower(*s2++):*s2++) )
	if ( *s1++ == '\0' )
	    return 0;
    return n < 0 ? 0 : *s1 - *--s2;
    }
