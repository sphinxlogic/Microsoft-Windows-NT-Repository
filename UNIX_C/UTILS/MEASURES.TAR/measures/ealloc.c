#

/*LINTLIBRARY*/

#include "stdio.h"

#if !defined lint && !defined NOID
static char	elsieid[] = "@(#)ealloc.c	8.2";
#endif /* !defined lint && !defined NOID */

extern char *	icalloc();
extern char *	icatalloc();
extern char *	icpyalloc();
extern char *	imalloc();
extern char *	irealloc();

static char *
check(pointer)
char *	pointer;
{
	if (pointer == NULL)
		wildrexit("allocating memory");
	return pointer;
}

char *
emalloc(size)
{
	return check(imalloc(size));
}

char *
ecalloc(nelem, elsize)
{
	return check(icalloc(nelem, elsize));
}

char *
erealloc(ptr, size)
char *	ptr;
{
	return check(irealloc(ptr, size));
}

char *
ecatalloc(old, new)
char *	old;
char *	new;
{
	return check(icatalloc(old, new));
}

char *
ecpyalloc(string)
char *	string;
{
	return check(icpyalloc(string));
}

efree(p)
char *	p;
{
	ifree(p);
}

ecfree(p)
char *	p;
{
	icfree(p);
}
