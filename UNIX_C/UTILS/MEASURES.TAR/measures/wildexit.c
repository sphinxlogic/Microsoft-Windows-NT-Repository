#

/*LINTLIBRARY*/

#include "stdio.h"

#if !defined lint && !defined NOID
static char	elsieid[] = "@(#)wildexit.c	8.2";
#endif /* !defined lint && !defined NOID */

#if !defined TAMEEXITVAL
#define TAMEEXITVAL	0
#endif /* !defined TAMEEXITVAL */

#if !defined WILDEXITVAL
#define WILDEXITVAL	1
#endif /* !defined WILDEXITVAL */

wildexit(string)
char *	string;
{
	wild(string);
	for ( ; ; )
		exit(WILDEXITVAL);
}

wildcexit(string)
char *	string;
{
	wildcall(string);
	for ( ; ; )
		exit(WILDEXITVAL);
}

wildrexit(string)
char *	string;
{
	wildret(string);
	for ( ; ; )
		exit(WILDEXITVAL);
}

wild2exit(part1, part2)
char *	part1;
char *	part2;
{
	wild2(part1, part2);
	for ( ; ; )
		exit(WILDEXITVAL);
}

tameexit()
{
	for ( ; ; )
		exit(TAMEEXITVAL);
}
