#

/*LINTLIBRARY*/

#include "stdio.h"

#if !defined lint && !defined NOID
static char	elsieid[] = "@(#)wild.c	8.3";
#endif /* !defined lint && !defined NOID */

char *
wildname(name)
char *	name;
{
	register int	i;
	static char	saved[15];

	if (name != NULL && *name != '\0')
		for (i = 0; (saved[i] = *name) != '\0'; ++name)
			if ((*name == '/' || *name == '\\') &&
				*(name + 1) != '/' && *(name + 1) != '\\' &&
				*(name + 1) != '\0')
					i = 0;
			else if (i < sizeof saved - 1)
				++i;
	return (saved[0] == '\0') ? "?" : saved;
}

wild2(part1, part2)
char *	part1;
char *	part2;
{
	(void) fputs(wildname(""), stderr);
	/*
	** One space after the colon matches what perror does
	** (although your typing teacher may want a second space).
	*/
	(void) fputs(": wild ", stderr);
	if (part1 == NULL)
		part1 = "";
	if (part2 == NULL)
		part2 = "";
	(void) fputs(part1, stderr);
	if (*part1 != '\0' && *part2 != '\0')
		(void) fputs(" ", stderr);
	(void) fputs(part2, stderr);
	(void) fputs("\n", stderr);
}

wild(string)
char *	string;
{
	wild2("", string);
}

wildcall(string)
char *	string;
{
	wild2("call of", string);
}

wildret(string)
char *	string;
{
	wild2("result from", string);
}
