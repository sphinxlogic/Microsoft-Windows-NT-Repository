/* spinparse.h - internal include file for spin parser
 *
 * 20.Oct.87  jimmc  Add string stuff
 */

typedef struct _SPstreaminfo {
	int type;	/* 's' for string, 'f' for stream (file) */
	int eofflag;	/* set when no more chars in input */
	FILE *stream;
	char *string;
	char *stringget;	/* points into string */
	char *SPlinebuf;
	int SPlinebufsize;
	int SPlineno;
	SPtoken *tokenlist;	/* the line parsed into tokens */
	SPtoken *execlist;	/* list of tokens being executed */
	SPtoken *valuelist;	/* list of values in the stack */
} SPstreaminfo;

/* end */
