/* initsubs.c - this routine pulls in all of the standard spin subroutine
 * packages which are available.
 *
 * 16.Oct.87  jimmc  Initial definition
 *  4.Nov.87  jimmc  Add call to SPinitgoto
 *  5.Nov.87  jimmc  Add call to SPinitmath
 * 30.Nov.87  jimmc  Lint cleanup
 *  1.Mar.88  jimmc  Add SPversion
 */
/* LINTLIBRARY */

static char *SPversion_string = "spin v1.0 1.Mar.88";

#include "spin.h"

char *
SPversion()
{
	return SPversion_string;
}

SPinitsubs()
{
	SPdeffunc("SPversion","s",SPversion);

	SPinitgoto();	/* labels and goto */
	SPinitmath();	/* math operators */
	SPinitcont();	/* control flow */
	SPinitvars();	/* variables and function definitions */
	SPinitlist();	/* list operations */
	SPinitfile();	/* file operations */
}

/* end */
