/* goto.h - things required to use the setjmp stuff in SP
 *
 *  4.Nov.87  jimmc  Initial definition
 */

#include <setjmp.h>

/* The fact that jmp_buf is so hazily defined makes it difficult to
 * deal with pointers to jmp_bufs, etc.  The following code assumes
 * that a jmp_buf is an array of ints, so it may be machine dependent.
 */

typedef int *jmp_bufp;

extern jmp_bufp SPjbufp;
extern char *SPgotolabel;

#define jmpbuf_addr(jb) jb
#define jmpbuf_ref(jbp) jbp

/* end */
