/* exec.h - stuff for spin execution
 *
 */

typedef struct _SPfuncinfo {
	char *name;		/* name of the function */
	char *args;		/* return ard arg types */
	void (*funcp)();	/* pointer to the function */
	struct _SPfuncinfo *next;
} SPfuncinfo;

/* end */
