/*	Copyright (c) 1987, 1988 by Software Research Associates, Inc.	*/

#ifndef lint
# define FEP_STAT \
    "$Header: fep_stat.h,v 4.0 88/08/05 20:21:58 utashiro Rel $ (SRA)"
#endif lint

extern long stat_obyte;
extern long stat_ibyte;
extern long stat_rerror;
extern long stat_werror;
extern long stat_nselect;

struct statistics {
    char *info_name;
    long *info_valp;
};
