/* $Header: EXTERN.h,v 3.0 89/10/18 15:33:37 lwall Locked $
 *
 *    Copyright (c) 1989, Larry Wall
 *
 *    You may distribute under the terms of the GNU General Public License
 *    as specified in the README file that comes with the perl 3.0 kit.
 *
 * $Log:	EXTERN.h,v $
 * Revision 3.0  89/10/18  15:33:37  lwall
 * 3.0 baseline
 * 
 */

#undef EXT
#define EXT extern

#undef INIT
#define INIT(x)

#undef DOINIT
