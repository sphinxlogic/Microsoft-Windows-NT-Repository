#include <stdio.h>

static char SCCSid[] = {"@(#)substr.c v1.2 - 11/16/87"};

main (argc, argv)
    int  argc;
    char *argv[];
{
    register char *ptr;
    register char ch;
    int start, end;	/* first and last character to extract */
    int slen;		/* string length */

    if (argc < 4)
	exit (0);
    start = atoi (argv[2]);
    end = atoi (argv[3]);
    slen = strlen(argv[1]);
    if (slen == 0) exit(1);

    /* test for special values */
    if (start < 0)
        start += slen + 1;
    if (end == 0)
        end = slen - start + 1;
    else if (end < 0)
        end += slen - (start - 1);

    /* validate the values */
    if (start < 1 || end < 1)
	exit (1);

    ptr = argv[1] + start - 1;
    while (end-- && (ch = *ptr++))
	putchar (ch);
    putchar ('\n');
    exit(0);
}
