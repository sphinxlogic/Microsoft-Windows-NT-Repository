#!/bin/sh

[ "x`echo -n x`" = "x-n x" ] && {
	C=\\c
	N=
} || {
	C=
	N=-n
}

echo $N 'Into which directory do you want "ctrl" c.s. to be placed? '$C

while :
do
	read dir
	[ = = "$dir" -o != = "$dir" ] && dir=./$dir
	[ -d "$dir" -a -x "$dir" -a -w "$dir" ] && break
	echo "There is no writable directory '$dir'."
	echo $N 'Try again: '$C
done

mv ctrl "$dir" || exit 1

cd "$dir" || exit 1

ln ctrl unesc
ln ctrl esc
ln ctrl bell
ln ctrl beep
