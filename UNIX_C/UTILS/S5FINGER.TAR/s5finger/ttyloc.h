/*
** ttyloc.h - For the finger distribution.
**
** Written by Keith Gabryelski
** Released into public domain September 1, 1988.
** Please keep this header.
*/

#define TTYLOCS		"/etc/ttylocs"
#define LTMP		"/etc/ltmp"

#define	DEFAULT_TTYLOC_FILE	".ttylocs"
#define	TTYLOC_LENGTH		50

struct ltmp
{
    char	lt_line[12];		/* Ttyname. */
    char	lt_loc[TTYLOC_LENGTH];	/* Ttyloc string. */
    time_t	lt_time;		/* Time stamp from utmp. */
};

extern char *get_ttyloc();
extern int set_ttyloc();
