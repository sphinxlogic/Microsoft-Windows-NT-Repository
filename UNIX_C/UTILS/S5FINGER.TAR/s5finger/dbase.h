/*
** dbase.h - For the finger distribution.
**
** Written by Keith Gabryelski
** Released into public domain September 1, 1988.
** Please keep this header.
*/

/*
** The finger structure.
*/

struct finger
{
    int valid_whois;	/* Is this whois entry valid? */
    int pid;		/* Process id. */
    char uname[8];	/* User name. */
    ushort uid;		/* User ID of user. */
    char gname[12];	/* Group name. */
    ushort gid;		/* Group ID of user. */
    char flname[30];	/* Full name. */
    int messy;		/* Messages on?. */
    char ttyname[12];	/* Name of controlling tty device. */
    long idletime;	/* Idle time of tty device. */
    char idle[9];	/* string for the idle time. */
    char what[14];	/* Currently running program. */
    char ttyloc[TTYLOC_LENGTH];	/* Informative tty location. */
    char *nickname;	/* Nickname of user. */
    char *home_dir;	/* Home directory. */
    char *login_shell;	/* Login Shell. */
    char *work_addr;	/* Work address. */
    char *work_phone;	/* Work phone. */
    char *home_addr;	/* Home address. */
    char *home_phone;	/* Home phone. */
    char *birthday;	/* Birthday. */
    char *project;	/* Current Project. */
    char *supervisor;	/* Supervisor. */
    char *remark;	/* Ramblings. */
    struct finger *next;/* Next struct in the linked list. */
};
