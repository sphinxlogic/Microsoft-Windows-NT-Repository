main(){
	int a[4];
	int numfnd = -1;
	int this, found[10000];
	int t;
	int p,q,r,s,i,j,k,l,n;
	for(i=0;i<10;i++)
		for(j=0;j<10;j++)if(i==j)continue;
		else
			for(k=0;k<10;k++)
				for(l=0;l<10;l++)if(k==l)continue;
				else
				{
					p=i*10+j;
					q=k*10+l;

					r=j*10+i;
					s=l*10+k;
					if(p==r || p==s ||q==r||q==s)continue;
					else
						if((n=p*q) == r*s){
							int i,j;
							/*bingo*/
							a[0]=p;
							a[1]=q;
							a[2]=r;
							a[3]=s;
xxx:
							for(i=0;i<4;i++)for(j=i;j<4;j++)if(a[i]>a[j]){
								t=a[i];
								a[i]=a[j];
								a[j]=t;
								goto xxx;
							}
							/*printf("%d %d %d %d %d  " ,p,q,r,s,n);*/
							this=a[0]*1000000+a[1]*10000+a[2]*100+a[3];
							if(numfnd== -1){
								found[++numfnd]=this;
								printf("%d %d\n",a[0],n);
								continue;
							}
							else{
								t=0;
								for(i=0;i<=numfnd;i++)if(found[i]==this)t=1;
							}
							if(!t)
							{
								found[++numfnd]=this; 
								printf("%d %d\n",a[0],n);
							}
							else /*putchar('\n')*/ ;
						}
				}


}
