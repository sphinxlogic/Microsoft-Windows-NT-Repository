main(){
	char line[256];
	int i;
	char *gets();
	while(gets(line)==line){
		i=0;
		while(line[i]>=' ' || line[i]=='\t')i++;
		i--;
		while(i>=0){putchar(line[i--]);}
		putchar('\n');
	}
}
