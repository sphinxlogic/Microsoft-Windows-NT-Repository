main(){
	int ii,jj,kk,a,b,M,N,i,j,k;
	int abin,bbin,nbin[200],bin[200][30];

	scanf("%d%d",&M,&N);
	for(i=1;i<=N;i++){
		bin[i][1]=i;
		nbin[i]=1;
	}
	for(kk=1;kk<=M;kk++){
		if(scanf("%d%d",&a,&b)!=2)exit(1);
		ii=jj=0;
		for(i=1;i<=N;i++){
			if(nbin[i]<1)continue;
			for(j=1;j<=nbin[i];j++)
				if(bin[i][j]==a){
					ii=i;
					jj=j;
				}
		}
		if(ii==0||jj==0){
			printf("oops a=%d b=%d ii=%d jj=%d i=%d j=%d nbin[ii]=%d\n"
			    ,a,b,ii,jj,i,j,nbin[ii]);
			exit(2);
		}
		/*bin[ii][jj]=0;*/
		abin=ii;
		ii=jj=0;
		for(i=1;i<=N;i++){
			if(nbin[i]<1)continue;
			for(j=1;j<=nbin[i];j++)
				if(bin[i][j]==b){
					ii=i;
					jj=j;
					break;
				}
		}
		if(ii==0||jj==0){
			printf("oops ii=%d jj=%d i=%d j=%d nbin[ii]=%d\n"
			,ii,jj,i,j,nbin[ii]);
			exit(3);
		}
		bbin=ii;
		for(j=1;j<=nbin[abin];j++)bin[bbin][++nbin[bbin]]=bin[abin][j];
		nbin[abin]=0;
	}
	for(i=1;i<=N;i++)
	{
		k=nbin[i];
		if(k<1)continue;
		if(k>=2){
			int l,m;
			for(l=1;l<k;l++)for(m=l+1;m<=k;m++)if(bin[i][l]>bin[i][m]){
				int t; 
				t=bin[i][l]; 
				bin[i][l]=bin[i][m]; 
				bin[i][m]=t;
			}
		}
	}
	for(i=1;i<=N;i++)
	for(kk=1;kk<=N;kk++)
	if(nbin[kk]<1)continue; else{
		if(bin[kk][1]==i){
			for(j=1;j<=nbin[kk];j++) printf(" %d ",bin[kk][j]);
			puts("");

		}
		}

}
