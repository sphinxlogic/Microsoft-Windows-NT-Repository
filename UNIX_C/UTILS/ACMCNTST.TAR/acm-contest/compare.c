#include <stdio.h>
#define tab '\t'
#define null '\0'
#define newline '\n'
main(argc,argv)
char **argv;
{
	FILE *fpa, *fpb;
	char linea[200], lineb[200];
	char tempa[200], tempb[200];

	char *p, *q;
	int eofa=0,eofb=0;
	int compare;
	if(argc!=3)exit(1);

	fpa=fopen(argv[1],"r");
	if(fpa==(FILE *)0)exit(2);

	fpb=fopen(argv[2],"r");
	if(fpb==(FILE *)0)exit(3);
	eofa=eofb=0;
	compare=0;
read:
	if(!eofa)if(fgets(linea,199,fpa)!=linea)eofa=1;
	if(!eofb)if(fgets(lineb,199,fpb)!=lineb)eofb=1;
	if(eofa && eofb)exit(compare);

	if(eofa&& !eofb)exit(4);
	if(eofb&& !eofa)exit(5);
	if(eofa || eofb)exit(6);

for(p=linea;*p;p++){if(*p==tab) *p=' ';if(*p==newline) *p=0;}
for(p=lineb;*p;p++){if(*p==tab) *p=' ';if(*p==newline) *p=0;}
	p=linea;
	q=lineb;
tightloop:
	while(*p==' ' || *p==tab || *p==newline)p++;
	while(*q==' ' || *q==tab || *q==newline)q++;
	if(*p!= *q){
		printf("them: %s\n",linea);
		printf("  us: %s\n",lineb);
		compare=1;
		puts("------------------------------------");
		goto read;
		}
	else{
		p++;
		q++;
		if(*p==null)if(*q==null)goto read;
		goto tightloop;
	}

}
