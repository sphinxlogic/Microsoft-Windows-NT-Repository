main(){
	int a[500];
int	m,n,i,j,num,pn,M,N;
for(pn=0;pn<4;pn++){
	scanf("%d%d",&M,&N);
	n=N;
	m=M;
	for(i=1;i<=n+1;i++)a[i]=i;

loop:
	if(m>n)m=1;
	printf("%d ",a[m]);
	for(j=m;j<=100;j++)a[j]=a[j+1];
	n--;
	if(m>n)m=1;
	if(n==1){printf(" %d\n", a [m]);continue;}
	for(i=1;i<=M-1;i++){if(m>n)m=1;m++;if(m>n)m=1;}
	goto loop;




}
}
