main(){
/*	integer odds(100),evens(100)*/
	int odds[101],evens[101];
	int k; /*had to be added... fortran implicitly declared it*/
/*	integer a*/
	int a;
/*	integer i,j*/
	int i,j;

/*	i=1*/
/*	j=1*/
	i=j=1;
/*	do 10 k=1,100*/
	for(k=1;k<=100;k++)odds[k]=evens[k]= -1;
/*	odds(k)= -1*/
/*10	evens(k)= -1*/

/*1	read*,a*/
loop: scanf("%d",&a);
/*	if(a.lt.0)goto 4*/
	if(a<0)goto out;
/*	if( mod(a,2) .eq. 0)goto 2*/
/*	odds(i)=a*/
/*	i= i+1*/
/*	goto 3*/
/*2	evens(j)=a*/
/*	j=j+1*/
/*3	continue*/
	if(a%2)odds[i++]=a;
	else evens[ j++]=a;
/*	goto 1*/
	goto loop;

/*4	continue*/
out:
/*	j = max(i,j) -1*/
	j= (j>i?j:i)-1;
	for(i=1;i<=j;i++)
/*	do 5 i=1,j*/
/*	print*,odds(i),evens(i)*/
	printf("%d %d\n",odds[i],evens[i]);
/*5	continue*/
/*	stop*/
/*	end*/
exit(0);
}
