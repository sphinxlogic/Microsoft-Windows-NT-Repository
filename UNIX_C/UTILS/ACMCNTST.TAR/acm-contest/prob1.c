main()
{
	int *left, *right, *doub;
	int l,m, i=0,j,k;
	int nd=0;
	char *malloc();
left=(int *)malloc(500*sizeof(int));
right=(int *)malloc(500*sizeof(int));
doub=(int *)malloc(500*sizeof(int));

	for(i=0;i<500;i++)doub[i]=0;
	i=0;
	while( scanf("%d%d",&j,&k)==2)
	if(j>=0 && k>=0){left[i]=j; right[i]=k; i++;}
	else break;
	i--;
	for (j=0;j<=i;j++)
	{
		k=left[j];
		for(m=0;m<=i;m++)if(k==right[m]){doub[nd++]=k;break;}
	}
	if(nd){
/*		for(i=0;i<nd;i++)if(doub[i])printf("%d\n",doub[i]);*/

		if(nd>=2){
			for(i=0;i<nd-1;i++)
			for(j=i+1;j<nd;j++)
			if(doub[i]>doub[j]){k=doub[i];doub[i]=doub[j];doub[j]=k;}
			else {}
		}else printf("%d\n",doub[0]);

	}else{}
	doub[nd]= -1;
/*		for(i=0;i<nd;i++)if(doub[i])
printf("%d\n",doub[i]);
*/

k= -1;

	for(i=0;i<nd;i++)if(doub[i]!=doub[i+1])
printf("%d\n",doub[i]);

	return 0;
}
