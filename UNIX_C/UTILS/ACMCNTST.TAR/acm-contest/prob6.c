main(){
	int i,j;
	int lt,gt,a[4];
	while( scanf("%d%d%d%d",&a[0],&a[1],&a[2],&a[3])==4){
	if(a[0]<0)exit(0);
	gt=lt=0;
	for(i=0;i<=2;i++)for(j=i+1;j<=3;j++){
	if(a[i]<a[j])lt++;
	if(a[i]>a[j])gt++;
	}
	printf("%d %d %d %d %d %d\n",a[0],a[1],a[2],a[3],lt,gt);
	}
	}
