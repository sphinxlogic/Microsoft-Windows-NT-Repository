#include <stdio.h>
/*#include <fcntl.h>*/
#include <signal.h>
/*#include <sys/wait.h>*/
int k;
main(argc,argv)
char **argv;
{
	int childstatus(),oops();
	setuid(getuid());
	k=fork();
	if(k){
		signal(SIGALRM,oops);
#ifndef SIGCHLD
#define SIGCHLD SIGCLD
#endif
/*CHLD=20 for dynix, CLD=18 for SysV2*/
/* anyway what we want is to catch "death of child" signal*/
		signal(SIGCHLD,childstatus);
		alarm(10);
		wait(0);}
	else
		execl(argv[1],"dumbo",0);
}
childstatus(sig,code,x)
{
	int i,j,m;

	fprintf(stderr,"sig=%d,code=%d, k=%d\n",sig,code,k);

	for(i=0;i<200;i++){
		j=k+i;
		j= j % 32768;
		if(j>1){
			m=kill(j,9);
			if(m>=0)fprintf(stderr,"killed %d ",j);
			}
		}

	exit(0);
}
oops(sig,code,x)
{
	fprintf(stderr,"sig=%d,code=%d\n",sig,code);
	fprintf(stderr,"there may be a daemon attack underway\n");
	fprintf(stderr,"kill %d\n",k);
	childstatus(sig,code,x);
	exit(1);
}

