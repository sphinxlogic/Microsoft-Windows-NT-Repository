#include <stdio.h>
main(argc,argv)
char *argv[];
{
	int i,k;
	char *p,*q;
	if(argc!=2)exit(1);
	p=argv[1];
	q=p;
	p +=strlen(p)-1;
	while(p>=q && *p!='/')p--;
	p++;
	for(;*p;p++)if(*p>='0' && *p<='9')break;
	if(!*p){putchar('-');return;}
	while(*p>='0' && *p<='9'){putchar(*p);p++;}
}
