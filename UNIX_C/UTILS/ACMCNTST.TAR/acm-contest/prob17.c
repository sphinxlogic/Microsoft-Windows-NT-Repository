#include <stdio.h>
main(){
	int z,s,x[4],y[4],tx,ty,xi,yi,abig,area();
	char *p;
	int t=0,i,k;
	while( scanf("%d%d",&x[1],&y[1]) == 2){
	scanf("%d%d",&x[2],&y[2]);
	scanf("%d%d",&x[3],&y[3]);
	t++;
	for(k=1;k<=7;k++){
	scanf("%d%d",&tx,&ty);
	abig=area(x,y);
	s=(int)0;
	for(i=1;i<=3;i++){
		xi=x[i];
		x[i]=tx;
		yi=y[i];
		y[i]=ty;
		s +=area(x,y);
		x[i]=xi;
		y[i]=yi;

	}
	z=s-abig;
	if(z<0)z= -z;
	if(z==0){
/*	fprintf(stderr,"yes\n");*/
	p="inside";}
	else {
/*	fprintf(stderr,"no\n");*/
	p="outside";}
	printf("%d %d is %s triangle %d\n",(int)(tx),(int)(ty),p,t);
/*	fprintf(stderr,"\n");*/
	}
	}
}
int area(x,y)
int x[],y[];
{
	int z;
	z= (x[1]*y[2]-x[1]*y[3]+x[2]*y[3]-x[2]*y[1]+x[3]*y[1]-x[3]*y[2]);
/*	z= z ;*/
	if(z<0)z = -z;
/*	fprintf(stderr,"area=%d ",z);*/
	return z;
}
