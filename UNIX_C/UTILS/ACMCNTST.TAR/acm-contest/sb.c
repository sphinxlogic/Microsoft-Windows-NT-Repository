#include <stdio.h>
#define newline '\n'
#define blank ' '
#define tab '\t'
#define indent {myputs(line);ilev++;goto lbl;}
#define undent {ilev--;myputs(line);goto lbl;}
int ilev = 0;
main(argc,argv) char **argv;
{
	char line[512], *a;
	int i;

	while(gets(line)==line){
	a=line;
	while(*a){if(*a==newline)*a=0; a++;}
		if(endsin(line,"then")==0){
			indent		}
		if(endsin(line,"else")==0){
			
			ilev--; myputs(line); ilev++;goto lbl;
			}
		if(endsin(line,"fi")==0){
			undent		}
		if(endsin(line,"done")==0){
			undent		}
		if(endsin(line,"do")==0){
			indent		}
		if(begins(line,"case")==0){
			indent		}
		if(endsin(line,"esac")==0){
			undent		}
	myputs(line);
lbl: ;
	}
}
myputs(p)char *p;
{
	int i;
	while(*p==blank ||*p==tab)p++;
	if(ilev>0)for(i=1;i<=ilev;i++)printf("   ");
/*	printf("%d",ilev);*/
	puts(p);
}

endsin(a,b)
char *a, *b;
{
	char *aa;
	int i;
	aa=a;
	while(*aa==blank || *aa==tab)aa++;
	if(strlen(a)<strlen(b))return -1;
	a = a +strlen(a)-strlen(b);
	i= kindex(a,b);
	if(strlen(aa)==strlen(b))return i;
	a--;
	if(*a==tab||*a==';'||*a==blank)return i; else return -1;
/*	printf("in endsin, a=%s b=%s returning %d\n",a,b,i);*/
/*	fflush(stdout);*/
/*	return i;*/

}
	




begins(a,b)
char *a, *b;
{
	int i;
	while(*a==blank || *a==tab)a++;
	return kindex(a,b);

}
	



kindex(s,t) 
char s[],t[];
{
	int c,i,j,k;
	c=s[0];
	if(c==0){return -1;
/*		i=puts("in kindex ... dummy, s[0] is zero");j=i;*/
/*		puts(t);*/
/*		if(i==j)exit(1);*/
		}
	c=t[0];
	if(c==0){return -1;
/*	i=puts("in kindex ... dummy, t[0] is zero");j=i;*/
/*		puts(s);*/
/*		if(j==i)exit(1);*/
		}
	for(i=0;s[i] !='\0'; i++){
		for(j=i,k=0;t[k] !='\0' && s[j]==t[k];j++,k++)
				;
		if(t[k]=='\0')return (i);
	}
		return(-1);
} 
