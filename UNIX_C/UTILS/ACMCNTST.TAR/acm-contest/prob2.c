main()
{
	char line[99];

	int count[256];
	int i;
		char *gets();

	for(i=0;i<256;i++)count[i]=0;
	while( gets(line)==line )
		for(i=0;line[i] && line[i]!='\n';i++)
			count[ line[i] ]++;
		
	printf("%5d%5d\n",'\t',count['\t']);
	for(i=' ';i<0177;i++) if(count[i])printf("%5d%5d\n",i,count[i]);
	exit(0);
}
