#define CURVERS 21
#define HOURS 4
#include <stdio.h>
#include <sys/types.h>
#ifdef sequent
#include <sys/time.h>
#else
#include <time.h>
#endif
int prob,team;
char *let[4] = {
	"   ","beg","int","adv"};
int category[31];

main()
{
	char *malloc();
	char *end;
	FILE *fopen(), *fp ;
	int sus,finish;
	long version,starttime;
	char *teamnames[31], *strcpy();
	time_t ct,ct1;
	long time();
	int solvedat[31][19];
	int penal[31],nfail[31],nworked[31];
	int i,k;
	long  endcontest;
	char temp[81];

	for(team=1;team<=30;team++){
		penal[team]=0;
		nfail[team]=0;
		nworked[team]=0;
		teamnames[team]=(char *)0;
		for(prob=1;prob<=18;prob++)solvedat[team][prob]=0;
	}

	if ((fp= fopen(SCOREBOARD,"r")) == NULL) {
		printf("Can not open scoreboard file [%s].\n",SCOREBOARD);
		exit(1);
	} 

	if ( fscanf(fp,"%d",&version) != 1) {
		printf("Can not read version from scoreboard\n");
		exit(2);
	}
	if (version!=CURVERS){
		puts("an old version perhaps?");
		exit(8);
	}
	for(i=1;i<=30;i++){
		if( fscanf(fp,"%d%d%s",&team,&k,temp) != 3){
			printf("%d%d%s\n",team,k,temp);exit(3);}
			if(team==99)team=0;
		if(k<0){
		break;
		}
		else {
		if(team==99)team=0;
		category[team]=k;
		teamnames[team]=malloc((unsigned)(strlen(temp)+2));
		(void)strcpy(teamnames[team],temp);
		}
	}

	if(1!=fscanf(fp,"%ld",&starttime))exit(5) ;
	endcontest=starttime+HOURS*3600;
	ct = time((long *)0);
	ct1=ct;
	end="ends ";
	if(ct>endcontest){ct=endcontest;end="ended";}

	while ( fscanf(fp,"%d %d %d %d",&sus,&team,&prob,&finish) == 4) {
		if(team==99)team=0;
		if (sus) { 
			solvedat[team][prob]=finish;
		}
		else{
			nfail[team]++;
			penal[team] += 10;
		}
	}/*end of file*/

	(void) fclose(fp);

	for(team=1;team<=30;team++)
		if(category[team])
			for(k=prob=category[team]*6-5;prob<k+6;prob++)
				if(solvedat[team][prob])
				{
					penal[team] +=(solvedat[team][prob]-starttime)/60;
					nworked[team]++;
				}
				else
				{
		penal[team] += (ct  - starttime)/60;
				}

	printf("\n                    the scoreboard \n\n");
	printf("                %s\n",ctime((time_t *)&ct1));
	printf("        contest began %s",ctime( (time_t *) &starttime));
	printf("        contest %s %s\n",end,ctime( (time_t *) &endcontest));
	printf(
	"team class  #fail   penal  #solved   which           who\n");
	for(i=3;i>=1;i--)
	/*if(i!=2)*//*this line eliminates the intermediate category*/
	{
		puts("");
		for(team=1;team<=15;team++)
			if(category[team]==i)
			{
				printf("%3d  %s %5d%11d     %d  "
				    ,team,let[category[team]],nfail[team],
				penal[team],
				nworked[team]);
				if(category[team])
					for(k=prob=category[team]*6-5;prob<k+6;prob++)
						if(solvedat[team][prob])printf("%3d", prob);
						else printf("  .");
				if(teamnames[team]){
					(void)putchar(' ');
					(void)putchar(' ');
					puts(teamnames[team]);
				}
				else printf("\n");
			}
	}

}
