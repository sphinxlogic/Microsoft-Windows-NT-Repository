main(){
	int oldop,mask,flag;
#define newline '\n'
#define null '\0'
	/*
From norris Fri Nov 11 11:06:03 1988
Binary-binary

    Mathematicians refer to addition and subtraction as binary
operations.  Since computer scientists like to take things much
farther than they were intended, you are going to write a
binary binary calculator.
    This calculator program will accept infix expressions involving
only + and - and unsigned binary integers.  No parentheses or
other operations will be present.  You must compute the value
of the expression and display the result in binary.  Negative
results should be printed with a leading minus sign.
    Data considerations:
      Input will consist of an unspecified number of expressions,
   one per line; end-of-file will indicate the end of data. Each
   expression will contain no leading or embedded blanks.  No
   expression will contain more than 80 characters.  The
   expression values are to be computed left-to-right.  No
   number or intermediate value will require more than 15 bits
   of precision.  Output should start in column 1 of the 
   output file, one result per line, with no leading zeroes.

Example:
   the input expression:   110+11-1+100
   results in the output
1100

   the input expression:   1100-11000+111-10
   results in the output
-111
*/
	char line[90];
	int sum,n;
	char *p;
	char *gets();
	while(  gets(line)==line  ){
		p=line;
		n=0;
		for(p=line,n=0,sum=0,oldop='+';;p++) {
			switch(*p){
			case '-':
			case '+':
				if(oldop=='+')sum += n; 
				else sum -=n; 
				n=0; 
				oldop= *p;
				break;
			case '0': 
				n= n* 2; 
				break;
			case '1': 
				n= n*2+1; 
				break;
			case newline:
			case 0:
				if(oldop=='+')sum += n; 
				else sum -=n; 
				goto out;
/*				n=0; */
/*				oldop= *p;*/
				break;
			default: 
				;
			}
		}
out: /*printf("%d\n",sum);*/
		;
		if(sum==0){
			putchar('0');
			putchar(newline);
			continue;
		}
		if(sum<0){
			putchar('-'); 
			sum = - sum;
		}
		for(mask=0100000, flag=0; mask; mask >>=1){

			if(sum & mask ){
				putchar('1');
				flag=1;
			} else if(flag)putchar('0');
		}
		putchar(newline);

	}/*endwhile gets*/
}/*end main*/
