#include <stdio.h>
#define zero '0'
#define nine '9'
main(argc,argv)
char *argv[];
{
	int i,k;
	char *p,*q;
	if(argc!=2)exit(1);
	p=argv[1];
	putchar('t');
	while( *p &&(*p<zero || *p>nine))p++;
	while(*p &&(*p>=zero && *p<=nine)){putchar(*p);p++;}
	putchar('p');
	while( *p &&(*p<zero || *p>nine))p++;
	while(*p &&(*p>=zero && *p<=nine)){putchar(*p);p++;}
}
