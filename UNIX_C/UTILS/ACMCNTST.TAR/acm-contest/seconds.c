main(){
	long time(), t;
	printf("%ld\n",time( (long *) 0 ));
	}
