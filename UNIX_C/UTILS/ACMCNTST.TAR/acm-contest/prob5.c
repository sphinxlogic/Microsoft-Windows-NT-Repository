main()
{
	char line[256];
	int i,j,wc;
	char *gets();
	
	while( gets(line)==line)
	{
		if(strlen(line)==0){printf("0\n");continue;}
		i=0;
		wc=0;
	for(i=0;line[i];i++){
	if(line[i]>='a' && line[i]<='z'){
						if(line[i+1]<'a' ||line[i+1]>'z')wc++;
			}
	}
	printf("%d\n",wc);
	}
}

