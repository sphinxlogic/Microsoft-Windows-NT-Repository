/*
 * Created 1989 by greg yachuk.  Placed in the public domain.
 */

#include <stdio.h>
#include <malloc.h>

#include "mdiskio.h"

/*
 * _mdgetbuf -	allocate a buffer of given size.  if that fails,
 *		allocate a buffer of standard size.  if *that*
 *		fails, use a single characte buffer (in the struct).
 *
 * returns:	size of buffer allocated
 */
_mdgetbuf(mdp, blen)
MDFILE *mdp;
int	blen;
{
	mdp->flags |= _MDEMPTY;

	if ((mdp->buffer = malloc(blen)) == NULL && blen > BUFSIZ)
	{
		blen = BUFSIZ;
		mdp->buffer = malloc(BUFSIZ);
	}

	if (mdp->buffer == NULL)
	{
		mdp->buffer = &mdp->spare;
		return (1);
	}

	return (blen);
}
