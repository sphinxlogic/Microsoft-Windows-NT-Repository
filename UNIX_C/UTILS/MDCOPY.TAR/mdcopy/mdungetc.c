/*
 * Created 1989 by greg yachuk.  Placed in the public domain.
 */

#include <stdio.h>
#include "mdiskio.h"

/*
 * mdungetc -	push back a character into the input stream.
 *		this is not guaranteed for more than one character.
 */
mdungetc(c, mdp)
int	c;
MDFILE *mdp;
{
	if (mdeof(mdp))
		return (EOF);
	*--mdp->bufptr = c;
	++mdp->bufcnt;
	return (c);
}
