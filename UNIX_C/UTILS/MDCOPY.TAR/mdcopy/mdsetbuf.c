/*
 * Created 1989 by greg yachuk.  Placed in the public domain.
 */

#include <stdio.h>
#include <malloc.h>

#include "mdiskio.h"

mdsetbuf(mdp, blen)
MDFILE *mdp;
int	blen;
{
	if (mdp->buffer != NULL)
		return (1);		/* already has a buffer */

	if ((mdp->buffer = malloc(blen)) == NULL)
		return (2);		/* not enough memory */

	/* calculate the end pointer */
	mdp->bufptr = mdp->buffer + blen;

	/* indicate an empty buffer */
	mdp->flags |= _MDEMPTY;

	/* indicate that all is well */
	return (0);
}
