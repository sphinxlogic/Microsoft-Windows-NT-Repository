/*
 * Created 1989 by greg yachuk.  Placed in the public domain.
 */
#include <stdio.h>
#include <fcntl.h>
#include "mdiskio.h"

char   *_mdfilenm();
int	_mdprompt();

MDFILE	_mdstdin =
{
	(char *) 0x0400,	/* bufptr */
	(int) 0,		/* bufcnt */
	(char *) NULL,		/* buffer */
	(char *) "stdin",	/* basename */
	(char *) NULL,		/* filename */
	(int) 0,		/* seq */
	(char) 0,		/* fid for stdout */
	(char) 0,		/* spare */
	(char) _MDREAD,		/* oflag */
	(char) O_RDONLY,	/* flags */
	_mdfilenm,		/* filenm() */
	mdateof,		/* ateof() */
	_mdprompt,		/* prompt() */
};

MDFILE	_mdstdout =
{
	(char *) 0x0400,	/* bufptr */
	(int) 0,		/* bufcnt */
	(char *) NULL,		/* buffer */
	(char *) "stdout",	/* basename */
	(char *) NULL,		/* filename */
	(int) 0,		/* seq */
	(char) 1,		/* fid for stdout */
	(char) 0,		/* spare */
	(char) _MDWRITE,	/* oflag */
	(char) O_CREAT|O_TRUNC|O_WRONLY,	/* flags */
	_mdfilenm,		/* filenm() */
	mdateof,		/* ateof() */
	_mdprompt,		/* prompt() */
};

MDFILE	_mdstderr =
{
	(char *) 0x0400,	/* bufptr */
	(int) 0,		/* bufcnt */
	(char *) NULL,		/* buffer */
	(char *) "stderr",	/* basename */
	(char *) NULL,		/* filename */
	(int) 0,		/* seq */
	(char) 2,		/* fid for stdout */
	(char) 0,		/* spare */
	(char) _MDWRITE,	/* oflag */
	(char) O_CREAT|O_TRUNC|O_WRONLY,	/* flags */
	_mdfilenm,		/* filenm() */
	mdateof,		/* ateof() */
	_mdprompt,		/* prompt() */
};
