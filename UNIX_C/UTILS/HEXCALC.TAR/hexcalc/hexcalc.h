
/*	hexcalc.h	include file supporting the calculator utility hexcalc
 */

#ifdef DEBUG
#define STATIC
#else
#define STATIC static
#endif

typedef unsigned long BASE_TYPE;

BASE_TYPE dec(), oct(), hex();
BASE_TYPE ulpow();

typedef struct Symbol		/* symbol table entry */
{
	char *name;
	short type;		/* VAR, BLTIN, UNDEF */
	union
	{
		BASE_TYPE val;	/* if VAR */
		BASE_TYPE (*ptr)();	/* if BLTIN */
	} u;
	struct Symbol *next;	/* to link to another */
} Symbol;

Symbol *install(), *lookup();
