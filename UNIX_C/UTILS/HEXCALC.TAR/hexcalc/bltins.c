
/*	bltins.c	hexcalc built-in functions
 */

#include "hexcalc.h"

/******************************************************************************/
BASE_TYPE dec(val)
BASE_TYPE val;
{
	printf("\t%lu\n", val);
	return val;
}

/******************************************************************************/

BASE_TYPE oct(val)
BASE_TYPE val;
{
	printf("\t%lo\n", val);
	return val;
}

/******************************************************************************/

BASE_TYPE hex(val)
BASE_TYPE val;
{
	printf("\t%lx\n", val);
	return val;
}
