typedef union {
  BASE_TYPE val;	/* actual value */
  Symbol *sym;		/* symbol table pointer */
} YYSTYPE;
#define NUMBER	257
#define CONST	258
#define VAR	259
#define BLTIN	260
#define UNDEF	261
#define QUIT	262
#define HELP	263
#define CHRADIX	264
#define LSH	265
#define RSH	266
#define UNARYMINUS	267
#define POW	268
extern YYSTYPE yyval, yylval;
