/* dlists.c - generate date lists for various things
 *
 *  4.Jan.88  jimmc  Initial definition
 */

#include <stdio.h>
#include "geneal.h"

extern char *convertidate();

int
bdlist1(sdate,name,idate)
char *sdate;
char *name;
int idate;
{
	char *cnvdate;

	if (idate>0)
		cnvdate = convertidate(idate);
	else
		cnvdate = sdate;
	fprintf(outfp,"    %-24s%s\n", cnvdate, name);
	return 0;
}

int
bdlist(idcount,idlist)
int idcount;		/* number of entries in idlist */
int *idlist;		/* array of id numbesr */
{
	int i;
	char *bdate, *name;

	dsortinit();
	for (i=0; i<idcount; i++) {
		bdate = fgstr(idlist[i],"B");
		name = fgfname(idlist[i]);
		if (bdate&&bdate[0] || name&&name[0])
			dsortadd(bdate,name);
	}

	fprintf(outfp,"                     BIRTHDAYS\n\n");
	dsortenum(bdlist1);
}

int
annlist(idcount,idlist)
int idcount;		/* number of entries in idlist */
int *idlist;		/* array of id numbesr */
{
	int i;
	char *bdate, *name;

	dsortinit();
	for (i=0; i<idcount; i++) {
		bdate = fgstr(idlist[i],"M");
		name = fglpname(idlist[i]);
		if (bdate&&bdate[0] || name&&name[0])
			dsortadd(bdate,name);
	}

	fprintf(outfp,"                     ANNIVERSARIES\n\n");
	dsortenum(bdlist1);
}

/* end */
