/* dataman.h - include file for dataman structures */
/* Written by Jim McBeath (jimmc) at SCI */
/* last edit 24-Jan-85 08:02:52 by jimmc (Jim McBeath) */
/* Revision history:
 * 24-Jan-85	Jim McBeath	remove from dataman.c to create dataman.h
 */

/* stdio must be included before this file is included */

#ifndef DATAMANH	/* safe for double inclusions */
#define DATAMANH

struct dpoint {
    FILE *ff;		/* which data file to read */
    struct toplevel *xx;		/* pointer for index routine */
    };

struct drecord {
    int numfields;	/* number of name/value pairs */
    char **name;	/* array of pointers to name strings */
    char **value;	/* array of pointers to value strings */
};

#endif DATAMANH

/* end */
