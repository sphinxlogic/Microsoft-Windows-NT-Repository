/* geneal.h - general include stuff for geneal modules
 * Written by Jim McBeath (jimmc) at SCI
 *
 * Revision history:
 * 24-Jan-85	Jim McBeath	use dpoint instead of int for gendp
 * 17.Aug.87  jimmc  Add reference to fglname
 * 18.Aug.87  jimmc  Add Group structure
 *  8.Sep.87  jimmc  Add fgtnote
 * 18.Sep.87  jimmc  Add fgaddrphn
 * 27.Oct.87  jimmc  Add fggen, outfp
 *  1.Jan.88  jimmc  Add fglpname
 *  4.Jan.88  jimmc  Add fglhname
 *  8.Jan.88  jimmc  Add sepstr
 * 19.Jan.88  jimmc  Remove dpoint/gendp stuff
 */

/* global variables */
extern char Gflag[];		/* various mode and debug flags */
extern FILE *outfp;	/* the stream to outputo */
extern char *sepstr;	/* separator string between info pages */

/* declare functions */
char *index();

char *getData();
char *strsav();
char *tprintf();

char *fgstr();
char *fgtname();
char *fglname();
char *fglpname();
char *fglhname();
char *fgbname();
char *fgfname();
char *fgbirth();
char *fgdeath();
char *fgburied();
char *fgbrtdeath();
char *fgmarriage();
char *fgnmarriage();
char *fgtnote();
char *fggen();
char *fgaddrphn();

/* a structure for lists of id numbers */
typedef struct _group {
	int count;	/* number of used entries in the array */
	int alloc;	/* size of the array (number of entries) */
	int *n;		/* pointer to array of ints */
} Group;

/* end */
