/*Copyright  (c)   1992  Adam  Stein.   All  Rights Reserved.   

  Permission to use,  copy,  modify  and  distribute  without
  charge this software, documentation, images, etc. is grant-
  ed, provided that this copyright and the author's  name  is  
  retained.   
  
  A fee may be charged for this program ONLY to recover costs   
  for distribution (i.e. media costs).  No profit can be made            
  on this program.   
   
  The author assumes no responsibility for disasters (natural   
  or otherwise) as a consequence of use of this software.      
   
  Adam Stein (stein.wbst129@xerox.com)         
*/ 

#define AMBIGUOUS -2				/*Ambiguous syntax*/
#define UNKNOWN -1				/*Value is unknown*/
#define VERSION_STR "v1.0 by Adam Stein"	/*Version string*/

/*Commands*/
#define ALPHA		0		/*Alpha*/
#define EXIT		1		/*Exit program*/
#define HELP		2		/*Help*/
#define INODES		3		/*Number of input nodes*/
#define LOAD		4		/*Load variables from a file or stdin*/
#define NODE		5		/*Node command*/
#define ONODES		6		/*Number of output nodes*/
#define RANGE		7		/*Range of something*/
#define RUN		8		/*Run the simulator*/
#define SAVE		9		/*Save variables to a file*/
#define SHOW		10		/*Show the value of a variable*/
#define TRAINING	11		/*Training mode toggle*/
#define VERSION 	12		/*Show version*/

#define NUM_CMDS	13		/*Number of commands available*/

/*Qualifiers*/
#define ASCII		50		/*File is of type ASCII*/
#define BINARY		51		/*File is of type binary (byte size)*/
#define DESIRED		52		/*Operation involves desired output*/
#define FUNCTION	53		/*Non-linearity function to use*/
#define INPUT		54		/*Operation involves input data*/
#define OUTPUT		55		/*Operation involves output data*/
#define RANDOM		56		/*Load weights randomly*/
#define STDIN		57		/*Read values from stdin*/
#define SYS_VARS	58		/*Operation involves system variables*/
#define THRESHOLD	59		/*Set node's threshold*/
#define VERBOSE		60		/*Run in verbose mode*/
#define WEIGHTS		61		/*Operation involves weight data*/

#define NUM_QUALIFIERS	12		/*Number of qualifiers*/

/*Command structure*/
typedef struct _cmd {
	int numargs;			/*Number of arguments for cmd*/
	char *name;			/*Name of command*/
} CMD;

/*Node information structure*/
typedef struct _node_attr {
	double threshold;		/*Node threshold*/
	double (*func)();		/*Non-linear function*/
} NODE_ATTR;

/*System variables structure*/
typedef struct _state {
	double alpha;			/*Alpha*/
	int inodes;			/*Number of input nodes*/
	int onodes;			/*Number of output nodes*/
	int training;			/*Training mode status (on/off)*/
} STATE;

/*Structure of file containing weight information*/
typedef struct _weight {
	int from;			/*From input node number*/
	int to;				/*To output node number*/
	double value;			/*Weight value*/
} WEIGHT;

