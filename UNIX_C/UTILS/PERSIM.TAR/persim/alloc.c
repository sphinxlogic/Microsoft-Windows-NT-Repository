/*Copyright  (c)   1992  Adam  Stein.   All  Rights Reserved.

  Permission to use,  copy,  modify  and  distribute  without
  charge this software, documentation, images, etc. is grant-
  ed, provided that this copyright and the author's  name  is
  retained.

  A fee may be charged for this program ONLY to recover costs
  for distribution (i.e. media costs).  No profit can be made
  on this program.

  The author assumes no responsibility for disasters (natural
  or otherwise) as a consequence of use of this software.

  Adam Stein (stein.wbst129@xerox.com)
*/

#include <stdio.h>
#include "persim.h"

char *calloc();

/*This routine allocates data for 1D arrays of double numbers.

  Inputs:  array    - pointer to array allocate (and deallocate if necessary)
	   numnodes - number of elements to allocate for
  Outputs: array    - pointer to new array
  Locals:  none
  Globals: NULL     - 0
*/
alloc_data(numnodes,array)
register int numnodes;
register double **array;
{
	/*Deallocate previous array if there is one*/
	if(*array) free((char *) *array);

	/*Allocate space for new array*/
	if((*array = (double *) calloc(numnodes,sizeof(double))) == NULL)
	  error();
}

/*This routine allocates data for 2D arrays of double numbers (i.e. the
  weights).

  Inputs:  array    - pointer to array allocate (and deallocate if necessary)
	   inodes   - number of input nodes
	   onodes   - number of output nodes
  Outputs: none
  Locals:  loop     - number of input nodes (1st deminsion of 2D array)
  Globals: none
*/
alloc_wts(array,inodes,onodes)
register int inodes,onodes;
register double ***array;
{
	register int loop;

	/*Deallocate array if there is one*/
	if(*array) {
	  for(loop = 0;loop < inodes;++loop)
	    free((char *) (*array)[loop]);

	  free((char *) *array);
	}

	/*Allocate new array*/
	if((*array = (double **) calloc(inodes,sizeof(double *)))== NULL)
	  error();
	for(loop = 0;loop < inodes;++loop)
	  if(((*array)[loop] = (double *) calloc(onodes,sizeof(double))) == NULL)
	    error();
}

/*This routine will deallocate the space taken up by the perceptron weights
  arrays.

  Inputs:  none
  Outputs: none
  Locals:  loop    - loop through weights array
  Globals: state   - system variables
	   weights - percetron weights
	   NULL    - 0
*/
deallocwts()
{
	register int loop;
	extern double **weights;
	extern STATE state;

	for(loop = 0;loop < state.inodes;++loop)
	  free((char *) weights[loop]);

	free((char *) weights);

	weights = (double **) NULL;
}

