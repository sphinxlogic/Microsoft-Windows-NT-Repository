/*Copyright  (c)   1992  Adam  Stein.   All  Rights Reserved.   

  Permission to use,  copy,  modify  and  distribute  without
  charge this software, documentation, images, etc. is grant-
  ed, provided that this copyright and the author's  name  is  
  retained.   
  
  A fee may be charged for this program ONLY to recover costs   
  for distribution (i.e. media costs).  No profit can be made            
  on this program.   
   
  The author assumes no responsibility for disasters (natural   
  or otherwise) as a consequence of use of this software.      
   
  Adam Stein (stein.wbst129@xerox.com)         
*/ 

#include "persim.h"
#include "commands.h"
#include "grammar.h"

/*This routine will determine if a string of characters is a keyword.

  Inputs:  numargs   - (return value)
	   string    - string of characters to identify as a keyword or not
  Outputs: numargs   - number of arguments this keyword takes
  Locals:  loop      - loop through list of keywords
	   pointer   - pointer to each keyword in list to compare
  Globals: cmd       - name of keyword
	   AMBIGUOUS - not enough of a keyword was given to distiguish it
	   NUM_CMDS  - total number of commands available
	   UNKNOWN   - string is not a keyword
*/
iskeyword(string,numargs)
register int *numargs;
register char *string;
{
	register int loop;
	register char *pointer;
	char *strstr();

	/*Look for a match*/
	for(loop = 0;loop < NUM_CMDS;++loop)
	  if((pointer = strstr(cmd[loop].name,string)) == cmd[loop].name)
	    break;

	/*If didn't find a match, string is unknown*/
	if(loop == NUM_CMDS) loop = UNKNOWN;
	else {
	       /*Find out if the 'match' matched more than 1 item (ambiguous)*/
	       if((loop == (NUM_CMDS - 1)) ||
		  (strstr(cmd[loop + 1].name,string) != cmd[loop + 1].name))
	         *numargs = cmd[loop].numargs;
	       else loop = AMBIGUOUS;
	     }

	return(loop);
}

/*This routine will check to see if a string of characters is a qualifier.

  Inputs:  type           - (return value)
	   string         - string of characters to identify as a keyword or not
  Outputs: type           - type of qualifier (used in grammar.y)
  Locals:  loop           - loop through list of keywords
	   pointer        - pointer to each keyword in list to compare
  Globals: AMBIGUOUS	  - not enough of a qualifier was given to distiguish it
	   ASCII	  - qualifier relates to an ascii filetype
	   BINARY	  - qualifier relates to a binary filetype
	   DATA   	  - data attribute (used in grammar.y)
	   DESIRED	  - qualifier relates to desired output values
	   FILETYPE   	  - filetype attribute (used in grammar.y)
	   FUNC_ATTR	  - function attribute (used in grammar.y)
	   FUNCTION	  - qualifier relates to a node's function
	   INPUT	  - qualifier relates to input values
	   NOTFILE	  - loading values is not coming from a file (grammar.y)
	   NUM_QUALIFIERS - total number of qualifiers
	   OUTPUT	  - qualifier relates to output values
	   SYS_VARS       - qualifier relates to system variables
	   RANDOM         - qualifier relates to using random values
	   STDIN          - qualifier relates to loading values from keyboard
	   THRESHOLD      - qualifier relates to threshold value
	   THRESHOLD_ATTR - threshold attribute (used in grammar.y)
	   WEIGHTS	  - qualifier relates to weights
	   UNKNOWN        - string is not a qualifier
	   VERBOSE	  - qualifier relates to verbosity of a command
	   VERBOSE_ATTR   - verbose attribute (used in grammar.y)
*/
isqualifier(string,type)
register int *type;
register char *string;
{
	register int loop;
	register char *pointer;
	char *strstr();

	/*Look for a match*/
	for(loop = 0;loop < NUM_QUALIFIERS;++loop)
	  if((pointer = strstr(qual[loop],string)) == qual[loop])
	    break;

	/*If didn't find a match, string is unknown*/
	if(loop == NUM_QUALIFIERS) loop = UNKNOWN;
	else if((loop != (NUM_QUALIFIERS - 1)) &&
		(strstr(qual[loop + 1],string) == qual[loop + 1]))
	       loop = AMBIGUOUS;
	     else loop += 50;

	/*Find out which part of the grammar this qualifier belongs to*/
	switch(loop) {
	  case ASCII:
	  case BINARY:
			*type = FILETYPE;
			break;
	  case DESIRED:
	  case INPUT:
	  case OUTPUT:
	  case SYS_VARS:
	  case WEIGHTS:
			*type = DATA;
			break;
	  case RANDOM:
	  case STDIN:
			*type = NOTFILE;
			break;
	  case FUNCTION:
			*type = FUNC_ATTR;
			break;
	  case THRESHOLD:
			*type = THRESHOLD_ATTR;
			break;
	  case VERBOSE:
			*type = VERBOSE_ATTR;
			break;
	}

	return(loop);
}

