/*Copyright  (c)   1992  Adam  Stein.   All  Rights Reserved.   

  Permission to use,  copy,  modify  and  distribute  without
  charge this software, documentation, images, etc. is grant-
  ed, provided that this copyright and the author's  name  is  
  retained.   
  
  A fee may be charged for this program ONLY to recover costs   
  for distribution (i.e. media costs).  No profit can be made            
  on this program.   
   
  The author assumes no responsibility for disasters (natural   
  or otherwise) as a consequence of use of this software.      
   
  Adam Stein (stein.wbst129@xerox.com)         
*/ 

void fpset(),help(),iset(),load(),range(),run(),save(),show(),toggle();
void version();

/*Array of functions to execute for keywords.  Index into the array is
  determined by which keyword was found.*/
void (*execute[NUM_CMDS])() = {
			 	fpset, NULL, help, iset, load, NULL, iset,
				range, run, save, show, toggle, version
			      };

