/*Copyright  (c)   1992  Adam  Stein.   All  Rights Reserved.   

  Permission to use,  copy,  modify  and  distribute  without
  charge this software, documentation, images, etc. is grant-
  ed, provided that this copyright and the author's  name  is  
  retained.   
  
  A fee may be charged for this program ONLY to recover costs   
  for distribution (i.e. media costs).  No profit can be made            
  on this program.   
   
  The author assumes no responsibility for disasters (natural   
  or otherwise) as a consequence of use of this software.      
   
  Adam Stein (stein.wbst129@xerox.com)         
*/ 

#include <stdio.h>
#include <fcntl.h>
#include "persim.h"

/*This routine will write values for 1D arrays to a file.

  Inputs:  filename - name of the file to write to
	   filetype - what type this file it is
	   numnodes - number of values to write out
	   var      - which variable to write out
  Outputs: none
  Locals:  data	    - line of data to write out
	   fp       - file pointer
	   loop     - loop through writing out values
  Globals: ASCII    - write out in ascii format
	   NULL     - 0
*/
writedata(var,numnodes,filename,filetype)
register int numnodes,filetype;
register double var[];
register char *filename;
{
	register int loop;
	register unsigned char *data;
	register FILE *fp;
	char *malloc();

	if((fp = fopen(filename,"w")) == NULL) {
          printf("can't open {%s}\n",filename);
	  return;
        }

	if((data = (unsigned char *) malloc(numnodes)) == NULL)
	  error();

	for(loop = 0;loop < numnodes;++loop)
	  if(filetype == ASCII) fprintf(fp,"%d\n",(int) var[loop]);
	  else data[loop] = (unsigned char) var[loop];

	if(filetype != ASCII)
	  if(fwrite(data,1,numnodes,fp) != numnodes) error();

	fclose(fp);
}

/*This routine will write out the system variables.

  Inputs:  filename - name of the file to write to
  Outputs: none
  Locals:  fd	    - file descriptor
  Globals: state    - system variables
	   O_CREAT  - create file if necessary
	   O_RDONLY - open file for reading
	   O_WRONLY - open file for writing
*/
writestate(filename)
register char *filename;
{
	register int fd;
	extern STATE state;

	if((fd = open(filename,O_RDONLY)) != -1) {
	  close(fd);
	  printf("{%s} already exists\n",filename);
	  return;
	}

	if((fd = open(filename,O_WRONLY|O_CREAT,0644)) == -1) {
	  printf("can't open {%s}\n",filename);
	  return;
	}

	if(write(fd,(char *) &state,sizeof(state)) != sizeof(state))
	  puts("writing system variables failed");

	close(fd);
}

/*This function will write the values from a 2D array to a file.

  Inputs:  filename - name of the file to write to
	   filetype - what type this file it is
	   innodes  - number of input nodes
	   outnodes - number of output nodes
	   var      - which variable to write out
  Outputs: none
  Locals:  fd       - file descriptor
  Globals: ASCII    - write out in ascii format
	   NULL     - 0

*/
writewts(var,innodes,outnodes,filename,filetype)
register int innodes,outnodes,filetype;
register double *var[];
register char *filename;
{
	register int loop,loop2;
	register FILE *fp;
	WEIGHT weight;

	if((fp = fopen(filename,"w")) == NULL) {
          printf("can't open {%s}\n",filename);
          return;
        }

	for(loop = 0;loop < innodes;++loop)
	  for(loop2 = 0;loop2 < outnodes;++loop2)
	    if(var[loop][loop2] != 0.0)
	      if(filetype != ASCII) {
		weight.from = loop+1;
		weight.to = loop2+1;
		weight.value = var[loop][loop2];
	        if(fwrite((char *) &weight,sizeof(weight),1,fp) != 1)
		  error();
	      } else fprintf(fp,"%d %d %lf\n",loop+1,loop2+1,var[loop][loop2]);

	fclose(fp);
}

