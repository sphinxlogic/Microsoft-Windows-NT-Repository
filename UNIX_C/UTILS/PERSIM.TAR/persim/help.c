/*Copyright  (c)   1992  Adam  Stein.   All  Rights Reserved.   

  Permission to use,  copy,  modify  and  distribute  without
  charge this software, documentation, images, etc. is grant-
  ed, provided that this copyright and the author's  name  is  
  retained.   
  
  A fee may be charged for this program ONLY to recover costs   
  for distribution (i.e. media costs).  No profit can be made            
  on this program.   
   
  The author assumes no responsibility for disasters (natural   
  or otherwise) as a consequence of use of this software.      
   
  Adam Stein (stein.wbst129@xerox.com)         
*/ 

#include "persim.h"

/*This routine prints information and the syntax for a specified command or
  a list of all commands if no special commands is specified.

  Inputs:  subject - subject to provide help on
  Outputs: none
  Locals:  none
  Globals: cmd     - name of command to print information about
	   desc    - help description to print
*/
void help(subject)
register int subject;
{
	extern char *desc[];
	extern CMD cmd[];

	if(subject == UNKNOWN) {
	  puts("Commands may be abbreviated.  The following commands are available:");
	  puts("");
	  puts("alpha\t\tinodes\t\tonodes\t\tsave\t\ttraining");
	  puts("exit\t\tload\t\trange\t\tshow\t\tversion");
	  puts("help\t\tnode\t\trun");
	} else if(subject == AMBIGUOUS)
		 puts("*** ambiguous help subject ***");
	       else printf("%s - %s\n",cmd[subject].name,desc[subject]);
}

