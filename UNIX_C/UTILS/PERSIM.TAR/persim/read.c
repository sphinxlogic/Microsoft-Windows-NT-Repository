/*Copyright  (c)   1992  Adam  Stein.   All  Rights Reserved.   

  Permission to use,  copy,  modify  and  distribute  without
  charge this software, documentation, images, etc. is grant-
  ed, provided that this copyright and the author's  name  is  
  retained.   
  
  A fee may be charged for this program ONLY to recover costs   
  for distribution (i.e. media costs).  No profit can be made            
  on this program.   
   
  The author assumes no responsibility for disasters (natural   
  or otherwise) as a consequence of use of this software.      
   
  Adam Stein (stein.wbst129@xerox.com)         
*/ 

#include <stdio.h>
#include <fcntl.h>
#include "persim.h"

double atof();

/*This routine will read in values for 1D arrays from a file or keyboard.

  Inputs:  filename - name of the file containing the values
	   filetype - what type this file it is
	   numnodes - number of values to read in
	   var      - which variable these values are for
  Outputs: 1 if successful, 0 if an error occurred
  Locals:  data     - used to read in data from binary files
	   dummy    - used to check if there are too many values in the file
	   fp       - file pointer
	   loop     - loop through reading in values
  Globals: ASCII    - file is in ascii format
	   EOF      - user terminated input
	   NULL     - 0
*/
readdata(var,numnodes,filename,filetype)
register int numnodes,filetype;
register double var[];
register char *filename;
{
	register int loop;
	register unsigned char *data,dummy[21];
	register FILE *fp;
	char *malloc();

	/*If filename isn't NULL, read in values from a file*/
	if(filename) {
	  if((fp = fopen(filename,"r")) == NULL) {
	    printf("can't open {%s}\n",filename);
	    return(0);
	  }

	  /*If binary, read in a line of values at a time*/
	  if(filetype != ASCII) {
	    if((data = (unsigned char *) malloc(numnodes)) == NULL)
	      error();

	    if(fread(data,1,numnodes,fp) != numnodes) error();

	    if(fread(&dummy[0],1,1,fp) || !feof(fp))
	      puts("warning: too many data points in file");
	  }

	  /*Read values from ascii file or convert from binary array*/
	  for(loop = 0;loop < numnodes;++loop)
	    if(filetype == ASCII) {
	      if(fgets(dummy,21,fp) == NULL) {
		puts("not enough data points in file");
		break;
	      } else var[loop] = atof(dummy);
	    } else var[loop] = (double) data[loop];

	  fclose(fp);
	} else for(loop = 0;loop < numnodes;++loop) { /*Get data from keyboard*/
		 printf("Data Point #%d? ");

		 if(fgets(dummy,21,stdin) == (char *) EOF) {
		   puts("input ended early at request of the user");
		   break;
		 } else var[loop] = atof(dummy);
	       }

	return(1);
}

/*This routine will read in the system variables.

  Inputs:  filename - name of the file containing the values
  Outputs: none
  Locals:  fd       - file descriptor
	   tmp      - temporary holding place for read in values
  Globals: state    - system variables
	   O_RDONLY - open file for reading
*/
readstate(filename)
register char *filename;
{
	register int fd;
	STATE tmp;
	extern STATE state;

	if((fd = open(filename,O_RDONLY)) == -1) {
	  printf("can't open {%s}\n",filename);
	  return;
	}

	if(read(fd,(char *) &tmp,sizeof(tmp)) != sizeof(tmp))
	  puts("reading system variables failed");
	else bcopy((char *) &tmp,(char *) &state,sizeof(state));

	close(fd);
}

/*This routine will read in values for 2D arrays from a file or keyboard.

  Inputs:  filename - name of the file containing the values
	   filetype - what type this file it is
	   innodes  - number of input nodes
	   outnodes - number of output nodes
	   var      - which variable these values are for
  Outputs: 1 if successful, 0 if an error occurred
  Locals:  fp       - file pointer
	   from     - from which input node value
	   dummy    - line of input from keyboard
	   to       - to which output node value
	   value    - weight value
	   weight   - read in values (from, to, value)
  Globals: ASCII    - file is in ascii format
	   NULL     - 0
*/
readwts(var,innodes,outnodes,filename,filetype)
register int innodes,outnodes,filetype;
register double *var[];
register char *filename;
{
	int from,to;
	double value;
	register char dummy[21];
	register FILE *fp;
	WEIGHT weight;

	/*If filename isn't NULL, read values from a file*/
	if(filename) {
	  if((fp = fopen(filename,"r")) == NULL) {
	    printf("can't open {%s}\n",filename);
	    return(0);
	  }

	  if(filetype != ASCII)
	    while(fread((char *) &weight,sizeof(weight),1,fp) == 1) {
	      if((weight.from < 1) || (weight.from > innodes))
		printf("\nthe specified input node #%d is out of bounds\n\n",
		       weight.from);
	      else if((weight.to < 1) || (weight.to > outnodes))
		     printf("\nthe specified output node #%d is out of bounds\n\n",
		            weight.to);
	           else var[weight.from-1][weight.to-1] = weight.value;
	    }
	  else while(fscanf(fp,"%d %d %lf",&from,&to,&value) == 3) {
	         if((from < 1) || (from > innodes))
		   printf("\nthe specified input node #%d is out of bounds\n\n",
		          from);
	         else if((to < 1) || (to > outnodes))
		        printf("\nthe specified output node #%d is out of bounds\n\n",
		               to);
		      else var[from-1][to-1] = value;
	       }

	  fclose(fp);
	} else {
		 /*Read from keyboard until user quits*/
		 while(1) {
		   printf("From Input Node? ");
		   fgets(dummy,21,stdin);
		   if(dummy[0] == '\n') break;
		   from = atoi(dummy);

		   printf("To Output Node? ");
		   fgets(dummy,21,stdin);
		   if(dummy[0] == '\n') break;
		   to = atoi(dummy);

		   printf("Weight Value? ");
		   fgets(dummy,21,stdin);
		   if(dummy[0] == '\n') break;
		   puts("");

	           if((from < 1) || (from > innodes))
		     printf("\nthe specified input node #%d is out of bounds\n\n",
		            from);
	           else if((to < 1) || (to > outnodes))
		          printf("\nthe specified output node #%d is out of bounds\n\n",
		                 to);
		        else var[from-1][to-1] = atof(dummy);
		 }
	       }

	return(1);
}

