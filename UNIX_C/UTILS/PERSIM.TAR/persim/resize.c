/*Copyright  (c)   1992  Adam  Stein.   All  Rights Reserved.   

  Permission to use,  copy,  modify  and  distribute  without
  charge this software, documentation, images, etc. is grant-
  ed, provided that this copyright and the author's  name  is  
  retained.   
  
  A fee may be charged for this program ONLY to recover costs   
  for distribution (i.e. media costs).  No profit can be made            
  on this program.   
   
  The author assumes no responsibility for disasters (natural   
  or otherwise) as a consequence of use of this software.      
   
  Adam Stein (stein.wbst129@xerox.com)         
*/ 

#include <stdio.h>
#include "persim.h"

char *realloc();

/*This routine will resize the 1D arrays.

  Inputs:  array - array to resize
	   size  - number of nodes to resize to
  Outputs: none
  Locals:  none
  Globals: NULL  - 0
*/
resize_io(array,size)
register int size;
double **array;
{
	if((*array = (double *) realloc(*array,size*sizeof(double))) == NULL)
	  error();
}

/*This routine will resize an array of node attributes.

  Inputs:  array - array to resize
	   size  - number of nodes to resize to
  Outputs: none
  Locals:  none
  Globals: NULL  - 0
*/
resize_attr(array,size)
register int size;
NODE_ATTR **array;
{
	if((*array = (NODE_ATTR *) realloc(*array,size*sizeof(NODE_ATTR)))
	   == NULL)
	  error();
}

