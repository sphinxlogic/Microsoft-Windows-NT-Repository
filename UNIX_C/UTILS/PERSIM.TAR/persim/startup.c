/*Copyright  (c)   1992  Adam  Stein.   All  Rights Reserved.   

  Permission to use,  copy,  modify  and  distribute  without
  charge this software, documentation, images, etc. is grant-
  ed, provided that this copyright and the author's  name  is  
  retained.   
  
  A fee may be charged for this program ONLY to recover costs   
  for distribution (i.e. media costs).  No profit can be made            
  on this program.   
   
  The author assumes no responsibility for disasters (natural   
  or otherwise) as a consequence of use of this software.      
   
  Adam Stein (stein.wbst129@xerox.com)         
*/ 

#include <stdio.h>

int print_line;

extern FILE *yyin;

/*This routine will open the file containing commands to execute
  (for batch processing).  If no filename is passed in, commands are
  assumed to come from stdin.  Finally the function to startup yacc
  is called.

  Inputs:  filename      - name of file containing PERSIM commands
  Outputs: none
  Locals:  none
  Globals: errno	 - number of last error
	   print_line    - flag indicating if commands are from a batch file
	   stdin	 - standard input
	   yyin          - file pointer used by lex
	   NULL          - 0
*/
startup(filename)
register char *filename;
{
	if(filename == NULL) {
	  yyin = stdin;
	  print_line = 0;
	} else if((yyin = fopen(filename,"r")) == NULL) error();
	       else print_line = 1;

	prompt();
	yyparse();
}

