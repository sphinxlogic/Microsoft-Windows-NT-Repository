/*Copyright  (c)   1992  Adam  Stein.   All  Rights Reserved.   

  Permission to use,  copy,  modify  and  distribute  without
  charge this software, documentation, images, etc. is grant-
  ed, provided that this copyright and the author's  name  is  
  retained.   
  
  A fee may be charged for this program ONLY to recover costs   
  for distribution (i.e. media costs).  No profit can be made            
  on this program.   
   
  The author assumes no responsibility for disasters (natural   
  or otherwise) as a consequence of use of this software.      
   
  Adam Stein (stein.wbst129@xerox.com)         
*/ 

extern double ranges[1][2];

/*This routine is a step (i.e. sgn) function.  Any value greater than or equal
  to 0 outputs 1 value, less than 0 outputs another value.

  Inputs:  value  - value to act upon
  Outputs: max range if value >=0, min range if < 0
  Locals:  none
  Globals: ranges - max and min values to return
*/
double step(value)
register double value;
{
	return((value >= 0.0)?ranges[0][1]:ranges[0][0]);
}

