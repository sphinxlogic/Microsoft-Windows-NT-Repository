/*Copyright  (c)   1992  Adam  Stein.   All  Rights Reserved.   

  Permission to use,  copy,  modify  and  distribute  without
  charge this software, documentation, images, etc. is grant-
  ed, provided that this copyright and the author's  name  is  
  retained.   
  
  A fee may be charged for this program ONLY to recover costs   
  for distribution (i.e. media costs).  No profit can be made            
  on this program.   
   
  The author assumes no responsibility for disasters (natural   
  or otherwise) as a consequence of use of this software.      
   
  Adam Stein (stein.wbst129@xerox.com)         
*/ 

#include "persim.h"

/*This routine will toggle the value of a variable.

  Inputs:  none
  Outputs: none
  Locals:  none
  Globals: state - system variables
*/
void toggle()
{
	extern STATE state;

	state.training ^= 1;
	if(state.training) puts("training mode is now turned on");
	else puts("training mode has been turned off");
}

