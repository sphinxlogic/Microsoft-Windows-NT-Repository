/*Copyright  (c)   1992  Adam  Stein.   All  Rights Reserved.   

  Permission to use,  copy,  modify  and  distribute  without
  charge this software, documentation, images, etc. is grant-
  ed, provided that this copyright and the author's  name  is  
  retained.   
  
  A fee may be charged for this program ONLY to recover costs   
  for distribution (i.e. media costs).  No profit can be made            
  on this program.   
   
  The author assumes no responsibility for disasters (natural   
  or otherwise) as a consequence of use of this software.      
   
  Adam Stein (stein.wbst129@xerox.com)         
*/ 

#include <stdio.h>
#include <math.h>
#include "persim.h"

extern NODE_ATTR *node_attr;
extern STATE state;

/*This routine will set a variable to an integer number.

  Inputs:  number    - number to set variable to
	   var       - variable to set
  Outputs: none
  Locals:  loop      - loop through output nodes
  Globals: input     - input values array
	   node_attr - node attributes (function, threshold)
	   output    - output values array
	   state     - system variables
	   INODES    - set number of input nodes variable
	   ONODES    - set number of output nodes variable
	   NULL      - 0
*/
void iset(var,number)
register int var,number;
{
	register int loop;
	char *calloc();
	extern double *input,*output;

	switch(var) {
	  case INODES:
		if(number < 1) puts("illegal value for number of input nodes");
		else {
		       if(input != (double *) NULL)
			 resize_io(&input,number);

		       state.inodes = number;
		     }
		break;
	  case ONODES:
		if(number < 1) puts("illegal value for number of output nodes");
		else {
		       if(output != (double *) NULL) resize_io(&output,number);
		       if(node_attr != (NODE_ATTR *) NULL)
			 resize_attr(&node_attr,number);
		       else if((node_attr = (NODE_ATTR *) calloc(number,
							  sizeof(NODE_ATTR)))
							  == NULL)
			      error();

		       for(loop = 0;loop < state.onodes;++loop)
			 node_attr[loop].func = NULL;

		       state.onodes = number;
		     }
		break;
	}
}

/*This routine will set a variable to a floating point number.

  Inputs:  number - number to set variable to
	   var	  - variable to set
  Outputs: none
  Locals:  none
  Globals: state  - system variables
	   ALPHA  - set alpha
*/
void fpset(var,number)
register int var;
register double number;
{
	switch(var) {
	  case ALPHA:
		if((number < 0.0) || (number > 1.0))
		  puts("illegal value for alpha");
		else state.alpha = number;
		break;
	}
}

/*This routine will set the threshold level of an output node.

  Inputs:  value      - threshold level
	   whichnnode - which node to set (-1 means ALL nodes)
  Outputs: none
  Locals:  loop	      - loop through output nodes
  Globals: node_attr  - node attributes (function, threshold)
	   state      - system variables
	   NULL       - 0
*/
void set_threshold(whichnode,value)
register int whichnode;
register double value;
{
	register int loop;

	if(node_attr == (NODE_ATTR *) NULL) {
	  puts("the number of output nodes has not been set yet");
	  return;
	}

	if(whichnode == -1)
	  for(loop = 0;loop < state.onodes;++loop)
	    node_attr[loop].threshold = value;
	else node_attr[whichnode-1].threshold = value;
}

/*This routine will set the function of an output node.

  Inputs:  string     - function to set
	   whichnnode - which node to set (-1 means ALL nodes)
  Outputs: none
  Locals:  loop	      - loop through output nodes
  Globals: node_attr  - node attributes (function, threshold)
	   state      - system variables
	   NULL       - 0
*/
void set_func(whichnode,string)
register int whichnode;
register char *string;
{
	register int loop;

	if(node_attr == (NODE_ATTR *) NULL) {
	  puts("the number of output nodes has not been set yet");
	  return;
	}

	if(whichnode == -1) {
	  for(loop = 0;loop < state.onodes;++loop)
	    if(!_set_func(string,&node_attr[loop]))
	      puts("illegal function");
	} else if(!_set_func(string,&node_attr[whichnode-1]))
		 puts("illegal function");
}

/*This routine will set the correct function pointer based on function name.
  
  Inputs:  node   - which output node to set
	   string - function to set it to
  Outputs: none
  Locals:  none
  Globals: none
*/
_set_func(string,node)
register char *string;
register NODE_ATTR *node;
{
	double step();

	if(!strcmp(string,"step")) node->func = step;
	else if(!strcmp(string,"arctan")) node->func = atan;
}

