/*Copyright  (c)   1992  Adam  Stein.   All  Rights Reserved.   

  Permission to use,  copy,  modify  and  distribute  without
  charge this software, documentation, images, etc. is grant-
  ed, provided that this copyright and the author's  name  is  
  retained.   
  
  A fee may be charged for this program ONLY to recover costs   
  for distribution (i.e. media costs).  No profit can be made            
  on this program.   
   
  The author assumes no responsibility for disasters (natural   
  or otherwise) as a consequence of use of this software.      
   
  Adam Stein (stein.wbst129@xerox.com)         
*/ 

/*This function assigned max and min values for an object (right now, only
  the range of the step function can be set).

  Inputs:  max    - maximum value to set
	   min    - minimum value to set
	   string - object to set range for
  Outputs: none
  Locals:  none
  Globals: ranges - max and min values of objects
*/
void range(string,min,max)
register double min,max;
register char *string;
{
	extern double ranges[1][2];

	if(!strcmp(string,"step")) {
	  ranges[0][0] = min;
	  ranges[0][1] = max;
	} else puts("illegal object for a range");
}

