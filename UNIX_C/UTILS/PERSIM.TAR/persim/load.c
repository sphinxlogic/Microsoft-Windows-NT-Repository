/*Copyright  (c)   1992  Adam  Stein.   All  Rights Reserved.   

  Permission to use,  copy,  modify  and  distribute  without
  charge this software, documentation, images, etc. is grant-
  ed, provided that this copyright and the author's  name  is  
  retained.   
  
  A fee may be charged for this program ONLY to recover costs   
  for distribution (i.e. media costs).  No profit can be made            
  on this program.   
   
  The author assumes no responsibility for disasters (natural   
  or otherwise) as a consequence of use of this software.      
   
  Adam Stein (stein.wbst129@xerox.com)         
*/ 

#include <stdio.h>
#include "persim.h"

/*This routine will load values into the different variables.

  Inputs:  filename - name of the file containing the values
	   filetype - what type this file it is
	   var      - what variable to load
  Outputs: none
  Locals:  none
  Globals: desired  - desired output value array
	   input    - input value array
	   output   - output value array
	   state    - system variables
	   weights  - perceptron weights
	   DESIRED  - load desired output values
	   INPUT    - load input values
	   NULL     - 0
	   OUTPUT   - load output values
	   RANDOM   - load variable with random numbers
	   SYS_VARS - load system variables
	   UNKNOWN  - variable isn't set
	   WEIGHTS  - load perceptron weights
*/
void load(var,filename,filetype)
register int var,filetype;
register char *filename;
{
	char *calloc();
	extern double *input,*output,*desired,**weights;
	extern STATE state;

	switch(var) {
	  case DESIRED:
		if(filetype == RANDOM)
		  puts("can't assign random values to desired output");
		else if(state.onodes == UNKNOWN)
		       puts("the number of output nodes has not been set");
		     else {
			    /*Allocate space*/
		            alloc_data(state.onodes,&desired);

			    /*Read in values from file or keyboard*/
		            if(!readdata(desired,state.onodes,filename,
					 filetype)) {
			      /*If the read failed, deallocate unused space*/
			      free((char *) desired);
			      desired = (double *) NULL;
		            }
		          }
		break;
	  case INPUT:
		if(filetype == RANDOM)
		  puts("can't assign random values for input");
		else if(state.inodes == UNKNOWN)
		       puts("the number of input nodes has not been set");
		     else {
			    /*Allocate space*/
			    alloc_data(state.inodes,&input);

			    /*Read in values from file or keyboard*/
		            if(!readdata(input,state.inodes,filename,
					 filetype)) {
			      /*If read failed, deallocate unused space*/
			      free((char *) input);
			      input = (double *) NULL;
		            }
		          }
		break;
	  case OUTPUT:
		puts("can't load output values (must be generated)");
		break;
	  case SYS_VARS:
		readstate(filename);
		break;
	  case WEIGHTS:
		if(state.inodes == UNKNOWN)
		  puts("the number of input nodes has not been set");
		else if(state.onodes == UNKNOWN)
		       puts("the number of output nodes has not been set");
		     else {
			    if(filetype != RANDOM) {
			      /*Allocate space*/
			      alloc_wts(&weights,state.inodes,state.onodes);

			      /*Read in values from file or keyboard*/
		              if(!readwts(weights,state.inodes,state.onodes,
					  filename,filetype))
				/*If read failed, deallocate unused space*/
				deallocwts();
			    } else randomize();
			  }
		break;
	}
}

