/*Copyright  (c)   1992  Adam  Stein.   All  Rights Reserved.   

  Permission to use,  copy,  modify  and  distribute  without
  charge this software, documentation, images, etc. is grant-
  ed, provided that this copyright and the author's  name  is  
  retained.   
  
  A fee may be charged for this program ONLY to recover costs   
  for distribution (i.e. media costs).  No profit can be made            
  on this program.   
   
  The author assumes no responsibility for disasters (natural   
  or otherwise) as a consequence of use of this software.      
   
  Adam Stein (stein.wbst129@xerox.com)         
*/ 

#include <stdio.h>
#include "persim.h"

/*This function will save values from the different variables.

  Inputs:  filename - name of the file to save values to
	   filetype - what type this file it is
	   var      - what variable to save
  Outputs: none
  Locals:  none
  Globals: desired  - desired output value array
	   input    - input value array
	   output   - output value array
	   state    - system variables
	   weights  - perceptron weights
	   DESIRED  - save desired output values
	   INPUT    - save input values
	   NULL     - 0
	   OUTPUT   - save output values
	   SYS_VARS - save system variables
	   WEIGHTS  - save perceptron weights
*/
save(var,filename,filetype)
register int var,filetype;
register char *filename;
{
	extern double *input,*output,*desired,**weights;
	extern STATE state;

	if(!filename) {
	  puts("no filename given");
	  return;
	}

	switch(var) {
	  case DESIRED:
		if(desired == (double *) NULL)
		  puts("there are no desired output values to save");
		else writedata(desired,state.onodes,filename,filetype);
		break;
	  case INPUT:
		if(input == (double *) NULL)
		  puts("there are no input values to save");
		else writedata(input,state.inodes,filename,filetype);
		break;
	  case OUTPUT:
		if(output == (double *) NULL)
		  puts("there are no output values to save");
		else writedata(output,state.onodes,filename,filetype);
		break;
	  case SYS_VARS:
		writestate(filename);
		break;
	  case WEIGHTS:
		if(weights == (double **) NULL)
		  puts("there are no weights to save");
		else writewts(weights,state.inodes,state.onodes,filename,
			      filetype);
		break;
	}
}

