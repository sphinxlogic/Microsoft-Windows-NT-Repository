/*Copyright  (c)   1992  Adam  Stein.   All  Rights Reserved. 

  Permission to use,  copy,  modify  and  distribute  without
  charge this software, documentation, images, etc. is grant-
  ed, provided that this copyright and the author's  name  is
  retained. 
 
  A fee may be charged for this program ONLY to recover costs 
  for distribution (i.e. media costs).  No profit can be made    
  on this program. 
 
  The author assumes no responsibility for disasters (natural 
  or otherwise) as a consequence of use of this software.  
 
  Adam Stein (stein.wbst129@xerox.com)   
*/

/*Command names and the number of arguments to issue the command.  A -1
  indicates that the value isn't used for that command.*/
CMD cmd[NUM_CMDS] = {
		      {2,"alpha"},
		      {-1,"exit"},
		      {-1,"help"},
		      {2,"inodes"},
		      {3,"load"},
		      {3,"node"},
		      {2,"onodes"},
		      {4,"range"},
		      {-1,"run"},
		      {3,"save"},
		      {-1,"show"},
		      {1,"training"},
		      {0,"version"}
		    };

/*Qualifiers*/
char *qual[NUM_QUALIFIERS] = {
			       "ascii","binary","desired","function","input",
			       "output","random", "stdin","state","threshold",
			       "verbose", "weights"
			     };

/*Description of each command for the help function*/
char *desc[NUM_CMDS] = {
"set alpha\n\
\n\
syntax: alpha = #",

"exit program\n\
\n\
syntax: exit",

"print local help information\n\
\n\
syntax: help <command>",

"set the number of input nodes\n\
\n\
syntax: inodes = #",

"load variables from a file or stdin\n\
\n\
syntax: load <var> \"filename\"[, type]  (file)\n\
	load <var> stdin               (keyboard)",

"set output node information\n\
\n\
syntax: node[#] attr value",

"set the number of output nodes\n\
\n\
syntax: onodes = #",

"set a range\n\
\n\
syntax: range <obj> min max",

"run the simulator\n\
\n\
syntax: run [verbose]",

"save variables to a file\n\
\n\
syntax: save <var> \"filename\"[, type]",

"show the value of a variable\n\
\n\
syntax: show <var>",

"toggle training mode\n\
\n\
syntax: training",

"print current version\n\
\n\
syntax: version"
};

