/*Copyright  (c)   1992  Adam  Stein.   All  Rights Reserved.   

  Permission to use,  copy,  modify  and  distribute  without
  charge this software, documentation, images, etc. is grant-
  ed, provided that this copyright and the author's  name  is  
  retained.   
  
  A fee may be charged for this program ONLY to recover costs   
  for distribution (i.e. media costs).  No profit can be made            
  on this program.   
   
  The author assumes no responsibility for disasters (natural   
  or otherwise) as a consequence of use of this software.      
   
  Adam Stein (stein.wbst129@xerox.com)         
*/ 

#include <stdio.h>
#include <math.h>
#include "persim.h"

/*This routine will show the values of different variables.

  Inputs:  var        - which variable to display
	   whichnode  - in the case of output node attributes, which node
  Outputs: none
  Locals:  loop       - loop through variable elements
	   loop2      - loop through variable elements (for 2D arrays)
  Globals: desired    - desired output values
	   input      - intput values
	   output     - output values
	   node_attr  - node attributes (function, threshold)
	   print_line - flag indicating if commands are from a batch file
	   ranges     - max and min values (only for step function right now)
	   state      - system variables
	   weights    - perceptron weights
	   ALPHA      - show alpha
	   AMBIGUOUS  - ambiguous variable specified
	   DESIRED    - show desired output values
	   NULL       - 0
	   INODES     - show number of input nodes
	   INPUT      - show input values
	   NODE       - show node attributes
	   ONODES     - show number of output nodes
	   OUTPUT     - show output values
	   RANGE      - show ranges
	   SYS_VARS   - show system variables
	   UNKNOWN    - variable isn't set
	   TRAINING   - show status of training mode
	   WEIGHTS    - show perceptron weights
*/
show(var,whichnode)
register int var,whichnode;
{
	register int loop,loop2;
	extern int print_line;
	extern double *input,*output,*desired,**weights,ranges[1][2];
	extern NODE_ATTR *node_attr;
	extern STATE state;

	switch(var) {
	  case ALPHA:
		printf("Alpha is currently set to %lf\n",state.alpha);
		break;
	  case AMBIGUOUS:
		puts("*** ambiguous variable to show ***");
		break;
	  case DESIRED:
		if(desired == (double *) NULL)
		  puts("no desired output data points have been loaded");
		else
		  for(loop = 0;loop < state.onodes;++loop)
		    printf("Desired Output Data Point #%d = %lf\n",loop+1,desired[loop]);
		break;
	  case INODES:
		if(state.inodes == UNKNOWN)
		  puts("The number of input nodes has not been set");
		else
		  printf("The number of input nodes is currently set to %d\n",
			 state.inodes);
		break;
	  case INPUT:
		if(input == (double *) NULL)
		  puts("no input data points have been loaded");
		else
		  for(loop = 0;loop < state.inodes;++loop)
		    printf("Input Data Point #%d = %lf\n",loop+1,input[loop]);
		break;
	  case NODE:
		if(node_attr == (NODE_ATTR *) NULL)
		  puts("no node attributes have been set");
		else if(whichnode == -1)
		       for(loop = 0;loop < state.onodes;++loop)
			 show_node(loop+1,node_attr[loop]);
		     else show_node(whichnode,node_attr[whichnode-1]);
		break;
	  case ONODES:
		if(state.onodes == UNKNOWN)
		  puts("The number of output nodes has not been set");
		else
		  printf("The number of output nodes is currently set to %d\n",
			 state.onodes);
		break;
	  case OUTPUT:
		if(output == (double *) NULL)
		  puts("no output data points have generated");
		else
		  for(loop = 0;loop < state.onodes;++loop)
		    printf("Output Data Point #%d = %lf\n",loop+1,output[loop]);
		break;
	  case RANGE:
		puts("Step Function:");
		printf("  min: %lf, max: %lf\n",ranges[0][0],ranges[0][1]);
		break;
	  case SYS_VARS:
		puts("System Variables:");
		printf("  alpha = %lf\n",state.alpha);

		printf("  inodes = ");
		if(state.inodes == UNKNOWN) puts("NOT SET");
		else printf("%d\n",state.inodes);

		printf("  onodes = ");
		if(state.onodes == UNKNOWN) puts("NOT SET");
		else printf("%d\n",state.onodes);

		printf("  training mode is ");
		if(state.training) puts("ON");
		else puts("OFF");
		break;
	  case TRAINING:
		printf("training mode is ");
		if(state.training) puts("ON");
		else puts("OFF");
		break;
	  case WEIGHTS:
		if(weights == (double **) NULL)
		  puts("no weights have been loaded");
		else
		  for(loop = 0;loop < state.inodes;++loop)
		    for(loop2 = 0;loop2 < state.onodes;++loop2)
		      if(weights[loop][loop2] != 0.0)
			printf("From Input Node #%d, To Output Node #%d, Weight = %lf\n",
			       loop+1,loop2+1,weights[loop][loop2]);
		break;
	}
}

/*This routine will show the attributes of an output node.

  Inputs:  node      - node attributes
	   whichnode - which node to display information about
  Outputs: none
  Locals:  none
  Globals: none
*/
show_node(whichnode,node)
register int whichnode;
NODE_ATTR node;
{
	double step();

	printf("Output Node #%d: threshold = %lf, function = ",whichnode,
							       node.threshold);
	
	if(node.func == atan) puts("arctan");
	else if(node.func == step) puts("step");
	     else  puts("NULL");
}

