/* SCCSID @(#)keydef.h	1.5	4/11/89 */
#include <strings.h>    /* CHANGE to strings.h for BSD, string.h for SYS V */

#define ESC '\033'     /* escape code */
#define BSLASH '\134'  /* back slash  */
#define NL     '\n'    /* newline     */
#define RET    '\r'    /* return      */
#define TAB    '\t'    /* tab         */
#define PREFIX "P1;1|" /* DEC refers to this as "Pc;Pl |"
                          see pg 29, VT220 Programmer Pocket Guide */
#define PROGNAME "keydef" /* argv[0][0] may be a full path name    */
#define RCFILE ".keydef"  /* every program has one these days, maybe */
                          /* what we need is a "dot" directory for them all */
