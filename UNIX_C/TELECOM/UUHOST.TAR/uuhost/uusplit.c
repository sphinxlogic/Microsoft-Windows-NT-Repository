/*
 * UUHOST, Copyright 1992,   Jan-Piet Mens [Logix GmbH, Wiesbaden, Germany]
 * License to freely use and distribute this software is hereby granted 
 * by the author, subject to the condition that this copyright notice 
 * remains intact.  The author retains the exclusive right to publish 
 * derivative works based on this work, including, but not limited
 * to, revised versions of this work.
 *
 * $Id: uusplit.c,v 2.2 1992/01/16 09:40:58 jpm Exp $
 *
 * $Log: uusplit.c,v $
 * Revision 2.2  1992/01/16  09:40:58  jpm
 * Cleanup
 *
 * Revision 2.1  1991/10/19  14:27:49  jpm
 * *** empty log message ***
 *
 *
 */
#include <stdio.h>
#define MAXBUF		1024

#if defined(__STDC__) || defined(__cplusplus)
# define P_(s) s
#else
# define P_(s) ()
#endif

int main P_((int argc, char **argv));
void split P_((char *bp, char *fname));
void exit();
int strlen();
int atoi();

#undef P_

#ifndef lint
static char rcs_id[] = "@(#)$Id: uusplit.c,v 2.2 1992/01/16 09:40:58 jpm Exp $";
#endif

int main(argc, argv)
int argc;
char **argv;
{
	char buf[MAXBUF];
	char *fname = argv[1];
	int n = strlen(fname) - 1;

	if (argc != 2)
		exit(fprintf(stderr,"Usage: %0 filename\n", *argv));

	/*
	 * If filenames end in .Z, chop it off. We don't need that.
	 * Just wastes space ...
	 */

	if (fname[n] == 'Z' && fname[n - 1] == '.')
		fname[n - 1] = '\0';

	while (fgets(buf, MAXBUF, stdin) != (char *)0)
		split(buf, argv[1]);
	return (0);
}

/*
 * `fname' is a relative path to a map: u.deu.2.
 * `bp' contains an `#N' line from the map which has a line-number
 *  prepended to it by `grep' , as in
 *
 *     1245:#N        logixwi, .logix.de,  logix.de
 *
 * Split that line up into lines containing the host name, a filename, and
 * the line number.
 *
 *	logixwi    u.deu.2 1245
 *	.logix.de       u.deu.2 1245
 *	logix.de    u.deu.2 1245
 */

void split(bp, fname)
char *bp, *fname;
{
	char *ptr, *strtok();
	int line;

	if ((ptr = strtok(bp, ":")) == (char *)0)
		(void)fprintf(stderr, "ERROR: no line number\n");
	line = atoi(ptr);

	ptr = strtok(NULL, " \t,;\n");

	while ((ptr = strtok(NULL, " \t,;\n")) != (char *)0)
		(void)printf("%s\t%s\t%d\n", ptr, fname, line);
}
