/*
 * UUHOST, Copyright 1992,   Jan-Piet Mens [Logix GmbH, Wiesbaden, Germany]
 * License to freely use and distribute this software is hereby granted 
 * by the author, subject to the condition that this copyright notice 
 * remains intact.  The author retains the exclusive right to publish 
 * derivative works based on this work, including, but not limited
 * to, revised versions of this work.
 *
 * $Id: uulookup.c,v 2.3 1992/01/16 09:40:58 jpm Exp $
 *
 * $Log: uulookup.c,v $
 * Revision 2.3  1992/01/16  09:40:58  jpm
 * Cleanup
 *
 * Revision 2.2  1991/10/22  18:14:09  jpm
 * Added -u option. Thanks to Pat Myrto <pat@rwing> for suggesting it.
 *
 * Revision 2.1  1991/10/19  14:25:54  jpm
 * *** empty log message ***
 *
 *
 */

#include <stdio.h>
#include <ctype.h>
#ifdef NEED_STRINGS_H
# include <strings.h>
#else
# include <string.h>
#endif
#define MAXBUF	1024

#if defined(__STDC__) || defined(__cplusplus)
# define P_(s) s
#else
# define P_(s) ()
#endif

int main P_((int argc, char **argv));
void splitpath P_((char *usr, char *adr));
int look P_((char *key, char *result));
int strsplit P_((register char *s, int sep, char **arg));
void usage P_((void));
int getopt();
void exit();

#undef P_
#define FALSE		0
#define TRUE		1
#define MAXDOMS		20

char *progname;
char *database;			/* For look() */

#ifndef lint
static char rcs_id[] = "@(#)$Id: uulookup.c,v 2.3 1992/01/16 09:40:58 jpm Exp $";
#endif
void usage();

int main(argc, argv)
int argc;
char **argv;
{
	char addr[100], user[100], buf[MAXBUF];
	extern char *optarg;
	char *doms[MAXDOMS];			/* Each component of domain */
	int count, i, c, hf = FALSE, mf = FALSE, uf = FALSE;
	int verbose = FALSE, found;

	progname = argv[0];
	(void)strcpy(user, "");

	while ((c = getopt(argc, argv, "vh:m:u:")) != EOF)
		switch (c)
		{
			case 'h':
				database = UUHOSTINDEX;
				(void)strcpy(addr, optarg);
				hf = TRUE;
				break;
			case 'm':
				database = PATHALIAS;
				(void)strcpy(addr, optarg);
				mf = TRUE;
				break;
			case 'u':
				database = PATHALIAS;
				(void)strcpy(user, optarg);
				uf = TRUE;
				break;
			case 'v':
				verbose = TRUE;
				break;
			default:
				usage();
		}

	if (hf + mf + uf != 1)		/* Options are exclusive */
		usage();

	if (uf)
		splitpath(user, addr);

	/*
	 * Split addr into a list of domains. If `addr' has foo.bar.top.level
	 * it will get split into
	 *
	 *	foo.bar.top.level
	 *	.bar.top.level
	 *	.top.level
	 *	.level
	 */

	count = strsplit(addr, '.', doms);

	/*
	 * Forget about the top-level domains. They are not in (my) 
	 * PATHALIAS.
	 */

	--count;

	if (verbose)
		(void)printf("Trying '%s'\n", addr);

	found = FALSE;
	if (look(addr, buf) != 0)
	{
		for (i = 0; i < count; i++)
		{
			if (verbose)
				(void)printf("Trying '%s'\n", doms[i]);
			if (look(doms[i] - 1, buf) == 0 	/* With dot */
				|| look(doms[i] - 1, buf) == 0)	/* W/o dot */
			{
				found = TRUE;
				break;
			}
		}
	}
	else found = TRUE;

	if (found == FALSE)
		if (hf)
			return fprintf(stderr, "HOST: '%s' not found\n", addr);
		else 
			return fprintf(stderr, "Path to '%s' not found\n",addr);

	if (uf == TRUE)
	{
		(void)printf(buf, user);
		(void)putchar('\n');	
	}
	else if (mf == TRUE)
		(void)printf("Path to %s\n\t%s\n", addr, buf);
	else
		(void)printf("%s %s\n", addr, buf);
	return (0);
}

void splitpath(usr, adr)
char *usr;				/* Contains user@site or site!user */
char *adr;				/* Target will contain "site"  */
{
	char *strchr(), *ptr, a[100], u[100];

	/*
	 *  user@site  ?
	 *  Copy "site" into `adr' and chop `usr' at '@'
	 */

	if ((ptr = strchr(usr, '@')) != (char *)0)
	{
		(void)strcpy(a, ptr + 1);
		*(ptr) = '\0';
		(void)strcpy(u, usr);
	}
	else if ((ptr = strchr(usr, '!')) != (char *)0)
	{
		(void)strcpy(u, ptr + 1);
		*(ptr) = '\0';
		(void)strcpy(a, usr);
	}
	else 
	{
		(void)strcpy(a, usr);
		(void)strcpy(u, "%s");
	}

	(void)strcpy(adr, a);
	(void)strcpy(usr, u);
}
	
/*
 * From "Portable C Software by Mark Horton"
 */

int look(key, result)
char *key, *result;
{
	long pos, middle, hi, lo;
	static long pathlength = 0;
	register char *s;
	int c, flag;
	static FILE *fp;

	if (!pathlength)
	{
		if ((fp = fopen(database,"r")) == (FILE *)0) {
			(void)perror(database);
			pathlength = -1;
		}
		else {
			(void)fseek(fp, 0L, 2);
			pathlength = ftell(fp);
		}
	}

	if (pathlength == -1)
		return (-2);			/* No database file */

	lo = 0;
	hi = pathlength;
	(void)strcpy(result, key);
	(void)strcat(result, "\t");

	while (1)
	{
		pos = middle = (hi + lo + 1) /2;
		(void)fseek(fp, pos, 0);		/* Find midpoint */
		if (pos)			/*  to begin of next line */
			while ((c = getc(fp)) != EOF && c != '\n')
				;	/* Nothing */
			
		for (flag = 0, s = result; !flag; s++) {	/* Match ? */
			if (*s == '\0')
				goto solved;
			c = getc(fp);
			flag = tolower(c) - tolower(*s);
		}
		if (lo >= middle)		/* Failure ? */
			return (-1);
		if (c != EOF && flag < 0)	/* Close window */
			lo = middle;
		else
			hi = middle - 1;
	}
solved:			/* Just copy result... */
	while ((c = getc(fp)) != EOF && c != '\n')
		*result++ = c;
	*result = '\0';
	return (0);
}

int strsplit(s, sep, arg)
register char *s;
int sep;
char **arg;
{
	int count = 0;
	int wastoken = 0;

	for (; *s; ++s)
	{
		if (!wastoken)
		{
			++count;
			*arg++ = s;
		}
		wastoken = (sep != *s);
	}

	if (!wastoken)
	{
		++count;
		*arg++ = s;
	}
	*arg = (char *)0;
	return (count);
}

void usage()
{
	(void)fprintf(stderr, "Usage: %s [-h hostname] [-m mailname] [-u user] [-v]\n", progname);
	exit(1);
}
