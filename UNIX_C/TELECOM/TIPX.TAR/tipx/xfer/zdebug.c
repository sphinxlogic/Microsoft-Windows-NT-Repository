/* see zcurses.c report_lasthdr() */
/*+:EDITS:*/
/*:05-21-1990-16:00-wht@tridom-adapt ecu xfer protocols for tipwht */
int header_debug = 0;
/* vi: set tabstop=4 shiftwidth=4: */
