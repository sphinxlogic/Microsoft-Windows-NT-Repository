/*+-----------------------------------------------------------------------
	zlint.h
------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:05-21-1990-16:00-wht@tridom-adapt ecu xfer protocols for tipwht */

/* zcommon.c */
static  unsigned int getspeed();
void get_curr_dir();
/* zcurses.c */
char *get_elapsed_time();
char *get_tod();
char *mode_map();
void report_file_close();
void report_file_open_tod();
void report_file_send_open();
void report_init();
void report_last_rxhdr();
void report_last_txhdr();
void report_mode();
void report_rx_ind();
void report_rxblklen();
void report_rxpos();
void report_str();
void report_top_line();
void report_transaction();
void report_tx_ind();
void report_txblklen();
void report_txpos();
void report_uninit();
void report_window();
/* zdebug.c */
/* zmodem.c */
long rclhdr();

/* vi: set ts=4 sw=4: */
/* end of zlint.h */
