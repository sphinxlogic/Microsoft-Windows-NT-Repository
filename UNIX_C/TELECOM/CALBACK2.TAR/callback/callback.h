/*
 * callback.h - Common include file for callback system.
 *
 * Copyright 1990 Howard Lee Gayle
 *
 * $Header: callback.h,v 1.6 89/12/28 16:43:44 howard Exp $
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 1,
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * Prerequisites: howard/port.h.
 */

#include <errno.h>
#include <string.h>
#include <time.h>
#include <sys/termios.h>
#include <howard/malf.h>
#include <howard/registers.i>

#define ABORTSEC 120 /* Abort connection attempt after this many seconds.*/
#define DROPSEC   10 /* Time to leave line hung up (seconds).*/

typedef struct /* One entry in the modem reply code table mrctab[].*/
   {
   bStrT mrcStr;   /* Prefix of string from modem.*/
   boolT mrcRetry; /* True iff retry on this string.*/
   } mrcT;

typedef struct /* Contents of a state file. */
   {
   ulongT stCflag;   /* c_cflag as set by getty(8).*/
   char   stName[9]; /* Login name.*/
   } stateT;

/* Full path names of tty-specific files.  A suffix is added by initTty().*/
PRIVATE char ctlfn  [MFILE] = "/etc/local/callback/control/ttyd"; /* Control.*/
PRIVATE char lfn    [MFILE] = "/etc/local/callback/log/ttyd";     /* Log.*/
PRIVATE char statefn[MFILE] = "/etc/local/callback/state/ttyd";   /* State.*/
PRIVATE char cun    [MFILE] = "/dev/cua"; /* Dial-out device.*/
PRIVATE char tn     [MFILE] = "/dev/ttyd"; /* TTY name.*/

/* Executable of getty that execs callback0 instead of login: */
PRIVATE char getty[] = "/usr/local/free/callback/0/bin/getty-cb";

PRIVATE char    login[] = "/bin/login"; /* Login executable.*/
PRIVATE streamT ls;                     /* Log file stream.*/

PRIVATE mrcT mrctab[] = /* Modem reply code table.*/
   {
   S("BUSY"),        TRUE,
   S("CONNECT"),     FALSE,
   S("NO ANSWER"),   TRUE,
   S("NO CARRIER"),  TRUE,
   S("NO DIALTONE"), TRUE,
   NULBSTR,          FALSE,
   };

/* User messages: */
PRIVATE char umBye[] = "BYE bye\n"; /* Correct symbolic phone #.*/
PRIVATE char umNo [] = "NO no\n";   /* Unknown symbolic phone #.*/

PRIVATE cStrT speeds[] = /* Line speed as string.*/
   {
   "0",
   "50",
   "75",
   "110",
   "134.5",
   "150",
   "200",
   "300",
   "600",
   "1200",
   "1800",
   "2400",
   "4800",
   "9600",
   "19200",
   "38400"
   };

extern long time(); /* (3C).*/

PRIVATE void gts();
PRIVATE void initLog();
PRIVATE void initTty();
PRIVATE void logArgs();
PRIVATE void logMMSS();
PRIVATE void sts();

/* gts - get tty status */

PRIVATE void gts (tp)
R1 struct termios *tp; /* Points to place to store result.*/

/* Function:
 *    Call the TCGETS ioctl.  Log the results and return them.
 * Algorithm:
 *    
 * Notes:
 *    
 */
{
int i;   /* Process group.*/
int mcl; /* Modem control lines.*/

logMMSS();
if (-1 == ioctl (0, TCGETS, tp)) malf1 ("TCGETS failed");
if (-1 == ioctl (0, TIOCMGET, &mcl)) malf1 ("TIOCMGET failed");
if (-1 == ioctl (0, TIOCGPGRP, &i)) malf1 ("TIOCGPGRP failed");
FPRINTF (ls, "i: %5lo o: %6lo c: %7lo l: %6lo line: %d m: %3o pgrp: %5d\n",
         tp->c_iflag, tp->c_oflag, tp->c_cflag, tp->c_lflag, tp->c_line,
         mcl, i);
FFLUSH (ls);
}

/* initLog - start logging */

PRIVATE void initLog (cn)
bStrT cn; /* Command name.*/

/* Function:
 *    Open log file.  Write initial message.  Make standard error
 *    go to log file.
 * Algorithm:
 *    Open the log file for appending to the end, and exit on error.
 *    Print an initial message.  Flush.  Close file descriptor 2,
 *    then dup the log file's descriptor to be file descriptor 2.
 *    Test malf0().  Set the close-on-exec bit.
 * Notes:
 *    1) Once stderr corresponds to the log file, malf can be used.
 *    2) The close-on-exec bit is set on the file descriptor from
 *       the original open on the log file, but not on file descriptor 2.
 */
{
   long       ut;  /* Current system time.*/
R1 struct tm *tmp; /* Returned by localtime().*/

ls = fopen (lfn, "a+");
if (NULSTRM == ls) exit (2);
ut = time ((long *) NULL);
tmp = localtime (&ut);
FPRINTF (ls,
         "\n\f\n%d-%02d-%02d %02d:%02d:%02d %s pid: %d pgrp: %d\n",
         1900 + tmp->tm_year, 1 + tmp->tm_mon, tmp->tm_mday,
         tmp->tm_hour, tmp->tm_min, tmp->tm_sec,
         cn, getpid(), getpgrp (0));
FFLUSH (ls);
if (close (2))
   {
   FPRINTF (ls, "Can not close 2");
   exit (1);
   }
if (2 != dup (fileno (ls)))
   {
   FPRINTF (ls, "Can not dup %d", fileno (ls));
   exit (1);
   }
errno = 0;
malf0 ("stderr OK");
if (-1 == fcntl (fileno (ls), F_SETFD, 1)) malf1 ("Can not SETFD");
}

/* initTty - initialize tty-dependent file names */

PRIVATE void initTty (pfx, ftn)
bStrT pfx; /* Expected prefix of tty name.*/
bStrT ftn; /* Full tty name.*/

/* Function:
 *    Append argument to the tty-dependent file names.
 * Algorithm:
 *    
 * Notes:
 *    1) There is no checking for overflow.
 */
{
R1 bStrT s = prefix (pfx, ftn); /* Suffix of tty name.*/

if ((NULBSTR == s) || (EOS == B(*s))) exit (8);
STRCAT (ctlfn,   (cStrT) s);
STRCAT (cun,     (cStrT) s);
STRCAT (lfn,     (cStrT) s);
STRCAT (statefn, (cStrT) s);
STRCAT (tn,      (cStrT) s);
}

/* logArgs - write vector of command arguments to log file */

PRIVATE void logArgs (cn, v)
bStrT  cn; /* Command name.*/
bStrT *v;  /* Argument vector.*/

/* Function:
 *    Write command name followed by arguments to log file.
 * Algorithm:
 *    
 * Notes:
 *    
 */
{
FPUTS (cn, ls);
for (; NULBSTR != *v; ++v)
   {
   PUTC (' ', ls);
   FPUTS (*v, ls);
   }
PUTC ('\n', ls);
FFLUSH (ls);
}

/* logMMSS - log minutes & seconds */

PRIVATE void logMMSS()

/* Function:
 *    Write current minutes and seconds to log file.
 * Algorithm:
 *    
 * Notes:
 *    1) This function is typically called to start each line written
 *       to the log file.  The initial log message gives the complete
 *       date and time, so it's only necessary to log minutes & seconds.
 */
{
   long       ut;  /* Current system time.*/
R1 struct tm *tmp; /* Returned by localtime().*/

ut = time ((long *) NULL);
tmp = localtime (&ut);
FPRINTF (ls, "%02d%02d ", tmp->tm_min, tmp->tm_sec);
}

/* sts - set tty status */

PRIVATE void sts (tp)
struct termios *tp;

/* Function:
 *    Call TCSETS ioctl.  Flush.  Call gts().
 * Algorithm:
 *    
 * Notes:
 *    1) Calling gts() at the end verifies and logs what was set.
 */
{
if (-1 == ioctl (0, TCSETS, tp)) malf1 ("TCSETS failed");
if (-1 == ioctl (0, TCFLSH, 2)) malf1 ("TCFLSH failed");
gts (tp);
}
