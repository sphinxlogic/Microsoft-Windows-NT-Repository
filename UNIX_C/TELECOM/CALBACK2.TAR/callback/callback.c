/*
 * callback - forked from init process for dialup lines
 */

#ifndef lint
static char _cpyrgt[] = "Copyright 1990 Howard Lee Gayle";
#endif lint

/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 1,
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <howard/port.h>
#include <howard/version.h>
#include <howard/usage.h>

MAINVER ("@(#)$Header: callback.c,v 1.11 89/12/28 10:34:24 howard Exp $");
USAGE ("speed ttyd*");

#include <fcntl.h>
#include "callback.h"

/* close01 - close fd 0 & 1 & report errors */

PRIVATE void close01()

/* Function:
 *    Close standard input and standard output.  Call malf1() on error.
 * Algorithm:
 *    
 * Notes:
 *    
 */
{
if (close (0)) malf1 ("Can not close 0");
if (close (1)) malf1 ("Can not close 1");
}

/* main - main function							*/

PUBLIC int main (argc, argv)
   int    argc; /* Number of arguments.*/
R1 bStrT *argv; /* Points to array of argument strings.*/

/* Function:
 *    Exec either the special getty or login.
 * Algorithm:
 *    Set real & effective group IDs to 0.  Close standard input,
 *    output, and error.  Get suffix of ttyd* argument and call
 *    initTty() to append it to the tty-dependent file names.
 *    Open log file and make standard error go to it.  Write
 *    initial log file message.  Try to open state file.  If there
 *    is no state file, exec the special getty.  But if there is
 *    a state file, read it in and remove it.  Open standard input
 *    and output as the tty.  Set the tty to the
 *    correct modes for login.  Make standard error correspond to
 *    the tty.  Exec login.
 * Notes:
 *	
 */

{
R2 streamT         sis; /* State file input stream.*/
   stateT          st;  /* State file contents.*/
   struct termios  ts;  /* TTY status.*/

if (-1 == setregid (0, 0)) exit (3);
(void) close (0);
(void) close (1);
(void) close (2);
if (argc < 3) exit (7);
initTty (S("ttyd"), argv[2]);
if (0 != open (lfn, O_APPEND | O_CREAT, 0640)) exit (4);
if (1 != dup (0)) exit (5);
if (2 != dup (0)) exit (6);
initLog ("callback");
sis = fopen (statefn, "r");
if (NULSTRM == sis)
   {
   FPRINTF (ls, "No %s\n", statefn);
   FFLUSH (ls);
   close01();
   if (fclose (stderr))
      {
      FPRINTF (ls, "Can not close stderr\n");
      exit (1);
      }
   logArgs ((bStrT) getty, argv);
   execv (getty, argv);
   FPRINTF (ls, "%s: can not exec\n", getty);
   exit (1);
   }
if ((1 != fread ((cStrT) &st, sizeof (stateT), 1, sis)) || ferror (sis))
   malf1 ("%s: Read error", statefn);
mfclose (sis, statefn);
if (unlink (statefn)) malf1 ("%s: Can not unlink", statefn);
FPRINTF (ls, "Rm %s\n", statefn);
FFLUSH (ls);
close01();
if (0 != open (tn, O_RDWR)) malf1 ("%s: Can not open read/write", tn);
if (1 != dup (0)) malf1 ("Can not dup 1");
gts (&ts);
ts.c_iflag = (IGNPAR | IMAXBEL);
ts.c_cflag = st.stCflag;
ts.c_lflag |= (ECHO | ECHOE | ECHOK | TOSTOP | ECHOCTL | ECHOKE);
sts (&ts);
if (fclose (stderr))
   {
   FPRINTF (ls, "Can not close stderr\n");
   exit (1);
   }
if (2 != dup (0))
   {
   FPRINTF (ls, "Can not dup 2\n");
   exit (1);
   }
FPRINTF (ls, "%s -p %s\n", login, st.stName);
FFLUSH (ls);
execl (login, "login", "-p", st.stName, NULCSTR);
FPRINTF (ls, "%s: can not exec\n", login);
exit (1);
#ifdef lint
return (SUCCESS);
#endif
}
