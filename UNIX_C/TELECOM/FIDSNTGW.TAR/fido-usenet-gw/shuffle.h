#define MAX_CONVERT_BUFFERS 10
#define MAX_CONVERT_BUFLEN 80
static char bufs[MAX_CONVERT_BUFFERS][MAX_CONVERT_BUFLEN], *tcharp;
static int bflag;

#define SHUFFLEBUFFERS \
loop_increment(bflag, MAX_CONVERT_BUFFERS); tcharp = bufs[bflag]
