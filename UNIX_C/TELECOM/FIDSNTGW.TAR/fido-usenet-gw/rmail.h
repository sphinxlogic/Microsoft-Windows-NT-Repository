/* @(#)%M%  %I%  Teemu Torma %H%

   Definitions for rmail

   @(#)Copyright (c) 1987 by Teemu Torma

   Permission is given to distribute this program and alter this code as
   needed to adapt it to forign systems provided that this header is
   included and that the original author's name is preserved. */

/* Configurable definitions. Change them to according your configuration. */

#define FIDOMAILER "/usr/llib/fnet/rfmail" /* fidonet mailer */
/* #define RMAIL "/usr/lib/mail/rmail" /* real rmail */
#define RMAIL "/bin/rmail" /* real rmail */
#undef GATEWAY /* "pgmf" /* route to fidonet gateway */
/* above undef??? */

/* Don't touch the rest if you are not absolutely sure what you are
   doing... */

#define True (1)
#define False (0)
#define bool int
#define marray(n) ((char **) malloc((unsigned) ((n) * sizeof(char *))))
