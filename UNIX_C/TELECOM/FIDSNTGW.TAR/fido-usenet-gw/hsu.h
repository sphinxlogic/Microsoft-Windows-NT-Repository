#ifndef H_HSU
#define H_HSU 1

/* I'm here !!! */

#define HSU 1

/* I fucked it up again */

#define HSU_ERROR 100

/* to debug or not to debug */

#ifdef DEBUG
#define LOG(level, x) printf x; _rkey()
#define DBUG(x) LOG(D_ALL, (x))
#else
#define LOG(level, x)
#define DBUG(x)
#endif
#define D_LOG 1
#define D_ALL 2
#define D_TEMP 4

/* Specifies machine I run on */

/* & needed to take address of setjmp variable? */
#ifdef unix
#define ADDRESS_OF_SETJMP_VARIABLE (char *) &
#endif
#ifdef MSDOS
#define ADDRESS_OF_SETJMP_VARIABLE (char *) &
#endif
#ifndef ADDRESS_OF_SETJMP_VARIABLE
pang, pang, youre dead !!
#endif

/* General stuff I like */

#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

#define LINEBUF 256
#define ERRBUF 512

#define FLOATCHARS "0123456789.-eE+"
#define INTCHARS "0123456789-"
#define UNSIGNEDCHARS "0123456789"
#define SEPARATORS " ,;\015\012\011"
#define WHITESPACE " \015\012\011"

/* If ALIGN_ODD defined, align long, int, double to n lower bits */

#define ALIGN_ODD 1

/* New alignment system, use this now and ignore ALIGN_ODD */

#ifdef MSDOS
#define SIZEOFINT 2
#define INT_ALIGN 2
#define CHAR_ARRAY_ALIGN 1
#define LONG_ALIGN 2
#define DOUBLE_ALIGN 2
#define CHAR_ALIGN 1
#endif
#ifdef i286
#define SIZEOFINT 2
#define INT_ALIGN 2
#define CHAR_ARRAY_ALIGN 1
#define LONG_ALIGN 2
#define DOUBLE_ALIGN 2
#define CHAR_ALIGN 1
#endif
#ifdef i386
#define SIZEOFINT 4
#define INT_ALIGN 4
#define CHAR_ARRAY_ALIGN 1
#define LONG_ALIGN 4
#define DOUBLE_ALIGN 4
#define CHAR_ALIGN 1
#endif
#if defined(mc68k) || defined(m68k) || defined(m68000) || defined(m68k32)
#define SIZEOFINT 4
#define INT_ALIGN 4
#define CHAR_ARRAY_ALIGN 1
#define LONG_ALIGN 4
#define DOUBLE_ALIGN 4
#define CHAR_ALIGN 1
#endif

#ifndef SIZEOFINT
pang, pang, youre dead!!
#endif

/* Pointer type is int/long etc with size same as pointers */

#define POINTER_TYPE long

/* keys */

#define ESC 27

/* Can't live without this macro */

#ifdef lint
extern char *strsave(), *strasave();
#else
#define strsave(s) (strcpy(malloc((unsigned) (strlen(s) + 1)), (s)))
#define strasave(s) (strcpy(alloca((unsigned) (strlen(s) + 1)), (s)))
#endif
#define strequ(x,y) (strcmp(x,y) == 0)
#define strnequ(x,y) (strcmp(x,y) != 0)
#define strnotnull(x) (*x != '\0')
#define strnull(x) (*x == '\0');
/* Pointer to end of string */
#define strend(x) ((x) + strlen(x))

/* Increment counter, looping back to 0 if wrap-over */

#define loop_increment(x,y) (x = (++x >= (y)) ? 0 : x)
#define loop_decrement(x,y) (x = (--x < 0) ? (y)-1 : x)

/* I use this always */

#define curse(buf) waddstr(crnt_window,buf); wrefresh(crnt_window)

#define BIT0 1
#define BIT1 2
#define BIT2 4
#define BIT3 8
#define BIT4 16
#define BIT5 32
#define BIT6 64
#define BIT7 128
#define BIT8 256
#define BIT9 512
#define BIT10 1024
#define BIT11 2048
#define BIT12 4096

/* Some procedures */

extern char *alloca(), *strncpy(), *strncat(), *sprintfs(), *sstrcat();
extern char *mktemp(), *strclean(), *strsclean();
extern int strempty();
extern void exit(), qsort();
extern long time();
extern unsigned short getuid();
extern unsigned short geteuid();
extern unsigned short getgid();
extern unsigned short getegid();
extern unsigned alarm();
extern unsigned sleep();

/* Some typedefs */

typedef         int (*INT_FP)();

/* Defines which are not in std libraries (why!?) */

extern char *optarg, *sys_errlist[], *getenv();
extern int optind, opterr, errno, sys_nerr;
extern long atol();

/* I like it, and it's not always defined in math.h, (not in msc headers). */

#ifndef _ABS
#define _ABS(x) ((x) < 0 ? -(x) : (x))
#endif
#ifndef _MIN
#define _MIN(x, y) ((x) < (y) ? (x) : (y))
#endif

/* Macro version of getw putw. w is destination. */

#define FGETW(w, fp) \
  if ((fp)->_cnt < sizeof(int)) w = getw(fp); \
  else { w = *(int *) (fp)->_ptr; \
       (fp)->_ptr += sizeof(int); (fp)->_cnt -= sizeof(int); }

#define FPUTW(w, fp) \
  if ((fp)->_cnt < sizeof(int)) putw(w, fp); \
  else { *(int *) (fp)->_ptr = w; \
       (fp)->_ptr += sizeof(int); (fp)->_cnt -= sizeof(int); }

#define FGETINT16(w, fp) \
  if ((fp)->_cnt < sizeof(short)) fread( (char *) &(w), sizeof(short), 1, fp);\
  else { w = *(short *) (fp)->_ptr; \
       (fp)->_ptr += sizeof(short); (fp)->_cnt -= sizeof(short); }

#define FPUTINT16(w, fp) \
  if ((fp)->_cnt < sizeof(short)) \
    fwrite( (char *) &(w), sizeof(short), 1, fp); \
  else { *(short *) (fp)->_ptr = w; \
       (fp)->_ptr += sizeof(short); (fp)->_cnt -= sizeof(short); }

#define FGETLW(w, fp) \
  if ((fp)->_cnt < sizeof(long)) fread( (char *) &w, sizeof(long), 1, fp); \
  else { w = *(long *) (fp)->_ptr; \
       (fp)->_ptr += sizeof(long); (fp)->_cnt -= sizeof(long); }

#define FPUTLW(w, fp) \
  if ((fp)->_cnt < sizeof(long)) fwrite( (char *) &w, sizeof(long), 1, fp); \
  else { *(long *) (fp)->_ptr = w; \
       (fp)->_ptr += sizeof(long); (fp)->_cnt -= sizeof(long); }

#ifdef SAFE
#define FREAD(p, bytes, nitems, fp) (void) fread(p, bytes, nitems, fp)
#define FWRITE(p, bytes, nitems, fp) (void) fwrite(p, bytes, nitems, fp)
#else

/* And fread, fwrite. Don't return a value, so it has to be checked. */
/*

  could this work? test it!
  #define FREAD(p, bytes, nitems, fp)
  (((fp)->_cnt < (nitems) * (bytes)) ? fread(p, bytes, nitems, fp) :
  nitems, memcpy( (p), (char *) (fp)->_ptr, (int) ((nitems) * (bytes))),
  (fp)->_ptr += (nitems) * (bytes), (fp)->_cnt -= (nitems) * (bytes))

  */
#define FREAD(p, bytes, nitems, fp) \
  if ((fp)->_cnt < (nitems) * (bytes)) (void) fread(p, bytes, nitems, fp); \
  else { memcpy( (p), (char *) (fp)->_ptr, (int) ((nitems) * (bytes))); \
       (fp)->_ptr += (nitems) * (bytes); \
         (fp)->_cnt -= (nitems) * (bytes); }

#define FWRITE(p, bytes, nitems, fp) \
  if ((fp)->_cnt < (nitems) * (bytes)) (void) fwrite(p, bytes, nitems, fp); \
  else { memcpy( (char *) (fp)->_ptr, (p), (int) ((nitems) * (bytes))); \
       (fp)->_ptr += (nitems) * (bytes); \
         (fp)->_cnt -= (nitems) * (bytes); }
#endif

/* FGETS differ from original: \n in the end is NOT copied!! (because
   I don't like that) */

extern char *strnchr();

#define FGETS(cp, maxlen, fp) \
  if (strnchr((fp)->_ptr, '\n', (fp)->_cnt)) \
{ \
  register count; \
  register char *p; \
  for (count = 1, p = cp; (*p = *(fp)->_ptr++) != '\n'; p++, count++) \
    if (count >= (maxlen)) break; \
  *p = '\0'; \
  (fp)->_cnt -= count; \
} else { \
  fgets(cp, maxlen, fp); \
  if (strchr(cp, '\n')) *(strchr(cp, '\n')) = '\0'; \
}

/* Checks for both eof and error status, better than feof || ferror when
   compilers are stupid enough not to optimize that kind of situation. */

#define ferr(fp) ((fp)->_flag & (_IOEOF | _IOERR))

#endif /* H_HSU */

