/* @(#)%M%  %I%  Teemu Torma %H%

   Definitions for io.

   @(#)Copyright (c) 1987 by Teemu Torma

   Permission is given to distribute this program and alter this code as
   needed to adapt it to forign systems provided that this header is
   included and that the original author's name is preserved. */

/* Telink/xmodem special characters. */

#define SOH (0x01) /* first character of xmodem block */
#define STX (0x02) /* send 1 k blocks */
#define ENQ (0x05) /* Bink sends this if there is no mail to pick up */
#define ACK (0x06) /* ok to send */
#define NAK (0x15) /* fail, resend */
#define SYN (0x16) /* first character of telink block */
#define EOT (0x04) /* end of stransmission */
#define SUB (0x1a) /* end of filename in MODEM7 */
#define CTRLZ (0x1a) /* char to fill partial packet */

/* Definitions for xmodem. */

#define BlockSize (128) /* small xmodem sector size */
#define KBlockSize (1024) /* one k-byte xmodem sector size */

/* Misc. definitions. */

#define TSYNCH (0xae) /* sync character for fido */
#define TIMEOUT (-2) /* timeout on readline() */
