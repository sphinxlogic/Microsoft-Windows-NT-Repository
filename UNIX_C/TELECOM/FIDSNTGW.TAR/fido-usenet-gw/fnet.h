/* @(#)%M%  %I%  Teemu Torma %H%

   General definitions for fidonet software

   @(#)Copyright (c) 1987 by Teemu Torma

   Permission is given to distribute this program and alter this code as
   needed to adapt it to forign systems provided that this header is
   included and that the original author's name is preserved. */

#define PROGRAMNAME "rfmail 0.3.3"

/* General defines to make program more readable and easier to write... */

#define True (1)
#define False (0)
#define bool int
#ifdef lint
extern char *strsave();
#else
#define strsave(s) (strcpy(malloc((unsigned) (strlen(s) + 1)), (s)))
#endif
#define BUFLEN 256
#define OK (0)
#define ERROR (-1)

/* Global variables. */

extern bool verbose;
extern int line;
extern int receiving_data;

/* Function declarations. */

extern int fine_convert();
extern char *ascnode();
extern char *internode();
extern char *ascnodei();
extern char *ascii_convert();
extern int stricmp();
extern int strnicmp();
extern char *sprintfs();
extern time_t getdate();
extern char *alloca();
extern void flush();
extern void sendline();
extern char *getcl();
extern void section();
extern void log();
extern void debug();
extern int lock();
extern int unlock();
extern char *spoolfile();
extern int quit();
extern char *basename();
extern FILE *pfopen();
extern char *date();
extern long job_number();
extern char *parse_address();
extern long sequencer();
extern char *mheader();
