/* This is for functions not defined anywhere */

#include <stdio.h>
#include <sys/types.h>
#include "hsu.h"
#include "config.h"

#ifdef lint
/*ARGSUSED*/
lockf(fd, mode, position) int fd, mode; long position; { return 0; }
/*ARGSUSED*/
char *strnchr(p, c, maxlen) unsigned char *p; int c, maxlen;
{ return (char *) p; }
/*ARGSUSED*/
char *strsave(s) char *s; { return s; }
/*ARGSUSED*/
/*VARARGS1*/
char *regex(re) char *re; {}
/*ARGSUSED*/
time_t getdate(p, now) char *p; struct timeb *now; { return 0L; }
#endif


