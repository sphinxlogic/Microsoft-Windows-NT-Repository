#include <stdio.h>
#include <string.h>
#include "hsu.h"

/* Searches char * table for string */

int listscan(list,search)
char **list;
char *search;
{
  register int i;
  static char *p1, *p2;

  i = 0;
  p1 = *list++;
  while (*p1 != '\0') {
    p2 = search;
    while (*p1 == *p2) {
      if (*p1++ == '\0')
    return(i);
      p2++;
    }
    if (*p2 == ' ') return i;
    i++;
    p1 = *list++;
  }
  return -1;
}

