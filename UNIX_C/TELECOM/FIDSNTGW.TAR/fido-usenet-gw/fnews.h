/* @(#)%M%  %I% Teemu Torma %H%

   Definitions for fidonet news-system.

   @(#)Copyright (c) 1987 by Teemu Torma

   Permission is given to distribute this program and alter this code as
   needed to adapt it to forign systems provided that this header is
   included and that the original author's name is preserved. */

/* Section definitions for configure file. */

#define SECT_NETNODE (1) /* Net/node for receiving node */
#define SECT_NG_AREA (2) /* Newsgroup -> area conversions */
#define SECT_HEADERS (3) /* Header-field definitions */
#define SECT_ENDMSG (4) /* Text to be placed at the end of msg */
#define SECT_AREA_NG (5) /* Area -> newsgroup conversions */

/* Other definitions for news-system. */

/* If you have some junk area (like junk in Usenet News), define this
   to name of that area. Otherwise messages to unknown areas will
   be dicarded. */
#define JUNK_AREA "FNET.JUNK" /**/

/* Usenet news junk area. Unknown echos are put here */
#define JUNK "junk" /**/
