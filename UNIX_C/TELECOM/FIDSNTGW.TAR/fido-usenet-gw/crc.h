/* %M%  %I%  Teemu Torma %H%

   Header file for updcrc macro.

   @(#)Copyright (c) 1987 by Teemu Torma

   Permission is given to distribute this program and alter this code as
   needed to adapt it to forign systems provided that this header is
   included and that the original author's name is preserved. */

extern unsigned short crctab[];

/* #define updcrc(c, crc) (crctab[((crc >> 8) & 255)] ^ (crc << 8) ^ c) */
#define updcrc(c, crc) (crctab[((crc >> 8) & 255) ^ ((c) & 255)] ^ (crc << 8))
