#define LCKFILE "/usr/spool/uucp/LCK/LCK..ttyh0"
#define KERMIT "/usr/uncw/kermit" /*where you keep your kermit*/
#ifdef BSD
#define DEVICE "/dev/ttyh8"
#else
#define DEVICE "/dev/contty"
#endif
#define SPEED "1200"
#define S1 "ate1q0x4v1\015"
#define S2 "atz\015"
#define S1L strlen(S1)
#define S2L strlen(S2)
#ifdef BSD
#define SED1 "sed '/ttyh0/s/^1/0/' /etc/ttys >/tmp/dialout.tmp"
#define SED2 "sed '/ttyh0/s/^0/1/' /etc/ttys >/tmp/dialout.tmp"
#else
/*SysV*/
#define SED1 "sed '/^ct:/s/respawn/off/' /etc/inittab>/tmp/dialout.tmp"
#define SED2 "sed '/^ct:/s/off/respawn/' /etc/inittab>/tmp/dialout.tmp"
#endif
#define CAT "cat /usr/lib/uucp/avatex.data"
#define AUTHFILE "/etc/dialout.auth"
#ifdef BSD
#define DIFF1	"diff /etc/ttys /tmp/dialout.tmp"
#define CP1		"cp /etc/ttys /etc/ttys.bak.tst"
#define CP2		"cp /tmp/dialout.tmp /etc/ttys"
#define DIFF2	"diff /etc/ttys /tmp/dialout.tmp"
#define CP3		"cp /tmp/dialout.tmp /etc/ttys"
#else
#define DIFF1	"diff /etc/inittab /tmp/dialout.tmp"
#define CP1		"cp /etc/inittab /etc/ttys.bak.tst"
#define CP2		"cp /tmp/dialout.tmp /etc/inittab"
#define DIFF2	"diff /etc/inittab /tmp/dialout.tmp"
#define CP3		"cp /tmp/dialout.tmp /etc/inittab"
#endif
