/* program to kill getty & bring up kermit on a tty line*/
/* probably dynix specific ... don't know, don't care */
/* j. nelson, (nelson@uncw.uucp) (nelson@ecsvax.uncecs.edu) */
/* latest revision 
Sat Mar 10 15:32:08 EST 1990
*/
#include <stdio.h>
#include <fcntl.h>
#include <pwd.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "dialout.h"
/* the dialout.h files should be in specific subdirectories, e.g.*/
/*avatex, courier, etc. */
main(argc,argv)char *argv[];
{
	int i,fd; 
		unsigned long t;
	FILE *fp;
	char buf[120], name[12], *strncpy();
	struct passwd *p, *getpwuid();
	char *q, *getlogin();

	(void)argc;
	(void)argv; /*strictly for lint*/
	q=getlogin();
	if(!authorized(q)){
		fprintf(stderr,"%s not authorized to dialout\n",q);
		exit(1);
		}
	{
		fp=fopen("/tmp/dialoutlog","a");
		if(!fp)exit(2);
		t=time(0);
		fprintf(fp," + %s %s",q,ctime(&t));
		fclose(fp);

	}
	if(geteuid()!=0){
		fprintf(stderr,"oops, this prog should be setuid root\n");
		error(1);
	}
	fiddle();
	p = getpwuid(getuid());
	(void)strncpy(name,p->pw_name,11);
	for(i=0;i<12;i++)if(name[i]<' ' || name[i]>0176)name[i]=0;
	fprintf(stderr,"%s\n",name);
	if(stat(LCKFILE,(struct stat *)0)>=0)
	{
		fd=open(LCKFILE,0);
		if(fd>=0){
			fprintf(stderr,"oops\n");
			fprintf(stderr,"%s busy\n",LCKFILE);
			i=read(fd,buf,11);
			if(i>0)fprintf(stderr,"by %s ... try later\n",buf);
			error(2);
		}
	}
	else {
		fprintf(stderr,"ok no lock\n");
	}
	(void)system(SED1);
/*	(void)system("	diff /etc/ttys /tmp/dialout.tmp");*/
	(void)system(DIFF1);
/*	(void)system("	cp /etc/ttys /etc/ttys.bak.tst");*/
	(void)system(CP1);
/*	(void)system("	cp /tmp/dialout.tmp /etc/ttys");*/
	(void)system(CP2);
	i=kill(1,1); /*kill(pid,signal)*/
	if(i<0){
		fprintf(stderr,"could not kill(1,1)\n");
		error(3);
	}
	(void)system("	rm -f /tmp/dialout.tmp" );
	fd=open(DEVICE,1);
	if(fd<0){
		error(4);
	}
	i=write(fd,S1,S1L);
	if(i<0)error(5);
	sleep(1);
	(void)system(CAT);

	fiddle();
/*	i=fchown(fd,getuid(),getgid());*/
/* apparently SysV does not have fchown() nor fchmod() :-(  */
	i=chown(DEVICE,getuid(),getgid());
	if(i<0)error(6);
/*	i=fchmod(fd,0666);*/
	i=chmod(DEVICE,0666);
	if(i<0)error(7);
	i=close(fd);
	if(i<0)error(8);

	if(fork()==0)
	{
		/*child*/
		i=setuid(getuid());/*relinquish root privileges in child*/
		if(i<0 || geteuid()==0)error(9);
		fprintf(stderr,"PLEASE exit from kermit normally so that\n");
		fprintf(stderr,"the modem line can be reset properly.\n");
		fprintf(stderr,
		"The proper way is ctrl-\\, then \"c\", then \"ex\"\n");

		(void)execl(KERMIT,"kermit","-l",DEVICE,
		"-b",SPEED,(char *)NULL);
		fprintf(stderr,"exec failed\n");/*should never happen*/
		error(10);/*should never happen*/
	}
	else
	{
		/*parent*/
		/* (parent is still root) */
		(void)wait(0);
		fd=open(DEVICE,1);
		if(fd<0){
			error(11);
		}
		i=write(fd,S2,S2L);
		if(i<0)error(12);
		fprintf(stderr,"wait...\n");
		sleep(2);
/*	i=fchown(fd,0,0);*/
	i=chown(DEVICE,0,0);
	if(i<0)error(6);
/*	i=fchmod(fd,0666);*/
	i=chmod(DEVICE,0666);
	if(i<0)error(7);
		i=close(fd);
		if(i<0)error(13);
		(void)unlink(LCKFILE); /*ignore error, because kermit didit*/
		(void)system(SED2);

/*		(void)system("	diff /etc/ttys /tmp/dialout.tmp");*/
		(void)system(DIFF2);
/*		(void)system("	cp /tmp/dialout.tmp /etc/ttys");*/
		(void)system(CP3);
		i=kill(1,1); /*kill(pid,signal)*/
		if(i== -1){
			fprintf(stderr,"could not kill(1,1)\n");
			if(getuid()!=0 && getuid()!=100)error(14);
		}
		(void)system("	rm -f /tmp/dialout.tmp" );

	
		fp=fopen("/tmp/dialoutlog","a");
		if(!fp)exit(2);
		t=time(0);
		fprintf(fp," - %s %s",q,ctime(&t));
		fclose(fp);

	
	}
}
fiddle()
{
	struct passwd *p;
	struct stat zork;
	int i,c;
	i=stat(DEVICE,&zork);
	if(i<0)error(15);
	if(zork.st_uid != 0){
		p=getpwuid(zork.st_uid);
		fprintf(stderr,
		"the modem seems to be owned by %s\n",/*zork.st_uid*/p->pw_name);
		fprintf(stderr,"do you wish to barge right on through?");
		c=getchar(); while(getchar()!='\n');
		if(c!='y')error(16);
	}
	if((zork.st_mode & 0777) != 0622){
		fprintf(stderr,"%s has wrong mode\n",DEVICE);
		fprintf(stderr,"do you wish to barge right on through?");
		c=getchar(); while(getchar()!='\n');
		if(c!='y')error(17);
	}
}
error(i)
{
	FILE *fp;
	char *q;
	unsigned long t;
	fprintf(stderr,"error %d\n",i);
	(void)fflush(stderr);
		fp=fopen("/tmp/dialoutlog","a");
		if(!fp)exit(2);
		t=time(0);
		q=getlogin();
		fprintf(fp," - error %d %s %s",i,q,ctime(&t));
		fclose(fp);
	exit(i);
}
kindex(s,t) 
char s[],t[];
{
	int c,i,j,k;
	c=s[0];
	if(c==0){return -1;
		}
	c=t[0];
	if(c==0){return -1;
		}
	for(i=0;s[i] !='\0'; i++){
		for(j=i,k=0;t[k] !='\0' && s[j]==t[k];j++,k++)
				;
		if(t[k]=='\0')return (i);
	}
		return(-1);
} 
authorized(name)
char *name;
{
	FILE *fp;
	int k;
	char buf[99];
	fp=fopen(AUTHFILE,"r");
	if(!fp)return 0;
	while( fgets(buf,98,fp)==buf){
	if(kindex(buf,name)==0){
		fclose(fp);
		return 1;
	}
	}
	fclose(fp);
	return 0;

}
