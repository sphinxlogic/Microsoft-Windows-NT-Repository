/*
 *	program options
 */

extern	bool	verbose;

extern	FILE	* outfd;
extern	FILE	* infd;

extern	char	* font_sub_file;
