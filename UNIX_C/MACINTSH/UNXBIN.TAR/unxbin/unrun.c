/*
 * remove run length problems
 */

#include <stdio.h>

main()
{
	int c;
	while ( (c = getchar()) != EOF )
	{
		putchar( c );
		if ( c == 0x90 )
			putchar( 0 );
	}
}
