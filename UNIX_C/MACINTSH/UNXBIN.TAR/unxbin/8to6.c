/*
 * Convert 8 bit data stream into 6 bit data stream.  
 * The approach is very dumb, but I was in a hurry.
 */

#include <stdio.h>

char tr[]="!\"#$%&'()*+,-012345689@ABCDEFGHIJKLMNPQRSTUVXYZ[`abcdefhijklmpqr";

getbit()
{
	static int c, mask = 0x00;
	static int count;

	if ( mask == 0 ) {
		mask = 0x80; c = getchar();
		if ( c == EOF )
			if ( count % 3 == 0 )
				return -1;
			else
				c = 0;	/* make everything come out even */
		count++;
	}
	if ( c & mask )
	{
		mask >>= 1; return 1;
	} else {
		mask >>= 1; return 0;
	}
}

main()
{
	int bits = 0; int c;
	int count; int val;

	printf( "(This file must be converted with something)\n:" );
	count = 1;
	while ( ( val = getbit() ) != -1 )
	{
		c = c + c + val; bits++;
		if ( bits == 6 ) {
			bits = 0; putchar( tr[ c ] ); c = 0;
			if ( count++ > 62 ) {
				count = 0; putchar( '\n' );
			}
		}
	}
	if ( bits != 0 )
		write( 2, "no bits\n", 8 );
	putchar( ':' ); putchar( '\n' );
}
