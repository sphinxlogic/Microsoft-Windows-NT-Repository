/*
 * filter to change a foo.info file into a proper header for a .hqx file
 */

char head[ 128 ];

main()
{
	int n;

	read( 0, head, 128 );

	put( 1, 1 );

	for ( n = 0; n < head[1]; n++ )
		put( 1, n+2 );
	head[0] = 0; put( 1, 0 );
	put( 4, 65 ); put( 4, 69 );
	put( 2, 63 ); put( 4, 83 );
	put( 4, 87 );
}

put( cnt, offset )
{
	while ( cnt-- > 0 )
		putchar( head[ offset++ ] );
}
