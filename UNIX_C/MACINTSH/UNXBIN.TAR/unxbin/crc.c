/*
 * compute the crc used in .hqx files
 */
#include <stdio.h>

int crc, temp;

main()
{
	int c;

	crc = 0;
	while ( ( c = getchar() ) != EOF )
		docrc( c );
	docrc(0); docrc(0);
	putchar( (crc>>8) & 0xff ); putchar( crc & 0xff );
}

docrc( c )
	int c;
{
	register int i;
	temp = crc;
	for ( i = 0; i < 8; i++ )
	{
		c <<= 1;
		if ( (temp <<= 1) & 0x10000 )
			temp = (temp & 0xffff) ^ 0x1021;
		temp ^= (c >> 8);
		c &= 0xff;
	}
	crc = temp;
}
