#include <stdio.h>
main(argc,argv)
int argc;
char **argv;
{
/*	structure of the info file - from MacBin.C
	char zero1;
	char nlen;
	char name[63];
	char type[4];		65	0101
	char creator[4];	69
	char flags;		73
	char zero2;		74	0112
	char location[6];	80
	char protected;		81	0121
	char zero3;		82	0122
	char dflen[4];
	char rflen[4];
	char cdate[4];
	char mdate[4];
*/
	FILE *fd, *ofd;
	char iname[128];
	char dname[128];
	char rname[128];
	char oname[128];
	char buf[128];
	if (argc != 2) {
		fprintf(stderr,"\nUsage: %s filename\n",argv[0]);
		exit(1);
	}
	bzero(buf,128);
	strcpy(oname,argv[1]);
	strcat(oname,".bin");
	if ((ofd = fopen( oname, "w")) == NULL){
		fprintf(stderr, "\n Cannot open %s\n",oname);
		exit(1);
	}
	strcpy(iname,argv[1]);
	strcat(iname,".info");
	if ((fd = fopen(iname,"r")) == NULL){
		fprintf(stderr,"No %s file!\n", iname);
		fclose(ofd);
		unlink(oname);
		exit(1);
	}
	if (fread(buf, sizeof(*buf), 128, fd) > 0){
		if (buf[74] & 0x40) buf[81] = '\1'; /* protected */
		buf[74] = '\0'; /* clear zero2 */
		fwrite(buf, sizeof(*buf),128, ofd);
		bzero(buf,128);
	}
	fclose(fd);
	strcpy(dname,argv[1]);
	strcat(dname,".data");
	if ((fd = fopen(dname,"r")) == NULL){
		fprintf(stderr,"No %s file!\n", dname);
		fclose(ofd);
		unlink(oname);
		exit(1);
	}
	while (fread(buf, sizeof(*buf),128, fd) > 0){
		fwrite(buf, sizeof(*buf),128, ofd);
		bzero(buf,128);
	}
	fclose(fd);
	strcpy(rname,argv[1]);
	strcat(rname,".rsrc");
	if ((fd = fopen(rname,"r")) == NULL){
		fprintf(stderr,"No %s file!\n", rname);
		fclose(ofd);
		unlink(oname);
		exit(1);
	}
	while (fread(buf, sizeof(*buf),128, fd) > 0){
		fwrite(buf, sizeof(*buf),128, ofd);
		bzero(buf,128);
	}
	fclose(fd);
}
