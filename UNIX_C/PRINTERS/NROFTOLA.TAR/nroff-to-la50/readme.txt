ulfix is a public-domain program that converts nroff-style underlines
and superscripts to the escape sequences understood by Dec LA50
and VT200 series terminals.  It is a quick hack and shouldn't
be taken seriously.

Martin Minow
decvax!minow
