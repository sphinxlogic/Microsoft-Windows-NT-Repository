/*
 * $Header: asctab.h,v 1.1 85/08/15 14:55:33 ron Exp $
 */

/*
 * asctab.h - Copyright (c) 1985 by Ron Saad
 *
 * This code may be freely distributed in source
 * for non commercial purposes.
 * Please keep this notice intact.
 */

/*
 * $Log:	asctab.h,v $
 * Revision 1.1  85/08/15  14:55:33  ron
 * Initial revision
 * 
 * 
 */

char *asctab[] ={
	/*
	 * these should be things that are "easy"
	 * to generate with esc seq and the
	 *  cartridge data, not needing a raster map,
	 *  plus things that are not available on the
	 *  special font in raster form
	 */
	"\\|", "\033&a+12H", /* 1/6 em space ?? */
	"\\^", "\033&a+36H", /* 1/2 em space ?? */
	"em", "-", /* FIX THIS TO DO 3/4 EM */
	"hy", "-",
	"\\-", "\033&a+30H-",	/* curr fnt minus - spacing problem */
	/* "mi", "\033&a+30H-",	/* SHOULD BE ON SPEC FONT */
	"ce", "\277",
		/* does not work - maybe because we have
		 * the B cartridge instead of the F one
		 */
	"dg", "|\033&a-30H-",	/* looks lousy - do better */
	"aa", "'",
	"ga", "`",
	"en", "-",
	/* "ru", "_", /* use the bit map instead */
	"l.", ".",
	"br", "|",
	"vr", "|",
	"fm", "'",
	"or", "|",
	"fi", "f\033&a-25Hi",	/* fake ligature */
	"ff", "f\033&a-25Hf",	/* fake ligature */
	"fl", "f\033&a-25Hl",	/* fake ligature */
	"Fi", "f\033&a-30Hf\033&a-25Hi",	/* fake ligature */
	"Fl", "f\033&a-30Hf\033&a-25Hl",	/* fake ligature */
	/* "sl", "\033&a-50H/", /* spacing problem - is on the spec font */
	0, 0,
};

