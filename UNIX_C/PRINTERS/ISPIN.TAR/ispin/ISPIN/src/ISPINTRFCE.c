/****************************************************************************/
/*                                                                          */
/* ISPINTRFCE - serves as the "interface" program under the lp(1) spooler.  */
/*              determines spool member name, then passes name and all      */
/*              other arguments to ISPIN for execution.                     */
/*                                                                          */
/*                                                                          */
/*                                                                          */
/*                                                                          */
/* ISPIN                                                                    */
/*                                                                          */
/* Indianapolis Standard Printer Interface (for Network printers)           */
/****************************************************************************/
/*                                                                          */
/*  Copyright (C) 1991                                                      */
/*  Larry Bartz                                                             */
/*  Internal Revenue Service                                                */
/*  Indianapolis District Office                                            */
/*                                                                          */
/*  This program is free software; you can redistribute it and/or modify    */
/*  it under the terms of the GNU General Public License as published by    */
/*  the Free Software Foundation, version 1.                                */
/*                                                                          */
/*  This program is distributed in the hope that it will be useful,         */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of          */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           */
/*  GNU General Public License for more details.                            */
/*                                                                          */
/*  You should have received a copy of the GNU General Public License       */
/*  along with this program; if not, write to the Free Software             */
/*  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.               */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* COMMENTS                                                                 */
/*                                                                          */
/* Read comments in common.h for the BIG PICTURE.                           */
/*                                                                          */
/* This small executable adds one argument to the argument vector, then     */
/* execs a centralized ISPIN executable.                                    */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* DEFINES                                                                  */
/*                                                                          */
/* Nothing defined locally in this program                                  */
/*                                                                          */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* INCLUDES                                                                 */
/*                                                                          */
/*                                                                          */
#include <stdio.h>
#include <string.h>
#include "../h/localcnfg.h"
/*                                                                          */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* DATA TYPES, VARIABLES, ETC                                               */
/*                                                                          */
/* All local to this program only.                                          */
/*                                                                          */
/*                                                                          */
/*                                                                          */
/****************************************************************************/


main(argc,argv)
int argc;
char *argv[];
{
  int args, myargs, lp_args;
  char *base, intrfce[BUFSIZ];
  char **myargv;

  myargv = (char **) calloc(argc + 1, sizeof(char *));

  base = strrchr(argv[0],'/');
  ++base;
  
  /* INTRFCE is defined in localcnfg.h */
  strcpy(intrfce,INTRFCE);
  myargv[0] = &intrfce[0];

  myargv[1] = base;

  myargs = 2;
  lp_args = 1;

  while(lp_args <= argc)
  {
    myargv[myargs++] = argv[lp_args++];
  }



  execv(INTRFCE, myargv);
  

}
