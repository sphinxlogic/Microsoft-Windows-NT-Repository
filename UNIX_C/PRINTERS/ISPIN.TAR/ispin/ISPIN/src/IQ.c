/****************************************************************************/
/*                                                                          */
/* IQ - IQUEUER query program. An executable to check current status of:    */
/*                                                                          */
/*                                                                          */
/*                                                                          */
/* IQUEUER - the secondary queueing daemon for:                             */
/*                                                                          */
/* ISPIN                                                                    */
/*                                                                          */
/* Indianapolis Standard Printer Interface (for Network printers)           */
/****************************************************************************/
/*                                                                          */
/*  Copyright (C) 1991                                                      */
/*  Larry Bartz                                                             */
/*  Internal Revenue Service                                                */
/*  Indianapolis District Office                                            */
/*                                                                          */
/*  This program is free software; you can redistribute it and/or modify    */
/*  it under the terms of the GNU General Public License as published by    */
/*  the Free Software Foundation, version 1.                                */
/*                                                                          */
/*  This program is distributed in the hope that it will be useful,         */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of          */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           */
/*  GNU General Public License for more details.                            */
/*                                                                          */
/*  You should have received a copy of the GNU General Public License       */
/*  along with this program; if not, write to the Free Software             */
/*  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.               */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* COMMENTS                                                                 */
/*                                                                          */
/* Read comments in common.h for the BIG PICTURE.                           */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* DEFINES                                                                  */
/*                                                                          */
/* Refer to common.h and iqueuer.h                                          */
/*                                                                          */
/* #define DEBUG                                                            */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* INCLUDES                                                                 */
/*                                                                          */
/* Refer to common.h and iqueuer.h                                          */
/*                                                                          */
#include "../h/iqueuer.h"
/*                                                                          */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* DATA TYPES, VARIABLES, ETC                                               */
/*                                                                          */
/* Refer to common.h and iqueuer.h                                          */
/*                                                                          */
/*                                                                          */
/*                                                                         */
/****************************************************************************/
/*                                                                          */
/* MODIFICATIONS                                                            */
/*                                                                          */
/* 10/13/89 Kevin Fannin - Modified program to print "unassigned" for port  */
/*                         when iq reports on a waiting job. Waiting jobs   */
/*                         now have the port inode number set to -1 to      */
/*                         indicate that no device has been chosen yet.     */
/****************************************************************************/

main(argc,argv)
int argc;
char *argv[];
{
  int gotstats = 0;

  int check_char, keep_char;

  int not_now();

  char out_buf[BUFSIZ];

  char *myncheck();


  count1 = count2 = 0;
  
  /* take care of the signals */
  signal(SIGINT, SIG_DFL);    /* default for "interrupt" signal <DEL> */
  signal(SIGHUP, SIG_DFL);    /* default for "hang up" signal */
  signal(SIGQUIT, SIG_DFL);   /* default for "quit" signal */
  signal(SIGALRM, SIG_DFL);   /* default for "alarm" signal */
  signal(SIGTERM, not_now);   /* trap "term" signal */

  /* allocate storage for our file status buffer */
  stat_buf = (struct stat *) calloc(1,sizeof(struct stat));


  /* what is the name of the FIFO I talk through?   */
  strcpy(outFIFO,FIFOdir);
  strcat(outFIFO,"IQUEUER");
  /* does it exist? */
  if(stat(outFIFO,stat_buf))
  {
    /* if not,      */
    /* die horribly */
    /* need to send out an error msg */
          /* format an error message */
          time(&tloc);
          nowtime = (struct tm *)localtime(&tloc);
          time_str = asctime(nowtime);
          sprintf(errmsg,"IQ: stat outFIFO: %s. time:\n",sys_errlist[errno]);
          strcat(errmsg,"                            ");
          strcat(errmsg,time_str);
          strcat(errmsg,"\n");

    fprintf(stderr,errmsg);
    exit(1);

  }


  /* An open for writing will block unless a process (IQUEUER) has the file   */
  /* open for reading.                                                        */


  signal(SIGALRM, not_now);
  alarm(5);
  /* this open of the FIFO is the one we'll use for our write           */
  if((outfifo = open(outFIFO,O_WRONLY)) == -1)
  {
    /* need to send out an error msg */
          /* format an error message */
          time(&tloc);
          nowtime = (struct tm *)localtime(&tloc);
          time_str = asctime(nowtime);
          sprintf(errmsg,"IQ: open %s: %s. time:\n",outFIFO,sys_errlist[errno]);
          strcat(errmsg,"                            ");
          strcat(errmsg,time_str);
          strcat(errmsg,"\n");

         fprintf(stderr,errmsg);
         exit(1);

  }
  alarm(0);
  signal(SIGALRM, SIG_IGN);


  /* open the status fifo */

  /* what is the name of the status FIFO ? */
  strcpy(statFIFO,FIFOdir);
  strcat(statFIFO,"STATUS");
  /* does it exist? */
  if(stat(statFIFO,stat_buf))
  {
    /* if not,      */
    /* create it if we can */
    if(mknod(statFIFO,0010666,1) != SUCCESS)
    {
      /* It didn't exist and we couldn't create it either. */
      /* All hope is lost.                                 */
      /* need to send out an error msg */
          /* format an error message */
          time(&tloc);
          nowtime = (struct tm *)localtime(&tloc);
          time_str = asctime(nowtime);
          sprintf(errmsg,"IQ: mknod statFIFO: %s. time:\n",sys_errlist[errno]);
          strcat(errmsg,"                            ");
          strcat(errmsg,time_str);
          strcat(errmsg,"\n");

          /* We can still write to stderr at this point. */
          fprintf(stderr,errmsg);

          exit(1);
    }
  }


  /* An open for reading will block unless a process (IQUEUER) has the file   */
  /* open for writing.                                                        */

  signal(SIGALRM, not_now);
  alarm(5);
  if((statropn = open(statFIFO,O_RDONLY)) == -1)
  {
    /* need to send out an error msg */
          /* format an error message */
          time(&tloc);
          nowtime = (struct tm *)localtime(&tloc);
          time_str = asctime(nowtime);
          sprintf(errmsg,"IQ: IQUEUER does not exist. time:\n");
          strcat(errmsg,"                            ");
          strcat(errmsg,time_str);
          strcat(errmsg,"\n");

          /* We can still write to stderr at this point. */
          fprintf(stderr,errmsg);

          exit(1);
  }
  alarm(0);
  signal(SIGALRM, SIG_IGN);

  free(stat_buf);

  /* format our message to the almighty IQUEUER */

      /* what type of message? */
      req_msg.typ.intgr = STATUS;
      while(count1 < intsize)
      {
        msg_buf[count2++] = req_msg.typ.chr[count1++];
      }
      count1 = 0;

      /* what is my pid? */
      req_msg.my_pid.intgr = getpid();
      while(count1 < intsize)
      {
        msg_buf[count2++] = req_msg.my_pid.chr[count1++];
      }
      count1 = 0;

      req_msg.my_fifo.intgr = 0;
      while(count1 < intsize)
      {
        msg_buf[count2++] = req_msg.my_fifo.chr[count1++];
      }
      count1 = 0;

      req_msg.dev1_inod.intgr = 0;
      while(count1 < intsize)
      {
        msg_buf[count2++] = req_msg.dev1_inod.chr[count1++];
      }
      count1 = 0;

      req_msg.dev2_inod.intgr = 0;
      while(count1 < intsize)
      {
        msg_buf[count2++] = req_msg.dev2_inod.chr[count1++];
      }
      count1 = 0;

      req_msg.dev3_inod.intgr = 0;
      while(count1 < intsize)
      {
        msg_buf[count2++] = req_msg.dev3_inod.chr[count1++];
      }
      count1 = 0;

      req_msg.dev4_inod.intgr = 0;
      while(count1 < intsize)
      {
        msg_buf[count2++] = req_msg.dev4_inod.chr[count1++];
      }
      count1 = 0;

      req_msg.dev5_inod.intgr = 0;
      while(count1 < intsize)
      {
        msg_buf[count2++] = req_msg.dev5_inod.chr[count1++];
      }
      count1 = 0;

      req_msg.dev6_inod.intgr = 0;
      while(count1 < intsize)
      {
        msg_buf[count2++] = req_msg.dev6_inod.chr[count1++];
      }
      count1 = 0;

      req_msg.dev7_inod.intgr = 0;
      while(count1 < intsize)
      {
        msg_buf[count2++] = req_msg.dev7_inod.chr[count1++];
      }
      count1 = 0;

      req_msg.dev8_inod.intgr = 0;
      while(count1 < intsize)
      {
        msg_buf[count2++] = req_msg.dev8_inod.chr[count1++];
      }
      count1 = 0;

      req_msg.dev9_inod.intgr = 0;
      while(count1 < intsize)
      {
        msg_buf[count2++] = req_msg.dev9_inod.chr[count1++];
      }
      count1 = 0;

      req_msg.dev10_inod.intgr = 0;
      while(count1 < intsize)
      {
        msg_buf[count2++] = req_msg.dev10_inod.chr[count1++];
      }
      count1 = 0;

      req_msg.dev11_inod.intgr = 0;
      while(count1 < intsize)
      {
        msg_buf[count2++] = req_msg.dev11_inod.chr[count1++];
      }
      count1 = 0;

      /* identify the requesting user */
      req_msg.uid.intgr = (int)getuid();
      while(count1 < intsize)
      {
        msg_buf[count2++] = req_msg.uid.chr[count1++];
      }
      count1 = 0;

      req_msg.loop.intgr = 0;
      while(count1 < intsize)
      {
        msg_buf[count2++] = req_msg.loop.chr[count1++];
      }
      count1 = 0;
      count2 = 0;

  /* send our message to the almighty IQUEUER */

      count1 = write(outfifo,msg_buf,to_iqrsiz);
      close(outfifo);

#ifdef DEBUG
      printf("wrote %d chars\n",count1);
#endif

      count1 = 0;

  /* read until we get a message of all zeroes */


  to_IQ.typ.lng = 1L;

  while(to_IQ.typ.lng != 0L)
  {
    chars_got = read(statropn,msg_buf, to_iq_siz);

#ifdef DEBUG
      printf("first read %d chars\n",chars_got);
#endif

    if(chars_got < 1)
    {
      close(statropn);
      if((statropn = open(statFIFO,O_RDONLY)) == -1)
      {
        /* need to send out an error msg */
              /* format an error message */
              time(&tloc);
              nowtime = (struct tm *)localtime(&tloc);
              time_str = asctime(nowtime);
              sprintf(errmsg,"IQ: IQUEUER does not exist. time:\n");
              strcat(errmsg,"                            ");
              strcat(errmsg,time_str);
              strcat(errmsg,"\n");

              /* We can still write to stderr at this point. */
              fprintf(stderr,errmsg);

              exit(1);
      }
      chars_got = read(statropn,msg_buf, to_iq_siz);

#ifdef DEBUG
      printf("second read %d chars\n",chars_got);
#endif

      
    }

    /* fill our structure of unions from the msg_buf */
    count1 = count2 = 0;

    while(count1 < longsize)
    {
      to_IQ.typ.chr[count1++] = msg_buf[count2++];
    }
    count1 = 0;

    while(count1 < longsize)
    {
      to_IQ.devinod.chr[count1++] = msg_buf[count2++];
    }
    count1 = 0;

    while(count1 < longsize)
    {
      to_IQ.my_fifo.chr[count1++] = msg_buf[count2++];
    }
    count1 = 0;

    while(count1 < longsize)
    {
      to_IQ.pid.chr[count1++] = msg_buf[count2++];
    }
    count1 = 0;

    while(count1 < longsize)
    {
      to_IQ.time_in.chr[count1++] = msg_buf[count2++];
    }
    count1 = 0;

    while(count1 < longsize)
    {
      to_IQ.time_out.chr[count1++] = msg_buf[count2++];
    }
    count1 = 0;

    while(count1 < longsize)
    {
      to_IQ.uid.chr[count1++] = msg_buf[count2++];
    }
    count1 = 0;

    while(count1 < longsize)
    {
      to_IQ.loop.chr[count1++] = msg_buf[count2++];
    }
    count1 = 0;
    count2 = 0;

    /* now see what we got */
    if(to_IQ.typ.lng != 0L)
    {
      ++gotstats;

      if(gotstats == 1)
      {
          /* do a header for jobs which are running */
          sprintf(out_buf,"PORT           ");     /* 14 positions, plus space */
          strcat(out_buf,"PRINTER        ");     /* 14 positions, plus space */
          strcat(out_buf,"PID    ");             /*  6 positions, plus space */
          strcat(out_buf,"TIME-IN  ");           /*  8 positions, plus space */
          strcat(out_buf,"STATE-TIME ");         /*  8 positions, plus space */
                                                 /*  STATE TIME header over- */
                                                 /*  -runs following field   */
          strcat(out_buf,"USER   ");             /*  8 positions, plus space */
          strcat(out_buf," LOOP ");              /*  5 positions, plus space */
          strcat(out_buf,"STATE\n\n");           /* 10 positions, plus \n's  */

          printf(out_buf);
      }

      /* make some sense of what we got */

     /**********************************************************************/

      /* If -1 was passed as inode number, this signifies that the job   */
      /* is waiting to be assigned a device once one becomes available.  */

      if (to_IQ.devinod.lng == -1)     
        strcpy(lil_buf,"unassigned");
      else
        /* get cpu port's name from inode number */
        strcpy(lil_buf,myncheck((int)to_IQ.devinod.lng,"/dev"));

      if(strlen(lil_buf) == 0)
      {
        /* need to send out an error msg */
        /* format an error message */
        time(&tloc);
        nowtime = (struct tm *)localtime(&tloc);
        time_str = asctime(nowtime);
        sprintf(errmsg,"IQ: can't find port used by ISPIN pid = %d.  time:\n",(int)to_IQ.pid.lng);
        strcat(errmsg,"                            ");
        strcat(errmsg,time_str);
        strcat(errmsg,"\n");
    
        fprintf(stderr,errmsg);
       /* don't exit */
     }

/*****************************************************************************/
     sprintf(out_buf,"%-*s",15, lil_buf);
/*****************************************************************************/
      /* get printer's fifo's name from inode number */
      /* where's his FIFO? */

      strcpy(lil_buf,myncheck((int)to_IQ.my_fifo.lng,FIFOdir));

      if(strlen(lil_buf) == 0)
      {
        /* need to send out an error msg */
        /* format an error message */
        time(&tloc);
        nowtime = (struct tm *)localtime(&tloc);
        time_str = asctime(nowtime);
        sprintf(errmsg,"IQ: can't find FIFO of ISPIN pid = %d.  time:\n",(int)to_IQ.pid.lng);
        strcat(errmsg,"                            ");
        strcat(errmsg,time_str);
        strcat(errmsg,"\n");
    
       fprintf(stderr,errmsg);
       /* don't exit */
     }


/*****************************************************************************/
     sprintf(build_cmd,"%-*s",15,lil_buf);
     strcat(out_buf, build_cmd);
/*****************************************************************************/

     sprintf(build_cmd,"%-*ld",7,to_IQ.pid.lng);
     strcat(out_buf, build_cmd);
     
     /* create something from the time */
     tloc = to_IQ.time_in.lng;
     nowtime = (struct tm *)localtime(&tloc);
     sprintf(build_cmd,"%2.2d:",nowtime->tm_hour);
     strcat(out_buf, build_cmd);
     sprintf(build_cmd,"%2.2d:",nowtime->tm_min);
     strcat(out_buf, build_cmd);
     sprintf(build_cmd,"%2.2d ",nowtime->tm_sec);
     strcat(out_buf, build_cmd);

     if((int)to_IQ.typ.lng == WAITING)
     {
       strcat(out_buf,"          ");
     }
     else
     {
       /* create something from the time */
       tloc = to_IQ.time_out.lng;
       nowtime = (struct tm *)localtime(&tloc);
       sprintf(build_cmd,"%2.2d:",nowtime->tm_hour);
       strcat(out_buf, build_cmd);
       sprintf(build_cmd,"%2.2d:",nowtime->tm_min);
       strcat(out_buf, build_cmd);
       sprintf(build_cmd,"%2.2d  ",nowtime->tm_sec);
       strcat(out_buf, build_cmd);
     }

     /* get logname from uid */
     pass = getpwuid((int)to_IQ.uid.lng);
     sprintf(build_cmd,"%-*s",8,pass->pw_name);
     strcat(out_buf, build_cmd);

     /* which loop are we on? */
     sprintf(build_cmd,"%*d",5,(int)to_IQ.loop.lng);
     strcat(out_buf, build_cmd);

     strcat(out_buf, " ");

     switch((int)to_IQ.typ.lng)
     {
       case STARTUP:
           strcat(out_buf,"STARTUP");
       break;
       case CONNECTING:
           strcat(out_buf,"CONNECT");
       break;
       case PRINTING:
           strcat(out_buf,"PRINTING");
       break;
       case LOOPING:
           strcat(out_buf,"LOOPING");
       break;
       case WAITING:
           strcat(out_buf,"WAIT port");
       break;
       case DISCONNECTING:
         strcat(out_buf,"DISCONNECT");
       break;
       case QUITTING:
         strcat(out_buf,"QUITTING");
       break;
       default:
         strcat(out_buf,"NOTIFY SYS ADMIN");
       break;
     }

     
     strcat(out_buf, "\n");


     printf(out_buf);
    }
  }
  if(gotstats == 0)
  {
    fprintf(stderr,"all quiet\n");
  }
}


not_now(sig)
int sig;
{
  /* take care of the signals */
  signal(SIGINT, SIG_IGN);    /* ignore "interrupt" signal <DEL> */
  signal(SIGHUP, SIG_IGN);    /* ignore "hang up" signal */
  signal(SIGQUIT, SIG_IGN);   /* ignore "quit" signal */
  signal(SIGALRM, SIG_IGN);   /* ignore "alarm" signal */
  signal(SIGTERM, SIG_IGN);   /* ignore "term" signal */

  switch(sig)
  {
    case SIGTERM:
       fprintf(stderr, "IQ: IQUEUER status not available now.\n"); 
    break;
    case SIGALRM:
       fprintf(stderr, "IQ: IQUEUER not running now.\n"); 
    break;
    default:
       fprintf(stderr, "IQ: IQ bombed off.\n"); 
    break;
  }

  exit(1);
}

/**************************************************************************/
/*                                                                        */
/* MYNCHECK                                                               */
/*                                                                        */
/* 04/20/89 L. Bartz, Internal Revenue Service, Indianapolis              */
/*                                                                        */
/* This function is given an inode number and (pointer to) directory      */
/* name. It returns (pointer to) file name associated with the inode      */
/* number on success, null character pointer on failure.                  */
/*                                                                        */
/* Must have been declared in the calling function like so:               */
/*                                                                        */
/*                        char *myncheck();                               */
/* Called like so:                                                        */
/*                                                                        */
/*                  strcpy(fylname,myncheck(inode,dirname));              */
/*                                                                        */
/* Where variables have been declared in the calling function like so:    */
/*                                                                        */
/*                  int inode;                                            */
/*                  char *dirname;                                        */
/*                  char fylname[DIRSIZ + 1];                             */
/*                                                                        */
/* DIRSIZ is #defined in sys/dir.h                                        */
/*                                                                        */
/*                                                                        */
/*                                                                        */
/* 05/11/90  LSB  - Modified for enhanced portability to accomodate the   */
/*                  more modern "dirent" directory structure and related  */
/*                  family of directory access routines.                  */
/*                  Presently only good for those dirent-style systems    */
/*                  which support a vestigal sys/dir.h file and a         */
/*                  struct dirent which is named "direct" for backwards   */
/*                  compatibility.                                        */
/*                                                                        */
/*                                                                        */
/**************************************************************************/
char *myncheck(inode,dirname)
int inode;
char *dirname;
{
/* uncomment the following if not elsewhere included */
/* #include <stdio.h> */

/* uncomment the following if not elsewhere included */
/* #include <sys/types.h> */

/* uncomment the following if not elsewhere included */
/* #include <sys/dir.h> */


  int ret_val = 1;

#ifdef MODERN_DIRS
/* uncomment the following if not elsewhere included */
/* #include <strings.h> */

  DIR *file1;
  struct direct *dp;
  char dir_name[MAXNAMLEN+1];
#else
/* uncomment the following if not elsewhere included */
/* #include <string.h> */
/* uncomment the following if not elsewhere included */
/* #include <fcntl.h> */
  FILE *file1;
  struct direct dir1;
#endif



#ifdef MODERN_DIRS

        file1 = opendir(dirname);

        while((dp = readdir(file1)) != NULL )
        {
          if((int)dp->d_ino == inode)
          {
            strcpy(&dir_name[0], dp->d_name);
	    closedir(file1);
            return((char *) &dir_name[0]);
          }
        }
        closedir(file1);
        
#else
        file1 = fopen(dirname,"r");

        while(ret_val > 0)
        {
          ret_val = fread(&dir1,sizeof(struct direct),1,file1);
          if((int)dir1.d_ino == inode)
          {
	    fclose(file1);
            return((char *) &dir1.d_name[0]);
          }
        }
        fclose(file1);
#endif

        /* we didn't find it */
        return((char *) 0);
}
