/****************************************************************************/
/*                                                                          */
/* 1988, SOWSEAR ENGINEERING, SOFTWARE GROUP    Indianapolis, IN            */
/*                                                                          */
/*               our motto: "Who says you can't...?"                        */
/*                                                                          */
/****************************************************************************/
/* ISPIN.H                                                                  */
/*                                                                          */
/* common.h is the header file which is shared by ISPIN, IQUEUER, and IQ.   */
/*                                                                          */
/* Any defines, includes, or variables which may be peculiar to a           */
/* particular program is in ispin.h, iqueuer.h, or iq.h, resectively.       */
/*                                                                          */
/* ISPIN                                                                    */
/*                                                                          */
/* Indianapolis Standard Printer Interface (for Network printers)           */
/****************************************************************************/
/*                                                                          */
/* COMMENTS                                                                 */
/*                                                                          */
/* Read comments in common.h for the BIG PICTURE.                           */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* DEFINES                                                                  */
/*                                                                          */
/* Refer to common.h                                                        */
/*                                                                          */
/* number of seconds to wait before looping on network re-try               */
#define NETSLEEP 30
/*                                                                          */
/* maximum number of attempts at network negotiation                        */
#define MAXNET_TRY 10000
/*                                                                          */
/* number of seconds to wait between bursts of chars sent out to printer    */
#define BURSTWAIT 0
/*                                                                          */
/* number of seconds to allow for any write operation, such as bursts of    */
/* chars sent to printer. Setting the alarm clock for WRITEWAIT seconds     */
/* makes sure we won't wait forever when/if output is blocked.              */
/* If you modify this constant, make sure you leave enough time for the     */
/* user to change the ribbon, clear the paper jam, or replenish the paper   */
/* supply.                                                                  */
#define WRITEWAIT 300
/*                                                                          */
/* number of seconds to allow for the write_net() function to send          */
/* (usually) single chars during negotiate() and quit_net().                */
/* We used to wait WRITEWAIT seconds in write_net(), but that was too long. */
/* 07/26/90    LSB                                                          */
#define NETWAIT 5
/*                                                                          */
/* Number of characters sent as a burst. Sized for our X.25 packet size     */
/* optimization. UNIX cblocks are 64 bytes, of which there are four, so     */
/* keep the BURSTSIZ below 256, so we never overflow the output buffer.     */
#define BURSTSIZ 128
/*                                                                          */
/*                                                                          */
/*                                                                          */
#define NULLCHARPTR (char *) 0
/*                                                                          */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* INCLUDES                                                                 */
/*                                                                          */
/* Refer to common.h                                                        */
/*                                                                          */
/*                                                                          */
/*                                                                          */
/*                                                                          */
/* Same for everybody.                                                      */
#include <termio.h>
#include <sys/utsname.h>
/*                                                                          */
/*                                                                          */
/****************************************************************************/
/* DATA TYPES, VARIABLES, ETC                                               */
/*                                                                          */
/* Refer to common.h                                                        */
/*                                                                          */
/*                                                                          */
/*                                                                          */
FILE *fdopen(),
     *i_stream,   /* the input file stream            */
     *rtab;       /* the file stream for the external table of connect info */

char line_buf[BUFSIZ];          /* a place to put connect info */

char in_buf[BUFSIZ];            /* read into in_buf from out_file */

char *cpnd_send, *cpnd_expt;  /* pointers for compound EXPECT-SEND-EXPECT */
char *expt1, *c_send, *expt2; /* pointers to storage for EXPECT-SEND-EXPECT */



struct termio T;        /* defined in termio.h */
struct termio Tsav;        /* defined in termio.h */
struct termio T_COOK;
struct termio T_RAW;

/****************************************************************************/
/*                                                                          */
/*                                                                          */
/* vars and structs for common resolution of invocation flags and args      */

  /* a couple just for the NQ crowd */

  int   no_input = 0;     /* indicates no input file was passed */
  char  *sptime;          /* time that file was spooled */

  /* two just for the LP crowd */

  char *lp_id;             /* request id from lp */
  int numfiles;            /* howmany files are we asked to print ? */
  int num_ofile;            /* howmany files are we asked to print ? */

  /* the rest are same for either */

  int   banner = 0;       /* indicates a banner should be printed */
  int   prtimes = 1;      /* number of times to print the file(s) */

  char  *from;            /* the user making the request */
  char  *title;           /* title requested */
  char  *dest;            /* destination string (printer name) */
  char  *usr_strng;       /* string specified on the lp or nq command line */

  /**************************************************************/
  /* file descriptors and streams */
  /* dqueuer will only pass one file name, while */
  /* lp will pass additional args for add'l files */

#ifdef NQ
  char *fyle;   /* in the NQ case, this points merely to the base filename */
#else
  char **fyles;
#endif

  int out_file;/* file descriptor of output file     */
                          /* necessary as argument to ioctl calls */
/*                                                                          */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*                                                                          */
/*                                                                          */
/* variables and structures for data gathered from read of rtab             */


    

    /* speed */
    int speed;

    /* a linked list for network "busy" strings */ 
    struct busy_list
        {
          char *busy_strg;                        /* NULL terminated */
          struct busy_list *next;                 /* pointer to next one */
                                                  /* last has value NULL */
        };
    struct busy_list *busy_head;/* head of the list of "busy" strings         */
    struct busy_list *busy_curr;/* current member of list of "busy" strings   */
    struct busy_list *busy_list;/* movable pointer for list of "busy" strings */


    /* a linked list for network "inactive" strings */ 
    struct dead_list
        {
          char *dead_strg;                        /* NULL terminated */
          struct dead_list *next;                 /* pointer to next one */
                                                  /* last has value NULL */
        };
    struct dead_list *dead_head;/* head of the list of "dead" strings         */
                                /* any other Dead Heads out there ?     LSB   */
    struct dead_list *dead_curr;/* current member of list of "dead" strings   */
    struct dead_list *dead_list;/* movable pointer for list of "dead" strings */

    /* a linked list for network "quit" strings */ 
    struct quit_list
        {
          char *quit_strg;                        /* NULL terminated */
          struct quit_list *next;                 /* pointer to next one */
                                                  /* last has value NULL */
        };
    struct quit_list *quit_head;/* head of the list of "quit" strings         */
    struct quit_list *quit_curr;/* current member of list of "quit" strings   */
    struct quit_list *quit_list;/* movable pointer for list of "quit" strings */


    /* a linked list for network "disconnect" strings */ 
    struct disc_list
        {
          char *disc_strg;                        /* NULL terminated */
          struct disc_list *next;                 /* pointer to next one */
                                                  /* last has value NULL */
        };
    struct disc_list *disc_head;/* head of the list of "disc" strings         */
    struct disc_list *disc_curr;/* current member of list of "disc" strings   */
    struct disc_list *disc_list;/* movable pointer for list of "disc" strings */


    /* a linked list for network "expect" strings */ 
    struct expt_list
        {
          char *expt_strg;                        /* NULL terminated */
          struct expt_list *prev;                 /* pointer to prev one */
                                                  /* first has value NULL */
          struct expt_list *next;                 /* pointer to next one */
                                                  /* last has value NULL */
        };
    struct expt_list *expt_head;/* head of the list of "expt" strings         */
    struct expt_list *expt_curr;/* current member of list of "expt" strings   */
    struct expt_list *expt_list;/* movable pointer for list of "expt" strings */

    /* a linked list for network "send" strings */ 
    struct send_list
        {
          char *send_strg;                        /* NULL terminated */
          struct send_list *prev;                 /* pointer to prev one */
                                                  /* first has value NULL */
          struct send_list *next;                 /* pointer to next one */
                                                  /* last has value NULL */
        };
    struct send_list *send_head;/* head of the list of "send" strings         */
    struct send_list *send_curr;/* current member of list of "send" strings   */
    struct send_list *send_list;/* movable pointer for list of "send" strings */


/****************************************************************************/
/*                                                                          */
/*                                                                          */
/* some general purpose stuff                                               */
/*                                                                          */

/* for supporting setjmp and longjmp */
#ifdef NQ
#include <setret.h>
#define SETJMP(p) setret(p)
#define LONGJMP(s,n) longret(s,n)
ret_buf agayn, kwit;
#else
#include <setjmp.h>
#define SETJMP(p) setjmp(p)
#define LONGJMP(s,n) longjmp(s,n)
jmp_buf agayn, kwit;
#endif

char outFIFO[80];
char inFIFO[80];

#ifdef NQ
char *strtok();
char *strchr();
char *strrchr();
#endif

int outfifo,infifo;
int outropn,inropn,inwopn;
int check_char, keep_char;
int port_open = 0;
int quit_once = 0;
int savd_errno = 0;

int flgs_delay;
int flgs_ndelay;

struct stat *stat_buf;


struct utsname sysnam;


int    netloop;             /* counter for num of loops on network busy  */
int    status;              /* variable for return status of subroutines */
int    logging = 0;         /* flag to determine if event logging is on  */
int    raw = 0;             /* flag to determine if RAW output is desired*/
int    tab_expand = 0;      /* flag to determine if tab expansion desired*/
int    usr_addr = 0;        /* flag to determine if user-specified addr  */
int    stayt;               /* variable for current state of execution */


/* THE output device chosen by IQUEUER, NULL terminated */
char GO_dev[80];

/* the control terminal, chosen by ISPIN, NULL terminated */
/* string */
char ctrl_tty[80];
/* file descriptor */
int ctrltty;


/* DEFINES required by regexp(5), used in matcher()                   */
#define INIT            register char *sp = instring;
#define GETC()          (*sp++)
#define PEEKC()         (*sp)
#define UNGETC(c)       (--sp)
#define RETURN(c)       return;
#define ERROR(c)        {\
                         time(&tloc);\
                         nowtime = (struct tm *)localtime(&tloc);\
                         time_str = asctime(nowtime);\
                         sprintf(errmsg,"ISPIN: REGEXP ERROR: %d. time:\n",c);\
                         strcat(errmsg,"                            ");\
                         strcat(errmsg,time_str);\
                         strcat(errmsg,"\n");\
                         my_error(SYSERR);\
                        }

/* INCLUDE required by regexp(5), used in matcher()   */
#include <regexp.h>
/*                                                                            */
/*                                                                            */
/******************************************************************************/
