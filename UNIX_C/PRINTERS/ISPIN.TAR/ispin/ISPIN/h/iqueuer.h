/****************************************************************************/
/*                                                                          */
/* 1988, SOWSEAR ENGINEERING, SOFTWARE GROUP    Indianapolis, IN            */
/*                                                                          */
/*               our motto: "Who says you can't...?"                        */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* IQUEUER.H                                                                */
/*                                                                          */
/* common.h is the header file which is shared by ISPIN, IQUEUER, and IQ.   */
/*                                                                          */
/* Any defines, includes, or variables which may be peculiar to a           */
/* particular program is in ispin.h, iqueuer.h, or iq.h, resectively.       */
/*                                                                          */
/*                                                                          */
/* IQUEUER - the secondary queueing daemon for:                             */
/*                                                                          */
/* ISPIN                                                                    */
/*                                                                          */
/* Indianapolis Standard Printer Interface (for Network printers)           */
/****************************************************************************/
/*                                                                          */
/* COMMENTS                                                                 */
/*                                                                          */
/* Read comments in common.h for the BIG PICTURE.                           */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* DEFINES                                                                  */
/*                                                                          */
/* Refer to common.h                                                        */
/*                                                                          */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* INCLUDES                                                                 */
/*                                                                          */
/* Refer to common.h                                                        */
/*                                                                          */
#include "../h/common.h"
#include <sys/dir.h>
/*                                                                          */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* DATA TYPES, VARIABLES, ETC                                               */
/*                                                                          */
/* Refer to common.h                                                        */
/*                                                                          */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* MODIFICATIONS                                                            */
/*                                                                          */
/* Kevin Fannin 10/13/89 - Modified the wait_que structure drastically.     */
/*                         Eliminated the job structure. See modification   */
/*                         comments in IQUEUER.c for details.               */
/*                                                                          */
/*                                                                          */
/****************************************************************************/

/* a struct to receive incoming messages                                    */

  struct to_iqueuer incoming;

/* a struct to build out-going messages to the ISPIN                        */

  struct to_ispin out_msg;

/* a struct to build out-going messages to the status inquirer              */

  struct to_iq
  {
    union chr_lng typ;                  /* the current state */
    union chr_lng devinod;              /* the dev's inode number    */
    union chr_lng my_fifo;              /* so iq can figure printer's name */
    union chr_lng pid;                  /* pid of the print job */
    union chr_lng time_in;              /* when IQUEUER rec'd the request */
    union chr_lng time_out;             /* when IQUEUER rec'd last status  */
                                           /* report from the ISPIN process */
    union chr_lng uid;                  /* uid of user requesting print job */
    union chr_lng loop;                 /* if looping (BUSY), what iteration? */
  } to_IQ;

int to_iq_siz;
to_iq_siz = sizeof(struct to_iq);

/* Hold onto pid of last previous IQ (status inquiry). A tool to prevent    */
/* interleaved reads of the status FIFO. See write_status().                */

int iq_pid;

/* structures for linked lists (queues)                                     */

/* the list of waiting requests                                             */

  struct wait_queue
  {
    struct to_iqueuer job_id;   /* the info ISPIN gave in request for service */
    int    devinod[11];         /* the possible devices for this job */
    long   time_in;             /* when did we receive this request?       */
    struct wait_queue *next;    /* the next job in this list               */
    struct wait_queue *prev;    /* points backwards in the list            */
  };
  struct wait_queue *head_wait;
  struct wait_queue *curr_wait;
  struct wait_queue *list_wait;
  struct wait_queue *hold_wait;


/* the list of jobs running right now                                       */

  struct go_list
  {
    int devinod;                /* the inode number for the tty     */
    struct to_iqueuer job_id;   /* the info ISPIN gave in request for service */
    long   time_in;             /* when did we receive this request?       */
    long   time_out;            /* when was status last updated?           */
    struct go_list *next;       /* the next job in the list                */
    struct go_list *prev;       /* points backwards in the list            */
  };
  struct go_list *head_dsptch;
  struct go_list *curr_dsptch;
  struct go_list *list_dsptch;
  struct go_list *hold_dsptch;

  char inFIFO[160];
  char statFIFO[160];
  char outFIFO[160];
  char build_cmd[240];
  char lil_buf[BUFSIZ];

  int outfifo,infifo,statfifo;
  int outropn,inropn,inwopn,statropn,statdump;

  struct stat *stat_buf;

  int d, e;
  long oldtime;


  char tty_lock[100];
  int oumask;

#ifndef LCK_DIR
#define LCK_DIR "/usr/spool/uucp/"
#endif

  char *myncheck();
