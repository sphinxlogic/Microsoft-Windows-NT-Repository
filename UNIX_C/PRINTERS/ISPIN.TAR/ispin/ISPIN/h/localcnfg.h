/****************************************************************************/
/*                                                                          */
/* 1988, SOWSEAR ENGINEERING, SOFTWARE GROUP    Indianapolis, IN            */
/*                                                                          */
/*               our motto: "Who says you can't...?"                        */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* LOCALCNFG.H                                                              */
/*                                                                          */
/* localcnfg.h is a header file which is shared by ISPIN, IQUEUER, and IQ.  */
/*                                                                          */
/* The items and constants described in this header file are those which    */
/* are likely to be adjusted at install time to suit local needs and        */
/* preferences.                                                             */
/*                                                                          */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* COMMENTS                                                                 */
/*                                                                          */
/* read common.h for the BIG PICTURE                                        */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* DEFINES                                                                  */
/*                                                                          */
/*                                                                          */
/* SITELINE is the opportunity for you to tailor the banner page to reflect */
/* the name of your site.                                                   */
/* Please only modify what is between the first and last asterisk.          */
/* Leave it just this width, so it matches the rest of the banner.          */
/*                                                                          */
#define SITELINE "* *****        INDIANAPOLIS DISTRICT OFFICE        ***** *\n"
/*                                                                          */
/*                                                                          */
/*                                                                          */
/* These path-specific #defined variables seemed to me like logical places  */
/* to put things. If you don't agree, change 'em!                           */
/*                                                                          */
/* If you do change the locations, adjust your applicable install script    */
/* accordingly.                                                             */
/*                                                                          */
/* The file where we'll write event msgs and error msgs.                    */
#ifdef NQ
#define LOGFILE "/usr/spool/queuer/ISPIN/log"
#else
#define LOGFILE "/usr/spool/lp/ISPIN/log"
#endif
/*                                                                          */
/*                                                                          */
/* Directory location FIFOs. Again, the location is merely a suggestion.    */
#ifdef NQ
#define FIFOdir "/usr/spool/queuer/ISPIN/FIFO/"
#else
#define FIFOdir "/usr/spool/lp/ISPIN/FIFO/"
#endif
/*                                                                          */
/*                                                                          */
/* Name of ISPIN's table of remote printer information. Again, the location */
/* is merely a suggestion.                                                  */
#ifdef NQ
#define RTAB "/usr/spool/queuer/ISPIN/rtab"
#else
#define RTAB "/usr/spool/lp/ISPIN/rtab"
#endif
/*                                                                          */
/*                                                                          */
/* Location of the ISPIN executable. This constant is used by the small     */
/* executable which serves as the "interface" in the LP situation, thereby  */
/* requiring only one centrally located copy of the ISPIN executable.       */
/* INTRFCE execs the ISPIN. This saves considerable disk space, as opposed  */
/* to having a complete, separate ISPIN as the interface for each queue     */
/* member.                                                                  */
#define INTRFCE "/usr/spool/lp/ISPIN/ispin"
/*                                                                          */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* INCLUDES                                                                 */
/*                                                                          */
/* Refer to common.h                                                        */
/*                                                                          */
/*                                                                          */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* DATA TYPES, VARIABLES, ETC                                               */
/*                                                                          */
/* Refer to common.h                                                        */
/*                                                                          */
/*                                                                          */
/*                                                                          */
/****************************************************************************/
