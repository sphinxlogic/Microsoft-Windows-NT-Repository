/****************************************************************************/
/*                                                                          */
/* 1988, SOWSEAR ENGINEERING, SOFTWARE GROUP    Indianapolis, IN            */
/*                                                                          */
/*               our motto: "Who says you can't...?"                        */
/*                                                                          */
/****************************************************************************/
/* COMMON.H                                                                 */
/*                                                                          */
/* This is the header file which is shared by ISPIN, IQUEUER, and IQ.       */
/* Any defines, includes, or variables which may be peculiar to a           */
/* particular program is in ispin.h, iqueuer.h, or iq.h, resectively.       */
/*                                                                          */
/* ISPIN                                                                    */
/*                                                                          */
/* Indianapolis Standard Printer Interface (for Network printers)           */
/****************************************************************************/
/*                                                                          */
/* COMMENTS                                                                 */
/*                                                                          */
/* This program services printers which are not directly connected to       */
/* the cpu, but which are accessible from the cpu via network facilities.   */
/* ISPIN is conditionally compiled to support either one of two spooler/    */
/* queuer environments. ISPIN is able to provide this service by capital-   */
/* -izing upon the spooler/queuer facilities which are native to the        */
/* system. Each of these native spooler/queuers was designed to permit the  */
/* user (System Administrator and/or system programmer) the ability to      */
/* create and implement customized programs ("backend" for NQ, "interface"  */
/* for LP) such as this. Check the documentation. It's all there.           */
/* It's no big deal.                                                        */
/*                                                                          */
/* NQ is for the older, System III Zilogs of which IRS had approximately    */
/* 500 in service. These machines run under Zilog's ZEUS 3.21 UNIX. The     */
/* spooler/queuer is comprised of the family nq(1), xq(1), dqueuer(M).      */
/* In this environment, ISPIN will function as the "backend" program, so    */
/* must be so specified in the /usr/spool/queuer/config file.               */
/*                                                                          */
/* LP is for the System V UNIX spooler, as implemented by AT&T and those    */
/* which are similarly implemented. In this environment, ISPIN will         */
/* function as the "interface" program.                                     */
/*                                                                          */
/* EXTERNAL ENTITIES                                                        */
/*                                                                          */
/* In addition to the native queueing system and its utilities, ISPIN       */
/* depends on the existence and functionality of four entities which        */
/* are external to ISPIN but which exist solely to support ISPIN.           */
/*                                                                          */
/*   RTAB - The first such entity is an ascii file which is a table of data */
/* which is required to contact the remote printer. Each remote printer     */
/* which is supported will have an entry in this table. The construction    */
/* and usage of this table is roughly analogous to uucp's L.sys file (or    */
/* the Systems file under HoneyDanBer uucp). See further comments in the    */
/* quoted-out comments of the rtab file supplied with this release.         */
/*                                                                          */
/*   IQUEUER - The second of the external entities is the daemon IQUEUER.   */
/* The sole function of IQUEUER is to manage a fair FIFO competition        */
/* among multiple simultaneous invocations of ISPIN which may compete with  */
/* each other for access to a cpu port. IQUEUER has no control over the     */
/* life or death of the process ISPIN. Such control remains the exclusive   */
/* domain of the native queuer.                                             */
/*   This method (a secondary queuer) was chosen over the relatively        */
/* arcane method of using LOCKFILEs for several reasons. LOCKFILE-controlled*/
/* resource management naturally results in randomly sequenced servicing    */
/* of those processes which are competing for resources. Under a LOCKFILE   */
/* regime, there is no queueing. Race conditions and/or wasteful looping    */
/* and checking determine access sequence. Also, LOCKFILEs may be aban-     */
/* doned by dead processes (dead because they bombed, or were killed, or    */
/* because the system crashed). Abandoned LOCKFILEs generally require the   */
/* intervention of the Systems Administrator, who must expunge them in      */
/* order to return the system to functionality.                             */
/*                                                                          */
/*   PIPES - ISPIN and IQUEUER communicate via named pipes. This communi-   */
/* cation method is more robust than SIGNAL communication while being       */
/* more efficient than communication which relies upon intermediate         */
/* status files. The "blocking read" permitted under this approach allows   */
/* ISPIN and IQUEUER to merely sleep while waiting for work orders, as      */
/* opposed to wasteful looping and checking of an intermediate status file  */
/* to see whether there is work to be done.                                 */
/*                                                                          */
/*   IQ - the status enquirer. This program is a command to be executed by  */
/* those users who wish to know the current status of requests which have   */
/* been released by the native queuer but are now being monitored and/or    */
/* queued by IQUEUER. All such jobs will be shown as "running" or "now      */
/* printing" by the native queuer, since (as far as the native queuer knows)*/
/* once the backend (NQ) or interface (LP) program has been invoked, the    */
/* request is being satisfied. IQ exercises no control whatsoever over the  */
/* IQUEUER, the ISPIN, or the native queuer. Again, all control over the    */
/* backend/interface (ISPIN) is retained by the native queuer and its       */
/* utilities.                                                               */
/*                                                                          */
/*                                                                          */
/* CHOICES                                                                  */
/*                                                                          */
/* We have chosen not to support certain "features" of the NQ/DQUEUER       */
/* environment. These include, reporting print job progress to the status   */
/* file (STATUSFD), and ignoring the restart and backup commands of the     */
/* xq command. We have many good reasons for this, but system performance   */
/* and robustness of the backend are paramount.                             */
/*                                                                          */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* DEFINES                                                                  */
/*                                                                          */
/* Which spooler are we compiling for?                                      */
/* Define one or the other, never both.                                     */
/*                                                                          */
/* If we want to compile for NQ, we'll define it in the compile line.       */
/*                                                                          */
/* #define NQ                                                               */
/* or #define LP                                                            */
#ifndef NQ
#define LP
#endif
/*                                                                          */
/*  NQ is for the older System III Zilogs, which use nq, xq, and dqueuer.   */
/*  LP is for System V lp spoolers.                                         */
/*                                                                          */
/*                                                                          */
/*                                                                          */
/*                                                                          */
/*                                                                          */
/*                                                                          */
#define SUCCESS 0
/*                                                                          */
/* Flags for use with notify() function                                     */
#define HERE 1
#define WORKING 2
#define DONE 3
#define TROUBLE 4
#define WAIT 5
#define GO 6
#define BUSY 7
#define STATUS 8
/* status, or current state of the ISPIN                                    */
#define STARTUP 22
#define CONNECTING 33
#define PRINTING 44
#define LOOPING 55
#define WAITING 66
#define DISCONNECTING 77
#define QUITTING 88
#define NET_TIME 90
#define TIMEOUT 99
/* error types for use with my_error() function                             */
/* keep these less than 127, or lpsched will have a fit!                    */
#define NO_EXIT 115
#define NONOTIFY 116
#define MYERR 117
#define SYSERR 118
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* INCLUDES                                                                 */
/*                                                                          */
/*                                                                          */
/*                                                                          */
/* Same for everybody.                                                      */
#include <stdio.h>
#include <ctype.h>
#include <time.h>
#include <fcntl.h>
#include <errno.h>
#include <pwd.h>
#include <sys/types.h>
#include <sys/stat.h>
/*                                                                          */
/*                                                                          */
/* Some conditional includes, assuming Zeus 3.21 for NQ                     */
/* and System V UNIX for LP.                                                */
/*                                                                          */
#ifdef NQ
#include <ssignal.h>
#include "../h/nqspool.h"
#else
#include <signal.h>
#include <string.h>
#include <malloc.h>
#endif
/*                                                                          */
/* Allow for local configuration adjustments                                */
/*                                                                          */
#include "../h/localcnfg.h"
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* DATA TYPES, VARIABLES, ETC                                               */
/*                                                                          */
/*                                                                          */
FILE *fopen(),
     *logfile;    /* the error file stream            */


/* a union used to treat integers as arrays of characters                   */
union chr_int
{
  char chr[sizeof(int)];
  int  intgr;
};

int intsize;
intsize = sizeof(int);

/* a union used to treat longs as arrays of characters                      */
union chr_lng
{
  char chr[sizeof(long)];
  long lng;
};

int longsize;
longsize = sizeof(long);

/* for use with reads: how many characters did we get?                      */
int chars_got;
/*                                                                          */

char errmsg[BUFSIZ];     /* a place to format an error msg */
char errmsg2[BUFSIZ];     /* a place to format an error msg */
char msg_buf[BUFSIZ];    /* a place to format msg between procs via FIFOs */

long tloc;
char *time_str;
char *asctime();
struct tm *localtime();
struct tm *nowtime;

struct passwd *getpwnam(), *getpwuid(), *pass;

extern char **environ;

extern int  errno;           /*\            */
#ifdef NQ
extern int  deverr;          /* \ see       */
#endif
extern int  sys_nerr;        /* / perror(3) */
extern char *sys_errlist[];  /*/            */

char *calloc();

/* the structures used for communication with IQUEUER  */

  struct to_iqueuer
  {
    union chr_int typ;              /* what kind of message is this? */
    union chr_int my_pid;           /* the pid of this process       */
    union chr_int my_fifo;          /* the inode number of my FIFO   */
    union chr_int dev1_inod;        /* the inode number of the primary device */
    union chr_int dev2_inod;        /* the inode number of secondary device */
    union chr_int dev3_inod;        /* the inode number of tertiary device */
    union chr_int dev4_inod;        /* the inode number of 4th device */
    union chr_int dev5_inod;        /* the inode number of 5th device */
    union chr_int dev6_inod;        /* the inode number of 6th device */
    union chr_int dev7_inod;        /* the inode number of 7th device */
    union chr_int dev8_inod;        /* the inode number of 8th device */
    union chr_int dev9_inod;        /* the inode number of 9th device */
    union chr_int dev10_inod;       /* the inode number of 10th device */
    union chr_int dev11_inod;       /* the inode number of 11th device */
                                    /* devX_inode == 0 if no Xth dev */
    union chr_int  uid;             /* uid of the requesting user                   */
    union chr_int loop;             /* counter for number of BUSY loops             */
                                    /* Make sure we can go evenly into 512.  */
  } req_msg;

int to_iqrsiz;
to_iqrsiz = sizeof(struct to_iqueuer);

  struct to_ispin
  {
    union chr_int orders;           /* wait or go?                   */
    union chr_int iq_pid;           /* the pid of the daemon         */
    union chr_int dev_use_ino;      /* the inode number of the device to use */
    union chr_int pad1;             /* Padding, FIFO either has enough room, */
                                    /* or is full.                           */
                                    /* Make sure we can go evenly into 512.  */
  } cmd_msg;

int to_ispinsiz;
to_ispinsiz = sizeof(struct to_ispin);

  struct dev_info
  {
    int inode;                      /* the inode number of the device */
    char name[80];                  /* the name of the device         */
    int so_many;                    /* how many requests for this dev */
   } devinfo;

  /* we'll handle up to eleven potential devices */
  /* used by both IQUEUER and ISPIN              */
  struct dev_info dev_ray[11];

/* counters for use when moving chars to/from the FIFO read/write buffer      */
int count1, count2;
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*                                                                            */
int    time_out = 0;        /* variable for knowing whether we timed out */
int    ret_val  = 0;        /* variable for return values of functions   */
int    my_error();
