#!/bin/sh
# split_it.sh - called by make when command "make clean" is executed

if [ -f ../src/IQUEUER.c ]
then
	cd ../src
	/usr/bin/split IQUEUER.c IQUEUER.c.
	/bin/rm IQUEUER.c
	cd ../install
fi

if [ -f ../src/ISPIN.c ]
then
	cd ../src
	/usr/bin/split ISPIN.c ISPIN.c.
	/bin/rm ISPIN.c
	cd ../install
fi
