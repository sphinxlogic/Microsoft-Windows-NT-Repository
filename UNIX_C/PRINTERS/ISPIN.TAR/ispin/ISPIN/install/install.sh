#!/bin/sh
# install.sh - called by make when command "make install" is executed

spooler=$1
if [ $spooler != "ZILOGNQ" ] && [ $spooler != "ZILOGLP" ] && [ $spooler != "DYNIX" ] && [ $spooler != "LP" ] && [ $spooler != "CCI" ] && [ $spooler != "3B1" ] && [ $spooler != "UNISYS" ]
then
  echo " ERROR : install.sh must be called with an argument specifying spooler"
  echo "         (i.e. install.sh ZILOGLP) "
  exit 1
fi

if [ $spooler = "ZILOGNQ" ]
then
  dirname="queuer"
else
  dirname="lp"
fi

if [ ! -d /usr/spool/$dirname/ISPIN ]
then
  echo "making new directories"
  echo "mkdir /usr/spool/$dirname/ISPIN"
  mkdir /usr/spool/$dirname/ISPIN
  chmod 777 /usr/spool/$dirname/ISPIN
fi

if [ ! -d /usr/spool/$dirname/ISPIN/FIFO ]
then
  echo "mkdir /usr/spool/$dirname/ISPIN/FIFO"
  mkdir /usr/spool/$dirname/ISPIN/FIFO
  chmod 777 /usr/spool/$dirname/ISPIN/FIFO
fi

if [ ! -r /usr/spool/$dirname/ISPIN/FIFO/IQUEUER ]
then
  echo "creating named pipes"
  echo "/etc/mknod /usr/spool/$dirname/ISPIN/FIFO/IQUEUER p"
  /etc/mknod /usr/spool/$dirname/ISPIN/FIFO/IQUEUER p
  chmod 666 /usr/spool/$dirname/ISPIN/FIFO/IQUEUER
fi

if [ ! -r /usr/spool/$dirname/ISPIN/FIFO/STATUS ]
then
  echo "/etc/mknod /usr/spool/$dirname/ISPIN/FIFO/STATUS p"
  /etc/mknod /usr/spool/$dirname/ISPIN/FIFO/STATUS p
  chmod 666 /usr/spool/$dirname/ISPIN/FIFO/STATUS
fi

if [ ! -f /usr/spool/$dirname/ISPIN/rtab ]
then
  echo "copy <<empty>> rtab to /usr/spool/$dirname/ISPIN directory"
  echo "cp rtab /usr/spool/$dirname/ISPIN"
  cp rtab /usr/spool/$dirname/ISPIN
  chmod 744 /usr/spool/$dirname/ISPIN/rtab
fi

echo "copy executable iqueuer to /usr/spool/$dirname/ISPIN directory"
echo "cp ../obj/iqueuer /usr/spool/$dirname/ISPIN"
cp ../obj/iqueuer /usr/spool/$dirname/ISPIN

echo "copy executable ispin to /usr/spool/$dirname/ISPIN directory"
echo "cp ../obj/ispin /usr/spool/$dirname/ISPIN"
cp ../obj/ispin /usr/spool/$dirname/ISPIN

if [ $spooler != "ZILOGNQ" ]
then
  echo "copy ispintrfce to /usr/spool/$dirname/ISPIN directory"
  echo "cp ../obj/ispintrfce /usr/spool/$dirname/ISPIN"
  cp ../obj/ispintrfce /usr/spool/$dirname/ISPIN
fi

echo "What's left?"
echo
echo "1. Copy iq to a directory to which your users have a path for"
echo "   execution ( such as, generally, /z/bin, or /usr/local/bin )."
echo "2. Make provision in your system start-up script(s) to invoke"
echo "   /usr/spool/$dirname/ISPIN/iqueuer (the daemon) every start-up"
echo "   Execute it now, just for the first start-up."
echo "3. Choose the tty(s) through which ISPIN will contact printer(s)"
echo "4. Connect tty(s) to network"
echo "5. Edit the /usr/spool/$dirname/ISPIN/rtab to add a line for"
echo "   connect info for each remote printer"
if [ $spooler =  "ZILOGNQ" ]
then
  echo "6. Add each remote printer as a member of the native queuer by"
  echo "   editing the /usr/spool/queuer/config file"
  echo "7. Force the dqueuer (native queueing daemon) to read the config file"
  echo "    by executing:     dqueuer -r"
  echo "   The dqueuer will thus re-read the config file and learn of the"
  echo "   new printer(s)."
else
  echo "6. Shut down lpsched by executing lpshut."
  echo "7. Add each remote printer as a member of the native queuer by"
  echo "   executing     lpadmin -pyour_printer_name -iispintrfce -v/dev/null"
  echo "8. Re-start the lp scheduler by executing lpsched."
  echo "9. Use the lp-family commands << enable >> and << accept >> to"
  echo "    bring each new printer on-line."
fi
