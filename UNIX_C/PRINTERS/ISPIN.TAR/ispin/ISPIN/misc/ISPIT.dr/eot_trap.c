#include <stdio.h>

main()
{
  int c;

  while ((c = getc(stdin)) != EOF)
  {
    if(c == 4)
    {
      exit(0);
    }

    putc(c,stdout);
  }
}
