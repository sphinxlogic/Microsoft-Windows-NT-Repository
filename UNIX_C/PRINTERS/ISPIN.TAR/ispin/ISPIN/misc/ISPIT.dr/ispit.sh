#!/bin/sh
# ispit.sh         080791    LSB
# written to run as the user ispit's default shell (last field in passwd entry)
# stty call is of "att" type, so must be run under att on dual universe boxes
echo "OUTPUT_FILE?"
read OF
echo "OK"
stty raw ixoff -echo hupcl brkint
echo "ISPIT START" >> ispit.log
date >> ispit.log
echo $OF >> ispit.log
./eot_trap > $OF
date >> ispit.log
stty sane
exit
