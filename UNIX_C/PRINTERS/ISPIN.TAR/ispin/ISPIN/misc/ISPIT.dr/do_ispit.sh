#!/bin/sh
# do_ispit.sh         08/07/91     LSB
# When you install this in an accessible path, call it "ispit". This will
# assure compatibility with possible future executables.
# requires three args:
# $1 is file to be xferred: could be a directory, could be more than one
#                           file if all enclosed in double quote
#
# $2 is destination file name (full path on remote system, or relative to
# ispit's home directory on the remote system)
#
# $3 is the lp queue member to use (for destination system)
#
# so:
#     ispit source_file destination_file destination_system_queue_member
#
# examples:
#
# send testfile to /tmp/testfile on queue indy6:
#     ispit testfile /tmp/testfile indy6
#
# send directory UUGETTY and all contents to /tmp/UUG.cp.Z.a on queue indy6:
#     ispit UUGETTY /tmp/UUG.cp.Z.a indy6
#
# send all files whose names contain "ind" to /tmp/ind.cp.Z.a on queue indy6:
#     ispit "`ls *ind*`" /tmp/ind.cp.Z.a indy6
#
# nowfile (not an argument) is the name of the named pipe in /tmp we'll use
#
#
nowfile=`/bin/date +%m%d%y`.`/bin/date +%H%M%S`
echo "ISPIT REQUEST" >> /tmp/ispit.log
date >> /tmp/ispit.log
echo "        user: "`id`  >> /tmp/ispit.log
echo "      source: "$1  >> /tmp/ispit.log
echo " destination: "$2  >> /tmp/ispit.log
echo "       queue: "$3  >> /tmp/ispit.log
echo "        pipe: /tmp/"$nowfile  >> /tmp/ispit.log
/bin/rm -f /tmp/$nowfile
/etc/mknod /tmp/$nowfile p
/bin/chmod 666 /tmp/$nowfile
find $1 ! -type p -print|/bin/cpio -oc|/usr/local/bin/compress|/usr/local/bin/btoa > /tmp/$nowfile &
/usr/bin/lp -d$3 -o$2@/tmp/$nowfile /etc/passwd
# Yes, I do mean /etc/passwd! It's here as a necessary argument to fool lp.
