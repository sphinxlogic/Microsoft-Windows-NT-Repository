#!/bin/sh
# lp_perms.sh     05/13/91    LSB     IRS Indianapolis
#
# This routine sets up a System V, release 2 lp subsystem to behave
# similar to a System V, release 3 lp subsystem with respect to file
# access. It all runs as setuid to superuser. Under this setup, it
# is CRITICALLY IMPORTANT to have an interface program which will
# setgid and setuid back to the user who requested the job, thus
# maintaining security. 
# After implementation of this routine and the setgid/setuid interface,
# users will be able to print any file which they themselves can read.
#
# This is the code fragment for ispin which does the trick:
#     #ifdef LP
#           /* If this process is running as setuid to root (uid == 0),
#              then setuid to the requesting user.      05/09/91  LSB   */
#           if(geteuid() == 0)
#           {
#             setgid(pass->pw_gid);
#             setuid(pass->pw_uid);
#           }
#     #endif
# ISPIN.rel_2.1/src/ISPIN.c can be patched with this code fragment after line
# 1269. All ISPIN releases after ISPIN.rel_2.1 will contain this code.
#
# NOTE: ISPIN.rel_2.2 HAS ALREADY BEEN PATCHED WITH THE ABOVE CODE FRAGMENT
#
# change lp's uid to 0
set UID
set LYNE
UID=`grep ^lp\: /etc/passwd|cut -d\: -f3`
LYNE=`grep -n lp\: /etc/passwd|cut -d\: -f1`
sed $LYNE\ s/\:$UID\:/\:0\:/g /etc/passwd > /tmp/passwd.TMP
cp /etc/passwd /tmp/passwd.sav
cp /tmp/passwd.TMP /etc/passwd
#
# lp administrative stuff, superuser only
chown lp /usr/lib/lpsched
chmod 700 /usr/lib/lpsched
chown lp /usr/lib/lpshut
chmod 700 /usr/lib/lpshut
chown lp /usr/lib/lpmove
chmod 700 /usr/lib/lpmove
chown lp /usr/lib/accept
chmod 700 /usr/lib/accept
chown lp /usr/lib/reject
chmod 700 /usr/lib/reject
#
# lp user stuff
chown lp /usr/bin/lp
chmod 4711 /usr/bin/lp
chown lp /usr/bin/lpstat
chmod 4711 /usr/bin/lpstat
chown lp /usr/bin/cancel
# The following lets any user cancel any job, same as before.
# If you don't like that, change 4711 to 700. Then only superuser can cancel.
# Same goes for enable and disable.
chmod 4711 /usr/bin/cancel
chown lp /usr/bin/enable
chmod 4711 /usr/bin/enable
chown lp /usr/bin/disable
chmod 4711 /usr/bin/disable
