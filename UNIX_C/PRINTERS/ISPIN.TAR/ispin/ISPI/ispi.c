/****************************************************************************/
/*                                                                          */
/*  ISPI                                                                    */
/*                                                                          */
/*  Indianapolis Standard Printer Interface                                 */
/*                                                                          */
/*  - generates printer selection menu from table, serves as front-end      */
/*    for System V lp/lpsched or Zilog System III nq/dqueuer spoolers.      */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  Copyright (C) 1991                                                      */
/*  Kent Meurer                                                             */
/*  Internal Revenue Service                                                */
/*  Indianapolis District Office                                            */
/*                                                                          */
/*  This program is free software; you can redistribute it and/or modify    */
/*  it under the terms of the GNU General Public License as published by    */
/*  the Free Software Foundation, version 1.                                */
/*                                                                          */
/*  This program is distributed in the hope that it will be useful,         */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of          */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           */
/*  GNU General Public License for more details.                            */
/*                                                                          */
/*  You should have received a copy of the GNU General Public License       */
/*  along with this program; if not, write to the Free Software             */
/*  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.               */
/*                                                                          */
/****************************************************************************/
/*

 *
  COMPILE
        Zilog System III Zeus Unix:         cc -o ispi ispi.c -s
        Zilog System V (Models 32 & 130):   cc -f -DSYSTEM_V -o ispi ispi.c -s
        Sequent System V Unix:              cc -DSEQUENT -o ispi ispi.c -s
        Other System V:                     cc -DSYSTEM_V -o ispi ispi.c -s

             *
              If Supporting ISPIN's external printing, include -DEXTERN
              in the above compile lines.

              If Supporting ISPI's file transfer capability, include -DXFER
              in the above compile lines. Also check value assigned to
              XFERCMD constant, below.

              If Supporting UUCP printing, (88.  Print to Another System),
              include -DUUCP in the above compile lines.

              Written by:             Kent Meurer   IRS, Indianapolis District
              modifications by:       Larry Bartz   IRS, Indianapolis District
              modifications by:       Kevin Fannin  IRS, Indianapolis District


                                                                              */

#include <stdio.h>
#include <sys/utsname.h>
#include <signal.h>
#include <pwd.h>

struct term_types
 {
   char term[8];
   char on[8];
   char off[8];
 };

static struct term_types terminals[] =  {
/* Use octal representations of unprintable chars for ON and OFF strings.     */
/* Terminate strings with \\c so echo does not send a newline. See echo(1).   */
/*        TERM    ON     OFF                                                  */
/*        ----    --     ---                                                  */
          {"v5", "\033*\\c", "\033?\\c"},    /* Visual 50/55/65               */
          {"v55", "\033*\\c", "\033?\\c"},   /* Visual 50/55/65               */
          {"v65", "\033*\\c", "\033?\\c"},   /* Visual 50/55/65               */
          {"d2", "\033[5i\\c", "\033[4i\\c"},/* TI/IBM PC's (VT100 Termcap)   */
          {"vt100", "\033[5i\\c", "\033[4i\\c"},  /*  PC's (VT100 Termcap)    */
          {"wy50", "\030\\c", "\024\\c"},      /* Wyse 50                       */
                                             /* add new terminal type(s) here */
          {"\0", "\0", "\0"}            };

#define MAX_PRINTERS  28
#define TERM_ENV      "TERM"
#define CONFIG_ENV    "CONFIGDIR"
#define TRUE          1
#define FALSE         0
#define FLAG(x)       (x == '-')
#define NUM(x)        ((x >= '0') && (x <= '9'))
#define WS(x)         ((x == ' ') || (x == '\t'))
#define NL(x)         ((x == '\n') || (x == '\r'))
#define NP(x)         (x == 014)
#define ASCII(x)      (((x >= 040) && (x <= 0176)) || \
                        (x == 010) || (x == 011) || (x == 012))

#ifdef  EXTERN
#  define EXTERN_QUEUE_NAME   "ext"
#endif

#ifdef SEQUENT
#  define SYSTEM_V
#  define CLEAR               "/usr/ucb/clear"
#  ifdef UUCP
#    define UUX               "ucb uux"
#    define UUNAME            "ucb uuname"
#  endif
#else
#  define CLEAR               "clear"
#  ifdef UUCP
#    define UUX               "uux"
#    define UUNAME            "uuname"
#  endif
#endif

#ifdef SYSTEM_V
#  define setjmpret(p)        setjmp(p)
#  define longjmpret(s, n)    longjmp(s, n)
#  define CONFIG_PATH         "/usr/spool/lp/ISPIN"
#  ifdef EXTERN
#    define RTAB_PATH         "/usr/spool/lp/ISPIN"
#  endif
#else
#  define setjmpret(p)        setret(p)
#  define longjmpret(s, n)    longret(s, n)
#  define CONFIG_PATH         "/usr/spool/queuer"
#  ifdef EXTERN
#    define RTAB_PATH         "/usr/spool/queuer/ISPIN"
#  endif
#endif

/* file xfer stuff 12/11/90 LSB */
#ifdef XFER

   /* command to be invoked to transfer the file to user's system */

#  define XFERCMD             "/usr/local/bin/kermit -is"

   /* An environmental variable will override the compiled-in value, */
   /* such as if certain (group of) user(s) would prefer to use [u,x,z]modem */
#  define XFER_ENV            "XFERCMD"
#endif


typedef int            ret_buf[10];
typedef unsigned int   index;
typedef unsigned short bool;

struct device
 {
   char q_name[15];
   char d_name[6];
   char comments[21];
 };

FILE              *fopen(), *config, *tty, *report;
unsigned short    exit_status = 0, num_printers;
int               num_choices, choice, c, copies = 1, fileargc, get_groupid(),
                  usergroupid, proc_id;
char              que_name[9], current_config[50], curr_system[10], printer[15],
                  clear_buff[256], file_buffer[BUFSIZ], prog_name[15], term[10],
                  *getenv(), *fileargv[100], *config_ptr, config_path[50];
#ifdef XFER
char              *xfer_ptr, xfer_cmd[50];
void              xfer_it();
#endif
struct term_types *t_ptr;
struct device     devices[MAX_PRINTERS+1], *d_ptr;
struct utsname    *sys_name, tmp_struct;
void              clear_scr(), ignore_line(), get_queue_descriptor(), view(), 
                  get_device_descriptor(), save_comments(), set_lps(), show(),
                  print_menu(), get_choice(), verify_choice(),
                  get_copies(), printjob(), delfunc(), sysdelfunc(), uname(),
                  check_group();
bool              no_choice_has_been_made = TRUE,
                  remote_printer = FALSE, lp = FALSE, clear_set = FALSE,
                  setcom = FALSE, banner = FALSE, copy = FALSE, mail = FALSE,
                  all_printers = FALSE;
ret_buf           print, sys;


#ifdef UUCP
  unsigned short  num_systems = 0;
  static char     systems[32][9];
  void            get_system();
  bool            systems_set = FALSE;
#endif

#ifdef EXTERN
  void            ignore_queue_name(), show_externs(), extdelfunc(),
                  load_externs();
  char            address[128];
  ret_buf         ext;
  bool            externs = FALSE;
#endif


main(argc, argv)
 int  argc;
 char *argv[];
 {
  index  n = 1;
  bool   q_came_first = FALSE, buffer_not_loaded = TRUE;

   if((tty = fopen((ttyname(0)),"w")) == NULL)
    {
      fprintf(stderr,"Not a tty\n");
      exit(5);
    }

   signal(SIGQUIT, SIG_IGN);
   signal(SIGINT, SIG_IGN);

   strcpy(prog_name, argv[0]);

   /* Added support for defining config file location via ENVIRONMENT */
   /* variable named CONFIGDIR.                                       */
   /* 08/07/90   LSB                                                  */
   config_ptr = getenv(CONFIG_ENV);
   if(config_ptr ==  (char *)0)
   {
     sprintf(current_config,"%s/config", CONFIG_PATH);
     sprintf(config_path,"%s", CONFIG_PATH);
   }
   else
   {
     sprintf(current_config,"%s/config", config_path);
     /* Include alternative to revert to compiled-in path */
     /* if the environmental variable is ill-defined.     */
     if((config = fopen(current_config,"r")) == NULL)
     {
       sprintf(current_config,"%s/config", CONFIG_PATH);
       sprintf(config_path,"%s", CONFIG_PATH);
     }
     else
     {
       fclose(config);
     }
   }


   if((config = fopen(current_config,"r")) == NULL)
    {
        fprintf(stderr, "%s: Print Request Aborted - Unable to open %s\n",
                         prog_name, current_config);
        exit(7);

    }


   /* Added support for defining file transfer command via ENVIRONMENT */
   /* variable named XFERCMD.                                          */
   /* 12/10/90   LSB                                                   */
#ifdef XFER
   xfer_ptr = getenv(XFER_ENV);
   if(xfer_ptr != (char *)0)
   {
     strcpy(xfer_cmd,xfer_ptr);
   }
   else
   {
     strcpy(xfer_cmd, XFERCMD);
   }
#endif


   usergroupid = get_groupid();

   sys_name = &tmp_struct;
   uname(sys_name);
   strcpy(curr_system,sys_name->nodename);


   while(FLAG(argv[n][0]))
    {
      switch(argv[n][1])
       {
         case 'a':
         case 'A':
                   all_printers = TRUE;
                   break;
         case 's':
                   setcom = TRUE;
                   break;
         case 'B':
                   banner = TRUE;
                   break;
         case 'm':
                   mail = TRUE;
                   break;
         case 'c':
                   copy = TRUE;
                   break;
         case 't':
                   copies = atoi(argv[n+1]);
                   if(copies < 1)
                    copies = 1;
                   n++;
                   break;
         case 'd':
         case 'p':           /* ignore these nq flags and their args */
                   n++;
                   break;
         default:            /* ignore other flags we don't support  */
                   break;
       }
      n++;
    }

   if((n == argc) && (! setcom))
    {
      fileargv[0] = &file_buffer[0];
      fileargc = 1;
      while(buffer_not_loaded)
       {
          n = 0;
          fprintf(tty,"\n\nEnter the name of the File(s) to be printed: ");
          fflush(tty);

          file_buffer[n] = getc(stdin);

          while(WS(file_buffer[n]))
            file_buffer[n] = getc(stdin);

          while((! NL(file_buffer[n])) && (n < BUFSIZ))
           {
             n++;
             file_buffer[n] = getc(stdin);
             while(! NL(file_buffer[n]) &&
                  (! WS(file_buffer[n])) && (n < BUFSIZ))
              {
                n++;
                file_buffer[n] = getc(stdin);
              }

             if(WS(file_buffer[n]))
              {
                file_buffer[n] = '\0';
                n++;
                file_buffer[n] = getc(stdin);
                while(WS(file_buffer[n]))
                  file_buffer[n] = getc(stdin);
                if(! NL(file_buffer[n]))
                 {
                   fileargv[fileargc] = &file_buffer[n];
                   fileargc++;
                 }
              }
             buffer_not_loaded = FALSE;
           }
          file_buffer[n] = '\0';
       }

      if(n >= BUFSIZ)
       {
         fprintf(stderr,"%s: File list too long\n", prog_name);
         exit(3);
       }
    }
   else
    {
      fileargc = 0;
      for(n; n < argc; n++, fileargc++)
        fileargv[fileargc] = argv[n];
    }


   while(no_choice_has_been_made)
    {
      setjmpret(print);
      signal(SIGINT, delfunc);
      num_printers = 0;
      d_ptr = devices;
      while(((c = getc(config)) == ' ') || (c == '\t'));
      lp = FALSE;

      while((c != EOF) && (num_printers < MAX_PRINTERS))
       {
         switch(c)
          {
            case '#':
              ignore_line();
              break;
            case 'Q':
              q_came_first = TRUE;
              get_queue_descriptor();
              break;
            case 'D':
              if(q_came_first)
               {
                 get_device_descriptor();
                 num_printers++;
               }
              else
               {
                 fprintf(stderr,
                   "Print Request Unsuccessful - %s: file garbled\n",
                   current_config);
                 exit(8);
               }
              break;
            case 'L':
            case 'l':
              if((((c = getc(config)) == 'P') || (c == 'p')) &&
                   (! q_came_first))
               {
                 lp = TRUE;
                 set_lps();
               }
              else
               {
                 fprintf(stderr,
                   "Print Request Unsuccessful - %s: file garbled\n",
                   current_config);
                 exit(8);
               }
              break;
            default:
              fprintf(stderr,
                "Print Request Unsuccessful - %s: file garbled\n",
                current_config);
              exit(8);
              break;
           }
          if(c != EOF)
            while(((c = getc(config)) == ' ') || (c == '\t'));
       }

     q_came_first = FALSE;
     fclose(config);
     /* KDF 11/29/90 Following caused last printer to be blank on lp systems */
     /*              when menu was full.                                     */
     /* d_ptr->d_name[0] = d_ptr->q_name[0] = d_ptr->comments[0] = NULL;     */
     print_menu();
     get_choice();
     if(! no_choice_has_been_made)
      {
        if(! remote_printer)
         {
           if(lp)
             strcpy(printer,devices[choice-1].q_name);
           else
             sprintf(printer,"%s:%s", devices[choice-1].q_name,
                     devices[choice-1].d_name);
         }
        verify_choice();
      }
    }

   printjob(fileargc, fileargv);
   fclose(tty);
   exit(exit_status);
 }


/* Function added to get group id.    KDF 11/28/90 */
int get_groupid()
 {
   struct passwd *pwentry, *getpwuid();

   pwentry = getpwuid(getuid());
   return(pwentry->pw_gid);
 }

void verify_choice()
 {
   signal(SIGINT, delfunc);

   clear_scr();
   fprintf(tty, "\n\n\n\n\n\n\n\n\n                You have selected ");

   if(remote_printer)
     fprintf(tty, "Slave Printing");
   else

#  ifdef EXTERN
   if(externs)
    {
       fprintf(tty, "%s - %s", printer, devices[choice-1].comments);
       fprintf(tty, 
               "\n                                  @ address %s", address);
    }
   else
#  endif

     fprintf(tty, "%s - %s", printer, devices[choice-1].comments);


   fprintf(tty, "\n\n                Is this correct (y/n) ? ");
   fflush(tty);

   while(((c = getc(stdin)) == ' ') || (c == '\t'));
   if(c != '\n')
     while((getc(stdin)) != '\n');

   if((c == 'Y') || (c == 'y'))
     return;

#  ifdef EXTERN
     externs = FALSE;
#  endif

   no_choice_has_been_made = TRUE;
   remote_printer  = FALSE;

   if((config = fopen(current_config,"r")) == NULL)
    {
      fprintf(stderr, "%s: Print Request Aborted - Unable to open %s\n",
                       prog_name, current_config);
      exit(7);
    }
 }



void clear_scr()
 {
  FILE *clr;
  char *cptr;

   if(! clear_set)
    {
      if((clr = popen(CLEAR, "r")) == NULL)
       {
         fprintf(stderr,"%s: bad status from system clear\n", prog_name);
         exit(6);
       }
      cptr = clear_buff;
      while(((c = getc(clr)) != EOF) && (cptr != &clear_buff[255]))
        *cptr++ = c;

      *cptr = '\0';

      clear_set = TRUE;
    }

   fprintf(tty, "%s", clear_buff);
 }



void ignore_line()
 {
   while(((c = getc(config)) != '\n') && (c != EOF));
 }



void get_queue_descriptor()
 {
  index n = 0;

   que_name[n] = getc(config);
   while((que_name[n] != ',') && (n < 9))
    {
      n++;
      que_name[n] = getc(config);
    }
   que_name[n] = '\0';
   ignore_line();

#  ifdef EXTERN
     if((strcmp(que_name, EXTERN_QUEUE_NAME)) == 0)
       ignore_queue_name();
#  endif
 }



#ifdef EXTERN

void ignore_queue_name()
 {
   while(((c = getc(config)) == ' ') || (c == '\t'));
   while((c != EOF) && (c != 'Q'))
    {
      ignore_line();
      while(((c = getc(config)) == ' ') || (c == '\t'));
    }
   ungetc(c,config);
 }

#endif



void get_device_descriptor()
 {
  index n = 0;

   strcpy(d_ptr->q_name,que_name);
   d_ptr->d_name[n] = getc(config);
   while((d_ptr->d_name[n] != ',') && (n < 6))
    {
      n++;
      d_ptr->d_name[n] = getc(config);
    }
   d_ptr->d_name[n] = '\0';

   ignore_line();
   save_comments();
   d_ptr++;
 }



void save_comments()
 {
  index n = 0;

   while(((c = getc(config)) == ' ') || (c == '\t'));
   if(c != '#')
    {
      while(n < 20)
        d_ptr->comments[n++] = ' ';
      d_ptr->comments[20] = '\0';
      ungetc(c,config);
      return;
    }

   while(((d_ptr->comments[n] = getc(config)) == ' ') ||
          (d_ptr->comments[n] == '\t'));
   while((d_ptr->comments[n] != '\n') && (n < 20))
    {
      n++;
      c = getc(config);
      if(c != EOF)
       {
         if(c != '\t')
          d_ptr->comments[n] = c;
         else
          d_ptr->comments[n] = ' ';
       }
      else
        break;
    }

   if((d_ptr->comments[n] != '\n') && (c != EOF))
     ignore_line();

   while(n < 20)
    d_ptr->comments[n++] = ' ';
   d_ptr->comments[n] = '\0';

   check_group(); /* Function to check optional printer group parameter */
 }


/* Code added to read optional printer GROUP comment line. KDF 11/28/90 */

void check_group()
 {
   int n, printergroup; 
   char holdnum[10];

   while(((c = getc(config)) == ' ') || (c == '\t'));
   if (c != '#')
    {
      ungetc(c,config);
      return;
    }

   while(((c = getc(config)) == ' ') || (c == '\t'));

   if ( (toupper(c)) != 'G' || (toupper(getc(config))) != 'R' || 
        (toupper(getc(config))) != 'O' || (toupper(getc(config))) != 'U' || 
        (toupper(getc(config))) != 'P' || 
        ((c = (getc(config))) != ' ' && c != '\t')  )
     {
       ungetc(c,config);
       ignore_line();
       return;
     }

   while(((c = getc(config)) == ' ') || (c == '\t'));

   if ((toupper(c)) == 'A') /* all groups specified */
    {
      ignore_line();
      return;
    }

  n = 0;
  while (c != '\n' && c != EOF)
    {
      if (c == ' ' || c == '\t')
        {
          holdnum[n] = '\0';
          printergroup = atoi(holdnum);
          if (printergroup == usergroupid)
            {
              ignore_line();
              return;
            }
          while(((c = getc(config)) == ' ') || (c == '\t'));
          n = 0;
        }
      else
        {
          holdnum[n] = c;
          n++;
          c = getc(config);
        }
    }

  if (n > 0)
    {
      holdnum[n] = '\0';
      printergroup = atoi(holdnum);
      if (printergroup == usergroupid)
        return;
    }

  /* if ispi called with -a flag, list all printers regardless of groups
     that are specified in config file */
  if (all_printers)
    return;

  /* if didn't find users group listed, then remove this printer from list */
  d_ptr--;
  num_printers--;

 }


void set_lps()
 {
  index n = 0;

   ignore_line();
   num_printers = 0;

   while((c != EOF) && (num_printers < MAX_PRINTERS))
    {
      d_ptr->d_name[0] = '\0';

      while((c = getc(config)) == '#')
        ignore_line();

      while((WS(c)) || (NL(c)))
        c = getc(config);

      while((! WS(c)) && (! NL(c)) && (c != EOF) && (n < 14))
       {
         d_ptr->q_name[n++] = c;
         c = getc(config);
       }
      if(n > 0)
        num_printers++;
      d_ptr->q_name[n++] = '\0';

      while((! NL(c)) && (c != EOF))
         c = getc(config);

      if(c == EOF)
        ungetc(c,config);
      save_comments();

      n = 0;
      if(num_printers < MAX_PRINTERS)
        d_ptr++;
     }
 }



void print_menu()
 {
  int   len;
  index n;
  char  fprinter[15], fprinter2[15];

   num_choices = 1;
   clear_scr();
   fprintf(tty,"\n                      ");
   fprintf(tty,"%s Printer Selection Menu\n", curr_system);
   fprintf(tty,"                      ");
   for(len = 0; len < strlen(curr_system); len++)
     fprintf(tty,"-");
   fprintf(tty," ------- --------- ----\n");
   if(num_printers < 19)
    fprintf(tty, "\n");


   if(num_printers < 10)
    {
      d_ptr = devices;
      /* Changed while statement KDF 11/29/90 */
      /* while(d_ptr->q_name[0] != NULL) */
      while(num_choices <= num_printers)
       {
        if(lp)
           fprintf(tty,"                     %2d.  %s  %s", num_choices,
                        d_ptr->comments, d_ptr->q_name);
        else
         {
           sprintf(fprinter, "%s:%s", d_ptr->q_name, d_ptr->d_name);
           fprintf(tty,"                     %2d.  %s  %s", num_choices,
                        d_ptr->comments, fprinter);
         }

        for(len=(strlen(d_ptr->q_name)+strlen(d_ptr->d_name)); len <= 14; len++)
          fprintf(tty," ");

        fprintf(tty,"\n");
        num_choices++;
        d_ptr++;
       }

    }
   else
    {
      num_choices = num_printers + 1;

      if((num_printers + 1) % 2)
       {
        for(n = 0; n < (num_printers/2); n++)
          if(lp)
            fprintf(tty,"%2d. %.20s %-14.14s %2d. %.20s %-14.14s\n", n+1,
                devices[n].comments, devices[n].q_name, n+((num_printers/2)+1),
                devices[n+(num_printers/2)].comments,
                devices[n+(num_printers/2)].q_name);
          else
           {
             sprintf(fprinter, "%s:%s", devices[n].q_name, devices[n].d_name);
             sprintf(fprinter2, "%s:%s", devices[n+(num_printers/2)].q_name,
                                      devices[n+(num_printers/2)].d_name);

             fprintf(tty,"%2d. %.20s %-15.14s%2d. %.20s %s\n",
                 n+1, devices[n].comments, fprinter, n+((num_printers/2)+1),
                 devices[n+(num_printers/2)].comments, fprinter2);
           }
       }
      else
       {
        for(n = 0; n < (num_printers/2); n++)
          if(lp)
             fprintf(tty,"%2d. %.20s %-14.14s %2d. %.20s %-14.14s\n",
                 n+1, devices[n].comments, devices[n].q_name,
                 n+((num_printers/2)+2), devices[n+(num_printers/2)+1].comments,
                 devices[n+(num_printers/2)+1].q_name);
          else
           {
              sprintf(fprinter, "%s:%s", devices[n].q_name, devices[n].d_name);
              sprintf(fprinter2, "%s:%s", devices[n+(num_printers/2)+1].q_name,
                                      devices[n+(num_printers/2)+1].d_name);
              fprintf(tty,"%2d. %.20s %-15.14s%2d. %.20s %s\n",
                  n+1, devices[n].comments, fprinter, n+((num_printers/2)+2),
                  devices[n+(num_printers/2)+1].comments, fprinter2);
           }

          if(lp)
              fprintf(tty,"%2d. %.20s %-14.14s\n",
                  n+1, devices[n].comments, devices[n].q_name);
          else
           {
              sprintf(fprinter, "%s:%s", devices[n].q_name, devices[n].d_name);
              fprintf(tty,"%2d. %.20s %-15.14s\n",
                  n+1, devices[n].comments, fprinter);
           }

       }
    }

   fprintf(tty,"\n");

   if((strcmp(curr_system,sys_name->nodename)) == 0)
    {
#     ifdef XFER
      if(! setcom)
        fprintf(tty,"                     33.  Download File\n");
#     endif
#     ifdef EXTERN
        fprintf(tty,"                     44.  External Printers\n");
#     endif
      fprintf(tty,"                     55.  Slave Printer\n");
    }
   if(! setcom)
      fprintf(tty,"                     66.  View File on Terminal\n");
   fprintf(tty,
         "                     77.  Change Number of Copies - Currently %d\n",
                    copies);
#  ifdef UUCP
      fprintf(tty,"                     88.  Print File on Another System\n");
#  endif
   fprintf(tty,"                     99.  Abort Without Printing\n");
   fprintf(tty,"\n");
   if(num_printers < 19)
      fprintf(tty,"\n");
   fflush(tty);
 }



void get_choice()
 {
  index n = 0;
  char  char_choice[20];

   while(1)
    {
      fprintf(tty,"                                 ");
      fprintf(tty,"Enter your choice: ");
      fflush(tty);

      while(((char_choice[n] = getc(stdin)) == ' ') ||
             (char_choice[n] == '\t'));

      if(! NL(char_choice[n]))
        n++;

      if NUM(char_choice[n-1])
       {
         char_choice[n] = getc(stdin);
         while((NUM(char_choice[n])) && (n < 19))
          {
            n++;
            char_choice[n] = getc(stdin);
          }
       }

      while(WS(char_choice[n]))
          char_choice[n] = getc(stdin);

      if(! NL(char_choice[n]))
       {
          while(((c = getc(stdin)) != '\n') && (c != '\r'));
          n = 0;
       }

      char_choice[n] = '\0';

      choice = atoi(char_choice);

      if((choice == 66) && (! setcom))
       {
         view(fileargc, fileargv);
         return;
       }
#ifdef XFER
      if((choice == 33) && (! setcom))
       {
         xfer_it(fileargc, fileargv);
         return;
       }
#endif
      else if(choice == 77)
       {
         get_copies();
         return;
       }
      else if(choice == 88)
       {
#        ifdef UUCP
           get_system();
           signal(SIGINT, delfunc);
           return;
#        else
           choice = 0;
#        endif
       }
      else if(choice == 99)
       {
         fprintf(tty,"\n                          Print Request Aborted\n");
         fclose(tty);
         if(setcom)
           fprintf(stdout,"abort");
         exit(1);
       }
      else if(choice == 44)
       {
#        ifdef EXTERN
           if((strcmp(curr_system,sys_name->nodename)) == 0)
            {
               show_externs();
               break;
            }
           else
             choice = 0;
#        else
           choice = 0;
#        endif
       }
      else if(choice == 55)
       {
         if((strcmp(curr_system,sys_name->nodename)) == 0)
          {
            strcpy(term,(getenv(TERM_ENV)));
            t_ptr = terminals;
            while(((strcmp(term,t_ptr->term)) != 0) && (t_ptr->term[0] != '\0'))
              t_ptr++;
            if(t_ptr->term[0] == '\0')
             {
               fprintf(tty,"\nSlave Printing Denied: Unknown Terminal Type\n");
               fflush(tty);
               sleep(4);
             }
            else
             {
               remote_printer = TRUE;
               no_choice_has_been_made = FALSE;
               break;
             }
          }
         else
           choice = 0;
       }

      if((choice > 0) && (choice < num_choices))
       {
         no_choice_has_been_made = FALSE;
         break;
       }

      fprintf(tty,"\n                              INVALID CHOICE");
      fflush(tty);
      sleep(2);

      print_menu();
      n = 0;
    }
 }



#ifdef EXTERN

void show_externs()
 {
  char rtab[80];
  index n;


   setjmpret(ext);
   signal(SIGINT, extdelfunc);

   sprintf(rtab, "%s/rtab", RTAB_PATH);
   fclose(config);
   if((config = fopen(rtab,"r")) == NULL)
    {
      fprintf(tty,"\nExternal Printing Denied: Unable to open %s\n", rtab);
      fflush(tty);
      sleep(4);
      if((config = fopen(current_config,"r")) == NULL)
       {
         fprintf(stderr, "%s: Print Request Aborted - Unable to open %s\n",
                          prog_name, current_config);
         exit(7);
       }
      return;
    }
   clear_scr();
   load_externs();

   strcpy(curr_system, "External");

   no_choice_has_been_made = TRUE;
   choice = 0;
# ifdef UUCP
   while((choice != 88) && (choice != 99) && (no_choice_has_been_made))
# else
   while((choice != 99) && (no_choice_has_been_made))
# endif
    {
      print_menu();
      get_choice();
    }
   if(! no_choice_has_been_made)
    {
      fprintf(tty, "\n\n                     Enter Address: ");
      fflush(tty);
      n = 0;
      while(((address[n++] = getc(stdin)) != '\n') && (n < 127));
      if(address[--n] != '\n')
        while((getc(stdin)) != '\n');
      address[n] = '\0';
      externs = TRUE;
      strcpy(curr_system,sys_name->nodename);
    }
 }



void load_externs()
 {
  char  ext_name[15];
  index n;
  bool  found_slash = FALSE;

   d_ptr = devices;
   num_printers = 0;

   while(((c = getc(config)) == ' ') || (c == '\t'));
   while(c != EOF)
    {
      if(c == '#')
        ignore_line();
      else
       {
         ext_name[0] = c;
         n = 1;
         while(((ext_name[n++] = getc(config)) != ';') && (n < 14));
         ext_name[--n] = '\0';

         while(((c = getc(config)) != '\n') && (c != EOF))
          {
            if(found_slash)
             {
               if(c == 'U')
               {
                 if(lp)
                   strcpy(d_ptr->q_name, ext_name);
                 else
                  {
                    strcpy(d_ptr->d_name, ext_name);
                    strcpy(d_ptr->q_name, EXTERN_QUEUE_NAME);
                  }
                 ignore_line();
                 save_comments();
                 num_printers++;
                 d_ptr++;
                 found_slash = FALSE;
                 break;
               }
              else
               if(c != '\\')
                 found_slash = FALSE;
             }
            else
              if(c == '\\')
               found_slash = TRUE;
          }
       }
      if(c != EOF) /*&& ((c == ' ') || (c == '\t')))*/
        while(((c = getc(config)) == ' ') || (c == '\t'));
    }
   d_ptr->q_name[0] = d_ptr->d_name[0] = '\0';
 }

#endif



#ifdef UUCP

void get_system()
 {
  char  char_choice[6], command[20];
  int   sys_choice;
  short n;
  bool  system_not_chosen = TRUE;
  FILE  *uudata;

   setjmpret(sys);
   signal(SIGINT, sysdelfunc);

   if(! systems_set)
    {
      sprintf(command, "%s | sort", UUNAME);

      if((uudata = popen(command, "r")) == NULL)
       {
         fprintf(stderr,"%s: bad status from uuname\n", prog_name);
         exit(6);
       }

      while((c = getc(uudata)) != EOF)
       {
         n = 0;
         while(c != '\n')
          {
            systems[num_systems][n] = c;
            n++;
            c = getc(uudata);
          }
         systems[num_systems][n] = '\0';

         sprintf(curr_system,"%s", systems[num_systems]);
         sprintf(current_config,"%s/config%s", config_path, curr_system);

         if((config = fopen(current_config,"r")) != NULL)
          {
            fclose(config);
            num_systems++;
          }

         if(num_systems > 31)
          break;
       }
      systems_set = TRUE;
   }


   while(system_not_chosen)
    {
      clear_scr();
      fprintf(tty,"\n\n");
      fprintf(tty,"                            System Selection Menu\n");
      fprintf(tty,"                            ------ --------- ----\n");

      if(num_systems < 9)
       {
          for(n = 0; n < num_systems; n++)
            fprintf(tty, "\n                     %2d.  %s", n+1, systems[n]);
          fprintf(tty, "\n                      ");
          fprintf(tty,"%d.  Return to Local System Menu (%s)\n\n",num_systems+1,
                     sys_name->nodename );
       }
      else
       {
         if((num_systems + 1) % 2)
          {
           for(n = 0; n < (num_systems/2); n++)
             fprintf(tty,
                "\n                   %2d.  %-9s           %2d.  %-9s", n+1,
                systems[n], n+((num_systems/2)+1), systems[n+(num_systems/2)]);
          }
         else
          {
           for(n = 0; n < (num_systems/2); n++)
            fprintf(tty, "\n                   %2d.  %-9s           %2d.  %-9s",
                n+1, systems[n], n+((num_systems/2)+2),
                systems[n+(num_systems/2)+1]);
            fprintf(tty, "\n                   %2d.  %-9s",
                ((num_systems/2)+1), systems[(num_systems/2)]);
          }
        fprintf(tty, "\n\n                   ");
        fprintf(tty,"%d.  Return to Local System Menu (%s)\n\n",num_systems+1,
            sys_name->nodename );
      }


      fprintf(tty,"\n                                        ");
      fprintf(tty,"Enter your choice: ");
      fflush(tty);

      n = 0;
      while(((char_choice[n] = getc(stdin)) == ' ') ||
             (char_choice[n] == '\t'));

      if(! NL(char_choice[n]))
        n++;

      if NUM(char_choice[n-1])
       {
         char_choice[n] = getc(stdin);
         while((NUM(char_choice[n])) && (n < 19))
          {
            n++;
            char_choice[n] = getc(stdin);
          }
       }

      while(WS(char_choice[n]))
        char_choice[n] = getc(stdin);

      if(! NL(char_choice[n]))
       {
         while(((c = getc(stdin)) != '\n') && (c != '\r'));
         n = 0;
       }

      char_choice[n] = '\0';
      sys_choice = atoi(char_choice);

      if((sys_choice > 0) && (sys_choice <= (num_systems+1)))
        system_not_chosen = FALSE;
      else
       {
         fprintf(tty,"\n                              INVALID CHOICE");
         fflush(tty);
         sleep(2);
       }

    }

   if(sys_choice == (num_systems+1))
    {
      strcpy(curr_system,sys_name->nodename);
      sprintf(current_config,"%s/config" ,config_path);
    }
  else
    {
      sprintf(curr_system,"%s", systems[sys_choice-1]);
      sprintf(current_config,"%s/config%s", config_path, curr_system);
    }

   if((config = fopen(current_config,"r")) == NULL)
    {
      fprintf(stderr, "%s: Print Request Aborted - Unable to open %s\n",
                       prog_name, current_config);
      exit(7);
    }
 }

#endif



void view(vargc, vargv)
 int  vargc;
 char *vargv[];
 {
  index n;

   fclose(config);

   for(n = 0; n < vargc; n++)
    {
      if((report = fopen(vargv[n],"r")) == NULL)
       {
         clear_scr();
         fprintf(tty,"\n\n\n%s: Cannot open %s\n\n\n", prog_name, vargv[n]);
       }
      else
       {
         clear_scr();
         fprintf(tty, "\n\n\n\n\nNext File: %s", vargv[n]);
         fprintf(tty, "\n\n\n\n<RETURN> to Continue - <DEL> to Abort ");
         fflush(tty);
         while((getc(stdin)) != '\n');
         show();
         fclose(report);
       }
      fprintf(tty, "<RETURN> to Continue ");
      fflush(tty);
      while((getc(stdin)) != '\n');
    }
   if((config = fopen(current_config,"r")) == NULL)
    {
      fprintf(stderr, "%s: Print Request Aborted - Unable to open %s\n",
                       prog_name, current_config);
      exit(7);
    }

 }



void show()
 {
   short columns = 0, rows = 0;

    clear_scr();

    while((c = getc(report)) != EOF)
     {
       if(ASCII(c))
        {
          if(rows >= 23)
           {
             fprintf(tty, "<RETURN> to Continue - <DEL> to Abort ");
             fflush(tty);
             while((getc(stdin)) != '\n');
             rows = columns = 0;
           }
          fputc(c, tty);
          columns++;
          if((c == '\r') || (c == '\n') || (columns >= 80))
           {
             columns = 0;
             rows++;
           }
        }
       else
        if(NP(c))
         do
          {
            fputc('\n', tty);
            rows++;
          } while(rows < 23);
     }

    while(rows < 23)
     {
       fputc('\n', tty);
       rows++;
     }
 }



void get_copies()
 {
  char  cnum[3];
  bool  get_number = TRUE;
  short tmp_copies;

  while(get_number)
   {
     clear_scr();
     fprintf(tty, "\n\n\nEnter Number of Copies (1-10 default = 1) : ");
     fflush(tty);

     while(((cnum[0] = getc(stdin)) == ' ') || (cnum[0] == '\t'));

     if(cnum[0] == '\n')
      {
        copies = 1;
        break;
      }

     if(! NUM(cnum[0]))
      {
        while((cnum[0] = getc(stdin)) != '\n');
        fprintf(tty, "\n\n\07Bad Number - Please Re-enter");
        fflush(tty);
        sleep(2);
        continue;
      }

     cnum[1] = getc(stdin);
     if(cnum[1] == '\n')
       cnum[1] = '\0';
     else
      {
       if(! NUM(cnum[1]))
        {
          while((cnum[0] = getc(stdin)) != '\n');
          fprintf(tty, "\n\n\07Bad Number - Please Re-enter");
          fflush(tty);
          sleep(2);
          continue;
        }

       cnum[2] = getc(stdin);
       if(cnum[2] != '\n')
        {
          while((cnum[0] = getc(stdin)) != '\n');
          fprintf(tty, "\n\n\07Bad Number - Please Re-enter");
          fflush(tty);
          sleep(2);
          continue;
        }
       cnum[2] = '\0';

      }

   tmp_copies = atoi(cnum);
   if(tmp_copies > 10)
    {
      fprintf(tty, "\n\n10 Copy Maximum");
      fflush(tty);
      sleep(2);
      continue;
    }
   else
   if(tmp_copies < 1)
    {
      fprintf(tty, "\n\n1 Copy Minimum");
      fflush(tty);
      sleep(2);
      continue;
    }
   else
    get_number = FALSE;

   copies = tmp_copies;

  }

   if((config = fopen(current_config,"r")) == NULL)
    {
      fprintf(stderr, "%s: Print Request Aborted - Unable to open %s\n",
                       prog_name, current_config);
      exit(7);
    }
 }



void delfunc()
 {
   signal(SIGQUIT, SIG_IGN);
   signal(SIGINT, delfunc);

   fclose(config);
   if((config = fopen(current_config, "r")) == NULL)
    {
      fprintf(stderr, "%s: Print Request Aborted - Unable to open %s\n",
                       prog_name, current_config);
      exit(7);
    }

   longjmpret(print, 1);
 }



void sysdelfunc()
 {
   signal(SIGINT, sysdelfunc);
   signal(SIGQUIT, SIG_IGN);
   longjmpret(sys, 1);
 }



#ifdef EXTERN

void extdelfunc()
 {
   signal(SIGINT, extdelfunc);
   signal(SIGQUIT, SIG_IGN);
   longjmpret(ext, 1);
 }

#endif


void printjob(pjargc, pjargv)
 int  pjargc;
 char *pjargv[];
 {
  char  command[BUFSIZ], files[BUFSIZ-50], flags[138];
  bool  file_found = FALSE, found_at_least_one = FALSE;
  index n;


   files[0] = '\0';
   for(n = 0; n < pjargc; n++)
    {
      if(! setcom)
       {
         if((report = fopen(pjargv[n],"r")) == NULL)
          {
            fprintf(stderr,"%s: Cannot open %s\n", prog_name, pjargv[n]);
            exit_status = 2;
            file_found = FALSE;
          }
         else
          {
            fclose(report);
            found_at_least_one = TRUE;
            file_found = TRUE;
            exit_status = 0;
          }
       }

      if((file_found) || (setcom))
        sprintf(files, "%s %s", files, pjargv[n]);
      else
        pjargv[n][0] = '\0';
    }

   flags[0] = '\0';
   if((found_at_least_one) || (setcom))
    {
      if(remote_printer)
       {
         if((setcom) && (pjargc == 0))
         {
         proc_id = getpid();

         sprintf(command, 
          "cat > /tmp/ispi%d << \\EOF%c#!/bin/sh%c cat > /tmp/$$.pr%c echo \"%s\"%c copeez=%d%c while [ $copeez -ge 1 ]%c do%c cat /tmp/$$.pr%c copeez=`expr $copeez - 1`%c done%c echo \"%s\"%c rm /tmp/$$.pr%c exit%cEOF%c chmod 755 /tmp/ispi%d%c%c",
          proc_id, '\n', '\n', '\n', t_ptr->on, '\n', copies, '\n', '\n', '\n', '\n', '\n', '\n', t_ptr->off, '\n', '\n', '\n', '\n', proc_id, '\n', '\0');

         system(command);
         sprintf(command,"/tmp/ispi%d", proc_id);

         }
         else
         {

          sprintf(command,
           "sh -c \'echo \"%s\"%c copeez=%d%c while [ $copeez -ge 1 ]%c do%c cat %s%c copeez=`expr $copeez - 1`%c done%c echo \"%s\"%c exit%c%c\'",
           t_ptr->on, '\n', copies, '\n', '\n', '\n', files, '\n', '\n', '\n', t_ptr->off, '\n', '\n', '\0');

         }


       }

      else if((strcmp(curr_system,sys_name->nodename)) == 0)
       {
         if(copy)
          strcat(flags, "-c ");
         if(mail)
          strcat(flags, "-m ");

         if(lp)
          {
            if(banner)
              strcat(flags, "-tt");
#           ifdef EXTERN
            if(externs)
              sprintf(flags, "%s -o\"%s\"", flags, address);
#           endif
            sprintf(command,"lp %s -n%d -s -d%s %s",
                            flags, copies, printer, files);
          }
         else
          {
            if(! banner)
              strcat(flags, "-nb");
#           ifdef EXTERN
            if(externs)
              sprintf(flags, "%s -d \"%s\"", flags, address);
#           endif
            sprintf(command,"nq %s -t %d -q %s %s",
                           flags, copies, printer, files);
          }
       }
#    ifdef UUCP
      else
       {
         if(mail)
          strcat(flags, "-m ");
         if(banner && lp)
          strcat(flags, "-tt");
         else if((! banner) && (! lp))
          strcat(flags, "-nb");

         command[0] = '\0';
         if((pjargc == 0) && (setcom))
          {
            if(lp)
              sprintf(command,"%s - %s\\! lp %s -c -n%d -s -d%s",
                    UUX, curr_system, flags, copies, printer);
            else
              sprintf(command,"%s - %s\\! nq %s -c -t %d -q %s",
                    UUX, curr_system, flags, copies, printer);
          }
         else for(n = 0; n < pjargc; n++)
          {
           if(pjargv[n][0] != '\0')
            {
             if(lp)
               sprintf(command,"%scat %s | %s - %s\\! lp %s -c -n%d -s -d%s ; ",
                 command, pjargv[n], UUX, curr_system, flags, copies, printer);
             else
               sprintf(command,"%scat %s | %s - %s\\! nq %s -c -t %d -q %s ; ",
                 command, pjargv[n], UUX, curr_system, flags, copies, printer);
            }
          }
       }
#     endif
    }

    if(setcom)
      fprintf(stdout,"%s",command);
    else if(found_at_least_one)
      exit_status = system(command);
    else
      exit_status = 2;
 }

#ifdef XFER
void xfer_it(vargc, vargv)
 int  vargc;
 char *vargv[];
 {
  index n;
  char sistum[BUFSIZ];

   fclose(config);

   for(n = 0; n < vargc; n++)
    {
      if((report = fopen(vargv[n],"r")) == NULL)
       {
         clear_scr();
         fprintf(tty,"\n\n\n%s: Cannot open %s\n\n\n", prog_name, vargv[n]);
       }
      else
       {
         clear_scr();
         sprintf(sistum, "%s %s", xfer_cmd, vargv[n]);
         fprintf(tty, "\n\n\n\n\n%s", sistum);
         fprintf(tty, "\n\n\nABORT this routine if you are ");
         fprintf(tty, "not prepared to start the receiving process.");
         fprintf(tty, "\n\n\n\n<RETURN> to Begin - <DEL> to Abort ");
         fflush(tty);
         while((getc(stdin)) != '\n');
         sleep(10);
         system(sistum);
         fclose(report);
       }
      fprintf(tty, "<RETURN> to Continue ");
      fflush(tty);
      while((getc(stdin)) != '\n');
    }
   if((config = fopen(current_config,"r")) == NULL)
    {
      fprintf(stderr, "%s: Print Request Aborted - Unable to open %s\n",
                       prog_name, current_config);
      exit(7);
    }

 }
#endif
