/*  UUSTART								*/
/*		THIS IS UUSTART FOR THE MODEL 31 ZILOG			*/
/*		This program is designed to invoke uucico on a more	*/
/*	regular basis than would be possible via cron.                  */
/*									*/
/*	The program copies itself into a child process and runs		*/
/*	continuously without tying up the user's terminal.  The		*/
/*	program starts uucico at the requested interval.                */
/*									*/
/*      This timing and invocation routine is adapted from "monitor"	*/
/*      which was written by:						*/
/*									*/
/*	       	John Withers						*/
/*		IRS (Springfield District)				*/
/*		Phone:	FTS 955-4842					*/
/*									*/
/*									*/
/*      UUSTART was written by:						*/
/*		Larry Bartz                                             */
/*		IRS (Indianapolis District)                             */
/*		Phone: FTS 331-6796                                     */
/*									*/
/*	Date:	December 30, 1986					*/
/*									*/
/*									*/

#include <stdio.h>
#include <time.h>
#include <ssignal.h>

/*  User adjustable constants for "uustart.c"				  */

/* Define the execution window, STIME to ETIME on DAY1 through DAY2	  */

#define STIME 25200	/* Daily starting time 6:00 AM (sec past midnight)*/
#define ETIME 64800	/* Daily ending time 7:00 PM (sec past midnight)  */
#define DAY1  0		/* Starting day of the week, (Sun = 0)		  */
#define DAY2  6		/* Ending day of the week (Sun = 0)		  */

/* Define the interval between samples					  */

#define INTV  120	/* Interval between invocations [2 min](in seconds)*/


main()

{


  int pid,
      status,
      child,
      parent,
      fork();

  long last_time,
       curtime,
       stop();

/* On with the show							*/

  signal(SIGHUP, SIG_IGN);	/* Ignore 'Hang-up' signals		*/
  signal(SIGINT, SIG_IGN);	/* Ignore 'Interrupt' signals		*/
  signal(SIGQUIT,SIG_IGN);	/* Ignore 'Quit' signals		*/

  switch (pid = fork())		/* Switch to child process		*/
  {
	case 0:			/* In child process, all ok		*/
		break;

	case -1:		/* In parent process with error		*/
		sysmsg("uustart: fork failed");
		exit(1);

	default:		/* In parent process, all ok		*/
		exit(0);
  }

  last_time = stop(INTV);	/* Wait until on interval get time	*/


  for(;;)
  {
	curtime = stop(INTV);	/* Wait for interval, get current time	*/

	last_time = curtime;

	if (checktime(curtime) == 0) continue;

	switch(child = fork())
	{
		case -1:
			sysmsg("uustart - fork failed");
			break;

		case 0:		/* Child process			*/
			execlp("/usr/lib/uucp/uucico","uucico","-r1",NULL);
			sysmsg("uustart - exec failed");
			break;

		default:
			parent = wait(&status);
			break;
	}
  }
}

/*  STOP								*/
/*	This function stops the current process until the next even	*/
/*	'interval' (e.g. next quarter hour).  The function returns	*/
/*	the current system time as its functional value			*/

long stop(interval)

int interval;

{
  int intrtn();

  unsigned length;

  long now, time();

  now = time((long *) 0);

  length = ((now / interval) + 1) * interval - now;

  signal(SIGALRM, intrtn);
  alarm(length);
  pause();
  return(time((long *) 0));
}

/* INTRTN								*/
/*  This function is present to allow for alarm clock signal trapping	*/
intrtn()
{return;}

int checktime(when)

long when;

{
  extern long timezone;		/* Seconds adjustment for time zone	*/

  extern int  daylight;		/* TRUE if daylight savings time	*/

  int wday,
      flag = 1;

  long now;

  tzset();			/* Set the time zone adjustment		*/

  when -= timezone;		/* Adjust for local time		*/

  if (daylight) when += 3600;	/* Adjust for daylight saving time	*/

  now = when % 86400;		/* Seconds since midnight		*/

  if (now < (STIME + INTV) || now > ETIME) flag = 0;

  wday = ((when / 86400) + 4) % 7;

  if (wday < DAY1 || wday > DAY2) flag = 0;

  return(flag);
}

sysmsg(msg)

char *msg;

{
  extern int 	errno,
		deverr,
		sys_nerr;

  extern char	*sys_errlist[];

  struct tm *x, *localtime();

  long now, time();

  now = time((long *) 0);

  x = localtime(&now);

  fprintf(stderr,"%02d/%02d/%02d %02d:%02d:%02d - ",
	x->tm_mon+1, x->tm_mday, x->tm_year, x->tm_hour, x->tm_min, x->tm_sec);

  fprintf(stderr,msg);

  if (errno <= sys_nerr)
	fprintf(stderr, " (%s)\n", sys_errlist[errno]);
  else
	fprintf(stderr, " (Error %d)\n", errno);

  fflush(stderr);
}
