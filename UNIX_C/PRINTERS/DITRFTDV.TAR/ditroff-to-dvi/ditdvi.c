#include	<stdio.h>
#include	"ditdvi.h"

char		pageoffset	= 1;
char		*prog_name;

/*VARARGS1*/
fatal(s, arg1, arg2)
	char		*s;
	int		arg1, arg2;
{
	(void)fprintf(stderr, s, arg1, arg2);
	exit(1);
}

main(argc, argv)
	int		argc;
	char		*argv[];
{
	register int	c;
	char		*rindex();
	int		getopt();
	extern int	optind;
	extern char	*optarg;

	if ((prog_name = rindex(argv[0], '/')) == NULL)
		prog_name = argv[0];
	else
		++prog_name;
	while ((c = getopt(argc, argv, "o")) != EOF)
	{
		switch (c)
		{
		case 'o':
			pageoffset = 0;
			break;
		default:
			fatal("Usage: %s [-o] < f.di > f.dvi\n", prog_name);
			break;
		}
	}
	reader();
	exit(0);
}
