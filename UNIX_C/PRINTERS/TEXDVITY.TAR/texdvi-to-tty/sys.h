procedure exit(i : integer); external;			{ in libc }

procedure setpos(var f : DVIfiletype; p, m : integer); external;

function sizef(var f : DVIfiletype) : integer; external;

procedure delete(var f : text); external;

function readp(var filename : string) : boolean; external;

function writep(var filename : string) : boolean; external;

procedure tostdout(var f  :text); external;

procedure tostderr(var f : text); external;

function ttyp(var f :text) : boolean; external;

function popenp(var f :text; var path : pathtype;
                                pathpgm : boolean) : boolean; external;

procedure pcloseit(var f :text); external;

function envargs(var optch :char; var str :string) : boolean; external;
