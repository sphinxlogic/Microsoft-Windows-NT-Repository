/***************************************************************************
 * U. Minnesota LPD Software * Copyright 1987, 1988, Patrick Powell
 ***************************************************************************
 * MODULE: setup_test.c
 * sets the test version of things
 ***************************************************************************
 * Revision History: Created Sun Jan 31 06:09:35 CST 1988
 * $Log:	setup_test.c,v $
 * Revision 3.1  88/06/18  09:35:47  papowell
 * Version 3.0- Distributed Sat Jun 18 1988
 * 
 * Revision 2.2  88/05/14  10:21:07  papowell
 * Modified -X flag handling
 * 
 * Revision 2.1  88/05/09  10:10:27  papowell
 * PLP: Released Version
 * 
 * Revision 1.4  88/04/27  20:27:20  papowell
 * Modified to remove unused variables
 * 
 * Revision 1.3  88/04/07  12:31:00  papowell
 * 
 * Revision 1.2  88/03/11  19:29:38  papowell
 * Minor Changes, Updates
 * 
 * Revision 1.1  88/03/01  11:09:21  papowell
 * Initial revision
 * 
 ***************************************************************************/
#ifndef lint
static char id_str1[] =
	"$Header: setup_test.c,v 3.1 88/06/18 09:35:47 papowell Exp $ PLP Copyright 1988 Patrick Powell";
#endif lint

#include "lp.h"

Setup_test()
{
	(void)strcpy( Lpdlogf, TDEFLPDLOGF );
	(void)strcpy( Masterlock, TMASTERLOCK );
	Maxportno = TMAXPORTNO;
	Minportno = TMINPORTNO;
	(void)strcpy( Permfile, TPERMFILE );
	(void)strcpy( Printcap, TPRINTCAP );
	Lpr_port_num = htons( TPORTNUM );
}
