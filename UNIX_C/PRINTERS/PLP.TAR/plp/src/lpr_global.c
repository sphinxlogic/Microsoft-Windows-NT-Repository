/***************************************************************************
 * U. Minnesota LPD Software * Copyright 1987, 1988, Patrick Powell
 ***************************************************************************
 * MODULE: lpr_global.c
 * Globals for LPR Program
 ***************************************************************************
 * Revision History: Created Mon Jan 25 17:16:16 CST 1988
 * $Log:	lpr_global.c,v $
 * Revision 3.1  88/06/18  09:34:56  papowell
 * Version 3.0- Distributed Sat Jun 18 1988
 * 
 * Revision 2.1  88/05/09  10:09:16  papowell
 * PLP: Released Version
 * 
 * Revision 1.3  88/05/05  20:08:58  papowell
 * Added a NOHEADER option that allows user to suppress banner
 * 
 * Revision 1.2  88/03/25  15:00:32  papowell
 * Debugged Version:
 * 1. Added the PLP control file first transfer
 * 2. Checks for MX during file transfers
 * 3. Found and fixed a mysterious bug involving the SYSLOG facilities;
 * 	apparently they open files and then assume that they will stay
 * 	open.
 * 4. Made sure that stdin, stdout, stderr was available at all times.
 * 
 * Revision 1.1  88/03/01  11:08:47  papowell
 * Initial revision
 * 
 ***************************************************************************/
#ifndef lint
static char id_str1[] =
	"$Header: lpr_global.c,v 3.1 88/06/18 09:34:56 papowell Exp $ PLP Copyright 1988 Patrick Powell";
#endif lint

#include "lpr.h"

int Format;					/* Job Format */
int Copies;					/* Number of Copies */
int Binary;					/* Binary files */
int Remove;					/* Remove files after using */
int Use_links;				/* Make a symbolic link to the file */
char **Temp_file;			/* Names of temp files */
int Temp_count;				/* current number of temp files */
int Temp_max;				/* maximum number of temp files */
int Exper;					/* use the Xpert version */
int Priority;				/* job priority */
int Job_number;				/* job sequence number */
char *Read_stdin;			/* name of temp file holding stdin */
char *Filter_out;			/* name of temp file for filter output */
int Noheader;				/* No header is to be printed */
