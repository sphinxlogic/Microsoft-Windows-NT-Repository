#!/bin/sh
case $# in
0)   lpr -p ;;
*)   lpr -p "$@" ;;
esac
