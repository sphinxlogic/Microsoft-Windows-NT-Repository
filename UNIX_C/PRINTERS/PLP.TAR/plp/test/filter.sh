#!/bin/sh
#	Filter Dummy Test
# $Header: filter.sh,v 3.1 88/06/18 09:56:26 papowell Exp $
# $Log:	filter.sh,v $
# Revision 3.1  88/06/18  09:56:26  papowell
# Version 3.0- Distributed Sat Jun 18 1988
# 
PATH=/bin:/usr/bin
echo $0 $* 1>&2
echo "pwd " `/bin/pwd`  1>&2
delay=0
for i in $*
do
	case $i in
		-delay*) delay=`echo $i |sed -e 's/-delay//'` ;;
		-error*) error=`echo $i |sed -e 's/-error//'` ;;
		-*) ;;
		*) file=$i ;;
	esac
done
if test -n "$file";
	then echo $0 $* >>$file
	else echo "--- NO Accounting File ---" 1>&2
fi
# echo information into output
echo $0 $*
# wait a minute to simulate the delay
if test $delay -ne 0 ; then sleep $delay; fi;
# exit with error status
if test -n "$error";
then
	exit $error;
fi;
# pump stdin to stdout
cat
