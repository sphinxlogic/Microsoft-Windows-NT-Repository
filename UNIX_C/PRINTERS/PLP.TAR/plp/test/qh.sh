#!/bin/sh
echo $0 $- $* 1>&2
exit 0
