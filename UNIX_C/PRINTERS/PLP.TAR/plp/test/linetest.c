/*
 * linetest: print the rolling banner pattern
 * linetest [width]
 * Sat Jun 18 09:47:06 CDT 1988 Patrick Powell
 * $Log:	linetest.c,v $
 * Revision 3.1  88/06/18  09:56:27  papowell
 * Version 3.0- Distributed Sat Jun 18 1988
 * 
 */
#include <stdio.h>
#include <ctype.h>
static char id_str1[] =
	"$Header: linetest.c,v 3.1 88/06/18 09:56:27 papowell Exp $ PLP Copyright 1988 Patrick Powell";
char *Name;

main(argc, argv)
	int argc;
	char **argv;
{
	int width = 132;
	int i,j;

	Name = argv[0];
	if( argc > 2 || argc < 1 ){
		usage();
	}
	if( argc == 2 ){
		i = atoi( argv[1] );
		if( i != 0 ){
			width = i;
		} else {
			usage();
		}
	}
	
	i = ' ';
	while(1){
		for( j = 0; j < width; ++j ){
			if( !isprint(i) || isspace(i) ){
				i = 'A';
			}
			putchar( i );
			i = i + 1;
		}
		putchar( '\n' );
	}
}

usage()
{
	fprintf( stderr, "%s [width]\n", Name );
	exit( 0 );
}
