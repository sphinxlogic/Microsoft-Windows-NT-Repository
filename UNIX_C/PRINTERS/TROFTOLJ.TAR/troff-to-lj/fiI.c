/*
 * fiI.c
 * HP fontinfo definition for
 * Times italic typeface
 */

#include "hpfinfo.h"

struct hpfontinfo x = {
	0,	/* portrait */
	1,	/* proportional spacing */
	1,	/* italic */
	0,	/* medium boldness */
	5	/* Times typeface */
};
