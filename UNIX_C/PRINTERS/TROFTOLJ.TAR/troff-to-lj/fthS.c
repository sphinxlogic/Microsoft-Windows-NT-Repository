char XXw[256-32] = {
0,		/* null */
0,		/* null */
13,		/* " */
26,		/* # */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
21,		/* < */
0,		/* null */
21,		/* > */
0,		/* null */
34,		/* @ */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
18,		/* \ */
0,		/* null */
14,		/* ^ */
30,		/* _ */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
14,		/* { */
0,		/* null */
15,		/* } */
15,		/* ~ */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
20+0300,	/* section */
0,		/* null */
10,		/* acute accent */
10,		/* grave accent */
30,		/* underrule */
18,		/* slash (matching backslash) */
0,		/* null */
0,		/* null */
22,		/* alpha */
21+0300,	/* beta */
20+0100,	/* gamma */
16+0200,	/* delta */
15,		/* epsilon */
17+0300,	/* zeta */
19+0100,	/* eta */
15+0200,	/* theta */
14,		/* iota */
20,		/* kappa */
20+0200,	/* lambda */
22+0100,	/* mu */
20,		/* nu */
18+0300,	/* xi */
17,		/* omicron */
20,		/* pi */
17+0100,	/* rho */
19,		/* sigma */
16,		/* tau */
19,		/* upsilon */
20+0100,	/* phi */
22+0100,	/* chi */
22+0300,	/* psi */
22,		/* omega */
21+0200,	/* Gamma */
30+0200,	/* Delta */
26+0200,	/* Theta */
23+0200,	/* Lambda */
20+0300,	/* Xi */
26+0200,	/* Pi */
26+0200,	/* Sigma */
0,		/* null */
25+0200,	/* Upsilon */
26+0200,	/* Phi */
27+0200,	/* Psi */
24+0200,	/* Omega */
30,		/* square root */
17,		/* terminal sigma */
30,		/* root en extender */
21,		/* >= */
21,		/* <= */
22,		/* identically equal */
20,		/* minus */
26,		/* approx = */
22,		/* approximates */
22+0300,	/* not equal */
34,		/* right arrow */
34,		/* left arrow */
18+0200,	/* up arrow */
18+0200,	/* down arrow */
22,		/* math equals */
21,		/* multiply */
20,		/* divide */
21,		/* plus-minus */
24,		/* cup (union) */
24,		/* cap (intersection) */
24,		/* subset of */
24,		/* superset of */
24,		/* improper subset */
24,		/* improper superset */
35,		/* infinity */
20+0200,	/* partial derivative */
20,		/* gradient */
23,		/* not */
22,		/* integral sign */
26,		/* proportional to */
25+0300,	/* empty set */
24,		/* member of */
20,		/* math plus */
0,		/* null */
0,		/* null */
30,		/* box vertical rule */
0,		/* null */
16+0300,	/* dbl dagger */
34,		/* right hand */
34,		/* left hand */
19+0200,	/* math star */
21,		/* bell system sign (replaced with h bar)*/
7+0200,		/* or */
27,		/* circle */
30,		/* left top (of big curly) */
30,		/* left bottom */
30,		/* right top */
30,		/* right bot */
30,		/* left center of big curly bracket */
30,		/* right center of big curly bracket */
30,		/* bold vertical */
30,		/* left floor (lb of bracket) */
30,		/* right floor (rb of bracket) */
30,		/* left ceiling (lt of bracket) */
30,		/* right ceiling (rt of bracket) */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0,		/* null */
0		/* null */
};
