/*
 * fiR.c
 * HP fontinfo definition for
 * Times Roman typeface
 */

#include "hpfinfo.h"

struct hpfontinfo x = {
	0,	/* portrait */
	1,	/* proportional spacing */
	0,	/* upright */
	0,	/* medium boldness */
	5	/* Times typeface */
};
