DVItoVDU in C, version 1.0 for UNIX
===================================
Andrew Trevorrow,
Marc Hadley and Mark J. Hewitt
 
DVItoVDU is a public-domain TeX previewer that drives a variety
of commonly available terminals.
 
This version of DVItoVDU was developed from Andrew Trevorrow's Modula-2 version
but hand-translated into C for use on Unix systems without an adequate
Pascal compiler and which cannot use Andrew's Pascal version of the program.
 
Installation
------------
 
1. Edit the Makefile to suit your system.
 
   The following Makefile variables can be set:
	PARALLEL	If your make supports parallel operation - PARALLEL
			should be set to &
	SYSTEM		For BSD-derived variants of Unix, SYSTEM=BSD
			For SystemV-derived variants, SYSTEM=USG
	DIRCALLS	For BSD or SysV.3 variants with the mkdir(2)
			and rmdir(2) calls, DIRCALLS=OK_DIRCALLS
			if  your system does not provide these system calls,
			DIRCALLS=NO_DIRCALLS
	FILESYSTEM	For systems with a BSD filesystem,
			FILESYSTEM=BSD_FILESYSTEM
			for SysV filesystems, FILESYSTEM=USG_FILESYSTEM
	TTYIO		For 4.2BSD-type terminal i/o, TTYIO=bsdio
			for SysV terminal i/o, TTYIO=usgio
	LIBS		Library flags for ld.  -lm is always needed.
			For example, LIBS=-lm -lseq  on a Sequent.
	LINTOPTS	Options for lint(1).
	TMPDIR		Directory for temp files (default TMPDIR=/tmp)
	PXLFONTDIR	Directory containing PXL files
			(default PXLFONTDIR=/usr/local/lib/tex/fonts/pxl)
	PKFONTDIR	Directory containing PK files
			(default PKFONTDIR=/usr/local/lib/tex/fonts/pk)
	HELPFILE	Path to help file
			(default HELPFILE=/usr/local/lib/tex/dvitovdu.hlp)
	EXECNAME	Name to give the executable file
			(default EXECNAME=dvi2vdu)
	USERFLAGS	Other options for cc(1).
			On systems which don't correctly handle assignments
			to pointers to functions returning void, add
			-DVOIDPTR=int
			(default USERFLAGS=-O)
 
 
2. Build ${EXECNAME} by running make.
 
 
Revision history
----------------
 
Version 1.0 was released in February 1990 and was based on Andrew Trevorrow's
Modula-2 version. The translation to C was made by Marc Hadley, Mark J.Hewitt
and colleagues at Kernel Technology, Leeds, England.
