/* Original Author:         Andrew Trevorrow
   Implementation: Modula-2 under VAX/UNIX 4.2 BSD
   Date Started:   June, 1986 (based on DCLInterface under VAX/VMS)
 
   Description:
   InitSysInterface gets the DVItoVDU command line and initializes
   the DVI file name and command option values.
 
   This version converted to C and ported to BSD and System V UNIX by
   some chaps at Kernel Technology up to September 1989.  Contact
   mjh@uk.co.kernel (Mark J. Hewitt) with bug fixes etc.
 
   Involved were:	Mark J. Hewitt
   			Dave Dixon
			Marc Hadley
*/
 
static char *sccsid_sys[] = "@(#)systemif.h	1.1";
 
extern int GetParameter();
 
unsigned int
   resolution,     /* -r value defines pixels per inch */
   mag,            /* -m value replaces DVI mag; default = 0 = use DVI mag */
   paperwd,        /* -x value defines paper width; converted to pixels */
   paperht;        /* -y value defines paper height; converted to pixels */
 
stringvalue
   fontdir,        /* -f value defines directory containing PXL files */
   dummyfont,      /* -d value defines dummy PXL file */
   helpname,       /* -h value defines help file read by ? command */
   vdu,            /* -v value tells DVItoVDU what terminal is being used */
   DVIname;       /* DVI file name */
 
void InitSysInterface();
 
 
