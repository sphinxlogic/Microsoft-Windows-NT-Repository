/* Some	generally useful definitions for dvitovdu
 
   Mark	J. Hewitt  Kernel Technology Limited. 22-November-1989
*/
 
static char *sccsid_def[] = "@(#)def.h	1.1";
 
#include <stdio.h>
 
#define	ABS(a) (((a)<0)? -(a):(a))
 
#define	ESC 033
#define	FF  014
#define	SO 016
#define	SI 017
#define	DEL  '\177'
#define	FS  034
#define	GS  035
#define	US  037
#define	TRUE 0x0001
#define	FALSE 0x0000
#define	CAN 030
 
#ifndef	VOIDPTR
#define	VOIDPTR	void
#endif
 
typedef	VOIDPTR	Void;		/* for ptr to functions returning void */
 
#ifdef BSD
#ifndef BSD_FILESYSTEM
#define BSD_FILESYSTEM
#endif /* BSD_FILESYSTEM */
#endif /* BSD */
 
#define MAXSTRLEN 81

#define exitprog(i) exit(i)
 
typedef  char   stringvalue[MAXSTRLEN+1] ;
 
/* Per device action routines */
 
extern	Void (*ClearScreen) (),
	     (*ClearTextLine) (),
	     (*LoadFont) (),
	     (*MoveToTextLine) (),
	     (*ResetVDU) (),
	     (*ShowChar) (),
	     (*ShowRectangle) (),
	     (*StartGraphics) (),
	     (*StartText) ();
 
extern	void InitSysInterface (),
	     InitVDUInterface (),
	     MoveAbs (),
	     Read (),
	     ReadString	(),
	     RestoreTerminal (),
	     Write (),
	     WriteBuffer (),
	     WriteCard (),
	     WriteInt (),
	     WriteLn (),
	     WriteString (),
	     exit(),
	     free(),
	     suspend ();
 
extern int  windowh,
	    windowht,
	    windowstatusl,
	    windowv,
	    windowwd,
	    bottoml,
	    screenht,
	    messagel,
	    commandl,
	    maxhp,
	    maxvp,
	    minhp,
	    minvp;
 
 
extern char *malloc (),
	    *strcpy ();
 
extern char TeXtoASCII[];
 
extern int  DVIstatusl;
 
extern int  strlen ();
 
extern unsigned	int mag,
		    paperht,
		    paperwd,
		    resolution;
 
