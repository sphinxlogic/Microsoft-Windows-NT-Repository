/* Original Author:         Andrew Trevorrow
   Implementation: Modula-2 under VAX/UNIX 4.2 BSD
   Date Started:   June, 1986 (based on version 1.5 under VAX/VMS 4.2)
 
   Description:
   DVItoVDU allows pages from a DVI file produced by TeX82 to be viewed on a
   variety of VDU screens.
 
   This version converted to C and ported to BSD and System V UNIX by
   some chaps at Kernel Technology up to September 1989.  Contact
   mjh@uk.co.kernel (Mark J. Hewitt) with bug fixes etc.
 
   Involved were:	Mark J. Hewitt
   			Dave Dixon
			Marc Hadley
*/
 
/* Version History:
 
   18-Jan-90	mjh	Issued release one with lots of help from Dave
			Osborne at Nottingham University.
 
*/

/* 
  12-May-90 M.Kitagawa  True PK version with JTeX support
*/

static char *sccsid_ver[] = "%W";
 
char Version[] = "DVItoVDU. [ICCE] C version 1.1J";
 
 
 
