/* include file for all dvitovdu files defines values for general use */
/*
   This version converted to C and ported to BSD and System V UNIX by
   some chaps at Kernel Technology up to September 1989.  Contact
   mjh@uk.co.kernel (Mark J. Hewitt) with bug fixes etc.
 
   Involved were:	Mark J. Hewitt
   			Dave Dixon
			Marc Hadley
*/
 
static char *sccsid_dvi[] = "@(#)dvitovdu.h	1.1";
 
Void (*StartText)();
Void (*ClearScreen)();
Void (*ResetVDU)();
Void (*ClearTextLine)();
Void (*MoveToTextLine)();
Void (*StartGraphics)();
Void (*LoadFont)();
Void (*ShowChar)();
Void (*ShowRectangle)();
