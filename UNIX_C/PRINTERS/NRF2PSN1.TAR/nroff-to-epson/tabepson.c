/*
 * EPSON
 * nroff driving tables
 * width and code tables
 */

#define INCH	240

struct {
	int bset;
	int breset;
	int Hor;
	int Vert;
	int Newline;
	int Char;
	int Em;
	int Halfline;
	int Adj;
	char *twinit;
	char *twrest;
	char *twnl;
	char *hlr;
	char *hlf;
	char *flr;
	char *bdon;
	char *bdoff;
	char *ploton;
	char *plotoff;
	char *up;
	char *down;
	char *right;
	char *left;
	char *codetab[256-32];
	int zzz;
	} t = {
/*bset*/	0,
/*breset*/	0177420,
/*Hor*/		INCH/6,
/*Vert*/	INCH/48,
/*Newline*/	INCH/6,
/*Char*/	INCH/12,
/*Em*/		INCH/12,
/*Halfline*/	INCH/12,
/*Adj*/		INCH/12,
/*twinit*/	"\033AA",
/*twrest*/	"\033AB",
/*twnl*/	"\012",
/*hlr*/		"\033AC",	/* SUPERSCRIPT */
/*hlf*/		"\033AD",	/* SUBSCRIPT   */
/*flr*/		"\033AE",	/* 1 line UP   */
/*bdon*/	"\033AF",
/*bdoff*/	"\033AG",
/*ploton*/	"",
/*plotoff*/	"",
/*up*/		"",
/*down*/	"\n",
/*right*/	" ",
/*left*/	"\b",
/*codetab*/
#include "code.epson"
