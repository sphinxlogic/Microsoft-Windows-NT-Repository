static char *RCSid = "$Header: strsave.c,v 1.1 87/10/23 19:08:15 sysad Exp $";

/*
 * $Log:	strsave.c,v $
 * Revision 1.1  87/10/23  19:08:15  sysad
 * Initial revision
 * 
 * 
 */

/*                                                                    */
/* save a copy of the string 'string' some place.                     */
/*                                                                    */

#define	NULL	(char *)0
#define NOWORD	"(null)"
char *TOOMUCH = "savestr; too much space allocated\n";

char *
savestr(str)
char *str;
{
	char *place,*save,*calloc();
	char *tmp;
	int i,j;

	if( (i = strlen(str)) <= 0 )
	{
		save = "garbage";
		i = 7;
	}
	else save = str;
	if((place = calloc(1,i+1)) == NULL ) 
	{
		/* dont' want or need stdio */
		write(2,TOOMUCH,sizeof(TOOMUCH));
		exit(1);
	}
	tmp = place;
	i++;	/* room for the null byte */
	j = 0;
	while ( (j++ < i) &&  *save )
		 *tmp++ = *save++;
	*tmp = 0;
	return(place);
}
