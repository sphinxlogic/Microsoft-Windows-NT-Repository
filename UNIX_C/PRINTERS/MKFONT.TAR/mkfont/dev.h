/*
 * $Header: dev.h,v 1.1 87/10/23 19:08:07 sysad Exp $
 */

/*
 * $Log:	dev.h,v $
 * Revision 1.1  87/10/23  19:08:07  sysad
 * Initial revision
 * 
 * 
 */

 struct dev {
	unsigned short filesize;
	short res;
	short hor;
	short vert;
	short unitwidth;
	short nfonts;
	short nsizes;
	short sizescale;
	short paperwidth;
	short paperlength;
	short nchtab;
	short lchname;
	short biggestfont;
	short spare;
};
