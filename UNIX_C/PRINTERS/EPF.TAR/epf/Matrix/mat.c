
main () {
   int   digit,
         x,
         y,
         n;
   extern int  array[24][28]; 
   printf ("    {\n    ");
   printf (" 27,'p',  1, 27,'&',  0,'A','A',  4, 28,  5,\n    ");
   for (x = 0; x < 28; x++) {
      digit = 0;
      n = 1;
      for (y = 7; y >= 0; y-- ) {
	 digit += (array[y][x] * n);
	 n = n * 2;
      }
      printf ("%3d,", digit);
      digit = 0;
      n = 1;
      for (y = 15; y > 7; y--) {
	 digit += (array[y][x] * n);
	 n = n * 2;
      }
      printf ("%3d,", digit);
      digit = 0;
      n = 1;
      for (y = 23; y > 15; y--) {
	 digit += (array[y][x] * n);
	 n = n * 2;
      }
      printf ("%3d,", digit);
      if (x == 4 | x == 9 | x == 14 | x == 19 | x == 24)
	 printf ("\n    ");
   }
   printf("\n     27,'%%',  1,'A', 27,'%%',  0, 27,'p',  0");
   printf ("\n    },\n");
}
