for i in $*
do
	echo $i
	sed -e "s/[ ],/0,/g" $i >matrix.c
	make
	echo "/* $i /* . */" >>addin
	cat to* >>addin
done

