/*
 * dvipage: DVI Previewer Program for Suns
 *
 * Neil Hunt (hunt@spar.slb.com)
 *
 * This program is based, in part, upon the program dvisun,
 * distributed by the UnixTeX group, extensively modified by
 * Neil Hunt at the Schlumberger Palo Alto Research Laboratories
 * of Schlumberger Technologies, Inc.
 *
 * From the dvisun manual page entry:
 *	Mark Senn wrote the early versions of [dvisun] for the
 *	BBN BitGraph. Stephan Bechtolsheim, Bob Brown, Richard
 *	Furuta, James Schaad and Robert Wells improved it. Norm
 *	Hutchinson ported the program to the Sun. Further bug fixes
 *	by Rafael Bracho at Schlumberger.
 *
 * Copyright (c) 1988 Schlumberger Technologies, Inc 1988.
 * Anyone can use this software in any manner they choose,
 * including modification and redistribution, provided they make
 * no charge for it, and these conditions remain unchanged.
 *
 * This program is distributed as is, with all faults (if any), and
 * without any warranty. No author or distributor accepts responsibility
 * to anyone for the consequences of using it, or for whether it serves any
 * particular purpose at all, or any other reason.
 *
 * HISTORY
 *
 * 12 April 1988 - Neil Hunt
 *	Version 2.0 released for use.
 *
 * Earlier history unavailable.
 */

#define  SETC_000    0
#define  SETC_001    1
#define  SETC_002    2
#define  SETC_003    3
#define  SETC_004    4
#define  SETC_005    5
#define  SETC_006    6
#define  SETC_007    7
#define  SETC_008    8
#define  SETC_009    9
#define  SETC_010   10
#define  SETC_011   11
#define  SETC_012   12
#define  SETC_013   13
#define  SETC_014   14
#define  SETC_015   15
#define  SETC_016   16
#define  SETC_017   17
#define  SETC_018   18
#define  SETC_019   19
#define  SETC_020   20
#define  SETC_021   21
#define  SETC_022   22
#define  SETC_023   23
#define  SETC_024   24
#define  SETC_025   25
#define  SETC_026   26
#define  SETC_027   27
#define  SETC_028   28
#define  SETC_029   29
#define  SETC_030   30
#define  SETC_031   31
#define  SETC_032   32
#define  SETC_033   33
#define  SETC_034   34
#define  SETC_035   35
#define  SETC_036   36
#define  SETC_037   37
#define  SETC_038   38
#define  SETC_039   39
#define  SETC_040   40
#define  SETC_041   41
#define  SETC_042   42
#define  SETC_043   43
#define  SETC_044   44
#define  SETC_045   45
#define  SETC_046   46
#define  SETC_047   47
#define  SETC_048   48
#define  SETC_049   49
#define  SETC_050   50
#define  SETC_051   51
#define  SETC_052   52
#define  SETC_053   53
#define  SETC_054   54
#define  SETC_055   55
#define  SETC_056   56
#define  SETC_057   57
#define  SETC_058   58
#define  SETC_059   59
#define  SETC_060   60
#define  SETC_061   61
#define  SETC_062   62
#define  SETC_063   63
#define  SETC_064   64
#define  SETC_065   65
#define  SETC_066   66
#define  SETC_067   67
#define  SETC_068   68
#define  SETC_069   69
#define  SETC_070   70
#define  SETC_071   71
#define  SETC_072   72
#define  SETC_073   73
#define  SETC_074   74
#define  SETC_075   75
#define  SETC_076   76
#define  SETC_077   77
#define  SETC_078   78
#define  SETC_079   79
#define  SETC_080   80
#define  SETC_081   81
#define  SETC_082   82
#define  SETC_083   83
#define  SETC_084   84
#define  SETC_085   85
#define  SETC_086   86
#define  SETC_087   87
#define  SETC_088   88
#define  SETC_089   89
#define  SETC_090   90
#define  SETC_091   91
#define  SETC_092   92
#define  SETC_093   93
#define  SETC_094   94
#define  SETC_095   95
#define  SETC_096   96
#define  SETC_097   97
#define  SETC_098   98
#define  SETC_099   99
#define  SETC_100  100
#define  SETC_101  101
#define  SETC_102  102
#define  SETC_103  103
#define  SETC_104  104
#define  SETC_105  105
#define  SETC_106  106
#define  SETC_107  107
#define  SETC_108  108
#define  SETC_109  109
#define  SETC_110  110
#define  SETC_111  111
#define  SETC_112  112
#define  SETC_113  113
#define  SETC_114  114
#define  SETC_115  115
#define  SETC_116  116
#define  SETC_117  117
#define  SETC_118  118
#define  SETC_119  119
#define  SETC_120  120
#define  SETC_121  121
#define  SETC_122  122
#define  SETC_123  123
#define  SETC_124  124
#define  SETC_125  125
#define  SETC_126  126
#define  SETC_127  127
#define  SET1          128
#define  SET2          129
#define  SET3          130
#define  SET4          131
#define  SET_RULE      132
#define  PUT1          133
#define  PUT2          134
#define  PUT3          135
#define  PUT4          136
#define  PUT_RULE      137
#define  NOP           138
#define  BOP           139
#define  EOP           140
#define  PUSH          141
#define  POP           142
#define  RIGHT1        143
#define  RIGHT2        144
#define  RIGHT3        145
#define  RIGHT4        146
#define  W0            147
#define  W1            148
#define  W2            149
#define  W3            150
#define  W4            151
#define  X0            152
#define  X1            153
#define  X2            154
#define  X3            155
#define  X4            156
#define  DOWN1         157
#define  DOWN2         158
#define  DOWN3         159
#define  DOWN4         160
#define  Y0            161
#define  Y1            162
#define  Y2            163
#define  Y3            164
#define  Y4            165
#define  Z0            166
#define  Z1            167
#define  Z2            168
#define  Z3            169
#define  Z4            170
#define  FONT_00    171
#define  FONT_01    172
#define  FONT_02    173
#define  FONT_03    174
#define  FONT_04    175
#define  FONT_05    176
#define  FONT_06    177
#define  FONT_07    178
#define  FONT_08    179
#define  FONT_09    180
#define  FONT_10    181
#define  FONT_11    182
#define  FONT_12    183
#define  FONT_13    184
#define  FONT_14    185
#define  FONT_15    186
#define  FONT_16    187
#define  FONT_17    188
#define  FONT_18    189
#define  FONT_19    190
#define  FONT_20    191
#define  FONT_21    192
#define  FONT_22    193
#define  FONT_23    194
#define  FONT_24    195
#define  FONT_25    196
#define  FONT_26    197
#define  FONT_27    198
#define  FONT_28    199
#define  FONT_29    200
#define  FONT_30    201
#define  FONT_31    202
#define  FONT_32    203
#define  FONT_33    204
#define  FONT_34    205
#define  FONT_35    206
#define  FONT_36    207
#define  FONT_37    208
#define  FONT_38    209
#define  FONT_39    210
#define  FONT_40    211
#define  FONT_41    212
#define  FONT_42    213
#define  FONT_43    214
#define  FONT_44    215
#define  FONT_45    216
#define  FONT_46    217
#define  FONT_47    218
#define  FONT_48    219
#define  FONT_49    220
#define  FONT_50    221
#define  FONT_51    222
#define  FONT_52    223
#define  FONT_53    224
#define  FONT_54    225
#define  FONT_55    226
#define  FONT_56    227
#define  FONT_57    228
#define  FONT_58    229
#define  FONT_59    230
#define  FONT_60    231
#define  FONT_61    232
#define  FONT_62    233
#define  FONT_63    234
#define  FNT1          235
#define  FNT2          236
#define  FNT3          237
#define  FNT4          238
#define  XXX1          239
#define  XXX2          240
#define  XXX3          241
#define  XXX4          242
#define  FNT_DEF1      243
#define  FNT_DEF2      244
#define  FNT_DEF3      245
#define  FNT_DEF4      246
#define  PRE           247
#define  POST          248
#define  POST_POST     249

#define  FIRSTPXLCHAR     0
#define  LASTPXLCHAR    127
#define  NPXLCHARS      128
#define  PXLID         1001
