/* We need this file, because there is no static version of libdl */
/* Copyright (C) 1991 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/* As a special exception, if you link this file with files
   compiled with GCC to produce an executable, this does not cause
   the resulting executable to be covered by the GNU General Public License.
   This exception does not however invalidate any other reasons why
   the executable file might be covered by the GNU General Public License.  */

#include "init_main.h"

/* dummy functions, which can be overwritten by the user */
/* They are called before and after __init_main();
    i.e. the static initialization */

#ifdef L_init_start
void INIT_START() {}
#endif 

#ifdef L_init_end
void INIT_END() {}
#endif


/* in case that there are no global constructors we need these dummies */

#ifdef L_ctor_list
ep_fp * __CTOR_LIST__ = 0;
#endif

#ifdef L_dtor_list
ep_fp * __DTOR_LIST__ = 0;
#endif

/* dymmy functions needed when using static and dynamic linking */

#ifdef l_dl 
#if defined( sun) && !defined( NO_DYNAMIC_LIBS)

#include <dlfcn.h>

void __eprintf ();		/* Defined in gnulib */

void *dlopen( char * path, int mode)
{
	__eprintf( "ERROR: dlopen must never be called.\n");
	abort();
}

char *dlerror()
{
	__eprintf( "ERROR: dlerror must never be called.\n");
	abort();
}

void *dlsym( void * handle, char * symbol)
{
	__eprintf( "ERROR: dlsym must never be called.\n");
	abort();
}

#endif
#endif /* L_dl */
