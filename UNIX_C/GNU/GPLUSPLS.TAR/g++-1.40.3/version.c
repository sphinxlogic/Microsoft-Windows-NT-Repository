char *version_string = "1.40.3 (based on GCC 1.40)";
