#define FONTPATH ".:/usr/local/lib/groff/font:/usr/local/lib/font:/usr/lib/font"
