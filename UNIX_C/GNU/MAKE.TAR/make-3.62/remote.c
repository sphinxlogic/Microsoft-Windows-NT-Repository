#ifdef	CUSTOMS
#include "remote-cstms.c"
#else	/* Not CUSTOMS.  */
#include "remote-stub.c"
#endif	/* CUSTOMS.  */
