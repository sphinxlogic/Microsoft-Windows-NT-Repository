/* Permuted index, with keywords in their context.
   Copyright (C) 1990 Free Software Foundation, Inc.
   Francois Pinard <pinard@iro.umontreal.ca>, 1990.
*/

#include <stdio.h>

char *version_string = "\nGNU ptx version 0.2\n";
char *copyright_line = "Copyright (C) 1991 Free Software Foundation, Inc.";


/* Prints the package name and version, and the short Copyright.  */

void
#ifndef __STDC__
print_version ()
#else
print_version (void)
#endif
{
  fprintf (stderr, "%s%s\n", version_string, copyright_line);
}


/* Prints a more detailed Copyright.  */

void
#ifndef __STDC__
print_copyright ()
#else
print_copyright (void)
#endif
{
  fprintf (stderr, "\
This program is free software; you can redistribute it and/or modify\n\
it under the terms of the GNU General Public License as published by\n\
the Free Software Foundation; either version 1, or (at your option)\n\
any later version.\n\
\n\
This program is distributed in the hope that it will be useful,\n\
but WITHOUT ANY WARRANTY; without even the implied warranty of\n\
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n\
GNU General Public License for more details.\n\
\n\
You should have received a copy of the GNU General Public License\n\
along with this program; if not, write to the Free Software\n\
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.\n\
\n");
}
