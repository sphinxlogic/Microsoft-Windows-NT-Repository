/* Permuted index, with keywords in their context.
   Copyright (C) 1990 Free Software Foundation, Inc.
   Francois Pinard <pinard@iro.umontreal.ca>, 1988.
*/


/* Some system dependant declarations.  */

#ifdef sparc
/* Sparc machines require word alignment for each OCCURS structure.  */
#define OCCURS_ALIGNMENT 4
#endif


/* ANSI vs non-ANSI compilers.  */

#ifndef __STDC__
#define const
#define volatile
#endif

#ifdef STDC_HEADERS
#include <stdlib.h>
#endif


/* GNU library prototypes.  */

#ifndef __STDC__
void *xmalloc ();
void *xrealloc ();
#else
void *xmalloc (int);
void *xrealloc (void *, int);
#endif


/* Local prototypes.  */

#ifndef __STDC__
void print_copyright ();
void print_version ();
#else
void print_copyright (void);
void print_version (void);
#endif
