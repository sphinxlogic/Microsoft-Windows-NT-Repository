/* Test class SortedCltn

	THIS SOFTWARE FITS THE DESCRIPTION IN THE U.S. COPYRIGHT ACT OF A
	"UNITED STATES GOVERNMENT WORK".  IT WAS WRITTEN AS A PART OF THE
	AUTHOR'S OFFICIAL DUTIES AS A GOVERNMENT EMPLOYEE.  THIS MEANS IT
	CANNOT BE COPYRIGHTED.  THIS SOFTWARE IS FREELY AVAILABLE TO THE
	PUBLIC FOR USE WITHOUT A COPYRIGHT NOTICE, AND THERE ARE NO
	RESTRICTIONS ON ITS USE, NOW OR SUBSEQUENTLY.

Author:
	K. E. Gorlen
	Bg. 12A, Rm. 2033
	Computer Systems Laboratory
	Division of Computer Research and Technology
	National Institutes of Health
	Bethesda, Maryland 20892
	Phone: (301) 496-1111
	uucp: uunet!nih-csl!keith
	Internet:keith@alw.nih.gov

Function:
	
Modification History:
	
$Log:	sortedcltn.c,v $
 * Revision 2.204  89/10/07  23:51:33  keith
 * Pre-release
 * 
 * Revision 2.203  89/08/08  14:51:40  keith
 * Pre-release
 * 
 * Revision 2.201  89/05/12  13:24:19  keith
 * Release for R2.0 Beta test.
 * 
 * Revision 2.200.1.1  89/05/11  22:25:24  keith
 * Update for R2.0.
 * 
 * Revision 2.200  89/04/24  17:35:42  keith
 * Base revision for R2.0.
 * 
 * Revision 2.121  89/02/26  22:22:24  keith
 * Base revision for C++ R1.2.1 compatible version.
 * 
 * Revision 2.2  89/02/08  14:05:02  ted
 * changed names from oops to nihcl
 * 
 * Revision 2.1  89/01/30  16:21:37  ted
 * Added calls to occurrencesOf() and remove().
 * 
 * Revision 2.0  88/03/29  13:28:21  keith
 * Version 2 Release 2
 * 
 * Revision 1.1  88/01/17  22:25:07  keith
 * Initial revision
 * 

*/
static char rcsid[] = "$Header: sortedcltn.c,v 2.204 89/10/07 23:51:33 keith Stab $";

#include "Point.h"
#include "SortedCltn.h"
#include "Set.h"

main()
{
	cout << "\nTest class SortedCltn\n";
	Point A(1,1);
	Point B(1,2);
	Point C(1,3);
	Point D(1,3);
	Point E(1,4);
	SortedCltn s(8);
	SortedCltn t(8);
	s.add(A);
	s.add(B);
	s.add(C);
	s.add(D);
	s.add(E);
	cout << "s = " << s << endl;
	t.add(E);
	t.add(D);
	t.add(C);
	t.add(B);
	t.add(A);
	cout << "s==t: " << (s==t) << endl;
	cout << form("s.occurrencesOf(D) = %d\n", s.occurrencesOf(D));
	t.remove(B);
	cout << "t after remove  = " << t << endl;
	Set st = s.asSet();
	cout << "s.asSet(): " << st << endl;
	cout << "st.asSortedCltn(): " << st.asSortedCltn() << endl;
}
