/* Test class ArrayOb

	THIS SOFTWARE FITS THE DESCRIPTION IN THE U.S. COPYRIGHT ACT OF A
	"UNITED STATES GOVERNMENT WORK".  IT WAS WRITTEN AS A PART OF THE
	AUTHOR'S OFFICIAL DUTIES AS A GOVERNMENT EMPLOYEE.  THIS MEANS IT
	CANNOT BE COPYRIGHTED.  THIS SOFTWARE IS FREELY AVAILABLE TO THE
	PUBLIC FOR USE WITHOUT A COPYRIGHT NOTICE, AND THERE ARE NO
	RESTRICTIONS ON ITS USE, NOW OR SUBSEQUENTLY.

Author:
	K. E. Gorlen
	Bg. 12A, Rm. 2033
	Computer Systems Laboratory
	Division of Computer Research and Technology
	National Institutes of Health
	Bethesda, Maryland 20892
	Phone: (301) 496-1111
	uucp: uunet!nih-csl!keith
	Internet:keith@alw.nih.gov

Function:
	
Modification History:
	
$Log:	array.c,v $
 * Revision 2.204  89/10/07  23:49:42  keith
 * Pre-release
 * 
 * Revision 2.203  89/08/08  14:50:39  keith
 * Pre-release
 * 
 * Revision 2.201  89/05/12  13:20:22  keith
 * Release for R2.0 Beta test.
 * 
 * Revision 2.200.1.1  89/05/11  22:23:31  keith
 * Update for R2.0.
 * 
 * Revision 2.200  89/04/24  17:31:54  keith
 * Base revision for R2.0.
 * 
 * Revision 2.121  89/02/26  22:19:14  keith
 * Base revision for C++ R1.2.1 compatible version.
 * 
 * Revision 2.2  89/02/08  14:03:52  ted
 * changed names from oops to nihcl
 * 
 * Revision 2.1  88/05/30  09:47:34  keith
 * Update for new dumpOn()/printOn() format.
 * 
 * Revision 2.0  88/03/29  13:25:36  keith
 * Version 2 Release 2
 * 
 * Revision 1.1  88/01/17  22:24:20  keith
 * Initial revision
 * 

*/
static char rcsid[] = "$Header: array.c,v 2.204 89/10/07 23:49:42 keith Stab $";

#include "Point.h"
#include "Rectangle.h"
#include "ArrayOb.h"

main()
{
	cout << "\nTest class ArrayOb\n";
	Point A(1,2);
	Point B(3,4); 
	Rectangle a(0,0,10,10);
	Rectangle b(1,2,1,2);
	ArrayOb v(10);
	ArrayOb t(2),u(2);
	v[0] = &a;
	v[1] = &A;
	v[2] = new Point(0,1);
	cout << v << endl;
	t[0] = &a; t[1] = &A;
	u = t;
	cout << "t = " << t << endl;
	cout << "t == u: " << (t==u) << endl;
	cout << "t isEqual u: " << t.isEqual(u) << endl;
	cout << "t isEqual v: " << t.isEqual(v) << endl;
}
