/* Test class Range

	THIS SOFTWARE FITS THE DESCRIPTION IN THE U.S. COPYRIGHT ACT OF A
	"UNITED STATES GOVERNMENT WORK".  IT WAS WRITTEN AS A PART OF THE
	AUTHOR'S OFFICIAL DUTIES AS A GOVERNMENT EMPLOYEE.  THIS MEANS IT
	CANNOT BE COPYRIGHTED.  THIS SOFTWARE IS FREELY AVAILABLE TO THE
	PUBLIC FOR USE WITHOUT A COPYRIGHT NOTICE, AND THERE ARE NO
	RESTRICTIONS ON ITS USE, NOW OR SUBSEQUENTLY.

Author:
	K. E. Gorlen
	Bg. 12A, Rm. 2033
	Computer Systems Laboratory
	Division of Computer Research and Technology
	National Institutes of Health
	Bethesda, Maryland 20892
	Phone: (301) 496-1111
	uucp: uunet!nih-csl!keith
	Internet:keith@alw.nih.gov

Function:
	
Modification History:
	
$Log:	range.c,v $
 * Revision 2.204  89/10/07  23:51:18  keith
 * Pre-release
 * 
 * Revision 2.203  89/08/08  14:51:34  keith
 * Pre-release
 * 
 * Revision 2.201  89/05/12  13:23:40  keith
 * Release for R2.0 Beta test.
 * 
 * Revision 2.200.1.1  89/05/11  22:25:14  keith
 * Update for R2.0.
 * 
 * Revision 2.200  89/04/24  17:35:15  keith
 * Base revision for R2.0.
 * 
 * Revision 2.121  89/02/26  22:21:56  keith
 * Base revision for C++ R1.2.1 compatible version.
 * 
 * Revision 2.1  89/02/08  14:04:54  ted
 * changed names from oops to nihcl
 * 
 * Revision 2.0  88/03/29  13:27:53  keith
 * Version 2 Release 2
 * 
 * Revision 1.1  88/01/17  22:25:00  keith
 * Initial revision
 * 

*/
static char rcsid[] = "$Header: range.c,v 2.204 89/10/07 23:51:18 keith Stab $";

#include "Range.h"

main()
{
	Range a;
	a.firstIndex(0);  a.lastIndex(1);
	cout << a << endl;
	Range b(3,14);
	cout << "firstIndex(): " << b.firstIndex() << " lastIndex(): " << b.lastIndex() << " length(): " << b.length() << endl;
	cout << a << endl;
	cout << b << endl;
	a=b;
	cout << a << endl;
}
