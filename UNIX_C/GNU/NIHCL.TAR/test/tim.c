/* Test class Time

	THIS SOFTWARE FITS THE DESCRIPTION IN THE U.S. COPYRIGHT ACT OF A
	"UNITED STATES GOVERNMENT WORK".  IT WAS WRITTEN AS A PART OF THE
	AUTHOR'S OFFICIAL DUTIES AS A GOVERNMENT EMPLOYEE.  THIS MEANS IT
	CANNOT BE COPYRIGHTED.  THIS SOFTWARE IS FREELY AVAILABLE TO THE
	PUBLIC FOR USE WITHOUT A COPYRIGHT NOTICE, AND THERE ARE NO
	RESTRICTIONS ON ITS USE, NOW OR SUBSEQUENTLY.

Author:
	K. E. Gorlen
	Bg. 12A, Rm. 2033
	Computer Systems Laboratory
	Division of Computer Research and Technology
	National Institutes of Health
	Bethesda, Maryland 20892
	Phone: (301) 496-1111
	uucp: uunet!nih-csl!keith
	Internet:keith@alw.nih.gov

Function:
	
Modification History:
	
$Log:	tim.c,v $
 * Revision 2.204  89/10/07  23:51:49  keith
 * Pre-release
 * 
 * Revision 2.203  89/08/08  14:51:50  keith
 * Pre-release
 * 
 * Revision 2.201  89/05/12  13:24:58  keith
 * Release for R2.0 Beta test.
 * 
 * Revision 2.200.1.1  89/05/11  22:25:37  keith
 * Update for R2.0.
 * 
 * Revision 2.200  89/04/24  17:36:24  keith
 * Base revision for R2.0.
 * 
 * Revision 2.121  89/02/26  22:22:54  keith
 * Base revision for C++ R1.2.1 compatible version.
 * 
 * Revision 2.2  89/02/08  14:05:13  ted
 * changed names from oops to nihcl
 * 
 * Revision 2.1  88/05/30  09:50:04  keith
 * Update for new dumpOn()/printOn() format.
 * 
 * Revision 2.0  88/03/29  13:28:44  keith
 * Version 2 Release 2
 * 
 * Revision 1.1  88/01/17  22:25:14  keith
 * Initial revision
 * 

*/
static char rcsid[] = "$Header: tim.c,v 2.204 89/10/07 23:51:49 keith Stab $";

#include "Date.h"
#include "Time.h"
#include "SortedCltn.h"

main()
{
	cout << "\nTest class Time\n";
	Time now;
	int hr,mn,sc;
	char junk[512];
	SortedCltn timelist;
	cerr << "It is now " << now << endl;
	while (YES) {
		cout << "Enter date and time: ";
		Date& date = *new Date(cin);
		if (cin.eof()) break;
		if (cin.fail()) {
			cout << "Bad date\n";
			cin.clear();  cin >> junk;
			continue;
		}
		cin >> hr >> mn >> sc;
		cout << endl;
		if (cin.eof()) break;
		if (cin.fail()) {
			cout << "Bad time\n";
			cin.clear();  cin.get(junk,sizeof junk);
			continue;
		}
		Time& time = *new Time(date,hr,mn,sc);
		timelist.add(time);
		cout << time << endl;
	}
	cout << endl << timelist << endl;
}
