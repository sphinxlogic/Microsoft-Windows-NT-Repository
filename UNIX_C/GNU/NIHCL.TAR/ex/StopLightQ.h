#ifndef STOPLIGHTQ_H
#define STOPLIGHTQ_H

// $Header: StopLightQ.h,v 2.204 89/10/08 14:39:21 keith Stab $

// StopLightQ.h -- Stop Light Vehicle Queue LinkedList

#ifndef MI
#define MI
#endif

#include "VehicleQ.h"

class LandVhcl;

class StopLightQ: public VehicleQ {
    DECLARE_MEMBERS(StopLightQ);
#ifndef BUG_38
// internal <<AT&T C++ Translator 2.00 06/30/89>> error: bus error (or something nasty like that)
protected:              // storer() functions for object I/O
    virtual void storer(OIOofd& fd) const   { VehicleQ::storer(fd); };
    virtual void storer(OIOout& strm) const { VehicleQ::storer(strm); };
#endif
public:
    StopLightQ() {}
    virtual void addVehicle(LandVhcl&);
};

#endif
