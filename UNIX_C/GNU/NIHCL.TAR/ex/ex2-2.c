/* ex2-2.c -- Add multiple-precision integers using mp library */

/*$Header: ex2-2.c,v 2.204 89/10/08 14:41:07 keith Stab $*/

#include <mp.h>

MINT* dtom(d)
char *d;
{
    MINT *t, *ten;
    t = itom(0);
    ten = itom(10);
    while (*d) {
        MINT *u;
        u = itom(*d++ - '0');
        mult(t,ten,t);
        madd(t,u,t);
        mfree(u);
    }
    mfree(ten);
    return t;
}

main()
{
    MINT *a, *b, *c, *t;
    a = dtom("25123654789456");
    b = dtom("456023398798362");
    c = itom(0);
    t = itom(47);
    madd(a,b,c);
    madd(c,t,c);
    mout(c);
    printf("\n");
    mfree(a); mfree(b); mfree(c); mfree(t);
}
