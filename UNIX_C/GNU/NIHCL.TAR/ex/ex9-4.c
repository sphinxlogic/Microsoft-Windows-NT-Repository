// ex9-4.c -- Virtual inline function calls

// $Header: ex9-4.c,v 2.204 89/10/08 14:43:14 keith Stab $

class X {
    int n;
public:
    X(int i=0)          { n = i; }
    virtual void inc()  { n++; }
};

main()
{
    X x;
    X* xp = new X;
// virtual function with scope resolution applied
// to class instance
    x.X::inc();
// virtual function with scope resolution applied
// through pointer to class instance
    xp->X::inc();
// virtual function applied to class instance
    x.inc();
// virtual function applied through pointer to class instance
    xp->inc();
}
