// ex8-13.c -- Comparison of classes Set and IdentSet

// $Header: ex8-13.c,v 2.204 89/10/08 14:42:25 keith Stab $

#include "Set.h"
#include "IdentSet.h"
#include "String.h"
#include "SortedCltn.h"

main()
{
    String s1 = "A String";
    String s2 = "A String";
    String s3 = "Another String";

    Set s;
    s.add(s1); s.add(s2); s.add(s3); s.add(s3);
    cout << "Set:\n";
    cout << s.asSortedCltn() << endl;

    IdentSet i;
    i.add(s1); i.add(s2); i.add(s3); i.add(s3);
    cout << "\nIdentSet:\n";
    cout << i.asSortedCltn() << endl;
}
