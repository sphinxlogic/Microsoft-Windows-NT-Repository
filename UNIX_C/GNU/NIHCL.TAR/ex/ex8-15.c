// ex8-15.c -- Comparison of classes Dictionary and IdentDict

// $Header: ex8-15.c,v 2.204 89/10/08 14:42:31 keith Stab $

#include "Dictionary.h"
#include "IdentDict.h"
#include "LookupKey.h"
#include "String.h"
#include "SortedCltn.h"

main()
{
    String s1 = "A String";

    Dictionary d;
    d.addAssoc(s1,*new String("value associated with s1"));
    cout << "Dictionary:" << endl;
    LookupKey* lk = d.assocAt(String("A String"));
    if (lk) cout << *lk->value() << endl;
    else cout << "Not found" << endl;
    lk = d.assocAt(s1);
    if (lk) cout << *lk->value() << endl;
    else cout << "Not found" << endl;
    cout << endl;

    IdentDict i;
    i.addAssoc(s1,*new String("value associated with s1"));
    cout << "IdentDict:" << endl;
    lk = i.assocAt(String("A String"));
    if (lk) cout << *lk->value() << endl;
    else cout << "Not found" << endl;
    lk = i.assocAt(s1);
    if (lk) cout << *lk->value() << endl;
    else cout << "Not found" << endl;
}
