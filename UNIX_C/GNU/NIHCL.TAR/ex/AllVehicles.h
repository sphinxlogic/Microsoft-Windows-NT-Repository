#ifndef ALLVEHICLES_H
#define ALLVEHICLES_H

// $Header: AllVehicles.h,v 2.204 89/10/08 14:38:27 keith Stab $

// AllVehicles.h -- LinkedList of all Vehicles

#ifndef MI
#define MI
#endif

#include "LinkedList.h"

class AllLink;
class Iterator;

class AllVehicles: public LinkedList {
    DECLARE_MEMBERS(AllVehicles);
#ifndef BUG_38
// internal <<AT&T C++ Translator 2.00 06/30/89>> error: bus error (or something nasty like that)
protected:              // storer() functions for object I/O
    virtual void storer(OIOofd& fd) const   { LinkedList::storer(fd); };
    virtual void storer(OIOout& strm) const { LinkedList::storer(strm); };
#endif
protected:
    virtual Link& linkCastdown(Object&) const;
public:
    AllVehicles() {}
    virtual void addVehicle(AllLink&);
    virtual void removeVehicle(AllLink&);
};

#endif
