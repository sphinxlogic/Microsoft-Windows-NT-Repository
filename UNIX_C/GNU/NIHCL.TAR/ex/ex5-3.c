// ex5-3.c -- Writing a BigInt to the standard output

// $Header: ex5-3.c,v 2.204 89/10/08 14:41:25 keith Stab $

#include <iostream.h>
#include "BigInt.h"

main()
{
    BigInt b= "1234567890";
    cout << "The BigInt is " << b << endl;
}
