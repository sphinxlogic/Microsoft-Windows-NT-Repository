// DrawBridgeQ.c -- Stop Light Vehicle Queue LinkedList

#include "DrawBridgeQ.h"
#include "WaterVhcl.h"
#include "nihclIO.h"

#define THIS    DrawBridgeQ
#define BASE    VehicleQ
#define BASE_CLASSES BASE::desc()
#define MEMBER_CLASSES
#define VIRTUAL_BASE_CLASSES

DEFINE_CLASS(DrawBridgeQ,1,"$Header: DrawBridgeQ.c,v 2.204 89/10/08 14:38:48 keith Stab $",NULL,NULL);

void DrawBridgeQ::addVehicle(WaterVhcl& l)    { BASE::addVehicle(l); }

DrawBridgeQ::DrawBridgeQ(OIOin& strm) : BASE(strm) {}

DrawBridgeQ::DrawBridgeQ(OIOifd& fd) : BASE(fd) {}
