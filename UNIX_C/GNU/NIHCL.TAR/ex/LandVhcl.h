#ifndef LANDVHCL_H
#define LANDVHCL_H

// $Header: LandVhcl.h,v 2.204 89/10/08 14:38:55 keith Stab $

#ifndef MI
#define MI
#endif

#include "Vehicle.h"

class LandVhcl: public virtual Vehicle {
    DECLARE_MEMBERS(LandVhcl);
    unsigned axles;
protected:      // storer() functions for object I/O
    virtual void storer(OIOofd&) const;
    virtual void storer(OIOout&) const;
    virtual void _printOn(ostream& strm =cout) const;
public:
    LandVhcl(float h, float l, unsigned a =2) : Vehicle(h,l) { axles = a; }
    virtual void deepenShallowCopy();
};

#endif
