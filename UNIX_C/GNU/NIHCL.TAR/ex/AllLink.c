// AllLink.c -- Link used by AllVehicles LinkedList

#include "AllLink.h"
#include "nihclIO.h"

#define THIS    AllLink
#define BASE    Link
#define BASE_CLASSES BASE::desc()
#define MEMBER_CLASSES
#define VIRTUAL_BASE_CLASSES

DEFINE_ABSTRACT_CLASS(AllLink,1,"$Header: AllLink.c,v 2.204 89/10/08 14:38:22 keith Stab $",NULL,NULL);

AllLink::AllLink(OIOin& strm) : BASE(strm) {}

AllLink::AllLink(OIOifd& fd) : BASE(fd) {}
