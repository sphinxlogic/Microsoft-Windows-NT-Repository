// ex8-3.c -- Nested Iterators

// $Header: ex8-3.c,v 2.204 89/10/08 14:42:42 keith Stab $

#include "OrderedCltn.h"
#include "Iterator.h"
#include "String.h"

void printPairs(const Collection& c1, const Collection& c2)
{
    Iterator it1(c1), it2(c2);

    while(it1++) {
        while (it2++) {
            cout << '[' << *it1() << ',' << *it2() << "]  ";
        }
        cout << endl;
        it2.reset();
    }
}

main()
{
    OrderedCltn symbols;
    symbols.add(*new String("A"));
    symbols.add(*new String("C"));
    symbols.add(*new String("G"));
    symbols.add(*new String("T"));
    printPairs(symbols,symbols);
}
