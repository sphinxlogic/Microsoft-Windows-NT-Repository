#ifndef DRAWBRIDGEQ_H
#define DRAWBRIDGEQ_H

// $Header: DrawBridgeQ.h,v 2.204 89/10/08 14:38:50 keith Stab $

// DrawBridgeQ.h -- Draw Bridge Vehicle Queue LinkedList

#ifndef MI
#define MI
#endif

#include "VehicleQ.h"

class WaterVhcl;

class DrawBridgeQ: public VehicleQ {
    DECLARE_MEMBERS(DrawBridgeQ);
#ifndef BUG_38
// internal <<AT&T C++ Translator 2.00 06/30/89>> error: bus error (or something nasty like that)
protected:              // storer() functions for object I/O
    virtual void storer(OIOofd& fd) const   { VehicleQ::storer(fd); };
    virtual void storer(OIOout& strm) const { VehicleQ::storer(strm); };
#endif
public:
    DrawBridgeQ() {}
    virtual void addVehicle(WaterVhcl&);
};

#endif
