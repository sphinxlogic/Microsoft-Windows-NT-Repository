// ex5-4.c -- Extending stream I/O for class BigInt

// $Header: ex5-4.c,v 2.204 89/10/08 14:41:27 keith Stab $

#include "BigInt.h"
#include <osfcn.h>

main()
{
    BigInt a,b;
    while ( cin.good() ) {
        cout << "Enter a: "; cin >> a;
        if (cin.fail()) break;
        cout << "Enter b: "; cin >> b;
        if (cin.fail()) break;
        cout << "a+b=" << (a+b) << endl;
    }
}
