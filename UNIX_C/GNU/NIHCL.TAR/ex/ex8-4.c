// ex8-4.c -- Incorrectly modifying a container during iteration

// $Header: ex8-4.c,v 2.204 89/10/08 14:42:45 keith Stab $

#include "OrderedCltn.h"
#include "Iterator.h"
#include "String.h"

main()
{
    OrderedCltn symbols;
    symbols.add(*new String("A"));
    symbols.add(*new String("C"));
    symbols.add(*new String("G"));
    symbols.add(*new String("T"));

    Iterator it(symbols);
    while (it++)
        if (it()->compare(String("G")) < 0) symbols.remove(*it());

    cout << symbols << endl;
}
