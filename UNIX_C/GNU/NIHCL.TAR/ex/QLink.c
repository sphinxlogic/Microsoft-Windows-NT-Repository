// QLink.c -- Link used by AllVehicles LinkedList

#include "QLink.h"
#include "nihclIO.h"

#define THIS    QLink
#define BASE    Link
#define BASE_CLASSES BASE::desc()
#define MEMBER_CLASSES
#define VIRTUAL_BASE_CLASSES

DEFINE_ABSTRACT_CLASS(QLink,1,"$Header: QLink.c,v 2.204 89/10/08 14:39:13 keith Stab $",NULL,NULL);

QLink::QLink(OIOin& strm) : BASE(strm) {}

QLink::QLink(OIOifd& fd) : BASE(fd) {}
