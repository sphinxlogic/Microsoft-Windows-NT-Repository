// ex8-11.c -- Test if date falls on a weekday

// $Header: ex8-11.c,v 2.204 89/10/08 14:42:19 keith Stab $

#include "Date.h"
#include "Set.h"
#include "String.h"
#include <osfcn.h>

main ()
{
    Set weekdays;       // Set of weekday names
    String mon = "Monday", tue = "Tuesday", wed = "Wednesday",
        thu = "Thursday", fri = "Friday";
    weekdays.add(mon);  weekdays.add(tue);  weekdays.add(wed);
        weekdays.add(thu);  weekdays.add(fri);

    Date date;
    while (YES) {
        cout << "Enter date: ";  cin >> date;
        if (cin.eof()) exit(0);
// Convert date to String containing name of day and search Set for match
        if (weekdays.includes(String(Date::nameOfDay(date.weekDay()))))
            cout << date << " is a weekday" << endl;
        else
            cout << date << " is not a weekday" << endl;
    }
}
