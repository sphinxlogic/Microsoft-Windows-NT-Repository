// ex8-1.c -- Description of a Patient object

// $Header: ex8-1.c,v 2.204 89/10/08 14:42:13 keith Stab $

#include "Patient.h"

main()
{
    Patient aPatient("Doe, John","000-00-0000",12345);

    cout << "Class[" << aPatient.className() << "] "
         << "ByteSize[" << sizeof(aPatient) << "]" << endl;
    aPatient.dumpOn(cout);
}
