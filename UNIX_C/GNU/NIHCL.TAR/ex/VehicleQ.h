#ifndef VEHICLEQ_H
#define VEHICLEQ_H

// $Header: VehicleQ.h,v 2.204 89/10/08 14:39:27 keith Stab $

// VehicleQ.h -- Vehicle Queue LinkedList

#ifndef MI
#define MI
#endif

#include "LinkedList.h"

class QLink;
class Iterator;

class VehicleQ: public LinkedList {
    DECLARE_MEMBERS(VehicleQ);
#ifndef BUG_38
// internal <<AT&T C++ Translator 2.00 06/30/89>> error: bus error (or something nasty like that)
protected:              // storer() functions for object I/O
    virtual void storer(OIOofd& fd) const   { LinkedList::storer(fd); };
    virtual void storer(OIOout& strm) const { LinkedList::storer(strm); };
#endif
protected:
    virtual Link& linkCastdown(Object&) const;
public:
    VehicleQ() {}
    virtual void addVehicle(QLink&);
    virtual void removeVehicle(QLink&);
};

#endif
