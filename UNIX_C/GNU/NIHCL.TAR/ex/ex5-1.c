// ex5-1.c -- Writing to the standard output stream

// $Header: ex5-1.c,v 2.204 89/10/08 14:41:13 keith Stab $

#include <iostream.h>

main()
{
    float x = 1.2;
    int i = 3;
    char* prog = "myprogram";

    cout << prog;
    cout << ":";
    cout << endl;

    cout << "at step " << i << ", x = " << x << endl;
}
