// ex8-7.c -- sorting Patient records by name

// $Header: ex8-7.c,v 2.204 89/10/08 14:42:53 keith Stab $

#include "SortedCltn.h"
#include "String.h"

#include "Patient.h"

main()
{
    SortedCltn cltn;
    cltn.add(*new Patient("Smith John A.","111-22-3333",22222));
    cltn.add(*new Patient("Fried Harry I.","123-45-6789",22221));
    cltn.add(*new Patient("Chavez Maria G.","444-555-6666",22223));

    cout << cltn << endl;
}
