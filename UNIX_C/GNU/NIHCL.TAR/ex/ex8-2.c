// ex8-2.c -- Use of an Iterator with container for objects of unknown class

// $Header: ex8-2.c,v 2.204 89/10/08 14:42:39 keith Stab $

#include "OrderedCltn.h"
#include "Iterator.h"
#include "String.h"

void listContainer(ostream& strm,Collection& cltn)
{
// Iterator knows neither
//  the actual class of cltn nor    
//  the actual class of any Object in cltn
    Iterator it(cltn);    
    while (it++) strm << *it() << " ";    
}

main()
{
    OrderedCltn symbols;
    symbols.add(*new String("A"));
    symbols.add(*new String("C"));
    symbols.add(*new String("G"));
    symbols.add(*new String("T"));

    listContainer(cout,symbols);
    cout << endl;
}
