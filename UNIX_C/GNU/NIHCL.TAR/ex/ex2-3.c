// ex2-3.c -- Add instances of class BigInt

// $Header: ex2-3.c,v 2.204 89/10/08 14:41:10 keith Stab $

#include "BigInt.h"

main()
{
    BigInt a =  "25123654789456";
    BigInt b = "456023398798362";
    BigInt c;
    c = a + b + 47;
    c.print();  printf("\n");
}
