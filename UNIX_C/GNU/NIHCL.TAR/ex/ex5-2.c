// ex5-2.c -- Reading from the standard input

// $Header: ex5-2.c,v 2.204 89/10/08 14:41:22 keith Stab $

#include <iostream.h>

main()
{
    float x;
    int i;
    char* prompt = "Enter [float int]?";

    cout << prompt << flush;
    cin >> x >> i;

    cout << "x=" << x << " i=" << i << endl;
}
