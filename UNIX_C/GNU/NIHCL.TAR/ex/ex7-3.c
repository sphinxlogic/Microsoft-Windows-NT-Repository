// ex7-3.c -- Object I/O readFrom()

// $Header: ex7-3.c,v 2.204 89/10/08 14:42:10 keith Stab $

#include <fstream.h>
#include <osfcn.h>
#include "Point.h"
#include "Line.h"
#include "Circle.h"
#include "Picture.h"
#include "OIOnih.h"

main()
{
    ifstream in("picturefile");
    if (in.fail()) {
        cerr << "Failed to open picturefile\n";
        exit(1);
    }
    Picture* bigPic = Picture::readFrom(OIOnihin(in));
    bigPic->draw();
}
