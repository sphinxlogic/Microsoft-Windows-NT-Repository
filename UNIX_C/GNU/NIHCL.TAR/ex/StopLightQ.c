// StopLightQ.c -- Stop Light Vehicle Queue LinkedList

#include "StopLightQ.h"
#include "LandVhcl.h"
#include "nihclIO.h"

#define THIS    StopLightQ
#define BASE    VehicleQ
#define BASE_CLASSES BASE::desc()
#define MEMBER_CLASSES
#define VIRTUAL_BASE_CLASSES

DEFINE_CLASS(StopLightQ,1,"$Header: StopLightQ.c,v 2.204 89/10/08 14:39:19 keith Stab $",NULL,NULL);

void StopLightQ::addVehicle(LandVhcl& l)    { BASE::addVehicle(l); }

StopLightQ::StopLightQ(OIOin& strm) : BASE(strm) {}

StopLightQ::StopLightQ(OIOifd& fd) : BASE(fd) {}
