/* ex2-1.c -- Add ints */

/*$Header: ex2-1.c,v 2.204 89/10/08 14:41:01 keith Stab $*/

main()
{
    int a = 193;
    int b = 456;
    int c;
    c = a + b + 47;
    printf("%d\n",c);
}
