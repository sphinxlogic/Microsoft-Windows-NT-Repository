// ex13-3.c -- Virtual functions and multiple inheritance

// $Header: ex13-3.c,v 2.204 89/10/08 14:40:30 keith Stab $

#include <iostream.h>

class A {
public:
    virtual void f()    { cout << "A::f()" << endl; }
};

class B {
public:
    virtual void f()    { cout << "B::f()" << endl; }
};

class C: public A, public B {
public:
    virtual void f()    { cout << "C::f()" << endl; }
};

main()
{
    A* pa = new C;
    B* pb = new C;
    C* pc = new C;
    pa->f();        // calls C::f()
    pb->f();        // calls C::f()
    pc->f();        // calls C::f()
}
