#ifndef ALLLINK_H
#define ALLLINK_H

// $Header: AllLink.h,v 2.204 89/10/08 14:38:24 keith Stab $

// AllLink.h -- Link used by AllVehicles LinkedList

#ifndef MI
#define MI
#endif

#include "Link.h"

class AllLink: public Link {
    DECLARE_MEMBERS(AllLink);
protected:
    AllLink() {};
public:
    virtual int compare(const Object&) const = 0;
    virtual unsigned hash() const = 0;
    virtual bool isEqual(const Object&) const = 0;
    virtual void printOn(ostream& strm =cout) const = 0;
};

#endif
