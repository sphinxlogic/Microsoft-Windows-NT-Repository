#ifndef WATERVHCL_H
#define WATERVHCL_H

// $Header: WaterVhcl.h,v 2.204 89/10/08 14:39:29 keith Stab $

#ifndef MI
#define MI
#endif

#include "Vehicle.h"

class WaterVhcl: public virtual Vehicle {
    DECLARE_MEMBERS(WaterVhcl);
    float draft;
protected:      // storer() functions for object I/O
    virtual void storer(OIOofd&) const;
    virtual void storer(OIOout&) const;
    virtual void _printOn(ostream& strm =cout) const;
public:
    WaterVhcl(float h, float l, float d) : Vehicle(h,l) { draft = d; }
    virtual void deepenShallowCopy();
};

#endif
