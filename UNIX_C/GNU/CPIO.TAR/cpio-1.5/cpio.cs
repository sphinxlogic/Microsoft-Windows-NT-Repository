(-W1 -Za -Od -Olt -I.
-DSTDC_HEADERS -DNO_MTIO -DNO_REMOTE
main.c     {cpio.h dstring.h extern.h rmt.h}
copyin.c   {cpio.h dstring.h extern.h filetypes.h fnmatch.h rmt.h}
copyout.c  {cpio.h dstring.h extern.h filetypes.h rmt.h}
copypass.c {cpio.h dstring.h extern.h filetypes.h}
global.c   {cpio.h dstring.h}
util.c     {extern.h rmt.h}
dstring.c  {dstring.h}
error.c filemode.c version.c
fnmatch.c getopt.c getopt1.c
xmalloc.c xstrdup.c dirname.c makepath.c bcopy.c
)
binmode.obj
cpio.exe
cpio.def
-AS -LB -S0x4000
