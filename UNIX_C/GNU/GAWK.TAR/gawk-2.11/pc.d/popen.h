/*
** popen.h -- prototypes for pipe functions
*/
#if !defined(FILE)
#include <stdio.h>
#endif
extern FILE *popen( char *, char * );

