 /*
  * 5620mstty Gernot Heiser (heiser@iis.uucp) 1988-07-16
  *
  * Fix terminal in a mux layer. Do an `stty crt echo' afterwards for the usual
  * tty settings.
  */

#include <sys/ioctl.h>
#include <sys/jioctl.h>

main ()
{
   int x = 0;
   return ioctl (0, JIOCTL, &x) < 0;
}
