/*
 * 5620_mouse - A layers program able to send mouse coordinates but otherwise
 *              behaving like a normal layer
 *
 * Version 2.2
 *
 * Public domain software.
 * Written by Gernot Heiser (heiser@ethz.uucp) in April 1987
 * based on the vt100 terminal emulator by Leif Samuelsson
 *    as modified by Peter Lamb
 * History :
 *   Version 1.3, Gernot Heiser, Stefan Zeiger, July 1987:
 *      selection feedback
 *   Version 1.4, Gernot Heiser, August 1987:
 *      different selection kinds; special ESC-sequence for selection
 *   Version 1.5, Gernot Heiser, September 1987:
 *      define characteristics of layers to clone in startup file
 *      ensure mouse coordinates are sent "as seen"
 *      box cursor when layer is inactive
 *   Version 1.6, Gernot Heiser, September 1987:
 *      scroll bars
 *   Version 2.1, Gernot Heiser, 1988-05-29:
 *      fixed several problems with mux version
 *   Version 2.2, Gernot Heiser, 1988-07-13:
 *      small fixes
 */

/* 5620 menu stuff */

#include "5620.h"

#define CLONE 0
#define INVERT 1
#define RESET 2
#if FALSE
#define SENDSN 3
#define EXIT 4
#else /* ! FALSE */
#define EXIT 3
#endif /* ! FALSE */

char Clone[]   = "clone";
char Invert[]  = "invert";
char Reset[]   = "reset";
char Send[]    = "send";
char Exit[]    = "exit";

init_menu(t)
register struct tstat *t;
{
	menu.item   = menustrs;
	menu.prevhit = menu.prevtop = 0;
	menu.generator = 0;
	menustrs[CLONE]  = Clone;
	menustrs[INVERT] = Invert;
#ifdef MUX
	menustrs[RESET]  = Reset;
#if FALSE
        menustrs[SENDSN] = Send;
#endif /* FALSE */
        menustrs[EXIT]   = Exit;
#else
	menustrs[RESET]  = 0;
        menustrs[EXIT]   = 0;
#endif
        menustrs[NMENU]  = 0;
}

do_menu(t, n)
register struct tstat *t;
{
	extern void clone_0();

	switch(menuhit(&menu, n)) {
	case CLONE:
		if (!cloned)
			((char **)P->text)[-1] = 0;
		clone_info = *t;
		newwindow (clone_0);
		break;
	case INVERT:
		inverse_vid (t, clr == F_CLR);
		break;
        case RESET:
                do_reset (t);
		break;
#if FALSE
#ifdef MUX
        case SENDSN:
                send_snarf (t);
		break;
#endif /* MUX */
#endif /* FALSE */
	case EXIT:
		exit ();
		break;
	}
}
