/*
 * 5620_mouse - A layers program able to send mouse coordinates but otherwise
 *              behaving like a normal layer
 *
 * Version 2.1
 *
 * Public domain software.
 * Written by Gernot Heiser (heiser@ethz.uucp) in April 1987
 * based on the vt100 terminal emulator by Leif Samuelsson
 *    as modified by Peter Lamb
 * History :
 *   Version 1.3, Gernot Heiser, Stefan Zeiger, July 1987:
 *      selection feedback
 *   Version 1.4, Gernot Heiser, August 1987:
 *      different selection kinds; special ESC-sequence for selection
 *   Version 1.5, Gernot Heiser, September 1987:
 *      define characteristics of layers to clone in startup file
 *      ensure mouse coordinates are sent "as seen"
 *      box cursor when layer is inactive
 *   Version 1.6, Gernot Heiser, September 1987:
 *      scroll bars
 *   Version 1.9, Gernot Heiser, 1988-02-02:
 *      test for valid parameters in scroll_region
 *   Version 2.0, Gernot Heiser, 1988-02-27:
 *      adapted to mux
 *   Version 2.1, Gernot Heiser, 1988-05-29:
 *      fixed several problems with mux version
 */


/* This module contains termcap and tty routines */

#include "5620.h"

#ifdef MUX

Texture T_grey = {
	0xaaaa, 0xffff, 0xaaaa, 0xffff, 0xaaaa, 0xffff, 0xaaaa, 0xffff,
	0xaaaa, 0xffff, 0xaaaa, 0xffff, 0xaaaa, 0xffff, 0xaaaa, 0xffff
};
#endif

#define rowy(r)		(Trect.origin.y + (r) * charheight)
#define colx(c)		(Trect.origin.x + (c) * charwidth)

   /* bitmaps for selection feedback patterns */
static struct Bitmap feedback_bm [nbr_patterns+1]; /* note: [0] unused! */

extern
void init_term(t)
register struct tstat *t;
{
#define WordsPerLine ((XMAX-1) / WORDSIZE + 1)
#define RowsPerLine  20    /* >= charheight */

   /* bitmap storage for selection feedback patterns */
   static Word feedback_bm_storage [nbr_patterns][RowsPerLine][WordsPerLine];

   int bm, r, i;

   clr = F_CLR; or = F_OR;
#ifdef MUX
   charwidth  = P->defaultfont->info['0'].width;
   charheight = P->defaultfont->height;
#else
   charwidth  = defont.info['A'+1].x - defont.info['A'].x;
   charheight = defont.height + 2;
#endif


   if (cloned)
      return;

   /* init selection feedback bitmap storage.
      The first two rows of copy and move bitmaps as well as the last
      two rows of the delete and copy bitmap are to be filled with the
      ragged pattern (already contained in the first row of the copy bitmap.
      All the other rows are to be initialized with all ones bits. */

#define ragged_pat  0xF0F0F0F0
#define solid_pat   0xFFFFFFFF
#define ragged_rows 3
   
   if (charheight > RowsPerLine) {      /* feedback bitmap too small */
      exit();
   }

   for (bm = select; bm <= nbr_patterns; bm++) {
      for (r = 0; r < charheight; r++) {
	 for (i=0; i < WordsPerLine; i++) {
	    if (bm==copy    &&  r <  ragged_rows ||
		bm==delete  &&  r >= charheight-ragged_rows) {
		   feedback_bm_storage [bm-1][r][i] =
		                         ragged_pat;
	     } else if (bm == move) {   /* move pattern is copy & delete */
		   feedback_bm_storage [bm-1][r][i] =
		                         feedback_bm_storage [copy-1][r][i] &
		                         feedback_bm_storage [delete-1][r][i];
	     } else if (bm > move) {    /* inverse patterns */
		   feedback_bm_storage [bm-1][r][i] =
		                        ~feedback_bm_storage [bm-3-1][r][i];
	     } else {
		   feedback_bm_storage [bm-1][r][i] =
		                         solid_pat;
	     }
	  }
       }
      feedback_bm [bm].base          = (Word*) feedback_bm_storage [bm-1];
      feedback_bm [bm].width         = WordsPerLine;
      feedback_bm [bm].rect.origin.x = 0;
      feedback_bm [bm].rect.origin.y = 0;
      feedback_bm [bm].rect.corner.x = XMAX;
      feedback_bm [bm].rect.corner.y = charheight;
    }
}


/* clear_bos - clear from beginning of screen to cursor
 */
extern
clear_bos(t, c, r)
register struct tstat *t;
int c,r;
{
    cursor_off(t);
    rectf(&display,
	Rect(Trect.origin.x, Trect.origin.y, colx(ncols), rowy(r)), clr);
    clear_bol(t, c,r);
}


/* clear_eos - Clear from cursor to end of screen.
 */
extern
clear_eos(t)
register struct tstat *t;
{
    cursor_off(t);
    clear_eol(t, col-1,arow-1);
    rectf(&display,
	Rect(colx(0), rowy(arow), Trect.corner.x, Trect.corner.y), clr);
}


/* clear_bol - Clear from beginning of line to cursor.
 */
extern
clear_bol(t, c,r)
register struct tstat *t;
int c,r;
{
    cursor_off(t);
    rectf(&display, Rect(colx(0), rowy(r), colx(c), rowy(r+1)), clr);
}


/* clear_eol - Clear from cursor to end of line.
 */
extern
clear_eol(t, c, r)
register struct tstat *t;
int c, r;
{
    cursor_off(t);
    rectf(&display, Rect(colx(c), rowy(r), colx(ncols), rowy(r+1)), clr);
}

/* Scroll region between lin1 and lin2 inclusive n lines up or down
 */
extern
void scroll_region(t, lin1, lin2, n, upward) 
      register struct tstat *t;
      int lin1, lin2, n;
{
   cursor_off(t);
   lin2 = lin2 > bottom_margin-1 ? bottom_margin-1 : lin2;
   n    = n    > lin2+1-lin1     ? lin2+1-lin1     : n;
   if (upward) {
      if (n > 0) {
         bitblt(&display,
                Rect(Trect.origin.x, rowy(lin1+n),
                     Trect.corner.x, rowy(lin2+1)),
                &display,
                Pt(Trect.origin.x, rowy(lin1)), F_STORE);
         rectf(&display, Rect(Trect.origin.x, rowy(lin2+1-n),
                              Trect.corner.x, rowy(lin2+1)),   clr);
      }
   } else {
      if (n > 0) {
         bitblt(&display,
                Rect(Trect.origin.x, rowy(lin1),
                     Trect.corner.x, rowy(lin2+1-n)),
                &display,
                Pt(Trect.origin.x, rowy(lin1+n)), F_STORE);
         rectf(&display, Rect(Trect.origin.x, rowy(lin1),
                              Trect.corner.x, rowy(lin1+n)),   clr);
      }
   }
}


#define swap(a, b)   {int temp; temp=a; a=b; b=temp;}

extern
void hilight_region(t, from_row, from_col, to_row, to_col, kind)
      register struct tstat *t;
      int from_row, from_col, to_row, to_col, kind;
{
   int t_c;
   
   if (from_row>to_row || from_row==to_row && from_col>to_col) {
      swap (from_row, to_row);
      swap (from_col, to_col);
   }
   
   for (t_c = ncols; from_row <= to_row; from_row++) {
      if (from_row == to_row)
	 t_c = to_col;
      
      bitblt (&feedback_bm [kind],
	      Rect (from_col*charwidth, 0, t_c*charwidth, charheight),
	      &display,
	      Pt (colx (from_col), rowy (from_row)),
	      F_XOR);
      from_col = 0;
   }
}


extern
clear_screen(t)
      register struct tstat *t;
{
   cursor_off(t);
   rectf(&display, Trect, clr);
   if (scroll_active)
      rectf  (&display,                           /* redraw scrollbar     */
	      Rect (Trect.origin.x-BORDER-2, Trect.origin.y,
		    Trect.origin.x-BORDER-1, Trect.corner.y),   or);
}


extern
cursor_off(t)
      register struct tstat *t;
{
   single_cursor_off(t, &cursc, &cursr, is_current);
   single_cursor_off(t, &mcursc, &mcursr, &T_grey);
}


extern
cursor_on(t)
      register struct tstat *t;
{
   int r = arow-1, c = col-1;
   
   if (is_current != ((own()&MOUSE) != 0)) {
      single_cursor_off (t, &cursc, &cursr, is_current);
      is_current = !is_current;
   }
   if (is_current && tock || !is_current)
      single_cursor_on(t, c, r, &cursc, &cursr, is_current);
   else
      single_cursor_off(t, &cursc, &cursr, is_current);
   if (mouse_en && mbuts && !select_kind)  /* not for selection */
      single_cursor_on(t, mcol, mrow, &mcursc, &mcursr, &T_grey);
   else
      single_cursor_off(t, &mcursc, &mcursr, &T_grey);
}


extern
mcursor_off(t)
      register struct tstat *t;
{
   single_cursor_off(t, &mcursc, &mcursr, &T_grey);
}


/* In the following procedures (lastr < 0) indicates the cursor is off.
   Note that (lastc < 0) means the cursor is in the scroll bar!         */

static
single_cursor_on(t, c, r, lastc, lastr, tex)
      register struct tstat *t;
      int *lastc, *lastr;
      Texture *tex;
{
   if(*lastr >= 0 && (*lastc != c || *lastr != r)) {
      xcursor(t, *lastc, *lastr, tex);
      *lastr = -1;
   }
   if(*lastr < 0)
      xcursor(t, *lastc = c, *lastr = r, tex);
}


static
single_cursor_off(t, lastc, lastr, tex)
      register struct tstat *t;
      int *lastc, *lastr;
      Texture *tex;
{
   if(*lastr >= 0) {
      xcursor(t, *lastc, *lastr, tex);
      *lastr = -1;
   }
}


static
xcursor(t, c, r, tex)
      register struct tstat *t;
      Texture *tex;
{
   Rectangle curs_r;
   if (c < 0) {     /* in scroll bar */
      curs_r.origin.x = Srect.origin.x - 2;
      curs_r.corner.x = Trect.origin.x - BORDER - 3;
   }
   else {
      curs_r.origin.x = colx (c);
      curs_r.corner.x = colx (c+1);
   }
   curs_r.origin.y = rowy (r);
   curs_r.corner.y = rowy (r+1);
   if (tex == 0 || tex == (Texture *)1) {  /* warning: ugly hack! (gh) */
      rectf(&display, curs_r, F_XOR);
      if (tex == 0)
	 rectf (&display, inset (curs_r, 1), F_XOR);
   }
   else
      texture(&display, curs_r, tex, F_XOR);
}


extern
splat(t, ch)
      register struct tstat *t;
{
   out_buf[0] = ch;
   out_buf[1] = '\0';
   buf_ptr    = 1;
   splat_n (t);
}


extern
splat_n(t)
      register struct tstat *t;
{
   Rectangle crect;
   cursor_off(t);
   crect.origin.x = colx(col-1);
   crect.origin.y = rowy(arow-1);
   crect.corner.x = colx(col-1+buf_ptr);
   crect.corner.y = rowy(arow);
   if(insert_mode)
      bitblt(&display,
	     Rect(crect.origin.x, crect.origin.y,
		  Trect.corner.x-charwidth, crect.corner.y),
	     &display,
	     Pt(crect.corner.x, crect.origin.y), F_STORE);
   
   rectf(&display, crect, clr);
   string(&defont, out_buf, &display, crect.origin, or);
   if(graph_att & BOLD)
      string(&defont, out_buf, &display,
	     Pt(crect.origin.x+1, crect.origin.y+1), or);
   if(graph_att & UNDER)
      rectf(&display,
	    Rect(crect.origin.x, crect.origin.y+defont.ascent+2,
		 crect.corner.x, crect.origin.y+defont.ascent+3), or);
   if(graph_att & REV)
      rectf(&display, crect, F_XOR);
}


extern
ins_nchar(t, n)
      register struct tstat *t;
      register int n;
{
   Rectangle crect;
   cursor_off(t);
   crect.origin.x = colx(col-1);
   crect.origin.y = rowy(arow-1);
   crect.corner.x = colx(col-1+n);
   crect.corner.y = rowy(arow);
   bitblt(&display,
	  Rect (crect.origin.x, crect.origin.y,
		Trect.corner.x-n*charwidth, crect.corner.y),
	  &display,
	  Pt(crect.corner.x, crect.origin.y), F_STORE);
   rectf(&display, crect, clr);
}


extern
del_nchar(t, n)
      register struct tstat *t;
      register int n;
{
   Rectangle crect;
   cursor_off(t);
   crect.origin.x = colx(col-1);
   crect.origin.y = rowy(arow-1);
   crect.corner.x = colx(col-1+n);
   crect.corner.y = rowy(arow);
   bitblt(&display,
	  Rect(crect.corner.x, crect.origin.y,
	       Trect.corner.x, crect.corner.y),
	  &display,
	  Pt(crect.origin.x, crect.origin.y), F_STORE);
   rectf(&display, Rect(colx(ncols-n), crect.origin.y,
			Trect.corner.x, crect.corner.y), clr);
}


extern
inverse_vid(t, inv)
      register struct tstat *t;
{
   if(inv && clr == F_CLR) {
      clr = F_OR; or = F_CLR;
      goto flip;;
   } else  if(!inv && clr != F_CLR) {
      clr = F_CLR; or = F_OR;
    flip:
      rectf(&display, D_rect, F_XOR);
   }
}


extern
install_scrollbar (t)
      register struct tstat *t;
{
   Trect.origin.x = Srect.origin.x + Srect.corner.x - colx (--ncols);
   bitblt (&display,
	   Rpt (Srect.origin,
		Pt (Srect.corner.x - (Trect.origin.x - Srect.origin.x),
		    Srect.corner.y)),
	   &display, Trect.origin, F_STORE);   /* move screen contents */
   rectf  (&display, Rpt (Srect.origin, Pt (Trect.origin.x, Trect.corner.y)),
	   clr);                               /* clear scrollbar      */
   rectf  (&display,                           /* draw line            */
	   Rect (Trect.origin.x-BORDER-2, Trect.origin.y,
		 Trect.origin.x-BORDER-1, Trect.corner.y),   or);
} /* install_scrollbar */


extern
remove_scrollbar (t)
      register struct tstat *t;
{
   bitblt (&display, Trect, &display, Srect.origin, F_STORE);   /* move */
   Trect.origin.x = Srect.origin.x;
   rectf  (&display,                            /* clear right column   */
	   Rpt (Pt (colx (ncols++), Trect.origin.y), Trect.corner), clr);
} /* remove_scrollbar */
