/*
 * 5620_mouse - A layers program able to send mouse coordinates but otherwise
 *              behaving like a normal layer
 *
 * Version 2.2
 *
 * Public domain software.
 * Written by Gernot Heiser (heiser@ethz.uucp) in April 1987
 * based on the vt100 terminal emulator by Leif Samuelsson
 *    as modified by Peter Lamb
 * History :
 *   Version 1.1, Gernot Heiser, added scroll-region, repeat-char
 *   Version 1.3, Gernot Heiser July 1987:
 *     selection feedback
 *   Version 1.4, Gernot Heiser, August 1987:
 *      different selection kinds; special ESC-sequence for selection
 *   Version 1.5, Gernot Heiser, September 1987:
 *      define characteristics of layers to clone in startup file
 *      ensure mouse coordinates are sent "as seen"
 *      box cursor when layer is inactive
 *   Version 1.6, Gernot Heiser, September 1987:
 *      scroll bars
 *   Version 1.8, Gernot Heiser, October 1987:
 *      fixed reset bug, set layer size in TERMCAP string
 *   Version 1.9, Gernot Heiser, 1988-02-02:
 *      automatically report layer resize
 *   Version 2.2, Gernot Heiser, 1988-07-13:
 *      compressed mouse sequences, small fixes
 */

/* 5620 terminal output routines */

/* not yet implemented:
      "Set PF Key" (ESC [ k;n q string)
   additional (non-5620) features:
      received codes:
         clear_bos, clear_bol,
         parameters for cursor movements
         send-terminal-id  (\ez [identical to \e[c])
         set-scroll-region (\e[%i%d;%dr)
         repeat-char       (\e[R%.%dR [this is not ANSI])
	 send-window-size  (\e[?C)
         mouse on/off      (\e[?%dm          mouse_en  = par!=0)
         scrollbar on/off  (\e[?%ds          scroll_en = par!=0)
         open mode on/off  (\e[?%dh \e[?%dl)
         define buttons    (\e[?%d;%d;%db)
        <send-snarf-buffer (\e[?%dp [not implemented])>
        <set-snarf-buffer  (\e[?%dP%s [not implemented])>
      sent codes:
         window-size       (\e[?%d;%dC)
	<mouse-cursor      (\e[?%i%d;%i%d;%dR [no longer sent])>
	 mouse-cursor      (\e[?%i%d;%d;%d;%d;%dQ [from pt, to pt, buts])
	 selection-region  (\e[?%i%d;%d;%d;%d;%dS)
	 resized           (\e[?c\n)
 */

#include "5620.h"



static char i_am_5620[]  = "\033[??8;7;5c";

/* nextch - read output and interpret control characters (as far as interpreted
            by 5620).
 *	    Return first 5620 graphic character.
 */
int nextch(t)
register struct tstat *t;
{
	register int ch;

    while ((ch = wreceive(t)) >= 0) {
	switch (ch) {
	    case '\007':		/* Bell */
		ringbell();
		break;
	    case '\b':			/* BackSpace */
		    if (col > 1) {
			col--;
		    }
		break;
	    case '\t':			/* Tab */
		while (col < ncols && !tabs[col++]);
		break;
	    case '\n':			/* Line Feed */
		do_linefeed(t);
		if(!nl_mode)
			break;
		/* Otherwise FALL THROUGH!! */
	    case '\r':			/* Carriage Return */
		if (col > 1) {
		    col = 1;
		}
		break;
	    case '\021':		/* Ignore ^Q/^S */
	    case '\023':
	        break;
	    default:
		    return(ch);
	}
    }
    return(ch);
} /* nextch */


/* handle_output - Main loop of output process.
 *		   Reads and dispatches characters from output stream.
 */
handle_output(t)
register struct tstat *t;
{
register int ch;

    while ((ch = nextch(t)) >= 0) {
	if (ch == '\033') {		/* Escape character */
	    do_ansi_escape(t);
	}
	else {          		/* 5620 printing character */
	    if (col >= ncols) {
		splat(t, ch);
		if (wrap) {
		    col = 1;
		    do_linefeed(t);
		  }
	    }
	    else {                     /* receive (and buffer) chars as     */
	        buf_ptr = 1;           /* available and fit on line, then   */
		out_buf[0] = ch;       /* output the whole string           */
		ch = -1;
		while (col+buf_ptr < ncols && buf_ptr < BUFS
		       && (ch = rcvchar()) >= ' ' && ch < '\177') {
			  out_buf[buf_ptr++] = ch;
			  ch = -1;
		}
		out_buf [buf_ptr] = '\0';
		peek_ch = ch;
		splat_n(t);
		col += buf_ptr;
	    }
	}
    }
} /* handle_output */


/* do_ansi_escape - reads and interprets an ANSI escape sequence
 */

do_ansi_escape(t)
register struct tstat *t;
{
register int ch;

    if ((ch = nextch(t)) < 0)
	return;
    switch (ch) {
	case '7':
	    save_row = row;
	    save_col = col;
	    save_graph_att = graph_att;
	    break;
	case '8':
	    if (save_row > 0) {
		row = save_row;
		col = save_col;
	        graph_att = save_graph_att;
	    } break;

	case '[':
	    do_csi(t); break;

	case 'c':
	    do_reset(t); break;

	case 'z':
	    sendnchars(sizeof i_am_5620 - 1, i_am_5620); break;

    }
} /* do_ansi_escape */


/* do_csi - the real ANSI interpreter
 */
do_csi(t)
register struct tstat *t;
{
register int i, ch;
int private;

    if ((ch = nextch(t)) < 0)
	return;

    /* Check if private 5620 ESC sequence */
    private = 0;
    if (ch == '?') {
	private++;
	if ((ch = nextch(t)) < 0)
	    return;
    }

    if((ch = do_args(t, ch)) < 0)
	return;

    if (private) {
	switch (ch) {
	   case 'b':         /* define buttons */
	                     /* "m;s;c"  m=menu, s=selection, c=copy */
	                     /*    = 0: feature disabled,            */
	                     /*    > 7: leave previous setting       */
	      if ((i=argno) > 0) {
		 if (arg[0] < 7) {
		    menu_but = arg[0];
		    if (sel_but & menu_but) {
		       sel_but = 0;
		     }
		  }
	       }
	      if (i > 1) {
		 if (arg[1] < 7) {
		    sel_but = arg[1];
		    if (sel_but != 0 && copy_but != 0) {
		       if (copy_but & sel_but) {
			  copy_but = 0;
			  del_but  = 0;
			}
		       else {
			  del_but = 7 & ~(sel_but|copy_but);
			}
		     }
		    if (menu_but == copy_but) {
		       menu_but = 0;
		     }
		  }
	       }
	      if (i > 2) {
		 if (arg[2] < 7) {
		    copy_but = arg[2];
		    if (copy_but & sel_but) {
		       sel_but = 0;
		     }
		    if (copy_but == 0 || sel_but == 0) {
		       del_but = 0;
		     }
		    else {
		       del_but  = 7 & ~(sel_but|copy_but);
		     }
		  }
	       }
	      break;
	   case 'C':
	      send_window_size (t);
	      break;
	   case 'h':                    /* start open mode */
	   case 'l':                    /* end   open mode */
	      if (argno > 1)
		 return;
	      if (open_mode = ch == 'h') {
		 mcursc = mcursr = -1;
	      }
	      if (scroll_active != (open_mode && scroll_en)) {
		 if (scroll_active = !scroll_active)
		    install_scrollbar (t);
		 else
		    remove_scrollbar (t);
	      }
	      mouse_active = open_mode && mouse_en;
	      break;
	   case 'm':                    /* enable/disable mouse */
	      if (argno > 1)
		 return;
	      mouse_en     = argno && arg[0];
	      mouse_active = open_mode   &&  mouse_en;
	      break;
#if FALSE
#ifdef MUX
           case 'p':                    /* send snarf buffer */
	      if (argno > 0)
		 return;
	      send_snarf (t);
              break;
           case 'P':                    /* set snarf buffer */
	      if (argno != 1)
		 return;
              while (arg[0]--) {
                 while ((ch = wreceive (t)) >= 0) { /* for now dump them */
                 }                                  /* on the floor */
              }
#endif /* MUX */
#endif /* FALSE */
	   case 's':                    /* enable/disable scroll bar */
	      if (argno > 1)
		 return;
	      scroll_en    = argno && arg[0];
	      if (scroll_active != (open_mode && scroll_en)) {
		 if (scroll_active = !scroll_active)
		    install_scrollbar (t);
		 else
		    remove_scrollbar (t);
	      }
	      break;
	}
    }
    else {
	switch (ch) {
	    case 'A':
		i = (argno == 1 && arg[0] > 0) ? arg[0] : 1;
		while (i-- && row > 1) {
		    row--;
		} break;

	    case 'B':
		i = (argno == 1 && arg[0] > 0) ? arg[0] : 1;
		while (i-- && row < bottom_margin-top_margin+1) {
		    row++;
		} break;

	    case 'C':
		i = (argno == 1 && arg[0] > 0) ? arg[0] : 1;
		while (i-- && col < ncols) {
		    col++;
		} break;

	    case 'D':
		i = (argno == 1 && arg[0] > 0) ? arg[0] : 1;
		while (i-- && col > 1) {
		    col--;
		} break;

	    case 'H':
	    case 'f':
		do_set_cursor(t); break;
	    case 'J':
		do_erase_in_display(t); break;
	    case 'K':
		do_erase_in_line(t); break;
	    case 'L':
		do_insert_line(t); break;
	    case 'M':
		do_delete_line(t); break;
	    case 'P':
		do_delete_char(t); break;
	    case '@':
		do_insert_char(t); break;
	    case 'm':
		do_attributes(t); break;
	    case 'r':
		do_set_scroll_region(t); break;
	    case 'R':
		if ((ch = nextch(t)) < 0)
		   return;
		if (do_args(t, nextch(t)) != 'R')
		   return;
		do_repeat_char(t, ch); break;
	    case 'S':
		do_scroll(t, TRUE); break;
	    case 'T':
		do_scroll(t, FALSE); break;
	    case 'c':
		switch (arg[0]) {
		    case 0:
			sendnchars(sizeof i_am_5620 - 1, i_am_5620); break;
		} break;
	}
    }
} /* do_csi */


do_args(t, ch)
register struct tstat *t;
register int ch;
{
    /* Parse arguments */
    argno = 0;
    while ((ch >= '0' && ch <= '9') || ch == ';') {
	arg[argno] = 0;
	while (ch >= '0' && ch <= '9') {
	    arg[argno] = arg[argno] * 10 + (ch - '0');
	    if ((ch = nextch(t)) < 0)
		return -1;
	}
	if (ch == ';')
	    if ((ch = nextch(t)) < 0)
		return -1;
	argno++;
    }

    return ch;
} /* do_args */


do_set_cursor(t)
register struct tstat *t;
{
    if (arg[0] == 0)
	arg[0]++;
    if (arg[1] == 0)
	arg[1]++;
    switch (argno) {
	case 0:
	    arg[0] = 1;
	    argno++;
	    /* Fall through */

	case 1:
	    arg[1] = 1;		/* Correct? */
	    argno++;
	    /* Fall through... */

	case 2:
	    row = arg[0];
	    if (row>bottom_margin) row=bottom_margin;
	    col = arg[1];
	    if (col>ncols) col=ncols;
	    break;
    }
} /* do_set_cursor */


send_reshaped (t)
register struct tstat *t;
{
   send_string ("\033[?c\n");
} /* send_reshaped */


send_window_size(t)
register struct tstat *t;
{
	sendnchars(3, "\033[?");
	send_num(nrows);
	sendchar(';');
	send_num(ncols + (int)scroll_active);
	sendchar('C');
        if (! open_mode) {
           sendchar ('\n');
        }
} /* send_window_size */


send_curs(t)
register struct tstat *t;
{
	sendnchars(2, "\033[");
	send_num(row);
	sendchar(';');
	send_num(col);
	sendchar('R');
} /* send_curs */


#if FALSE
send_mcurs(t, c, r, b)
register struct tstat *t;
{ /* note that rows and columns are zero-relative but sent one-relative! */
	sendnchars(3, "\033[?");
	send_num(r+1);
	sendchar(';');
	send_num(c+1);
	sendchar(';');
	send_num(b);
	sendchar('R');
} /* send_mcurs */
#endif /* FALSE */


void send_region(t, row_0, col_0, row_1, col_1, kind, selection)
register struct tstat *t;
int                   row_0, col_0, row_1, col_1, kind;
Bool                  selection;
{ /* note that rows and columns are zero-relative but sent one-relative! */
	sendnchars (3, "\033[?");
	send_num (row_0+1);
	sendchar (';');
	send_num (col_0+1);
	sendchar (';');
	send_num (row_1+1);
	sendchar (';');
	send_num (col_1+1);
	sendchar (';');
	sendchar (kind + '0');
        if (selection) {
           sendchar ('S');
        }
        else {
           sendchar ('Q');
        }
} /* send_region */


send_num(n)
register int n;
{
	register int i;
	if(i = n/10)
		send_num(i);
	sendchar(n%10+'0');
} /* send_num */


#if FALSE
#ifdef MUX
send_snarf (t)
register struct tstat *t;
{
   if (! open_mode) { /* if not open mode append newline */
      sendchar ('\n');
   }
} /* send_snarf */
#endif /* MUX */
#endif /* FALSE */


do_erase_in_display(t)
register struct tstat *t;
{
    switch (argno) {
	case 0:
	    arg[0] = 0;
	    argno++;
	    /* Fall through */
	case 1:
	    switch (arg[0]) {
		case 0:
		    clear_eos(t);
		    break;
		case 1:    /* not really a 5620 sequence, but doesn't harm */
		    clear_bos(t, col-1, arow-1);
		    break;
		case 2:
		    clear_screen(t);
		    break;
	    }
	    break;
    }
} /* do_erase_in_display */


do_erase_in_line(t)
register struct tstat *t;
{
    switch(argno) {
	case 0:
	    arg[0] = 0;
	    argno++;
	    /* fall through */
	case 1:
	    switch (arg[0]) {
		case 0:
		    clear_eol(t, col-1, arow-1);
		    break;
		case 1:    /* not really a 5620 sequence, but doesn't harm */
		    clear_bol(t, col-1, arow-1);
		    break;
		case 2:    /* not really a 5620 sequence, but doesn't harm */
		    clear_eol(t, 0, arow-1);
		    break;
	    } break;
    }
} /* do_erase_in_line */


#if FALSE
do_clear_tabs(t)
register struct tstat *t;
{
register int i;

    if (argno == 0)
	arg[argno++] = 0;
    switch (arg[0]) {
	case 0:
	    tabs[col-1] = 0; break;
	case 3:
	    for (i = 0; i<ncols; i++)
		tabs[i] = 0; break;
    } 
} /* do_clear_tabs */
#endif


do_attributes(t)
register struct tstat *t;
{
register int i;

    if (argno == 0) {
	arg[0] = 0;
	argno++;
    }
    for (i=0; i<argno; i++) {
	switch (arg[i]) {
	    case 0:
		graph_att = 0;
		break;
	    case 1:    /* not really a 5620 sequence, but doesn't harm */
		graph_att |= BOLD; break;

	    case 4:
		graph_att |= UNDER; break;

	    case 7:
		graph_att |= REV; break;
	}
    }
} /* do_attributes */


do_set_scroll_region(t)
register struct tstat *t;
{
    if (arg[0] == 0)
	arg[0]++;
    if (arg[1] == 0)
	arg[1]++;
    switch (argno) {
	case 0:
	    arg[0] = 1;
	    /* Fall through */

	case 1:
	    arg[1] = nrows;
	    argno = 2;
	    /* Fall through */

	case 2:
	    top_margin = arg[0];
	    bottom_margin = arg[1];
	    col = row = 1;
	    break;
    }
} /* do_set_scroll_region */


do_repeat_char(t, ch)
      register struct tstat *t;
      register int ch;
{
   if (argno == 0)
      return;
   while (arg[0] > 0) {
      buf_ptr = 0;
      while (arg[0] > 0 && col+buf_ptr < ncols && buf_ptr < BUFS) {
	 out_buf [buf_ptr++] = ch;
	 arg[0]--;
      }
      out_buf [buf_ptr] = '\0';
      splat_n(t);
      col += buf_ptr;
      if (col >= ncols && wrap) {
	 col = 1;
	 do_linefeed(t);
      }
   }
} /* do_repeat_char */


do_linefeed(t)
register struct tstat *t;
{
    if (arow == bottom_margin) {
	scroll_region(t, top_margin-1, bottom_margin-1, 1, TRUE);
    }
    else if (arow < nrows) {
	row++;
    }
} /* do_linefeed */


#if FALSE
do_reverse_lf(t)
register struct tstat *t;
{
    if (arow == top_margin) {
	scroll_region(t, top_margin-1, bottom_margin-1, 1, FALSE);
    }
    else if (arow > 1) {
	row--;
    }
} /* do_reverse_lf */
#endif


/* do_reset - Reset emulator and screen */
do_reset(t)
register struct tstat *t;
{
    register int i;
    void         reshape ();

    graph_att     =
    sel_but       =
    copy_but      =
    del_but       =
    menu_but      =
    mbuts         = 0;
    save_row      = -1;			/* So we know we haven't saved */
    origin_mode   =
    kbd_lock      =
    insert_mode   =
    nl_mode       =
    cancel        =
    mouse_en      =
    scroll_en     =
    open_mode     =
    mouse_active  =
    scroll_active = FALSE;
    wrap          = TRUE;
    reshape (t, FALSE);
    for (i=0; i<ncols; i++)
	tabs[i] = ((i/8)*8 == i);
    inverse_vid (t, FALSE);
    init_menu (t);
    clear_screen (t);
    cursc = cursr = mcursc = mcursr = -1;
} /* do_reset */


do_scroll(t, upward)
register struct tstat *t;
int upward;
{
  scroll_region (t, top_margin-1, bottom_margin-1,
		 (argno == 1 && arg[0] > 0) ? arg[0] : 1,
		 upward);
} /* do_scroll */


do_insert_line(t)
register struct tstat *t;
{
	scroll_region(t, arow-1, bottom_margin-1,
		      (argno == 1 && arg[0] > 0) ? arg[0] : 1,
		      FALSE);
} /* do_insert_line */


do_delete_line(t)
register struct tstat *t;
{
	scroll_region(t, arow-1, bottom_margin-1,
		      (argno == 1 && arg[0] > 0) ? arg[0] : 1,
		      TRUE);
} /* do_delete_line */


do_insert_char(t)
register struct tstat *t;
{
	register int i;
	i = (argno == 1 && arg[0] > 0) ? arg[0] : 1;
	ins_nchar(t, i);
} /* do_insert_char */


do_delete_char(t)
register struct tstat *t;
{
	register int i;
	i = (argno == 1 && arg[0] > 0) ? arg[0] : 1;
	del_nchar(t, i);
} /* do_delete_char */
