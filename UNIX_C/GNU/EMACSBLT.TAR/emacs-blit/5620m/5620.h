/*
 * 5620_mouse - A layers program able to send mouse coordinates but otherwise
 *              behaving like a normal layer
 *
 * Version 2.2
 *
 * Public domain software.
 * Written by Gernot Heiser (heiser@ethz.uucp) in April 1987
 * based on the vt100 terminal emulator by Leif Samuelsson
 *    as modified by Peter Lamb
 * History :
 *   Version 1.3, Gernot Heiser, Stefan Zeiger, July 1987:
 *      selection feedback
 *   Version 1.4, Gernot Heiser, August 1987:
 *      different selection kinds; special ESC-sequence for selection
 *   Version 1.5, Gernot Heiser, September 1987:
 *      define characteristics of layers to clone in startup file
 *      ensure mouse coordinates are sent "as seen"
 *      box cursor when layer is inactive
 *   Version 1.6, Gernot Heiser, September 1987:
 *      scroll bars
 *   Version 2.0, Gernot Heiser, 1988-02-27:
 *      adapted to mux
 *   Version 2.2, Gernot Heiser, 1988-07-13:
 *      compressed mouse sequences, small fixes
 */

/* include file containing global definitions */

#ifdef MUX

#include <jerq.h>
#include <layer.h>
#include <jerqproc.h>
#include <msgs.h>
#include <font.h>

#else

#define PANDORA
#include <dmd.h>
#include <layer.h>	/* to keep lint quiet */
#include <dmdproc.h>
#include <msgs.h>
#include <font.h>
#define mpxnewwind
#define newwindow
#define dellayer
#define newlayer
#define newproc
#define upfront
#include <pandora.h>

#endif

#undef button1
#undef button2
#undef button3
#undef button123
#undef display

#define Mouse		(((struct udata *)P->data)->mouse)
#define r_butt()        (Mouse.buttons & 4)
#define m_butt()        (Mouse.buttons & 2)
#define l_butt()        (Mouse.buttons & 1)
#define any_butt()      (Mouse.buttons & 7)
#define D_rect		(((struct udata *)P->data)->Drect)
#define display		(*(P->layer))

#define send_string(s)  sendnchars (strlen (s), s)

#define FALSE 0
#define TRUE  1

typedef short Bool;

#define J_BORDER   8
#define INSET	   5
#define BORDER	   2
#define XMIN     101
#define YMIN      51

typedef Bool int;

extern int cloned;
extern struct tstat clone_info;
extern int charwidth;
extern int charheight;


/* selection kinds: */

#define select        1
#define copy          2
#define delete        3
#define move          4
#define inv_copy      5   /* these are the inverse patterns */
#define inv_delete    6
#define inv_move      7
#define nbr_patterns  7


#define BUFS            32

#define NMENU		5

/* arow is absolute row, taking top_margin into account */
#define arow	(row + (origin_mode ? (top_margin - 1) : 0))

#define REV	(1<<0)
#define BOLD	(1<<1)
#define UNDER	(1<<2)

struct tstat {
	/* Size of screen */
	int	t_nrows;
	int	t_ncols;

	/* Cursor and margins */
	int	t_row;
	int	t_col;
	int	t_top_margin;
	int	t_bottom_margin;

	/* Terminal modes */
	int	t_graph_att;
	Bool	t_origin_mode;
	Bool	t_wrap;
	Bool	t_kbd_lock;
	Bool	t_insert_mode;
	Bool	t_nl_mode;
	Bool	t_mouse_en;      /* mouse active if in open mode        */
	Bool    t_scroll_en;     /* scroll bars if in open mode         */
	Bool    t_open_mode;     /* editing facilities active           */
	Bool    t_mouse_active;  /* t_open_mode && t_mouse_en           */
	Bool    t_scroll_active; /* t_open_mode && t_scroll_en          */
	Bool    t_is_current;

	/* cursor/attribute save area */
	int	t_save_row;
	int	t_save_col;
	int	t_save_graph_att;

	/* Tabs definition */
	char	t_tabs[132];

	/* input/output buffers */
	char    t_out_buf[BUFS+1];
	int     t_buf_ptr;
	int     t_peek_ch;

	/* Ansi argument parse scratch */
	int	t_arg[10];
	int	t_argno;

	/* Bitmap data */
	Rectangle t_Srect;       /* usable screen area                  */
	Rectangle t_Trect;       /* screen area proper: Srect-scrollbar */
	Code	t_clr, t_or;

	/* Menu */

	Menu	t_menu;
	char	*t_menustrs[NMENU+1];

	/* Buttons */

	int     t_sel_but;     /* selection            */
	int     t_copy_but;    /* .. .copy selection   */
	int     t_del_but;     /* ... delete selection */
	int     t_menu_but;    /* display menu         */
        int     t_tot_buts;    /* sum of depressed buttons */
	int     t_select_kind; /* kind of current selection */
	int     t_cancel;      /* current mouse op is cancelled */

	/* Variables that should be statics (and were once...) */
	int     t_tock;
	int	t_cursc;
	int	t_cursr;
	int	t_mcol;		/* Mouse cursor variables */
	int	t_mrow;
        int     t_mcol_0; 
	int     t_mrow_0;
	int     t_mcol_old;
	int     t_mrow_old;
	int	t_mcursc;
	int	t_mcursr;
	int	t_mbuts;

};

#define nrows		t->t_nrows
#define ncols		t->t_ncols
#define row		t->t_row
#define col		t->t_col
#define top_margin	t->t_top_margin
#define bottom_margin	t->t_bottom_margin
#define origin_mode	t->t_origin_mode
#define kbd_lock	t->t_kbd_lock
#define insert_mode	t->t_insert_mode
#define nl_mode		t->t_nl_mode
#define graph_att	t->t_graph_att
#define wrap		t->t_wrap
#define mouse_en	t->t_mouse_en
#define scroll_en       t->t_scroll_en
#define open_mode       t->t_open_mode
#define mouse_active    t->t_mouse_active
#define scroll_active   t->t_scroll_active
#define is_current      t->t_is_current
#define save_row	t->t_save_row
#define save_col	t->t_save_col
#define save_graph_att	t->t_save_graph_att
#define tabs		t->t_tabs
#define out_buf         t->t_out_buf
#define buf_ptr         t->t_buf_ptr
#define peek_ch         t->t_peek_ch
#define arg		t->t_arg
#define argno		t->t_argno
#define Srect		t->t_Srect
#define Trect		t->t_Trect
#define clr		t->t_clr
#define or		t->t_or
#define menu		t->t_menu
#define menustrs	t->t_menustrs
#define sel_but         t->t_sel_but
#define copy_but        t->t_copy_but
#define del_but         t->t_del_but
#define menu_but        t->t_menu_but
#define tot_buts        t->t_tot_buts
#define select_kind     t->t_select_kind
#define cancel          t->t_cancel
#define tock            t->t_tock
#define cursc		t->t_cursc
#define cursr		t->t_cursr
#define mcol		t->t_mcol
#define mrow		t->t_mrow
#define mcol_0          t->t_mcol_0
#define mrow_0          t->t_mrow_0
#define mcol_old        t->t_mcol_old
#define mrow_old        t->t_mrow_old
#define mcursc		t->t_mcursc
#define mcursr		t->t_mcursr
#define mbuts		t->t_mbuts
