/*
 * 5620_mouse - A layers program able to send mouse coordinates but otherwise
 *              behaving like a normal layer
 *
 * Version 2.2
 *
 * Public domain software.
 * Written by Gernot Heiser (heiser@ethz.uucp) in April 1987
 * based on the vt100 terminal emulator by Leif Samuelsson
 *    as modified by Peter Lamb
 * History :
 *   Version 1.3, Gernot Heiser, Stefan Zeiger, July 1987:
 *      selection feedback
 *   Version 1.4, Gernot Heiser, August 1987:
 *      different selection kinds; special ESC-sequence for selection
 *   Version 1.5, Gernot Heiser, September 1987:
 *      define characteristics of layers to clone in startup file
 *      ensure mouse coordinates are sent "as seen"
 *      box cursor when layer is inactive
 *   Version 1.6, Gernot Heiser, September 1987:
 *      scroll bars
 *   Version 1.8, Gernot Heiser, October 1987:
 *      fixed reset bug, set layer size in TERMCAP string, comments (#) in
 *      startup file
 *   Version 1.9, Gernot Heiser, 1988-02-02:
 *      automatically report layer resize,
 *      only clicks left to or on vertical line are in scrollbar
 *   Version 2.0, Gernot Heiser, 1988-02-27:
 *      adapted to mux
 *   Version 2.1, Gernot Heiser, 1988-05-29:
 *      fixed several problems with mux version
 *   Version 2.2, Gernot Heiser, 1988-07-13:
 *      compressed mouse sequences, small fixes
 */

/* 5620 main line */

#include "5620.h"

#define NEED	(KBD|RCV|ALARM|MOUSE)
#define MAXCLONE    15

       int          cloned            = FALSE;
       struct tstat clone_info;
       int          clone_nbr         = 0;
static char         *gargs [MAXCLONE],
                    termcap_buf [512],
                    *general_argv = termcap_buf,
                    *line_field   = NULL,
                    *column_field = NULL;
static char         **gargv[MAXCLONE];
       int          charwidth;
       int          charheight;

static
void clone_main();

extern
void clone_0 ()
{
   clone_main (0, gargv[0]);
}

static
void clone_1 ()
{
   clone_main (1, gargv[1]);
}

static
void clone_2 ()
{
   clone_main (1, gargv[2]);
}

static
void clone_3 ()
{
   clone_main (1, gargv[3]);
}

static
void clone_4 ()
{
   clone_main (1, gargv[4]);
}

static
void clone_5 ()
{
   clone_main (1, gargv[5]);
}

static
void clone_6 ()
{
   clone_main (1, gargv[6]);
}

static
void clone_7 ()
{
   clone_main (1, gargv[7]);
}

static
void clone_8 ()
{
   clone_main (1, gargv[8]);
}

static
void clone_9 ()
{
   clone_main (1, gargv[9]);
}

static
void clone_10 ()
{
   clone_main (1, gargv[10]);
}

static
void clone_11 ()
{
   clone_main (1, gargv[11]);
}

static
void clone_12 ()
{
   clone_main (1, gargv[12]);
}

static
void clone_13 ()
{
   clone_main (1, gargv[13]);
}

static
void clone_14 ()
{
   clone_main (1, gargv[14]);
}

static void (*clone_func[]) () = {clone_0, clone_1, clone_2, clone_3, clone_4,
				  clone_5, clone_6, clone_7, clone_8, clone_9,
				  clone_10, clone_11, clone_12, clone_13,
				  clone_14};


static
int get_num (argc, argv, orig, fact, corner, more)
      register char ***argv;
      int           *argc, orig, fact;
      Bool          corner, *more;
{
   /* Read a number from the argument string.
      If the number is prefixed by '+' it is relative to orig,
      if it is suffixed by 'c' or 'C' it is in character units.
      Return the absolute number in pixel units.                 */

   int  ch, num = 0;
   Bool relative = FALSE;
   
   if (*more && *argc > 0) {
      if (relative = ***argv == '+')
	 (**argv)++;
      while ((ch = *(**argv)++) >= '0' && ch <= '9') {
	 num = num * 10 + ch - '0';
      }
      if (ch == 'c' || ch == 'C') {
	 ch = *(**argv)++;
	 num *= fact;
	 if (corner)
	    num += 2 * INSET;  /* all magic as far as I'm concerned */
      }
      while (ch == ' ' || ch == '\t')     /* skip whitespace */
	 ch = *(**argv)++;
      if (ch == '\0') {  /* end of arg word */
	 (*argc)--; (*argv)++;
      }
      else {
	 (**argv)--;
      }
   }
   else
      *more = FALSE;
   return  relative ? num+orig : num;
} /* get_num */


static
char *get_string (argc, argv, more)
      register char ***argv;
      int           *argc;
      Bool          *more;
{
   char ch, *ptr = **argv;

   /* If argument value doesn't start with '-', return a pointer
      to it, otherwise return NULL.                                   */

   if (*argc <= 0 || *ptr == '-' || !*more) {
      *more = FALSE;
      return NULL;
   }
   while ((ch = *(**argv)++) != '\0') {
      if (ch == '\n') {
	 if (**argv == ptr+1  ||  *(**argv-2) != '\\')
	    break;
      }
   }
   if (ch == '\n') {
      *((**argv)-1) = '\0';
      ch = *(**argv)++;
   }
   if (*more = ch != '\0') {
      (**argv)--;
   }
   else {
      (*argc)--;
      (*argv)++;
   }
   return ptr;
} /* get_string */


static
void auto_clone (argc, argv, more)
      register char ***argv;
      int           *argc;
      Bool          *more;
{
   Rectangle   r;
   struct Proc *p;
   char        *ptr;

   if (*argc > 0) {
      *more = TRUE;
      while (***argv == ' '  || ***argv == '\t')  /* skip white space */
	 (**argv)++;
      if (***argv == '#') {  /* comment line - ignore */
	 while (***argv != '\n'  &&  ***argv != '\0') {
	    (**argv)++;
	 }
	 if (***argv == '\n') {
	    (**argv)++;
	 }
	 if (***argv == '\0') {
	    (*argc)--; (*argv)++;
	 }
	 return;
      }
   }
   else {
      *more = FALSE;
      return;
   }
   r.origin.x = get_num (argc, argv, J_BORDER, charwidth, FALSE, more);
   r.origin.y = get_num (argc, argv, J_BORDER, charheight, FALSE, more);
   r.corner.x = get_num (argc, argv, r.origin.x, charwidth, TRUE, more);
   r.corner.y = get_num (argc, argv, r.origin.y, charheight, TRUE, more);
   ptr = get_string (argc, argv, more);
   if (++clone_nbr > MAXCLONE)
      return;
   *(gargv [clone_nbr] = &gargs [clone_nbr]) = ptr;

      /* attempt to move rectangle into "valid region": */
   r = rsubp (r, Pt (r.corner.x <= XMAX-J_BORDER
		                            ? 0 : r.corner.x+J_BORDER-XMAX,
		     r.corner.y <= YMAX-J_BORDER
		                            ? 0 : r.corner.y+J_BORDER-YMAX));
   r = raddp (r, Pt (r.origin.x >= J_BORDER ? 0 : J_BORDER-r.origin.x,
		     r.origin.y >= J_BORDER ? 0 : J_BORDER-r.origin.y));
      /* clip rectangle to "valid region": */
   if (!rectclip (&r, inset (Rect (0, 0, XMAX, YMAX), J_BORDER))  ||
       r.corner.x - r.origin.x < XMIN  ||  r.corner.y - r.origin.y < YMIN) {
      return;    /* illegal rectangle */
   }

#ifdef DEBUG
   sendnchars (15, "echo cloning '(");
   send_num (r.origin.x); sendchar (',');
   send_num (r.origin.y); sendchar (',');
   send_num (r.corner.x); sendchar (',');
   send_num (r.corner.y); send_string (")' '");
   send_string (*gargv); send_string ("'\n");
#endif

   if (p = newproc (clone_func [clone_nbr])) {
      if (p->layer = newlayer (inset (r, - BORDER))) {
	    /* the parameter to "newlayer" will determine */
	    /* the size of the outer rectangle */
	 p->rect = inset (r, BORDER);  /* this rectangle will be */
				       /* reported by jwin       */
#ifdef MUX
	 muxnewwind (p, C_NEW);
#else
	 mpxnewwind (p, C_NEW);
#endif
         tolayer (p->layer);
      }
      else {
	 p->state = 0;
	 return;
      }
   }
   else {
      return;
   }
} /* auto_clone */


static
void send_arg (argv, newline)
      char *argv;
      Bool newline;
{
   int l;

   if (argv && (l = strlen (argv))) {
      sendnchars (l, argv);
      if (newline) {
	 sendchar ('\n');
      }
   }
} /* send_arg */


static
char *put_str (buffer, str)
      char *buffer, *str;
{
   while (*str != '\0') {
      *buffer++ = *str++;
   }
   return  buffer;
}


static
char *put_nbr (buffer, nbr)
      char *buffer;
      int  nbr;
{
   *buffer++ = nbr/10 + '0';
   *buffer++ = nbr%10 + '0';
   return  buffer;
}


static
void term_main(t, argc, argv)
      register struct tstat *t;
      char **argv;
{
   if (line_field != NULL) {
      put_nbr (line_field, nrows);
      put_nbr (column_field, ncols);
   }
#ifndef MUX
   send_arg (general_argv, TRUE);
#endif
   while(argc > 0) {
      send_arg (*argv++, TRUE);
      argc--;
   }

   tock = FALSE;
   peek_ch     = -1;     /* init input buffer */
   select_kind =  0;     /* init selection kind */
   cancel      = FALSE;
   request(NEED);
   
   for(;;) {
      handle_output(t);  /* handle_input() called from wreceive() */
   }
} /* term_main */


void main(argc, argv)
      int  argc;
      char **argv;
{
   register struct tstat *t = (struct tstat *)alloc(sizeof (struct tstat));
   Bool     more, was_current;
   Layer    *my_layer;

   if(t == 0)
      exit();

   init_term(t);
   do_reset(t);
   my_layer = P->layer;
   was_current = own () & MOUSE;

   argc--; argv++;
   while(argc > 0 && **argv == '-') {
      switch(argv[0][1]) {
       case 'a':
	 argc--; argv++;
	 if (argc > 0) {
	    while (**argv != '\0') {
	       if (**argv     == '#'  &&  *(*argv+1) == '#'  &&
		   *(*argv+2) == '#'  &&  *(*argv+3) == '#'    )  {
		  general_argv = put_str (general_argv, "li#00:co#00");
		  line_field   = general_argv - 8; /* line field */
		  column_field = general_argv - 2; /* column field */
		  general_argv = put_str (general_argv, *argv+4);
		  break;
	       }
	       else {
		  *general_argv++ = *(*argv)++;
	       }
	    }
	    *general_argv = '\0';
	    general_argv  = termcap_buf;
	    argc--; argv++;
	 }
	 break;
       case 'c':
	 argc--; argv++;
	 do auto_clone (&argc, &argv, &more);
	    while (more);
	 break;
       default:
	 argc--; argv++;
	 break;
      }
   }
#if FALSE
   if (was_current) {
      upfront (my_layer);  /* bring "original" layer on top */
      tolayer (my_layer);  /* make it current again */
   }
#endif FALSE
   term_main (t, argc, argv);
} /* main */


static
void clone_main(argc, argv)
      int  argc;
      char **argv;
{
	register struct tstat *t = (struct tstat *)alloc(sizeof(struct tstat));

	*t = clone_info;		/* Get config data out of shared bss */

	if((P->data = alloc(sizeof(struct udata))) == 0) {
	   exit();
	}

	P->state |= USER;

	cloned = TRUE;

	init_term(t);
	do_reset(t);

#ifdef MUX
        send_arg (general_argv, TRUE);
#endif
	term_main(t, argc, argv);
} /* clone_main */


static
void handle_input(t)
register struct tstat *t;
{
   int k;
   static char trans [] = "WTXUYV";

   while((k = kbdchar()) >= 0)
      if (!kbd_lock) {
#ifdef MUX
         if (k < 0200) {                    /* "normal" keyboard key */
            sendchar(k);
            return;
         }
         else if (k < 0300) {               /* spec. +  shifted keypad: SS3 */
            sendnchars (2, "\033O");
            sendchar (0220 <= k && k <= 0231 ? k-040  : /* shifted keypad */
                      0232 <= k && k <= 0233 ? k-055  : /* keypad - . */
                      k == 0200              ? 'k'    : /* BRK */
                      k == 0256              ? 'l'    : /* SETUP */
                      k == 0262              ? 'o'    : /* NUM LOCK */
                                               '\033'); /* no such key */
         }
         else if (0310 <= k && k <= 0317) { /* shifted functions keys: CSI */
            sendnchars (3, "\033[2");
            sendchar (k-0227); /* decimal function key nbr */
            sendchar ('~');
         }
         else if (0350 <= k && k <= 0357) { /* unshifted functions keys: CSI */
            sendnchars (3, "\033[1");
            sendchar (k-0267); /* decimal function key nbr */
            sendchar ('~');
         }
         else if (k == 0345) {
            sendnchars (4, "\033[2J");      /* CLEAR */
         }
         else {                             /* others: CSI */
            sendnchars (2, "\033[");
            sendchar (k == 0300              ? 'H'    : /* HOME */
                      k <= 0306              ? k-0200 : /* cursor keys */
                      0322 <= k && k <= 0327 ? trans [k-0322] : /* 4-9 */
                      k == 0365              ? 'Z'    : /* shift CLEAR */
                                               '\033'); /* no such key */
         }
         if (! open_mode) { /* if not open mode append newline */
            sendchar ('\n');
         }
#else
         sendchar(k);
#endif
      }
      else
         ringbell();
} /* handle_input */


extern
void setrect(t, r)
register struct tstat *t;
Rectangle r;
{
   Srect = inset(r, BORDER);
   Trect = Srect;
   if (scroll_active)
      Trect.origin.x = Srect.origin.x + charwidth +
	               (Srect.corner.x - Srect.origin.x) % charwidth;
} /* setrect */


int wreceive(t)
register struct tstat *t;
{
	int got;
	int atime = 1;
	register ch = peek_ch;
	void term_mouse ();
        void reshape ();

	peek_ch = -1;
	alarm(1);
	for(;;) {
	        if (ch > 0)
		   return (ch);
		got = wait(NEED);
		if(P->state & MOVED) {
			setrect(t, D_rect);
			P->state &= ~MOVED;
		} else if(P->state & RESHAPED) {
			reshape(t,TRUE);
		}
		if(got & KBD)
			handle_input(t);
		if(got & ALARM) {
			cursor_on(t);
			tock = !tock;
			alarm(30 - realtime() % 30);
		}
		if(got & MOUSE) {
			term_mouse(t);
		}
		if(got & RCV)
			return rcvchar(t);
	}
} /* wreceive */


#undef transform
#define transform(x) if      (sel_but == 1)  x  = (x&6) >> 1;            \
                     else if (sel_but == 2)  x  = x & 1  |  (x&4) >> 1;  \
		     else                    x &= 3;                     \
		     if (del_but < copy_but) x  = (x >> 1) | (x << 1) & 3
static
int inv_kind (t, old_buts, buts, kind)
      register struct tstat *t;
      int old_buts, buts, *kind;
{
   int inv, old = *kind - select;

   transform (old_buts);  /* make "copy-bit" first, "delete-bit" second */
   transform (buts);
     /* the following looks like magic but is just boolean algebra */
   *kind  = old == buts  ?  0  :  old_buts | buts;
   inv    = old ^ *kind;
   *kind += select;
   return   inv + select + 3;  /* + 3 for inverse pattern */
}
#undef transform


#define rowof(ry)	  ((ry - Trect.origin.y) / charheight)
#define colof(cx)	  ((cx - Trect.origin.x) / charwidth)

#define in_scrollbar(xy)  (xy.x < Trect.origin.x - BORDER)

static
void term_mouse(t)
      register struct tstat *t;
{
   int   buts;
   Bool  scrolling;
   Point mouse_xy;

   if (!mouse_active) {
      if (r_butt()) {             /* do layers menu */
         while (r_butt());
       }
      else if (m_butt()) {        /* do own menu */
         do_menu (t, 2);
       }
      else if (l_butt()) {        /* wait till button released */
         request (NEED & ~MOUSE);
         wait (CPU);
         request (NEED);
       }
      if(mcursr >= 0) {
         mcursor_off(t);
       }
      return;
   }

   if ((buts = any_butt()) || mbuts) {  /* update mouse cursor */
      cancel |= !ptinrect (mouse_xy=Mouse.xy, P->layer->rect) | !is_current;
      mrow = rowof (mouse_xy.y);
      mrow = mrow < 0  ?  0  :  mrow >= nrows  ?  nrows-1  :  mrow;
      scrolling = in_scrollbar (mouse_xy);
      if (mbuts && !select_kind ||     /* point event, not a selection */
	  !mbuts && (scrolling || !(buts & sel_but))) {
	 mcol = colof(mouse_xy.x);      /* point "to" char */
	 mcol = scrolling  ?  -1
	                   :  mcol < 0  ?  0
			                :  mcol >= ncols  ?  ncols-1
					                  :  mcol;
         if (!mbuts) { /* just started pointing */
            tot_buts = buts;
            mrow_0 = mrow;
            mcol_0 = mcol;
         }
         else if (!buts) { /* just finished pointing */
            if (!cancel) {
               send_region (t, mrow_0, mcol_0, mrow_old, mcol_old,
                            tot_buts, FALSE);
               tot_buts = 0;
            }
            cancel   = FALSE;
         }
         else {
            tot_buts |= buts;
         }
      } /* point event */

      else {             /* selection */
	 mcol = colof(mouse_xy.x + charwidth/2);   /* point "between" chars */
	 mcol = mcol < 0  ?  0  :  mcol >= ncols  ?  ncols  :  mcol;
	 if (!mbuts) {               /* start selection */
	    mrow_0 = mrow;
	    mcol_0 = mcol;
	    select_kind = buts & copy_but ? (buts & del_but ? move : copy)
	                                  :  buts & del_but ? delete : select;
	 }
	 else {          /* already selecting */
	    if (!buts) {           /* end selection */
	       hilight_region (t, mrow_0, mcol_0, mrow_old, mcol_old,
			       select_kind);
	       if (!cancel)
		  send_region (t, mrow_0, mcol_0, mrow_old, mcol_old,
			       select_kind, TRUE);
	       cancel      = FALSE;
	       select_kind = 0;
	    }
	    else if (buts & ~mbuts & ~sel_but) {   /* add button */
	       hilight_region (t, mrow_0, mcol_0, mrow_old, mcol_old,
			       inv_kind (t, mbuts, buts, &select_kind));
	    }
	    hilight_region (t, mrow_old, mcol_old, mrow, mcol, select_kind);
	 }  /* already selecting */
      } /* selection */
      mbuts = buts;
      mrow_old = mrow;
      mcol_old = mcol;
      cursor_on (t);
   } /* buts || mbuts */
} /* term_mouse */


void reshape(t, notify)
register struct tstat *t;
Bool notify;
{
   int old_nrows = nrows;
   int old_ncols = ncols;
   P->state     &= ~RESHAPED;
   P->rect       = inset (P->layer->rect, INSET);
   D_rect        = P->rect;
   setrect (t, D_rect);
   ncols         = (Trect.corner.x - Trect.origin.x) / charwidth;
   nrows         = (Trect.corner.y - Trect.origin.y) / charheight;
   top_margin    = 1;
   bottom_margin = nrows;
   if (! notify  ||  ncols != old_ncols  ||  nrows != old_nrows) {
      row   = 1;
      col   = 1;
      if (notify) {
         send_reshaped (t);
      }
      clear_screen (t);
   }
} /* reshape */
