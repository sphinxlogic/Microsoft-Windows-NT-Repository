char *version_string = "imgrotate version 0.4";
