char *version_string = "xbfe version 0.4";
