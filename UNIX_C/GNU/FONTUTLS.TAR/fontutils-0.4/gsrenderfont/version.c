char *version_string = "bbcount version 0.4";
