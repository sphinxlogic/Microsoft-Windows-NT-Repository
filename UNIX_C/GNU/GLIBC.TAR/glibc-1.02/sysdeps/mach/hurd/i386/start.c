#define SET_SP(sp) \
  asm volatile ("movl %0, %%esp" : : "g" (sp) : "%esp")
#define GET_STACK(low, high)						      \
  ({									      \
    register vm_address_t ax asm ("%eax"), sp asm ("%esp");		      \
    high = sp;								      \
    low = ax;								      \
  })
#include <sysdeps/mach/hurd/start.c>
