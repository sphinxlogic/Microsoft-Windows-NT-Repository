#define	FUNC	cos
#include <../sysdeps/m68k/68881/acos.c>
