#define	FUNC	log10
#include <../sysdeps/m68k/68881/acos.c>
