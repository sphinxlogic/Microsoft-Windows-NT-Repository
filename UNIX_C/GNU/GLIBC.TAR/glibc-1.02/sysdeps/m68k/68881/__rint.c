#define	FUNC	__rint
#define	OP	intr
#include <../sysdeps/m68k/68881/acos.c>
