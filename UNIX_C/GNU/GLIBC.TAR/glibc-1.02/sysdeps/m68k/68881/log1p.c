#define	FUNC	log1p
#include <../sysdeps/m68k/68881/acos.c>
