#define	FUNC	tanh
#include <../sysdeps/m68k/68881/acos.c>
