#define	FUNC	tan
#include <../sysdeps/m68k/68881/acos.c>
