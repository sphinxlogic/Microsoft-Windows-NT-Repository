#define	FUNC	atan
#include <../sysdeps/m68k/68881/acos.c>
