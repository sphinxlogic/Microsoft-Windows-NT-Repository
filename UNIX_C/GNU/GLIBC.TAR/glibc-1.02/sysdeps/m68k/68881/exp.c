#define	FUNC	exp
#define	OP	etox
#include <../sysdeps/m68k/68881/acos.c>
