#define	FUNC	__expm1
#define	OP	expm1
#include <../sysdeps/m68k/68881/acos.c>
