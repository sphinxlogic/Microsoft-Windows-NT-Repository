#define	FUNC	atanh
#include <../sysdeps/m68k/68881/acos.c>
