#define	FUNC	sinh
#include <../sysdeps/m68k/68881/acos.c>
