#define	FUNC	log
#define	OP	logn
#include <../sysdeps/m68k/68881/acos.c>
