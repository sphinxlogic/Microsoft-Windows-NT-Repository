#define	FUNC	__isnan
#include <../sysdeps/m68k/68881/__isinf.c>
