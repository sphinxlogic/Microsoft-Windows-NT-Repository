/* We don't want any inlines when we might not have a 68881.  */
