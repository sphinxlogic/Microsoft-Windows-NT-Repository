#define	FUNC	fabs
#define	OP	abs
#include <../sysdeps/m68k/68881/acos.c>
