#define	NO_WAITPID
#include <sysdeps/posix/system.c>
