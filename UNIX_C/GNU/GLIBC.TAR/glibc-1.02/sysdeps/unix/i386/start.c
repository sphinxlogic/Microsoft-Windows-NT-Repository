#define	DUMMIES	dummy0
#include <sysdeps/unix/start.c>
