#define	NO_WAITPID
#include <sysdeps/posix/pipestream.c>
