#include <../sysdeps/unix/bsd/sun/sun3/start.c>
