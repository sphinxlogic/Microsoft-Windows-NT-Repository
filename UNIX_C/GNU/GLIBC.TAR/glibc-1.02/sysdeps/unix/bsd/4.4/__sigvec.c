#include <sysdeps/posix/__sigvec.c>
