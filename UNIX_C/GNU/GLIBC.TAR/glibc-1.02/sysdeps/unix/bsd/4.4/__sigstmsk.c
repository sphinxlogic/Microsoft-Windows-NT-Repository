#include <sysdeps/posix/__sigsetmask.c>
