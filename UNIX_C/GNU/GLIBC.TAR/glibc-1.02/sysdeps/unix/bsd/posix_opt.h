#define	_POSIX_JOB_CONTROL	1
#undef	_POSIX_SAVED_IDS
#define	_POSIX_CHOWN_RESTRICTED	1
#define	_POSIX_NO_TRUNC		-1
#define	_POSIX_VDISABLE		((unsigned char) -1)
