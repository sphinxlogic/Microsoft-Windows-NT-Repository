#define	FORK	__vfork
#define	NO_WAITPID
#include <../sysdeps/posix/pipestream.c>
