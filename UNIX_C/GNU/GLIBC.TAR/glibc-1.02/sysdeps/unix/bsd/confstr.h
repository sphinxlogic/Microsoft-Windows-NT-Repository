#define	CS_PATH	"/usr/ucb:/bin:/usr/bin"
