#define	DUMMIES	ignore0

#include <sysdeps/unix/start.c>
