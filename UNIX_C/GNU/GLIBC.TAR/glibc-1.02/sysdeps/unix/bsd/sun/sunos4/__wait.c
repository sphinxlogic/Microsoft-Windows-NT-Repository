#include <sysdeps/unix/bsd/4.4/__wait.c>
