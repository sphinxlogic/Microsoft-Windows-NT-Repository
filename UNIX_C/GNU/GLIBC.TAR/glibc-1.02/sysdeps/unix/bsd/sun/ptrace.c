#define	PTRACE_5ARGS_OK

#include <../sysdeps/unix/ptrace.c>
