#include <sysdeps/unix/bsd/4.4/__waitpid.c>
