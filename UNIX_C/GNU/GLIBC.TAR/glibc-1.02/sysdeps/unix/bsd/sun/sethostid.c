#include <sysdeps/stub/sethostid.c>
