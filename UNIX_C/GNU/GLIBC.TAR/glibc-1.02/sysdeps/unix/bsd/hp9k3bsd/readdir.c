/* hp9k3bsd has `getdirentries' like Sun.  */
#include <sysdeps/unix/bsd/sun/readdir.c>
