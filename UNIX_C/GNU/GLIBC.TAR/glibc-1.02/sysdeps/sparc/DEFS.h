#define	FUNC(name)	\
	.global name;	\
	.align 4;	\
	name:
