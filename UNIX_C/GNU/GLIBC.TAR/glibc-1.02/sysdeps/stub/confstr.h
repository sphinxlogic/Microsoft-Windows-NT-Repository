/* This file should define values for the strings returned by `confstr'.
   If _NAME is passed to `confstr', define NAME.  */

#define	CS_PATH	""
