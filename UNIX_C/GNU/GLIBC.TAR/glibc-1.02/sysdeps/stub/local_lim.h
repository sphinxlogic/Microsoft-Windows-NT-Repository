/* This file should define the implementaton-specific limits described
   in posix[12]_limits.h.  If there are no useful values to give a limit,
   don't define it.  */
