/* Define the machine-dependent type `jmp_buf'.  Stub version.  */

typedef int __jmp_buf[1];
