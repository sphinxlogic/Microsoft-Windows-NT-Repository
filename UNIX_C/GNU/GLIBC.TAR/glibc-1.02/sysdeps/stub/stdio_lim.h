#define	L_tmpnam	1
#define	TMPMAX		0
#define	L_ctermid	1
#define	L_cuserid	1
#define	FOPEN_MAX	16
#define	FILENAME_MAX	14
