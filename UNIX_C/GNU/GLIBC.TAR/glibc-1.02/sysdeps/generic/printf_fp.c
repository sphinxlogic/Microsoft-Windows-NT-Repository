/* Copyright (C) 1991 Free Software Foundation, Inc.
This file is part of the GNU C Library.

The GNU C Library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public License as
published by the Free Software Foundation; either version 2 of the
License, or (at your option) any later version.

The GNU C Library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

You should have received a copy of the GNU Library General Public
License along with the GNU C Library; see the file COPYING.LIB.  If
not, write to the Free Software Foundation, Inc., 675 Mass Ave,
Cambridge, MA 02139, USA.  */

#include <ansidecl.h>
#include <ctype.h>
#include <stdio.h>
#include <float.h>
#include <math.h>
#include <stdarg.h>
#include <stdlib.h>
#include <localeinfo.h>

#include <printf.h>

#define	outchar(x)							      \
  do									      \
    {									      \
      register CONST int outc = (x);					      \
      if (putc(outc, s) == EOF)						      \
	return -1;							      \
      else								      \
	++done;								      \
    } while (0)

int
DEFUN(__printf_fp, (s, info, args),
      FILE *s AND CONST struct printf_info *info AND va_list *args)
{
  int done = 0;

  LONG_DOUBLE fpnum;
  double fpart, ipart;
  int exp;
  int is_neg;
  int showdot;

  char ework[30];
  char *CONST eworkend = &ework[sizeof(ework) - 1];
  char fwork[LDBL_DIG];
  char iwork[LDBL_DIG + (LDBL_MAX_10_EXP > -LDBL_MIN_10_EXP ?
			 LDBL_MAX_10_EXP : -LDBL_MIN_10_EXP)];
  char *iworkend = &iwork[sizeof(iwork) - 1];
  register char *fw, *ew, *iw;

  /* Decimal point character.  */
  CONST char *CONST decimal = _numeric_info->decimal_point;

  char type = tolower(info->spec);
  CONST char pad = info->pad;
  int prec = info->prec;
  int width = info->width;

  if (info->is_long_double)
    fpnum = va_arg(*args, LONG_DOUBLE);
  else
    fpnum = (LONG_DOUBLE) va_arg(*args, double);

#ifdef	HANDLE_SPECIAL
  HANDLE_SPECIAL(done, s, info, fpnum);
#endif

#ifndef	IS_NEGATIVE
#define	IS_NEGATIVE(num)	((num) < 0)
#endif

  is_neg = IS_NEGATIVE(fpnum);
  if (is_neg)
    fpnum = - fpnum;

  if (prec == -1)
    prec = 6;
  
  if (type == 'g')
    {
      if (prec == 0)
	prec = 1;

      if (fpnum == 0 || fpnum >= 1e-4 && fpnum < pow(10.0, (double) prec))
	type = 'f';

      /* For 'g'/'G' format, the precision specifies "significant digits",
	 not digits to come after the decimal point.  */
	 --prec;
    }
  
  /* Break FPNUM into fractional and integral parts.  */
  fpart = modf((double) fpnum, &ipart);

  /* Initialize the exponent to zero.  */
  exp = 0;

  /* Convert the fractional part into FWORK.  */
  fw = fwork;
  if (fpart != 0.0)
    {
      int p = prec;

      /* Decrement EXP for each leading zero.  */
      while (fpart != 0)
	{
	  double digit;
	  fpart = modf(fpart * 10.0, &digit);
	  if (digit == 0)
	    --exp;
	  else
	    {
	      /* Found the first nonzero digit.  */
	      *fw++ = '0' + (unsigned int) digit;
	      --p;
	      break;
	    }
	}

      if (type == 'f')
	/* In %f format, the leading zeros count
	   towards filling the precision.  */
	p -= - exp;

      /* Convert the digits remaining up to the precision.  */
      while (fpart != 0.0 && p-- > 0)
	{
	  double digit;
	  fpart = modf(fpart * 10.0, &digit);
	  *fw++ = '0' + (unsigned int) digit;
	}

      if (fpart != 0.0)
	{
	  /* The fractional part has more digits than
	     the precision, so we need to round it.  */
	  double digit;
	  (void) modf(fpart * 10.0, &digit);
	  if ((unsigned int) digit >= 5)
	    {
	      /* Round up.  */

	      if (prec == 0)
		/* We're not printing any fractional digits,
		   so bump the integer part.  */
		++ipart;
	      else
		{
		  register char *p = fw - 1;
		  while (*p == '9' && p > fwork)
		    *p-- = '0';
		  if (*p == '9' && p == fwork)
		    {
		      /* 123.9999999... rounded up to 124;
			 increment the integer part and
			 zero the fractional part.  */
		      ++ipart;
		      *p = '0';
		    }
		  else
		    ++*p;
		}
	    }
	}

      /* Record in PREC how many digits we have converted.  */
      prec -= fw - fwork;
    }

  /* Convert the integer part into IWORK.  */
  iw = iworkend;
  if (ipart == 0)
    /* Make sure there is a digit before the decimal point.  */
    *iw-- = '0';
  else
    {
      while (ipart != 0)
	{
	  *iw-- = '0' + (unsigned int) ((modf(ipart / 10, &ipart) + .01) * 10);

	  /* Increment the exponent to account for this decimal place.  */
	  ++exp;
	}

      /* The exponent now accounts for each digit converted.
	 We don't want to count the first digit, so decrement it.  */
      --exp;
    }

  if (type != 'f')
    {
      /* The digits of IPART after the first are in the fractional part.  */
      prec -= (iworkend - iw) - 1;

      if (prec < 0)
	{
	  /* We have converted more digits than the precision specifies.  */

	  if (- prec >= fw - fwork)
	    {
	      /* All of FWORK is excess precision.  Toss FWORK,
		 and round the value printed in IWORK as necessary.  */

	      prec += fw - fwork;
	      fw = fwork;

	      if (prec < 0)
		{
		  /* Still more rounding to be done.  */
		  iworkend -= - prec;
		  if (*iworkend - '0' >= 5)
		    {
		      /* Round up.  */
		      register char *p = iworkend;
		      while (*p == '9' && p > iw)
			*p-- = '0';
		      if (*p == '9' && p == iw)
			{
			  *p = '0';
			  *iw-- = '1';
			}
		      else
			++*p;
		    }
		}
	    }
	  else
	    {
	      /* Round -PREC digits off the value printed in FWORK.  */
	      fw -= (-prec) - 1;
	      if (*fw - '0' >= 5)
		{
		  /* Round up.  */
		  register char *p = fw - 1;
		  while (*p == '9' && p > fwork)
		    *p-- = '0';
		  ++*p;
		}

	      if (type == 'g' && !info->alt)
		/* Trim trailing zeros.  */
		while (fw > fwork && fw[-1] == '0')
		  --fw;
	    }

	  prec = 0;
	}
    }

  if (!info->alt && tolower(info->spec) == 'g')
    {
      /* Remove trailing zeros from the fractional part.  */
      while (fw > fwork && fw[-1] == '0')
	--fw;
      if (type != 'f' && fw == fwork)
	/* All but the first digit in IWORK is also in the fractional part.
	   Remove trailing zeros there as well.  */
	while (iworkend > iw + 1 && *iworkend == '0')
	  --iworkend;

      /* Make sure we don't add more zeros for the precision.  */
      prec = 0;
    }

  showdot = (info->alt || fw > fwork || prec > 0 ||
	     (type == 'f' ? exp < 0 : iworkend - iw > 1));

  ew = eworkend;
  if (type != 'f')
    {
      /* Convert the exponent in EWORK.  */
      CONST int eneg = exp < 0;
      if (eneg)
	exp = - exp;
      while (exp > 0)
	{
	  *ew-- = '0' + (exp % 10);
	  exp /= 10;
	}
      /* Add leading zeros to ensure at least two digits.  */
      while (eworkend - ew < 2)
	*ew-- = '0';
      *ew-- = eneg ? '-' : '+';
      *ew-- = isupper(info->spec) ? 'E' : 'e';
    }

  width -= iworkend - iw;
  if (showdot)
    --width;
  width -= prec;
  width -= fw - fwork;
  width -= eworkend - ew;

  if (is_neg || info->showsign || info->space)
    --width;

  if (!info->left && pad == ' ')
    while (width-- > 0)
      outchar(' ');

  if (is_neg)
    outchar('-');
  else if (info->showsign)
    outchar('+');
  else if (info->space)
    outchar(' ');

  if (!info->left && pad == '0')
    while (width-- > 0)
      outchar('0');

  if (type == 'f')
    {
      /* Write the integral part.  */
      while (++iw <= iworkend)
	outchar(*iw);
      if (showdot)
	{
	  /* Write the dot and the leading zeros of the fractional part.  */
	  outchar(*decimal);
	  while (exp++ < 0)
	    outchar ('0');
	}
    }
  else
    {
      /* Write the first digit of the integer part.  */
      outchar(*++iw);
      if (showdot)
	{
	  /* Write the decimal point and the remaining digits of IPART,
	     which EXP makes the beginning of the fractional part.  */
	  outchar (*decimal);
	  while (++iw <= iworkend)
	    outchar (*iw);
	}
    }

  /* Write the fractional part.  */
  {
    register CONST char *p;
    for (p = fwork; p < fw; ++p)
      outchar(*p);
  }

  /* Pad with zeros to the precision.  */
  while (prec-- > 0)
    outchar ('0');

  /* Write the exponent.  */
  while (++ew <= eworkend)
    outchar(*ew);

  if (info->left)
    while (width-- > 0)
      outchar(' ');

  return done;
}
