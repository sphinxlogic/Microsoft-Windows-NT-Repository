/* Additions to std.h */

typedef byte bool;
#define false 0
#define true 1
