#include <stdio.h>

main()

{
    register char *s,*t;
    char topic[80],prevtopic[80];
    char stg[80],outstg[2048];
    char *osp;
    char *head;
    int references[2048],i,j,f;

    prevtopic[0] = '\0';
    i = 0;
    topic[0] = '\0';
    f = 0;
    printf(".in 8\n");
    while (gets(stg) != NULL) {
	for(s = stg,t = topic;*s != '\t';)
	    *t++ = *s++;
	*t = '\0';
	s++;
	if (strcmp(topic,prevtopic) != 0) {
	  output:
	    if (prevtopic[0] != '\0') {
		if (prevtopic[0] == '.') 
		    printf(".ti 0\n\\&%s,   ",prevtopic);
		else
		    printf(".ti 0\n%s,   ",prevtopic);
		if (i > 0)
		  printf("%d",references[0]);
		for(j=1;j < i;j++) {
		    printf(", %d",references[j]);
		}
		putchar('\n');
	    }
	    strcpy(prevtopic,topic);
	    references[0] = atoi(s);
	    i = 1;
	    if (f) exit(0);
	}
	else {
	    references[i++] = atoi(s);
	}
    }
    f = 1;
    goto output;
}
