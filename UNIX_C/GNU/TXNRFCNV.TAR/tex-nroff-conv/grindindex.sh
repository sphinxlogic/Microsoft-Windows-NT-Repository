sed -n "s/@$1{ //p" emacs.index | \
sed -e 's/	\([0-9]\)$/	00\1/' -e \
       's/	\([0-9][0-9]\)$/	0\1/' | sort | mkindex 
