/*
 *	VAX-11 "C" runtime string hacking replacement module
 *	(we need to make sure all the [.strings]string routines are in the
 *	 same module or we can get the VAX-11 "C" strings module
 *	 brought in by mistake!)
 */
#include "[.strings]strcat.c"
#include "[.strings]strcmp.c"
#include "[.strings]strcpy.c"
#include "[.strings]strlen.c"
#include "[.strings]strncat.c"
#include "[.strings]strncmp.c"
#include "[.strings]strncpy.c"
