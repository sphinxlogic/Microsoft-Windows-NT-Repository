/*
 *
 *	This function was not included in the VAX-11 "C" runtime system.
 *
 */
char *index(cp, character)
register char *cp;
register char character;
{
	do {
		/*
		 *	If we have found the index character, return the
		 *	pointer to it.
		 */
		if (*cp == character) return(cp);
		} while (*cp++);
	/*
	 *	Index character not found
	 */
	return(0);
}
