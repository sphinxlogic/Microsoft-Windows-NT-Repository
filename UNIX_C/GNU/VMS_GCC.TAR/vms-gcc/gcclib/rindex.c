/*
 *
 *	This function was not included in the VAX-11 "C" runtime system.
 *
 */
char *rindex(cp, character)
register char *cp;
register char character;
{
	register char *cp1;

	/*
	 *	Assume "not found"
	 */
	cp1 = 0;
	/*
	 *	Search for the index character
	 */
	do {
		/*
		 *	If this is the index character remember it as the
		 *	one most towards the end of the string.
		 */
		if (*cp == character) cp1 = cp;
	} while (*cp++);
	/*
	 *	Return the pointer to the index character
	 */
	return(cp1);
}
