/*	RMS - Include all RMS data structure definitions	*/

#include <nam.h>
#include <fab.h>
#include <rab.h>
#include <xab.h>
#include <rmsdef.h>
