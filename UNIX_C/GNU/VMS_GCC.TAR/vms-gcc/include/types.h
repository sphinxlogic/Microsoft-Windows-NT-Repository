/*
 *	VAX-11 "C" types
 */

#ifndef TYPES_H_DEFINED
#define TYPES_H_DEFINED
typedef long int time_t;
#endif	TYPES_H_DEFINED
