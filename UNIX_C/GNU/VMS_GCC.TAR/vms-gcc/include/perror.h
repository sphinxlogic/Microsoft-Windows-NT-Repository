/*
 *	Define the VAX-11 "C" runtime perror variables
 */
#define	sys_errlist	$$PsectAttributes_NOSHR$$sys_errlist
#define	sys_nerr	$$PsectAttributes_NOSHR$$sys_nerr
