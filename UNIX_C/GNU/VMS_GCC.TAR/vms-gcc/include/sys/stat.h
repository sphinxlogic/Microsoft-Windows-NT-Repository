/*
 *	Some UNIX programs want to find "stat" here
 */
#include <stat.h>
