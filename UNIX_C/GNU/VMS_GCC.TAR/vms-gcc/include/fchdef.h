/*
 * File Characteristics Bit Positions and Mask Definitions
 *	Provided as part of DEC/Shell V1.0
 */
#define FCH$V_ACL	0x00B			/* position of acl bit */
#define FCH$M_ACL	(1 << FCH$V_ACL) 	/* acl bit mask */
#define FCH$V_BADBLOCK	0x00E			/* position of badblk bit */
#define FCH$M_BADBLOCK	(1 << FCH$V_BADBLOCK)	/* badblock bit mask */
#define FCH$V_CONTIG	0x007			/* position of contig bit */
#define FCH$M_CONTIG	(1 << FCH$V_CONTIG)	/* contig bit mask */
#define FCH$V_CONTIGB	0x005			/* pos of cont best try bit */
#define FCH$M_CONTIGB	(1 << FCH$V_CONTIGB)	/* contig best try bit mask */
#define FCH$V_DIRECTORY	0x00D			/* position of directory bit */
#define FCH$M_DIRECTORY (1 << FCH$V_DIRECTORY)	/* directory bit mask */
#define FCH$V_ERASE	0x011			/* position of erase bit */
#define FCH$M_ERASE	(1 << FCH$V_ERASE)	/* erase bit mask */
#define FCH$V_LOCKED	0x006			/* position of locked bit */
#define FCH$M_LOCKED	(1 << FCH$V_LOCKED)	/* locked bit mask */
#define FCH$V_MARKDEL	0x00F			/* pos of mark for del bit */
#define FCH$M_MARKDEL	(1 << FCH$V_MARKDEL)	/* mark for delete bit mask */
#define FCH$V_NOBACKUP	0x001			/* pos of nobackup bit */
#define FCH$M_NOBACKUP	(1 << FCH$V_NOBACKUP)	/* nobackup bit mask */
#define FCH$V_NOCHARGE	0x010			/* pos of nocharge bit */
#define FCH$M_NOCHARGE	(1 << FCH$V_NOCHARGE)	/* nocharge bit mask */
#define FCH$V_READCHECK	0x003			/* pos of readcheck bit */
#define FCH$M_READCHECK	(1 << FCH$V_READCHECK)	/* readcheck bit mask */
#define FCH$V_SPOOL	0x00C			/* pos of spool bit */
#define FCH$M_SPOOL	(1 << FCH$V_SPOOL)	/* spool bit mask */
#define FCH$V_WRITCHECK	0x004			/* pos of writecheck bit */
#define FCH$M_WRITCHECK	(1 << FCH$V_WRITCHECK)	/* writecheck bit mask */
#define FCH$V_WRITEBACK	0x002			/* pos of writeback bit */
#define FCH$M_WRITEBACK	(1 << FCH$V_WRITEBACK)	/* writeback bit mask */
