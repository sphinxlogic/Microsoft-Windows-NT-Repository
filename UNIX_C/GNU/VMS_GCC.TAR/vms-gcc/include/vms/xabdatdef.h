
/*
 *
 *	$XABDATDEF
 *	Generated automatically by "vms_struct Version 1.00"
 *	Created from VMS definition file "xabdatdef"
 *	Thu Apr 11 16:28:16 1985
 *
 */
struct XABDAT {
	unsigned char XABDAT_un1[20];
	union {
		struct {
			char XABDAT_un3[4];
			unsigned long	XABDAT_un4;
#define	xab$l_cdt4 XABDAT_un2.XABDAT_un5.XABDAT_un4
		} XABDAT_un5;
		unsigned long	XABDAT_un6;
#define	xab$l_cdt0 XABDAT_un2.XABDAT_un6
		unsigned char	XABDAT_un7[1];
#define	xab$r_cdt_fields XABDAT_un2.XABDAT_un7
		unsigned long	XABDAT_un8[2];
#define	xab$q_cdt XABDAT_un2.XABDAT_un8
		unsigned char	XABDAT_un9[1];
#define	xab$r_cdt_overlay XABDAT_un2.XABDAT_un9
	} XABDAT_un2;
	union {
		struct {
			char XABDAT_un11[4];
			unsigned long	XABDAT_un12;
#define	xab$l_edt4 XABDAT_un10.XABDAT_un13.XABDAT_un12
		} XABDAT_un13;
		unsigned long	XABDAT_un14;
#define	xab$l_edt0 XABDAT_un10.XABDAT_un14
		unsigned char	XABDAT_un15[1];
#define	xab$r_edt_fields XABDAT_un10.XABDAT_un15
		unsigned long	XABDAT_un16[2];
#define	xab$q_edt XABDAT_un10.XABDAT_un16
		unsigned char	XABDAT_un17[1];
#define	xab$r_edt_overlay XABDAT_un10.XABDAT_un17
	} XABDAT_un10;
	union {
		struct {
			char XABDAT_un19[4];
			unsigned long	XABDAT_un20;
#define	xab$l_bdt4 XABDAT_un18.XABDAT_un21.XABDAT_un20
		} XABDAT_un21;
		unsigned long	XABDAT_un22;
#define	xab$l_bdt0 XABDAT_un18.XABDAT_un22
		unsigned char	XABDAT_un23[1];
#define	xab$r_bdt_fields XABDAT_un18.XABDAT_un23
		unsigned long	XABDAT_un24[2];
#define	xab$q_bdt XABDAT_un18.XABDAT_un24
		unsigned char	XABDAT_un25[1];
#define	xab$r_bdt_overlay XABDAT_un18.XABDAT_un25
	} XABDAT_un18;
	};

#define	XAB$C_DAT	18
#define	XAB$K_DATLEN_V2	36
#define	XAB$C_DATLEN_V2	36
#define	XAB$K_DATLEN	44
#define	XAB$C_DATLEN	44
