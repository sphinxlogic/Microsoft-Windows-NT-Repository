
/*
 *
 *	$FABDEF
 *	Generated automatically by "vms_struct Version 1.00"
 *	Created from VMS definition file "fabdef"
 *	Auxiliary information from file "/usr/include/vms/fabdef.i"
 *	Wed Jan  9 17:21:48 1985
 *
 */
struct FAB {
	unsigned char	fab$b_bid;
	unsigned char	fab$b_bln;
	union {
		unsigned char	FAB_un2[1];
#define	fab$r_ifi_bits FAB_un1.FAB_un2
		unsigned short	FAB_un3;
#define	fab$w_ifi FAB_un1.FAB_un3
		unsigned char	FAB_un4[1];
#define	fab$r_ifi_overlay FAB_un1.FAB_un4
	} FAB_un1;
	union {
		unsigned char	FAB_un6[1];
#define	fab$r_fop_bits FAB_un5.FAB_un6
		unsigned long	FAB_un7;
#define	fab$l_fop FAB_un5.FAB_un7
		unsigned char	FAB_un8[1];
#define	fab$r_fop_overlay FAB_un5.FAB_un8
	} FAB_un5;
	unsigned long	fab$l_sts;
	unsigned long	fab$l_stv;
	unsigned long	fab$l_alq;
	unsigned short	fab$w_deq;
	union {
		unsigned char	FAB_un10[1];
#define	fab$r_fac_bits FAB_un9.FAB_un10
		unsigned char	FAB_un11;
#define	fab$b_fac FAB_un9.FAB_un11
		unsigned char	FAB_un12[1];
#define	fab$r_fac_overlay FAB_un9.FAB_un12
	} FAB_un9;
	union {
		unsigned char	FAB_un14[1];
#define	fab$r_shr_bits FAB_un13.FAB_un14
		unsigned char	FAB_un15;
#define	fab$b_shr FAB_un13.FAB_un15
		unsigned char	FAB_un16[1];
#define	fab$r_shr_overlay FAB_un13.FAB_un16
	} FAB_un13;
	unsigned long	fab$l_ctx;
	unsigned char	fab$b_rtv;
	union {
		unsigned char	FAB_un18[1];
#define	fab$r_org_bits FAB_un17.FAB_un18
		unsigned char	FAB_un19;
#define	fab$b_org FAB_un17.FAB_un19
		unsigned char	FAB_un20[1];
#define	fab$r_org_overlay FAB_un17.FAB_un20
	} FAB_un17;
	union {
		unsigned char	FAB_un22[1];
#define	fab$r_rat_bits FAB_un21.FAB_un22
		unsigned char	FAB_un23;
#define	fab$b_rat FAB_un21.FAB_un23
		unsigned char	FAB_un24[1];
#define	fab$r_rat_overlay FAB_un21.FAB_un24
	} FAB_un21;
	unsigned char	fab$b_rfm;
	unsigned long	fab$l_jnl;
	struct XAB *	fab$l_xab;
	struct NAM *	fab$l_nam;
	char *	fab$l_fna;
	char *	fab$l_dna;
	unsigned char	fab$b_fns;
	unsigned char	fab$b_dns;
	unsigned short	fab$w_mrs;
	unsigned long	fab$l_mrn;
	unsigned short	fab$w_bls;
	unsigned char	fab$b_bks;
	unsigned char	fab$b_fsz;
	unsigned long	fab$l_dev;
	unsigned long	fab$l_sdc;
	unsigned short	fab$w_gbc;
	union {
		unsigned char	FAB_un26[1];
#define	fab$r_acmodes_bits FAB_un25.FAB_un26
		unsigned char	FAB_un27;
#define	fab$b_acmodes FAB_un25.FAB_un27
		unsigned char	FAB_un28[1];
#define	fab$r_acmodes_overlay FAB_un25.FAB_un28
	} FAB_un25;
	union {
		unsigned char	FAB_un30[1];
#define	fab$r_rcf_bits FAB_un29.FAB_un30
		unsigned char	FAB_un31;
#define	fab$b_rcf FAB_un29.FAB_un31
		unsigned char	FAB_un32[1];
#define	fab$r_rcf_overlay FAB_un29.FAB_un32
	} FAB_un29;
	unsigned char	FAB_Fill[4];
	};

#define	FAB$C_BID	3
#define	FAB$M_PPF_RAT	16320
#define	FAB$M_PPF_IND	16384
#define	FAB$M_MXV	2
#define	FAB$M_SUP	4
#define	FAB$M_TMP	8
#define	FAB$M_TMD	16
#define	FAB$M_DFW	32
#define	FAB$M_SQO	64
#define	FAB$M_RWO	128
#define	FAB$M_POS	256
#define	FAB$M_WCK	512
#define	FAB$M_NEF	1024
#define	FAB$M_RWC	2048
#define	FAB$M_DMO	4096
#define	FAB$M_SPL	8192
#define	FAB$M_SCF	16384
#define	FAB$M_DLT	32768
#define	FAB$M_NFS	65536
#define	FAB$M_UFO	131072
#define	FAB$M_PPF	262144
#define	FAB$M_INP	524288
#define	FAB$M_CTG	1048576
#define	FAB$M_CBT	2097152
#define	FAB$M_RCK	8388608
#define	FAB$M_NAM	16777216
#define	FAB$M_CIF	33554432
#define	FAB$M_ESC	134217728
#define	FAB$M_TEF	268435456
#define	FAB$M_OFP	536870912
#define	FAB$M_KFO	1073741824
#define	FAB$M_PUT	1
#define	FAB$M_GET	2
#define	FAB$M_DEL	4
#define	FAB$M_UPD	8
#define	FAB$M_TRN	16
#define	FAB$M_BIO	32
#define	FAB$M_BRO	64
#define	FAB$M_EXE	128
#define	FAB$M_SHRPUT	1
#define	FAB$M_SHRGET	2
#define	FAB$M_SHRDEL	4
#define	FAB$M_SHRUPD	8
#define	FAB$M_MSE	16
#define	FAB$M_NIL	32
#define	FAB$M_UPI	64
#define	FAB$C_SEQ	0
#define	FAB$C_REL	16
#define	FAB$C_IDX	32
#define	FAB$C_HSH	48
#define	FAB$M_FTN	1
#define	FAB$M_CR	2
#define	FAB$M_PRN	4
#define	FAB$M_BLK	8
#define	FAB$C_RFM_DFLT	2
#define	FAB$C_UDF	0
#define	FAB$C_FIX	1
#define	FAB$C_VAR	2
#define	FAB$C_VFC	3
#define	FAB$C_STM	4
#define	FAB$C_STMLF	5
#define	FAB$C_STMCR	6
#define	FAB$C_MAXRFM	6
#define	FAB$M_RU	1
#define	FAB$M_AI	2
#define	FAB$M_BI	4
#define	FAB$K_BLN	80
#define	FAB$C_BLN	80
#define	FAB$M_ORG	16
#define	FAB$M_LNM_MODE	1
#define	FAB$M_CHAN_MODE	4
#define	FAB$M_FILE_MODE	16
