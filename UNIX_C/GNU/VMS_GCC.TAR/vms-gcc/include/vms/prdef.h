
/*
 *
 *	$PRDEF
 *	Generated automatically by "vms_struct Version 1.00"
 *	Created from VMS definition file "prdef"
 *	Fri Jan  2 14:53:47 1987
 *
 */
#define	PR$_KSP	0
#define	PR$_ESP	1
#define	PR$_SSP	2
#define	PR$_USP	3
#define	PR$_ISP	4
#define	PR$_P0BR	8
#define	PR$_P0LR	9
#define	PR$_P1BR	10
#define	PR$_P1LR	11
#define	PR$_SBR	12
#define	PR$_SLR	13
#define	PR$_PCBB	16
#define	PR$_SCBB	17
#define	PR$_IPL	18
#define	PR$_ASTLVL	19
#define	PR$_SIRR	20
#define	PR$_SISR	21
#define	PR$_ICCS	24
#define	PR$_RXCS	32
#define	PR$_RXDB	33
#define	PR$_TXCS	34
#define	PR$_TXDB	35
#define	PR$_MAPEN	56
#define	PR$_TBIA	57
#define	PR$_TBIS	58
#define	PR$_SID	62
#define	PR$_TBCHK	63
#define	PR$_SID_TYP780	1
#define	PR$_SID_TYP750	2
#define	PR$_SID_TYP730	3
#define	PR$_SID_TYP790	4
#define	PR$_SID_TYP8SS	5
#define	PR$_SID_TYP8NN	6
#define	PR$_SID_TYPMAX	8
#define	PR$_SID_TYPUV1	7
#define	PR$_SID_TYPUV2	8
#define	PR$_WCSA	44
#define	PR$_WCSD	45
#define	PR$_SBIFS	48
#define	PR$_SBIS	49
#define	PR$_SBISC	50
#define	PR$_SBIMT	51
#define	PR$_SBIER	52
#define	PR$_SBITA	53
#define	PR$_SBIQC	54
#define	PR$_CMIERR	23
#define	PR$_CSRS	28
#define	PR$_CSRD	29
#define	PR$_CSTS	30
#define	PR$_CSTD	31
#define	PR$_TBDR	36
#define	PR$_CADR	37
#define	PR$_MCESR	38
#define	PR$_CAER	39
#define	PR$_UBRESET	55
#define	PR$_PAMACC	64
#define	PR$_PAMLOC	65
#define	PR$_CSWP	66
#define	PR$_MDECC	67
#define	PR$_MENA	68
#define	PR$_MDCTL	69
#define	PR$_MCCTL	70
#define	PR$_MERG	71
#define	PR$_CRBT	72
#define	PR$_DFI	73
#define	PR$_EHSR	74
#define	PR$_ACCS790	75
#define	PR$_STXCS	76
#define	PR$_STXDB	77
#define	PR$_LSPA	78
#define	PR$_RSPD	79
#define	PR$M_SID_SN	1
#define	PR$M_SID_PL	4096
#define	PR$M_SID_ECO	32768
#define	PR$M_SID_TYPE	16777216
