
/*
 *
 *	$XABFHCDEF
 *	Generated automatically by "vms_struct Version 1.00"
 *	Created from VMS definition file "xabfhcdef"
 *	Thu Apr 11 16:27:14 1985
 *
 */
struct XABFHC {
	unsigned char XABFHC_un1[8];
	unsigned char	xab$b_rfo;
	unsigned char	xab$b_atr;
	unsigned short	xab$w_lrl;
	union {
		struct {
			char XABFHC_un3[2];
			unsigned short	XABFHC_un4;
#define	xab$w_hbk2 XABFHC_un2.XABFHC_un5.XABFHC_un4
		} XABFHC_un5;
		unsigned short	XABFHC_un6;
#define	xab$w_hbk0 XABFHC_un2.XABFHC_un6
		unsigned char	XABFHC_un7[1];
#define	xab$r_hbk_fields XABFHC_un2.XABFHC_un7
		unsigned long	XABFHC_un8;
#define	xab$l_hbk XABFHC_un2.XABFHC_un8
		unsigned char	XABFHC_un9[1];
#define	xab$r_hbk_overlay XABFHC_un2.XABFHC_un9
	} XABFHC_un2;
	union {
		struct {
			char XABFHC_un11[2];
			unsigned short	XABFHC_un12;
#define	xab$w_ebk2 XABFHC_un10.XABFHC_un13.XABFHC_un12
		} XABFHC_un13;
		unsigned short	XABFHC_un14;
#define	xab$w_ebk0 XABFHC_un10.XABFHC_un14
		unsigned char	XABFHC_un15[1];
#define	xab$r_ebk_fields XABFHC_un10.XABFHC_un15
		unsigned long	XABFHC_un16;
#define	xab$l_ebk XABFHC_un10.XABFHC_un16
		unsigned char	XABFHC_un17[1];
#define	xab$r_ebk_overlay XABFHC_un10.XABFHC_un17
	} XABFHC_un10;
	unsigned short	xab$w_ffb;
	unsigned char XABFHC_un18[1];
	unsigned char	xab$b_hsz;
	unsigned short	xab$w_mrz;
	unsigned short	xab$w_dxq;
	unsigned short	xab$w_gbc;
	unsigned char XABFHC_un19[8];
	unsigned short	xab$w_verlimit;
	unsigned long	xab$l_sbn;
	};

#define	XAB$C_FHC	29
#define	XAB$K_FHCLEN	44
#define	XAB$C_FHCLEN	44
