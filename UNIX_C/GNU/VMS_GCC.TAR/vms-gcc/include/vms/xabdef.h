
/*
 *
 *	$XABDEF
 *	Generated automatically by "vms_struct Version 1.00"
 *	Created from VMS definition file "xabdef"
 *	Auxiliary information from file "/usr/include/vms/xabdef.i"
 *	Mon Feb 25 11:37:47 1985
 *
 */
struct XAB {
	unsigned char	xab$b_cod;
	unsigned char	xab$b_bln;
	unsigned char XAB_un1[2];
	struct XAB *	xab$l_nxt;
	unsigned short	xab$w_rvn;
	unsigned char XAB_un2[2];
	union {
		struct {
			char XAB_un4[4];
			unsigned long	XAB_un5;
#define	xab$l_rdt4 XAB_un3.XAB_un6.XAB_un5
		} XAB_un6;
		unsigned long	XAB_un7;
#define	xab$l_rdt0 XAB_un3.XAB_un7
		unsigned char	XAB_un8[1];
#define	xab$r_rdt_fields XAB_un3.XAB_un8
		unsigned long	XAB_un9[2];
#define	xab$q_rdt XAB_un3.XAB_un9
		unsigned char	XAB_un10[1];
#define	xab$r_rdt_overlay XAB_un3.XAB_un10
	} XAB_un3;
	unsigned char XAB_un11[2];
	unsigned char	xab$b_bkz;
	};

#define	XAB$C_CXT_VER1	1
