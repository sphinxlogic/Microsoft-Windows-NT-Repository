
/*
 *
 *	$NAMDEF
 *	Generated automatically by "vms_struct Version 1.00"
 *	Created from VMS definition file "namdef"
 *	Auxiliary information from file "/usr/include/vms/namdef.i"
 *	Thu Jan  3 14:42:00 1985
 *
 */
struct NAM {
	unsigned char	nam$b_bid;
	unsigned char	nam$b_bln;
	unsigned char	nam$b_rss;
	unsigned char	nam$b_rsl;
	char *	nam$l_rsa;
	union {
		unsigned char	NAM_un2[1];
#define	nam$r_nop_bits NAM_un1.NAM_un2
		unsigned char	NAM_un3;
#define	nam$b_nop NAM_un1.NAM_un3
		unsigned char	NAM_un4[1];
#define	nam$r_nop_overlay NAM_un1.NAM_un4
	} NAM_un1;
	unsigned char	nam$b_rfs;
	unsigned char	nam$b_ess;
	unsigned char	nam$b_esl;
	char *	nam$l_esa;
	char *	nam$l_rlf;
	unsigned char	nam$t_dvi[1];
	unsigned char NAM_un5[15];
	union {
		unsigned short	NAM_un7;
#define	nam$w_fid_num NAM_un6.NAM_un7
		unsigned char	NAM_un8[1];
#define	nam$r_fid_fields NAM_un6.NAM_un8
		unsigned short	NAM_un9;
#define	nam$w_fid NAM_un6.NAM_un9
		unsigned char	NAM_un10[1];
#define	nam$r_fid_overlay NAM_un6.NAM_un10
	} NAM_un6;
	unsigned short	nam$w_fid_seq;
	union {
		struct {
			char NAM_un12[1];
			unsigned char	NAM_un13;
#define	nam$b_fid_nmx NAM_un11.NAM_un14.NAM_un13
		} NAM_un14;
		unsigned char	NAM_un15;
#define	nam$b_fid_rvn NAM_un11.NAM_un15
		unsigned char	NAM_un16[1];
#define	nam$r_fid_rvn_fields NAM_un11.NAM_un16
		unsigned short	NAM_un17;
#define	nam$w_fid_rvn NAM_un11.NAM_un17
		unsigned char	NAM_un18[1];
#define	nam$r_fid_rvn_overlay NAM_un11.NAM_un18
	} NAM_un11;
	union {
		unsigned short	NAM_un20;
#define	nam$w_did_num NAM_un19.NAM_un20
		unsigned char	NAM_un21[1];
#define	nam$r_did_fields NAM_un19.NAM_un21
		unsigned short	NAM_un22;
#define	nam$w_did NAM_un19.NAM_un22
		unsigned char	NAM_un23[1];
#define	nam$r_did_overlay NAM_un19.NAM_un23
	} NAM_un19;
	unsigned short	nam$w_did_seq;
	union {
		struct {
			char NAM_un25[1];
			unsigned char	NAM_un26;
#define	nam$b_did_nmx NAM_un24.NAM_un27.NAM_un26
		} NAM_un27;
		unsigned char	NAM_un28;
#define	nam$b_did_rvn NAM_un24.NAM_un28
		unsigned char	NAM_un29[1];
#define	nam$r_did_rvn_fields NAM_un24.NAM_un29
		unsigned short	NAM_un30;
#define	nam$w_did_rvn NAM_un24.NAM_un30
		unsigned char	NAM_un31[1];
#define	nam$r_did_rvn_overlay NAM_un24.NAM_un31
	} NAM_un24;
	union {
		unsigned char	NAM_un33[1];
#define	nam$r_wcc_bits NAM_un32.NAM_un33
		unsigned long	NAM_un34;
#define	nam$l_wcc NAM_un32.NAM_un34
		unsigned char	NAM_un35[1];
#define	nam$r_wcc_overlay NAM_un32.NAM_un35
	} NAM_un32;
	union {
		unsigned char	NAM_un37[1];
#define	nam$r_fnb_bits2 NAM_un36.NAM_un37
		unsigned char	NAM_un38[1];
#define	nam$r_fnb_bits1 NAM_un36.NAM_un38
		unsigned char	NAM_un39[1];
#define	nam$r_fnb_bits0 NAM_un36.NAM_un39
		unsigned long	NAM_un40;
#define	nam$l_fnb NAM_un36.NAM_un40
		unsigned char	NAM_un41[1];
#define	nam$r_fnb_overlay NAM_un36.NAM_un41
	} NAM_un36;
	unsigned char	nam$b_node;
	unsigned char	nam$b_dev;
	unsigned char	nam$b_dir;
	unsigned char	nam$b_name;
	unsigned char	nam$b_type;
	unsigned char	nam$b_ver;
	unsigned char NAM_un42[2];
	unsigned long	nam$l_node;
	unsigned long	nam$l_dev;
	unsigned long	nam$l_dir;
	unsigned long	nam$l_name;
	unsigned long	nam$l_type;
	unsigned long	nam$l_ver;
	};

#define	NAM$C_BID	2
#define	NAM$C_MAXRSS	255
#define	NAM$C_MAXRSSLCL	255
#define	NAM$M_PWD	1
#define	NAM$M_FILL_1	2
#define	NAM$M_FILL_2	4
#define	NAM$M_SYNCHK	8
#define	NAM$M_NOCONCEAL	16
#define	NAM$M_SLPARSE	32
#define	NAM$M_SRCHXABS	64
#define	NAM$C_UFS	0
#define	NAM$C_RMS11	1
#define	NAM$C_RMS20	2
#define	NAM$C_RMS32	3
#define	NAM$C_FCS11	4
#define	NAM$C_RT11FS	5
#define	NAM$C_TOPS20FS	7
#define	NAM$C_TOPS10FS	8
#define	NAM$C_RMS32S	10
#define	NAM$C_DVI	16
#define	NAM$M_IFI	65536
#define	NAM$M_SRCHNMF	1073741824
#define	NAM$M_SVCTX	-2147483648
#define	NAM$K_BLN_V2	56
#define	NAM$C_BLN_V2	56
#define	NAM$M_EXP_VER	1
#define	NAM$M_EXP_TYPE	2
#define	NAM$M_EXP_NAME	4
#define	NAM$M_WILD_VER	8
#define	NAM$M_WILD_TYPE	16
#define	NAM$M_WILD_NAME	32
#define	NAM$M_EXP_DIR	64
#define	NAM$M_EXP_DEV	128
#define	NAM$M_WILDCARD	256
#define	NAM$M_SEARCH_LIST	2048
#define	NAM$M_CNCL_DEV	4096
#define	NAM$M_ROOT_DIR	8192
#define	NAM$M_LOWVER	16384
#define	NAM$M_HIGHVER	32768
#define	NAM$M_PPF	65536
#define	NAM$M_NODE	131072
#define	NAM$M_QUOTED	262144
#define	NAM$M_GRP_MBR	524288
#define	NAM$M_WILD_DIR	1048576
#define	NAM$M_DIR_LVLS	14680064
#define	NAM$M_WILD_UFD	16777216
#define	NAM$M_WILD_SFD1	33554432
#define	NAM$M_WILD_SFD2	67108864
#define	NAM$M_WILD_SFD3	134217728
#define	NAM$M_WILD_SFD4	268435456
#define	NAM$M_WILD_SFD5	536870912
#define	NAM$M_WILD_SFD6	1073741824
#define	NAM$M_WILD_SFD7	-2147483648
#define	NAM$M_WILD_GRP	16777216
#define	NAM$M_WILD_MBR	33554432
#define	NAM$K_BLN_DIRWC	96
#define	NAM$C_BLN_DIRWC	96
#define	NAM$K_BLN	96
#define	NAM$C_BLN	96
