
/*
 *
 *	$PRVDEF
 *	Generated automatically by "vms_struct Version 1.00"
 *	Created from VMS definition file "prvdef"
 *	Thu Jan  3 22:20:31 1985
 *
 */
#define	PRV$M_CMKRNL	1
#define	PRV$M_CMEXEC	2
#define	PRV$M_SYSNAM	4
#define	PRV$M_GRPNAM	8
#define	PRV$M_ALLSPOOL	16
#define	PRV$M_DETACH	32
#define	PRV$M_DIAGNOSE	64
#define	PRV$M_LOG_IO	128
#define	PRV$M_GROUP	256
#define	PRV$M_NOACNT	512
#define	PRV$M_PRMCEB	1024
#define	PRV$M_PRMMBX	2048
#define	PRV$M_PSWAPM	4096
#define	PRV$M_SETPRI	8192
#define	PRV$M_SETPRV	16384
#define	PRV$M_TMPMBX	32768
#define	PRV$M_WORLD	65536
#define	PRV$M_MOUNT	131072
#define	PRV$M_OPER	262144
#define	PRV$M_EXQUOTA	524288
#define	PRV$M_NETMBX	1048576
#define	PRV$M_VOLPRO	2097152
#define	PRV$M_PHY_IO	4194304
#define	PRV$M_BUGCHK	8388608
#define	PRV$M_PRMGBL	16777216
#define	PRV$M_SYSGBL	33554432
#define	PRV$M_PFNMAP	67108864
#define	PRV$M_SHMEM	134217728
#define	PRV$M_SYSPRV	268435456
#define	PRV$M_BYPASS	536870912
#define	PRV$M_SYSLCK	1073741824
#define	PRV$M_SHARE	-2147483648
#define	PRV$M_ACNT	512
#define	PRV$M_ALTPRI	8192
