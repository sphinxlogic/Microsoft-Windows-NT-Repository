/*
 *
 *	$IRPDEF
 *	Generated automatically by "vms_struct Version 1.00"
 *	Created from VMS definition file "irpdef.mar"
 *	Auxiliary information from file "/usr/include/vms/irpdef.i"
 *	Thu Jan  3 14:29:58 1985
 *
 */
struct IRP {
	struct IRP *	irp$l_ioqfl;
	struct IRP *	irp$l_ioqbl;
	unsigned short	irp$w_size;
	unsigned char	irp$b_type;
	unsigned char	irp$b_rmod;
	unsigned long	irp$l_pid;
	unsigned long	irp$l_ast;
	unsigned long	irp$l_astprm;
	unsigned long	irp$l_wind;
	struct UCB *	irp$l_ucb;
	unsigned short	irp$w_func;
	unsigned char	irp$b_efn;
	unsigned char	irp$b_pri;
	unsigned short *	irp$l_iosb;
	unsigned short	irp$w_chan;
	unsigned short	irp$w_sts;
	unsigned long *	irp$l_svapte;
	unsigned short	irp$w_boff;
	unsigned short	irp$w_bcnt;
	unsigned short	irp$w_bcnt1;
	unsigned char IRP_un1[2];
	union {
		unsigned long	IRP_un3;
#define	irp$l_media IRP_un2.IRP_un3
		unsigned long	IRP_un4;
#define	irp$l_iost1 IRP_un2.IRP_un4
	} IRP_un2;
	union {
		unsigned char	IRP_un6;
#define	irp$b_carcon IRP_un5.IRP_un6
		unsigned long	IRP_un7;
#define	irp$l_tt_term IRP_un5.IRP_un7
		unsigned long	IRP_un8;
#define	irp$l_iost2 IRP_un5.IRP_un8
	} IRP_un5;
	union {
		struct {
			char IRP_un10[4];
			unsigned long	IRP_un11;
#define	irp$l_obcnt IRP_un9.IRP_un12.IRP_un11
		} IRP_un12;
		struct {
			char IRP_un13[4];
			unsigned short	IRP_un14;
#define	irp$w_obcnt IRP_un9.IRP_un15.IRP_un14
		} IRP_un15;
		unsigned short	IRP_un16;
#define	irp$w_abcnt IRP_un9.IRP_un16
		unsigned long	IRP_un17;
#define	irp$l_abcnt IRP_un9.IRP_un17
		unsigned long	IRP_un18[2];
#define	irp$q_tt_state IRP_un9.IRP_un18
		unsigned long	IRP_un19[2];
#define	irp$q_station IRP_un9.IRP_un19
		unsigned long	IRP_un20[2];
#define	irp$q_nt_prvmsk IRP_un9.IRP_un20
	} IRP_un9;
	union {
		unsigned long	IRP_un22;
#define	irp$l_jnl_seqno IRP_un21.IRP_un22
		unsigned long	IRP_un23;
#define	irp$l_segvbn IRP_un21.IRP_un23
	} IRP_un21;
	union {
		unsigned short	IRP_un25;
#define	irp$w_tt_prmpt IRP_un24.IRP_un25
		unsigned long	IRP_un26;
#define	irp$l_diagbuf IRP_un24.IRP_un26
	} IRP_un24;
	unsigned long	irp$l_seqnum;
	unsigned long	irp$l_extend;
	unsigned long	irp$l_arb;
	unsigned long	irp$l_keydesc;
	unsigned long	irp$l_fqfl;
	unsigned long	irp$l_fqbl;
	unsigned short	irp$w_cdrpsize;
	unsigned char	irp$b_cd_type;
	unsigned char	irp$b_fipl;
	unsigned long	irp$l_fpc;
	unsigned long	irp$l_fr3;
	unsigned long	irp$l_fr4;
	unsigned long	irp$l_savd_rtn;
	unsigned long	irp$l_msg_buf;
	unsigned long	irp$l_rspid;
	unsigned long	irp$l_cdt;
	unsigned long	irp$l_rwcptr;
	union {
		unsigned long	IRP_un28;
#define	irp$l_val1 IRP_un27.IRP_un28
		unsigned long	IRP_un29;
#define	irp$l_lbufh_ad IRP_un27.IRP_un29
	} IRP_un27;
	union {
		unsigned long	IRP_un31;
#define	irp$l_fill_val IRP_un30.IRP_un31
		unsigned long	IRP_un32;
#define	irp$l_val2 IRP_un30.IRP_un32
		unsigned char	IRP_un33[1];
#define	irp$t_lbufhndl IRP_un30.IRP_un33
		unsigned long	IRP_un34;
#define	irp$l_lboff IRP_un30.IRP_un34
	} IRP_un30;
	union {
		unsigned long	IRP_un36;
#define	irp$l_val3 IRP_un35.IRP_un36
		unsigned long	IRP_un37;
#define	irp$l_rbufh_ad IRP_un35.IRP_un37
	} IRP_un35;
	union {
		unsigned long	IRP_un39;
#define	irp$l_val4 IRP_un38.IRP_un39
		unsigned long	IRP_un40;
#define	irp$l_rboff IRP_un38.IRP_un40
	} IRP_un38;
	union {
		unsigned long	IRP_un42;
#define	irp$l_val5 IRP_un41.IRP_un42
		unsigned long	IRP_un43;
#define	irp$l_ubarsrce IRP_un41.IRP_un43
		unsigned long	IRP_un44;
#define	irp$l_xct_len IRP_un41.IRP_un44
	} IRP_un41;
	union {
		unsigned long	IRP_un46;
#define	irp$l_cnxsvapte IRP_un45.IRP_un46
		unsigned long	IRP_un47;
#define	irp$l_val6 IRP_un45.IRP_un47
		unsigned long	IRP_un48;
#define	irp$l_dutuflags IRP_un45.IRP_un48
	} IRP_un45;
	union {
		struct {
			char IRP_un50[2];
			unsigned short	IRP_un51;
#define	irp$w_endmsgsiz IRP_un49.IRP_un52.IRP_un51
		} IRP_un52;
		struct {
			char IRP_un53[2];
			unsigned short	IRP_un54;
#define	irp$w_cnxbcnt IRP_un49.IRP_un55.IRP_un54
		} IRP_un55;
		unsigned short	IRP_un56;
#define	irp$w_cnxboff IRP_un49.IRP_un56
		unsigned long	IRP_un57;
#define	irp$l_val7 IRP_un49.IRP_un57
		unsigned short	IRP_un58;
#define	irp$w_dutucntr IRP_un49.IRP_un58
	} IRP_un49;
	union {
		struct {
			char IRP_un60[3];
			unsigned char	IRP_un61;
#define	irp$b_cltsts IRP_un59.IRP_un62.IRP_un61
		} IRP_un62;
		struct {
			char IRP_un63[2];
			unsigned char	IRP_un64;
#define	irp$b_cnxrmod IRP_un59.IRP_un65.IRP_un64
		} IRP_un65;
		unsigned short	IRP_un66;
#define	irp$w_cnxbcnt1 IRP_un59.IRP_un66
		unsigned long	IRP_un67;
#define	irp$l_val8 IRP_un59.IRP_un67
	} IRP_un59;
	unsigned long	irp$l_msgbld;
	unsigned long	irp$l_savepc;
	unsigned short	irp$w_sendseqnm;
	unsigned char	irp$b_cnxstate;
	unsigned char IRP_un68[1];
	union {
		unsigned long	IRP_un70;
#define	irp$l_btx IRP_un69.IRP_un70
		unsigned long	IRP_un71;
#define	irp$l_retrspid IRP_un69.IRP_un71
	} IRP_un69;
	unsigned long	irp$l_val9;
	unsigned long	irp$l_val10;
	};

#define	IRP$M_FCODE	63
#define	IRP$M_BUFIO	1
#define	IRP$M_FUNC	2
#define	IRP$M_PAGIO	4
#define	IRP$M_COMPLX	8
#define	IRP$M_VIRTUAL	16
#define	IRP$M_CHAINED	32
#define	IRP$M_SWAPIO	64
#define	IRP$M_DIAGBUF	128
#define	IRP$M_PHYSIO	256
#define	IRP$M_TERMIO	512
#define	IRP$M_MBXIO	1024
#define	IRP$M_EXTEND	2048
#define	IRP$M_FILACP	4096
#define	IRP$M_MVIRP	8192
#define	IRP$M_JNL_REMREQ	16384
#define	IRP$M_KEY	32768
#define	IRP$K_CDRP	96
#define	IRP$C_CDRP	96
#define	IRP$K_BT_LEN	160
#define	IRP$C_BT_LEN	160
#define	IRP$K_CD_LEN	168
#define	IRP$C_CD_LEN	168
#define	IRP$K_NORMAL	0
#define	IRP$K_REQUESTOR	1
#define	IRP$K_PARTNER	2
#define	IRP$K_CM_LENGTH	192
#define	IRP$K_CM_LONG_LENGTH	196
#define	IRP$K_LENGTH	196
#define	IRP$C_LENGTH	196
