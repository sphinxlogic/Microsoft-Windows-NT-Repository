
/*
 *
 *	$ADPDEF
 *	Generated automatically by "vms_struct Version 1.00"
 *	Created from VMS definition file "adpdef"
 *	Auxiliary information from file "/usr/include/vms/adpdef.i"
 *	Thu Jan  3 17:37:54 1985
 *
 */
struct ADP {
	char *	adp$l_csr;
	struct ADP *	adp$l_link;
	unsigned short	adp$w_size;
	unsigned char	adp$b_type;
	unsigned char	adp$b_number;
	unsigned short	adp$w_tr;
	unsigned short	adp$w_adptype;
	union {
		unsigned long	ADP_un2;
#define	adp$l_crb ADP_un1.ADP_un2
		char **	ADP_un3;
#define	adp$l_vector ADP_un1.ADP_un3
	} ADP_un1;
	union {
		unsigned long	ADP_un5;
#define	adp$l_mbascb ADP_un4.ADP_un5
		unsigned long	ADP_un6;
#define	adp$l_prqqfl ADP_un4.ADP_un6
		struct FKB *	ADP_un7;
#define	adp$l_dpqfl ADP_un4.ADP_un7
	} ADP_un4;
	union {
		unsigned long	ADP_un9;
#define	adp$l_mbaspte ADP_un8.ADP_un9
		unsigned long	ADP_un10;
#define	adp$l_prqqbl ADP_un8.ADP_un10
		struct FKB *	ADP_un11;
#define	adp$l_dpqbl ADP_un8.ADP_un11
	} ADP_un8;
	unsigned long	adp$l_avector;
	unsigned long	adp$l_bi_only;
	unsigned char ADP_un12[12];
	union {
		unsigned long	ADP_un14;
#define	adp$l_shb ADP_un13.ADP_un14
		struct FKB *	ADP_un15;
#define	adp$l_mrqfl ADP_un13.ADP_un15
	} ADP_un13;
	union {
		unsigned char	ADP_un17;
#define	adp$b_port ADP_un16.ADP_un17
		unsigned long	ADP_un18;
#define	adp$l_mrqbl ADP_un16.ADP_un18
	} ADP_un16;
	unsigned long	adp$l_intd;
	unsigned char ADP_un19[8];
	unsigned long	adp$l_ubascb;
	unsigned char ADP_un20[12];
	unsigned long	adp$l_ubaspte;
	unsigned char ADP_un21[4];
	unsigned long	adp$l_mractmdrs;
	unsigned short	adp$w_dpbitmap;
	unsigned short	adp$w_mrnfence;
	unsigned short	adp$w_mrnregary;
	unsigned char ADP_un22[246];
	unsigned short	adp$w_mrffence;
	unsigned short	adp$w_mrfregary;
	unsigned char ADP_un23[246];
	unsigned short	adp$w_umr_dis;
	};

#define	ADP$K_MBAADPLEN	48
#define	ADP$C_MBAADPLEN	48
#define	ADP$K_DRADPLEN	48
#define	ADP$C_DRADPLEN	48
#define	ADP$K_CIADPLEN	48
#define	ADP$C_CIADPLEN	48
#define	ADP$K_MPMADPLEN	68
#define	ADP$C_MPMADPLEN	68
#define	ADP$K_UBAADPLEN	600
#define	ADP$C_UBAADPLEN	600
#define	ADP$C_NUMDATAP	16
