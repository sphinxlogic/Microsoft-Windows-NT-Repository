/*
 *	VAX-11 "C" runtime compatible setjmp
 */
typedef int jmp_buf[15];
