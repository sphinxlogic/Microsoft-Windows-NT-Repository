Elvis is a clone of vi/ex, the standard UNIX editor.  Elvis supports
nearly all of the vi/ex commands, in both visual mode and colon mode.

Elvis runs under BSD UNIX, AT&T SysV UNIX, SCO Xenix, Minix, MS-DOS
(Turbo-C or MSC 5.1), Atari TOS, OS9/68000, Coherent, VMS, and AmigaDos.
Ports to other operating systems are in progress; contact me before you
start porting it to some other OS, because somebody else may have
already done it for you.

Elvis is freely redistributable, in either source form or executable
form.  There are no restrictions on how you may use it.

The file "elvisman.txt" contains the manual for elvis.  It is a plain
ASCII file with nothing more exotic than a newline character.  It is
formatted for 66-line, 80-column pages.  There may also be an archive of
"*.ms" and "*.man" files, which contain the TROFF source text used to
generate that manual.

The file named "Makefile.mix" is used to compile elvis for all systems
except VMS and possibly MS-DOS.  You should copy "Makefile.mix" to
"Makefile", and then edit "Makefile" to select the appropriate group of
settings for your system.


Author: Steve Kirkendall
	14407 SW Teal Blvd. #C
	Beaverton, OR   97005

E-mail:	kirkenda@cs.pdx.edu

Phone:	(503) 643-6980
