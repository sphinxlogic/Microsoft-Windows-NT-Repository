/* Linked with ar.o to flag that this program is 'ar' (not 'ranlib'). */

int is_ranlib = 0;
