
void EXFUN(bfd_fatal,(CONST char *));
PTR EXFUN(xmalloc,(unsigned int));
void EXFUN(fatal,(CONST char *,...));


