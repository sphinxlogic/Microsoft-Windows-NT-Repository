/* Linked with copy.o to flag that this program is 'strip' (not 'copy'). */

int is_strip = 1;
