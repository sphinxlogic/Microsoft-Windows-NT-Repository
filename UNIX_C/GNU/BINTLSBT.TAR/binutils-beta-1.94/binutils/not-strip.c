/* Linked with copy.o to flag that this program is 'copy' (not 'strip'). */

int is_strip = 0;
