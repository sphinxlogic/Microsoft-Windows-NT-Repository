
void EXFUN(find_constructors,(void));
void EXFUN(ldlang_check_for_constructors,(
				     struct
				     lang_input_statement_struct *));


void EXFUN(ldlang_add_constructor,(ldsym_type *name));

