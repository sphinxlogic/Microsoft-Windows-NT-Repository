

void EXFUN(do_indirect, (ldsym_type *));
void EXFUN(add_indirect,(asymbol **));
