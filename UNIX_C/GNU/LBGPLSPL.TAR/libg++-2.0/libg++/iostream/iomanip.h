#ifndef IOMANIPdeclare

#define IOMANIPdeclare(T) \

IOMANIPdeclare(int);
IOMANIPdeclare(long);

#endif /*!IOMANIPdeclare*/
