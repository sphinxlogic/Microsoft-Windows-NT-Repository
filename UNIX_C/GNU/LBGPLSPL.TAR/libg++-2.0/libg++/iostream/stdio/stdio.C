#include <stdioprivate.h>

int __underflow(FILE* stream)
{
    return ((streambuf*)stream)->underflow();
}

int __overflow(FILE* stream, int c)
{
    return ((streambuf*)stream)->overflow(c);
}

extern "C" void _cleanup() { streambuf::flush_all(); } // For GNU libc.
