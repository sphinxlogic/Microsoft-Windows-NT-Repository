#include "stdioprivate.h"

extern "C" int fputs(const char *str, FILE *fp)
{
    if (!__validfp(fp))
	return EOF;
    return ((streambuf*)fp)->sputn(str, strlen(str));
}
