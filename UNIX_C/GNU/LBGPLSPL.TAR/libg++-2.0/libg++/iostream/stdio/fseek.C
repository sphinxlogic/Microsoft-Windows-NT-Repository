#include <stdioprivate.h>

extern "C" long int fseek(FILE* fp, long int offset, int whence)
{
    if (!__validfp(fp))
	return EOF;
    return ((streambuf*)fp)->seekoff(offset, (_seek_dir)whence);
}
