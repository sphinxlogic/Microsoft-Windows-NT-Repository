#include <stdioprivate.h>

extern "C" long int ftell(FILE* fp)
{
    if (!__validfp(fp))
	return EOF;
    return ((streambuf*)fp)->seekoff(0, ios::cur);
}
