#include <stream.h>
#include <String.h>

String s1 = String("Hello ");
String s2 = String(" world!\n");

int f()
{
	cout << s1 + s2;
        return cout.good();
}

