#include <std.h>

extern int f();

int main()
{
        errno = f();
	fprintf(stderr, "Errno: %d\n",errno);
        exit(0);
}
