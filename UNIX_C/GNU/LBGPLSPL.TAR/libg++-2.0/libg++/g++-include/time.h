#ifndef time_h

extern "C" {

#ifdef __time_h_recursive
#include_next <time.h>
#else
#define __time_h_recursive

#include <_G_config.h>

// A clean way to use and/or define time_t might allow removal of this crud.
#ifndef __sys_time_h_recursive
#define time __hide_time
#define clock __hide_clock
#define difftime __hide_difftime
#define gmtime __hide_gmtime
#define localtime __hide_localtime
#define ctime __hide_ctime
#define asctime __hide_asctime
#define strftime __hide_strftime
#endif
#define mktime __hide_mktime
#define tzset __hide_tzset
#define tzsetwall __hide_tzsetwall
#define getitimer __hide_getitimer
#define setitimer __hide_setitimer
#define gettimeofday __hide_gettimeofday
#define settimeofday __hide_settimeofday

#ifdef VMS
	struct  unix_time
	{
		long int	tv_sec;
		long int	tv_usec;
	};

	struct rusage
	{
		struct unix_time	ru_utime;
	};

#define RUSAGE_SELF 0		//define it, it will be unused
#else
#ifdef hpux
#define _INCLUDE_POSIX_SOURCE
#endif

#ifndef __NeXT__
#include_next <time.h>
#else
#ifndef __NeXT__
#include "//usr/include/time.h"
#endif
#endif
#endif
#undef __time_h_recursive

#define time_h 1

#undef time
#undef clock
#undef difftime
#undef gmtime 
#undef localtime 
#undef asctime 
#undef ctime 
#undef mktime
#undef strftime 
#undef tzset 
#undef tzsetwall 
#undef getitimer
#undef setitimer
#undef gettimeofday
#undef settimeofday

extern char* asctime(_G_const struct tm*);
extern char* ctime(_G_const _G_time_t*);
double difftime(_G_time_t, _G_time_t);
extern struct tm* gmtime(_G_const _G_time_t*);
extern struct tm* localtime(_G_const _G_time_t*);
extern _G_time_t mktime(struct tm*);
extern _G_size_t strftime(char*,_G_size_t,_G_const char*,_G_const struct tm*);
extern void tzset();
extern void tzsetwall();

#ifdef convex
extern clock_t times(struct tms*);
#elif defined(hpux)
extern unsigned long times(struct tms*);
#else
extern long times(struct tms*); 
#endif

#if defined(USG)
extern long timezone;
#ifdef hpux
extern int getitimer(int, struct itimerval*);
extern int setitimer(int, struct itimerval*, struct itimerval*);
extern int gettimeofday(struct timeval*, struct timezone*);
extern int settimeofday(struct timeval*, struct timezone*);
#endif
extern int daylight;
extern char* tzname[];
#else
extern char* timezone(int, int);
extern int getitimer(int, struct itimerval*);
extern int setitimer(int, struct itimerval*, struct itimerval*);
extern int gettimeofday(struct timeval*, struct timezone*);
extern int settimeofday(struct timeval*, struct timezone*);
extern int stime(long*);
int       dysize(int);

#endif

#if defined(___AIX__)
int clock (void);
#elif defined(hpux)
unsigned long      clock(void);
#else
long      clock(void);
#endif
_G_time_t      time(_G_time_t*);
unsigned  ualarm(unsigned, unsigned);
unsigned  usleep(unsigned);
int       profil(char*, int, int, int);

#endif
}
#endif
