#ifndef unistd_h
#define unistd_h 1

#include <_G_config.h>

extern "C" {

#if 1

// Should #include_next <unistd.h>, but only if it exists!  FIXME!

#ifndef SEEK_SET
#define SEEK_SET        0
#define SEEK_CUR        1
#define SEEK_END        2
#endif

#define F_OK            0
#define X_OK            1
#define W_OK            2
#define R_OK            4
#endif

#ifdef __GNUG__
void volatile _exit(int);
#else
void _exit(int);
#endif

unsigned  alarm(unsigned);
int       brk(void*);
int       chdir(const char*);
int       chmod(const char*, int);
int       chown(const char*, int, int);
int       close(int);
char*     crypt(const char*, const char*);
int       dup(int);
int       dup2(int, int);
char*     encrypt(char*, int);
int       execl(const char*, const char *, ...);
int       execle(const char*, const char *, ...);
int       execlp(const char*, const char*, ...);
int       exect(const char*,  const char**,  char**);
int       execv(const char*,  const char**);
int       execve(const char*, const char**, char**);
int       execvp(const char*,  const char**);
int       fchown(int, int, int);
int       fork(void);
int       fsync(int);
int       ftruncate(int, unsigned long);
char*     getcwd(char*, int);
int       getdomainname(char*, int);
int       getdtablesize(void);

int       getgroups(int, int*);
int       geteuid(void);
int       getegid(void);
int       getgid(void);
long      gethostid(void);
int       gethostname(char*, int);
int       getpgrp(...);
int       getpid(void);
int       getppid(void);
char*     getlogin(void);
char*     getpass(const char*);
unsigned  getuid(void);
int       ioctl(int, int, void*);
int       isatty(int);
int       link(const char*, const char*);
int       mkstemp(char*);
char*     mktemp(char*);
int       nice(int);
#ifdef __GNUG__
void volatile pause(void);
#else
void pause(void);
#endif
int       pipe(int*);
int       readlink(const char*, char*, int);
int       rename(const char*, const char*);
int       rmdir(const char*);               
void*     sbrk(int);              
int       syscall(int, ...);
int       setgid(int);
int       sethostname(const char*, int);
int       setpgrp(...);
int       setregid(int, int);
int       setreuid(int, int);
int       setuid(int);
unsigned  sleep(unsigned);
void      swab(void*, void*, int);
int       symlink(const char*, const char*);
int       truncate(const char*, unsigned long);
char*     ttyname(int);
int       ttyslot(void);
// int       umask(int); /* commented out for now; wrong for SunOs4.1 */
int       unlink(const char*);
int       vfork(void);
int       vadvise(int);
int       vhangup(void);

long      lseek(int, long, int);
int       read(int, void*, _G_size_t);
int       write(int, const void*, _G_size_t);
int       access(const char*, int);
#ifndef hpux
int       flock(int, int);
#endif

}

#endif


