
#ifndef OSFCN_H
#define OSFCN_H 1

#include <std.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/resource.h>


#endif
