
#ifndef _bool_h
#define _bool_h 1

enum bool { FALSE = 0, TRUE = 1 };

#endif
