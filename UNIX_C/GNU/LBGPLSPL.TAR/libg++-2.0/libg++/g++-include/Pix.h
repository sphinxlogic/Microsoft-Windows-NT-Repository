
#ifndef _Pix_h
#define _Pix_h 1
typedef void* Pix;
#endif
