#ifndef __libgxx_assert_h

extern "C" {
#ifdef __assert_h_recursive
#include_next <assert.h>
#else
#include_next <assert.h>

#define __libgxx_assert_h 1
#endif
}
#endif
