#ifndef __libgxx_dirent_h

extern "C" {

#ifdef __dirent_h_recursive
#include_next <dirent.h>
#else
#define __dirent_h_recursive
#define opendir __hide_opendir
#define closedir __hide_closedir
#define readdir __hide_readdir
#define telldir __hide_telldir
#define seekdir __hide_seekdir
#if ! (defined(__ultrix__) || defined(__sun__))
#define rewinddir __hide_rewinddir
#endif

#include_next <dirent.h>

#define __libgxx_dirent_h
#undef opendir
#undef closedir
#undef readdir
#undef telldir
#undef seekdir
#if ! (defined(__ultrix__) || defined(__sun__))
#undef rewinddir
#endif

DIR *opendir(const char *);
int closedir(DIR *);
struct dirent *readdir(DIR *);
long telldir(DIR *);
void seekdir(DIR *, long);
#ifndef rewinddir
void rewinddir(DIR *);
#endif
#endif
}

#endif
