#ifndef __libgxx_stdarg_h

extern "C" {
#ifdef __stdarg_h_recursive
#include_next <stdarg.h>
#else
#include_next <stdarg.h>

#define __libgxx_stdarg_h 1
#endif
}
#endif
