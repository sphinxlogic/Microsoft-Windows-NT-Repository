#ifndef __libgxx_sys_dir_h

extern "C" {

#ifdef __sys_dir_h_recursive
#include_next <sys/dir.h>
#else
#define __sys_dir_h_recursive
#define opendir __hide_opendir
#define closedir __hide_closedir
#define readdir __hide_readdir
#define telldir __hide_telldir
#define seekdir __hide_seekdir
#if ! (defined(__ultrix__) || defined(__sun__))
#define rewinddir __hide_rewinddir
#endif

#include_next <sys/dir.h>

#define __libgxx_sys_dir_h
#undef opendir
#undef closedir
#undef readdir
#undef telldir
#undef seekdir
#if ! (defined(__ultrix__) || defined(__sun__))
#undef rewinddir
#endif

DIR *opendir(const char *);
int closedir(DIR *);
struct direct *readdir(DIR *);
long telldir(DIR *);
void seekdir(DIR *, long);
#ifndef rewinddir
void rewinddir(DIR *);
#endif
#endif
}

#endif
