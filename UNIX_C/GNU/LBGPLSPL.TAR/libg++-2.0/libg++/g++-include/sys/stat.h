#ifndef __libgxx_sys_stat_h

extern "C"
{
#ifdef __sys_stat_h_recursive
#include_next <sys/stat.h>
#else
#define __sys_stat_h_recursive
#ifdef VMS
#include "GNU_CC_INCLUDE:[sys]stat.h"
#else
#include_next <sys/stat.h>
#endif

#define __libgxx_sys_stat_h 1

int       stat (const char *path, struct stat *buf);
int       lstat (const char *path, struct stat *buf);
int       fstat (int fd, struct stat *buf);

#endif
}

#endif
