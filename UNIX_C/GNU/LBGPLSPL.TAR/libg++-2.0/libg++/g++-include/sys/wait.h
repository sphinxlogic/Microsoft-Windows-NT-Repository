#ifndef __libgxx_sys_wait_h

extern "C" {
#ifdef __sys_wait_h_recursive
#include_next <sys/wait.h>
#else
#define __sys_wait_h_recursive

#ifdef VMS
#include "GNU_CC_INCLUDE:[sys]wait.h"
#else
#include_next <sys/wait.h>
#endif

#define __libgxx_sys_wait_h 1

struct rusage;
extern int wait(int*);
extern int waitpid(int, int*, int);
extern int wait3(int*, int options, struct rusage*);
extern int wait4(int, int*, int, struct rusage*);
#endif
}

#endif
