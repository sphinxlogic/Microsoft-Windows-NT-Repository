#ifndef _complex_h
#define _complex_h
#define __ATT_complex__
#include <Complex.h>
typedef class Complex complex;
#endif
