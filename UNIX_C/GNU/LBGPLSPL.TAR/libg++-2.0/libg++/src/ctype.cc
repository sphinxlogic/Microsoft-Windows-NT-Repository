#ifdef __GNUG__
#pragma implementation
#endif
#include <ctype.h>
