#ifdef __GNUG__
#pragma implementation
#endif
#include <math.h>
