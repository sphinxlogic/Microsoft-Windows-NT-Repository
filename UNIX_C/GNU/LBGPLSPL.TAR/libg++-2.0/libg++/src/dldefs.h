/*  dldefs.h:          C Version of Init Definitions
 *  Author:           James Kempf
 *  Created On:       Tue Feb  5 11:34:58 1991
 *  Last Modified By: James Kempf
 *  Last Modified On: Tue Aug  6 11:22:36 1991
 *  Update Count:     8
 *  Copyright 1988 Sun Microsystems, Inc.
*/

#ifndef DLDEFS_H
#define DLDEFS_H

/*Typedef needed for calling function*/

typedef void (*void_fn)();

/*The default name of the initialization function.*/

#define INIT_FUN __init                   /*one less _ due to assembler*/
#define FINI_FUN __fini
#define INIT_FUN_NAME "___init"
#define FINI_FUN_NAME "___fini"

#endif
