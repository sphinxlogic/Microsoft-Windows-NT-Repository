/* ostream.h and istream.h now separately includable */

#ifndef _stream_h
#ifdef __GNUG__
#pragma interface
#endif
#define _stream_h 1

#include <ostream.h>
#include <istream.h>

#endif
