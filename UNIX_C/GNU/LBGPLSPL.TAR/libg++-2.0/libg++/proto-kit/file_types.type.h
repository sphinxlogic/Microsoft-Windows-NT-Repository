Substrate_type = 
	isa_Substrate,
SubstrateUnix_type = 
	isa_Substrate | isa_Unix,
SubstrateImmediate_type = 
	isa_Substrate | isa_Immediate,
SubstrateSimple_type = 
	isa_Substrate | isa_Simple,
SubstrateUnixDirectory_type = 
	isa_Substrate | isa_Unix | isa_Directory,
SubstrateUnixImmediate_type = 
	isa_Substrate | isa_Unix | isa_Immediate,
SubstrateUnixSimple_type = 
	isa_Substrate | isa_Unix | isa_Simple,
SubstrateSimpleWhole_type = 
	isa_Substrate | isa_Simple | isa_Whole,
SubstrateSimplePartial_type = 
	isa_Substrate | isa_Simple | isa_Partial,
SubstrateUnixDirectoryImmediate_type = 
	isa_Substrate | isa_Unix | isa_Directory | isa_Immediate,
SubstrateUnixDirectorySimple_type = 
	isa_Substrate | isa_Unix | isa_Directory | isa_Simple,
SubstrateUnixSimpleWhole_type = 
	isa_Substrate | isa_Unix | isa_Simple | isa_Whole,
SubstrateUnixSimplePartial_type = 
	isa_Substrate | isa_Unix | isa_Simple | isa_Partial,
SubstrateUnixDirectorySimpleWhole_type = 
	isa_Substrate | isa_Unix | isa_Directory | isa_Simple | isa_Whole,
SubstrateUnixDirectorySimplePartial_type = 
	isa_Substrate | isa_Unix | isa_Directory | isa_Simple | isa_Partial,
