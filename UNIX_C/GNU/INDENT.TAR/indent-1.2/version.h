/* Originally based on Berkeley indent 5.11 (9/15/88). */

/* kingdon  merged in a bunch of changes from the BSD version of Sep 89, but
   it wouldn't really be correct to say that GNU indent is based on the new
   BSD stuff either.  */

/* Despite the continued presence of the original copyright, I think this
   version is sufficiently different to simply call it GNU indent.
   jla 11/91 */

#define VERSION_STRING "GNU indent 1.2"
