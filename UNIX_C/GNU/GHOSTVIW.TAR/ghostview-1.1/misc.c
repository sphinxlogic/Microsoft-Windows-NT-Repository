/*
 * misc.c -- Everything that isn't a callback or action.
 * Copyright (C) 1992  Timothy O. Theisen
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   Author: Tim Theisen           Systems Programmer
 * Internet: tim@cs.wisc.edu       Department of Computer Sciences
 *     UUCP: uwvax!tim             University of Wisconsin-Madison
 *    Phone: (608)262-0438         1210 West Dayton Street
 *      FAX: (608)262-9777         Madison, WI   53706
 */

#include <stdio.h>
#ifndef SEEK_SET
#define SEEK_SET 0
#endif

#include <signal.h>
#ifdef SIGNALRETURNSINT
#define SIGVAL int
#else
#define SIGVAL void
#endif

#include <math.h>

#include <X11/Xatom.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Shell.h>
#include <X11/Xaw/Cardinals.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/SmeBSB.h>
#include <X11/Xaw/SmeLine.h>
#include <X11/Xaw/Scrollbar.h>
#include <X11/Xaw/AsciiText.h>
/* Yuck, cannot get vScrollbar via the usual methods */
#include <X11/IntrinsicP.h>
#include <X11/Xaw/TextP.h>
#include <X11/Xmu/StdCmap.h>

#include <errno.h>
/* BSD 4.3 errno.h does not declare errno */
extern int errno;
extern int sys_nerr;
extern char *sys_errlist[];

#include "Ghostview.h"
#include "ghostview.h"
#include "ps.h"

#define max(a, b)	((a) > (b) ? (a) : (b))

/* Translate orientations defined by the enum in "ps.h" to
 * XtPageOrientations defined in "Ghostview.h".
 */
static XtPageOrientation
xorient(psorient)
    int psorient;
{
    switch (psorient) {
    case PORTRAIT: return XtPageOrientationPortrait;
    case LANDSCAPE:
	if (app_res.swap_landscape) {
	    return XtPageOrientationSeascape;
	} else {
	    return XtPageOrientationLandscape;
	}
    }
}

static void
reset_size_hints()
{
    Arg args[4];
    if (app_res.ncdwm) return;
    XtSetArg(args[0], XtNmaxWidth, XtUnspecifiedShellInt);
    XtSetArg(args[1], XtNmaxHeight, XtUnspecifiedShellInt);
    XtSetArg(args[2], XtNminWidth, XtUnspecifiedShellInt);
    XtSetArg(args[3], XtNminHeight, XtUnspecifiedShellInt);
    XtSetValues(toplevel, args, TWO);
}

static void
set_size_hints()
{
    Arg args[2];
    Dimension width, height;
    Dimension page_width, page_height;
    Dimension view_width, view_height;

    XtSetArg(args[0], XtNwidth, &page_width);
    XtSetArg(args[1], XtNheight, &page_height);
    XtGetValues(page, args, TWO);

    XtSetArg(args[0], XtNwidth, &view_width);
    XtSetArg(args[1], XtNheight, &view_height);
    XtGetValues(pageview, args, TWO);

    XtSetArg(args[0], XtNwidth, &width);
    XtSetArg(args[1], XtNheight, &height);
    XtGetValues(toplevel, args, TWO);

    width = width + (page_width - view_width);
    height = height + (page_height - view_height);

    XtSetArg(args[0], XtNmaxWidth, width);
    XtSetArg(args[1], XtNmaxHeight, height);
    XtSetValues(toplevel, args, TWO);
}

static Boolean horiz_scroll_saved = False;
static Boolean vert_scroll_saved = False;
static float horiz_top;
static float vert_top;

static void
reset_scroll_bars()
{
    Arg args[1];
    Widget scroll;
    float zero = 0.0;
    
    if (horiz_scroll_saved || vert_scroll_saved) return;

    scroll = XtNameToWidget(pageview, "horizontal");
    if (scroll) {
	XtSetArg(args[0], XtNtopOfThumb, &horiz_top);
	XtGetValues(scroll, args, ONE);
	XtCallCallbacks(scroll, XtNjumpProc, &zero);
	horiz_scroll_saved = True;
    }

    scroll = XtNameToWidget(pageview, "vertical");
    if (scroll) {
	XtSetArg(args[0], XtNtopOfThumb, &vert_top);
	XtGetValues(scroll, args, ONE);
	XtCallCallbacks(scroll, XtNjumpProc, &zero);
	vert_scroll_saved = True;
    }
}

static void
set_scroll_bars()
{
    Arg args[1];
    Widget scroll;
    float shown;

    if (horiz_scroll_saved) {
	scroll = XtNameToWidget(pageview, "horizontal");
	if (scroll) {
	    XtSetArg(args[0], XtNshown, &shown);
	    XtGetValues(scroll, args, ONE);
	    if (horiz_top > (1.0 - shown)) horiz_top = (1.0 - shown);
	    XtCallCallbacks(scroll, XtNjumpProc, &horiz_top);
	}
    }

    if (vert_scroll_saved) {
	scroll = XtNameToWidget(pageview, "vertical");
	if (scroll) {
	    XtSetArg(args[0], XtNshown, &shown);
	    XtGetValues(scroll, args, ONE);
	    if (vert_top > (1.0 - shown)) vert_top = (1.0 - shown);
	    XtCallCallbacks(scroll, XtNjumpProc, &vert_top);
	}
    }

    horiz_scroll_saved = vert_scroll_saved = False;
}

/* Start rendering a new page */
void
show_page(number, start_ghostscript)
    int number;
    Boolean start_ghostscript;
{
    struct stat sbuf;
    XtPageOrientation new_orientation;
    int new_pagemedia;
    int new_llx;
    int new_lly;
    int new_urx;
    int new_ury;
    int new_magstep;
    Boolean layout_changed = False;
    Arg args[20];
    Cardinal num_args;
    float xdpi, ydpi;

    /* Unmark current_page as current */
    if (toc_text && (current_page >= 0)) {
	int marker = current_page*toc_entry_length + toc_entry_length-2;
	toc_text[marker] = ' ';
	XawTextInvalidate(toc, marker, marker+1);
    }

    /* If the file has changed, rescan it so that offsets into the file
     * are still correct.  If the file is rescanned, we most setup() ghostview
     * again.  Also, force a new copy of ghostscript to start. */
    if (psfile) {
	if (!stat(filename, &sbuf) && mtime != sbuf.st_mtime) {
	    fclose(psfile);
	    psfile = fopen(filename, "r");
	    mtime = sbuf.st_mtime;
	    setup_ghostview();
	    start_ghostscript = True;
	}
    }

    /* Coerce page number to fall in range */
    if (toc_text) {
	if (number >= doc->numpages) number = doc->numpages - 1;
	if (number < 0) number = 0;
    }

    /* Figure out new orientation */
    if (app_res.force_orientation) {
	new_orientation = app_res.orientation;
    } else {
	if (doc) {
	    if (doc->numpages && doc->pages[number].orientation != NONE) {
		new_orientation = xorient(doc->pages[number].orientation);
	    } else if (doc->default_page_orientation != NONE) {
		new_orientation = xorient(doc->default_page_orientation);
	    } else if (doc->orientation != NONE) {
		new_orientation = xorient(doc->orientation);
	    } else {
		new_orientation = app_res.orientation;
	    }
	} else {
	    new_orientation = app_res.orientation;
	}
    }

    /* Figure out new pagemedia */
    if (app_res.force_pagemedia) {
	new_pagemedia = default_pagemedia;
    } else {
	if (doc) {
	    if (doc->numpages && doc->pages[number].media != NULL) {
		new_pagemedia = doc->pages[number].media - doc->media;
	    } else if (doc->default_page_media != NULL) {
		new_pagemedia = doc->default_page_media - doc->media;
	    } else {
		new_pagemedia = default_pagemedia;
	    }
	} else {
	    new_pagemedia = default_pagemedia;
	}
    }

    /* Figure out new magstep */
    new_magstep = app_res.magstep;

    /* If magstep changed, stop interpreter and setup for new dpi. */
    if (new_magstep != current_magstep) {
	GhostviewDisableInterpreter(page);
	XawFormDoLayout(form, False);
	reset_size_hints();
	reset_scroll_bars();
	layout_changed = True;
	xdpi = default_xdpi;
	ydpi = default_ydpi;
	magnify(&xdpi, new_magstep);
	magnify(&ydpi, new_magstep);
							num_args = 0;
	XtSetFloatArg(args[num_args], XtNxdpi, xdpi);	num_args++;
	XtSetFloatArg(args[num_args], XtNydpi, ydpi);	num_args++;
	XtSetValues(page, args, num_args);
	XtSetArg(args[0], XtNleftBitmap, None);
	XtSetValues(magstepentry[current_magstep - app_res.minimum_magstep],
		    args, ONE);
	current_magstep = new_magstep;
	XtSetArg(args[0], XtNleftBitmap, dot_bitmap);
	XtSetValues(magstepentry[current_magstep - app_res.minimum_magstep],
		    args, ONE);
    }

    /* If orientation changed,
     * stop interpreter and setup for new orientation. */
    if (new_orientation != current_orientation) {
	GhostviewDisableInterpreter(page);
	XawFormDoLayout(form, False);
	reset_size_hints();
	reset_scroll_bars();
	layout_changed = True;
	XtSetArg(args[0], XtNorientation, new_orientation);
	XtSetValues(page, args, ONE);
	XtSetArg(args[0], XtNleftBitmap, None);
	if (current_orientation == XtPageOrientationPortrait) 
	    XtSetValues(portraitbutton, args, ONE);
	else if (current_orientation == XtPageOrientationLandscape)
            XtSetValues(landscapebutton, args, ONE);
        else if (current_orientation == XtPageOrientationUpsideDown)
            XtSetValues(upsidedownbutton, args, ONE);
        else if (current_orientation == XtPageOrientationSeascape)
            XtSetValues(seascapebutton, args, ONE);
	current_orientation = new_orientation;
    }

    /* mark forced orientation with tie fighter. ("Use the force, Luke") */
    if (app_res.force_orientation) {
	XtSetArg(args[0], XtNleftBitmap, tie_fighter_bitmap);
    } else {
	XtSetArg(args[0], XtNleftBitmap, dot_bitmap);
    }
    if (current_orientation == XtPageOrientationPortrait) 
	XtSetValues(portraitbutton, args, ONE);
    else if (current_orientation == XtPageOrientationLandscape)
	XtSetValues(landscapebutton, args, ONE);
    else if (current_orientation == XtPageOrientationUpsideDown)
	XtSetValues(upsidedownbutton, args, ONE);
    else if (current_orientation == XtPageOrientationSeascape)
	XtSetValues(seascapebutton, args, ONE);

    /* If pagemedia changed, remove the old marker. */
    if (new_pagemedia != current_pagemedia) {
	XtSetArg(args[0], XtNleftBitmap, None);
	if (pagemediaentry[current_pagemedia])
	    XtSetValues(pagemediaentry[current_pagemedia], args, ONE);
	else
	    XtSetValues(pagemediaentry[current_pagemedia-1], args, ONE);

	current_pagemedia = new_pagemedia;
    }

    /* mark forced page media with tie fighter. ("Use the force, Luke") */
    if (app_res.force_pagemedia) {
	XtSetArg(args[0], XtNleftBitmap, tie_fighter_bitmap);
    } else {
	XtSetArg(args[0], XtNleftBitmap, dot_bitmap);
    }
    if (pagemediaentry[current_pagemedia])
	XtSetValues(pagemediaentry[current_pagemedia], args, ONE);
    else
	XtSetValues(pagemediaentry[current_pagemedia-1], args, ONE);

    /* Compute bounding box */
    if (!app_res.force_pagemedia && doc && doc->epsf &&
	/* Ignore malformed bounding boxes */
	(doc->boundingbox[URX] > doc->boundingbox[LLX]) &&
	(doc->boundingbox[URY] > doc->boundingbox[LLY])) {
	new_llx = doc->boundingbox[LLX];
	new_lly = doc->boundingbox[LLY];
	new_urx = doc->boundingbox[URX];
	new_ury = doc->boundingbox[URY];
    } else {
	new_llx = new_lly = 0;
	if (new_pagemedia < base_papersize) {
	    new_urx = doc->media[new_pagemedia].width;
	    new_ury = doc->media[new_pagemedia].height;
	} else {
	    new_urx = papersizes[new_pagemedia-base_papersize].width;
	    new_ury = papersizes[new_pagemedia-base_papersize].height;
	}
    }

    /* If bounding box changed, setup for new size. */
    if ((new_llx != current_llx) || (new_lly != current_lly) ||
	(new_urx != current_urx) || (new_ury != current_ury)) {
	GhostviewDisableInterpreter(page);
	XawFormDoLayout(form, False);
	reset_size_hints();
	reset_scroll_bars();
	layout_changed = True;
	current_llx = new_llx;
	current_lly = new_lly;
	current_urx = new_urx;
	current_ury = new_ury;
	XtSetArg(args[0], XtNllx, current_llx);
	XtSetArg(args[1], XtNlly, current_llx);
	XtSetArg(args[2], XtNurx, current_urx);
	XtSetArg(args[3], XtNury, current_ury);
	XtSetValues(page, args, FOUR);
    }

    if (layout_changed) layout_ghostview();
    if (!filename) return;

    /* Start a new ghostscript if requested, or layout changed, or
     * it is still working on the last page */
    start_ghostscript = start_ghostscript || layout_changed ||
		        (toc_text && processing_page);
    if (start_ghostscript) {
	GhostviewEnableInterpreter(page);
	if (toc_text) {
	    GhostviewSendPS(page, psfile, doc->beginprolog,
			    doc->endprolog, False);
	    GhostviewSendPS(page, psfile, doc->beginsetup,
			    doc->endsetup, False);
	}
    }
    if (toc_text) {
	int marker;
	current_page = number;
	XawTextUnsetSelection(toc);
	XawTextSetInsertionPoint(toc, current_page * toc_entry_length);
	marker = current_page*toc_entry_length + toc_entry_length-2;
	toc_text[marker] = '<';
	XawTextInvalidate(toc, marker, marker+1);
	if (!start_ghostscript && GhostviewNextPage(page) == False) {
	    /* It died, start another */
	    GhostviewEnableInterpreter(page);
	    GhostviewSendPS(page, psfile, doc->beginprolog,
			    doc->endprolog, False);
	    GhostviewSendPS(page, psfile, doc->beginsetup,
			    doc->endsetup, False);
	}
	if (doc->pageorder == DESCEND)
	    GhostviewSendPS(page, psfile,
			    doc->pages[(doc->numpages-1)-current_page].begin,
			    doc->pages[(doc->numpages-1)-current_page].end,
			    False);
	else
	    GhostviewSendPS(page, psfile, doc->pages[current_page].begin,
			    doc->pages[current_page].end, False);
	processing_page = True;
    } else {
	if (!start_ghostscript) {
	    /* if not ready and no toc, can't do much but ring the bell */
	    if (GhostviewNextPage(page) == False) XBell(XtDisplay(page), 0);
	}
    }

    if (toc_text) {
	XtSetSensitive(prevbutton, True);
	XtSetSensitive(nextbutton, True);
	XtSetSensitive(showbutton, True);
	if (current_page == 0) {
	    XtSetSensitive(prevbutton, False);
	}
	if (current_page == doc->numpages-1) {
	    XtSetSensitive(nextbutton, False);
	}
    }
}

/* setup ghostview.  This includes:
 *  scanning the PostScript file,
 *  setting the title and data labels,
 *  building the pagemedia menu,
 *  setting the default pagemedia,
 *  building the toc (table of contents)
 *  sensitizing the appropriate menu buttons,
 *  popping down and erasing the infotext popup.
 */
void
setup_ghostview()
{
    Arg args[20];
    Cardinal num_args;
    char *tocp;
    Widget w;
    XawTextBlock message_block;
    static String nothing = "";
    int i;

    GhostviewDisableInterpreter(page);
    XawFormDoLayout(form, False);
    reset_size_hints();
    reset_scroll_bars();

    /* Reset to a known state. */
    psfree(doc);
    doc = NULL;
    current_page = -1;
    if (toc_text) XtFree(toc_text);
    toc_text = NULL;

    /* Scan document and start setting things up */
    if (psfile) doc = psscan(psfile);

    if (app_res.show_title) {
	if (doc && doc->title) {
	    XtSetArg(args[0], XtNlabel, doc->title);
	    XtSetValues(title, args, ONE);
	} else {
	    if (filename) {
		XtSetArg(args[0], XtNlabel, filename);
	    } else {
		XtSetArg(args[0], XtNlabel, "");
	    }
	    XtSetValues(title, args, ONE);
	}
    }

    if (app_res.show_date) {
	if (doc && doc->date) {
	    XtSetArg(args[0], XtNlabel, doc->date);
	    XtSetValues(date, args, ONE);
	} else {
	    if (psfile) {
		XtSetArg(args[0], XtNlabel, ctime(&mtime));
	    } else {
		XtSetArg(args[0], XtNlabel, "");
	    }
	    XtSetValues(date, args, ONE);
	}
    }

    if (pagemediamenu) XtDestroyWidget(pagemediamenu);

							num_args = 0;
    XtSetArg(args[num_args], XtNallowShellResize, True);num_args++;
    XtSetArg(args[num_args], XtNinput, True);		num_args++;
    XtSetArg(args[num_args], XtNcolormap, cmap);	num_args++;
    if (special_cmap) {
	XtSetArg(args[num_args], XtNbackground, white);	num_args++;
    }
    pagemediamenu = XtCreatePopupShell("menu", simpleMenuWidgetClass,
				       pagemediabutton, args, num_args);

    /* Build the Page Media menu */
    /* the Page media menu has two parts.
     *  - the document defined page medias
     *  - the standard page media defined from Adobe's PPD
     */
    base_papersize = 0;
    if (doc) base_papersize = doc->nummedia;
    for (i = 0; papersizes[i].name; i++) {}	/* Count the standard entries */
    i += base_papersize;
    pagemediaentry = (Widget *) XtMalloc(i * sizeof(Widget));

    if (doc && doc->nummedia) {
	for (i = 0; i < doc->nummedia; i++) {
								num_args = 0;
	    if (special_cmap) {
		XtSetArg(args[num_args], XtNforeground, black);	num_args++;
		XtSetArg(args[num_args], XtNbackground, white);	num_args++;
	    }
	    XtSetArg(args[num_args], XtNleftMargin, 20);	num_args++;
	    pagemediaentry[i] = XtCreateManagedWidget(doc->media[i].name,
				smeBSBObjectClass, pagemediamenu,
				args, num_args);
	    XtAddCallback(pagemediaentry[i], XtNcallback,
			  set_pagemedia, (XtPointer)i);
	}

							num_args = 0;
	if (special_cmap) {
	    XtSetArg(args[num_args], XtNforeground, black);	num_args++;
	    XtSetArg(args[num_args], XtNbackground, white);	num_args++;
	}
	w = XtCreateManagedWidget("line", smeLineObjectClass, pagemediamenu,
			      args, num_args);
    }

    for (i = 0; papersizes[i].name; i++) {
	pagemediaentry[i+base_papersize] = NULL;
	if (i > 0) {
	    /* Skip over same paper size with small imageable area */
	    if ((papersizes[i].width == papersizes[i-1].width) &&
		(papersizes[i].height == papersizes[i-1].height)) {
		continue;
	    }
	}
							num_args = 0;
	if (special_cmap) {
	    XtSetArg(args[num_args], XtNforeground, black);	num_args++;
	    XtSetArg(args[num_args], XtNbackground, white);	num_args++;
	}
	XtSetArg(args[num_args], XtNleftMargin, 20);	num_args++;
	pagemediaentry[i+base_papersize] = XtCreateManagedWidget(
					    papersizes[i].name,
					    smeBSBObjectClass, pagemediamenu,
					    args, num_args);
	XtAddCallback(pagemediaentry[i+base_papersize], XtNcallback,
		      set_pagemedia, (XtPointer)(i+base_papersize));
    }

    /* Assign the default page media */
    default_pagemedia = -1;
    if (doc && doc->nummedia && doc->default_page_media) {
	default_pagemedia = doc->default_page_media - doc->media;
    }
    if ((default_pagemedia < 0) && doc && doc->nummedia) {
	default_pagemedia = 0;
    }
    if (app_res.force_pagemedia || (default_pagemedia < 0)) {
	for (i = base_papersize; papersizes[i-base_papersize].name; i++) {
	    if (!strcmp(app_res.pagemedia,
		papersizes[i-base_papersize].name)) {
		default_pagemedia = i;
		break;
	    }
	}
    }
    if (default_pagemedia < 0) {
	 app_res.force_pagemedia = False;
	 default_pagemedia = 0;
    }

    current_pagemedia = default_pagemedia;
    if (!app_res.force_pagemedia && doc && doc->epsf &&
	/* Ignore malformed bounding boxes */
	(doc->boundingbox[URX] > doc->boundingbox[LLX]) &&
	(doc->boundingbox[URY] > doc->boundingbox[LLY])) {
	current_llx = doc->boundingbox[LLX];
	current_lly = doc->boundingbox[LLY];
	current_urx = doc->boundingbox[URX];
	current_ury = doc->boundingbox[URY];
    } else {
	current_llx = current_lly = 0;
	if (current_pagemedia < base_papersize) {
	    current_urx = doc->media[current_pagemedia].width;
	    current_ury = doc->media[current_pagemedia].height;
	} else {
	    current_urx = papersizes[current_pagemedia-base_papersize].width;
	    current_ury = papersizes[current_pagemedia-base_papersize].height;
	}
    }
    XtSetArg(args[0], XtNllx, current_llx);
    XtSetArg(args[1], XtNlly, current_lly);
    XtSetArg(args[2], XtNurx, current_urx);
    XtSetArg(args[3], XtNury, current_ury);
    XtSetValues(page, args, FOUR);

    /* mark forced page media with tie fighter. ("Use the force, Luke") */
    if (app_res.force_pagemedia) {
	XtSetArg(args[0], XtNleftBitmap, tie_fighter_bitmap);
    } else {
	XtSetArg(args[0], XtNleftBitmap, dot_bitmap);
    }
    if (pagemediaentry[current_pagemedia])
	XtSetValues(pagemediaentry[current_pagemedia], args, ONE);
    else
	XtSetValues(pagemediaentry[current_pagemedia-1], args, ONE);

    /* Build table of contents */
    if (doc && doc->numpages) {
	Boolean useful_page_labels = False;
	int maxlen = 0;
	int i;

	if (doc->numpages == 1) useful_page_labels = True;
	for (i = 1; i < doc->numpages; i++)
	    if (useful_page_labels = (useful_page_labels ||
		    strcmp(doc->pages[i-1].label, doc->pages[i].label))) break;
	if (useful_page_labels) {
	    for (i = 0; i < doc->numpages; i++) 
		maxlen = max(maxlen, strlen(doc->pages[i].label));
	} else {
	    double x;
	    x = doc->numpages;
	    maxlen = log10(x) + 1;
	}
	toc_entry_length = maxlen + 3;
	toc_length = doc->numpages * toc_entry_length - 1;
	toc_text = XtMalloc(toc_length + 2); /* include final NULL */

	if (doc->pageorder == DESCEND) {
	    for (i = 0, tocp = toc_text; i < doc->numpages;
		 i++, tocp += toc_entry_length) {
		if (useful_page_labels) 
		    sprintf(tocp, " %*s \n", maxlen,
			    doc->pages[(doc->numpages-1)-i].label);
		else
		    sprintf(tocp, " %*d \n", maxlen, doc->numpages-i);
	    }
	} else {
	    for (i = 0, tocp = toc_text; i < doc->numpages;
		 i++, tocp += toc_entry_length) {
		if (useful_page_labels) 
		    sprintf(tocp, " %*s \n", maxlen, doc->pages[i].label);
		else
		    sprintf(tocp, " %*d \n", maxlen, i+1);
	    }
	}
	toc_text[toc_length] = '\0';
	processing_page = False;
							      	num_args = 0;
	XtSetArg(args[num_args], XtNfilename, NULL);      	num_args++;
	XtSetValues(page, args, num_args);
    } else {
	toc_length = 0;
	toc_entry_length = 3;
							      	num_args = 0;
	XtSetArg(args[num_args], XtNfilename, filename);      	num_args++;
	XtSetValues(page, args, num_args);
    }
								num_args = 0;
    XtSetArg(args[num_args], XtNlength, toc_length);		num_args++;
    if (toc_text) {
	XtSetArg(args[num_args], XtNstring, toc_text);		num_args++;
    } else {
	/* Text widget sometime blows up when given a NULL pointer */
	XtSetArg(args[num_args], XtNstring, nothing);		num_args++;
    }
    XtSetValues(toc, args, num_args);

    XtSetSensitive(savebutton, (toc_text != NULL));
    XtSetSensitive(printmarkedbutton, (toc_text != NULL));
    XtSetSensitive(prevbutton, (toc_text != NULL));
    XtSetSensitive(markbutton, (toc_text != NULL));
    XtSetSensitive(unmarkbutton, (toc_text != NULL));
    XtSetSensitive(nextbutton, (filename != NULL));
    XtSetSensitive(showbutton, (filename != NULL));
    XtSetSensitive(printwholebutton, (psfile != NULL));

    layout_ghostview();

    /* Reset ghostscript output messages popup */
    XtPopdown(infopopup);
    info_up = False;
    XtSetArg(args[0], XtNeditType, XawtextEdit);
    XtSetArg(args[1], XtNinsertPosition, 0);
    XtSetValues(infotext, args, TWO);
    message_block.length = 0;
    XawTextReplace(infotext, 0, info_length, &message_block);
    info_length = 0;
    XtSetArg(args[0], XtNeditType, XawtextRead);
    XtSetValues(infotext, args, ONE);
}

/* set the dimensions for items in the main form widget. */
/* set foreground and background color in scrollbars. */
/* (The scroll bars come and go as size changes.) */
/* Set window manager hints to keep window manager from causing main */
/* viewport from growing too large */
void
layout_ghostview()
{
    Arg args[20];
    Cardinal num_args;
    Widget w;
    /* Yuck, cannot get vScrollbar via the usual methods */
    TextWidget tw;
    Dimension page_width, page_height;
    Dimension view_width, view_height;
    Dimension screen_width, screen_height;
    Dimension height, border;
    Dimension toc_width, bar_width;
    Dimension leftMargin, rightMargin;
    Dimension pageborder, tocborder;
    Dimension boxborder;
    int distance, vert_margin, horiz_margin;
    XFontStruct *font;

    XawFormDoLayout(form, False);
    reset_size_hints();
    reset_scroll_bars();

							      	num_args = 0;
    XtSetArg(args[num_args], XtNwidth, &page_width);		num_args++;
    XtSetArg(args[num_args], XtNheight, &page_height);		num_args++;
    XtGetValues(page, args, num_args);
    view_width = page_width;
    view_height = page_height;

							      	num_args = 0;
    XtSetArg(args[num_args], XtNborderWidth, &pageborder);	num_args++;
    XtGetValues(pageview, args, num_args);

							      	num_args = 0;
    XtSetArg(args[num_args], XtNborderWidth, &boxborder);	num_args++;
    XtGetValues(boxview, args, num_args);

								num_args = 0;
    XtSetArg(args[num_args], XtNfont, &font);			num_args++;
    XtSetArg(args[num_args], XtNleftMargin, &leftMargin);	num_args++;
    XtSetArg(args[num_args], XtNrightMargin, &rightMargin);	num_args++;
    XtSetArg(args[num_args], XtNborderWidth, &tocborder);	num_args++;
    XtGetValues(toc, args, num_args);

								num_args = 0;
    XtSetArg(args[num_args], XtNdefaultDistance, &distance);	num_args++;
    XtGetValues(form, args, num_args);

    toc_width = font->max_bounds.width * (toc_entry_length - 1) +
		leftMargin + rightMargin;

    /* Add up space taken by borders, etc. */
    horiz_margin = app_res.wm_horiz_margin + toc_width + 2*tocborder +
		   2*pageborder + 3*distance;
    vert_margin = app_res.wm_vert_margin +
		  2*(pageborder>tocborder?pageborder:tocborder) +
		  2*boxborder + 3*distance;

    XtSetArg(args[0], XtNheight, &height);
    XtSetArg(args[1], XtNborderWidth, &border);
    XtGetValues(boxview, args, ONE);
    vert_margin += height;
    if (app_res.show_title || app_res.show_date || app_res.show_locator) 
	vert_margin += distance;
    if (app_res.show_title) {
	XtGetValues(title, args, TWO);
	vert_margin += height + border;
    }
    if (app_res.show_date) {
	XtGetValues(date, args, TWO);
	vert_margin += height + border;
    }
    if (app_res.show_locator) {
	XtGetValues(locator, args, TWO);
	vert_margin += height + border;
    }

    screen_width = WidthOfScreen(XtScreen(toplevel)) - horiz_margin;
    screen_height = HeightOfScreen(XtScreen(toplevel)) - vert_margin;

    if (view_width > screen_width) view_width = screen_width;
    if (view_height > screen_height) view_height = screen_height;

    bar_width = toc_width + tocborder + distance + pageborder + view_width;

    XtSetArg(args[0], XtNwidth, bar_width);
    XtSetValues(boxview, args, ONE);

    XtSetArg(args[0], XtNwidth, toc_width);
    XtSetArg(args[1], XtNheight, view_height);
    if (app_res.show_title) XtSetValues(blank1, args, ONE);
    if (app_res.show_date) XtSetValues(blank2, args, ONE);
    if (app_res.show_locator) XtSetValues(blank3, args, ONE);
    XtSetValues(toc, args, TWO);

    XtSetArg(args[0], XtNwidth, view_width);
    XtSetArg(args[1], XtNheight, view_height);
    if (app_res.show_title) XtSetValues(title, args, ONE);
    if (app_res.show_date) XtSetValues(date, args, ONE);
    if (app_res.show_locator) XtSetValues(locator, args, ONE);
    XtSetValues(pageview, args, TWO);

    XawFormDoLayout(form, True);

    if (special_cmap) {
	w = XtNameToWidget(boxview, "vertical");
	if (w) {
								num_args = 0;
	    XtSetArg(args[num_args], XtNforeground, black);	num_args++;
	    XtSetArg(args[num_args], XtNbackground, white);	num_args++;
	    XtSetValues(w, args, num_args);
	}

	/* Yuck, cannot get vScrollbar via the usual methods */
	/* w = XtNameToWidget(toc, "*vScrollbar"); */
	tw = (TextWidget) toc;
	w = tw->text.vbar;
	if (w) {
	    /* Double Yuck, have to set them twice to make them */
	    /* get the right colors */
								num_args = 0;
	    XtSetArg(args[num_args], XtNforeground, white);	num_args++;
	    XtSetArg(args[num_args], XtNbackground, black);	num_args++;
	    XtSetValues(w, args, num_args);
								num_args = 0;
	    XtSetArg(args[num_args], XtNforeground, black);	num_args++;
	    XtSetArg(args[num_args], XtNbackground, white);	num_args++;
	    XtSetValues(w, args, num_args);
	}

	w = XtNameToWidget(pageview, "horizontal");
	if (w) {
								num_args = 0;
	    XtSetArg(args[num_args], XtNforeground, black);	num_args++;
	    XtSetArg(args[num_args], XtNbackground, white);	num_args++;
	    XtSetValues(w, args, num_args);
	}

	w = XtNameToWidget(pageview, "vertical");
	if (w) {
								num_args = 0;
	    XtSetArg(args[num_args], XtNforeground, black);	num_args++;
	    XtSetArg(args[num_args], XtNbackground, white);	num_args++;
	    XtSetValues(w, args, num_args);
	}
    }

    if (!XtIsRealized(toplevel)) return;
    set_size_hints();
    set_scroll_bars();
}

/* Create a Standard colormap for ghostscript to use. */
/* I always replace the existing standard colormap because I */
/* have found that some applications will modify the value for */
/* black and white.  (black and white use r/w color cells) */
void
SetStandardColormap(w)
    Widget w;
{
    XVisualInfo xvinfo;
    XVisualInfo *xvinfop;
    Atom prop;
    XStandardColormap *std_cmap = NULL;
    XStandardColormap *scmap, *sp;
    Screen *scr = DefaultScreenOfDisplay(XtDisplay(w));
    int nitems, i;
    Boolean has_color;
    Arg args[20];
    Cardinal num_args;

    XtSetArg(args[0], XtNvisual, &(xvinfo.visual));
    XtGetValues(w, args, ONE);
    if (xvinfo.visual == CopyFromParent)
	xvinfo.visual = DefaultVisualOfScreen(scr);
    xvinfo.visualid = XVisualIDFromVisual(xvinfo.visual);
    xvinfop = XGetVisualInfo(XtDisplay(w), VisualIDMask, &xvinfo, &nitems);
    if (xvinfop == NULL) {
        fprintf(stderr, "Bad visual class.\n");
	exit(1);
    }
    xvinfo = *xvinfop;
    XFree((char *)xvinfop);

    has_color = (xvinfo.class != StaticGray) && (xvinfo.class != GrayScale);

    if (has_color) {
	if (xvinfo.visual == DefaultVisualOfScreen(scr)) {
	    prop = XA_RGB_DEFAULT_MAP;
	} else {
	    prop = XA_RGB_BEST_MAP;
	}
    } else {
	prop = XA_RGB_GRAY_MAP;
    }

    if (XGetRGBColormaps(XtDisplay(w), RootWindowOfScreen(scr),
			 &scmap, &nitems, prop)) {
	for (i = 0, sp = scmap; i < nitems; i++, sp++) {
	    if (xvinfo.visualid == sp->visualid) {
		std_cmap = sp;
		break;
	    }
	}
    }

    if (!std_cmap) {
	if (XmuLookupStandardColormap(XtDisplay(w),
				      DefaultScreen(XtDisplay(w)),
				      xvinfo.visualid, xvinfo.depth,
				      prop, False, True)) {
	    if (XGetRGBColormaps(XtDisplay(w), RootWindowOfScreen(scr),
				 &scmap, &nitems, prop)) {
		for (i = 0, sp = scmap; i < nitems; i++, sp++) {
		    if (xvinfo.visualid == sp->visualid) {
			std_cmap = sp;
		    }
		}
	    }
	}
    }

    if (std_cmap) {
	if (has_color) {
	    if ((std_cmap->red_max == std_cmap->green_max) &&
		(std_cmap->green_max == std_cmap->blue_max)) {
		cmap = std_cmap->colormap;
	    } else if ((std_cmap->red_max == 7) && (std_cmap->green_max == 7) &&
		       (std_cmap->blue_max == 3)) {
		/* Ghostscript will tailor this colormap to be useable */
		cmap = std_cmap->colormap;
	    } else {
		XFree((char *)scmap);
	    }
	} else {
	    cmap = std_cmap->colormap;
	}
    }

    if (cmap) {
	XSetRGBColormaps(XtDisplay(w), RootWindowOfScreen(scr),
			 std_cmap, 1, prop);
	black = std_cmap->base_pixel;
	white = std_cmap->red_max * std_cmap->red_mult +
		std_cmap->green_max * std_cmap->green_mult +
		std_cmap->blue_max * std_cmap->blue_mult +
		std_cmap->base_pixel;
    } else {
	if (xvinfo.visual == DefaultVisualOfScreen(scr)) {
	    cmap = DefaultColormapOfScreen(scr);
	    white = WhitePixelOfScreen(scr);
	    black = BlackPixelOfScreen(scr);
	} else {
	    XColor c;
	    cmap = XCreateColormap(XtDisplay(w), RootWindowOfScreen(scr),
				   xvinfo.visual, AllocNone);
	    c.red = c.green = c.blue = ~(unsigned short)0;
	    XAllocColor(XtDisplay(w), cmap, &c);
	    white = c.pixel;
	    c.red = c.green = c.blue = 0;
	    XAllocColor(XtDisplay(w), cmap, &c);
	    black = c.pixel;
	}
    }
    special_cmap = cmap != DefaultColormapOfScreen(scr);

							num_args = 0;
    XtSetArg(args[num_args], XtNcolormap, cmap);	num_args++;
    if (special_cmap) {
	XtSetArg(args[num_args], XtNforeground, black);	num_args++;
	XtSetArg(args[num_args], XtNbackground, white);	num_args++;
    }
    XtSetValues(w, args, num_args);
}

/* Compute new dpi from magstep */
void
magnify(dpi, magstep)
    float *dpi;
    int    magstep;
{
    if (magstep < 0) {
	while (magstep++) *dpi /= 1.2;
    } else {
	while (magstep--) *dpi *= 1.2;
    }
}

/* Attempt to open file, return error message string on failure */
String
open_file(name)
    String name;
{
    FILE *fp;
    struct stat sbuf;

    if (*name == '\0') {	/* Null filename */
	return(NULL);
    }
    if (strcmp(name, "-")) {
	if ((fp = fopen(name, "r")) == NULL) {
	    String buf = XtMalloc(strlen(app_res.open_fail) +
				  strlen(sys_errlist[errno]) + 1);
	    strcpy(buf, app_res.open_fail);
	    if (errno <= sys_nerr) strcat(buf, sys_errlist[errno]);
	    return buf;
	} else {
	    if (filename) XtFree(filename);
	    filename = XtNewString(name);
	    if (psfile) fclose(psfile);
	    psfile = fp;
	    stat(filename, &sbuf);
	    mtime = sbuf.st_mtime;
	    setup_ghostview();
	    show_page(0, True);
	    return(NULL);
	}
    } else {
	if (filename) XtFree(filename);
	filename = XtNewString(name);
	if (psfile) fclose(psfile);
	psfile = NULL;
	setup_ghostview();
	show_page(0, True);
	return(NULL);
    }
}

/* Attempt to save file, return error message string on failure */
String
save_file(name)
    String name;
{
    FILE *pswrite;

    if (*name == '\0') {	/* Null filename */
	return(NULL);
    }
    if ((pswrite = fopen(name, "w")) == NULL) {
	String buf = XtMalloc(strlen(app_res.save_fail) +
			      strlen(sys_errlist[errno]) + 1);
	strcpy(buf, app_res.save_fail);
	if (errno <= sys_nerr) strcat(buf, sys_errlist[errno]);
	return buf;
    } else {
	pscopydoc(pswrite);
	fclose(pswrite);
	return(NULL);
    }
}

/* Attempt to print file.  Return error string on failure */ 
String
print_file(name, whole_mode)
    String name;
    Boolean whole_mode;
{
    FILE *printer;
    SIGVAL (*oldsig)();
    int bytes;
    String ret_val;

    if (*name == '\0') {	/* Null printername */
	return(NULL);
    }
    setenv("PRINTER", name, True);
    oldsig = signal(SIGPIPE, SIG_IGN);
    printer = popen(app_res.print_command, "w");
    if (toc_text && !whole_mode) {
	pscopydoc(printer);
    } else {
	char buf[BUFSIZ];
	FILE *psfile = fopen(filename, "r");
	while (bytes = read(fileno(psfile), buf, BUFSIZ))
	    bytes = write(fileno(printer), buf, bytes);
	fclose(psfile);
    }
    if (pclose(printer)) {
	ret_val = XtNewString(app_res.print_fail);
    } else {
	ret_val = NULL;
    }
    signal(SIGPIPE, oldsig);
    return(ret_val);
}

/* length calculates string length at compile time */
/* can only be used with character constants */
#define length(a) (sizeof(a)-1)

/* Copy the headers, marked pages, and trailer to fp */
void
pscopydoc(fp)
    FILE *fp;
{
    FILE *psfile;
    char text[PSLINELENGTH];
    char *comment;
    Boolean pages_written = False;
    Boolean pages_atend = False;
    int pages = 0;
    int page = 1;
    int i;
    long here;

    psfile = fopen(filename, "r");

    for (i = 0; i < doc->numpages; i++) {
	if (toc_text[toc_entry_length * i] == '*') pages++;
    }

    here = doc->beginheader;
    while (comment = pscopyuntil(psfile, fp, here,
				 doc->endheader, "%%Pages:")) {
	here = ftell(psfile);
	if (pages_written || pages_atend) {
	    free(comment);
	    continue;
	}
	sscanf(comment+length("%%Pages:"), "%s", text);
	if (strcmp(text, "(atend)") == 0) {
	    fputs(comment, fp);
	    pages_atend = True;
	} else {
	    switch (sscanf(comment+length("%%Pages:"), "%*d %d", &i)) {
		case 1:
		    fprintf(fp, "%%%%Pages: %d %d\n", pages, i);
		    break;
		default:
		    fprintf(fp, "%%%%Pages: %d\n", pages);
		    break;
	    }
	    pages_written = True;
	}
	free(comment);
    }
    pscopy(psfile, fp, doc->beginpreview, doc->endpreview);
    pscopy(psfile, fp, doc->begindefaults, doc->enddefaults);
    pscopy(psfile, fp, doc->beginprolog, doc->endprolog);
    pscopy(psfile, fp, doc->beginsetup, doc->endsetup);

    for (i = 0; i < doc->numpages; i++) {
	if (toc_text[toc_entry_length * i] == '*') {
	    comment = pscopyuntil(psfile, fp, doc->pages[i].begin,
				  doc->pages[i].end, "%%Page:");
	    fprintf(fp, "%%%%Page: %s %d\n",
		    doc->pages[i].label, page++);
	    free(comment);
	    pscopy(psfile, fp, -1, doc->pages[i].end);
	}
    }

    here = doc->begintrailer;
    while (comment = pscopyuntil(psfile, fp, here,
				 doc->endtrailer, "%%Pages:")) {
	here = ftell(psfile);
	if (pages_written) {
	    free(comment);
	    continue;
	}
	switch (sscanf(comment+length("%%Pages:"), "%*d %d", &i)) {
	    case 1:
		fprintf(fp, "%%%%Pages: %d %d\n", pages, i);
		break;
	    default:
		fprintf(fp, "%%%%Pages: %d\n", pages);
		break;
	}
	pages_written = True;
	free(comment);
    }
    fclose(psfile);
}
#undef length

/* position popup window under the cursor */
void
positionpopup(w)
    Widget w;
{
    Arg args[3];
    Cardinal num_args;
    Dimension width, height, b_width;
    int x, y, max_x, max_y;
    Window root, child;
    int dummyx, dummyy;
    unsigned int dummymask;
    
    XQueryPointer(XtDisplay(w), XtWindow(w), &root, &child, &x, &y,
		  &dummyx, &dummyy, &dummymask);
    num_args = 0;
    XtSetArg(args[num_args], XtNwidth, &width); num_args++;
    XtSetArg(args[num_args], XtNheight, &height); num_args++;
    XtSetArg(args[num_args], XtNborderWidth, &b_width); num_args++;
    XtGetValues(w, args, num_args);

    width += 2 * b_width;
    height += 2 * b_width;

    x -= ( (Position) width/2 );
    if (x < 0) x = 0;
    if ( x > (max_x = (Position) (XtScreen(w)->width - width)) ) x = max_x;

    y -= ( (Position) height/2 );
    if (y < 0) y = 0;
    if ( y > (max_y = (Position) (XtScreen(w)->height - height)) ) y = max_y;
    
    num_args = 0;
    XtSetArg(args[num_args], XtNx, x); num_args++;
    XtSetArg(args[num_args], XtNy, y); num_args++;
    XtSetValues(w, args, num_args);
}
