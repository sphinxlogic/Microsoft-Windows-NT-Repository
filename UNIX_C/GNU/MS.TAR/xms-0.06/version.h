char ms_version[] = "0.06";
