#define MTU 1536

#ifdef NIT
#include <net/nit_if.h>
#include <net/nit_pf.h>
#define DEFAULT "le0"
#else
#include <net/pfilt.h>
#define DEFAULT "ln0"
#endif
typedef struct ether_packet {
#ifdef NIT	/* sunos */
#ifdef STAMPS
	unsigned char stamp[sizeof(struct nit_iftime)+sizeof(struct nit_ifdrops)];
#endif
#else	/* ultrix packet filter */
	unsigned char  stamp[sizeof (struct enstamp)];
#endif
	unsigned char  dhost[6];
	unsigned char  shost[6];
	unsigned short type;
	unsigned char data[MTU];
} ether_packet;

