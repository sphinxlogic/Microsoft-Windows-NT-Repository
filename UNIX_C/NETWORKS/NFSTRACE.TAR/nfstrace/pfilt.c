#include<sys/types.h>
#include<sys/socket.h>
#include <rpc/rpc.h>
#include<net/if.h>
#include<netinet/in_systm.h>
#include<netinet/in.h>
#include<netinet/ip.h>
#include<netinet/udp.h>
#include<netinet/if_ether.h>
#include<rpc/types.h>
#include<sys/param.h>
#include<sys/time.h>
#include <sys/file.h>
#include <sys/errno.h>
#include <sys/ioctl.h>

#include <signal.h>
#include<netdb.h>
#include "rpcspy.h"
#include <stdio.h>
#define RES 1	/* tick every second */


int dropped=0;
int pr=0;
extern int ok, call, fgc;
long secs;	/* current time in secs */
int ser;	/* packets this second */
int clk();
int die();

struct enfilter filt = {
	10, 4,
	ENF_PUSHWORD + 6,
	ENF_PUSHLIT, 0x0008,
	ENF_EQ
};


char pint[64];

net_open(interface)
     char *interface;
{
	int efd;
	unsigned short bits;
	int one=1;
	unsigned int back=32;

	if ((efd=pfopen(interface,O_RDONLY)) <0) {
		return(efd);
	}
	strcpy(pint,interface);
	/* install filter */
	if (ioctl(efd,EIOCSETF,&filt)<0)
		return -1;
	/*these fail if not root. thats ok */
	ioctl(efd,EIOCALLOWPROMISC,&one);
	ioctl(efd,EIOCALLOWCOPYALL,&one);

	ioctl(efd, EIOCSETW, &back);
	bits=ENNONEXCL|ENTSTAMP|ENCOPYALL|ENPROMISC;
	if (ioctl(efd,EIOCMBIS,&bits)<0)
		return -1;
	/* set prom. mode */
        signal(SIGINT, die);
        signal(SIGHUP, die);
	return efd;
}

net_read(efd,buf,len)
     int efd;
     ether_packet *buf;
     int len;
{
	int r;
	struct enstamp e;

	r=read(efd,buf,len);
	if (r<0)
		return r;
	bcopy(buf,&e,sizeof(struct enstamp));;
	secs=e.ens_tstamp.tv_sec;
	ser=e.ens_tstamp.tv_usec;
	dropped += e.ens_dropped;
	pr++;
	return r;
}

die()
{
	printf("\n# flush (processed = %d, dropped = %d, call=%d, ok=%d, fgc=%d)\n",
	pr,dropped,call,ok,fgc);
	exit(0);
}
