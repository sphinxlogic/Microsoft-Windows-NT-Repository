#ifndef lint
static char *RCSid = "$Header: misc.c,v 1.1 87/08/06 19:06:34 sahayman Exp $";
#endif

#if 0
/*
 * $Log:	misc.c,v $
 * Revision 1.1  87/08/06  19:06:34  sahayman
 * Initial revision
 * 
 */
#endif

/* misc.c
   miscellaneous routines
*/


extern int sys_nerr, errno;
extern char *sys_errlist[], *sprintf();

char *
syserr()
{
	static char buf[80];

	return( (errno<sys_nerr) ? sys_errlist[errno] :
		sprintf(buf,"Unknown error %d", errno) );
}
