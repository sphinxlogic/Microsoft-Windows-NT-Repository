/* 
 *  dtime.h -- interface file to dos to unix time conversion routines. 
 * 
 *  Author: See-Mong Tan 
 */ 
 
  /* initialize time module */ 
extern bool_t dtime_init(void); 
  /* converts dos to unix style time */ 
extern long unixtime(unsigned, unsigned); 
