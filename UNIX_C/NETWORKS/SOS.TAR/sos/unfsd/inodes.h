/* 
 *  inodes.h -- 
 *      Inode interface file. 
 * 
 *  Author: 
 *      See-Mong Tan 
 */ 
 
  /* init */ 
extern bool_t inode_init(void); 
  /* add a path name to the directory tree */ 
extern u_long addpathtodirtree(char *); 
  /* path name to inode */ 
extern u_long pntoin(char *); 
  /* inode to path name in dos format */ 
extern char *intopn(unsigned long); 
  /* inode to name */ 
extern char *intoname(unsigned long); 
 
#ifndef MAXFILENAMELEN 
#define MAXFILENAMELEN 20 
#endif 
 
#ifndef MAXPATHNAMELEN 
#define MAXPATHNAMELEN 128 
#endif 
 
extern FILE *inodefp; 
