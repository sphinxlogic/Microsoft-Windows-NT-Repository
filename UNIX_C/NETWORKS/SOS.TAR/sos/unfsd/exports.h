/* 
 *  exports.h -- 
 *      Interface file for the exports module. 
 * 
 *  Author: 
 *      See-Mong Tan 
 */ 
 
#define EXPORTS "export.us" 
 
/* export list specification */ 
#define MAXEXPSCLNTS 50 
typedef struct EXPS { 
	int drive;					/* drive # */ 
	char *pn;					/* path name */ 
	char *clnts[MAXEXPSCLNTS];			/* client names */ 
	long clnts_ip[MAXEXPSCLNTS]; 		  	/* client IP addrs */ 
	int fsys;					/* file system number */ 
	struct EXPS *next;				/* next entry */ 
} Exports; 
 
  /* parses the exports file */ 
extern bool_t exps_parse(void); 
  /* show exports */ 
extern void exps_showexps(void); 
  /* TRUE iff file is in export list */ 
extern Exports *exps_isexport(char *); 
  /* true if the address is one of an exported client */ 
extern bool_t exps_isclnt(char *, long); 
