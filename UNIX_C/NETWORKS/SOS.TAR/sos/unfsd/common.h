#include <stdio.h> 
#include "..\rpc\types.h" 
#include <ctype.h> 
#include <malloc.h> 
#include <sys\time.h> 
#include <errno.h> 
#include <signal.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 
#include "..\rpc\xdr.h" 
#include "..\rpc\p_prot.h" 
#include "..\rpc\auth.h" 
#include "..\rpc\svc.h" 
#include "general.h" 
#include "nfs.h" 
#include "netd.h" 
#include "pmap.h" 
#include "mountd.h" 
#include "exports.h" 
#include "files.h" 
#include "sock.h" 
#include "inodes.h" 
#include "dtime.h" 
#include "udir.h" 
 
 
