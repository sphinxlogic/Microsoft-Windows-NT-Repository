/* 
 *  netd.h -- header file for the PC-NFS net daemon 
 */ 
 
  /* Error reporting for irrecoverable net daemon errors */ 
extern void netd_Punt(char *); 
  /* initialize */ 
extern void netd_init(int, char **); 
  /* break handler */ 
extern void netd_break(void); 
  /* command line parser */ 
extern void netd_parsecmdln(int, char **); 
 
extern bool_t NFS_VERBOSE;		/* verbose mode nfs reporting */ 
extern bool_t NFS_READONLYFS;		/* a read only filesystem */ 
