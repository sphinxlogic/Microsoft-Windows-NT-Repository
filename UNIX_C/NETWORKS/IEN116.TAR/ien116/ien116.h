/* defines for the ien116 name server */

#define PORT 42			/* Port for the server */

/* Message types from IEN 116 */
#define ADDR_REQ 1		/* Address Request */
#define ADDR_ANS 2		/* Address Request Answer */
#define ERR      3		/* Error */

/* Error types from IEN 116 */
#define UNK_ERR  0		/* Unknown Error */
#define HOST_UNK 1		/* Host Unknown */
#define SYNT_ERR 2		/* Syntax Error */
