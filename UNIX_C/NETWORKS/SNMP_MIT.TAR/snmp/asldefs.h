#ifndef		_ASLDEFS_H_
#define		_ASLDEFS_H_

/*
 *	$Header: asldefs.h,v 1.1 89/01/11 22:10:02 jrd Exp $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */

#include	<notice.h>

#include	<ctypes.h>
#include	<asl.h>
#include	<asn.h>

typedef         struct                  AslNodeTag {

                AsnTypeType          	aslNodeKind;
                CUnswType               aslNodeStuff;
                AsnLengthType		aslNodeMinLen;
		AslIdType		aslNodeNext;

                }                       AslNodeType;

typedef         AslNodeType             *AslNodePtrType;

/*
extern		AslNodeType	aslNodeTable [];

#define		aslIdToPtr(n)	\
			(& (aslNodeTbl [ ((AslIdType)(n)) ]))
*/

#define		aslIdToPtr(n)	\
			((AslNodePtrType) ((AslIdType)(n)))

#define		aslPtrToId(n)	\
			((AslIdType) ((AslNodePtrType) (n)))

#define		aslKindDef(n)	((aslIdToPtr (n))->aslNodeKind)
#define		aslMinLenDef(n)	\
		((AsnLengthType) (aslIdToPtr (n))->aslNodeMinLen)
#define		aslNextDef(n)	\
		((AslIdType) ((aslIdToPtr (n))->aslNodeNext))
#define		aslSonDef(n)	\
		((AslIdType) ((aslIdToPtr (n))->aslNodeStuff))

#endif		/*	_ASLDEFS_H_	*/
