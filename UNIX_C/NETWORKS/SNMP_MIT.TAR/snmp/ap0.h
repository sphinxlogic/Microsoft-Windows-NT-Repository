#ifndef		_AP0_H_
#define		_AP0_H_

/*
 *	$Header: ap0.h,v 1.1 89/01/11 22:09:45 jrd Exp $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */

#include	<notice.h>

CVoidType	ap0Init ();

#endif		/*	_AP0_H_	*/
