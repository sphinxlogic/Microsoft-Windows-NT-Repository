#ifndef		_APS_H_
#define		_APS_H_

/*
 *	$Header: aps.h,v 1.1 89/01/11 22:09:43 jrd Exp $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */

#include	<notice.h>

#include	<ctypes.h>
#include	<error.h>
#include	<asn.h>

typedef		ErrStatusType		ApsStatusType;

typedef		CUnswType		ApsIdType;

typedef		CBytePtrType		ApsNameType;

typedef		CUnswType		ApsGoodiesType;

typedef		CBoolType		(*ApsVerifyFnType) ();

typedef		AsnIdType		(*ApsEncodeFnType) ();

typedef		AsnIdType		(*ApsDecodeFnType) ();

ApsStatusType	apsScheme ();
ApsIdType	apsNew ();
ApsIdType	apsFree ();
ApsIdType	apsVerify ();
AsnIdType	apsEncode ();
AsnIdType	apsDecode ();
CVoidType	apsInit ();

#endif		/*	_APS_H_	*/
