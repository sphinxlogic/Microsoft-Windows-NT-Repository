#ifndef		_VEC_H_
#define		_VEC_H_

/*
 *	$Header: vec.h,v 1.1 89/01/11 22:10:11 jrd Exp $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */

#include	<notice.h>

#include	<ctypes.h>

CUnsfType		vecParse ();

#endif		/*	_VEC_H_		*/
