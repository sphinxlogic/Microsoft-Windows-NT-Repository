#ifndef		_LOCAL_H_
#define		_LOCAL_H_

/*
 *	$Header: local.h,v 1.1 89/01/11 22:09:39 jrd Exp $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */

#include	<notice.h>

char	*	malloc ();
int		free ();
int		bzero ();
int		bcopy ();
int		strcmp ();
char	*	strcpy ();
int		strlen ();

#endif		/*	_LOCAL_H_	*/
