#ifndef		_OID_H_
#define		_OID_H_

/*
 *	$Header: oid.h,v 1.1 89/01/11 22:10:13 jrd Exp $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */

#include	<notice.h>

#include	<ctypes.h>

CIntfType		oidDecode ();
CIntfType		oidEncode ();

#endif		/*	_OID_H_		*/
