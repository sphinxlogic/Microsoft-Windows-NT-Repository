#ifndef		_ERROR_H_
#define		_ERROR_H_

/*
 *	$Header: error.h,v 1.1 89/01/11 22:09:37 jrd Exp $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */

#include	<notice.h>

typedef		enum		ErrStatusTag	{

		errOk,
		errBad

		}		ErrStatusType;

#endif		/*	_ERROR_H_	*/
