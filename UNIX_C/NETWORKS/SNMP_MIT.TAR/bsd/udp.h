#ifndef		_UDP_H_
#define		_UDP_H_

/*
 *	$Header: udp.h,v 1.1 89/01/11 22:10:48 jrd Exp $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */

#include	<notice.h>

#include	<ctypes.h>
#include	<smp.h>

SmpStatusType	udpSend ();
SmpSocketType	udpNew ();
SmpSocketType	udpFree ();

#endif		/*	_UDP_H_	*/
