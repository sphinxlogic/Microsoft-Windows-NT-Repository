#ifndef		_SYSTM_H_
#define		_SYSTM_H_

/*
 *	$Header: systm.h,v 1.1 89/01/11 22:10:50 jrd Exp $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */

#include	<notice.h>

CVoidType	systmInit ();

#endif		/*	_SYSTM_H_	*/
