#ifndef		_TCP_H_
#define		_TCP_H_

/*
 *	$Header: tcp.h,v 1.1 89/01/11 22:11:00 jrd Exp $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */

#include	<notice.h>

#include	<ctypes.h>
#include	<smp.h>

SmpStatusType	tcpSend ();
SmpSocketType	tcpNew ();
SmpSocketType	tcpFree ();

#endif		/*	_TCP_H_	*/
