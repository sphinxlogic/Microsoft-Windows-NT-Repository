#include "talk.h"


xwin_t userwindow[5];
char *current_state;

/* 
 * standard talk procedure to communicate to another user
 */
main(argc, argv)
int argc;
char *argv[];
{

int INPORT, OUTPORT ;

	get_names(argc, argv);

	open_ctl();
	open_sockt();
	start_msgs();

	if ( !check_local() ) {
	    invite_remote();
	}
	end_msgs();

	init_disp();

	INPORT = OUTPORT = sockt ;
	talk1(INPORT,OUTPORT);
}
