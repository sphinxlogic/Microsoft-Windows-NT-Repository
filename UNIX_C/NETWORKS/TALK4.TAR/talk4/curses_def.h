#define GRAPHICS_ON     printf("\033F");      /*   graphics characters   */
#define GRAPHICS_OFF    printf("\033G");
#define CURSOR_OFF      printf("\033m");
#define CURSOR_ON       printf("\033X");
#define V_LINE          'a'
#define H_LINE          '`'
#define TL_CORNER       's'
#define TR_CORNER       'l'
#define BL_CORNER       'e'
#define BR_CORNER       'm'
#define LEFT_T          'n'
#define RIGHT_T         'o'
#define UP_T		'c'
#define DOWN_T		'd'
#define CROSS		'b'
