#include	<errno.h>
#include	<signal.h>
#include	<stdio.h>
#include	"talk.h"
#include	<sys/time.h>


extern	int	errno;			/* error number */
xwin_t  userwindow[5];			/* curses windows */
int	inport[5], outport[5], pid[5];	/* pipes */
int	INPORT, OUTPORT, ID;		/* sockets */
int	no_users;			/* number of users */
char	user[4][20];			/* user names */
char	*getlogin(),*cp;		/* standard getlogin proc */
char 	*current_state;			/* global state variable */
long 	seed;				/* seed for time init */
struct 	timeval wait;			/* timeout */
int	readmask;			/* mask */

/* 
 * main : 
 * Guts of program.  Here, main controls one-to-one conversations between
 * users and redistributes the messages.  
 */
main(argc, argv)
int	argc;
char	*argv[];
{	int	fides1[2], fides2[2] ;
	int	i,j, rtn, nb ,wp,read_set,read_template;
	char	ins[40],ch;
    	BMSG	buf;
	int 	nbuf=sizeof buf;
    	struct 	sgttyb tty;
    	struct 	ltchars ltc;
    	struct 	timeval wait;
	int	inmask[4], sinmask, readmask, readtmp,intyp;
	char	inp[40],*cp,tbuf[10];

	no_users = argc-1;
	for (i=0; i<no_users; i++)
		strcpy(user[i],argv[i+1]);

	time(&seed);
	for (i=0; i<=no_users; i++){

		/* PIPE INITIALIZATION */

		rtn = pipe(fides1);
		if (rtn == -1){
		    printf("Error in pipe1, errno = %d\n", errno);
		    exit(-1);
		};

		rtn = pipe(fides2);
		if (rtn == -1){
		    printf("Error in pipe2, errno = %d\n", errno);
		    exit(-1);
		};


		for (pid[i]=fork(); pid[i]<0;pid[i]=fork()); 

		if (pid[i] == 0){
		    ID = i;
		    INPORT = fides1[0];
		    OUTPORT = fides2[1];

		    if (i==no_users){
			init_disp();
			talk1(INPORT,OUTPORT);
			exit();
		    }
		    if (i==no_users-1){
			printf("Calling %s \n",user[i]);
			comm(2, &argv[i]);
			exit();
		    }
		    if (i==no_users-2){
			printf("Calling %s \n",user[i]);
			comm(2, &argv[i]);
			exit();
		    }
		    if (i==no_users-3){
			printf("Calling %s \n",user[i]);
			comm(2, &argv[i]);
			exit();
		    }

		}
		inport[i] = fides2[0];
		outport[i] = fides1[1];
                cp=(char *)user[i];cp+=2; 
		if(i==no_users)strncpy(cp, getlogin(), 6);


		if (i<no_users){strncpy(cp, argv[i+1], 6);
			do{
			rtn = read(inport[i], tbuf, 10);
			}while(rtn <= 1);
		}
	}
	read_template=0; wp=0; ins[0]=ins[1]=ins[2]=0;
	for(i=0;i<=no_users;++i){read_template|=(1<<inport[i]);}
	forever{
		read_set=read_template;
		wait.tv_sec=100000;
	/* 
	 * wait for user to put something on channel
	 */
		select(32,&read_set,0,0,&wait);
		for(i=0;i<=no_users;++i){
			if(!(read_set&(1<<inport[i]))) continue;
			nb=read(inport[i],&buf,nbuf);
			if(nb==nbuf){
			/* 
			 * distribute message to everyone
			 */
				for(j=0;j<=no_users;++j){
					WN=1+(j-i+6)%4;
					if(i!=j){
					  write(outport[j],&buf,sizeof buf);
					}
				}
			}
		}
	}
}




/*
 * standard talk procedure to communicate to individual user
 */
comm(argc, argv)
int argc;
char *argv[];
{	char	string[10];

	get_names(argc, argv);


	open_ctl();
	open_sockt();
	start_msgs();

	if ( !check_local() ) {
	    invite_remote();
	}

	end_msgs();
	write(OUTPORT, string, 10);

	talk(INPORT,OUTPORT);
}
 
 
