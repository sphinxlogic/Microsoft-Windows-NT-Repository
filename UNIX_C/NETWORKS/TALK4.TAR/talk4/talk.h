#include <curses.h>
#include <utmp.h>

#define	forever		for(;;)

#define	BUF_SIZE	512
#define	WN		buf.wn
#define STR		buf.string

FILE *popen();
int quit(), sleeper();

extern int sockt;
extern int curses_initialized;
extern int invitation_waiting;

extern char *current_state;
extern int current_line;
extern int no_users;

typedef struct xwin {
	WINDOW *win;
	int nlines;
	int ncols;
        int cur_row;
	int cur_col;
	int start_row;
	int start_col;
} xwin_t;

extern xwin_t userwindow[5];

typedef struct {
	char	wn,row,col;
	char	string[40];
} BMSG;
