/*                                                                            */
/*       xnetdb                                                               */
/*                                                                            */
/*       Copyright (C) 1991 The Ohio State University, All Rights Reserved    */
/*       Copyright (C) 1990 Henry Clark, All Rights Reserved                  */
/*                                                                            */
/*       Licensing details are in the file "License"                          */
/*                                                                            */
/*       xnetdb.h                                                             */
/*                                                                            */
/*       all the include stuff                                                */
/*                                                                            */


#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <sys/ioctl.h>
#include <sys/file.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <setjmp.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <netdb.h>


/*                                                                            */
/*       The following define's should be adjusted to fit                     */
/*       the configuration you want...                                        */
/*                                                                            */

/*                                                                            */
/*       This is the timeout between xnetdbquery passes                       */
/*                                                                            */

#define SLEEP_TIME 60

/*                                                                            */
/*       This is the default path into the database                           */
/*                                                                            */

#define DATABASEPATH "/usr/DATABASE"


/*                                                                            */
/*       This is the default path for finding the binaries                    */
/*                                                                            */


#define BPATH "/usr/local/bin"


/*                                                                            */
/*       This is the default path for finding the config files                */
/*                                                                            */


#define CPATH "/usr/DATABASE/config"

/*                                                                            */
/*       This is the name of *your* domain                                    */
/*                                                                            */
/*       This is used to filter out routers in a site list.  If               */
/*         you want all routers listed, set this to a null string.            */
/*                                                                            */


#define MYDOMAIN  "my.domain"


/*                                                                            */
/*      This is your choice of pager (more, pg, etc.)                         */
/*                                                                            */


#define PGPATH "/usr/5bin/pg"

/*                                                                            */
/*       If you're using OpenWindows, change this define                      */
/*                                                                            */


#undef OPENWIN
/* #define OPENWIN 1 */


/*                                                                            */
/*       The amount of time between the time xnetdb tries to                  */
/*       bring dead routers back to life... (in seconds)                      */
/*                                                                            */


#define RESURRECT_TIME 1200


/*                                                                            */
/*       Please only adjust these define's if you have a real                 */
/*       need to...                                                           */
/*                                                                            */


#define MAXNUMBOARDS 20
#define MAXNUMTHINGS 500
#define MAXNUMROUTERS 100
#define MAXNUMCONTACTS 10
#define MAXNUMCIRCUITS 150
#define MAXNUMETHERNETS 150
#define MAXNUMROUTERINTERFACES 20
#define NUMCOLLECTVARS 30


/*                                                                            */
/*       All variable type definitions                                        */
/*                                                                            */


#define VERSION 2.10

#define WHTSP 2

#define DOWN 0
#define UP 1

#define TRUE 1

#define NOIDEA           0
#define ISAROUTER        1
#define ISAHOST          2
#define ISAHOSTPINGER    3
#define ISAROUTERPINGER  4

struct addresstype {
  char name[40];
  char addr1[60];
  char addr2[60];
  char city[20];
  char state[10];
  char zip[11];
  char phone[16];
  char email[30];
  char comment[80];
};


struct interfacetype {
  char  physaddr[30];
  char  ip_address[20];
  char  subnet_mask[20];
  char  board[100];
  int   index;
  int   speed;
  int   admin_status;
  int   oper_status;
  unsigned long  inoctets;
};


struct mapcomputedtype {
  int x1;
  int y1;
  int x2;
  int y2;
};


struct maplocationtype {
  int x;
  int y;
  struct mapcomputedtype computed;
};
 

struct remoteaccesstype {
  char phone[20];
  int  baud;
};


struct boardtype {
  char  name[30];
  char  rev_level[20];
  char  serial_num[30];
};


struct routertype {
  char   routername[20];             /* "official" name of router */
  char   pathname[200];              /* database location of router */
  char   mapname[30];                /* name printed on the map */
  char   manufacturer[20];
  char   model[20];
  char   netaddress[16];
  char   serialnumber[20];
  int    numinterfaces;
  struct interfacetype interface[MAXNUMROUTERINTERFACES]; 
  struct remoteaccesstype remoteaccess;
  int    numcontacts;
  struct addresstype contacts[MAXNUMCONTACTS];
  int    numboards;
  struct boardtype board[MAXNUMBOARDS];
  struct maplocationtype map;
  int    status;
  char   domainname[50];
  char   reportname[40];
  char   community[20];
  int    type;
} router[MAXNUMROUTERS];


struct membertype {
  int router;
  int interface;
};


struct ethernettype {
  char   subnet[20];
  int    x_start;
  int    y_start;
  int    x_end;
  int    y_end;
  int    nummembers;
  int    speed;
  struct membertype member[50];
} ethernet[MAXNUMETHERNETS];


struct carriertype {
  char   name[30];
  char   circuitnum[20];
};


struct csutype {
  char manufacturer[30];
  char model[20];
  char rev_level[10];
  char serial_num[15];
};


struct usagetype {
  float  min;
  float  curr;
  float  max;
  long int lastoctets;
};


struct circuittype {
  char   subnet[20];
  int    from_rtr;
  int    from_intf;
  int    to_rtr;
  int    to_intf;
  int    valid;
  struct usagetype usage;
  struct carriertype pri_carrier;
  struct carriertype sec_carrier;
  struct csutype from_csu;
  struct csutype to_csu;
  int    numcontacts;
  struct addresstype contact[MAXNUMCONTACTS];
  struct mapcomputedtype map;
  int    show_stats;
  Window mywindow;
} circuit[MAXNUMCIRCUITS];


struct thingtype {
  char  ip_address[20];
  int   intf_num;
  char  community[20];
  int   octet_ok;
} thing[MAXNUMTHINGS];


struct collecttype {
  char ipaddress[30];
  char filename[80];
  char variable[80];
  char community[30];
  int  interval;
  int  filedes;
  struct timeval last_time;
} collect[NUMCOLLECTVARS];


/*                                                                            */
/*       Other assorted misc variables                                        */
/*                                                                            */


int    numrouters, numcircuits, numethernets;

XColor   exact, red, blue, gray, green, brown, yellow, purple, orange, pink;
GC       mygc;
Display  *mydisplay;
int      i;
Window   mywindow, mymenuwindow, rootwindow;
unsigned long black,white;
XEvent   myevent, display_event;
XFontStruct *font_struct;
Font     the_font;

char     buffer[100];
int      bufferlen;

int      datafile;
int      num_things;
int      proteon_flag;
int  child_pid;
char portnum[6];
int skt;

char     snmp_buffer[150];

char community[40];

struct timeval last_alarm_time;
struct timeval current_alarm_time;
struct timeval prev_circuit_stats;
struct timeval curr_circuit_stats;
struct timeval last_resurrect_time;
struct timeval current_resurrect_time;

jmp_buf env;

char display[80];

struct sigvec siginfo;

int color;
int b_w;
int monitor;
int verbose;
int logging;
int log_file;
int noisy;
int initialized;

char event[100];
char event_buffer[150];
char strclr[80];

int nummon;
struct {
  char router[20];
  char variable[100];
  char vartype[30];
  char community[20];
} varmon[100];

char cpath[100];
char bpath[100];
char filename[240];


int num_malloc;
int malloc_table[2500];



/*                                                                            */
/*       menu stuff                                                           */
/*                                                                            */


struct MenuType {
  char string[20];
  int  x;
  int  y;
  int  miny;
  int  maxy;
};


struct mbuffer_type {
  char  buffer[100];
} snmp_mbuffer[500];
