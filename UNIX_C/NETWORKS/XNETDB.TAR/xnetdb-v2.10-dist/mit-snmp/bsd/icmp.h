#ifndef		_ICMP_H_
#define		_ICMP_H_

/*
 *	$Header: icmp.h,v 1.1 89/01/11 22:10:53 jrd Exp $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */

#include	<notice.h>

CVoidType	icmpInit ();

#endif		/*	_ICMP_H_	*/
