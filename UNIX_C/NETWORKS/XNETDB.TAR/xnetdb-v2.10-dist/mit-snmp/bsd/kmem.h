#ifndef		_KMEM_H_
#define		_KMEM_H_

/*
 *	$Header: kmem.h,v 1.1 89/01/11 22:10:58 jrd Exp $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */

#include	<notice.h>

CVoidType	kmemInit ();
CIntfType	kmemRead ();

#endif		/*	_KMEM_H_	*/
