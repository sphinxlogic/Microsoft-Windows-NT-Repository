
/*
 *	$Header: kmem.c,v 1.1 89/01/11 22:10:41 jrd Exp $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */

#include	<notice.h>


#include	<ctypes.h>
#include	<debug.h>

#include	<stdio.h>
#include	<sys/types.h>
#include	<sys/file.h>

static		int		kmemFd;

CVoidType		kmemInit ()

{
	if ((kmemFd = open ("/dev/kmem", O_RDONLY, 0)) == -1) {
		perror ("kmemInit");
	}
}

CIntfType		kmemRead (bp, n, addr)

CBytePtrType		bp;
CIntfType		n;
CUnslType		addr;

{
	off_t			lseek ();

	if (lseek (kmemFd, (off_t) addr, L_SET) == (off_t) -1) {
		return ((CIntfType) -1);
	}
	else {
		return ((CIntfType) read (kmemFd, (char *) bp, (int) n));
	}
}

