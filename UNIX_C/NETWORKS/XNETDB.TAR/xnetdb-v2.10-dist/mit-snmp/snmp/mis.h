#ifndef		_MIS_H_
#define		_MIS_H_

/*
 *	$Header: mis.h,v 1.1 89/01/11 22:09:41 jrd Exp $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */

#include	<notice.h>

#include	<ctypes.h>
#include	<error.h>
#include	<mix.h>
#include	<aps.h>

typedef		ErrStatusType		MisStatusType;

typedef		CBoolType		MisAccessType;

CVoidType	misInit ();
MisStatusType	misExport ();
MisAccessType	misCommunityToAccess ();
MixIdType	misCommunityToMib ();
ApsIdType	misCommunityByName ();

#endif		/*	_MIS_H_	*/
