/*                                                                            */
/*       xnetdb                                                               */
/*                                                                            */
/*       Copyright (C) 1991 The Ohio State University, All Rights Reserved    */
/*       Copyright (C) 1990 Henry Clark, All Rights Reserved                  */
/*                                                                            */
/*       Licensing details are in the file "License"                          */
/*                                                                            */
/*       adj_malloc.c                                                         */
/*                                                                            */
/*       this function contains code to seal all snmp memory leaks            */
/*                                                                            */


extern int num_malloc;
extern int malloc_table[200];


int add_malloc(address)

int address;

{
  malloc_table[num_malloc] = address;
  num_malloc++;
  return 0;
}


int delete_malloc(address)

int address;

{
  int i, j;

  for (i=0; i<num_malloc; i++)
    if (malloc_table[i] == address) {
      for (j=i; j<num_malloc-1; j++)
        malloc_table[j] = malloc_table[j+1]; 
      num_malloc--;
      return 0;
    }
  return -1;
}
