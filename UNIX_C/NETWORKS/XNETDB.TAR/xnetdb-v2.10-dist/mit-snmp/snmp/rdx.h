#ifndef		_RDX_H_
#define		_RDX_H_

/*
 *	$Header: rdx.h,v 1.1 89/01/11 22:09:32 jrd Exp $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */

#include	<notice.h>

#include	<ctypes.h>

CIntfType		rdxDecode10 ();
CIntfType		rdxDecode08 ();
CIntfType		rdxDecode16 ();
CIntfType		rdxDecodeAny ();

CIntfType		rdxEncode10 ();
CIntfType		rdxEncode08 ();

#endif		/*	_RDX_H_		*/
