#ifndef		_ASX_H_
#define		_ASX_H_

/*
 *	$Header: asx.h,v 1.1 89/01/11 22:10:09 jrd Exp $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */

#include	<notice.h>

#include	<ctypes.h>
#include	<error.h>
#include	<asn.h>

typedef		ErrStatusType		AsxStatusType;

AsxStatusType	asxPrint ();
CBytePtrType	asxTypeToLabel ();
CVoidType	asxInit ();

#endif		/*	_ASX_H_	*/
