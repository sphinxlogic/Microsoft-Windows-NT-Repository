/*                                                                            */
/*       xnetdb                                                               */
/*                                                                            */
/*       Copyright (C) 1991 The Ohio State University, All Rights Reserved    */
/*       Copyright (C) 1990 Henry Clark, All Rights Reserved                  */
/*                                                                            */
/*       Licensing details are in the file "License"                          */
/*                                                                            */
/*       xnetdb.c                                                             */
/*                                                                            */
/*       this function contains code to run xnetdb stuff                      */
/*                                                                            */


#include "xnetdb.h"


char xnetdb[] = "xnetdb";
int skt;
int signal_sigalarm_handler();
int signal_sighup_handler();
int signal_sigquit_handler();
int signal_sigusr1_handler();
int  child_pid;
char portnum[6];

main(argc, argv)
     int argc;
     char **argv;
{
  int     myscreen;
  XSizeHints myhint;
  int        done;
  Colormap   mycmap;
  int        result;
  int        total_width, total_height;
  int direction_hint;
  int font_ascent, font_descent;
  XCharStruct overall;
  char  text[10];
  KeySym mykey;
  struct sigvec siginfo;
  struct sockaddr_in local;
  int len=sizeof(local);
  int  clkinit();
  int  i,j,xmin,xmax,ymin,ymax,xavg,yavg,xmidpt,ymidpt;
  int  x,y;
  int xr,yr;
  unsigned int buttons;
  Window rw, cw;
  char path[300];
  int frog;
  char froggie[80];
  int  status;
  Time focus_time;
  int  count;


  siginfo.sv_handler = (void *) clkinit;
  siginfo.sv_onstack = 0;
  siginfo.sv_mask = SIGALRM | SIGHUP | SIGUSR1 | SIGQUIT;
  sigvec(SIGALRM, &siginfo, (struct sigvec *) 0);
  siginfo.sv_handler = (void *) signal_sighup_handler;
  sigvec(SIGHUP, &siginfo, (struct sigvec *) 0);
  siginfo.sv_handler = (void *) signal_sigquit_handler;
  sigvec(SIGQUIT, &siginfo, (struct sigvec *) 0);
  siginfo.sv_handler = (void *) signal_sigusr1_handler;
  sigvec(SIGUSR1, &siginfo, (struct sigvec *) 0);

                                        /* default to no monitor and color */

  monitor = 0;
  verbose = 0;
  logging = 0;
  noisy = 0;
  initialized = 0;
  sprintf(bpath, "%s", BPATH);
  sprintf(cpath, "%s", CPATH);

                                        /* solve possible ping problems */

  if (setuid(0) != 0) 
    printf("xnetdb: warning: don't use ping - I couldn't setuid to root!\n");

                                        /* parse command-line args */

  display[0] = '\0';
  for (i=1; i<argc; i++) {
    if (argv[i][0] == '-')
      switch (argv[i][1]) {
        case 'b': if ((argc > (i + 1)) && (strlen(argv[i+1]) > 0))
                    sprintf(bpath, "%s", argv[i+1]);
                  else {
                    printf("xnetdb: invalid bpath specified!\n");
                    exit();
                  }
                  break;
        case 'c': if ((argc > (i + 1)) && (strlen(argv[i+1]) > 0))
                    sprintf(cpath, "%s", argv[i+1]);
                  else {
                    printf("xnetdb: invalid cpath specified!\n");
                    exit();
                  }
                  break;
        case 'd': if ((argc > (i + 1)) && (strlen(argv[i+1]) > 0))
                    sprintf(display, "%s", argv[i+1]);
                  else {
                    printf("xnetdb: invalid display specified!\n");
                    exit();
                  }
                  break;
        case 'l': logging = 1;
                  break;
        case 'm': monitor = 1;
                  break;
        case 'n': noisy = 1;
                  break;
        case 'v': verbose = 1;
                  break;
         default: printf("xnetdb: unknown option %s!\n", argv[i]);
                  exit();
      }
  }

                                         /* init xnetdb */

  if (logging) {
    log_file = open("xnetdb.log", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (log_file == -1) {
      printf("xnetdb: can't open log file!\n");
      exit(1);
    }
  }

  read_config_file();
  read_location_file();
      
                                         /* now start to set up X environ */

  if (strlen(display) > 0) {
    if((mydisplay = XOpenDisplay(display)) == 0) {
      printf("Cannot open display\n");
      exit(1);
    }
  }
  else {
    if((mydisplay = XOpenDisplay("")) == 0) {
      printf("Cannot open display\n");
      exit(1);
    }
  }
  rootwindow = XDefaultRootWindow(mydisplay);
  if (XDefaultDepth(mydisplay, 0) > 2) {
    color = 1;
    b_w = 0;
  }
  else {
    b_w = 1;
    color = 0;
  }
  myscreen = XDefaultScreen(mydisplay);
#ifdef XDEBUG
  XSynchronize(mydisplay, 1);
#endif XDEBUG
  black = XBlackPixel(mydisplay, myscreen);
  white = XWhitePixel(mydisplay, myscreen);
  myhint.x = 40;
  myhint.y = 40;
  myhint.width = 1000;
  myhint.height = 800;
  myhint.flags = PPosition | PSize;
  if (color)
    mywindow = XCreateSimpleWindow(mydisplay, rootwindow,
                                   myhint.x, myhint.y,
                                   myhint.width, myhint.height,
                                   3, white, black);
  else
    mywindow = XCreateSimpleWindow(mydisplay, rootwindow,
                                   myhint.x, myhint.y,
                                   myhint.width, myhint.height,
                                   3, black, white);
  XSetStandardProperties(mydisplay, mywindow, xnetdb, xnetdb, None,
                         argv, argc, &myhint); 
  XStoreName(mydisplay, mywindow, xnetdb);
  XSetIconName(mydisplay, mywindow, xnetdb);
  mygc = XCreateGC(mydisplay, mywindow, 0, 0);
  XSetForeground(mydisplay, mygc, black);
  XSetBackground(mydisplay, mygc, white);
  XSelectInput(mydisplay, mywindow, 
            Button1MotionMask | Button2MotionMask | Button3MotionMask |
            ButtonPressMask | ButtonReleaseMask | ExposureMask | KeyPressMask |
            KeyReleaseMask | EnterWindowMask | LeaveWindowMask );
  XMapRaised(mydisplay, mywindow);

                                          /* Get Colors and Load Font */

  mycmap = XDefaultColormap(mydisplay, myscreen);
  if (color) {
    if (XAllocNamedColor(mydisplay, mycmap, "red", &exact, &red) == 0) 
      printf("xnetdb: couldn't allocate color 'red'\n");
    if (XAllocNamedColor(mydisplay, mycmap, "green", &exact, &green) == 0)
      printf("xnetdb: couldn't allocate color 'green'\n");
    if (XAllocNamedColor(mydisplay, mycmap, "blue", &exact, &blue) == 0)
      printf("xnetdb: couldn't allocate color 'blue'\n");
    if (XAllocNamedColor(mydisplay, mycmap, "orange", &exact, &brown) == 0)
      printf("xnetdb: couldn't allocate color 'orange'\n");
    if (XAllocNamedColor(mydisplay, mycmap, "yellow", &exact, &yellow) == 0)
      printf("xnetdb: couldn't allocate color 'yellow'\n");
    if (XAllocNamedColor(mydisplay, mycmap, "gray", &exact, &gray) == 0)
      printf("xnetdb: couldn't allocate color 'gray'\n");
    if (XAllocNamedColor(mydisplay, mycmap, "steel blue", &exact, &orange) == 0)
      printf("xnetdb: couldn't allocate color 'steel blue'\n");
    if (XAllocNamedColor(mydisplay, mycmap, "purple", &exact, &purple) == 0)
      printf("xnetdb: couldn't allocate color 'purple'\n");
    if (XAllocNamedColor(mydisplay, mycmap, "pink", &exact, &pink) == 0)
      printf("xnetdb: couldn't allocate color 'pink'\n");
  }
  the_font = XLoadFont(mydisplay, "6x10");
  XSetFont(mydisplay, mygc, the_font);
  font_struct = XLoadQueryFont(mydisplay, "6x10");

                                           /* finish the init process */

  proteon_flag = 0;
  for (i=0; i<numrouters; i++) {
    if ((router[i].type != ISAHOSTPINGER)&&(router[i].type != ISAROUTERPINGER))
      init_snmp_variables(i);
    else 
      router[i].numinterfaces = 0;
    init_router_box(i);
  }
  init_circuits();
  for (i=0; i<numrouters; i++) {
    read_database(i);
    if (strcmp(router[i].community, "--PING--") == 0) {
      count = 0;
      status = -1;
      while ((status != 0) && (count < 5)) {
        alarm(10);
        if (setjmp(env)) {
          status = -1;
          printf("xnetdb: ping receive timed out from %s\n", 
                                                          router[i].routername);
        }
        else 
          status = ping(router[i].netaddress);
        alarm(0);
        count++;
      }
      if (status != 0)
        printf("xnetdb: router %s is DEAD!\n", router[i].routername);
      for (j=0; j<router[i].numinterfaces; j++)
        if (status == 0)
          router[i].interface[j].oper_status = 1;
        else
          router[i].interface[j].oper_status = 2;
    }
  }
  init_circuits();

                                         /* init query process if needed */

  if (monitor) {
    gettimeofday(&prev_circuit_stats, 0);
    if ((skt = socket(AF_INET, SOCK_DGRAM, 0)) <= 0) {
      printf("xnetdb: can't open socket\n");
      exit(1);
    }
    fcntl(skt, F_SETFL, FNDELAY);
    local.sin_family = AF_INET;
    local.sin_addr.s_addr = INADDR_ANY;
    local.sin_port = 0;
    bind(skt, &local, sizeof(local));
    getsockname(skt, &local, &len);
    sprintf(portnum, "%d", local.sin_port);
    init_query();
    sprintf(path, "%s/xnetdbquery", bpath);
    if ((child_pid = fork()) == 0) {
      execl(path, "xnetdbquery", portnum, cpath, 0);
      printf("Holy Cow, Batman, the execl failed!\n");
    }
    siginfo.sv_onstack = 0;
    siginfo.sv_mask = SIGALRM | SIGHUP | SIGUSR1 | SIGQUIT;
    siginfo.sv_handler = (void *) signal_sigalarm_handler;
    sigvec(SIGALRM, &siginfo, (struct sigvec *) 0);
    siginfo.sv_handler = (void *) signal_sighup_handler;
    sigvec(SIGHUP, &siginfo, (struct sigvec *) 0);
    siginfo.sv_handler = (void *) signal_sigquit_handler;
    sigvec(SIGQUIT, &siginfo, (struct sigvec *) 0);
    siginfo.sv_handler = (void *) signal_sigusr1_handler;
    sigvec(SIGUSR1, &siginfo, (struct sigvec *) 0);
    gettimeofday(&last_alarm_time, 0);
    alarm(15);
  }
  else {
    siginfo.sv_handler = (void *) signal_sighup_handler;
    siginfo.sv_onstack = 0;
    siginfo.sv_mask = SIGHUP;
    sigvec(SIGHUP, &siginfo, (struct sigvec *) 0);
  }


                                           /* init event stuff */

  sprintf(event, "No Problems");
  make_event();

                                           /* init resurrect time */

  gettimeofday(&last_resurrect_time, 0);

                                           /* main event loop */

  initialized = 1;
  done = 0;
  while (done == 0) {
    XNextEvent(mydisplay, &myevent);
    switch (myevent.type) {
      case Expose: if (myevent.xexpose.count == 0) {
                     display_event = myevent;
                     display_map(); 
                   }
                   break;
      case ButtonPress:switch (myevent.xbutton.button) {
                         case 1: XQueryPointer(mydisplay, mywindow, 
                                          &rw, &cw, &xr, &yr, &x, &y, &buttons);
                                 display_menu(x,y);
                                 break;
                       }
      case KeyPress: case KeyRelease:
                     i = XLookupString (&myevent, text, 10, &mykey, 0);
                     if (i==1 && (text[0] == 'q' || text[0] == 'Q')) done = 1;
                     break;
      case MappingNotify: XRefreshKeyboardMapping(&myevent);
                          break; 
#ifdef OPENWIN
      case EnterNotify: XSetInputFocus(mydisplay, mywindow, 
                                                    RevertToParent, focus_time);
                        break;
#endif OPENWIN
    }
  }

                                        /* make new location.cf... */

  sprintf(filename, "%s/location.cf", cpath);
  frog = open(filename, O_TRUNC | O_CREAT | O_RDWR, 0644);
  for (i=0; i<numrouters; i++) {
    sprintf(froggie, "%s\t%d\t%d\n", router[i].routername, 
                                     router[i].map.x, router[i].map.y);
    write(frog, froggie, strlen(froggie));
  }
  close(frog);

  XFreeGC(mydisplay, mygc);
  XDestroyWindow(mydisplay, mywindow);
  XCloseDisplay(mydisplay);
  if (logging)
    close(log_file);
  if (monitor) {
    close(skt);
    kill(child_pid, SIGKILL);
  }
  return 0;
}


int display_menu(x,y)

int x,y;

{
  int i;
  int x1, x2, y1, y2;
  int found;

  found = 0; 
  for (i=0; i<numrouters; i++) 
    if ((x > router[i].map.computed.x1) && 
        (x < (router[i].map.computed.x1 + router[i].map.computed.x2)) &&
        (y > router[i].map.computed.y1) &&
        (y < (router[i].map.computed.y1 + router[i].map.computed.y2))) {
      display_router_menu(i);
      found = 1;
    }
  if (!found)
    for (i=0; i<numcircuits; i++) {
      if ((circuit[i].map.x1 - circuit[i].map.x2) < 10) {
        if (circuit[i].map.x1 <  circuit[i].map.x2) {
          x1 = circuit[i].map.x1 - 6;
          x2 = circuit[i].map.x2 + 6;
        }
        else {
          x2 = circuit[i].map.x2 - 6;
          x1 = circuit[i].map.x1 + 6;
        }
      }
      else {
        x1 = circuit[i].map.x1;
        x2 = circuit[i].map.x2;
      }
      if ((circuit[i].map.y1 - circuit[i].map.y2) < 10) {
        if (circuit[i].map.y1 <  circuit[i].map.y2) {
          y1 = circuit[i].map.y1 - 6;
          y2 = circuit[i].map.y2 + 6;
        }
        else {
          y2 = circuit[i].map.y2 - 6;
          y1 = circuit[i].map.y1 + 6;
        }
      }
      else {
        y1 = circuit[i].map.y1;
        y2 = circuit[i].map.y2;
      }
      if ((((x1 <= x) && (x2 >= x)) || ((x1 >= x) && (x2 <= x))) &&
          (((y1 >= y) && (y2 <= y)) || ((y1 <= y) && (y2 >= y)))) {
        display_circuit_menu(i);
        found = 1;
      }
    }
  if (!found)
    display_summary_menu();
}


int traceroute(i)

int i;

{
  Window myinfowindow;
  int    sitedone;
  char   dest_net[16], cow[80], moo[100];
  char   text[10];
  KeySym mykey;
  int    numchar;
  int    offset;
  int    j,k;
  char   cow_net[40], cow_default[40];
  char   result[20], next_hop[20];
  int    found, q;

  numchar = 0;
  sitedone = 0;
  offset = 160;
  myinfowindow = XCreateSimpleWindow(mydisplay, mywindow, 50, 50, 280, 30,     
                                                               1, black, white);
  XMapRaised(mydisplay, myinfowindow);
  XSetForeground(mydisplay, mygc, black);
  XDrawString(mydisplay, myinfowindow, mygc, 10, 15, 
                                                 "Enter destination net: ", 23);
  while (sitedone == 0) {
    XNextEvent(mydisplay, &myevent);
    switch (myevent.type) {
      case ButtonRelease: XDestroyWindow(mydisplay, myinfowindow);
                          sitedone = 1;
                          break;
         case KeyRelease: XLookupString(&myevent, text, 10, &mykey, 0);
                          if ((text[0] == '\n') || (text[0] == '\r')) {
                            dest_net[numchar] = 0x00;
                            XDestroyWindow(mydisplay, myinfowindow);
                            sitedone = 1;
                          }
                          else {
                            dest_net[numchar] = text[0];
                            numchar++;
                            XDrawString(mydisplay, myinfowindow, mygc,
                                                       offset, 15, text, 1);
                            offset += 7;
                          }
                          break;
    }
  }

#ifdef DEBUG
  printf("traceroute: dest_net = %s\n", dest_net);
#endif DEBUG

                                  /* now that we know the source and */
                                  /* destination, go do snmp stuff   */
                                  /* and draw path...                */

  display_map();
  sitedone = 0;
  sprintf(cow_net, "1.3.6.1.2.1.4.21.1.7.%s", dest_net);
  sprintf(cow_default, "1.3.6.1.2.1.4.21.1.7.0.0.0.0");
  while (sitedone == 0) {
    found = 0;
    make_snmp_query(router[i].netaddress, cow_net, router[i].community, 2);
    sscanf(snmp_buffer, "%s %s", result, next_hop);
    if (strcmp(result, "IPAddr") != 0) {
      make_snmp_query(router[i].netaddress, cow_default, router[i].community,2);
      sscanf(snmp_buffer, "%s %s", result, next_hop);
      if (strcmp(result, "IPAddr") != 0) {
        sprintf(event, "no route for %s on router %s!", 
                                                dest_net, router[i].routername);
        make_event();
        show_event();
        return 1;
      }
    }
    if (strcmp(result, "ERROR!") == 0) sitedone = 1;
    for (j=0; j<numrouters; j++)
      for (k=0; k<router[j].numinterfaces; k++)
        if (strcmp(next_hop, router[j].interface[k].ip_address) == 0) {
          if (color)
            XSetForeground(mydisplay, mygc, pink.pixel);
          else
            XSetLineAttributes(mydisplay, mygc, 4,
                                            LineDoubleDash, CapButt, JoinMiter);
          XDrawRectangle(mydisplay, mywindow, mygc,
                        router[j].map.computed.x1, router[j].map.computed.y1,
                        router[j].map.computed.x2, router[j].map.computed.y2);
          for (q=0; q<numcircuits; q++) {
            if (
  (strcmp(router[circuit[q].from_rtr].routername, router[i].routername) == 0) &&
  (strcmp(router[circuit[q].to_rtr].routername, router[j].routername) == 0))
              XDrawLine(mydisplay, mywindow, mygc, 
                      circuit[q].map.x1, circuit[q].map.y1, 
                      circuit[q].map.x2, circuit[q].map.y2);
            if (
  (strcmp(router[circuit[q].to_rtr].routername, router[i].routername) == 0) &&
  (strcmp(router[circuit[q].from_rtr].routername, router[j].routername) == 0))
              XDrawLine(mydisplay, mywindow, mygc, 
                      circuit[q].map.x1, circuit[q].map.y1, 
                      circuit[q].map.x2, circuit[q].map.y2);
          }
          if (strcmp(router[i].netaddress, router[j].netaddress) == 0)
            sitedone = 1;
          i = j; 
#ifdef DEBUG
          printf("next hop = %s\n", router[i].netaddress);
#endif DEBUG
          found = 1;
        }
    if ((strcmp(next_hop, "0.0.0.0") == 0) || (found == 0))
      sitedone = 1;
  }
  sprintf(event, "Press any mouse button...");
  make_event();
  show_event();
  sitedone = 0;
  while (sitedone == 0) {
    XNextEvent(mydisplay, &myevent);
    switch (myevent.type) {
      case ButtonRelease: sitedone = 1;
                          break;
    }
  }
  sprintf(event, "Traceroute done...");
  make_event();
  show_event();
  display_map();
}


int get_date(date)

char *date;

{
  Window myinfowindow;
  int    sitedone;
  char   text[10];
  int    numchar;
  int    offset;
  KeySym mykey;

  numchar = 0;
  sitedone = 0;
  offset = 160;
  myinfowindow = XCreateSimpleWindow(mydisplay, mywindow, 50, 50, 280, 30,     
                                                               1, black, white);
  XMapRaised(mydisplay, myinfowindow);
  XSetForeground(mydisplay, mygc, black);
  XDrawString(mydisplay, myinfowindow, mygc, 10, 15, 
                                                 "Enter day of interest: ", 23);
  while (sitedone == 0) {
    XNextEvent(mydisplay, &myevent);
    switch (myevent.type) {
      case ButtonRelease: XDestroyWindow(mydisplay, myinfowindow);
                          sitedone = 1;
                          break;
         case KeyRelease: XLookupString(&myevent, text, 10, &mykey, 0);
                          if ((text[0] == '\n') || (text[0] == '\r')) {
                            date[numchar] = 0x00;
                            XDestroyWindow(mydisplay, myinfowindow);
                            sitedone = 1;
                          }
                          else {
                            date[numchar] = text[0];
                            numchar++;
                            XSetForeground(mydisplay, mygc, black);
                            XDrawString(mydisplay, myinfowindow, mygc,
                                                       offset, 15, text, 1);
                            offset += 7;
                          }
                          break;
    }
  }
  return numchar;
}


int clkinit()

{
  longjmp(env, TRUE);
  return 0;
}

