/*                                                                            */
/*       xnetdb                                                               */
/*                                                                            */
/*       Copyright (C) 1991 The Ohio State University, All Rights Reserved    */
/*       Copyright (C) 1990 Henry Clark, All Rights Reserved                  */
/*                                                                            */
/*       Licensing details are in the file "License"                          */
/*                                                                            */
/*       xnetdbquery.c                                                        */
/*                                                                            */
/*       this program will go and query all interfaces for                    */
/*         their ifOperStatus and then pass the information                   */
/*         back to the map program                                            */
/*                                                                            */


#include "xnetdb.h"


main(argc, argv)

int  argc;
char *argv[];

{
  int i,j;
  int router_status;
  struct sockaddr_in remote;
  int skt;
  struct hostent *hp;
  char buf[BUFSIZ], buf2[BUFSIZ];
  FILE *cow;
  int  eof;
  char variable[100];
  int  status;
  struct sigvec siginfo;
  int  clkinit();
  unsigned long inoctets;
  int   octet_flag;
  char  vartype[10];
  char  result[80];
  char  string[30];
  char  type[20];
  char filename[240];
  int  count;
  int  numcoll;
  struct timeval current_time;
  struct tm *tp;
  char   *ap;
  char  cow_buffer[200];


  siginfo.sv_handler = (void *) clkinit;
  siginfo.sv_onstack = 0;
  siginfo.sv_mask = SIGALRM;
  sigvec(SIGALRM, &siginfo, (struct sigvec *) 0);

                               /* first read list of things to query */

  num_things = 0;
  sprintf(filename, "%s/xnetdbquery.cf", argv[2]);
  if ((cow = fopen(filename, "r")) == NULL) {
    printf("xnetdbquery: unable to find xnetdbquery.cf!!!\n");
    exit(1);
  }
  eof = fscanf(cow, "%s %d %s", thing[num_things].ip_address, 
                                                &thing[num_things].intf_num,
                                                thing[num_things].community);
  thing[num_things].octet_ok = 1;
  while (eof != EOF) {
    num_things++;
    eof = fscanf(cow, "%s %d %s", thing[num_things].ip_address, 
                                                &thing[num_things].intf_num,
                                                thing[num_things].community);
    thing[num_things].octet_ok = 1;
  } 
  fclose(cow);

#ifdef DEBUG
  for (i=0; i<num_things; i++)
    printf("xnetdbquery: monitoring %s interface %d community %s\n",
                    thing[i].ip_address, thing[i].intf_num, thing[i].community);
#endif DEBUG

                              /* now read list of stuff to monitor */

  nummon = 0;
  numcoll = 0;

  sprintf(filename, "%s/xnetdb.cf", argv[2]);
  if ((datafile = open(filename, O_RDONLY)) == -1) {
    printf("xnetdbquery: unable to find %s/xnetdb.cf!\n", argv[2]);
    exit(1);
  }
  while (fetch_more_data() != 0)
    if (buffer[0] != '#') {
      sscanf(buffer, "%s", string);
      if (strcmp(string, "VARIABLE") == 0) {
        sscanf(buffer, "%s %s %s %s %s", string, varmon[nummon].router, 
                               varmon[nummon].variable, varmon[nummon].vartype,
                               varmon[nummon].community);
        if (strcmp(varmon[nummon].community, "--PING--") != 0)
          nummon++;
      }
      if (strcmp(string, "COLLECT") == 0) {
        sscanf(buffer, "COLLECT %s %s %s %s %d", collect[numcoll].ipaddress, 
                         collect[numcoll].variable, collect[numcoll].community,
                         collect[numcoll].filename, &collect[numcoll].interval);
        if ((collect[numcoll].filedes = open(collect[numcoll].filename, 
                                    O_CREAT | O_WRONLY | O_APPEND, 0644)) == -1)
          printf("xnetdbquery: can't open %s - collect entry ignored\n", 
                                                     collect[numcoll].filename);
        else {
          gettimeofday(&collect[numcoll].last_time, 0);
          numcoll++;
        }
      }
    }
  close(datafile);

                              /* now go and query */

  skt = socket(AF_INET, SOCK_DGRAM, 0);
  remote.sin_family = AF_INET;
  remote.sin_port = atoi(argv[1]);

  if ((hp = gethostbyname("localhost")) == NULL) {
    printf("xnetdbquery: can't get localhost address\n");
    exit(-1);
  }
  bcopy((char *)hp->h_addr,(char *)&remote.sin_addr,hp->h_length);

  while (1 == 1) {
    sleep(SLEEP_TIME);
    for (i=0; i<num_things; i++) {
      octet_flag = 0;
      if (strcmp(thing[i].community, "--PING--") == 0) {
        if (ping(thing[i].ip_address, 2) == 0)
          status = 1;
        else
          status = 2;
      }
      else {
        siginfo.sv_handler = (void *) clkinit;
        siginfo.sv_onstack = 0;
        siginfo.sv_mask = SIGALRM;
        sigvec(SIGALRM, &siginfo, (struct sigvec *) 0);
        sprintf(variable, "1.3.6.1.2.1.2.2.1.8.%d", thing[i].intf_num);
        status = make_snmp_query(thing[i].ip_address, variable,
                                                     thing[i].community, 2);
        if (status == 0) {
          sscanf(snmp_buffer, "%s %d", result, &status);
#ifdef DEBUG
          printf("xnetdbquery: router %s interface %d status %d\n",
                                thing[i].ip_address, thing[i].intf_num, status);
#endif DEBUG
          if (strcmp(result, "Integer") != 0) {
            printf("xnetdbquery: got a %s for ifOperStatus_%d\n", result,
                                       thing[i].intf_num);
            printf("             setting %s interface %d to DOWN!\n",
                                      thing[i].ip_address, thing[i].intf_num);
            status = 2;
          }
          if (thing[i].octet_ok == 1) {
            sprintf(variable, "1.3.6.1.2.1.2.2.1.10.%d", thing[i].intf_num);
            make_snmp_query(thing[i].ip_address,variable,thing[i].community,2);
            sscanf(snmp_buffer, "%s %d", result, &inoctets);
            if (strcmp(result, "Counter") != 0) {
              printf("xnetdbquery: got a %s for inOctets_%d\n", result,
                                                          thing[i].intf_num);
              inoctets = -1;
              thing[i].octet_ok = 0;
            }
            if (inoctets < 0) inoctets = -1;
            octet_flag = 1;
          }
        }
        else 
          status = 2;
      }
#ifdef DEBUG
      printf("query: router %s interface %d status %d\n", thing[i].ip_address,
                                                    thing[i].intf_num, status);
#endif DEBUG
      switch (status) {
        case 1: sprintf(buf, "RTR %s INTF %d UP", 
                                       thing[i].ip_address, thing[i].intf_num);
                if (octet_flag)
                  sprintf(buf2, "RTR %s INTF %d INOCTETS %d",
                             thing[i].ip_address, thing[i].intf_num, inoctets);
                break;
        case 2: sprintf(buf, "RTR %s INTF %d DN", 
                                       thing[i].ip_address, thing[i].intf_num);
                break;
        case 3: sprintf(buf, "RTR %s INTF %d TG", 
                                       thing[i].ip_address, thing[i].intf_num);
                break;
      }
      if (sendto(skt, buf, strlen(buf), 0, (struct sockaddr *) &remote, 
                                                        sizeof(remote)) == -1) {
        printf("xnetdbquery: can't write to socket - errno = %d\n", errno);
        exit(1);
      }
      if (octet_flag) {
        if (sendto(skt, buf2, strlen(buf2), 0, (struct sockaddr *) &remote, 
                                                        sizeof(remote)) == -1) {
          printf("xnetdbquery: can't write to socket - errno = %d\n", errno);
          exit(1);
        }
      }
    }

    siginfo.sv_handler = (void *) clkinit;
    siginfo.sv_onstack = 0;
    siginfo.sv_mask = SIGALRM;
    sigvec(SIGALRM, &siginfo, (struct sigvec *) 0);

    for (i=0; i<nummon; i++) {
      status = make_snmp_query(varmon[i].router, varmon[i].variable, 
                                                        varmon[i].community, 2);
      sscanf(snmp_buffer, "%s %s", result, buf);
      if ((strcmp(result, varmon[i].vartype) == 0) && (status == 0)) 
        sprintf(buf, "VAR %s %s OK", varmon[i].router, varmon[i].variable);
      else
        sprintf(buf, "VAR %s %s FU", varmon[i].router, varmon[i].variable);
#ifdef DEBUG
      printf("%s\n", buf);
#endif DEBUG
      if (sendto(skt, buf, strlen(buf), 0,  (struct sockaddr *) &remote, 
                                                        sizeof(remote)) == -1) {
        printf("xnetdbquery: can't write to socket - errno = %d\n", errno);
        exit(1);
      }
    }
    gettimeofday(&current_time, 0);
    tp = localtime((time_t *) &current_time);
    ap = asctime(tp);
    ap[strlen(ap)-1] = 0x00;
    for (i=0; i<numcoll; i++) 
      if (current_time.tv_sec > 
             (collect[i].last_time.tv_sec + collect[i].interval * SLEEP_TIME)) {
        status = make_snmp_query(collect[i].ipaddress, collect[i].variable,
                               collect[i].community, 2);
        sscanf(snmp_buffer, "%s %s", type, result);
        sprintf(cow_buffer, "%s: %s %s %s\n", ap, collect[i].ipaddress, 
                                                   collect[i].variable, result);
        if ((write(collect[i].filedes, cow_buffer, strlen(cow_buffer))) == -1)
          printf("xnetdbquery: write of %s failed!\n", collect[i].filename);
        collect[i].last_time = current_time;
      }
  }
}


int clkinit()

{
  longjmp(env, TRUE);
  return 0;
}


int fetch_more_data()

{
  char charbuf;
  int  cow;

  bufferlen = 0;
  while ((cow = read(datafile, &charbuf, 1)) != 0) {
    buffer[bufferlen] = charbuf;
    if (buffer[bufferlen] == '\n') break;
    bufferlen++;
  }
  buffer[bufferlen] = '\0';
  return cow;
}
