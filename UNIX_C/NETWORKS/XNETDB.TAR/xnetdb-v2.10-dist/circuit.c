/*                                                                            */
/*       xnetdb                                                               */
/*                                                                            */
/*       Copyright (C) 1991 The Ohio State University, All Rights Reserved    */
/*       Copyright (C) 1990 Henry Clark, All Rights Reserved                  */
/*                                                                            */
/*       Licensing details are in the file "License"                          */
/*                                                                            */
/*       circuit.c                                                            */
/*                                                                            */
/*       this function contains code to run circuit stuff                     */
/*                                                                            */


#include "xnetdb.h"


struct MenuType circuit_menu[] = {
  {"Information", 15, 33, 20, 40},
  {"Contacts",    19, 53, 40, 60},
  {"Show Stats",  16, 73, 60, 80}
};

int num_circuit_menu_choices = 3;


int display_circuit_menu(choice)

int choice;

{
  int i,x,y, length;
  int localdone;
  int xr,yr;
  unsigned int buttons;
  Window rw, cw;
  int  cow, prev_cow, cowdone;
  char  window_name[40];

  cow = -1;
  prev_cow = -1;
  x = myevent.xbutton.x;
  y = myevent.xbutton.y;
  localdone = 0;
  length = num_circuit_menu_choices * 20 + 20;
  mymenuwindow = XCreateSimpleWindow(mydisplay, mywindow, x, y,
                                         100, length, 1, black, white);
  XMapRaised(mydisplay, mymenuwindow);
  if (color)
    XSetForeground(mydisplay, mygc, blue.pixel);
  else
    XSetForeground(mydisplay, mygc, black);
  XFillRectangle(mydisplay, mymenuwindow, mygc, 0, 0, 100, 20);
  XSetForeground(mydisplay, mygc, white);
  XDrawString(mydisplay, mymenuwindow, mygc, 14, 13,"Circuit Menu",12);
  XSetForeground(mydisplay, mygc, black);
  for (i=0; i<num_circuit_menu_choices; i++) 
     XDrawString(mydisplay, mymenuwindow, mygc, 
                 circuit_menu[i].x, circuit_menu[i].y, 
                 circuit_menu[i].string, strlen(circuit_menu[i].string));
  while (localdone == 0) {
    XNextEvent(mydisplay, &myevent);
    switch (myevent.type) {
      case MotionNotify: XQueryPointer(mydisplay, mymenuwindow, &rw, &cw,
                                       &xr, &yr, &x, &y, &buttons);
         for (i=0; i<num_circuit_menu_choices; i++)
           if ((y > circuit_menu[i].miny) && (y < circuit_menu[i].maxy))
             cow = i;
         if (cow != prev_cow) 
           for (i=0; i<num_circuit_menu_choices; i++)
             if ((y > circuit_menu[i].miny) && (y < circuit_menu[i].maxy)) {
               XSetForeground(mydisplay, mygc, black);
               XFillRectangle(mydisplay, mymenuwindow, mygc, 
                            0, circuit_menu[i].miny, 100, circuit_menu[i].maxy);
               XSetForeground(mydisplay, mygc, white);
               XDrawString(mydisplay, mymenuwindow, mygc, 
                        circuit_menu[i].x, circuit_menu[i].y, 
                        circuit_menu[i].string, strlen(circuit_menu[i].string));
             }
             else {
               XSetForeground(mydisplay, mygc, white);
               XFillRectangle(mydisplay, mymenuwindow, mygc, 
                            0, circuit_menu[i].miny, 100, circuit_menu[i].maxy);
               XSetForeground(mydisplay, mygc, black);
               XDrawString(mydisplay, mymenuwindow, mygc, 
                        circuit_menu[i].x, circuit_menu[i].y, 
                        circuit_menu[i].string, strlen(circuit_menu[i].string));
             }
         prev_cow = cow;
         break;
      case ButtonRelease: 
         XQueryPointer(mydisplay, mymenuwindow, &rw, &cw,
                                        &xr, &yr, &x, &y, &buttons);
         XDestroyWindow(mydisplay, mymenuwindow);
         if ((y >= 20) && (y <= 40)) display_circuit_information(choice);
         if ((y >= 40) && (y <= 60) && (circuit[choice].numcontacts > 0)) 
           display_circuit_contacts(choice);
         if ((y > 60)  && (monitor))
           if (circuit[choice].show_stats > 0) {
             circuit[choice].show_stats = 0;
             XDestroyWindow(mydisplay, circuit[choice].mywindow);
           }
           else {
             sprintf(event, "Click where you want the stats window...");
             make_event();
             show_event();
             cowdone = 0;
             while (cowdone == 0) {
               XNextEvent(mydisplay, &myevent);
               switch (myevent.type) {
                 case ButtonRelease: 
                   XQueryPointer(mydisplay, mywindow, &rw, &cw,
                                        &xr, &yr, &x, &y, &buttons);
                   cowdone = 1;
                   break;
               }
             }
             circuit[choice].show_stats = 1;
             circuit[choice].mywindow = XCreateSimpleWindow(mydisplay, mywindow,
                                x, y, 110, 16, 1, black, white);
             sprintf(window_name, "%s-%s", 
                                  router[circuit[choice].from_rtr].routername, 
                                  router[circuit[choice].to_rtr].routername);
             XStoreName(mydisplay, circuit[choice].mywindow, window_name);
             XMapRaised(mydisplay, circuit[choice].mywindow);
           }
         localdone = 1;
         break;
    }
  }
}


int display_circuit_information(i)

int i;

{
  Window myinfowindow;
  int    sitedone;
  char   cow[50];
  char   puppy[10];
  int    speed;
  char   subnet[20];

  sitedone = 0;
  myinfowindow = XCreateSimpleWindow(mydisplay, mywindow, 100, 100, 285, 190,
                                                               1, black, white);
  XMapRaised(mydisplay, myinfowindow);
  XSetForeground(mydisplay, mygc, black);
  if ((router[circuit[i].from_rtr].interface[circuit[i].from_intf].speed < 
       router[circuit[i].to_rtr].interface[circuit[i].to_intf].speed ) &&
     (router[circuit[i].from_rtr].interface[circuit[i].from_intf].speed > 1000))
    speed = router[circuit[i].from_rtr].interface[circuit[i].from_intf].speed;
  else
    if (router[circuit[i].to_rtr].interface[circuit[i].to_intf].speed > 1000)
      speed = router[circuit[i].to_rtr].interface[circuit[i].to_intf].speed;
    else {
      printf("xnetdb: circuit: can't figure out router interface speed!\n");
      exit(1);
    }
  if (speed > 30000000)
    sprintf(puppy, "T3");
  else
    if (speed > 1000000)
      sprintf(puppy, "T1");
    else
      sprintf(puppy, "56Kb");
  if (strcmp(circuit[i].subnet, "500.500.500.500") != 0) {
    make_subnet(
        router[circuit[i].from_rtr].interface[circuit[i].from_intf].ip_address,
        router[circuit[i].from_rtr].interface[circuit[i].from_intf].subnet_mask,
        subnet);
    sprintf(cow, "Circuit %s to %s -- %s (%s)", 
                           router[circuit[i].from_rtr].routername,
                           router[circuit[i].to_rtr].routername, puppy, subnet);
  }
  else {
    sprintf(cow, "Circuit %s to %s -- %s", 
                           router[circuit[i].from_rtr].routername,
                           router[circuit[i].to_rtr].routername, puppy);
  }
  XDrawString(mydisplay, myinfowindow, mygc, 10, 10, cow, strlen(cow));
  sprintf(cow, "Primary Carrier"); 
  XDrawString(mydisplay, myinfowindow, mygc, 10, 40, cow, strlen(cow));
  XDrawString(mydisplay, myinfowindow, mygc, 10, 60, 
              circuit[i].pri_carrier.name, strlen(circuit[i].pri_carrier.name));
  XDrawString(mydisplay, myinfowindow, mygc, 10, 80, 
                                     circuit[i].pri_carrier.circuitnum, 
                                     strlen(circuit[i].pri_carrier.circuitnum));
  if (strlen(circuit[i].sec_carrier.name) > 0) {
    sprintf(cow, "Secondary Carrier");
    XDrawString(mydisplay, myinfowindow, mygc, 130, 40, cow, strlen(cow));
    XDrawString(mydisplay, myinfowindow, mygc, 130, 60, 
              circuit[i].sec_carrier.name, strlen(circuit[i].sec_carrier.name));
    XDrawString(mydisplay, myinfowindow, mygc, 130, 80, 
                                     circuit[i].sec_carrier.circuitnum, 
                                     strlen(circuit[i].sec_carrier.circuitnum));
  }
  sprintf(cow, "CSU/DSU @ %s", router[circuit[i].from_rtr].routername);
  XDrawString(mydisplay, myinfowindow, mygc, 10, 110, cow, strlen(cow));
  sprintf(cow, "%s %s", circuit[i].from_csu.manufacturer,
                        circuit[i].from_csu.model);
  XDrawString(mydisplay, myinfowindow, mygc, 10, 130, cow, strlen(cow));
  XDrawString(mydisplay, myinfowindow, mygc, 10, 150, 
                                        circuit[i].from_csu.rev_level,
                                        strlen(circuit[i].from_csu.rev_level));
  XDrawString(mydisplay, myinfowindow, mygc, 10, 170, 
                                        circuit[i].from_csu.serial_num,
                                        strlen(circuit[i].from_csu.serial_num));
  sprintf(cow, "CSU/DSU @ %s", router[circuit[i].to_rtr].routername);
  XDrawString(mydisplay, myinfowindow, mygc, 130, 110, cow, strlen(cow));
  sprintf(cow, "%s %s", circuit[i].to_csu.manufacturer,
                        circuit[i].to_csu.model);
  XDrawString(mydisplay, myinfowindow, mygc, 130, 130, cow, strlen(cow));
  XDrawString(mydisplay, myinfowindow, mygc, 130, 150, 
                                        circuit[i].to_csu.rev_level,
                                        strlen(circuit[i].to_csu.rev_level));
  XDrawString(mydisplay, myinfowindow, mygc, 130, 170, 
                                        circuit[i].to_csu.serial_num,
                                        strlen(circuit[i].to_csu.serial_num));
  while (sitedone == 0) {
    XNextEvent(mydisplay, &myevent);
    switch (myevent.type) {
      case ButtonRelease: XDestroyWindow(mydisplay, myinfowindow);
                          sitedone = 1;
                          break;
    }
  }
}


display_circuit_contacts(i)

int i;

{
  Window myinfowindow;
  int    sitedone;
  int    width;
  int    offset;
  int    j;
  char   cows[80];

  sitedone = 0;
  width = 140 * circuit[i].numcontacts;
  if (width < 1) width = 1;
  myinfowindow = XCreateSimpleWindow(mydisplay, mywindow, 100, 100, width, 150,
                                         1, black, white);
  XMapRaised(mydisplay, myinfowindow);
  XSetForeground(mydisplay, mygc, black);
  XDrawString(mydisplay, myinfowindow, mygc, 30, 15, "Contacts", 8);
  for (j=0; j<circuit[i].numcontacts; j++) {
    offset = 140 * j + 10;
    XDrawString(mydisplay, myinfowindow, mygc, offset, 30,
        circuit[i].contact[j].name, strlen(circuit[i].contact[j].name));
    XDrawString(mydisplay, myinfowindow, mygc, offset, 45,
        circuit[i].contact[j].addr1, strlen(circuit[i].contact[j].addr1));
    XDrawString(mydisplay, myinfowindow, mygc, offset, 60,
        circuit[i].contact[j].addr2, strlen(circuit[i].contact[j].addr2));
    sprintf(cows, "%s %s %s", circuit[i].contact[j].city, 
                       circuit[i].contact[j].state, circuit[i].contact[j].zip);
    XDrawString(mydisplay, myinfowindow, mygc, offset, 75, cows, strlen(cows));
    XDrawString(mydisplay, myinfowindow, mygc, offset, 90,
        circuit[i].contact[j].phone, strlen(circuit[i].contact[j].phone));
    XDrawString(mydisplay, myinfowindow, mygc, offset, 105,
        circuit[i].contact[j].email, strlen(circuit[i].contact[j].email));
    XDrawString(mydisplay, myinfowindow, mygc, offset, 120,
        circuit[i].contact[j].comment, strlen(circuit[i].contact[j].comment));
  }
  while (sitedone == 0) {
    XNextEvent(mydisplay, &myevent);
    switch (myevent.type) {
      case ButtonRelease: XDestroyWindow(mydisplay, myinfowindow);
                          sitedone = 1;
                          break;
    }
  }
}
