/*                                                                            */
/*       xnetdb                                                               */
/*                                                                            */
/*       Copyright (C) 1991 The Ohio State University, All Rights Reserved    */
/*       Copyright (C) 1990 Henry Clark, All Rights Reserved                  */
/*                                                                            */
/*       Licensing details are in the file "License"                          */
/*                                                                            */
/*       query_next.c                                                         */
/*                                                                            */
/*       this function contains code to do snmp "next" functions              */
/*                                                                            */


/*
 *	$Header: snmpnext.c,v 1.2 89/02/17 19:02:21 jrd Exp $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */


#include	<notice.h>


#include <sys/ioctl.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <setjmp.h>
#include <signal.h>
#include <netdb.h>

#include	<host.h>

#include	<ctypes.h>
#include	<local.h>
#include	<rdx.h>
#include	<debug.h>
#include	<smp.h>
#include	<aps.h>
#include	<ap0.h>
#include	<asn.h>
#include	<smx.h>
#include	<udp.h>

#define		cmdBufferSize		(2048)
#define		cmdBindListSize		(20)
#define		cmdTextSize		(64)


static		CBoolType		cmdDone;
static		CByteType		buf [ cmdBufferSize ];
static		SmpBindType		bindList [ cmdBindListSize ];
static		SmpRequestType		req;
static		SmpSequenceType		requestId;
static		int			curr_item;


extern struct mbuffer_type {
  char  buffer[100];
} snmp_mbuffer[500];
extern jmp_buf env;
extern int num_malloc;
extern int malloc_table[2000];
extern int numethernets;

	SmpIdType		smp;
	int			s;
	ApsIdType		communityId;
	SmpSocketType		udp;


static	void	cmdInit ()

{
	aslInit ();
	asnInit ();
	apsInit ();
	ap0Init ();
	smpInit ();
}


static	int		alarmHandler (sig, code, scp)

int			sig;
int			code;
struct	sigcontext	*scp;

{
	sig = sig;
	code = code;
	scp = scp;
	fprintf (stderr, "Request Timed Out\n");
	(void) fflush (stderr);
	exit (4);
}


static  SmpStatusType   myUpCall (smp, req)

SmpIdType               smp;
SmpRequestPtrType       req;

{
	int			cmp;
	SmpIndexType		i;
	SmpBindPtrType		bind;
	SmpBindPtrType		orig;
	CCharType		text [ cmdTextSize ];

	if ((req->smpRequestCmd != smpCommandRsp) ||
		(req->smpRequestId != requestId)) {
		return (errOk);
	}

        smp = smp;
#ifdef SNMPDEBUG
	printf ("Request Id: %d\n", req->smpRequestId);
	printf ("Error: %s\n", smxErrorToText (req->smpRequestError));
	printf ("Index: %d\n", req->smpRequestIndex);
	printf ("Count: %d\n", req->smpRequestCount);
	printf ("\n");
#endif SNMPDEBUG

	bind = req->smpRequestBinds;
	for (i = req->smpRequestCount; i != 0; i--) {
		if (smxNameToText (text, (CIntfType) cmdTextSize,
			(CBytePtrType) bind->smpBindName,
			(CIntfType) bind->smpBindNameLen) >=
			(CIntfType) 0) {
#ifdef SNMPDEBUG
			printf ("Name: %s\n", text);
#endif SNMPDEBUG
		}
#ifdef SNMPDEBUG
		printf ("Kind: %s\n", smxKindToText (bind->smpBindKind));
#endif SNMPDEBUG
		if (smxValueToText (text, (CIntfType) cmdTextSize,
			bind) >= (CIntfType) 0) {
#ifdef SNMPDEBUG
			printf ("Value: %s\n", text);
#endif SNMPDEBUG
			sprintf(snmp_mbuffer[curr_item].buffer, "%s %s", 
                                       smxKindToText (bind->smpBindKind), text);
			curr_item++;
		}
		else {
#ifdef SNMPDEBUG
			printf ("Value: GARBLED\n");
#endif SNMPDEBUG
		}
#ifdef SNMPDEBUG
		printf ("\n");
#endif SNMPDEBUG
		bind++;
	}

	if (req->smpRequestError == smpErrorNone) {
		orig = bindList;
		bind = req->smpRequestBinds;
		cmp = 0;
		for (i = req->smpRequestCount; (i != 0) &&
			((cmp = bcmp ((char *) bind->smpBindName,
			(char *) orig->smpBindName,
			(int) orig->smpBindNameLen)) == 0); i--) {
			orig++;
			bind++;
		}
		if (cmp == 0) {
			req->smpRequestCmd = smpCommandNext;
			req->smpRequestId = ++requestId;
			(void) smpRequest (smp, req);
		}
		else {
			cmdDone = TRUE;
		}
	}
	else {
		cmdDone = TRUE;
	}
        return (errOk);
}


int make_snmp_mquery(ip_address, variable, the_community)

char *ip_address;
char *variable;
char *the_community;

{
  int i;
  int num;

  alarm(10);
  if (setjmp(env)) {
    close(s);
    for (i=0; i<num_malloc; i++)
      free(malloc_table[i]);
    num_malloc = 0;
    printf("xnetdb: mquery receive timed out from %s\n", ip_address);
    alarm(10);
  }
  num = make_the_mquery(ip_address, variable, the_community);
  alarm(0);
  for (i=0; i<num_malloc; i++)
    free(malloc_table[i]);
  num_malloc = 0;
  return num;
}


int make_the_mquery(ip_address, variable, the_community)

char *ip_address;
char *variable;
char *the_community;

{
	int			guernsey;
        int			cow;
	int			salen;
	int			result;
	struct	sockaddr	salocal;
	struct	sockaddr	saremote;
	struct	sockaddr_in	*sin;
        struct  servent         *svp;
	unsigned		timeout;
	struct	sigvec		newSignalVector;

	u_long			fhost;
	u_short			fport;
	CUnslType		number;

	CByteType		pkt [ cmdBufferSize ];
	CBytePtrType		bp;
	SmpIndexType		bindCount;
	SmpBindPtrType		bindp;
	CCharPtrType		*ap;
	CCharPtrType		cp;
	CBoolType		noerror;
	CIntfType		len;
	CIntfType		space;

	CCharPtrType		communityString;

	char			community_buffer[20];
	CCharPtrType		fhostString;
	CCharPtrType		fportString;
	CCharPtrType		requestIdString;
	CCharPtrType		timeoutString;


	curr_item = 0;
	guernsey = 0;

	fhostString = ip_address;
	fhost = (u_long) hostAddress (fhostString);

        fport = htons((u_short) 161);

	timeout = (unsigned) 0;

	requestId = (SmpSequenceType) getpid();

	communityString = (CCharPtrType) the_community;

	cmdInit ();

	bp = buf;
	space = cmdBufferSize;
	bindp = bindList;
	bindCount = (SmpIndexType) 0;
        cow = 1;
        ap = (CCharPtrType *) variable;

	for (noerror = TRUE; (noerror) && (cow > 0); cow--) {
		if ((len = smxTextToObjectId (bp, space, ap)) <
			(CIntfType) 0) {
			noerror = FALSE;
		}
		else {
			ap++;
			bindp->smpBindName = (SmpNameType) bp;
			bindp->smpBindNameLen = (SmpLengthType) len;
			bp += len;
			space -= len;
			bindp->smpBindKind = smpKindOctetString;
			bindp->smpBindValue = (SmpValueType) 0;
			bindp->smpBindValueLen = (SmpLengthType) 0;
			bindp++;
			bindCount++;
		}
	}

	if (! noerror) {
		fprintf (stderr, "Error parsing argument\n");
		return (2);
	}

	s = socket (AF_INET, SOCK_DGRAM, 0);
	if (s < 0) {
		(void) perror ("socket");
		return (1);
	}

	sin = (struct sockaddr_in *) & salocal;
        bzero ((char *) sin, sizeof (*sin));
	sin->sin_family = AF_INET;
	sin->sin_addr.s_addr = (u_long) 0;
	sin->sin_port = (u_short) 0;

	result = bind (s, & salocal, sizeof (*sin));
	if (result < 0) {
		(void) perror ("bind");
		return (1);
	}

        udp = udpNew (s, fhost, fport);
        smp = smpNew (udp, udpSend, myUpCall);
	if (smp == (SmpIdType) 0) {
		fprintf (stderr, "Error creating protocol object\n");
		udp = udpFree (udp);
		return (2);
	}

	communityId = apsNew ((ApsNameType) communityString,
		(ApsNameType) "trivial", (ApsGoodiesType) 0);

	req.smpRequestCmd = smpCommandNext;
	req.smpRequestCommunity = communityId;
	req.smpRequestId = requestId;
	req.smpRequestError = smpErrorNone;
	req.smpRequestIndex = (SmpIndexType) 0;
	req.smpRequestCount = bindCount;
	req.smpRequestBinds = bindList;

	if (smpRequest (smp, & req) != errOk) {
		fprintf (stderr, "Error sending protocol request\n");
		smp = smpFree (smp);
		udp = udpFree (udp);
		communityId = apsFree (communityId);
		return (2);
	}
	smp = smpFree (smp);

	sin = (struct sockaddr_in *) & saremote;

	if (timeout != (unsigned) 0) {
		newSignalVector.sv_handler = (void *) alarmHandler;
		newSignalVector.sv_mask = 0;
		newSignalVector.sv_flags = 0;
		if (sigvec (SIGALRM, & newSignalVector,
			(struct sigvec *) 0) == -1) {
			udp = udpFree (udp);
			communityId = apsFree (communityId);
			return (2);
		}
	}

	cmdDone = FALSE;

	do {
		if (timeout != (unsigned) 0) {
			(void) alarm (timeout);
		}

        	smp = smpNew (udp, udpSend, myUpCall);
		if (smp == (SmpIdType) 0) {
			fprintf (stderr, "Error creating protocol object\n");
			udp = udpFree (udp);
			communityId = apsFree (communityId);
			return (2);
		}

		salen = sizeof (saremote);
		result = recvfrom (s, (char *) pkt, (int) cmdBufferSize,
			(int) 0, & saremote, & salen);
#ifdef SNMPDEBUG
		DEBUGBYTES (pkt, result);
		DEBUG0 ("\n");
#endif SNMPDEBUG

		for (bp = pkt; ((result > 0) &&
			(smpInput (smp, *bp++) == errOk));
			result--);

		smp = smpFree (smp);

		guernsey++;

		DEBUG1 ("result: %d\n", result);

	} while ((result >= 0) && (! cmdDone));

	udp = udpFree (udp);
	communityId = apsFree (communityId);
 	close(s);
	return guernsey;
}
