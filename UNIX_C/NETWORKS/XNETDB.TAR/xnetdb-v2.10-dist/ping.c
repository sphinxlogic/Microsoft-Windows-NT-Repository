/*                                                                            */
/*       xnetdb                                                               */
/*                                                                            */
/*       Copyright (C) 1991 The Ohio State University, All Rights Reserved    */
/*       Copyright (C) 1990 Henry Clark, All Rights Reserved                  */
/*                                                                            */
/*       Licensing details are in the file "License"                          */
/*                                                                            */
/*       ping.c                                                               */
/*                                                                            */
/*       this function contains code to ping remote hosts                     */
/*                                                                            */


/*
 *			P I N G . C
 *
 * Using the InterNet Control Message Protocol (ICMP) "ECHO" facility,
 * measure round-trip-delays and packet loss across network paths.
 *
 * Author -
 *	Mike Muuss
 *	U. S. Army Ballistic Research Laboratory
 *	December, 1983
 * Modified at Uc Berkeley
 * Record Route and verbose headers - Phil Dykstra, BRL, March 1988.
 * Multicast options (ttl, if, loop) - Steve Deering, Stanford, August 1988.
 * ttl, duplicate detection - Cliff Frost, UCB, April 1989
 * Pad pattern - Cliff Frost (from Tom Ferrin, UCSF), April 1989
 * Wait for dribbles, option decoding, pkt compare - vjs@sgi.com, May 1989
 *
 * Status -
 *	Public Domain.  Distribution Unlimited.
 *
 * Bugs -
 *	More statistics could always be gathered.
 *	This program has to run SUID to ROOT to access the ICMP socket.
 */


#include <stdio.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/signal.h>

#include <sys/param.h>
#include <sys/socket.h>
#include <sys/file.h>

#include <netinet/in_systm.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <netinet/ip_var.h>
#include <ctype.h>
#include <netdb.h>
#include <setjmp.h>

#define	MAXWAIT		10	/* max time to wait for response, sec. */
#define	MAXPACKET	(65536-60-8)	/* max packet size */
#define VERBOSE		1	/* verbose flag */
#define QUIET		2	/* quiet flag */
#define FLOOD		4	/* floodping flag */
#define	RROUTE		8	/* record route flag */
#define PING_FILLED     16      /* is buffer filled? */
#define	NUMERIC		32	/* don't do gethostbyaddr() calls */
#define	INTERVAL	64	/* did user specify interval? */
#define	NROUTES		9	/* number of record route slots */
#ifndef MAXHOSTNAMELEN
#define MAXHOSTNAMELEN	64
#endif

#define MULTICAST_NOLOOP 1	/* multicast options */
#define MULTICAST_TTL	 2
#define MULTICAST_IF	 4

extern jmp_buf env;

/* MAX_DUP_CHK is the number of bits in received table, ie the */
/*      maximum number of received sequence numbers we can keep track of. */
/*      Change 128 to 8192 for complete accuracy... */

#define MAX_DUP_CHK     8 * 128
int     mx_dup_ck = MAX_DUP_CHK;
char    rcvd_tbl[ MAX_DUP_CHK / 8 ];
int     nrepeats = 0;

#define A(bit)          rcvd_tbl[ (bit>>3) ]    /* identify byte in array */
#define B(bit)          ( 1 << (bit & 0x07) )   /* identify bit in byte */
#define SET(bit)        A(bit) |= B(bit)
#define CLR(bit)        A(bit) &= (~B(bit))
#define TST(bit)        (A(bit) & B(bit))


char	*malloc();

u_char	*packet;
int	packlen;
int	i, pingflags = 0, options, moptions;
extern	int errno;

int s;			/* Socket file descriptor */
struct hostent *hp;	/* Pointer to host info */
struct timezone tz;	/* leftover */

struct sockaddr whereto;	/* Who to ping */
int datalen = 64-8;		/* How much data */

char usage[] = "Usage: \
ping [-dfnqrvR] [-c count] [-s size] [-l preload] [-p pattern] [-i interval]\n\
     [-h] host\n";

char *hostname;
char hnamebuf[MAXHOSTNAMELEN];

static u_char outpack[MAXPACKET];

int npackets=0;
int preload = 0;		/* number of packets to "preload" */
int ntransmitted = 0;		/* sequence # for outbound packets = #sent */
int ident;
unsigned interval=1;		/* interval between packets */

int nreceived = 0;		/* # of packets we got back */
int timing = 0;
int tmin = 999999999;
int tmax = 0;
int tsum = 0;			/* sum of all times, for doing average */
int bufspace = 48*1024;
char rspace[3+4*NROUTES+1];	/* record route space */


int ping(host_to_ping, num_retry)

char *host_to_ping;
int  num_retry;

{
	struct sockaddr_in from;
	struct sockaddr_in *to = (struct sockaddr_in *) &whereto;
	int c, k, on = 1, hostind = 0;
	struct protoent *proto;
	static u_char *datap = &outpack[8+sizeof(struct timeval)];
	unsigned char ttl, loop;
	struct in_addr ifaddr;
	extern int optind;
	extern char *optarg;
	int fromlen = sizeof (from);
	int cc;
	struct timeval timeout;
 	int munged;


	bzero((char *)&whereto, sizeof(struct sockaddr) );
	to->sin_family = AF_INET;
	to->sin_addr.s_addr = inet_addr(host_to_ping);
	if(to->sin_addr.s_addr != (unsigned)-1) {
		strcpy(hnamebuf, host_to_ping);
		hostname = hnamebuf;
	} else {
		hp = gethostbyname(host_to_ping);
		if (hp) {
			to->sin_family = hp->h_addrtype;
			bcopy(hp->h_addr, (caddr_t)&to->sin_addr, hp->h_length);
			strncpy( hnamebuf, hp->h_name, sizeof(hnamebuf)-1 );
			hostname = hnamebuf;
		} else {
			printf("xnetdb: unknown ping host %s\n", host_to_ping);
			exit(1);
		}
	}

	if (datalen >= sizeof(struct timeval))	/* can we time 'em? */
		timing = 1;
	packlen = datalen + 60 + 76;	/* MAXIP + MAXICMP */
	if( (packet = (u_char *)malloc((unsigned)packlen)) == NULL ) {
		fprintf( stderr, "ping: malloc failed\n" );
		exit(1);
	}

	if (!(pingflags & PING_FILLED)) {
                for( k=8; k<datalen; k++) *datap++ = k;
        }

	ident = getpid() & 0xFFFF;

	if ((proto = getprotobyname("icmp")) == NULL) {
		fprintf(stderr, "icmp: unknown protocol\n");
		exit(10);
	}
	if ((s = socket(AF_INET, SOCK_RAW, proto->p_proto)) < 0) {
		perror("ping: socket");
		exit(5);
	}
        munged = 0;

cows:
        alarm(10);
        if (setjmp(env)) {
          printf("xnetdb: ping timed out from %s\n", host_to_ping);
          num_retry--;
          if (num_retry < 1) {
            free(packet);
            close(s);
            return -1;
          }
          alarm(10);
        }
 	pinger();
        cc=recvfrom(s, (char *)packet, packlen, 0, 
					(struct sockaddr *)&from, &fromlen);
        alarm(0);

	if ((cc == -1) || (pr_pack( (char *)packet, cc, &from ) == -1)) {
          if ((cc > 0) && (munged == 0)) {
            munged = 1;
            goto cows;
          }
          close(s);
          free(packet);
          return -1;
        }
        else {
          close(s);
          free(packet);
          return 0;
        }
}


/*
 * 			P I N G E R
 * 
 * Compose and transmit an ICMP ECHO REQUEST packet.  The IP packet
 * will be added on by the kernel.  The ID field is our UNIX process ID,
 * and the sequence number is an ascending integer.  The first 8 bytes
 * of the data portion are used to hold a UNIX "timeval" struct in VAX
 * byte-order, to compute the round-trip time.
 */
pinger()
{
	register struct icmp *icp = (struct icmp *) outpack;
	int i, cc;
	register struct timeval *tp = (struct timeval *) &outpack[8];

	icp->icmp_type = ICMP_ECHO;
	icp->icmp_code = 0;
	icp->icmp_cksum = 0;
	icp->icmp_seq = htons((unsigned short)(ntransmitted++));
	icp->icmp_id = ident;		/* ID */

        CLR( ntohs(icp->icmp_seq) % mx_dup_ck );

	cc = datalen+8;			/* skips ICMP portion */

	if (timing)
		gettimeofday( tp, &tz );

	/* Compute ICMP checksum here */
	icp->icmp_cksum = in_cksum( (u_short *)icp, cc );

	/* cc = sendto(s, msg, len, flags, to, tolen) */
	i = sendto( s, (char *)outpack, cc, 0, &whereto, sizeof(struct sockaddr) );

	if( i < 0 || i != cc )  {
		if( i<0 )  perror("sendto");
		printf("ping: wrote %s %d chars, ret=%d\n",
			hostname, cc, i );
		fflush(stdout);
	}
	if( pingflags & FLOOD ) {
		putchar('.');
		fflush(stdout);
	}
}


/*
 *			P R _ P A C K
 *
 * Print out the packet, if it came from us.  This logic is necessary
 * because ALL readers of the ICMP socket get a copy of ALL ICMP packets
 * which arrive ('tis only fair).  This permits multiple copies of this
 * program to be run without having intermingled output (or statistics!).
 */


pr_pack( buf, cc, from )
char *buf;
int cc;
struct sockaddr_in *from;
{
	struct ip *ip;
	register struct icmp *icp;
	register int i, j;
	register u_char *cp,*dp;
	static int old_rrlen;
	static char old_rr[MAX_IPOPTLEN];
	struct timeval tv;
	struct timeval *tp;
	int hlen, triptime, dupflag;

	gettimeofday( &tv, &tz );

	/* Check the IP header */
	ip = (struct ip *) buf;
	hlen = ip->ip_hl << 2;

	/* Now the ICMP part */
	cc -= hlen;
	icp = (struct icmp *)(buf + hlen);
	if( icp->icmp_type == ICMP_ECHOREPLY ) {
		if( icp->icmp_id != ident )
			return;			/* 'Twas not our ECHO */

		nreceived++;
		if (timing) {
#ifndef icmp_data
			tp = (struct timeval *)&icp->icmp_ip;
#else
			tp = (struct timeval *)&icp->icmp_data[0];
#endif
			tvsub( &tv, tp );
			triptime = tv.tv_sec*1000+(tv.tv_usec/1000);
			tsum += triptime;
			if( triptime < tmin )
				tmin = triptime;
			if( triptime > tmax )
				tmax = triptime;
		}

                if ( TST(ntohs(icp->icmp_seq)%mx_dup_ck) ) {
                       	nrepeats++, nreceived--;
			dupflag=1;
                } else {
			SET(ntohs(icp->icmp_seq)%mx_dup_ck);
			dupflag=0;
		}

		if( pingflags & QUIET )
			return 0;

		if( pingflags & FLOOD ) {
			putchar('\b');
			fflush(stdout);
		} else {
			/* check the data */
			cp = (u_char*)&icp->icmp_data[8];
			dp = &outpack[8+sizeof(struct timeval)];
			for (i=8; i<datalen; i++, cp++, dp++) {
				if (*cp != *dp) {
					cp = (u_char*)&icp->icmp_data[0];
					break;
				}
			}

		}
	} else {
		/* We've got something other than an ECHOREPLY */

		pr_icmph( icp );
		return -1;
	}

	/* Display any IP options */
	cp = (u_char *)buf + sizeof(struct ip);
	while (hlen > sizeof(struct ip) && (hlen >= 0)) { /* !ANSI C will  */
		register unsigned long l;		 /* force hlen to */
		switch (*cp) {				 /* unsigned!     */
		case IPOPT_EOL:
			hlen = 0;
			break;
		case IPOPT_LSRR:
			printf("\nLSRR: ");
			hlen -= 2;
			j = *++cp;
			++cp;
			if (j > IPOPT_MINOFF) for (;;) {
				l = *++cp;
				l = (l<<8) + *++cp;
				l = (l<<8) + *++cp;
				l = (l<<8) + *++cp;
				hlen -= 4;
				j -= 4;
				if (j <= IPOPT_MINOFF)
					break;
			}
			break;
		case IPOPT_RR:
			j = *++cp;	/* get length */
			i = *++cp;	/* and pointer */
			hlen -= 2;
			if (i > j) i = j;
			i -= IPOPT_MINOFF;
			if (i <= 0)
				continue;
			if (i == old_rrlen
			    && cp == (u_char *)buf + sizeof(struct ip) + 2
			    && !bcmp((char *)cp, old_rr, i)
			    && !(pingflags & FLOOD)) {
				printf("\t(same route)");
				i = ((i+3)/4)*4;
				hlen -= i;
				cp += i;
				break;
			}
			old_rrlen = i;
			bcopy((char *)cp, old_rr, i);
			printf("\nRR: ");
			for (;;) {
				l = *++cp;
				l = (l<<8) + *++cp;
				l = (l<<8) + *++cp;
				l = (l<<8) + *++cp;
				hlen -= 4;
				i -= 4;
				if (i <= 0)
					break;
			}
			break;
		case IPOPT_NOP:
			printf("\nNOP");
			break;
		default:
			printf("\nunknown option %x", *cp);
			break;
		}
		hlen--;
		cp++;
	}
	fflush(stdout);
}

/*
 * 			T V S U B
 * 
 * Subtract 2 timeval structs:  out = out - in.
 * 
 * Out is assumed to be >= in.
 */
tvsub( out, in )
register struct timeval *out, *in;
{
	if( (out->tv_usec -= in->tv_usec) < 0 )   {
		out->tv_sec--;
		out->tv_usec += 1000000;
	}
	out->tv_sec -= in->tv_sec;
}


/*
 *  Print a descriptive string about an ICMP header.
 */


pr_icmph( icp )
struct icmp *icp;
{
	switch( icp->icmp_type ) {
	case ICMP_UNREACH:
		switch( icp->icmp_code ) {
		case ICMP_UNREACH_NET:
			printf("xnetdb (ping): got net unreachable\n");
			break;
		case ICMP_UNREACH_HOST:
			printf("xnetdb (ping): got host unreachable\n");
			break;
		case ICMP_UNREACH_PROTOCOL:
			printf("xnetdb (ping): got protocol unreachable\n");
			break;
		case ICMP_UNREACH_PORT:
			printf("xnetdb (ping): got port unreachable\n");
			break;
		case ICMP_UNREACH_NEEDFRAG:
			printf("xnetdb (ping): got frag needed\n");
			break;
		}
		break;
	case ICMP_SOURCEQUENCH:
		printf("xnetdb(ping): got a source quench\n");
		break;
	case ICMP_REDIRECT:
		switch( icp->icmp_code ) {
		case ICMP_REDIRECT_NET:
			printf("xnetdb (ping): redirect network\n");
			break;
		case ICMP_REDIRECT_HOST:
			printf("xnetdb (ping): redirect host\n");
			break;
		case ICMP_REDIRECT_TOSNET:
			printf("xnetdb (ping): redirect TOS and network\n");
			break;
		case ICMP_REDIRECT_TOSHOST:
			printf("xnetdb (ping): redirect TOS and host\n");
			break;
		}
		break;
	case ICMP_TIMXCEED:
		switch( icp->icmp_code ) {
		case ICMP_TIMXCEED_INTRANS:
			printf("xnetdb (ping): time to live exceeded\n");
			break;
		case ICMP_TIMXCEED_REASS:
			printf("xnetdb (ping): frag reassem exceeded\n");
			break;
		}
		break;
	default:
		printf("xnetdb (ping): bad ICMP type: %d\n",icp->icmp_type);
	}
}

/*
 *			I N _ C K S U M
 *
 * Checksum routine for Internet Protocol family headers (C Version)
 *
 */
in_cksum(addr, len)
u_short *addr;
int len;
{
	register int nleft = len;
	register u_short *w = addr;
	register int sum = 0;
	u_short answer = 0;

	/*
	 *  Our algorithm is simple, using a 32 bit accumulator (sum),
	 *  we add sequential 16 bit words to it, and at the end, fold
	 *  back all the carry bits from the top 16 bits into the lower
	 *  16 bits.
	 */
	while( nleft > 1 )  {
		sum += *w++;
		nleft -= 2;
	}

	/* mop up an odd byte, if necessary */
	if( nleft == 1 ) {
		*(u_char *)(&answer) = *(u_char *)w ;
		sum += answer;
	}

	/*
	 * add back carry outs from top 16 bits to low 16 bits
	 */
	sum = (sum >> 16) + (sum & 0xffff);	/* add hi 16 to low 16 */
	sum += (sum >> 16);			/* add carry */
	answer = ~sum;				/* truncate to 16 bits */
	return (answer);
}
