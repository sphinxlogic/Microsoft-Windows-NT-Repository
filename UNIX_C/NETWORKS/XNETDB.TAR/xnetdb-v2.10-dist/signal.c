/*                                                                            */
/*       xnetdb                                                               */
/*                                                                            */
/*       Copyright (C) 1991 The Ohio State University, All Rights Reserved    */
/*       Copyright (C) 1990 Henry Clark, All Rights Reserved                  */
/*                                                                            */
/*       Licensing details are in the file "License"                          */
/*                                                                            */
/*       signal.c                                                             */
/*                                                                            */
/*       this function contains code to do signal stuff                       */
/*                                                                            */


#include "xnetdb.h"


int signal_sighup_handler()

{
  int i;
  char path[300];

  initialized = 0;
  if (monitor) {
    kill(child_pid, SIGKILL);
    wait(0);
  }
  read_config_file();
  read_location_file();
  for (i=0; i<numrouters; i++)
    init_snmp_variables(i);
  init_circuits();
  for (i=0; i<numrouters; i++)
    read_database(i);
  display_map();
  if (monitor) {
    sprintf(path, "%s/xnetdbquery", bpath);
    if ((child_pid = fork()) == 0) {
      execl(path, "xnetdbquery", portnum, cpath, 0);
      printf("Holy Cow, Batman, the execl failed!\n");
    }
  }
  initialized = 1;
}


int signal_sigalarm_handler()

{
  char buf[BUFSIZ];
  char string1[10], string2[60], string3[50]; 
  char string4[60], string5[15], string6[20];
  char command[80];
  int i,j, k, intf_num;
  int change;
  int period, diff, line_speed;
  long int time_diff, max_bytes;
  char path[300];
  char ppid[8];
  int  bigfrog, ug;


  if ((monitor != 1) || (initialized != 1)) {
    longjmp(env, TRUE);
  }
  change = 0;
  gettimeofday(&current_alarm_time, 0);
  while (read(skt, buf, BUFSIZ) > 0) {
    sscanf(buf, "%s %s %s %s %s %s",
                          string1, string2, string3, string4, string5, string6);
#ifdef DEBUG
    printf("mesg = %s\n", buf);
#endif DEBUG
    if (strcmp(string1, "RTR") == 0) {
      for (i=0; i<numrouters; i++) 
        for (j=0; j<router[i].numinterfaces; j++)
          if (strcmp(string2, router[i].interface[j].ip_address) == 0) {
            gettimeofday(&last_alarm_time, 0);
            sscanf(string4, "%d", &intf_num);
            if (intf_num != router[i].interface[j].index) {
              for (k=0; k<router[i].numinterfaces; k++)
                if (router[i].interface[k].index == intf_num)
                  j = k;
            }
            if (strcmp(string5, "UP") == 0) {
              if (router[i].interface[j].oper_status != 1) {
                if ((router[i].type == ISAHOST) || 
                                          (router[i].type == ISAHOSTPINGER))
                  sprintf(event, "Host %s interface %d came UP!",
                                                       router[i].routername, j);
                else
                  sprintf(event, "Router %s interface %d came UP!",
                                                       router[i].routername, j);
                make_event();
                show_event();
                change = 1;
                if (verbose)
                   printf("Xnetdb: Router %s interface %d came up!\n",
                                                       router[i].routername, j);
              }
              router[i].interface[j].oper_status = 1;
            }
            if (strcmp(string5, "DN") == 0) {
              if (router[i].interface[j].oper_status != 2) {
                if ((router[i].type == ISAHOST) || 
                                          (router[i].type == ISAHOSTPINGER))
                  sprintf(event, "Host %s interface %d went DOWN!",
                                                       router[i].routername, j);
                else
                  sprintf(event, "Router %s interface %d went DOWN!",
                                                       router[i].routername, j);
                make_event();
                show_event();
                change = 1;
                if (verbose)
                   printf("Xnetdb: Router %s interface %d went down!\n",
                                                       router[i].routername, j);
              }
              router[i].interface[j].oper_status = 2;
            }
            if (strcmp(string5, "TG") == 0) {
              if (router[i].interface[j].oper_status != 3) {
                 sprintf(event, "Router %s interface %d in TESTING mode!",
                                                       router[i].routername, j);
                 make_event();
                 show_event();
                 change = 1;
                 if (verbose)
                   printf("Xnetdb: Router %s interface %d now testing!\n",
                                                       router[i].routername, j);
               }
               router[i].interface[j].oper_status = 3;
             }
             if (strcmp(string5, "INOCTETS") == 0) {
               sscanf(buf, "%s %s %s %s %s %d", string1, string2, string3,
                                             string4, string5, 
                                             &router[i].interface[j].inoctets);
               if (verbose)
                 printf("Xnetdb: Router %s interface %d inoctets %u\n", 
                     router[i].routername, j, router[i].interface[j].inoctets);
             }
           }
    }
    if (strcmp(string1, "VAR") == 0) {
      if (strcmp(string4, "OK") != 0) {
        sprintf(event, "%s %s in Error!", string2, string4);
        make_event();
        show_event();
        if (verbose)
          printf("Xnetdb: Variable %s %s in error!\n", string2, string4);
      }
    }
    for (i=0; i<BUFSIZ; i++)
      buf[i] = 0x00;
  }

  gettimeofday(&curr_circuit_stats, 0);
  if ((curr_circuit_stats.tv_sec - prev_circuit_stats.tv_sec)>(SLEEP_TIME * 5)){
    time_diff =  curr_circuit_stats.tv_sec -  prev_circuit_stats.tv_sec;
    for (i=0; i<numcircuits; i++) {
      period = 
          router[circuit[i].from_rtr].interface[circuit[i].from_intf].inoctets +
          router[circuit[i].to_rtr].interface[circuit[i].to_intf].inoctets;
      if ((router[circuit[i].from_rtr].interface[circuit[i].from_intf].speed < router[circuit[i].to_rtr].interface[circuit[i].to_intf].speed ) &&
          (router[circuit[i].from_rtr].interface[circuit[i].from_intf].speed > 1000))
        line_speed = router[circuit[i].from_rtr].interface[circuit[i].from_intf].speed;
      else
        if ( router[circuit[i].to_rtr].interface[circuit[i].to_intf].speed > 1000 )
          line_speed = router[circuit[i].to_rtr].interface[circuit[i].to_intf].speed;


      if (circuit[i].usage.lastoctets == 0)
        diff = 0;
      else
        diff = period - circuit[i].usage.lastoctets;
      max_bytes = (line_speed / 8) * time_diff;
      if (max_bytes <= 0) max_bytes = 1000000000;
      circuit[i].usage.curr =  ((float) diff / (float) max_bytes) * 100;

      if (circuit[i].usage.curr < 0)  circuit[i].usage.curr = 0;
      if (circuit[i].usage.curr > 100)  circuit[i].usage.curr = 100;
      if (circuit[i].usage.curr < circuit[i].usage.min)
        circuit[i].usage.min = circuit[i].usage.curr;
      if (circuit[i].usage.curr > circuit[i].usage.max)
        circuit[i].usage.max = circuit[i].usage.curr;
      circuit[i].usage.lastoctets = period;

#ifdef DEBUG
      printf("circuit[%d] (%s) usage stats\n", i, circuit[i].subnet);
      printf("circuit[%d] speed = %d diff/max = %d / %d \n", i, line_speed,
                                                               diff, max_bytes);
      printf("circuit[%d].usage min/curr/max = %2.3f/%2.3f/%2.3f\n", i, 
             circuit[i].usage.min, circuit[i].usage.curr, circuit[i].usage.max);
      printf("circuit[%d].usage.lastoctets = %d\n", i, 
                                                   circuit[i].usage.lastoctets);
#endif DEBUG

      prev_circuit_stats.tv_sec = curr_circuit_stats.tv_sec;
    }
  }

  if ((current_alarm_time.tv_sec - last_alarm_time.tv_sec) > 300) {
    sprintf(event, "Xnetdbquery process may be DEAD!");
    make_event();
    show_event();
  }  

  gettimeofday(&current_resurrect_time, 0);
  if ((current_resurrect_time.tv_sec - last_resurrect_time.tv_sec) >
                                                               RESURRECT_TIME) {
    if (fork() == 0) {
      sleep(5);
      sprintf(ppid, "%d", getppid());
      execl("/bin/kill", "kill", "-USR1", ppid, 0);
    }
    gettimeofday(&last_resurrect_time, 0);
  }

  if (b_w && change)
    display_map();
  else
    redisplay_map();
  XFlush(mydisplay);
  alarm(15);
}


int signal_sigusr1_handler()

{
  int  i;
  char path[300];
  int  *cowptr;

  wait(0);
  initialized = 0;
  printf("xnetdb: processing USR1 signal...\n");
  for (i=0; i<numrouters; i++) {
    if (router[i].numinterfaces == 0) {
      if (make_snmp_query(router[i].netaddress, "1.3.6.2.1.2.2.1.0", 
                                                 router[i].community, 2) != -1){
        init_snmp_variables(i);
        init_router_box(i);
        init_circuits();
        read_database(i);
        init_circuits();
        init_query();
        kill(child_pid, SIGKILL);
        wait(0);
        sprintf(path, "%s/xnetdbquery", bpath);
        printf("xnetdb: execing %s %s %s\n", path, portnum, cpath);
        if ((child_pid = fork()) == 0) {
          execl(path, "xnetdbquery", portnum, cpath, 0);
          printf("Holy Cow, Batman, the execl failed!\n");
          exit(1);
        }
        display_map();
      }
    }
  }
  printf("xnetdb: USR1 signal processing complete\n");
  initialized = 1;
  alarm(15);
}


int signal_sigquit_handler()

{
  char filename[300];
  int frog;
  char froggie[100];

  printf("xnetdb exiting...");
  sprintf(filename, "%s/location.cf", cpath);
  frog = open(filename, O_TRUNC | O_CREAT | O_RDWR, 0644);
  for (i=0; i<numrouters; i++) {
    sprintf(froggie, "%s\t%d\t%d\n", router[i].routername, 
                                     router[i].map.x, router[i].map.y);
    write(frog, froggie, strlen(froggie));
  }
  close(frog);
  if (logging)
    close(log_file);
  if (monitor) {
    close(skt);
    kill(child_pid, SIGKILL);
  }
  XFreeGC(mydisplay, mygc);
  XDestroyWindow(mydisplay, mywindow);
  XCloseDisplay(mydisplay);
  printf("done\n");
  exit(0);
}
