/*                                                                            */
/*       xnetdb                                                               */
/*                                                                            */
/*       Copyright (C) 1991 The Ohio State University, All Rights Reserved    */
/*       Copyright (C) 1990 Henry Clark, All Rights Reserved                  */
/*                                                                            */
/*       Licensing details are in the file "License"                          */
/*                                                                            */
/*       init.c                                                               */
/*                                                                            */
/*       read the data config files and init xnetdb....                       */
/*                                                                            */


#include "xnetdb.h"


int read_config_file()

{
  int j, fintf, tintf;
  char string1[30], string2[30], string3[30], string4[30];

  numrouters = 0;
  numcircuits = 0;
  sprintf(filename, "%s/xnetdb.cf", cpath);
  if ((datafile = open(filename, O_RDONLY)) == -1) {
    printf("xnetdb: can't find configuration file %s\n", filename);
    exit(1);
  }
  while (fetch_more_data() != 0)
    if ((buffer[0] != '#') || (strlen(buffer) == 0)) {
      sscanf(buffer, "%s", string1);
      if (strcmp(string1, "ROUTER") == 0) {
        sscanf(buffer, "%s %s %s %s %s %s", 
                 string1, router[numrouters].pathname,
                 router[numrouters].routername, router[numrouters].mapname, 
                 router[numrouters].netaddress, router[numrouters].community);
        if (strcmp(router[numrouters].community, "--PING--") == 0)
          router[numrouters].type = ISAROUTERPINGER;
        else
          router[numrouters].type = ISAROUTER;
        numrouters++;
      }
      if (strcmp(string1, "CIRCUIT") == 0) {
        sscanf(buffer, "CIRCUIT %s INTERFACE %s TO %s INTERFACE %s", 
                                          string1, string2, string3, string4);
        for (i=0; i<numrouters; i++)
          if (strcmp(string1, router[i].routername) == 0)
            for (j=0; j<numrouters; j++)
              if (strcmp(string3, router[j].routername) == 0) {
                sscanf(string2, "%d", &fintf);
                sscanf(string4, "%d", &tintf);
                router[i].interface[fintf-1].index = fintf;
                router[j].interface[tintf-1].index = tintf;
                tintf--;
                fintf--;
                sprintf(router[i].interface[fintf].ip_address,
                                                             "500.500.500.500");
                sprintf(router[i].interface[fintf].subnet_mask,
                                                             "100.200.300.400");
                sprintf(router[j].interface[tintf].ip_address,
                                                             "500.500.500.500");
                sprintf(router[j].interface[tintf].subnet_mask,
                                                             "100.200.300.400");
                circuit[numcircuits].valid = 1;
		sprintf(circuit[numcircuits].subnet, "500.500.500.500");
                circuit[numcircuits].numcontacts = 0;
                circuit[numcircuits].from_rtr = i;
                circuit[numcircuits].to_rtr = j;
                circuit[numcircuits].from_intf = fintf;
                circuit[numcircuits].to_intf = tintf;
                numcircuits++;
              }
      }
      if (strcmp(string1, "HOST") == 0) {
        sscanf(buffer, "%s %s %s %s %s %s", 
                 string1, router[numrouters].pathname,
                 router[numrouters].routername, router[numrouters].mapname, 
                 router[numrouters].netaddress, router[numrouters].community);
        if (strcmp(router[numrouters].community, "--PING--") == 0)
          router[numrouters].type = ISAHOSTPINGER;
        else
          router[numrouters].type = ISAHOST;
        numrouters++;
      }
    }
  close(datafile);
}


int init_snmp_variables(i)

int i;

{
  char string1[30], string2[30], string3[30], cowshit[30];
  char string4[30], string5[30], string6[40];
  char object[100];
  int  numboards, numcontacts;
  int  carrier, circuitflag, routerflag;
  int  j,k;
  int  subnet_len;
  int  found;
  int  crnt_crct;
  struct {
    char address[30];
    int  intf_num;
  } ip_address[30];
  int  numintf;
  int  xmin, ymin, xmax, ymax;
  int  cow_moo, frog;
  char result[20], address[20];
  int pos, q, copy;
  int qcow, moocow;
  int cows_go_moo;
  int mtu;
  char physical_address[40];
  int  n1, n2, n3, n4, n5, n6;
  char c1;
  int  offset, temp_index, real_interfaces;
  int  birds;

                             /* get the number of interfaces on this router */

  if (make_snmp_query(router[i].netaddress, "1.3.6.1.2.1.2.1.0", 
                                                router[i].community, 5) == -1) {

                                  /* oops, router is dead */

    router[i].numinterfaces = 0;
    for (j=0; j<MAXNUMROUTERINTERFACES; j++) {
      sprintf(router[i].interface[j].ip_address, "500.500.500.500");
      router[i].interface[j].oper_status = 2;
      router[i].interface[j].admin_status = 2;
    }
    printf("Router %s is DEAD!\n", router[i].routername);
    goto EndOfLoop;
  }
  sscanf(snmp_buffer, "%s %d", result, &router[i].numinterfaces);
  if (strcmp(result, "Integer") != 0) {
    printf("xnetdb: init: got a %s for ifNumber_0\n", result);
    exit(1);
  }

  real_interfaces = 0;

  for (j=0; j<router[i].numinterfaces; j++) {

                             /* get the snmp index of each interface */

    if (j == 0)
      offset = 0;
    else
      offset = router[i].interface[j-1].index;
    router[i].interface[j].index = 0;
    while (router[i].interface[j].index == 0) {
      offset++;
      sprintf(object, "1.3.6.1.2.1.2.2.1.1.%d", offset);
      make_snmp_query(router[i].netaddress, object, router[i].community, 2);
      sscanf(snmp_buffer, "%s %d", result, &temp_index);
      if (strcmp(result, "Integer") != 0) {
        printf("xnetdb: init: got a %s for ifIndex_%d\n", result, offset);
      }
      else {
        router[i].interface[j].index = offset;
        real_interfaces++;
      }
      if (offset > router[i].numinterfaces) {
        j = 100;
        router[i].numinterfaces = real_interfaces;
        break;
      }
    }

    if (j >= 100) break;

#ifdef DEBUG
    printf("xnetdb: assigning snmp index %d to router %s interface %d\n", 
                                               offset, router[i].routername, j);
#endif DEBUG

                             /* Check ifAdminStatus of each interface */

    sprintf(object, "1.3.6.1.2.1.2.2.1.7.%d", router[i].interface[j].index);
    make_snmp_query(router[i].netaddress, object, router[i].community, 2);
    sscanf(snmp_buffer, "%s %d", result, &router[i].interface[j].admin_status);
    if (strcmp(result, "Integer") != 0) {
      printf("xnetdb: init: got a %s for ifAdminStatus_%d\n", result, j+1);
      exit(1);
    }

                             /* Check ifOperStatus of each interface */

    sprintf(object, "1.3.6.1.2.1.2.2.1.8.%d", router[i].interface[j].index);
    make_snmp_query(router[i].netaddress, object, router[i].community, 2);
    sscanf(snmp_buffer, "%s %d", result, &router[i].interface[j].oper_status);
    if (strcmp(result, "Integer") != 0) {
      printf("xnetdb: init: got a %s for ifOperStatus_%d\n", result, j+1);
      exit(1);
    }

                             /* Now continue with querying iff the interface */
                             /*   is operational                             */

    if ((router[i].interface[j].admin_status == 2) &&
          (router[i].interface[j].oper_status == 2)) {
        sprintf(router[i].interface[j].ip_address, "500.500.500.500");
    }
    else {

                             /* get line speed of each interface */

      sprintf(object, "1.3.6.1.2.1.2.2.1.5.%d", router[i].interface[j].index);
      make_snmp_query(router[i].netaddress, object, router[i].community, 2);
      sscanf(snmp_buffer, "%s %d", result, &router[i].interface[j].speed);
      if ((strcmp(result,"Guage") != 0)||(router[i].interface[j].speed < 1000)){
        if (router[i].type == ISAHOST) {
          sprintf(object, "1.3.6.1.2.1.2.2.1.4.%d", 
                                                  router[i].interface[j].index);
          make_snmp_query(router[i].netaddress, object, router[i].community, 2);
          sscanf(snmp_buffer, "%s %d", result, &mtu);
          if ((mtu >= 1450) && (mtu <= 1500)) 
            router[i].interface[j].speed = 10000000;
          else 
            if (mtu > 4000)
              router[i].interface[j].speed = 50000000;
            else {
              router[i].interface[j].oper_status = 2;
              router[i].interface[j].admin_status = 2;
              sprintf(router[i].interface[j].ip_address, "500.500.500.500");
            }
        }
        else 
          if (router[i].type != ISAROUTER) {
            printf("xnetdb: init: got a %s for ifSpeed_%d\n", result, j+1);
            exit(1);
          }
      }


                             /* get hardware type of each interface */

      sprintf(object, "1.3.6.1.2.1.2.2.1.2.%d", router[i].interface[j].index);
      make_snmp_query(router[i].netaddress, object, router[i].community, 2);
      copy = 0;
      pos = 0;
      for (q=0; q<strlen(snmp_buffer); q++) {
        if (snmp_buffer[q] == '"') {
          if (copy) 
            copy = 0;
          else
            copy = 1;
        }
        else {
          if (snmp_buffer[q] == 92) {
            if (copy) 
              copy = 0;
          }
        }
        if ((copy) && (snmp_buffer[q] != '"') && (snmp_buffer[q] != 92)) {
          router[i].interface[j].board[pos] = snmp_buffer[q];
          pos++;
        }
      }
      router[i].interface[j].board[pos] = '\0';
    }
  }

                             /* get interface addresses */

                             /* first get all interface ip addresses */

  birds = make_snmp_mquery(router[i].netaddress, "1.3.6.1.2.1.4.20.1.1", 
							router[i].community);
#ifdef SNMPDEBUG
  printf("Raw snmp_mbuffer table for %s\n", router[i].routername);
  for (j=0; j<=router[i].numinterfaces; j++)  
    printf("snmp_mbuffer[%d].buffer = %s\n", j, snmp_mbuffer[j].buffer);
#endif SNMPDEBUG

                             /* now get all interface ip address index */
                             /* and match address index to an interface */

  numintf = 0;
  for (j=0; j<=router[i].numinterfaces; j++) {

                             /* first get the ip address */

    sscanf(snmp_mbuffer[j].buffer, "%s %s", result, address);

                             /* if we have a reasonable looking ip address... */

    if (strcmp(result, "IPAddr") == 0) 
      if ((strlen(address) >= 7) && (strncmp(address, "255", 3) != 0)) {

                             /* get the interface number for the ip address */

        sprintf(object,"1.3.6.1.2.1.4.20.1.2.%s", address);
        make_snmp_query(router[i].netaddress, object, router[i].community, 2);
        sscanf(snmp_buffer, "%s %d", result, &frog);
  
        if (strcmp("Integer", result)  == 0)
          for (k=0; k<router[i].numinterfaces; k++) 
            if ((frog > 0) && (frog == router[i].interface[k].index) &&
                (router[i].interface[k].admin_status == 1))
              sprintf(router[i].interface[k].ip_address, "%s", address);
      }
  }
  for (j=0; j<router[i].numinterfaces; j++)
    if (strcmp(router[i].interface[j].ip_address, "127.0.0.1") == 0) {
      sprintf(router[i].interface[j].ip_address, "500.500.500.500");
      router[i].interface[j].oper_status = 2;
      router[i].interface[j].admin_status = 2;
      router[i].interface[j].speed = 0;
      router[i].interface[j].board[0] = '\0';
    }

  for (j=0; j<router[i].numinterfaces; j++)
    if ((strcmp("500.500.500.500", router[i].interface[j].ip_address) != 0) &&
        (strlen(router[i].interface[j].ip_address) >= 7)) {

                                        /* get subnet mask of interface */

      sprintf(object,"1.3.6.1.2.1.4.20.1.3.%s", 
                                             router[i].interface[j].ip_address);
      make_snmp_query(router[i].netaddress, object, router[i].community, 2);
      sscanf(snmp_buffer, "%s %s", result, address);
      if (strcmp("IPAddr", result)  != 0) {
        printf("xnetdb: got a %s for _ipAdEntNetMask\n", result);
        printf("address = %s\n", address);
        exit(1);
      }
      sprintf(router[i].interface[j].subnet_mask, "%s", address);
    } 

EndOfLoop:
  cows_go_moo++;
}


int init_router_box(i)

int i;

{
  XCharStruct overall;
  int        total_width, total_height;
  int direction_hint;
  int font_ascent, font_descent;

  XTextExtents(font_struct, router[i].mapname, 
                 strlen(router[i].mapname), &direction_hint, 
                 &font_ascent, &font_descent, &overall);
  total_width = (int) overall.lbearing + (int) overall.rbearing;
  total_height = (int) -overall.ascent + (int) overall.descent;
  router[i].map.computed.x1 = router[i].map.x - 3;
  router[i].map.computed.y1 = router[i].map.y - 6 - abs(total_height);
  router[i].map.computed.x2 = abs(total_width) + 5;
  router[i].map.computed.y2 = abs(total_height) + 10;
}


int init_circuits()

{
  char string1[30], string2[30], string3[30], cowshit[30];
  char string4[30], string5[30], string6[40], string7[30], string8[30];
  char object[100];
  int  numboards, numcontacts;
  int  carrier, circuitflag, routerflag;
  int  j,k;
  char subnet_mask[20];
  int  found;
  int  crnt_crct;
  struct {
    char address[30];
    int  intf_num;
  } ip_address[30];
  int  numintf;
  int  xmin, ymin, xmax, ymax;
  int  cow_moo, frog;
  char result[20], address[20];
  int  xmidpt, ymidpt, xavg, yavg;
  char filename[240];
  int  subnet_length;
  char *lastplace1, *lastplace2;
  int  qa, qb, qc, qd, qi, qj, qm, qn, qr, qs, qt, qu;

  for (i=0; i<numrouters; i++)
    for (j=0; j<router[i].numinterfaces; j++)
      if ((router[i].interface[j].speed != 10000000) &&
          (router[i].interface[j].speed < 60000000) &&
          (strcmp(router[i].interface[j].ip_address, "500.500.500.500") != 0) &&
          (strlen(router[i].interface[j].ip_address) >= 7)) {
         make_subnet(router[i].interface[j].ip_address, 
                     router[i].interface[j].subnet_mask, subnet_mask);
         found = 0;
         for (k=0; k<numcircuits; k++) 
           if ((strcmp(subnet_mask, circuit[k].subnet) == 0) &&
               (strlen(subnet_mask) == strlen(circuit[k].subnet))){
             found = 1;
             circuit[k].to_rtr = i;
             circuit[k].to_intf = j;
             if (circuit[k].to_rtr == circuit[k].from_rtr)
               circuit[k].valid = 0;
             else
               circuit[k].valid = 1;
#ifdef DEBUG
             printf("assigning circuit %s to_rtr as %s\n", 
                                       circuit[k].subnet, router[i].routername);
#endif DEBUG
           }
           else {
             lastplace1 = rindex(router[i].interface[j].ip_address, '.');
             qi = circuit[k].from_rtr;
             qj = circuit[k].from_intf;
             lastplace2 = rindex(router[qi].interface[qj].ip_address, '.');
             qm = lastplace1 - router[i].interface[j].ip_address;
             qn = lastplace2 - router[qi].interface[qj].ip_address;
             sscanf(router[i].interface[j].subnet_mask, "%d.%d.%d.%d", 
                                                           &qr, &qs, &qt, &qu);
             sscanf(router[qi].interface[qj].subnet_mask, "%d.%d.%d.%d", 
                                                           &qa, &qb, &qc, &qd);
             if ((qm == qn) && 
                 (strncmp(router[i].interface[j].ip_address, 
                              router[qi].interface[qj].ip_address, qm) == 0) &&
                 (qr == 255) && (qa == 255) &&
                 (qs == 255) && (qb == 255) &&
                 (qt != qc) &&
                 (qu == 0) && (qd == 0))
               printf("xnetdb: possible subnet problem with %s and %s\n", 
                                        router[i].interface[j].ip_address, 
                                        router[qi].interface[qj].ip_address); 
           }
         if (found == 0) {
           sprintf(circuit[numcircuits].subnet, "%s", subnet_mask);
           circuit[numcircuits].from_rtr = i;
           circuit[numcircuits].from_intf = j;
           circuit[numcircuits].valid = 0;
#ifdef DEBUG
           printf("assigning circuit %s from_rtr as %s\n", 
                             circuit[numcircuits].subnet, router[i].routername);
#endif DEBUG
           numcircuits++;
         }
      }

                                   /* finally, init ethernet stuff */

  numethernets = 0;
  for (i=0; i<numrouters; i++)
    for (j=0; j<router[i].numinterfaces; j++)
      if (((router[i].interface[j].speed == 10000000) || 
           (router[i].interface[j].speed >= 60000000))&& 
          (strlen(router[i].interface[j].ip_address) >= 7) &&
          (strcmp(router[i].interface[j].ip_address, "500.500.500.500") != 0)) {
        make_subnet(router[i].interface[j].ip_address, 
                     router[i].interface[j].subnet_mask, subnet_mask);
        found = 0;
        if (router[i].interface[j].speed == 80000000) proteon_flag = 1;
        for (k=0; k<numethernets; k++) 
          if (strcmp(ethernet[k].subnet, subnet_mask) == 0) {
            ethernet[k].member[ethernet[k].nummembers].router = i;
            ethernet[k].member[ethernet[k].nummembers].interface = j;
            ethernet[k].nummembers++;
            found = 1;
          }
        if (found == 0) {
          sprintf(ethernet[numethernets].subnet, "%s", subnet_mask);
            ethernet[k].member[0].router = i;
            ethernet[k].member[0].interface = j;
          ethernet[numethernets].nummembers = 1;
	  ethernet[numethernets].speed = router[i].interface[j].speed;
          numethernets++;
        }
      }
        
  for (i=0; i<numethernets; i++) 
    if ((ethernet[i].nummembers > 1) && (ethernet[i].speed == 10000000)) {
      xmin = 10000;
      xmax = 0;
      ymin = 10000;
      ymax = 0;
      for (j=0; j<ethernet[i].nummembers; j++) {
        xmidpt =  router[ethernet[i].member[j].router].map.computed.x1 +
                  (router[ethernet[i].member[j].router].map.computed.x2 / 2);
        ymidpt =  router[ethernet[i].member[j].router].map.computed.y1 +
                  (router[ethernet[i].member[j].router].map.computed.y2 / 2);
        if (xmidpt < xmin) xmin = xmidpt;
        if (xmidpt > xmax) xmax = xmidpt;
        if (ymidpt < ymin) ymin = ymidpt;
        if (ymidpt > ymax) ymax = ymidpt;
      }

                             /* horizontal line */

      if ((xmax - xmin) > (ymax - ymin)) {

        ethernet[i].x_start = xmin;
        ethernet[i].x_end = xmax;
        yavg = (ymax + ymin) / 2;
        if ((ymax - yavg) < 10) yavg += 20;
        ethernet[i].y_start = yavg;
        ethernet[i].y_end = yavg;
      }

                             /* vertical line */

      else {
        xavg = (xmax + xmin) / 2;
        if ((xmax - xmin) < 10) xavg += 20;
        ethernet[i].x_start = xavg;
        ethernet[i].x_end = xavg;
        ethernet[i].y_start = ymin;
        ethernet[i].y_end = ymax;
      }
    }

  for (i=0; i<numethernets; i++) 
    if ((ethernet[i].nummembers > 1) && (ethernet[i].speed >= 60000000)) {
      xmin = 10000;
      xmax = 0;
      ymin = 10000;
      ymax = 0;
      for (j=0; j<ethernet[i].nummembers; j++) {
        if (router[ethernet[i].member[j].router].map.computed.x1 < xmin)
          xmin =  router[ethernet[i].member[j].router].map.computed.x1;
        if (router[ethernet[i].member[j].router].map.computed.x1 > xmax)
          xmax =  router[ethernet[i].member[j].router].map.computed.x1;
        if (router[ethernet[i].member[j].router].map.computed.y1 < ymin)
          ymin =  router[ethernet[i].member[j].router].map.computed.y1;
        if (router[ethernet[i].member[j].router].map.computed.y1 > ymax)
          ymax =  router[ethernet[i].member[j].router].map.computed.y1;
      }
      ethernet[i].x_start = xmin + (xmin * 0.2);
      ethernet[i].y_start = ymin + (ymin * 0.1);
      ethernet[i].x_end = (xmax - xmin) / 2;
      ethernet[i].y_end = (ymax - ymin) / 2;
    }
}


int  init_query()

{
  int j;
  char cow[100];

  sprintf(filename, "%s/xnetdbquery.cf", cpath);
  datafile = open(filename, O_TRUNC | O_CREAT | O_RDWR, 0644);
  for (i=0; i<numrouters; i++)
    for (j=0; j<router[i].numinterfaces; j++) {
      if ((strcmp(router[i].interface[j].ip_address, "500.500.500.500") != 0) &&
          (strlen(router[i].interface[j].ip_address) >= 7)) {
        sprintf(cow, "%s %d %s\n", router[i].interface[j].ip_address, 
                                      router[i].interface[j].index,
                                      router[i].community);
        write(datafile, cow, strlen(cow));
      }
      if ((strcmp(router[i].interface[j].ip_address, "500.500.500.500") == 0) &&
          (strcmp(router[i].interface[j].subnet_mask, 
                                                     "100.200.300.400") == 0)) {
        sprintf(cow, "%s %d %s\n", router[i].netaddress,
                                      router[i].interface[j].index,
                                      router[i].community);
        write(datafile, cow, strlen(cow));
      }
    }
  close(datafile);
}


int fetch_more_data()

{
  char charbuf;
  int  cow;

  bufferlen = 0;
  while ((cow = read(datafile, &charbuf, 1)) != 0) {
    if ((bufferlen == 0) && ((charbuf == ' ') || (charbuf == '\t')))
      continue;
    buffer[bufferlen] = charbuf;
    if (buffer[bufferlen] == '\n') break;
    bufferlen++;
  }
  buffer[bufferlen] = '\0';
  return cow;
}


int read_database(i)

int i;

{
  char filename[240], pathname[240], string[40];
  FILE *cow;
  int  field, moo, numboards, numcontacts;
  int  j;
  char string1[40], string2[40];
  char s1[20], s2[20], s3[20], s4[20], s5[20];
  int  eof, numintf;

  sprintf(pathname, "%s/%s", DATABASEPATH, router[i].pathname);
  sprintf(filename, "%s/Routers/%s/remoteaccess", pathname, 
                                                         router[i].routername);
  if ((cow = fopen(filename, "r")) != NULL) {
    fscanf(cow, "%s %d", router[i].remoteaccess.phone, 
                                                 &router[i].remoteaccess.baud);
    fclose(cow);
  }
  sprintf(filename, "%s/Routers/%s/reportname", pathname, 
                                                         router[i].routername);
  if ((cow = fopen(filename, "r")) != NULL) {
    fscanf(cow, "%s", router[i].reportname);
    fclose(cow);
  }
  sprintf(filename, "%s/domainname", pathname);
  if ((cow = fopen(filename, "r")) != NULL) {
    fscanf(cow, "%s", router[i].domainname);
    fclose(cow);
  }
  numboards = 0;
  sprintf(filename, "%s/Routers/%s/hardware", pathname, router[i].routername);
  if ((datafile = open(filename, O_RDONLY)) != -1) {
    if (fetch_more_data() != 0)
      sscanf(buffer, "%s %s %s %s", string1, router[i].serialnumber, 
                                       router[i].manufacturer, router[i].model);
    while (fetch_more_data() != 0) {
      sscanf(buffer, "%s %s %s", router[i].board[numboards].name,
                                   router[i].board[numboards].rev_level, 
                                   router[i].board[numboards].serial_num);
      numboards++;
    }
    router[i].numboards = numboards;
    close(datafile);
  }
  numcontacts = 0;
  sprintf(filename, "%s/Contacts/primary", pathname);
  if ((datafile = open(filename, O_RDONLY)) != -1) {
    field = 0;
    while (fetch_more_data() != 0)
      if (buffer[0] != '#') {
        switch (field) {
          case 0: sprintf(router[i].contacts[numcontacts].name, "%s", buffer);
                  break;
          case 1: sprintf(router[i].contacts[numcontacts].addr1, "%s", buffer);
                  break;
          case 2: sprintf(router[i].contacts[numcontacts].addr2, "%s", buffer);
                  break;
          case 3: sscanf(buffer, "%s %s %s", 
                            router[i].contacts[numcontacts].city, 
                            router[i].contacts[numcontacts].state, 
                            router[i].contacts[numcontacts].zip);
                  break;
          case 4: sprintf(router[i].contacts[numcontacts].phone, "%s", buffer);
                  break;
          case 5: sprintf(router[i].contacts[numcontacts].email, "%s", buffer);
                  break;
          case 6: sprintf(router[i].contacts[numcontacts].comment, "%s",buffer);
                  break;
        }
        if (field >= 6) {
          field = 0;
          numcontacts++;
        }
        else
          field++;
      }
    close(datafile);
  }
  sprintf(filename, "%s/Contacts/secondary", pathname);
  if ((datafile = open(filename, O_RDONLY)) != -1) {
    field = 0;
    while (fetch_more_data() != 0)
      if (buffer[0] != '#') {
        switch (field) {
          case 0: sprintf(router[i].contacts[numcontacts].name, "%s", buffer);
                  break;
          case 1: sprintf(router[i].contacts[numcontacts].addr1, "%s", buffer);
                  break;
          case 2: sprintf(router[i].contacts[numcontacts].addr2, "%s", buffer);
                  break;
          case 3: sscanf(buffer, "%s %s %s", 
                            router[i].contacts[numcontacts].city, 
                            router[i].contacts[numcontacts].state, 
                            router[i].contacts[numcontacts].zip);
                  break;
          case 4: sprintf(router[i].contacts[numcontacts].phone, "%s", buffer);
                  break;
          case 5: sprintf(router[i].contacts[numcontacts].email, "%s", buffer);
                  break;
          case 6: sprintf(router[i].contacts[numcontacts].comment, "%s",buffer);
                  break;
        }
        if (field >= 6) {
          field = 0;
          numcontacts++;
        }
        else
          field++;
      }
    close(datafile);
  }
  sprintf(filename, "%s/Contacts/others", pathname);
  if ((datafile = open(filename, O_RDONLY)) != -1) {
    field = 0;
    while (fetch_more_data() != 0)
      if (buffer[0] != '#') {
        switch (field) {
          case 0: sprintf(router[i].contacts[numcontacts].name, "%s", buffer);
                  break;
          case 1: sprintf(router[i].contacts[numcontacts].addr1, "%s", buffer);
                  break;
          case 2: sprintf(router[i].contacts[numcontacts].addr2, "%s", buffer);
                  break;
          case 3: sscanf(buffer, "%s %s %s", 
                            router[i].contacts[numcontacts].city, 
                            router[i].contacts[numcontacts].state, 
                            router[i].contacts[numcontacts].zip);
                  break;
          case 4: sprintf(router[i].contacts[numcontacts].phone, "%s", buffer);
                  break;
          case 5: sprintf(router[i].contacts[numcontacts].email, "%s", buffer);
                  break;
          case 6: sprintf(router[i].contacts[numcontacts].comment, "%s",buffer);
                  break;
        }
        if (field >= 6) {
          field = 0;
          numcontacts++;
        }
        else
          field++;
      }
    close(datafile);
  }
  router[i].numcontacts = numcontacts;
  for (j=0; j<numcircuits; j++)
    if (strcmp(router[i].routername, 
                                 router[circuit[j].from_rtr].routername) == 0) {
      sprintf(pathname,"%s/%s/Circuits/%s-%s", DATABASEPATH, router[i].pathname,
                                     router[circuit[j].from_rtr].routername,
                                     router[circuit[j].to_rtr].routername);
      sprintf(filename, "%s/circuit", pathname);
      if ((cow = fopen(filename, "r")) != NULL) {
        fscanf(cow, "%s %s", circuit[j].pri_carrier.name,
                                             circuit[j].pri_carrier.circuitnum);
        fscanf(cow, "%s %s", circuit[j].sec_carrier.name,
                                             circuit[j].sec_carrier.circuitnum);
        fclose(cow);
      }
      sprintf(filename, "%s/csu", pathname);
      if ((cow = fopen(filename, "r")) != NULL) {
        while (fscanf(cow, "%s %s %s %s %s", s1, s2, s3, s4, s5) > 0) 
         if (strcmp(s1, router[circuit[j].from_rtr].routername) == 0) {
           sprintf(circuit[j].from_csu.manufacturer, "%s", s2);
           sprintf(circuit[j].from_csu.model, "%s", s3);
           sprintf(circuit[j].from_csu.rev_level, "%s", s4);
           sprintf(circuit[j].from_csu.serial_num, "%s", s5);
         }
         else {
           sprintf(circuit[j].to_csu.manufacturer, "%s", s2);
           sprintf(circuit[j].to_csu.model, "%s", s3);
           sprintf(circuit[j].to_csu.rev_level, "%s", s4);
           sprintf(circuit[j].to_csu.serial_num, "%s", s5);
          }
        fclose(cow);
      }
      numcontacts = 0;
      sprintf(filename, "%s/contacts", pathname);
      if ((datafile = open(filename, O_RDONLY)) != -1) {
        field = 0;
        while (fetch_more_data() != 0)
          if (buffer[0] != '#') {
            switch (field) {
          case 0: sprintf(circuit[j].contact[numcontacts].name, "%s", buffer);
                  break;
          case 1: sprintf(circuit[j].contact[numcontacts].addr1, "%s", buffer);
                  break;
          case 2: sprintf(circuit[j].contact[numcontacts].addr2, "%s", buffer);
                  break;
          case 3: sscanf(buffer, "%s %s %s", 
                            circuit[j].contact[numcontacts].city, 
                            circuit[j].contact[numcontacts].state, 
                            circuit[j].contact[numcontacts].zip);
                  break;
          case 4: sprintf(circuit[j].contact[numcontacts].phone, "%s", buffer);
                  break;
          case 5: sprintf(circuit[j].contact[numcontacts].email, "%s", buffer);
                  break;
          case 6: sprintf(circuit[i].contact[numcontacts].comment, "%s",buffer);
                  break;
            }
            if (field >= 6) {
              field = 0;
              numcontacts++;
            }
            else
              field++;
          }
        close(datafile);
        circuit[j].numcontacts = numcontacts;
      }
    }
  if ((router[i].type == ISAHOSTPINGER)||(router[i].type == ISAROUTERPINGER)) { 
    if (router[i].type == ISAHOSTPINGER)
      sprintf(filename, "%s/%s/Hosts/%s/interfaces", DATABASEPATH,
                                      router[i].pathname, router[i].routername);
    else
      sprintf(filename, "%s/%s/Routers/%s/interfaces", DATABASEPATH,
                                      router[i].pathname, router[i].routername);
    if ((cow = fopen(filename, "r")) == NULL) {
      printf("xnetdb: unable to find interfaces file for %s\n", 
                                                          router[i].routername);
      exit(1);
    }
    numintf = 0;
    eof = fscanf(cow, "%s %s %d", router[i].interface[numintf].ip_address, 
                                      router[i].interface[numintf].subnet_mask,
                                      &router[i].interface[numintf].speed);
    router[i].interface[numintf].index = numintf;
    if (router[i].interface[numintf].speed > 1000) {
      router[i].interface[numintf].oper_status = 1;
      router[i].interface[numintf].admin_status = 1;
    } 
    else {
      router[i].interface[numintf].oper_status = 2;
      router[i].interface[numintf].admin_status = 2;
    }
    while (eof != EOF) {
      numintf++;
      eof = fscanf(cow, "%s %s %d", router[i].interface[numintf].ip_address, 
                                      router[i].interface[numintf].subnet_mask,
                                      &router[i].interface[numintf].speed);
      router[i].interface[numintf].index = numintf;
      if (router[i].interface[numintf].speed > 1000) {
        router[i].interface[numintf].oper_status = 1;
        router[i].interface[numintf].admin_status = 1;
      } 
      else {
        router[i].interface[numintf].oper_status = 2;
        router[i].interface[numintf].admin_status = 2;
      }
    }
    fclose(cow);
    router[i].numinterfaces = numintf;
  }
}


int read_location_file()

{
  int  cow;
  int  x,y;
  char site[20];

  for (i=0; i<numrouters; i++) {
    router[i].map.x = 0;
    router[i].map.y = 0;
  }

  sprintf(filename, "%s/location.cf", cpath);
  if ((cow = open(filename, O_RDONLY)) == -1) {
    printf("xnetdb: can't find location file %s\n", filename);
  }
  else {
    while (fetch_more_data() != 0) {
      sscanf(buffer, "%s %d %d", site, &x, &y);
      for (i=0; i<numrouters; i++)
        if (strcmp(router[i].routername, site) == 0) {
          router[i].map.x = x;
          router[i].map.y = y;
        }
    }
    close(cow);
  }

  for (i=0; i<numrouters; i++) 
    if ((router[i].map.x == 0) && (router[i].map.y == 0)) {
      printf("I can't seem to find location coordinates for router %s\n",
                                                          router[i].routername);
      printf("Enter X coordinate: ");
      scanf("%d", &router[i].map.x);
      printf("Enter Y coordinate: ");
      scanf("%d", &router[i].map.y);
    }
}


int make_subnet(ip_address, subnet_mask, result)

char *ip_address;
char *subnet_mask;
char *result;

{
  char *cow;
  int s1, s2, s3, s4;
  int a1, a2, a3, a4;
  int r1, r2, r3, r4;

  sscanf(subnet_mask, "%d.%d.%d.%d", &s1, &s2, &s3, &s4);
  sscanf(ip_address, "%d.%d.%d.%d", &a1, &a2, &a3, &a4);
  r1 = s1 & a1;
  r2 = s2 & a2;
  r3 = s3 & a3;
  r4 = s4 & a4;
  sprintf(result, "%d.%d.%d.%d", r1, r2, r3, r4);
#ifdef DEBUG
  printf("address = %s, subnet mask = %s, subnet = %s\n", 
                                               ip_address, subnet_mask, result);
#endif DEBUG
  return 0;
}
