/*                                                                            */
/*       xnetdb                                                               */
/*                                                                            */
/*       Copyright (C) 1991 The Ohio State University, All Rights Reserved    */
/*       Copyright (C) 1990 Henry Clark, All Rights Reserved                  */
/*                                                                            */
/*       Licensing details are in the file "License"                          */
/*                                                                            */
/*       display_map.c                                                        */
/*                                                                            */
/*       this function contains code to display the xnetdb map                */
/*                                                                            */


#include "xnetdb.h"



int redisplay_map()

{
  int i,j;
  int m,n,o,p;
  int rtrto, rtrfrom;
  int rtrnum, rtrintf, speed;
  int x1, y1, x2, y2;
  int xdiff, ydiff;
  int up, down;
  int line_speed;
  int north, east, south, west;
  char  stat_string[20];


                                       /* display routers */

  for (i=0; i<numrouters; i++) {
    if (color)
      XSetForeground(mydisplay, mygc, white);
    else
      XSetForeground(mydisplay, mygc, black);
#ifdef DEBUG
      printf("about to draw router[%d] text...\n", i);
      printf("   coords = %d,%d\n", router[i].map.x, router[i].map.y);
#endif DEBUG
    XDrawString(mydisplay, mywindow, mygc,
                     router[i].map.x, router[i].map.y, router[i].mapname,
                     strlen(router[i].mapname));
    up = 0;
    for (j=0; j<router[i].numinterfaces; j++)
      if (router[i].interface[j].oper_status == 1)
        up++;
    if (up > 0) 
      router[i].status = UP;
    else
      router[i].status = DOWN;
    if (router[i].status == DOWN)
      if (color) {
        XSetForeground(mydisplay, mygc, red.pixel);
        XSetLineAttributes(mydisplay, mygc, 1, LineSolid, CapButt, JoinMiter);
      }
      else {
        XSetForeground(mydisplay, mygc, black);
        XSetLineAttributes(mydisplay, mygc, 1, 
                                            LineDoubleDash, CapButt, JoinMiter);
      }
    else
      if (color) {
        XSetForeground(mydisplay, mygc, green.pixel);
        XSetLineAttributes(mydisplay, mygc, 1, LineSolid, CapButt, JoinMiter);
      }
      else {
        XSetForeground(mydisplay, mygc, black);
        XSetLineAttributes(mydisplay, mygc, 1, LineSolid, CapButt, JoinMiter);
      }
      if (abs(router[i].map.computed.x2) > 1000)
        router[i].map.computed.x2-= 1000;
      if (abs(router[i].map.computed.y2) > 1000)
        router[i].map.computed.y2-= 1000;
#ifdef DEBUG
      printf("about to draw router[%d] box...\n", i);
      printf("   coords = %d,%d - %d,%d\n",
               router[i].map.computed.x1, router[i].map.computed.y1,
               router[i].map.computed.x2, router[i].map.computed.y2);
#endif DEBUG
      XDrawRectangle(mydisplay, mywindow, mygc,
               router[i].map.computed.x1, router[i].map.computed.y1,
               router[i].map.computed.x2, router[i].map.computed.y2);
  }

                              /* now draw all serial lines */

  for (i=0; i<numcircuits; i++) 
    if (circuit[i].valid == 1) {
      m = circuit[i].from_rtr;
      n = circuit[i].from_intf;
      o = circuit[i].to_rtr;
      p = circuit[i].to_intf;
      xdiff = router[m].map.x - router[o].map.x;
      ydiff = router[m].map.y - router[o].map.y;
      if (abs(ydiff) > 17) {
        if ( ydiff > -10 ) {
          circuit[i].map.x1 = router[m].map.computed.x1 +
                            (router[m].map.computed.x2 / 2);
          circuit[i].map.y1 = router[m].map.computed.y1 - 1;
          circuit[i].map.x2 = router[o].map.computed.x1 +
                            (router[o].map.computed.x2 / 2);
          circuit[i].map.y2 = router[o].map.computed.y1 +
                            router[o].map.computed.y2 + 1;
        }
        else {
          circuit[i].map.x1 = router[m].map.computed.x1 +
                              (router[m].map.computed.x2 / 2);
          circuit[i].map.y1 = router[m].map.computed.y1 +
                              router[m].map.computed.y2 + 1;
          circuit[i].map.x2 = router[o].map.computed.x1 +
                              (router[o].map.computed.x2 / 2);
          circuit[i].map.y2 = router[o].map.computed.y1 - 1;
        }
      }
      else {
        if ( xdiff > 10 ) {
          circuit[i].map.x1 = router[m].map.computed.x1 - 1; 
          circuit[i].map.y1 = router[m].map.computed.y1 +
                              (router[m].map.computed.y2 / 2);
          circuit[i].map.x2 = router[o].map.computed.x1 +
                              router[o].map.computed.x2 + 1;
          circuit[i].map.y2 = router[o].map.computed.y1 +
                              (router[o].map.computed.y2 / 2);
        }
        else {
          circuit[i].map.x1 = router[m].map.computed.x1 +
                              router[m].map.computed.x2 + 1;
          circuit[i].map.y1 = router[m].map.computed.y1 +
                              (router[m].map.computed.y2 / 2);
          circuit[i].map.x2 = router[o].map.computed.x1 - 1;
          circuit[i].map.y2 = router[o].map.computed.y1 +
                              (router[o].map.computed.y2 / 2);
        }
      }
      
   XSetLineAttributes(mydisplay, mygc, 1, LineSolid, CapButt, JoinMiter);
   if ((router[m].interface[n].oper_status == 1) &&
       (router[o].interface[p].oper_status == 1)) {

                                       /* cisco's tell untruths sometimes... */
                                       /* proteon is guilty also :-)         */

     if (( router[m].interface[n].speed < router[o].interface[p].speed ) &&
         ( router[m].interface[n].speed > 1000))
       line_speed = router[m].interface[n].speed;
     else
       if ( router[o].interface[p].speed > 1000 )
         line_speed = router[o].interface[p].speed;
       else {
         printf("xnetdb: can't figure out router interface speed!\n");
         printf("xnetdb: router = %s, interface %d\n",
                            router[m].routername, router[m].interface[n].index);
         printf("xnetdb: router = %s, interface %d\n",
                            router[o].routername, router[o].interface[p].index);
         exit(1);
       }

     if (line_speed > 40000000) {
       if (color) 
         XSetForeground(mydisplay, mygc, orange.pixel);
       else {
         XSetForeground(mydisplay, mygc, black);
         XSetLineAttributes(mydisplay, mygc, 8, LineSolid, CapButt, JoinMiter);
       }
     }
     else
       if (line_speed > 1000000) {
         if (color) 
           XSetForeground(mydisplay, mygc, blue.pixel);
         else {
           XSetForeground(mydisplay, mygc, black);
           XSetLineAttributes(mydisplay, mygc, 4, 
                                              LineSolid, CapButt, JoinMiter);
         }
       }
       else
         if (line_speed > 50000)
           if (color)
             XSetForeground(mydisplay, mygc, brown.pixel);
           else {
             XSetForeground(mydisplay, mygc, black);
             XSetLineAttributes(mydisplay, mygc, 2, 
                                                 LineSolid, CapButt, JoinMiter);
           }
         else
           if (color)
             XSetForeground(mydisplay, mygc, gray.pixel);
           else {
             XSetForeground(mydisplay, mygc, black);
             XSetLineAttributes(mydisplay, mygc, 1, 
                                                 LineSolid, CapButt, JoinMiter);
           }
       }
       else 
         if (color)
           XSetForeground(mydisplay, mygc, red.pixel);
         else {
           XSetLineAttributes(mydisplay, mygc, 1, 
                                             LineOnOffDash, CapButt, JoinMiter);
           XSetForeground(mydisplay, mygc, black);
         }
     XDrawLine(mydisplay, mywindow, mygc, circuit[i].map.x1, circuit[i].map.y1, 
                                         circuit[i].map.x2, circuit[i].map.y2); 
     if (circuit[i].show_stats > 0) {
       XClearArea(mydisplay, circuit[i].mywindow, 0, 0, 0, 0, False);
       XSetForeground(mydisplay, mygc, black);
       sprintf(stat_string, "%2.2f/%2.2f/%2.2f", circuit[i].usage.min, 
                                  circuit[i].usage.curr, circuit[i].usage.max);
       XDrawString(mydisplay, circuit[i].mywindow, mygc,
                                     11, 11, stat_string, strlen(stat_string));
     }
   }

                                /* finally, draw all ethernets */

  for (i=0; i<numethernets; i++) 
    if (ethernet[i].nummembers > 1) {
      if (color)
        if (ethernet[i].speed >= 60000000)
          XSetForeground(mydisplay, mygc, purple.pixel);
        else
          XSetForeground(mydisplay, mygc, yellow.pixel);
      else
        if (ethernet[i].speed >= 60000000) {
          XSetLineAttributes(mydisplay, mygc,1, LineDoubleDash, 
                                                           CapButt, JoinMiter);
          XSetForeground(mydisplay, mygc, black);
        }
        else {
          XSetLineAttributes(mydisplay, mygc, 1, LineSolid, CapButt, JoinMiter);
          XSetForeground(mydisplay, mygc, black);
        }
      if (ethernet[i].speed > 60000000) {
        XDrawArc(mydisplay, mywindow, mygc, ethernet[i].x_start, 
           ethernet[i].y_start, ethernet[i].x_end, ethernet[i].y_end, 0, 23040);
        west = ethernet[i].x_start + (ethernet[i].x_end * .33);
        east = ethernet[i].x_start + (ethernet[i].x_end * .66);
        north = ethernet[i].y_start + (ethernet[i].y_end * .33);
        south = ethernet[i].y_start + (ethernet[i].y_end * .66);
        for (j=0; j<ethernet[i].nummembers; j++) {
          m = ethernet[i].member[j].router;
          if (router[m].map.y < north)
            if (router[m].map.x < west) {
                                                          /* NW */
              x1 = router[m].map.computed.x1 +
                   (router[m].map.computed.x2);
              y1 = router[m].map.computed.y1 +
                   (router[m].map.computed.y2 / 2);
              x2 = ethernet[i].x_start + (ethernet[i].x_end * 0.165);
              y2 = ethernet[i].y_start + (ethernet[i].y_end * 0.165);
            }
            else if (router[m].map.x > east) {
                                                          /* NE */
                   x1 = router[m].map.computed.x1;
                   y1 = router[m].map.computed.y1 +
                        (router[m].map.computed.y2 / 2);
                   x2 = ethernet[i].x_start + (ethernet[i].x_end * 0.845);
                   y2 = ethernet[i].y_start + (ethernet[i].y_end * 0.155);
                 }
                 else {
                                                          /* N  */
                   x1 = router[m].map.computed.x1 +
                        (router[m].map.computed.x2 / 2);
                   y1 = router[m].map.computed.y1 + router[m].map.computed.y2;
                   x2 = ethernet[i].x_start + (ethernet[i].x_end / 2);
                   y2 = ethernet[i].y_start;
                 }
          else if (router[m].map.y < south)
                 if (router[m].map.x < west) {
                                                          /* SW */
                   x1 = router[m].map.computed.x1 +
                        (router[m].map.computed.x2 / 2);
                   y1 = router[m].map.computed.y1 +
                        (router[m].map.computed.y2);
                   x2 = ethernet[i].x_start + (ethernet[i].x_end * 0.165);
                   y2 = ethernet[i].y_start + (ethernet[i].y_end * 0.845);
                 }
                 else if (router[m].map.x > east) {
                                                          /* SE */
                        x1 = router[m].map.computed.x1 +
                             (router[m].map.computed.x2 / 2);
                        y1 = router[m].map.computed.y1 +
                             (router[m].map.computed.y2);
                        x2 = ethernet[i].x_start + (ethernet[i].x_end * 0.845);
                        y2 = ethernet[i].y_start + (ethernet[i].y_end * 0.845);
                      }
                      else {
                                                          /* S  */
                        x1 = router[m].map.computed.x1 +
                             (router[m].map.computed.x2 / 2);
                        y1 = router[m].map.computed.y1 -
                             router[m].map.computed.y2;
                        x2 = ethernet[i].x_start + (ethernet[i].x_end / 2);
                        y2 = ethernet[i].y_start + ethernet[i].y_end;
                      }
               else if (router[m].map.x < west) {
                                                          /* W  */
                      x1 = router[m].map.computed.x1 +
                           router[m].map.computed.x2;
                      y1 = router[m].map.computed.y1 +
                           (router[m].map.computed.y2 / 2);
                      x2 = ethernet[i].x_start;
                      y2 = ethernet[i].y_start + (ethernet[i].y_end / 2);
                    }
                    else if (router[m].map.x > east) {
                                                          /* E  */
                           x1 = router[m].map.computed.x1;
                           y1 = router[m].map.computed.y1 +
                                (router[m].map.computed.y2 / 2);
                           x2 = ethernet[i].x_start + ethernet[i].x_end;
                           y2 = ethernet[i].y_start + (ethernet[i].y_end / 2);
                         }
                         else {
                           printf("xnetdb: error in ring computations!!!\n");
                           exit(1);
                         }

          XDrawLine(mydisplay, mywindow, mygc, x1, y1, x2, y2);
        }
      }
      else {
        XDrawLine(mydisplay, mywindow, mygc, ethernet[i].x_start, 
                     ethernet[i].y_start, ethernet[i].x_end, ethernet[i].y_end);
      for (j=0; j<ethernet[i].nummembers; j++) {
        if (ethernet[i].x_start == ethernet[i].x_end) 

                               /* vertical, ether to left */

        if (router[ethernet[i].member[j].router].map.computed.x1 <
            ethernet[i].x_start) {
          x1 = ethernet[i].x_start;
          x2 = router[ethernet[i].member[j].router].map.computed.x1;
          y1 = router[ethernet[i].member[j].router].map.computed.y1 +
               (router[ethernet[i].member[j].router].map.computed.y2 / 2);
          y2 = router[ethernet[i].member[j].router].map.computed.y1 +
               (router[ethernet[i].member[j].router].map.computed.y2 / 2);
        }

                                /* vertical, ether to right */

        else {
          x1 = router[ethernet[i].member[j].router].map.computed.x1 +
               router[ethernet[i].member[j].router].map.computed.x2;
          x2 = ethernet[i].x_start;
          y1 = router[ethernet[i].member[j].router].map.computed.y1 +
               (router[ethernet[i].member[j].router].map.computed.y2 / 2);
          y2 = router[ethernet[i].member[j].router].map.computed.y1 +
               (router[ethernet[i].member[j].router].map.computed.y2 / 2);
        }
      else 

                               /* horizontal, ether above */

        if (router[ethernet[i].member[j].router].map.computed.y1 <
            ethernet[i].y_start) {
          x1 = router[ethernet[i].member[j].router].map.computed.x1 +
               (router[ethernet[i].member[j].router].map.computed.x2 / 2);
          x2 = router[ethernet[i].member[j].router].map.computed.x1 +
               (router[ethernet[i].member[j].router].map.computed.x2 / 2);
          y1 = ethernet[i].y_start;
          y2 = router[ethernet[i].member[j].router].map.computed.y1 +
               router[ethernet[i].member[j].router].map.computed.y2;
        }

                               /* horizontal, ether below */

        else {
          x1 = router[ethernet[i].member[j].router].map.computed.x1 +
               (router[ethernet[i].member[j].router].map.computed.x2 / 2);
          x2 = router[ethernet[i].member[j].router].map.computed.x1 +
               (router[ethernet[i].member[j].router].map.computed.x2 / 2);
          y1 = router[ethernet[i].member[j].router].map.computed.y1;
          y2 = ethernet[i].y_start;
        }
      XDrawLine(mydisplay, mywindow, mygc, x1, y1, x2, y2);
    }
   } 
  }
  show_event();
}


int display_map()

{
  int j;
  int rtrto, rtrfrom;
  int rtrnum, rtrintf, speed;
  int x1, y1, x2, y2;
  int xdiff, ydiff;
  char cow[60];



  XClearArea(mydisplay, mywindow, 0, 0, 0, 0, False);

                                     /* display key */


  if (color) {
    XSetBackground(mydisplay, mygc, black);
    XSetForeground(mydisplay, mygc, white);
  }
  else {
    XSetBackground(mydisplay, mygc, white);
    XSetForeground(mydisplay, mygc, black);
  }


  sprintf(cow, "Xnetdb %2.2f - Copyright (C) 1991 The Ohio State University", 
                                                                       VERSION);
  XDrawString(mydisplay, mywindow, mygc, 20, 20, cow, strlen(cow));
  if (color) {
    XSetForeground(mydisplay, mygc, purple.pixel);
    XDrawLine(mydisplay, mywindow, mygc, 20, 40, 40, 40); 
    XSetForeground(mydisplay, mygc, white);
    if (proteon_flag)
      XDrawString(mydisplay, mywindow, mygc, 60, 44, "PROnet-80", 9);
    else
      XDrawString(mydisplay, mywindow, mygc, 60, 44, "FDDI", 4);
    XSetForeground(mydisplay, mygc, orange.pixel);
    XDrawLine(mydisplay, mywindow, mygc, 20, 60, 40, 60); 
    XSetForeground(mydisplay, mygc, white);
    XDrawString(mydisplay, mywindow, mygc, 60, 64, "T3", 2);
    XSetForeground(mydisplay, mygc, yellow.pixel);
    XDrawLine(mydisplay, mywindow, mygc, 20, 80, 40, 80); 
    XSetForeground(mydisplay, mygc, white);
    XDrawString(mydisplay, mywindow, mygc, 60, 84, "Ethernet", 8);
    XSetForeground(mydisplay, mygc, blue.pixel);
    XDrawLine(mydisplay, mywindow, mygc, 20, 100, 40, 100); 
    XSetForeground(mydisplay, mygc, white);
    XDrawString(mydisplay, mywindow, mygc, 60, 104, "T1", 2);
    XSetForeground(mydisplay, mygc, brown.pixel);
    XDrawLine(mydisplay, mywindow, mygc, 20, 120, 40, 120); 
    XSetForeground(mydisplay, mygc, white);
    XDrawString(mydisplay, mywindow, mygc, 60, 124, "56Kb", 4);
    XSetForeground(mydisplay, mygc, gray.pixel);
    XDrawLine(mydisplay, mywindow, mygc, 20, 140, 40, 140); 
    XSetForeground(mydisplay, mygc, white);
    XDrawString(mydisplay, mywindow, mygc, 60, 144, "9.6Kb", 5);
  } 
  else {
    XSetForeground(mydisplay, mygc, black);
    XSetLineAttributes(mydisplay, mygc, 1, LineDoubleDash, CapButt, JoinMiter);
    XDrawLine(mydisplay, mywindow, mygc, 20, 40, 40, 40); 
    XDrawString(mydisplay, mywindow, mygc, 60, 44, "FDDI", 4);
    XSetLineAttributes(mydisplay, mygc, 8, LineSolid, CapButt, JoinMiter);
    XDrawLine(mydisplay, mywindow, mygc, 20, 60, 40, 60); 
    XDrawString(mydisplay, mywindow, mygc, 60, 64, "T3", 2);
    XSetLineAttributes(mydisplay, mygc, 1, LineSolid, CapButt, JoinMiter);
    XDrawLine(mydisplay, mywindow, mygc, 20, 80, 40, 80); 
    XDrawString(mydisplay, mywindow, mygc, 60, 84, "Ethernet", 8);
    XSetLineAttributes(mydisplay, mygc, 4, LineSolid, CapButt, JoinMiter);
    XDrawLine(mydisplay, mywindow, mygc, 20, 100, 40, 100); 
    XDrawString(mydisplay, mywindow, mygc, 60, 104, "T1", 2);
    XSetLineAttributes(mydisplay, mygc, 2, LineSolid, CapButt, JoinMiter);
    XDrawLine(mydisplay, mywindow, mygc, 20, 120, 40, 120); 
    XDrawString(mydisplay, mywindow, mygc, 60, 124, "56Kb", 4);
    XSetLineAttributes(mydisplay, mygc, 1, LineSolid, CapButt, JoinMiter);
    XDrawLine(mydisplay, mywindow, mygc, 20, 140, 40, 140); 
    XDrawString(mydisplay, mywindow, mygc, 60, 144, "9.6Kb", 5);
  }

  redisplay_map();
}


int show_event()

{
  XClearArea(mydisplay, mywindow, 20, 750, 0, 0, False);
  if (color)
    XSetForeground(mydisplay, mygc, white);
  else
    XSetForeground(mydisplay, mygc, black);
  XDrawString(mydisplay, mywindow, mygc, 25, 775,
                                            event_buffer, strlen(event_buffer));
  if (noisy)
    XBell(mydisplay, 100);
}


int make_event()

{
  struct tm *tp;
  struct timeval tv;
  char   *ap;
  char   buffer[100];
  char  cow_buffer[200];

  gettimeofday(&tv, 0);
  tp = localtime((time_t *) &tv.tv_sec);
  ap = asctime(tp);
  ap[strlen(ap)-1] = 0x00;
  sprintf(event_buffer, "%s: %s", ap, event);
  if (logging) {
    sprintf(cow_buffer, "%s\n", event_buffer);
    write(log_file, cow_buffer, strlen(cow_buffer));
  }
}
