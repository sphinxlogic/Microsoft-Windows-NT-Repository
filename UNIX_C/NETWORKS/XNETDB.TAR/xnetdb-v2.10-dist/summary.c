/*                                                                            */
/*       xnetdb                                                               */
/*                                                                            */
/*       Copyright (C) 1991 The Ohio State University, All Rights Reserved    */
/*       Copyright (C) 1990 Henry Clark, All Rights Reserved                  */
/*                                                                            */
/*       Licensing details are in the file "License"                          */
/*                                                                            */
/*       summary.c                                                            */
/*                                                                            */
/*       this function contains code to run summary stuff                     */
/*                                                                            */


#include "xnetdb.h"


struct MenuType summary_menu[] = {
  {"Circuits",    17, 33, 20,  40},
  {"CSU/DSU",     18, 53, 40,  60},
  {"Sites",       21, 73, 60,  80}
};

int num_summary_menu_choices = 3;


int display_summary_menu()

{
  int  localdone;
  int  x,y, length;
  int xr,yr;
  unsigned int buttons;
  Window rw, cw;
  int  cow, prev_cow;

  cow = -1;
  prev_cow = -1;
  localdone = 0;
  length = 20 + num_summary_menu_choices * 20;
  XQueryPointer(mydisplay, mywindow, &rw, &cw,
                                           &xr, &yr, &x, &y, &buttons);
  mymenuwindow = XCreateSimpleWindow(mydisplay, mywindow, x, y,
                                         100, length, 1, black, white);
  XMapRaised(mydisplay, mymenuwindow);
  if (color)
    XSetForeground(mydisplay, mygc, blue.pixel);
  else
    XSetForeground(mydisplay, mygc, black);
  XFillRectangle(mydisplay, mymenuwindow, mygc, 0, 0, 120, 20);
  XSetForeground(mydisplay, mygc, white);
  XDrawString(mydisplay, mymenuwindow, mygc, 14, 13,"Summary Menu",12);
  XSetForeground(mydisplay, mygc, black);
  for (i=0; i<num_summary_menu_choices; i++)
    XDrawString(mydisplay, mymenuwindow, mygc, 
                summary_menu[i].x, summary_menu[i].y, 
                summary_menu[i].string, strlen(summary_menu[i].string));
  while (localdone == 0) {
    XNextEvent(mydisplay, &myevent);
    switch (myevent.type) {
      case MotionNotify: 
         XQueryPointer(mydisplay, mymenuwindow, &rw, &cw,
                                           &xr, &yr, &x, &y, &buttons);
         for (i=0; i<num_summary_menu_choices; i++)
           if ((y > summary_menu[i].miny) && (y < summary_menu[i].maxy))
             cow = i;
         if (cow != prev_cow) 
           for (i=0; i<num_summary_menu_choices; i++)
             if ((y > summary_menu[i].miny) && (y < summary_menu[i].maxy)) {
               XSetForeground(mydisplay, mygc, black);
               XFillRectangle(mydisplay, mymenuwindow, mygc, 
                            0, summary_menu[i].miny, 100, summary_menu[i].maxy);
               XSetForeground(mydisplay, mygc, white);
               XDrawString(mydisplay, mymenuwindow, mygc, 
                        summary_menu[i].x, summary_menu[i].y, 
                        summary_menu[i].string, strlen(summary_menu[i].string));
             }
             else {
               XSetForeground(mydisplay, mygc, white);
               XFillRectangle(mydisplay, mymenuwindow, mygc, 
                            0, summary_menu[i].miny, 100, summary_menu[i].maxy);
               XSetForeground(mydisplay, mygc, black);
               XDrawString(mydisplay, mymenuwindow, mygc, 
                        summary_menu[i].x, summary_menu[i].y, 
                        summary_menu[i].string, strlen(summary_menu[i].string));
             }
         prev_cow = cow;
         break;
      case ButtonRelease: 
         XQueryPointer(mydisplay, mymenuwindow, &rw, &cw,
                                            &xr, &yr, &x, &y, &buttons);
         XDestroyWindow(mydisplay, mymenuwindow);
         if ((y >= 20) && (y <= 40)) display_summary_circuits();
         if ((y >= 40) && (y <= 60)) display_summary_csu_dsu();
         if (y >= 60) display_summary_sites();
         localdone = 1;
         break;
    } 
  }
}


int display_summary_circuits()

{
  Window myinfowindow;
  int    sitedone;
  char   cow[100];
  int    i, height, y;
  int    num_valid_circuits;

  sitedone = 0;
  num_valid_circuits = 0;
  for (i=0; i<numcircuits; i++) 
    if (strlen(circuit[i].pri_carrier.name) > 0)
      num_valid_circuits++;
  if (num_valid_circuits > 0) {
    height = num_valid_circuits * 20 + 10;
    myinfowindow = XCreateSimpleWindow(mydisplay, mywindow, 50, 50, 500, height,
                                                               1, black, white);
    XMapRaised(mydisplay, myinfowindow);
    XSetForeground(mydisplay, mygc, black);
    y = 20;
    for (i=0; i<numcircuits; i++) 
      if (strlen( circuit[i].pri_carrier.name) > 0) {
        sprintf(cow, "%12s to %12s    %20s    %20s", 
                     router[circuit[i].from_rtr].routername,
                     router[circuit[i].to_rtr].routername,
                     circuit[i].pri_carrier.name, 
                     circuit[i].pri_carrier.circuitnum);
        XDrawString(mydisplay, myinfowindow, mygc, 10, y, cow, strlen(cow));
        y = y + 20;
      }
    while (sitedone == 0) {
      XNextEvent(mydisplay, &myevent);
      switch (myevent.type) {
        case ButtonRelease: XDestroyWindow(mydisplay, myinfowindow);
                            sitedone = 1;
                            break;
      }
    }
  }
}


int display_summary_csu_dsu()

{
  Window myinfowindow;
  int    sitedone;
  char   cow[80];
  int    i, num_valid, offset;

  sitedone = 0;
  num_valid = 0;
  for (i=0; i<numcircuits; i++) {
    if (strlen(circuit[i].from_csu.serial_num) > 0) num_valid++;
    if (strlen(circuit[i].to_csu.serial_num) > 0) num_valid++;
  }
  if (num_valid <= 0) return 1;
  offset = 20 * num_valid + 10;
  myinfowindow = XCreateSimpleWindow(mydisplay, mywindow, 50, 50, 350, offset,
                                                               1, black, white);
  XMapRaised(mydisplay, myinfowindow);
  XSetForeground(mydisplay, mygc, black);
  offset = 20;
  for (i=0; i<numcircuits; i++) {
    if (strlen(circuit[i].from_csu.serial_num) > 0) {
      sprintf(cow, "%12s %10s %5s  %3s %12s",
                    router[circuit[i].from_rtr].routername,
                    circuit[i].from_csu.manufacturer,
                    circuit[i].from_csu.model,
                    circuit[i].from_csu.rev_level,
                    circuit[i].from_csu.serial_num);
      XDrawString(mydisplay, myinfowindow, mygc, 10, offset, 
                                                              cow, strlen(cow));
      offset += 20;
    }
    if (strlen(circuit[i].to_csu.serial_num) > 0) {
      sprintf(cow, "%12s %10s %5s %3s %12s",
                    router[circuit[i].to_rtr].routername,
                    circuit[i].to_csu.manufacturer,
                    circuit[i].to_csu.model,
                    circuit[i].to_csu.rev_level,
                    circuit[i].to_csu.serial_num);
      XDrawString(mydisplay, myinfowindow, mygc, 10, offset, 
                                                              cow, strlen(cow));
      offset += 20;
    }
  }
  while (sitedone == 0) {
    XNextEvent(mydisplay, &myevent);
    switch (myevent.type) {
      case ButtonRelease: XDestroyWindow(mydisplay, myinfowindow);
                          sitedone = 1;
                          break;
    }
  }
}


int display_summary_sites()

{
  Window myinfowindow;
  int    sitedone;
  char   cow[50];
  char   cats[50];
  int    i,y,height;
  int    moo;
  int    nummoo;

  sitedone = 0;
  nummoo = 0;
  for (i=0; i<numrouters; i++) {
    sprintf(cats, "%s", MYDOMAIN);
    if (strcmp(cats, router[i].domainname) != 0)
      nummoo++;
  }
  if (nummoo <= 0) return 1;
  height = nummoo * 20 + 10;
  myinfowindow = XCreateSimpleWindow(mydisplay, mywindow, 50, 50, 320, height,
                                                               1, black, white);
  XMapRaised(mydisplay, myinfowindow);
  XSetForeground(mydisplay, mygc, black);
  moo = 0;
  for (i=0; i<numrouters; i++) 
    if (strcmp(MYDOMAIN, router[i].domainname) != 0) {
      y = moo * 20 + 20;
      sprintf(cow, "%20s   %20s", router[i].routername, router[i].domainname);
      XDrawString(mydisplay, myinfowindow, mygc, 10, y, cow, strlen(cow));
      moo++;
    }
  while (sitedone == 0) {
    XNextEvent(mydisplay, &myevent);
    switch (myevent.type) {
      case ButtonRelease: XDestroyWindow(mydisplay, myinfowindow);
                          sitedone = 1;
                          break;
    }
  }
}
