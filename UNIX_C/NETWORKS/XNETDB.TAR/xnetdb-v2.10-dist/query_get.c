/*                                                                            */
/*       xnetdb                                                               */
/*                                                                            */
/*       Copyright (C) 1991 The Ohio State University, All Rights Reserved    */
/*       Copyright (C) 1990 Henry Clark, All Rights Reserved                  */
/*                                                                            */
/*       Licensing details are in the file "License"                          */
/*                                                                            */
/*       query_get.c                                                          */
/*                                                                            */
/*       this function contains code to do snmp queries                       */
/*                                                                            */


/*
 *	$Header: snmpget.c,v 1.2 89/02/17 18:59:31 jrd Locked $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */

#include	<notice.h>

#include <sys/ioctl.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <setjmp.h>
#include <signal.h>
#include <netdb.h>

#include	<host.h>

#include	<ctypes.h>
#include	<rdx.h>
#include	<debug.h>
#include	<smp.h>
#include	<aps.h>
#include	<ap0.h>
#include	<asn.h>
#include	<smx.h>
#include	<udp.h>

#define		cmdBufferSize		(2048)
#define		cmdBindListSize		(20)
#define		cmdTextSize		(128)

static		SmpSequenceType		requestId;
static		CBoolType		cmdDone;
SmpIdType		smp;
SmpSocketType		udp;
ApsIdType		communityId;
CCharPtrType		*ap;

extern char snmp_buffer[100];
extern jmp_buf env;
extern int num_malloc;
extern int malloc_table[2000];

	int			s;

static	void	cmdInit ()

{
	aslInit ();
	asnInit ();
	apsInit ();
	ap0Init ();
	smpInit ();
}

static  SmpStatusType   myUpCall (smp, req)

SmpIdType               smp;
SmpRequestPtrType       req;

{
	SmpIndexType		i;
	SmpBindPtrType		bind;
	CCharType		text [ cmdTextSize ];


        if ((req->smpRequestCmd != smpCommandRsp) ||
                (req->smpRequestId != requestId)) {
                return (errOk);
        }

	cmdDone = TRUE;
        smp = smp;
#ifdef SNMPDEBUG
	printf ("Request Id: %d\n", req->smpRequestId);
	printf ("Error: %s\n", smxErrorToText (req->smpRequestError));
	printf ("Index: %d\n", req->smpRequestIndex);
	printf ("Count: %d\n", req->smpRequestCount);
	printf ("\n");
#endif SNMPDEBUG

	bind = req->smpRequestBinds;
	for (i = req->smpRequestCount; i != 0; i--) {
		if (smxNameToText (text, (CIntfType) cmdTextSize,
			(CBytePtrType) bind->smpBindName,
			(CIntfType) bind->smpBindNameLen) >=
			(CIntfType) 0) {
#ifdef SNMPDEBUG
			printf ("Name: %s\n", text);
#endif SNMPDEBUG
		}
#ifdef SNMPDEBUG
		printf ("Kind: %s\n", smxKindToText (bind->smpBindKind));
#endif SNMPDEBUG
		if (smxValueToText (text, (CIntfType) cmdTextSize,
			bind) >= (CIntfType) 0) {
			sprintf(snmp_buffer, "%s %s",  
                                       smxKindToText (bind->smpBindKind), text);
#ifdef SNMPDEBUG
			printf ("Value: %s\n", text);
#endif SNMPDEBUG
		}
		else {
#ifdef SNMPDEBUG
			printf ("Value: GARBLED\n");
#endif SNMPDEBUG
		}
#ifdef SNMPDEBUG
		printf ("\n");
#endif SNMPDEBUG
		bind++;
	}
        return (errOk);
}


int make_snmp_query(ip_address, variable, the_community, count)

char *ip_address;
char *variable;
char *the_community;
int  count;

{
  int  i;
  int  timeout=5;

  alarm(timeout);
  if (setjmp(env)) {
    close(s);
    for (i=0; i<num_malloc; i++)
      free(malloc_table[i]);
    num_malloc = 0;
    if (count <= 1) {
      printf("xnetdbquery: receive timed out from %s\n", ip_address);
      return -1;
    }
    else {
      count--;
      timeout += 3;
      alarm(timeout);
    }
  }
  make_the_query(ip_address, variable, the_community);
  alarm(0);
  for (i=0; i<num_malloc; i++)
    free(malloc_table[i]);
  num_malloc = 0;
  return 0;
}


int make_the_query (ip_address, variable, the_community)

char *ip_address;
char *variable;
char *the_community;

{
	int			salen;
	int			result;
	struct	sockaddr	salocal;
	struct	sockaddr	saremote;
	struct	sockaddr_in	*sin;
        struct  servent         *svp;
	unsigned		timeout;

	u_long			fhost;
	u_short			fport;
	CUnslType		number;

	CByteType		buf [ cmdBufferSize ];
	CBytePtrType		bp;
	SmpBindType		bindList [ cmdBindListSize ];
	SmpIndexType		bindCount;
	SmpRequestType		req;
	SmpBindPtrType		bindp;
	CCharPtrType		cp;
	CBoolType		noerror;
	CIntfType		len;
	CIntfType		space;

        int                     cow;

	CCharPtrType		communityString;
	CCharPtrType		fhostString;
	CCharPtrType		fportString;
	CCharPtrType		requestIdString;
	CCharPtrType		timeoutString;

	char			community_buffer[20];


	fhostString = ip_address;
#ifdef SNMPDEBUG
        printf("Host = %s\n", ip_address);
#endif SNMPDEBUG
	fhost = (u_long) hostAddress (fhostString);

        fport = htons((u_short) 161);

	timeout = (unsigned) 0;

	requestId = (SmpSequenceType) 1357;

	communityString = (CCharPtrType) the_community;

	cmdInit ();

	bp = buf;
	space = cmdBufferSize;
	bindp = bindList;
	bindCount = (SmpIndexType) 0;
        cow = 1;
        ap = (CCharPtrType *) variable;

	for (noerror = TRUE; (noerror) && (cow > 0); cow-- ) {
		if ((len = smxTextToObjectId (bp, space, ap)) <
			(CIntfType) 0) {
			noerror = FALSE;
		}
		else {
			ap++;
			bindp->smpBindName = (SmpNameType) bp;
			bindp->smpBindNameLen = (SmpLengthType) len;
			bp += len;
			space -= len;
			bindp->smpBindKind = smpKindOctetString;
			bindp->smpBindValue = (SmpValueType) 0;
			bindp->smpBindValueLen = (SmpLengthType) 0;
			bindp++;
			bindCount++;
		}
	}

	s = socket (AF_INET, SOCK_DGRAM, 0);
	if (s < 0) {
		(void) perror ("socket");
		return (1);
	}

	sin = (struct sockaddr_in *) & salocal;
        bzero ((char *) sin, sizeof (*sin));
	sin->sin_family = AF_INET;
	sin->sin_addr.s_addr = (u_long) 0;
	sin->sin_port = (u_short) 0;

	result = bind (s, & salocal, sizeof (*sin));
	if (result < 0) {
		(void) perror ("bind");
		return (1);
	}

        udp = udpNew (s, fhost, fport);
        smp = smpNew (udp, udpSend, myUpCall);
	if (smp == (SmpIdType) 0) {
		fprintf (stderr, "Error creating protocol object\n");
		udp = udpFree (udp);
		smp = smpFree (smp);
		return (2);
	}

	communityId = apsNew ((ApsNameType) communityString,
		(ApsNameType) "trivial", (ApsGoodiesType) 0);

	req.smpRequestCmd = smpCommandGet;
	req.smpRequestCommunity = communityId;
	req.smpRequestId = requestId;
	req.smpRequestError = smpErrorNone;
	req.smpRequestIndex = (SmpIndexType) 0;
	req.smpRequestCount = bindCount;
	req.smpRequestBinds = bindList;

	if (smpRequest (smp, & req) != errOk) {
		fprintf (stderr, "Error sending protocol request\n");
		smp = smpFree (smp);
		udp = udpFree (udp);
		communityId = apsFree (communityId);
		return (2);
	}
	smp = smpFree (smp);

	sin = (struct sockaddr_in *) & saremote;

	cmdDone = FALSE;

	do {
        	smp = smpNew (udp, udpSend, myUpCall);
		if (smp == (SmpIdType) 0) {
			fprintf (stderr, "Error creating protocol object\n");
			udp = udpFree (udp);
			communityId = apsFree (communityId);
			smp = smpFree (smp);
			return (2);
		}

		salen = sizeof (saremote);
		result = recvfrom (s, (char *) buf, (int) cmdBufferSize,
			(int) 0, & saremote, & salen);
#ifdef SNMPDEBUG
		DEBUGBYTES (buf, result);
		DEBUG0 ("\n");
#endif SNMPDEBUG

		for (bp = buf; ((result > 0) &&
			(smpInput (smp, *bp++) == errOk));
			result--);

		DEBUG1 ("result: %d\n", result);
		smp = smpFree (smp);

	} while ((result >= 0) && (! cmdDone));

	udp = udpFree (udp);
	communityId = apsFree (communityId);
	return (close (s));
}
