/*                                                                            */
/*       xnetdb                                                               */
/*                                                                            */
/*       Copyright (C) 1991 The Ohio State University, All Rights Reserved    */
/*       Copyright (C) 1990 Henry Clark, All Rights Reserved                  */
/*                                                                            */
/*       Licensing details are in the file "License"                          */
/*                                                                            */
/*       router.c                                                             */
/*                                                                            */
/*       this function contains code to do router stuff                       */
/*                                                                            */


#include "xnetdb.h"


struct MenuType router_menu[] = {
  { "Information",  15,  33,  20,  40 },
  { "Interfaces",   15,  53,  40,  60 },
  { "Contacts",     19,  73,  60,  80 },
  { "Shell",        22,  93,  80, 100 },
  { "Routes",       21, 113, 100, 120 },
  { "Move",         22, 133, 120, 140 },
  { "Traceroute",   16, 153, 140, 160 }
};

int num_router_menu_choices = 7;


int display_router_menu(choice)

int choice;

{
  int i, length;
  int localdone;
  int x, y, xr,yr;
  unsigned int buttons;
  Window rw, cw;
  char command[100];
  int  cow, prev_cow;

  cow = -1;
  prev_cow = -1;
  localdone = 0;
  length = num_router_menu_choices * 20 + 20;
  mymenuwindow = XCreateSimpleWindow(mydisplay, mywindow, 
                                         myevent.xbutton.x, myevent.xbutton.y,
                                         100, length, 1, black, white);
  XMapRaised(mydisplay, mymenuwindow);
  if (color)
    XSetForeground(mydisplay, mygc, blue.pixel);
  else
    XSetForeground(mydisplay, mygc, black);
  XFillRectangle(mydisplay, mymenuwindow, mygc, 0, 0, 100, 20);
  XSetForeground(mydisplay, mygc, white);
  switch (router[choice].type) {
    case ISAROUTER: case ISAROUTERPINGER:
      XDrawString(mydisplay, mymenuwindow, mygc, 15, 13,"Router Menu", 11);
      break;
    case ISAHOST: case ISAHOSTPINGER:
      XDrawString(mydisplay, mymenuwindow, mygc, 15, 13,"Host Menu", 9);
      break;
  }
  XSetForeground(mydisplay, mygc, black);
  for (i=0; i<num_router_menu_choices; i++)
    XDrawString(mydisplay, mymenuwindow, mygc, 
                router_menu[i].x, router_menu[i].y, 
                router_menu[i].string, strlen(router_menu[i].string));
  while (localdone == 0) {
    XNextEvent(mydisplay, &myevent);
    switch (myevent.type) {
      case MotionNotify: 
         XQueryPointer(mydisplay, mymenuwindow, &rw, &cw,
                                           &xr, &yr, &x, &y, &buttons);
         for (i=0; i<num_router_menu_choices; i++)
           if ((y > router_menu[i].miny) && (y < router_menu[i].maxy))
             cow = i;
         if (cow != prev_cow) 
           for (i=0; i<num_router_menu_choices; i++)
             if ((y > router_menu[i].miny) && (y < router_menu[i].maxy)) {
               XSetForeground(mydisplay, mygc, black);
               XFillRectangle(mydisplay, mymenuwindow, mygc, 
                              0, router_menu[i].miny, 100, router_menu[i].maxy);
               XSetForeground(mydisplay, mygc, white);
               XDrawString(mydisplay, mymenuwindow, mygc, 
                          router_menu[i].x, router_menu[i].y, 
                          router_menu[i].string, strlen(router_menu[i].string));
             }
             else {
               XSetForeground(mydisplay, mygc, white);
               XFillRectangle(mydisplay, mymenuwindow, mygc, 
                              0, router_menu[i].miny, 100, router_menu[i].maxy);
               XSetForeground(mydisplay, mygc, black);
               XDrawString(mydisplay, mymenuwindow, mygc, 
                         router_menu[i].x, router_menu[i].y, 
                         router_menu[i].string, strlen(router_menu[i].string));
             }
         prev_cow = cow;
         break;
      case ButtonRelease: 
         XQueryPointer(mydisplay, mymenuwindow, &rw, &cw,
                                            &xr, &yr, &x, &y, &buttons);
         XDestroyWindow(mydisplay, mymenuwindow);
         if ((y >= 20) && (y < 40)) display_router_information(choice);
         if ((y >= 40) && (y < 60)) 
           if (router[choice].numinterfaces > 0)
             display_router_interfaces(choice);
         if ((y >= 60) && (y < 80)) 
           if ( router[choice].numcontacts > 0 )
             display_router_contacts(choice);
         if ((y >= 80) && (y < 100)) {
           if (strlen(display) > 0)
             sprintf(command, 
                     "xterm  -T \"%s Login\" -display %s -e telnet %s &",
                     router[choice].routername, display, 
                     router[choice].netaddress);
           else
             sprintf(command, 
                     "xterm  -T \"%s Login\" -e telnet %s &",
                     router[choice].routername, router[choice].netaddress);
           system(command);
         }
         if ((y >= 100) && (y <= 120) &&
                            (strcmp(router[choice].community, "--PING--") != 0))
           display_router_routes(choice);
         if ((y >= 120) && (y <= 140)) move_router(choice);
         if ((y >= 140) && (strcmp(router[choice].community, "--PING--") != 0))
           traceroute(choice);
         localdone = 1;
         break;
     }
  }
}


int display_router_information(i)

int i;

{
  Window myinfowindow;
  int    sitedone, j, offset, width;
  char   cow[50];

  sitedone = 0;
  offset = router[i].numboards * 100 + 20;
  if (offset < 200) 
    offset = 200;
  if (router[i].numboards == 0)
    width = 150;
  else
    width = 240;
  myinfowindow = XCreateSimpleWindow(mydisplay, mywindow, 100, 100, 
                                                offset, width, 1, black, white);
  XMapRaised(mydisplay, myinfowindow);
  XSetForeground(mydisplay, mygc, black);
  sprintf(cow, "%s   %s", router[i].routername, router[i].domainname);
  XDrawString(mydisplay, myinfowindow, mygc, 10, 10, cow, strlen(cow));
  sprintf(cow, "%s %s", router[i].manufacturer, router[i].model);
  XDrawString(mydisplay, myinfowindow, mygc, 10, 30, cow, strlen(cow));
  XDrawString(mydisplay, myinfowindow, mygc, 10, 50, 
                            router[i].netaddress, strlen(router[i].netaddress));
  if (strlen(router[i].remoteaccess.phone) > 4) {
    XDrawString(mydisplay, myinfowindow, mygc, 10, 70, "Remote Access", 13);
    XDrawString(mydisplay, myinfowindow, mygc, 30, 90, 
                                          router[i].remoteaccess.phone, 
                                          strlen(router[i].remoteaccess.phone));
    sprintf(cow, "%d baud", router[i].remoteaccess.baud);
    XDrawString(mydisplay, myinfowindow, mygc, 30, 110, cow, strlen(cow));
  }
  else 
    XDrawString(mydisplay, myinfowindow, mygc, 10, 70, "No Remote Access", 16);
  if (strlen(router[i].serialnumber) > 0) {
    sprintf(cow, "Router Serial#: %s", router[i].serialnumber);
    XDrawString(mydisplay, myinfowindow, mygc, 10, 130, cow, strlen(cow));
  }
  if (router[i].numboards > 0) {
    XDrawString(mydisplay, myinfowindow, mygc, 10, 150, "Board Info", 10);
    for (j=0; j<router[i].numboards; j++) {
      offset = 10 + j * 100;
      XDrawString(mydisplay, myinfowindow, mygc, offset, 170,
                      router[i].board[j].name, strlen(router[i].board[j].name));
      XDrawString(mydisplay, myinfowindow, mygc, offset, 190, 
                                         router[i].board[j].rev_level,
                                         strlen(router[i].board[j].rev_level));
      XDrawString(mydisplay, myinfowindow, mygc, offset, 210,
                                         router[i].board[j].serial_num,
                                         strlen(router[i].board[j].serial_num));
    }
  }
  while (sitedone == 0) {
    XNextEvent(mydisplay, &myevent);
    switch (myevent.type) {
      case ButtonRelease: XDestroyWindow(mydisplay, myinfowindow);
                          sitedone = 1;
                          break;
    }
  }
}


int display_router_interfaces(i)

int i;

{
  Window myinfowindow;
  int   sitedone;
  int   width, height, x, y, y_offset;
  int   j;
  char  cow[5];
  int   num_rows;

  sitedone = 0;
  if (router[i].numinterfaces > 5) 
    if (router[i].numinterfaces > 10) {
      num_rows = 3;
      width = 660;
    }
    else {
      num_rows = 2;
      width = 660;
    }
  else {
    num_rows = 1;
    width = 10 + (router[i].numinterfaces * 130);
  }
  height = 120 * num_rows;
  myinfowindow = XCreateSimpleWindow(mydisplay, mywindow, 100, 100, width, 
                                                       height, 1, black, white);
  XMapRaised(mydisplay, myinfowindow);
  XSetForeground(mydisplay, mygc, black);
  XDrawString(mydisplay, myinfowindow, mygc, 10, 13, "Interfaces", 10);
  for (j=0; j<router[i].numinterfaces; j++) {
    if (j > 4) 
      if (j > 9) {
        y_offset = 240;
        x = 10 + (130 * (j-10));
      } 
      else  {
        y_offset = 120;
        x = 10 + (130 * (j-5));
      }
    else {
      y_offset = 0;
      x = 10 + (130 * j);
    }
    sprintf(cow, "%d", router[i].interface[j].index);
    y = 45 + y_offset;
    XDrawString(mydisplay, myinfowindow, mygc, x, y, cow, strlen(cow));
    y = 60 + y_offset;
    if (strcmp(router[i].interface[j].ip_address, "500.500.500.500") != 0) {
      XDrawString(mydisplay, myinfowindow, mygc, x, y,
                       router[i].interface[j].ip_address, 
                       strlen(router[i].interface[j].ip_address));
    }
    y = 75 + y_offset;
    if (router[i].interface[j].speed == 100000000)
      XDrawString(mydisplay, myinfowindow, mygc, x, y, "FDDI", 4);
    else
      if (router[i].interface[j].speed == 80000000)
        XDrawString(mydisplay, myinfowindow, mygc, x, y, "Pronet-80", 9);
      else
        if (router[i].interface[j].speed >= 40000000)
          XDrawString(mydisplay, myinfowindow, mygc, x, y, "T3", 2);
        else
          if (router[i].interface[j].speed == 10000000)
            XDrawString(mydisplay, myinfowindow, mygc, x, y, "Ethernet", 8);
          else
            if (router[i].interface[j].speed == 4000000)
              XDrawString(mydisplay, myinfowindow, mygc, x, y, 
                                                        "Token Ring (4Mb)", 16);
            else
              if (router[i].interface[j].speed > 1000000)
                XDrawString(mydisplay, myinfowindow, mygc, x, y, "T1", 2);
              else
                if (router[i].interface[j].speed > 50000)
                  XDrawString(mydisplay, myinfowindow, mygc, x, y, "56Kb", 4);
                else
                  if (router[i].interface[j].speed > 9000)
                    XDrawString(mydisplay, myinfowindow, mygc, x, y, "9.6Kb",5);
    y = 90 + y_offset;
    switch (router[i].interface[j].oper_status) {
      case 1: XDrawString(mydisplay, myinfowindow, mygc, x, y, "Up", 2);
              break;
      case 2: if (router[i].interface[j].admin_status == 2)
                XDrawString(mydisplay, myinfowindow, mygc, x, y, "Disabled", 8);
              else
                XDrawString(mydisplay, myinfowindow, mygc, x, y, "Down", 4);
              break;
      case 3: XDrawString(mydisplay, myinfowindow, mygc, x, y, "Testing", 7);
              break;
    }
    y = 105 + y_offset;
    XDrawString(mydisplay, myinfowindow, mygc, x, y, 
                                 router[i].interface[j].board, 
                                 strlen(router[i].interface[j].board));
  }
  while (sitedone == 0) {
    XNextEvent(mydisplay, &myevent);
    switch (myevent.type) {
      case ButtonRelease: XDestroyWindow(mydisplay, myinfowindow);
                          sitedone = 1;
                          break;
    }
  }
}


int display_router_contacts(i)

int i;

{
  Window myinfowindow;
  int    sitedone;
  int    width, depth;
  int    offset, down, total_down;
  int    j;
  char   cows[80];

  sitedone = 0;
  if (width <=0) width = 10;
  if (router[i].numcontacts <= 4) {
    depth = 150;
    width = 190 * router[i].numcontacts + 10;
  }
  else {
    depth = 300;
    width = 190 * 4 + 10;
  }
  myinfowindow = XCreateSimpleWindow(mydisplay, mywindow, 100, 100, 
                                                 width, depth, 1, black, white);
  XMapRaised(mydisplay, myinfowindow);
  XSetForeground(mydisplay, mygc, black);
  for (j=0; j<router[i].numcontacts; j++) {
    if (j >= 4) {
      down = 150;
      offset = 190 * (j - 4) + 10;
    }
    else {
      down = 0;
      offset = 190 * j + 10;
    }
    total_down = down + 30;
    XDrawString(mydisplay, myinfowindow, mygc, offset, total_down, 
          router[i].contacts[j].name, strlen(router[i].contacts[j].name));
    total_down = down + 45;
    XDrawString(mydisplay, myinfowindow, mygc, offset, total_down, 
          router[i].contacts[j].addr1, strlen(router[i].contacts[j].addr1));
    total_down = down + 60;
    XDrawString(mydisplay, myinfowindow, mygc, offset, total_down, 
          router[i].contacts[j].addr2, strlen(router[i].contacts[j].addr2));
    sprintf(cows, "%s %s %5s", router[i].contacts[j].city,
                      router[i].contacts[j].state, router[i].contacts[j].zip);
    total_down = down + 75;
    XDrawString(mydisplay, myinfowindow, mygc, offset, total_down, 
                                                           cows, strlen(cows));
    total_down = down + 90;
    XDrawString(mydisplay, myinfowindow, mygc, offset, total_down,
          router[i].contacts[j].phone, strlen(router[i].contacts[j].phone));
    total_down = down + 105;
    XDrawString(mydisplay, myinfowindow, mygc, offset, total_down,
          router[i].contacts[j].email, strlen(router[i].contacts[j].email));
    total_down = down + 120;
    XDrawString(mydisplay, myinfowindow, mygc, offset, total_down,
          router[i].contacts[j].comment, strlen(router[i].contacts[j].comment));
  }
  while (sitedone == 0) {
    XNextEvent(mydisplay, &myevent);
    switch (myevent.type) {
      case ButtonRelease: XDestroyWindow(mydisplay, myinfowindow);
                          sitedone = 1;
                          break;
    }
  }
}


int display_router_routes(i)

int i;

{
  int  j;
  char variable[80];
  int  metric;
  char next_hop[30];
  char result[30];
  char route_dest[30];
  int  route_proto;
  char proto_str[30];
  char buffer[150];
  int  dog;
  char cow_buf[300];
  int  num;
  char    pgpath[80];


                                    /* get list of all Route Dest's */

  num = make_snmp_mquery(router[i].netaddress, "1.3.6.1.2.1.4.21.1.1", 
							router[i].community);

                                    /* now get info for each destination */

  dog = open("/tmp/dog", O_RDWR | O_CREAT, 0644 );

  sprintf(buffer, "%16s\t%16s\t%8s\t%8s\n", 
                                  "Destination", "Next Hop", "Metric", "Proto");
  write(dog, buffer, strlen(buffer));
  for (j=0; j<num; j++) {
    sscanf(snmp_mbuffer[j].buffer, "%s %s", result, route_dest);
    if (strcmp(result, "IPAddr") == 0) {
 
                                    /* get ipRouteMetric1 */

      sprintf(variable, "1.3.6.1.2.1.4.21.1.3.%s", route_dest);
      make_snmp_query(router[i].netaddress, variable, router[i].community, 2);
      sscanf(snmp_buffer, "%s %d", result, &metric);
      if (strcmp(result, "Integer") != 0) {
        printf("xnetdb: got a %s for ipRouteMetric1!\n", result);
        exit(1);
      }
 
                                    /* get ipRouteNextHop */

      sprintf(variable, "1.3.6.1.2.1.4.21.1.7.%s", route_dest);
      make_snmp_query(router[i].netaddress, variable, router[i].community, 2);
      sscanf(snmp_buffer, "%s %s", result, next_hop);
      if (strcmp(result, "IPAddr") != 0) {
        printf("xnetdb: got a %s for ipRouteNextHop!\n", result);
        exit(1);
      }
 
                                    /* get ipRouteProto */

      sprintf(variable, "1.3.6.1.2.1.4.21.1.9.%s", route_dest);
      make_snmp_query(router[i].netaddress, variable, router[i].community, 2);
      sscanf(snmp_buffer, "%s %d", result, &route_proto);
      if (strcmp(result, "Integer") != 0) {
        printf("xnetdb: got a %s for ipRouteProto!\n", result);
        exit(1);
      }
      switch (route_proto) {
         case 2: sprintf(proto_str, "Local");
                 break;
         case 5: sprintf(proto_str, "EGP");
                 break;
         case 8: sprintf(proto_str, "RIP");
                 break;
        default: sprintf(proto_str, "Other");
                 break;
      }

      sprintf(buffer, "%16s\t%16s\t%8d\t%8s\n", 
                              route_dest, next_hop, metric, proto_str);
      write(dog, buffer, strlen(buffer));
    }
  }
  close(dog);
  sprintf(pgpath, "%s", PGPATH);
  if (strlen(display) > 0) {
    sprintf(cow_buf, 
            "xterm -sl 1000 -sb  -T \"%s Routes\" -display %s -e %s /tmp/dog &",
            router[i].routername, display, pgpath);
    system(cow_buf);
  }
  else {
    sprintf(cow_buf,
            "xterm -sl 1000 -sb  -T \"%s Routes\" -e %s /tmp/dog &",
            router[i].routername, pgpath);
    system(cow_buf);
  }
}


int move_router(i)

int i;

{ 
  int localdone;
  int x, y, xr,yr;
  unsigned int buttons;
  Window rw, cw;

  sprintf(event, "Now click where you want it moved to...");
  make_event();
  redisplay_map();
  localdone = 0;
  while (localdone == 0) {
    XNextEvent(mydisplay, &myevent);
    switch (myevent.type) {
      case ButtonRelease: 
         XQueryPointer(mydisplay, mywindow, &rw, &cw,
                                           &xr, &yr, &x, &y, &buttons);
         router[i].map.x = x;
         router[i].map.y = y;
         localdone = 1;
         break;
    }
  }
  init_router_box(i);
  init_circuits();
  sprintf(event, "Router move completed...");
  make_event();
  display_map();
}
