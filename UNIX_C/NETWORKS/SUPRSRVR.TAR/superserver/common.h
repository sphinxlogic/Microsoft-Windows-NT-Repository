/*
 * Common.h
 *
 * Definitions common to both the sub- and superserver.
 */

/*
 * Common include files
 */
#include <stdio.h>
#include <signal.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/param.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <sys/socket.h>

/*
 * This is the port number that the superserver listens on.
 */
#define SUPERPORT	3502

/*
 * Common external variables.
 */
extern int errno;

