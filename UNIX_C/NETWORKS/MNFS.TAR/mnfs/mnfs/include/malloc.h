char *malloc();
char *realloc();
char *copyofstr();
char *copyofblk();
int free();
#define NEW(type) ((type *) malloc(sizeof(type)))
#define OLD(x) free((char *) x)
