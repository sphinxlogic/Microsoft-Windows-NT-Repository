#include "/usr/include/syscall.h"

#define SYS_nfssvc_create 256
#define SYS_nfssvc_link 257
#define SYS_nfssvc_lookup 258
#define SYS_nfssvc_mkdir 259
#define SYS_nfssvc_read 260
#define SYS_nfssvc_readlink 261
#define SYS_nfssvc_remove 262
#define SYS_nfssvc_rename 263
#define SYS_nfssvc_rmdir 264
#define SYS_nfssvc_setattr 265
#define SYS_nfssvc_stat 266
#define SYS_nfssvc_statfs 267
#define SYS_nfssvc_symlink 268
#define SYS_nfssvc_write 269
