#include <xdr.h>

bool_t _xdr_generic_getlong(x,lp)
XDR *x;
long int *lp;
{
 long int li;

 if (!(*x->x_ops->x_getbytes)(x,(char *)&li,sizeof(long int)))
  { return(FALSE);
  }
 *lp = _xdr_reverse_long(li);
 return(TRUE);
}

bool_t _xdr_generic_putlong(x,lp)
XDR *x;
long int *lp;
{
 long int li;

 li = _xdr_reverse_long(*lp);
 return((*x->x_ops->x_putbytes)(x,(char *)&li,sizeof(long int)));
}

long int _xdr_reverse_long(i)
long int i;
{
 long int j;
 register char *cp;
 register char *dp;
 register int c;

 cp = (char *) &i;
 dp = 4 + (char *) &j;
 for (c=0;c<4;c++)
  { *--dp = *cp++;
  }
 return(j);
}
