#include <stdio.h>

char get()
{
 char c;

 c = getchar();
 if (feof(stdin) || ferror(stdin))
  { exit(0);
  }
}

main()
{
 char c;

 while (1)
  { while (get() != '\t') ;
    while (get() != '\t') ;
    get();
    get();
    c = get();
    if (c != '#')
     { putchar(c);
       while (1)
	{ c = get();
	  if (c == '(')
	   { break;
	   }
	  putchar(c);
	}
       printf("();\n");
     }
    while (get() != '\n') ;
  }
}
