/* BEWARE OPTIMIZER BUG:  Don't use -O! */

struct vax_f_float {
  unsigned int frac_1 : 7;
  unsigned int exp : 8;
  unsigned int sign : 1;
  unsigned int frac_2 : 16; };

struct ieee_f_float {
  unsigned int frac_2 : 16;
  unsigned int frac_1 : 7;
  unsigned int exp : 8;
  unsigned int sign : 1; };

struct vax_d_float {
  unsigned int frac_1 : 7;
  unsigned int exp : 8;
  unsigned int sign : 1;
  unsigned int frac_2 : 16;
  unsigned int frac_3 : 16;
  unsigned int frac_4 : 16; };

struct ieee_d_float {
  unsigned int frac_4 : 16;
  unsigned int frac_3 : 16;
  unsigned int frac_2 : 16;
  unsigned int frac_1 : 4;
  unsigned int exp : 11;
  unsigned int sign : 1; } ;
