#include <xdr.h>

u_int xdr_getpos(x)
XDR *x;
{
 return((*x->x_ops->x_getpostn)(x));
}

bool_t xdr_setpos(x,pos)
XDR *x;
u_int pos;
{
 return((*x->x_ops->x_setpostn)(x,pos));
}

VOID xdr_destroy(x)
XDR *x;
{
 (*x->x_ops->x_destroy)(x);
 x->x_ops = (XDR_OPS *) 0;
}

long *xdr_inline(x,size)
XDR *x;
u_int size;
{
 return((long *)(*x->x_ops->x_inline)(x,size));
}
