#include <sys/time.h>

#include <xdr.h>
#include <rpc.h>

unsigned int get_rpcxid()
{
 static int xid = 0;

 if (xid == 0)
  { struct timeval tv;
    gettimeofday(&tv,(struct timezone *)0);
    xid = getpid() ^ tv.tv_sec ^ tv.tv_usec;
  }
 return(xid++);
}
