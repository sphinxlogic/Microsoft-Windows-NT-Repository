    /*********************************************************************\
    *  Copyright (c) 1991 by Wen-King Su (wen-king@vlsi.cs.caltech.edu)   *
    *                                                                     *
    *  You may copy or modify this file in any manner you wish, provided  *
    *  that this notice is always included, and that you hold the author  *
    *  harmless for any loss or damage resulting from the installation or *
    *  use of this software.                                              *
    \*********************************************************************/

#include "client_def.h"

extern char **glob();
extern char *env_dir;
extern char *util_abs_path();

main(argc,argv)
    int argc;
    char **argv;
{
    char *np;
    char **av, *av2[2];

    env_client();
    if(argc == 1)
    {
	print_pro("/");
	puts("/");
    }
    else
    {
        if(!(av = glob(argv[1]))) { av = av2; av2[0] = *argv; av2[1] = 0; }
	np = util_abs_path(*av);
	if(print_pro(np)) puts(np); else puts(env_dir);
    }
    client_done();
    exit(0);
}

print_pro(p)
    char *p;
{
    UBUF *ub;

    ub = client_interact(CC_GET_PRO,0L, strlen(p),p+1, 0,NULLP);

    if(ub->cmd == CC_ERR)
    {
	fprintf(stderr,"ERR: %s\n",ub->buf);
	return(0);

    } else
    {
	fprintf(stderr,"directory mode: %s\n",ub->buf);
	return(1);
    }
}
