    /*********************************************************************\
    *  Copyright (c) 1991 by Wen-King Su (wen-king@vlsi.cs.caltech.edu)   *
    *                                                                     *
    *  You may copy or modify this file in any manner you wish, provided  *
    *  that this notice is always included, and that you hold the author  *
    *  harmless for any loss or damage resulting from the installation or *
    *  use of this software.                                              *
    \*********************************************************************/

#include "client_def.h"

main(argc,argv,envp)
    int argc;
    char **argv,**envp;
{
    unsigned long pos;
    RDIRENT **dp;

    env_client();

    fls_main(argc,argv,envp);

    client_done();

    exit(0);
}

ls_bad(n)
    int n;
{
    client_done();
    exit(n);
}
