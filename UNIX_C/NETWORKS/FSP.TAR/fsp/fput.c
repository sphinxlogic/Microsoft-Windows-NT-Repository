    /*********************************************************************\
    *  Copyright (c) 1991 by Wen-King Su (wen-king@vlsi.cs.caltech.edu)   *
    *                                                                     *
    *  You may copy or modify this file in any manner you wish, provided  *
    *  that this notice is always included, and that you hold the author  *
    *  harmless for any loss or damage resulting from the installation or *
    *  use of this software.                                              *
    \*********************************************************************/

#include "client_def.h"

main(argc,argv,envp)
    int argc;
    char **argv,**envp;
{
    env_client();
    while(*++argv) put_file(*argv);
    client_done();

    exit(0);
}

put_file(path)
    char *path;
{
    struct stat sb;
    char *name, *t2;
    FILE *fp;

    if(stat(path,&sb) != 0) { perror(path); return; }
    if(!(S_IFREG & sb.st_mode)) { fprintf(stderr,"%s: not a file\n",path);
				return; }

    for(name = t2 = path; *t2; t2++) if(*t2 == '/') name = t2 + 1;

    if(fp = fopen(path,"r"))
    {
	util_upload(name,fp);
	fclose(fp);

    } else fprintf(stderr,"Cannot read %s\n",path);
}
