    /*********************************************************************\
    *  Copyright (c) 1991 by Wen-King Su (wen-king@vlsi.cs.caltech.edu)   *
    *                                                                     *
    *  You may copy or modify this file in any manner you wish, provided  *
    *  that this notice is always included, and that you hold the author  *
    *  harmless for any loss or damage resulting from the installation or *
    *  use of this software.                                              *
    \*********************************************************************/

#include "client_def.h"

extern char **glob(), *util_abs_path();

main(argc,argv,envp)
    int argc;
    char **argv,**envp;
{
    char **av, *av2[2], *key;

    env_client();

    if(argv[1]	&& (argv[1][0] == '+' || argv[1][0] == '-')
		&& (argv[1][1] == 'c' || argv[1][1] == 'd'))
    {
        key = *++argv;

	while(*++argv)
	{
	    if(!(av = glob(*argv))) { av = av2; av2[0] = *argv; av2[1] = 0; }
	    while(*av) set_pro(*av++,key);
	}

    } else
    {
	if(argv[1]) while(*++argv)
	{
	    if(!(av = glob(*argv))) { av = av2; av2[0] = *argv; av2[1] = 0; }
	    while(*av) print_pro(*av++);

	} else print_pro(".");
    }

    client_done();

    exit(0);
}

print_pro(p)
    char *p;
{
    char *op;
    UBUF *ub;

    op = util_abs_path(p);

    ub = client_interact(CC_GET_PRO,0L, strlen(op),op+1, 0,NULLP);

    printf("%s\t: %s\n",p,ub->buf);

    return(0);
}

set_pro(p,key)
    char *p, *key;
{
    char *op;
    UBUF *ub;

    op = util_abs_path(p);

    ub = client_interact(CC_SET_PRO,0L, strlen(op),op+1, strlen(key)+1,key);

    printf("%s\t: %s\n",p,ub->buf);

    return(0);
}
