/*
 * Copyright (c) 1991 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that the above copyright notice and this paragraph are
 * duplicated in all such forms and that any documentation,
 * advertising materials, and other materials related to such
 * distribution and use acknowledge that the software was developed
 * by the University of California, Irvine.  The name of the
 * University may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */
#include <stdio.h>
#include <curses.h>
#include <signal.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/time.h>
#include <math.h>
#include "ethertop.h"
#include "buffer.h"
#include "sort.h"
#ifndef lint
char copyright[]="Copyright (c) 1991 Regents of the University of California. All rights reserved.";
#endif 
WINDOW *src_window;
WINDOW *dest_window;
WINDOW *size_window1;
WINDOW *size_window2;
WINDOW *load_window;
WINDOW *user_window;

struct sgttyb tty_settings;

displayip=FALSE;
total=FALSE;
char *server;
int maxlines;

void swan_song(message)
char *message;
{
  clear();
  mvcur(0, COLS-1, LINES-1, 0);
  refresh();
  endwin();
  perror(message);
  fflush(stderr);
  exit(0);
}

void death()
{
  signal(SIGINT, SIG_IGN);
  clear();
  mvcur(0, COLS-1, LINES-1, 0);
  refresh();
  endwin();
  exit(0);
}

/*
         1         2         3         4         5         6         7         
1234567890123456789012345678901234567890123456789012345678901234567890123456789
*/
/*
       |       |       |       |       |       |       |       |       |
*/


void setup_screen()
{
  int x;
  signal(SIGINT, death);
  ioctl(0,TIOCGETP,&tty_settings);
  initscr();
  maxlines=LINES-9;
  noecho();
  crmode();
  nonl();
  user_window=newwin(1,0,0,0);
  scrollok(stdscr,0);
  load_window=subwin(stdscr,1,0,2,0);
  size_window1=subwin(stdscr,1,0,5,0);
  size_window2=subwin(stdscr,1,0,7,0);
  src_window=subwin(stdscr,LINES-10,39,10,0);
  dest_window=subwin(stdscr,LINES-10,39,10,41);
  move(0,0);
  printw("Network load as seen from %s", server);
  move(1,0);
  printw("   bytes    pkts    bcst     tcp     udp    icmp     arp      nd     oth");
  move(3,0);
  printw("packet sizes:");
  move(4,0);
  printw(" 64-154  155-245    246-336    337-427   428-518   519-609   610-699   700-790");
  move(6,0);
  printw("791-881  882-972   973-1063  1064-1154 1155-1245 1246-1336 1337-1427 1428-1518");
  move(8,0);
  printw("--------------------------------------------------------------------------------");
  move(9,0);
  printw("HOSTNAME                          SENT | HOSTNAME                          RECV ");
  for (x=9; x!=LINES; x++)
    {
      move(x,39);
      addch('|');
    }
}

void display_data(diffstat)
etherfloatstat *diffstat;
{
      
      wmove(load_window,0,0);
      wprintw(load_window,"%7.2fK %7.2f %7.2f %7.2f %7.2f %7.2f %7.2f %7.2f %7.2f",
	      (double) diffstat->e_bytes/1024.0,
	      (double) diffstat->e_packets,
	      (double) diffstat->e_bcast,
	      (double) diffstat->e_proto[3], 
	      (double) diffstat->e_proto[2],
	      (double) diffstat->e_proto[1],
	      (double) diffstat->e_proto[4],
	      (double) diffstat->e_proto[0],
	      (double) diffstat->e_proto[5]);
      
      wmove(size_window1,0,0);
      wprintw(size_window1,"%7.2f  %7.2f    %7.2f    %7.2f   %7.2f   %7.2f   %7.2f   %7.2f ",
	      (double) diffstat->e_size[0],
	      (double) diffstat->e_size[1],
	      (double) diffstat->e_size[2],
	      (double) diffstat->e_size[3],
	      (double) diffstat->e_size[4],
	      (double) diffstat->e_size[5],
	      (double) diffstat->e_size[6],
	      (double) diffstat->e_size[7]);

      wmove(size_window2,0,0);
      wprintw(size_window2,"%7.2f  %7.2f    %7.2f    %7.2f   %7.2f   %7.2f   %7.2f   %7.2f ",
	      (double) diffstat->e_size[8],
	      (double) diffstat->e_size[9],
	      (double) diffstat->e_size[10],
	      (double) diffstat->e_size[11],
	      (double) diffstat->e_size[12],
	      (double) diffstat->e_size[13],
	      (double) diffstat->e_size[14],
	      (double) diffstat->e_size[15]);

}

void display_a_list(window,buf)
     WINDOW *window;
     buffer *buf;
{
  register unsigned int i;
  etherfloat_node *ptr;
  for (i=0; i<maxlines && i<buf->end; i++)
    {
      wmove(window,i,0);
      ptr=buf->p[i];
      wprintw(window, "%-30.30s %7.2f", 
	      gethostnamebyip(ptr->h_addr),
	      (double)ptr->h_cnt);
    }
  wmove(window,i,0);
  wclrtobot(window);
}

/* I am not proud of this routine, but it works */
int wgnum(window,min,max)
WINDOW *window;
int min;
int max;
{
  int ch;
  int i=0;
  int x,y;
  int maxchar;
  int minchar;
  char string[80];
  bzero(string,80);
  maxchar=(int) log10 ((double) (max*10));
  nl();
  noecho();
  getyx(window,y,x);
  while(1)
    {
      ch=getch();
      if ((ch=='\n')
	  && i>0
	  && (atoi(string) <=max)
	  && (atoi(string) >= min) )
	{
	  nonl();
	  noecho();
	  return(atoi(string));
	}
      if(ch==tty_settings.sg_erase)
	{
	  if(i>0)
	    {
	      string[--i]=0;
	      mvwdelch(window,y,x+i);
	      wrefresh(window);
	      continue;
	    }
	  else
	    {
	      continue;
	    }
	}
      if(isdigit(ch))
	{
	  if (i<maxchar)
	    {
	      string[i++]=ch;
	      mvwaddch(window,y,x+i-1,ch);
	      wrefresh(window);
	      continue;
	    }
	}
    }
}


void process_input()
{
  switch(tolower(getch()))
    {
    case 'i':
      displayip=!displayip;
      break;
    case 't':
      total=!total;
      break;
    case 'q':
      death();
      break;
    case 'l':
      wrefresh(curscr);
      break;
    case 's':
      {
	werase(user_window);
	wstandout(user_window);
	waddstr(user_window,"Seconds to delay:");
	wstandend(user_window);
	waddstr(user_window," ");
	touchwin(user_window);
	wrefresh(user_window);
	timeout.tv_sec=wgnum(user_window,2,3600);
	touchwin(stdscr);
	refresh();
	break;
      }
    case 'n':
      	werase(user_window);
	wstandout(user_window);
	waddstr(user_window,"Hosts to display:");
	wstandend(user_window);
	waddstr(user_window," ");
	touchwin(user_window);
	wrefresh(user_window);
	maxlines=wgnum(user_window,0,LINES-9);
	touchwin(stdscr);
	refresh();
	break;
    default:
      ;
    }
}


int errflg=0;
etherfloatstat diffstat;
etheraddrs old_src_addrs;
etheraddrs old_dest_addrs; 
etherstat old_stat_data;
fd_set readfds,tempreadfds;
struct timeval timeout={5,0};
struct timeval temptimeout;
extern char *optarg;
extern int optind, opterr;
      

main(argc, argv)

     char *argv[];
{
  CLIENT *cl;
  etherstat *stat_data;
  etheraddrs *src_addrs;
  etheraddrs *dest_addrs;
  buffer *src_buf;
  buffer *dest_buf;
  char c;

  while ((c=getopt(argc, argv, "is:t"))!=-1)
    switch(c)
      {
      case 'i':
	displayip++;
	break;
	
      case 's':
	timeout.tv_sec=atol(optarg);
	if (timeout.tv_sec<2)
	  errflg++;
	break;
	
      case 't':
	total++;
	break;

      case '?':
	errflg++;
	break;
      }

  if (optind!=argc-1  || errflg)
    {
      fprintf(stderr,"Usage:\n");
      fprintf(stderr,"%s [options] hostname\n\n",argv[0]);
      fprintf(stderr,"options are:\n");
      fprintf(stderr,"-i           don't map ip numbers to hostnames\n");
      fprintf(stderr,"-s int       seconds between updates.  Minimum of 2 seconds.\n");
      fprintf(stderr,"-t           display time averaged totals, rather than instantanous averages\n");
      exit(2);
    }
  server=argv[optind];

  src_buf=init_buffer();     
  dest_buf=init_buffer();
  cl = clnt_create(server, ETHERPROG, ETHERVERS, "udp");
  if (cl == NULL)
    {
      clnt_pcreateerror(server);
      exit(1);
    }
  setup_screen();
  init_gethostnamebyip();
  FD_ZERO(&readfds);
  FD_SET(0,&readfds); /* set up stdin for select */
  

  if((etherproc_on_1((void *)NULL,cl))==NULL)
    swan_song("etherproc_on failed. rpc.etherd probably died");

  if((stat_data=etherproc_getdata_1((void *) NULL, cl))==NULL)
    swan_song("etherproc_getdata failed. rpc.etherd probably died");
     
  old_stat_data=*stat_data;
  
  if((src_addrs=etherproc_getsrcdata_1((void *) NULL, cl))==NULL)
    swan_song("etherproc_getdata failed. rpc.etherd probably died");

  old_src_addrs=*src_addrs;

  if( (dest_addrs =etherproc_getdstdata_1((void *) NULL, cl))==NULL)
    swan_song("etherproc_getdata failed. rpc.etherd probably died");


  old_dest_addrs=*dest_addrs;
  sleep(1); /*snewz*/
  
  for (;;)
    {
      move(2,0);
      refresh();
      tempreadfds=readfds;
      temptimeout=timeout;
      if(select(3,&tempreadfds,NULL,NULL,&temptimeout))
	process_input();

      if( (stat_data=etherproc_getdata_1((void *) NULL, cl))==NULL)
	swan_song("etherproc_getdata failed. rpc.etherd probably died");

      subtract_etherstat(stat_data,&old_stat_data,&diffstat);
      if (total)
	{
	  xdr_free(xdr_etherstat,stat_data);
	}
      else
	{
	  xdr_free(xdr_etherstat,&old_stat_data);
	  old_stat_data=*stat_data;
	}
      
      display_data(&diffstat);
      
      if( (src_addrs =etherproc_getsrcdata_1((void *) NULL, cl))==NULL)
	swan_song("etherproc_getsrcdata failed. rpc.etherd probably died");

      subtract_and_sort_etheraddrs(src_addrs, &old_src_addrs, src_buf);

      if (total)
	{
	  xdr_free(xdr_etheraddrs,src_addrs);
	}
      else
	{
	  xdr_free(xdr_etheraddrs,&old_src_addrs);
	  old_src_addrs=*src_addrs;
	}

      
      if( (dest_addrs=etherproc_getdstdata_1((void *) NULL, cl))==NULL)
	swan_song("etherproc_getdstdata failed. rpc.etherd probably died");

      subtract_and_sort_etheraddrs(dest_addrs, &old_dest_addrs, dest_buf);
      if (total)
	{
	  xdr_free(xdr_etheraddrs,dest_addrs);
	}
      else
	{
	  xdr_free(xdr_etheraddrs,&old_dest_addrs);
	  old_dest_addrs=*dest_addrs;
	}
      display_a_list(src_window,src_buf);
      display_a_list(dest_window,dest_buf);
      free_buffer(src_buf);
      free_buffer(dest_buf);
    }
}






      






