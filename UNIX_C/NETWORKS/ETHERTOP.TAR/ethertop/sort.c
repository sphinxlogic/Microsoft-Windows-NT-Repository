/*
 * Copyright (c) 1991 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that the above copyright notice and this paragraph are
 * duplicated in all such forms and that any documentation,
 * advertising materials, and other materials related to such
 * distribution and use acknowledge that the software was developed
 * by the University of California, Irvine.  The name of the
 * University may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */
#include <stdio.h>
#include "ethertop.h"
#include "buffer.h"

#define subtract(x,y) ((x)>(y) ? (x)-(y) : (y)-(x))

void subtract_etherstat(new,old,diff)
struct etherstat *new, *old;
etherfloatstat *diff;
{
  register unsigned int x;
  float difftime;
  difftime=(float) subtract(new->e_time.tv_seconds,old->e_time.tv_seconds)
    + (subtract((float) new->e_time.tv_useconds , (float) old->e_time.tv_useconds)) / 1000000.00;
  diff->e_time=difftime;
  diff->e_bytes  =subtract(new->e_bytes,old->e_bytes)/difftime;
  diff->e_packets=subtract(new->e_packets,old->e_packets)/difftime;
  diff->e_bcast  =subtract(new->e_bcast,old->e_bcast)/difftime;
  for (x=0; x<NPROTOS; x++)
    {
      diff->e_proto[x]=subtract(new->e_proto[x],old->e_proto[x])/difftime;
    }
  for (x=0; x<NBUCKETS; x++)
    {
      diff->e_size[x]=subtract(new->e_size[x],old->e_size[x])/difftime;
    }
}




int size_compare(a,b)
etherfloat_node **a,**b;
{
  if ((*b)->h_cnt < (*a)->h_cnt)
    return -1;
  if((*b)->h_cnt > (*a)->h_cnt)
    return 1;
  return 0;
}


void subtract_and_sort_etheraddrs(new, old, buf)
     struct etheraddrs *new,*old;
     buffer *buf;
{
  register unsigned int i;
  register float difftime;
  etherhmem_node *newptr, *oldptr;
  etherfloat_node *diffptr;
  difftime=(float) subtract(new->e_time.tv_seconds,old->e_time.tv_seconds)
    + (subtract((float) new->e_time.tv_useconds , (float) old->e_time.tv_useconds)) / 1000000.00;

  for (i=0; i<HASHSIZE; i++)
    {
      newptr=new->e_addrs[i];
      oldptr=old->e_addrs[i];
      while(newptr!=NULL) /* not a valid record */
	{
	  while (oldptr!=NULL &&  /* old record is there */
		 oldptr->h_addr!=newptr->h_addr) /* but record has been inserted */
	    {
	      oldptr=oldptr->h_nxt; /* jump to next old address until you reach end */
	                            /* or addresses match */
	    }
	  if (oldptr==NULL)  /* old record does not exist */
	    {
	      diffptr=(etherfloat_node *)malloc(sizeof(etherfloat_node));
	      diffptr->h_addr=newptr->h_addr;
	      diffptr->h_cnt=(float)(newptr->h_cnt) / difftime;
	      add_buffer(buf,diffptr);
	    }
	  else /* old record existed */
	    { 
	      if (newptr->h_cnt!=oldptr->h_cnt) /* count different */
		{
		  diffptr=(etherfloat_node *)malloc(sizeof(etherfloat_node));
		  diffptr->h_addr=newptr->h_addr;
		  diffptr->h_cnt=(float) (subtract(newptr->h_cnt,oldptr->h_cnt)/difftime);
		  add_buffer(buf,diffptr);
		}
	      oldptr=oldptr->h_nxt;
	    }
	  newptr=newptr->h_nxt;
	}
    }
  qsort( (char *) buf->p, buf->end, sizeof(void *), size_compare);
}


