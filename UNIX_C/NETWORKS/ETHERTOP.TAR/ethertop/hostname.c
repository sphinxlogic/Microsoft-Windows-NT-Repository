/*
 * Copyright (c) 1991 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that the above copyright notice and this paragraph are
 * duplicated in all such forms and that any documentation,
 * advertising materials, and other materials related to such
 * distribution and use acknowledge that the software was developed
 * by the University of California, Irvine.  The name of the
 * University may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <string.h>
#include "ethertop.h"


static host_ip_ent *hash_table[H2IP_HASH_SIZE];

void init_gethostnamebyip()
{
  register int i;
  for(i=0; i<H2IP_HASH_SIZE; i++)
    hash_table[i]=NULL;
}


char *gethostnamebyip(h_addr)
     int h_addr;
{
  register host_ip_ent *ptr;
  struct hostent *host;
  host_ip_ent *temp;
  unsigned int index;
  if (displayip)
    {
      return(inet_ntoa(&h_addr));
    }
  index=((unsigned int)h_addr & H2IP_HASH_MASK);

  for (ptr=hash_table[index] ; ptr!=NULL; ptr=ptr->h_nxt )
    {
      if (ptr->h_addr==h_addr)
	{
	  return(ptr->h_name);
	}
    }
  temp=hash_table[index];
  ptr=hash_table[index]=(host_ip_ent *)malloc(sizeof(host_ip_ent));
  ptr->h_nxt=temp;
  ptr->h_addr=h_addr;
  if ((host=gethostbyaddr(&h_addr,sizeof(int),AF_INET))!=NULL)
    {
      ptr->h_name=strdup(host->h_name);
    }
  else
    {
      ptr->h_name=strdup(inet_ntoa(&h_addr));
    }
  return(ptr->h_name);
}



  
  




