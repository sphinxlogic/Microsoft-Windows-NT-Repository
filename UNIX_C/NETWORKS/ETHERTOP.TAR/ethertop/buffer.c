/*
 * Copyright (c) 1991 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that the above copyright notice and this paragraph are
 * duplicated in all such forms and that any documentation,
 * advertising materials, and other materials related to such
 * distribution and use acknowledge that the software was developed
 * by the University of California, Irvine.  The name of the
 * University may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */
#include "buffer.h"
#include <stdio.h>

void add_buffer(buf, entry)
buffer *buf;
void *entry;
{
  buf->p[buf->end]=entry;
  buf->end++;
  if (buf->end == buf->len)
    {
      fprintf(stderr,"reallocing buffer\n");
      buf->len+=BUFLEN;
      buf->p=(void **)realloc(buf->p,buf->len);
    }
}

void clear_buffer(buf)
buffer *buf;
{
buf->end=0;
}

void free_buffer(buf)
buffer *buf;
{
unsigned int i;
for (i=0; i<buf->end; i++)
	free(buf->p[i]);
buf->end=0;
}


buffer *init_buffer()
{
  buffer *buf;
  
  buf= (buffer *) malloc (sizeof(buffer));
  buf->p=(void **) malloc(BUFLEN*sizeof(void *));
  buf->end=0;
  buf->len=BUFLEN;
  return (buf);
}




