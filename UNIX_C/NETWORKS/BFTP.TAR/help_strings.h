/* Help strings for event procs -- middle mouse button */

char
  paren_help[] = 
    "  If blank, the default is shown in parentheses.",

  toggle_help[] =
    "  Click to display/undisplay the subwindow.",

  reqSW1_help[] =
    "The Request Storage subwindow is used to save the current request",
  reqSW2_help[] =
    "  in a file, or to load a request that has been saved previously.",


  dhost_help[] =
    "Destination host name: e.g. 'venera.isi.edu' or '128.9.0.32'.",
  dlogin_help[] =
    "Login (user name) on the destination host.",
  dpass_help[] =
    "Password on the destination host.",
  dfile_help[] =
    "File name that will be used on the destination host.",

  ddir1_help[] =
    "Directory on the destination host in which the file will be located.",
  ddir2_help[] =
    "  If the login directory is to be used, this field should be left",
  ddir3_help[] = 
    "  blank.  This field may be specified as an absolute path, or",
  ddir4_help[] = 
    "  relative to the login directory.  Any delimiter characters used",
  ddir5_help[] = 
    "  on this host, for example '/' or '<>' may be included.",
  quit_help[] =
    "Quit is used to exit the tool, destroying any popup windows.",

  sHost_help[] =
  "Source host name or number: e.g. 'venera.isi.edu' or '128.9.0.32'.",

  sLogin_help[] =
  "Login (user name) on the source host.",
	   
  sPass_help[] =
  "Password on the source host.",

  sFile1_help[] =
  "Name of file to be transfered.  The wildcard character '*'",
  sFile2_help[] =
  "  may be used if the Multiple flag is set to TRUE.",

  sDir1_help[] =
"Directory on the source host in which the file is located.  If the",
  sDir2_help[] =
"  login directory is to be used, this field should be left blank.",
  sDir3_help[] =
"  This field may be specified as an absolute path, or relative to",
  sDir4_help[] =
"  the login directory.  Any delimiter characters used on the",
  sDir5_help[] =
"  source host, for example '/' or '<>' may be included.";

