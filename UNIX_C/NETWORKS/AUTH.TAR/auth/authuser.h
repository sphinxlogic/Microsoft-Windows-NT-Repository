#ifndef AUTHUSER_H
#define AUTHUSER_H

extern char authuserauthor[];
extern char authuserversion[];
extern char authusercopyright[];
extern char authuserwarranty[];
extern char authuserhelp[];

int auth_casecmp();
char *auth_xline();
int auth_fd();
char *auth_tcpuser();

#endif
