/*
authd.c: Authentication Server daemon
*/

static char authdauthor[] =
"authd was written by Daniel J. Bernstein.\n\
Internet address: brnstnd@acf10.nyu.edu.\n";

static char authdversion[] = 
"authd version 2.1, April 18, 1990.\n\
Copyright (c) 1990, Daniel J. Bernstein.\n\
All rights reserved.\n";

static char authdcopyright[] =
"authd version 2.1, April 18, 1990.\n\
Copyright (c) 1990, Daniel J. Bernstein.\n\
All rights reserved.\n\
\n\
Until January 1, 1995, you are granted the following rights: A. To make\n\
copies of this work in original form, so long as (1) the copies are exact\n\
and complete; (2) the copies include the copyright notice, this paragraph,\n\
and the disclaimer of warranty in their entirety. B. To distribute this\n\
work, or copies made under the provisions above, so long as (1) this is\n\
the original work and not a derivative form; (2) you do not charge a fee\n\
for copying or for distribution; (3) you ensure that the distributed form\n\
includes the copyright notice, this paragraph, and the disclaimer of\n\
warranty in their entirety. These rights are temporary and revocable upon\n\
written, oral, or other notice by Daniel J. Bernstein. These rights are\n\
automatically revoked on January 1, 1995. This copyright notice shall be\n\
governed by the laws of the state of New York.\n\
\n\
If you have questions about authd or about this copyright notice,\n\
or if you would like additional rights beyond those granted above,\n\
please feel free to contact the author at brnstnd@acf10.nyu.edu\n\
on the Internet.\n";

static char authdwarranty[] =
"To the extent permitted by applicable law, Daniel J. Bernstein disclaims\n\
all warranties, explicit or implied, including but not limited to the\n\
implied warranties of merchantability and fitness for a particular purpose.\n\
Daniel J. Bernstein is not and shall not be liable for any damages,\n\
incidental or consequential, arising from the use of this program, even\n\
if you inform him of the possibility of such damages. This disclaimer\n\
shall be governed by the laws of the state of New York.\n\
\n\
In other words, use this program at your own risk.\n\
\n\
If you have questions about authd or about this disclaimer of warranty,\n\
please feel free to contact the author at brnstnd@acf10.nyu.edu\n\
on the Internet.\n";

static char authdusage[] =
"Usage: authd [ -ACHUVW ] \n\
Help:  authd -H\n";

static char authdhelp[] =
"authd provides TCP authentication information to other Internet hosts. \n\
\n\
authd -A: print authorship notice\n\
authd -C: print copyright notice\n\
authd -H: print this notice\n\
authd -U: print short usage summary\n\
authd -V: print version number\n\
authd -W: print disclaimer of warranty\n\
\n\
authd: provide authentication information as per RFC 931\n\
\n\
authd should be run under a TCP connection server, such as\n\
inetd(8) or attachport(1).\n\
\n\
If you have questions about or suggestions for authd, please feel free\n\
to contact the author, Daniel J. Bernstein, at brnstnd@acf10.nyu.edu\n\
on the Internet.\n";

#include <stdio.h>
extern int errno;
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/file.h>
#ifdef BSD
#include <limits.h>
#endif
extern int getopt();
extern char *optarg; /* these should be in getopt.h! */
extern int optind;
#include <ctype.h>
#include "djberr.h"

#ifndef AUTHDIR
#define AUTHDIR "/usr/etc/auth"
#endif

#define ERR(num) { printf("%s, %s: ERROR: UNKNOWN-ERROR\r\n",\
                          localport,remoteport); exit(num); }

main(argc,argv,envp)
int argc;
char *argv[];
char *envp[];
{
 int ch;
 char localport[10];
 int localportlen = 0;
 char remoteport[10];
 int remoteportlen = 0;
 int loop = 0;
 struct sockaddr_in sa;
 int salen;
 int authfd;
 char authfn[sizeof(AUTHDIR) + 30];
 int lockfd;
 char lockfn[sizeof(AUTHDIR) + 30]; /* for new locking protocol */
 char lockbuf[32]; /* 5 pid, 1 :, 10 I, 1 ., 5 R, 1 \n, 8 U, 1 \0 */
 unsigned long lockin;
 unsigned short lockport;
 int r;
 char buf[9];
 int opt;

 while ((opt = getopt(argc,argv,"ACHUVW")) != EOF)
   switch(opt)
    {
     case 'A': (void) err(authdauthor); exit(1);
     case 'C': (void) err(authdcopyright); exit(1);
     case 'H': (void) err(authdhelp); exit(1);
     case 'U': (void) err(authdusage); exit(1);
     case 'V': (void) err(authdversion); exit(1);
     case 'W': (void) err(authdwarranty); exit(1);
     case '?': (void) err(authdusage); exit(1);
    }
 argv += optind, argc -= optind;
 if (*argv)
  {
   (void) err(authdusage); exit(1);
  }

 while ((ch = getchar()) != ',')
  {
   if (isascii(ch) && isdigit(ch))
     localport[localportlen++] = ch;
   if (localportlen == 6) /* tough luck! */
     exit(2);
   if ((++loop) > 1000) /* tough luck! */
     exit(3);
  }
 
 while ((ch = getchar()) != '\n')
  {
   if (isascii(ch) && isdigit(ch))
     remoteport[remoteportlen++] = ch;
   if (remoteportlen == 6) /* tough luck! */
     exit(4);
   if ((++loop) > 1000) /* tough luck! */
     exit(5);
  }
 
 /* Now we'll be nice enough to respond. */

 salen = sizeof(sa);
 if (getpeername(0,&sa,&salen) == -1) ERR(6)

 /* Now we have enough information to look up answer. */

 (void) sprintf(lockfn,"%s/tcp/lock.%s",AUTHDIR,localport);
 if ((lockfd = open(lockfn,O_RDONLY)) == -1) ERR(7)
 (void) flock(lockfd,LOCK_EX); /* can't fail */
 if ((r = read(lockfd,lockbuf,31)) <= 0) ERR(8)
 lockbuf[r] = '\0';
 if (lockbuf[0] == '!') ERR(12) /* ding ding ding! security alert! */

 (void) sprintf(authfn,"%s/tcp/%D.%s.%s",AUTHDIR,sa.sin_addr.s_addr,
                localport,remoteport);
 if ((authfd = open(authfn,O_RDONLY)) == -1)
  {
   /* maybe it's authtcp and username file isn't there yet */
   if (sscanf(lockbuf,"%*d:%D.%hd %8s",&lockin,&lockport,buf) < 3) ERR(9)
   if ((lockin != sa.sin_addr.s_addr) || (lockport != atoi(remoteport))) ERR(10)
   /* bingo! */
  }
 else
  {
   if ((r = read(authfd,buf,8)) <= 0) ERR(11)
   buf[r] = '\0';
  }

 printf("%s, %s: USERID: UNIX: %s\r\n",localport,remoteport,buf);

 (void) flock(lockfd,LOCK_UN); /* unnecessary */
 exit(0);
}
