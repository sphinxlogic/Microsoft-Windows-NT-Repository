/*
attachport.c: attach a server program to a TCP port
*/

/* WARNING! WARNING! WARNING! */
/* For the authentication to work, attachport must run setuid auth! */
/* All setuid programs are dangerous! Check them carefully! */

static char attachportauthor[] =
"attachport was written by Daniel J. Bernstein.\n\
Internet address: brnstnd@acf10.nyu.edu.\n";

static char attachportversion[] = 
"attachport version 4.1, April 18, 1990.\n\
Copyright (c) 1990, Daniel J. Bernstein.\n\
All rights reserved.\n";

static char attachportcopyright[] =
"attachport version 4.1, April 18, 1990.\n\
Copyright (c) 1990, Daniel J. Bernstein.\n\
All rights reserved.\n\
\n\
Until January 1, 1995, you are granted the following rights: A. To make\n\
copies of this work in original form, so long as (1) the copies are exact\n\
and complete; (2) the copies include the copyright notice, this paragraph,\n\
and the disclaimer of warranty in their entirety. B. To distribute this\n\
work, or copies made under the provisions above, so long as (1) this is\n\
the original work and not a derivative form; (2) you do not charge a fee\n\
for copying or for distribution; (3) you ensure that the distributed form\n\
includes the copyright notice, this paragraph, and the disclaimer of\n\
warranty in their entirety. These rights are temporary and revocable upon\n\
written, oral, or other notice by Daniel J. Bernstein. These rights are\n\
automatically revoked on January 1, 1995. This copyright notice shall be\n\
governed by the laws of the state of New York.\n\
\n\
If you have questions about attachport or about this copyright notice,\n\
or if you would like additional rights beyond those granted above,\n\
please feel free to contact the author at brnstnd@acf10.nyu.edu\n\
on the Internet.\n";

static char attachportwarranty[] =
"To the extent permitted by applicable law, Daniel J. Bernstein disclaims\n\
all warranties, explicit or implied, including but not limited to the\n\
implied warranties of merchantability and fitness for a particular purpose.\n\
Daniel J. Bernstein is not and shall not be liable for any damages,\n\
incidental or consequential, arising from the use of this program, even\n\
if you inform him of the possibility of such damages. This disclaimer\n\
shall be governed by the laws of the state of New York.\n\
\n\
In other words, use this program at your own risk.\n\
\n\
If you have questions about attachport or about this disclaimer of warranty,\n\
please feel free to contact the author at brnstnd@acf10.nyu.edu\n\
on the Internet.\n";

static char attachportusage[] =
"Usage: attachport [ -01vrRxXACHUVW ] [ -pport ] program [ arg ... ]\n\
Help:  attachport -H\n";

static char attachporthelp[] =
"attachport attaches a server program to a TCP port.\n\
\n\
attachport -A: print authorship notice\n\
attachport -C: print copyright notice\n\
attachport -H: print this notice\n\
attachport -U: print short usage summary\n\
attachport -V: print version number\n\
attachport -W: print disclaimer of warranty\n\
\n\
attachport [ -01vrRxX ] [ -pport ] program [ arg ... ]: attach program to port\n\
  -v: verbose: proclaim success\n\
  -1: print port number on standard output\n\
  -0: check every ten seconds for fd 0 to have links; if none, wither away\n\
  -x: locally authenticate connections with authd(8) (default)\n\
  -X: do not locally authenticate\n\
  -r: attempt to authenticate the remote side as well (default), placing\n\
      user@host and TCP into environment variables REMOTE and PROTO\n\
  -R: do not remotely authenticate\n\
  -pport: attach server to a particular TCP port\n\
\n\
If you have questions about or suggestions for attachport, please feel free\n\
to contact the author, Daniel J. Bernstein, at brnstnd@acf10.nyu.edu\n\
on the Internet.\n";

#include <stdio.h>
#include <sys/types.h>
#include <sys/file.h>
#ifdef BSD
#include <limits.h>
#endif
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <sys/param.h>
#include <pwd.h>
extern char *malloc(); /* many systems don't have malloc.h */
extern int getopt();
extern char *optarg; /* these should be in getopt.h! */
extern int optind;
#include <ctype.h>
#include "authuser.h"
#include "djberr.h"
#include "djbatoi.h"

#ifndef AUTHDIR
#define AUTHDIR "/usr/etc/auth"
#endif

#ifndef MAXHOSTNAMELEN
#define MAXHOSTNAMELEN 128 /* stupid Suns don't define this in sys/param.h */
#endif

int numkids = 0;
int flagauth = 1;

unsigned long myinetaddr()
{
 char hn[MAXHOSTNAMELEN + 1];
 struct hostent *he;

 if (gethostname(hn,MAXHOSTNAMELEN) == -1)
   return((unsigned long) -1);
 if ((he = gethostbyname(hn)) == NULL)
   return((unsigned long) -1);

 return (*((unsigned long *) (he->h_addr)));
}

dissociatetty()
{
 int fd;

 if ((fd = open("/dev/tty",O_RDWR)) == -1)
  {
   perrn2("%s","attachport: warning: cannot open /dev/tty");
  }
 else
  {
   if (ioctl(fd,(unsigned long) TIOCNOTTY,(char *) NULL) == -1)
     perrn2("%s","attachport: warning: cannot dissociate /dev/tty");
   (void) close(fd);
  }
}

int uid;
int euid;

int flagcheckin = 0;
int alrmcounter = 0;

int flagdie;

sigterm()
{
 flagdie = 1;
}

sigalrm()
{
 struct stat st;

 if (flagcheckin)
  {
   (void) fstat(0,&st);
   if (st.st_nlink == 0)
     sigterm();
  }
 if ((++alrmcounter) % 12) /* every two minutes */
  {
   alrmcounter = 0;
   (void) kill(getpid(),SIGCHLD);
  }
}

sigchld()
{
 int w;
 char authfn[sizeof(AUTHDIR) + 30];
 char authpfn[sizeof(AUTHDIR) + 30];
 int authpfd;
 int r;
 int noweuid = geteuid();

 if (noweuid == uid) /* oopsie */
   if (setreuid(uid,euid))
    {
     perrn2("%s","attachport: warning: cannot setreuid");
     return; /* This is impossible anyway. */
    }

 while ((w = wait3((union wait *) 0,WNOHANG,(struct rusage *) NULL)) > 0)
  {
   numkids--;
   if (flagauth)
    {
     (void) sprintf(authpfn,"%s/tcp/ps.%d.%d",AUTHDIR,getpid(),w);
     if ((authpfd = open(authpfn,O_RDONLY,0600)) == -1)
      {
       perrn2("attachport: warning: cannot unlink authentication entry %s",authpfn);
       continue;
      }
     r = read(authpfd,authfn,sizeof(authfn));
     (void) close(authpfd);
     if ((r <= 0) || (strncmp(authfn,AUTHDIR,strlen(AUTHDIR))))
      { /* Make sure the worst damage we can do is confined to AUTHDIR. */
       perrn2("attachport: warning: cannot unlink authentication entry %s",authpfn);
       continue;
      }
     authfn[r] = '\0';
     if (unlink(authfn) == -1) /* had better succeed! */
      {
       perrn2("attachport: warning: cannot unlink authentication entry %s",authfn);
       continue;
      }
     if (unlink(authpfn) == -1) /* had better succeed! */
      {
       perrn2("attachport: warning: cannot unlink authentication entry %s",authpfn);
      }
    }
  }

 if (noweuid == uid) /* daisie */
   if (setreuid(euid,uid))
    {
     perrn2("%s","attachport: warning: cannot setreuid");
     return;
    }
}

extern char **environ;

main(argc,argv,envp)
int argc;
char *argv[];
char *envp[];
{
 int opt;
 int flagverbose = 0;
 int flagminiverb = 0;
 int flagremote = 2;
 char *strlocalport = "0";
 unsigned short localport;
 char **program = NULL;
 struct sockaddr_in sa;
 int s;
 int t;
 unsigned long in;
 int dummy;
 struct passwd *pw;
 int f;
 int authfd;
 int authpfd;
 char authfn[sizeof(AUTHDIR) + 30];
 char authpfn[sizeof(AUTHDIR) + 30];
 char lockfn[sizeof(AUTHDIR) + 30];
 int lockfd;
 char lockbuf[32]; /* 5 pid, 1 :, 10 I, 1 ., 5 R, 1 \n, 8 U, 1\0 */
		   /* we use just 5 pid, 1 -, 8 U, 1\0 */
 int lockbuflen;
 char foobuf[32];
 struct itimerval it;
 fd_set ready;
 struct servent *se;
 struct in_addr inet; /* dummy for inet_ntoa */
 int flagsigintign;
 int flagsigquitign;
 int flagsigtstpign;
 int flagsighupign;
 int flagsigxcpuign;
 int flagsigxfszign;
 int flagsigvtalrmign;
 int flagsigprofign;
 int flagsigchldign;
 int flagsigalrmign;
 int flagsigtermign;

 /* ALERT! ALERT! ALERT! We're probably running setuid auth! */
 /* Note that accounting is by real uid, not effective uid. */
 /* The system should be careful about setuid core dumps 'n' such. */

 uid = getuid();
 euid = geteuid();

 /* The following are necessary to be absolutely sure of removing the
    authentication entry. It's a flaw of the signal handling system that
    every new extension could turn a secure program like this into an
    (ever so slightly) insecure one. */
 flagsigintign = (signal(SIGINT,SIG_IGN) == SIG_IGN);
 flagsigquitign = (signal(SIGQUIT,SIG_IGN) == SIG_IGN);
 flagsigtstpign = (signal(SIGTSTP,SIG_IGN) == SIG_IGN);
 flagsighupign = (signal(SIGHUP,SIG_IGN) == SIG_IGN);
 flagsigxcpuign = (signal(SIGXCPU,SIG_IGN) == SIG_IGN);
 flagsigxfszign = (signal(SIGXFSZ,SIG_IGN) == SIG_IGN);
 flagsigvtalrmign = (signal(SIGVTALRM,SIG_IGN) == SIG_IGN);
 flagsigprofign = (signal(SIGPROF,SIG_IGN) == SIG_IGN);
 flagsigchldign = (signal(SIGCHLD,SIG_IGN) == SIG_IGN);
 flagsigalrmign = (signal(SIGALRM,SIG_IGN) == SIG_IGN);
 flagsigtermign = (signal(SIGTERM,SIG_IGN) == SIG_IGN);
 /* At least we can depend on SIG_IGN and SIG_DFL being the only
    possible handlers passed through an exec. Programmers should note
    the above trick to avoid having to worry about the signal() type. */

 while ((opt = getopt(argc,argv,"01vrRxXp:ACHUVW")) != EOF)
   switch(opt)
    {
     case 'v': flagverbose = 1; break;
     case '1': flagminiverb = 1; break;
     case '0': flagcheckin = 1; break;
     case 'r': flagremote = 1; break;
     case 'R': flagremote = 0; break;
     case 'x': flagauth = 1; break;
     case 'X': flagauth = 0; break;
     case 'p': strlocalport = optarg; break;
     case 'A': (void) err(attachportauthor);(void)setreuid(uid,uid); exit(1);
     case 'C': (void) err(attachportcopyright);(void)setreuid(uid,uid); exit(1);
     case 'H': (void) err(attachporthelp);(void)setreuid(uid,uid); exit(1);
     case 'U': (void) err(attachportusage);(void)setreuid(uid,uid); exit(1);
     case 'V': (void) err(attachportversion);(void)setreuid(uid,uid); exit(1);
     case 'W': (void) err(attachportwarranty);(void)setreuid(uid,uid); exit(1);
     case '?': (void) err(attachportusage);(void)setreuid(uid,uid); exit(1);
    }
 argv += optind; argc -= optind;
 program = argv;

 if ((program == NULL) || (*program == NULL))
  {
   (void) err(attachportusage);
   (void) setreuid(uid,uid); exit(1);
  }

 in = myinetaddr();
 if (in == (unsigned long) -1)
  {
   (void) errn("attachport: fatal: can't find my own Internet number?!");
   (void) setreuid(uid,uid); exit(1);
  }

 t = strlen(strlocalport) - 1;
 if (isascii(strlocalport[t]) && isdigit(strlocalport[t]))
   localport = atoi(strlocalport); /* so who cares if it's zero? */
 else
   if ((se = getservbyname(strlocalport,"tcp")) == NULL)
     localport = 0;
   else
     localport = ntohs(se->s_port); /* inconsistency alert! */
				    /* se->s_port is int! */

 if (flagauth)
   if ((pw = getpwuid(uid)) == NULL)
    {
     (void) errn("attachport: fatal: cannot authenticate: who are you?");
     (void) setreuid(uid,uid); exit(1);
    }

 /* We now switch to the real user id, though preserving euid for auth. */

 if (setreuid(euid,uid))
  {
   perrn2("%s","attachport: fatal: cannot setreuid");
   (void) setreuid(uid,uid); exit(1);
  }

 if ((s = socket(AF_INET,SOCK_STREAM,0)) == -1) /* no security problem */
  {
   perrn2("%s","attachport: fatal: cannot create socket");
   (void) setreuid(uid,uid); exit(1);
  }

 sa.sin_family = AF_INET;
 sa.sin_port = htons(localport);
 sa.sin_addr.s_addr = INADDR_ANY;

 if (bind(s,&sa,sizeof(sa)) == -1)
  {
   perrn2("%s","attachport: fatal: cannot bind");
   (void) setreuid(uid,uid); exit(1);
  }

 if (listen(s,5) == -1) /* 5 should be an option! */
  {
   perrn2("%s","attachport: fatal: cannot listen");
   (void) setreuid(uid,uid); exit(1);
  }

 dissociatetty();

 (void) signal(SIGTERM,sigterm); /* for killaport */
 (void) signal(SIGALRM,sigalrm); /* used to be just if flagcheckin */
 it.it_value.tv_sec = 10; it.it_value.tv_usec = 0; /* every ten seconds */
 it.it_interval.tv_sec = 10; it.it_interval.tv_usec = 0;
 (void) setitimer(ITIMER_REAL,&it,(struct itimerval *) 0);

 /* we still have uids switched */
 if (setreuid(uid,euid))
  {
   perrn2("%s","attachport: fatal: cannot setreuid");
   (void) setreuid(uid,uid); exit(1);
  }
 /* Now we're back to setuid auth... */

 dummy = sizeof(sa);
 if (getsockname(s,&sa,&dummy) == -1)
  {
   perrn2("%s","attachport: fatal: cannot get socket name");
   (void) setreuid(uid,uid); exit(1);
  }
 if (flagremote == 2)
   flagremote = (ntohs(sa.sin_port) != 113);
 if (flagverbose)
   (void) errn2("attachport: attached to port %d",ntohs(sa.sin_port));
 if (flagminiverb)
  {
   (void) printf("%d\n",ntohs(sa.sin_port));
   (void) fflush(stdout);
  }
 if (flagauth)
  {
   (void) sprintf(lockfn,"%s/tcp/lock.%u",AUTHDIR,
		  (unsigned int) ntohs(sa.sin_port));
   if (((lockfd = open(lockfn,O_WRONLY | O_CREAT | O_EXCL,0600)) == -1)
     &&(((lockfd = open(lockfn,O_RDONLY)) == -1)
	||(flock(lockfd,LOCK_EX) == -1)
        ||(read(lockfd,lockbuf,31) <= 0)
	||((lockbuf[0] != '!')
          &&((atoi(lockbuf) <= 0)
             ||(kill(atoi(lockbuf),0) == 0))) /* okay, screw the last process */
	||(close(lockfd) == -1) /* impossible */
        ||((lockfd = open(lockfn,O_WRONLY | O_CREAT | O_TRUNC,0600)) == -1)))
    { /* yikes, that was incomprehensible */
     errn2("attachport: fatal: local port %u locked",
	   (unsigned int) ntohs(sa.sin_port));
     (void) setreuid(uid,uid); exit(1);
    }
   (void) flock(lockfd,LOCK_EX);
   (void) sprintf(lockbuf,"%d-%s",getpid(),pw->pw_name);
   lockbuflen = strlen(lockbuf);
   (void) sprintf(foobuf,"!%s%d",pw->pw_name,getpid());
   (void) write(lockfd,lockbuf,lockbuflen);
   (void) flock(lockfd,LOCK_UN);
  }

 /* We must remain setuid auth as long as there are live authentication */
 /* entries. Otherwise the user could kill us and, if lucky enough, */
 /* misauthenticate future connections. It isn't so important to worry */
 /* about the lock file: that can only lead to a denial of service, and */
 /* it would take a huge amount of effort to guarantee that denial. */
 /* Anyway, we have to fork as the real uid: one system stupidity is */
 /* that fork() uses the effective uid for MAXUPRC checks. This isn't */
 /* a problem if there are no live authentication entries. */

 /* The solution is simple: We screw up the lock file while forking as */
 /* the real uid, then restore it afterwards. If we're killed in the */
 /* middle, authd will notice. This once again reduces the problem to */
 /* denial of service, which is acceptable. (In fact, the nature of the */
 /* messed up lock file is that it can't even cause denial of service.) */
 /* Ha! */

 (void) signal(SIGCHLD,sigchld);
 for (;;)
   if (flagdie)
     if (numkids > 0)
       sleep(60);
     else
      {
       if (flagauth)
	 (void) unlink(lockfn);
       (void) setreuid(uid,uid); exit(0); /* ahhh, so simple */
      }
   else
    {
     FD_ZERO(&ready); /* why, oh why doesn't this pass lint? */
     FD_SET(s,&ready);
     while ((select(s + 1,&ready,(fd_set *) 0,(fd_set *) 0,0) < 0)
	    && !flagdie)
       ; /* on error, ready won't be affected, so this is safe */
     if (!flagdie) /* could be set any time, so we have to check */
      {
       dummy = sizeof(sa);
       (void) flock(lockfd,LOCK_EX);
       (void) lseek(lockfd,(off_t) 0,0);
       (void) write(lockfd,foobuf,lockbuflen);
       if ((t = accept(s,&sa,&dummy)) > -1)
         if (setreuid(euid,uid))
	  {
	   perrn2("%s","attachport: warning: cannot setreuid");
	   (void) setreuid(uid,euid);
	  }
         else if ((f = fork()) == 0)
          {
           if (setreuid(uid,euid))
            {
             perrn2("%s","attachport: fatal: cannot setreuid");
             (void) setreuid(uid,uid); exit(1);
            }
           if (flagauth)
            {
             (void) sprintf(authfn,"%s/tcp/%D.%d.%d",AUTHDIR,
                            sa.sin_addr.s_addr,localport,ntohs(sa.sin_port));
             (void) sprintf(authpfn,"%s/tcp/ps.%d.%d",AUTHDIR,getppid(),getpid());
  	     if ((authpfd = open(authpfn,O_WRONLY | O_CREAT | O_EXCL,0600)) == -1)
  	      {
               perrn2("%s","attachport: warning: cannot authenticate");
	      }
             if ((authfd = open(authfn,O_WRONLY | O_CREAT | O_EXCL,0600)) == -1)
              {
               perrn2("%s","attachport: warning: cannot authenticate");
              }
             (void) write(authpfd,authfn,strlen(authfn));
             (void) write(authfd,pw->pw_name,strlen(pw->pw_name));
             (void) close(authpfd);
             (void) close(authfd); /* if it fails, tough luck. */
            }

           if (flagremote)
            {
             unsigned long in; /* keep confirming variables separate */
             unsigned short local;
             unsigned short remote;
             char *ruser;
             char *srem;
             char **temp;
             char **trem;
             char **tproto;
             char **envbak;
        
             if (auth_fd(t,&in,&local,&remote) == -1)
              {
               perrn2("%s","attachport: fatal: cannot confirm connection");
               exit(1);
              }
             if ((ruser = auth_tcpuser(in,local,remote)) == NULL)
               ruser = ""; /* bummer */
             if ((srem = malloc(strlen(ruser) + 30)) == NULL)
              {
               perrn2("%s","attachport: fatal: cannot allocate environment");
               exit(1);
              }
	     inet.s_addr = in;
	     sprintf(srem,"REMOTE=%s@%s",ruser,inet_ntoa(inet));
             for (trem = envp;*trem;trem++)
               if (strncmp(*trem,"REMOTE=",7) == 0)
                 break;
             for (tproto = envp;*tproto;tproto++)
               if (strncmp(*tproto,"PROTO=",6) == 0)
                 break;
             if (!(*trem && *tproto))
              {
               envbak = envp;
               if ((environ = (char **) malloc((trem - envp + 3) * sizeof(char*)))
		   == NULL)
                {
                 perrn2("%s","attachport: fatal: cannot allocate environment");
                 exit(1);
                }
               for (temp = envbak;*temp;temp++)
                 environ[temp - envbak] = *temp; /* not worth a bcopy */
               trem = environ + ((*trem ? trem : temp++) - envbak);
               tproto = environ + ((*tproto ? tproto : temp++) - envbak);
               environ[temp - envbak] = NULL;
              }
             *trem = srem;
             *tproto = "PROTO=TCP";
             /* XXXXXX: Should we do confirming sanity checks here? */
            }
           (void) close(0); (void) dup(t);
           (void) close(1); (void) dup(t);
           (void) close(2); (void) dup(t);
	   for (t = getdtablesize();t > 2;t--)
             (void) close(t);
	
           (void) signal(SIGINT,flagsigintign ? SIG_IGN : SIG_DFL);
           (void) signal(SIGQUIT,flagsigquitign ? SIG_IGN : SIG_DFL);
           (void) signal(SIGTSTP,flagsigtstpign ? SIG_IGN : SIG_DFL);
           (void) signal(SIGHUP,flagsighupign ? SIG_IGN : SIG_DFL);
           (void) signal(SIGXCPU,flagsigxcpuign ? SIG_IGN : SIG_DFL);
           (void) signal(SIGXFSZ,flagsigxfszign ? SIG_IGN : SIG_DFL);
           (void) signal(SIGVTALRM,flagsigvtalrmign ? SIG_IGN : SIG_DFL);
           (void) signal(SIGPROF,flagsigprofign ? SIG_IGN : SIG_DFL);
           (void) signal(SIGCHLD,flagsigchldign ? SIG_IGN : SIG_DFL);
           (void) signal(SIGALRM,flagsigalrmign ? SIG_IGN : SIG_DFL);
           (void) signal(SIGTERM,flagsigtermign ? SIG_IGN : SIG_DFL);

           if (setreuid(uid,uid))
            {
             perrn2("%s","attachport: fatal: cannot setreuid");
             (void) setreuid(uid,uid); exit(1);
            }

           /* Yes, Virginia, this is portable. Read execvp(3). */
           /* Annoying that there isn't a better interface, though. */
           (void) execvp(*program,program); /* must use environ! */
	   /* option to yell to remote end about failure? hmmm */
           exit(1);
          }
         else if (f == -1)
          {
           /* option to yell to remote end before closing? perhaps */
           (void) close(t); /* sigh */
           if (setreuid(uid,euid))
            {
             perrn2("%s","attachport: warning: cannot setreuid");
	     (void) setreuid(uid,euid);
            }
          }
         else
          {
           if (setreuid(uid,euid))
            {
             perrn2("%s","attachport: warning: cannot setreuid");
	     (void) setreuid(uid,euid);
            }
	   numkids++;
           (void) close(t);
          }
       (void) lseek(lockfd,(off_t) 0,0);
       (void) write(lockfd,lockbuf,lockbuflen);
       (void) flock(lockfd,LOCK_UN);
      }
    }
 /*NOTREACHED*/
}
