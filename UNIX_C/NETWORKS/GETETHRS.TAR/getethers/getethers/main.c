#ifndef lint
static char *RCSid = "$Header: /usr/src/ecn/getethers/RCS/main.c,v 1.1 91/11/27 10:56:32 davy Exp $";
#endif
/*
 * getethers - get hostname/ethernet address information for all hosts on
 *	       an ethernet.
 *
 * David A. Curry
 * Purdue University
 * Engineering Computer Network
 * davy@ecn.purdue.edu
 * November, 1991
 *
 * $Log:	main.c,v $
 * Revision 1.1  91/11/27  10:56:32  davy
 * Initial revision
 * 
 */
#include <sys/param.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <netdb.h>
#include <stdio.h>
#include "defs.h"

char	*pname;

main(argc, argv)
char **argv;
int argc;
{
	char *p;
	FILE *fp;
	u_long network;
	char *get_arp();
	struct hostent *hp;
	struct in_addr addr;
	HostInfo hosts[MAXHOST];
	char hname[64], fname[BUFSIZ];
	int lna, verbose, writefile;

	pname = *argv;
	verbose = writefile = 0;

	if (argc < 2)
		usage();

	/*
	 * Get our hostname.
	 */
	if (gethostname(hname, sizeof(hname)) < 0) {
		error("gethostname");
		exit(1);
	}

	/*
	 * Process arguments.
	 */
	while (--argc) {
		/*
		 * Option.
		 */
		if (**++argv == '-') {
			switch (*++*argv) {
			case 'v':			/* verbose	*/
				verbose = 1;
				break;
			case 'w':			/* write files	*/
				writefile = 1;
				break;
			default:
				usage();
				break;
			}

			continue;
		}

		/*
		 * Do *something*.
		 */
		if (!verbose && !writefile)
			verbose = 1;

		/*
		 * Convert the given network address to an internet
		 * address.
		 */
		network = inet_network(*argv);
		addr = inet_makeaddr(network, 0);
		bzero(hosts, sizeof(hosts));

		/*
		 * Find the ethernet interface that's on that network.
		 */
		if ((lna = check_if(addr, hosts)) < 0) {
			fprintf(stderr, "%s: this host is not on the %s net.\n",
				pname, inet_ntoa(addr));
			continue;
		}

		/*
		 * Save our hostname.  check_if() filled in our
		 * internet address and ethernet address.
		 */
		hosts[lna].hl_name = hname;

		if (verbose)
			printf("%s:\n    ", *argv);

		/*
		 * For each host...
		 */
		for (lna = MINADDR; lna <= MAXADDR; lna++) {
			if ((verbose == 1) && ((lna % 16) == 0)) {
				printf("%d...", lna);
				fflush(stdout);
			}

			/*
			 * Skip our entry; we did it already.
			 */
			if (hosts[lna].hl_name != NULL)
				continue;

			/*
			 * Build the internet address.
			 */
			addr = inet_makeaddr(network, lna);

			/*
			 * Ping it, and if it's up...
			 */
			if (ping(addr, lna)) {
				/*
				 * Get the hostname.
				 */
				hp = gethostbyaddr(&addr.s_addr,
						   sizeof(addr.s_addr),
						   AF_INET);

				/*
				 * Save the hostname.
				 */
				if (hp != NULL)
					hosts[lna].hl_name = strdup(hp->h_name);
				else
					hosts[lna].hl_name = strdup("???");

				/*
				 * Save the internet address and get the
				 * ethernet address from the arp table.
				 */
				hosts[lna].hl_inet = strdup(inet_ntoa(addr));
				hosts[lna].hl_ether = get_arp(addr);
			}
		}

		if (verbose)
			putchar('\n');

		/*
		 * If we need to write files, create the file for this
		 * network.
		 */
		if (writefile) {
			p = strrchr(*argv, '.') + 1;
			sprintf(fname, "%snet.nam", p);

			if ((fp = fopen(fname, "w")) == NULL) {
				error(fname);
				exit(1);
			}

			excelan_header(fp);
		}
			
		/*
		 * Write or print each entry.
		 */
		for (lna = MINADDR; lna <= MAXADDR; lna++) {
			if (hosts[lna].hl_name == NULL)
				continue;

			if (writefile)
				excelan_entry(&hosts[lna], fp);
				
			if (verbose) {
				printf("%s %s %s\n", hosts[lna].hl_name,
				       hosts[lna].hl_inet, hosts[lna].hl_ether);
			}

			free(hosts[lna].hl_name);
			free(hosts[lna].hl_inet);
			free(hosts[lna].hl_ether);
		}

		/*
		 * Write a footer and close the file.
		 */
		if (writefile) {
			excelan_footer(fp);
			fclose(fp);
		}
	}

	exit(0);
}

/*
 * error - perror with program name.
 */
error(s)
char *s;
{
	fprintf(stderr, "%s: ", pname);
	perror(s);
}

usage()
{
	fprintf(stderr, "Usage: %s [-v] [-w] network [network...]\n", pname);
	exit(1);
}
