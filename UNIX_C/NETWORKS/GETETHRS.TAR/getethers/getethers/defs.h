/*
 * $Header: /usr/src/ecn/getethers/RCS/defs.h,v 1.1 91/11/27 10:56:28 davy Exp $
 *
 * Definitions for getethers.
 *
 * David A. Curry
 * Purdue University
 * Engineering Computer Network
 * davy@ecn.purdue.edu
 * November, 1991
 *
 * $Log:	defs.h,v $
 * Revision 1.1  91/11/27  10:56:28  davy
 * Initial revision
 * 
 */
#define VERSION		1.0

#define MAXHOST		256		/* max number of hosts to check	*/
#define MINADDR		1		/* minimum host number		*/
#define MAXADDR		254		/* maximum host number		*/
#define MAXPING		3		/* max number of pings to send	*/
#define PACKWAIT	1		/* min time to wait for packet	*/
#define MAXPACKET	4096		/* max packet size for ping	*/
#define FILESIZE	2584		/* size of lanalyzer file	*/

/*
 * Record for a host.
 */
typedef struct {
	char	*hl_name;		/* host name			*/
	char	*hl_inet;		/* internet address		*/
	char	*hl_ether;		/* ethernet address		*/
} HostInfo;
