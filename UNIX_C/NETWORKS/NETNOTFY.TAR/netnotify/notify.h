#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define SERVICE_NAME "notify"
#define MESS_SIZE 1000

#define MACHINE_WIDE 0
#define PERSON_ONLY  1
#define WINDOWED     2
#define MACH_AND_WIN 3

typedef struct {
	char id[8];
	char mess[MESS_SIZE]; 		/* The message */
	char to[9]; 		   	/* who it's to */
	char from[9];			/* who it's from */
	char type;			/* MACHINE_WIDE, PERSON or WINDOWED */
} notify;
