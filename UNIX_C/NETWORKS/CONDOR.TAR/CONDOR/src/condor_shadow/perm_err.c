/* 
** Copyright 1986, 1987, 1988, 1989 University of Wisconsin
** 
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted,
** provided that the above copyright notice appear in all copies and that
** both that copyright notice and this permission notice appear in
** supporting documentation, and that the name of the University of
** Wisconsin not be used in advertising or publicity pertaining to
** distribution of the software without specific, written prior
** permission.  The University of Wisconsin makes no representations about
** the suitability of this software for any purpose.  It is provided "as
** is" without express or implied warranty.
** 
** THE UNIVERSITY OF WISCONSIN DISCLAIMS ALL WARRANTIES WITH REGARD TO
** THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
** FITNESS. IN NO EVENT SHALL THE UNIVERSITY OF WISCONSIN  BE LIABLE FOR
** ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
** WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
** ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
** OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
** 
** Authors:  Allan Bricker and Michael J. Litzkow,
** 	         University of Wisconsin, Computer Sciences Dept.
** 
*/ 


#include <stdio.h>
#include <varargs.h>
#include <time.h>
#include "condor_sys.h"
#include "exit.h"
#include "debug.h"


extern int	errno;
extern int	sys_nerr;
extern char	*sys_errlist[];

#ifdef LINT

/* VARARGS1 */
PERM_ERR(foo)
char	*foo;
{ printf( foo ); }
#else LINT

PERM_ERR(va_alist)
va_dcl
{
	va_list pvar;
	char *fmt;
	char buf[ BUFSIZ ];

	(void)SetSyscalls( SYS_LOCAL | SYS_UNRECORDED );
	va_start(pvar);

	fmt = va_arg(pvar, char *);

#if vax || i386 || bobcat || ibm032
	{
		FILE _strbuf;
		int *argaddr = &va_arg(pvar, int);

		_strbuf._flag = _IOWRT+_IOSTRG;
		_strbuf._ptr  = buf;
		_strbuf._cnt  = BUFSIZ;
		_doprnt( fmt, argaddr, &_strbuf );
		putc('\0', &_strbuf);
	}
#else vax || i386 || bobcat || ibm032
	vsprintf( buf, fmt, pvar );
#endif vax || i386 || bobcat || ibm032

	if( errno ) {
		dprintf( D_ALWAYS|D_NOHEADER, "ERROR: %s: %s\n",
			buf, (errno<sys_nerr) ? sys_errlist[errno] : "Unknown error" );
	} else {
		dprintf( D_ALWAYS|D_NOHEADER, "ERROR: %s\n", buf );
	}

	va_end(pvar);
}
#endif LINT
