/* 
** Copyright 1986, 1987, 1988, 1989 University of Wisconsin
** 
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted,
** provided that the above copyright notice appear in all copies and that
** both that copyright notice and this permission notice appear in
** supporting documentation, and that the name of the University of
** Wisconsin not be used in advertising or publicity pertaining to
** distribution of the software without specific, written prior
** permission.  The University of Wisconsin makes no representations about
** the suitability of this software for any purpose.  It is provided "as
** is" without express or implied warranty.
** 
** THE UNIVERSITY OF WISCONSIN DISCLAIMS ALL WARRANTIES WITH REGARD TO
** THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
** FITNESS. IN NO EVENT SHALL THE UNIVERSITY OF WISCONSIN  BE LIABLE FOR
** ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
** WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
** ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
** OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
** 
** Authors:  Allan Bricker and Michael J. Litzkow,
** 	         University of Wisconsin, Computer Sciences Dept.
** 
*/ 


#include <stdio.h>
#include <sys/types.h>
#include <sys/param.h>
#include <sys/file.h>
#include "errno.h"
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <rpc/types.h>
#include <rpc/xdr.h>
#include <varargs.h>

#include "condor_types.h"
#include "ckpt_file.h"
#include "condor_sys.h"
#include "condor_rsc.h"
#include "xdr_lib.h"
#include "trace.h"
#include "except.h"
#include "debug.h"

#ifndef LINT
static char *_FileName_ = __FILE__;		/* Used by EXCEPT (see except.h)     */
#endif LINT

extern int SyscallInProgress;
extern int CkptWanted;

#ifdef CONDOR
static XDR xdr_data;	/* Only the RSCSock will use XDR */

static XDR *xdr_syscall;

static int RSCSock;
static int ErrSock;

#define XDR_BUFSIZ	(4 * 1024)

XDR *
RSC_Init( rscsock, errsock )
int rscsock, errsock;
{
	int XDR_Read(), XDR_Write();

	xdr_syscall = &xdr_data;
	RSCSock     = rscsock;
	xdrrec_create( xdr_syscall, XDR_BUFSIZ, XDR_BUFSIZ, &RSCSock,
			XDR_Read, XDR_Write );

	ErrSock = errsock;

	return( xdr_syscall );
}
#endif CONDOR

int CurrentSysCall;

/*
**	In the REMOTE_syscall routine, a1 through a6 are the arguments
**	to the system call.  They will be cast as needed.
*/

/*VARARGS1*/
/* REMOTE_syscall( condor_sysnum, a1, a2, a3, a4, a5, a6 ) */
REMOTE_syscall(va_alist)
va_dcl
{
	va_list pvar;
	int condor_sysnum;
#ifdef CONDOR
	char ErrBuf[ BUFSIZ ];
#endif CONDOR
	int rval;
	extern errno;

	va_start(pvar);

	condor_sysnum = va_arg(pvar, int);

	CurrentSysCall = condor_sysnum;

#ifndef CONDOR
	fprintf(stderr, "REMOTE syscall: CONDOR system call is %s\n",
		CONDOR_SYSCALLNAME(condor_sysnum));

	rval = -1;
	goto RETURN;
#else CONDOR

	/*
	**	System calls which must be done locally
	*/
	switch( condor_sysnum ) {
	case PSEUDO_brk:		/* char *brk( char * )                        */
	case CONDOR_sbrk:			/* char *sbrk( int )                      */
	case CONDOR_profil:			/* profil( char *, int, int, int )        */
	case CONDOR_sigblock:		/* sigblock( int )                        */
	case CONDOR_sigpause:		/* sigpause( int )                        */
	case CONDOR_sigreturn:		/* sigreturn( struct sigcontext * )       */
	case CONDOR_sigsetmask:		/* sigsetmask( int )                      */
	case CONDOR_sigstack:		/* sigstack( struct sigstack *,
									   R struct sigstack * )              */
	case CONDOR_sigvec:			/* sigvec( int, struct sigvec *,
										  R struct sigvec * )             */
		sprintf(ErrBuf, "ERROR: %s call should be performed locally",
				CONDOR_SYSCALLNAME(condor_sysnum));
		dprintf(D_ALWAYS, "%s\n", ErrBuf);
		fprintf(stderr, "%s\n", ErrBuf);
		errno = ESYSNOTSUPP;
		rval = -1;
		goto RETURN;
	}

	SyscallInProgress = 1;

	xdr_syscall->x_op = XDR_ENCODE;
	ASSERT( xdr_int(xdr_syscall, &condor_sysnum) );

	dprintf(D_SYSCALLS, "REMOTE_syscall: calling %s\n",
			CONDOR_SYSCALLNAME(condor_sysnum));

	switch( condor_sysnum ) {
	/*
	**	System calls with no arguments
	*/
	case CONDOR_async_daemon:	/* async_daemon()                          */
	case CONDOR_fork:			/* fork()                                  */
	case CONDOR_getdtablesize:	/* getdtablesize()                         */
	case PSEUDO_getegid:	/* getegid()                                   */
	case PSEUDO_geteuid:	/* geteuid()                                   */
	case CONDOR_getgid:			/* getgid()                                */
	case CONDOR_gethostid:		/* gethostid()                             */
	case CONDOR_getpagesize:	/* getpagesize()                           */
	case CONDOR_getpid:			/* getpid()                                */
	case PSEUDO_getppid:	/* getppid()                                   */
	case CONDOR_getuid:			/* getuid()                                */
	case CONDOR_sync:			/* sync()                                  */
	case CONDOR_vhangup:		/* vhangup()                               */
		GET_RVAL(xdr_syscall);
		goto RETURN;

	/*
	**	System calls which take one integer argument
	*/
	case CONDOR__exit:			/* _exit( int status )                     */
	case CONDOR_close:			/* close( int d )                          */
	case CONDOR_dup:			/* dup( int oldd )                         */
	case CONDOR_fsync:			/* fsync( int fd )                         */
	case CONDOR_getpgrp:		/* getpgrp( int pid )                      */
	case CONDOR_nfssvc:			/* nfssvs( int ??? )                       */
	case CONDOR_reboot:			/* reboot( int howto )                     */
	case CONDOR_umask:			/* umask( int numask )                     */
	{
		int int_arg1 = va_arg(pvar, int);

		ASSERT(xdr_int(xdr_syscall, &int_arg1));
		GET_RVAL(xdr_syscall);
		goto RETURN;
	}

	/*
	**	System calls which take one long argument
	*/
	case CONDOR_sethostid:		/* sethostid( long hostid )                  */
	{
		long hostid = va_arg(pvar, long);

		ASSERT(xdr_long(xdr_syscall, &hostid));
		GET_RVAL(xdr_syscall);
		goto RETURN;
	}

	/*
	**	System calls which take two integer arguments
	*/
	case CONDOR_dup2:			/* dup2( int oldd, int newd )                */
	case CONDOR_fchmod:			/* fchmod( int fd, int mode )                */
	case CONDOR_flock:			/* flock( int fd, int operation )            */
	case CONDOR_getpriority:	/* getpriority( int which, int who )         */
	case CONDOR_kill:			/* kill( int pid, int sig )                  */
	case CONDOR_killpg:			/* killpg( int pgrp, int sig )               */
	case CONDOR_listen:			/* listen( int s, int backlog )              */
	case CONDOR_setpgrp:		/* setpgrp( int pid, int pgrp )              */
	case CONDOR_setregid:		/* setregid( int rgid, int egid )            */
	case CONDOR_setreuid:		/* setreuid( int ruid, int euid )            */
	case CONDOR_shutdown:		/* shutdown( int s, int how )                */
	{
		int int_arg1 = va_arg(pvar, int);
		int int_arg2 = va_arg(pvar, int);

		ASSERT(xdr_int(xdr_syscall, &int_arg1));
		ASSERT(xdr_int(xdr_syscall, &int_arg2));
		GET_RVAL(xdr_syscall);
		goto RETURN;
	}

	/*
	**	System calls which take an integer argument and an off_t argument
	*/
	case CONDOR_ftruncate:		/* ftruncate( int fd, off_t length )         */
	{
		int fd = va_arg(pvar, int);
		off_t length = va_arg(pvar, off_t);

		ASSERT(xdr_int(xdr_syscall, &fd));
		ASSERT(xdr_off_t(xdr_syscall, &length));
		GET_RVAL(xdr_syscall);
		goto RETURN;
	}

	/*
	**	System calls which take three integer arguments
	*/
	case CONDOR_fchown:			/* fchown( int fd, int owner, int group )    */
	case CONDOR_fcntl:			/* fcntl( int fd, int cmd, int arg )         */
	case CONDOR_setpriority:	/* setpriority( int which, int who,
																int prio )   */
	case CONDOR_socket:			/* socket( int domain, int type,
																int protocol)*/
	{
		int int_arg1 = va_arg(pvar, int);
		int int_arg2 = va_arg(pvar, int);
		int int_arg3 = va_arg(pvar, int);

		ASSERT(xdr_int(xdr_syscall, &int_arg1));
		ASSERT(xdr_int(xdr_syscall, &int_arg2));
		ASSERT(xdr_int(xdr_syscall, &int_arg3));
		GET_RVAL(xdr_syscall);
		goto RETURN;
	}

	/*
	**	System calls which take an integer argument followed by
	**	an off_t argument followed by another integer argument.
	*/
	case CONDOR_lseek:			/* lseek( int d, off_t offset, int whence )  */
	{
		int d = va_arg(pvar, int);
		off_t offset = va_arg(pvar, off_t);
		int whence = va_arg(pvar, int);

		ASSERT(xdr_int(xdr_syscall, &d));
		ASSERT(xdr_off_t(xdr_syscall, &offset));
		ASSERT(xdr_int(xdr_syscall, &whence));
		GET_RVAL(xdr_syscall);
		goto RETURN;
	}

	/*
	**	System calls which take one string argument
	*/
	case CONDOR_acct:			/* acct( char *file )                        */
	case CONDOR_chdir:			/* chdir( char *path )                       */
	case CONDOR_chroot:			/* chroot( char *dirname )                   */
	case CONDOR_rmdir:			/* rmdir( char *path )                       */
	case CONDOR_swapon:			/* swapon( char *special )                   */
	case CONDOR_unlink:			/* unlink( char *path )                      */
	case CONDOR_unmount:		/* unmount( char *name )                     */
	{
		char *str_arg1 = va_arg(pvar, char *);

		ASSERT(xdr_string(xdr_syscall, &str_arg1, MAXPATHLEN));
		GET_RVAL(xdr_syscall);
		goto RETURN;
	}

	/*
	**	System calls which take one string and one integer as arguments
	*/
	case CONDOR_access:			/* access( char *path, int mode )            */
	case CONDOR_chmod:			/* chmod( char *path, int mode )             */
	case CONDOR_creat:			/* creat( char *path, int mode )             */
	case CONDOR_mkdir:			/* mkdir( char *path, int mode )             */
	case CONDOR_setdomainname:	/* setdomainname( char *name, int namelen )  */
	case CONDOR_sethostname:	/* sethostname( char *name, int namelen )    */
	{
		char *str_arg1 = va_arg(pvar, char *);
		int int_arg2 = va_arg(pvar, int);

		ASSERT(xdr_string(xdr_syscall, &str_arg1, MAXPATHLEN));
		ASSERT(xdr_int(xdr_syscall, &int_arg2));
		GET_RVAL(xdr_syscall);
		goto RETURN;
	}

	/*
	**	System calls which take one string and one off_t as arguments
	*/
	case CONDOR_truncate:		/* truncate( char *path, off_t length )      */
	{
		char *path = va_arg(pvar, char *);
		off_t length = va_arg(pvar, off_t);

		ASSERT(xdr_string(xdr_syscall, &path, MAXPATHLEN));
		ASSERT(xdr_off_t(xdr_syscall, &length));
		GET_RVAL(xdr_syscall);
		goto RETURN;
	}

	/*
	**	System calls which take one string and two integers as arguments
	*/
	case CONDOR_chown:			/* chown( char *path, int owner, int group ) */
	case CONDOR_mknod:			/* mknod( char *path, int mode, int dev )    */
	case CONDOR_open:			/* open( char *path, int flags, int mode )   */
	{
		char *str_arg1 = va_arg(pvar, char *);
		int int_arg2 = va_arg(pvar, int);
		int int_arg3 = va_arg(pvar, int);

		ASSERT(xdr_string(xdr_syscall, &str_arg1, MAXPATHLEN));
		ASSERT(xdr_int(xdr_syscall, &int_arg2));
		ASSERT(xdr_int(xdr_syscall, &int_arg3));
		GET_RVAL(xdr_syscall);
		goto RETURN;
	}

	/*
	**	System calls which take two strings as arguments
	*/
	case CONDOR_link:			/* link( char *name1, char *name2 )          */
	case CONDOR_rename:			/* rename( char *from, char *to )            */
	case CONDOR_symlink:		/* symlink( char *name1, char *name2 )       */
	{
		char *str_arg1 = va_arg(pvar, char *);
		char *str_arg2 = va_arg(pvar, char *);

		ASSERT(xdr_string(xdr_syscall, &str_arg1, MAXPATHLEN));
		ASSERT(xdr_string(xdr_syscall, &str_arg2, MAXPATHLEN));
		GET_RVAL(xdr_syscall);
		goto RETURN;
	}

	/*
	**	Other system calls
	*/

	case CONDOR_wait:			/* wait( R union wait *status )              */
	{
		union wait *status = va_arg(pvar, union wait *);

		GET_RVAL(xdr_syscall);
		if( status != 0 ) {
			ASSERT(xdr_wait(xdr_syscall, status));
		} else {
			union wait dummy;
			ASSERT(xdr_wait(xdr_syscall, &dummy));
		}
		goto RETURN;
	}

	case PSEUDO_wait3: /* wait3( R union wait *status, int options,
					   **						struct rusage *rusage )
					   */
	{
		int xdr_rusage();
		union wait *status = va_arg(pvar, union wait *);
		int options = va_arg(pvar, int);
		struct rusage *rusage = va_arg(pvar, struct rusage *);
		
		ASSERT(xdr_int(xdr_syscall, &options));
		ASSERT(xdr_ptr(xdr_syscall, (caddr_t *) &rusage, xdr_rusage));
		GET_RVAL(xdr_syscall);
		ASSERT(xdr_wait(xdr_syscall, status));
		ASSERT(xdr_ptr(xdr_syscall, (caddr_t *) &rusage, xdr_rusage));
		goto RETURN;
	}

	case PSEUDO_reallyexit: /* reallyexit( M union wait *status,
							**			   M struct rusage *rusage )         */
	{
		union wait *status = va_arg(pvar, union wait *);
		struct rusage *rusage = va_arg(pvar, struct rusage *);

		ASSERT(xdr_wait(xdr_syscall, status));
		ASSERT(xdr_rusage(xdr_syscall, rusage));

		GET_RVAL(xdr_syscall);

		goto RETURN;
	}

	case PSEUDO_getwd: /* getwd( R char *pathname )                          */
	{
		char *pathname = va_arg(pvar, char *);
		
		GET_RVAL(xdr_syscall);
		ASSERT(xdr_string(xdr_syscall, &pathname, MAXPATHLEN));

		if( rval != 0 ) {
			rval = (int) pathname;
		}

		goto RETURN;
	}

	case CONDOR_lstat:			/* lstat( char *path, R struct stat *buf )   */
	case CONDOR_stat:			/* stat( char *path, R struct stat *buf )    */
	{
		char *path = va_arg(pvar, char *);
		struct stat *buf = va_arg(pvar, struct stat *);
		
		ASSERT(xdr_string(xdr_syscall, &path, MAXPATHLEN));
		GET_RVAL(xdr_syscall);
		ASSERT(xdr_stat(xdr_syscall, buf));
		goto RETURN;
	}

	case CONDOR_pipe:			/* pipe( int fildes[2] )                     */
	{
		int *fildes = va_arg(pvar, int *);

		GET_RVAL(xdr_syscall);
		ASSERT(xdr_int(xdr_syscall, &fildes[0]));
		ASSERT(xdr_int(xdr_syscall, &fildes[1]));
		goto RETURN;
	}

	case CONDOR_settimeofday:	/* settimeofday( struct timeval *tp,
							**				 struct timezone *tzp )
							*/
	{
		struct timeval *tp = va_arg(pvar, struct timeval *);
		struct timezone *tzp = va_arg(pvar, struct timezone *);
		int xdr_timezone();
		
		ASSERT(timeval_xdr(xdr_syscall, tp));
		ASSERT(xdr_ptr(xdr_syscall, (caddr_t *) &tzp, xdr_timezone));
		GET_RVAL(xdr_syscall);
		goto RETURN;
	}

	case CONDOR_gettimeofday:	/* gettimeofday( R struct timeval *tp,
							**				 R struct timezone *tzp )
							*/
	{
		struct timeval *tp = va_arg(pvar, struct timeval *);
		struct timezone *tzp = va_arg(pvar, struct timezone *);
		int xdr_timezone();
		
		ASSERT(xdr_ptr(xdr_syscall, (caddr_t *) &tzp, xdr_timezone));

		GET_RVAL(xdr_syscall);
		ASSERT(timeval_xdr(xdr_syscall, tp));
		ASSERT(xdr_ptr(xdr_syscall, (caddr_t *) &tzp, xdr_timezone));
		goto RETURN;
	}

	case CONDOR_getdomainname:	/* getdomainname( R char *name, int namelen )*/
	case CONDOR_gethostname:	/* gethostname( R char *name, int namelen )  */
	{
		char *name = va_arg(pvar, char *);
		int namelen = va_arg(pvar, int);
		
		ASSERT(xdr_int(xdr_syscall, &namelen));
		GET_RVAL(xdr_syscall);
		ASSERT(xdr_string(xdr_syscall, &name, namelen));
		goto RETURN;
	}
		
	case CONDOR_select:			/* select( int nfds,
							**		0/VR fd_set *readfds,
							**		0/VR fd_set *writefds,
							**		0/VR fd_set *exceptfds,
							**		0/V struct timeval *timeout )
							*/
	{
		int xdr_fdset(), timeval_xdr();
		int nfds = va_arg(pvar, int);
		fd_set *readfds = va_arg(pvar, fd_set *);
		fd_set *writefds = va_arg(pvar, fd_set *);
		fd_set *exceptfds = va_arg(pvar, fd_set *);
		struct timeval *timeout = va_arg(pvar, struct timeval *);

		ASSERT(xdr_int(xdr_syscall, &nfds));
		ASSERT(xdr_ptr(xdr_syscall, (caddr_t *) &readfds, xdr_fdset));
		ASSERT(xdr_ptr(xdr_syscall, (caddr_t *) &writefds, xdr_fdset));
		ASSERT(xdr_ptr(xdr_syscall, (caddr_t *) &exceptfds, xdr_fdset));
		ASSERT(xdr_ptr(xdr_syscall, (caddr_t *) &timeout, timeval_xdr));

		GET_RVAL(xdr_syscall);

		ASSERT(xdr_ptr(xdr_syscall, (caddr_t *) &readfds, xdr_fdset));
		ASSERT(xdr_ptr(xdr_syscall, (caddr_t *) &writefds, xdr_fdset));
		ASSERT(xdr_ptr(xdr_syscall, (caddr_t *) &exceptfds, xdr_fdset));
		ASSERT(xdr_ptr(xdr_syscall, (caddr_t *) &timeout, timeval_xdr));

		goto RETURN;
	}

	case CONDOR_setgroups:		/* setgroups( int ngroups, M int *gidset )   */
	{
		int ngroups = va_arg(pvar, int);
		int *gidset = va_arg(pvar, int *);

		ASSERT(xdr_array(xdr_syscall, &gidset, &ngroups, NGROUPS, sizeof(int), xdr_int));
		GET_RVAL(xdr_syscall);
		goto RETURN;
	}

	case CONDOR_setitimer:		/* setitimer( int which,
							**			M struct itimerval *value,
							**		  R/0 struct itimerval *ovalue )
							*/
	{
		int which = va_arg(pvar, int);
		struct itimerval *value = va_arg(pvar, struct itimerval *);
		struct itimerval *ovalue = va_arg(pvar, struct itimerval *);
		
		ASSERT(xdr_int(xdr_syscall, &which));
		ASSERT(xdr_itimerval(xdr_syscall, value));
		ASSERT(xdr_ptr(xdr_syscall, (caddr_t *) &ovalue, timeval_xdr));

		GET_RVAL(xdr_syscall);

		ASSERT(xdr_ptr(xdr_syscall, (caddr_t *) &ovalue, timeval_xdr));
		goto RETURN;
	}

	case CONDOR_setrlimit:		/* setrlimit( int resource,
							**			M struct rlimit *rlp )
							*/
	{
		int resource = va_arg(pvar, int);
		struct rlimit *rlp = va_arg(pvar, struct rlimit *);
		
		ASSERT(xdr_int(xdr_syscall, &resource));
		ASSERT(xdr_rlimit(xdr_syscall, rlp));
		GET_RVAL(xdr_syscall);
		goto RETURN;
	}

	case CONDOR_getdirentries:	/* getdirentries( int fd,
							**				R char *buf,
							**				  int nbytes,
							**				R off_t *basep )
							*/
	{
		int fd = va_arg(pvar, int);
		char *buf = va_arg(pvar, char *);
		int nbytes = va_arg(pvar, int);
		long *basep = va_arg(pvar, long *);

		ASSERT(xdr_int(xdr_syscall, &fd));
		ASSERT(xdr_int(xdr_syscall, &nbytes));
		GET_RVAL(xdr_syscall);

		ASSERT(xdr_direntries(xdr_syscall, buf, rval));
		ASSERT(xdr_off_t(xdr_syscall, basep));

		goto RETURN;
	}

	case CONDOR_getgroups:		/* getgroups( int gidsetlen, R int *gidset ) */
	{
		int gidsetlen = va_arg(pvar, int);
		int *gidset = va_arg(pvar, int *);
		register int i;

		ASSERT(xdr_int(xdr_syscall, &gidsetlen));
		GET_RVAL(xdr_syscall);

		for( i = 0; i < rval; i++ ) {
			ASSERT(xdr_int(xdr_syscall, &gidset[i]));
		}
		goto RETURN;
	}

	case CONDOR_getitimer:		/* getitimer( int which,
							**			R struct itimerval *value )
							*/
	{
		int which = va_arg(pvar, int);
		struct itimerval *value = va_arg(pvar, struct itimerval *);
		
		ASSERT(xdr_int(xdr_syscall, &which));
		GET_RVAL(xdr_syscall);
		ASSERT(xdr_itimerval(xdr_syscall, value));
		goto RETURN;
	}

	case CONDOR_getrlimit:		/* getrlimit( int resource,
							**			R struct rlimit *rlp )
							*/
	{
		int resource = va_arg(pvar, int);
		struct rlimit *rlp = va_arg(pvar, struct rlimit *);
		
		ASSERT(xdr_int(xdr_syscall, &resource));
		GET_RVAL(xdr_syscall);
		ASSERT(xdr_rlimit(xdr_syscall, rlp));
		goto RETURN;
	}

	case CONDOR_getrusage:		/* getrusage( int who,
							**			R struct rusage *rusage )
							*/
	{
		int who = va_arg(pvar, int);
		struct rusage *rusage = va_arg(pvar, struct rusage *);

		
		ASSERT(xdr_int(xdr_syscall, &who));
		GET_RVAL(xdr_syscall);
		ASSERT(xdr_rusage(xdr_syscall, rusage));
		goto RETURN;
	}

	case CONDOR_fstat:			/* fstat( int fd, R struct stat *buf )       */
	{
		int fd = va_arg(pvar, int);
		struct stat *buf = va_arg(pvar, struct stat *);
		
		ASSERT(xdr_int(xdr_syscall, &fd));
		GET_RVAL(xdr_syscall);
		ASSERT(xdr_stat(xdr_syscall, buf));
		goto RETURN;
	}

	case CONDOR_fstatfs:		/* fstatfs( int fd, struct statfs *buf )     */
	{
		int fd = va_arg(pvar, int);
		struct statfs *buf = va_arg(pvar, struct statfs *);
		
		ASSERT(xdr_int(xdr_syscall, &fd));
		GET_RVAL(xdr_syscall);
		ASSERT(xdr_statfs(xdr_syscall, buf));
		goto RETURN;
	}

	case CONDOR_utimes:			/* utimes( char *file, M struct timeval *tvp)*/
	{
		char *file = va_arg(pvar, char *);
		struct timeval *tvp = va_arg(pvar, struct timeval *);

		ASSERT(xdr_string(xdr_syscall, &file, MAXPATHLEN));
		ASSERT(timeval_xdr(xdr_syscall, &tvp[0]));
		ASSERT(timeval_xdr(xdr_syscall, &tvp[1]));

		GET_RVAL(xdr_syscall);
		goto RETURN;
	}

	case CONDOR_readlink:		/* readlink( char *path, char *buf,
																int bufsiz ) */
	{
		char *path = va_arg(pvar, char *);
		char *buf = va_arg(pvar, char *);
		int bufsiz = va_arg(pvar, int);

		ASSERT(xdr_string(xdr_syscall, &path, MAXPATHLEN));
		ASSERT(xdr_int(xdr_syscall, &bufsiz));
		GET_RVAL(xdr_syscall);
		ASSERT(xdr_string(xdr_syscall, &buf, bufsiz));
		goto RETURN;
	}

	case CONDOR_adjtime:		/* adjtime( M struct timeval *delta,
							**		  R/0 struct timeval *olddelta )
							*/
	{
		struct timeval *delta = va_arg(pvar, struct timeval *);
		struct timeval *olddelta = va_arg(pvar, struct timeval *);

		ASSERT(timeval_xdr(xdr_syscall, delta));
		ASSERT(xdr_ptr(xdr_syscall, (caddr_t *) &olddelta, timeval_xdr));

		GET_RVAL(xdr_syscall);

		ASSERT(xdr_ptr(xdr_syscall, (caddr_t *) &olddelta, timeval_xdr));

		goto RETURN;
	}

	case CONDOR_statfs:			/* statfs( char *path, R struct statfs *buf )*/
	{
		char *path = va_arg(pvar, char *);
		struct statfs *buf = va_arg(pvar, struct statfs *);
		
		ASSERT(xdr_string(xdr_syscall, &path, MAXPATHLEN));
		GET_RVAL(xdr_syscall);
		ASSERT(xdr_statfs(xdr_syscall, buf));
		goto RETURN;
	}

	case CONDOR_write:			/* write( int d, M char *buf, int nbytes )   */
	{
		int d = va_arg(pvar, int);
		char *buf = va_arg(pvar, char *);
		int nbytes = va_arg(pvar, int);

		ASSERT(xdr_int(xdr_syscall, &d));
		ASSERT(xdr_int(xdr_syscall, &nbytes));
		ASSERT(xdr_bytes(xdr_syscall, (caddr_t *) &buf, &nbytes, nbytes));

		GET_RVAL(xdr_syscall);
		goto RETURN;
	}

	case CONDOR_read:			/* write( int d, R char *buf, int nbytes )   */
	{
		int d = va_arg(pvar, int);
		char *buf = va_arg(pvar, char *);
		int nbytes = va_arg(pvar, int);

		ASSERT(xdr_int(xdr_syscall, &d));
		ASSERT(xdr_int(xdr_syscall, &nbytes));

		GET_RVAL(xdr_syscall);

		ASSERT(xdr_bytes(xdr_syscall, (caddr_t *) &buf, &nbytes, nbytes));
		goto RETURN;
	}

	case CONDOR_ioctl:			/* ioctl( int d, u_long request, char *argp )*/
	{
		int d = va_arg(pvar, int);
		u_long request = va_arg(pvar, u_long);
		char *argp = va_arg(pvar, char *);

		ASSERT(xdr_int(xdr_syscall, &d));
		ASSERT(xdr_u_long(xdr_syscall, &request));

		if( request & IOC_IN ) {
			ASSERT(xdr_opaque(xdr_syscall, argp, request & IOCPARM_MASK));
		}

		GET_RVAL(xdr_syscall);

		if( request & IOC_OUT ) {
			ASSERT(xdr_opaque(xdr_syscall, argp, request & IOCPARM_MASK));
		}
	}

	case CONDOR_writev:			/* writev( int d, struct iovec *iov,
																int iovcnt ) */
	case CONDOR_readv:			/* readv( int, VR iov *, int )               */

	case CONDOR_ptrace:			/* ptrace( int, int, VR int *, int           */
	case CONDOR_quotactl:		/* quotaactl( int, str, int, VRU caddr_t )   */
	case CONDOR_execv:			/* execv( str, M str[] )                     */
	case CONDOR_execve:			/* execve( str, M str[], M str[] )           */

	case CONDOR_send:			/* send( int, M caddr_t, int, int )          */
	case CONDOR_sendto:			/* sendto( int, M caddr_t, int, int,
										M sockaddr *, int                    */
	case CONDOR_sendmsg:		/* sendmsg( int, V msghdr[], int )           */

	case CONDOR_recv:			/* recv( int, R caddr_t, int, int )          */
	case CONDOR_recvfrom:		/* recvfrom( int, R caddr_t, int, int,
											0/R sockaddr *, VR int * )       */
	case CONDOR_recvmsg:		/* recvmsg( int, VR msghdr[], int )          */

	case CONDOR_setsockopt:		/* setsockopt( int, int, int, M caddr_t,int) */
	case CONDOR_getsockopt:		/* getsockopt( int, int, int,
									R caddr_t, VR int * )                    */
	case CONDOR_socketpair:		/* socketpair( int, int, int, R int[2] )     */
	case CONDOR_bind:			/* bind( int, sockaddr *, int )              */
	case CONDOR_connect:		/* connect( int, sockaddr *, int )           */
	case CONDOR_mount:			/* mount( int, str, int,
										MU caddr_t )                         */
	case CONDOR_accept:			/* accept( int, R sockaddr *, VR int * )     */
	case CONDOR_getsockname:	/* getsockname( int, R sockaddr *, VR int * )*/

	case CONDOR_getpeername:	/* getpeername( int, R sockaddr *, VR int * )*/


	/*
	**	System calls with (as yet) unknown arguments
	*/
	case CONDOR_exportfs:
	case CONDOR_getdopt:
	case CONDOR_getfh:
	case CONDOR_madvise:
	case CONDOR_mincore:
	case CONDOR_mmap:
	case CONDOR_mprotect:
	case CONDOR_mremap:
	case CONDOR_munmap:
	case CONDOR_setdopt:
	case CONDOR_sstk:
		sprintf(ErrBuf, "ERROR: %s is a currently unsupported system call\n",
			CONDOR_SYSCALLNAME(condor_sysnum));
		dprintf(D_ALWAYS, "%s\n", ErrBuf);
		fprintf(stderr, "%s\n", ErrBuf);
		errno = ESYSNOTSUPP;
		rval = -1;
		goto RETURN;

	default:
		sprintf(ErrBuf, "ERROR: %d is an unknown system call number\n",
			condor_sysnum);
		dprintf(D_ALWAYS, "%s\n", ErrBuf);
		fprintf(stderr, "%s\n", ErrBuf);
		errno = ESYSNOTSUPP;
		rval = -1;
		goto RETURN;
	}
#endif ! CONDOR

RETURN:
	va_end(pvar);

	SyscallInProgress = 0;
	if( CkptWanted ) {
		dprintf(D_ALWAYS, "REMOTE_syscall: [%s] completed, checkpoint wanted\n",
				CONDOR_SYSCALLNAME(CurrentSysCall));
		ckpt();
	}

	return( rval );
}

#ifdef CONDOR

static
XDR_Read( iohandle, buf, len )
int *iohandle;
char *buf;
u_int len;
{
	register int scm = SetSyscalls( SYS_LOCAL | SYS_UNRECORDED );
	int cnt;

	dprintf(D_XDR, "XDR_Read: about to read(%d, 0x%x, %d)\n",
			*iohandle, buf, len);

	cnt = read(*iohandle, buf, len);
	if( cnt == 0 ) {
		dprintf(D_XDR, "XDR_Read: cnt was zero, returning -1\n");
		cnt = -1;
	}

	dprintf(D_XDR, "XDR_Read: cnt = %d\n", cnt);

	(void) SetSyscalls( scm );

	return( cnt );
}

static
XDR_Write( iohandle, buf, len )
int *iohandle;
char *buf;
u_int len;
{
	register int scm = SetSyscalls( SYS_LOCAL | SYS_UNRECORDED );
	int cnt;

	dprintf(D_XDR, "XDR_Write: about to write(%d, 0x%x, %d)\n",
			*iohandle, buf, len);

	cnt = write( *iohandle, buf, len );

	dprintf(D_XDR, "XDR_Write: cnt = %d\n", cnt);

	if( cnt != len ) {
		EXCEPT("write(%d, 0x%x, %d) returned %d", *iohandle, buf, len, cnt);
	}

	(void) SetSyscalls( scm );

	return( cnt );
}

#endif CONDOR
