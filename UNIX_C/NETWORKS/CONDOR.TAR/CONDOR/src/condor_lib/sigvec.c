/* 
** Copyright 1986, 1987, 1988, 1989 University of Wisconsin
** 
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted,
** provided that the above copyright notice appear in all copies and that
** both that copyright notice and this permission notice appear in
** supporting documentation, and that the name of the University of
** Wisconsin not be used in advertising or publicity pertaining to
** distribution of the software without specific, written prior
** permission.  The University of Wisconsin makes no representations about
** the suitability of this software for any purpose.  It is provided "as
** is" without express or implied warranty.
** 
** THE UNIVERSITY OF WISCONSIN DISCLAIMS ALL WARRANTIES WITH REGARD TO
** THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
** FITNESS. IN NO EVENT SHALL THE UNIVERSITY OF WISCONSIN  BE LIABLE FOR
** ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
** WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
** ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
** OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
** 
** Authors:  Allan Bricker and Michael J. Litzkow,
** 	         University of Wisconsin, Computer Sciences Dept.
** 
*/ 


#include "condor_sys.h"
#include <signal.h>

sigvec( sig, vec, ovec )
int sig;
struct sigvec *vec, *ovec;
{
	int rval;

	if( Syscalls & SYS_LOCAL ) {
#ifdef notdef
#ifdef sequent
		int _sigcode();
		rval = syscall( SYS_sigvec, sig, vec, ovec, _sigcode );
#else sequent
		rval = syscall( SYS_sigvec, sig, vec, ovec );
#endif sequent
#else notdef
		rval = SIGVEC( sig, vec, ovec );
#endif notdef
	} else {
		rval = REMOTE_syscall( CONDOR_sigvec, sig, vec, ovec );
	}

	return( rval );
}

#ifdef notdef

#ifdef sequent
;asm("		.globl	__sigcode");
;asm("		.text");
;asm("		.align	2");
;asm("__sigcode:");
;asm("		cld");
;asm("		call	*%eax");
;asm("		addl	$8, %esp");
;asm("		movl	$[97|[0x1<<16]], %eax");
;asm("		int		$40");
;asm("		popfl");
;asm("		ret");
#endif sequent

#endif notdef
