/*
 * lastlog.c - get time and location of last login
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: lastlog.c,v 3.0 90/07/06 13:11:14 budd Rel $";
# endif /* lint not defined */

# include "finger.h"
# ifdef LASTLOG
# include <sys/types.h>
# include <ctype.h>
# include <lastlog.h>

# ifndef LLPATH
# define LLPATH "/usr/adm/lastlog"
# endif /* LLPATH not defined */

LOCAL llfile = -1;

GLOBAL void llopen() {
    if( llfile < 0 )
	llfile = open(LLPATH, 0);
    else
	lseek( llfile, 0L, 0 );
} /* llopen */

GLOBAL void llclose() {
    if( llfile >= 0 )
	close( llfile );
} /* llclose */

GLOBAL BOOL lltime( uid, location, time, host )
short uid;
char *location;
time_t *time;
int *host;
{
    struct lastlog ll;

    if( llfile < 0 )
	return( FALSE );

    lseek( llfile, uid * sizeof( ll ), 0 );
    if( read(llfile, &ll, sizeof( ll ) ) != sizeof( ll ) )
	return( FALSE );

    *time = ll.ll_time;			/* return time of login */
    if( ll.ll_host[0] != EOS ) {
	*host = TRUE;
	strzcpy(location, ll.ll_host,
		sizeof( ll.ll_host ) );	/* copy fixed len */

	if( isdigit(*location) )
	    checkhost( location, sizeof( location ) ); /* hack octets */
	undomain( location, 0 ); 	/* remove domains, but not prefixes */
	HZUP( location );		/* upper caseify */
    }
    else {
	*host = FALSE;
	strzcpy(location, ll.ll_line, sizeof( ll.ll_line ) );
    }
    return( TRUE );
} /* lltime */
# endif /* LASTLOG defined */
/*
 * Local variables:
 * comment-column: 40
 * End:
 */
