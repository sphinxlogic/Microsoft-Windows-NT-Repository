/*
 * mywhoami.c -- whoami for makefile/make-version on USG systems
 *
 * Copyright (C) 1989, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: mywhoami.c,v 3.0 90/07/06 13:11:22 budd Rel $";
static char Copyright[] = "Copyright (C) 1986, 1990  Philip L. Budne";
# endif /* lint not defined */

# include <stdio.h>
# include <pwd.h>

extern char *getenv();
extern struct passwd *getpwuid();	/* USG pwd.h */

# define IFENV(v) if( (e = getenv(v)) != NULL ) puts( e )

int
main() {
    struct passwd *pw;
    char *e;

    if( (pw = getpwuid( getuid())) != NULL )
	puts( pw->pw_name );
    else IFENV( "USER" );
    else IFENV( "LOGNAME" );
    else
	puts("???");
    return( 0 );			/* be ANSI */
} /* main */

