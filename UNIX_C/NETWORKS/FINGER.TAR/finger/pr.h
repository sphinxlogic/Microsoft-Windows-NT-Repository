/*
 * pr.h -- process table structure for finger
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# define PR_RCSID "$Id: pr.h,v 3.0 90/07/06 13:11:33 budd Rel $"

enum sig { S_DEFAULT=1, S_IGNORE, S_CATCH, S_HOLD };
# define SIGNAME "?DICH?"

struct pr {
    /* from proc struct */
    short pr_pid;			/* proc.p_pid   process pid */
    short pr_ppid;			/* proc.p_ppid  parent pid */
    short pr_pgrp;			/* proc.p_pgrp  pgrp leader pid */
    short pr_uid;			/* proc.p_uid   userid */
    char pr_flag;			/* proc.p_flag  process flags (SWAP) */
    caddr_t pr_wchan;			/* proc.p_wchan wait addr */
    char pr_stat;			/* proc.p_stat  state 1..6 */

    /* from user struct */
    dev_t pr_ttyd;			/* user.u_ttyd  tty device of process */
    char pr_cmd[15];			/* user.u_comm  command name */
# ifdef SHORT_TTYP
    short *pr_ttyp;			/* user.u_ttyp  ptr to tpg in stream */
# else  /* SHORT_TTYP not defined */
    struct tty *pr_ttyp;		/* user.u_ttyp  pointer to tty str */
# endif /* SHORT_TTYP not defined */
    enum sig pr_intr,			/* state of SIGINT */
	     pr_quit,			/* state of SIGQUIT */
	     pr_hup;			/* state of SIGHUP */

    /* derived */
    SIGNED long pr_weight;		/* heuristic display weight */
};

void dumppr();
/*
 * Local variables:
 * comment-column: 40
 * End:
 */
