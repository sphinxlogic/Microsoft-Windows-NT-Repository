/*
 * getut.c -- read utmp file
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: getut.c,v 3.0 90/07/06 13:10:58 budd Rel $";
# endif /* lint not defined */

# include "finger.h"
# ifdef USG				/* UTMP_NEEDS_TIME_T? */
# include <sys/types.h>			/* for time_t */
# endif /* USG defined */
# include <utmp.h>
# include <stdio.h>

# ifdef USER_PROCESS
# include <errno.h>
# endif /* USER_PROCESS defined */

# define UTFILE "/etc/utmp"
# define MAXNAME 100

LOCAL char utfile[MAXNAME] = UTFILE;
LOCAL FILE *f = NULL;

void setutent() {
    if( f == NULL )
	f = fopen( utfile, "r" );
    else
	rewind( f );
} /* setutent */

void endutent() {
    if( f != NULL )
	fclose( f );
} /* endutent */

void utmpname( file )
char *file;
{
    endutent();
    strcpy(utfile, file);
} /* utmpname */

struct utmp *getutent() {
    static struct utmp ut;
 
    if( f == NULL ) {
	setutent();
	if( f == NULL )
	    return( NULL );
    }

    while( fread(&ut, sizeof( ut ), 1, f) == 1 ) {
# ifdef USER_PROCESS
	if( ut.ut_type == USER_PROCESS
	   && (kill( ut.ut_pid, 0 ) == 0 || errno == EPERM ) )
# endif /* USER_PROCESS defined */
	    return( &ut );
    }
    rewind( f );
    return( NULL );
} /* getutent */

/*
 *	not implemented:
 *
 *	void pututline( struct utmp *u );
 *		(uses direct write(2))
 *	struct utmp *getutline( struct utmp *line )
 *		find entry with matching ut->line
 *	struct utmp *getutid( struct utmp *id )
 *		find entry with matching ut->type (!!)
 *		(RUN_LVL, BOOT_TIME, OLD_TIME, NEW_TIME)
 *		if one of (INIT_PROCESS, LOGIN_PROCESS, USER_PROCESS
 *		or DEAD_PROCESS) ut_id must mach also.
 */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
