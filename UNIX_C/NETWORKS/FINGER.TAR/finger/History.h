/*-*-text-*-*/
/*
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# define HISTORY_RCSID "$Id: History.h,v 3.0 90/07/06 13:09:46 budd Rel $"

# ifdef __GNUC__x		/* works in GCC 1.20 and up */
# define B(x)			/* RMS does not believe in regression tests! */
# else  /* __GNUC__x not defined */
# define B(x) : x
# endif /* __GNUC__x not defined */

struct _JBVER {
    unsigned who   B(3);	/* 0=development group, 1=other digital */
				/* 2,3,4 customer; 5,6,7 customer's user */
    unsigned major B(9);
    unsigned minor B(6);
# if 1
    unsigned edit  B(18);
# else  /* not 1 */
    unsigned flag  B(1);
    unsigned edit  B(17);
# endif /* not 1 */
};

/*
 * For the uninformed:
 *
 * This is the format TOPS-10 uses to store version numbers.  Word
 * 0137 in low core -- The JOB DATa area (JOBDAT) is called .JBVER
 *
 * TOPS-20 uses it too, with minor perversions: major/minor edits are
 * displayed as major.minor (5.1 rather than 5A) If the high order bit
 * of edit is set (0400000) the low 17 bits are printed in decimal.
 *
 */

/****************************************************************

	Pre-History:

	Nov 85 -- Work began with code that is now maketree and dofinger.
		  Just printed current users nicely.
	Dec 85 -- enhanced ttylocs.
	Jan 86 -- Command line parsing added.

100	Wed May 21, 1986	Phil
	Start History file.
	Allow slash switches appended directly to unames.
	Create routine doswitch().
	Files:
		args.c

101	Wed May 28, 1986	Phil
	Display last login host uppercase.
	Remove ".arpa" in undomain.
	Files:
		lastlog.c	undomain.c

102	Thurs May 28, 1986	Phil
	Wrote my own getutmp().
	Flush SYS V utmp.c
	Files:
		getut.c

103	Thurs May 28, 1986	Phil
	Massive cleanup.  Add copyrights,
	make sure to use finger.h
	Display [n.n.n.n]
	Files:
		doremote.c ....

**** given to sundar@mit-hermes ****

104	July 16, 1986		BZS
	Add SYSLOG option to fingerd.c

105	August 12, 1986		Phil
	Add ttyplace, ttyrandom options to ttyask.c

106	August 12, 1986		Phil
	Add -j option to force whoj output
	Files:
		args.c args.h

107	Weds Sept 3, 1986	Phil
	Merge in stuff for Umax (Encore Multimax 4.2) [under ifdef Umax]
	Files:
		luser.h	getttyloc.c output.c
		getcommand.c readpr.c fingerd.c

108	Sat Sept 27, 1986	Phil
	Remove "On since" since it only applies to one login.
	Files:
		whois.c

109	Thus Oct 2, 1986	Phil
	Add hackery for "consdev" on sun. Does the right thing when
	console is really a printer on ttya, but not when workstation
	with a console window.
	Files:
		readpr.c getcommand.c

110	Thus Oct 2, 1986	Phil
	Add NETLOC and OTTYLOC conditionals.
	Files:
		getttyloc.c locname.c

111	Fri Oct 3, 1986		Phil
	Add (/L) sw_location -- ignore user ttyloc
	Files:
		getttyloc.c args.h args.c

112	Mon Oct 6, 1986		Phil
	Fix undomain
	File:
		undomain.c

113	Mon Oct 6, 1986		Phil
	Merge in working inq_stats code for Umax (encore)
	Files:
		undomain.c

114	Weds Oct 22, 1986	Phil
	Make getcommand() return struct pr.
	Print flag for suid programs.
	Make room for inquire group.
	Split off whoj.c and finger.c from output.c.
	Add ifdef lint around copyright in finger.h.
	Create inquire.c hook into inquire/holmes.
	Add fields in person struct, move p_Rc into p_flags.
	Files:
		whoj.c finger.c output.c finger.h inquire.c getperson.c

115	Wednesday October 28, 1986	Phil
	Create code to use mmap to read process table, and upage
	pagemaps.  Code to read actual upage(s) does not work.  (MAP
	UMAP1 UMAP2 in map.h).  Performance win is barely noticeable
	Create names.c syms.h info.h. Read namelist into info struct
	and save as /etc/saved-finger-namelist.  BIG win, bigger than
	any crock in readpr.
	Files:
		readpr.c names.c syms.h info.h map.h

116	Thursday October 29, 1986	Phil
	create ttycycle (ttyask -c[time]).  Cycles thru ttylplaces
	sleeping for time seconds.
	Files:
		ttyask.c

**** second version given to sundar@hermes ****

117	Saturday November 1, 1986	Phil
	Split readpr.c into kmem.c, readpr.c, ustruct.c
	Split pr.h into pr.h and kmem.h
	Files:
		getcommand.c readpr.c pr.h

118	Sunday November 1, 1986		Phil
	Add optional ttyrandom cycling (ttyask -r<time>), -b(ackground).
	Add savewho/checkwho to kill self when parent goes away.
	File:
		ttyask.c

119	Monday November 3, 1986		Phil
	Append suid character to program name.
	Start playing with new select stuff (+tty .)
	Files:
		finger.c select.h select.c args.c

120	Sunday, November 9, 1986	Phil
	Make ttyloc check tty ownership, remove fchown().
	Files:
		ttyloc.c

121	Monday, November 10, 1986	Phil
	Don't decr todo counter unless hit has no person entry in pwtree.
	Files:
		getperson.c

122	Monday, November 10, 1986	Phil
	Implement blankline(), better defaults for empty fields in finger.
	Files:
		getperson.c doremote.c mcheck.c
		finger.c inquire.c output.c


123	Wednesday, November 12, 1986	Phil
	Do NETLOC for annexes too!  Make undomain() optionally
	remove prefixes to 100% domain matches. Put it 'make depend'
	Files:
		undomain.c prefixes.h getttyloc.c lastlog.c whoj.c
		Makefile

124	Tuesday, December 2, 1986	Phil
	zero p_count in makeperson. Warn about unknown switches.
	Files:
		getperson.c args.c

125	Friday, January 1, 1987		Phil
	Clean up NFILE reading, rejection.
	Have ttyask use optarg(3), add -t time flag (as opposed
	too -c [time] and -r [time]), use as timeout in ttyask too.
	Files:
		names.c ttyask.c

126	Monday, January 12, 1987	Phil
	Add read_vmunix, used to find _version in /vmunix and
	fill in info_verstr when reading nlist.
	Files:
		names.c read_vmunix.c

127	Monday, January 12, 1987	Phil
	Add 4.3 stuff under BSD4_3; tty.h wants ioctl.h
	tty group/mesg stuff.
	Files:
		getcommand.c output.c

128	Friday, January 16, 1987	Phil
	If stdin is not a tty, act as if /berk.
	Fix doswitch() to accept multi letter switch names.
	File:
		args.c

129	Sunday, January 25, 1987	Phil
	Print /etc/nologin after herald.
	File:
		fingerd.c

130	Feb 26, 1987	Phil
	Do special ttyloc display for xterms.
	File:
		getttyloc.c

131	Friday, March 13, 1987	Phil
	Create netfinger variable, use in outchar to output <CR><LF>
	and for /berk madness (see [128])
	Files:
		args.c output.c


132	Sunday, March 15, 1987	Phil
	Display times more than a day, and less than 10
	using hours, not fractions of days. Handle weeks ...
	File:
		output.c

133	Weds, April 22, 1987	Phil
	Don't set same is person && u->u_person are both NULL
	File:
		finger.c

134	Sat, May 23, 1987	Phil
	Clean up for namelist read/write. Add AUTONLIST.
	Add fchown, fchmod in write.  Add ifdef Umax to read_vmunix.
	Files:
		names.c read_vmunix.c

135	Mon, May 25, 1987	Phil
	Add maddr() for mailing address.
	Display '.' for biff, ',' for hungry, ';' for hungry + biff.
	Files:
		person.h finger.c mcheck.c getperson.c whois.c

136	Tues, May 26, 1987	Phil
	Never display interval with weeks, and zero days.
	File:
		output.c

137	Friday May 29 and (cleanup) Monday June 29, 1987  Phil
	(My father died June 10th) Use inquire for user lookup.  Use
	getpwbynam in pwtree if GETPWNAM_SLOW is not defined.
	makeperson and insert_winner take struct info pointer if
	INQUIRE is defined. Can now display a person with no password
	entry (but still has inquire entry!!)
	Files:
		getperson.c select.c inquire.c finger.c

140	Saturday July 11, 1987		Phil
	Check if last element in second strncmp in do_ttyplace.
	File:
		ttyask.c

141	Saturday July 11, 1987		Phil
	Change History into History.c. Create make-version, BUILD,
	and version.c (reset BUILD when History is modified?)
	Files:
		make-version History.c version.c Makefile

142	Saturday July 11, 1987		Phil
	Implement full switch names. Add switch.h
	Only say one of forwarded and no mailbox.
	Add UNPREIX_NODOMAINS and unprefix() [helful for Xhost:display]
	Add /version
	create ttyloc.1
	Files:
		args.c switch.h mcheck.c undomain.c ttyloc.1

143	Sunday July 12, 1987		Phil
	Implement tty selectors. +name. checks for implied leading "tty"
	Add tsel.h
	Files:
		getent.c finger.c tsel.h

144	Sunday July 12, 1987		Phil
	Add CONC macro.  Give SYM two arguments, first string, second member.
	Put longversion[] into saved nlist file.
	Files:
		syms.h info.h names.c finger.h

145	Monday July 13, 1987		Phil
	Add /help, values on switches.
	Files:
		switch.h args.h

146	Tuesday July 14, 1987	2am	Phil	-- Bastile Day!!
	Add /follow, move savestr to string.c.
	Add malloc and savestr defs to finger.h
	Add <strings.h> in many places.
	Files:
		switch.h args.h select.c mcheck.c finger.h
		ttyloc.c fingerd.c whois.c getperson.c

147	Tuesday July 14, 1987	4pm	Phil	-- Bastile Day!!
	Add readnewttyloc() new format ttyloc file (has short, line type)
	Files:
		getttyloc.c readttylocfile.c readttylocfile.h

150	Thursday July 16, 1987		Phil
	Add getttyents() -- read 4.3 /etc/ttys file as last resort
	for tty locations.
	Files:
		getttyloc.c readttylocfile.c

151	Thursday July 16, 1987		Phil
	Create getttytype for ttyask-ing.  Create skip.c. use in readttylocfile
	move findttyloc into readttylocfile.c make nttyloc static there.
	Files:
		getttytype.c skip.c readttylocfile.c getttyloc.c Makefile

152	Friday July 17, 1987	2am	Phil
	Add sw_fields, /fields, set_fields (no action yet)
	Use binary search in findttyloc
	Files:
		args.c args.h switch.h readttylocfile.c

153	Friday July 17, 1987	5pm	Phil
	Create switch.c move doswitch and other switchiness there.
	Use skipwhite and skipblack all over.
	Files:
		args.c switch.c Makefile getperson.c select.c ttyask.c

154	Wednesday July 22, 1987	4am	Phil
	Clean up readpr, make signal state an enum. Look at it in getcommand.
	Files:
		readpr.c pr.h getcommand.c

155	Wednesday July 22, 1987	5am	Phil
	Add ttystate, TTYSTATE
	Files:
		syms.h finger.c

156	Thursday July 23, 1987	Phil
	Add /debug sw_debug DEBUGSW
	Files:
		args.h switch.h switch.c Makefile getcommand.c

157	Thursday July 23, 1987	Phil
	Check for backgrounded forks which have group membership
	by being disowned and writing to tty. Add II and IID macros.
	File:
		getcommand.c

160	Saturday July 25, 1987	Phil
	rename /save to /read. Add /nosave.  Force on when 'xf'
	Files:
		args.c args.h switch.h names.c

161	Thursday July 30, 1987	Phil
	Set width to PLUS_INF if netfinger
	Files:
		output.c

162	Friday July 31, 1987	Phil
	Create flags.h args.m4 flags struct.  Save Flags before
	smashing for /berk.
	Files:
		flags.h args.m4 Makefile args.c

163	Saturday August 1, 1987	Phil
	Create local.h, removed prefixes.h.  sed UMAX to Umax.
	Move Makefile work to ymakefile
	Files:
		local.h Makefile ymakefile

164	Monday August 3, 1987	Phil
	Remove tiresome fencepost errors.
	Files:
		getcommand.c read_vmunix.c names.c

165	Saturday August 8, 1987	Phil
	syslog argv passed to finger.
	File:
		fingerd.c

166	Wednesday Sept 2, 1987	Phil
	add unswitch -- detect switches on . and +
	File:
		args.c

167	Thursday Sept 17, 1987	Phil
	add else after doswitch in finger().
	add ttystate_t tiwait towait
	Files:
		args.c pr.h getcommand.c readpr.c

170	Thursday October 29, 1987	Phil
	Flush zombies in getcommand()
	Files:
		getcommand.c

171	Tuesday November 10, 1987	Phil
	Make compile on ULTRIX
	Split BSD4_3 defines into TTY_GROUP TTYENT TTY_REQUIRES_IOCTL
	Files:
		fingerd.c	getttytype.c	getttyloc	readpr.c
		getcommand.c	output.c	undomain.c	readttylocfile.c

172	Friday November 13, 1987	Phil
	Move ttystate_t into ttystate.h (for Umax)
	Update for Umax 3.1.0; no more libu.a, no more statistics typedefs.
	Files:
		ttystate.h getcommand.c readpr.c finger.c getttyloc.c
		kmem.c names.c output.c pr.h read_vmunix.c ustruct.c
		ymakefile

**** given to dle@csl.sri.com ****

173	Tuesday Junuary 12, 1988	Phil
	Display 0:xx as 12:xxAM and 12:xx as 12:xxPM in nicetime.
	File:
		whois.c

174	Wednesday January 13, 1988	Phil
	Port to IBM AIS 4.2 on PC/RT (ibm032);
	- use getdtablsize in fingerd.
	- Add L1 and N_SEGSIZ in read_vmunix.
	- Add VDEBUG in readpr.
	- Do awful things in ustruct.c
	Files:
		read_vmunix.c ustruct.c readpr.c fingerd.c

175	Thursday January 14, 1988	Phil
	Add u_daemon enum in pr struct.  Fill in
	by tracing parents of current process in getcommand.
	Move body of getcommand to getcommand2. Display
	in getttyloc. Clean up readpr().
	Files:
		pr.h getcommand.c getttyloc.c readpr.c

176	Saturday, January 23, 1988	Phil
	Create daemon struct in daemon.h.
	Create daemon table in daemon.c.
	Make u_daemon a short -- index into daemons[].
	Display daemon parantage without host (suntools)
	Recognize /dev/console as location "Console"
	Add suntools, vt100tool, othertools, dlogind(?) to known daemons.
	Files:
		ymakefile daemon.h daemon.c getttyloc.c readpr.c

177	Wednesday, February 10, 1988	Phil
	Add ttwait and selwait check in getcommand.
	Display number of processes found in readpr.
	Files:
		getcommand.c readpr.c

**** new version given to dle@csl.sri.com ****
**** given to winser@gnu.ai.mit.edu ****

200	Wednesday, Feb 17, 1988	Phil
	Revamp autoconfig. Do DEFBANNER, TTYGROUP, TTYENT seperately
	Revamp taring in ymakefile. Include stuff dir.
	Move this to History.h. Create pversion.c
	File:
		autoconfig ymakefile History.h pversion.c

201	Thursday, Feb 25, 1988	Phil
	Add u_daemonp to LUSER, make u_daemon a struct daemon *
	Files:
		luser.h daemon.h getcommand.c getttyloc.c

202	Monday, March 7, 1988	Phil
	Define INIT_PID as 1, use in getcommand.c ttyask.c
	Use heuristic weighting in getcommand2()
	Create pr_weight
	Files:
		pr.h finger.h getcommand.c

203	Tuesday March 8, 1988	Phil
	figure out signal states under Umax
	use valloc for mapping in readpr()
	rename ttystate etc to waitstate ...
	penalize gamescontrol (crocked for now)
	bonus for runnable
	finger.c no longer includes waitstate
	Files:
		ttystate.h -> waitstate.h
		finger.c getcommand.c readpr.c

204	Thursday March 10, 1988	Phil
	Create enum and strings via _STATE and _STATES
	Create PAuse state and WAit state.
	Zero strings ends in names.c, alloc strings as VERSTRLEN+1
	Add _u to syms (for pause state)
	Files:
		waitstate.h readpr.c info.h names.c syms.h

205	Tuesday, March 22, 1988 Phil
	Back from St. Lucia, W.I.
	Add officialhostname and OFFICIALhostname to args.c, use in undomain.c
	Other cleanup in undomain.c
	Handle X11 host:[:]display[.[screen]] madness in getttyloc.c
	Files:
		args.c undomain.c getttyloc.c

206	Wednesday, March 23, 1988 Phil
	Add aliases islocalhost() to args.c, use in mcheck.c
	Add BOOL to finger.h
	Make strupcpy() and strzcpy() in strings.c return src (like strcpy)
	Fix LOG_ERROR to be LOG_ERR (for 4.3) in fingerd.c
	Files:
		args.c mcheck.c finger.h strings.c fingerd.c

207	Monday, April 4, 1988	Phil
	Use mtime .ge. atime (was .gt.) in mcheck()
	File:
		mcheck.c

210	Monday, April 10, 1988	Phil
	NETFOLLOW only when there are local users specified.
	Do remote users even if no local users were specified.
	(make just /follow work again)
	File:
		args.c

211	Wednesday, April 20, 1988 Phil
	Call openlog with name "fingerd", use LOG_DAEMON if defined.
	Add HIDDEN_PROGRAMS for things like "gamescontrol"
	Files:
		fingerd.c getcommand.c

212	Tuesday, May 3, 1988	Phil
	Add /state switch.
	Files:
		getcommand.c finger.c flags.h switch.c switch.h

213	Saturday, May 6, 1988	Phil
	Have makeperson take luser as first arg.  This way we can
	finger personal name via inquire even if the yellow pages are
	dead!  Flush getperson1. Add REL_SUP.
	Files:
		getperson.c select.c finger.c

214	Sunday, May 7, 1988	Phil
	If redirected console, display in default ttyloc.  Add /ITS
	(change nicetime, "Jobnam" header).  Display relation even if
	REL_SUP under /whois.  Add /output-idle -- displays time since
	last output.  Display groups in whois() -- Can get redundancies!!
	Files:
		getttyloc.c whois.c flags.h switch.c
		switch.h finger.c output.c

215	Friday, May 13, 1988	Phil
	Port to Celerity (accel 3.4.x).  Make read_vmunix read NMAGIC
	files.  Capitalize first letter of uname inserted by '&' crock.
	Check for vaild u_procp in readpr().  Reuse t_short as long string
	if no ty_comment in readttyents().  Add PICKY.  Correct TTYENT
	ifdefs. Fix bsd4_3 quote problem in autoconfig.  Add accel to
	fingerd ARHITECTUREs.  Make Ultrix an ARCHITECTURE.  Add -L to ls
	/bin/write in autoconfig -- On accel its a symlink!
	Files:
		getperson.c getcommand.c getttyloc.c kmem.c read_vmunix.c
		readpr.c readttylocfile.c syms.h ustruct.c names.c
		autoconfig fingerd.c

216	Tuesday, May 17, 1988	Phil
	Check for console redirection in getttyloc(). Add ISCONS macro.
	Add BIG_CONSOLE, SMALL_CONSOLE to tag lines.
	Add UID_NOBODY, USER_NOBODY to fingerd.
	Files:
		getttyloc.c fingerd.c

217	Friday, May 20, 1988	Phil
	Add /process (sw_pid). Column not wide enough!!
	Files:
		finger.c flags.h switch.h switch.c

220	Thursday, May 26, 1988	Phil (bucsf)
	Add NINQUIRE, inquire.h to support *NEW INQUIRE*
	Add P_NOPWENT to explicily flag users without password
	file entries (yp failure, stale inquire entry)
	Add s_next field to SELs for quick traversal.
	make ttyask timeouts be per question
	Files:
		person.h finger.c inquire.h ttyask.c getperson.c
		select.c select.h

221	Monday, June 6, 1988 AM Phil (bucsf)
	Add MINCYCLE for ttycycle/ttyrandom.
	Cleanup in getcommand() and getcommand2().
	Add X10_STR/X11_STR to getttyloc()
	Add useinquire global.  Not yet checked *TODO*
	Use acct as supervisor,  Flush [maddr] display in whois.c
	Files:
		ttyask.c getcommand.c getttyloc.c args.c whois.c

222	Monday, June 6, 1988 PM Phil (bucsf)
	Make finguser() table driven!!!
	File:
		finger.c

223	Wednesday, June 8, 1988 Phil
	Rename /process to /pid. Document.  Create PID_COL:
	display pid in own column (crowds personal name) if defined.
	File:
		finger.c switch.h

**************** Begin version 2

300	Wednesday, June 15, 1988 Phil
	Prepped for Beta.  Updated all Copyrights, man page dates.
	Move DOC and SITE text into README.
	Kill locname.h move stuff to local.h, autoconfig.
	Make Install a sh file, preprocess with cpp (renamed Install.cpp)
	Fix day 1 bug in outchar (tab accounting (we do this twice!!)
	Files:
		COPYRIGHT Copying finger.1 ttyloc.1 nttyloc.5 fingerd.8c
		Install.cpp ymakefile Makefile
		autoconfig ttyloc.c locname.c output.c

**** Beta release!!

301	Wednesday, June 15, 1988 Phil
	Fix tar build to exclude SAMPLE*.h (avoid doubles)
	Invoke symdate and make-version with ./
		Allow supression of "same" (NEVER_SAME) (Fuat@columbia)
	Flush locname once and for all. Check for /usr/var under ultrix
		(mkhaw@teknowledge-vaxc.arpa)
	Allow suppression of "What" field (SUPPRESS_WHAT) (henry@garp)
	Files:
		Install.cpp ymakefile autoconfig finger.c

302	Sunday, June 26, 1988 Phil
	Add ALWAYS_PRINT_HEADER, DONT_TAB_PLAN (fuat)
	Use LOADADDR on VAXen (Stu Grossman@Stanford)
	Create HZUP macro for hosts only, create PRESERVE_HOST_CASE (Stu)
	and uppercase[] table.  Use in zup, strupcpy.
	Print "No one logged in." when needed.
	Files:
		finger.c whois.c read_vmunix.c finger.h doremote.c
		getttyloc.c whois.c undomain.c string.c ymakefile
	New:
		upper.h upper.c

303	Tuesday, July 6, 1988 Phil
	Ran thru comdef to comment all #else and #endifs (Fuat)

304	Friday, July 8, 1988 Phil
	Monday, July 11
	Use fprintf for help, feed thru pager.
	Print copyright and version along with help.
	File:
		switch.c

**** Second Beta release!!

305	Monday, July 25, 1988 Phil
	rename PRESERVE_HOST_CASE to UPCASE_HOSTS and swap sense of test.
	(host case preservation is now the default)
	File:
		finger.h

306	Wednesday, July 27, 1988 Phil
	Fix sense of ALWAYS_PRINT_HEADER.  Display last modification
	date of plan.  Add telnet.gw to daemons under ultrix
	Files:
		finger.c whois.c daemon.c

307	Friday, July 29, 1988	Phil
	Sunday, July 31, 1988
	Port to SunOS 4.0 (sos4_0) on bu-pub a sun4
	Files:
		readpr.c ustruct.c getcommand.c syms.h pr.h
		autoconfig Install.cpp

310	Monday, August 29, 1988	Phil
	Use kvm library under sos4_0
	(but not for struct proc, or nlist)
	Files:
		getcommand.c kmem.h names.c ustruct.c
		kmem.c readpr.c ymakefile

311	Monday, September 19, 1988 Phil
	Various cleanup; add some forwards (thanks to gcc 1.25)
	Make edit 310 work on non SOS4.0. Use enum in ttyask.
	Files:
		ttyask.c ustruct.c ttyloc.c names.c
		getttyloc.c args.c

312	Monday, October 24, 1988 Phil
	Check for pty named ttyv0 under Ultrix, remove leading
	pound sign and spaces from ttyent comments.  Add dtermd (?)
	to daemons list.
	Files:
		getttyloc.c readttylocfile.c daemon.c

313	Wednesday, October 26, 1988 Phil
	Use switch in finger(). Add \ quoting. Don't stomp on prog.
	Increment sp after & copy loop in makeperson()
	Fix some Ultrix typos.
	Files:
		args.c getperson.c
		autoconfig daemon.c readttylocfile.c

314	Saturday, November 12, 1988	Phil
	Port to Road Runner (sun 386i); Allow for alternate symbol
	forms under COFF.  Add cmdtool to daemons list (4.0 sunview?).
	read_vmunix does not yet understand COFF.  Add RR to fingerd.
	Detect NULL in pstr().  Chuck tp_long if NULL.
	Files:
		names.c syms.h info.h fingerd.c autoconfig
		daemon.c finger.c getttyloc.c

315	Sunday, November 13, 1988	Phil
	Crock console stuff to work for 4.0.  Output consdev... under
	DEBUGSW.  Always output dev_t's in hex. Document consdev obs.
	Files:
		getcommand.c kmem.c readpr.c

316	Tuesday, November 15, 1988	Phil
	Add selection_svc to list of hidden[].  Create IN_DOT_SERVER
	in case somone other than sun uses in.telnetd etc.  Flush
	sos4_0 in favor of SunOS >= 40.  Define KMEMREAD FTYPE
	ISBADFILE using kvm_t. Have symdate give real exit values.
	Files:
		getcommand.c daemon.c autoconfig daemon.c kmem.h
		kmem.c readpr.c ustruct.c fingerd.c pr.h syms.h
		getcommand.c symdate.c

months pass...

317	Thursday, February 2, 1989	Phil
	Clean up in autoconfig. Use $T $RD etc for testing.
	Port to Ultrix 3.0; VOIDSIG (was SunOs >= 40), and P_TTYP.
	Add S_HELD for yux.
	Files:
		autoconfig readpr.c pr.h

320	Thursday, February 16, 1989	Phil
	Clear lastpr in getcommand()
	File:
		getcommand.c

321	Tuesday, February 22, 1989	Phil
	Fix ttyask symlink in Install.cpp
	File:
		Install.cpp

322	Friday, March 3, 1989		Phil
	Port to Sony News. Very clean 4.3!!
	Punt in pstr before togoal()!
	Files:
		finger.c fingerd.c getttyloc.c read_vmunix.c

323	Wednesday, April 26, 1989	Phil
	Back from the Yucatan, Mex.
	Update Copyrights again!  This time use GNU General
	Public Licence Version 1. RCS-ified (1.1)
	Files:
		The known world

324	Wednesday, April 26, 1989	Phil
	Shorten KIT name for S5!
	File:
		ymakefile

325	Sunday, May 21, 1989		Phil
	Port to DEC PMAX. Ran comdef on *.c. Removed UMAP1/2 code
	Files:
		ustruct.c read_vmunix.c fingerd.c
		autoconfig

326	Monday, May 22, 1989		Phil
	Use h_errno, h_errlist to report errors!
	File:
		doremote.c

327	Sunday, June 11, 1989		Phil
	Fix long standing bug with explicit finger of remotely logged
	8 character usernames(!)  in ent_select() found by
	composer@bucsf
	File:
		getent.c

330	Monday, June 12, 1989		Phil
	Port to SGI/Iris.  First USG system with the necessary tools
	(job control and GNU Emacs)! myecho no longer needed.
	Files:
		Makefile acct.c getttyloc.c readpr.c autoconfig
		getut.c make-version switch.c finger.c info.h myecho.c
		syms.h fingerd.c kmem.c names.c getcommand.c kmem.h
		pr.h ustruct.c getent.c lastlog.c read_vmunix.c
		ymakefile ttyloc.c ttyask.c getent.c daemon.c

	New:
		mywhoami.c uptime.c COMDEFALL DIFFALL

331	Wednesday, June 14, 1989	Phil
	Port back from SGI Clean up system include files in
	readpr/getcommand/ustruct Compiles on SOS3, SOS4, SGI.  Defend
	against missing h_errno.  Add new daemon names for SGI.  Try
	to convert dotted octets to hostname or netname (checkhost).
	Lookup terminal location for last logout terminal.  If stdout
	not a terminal use unlimited output width.  Create strings.h
	to ease ports to other USG systems.
	Files:
		daemon.c doremote.c finger.c readpr.c undomain.c
		ustruct.c getcommand.c output.c readttylocfile.h

	New:
		strings.h CHECKINALL

332	Thursday, June 15, 1989		Phil
	Killed unused vars found with gcc -W.  What a compiler!
	Files:
		ttyask.c fingerd.c switch.c args.c readttylocfile.c
		readttylocfile.h kmem.c finger.c

333	Tuesday, June 20, 1989		Phil
	Port to Umax V (Multimax System 5) -- Second USG system
	Clean up ttyloc.c, fingerd.c, PMAX/ultrix in ustruct.c
	More gcc induced cleanup (void and int function decls)
	Files:
		Makefile acct.c autoconfig doremote.c finger.c
		fingerd.c getcommand.c getttyloc.c kmem.c mcheck.c
		names.c output.c pr.h pversion.c readpr.c syms.h
		ttyloc.c ustruct.c ymakefile
	Renamed:
		readttylocfile.[ch] to ttylocfile.[ch]

334	Wednesday, June 21, 1989	Phil
	Port back to VAX/4.3 and RT/4.3.  Use getpwnam for unmatched
	SELs under INQUIRE.  Add new switch /noinquire.  Add s_orig to
	SEL.  Add PUP telser daemon! Weight reduction in readpr and
	ustruct.  Always use p_addr, flushed MAP, HOG is default.  Use
	ioctls to get terminal width.  Add U_BADTTY to luser.  Keep
	last test version/date in README.
	Files:
		luser.h daemon.c finger.c output.c readpr.c
		select.[ch] switch.[ch] symsh.h ustruct.c README
		

335	Thursday, June 22, 1989		Phil
	Update finger man page.  Start port to AIX/RT; autoconfig for
	SHORT_TTYP SYSLOG STREAMS SVR3_STATES PTYPATH PTS_PTY_NAMES.
	Set SHELL in Makefile! Handle TTY_WID/PER_WID differently.
	Move STD_{INPUT,OUTPUT} to finger.h. Always read padded
	ustruct from drum.
	Files:
		Makefile finger.h output.c switch.h autoconfig
		getcommand.c pr.h syms.h finger.1 getttyloc.c readpr.c
		ttyask.c finger.c names.c switch.c ustruct.c

336	Sunday, June 25, 1989		Phil
	Use UNDERSCORE_NLIST_NAMES to determine nlist symbol flavor.
	Move make depend to Makefile, use cc -M; add cc-M from xrn11.
	Bring back usrpt lossage for ibm032 under NEED_USRPT.  Add
	NEED_USERMAP for non accel BSD systems.
	Files:
		finger.c getcommand.c names.c pr.h syms.h ustruct.c
		ymakefile Makefile autoconfig kmem.c readpr.c

337	Tuesday, June 27, 1989		Phil
	Make /follow work locally (at long last!)
	Fix ttyloc.  Only CHECKINALL locked files!
	Files:
		args.c mcheck.c select.c CHECKINALL

340	Sunday, July 9, 1989		Phil
	Port back to VAX Ultrix 3.0; Fix mail last read time.
	Files:
		ymakefile daemon.c finger.c getcommand.c
		mcheck.c output.c ustruct.c

341	Wednesday, July 12, 1989	Phil
	Port back to Umax 4.2 (no ttyp).  Use ut_pid under S5 and
	kill(2) to verify utmp entries!  Works on sgi and Umax V.
	Files:
		getcommand.c getut.c

342	Wednesday, July 26, 1989	Phil
	output \r in fingerd. ansify newmanifest. Add DONT_SAY_HACKING
	in whois(). make split uuencodes of compressed tar. Make
	net_name a routine. use h_addr_list, display Trying...  use
	net_name for remote fingers.
	Files:
		ymakefile fingerd.c newmanifest.c
		whois.c undomain.c doremote.c


343	Tuesday, August 1, 1989		Phil
	Now works on IBM PC-RT/AIX.  If /usr/mail exists use it.
	Files:
		ustruct.c autoconfig

344	Saturday, September 9, 1989	Phil
	Check for NULL in pcount()
	File:
		finger.c

345	Wednesday, November 15, 1989	Phil
	Add /noplan
	File:
		finger.c args.c flag.h switch.c switch.h finger.1

346	Friday, December 1, 1989	Phil
	Update for Umax V 2.2g
	Files:
		autoconfig ustruct.c readpr.c

347	??? Phil
	Start working on per-user flags.
	Particularly force /match for local names in .forward!!
	Files:
		args.c doremote.c

350	Friday, January 12, 1990	Phil
	Port to Interactive 386/ix SVR3.2; Put all ustruct include in
	ustruct.h; Check modes in autoconfig with checkmode.c
	Files:
		autoconfig Makefile ymakefile
		ustruct.c getcommand.c readpr.c 
	New:
		checkmode.c ustruct.h

351	Friday, January 12, 1990	Phil
	Reimplement select.c using lists, flush select.h
	Implement per-user switches (only /match for now)
	Files:
		args.c select.c
	Flushed:
		select.h

352	Friday, January 12, 1990	Phil
	Add struct flags to luser struct
	Do make depend while building xmakefile
	Files:
		finger.c getcommand.c getent.c getperson.c getttyloc.c
		luser.c mcheck.c output.c select.c whois.c whoj.c
		Makefile ymakefile

353	Tuesday, January 30, 1990	Phil
	Flush args.m4, etc, rename flags struct, Flags to
	switches, Sw.  Remove old inquire (and INQUIRE define).
	Major cleanup in select.c
	Flushed:
		args.m4 flags.h
	New:
		args.h	
	Files:
		ymakefile args.c finger.c getent.c getttyloc.c inquire.h
		inquire.c luser.h mcheck.c select.c switch.c finger.1

354	Tuesday, April 24, 1990	Phil
	Only make depend when building programs. Added DEPEND hack.
	Fix kit/dist. Update Copyrights to 1990, remove some
	boilerplate, use RCS Id rather than Header. Ran COMDEFALL.
	Checked in as RCS version 2.0
	Files:
		Makefile ymakefile README autoconfig

355	Wednesday, April 25, 1990 3AM	Phil
	Touchups for UmaxV and AIX
	Files:
		Makefile ymakefile autoconfig readpr.c ustruct.h cc-M

356	Wednesday, April 25, 1990 6PM	Phil
	Touchups for SGI/Irix and Ultrix 3.1 (per jdh)
	Files:
		ustruct.c ustruct.h output.c getttyloc.c

357	Wednesday, April 25, 1990 8PM	Phil
	Moved make depend work back to x/ymakefile
	Files:
		Makefile ymakefile

360	Thursday, April 26, 1990 -
	Wednesday, May 2, 1990		Phil
	Fixes to Install.cpp from spike@world.std.com;
	Implement finger.conf file!!
	Flushed:
		acct.c
	New:
		conf.c finger.conf.5 finger.conf
	Files:
		Install.cpp Makefile args.c autoconfig doremote.c
		finger.c getcommand.c getperson.c output.c undomain.c
		whois.c ymakefile

361	Tuesday, May 8, 1990		Phil
	Port to SunOS 4.1, Make SunOS define 3 digits!!
	Files:
		autoconfig daemon.c fingerd.c getcommand.c getttyloc.c
		kmem.c kmem.h luser.h output.c pr.h readpr.c syms.h
		ustruct.c ustruct.h README

362	Thursday, May 17, 1990		Phil
	Port to Sequent S3, add ORIG to kit.
	New:
		ORIG
	Files:
		DIFFALL README autoconfig fingerd.c read_vmunix.c
		ustruct.c ymakefile

363	Friday, May 18, 1990		Phil
	Port back to Celerity, cleanup fingerd
	Files:
		autoconfig fingerd.c README

364	Sunday, May 20, 1990		Phil
	Define Umax as 42 or 43 in preparation for release 4.0
	Use stat of /dev/tty15 in onlat(). Define and use AIX_RT
	Files:
		autoconfig fingerd.c getcommand.c getttyloc.c kmem.c
		names.c read_vmunix.c readpr.c ustruct.c ustruct.h

365	Monday, May 21, 1990 -
	Monday, June 4, 1990		Phil
	Port to AIX3 on the IBM RS/6000
	Files:
		args.c autoconfig daemon.c finger.c fingerd.c getcommand.c
		getttyloc.c output.c readpr.c ustruct.c ustruct.h whois.c
		ymakefile

366	Tuesday, May 29, 1990 -
	Monday, June 4, 1990		Phil
	Merge back changes for AIX 1.1 PS/2 port.
	Have not tested ustruct2() code. Add "make quick"
	Files:
		Makefile autoconfig fingerd.c getut.c ustruct.c ustruct.h

367	Thursday, June 14, 1990		Phil
	Port to Umax 4.3 (rel 4.0).
	Files:
		autoconfig getcommand.c output.c
		read_vmunix.c readpr.c ustruct.c ymakefile


370	Friday, June 29, 1990		Phil
	Fix display of last login host.  Do checkhost() in lltime(),
	pass back host flag to prevent tty line lookup!!  If local
	host is a suffix of remote host remove entire thing!!  Change
	" Account: " display to " Group: ".
	Files:
		undomain.c lastlog.c finger.c

**************** Start version 3

400	Friday, July 6, 1990		Phil
	Ran COMDEF, checked all files in as 3.0
	Status "Rel", tag "rel1"

**************** released to comp.sources.unix

******** DONT FORGET TO UPDATE VERSION NUMBER BELOW!! (IN OCTAL) ********/

struct _JBVER ver = { 0, 03, 0, 0400 };	/* who, major, minor, edit */
