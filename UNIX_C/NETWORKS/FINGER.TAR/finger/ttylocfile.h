/*
 * ttylocfile.h -- defns to read /etc/ttyloc (December 1985)
 /*
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# define TTYLOCFILE_RCSID "$Id: ttylocfile.h,v 3.0 90/07/06 13:12:05 budd Rel $"

# ifndef LOCFILE
# define LOCFILE "/etc/ttyloc"
# endif /* LOCFILE not defined */

# ifndef NLOCFILE
# define NLOCFILE "/etc/nttyloc"	/* new format file */
# endif /* NLOCFILE not defined */

# ifndef MAXTTY
# define MAXTTY 100			/* number of ttys on system */
# endif /* MAXTTY not defined */

typedef enum { LT_HARD, LT_TTYLOC, LT_DIALUP, LT_UNKNOWN } LINETYPE;

typedef struct ttyloc {
    char *t_name;			/* terminal name */
    char *t_locn;			/* default (long) terminal location */
    char *t_short;			/* short locn (prepended to user str) */
    LINETYPE t_type;			/* line type */
} TTYLOC;

extern TTYLOC *findttyloc();

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
