/*
 * getent.c -- build local user tree for finger
 * It all started here.. (November 1985)
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: getent.c,v 3.0 90/07/06 13:10:48 budd Rel $";
# endif /* lint not defined */

# include <sys/types.h>
# include <utmp.h>
# include <stdio.h>
# include <ctype.h>
# include "person.h"
# include "args.h"			/* for luser.h */
# include "luser.h"
# include "tsel.h"
# include "finger.h"

extern struct utmp *getutent();		/* from utmp.c */
extern endutent();			/* from utmp.c */
extern LUSER *treefind();		/* from getperson.c */

FORWARD GLOBAL LUSER *linsert();
FORWARD LOCAL  LUSER *mkluser();

LOCAL TSEL *first_tsel, *last_tsel;

# define LINESIZE sizeof( ((struct utmp *)0)->ut_line )	/* size of ut_line */

/* .see gtname() in output.c */
# define TTY_PREFIX "tty"
# define TTY_PREFIX_SIZE (sizeof(TTY_PREFIX)-1)


GLOBAL void init_tsel() {
    first_tsel = last_tsel = NULL;
}

GLOBAL void addtty( s )
    char *s;
{
    register TSEL *ts;
    register l, l2;
    if( (ts = (TSEL *) malloc( sizeof( TSEL ) )) == NULL ) {
	perror("could not allocate tty selector");
	exit( 1 );
    }

    l = l2 = strlen( s );
    if( l > LINESIZE ) {
	l = LINESIZE;
	if( l > LINESIZE - TTY_PREFIX_SIZE )
	    l2 = l - TTY_PREFIX_SIZE;
    }

    ts->ts_name = s;
    ts->ts_len = l;
    ts->ts_len2 = l2;
    ts->ts_next = NULL;
    if( first_tsel == NULL )
	first_tsel = last_tsel = ts;
    else {
	last_tsel->ts_next = ts;
	last_tsel = ts;
    }
}

GLOBAL LTREE *maketree() {		/* create tree of users */
    register struct utmp *ut;
    LTREE *tree;
    LUSER *new;

    tree = NULL;

    while( (ut = getutent()) != NULL ) {

	if( ut->ut_name[0] == EOS )	/* entry has name? */
 	    continue;			/* no, get next */

	if( first_tsel != NULL ) {
	    register TSEL *t;
	    int ok;

	    ok = FALSE;
	    for( t = first_tsel; t != NULL; t = t->ts_next ) {
		if( strncmp( ut->ut_line, t->ts_name, t->ts_len ) == 0 ||
		   (strncmp( ut->ut_line, TTY_PREFIX, TTY_PREFIX_SIZE ) == 0 &&
		    strncmp( &ut->ut_line[TTY_PREFIX_SIZE],
			    t->ts_name, t->ts_len2 ) == 0) ){
		    ok = TRUE;
		    break;
		} /* if strncmp */
	    } /* for */
	    if( !ok )
		continue;
	} /* first_tsel */

	new = mkluser(ut);
	tree = linsert(new, tree);
    }
    endutent();
    return( tree );
} /* maketree */

GLOBAL LTREE *linsert(new, tree) 	/* insert new user into tree */
register LUSER *new;
register LTREE *tree;
{
    if( tree == NULL )			/* empty tree. return new entry */
        return( new );

    if( strcmp(new->u_user, tree->u_user) < 0 ) /* less than root? */
	 tree->u_left = (LUSER *)linsert(new, tree->u_left); /* put on left */
    else
         tree->u_right = (LUSER *)linsert(new, tree->u_right);/* put on right */
					/* dupes are added to right */
					/* (.see pwtree) because we assume */
					/* that the utmp file is in tty name */
					/* order */

    return( tree );			/* return the tree */
}

GLOBAL LUSER *newluser() {		/* create empty luser struct */
    register LUSER *new;

    if( (new = (LUSER *)malloc( sizeof( LUSER ) )) == NULL ) {
	fprintf(stderr, "malloc failed in newluser\n");
	exit( 1 );
    }
    new->u_person = NULL;
    new->u_left = new->u_right = NULL;
    new->u_flags = 0;
    new->u_sw = Sw;			/* get per-person switches */
    return( new );
} /* newluser */

LOCAL LUSER *mkluser( ut )		/* create a luser from utmp */
register struct utmp *ut;
{
    register LUSER *new;

    new = newluser();

    strzcpy(new->u_user, ut->ut_name, sizeof(ut->ut_name) );
    strzcpy(new->u_line, ut->ut_line, sizeof(ut->ut_line) );
# ifndef UTMP_NO_HOST
    strzcpy(new->u_host, ut->ut_host, sizeof(ut->ut_host) );
# endif /* UTMP_NO_HOST not defined */
    new->u_time = ut->ut_time;

    return( new );
} /* mkluser */

/*
 * here with tree of usernames from command line
 * return new tree of logged in users
 */

GLOBAL LTREE *ent_select( proto )
LUSER *proto;
{
    register struct utmp *ut;
    char name[ sizeof( ut->ut_name ) + 1 ];
    LUSER *new, *found;
    LTREE *t2;

    t2 = NULL;

    while( (ut = getutent()) != NULL ) {
	if( ut->ut_name[0] == EOS )	/* entry has name? */
	    continue;			/* no, get next */

	strzcpy( name, ut->ut_name, sizeof( ut->ut_name ) );
	if( (found = treefind( proto, name )) != NULL ) {
	    register PERSON *p;

	    found->u_flags |= U_FOUND;
	    new = mkluser(ut);
	    p = new->u_person = found->u_person;
	    if( p != NULL )
		p->p_count++;
	    t2 = linsert(new, t2);
	} /* found template */
    } /* while utmp */
    endutent();

    return( t2 );
} /* ent_select */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
