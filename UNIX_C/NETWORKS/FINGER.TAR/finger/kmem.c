/*
 * kmem.c -- interact with /dev/kmem, /dev/mem etc.
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: kmem.c,v 3.0 90/07/06 13:11:09 budd Rel $";
# endif /* lint not defined */

# include "finger.h"
# if Umax != 42
# include <sys/types.h>
# include "kmem.h"
# include "args.h"			/* sw_debug */

/* # define DEBUG			/**/

# ifdef sun
# include "info.h"			/* info_[r]consdev */
extern struct info I;			/* namelist values from names.c */

# include <sys/stat.h>			/* to stat /dev/console */
GLOBAL dev_t consdev;
GLOBAL dev_t rconsdev;
GLOBAL dev_t dev_console;
# endif /* sun defined */

GLOBAL FTYPE kmem;			/* fd for /dev/kmem */
# if SunOS < 400
GLOBAL FTYPE mem;			/* fd for /dev/mem */
# ifdef SWAP_DEVICE
GLOBAL FTYPE drum;			/* fd for /dev/drum */
# endif /* SWAP_DEVICE defined */
# else  /* not SunOS < 400 */
# include <sys/file.h>			/* O_RDONLY */
# include <stdio.h>			/* NULL */
# endif /* not SunOS < 400 */


GLOBAL int ini_kmem() {
# ifdef sun
    struct stat stb;
# endif /* sun defined */

# if SunOS >= 400
    if( (kmem = kvm_open( NULL, NULL, NULL, O_RDONLY, "finger" )) == NULL ) {
	perror("kvm_open");
	return( FALSE );
    }
# else  /* not SunOS >= 400 */
    if( ISBADFILE( (kmem = OPEN("/dev/kmem")) ) ) {
	perror("/dev/kmem");
 	kmem = BADFILE; 	
	return( FALSE );
    }

    if( ISBADFILE( (mem = OPEN("/dev/mem")) ) ) {
	perror("/dev/mem");
	CLOSE(kmem);
	kmem = BADFILE;
	return( FALSE );
    }

# ifdef SWAP_DEVICE
    if( ISBADFILE( (drum = OPEN( SWAP_DEVICE )) ) ) {
	perror(SWAP_DEVICE);
	CLOSE(kmem);
	CLOSE(mem);
 	kmem = BADFILE;
 	return( FALSE );
    }
# endif /* SWAP_DEVICE defined */
# endif /* not SunOS >= 400 */

    if( !readnames() )			/* read in info struct */
	return( FALSE );

# ifdef sun
    KMEMREAD(I.info_consdev,  &consdev,  sizeof(consdev));
    KMEMREAD(I.info_rconsdev, &rconsdev, sizeof(rconsdev));
    if( stat("/dev/console", &stb ) == 0 )
	dev_console = stb.st_rdev;
    else
	dev_console = 0xffff;		/* makedev(255,255) */
# ifdef DEBUGSW
    if( sw_debug )
	printf("consdev %#x rconsdev %#x /dev/console %#x\n",
	       consdev, rconsdev, dev_console );
# endif /* DEBUGSW defined */
# endif /* sun defined */

    return( TRUE );
} /* ini_kmem */

# if SunOS < 400			/* anything but SunOS 4.x */
GLOBAL int kread(f, pos, buf, count)
FTYPE f;
int count;
unsigned long pos;			/* caddr_t? */
char *buf;
{
    int cc;
# ifdef DEBUG
    char *name;

    if( f == mem )
	name = " mem";
    else if( f == kmem )
	name = "kmem";
    else if( f == drum )
	name = "drum";
    else
	name = "??";
# endif /* DEBUG defined */

    if( SEEK(f, pos, 0) == -1 ) {
        perror("seek");
	cc = -1;
    }
    else 
	cc = READ(f, buf, count);

# if BUFIO
    if( cc > 0 )
	cc *= count;
# endif /* BUFIO */

# ifdef DEBUG
    printf("kread: %s@%08x %d(%d) chars\n",
	   name,
	   pos,
	   count,
	   cc);
# endif /* DEBUG defined */

    if( cc == -1 ) {
# ifdef DEBUG
	perror("read");
# endif /* DEBUG defined */
	return( FALSE );
    } /* bad return */
    return( TRUE );
} /* kread */
# endif /* SunOS < 400 */

# endif /* Umax != 42 */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
