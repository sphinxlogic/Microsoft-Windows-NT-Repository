/*
 * getperson.c -- read person oriented data (December 1985)
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: getperson.c,v 3.0 90/07/06 13:10:51 budd Rel $";
# endif /* lint not defined */

# include <sys/types.h>
# include <strings.h>
# include <ctype.h>
# include <stdio.h>
# include <pwd.h>			/* getpwent defns */
# ifdef INQUIRE
# include <inquir.h>
# endif /* INQUIRE defined */
# include "person.h"
# include "args.h"			/* before luser.h */
# include "luser.h"
# include "finger.h"

# ifndef DEFSHELL
# define DEFSHELL "/bin/csh"		/* dull shell */
# endif /* DEFSHELL not defined */

# ifndef PRJLEN
# define PRJLEN 70			/* max lex for project */
# endif /* PRJLEN not defined */

extern char *strip();			/* from string.c */
extern BOOL useinquire;

PERSON *makeperson();			/* forward... */

GLOBAL int treesize( t )		/* count entries in a tree */
register LUSER *t;
{
    if( t == NULL )
	return( 0 );
    else
	return( treesize( t->u_left ) + treesize( t->u_right ) + 1 );
}

GLOBAL LUSER *treefind(t, uname)	/* find uname in tree */
register LUSER *t;
char *uname;
{
    register int compare;

    while( t != NULL ) {
# ifdef DEBUG
	printf(" tf '%s' ", uname );
	fflush(stdout);
	printf(" '%s'", t->u_user );
	fflush(stdout);
# endif /* DEBUG defined */
        compare = strcmp(uname, t->u_user); /* do compare once */
# ifdef DEBUG
	printf(" %d\n", compare );
# endif /* DEBUG defined */
	if( compare > 0 )
	    t = t->u_right;
	else if( compare < 0 )
	    t = t->u_left;
	else
	    return( t );
    }
    return( NULL );
} /* treefind */

# ifdef GETPWNAM_SLOW
GLOBAL int pwtree( t )			/* get pw entries for whole tree */
LTREE *t;
{
    register struct passwd *pw;
    int size, todo;			/* number of tree entries */

    size = todo = treesize( t );	/* get entries in tree */
    if( todo == 0 )
	return( 0 );			/* nothing to do! */

    setpwent();
    while( todo > 0  &&  (pw = getpwent()) != NULL ) { /* for each pwentry */
					/* search in tree for this uname */
					/* if found, create a person struct */
					/* and look for multiple logins */

	register LUSER *tp;
	register PERSON *pp;

# ifdef DEBUG
	printf("pwtree(%d): %s\n", todo, pw->pw_name );
# endif /* DEBUG defined */

	tp = t;				/* get root of tree */
	pp = NULL;			/* no person entry created yet */

	tp = treefind(tp, pw->pw_name); /* lookup user in tree */
	while( todo > 0  &&  tp != NULL ) {
	    if( tp->u_person != NULL )	/* already have person? */
		break;			/* must be is passwd twice! (or yp) */

	    todo--;			/* one less to do */
# ifdef DEBUG
	    printf(" ** %s **\n", tp->u_user );
# endif /* DEBUG defined */
	    if( pp == NULL )		/* created a person yet? */
	        pp = makeperson(tp,pw,NULL); /* do it now. */
	    pp->p_count++;		/* bump use count */
	    tp->u_person = pp;		/* point user to person */
	    tp = treefind(tp->u_right, pw->pw_name); /* lookup again */
					/* assumes that dupes are added */
					/* to right side (.see insert)*/
	} /* while tp != NULL */
    } /* while getpwent */
    endpwent();
    return( size );
} /* pwtree */
# else  /* GETPWNAM_SLOW not defined */
LOCAL int pwtree2_count;		/* ah for pascal */
LOCAL void pwtree2();			/* forward */

GLOBAL int pwtree( t )
LTREE *t;
{
    setpwent();				/* getpwnam does set/end */
					/* so this is a noop */
    pwtree2_count = 0;
    pwtree2( t );
    endpwent();
    return( pwtree2_count );
} /* pwtree */

LOCAL void pwtree2( t )			/* fill in person entries */
LTREE *t;				/* using getpwnam */
{    
    register struct passwd *pw;
    register LUSER *tp;
    register PERSON *pp;

# ifdef DEBUG
    printf("pwtree2(%d): %s\n", todo, pw->pw_name );
# endif /* DEBUG defined */

    tp = (LUSER *)t;			/* get root of tree */
    pp = NULL;				/* no person entry created yet */

    if( tp == NULL )
	return;

    while( tp != NULL && tp->u_person == NULL ) {
	if( pp == NULL ) {		/* created a person yet? */
	    if( (pw = getpwnam( tp->u_user )) == NULL )
		break;
	    pp = makeperson(tp,pw,NULL); /* do it now. */
	}
	pp->p_count++;			/* bump use count */
	pwtree2_count++;
	tp->u_person = pp;		/* point user to person */
	tp = treefind(tp->u_right, pw->pw_name); /* lookup again */
					/* assumes that dupes are added */
					/* to right side (.see insert)*/
    } /* while tp != NULL */

    pwtree2( t->u_right );
    pwtree2( t->u_left );

} /* pwtree2 */
# endif /* GETPWNAM_SLOW not defined */

GLOBAL PERSON *makeperson( up, pw, inq )
LUSER *up;
struct passwd *pw;
struct info *inq;
{
    char fname[100], pbuf[ PLEN+1 ];
    register PERSON *pp;
    register char *dp;
    register int i;
    char *sp;
    int file;

    if( (pp = (PERSON *) malloc( sizeof( PERSON ) )) == NULL )
	return( NULL );

    pp->p_count = 0;
    pp->p_flags = 0;			/* clear flags */
    pp->p_waddr = pp->p_wphone = pp->p_hphone = pp->p_haddr = NULL;
    pp->p_birthday = pp->p_supervisor = pp->p_project = pp->p_nickname = NULL;
    pp->p_maddr = pp->p_personal = pp->p_home = NULL;
    pp->p_remarks = pp->p_shell = NULL;
    pp->p_group = pp->p_relation = ' ';

    if( pw != NULL ) {			/* !! */
	pp->p_uid = pw->pw_uid;		/* copy user id */
	pp->p_gid = pw->pw_gid;		/* copy group id */
	pp->p_home = savestr( pw->pw_dir ); /* home directory */

	maddr( pp, pw->pw_name );	/* get mailing address */

	sp = pw->pw_gecos;		/* source pointer */
	if( strcmp(sp, "RC") == 0 ) {	/* gecos == "RC" */
	    pp->p_flags |= P_RC;	/* flag it */
	    return( pp );
	} /* RC */
    }
    else
	pp->p_flags |= P_NOPWENT;

# ifdef INQUIRE
    if( pw != NULL )
	name = pw->pw_name;
    else				/* seems unlikely, but */
	name = up->u_user;		/* of use when yp kaput! */
    if( useinquire && doinquire( name, pp, inq ) ) /* check holmes database */
	pp->p_flags |= P_INQUIRE;	/* flag it */
# else  /* INQUIRE not defined */
    acct_group( pp );
# endif /* INQUIRE not defined */

    if( pw != NULL && pp->p_personal == NULL ) {
	dp = pbuf;			/* pointer to dest */
	for( i = 0; i < PLEN; i++ ) {	/* for max len of personal name */
	    if( *sp == EOS || *sp == ',' )
		break;
	    if( *sp == '&' ) {		/* sigh, handle ampersand crock */
		register char *unp;	/* uname pointer */
		unp = pw->pw_name;	/* get pointer to user name */
		if( islower( *unp ) && (i == 0 || isspace(sp[-1])) ) {
		    *dp++ = toupper( *unp );
		    unp++;		/* avoid side effect as macro arg */
		    i++;
		} /* first char is lower */

		while( i < PLEN && *unp != NULL ) { /* copy it in */
		    i++;
		    *dp++ = *unp++;
		} /* while */
		sp++;
	    } /* & */
	    else
		*dp++ = *sp++;
	} /* for i */
	*dp = EOS;
	pp->p_personal = savestr( pbuf );
    } /* have pw entry, no personal name */

    if( !sw_whois )			/* **** doing full? **** */
	return( pp );			/* no, quit now */

    if( pw != NULL &&
       (pp->p_waddr == NULL ||
	pp->p_wphone == NULL || pp->p_hphone == NULL ) ) {

	/* BUG: handle USG format gecos data */
	sp = index(pw->pw_gecos, ',');	/* anything after user? */
	while( sp != NULL ) {		/* radioactive waste *BOGUS LOOP* */
	    sp++;			/* skip comma */

	    if( !skipwhite( &sp ) )
		break;			/* break bogus loop */
					/* avoids harmful goto! */
	    dp = index(sp, ',');
	    if( dp != NULL )
	    *dp++ = EOS;
	    sp = strip( sp );
	    if( pp->p_waddr == NULL && strlen( sp ) > 0 )
		pp->p_waddr = savestr( office( sp ) );
	    if( dp == NULL )
		break;			/* break bogus loop */

	    sp = dp;
	    if( !skipwhite( &sp ) )
		break;			/* break bogus loop */

	    dp = index(sp, ',');
	    if( dp != NULL )
		*dp++ = EOS;
	    sp = strip( sp );
	    if( *sp != EOS )
		if( pp->p_wphone == NULL )
		    pp->p_wphone = savestr( sp );

	    if( dp == NULL )
		break;			/* break bogus loop */

	    sp = dp;
	    if( !skipwhite( &sp ) )
		break;			/* break bogus loop */

	    sp = strip( sp );
	    if( *sp != EOS )
		if( pp->p_hphone == NULL )
		    pp->p_hphone = savestr( sp );

	    break;			/* break bogus loop */
	} /* process radioactive waste (gecos) */
    } /* pw entry & missing info from GECOS */

    if( pw != NULL ) {
	if( strcmp(pw->pw_shell, DEFSHELL) != 0 )
	    pp->p_shell = savestr( pw->pw_shell );
	else
	    pp->p_shell = NULL;
	
	if( pp->p_project == NULL ) {
	    strcpy(fname, pp->p_home);
	    strcat(fname, "/.project");
	    while( (file = open(fname, 0)) >= 0 ) {
		char prjbuf[PRJLEN];
		char *cp;
		int cc;
		
		cc = read(file, prjbuf, PRJLEN-1);
		close(file);
		if( cc < 1 )
		    break;		/* leave bogus loop */
		prjbuf[cc] = EOS;
		
		if( (cp = index(prjbuf, '\n')) != NULL )
		    *cp = EOS;
		
		cp = strip( prjbuf );
		if( *cp != EOS )
		    pp->p_project = savestr( cp );
		break;		/* leave bogus loop */
	    } /* found project */
	} /* look at .project file */
    } /* have pw entry */
    return( pp );
} /* makeperson */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
