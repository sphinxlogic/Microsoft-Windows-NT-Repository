/*
 * args.c -- process arguments for finger / whoj
 * January 1986  -- Year of the Commet
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

# ifndef lint
static char *rcsid = "$Id: args.c,v 3.0 90/07/06 13:10:18 budd Rel $";
# endif /* lint not defined */

# include <sys/types.h>
# include <strings.h>
# include <stdio.h>
# include <ctype.h>
# include <netdb.h>			/* to get cannonical name */

# include "args.h"
# include "remote.h"
# include "finger.h"
# include "inquire.h"

extern dowhoj(), dofinger();		/* from output.c */
extern void ini_select(), addlocal();	/* from select.c */
extern BOOL have_local();		/* from select.c */
extern void ini_tsel(), addtty();	/* from getent.c */
extern char *ttyname();			/* from libc */
extern void doswitch();			/* from switch.c */

LOCAL RHOST *host_chain, *end_host_chain; /* chain of 4n hosts */
GLOBAL int netfinger;			/* input from socket */
GLOBAL BOOL useinquire;			/* have inquire database */

LOCAL void finger();			/* forward */
LOCAL int isasocket();			/* forward */
GLOBAL void add4n();			/* forward */

GLOBAL char localhost[ MAXHOSTLEN+1 ];	/* system /bin/hostname */
GLOBAL char officialhostname[ MAXHOSTLEN*2 ]; /* official name from host table*/
GLOBAL char OFFICIALhostname[ MAXHOSTLEN*2 ]; /* upper case copy */
GLOBAL char **aliases;			/* aliases for this host */

GLOBAL int main( argc, argv )
int argc;
char *argv[];
{
    char *prog;
    
    netfinger = isasocket(0) && isasocket(1); /* are stdin and
					       * stdout sockets (pipes)? */

    if( !netfinger && getuid() == 0 ) {	/* if superuser */
	nice( -120 );			/* run fast */
	nice( 20 - 10 );		/* (absolute -10) */
    } /* superuser */

    if( gethostname( localhost, MAXHOSTLEN ) == 0 ) {
	struct hostent *h;
	if( (h = gethostbyname( localhost )) != NULL ) {
	    int c;
	    char **a, **b;

	    strcpy( officialhostname, h->h_name );
	    strupcpy( OFFICIALhostname, officialhostname );

	    c = 0;
	    a = h->h_aliases;
	    while( *a++ != NULL )	/* count aliases */
		c++;

	    a = h->h_aliases;
	    aliases = b = (char **) calloc( c + 1, sizeof( char * ) );
	    while( (*b++ = savestr( *a++ )) != NULL )
		;
	} /* got host entry */
    } /* gethostname */

    getterm();				/* get terminal stuff */

    host_chain = end_host_chain = NULL;	/* clear 4n host chain */

    if( (prog = rindex(argv[0], '/')) != NULL ) /* isolate last part of path */
	prog++;				/* skip slash */
    else
	prog = argv[0];

    init_tsel();			/* clear tty selectors */

    finger(prog, argc, argv);
    return( 0 );			/* ANSI conforming */
} /* main */

LOCAL int isasocket( s )
int s;
{
    int l;
    char sa[ 200 ];			/* bogus sockaddr struct */

    l = sizeof( sa );			/* pass length by reference */
    if( getpeername( s, sa, &l ) < 0 )
	return( FALSE );
    else
	return( TRUE );
} /* isasocket */

LOCAL void unswitch( str )
    char *str;
{
    register char *cp;
    if( (cp = index(str, '/')) != NULL ) {
       *cp++ = EOS;
       doswitch( cp );
   } /* found a slash */
} /* unswitch */


LOCAL void adduser( user )
char *user;
{
    char *tp;				/* char pointer */
    struct switches SavedSw;

    for( ; user != NULL; user = rindex(user, ',') ) {

	if( !skipwhite( &user ) )		/* remove leading white */
	    continue;

	tp = user;			/* remove trailing white */
	if( skipblack( &tp ) )		/* skip token. find EOS? */
	    *tp = EOS;			/* found white -- nuke it! */

	tp = rindex(user, '@');		/* any ATs? (reverse -- for routing) */
	if( tp != NULL ) {		/* oh goody! */
	    *tp++ = EOS;		/* blast at */
	    add4n( user, tp );		/* add to list of aliens */
	    continue;
	}

	SavedSw = Sw;			/* save flags */
	unswitch( user );		/* remove and process switches */
	addlocal( user );		/* process local user */
	Sw = SavedSw;			/* per user switches */
    } /* for user */
} /* adduser */

LOCAL void finger(prog, argc, argv)
char *prog;
int argc;
char *argv[];
{
    static char mytty[ 20 ];
    register char *cp, *tp;

    if( strcmp(prog, "whoj") == 0 )
	sw_jobs = TRUE;

    ini_select();			/* init selector tree etc.. */

# ifdef INQUIRE
    useinquire = TRUE;
    if( !Mapin( NULL ) ) {		/* map in inquire database */
	useinquire = FALSE;
	fprintf( stderr, "%s\n", inq_error );
    } /* Mapin failed */
# endif /* INQUIRE defined */

    tp = ttyname( 0 );			/* get device */
    if( tp != NULL ) {
	if( strncmp( tp, "/dev/", 5 ) == 0 )
	    tp += 5;
	strcpy( mytty, tp );
    }
    else
	mytty[0] = EOS;

# ifdef NETBERK
    if( netfinger )			/* from network? */
	sw_berkeley = TRUE;		/* be verbose if asked by name */
					/* I hate it, but it helps aliens */
					/* with lousy finger programs */
# endif /* NETBERK defined */

    if( strcmp(prog, "whois") == 0 )	/* invoked as whois? */
        sw_whois = TRUE;		/* yes, set flag now */
    else if( strcmp(prog, "xf") == 0 )	/* xf? */
	sw_nosave = TRUE;		/* be nice (don't write nm file) */

    argv++;
    argc--;
    while( argc > 0 ) {			/* while more args */
	struct switches SavedSw;

	switch( argv[0][0] ) {
	case '-':
	case '/':			/* switch */
	    doswitch( &argv[0][1] );
	    break;

	case '+':			/* tty */
	    SavedSw = Sw;
	    unswitch( &argv[0][1] );
	    addtty( &argv[0][1] );
	    Sw = SavedSw;		/* per user switches */
	    break;

	case '.':			/* just dot */
	    SavedSw = Sw;
	    unswitch( &argv[0][1] );
	    if( argv[0][1] != EOS )
		fprintf( stderr, "%%Garbage after DOT: %s\n", &argv[0][1] );

	    if( mytty[0] != EOS )
		addtty( mytty );	/* do us. */
	    else
		fprintf( stderr, "%%Could not get own terminal for '.'\n" );
	    Sw = SavedSw;		/* per user switches!! */
	    break;

	case '\\':			/* quoting against local switch */
					/* expansion? */
	    adduser( argv[0]+1 );
	    break;

	default:			/* must be a user */
	    adduser( argv[0] );
	    break;
	} /* switch */
	argv++;
	argc--;
    } /* while argc */

    read_conf();			/* read finger.conf */
					/* after switches!! */

    if( sw_jobs ) {
	dowhoj();
	return;
    }

    if( !have_locals() && host_chain == NULL ) /* no hard work */
	dofinger( NULL );		/* show logged in users */

    if( have_locals() ) {		/* /follow may have added locals! */
	struct switches SavedSw;
	sw_t SavedWhois;

	SavedSw = Sw;		/* save flags */
	SavedWhois = sw_whois;
	if( sw_berkeley ) {		/* in berkley emulation mode? */
	    sw_whois = TRUE;		/* yes, be verbose */
	    Sw.sw_plan = !Sw.sw_noplan;
	}

# ifdef NETFOLLOW
	if( netfinger )			/* only follow if network AND people */
	    sw_follow = TRUE;
# endif /* NETFOLLOW defined */

	select_go();			/* run locals */

	Sw = SavedSw;			/* restore flags */
	sw_whois = SavedWhois;		/* before doing remote!! */
    } /* else */

    if( host_chain != NULL )
	doremote( host_chain );

} /* finger */

LOCAL RHOST *mkrhost( name )
char *name;
{
    register RHOST *rh;
    if( (rh = (RHOST *)malloc( sizeof( RHOST ) )) == NULL ) {
	perror("mkrhost malloc failed");
	exit( 1 );
    } /* malloc failed */

    rh->rh_name = name;
    rh->rh_next = NULL;
    rh->rh_user = rh->rh_endu = NULL;

    return( rh );
} /* mkrhost */

LOCAL RUSER *mkruser( name )
char *name;
{
    register RUSER *ru;
    if( (ru = (RUSER *)malloc( sizeof( RUSER ) )) == NULL ) {
	perror("mkruser malloc failed");
	exit( 1 );
    } /* malloc failed */

    ru->ru_name = name;
    ru->ru_next = NULL;
    return( ru );
} /* mkruser */

GLOBAL void add4n( user, host )
char *user, *host;
{
    if( *host == EOS ) {
	fprintf(stderr, "?Empty hostname\n");
    }
    else {				/* has host */
	register RHOST *hp;		/* host pointer */

	for( hp = host_chain; hp != NULL; hp = hp->rh_next )
	    if( strcmp(hp->rh_name, host) == 0 )
	        break;

	if( hp == NULL ) {		/* search failed */
	    if( host_chain == NULL )	/* empty chain? */
	        host_chain = end_host_chain = hp = mkrhost( host ); /* make1 */
	    else {			/* add new host */
	        hp = mkrhost( host );	/* create node */
		end_host_chain->rh_next = hp; /* add after last */
		end_host_chain = hp;	/* point end to me */
	    } /* add new host */

	    hp->rh_user = hp->rh_endu = mkruser( user ); /* create usr chain */
	} /* search failed */
	else {				/* search won */
	    register RUSER *up;

	    up = mkruser( user );	/* create user node */
	    hp->rh_endu->ru_next = up;	/* add after last for this host */
	    hp->rh_endu = up;		/* point end of list to us */
	} /* add to existing chain (search won) */
    } /* non-empty host */

# ifdef DEBUG
    if( *user == EOS )
        printf(" @%s\n", host);
    else
        printf("%s@%s\n", user, host);
# endif /* DEBUG defined */
} /* add 4n */

GLOBAL BOOL islocalhost( s )
    char *s;
{
    struct hostent *h;
    char **a;

    if( strcmp( s, officialhostname ) == 0 || strcmp( s, localhost ) == 0 )
	return( TRUE );

    a = aliases;
    while( *a != NULL )
	if( strcmp( s, *a++ ) == 0 )
	    return( TRUE );

    if( (h = gethostbyname( s )) == NULL )
	return( FALSE );

    if( strcmp( h->h_name, officialhostname ) == 0 )
	return( TRUE );

    return( FALSE );
} /* islocalhost */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
