/*
 * output.h -- output defns for new finger
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# define OUTPUT_RCSID "$Id: output.h,v 3.0 90/07/06 13:11:31 budd Rel $"

# define MAXLINE 200
# define OUTPUT stdout

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
