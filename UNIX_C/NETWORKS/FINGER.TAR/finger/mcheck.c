/*
 * mcheck.c -- check for mail
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: mcheck.c,v 3.0 90/07/06 13:11:19 budd Rel $";
# endif /* lint not defined */

# include <sys/types.h>
# include <sys/stat.h>
# include <strings.h>
# include <errno.h>
# include <stdio.h>
# include <ctype.h>
# include "person.h"
# include "args.h"			/* before luser.h */
# include "luser.h"
# include "finger.h"

extern void add4n();			/* from args.c */

/*
 *	it is possible to detect aliasing by invoking sendmail -bv
 *	<user>. This checks .forward files too!!  but is of little use
 *	when the current host is a workstation or other mail moron
 *	that hands off all work to a server.
 *
 *	"ypmatch <user> aliases" DOES work, but no functions 
 *	are provided to access the mail.alias yp map.  TODO
 */

# define LEN 1024
GLOBAL void mcheck( u )
LUSER *u;
{
# ifdef MAIL_SPOOL
    BOOL nomailbox;
    char fname[LEN];
    struct stat stb;
    extern int errno;
    extern char *sys_errlist[];

# ifdef AIX_PS2
    if( u->u_person == NULL )
	return;
    strcpy(fname, u->u_person->p_home );
    strcat(fname, "/.newmail");
# else  /* AIX_PS2 not defined */
    strcpy(fname, MAIL_SPOOL );
    strcat(fname, "/");
    strcat(fname, u->u_user );
# endif /* AIX_PS2 not defined */

    nomailbox = FALSE;
    if( stat(fname, &stb) != 0 ) {
	switch( errno ) {
        case ENOENT:
	    nomailbox = TRUE;
	    break;

	case EPERM:
	    outline("  [Mail file protected]");
	    break;

	default:
	    sprintf(fname, "  [Funny mail file error (%s)]",
		    sys_errlist[errno] );
	    outline( fname );
	} /* switch */
    } /* stat failed */
    else {				/* stat ok */
	if( stb.st_size > 0  &&  stb.st_mtime >= stb.st_atime ) {
	    sprintf(fname, "  %s has new mail as of %s",
		    u->u_user, nicetime( stb.st_mtime ) );

	    if( stb.st_atime != stb.st_ctime ) { /* read since created */
		outline( fname );	/* output previous line */
		sprintf(fname, "  last read %s", nicetime( stb.st_atime ) );
	    }
	}
	else				/* empty or access after modify */
	    sprintf(fname, "  %s has no new mail, last read %s",
		    u->u_user, nicetime( stb.st_atime ) );
	outline( fname );
    } /* stat ok */

    if( u->u_person != NULL && u->u_person->p_maddr != NULL ) {
	sprintf(fname, "  [%s is forwarded to %s]",
		(nomailbox ? "Mail" : "New mail"),
		u->u_person->p_maddr );
	outline( fname );
    }
    else if( nomailbox )
	outline("  [No mail file]");
# endif /* MAIL_SPOOL defined */
} /* mcheck */

/**** THIS IS GROSS ****/

GLOBAL void maddr( p, uname )		/* get mailing address */
    PERSON *p;
    char *uname;			/* for possible alias hackery */
{
    register char *dp, *xp, *ap;
    char fname[ LEN ], obuf[ LEN*3 ], *sp;
    int room;
    FILE *f;

    /* try yp_match( domain, "mail.alias", name, namelen, valp, vallenp ) */

    strcpy( fname, p->p_home );
    strcat( fname, "/.forward" );
    f = fopen( fname, "r" );
    if( f == NULL )
	return;

    dp = obuf;				/* set dest ptr */
    room = sizeof( obuf );
    while( fgets( fname, sizeof( fname ), f ) != NULL ) {
	sp = fname;			/* set src ptr */

	for( ; ; ) {
	    if( !skipwhite( &sp ) )	/* eat whitespace */
		break;			/* nothing left? */

	    /* check for " / | \ */
	    if( room > 0 &&dp != obuf ) { /* not the first? */
		*dp++ = ',';
		room--;
	    }

	    xp = sp;			/* save start of addr */
	    while( *sp != EOS && !isspace( *sp ) && *sp != ',' )
		if( --room > 0 )
		    *dp++ = *sp++;	/* copy while not white */

	    if( *sp != EOS )		/* if not end of source */
		*sp++ = EOS;		/* tie off (blast/skip punct) */

	    if( sw_follow ) {
		if( (ap = rindex( xp, '@' )) != NULL ) /* have a host? */
		    *ap++ = EOS;	/* tie off host */

		if( *xp == '\\' )	/* backslash quoted username? */
		    xp++;		/* skip bs */

		if( *xp != '|' && *xp != '/' ) { /* not pipe or file */
		    char *pp;		/* percent ptr */

		    /* perhaps blast only the rightmost %? */
		    pp = xp;		/* blast all %'s in user into @'s */
		    while( (pp = index(pp, '%')) != NULL )
			*pp++ = '@';

		    if( ap != NULL && !islocalhost(ap) )
			add4n(savestr(xp), savestr(ap) ); /* user, host */
		    else if( strcmp( xp, uname ) != 0 ) { /* not me? */
			struct switches SavedSw;
			SavedSw = Sw;
			Sw.sw_match = TRUE;
			addlocal( savestr(xp) );
			Sw = SavedSw;
		    }
		} /* not pipe or file */
	    } /* sw_follow */
	} /* for ever */
    } /* read ok */
    *dp = EOS;				/* tie off */

    p->p_maddr = savestr( obuf );	/* fill in person's mailing address */

    close( f );
} /* maddr */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
