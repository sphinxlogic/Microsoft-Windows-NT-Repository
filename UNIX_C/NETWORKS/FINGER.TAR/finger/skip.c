/*
 * skip.c -- skip white and non (July 1987)
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: skip.c,v 3.0 90/07/06 13:11:43 budd Rel $";
# endif /* lint not defined */

# include <ctype.h>
# include "finger.h"

GLOBAL int skipwhite( cpp )
char **cpp;
{
    register char *cp = *cpp;
    while( *cp != EOS && isspace( *cp ) )
	cp++;
    *cpp = cp;
    if( *cp == EOS )
	return( FALSE );
    else
	return( TRUE );
} /* skipwhite */

GLOBAL int skipblack( cpp )
char **cpp;
{
    register char *cp = *cpp;
    while( *cp != EOS && !isspace( *cp ) )
	cp++;
    *cpp = cp;
    if( *cp == EOS )
	return( FALSE );
    else
	return( TRUE );
} /* skipblack */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
