/*
 * myecho.c -- avoid Sys V compatible echo (interprets \n) for make-version
 *
 * Copyright (C) 1988, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: myecho.c,v 3.0 90/07/06 13:11:21 budd Rel $";
# endif /* lint not defined */

# include <stdio.h>
# include "finger.h"

main( c, v )
    int c;
    char **v;
{
    int i, newline;
    c--;
    v++;

    newline = 1;
    if( strcmp( *v, "-n" ) == 0 ) {
	c--;
	v++;
	newline = 0;
    }
    while( c-- > 0 ) {
	if( i++ > 0 )
	    putchar(' ');
	printf("%s", *v++ );
    } /* for */
    if( newline )
	putchar('\n');
    exit( 0 );
} /* main */
