/*
 * remote.h -- structs for remote user input
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# define REMOTE_RCSID "$Id: remote.h,v 3.0 90/07/06 13:11:40 budd Rel $"

typedef struct rhost {
    char *rh_name;			/* host name */
    struct rhost *rh_next;		/* next host in chain */
    struct ruser *rh_user;		/* pointer to user chain */
    struct ruser *rh_endu;		/* end of user chain */
} RHOST;

typedef struct ruser {
    char *ru_name;			/* user name */
    struct ruser *ru_next;		/* next in chain */
} RUSER;

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
