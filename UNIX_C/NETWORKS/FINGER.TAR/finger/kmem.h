/*
 * kmem.h -- interface to kmem.c
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# define KMEM_RCSID "$Id: kmem.h,v 3.0 90/07/06 13:11:11 budd Rel $"

# if SunOS >= 400
# include <kvm.h>
# define FTYPE kvm_t *
# define KMEMREAD(p,b,l) kvm_read(kmem, p, b, l)
# define ISBADFILE(f) ((f) == NULL)
# else  /* not SunOS >= 400 */

# define BUFIO 0		/* total lose */

# if BUFIO
# define ISBADFILE(f) (f == NULL)
# define BADFILE NULL
# define FTYPE FILE *
# define OPEN(n) fopen(n, "r")
# define CLOSE(f) fclose(f)
# define READ(f,buf,cnt) fread(buf,cnt,1,f)
# define SEEK(f,o,w) fseek(f,o,w)
# define FILENO(f) fileno(f)
# else  /* not BUFIO */
# define ISBADFILE(f) (f < 0)
# define BADFILE -1
# define FTYPE int
# define CLOSE(f) close(f)
# define OPEN(n) open(n, 0)
# define READ(f,buf,cnt) read(f,buf,cnt)
# define SEEK(f,o,w) lseek(f,o,w)
# define FILENO(f) (f)
# endif /* not BUFIO */

# ifdef sgi
/* Bletch! remove K0BASE.  works for K0 and K2 addrs */
# define KVADDR(p) (((unsigned long)(p)) & ~0x80000000 )
# else  /* sgi not defined */
# define KVADDR(p) (p)
# endif /* sgi not defined */

# define KMEMREAD(p,b,l) kread(kmem, KVADDR(p), b, l)
# endif /* not SunOS >= 400 */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
