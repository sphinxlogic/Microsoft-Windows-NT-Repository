/*
 * Copyright (C) 1988, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# define INQUIRE_RCSID "$Id: inquire.h,v 3.0 90/07/06 13:11:07 budd Rel $"

# ifdef INQUIRE
# include "hakinq/helper.h"	/* PROTO() */
# include "hakinq/fields.h"
# include "hakinq/buffer.h"

# include "hakinq/person.h"	/* one or the other */
# include "hakinq/user.h"
# include "hakinq/lose.h"

# define INQ_INFO char **

# endif /* INQUIRE defined */
