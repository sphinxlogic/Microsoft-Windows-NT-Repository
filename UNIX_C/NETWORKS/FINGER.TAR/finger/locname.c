/*
 * locname.c -- create ttyloc file paths for ttyloc.c and finger
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: locname.c,v 3.0 90/07/06 13:11:15 budd Rel $";
# endif /* lint not defined */

# include "finger.h"

extern char localhost[];

LOCAL char *_locname(type, ttyname)
    char *type, *ttyname;
{
    static char buffer[200];
    sprintf(buffer, "%s/%s_%s_%s", TTYLOC_DIR, type, localhost, ttyname);
    return( buffer );
} /* _locname */

GLOBAL char *locname( ttyname )
    char *ttyname;
{
    return( _locname("ttyloc", ttyname ) );
} /* locname */

GLOBAL char *netlocname( ttyname )
    char *ttyname;
{
    return( _locname("netloc", ttyname ) );
} /* netlocname */


/*
 * Local variables:
 * comment-column: 40
 * End:
 */
