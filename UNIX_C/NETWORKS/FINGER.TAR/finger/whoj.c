/*
 * whoj.c -- whoj style output for finger
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: whoj.c,v 3.0 90/07/06 13:12:21 budd Rel $";
# endif /* lint not defined */

# include <sys/types.h>
# include <stdio.h>
# include "output.h"
# include "args.h"			/* for luser.h */
# include "luser.h"
# include "finger.h"
# include "pr.h"

extern LUSER *maketree();		/* from getent.c */
extern struct pr *getcommand();		/* from getcommand.c */
extern char *gtname();			/* from XXX */
extern void ptree();			/* from XXX */

static int whoj_termw;			/* whoj terminal name width */
static int whoj_userw;			/* whoj user name width */
static time_t now;			/* current time */

LOCAL void whojwidth();			/* forward */
LOCAL void whojuser();			/* forward */

GLOBAL void dowhoj() {
    LUSER *t;

    time( &now );			/* get current time */
    t = maketree();			/* build tree of utmp entries */
    whoj_termw = whoj_userw = -1;
    ptree( t, whojwidth );		/* figure widths */
    ptree( t, whojuser );		/* print tree */
} /* whoj */

LOCAL int max(a, b)
int a, b;
{
    if( a > b )
	return( a );
    else
        return( b );
} /* max */

LOCAL void whojwidth( u )
LUSER *u;
{
    char *tn;
    int tnl;

    if( u->u_host[0] == EOS ) {		/* no host? */
	tn = gtname( u->u_line );	/* remove tty from line name */
	tnl = strlen( tn );
	if( tn != u->u_line )		/* it did? */
	    tnl++;			/* yes, add back a 't' */
    }
    else {
	undomain( u->u_host, TRUE ); 	/* remove domains and prefixes */
        tnl = strlen( u->u_host );
    }

    whoj_termw = max( tnl, whoj_termw );
    whoj_userw = max( strlen( u->u_user ), whoj_userw );
} /* whojwidth */

LOCAL void whojuser( u )
LUSER *u;
{
    struct pr *pr;
    char line[MAXLINE],			/* output line */
    	*tn,				/* return from gtname */
    	tname[20],			/* terminal name to output */
        *cmd;				/* command to output */

    line[0] = EOS;
    if( u->u_host[0] == EOS ) {
	tn = gtname( u->u_line );
	if( tn != u->u_line ) {
	    tname[0] = 't';
	    strcpy(&tname[1], tn);
	    tn = tname;
	}
    }
    else
        tn = u->u_host;

    termstat( u );			/* needed for getcommand */
    pr = getcommand( u );
    if( pr != NULL )
	cmd = pr->pr_cmd;
    else
	cmd = "?";

    sprintf(line,
	    "%*s  %*s  %s",
	    -whoj_termw,
	    tn,
	    -whoj_userw,
	    u->u_user,
	    cmd
	    );
    outline(line);
} /* whojuser */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
