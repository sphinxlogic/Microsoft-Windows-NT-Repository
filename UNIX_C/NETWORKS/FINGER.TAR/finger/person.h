/*
 * person.h -- person structure for finger (per username)
 *	December 1985
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# define PERSON_RCSID "$Id: person.h,v 3.0 90/07/06 13:11:32 budd Rel $"

# ifdef _PERSON_
	OOPS!!			/* loaded twice, or luser.h loaded first!! */
# endif /* _PERSON_ defined */
# define _PERSON_		/* say we have loaded! */

# define PLEN 33		/* personal name length */

typedef struct person {
    short p_count;		/* use count */
    short p_uid, p_gid;		/* user id, group id */

    short p_flags;
# define P_RC		01	/* gecos == "RC" */
# define P_INQUIRE	02	/* data came from inquire/holmes */
# define P_NOPWENT	04	/* no passwd entry */

    char *p_home;		/* home directory */
    char *p_shell;		/* default shell */

    char *p_personal;		/* personal name */
    char *p_waddr;		/* work address */
    char *p_wphone;		/* work phone */
    char *p_hphone;		/* home phone */

/* below here not from password file */
    char *p_project;		/* first line of .project */
    char *p_maddr;		/* mailing address (from .forward) */

/* below here from inquire database */
    char *p_supervisor;		/* yes */
    char *p_nickname;		/* what I like to be called */
    char *p_birthday;		/* yes */
    char *p_haddr;		/* home address */
    char *p_remarks;		/* clever stuff here */
    char p_group;		/* user group */
    char p_relation;		/* relation to group */
} PERSON;

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
