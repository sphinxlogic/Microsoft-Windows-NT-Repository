/*
 * whois -- user info output for new finger
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: whois.c,v 3.0 90/07/06 13:12:18 budd Rel $";
# endif /* lint not defined */

# include "finger.h"
# include <sys/types.h>
# include <sys/stat.h>
# include <sys/time.h>
# include <strings.h>
# include <stdio.h>
# include <ctype.h>
# if defined(AUX) || defined(AIX3)
# include <time.h>			/* bus-ted */
# endif /* defined(AUX) || defined(AIX3) */
# include <pwd.h>
# include <grp.h>
# include "person.h"
# include "args.h"			/* sw_its (before luser.h) */
# include "luser.h"
# include "output.h"

EXTERN void outline();			/* from output.c */
EXTERN char *acct_name();		/* from conf.c */
EXTERN char *office();			/* from acct.c */
EXTERN struct group *getgrent();	/* USG grp.h loses */

FORWARD GLOBAL char *nicetime();

LOCAL char line[MAXLINE];

LOCAL void newline() {
    if( line[0] != EOS ) {
	outline( line );
	line[0] = EOS;
    } /* non-empty */
} /* newline */

LOCAL void checksemi() {
    if( line[0] != EOS )
	strcat(line, ";");
} /* checksemi */

GLOBAL void whois( u )
register LUSER *u;
{
    char tbuf[ 100 ];
    register PERSON *p;
    struct group *gr;
    char **members, *acctname;

    line[0] = EOS;

    p = u->u_person;		/* get person structure */
    if( p != NULL ) {
	if( p->p_nickname != NULL ) {
	    strcat(line, "  (");
	    strcat(line, p->p_nickname);
	    strcat(line, ")");
	} /* nickname */

# ifdef notdef				/* shown below (in mcheck) */
	if( p->p_maddr != NULL ) {
	    strcat(line, "  [" );
	    strcat(line, p->p_maddr );
	    strcat(line, "]");
	} /* mail address */
# endif /* notdef defined */

	acctname = acct_name( p );
	if( p->p_project != NULL || p->p_supervisor != NULL ||
	   acctname != NULL ) {
# ifdef DONT_SAY_HACKING		/* some people confuse hackers */
	    strcat(line, "  working ");	/* and crackers!! */
# else  /* DONT_SAY_HACKING not defined */
	    strcat(line, "  Hacking ");
# endif /* DONT_SAY_HACKING not defined */
	    if( p->p_project != NULL ) {
# ifdef DONT_SAY_HACKING
		strcat(line, " on ");
# endif /* DONT_SAY_HACKING defined */
		strcat(line, p->p_project);
		strcat(line, " ");
	    } /* project */
	    if( p->p_supervisor != NULL || acctname != NULL ) {
		strcat(line, "for ");
		if( p->p_supervisor != NULL )
		    strcat(line, p->p_supervisor);
		else {
		    strcat(line, acctname ); /* *TODO* do this in getperson? */
		    acctname = NULL;	/* don't repeat this! */
		}
	    } /* super */
	} /* project or super */

	newline();

	if( p->p_birthday != NULL ) {
	    strcat(line, "  Birthday ");
	    strcat(line, p->p_birthday);
	} /* birthday */

	if( p->p_waddr != NULL || p->p_wphone != NULL ) {
	    checksemi();
	    strcat(line, "  Work ");
	    if( p->p_waddr != NULL ) {
		strcat(line, p->p_waddr );
		if( p->p_wphone != NULL ) {
		    strcat(line, "; ");
		    catphone(line, p->p_wphone );
		} /* waddr and wphone */
	    } /* one of waddr and wphone */
	    else
		catphone(line, p->p_wphone);
	} /* work address or phone */

	newline();

	if( p->p_haddr != NULL || p->p_hphone != NULL ) {
	    strcat(line, "  Home ");
	    if( p->p_haddr != NULL ) {
		strcat(line, p->p_haddr );
		if( p->p_hphone != NULL ) {
		    strcat(line, "; ");
		    catphone(line, p->p_hphone );
		} /* addr and phone */
	    } /* one of addr and phone */
	    else
		catphone(line, p->p_hphone);
	} /* home address or phone */

	/**************** dull stuff ****************/
	newline();
	if( p->p_home != NULL ) {
	    struct passwd *pw;
	    char *acn;

	    sprintf(tbuf, "  [%d,%d]", p->p_uid, p->p_gid );
	    strcat(line, tbuf);

	    strcat(line, "  <");
	    strcat(line, p->p_home);
	    strcat(line, ">");

	    acn = NULL;
	    if( (gr = getgrgid( p->p_gid )) != NULL )
		acn = gr->gr_name;
# ifndef NO_COMMON_NAMESPACE		/* uid's and gid's use same names @bu */
	    else if( (pw = getpwuid( p->p_gid )) != NULL ) /* NOTE: gid! */
		acn = pw->pw_name;
# endif /* NO_COMMON_NAMESPACE not defined */
	    else
		acn = acctname;

	    if( acn != NULL ) {
		checksemi();
		strcat(line, "  Group: ");
		strcat(line, acn );
	    }
	    if( p->p_shell != NULL ) {
		strcat(line, "  Shell: ");
		strcat(line, p->p_shell);
	    } /* unusual shell */
	} /* has home (password entry) */

	newline();
    } /* has person struct */

    setgrent();
    tbuf[0] = EOS;
    while( (gr = getgrent()) != NULL ) {
	for( members = gr->gr_mem; *members != NULL; members++ ) {
	    if( strcmp( u->u_user, *members ) == 0 ) {
		strcat( tbuf, " " );	/* add a space */
		strcat( tbuf, gr->gr_name ); /* add name */
		break;
	    } /* match */
	} /* while members */
    } /* while gr */
    endgrent();

    if( tbuf[0] != EOS ) {
	strcpy(line, "  Groups:");
	strcat(line, tbuf );
	newline();
    } /* found groups */

} /* whois */

# define PLANBUFLEN 200
GLOBAL BOOL plan( u )
LUSER *u;
{
    char buf[PLANBUFLEN];
    struct stat st;
    PERSON *p;
    FILE *f;

    if( (p = u->u_person) == NULL || p->p_home == NULL || p->p_home[0] == EOS )
	return( FALSE );

    strcpy(buf, p->p_home);
    strcat(buf, "/.plan");

    if( (f = fopen(buf, "r")) == NULL )
        return( FALSE );

    if( fstat( fileno(f), &st ) < 0 )
	outline("  Plan:");
    else {
	sprintf( buf, "  Plan: (last modified %s)", nicetime( st.st_mtime ) );
	outline( buf );
    }

    while( fgets(buf, PLANBUFLEN, f) != NULL ) {
	register char *cp;
	if( (cp = index(buf, '\n')) != NULL )
	    *cp = EOS;
# ifndef DONT_TAB_PLAN
	outchar('\t');
# endif /* DONT_TAB_PLAN not defined */
	outline( buf );
    } /* while */
    fclose( f );
    return( TRUE );
} /* plan */

LOCAL char *weekday[] = {
    "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"
};

LOCAL char *month[] = {
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
};

GLOBAL char *nicetime( t )
time_t t;
{
    struct tm *tm, *localtime();
    static char buffer[100];
    char *am;
    int hour;

    tm = localtime( &t );
    if( sw_its ) {			/* format date/time like ITS */
	sprintf( buffer, "%02d/%02d/%02d %02d:%02d:%02d",
		tm->tm_mon+1, tm->tm_mday, tm->tm_year,
		tm->tm_hour,  tm->tm_min, tm->tm_sec );
	return( buffer );
    } /* ITS */

    hour = tm->tm_hour;
    am = "AM";
    if( hour == 0 )			/* fix midnight */
	hour = 12;
    else if( hour > 11 ) {		/* after 11AM */
	am = "PM";			/* its after-noon */
	if( hour > 12 )			/* but don't touch 12!! */
	    hour -= 12;
    } /* PM */

    sprintf(buffer, "%s %d-%s-%d %d:%02d%s",
	    weekday[tm->tm_wday], tm->tm_mday,
	    month[tm->tm_mon], tm->tm_year,
	    hour, tm->tm_min, am);

    return( buffer );
} /* nicetime */

GLOBAL void remarks(u)
LUSER *u;
{
    PERSON *p;
    register char *cp;

    p = u->u_person;
    if( p != NULL && p->p_remarks != NULL ) {
	cp = p->p_remarks;
	while( *cp != EOS )
	    outchar( *cp++ );
    } /* have person and remarks */
} /* remarks */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
