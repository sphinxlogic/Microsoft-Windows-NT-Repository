/*
 * switch.h -- switch definitions for finger
 *
 * Copyright (C) 1987, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# define SWITCH_RCSID "$Id: switch.h,v 3.0 90/07/06 13:11:50 budd Rel $"

/* string, unique length, action(routine in args.c), help */
SWITCH("age",	    1,set_age,	"display job age rather than idle time")
SWITCH("berkeley",  1,set_berkeley,"user names imply /plan/whois")
# ifdef DEBUGSW
SWITCH("debug",	    1,set_debug,"enable debug output")
# endif /* DEBUGSW defined */
# ifdef notdef
SWITCH("fields",    2,set_fields,"output for awk /fields[:sep] sets FS")
# endif /* notdef defined */
SWITCH("follow",    2,set_follow,"let finger do the walking (follow .forward)")
SWITCH("help",	    1,display_help,"display help (you are looking at it)")
SWITCH("its",	    1,set_its,"format output more like MIT-ITS finger")
SWITCH("location",  1,set_location,"ignore user set ttylocs")
SWITCH("mail-check",3,set_mail,	"show information about mail file")
SWITCH("match-user",1,set_match,"match on user name only")
# ifdef INQUIRE
SWITCH("noinquire", 1,set_noinquire,"prohibit using inquire database")
# endif /* INQUIRE defined */
SWITCH("noplan",    3,set_noplan,"prohibit plan display")
# ifdef SAVED_NLIST
SWITCH("nosave-nlist",3,set_nosave,"prohibit saving of /vmunix namelist file")
# endif /* SAVED_NLIST defined */
SWITCH("output-idle",1,set_output,"show time since last output to terminal")
SWITCH("plan-check",1,set_plan,	"show plan files")
SWITCH("pid",	    2,set_pid,	"show process id")
# ifdef SAVED_NLIST
SWITCH("read-nlist",1,set_read, "force reading of /vmunix namelist file")
# endif /* SAVED_NLIST defined */
SWITCH("short",	    1,set_jobs,	"short form (same as /jobs)")
SWITCH("state",	    1,set_state,"display process state in place of idle time")
SWITCH("user-match",1,set_match,"alias for /match-user")
SWITCH("whois",	    1,set_whois,"display personal info (whois command)")
SWITCH("whoj",	    4,set_jobs, "alias for /short")
SWITCH("version",   1,display_version, "display version")

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
