/*
 * getgroup.c -- report file group ID for autoconfig
 *
 * Copyright (C) 1988, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: getgroup.c,v 3.0 90/07/06 13:10:49 budd Rel $";
static char Copyright[] = "Copyright (C) 1986, 1990  Philip L. Budne";
# endif /* lint not defined */

# include <sys/types.h>
# include <sys/stat.h>
# include <stdio.h>
# include <grp.h>
/* cannot use finger.h -- run from autoconfig */

extern struct group *getgrgid();	/* USG grp.h loses */

int
main( c, v )
    int c;
    char **v;
{
    struct stat st;
    struct group *gr;

    if( c < 1 ) {
	fprintf( stderr, "Usage %s file\n", v[0] );
	exit( 1 );
    }
    c--;
    v++;
    while( c > 0 ) {
	if( stat( v[0], &st ) < 0 )
	    perror( v[0] );
	else if( (gr = getgrgid( st.st_gid )) != NULL )
	    printf("%s %d %s\n", v[0], st.st_gid, gr->gr_name );
	else
	    printf("%s %d\n", v[0], st.st_gid );
	c--;
	v++;
    }
    return( 0 );			/* be ANSI */
} /* main */
