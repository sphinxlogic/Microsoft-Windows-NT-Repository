/*
 * uptime.c -- /usr/ucb/uptime replacement for USG systems
 *
 * Copyright (C) 1989, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: uptime.c,v 3.0 90/07/06 13:12:10 budd Rel $";
# endif /* lint not defined */

# include <stdio.h>
# include <sys/types.h>
# include <time.h>
# include <utmp.h>

main() {
    struct utmp *ut;
    time_t boot, now;
    struct tm *tm;
    int users, hour, min, day, items;
    char am;

    users = boot = 0;
    setutent();
    while( (ut = getutent()) )
	switch( ut->ut_type ) {
	case BOOT_TIME:
	    boot = ut->ut_time;
	    break;
	case USER_PROCESS:
	    users++;
	    break;
	}

    time( &now );
    tm = localtime( &now );

    hour = tm->tm_hour;
    am = 'a';
    if( hour == 0 )			/* fix midnight */
	hour = 12;
    else if( hour > 11 ) {		/* after 11AM */
	am = 'p';			/* its after-noon */
	if( hour > 12 )			/* but don't touch 12!! */
	    hour -= 12;
    } /* pm */
    printf("%2d:%02d%cm  ", hour, tm->tm_min, am );

    items = 0;
    if( boot != 0 ) {
	int min, day;
	boot = now - boot;		/* get time since boot */
	boot /= 60;			/* get minutes */

	min = boot % 60;
	boot /= 60;			/* toss mins */

	hour = boot % 24;		/* get hours */
	boot /= 24;

	day = boot % 7;
	boot /= 7;

	printf("up ");

# define PUTF(what,n)\
	{ if( items++ > 0 ) { putchar(','); putchar(' '); } \
	printf("%d %s", n, what); if( n != 1 ) putchar('s'); }

	if( boot > 0 )
	    PUTF("week", boot );

	if( day > 0 )
	    PUTF("day", day );

	if( hour > 0 )
	    PUTF("hour", hour );

	if( min > 0 )
	    PUTF("minute", min );
    } /* have boot */

    PUTF("user", users );
    putchar('\n');
}
