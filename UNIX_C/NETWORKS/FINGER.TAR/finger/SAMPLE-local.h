/*
 *	local.h for bu-it
 *	created on Thu May 17 21:58:00 EDT 1990 by budd using autoconfig
 */

/* local-flags: *****************/
/* local-flags for bu-it */

/*
# define INQUIRE
*/

# define C_COMPILER gcc
# if 1
# define C_FLAGS -g -O
# else  /* not 1 */
# define C_FLAGS -W -Wreturn-type -Wunused -Wswitch -Wshadow -Wpointer-arith -Wcast-qual -Wpointer-arith -Wcast-qual -Dlint -g
# endif /* not 1 */

# define DEBUGSW		/* include /debug switch */
# define UNPREFIX_NODOMAIN 	/* unprefix hosts with no dots */
/* end of local-flags ***********/

# define SunOS 403

# define IN_DOT_DAEMON	/* internet daemon names prefixed with in. */

# define LASTLOG			/* BSD last login file */

# define SWAP_DEVICE "/dev/drum"	/* swap device */

# define UNDERSCORE_NLIST_NAMES

# define STREAMS

# define SHORT_TTYP


# define TTY_GROUP_NUMBER 4

# define TTY_GROUP "tty"

/* for Install.cpp */
# define KMEM_GROUP kmem

/* getpwnam(3) is fast (yellow pages) */

# define HAVE_YP_MATCH			/* have yp_match(3) */

# define ALIASES "/etc/aliases"	/* sendmail aliases file */

# define TTYENT				/* use getttyent(3) */

# define INETD				/* use inetd for fingerd */

# define VOIDSIG			/* signal() declared as void * */

/* utmp has ut_host field */

# define KERNEL_FILE "/vmunix"

# define MAIL_SPOOL "/usr/spool/mail"

# define SYSLOG				/* fingerd does syslog-ing */

# define SAVED_NLIST "/etc/finger-saved-nlist" /* save nlist to this file */

# define AUTONLIST			/* update nlist save file as needed */

# define NLIST_MODE 0664		/* creation mode for nlist file */

# define NETBERK			/* network finger implies /berk */
					/* (I hate this) */

# define NETFOLLOW			/* net finger implies /follow */

/**************** REQUIRED!! (used by Install) ****************/

# define TTYLOC_DIR "/usr/spool/ttyloc"

# define TTYLOC_MODE 0644

/* extra paths to try to exec finger */
/* # define FINGERPATHS "/usr/local/local/bin/finger", "/bin/who" /*  */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
