/*
 * getttytype.c -- get tty type for a line (July 1987)
 *
 * Copyright (C) 1987, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: getttytype.c,v 3.0 90/07/06 13:10:56 budd Rel $";
# endif /* lint not defined */

# include <stdio.h>
# include "finger.h"

# ifdef TTYENT

# include <ttyent.h>

GLOBAL char *getttytype( tty )
char *tty;
{
    register struct ttyent *ty;
    register char *type;

    setttyent();
    if( (ty = getttynam( tty )) == NULL )
	type = NULL;
    else
	type = ty->ty_type;

    endttyent();
    return( type );
} /* 4.3 getttytype */

# else  /* TTYENT not defined */

# include <strings.h>

GLOBAL char *getttytype( tty )
char *tty;
{
    FILE *f;
    char line[ 512 ];
    char *cp, *type;
    register char *sp;

    if( (f = fopen("/etc/ttytype", "r")) == NULL )
	return( NULL );

    type = NULL;			/* be realistic */
    while( fgets( line, sizeof( line ), f ) != NULL ) {
	cp = line;
	if( !skipwhite( &cp ) )
	    continue;

	type = cp;
	if( !skipblack( &cp ) )
	    continue;
	*cp++ = EOS;			/* tie off type */

	if( !skipwhite( &cp ) )		/* eat white. */
	    continue;

	if( (sp = index(cp, '\n')) != NULL ) /* kill eol */
	    *sp = EOS;

	if( strcmp( cp, tty ) != 0 ) {	/* match tty name? */
	    type = NULL;
	    continue;			/* no, back to work */
	}
	break;
    } /* while */
    fclose( f );
    return( type );
} /* 4.2 getttytype */
# endif /* TTYENT not defined */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
