/*
 * string.c -- common string routines for finger (December 1985)
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: string.c,v 3.0 90/07/06 13:11:46 budd Rel $";
# endif /* lint not defined */

# include <ctype.h>			/* for isxxx */
# include <stdio.h>			/* for NULL */
# include <strings.h>			/* for strcpy() */
# include "finger.h"
# include "upper.h"			/* uppercase[] */

GLOBAL char *strip( s )
register char *s;
{
    register char *cp;

    for( cp = s; isprint( *cp ); cp++ )	/* skip printing chars */
	;
    *cp = EOS;				/* tie off after printables */

    while( cp > s )			/* backup */
	if( isspace( *(cp - 1) ) )	/* is previous a space? */
	    cp--;			/* yes, keep going */
	else
	    break;
    *cp = EOS;				/* tie off before spaces */

    for( cp = s; isspace( *cp ); cp++ )	/* start at top */
	;				/* skipping spaces */

    return( cp );			/* return remainder */
} /* strip */

GLOBAL void cleanup( s )	/* strip off leading white, trailing crud */
register char *s;		/* in place */
{
    register char *cp;

    for( cp = s; isprint( *cp ); cp++ ) ; /* cut off any crud.. */
    *cp = EOS;

    for( cp = s; *cp != EOS && isspace( *cp ); cp++ ); /* trim leading white */

    if( cp != s )		/* leading white? */
	if( *cp == EOS )
	    *s = EOS;		/* empty string!! */
	else
	    strcpy(s, cp);	/* copy backwards to remove leading white */
} /* cleanup */

GLOBAL char *zup( s )		/* blast in place to upper */
char *s;
{
    register char *cp;
    for( cp = s; *cp != NULL; cp++ )
	    *cp = uppercase[ *cp & 0177 ];

    return( s );
} /* zup */

GLOBAL char *strzcpy(dest, src, count)	/* non-nul terminated src, max length */
register char *dest, *src;
register int count;
{
    while( count-- > 0  &&  *src != EOS )
	*dest++ = *src++;

    *dest = EOS;
    return( dest );
} /* strzcpy */


GLOBAL char *strupcpy(dest, src)	/* copy and uppercasify */
register char *src, *dest;
{
    register int c;

    do
	*dest++ = uppercase[ (c = *src++ & 0177) ];
    while( c != EOS );
    return( dest );
} /* strupcpy */

GLOBAL char *savestr( s )
char *s;
{
    char *d;

    if( s == NULL )
	return( NULL );			/* note: NOT "" (see alias copy loop) */
					/* in args.c */

    if( (d = malloc( strlen( s ) + 1 )) == NULL ) {
	fprintf(stderr, "?Savestr failed for '%s'\n", s);
	exit( 1 );
    }
    return( strcpy(d, s) );
} /* savestr */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
