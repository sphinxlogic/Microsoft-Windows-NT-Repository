/*
 * args.h -- flag/switch definitions
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# define ARGS_RCSID "$Id: args.h,v 3.0 90/07/06 13:10:20 budd Rel $"

# ifndef EXTERN
# define EXTERN extern
# endif /* EXTERN not defined */

/* global (not per-person) switches */
typedef char sw_t;

EXTERN sw_t sw_age;		/* age switch */
				/* display on rather than idle */
EXTERN sw_t sw_berkeley;	/* be like bzerkly finger */
				/* (force -w -p with names) */
EXTERN sw_t sw_debug;		/* enable debug output */
EXTERN sw_t sw_follow;		/* let finger do the walking */
				/* cudos to CTorek for the idea */
EXTERN sw_t sw_its;		/* be more like ITS (default is Twenex; */
EXTERN sw_t sw_jobs;		/* do whoj display */
EXTERN sw_t sw_nosave;		/* prohibit write of nlist */
				/* this is forced on by 'xf' */
EXTERN sw_t sw_output;		/* display idle time based on last output */
EXTERN sw_t sw_pid;		/* show current process pid */
EXTERN sw_t sw_read;		/* force read of nlist, and save */
				/* do this from your rc file */
				/* if you don't use AUTONLIST */
EXTERN sw_t sw_state;		/* show process state in place of idle */
EXTERN sw_t sw_whois;		/* whois switch -- show long information */

EXTERN char *sw_fields;		/* NYI: display output in AWKable form */

/****************
 * flags processed per-user
 */

EXTERN struct switches {
    int sw_location	: 1;	/* ignore user location */
    int sw_mail		: 1;	/* force mail check */
    int sw_match	: 1;	/* match on usernames only */
    int sw_noplan	: 1;	/* prhibit display of plan under /whois */
    int sw_plan		: 1;	/* check for ~/.plan file */
} Sw;

/*
 * Local variables:
 * comment-column: 32
 * End:
 */
