/*
 * pversion -- display finger version for build procedure
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# include "finger.h"
# include "History.h"

# ifndef lint
static char *history_rcsid = HISTORY_RCSID;
static char *rcsid = "$Id: pversion.c,v 3.0 90/07/06 13:11:35 budd Rel $";
# endif /* lint not defined */

int main() {
    printf("%o", ver.major );
    if( ver.minor != 0 ) {
	int m1;
	if( ver.minor > 25 ) {
	    m1 = ver.minor / 26;
	    if( m1 > 26 )
		m1 = 26;
	    printf("%c", 'A' + m1 - 1 );
	    ver.minor %= 26;
	} /* more than one letter? */
	printf("%c", 'A' + ver.minor - 1 );
    } /* minor version */
    printf("(%o)", ver.edit );
    if( ver.who != 0 )
	printf("-%o", ver.who );
    puts("");
    return( 0 );			/* be a good ANSI program */
} /* main */
