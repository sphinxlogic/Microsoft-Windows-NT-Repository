/*
 * newmanifest.c -- crock to merge MANIFEST descriptions with file list
 *
 * Copyright (C) 1989, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: newmanifest.c,v 3.0 90/07/06 13:11:25 budd Rel $";
# endif /* lint not defined */

# include <stdio.h>
# include <ctype.h>
# include <strings.h>			/* I'm sorry for you if you use USG! */

# define MAXFILES 5000			/* seems like plenty */
# define MAXSTR 100

struct file {
    char fname[ MAXSTR ];
    int archive, found;
    char descrip[ MAXSTR ];
} files[ MAXFILES ];			/* should use a binary tree. */
int nfiles = 0;

# define MANIFEST "MANIFEST"

char *prog;

int
main( argc, argv )
    int argc;
    char *argv[];
{
    FILE *m;
    char line[ 1024 ];
    int i;

    prog = argv[0];
    argc--;
    argv++;

    if( (m = fopen(MANIFEST, "r")) == NULL ) {
	perror( MANIFEST );
    }
    else {
	int skip = 2;

	while( fgets( line, sizeof( line ), m ) != NULL )
	    if( skip > 0 )
		skip--;
	    else {
		char *cp, *dp;
		if( (cp = index( line, '\n' )) != NULL )
		    *cp = '\0';
		else
		    fprintf( stderr, "line truncated!!\n" );

		cp = line;
		if( isspace( *cp ) )
		    cp++;
		if( *cp == '\0' )
		    continue;

		dp = files[ nfiles ].fname;
		while( *cp != '\0' && !isspace( *cp ) )
		    *dp++ = *cp++;
		if( dp == files[ nfiles ].fname )
		    continue;

		while( isspace( *cp ) )
		    cp++;

		files[ nfiles ].archive = atoi( cp ); /* who cares!! */
		while( isdigit( *cp ) )	/* skip past archive number */
		    cp++;

		while( isspace( *cp ) )	/* skip any whitspace */
		    cp++;

		dp = files[ nfiles ].descrip;
		while( *dp++ = *cp++ )	/* save any description */
		    ;

		files[nfiles].found = 0; /* not found yet */
		nfiles++;
	    } /* not skipping */
    } /* while */

    /* perhaps qsort files[] so we can binary search? */
    /* perhaps store in a binary tree so we can insert easily? */
    /* don't you wish you used C++?? Looks like line noise to me tho.... */
    /* do we really care? how big is this kit anyway??? */

    while( argc > 0 ) {
	for( i = 0; i < nfiles; i++ )	/* awful linear search */
	    if( strcmp( files[i].fname, argv[0]) == 0 ) {
		files[i].found = 1;	/* now can see (was blind) */
		break;
	    }
	if( i == nfiles ) {		/* not found in MANIFEST? */
	    strcpy( files[i].fname, argv[0] ); /* add it to list */
	    strcpy( files[i].descrip, "" ); /* sorry. */
	    files[i].archive = 999;	/* very silly kit number */
	    files[i].found = -1;	/* flag as just added */
	    nfiles++;
	    fprintf( stderr, "adding %s\n", argv[0] );
	} /* not previously in list */
	argc--;
	argv++;
    } /* while argc */

    /* I'm so lazy, should fopen output file, not use stdout! */
    puts("this was created by newmanifest.");
    puts("   File Name		Archive #	Description");

    /* less than perfect formatting. will be re-read by makekit soon */
    for( i = 0; i < nfiles; i++ )
	if( files[i].found != 0 )	/* found in argv[] */
	    printf(" %-25s %d\t%s\n",
		   files[ i ].fname,
		   files[ i ].archive,
		   files[ i ].descrip );
	else				/* not found... */
	    fprintf( stderr, "flushing %s\n", files[i].fname );
    return( 0 );			/* Be ANSI */
} /* main */
