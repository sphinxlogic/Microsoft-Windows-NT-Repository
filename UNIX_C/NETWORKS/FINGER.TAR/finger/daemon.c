/*
 * daemon.c -- Different things that can parent a shell -- January 1988
 *
 * Copyright (C) 1988, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: daemon.c,v 3.0 90/07/06 13:10:29 budd Rel $";
# endif /* lint not defined */

# include "finger.h"
# include "daemon.h"

struct daemon daemons [] = {
    /* cmd		short		long */

# ifdef sun
# if SunOS >= 400
    {"cmdtool",		"cmdtool",	"SunView (cmdtool)" },
# endif /* SunOS >= 400 */
    {"suntools",	"suntools",	"SunView (suntools)" },
    {"vt100tool",	"vt100tool",	"SunView (vt100tool)" },
    {"othertools",	"othertools",	"SunView (othertools)" },
    {"dbxtool",		"dbxtool",	"SunView (dbxtool)" }, /* use ptys? */
    {"dnalogind",	"DNA",		"DNA login" },	/* Sun DECnet? */
    {"dnaserver",	"DNI",		"Sunlink/DNI" }, /* ditto? */
    {"psterm",		"NeWs",		"NeWs Window" },
# endif /* sun defined */

# ifdef IN_DOT_DAEMON
    {"in.rlogind",	"rlogin",	"Remote Login" },
    {"in.telnetd",	"telnet",	"Telnet" },
    {"in.supdupd",	"supdup",	"Supdup" },
    {"in.rshd",		"rsh",		"Remote Shell" },
# else  /* IN_DOT_DAEMON not defined */
    {"rlogind",		"rlogin",	"Remote Login"},
    {"telnetd",		"telnet",	"Telnet" },
    {"supdupd",		"supdup",	"Supdup" },
    {"rshd",		"rsh",		"Remote Shell" },
# endif /* IN_DOT_DAEMON not defined */

# ifdef ultrix
    {"dlogin",		"dlogin",	"DECnet Login" },
    {"dlogind",		"dlogin",	"DECnet Login" },
    {"dtermd",		"dterm",	"DECnet Terminal" }, /* cterm? */
    {"dnet_spawner",	"decnet",	"DECnet" },	/* SNH? */
    {"telnet.gw",	"telnet",	"Telnet GW" },	/* SNH? */
    {"dxterm",		"dxterm",	"X window" },
# endif /* ultrix defined */

# ifdef sgi
    {"wsh",		"wsh",		"NeWs Window"},
    {"grcond",		"grcond",	"Graphics Console"},
# endif /* sgi defined */

# if defined(AIX_RT) || defined(AIX_PS2) || defined(AIX3)
    {"aixterm",		"aixterm",	"X Window" },	/* no host in utmp */
# endif /* defined(AIX_RT) || defined(AIX_PS2) || defined(AIX3) */

    {"xterm",		"xterm",	"X Window" },	/* no host in utmp */


    {"inetd",		"inet",		"Internet" },	/* SNH */

    /* **************** put under ifdefs? **************** */

    /* 4.3 XNS */
    {"GAP3d",		"GAP3",		"XNS GAP3" },
    {"xnscourierd",	"XNS",		"XNS Courier" }, /* snh */

    /* MIT Chaosnet */
    {"TELNET",		"chtn",		"Chaos Telnet" },
    {"SUPDUP",		"chsupdup",	"Chaos" },	/* ever get this? */
    {"chserver",	"chaos",	"Chaosnet" },	/* snh */

    /* Stanford PUP - Bill Nowicki and Jeff Mogul */
    {"telser",		"pup",		"PUP" },

# ifdef LOCAL_DAEMONS
    LOCAL_DAEMONS,
# endif /* LOCAL_DAEMONS defined */

    {0, 0, 0}
}; /* daemons[] */

/*
 * Local variables:
 * comment-column: 56
 * End:
 */
