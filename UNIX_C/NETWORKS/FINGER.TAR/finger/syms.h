/*
 * syms.h -- names to lookup via nlist
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# define SYMS_RCSID "$Id: syms.h,v 3.0 90/07/06 13:11:53 budd Rel $"

# ifndef _FINGER_H_
# include "finger.h"
# endif /* _FINGER_H_ not defined */

# ifndef _SYMS_H_
# define _SYMS_H_
# ifdef sgi
# define HAVE_KERNEL_MAGIC
# endif /* sgi defined */
# ifndef USG
# define HAVE_VERSION
# endif /* USG not defined */
# endif /* _SYMS_H_ not defined */

/*
 *	First argument is string for nlist.
 *	Second argument is string for nlist on COFF systems
 *	Third is member name for Info struct
 */

    SYM("_proc","proc",proc)		/* process table (or pointer) */
# if SunOS < 410
    SYM("_u","u",u)			/* u struct (for pause sleep addr) */
# else  /* not SunOS < 410 */
    SYM("_kernelmap","u",u)			/* u struct (for pause sleep addr) */
# endif /* not SunOS < 410 */

# ifdef USG
    SYM("_v","v",v)			/* sys/var.h var struct */
# ifdef STREAMS
    SYM("_pollwait","pollwait",pollwait) /* poll(2) sleep address */
# endif /* STREAMS defined */
# else  /* USG not defined */
    SYM("_nproc","nproc",nproc)		/* size of process table */
    SYM("_version","version",version)	/* version/build id string */
    SYM("_selwait","selwait",selwait)	/* select(2) sleep address */
# endif /* USG not defined */

# ifdef sun
    SYM("_consdev","consdev",consdev)	/* console device */
    SYM("_rconsdev","rconsdev",rconsdev) /* redirected console? */
# endif /* sun defined */

# ifdef sgi
    SYM("_end","end",end)		/* label at end of bss */
    SYM("_kernel_magic","kernel_magic",kernel_magic) /* value of _end */
# endif /* sgi defined */

# ifdef NEED_USRPT
    SYM("_usrpt","usrpt",usrpt)
    SYM("_Usrptmap","Usrptmap",Usrptmap)
# endif /* NEED_USRPT defined */

# ifdef ibm032				/* RT/AOS4.3 */
    SYM("_procSIZE","procSIZE",procSIZE)
    SYM("_userSIZE","userSIZE",userSIZE)
# endif /* ibm032 defined */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
