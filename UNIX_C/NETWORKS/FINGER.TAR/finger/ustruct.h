/*
 * ustruct.h -- system includes for user struct
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# define USTRUCT_RCSID "$Id: ustruct.h,v 3.0 90/07/06 13:12:14 budd Rel $"

# ifdef accel
# define INCLUDE_HEADERS
# endif /* accel defined */

# include <sys/param.h>			/* everyone!! */

# ifdef USG

# include <sys/types.h>
# include <sys/time.h>			/* for proc.h */
# include <sys/signal.h>		/* for MAXSIG */

# ifdef sgi
# include <sys/syssgi.h>
# endif /* sgi defined */

# ifdef SYSI86
# include <sys/sysi86.h>
# endif /* SYSI86 defined */

# ifndef AIX_RT				/* PC/RT AIX uses VRM segments */

# ifdef AIX3

# include <procinfo.h>

# else  /* AIX3 not defined */

# ifdef AUX				/* SVR2 */

# include <sys/mmu.h>
# include <sys/page.h>
# include <sys/seg.h>			/* for proc.h */
# include <sys/region.h>		/* for proc.h */

# else  /* AUX not defined */

# ifndef AIX_PS2

/* SVR3: UmaxV, 386/ix */

# ifdef DIR_H
# include <sys/dir.h>			/* for dirent u_dent */
# else  /* DIR_H not defined */
# include <sys/fs/s5dir.h>		/* for dirent u_dent */
# endif /* DIR_H not defined */

# ifndef SYSI86
/* for UmaxV, sgi */
# include <sys/sbd.h>			/* for proc.h (p_ubptbl[])*/
# endif /* SYSI86 not defined */

# include <sys/immu.h>			/* for region.h */
# include <sys/region.h>		/* for preg_t p_region */

# endif /* AIX_PS2 not defined */
# endif /* AUX not defined */

# endif /* AIX3 not defined */

# endif /* AIX_RT not defined */

# else  /* USG not defined */

/* BSD systems here */

# if defined(bsd4_3) || defined(ultrix)	/* ifdef NI_DENT?? */
# include <sys/dir.h>			/* for direct ni_dent in namei.h */
# endif /* defined(bsd4_3) || defined(ultrix) */

# if SunOS < 400
# include <sys/vm.h>
# ifndef accel
# include <machine/pte.h>
# endif /* accel not defined */
# endif /* SunOS < 400 */

# if SunOS >= 410
# include <sys/session.h>
# endif /* SunOS >= 410 */

# endif /* USG not defined */

/* everyone!! */
# include <sys/user.h>
# include <sys/proc.h>			/* for p_pid */
# undef u				/* sgi defines macro */

# ifndef SHORT_TTYP			/* SVR2, BSD, SOS3.x */
# ifdef TTY_REQUIRES_IOCTL		/* 4.3, Ultrix */
# include <sys/ioctl.h>
# endif /* TTY_REQUIRES_IOCTL defined */
# include <sys/tty.h>			/* for t_pgrp, t_{raw,out}q */
# endif /* SHORT_TTYP not defined */
