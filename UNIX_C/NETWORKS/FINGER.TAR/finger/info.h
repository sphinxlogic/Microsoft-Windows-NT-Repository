/*
 * info.h -- values looked up via nlist for finger
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# define INFO_RCSID "$Id: info.h,v 3.0 90/07/06 13:11:03 budd Rel $"

# define VERSTRLEN 80
# ifndef _FINGER_H_
# include "finger.h"			/* for CONC */
# endif /* _FINGER_H_ not defined */

/*
 *	this carries the creation date of syms.h but not the creation
 *	date of info.h its assumed (bad idea) that any change here
 *	will be refelected in the size of the written file.
 */

struct info {
    char info_fingerversion[ 2*VERSTRLEN ]; /* longversion from finger */
					/* (just for show) */
    unsigned long info_kerneldate;	/* creation time of /vmunix */
    unsigned long info_kernelsize;	/* file size of /vmunix */
    unsigned long info_symdate;		/* creation time of syms.h */
# define SYM(s,sc,m) unsigned long CONC(info_,m) ;
# include "syms.h"
# undef SYM
# ifdef HAVE_VERSION
    char info_verstr[ VERSTRLEN+1 ];	/* _version from kernel build */
# endif /* HAVE_VERSION defined */
};

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
