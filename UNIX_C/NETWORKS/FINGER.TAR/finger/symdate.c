/*
 * symdate.c -- stand alone prog to write symdate.h
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: symdate.c,v 3.0 90/07/06 13:11:52 budd Rel $";
# endif /* lint not defined */

# include <stdio.h>
# include <sys/types.h>
# include <sys/stat.h>
# include "finger.h"

main(argc, argv)
int argc;
char *argv[];
{
    struct stat stb;

    if( argc != 2 )
	fprintf(stderr, "%s file\n", argv[0] );
    else if( stat( argv[1], &stb ) < 0 )
	perror( argv[1] );
    else {
	printf("%ld\n", stb.st_mtime );
	exit( 0 );
    }
    exit( 1 );
} /* main */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
