/*
 * inquire.c -- interface from finger to inquire database (holmes)
 *	October 1986
 *
 * Copyright (C) 1988, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: inquire.c,v 3.0 90/07/06 13:11:05 budd Rel $";
# endif /* lint not defined */

# include "finger.h"
# ifdef INQUIRE				/* entire file! */
# include <stdio.h>
# include "inquire.h"
# include "person.h"
# include "args.h"


# define W(x,y) (pp->CONC(p_,x) = y)
# define X(x,y) W(x,savestr(bps[y]))
# define Y(x,y) if( bps[y][0] != EOS ) X(x,y); else W(x,NULL)
# define Z(x,y,z) if( bps[y][0] != EOS ) W(x,bps[y][0]); else W(x,z)

GLOBAL int doinquire( user, pp, bps )
char *user;
register PERSON *pp;
register char *bps[];
{
    if( bps == NULL ) {
	if( Read( user, BPs ) == NULL )
	    return( FALSE );
	bps = BPs;
    }

    if( bps[_PNAME][0] != EOS ) {
	char buf[ 120 ];
	npname( buf, bps[_PNAME]);
	pp->p_personal = savestr( buf );
    }

    Z(group,_GROUP,'?');
    Z(relation,_REL,'?');

    if( !sw_whois )
	return( TRUE );

    Y(waddr,_WADDR);
    Y(haddr,_HADDR);

    Y(wphone,_WPHON);
    Y(hphone,_HPHON);

    Y(project,_PROJ);
    Y(supervisor,_SUPER);

    Y(nickname,_NNAME);
    Y(birthday,_BIRTH);
    Y(remarks,_REM);

    return( TRUE );
} /* doinquire */
# endif /* INQUIRE defined */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
