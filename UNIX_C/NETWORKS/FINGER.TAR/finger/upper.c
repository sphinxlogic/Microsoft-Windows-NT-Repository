/*
 * upper.c -- uppercaseification table
 *
 * Copyright (C) 1988, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: upper.c,v 3.0 90/07/06 13:12:08 budd Rel $";
# endif /* lint not defined */

# include "finger.h"
# include "upper.h"

GLOBAL char uppercase[] = "\
\000\001\002\003\004\005\006\007\010\011\012\013\014\015\016\017\
\020\021\022\023\024\025\026\027\030\031\032\033\034\035\036\037\
 !\"#$%&'()*+,-./0123456789:;<=>?\
@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_\
`ABCDEFGHIJKLMNOPQRSTUVWXYZ{|}~\177";
