/*
 * ttylocfile.c -- read /etc/ttyloc and /etc/nttyloc (December 1985)
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: ttylocfile.c,v 3.0 90/07/06 13:12:03 budd Rel $";
# endif /* lint not defined */

# include "finger.h"
# include <sys/types.h>
# include <stdio.h>
# ifdef TTYENT
# include <ttyent.h>
# endif /* TTYENT defined */

# include "ttylocfile.h"

# define BUFSIZE 512

LOCAL TTYLOC ttyloc[MAXTTY];
LOCAL int nttyloc;

LOCAL int ttyloc_compare( a, b )	/* comparison for qsorting ttyloc[] */
    register struct ttyloc *a, *b;
{
    return strcmp( a->t_name, b->t_name );
} /* ttyloc_compare */

GLOBAL int readnewttylocfile() {
    FILE *fp;
    char buf[BUFSIZE];
    char *cp;
    register char *sp;
    register int c, q, l;
    register struct ttyloc *tp;

    nttyloc = 0;
    if( (fp = fopen(NLOCFILE,"r")) == NULL )
	return( 0 );			/* found none */

    tp = ttyloc;			/* point to start of array */
    while( nttyloc < MAXTTY && fgets(buf, BUFSIZE, fp) != NULL ) {
	cp = buf;

	tp->t_name = NULL;
	tp->t_short = NULL;
	tp->t_locn = NULL;
	tp->t_type = LT_UNKNOWN;

	l = strlen(cp);			/* smash nl into eos */
	if( l > 0 && (buf[l-1] == '\n') )
	    buf[l-1] = EOS;

	if( !skipwhite( &cp ) )
	    continue;

	if( *cp == '#' )		/* comment line? */
	    continue;			/*  yes, skip it */

	sp = cp;			/* get start of line type */
	if( !skipblack( &cp ) )
	    continue;
	*cp++ = EOS;

	l = strlen( sp );
	if( strncmp( sp, "hardwire", l ) == 0 )
	    tp->t_type = LT_HARD;
	else if( strncmp( sp, "ttyloc", l ) == 0 )
	    tp->t_type = LT_TTYLOC;
	else if( strncmp( sp, "dialup", l ) == 0 )
	    tp->t_type = LT_DIALUP;
	else if( strncmp( sp, "random", l ) == 0 )
	    tp->t_type = LT_UNKNOWN;
	else
	    continue;			/* you lose */

	if( !skipwhite( &cp ) )
	    continue;
	tp->t_name = cp;		/* save start of terminal name */
	if( !skipblack( &cp ) )
	    continue;
	*cp++ = EOS;

	/* pick up short location */
	if( *cp == '"' || *cp == '\'' ) {
	    q = *cp++;
	    sp = cp;
	    while( (c = *cp) != EOS && c != q )
		cp++;
	    if( c == EOS )
		continue;
	}
	else {
	    sp = cp;
	    if( !skipblack( &cp ) )
		continue;
	}
	*cp++ = EOS;

	tp->t_short = sp;

	if( !skipwhite( &cp ) )
	    continue;

	/* pick up long location */
	if( *cp == '"' || *cp == '\'' ) {
	    q = *cp++;
	    sp = cp;
	    while( (c = *cp) != EOS && c != q )
		cp++;
	    *cp++ = EOS;
	}
	else
	    sp = cp;

	if( strlen( sp ) == 0 )		/* no long location? */
	    continue;			/* get lost */

	tp->t_locn  = savestr( sp );
	tp->t_name  = savestr( tp->t_name );
	if( *tp->t_short != EOS )
	    tp->t_short = savestr( tp->t_short );
	else
	    tp->t_short = NULL;

	tp++;
	nttyloc++;
    } /* while fgets.. */
    fclose(fp);
    qsort( ttyloc, nttyloc, sizeof( ttyloc[0] ), ttyloc_compare );
    return( nttyloc );
} /* readnewttylocfile */

GLOBAL int readttylocfile() {
    FILE *fp;
    char buf[BUFSIZE];
    char *cp;
    register int i;
    register char *sp;
    register struct ttyloc *tp;

    nttyloc = 0;
    if( (fp = fopen(LOCFILE,"r")) == NULL )
	return( 0 );			/* found none */

    tp = ttyloc;			/* point to start of array */
    while( nttyloc < MAXTTY && fgets(buf, BUFSIZE, fp) != NULL ) {
	cp = buf;

	i = strlen(cp);			/* smash nl into eos */
	if( i > 0 && (buf[i-1] == '\n') )
	    buf[i-1] = EOS;

	if( !skipwhite( &cp ) )
	    continue;

	if( *cp == '#' )		/* comment line? */
	    continue;			/*  yes, skip it */

	sp = cp;
	if( !skipblack( &cp ))
	    continue;

	*cp++ = EOS;

	tp->t_short = NULL;
	tp->t_locn = NULL;
	tp->t_type = LT_UNKNOWN;

       if( strlen( cp ) > 0 ) {
	    tp->t_locn = savestr( cp );
	    tp->t_name = savestr( sp );
	    tp++;
	    nttyloc++;
	}
    } /* while fgets.. */
    fclose(fp);
    qsort( ttyloc, nttyloc, sizeof( ttyloc[0] ), ttyloc_compare );
    return( nttyloc );
} /* readttylocfile */

# ifdef TTYENT
GLOBAL int readttyents() {		/* 4.3/Ultrix ttys file */
    register struct ttyent *ty;
    register struct ttyloc *tp;

    nttyloc = 0;
    tp = ttyloc;
    setttyent();
    while( nttyloc < MAXTTY && (ty = getttyent()) != NULL ) {
# ifndef USE_ALL_TTYENTS
	if( (ty->ty_status & TTY_ON) == 0 )
	    continue;
# endif /* USE_ALL_TTYENTS not defined */

	tp->t_name = savestr( ty->ty_name ); /* save line name */

# ifdef DONT_USE_TTYENT_TYPE_AS_SHORT
	tp->t_short = NULL;
# else  /* DONT_USE_TTYENT_TYPE_AS_SHORT not defined */
	tp->t_short = savestr( ty->ty_type );
# endif /* DONT_USE_TTYENT_TYPE_AS_SHORT not defined */

	tp->t_locn = NULL;		/* assume the worst */
	if( ty->ty_comment != NULL ) {
	    char *cp;

	    cp = ty->ty_comment;
	    if( *cp == '#' )		/* strip leading pound sign */
		cp++;			/* (needed under uglix) */

	    while( *cp == ' ' || *cp == '\t' ) /* strip leading white */
		cp++;

	    if( *cp != EOS )		/* anything left? */
		tp->t_locn = savestr( cp ); /* yes, save as location */
	} /* have comment */
	tp->t_type = LT_UNKNOWN;
	tp++;
	nttyloc++;
    } /* while */
    endttyent();
    qsort( ttyloc, nttyloc, sizeof( ttyloc[0] ), ttyloc_compare );
    return( nttyloc );
} /* readttyents */
# endif /* TTYENT defined */

GLOBAL TTYLOC *findttyloc( tty )	/* find entry in ttyloc file */
char *tty;
{
    register int min, max, ptr;
    register TTYLOC *tp;

    min = 0;
    max = nttyloc - 1;
    while( min <= max ) {
	int v;
	ptr = (max + min + 1) >> 1;
	tp = &ttyloc[ ptr ];
	v = strcmp( tty, tp->t_name );
# ifdef DEBUG
	fprintf(stderr, "%d %d %d: %s,%s,%d\n",
		min, ptr, max, tty, tp->t_name, v);
# endif /* DEBUG defined */
	if( v == 0 )
	    return( tp );
	else if( v > 0 )
	    min = ptr + 1;
	else
	    max = ptr - 1;
    } /* while */
    return( NULL );
} /* findttyloc */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
