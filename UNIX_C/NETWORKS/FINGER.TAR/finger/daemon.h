/*
 * daemon.h -- Different things that can parent a shell -- January 1988
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# define DAEMON_RCSID "$Id: daemon.h,v 3.0 90/07/06 13:10:31 budd Rel $"

/*
 * see also daemon.c, getcommand.c, luser.h and getttyloc.c
 */

struct daemon {
    char
	*d_cmd,
	*d_short,
	*d_long;
};

extern struct daemon daemons[];
