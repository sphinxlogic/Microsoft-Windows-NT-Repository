/*
 * comdef.c -- comment defines automagicly
 *	esp for nasty ANSI conforming CPPs!
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: comdef.c,v 3.0 90/07/06 13:10:26 budd Rel $";
# endif /* lint not defined */

# include <stdio.h>
# include <ctype.h>

/* Should all be runtime options: */
# define USEDEF				/* check for if(n)def for comments */
/*# define DEBUG			/* output debug info */

/*
 * the following 4 (PRESERVE_xxx) output "#[s\t]thing" as input if
 * defined.  Otherwise if INDENTATION is defined they will be indented
 * according to depth.  If INDENT_OTHER is defined even includes and
 * defines will be indented (otherwise indented to MIN_INDENT).  if
 * IDENTATION is not defined all output will be indented to
 * MIN_INDENT.
 */

/*# define PRESERVE_BAD			/* preserve indentation on failures */
/*# define PRESERVE_IF			/* preserve indentation on ifs */
/*# define PRESERVE_ENDIF		/* preserve indentation on endifs */
/*# define PRESERVE_OTHER		/* preserve indentation on define... */
/*# define INDENTATION			/* indent by depth (but not define..)*/
/*# define INDENT_OTHER			/* indent define/include.. by depth */

# ifndef MIN_INDENT
# define MIN_INDENT 1
# endif /* MIN_INDENT not defined */

# define REL(i) ((i)+MIN_INDENT)

# define EOS '\0'

# define MAX 100			/* plenty!! */
char stack[MAX][ 256 ];
int flags[MAX];
int sp = -1;

# define FL_NOT 01			/* inverse of "condition" */
# define FL_ELS 02			/* seen else */
# define FL_DEF 04			/* was ifdef or ifndef */

main() {
    char line[ 1024 ], saved[ 1024 ];
    register char *cp, *xp, *yp;
    int ln;

    ln = -1;
    while( gets( line ) ) {
	cp = line;
	ln++;

	while( *cp && isspace( *cp ) )
	    cp++;

	if( *cp != '#' ) {
	    puts( line );
	    continue;
	}
	cp++;

	while( *cp && isspace( *cp ) )
	    cp++;

	xp = cp;
	while( isalpha( *cp ) )
	    cp++;

	strcpy( saved, line );		/* sigh */
	if( *cp != EOS ) {
	    if( !isspace( *cp ) ) {
		fprintf( stderr, "%d: bad line: %s\n", ln, line );
		puts( line );
		continue;
	    }
	    *cp++ = EOS;
	    while( isspace( *cp ) )
		cp++;
	}

# ifdef DEBUG
	fprintf( stderr, " <<< %s >>>\n", xp );
# endif /* DEBUG defined */
	if( strncmp( xp, "if", 2 ) == 0 || strcmp( xp, "elif" ) == 0 ) {
	    if( strcmp( xp, "elif" ) != 0 )
		sp++;
# ifdef PRESERVE_IF
	    puts( saved );
# else  /* PRESERVE_IF not defined */
	    putit( REL(sp), xp );
	    putchar(' ');
	    puts( cp );
# endif /* PRESERVE_IF not defined */

	    if( sp == MAX )
		fprintf( stderr, "%d: Beyond MAX", ln );
	    else {
		yp = cp;
		while( *cp != EOS )
		    if( *cp == '/' && cp[1] == '*' ) {
			while( isspace( cp[-1] ) && cp >= yp )
			    cp--;
			*cp = EOS;
			break;
		    }
		    else
			cp++;
# ifdef DEBUG
		fprintf( stderr, "saving: %s\n", yp );
# endif /* DEBUG defined */
		strcpy( stack[sp], yp );
		flags[sp] = 0;

		/* check for !exp ???!! */
		if( strcmp( xp, "ifndef" ) == 0 ) {
		    flags[sp] |= FL_NOT;
# ifdef USEDEF
		    flags[sp] |= FL_DEF;
# endif /* USEDEF defined */
		}
# ifdef USEDEF
		else if( strcmp( xp, "ifdef" ) == 0 )
		    flags[sp] |= FL_DEF;
# endif /* USEDEF defined */
	    }
	}
	else if( strcmp( xp, "else" ) == 0 ) {
	    if( sp < 0 ) {
		fprintf( stderr, "%d: else not under if\n", ln );
# ifdef PRESERVE_BAD
		puts( saved );
# else  /* PRESERVE_BAD not defined */
		putit( REL(sp), "else" );
		putchar('\n');
# endif /* PRESERVE_BAD not defined */
	    }
	    else {
		flags[sp] ^= FL_NOT;	/* invert not-ness */
		if( flags[sp] & FL_ELS )
		    fprintf( stderr, "double else for %s at line %d????\n",
			    stack[ sp ], ln );
# ifdef PRESERVE_BAD
		fputs( line, stdout );
# else  /* PRESERVE_BAD not defined */
		putit( REL(sp), "else" );
# endif /* PRESERVE_BAD not defined */
		/* extra space to match indent on endif */
		putchar( ' ' );
		comment(sp);
	    }
	}
	else if( strcmp( xp, "endif" ) == 0 ) {
	    if( sp >= MAX || sp < 0 ) {
		if( sp < 0 )
		    fprintf( stderr, "%d: Too many endifs\n", ln );
# ifdef PRESERVE_BAD
		puts( saved );
# else  /* PRESERVE_BAD not defined */
		putit( REL(sp), "endif");
		putchar('\n');
# endif /* PRESERVE_BAD not defined */
	    } /* bad sp */
	    else {
# ifdef PRESERVE_ENDIF
		fputs( line, stdout );
# else  /* PRESERVE_ENDIF not defined */
		putit( REL(sp), "endif" );
# endif /* PRESERVE_ENDIF not defined */
		comment(sp+1);		/* decr in wrong place for indenting */
	    } /* ok sp */
	    sp--;
	} /* found endif */
	else {				/* found something else */
# ifdef PRESERVE_OTHER
	    puts( saved );		/* define, include, or something... */
# else  /* PRESERVE_OTHER not defined */
# ifdef INDENT_OTHER
	    putit( REL(sp+1), xp );
# else  /* INDENT_OTHER not defined */
	    putit( MIN_INDENT, xp );
# endif /* INDENT_OTHER not defined */
	    putchar(' ');
	    puts( cp );
# endif /* PRESERVE_OTHER not defined */
	} /* define, include ... */
    } /* while */
} /* main */

putit( off, s )
    register off;
    char *s;
{
# ifdef DEBUG
    fprintf( stderr, "level %d off %d putit: %s\n", sp, off, s );
# endif /* DEBUG defined */

    putchar('#');

# ifdef INDENTATION
    if( off < MIN_INDENT )
# endif /* INDENTATION defined */
	off = MIN_INDENT;

    while( off-- > 0 )
	putchar(' ');

    fputs( s, stdout );
}

comment() {				/* comment elses and endif */
    fputs(" /* ", stdout );
    if( (flags[sp] & FL_DEF) == 0 && (flags[sp] & FL_NOT) )
	fputs("not ", stdout );

    fputs( stack[sp], stdout );
    if( flags[sp] & FL_DEF )
	if( flags[sp] & FL_NOT )
	    fputs(" not defined", stdout );
	else
	    fputs(" defined", stdout );
    puts( " */" );
} /* comment */
