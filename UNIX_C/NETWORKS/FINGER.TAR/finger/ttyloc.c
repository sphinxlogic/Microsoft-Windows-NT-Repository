/*
 * ttyloc.c -- Set Terminal Location (December 1985)
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: ttyloc.c,v 3.0 90/07/06 13:12:02 budd Rel $";
# endif /* lint not defined */

# include <sys/types.h>
# include <sys/stat.h>
# include <strings.h>
# include <errno.h>
# include <ctype.h>
# include <stdio.h>
# include "finger.h"

extern int errno;

# define LCLEN 100			/* location length */
# define FNLEN 100			/* file name length */
char *argv0;

GLOBAL char localhost[ MAXHOSTLEN+1 ];

extern char *ttyname();			/* from library */
extern char *locname();			/* from locname.c! */
FORWARD LOCAL char *gettname();
FORWARD LOCAL void getlocation(), fatal(), checkown(), pfatal(), checkdevice();

GLOBAL int main( argc, argv )
    int argc;
    char *argv[];
{
    int len;				/* length of ttyloc string */
    FILE *f;
    BOOL frobbing;			/* true if ttyfrob */
    char *tname;
    char locstr[LCLEN], *tfname;

    gethostname( localhost, MAXHOSTLEN );

    argv0 = "ttyloc?";
    frobbing = FALSE;

    if( argc > 0 ) {
	argv0 = rindex( argv[0], '/' );
	if( argv0 == NULL )
	    argv0 = argv[0];
	else
	    argv0++;

	if( strcmp(argv0, "ttyfrob") == 0 )
	    frobbing = TRUE;

	argc--;
	argv++;
    }

    if( frobbing ) {
	if( argc > 0 ) {
	    tname = argv[0];
	    argc--;
	    argv++;
	    checkdevice( tname );
	} /* more args */
	else
	    fatal("must have tty name");
    } /* frobbing */
    else {
	char *dev;
# if 0					/* returns /dev/tty! */
	dev = ctermid( NULL );
	if( dev == NULL )
# endif /* 0 */
	    dev = ttyname( 0 );
	if( dev == NULL )
	    fatal("could not find tty!");
	checkown( dev );
	tname = gettname( dev );
    }
    getlocation(locstr, argc, argv);

    tfname = locname( tname );		/* get spool file name */

    len = strlen(locstr);
    if( len == 0 ) {
	if( unlink( tfname ) < 0 && errno != ENOENT )
	    pfatal("could not unlink %s", tfname );
	exit( 0 );
    }

    f = fopen( tfname, "w" );
    if( f == NULL )
	pfatal("could not open %s");

    fputs( locstr, f );			/* check return? */

# ifdef USG
    chmod( tfname, TTYLOC_MODE );
# else  /* USG not defined */
    fchmod(fileno(f), TTYLOC_MODE);
# endif /* USG not defined */
    fclose( f );			/* check for err? */
    return( 0 );			/* ANSI! */
} /* main */

LOCAL void checkdevice( s )
    char *s;
{
    char devname[20];

    strcpy(devname, "/dev/");
    strcat(devname, s);
    checkown( devname );
} /* checkdevice */

LOCAL char *gettname( device )
    char *device;
{
    device = rindex(device, '/');
    if( device != NULL )
	device++;			/* skip over last slash */
    return( device );
} /* getttname */

LOCAL void getlocation(locstr, count, vec)
char *locstr;
int count;
char *vec[];
{
    register char *cp, *sp;

    cp = locstr;
    *cp = EOS;

    while( count > 0 ) {
	sp = vec[0];
	if( cp != locstr )
	    *cp++ = ' ';

	while( *sp != EOS ) {
	    if( isprint( *sp ) )
		*cp++ = *sp;
	    else
		fprintf( stderr, "%%%s: ignoring non printing character 0%o\n",
			argv0, *sp & 0xff );
	    sp++;
	}
	count--;
	vec++;
    }
    if( cp != locstr )
	*cp++ = '\n';
    *cp = EOS;
} /* getlocation */

LOCAL void fatal( s, x )
char *s;
int x;
{
    char line[ 1024 ];
    sprintf( line, s, x );
    fprintf(stderr, "?%s: %s\n", argv0, line );
    exit( 1 );
} /* fatal */

LOCAL void pfatal( s, x )
char *s;
int x;
{
    extern int errno, sys_nerr;
    extern char *sys_errlist[];
    char line[ 1024 ];

    sprintf( line, s, x );
    if( errno > 0 && errno < sys_nerr )
	fprintf(stderr, "?%s: %s; %s\n", argv0, line, sys_errlist[ errno ] );
    else
	fprintf(stderr, "?%s: %s; error %d\n", argv0, line, errno );
    exit( 1 );
} /* pfatal */

LOCAL void checkown( name )
    char *name;
{
    struct stat stb;
    int uid;

    if( stat( name, &stb ) < 0 ) {
	pfatal("could not stat %s", name );
	exit( 1 );
    } /* stat ok */
    if( (stb.st_mode & S_IFMT) != S_IFCHR )
	fatal("%s is not a character device!");
    uid = getuid();			/* get invoker's uid */
    if( uid != 0 && stb.st_uid != uid )
	fatal( "not owner of %s", name );
} /* checkown */


/*
 * Local variables:
 * comment-column: 40
 * End:
 */
