/*
 * luser.h -- per utmp entry information (December 1985)
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# define LUSER_RCSID "$Id: luser.h,v 3.0 90/07/06 13:11:17 budd Rel $"

# define ULEN 9			/* user length */
# define TLEN 9			/* tty (line) length */
# define HLEN 40		/* host name length */

typedef struct luser {		/* per-login/tty information */
    /* use pointers for user, line, host? */
    char u_user[ULEN];		/* user name */
    char u_line[TLEN];		/* tty name */
    char u_host[HLEN];		/* fn host (if any) */
    time_t u_time;		/* login time */
    time_t u_idle;		/* time of last terminal act. */
    struct person *u_person;	/* personal information */
    struct luser *u_left, *u_right; /* children for btree */
    unsigned short u_flags;	/* flagies */
    dev_t u_ttydev;		/* device number of tty */
    struct pr *u_command, *u_daemonp; /* "current" process, daemon process */
    struct daemon *u_daemon;	/* daemon if any */
# ifdef Umax
    long  u_ttyaddr;		/* inet addr of annex/rdp tty */
    short u_ttytype;		/* device type of annex/rdp tty */
    short u_ttynum;		/* device number of annex/rdp tty */
# endif /* Umax defined */
    struct switches u_sw;	/* per luser arg flags (from selector!) */
} LUSER;

# define LTREE LUSER

/* in u_flags */
# define U_NOWRITE 001		/* msg n */
# define U_BIFF	   002		/* biff y */
# define U_NLI     004		/* not logged in */
# define U_FOUND   010		/* found logged in */
# define U_HUNGRY  020		/* hungry y */
# define U_BADTTY  040		/* could not stat tty */

/*
 * Local variables:
 * comment-column: 32
 * End:
 */
