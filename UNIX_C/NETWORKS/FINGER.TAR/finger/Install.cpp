/*
 * Copyright (C) 1988, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 */

/*
 * $Id: Install.cpp,v 3.0 90/07/06 13:09:49 budd Rel $
 */

# include "local.h"

# ifdef USG
CHOWN=/bin/chown
# else  /* USG not defined */
CHOWN=/etc/chown
# endif /* USG not defined */

/* ttyloc program runs setuid */
TTYLOCOWN=daemon

/*fingerd must have this path built in (see FINGERPATHS in fingerd.c/local.h)*/
DEST=/usr/local/bin

/* you might change this to '1' if you don't have/use manl (local) */
MANSEC='l'
/* base for man files */
MAND=/usr/man

/* saved nlist file (finger needs to be in kmem group under 4.3) */
# ifdef KMEM_GROUP
NLISTGRP=KMEM_GROUP
# else  /* KMEM_GROUP not defined */
NLISTGRP=daemon
# endif /* KMEM_GROUP not defined */

# ifdef SAVED_NLIST
NFILE=SAVED_NLIST
# else  /* SAVED_NLIST not defined */
NFILE=/etc/finger-saved-nlist
# endif /* SAVED_NLIST not defined */

# ifdef NLIST_MODE
NFILEMODE=NLIST_MODE
# else  /* NLIST_MODE not defined */
NFILEMODE=664
# endif /* NLIST_MODE not defined */

# ifdef sun
FINGERDDEST=/usr/etc/in.fingerd
FINGERDSOURCE=in.fingerd
# if SunOS < 400
INETDCONF=/etc/servers
# else  /* not SunOS < 400 */
INETDCONF=/etc/inetd.conf
# endif /* not SunOS < 400 */
# else  /* sun not defined */
# ifdef sgi
FINGERDDEST=/usr/etc/fingerd
FINGERDSOURCE=fingerd
INETDCONF=/usr/etc/inetd.conf
# else  /* sgi not defined */
FINGERDDEST=/etc/fingerd
FINGERDSOURCE=fingerd
# ifdef INETD
INETDCONF=/etc/inetd.conf
# endif /* INETD defined */
# endif /* sgi not defined */
# endif /* sun not defined */

# ifdef sgi
/* what about other USG systems? */
UCBDIR=/usr/bsd
# else  /* sgi not defined */
UCBDIR=/usr/ucb
# endif /* sgi not defined */

echo binary dir is $DEST finger setgid $NLISTGRP
echo manual pages to $MAND section $MANSEC
echo saved namelist is $NFILE group $NLISTGRP mode $NFILEMODE
echo ttyloc dir is TTYLOC_DIR owner $TTYLOCOWN files mode TTYLOC_MODE
echo $FINGERDSOURCE to $FINGERDDEST
echo ''
echo "Type RETURN to continue"
read FOOBAR

/* flush groty versions */
if [ -r $UCBDIR/finger ]; then
	echo moving $UCBDIR/finger to $UCBDIR/ofinger
	mv $UCBDIR/finger $UCBDIR/ofinger
fi
if [ -r $UCBDIR/f ]; then
	echo moving $UCBDIR/f to $UCBDIR/of
	mv $UCBDIR/f $UCBDIR/of
fi
if [ -r $UCBDIR/whois ]; then
	echo moving $UCBDIR/whois to $UCBDIR/nicname
	mv $UCBDIR/whois $UCBDIR/nicname
fi

echo ''
echo installing $DEST/finger setgid $NLISTGRP
cp xf $DEST/finger
# ifndef NOSTRIP
strip $DEST/finger
# endif /* NOSTRIP not defined */
chgrp $NLISTGRP $DEST/finger
chmod 2711 $DEST/finger
ls -lg $DEST/finger

for x in whois whoj f; do
	if [ ! -r $DEST/$x ]; then
		echo linking $DEST/$x to $DEST/finger
		(cd $DEST; ln -s finger $x)
	fi
	ls -l $DEST/$x
done

echo ''
if [ ! -r $NFILE ]; then
	echo creating empty $NFILE
	touch $NFILE
fi
chgrp $NLISTGRP $NFILE
chmod $NFILEMODE $NFILE
ls -lg $NFILE

echo ''
echo installing $FINGERDSOURCE as $FINGERDDEST
cp $FINGERDSOURCE $FINGERDDEST
# ifndef NOSTRIP
strip $FINGERDDEST
# endif /* NOSTRIP not defined */
# ifdef INETD
echo "Checking $INETDCONF"
if grep finger $INETDCONF; then
	true;
else
	echo "Perhaps you should to edit $INETDCONF"
fi
# else  /* INETD not defined */
echo "Checking /etc/rc files"
if grep /etc/fingerd /etc/rc*; then
	true;
else
	echo "You might want to start fingerd from /etc/rc.local"
fi
# endif /* INETD not defined */

echo ''
echo installing $DEST/ttyloc setuid $TTYLOCOWN
cp ttyloc $DEST
# ifndef NOSTRIP
strip $DEST/ttyloc
# endif /* NOSTRIP not defined */
$CHOWN $TTYLOCOWN $DEST/ttyloc
chmod 4711 $DEST/ttyloc
ls -lg $DEST/ttyloc

echo ''
echo installing $DEST/ttyask
cp ttyask $DEST
# ifndef NOSTRIP
strip $DEST/ttyask
# endif /* NOSTRIP not defined */
(
    cd $DEST
    ls -lg ttyask
    for x in ttyplace ttyroom ttyrandom ttycycle; do
	rm -f $x
	echo linking $x to ttyask
	ln -s ttyask $x
	ls -l $x
    done
)

# ifdef TTYLOC_DIR
echo ''
if [ ! -d TTYLOC_DIR ]; then
	echo creating TTYLOC_DIR
	mkdir TTYLOC_DIR
fi
$CHOWN $TTYLOCOWN TTYLOC_DIR
ls -lgd TTYLOC_DIR
# else  /* TTYLOC_DIR not defined */
echo 'TTYLOC_DIR not defined in local.h!!' 1>&2
# endif /* TTYLOC_DIR not defined */

# ifdef USG
echo ''
echo installing man uptime in $UCBDIR/uptime
cp uptime $UDBDIR/uptime
# endif /* USG defined */

echo ''
echo installing man pages
cp finger.1	$MAND/man$MANSEC/finger.$MANSEC
cp ttyloc.1	$MAND/man$MANSEC/ttyloc.$MANSEC
cp nttyloc.5	$MAND/man5
cp finger.conf.5 $MAND/man5
cp fingerd.8c	$MAND/man8

echo ''
echo 'taking it out for a spin!'
$DEST/finger
