/*
 * global.c -- holds global symbols
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: global.c,v 3.0 90/07/06 13:11:01 budd Rel $";
# endif /* lint not defined */

# define EXTERN
# include "args.h"

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
