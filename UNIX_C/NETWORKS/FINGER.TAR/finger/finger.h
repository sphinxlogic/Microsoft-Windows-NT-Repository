/*
 * finger.h - basic language defines for finger etc
 *
 * Copyright (C) 1988, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# define FINGER_RCSID "$Id: finger.h,v 3.0 90/07/06 13:10:41 budd Rel $"

# ifndef _FINGER_H_
# define _FINGER_H_

# include "local.h"

# define EOS '\0'

# define LOCAL static
# define GLOBAL
# define FORWARD

# define BOOL int
# define FALSE 0
# define TRUE 1

# ifndef lint
LOCAL char Copyright[] = "Copyright (C) 1986, 1990  Philip L. Budne";
# endif /* lint not defined */

/* param.h (on 4.3) has MAXHOSTNAMELEN *TODO* */
# ifndef MAXHOSTLEN
# define MAXHOSTLEN 64
# endif /* MAXHOSTLEN not defined */

# define BPW (sizeof(int)*8)
# define MINUS_INF (1<<(BPW-1))
# define PLUS_INF  (MINUS_INF-1)

extern char *savestr();			/* string.c */
extern char *malloc();			/* libc */

# ifdef __STDC__			/* f****d up ANSI C (accomodate GCC) */

# define CONC(a,b) a##b			/* concatenate 2 strings */
# define CONC3(a,b,c) a##b##c		/* same for three */
# define STR(a) #a			/* make arg into a quoted string */

# define SIGNED signed

# else  /* __STDC__ not defined */

# define CONC(a,b) a/**/b
# define CONC3(a,b,c) a/**/b/**/c
# define STR(s) "s"

# define SIGNED

# endif /* __STDC__ not defined */

# ifndef INIT_PID
# define INIT_PID 1			/* Unix truism */
# endif /* INIT_PID not defined */

# ifdef UPCASE_HOSTS
# define HZUP(s) zup(s)
# else  /* UPCASE_HOSTS not defined */
# define HZUP(s) s
# endif /* UPCASE_HOSTS not defined */

/* std io descriptors */
# define STD_INPUT 0
# define STD_OUTPUT 1

# endif /* _FINGER_H_ not defined */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
