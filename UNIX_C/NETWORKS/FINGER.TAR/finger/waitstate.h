/*
 * waitstate.h -- wait state enumeration (once was ttystate.h)
 *
 * Copyright (C) 1987, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# define FOO_RCSID "$Id: waitstate.h,v 3.0 90/07/06 13:12:16 budd Rel $"

# define _STATES \
	_STATE(00) 			/* NULL */	\
	_STATE(TI) 			/* tty input */ \
	_STATE(TO) 			/* tty output */ \
	_STATE(TW) 			/* tty wait */	\
	_STATE(SE) 			/* select(2) */	\
	_STATE(RU) 			/* runable */	\
	_STATE(PA) 			/* pause(2) */	\
	_STATE(WA)			/* wait(2) */	\
	_STATE(SL)			/* other */

typedef enum { 
# define _STATE(s) CONC(WS_,s),
    _STATES
    WS_XX				/* use up extra comma */
# undef _STATE
} waitstate_t;

# ifdef WAITSTATENAME
char *WAITSTATENAME[] = {
# define _STATE(s) STR(s),
    _STATES
    "XX"
    };
# undef _STATE
# endif /* WAITSTATENAME defined */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
