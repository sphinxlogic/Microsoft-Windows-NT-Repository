/*
 * ttyask.c -- front end for ttyloc -- ask about ttyplaces
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: ttyask.c,v 3.0 90/07/06 13:11:57 budd Rel $";
# endif /* lint not defined */

# include "finger.h"
# include <pwd.h>
# include <stdio.h>
# include <ctype.h>
# include <signal.h>
# include <strings.h>
# ifdef USG
# include <termio.h>			/* POSIX too! */
# else  /* USG not defined */
# include <sgtty.h>
# endif /* USG not defined */

# include "ttylocfile.h"

extern char *getttytype();		/* from getttytype.c */
extern TTYLOC *findttyloc();		/* from readttylocfile.c */

# define TTYLOC_PROG "ttyloc"		/* program to set ttylocs */
# define TTYPLACES ".ttyplaces"		/* file to read */
# define MAXTTP 256

# ifndef DEFCYCLE
# define DEFCYCLE 120			/* default cycle sleep time */
# endif /* DEFCYCLE not defined */

# ifndef MINCYCLE
# define MINCYCLE 60			/* minimum allowed cycle/random time */
# endif /* MINCYCLE not defined */

char *pname;				/* name we were invoked as */

char *non_hardwire_types[] = {		/* if you are this in /etc/ttytype */
					/* (or /etc/ttys in 4.3) you are */
					/* probably NOT hardwired */
    "su",	"stupid",
    "du",	"dialup",	"sd",	"D2",
    "sa",	"network",
    "un",	"unknown",
    "se",	"ethernet",
    "sw",	"switch",
    "sp",	"plugboard",	"patch",
    "sb",	"arpanet",
    "sc",	"bussiplexer",
# ifdef Umax
    "",					/* CALL connections come in like this*/
					/* if tty type not set */
# endif /* Umax defined */
# ifdef NON_HARDWIRE_TYPES
    NON_HARDWIRE_TYPES ,
# endif /* NON_HARDWIRE_TYPES defined */
    NULL
    };

struct ttp {
    char *t_name;
    char *t_string;
} ttp[MAXTTP];
int nttp;

# ifdef USG
struct termio old, new;
# else  /* USG not defined */
struct sgttyb old, new;
# endif /* USG not defined */

FORWARD LOCAL BOOL check_hardwire();
FORWARD LOCAL void
    setup(), restore(), readttp(), do_ttyask(), do_ttyplace(),
    do_ttyrandom(), do_ttycycle(), sayit(), setit(), terpri(),
    whine(), catcher(), checkwho();

int hardwire = 0;
int cycletime = 0;
char mytty[ 512 ];

int main(argc, argv)
int argc;
char *argv[];
{
    enum { F_NONE=0, F_TTYASK, F_TTYPLACE, F_TTYRANDOM, F_TTYCYCLE } function;
    char *ttpfile;			/* -f argument */
    int err, arg;
    char *cp;				/* temp char ptr */

    extern int getopt(), optind;
    extern char *optarg;

    err = 0;
    pname = argv[0];
    function = F_NONE;

    if( (cp = rindex(pname, '/')) != NULL )
	pname = cp + 1;
    ttpfile = NULL;

    while( (arg = getopt(argc, argv, "acf:hprt:")) != -1 ) {
	switch( arg ) {
	case 'f':
	    ttpfile = optarg;
	    break;
	case 'h':
	    hardwire = 1;
	    break;
	case 'c':
	    function = F_TTYCYCLE;
	    break;
	case 'p':
	    function = F_TTYPLACE;
	    break;
	case 'r':
	    function = F_TTYRANDOM;
	    break;
	case 'a':
	    function = F_TTYASK;
	    break;
	case 't':
	    cycletime = atoi( optarg );
	    break;

	default:			/* ? or other junk */
	    err++;
	} /* switch */
    } /* while */

    if( err > 0 )
	whine("-a -c -r -h -t <time> -f <file>");

    readttp( ttpfile );			/* read .ttyplaces (or other) file */

    if( function == F_NONE ) {
	if( strcmp(pname, "ttyplace") == 0 )
	    function = F_TTYPLACE;
	else if( strcmp(pname, "ttyrandom") == 0 )
	    function = F_TTYRANDOM;
	else if( strcmp(pname, "ttycycle") == 0 )
	    function = F_TTYCYCLE;
    } /* F_NONE */

    switch( function ) {
    case F_NONE:
    case F_TTYASK:
	if( hardwire && check_hardwire() )
	    exit( 0 );
	setup();
	signal(SIGINT, catcher);
	do_ttyask();
	restore();
	break;
    case F_TTYPLACE:
	if( optind < argc )
	    do_ttyplace( argv[optind] );
	else
	    whine("must have string argument");
	break;
    case F_TTYRANDOM:
	do_ttyrandom();
	break;
    case F_TTYCYCLE:
	do_ttycycle();
	break;
    } /* switch */
    return( 0 );			/* ANSI! */
} /* main */

# define LEN 200
LOCAL void readttp( file )
char *file;
{
    char fname[ LEN ];
    struct passwd *pw;
    FILE *f;

    nttp = 0;
    if( (pw = getpwuid( getuid() )) == NULL )
	whine("no pw entry?");

    if( file == NULL ) {
	strcpy(fname, pw->pw_dir);
	strcat(fname, "/");
	strcat(fname, TTYPLACES);
	file = fname;
    }

    if( (f = fopen(file, "r")) == NULL ) {
	perror( file );
	exit( 1 );
    }

    while( fgets(fname, LEN, f) != NULL ) {
	register int i;
	register char *cp;
	char *p2;

	i = strlen( fname );
	if( i == 0 )
	    continue;

	if( i < LEN - 1 )
	    fname[ i - 1 ] = EOS;

	cp = fname;
	while( *cp != EOS  && isspace( *cp ) )
	    cp++;
	if( *cp == EOS )
	    continue;

	while( *cp != EOS  && !isspace( *cp ) )
	    cp++;

	if( *cp == EOS )
	    whine("no space on line: %s", fname);

	*cp++ = EOS;
	while( *cp != EOS  &&  isspace( *cp ) )
	    cp++;

	if( *cp == EOS )
	    whine("no location for '%s'", fname);

	ttp[ nttp ].t_name = p2 = malloc( strlen( fname ) + 1 );
	strcpy(p2, fname);

	ttp[ nttp ].t_string = p2 = malloc( strlen( cp ) + 1 );
	strcpy(p2, cp);

	nttp++;
    } /* while */
} /* readttp */

LOCAL void do_ttyask() {
    register int i, c;

    if( cycletime > 0 )
	signal(SIGALRM, catcher );
    for(i = 0; i < nttp; i++ ) {
	for( ; ; ) {
	    printf("--%s--", ttp[i].t_name );
	    if( cycletime > 0 )		/* time limit? */
		alarm( cycletime );	/* reset the clock! */
	    c = getchar();
	    terpri();
	    if( c == EOF )
		return;			/* unlikely in CBREAK */
	    switch( c & 0177 ) {
	    case '\03':			/* ^C */
	    case '\04':			/* ^D */
	    case 'Q':
	    case 'q':
		return;
	    case ' ':
	    case 'Y':
	    case 'y':
		alarm( 0 );
		setit( i );
		return;
	    case '?':
	    case 'h':
	    case 'H':
		printf("space, Y, y       = yes\r\n");
		printf("<del>, N, n, <bs> = no\r\n");
		printf("?, H, h           = this\r\n");
		printf("Q, q, ^c, ^d      = quit\r\n");
		break;
	    case 0177:
	    case '\b':
	    case 'N':
	    case 'n':
		goto no;	/* sigh (must break switch & for) */
		break;
	    default:
		printf("? for help\r\n");
		break;
	    } /* case */
	} /* for ever */
    no: ;			/* break forever */
    } /* for i */
} /* do_ttyask */

LOCAL int sort_item(a, b)
struct ttp *a, *b;
{
    return( strcmp( a->t_name, b->t_name ) );
} /* sort_item */

LOCAL void sort_all() {
    qsort(ttp, nttp, sizeof( struct ttp ), sort_item );
} /* sort_all */

LOCAL void do_ttyplace( name )
char *name;
{
    register int i, it, len;

    sort_all();
    it = -1;
    len = strlen( name );

    for( i = 0; i < nttp; i++ ) {
	if( strncmp(name, ttp[i].t_name, len) == 0 ) {
	    if( i+1 < nttp && strncmp(name, ttp[i+1].t_name, len) == 0 )
		whine("ambiguous place '%s'", name);
	    else {
		it = i;
		break;
	    }
	} /* if strncmp [i] */
    } /* for */

    if( it != -1 )
	sayit( it );
    else
	whine("no place called '%s'", name);

} /* do_ttyplace */

LOCAL void do_ttyrandom() {
    int i;
    unsigned long seed;

    if( cycletime > 0 && cycletime < MINCYCLE )
	cycletime = MINCYCLE;

    seed = getpid() + time( 0 );
    for( ; ; ) {
	seed = (seed * 11109 + 13849) & 0xffff;
	i = seed % nttp;
	setit( i );
	if( cycletime == 0 )
	    return;
	else
	    sleep( cycletime );
	checkwho();
    }
} /* do_ttyrandom */

LOCAL void do_ttycycle() {
    int i;

    if( cycletime < MINCYCLE )
	cycletime = DEFCYCLE;
    for( ; ; ) {
	for( i = 0; i < nttp; i++ ) {
	    setit( i );
	    sleep( cycletime );
	    checkwho();
	} /* for i */
    } /* for ever */
} /* do_ttycycle */

LOCAL void sayit( i )
int i;
{
    printf("%s (%s)\n", ttp[ i ].t_name, ttp[ i ].t_string );
    setit( i );
} /* sayit */

LOCAL void setit( i )
int i;
{
    char line[250];

    line[0] = EOS;
    sprintf(line, "%s %s", TTYLOC_PROG, ttp[i].t_string);

    system( line );
} /* setit */

LOCAL void terpri() {
    fputs("\r\n", stdout);		/* beware CBREAK mode */
} /* terpri */

LOCAL void whine(s,a)
char *s, *a;
{
    char buf[ 100 ];
    sprintf(buf, s, a);
    fprintf(stderr, "%s: %s\n", pname, buf);
    exit( 1 );
} /* whine */

LOCAL void catcher() {			/* here on signal */
    restore();
    exit( 1 );
} /* catcher */

LOCAL void setup() {
# ifdef USG				/* POSIX too! */
    ioctl( STD_INPUT, TCGETA, &old );
    new = old;
    new.c_cc[VMIN] = 1;
    new.c_lflag &=~ECHO;
    new.c_lflag &= ~ICANON;
    ioctl( STD_INPUT, TCSETA, &new );
# else  /* USG not defined */
    gtty( STD_INPUT, &old);
    new = old;
    new.sg_flags &= ~(CBREAK|ECHO);
    new.sg_flags |= RAW;
    stty( STD_INPUT, &new);
# endif /* USG not defined */
} /* setup */

LOCAL void restore() {
# ifdef USG				/* POSIX too! */
    ioctl( STD_INPUT, TCSETA, &old );
# else  /* USG not defined */
    stty( STD_INPUT, &old);
# endif /* USG not defined */
} /* restore */

/****************************************************************/

LOCAL void get_mytty() {
    register char *tn, *tp;
    extern char *ttyname();

    if( mytty[0] != EOS )
	return;

    tn = ttyname( 0 );
    if( tn == NULL )
	return;
    if( (tp = rindex( tn, '/')) != NULL )
	tp++;
    else
	tp = tn;
    strcpy( mytty, tp );
}

LOCAL void checkwho() {
    if( getppid() == INIT_PID )
	exit( 0 );
}

LOCAL BOOL check_hardwire() {
    register char *ty, *cp;
    register TTYLOC *tp;
    register i;

    get_mytty();

    /* try to check line type from new ttyloc file */
    if( readnewttylocfile() > 0 && (tp = findttyloc( mytty )) != NULL ) {
	if( tp->t_type == LT_HARD || tp->t_type == LT_TTYLOC )
	    return( TRUE );
	else
	    return( FALSE );
    }

    /* get terminal type (/etc/ttytype in 4.2; /etc/ttys in 4.3) */
    if( (ty = getttytype(mytty)) == NULL )
	return( FALSE );

    /* look for type in list of known NON hardwired line types */
    i = 0;
    while( (cp = non_hardwire_types[ i ]) != NULL )
	if( strcmp( cp, ty ) )
	    return( FALSE );		/* not a hardwire candidate */

    return( TRUE );
} /* check_hardwire */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
