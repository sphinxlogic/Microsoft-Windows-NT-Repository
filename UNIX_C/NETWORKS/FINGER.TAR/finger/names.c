/*
 * names.c -- lookup names via nlist
 *
 * Copyright (C) 1986, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# ifndef lint
static char *rcsid = "$Id: names.c,v 3.0 90/07/06 13:11:24 budd Rel $";
# endif /* lint not defined */

# include "finger.h"

# ifdef DEBUGSW
# define IFDEBUG( x ) if( sw_debug ) printf x
# else  /* DEBUGSW not defined */
# define IFDEBUG( x )
# endif /* DEBUGSW not defined */

# if Umax != 42				/* the rest of the file.... */

# ifdef USG
# include <fcntl.h>
/* TODO: <sys/var.h> check info_proc vs. ((proc *)v.ve_proc) - v.v_proc */
# else  /* USG not defined */
# include <sys/file.h>
# endif /* USG not defined */
# include <sys/types.h>
# include <sys/stat.h>
# ifdef AUX
# include <a.out.h>
# else  /* AUX not defined */
# include <nlist.h>
# endif /* AUX not defined */
# include <stdio.h>

# include "args.h"
# include "info.h"			/* after finger.h */
# include "kmem.h"

long symdate =
# include "symdate.h"
;

GLOBAL struct info I;

extern FTYPE kmem;			/* from kmem.c */

extern char longversion[];		/* from version.c */
extern char *sys_errlist[];		/* from library */
extern int errno;			/* from library */

struct nlist nl[] = {			/* nlist table */
# ifdef UNDERSCORE_NLIST_NAMES
# define SYM(s,sc,m) { s },
# else  /* UNDERSCORE_NLIST_NAMES not defined */
# define SYM(s,sc,m) { sc },
# endif /* UNDERSCORE_NLIST_NAMES not defined */
# include "syms.h"
# undef SYM
    ""
};
# define LNL ((sizeof(nl)/sizeof(struct nlist))-1)

unsigned long *nvptrs[] = {
# define SYM(s,sc,m) CONC(&I.info_,m) ,	/* build table of pointers to values */
# include "syms.h"
# undef SYM
};

LOCAL int readnlist(kfile)		/* force read of nlist */
char *kfile;
{
    register int i;
    struct stat kernst;
# ifdef HAVE_VERSION
    char kmem_verstr[ VERSTRLEN+1 ];
# endif /* HAVE_VERSION defined */

    IFDEBUG(("getting namelist from %s\n", kfile ));

    if( nlist(kfile, nl) < 0 ) {
	fprintf(stderr, "%%Could not read %s namelist\n", kfile );
	return( FALSE );
    }

    for( i = 0; i < LNL; i++ ) {
	if(
# ifndef COFF
	  nl[i].n_type == N_UNDF &&
# endif /* COFF not defined */
	  nl[i].n_value == 0L ) {
	    fprintf(stderr, "%%No namelist entry for %s\n", nl[i].n_name );
	    return( FALSE );
	} /* empty entry */
	*nvptrs[i] = nl[i].n_value;
    } /* for i */

    if( stat( kfile, &kernst ) == 0 ) {
	I.info_kerneldate = kernst.st_mtime;
	I.info_kernelsize = kernst.st_size;
	I.info_symdate = symdate;
    } /* stat */

    strncpy( I.info_fingerversion, longversion, sizeof( I.info_fingerversion));
# ifdef HAVE_VERSION
    bzero( I.info_verstr, sizeof( I.info_verstr ) );
    bzero( kmem_verstr,  sizeof( kmem_verstr )  );

    /* save _version from /vmunix in I.info_verstr */
    if( read_vmunix( KERNEL_FILE, I.info_version,
		    I.info_verstr, VERSTRLEN ) ) {
	I.info_verstr[VERSTRLEN] = '\0';

# ifdef DEBUGSW
	if( sw_debug ) {
	    printf("info_version %#x\n", I.info_version );
	    printf("%s:\n", kfile );
	    printf("%*s\n", -VERSTRLEN, I.info_verstr );
	}
# endif /* DEBUGSW defined */

# ifdef PICKY
	/*
	 * be picky.... insist that running kernel
	 * contain same string at same location
	 */

	if( KMEMREAD(I.info_version, kmem_verstr,  VERSTRLEN ) ) {
	    kmem_verstr[VERSTRLEN] = '\0';

# ifdef DEBUGSW
	    if( sw_debug ) {
		printf("kmem @ %#x:\n", I.info_version );
		printf("%*s\n", -VERSTRLEN, kmem_verstr );
	    }
# endif /* DEBUGSW defined */

	    /* if match, we win */
	    if( strncmp( kmem_verstr, I.info_verstr, VERSTRLEN ) == 0 )
		return( TRUE );
	} /* kread ok */
# endif /* PICKY defined */
    } /* got version from /vmunix file */
# ifdef PICKY
    return( FALSE );
# else  /* PICKY not defined */
    return( TRUE );
# endif /* PICKY not defined */
# else  /* HAVE_VERSION not defined */
    return( TRUE );
# endif /* HAVE_VERSION not defined */
} /* readnlist */

LOCAL int writenfile( kfile )
char *kfile;
{
    int nfile;

    if( !readnlist( kfile ) )
	return( FALSE );

    if( sw_nosave )			/* write prohibited? */
	return( TRUE );			/* be nice */

    IFDEBUG(("writing %s\n", SAVED_NLIST ));
    if( (nfile=open( SAVED_NLIST, O_TRUNC|O_CREAT|O_WRONLY,
		    NLIST_MODE)) >= 0 ) {
	write( nfile, &I, sizeof( I ) );
# ifndef USG
	fchown( nfile, geteuid(), getegid() );
	fchmod( nfile, NLIST_MODE );
# else  /* USG defined */
	chown( SAVED_NLIST, geteuid(), getegid() );
	chmod( SAVED_NLIST, NLIST_MODE );
# endif /* USG defined */
	close( nfile );
    } /* open for write */
    else
	fprintf( stderr, "%%Could not write %s (%s)\n",
		SAVED_NLIST, sys_errlist[ errno ] );
    return( TRUE );
} /* writenfile */

GLOBAL int readnames() {	/* get nlist from save file or /vmunix */
# ifdef SAVED_NLIST
    int nfile, oknfile, oknlist;
    struct stat savst, kernst;
    char kmem_verstr[ VERSTRLEN+1 ];

    oknfile = oknlist = FALSE;

    /* check if SAVED_NLIST exists, is right size */
    /* built from same copy of syms.h */
    if( !sw_read ) {				/* not getting new save */
	IFDEBUG(("%s: ", SAVED_NLIST ));
	if( stat( SAVED_NLIST, &savst ) == 0 &&	/* got status of save file */
	   savst.st_size == sizeof( I ) ) {	/* data file is right size */
	    IFDEBUG(("size ok "));

	    if( (nfile = open( SAVED_NLIST, O_RDONLY )) >= 0 ) { /* opened */
		if( read( nfile, &I, sizeof( I ) ) == sizeof( I ) ) {
		    IFDEBUG(("read ok "));
		    if( I.info_symdate == symdate ) {/* same copy of syms.h? */
			oknfile = TRUE;		/* doing fine */
			IFDEBUG(("symdate ok "));
		    } /* same copy of syms.h */
# ifdef DEBUGSW
		    else if( sw_debug )
			printf("*symdate mismatch*");
# endif /* DEBUGSW defined */

		}
		close( nfile );
	    } /* open ok */
	} /* stat + size ok */
	IFDEBUG(("\n"));
    } /* not sw_read */

    if( sw_read || !oknfile )		/* if no good fall back on /vmunix */
	return( writenfile( KERNEL_FILE ) );

# ifdef AUTONLIST
    /*
     *	does version string in running kernel match that of
     *  the kernel that was running when the nlist file was created?
     */
# ifdef HAVE_VERSION
    if( I.info_version != 0L ) {		/* have addr for verstr */
	bzero( kmem_verstr, sizeof( kmem_verstr ) );
	if( KMEMREAD( I.info_version, kmem_verstr, VERSTRLEN ) ) {
# ifdef DEBUGSW
	    if( sw_debug ) {
		printf("kmem @ %#x:\n", I.info_version );
		printf("%*s\n", -VERSTRLEN, kmem_verstr );
		printf("info_verstr:\n");
		printf("%*s\n", -VERSTRLEN, I.info_verstr );
	    } /* sw_debug */
# endif /* DEBUGSW defined */
	    if( strncmp( I.info_verstr, kmem_verstr, VERSTRLEN ) == 0  )
		oknlist = TRUE;			/* matches!! */
	} /* kread ok */
    } /* version != 0 */
    else
# endif /* HAVE_VERSION defined */
	if( stat( KERNEL_FILE, &kernst ) == 0 &&   /* get kernel date/size */
	    savst.st_mtime > kernst.st_mtime &&	  /* more recent than kernel */
	    I.info_kerneldate == kernst.st_mtime && /* same /vmunix */
	    I.info_kernelsize == kernst.st_size ) {
# ifdef DEBUGSW
	if( sw_debug )
	    printf("%s and %s kernel size and date match\n",
		   SAVED_NLIST, KERNEL_FILE );
# endif /* DEBUGSW defined */
	oknlist = TRUE;
    } /* stat ok... */
    if( !oknlist )
	return( writenfile( KERNEL_FILE ) );
# else  /* AUTONLIST not defined */
    if( !oknlist )
	return( readnlist( KERNEL_FILE ) );
# endif /* AUTONLIST not defined */
    return( TRUE );
# else  /* SAVED_NLIST not defined */
    return( readnlist( KERNEL_FILE ) );
# endif /* SAVED_NLIST not defined */
} /* readnames */

# endif /* Umax != 42 */

/*
 * Local variables:
 * comment-column: 40
 * End:
 */
