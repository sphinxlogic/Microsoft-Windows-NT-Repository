/*
 * strings.h - help for systems without old style string functions
 *
 * Copyright (C) 1989, 1990  Philip L. Budne
 *
 * This file is part of "Phil's Finger Program".
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 */

# define STRINGS_RCSID "$Id: strings.h,v 3.0 90/07/06 13:11:47 budd Rel $"

# ifndef _STRINGS_H_
# define _STRINGS_H_

# include <string.h>			/* sigh.. nested include */
# define index(s,c) strchr(s,c)
# define rindex(s,c) strrchr(s,c)	/* what a dumb name! */

# define bzero(s,c) memset(s,'\0',c)
# define bcopy(s,d,c) memcpy(d,s,c)
# endif /* _STRINGS_H_ not defined */
