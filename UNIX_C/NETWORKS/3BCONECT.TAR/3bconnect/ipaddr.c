/*
 * Copyright (C) 1988 Dave Settle. All rights reserved.
 * Permission is granted to use, copy and modify this software, providing
 * that it is not sold for profit, and that this copyright notice is retained
 * in any copies of the source.
 */
/*
 * ipaddr: print address as xx.xx.xx.xx.xx.xx
 */
char *ipaddr(a)
char *a;
{
	register int i;
	static char s[26];
	for(i=0;i<5;i++) sprintf(s + (i * 3), "%02x.", a[i]);
	sprintf(s + 15, "%02x", a[5]);
	return(s);
}

