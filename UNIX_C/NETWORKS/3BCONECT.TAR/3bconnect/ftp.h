/*
 * Some constants for the ftp
 */
#define WINDOW	4		/* Window size */
#define TRANSIT 2		/* Estimated transit time (sec) for window */
#define MAXRETRY 5		/* No of timeouts per window */


