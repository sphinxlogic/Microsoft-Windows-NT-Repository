/*
 * Copyright (C) 1988 Dave Settle. All rights reserved.
 * Permission is granted to use, copy and modify this software, providing
 * that it is not sold for profit, and that this copyright notice is retained
 * in any copies of the source.
 */
/*
 * mynode.c: print physical ethernet address of the local node.
 */
 
#include <sys/ni.h>

main(){
	NI_PORT port;
	int ethernet;
	if((ethernet = open("/dev/ni", 2)) == -1) {
		perror("/dev/ni");
		exit(1);
	}
	if(ioctl(ethernet, NIGETA, &port)) {
		perror("NIGETA");
		exit(1);
	}
	printf("Physical ethernet address: %s\n", ipaddr(port.srcaddr));
	close(ethernet);
	exit(0);
}
