/*
 * talk.c: routines to talk to the remote shell, run on the remote system
 */
#include "ni.h"


passon(r, output)
register struct request *r;	/* stuff to send		*/
int output;			/* file descriptor to write on	*/
{
	int ok = 1;
	switch(r->r_type) {
	case TERMINATE:
		ok = 0;
		break;
	case RMTSIGINT:
		kill(0, SIGINT);
		break;
	case RMTSIGQUIT:
		kill(0, SIGQUIT);
		break;
	case DATA:
		write(output, r->r_data, r->r_size);
		break;
	default:
		sprintf(r->r_data, "Bad packet type %d\n", r->r_type);
			send(r, strlen(r->r_data), DATA, client);
	}
	return(ok);
}
#define PTTY "/dev/ptc"
#define MAXPTTYS 8
/*
 * special case routine - use the PC-Interface pseudo-ttys to get a real
 * remote login!
 */
dologin(r)
register struct request *r;
{
	int dev;			/* file descriptor	*/
	int i, n, reader;
	char name[sizeof PTTY + 4];
	for(i=0;i<MAXPTTYS;i++) {
		sprintf(name, "%s%02d", PTTY, i);
		if((dev = open(name, 2)) != -1) break;
	}
	if(dev == -1) {
		n = sprintf(r->r_data, "No PC-Interface ports available");
		send(r, n, TERMINATE, client);
		exit(1);
	}
	if(reader = fork()) {
		while(1) {
			recv(r);
			if(passon(r, dev) == 0) {
				skill(reader, SIGTERM);
				exit(0);
			}
		}
	}
	else {
		while(1) {
			n = read(dev, r->r_data, sizeof r->r_data);
			send(r, n, DATA, client);
		}
	}
}

		
