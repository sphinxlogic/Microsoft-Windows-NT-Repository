#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define BUFFER      512				/* internal character buffer size */

char	*sprintf();
char	*index();
char	*strsave();
char	*malloc();
char	*basename();
char	*expalias();

char	*login;						/* user's login name       */
char	*tty;						/* tty he's on             */
char	*home;						/* home directory          */
char	*shell;						/* preferred shell         */
extern	char	host[];				/* local host name         */
extern	char	realname[];			/* from password file      */
int		maxx;						/* max legal x coordinate  */
int		maxy;						/* max legal y coordinate  */
int		stream;						/* stream socket filedes   */
int		ctl;						/* control socket fd       */
int		reading;					/* currently reading kb?   */
extern	char	buf[];				/* general-use buffer      */
extern	int		pending;			/* number of pending calls */
int		connected;					/* number of connected people */
int		touched25;					/* message changed line 25    */
struct	sockaddr_in locaddr;		/* localhost address   */
extern	char	convaddr[];			/* conversation address    */
int		port;						/* phoned socket port      */

#ifndef	ESC
#define	ESC		'\033'
#endif

#define PROMPT  "Command> "

#define ctrl(C)     ('C'-'@')
#define isdigit(c)  ('0' <= c && c <= '9')
#define	equal(a,b)	(strcmp (a,b) == 0)


/*
 *  Various oft-used flags.
 */

int		Interval;					/* seconds between messages */
int		Inverse;					/* allow use of inverse video */
int		Stop;						/* print "Stopped" to socket on ^Z */
int		Debug;						/* verbose tracing stuff */
int		Bells;						/* let ^G come through as bell */
int		Hold;						/* send input to child process */
int		Echo;						/* send input to socket when running prog */
