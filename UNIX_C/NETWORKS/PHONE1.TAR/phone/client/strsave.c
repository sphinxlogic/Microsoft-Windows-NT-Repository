#include <signal.h>
#include <stdio.h>

/*
 *  Allocate enough space for the given string and copy it over.
 */

char *
strsave (s)
char *s;
{
	register char *new;
	char     *malloc();

	if (new = malloc ((unsigned) (strlen (s) + 1)))
		strcpy (new, s);
	else
		error (1, "strsave: cannot malloc memory");

	return (new);
}
