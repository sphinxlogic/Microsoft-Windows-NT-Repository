/*
 *  Timer routine.
 *  When we come here, see if we have any pending calls or messages,
 *  call the appropriate routines, then reset the timer.
 */

timer ()
{
	extern	int pending, msgpending;

	if (pending)		/* have pending calls */
		reinvite ();

	if (msgpending >= 0)
		showmessage ();

	if (pending || msgpending >= 0)      /* set the next alarm */
		alarm (1);
}
