#include "defs.h"
#include <stdio.h>

#ifndef PHONERC
#define PHONERC	"/.phonerc"
#endif


/*
 *  Open the .phonerc and do the stuff in it.
 */

readrc ()
{
	char	line[BUFSIZ];
	char	*i, *index();
	FILE	*rc;

	strcpy (buf, home);
	strcat (buf, PHONERC);

	if ((rc = fopen (buf, "r")) == (FILE *) 0)
		return;
	
	while (fgets (line, BUFSIZ, rc)) {
		if (Debug)
			printf ("Rc: %s", line);
		if (*line == '#' || *line == '\n')
			continue;
		if (i = index (line, '\n'))
			*i = '\0';
		execute (line);
	}
	fclose (rc);
}
