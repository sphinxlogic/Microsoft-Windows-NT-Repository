#ifndef lint
static char RCSid[] = "$Header: inquire.c,v 1.1 85/10/28 17:38:21 broome Exp $";
#endif

/*
 * $Log:	inquire.c,v $
 * Revision 1.1  85/10/28  17:38:21  broome
 * Initial revision
 */

#include "../common.h"
#include "defs.h"

/*
 *  Check to see if there are any pending calls for this user,
 *  send back the first address and delete the invite if any are found.
 */

inquire (argv, sin)
char   *argv[];
struct sockaddr_in sin;
{
	INV  *inv;

	if (inv = lookup (argv[0], argv[1])) {		/* had one pending */
		sprintf (buf, "%c%c%c%s", ESC, INQUIRE, ACK, inv->convaddr);
		delete (inv);
	} else
		sprintf (buf, "%c%c%cNo messages pending.", ESC, INQUIRE, NAK);
	sendto (misc, buf, strlen (buf), 0, &sin, sizeof (sin));
}


/*
 *  They say they answered the call, so delete it from the list.
 *  This routine is for future use - not used now ...
 */

answer (argv)
char   *argv[];
{
	INV *inv;
	
	for (inv = invitations; inv; inv = inv->next)
		if (eq (argv[0], inv->callee) && eq (argv[1], inv->convaddr)) {
			sprintf (buf, "%c%c%c%s", ESC, ANSWER, ACK, inv->id);
			(void) sendto (misc, buf, strlen(buf), 0, &inv->ctladdr, 
				sizeof (inv->ctladdr));
			delete (inv);
			return;
		}
}
