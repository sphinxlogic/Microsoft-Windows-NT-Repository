#define TABLECMD	"/usr/bin/nitable"
#define RTOUCHCMD	"/usr/bin/nisend -e -s -d%s -!\042nisend -e -s -d%s \
-f%s /etc/fstab\042"
#define KILLCMD		"/usr/bin/nisend -s -e -k all"
#define TMPDIR		"/usr/tmp/%s" 
#define MAXTIMEOUT	60

#define MAXNODES	100
#define ROWS		18
#define COLWIDTH	20

#define MYrefresh move(12,78); refresh()
#define MS(x) (char *)malloc(x)
