/*****************************************************************************/
/*	CommonDefs.h - Common Definitions for all Displays, Collectors, etc. */
/*****************************************************************************/

#define FALSE 0
#define TRUE  1

#define DELIMITERS " \t\n"

#define MAXNODES        2000
#define MAXPROBLEMS     MAXNODES

#define MAXNODENAME 20	/* Size of Node Name */
#define MAXUNIQUEID 34	/* SIZE OF UNIQUE ID (USUALLY IP ADDR) */
#define MAXTESTNAME 15  /* SIZE OF TEST NAME THAT FAILED		*/

#define MAXLINE 150	/* MAXIMUM INPUT FILE LINE */ 
