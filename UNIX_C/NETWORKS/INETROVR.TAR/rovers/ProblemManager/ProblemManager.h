/*	*****************************************************************
 	*	ProblemManager.h - ProblemManager Routines		*
	*****************************************************************
*/


/*	Problem_Manager( Cmd, ProbType, Node, UniqueID )
		where Cmd=					*/
#define ADD_PROBLEM		1   
#define ADD_PRIMARY_PROBLEM	2	
#define DELETE_PROBLEM  	3 
#define UPDATE_PROBLEM  	4 
#define CLAIM_PROBLEM  		5 
#define CHECK			6 

/* Note: ADD Problem and DELETE Problem are straight forward.  ADD_PRIMARY
	will automatically DELETE all problems associated with this UniqueID
	that are not of ProbType.   That way, you can ADD_PRIMARY problems,
	that will automatically delete secondary problems for you.

*/
/* Cmd is an int, all other parms are char *. 				*/

int Problem_Manager();	/* Problem_Manager
			(Cmd,TypeProblem,nodename,UniqueID,StatusLine) */
			/* Returns non-zero if file has changed */
int TestNode();		/* Test Machine?  TestNode( nodename ) */
			/* public: long ProblemFileLastUpdated */
#include "ProblemFileio.h"
