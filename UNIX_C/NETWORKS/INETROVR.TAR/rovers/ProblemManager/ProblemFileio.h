/* File: ProblemFileio.h - ProblemFile Specific IO Routines */
#include "../CommonDefs.h"

#define STATUSX 53
#define MAXSTATUSLINE 26

struct ProblemType {
	long TimeStamp;
	char Name[MAXNODENAME];
	char UniqueID[MAXUNIQUEID];
	char TestName[MAXTESTNAME];
	char StatusLine[MAXSTATUSLINE];
};


/********************* Forward Declarations *******************************/
int ReadProblemFile();  /* read Problems into ProblemType Array from File */
int WriteProblemFile(); /* write Problems into Problem File               */
int Problem_Exists();   /* returns index, (Addr,Service,Problem,#Problems)*/
