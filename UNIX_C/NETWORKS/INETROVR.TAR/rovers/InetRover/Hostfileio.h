/*
		HostfileIO.h:	Hostfile IO Declares
 */

#include "../CommonDefs.h"

#define MAXTESTS 10
#define MAXARGS 2	/* ARGS within () of test : like PING(5,76); */

struct NodeType {
	char *NodeName;
	char *UniqueID;
	char *Helpfilename;
	struct TestType {
		char *argv[MAXARGS];
	} Test[MAXTESTS];
};

struct NodeType *ReadNodeFile();   /* Note that NumNodes is global if needed */ 
void PrintNodes();      /*                     Debug                      */
