/************************************************************************
 *   NetQuery.h    Definitions file form Network Query Interface        *
 *                                                                      */
#define WORD unsigned

WORD NetQuery();         /* Network Query - Pass a Service # and parms   */
WORD NetService();       /* Get Network Service Index ( for call to NetQuery)*/

char *NetServiceString(); /*- displays Service passed service index */
char *NetStatusString();  /* displays status passed status string */
/************************************************************************
 *      Network Services that we are interested in trying               *
 ************************************************************************/
#define ERROR  -1
#define NONE    0
#define PING    1     /* ICMP Echo Request (Ping) to determine reachability */
#define SGMP    2
#define SNMP    3
#define TELNET  4
#define FTP     5
#define SMTP    6
#define NAMED   7
#define TROUBLE 8
#define LOGICALINK 9
#define ATPING 10
#define ATLOOK 11
#define FINGER 12
#define GENERIC 13
#define MAXSERVICES 13
/************************************************************************
 *      NetQuery and NetService Return Codes                            *
 ************************************************************************/
#define ITWORKS 1 
#define ITBROKE 0 
#define ITERROR -1
#define ITDEAD 2


