static char *Version="connect v2.0 compiled on whitman.merit.edu at Mon May 13 09:19:32 EDT 1991";
