static char *Version="xdisplay v2.0 compiled on whitman.merit.edu at Mon May 13 09:20:24 EDT 1991";
