/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
typedef unsigned char byte;
typedef unsigned short u_short;
typedef unsigned long ip_addr;
typedef unsigned long u_long;
typedef byte EA[6];

/****************************************************************/
struct ipheader {
# ifdef SWAP
    int ip_ihl : 4;		/* Internet header length in 32 bit words */
    int ip_ver : 4;		/* Header version */
# else /* SWAP not defined */
    int ip_ver : 4;		/* Header version */
    int ip_ihl : 4;		/* Internet header length in 32 bit words */
# endif /* SWAP not defined */
    byte ip_tsrv;		/* Type of service */
    u_short ip_len;		/* Total packet length including header */
    u_short ip_id;		/* ID for fragmentation */
# ifdef SWAP
    u_short ip_foff : 13;	/* Fragment offset */
    u_short ip_flgs : 3;	/* flags */
# else /* SWAP not defined */
    u_short ip_flgs : 3;	/* flags */
    u_short ip_foff : 13;	/* Fragment offset */
# endif /* SWAP not defined */
# define IP_FLG_DF 01
# define IP_FLG_MF 02

    byte ip_ttl;		/* Time to live (secs) */
    byte ip_prot;		/* protocol */
    u_short ip_chksum;		/* Header checksum */
    ip_addr ip_src;		/* Source addrt */
    ip_addr ip_dst;		/* Destination addr */
    byte ip_options[1];		/* options... */
};
					/* from RFC990 */
# define IP_PROT_ICMP	1		/* control messages */
# define IP_PROT_GGP	2		/* gave vs gate */
					/* 5 - ST - stream */
# define IP_PROT_TCP	6		/* tcp */
# define IP_PROT_EGP	8		/* ext gateways */
					/* 9 - any igp */
# define IP_PROT_PUP	12		/* pup */
					/* 13 - ARGUS */
					/* 14 - EMCON */
					/* 15 - XNET - cross net debugger */
					/* 16 - Chaos */
# define IP_PROT_UDP	17		/* user datagrams */
					/* 18 - MUX - Multiplexing */
					/* 19 - DCN-MEAS */
					/* 20 - HMP host monitoring */
					/* 21 PRM */
# define IP_PROT_IDP	22		/* xns idp */
					/* 23 TRUNK1 */
					/* 24 TRUNK2 */
					/* 25 LEAF1 */
					/* 26 LEAF2 */
					/* 27 RDP */
					/* 28 IRTP - reliable transaction */
					/* 29 ISO-TP4 */
					/* 30 NETBLT */
					/* 61 any host internal protocol */
					/* 62 CFTP */
					/* 63 any local network */
					/* 64 SAT-EXPAK */
					/* 65 MIT-SUBNET */
					/* 66 - RVD */
					/* 67 IPPC */
					/* 68 any DFS */
					/* 69 SAT-MON */
					/* 71 IPCV */
					/* 76 BR-SAT-MON */
					/* 78 WB-MON */
					/* 79 WB-EXPAK */
# define IP_PROT_ND	77		/* net disk (SUN, unoff) */


/****************************************************************/
struct udpheader {
    u_short udp_srcp;			/* source port */
    u_short udp_dstp;			/* dest port */
    u_short udp_len;			/* length of UDP packet */
    u_short udp_cksum;			/* UDP checksum */
};

/****************************************************************/
struct tcpheader {			/* a tcp header */
    u_short tcp_srcp;			/* source port */
    u_short tcp_dstp;			/* dest port */
    u_long tcp_seq;			/* sequence number */
    u_long tcp_ack;			/* acknowledgement number */
# if 0
    u_short tcp_flags;
# define tcp_thl	tcp_flags >> 12
# define tcp_fin	tcp_flags & 001
# define tcp_syn	tcp_flags & 002
# define tcp_rst	tcp_flags & 004
# define tcp_psh	tcp_flags & 010
# define tcp_fack	tcp_flags & 020
# define tcp_furg	tcp_flags & 040
# else /* not 0 */
    unsigned tcp_thl : 4;		/* tcp header length */
    unsigned tcp_uu1 : 6;		/* unused */
    unsigned tcp_furg : 1;		/* urgent ptr. valid */
    unsigned tcp_fack : 1;		/* ack valid */
    unsigned tcp_psh : 1;		/* push bit */
    unsigned tcp_rst : 1;		/* reset bit */
    unsigned tcp_syn : 1;		/* syn bit */
    unsigned tcp_fin : 1;		/* fin bit */
# endif /* not 0 */
    u_short tcp_win;			/* window */
    u_short tcp_cksum;			/* checksum */
    u_short tcp_urg;			/* urgent pointer */
};

/****************************************************************/
struct ndpacket {
    byte nd_op, nd_dev, nd_err, nd_ver;
    u_long nd_seq, nd_blk, nd_count, nd_res, nd_off, nd_data;
};

/****************************************************************/
struct arppacket {
    u_short	arp_hw;			/* should be 1 */
    u_short	arp_pro;
    byte	arp_hln;		/* hdw addr len */
    byte	arp_pln;		/* proto addr len */
    u_short	arp_op;			/* arp opcode */
    byte	arp_data[1];		/* data... */
/*  EA		arp_xsha;		/* sender hardware address */
/*  ip_addr	arp_xspa;		/* sender protocol address */
/*  EA		arp_xtha;		/* target hardware address */
/*  ip_addr	arp_xtpa;		/* target protocol address */
};

# define ARP_REQUEST	1		/* request to resolve address */
# define ARP_REPLY	2		/* response to previous request */
# define RARP_REQUEST	3		/* request to resolve address */
# define RARP_REPLY	4		/* response to previous request */

/* as of rfc990 */
# define ARP_HW_ETHER	1		/* 10mb ether */
# define ARP_HW_XETHER	2		/* 3mb ether */
# define ARP_HW_AX25	3		/* amateur radio */
# define ARP_HW_PRONET	4
# define ARP_HW_CHAOS	5
# define ARP_HW_IEEE802	6

/****************************************************************/
struct puppacket {
    u_short pup_len;
    byte pup_transport;
    byte pup_type;
    u_long pup_id;
    struct {
	byte pup_port_net;
	byte pup_port_host;		/* swapped? */
	u_short pup_port_sock1, pup_port_sock2;
    } pup_src, pup_dst;
};

/****************************************************************/
struct xns_addr {
    byte xnsa_net[4];
    byte xnsa_host[6];
    u_short xnsa_port;
};

struct xnspacket {			/* xns idp */
    u_short xns_sum, xns_len;		/* cksum, len */
    byte xns_tc, xns_pt;		/* hops(transport), packet type */
    struct xns_addr xns_dst;
    struct xns_addr xns_src;
};
/****************************************************************/

union {
    byte p_bytes[ 2000 ];
    struct etherpacket {
	EA e_dst;
	EA e_src;
	u_short e_type;
	union {
	    byte d_bytes[1];
	    struct ipheader  d_ip;
	    struct arppacket d_arp;
	    struct puppacket d_pup;
	    struct xnspacket d_xns;
	} e_data;
    } p_ether;
} packet;
