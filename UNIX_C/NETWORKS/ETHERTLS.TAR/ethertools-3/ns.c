/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
/*
 *	ns.c -- name server crock
 *	Phil Budne @ Boston U / Distributed Systems
 *	September 1986
 */

# include <stdio.h>
# include <netdb.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <netinet/in.h>
# include <arpa/inet.h>
# include <signal.h>
# include <setjmp.h>

# ifndef DEBUGF
# define DEBUGF 0			/* non-zero to debug */
# endif /* DEBUGF not defined */

extern char *malloc(), *strcpy();

# define TABLE_SIZE 200
struct table {
    unsigned long table_addr;
    char *table_name;
} table[ TABLE_SIZE ];
int table_pointer = 0;

# define NS_ADDR 0x80c51428		/* bu-it-itnet */
# define NS_PORT 53

char *jname;				/* argv[0] */

struct domain {
    short id, op, qc, ac, nc, dc;
    char qa[1];
};

struct qsuf {
    short type, class;
};

# define cat(t,f){register int l = strlen(f);*t++ = l; strcpy(t,f);t+=l;}

int s;
inited = 0;

char *ns_lookup( addr )
unsigned long addr;
{
    struct sockaddr_in sin;
    char buf[ 128 ];			/* short query! */
    register struct domain *dp;
    register char *p;
    register struct qsuf *q;
    char name[ 100 ];

    if( !inited && (s = socket( AF_INET, SOCK_DGRAM, 0)) < 0 )
	return NULL;
    inited = 1;

    sin.sin_family = AF_INET;
    sin.sin_port = htons( NS_PORT );
    sin.sin_addr.s_addr = htonl( NS_ADDR );

    dp = (struct domain *) buf;
    dp->id = 0;
    dp->op = htons( 0400 );		/* please recurse */
    dp->qc = htons( 1 );		/* just one question... */
    dp->ac = dp->nc = dp->dc = 0;
    p = dp->qa;

    sprintf( name, "%d", addr & 255 );
    cat(p, name );
    sprintf( name, "%d", (addr >> 8) & 255 );
    cat(p, name );
    sprintf( name, "%d", (addr >> 16) & 255 );
    cat(p, name );
    sprintf( name, "%d", (addr >> 24) & 255 );
    cat(p, name );
    cat(p, "in-addr" );
    cat(p, "arpa" );
    *p++ = '\0';

    q = (struct qsuf *) p;
    q->type = htons( 12 );		/* domain name pointer */
    q->class = htons( 1 );		/* the internet */
    p += sizeof( struct qsuf );

# if DEBUGF
    printf( "to %s port %d\n",
	   inet_ntoa( sin.sin_addr.s_addr ), ntohs( sin.sin_port ) );
# endif /* DEBUGF */

    /* TIMEOUT!!!! */
    if( sendto( s, buf, p - buf, 0, &sin, sizeof( sin ) ) < 0 ||
       read( s, buf, sizeof( buf ) ) < 0 ) {
	close( s );
	inited = 0;
	return NULL;
    }

    if( ntohs( dp->op ) & 017 || ntohs( dp->ac ) <= 0 )
	return NULL;
    else {
	while( *p != '\0' )
	    if( *p & 0300 )		/* compressed? */
		*++p = '\0';
	    else
		p += *p + 1;
	    p += 10 + 1;		/* rsrc record heading len */


	name[0] = '\0';
	while( *p != '\0' ) {
	    if( *p & 0300 )		/* compressed? */
		p = buf + (ntohs( * (int *)p ) & 037777);
	    else {
		strncat( name, p+1, *p );
		strcat( name, "." );
		p += *p + 1;
	    }
	}

	if( strlen( name ) )
	    name[ strlen( name ) - 1 ] = '\0';

	return( strcpy( malloc( strlen( name ) + 1 ), name ) );
    }
} /* ns_lookup */

char *lookup_name( addr )
    unsigned long addr;
{
    register int i;
    char *n;

    for( i = 0; i < table_pointer; i++ )
	if( addr == table[ i ].table_addr )
	    return( table[ i ].table_name );

    n = ns_lookup( addr );

    if( table_pointer == TABLE_SIZE - 1 )
	return n;

/*  if( n == NULL ) return NULL;	/* cache failures too! */

    table[ table_pointer ].table_name = n;
    table[ table_pointer++ ].table_addr = addr;
    return( n );
}

