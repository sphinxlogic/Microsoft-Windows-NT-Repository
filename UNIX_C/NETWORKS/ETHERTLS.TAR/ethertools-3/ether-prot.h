/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
		Ethernet protocol types

The Ethernet TYPE field contains a hexadecimal number which can be
interpreted to yield a symbolic Ethernet protocol type name.  A table of
some of the major Ethernet protocol types and their descriptions follows:

Hexadecimal	Description

0x0200		Xerox PUP
0x0201		PUP Address Trans.
0x0600		Xerox XNS IDP
0x0800		DoD IP
0x0801		X.75 Internet
0x0802		NBS Internet
0x0803		ECMA Internet
0x0804		Chaosnet
0x0805		X.25 Level 3
0x0806		ARP
0x0807		XNS Compatability
0x081C		Symbolics Private
0x0a00		Xerox 802.3 PUP
0x0a01		PUP 802.3 Address Trans.
0x1000		Berkeley trailer
0x1001		IP_trailer_1_block
0x1002		IP_trailer_2_blocks
0x1003		IP_trailer_3_blocks
0x1004		IP_trailer_4_blocks
0x1005		IP_trailer_5_blocks
0x1006		IP_trailer_6_blocks
0x1007		IP_trailer_7_blocks
0x1008		IP_trailer_8_blocks
0x1009		IP_trailer_9_blocks
0x100a		IP_trailer_10_blocks
0x100b		IP_trailer_11_blocks
0x100c		IP_trailer_12_blocks
0x100d		IP_trailer_13_blocks
0x100e		IP_trailer_14_blocks
0x100f		IP_trailer_15_blocks
0x1600		VALID
0x5208		BBN Simnet
0x6000		DECNet0
0x6001		DEC MOP Dump/Load
0x6002		DEC MOP Remote Console
0x6003		DEC DECnet Routing
0x6004		DEC LAT
0x6005		DEC DECNet Diagnostics
0x6006		DEC DECNet SCA
0x6007		DEC DECNet7
0x8003		Cronus VLN
0x8004		Cronus Direct
0x8005		HP Probe
0x8006		Nestar
0x8010		Excelan
0x8013		SGI diagnostic type
0x8014		SGI network games
0x8015		SGI reserved type
0x8016		SGI `bounce server'
0x8035		Reverse ARP
0x8038		DEC LANBridge
0x805b		Stanford V Kernel experimental
0x805c		Stanford V Kernel production
0x807c		Merit Internodal
0x8080		VitaLink bridge
0x809b		Appletalk
0x80de		TRFS (Integrated Solutions Transparent Remote File System)
0x80f3		Appletalk ARP
0x9000		Loopback
0x9001		Bridge bridge
0x9002		Bridge terminal
0xff00		BBN VITAL LANBridge
