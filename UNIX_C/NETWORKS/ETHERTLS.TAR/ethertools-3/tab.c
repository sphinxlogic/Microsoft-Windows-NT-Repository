/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
# include <stdio.h>
# include <ctype.h>
# include "packet.h"

struct hent {
    union {
	EA hd_ea;
	short hd_type;
    } h_data;
    int h_cnt;
    int h_inuse;
};
# define h_ea h_data.hd_ea
# define h_type h_data.hd_type

# define HSIZE 1001
struct hent srchash[ HSIZE ];
struct hent dsthash[ HSIZE ];
struct hent typehash[ HSIZE ];
int length[ 1520 ];

int count = 0;
int pc;

main() {
    char line[ 4096 ];
    register byte *pp;
    register char *lp;
    register int i;

    pc = 0;
    pp = packet.p_bytes;
    while( gets( line ) ) {
	if( line[0] == ' ' || line[0] == '*' || line[0] == '\0' ) {
	    if( pc > 0 )
		process();
	    pp = packet.p_bytes;
	    pc = 0;
	    continue;
	}

	for( lp = line; *lp; lp++ ) {
	    if( isspace( *lp ) )
		continue;
	    else if( isxdigit( *lp ) && isxdigit( lp[1] ) ) {
		*pp++ = xval( *lp, lp[1] );
		lp++;
		pc++;
	    }
	    else
		fprintf( stderr, "you lose: %s\n", lp );
	}
    }
    if( pc > 0 )
	process();
    dump_ht_ea( "src", srchash, HSIZE );
    dump_ht_ea( "dst", dsthash, HSIZE );
    dump_ht_short( "type", typehash, HSIZE );

    for( i = 0; i < 1520; i++ )
	if( length[i] > 0 )
	    printf("%4d %4d\n", i, length[i] );
}

process() {
    register struct etherpacket *e = (struct etherpacket *) &packet;
    u_short type;

    count++;
    type = packet.p_ether.e_type;
/**
    terpri();
    printf("esrc: ");
    petaddr( e->e_src );
    putchar(' ');
    putchar('/');
    putchar(' ');
    printf("edst: ");
    petaddr( e->e_dst );
    terpri();
    printf("type=%02X-%02X len=%d\n",
	   (type >> 8) & 255,
	   type & 255,
	   pc );
**/

    ent_ea( srchash, e->e_src, HSIZE );
    ent_ea( dsthash, e->e_dst, HSIZE );

    ent_short( typehash, type, HSIZE );
    length[ pc ]++;
}

hash( p )
    register unsigned char *p;
{
    register h, h2, l;
    l = 3;
    h = 0;
    while( l-- )
	h = (h<<8) | *p++;

    l = 3;
    h2 = 0;
    while( l-- )
	h2 = (h2<<8) | *p++;

    return( h ^ h2 );
}

ent_ea( ht, ea, s )
    struct hent *ht;
    EA ea;
{
    int h;

    h = hash( ea ) % s;

    while( ht[ h ].h_inuse && bcmp( ht[h].h_ea, ea, 6) != 0 )
	h = (h + 101) % s;

    if( !ht[h].h_inuse ) {
	bcopy( ea, ht[h].h_ea, 6 );
	ht[h].h_inuse = 1;
    }

    ht[h].h_cnt++;
}

ent_short( ht, t, s )
    struct hent *ht;
    unsigned short t;
{
    int h;

    h = t % s;

    while( ht[ h ].h_inuse && ht[h].h_type != t )
	h = (h + 101) % s;

    if( !ht[h].h_inuse ) {
	ht[h].h_type = t;
	ht[h].h_inuse = 1;
    }

    ht[h].h_cnt++;
}

dump_ht_ea( n, h, s )
    char *n;
    struct hent *h;
{
    register int i;
    puts( n );
    for( i = 0; i < s; i++, h++ )
	if( h->h_inuse ) {
	    printf(" %5d ", h->h_cnt );
	    petaddrm( h->h_ea );
	    terpri();
	}
}

dump_ht_short( n, h, s )
    char *n;
    struct hent *h;
    int s;
{
    register int i;

    puts( n );
    for( i = 0; i < s; i++, h++ )
	if( h->h_inuse ) {
	    printf("%02X-%02X %d\n",
		   (h->h_type >> 8 ) & 255,
		   (h->h_type) & 255,
		   h->h_cnt );
	}
}

