/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
/*
 *	CTP -- Ethernet v2 Configuration Test Protocol User Process
 *	Philip L. Budne @ Boston University / Distributed Systems
 *
 */

# include <sys/types.h>
# include <sys/time.h>
# include <net/nit.h>
# include <signal.h>
# include <stdio.h>
# include "ctp.h"

/*
 * SIGH.  Move sender to child?
 * print loss.
 * print variance.
 */

# define SHM

typedef u_char ea_t[6];			/* ethernet address type */

# ifdef SHM
# include <sys/ipc.h>
# include <sys/shm.h>

int shmid;
char *shmaddr, *shmat();

# define NCOUNTS 8
# define NCOUNT (1<<(NCOUNTS))
struct stats {
    int total;				/* total count */
    int highseq;			/* highest seq seen */
    int outofseq;			/* number recvd out of sequence */
    int min, max;			/* min and max times */
    int sum, sumsq;			/* sum of times, sum of squares */
    int counts[ NCOUNT ];
    /* array of addrs? */
};

int lastseq = 0;
int nsent = 0;
# endif /* SHM defined */

int seq = 0;

struct packet {				/* CTP packet layout */
    ea_t    p_dst;			/* Ethernet dest */
    ea_t    p_src;			/* Ethernet src */
    u_short p_type;			/* Ethernet type (802 length) */
    u_short p_skip;			/* CTP skip */
    u_char  p_data[ 2048 ];		/* ... */
};

struct ctp_forward {			/* forward subpacket */
    u_short cf_function;		/* CTP_FWD */
    ea_t    cf_addr;
};

struct ctp_reply {			/* reply subpacket */
    u_short cr_function;		/* CTP_REP */
    /* The following is data that we use for own purposes */
    u_short cr_pid;			/* pid of sender -- not swapped */
    u_short cr_seq;			/* sequence number -- not swapped */
    struct timeval cr_sendt;		/* time packet was sent */
    /* more data here.. */
};

ea_t localaddr;				/* our ethernet address */

# define MAXPATH 200			/* !! (more than can fit in a packet) */
ea_t path[ MAXPATH];			/* path list */
int pathcount = 0;			/* length of path list */

# define MINPACK 60			/* minimum ether packet */
# define MAXPACK 1516			/* maximum ether packet */

int count = -1;				/* number of packets to send */
char ifbuf[ 100 ];
char *interface = ifbuf;		/* interface to use */
int verbose = 0;			/* extra output */
int noreturn = 0;			/* don't force final forward back */
int debug = 0;				/* don't fork */
int packlen = MINPACK;			/* default total packet length */
int slptim = 1000;			/* sleep time in ms */

int pid;				/* parent pid */
int child;				/* child pid */

main(argc, argv)
    int argc;
    char *argv[];
{
    extern char *optarg;
    extern int optind, opterr;
    int s, c, errs;
    void nit_input();			/* forward */

    errs = 0;
    while( (c = getopt( argc, argv, "c:di:l:ns:v" )) != EOF ) {
	switch( c ) {
	case 'c':
	    count = atoi( optarg );
	    break;
	case 'd':
	    debug ^= 1;
	    break;
	case 'i':
	    interface = optarg;
	    break;
	case 'l':
	    packlen = atoi( optarg );
	    if( packlen < MINPACK )
		packlen = MINPACK;
	    else if( packlen > MAXPACK )
		packlen = MAXPACK;
	    break;
	case 'n':
	    noreturn ^= 1;
	    break;
	case 's':
	    slptim = atoi( optarg );
	    break;
	case 'v':
	    verbose ^= 1;
	    break;
	default:
	    errs++;
	} /* switch */
    } /* while getopt */
    if( errs > 0 ) {
	fprintf( stderr, "Usage: %s [-c count] [-d] [-i ifn] ", argv[0] );
	fprintf( stderr, "[-l len] [-n] [-s sleep] [-v] [addr ...]\n");
	fprintf( stderr, "addr <- ether-addr | ipaddr | iphost | ");
	fprintf( stderr, "etherhost | 'BCAST' | 'MCAST'\n" );
	exit( 1 );
    }

    pid = getpid();			/* get parent pid */
    s = nit_open( interface, ETHERTYPE_CTP, localaddr, 0 );
    printf("%s address ", interface );
    petaddr( localaddr );
    puts( "" );

    pathcount = 0;
    while( optind < argc && pathcount < MAXPATH && argv[optind] != NULL ) {
	if( strcmp( argv[optind], "MCAST" ) == 0 ) {	/* CTP mcast addr */
	    register u_char *ea;
	    ea = path[pathcount];
	    *ea++ = 0XCF;
	    *ea++ = 0x00;
	    *ea++ = 0x00;
	    *ea++ = 0x00;
	    *ea++ = 0x00;
	    *ea   = 0x00;
	}
	else if( !htoea( argv[ optind ], path[pathcount] ) ) {
	    fprintf( stderr, "%s: unknown host %s\n",
		    argv[0], argv[optind] );
	    exit( 1 );
	} /* bad host */
	pathcount++;
	optind++;
    } /* while hosts */

    if( pathcount == 0 ) {		/* if no hosts */
	bcopy( bcast, path[0], sizeof( ea_t ) ); /* broadcast */
	pathcount++;			/* fake count */
    } /* empty path */

    if( debug )
	ctp_send( s );			/* just send */
    else {
# ifdef SHM
	void gotint(), die(), poop();
	struct stats *sp;

	signal( SIGINT, gotint );
	signal( SIGHUP, die );
	signal( SIGKILL, die );

	shmid = shmget( IPC_PRIVATE, sizeof( struct stats ), 0600 );
	shmaddr = shmat( shmid, 0, 0 );
	sp = (struct stats *)shmaddr;
	bzero( sp, sizeof( struct stats ) );
	sp->min = 100000;
	sp->max = -1;
# endif /* SHM defined */

	switch( (child = fork()) ) {
	case -1:
	    perror( "fork" );
	    exit( 1 );
	    /* NOTREACHED */

	case 0:
# ifdef SHM
	    signal( SIGINT,  poop );
	    signal( SIGHUP,  poop );
	    signal( SIGKILL, poop );
# endif /* SHM defined */
	    nit_loop( s, nit_input );	/* input in child */
	    /* NOTREACHED */

	default:
	    ctp_send(s);		/* output in parent */
	    /* NOTREACHED */
	} /* switch */
    }
} /* main */

# ifdef SHM
void
die() {
    (void) shmdt( shmaddr );
    (void) shmctl( shmid, IPC_RMID, 0 );
    exit( 0 );
}

void
poop() {
    exit( 1 );
}

void
stats() {
    register struct stats *sp;

    sp = (struct stats *) shmaddr;
    printf("----CTP statistics----\n");
    printf("%d Packet%s Sent, %d Recieved\n",
	   nsent, (nsent == 1 ? "" : "s"), sp->total );
    if( sp->total > 0 )
	printf("round-trip (ms)  min/avg/max = %d/%d/%d var=%d\n",
	       sp->min, sp->sum / sp->total, sp->max,
	       0 );
} /* stats */

void
gotint() {
    puts("");
    stats();
    die();
}

# endif /* SHM defined */

/****************************************************************/

void
nit_input( s, nh )
    int s;
    struct nit_hdr *nh;
{
    int l;
    u_char *p2;
    int len, l2, ms;
    short f, skip, seq;
    struct packet *pp;
    struct ctp_reply *cr;
# ifdef SHM
    register struct stats *sp;
    sp = (struct stats *) shmaddr;
# endif /* SHM defined */

    l = nh->nh_datalen;
    pp = (struct packet *) (((u_char *)nh) + sizeof( struct nit_hdr ));
    
    skip = pp->p_skip;			/* fetch skip */
    skip = SSWAP( skip );		/* swap it */

    if( skip & 1 )
	return;				/* skip must not be odd */

    p2 = (u_char *) pp->p_data + skip;
    len = l - 14 - skip - 2;		/* length of data */

    if( len < 2 )			/* no room for function */
	return;

    cr = (struct ctp_reply *) p2;	/* get reply struct */
    f = CTP_SHORT( p2 );		/* get function */
    p2 += 2;				/* advance past function */
    len -= 2;				/* account for function length */
    switch( f ) {
    case CTP_REP:			/* reply */
	break;

    case CTP_FWD:
	return;				/* we are a client. */
	break;

    default:
/*	printf(" fncn %d. data: ", f );	/* !! */
	return;
    }

    if( cr->cr_pid != pid )		/* check for parent pid */
	return;

    p2 += 2;				/* advance past pid */
    len -= 4;				/* pid, seq */

    printf("%d bytes from ", l );
    petaddr( pp->p_src );
    seq = CTP_SHORT( p2 );
    ms = delta( &nh->nh_timestamp, &cr->cr_sendt );
    printf(": seq %2d. time=%dms\n", seq, ms );

# ifdef SHM
    sp->total++;
    if( seq != lastseq && seq != lastseq+1 )
	sp->outofseq++;
    lastseq = seq;
    if( ms > sp->max )
	sp->max = ms;
    if( ms < sp->min )
	sp->min = ms;
    if( seq > sp->highseq )
	sp->highseq = seq;
    sp->sum += ms;
    sp->sumsq = ms * ms;
    sp->counts[ seq & (NCOUNT-1) ]++;
# endif /* SHM defined */
} /* nit_input */

delta( a, b )
    struct timeval *a, *b;
{
    int usec, sec;
    usec = a->tv_usec - b->tv_usec;
    sec  = a->tv_sec  - b->tv_sec;

    if( usec < 0 )   {
	sec--;
	usec += 1000000;
    }
    usec += 999;			/* round to ms */
    sec = sec * 1000 + usec / 1000;	/* get ms */
    if( sec < 0 ) {
	printf("a: %d %d b: %d %d\n",
	       a->tv_sec, a->tv_usec,
	       b->tv_sec, b->tv_usec );
	return( 0 );
    } /* sec < 0 */
    return( sec );
} /* delta */

/****************************************************************/

ctp_send( s )
    int s;
{
    struct timezone tz;
    struct ctp_forward *cf;
    struct ctp_reply *cr, *ocr;
    struct packet p;
    u_char *cp;
    int i, c;

    printf("to ");
    for( i = 0; i < pathcount; i++ ) {
	if( i > 0 )
	    printf(", ");
	petaddr( path[i] );
    }

    /* fill in ether packet header */
    bcopy( path[ 0 ], p.p_dst, sizeof( p.p_dst ) ); /* fill in initial dest */
    p.p_type = ETHERTYPE_CTP;		/* fill in type */
    p.p_skip = SSWAP( 0 );		/* fill in initial CTP skip */

    cf = (struct ctp_forward *) p.p_data; /* get data pointer */
    for( i = 1; i < pathcount; i++ ) {
	cf->cf_function = SSWAP( CTP_FWD );
	bcopy( path[i], cf->cf_addr, sizeof( ea_t ) );
	cf++;				/* advance pointer */
    }

    /* ensure packet gets back -- append forward to ourselves */
    if( !noreturn &&
       bcmp( path[pathcount-1], localaddr, sizeof( localaddr ) ) != 0 ) {
	cf->cf_function = SSWAP( CTP_FWD );
	bcopy( localaddr, cf->cf_addr, sizeof( localaddr ) );
	cf++;
    }

    /* create reply data */
    cr = (struct ctp_reply *) cf;
    cr->cr_function = SSWAP( CTP_REP );
    cr->cr_pid = pid;			/* pid of parent */
    ocr = cr;				/* save pointer for timestamp */
    cr++;				/* advance past reply */

    cp = (u_char *) cr;			/* get pointer to reply data */
    i = cp - (u_char *)&p;		/* get length of packet so far */

    if( i > packlen )
	if( i > MAXPACK ) {
	    fprintf( stderr, "Packet too large without data (%d)\n", i );
	    exit( 1 );
	}
	else
	    packlen = i;

    printf(": %d data bytes (%d total)\n", packlen - i, packlen );
    fflush( stdout );

    while( i < packlen )
	*cp++ = i++ & 0xff;

    slptim *= 1000;			/* convert to usec */
    while( count != 0 ) {
	if( count > 0 )
	    count--;
	ocr->cr_seq = SSWAP( seq );
	seq++;				/* update sequence */
	gettimeofday( &ocr->cr_sendt, &tz );

	if( nit_output( s, &p, packlen ) < 0 )
	    perror( "write" );
	else
	    nsent++;
	usleep( slptim ); 
    }
    kill( child, SIGINT );
    stats();
    die();
} /* ctp_send */ 
