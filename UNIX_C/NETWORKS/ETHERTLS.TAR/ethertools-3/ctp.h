/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
/*
 *	Parameters for Ethernet Version 2
 *	Configuration Test Protocol
 *
 *	Philip Budne @ BU/DSG
 */

# define ETHERTYPE_CTP 0x9000

# define etcmp(a,b) (((*( (u_long *)a ))  == (*((u_long *)b))) && \
		     ((*( (u_short *)&a[4] )) == (*((u_short *)&b[4]))))

static u_char bcast[] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };	/* broadcast */
static u_char mcast[] = { 0xcf, 0x00, 0x00, 0x00, 0x00, 0x00 };	/* CTP mcast */

# define CTP_REP 1
# define CTP_FWD 2

# if defined(vax) || defined(ns32000)
# define CTP_SHORT(sp) (*(u_short *)(sp))
# define SSWAP(s) (s)
# else /* not defined(vax) || defined(ns32000) */
# define CTP_SHORT(sp) (*sp | (sp[1]<<8))
# define SSWAP(s) ((((s)>>8) & 0xff) | (((s)<<8) & 0xff00))
# endif /* not defined(vax) || defined(ns32000) */
