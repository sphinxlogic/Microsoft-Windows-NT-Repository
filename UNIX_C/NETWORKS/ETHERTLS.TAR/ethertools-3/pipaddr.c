/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
# include "packet.h"
int use_nameserver = 1;
# define NULL ((char *)0)

pipaddr( f, i )
    int f;
    ip_addr i;
{
    char *n, *lookup_name();
    if( f && use_nameserver && (n = lookup_name( i )) != NULL )
	printf("%s", n );
    else
	printf("%d.%d.%d.%d",
	   (i >> 24) & 255,
	   (i >> 16) & 255,
	   (i >> 8) & 255,
	   i & 255 );
}

