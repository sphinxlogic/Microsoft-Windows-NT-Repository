/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
/*
 *	show.c -- show ctp traffic
 *	Phil Budne @ BU/DSG
 *
 *	NOTE: user mode ctpd robs replies (?)
 */

# include <sys/types.h>
# include <sys/time.h>
# include <net/nit.h>
# include <stdio.h>
# include "ctp.h"

struct packet {
    u_char  p_dst[ 6 ];
    u_char  p_src[ 6 ];
    u_short p_type;
    u_char  p_data[ 2048 ];
};

u_char localaddr[ 6 ];
int count = -1;
int promisc = 1;
char *interface = "ie0";

main(argc, argv)
    int argc;
    char *argv[];
{
    extern char *optarg;
    extern int optind, opterr;
    int s, c, errs;
    void nit_input();			/* forward */

    errs = 0;
    while( (c = getopt( argc, argv, "c:i:p" )) != EOF ) {
	switch( c ) {
	case 'c':
	    count = atoi( optarg );
	    break;
	case 'i':
	    interface = optarg;
	    break;
	case 'p':
	    promisc ^= 1;
	    break;
	default:
	    errs++;
	}
    }
    if( errs > 0 )
	exit( 1 );

    /*NT_ALLTYPES*/
    s = nit_open( interface, ETHERTYPE_CTP, localaddr, promisc );
    printf("%s address ", interface );
    petaddr( localaddr );
    puts( "" );

    nit_loop( s, nit_input );		/* never returns */
} /* main */

/****************************************************************/

void
nit_input( s, nh )
    int s;
    struct nit_hdr *nh;
{
    int l;
    struct packet *pp;

    u_char *p2;
    short f, skip;
    int len, l2;

    l = nh->nh_datalen;
    pp = (struct packet *) (((u_char *)nh) + sizeof( struct nit_hdr ));

    printf("src ");
    petaddr( pp->p_src );
    printf(" dest ");
    petaddr( pp->p_dst );

    p2 = (u_char *) pp->p_data;
    skip = CTP_SHORT(p2);

    if( skip & 1 )
	return;				/* skip must not be odd */

    p2 += skip + 2;			/* point to data (skip skip!) */
    len = l - 14 - skip - 2;		/* length of data */

    printf(" skip %d.\n", skip );
    for( ; ; ) {
	if( len < 2 )
	    return;

	f = CTP_SHORT( p2 );		/* get function */
	p2 += 2;			/* advance past function */
	len -= 2;			/* account for function length */
	switch( f ) {
	case CTP_REP:			/* reply */
	    printf(" REPLY data: ");
	    goto break_for;
	    break;

	case CTP_FWD:			/* forward */
	    if( len < 6 ) {
		printf("Too little data for FORWARD packet\n");
		return;
	    }
	    printf(" FORWARD to: ");
	    petaddr( p2 );		/* print ether addr */
	    puts("");
	    p2 += 6;			/* advance data */
	    len -=6;			/* account for len */
	    break;

	default:
	    printf(" fncn %d. data: ", f );
	    goto break_for;
	}
    }
 break_for: ;
    l2 = len;
    if( l2 > 32 )
	l2 = 32;
    pbytes( p2, l2 );
    if( len > 32 )
	printf("...");
    puts("");


    if( count > 0 )
	if( --count == 0 )
	    exit( 0 );

}

pbytes( p, c )
    u_char *p;
    int c;
{
    while( c-- > 0 )
	printf("%02X", *p++ & 0xff );
}
