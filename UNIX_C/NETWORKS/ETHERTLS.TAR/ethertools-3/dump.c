/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
/*
 *	dump.c -- dump ether traffic
 *	Phil Budne @ BU/DSG
 *
 */

# include <sys/types.h>
# include <sys/time.h>
# include <net/nit.h>
# include <stdio.h>

u_char localaddr[ 6 ];
int count = -1;
int promisc = 1;
char ibuf[100];
char *interface = ibuf;

extern int nit_snaplen;

main(argc, argv)
    int argc;
    char *argv[];
{
    extern char *optarg;
    extern int optind, opterr;
    int s, c, errs, len;
    void nit_input();			/* forward */

    errs = 0;
    len = -1;
    while( (c = getopt( argc, argv, "c:i:l:p" )) != EOF ) {
	switch( c ) {
	case 'c':
	    count = atoi( optarg );
	    break;
	case 'i':
	    interface = optarg;
	    break;
	case 'l':
	    len = atoi( optarg );
	    break;
	case 'p':
	    promisc ^= 1;
	    break;
	default:
	    errs++;
	}
    }
    if( errs > 0 )
	exit( 1 );

    if( len > 0 )
	nit_snaplen = len;

    s = nit_open( interface, NT_ALLTYPES, localaddr, promisc );
    printf(" %s address ", interface );
    petaddr( localaddr );
    puts( "" );

    nit_loop( s, nit_input );		/* never returns */
} /* main */

/****************************************************************/

void
nit_input( s, nh )
    int s;
    struct nit_hdr *nh;
{
    int l, l2;
    u_char *pp;

    l = nh->nh_datalen;			/* wirelen? */
    pp = ((u_char *)nh) + sizeof( struct nit_hdr );

    while( l > 0 ) {
	l2 = l;
	if( l2 > 32 )
	    l2 = 32;
	pbytes( pp, l2 );
	puts("");
	pp += l2;
	l -= l2;
    }
    puts("");

    if( count > 0 )
	if( --count == 0 )
	    exit( 0 );

}

pbytes( p, c )
    register u_char *p;
    register int c;
{
    while( c-- > 0 )
	puthex( *p++ & 0xff );
}
