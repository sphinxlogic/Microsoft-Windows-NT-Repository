/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
struct protocol {
    unsigned short pr_type;
    char *pr_short;
    char *pr_name;
} protocols[] = {
    0x0200,	"PUP",		"Xerox PUP", /* 802.3 length!! */
    0x0201,	"PUPAT",	"Xerox PUP Addr. Trans.", /* 802.3 length!! */
    0x0600,	"XNS",		"Xerox NS (XNS) IDP",
    0x0800,	"IP",		"DoD IP",
    0x0801,	"X.75",		"X.75 Internet",
    0x0802,	"NBS",		"NBS Internet",
    0x0803,	"ECMA",		"ECMA Internet",
    0x0804,	"Chaos",	"Chaosnet",
    0x0805,	"X.25",		"X.25 Level 3",
    0x0806,	"ARP",		"Address Resolution Protocol (ARP)",
    0x0807,	"XNScomp",	"XNS Compatibility",
    0x081c,	"Symbolics",	"Symbolics Private",
    0x0888,	"Xyplex",	"Xyplex",
    0x0a00,	"PUP2",		"802.3 Xerox PUP",
    0x0a01,	"PUPAT2",	"802.3 PUP Address Translation",
    0x0bad,	"Banyan",	"Banyan Systems",
    0x1000,	"TRAIL0",	"Berkeley Trailer negotiation",
    0x1001,	"TRAIL1",	"Berkeley Trailer 1",
    0x1002,	"TRAIL2",	"Berkeley Trailer 2",
    0x1003,	"TRAIL3",	"Berkeley Trailer 3",
    0x1004,	"TRAIL4",	"Berkeley Trailer 4",
    0x1005,	"TRAIL5",	"Berkeley Trailer 5",
    0x1006,	"TRAIL6",	"Berkeley Trailer 6",
    0x1007,	"TRAIL7",	"Berkeley Trailer 7",
    0x1008,	"TRAIL8",	"Berkeley Trailer 8",
    0x1009,	"TRAIL9",	"Berkeley Trailer 9",
    0x100a,	"TRAIL10",	"Berkeley Trailer 10",
    0x100b,	"TRAIL11",	"Berkeley Trailer 11",
    0x100c,	"TRAIL12",	"Berkeley Trailer 12",
    0x100d,	"TRAIL13",	"Berkeley Trailer 13",
    0x100e,	"TRAIL14",	"Berkeley Trailer 14",
    0x100f,	"TRAIL15",	"Berkeley Trailer 15",
    0x1600,	"VALID",	"VALID",
    0x5208,	"Simnet",	"BBN Simnet Private",
    0x6000,	"DEC XP",	"DEC XP",
    0x6001,	"DEC DL-MOP",	"DEC Dump/Load Maintenance Operation Protocol",
    0x6002,	"DEC RE-MOP", 	"DEC Remote Console Maintenance Operation",
    0x6003,	"DECnet",	"DECNET Phase IV",
    0x6004,	"LAT",		"DEC LAT - Local Area Transport",
    0x6005,	"DEC diag?",	"DEC interface initialization / diagnostics?",
    0x6006,	"DEC customer",	"DEC customer use",
    0x6007,	"DEC SCA/LAVC",	"DEC Sy. Comm. Arch. / Local Area VAX Cluster",
    0x6008,	"DEC ??",	"DEC unassigned",
    0x6009,	"DEC ??",	"DEC unassigned",
    0x7000,	"UB/down",	"Ungerman Bass download",
    0x7002,	"UB/diag",	"Ungerman Bass diag/loopback",
    0x7030,	"Interlan",	"Interlan 3010 test packet?",
    0x8003,	"Cronus VLN",	"Cronus VLN",
    0x8004,	"Cronus Direct","Cronus Direct",
    0x8005,	"HP Probe",	"HP Probe protocol",
    0x8006,	"Nestar",	"Nestar",
    0x8008,	"3BNET",	"ATT 3BNET",
    0x8010,	"Excelan",	"Excelan",
    0x8013,	"SGI diag",	"Silicon Graphics diagnostic",
    0x8014,	"SGI games",	"Silicon Graphics network games",
    0x8015,	"SGI reserved",	"Silicon Graphics reserved type",
    0x8016,	"SGI bounce",	"Silicon Graphics XNS nameserver/bounce",
    0x8019,	"Apollo",	"Apollo DOMAIN",
    0x8035,	"RARP",		"Reverse ARP",
    0x8038,	"DEBET",	"DEC LanBridge (Debet) Management",
    0x8039,	"DEC ?",	"DEC unassigned",
    0x803a,	"DEC ?",	"DEC unassigned",
    0x803b,	"DEC ?",	"DEC unassigned",
    0x803c,	"DEC ?",	"DEC unassigned",
    0x803d,	"DEC EEP",	"DEC Ethernet Encryption Protocol",
    0x803e,	"DEC ?",	"DEC unassigned",
    0x803f,	"DEC LTM",	"DEC Lan Traffic Monitor",
    0x8040,	"DEC ?",	"DEC unassigned",
    0x8041,	"DEC ?",	"DEC unassigned",
    0x8042,	"DEC ?",	"DEC unassigned",
    0x805b,	"exp. V",	"Stanford V Kernel experimental",
    0x805c,	"prod. V",	"Stanford V Kernel production",
    0x807c,	"Merit",	"Merit Internodal",
    0x807d,	"Vitalink ?",	"Vitalink ?",
    0x807e,	"Vitalink ?",	"Vitalink ?",
    0x807f,	"Vitalink ?",	"Vitalink ?",
    0x8080,	"Vitalink mgmt","Vitalink TransLAN III bridge mgmt",
    0x809b,	"EtherTalk",	"Ethernet/AppleTalk",
    0x809c,	"EtherTalk Arp","Ethernet/AppleTalk Arp", /* ?? */
    0x80de,	"TRFS",		"Integrated Solutions Transparent Remote File System",
    0x80f3,	"Appletalk ARP?","Appletalk ARP??", /* ?? */
    0x8107,	"Symbolics",	"Symbolics Private",
    0x8108,	"Symbolics",	"Symbolics Private",
    0x8109,	"Symbolics",	"Symbolics Private",
    0x8137,	"Novell",	"Novell", /* netware?? */
    0x9000,	"CTP",		"Configuration Test Protocol (CTP) Loopback",
    0x9001,	"BRIDGEbridge",	"BRIDGE bridge mgmt", /* XNS mgmt? */
    0x9002,	"BRIDGEterm",	"BRIDGE terminal server", /* TCP/IP mgmt? */
    0xff00,	"VITAL",	"BBN VITAL LANBridge cache wakeups",
    0,		""
};

# define NPROTO (((sizeof protocols)/(sizeof( struct protocol )))-1)
