/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
# include <sys/ioctl.h>			/* TIOCNOTTY */
# include <sys/types.h>
# include <sys/time.h>
# include <net/nit.h>
# include <stdio.h>
# include "ctp.h"

struct packet {
    u_char  p_dst[ 6 ];
    u_char  p_src[ 6 ];
    u_short p_type;
    u_char  p_data[ 2048 ];
};

u_char localaddr[ 6 ];
int debug = 0;
char *interface = "ie0";

main(argc, argv)
    int argc;
    char *argv[];
{
    extern char *optarg;
    extern int optind, opterr;
    int s, c, errs;
    void nit_input();			/* forward */

    errs = 0;
    while( (c = getopt( argc, argv, "di:" )) != EOF ) {
	switch( c ) {
	case 'd':
	    debug++;
	    break;
	case 'i':
	    interface = optarg;
	    break;
	default:
	    errs++;
	}
    }
    if( errs > 0 )
	exit( 1 );

    s = nit_open( interface, ETHERTYPE_CTP, localaddr, 1 );
    if( s < 0 )
	exit( 1 );

    printf("%s address ", interface );
    petaddr( localaddr );
    puts( "" );
    if( !debug ) {
	int i;

	i = fork();
	if( i < 0 ) {
	    perror( "fork" );
	    exit( 1 );
	}
	else if( i != 0 )
	    exit( 0 );

	for( i = getdtablesize() - 1; i >= 0; i-- )
	    if( i != s )
		close( i );
	open( "/", 0 );
	dup( 0 );
	dup( 0 );
	if( (i = open( "/dev/tty", 0)) >= 0 ) {
	    ioctl( i, TIOCNOTTY, 0 );
	    close( i );
	}
    }

    nit_loop( s, nit_input );		/* never returns */
} /* main */

/****************************************************************/

void
nit_input( s, nh )
    int s;
    struct nit_hdr *nh;
{
    int l;
    struct packet *pp;
    u_char *p2, *p3;
    short f, skip;
    int len, l2;

    l = nh->nh_datalen;
    pp = (struct packet *) (((u_char *)nh) + sizeof( struct nit_hdr ));

    if( !etcmp( pp->p_dst, bcast ) &&
        !etcmp( pp->p_dst, mcast ) &&
        !etcmp( pp->p_dst, localaddr ) )
	return;

    p2 = (u_char *) pp->p_data;
    skip = CTP_SHORT(p2);

    if( skip & 1 )
	return;				/* skip must not be odd */

    p3 = p2 + skip + 2;			/* point to data (skip skip!) */
    len = l - 14 - skip - 2;		/* length of data */

    if( debug )
	printf("CTP skip %d.\n", skip );
    if( len < 2 )
	return;

    f = CTP_SHORT( p3 );		/* get function */
    p3 += 2;				/* advance past function */
    len -= 2;				/* account for function length */
    switch( f ) {
	case CTP_REP:			/* reply */
	/* we're a server! */
	break;

    case CTP_FWD:			/* forward */
	if( len < 6 ) {
	    if( debug )
		printf("Too little data for FORWARD packet\n");
	    return;
	}
	if( debug ) {
	    printf(" FORWARD to: ");
	    petaddr( p3 );		/* print ether addr */
	    puts("");
	}
	if( *p3 & 0x01 ) {
	    if( debug )
		printf("will not forward to multicast/broadcast\n");
	    return;
	}
	skip += 6 + 2;			/* skip function and address */
	* ((u_short *)p2) = SSWAP( skip );
	bcopy( localaddr, pp->p_src, sizeof( pp->p_src ) );
	bcopy( p3, pp->p_dst, sizeof( pp->p_dst ) );
	if( nit_output( s, pp, l ) < 0 )
	    perror( "nit output" );
	break;

    default:
	if( debug )
	    printf(" fncn %d.\n", f );
	break;
    }
}
