/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
# include <stdio.h>
# include <netdb.h>			/* for hostent */
# include <sys/types.h>			/* for socket.h */
# include <sys/socket.h>		/* AF_INET */
# include <ctype.h>

htoea( h, ea )
    char *h, *ea;
{
    struct hostent *he;
    int tempea[6], tempip;
    int i;

    if( sscanf( h, "%x-%x-%x-%x-%x-%x",	/* Xerox/DEC/Intel format? */
	        &tempea[0], &tempea[1], &tempea[2],
	        &tempea[3], &tempea[4], &tempea[5] ) == 6 ||
       sscanf( h, "%x:%x:%x:%x:%x:%x",	/* BSD format? */
	        &tempea[0], &tempea[1], &tempea[2],
	        &tempea[3], &tempea[4], &tempea[5] ) == 6 ) {
	for( i = 0; i < 6; i++ )
	    *ea++ = tempea[i] & 0xff;	/* complain if gt 8 bits? */
	return( 1 );
    }

    if( isalpha( h[0] ) ) {
	if( ether_hostton( h, ea ) == 0 ) /* look up in /etc/ethers */
	    return( 1 );		/* we win! */

	if( (he = gethostbyname( h )) != NULL ) { /* get host ent */
	    if( hostenttoea( he, ea ) )	/* look up name in /etc/hosts */
		return( 1 );
	}

	if( strcmp( h, "BCAST" ) == 0 ) { /* do last? */
	    for( i = 0; i < 6; i++ )
		*ea++ = 0xff;
	    return( 1 );
	}
    }

    /* @@ handle 96 hex digits, 48hex-48hex */

    /* after hex format */
    if( (tempip = inet_addr( h )) != 0) { /* ip octets? */
	if( iptoea( &tempip, ea ) )
	    return( 1 );

	if( (he = gethostbyaddr( &tempip, 4, AF_INET )) != NULL )
	    if( hostenttoea( he, ea ) )
		return( 1 );
    }
    return( 0 );
}
