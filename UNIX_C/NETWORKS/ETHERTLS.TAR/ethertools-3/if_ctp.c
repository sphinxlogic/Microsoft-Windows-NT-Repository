/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
/*
 * if_ctp.c -- Ethernet Version 2 Configuation Test Protocol (CTP)
 *
 * DEC DEUNA does this at the controller level??
 */


/*
 * Called from do_protocol in sunif/if_subr.c;
 *
 *#endif INET
>*#ifdef ETHERPUP_CTPTYPE:
>*	case ETHERPUP_CTPTYPE:
>*		ctp_input( header, m, &ap->ac_if );
>*		break;
>*#endif ETHERPUP_CTPTYPE:
 *	default:
 */

/*
 * add to /sys/conf/files;
 * sunif/if_ctp.c		optional ether
 */

/* add to netinet/if_ether.h;
/* #define ETHERTYPE_CTP	0x9000		/* Config. Test Protocol */
/* ... */
/* #define ETHERPUP_CTPTYPE	0x9000		/* Config. Test Protocol */


# include "ether.h"

# if NETHER > 0
# include "../h/param.h"
# include "../h/systm.h"
# include "../h/mbuf.h"
# include "../h/socket.h"
# include "../h/time.h"
# include "../h/kernel.h"
# include "../h/errno.h"
# include "../h/ioctl.h"

# include "../net/if.h"
# include "../netinet/in.h"		/* for if_ether */
# include "../netinet/if_ether.h"	/* for ether_header */

# define DEBUG

# define CTP_REP 1
# define CTP_FWD 2

# if defined(vax) || defined(ns32000)	/* machine is a byteswapper? */
# define SWAP(s) (s)			/* CTP wants them swapped!! */
# else /* not defined(vax) || defined(ns32000) */
# define SWAP(s) ((((s)>>8) & 0xff) | (((s)<<8) & 0xff00))
# endif /* not defined(vax) || defined(ns32000) */

# ifndef ETHERTYPE_CTP
# define ETHERTYPE_CTP 0x9000		/* 90-00 */
# endif /* ETHERTYPE_CTP not defined */

# define SP(s) ((u_short *)s)
# define SS (sizeof(short))

int ctp_rawinput;			/* total input */
int ctp_reply;				/* replies to us */
int ctp_forward;			/* packets forwarded */
int ctp_multicast;			/* err: forward to multicast!! */
int ctp_badfunction;			/* err: bad function */
int ctp_errs;				/* other errs */
ctp_input( h, m, myif )
    register struct ether_header *h;
    register struct mbuf *m;
    struct ifnet *myif;
{
    ctp_rawinput++;

    if( !ctp_process( h, m ) )		/* no reply generated?? */
	m_freem(m);			/* discard buffer */
}

static ctp_process( h, m, myif )
    register struct ether_header *h;
    register struct mbuf *m;
    struct ifnet *myif;
{
    register u_short func, skip;
    register u_char *cp;
    register int l;

    struct ether_header *eh;
    struct sockaddr sa;

    l = m->m_len;			/* get data length */
    cp = mtod(m, u_char *);		/* get data pointer */

    /****************************************************************
     * process skip
     */

    l -= SS;
    if( l < 0 ) {
# ifdef DEBUG
	ctp_msg( h );
	printf("-- too short for skip\n", skip );
# endif /* DEBUG defined */
	ctp_errs++;
	return( 0 );			/* no reply generated */
    }

    skip = *SP( cp );			/* get skip */
    skip = SWAP( skip );		/* byte swap if needed */
    cp += SS;

    if( skip & 1 ) {
# ifdef DEBUG
	ctp_msg( h );
	printf("-- odd skip %d\n", skip );
# endif /* DEBUG defined */
	ctp_errs++;
	return( 0 );			/* no reply generated */
    }

    /****************************************************************
     * process function
     */

    l -= skip;
    if( l < 0 ) {
# ifdef DEBUG
	ctp_msg( h );
	printf("-- skip too large (%d.)\n", skip );
# endif /* DEBUG defined */
	ctp_errs++;
	return( 0 );			/* no reply generated */
    }

    cp += skip;				/* get address of function */

    func = *SP( cp );			/* get function */
    func = SWAP( func );		/* byte swap if needed */

    l -= SS;				/* deduct function length */
    cp += SS;				/* advance past function */

    switch( func ) {

    case CTP_REP:			/* reply */
# ifdef DEBUG
	ctp_msg( h );
	printf("-- reply, %d bytes\n", l);
# endif /* DEBUG defined */
	/* create AF_CTP and pass up to users?? */
	ctp_reply++;
	return( 0 );			/* no reply generated */
	break;

    case CTP_FWD:
	l -= sizeof( struct ether_addr );
	if( l < 0 ) {
# ifdef DEBUG
	    ctp_msg( h );
	    printf("-- forward too short\n");
# endif /* DEBUG defined */
	    ctp_errs++;
	    return( 0 );
	}
	if( *cp & 1 ) {			/* multicast bit */
	    ctp_msg( h );
	    printf(" -- forward to multicast address ");
	    ether_print( cp );
	    printf(" ignored\n");
	    ctp_multicast++;
	    return( 0 );		/* no reply generated */
	}
# ifdef DEBUG
	ctp_msg( h );
	printf("-- forwarding %d bytes to ", l);
	ether_print( cp );
# endif /* DEBUG defined */
	skip += SS + sizeof( struct ether_addr ); /* skip forward function */
					/* and address */
	*mtod(m, u_short *) = SWAP( skip ); /* update in packet */

	sa.sa_family = AF_UNSPEC;		/* set family */
	eh = (struct ether_header *)sa.sa_data;	/* get sockaddr */
	eh->ether_type = ETHERTYPE_CTP;		/* set ether type */
	eh->ether_dhost = *(struct ether_addr *) cp; /* copy dest */
	(myif->if_output)( myif, m, &sa );

	ctp_forward++;
	return( 1 );			/* AH-HAH!! we generated a reply!! */
	break;

    default:
# ifdef DEBUG
	ctp_msg( h );
	printf("-- bad function %d.\n", func );
# endif /* DEBUG defined */
	ctp_badfunction++;
	return( 0 );
	break;
    }
    return( 0 );			/* just in case */
} /* ctp_process */

ctp_msg( h )
    register struct ether_header *h;
{
    printf("CTP packet from ");
    ether_print( &h->ether_shost );
} /* ctp_msg */

# endif /* NETHER > 0 */
