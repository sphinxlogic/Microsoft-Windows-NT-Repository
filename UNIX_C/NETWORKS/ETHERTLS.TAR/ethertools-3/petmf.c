/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
# include <stdio.h>
# include "mfgr.h"

petmf( a )				/* print ether mfgr name */
    register unsigned char *a;
{
    long mfc;
    register MFGR *mf;

    mfc = (((a[0] << 8) + a[1]) << 8) + a[2]; /* top 24 bits */

    /* check for IEEE "local" bit??? @@ */
    if( *a & 1 ) {			/* logical address? */
	register int broadcast, i;

	broadcast = 1;			/* set true */
	for( i = 0; broadcast && i < 6; i++ )
	    if( a[i] != 0xff )
		broadcast = 0;

	if( broadcast )
	    printf( "broadcast" );
	else
	    printf( "%smulticast", "" /* lookup registry of mfc */ );
	return;
    } /* logical */

    /* @@TLU */
    for( mf = mfgrs; mf->mf_code != 0; mf++ )
	if( mf->mf_code == mfc ) {
	    printf( "%s", mf->mf_name );
	    return;
	}
	else if( mf->mf_code > mfc )
	    break;

    printf( "unknown");
}
