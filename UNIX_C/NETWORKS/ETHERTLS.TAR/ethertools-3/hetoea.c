/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
# include <stdio.h>
# include <netdb.h>			/* for hostent */
# include <sys/types.h>			/* for socket.h */
# include <sys/socket.h>		/* AF_INET */

hostenttoea( he, ea )
    struct hostent *he;
    char *ea;
{
    char **ap;

    if( ether_hostton( he->h_name, ea ) == 0 ) /* try official name */
	return( 1 );			/* in ethers file */
	
    for( ap = he->h_aliases; *ap != NULL; ap++ )
	if( ether_hostton( *ap, ea ) == 0 ) /* try aliases in ethers file */
	    return( 1 );

    if( he->h_addrtype == AF_INET )	/* is inet host?? */
	if( iptoea( he->h_addr, ea ) )	/* try to convert to ea */
	    return( 1 );

    return( 0 );
} /* hostenttoea */
