/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
# include <stdio.h>
# include <ctype.h>
# include "packet.h"

# define EP_PUP		0x0200
# define EP_XNS		0x0600
# define EP_IP		0x0800
# define EP_CHAOS	0x0804
# define EP_ARP		0x0806
# define EP_TRAIL	0x1000		/* TO DO! */
# define EP_RARP	0x8035		/* TO DO! */
# define EP_CTP		0x9000

int	dumpdata = 1;
int	indent = 0;

/* counts: */
int	count		= 0;
int	 ipcount	= 0;
int	  icmpcount	= 0;
int	  tcpcount	= 0;
int	  udpcount	= 0;
int	  ndcount	= 0;
int	  ippupcount	= 0;
int	  ipidpcount	= 0;
int	  egpcount	= 0;
int	  ggpcount	= 0;
int	  ipfragcount   = 0;
int	  ipothercount	= 0;
int	  ipbadvercount	= 0;
int	 arpcount	= 0;
int	 rarpcount	= 0;
int	 ieeecount	= 0;
int	 pupcount	= 0;
int	 xnscount	= 0;
int	 othercount	= 0;
int	 ctpcount	= 0;

/****************************************************************/
# include "protocol.h"
int pr_count[ NPROTO ];
/****************************************************************/

int pc;					/* packet byte count */

main() {
    char line[ 4096 ];
    register byte *pp;
    register char *lp;

    pc = 0;
    pp = packet.p_bytes;
    while( gets( line ) ) {
	if( line[0] == ' ' || line[0] == '*' || line[0] == '\0' ) {
	    if( pc > 0 )
		process();
	    pp = packet.p_bytes;
	    pc = 0;
	    continue;
	}

	for( lp = line; *lp; lp++ ) {
	    if( isspace( *lp ) )
		continue;
	    else if( isxdigit( *lp ) && isxdigit( lp[1] ) ) {
		*pp++ = xval( *lp, lp[1] );
		lp++;
		pc++;
	    }
	    else
		fprintf( stderr, "you lose: %s\n", lp );
	}
    }
    if( pc > 0 )
	process();
    dump_stats();
}

process() {
    register struct etherpacket *e = (struct etherpacket *) &packet;
    u_short type;

    count++;

    terpri();
    printf("Packet #%d\n", count );

    type = packet.p_ether.e_type;
    printf("Ether type %02X-%02X len %d ",
	   (type >> 8) & 255, type & 255, pc );


    petaddr( e->e_src );
    putchar(' ');
    putchar('>');
    putchar(' ');
    petaddr( e->e_dst );
    terpri();

    switch( type ) {
    case EP_PUP:
	process_pup();
	break;
    case EP_IP:
	process_ip( 1, &packet.p_ether.e_data.d_ip );
	break;
    case EP_ARP:
	process_arp();
	break;
    case EP_RARP:
	process_rarp();
	break;
    case EP_XNS:
	process_xns();
	break;
    case EP_CTP:
	process_ctp();
	break;
    default:
# ifdef IEEE
	if( packet.p_ether.e_type < 0x0600 )
	    process_ieee( type );
	else
# endif /* IEEE defined */
	    process_other( type );
	break;
    }
    fflush( stdout );
    fflush( stderr );
}

process_ip( live, i )
    int live;				/* true if a real packet */
					/* false for icmp sent headers */
    register struct ipheader *i;
{
    register byte *d, *op;
    int size;

    if( live) 
	ipcount++;

    if( i->ip_ver != 4 ) {
	printf("IP version not 4 (%d)", i->ip_ver );
	terpri();
	ipbadvercount++;
	return;
    }

    printf("IP ");
    pipaddr( 1, i->ip_src );
    printf(" > ");
    pipaddr( 1, i->ip_dst );

    printf(" len %d",i->ip_len );

    if( i->ip_flgs & IP_FLG_DF )	/* don't frag */
	printf(" df");

    if( i->ip_flgs & IP_FLG_MF )	/* more frags/last frag */
	printf(" mf");

/*    if( i->ip_ttl != 0 && i->ip_ttl != 255 ) /**/
	printf(" ttl %d", i->ip_ttl );

    if( i->ip_tsrv != 0 ) {
	if( (i->ip_tsrv>>5) & 07 )
	    printf(" prec %d", ((i->ip_tsrv>>5) & 07) );
	if( i->ip_tsrv & 020 )
	    printf(" low_delay");
	if( i->ip_tsrv & 010 )
	    printf(" hi_thruput");
	if( i->ip_tsrv & 04 )
	    printf(" hi_rely");
    }

    /* more frags or offset? */
    printf(" id %d", i->ip_id );
    printf(" off %d", i->ip_foff << 3 );

    if( (i->ip_flgs & (IP_FLG_MF|IP_FLG_DF)) || i->ip_foff != 0 ) {
	if( i->ip_foff ) {
	    if( live )
		ipfragcount++;
	}
    }
    terpri();

    d = ((byte *)(i)) + (i->ip_ihl << 2); /* point to data */

    /* options processing!! never tested */
    op = i->ip_options;
    while( op < d ) {
	if( *op & 0200 )
	    printf(" copy");

	switch( ((*op)>>5)&03 ) {	/* print option class */
					/* perhaps only for unkn types? */
	case 0:
	    printf(" control");
	    break;
	case 2:
	    printf(" debug/meas");
	    break;
	case 1:
	    printf(" reserved1");
	    break;
	case 3:
	    printf(" reserved3");
	    break;
	}

	switch( (*op) & 017 ) {
	case 0:				/* end of list */
	    goto end_of_options;
	    
	case 1:
	    printf(" noop");
	    op++;
	    break;
	    
	case 2:
	    printf(" security %02X %02X", op[2], op[3] );
	    op += op[1];			/* should be 11 */
	    break;
	    
	case 3:
	    printf(" LS+RR");		/* loose source */
	    /* print more info! */
	    op += op[1];
	    break;
	    
	case 4:
	    printf(" TIMESTAMP");
	    switch( op[3] &0xf ) {
	    case 0:
		break;			/* time stamps only */
	    case 1:
		printf("+ADDRESS");
		break;
		
	    case 2:
		printf(" ?flag 2?");
		break;
		
	    case 3:
		printf(" (prespec)");
		break;
	    }
	    
	    if( op[3] & 0xf0 )
		printf(" %d overflows", (op[3]>>4)&0xf );
	    
	    op += op[1];
	    break;
	    
	case 7:
	    printf(" RR");
	    /* print more info! */
	    op += op[1];
	    break;
	    
	case 8:
	    printf(" SATNET_Stream_ID");
	    /* print more info! */
	    op += op[1];			/* should be 4 */
	    break;
	    
	case 9:
	    printf(" SS+RR");		/* strict source */
	    /* print more info! */
	    op += op[1];
	    break;
	    
	default:
	    printf(" option %d.", *op&017 );
	    op += op[1];
	    break;
	} /* switch on option number */
	terpri();
    } /* while op */

end_of_options: ;

    if( i->ip_foff != 0 && live ) {
	printf("  FRAGMENT (proto %d.)", i->ip_prot );
	terpri();
	return;				/* ?? */
    }

    size = pc - (d - packet.p_bytes);

    switch( i->ip_prot ) {
    case IP_PROT_UDP:
	if( live )
	    udpcount++;
	process_ip_udp( d, size );
	break;
    case IP_PROT_TCP:
	if( live )
	    tcpcount++;
	process_ip_tcp( d, size );
	break;
    case IP_PROT_ND:
	if( live )
	    ndcount++;
	process_ip_nd( d, size );
	break;
    case IP_PROT_ICMP:
	if( live )
	    icmpcount++;
	process_ip_icmp( d );
	break;
    case IP_PROT_GGP:
	printf("GGP");
	terpri();
	if( live )
	    ggpcount++;
	/* process?? */
	break;
    case IP_PROT_EGP:
	printf("EGP");
	terpri();
	if( live )
	    egpcount++;
	/* process?? */
	break;
    case IP_PROT_PUP:
	printf("PUP-IP");
	terpri();
	if( live )
	    ippupcount++;
	break;
    case IP_PROT_IDP:			/* xns idp */
	printf("IDP-IP (xns)");
	terpri();
	if( live )
	    ipidpcount++;
	/* process?? */
	break;
    default:
	printf(" ipproto %d", i->ip_prot );
	terpri();
	if( live )
	    ipothercount++;
    }
}

process_ip_udp( d )
byte *d;
{
    register struct udpheader *u = (struct udpheader *) d;
    printf("UDP srcp: %d destp: %d", u->udp_srcp, u->udp_dstp );
    terpri();
}

process_ip_tcp( d, size )
byte *d;
{
    register struct tcpheader *t = (struct tcpheader *) d;
    register byte *o, *td;
    int c, l;

    printf("TCP srcp: %d destp: %d", t->tcp_srcp, t->tcp_dstp );

    if( t->tcp_furg )
	printf(" urg %#x", t->tcp_urg );
    if( t->tcp_fack )
	printf(" ack %#x", t->tcp_ack );
    if( t->tcp_psh )
	printf(" psh");
    if( t->tcp_rst )
	printf(" rst");
    if( t->tcp_syn )
	printf(" syn");
    if( t->tcp_fin )
	printf(" fin");
    printf(" window %d.", t->tcp_win );

    c = ((t->tcp_thl) << 2);		/* get tcp data offset */

    size -= c;				/* get size of data */
    td = d + c;				/* start of tcp data */

    printf(" data %d.", size );

    o = d + sizeof( struct tcpheader );	/* get start of options */
    c -= sizeof( struct tcpheader );	/* get size of options */

    while( c > 0 ) {			/* process tcp options */
	switch( *o ) {
	case 0:				/* end of list */
	    goto break_options_loop;

	case 1:				/* nop */
	    l = 1;
	    break;

	case 2:				/* mss */
	    l = o[1];
	    if( l != 4 ) {
		printf("BAD_mss"); 
	    }
	    else
		printf(" mss %d", *((u_short *)(&o[2])) );
	    break;

	default:
	    l = o[1];
	    printf(" option %d. (len %d.)", *o, l );
	    break;
	} /* switch */
	o += l;
	c -= l;
    } /* tcp options loop */
 break_options_loop:;

    terpri();

    if( dumpdata ) {
	while( size-- > 0 )
	    putbyte( *td++ );
	terpri();
    }
} /* process_ip_tcp */

putbyte( c ) {
    if( c >= ' ' && c <= 0176 )
	putchar( c );
    else
	switch( c ) {
	case '\n':
	    printf("\\n");
	    break;
	case '\r':
	    printf("\\r");
	    break;
	case '\f':
	    printf("\\f");
	    break;
	/* ** MORE ESCAPES ** @@ */
	default:
	    printf("\\%#o", c & 0xff );
	    break;
	} /* switch */
} /* putbyte */

process_ip_icmp( d )
byte *d;
{
    register struct icmppacket {
	byte icmp_type, icmp_code;
	u_short icmp_cksum;
	union {
	    u_short id_short[2];
	    u_long  id_long[1];
	    byte    id_byte[4];
	} icmp_data;
	struct ipheader icmp_ip;
    } *i = (struct icmppacket *) d;

    static char *icmp_unreach_names[] = {
	"net", "host", "proto", "port", "need frag", "srcroute failed" };
# define N_ICMP_UNREACH_NAMES (sizeof( icmp_unreach_names ) / sizeof( char * ))

    printf("ICMP ");
    switch( i->icmp_type ) {
    case 0:				/* ECHOREPLY */
    case 8:				/* ECHO */
	printf("echo");
	if( i->icmp_type == 0 )
	    printf(" reply");
	printf(" id %d seq %d data: ",
	       i->icmp_data.id_short[0], i->icmp_data.id_short[1] );
	pbytes( &i->icmp_data.id_byte[4], 16 );
	terpri();
	return;
	break;

    case 3:				/* ICMP_UNREACH */
	if( i->icmp_code < N_ICMP_UNREACH_NAMES )
	    printf("unreachable %s", icmp_unreach_names[ i->icmp_code ] );
	else
	    printf("unreachable (code %d)", i->icmp_code );
	break;

    case 4:
	printf("source quench");
	break;

    case 5:				/* ICMP_REDIRECT */
	printf("redirect");
	if( i->icmp_code == 0 )
	    printf(" net");
	else if( i->icmp_code == 1 )
	    printf(" host");
	else if( i->icmp_code == 2 )
	    printf(" tos/net");
	else if( i->icmp_code == 3 )
	    printf(" tos/host");
	else
	    printf(" (code %d)", i->icmp_code );
	printf(" to ");
	pipaddr( 1, i->icmp_data.id_long[0] );
	break;

    case 11:
	switch( i->icmp_code ) {
	case 0:
	    printf("ttl exceeded");
	    break;
	case 1:
	    printf("reassembly ttl exceeded");
	    break;
	default:
	    printf("time exceeded code %d", i->icmp_code );
	    break;
	}
	break;

    case 12:
	printf("parmeter problem at %d", i->icmp_data.id_byte[0] );
	break;

    case 13:
    case 14:
	printf("timestamp");
	if( i->icmp_type == 14 )
	    printf(" reply");
	printf(" id %d seq %d",
	       i->icmp_data.id_short[0], i->icmp_data.id_short[1] );
	terpri();
	printf("orig ");
	ptime( i->icmp_data.id_long[1] );

	if( i->icmp_type == 14 ) {	/* reply */
	    printf(" rcv ");
	    ptime( i->icmp_data.id_long[2] );
	    printf(" xmit ");
	    ptime( i->icmp_data.id_long[3] );
	}
	terpri();
	return;
	break;

    case 15:
	printf("info request id %d seq %d",
	       i->icmp_data.id_short[0], i->icmp_data.id_short[1] );
	terpri();
	return;
	break;

    case 16:
	printf("info reply id %d seq %d",
	       i->icmp_data.id_short[0], i->icmp_data.id_short[1] );
	terpri();
	return;
	break;

    case 17:
	printf("mask request id %d seq %d",
	       i->icmp_data.id_short[0], i->icmp_data.id_short[1] );
	terpri();
	return;				/* no enacpsulated packet */
	break;

    case 18:
	printf("mask reply id %d seq %d ",
	       i->icmp_data.id_short[0], i->icmp_data.id_short[1] );
	pipaddr( 0, i->icmp_data.id_long[1] );
	terpri();
	return;				/* no enacpsulated packet */
	break;

    default:
	printf("type %d", i->icmp_type );
	if( i->icmp_code != 0 )
	    printf(" (code %d)", i->icmp_code );
	printf(" data: ");
	pbytes( i->icmp_data.id_byte, 4 );
	terpri();
	return;				/* no enacpsulated packet?? */
	break;
    }

    indent += 4;
    terpri();
    process_ip( 0, &i->icmp_ip );	/* RECURSE!! */
    indent -= 4;
    terpri();
}

ptime( t )
u_long t;
{
    int h, m, s;
    if( t & 0x40000000 ) {
	printf( "%d.", t & 0xbfffffff );
	return;
    }
    s = t / 1000;
    m = s / 60;
    h = m / 60;

    m %= 60;
    s %= 60;
    t %= 1000;
    if( h > 0 )
	printf("%dh", h );
    if( m > 0 )
	printf("%dm", m  );
    printf("%d.%03d", s, t );
}

process_ip_nd( d )
byte *d;
{
    register struct ndpacket *n = (struct ndpacket *) d;

    printf("ND");

    switch( n->nd_op & 7 ) {
    case 1:
	printf(" read");
	break;
    case 2:
	printf(" write");
	break;
    case 3:
	printf(" error");
	break;
    default:
	printf(" op %d", n->nd_op & 7 );
	break;
    }
    if( n->nd_op & 010 )
	printf(" wait");
    if( n->nd_op & 020 )
	printf(" done");

    printf(" /dev/nd");
    if( n->nd_dev > 0177 )
	putchar('l');
    else if( n->nd_dev > 077 )
	putchar('p');
    printf("%d seq %d",  n->nd_dev & 077, n->nd_seq );
    printf(" block %d count %d",
	   n->nd_blk, n->nd_count);
    if( n->nd_res > 0 )
	printf(" resid %d", n->nd_res );
    if( n->nd_off > 0 )
	printf(" off %d",
	       n->nd_off );
    if( n->nd_data > 0 )
	printf(" data %d",
	       n->nd_data );
    terpri();
}

process_arp() {
    arpcount++;
    printf("ARP");
    process_arp2(0);
}

# define EA_NZERO(p) ( (*(long *)p) != 0 && (*(short *)(p+4)) != 0 )

process_arp2(israrp) {
    register struct arppacket *a = &packet.p_ether.e_data.d_arp;
    register struct protocol *pp;
    int xsha, xspa, xtha, xtpa;
    ip_addr i;

    xsha = 0;				/* sender hdw addr */
    xspa = a->arp_hln;			/* sender proto addr */
    xtha = xspa + a->arp_pln;		/* target hdw addr */
    xtpa = xtha + a->arp_hln;		/* target proto addr */

    switch( a->arp_hw ) {
    case ARP_HW_ETHER:
	break;
    case ARP_HW_XETHER:
	printf(" 3Mb ether");
	break;
    case ARP_HW_AX25:
	printf(" AX.25");
	break;
    case ARP_HW_PRONET:
	printf(" PROnet");
	break;
    case ARP_HW_CHAOS:
	printf(" Chaos");
	break;
    case ARP_HW_IEEE802:
	printf(" IEEE 802");
	break;
    }

    switch( a->arp_pro ) {
    case EP_IP:
    case EP_TRAIL:
	printf(" IP");
	if( a->arp_pro == EP_TRAIL )
	    printf(" trailers");
	if( a->arp_op == ARP_REQUEST )
	    printf(" request ");
	else if( a->arp_op == RARP_REQUEST )
	    printf(" reverse request ");
	else if( a->arp_op == RARP_REPLY )
	    printf(" reverse reply ");
	else
	    printf(" op %d ", a->arp_op );

	printf("source");
	if( EA_NZERO( a->arp_data + xsha ) ) {
	    putchar(' ');
	    petaddr( a->arp_data + xsha );
	}
	i = * (ip_addr *) (a->arp_data + xspa);
	if( i != 0 ) {
	    putchar(' ');
	    pipaddr( 1, i );
	}
	terpri();

	printf("target");
	if( EA_NZERO( a->arp_data + xtha ) ) {
	    putchar(' ');
	    petaddr( a->arp_data + xtha );
	}
	i = * (ip_addr *) (a->arp_data + xtpa);
	if( i != 0 ) {
	    putchar(' ');
	    pipaddr( 1, i );
	}
	terpri();
	return;

    case EP_CHAOS:
	printf(" CHAOS ");
	if( a->arp_op == ARP_REQUEST )
	    printf(" request ");
	else if( a->arp_op == ARP_REPLY )
	    printf(" reply to ");
	else
	    printf("op %d ", a->arp_op );

	printf("source ");
	petaddr( a->arp_data + xsha );
	putchar( ' ' );
	printf("%#o ", * (u_short *) (a->arp_data + xspa) );
	terpri();

	printf("target ");
	petaddr( a->arp_data + xtha );
	putchar(' ');
	printf("%#o ", * (u_short *) (a->arp_data + xtpa) );
	terpri();

	return;

    default:
	for( pp = protocols; pp->pr_type != 0; pp++ )
	    if( a->arp_pro == pp->pr_type ) {
		printf("%s ???", pp->pr_name );
		terpri();
		return;
	    }
	printf("%02X-%02X ???", (a->arp_pro >> 8) & 255,
	       a->arp_pro & 255 );
	terpri();
    }
}

process_ieee( l )
u_short l;
{
    ieeecount++;
    printf("IEEE len %d", l );
    terpri();
}

process_pup() {
    register struct puppacket *p = &packet.p_ether.e_data.d_pup;
    pupcount++;
    printf("PUP len %d transport %d type %#o id %d",
	   p->pup_len, p->pup_transport, p->pup_type );
    terpri();
    printf("src net %#o host %#o socket %#o",
	   p->pup_src.pup_port_net,
	   p->pup_src.pup_port_host,
	   (p->pup_src.pup_port_sock1) << 16 +
	   p->pup_src.pup_port_sock2 );
    terpri();
    printf("dst net %#o host %#o socket %#o",
	   p->pup_dst.pup_port_net,
	   p->pup_dst.pup_port_host,
	   (p->pup_dst.pup_port_sock1) << 16 +
	   p->pup_dst.pup_port_sock2 );
    terpri();
}

process_rarp() {
    rarpcount++;
    printf("RARP");
    process_arp2(1);
}

# define CTP_REP 1
# define CTP_FWD 2
# define CTP_SHORT(sp) (*sp | (sp[1]<<8))

process_ctp() {
    byte *p2, *p = packet.p_ether.e_data.d_bytes;
    short f, skip;
    int len, l2;

    ctpcount++;
    skip = CTP_SHORT(p);
    p2 = p + skip + 2;			/* point to data (skip skip!) */
    len = pc - 14 - skip - 2;		/* length of data */

    printf("CTP skip %d.", skip );
    terpri();
    for( ; ; ) {
	if( len < 2 )
	    return;

	f = CTP_SHORT( p2 );		/* get function */
	p2 += 2;			/* advance past function */
	len -= 2;			/* account for function length */
	switch( f ) {
	case CTP_REP:			/* reply */
	    printf(" REPLY data: ");
	    goto break_for;
	    break;

	case CTP_FWD:			/* forward */
	    if( len < 6 ) {
		printf("Too little data for FORWARD packet");
		terpri();
		return;
	    }
	    printf(" FORWARD to: ");
	    petaddr( p2 );		/* print ether addr */
	    terpri();
	    p2 += 6;			/* advance data */
	    len -=6;			/* account for len */
	    break;

	default:
	    printf(" fncn %d. data: ", f );
	    goto break_for;
	}
    }
 break_for: ;
    l2 = len;
    if( l2 > 32 )
	l2 = 32;
    pbytes( p2, l2 );
    if( len > 32 )
	printf("...");
    terpri();
}

process_xns() {
    register struct xnspacket *x = &packet.p_ether.e_data.d_xns;
    xnscount++;
    printf("XNS IDP len %d transport %d type %d",
	   x->xns_len, x->xns_tc, x->xns_pt );
    terpri();
    printf("src: ");
    pxnsaddr( &x->xns_src );
    terpri();

    printf("dst: ");
    pxnsaddr( &x->xns_dst );
    terpri();
}

pxnsaddr( xa )
    register struct xns_addr *xa;
{
    pbytes( xa->xnsa_net, 4 );
    putchar(':');
    pbytes( xa->xnsa_host, 6 );
    printf(" port %d", xa->xnsa_port );
}

process_other( type )
int type;
{
    register struct protocol *pp;
    register int i;

    for( i = 0, pp = protocols; pp->pr_type != 0; i++, pp++ )
	if( type == pp->pr_type ) {
	    printf( "%s", pp->pr_name );
	    terpri();
	    pr_count[ i ]++;
	    pbytes( packet.p_ether.e_data.d_bytes, 32 );
	    printf("...");
	    terpri();
	    return;
	}
	else if( type < pp->pr_type )
	    break;
    pbytes( packet.p_ether.e_data.d_bytes, 32 );
    printf("...");
    terpri();
    othercount++;
}

dump_stats() {
    register struct protocol *pp;
    int i;

    if( count > 0 )
	fprintf( stderr, "count: %d\n", count );
    if( ipcount > 0 )
	fprintf( stderr, " ipcount: %d\n", ipcount );
    if( icmpcount > 0 )
	fprintf( stderr, "  icmpcount: %d\n", icmpcount );
    if( tcpcount > 0 )
	fprintf( stderr, "  tcpcount: %d\n", tcpcount );
    if( udpcount > 0 )
	fprintf( stderr, "  udpcount: %d\n", udpcount );
    if( ndcount > 0 )
	fprintf( stderr, "  ndcount: %d\n", ndcount );
    if( egpcount > 0 )
	fprintf( stderr, "  egpcount: %d\n", egpcount );
    if( ggpcount > 0 )
	fprintf( stderr, "  ggpcount: %d\n", ggpcount );
    if( ippupcount > 0 )
	fprintf( stderr, "  ippupcount: %d\n", ippupcount );
    if( ipidpcount > 0 )
	fprintf( stderr, "  ipidpcount: %d\n", ipidpcount );
    if( ipfragcount > 0 )
	fprintf( stderr, "  ipfragcount: %d\n", ipfragcount );
    if( ipothercount > 0 )
	fprintf( stderr, "  ipothercount: %d\n", ipothercount );
    if( ipbadvercount > 0 )
	fprintf( stderr, "  ipbadvercount: %d\n", ipbadvercount );
    if( arpcount > 0 )
	fprintf( stderr, " arpcount: %d\n", arpcount );
    if( rarpcount > 0 )
	fprintf( stderr, " rarpcount: %d\n", rarpcount );
    if( ieeecount > 0 )
	fprintf( stderr, " ieeecount: %d\n", ieeecount );
    if( pupcount > 0 )
	fprintf( stderr, " pupcount: %d\n", pupcount );
    if( xnscount > 0 )
	fprintf( stderr, " xnscount: %d\n", xnscount );
    if( ctpcount > 0 )
	fprintf( stderr, " ctpcount: %d\n", ctpcount );

    for( i = 0, pp = protocols; pp->pr_type != 0; i++, pp++ )
	if( pr_count[i] > 0 )
	    fprintf( stderr, " %s: %d\n", pp->pr_name, pr_count[i] );

    if( othercount > 0 )
	fprintf( stderr, " othercount: %d\n", othercount );
}

terpri() {
    register int i = indent;
    putchar( '\n' );
    while( i-- > 0 )
	putchar( ' ' );
}
