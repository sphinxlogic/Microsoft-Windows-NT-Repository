/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
# include <sys/types.h>
# include <sys/time.h>
# include <sys/socket.h>
# include <sys/ioctl.h>
# include <net/nit.h>
# include <net/if.h>
# include <stdio.h>

# define GLOBAL

# ifdef DEBUG
# define IFDEB(x) (x)
# else /* DEBUG not defined */
# define IFDEB(x)
# endif /* DEBUG not defined */

# define ALIGNSIZE sizeof( int )
# define ALIGN(a) (((a) + ALIGNSIZE - 1) & ~(ALIGNSIZE - 1))
/* NITBUFSIZ == 1K */
# define BUFSPACE (NITBUFSIZ * 256)
# define CHUNKSIZE (NITBUFSIZ * 64)
/****************************************************************/


GLOBAL int nit_errors = 1;		/* display errors */
GLOBAL int nit_exit = 1;		/* exit on errors */
GLOBAL int nit_bufspace = BUFSPACE;
GLOBAL int nit_chunksize = CHUNKSIZE;
GLOBAL int nit_snaplen = 2000;

typedef void (*FPTR)();

GLOBAL int
nit_loop( s, input_handlr )
    int s;
    FPTR input_handlr;
{
    for( ;; ) {
	static char buf[ BUFSPACE ];
	register char *pp;
	register struct nit_hdr *nh;
	char *pe;
	int cc;

	cc = read( s, buf, sizeof( buf ) );
	if( cc < sizeof( struct nit_hdr ) ) {
	    if( nit_errors )
		fprintf(stderr, "nit_loop: short read (%d)\n", cc );
	    if( nit_exit )
		exit( 1 );
	    else
		return( -1 );
	} /* short read */

	pp = buf;
	pe = pp + cc;
	while( pp < pe ) {
	    nh = (struct nit_hdr *) pp;
	    cc = process_nh( s, nh, input_handlr );
	    if( cc < 0 )
		break;
	    else
		pp += ALIGN( sizeof( struct nit_hdr ) + cc );
	} /* while */
    } /* for ever */
} /* nit_process */

static int
process_nh( s, nh, input_handlr )
    int s;
    struct nit_hdr *nh;
    FPTR input_handlr;
{
    switch( nh->nh_state ) {
    case NIT_QUIET:
	IFDEB( fprintf(stderr, "quiet\n") );
	return( 0 );

    case NIT_CATCH:
	(*input_handlr)( s, nh );
	return( nh->nh_datalen );

    case NIT_NOMBUF:
	fprintf(stderr, "out of mbufs, dropped %d packets\n",
		nh->nh_dropped );
	return( 0 );
	
    case NIT_NOCLUSTER:
	fprintf(stderr, "out of mclusters, dropped %d packets\n",
		nh->nh_dropped );
	return( 0 );
	
    case NIT_NOSPACE:
	fprintf(stderr, "bufspace exceeded, dropped %d packets\n",
		nh->nh_dropped );
	return( 0 );
	
    case NIT_SEQNO:
	IFDEB( fprintf(stderr, "seqno %d\n", nh->nh_seqno ) );
	return( 0 );

    default:
	fprintf(stderr, "bad NIT state: %d\n", nh->nh_state );
	return( -1 );
    } /* switch */
}

GLOBAL int
nit_open( ifa, type, la, pro )
    char *ifa;
    unsigned int type;
    u_char *la;
    int pro;
{
    struct sockaddr_nit snit;
    struct nit_ioc nioc;
    struct ifreq ifr;
    int s;

    if( ifa == NULL ) {
	if( nit_errors )
	    fprintf( stderr, "nit_open: must have interface pointer\n" );
	if( nit_exit )
	    exit( 1 );
	else
	    return( -1 );
    } /* no ifa */

    if( (s = socket(AF_NIT, SOCK_RAW, NITPROTO_RAW)) < 0 ) {
	if( nit_errors )
	    perror( "socket" );
	if( nit_exit )
	    exit( 1 );
	else
	    return( -1 );
    } /* socket */

    if( *ifa == '\0' ) {		/* no interface specified */
	struct ifconf ifc;
	char ifbuf[ 100 ];

	ifc.ifc_len = sizeof( ifbuf );
	ifc.ifc_buf = ifbuf;

	if( ioctl(s, SIOCGIFCONF, (char *)&ifc) < 0 ) {
	    if( nit_errors )
		perror( "ifconf ioctl");
	    close( s );
	    if( nit_exit )
		exit( 1 );
	    else
		return( -1 );
	} /* ifconf failed */
	strcpy( ifa, ifc.ifc_req->ifr_name ); /* copy back to buffer */
    } /* try to find an interface */

    snit.snit_family = AF_NIT;
    strncpy( snit.snit_ifname, ifa, sizeof(snit.snit_ifname ) );
    if( bind(s, (struct sockaddr *)&snit, sizeof( snit ) ) < 0 ) {
	if( nit_errors )
	    perror( ifa );
	close( s );
	if( nit_exit )
	    exit( 1 );
	else
	    return( -1 );
    } /* bind failed */

    bzero(&nioc, sizeof(nioc));
    nioc.nioc_bufspace = nit_bufspace;
    nioc.nioc_chunksize = nit_chunksize;
    nioc.nioc_typetomatch = type;
    nioc.nioc_snaplen = nit_snaplen;
    nioc.nioc_bufalign = ALIGNSIZE;
    nioc.nioc_bufoffset = 0;
    nioc.nioc_flags = (pro ? NF_PROMISC : 0 ) | NF_TIMEOUT;   
    nioc.nioc_timeout.tv_sec = 1;
    nioc.nioc_timeout.tv_usec = 0;
    if (ioctl(s, SIOCSNIT, &nioc) != 0) {
	if( nit_errors )
	    perror("nit ioctl");
	close( s );
	if( nit_exit )
	    exit(1);
	else
	    return( -1 );
    } /* nit ioctl */

    strncpy(ifr.ifr_name, ifa, sizeof ifr.ifr_name);
    if( ioctl(s, SIOCGIFADDR, (caddr_t) &ifr) < 0 ) {
	if( nit_errors )
	    fprintf(stderr, "cannot find ether address for %s\n", ifa );
	close( s );
	if( nit_exit )
	    exit( 1 );
	else
	    return( -1 );
    } /* interface address ioctl */
    bcopy( ifr.ifr_addr.sa_data, la, 6 );
    return( s );
} /* nit_open */

GLOBAL int
nit_output(fd, buf, len)
    int fd, len;
    char *buf;
{
    struct sockaddr sa;
    int offset = sizeof(sa.sa_data);
    int result;

    sa.sa_family = AF_UNSPEC;
    bcopy(buf, sa.sa_data, offset);
    result = sendto(fd, buf+offset, len-offset, 0, &sa, sizeof(sa));
    if( result < 0 )
	return( result );
    return( result+offset );
} /* nit_output */
