/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
# include "mfgr.h"

MFGR mfgrs[] = {
    0x00000c,	"W.D.",			/* Western Digital */
    0x00002a,	"TRW",
    0x00005a,	"S&Koch",
    0x000093,	"Proteon",
    0x000093,	"Ameristar",		/* Ameristar Tech. */
    0x0000aa,	"Xerox",
    0x0000c0,	"W.D.",			/* ? */
    0x0000dd,	"Gould",
    0x000102,	"BBN",			/* unofficial */
    0x001700,	"Kabel",
    0x00dd00,	"U-B",			/* seen in PC/RT */
    0x00dd01,	"U-B",			/* seen in IBM 8232 (2273A board) */
    0x020701,	"Interlan",		/* (UNIBUS/QBUS), Apollo */
    0x020406,	"BBN",			/* unofficial */
    0x02608c,	"3Com",			/* (PC/Imagen/Valid) */
    0x02cf1f,	"CMC",			/* (Masscomp/SGI) */
    0x080002,	"Bridge",
    0x080005,	"Symbolics",
    0x080008,	"BBN",
    0x080009,	"H-P",
    0x080010,	"AT+T",			/* ?? */
    0x080014,	"Excelan",		/* (BBN Butterfly/Masscomp/Iris) */
    0x08001a,	"DG",
    0x08001b,	"DG",
    0x08001e,	"Apollo",
    0x080020,	"Sun",
    0x080028,	"TI",			/* TI Explorer */
    0x08002b,	"DEC",			/* UNIBUS/QBUS/VAX/LANBridge */
					/* DEUNA, DEQNA, DELUA */

    0x080045,	"???",
    0x080047,	"Sequent",
    0x080049,	"Univation",
    0x08004c,	"Encore",
    0x08004e,	"BICC",
    0x080068,	"Ridge",
    0x080069,	"SGI",			/* Silicon Graphics */
    0x08006e,	"Excelan",
    0x08007c,	"Vitalink",		/* TransLAN III */
    0x080089,	"Kinetics",
    0x08008b,	"Pyramid",
    0x08008d,	"XyVision",
    0x090090,	"H-P",			/* MULTICAST */
    0x09002b,	"LanBridge",		/* MULTICAST */
    /* 01-00-00 LanBridge Copy */
    /* 01-00-01 LanBridge Hello (1/sec)*/

    0x800010,	"AT+T",			/* 3b2 3Bnet card */
    0xaa0003,	"DEC",			/* DEUNA/KLNI */
    0xaa0004,	"DECNET",		/* logical address */

    0xab0000,  	"DEC multcast",		/* MULTICAST */
    /*
     * lower part
     * 01-00-00 DL-MOP 			Dump/Load assist
     * 02-00-00 RE-MOP 			Remote console sys id (1 every 8-10min)
     *					from LanBridge, DEUNA, DELUA, DEQNA*
     * 03-00-00	DECnet phase IV		end node hello (1 every 15 sec)
     * 04-00-00	DECnet phase IV		router hello (1 every 15 sec)
     * 
     */

    0xab0001,  	"DEC ??",		/* reserved MULTICAST */
    0xab0002,  	"DEC ??",		/* reserved MULTICAST */

    0xab0003,	"LAT",			/* MULTICAST */
    /* low octets? */

    0xab0004,  	"DEC",			/* reserved MULTICAST */
    /*
     * 00-00-00 thru
     * ff-ff-ff reserved for customer??
     * 01-xx-yy LAVC Cluster group yy??
     */
    0xc00000,	"Western Digital?",	/* ?? */
    0xcf0000,	"CTP",			/* MULTICAST */
    0,		""
};

int nmfgrs = ( sizeof( mfgrs ) / sizeof( MFGR ) ) - 1;
