/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
# include <sys/types.h>			/* for socket.h */
# include <sys/socket.h>		/* sockaddr */
# include <net/if.h>			/* arpreq */
# include <sys/ioctl.h>
# include <sys/errno.h>
# include <netinet/in.h>		/* sockaddr_in */
extern int errno;

iptoea( ip, ea )
    long *ip;
    char *ea;
{
    struct sockaddr_in *sin;
    struct arpreq arp;
    int s, i;

    if( (s = socket( AF_INET, SOCK_DGRAM, 0 )) < 0 )
	return( 0 );

    arp.arp_ha.sa_family = AF_UNSPEC;
    arp.arp_pa.sa_family = AF_INET;
    sin = (struct sockaddr_in *) &arp.arp_pa;
    bcopy( ip, &sin->sin_addr, sizeof( *ip ) );

    /* force arp */
    sin->sin_port = 1;			/* seems unlikely */
    if( sendto( s, &s, 0, 0, sin, sizeof( struct sockaddr_in ) ) < 0 )
	perror( "sendto" );		/* ??ignore */

    for( i = 0; i < 10; i++ ) {
	if( ioctl( s, SIOCGARP, &arp ) < 0 ) {
	    if( errno != ENXIO ) {	/* not does not exist? */
		perror( "ioctl" );	/* whine */
		break;			/* leave while */
	    }
	    i++;			/* penalize for no entry yet */
					/* (wait longer if incomplete found) */
	}
	else if( arp.arp_flags & ATF_COM ) { /* complete? */
	    bcopy( arp.arp_ha.sa_data, ea, 6 );
	    close( s );
	    return( 1 );
	} /* complete */
	usleep( 100000 );		/* .1 sec */
    } /* for */

    close( s );
    return( 0 );
}
