/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
# include <ctype.h>

xval( c1, c2 )
char c1, c2;
{
    int i;
    i = (xnybble( c1 ) << 4) + xnybble( c2 );
    return( i );
}

xnybble( c )
char c;
{
    if( isdigit( c ) )
	return( c - '0' );
    else if( isupper( c ) )
	return( c - 'A' + 10 );
    else
	return( c - 'a' + 10 );
}

