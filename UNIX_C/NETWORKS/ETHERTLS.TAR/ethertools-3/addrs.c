/*
 * Copyright (c) 1988 Philip L. Budne and The Trustees of Boston University
 * All Rights Reserved
 *
 * Permission is granted to any individual or institution to use, copy,
 * or redistribute this software so long as it is not sold for profit,
 * provided that this notice and the original copyright notices are
 * retained.  Boston University makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */
# include <stdio.h>
# include <ctype.h>
# include "packet.h"

struct hent {
    union {
	EA hd_ea;
	short hd_type;
    } h_data;
    int h_cnt;
    int h_inuse;
};
# define h_ea h_data.hd_ea
# define h_type h_data.hd_type

int length[ 1520 ];

int count = 0;
int pc;
int sflg, dflg, pflg;

main(argc, argv)
    int argc;
    char *argv[];
{
    extern char *optarg;
    extern int optind, opterr;
    int errs, c;
    char line[ 4096 ];
    register byte *pp;
    register char *lp;
    register int i;

    errs = 0;
    sflg = dflg = pflg = 0;
    while( (c = getopt( argc, argv, "sdp" )) != EOF ) {
	switch( c ) {
	case 's':
	    sflg++;
	    break;
	case 'd':
	    dflg++;
	    break;
	case 'p':
	    pflg++;
	    break;
	default:
	    errs++;
	}
    }
    if( errs > 0 )
	exit( 1 );

    if( sflg + dflg + pflg == 0 )
	sflg = dflg = pflg = 1;

    pc = 0;
    pp = packet.p_bytes;
    while( gets( line ) ) {
	if( line[0] == ' ' || line[0] == '*' || line[0] == '\0' ) {
	    if( pc > 0 )
		process();
	    pp = packet.p_bytes;
	    pc = 0;
	    continue;
	}

	for( lp = line; *lp; lp++ ) {
	    if( isspace( *lp ) )
		continue;
	    else if( isxdigit( *lp ) && isxdigit( lp[1] ) ) {
		*pp++ = xval( *lp, lp[1] );
		lp++;
		pc++;
	    }
	    else
		fprintf( stderr, "you lose: %s\n", lp );
	}
    }
    if( pc > 0 )
	process();
}

process() {
    register struct etherpacket *e = (struct etherpacket *) &packet;
    u_short type;

    count++;
    type = packet.p_ether.e_type;
    if( sflg ) {
	petaddr( e->e_src );
	putchar(' ');
    }
    if( dflg ) {
	petaddr( e->e_dst );
	putchar(' ');
    }
    if( pflg ) {
	puthex( (type >> 8) & 0xff );
	putchar( '-' );
	puthex( type & 255 );
    }
    /* pc == len */
}
