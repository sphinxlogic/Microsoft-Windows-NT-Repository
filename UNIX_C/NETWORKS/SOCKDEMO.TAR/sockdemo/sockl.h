/* sockl.h */

#ifndef SOCKL_H
#define SOCKL_H

#define SOCKET_PATH_NAME "sweet_babboo"
#define SOCKET_QUEUE_LENGTH SOMAXCONN

#endif
