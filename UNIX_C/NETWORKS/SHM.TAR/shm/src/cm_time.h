extern struct timeval cm_period_zero, cm_period_infinite;

#define time_now(x) gettimeofday(x,(struct timezone *)0)
