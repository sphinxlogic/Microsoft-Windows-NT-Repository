/* client8.c - constantly write a variable to common memory (see server8.c) */

#include <sys/time.h>
#include "cm.h"

cm_variable *variable;
cm_value value = { "foo", 4, 4, 0};

main()
{
	if (0>cm_init("constant writer",0,0)) exit(-1);

	if (!(variable = cm_declare("variable",CM_ROLE_XWRITER))) exit(-1);

	while (1) {
		cm_set_value(variable,&value);
		cm_sync(CM_NO_WAIT);
	}
}
