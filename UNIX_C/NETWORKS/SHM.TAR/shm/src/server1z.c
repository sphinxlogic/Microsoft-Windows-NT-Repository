/* server1.c
This process, s, prints the latest values of variables a_var and b_var
*/
#include <sys/time.h>
#include "cm.h"

cm_value a_val = {0,0,0,1}, b_val = {0,0,0,1};

main()
{
	cm_variable *a_var, *b_var;

	if (0>cm_init("s",0,0)) exit(-1);

	if (!(a_var = cm_declare("a_var",CM_ROLE_READER|CM_ROLE_WAKEUP)))
			exit(-1);
	if (!(b_var = cm_declare("b_var",CM_ROLE_READER|CM_ROLE_WAKEUP)))
			exit(-1);

	for (;;) {
		cm_sync(CM_WAIT_AT_MOST_ONCE);
		if (cm_get_new_value(a_var,&a_val))
			printf("a_var: %s\n",a_val.data);
		if (cm_get_new_value(b_var,&b_val))
			printf("b_var: %s\n",b_val.data);
	}
}
