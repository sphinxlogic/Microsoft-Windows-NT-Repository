/*					-[Mon Dec  3 16:37:08 1984 by layer]-
 * 	dfuncs.h			$Locker:  $
 * external function declaration
 *
 * $Header: dfuncs.h,v 40.6 85/03/12 12:54:37 layer Exp $
 *
 * (c) copyright 1982, Regents of the University of California
 * Enhancements (c) copyright 1984, Franz Inc., Oakland California
 */
 
char *brk();
char *pinewstr();
char *inewstr();
char *newstr();
char *sbrk();
char *xsbrk();
char *ysbrk();
int csizeof();
lispval Iget();
lispval Imakeht();
lispval Imkrtab();
lispval Iputprop();
lispval Istsrch();
lispval Lfuncal();
lispval Lnegp();
lispval Lread();
lispval Lsub();
lispval copval();
lispval csegment();
lispval error();
lispval errorh();
lispval errorh1();
lispval errorh2();
lispval eval();
lispval gc();
lispval getatom();
lispval inewatom();
lispval inewint();
lispval inewval();
lispval matom();
lispval mfun();
lispval mstr();
lispval newarray();
lispval newdot();
lispval newdoub();
lispval newfunct();
lispval newint();
lispval newsdot();
lispval newval();
lispval newhunk();
lispval pnewdot();
lispval pnewdb();
lispval pnewhunk();
lispval pnewint();
lispval pnewsdot();
lispval pnewval();
lispval popnames();
lispval r();
lispval ratomr();
lispval readr();
lispval readrx();
lispval readry();
lispval typefrob();
lispval typred();
lispval unprot();
lispval verify();
struct atom	*makeatom();
struct atom	*newatom();
