/*					-[Wed May 15 10:14:01 1985 by layer]-
 * 	ltypes.h			$Locker:  $
 * lisp data type defs
 *
 * $Header: ltypes.h,v 40.6 85/05/16 03:58:00 smh Exp $
 *
 * (c) copyright 1982, Regents of the University of California
 * Enhancements (c) copyright 1984, Franz Inc., Oakland California
 */
 
/* type flags */

#define	UNBO	-1
#define	STRNG	0
#define	ATOM	1
#define	INT	2
#define	DTPR	3
#define DOUB	4
#define	BCD	5
#define	PORT	6
#define	ARRAY	7
#define OTHER   8
#define SDOT	9
#define VALUE	10

#define HUNK2	11		/* The hunks */
#define HUNK4	12
#define HUNK8	13
#define HUNK16	14
#define HUNK32	15
#define HUNK64	16
#define HUNK128	17

#define VECTOR  18
#define VECTORI 19

#define NUMSPACES (VECTORI + 1)

#define	HUNKP(a1)	((TYPE(a1) >= HUNK2) & (TYPE(a1) <= HUNK128))

#define HASHTP(p)	((p)->v.vector[VPropOff] == hasht_atom)
#define PACKAGEP(p)	((p)->v.vector[VPropOff] == pkg_atom)
#define INSTANCEP(p)	((TYPE((p)->v.vector[VPropOff]) == VECTOR) && \
			 ((p)->v.vector[VPropOff]->v.vector[VPROPOFF] == \
			  flavor))

