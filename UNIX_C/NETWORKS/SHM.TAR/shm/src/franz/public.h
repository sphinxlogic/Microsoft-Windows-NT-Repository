/*					-[Tue May 21 17:05:40 1985 by layer]-
 * 	public.h			$Locker:  $
 *
 *   definition for Public data objects which all files are permitted
 *   to look at. [These are the very public data objects]
 *
 * $Header: public.h,v 40.5 85/05/21 17:24:04 layer Exp $
 *
 * 
 * (c) copyright 1984, Franz Inc., Oakland California
 */

#ifdef apollo
extern
#else
Public
#endif
struct nament *bnp;	/* first free bindstack entry */
Public struct nament *bnplim,	/* limit of bindstack */
		     *orgbnp;	/* base of the bindstack */


#ifdef NPINREG
Import
#else
#ifdef apollo
extern
#else
Public
#endif apollo
#endif NPINREG
	struct	 argent *lbot,	/* base of arguments to function */
		         *np;	/* first free namestack entry */
			 
Public struct argent *nplim,	/* one above limit of namestack */
		     *orgnp;	/* first slot in the namestack */
		     
#ifdef apollo
extern
#else
Public
#endif apollo
    word retval;		/* used by each error/prog call	 */
				/* retval could be an int */
#ifdef apollo
extern
#else
Public
#endif apollo
lispval  lispretval;	/* used by non-local go  */

Public lispval datalim;		/* limit of valid data area */

Public lispval vtemp;		/* used in a few macros as a temp */
Public long sigintcnt;		/* count of interrupts since processed */
				/* sigintcnt could be an int */

Import char typetable[];		/* one byte per page */

#ifdef MVR
/* Stuff having to do with Multiple Values */
#ifdef apollo
extern
#else
Public
#endif apollo
int nmvr;	    /* # of multiple values being returned less 1 */
Import int mmvr;	    /* Max # of multiple values possibly returned*/
#ifdef apollo
extern
#else
Public
#endif apollo
lispval *mvals;	    /* pointer to a static storage area for them */
Public lispval *mvalsMMVR;  /* pointer to end of storage area for them */
#define clrnmv() (nmvr = 0);
#endif MVR

#ifdef Savelisp
Public lispval relvectors;  /* for save/restorelisp */
#endif Savelisp
