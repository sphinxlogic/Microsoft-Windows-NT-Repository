/* cm_sd.h - sized-data structures */

/* there is no reason why the items typed as shorts cannot be longer */

typedef struct cm_value {
	char *data;
	unsigned short msize;	/* max size of data */
	unsigned short size;	/* size of data used */
	char mallocable;	/* TRUE, if we can free and malloc data */
} cm_value;

struct cm_flattened_data {
	unsigned short size;
	char data[1];
};
