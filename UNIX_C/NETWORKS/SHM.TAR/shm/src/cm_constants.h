#define CM_PORT			1525

/* maximums */
#define CM_MSGSIZE		100000/* max length of all variables
					sent to	server at one time */
#define CM_SLOTSIZE		20000 /* max single variable length */
#define CM_PROCESSNAMELENGTH	20
#define CM_VARIABLENAMELENGTH	20
#define CM_MAXVARIABLENAMELENGTH	20
#define CM_MAXPROCESSNAMELENGTH	20
#define CM_MAXUSERVARIABLES	100

#define E_CMM_DIED		-1
#define E_CM_INIT_FAILED		-2
#define E_CM_WRONG_VERSION		-100
