/* server8b.c - receive updates from common memory but do not read() */
/* see if cmm eventually hangs on write() */

#include <sys/time.h>
#include "cm.h"

cm_variable *variable;

main()
{
	if (0>cm_init("constant reader hang",0,0)) exit(-1);

	if (!(variable = cm_declare("variable",CM_ROLE_READER|CM_ROLE_WAKEUP))) exit(-1);

	cm_sync(CM_NO_WAIT);
	sigpause();
}
