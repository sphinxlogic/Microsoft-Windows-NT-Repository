/* cm_bytestuff.h - byte stuffing aids */

/* #byteadd is used to add offsets to structures */
/*#define byteadd(a,b)	(((int)a) + ((int)b) + (((int)a) + (int)b) % 2)*/
#define byteadd(a,b)	(align(((int)(a)) + ((int)(b))))

/* align converts rounds up addresses if they are odd */
/* if this is not done, longword stores fail on the 68000 */
#define align(x)	((x) + (x)%2)
