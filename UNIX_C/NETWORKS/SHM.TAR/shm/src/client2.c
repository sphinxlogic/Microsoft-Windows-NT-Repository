/* client2.c
 this client writes the following to common memory:
s_var: a line read from stdin
i_var: the length of s_var
d_var: a random double variable
*/
#include <sys/time.h>
#include "cm.h"

cm_variable *i_var, *d_var, *s_var;
cm_value i_val, d_val, s_val;
double d_val_data = 3.14159;

char s_val_data[1000];
int i_val_data;

main(argc,argv)
int argc;
char **argv;
{
	if (argc>1) printf("going to host %s for cmm\n",argv[1]);
	if (0 > cm_init("don",(argc>1?argv[1]:(char *)0),0)) exit(-1);

	s_var = cm_declare("s_var",CM_ROLE_NONXWRITER);
	i_var = cm_declare("i_var",CM_ROLE_NONXWRITER);
	d_var = cm_declare("d_var",CM_ROLE_NONXWRITER);

	d_val.data = (char *)&d_val_data;
	d_val.size = sizeof(d_val_data);
	s_val.data = s_val_data;
	i_val.data = (char *)&i_val_data;

	while (TRUE) {
		cm_set_value(d_var,&d_val);

		printf("enter string for s_val: ");
		gets(s_val_data);
		s_val.size = strlen(s_val_data);
		cm_set_value(s_var,s_val);

		i_val_data = strlen(s_val_data);
		cm_set_value(i_var,&i_val);

		if (0 > cm_sync(CM_NO_WAIT)) return;
	}
}
