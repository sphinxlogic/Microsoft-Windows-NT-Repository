/* server8a.c - constant wait on common memory to test that cmm doesn't */
/* blow up when we die and it is writing to us (SIGPIPE) */

#include <sys/time.h>
#include "cm.h"

cm_variable *variable;

main()
{
	if (0>cm_init("constant reader SIGPIPE",0,0)) exit(-1);

	if (!(variable = cm_declare("variable",CM_ROLE_READER|CM_ROLE_WAKEUP))) exit(-1);

	while (1) {
		cm_sync(CM_WAIT);
	}
}
