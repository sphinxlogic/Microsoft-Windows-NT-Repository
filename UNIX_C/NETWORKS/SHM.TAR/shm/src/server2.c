/* all this server does is print out whatever its given */

/* Note, this has not been converted over to use cmm v7!!! */

#include <sys/time.h>
#include "cm.h"

main(argc,argv)
int argc;
char **argv;
{
	cm_variable *i_var, *d_var, *s_var;
	char s_val[1000];
	int i_val;
	double d_val;

	if (argc>1) printf("going to host %s for cmm\n",argv[1]);
	if (0 > cm_init("printer",(argc>1?argv[1]:(char *)0),0)) exit(-1);

	i_var = cm_declare("i_var",CM_ROLE_READER | CM_ROLE_WAKEUP);
	d_var = cm_declare("d_var",CM_ROLE_READER);
	s_var = cm_declare("s_var",CM_ROLE_READER);

	while (TRUE) {
		if (0 > cm_sync(CM_WAIT_AT_MOST_ONCE)) return;
		cm_get_value(i_var,&i_val);
		printf("i_var = %d\n",i_val);
		cm_get_value(d_var,&d_val);
		printf("d_var = %g\n",d_val);
		cm_get_value(s_var,s_val);
		printf("s_var = %s\n",s_val);
	}
}
