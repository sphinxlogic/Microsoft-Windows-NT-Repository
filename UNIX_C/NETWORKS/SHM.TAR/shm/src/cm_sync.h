/* cm_sync.h */

/* OR together one from first set to one from second set */
/* defaults are CM_WAIT|CM_WAIT_FOR_ALL */

/* first set of options */
#define CM_WAIT			0
#define CM_NO_WAIT		1
/* second set of options */
#define CM_WAIT_FOR_ALL		0
#define CM_WAIT_AT_MOST_ONCE	2
/* third set of options */
#define CM_WAIT_READ		4
