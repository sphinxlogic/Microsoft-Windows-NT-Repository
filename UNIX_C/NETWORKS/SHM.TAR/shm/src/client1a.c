/* client1a.c
This process, a, writes a string to variable a_var.
It then checks variable b_var for a new value, and if it is, prints it.
It then sleeps for 3 seconds.
*/
#include "cm.h"

#define BUFFER_LENGTH	1000
char a_data[BUFFER_LENGTH];

cm_value a_val = {a_data,BUFFER_LENGTH,0,0}, b_val = {0,0,0,1};

main()
{
	cm_variable *a_var, *b_var;
	int seqno = 0;

	if (0> cm_init("a",0,0)) exit(-1);

	if (!(a_var = cm_declare("a_var",CM_ROLE_NONXWRITER)))
		exit(-1);
	if (!(b_var = cm_declare("b_var",CM_ROLE_READER|CM_ROLE_WAKEUP)))
		exit(-1);

	for (;;) {
		sprintf(a_data,"Message from a.  seq #%d",seqno++);
		a_val.size = strlen(a_data) + 1;
		cm_set_value(a_var,&a_val);
		cm_sync(CM_NO_WAIT);
		if (cm_get_new_value(b_var,&b_val))
			printf("b_var: %s\n",b_val.data);
		sleep(3);
	}
}
