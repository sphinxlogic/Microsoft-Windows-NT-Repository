/* set_cm_process_name.c */

#include <stdio.h>
#include "cm_constants.h"

char cm_process_name[CM_PROCESSNAMELENGTH];

set_cm_process_name(name)
char *name;
{
	strncpy(cm_process_name,name,CM_PROCESSNAMELENGTH);
}

