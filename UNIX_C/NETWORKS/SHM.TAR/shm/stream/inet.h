#define TRUE		1
#define FALSE		0

#define PORT_TYPE_NAME		1
#define PORT_TYPE_NUMBER	2

#define PORT_NAME(name)		PORT_TYPE_NAME,name,(u_short)0
#define PORT_NUMBER(number)	PORT_TYPE_NUMBER,0,(u_short)number

/* sockettypes are SOCKET_STREAM and SOCKET_DGRAM */

#define DATAGRAM_FLAGS	0		/* for recv and sendto */

#define SERVER		1
#define CLIENT		2
#define server		(role == SERVER)
#define client		(role == CLIENT)
