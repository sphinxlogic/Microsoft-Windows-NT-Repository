#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
/* #include <netdb.h> */
#include "inet.h"

char msg[2000];

struct timeval timeout = {0L, 0L};
int maxfds;

main(argc,argv)
int argc;
char **argv;
{
	int cc;
	int i;
	int fd;
	int readfds;

	maxfds = getdtablesize();
	fd = initport(PORT_NUMBER(2000),CLIENT,SOCK_STREAM,argc>1?argv[1]:"");

	if (fd < 0) {
		fprintf(stderr,"initport() = %d\n",fd);
		exit(-1);
	}
	for (i=0;;i++) {
		printf("%d: ",i);
		gets(msg);
		cc = sized_write(fd,msg,strlen(msg)+1);
		readfds = 1<<fd;
		if (0 < select(maxfds,&readfds,0,0,&timeout)
		   && readfds == 1<<fd) {
			cc = sized_read(fd,msg,2000);
			msg[cc] = '\0';
			printf("msg from server: %s\n",msg);
		}
	}
}
