#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "inet.h"

char buf[2000];

main(argc,argv)
int argc;
char **argv;
{
	int writer;
	int cc;
	int fd;
	int fds = 0;

	/* if an arg is provided, use that as the hostname to look for the */
	/* service */
	fd = initport(PORT_NUMBER(2000),SERVER,SOCK_STREAM,(char *)0);
	if (fd < 0) {
		fprintf(stderr,"initport() = %d\n",fd);
		exit(-1);
	}

        while (TRUE) {
		writer = select_server_stream(fd,&fds);
		cc = sized_read(writer,buf,2000);
		if (cc <= 0) {
			printf("%d: EOF\n",writer);
			close(writer);
			continue;
		}
		printf("%d: %s\n",writer,buf);
		if (cc == 1) cc = sized_write(writer,"1 char",6);
	}
}
