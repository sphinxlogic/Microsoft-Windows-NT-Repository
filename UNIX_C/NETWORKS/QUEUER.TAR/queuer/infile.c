/* Copyright 1990  The President and Fellows of Harvard University

Permission to use, copy, modify, and distribute this program for any
purpose and without fee is hereby granted, provided that this
copyright and permission notice appear on all copies and supporting
documentation, the name of Harvard University not be used in advertising
or publicity pertaining to distribution of the program, or to results
derived from its use, without specific prior written permission, and notice
be given in supporting documentation that copying and distribution is by
permission of Harvard University.  Harvard University makes no
representations about the suitability of this software for any purpose.
It is provided "as is" without express or implied warranty.	*/


/* infile.c - Dan Lanciani '85 */

#include <stdio.h>

infile(file, name)
register char *file, *name;
{
	char buf[BUFSIZ];
	register FILE *n;

	if(!(n = fopen(file, "r")))
		return(0);
	while(fgets(buf, sizeof(buf), n)) {
		buf[strlen(buf)-1] = '\0';
		if(!strcmp(buf, name)) {
			fclose(n);
			return(1);
		}
	}
	fclose(n);
	return(0);
}
