/* A very poor "strings" clone; just what you need for RNA 2.0 ;-)
 * I could do it in bourne shell as well, but -com'on- that would
 * really mean wasting time!
 * I still wonder why my 3b2-600 with UNIX V 3.2. has no "strings".
 * Who cares after all...
 * Use this 'strings' for 'MAKE_RNA' and inside RNA. The only
 * common thing between original 'strings' and this one is the name.
 * This is used twice in the whole package: once inside RNA, with 
 * a single argument (filename), to grep out empty lines.
 * Once also inside MAKE_RNA, with a necessary option '-1' to force it
 * keeping lines with a single valid character (for instance a bracket).
 * No need to do more.
 */

#include <stdio.h>

main(argc,argv) 
int argc;
char *argv[];
{
FILE *fp, *fopen();
int car;


if ((strcmp(argv[1],"-1")) == 0) 
	fp=fopen(argv[2],"r"); 
else 
	fp=fopen(argv[1],"r");

while (( car=getc(fp)) != EOF) 
        if (car >32) {
                putc(car,stdout);
                while (( car=getc(fp)) != 10) putc(car,stdout);
		putc(10,stdout);
        }
fclose(fp);
}
