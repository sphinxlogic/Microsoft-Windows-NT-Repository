/* $Id: dliwrite.c,v 2.1 89/10/23 15:42:09 dupuy Exp $ */

#include <sys/param.h>			/* NOFILE */
#include <sys/socket.h>			/* sockaddr_dl (sockaddr) */

#include <net/if.h>			/* ifdevea */
#include <netinet/in.h>			/* (ether_header) (in_addr) */
#include <netinet/if_ether.h>		/* sockaddr_dl (ether_header) */
#include <netdnet/dli_var.h>		/* sockaddr_dl */

#include <errno.h>			/* EWOULDBLOCK */

#include "libether.h"

extern struct sockaddr_dl _ether_sockaddrs[NOFILE];

#define sad (_ether_sockaddrs[fd])

/*
 * Writes a single packet, filling src and type fields.
 */

int
ether_write (fd, packet)
int fd;
ether_packet *packet;
{
    int result;

    bcopy ((char *) &packet->dest,
	   (char *) sad.choose_addr.dli_eaddr.dli_target, DLI_EADDRSIZE);

    result = sendto (fd, packet->pktbuf, (int) packet->pktlen, 0,
		     (struct sockaddr *) &sad, sizeof (struct sockaddr_dl));

    if (result < 0 && errno == EWOULDBLOCK)
	errno = EAGAIN;

    return (result);
}
