/* $Id: etheraddr.c,v 2.1 89/10/23 15:44:44 dupuy Exp $ */

/*
 * Static initialization of ethernet broadcast address.	 We do it in a separate
 * file so that it can be compiled with -R (read-only), but more importatntly,
 * so that we can get around the restriction on initializing unions if needed.
 */

#ifdef __STDC__

#include "ether.h"

ether_addr ether_bcast_addr = {{ 0xff, 0xff, 0xff, 0xff, 0xff, 0xff }};

#else

#ifdef lint

#include "ether.h"

ether_addr ether_bcast_addr;		/* a little white lie */

#else

#define __ETHER_BCAST_ADDR__		/* avoid conflict with ether.h */

#include "ether.h"

struct ether_addr
{
    unsigned short shorts[3];		/* must have short alignment */
}
ether_bcast_addr =  {{ 0xffff, 0xffff, 0xffff }};

#endif

#endif
