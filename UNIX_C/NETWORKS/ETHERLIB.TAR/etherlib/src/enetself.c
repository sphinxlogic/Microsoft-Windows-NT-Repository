/* $Id: enetself.c,v 2.0 89/10/20 19:02:05 dupuy Exp $ */

/*
 * Most, but not all, VAX interfaces, loopback packets.	 The enetfilter
 * drivers for the ec (3com) interface loops back packets in software, except
 * for multicast packets.  Since the enetfilter currently has no way to
 * receive multicast packets, that makes little difference.
 */

/* ARGSUSED */

int
ether_send_self (fd)
int fd;
{
    return (1);
}

/* ARGSUSED */

int
ether_mcast_self (fd)
int fd;
{
    return (0);				/* can't receive multicast packets */
}

/* ARGSUSED */

int
ether_bcast_self (fd)
int fd;
{
    return (1);
}
