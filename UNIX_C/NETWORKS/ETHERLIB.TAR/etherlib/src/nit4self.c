/* $Id: nit4self.c,v 2.0 89/10/20 19:02:46 dupuy Exp $ */

#include <sys/sockio.h>			/* SIOCGETFDSTAT */

/*
 * No standard sun ethernet interface loops back packets.  Early versions of
 * the streams-based Sun NIT interface don't loopback broadcast packets, but
 * 4.0.3 and later appear to (although 4.0.3 has bugs).	 Since a 4.0 compiled
 * binary will run on a 4.0.3 system, we can't determine the answer correctly
 * at compile time.  Since there doesn't seem to be any kernel feature present
 * in 4.0.3 and absent in earlier versions that we can test for, we use a
 * compile-time check.	It's the best we can do for now.
 */

/* ARGSUSED */

int
ether_send_self (fd)
int fd;
{
    return (0);
}

/* ARGSUSED */

int
ether_mcast_self (fd)
int fd;
{
    return (0);
}

/* ARGSUSED */

int
ether_bcast_self (fd)
int fd;
{
#ifdef SIOCGETFDSTAT
    return (1);
#else
    return (0);
#endif
}
