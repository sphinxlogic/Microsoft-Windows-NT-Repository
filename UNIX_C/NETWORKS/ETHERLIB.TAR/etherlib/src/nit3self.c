/* $Id: nit3self.c,v 2.0 89/10/20 19:02:40 dupuy Exp $ */

/*
 * No standard sun ethernet interface loops back packets. The socket-based Sun
 * NIT interface doesn't do it either.
 */

/* ARGSUSED */

int
ether_send_self (fd)
int fd;
{
    return (0);
}

/* ARGSUSED */

int
ether_mcast_self (fd)
int fd;
{
    return (0);
}

/* ARGSUSED */

int
ether_bcast_self (fd)
int fd;
{
    return (0);
}
