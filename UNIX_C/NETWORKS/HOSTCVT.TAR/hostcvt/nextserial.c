#include <stdio.h>

#ifndef lint
static char *RCSid = "$Id: nextserial.c,v 1.1 90/10/03 22:56:42 rogers Release $";
#endif

#define PAT	"Serial"

extern int errno;
extern char *sys_errlist[];
#define ERR	sys_errlist[errno]

main(argc, argv)
int argc;
char *argv[];
{
    FILE *fopen();
    char *re_comp(), *fgets(), *index(), *mktemp();
    register char *cp;
    register FILE *infp, *outfp;
    register char *tmpname;
    char buf[BUFSIZ];
    int serial;

    (void)umask(022);

    if(argc != 2){
	(void)fprintf(stderr, "usage: nextserial soafile\n");
	exit(1);
    }

    if((cp = re_comp(PAT)) != NULL){
	(void)fprintf(stderr, "nextserial: %s\n", cp);
	exit(1);
    }

    tmpname = mktemp(".nxtXXXXXX");
    (void)unlink(tmpname);

    if(rename(argv[1], tmpname) == -1){
	(void)fprintf(stderr, "nextserial: could not rename(%s, %s) - %s (%d)\n", argv[1], tmpname, ERR);
	exit(1);
    }

    if((infp = fopen(tmpname, "r")) == NULL){
	(void)fprintf(stderr, "nextserial: could not open %s for read\n", tmpname);

	if(rename(tmpname, argv[1]) == -1)
	    (void)fprintf(stderr, "EKK! could not put %s back to %s!\n", tmpname, argv[1]);
	exit(1);
    }

    if((outfp = fopen(argv[1], "w")) == NULL){
	(void)fprintf(stderr, "nextserial: could not open %s for write\n", argv[1]);

	if(rename(tmpname, argv[1]) == -1)
	    (void)fprintf(stderr, "EKK! could not put %s back to %s!\n", tmpname, argv[1]);
	exit(1);
    }

    while(fgets(buf, BUFSIZ, infp) != NULL){
	switch(re_exec(buf)){
	    case 0:
		(void)fputs(buf, outfp);
		break;
	    
	    case -1:
	    default:
		(void)fprintf(stderr, "nextserial: regex internal error\n");
		exit(1);
	    
	    case 1:
		if((cp = index(buf, '\n')) != NULL)
		    *cp = '\0';

		if(sscanf(buf, "%d", &serial) != 1){
		    (void)fprintf(stderr, "nextserial: could not decode [%s]\n", buf);
		    exit(1);
		}

		(void)fprintf(outfp, "\t\t\t\t%d\t; %s\n", ++serial, PAT);
		break;
	}
    }
    (void)fclose(outfp);
    (void)fclose(infp);
    (void)unlink(tmpname);
    exit(0);
}
