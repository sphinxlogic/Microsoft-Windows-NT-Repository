/*	@(#)vers.c 1.1 90/03/23 SMI	*/
char version[] = "SunOS 4.1";
