#include <sys/param.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <netdb.h>
#include <grp.h>
#include <pwd.h>

char *grpnames[NGROUPS+1];
int ngrps;
struct passwd *pwd;
struct group *grp;
int verbose;

extern int permcheck();

main(argc, argv)
char **argv;
{
	char *logn, *ttyn, *hostn;
	struct hostent *hent;
	int lp, i;

	if(argc<4) {
		fprintf(stderr, "usage: %s [-v] username ttyname hostname\n",
			*argv);
		exit(0);
	}
	if(!strcmp(argv[1], "-v")) {
		argv++;
		verbose=1;
	}

	logn = argv[1];
	ttyn = argv[2];

	setpwent();
	pwd = getpwnam(logn);
	if(!pwd) {
		fprintf(stderr, "%s: unknown user\n", logn);
		exit(0);
	}

	setgrent();
	ngrps = 0;
	if(!(grp=getgrgid(pwd->pw_gid))) {
		fprintf(stderr, 
			"%d: group id has no name\n", pwd->pw_gid);
		exit(0);
	}
	grpnames[ngrps++] = strdup(grp->gr_name);
	while( grp=getgrent() ) {
		if(pwd->pw_gid == grp->gr_gid)
			continue;
		while(*grp->gr_mem) {
			if( !strcmp(logn, *grp->gr_mem)) {
				grpnames[ngrps++] = strdup(grp->gr_name);
			}
			grp->gr_mem++;
		}
	}
	endgrent();
	grpnames[ngrps] = NULL;

	if(verbose) {
		printf("%d group%s:", ngrps, (ngrps>1)?"s":"");
		for(i=0; i<ngrps; i++)
			printf(" %s", grpnames[i]);
		printf("\n");
	}

	for( argv= &argv[3]; *argv; argv++) {
		if((hent = gethostbyname(*argv)))
			hostn = hent->h_name;
		else
			hostn = *argv;
		lp = permcheck(logn, ttyn, grpnames, hostn);
		if(verbose)
			printf("user %s %spermitted on %s:%s\n",
				logn, lp ? "":"not ", hostn, ttyn);
		else
			printf("%s: %s\n", hostn, lp ? "":"not");
	}
	exit(0);
}



