/*
 * $Header: patchlevel.h,v 1.1 89/06/20 21:48:53 aklietz Exp $
 *
 * $Log:	patchlevel.h,v $
 * Revision 1.1  89/06/20  21:48:53  aklietz
 * Initial revision
 * 
 */

#define PATCHLEVEL 1
