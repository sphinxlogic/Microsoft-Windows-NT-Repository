
/* @(#) patchlevel.h 1.1 90/09/08 14:45:00 */

/*
 * Package:	du - Enhanced "du" disk usage replacement.
 * File:	patchlevel.h - Version comments.
 *
 * Sat Sep  8 14:34:56 1990 - Chip Rosenthal <chip@chinacat.Unicom.COM>
 *	Cleanup for distribution.
 * Tue Apr 17 21:50:58 1990 - Chip Rosenthal <chip@chinacat.Unicom.COM>
 *	Original composition.
 *
 * Copyright 1990, Unicom Systems Development.  All rights reserved.
 * See accompanying README file for terms of distribution and use.
 */


#define PATCHLEVEL	0

