/*
 * rnews.c - uux command for bootstrap news
 * copyright 1989 Ronald Florence (ron@mlfarm 7/30/89)
 */

#include <stdio.h>
#include <time.h>

#ifndef Newsspool
#define Newsspool    "/usr/spool/news/bsnews"
#endif
#ifndef Feeder
#define Feeder	     "Usenet"
#endif

#define Compress     "/usr/bin/compress -dc > "

char  	*mktemp(),
        dcomp[40] = Compress;

main()
{
  FILE	*nf, *cf;
  char  buf[BUFSIZ],
        *tmpnews = mktemp("newsart.XXXXXX");
  register  c;
  int	new = 1, n;

  if (!(nf = fopen(Newsspool, "a")))
    {
      fprintf(stderr, "rnews: can't write to %s\n", Newsspool);
      exit(1);
    }

  while (fgets(buf, BUFSIZ, stdin) != NULL)
    {
				/* batched? */
      if (!strncmp(buf, "#! ", 3))
	{
				/* compressed? */
	  if (!strncmp(buf+3, "cunbatch", 8))
	    {
	      strcat(dcomp, tmpnews);
	      if (!(cf = popen(dcomp, "w")))
		{
		  timestamp(nf);
		  fprintf(nf, "\nNews lost!  Can't uncompress (rnews).\n\n");
		  exit(1);
		}
				/* uncompress */
	      while ((c = getchar()) != EOF)
		putc(c, cf);
	      pclose(cf);
				/* and loop around to unbatch */
	      cf = freopen(tmpnews, "r", stdin);
	      continue;
	    }
				/* unpack the batch */
	  else if (sscanf(buf+3, "rnews %d", &n) == 1)  
	    {
	      timestamp(nf);
	      for (c = 0; c < n; c += strlen(buf))
		{
		  if (fgets(buf, BUFSIZ, stdin) == NULL)
		    break;
		  if (!strncmp(buf, "From ", 5))
		    putc('>', nf);
		  fputs(buf, nf);
		}
	      putc('\n', nf);
	      continue;
	    }
	}
				/* it must be unbatched */
      else	
	{
	  if (new)
	    {
	      timestamp(nf);
	      new = 0;
	    }
	  if (!strncmp(buf, "From ", 5))
	    putc('>', nf);
	  fputs(buf, nf);
	}
    }
  if (!new)
    putc('\n', nf);
  unlink(tmpnews);
  exit(0);
}


timestamp(newsfile)
FILE  *newsfile;
{
  long	clock, time();
  char	*ctime();

  time(&clock);
  fprintf(newsfile, "From %s %s", Feeder, ctime(&clock));
}
