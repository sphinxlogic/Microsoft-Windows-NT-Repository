/*
 * checknews.c - checks for bootstrap news
 * copyright 1989 Ronald Florence (ron@mlfarm, 7/30/89)
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifndef Newsspool
#define Newsspool  "/usr/spool/news/bsnews"
#endif
#define bye(s)	   puts(s), exit(1)

main()
{
  struct stat nt, lt;
  char newsmarker[80], *getenv();

  if (!strcpy(newsmarker, getenv("HOME")))
    bye("checknews: cannot find $HOME.");
  strcat(newsmarker, "/.lastnews");
  if (stat(newsmarker, &lt) == -1)
    lt.st_mtime = 0;
  if (stat(Newsspool, &nt) == -1)
    bye("checknews: cannot find Newsspool.");
  puts(nt.st_mtime < lt.st_mtime ? "No news is good news.":\
       "New news has arrived.");
  exit(0);
}
