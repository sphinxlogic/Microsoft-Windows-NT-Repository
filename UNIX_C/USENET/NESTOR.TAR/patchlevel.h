/*
 *---------------------------------------------------------------------------
 *
 *		H I S T O R Y     M O D I F I C A T I O N S
 *		===========================================
 *
 *	17-Mar-91 EHK	Written from scratch.
 *	02-Apr-91 EHK	Major cleanup; prepare test-release;	0.0-beta PL0
 *	09-Apr-91 EHK	Ultrix syslog differs; fixed;		0.1-beta PL0
 *	11-Apr-91 EHK	Intermediate test-release; bug fix;	0.2-beta PL0
 *	16-Apr-91 EHK	Generic syslog parsing; speed reduce;	0.3-beta PL0
 *	17-Apr-91 EHK	Few additions per beta-testers request	0.4-beta PL0
 *	23-May-91 EHK	Fixed stupid bug in supplied 'strstr'	0.5-beta PL0
 *	23-May-91 EHK	Prepared UseNet community release	1.0 PL0
 *	03-Jun-91 EHK	Various problem fixes; better parsing	1.0 PL1
 *	11-Jun-91 EHK	Safer mem alloc; real-logging period 	1.0 PL2
 *	08-Jul-91 EHK	Nicer report; longer hostnames allowed	1.0 PL3
 *
 *---------------------------------------------------------------------------
 */

#define PATCHLEVEL	3
