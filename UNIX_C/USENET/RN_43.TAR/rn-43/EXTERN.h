/* $Header: EXTERN.h,v 4.3 85/05/01 11:58:01 lwall Exp $
 *
 * $Log:	EXTERN.h,v $
 * Revision 4.3  85/05/01  11:58:01  lwall
 * Baseline for release with 4.3bsd.
 * 
 */

#undef EXT
#define EXT extern

#undef INIT
#define INIT(x)

#undef DOINIT
