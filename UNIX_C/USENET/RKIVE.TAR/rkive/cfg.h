/*
** 	@(#)cfg.h	1.1 6/1/89 
*/
#include "rkive.h"

#ifndef CFG
#define CFG 1
	int num;
	char *progname;
	struct group_archive group[NUM_NEWSGROUPS];
	FILE *errfp;
	FILE *logfp;
	int fill_in_defaults;
	extern char *config_file;
	extern char problems_dir[];
	extern char spooldir[];
	extern char compress[];
	extern char log[];
	extern char log_format[];
	extern char index[];
	extern char index_format[];
	extern char mail[];
	extern int default_type;
	extern int default_patch_type;
	extern int default_owner;
	extern int default_group;
	extern int default_modes;
#else
	extern int num;
	extern char *progname;
	extern struct group_archive group[];
	extern FILE *errfp;
	extern FILE *logfp;
#endif /* CFG */
