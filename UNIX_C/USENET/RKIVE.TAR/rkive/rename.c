/*    
**
** This software is Copyright (c) 1989 by Kent Landfield.
**
** Permission is hereby granted to copy, distribute or otherwise 
** use any part of this package as long as you do not try to make 
** money from it or pretend that you wrote it.  This copyright 
** notice must be maintained in any copy made.
**
**
**  History:
**	Creation: Tue Feb 21 08:52:35 CST 1989 due to necessity.
**                                                               
*/
#ifndef lint
static char SID[] = "@(#)rename.c	1.1 6/1/89";
#endif

#include <stdio.h>

extern FILE *errfp;

/*
**    rename(sfn, dfn)
**    rename char *sfn to char *dfn
*/

int rename(sfn, dfn)
char *sfn;        /* source file name      */
char *dfn;        /* destination file name */
{
    int rcd;

    (void) unlink(dfn);       /* remove the destination file */

    if ((rcd = link(sfn, dfn)) == -1) 
        (void) fprintf(errfp, "Can't link %s to %s\n", sfn, dfn);
    else if ((rcd = unlink(sfn)) == -1) 
        (void) fprintf(errfp, "Can't unlink %s\n", sfn);
    return(rcd);
}

