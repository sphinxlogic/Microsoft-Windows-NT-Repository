/*
**
** This software is Copyright (c) 1989 by Kent Landfield.
**
** Permission is hereby granted to copy, distribute or otherwise 
** use any part of this package as long as you do not try to make 
** money from it or pretend that you wrote it.  This copyright 
** notice must be maintained in any copy made.
**
**
**  History:
**	Creation: Tue Feb 21 08:52:35 CST 1989 due to necessity.
**                                                               
*/
#ifndef lint
static char SID[] = "@(#)version.c	1.1 6/1/89";
#endif

#include <stdio.h>
#include "patchlevel.h"

extern char sccsid[];

version()
{
    void exit();

    (void) fprintf(stderr,"%s\nPatch level: %d\n", sccsid, PATCHLEVEL);
    exit(0);
}
