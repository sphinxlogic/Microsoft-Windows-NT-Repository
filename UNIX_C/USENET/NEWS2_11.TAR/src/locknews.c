/*
 * From: hansen@pegasus.UUCP (Tony L. Hansen)
 * Newsgroups: news.admin,comp.sources.unix,news.software.b
 * Subject: Re: rmgroups for old rec groups have been posted
 * Date: 21 Dec 86 04:12:51 GMT
 * Reply-To: hansen@pegasus.UUCP (62545457-Tony L. Hansen;LZ 3B-315;6243)
 * Organization: AT&T-IS Labs, Lincroft, NJ
 *
 * < I got all the rmgroups.  Unfortunately, I found out the hard way
 * < that rmgroup still doesn't lock the active file while doing its
 * < work, so if news is coming in while you're rmgroup'ing, you'll
 * < corrupt your active file.
 *
 * Here is a locknews (and unlocknews) program which uses the same locking
 * scheme as the rest of 2.11 news. I've only tested it on System V machines,
 * but the code is there for other systems and it should work unless I've made
 * some silly mistake in the coding. Feel free to post fixes as they are found.
 *
 * The following shar contains the code for locknews/unlocknews, plus patches
 * for Makefile.dst and rmgroup.sh to build and use the new process.  I put the
 * same copyright comment at the top of the code which is found on top of all
 * of the rest of the 2.11 code.  On System V machines, only epathinit.o needs
 * to be linked in, but this may not be true for other systems. 
 *
 * This pair of processes can also be used whenever you're doing some work on
 * the news system. Simply run locknews, do your work, and then run unlocknews.
 *
 * The code is being mailed to Rick as well as being posted.
 *
 *					Tony Hansen
 *					ihnp4!pegasus!hansen
*/

/*
 * This software is Copyright (c) 1986 by Rick Adams.
 *
 * Permission is hereby granted to copy, reproduce, redistribute or
 * otherwise use this software as long as: there is no monetary
 * profit gained specifically from the use or reproduction or this
 * software, it is not sold, rented, traded or otherwise marketed, and
 * this copyright notice is included prominently in any copy
 * made.
 *
 * The author make no claims as to the fitness or correctness of
 * this software for any use whatsoever, and it is provided as is.
 * Any use of this software is at the user's own risk.
 *
 * lock.news/unlock.news - locks and unlocks news system
 */

#ifdef SCCSID
static char	*SccsId = "@(#)locknews.c	1.1	12/19/86";
#endif /* SCCSID */

#include "params.h"
#include "defs.h"
#include <errno.h>
#include <sys/file.h>

#ifdef LOCKF
#include <unistd.h>
#endif /* LOCKF */

FILE	*lockfp;
char	execbuf[BUFLEN];

char *Progname;				/* name of program */
char bfr[LBUFLEN];			/* general-use scratch area */

#if defined(BSD4_2) || defined(LOCKF) || defined(BSD4_3)
static int LockFd = -1;			/* file descriptor opened */
#endif

#if defined(BSD4_2) || defined(LOCKF) || defined(BSD4_3)
catchunlock()
{
    /* don't do anything */
}
#endif /* BSD4_2 || LOCKF || BSD4_3) */

dolock()
{
#if defined(BSD4_2) || defined(LOCKF) || defined(BSD4_3)
    if (signal(SIGHUP, SIG_IGN) != SIG_IGN)
	signal(SIGHUP, catchunlock);
    if (signal(SIGINT, SIG_IGN) != SIG_IGN)
        signal(SIGINT, catchunlock);
    if (signal(SIGTERM, SIG_IGN) != SIG_IGN)
        signal(SIGTERM, catchunlock);

    /* set up exclusive locking so inews does not run while expire does */
    LockFd = open(ACTIVE, 2);
# ifdef    LOCKF
    (void) lockf(LockFd, F_LOCK, 0);
# else    /* BSD4_2, BSD4_3 */
    (void) flock(LockFd, LOCK_EX);
# endif    /* BSd4_2, BSD4_3 */
    
    /* save a reference to this process so */
    /* that unlocknews can find it */
    sprintf(bfr, "%s.lock", ACTIVE);
    lockfp = fopen(bfr, "w");
    if (!lockfp)
	xerror("Cannot open lock file\n");

    if (fork())
        {
        sleep(2); /* give the child a chance to write its pid */
        xxit(0);
	}
    else
        {
        (void) fprintf (lockfp, "%d", getpid());
        fclose(lockfp);
        pause();	/* now wait for signal from unlocknews */
	}
#else    /* !BSD4_2 && !LOCKF && !BSD4_3 */
    int i = 0;
    sprintf(bfr, "%s.lock", ACTIVE);
    while (LINK(ACTIVE, bfr) < 0 && errno == EEXIST)
        {
        if (i++ > 5)
	    xerror("Can't get lock for locknews\n");
        sleep(i*2);
	}
#endif    /* !BSD4_2  && !LOCKF && !BSD4_3 */
}

rmlock()
{
#if defined(BSD4_2) || defined(LOCKF) || defined(BSD4_3)
    sprintf(bfr, "%s.lock", ACTIVE);
    lockfp = fopen(bfr, "r");
    if (!lockfp)
	xerror("Cannot open lock file\n");

    if (!fgets(bfr, sizeof(bfr), lockfp))
        xerror("Cannot cannot read locking process id\n");
    (void) UNLINK(bfr);
    (void) kill(atoi(bfr), SIGTERM);
#else
    sprintf(bfr, "%s.lock", ACTIVE);
    (void) UNLINK(bfr);
#endif    /* !BSD4_2 && !BSD4_3 */
}

main(argc, argv)
int argc;
char **argv;
{
    char *name = rindex(argv[0], '/');
    if (name++ == NULL)
        name = argv[0];
    Progname = argv[0];
    pathinit();
    (void) umask(N_UMASK);

    if (strncmp(name, "lock", 4) == 0)
        dolock();
    else {
        rmlock();
	/*
	 * Now read in any saved news.
	 */
#ifdef IHCC
	sprintf(execbuf, "%s/%s", logdir(HOME), RNEWS);
	execl(execbuf, "rnews", "-U", (char *)NULL);
#else /* ! IHCC */
	execl(RNEWS, "rnews", "-U", (char *)NULL);
#endif /* ! IHCC */
	perror(RNEWS);
	xxit(1);
    }
    xxit(0);
    /* NOTREACHED */
}

xxit(i)
{
    exit(i);
}

/* VARARGS1 */
xerror(message, arg1, arg2, arg3)
char *message;
long arg1, arg2, arg3;
{
	char buffer[LBUFLEN];

	fflush(stdout);
	(void) fprintf (stderr, "%s: ", Progname);
	(void) fprintf (stderr, message, arg1, arg2, arg3);
	xxit(1);
}
