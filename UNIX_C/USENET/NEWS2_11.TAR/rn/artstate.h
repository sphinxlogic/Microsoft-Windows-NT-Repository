/* $Header: /usr/src/local/bin/news/rn/RCS/artstate.h,v 4.4 85/08/13 17:44:46 rsk Exp $
 *
 * $Log:	artstate.h,v $
 * Revision 4.4  85/08/13  17:44:46  rsk
 * Results of patches 1 through 25
 * 
 * Revision 4.3  85/05/01  11:35:59  lwall
 * Release 4.3 of rn
 * 
 * Revision 4.3  85/05/01  11:35:59  lwall
 * Baseline for release with 4.3bsd.
 * 
 */

EXT bool reread INIT(FALSE);		/* consider current art temporarily */
				    /* unread? */
EXT bool do_fseek INIT(FALSE);	/* should we back up in article file? */

EXT bool oldsubject INIT(FALSE);	/* not 1st art in subject thread */
EXT ART_LINE topline INIT(-1);		/* top line of current screen */
EXT bool do_hiding INIT(TRUE);		/* hide header lines with -h? */
#ifdef ROTATION
EXT bool rotate INIT(FALSE);		/* has rotation been requested? */
#endif
EXT char *prompt;			/* pointer to current prompt */

EXT char *firstline INIT(Nullch);			/* special first line? */
#ifdef CUSTOMLINES
EXT char *hideline INIT(Nullch);		/* custom line hiding? */
EXT char *pagestop INIT(Nullch);		/* custom page terminator? */
EXT COMPEX hide_compex;
EXT COMPEX page_compex;
#endif
