#!/bin/sh
# config.sh
# This file was produced by running the Configure script.

pdp=''
case `hostname` in
	c.cc.purdue.edu)  pdp='yes' ;;
	d.cc.purdue.edu)  pdp='yes' ;;
	e.cc.purdue.edu)  pdp='yes' ;;
	h.cc.purdue.edu)  pdp='' ;;
	i.cc.purdue.edu)  pdp='' ;;
	j.cc.purdue.edu)  pdp='' ;;
	k.cc.purdue.edu)  pdp='' ;;
	l.cc.purdue.edu)  pdp='' ;;
	n.cc.purdue.edu)  pdp='' ;;
	s.cc.purdue.edu)  pdp='' ;;
	t.cc.purdue.edu)  pdp='' ;;
esac

n='-n'
c=''
libc='/lib/libc.a'
eunicefix=':'
eunice='undef'
cpp='cc -E'
shsharp='true'
startsh='#!/bin/sh'
spitshell='cat'
test='/bin/test'
expr='expr'
sed='sed'
echo='echo'
cat='cat'
rm='rm'
mv='mv'
cp='cp'
tail='tail'
tr='tr'
mkdir='mkdir'
sort='sort'
uniq='uniq'
inews='/usr/local/lib/news/inews'
grep='grep'
egrep='/usr/bin/egrep'
contains='grep'
lib='/usr/local/lib/news'
libexp='/usr/local/lib/news'
nametype='bsd'
cc='cc'
if [ -n "$pdp" ]
then
	iandd='-i'
else
	iandd=''
fi
termlib='-ltermlib'
if [ -n "$pdp" ]
then
	jobslib='-ljobs'
	ndirlib='-lndir'
	libndir='define'
else
	jobslib=''
	ndirlib=''
	libndir='undef'
fi
usendir='undef'
ndirc=''
ndiro=''
pager='/usr/ucb/more'
mailer='/usr/lib/sendmail'
internet='define'
rnbin='/usr/local/bin'
filexp='/usr/local/lib/rn/filexp'
distlist='all '
Log='$Log'
Header='$Header'
sitename='cc.purdue.edu'
domain='cc.purdue.edu'
orgname='Purdue University'
isadmin='define'
newsadmin='news'
rnlib='/usr/local/lib/rn'
mansrc='/usr/man/man1'
manext='1'
maildir='/usr/spool/mail'
spool='/usr/spool/news'
active='/usr/local/lib/news/active'
myactive='/usr/local/lib/news/active'
mininact='define'
pref='/bin/csh'
defeditor='/usr/ucb/vi'
rootid='0'
mboxchar='F'
locpref='pucc'
orgpref='purdue'
citypref='laf'
statepref='in'
cntrypref='usa'
contpref='na'
strchr='undef'
if [ -n "$pdp" ]
then
	novoid='define'
else
	novoid='undef'
fi
novfork='undef'
portable='define'
passnam='define'
berknam='define'
usgnam='undef'
whoami='undef'
termio='undef'
if [ -n "$pdp" ]
then
	fcntl='undef'
else
	fcntl='define'
fi
ioctl='define'
normsig='define'
havetlib='define'
getpwent='undef'
gethostname='define'
douname='undef'
phostname='define'
hostcmd='hostname'
norelay='define'
isrrn='undef'
rrnserver=''
NNTPSRC=''
CONFIG=true
