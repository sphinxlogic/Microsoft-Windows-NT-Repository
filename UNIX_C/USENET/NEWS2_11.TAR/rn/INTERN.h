/* $Header: /usr/src/local/bin/news/rn/RCS/INTERN.h,v 4.3 85/05/01 11:33:16 lwall Exp $
 *
 * $Log:	INTERN.h,v $
 * Revision 4.3  85/05/01  11:33:16  lwall
 * Release 4.3 of rn
 * 
 * Revision 4.3  85/05/01  11:33:16  lwall
 * Baseline for release with 4.3bsd.
 * 
 */

#undef EXT
#define EXT

#undef INIT
#define INIT(x) = x

#define DOINIT
