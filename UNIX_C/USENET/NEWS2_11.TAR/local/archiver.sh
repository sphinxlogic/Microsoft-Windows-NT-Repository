#!/bin/csh -f

# This alias trims and beautifies an article.  Well, sort of.

alias artfilt	'sed -e "/^Path: /d" -e "/^Newsgroups: /d" -e "/^Message-ID: /d" -e "/^Date-Received: /d" -e "/^Reply-To: /d" -e "/^Followup-To: /d" -e "/^Distribution: /d" -e "/^Organization: /d" -e "/^Lines: /d" -e "/^Xref: /d" -e "/^-- "\$"/,"\$"d"'

set newsgroup = `basename ${argv[1]:h}`
set article = ${argv[1]:t}
set logfile = /usr/adm/logs/$newsgroup

echo "Article: $article" >> $logfile
cat $argv[1] | artfilt  >> $logfile
echo "" >> $logfile
