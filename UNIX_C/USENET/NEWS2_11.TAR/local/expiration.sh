#!/bin/csh
#
# News expiration script for PUCC machines
# Expire all usenet news after 7 days; force it.
# Expire all local news after 14 days

set LIBDIR = /usr/local/lib/news

$LIBDIR/expire -e 7 -i -n control junk comp misc news rec sci soc talk unix-pc bionet alt gnu ddn
$LIBDIR/expire -e 14 -n general test purdue in

# Zero log files
# Dink old history files (but keep old active file)

cp /dev/null $LIBDIR/log
cp /dev/null $LIBDIR/errlog
rm -f $LIBDIR/ohistory $LIBDIR/ohistory.dir $LIBDIR/ohistory.pag
