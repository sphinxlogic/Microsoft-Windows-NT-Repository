#!/bin/sh
#
PATH=/usr/local/bin:/usr/ucb:/bin:/usr/bin:/usr/local/lib/news
export PATH

Groups="unix hardware isn vm vsos operations"

if [ $# -ne 1 ]
then
	echo "Usage: 'log <group>' where <group> is one of: $Groups"
	exit 1
fi

DEFeditor=/usr/ucb/vi
Tmpart=${DOTDIR-${HOME-$LOGDIR}}/.article
Loggroup=purdue.cc.log.$1
Logsender=`/usr/ucb/whoami`
Logsite=`/bin/hostname`
Logname=`/usr/local/bin/uid -ib`
Logdate=`/bin/date`
Logorg="Purdue University Computing Center"

cat > $Tmpart << HEADER
Newsgroups: $Loggroup
Subject: 
Expires: 
References: 
Sender: $Logsender@$Logsite ($Logname)
Reply-To: $Logsender@$Logsite
Followup-To: test
Distribution: purdue
Organization: $Logorg
Keywords: 

Date:	$Logdate

HEADER

case $1 in
	unix)
		cat >> $Tmpart << BODY
What:	

Systems: VAX		(h i j k l n mace)
	 Sequent	(s t mentor)
	 Sun		(staff)
	 ETA		(boiler)

Documentation Affected:	

Changes Reported To:	Berkeley DEC ETA Sequent Sun

Files:	

BODY
		;;

	hardware)
		cat >> $Tmpart << BODY
Hardware Device/System:

Problem:

Action:

Possible Side Effects:

Suggested Followup or Action on Reoccurence:

Other Engineers Involved:

BODY
		;;

	isn)
		cat >>  $Tmpart << BODY
What:	

Systems: VAX		(h i j k l n mace)
	 Sequent	(s t mentor)
	 Sun		(staff)
	 ETA		(boiler)

Documentation Affected:	

Changes Reported To:	AT&T-IS

Files:	

BODY
		;;

	vm)
		echo "Not implemented, must be logged from VM"
		exit 1
		;;

	vsos)
		cat >> $Tmpart << BODY
What:	

Systems: VSOS		(LCD)

Documentation affected:	

Changes reported to:	CDC

Files/decks:    

BODY
		;;
	operations)
		cat >> $Tmpart << BODY
Operator:	

Time	Log Entry

BODY
		;;
	*)
		echo "Usage: 'log <group>' where <group> is one of: $Groups"
		exit 1
		;;
esac

State=edit
while true
do
	case $State in
		edit)
			${VISUAL-${EDITOR-$DEFeditor}} $Tmpart
			State=ask
			;;

		ask)
			echo ""
			echo -n "Send, abort, edit, or list? "
			read Ans

			case "$Ans" in
				a*)
					State=rescue
					;;

				e*)
					set $Ans
					case $# in
						2)
							VISUAL="$2"
							;;
					esac
					State=edit
					;;

				l*)
					${PAGER-/usr/ucb/more} $Tmpart
					State=ask
					;;

				s*)
					State=send
					;;

				h*)
					cat <<'EOH'

Type s to send the article, a to abort and append the article to dead.article,
e to edit the article again, or l to list the article.

To invoke an alternate editor, type 'e editor'.

EOH
					;;
			esac
			;;

		send)
			set X `sed < $Tmpart -n -e '/^Newsgroups: /{' -e p -e q -e '}'`
			shift
			case $# in
				2)
					if inews -h < $Tmpart
					then
						exit 0
					else
						State=rescue
					fi
					;;

				*)
					echo ""
					echo "Malformed Newsgroups line."
					echo ""
					sleep 1
					State=edit
					;;
			esac
			;;

		rescue)
			cat $Tmpart >> ${HOME-$LOGDIR}/dead.article
			echo "Article appended to ${HOME-$LOGDIR}/dead.article"
			echo "A copy may be temporarily found in $Tmpart"
			exit 1
			;;
	esac
done
