/*
 * Provide the version number of this release.
 */

char	nntp_version[] = "1.5 (26 Feb 88)";
