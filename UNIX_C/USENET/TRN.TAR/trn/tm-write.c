/* $Id: tm-write.c,v 4.4.3.1 1991/11/22 04:12:21 davison Trn $
**
** $Log: tm-write.c,v $
** Revision 4.4.3.1  1991/11/22  04:12:21  davison
** Trn Release 2.0
** 
*/

#define TMPTHWRITE
#include "mt-write.c"
