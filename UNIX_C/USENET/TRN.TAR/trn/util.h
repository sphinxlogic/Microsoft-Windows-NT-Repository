/* $Id: util.h,v 4.4 1991/09/09 20:27:37 sob Exp sob $
 *
 * $Log: util.h,v $
 * Revision 4.4  1991/09/09  20:27:37  sob
 * release 4.4
 *
 *
 * 
 */
/* This software is Copyright 1991 by Stan Barber. 
 *
 * Permission is hereby granted to copy, reproduce, redistribute or otherwise
 * use this software as long as: there is no monetary profit gained
 * specifically from the use or reproduction of this software, it is not
 * sold, rented, traded or otherwise marketed, and this copyright notice is
 * included prominently in any copy made. 
 *
 * The author make no claims as to the fitness or correctness of this software
 * for any use whatsoever, and it is provided as is. Any use of this software
 * is at the user's own risk. 
 */

EXT bool waiting INIT(FALSE);	
			/* are we waiting for subprocess (in doshell)? */
EXT int len_last_line_got INIT(0);
			/* strlen of some_buf after */
			/*  some_buf = get_a_line(bufptr,buffersize,fp) */

/* is the string for makedir a directory name or a filename? */

#define MD_DIR 	0
#define MD_FILE 1

void	util_init ANSI((void));
int	doshell ANSI((char *,char *));
char	*safemalloc ANSI((MEM_SIZE));
char	*saferealloc ANSI((char *,MEM_SIZE));
char	*safecpy ANSI((char *,char *,int));
char	*safecat ANSI((char *,char *,int));
char	*cpytill ANSI((char *,char *,int));
char	*instr ANSI((char *,char *, int));
#ifdef SETUIDGID
    int		eaccess ANSI((char *,int));
#endif
char	*getwd ANSI((char *));
char	*get_a_line ANSI((char *,int,FILE *));
char	*savestr ANSI((char *));
int	makedir ANSI((char *,int));
void	setenv ANSI((char *,char *));
int	envix ANSI((char *));
void	notincl ANSI((char *));
char	*getval ANSI((char *,char *));
void	growstr ANSI((char **,int *,int));
void	setdef ANSI((char *,char *));
#ifdef SERVER
int	nntp_get ANSI((char *, int));
#endif
