/* $Id: rcstuff.h,v 4.4.2.1 1991/12/01 18:05:42 sob PATCH_2 sob $
 *
 * $Log: rcstuff.h,v $
 * Revision 4.4.2.1  1991/12/01  18:05:42  sob
 * Patchlevel 2 changes
 *
 * Revision 4.4  1991/09/09  20:27:37  sob
 * release 4.4
 *
 *
 * 
 */
/* This software is Copyright 1991 by Stan Barber. 
 *
 * Permission is hereby granted to copy, reproduce, redistribute or otherwise
 * use this software as long as: there is no monetary profit gained
 * specifically from the use or reproduction of this software, it is not
 * sold, rented, traded or otherwise marketed, and this copyright notice is
 * included prominently in any copy made. 
 *
 * The author make no claims as to the fitness or correctness of this software
 * for any use whatsoever, and it is provided as is. Any use of this software
 * is at the user's own risk. 
 */

EXT char **rcline INIT(NULL);/* pointers to lines of .newsrc */
EXT ART_UNREAD *toread INIT(NULL);
			/* number of articles to be read in newsgroup */
			/* <0 => invalid or unsubscribed newsgroup */
#define TR_ONE ((ART_UNREAD) 1)
#define TR_NONE ((ART_UNREAD) 0)
#define TR_UNSUB ((ART_UNREAD) -1)
			/* keep this one as -1, some tests use >= TR_UNSUB */
#define TR_BOGUS ((ART_UNREAD) -2)
#define TR_JUNK ((ART_UNREAD) -3)

#ifdef USETHREADS
#define RCCHAR(ch) ((ch) == '0' ? ':' : (ch))
#endif

EXT char *rcchar INIT(NULL); /* holds the character : or ! while spot is \0 */
EXT char *rcnums INIT(NULL); /* offset from rcline to numbers on line */
EXT ACT_POS *softptr INIT(NULL);
			/* likely ptr to active file entry for newsgroup */
EXT bool paranoid INIT(FALSE);	/* did we detect some inconsistency in .newsrc? */
EXT int maxrcline INIT(0);	/* current maximum # of lines in .newsrc */

bool	rcstuff_init ANSI((void));
bool	get_ng ANSI((char *,bool_int));	/* return TRUE if newsgroup can be found or added */
NG_NUM	add_newsgroup ANSI((char *,char_int));
#ifdef RELOCATE
    NG_NUM	relocate_newsgroup ANSI((NG_NUM,NG_NUM));/* move newsgroup around */
#endif
void	list_newsgroups ANSI((void));
NG_NUM	find_ng ANSI((char *));	/* return index of newsgroup */
void	cleanup_rc ANSI((void));
void	sethash ANSI((NG_NUM));
int	hash ANSI((char *));
void	newsrc_check ANSI((void));
void	write_rc ANSI((void));
void	get_old_rc ANSI((void));
