/* $Id: ngdata.h,v 4.4 1991/09/09 20:23:31 sob Exp sob $
 *
 * $Log: ngdata.h,v $
 * Revision 4.4  1991/09/09  20:23:31  sob
 * release 4.4
 *
 *
 * 
 */
/* This software is Copyright 1991 by Stan Barber. 
 *
 * Permission is hereby granted to copy, reproduce, redistribute or otherwise
 * use this software as long as: there is no monetary profit gained
 * specifically from the use or reproduction of this software, it is not
 * sold, rented, traded or otherwise marketed, and this copyright notice is
 * included prominently in any copy made. 
 *
 * The author make no claims as to the fitness or correctness of this software
 * for any use whatsoever, and it is provided as is. Any use of this software
 * is at the user's own risk. 
 */

EXT FILE *actfp INIT(Nullfp);	/* the active file */
EXT bool writesoft INIT(FALSE);	/* rewrite the soft pointer file? */
EXT int softtries INIT(0), softmisses INIT(0);

#ifdef SERVER
    EXT char active_name[MAXFILENAME];
#endif

#ifdef CACHEFIRST
    EXT ART_NUM *abs1st INIT(NULL);	/* 1st real article in newsgroup */
#else
# ifdef MININACT
    EXT ART_NUM abs1st INIT(0);
# endif
#endif

EXT char *moderated;
#ifdef USETHREADS
EXT char *tmpthread_group INIT(Nullch);
EXT int tmpthread_glen INIT(0);
EXT char *tmpthread_file INIT(Nullch);
EXT bool ThreadedGroup;
#endif
EXT long activeitems;			/* number of enties in active file */
void	ngdata_init ANSI((void));
ART_NUM	getngsize ANSI((NG_NUM));
ACT_POS findact ANSI((char *,char *,int,long));
ART_NUM	getabsfirst ANSI((NG_NUM,ART_NUM));
ART_NUM	getngmin ANSI((char *,ART_NUM));
