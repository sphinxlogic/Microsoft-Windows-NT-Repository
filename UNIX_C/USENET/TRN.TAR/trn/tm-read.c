/* $Id: tm-read.c,v 4.4.3.1 1991/11/22 04:12:21 davison Trn $
**
** $Log: tm-read.c,v $
** Revision 4.4.3.1  1991/11/22  04:12:21  davison
** Trn Release 2.0
** 
*/

#define TMPTHREAD
#include "mt-read.c"
