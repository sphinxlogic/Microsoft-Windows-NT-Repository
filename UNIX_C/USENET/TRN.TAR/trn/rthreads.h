/* $Id: rthreads.h,v 4.4.3.1 1991/11/22 04:12:18 davison Trn $
**
** $Log: rthreads.h,v $
** Revision 4.4.3.1  1991/11/22  04:12:18  davison
** Trn Release 2.0
** 
*/

EXT TOTAL total;

EXT PACKED_ROOT *p_roots INIT(0);
EXT WORD *root_subjects INIT(0);
EXT WORD *author_cnts INIT(0);
EXT WORD *subject_cnts INIT(0);
EXT char **author_ptrs INIT(0);
EXT char **subject_ptrs INIT(0);
EXT PACKED_ARTICLE *p_articles INIT(0);
EXT WORD *root_article_cnts INIT(0);
EXT char *selected_roots INIT(0);
EXT ART_NUM *saved_selections INIT(0);
EXT bool unread_selector INIT(0);

EXT PACKED_ARTICLE *p_art INIT(0);
EXT PACKED_ARTICLE *curr_p_art INIT(0);
EXT PACKED_ARTICLE *recent_p_art INIT(0);

EXT int selected_root_cnt INIT(0);
EXT ART_NUM selected_count INIT(0);
EXT int unthreaded INIT(0);
EXT int select_page;
EXT bool scan_all_roots;
EXT bool output_chase_phrase;

#ifndef USETMPTHREAD
EXT int tobethreaded INIT(0);
#endif

void thread_init ANSI((void));
char *safemalloc ANSI((MEM_SIZE));
int use_data ANSI((bool_int));
void unuse_data ANSI((bool_int));
void find_article ANSI((ART_NUM));
void init_tree ANSI((void));
void entire_tree ANSI((void));
int tree_puts ANSI((char *,ART_LINE,int));
int finish_tree ANSI((ART_LINE));
void first_art ANSI((void));
void follow_thread ANSI((char_int));
void backtrack_thread ANSI((char_int));
void next_root ANSI((void));
void prev_root ANSI((void));
char select_thread ANSI((char_int));
int count_roots ANSI((bool_int));
int count_one_root ANSI((int));
PACKED_ARTICLE *upper_limit ANSI((PACKED_ARTICLE *,bool_int));

#define Nullart Null(PACKED_ARTICLE*)
