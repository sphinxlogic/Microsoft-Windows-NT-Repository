/*
 *	This version is for SunOS 3.x systems (tested on 3.5)
 */

#define	USE_STRINGS_H

#include "s-bsd4-2.h"

#define	HAVE_STRCHR

/*
 *	Define MICRO_ALARM to timeout after 0.1 seconds if possible
 */

#undef	MICRO_ALARM
#define MICRO_ALARM()	ualarm(100000,0)	/* BSD 4.3 */
