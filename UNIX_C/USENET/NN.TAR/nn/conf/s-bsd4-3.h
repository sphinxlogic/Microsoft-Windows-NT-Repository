/*
 *	This version is for 4.3 systems
 */

#include "s-bsd4-2.h"

/*
 *	Define MICRO_ALARM to timeout in 0.1 seconds if possible
 */

#undef	MICRO_ALARM
#define MICRO_ALARM()	ualarm(100000,0)	/* BSD 4.3 */

/*
 *	Define if your system has a 4.3BSD like syslog library.
 */

#define HAVE_SYSLOG
