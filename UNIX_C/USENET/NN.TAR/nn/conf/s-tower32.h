/*
 *	This version is for Tower-32 machines.
 */

#define NO_DIRENT_H
#include "s-sys5.h"

#undef	SIGNAL_HANDLERS_ARE_VOID
#undef	HAVE_MKDIR
