/*
 *	(c) Copyright 1990, Kim Fabricius Storm.  All rights reserved.
 *
 *	Modification history:
 *
 *	1988-07-20: Release 6.0beta 	(Denmark)
 *	1988-11-01: Release 6.1 	(Europe)
 *	1989-03-21: Release 6.2beta	(FTP)
 *	1989-05-30: Release 6.3		(comp.sources.unix)
 *	1989-09-08: Release 6.3.7	(FTP)
 *	1990-03-03: Release 6.4beta	(FTP)
 *	1990-05-07: Release 6.4		(comp.sources.unix)
 */

#define PATCHLEVEL 0

