/* $Source$
 *
 * $Revision$
 *
 *	uucast - Cast a UUX command to multiple systems.
 *
 * SYNOPSIS
 *
 * 	uucast
 *
 * DESCRIPTION
 *
 *	Note:	this program must run suid uucp.  It will create the
 *		files in the uucp directories owned by user uucp, with
 *		mask MASK.
 *
 * AUTHORS
 *
 * 	Mark Colburn, NAPS International (mark@jhereg.mn.org) 1/5/89
 * 	Shane McCarron, NAPS International (ahby@bungia.mn.org) 12/8/86
 *
 *	Copyright (C) Shane McCarron, 1987, 1989
 *
 * $Log$
 */

#include <pwd.h>
#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "uucast.h"
#ifndef	NODE
#include <sys/utsname.h>
#endif				/* NODE */

#define	NAMELEN	(14 + 1)	/* length of file names */

char	       *rcsid = "$Header$";


#ifdef	NODE
char            node[] = NODE,
#else				/* NODE */
char            node[8],	/* variable for node name from uname */
#endif				/* !NODE */
                user[] = USER,	/* the user that is doing the sending */
                comname[NAMELEN],	/* name of command file */
                remname[NAMELEN],	/* name of remote command file */
                nremname[NAMELEN],	/* name of remote data file */
                locname[NAMELEN];	/* name of local data file */
extern          errno;


int main(argc, argv)
int             argc;
char          **argv;
{
    void     	    makename();
    void     	    usage();
    struct passwd  *getpwnam();

    char            file[128],	/* file name to transmit */
                    path[128],	/* temporary path name */
                   *command = argv[2],	/* command to UUX */
                   *sysname[MAXSYS];	/* array of system names */
    FILE           *fptr;	/* file descriptor */
    int             i,		/* looping variable */
                    result,	/* result of link call */
                    seq,	/* sequence number */
                    syscount = 0;	/* number of systems to send to */
    struct passwd  *uucp;	/* struct for user uucp information */
#ifdef HDB
    struct stat	    sbuf;	/* struct for check directries */
#endif
    
    if (argc < 4) {
	usage(argv[0]);
    }
    
    if ((uucp = getpwnam("uucp")) >= 0) {
	setuid(uucp->pw_uid);
	setgid(uucp->pw_gid);
    }

    strcpy(file, argv[1]);	/* get the data file name */

    for (i = 3; i < argc; i++) {/* get the system names */
	sysname[i - 3] = argv[i];
	syscount++;
    }
#ifndef	NODE
    (void) getnode(node);	/* get the node name */
#endif				/* NODE */
    (void) umask(MASK);		/* clear the mask bits */
    seq = getpid();		/* get the process id */
    i = 0;
    while (i < syscount) {

#ifdef HDB
	(void) sprintf(path, "%s/%s", XDIR, sysname[i]);
	if (stat(path, &sbuf) == -1 && errno == ENOENT) {
	    if (mkdir(path, 0755) < 0) {
		(void) fprintf(stderr, "%s: unable to create directory %s\n", 
			       command, path);
		/*
		 * If the directory cannot be created, there is little
		 * sense going through the rest of the motions to copy
		 * the file the the non-existant directory...
		 */
		continue;
	    }
	}
#endif

	/*
	 * Cleaned up logic a bit - MHC 
	 */
	do {
	    makename(sysname[i], seq++);
#ifdef HDB
	    (void) sprintf(path, "%s/%s/%s", XDIR, sysname[i], remname);
#else
	    (void) sprintf(path, "%s/%s", XDIR, remname);
#endif				/* HDB */
	} while (!access(path, 0));

#ifdef HDB
	(void) sprintf(path, "%s/%s/%s", DDIR, sysname[i], comname);
#else
	(void) sprintf(path, "%s/%s", DDIR, comname);
#endif				/* HDB */

	if ((result = link(file, path)) == -1 && (errno == EXDEV)) {
	    /*
	     * Link failed due to target directoring being on a different
	     * file system.  Try doing a copy. If copy works then move path
	     * to file so that it can be used as a source to link the rest of
	     * the files. 
	     */

	    /* changed to do strcpy only if copy works - MHC */

	    if (result = copy(file, path) == 0) {
		strcpy(file, path);
	    }
	    
	} else if (result != 0) {
	    fprintf(stderr, "uucast: Link failed from %s to %s: %d\n",
		    file, path, errno);
	    exit(errno);
	}			/* end else */
# ifdef HDB
	(void) sprintf(path, "%s/%s/%s", XDIR, sysname[i], remname);
#else
	(void) sprintf(path, "%s/%s", XDIR, remname);
#endif
	fptr = fopen(path, "w");
#ifdef	WANTZ
	fprintf(fptr, "U %s %s\nN\nZ\nR %s\nF %s\nI %s\nC %s\n",
		user, node, user, comname, comname, command);
#else
	fprintf(fptr, "U %s %s\nF %s\nI %s\nC %s\n", user, node,
		comname, comname, command);
#endif
	fclose(fptr);
#ifdef HDB
	(void) sprintf(path, "%s/%s/%s", CDIR, sysname[i], locname);
#else
	(void) sprintf(path, "%s/%s", CDIR, locname);
#endif
	fptr = fopen(path, "w");
#ifdef HDB
	fprintf(fptr, "S %s %s %s - %s 0666 %s\nS %s %s %s - %s 0666 %s\n",
		comname, comname, user, comname, user, remname, nremname,
		user, remname, user);
#else
	fprintf(fptr, "S %s %s %s - %s 0666\nS %s %s %s - %s 0666\n",
		comname, comname, user, comname, remname, nremname,
		user, remname);
#endif
	fclose(fptr);
	i++;
    }				/* end for */
}


/* copy - copy a file from one spot to another
 *
 * DESCRIPTION
 *
 *	Copy copies a file using the system copy command.
 *
 * PARAMETERS
 *
 *	char *file1	- file to copy data from
 *	char *file2	- file to copy data to
 *
 * RETURNS
 *
 *	The result of the system cp(1) command.
 */

#ifdef __STDC__

int copy(char *file1, char *file2)

#else

int copy(file1, file2)
char           *file1,
               *file2;		/* source and destination name */

#endif
{
    char            cmd[BUFSIZ];/* make a command string */

    (void) sprintf(cmd, "cp %s %s", file1, file2);
    return (system(cmd));
}


#ifndef	NODE

/* getnode - get the nodename for the system
 *
 * DESCRIPTION
 *
 * 	Getnode attempts to get the node name of the system which
 *	this program is being executed on via the uname call.  If
 *	the uname call succeeds, the name of the system will be 
 *	copied into the array pointed to by name.
 *
 * PARAMETERS
 *
 *	char *name	- array to save node name in
 *
 * RETURNS
 *
 *	Getnode returns 0 if the uname call was successfull and 
 *	the node name was copied into the array pointed at by 
 *	name.  If the uname call fails, then the node name is
 *	not copied into the array pointed at by name, and getnode
 *	returns a value of -1 to the caller.
 */

#ifdef __STDC__

int getnode(char *name)

#else

int getnode(name)
char           *name;

#endif
{
    struct utsname  buffer;

    if (uname(&buffer) == 0) {
	strcpy(name, buffer.nodename);
	return(0);
    }
    return(-1);
}

#endif /* NODE */


/* makename - make the name files for casting.
 *
 * DESCRIPTION
 *
 *	remname and nremname use grade2 because on some systems (Ultrix)
 *	the remote command file must have an X in its name.  On normal
 *	systems, just make GRADE and GRADE2 the same.
 *
 * PARAMETERS
 *
 *	char *sysnam 	- name of system to send to
 *	int  num	- sequnce number to use for sending
 *
 */

#ifdef __STDC__

void makename(char *sysnam, int num)

#else

void makename(sysnam, num)	/* make file names */
char           *sysnam;		/* system name */
int             num;		/* sequence number */

#endif
{
    while (num > (10000 - 1))
	num = num - 10000;
#ifdef HDB
    (void) sprintf(comname, "D.%.5s%s%04d", node, GRADE, num);
    (void) sprintf(remname, "D.%.5s%04da12c", sysnam, num);
    (void) sprintf(nremname, "X.%.7s%s%04d", sysnam, GRADE, num);
    (void) sprintf(locname, "C.%.7s%s%04d", sysnam, GRADE, num);
#else
#ifndef	GRADE2
    (void) sprintf(comname, "D.%.6s%s%04d", sysnam, GRADE, num);
    (void) sprintf(remname, "D.%.6s%s%04d", node, GRADE, num);
    (void) sprintf(nremname, "X.%.6s%s%04d", node, GRADE, num);
    (void) sprintf(locname, "C.%.6s%s%04d", sysnam, GRADE, num);
#else
    (void) sprintf(comname, "D.%.6s%s%04d", sysnam, GRADE, num);
    (void) sprintf(remname, "D.%.6s%s%04d", node, GRADE2, num);
    (void) sprintf(nremname, "X.%.6s%s%04d", node, GRADE2, num);
    (void) sprintf(locname, "C.%.6s%s%04d", sysnam, GRADE, num);
#endif	!GRADE2
#endif	HDB
}


/* usage - print a usage message and exit
 *
 * DESCRIPTION
 *
 *	Usage prints out a helpful usage message on standard output
 *	and terminates the program.
 *
 * RETURNS
 *
 *	Usage returns a value of 1 to the parent process.
 */

#ifdef __STDC__

void usage(char *command)

#else

void usage(command)
char           *command;

#endif
{
    fprintf(stderr, "usage: %s file command system(s)\n", command);
    exit(1);
}


/* mkdir - make a directory
 *
 * DESCRIPTION
 *
 * 	Mkdir will make a directory of the name "dpath" with a mode of
 *	"dmode".  This is consistent with the BSD mkdir() function and the
 *	P1003.1 definitions of MKDIR.
 *
 *	Special considerations are taken into account since this will be
 *	running on a system which is running suid'ed.
 *
 * PARAMETERS
 *
 *	dpath		- name of directory to create
 *	dmode		- mode of the directory
 *
 * RETURNS
 *
 *	Returns 0 if the directory was successfully created, otherwise a
 *	non-zero return value will be passed back to the calling function
 *	and the value of errno should reflect the error.
 */

#ifdef __STDC__

int mkdir(char *dpath, int dmode)

#else
    
int mkdir(dpath, dmode)
char           *dpath;
int             dmode;

#endif
{
    int             cpid, status;
    int		    oldid;
    struct stat     statbuf;
    extern int      errno;
    char            buff[256];

    if (stat(dpath, &statbuf) == 0) {
	errno = EEXIST;		/* Stat worked, so it already exists */
	return (-1);
    }
    /* If stat fails for a reason other than non-existence, return error */
    if (errno != ENOENT)
	return (-1);

    switch (cpid = fork()) {

    case -1:			/* Error in fork() */
	return (-1);		/* Errno is set already */

    case 0:			/* Child process */

	status = umask(0);	/* Get current umask */
	status = umask(status | (0777 & ~dmode));	/* Set for mkdir */
	(void) sprintf(buff, "/bin/mkdir %s", dpath);
	if (system(buff) == 0) {

	    /*
	     * We are going to play a cute little game here.  We know
	     * that we are running set-uid.  therefore, when we create
	     * the directory, it will be owned by uid(getuid()) and 
	     * gid(getgid()), rather than uid(geteuid()) and 
	     * gid(getegid()), since mkdir is also set-uid.  Due to the
	     * way that the chown system call works, we have to change
	     * our effective user-id to our real-user-id in order to 
	     * change the ownership of the file to our effecitve-user-id.
	     * Got all that?  Since we are in a child, we don't care
	     * anyways...
	     */

	     oldid = geteuid();
	     if (setuid(getuid()) == 0) {
		 /* give away the file...only works on some systems */
		 chown(dpath, oldid, getuid());
	     }
	    _exit(0);
	} else {
	    _exit(-1);		/* Can't exec /bin/mkdir */
	}

    default:			/* Parent process */
	while (cpid != wait(&status)) {
	    /* Wait for child to finish */
	}
    }

    if ((status & 0x7F) != 0 || (status >> 8) != 0) {
	errno = EIO;		/* We don't know why, but */
	return (-1);		/* /bin/mkdir failed */
    }

    return (0);
}

