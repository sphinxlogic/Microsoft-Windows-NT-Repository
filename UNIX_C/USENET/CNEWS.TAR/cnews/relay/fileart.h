/* imports from fileart.c */
extern void filedebug();
extern void fileart();
