/*
 * print common messages
 */

#include <stdio.h>
#include <sys/types.h>
#include "news.h"
#include "headers.h"
#include "article.h"
#include "msgs.h"

void
fulldisk(art, file)		/* complain once & set ST_DISKFULL */
register struct article *art;
char *file;
{
	if (!(art->a_status&ST_DISKFULL))
		art->a_status |= prfulldisk(file);
}

statust
prfulldisk(file)		/* complain once & return bad status */
char *file;
{
	warning("error writing `%s', probably the disk filled", file);
	return ST_DISKFULL|ST_DROPPED;
}
