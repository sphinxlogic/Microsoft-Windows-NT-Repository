/*
 * definitions internal to the header modules (hdr*.c)
 */
#ifdef REALSTDC
#undef REALSTDC
#endif
#ifdef __STDC__
#if __STDC__ >= 1		/* microsoft, etc. brain-damage */
#define REALSTDC		/* truth in advertising: really ANSI */
#endif				/* __STDC__ < 1 */
#endif				/* __STDC__ */

#ifndef REALSTDC
#define const
#endif				/* REALSTDC */

#ifndef DEFDIST
#define DEFDIST "world"		/* default Distribution: */
#endif
#ifndef DEFMSGID
#define DEFMSGID "<message-id@absent>"
#endif

#define JUNK "junk"
#define ALL "all"

#ifdef SLOWCTLMATCH
#define OLDCNTRL "all.all.ctl"
#endif
#define SFXOLDCNTRL ".ctl"

struct hdrdef {
	const char *hdrnm;	/* ascii name */
	unsigned hdrlen;	/* STRLEN(hdrnm) */
	int hdroff;		/* offset into struct header */
};
typedef const struct hdrdef *hdrlist[];

extern const struct hdrdef pathhdr, xrefhdr;
extern const hdrlist parsehdrs, hdrvilest;

extern boolean headdebug;
