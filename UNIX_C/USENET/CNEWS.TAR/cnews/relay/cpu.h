/*
 * CPU-specific definitions
 */

#ifndef MAXLONG
#define MAXLONG ((long)(~(unsigned long)0 >> 1))
#endif
