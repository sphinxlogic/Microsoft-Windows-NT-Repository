/* imports from control.c */
extern void ctlmsg();
