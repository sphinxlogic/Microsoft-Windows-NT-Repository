/*
 * Usenet header common code.
 */

#include <stdio.h>
#include <sys/types.h>
#include "libc.h"
#include "news.h"
#include "headers.h"
#include "hdrint.h"

void
hdrdebug(state)
int state;
{
	headdebug = state;
}

void
hdrinit(hdrs)			/* zero all elements of hdrs */
register struct headers *hdrs;
{
	hdrs->h_subj = NULL;
	hdrs->h_ngs = NULL;
	hdrs->h_distr = NULL;
	hdrs->h_ctlcmd = NULL;
	hdrs->h_approved = NULL;
	hdrs->h_msgid = NULL;
	hdrs->h_artid = NULL;
	hdrs->h_expiry = NULL;
	hdrs->h_path = NULL;
	hdrs->h_sender = NULL;
}

boolean
oldctl(hdrs)			/* true iff ngs are OLDCNTRL (cache in hdrs) */
register struct headers *hdrs;
{
#ifdef SLOWCTLMATCH
	return ngmatch(OLDCNTRL, hdrs->h_ngs);
#else
	register int ngslen = strlen(hdrs->h_ngs);

	if (ngslen < STRLEN(SFXOLDCNTRL))	/* ngs too short */
		return NO;
	else					/* check for .ctl suffix */
		/*
		 * This is more general than RFC 850 specifies, but this
		 * generality seems harmless.  This doesn't work for e.g.
		 * x.y.ctl,z.q, which is a darn shame, but that's a violation
		 * of common sense.
		 */
		return STREQ(&hdrs->h_ngs[ngslen-STRLEN(SFXOLDCNTRL)],
			SFXOLDCNTRL);
#endif						/* SLOWCTLMATCH */
}

void
freeheaders(hdrs)		/* free (assumed) malloced storage */
register struct headers *hdrs;
{
	nnfree(&hdrs->h_subj);
	nnfree(&hdrs->h_ngs);
	nnfree(&hdrs->h_distr);
	nnfree(&hdrs->h_ctlcmd);
	nnfree(&hdrs->h_approved);
	nnfree(&hdrs->h_msgid);
	nnfree(&hdrs->h_artid);
	nnfree(&hdrs->h_expiry);
	nnfree(&hdrs->h_path);
	nnfree(&hdrs->h_sender);
}
