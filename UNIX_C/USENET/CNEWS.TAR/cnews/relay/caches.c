/*
 * cache control
 */

#include <stdio.h>
#include <sys/types.h>
#include "news.h"
#include "active.h"
#include "caches.h"
#include "transmit.h"

statust
loadcaches()				/* reload in-core caches from disk */
{
	return actload();
}

statust
synccaches()				/* force in-core caches to disk */
{
	return actsync() | trclose();
}
