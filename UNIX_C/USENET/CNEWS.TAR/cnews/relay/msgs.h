/* imports from msgs.c */
extern statust prfulldisk();
extern void fulldisk();
