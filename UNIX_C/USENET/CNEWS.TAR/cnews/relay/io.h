/* imports from io.c */
extern void nnfclose();
