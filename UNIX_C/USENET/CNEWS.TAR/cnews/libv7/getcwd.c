/*
 * SystemV getcwd simulation, courtesy peter honeyman
 */

#include <stdio.h>

/* imports from libc */
extern FILE *popen();
extern char *rindex();

char *
getcwd(path, size)
register char *path;
int size;
{
	register char *nlp;
	register FILE *fp;

	fp = popen("PATH=/bin:/usr/bin pwd", "r");
	if (fp == NULL)
		return 0;
	if (fgets(path, size, fp) == NULL) {
		(void) pclose(fp);
		return 0;
	}
	if ((nlp = rindex(path, '\n')) != NULL)
		*nlp = '\0';
	(void) pclose(fp);
	return path;
}
