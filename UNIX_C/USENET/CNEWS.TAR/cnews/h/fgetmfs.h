/* values for fgetmfs flag */
#define CONT_NO 0		/* no continuations */
#define CONT_NOSPC 1		/* continue & remove leading whitespace */
#define CONT_SPC 2		/* continue & keep leading whitespace */

extern char *fgetmfs();			/* internal interface */

/* external interfaces */
#define fgetms(fp) fgetmfs(fp, -1, CONT_NO)	/* unbounded read */
#define cfgetms(fp) fgetmfs(fp, -1, CONT_NOSPC)	/* unbounded read w continuation */
