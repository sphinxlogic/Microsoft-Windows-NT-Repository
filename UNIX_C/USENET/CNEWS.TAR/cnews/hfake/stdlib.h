/* ANSI (draft) definitions */

typedef struct {
	long quot, rem;
} ldiv_t;

extern ldiv_t ldiv();
