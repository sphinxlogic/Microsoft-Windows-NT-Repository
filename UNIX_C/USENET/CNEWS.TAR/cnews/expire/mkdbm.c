/*
 * mkdbm - rebuild dbm file for a history file
 *
 * History file on standard input; the dbm database is generated as
 * hist.dir and hist.pag.
 */
#include <stdio.h>
#include <string.h>
#include <ctype.h>

char buf[4096];			/* ought to be plenty */


char *progname = "mkdbm";
typedef struct { char *dptr; int dsize; } datum;

main()
{
	register char *scan;
	long place;
	datum lhs;
	datum rhs;
	register int ret;

	close(creat("hist.dir", 0666));
	close(creat("hist.pag", 0666));
	dbminit("hist");

	for (;;) {
		place = ftell(stdin);
		if (fgets(buf, sizeof(buf), stdin) == NULL)
			break;

		scan = strchr(buf, '\t');
		if (scan == NULL || buf[strlen(buf)-1] != '\n') {
			fprintf(stderr, "bad format: %s", buf);
			exit(1);
		}
		*scan = '\0';

		lhs.dptr = buf;
		lhs.dsize = strlen(buf) + 1;
		rhs.dptr = (char *)&place;
		rhs.dsize = sizeof place;
		ret = store(lhs, rhs);
		if (ret < 0)
			fprintf(stderr, "dbm failure '%s' @ %ld\n", buf, place);
	}
	exit(0);
}
