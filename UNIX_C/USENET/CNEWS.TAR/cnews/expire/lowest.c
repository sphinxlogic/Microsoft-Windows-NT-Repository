/*
 * lowest - print the number of the lowest article in a directory
 */

#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>

#define	HUGE	999999999L	/* Bigger than any valid article number. */

char *progname;

/*
 - main - parse arguments and handle options
 */
main(argc, argv)
int argc;
char *argv[];
{
	DIR *d;
	register struct dirent *dp;
	long lowest = HUGE;
	long this;
	extern long atol();

	progname = argv[0];

	if (argc != 2) {
		fprintf(stderr, "usage: %s directory\n", progname);
		exit(2);
	}

	d = opendir(argv[1]);
	if (d == NULL) {
		fprintf(stderr, "%s: can't read directory %s\n", progname,
								argv[1]);
		exit(1);
	}
	while ((dp = readdir(d)) != NULL) {
		if (strspn(dp->d_name, "0123456789") == strlen(dp->d_name)) {
			this = atol(dp->d_name);
			if (this < lowest)
				lowest = this;
		}
	}
	closedir(d);

	if (lowest != HUGE)
		printf("%ld\n", lowest);
}
