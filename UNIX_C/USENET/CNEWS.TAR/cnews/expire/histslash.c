/*
 * Convert slashed filenames to dotted group/article names in a history
 * file, for use in mkhistory.  Input comes only from stdin.
 */
#include <stdio.h>
#include <assert.h>

char *progname = "histslash";

char buf[4096];			/* paranoia -- ought to be lots */

main()
{
	register char *scan;
	register char *last;
	extern char *strchr();

	while (fgets(buf, sizeof(buf), stdin) != NULL) {
		scan = strchr(buf, '\t');
		scan = strchr(scan+1, '\t');
		scan++;
		last = NULL;
		while (*scan != '\0') {
			if (*scan == '/') {
				*scan = '.';
				last = scan;
			}
			if (*scan == ' ' || *scan == '\n') {
				assert(last != NULL);
				*last = '/';
			}
			scan++;
		}
		fputs(buf, stdout);
	}
}
