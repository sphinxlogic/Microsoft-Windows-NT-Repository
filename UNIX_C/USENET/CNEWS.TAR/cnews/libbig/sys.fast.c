/*
 * news sys file reading functions (fast, big, in-memory version)
 */

#include <stdio.h>
#include <sys/types.h>
#include "news.h"
#include "system.h"

/* imports */
extern struct system *currsys, *firstsys;

/* exports */
boolean justone = NO;

/* private */
static struct system *thissys = NULL;

/* ARGSUSED */
void
rewsys(fp)
FILE *fp;
{
	currsys = firstsys;
}

struct system *
mysysincache()				/* optimisation */
{
	return thissys;
}

void
remmysys(sys)				/* remember this system */
struct system *sys;
{
	thissys = sys;
}

void
freecurrsys()
{
	/* never free sys entries */
}
