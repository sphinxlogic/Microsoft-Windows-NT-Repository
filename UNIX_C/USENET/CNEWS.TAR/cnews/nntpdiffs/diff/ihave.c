46c46,52
< 	retcode = spawn(rnews, "rnews", (char *) 0, CONT_XFER, ERR_XFERFAIL, errbuf);
---
> #ifdef UNBATCHED_INPUT
> 	retcode = spawn(rnews, "rnews", (char *) 0, CONT_XFER,
> 		ERR_XFERFAIL, errbuf);
> #else
> 	/* C news input hook */
> 	retcode = batch_input_article(CONT_XFER, ERR_XFERFAIL, errbuf);
> #endif
