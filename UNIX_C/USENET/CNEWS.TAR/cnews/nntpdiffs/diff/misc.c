85d84
<  *			Converts "msg_id" to lower case.
118,121d116
< 
< 	for (cp = msg_id; *cp != '\0'; ++cp)
< 		if (isupper(*cp))
< 			*cp = tolower(*cp);
