239a240,242
> #ifndef UNBATCHED_INPUT
> 	{
> 		char errbuf[2 * NNTP_STRLEN];
240a244,246
> 		enqpartbatch(CONT_XFER, ERR_XFERFAIL, errbuf);
> 	}
> #endif
241a248
> 
290d296
< 
