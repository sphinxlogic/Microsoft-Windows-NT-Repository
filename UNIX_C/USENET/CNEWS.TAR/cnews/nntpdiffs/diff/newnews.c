258c258
< seekuntil(fp, key, line, linesize)
---
> seekuntil(fp, akey, line, linesize)
260c260
< 	char		*key;
---
> 	char		*akey;
266a267,268
> 	extern long dtol();
> 	char key[30];
267a270
> 	(void) sprintf(key, "%ld", dtol(akey));	/* akey -> time_t in ascii */
329a333,335
> /*
>  * C news version of getword.
>  */
336a343
> 	extern char *index();
340,366c347,359
< 	if (cp = index(line, '\t')) {
< /*
<  * The following gross hack is present because the history file date
<  * format is braindamaged.  They like "mm/dd/yy hh:mm", which is useless
<  * for relative comparisons of dates using something like atoi() or
<  * strcmp.  So, this changes their format into yymmddhhmm.  Sigh.
<  *
<  * 12345678901234	("x" for cp[x])
<  * mm/dd/yy hh:mm 	(their lousy representation)
<  * yymmddhhmm		(our good one)
<  * 0123456789		("x" for w[x])
<  */
< 		*cp = '\0';
< 		(void) strncpy(w, cp+1, 15);
< 		w[0] = cp[7];		/* Years */
< 		w[1] = cp[8];
< 		w[2] = cp[1];		/* Months */
< 		w[3] = cp[2];
< 		w[4] = cp[4];		/* Days */
< 		w[5] = cp[5];
< 		w[6] = cp[10];		/* Hours */
< 		w[7] = cp[11];
< 		w[8] = cp[13];		/* Minutes */
< 		w[9] = cp[14];
< 		w[10] = '\0';
< 	} else
< 		w[0] = '\0';
---
> 	w[0] = '\0';				/* in case of bad format */
> 	if (cp = index(line, '\t')) {		/* find 2nd field */
> 		register char *endp;
> 
> 		*cp++ = '\0';
> 		endp = index(cp, '~');		/* end of date-received */
> 		if (endp == NULL)
> 			endp = index(cp, '\t');	/* end of expiry */
> 		if (endp != NULL) {
> 			(void) strncpy(w, cp, endp - cp);
> 			w[endp - cp] = '\0';
> 		}
> 	}
