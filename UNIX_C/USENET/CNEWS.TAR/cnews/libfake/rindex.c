/*
 * rindex - find last occurrence of a character in a string
 */

#define	NULL	0

char *				/* found char, or NULL if none */
rindex(s, charwanted)
char *s;
char charwanted;
{
	extern char *strrchr();

	return(strrchr(s, charwanted));
}
