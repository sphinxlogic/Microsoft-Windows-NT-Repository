/*
 * ANSI's ldiv(num, denom) - yields (num/denom, num%denom)
 */

#include <stdlib.h>

ldiv_t
ldiv(num, denom)
register long num, denom;
{
	register ldiv_t result;

	result.quot = num/denom;
	result.rem = num%denom;
	return result;
}
