/*
 * news sys file reading functions (slow, small, on-disk version)
 */

#include <stdio.h>
#include <sys/types.h>
#include "news.h"
#include "system.h"

/* exports */
boolean justone = YES;

/* imports */
extern struct system *currsys, *firstsys;

struct system *
mysysincache()
{
	return NULL;
}

void
remmysys(sys)
struct system *sys;
{
	/* no cache */
}

void
rewsys(fp)
FILE *fp;
{
	if (fp != NULL)
		(void) rewind(fp);
}

/*
 * Free current sys entry & associated memory.  Zero currsys too.
 */
void
freecurrsys()
{
	if (currsys == NULL)
		return;
	nnfree(&currsys->sy_name);
	nnfree(&currsys->sy_ngs);
	nnfree(&currsys->sy_cmd);
	nnafree(&currsys);
}
