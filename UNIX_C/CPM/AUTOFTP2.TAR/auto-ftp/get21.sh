
# Do NOT run this program before you have read all of the following 
#    comments that contain important instructions!
#
# The comments consist of three parts:
#    * Note edited by Mingqi Deng for preparation additional to the
#      original get20
#    * written Ferd Brundick, the original author of get20.
#    * new feature with get21
#--------------------------------------------------------------------------
# This file is save as 'get21.sh'
#
# Shell proc 'get21.sh' UNATTENDANTLY transfers a file from simtel20 to a 
# UNIX machine with a Bourne shell (not C shell).
#
# In order to for you to run this program on your machine, 
#  1) adjust the following shell vairables in this file (line 63-74):
#         ALARM, SLEEP, _Behead, _pid, LocalHost
#  2) compile the two C programs: behead.c and pid.c inclued in the
#     shell archive.
#
# Output:
#  1) files you requested if nothing abnormal (see 2), and 
#  2) files msgXXXXX where XXXXX stands for a process ID (those shown 
#     by 'ps' command) that contain the message as to whether the transfer 
#     was successful ('get21.sh' fails only if (1) the file names are 
#     wrong; (2) the file being transfered is too large with respect to 
#     the value of the shell variable ALARM; increase it if this 
#     happens (3600 is proper), (3) the communication line went down 
#     without notice.
#  3) if the user does not have a .netrc (auto-ftp-login) file in his home
#     directory, one will be created for him.
#  4) Several working files will be automatically created when running 
#     get21.sh. They are files of names stderrXXXX, tmpXXXXX where XXXX 
#     are unique process ID's. They will be erased automatically if the
#     shell process 'get21.sh  ....' is killed by a user or the
#     communication line went silent. In either case, the user can delete
#     them manually.
#
# sample usage lines (refer to F. Brundick's note for modes): 
#   sh get21.sh -b pd2 cpm.modem7 mdm724.com
#   get21.sh  -b pd2 cpm.modem7 mdm724.com
#   get21.sh  -8 pd2 cpmug.vol042 resource.com resorc &
#   get21.sh  -8 pd2 sigm.vol165 nddt.doc
#
# To run it with multiple files, refer to the sample shell program
# run.sh in this package.
#
###########################################################################
#
#   written by  : Ferd Brundick
#   date written: some time in 1983
#   modification: 22 March 84
#     1. ftp modes are referred to as "ascii, binary, and tenex"
#	  but the ftp command "type xx" MAY be used instead because
#	  some ftp routines do not recognize the commands
#	  "ascii, binary, and tenex".  These may be changed after
#	  the comment that reads "define ftp mode commands".
#     2. The path to the ITS-format header stripper (behead) must be
#        stored in the variable "_Behead".  Whenever a file is
#        transferred in tenex mode, behead will be called automatically.
#        (behead.c is included with the shell archive)
#     3. The option -8 is idential to -t for tenex (36->8) transfers.
#     4. Both parts of the directory name must be given (see examples).
#     5. Remote host name now is stored in the variable "RemoteHost".
#     6. Local host name now is stored in the variable "LocalHost" for
#	  remote login usage because the remote host would like the
#	  local host name for password.  Be sure to insert your local
#	  host name after the comment line "define host names".
###########################################################################
#   Reviced by : Mingqi Deng,  Jan. 12, 1989
#     1. Unlike Get20, Get21 will not give up when connection is refused
#        or disrupted. Therefore the users will be relieved from
#        the frustration of running it over and over again for a good
#        connection.
#     2. To get out from a silent connection, there is a time out for each
#        connection. The default is one hour. For large files or slow 
#        commicication lines, the user is adviced to increase the value.
#     3. A separate shell program sample is included for transfering
#        multiple files from simtel20. (cf. run.sh)

# An ftp try will be aborted after ALARM many seconds.
ALARM=3600
# Try FTP into simtel20 every SLEEP seconds untill being connected
SLEEP=60

# define the full path names to specify where the behead and pid you 
# compiled are, eg. _Behead="/usr/usr/george/bin/behead"
_Behead=
_pid=

# define host names
RemoteHost="simtel20.arpa"     # .arpa suffixed is recent ARPANET change
LocalHost=                     # put your local host name here

exec 1>tmpmsg$$ 2>stderr$$

# define ftp mode commands
ascii="ascii"			    # 7-bit ASCII transfer
binary="binary" 		    # 8-bit binary image transfer
tenex="tenex"			    # 36 to 8-bit ITS format transfer
#"type L 8", "type local" or "type local byte" may be needed in place of 
# "tenex".  Do a "man ftp" to see how your system wants it.

# default mode is ascii
Mode=ascii

# check and extract options
    case $1 in
	-a) Mode=ascii
	    shift;;
	-b) Mode=binary
	    shift;;
     -[t8]) Mode=tenex
	    shift;;
	-*) echo "Unknown option -> $i"
	    echo 'get20 aborted'
	    exit 1;;
	 *) break;;
    esac

# check and store arguments
case $# in
    3)	RemoteFile="$1:<$2>$3"
	LocalFile=$3 ;;
    4)	RemoteFile="$1:<$2>$3"
	LocalFile=$4;;
    *)	echo 'Usage: get21.sh [-a|b|8] pd_no dir_name file_name [local_file_name]'
	echo 'get21.sh aborted'
	exit 1;;
esac

# block out interruptions
mesg n

# create ".netrc" (auto-login) file if one does not exist (or is empty)
# cf netrc by 'man netrc'
login_file=$HOME/.netrc
test -s $login_file ||
{
echo "machine $RemoteHost login anonymous password $LocalHost" >$login_file
    chmod 600 $login_file		# file MUST have 0600 permissions
}

# create ftp command file
case $Mode in
     ascii) Type="$ascii";;
    binary) Type="$binary";;
     tenex) Type="$tenex";;
esac
echo "$Type
verbose
get $RemoteFile $LocalFile
bye" >ftp.get.$$

# trap aborts
trap 'rm tmp$$ tmp0$$ tmp1$$ ftp.get.$$; exit 7 ' 2 3

# perform file transfer
echo "$RemoteFile will be copied with"
echo "            $Mode mode to $LocalFile"

# save messages
cat  tmpmsg$$  > msg$$
cat  stderr$$  >>msg$$

#initilize the loop
echo $junk >tmp$$

while test -s tmp$$
do

  > stderr$$
  > tmpmsg$$

# Create two sub-shell processes, one for FTP, one for time-out.
# Each sub shell has two parts. If the first part is succeeded, a KILL
# action will be taken to abort either the TIME-OUT or the FTP process.

  { ftp "$RemoteHost" <ftp.get.$$ &&
    { ps -x > tmp0$$; grep sleep tmp0$$ > tmp$$; 
      pd=`$_pid < tmp$$`; kill -9 $pd ; 
    }
  } & {
    sleep $ALARM &&
    { ps -x > tmp0$$; grep ftp tmp0$$ > tmp$$; 
      pd=`$_pid < tmp$$`; kill -9 $pd ; 
    }
  }

  cat tmpmsg$$ stderr$$ > tmp0$$

# to avoid infinite loop due to wrong file names
  grep "Invalid use of terminal designator" tmp0$$ > tmp$$
  if test -s tmp1$$
  then echo "FIle $RemoteFile not found!"
       break
  fi

# Error checking
  grep refused          tmp0$$ > tmp$$
  grep unreachable      tmp0$$ >> tmp$$
  grep "Not connected"  tmp0$$ >> tmp$$
  grep "timed out"      tmp0$$ >> tmp$$
  grep "not accessable" tmp0$$ >> tmp$$
  grep "not available"  tmp0$$ >> tmp$$
  grep "failed"         tmp0$$ >> tmp$$
  if test -s tmp$$ 
  then sleep $SLEEP 
  fi

done

cat tmpmsg$$ stderr$$  >> msg$$

rm ftp.get.$$ tmp*$$ stderr$$   #remove ftp command and working files

echo 'file transfer completed'

# remove ITS header bytes if transfer was done in tenex mode
if test $Mode = tenex
    then if $_Behead $LocalFile 2>/dev/null
	    then echo 'ITS header bytes removed'
	 fi
fi

# restore communications
mesg y
exit 0
echo shar: "3 control characters may be missing from 'get21.sh'"
echo shar: "3 control characters may be missing from 'get21.sh'"
echo shar: "3 control characters may be missing from 'get21.sh'"
