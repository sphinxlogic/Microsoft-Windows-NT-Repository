
# To run this program (saved as 'run.sh'), type 'sh run.sh'
#  The argumets 2-4/5 to 'set' are in accordance with 'get21'.

set - -a PD1 MSDOS.MEMACS EM38LFIX.MSG	
get21.sh $1 $2 $3 $4
set - -8 PD1 MSDOS.MEMACS EM39DOC.ARC.1 EMDOC.ARC
get21.sh $1 $2 $3 $4 $5
set - -8 PD1 MSDOS.MEMACS EM39EXE.ARC		
get21.sh $1 $2 $3 $4
set - -8 PD1 MSDOS.MEMACS EM39SPEL.ARC.1
get21.sh $1 $2 $3 $4
