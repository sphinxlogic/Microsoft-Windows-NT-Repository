/* used in get.sh to kill a process */

#include <stdio.h>

main()
{ int i;
  char *c, s[80];

  c=gets(s);
  if (c != NULL) for (i=0;i<5;i++) putchar(s[i]);
}
