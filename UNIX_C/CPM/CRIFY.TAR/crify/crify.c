/*
 *   crify.c  --  add cr's for cp/m sqeezed files 
 *
 *   syntax:
 *        crify  <oldfile >newfile
 */

#include <stdio.h>

main()
{
	register char c;

	while ( (c = getchar()) != EOF) {
		if (c == '\n') 
			putchar('\r');
		putchar(c);
	}
}

