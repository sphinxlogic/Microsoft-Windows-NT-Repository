#define	VERSION		0
#define REVISION	0
#define MOD_DATE	"04/18/85"

/* This program will type a member of a LBR file... any member,
   BUT anything other than an ASCII file will produce a screenful
   of garbage.

   USE: LTYPE <library> <member>
*/
#include <stdio.h>
#include <sys/file.h>

char curdsk, fcb[36];
char fnam[12], libnam[16], dirbuf[128], *dirp;
int  fd, dirsiz, filsiz;

#define OK	0
#define ERROR -1

main(argc,argv)
int argc;
char **argv;
{
	printf("\n\rLTYPE vers:%d.%02d  %s\n\r\n",
	VERSION,REVISION,MOD_DATE);
	opnlib(argv[1]);
	if (fndmem(argv[2]) == ERROR) erxit("\n\rMember not in LBR file!\n\r");
	printf("\n\rFile present - %d sectors.\n\r",filsiz);
	doit();
}

doit()
{
	int	j;
	int	c;
	dirsiz = filsiz;
	do {
		reload();
		for (j=0; j<128; j++){
			if (*dirp == 0x1a) exit();
			putchar(*dirp);
			if(*dirp == 0x0a) putchar(0x0d);
			dirp++;
		}
	}while(dirsiz != 0);
}

opnlib(file)
char *file;
{
	char l, *npnt;
	strcpy(libnam,file);
	fd = open(libnam,O_RDONLY);
	if(fd == -1) erxit("Library file not found.\n");
}

fndmem(file)
char *file;
{
	char dnam[16], fname[36];
	long int	floc;
	setfcb(fname,file);
	read(fd,dirbuf,128);
	dirp = dirbuf;
	dirsiz = *(dirp+14);
	dirp += 32;
	do{
		if (*dirp == 255) return(ERROR);
		if (*dirp == 0){
			strcpy(dnam, dirp+1);
			dnam[11]=0;
			if(strcmp(dnam, fname) == 0){
				filsiz = (*(dirp+14)) + ((*(dirp+15)) * 256);
				floc=(*(dirp+12)) + ((*(dirp+13)) * 256);
				lseek(fd,floc *128,0);
				return(OK);
			}
		}
		dirp += 32;
		if(dirp > dirbuf+128) reload();
	} while(dirsiz);
	return(ERROR);
}

reload()
{
	read(fd,dirbuf,128);
	dirp = dirbuf;
	dirsiz--;
}

matchr(st,ch)
char *st,ch;
{
	int i;
	for(i=0; st[i]; i++){
		if(st[i] == ch) return(i);
	}
	return(0);
}

setfcb(fname,file)
char *fname;
char *file;
{
	int i,j;
	i = 0; j = 0;
	while (file[j] && file[j] != '.' && i < 8) fname[i++] = file[j++];
	while (i < 8) fname[i++] = ' ';
	if (file[j] == '.') while (i < 11 && file[++j]) fname[i++] = file[j];
	while (i < 11) fname[i++] = ' ';
	fname[11] = 0;
}

erxit(strg)
char *strg;
{
	printf(strg);
	exit();
}
