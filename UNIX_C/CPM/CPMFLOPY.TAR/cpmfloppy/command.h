/*	command.h	1.5	83/05/13	*/
/*
 * Symbolic names for command indices
 */

#define	CMD_DIR		1
#define	CMD_RENAME	2
#define	CMD_ICOPY	3
#define	CMD_DELETE	4
#define	CMD_ERASE	5
#define	CMD_EXIT	6
#define	CMD_TYPE	7
#define	CMD_HELP	8
#define	CMD_LS		9
#define	CMD_LOGOUT	10
#define	CMD_ICCOPY	11
#define	CMD_OCCOPY	12
#define	CMD_OCOPY	13
#define	CMD_DUMP	14

