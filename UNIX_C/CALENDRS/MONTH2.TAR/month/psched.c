#include <curses.h>
#include "month.h"


/*

   My attempt to write a routine that will print out the schedule for 
   the day, i.e., 

               8:45 - 9:45  Foo Bar Baz

   and so on...

*/

psched()
{
	short i, shour, sminute, ehour, eminute, n;
	struct event_rec *events_today[MAX_DAILY_EVENTS];

	get_daily_events(events_today);
       for ( n = 0; events_today[n]; n++);
       sort_events(events_today,n);
        
       clear();
       move(0,0);
       i = 0;
      	while (events_today[i]) {

		shour = events_today[i]->hour;
		sminute = events_today[i]->minute;
               ehour = shour + (events_today[i]->duration_hours);
               eminute = sminute + (events_today[i]->duration_minutes);

               printw("%2d:%02d%2s-%2d:%02d%2s ",(shour <= 12) ? shour : (shour % 12),sminute,
                      ((shour < 12) ? "AM" : "PM"),  
                      (ehour <= 12) ? ehour : (ehour % 12),eminute,
                      ((ehour < 12) ? "AM" : "PM"));
               printw("%s\n", events_today[i]->event_string);

		i++;
	}
       refresh();
       get_char();
	clear();
	print_screen();
}

psched2()
{
	short i, shour, sminute, ehour, eminute, n;
	struct event_rec *events_today[MAX_DAILY_EVENTS];

	get_daily_events(events_today);
       for ( n = 0; events_today[n]; n++);
       sort_events(events_today,n);
        
       i = 0;
      	while (events_today[i]) {

		shour = events_today[i]->hour;
		sminute = events_today[i]->minute;
               ehour = shour + (events_today[i]->duration_hours);
               eminute = sminute + (events_today[i]->duration_minutes);

               printf("%2d:%02d%2s-%2d:%02d%2s ",(shour <= 12) ? shour : (shour % 12),sminute,
                      ((shour < 12) ? "AM" : "PM"),  
                      (ehour <= 12) ? ehour : (ehour % 12),eminute,
                      ((ehour < 12) ? "AM" : "PM"));
               printf("%s\n", events_today[i]->event_string);

		i++;
	}
}
