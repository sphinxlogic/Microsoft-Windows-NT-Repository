This is a public-domain reimplementation of the Unix "cal" calendar program.
The inner-loop -- that puts a date into the calendar -- was designed
for eventual rewriting in LaTeX (but I haven't gotten that working yet).

If you aren't interested in Julian/Gregorian hacks, the code can
be considerably simplified.

Happy New Year.

Martin Minow
decvax!minow
