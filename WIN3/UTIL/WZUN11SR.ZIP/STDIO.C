#include <sys\types.h>
#include <sys\stat.h>
#include <time.h>                
#include <string.h>             
#include <windows.h>    /* required for all Windows applications */
#include "winunzip.h"                /* specific to this program              */

/* Standard IO
 */
int printf(char *format, ...)
{
}

int fprintf(unsigned int file, char *format, ...)
{
}

int perror(char *parm1, char *parm2)
{
}
