#include <windows.h>

int FAR PASCAL LibMain(HANDLE hInst, WORD wDS, WORD wHS, LPSTR lpszCmd)
{
  if (wHS > 0) UnlockData(0);
  return(1);
}

int FAR PASCAL WEP(int nParam) { return(1); }

