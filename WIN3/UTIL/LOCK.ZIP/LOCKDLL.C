#include <windows.h>
#pragma argsused
FARPROC prevhook;
int top,bottom,left,right;

int FAR PASCAL LibMain(hInstance,wDataSeg,cbHeapSize,lpszCmdLine)
HANDLE hInstance;
WORD wDataSeg;
WORD cbHeapSize;
LPSTR lpszCmdLine;
{
 return 1;
}

int FAR PASCAL WEP(int nParam)
{
 return 1;
}

void FAR PASCAL TransitHook(FARPROC a)
{
 prevhook=a;
}

void FAR PASCAL TransitCoor(int a,int b,int c,int d)
{
 top=a; bottom=b;
 left=c; right=d;
}

void FAR PASCAL MyHookEr(int nCode,WORD wParam,DWORD lParam)
{
 MSG *p;

 if (nCode>=0)
 {
  p=(MSG *)lParam;
  switch(p->message)
  {
   case WM_SYSCOMMAND:
   case WM_SYSKEYUP:
   case WM_SYSKEYDOWN:
    p->message=WM_NULL;
   break;
   default:DefHookProc(nCode,wParam,lParam,&prevhook);
  }
 }
 else
 DefHookProc(nCode,wParam,lParam,&prevhook);
}
