/*
   CICA2DB - Create a database importable file from cica's win3 index

    Author:         Hans van Oostrom
                    hans@pine.circa.ufl.edu  INTERNET
                    hans@ufpine              BITNET

    Date:           May 19, 1992

    Version:        1.2

    Modifications:  Updated the program because of a change of format of the
					index file.
					Once again fix changes to th index file.

    Status:         Public Domain
                    You need not to send any money to use this, it's
                    absolutely free.  Also the source code is provided, so
                    make all the modifications you want. If you like it you
                    can let me know if you want to.


    Compiled with Borland C++ 3.00, also compatible with MSC 5.1

*/

#include <stdio.h>
#include <string.h>

#define TRUE	1
#define FALSE	0

/*** parse the filename and description ************************************/
int ParseFile(char *line)
{
    char temp[80];
    int i=1;
    char *tp=temp;
    
    if (strlen(line)<5) 
    {
        line[0]='\0';
        return 0;
    }
    
    strcpy(temp,line);
    line[0] = '\"';
    while (!isspace(*tp))
    {
        line[i++]=*tp;
        ++tp;
    }
    line[i++] = '\"';
    line[i++] = ',';
    line[i++] = '\"';
    
    while (isspace(*tp)) ++tp;

    while (!isspace(*tp))
    {
        line[i++]=*tp;
        ++tp;
    }
    line[i++] = '\"';
    line[i++] = ',';
    line[i++] = '\"';
    
    while (isspace(*tp)) ++tp;
    
    while (*tp!='\n')
    {
        line[i++]=*tp;
        ++tp;
    }
    line[i++] = '\"';
    line[i++] = '\0';
    
    return 0;
}
    

/*** parse the directory name.  Starts with win3\ **************************/
int ParseDir(char *line)
{
    char temp[80];
    int i=1;
    char *tp=temp;
    
    if (strlen(line)<5) 
    {
        line[0]='\0';
        return 0;
    }
    
    strcpy(temp,line);
    tp = strstr(tp, "win3" );
    if (tp==NULL)
    {
        line[0]='\0';
        return 0;
    }
    line[0] = '\"';


    while ((*tp!='\n') && (*tp!=' '))	/* check for space and CR */
    {
        line[i++]=*tp;
        ++tp;
    }
    line[i++] = '\"';
    line[i++] = '\0';
    
    return 0;
}


/*** main program entry point *********************************************/
void main(int argc, char *argv[])
{
    char line[80];
    char dir[80];
    FILE *in;
    FILE *out;
    char inname[80];
    char outname[80];
    int i;  
	char star;    

    printf( "CICA2DB - Index to database converter\n");
    printf( "      Version 1.2,  May 19, 1992\n" );
    printf( "        by Hans van Oostrom\n" );
    printf( "      hans@pine.circa.ufl.edu\n\n");

    switch(argc)                        /* handle command line parameters */
    {
        case 1:
            printf( "Input name:  " );
            gets( inname );
            printf( "Output name: ");
            gets( outname );
            break;
        case 2:
            strcpy(inname, argv[1]);
            printf( "Output name: ");
            gets( outname );
            break;
        case 3:
            strcpy(inname, argv[1]);
            strcpy(outname, argv[2]);
            break;
        default:
            printf( "Usage: %s <inputfile> <outputfile>\n", argv[0] );
            exit(1);
    }

    if ((in=fopen(inname, "r"))==NULL)
    {
        printf( "Error opening file: %s\n", inname );
        exit(2);
    }
    if ((out=fopen(outname, "w"))==NULL)
    {
        printf( "Error opening file: %s\n", outname );
        exit(2);
    }
    
    fgets(line, 80, in);
    while (!feof(in))
    {
        if (fgets( line, 80, in )==NULL) break;

        switch(line[0])
        {
            case '\n':
            case ' ':
                break;
            case '*':
				if (star) break;
                ParseDir(line);
                if (line[0]!='\0') 
				{
					star=TRUE;
					strcpy(dir, line);
				}
                break;
            default:
				star = FALSE;
                ParseFile(line);
                if (line[0] != 0)
                    fprintf( out, "%s,%s\n", dir, line );
                break;
        }
    }   
    fclose(in);
    fclose(out);
	printf( "Conversion complete.\n" );
}
        