#include <stdio.h>

void main()
{
   int n;
   float a=-2.19, b=0.95;

   printf("\n\n");
   for (n=0; n<=5; ++n)  printf("%G\n", ((5-n)/5.0)*a + (n/5.0)*b);
}