#include <windows.h>
#include <dos.h>
#include <memory.h>
#include <direct.h>
#include <wfext.h>

/*

DRTRASH

This program is intended for use with Dropper, a desktop manager.
You can leave it on the desktop, ready for activation.  It allows
you to delete files by dragging them onto this icon instead of having
to have a program running.

This program is Copyright 1993 by David C. Elliott.   It's freeware,
not shareware, and anyone can use or distribute it as long as they
don't sell it.

*/

#define WM_FILESYSCHANGE	0x034

BOOL Interactive = FALSE;

static void
about()
{
	MessageBox(NULL, "DropTrash\nCopyright 1993 David C. Elliott", "About DropTrash", MB_OK);
}

static void
removeFile(LPSTR name)
{
	OFSTRUCT ofs;

	_dos_setfileattr(name, _A_NORMAL);
	OpenFile(name, &ofs, OF_DELETE);
}

static void
removeDir(LPSTR name)
{
	struct _find_t info;
	unsigned nomore;
	
	if (_chdir(name) == -1) {
		return;
	}

	// Delete files

	nomore = _dos_findfirst("*.*", _A_RDONLY | _A_HIDDEN | _A_SYSTEM,
		&info);
	while (!nomore) {
		// MessageBox(NULL, info.name, "Delete file", MB_OK);
		removeFile(info.name);
		nomore = _dos_findnext(&info);
	}

	// Delete subdirectories

	nomore = _dos_findfirst("*.*", _A_SUBDIR, &info);
	while (!nomore) {
		if (info.attrib & _A_SUBDIR &&
		    lstrcmp(info.name, ".") != 0 &&
		    lstrcmp(info.name, "..") != 0) {
			// MessageBox(NULL, info.name, "Remove subdirectory", MB_OK);
			removeDir(info.name);
		}
		nomore = _dos_findnext(&info);
	}

	// Get rid of the directory
	
	_chdir("..");
	_rmdir(name);
}

int PASCAL WinMain(HANDLE hInstance,
		   HANDLE hPrevInstance,
		   LPSTR  lpszCmdLine,
		   int    nCmdShow)
{
	LPSTR cp, lcp;
	char chr;
	BOOL del = TRUE;
	unsigned attrib;
	BOOL dirs = FALSE;
	
	if (lpszCmdLine == NULL || *lpszCmdLine == '\0') {
		about();
		return 0;
	}
	
	if (GetKeyState(VK_CONTROL) & 0x8000) {
		Interactive = TRUE;
	}

	cp = lpszCmdLine;
	if ((*cp == '-' || *cp == '/') &&
		(*(cp + 1) == 'i' || *(cp + 1) == 'I')) {
		cp += 2;
		Interactive = TRUE;
	}
	while (*cp == ' ') {
		cp++;
	}
	for ( ; ; ) {
		lcp = cp;
		while (*cp && *cp != ' ') {
			cp++;
		}
		chr = *cp;
		*cp = '\0';
		if (Interactive) {
			switch (MessageBox(NULL, (LPSTR)lcp, "Delete file",
								MB_YESNOCANCEL | MB_ICONQUESTION)) {

			case IDYES:
				del = TRUE;
				break;

			case IDNO:
				del = FALSE;
				break;

			case IDCANCEL:
				return 0;

			}
		}
		if (del) {
			_dos_getfileattr(lcp, &attrib);
			if (attrib & _A_SUBDIR) {
				dirs = TRUE;
				removeDir(lcp);
			} else {
				removeFile(lcp);
			}
		}
		if (chr == '\0') {
			break;
		}
		cp++;
		while (*cp == ' ') {
			cp++;
		}
		if (*cp == '\0') {
			break;
		}
	}

	
#ifdef WM_FILESYSCHANGE
	SendMessage(HWND_BROADCAST, WM_FILESYSCHANGE, 0, 0);
#else
	// You're on your own
#endif
	SendMessage(HWND_BROADCAST, FM_REFRESH_WINDOWS, 0, 0);

    return 0;

} /*  End of WinMain                                                    */

