#include <Interviews\defs.h>

int min (int a, int b) { return a < b ? a : b; }
float min (float a, float b) { return a < b ? a : b; }
double min (double a, double b) { return a < b ? a : b; }

int max (int a, int b) { return a > b ? a : b; }
float max (float a, float b) { return a > b ? a : b; }
double max (double a, double b) { return a > b ? a : b; }

int round (double x) { return x > 0 ? int(x+0.5) : -int(-x+0.5); }

