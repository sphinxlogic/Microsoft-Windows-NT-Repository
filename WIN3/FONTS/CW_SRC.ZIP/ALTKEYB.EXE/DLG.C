#define		NOVIRTUALKEYCODES
#define		NOMINMAX
#include	"c:\windev\include\windows.h"

#include	"hello.h"
#include	"c:\windev\include\string.h"
#include	"c:\windev\include\stdlib.h"

extern	HANDLE	hInst;
extern	HWND	hMainWnd;
extern	HWND	hMainDlg;
extern  int	bLAT;
extern  char 	szAppName[];
extern  int     wasEdited;

char sk[]= "SKEYB";
char lk[]= "LKEYB";
char de[]= ".kbd";
FARPROC lpDlgProc;

BOOL FAR PASCAL kDlg();
BOOL FAR PASCAL lDlg();

void FAR PASCAL LTable(LPSTR);
void 		SetKeys();
int		filopen(PSTR, WORD);
int		filwrite(int);
int		filread(int);


#define 	KTABLESIZE	(72*4)
extern char	kTable[KTABLESIZE];

char vk_t[]= {
VK_OEM_1,VK_OEM_PLUS,VK_OEM_COMMA,VK_OEM_MINUS,VK_OEM_PERIOD,VK_OEM_2,VK_OEM_3,
VK_OEM_4,VK_OEM_5,VK_OEM_6,VK_OEM_7,VK_OEM_8,

VK_0		,VK_1		,VK_2		,VK_3		,VK_4		,VK_5		,
VK_6		,VK_7		,VK_8		,VK_9		,
VK_A		,VK_B		,VK_C		,VK_D		,VK_E		,VK_F		,
VK_G		,VK_H		,VK_I		,VK_J		,VK_K		,VK_L		,
VK_M		,VK_N		,VK_O		,VK_P		,VK_Q		,VK_R		,
VK_S		,VK_T		,VK_U		,VK_V		,VK_W		,VK_X		,
VK_Y		,VK_Z		,0
};

char vk_names[]= {
';', '=', ',', '-', '.', '/', '`',
'[', '\\', ']', '\'', '?',

'0', '1', '2', '3', '4', '5',
'6', '7', '8', '9',
'A', 'B', 'C', 'D', 'E', 'F',
'G', 'H', 'I', 'J', 'K', 'L',
'M', 'N', 'O', 'P', 'Q', 'R',
'S', 'T', 'U', 'V', 'W', 'X',
'Y', 'Z', '?' };

char buff[3]= { 0, 0, 0 };
extern HWND hkDlg= NULL;

void
KeybSet		(void)
{
	lpDlgProc= MakeProcInstance(kDlg, hInst);
	DialogBox(hInst, (LPSTR)sk, hMainWnd, lpDlgProc);
	hMainDlg= hkDlg= NULL;
	FreeProcInstance(lpDlgProc);
}

char		w_path[132];
char		s_path[256];
char 		l_name[13]= "cyrillic.kbd";

int	bNoTrs= 0;
int	FAR PASCAL EnumFunc (LPLOGFONT, LPTEXTMETRIC, short, LPSTR);
BOOL	FAR PASCAL SelectFont (HWND, unsigned, WORD, LONG);
int	_lstrlen (LPSTR);
void	_lstrncpy (LPSTR, LPSTR, int);
void	_lstrcpy (LPSTR, LPSTR);
BOOL	bChanged= FALSE;

#define	MAXSIZE		20
#define	MAXFONT		20

extern	char FontList [MAXFONT][32];
extern	char SizeList [MAXSIZE];
extern	BYTE CharSet[MAXFONT];
extern	BYTE PitchAndFamily[MAXFONT];
extern	int FontIndex;
extern	int SizeIndex;
extern	int CurrentFont;
extern	int CurrentSize;
extern	char szFont[];

HFONT	hFont= NULL;

int shiftstate= 0;
int	v= VK_Q;
char vasc;
int vtb;

int	dstate= 0;

BOOL FAR PASCAL
lDlg		(hDlg, message, wParam, lParam)
HWND		hDlg;
unsigned	message;
WORD		wParam;
LONG		lParam;
{
	WORD	w;
	int	i;
	short	flabel;
	FARPROC	lpFunc;
	char	mess [10];
	RECT	r;

	hMainDlg= hDlg;
	switch (message) {
	case WM_COMMAND:
		switch (wParam) {
		case IDD_HELP:
			WinHelp (hDlg, "CYRWIN.HLP", HELP_CONTEXT, 100);
			break;
		case 1:
			switch(dstate) {
			case 1:
				PostMessage(hDlg, WM_COMMAND, IDL_ACCEPT, 0L);
				break;
			case 2:
				PostMessage(hDlg, WM_COMMAND, IDL_OK, 0L);
				break;
			}
			break;
		case 2:
			PostMessage(hDlg, WM_COMMAND, IDL_CANCEL, 0L);
			break;
		case IDL_OK:
			LTable(kTable);
			EndDialog(hDlg, NULL);
			return TRUE;
		case IDL_LOAD:			// Save now !!!
dook:
			flabel= filopen(s_path, OF_WRITE);
			if (flabel < 0)
				break;
			if (filwrite(flabel))
			_lclose(flabel);
			LTable(kTable);
			bChanged= FALSE;
			break;
		case IDL_CANCEL:
			wasEdited--;
			bChanged= FALSE;
			flabel= filopen(s_path, OF_READ);
			filread (flabel);
			_lclose (flabel);
			EndDialog(hDlg, NULL);
			return TRUE;
		case IDL_TRS:
			CheckDlgButton (hDlg, IDL_TRS, bNoTrs);
			bNoTrs ^= 1;
            vasc= GetKeyName(v);
            buff [0]= vasc;
			SetDlgItemText(hDlg, IDL_VEDIT, buff);
			SetDlgItemInt(hDlg, IDL_VINT, vasc, FALSE);
			SetScrollPos(GetDlgItem(hDlg, IDL_SCROLL), SB_CTL, vasc, TRUE);
			if (bNoTrs) {
				EnableWindow (GetDlgItem (hDlg, IDL_ACCEPT), FALSE);
				EnableWindow (GetDlgItem (hDlg, IDL_SCROLL), FALSE);
			} else {
				EnableWindow (GetDlgItem (hDlg, IDL_ACCEPT), TRUE);
				EnableWindow (GetDlgItem (hDlg, IDL_SCROLL), TRUE);
			}
			SetKeys (hDlg);
			break;
		case IDL_SELF:
			lpFunc= MakeProcInstance(SelectFont, hInst);
			i= DialogBox(hInst, "SELFONT", hDlg, lpFunc);
			FreeProcInstance(lpFunc);
//			if (hFont != GetStockObject (SYSTEM_FIXED_FONT))
//				DeleteObject (hFont);
			if (i)
				{
				DeleteObject (hFont);
				GetClientRect (GetDlgItem(hDlg, VK_0), (LPRECT) &r);
				hFont= CreateFont (
					r.bottom * 2 / 3 /* SizeList [CurrentSize] */,
					0, 0, 0,
					FW_NORMAL,
					FALSE,
					FALSE,
					FALSE,
					CharSet [CurrentFont],
					OUT_DEFAULT_PRECIS,
					CLIP_DEFAULT_PRECIS,
					PROOF_QUALITY,
					PitchAndFamily [CurrentFont],
					FontList [CurrentFont]
				);
				SetDlgItemText (hDlg, IDL_FONTNAME, FontList [CurrentFont]);
				SetFonts (hDlg, hFont);
				WriteProfileString (szAppName, szFont, itoa (CurrentFont+1, mess, 10));
				}
//			else
//				{
//				CurrentFont= 0;
//				hFont= GetStockObject (SYSTEM_FIXED_FONT);
//				SetDlgItemText (hDlg, IDL_FONTNAME, "System fixed");
//				}
//			SetFonts (hDlg, hFont);
			break;
		case IDL_SHIFT:
			shiftstate ^= 1;
			CheckDlgButton(hDlg, IDL_SHIFT, shiftstate);
			SetKeys(hDlg);
            /*
			if (!bNoTrs) {
				vasc= CyrTrs(v, shiftstate);
			} else {
				vasc= v;
			}
			buff[0]= vasc;
            */
			vasc= GetKeyName(v);
			buff [0]= vasc;
			SetDlgItemText(hDlg, IDL_VEDIT, buff);
			SetDlgItemInt(hDlg, IDL_VINT, vasc, FALSE);
			SetScrollPos(GetDlgItem(hDlg, IDL_SCROLL), SB_CTL, vasc, TRUE);
			break;
		case IDL_ACCEPT:
acckey:
			dstate= 2;
			CyrWrite(v, vasc, shiftstate);
			buff[0]= vasc; buff [1]= 0;
			SetDlgItemText(hDlg, v, buff);
			bChanged= TRUE;
			break;
		default:					 /* key pressed */
			if ((w= mystrchr(vk_t, wParam)) >= 0) {
				dstate= 1;
				v= wParam;
                //vasc= CyrTrs(v, shiftstate);
                vasc= GetKeyName(v);
				buff[0]= vk_names[w];
				SetDlgItemText(hDlg, IDL_KNAME, buff);
                buff[0]= vasc;
				SetDlgItemText(hDlg, IDL_VEDIT, buff);
				SetDlgItemInt(hDlg, IDL_VINT, vasc, FALSE);
				SetScrollPos(GetDlgItem(hDlg, IDL_SCROLL), SB_CTL, vasc, TRUE);
				SetFocus (GetDlgItem (hDlg, IDL_SCROLL));
			}
		}
		break;
	case WM_HSCROLL:
		dstate= 1;
		switch (wParam) {
		case SB_LINEUP:
			if (vasc > 32) vasc--; 		break;
		case SB_LINEDOWN:
			if ((int)vasc < 255) vasc++; 	break;
		case SB_PAGEUP:
			if (vasc >= 42) vasc-= 10; 	break;
		case SB_PAGEDOWN:
			if (vasc <= 245) vasc+= 10; 	break;
		case SB_THUMBTRACK:
		case SB_THUMBPOSITION:
			vasc= LOWORD(lParam); 		break;
		}
		SetScrollPos(GetDlgItem(hDlg, IDL_SCROLL), SB_CTL, (int)vasc, TRUE);
		buff[0]= vasc;
		SetDlgItemText(hDlg, IDL_VEDIT, buff);
		SetDlgItemInt(hDlg, IDL_VINT, vasc, FALSE);
		break;
	case WM_TIMER:
		shiftstate= 0;
		dstate= wasEdited= 1;
		bNoTrs= FALSE;
		CheckDlgButton (hDlg, IDL_TRS, TRUE);
		GetFonts (hDlg);
//		hFont= GetStockObject (SYSTEM_FIXED_FONT);
		GetClientRect (GetDlgItem(hDlg, VK_0), (LPRECT) &r);
		hFont= CreateFont (
			r.bottom * 2 / 3 /* SizeList [CurrentSize] */,
			0, 0, 0,
			FW_NORMAL,
			FALSE,
			FALSE,
			FALSE,
			CharSet [CurrentFont],
			OUT_DEFAULT_PRECIS,
			CLIP_DEFAULT_PRECIS,
			PROOF_QUALITY,
			PitchAndFamily [CurrentFont],
			FontList [CurrentFont]
		);
		SetDlgItemText (hDlg, IDL_FONTNAME, FontList [CurrentFont]);
		SetFonts (hDlg, hFont);
		EnableWindow(GetDlgItem(hDlg, VK_TAB), FALSE);
		for (i= IDL_SHIFT0; i<= IDL_CAPS; i++)
			EnableWindow(GetDlgItem(hDlg, i), FALSE);
		SetScrollRange(GetDlgItem(hDlg, IDL_SCROLL), SB_CTL, 32, 255, 1);
		SetDlgItemText(hDlg, IDL_NAME, l_name);
		SetKeys(hDlg);
		PostMessage(hDlg, WM_COMMAND, v, 0L);
		SetFocus(GetDlgItem(hDlg, IDL_OK));
		break;
	case WM_INITDIALOG:
		PostMessage(hDlg, WM_TIMER, 0, 0L);	// crazy Windows !
		break;
	}
	return FALSE;
}

/* *** */
