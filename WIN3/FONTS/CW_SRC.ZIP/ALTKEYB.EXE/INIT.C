#define		no_Protect_
#define		no_DEMO_
#define		NOVIRTUALKEYCODES
#include	"c:\windev\include\windows.h"
#include	"hello.h"

extern char	szAppName[];
long FAR PASCAL HelloWndProc();
void FAR PASCAL LTable(LPSTR);

#define		KTABLESIZE	(72*4)
extern char 	kTable[];
extern char	l_name[13];
extern char	de[];
extern	int legal_use;
extern	int Chk (void);

extern	int nSwitch;
extern	int CurrentFont;

char	szSwitch[]= "switch";
char	szFont[]= "font";

init		(hInstance)
HANDLE		hInstance;
{
	WNDCLASS	WndClass;
	short		flabel;
	char		s_name[132];
	char		section[10];
	char		deftable[13];

	GetWindowsDirectory (s_name, sizeof s_name);
#ifdef	_Protect_
	if (GetDriveType (s_name [0]- ('A'+ 1)) != DRIVE_REMOTE)
		{
		legal_use= Chk ();
		}
//	else
//		{
//		legal_use= TRUE;
//		}
#else
	legal_use = TRUE;
#endif

#ifdef	_DEMO_
	legal_use = FALSE;
#endif

	LoadString(hInstance, ERR_SECTION, section, sizeof section);
	LoadString(hInstance, ERR_DEFTABLE, deftable, sizeof deftable);

	if (GetProfileString(szAppName, section, deftable, l_name, 13) != 13) {
		WriteProfileString(szAppName, section, deftable);
	}

	AddExt(l_name, de);

	flabel= GetWindowsDirectory(s_name, sizeof s_name);
	if (s_name[flabel] != '\\') { s_name[flabel]= '\\'; s_name[flabel+1]= '\0'; }
	lstrcat(s_name, l_name);
	if ((flabel= _lopen(s_name, OF_READ)) < 0) {
		_lclose(_lcreat(s_name, 0));
		flabel= _lopen(s_name, OF_WRITE);
		_lwrite(flabel, kTable, KTABLESIZE);
	}	else {
		_lread(flabel, kTable, KTABLESIZE);
	}
	_lclose(flabel);
	LTable(kTable);

	nSwitch= (GetProfileInt (szAppName, szSwitch, 1)); nSwitch--;
	CurrentFont= (GetProfileInt (szAppName, szFont, 1)); CurrentFont--;

    	WndClass.hCursor       = LoadCursor (NULL, IDC_ARROW);
    	WndClass.hIcon         = NULL;
    	WndClass.cbClsExtra    = 0;
    	WndClass.cbWndExtra    = 0;
    	WndClass.lpszMenuName  = NULL;
    	WndClass.lpszClassName = (LPSTR) szAppName;
    	WndClass.hbrBackground = (HBRUSH) GetStockObject (WHITE_BRUSH);
    	WndClass.hInstance     = hInstance;
    	WndClass.style         = NULL;
    	WndClass.lpfnWndProc   = HelloWndProc;

    	if (!RegisterClass ((LPWNDCLASS) &WndClass)) {
       		return FALSE;
    	}
    	return TRUE;
}
