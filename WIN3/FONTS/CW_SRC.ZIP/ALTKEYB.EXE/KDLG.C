// #define		_TRACE_

#ifdef		_TRACE_
#	define	Trace(s)	MessageBox (GetFocus (), s, NULL, NULL)
#else
#	define	Trace(s)
#endif


#define		NOVIRTUALKEYCODES
#define		NOMINMAX
#define		_STAT_DEFINED
#include	"c:\windev\include\windows.h"
#include	"hello.h"
#include	"c:\windev\include\string.h"
#include	"c:\windev\include\stdlib.h"

extern HANDLE	hInst;
extern HWND	hMainWnd;
extern HWND	hMainDlg;
extern int	bLAT;
extern char 	szAppName[];
extern char 	w_path[132];
extern char	s_path[256];
extern char 	l_name[13];
extern char 	sk[];
extern char 	lk[];
extern char 	de[];
extern FARPROC 	lpDlgProc;

void FAR PASCAL	CyrSwitch();
char FAR PASCAL TrsVK(int, int);
void FAR PASCAL LTable(char far *);
BOOL FAR PASCAL kDlg();
BOOL FAR PASCAL lDlg();
int		filopen(PSTR, WORD);
int		filwrite(int);
int		filread(int);

#define 	KTABLESIZE	(72*4)
extern char	kTable[KTABLESIZE];

int		wasEdited= 0;
BOOL		bDlgActive= FALSE;
HWND		hkDlg;

extern	char szSwitch[];

static	char szSwitchNames[3][12]=
	{
	"Ctrl",
	"Shift-Shift",
	"Ctrl-Shift"
	};

int	nSwitch= 0;
BOOL	bSelChanged= FALSE;
extern	int legal_use;
void FAR PASCAL CyrStart();
void FAR PASCAL CyrStop();

extern	BOOL bChanged;


BOOL FAR PASCAL
kDlg		(hDlg, message, wParam, lParam)
HWND		hDlg;
unsigned	message;
WORD		wParam;
LONG		lParam;
{
	FARPROC	lpLp;
	int i;
	short	flabel;
	char	mess[15];

	hMainDlg= hDlg;

	switch (message) {
	case WM_INITDIALOG:
		bSelChanged= FALSE;
		hkDlg= hDlg;
		i= GetWindowsDirectory(w_path, sizeof w_path);
		if (w_path[i] != '\\') { w_path[i]= '\\'; w_path[i+1]= '\0'; }
		UpdateListBox(hDlg);
		SendDlgItemMessage (hDlg, IDS_LIST, CB_SELECTSTRING, -1, (LONG) (LPSTR) l_name);
//		SetDlgItemText(hDlg, IDS_LEDIT, l_name);
//		SendDlgItemMessage(hDlg, IDS_LEDIT, EM_SETSEL, NULL, MAKELONG(0, 0x7fff));
		if (bLAT) {
			CheckRadioButton(hDlg, IDS_LAT, IDS_CYR, IDS_LAT);
		} else {
			CheckRadioButton(hDlg, IDS_LAT, IDS_CYR, IDS_CYR);
		}
		for (i= 0; i< 3; i++)
			{
			SendDlgItemMessage (hDlg, IDS_KSWITCH, CB_ADDSTRING, NULL, (LONG) (LPSTR) szSwitchNames [i]);
			}
		SendDlgItemMessage (hDlg, IDS_KSWITCH, CB_SETCURSEL, nSwitch, 0L);
		SetFocus(GetDlgItem(hDlg, IDS_LIST));
		return FALSE;
	case WM_COMMAND:
		switch (wParam) {
		case IDD_HELP:
			WinHelp (hDlg, "CYRWIN.HLP", HELP_CONTEXT, 101);
			break;
		case 1:
			if (bDlgActive) { MessageBeep(0); break; }
			PostMessage(hDlg, WM_COMMAND, IDS_OK, 0L);
			break;
		case IDS_KSWITCH:
			switch (HIWORD (lParam))
				{
				case CBN_DBLCLK:
					nSwitch= SendDlgItemMessage (hDlg, IDS_KSWITCH,
							CB_GETCURSEL, 0, 0L);
					if (nSwitch == CB_ERR)
						nSwitch= 0;
					goto do_ok;
				case CBN_SELCHANGE:
					nSwitch= SendDlgItemMessage (hDlg, IDS_KSWITCH,
							CB_GETCURSEL, 0, 0L);
					if (nSwitch == CB_ERR)
						nSwitch= 0;
					break;
				}
			break;
		/*
		case IDS_LIST:
			if (HIWORD (lParam) == CBN_SELCHANGE)
				{
				bSelChanged= TRUE;
//				bChanged= FALSE;
				}
			break;
//			switch(HIWORD(lParam)) {
//			case CBN_SELCHANGE:
//				if (!DlgDirSelectComboBox(hDlg, l_name, IDS_LIST)) {
//					AddExt(l_name, de);
//					SetDlgItemText(hDlg, IDS_LEDIT, l_name);
//					SendDlgItemMessage(hDlg, IDS_LEDIT, EM_SETSEL, NULL, MAKELONG(0, 0x7fff));
//				}	else {
//					UpdateListBox(hDlg);
//				}
//				break;
			case CBN_DBLCLK:
				if (bDlgActive) { MessageBeep(0); break; }
				goto do_ok;
			}
			break;
		*/
		case IDS_CYR:
		case IDS_LAT:
			CyrSwitch();
			bLAT ^= 1;
		case IDS_SWITCH:
			if (bLAT) {
				CheckRadioButton(hDlg, IDS_LAT, IDS_CYR, IDS_LAT);
			} else {
				CheckRadioButton(hDlg, IDS_LAT, IDS_CYR, IDS_CYR);
			}
			break;
		case IDS_QUIT:
			if (bDlgActive)
				SendMessage(hMainDlg, WM_COMMAND, IDL_CANCEL, 0L);
			PostMessage(hMainWnd, WM_DESTROY, 0, 0L);
			EndDialog(hDlg, NULL);
			return FALSE;
do_ok:
		case IDS_OK:
			if (bDlgActive) { MessageBeep(0); break; }
			GetDlgItemText (hDlg, IDS_LIST, mess, 13); AddExt (mess, de);
			strcpy(s_path, w_path); strcat(s_path, mess);
			if (strcmp (l_name, mess))
				{
				if (bChanged)
					{
					if (ask_save(l_name))
						{
						strcpy (s_path, w_path); strcat (s_path, l_name);
						flabel= filopen (s_path, OF_WRITE);
						if (flabel < 0)
							break;
						if (filwrite(flabel))
						_lclose(flabel);
						}
						bChanged= FALSE;
					}
				GetDlgItemText (hDlg, IDS_LIST, l_name, 13);
				strcpy(s_path, w_path); strcat(s_path, l_name); AddExt(s_path, de);
				flabel= filopen (s_path, OF_READ);
				if (flabel < 0)
					break;
				if (filread(flabel) < 0)
					break;
				_lclose(flabel);
				}
			LTable(kTable);
			GetDlgItemText (hDlg, IDS_LIST, l_name, 13); AddExt (mess, de);
			strcpy(s_path, w_path); strcat(s_path, l_name);
			LoadString(hInst, ERR_SECTION, mess, sizeof mess);
			WriteProfileString(szAppName, mess, l_name);
		case 2:
			if (bDlgActive) { MessageBeep(0); break; }
			WriteProfileString (szAppName, szSwitch, itoa (nSwitch+1, mess, 10));
			SetText();
			CyrStop ();
			CyrStart (hMainWnd, legal_use, nSwitch);
			SendMessage(hMainWnd, WM_TIMER, bLAT, 0L);
			EndDialog(hDlg, NULL);
			return TRUE;
		case IDS_CANCEL:
			if (bDlgActive) { MessageBeep(0); break; }

			GetDlgItemText (hDlg, IDS_LIST, mess, 13); AddExt (mess, de);
			if (strcmp (mess, l_name))
				{
				Trace("Compare");
				if (bChanged)
					{
					strcpy (s_path, w_path);
					strcat (s_path, l_name);
				        if (ask_save (l_name))
				    		{
						flabel= filopen (s_path, OF_WRITE);
						if (flabel < 0)
							break;
						if (filwrite(flabel))
						_lclose(flabel);
						}
					bChanged= FALSE;
					}
				Trace("Read");
				GetDlgItemText (hDlg, IDS_LIST, l_name, 13); AddExt (l_name, de);
				strcpy (s_path, w_path); strcat (s_path, l_name);
				Trace(s_path);
				flabel= filopen (s_path, OF_READ);
				if (flabel < 0)
					break;
				else
					{
					if (filread (flabel) < 0)
						break;
					else
						_lclose (flabel);
					}
				}

			GetDlgItemText (hDlg, IDS_LIST, l_name, 13); AddExt (l_name, de);
			SetText();
			strcpy(s_path, w_path); strcat(s_path, l_name);
			Trace("Edit");
			Trace(s_path);
edit:			lpLp= MakeProcInstance(lDlg, hInst);
			/* EnableWindow(hDlg, FALSE); */
			bDlgActive= TRUE;
			flabel= filopen (s_path, OF_READ);
			if (flabel < 0)
				goto e_failed;
			else
				_lclose (flabel);
			DialogBox(hInst, lk, hMainWnd, lpLp);
e_failed:		bDlgActive= FALSE;
			/* EnableWindow(hDlg, TRUE); */
			FreeProcInstance(lpLp);
			UpdateListBox (hDlg);
			SendDlgItemMessage (hDlg, IDS_LIST, CB_SELECTSTRING, -1, (LONG) (LPSTR) l_name);
			SetFocus(GetDlgItem(hDlg, IDS_OK));
			break;
		}
		return TRUE;
	}
	return FALSE;
}

UpdateListBox	(hDlg)
HANDLE		hDlg;
{
	strcpy(s_path, w_path); strcat(s_path, "*.kbd");
	DlgDirListComboBox(hDlg, s_path, IDS_LIST, NULL, 0x0000);
}