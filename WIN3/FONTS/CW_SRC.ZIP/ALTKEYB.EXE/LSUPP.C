#define		no_Trace_

#define		NOVIRTUALKEYCODES
#include	"c:\windev\include\windows.h"
#include	"hello.h"

#define		KTABLESIZE (72*4)
extern int	shiftstate;
extern char	kTable[KTABLESIZE];
extern char	buff[];
extern char	vk_t[];
extern char	vk_names[];
extern HANDLE	hInst;
extern int	bNoTrs;

int	GetScanCode (int);

/*
static	char spc_keys []=
	{
	VK_0,		')',
	VK_1,		'!',
	VK_2,		'@',
	VK_3,		'#',
	VK_4,		'$',
	VK_5,		'%',
	VK_6,		'^',
	VK_7,		'&',
	VK_8,		'*',
	VK_9,		'(',
	VK_OEM_1,	':',
	VK_OEM_2,	'?',
	VK_OEM_3,	'~',
	VK_OEM_4,	'{',
	VK_OEM_5,	'|',
	VK_OEM_6,	'}',
	VK_OEM_7,	'"',
	VK_OEM_PLUS,	'+',
	VK_OEM_MINUS,	'_',
	VK_OEM_COMMA,	'<',
	VK_OEM_PERIOD,	'>',
	0
	};
*/
//
//	Returns ascii 'key name' - from alternative layout, or from
//	current language layout
//
//	NOTE:	All key translation must be performed from keys ScanCodes,
//		not from VK_ codes !!! (little BUG!)
//

int	GetKeyName (int vkey)
	{
	unsigned i;
	unsigned j, scan;
	DWORD	oem;
	int	retval;
	char	tbu [132];

	for (i= 0; vk_t [i]; i++)
		{
		if ((char)vkey == vk_t [i])
			break;
		}

	if (!vk_t[i])
		{
		return '?';
		}

	if (bNoTrs)
		{
		shiftstate= (shiftstate) ? 1 : 0;
		if ((scan= GetScanCode ((int)vkey)) != 0xff)
			{
			for (j= 0x20; j< '~'; j++)
				{
				oem= OemKeyScan ((char) j);
				if (((HIWORD (oem)>> 1) & 1) == shiftstate)
					{
					if ((char)(LOWORD (oem)) == (char) scan)
						{
						return j;
						}
					}
				}
				j= MapVirtualKey (i= MapVirtualKey (scan, 1), 2);
				if (shiftstate)
					{
//					AnsiUpper ((LPSTR) &j);
					return j;
					}
				/*
				i= VK_ key code;
				*/
				for (j= 0x20; j< 0xff; j++)
					{
					scan= VkKeyScan (j);
					if (LOWORD (scan) == i)
						{
						if (!HIWORD (scan))
							return j;
						}
					}
				return ' ';
			}
		else
			{
			return '?';
			}
		}
	else
		{
		retval= (char) CyrTrs (vk_t [i], shiftstate);
		}
	return retval;
	}

void	SetKeys (HWND hDlg)
	{
	int i;
	int j;

	buff [1]= 0;
	for (i= 0; vk_t [i] != 0; i++)
		{
         buff [0]= GetKeyName (vk_t [i]);
		if (buff [0] == '&')
			{
			buff [1]= '&';
			buff [2]= 0;
			}
		SetDlgItemText (hDlg, vk_t [i], (LPSTR) buff);
		buff [1]= 0;
		}
	}

void
SetFonts	(hDlg, hFont)
HWND		hDlg;
HFONT		hFont;
{
	int	i;

	for (i= 0; vk_t[i] != 0; i++) {
		SendDlgItemMessage (hDlg, vk_t[i], WM_SETFONT, hFont, 1L);
	}
	SendDlgItemMessage (hDlg, IDL_VEDIT, WM_SETFONT, hFont, 1L);
}

AddExt(name, ext)
char name[], ext[];
{
	PSTR pTptr;

	pTptr= name;
	while (*pTptr && *pTptr != '.') pTptr++;
	if (*pTptr != '.')
		strcat(name, ext);
}

mystrchr(char *s, int vl)
{
	int i;

	for (i= 0; s[i]; i++)
		if (s[i] == vl) return i;
	return -1;
}

extern HWND	hMainWnd;
extern HWND	hMainDlg;
extern char	szAppName[];
extern char	l_name[];

SetText()
{
	char	str[132];

	lstrcpy(str, szAppName);
	lstrcat(str, " - ");
	lstrcat(str, l_name);
	SetWindowText(hMainWnd, str);
}

int
filopen		(path, mode)
PSTR		path;
{
	short	flabel;
	int	i;
	char	message[30];
	char	msg [50];

retry:
	flabel= _lopen(path, mode);
	if (flabel < 0) {
		LoadString(hInst, ERR_CREATE, message, sizeof message);
		sprintf (msg, "cannot open file %s, create?", path);
		if (MessageBox(hMainDlg, msg, szAppName, MB_YESNO|MB_ICONQUESTION|MB_SYSTEMMODAL) == IDYES) {
			_lclose(_lcreat(path, 0));
			flabel= _lopen(path, OF_WRITE);
//			for (i= 0; i< KTABLESIZE; i++)
//				if (i%4) kTable[i]= '?';
			if (filwrite(flabel))
				return -1;
			_lclose(flabel);
			goto retry;
		}
	}
	return flabel;
}

int
filwrite	(flabel)
short		flabel;
{
	char	message[30];

	if (_lwrite(flabel, kTable, KTABLESIZE) != KTABLESIZE) {
		LoadString(hInst, ERR_WRITE, message, sizeof message);
		MessageBox(hMainDlg, message, szAppName, MB_OK);
		_lclose(flabel);
		return -1;
	}
	return 0;
}

int
filread		(flabel)
short		flabel;
{
	char	message[30];

	if (_lread(flabel, kTable, KTABLESIZE) != KTABLESIZE) {
		LoadString(hInst, ERR_READ, message, sizeof message);
		MessageBox(hMainDlg, message, szAppName, MB_OK);
		_lclose(flabel);
		return -1;
	}
	return 0;
}

void
demomsg		()
{
	char	dmsg[256];
	LoadString(hInst, ERR_DEMO, dmsg, 256);
	MessageBox(NULL, dmsg, szAppName, MB_OK);
}


//
//	fonts
//

#define	MAXSIZE		20
#define	MAXFONT		20

int	FontIndex= 0;
int	SizeIndex= 0;
int	CurrentFont= 0;
int	CurrentSize= 0;

char	FontList [MAXFONT][32];
char	SizeList [MAXSIZE];
BYTE	CharSet[MAXFONT];
BYTE	PitchAndFamily[MAXFONT];

FARPROC	lpEnumFunc;

int	FAR PASCAL EnumFunc (LPLOGFONT, LPTEXTMETRIC, short, LPSTR);
BOOL	FAR PASCAL SelectFont (HWND, unsigned, WORD, LONG);
int	_lstrlen (LPSTR);
void	_lstrncpy (LPSTR, LPSTR, int);
void	_lstrcpy (LPSTR, LPSTR);

void GetSizes(hWnd, _CurrentFont)
HWND hWnd;
int _CurrentFont;
{
    HDC hDC;

    SizeIndex = 0;
    hDC = GetDC(hWnd);
    lpEnumFunc = MakeProcInstance(EnumFunc, hInst);
    EnumFonts(hDC, FontList[_CurrentFont], lpEnumFunc, (LPSTR) 1L);
    FreeProcInstance(lpEnumFunc);
    ReleaseDC(hWnd, hDC);
}

void GetFonts(hWnd)
HWND hWnd;
{

    HDC hDC;

    FontIndex = 0;
    SizeIndex = 0;
    hDC = GetDC(hWnd);
    lpEnumFunc = MakeProcInstance(EnumFunc, hInst);
    EnumFonts(hDC, (LPSTR) NULL, lpEnumFunc, (LPSTR) NULL);
    FreeProcInstance(lpEnumFunc);
    ReleaseDC(hWnd, hDC);
}

BOOL FAR PASCAL SelectFont(hDlg, message, wParam, lParam)
HWND hDlg;
unsigned message;
WORD wParam;
LONG lParam;
{

    int i;
    int index;
    char buf[LF_FACESIZE];

    switch (message) {
        case WM_INITDIALOG:
	    GetFonts (hDlg);
            for (i=0; i<FontIndex; i++) {        /* displays available fonts */
                SendDlgItemMessage(hDlg, ID_SF_LIST, LB_ADDSTRING,
                    NULL, (LONG) (LPSTR) FontList[i]);
                SendDlgItemMessage(hDlg, ID_SF_LIST, LB_SETCURSEL,
                    0, 0L);
            }
            SendDlgItemMessage(hDlg, ID_SF_LIST, LB_SETCURSEL,
                CurrentFont, 0L);
            GetSizes(hDlg, 0);
            for (i=0; i<SizeIndex; i++) {        /* displays font sizes      */
                sprintf(buf, "%d", SizeList[i]);
                SendDlgItemMessage(hDlg, ID_SF_SIZE, LB_ADDSTRING,
                    0, (LONG) (LPSTR) buf);
                SendDlgItemMessage(hDlg, ID_SF_SIZE, LB_SETCURSEL,
                    0, 0L);
            }
            return (TRUE);
            break;

        case WM_COMMAND:
            switch (wParam) {
                case ID_SF_OK:
okay:
                    index=SendDlgItemMessage(hDlg, ID_SF_LIST,
                        LB_GETCURSEL, 0, 0L);
                    if (index == LB_ERR) {
                        MessageBox(hDlg, "No font selected",
                            "Select Font", MB_OK | MB_ICONEXCLAMATION);
                    break;
            }
            CurrentFont = index;
            index = SendDlgItemMessage(hDlg, ID_SF_SIZE,
                LB_GETCURSEL, 0, 0L);
            if (index == LB_ERR) {
                MessageBox(hDlg, "No size selected",
                    "Select Font", MB_OK | MB_ICONEXCLAMATION);
                break;
            }
            CurrentSize = index;
            EndDialog(hDlg, 1);
            break;

        case ID_SF_CANCEL:
            EndDialog(hDlg, 0);
            break;

        case ID_SF_LIST:
            switch (HIWORD(lParam)) {
                case LBN_SELCHANGE:
                    index = SendDlgItemMessage(hDlg, ID_SF_LIST,
                        LB_GETCURSEL, 0, 0L);
                    if (index == LB_ERR)
                        break;
                    SendDlgItemMessage(hDlg, ID_SF_SIZE, LB_RESETCONTENT, 0, 0L);
                    GetSizes(hDlg, index);
                    for (i = 0; i < SizeIndex; i++) {
                        sprintf(buf, "%d", SizeList[i]);
                        SendDlgItemMessage(hDlg, ID_SF_SIZE,
                            LB_ADDSTRING, 0, (LONG) (LPSTR) buf);
                        SendDlgItemMessage(hDlg, ID_SF_SIZE, LB_SETCURSEL, 0, 0L);
            }
            break;

                case LBN_DBLCLK:
                goto okay;
                break;
            }
            break;

        case ID_SF_SIZE:
            if(HIWORD(lParam) == LBN_DBLCLK)
                goto okay;
            break;
        }
        break;
    }
    return (FALSE);
}

int FAR PASCAL EnumFunc(lpLogFont, lpTextMetric, FontType, lpData)
LPLOGFONT lpLogFont;
LPTEXTMETRIC lpTextMetric;
short FontType;
LPSTR lpData;
{
    switch (LOWORD(lpData)) {
        case 0:
            if (FontIndex >= MAXFONT)
                return (0);
            _lstrcpy((LPSTR) FontList[FontIndex],
                (LPSTR) (lpLogFont->lfFaceName));
            CharSet[FontIndex] = lpLogFont->lfCharSet;
            PitchAndFamily[FontIndex] = lpLogFont->lfPitchAndFamily;
            return (++FontIndex);

        case 1:
            if (SizeIndex >= MAXSIZE)
                return (0);
            SizeList[SizeIndex] = lpLogFont->lfHeight;
            return (++SizeIndex);
    }
}

int _lstrlen(lpStr)
LPSTR lpStr;
{
    int i;
    for (i=0; *lpStr++; i++);
    return (i);
}

void _lstrncpy(lpDest, lpSrc, n)
LPSTR lpDest, lpSrc;
int n;
{
    while (n--)
        if(!(*lpDest++ = *lpSrc++))
            return;
}

void _lstrcpy(lpDest, lpSrc)
LPSTR lpDest, lpSrc;
{
    while(*lpDest++ = *lpSrc++);
}

int	ask_save (char *s)
	{
	char	smsg [100];

		sprintf (smsg, "Keyboard layout %s has changed.\nDo you want to save it?", s);
		return (MessageBox (GetFocus (), smsg, szAppName, MB_YESNO|MB_ICONQUESTION|MB_SYSTEMMODAL) == IDYES);
	}
