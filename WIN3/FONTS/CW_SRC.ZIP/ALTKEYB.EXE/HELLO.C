#include "c:\windev\include\windows.h"

long FAR PASCAL HelloWndProc(HWND, unsigned, WORD, LONG);

void FAR PASCAL CyrStart();
void FAR PASCAL CyrStop();

extern	int nSwitch;

char szAppName[]= "AltKeyb";
int	 legal_use= TRUE;

HWND	hMainWnd;
HWND	hMainDlg= NULL;
HANDLE	hInst;


int PASCAL WinMain (hInstance, hPrevInstance, lpszCmdLine, nCmdShow)
    HANDLE hInstance, hPrevInstance;
    LPSTR  lpszCmdLine;
    int    nCmdShow;
{
	HWND        hWnd;
	MSG         msg;

    if (hPrevInstance) {
       return FALSE;
    }

//	legal_use = TRUE;
//	GetWindowsDirectory ((LPSTR)&legal_use, 2);
//	MessageBox (NULL, (LPSTR) &legal_use, "Drive", NULL);
//      legal_use = Chk();

	if (!init(hInstance))
		return FALSE;

    hWnd = CreateWindow ((LPSTR) szAppName,
           (LPSTR) szAppName,
           WS_TILEDWINDOW,
           0, 0, 0, 0,
           (HWND)   NULL,
           (HMENU)  NULL,
           (HANDLE) hInstance,
           (LPSTR)  NULL);

	hMainWnd= hWnd;
	hInst= hInstance;

    SetText();
    CyrStart(hWnd, legal_use, nSwitch);

    ShowWindow(hWnd, SW_SHOWMINIMIZED);

    while (GetMessage ((LPMSG) &msg, NULL, 0, 0) && !IsDialogMessage(hMainDlg, &msg))
    	{
	TranslateMessage (&msg);
        DispatchMessage (&msg);
	}

    CyrStop();

    return (int) msg.wParam;
}
