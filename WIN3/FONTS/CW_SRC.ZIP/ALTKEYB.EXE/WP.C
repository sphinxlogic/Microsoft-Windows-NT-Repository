#define		no_Trace_

#define		NOVIRTUALKEYCODES
#include	"c:\windev\include\windows.h"
#include	"hello.h"
#define		WM_ALARM	(WM_USER+1)
#define		WM_ALTKEYBKILL	(WM_USER + 1141)

long FAR PASCAL HelloWndProc();
void FAR PASCAL CyrStart();
void FAR PASCAL CyrStop();
void FAR PASCAL CyrSwitch();
void		demomsg();

BOOL bLAT= TRUE;
char kreg[2][3]= { "Alt", "Def" };

extern char szAppName[];
extern int legal_use;
extern HANDLE hInst;
extern HWND hkDlg;
extern BOOL bDlgActive;
extern HWND hMainDlg;
extern HWND hkDlg;
extern BOOL bChanged;
extern char s_path [];
extern char l_name [];
extern char w_path [];

long FAR PASCAL HelloWndProc( hWnd, message, wParam, lParam )
HWND hWnd;
unsigned message;
WORD wParam;
LONG lParam;
{
	PAINTSTRUCT	ps;
	RECT		rect;
	HMENU		hSysMenu;
	short		flabel;
	WORD		wpsave;

    switch (message) {
	case WM_CREATE:
		hSysMenu= GetSystemMenu (hWnd, FALSE);
		DeleteMenu(hSysMenu, SC_RESTORE,  MF_BYCOMMAND);
		DeleteMenu(hSysMenu, SC_MINIMIZE, MF_BYCOMMAND);
		DeleteMenu(hSysMenu, SC_MAXIMIZE, MF_BYCOMMAND);
		DeleteMenu(hSysMenu, SC_SIZE,     MF_BYCOMMAND);
		AppendMenu(hSysMenu, MF_SEPARATOR, -1, NULL);
		AppendMenu(hSysMenu, MF_STRING, SC_RESTORE,
			(LPSTR) "&Settings...");
		AppendMenu(hSysMenu, MF_STRING, IDM_SETTINGS,
			(LPSTR) "&About AltKeyb...");
#ifdef		_Trace_
		CreateDebugWindow (NULL);
#endif
		break;
	
	case WM_SYSCOMMAND:

		wpsave= wParam;	wParam&= 0xFFF0;

		switch (wParam) {
		case SC_RESTORE:
			KeybSet ();
			break;
		case IDM_SETTINGS:
			DoAbout ();
			break;
		default:
			wParam= wpsave;
			goto retDef;
		}
		break;
	
    case WM_ALARM:
    case WM_DESTROY:
    case WM_ALTKEYBKILL:
#ifdef		_Trace_
		DestroyDebugWindow ();
#endif
		CyrStop();
		if (bChanged)
			{
			if (ask_save (l_name))
				{
				strcpy (s_path, w_path);
				strcat (s_path, l_name);
				flabel= filopen(s_path, OF_WRITE);
				if (flabel < 0)
					break;
				if (filwrite(flabel))
				_lclose(flabel);
				}
			}
		if (! legal_use) demomsg();
		PostQuitMessage(0);
		break;
    case WM_TIMER:
    		bLAT= wParam; InvalidateRect(hWnd, NULL, TRUE);
		if (hkDlg)
			SendMessage(hkDlg, WM_COMMAND, IDS_SWITCH, 0L);
    		break;
    case WM_PAINT:
		BeginPaint(hWnd, (LPPAINTSTRUCT)&ps);
		GetClientRect(hWnd, (LPRECT)&rect);
		DrawText(ps.hdc, (LPSTR) kreg[bLAT], 3, (LPRECT)&rect, DT_WORDBREAK);
		EndPaint(hWnd, (LPPAINTSTRUCT)&ps);
		break;
    default:
retDef:        return DefWindowProc (hWnd, message, wParam, lParam);
    }
    return 0L;
}
