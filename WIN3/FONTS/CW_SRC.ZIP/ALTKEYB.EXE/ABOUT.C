#define		NOVIRTUALKEYCODES
#include	"c:\windev\include\windows.h"
#include	"hello.h"

extern	HANDLE	hInst;
extern	HWND	hMainWnd;

BOOL FAR PASCAL	About (HWND, unsigned, WORD, LONG);

void
DoAbout		()
{
	FARPROC	lpAbout;

	lpAbout= MakeProcInstance (About, hInst);
	DialogBox(hInst, "About", hMainWnd, lpAbout);
	FreeProcInstance(lpAbout);
}

BOOL FAR PASCAL
About		(hDlg, message, wParam, lParam)
HWND		hDlg;
unsigned	message;
WORD		wParam;
LONG		lParam;
{
	if (message == WM_COMMAND) {
		EndDialog (hDlg, TRUE);
		return TRUE;
	} else if (message == WM_INITDIALOG) {
		return TRUE;
	} else {
		return FALSE;
	}
}