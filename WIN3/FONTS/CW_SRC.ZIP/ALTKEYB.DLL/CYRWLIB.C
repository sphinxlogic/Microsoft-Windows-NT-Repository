#define no_TRACE_

#include    "c:\windev\include\windows.h"
#include    "c:\windev\include\string.h"
#include    "ewtdebug.h"

static	char szHookName[]= "CyrKeyb";

FARPROC	prevHook= NULL;
FARPROC myHook= NULL;

HANDLE hMainWnd= NULL;
int    legal_use= FALSE;
int	nSwitch= 0;

int FAR PASCAL CyrKeyb(int, WORD, LONG);

int FAR PASCAL	LibMain(hInstance, wDataSeg, cbHeapSize, lpszCmdLine)
	HANDLE		hInstance;
	WORD		wDataSeg;
	WORD		cbHeapSize;
	LPSTR		lpszCmdLine;
{
        CreateDebugWindow (GetFocus());
	return 1;
}

void FAR PASCAL
CyrStart    (hWnd, lu, sw)
HWND    hWnd;
int	lu;
int	sw;
{
	FARPROC (FAR PASCAL *_sethook) (int, FARPROC);

	myHook= GetProcAddress(GetModuleHandle("AltKeyb"), (LPSTR)MAKELONG(100,0));

	_sethook= (FARPROC) GetProcAddress (GetModuleHandle ("USER.EXE") , (LPSTR) MAKELONG (121, 0));
//	prevHook= SetWindowsHook(WH_KEYBOARD, CyrKeyb);
	prevHook= (*_sethook) (WH_KEYBOARD, (FARPROC) CyrKeyb);
	hMainWnd= hWnd;
	legal_use= lu;
	if (sw < 0 || sw > 3)
		{
		MessageBeep (0);
		sw= 0;
		}
	nSwitch= sw;
}

void FAR PASCAL	CyrStop(void)
{
	BOOL (FAR PASCAL *_unhook) (int, FARPROC);

	_unhook= (FARPROC) GetProcAddress (GetModuleHandle ("USER.EXE"), (LPSTR) MAKELONG (234, 0));

//	if (!UnhookWindowsHook(WH_KEYBOARD, myHook)) {
//		FatalExit(0xaaa);
//	}
	if (!(*_unhook) (WH_KEYBOARD, (FARPROC) myHook)) {
		FatalExit (0xaaa);
	}

	hMainWnd= NULL;
}

extern int bLAT;

void FAR PASCAL CyrSwitch()
{
	bLAT ^= 1;
	MessageBeep(0);
	PostMessage(hMainWnd, WM_TIMER, bLAT, 0L);
}
