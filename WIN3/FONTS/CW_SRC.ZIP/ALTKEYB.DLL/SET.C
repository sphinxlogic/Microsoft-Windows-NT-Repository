#include	"c:\windev\include\windows.h"

#define 	KTABLESIZE (72*4)


extern BOOL shift;
extern WORD CyrTrs(WORD, WORD, WORD);
void   FAR PASCAL LTable(LPSTR);

extern PSTR CTable;

void FAR PASCAL
LTable		(kMemory)
LPSTR		kMemory;
{
	int	i;
	for (i= 0; i< KTABLESIZE; i++) {
		CyrLoad(kMemory[i], i);
	}
}

void FAR PASCAL
WEP		(nParameter)
int		nParameter;
{
	return;
}

//
//	SetWindowsHook, UnhookWindowsHook calls
//
//	FARPROC FAR PASCAL SetWindowsHook(int, FARPROC);
//	BOOL	FAR PASCAL UnhookWindowsHook(int, FARPROC);
//	DWORD	FAR PASCAL DefHookProc(int, WORD, DWORD, FARPROC FAR *);
//

FARPROC	FAR PASCAL mySetWindowsHook(int, FARPROC);
BOOL	FAR PASCAL myUnhookWindowsHook(int, FARPROC);
DWORD	FAR PASCAL myDefHookProc(int, WORD, DWORD, FARPROC FAR *);

#define	SETWINDOWSHOOK		121
#define	UNHOOKWINDOWSHOOK	234
#define	DEFHOOKPROC		235

FARPROC	lpCall= (FARPROC) NULL;

FARPROC	GetAddr(WORD);

FARPROC FAR PASCAL
mySetWindowsHook	(iHook, fpProc)
int			iHook;
FARPROC			fpProc;
{
	lpCall= GetAddr(SETWINDOWSHOOK);
}

FARPROC
GetAddr			(wNumber)
WORD			wNumber;
{
	return GetProcAddress(GetModuleHandle("user.exe"), 
			      (LPSTR) MAKELONG(wNumber, 0));
}
