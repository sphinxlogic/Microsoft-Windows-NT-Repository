#define	_WINDOWS
#define	no_Protect_

#define	_Fast_
#define	no_Trace_

//
// CyrWin installation program
//
#define	NOMINMAX
#include "c:\windev\include\windows.h"
#include "c:\windev\include\memory.h"
#include "c:\windev\include\string.h"
#include "c:\windev\include\direct.h"
#include "c:\windev\include\stdlib.h"
#include "c:\windev\include\stdio.h"
#include "cwinst.h"
#include "ewtdebug.h"

extern	HANDLE hInst;
extern	HANDLE hArrow, hWait;
HANDLE	hMainWnd;

char	szSrcPath [132];			// source path
char	szDstPath [132];			// dest. path (ROOT)
char	szSysPath [132];			// syst. path (SYSTEM)

char	szSrcFile [132];			// source file name
char	szDstFile [132];			// dest. file name

char	szDiskName [132];			// installation volume name
char	szSetupInf []= "cwsetup.inf";		// .inf file name
char	szSetupFile [132];			// full file name with path

char	szSetupStr [132];			// readed string

char	cCpBuff [20480];			// 20 Kbutes long buffer
char	cFilBuff [5120];			// 5 Kbutes filenames buffer
char	cTmpBuff [5120];			// 5 Kbutes temp buffer
char	cTmpStr [256];

char	szDiskName [132];			// distribution disk name
extern	char szTitle [];

static char szFonts[][4]= {
	"FIX",
	"SYS",
	"866",
	""
};

static char szSects[][13]= {
	"fixedfon.fon",
	"fonts.fon",
	"oemfonts.fon",
	""
};

static char szCards[][4]= {
	"CGA",
	"EGA",
	"VGA",
	"8514",
	""
};

BOOL	FAR PASCAL Floppy (HWND, WORD, WORD, LONG);
int	bCopyFile (PSTR, PSTR, PSTR);
int	CopyErr (PSTR, PSTR, int);
PSTR	_strup (PSTR);
PSTR	pFontName (PSTR);
BOOL	myssearch (PSTR, PSTR);
BOOL	bSearchCyr (char *);
#ifdef	_Protect_
static	short Protect (char*);
unsigned BiosSum (void);
int	checkdsk (int);
#endif

char	szUninstall[]= "uninstall";

#define	GetKey(app,key,str)	GetPrivateProfileString (app, key, "", str, sizeof str, szSetupFile)
// #define	WriteChanges(file,str)	WritePrivateProfileString (szUninstall, file, str, szSetupFile)
#define	WriteChanges(file,str)
#define	AddSlash(str)		if (str [i= (strlen (str)-1)] != '\\')	\
					{				\
					str [++i]= '\\';		\
					str [++i]= 0;			\
					}
#define	clear(x)		memset (x, 0, sizeof x)


char	szContScaling[]= "CONTINUOUSSCALING";

typedef	struct
	{
	int	a, b, c;
	char	cLetter;
	} tag_fnt;

//
// installations options
//
extern	int bInstallSys;
extern	int bCommentFonts;
extern	int bLangInfo;
extern	int bLoadFonts;
extern	int bLoadAuto;

typedef	struct
	{
	char	name [15];
	int	*val;
	} tagDefs;

tagDefs	instDefs []=
	{
	"INSTALLSYS", &bInstallSys,
	"LANGINFO", &bLangInfo,
	"LOADAUTO", &bLoadAuto,
	"LOADFONTS", &bLoadFonts,
	"COMMENTFONTS", &bCommentFonts,
	"", NULL
	};

//
//	font parameter table
//
tag_fnt	fTypes [6]=
	{
	200,  96,  48,  'A',
	133,  96,  72,  'B',
	 83,  60,  72,  'C',
	167, 120,  72,  'D',
	100,  96,  96,  'E',
	100, 120, 120,  'F'
	};

int	FontType (PSTR, tag_fnt *);		// returns font params

//
//	Read installation defaults from cwinst.inf and copy this file
//	to the Windows ROOT directory
//
int	cwDefaults (HWND hWnd)
	{
	int	iRetVal= 0;
	int	i;
	FARPROC	lpfnProc;
	PSTR	cp;
	int	iErr;
	PSTR	cps;
	char	b [255];
	char	tmp1 [255];
	char	tmp2 [255];
	PSTR	pCard;
	PSTR	pFontSect;
	tag_fnt	dFont;
	tagDefs	*td;

	hMainWnd= hWnd;
	clear (szDstPath);
	GetWindowsDirectory (szDstPath, sizeof szDstPath);
	AddSlash (szDstPath);
	strcpy (szSysPath, szDstPath); strcat (szSysPath, "SYSTEM\\");
	clear (szSrcPath);
	getcwd (szSrcPath, sizeof szSrcPath);
	AddSlash (szSrcPath);

	//
	// search cwsetup.inf file
	//
	for (;;)
		{
		strcpy (szSetupFile, szSrcPath);
		strcat (szSetupFile, szSetupInf);
		i= _lopen (szSetupFile, OF_READ);
		if (i > 0)
			{
			_lclose (i);
			break;
			}
		else
			{
			strcpy (szDiskName, "CyrWin distribution disk #1");
			lpfnProc= MakeProcInstance (Floppy, hInst);
			i= DialogBox (hInst, "FLOPPY", hWnd, lpfnProc);
			FreeProcInstance (lpfnProc);
			if (i)
				{
				AddSlash (szSrcPath);
				}
			else
				return FALSE;
			}
		}				// 'for' get first disk

	strcpy (szSrcFile, szSrcPath); strcat (szSrcFile, szSetupInf);
	strcpy (szDstFile, szDstPath); strcat (szDstFile, szSetupInf);
	if (CopyErr (szSrcFile, szDstFile, bCopyFile (szSrcFile, szDstFile, "setup information file")))
		return FALSE;
	clear (szSetupFile);
	strcpy (szSetupFile, szDstPath); strcat (szSetupFile, szSetupInf);

	for (td= &instDefs [0]; td->val != NULL; td++)
		{
		GetKey ("defaults", td->name, b);
		if (b [0] == 't' || b [0] == 'T')
			*(td->val)= 1;
		else
			*(td->val)= 0;
		}

	WriteChanges (szSetupFile, "----");
	return TRUE;
	}
//
//	Start CyrWin installation
//
int	cwInst (HWND hWnd)
	{
	int	iRetVal= 0;
	int	i;
	FARPROC	lpfnProc;
	PSTR	cp;
	int	iErr;
	PSTR	cps;
	char	b [255];
	char	tmp1 [255];
	char	tmp2 [255];
	PSTR	pCard;
	PSTR	pFontSect;
	tag_fnt	dFont;
	tagDefs	*td;
	BOOL	bNeedCopy;

	hMainWnd= hWnd;
	clear (szDstPath);
	GetWindowsDirectory (szDstPath, sizeof szDstPath);
	AddSlash (szDstPath);
	strcpy (szSysPath, szDstPath); strcat (szSysPath, "SYSTEM\\");
	clear (szSrcPath);
	getcwd (szSrcPath, sizeof szSrcPath);
	AddSlash (szSrcPath);

	//
	// search cwsetup.inf file
	//
	/*
	for (;;)
		{
		strcpy (szSetupFile, szSrcPath);
		strcat (szSetupFile, szSetupInf);
		i= _lopen (szSetupFile, OF_READ);
		if (i > 0)
			{
			_lclose (i);
			break;
			}
		else
			{
			strcpy (szDiskName, "CyrWin distribution disk #1");
			lpfnProc= MakeProcInstance (Floppy, hInst);
			i= DialogBox (hInst, "FLOPPY", hWnd, lpfnProc);
			FreeProcInstance (lpfnProc);
			if (i)
				{
				AddSlash (szSrcPath);
				}
			else
				return FALSE;
			}
		}				// 'for' get first disk
	*/
	//
	// szSrcPath - first disk!
	// make win.bak and system.bak files
	// copy cwsetup.inf to Windows directory
	//
	if (bInstallSys || bLangInfo || bLoadAuto || bLoadFonts)
		{
		strcpy (szSrcFile, szDstPath); strcpy (szDstFile, szDstPath);
		strcat (szSrcFile, "WIN.INI"); strcat (szDstFile, "WIN.CW");
		if (CopyErr (szSrcFile, szDstFile, bCopyFile (szSrcFile, szDstFile, "make backup of win.ini file")))
			return FALSE;
		strcpy (szSrcFile, szDstPath); strcpy (szDstFile, szDstPath);
		strcat (szSrcFile, "SYSTEM.INI"); strcat (szDstFile, "SYSTEM.CW");
		if (CopyErr (szSrcFile, szDstFile, bCopyFile (szSrcFile, szDstFile, "make backup of system.ini file")))
			return FALSE;
		MessageBox (hWnd, "Your win.ini and system.ini files was renamed to win.cw and system.cw files", szTitle, MB_ICONINFORMATION|MB_OK);
		}

//	strcpy (szSrcFile, szSrcPath); strcat (szSrcFile, szSetupInf);
//	strcpy (szDstFile, szDstPath); strcat (szDstFile, szSetupInf);
//	if (CopyErr (szSrcFile, szDstFile, bCopyFile (szSrcFile, szDstFile, "setup information file")))
//		return FALSE;
//	clear (szSetupFile);
//	strcpy (szSetupFile, szDstPath); strcat (szSetupFile, szSetupInf);

	//
	// copy nesessary files
	//
	clear (cFilBuff);
	GetKey ("nfiles", NULL, cFilBuff);
	for (cp= cFilBuff; *cp; cp+= strlen (cp)+1)
		{
		GetKey ("nfiles", cp, szSetupStr);
		for (cps= szSetupStr; *cps == ':'; *cps++);
		clear (szDiskName); szDiskName [0]= *cps;
		GetKey ("disks", szDiskName, szDiskName);
		for (cps++; *cps == ':'; *cps++);
		clear (b);
		for (i= 0; *cps != ':'; i++)
			b [i]= *cps++; cps++;
		strcpy (tmp1, cps); _strup (tmp1);
		if (!strcmp (tmp1, "TRUE"))
			{
			bNeedCopy= TRUE;
			}
		else
			{
			for (td= instDefs; td->val != NULL; td++)
				{
				if (!strcmp (tmp1, td->name))
					{
					bNeedCopy= *(td->val);
					break;
					}
				}
			}

		if (!bNeedCopy)
			continue;
NeedRetry :	strcpy (szSrcFile, szSrcPath); strcat (szSrcFile, cp);
		strcpy (szDstFile, szDstPath); strcat (szDstFile, cp);
		iErr= (int) bCopyFile (szSrcFile, szDstFile, cps);
		if (iErr == 1)
			{
			lpfnProc= MakeProcInstance (Floppy, hInst);
			i= DialogBox (hInst, "FLOPPY", hMainWnd, lpfnProc);
			FreeProcInstance (lpfnProc);
			if (i)
				{
				AddSlash (szSrcPath); goto NeedRetry;
				}
			else
				return FALSE;
			}
		else if (iErr)
			{
			CopyErr (szSrcFile, szDstFile, iErr);
			return FALSE;
			}
		WriteChanges (szDstFile, "----");
		}				// 'for' - copy nesessary files

	if (bLoadAuto)
		{
		GetProfileString ("windows", "load", "", b, 255);
//		PutString ("readed string from win.ini [load]", b);
		if (!myssearch (b, "altkeyb.exe"))
			{
			clear (tmp2);
			strcpy (tmp2, b);
			strcat (b, " altkeyb.exe");
			strcpy (tmp1, "win.ini-windows-load-");
			strcat (tmp1, b); strcat (tmp1, "-"); strcat (tmp1, tmp2);
			clear (tmp2); strcpy (tmp2, szDstPath); strcat (tmp2, "ALTKEYB.EXE");
			WriteChanges (tmp2, tmp1);
			WriteProfileString ("windows", "load", b);
			clear (tmp1);
			}
		}
	if (bLangInfo)
		{
		WritePrivateProfileString ("keyboard", "oemansi.bin", "xlat866.bin", "system.ini");
		WritePrivateProfileString ("boot", "language.dll", "langcyr.dll", "system.ini");
		WriteChanges ("langinfo", "TRUE");
		}
	//
	// copy and install screen fonts
	//
	if (!bInstallSys)
		goto NoInstallSys;
	// determine type of video adapter, pCard -> type string

	GetPrivateProfileString ("boot", "fonts.fon", NULL, b, 255, "system.ini");
	for (pCard= szCards[0]; *pCard; pCard+= strlen (pCard)+1)
		{
		char * _strup (char *b);
		if (!strncmp ( _strup (b), pCard, strlen (pCard)))
			break;
		}
	if (!(*pCard))
		{
		MessageBox (hMainWnd, "Cannot identify video adapter", szTitle, NULL);
		return FALSE;
		}

	//
	// copy screen fonts
	//
	if (bInstallSys)
		{
		for (cp= szFonts [0], pFontSect= szSects [0]; *cp; cp+= 4)
			{
			strcpy (b, pCard); strcat (b, cp); strcat (b, ".FON");
			GetKey ("sfonts", b, szSetupStr);
			for (cps= szSetupStr; *cps == ':'; *cps++);
			clear (szDiskName); szDiskName [0]= *cps;
			GetKey ("disks", szDiskName, szDiskName);
NeedSfRetry :		strcpy (szSrcFile, szSrcPath); strcat (szSrcFile, b);
			strcpy (szDstFile, szDstPath); strcat (szDstFile, b);
			iErr= bCopyFile (szSrcFile, szDstFile, pFontName (szSrcFile));
			if (iErr == 1)
				{
				lpfnProc= MakeProcInstance (Floppy, hInst);
				i= DialogBox (hInst, "FLOPPY", hMainWnd, lpfnProc);
				FreeProcInstance (lpfnProc);
				if (i)
					{
					AddSlash (szSrcPath); goto NeedSfRetry;
					}
				else
					{
					return FALSE;
					}
				}		// 'if' iErr == 1
			else if (iErr)
				{
				CopyErr (szSrcFile, szDstFile, iErr);
				return FALSE;
				}
				WritePrivateProfileString ("boot", pFontSect, b,"system.ini");
//				PutString (pFontSect, b);
				pFontSect+= 13;
			}			// 'for' - copy screen fonts
		}

NoInstallSys:

	if (!bLoadFonts)
		goto NoInstallFonts;
	//
	// copy fonts (from [pfonts] section of 'cwsetup.inf'
	//
	clear (cFilBuff);
//	PutString ("install fonts", "");
	GetProfileString ("fonts", NULL, "", cFilBuff, sizeof cFilBuff);
	for (cp= cFilBuff; *cp; cp+= strlen (cp)+1)
		{
//		PutString ("check font", cp);
		if (bSearchCyr (cp))
			continue;
//		PutString ("this font is not cyrillic", "");
		clear (b); clear (tmp1); clear (tmp2);
		tmp1 [0]= ';';
		GetProfileString ("fonts", cp, "", b, sizeof b);
//		PutString ("font file name", b);
		strcpy (tmp1+1, cp); strcpy (tmp2, b); _strup (tmp2);
		//
		// tmp2 - contains font file name
		//
		//
		// Built cyrillic font name here
		//
		clear (cTmpStr);
		for (i= 0; tmp2 [i] != '.'; i++)
			cTmpStr [i]= tmp2 [i];
		strcat (cTmpStr, "CYR");
		strcpy (cTmpStr+8, ".FON");
//		PutString ("cyrillic font name", cTmpStr);
		clear (szDiskName);
		GetKey ("fonts", cTmpStr, szDiskName);
		if (!szDiskName [0])
			{
//			PutString ("font not found", ""); Halt ();
			continue;
			}
		GetKey ("disks", szDiskName, szDiskName);
NeedFRetry:	clear (szSrcFile); clear (szDstFile);
		strcpy (szSrcFile, szSrcPath);
		strcpy (szDstFile, szDstPath);
		strcat (szDstFile, cTmpStr);
		strcat (szSrcFile, cTmpStr);
//		PutString (szSrcFile, szDstFile);
		iErr= (int) bCopyFile (szSrcFile, szDstFile, pFontName (szSrcFile));
		if (iErr == 1)
			{
			lpfnProc= MakeProcInstance (Floppy, hInst);
			i= DialogBox (hInst, "FLOPPY", hMainWnd, lpfnProc);
			FreeProcInstance (lpfnProc);
			if (i)
				{
				AddSlash (szSrcPath); goto NeedFRetry;
				}
			else
				return FALSE;
			}
		else if (iErr)
			{
			CopyErr (szSrcFile, szDstFile, iErr);
			return FALSE;
			}
		//
		// font file cTmpStr copied Ok here
		// Read it FONTRES string and add it to win.ini file
		// and, if bCommentFont == TRUE, comment old font
		//

		strcpy (cTmpBuff, szDstPath);
		strcat (cTmpBuff, cTmpStr);
		if ((cps= pFontName (cTmpBuff)) == NULL)
			{
			return FALSE;
			}
//		PutString (cps, cTmpStr); Halt ();
		WriteProfileString ("fonts", cps, cTmpStr);
		if (bCommentFonts)
			{
			WriteProfileString ("fonts", tmp1+1, NULL);
			WriteProfileString ("fonts", tmp1, tmp2);
			}
		}
NoInstallFonts:
	//
	// Protect keyboard driver here
	//
#ifdef	_Protect_
	strcpy (b, szDstPath); strcat (b, "ALTKEYB.EXE");
	i= toupper (szSrcPath [0])-'A';
//	PutInt ("drive Id for protection is", i);
	if (i > 3)
		i= 0;
	iErr= checkdsk (i);
	if (iErr == 0)
		{
		if (Protect (b) != 1)
			{
			SetCursor (hArrow);
			MessageBox (GetFocus (), "Cannot correctly install keyboard driver", szTitle, MB_ICONSTOP|MB_OK);
			return FALSE;
			}
		}
#endif

	return TRUE;
	}




BOOL	FAR PASCAL Floppy (hDlg, wMsg, wParam, lParam)
	register HWND hDlg;
	register WORD wMsg;
	WORD	wParam;
	LONG	lParam;
	{
	switch (wMsg)
		{
	case WM_INITDIALOG:
		SetDlgItemText (hDlg, IDF_TEXT, szDiskName);
		SetDlgItemText (hDlg, IDF_EDIT, szSrcPath);
		SetFocus (GetDlgItem (hDlg, IDF_EDIT));
		return TRUE;
	case WM_COMMAND:
		switch (wParam)
			{
		case IDOK:
			clear (szSrcPath);
			GetDlgItemText (hDlg, IDF_EDIT, szSrcPath, sizeof szSrcPath);
			EndDialog (hDlg, TRUE);
			SetCursor (hWait);
			return TRUE;
		case IDCANCEL:
			EndDialog (hDlg, FALSE);
			SetCursor (hWait);
			return TRUE;
			}
		break;
		}
	return FALSE;
	}

BOOL	FAR PASCAL Options (hDlg, wMsg, wParam, lParam)
	register HWND hDlg;
	register WORD wMsg;
	WORD wParam;
	LONG	lParam;
	{
	static int bTmpCFonts;
	static int bTmpSysFonts;

	switch (wMsg)
		{
	case WM_INITDIALOG:
		bTmpCFonts= bCommentFonts;
		bTmpSysFonts= bInstallSys;
		CheckDlgButton (hDlg, IDO_CFONTS, bCommentFonts);
		CheckDlgButton (hDlg, IDO_SYSFONTS, bInstallSys);
		return TRUE;
	case WM_COMMAND:
		switch (wParam)
			{
		case IDO_OK:
			bCommentFonts= bTmpCFonts;
			bInstallSys= bTmpSysFonts;
			SetCursor (hWait);
			EndDialog (hDlg, TRUE);
			return FALSE;
		case IDO_CAN:
			SetCursor (hWait);
			EndDialog (hDlg, FALSE);
			return FALSE;
		case IDO_CFONTS:
			bTmpCFonts^= 1;
			CheckDlgButton (hDlg, IDO_CFONTS, bTmpCFonts);
			break;
		case IDO_SYSFONTS:
			bTmpSysFonts^= 1;
			CheckDlgButton (hDlg, IDO_SYSFONTS, bTmpSysFonts);
			break;
			}
		break;
		}
	return FALSE;
	}

//
//	Copy file pSrc -> pDst and display message 'copying' in hWnd window
//
//	return codes:
//		0 - Ok
//		1 - cannot open pSrc file
//		2 - cannot create pDst file
//		3 - error reading source file
//		4 - error writing destination file
//
int	bCopyFile (pSrc, pDst, pMessage)
	PSTR	pSrc;				// src file name
	PSTR	pDst;				// dst file name
	PSTR	pMessage;			// file description
						// (of == NULL, then
						// display file name)
	{
	short	fSrc, fDst;
	int	iReaded;
	int	iRetVal= 0;

	if (pMessage == NULL)
		pMessage= pSrc;

	SetDlgItemText (hMainWnd, IDC_HTEXT, "Copying file");
	SetDlgItemText (hMainWnd, IDC_TEXT, pMessage);

	if ((fSrc= _lopen (pSrc, OF_READ)) < 0)
		{
		iRetVal= 1;
		goto CopyRet;
		}

	_lclose (_lcreat (pDst, 0));
	if ((fDst= _lopen (pDst, OF_WRITE)) < 0)
		{
		iRetVal= 2;
		goto CopyRet;
		}

	do
		{
#ifdef	_Fast_
		iReaded= _lread (fSrc, cCpBuff, sizeof cCpBuff);
#else
		iReaded= _lread (fSrc, cCpBuff, 10);
#endif
		if (iReaded < 0)
			{
			iRetVal= 3;
			goto CopyRet;
			}
		if (_lwrite (fDst, cCpBuff, iReaded) != iReaded)
			{
			iRetVal= 4;
			goto CopyRet;
			}
		}
	while (iReaded > 0);
CopyRet	:
	_lclose (fSrc);
	_lclose (fDst);
	SetDlgItemText (hMainWnd, IDC_HTEXT, "");
	SetDlgItemText (hMainWnd, IDC_TEXT, "");
	return iRetVal;
	}

//
//	Display error message
//
char	szErrMessage [256];

int	CopyErr (pSrc, pDst, iError)
	PSTR	pSrc;
	PSTR	pDst;
	int	iError;
	{

	switch (iError)
		{
	case 0:
		return 0;
	case 1:
		strcpy (szErrMessage, "Error opening file ");
		strcat (szErrMessage, pSrc);
		break;
	case 2:
		strcpy (szErrMessage, "Cannot create file ");
		strcat (szErrMessage, pDst);
		break;
	case 3:
		strcpy (szErrMessage, "Error reading file ");
		strcat (szErrMessage, pSrc);
		break;
	case 4:
		strcpy (szErrMessage, "Error writing file ");
		strcat (szErrMessage, pDst);
		break;
	default:
		strcpy (szErrMessage, "unknown error while copying");
		break;
		}
	MessageBox (hMainWnd, szErrMessage, szTitle, MB_ICONSTOP|MB_OK);
ErrRet	:
	return iError;
	}

//
//	_strup
//
PSTR	_strup (char *b)
	{
	register int i;

	for (i= 0; i< strlen (b); i++)
		b [i]= toupper (b [i]);
	return b;
	}

//
//	search s2 in s1 (of Ok, returns TRUE)
//
BOOL	myssearch (PSTR s1, PSTR s2)
	{
	register int i;

	_strup (s1); _strup (s2);
	for (i= 0; strlen (s1+i) >= strlen (s2); i++)
		{
		if (!strncmp (s1+i, s2, strlen (s2)))
			{
			return i+1;
			}
		}

	return FALSE;
	}

char	patch []= "FONTRES";
//
//	returns null terminated string with font description
//
PSTR	pFontName (PSTR pFont)
	{
	short flabel;
	register int i;

	clear (cCpBuff);
	flabel= _lopen (pFont, OF_READ);
	if (flabel < 0)
		return cCpBuff;
	_lread (flabel, cCpBuff, sizeof cCpBuff);
	_lclose (flabel);

	for (i= 0; i< sizeof cCpBuff; i++)
		{
		if (!strncmp (cCpBuff+i, patch, strlen (patch)))
			{
			for (i+= sizeof patch;i< sizeof cCpBuff; i++)
				{
				if (cCpBuff [i] == ':')
					{
					for (i++;i< sizeof cCpBuff; i++)
						{
						if (cCpBuff [i] != ' ')
							{
							return cCpBuff+i;
							}
						}
					}
				}
			}

		}
	return NULL;
	}


char	szCyrillic []= "CYRILLIC";
char	szSearch [256];

BOOL	bSearchCyr (char *cpStr)
	{
	int	i;

	strcpy (szSearch, cpStr); _strup (szSearch);

	for (i= 0; i< strlen (szSearch) - sizeof szCyrillic - 1; i++)
		{
		if (!strncmp (szSearch+i, szCyrillic, strlen (szCyrillic)))
			{
			return TRUE;
			}
		}
	return FALSE;
	}

//
//	Remove all CyrWin files and restore saved win.ini and system.ini
//	files
//
BOOL	bUninstall (HWND hWnd)
	{
	int	iRetVal= 0;
	int	i;
	FARPROC	lpfnProc;
	PSTR	cp;
	int	iErr;
	PSTR	cps;
	char	b [255];
	char	tmp1 [255];
	char	tmp2 [255];
	PSTR	pCard;
	PSTR	pFontSect;
	tag_fnt	dFont;
	tagDefs	*td;

	if (MessageBox (hWnd, "Are you sure to UNINSTALL CyrWin ?", szTitle, MB_ICONQUESTION|MB_YESNOCANCEL) != IDYES)
		return FALSE;
	//
	// uninstall cyrwin from the windows directory
	//
	GetWindowsDirectory (szDstPath, sizeof szDstPath); AddSlash (szDstPath);
	strcpy (szSetupFile, szDstPath); strcat (szSetupFile, szSetupInf);
	if ((i= _lopen (szSetupFile, OF_READ)) < 0)
		{
		MessageBox (hWnd, "Cannot find cwsetup.inf\n"
				  "Uninstall failed", szTitle, MB_ICONSTOP|MB_OK);
		return FALSE;
		}
	_lclose (i);
	//
	// ensure that .cw files are Ok
	//
	strcpy (b, szDstPath); strcat (b, "win.cw");
	if ((i= _lopen (b, OF_READ)) < 0)
		{
		MessageBox (hWnd, "Cannot find win.cw\n"
				  "Uninstall failed", szTitle, MB_ICONSTOP|MB_OK);
		return FALSE;
		}
	_lclose (i);
	strcpy (b, szDstPath); strcat (b, "system.cw");
	if ((i= _lopen (b, OF_READ)) < 0)
		{
		MessageBox (hWnd, "Cannot find system.cw\n"
				  "Uninstall failed", szTitle, MB_ICONSTOP|MB_OK);
		return FALSE;
		}
	_lclose (i);

	//
	// delete cyrwin changes from win.ini and system.ini files
	//

	// 1. delete altkeyb.exe from the [windows]-load entry of win.ini

	clear (b);
	GetProfileString ("windows", "load", "", b, sizeof b);
	if (i= myssearch (_strup (b), "ALTKEYB.EXE"))
		{
//		PutInt ("index", i); PutString ("in", b); Halt ();
		clear (tmp1); strncpy (tmp1, b, i-1); strcpy (tmp1, b+i+12);
//		PutString (b, tmp1); Halt ();
		WriteProfileString ("windows", "load", tmp1);
		}

	// 2. restore system fonts in system.ini file
	// (copy from .cw files)

	GetPrivateProfileString ("boot", "fonts.fon", "", b, 255, "system.cw");
	WritePrivateProfileString ("boot", "fonts.fon", b,"system.ini");
	GetPrivateProfileString ("boot", "oemfonts.fon", "", b, 255, "system.cw");
	WritePrivateProfileString ("boot", "oemfonts.fon", b,"system.ini");
	GetPrivateProfileString ("boot", "fixedfon.fon", "", b, 255, "system.cw");
	WritePrivateProfileString ("boot", "fixedfon.fon", b,"system.ini");

	// 3. restore langdll and oem2ansi table in system.ini file
	// (copy from .cw files)
	GetPrivateProfileString ("boot", "language.dll", "", b, 255, "system.cw");
	WritePrivateProfileString ("boot", "language.dll", b,"system.ini");

	GetPrivateProfileString ("boot", "oemansi.bin", "", b, 255, "system.cw");
	WritePrivateProfileString ("boot", "oemansi.bin", b,"system.ini");

	// 3. restore fonts section in win.ini file
	// (copy from .cw files)

	// clear fonts section in win.ini file

	GetProfileString ("fonts", NULL, "", cFilBuff, sizeof cFilBuff);
	for (cp= cFilBuff; *cp; cp+= strlen (cp)+1)
		{
		WriteProfileString ("fonts", cp, NULL);
		}
	
	//
	// copy fonts from old file
	//
	GetPrivateProfileString ("fonts", NULL, "", cFilBuff, sizeof cFilBuff, "win.cw");
	for (cp= cFilBuff; *cp; cp+= strlen (cp)+1)
		{
		GetPrivateProfileString ("fonts", cp, "", b, sizeof b, "win.cw");
		WriteProfileString ("fonts", cp, b);
		}
	//
	// delete CyrWin files
	//
	strcpy (b, szDstPath); strcat (b, "win.cw"); unlink (b);
	strcpy (b, szDstPath); strcat (b, "system.cw"); unlink (b);

	GetKey ("nfiles", NULL, cFilBuff);
	for (cp= cFilBuff; *cp; cp+= strlen (cp)+1)
		{
		strcpy (b, szDstPath); strcat (b, cp); unlink (b);
		}

	strcpy (b, szDstPath); strcat (b, szSetupInf); unlink (b);

	return TRUE;
	}

#ifdef	_Protect_

#include "io.h"
#include "fcntl.h"

char	cKeys[]= { "Ole" };

short	Protect (char *file)
	{
	short	f, c;
	char	*cp;
	unsigned int BiosChk= 0;
	int fleng;
	int i;

	f= open (file, O_RDWR|O_BINARY);
	clear (cCpBuff);
	fleng= read (f, cCpBuff, sizeof cCpBuff);
	if (f < 0)
		return 0;

	for (i= 0, cp= cKeys; i< fleng ;i++)
		{
		if (cCpBuff [i] == *cp)
			cp++;
		else
			cp= cKeys;
		if (!*cp)
			break;
		}
	if (!*cp)
		{
		BiosChk= BiosSum ();
		lseek (f, (LONG) i+3, SEEK_SET);
		write (f, &BiosChk, 2);
		(short) BiosChk= 1;
		}
	close (f);
	return BiosChk;
	}


#endif

/* *** */