
#include "worm.h"

/* --------------------------------------------------------------------- */

BOOL WormInit(HANDLE hInstance)
{
HANDLE hMemory;
PWNDCLASS pWndClass;
BOOL bSuccess;

hMemory = LocalAlloc(LPTR, sizeof(WNDCLASS));
pWndClass = (PWNDCLASS) LocalLock(hMemory);

pWndClass->style = NULL;
pWndClass->lpfnWndProc = WormWndProc;
pWndClass->hInstance = hInstance;
pWndClass->hIcon = LoadIcon(hInstance, "worm");
pWndClass->hCursor = LoadCursor(NULL, IDC_CROSS);
pWndClass->hbrBackground = GetStockObject(WHITE_BRUSH);
pWndClass->lpszMenuName = (LPSTR) NULL;
pWndClass->lpszClassName = (LPSTR) WORM_APPNAME;
bSuccess = RegisterClass(pWndClass);
LocalUnlock(hMemory);
LocalFree(hMemory);

return(bSuccess);
}
/* --------------------------------------------------------------------- */
/* EOF */