
#include "worm.h"

BOOL FAR PASCAL AboutDlgProc(HWND hDlg, unsigned message, WORD wParam,
                             LONG lParam)
{
switch(message)
    {
    case WM_INITDIALOG:
        return (TRUE);
    case WM_COMMAND:
        if (wParam == IDOK)
            {
            EndDialog(hDlg, NULL);
            return (TRUE);
       }
        break;
    }
return(FALSE);
}
