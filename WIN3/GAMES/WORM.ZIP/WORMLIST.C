
#include "worm.h"

RING *h;
RING* InitWormList(void)
{
 RING *t, *p;
 int i;
 POINT point;

 point.x = 200; //GetSize();
 point.y = 0; //GetSize();

 h = malloc(sizeof(RING));
 h->center = point;
 h->state = INACTIVE;
 h->color = 0;
 h->next = h;

 p = h;

 for(i = 1; i < GetRings(); i++) {
   t = p;
   p = malloc(sizeof(RING));
    p->center = point;
    p->state = INACTIVE;
    p->color = 0;
    t->next = p;
 }

 p->next = h;
 return h;
} /* InitWormList */

/* -------------------------------------------------------------------- */

void FreeWormList(void)
{
 RING *t, *p;
 int i;

 p = h;

 for (i=0; i < GetRings(); i++) {
  t = p->next;
  free(p);
  p = t;
 }

}

/* EOF */