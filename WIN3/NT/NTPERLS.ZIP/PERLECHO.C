/*
 * Echo for NT.  Relies on the expansion done by the library
 * startup code. 
 */

#include <stdio.h>
#include <string.h>

int
main(int argc, char *argv[])
{
    int i;

    for (i = 1; i < argc; i++) {
	if (i > 1)
	    putchar (' ');
	fputs(strlwr(argv[i]), stdout);
    }
    return 0;
}
