/*
 *  Copyright (c) 1993, Intergraph Corporation
 *
 *  You may distribute under the terms of either the GNU General Public
 *  License or the Artistic License, as specified in the perl README file.
 *
 * This file is used to set up predefined variables and subroutines for
 * use by perl on the NT operating system.
 */

#include "EXTERN.h"
#include "perl.h"

enum UserVars {
    UV_LoginName,
    UV_NodeName,
    //
    // File system type for current directory
    //
    UV_FSTYPE,
    //
    // number of variables defined
    //
    UV_NUMVARS
};

enum UserSubs {
    US_RegCloseKey,
    US_RegConnectRegistry,
    US_RegCreateKey,
    US_RegCreateKeyEx,
    US_RegDeleteKey,
    US_RegDeleteValue,
    US_RegEnumKey,
    US_RegEnumKeyEx,
    US_RegEnumValue,
    US_RegFlushKey,
    US_RegGetKeySecurity,
    US_RegLoadKey,
    US_RegNotifyChangeKeyValue,
    US_RegOpenKey,
    US_RegOpenKeyEx,
    US_RegQueryInfoKey,
    US_RegQueryValue,
    US_RegQueryValueEx,
    US_RegReplaceKey,
    US_RegRestoreKey,
    US_RegSaveKey,
    US_RegSetKeySecurity,
    US_RegSetValue,
    US_RegSetValueEx,
    US_RegUnloadKey,
    US_Spawn,
    US_NUMSUBS
};

static char *UserSubNames[] = {
    "RegCloseKey",
    "RegConnectRegistry",
    "RegCreateKey",
    "RegCreateKeyEx",
    "RegDeleteKey",
    "RegDeleteValue",
    "RegEnumKey",
    "RegEnumKeyEx",
    "RegEnumValue",
    "RegFlushKey",
    "RegGetKeySecurity",
    "RegLoadKey",
    "RegNotifyChangeKeyValue",
    "RegOpenKey",
    "RegOpenKeyEx",
    "RegQueryInfoKey",
    "RegQueryValue",
    "RegQueryValueEx",
    "RegReplaceKey",
    "RegRestoreKey",
    "RegSaveKey",
    "RegSetKeySecurity",
    "RegSetValue",
    "RegSetValueEx",
    "RegUnloadKey",
    "Spawn"
};

#define MAGICVAR(name, idx) uf.uf_index = idx, magicname(name, &uf, sizeof(uf))
#define TMPBUFSZ 512

#define GOOD_RETURN(x) (x == ERROR_SUCCESS)
#define BAD_RETURN(x) (x != ERROR_SUCCESS)

#define SET_GOOD_RETURN do {st[0] = &str_yes;} while(0)
#define SET_BAD_RETURN do {st[0] = &str_no; errno = retval; } while (0)

#define SET_RETURN_VALUE(retval) \
    if (GOOD_RETURN(retval)) SET_GOOD_RETURN; else SET_BAD_RETURN;

static int userset(int, STR *);
static int userval(int, STR *);
static int usersub(int, int, int);

SUBR *make_usub(char *, int, int, char *);

int
userinit()
{
    int i;
    struct ufuncs uf;
    char *filename = "usersub.c";

    uf.uf_set = userset;
    uf.uf_val = userval;

    //
    // Instantiate our magic variables
    //

    //
    // convenient
    //
    MAGICVAR("LoginName", UV_LoginName);
    MAGICVAR("NodeName", UV_NodeName);
    MAGICVAR("FsType", UV_FSTYPE);

    //
    // Now make our user subroutines available
    //

    for (i = 0; i < US_NUMSUBS; i++)
	make_usub(UserSubNames[i], i, (int) usersub, filename);

    return 0;
}

char *NTLoginName = NULL;
char *NTNodeName = NULL;
char NTFsType[80];

int
userset (int idx, STR *str)
{
    int retval = 0;

    switch((enum UserVars) idx) {
      case UV_LoginName:
      case UV_NodeName:
      case UV_FSTYPE:
	warn ("Attempt to set read-only system variable\n");
	retval = -1;
	break;
      default:
	fatal("Unknown user variable id passed to userset: %d\n", idx);
    }
    return retval;
}

int
userval (int idx, STR *str)
{
    char buffer[TMPBUFSZ];
    long len;

    switch((enum UserVars)idx) {

      case UV_LoginName:
	if (!NTLoginName) {
	    len = 512;
	    if (GetUserName(buffer, &len)) {
		New(1901, NTLoginName, len+1, char);
		strncpy(NTLoginName, buffer, len);
		NTLoginName[len] = '\0';
	    }
	    else {
		NTLoginName = "<Unknown>";
	    }
	}
	str_set(str, NTLoginName);
	break;

      case UV_NodeName:
	if (!NTNodeName) {
	    len = 512;
	    if (GetComputerName(buffer, &len)) {
		New(1902, NTNodeName, len+1, char);
		strncpy(NTNodeName, buffer, len);
		NTNodeName[len] = '\0';
	    }
	    else {
		NTNodeName = "<Unknown>";
	    }
	}
	str_set(str, NTNodeName);
	break;

      case UV_FSTYPE:
      {
	  char currdir[512];
	  char root[512];
	  char *filename;
	  DWORD volsiz = 512, dirsz = 512;
	  DWORD serial, maxnamelen, flags, fsnamelen;

	  if (dirsz = GetFullPathName(".", 512, currdir, &filename)) {
	      strcpy(root, currdir);
	      if ((filename = strchr(root, '\\')))
		  *++filename = '\0';
	  }

	  if (GetVolumeInformation(root, currdir, 512, &serial, &maxnamelen,
				   &flags, NTFsType, 80))
	      str_set(str, NTFsType);
	  else
	      str_set(str, "<Unknown>");
      }
	break;
      default:
	fatal ("Unknown user variable value (%d)\n", idx);
    }
    return 0;
}

static void do_close_key (int, STR **);
static void do_connect_registry (int, enum UserSub, STR **);
static void do_create_key (int, enum UserSub, STR **);
static void do_delete_key (int, STR **);
static void do_delete_value (int, STR **);
static void do_enum_key (int, enum UserSub, STR **);
static void do_enum_value (int, STR **);
static void do_flush_key (int, STR **);
static void do_get_key_security (int, STR **);
static void do_load_key (int, STR **);
static void do_notify_change_key_value (int, STR **);
static void do_open_key (int, enum UserSub, STR **);
static void do_query_info_key (int, STR **);
static void do_query_value (int, enum UserSub, STR **);
static void do_replace_key (int, STR **);
static void do_restore_key (int, STR **);
static void do_save_key (int, STR **);
static void do_set_key_security (int, STR **);
static void do_set_value (int, enum UserSub, STR **);
static void do_unload_key (int, STR **);
static time_t ft2timet (FILETIME *);
static void do_ntspawn (int, STR **);

int
usersub (int idx, int sp, int items)
{
    STR **st = stack->ary_array + sp;

    switch ((enum UserSub) idx) {

      case US_RegCloseKey:

	//
	// Close a previously opened key handle to the
	// registry
	//

	do_close_key(items, st);
	break;

      case US_RegConnectRegistry:

	//
	// Connect to a remote registry
	//

	do_connect_registry(items, idx, st);
	break;


      case US_RegCreateKey:
      case US_RegCreateKeyEx:

	//
	// create or open a key in the registry
	//

	do_create_key(items, idx, st);
	break;

      case US_RegDeleteKey:

	//
	// delete a key from the registry
	//

	do_delete_key(items, st);
	break;

      case US_RegDeleteValue:

	//
	// Delete a value from a key
	//

	do_delete_value(items, st);
	break;

      case US_RegEnumKey:
      case US_RegEnumKeyEx:

	//
	// Iterate through a key, listing the subkeynames. $idx starts
	// at zero and is incremented for each call.
	//
	do_enum_key(items, idx, st);
	break;


      case US_RegEnumValue:
	do_enum_value(items, st);
	break;

      case US_RegFlushKey:
	do_flush_key(items, st);
	break;

      case US_RegGetKeySecurity:
	do_get_key_security(items, st);
	break;

      case US_RegLoadKey:
	do_load_key(items, st);
	break;

      case US_RegNotifyChangeKeyValue:
	do_notify_change_key_value(items, st);
	break;

      case US_RegOpenKey:
      case US_RegOpenKeyEx:

	//
	// Open a key into the registry and return a handle for that
	// key.
	//

	do_open_key(items, idx, st);
	break;

      case US_RegQueryInfoKey:
	do_query_info_key(items, st);
	break;

      case US_RegQueryValue:
      case US_RegQueryValueEx:

	//
	// Query a key/valuename for it\'s value
	//

	do_query_value(items, idx, st);
	break;

      case US_RegReplaceKey:
	do_replace_key(items, st);
	break;

      case US_RegRestoreKey:
	do_restore_key (items, st);
	break;

      case US_RegSaveKey:
	do_save_key (items, st);
	break;

      case US_RegSetKeySecurity:
	do_set_key_security(items, st);
	break;

      case US_RegSetValue:
      case US_RegSetValueEx:
	do_set_value(items, idx, st);
	break;

      case US_RegUnloadKey:
	do_unload_key (items, st);
	break;

      case US_Spawn:
	do_ntspawn (items, st);
	break;

      default:
	fatal ("unknown usersub index: %d\n", idx);
    }
    return (int) sp;
}


static void
do_close_key (int items, STR **st)
{
    HKEY hkey;
    long retval;

    if (items != 1) {
	fatal("usage: &RegCloseKey($hkey)\n");
    }

    hkey = (HKEY) ((unsigned long) str_gnum(st[1]));
    retval = RegCloseKey(hkey);
    SET_RETURN_VALUE(retval);
}


static void
do_connect_registry (int items, enum UserSub idx, STR **st)
{
    HKEY hkey, handle;
    char *subkey;
    long retval;

    if (items != 3) {
	fatal ("usage: &RegConnectRegistry($machine, $hkey, $handle)\n");
    }
    subkey = (char *) str_get(st[1]);
    hkey = (HKEY) ((unsigned long) str_gnum(st[2]));
    retval = RegConnectRegistry(subkey, hkey, &handle);
    if (BAD_RETURN(retval)) {
	st[3] = &str_undef;
	SET_BAD_RETURN;
    }
    else {
	str_numset(st[3], (double) ((unsigned long) handle));
	SET_GOOD_RETURN;
    }
}

static void
do_create_key (int items, enum UserSub idx, STR **st)
{
    long retval;
    HKEY hkey, handle;
    char *subkey;
    char *class;
    DWORD options, disposition;
    REGSAM sam;
    SECURITY_ATTRIBUTES sa, *psa;

    if (idx == US_RegCreateKey && items != 3) {
	fatal("usage: &%s($hkey, $subkey, $handle)\n", UserSubNames[idx]);
    }
    else if (idx == US_RegCreateKeyEx && items != 9) {
	fatal("usage: &%s($hkey, $subkey, $reserved, $class, $options, $sam, "
	      "$security, $handle, $disposition)\n", UserSubNames[idx]);
    }
    hkey = (HKEY) ((unsigned long) str_gnum(st[1]));
    subkey = (char *) str_get(st[2]);
    if (idx == US_RegCreateKeyEx) {
	class = (char *) str_get(st[4]);
	options = (DWORD) ((unsigned long) str_gnum(st[5]));
	sam = (REGSAM) ((unsigned long) str_gnum(st[6]));
	if (st[7]->str_nok) 
	    psa = (SECURITY_ATTRIBUTES *) ((unsigned long)str_gnum(st[7]));
	else
	    psa = (SECURITY_ATTRIBUTES *) str_get(st[7]);
    }
    else {
	class = (char *) NULL;
	options = REG_OPTION_NON_VOLATILE;
	sam = KEY_ALL_ACCESS;
	psa = NULL;
    }

    SET_GOOD_RETURN;
    retval =  RegCreateKeyEx(hkey, subkey, 0, class, options, sam,
			     psa, &handle, &disposition);

    if (BAD_RETURN(retval)) {
	SET_BAD_RETURN;
    }
    else {
	if (idx == US_RegCreateKeyEx) {
	    str_nset(st[7], (char *) &sa, sizeof(sa));
	    str_numset(st[8],(double) ((unsigned long) handle));
	    str_numset(st[9],(double) ((unsigned long) disposition));
	}
	else {
	    str_numset(st[3],(double) ((unsigned long) handle));
	}
    }
}

static void
do_delete_key (int items, STR **st)
{
    HKEY hkey;
    char *subkey;
    long retval;

    if (items != 2) {
	fatal("&RegDeleteKey($hkey, $subkey)\n");
    }
    hkey = (HKEY) ((unsigned long) str_gnum(st[1]));
    subkey = (char *) str_get(st[2]);
    retval = RegDeleteKey(hkey, subkey);
    SET_RETURN_VALUE(retval);
}

static void
do_delete_value (int items, STR **st)
{
    HKEY hkey;
    char *valname;
    long retval;

    if (items != 2) {
	fatal("&RegDeleteValue($hkey, $valname)\n");
    }
    hkey = (HKEY) ((unsigned long) str_gnum(st[1]));
    valname = (char *) str_get(st[2]);
    retval = RegDeleteValue(hkey, valname);
    SET_RETURN_VALUE(retval);
}

static void
do_enum_key(int items, enum UserSub idx, STR **st)
{
    HKEY hkey;
    DWORD i, keysz, classsz;
    char keybuffer[TMPBUFSZ];
    char classbuffer[TMPBUFSZ];
    long retval;
    FILETIME filetime;

    if (idx == US_RegEnumKey && items != 3) {
	fatal ("usage: &%s($hkey, $idx, $subkeyname)\n",
	       UserSubNames[idx]);
    }
    if (idx == US_RegEnumKeyEx && items != 6) {
	fatal ("usage: &%s($hkey, $idx, $subkeyname, $reserved, $class, $time)\n",
	       UserSubNames[idx]);
    }

    hkey = (HKEY) ((unsigned long) str_gnum(st[1]));
    i = (DWORD) ((unsigned long) str_gnum(st[2]));
    keysz = sizeof(keybuffer);
    classsz = sizeof(classbuffer);
    retval = RegEnumKeyEx(hkey, i, keybuffer, &keysz, 0,
			  classbuffer, &classsz, &filetime);
    if (BAD_RETURN(retval)) {
	SET_BAD_RETURN;
    }
    else {
	str_set(st[3], keybuffer);
	if (idx == US_RegEnumKeyEx) {
	    str_set(st[5], classbuffer);
	    //
	    // do time!
	    //
	    str_numset(st[6], (double) ft2timet(&filetime));
	}
	SET_GOOD_RETURN;
    }
}

static void
do_enum_value(int items, STR **st)
{
    HKEY hkey;
    DWORD value, type, namesz, valsz;
    long retval;
    static HANDLE last_hkey = INVALID_HANDLE_VALUE;
    static char *valbuf = NULL, *namebuf = NULL;
    static DWORD maxvalsz, maxnamesz;

    if (items != 6) {
	fatal("usage: &RegEnumValue($hkey, $i, $name, $reserved, $type, $value)\n");
    }

    hkey = (HANDLE) ((unsigned long) str_gnum(st[1]));

    //
    // If this is a new key, find out how big the maximum
    // name and value sizes are and allocate space for them.
    // Free any old storage and set the old key value to the
    // current key.
    //

    if (hkey != last_hkey) {
	char class[TMPBUFSZ];
	DWORD classsz, subkeys, maxsubkey, maxclass, values, salen;
	FILETIME ft;
	classsz = TMPBUFSZ;
	retval = RegQueryInfoKey(hkey, class, &classsz, 0,
				 &subkeys, &maxsubkey, &maxclass,
				 &values, &maxnamesz, &maxvalsz,
				 &salen, &ft);
	if (BAD_RETURN(retval)) {
	    SET_BAD_RETURN;
	    return;
	}
	if (valbuf) Safefree(valbuf);
	New(1903, valbuf, ++maxvalsz, char);
	if (namebuf) Safefree(namebuf);
	New(1903, namebuf, ++maxnamesz, char);
	last_hkey = hkey;
    }

    value = (DWORD) str_gnum(st[2]);

    namesz = maxnamesz;
    valsz = maxvalsz;
    retval = RegEnumValue(hkey, value, namebuf, &namesz, 0,
			  &type, (LPBYTE) valbuf, &valsz);
    if (BAD_RETURN(retval)) {
	SET_BAD_RETURN;
    }
    else {
	str_set(st[3], namebuf);
	str_numset(st[5], (double) type);
	//
	// for strings, valsz includes the null terminator, so we\'ll
	// treat them special when we set the returned value.
	//
	switch (type) {
	  case REG_SZ:
	  case REG_EXPAND_SZ:
	  case REG_MULTI_SZ:
	    str_nset(st[6], valbuf, valsz-1);
	    break;
	  default:
	    str_nset(st[6], valbuf, valsz);
	}
	SET_GOOD_RETURN;
    }
}

static void
do_flush_key (int items, STR **st)
{
    HKEY hkey;
    long retval;

    if (items != 1) {
	fatal("usage: &RegFlushKey($hkey)\n");
    }
    hkey = (HANDLE) ((unsigned long) str_gnum(st[1]));
    retval = RegFlushKey(hkey);
    SET_RETURN_VALUE(retval);
}


static void
do_get_key_security(int items, STR **st)
{
    HKEY hkey;
    SECURITY_INFORMATION si;
    SECURITY_DESCRIPTOR sd;
    DWORD sdsz;
    long retval;

    if (items != 3) {
	fatal("usage: &RegGetKeySecurity($hkey, $security_info, $security_descriptor);\n");
    }
    hkey = (HKEY) ((unsigned long) str_gnum(st[1]));
    si = (SECURITY_INFORMATION) str_gnum(st[2]);
    sdsz = sizeof(sd);
    retval = RegGetKeySecurity (hkey, si, &sd, &sdsz);
    if (GOOD_RETURN(retval)) {
	str_nset(st[3], &sd, sdsz);
	SET_GOOD_RETURN;
    }
    else {
	SET_BAD_RETURN;
    }
}

static void
do_load_key (int items, STR **st)
{
    HKEY hkey;
    char *subkey, *filename;
    long retval;

    if (items != 3) {
	fatal("usage: &RegLoadKey($hkey, $subkey, $filename);\n");
    }
    hkey = (HKEY) ((unsigned long) str_gnum(st[1]));
    subkey = (char *) str_get(st[2]);
    filename = (char *) str_get(st[3]);
    retval = RegLoadKey(hkey, subkey, filename);
    SET_RETURN_VALUE(retval);
}

static void
do_notify_change_key_value (int items, STR **st)
{
    fatal("&RegNotifyChangeKeyValue not yet implemented!\n");
}


static void
do_open_key(int items, enum UserSub idx, STR **st)
{
    HKEY hkey, handle;
    char *subkey;
    REGSAM sam;
    STR *str;
    long retval;

    if (idx == US_RegOpenKey && items != 3) {
	fatal("usage: &RegOpenKey ($hkey, $subkey, $handle);\n");
    }
    if (idx == US_RegOpenKeyEx && items != 5) {
	fatal("usage: &RegOpenKeyEx ($hkey, $subkey, $reserved, $sam, $handle);\n");
    }
    hkey = (HKEY) ((unsigned long) str_gnum(st[1]));
    subkey = (char *) str_get(st[2]);
    if (idx == US_RegOpenKey) {
	sam = KEY_ALL_ACCESS;
	str = st[3];
    }
    else {
	sam = (REGSAM) ((unsigned long) str_gnum(st[4]));
	str = st[5];
    }
    retval = RegOpenKeyEx(hkey, subkey, 0, sam, &handle);

    if (BAD_RETURN(retval)) {
	SET_BAD_RETURN;
    }
    else {
	str_numset(str, (double) ((unsigned long) handle));
	SET_GOOD_RETURN;
    }
}

static void
do_query_info_key (int items, STR **st)
{
    HKEY hkey;
    char class[TMPBUFSZ];
    DWORD subkeys, maxsubkey, maxclass, values, maxvalname, maxvaldata;
    DWORD seclen, classsz;
    FILETIME ft;
    long retval;

    if (items != 11) {
	fatal("usage: &RegQueryInfoKey($hkey, $class, $numsubkeys, $maxsubkey,"
	      "$maxclass, $values, $maxvalname, $maxvaldata, $secdesclen,"
	      "$lastwritetime\n");
    }

    hkey = (HKEY) ((unsigned long) str_gnum(st[1]));
    classsz = TMPBUFSZ;
    retval = RegQueryInfoKey (hkey, class, &classsz, 0, &subkeys, &maxsubkey,
			      &maxclass, &values, &maxvalname, &maxvaldata,
			      &seclen, &ft);
    if (BAD_RETURN(retval)) {
	SET_BAD_RETURN;
    }
    else {
	str_set(st[2], class);
	str_numset(st[4], (double) subkeys);
	str_numset(st[5], (double) maxsubkey);
	str_numset(st[6], (double) maxclass);
	str_numset(st[7], (double) values);
	str_numset(st[8], (double) maxvalname);
	str_numset(st[9], (double) maxvaldata);
	str_numset(st[10], (double) seclen);

	//
	// I hate this!
	//

	str_numset(st[11], (double) ft2timet(&ft));
	SET_GOOD_RETURN;
    }
}

static void
do_query_value (int items, enum UserSub idx, STR **st)
{
    HKEY hkey;
    char *subkey;
    long retval;
    unsigned char databuffer[TMPBUFSZ*2];
    DWORD datasz = TMPBUFSZ*2;
    DWORD type;
    int i;

    if (idx == US_RegQueryValue && items != 3) {
	fatal("usage: &%s($hkey, $valuename, $data)\n",
	      UserSubNames[idx]);
    }
    if (idx == US_RegQueryValueEx && items != 5) {
	fatal("usage: &%s($hkey, $valuename, $reserved, $type, $data)\n",
	      UserSubNames[idx]);
    }

    hkey = (HKEY) ((unsigned long) str_gnum(st[1]));
    subkey = (char *) str_get(st[2]);
    retval = RegQueryValueEx(hkey, subkey, 0, &type, databuffer, &datasz);
    if (BAD_RETURN(retval)) {
	SET_BAD_RETURN;
    }
    else {
	//
	// the returned size INCLUDES the null terminator for a string!
	//
	if (type == REG_SZ ||
	    type == REG_EXPAND_SZ ||
	    type == REG_MULTI_SZ) {
	    datasz--;
	}
	if (idx == US_RegQueryValueEx) {
	    str_numset(st[4], (double) type);
	    str_nset(st[5], databuffer, datasz);
	}
	else {
	    str_nset(st[3], databuffer, datasz);
	}
	SET_GOOD_RETURN;
    }
}


static void
do_replace_key(int items, STR **st)
{
    HKEY hkey;
    char *subkey, *newfile, *oldfile;
    long retval;

    if (items != 4) {
	fatal("usage: &RegReplaceKey($hkey, $subkey, $newfile, $oldfile);\n");
    }
    hkey = (HKEY) ((unsigned long) str_gnum(st[1]));
    subkey = (char *) str_get(st[2]);
    newfile = (char *) str_get(st[3]);
    oldfile = (char *) str_get(st[4]);
    retval = RegReplaceKey(hkey, subkey, newfile, oldfile);
    SET_RETURN_VALUE(retval);
}

static void
do_restore_key(int items, STR **st)
{
    HKEY hkey;
    char *filename;
    DWORD flags;
    long retval;

    if (items < 2 || items > 3) {
	fatal("usage &RegRestoreKey($hkey, $filename [, $flags]);\n");
    }
    hkey = (HKEY) ((unsigned long) str_gnum(st[1]));
    filename = (char *) str_get(st[2]);
    flags = (items == 3) ? (DWORD) str_gnum(st[3]) : 0;
    retval = RegRestoreKey(hkey, filename, flags);
    SET_RETURN_VALUE(retval);
}

static void
do_save_key (int items, STR **st)
{
    HKEY hkey;
    char *filename;
    long retval;

    if (items != 2) {
	fatal("usage: &RegSaveKey($hkey, $filename);\n");
    }
    hkey = (HKEY) ((unsigned long) str_gnum(st[1]));
    filename = (char *) str_get(st[2]);
    retval = RegSaveKey(hkey, filename, NULL);
    SET_RETURN_VALUE(retval);
}

static void
do_set_key_security(int items, STR **st)
{
    HKEY hkey;
    SECURITY_INFORMATION si;
    SECURITY_DESCRIPTOR sd;
    long retval;

    if (items != 3) {
	fatal("usage: &RegSetKeySecurity($hkey, $security_info, $security_descriptor);\n");
    }
    hkey = (HKEY) ((unsigned long) str_gnum(st[1]));
    si = *((SECURITY_INFORMATION *) str_get(st[2]));
    sd = *((SECURITY_DESCRIPTOR *) str_get(st[3]));
    retval = RegSetKeySecurity (hkey, si, &sd);
    SET_RETURN_VALUE(retval);
}


static void
do_set_value (int items, enum UserSub idx, STR **st)
{
    HKEY hkey;
    char *valname;
    int validx;
    DWORD type;
    DWORD val;
    long retval;
    int size;
    char *buffer;

    if (idx == US_RegSetValue && items != 4) {
	fatal ("usage: &RegSetValue ($hkey, $valname, $type, $data);\n");
    }
    if (idx == US_RegSetValueEx && items != 5) {
	fatal ("usage: &RegSetValueEx ($hkey, $valname, $reserved, $type, $data);\n");
    }
    hkey = (HKEY) ((unsigned long) str_gnum(st[1]));
    valname = (char *) str_get(st[2]);
    type = (DWORD) str_gnum(st[idx == US_RegSetValue? 3 : 4]);
    validx = (idx == US_RegSetValue) ? 4 : 5;
    switch (type) {
      case REG_SZ:
      case REG_BINARY:
      case REG_MULTI_SZ:
      case REG_EXPAND_SZ:
	size = str_len(st[validx]);
	if (type != REG_BINARY)
	    size++; // include null terminator in size
	buffer = _alloca(size);
	memset(buffer, 0, size);
	strncpy(buffer, str_get(st[validx]), str_len(st[validx]));
	retval = RegSetValueEx (hkey, valname, 0, type,
				(PBYTE) buffer, size);
	break;
      case REG_DWORD_BIG_ENDIAN:
      case REG_DWORD_LITTLE_ENDIAN: // Same as REG_DWORD
	val = (DWORD) str_gnum(st[validx]);
	retval = RegSetValueEx (hkey, valname, 0, type,
				(PBYTE) &val, sizeof(val));
	break;
      default:
	fatal("&RegSetValue: Type not specified, cannot set %s\n", valname);
    }
    SET_RETURN_VALUE(retval);
}

static void
do_unload_key (int items, STR **st)
{
    HKEY hkey;
    char *subkey;
    long retval;

    if (items != 2) {
	fatal("usage: &RegUnLoadKey($hkey, $subkey);\n");
    }
    hkey = (HKEY) ((unsigned long) str_gnum(st[1]));
    subkey = (char *) str_get(st[2]);
    retval = RegUnLoadKey(hkey, subkey);
    SET_RETURN_VALUE(retval);
}


static time_t
ft2timet(FILETIME *ft)
{
    SYSTEMTIME st;
    struct tm tm;

    FileTimeToSystemTime(ft, &st);
    tm.tm_sec = st.wSecond;
    tm.tm_min = st.wMinute;
    tm.tm_hour = st.wHour;
    tm.tm_mday = st.wDay;
    tm.tm_mon = st.wMonth - 1;
    tm.tm_year = st.wYear - 1900;
    tm.tm_wday = st.wDayOfWeek;
    tm.tm_yday = -1;
    tm.tm_isdst = -1;
    return mktime (&tm);
}

//
// Routine to start a process, generally for bi-directional
// IPC. Takes a variable number of arguments, from 1 to 4 which are:
//
//  command line  - character string
//  stdin         - File descriptor
//  stdout        - File descriptor
//  stderr        - File descriptor
//

#define R  3
#define W  4
#define E  5

static void
do_ntspawn (int items, STR **st)
{
    char **vec;
    int swapio = items == 5;
    int vecc;
    char *cmd;
    int savein, saveout, saveerr;
    STAB *stab;
    long pid;

    if (items != 2 && items != 5)
	fatal ("usage: &Spawn ($cmd, $pid [,inhandle, outhandle, errhandle])\n");

    //
    // make a command vector from the string passed in
    //

    New (1904, cmd, str_len(st[1])+1, char);
    strcpy(cmd, str_get(st[1]));
    vecc = NtMakeCmdVector(cmd, &vec, FALSE);

    //
    // if the user specified the processes I/O channels, swap
    // the current processes stdin, stdout, and stderr
    //

    if (swapio) {
	int fd;
	savein = _dup(fileno(stdin));
	saveout = _dup(fileno(stdout));
	saveerr = _dup(fileno(stderr));

	//
	// if the input parameter is a number then we assume
	// that it\'s a file descriptor (output of a call to fileno,
	// or a socket). If it\'s a string then we assume that it\'s
	// a file handle and need to go through the gyrations needed
	// to get its file descriptor
	//

	// input descriptor or handle

	fd = st[R]->str_nok ?
	        (int) str_gnum(st[R]) :
	        (int) fileno(stab_io(stabent(str_get(st[R])))->ifp);

	if (_dup2(fd, fileno(stdin)) == -1)
	    fatal("internal (&Spawn: error swapping stdin\n");

	// error descriptor or handle

	fd = st[W]->str_nok ?
	        (int) str_gnum(st[W]) :
	        (int) fileno(stab_io(stabent(str_get(st[W])))->ifp);
	if (_dup2(fd, fileno(stdout)) == -1)
	    fatal("internal (&Spawn: error swapping stdout\n");

	// error descriptor or handle

	fd = st[E]->str_nok ?
	        (int) str_gnum(st[E]) :
	        (int) fileno(stab_io(stabent(str_get(st[E])))->ifp);
	if (_dup2(fd, fileno(stderr)) == -1)
	    fatal("internal (&Spawn: error swapping stderr\n");
    }

    //
    // create the process
    //

    pid = spawnvpe(P_NOWAIT, vec[0], vec, environ);

    //
    // Now put our I/O back the way it was
    //

    if (swapio) {
	if (_dup2(savein, fileno(stdin)) == -1)
	    fatal("internal (&Spawn: error unswapping stdin\n");
	if (_dup2(saveout, fileno(stdout)) == -1)
	    fatal("internal (&Spawn: error unswapping stdout\n");
	if (_dup2(saveerr, fileno(stderr)) == -1)
	    fatal("internal (&Spawn: error unswapping stderr\n");
    }

    //
    // free up the command vector
    //

    Safefree(vec);

    //
    // return the pid (or error value)
    //

    str_numset(st[2], (double) pid);

    st[0] =  pid < 0 ? &str_no : &str_yes;
}

