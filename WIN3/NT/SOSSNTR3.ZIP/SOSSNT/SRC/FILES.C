/*
 *  files.c --
 *      File manipulation procedures.  This module is highly machine
 *      dependent.
 *
 *  Author:
 *      See-Mong Tan
 *  Modified by:
 *  Rich Braun @ Kronos
 *
 *  Revision history:
 *  
 * $Log: files.c_v $
 * Revision 1.6  1991/05/13  17:43:50  richb
 * Correct the return value of file_freeblocks so it won't produce
 * an error if there are 0 free blocks.
 *
 * Revision 1.5  1991/04/17  18:04:30  richb
 * Correct the modification time stored when a file block is
 * written.  (small bug in 3.1.)
 *
 * Revision 1.4  1991/04/11  20:36:51  richb
 * Add name truncation support.
 *
 * Revision 1.3  1991/03/15  22:39:19  richb
 * Several mods:  fixed unlink and rename.
 *
 */


#ifdef RCSID
static char _rcsid_ = "$Id: files.c_v 1.6 1991/05/13 17:43:50 richb Exp $";
#endif

#include "common.h"
#include <direct.h>     /* for dos directory ops */
#include <fcntl.h>      /* these ... */
#include <sys/stat.h>       /* for ... */
#include <io.h>         /* low level DOS access */
#include <sys/types.h>
#include <sys/utime.h>

#include <errno.h>
#include <ctype.h>
#include "ntfsauth.h"


#define READWITHCACHE  1        // turn off when problem
#ifdef  READWITHCACHE
//#define WRITEWITHCACHE  1
#endif

/* Default permissions for files are 555 for read-only and 777  */
/* for writeable.  The low-order 9 bits can be modified by the  */
/* administrator.                       */
u_short uperm_rdonly = UPERM_FILE | UPERM_READ | UPERM_EXEC;
u_short uperm_write  = UPERM_FILE | UPERM_READ | UPERM_WRITE | UPERM_EXEC;
u_short uperm_dir    = UPERM_DIR | UPERM_READ | UPERM_WRITE | UPERM_SEARCH;


#ifdef NOVELL
#include "novell.h"     /* Novell definitions */
static struct _uidmap {
	u_long  unix_ID;
	u_long  Novell_ID;
	} *uIDmappings = NULL;
static int uIDcount;
static u_long uIDoffset;
static u_long gID;
static u_short novelldirprot;

static bool_t ldnovell (u_long, char *, struct nfsfattr *);
#endif /* NOVELL */


#ifdef DOSAUTH
/* Support for handling file authentication */
struct _authent {
	u_short uid;        /* UID of file owner */
	u_short gid;        /* GID of file owner */
	u_short mode;       /* Protection mode bits */
	u_short reserved;
	};
#define AUTHSIZE (sizeof (struct _authent))
#define AUTHFILE "AUTHS.DMP"
static int authfh = 0;
#endif /* DOSAUTH */

static int file_nsubdirs(char *);
static bool_t file_readattr(char *, struct nfsfattr *);
static void   cvtd2uattr (u_long, struct _finddata_t *, struct nfsfattr *);
static void frdc_clr( void);

#define DRIVE_SCALINGFACTOR 4   /* scaling factor for NT */

BOOL
setnormalfileattr(char *name)
{
	return SetFileAttributes(name,FILE_ATTRIBUTE_NORMAL);
}

BOOL
setreadonlyfileattr(char *name)
{
	return SetFileAttributes(name,FILE_ATTRIBUTE_READONLY);
}

/*
 *  bool_t file_getattr(char *path, struct nfsfattr *attr) --
 *      Gets attributes for designated file or directory and puts
 *      the information in *attr.  Returns TRUE if successful, FALSE otherwise.
 */
bool_t file_getattr(path, attr)
	char *path;
	struct nfsfattr *attr;
{
	if (path == NULL)
	  return FALSE;
#ifdef READWITHCACHE
	frdc_clr();
#endif
	/* See if info is cached in the inode tree */

#ifdef CACHEIT
	if (inattrget (pntoin (path), attr) != NULL)
	return TRUE;
#endif

	/* Else go out to disk */
DBGPRT1 (inode, "getattr going to disk, path = %s", path);
	return  file_readattr(path, attr);
}

/* myfindfirst - note that _findclose is called, so that the search */
/* cannot be continued.  This only returns the first file match. */
int
myfindfirst(path, findbuf)
char *path;
struct _finddata_t *findbuf;
{
	long fhand;

	fhand = _findfirst(path,findbuf);
	if ( fhand < 0 ) {
		DBGPRT0 (inode, "myfindfirst, fhand<0");
		return -1;
	}
	/* We used to check only for NORMAL/SUBDIR/RDONLY files, but that */
	/* didn't seem to work right, and besides, it seems like we should */
	/* just see most files, right? */
	DBGPRT3 (inode, "myfindfirst  name=%s attrib=0x%x  access=%d",path,findbuf->attrib,_access(path,04));
	_findclose(fhand);
	return 0;
}


/*
 *  bool_t file_readattr(char *path, struct nfsfattr *attr) --
 *      Reads file attributes for a file from disk.
 *      Returns TRUE if successful, FALSE otherwise.
 *  Adds file to directory tree if the file does not already exist in
 *  the tree.
 */
static bool_t file_readattr(path, attr)
	char *path;
	struct nfsfattr *attr;
{
	struct _finddata_t findbuf;
	u_long nodeid;

	/* Special-case the root directory */
	if (strlen (path) == 2 && path[1] == ':') {

		(void) bzero((char*)attr, sizeof(struct nfsfattr));
		attr->na_blocksize = NFS_MAXDATA;


		/* Set directory attributes */
		attr->na_type = NFDIR;
		attr->na_mode = uperm_dir;
		attr->na_nlink = 2;
		attr->na_blocks = 1;         /* just say 1 block */
		attr->na_size = 1024;
//        attr->na_size = 8192;

		/* cache this info */
		inattrset (nodeid, attr);
		return TRUE;
	}

	/* Look for the file given */
DBGPRT1 (inode, "caling myfindfirst for path= %s", path);
	if (myfindfirst(path,&findbuf) != 0) {

		/* not successful */
		if ((nodeid = pntoin(path)) != -1)
			  inremnode (nodeid);
			DBGPRT0 (inode, "return false A");
			return FALSE;
		}
		if ((nodeid = pntoin(path)) == -1) {
		  nodeid = addpathtodirtree(path);
	}

	/* Load attributes from findbuf */
	(void) bzero((char*)attr, sizeof(struct nfsfattr));
	cvtd2uattr (nodeid, &findbuf, attr);

		if (findbuf.attrib & _A_SUBDIR)
	  attr->na_mode = uperm_dir;
		else if (findbuf.attrib & _A_RDONLY)
	  attr->na_mode = uperm_rdonly;
	else
	  attr->na_mode = uperm_write;

#ifdef NOVELL
	/* Novell stuff */
	(void) ldnovell (nodeid, path+2, attr);
#endif

#ifdef NTFS
	if( TRUE == NtfsCompDriveType( path, "NTFS"))
		NtfsGetUnixAttrib( path, attr);    
#endif

#ifdef DOSAUTH
	/* Read authentication entry */
	if (authfh != 0 && lseek (authfh, nodeid * AUTHSIZE, SEEK_SET) ==
	  nodeid * AUTHSIZE) {
		struct _authent authentry;
		if (read (authfh, &authentry, AUTHSIZE) == AUTHSIZE) {
		attr->na_uid = authentry.uid;
		attr->na_gid = authentry.gid;
		attr->na_mode = authentry.mode;
		}
	}
#endif /* DOSAUTH */
	/* cache this info */
	inattrset (nodeid, attr);
DBGPRT0 (inode, "return true A");
	return TRUE;
}

static void cvtd2uattr (nodeid, findbuf, attr)
	 u_long nodeid;
	 struct _finddata_t *findbuf;
	 struct nfsfattr *attr;
{
	/* file protection bits and type */
	if (findbuf->attrib & _A_SUBDIR) {      /* subdirectory */
	attr->na_type = NFDIR;
	attr->na_nlink = 2;  /*** + file_nsubdirs(path) ***/
	/* # of subdirectories plus this one */
	}
	else if (findbuf->attrib & _A_RDONLY) {     /* rdonly */
	attr->na_type = NFREG;
	attr->na_nlink = 1;
	}
	else {
	attr->na_type = NFREG;      /* normal file */
	attr->na_nlink = 1;
	}

	/* file size in bytes */
	if (findbuf->attrib & _A_SUBDIR) {        /* directory */
	attr->na_blocks = 1;         /* just say 1 block */
//      attr->na_size = 8192;
		attr->na_size = 1024;
	}
	else {
	attr->na_size = findbuf->size;
	attr->na_blocks = findbuf->size / BASIC_BLOCKSIZE + 
	  (findbuf->size % BASIC_BLOCKSIZE == 0 ? 0 : 1);
	}
	/* preferred transfer size in blocks */
	attr->na_blocksize = NFS_MAXDATA;

	/* device # == drive # */
	attr->na_fsid = ingetfsid (nodeid);
	attr->na_rdev = attr->na_fsid;

	/* inode # */
	attr->na_nodeid = nodeid;

	/* time of last access */
	attr->na_atime.tv_usec = 0;
	attr->na_atime.tv_sec = findbuf->time_write;

	/* time of last write */
	attr->na_mtime = attr->na_atime;       /* note all times are the same */

	/* time of last change */
	attr->na_ctime = attr->na_atime;
}


/*
 *  int file_nsubdirs(char *path) --
 *  Returns # of subdirectories in the given directory.
 */
static int file_nsubdirs(path)
	char *path;
{
	int subdirs = 0;
#define VALID(ft) (strcmp((ft).name, ".") != 0 && strcmp((ft).name, "..") != 0)

/* Hack:  this routine eats a lot of time and doesn't work anyway. */

printf("FILE_NSUBDIRS IS RETURNING 0 - A LIEEEEEEE!!!!\n");
return 0;

#if 0
	struct _finddata_t ft;
	char name[MAXPATHNAMELEN];

	(void) strcpy(name, path);
	(void) strcat(name, "\\*.*");       /* append wildcard */


/* NOTE: NOT UPGRADED TO WINDOWS NT, SINCE THIS IS COMMENTED OUT */

	if (_dos_findfirst(name, _A_SUBDIR, &ft) != 0)
		if (VALID(ft))
			subdirs++;
		else
			return 0;

	while(_dos_findnext(&ft) == 0)
		if (VALID(ft))
			subdirs++;
	DBGPRT2 (nfslookup, "dos_findfirst '%s', found %d subdirs",
		name, subdirs);

	/* IF THIS CODE IS RESURRECTED, BE SURE TO CALL _findclose() !! */

	return subdirs;
#endif /* 0 */

#undef VALID
}

/*
 *  int file_freeblocks(int drive, long *free, long *total) --
 *      Return # of free blocks in specified filesystem (ie. drive).
 */
long file_freeblocks(drive, free, total)
	int drive;
	long *free, *total;
{
	char drvname[8];
	DWORD nsectors, nbytes, nfreeclusters, nclusters;

#ifdef READWITHCACHE
	frdc_clr();
#endif
	sprintf(drvname,"%c:\\",'A'+drive-1);
	if ( GetDiskFreeSpace(drvname,&nsectors,&nbytes,
			&nfreeclusters,&nclusters) == FALSE ) {
		(void) fprintf(stderr, "freeblocks: err, cannot read\n");
		return -1;
	}
/*  DBGPRT2 (nfsdebug, "%c: blocks free %ld", 'A'+drive-1,
		 (long) nfreeclustors * nsectors); */

	*free = ((long)nfreeclusters * nsectors) / DRIVE_SCALINGFACTOR;
	*total = ((long)nclusters * (long)nsectors) / DRIVE_SCALINGFACTOR;

	return 0;
}

#ifdef READWITHCACHE
/* a file pointer cache for read requests */
#define FRDCSIZ 10
static struct {
	u_long  nodeid;
	FILE    *fp;
	int     mode;
} frdc_cache[FRDCSIZ];

static int frdc_last = 0;       /* last location saved */
#endif

/*
 *  void frdc_save(u_long nodeid, FILE *fp) --
 *  Cache read file pointers.
 */
static void frdc_save( u_long nodeid, FILE* fp, int mode)
{
#ifdef READWITHCACHE
	if (frdc_cache[frdc_last].fp != NULL)
		(void) fclose(frdc_cache[frdc_last].fp);    /* throw away */
	frdc_cache[frdc_last].nodeid = nodeid;
	frdc_cache[frdc_last].mode = mode;
	frdc_cache[frdc_last++].fp = fp;
	if (frdc_last == FRDCSIZ)
		frdc_last = 0;
#endif
}

/*
 *  void frdc_del(u_long nodeid) --
 *  Delete saved file pointer from read cache.  No effect if file
 *  was not cached.  Closes file pointer also.
 */
static void frdc_del(nodeid)
	 u_long nodeid;
{
#ifdef READWITHCACHE
	int i;

	for(i = 0; i < FRDCSIZ; i++) {
		if (frdc_cache[i].fp != NULL && frdc_cache[i].nodeid == nodeid) {
			(void) fclose(frdc_cache[i].fp);
			frdc_cache[i].fp = NULL;
			return;
		}
	}
#endif
}

/*
 *  clear all cached files
 *
 */

static void frdc_clr( void)
{
	int i;

	for( i = 0; i < FRDCSIZ; i++)
	{
		if (frdc_cache[i].fp != NULL) {
			(void) fclose(frdc_cache[i].fp);
			frdc_cache[i].fp = NULL;
printf("Close cached file\n");
		}
	}
}

/*
 *  FILE *frdc_find(u_long nodeid) --
 *  Finds cached file pointer corresponding to nodeid, or NULL
 *  if no such file exists.
 */

static FILE *frdc_find(u_long nodeid, int mode)
{
#ifdef READWITHCACHE
	int i;

	for(i = 0; i < FRDCSIZ; i++) {
		if (frdc_cache[i].fp != NULL && frdc_cache[i].nodeid == nodeid)
		{
			if( frdc_cache[i].mode != mode)
			{
				fclose( frdc_cache[i].fp);
				frdc_cache[i].fp = NULL;
			}
			else
				return frdc_cache[i].fp;
		}
	}
#endif
	return NULL;
}

/*
 *  int file_read(u_long nodeid, u_long offset,
 *                u_long count, char *buffer) --
 *  Reads count bytes at offset into buffer.  Returns # of bytes read,
 *      and -1 if an error occurs, or 0 for EOF or null file.
 */
int file_read(nodeid, offset, count, buffer)
	 u_long nodeid;
	 u_long offset, count;
	 char *buffer;
{
	FILE *fp;
	bool_t saved = FALSE;
	int bytes = 0;
	char path [MAXPATHNAMELEN];

	if ((fp = frdc_find(nodeid, 0)) != NULL) {
	saved = TRUE;
	}
	else if ((fp = fopen(intopn (nodeid, path), "rb")) == NULL) {
	  DBGPRT3 (nfserr, "file_read open errno=%d path=%s nodeid=%d", errno,path,nodeid);
	  return -1;
	 }

	/* Seek to correct position */
	if (fseek(fp, (long) offset, 0) != 0) {
		if (!feof(fp)) {
			(void) fclose(fp);
			DBGPRT1 (nfserr, "file_read unable to seek? path=%s", path);
			return -1;
		}
		else
		{
#ifndef READWITHCACHE
		  fclose( fp);
		  return 0; 
#endif
		}
	}

	/* Read from the file */
	bytes = fread(buffer, sizeof(char), (size_t) count, fp);
#ifndef READWITHCACHE
	fclose( fp);
#else
	if (!saved)
	  frdc_save(nodeid, fp, 0);
#endif

	return bytes;
}

/*
 *  int file_rddir(u_long nodeid, u_long offs, struct udirect *udp) --
 *      Put file information at offs in directory at path in nfs cookie 
 *  at *udp. Returns # of bytes in record, 0 if there are no more entries
 *      or -1 for a read error.
 */
int file_rddir(nodeid, offs, udp)
	 u_long nodeid;
	 u_long offs;
	 struct udirect *udp;
{
	char filename[MAXPATHNAMELEN];
	char npath[MAXPATHNAMELEN], path[MAXPATHNAMELEN];
	struct _finddata_t findbuf;
	struct nfsfattr attr;
	u_long fnode;
	long fhand;

#define SUD  32 /*  sizeof(struct udirect) */ /* full udp cookie size */

#ifdef READWITHCACHE
	frdc_clr();
#endif
	if (offs == 0) {
	/* Force a read of the full directory if offset is zero. */

	if (intopn (nodeid, path) == NULL)
	  return -1;

	/* look for the first file in the directory */
	(void) sprintf(npath, "%s\\*.*", path);

	if ( (fhand=_findfirst(npath, &findbuf)) >= 0) {

		/* Read file attributes from each entry into inode cache */
		for (;;) {

		/* convert to lowercase and get the full path */
		(void) strtolower(findbuf.name);
		(void) sprintf(filename, "%s\\%s", path, findbuf.name);

		if ((fnode = pntoin(filename)) == -1)
		  fnode = addpathtodirtree(filename);
		if (inattrget (fnode, &attr) == (struct nfsfattr *) NULL)
		  (void) bzero ((char*)&attr, sizeof (struct nfsfattr));
		cvtd2uattr (fnode, &findbuf, &attr);
		if (findbuf.attrib & _A_SUBDIR)
		  attr.na_mode = uperm_dir;
		else if (findbuf.attrib & _A_RDONLY)
		  attr.na_mode = uperm_rdonly;
		else
		  attr.na_mode = uperm_write;
#ifdef NOVELL
		(void) ldnovell (fnode, filename+2, &attr);
#endif

#ifdef NTFS
		if( TRUE == NtfsCompDriveType( path, "NTFS"))
			NtfsGetUnixAttrib( filename, &attr);    
#endif

		/* cache this info */
		inattrset (fnode, &attr);

		/* fetch next entry */
		if (_findnext(fhand,&findbuf) != 0) {
		  break;
		}
		}
		_findclose(fhand);
	}
	}

	/* fetch the proper inode */
	if ((udp->d_fileno = ingetentry (nodeid, offs / SUD, udp->d_name)) == -1)
	  return -1;

	/* store the remaining udp info */
	udp->d_namlen = strlen(udp->d_name);
	udp->d_offset = offs + SUD;
	udp->d_reclen = UDIRSIZ(udp);

	/* return 0 if this is the last entry */
	if (ingetentry (nodeid, (offs / SUD) + 1, filename) == -1)
	  return 0;
	else
	  return udp->d_reclen;

#undef SUD
}
	
/*
 *  char *strtolower(char *s) --
 *  Converts all characters in s to lower case.  Returns s.
 */
char *strtolower(s)
	char *s;
{
	char *tmp;

	// no lowercasing
	return s;

	tmp = s;
	while(*s != '\0') {
		if (isalpha(*s) && isupper(*s))
			*s = tolower(*s);
		s++; 
	}

	return tmp;
}

/*
 *  enum nfsstat file_write(u_long nodeid, u_long offset,
 *                          u_long count, char *buffer) --
 *      Write to file with name at offset, count bytes of data from buffer.
 *  File should already exist.  Returns 0 for success, or some error 
 *  code if not.
 */
enum nfsstat file_write(nodeid, offset, count, buffer)
	u_long nodeid;
	u_long offset;
	u_long count;
	char *buffer;
{
#ifndef WRITEWITHCACHE
	int handle;         /* write file handle */
	long newoff;
	char name [MAXPATHNAMELEN];
	int fw_num = WR_SIZ;
	struct nfsfattr attr;
	time_t now;

	if (intopn (nodeid, name) == NULL)
	  return NFSERR_STALE;

	frdc_del(nodeid);           /* delete from read cache */

	/* Get cached file attributes */
	if (inattrget (nodeid, &attr) == (struct nfsfattr *) NULL) {
		fprintf (stderr, "file_write: attrget failed\n");
	}
	else {
		/* If the file is read-only, temporarily set it to read/write */
		if (!(attr.na_mode & UCHK_WR))
		  (void) setnormalfileattr(name);
	}

	/* open for writing only */
	handle = open(name, O_WRONLY | O_BINARY);
	if (handle == -1)
		return puterrno(errno); /* return error code */
	DBGPRT4 (nfswrite, "%s, %ld bytes at %ld (len = %ld)",
		 name, count, offset, attr.na_size);
 
	newoff = lseek(handle, offset, 0);
	if (count < WR_SIZ) fw_num = count;
		if (write(handle, buffer, fw_num) == -1) {
			(void) close(handle);
			return puterrno(errno);     /* some error */
		}

	/* Update cached file attributes */
	attr.na_size = filelength (handle);
	(void) time (&now);
	attr.na_atime.tv_usec = 0;
	attr.na_atime.tv_sec = now;
	attr.na_mtime = attr.na_atime;
	attr.na_ctime = attr.na_atime;
	(void) inattrset (nodeid, &attr);

	(void) close(handle);
	/* If the file is read-only, set its _A_RDONLY attribute */
//    if (!(attr.na_mode & UCHK_WR))
//      (void) setreadonlyfileattr(name);
#else
	FILE*   fp;
	bool_t saved = FALSE;
	long newoff;
	char name [MAXPATHNAMELEN];
	int fw_num = WR_SIZ;
	struct nfsfattr attr;
	time_t now;

	if (intopn (nodeid, name) == NULL)
	  return NFSERR_STALE;

	/* Get cached file attributes */
	if (inattrget (nodeid, &attr) == (struct nfsfattr *) NULL) {
		fprintf (stderr, "file_write: attrget failed\n");
	}
	else {
	}

	if ((fp = frdc_find(nodeid, 1)) != NULL) {
printf("Write file cached\n");
		saved = TRUE;
	}
	else if ((fp = fopen(name, "r+b")) == NULL) {
	  DBGPRT3 (nfserr, "file_write open errno=%d path=%s nodeid=%d", errno,name,nodeid);
	  return -1;
	 }
	DBGPRT4 (nfswrite, "%s, %ld bytes at %ld (len = %ld)",
		 name, count, offset, attr.na_size);
 
	newoff = fseek( fp, offset, 0);
	if (count < WR_SIZ) fw_num = count;
		if ( fwrite(buffer, 1, fw_num, fp) != fw_num) {
			(void) fclose( fp);
			return puterrno(errno);     /* some error */
		}

	/* Update cached file attributes */
	attr.na_size = filelength ( fileno( fp) );
	(void) time (&now);
	attr.na_atime.tv_usec = 0;
	attr.na_atime.tv_sec = now;
	attr.na_mtime = attr.na_atime;
	attr.na_ctime = attr.na_atime;
	(void) inattrset (nodeid, &attr);

	if (!saved)
	  frdc_save(nodeid, fp, 1);
#endif    
	return NFS_OK;
}

/*
 *  enum nfsstat file_create(char *name, struct nfssattr *sattr,
 *                           struct nfsfattr *fattr)
 *      Creates a file with full path name and attributes sattr, and returns
 *      the file attributes in *fattr.  Adds file to directory tree.
 *      Returns NFS_OK for success, or some error code for failure.
 */
enum nfsstat file_create(name, sattr, fattr)
	 char *name;
	 struct nfssattr *sattr;
	 struct nfsfattr *fattr;
{
	int handle;         /* file handle */
	enum nfsstat stat;
	u_long node;
	int sattribs = S_IREAD;     /* set attributes */

#ifdef READWITHCACHE
	frdc_clr();
#endif
	if (name == NULL)
	  return NFSERR_NOENT;

	if ((stat = validate_path (name)) != NFS_OK)
	  return (stat);

	if (sattr->sa_mode & UCHK_WR)      /* file is writeable */
	  sattribs |= S_IWRITE;    /* set DOS file to be read & write */

	/* Remove the inode if assigned */
	if ((node = pntoin (name)) != -1) {
	frdc_del (node);
	inremnode (node);
	}

#if 0

	/* obsolete code -- now get uid/gid from RPC header */
	if (sattr->sa_uid == -1 || sattr->sa_gid == -1) {
	char parent [MAXPATHNAMELEN];
	struct nfsfattr pattr;      /* attributes of parent */
	char *strrchr();

	/* Set up UID and GID defaults from parent inode */
	strcpy (parent, name);
	*strrchr (parent, '\\') = '\0';
	if (!file_getattr (parent, &pattr)) {
		DBGPRT1 (nfsdebug, "no attrs %s", parent);
	}
	else {
		if (sattr->sa_uid == -1)
		  sattr->sa_uid = pattr.na_uid;
		if (sattr->sa_gid == -1)
		  sattr->sa_uid = pattr.na_gid;
	}
	}
#endif

	DBGPRT4 (nfsdebug, "file_create %s <%o> [%ld,%ld]", name,
		 (int) sattr->sa_mode, sattr->sa_uid, sattr->sa_gid);

	/* check if file already exists */
	if ((handle = open(name, O_CREAT | O_TRUNC, sattribs)) == -1)
	  return puterrno (errno);
	close(handle);

	/* Add to inode tree */
	if ((node = pntoin(name)) == -1)
	  node = addpathtodirtree(name);

	/* Set the file's ownership */
	//{
	//    DWORD   time = GetCurrentTime() + 2000;
	//    while( time > GetCurrentTime());
	//}
#if 0
	(void) file_setowner (node, sattr->sa_uid, sattr->sa_gid);
#else
	(void) file_setattr(node, sattr->sa_uid, sattr->sa_gid, sattr->sa_mode);
#endif
	/* Read the file's attributes and return */
	if (! file_readattr(name, fattr)) 
	  return NFSERR_IO;   /* just created but not found now! */

	return NFS_OK;
}

/*
 *  int file_setattr(char *path, long uid, long gid, long perm) --
 *  Returns 0 for success or some error code if an error occurs.
 */
enum nfsstat file_setattr(nodeid, uid, gid, perm)
	 u_long nodeid;
	 long uid;
	 long gid;
	 long perm;
{
	int stat;
	char path [MAXPATHNAMELEN];
	struct nfsfattr attr;

#ifdef READWITHCACHE
	frdc_clr();
#endif
	if (intopn(nodeid, path) == NULL)   /* get file name */
	  return NFSERR_STALE;
	DBGPRT4 (nfsdebug, "file_settr %s <%o> [%ld,%ld]", path,
		 (int) perm, uid, gid);

	stat = TRUE;

#ifdef NTFS
	if( FALSE == NtfsCompDriveType( path, "NTFS"))
#endif
	{
#ifndef DOSAUTH
		if (perm & UPERM_WRITE) {
			stat = setnormalfileattr(path);
			perm = uperm_write;
		}
		else {
			stat = setreadonlyfileattr(path);
			perm = uperm_rdonly;
		}
#endif
	}


	if (stat == TRUE) {
		DBGPRT2 (nfsdebug, "file_setattr(%s..) %s", path, "point1");
		/* Update cached file attributes */

#if 0        
		if (inattrget (nodeid, &attr) != (struct nfsfattr *) NULL) 
#endif
		{
			DBGPRT2 (nfsdebug, "file_setattr(%s..) %s", path, "point2");
			attr.na_mode = perm;
			attr.na_uid  = uid;
			attr.na_gid  = gid;
#ifdef NTFS
			if(TRUE == NtfsCompDriveType( path, "NTFS"))
				stat = NtfsSetUnixAttrib( path, &attr);
#endif
			if( stat == TRUE)
				(void) inattrset (nodeid, &attr);
		}
		return NFS_OK;
	} 
	DBGPRT2 (nfsdebug, "file_setattr(%s..) %s", path, "point3");
	return puterrno(errno);
}

#if 0
/*
 *  int file_setperm(char *path, long perm) --
 *      Sets file permissions depending on perm.  Perm is of two types,
 *      uperm_write (regular file) or uperm_rdonly (read only).
 *  Returns 0 for success or some error code if an error occurs.
 */
enum nfsstat file_setperm(nodeid, perm)
	 u_long nodeid;
	 long perm;
{
	int stat;
	char path [MAXPATHNAMELEN];
	struct nfsfattr attr;

#ifdef READWITHCACHE
	frdc_clr();
#endif
	if (intopn(nodeid, path) == NULL)   /* get file name */
	  return NFSERR_STALE;

	stat = TRUE;

#ifdef NTFS
	if( FALSE == NtfsCompDriveType( path, "NTFS"))
#endif
	{
#ifndef DOSAUTH
		if (perm & UPERM_WRITE) {
			stat = setnormalfileattr(path);
			perm = uperm_write;
		}
		else {
			stat = setreadonlyfileattr(path);
			perm = uperm_rdonly;
		}
#endif
	}


	if (stat == TRUE) {
	/* Update cached file attributes */
	if (inattrget (nodeid, &attr) != (struct nfsfattr *) NULL) {
		attr.na_mode = perm;
#ifdef NTFS
		if(TRUE == NtfsCompDriveType( path, "NTFS"))
			stat = NtfsSetUnixAttrib( path, &attr);
#endif
		if( stat == TRUE)
			(void) inattrset (nodeid, &attr);
	}
	return NFS_OK;
	} else
	  return puterrno(errno);
}   
		
#endif

/*
 *  int file_setsize(u_long nodeid, long size) --
 *      Sets file size.
 *  Returns 0 for success or some error code if an error occurs.
 */
enum nfsstat file_setsize(nodeid, size)
	 u_long nodeid;
	 long size;
{
	int handle;
	char path [MAXPATHNAMELEN];
	struct nfsfattr attr;

#ifdef READWITHCACHE
	frdc_clr();
#endif
	if (intopn(nodeid, path) == NULL)   /* get file name */
	  return NFSERR_STALE;

	if (size == 0L) {
	if ((handle = open(path, O_CREAT | O_TRUNC, S_IWRITE)) == -1)
		return puterrno (errno);
	close(handle);

	/* Update cached file attributes */
	if (inattrget (nodeid, &attr) != (struct nfsfattr *) NULL) {
		attr.na_size = 0;
		(void) inattrset (nodeid, &attr);
	}
	return NFS_OK;
	}
	else
	  return NFSERR_IO;
}   

/*
 *  int file_settime(u_long nodeid, long secs) --
 *      Sets file time specified by secs (# of seconds since 0000, Jan 1, 1970.
 *  Returns 0 for success or some error code if an error occurs.
 */
enum nfsstat file_settime(nodeid, secs)
	 u_long nodeid;
	 long secs;
{
	int stat;
	char path [MAXPATHNAMELEN];
	struct nfsfattr attr;
	struct _utimbuf ut;

#ifdef READWITHCACHE
	frdc_clr();
#endif
	if (intopn(nodeid, path) == NULL)   /* get file name */
	  return NFSERR_STALE;

	ut.actime = ut.modtime = secs;
	stat = _utime(path, &ut);

	if (stat != 0)
	  return puterrno(errno);
	else {
	/* Update cached file attributes */
	if (inattrget (nodeid, &attr) != (struct nfsfattr *) NULL) {
		attr.na_atime.tv_usec = 0;
		attr.na_atime.tv_sec = secs;
		attr.na_mtime = attr.na_atime;
		attr.na_ctime = attr.na_atime;
		(void) inattrset (nodeid, &attr);
	}

	return NFS_OK;
	}
}

#if 0
/*
 *  int file_setowner(u_long nodeid, long uid, long gid) --
 *      Sets file ownership values.
 *      This can only set the values in cache, because DOS doesn't
 *  support an on-disk representation.
 */
enum nfsstat file_setowner(nodeid, uid, gid)
	 u_long nodeid;
	 long uid, gid;
{
	struct nfsfattr attr;
	struct nfssattr sattr;
	char path [MAXPATHNAMELEN];

#ifdef READWITHCACHE
	frdc_clr();
#endif
	if (intopn (nodeid, path) == NULL)
	  return NFSERR_NOENT;
	DBGPRT3 (nfsdebug, "Setting owner to [%ld,%ld] %s", uid, gid, path);

	if (file_getattr (path, &attr)) {
#ifdef NOVELL
	if (!(attr.na_mode & UPERM_DIR) && uid != -1) {
		/* Set up the Scan File Information request block, as defined on */
		/* page 283 of the Novell API Reference, rev 1.00.       */

		static struct _sfireq sfireq = /* These are placed in static */
		  {0, 0x0F, -1, -1, 0, 0, 0};  /* memory because code here   */
		static struct _sfirep sfirep;  /* assumes seg register DS.   */
		static struct _setfireq setfireq =
		  {0, 0x10, 0};
		static struct _setfirep setfirep;
		u_char handle;
		union REGS regsin, regsout;
		struct SREGS segregs;
		int i;

		if ((handle = novell_GDH (ingetfsid (nodeid))) != 255) {
		segregs.ds = get_ds();
		segregs.es = segregs.ds;

		sfireq.handle = handle;
		sfireq.pathlen = strlen (path+2);
		sfireq.len = 6 + sfireq.pathlen;
		sfirep.len = sizeof (sfirep) -2;
		strcpy (sfireq.path, path+2);

		novell_API(0xE3, &sfireq, &sfirep, regsin, &regsout, &segregs);
		if (regsout.h.al != 0)
			return NFSERR_IO;

		/* Set up the Set File Info request block */
		setfireq.handle = handle;
		setfireq.pathlen = strlen (path+2);
		setfireq.len = 4 + sizeof (struct _fileinfo) + sfireq.pathlen;
		setfirep.len = sizeof (setfirep) -2;
		strcpy (setfireq.path, path+2);
		setfireq.info = sfirep.info;
		setfireq.info.size = 0;

		/* Look up the Novell user ID */
		setfireq.info.ownerID = uid - uIDoffset;
		for (i = 0; i < uIDcount; i++)
		  if (uIDmappings[i].unix_ID == uid + uIDoffset) {
			  setfireq.info.ownerID = uIDmappings[i].Novell_ID;
			  break;
		  }

		/* Issue the Set File Information request */
		novell_API(0xE3, &setfireq, &setfirep, regsin, &regsout,
			   &segregs);
		if (regsout.h.al != 0)
			return NFSERR_ACCES;
		}
	}
#endif /* NOVELL */

	/* Update cached file attributes */
	if (uid != -1)
	  attr.na_uid = uid;
	if (gid != -1)
	  attr.na_gid = gid;

		{
#ifdef NTFS
			BOOL    stat = TRUE;
			if(TRUE == NtfsCompDriveType( path, "NTFS"))
				stat = NtfsSetUnixAttrib( path, &attr);
			if( stat != TRUE)
			{
				DBGPRT3 (nfsdebug, "FAILED Setting owner to [%ld,%ld] %s", 
					attr.na_uid, attr.na_gid, path);
			}
			else
#endif
				(void) inattrset (nodeid, &attr);
		}
		return NFS_OK;
	}
	else
		return NFSERR_NOENT;
}

#endif

/*
 *  int file_unlink(char *name) --
 *       Removes named file.
 */
enum nfsstat file_unlink(name)
	char *name;
{
	u_long node;
	int    stat;

#ifdef READWITHCACHE
	frdc_clr();
#endif
	/* Close the file if we still have a handle to it */
	if ((node = pntoin (name)) != -1)
	frdc_del (node);

	/* Reset file attributes */
	(void) setnormalfileattr(name);

	/* Call unlink library function to remove the file. */
	stat = unlink(name);
DBGPRT3 (nfserr, "unlink %s: stat = %d, len = %d", name, stat, strlen(name));

	/* Remove the inode associated with the file, if present. */
	if (stat == 0 && node != -1)
	inremnode (node);
	return (stat == 0) ? NFS_OK : puterrno (errno);
}


/*
 *  int file_rename(char *oldname, char *newname) --
 *       Renames a file
 */
enum nfsstat file_rename(oldname, newname)
	char *oldname, *newname;
{
	u_long node;
	int    err;
	struct stat buf;
	enum   nfsstat code;

#ifdef READWITHCACHE
	frdc_clr();
#endif
	/* Close the file if we still have a handle to it */
	if ((node = pntoin (oldname)) != -1)
	frdc_del (node);

	/* Reset file attributes (e.g., read-only) */
	(void) setnormalfileattr(oldname);

	/* Validate the new filename */
	if ((code = validate_path (newname)) != NFS_OK)
	  return (code);

	/* Delete destination file if present */
	if (stat (newname, &buf) == 0) {
	if (buf.st_mode & S_IFDIR)
	  return NFSERR_ISDIR;
	if ((code = file_unlink (newname)) != NFS_OK)
	  return code;
	}

	/* Call rename library function to rename the file. */
	err = rename(oldname,newname);

	/* Update the inode associated with the file, if present. */
	if (err == 0 && node != -1) {
	(void) inremnode (node);
	(void) addpathtodirtree(newname);
	}
	return (err == 0) ? NFS_OK : puterrno (errno);
}

/*
 *  enum nfsstat validate_path (char *name) --
 *       Validate a path name's syntax.  Returns 0 if OK.
 *       Modifies the path appropriately if NFS_TRUNCATENAMES is set.
 */
enum nfsstat validate_path (name)
	 char *name;
{
	char *ptr, *ptr2, *strrchr(), *strchr();
	int i;

#ifdef READWITHCACHE
	frdc_clr();
#endif
	if ((ptr = strrchr (name, '\\')) == (char *)NULL &&
	(ptr = strrchr (name, ':')) == (char *)NULL)
	ptr = name;
	else
		ptr++;

	/* Check validity of characters in final component */
	for (ptr2 = ptr; *ptr2; ) {
	if (*ptr2 <= ' ' || (*ptr2 & 0x80) || !inchvalid[*ptr2 - '!'])
	  return NFSERR_INVAL;
	else
	  ptr2++;
	}
#if 1
	/* PCM 93.04.15 -- Added NTFS long file name check */
	/* if we're not truncating the names, check to see */
	/* if the volume is not FAT, and the name length is*/
	/* less than the allowable */
	if (!NFS_TRUNCATENAMES) {
		DWORD maxlen = 0;
		char root[64];
		char * p;

		strncpy(root, name, 63);
		root[63] = '\0';
		p=strchr(root, ':');
		if (p) {
			*++p = '\\';
			*++p = '\0';
		} else {
			p=strchr(root, '\\');
			if (p)
				*++p = '\0';
			else
				root[0] = '\0';
		}


		if( root[0])
			if(GetVolumeInformation(root, NULL, 0, 0, &maxlen, 
					NULL, NULL, 0))
			{
			/* FAT systems return 12 -- handle in usual way */
			if ((maxlen>12)&&(strlen(ptr)<maxlen))
				return NFS_OK;
			}
	}
#endif
	/* Verify there are no more than 8 chars before '.' */
	if ((i = strcspn (ptr, ".")) > 8) {
	if (!NFS_TRUNCATENAMES)
	  return NFSERR_NAMETOOLONG;
	strcpy (ptr + 8, ptr + i);
	}
	if ((ptr2 = strchr (ptr, '.')) == (char *)NULL)
	return NFS_OK;
	else
		ptr2++;
	ptr = ptr2;
	if (strlen (ptr) > 3) {
	if (!NFS_TRUNCATENAMES)
	  return NFSERR_NAMETOOLONG;
	ptr[3] = '\0';
	}
	return NFS_OK;
}



#ifdef NOVELL
/*
 *  u_char novell_GDH (int fsid) --
 *  Get Novell directory handle for a filesystem.
 */
u_char novell_GDH (fsid)
int fsid;
{
union REGS regsin, regsout;

	/* Get the file system's directory handle */
	regsin.x.ax = 0xE900;
	regsin.x.dx = fsid - 1;
	intdos (&regsin, &regsout);

	/* Return -1 error code if the permanent directory bit is not set or */
	/* the local-directory bit is set.                       */
	if ((regsout.h.ah & 0x83) != 1)
	  return 255;

	return regsout.h.al;
}

/*
 *  void ldnovell (u_long nodeid, char *path, struct nfsfattr *attr) --
 *  Loads attributes of a Novell network file
 */
static bool_t ldnovell (nodeid, path, attr)
	 u_long nodeid;
	 char   *path;
	 struct nfsfattr *attr;
{
	FILE *fp, *fopen();
	int i;
	int stat;
	u_char handle;
	char fcn [10];
	union REGS regsin, regsout;
	struct SREGS segregs;

	if ((handle = novell_GDH (ingetfsid (nodeid))) == 255)
	return FALSE;

	/* Initialize the Novell ID mapping table if not set */
	if (uIDmappings == NULL) {
	uIDmappings = (struct _uidmap *) malloc (sizeof (struct _uidmap) *
						MAXNOVELLID);
	if (uIDmappings == NULL) {
		fprintf (stderr, "out of memory\n");
		abort();
	}
	uIDoffset = uIDcount = gID = 0;

	/* Default protection is 775 */
	novelldirprot = UPERM_OWNER | UPERM_GROUP | UPERM_READ | UPERM_SEARCH;

	if ((fp = fopen(IDFILE, "r")) == NULL) {
		fprintf (stderr, ">>> File %s missing\n", IDFILE);
	}
	else {
		while(fscanf(fp, "%s", fcn) != EOF) {
		/* Check command line for 'offset', 'group', 'user', */
		/* 'protection'.                     */
		if (fcn[0] == 'o')
			fscanf(fp, "%ld", &uIDoffset);
		else if (fcn[0] == 'g')
			fscanf(fp, "%ld", &gID);
		else if (fcn[0] == 'p')
			fscanf(fp, "%o", &novelldirprot);
		else if (fcn[0] == 'u') {
			char user[20];
			fscanf(fp, "%s %ld %ld", user,
			   &uIDmappings[uIDcount].unix_ID,
			   &uIDmappings[uIDcount].Novell_ID);
			if (uIDcount < MAXNOVELLID-1)
			  uIDcount++;
		}
		}
		fclose (fp);
	}
	}

	segregs.ds = get_ds();
	segregs.es = segregs.ds;

	if (attr->na_type != NFDIR) {
	/* Set up the Scan File Information request block, as defined on */
	/* page 283 of the Novell API Reference, rev 1.00.       */

	static struct _sfireq sfireq =  /* These are placed in static */
	  {0, 0x0F, -1, -1, 0, 0, 0};   /* memory because code here   */
	static struct _sfirep sfirep;   /* assumes seg register DS.   */

	sfireq.handle = handle;
	sfireq.pathlen = strlen (path);
	sfireq.len = 6 + sfireq.pathlen;
	sfirep.len = sizeof (sfirep) -2;
	strcpy (sfireq.path, path);

	novell_API(0xE3, &sfireq, &sfirep, regsin, &regsout, &segregs);
	if (regsout.h.al != 0) {
		DBGPRT2 (nfsdebug, "%s sfi err %d", path, regsout.h.al);
		return FALSE;
	}
	attr->na_uid = sfirep.info.ownerID;
	attr->na_gid = gID;
	}
	else {
	/* Special case for directories:  invoke Scan Directory For   */
	/* Trustees system call, defined on p. 280 of Novell API Ref. */

	/* Load the protection bits */
	attr->na_mode = UPERM_DIR | novelldirprot;
#if 0
	/* SDFT not supported because Novell allows a directory to be */
	/* a member of several groups while Unix only attaches one    */
	/* group ID to the file.  We punt and just return the same    */
	/* group every time, to avoid confusion.              */

	static struct _sdftreq sdftreq = {0, 0x0C, 0, 0, 0};
	static struct _sdftrep sdftrep;

	sdftreq.handle = handle;
	sdftreq.pathlen = strlen (path);
	sdftreq.len = 4 + sdftreq.pathlen;
	sdftrep.len = sizeof (sdftrep) -2;
	strcpy (sdftreq.path, path);

	novell_API (0xE2, &sdftreq, &sdftrep, regsin, &regsout, &segregs);
	if (regsout.h.al == 0) {
		attr->na_uid = sdftrep.ownerID;
	}
	else
#endif /* 0 */
	{
		/* If SDFT call failed, usually due to access problems, */
		/* use the Scan Directory Info call.            */
		static struct _sdireq sdireq = {0, 0x02, 0, 0, 0};
		static struct _sdirep sdirep;

		sdireq.handle = handle;
		sdireq.pathlen = strlen (path);
		sdireq.len = 5 + sdireq.pathlen;
		sdirep.len = sizeof (sdirep) -2;
		strcpy (sdireq.path, path);

		novell_API (0xE2, &sdireq, &sdirep, regsin, &regsout, &segregs);
		DBGPRT3 (nfsdebug, "SDIREQ %d: %d %ld", sdireq.handle, regsout.h.al,
			 sdirep.ownerID);
		if (regsout.h.al != 0)
		  return FALSE;
		attr->na_uid = sdirep.ownerID;
		attr->na_gid = gID;
	}
	}

	DBGPRT2 (nfslookup, "%s ID = %ld", path, attr->na_uid);

	/* Look for ID in mapping table */
	for (i = 0; i < uIDcount; i++)
	  if (uIDmappings[i].Novell_ID == attr->na_uid) {
	  attr->na_uid = uIDmappings[i].unix_ID;
	  return TRUE;
	  }

	/* Not found in mapping table:  add the offset and return. */
	attr->na_uid += uIDoffset;
	return TRUE;
}
#endif /* NOVELL */

