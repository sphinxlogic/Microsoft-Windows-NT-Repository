/******************************************************************************\
*
*  MODULE:      THE_DLL.C
*
*  PURPOSE:     To provide the required (simple) entry point for a resource-
*               only DLL.
*
*  FUNCTIONS:   DLLEntryPoint() - DLL entry point
*
*                           Microsoft Developer Support
*                     Copyright (c) 1992 Microsoft Corporation
*
\******************************************************************************/

#include <windows.h>



/******************************************************************************\
*
*  FUNCTION:    DLLEntryPoint
*
*  INPUTS:      hDLL       - handle of DLL
*               dwReason   - indicates why DLL called
*               lpReserved - reserved
*
*  RETURNS:     TRUE (always, in this example.)
*
*               Note that the retuRn value is used only when
*               dwReason = DLL_PROCESS_ATTACH.
*
*               Normally the function would return TRUE if DLL initial-
*               ization succeeded, or FALSE it it failed.
*
\******************************************************************************/

BOOL WINAPI DLLEntryPoint (HANDLE hDLL, DWORD dwReason, LPVOID lpReserved)
{
  return TRUE;
}
