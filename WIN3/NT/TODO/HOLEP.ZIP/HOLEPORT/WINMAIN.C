#include "os2win.h"
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <ctype.h>

int WINAPI WinMain(HANDLE hinstance, HANDLE hPrev, LPSTR lpszCmdLine,
    int nCmd)
    {
    int argc = 1;
    char **argv;
    char ch;
    char *pch;
    int ii;
	 int uRet;


    HP_SetHinst(hinstance);

    nCmdShow = nCmd;

    pch = lpszCmdLine;

    while (iswspace(ch))
        ch = *++pch;

    while (ch = *pch)
        {
        while (!iswspace(ch) && ch)
            ch = *++pch;
        argc++;
        while (iswspace(ch))
            ch = *++pch;
        }

    argv = (char **) malloc(argc * sizeof(char *));
    

    pch = lpszCmdLine;
	 ch = *pch;

    while (iswspace(ch))
        ch = *++pch;

	 argv[0] = "executable";
    for (ii = 1; ii < argc; ii++)
        {
        argv[ii] = pch;

        while (!iswspace(ch) && ch)
            ch = *++pch;
        
        *pch++ = 0x00;

        while (iswspace(ch))
            ch = *++pch;
        }

	 try {
	  	  uRet = main(argc, argv);
		  }
	 except( EXCEPTION_EXECUTE_HANDLER)
	 	  {
		  fprintf( stderr, "Exception %ld Terminates App\n", GetExceptionCode());
		  }

    return(uRet);


    }

