#include <windows.h>
#include <mmsystem.h>
#include <stdio.h>


int PASCAL WinMain(HINSTANCE hinstance, HINSTANCE hprevinstance,
		   LPSTR lpszcmdparam, int ncmdshow)
{
int   volume;
BOOL  error = sscanf(lpszcmdparam, "%d", &volume) != 1;
WORD  half;
DWORD both;

if (!error && volume >= 0 && volume <= 255)
  {
  half = ((WORD) volume) * 256 + ((WORD) volume);
  both = (half << 16) + half;
  waveOutSetVolume(0, both);
  }
else
  waveOutSetVolume(0, -1);

ExitProcess(0);
}
