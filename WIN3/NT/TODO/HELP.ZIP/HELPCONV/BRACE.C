#include <stdio.h>

FILE *fp_in;

main( argc, argv)
	int argc;
	char *argv[];
    {
    int ii_brace = 0;
    char ch;

    fp_in  = freopen( "out.rtf", "rt", stdin);

    while ( (ch = fgetc( fp_in)) != EOF )
        {
        switch( ch)
            {
            case '{':   ii_brace++; break;
            case '}':   ii_brace--; break;
            default:
                break;
            }
        }
    if (ii_brace == 0)
        printf( "Braces match\n");
    else
        printf( "Brace count %d\n", ii_brace);

    }    
