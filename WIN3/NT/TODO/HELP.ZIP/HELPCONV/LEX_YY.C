# include "stdio.h"
# define U(x) x
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX 200
# define output(c) putc(c,yyout)
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
# define ECHO fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin ={stdin}, *yyout ={stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;
#include "token.h"
# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:
                  return(COMMENT);
break;
case 2:
                   return(COMMENT);
break;
case 3:
                 return(COLON);
break;
case 4:
                      return(COLON);
break;
case 5:
               return(NTEXT);
break;
case 6:
                      return(NTEXT);
break;
case 7:
                     return(NL);
break;
case 8:
           return(HDR);
break;
case 9:
                  return(NDX1);
break;
case 10:
               return(NDX2);
break;
case 11:
                 return(HPT);
break;
case 12:
                return(EHPT);
break;
case 13:
                   return(PARA);
break;
case 14:
                  return(PARA);
break;
case 15:
        return(FNREF);
break;
case 16:
        return(HDREF);
break;
case 17:
             return(STYLE);
break;
case 18:
            return(ESTYLE);
break;
case 19:
                  return(MARGIN);
break;
case 20:
             return(MARGIN);
break;
case 21:
                  return(NOTE);
break;
case 22:
             return(NOTE);
break;
case 23:
                 return(ENOTE);
break;
case 24:
                 return(XMP);
break;
case 25:
                return(EXMP);
break;
case 26:
                return(LI);
break;
case 27:
            return(SL);
break;
case 28:
  return(SLC);
break;
case 29:
           return(ESL);
break;
case 30:
             return(DL);
break;
case 31:
                 return(EDL);
break;
case 32:
                return(DTHD);
break;
case 33:
                return(DDHD);
break;
case 34:
                return(DT);
break;
case 35:
                return(DD);
break;
case 36:
          return(DL);
break;
case 37:
              return(EDL);
break;
case 38:
                  return(DT);
break;
case 39:
                  return(DD);
break;
case 40:
        return(ARTWORK);
break;
case 41:
             return(FN);
break;
case 42:
                 return(EFN);
break;
case 43:
             return(USERDOC);
break;
case 44:
            return(EUSERDOC);
break;
case -1:
break;
default:
fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */
#include "main.c"
int yyvstop[] ={
0,

5,
0,

5,
0,

5,
0,

7,
0,

6,
0,

4,
0,

2,
5,
0,

1,
5,
0,

2,
0,

1,
0,

9,
0,

13,
0,

35,
0,

34,
0,

8,
0,

10,
0,

26,
0,

19,
0,

14,
0,

21,
0,

27,
0,

39,
0,

38,
0,

30,
0,

31,
0,

42,
0,

23,
0,

29,
0,

41,
0,

17,
0,

11,
0,

20,
0,

22,
0,

24,
0,

3,
0,

33,
0,

32,
0,

18,
0,

12,
0,

25,
0,

15,
0,

16,
0,

37,
0,

36,
0,

43,
0,

40,
0,

44,
0,

28,
0,
0};
# define YYTYPE int
struct yywork { YYTYPE verify, advance; } yycrank[] ={
0,0,	0,0,	1,3,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	7,7,	0,0,	1,4,	
0,0,	3,0,	0,0,	0,0,	
0,0,	0,0,	7,0,	0,0,	
8,8,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	8,0,	0,0,	0,0,	
0,0,	1,3,	0,0,	0,0,	
0,0,	2,7,	0,0,	1,5,	
7,7,	3,0,	0,0,	0,0,	
0,0,	0,0,	7,22,	1,3,	
2,8,	1,3,	0,0,	8,8,	
15,41,	15,42,	7,7,	0,0,	
7,7,	8,23,	0,0,	1,6,	
2,6,	3,0,	27,58,	0,0,	
0,0,	8,8,	0,0,	8,8,	
0,0,	14,38,	14,38,	14,38,	
14,38,	14,38,	14,38,	14,38,	
14,38,	14,38,	14,38,	38,71,	
42,75,	44,77,	46,80,	0,0,	
19,48,	0,0,	37,69,	47,82,	
0,0,	0,0,	43,76,	45,79,	
50,85,	51,86,	0,0,	44,78,	
46,81,	26,56,	0,0,	28,59,	
5,9,	47,83,	6,10,	0,0,	
0,0,	6,11,	6,12,	6,13,	
0,0,	6,14,	6,15,	13,37,	
1,3,	6,16,	9,24,	6,17,	
6,18,	6,19,	10,25,	7,7,	
6,18,	14,39,	6,20,	11,26,	
17,46,	6,21,	18,47,	21,53,	
22,22,	6,18,	8,8,	11,27,	
12,29,	14,40,	12,30,	19,49,	
12,31,	22,0,	19,50,	11,28,	
24,54,	16,43,	12,32,	12,33,	
12,34,	16,44,	20,47,	12,33,	
16,45,	12,35,	25,55,	23,23,	
12,36,	20,52,	19,51,	26,57,	
12,33,	28,60,	29,61,	22,22,	
23,0,	30,62,	31,63,	32,64,	
33,65,	34,66,	36,68,	35,65,	
37,70,	39,72,	41,41,	49,84,	
52,87,	22,22,	35,67,	22,22,	
53,88,	54,89,	55,90,	41,0,	
57,91,	60,93,	23,23,	40,73,	
40,73,	40,73,	40,73,	40,73,	
40,73,	40,73,	40,73,	40,73,	
40,73,	61,94,	56,56,	58,58,	
23,23,	62,95,	23,23,	59,59,	
64,98,	41,41,	65,99,	56,0,	
58,0,	66,100,	67,101,	41,41,	
59,0,	68,102,	70,104,	72,105,	
69,69,	73,106,	74,107,	41,41,	
82,110,	41,41,	84,111,	87,112,	
88,113,	69,0,	89,114,	90,115,	
91,116,	56,56,	58,58,	92,0,	
93,117,	96,118,	59,59,	56,56,	
58,58,	97,119,	100,120,	101,121,	
59,59,	102,122,	22,22,	56,56,	
58,92,	56,56,	58,58,	69,69,	
59,59,	71,71,	59,59,	103,0,	
104,123,	69,69,	105,124,	40,74,	
108,0,	109,0,	71,0,	110,125,	
111,126,	69,103,	112,127,	69,69,	
115,128,	23,23,	63,96,	63,96,	
63,96,	63,96,	63,96,	63,96,	
63,96,	63,96,	63,96,	63,96,	
120,129,	121,130,	125,133,	126,134,	
71,71,	127,135,	128,136,	75,75,	
41,41,	129,137,	71,71,	130,138,	
76,76,	133,139,	135,141,	136,142,	
75,0,	138,143,	71,71,	139,144,	
71,71,	76,0,	140,0,	141,145,	
143,147,	77,77,	144,148,	146,0,	
148,149,	149,150,	80,80,	0,0,	
56,56,	58,58,	77,0,	0,0,	
0,0,	59,59,	75,75,	80,0,	
0,0,	0,0,	123,123,	76,76,	
75,75,	0,0,	0,0,	0,0,	
0,0,	76,76,	69,69,	123,0,	
75,75,	0,0,	75,75,	124,124,	
77,77,	76,76,	63,97,	76,76,	
134,134,	80,80,	77,77,	0,0,	
124,0,	0,0,	0,0,	80,80,	
0,0,	134,0,	77,108,	0,0,	
77,77,	123,123,	0,0,	80,109,	
0,0,	80,80,	0,0,	123,123,	
0,0,	142,142,	0,0,	71,71,	
0,0,	0,0,	124,124,	123,131,	
0,0,	123,123,	142,0,	134,134,	
124,124,	0,0,	0,0,	0,0,	
0,0,	134,134,	0,0,	0,0,	
124,132,	0,0,	124,124,	0,0,	
0,0,	134,140,	0,0,	134,134,	
0,0,	0,0,	0,0,	0,0,	
142,142,	0,0,	0,0,	0,0,	
0,0,	75,75,	142,142,	0,0,	
0,0,	0,0,	76,76,	0,0,	
0,0,	0,0,	142,146,	0,0,	
142,142,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	77,77,	
0,0,	0,0,	0,0,	0,0,	
80,80,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
123,123,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	124,124,	0,0,	0,0,	
0,0,	0,0,	134,134,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	142,142,	
0,0};
struct yysvf yysvec[] ={
0,	0,	0,
yycrank+-1,	0,		yyvstop+1,
yycrank+-2,	yysvec+1,	yyvstop+3,
yycrank+-3,	yysvec+1,	yyvstop+5,
yycrank+0,	0,		yyvstop+7,
yycrank+1,	0,		yyvstop+9,
yycrank+5,	0,		yyvstop+11,
yycrank+-8,	0,		yyvstop+13,
yycrank+-19,	0,		yyvstop+16,
yycrank+3,	0,		0,	
yycrank+4,	0,		0,	
yycrank+23,	0,		0,	
yycrank+32,	0,		0,	
yycrank+1,	0,		0,	
yycrank+21,	0,		0,	
yycrank+3,	0,		0,	
yycrank+36,	0,		0,	
yycrank+8,	0,		0,	
yycrank+18,	0,		0,	
yycrank+38,	0,		0,	
yycrank+38,	0,		0,	
yycrank+18,	0,		0,	
yycrank+-127,	yysvec+7,	yyvstop+19,
yycrank+-150,	yysvec+8,	yyvstop+21,
yycrank+32,	0,		0,	
yycrank+34,	0,		0,	
yycrank+51,	0,		0,	
yycrank+30,	0,		0,	
yycrank+53,	0,		0,	
yycrank+50,	0,		0,	
yycrank+51,	0,		0,	
yycrank+50,	0,		0,	
yycrank+47,	0,		0,	
yycrank+56,	0,		0,	
yycrank+68,	0,		0,	
yycrank+59,	0,		0,	
yycrank+57,	0,		0,	
yycrank+54,	0,		0,	
yycrank+47,	0,		0,	
yycrank+55,	0,		0,	
yycrank+135,	0,		0,	
yycrank+-169,	0,		yyvstop+23,
yycrank+48,	0,		0,	
yycrank+44,	0,		0,	
yycrank+49,	0,		0,	
yycrank+45,	0,		0,	
yycrank+50,	0,		0,	
yycrank+55,	0,		0,	
yycrank+0,	0,		yyvstop+25,
yycrank+57,	0,		0,	
yycrank+46,	0,		0,	
yycrank+47,	0,		0,	
yycrank+71,	0,		0,	
yycrank+64,	0,		0,	
yycrank+66,	0,		0,	
yycrank+59,	0,		0,	
yycrank+-193,	0,		yyvstop+27,
yycrank+80,	0,		0,	
yycrank+-194,	0,		0,	
yycrank+-198,	0,		yyvstop+29,
yycrank+81,	0,		0,	
yycrank+147,	0,		0,	
yycrank+151,	0,		0,	
yycrank+214,	0,		0,	
yycrank+154,	0,		0,	
yycrank+156,	0,		0,	
yycrank+91,	0,		0,	
yycrank+105,	0,		0,	
yycrank+97,	0,		0,	
yycrank+-211,	0,		0,	
yycrank+109,	0,		0,	
yycrank+-244,	0,		yyvstop+31,
yycrank+110,	0,		0,	
yycrank+167,	0,		0,	
yycrank+168,	0,		0,	
yycrank+-278,	0,		yyvstop+33,
yycrank+-283,	0,		yyvstop+35,
yycrank+-296,	0,		0,	
yycrank+0,	0,		yyvstop+37,
yycrank+0,	0,		yyvstop+39,
yycrank+-301,	0,		0,	
yycrank+0,	0,		yyvstop+41,
yycrank+117,	0,		0,	
yycrank+0,	0,		yyvstop+43,
yycrank+109,	0,		0,	
yycrank+0,	0,		yyvstop+45,
yycrank+0,	0,		yyvstop+47,
yycrank+105,	0,		0,	
yycrank+174,	0,		0,	
yycrank+112,	0,		0,	
yycrank+112,	0,		0,	
yycrank+178,	0,		0,	
yycrank+-217,	yysvec+58,	yyvstop+49,
yycrank+182,	0,		0,	
yycrank+0,	0,		yyvstop+51,
yycrank+0,	0,		yyvstop+53,
yycrank+183,	0,		0,	
yycrank+187,	0,		0,	
yycrank+0,	0,		yyvstop+55,
yycrank+0,	0,		yyvstop+57,
yycrank+125,	0,		0,	
yycrank+121,	0,		0,	
yycrank+191,	0,		0,	
yycrank+-237,	yysvec+69,	yyvstop+59,
yycrank+146,	0,		0,	
yycrank+148,	0,		0,	
yycrank+0,	0,		yyvstop+61,
yycrank+0,	0,		yyvstop+63,
yycrank+-242,	yysvec+77,	yyvstop+65,
yycrank+-243,	yysvec+80,	yyvstop+67,
yycrank+144,	0,		0,	
yycrank+148,	0,		0,	
yycrank+158,	0,		0,	
yycrank+0,	0,		yyvstop+69,
yycrank+0,	0,		yyvstop+71,
yycrank+146,	0,		0,	
yycrank+0,	0,		yyvstop+73,
yycrank+0,	0,		yyvstop+75,
yycrank+0,	0,		yyvstop+77,
yycrank+0,	0,		yyvstop+79,
yycrank+164,	0,		0,	
yycrank+173,	0,		0,	
yycrank+0,	0,		yyvstop+81,
yycrank+-313,	0,		0,	
yycrank+-326,	0,		0,	
yycrank+165,	0,		0,	
yycrank+243,	0,		0,	
yycrank+166,	0,		0,	
yycrank+171,	0,		0,	
yycrank+235,	0,		0,	
yycrank+172,	0,		0,	
yycrank+0,	0,		yyvstop+83,
yycrank+0,	0,		yyvstop+85,
yycrank+173,	0,		0,	
yycrank+-331,	0,		0,	
yycrank+187,	0,		0,	
yycrank+255,	0,		0,	
yycrank+0,	0,		yyvstop+87,
yycrank+190,	0,		0,	
yycrank+194,	0,		0,	
yycrank+-284,	yysvec+134,	yyvstop+89,
yycrank+249,	0,		0,	
yycrank+-352,	0,		0,	
yycrank+250,	0,		0,	
yycrank+199,	0,		0,	
yycrank+0,	0,		yyvstop+91,
yycrank+-289,	yysvec+142,	yyvstop+93,
yycrank+0,	0,		yyvstop+95,
yycrank+184,	0,		0,	
yycrank+255,	0,		0,	
yycrank+0,	0,		yyvstop+97,
0,	0,	0};
struct yywork *yytop = yycrank+463;
struct yysvf *yybgin = yysvec+1;
char yymatch[] ={
00  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,012 ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
040 ,01  ,01  ,01  ,01  ,01  ,'&' ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,'.' ,01  ,
'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,
'0' ,'0' ,'&' ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,'o' ,
01  ,01  ,01  ,'o' ,01  ,'o' ,01  ,01  ,
01  ,01  ,01  ,01  ,'o' ,01  ,01  ,01  ,
0};
char yyextra[] ={
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
/*	ncform	4.1	83/08/11	*/

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
yylook(){
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank){		/* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
			*yylastch++ = yych = input();
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
yyback(p, m)
	int *p;
{
if (p==0) return(0);
while (*p)
	{
	if (*p++ == m)
		return(1);
	}
return(0);
}
	/* the following are only used in the lex library */
yyinput(){
	return(input());
	}
yyoutput(c)
  int c; {
	output(c);
	}
yyunput(c)
   int c; {
	unput(c);
	}
