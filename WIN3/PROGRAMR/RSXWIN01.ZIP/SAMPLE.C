#include <stdio.h>
#include "windows.h"

BOOL Dialog(HWND hWnd,WORD wMsg,WORD wPar,LONG lPar)
{
    switch (wMsg)
    {
        case WM_COMMAND :
            switch(wPar)
            {
                case WM_INITDIALOG :
                    return TRUE;
                case IDOK :
                    EndDialog(hWnd,TRUE);
                    return TRUE;
             }
             break;
        }
    return FALSE;
}

int WinMain(HANDLE hInstance, HANDLE hPrevInstance,LPSTR lpCmdLine, int nCmdShow)
{
    HWND hwnd = GetActiveWindow();
    FARPROC lpfnDialog ;

    MessageBox(0, "MessageBox\nHello Window\n","RSXWIN", MB_OK);

    lpfnDialog=MakeProcInstance(Dialog,hInstance);
    DialogBox(hInstance,(LPSTR)"WININICHANGE",NULL,lpfnDialog);
    FreeProcInstance(lpfnDialog);

    MessageBox(0, "test ok!\n","RSXWIN", MB_OK);

    return 0;
}
