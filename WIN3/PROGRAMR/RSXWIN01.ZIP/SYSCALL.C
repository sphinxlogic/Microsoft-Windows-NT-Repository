#include <string.h>
#include "WINDOWS.H"

typedef unsigned short USHORT;
typedef unsigned int UINT;
typedef unsigned long ULONG;
typedef unsigned short * stackw;

/*
** EAX =  31-fnct-16 , 0x7E , 7-count-0
** EDX =  offset modulname  or 1,2,3
** ECX =  paramlist
*/
UINT _wincall(UINT fnct, UINT module, UINT param, char count)
{
    register int reg_ax;

    __asm__("shll   $16, %%eax \n\t"
	    "movb   %1, %%al \n\t"
	    "movb   $0x7E, %%ah \n\t"
	    "pushl  %%esi \n\t"
	    "pushl  %%edi \n\t"
	    "pushl  %%ebx \n\t"
	    "pushl  %%ebp \n\t"
	    "call   ___syscall \n\t"
	    "popl   %%ebp \n\t"
	    "popl   %%ebx \n\t"
	    "popl   %%edi \n\t"
	    "popl   %%esi \n\t"
	    : "=a" (reg_ax)
	    : "m" ((char)count), "a" (fnct) , "d" (module) , "c" (param) );

    return reg_ax;
}

USHORT get_ds(void)
{
    register unsigned short v;
    __asm__("mov %%ds, %0 \n\t"
	    : "=r" ((unsigned short) v) );
    return v;
}

#define M_GET_INSTANCE	    0
#define M_GET_CALLBACK	    1

#define MAGIC_INIT  0
#define USER	    1
#define GDI	    2
#define KERNEL	    3

#define ALLOCLPSTR(STRING) char *_##STRING = alloca( strlen(STRING) + 1 )
#define NOSTACK unsigned _st=0;char _count=0
#define STACKWORDS(words) \
    stackw _st = (stackw) alloca( (words) * sizeof(USHORT)); \
    void *_ps = _st; \
    char _count = words
#define PUSH_WORD(ARG)	    (*((USHORT *)_ps)++ = (ARG))
#define PUSH_LONG(ARG)	    (*((ULONG *)_ps)++ = (ARG))
#define PUSH_FP(ARG)	    *((USHORT *)_ps)++ = (ARG)>>16; *((USHORT *)_ps)++ = (USHORT)(ARG)
#define PUSH_LPSTR(ARG)     strcpy( _##ARG, ARG); PUSH_WORD(get_ds()); PUSH_WORD((USHORT)(UINT) _##ARG)
#define WINCALL(fnc,mod)    _wincall(fnc,mod,(unsigned)_st,_count)

extern int WinMain(HANDLE hInst, HANDLE hPrev,LPSTR lpCmdLine, int nCmdShow);
extern int callb32(void);

int __argc;
char **__argv;
char **__env;

int main(int argc,char **argv,char **env)
{
    HANDLE hInstance;
    HANDLE hPrevInstance;
    UINT ret;

    __argc = argc;
    __argv = argv;
    __env = env;

    ret = _wincall(M_GET_INSTANCE, MAGIC_INIT,(UINT)callb32,0);

    hInstance = (HANDLE)(ret >> 16);
    hPrevInstance = (HANDLE) ret;

    return WinMain(hInstance,hPrevInstance,NULL,SW_NORMAL);
}

FARPROC MakeProcInstance(FARPROC callback, HANDLE hInst)
{
    return (FARPROC) _wincall(M_GET_CALLBACK, MAGIC_INIT, (UINT)callback, 0);
}

int TestCallback(FARPROC callback)
{
    return _wincall(2, MAGIC_INIT, (UINT)callback, 0);
}

void FreeProcInstance(FARPROC thrunk)
{
    STACKWORDS(2);
    PUSH_FP((UINT)thrunk);
    WINCALL(52,KERNEL);
}

short DialogBox(HANDLE hInst, LPSTR dialogname, HWND hWnd, FARPROC thrunk)
{
    STACKWORDS(1+2+1+2);
    ALLOCLPSTR(dialogname);

    PUSH_WORD(hInst);
    PUSH_LPSTR(dialogname);
    PUSH_WORD(hWnd);
    PUSH_FP((UINT)thrunk);
    return WINCALL(87,USER);
}

void EndDialog(HWND hWnd, short ret)
{
    STACKWORDS(1+1);
    PUSH_WORD(hWnd);
    PUSH_WORD(ret);
    WINCALL(88,USER);
}

USHORT GetVersion(void)
{
    NOSTACK;
    return WINCALL(3,KERNEL);
}

long GetWinFlags(void)
{
    NOSTACK;
    return WINCALL(132,KERNEL);
}

HANDLE GetModuleHandle(LPSTR module_name)
{
    STACKWORDS(2);
    ALLOCLPSTR(module_name);

    PUSH_LPSTR(module_name);
    return WINCALL(47,KERNEL);
}

short MessageBox(HWND wnd, LPSTR text, LPSTR title, WORD flags)
{
    STACKWORDS(1+2+2+1);
    ALLOCLPSTR(text);
    ALLOCLPSTR(title);

    PUSH_WORD(wnd);
    PUSH_LPSTR(text);
    PUSH_LPSTR(title);
    PUSH_WORD(flags);
    return WINCALL(1,USER);
}

HWND GetActiveWindow(void)
{
    NOSTACK;
    return WINCALL(60,USER);
}

HMENU CreatePopupMenu(void)
{
    NOSTACK;
    return WINCALL(415,USER);
}

BOOL  AppendMenu(HMENU hmenu, WORD mf, WORD id, LPSTR title)
{
    STACKWORDS(1+1+1+2);
    ALLOCLPSTR(title);

    PUSH_WORD(hmenu);
    PUSH_WORD(mf);
    PUSH_WORD(id);
    PUSH_LPSTR(title);
    return WINCALL(411,USER);
}

HMENU CreateMenu(void)
{
    NOSTACK;
    return WINCALL(151,USER);
}

BOOL  SetMenu(HWND hwnd, HMENU hmenu)
{
    STACKWORDS(1+1);

    PUSH_WORD(hwnd);
    PUSH_WORD(hmenu);
    return WINCALL(158,USER);
}

void DrawMenuBar(HWND hwnd)
{
    STACKWORDS(1);

    PUSH_WORD(hwnd);
    WINCALL(160,USER);
}

BOOL DestroyMenu(HWND hwnd)
{
    STACKWORDS(1);

    PUSH_WORD(hwnd);
    WINCALL(152,USER);
}
