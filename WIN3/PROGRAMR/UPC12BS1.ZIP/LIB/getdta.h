/*--------------------------------------------------------------------*/
/*    g e t d t a . h                                                 */
/*                                                                    */
/*    Disk Transfer Address functions for MS C under DOS only for     */
/*    UUPC/extended                                                   */
/*                                                                    */
/*    Changes and Compilation Copyright (c) 1989-1993, Andrew H.      */
/*    Derbyshire                                                      */
/*--------------------------------------------------------------------*/

char far *getdta( void );

void setdta( char far *dtaptr );
