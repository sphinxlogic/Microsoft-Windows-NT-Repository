/*--------------------------------------------------------------------*/
/*    d c p s t a t s . h                                             */
/*                                                                    */
/*    UUPC/extended header file for file transfer stats               */
/*--------------------------------------------------------------------*/

/*--------------------------------------------------------------------*/
/*       Changes Copyright (c) 1989-1993 by Kendra Electronic         */
/*       Wonderworks.                                                 */
/*                                                                    */
/*       All rights reserved except those explicitly granted by       */
/*       the UUPC/extended license agreement.                         */
/*--------------------------------------------------------------------*/

/*
 *       $Id: dcpstats.h 1.2 1993/09/20 04:53:57 ahd Exp $
 *
 *       $Log: dcpstats.h $
 * Revision 1.2  1993/09/20  04:53:57  ahd
 * TCP/IP support from Dave Watt
 * 't' protocol support
 * OS/2 2.x support (BC++ 1.0 for OS/2 support)
 *
 */
void dcupdate( void );
void dcstats(void);
