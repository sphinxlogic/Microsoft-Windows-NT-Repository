/*--------------------------------------------------------------------*/
/*    n b s t i m e . h                                               */
/*                                                                    */
/*    Set local system clock from National Bureau of Standards        */
/*    Standard Time service                                           */
/*                                                                    */
/*    Copyright (c) 1991, Andrew H. Derbyshire                        */
/*    See README.PRN for distribution restrictions and additional     */
/*    copyrights                                                      */
/*--------------------------------------------------------------------*/

boolean nbstime( void );
