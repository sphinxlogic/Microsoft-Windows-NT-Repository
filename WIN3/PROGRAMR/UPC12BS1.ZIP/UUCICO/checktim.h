/*--------------------------------------------------------------------*/
/*    c h e c k t i m . h                                             */
/*                                                                    */
/*    Function prototypes for time of day validation routines for     */
/*    UUPC/extended                                                   */
/*--------------------------------------------------------------------*/

#define ALL_GRADES 'z'

char checktime(const char *xtime);
