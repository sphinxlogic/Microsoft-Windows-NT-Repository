/*
   dcplib.h

   System dependent (non-communications related) routines for
   UUPC.
*/

boolean login(void);

boolean loginbypass(const char *user);
