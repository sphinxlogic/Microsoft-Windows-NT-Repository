/*
** running bound DJGPP exe-files
** run only rsxdj.exe
**
** Rainer Schnitker
*/

#include <process.h>
#include <dos.h>
#include <memory.h>

unsigned _heaplen = 8192;
unsigned _stklen = 4096;
extern unsigned _psp;

void x2s(int v, char *s)
{
    static char hex[] = "0123456789abcdef";
    int i;

    for (i=0; i<4; i++) {
	s[3-i] = hex[v&15];
	v >>= 4;
    }
    s[4] = 0;
}

void print_string_stdout(char *s)
{
    _AH = 0x09;
    _DX = (unsigned) s;
    geninterrupt(0x21);
}

static char rsx_name[]="RSXDJ.EXE";

/* copy of PSP (because TCC/BCC spawn() destroy PSP at 0x80) */
static char psp_copy[256+16];

main(void)
{
    char psp_string[7];     /* command line -/xxxx/ where xxxx PSP segment */
    unsigned psp_segm;
    int r;

    psp_segm = _DS + (((unsigned)psp_copy + 15) >> 4);
    movedata(_psp, 0, psp_segm, 0, 256);
    psp_string[0]='-';
    psp_string[1]='/';
    x2s(psp_segm, psp_string+2);
    psp_string[6]='/';
    psp_string[7]='\0';
    r = spawnlp(P_WAIT, rsx_name, rsx_name, psp_string, 0);
    if (r == -1)
	print_string_stdout("Cannot run rsxdj.exe\r\n$");
    return r;
}
