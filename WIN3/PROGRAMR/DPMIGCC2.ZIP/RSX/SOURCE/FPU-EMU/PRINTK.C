int printk (const char *format, ...)
    {
    }
