
void verify_area(int type,void * addr,int count)
{
    return;
}
