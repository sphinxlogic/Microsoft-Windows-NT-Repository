/*
** running bound DJGPP exe-files
** go32.exe without DPMI
** rsxdj.exe with DPMI
**
** Rainer Schnitker
*/

#include <process.h>
#include <dos.h>
#include <memory.h>

unsigned _heaplen = 8192;
unsigned _stklen = 4096;
extern unsigned _psp;


void x2s(int v, char *s)
{
    static char hex[] = "0123456789abcdef";
    int i;

    for (i=0; i<4; i++) {
	s[3-i] = hex[v&15];
	v >>= 4;
    }
    s[4] = 0;
}

void print_string_stdout(char *s)
{
    _AH = 0x09;
    _DX = (unsigned) s;
    geninterrupt(0x21);
}

int dpmi_host(void)     /* ret = 0 DPMI, else not */
{
    _AX = 0x1687;
    geninterrupt(0x2F);
    return _AX;
}

char rsx_name[]="RSXDJ.EXE";
char go32_name[]="GO32.EXE";

/* copy of PSP (because TCC/BCC spawn() destroy PSP at 0x80) */
char psp_copy[256+16];

main(int argc, char **argv)
{
    char s_argc[5], s_seg[5], s_argv[5];
    char psp_string[7];     /* command line -/xxxx/ where xxxx PSP segment */
    unsigned psp_segm;
    int r;

    if (dpmi_host() == 0) {
	psp_segm = _DS + (((unsigned)psp_copy + 15) >> 4);
	movedata(_psp, 0, psp_segm, 0, 256);
	psp_string[0]='-';
	psp_string[1]='/';
	x2s(psp_segm, psp_string+2);
	psp_string[6]='/';
	psp_string[7]='\0';
	r = spawnlp(P_WAIT, rsx_name, rsx_name, psp_string, 0);
	if (r == -1)
	    print_string_stdout("Cannot run rsx.exe\r\n$");
    }
    else {
	x2s(argc, s_argc);
	x2s( _DS, s_seg);
	x2s((int)argv, s_argv);
	r = spawnlp(P_WAIT, go32_name, go32_name, "!proxy", s_argc, s_seg, s_argv, 0);
	if (r == -1)
	    print_string_stdout("Cannot run go32.exe\r\n$");
    }
    return r;
}
