#include <stdio.h>
#include "DPMI.H"
#include "PROCESS.H"
#include "ADOSX32.H"
#include "DEBUG.H"
#include "RSX.H"

void debugger(char *filename, int deb_cmd)
{
    opt_debug = 0 ;
#ifdef _EMX_
    printf("Use RSXDEB.EXE -S to debug %s\n",filename);
#else
    printf("Use RSXDJDEB.EXE -S to debug %s\n",filename);
#endif
    shut_down(1);
}

void debug_update_breakpoints(void)
{
}
