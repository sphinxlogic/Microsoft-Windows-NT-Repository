#include <windows.h>

long arg1, arg2, ret;

int far pascal LibMain(HANDLE hModule, WORD wDataSeg, WORD cbHeapSize, LPSTR lpszCmdLine)
{
	return TRUE;
}

long far pascal AddTwo(long far *Numbers)
{
	arg1=*Numbers;
	arg2=*(++Numbers);
	ret=arg1+arg2;
	return (ret);
}

long far pascal SubTwo(long far *Numbers)
{
	arg1=*Numbers;
	arg2=*(++Numbers);
	ret=arg1-arg2;
	return (ret);
}

long far pascal MultTwo(long far *Numbers)
{
	arg1=*Numbers;
	arg2=*(++Numbers);
	ret=arg1*arg2;
	return (ret);
}


long far pascal DivTwo(long far *Numbers)
{
	arg1=*Numbers;
	arg2=*(++Numbers);
	ret=arg1/arg2;
	return (ret);
}

long far pascal SumArray(long far *Numbers)
{
	long b, sum, SizeofArray, Index;
	long far *SumAddress;

	sum=0;
	SizeofArray=*Numbers;
	Numbers++;
	SumAddress=Numbers;
	for (Index=0;Index<(SizeofArray+1); Index++)
	 {  Numbers++;
	    b=*Numbers;
		sum += b; }
	*SumAddress=sum;
	return(1l);
}
