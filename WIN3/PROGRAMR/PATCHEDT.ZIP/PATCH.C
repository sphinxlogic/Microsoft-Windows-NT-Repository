#define 	NOCOMM
#include	<windows.h>

	extern	FARPROC 	lpwfEditControl;
	extern	HANDLE		hndUserExe;

	typedef struct {
		WORD		unknown[5];
		HANDLE	hmem;
	} WND;

LONG FAR PASCAL wfPatchEditControl
		(WORD hWnd, WORD message, WORD wParam, DWORD lParam)
{
	LONG	retcode;

	retcode = CallWindowProc(lpwfEditControl, hWnd, message, wParam, lParam);

	if ( message == WM_NCCREATE ) {
		WORD			 dsLocal,
							 dsUser 	= HIWORD(GlobalLock(hndUserExe));

		if ( dsUser ) {
			_asm	mov 	dsLocal, ds;
			_asm	mov 	ds, dsUser;
			if ( ((WND *)hWnd)->hmem ) {
				LocalFree(((WND *)hWnd)->hmem); 	((WND *)hWnd)->hmem = 0;
			}
			_asm	mov 	ds, dsLocal;
		}
	}
	return(retcode);
}
