/*
 *
 */

#define 	NOCOMM
#include	<windows.h>

				 FARPROC	lpwfEditControl;
				 HANDLE 	hndUserExe;
	static char 		szUserExe[] = { "user.exe" },
									szEdit[]		= { "edit" };

	extern LONG FAR PASCAL wfPatchEditControl
						(WORD hWnd, WORD message, WORD wParam, DWORD lParam);


int FAR PASCAL LibMain
		(HANDLE hInstance, WORD wDataSeg, WORD cbHeapSize, LPSTR lpCmdLine)
{
	WORD			Version = GetVersion();
	HWND			hWnd;
	WNDCLASS	wc;

	if ( LOBYTE(Version)>=3 && HIBYTE(Version)>=1 ||
			(hndUserExe=LoadLibrary(szUserExe))==0 )			return(0);

	GetClassInfo(NULL, szEdit, &wc);
	UnregisterClass(szEdit, NULL);
	lpwfEditControl 	= (FARPROC)wc.lpfnWndProc;
	wc.lpfnWndProc		= wfPatchEditControl;
	wc.lpszClassName	= szEdit;
	RegisterClass(&wc);

	return(1);
}

/*
void FAR PASCAL TestEntry(void)
{
	return;
}
 */

int FAR PASCAL WEP
		(short code)
{
	return(0);
}
