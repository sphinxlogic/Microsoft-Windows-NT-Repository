/* ENTASK.DLL -- Author Jeff Simms -- CIS 72200,3173 -- August 1, 1992 

Purpose - Subclass VB apps "invisible parent" and redirect WM_CLOSE sent by task list to VB apps form of choice.

Public Domain */

#include <windows.h>
#include "entask.h"


FARPROC  lpfnVBRTMainWndProc;
HWND hvbmain,hvbform;

int FAR PASCAL WEP (int bSystemExit)
{
    return (1);
}

VOID __export FAR PASCAL SetEndTaskHook(HWND hVBForm)
{
    hvbform = hVBForm;

    hvbmain = FindWindow("ThunderRTMain", NULL);

    lpfnVBRTMainWndProc = (FARPROC) SetWindowLong(hvbmain,GWL_WNDPROC,
				     (DWORD)(FARPROC) MainFilterProc);

}


VOID __export FAR PASCAL UndoEndTaskHook(int zero)
{

    SetWindowLong(hvbmain,GWL_WNDPROC, (DWORD)(FARPROC) lpfnVBRTMainWndProc);

}



LONG __export FAR PASCAL MainFilterProc(HWND hWnd,unsigned wMsg,WORD wParam,LONG lParam)
{

       if (wMsg == WM_CLOSE)
	{
	PostMessage(hvbform,WM_CLOSE,0,0);
	return 0;
	}

  return(CallWindowProc(lpfnVBRTMainWndProc,hWnd, wMsg, wParam, lParam));
}
