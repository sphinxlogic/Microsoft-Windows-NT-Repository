/****************************************************************************
 Util.c

 The Util module handles misc. low-level utilities.

****************************************************************************/
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1992.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
#include "windows.h"
#include "util.h"


/****************************************************************************
   Globals
****************************************************************************/

HCURSOR hcurSave;    /* saved cursor before hourglass is shown */


/****************************************************************************
   Functions
****************************************************************************/


int ToIntegerPin (long l)
{
   if (l > MAXINT)
      return MAXINT;
   else if (l < -MAXINT)
      return -MAXINT;
   else
      return (int)l;
}


int Min (int x, int y)
{
   return (x < y) ? x : y;
}


int Max (int x, int y)
{
   return (x > y) ? x : y;
}


unsigned long HexToLong (char *s)
{
   unsigned long l = 0L;
   register char c;

   for (; (c = *s); s++)
   {
      if (c >= '0' && c <= '9')
      {
         l = l * 16 + c - '0';
      }
      else if (c >= 'A' && c <= 'F')
      {
         l = l * 16 + c - 'A' + 10;
      }
      else if (c >= 'a' && c <= 'f')
      {
         l = l * 16 + c - 'a' + 10;
      }
   }
   return l;
}
