//---------------------------------------------------------------------------
//  DLLSTUFF - Windows DLL support functions
//
//  This File contains the source code for the standard DLL functions
//
//  Author:	Kyle Marsh
//              Windows Developer Technology Group
//              Microsoft Corp.
//
//---------------------------------------------------------------------------
/* COPYRIGHT:

     (C) Copyright Microsoft Corp. 1992.  All rights reserved.

     You have a royalty-free right to use, modify, reproduce and
     distribute the Sample Files (and/or any modified version) in
     any way you find useful, provided that you agree that
     Microsoft has no warranty obligations or liability for any
     Sample Application Files which are modified.*/
#include "windows.h"

//---------------------------------------------------------------------------
// Function declarations
//---------------------------------------------------------------------------


int FAR PASCAL LibMain (HANDLE hModule, WORD wDataSeg, WORD cbHeapSize, LPSTR
                        lpszCmdLine);
int FAR PASCAL WEP (int bSystemExit);

//---------------------------------------------------------------------------
// Global Variables...
//---------------------------------------------------------------------------

HANDLE hInstance;              // Global instance handle for  DLL

//---------------------------------------------------------------------------
// LibMain
//---------------------------------------------------------------------------


int FAR PASCAL LibMain (HANDLE hModule, WORD wDataSeg, WORD cbHeapSize, LPSTR
                        lpszCmdLine)
{
   hInstance = hModule;
   return 1;
}
#pragma alloc_text(FIXEDSEG, WEP)

//---------------------------------------------------------------------------
// WEP
//---------------------------------------------------------------------------


int FAR PASCAL WEP (int bSystemExit)
{
   return (1);
}
