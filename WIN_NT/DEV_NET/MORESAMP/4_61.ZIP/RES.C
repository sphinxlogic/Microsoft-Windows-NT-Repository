//*************************************************************
//  File name: res.c
//
//  Description: 
//      Code for displaying resources
//
//  History:    Date       Author     Comment
//               1/21/92   MSM        Created
//               9/14/92   Krishna    Modified to be able to save rsrcs.
//
// Written by Microsoft Product Support Services, Windows Developer Support
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//*************************************************************

#include "global.h"
#include "string.h"
#include "cderr.h"

extern char *rc_types[];

//*************************************************************
//
//  DisplayResource
//
//  Purpose:
//      Attempts to display the given resource
//
//
//  Parameters:
//      PEXEINFO pExeInfo
//      PRESTYPE ptr
//      PRESINFO pri
//      
//
//  Return: (BOOL)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//              1/21/92    MSM        Created
//              9/14/92    Krishna    Modified to display only bmp/cur/ico
//*************************************************************

BOOL DisplayResource ( PEXEINFO pExeInfo, PRESTYPE prt, PRESINFO pri )
{
    int      fFile;
    OFSTRUCT of;
    int      nErr = 0;
    RESPACKET rp;
    LPRESPACKET lprp = &rp;
    LONG     lSize;
    LONG     lOffset;
    HANDLE   hMem;
    LPSTR    lpMem;
    char huge *lpTMem;

    if (!pExeInfo || !prt || !pri)
    {
        MessageBox(ghWndMain,"Unable to display resource!","ResExt",MB_OK);
        return FALSE;
    }

    if (pExeInfo->NewHdr.wExpVersion < 0x0300)  // Win 2.x app??
    {
        MessageBox(ghWndMain,"Unable to display resource!  Windows 2.X app.",
                   "ResExt",MB_OK);
        return FALSE;
    }

    fFile = OpenFile( pExeInfo->pFilename, &of, OF_READ );
    if (!fFile)
    {
        MessageBox(ghWndMain,"Could not open file!","ResExt",MB_OK);
        return FALSE;
    }

    // Calculate the position in the the file and move file pointer
    lOffset = ((LONG)pri->wOffset)<<(pExeInfo->wShiftCount);
    
    _llseek( fFile, lOffset, 0 );

    // Allocate memory for resource
    lSize   = ((LONG)pri->wLength)<<(pExeInfo->wShiftCount);
    hMem = GlobalAlloc( GHND, lSize );

    if (!hMem)
    {
        _lclose( fFile );
        MessageBox(ghWndMain,"Could not allocate memory for resource!",
                   "ResExt",MB_OK);
        return FALSE;
    }

    lpMem = GlobalLock( hMem );
    if (!lpMem)
    {
        _lclose( fFile );
        MessageBox(ghWndMain,"Could not lock memory for resource!",
                   "ResExt",MB_OK);
        GlobalFree( hMem );
        return FALSE;
    }

    // Read in resource from file
    lpTMem = (char huge *)lpMem;

    SetCursor( LoadCursor(NULL, IDC_WAIT) );
    if (_hread(fFile, (void _huge*)lpTMem, lSize) == -1) // -1 is failure
    {
        _lclose( fFile );
        MessageBox(ghWndMain, "Error reading from file!", "ResExt", MB_OK);
        GlobalUnlock( hMem );
        GlobalFree( hMem );
        return FALSE;
    }
    SetCursor( LoadCursor(NULL, IDC_ARROW) );


    // Build a resource packet.  This allows the passing of all the
    // the needed info with one 32 bit pointer.
    rp.pExeInfo = pExeInfo;
    rp.prt      = prt;
    rp.pri      = pri;
    rp.lSize    = ((LONG)pri->wLength)<<(pExeInfo->wShiftCount);
    rp.lpMem    = lpMem;
    rp.fFile    = fFile;


    if (prt->wType & 0x8000)
    {
        switch (prt->wType & 0x7fff)
        {
            case RT_ICON:
            {
                FARPROC lpProc;

                lpProc = MakeProcInstance( (FARPROC)ShowIconProc, ghInst );

                // Re-use the GRAPHIC_DLG with a different DlgProc
                nErr = !DialogBoxParam( ghInst, "GRAPHIC_DLG", ghWndMain, 
                                        lpProc, (LONG)lprp );
                FreeProcInstance( lpProc );
            }
            break;

            case RT_CURSOR:
            {
                FARPROC lpProc;

                lpProc = MakeProcInstance( (FARPROC)ShowCursorProc, ghInst );

                // Re-use the GRAPHIC_DLG with a different DlgProc
                nErr = !DialogBoxParam( ghInst, "GRAPHIC_DLG", ghWndMain, lpProc,
                    (LONG)lprp );
                FreeProcInstance( lpProc );
            }
            break;

            case RT_BITMAP:
                ShowBitmap( lprp );
            break;

            default:
                nErr = TRUE;
            break;
        }
        if (!nErr)
        {
            _lclose( fFile );
            GlobalUnlock( hMem );
            GlobalFree( hMem );
            return TRUE;
        }
    }

    MessageBox(ghWndMain, "Unable to display resource!", "ResExt", MB_OK);
    _lclose( fFile );
    GlobalUnlock( hMem );
    GlobalFree( hMem );
    return FALSE;

} //*** DisplayResource

//*************************************************************
//
//  SaveResource
//
//  Purpose:
//      Saves the resource to a file chosen by the user.
//
//
//  Parameters:
//      LPSTR    lpMem - Buffer holding the resource.
//      LONG     lpMemSize - Number of bytes in the resource 
//                           buffer to be saved to file.
//      LPSTR    lpreshdr - Buffer containing file header for
//                          the resource.
//      WORD     wType - Type of resource.
//      
//
//  Return: TRUE if the resource is successfully saved to file.
//          FALSE otherwise.
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//
//              9/14/92    Krishna    Created
//*************************************************************

BOOL SaveResource (LPSTR lpMem, LONG lpMemSize, LPSTR lpreshdr, WORD wType)
{
    OPENFILENAME of;
    char         szFile[128];
    DWORD        dwError;
    UINT         uResHdrSize;
    static char szErr1[] = "Unable to display File Save dialog. Retry after closing some applications.";
    static char szErr[] = "ResExt Error";
    static char szErr2[] = "File name buffer passed with dialog is too small. Increase buffer size in SaveResource routine";  
    static char szErr3[] = "Resource was not saved. Try again.";

    memset( &of, 0, sizeof(OPENFILENAME) );

    szFile[0] = 0;

    // Prepare the of structure for GetSaveFileName  
    of.lStructSize  = sizeof(OPENFILENAME);
    of.nFilterIndex = 0;
    of.lpstrFile    = (LPSTR)szFile;
    of.nMaxFile     = sizeof(szFile);
    of.lpstrTitle   = (LPSTR)"Specify A File To Save The Resource";
    of.Flags        = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT
                              | OFN_PATHMUSTEXIST;

    switch (wType)
    {
       case CUR:
          of.lpstrFilter  = (LPSTR)"Cursor File\0*.CUR\0\0";
          of.lpstrDefExt  = (LPSTR)"CUR";
          uResHdrSize     = sizeof (CURSORDIR);  
          break;

       case ICO:
          of.lpstrFilter  = (LPSTR)"Icon File\0*.ICO\0\0";
          of.lpstrDefExt  = (LPSTR)"ICO";
          uResHdrSize = sizeof (ICONDIR);
          break;
      
       case BMP:
          of.lpstrFilter  = (LPSTR)".BMP File\0*.BMP\0.DIB File\0*.DIB\0\0";
          of.lpstrDefExt  = (LPSTR)"BMP";
          uResHdrSize     = sizeof(BITMAPFILEHEADER);
          break;
    }

    if (GetSaveFileName((LPOPENFILENAME)&of))
    {
        HFILE fFile;

        // Make an attempt to write the resource file and return success/failure
        fFile = _lcreat(of.lpstrFile, 0); // read and write permissions
        if (fFile == HFILE_ERROR)  // unable to create/open file
           return FALSE; 

        // Write the file header
        if (_lwrite(fFile, (const void _huge*) lpreshdr, uResHdrSize) != uResHdrSize)
        {
           _lclose(fFile);
           return (FALSE);
        }

        // Write the image plus data structures
        if (_hwrite(fFile, (const void _huge*) lpMem, lpMemSize) != lpMemSize)
        {
           _lclose(fFile);
           return (FALSE);
        }
        _lclose(fFile);
        return TRUE; 
    }
    else
    {
        dwError = CommDlgExtendedError();
        switch (dwError)
        {
            case CDERR_INITIALIZATION : 
            case CDERR_LOADSTRFAILURE : 
            case CDERR_LOADRESFAILURE :
            case CDERR_LOCKRESFAILURE :
            case CDERR_MEMALLOCFAILURE:
            case CDERR_MEMLOCKFAILURE :
               MessageBox(NULL, szErr1, szErr, MB_ICONSTOP | MB_OK);
               break;

            case FNERR_BUFFERTOOSMALL :
               MessageBox(NULL, szErr2, szErr, MB_ICONSTOP | MB_OK);
               break;

           default :
               MessageBox(NULL, szErr3, szErr, MB_ICONSTOP | MB_OK);
               break;
        }
        return FALSE;
    }
}

//*** EOF: res.c
