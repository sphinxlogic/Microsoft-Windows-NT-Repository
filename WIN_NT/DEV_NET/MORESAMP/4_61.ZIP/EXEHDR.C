//*************************************************************
//  File name: exehdr.c
//
//  Description: 
//      Routines for reading the exe headers and resources
//
//  History:    Date       Author     Comment
//               1/16/92   MSM        Created
//               9/14/92   Krishna    Modified to deal with only bmp/ico/cur
//
// Written by Microsoft Product Support Services, Windows Developer Support
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//*************************************************************

#include "global.h"

//*************************************************************
//
//  LoadExeInfo
//
//  Purpose:
//      Loads in the header information from the EXE
//
//
//  Parameters:
//      LPSTR    lpFile
//
//  Return: (PEXEINFO)
//
//
//  Comments:
//      This function will allocate a EXEINFO structure and
//      fill it out from the given filename.  This routine,
//      if successful will return a pointer to this structure.
//      If it fails, it returns a LERR_???? code.
//
//  History:    Date       Author     Comment
//               1/16/92   MSM        Created
//
//*************************************************************

PEXEINFO LoadExeInfo (LPSTR lpFile)
{
   OFSTRUCT of;
   int fFile = 0, nLen, nErr = 0;
   WORD wSize;
   PEXEINFO pExeInfo;

   #define ERROREXIT(X)    {nErr=X; goto error_out;}

   // Allocate place main EXEINFO structure    

   pExeInfo = (PEXEINFO)LocalAlloc(LPTR, sizeof(EXEINFO));
   if (!pExeInfo)
      return (PEXEINFO)LERR_MEMALLOC;

   // Open file and check for errors
   fFile = OpenFile(lpFile, &of, OF_READ);

   if (!fFile)
   ERROREXIT(LERR_OPENINGFILE);

   // Allocate space for the filename
   pExeInfo->pFilename = (PSTR)LocalAlloc(LPTR, lstrlen(lpFile) + 1);
   if (!pExeInfo->pFilename)
      return (PEXEINFO)LERR_MEMALLOC;

   lstrcpy(pExeInfo->pFilename, lpFile);

   // Read the OLD exe header
   nLen = (int)_lread(fFile, (LPSTR)&(pExeInfo->OldHdr), sizeof(OLDEXE));

   if (nLen < sizeof(OLDEXE))
   ERROREXIT(LERR_READINGFILE);

   if (pExeInfo->OldHdr.wFileSignature != OLDSIG)
   ERROREXIT(LERR_NOTEXEFILE);

   if (pExeInfo->OldHdr.wFirstRelocationItem < 0x40)  // Old EXE
   {
      pExeInfo->NewHdr.wNewSignature = 0;
      _lclose(fFile);
      return pExeInfo;
   }

   _llseek(fFile, pExeInfo->OldHdr.lNewExeOffset, 0);

   // Read the NEW exe header
   nLen = (int)_lread(fFile, (LPSTR)&(pExeInfo->NewHdr), sizeof(NEWEXE));

   if (nLen < sizeof(NEWEXE))
   ERROREXIT(LERR_READINGFILE);

   if (pExeInfo->NewHdr.wNewSignature != NEWSIG)
   ERROREXIT(LERR_NOTEXEFILE);

   // Read entry table
   wSize = pExeInfo->NewHdr.wEntrySize;

   pExeInfo->pEntryTable = (PSTR)LocalAlloc(LPTR, wSize);

   if (!pExeInfo->pEntryTable)
   ERROREXIT(LERR_MEMALLOC);

   _llseek(fFile, pExeInfo->OldHdr.lNewExeOffset +
           pExeInfo->NewHdr.wEntryOffset, 0);

   nLen = _lread(fFile, (LPSTR)pExeInfo->pEntryTable, wSize);

   if (nLen != (int)wSize)
   ERROREXIT(LERR_READINGFILE);
   // Do not read resources for OS/2 apps!!!!!!!
   if (pExeInfo->NewHdr.bExeType == 0x02)
   {
      if ((nErr = ReadResourceTable(fFile, pExeInfo)) < 0)
      ERROREXIT(nErr);
   }
   nErr = 1;

   error_out:
   // Close file and get outta here
   if (fFile)
      _lclose(fFile);

   if (nErr <= 0)
   {
      FreeExeInfoMemory(pExeInfo);
      return (PEXEINFO)nErr;
   }
   return pExeInfo;
}   //*** LoadExeInfo

//*************************************************************
//
//  FreeExeInfoMemory
//
//  Purpose:
//      Frees the memory associated created to store the info
//
//
//  Parameters:
//      PEXEINFO pExeInfo
//      
//
//  Return: (VOID)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//               1/17/92   MSM        Created
//
//*************************************************************

VOID FreeExeInfoMemory (PEXEINFO pExeInfo)
{
   PNAME pName = pExeInfo->pResidentNames;
   PRESTYPE prt = pExeInfo->pResTable;

   // Free Filename

   if (pExeInfo->pFilename)
      LocalFree((HANDLE)pExeInfo->pFilename);

   // Free Entry Table
   if (pExeInfo->pEntryTable)
      LocalFree((HANDLE)pExeInfo->pEntryTable);

   // Free Segment Table
   if (pExeInfo->pSegTable)
      LocalFree((HANDLE)pExeInfo->pSegTable);

   while (prt)     // Loop through the resource table
   {
      PRESTYPE prt_temp = prt->pNext;
      PRESINFO pri = prt->pResInfoArray;
      WORD wI = 0;

      // free if Resource array was allocated

      if (pri)
      {
         // Loop through and free any Resource Names
         while (wI < prt->wCount)
         {
            if (pri->pResourceName)
               LocalFree((HANDLE)pri->pResourceName);
            wI++;
            pri++;
         }
         LocalFree((HANDLE)prt->pResInfoArray);
      }

      // Free ResourceType name if there is one
      if (prt->pResourceType)
         LocalFree((HANDLE)prt->pResourceType);

      // Free resource type header
      LocalFree((HANDLE)prt);
      prt = prt_temp;
   }

   // Free Resident Name Table
   while (pName)
   {
      PNAME pN2 = pName->pNext;

      LocalFree((HANDLE)pName);
      pName = pN2;
   }

   // Free Import Name Table
   pName = pExeInfo->pImportedNames;
   while (pName)
   {
      PNAME pN2 = pName->pNext;

      LocalFree((HANDLE)pName);
      pName = pN2;
   }

   // Free Non-Resident Name Table
   pName = pExeInfo->pNonResidentNames;
   while (pName)
   {
      PNAME pN2 = pName->pNext;

      LocalFree((HANDLE)pName);
      pName = pN2;
   }

   // Free PEXEINFO struct
   LocalFree((HANDLE)pExeInfo);
}   //*** FreeExeInfoMemory

//*************************************************************
//
//  ReadResourceTable
//
//  Purpose:
//      LocalAllocs memory and reads in the resource headers
//
//
//  Parameters:
//      int fFile
//      PEXEINFO pExeInfo
//      
//
//  Return: (int)
//      0 or error condition
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//               1/17/92   MSM        Created
//
//*************************************************************

int ReadResourceTable (int fFile, PEXEINFO pExeInfo)
{
   int nLen;
   RESTYPE rt;
   PRESTYPE prt, prt_last = NULL;
   PRESINFO pri;
   long lResTable;
   WORD wResSize, wI;

   rt.pResourceType = NULL;
   rt.pResInfoArray = NULL;
   rt.pNext = NULL;

   if (pExeInfo->NewHdr.wResourceOffset == pExeInfo->NewHdr.wResOffset)
      return 0;    // No resources

   lResTable = pExeInfo->OldHdr.lNewExeOffset + pExeInfo->NewHdr.wResourceOffset;

   _llseek(fFile, lResTable, 0);

   // Read shift count
   if (_lread(fFile, (LPSTR)&(pExeInfo->wShiftCount), 2) != 2)
      return LERR_READINGFILE;

   // Read all the resource types    
   while (TRUE)
   {
      nLen = _lread(fFile, (LPSTR)&rt, sizeof(RTYPE));
      if (nLen != sizeof(RTYPE))
         return LERR_READINGFILE;
      if (rt.wType == 0)
         break;

      prt = (PRESTYPE)LocalAlloc(LPTR, sizeof(RESTYPE));
      if (!prt)
         return LERR_MEMALLOC;

      *prt = rt;

      if (prt_last == NULL)  // Is this the first entry??
         pExeInfo->pResTable = prt;
      else    // Nope
         prt_last->pNext = prt;

      prt_last = prt;

      // Allocate buffer for 'Count' resources of this type
      wResSize = prt->wCount * sizeof(RINFO);
      pri = (PRESINFO)LocalAlloc(LPTR, wResSize);
      if (!pri)
         return LERR_MEMALLOC;
      prt->pResInfoArray = pri;

      // Now read 'Count' resources of this type
      nLen = _lread(fFile, (LPSTR)pri, wResSize);
      if (nLen != (int)wResSize)
         return LERR_READINGFILE;
   }

   // Now that the resources are read, read the names
   prt = pExeInfo->pResTable;

   while (prt)
   {
      if (prt->wType & 0x8000)    // Pre-defined type
         prt->pResourceType = NULL;
      else    // Name is in the file
      {
         // wType is offset from beginning of Resource Table
         _llseek(fFile, lResTable + prt->wType, 0);

         wResSize = 0;
         // Read string size
         if (_lread(fFile, (LPSTR)&wResSize, 1) != 1)
            return LERR_READINGFILE;

         // +1 for the null terminator
         prt->pResourceType = (PSTR)LocalAlloc(LPTR, wResSize + 1);
         if (!prt->pResourceType)
            return LERR_MEMALLOC;

         // Read string
         if (_lread(fFile, (LPSTR)prt->pResourceType, wResSize) != wResSize)
            return LERR_READINGFILE;
         prt->pResourceType[wResSize] = 0;  // Null terminate string;
      }

      // Now do Resource Names for this type
      pri = prt->pResInfoArray;

      wI = 0;
      while (wI < prt->wCount)
      {
         if (pri->wID & 0x8000)   // Integer resource
            pri->pResourceName = NULL;
         else // Named resource
         {
            // wID is offset from beginning of Resource Table
            _llseek(fFile, lResTable + pri->wID, 0);

            wResSize = 0;
            // Read string size
            if (_lread(fFile, (LPSTR)&wResSize, 1) != 1)
               return LERR_READINGFILE;

            // +1 for the null terminator
            pri->pResourceName = (PSTR)LocalAlloc(LPTR, wResSize + 1);
            if (!pri->pResourceName)
               return LERR_MEMALLOC;

            // Read string
            if (_lread(fFile, (LPSTR)pri->pResourceName, wResSize) != wResSize)
               return LERR_READINGFILE;
            pri->pResourceName[wResSize] = 0;    // Null terminate string;
         }
         pri++;
         wI++;
      }
      prt = prt->pNext;
   }
   return 0;
}   //*** ReadResourceTable
