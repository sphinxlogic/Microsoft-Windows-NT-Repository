//*************************************************************
//  File name: filllb.c
//
//  Description: 
//      Contains all the code for filling the listbox with data
//
//  History:    Date       Author     Comment
//               1/20/92   MSM        Created
//               9/14/92   Krishna    Modified to display only bmp/ico/cur
//
// Written by Microsoft Product Support Services, Windows Developer Support
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//*************************************************************

#include "global.h"

//*************************************************************
//
//  FillLBWithResources
//
//  Purpose:
//      Fills the listbox with the Resource Table info
//
//
//  Parameters:
//      HWND hWnd
//      PEXEINFO pExeInfo
//      
//
//  Return: (BOOL)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//               1/20/92   MSM        Created
//               9/14/92   Krishna    Modified to display only bmp/ico/cur
//
//*************************************************************

BOOL FillLBWithResources (HWND hWnd, PEXEINFO pExeInfo)
{
   char szBuff[255];
   LPSTR lp = (LPSTR)szBuff;
   LPSTR lpn;
   PRESTYPE prt = pExeInfo->pResTable;

   #define ADDITEM() SendMessage( hWnd, LB_ADDSTRING, 0, (LONG)lp )

   SendMessage(hWnd, WM_SETREDRAW, 0, 0L);
   SendMessage(hWnd, LB_RESETCONTENT, 0, 0L);

   lstrcpy(lp, "[TYPE]\t\tOffset       Length       Flags                  Name");
   ADDITEM();

   lstrcpy(lp, "----------------------------------------------------------------------------");
   ADDITEM();

   while (prt)
   {
      PRESINFO pri = prt->pResInfoArray;
      WORD wI = 0;
      BOOL bAddToList = TRUE;     // indicates if item should be in list

      // & 0x7FFF eliminates the high bit, giving us the res. type 
      // We are interested in only bitmaps, icons. and cursors

      if (prt->wType & 0x8000)
      {
         switch (prt->wType & 0x7FFF)
         {
            case RT_BITMAP:
               lpn = (LPSTR)"BITMAP";
               break;

            case RT_ICON:
               lpn = (LPSTR)"ICON";
               break;

            case RT_CURSOR:
               lpn = (LPSTR)"CURSOR";
               break;

            default:
               bAddToList = FALSE;
               break;
         }
         if (bAddToList)     // add the resource to display list
         {
            wsprintf(lp, "[%s]", lpn);
            ADDITEM();

            while (wI < prt->wCount)
            {
               int nIndex;

               FormatResourceEntry(pExeInfo, pri, lp);
               if ((nIndex = (int)ADDITEM()) >= 0)
                  SendMessage(hWnd, LB_SETITEMDATA, nIndex,
                              MAKELONG((WORD)pri,(WORD)prt));
               // Set the item data for use when double clicking

               pri++;
               wI++;
            }
            lstrcpy(lp, "");
            ADDITEM();
         }
      }
      prt = prt->pNext;
   }

   SendMessage(hWnd, WM_SETREDRAW, 1, 0L);
   InvalidateRect(hWnd, NULL, TRUE);
   UpdateWindow(hWnd);
   return TRUE;
}   //*** FillLBWithResources


//*************************************************************
//
//  FormatResourceEntry
//
//  Purpose:
//      Formats the resource info and puts it in the 'lp' buffer
//
//
//  Parameters:
//      PEXEINFO  pExeInfo
//      PRESINFO  pri
//      LPSTR     lp
//      
//
//  Return: (VOID)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//               1/18/92   MSM        Created
//
//*************************************************************

LPSTR FormatResourceEntry (PEXEINFO pExeInfo, PRESINFO pri, LPSTR lp)
{
   WORD wShift = pExeInfo->wShiftCount;

   wsprintf(lp, "-->\t\t%#08lX   %#08lX   ", ((LONG)pri->wOffset) << wShift,
            ((LONG)pri->wLength) << wShift);

   if (pri->wFlags & F_MOVEABLE)
      lstrcat(lp, "MOVEABLE ");
   else
      lstrcat(lp, "         ");

   if (pri->wFlags & F_SHAREABLE)
      lstrcat(lp, "PURE ");
   else
      lstrcat(lp, "     ");

   if (pri->wFlags & F_PRELOAD)
      lstrcat(lp, "PRELOAD  ");
   else
      lstrcat(lp, "         ");

   if (pri->wID & 0x8000)    // Integer resource
   {
      char temp[10];

      wsprintf((LPSTR)temp, "%#04X", pri->wID);
      lstrcat(lp, temp);
   }
   else
      lstrcat(lp, pri->pResourceName);

   return lp;
}   //*** FormatResourceEntry

//*** EOF: filllb.c
