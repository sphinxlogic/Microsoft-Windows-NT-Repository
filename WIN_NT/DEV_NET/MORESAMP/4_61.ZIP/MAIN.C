//*************************************************************
//  File name: main.c
//
//  Description: 
//      WinMain and the WndProcs
//
//  History:    Date       Author     Comment
//              12/12/91   MSM        Created
//               9/14/92   Krishna    Modified to be able to save rsrcs.
//
// Written by Microsoft Product Support Services, Windows Developer Support
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//*************************************************************

#include "global.h"

HANDLE ghInst = NULL;
HWND ghWndMain = NULL;

char szMainMenu[] = "MainMenu";
char szMainClass[] = "MainClass";
PEXEINFO gpExeInfo;

//*************************************************************
//
//  WinMain()
//
//  Purpose:
//		Entry point for all windows apps
//
//
//  Parameters:
//      HANDLE hInstance
//      HANDLE hPrevInstance
//      LPSTR lpCmdLine
//      int nCmdShow
//      
//
//  Return: (int PASCAL)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//              12/12/91   MSM        Created
//
//*************************************************************

int PASCAL WinMain (HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
   MSG msg;

   if (!hPrevInstance && !InitApplication(hInstance))
      return (FALSE);

   if (!InitInstance(hInstance, nCmdShow))
      return (FALSE);

   while (GetMessage(&msg, NULL, NULL, NULL))
   {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   }
   return (msg.wParam);
}   //*** WinMain()

//*************************************************************
//
//  MainWndProc()
//
//  Purpose:
//		Main Window procedure
//
//
//  Parameters:
//      HWND hWnd
//      unsigned msg
//      WORD wParam
//      LONG lParam
//      
//
//  Return: (long FAR PASCAL)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//              12/12/91   MSM        Created
//               9/14/92   Krishna    Modified to be able to save rsrcs.
//
//*************************************************************

long FAR PASCAL MainWndProc (HWND hWnd, unsigned msg, WORD wParam, LONG lParam)
{
   FARPROC lpProc;
   RECT rc;
   HWND hLB = GetDlgItem(hWnd, IDL_LISTBOX);

   switch (msg)
   {
      case WM_COMMAND:
         switch (wParam)
         {
            case IDM_OPEN:
            {
               OPENFILENAME of;
               char szFile[120];

               memset(&of, 0, sizeof(OPENFILENAME));

               szFile[0] = 0;

               of.lStructSize = sizeof(OPENFILENAME);
               of.hwndOwner = ghWndMain;
               of.hInstance = ghInst;
               of.lpstrFilter = (LPSTR)"EXE file\0*.EXE\0DLL library\0*.DLL\0Font\0*.FON\0\0";
               of.nFilterIndex = 0;
               of.lpstrFile = (LPSTR)szFile;
               of.nMaxFile = (DWORD)256;
               of.lpstrTitle = (LPSTR)"Enter File";
               of.Flags = OFN_HIDEREADONLY | OFN_FILEMUSTEXIST;
               of.lpstrDefExt = (LPSTR)"EXE";

               if (GetOpenFileName(&of))
               {
                  // Kill the old exe info if it exists
                  if (gpExeInfo)
                  {
                     FreeExeInfoMemory(gpExeInfo);
                     gpExeInfo = NULL;
                  }

                  gpExeInfo = LoadExeInfo(szFile);

                  switch ((int)gpExeInfo)
                  {
                     case LERR_OPENINGFILE:
                        MessageBox(hWnd, "Error opening file!",
                                   "ResExt Error", MB_ICONSTOP | MB_OK);
                        SetWindowText(hWnd, "Windows Executable Viewer");
                        gpExeInfo = NULL;
                        break;

                     case LERR_NOTEXEFILE:
                        MessageBox(hWnd, "Not a valid EXE file!",
                                   "ResExt Error", MB_ICONSTOP | MB_OK);
                        SetWindowText(hWnd, "Windows Executable Viewer");
                        gpExeInfo = NULL;
                        break;

                     case LERR_READINGFILE:
                        MessageBox(hWnd, "Error reading file!",
                                   "ResExt Error", MB_ICONSTOP | MB_OK);
                        SetWindowText(hWnd, "Windows Executable Viewer");
                        gpExeInfo = NULL;
                        break;

                     case LERR_MEMALLOC:
                        MessageBox(hWnd, "Memory allocation denied!",
                                   "ResExt Error", MB_ICONSTOP | MB_OK);
                        SetWindowText(hWnd, "Windows Executable Viewer");
                        gpExeInfo = NULL;
                        break;

                     default:
                     {
                        char szBuff[120];

                        FillLBWithResources(hLB, gpExeInfo);
                        wsprintf(szBuff, "ResExt - %s", (LPSTR)szFile);
                        SetWindowText(hWnd, szBuff);
                        SetFocus(hLB);
                     }
                        break;
                  }
                  if (!gpExeInfo)
                     SendMessage(hLB, LB_RESETCONTENT, 0, 0L);
               }
            }
               break;

            case IDM_ABOUT:
               lpProc = MakeProcInstance(About, ghInst);
               DialogBox(ghInst, "AboutBox", hWnd, lpProc);
               FreeProcInstance(lpProc);
               break;

            case IDM_EXIT:
               PostMessage(hWnd, WM_SYSCOMMAND, SC_CLOSE, 0L);
               break;

            case IDL_LISTBOX:
            {
               int nItem = (int)SendMessage(hLB, LB_GETCURSEL, 0, 0L);
               LONG lData;

               if (HIWORD(lParam) != LBN_DBLCLK)
                  break;


               if (nItem < 0)
                  break;

               lData = SendMessage(hLB, LB_GETITEMDATA, nItem, 0L);

               if (lData == NULL)
                  break;

               return (LONG)DisplayResource(gpExeInfo,
                                            (PRESTYPE)HIWORD(lData), (PRESINFO)LOWORD(lData));
            }
               break;
         }
         break;

      case WM_SIZE:
         GetClientRect(hWnd, (LPRECT)&rc);
         // Resize listbox
         MoveWindow(hLB, 0, 0, rc.right, rc.bottom, TRUE); //FALSE);
         break;

      case WM_DESTROY:
         if (gpExeInfo)
         {
            FreeExeInfoMemory(gpExeInfo);
            gpExeInfo = NULL;
         }
         PostQuitMessage(0);
         break;
   }
   return (DefWindowProc(hWnd, msg, wParam, lParam));
}   //*** MainWndProc()

//*************************************************************
//
//  About()
//
//  Purpose:
//		the About dialog box procedure
//
//
//  Parameters:
//      HWND hDlg
//      unsigned msg
//      WORD wParam
//      LONG lParam
//      
//
//  Return: (BOOL FAR PASCAL)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//              12/12/91   MSM        Created
//
//*************************************************************

BOOL FAR PASCAL About (HWND hDlg, unsigned msg, WORD wParam, LONG lParam)
{
   switch (msg)
   {
      case WM_INITDIALOG:
         return (TRUE);

      case WM_COMMAND:
         if (wParam == IDOK || wParam == IDCANCEL)
         {
            EndDialog(hDlg, TRUE);
            return (TRUE);
         }
         break;
   }
   return (FALSE); /* Didn't process a message    */
}   //*** About()
