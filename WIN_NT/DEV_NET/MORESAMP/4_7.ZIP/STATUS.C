//****************************************************************************
// File: status.c
//
// Purpose: Status bar functions
//
// Functions:
//    SetStatusBar() - Sets the contents of the status bar.
//    DrawBoxIndent() - Draws 3-D style box
//    StatusLineWndProc() - Processes status bar windows messages
//
// Development Team:
//        Greg Keyser
//    Sara Williams
//
// Written by Microsoft Product Support Services, Windows Developer Support
// Copyright (c) 1992 Microsoft Corporation. All rights reserved.
//****************************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "global.h"


HDC ghFastStatusDC;
char szBuffer[256];

HPEN hGrayStatusPen;

//***********************************************************************
// Function: SetStatusBar()
//
// Purpose: Sets the text for the specified status bar frame.
//
// Parameters:
//    WORD wID - specifies the frame to set the text for
//
// Returns: VOID
//
// Comments:
//
// History:  Date       Author        Reason
//           1/27/92    saraw         Created
//****************************************************************************
void SetStatusBar (WORD wID)
{
   switch (wID)
   {
      case IDD_ADVISESTATUS: // set ADVISE frame text
      {
         if (bHotAdviseLoop)
            lstrcpy(szBuffer, "Advise Loop: Hot");
         else if (bWarmAdviseLoop)
            lstrcpy(szBuffer, "Advise Loop: Warm");
         else
            lstrcpy(szBuffer, "Advise Loop: None");

         break;
      }

      case IDD_CONNECTSTATUS:     // set CONVERSATION frame text
      {
         if (!ghConv & !ghSysConv)
         {
            lstrcpy(szBuffer, "Conversations: None");
            break;
         }
         if (ghConv)
            if (ghSysConv)
               lstrcpy(szBuffer, "Conversations: General & System");
            else
               lstrcpy(szBuffer, "Conversations: General");
         else
            lstrcpy(szBuffer, "Conversations: System");

         break;
      }  // end case
   }     // end switch

   SendMessage(ghWndStatus, WM_MYCOMMAND, wID, 0L);
}

//***********************************************************************
// Function: DrawBoxIndent()
//
// Purpose: Draws 3-D box in status bar window.
//
// Parameters:
//        HDC hDC - device context for status bar window.
//    HWND hWnd - handle to status bar window.
//    WORD xPos - x position to start 3-D box.
//    WORD xChars - length of box (in characters).
//
// Returns: VOID.
//
// Comments:
//
// History:  Date       Author        Reason
//           2/1/92     gregk         Created
//***************************************************************************
void DrawBoxIndent (HDC hDC, HWND hWnd, WORD xPos, WORD xChars)
{
   HPEN hOldPen;
   WORD wTextHeight, wTextWidth;
   RECT rc;

   if (!bMonochrome)
   {
      if (bEGAMode)
         hOldPen = SelectObject(hDC, GetStockObject(BLACK_PEN));
      else
         hOldPen = SelectObject(hDC, hGrayStatusPen);
   }
   else
      hOldPen = SelectObject(hDC, GetStockObject(BLACK_PEN));

   // We use ghFastStatusDC here since we want to scale the box
   // to the size of the font selected into ghFastStatusDC, not
   // the screen DC.

   wTextWidth = LOWORD (GetTextExtent(ghFastStatusDC, "X", 1));
   wTextHeight = HIWORD (GetTextExtent(ghFastStatusDC, "X", 1));

   GetClientRect(hWnd, &rc);

   MoveTo(hDC, wTextWidth * (xPos + 1), rc.bottom - (wTextHeight / 3));
   LineTo(hDC, wTextWidth * (xPos + 1), wTextHeight / 3);
   LineTo(hDC, wTextWidth * (xPos + 1 + xChars), wTextHeight / 3);

   if (!bMonochrome)
      SelectObject(hDC, GetStockObject(WHITE_PEN));

   LineTo(hDC, wTextWidth * (xPos + 1 + xChars), rc.bottom - (wTextHeight / 3));
   LineTo(hDC, wTextWidth * (xPos + 1), rc.bottom - (wTextHeight / 3));

   SelectObject(hDC, hOldPen);
}



//***********************************************************************
// Function: StatusLineWndProc()
//
// Purpose: Message processing for status bar window.
//
// Parameters:
//    HWND hWnd    - handle to status bar window
//    unsigned msg - current message
//    WORD wParam  - additional information
//    LONG lParam  - additional information
//
// Returns: (long FAR PASCAL)
//        depends on current message
// 
// Comments:
//
// History:  Date       Author        Reason
//           2/1/92     gregk         Created
//***************************************************************************
long FAR PASCAL StatusLineWndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
   HDC hDC;
   PAINTSTRUCT ps;
   RECT r;
   HPEN hOldPen;
   WORD wTextHeight, wTextWidth;
   int wyPos;
   static HBRUSH hBkgndBrush;
   DWORD dwColor;
   static BOOL bBigRectDrawn;

   switch (message)
   {
      case WM_CREATE:
         hGrayStatusPen = CreatePen(PS_SOLID, 1, RGB(128,128,128));
         hBkgndBrush = (HBRUSH)GetClassWord(hWnd, GCW_HBRBACKGROUND);
         if (!bMonochrome)
         {
            if (bEGAMode)
               dwColor = RGB(128, 128, 128);
            else
               dwColor = RGB(192, 192, 192);
         }
         else
            dwColor = RGB(255, 255, 255);

         SetBkColor(ghFastStatusDC, dwColor);

         r.left = r.top = 0;
         r.right = GetSystemMetrics(SM_CXSCREEN);
         r.bottom = HIWORD(GetTextExtent(ghFastStatusDC, "X", 1));
         FillRect(ghFastStatusDC, &r, hBkgndBrush);

         break;

      case WM_MYCOMMAND:
         hDC = GetDC(hWnd);

         wTextWidth = LOWORD (GetTextExtent(ghFastStatusDC, "X", 1));
         wTextHeight = HIWORD (GetTextExtent(ghFastStatusDC, "X", 1));

         wyPos = (gwBarHeight / 2) - (wTextHeight / 2);

         GetWindowRect(hWnd, &r);
         ScreenToClient(hWnd, (LPPOINT)&r.left);
         ScreenToClient(hWnd, (LPPOINT)&r.right);
         r.top += 2;
         r.bottom -= 2;

         //Note that for the IDD_CONNECTSTATUS and IDD_ADVISESTATUS cases below, 
         //szBuffer has been formatted    *prior* to entering this routine.  szBuffer 
         //is a global.

         switch (wParam)
         {
            case IDD_CONNECTSTATUS:
               ExtTextOut(ghFastStatusDC, 0, 0, ETO_OPAQUE, &r, szBuffer, lstrlen(szBuffer), NULL);
               BitBlt(hDC, (gwConnectPos + 1) * wTextWidth + 2, wyPos, CONNECTCHARS * wTextWidth - 2, wTextHeight,
                      ghFastStatusDC, 0, 0, SRCCOPY);
            break;

            case IDD_ADVISESTATUS:
               ExtTextOut(ghFastStatusDC, 0, 0, ETO_OPAQUE, &r, szBuffer, lstrlen(szBuffer), NULL);
               BitBlt(hDC, (gwAdvisePos + 1) * wTextWidth + 2, wyPos, ADVISECHARS * wTextWidth - 2, wTextHeight,
                      ghFastStatusDC, 0, 0, SRCCOPY);
            break;

            default:    //When user is checking out menu items...

               //If the next check is true, user is clicking on a popup menu or top level menuitem
               if ((wParam < IDM_LOWESTMENUID) || (wParam > IDM_HIGHESTMENUID))
               {
                  ReleaseDC(hWnd, hDC);
                  return (NULL);
               }

               //Now load the menuitem description string in to szBuffer.

               if (LoadString(ghInst, wParam, szBuffer, 128))
               {
                  if (!bBigRectDrawn)
                  {
                     bBigRectDrawn = TRUE;
                     FillRect(hDC, &r, hBkgndBrush);
                  }
                  ExtTextOut(ghFastStatusDC, 0, 0, ETO_OPAQUE, &r, szBuffer, lstrlen(szBuffer), NULL);
                  BitBlt(hDC, 1 * wTextWidth + 2, wyPos, 160 * wTextWidth - 2, wTextHeight, ghFastStatusDC, 0, 0,
                         SRCCOPY);
               }

               DrawBoxIndent(hDC, hWnd, 0, 70);
               ReleaseDC(hWnd, hDC);
               UpdateWindow(hWnd);
               return (NULL);
         }

         bBigRectDrawn = FALSE;
         DrawBoxIndent(hDC, hWnd, gwConnectPos, CONNECTCHARS);
         DrawBoxIndent(hDC, hWnd, gwAdvisePos, ADVISECHARS);

         ReleaseDC(hWnd, hDC);
         UpdateWindow(hWnd);
      break;

      case WM_PAINT:

         //If we get a paint when bBigRectDrawn=TRUE, don't process it.
         if (bBigRectDrawn)
            return DefWindowProc(hWnd, message, wParam, lParam);

         GetClientRect(hWnd, &r);

         hDC = BeginPaint(hWnd, &ps);

         DrawBoxIndent(hDC, hWnd, gwConnectPos, CONNECTCHARS);
         DrawBoxIndent(hDC, hWnd, gwAdvisePos, ADVISECHARS);

         hOldPen = SelectObject(hDC, GetStockObject(BLACK_PEN));

         MoveTo(hDC, 0, 0);
         LineTo(hDC, r.right, 0);

         MoveTo(hDC, 0, r.bottom - 1);
         LineTo(hDC, r.right, r.bottom - 1);

         if (!bMonochrome)
         {
            MoveTo(hDC, 0, r.bottom - 2);

            SelectObject(hDC, GetStockObject(WHITE_PEN));
            LineTo(hDC, 0, 1);
            LineTo(hDC, r.right, 1);

            if ((bMonochrome) || (350 == GetSystemMetrics(SM_CYSCREEN)))
               SelectObject(hDC, GetStockObject(BLACK_PEN));
            else
               SelectObject(hDC, hGrayStatusPen);

            LineTo(hDC, r.right, r.bottom - 2);
            LineTo(hDC, 0, r.bottom - 2);
         }

         SelectObject(hDC, hOldPen);

         EndPaint(hWnd, &ps);

         //This is a routine that will format szBuffer and do a
         //SendMessage(ghWndStatus, WM_MYCOMMAND, wUpdateWindow, 0L);
         //to output the text.

         SetStatusBar(IDD_ADVISESTATUS);
         SetStatusBar(IDD_CONNECTSTATUS);

      break;

      case WM_CLOSE:
         DestroyWindow(hWnd);
      break;

      case WM_DESTROY:
         if (hGrayStatusPen)
            DeleteObject(hGrayStatusPen);
      break;

      default:
         return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0L;
}
