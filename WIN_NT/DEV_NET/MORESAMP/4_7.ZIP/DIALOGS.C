//*************************************************************************
// File: dialogs.c
//
// Purpose: Contains dialog box procedures for the about box and the 
//    instructions dialog box.
//
// Functions:
//    About() - Handles about box processing
//    WhatDoIDo() - Handles information dialog box processing
//
// Development Team:
//    Sara Williams
//
// Written by Microsoft Product Support Services, Windows Developer Support
// Copyright (c) 1992 Microsoft Corporation. All rights reserved.
//*************************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "global.h"

//*************************************************************
//
//  Function: About()
//
//  Purpose:
//      Handles about box message processing
//
//
//  Parameters:
//      HWND hDlg       // Handle to the about box
//      unsigned msg    // current message
//      WORD wParam     // additional information
//      LONG lParam     // additional information
//      
//
//  Return: (BOOL FAR PASCAL)
//      Returns TRUE if the message is processed (ie., the dialog manageer
//      should not process it, and FALSE if the message is not processed
//      (ie., the dialog manager should process it).
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//              1/6/92     saraw      Created
//*************************************************************

BOOL FAR PASCAL About (HWND hDlg, unsigned msg, WORD wParam, LONG lParam)
{
   // All the standard stuff...
   switch (msg)
   {
      case WM_INITDIALOG:
         return (TRUE); // tells dialog manager to set the focus

      case WM_COMMAND:
         if (wParam == IDOK || wParam == IDCANCEL)
         {
            EndDialog(hDlg, TRUE);
            return (TRUE);
         }
      break;
   }
   return (FALSE); /* Didn't process a message    */
}   //*** About()


//*************************************************************
//
//  Function: WhatDoIDo()
//
//  Purpose:
//        Handles "whatdoIdo" dialog box message processing
//
//
//  Parameters:
//      HWND hDlg       // Handle to the about box
//      unsigned msg    // current message
//      WORD wParam     // additional information
//      LONG lParam     // additional information
//      
//
//  Return: (BOOL FAR PASCAL)
//      Returns TRUE if the message is processed (ie., the dialog manageer
//      should not process it, and FALSE if the message is not processed
//      (ie., the dialog manager should process it).
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//              2/19/92    saraw      Created
//
//*************************************************************

BOOL FAR PASCAL WhatDoIDo (HWND hDlg, unsigned msg, WORD wParam, LONG lParam)
{
   switch (msg)
   {
      case WM_INITDIALOG:
         return TRUE;   // tells dialog manager to set the focus

      case WM_COMMAND:
         if (wParam == IDOK || wParam == IDCANCEL)
         {
            EndDialog(hDlg, TRUE);
            return (TRUE);
         }
      break;
   }
   return (FALSE); /* Didn't process a message    */
}   //*** WhatDoIDo()
