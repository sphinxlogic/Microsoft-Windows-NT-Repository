//*************************************************************
// File name: init.c
//
// Purpose:
//      Initializes the app and instance
//
// Functions:
//      InitializeStatusBarStuff() - initializes status bar window
//      InitializeCoolBitmaps()    - initialize bitmaps used in 
//                                    asynch transactions
//      InitApplication()          - registers classes
//      InitInstance()             - creates windows
//      
// Development Team:
//        Sara Williams
//
// Written by Microsoft Product Support Services, Windows Developer Support
// Copyright (c) 1992 Microsoft Corporation. All rights reserved.
//*************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "global.h"

HBITMAP ghCoolBitmaps[NUMBITMAPS];     // array of bitmaps to display
WORD gwOrigBitmapWidth;                // used for sizing the client window
WORD gwOrigBitmapHeight;
WORD gwConnectPos;
WORD gwAdvisePos;
BOOL bMonochrome;                      // monitor types
BOOL bEGAMode;
WORD gwBarHeight;                      // height of status bar
char szNullString[] = "";              // strings
char szStatusLine[] = "StatBar";

//*************************************************************
//
//  Function: InitializeStatusBarStuff()
//
//  Purpose:
//        Initializes status bar stuff
//
//
//  Parameters:
//        None.
//
//  Return: BOOL
//        Returns TRUE if successful, FALSE otherwise.
//
//  Comments:
//
//  History:    Date       Author     Comment
//              2/6/92     saraw      Created from gregk's original code
//
//*************************************************************
BOOL InitializeStatusBarStuff (BOOL bScaled)
{
   HDC hDC;

   //Are we in monochrome land????  bMonochrome is a global.

   hDC = GetDC(NULL);
   bMonochrome = (2 == GetDeviceCaps(hDC, NUMCOLORS));     // Monochrome!
   ReleaseDC(NULL, hDC);

   if (!bMonochrome)    //Are we in EGA land???
   {
      hDC = GetDC(NULL);

      if (350 == GetDeviceCaps(hDC, VERTRES))
         bEGAMode = (TRUE);
      else
         bEGAMode = (FALSE);

      ReleaseDC(NULL, hDC);
   }

   // Initialize bitmap and DC

   hDC = GetDC(NULL);
   ghFastStatusDC = CreateCompatibleDC(hDC);
   ghFastBitmapStatus = CreateCompatibleBitmap(hDC,
                                               GetSystemMetrics(SM_CXSCREEN),
                                               HIWORD(GetTextExtent(hDC, "X", 1))
                                               );

   SelectObject(ghFastStatusDC, ghFastBitmapStatus);

   if (bScaled)  // use a smaller font if the window has been scaled.
   {
       ghSmallFont = CreateFont (-10, 0, 0, 0, 400, FALSE, FALSE, FALSE, 
                                 ANSI_CHARSET, OUT_CHARACTER_PRECIS,
                                 CLIP_DEFAULT_PRECIS, PROOF_QUALITY,
                                 VARIABLE_PITCH | FF_SWISS, (LPSTR)"Helv");

       SelectObject(ghFastStatusDC, ghSmallFont);  // select new font 

       // scale the two little frames in the status bar 
       // Really, we only have to scale the Advise frame because the
       // Connect frame starts at 0 regardless, and its width is
       // computed with the smaller font.

       gwConnectPos = CONNECTPOS;
       gwAdvisePos = ADVISEPOS - 4;
   }

       gwConnectPos = CONNECTPOS;
       gwAdvisePos = ADVISEPOS;

   SetBkMode(ghFastStatusDC, OPAQUE);

   ReleaseDC(NULL, hDC);

   return TRUE;
}

//*************************************************************
//
//  Function: InitializeCoolBitmaps()
//
//  Purpose:
//        Initializes array of bitmaps
//
//
//  Parameters:
//        None.
//
//  Return: BOOL
//        Returns TRUE if successful, FALSE otherwise.
//
//  Comments:
//    ghCoolBitmaps[1] is already set with the original bitmap.
//    The remaining bitmaps are just different sizes of the original
//    bitmap.  Keeping them in an array lets us use BitBlt() instead of
//    StretchBlt() when we want to display them (after the asynchronous
//    transaction). The following table shows the number of bitmaps 
//    displayed, the index into the ghCoolBitmaps array, and the 
//    shrink/expand factor from the original bitmap. Index is sqrt(# of 
//    bitmaps) - 1.
//
//    # of Bitmaps        Index        Shrink/Expand factor
//       1                  0          expand by factor of 2
//       4                  1          1 (original bitmap)
//       9                  2          shrink by 2/3
//       16                 3          shrink by 1/2
//       25                 4          shrink by 2/5
//
//  History:    Date       Author     Comment
//              1/18/92    saraw      Created
//
//*************************************************************
BOOL InitializeCoolBitmaps ()
{
   HDC hMemDC, hMem2DC, hDC;
   HBITMAP hOrigBitmap, hOrig2Bitmap;

   hDC = GetDC(ghWndMain);

   hMemDC = CreateCompatibleDC(hDC);
   hMem2DC = CreateCompatibleDC(hDC);

   hOrigBitmap = SelectObject(hMemDC, ghCoolBitmaps[1]);

   // Create bitmaps for each correct size 
   ghCoolBitmaps[0] = CreateCompatibleBitmap(hDC, 2 * gwOrigBitmapWidth,
                                             2 * gwOrigBitmapHeight);

   ghCoolBitmaps[2] = CreateCompatibleBitmap(hDC,
                                             MulDiv(2, gwOrigBitmapWidth, 3),
                                             MulDiv(2, gwOrigBitmapHeight, 3));

   ghCoolBitmaps[3] = CreateCompatibleBitmap(hDC, gwOrigBitmapWidth / 2,
                                             gwOrigBitmapHeight / 2);

   ghCoolBitmaps[4] = CreateCompatibleBitmap(hDC,
                                             MulDiv(2, gwOrigBitmapWidth, 5),
                                             MulDiv(2, gwOrigBitmapHeight, 5));

   // preserve color when StretchBlting
   SetStretchBltMode(hMem2DC, STRETCH_DELETESCANS);

   hOrig2Bitmap = SelectObject(hMem2DC, ghCoolBitmaps[0]);

   // set background
   PatBlt(hMem2DC, 0, 0, 2 * gwOrigBitmapWidth, 2 * gwOrigBitmapHeight, WHITENESS);

   // copy original bitmap into new bitmap
   StretchBlt(hMem2DC, 0, 0, 2 * gwOrigBitmapWidth, 2 * gwOrigBitmapHeight,
              hMemDC, 0, 0, gwOrigBitmapWidth, gwOrigBitmapHeight, SRCCOPY);

   SelectObject(hMem2DC, ghCoolBitmaps[2]);

   // set background
   PatBlt(hMem2DC, 0, 0, MulDiv(2, gwOrigBitmapWidth, 3),
          MulDiv(2, gwOrigBitmapHeight, 3), WHITENESS);

   // copy original bitmap into new bitmap
   StretchBlt(hMem2DC, 0, 0, MulDiv(2, gwOrigBitmapWidth, 3),
              MulDiv(2, gwOrigBitmapHeight, 3),
              hMemDC, 0, 0, gwOrigBitmapWidth, gwOrigBitmapHeight, SRCCOPY);

   SelectObject(hMem2DC, ghCoolBitmaps[3]);

   // set background
   PatBlt(hMem2DC, 0, 0, gwOrigBitmapWidth / 2, gwOrigBitmapHeight / 2, WHITENESS);

   // copy original bitmap into new bitmap
   StretchBlt(hMem2DC, 0, 0, gwOrigBitmapWidth / 2, gwOrigBitmapHeight / 2,
              hMemDC, 0, 0, gwOrigBitmapWidth, gwOrigBitmapHeight, SRCCOPY);

   SelectObject(hMem2DC, ghCoolBitmaps[4]);

   // set background
   PatBlt(hMem2DC, 0, 0, MulDiv(2, gwOrigBitmapWidth, 5),
          MulDiv(2, gwOrigBitmapHeight, 5), WHITENESS);

   // copy original bitmap into new bitmap
   StretchBlt(hMem2DC, 0, 0, MulDiv(2, gwOrigBitmapWidth, 5),
              MulDiv(2, gwOrigBitmapHeight, 5),
              hMemDC, 0, 0, gwOrigBitmapWidth, gwOrigBitmapHeight, SRCCOPY);

   // clean up
   SelectObject(hMem2DC, hOrig2Bitmap);
   SelectObject(hMemDC, hOrigBitmap);

   DeleteObject(hMemDC);
   DeleteObject(hMem2DC);

   ReleaseDC(ghWndMain, hDC);

   return TRUE;
}

//*************************************************************
//
//  Function: InitApplication()
//
//  Purpose:
//        Initializes the application (window classes)
//
//
//  Parameters:
//      HANDLE hInstance - hInstance from WinMain
//      
//
//  Return: (BOOL)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//              1/6/92     saraw      Created
//
//*************************************************************

BOOL InitApplication (HANDLE hInstance)
{
   WNDCLASS wc;

   wc.style = NULL;
   wc.lpfnWndProc = MainWndProc;

   wc.cbClsExtra = 0;
   wc.cbWndExtra = 0;
   wc.hInstance = hInstance;
   wc.hIcon = LoadIcon(hInstance, "MAINICON");
   wc.hCursor = LoadCursor(NULL, IDC_ARROW);
   wc.hbrBackground = COLOR_APPWORKSPACE + 1;
   wc.lpszMenuName = szMainMenu;
   wc.lpszClassName = szMainClass;

   if (!RegisterClass(&wc))
      return FALSE;

   wc.style = NULL;
   wc.lpfnWndProc = StatusLineWndProc;
   wc.cbClsExtra = 0;
   wc.cbWndExtra = 0;
   wc.hInstance = hInstance;
   wc.hIcon = NULL;
   wc.hCursor = LoadCursor(NULL, IDC_ARROW);
   wc.lpszMenuName = (LPSTR)NULL;
   wc.lpszClassName = (LPSTR)szStatusLine;

   if (!bMonochrome)    // set the background according to display device 
   {
      if (bEGAMode)
         wc.hbrBackground = GetStockObject(GRAY_BRUSH);
      else
         wc.hbrBackground = GetStockObject(LTGRAY_BRUSH);
   }
   else
      wc.hbrBackground = GetStockObject(WHITE_BRUSH);

   if (!RegisterClass(&wc))
      return FALSE;

   return TRUE;
}   //*** InitApplication()

//*************************************************************
//
//  Function: InitInstance()
//
//  Purpose:
//        Initializes each instance (window creation)
//
//
//  Parameters:
//      HANDLE hInstance - handle to this instance
//      int nCmdShow     - command line
//      
//
//  Return: 
//      TRUE if successful, FALSE otherwise
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//              1/6/92     saraw      Created
//
//*************************************************************

BOOL InitInstance (HANDLE hInstance, int nCmdShow)
{
   BITMAP bm;
   WORD wWinHeight, wWinWidth;
   RECT r;
   int iScreenWidth, iScreenHeight;

   ghInst = hInstance;

   // Initialize original bitmap since we need it to size the main 
   // window and initialize the other bitmaps.

   ghCoolBitmaps[1] = LoadBitmap(ghInst, "WINBTMP");

   GetObject(ghCoolBitmaps[1], sizeof(BITMAP), &bm);

   gwOrigBitmapWidth = bm.bmWidth;
   gwOrigBitmapHeight = bm.bmHeight;

   iScreenWidth = GetSystemMetrics(SM_CXSCREEN);
   iScreenHeight = GetSystemMetrics(SM_CYSCREEN);

   // Scale the bitmap so that it matches the current resolution.  
   // Since all the other bitmaps are made by expanding or shrinking 
   // the original bitmap, the scaling only has to be done once.

   if ((iScreenWidth != STNDWIDTH) | (iScreenHeight != STNDHEIGHT))
   {

      HDC hDC, hMemOrigDC, hMemNewDC;
      HBITMAP hNewBitmap, hOldBitmap, hOld2Bitmap;
      int iNewHeight, iNewWidth;

      // scale width and height

      iNewWidth = MulDiv(bm.bmWidth, iScreenWidth, STNDWIDTH);
      iNewHeight = MulDiv(bm.bmHeight, iScreenHeight, STNDHEIGHT);

      hDC = GetDC(ghWndMain);

      // Scale the original bitmap

      hMemOrigDC = CreateCompatibleDC(hDC);
      hMemNewDC = CreateCompatibleDC(hDC);

      hNewBitmap = CreateCompatibleBitmap(hDC, iNewWidth, iNewHeight);

      hOldBitmap = SelectObject(hMemOrigDC, ghCoolBitmaps[1]);

      hOld2Bitmap = SelectObject(hMemNewDC, hNewBitmap);

      SetStretchBltMode(hMemNewDC, STRETCH_DELETESCANS);

      StretchBlt(hMemNewDC, 0, 0, iNewWidth, iNewHeight,
                 hMemOrigDC, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY);

      // clean up
      SelectObject(hMemOrigDC, hOldBitmap);
      hNewBitmap = SelectObject(hMemNewDC, hOld2Bitmap);
      DeleteObject(hMemOrigDC);
      DeleteObject(hMemNewDC);
      DeleteObject(ghCoolBitmaps[1]);

      ReleaseDC(ghWndMain, hDC);

      ghCoolBitmaps[1] = hNewBitmap;

      // used to determine the width and height of the main window
      gwOrigBitmapHeight = iNewHeight;
      gwOrigBitmapWidth = iNewWidth;


   }

   ghCoolBitmaps[2] = ghCoolBitmaps[1];

   gwBarHeight = GetSystemMetrics(SM_CYICON);

   wWinHeight = 2 * gwOrigBitmapHeight + 2 * GetSystemMetrics(SM_CYBORDER)
                + GetSystemMetrics(SM_CYMENU)
                + GetSystemMetrics(SM_CYCAPTION)
                + gwBarHeight - 1;

   wWinWidth = 2 * gwOrigBitmapWidth + 2 * GetSystemMetrics(SM_CXBORDER);

   ghWndMain = CreateWindow(szMainClass,
			    "Sample DMLCLT Application",
                            WS_OVERLAPPEDWINDOW ^ WS_THICKFRAME,  // make it unsizeable          
                            20,
                            20,
                            wWinWidth,
                            wWinHeight,
                            NULL, NULL, hInstance, NULL);

   if (!ghWndMain)
      return (FALSE);

   ShowWindow(ghWndMain, nCmdShow);
//   UpdateWindow(ghWndMain);

   GetClientRect(ghWndMain, &r);

   if (iScreenWidth != STNDWIDTH)
       InitializeStatusBarStuff(TRUE);    // main window has been scaled.
   else
       InitializeStatusBarStuff(FALSE); // main window hasn't been scaled.

   ghWndStatus = CreateWindow(szStatusLine, szNullString,
                              WS_CHILD,
                              0, r.bottom - gwBarHeight,
                              GetSystemMetrics(SM_CXSCREEN),
                              gwBarHeight,
                              ghWndMain, NULL, ghInst, NULL);

   ShowWindow(ghWndStatus, SW_SHOWNORMAL);
   UpdateWindow(ghWndStatus);

   return (TRUE);
}   //*** InitInstance()

//*** EOF: init.c
