//****************************************************************************
// File: callback.c
//
// Purpose: Contains DDEML callback function
//
// Functions:
//    Handles ddeml callbacks
//
// Development Team:
//        Sara Williams
//
// Written by Microsoft Product Support Services, Windows Developer Support
// Copyright (c) 1992 Microsoft Corporation. All rights reserved.
//****************************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
#include "global.h"
#include <math.h>   // for sqrt function
#include <errno.h>

//*************************************************************
//
//  Function: DdeCallBack()
//
//  Purpose:
//        Handles DDEML transaction (callback) processing for the client.
//
//
//  Parameters:
//
//        WORD     wType    // type of transaction
//        WORD     wFmt     // clipboard format
//        HCONV    hConv    // handle of the conversation
//        HSZ      hsz1     // string handle
//        HSZ      hsz2     // string handle
//        HDDEDATA hDDEData // handle of a global memory object
//        DWORD    dwData1  // transaction-specific data
//        DWORD    dwData2  // transaction-specific data
//
//      
//
//  Return: HDDEDATA
//    Dependent on transaction
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//              1/6/92     saraw      Created
//
//*************************************************************
HDDEDATA EXPENTRY DdeCallBack(WORD     wType,
                              WORD     wFmt,
                              HCONV    hConv,
                              HSZ      hsz1,
                              HSZ      hsz2,
                              HDDEDATA hData,
                              DWORD    dwData1,
                              DWORD    dwData2)
{
      // The callback function allows the client to communicate 
      // with the DDEML, and thus, to the server.  When the DDEML
      // has something to tell the client, it calls the client's 
      // callback function. When the client has something to tell
      // the DDEML (or the server), it does it through the callback
      // function.

  switch(wType)
  {
    case XTYP_REGISTER:
    {
          // The client receives an XTYP_REGISTER transaction when the 
          // server calls DdeNameServer() to register the name of its
          // service.
 
          // Keep handles for later use.
          DdeKeepStringHandle(idInst, hsz1);
          DdeKeepStringHandle(idInst, hsz2);
          
          hszServerBase = hsz1;
          hszServerInst = hsz2;

    }
          return (HDDEDATA)NULL;

    case XTYP_UNREGISTER:

          return (HDDEDATA)NULL;

    case XTYP_DISCONNECT:
     {
          HMENU hMenu;
           
          DdeFreeStringHandle(idInst, hszServerBase);
          DdeFreeStringHandle(idInst, hszServerInst);

              // Adjust menu items
          hMenu = GetMenu(ghWndMain);

          EnableMenuItem(hMenu, IDM_CONNECTTOSERVER, 
                            MF_BYCOMMAND | MF_ENABLED);
                        
          EnableMenuItem(hMenu, IDM_DOTRANSACTION,
                         MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

          EnableMenuItem(hMenu, IDM_STARTHOTADVISE,
                         MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

          EnableMenuItem(hMenu, IDM_STARTWARMADVISE,
                         MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

          EnableMenuItem(hMenu, IDM_STOPHOTADVISE,
                         MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

          EnableMenuItem(hMenu, IDM_STOPWARMADVISE,
                         MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

          // Set global state variables
          ghConv = NULL;
          ghSysConv = NULL;
          bHotAdviseLoop = FALSE;
          bWarmAdviseLoop = FALSE;

           // Update status bar
          SetStatusBar(IDD_ADVISESTATUS);  
          SetStatusBar(IDD_CONNECTSTATUS);
     }
          return (HDDEDATA)NULL;

    case XTYP_ADVDATA:
     {
          // The client receives an XTYP_ADVDATA transaction when there is
          // an advise loop active and the associated data has changed. If
          // the advise loop is WARM, then hData parameter is NULL (no data
          // is sent, just notification).  If the advise loop is HOT, then
          // the hData parameter contains a handle to the changed data.

          BITMAP  bm;
          HBITMAP hBitmap, hOrigBitmap;
          RECT    Rect;
          HDC     hDC, hMemDC;
          BOOL    bWarm = FALSE;

          if (hData == NULL)  // hData == NULL if this is a WARM advise loop.
          {
             int  iRetValue;
              
             // Ask the user if the client should get the changed data
             // from the server.  If the user selects YES, then the 
             // client sends an XTYP_REQUEST for the changed bitmap.  If
             // the user selects NO, then we just return, without updating
             // the display.

             iRetValue = MessageBox(ghWndMain,"Server's Bitmap has changed.\r\nDo you want to update the client's bitmap?", 
				     "DDEML DMLCLT Sample", MB_YESNO | MB_ICONEXCLAMATION);

             if (iRetValue != IDYES) // user does not want to update
                return (HDDEDATA)DDE_FACK;

                 // User wants the updated data
             hData = DdeClientTransaction(NULL,
                                          0,
                                          hConv,
                                          hsz2,
                                          CF_BITMAP,      
                                          XTYP_REQUEST,
                                          1000,
                                          NULL);
             if (!hData)
             {
                WORD wError;
                char szBuffer[64];

                wError = DdeGetLastError(idInst);
                wsprintf(szBuffer, "DdeClientTransaction failed.  Error #%#0x", wError);
                MessageBox(ghWndMain, szBuffer, "Error", MB_OK);
                return (HDDEDATA)DDE_FNOTPROCESSED;
             }
             bWarm = TRUE;
          }


             // Copy the contents of hData into hBitmap. 
             // NOTE: If we wanted to use this bitmap after the callback had
             // returned (like in the WM_PAINT case), then we would have to
             // make a local copy of the entire bitmap (not just the handle)
             // for later use because the DDEML will free the hData when the
             // callback returns (unless the hData is appowned, but that's
             // another story...)

          DdeGetData(hData, (LPBYTE)&hBitmap, sizeof(HBITMAP), 0);

          // Display bitmap in client's window
          GetObject(hBitmap, sizeof(BITMAP), &bm);

          hDC = GetDC(ghWndMain);

          hMemDC = CreateCompatibleDC(hDC);

          hOrigBitmap = SelectObject(hMemDC, hBitmap);

          GetClientRect(ghWndMain, &Rect);

          StretchBlt(hDC, 0, 0, Rect.right, Rect.bottom - gwBarHeight + 1, 
                     hMemDC, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY);

          // Clean up our mess.
          ReleaseDC(ghWndMain, hDC);

          SelectObject(hMemDC, hOrigBitmap);
          DeleteObject(hMemDC);

          // The client is responsible for freeing any data handles that
          // it receives from a request.  The DDEML is smart enough not
          // to really free the data if it is appowned by the server.

          if (bWarm)
             DdeFreeDataHandle(hData);

     }
     return (HDDEDATA)DDE_FACK;


    case XTYP_XACT_COMPLETE:
     {
        // The client receives the XTYP_XACT_COMPLETE when the server has
        // completed an asynchronous transaction.

        if (!hData)
           return (HDDEDATA)NULL;

        // Since you could have multiple asynchronous tranactions all
        // going at the same time, it's important to know which 
        // transaction this result is for.  Since we only have one,
        // it's not such a big deal.

        if (dwData1 == dwAsyncXact)
        {
          DWORD  dwBytesCopied = 0;
          int    nReturnValue;

          // Copy the contents of hData into nReturnValue
          dwBytesCopied = DdeGetData(hData, (LPBYTE)&nReturnValue, 
                                     sizeof(int), 0);

          // Everything still okay?
          if (!dwBytesCopied)
              return (HDDEDATA)NULL;

          else
          {  
             BOOL bSuccess = FALSE;
             int  nRowsColumns;

             // The server returns the number of bitmaps the client 
             // should display.  To simplify things, the server can
             // only return perfect squares (makes tiling much easier).

             nRowsColumns = (int)(sqrt((LONG)nReturnValue));

             // Show the specified number of bitmaps.  The ghCoolBitmap
             // array is set up so that the number of columns -1 is the
             // index of the bitmap to be used to display (number of
             // columns)^2 bitmaps.

             bSuccess = ShowCoolBitmap(ghCoolBitmaps[nRowsColumns -1], nRowsColumns, nRowsColumns);

          }  // end else

        } // end if

        // Done with asynchronous transaction
        dwAsyncXact = 0L;

     }     // end case
     return (HDDEDATA)NULL;


     default:
        return (HDDEDATA)NULL;

  }  // end switch

}    // end DdeCallBack

