//*************************************************************
//  File name: DMLCLT.c
//
//  Purpose: Contains main message loop and application entry point
//
//  Functions:
//      WinMain() - initializes everything and enters message loop
//      MainWndProc() - main window message processing procedure
//      ShowCoolBitmaps() - displays specified number of bitmaps
//                          in client window.
//      DoSystemTopicRequest() - handles all requests on the SYSTEM
//                               topic.
//  Development Team:
//      Sara Williams 
//
// Written by Microsoft Product Support Services, Windows Developer Support
// Copyright (c) 1992 Microsoft Corporation. All rights reserved.
//*************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "global.h"

HANDLE  ghInst      = NULL; // handle to this instance
HWND    ghWndMain   = NULL; // handle to main window
HWND    ghWndStatus;        // handle to status bar window
HBITMAP ghFastBitmapStatus; // handle to status bar window
HFONT   ghSmallFont;        // handle to small font for status bar

char    szMainMenu[]    = "MainMenu";
char    szMainClass[]   = "ClientClass";
                                           
DWORD   idInst = 0L;             // instance identifier
HSZ     hszServerBase = NULL;    // Service name
HSZ     hszServerInst = NULL;    // Instance-specific service name
                                           
HSZ     ghszTopics[TOPICS];      // topics we use
HSZ     ghszItems[ITEMS];        // items we use
                                           
HCONV   ghConv = NULL;           // handle to conversation (generic)
HCONV   ghSysConv = NULL;        // handle to system conversation
                                            
BOOL    bAsyncStart = FALSE;     // Successful start of async transaction
DWORD   dwAsyncXact = NULL;      // unique identifier for async transaction

BOOL    bHotAdviseLoop = FALSE;  // For status bar updates
BOOL    bWarmAdviseLoop = FALSE; 

//*************************************************************
//
//  Function: MainWndProc()
//
//  Purpose:
//        Handles message processing for the main window. 
//
//
//  Parameters:
//      HWND hWnd     // handle to the main window
//      unsigned msg  // current message
//      WORD wParam   // additional information
//      LONG lParam   // additional information
//      
//
//  Return: (long FAR PASCAL)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//              1/6/92     saraw      Created
//
//*************************************************************

long FAR PASCAL MainWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    static FARPROC lpProc;
    static FARPROC lpfnDdeCallBack;

    switch (msg) 
    {
       case WM_CREATE:
       {
           char szBuffer[256];
           HMENU hMenu;

           // Ddeml initialization

           lpfnDdeCallBack = MakeProcInstance((FARPROC)DdeCallBack, ghInst);
           if(DdeInitialize(&idInst, (PFNCALLBACK)lpfnDdeCallBack,
                            APPCMD_CLIENTONLY, 0L))
              return FALSE;

           // Create string handles for the Topic names we'll be using
           LoadString(ghInst, IDS_SAMPLETOPIC, szBuffer, 256);
           ghszTopics[SAMPLE] = DdeCreateStringHandle(idInst, (LPSTR)szBuffer, CP_WINANSI);
           ghszTopics[SYSTEM] = DdeCreateStringHandle(idInst, (LPSTR)SZDDESYS_TOPIC, CP_WINANSI);
           
           // Create string handles for the Item names we'll be using
           LoadString(ghInst, IDS_NWDITEM, szBuffer, 256);
           ghszItems[NUMBER] = DdeCreateStringHandle(idInst, (LPSTR)szBuffer, CP_WINANSI);
           
           LoadString(ghInst, IDS_CHANGEBMPITEM, szBuffer, 256);
           ghszItems[CHANGEBMP] = DdeCreateStringHandle(idInst, (LPSTR)szBuffer, CP_WINANSI);

           // Initialize menu items

           hMenu = GetMenu(hWnd);
           EnableMenuItem(hMenu, IDM_DOTRANSACTION,
                          MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

           EnableMenuItem(hMenu, IDM_STARTHOTADVISE,
                          MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

           EnableMenuItem(hMenu, IDM_STARTWARMADVISE,
                          MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

           EnableMenuItem(hMenu, IDM_STOPHOTADVISE,
                          MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

           EnableMenuItem(hMenu, IDM_STOPWARMADVISE,
                          MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

           // need valid hDC to initialize bitmaps
           PostMessage(hWnd, WM_INITSTUFF, 0, 0L);  
        }
        break;

        case WM_INITSTUFF:
           // Initialize bitmap array and show the instructions dialog
           // box.

           if (!InitializeCoolBitmaps())
               MessageBox(hWnd, "Bitmaps not initialized.", "Error", MB_OK);

           SendMessage(hWnd, WM_COMMAND, IDM_WHATDOIDO, 0L);  // show instructions
           break;


        case WM_MENUSELECT:
           // Update status bar information based on the 
           // currently highlighted menu item.
           if (IsWindow(ghWndStatus))
           {
              if (-1 == LOWORD(lParam))  // User has left the menu - 
                                               // restore Status fields
              {
                  RECT r;
                  HDC  hDC;

                  hDC=GetDC(ghWndStatus);
                  GetWindowRect(ghWndStatus, &r);
                  ScreenToClient(ghWndStatus, (LPPOINT)&r.left);
                  ScreenToClient(ghWndStatus, (LPPOINT)&r.right);
                  r.top    += 2; //leave the nice border
                  r.bottom -= 2; //leave the nice border
                  FillRect(hDC, &r, (HBRUSH)GetClassWord(ghWndStatus, GCW_HBRBACKGROUND));
                  ReleaseDC(ghWndStatus, hDC);

                  SetStatusBar(IDD_ADVISESTATUS);  
                  SetStatusBar(IDD_CONNECTSTATUS);
              }
              else     // User is in the menu;  display information about 
                       // the currently highlighted menu item.

               SendMessage(ghWndStatus, WM_MYCOMMAND, wParam, 0L );
           }
           break;

         case WM_SIZE:
         {
           if (ghWndStatus)  // Size status window too.
           {
              RECT Rect;

              GetClientRect(hWnd, &Rect);

              MoveWindow(ghWndStatus, 0, Rect.bottom - gwBarHeight, 
                         GetSystemMetrics(SM_CXSCREEN), gwBarHeight, TRUE);
           }

             return DefWindowProc(hWnd, msg, wParam, lParam);
         }
                
         case WM_COMMAND: 
           switch ( wParam )
           {
              case IDM_CONNECTTOSERVER:  // establish GENERAL conversation
                                         // with server
              {  
                 HMENU hMenu;

                 // connect to server
                 if (!(ghConv = DdeConnect(idInst,            // instance identifier
                                           hszServerBase,     // service name
                                           ghszTopics[SAMPLE],// topic name
                                           (LPVOID)NULL)))    // use default CONVINFO
                 {
                    // Ddeconnect failed - do error handling
                     WORD wError;

                     wError = DdeGetLastError(idInst);
                     wsprintf(szBuffer, "DdeConnect failed.  Error #%#0x", wError);
                     MessageBox(ghWndMain, szBuffer, "Error", MB_OK);
                     return FALSE;
                 }

                 // Adjust menu items

                 hMenu = GetMenu(hWnd);

                 EnableMenuItem(hMenu, IDM_DOTRANSACTION, 
                                MF_BYCOMMAND | MF_ENABLED);

                 EnableMenuItem(hMenu, IDM_STARTHOTADVISE,
                                MF_BYCOMMAND | MF_ENABLED);

                 EnableMenuItem(hMenu, IDM_STARTWARMADVISE,
                                MF_BYCOMMAND | MF_ENABLED);

                 EnableMenuItem(hMenu, IDM_CONNECTTOSERVER, 
                                MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

                 // Update status bar
                 SetStatusBar(IDD_CONNECTSTATUS);

              }
              break;

              case IDM_DOTRANSACTION:  // Starts asynchronous transaction
              { 
                 // start asynch transaction with server
                 bAsyncStart = (BOOL) DdeClientTransaction(NULL, // pointer to data to pass to server
                                    0,                    // length of data
                                    ghConv,               // handle to conversation
                                    ghszItems[NUMBER],    // handle to item-name string
                                    CF_TEXT,              // clipboard format
                                    XTYP_REQUEST,         // transaction type
			    (DWORD) TIMEOUT_ASYNC,	  // asynchronous transaction
                                    (DWORD FAR *)&dwAsyncXact); // pointer to result

             
                 if (!bAsyncStart)
                 return FALSE;
               }
               break;

               case IDM_STARTHOTADVISE:
               {    
                  // Establish a hot advise loop to display server's
                  // bitmap in the client window.

                  HMENU hMenu;

                  // start hot advise loop
                  if (!DdeClientTransaction(NULL,  // don't pass any data
                             0,                    // no data has no length
                             ghConv,               // handle to conversation
                             ghszItems[CHANGEBMP], // handle to item-name string
                             CF_BITMAP,            // clipboard format
                             XTYP_ADVSTART,        // start hot advise loop 
                             1000,                 // timeout in one second
                             NULL))                // no result
                      return FALSE;

                    // update menu items
                  hMenu = GetMenu(hWnd);
                  
                  EnableMenuItem(hMenu, IDM_STARTHOTADVISE,
                                  MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

                  EnableMenuItem(hMenu, IDM_STARTWARMADVISE,
                                  MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

                  EnableMenuItem(hMenu, IDM_STOPHOTADVISE,
                                  MF_BYCOMMAND | MF_ENABLED);

                  // update status bar
                  bHotAdviseLoop = TRUE;
                  SetStatusBar(IDD_ADVISESTATUS);
               }
               break;

               case IDM_STARTWARMADVISE:
               {    
                  // Establish a warm advise loop to display server's
                  // bitmap in the client window.

                  HMENU hMenu;

                  // Start WARM advise loop. The XTYPF_NODATA flag
                  // is used to specify a warm loop.
                  if (!DdeClientTransaction(NULL, // don't pass any data
                            0,                    // no data has no length
                            ghConv,               // handle to conversation
                            ghszItems[CHANGEBMP], // handle to item-name string
                            CF_BITMAP,            // clipboard format
                            XTYP_ADVSTART         // start warm advise loop 
                             | XTYPF_NODATA,
                            1000,                 // timeout in one second
                            NULL))                // no result
                  {
                     wsprintf(szBuffer, "DdeClientTransaction - Advise loop - failed.");
                     MessageBox(ghWndMain, "DdeClientTransaction Failed.", "Error", MB_OK);
                     break;
                  }

                  // update menu items
                  hMenu = GetMenu(hWnd);
                  
                  EnableMenuItem(hMenu, IDM_STARTHOTADVISE,
                                 MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

                  EnableMenuItem(hMenu, IDM_STARTWARMADVISE,
                                 MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

                  EnableMenuItem(hMenu, IDM_STOPWARMADVISE,
                                 MF_BYCOMMAND | MF_ENABLED);

                  // update status bar
                  bWarmAdviseLoop = TRUE;
                  SetStatusBar(IDD_ADVISESTATUS);
                                                         
               }
               break;

               case IDM_STOPWARMADVISE:  // intentional fall-through
               case IDM_STOPHOTADVISE:
               {   
                  // stop the hot or warm advise loop

                  HMENU hMenu;

                  if (!DdeClientTransaction(NULL,  // don't pass any data
                           0,                      // no data has no length
                           ghConv,                 // handle to conversation
                           ghszItems[CHANGEBMP],   // handle to item-name string
                           CF_BITMAP,              // clipboard format
                           XTYP_ADVSTOP,           // stop advise loop 
                           1000,                   // timeout in one second
                           NULL))                  // no result

                      return FALSE;

                  // update menu items
                  hMenu = GetMenu(hWnd);
                  
                  EnableMenuItem(hMenu, IDM_STOPHOTADVISE,
                                 MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

                  EnableMenuItem(hMenu, IDM_STARTHOTADVISE,
                                 MF_BYCOMMAND | MF_ENABLED);

                  EnableMenuItem(hMenu, IDM_STOPWARMADVISE,
                                 MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

                  EnableMenuItem(hMenu, IDM_STARTWARMADVISE,
                                 MF_BYCOMMAND | MF_ENABLED);

                  // update status bar
                  bHotAdviseLoop = FALSE;  // Since they are mutually exclusize, 
                  bWarmAdviseLoop = FALSE; //   this is okay.
                                          //Update Status bar
                  SetStatusBar(IDD_ADVISESTATUS);

                }
                break;

                // Do a request transaction on the system topic
                case IDM_SYSTOPICS:  
                case IDM_ITEMLIST:
                case IDM_SYSITEMS:
                case IDM_FORMATS:
                case IDM_STATUS:
                case IDM_RTNMSG:
                case IDM_SVRHELP:        // intentional fall-throughs
                {
                   LPSTR lpMessage;

                   // DoSystemTopicRequest() returns a LPSTR to the
                   // title and string containing the system 
                   // information that is returned by the server

                   lpMessage = DoSystemTopicRequest(wParam);

                   // display system topic information
                   MessageBox(hWnd, lpMessage, (LPSTR)"DDEML Sample", 
                              MB_OK | MB_ICONEXCLAMATION);
                }
                break;


                case IDM_WHATDOIDO: // show the instructions box

                   lpProc = MakeProcInstance(WhatDoIDo, ghInst);
                   DialogBox(ghInst, "WhatDoIDo", hWnd, lpProc);    
                   FreeProcInstance(lpProc);

                break;

                case IDM_ABOUT: // show about box

                   lpProc = MakeProcInstance(About, ghInst);
                   DialogBox(ghInst, "AboutBox", hWnd, lpProc);    
                   FreeProcInstance(lpProc);

                break;
           }
         break;

         case WM_DESTROY:
         {
            int i;
            // Our mom doesn't work here, so we clean up
            // our mess.
            DdeFreeStringHandle(idInst, ghszTopics[SAMPLE]);
            DdeFreeStringHandle(idInst, ghszTopics[SYSTEM]);
            DdeFreeStringHandle(idInst, ghszItems[0]);
            DdeFreeStringHandle(idInst, ghszItems[1]);

            // terminate all DDE conversations
            DdeUninitialize(idInst);

            FreeProcInstance(lpfnDdeCallBack);

            for (i = 0; i < NUMBITMAPS; i++)
              DeleteObject(ghCoolBitmaps[i]);

            if (ghFastStatusDC) 
              DeleteDC(ghFastStatusDC);

            if (ghFastBitmapStatus) 
              DeleteObject(ghFastBitmapStatus);

            if (ghSmallFont)
              DeleteObject(ghSmallFont);

            PostQuitMessage(0);
         }
         break;
    }
    return (DefWindowProc(hWnd, msg, wParam, lParam));

} //*** MainWndProc()

//***********************************************************************
// Function: DoSysTopicRequest()
//
// Purpose: Handles request on system topic.
//
// Parameters:
//    WORD wParam - System item to use for the request.               
//
// Returns: 
//    LPSTR - points to string containing title and system information
//
// Comments:
//    There are two parts to the lpstr that gets returned: a title, and
//    the information from the request to the server.  Depending on the
//    item the user selects, the title is loaded into a buffer from the
//    string table, and a string handle is created for the item selected.
//    Then, if one is not present we establish a conversation on the
//    system topic and then send an XTYP_REQUEST to the server.  We then
//    concatenate the string returned by the server and the title we 
//    loaded and return the lpstr to the new string.
//
// History:  Date       Author        Reason
//           1/6/92     saraw         Created
//***********************************************************************
LPSTR DoSystemTopicRequest(WORD wParam)
{
   static char szBuffer[256];  // statics so strings do not reside on stack
    static char szMessage[512];
    HDDEDATA    hData;             // handle to system information returned by server
    HSZ         hszItem;        // item to request system info about
    DWORD       dwChars;        // length of string server returns 

   switch (wParam)   // Put the topic-specific title in a buffer and
                     // create a string handle for the specified item.
   {
     case IDM_SYSTOPICS:  
     {
        LoadString(ghInst, IDS_SYSTOPICSTITLE, szMessage, 256);
        hszItem = DdeCreateStringHandle(idInst, (LPSTR)SZDDESYS_ITEM_TOPICS, CP_WINANSI);
     }
     break;

     case IDM_ITEMLIST:
     {
        LoadString(ghInst, IDS_ITEMLISTTITLE, szMessage, 256);
        hszItem = DdeCreateStringHandle(idInst, (LPSTR)SZDDE_ITEM_ITEMLIST, CP_WINANSI);
     }
     break;

     case IDM_SYSITEMS:
     {
        LoadString(ghInst, IDS_SYSITEMSTITLE, szMessage, 256);
        hszItem = DdeCreateStringHandle(idInst, (LPSTR)SZDDESYS_ITEM_SYSITEMS, CP_WINANSI);
     }
     break;

     case IDM_FORMATS:
     {
        LoadString(ghInst, IDS_FORMATSTITLE, szMessage, 256);
        hszItem = DdeCreateStringHandle(idInst, (LPSTR)SZDDESYS_ITEM_FORMATS, CP_WINANSI);
     }
     break;

     case IDM_STATUS:
     {
        LoadString(ghInst, IDS_STATUSTITLE, szMessage, 256);
        hszItem = DdeCreateStringHandle(idInst, (LPSTR)SZDDESYS_ITEM_STATUS, CP_WINANSI);
     }
     break;

     case IDM_RTNMSG:
     {
        LoadString(ghInst, IDS_RTNMSGTITLE, szMessage, 256);
        hszItem = DdeCreateStringHandle(idInst, (LPSTR)SZDDESYS_ITEM_RTNMSG, CP_WINANSI);
     }
     break;

     case IDM_SVRHELP:
     {
        LoadString(ghInst, IDS_HELPTITLE, szMessage, 256);
        hszItem = DdeCreateStringHandle(idInst, (LPSTR)SZDDESYS_ITEM_HELP, CP_WINANSI);
     }
     break;

   }
    
   if (!ghSysConv)  // Is there a SYSTEM conversation already?
   {
      HSZ hszService;

      // Establish system conversation
      hszService = DdeCreateStringHandle(idInst, (LPSTR)"DDEMLDemo", CP_WINANSI);
      ghSysConv = DdeConnect(idInst, hszService, ghszTopics[SYSTEM], NULL);

      DdeFreeStringHandle(idInst, hszService);

      // update status bar
      SetStatusBar(IDD_CONNECTSTATUS); // update status bar
    }

    // Get the system information
    hData = DdeClientTransaction(NULL,         // no data to pass to server
                                 0,            // no data has no length
                                 ghSysConv,    // handle of the conversation
                                 hszItem,      // item we want system info about
                                 CF_TEXT,      // clipboard format
                                 XTYP_REQUEST, // type of transaction
                                 1000,         // timeout after 1 second
                                 NULL);        // no buffer

    if (!hData)
       lstrcpy(szBuffer, "Error");

    else
    {                
      // get the data out of hData
      dwChars = DdeGetData(hData, NULL, 256, 0); // find length of data
      dwChars = DdeGetData(hData, szBuffer, dwChars, 0);
    }

    // Let the ddeml know that it should free this data handle
    DdeFreeStringHandle(idInst, hszItem);

    // return the system info and the title
    return (lstrcat((LPSTR)szMessage, (LPSTR)szBuffer));

}


//***************************************************************************
//                                                                          
//  Function: ShowCoolBitmap()                                           
//                                                                          
//  Purpose:
//    Displays nRows * nColumns copies of the bitmap in the client window.
//                                                                          
//  Parameters:
//    HBITMAP hBitmap    - Handle to bitmap we want to display
//    int     nRows      - Number of rows
//    int     nColumns   - Number of columns
//
//  Returns: 
//    True if successful, False otherwise,                       
//
//  Comments:
//
//  History:  Date       Author        Reason
//            1/6/92     saraw         Created
//****************************************************************************
BOOL ShowCoolBitmap(HBITMAP hBitmap, int nRows, int nColumns)
{
  HDC         hDC, hMemDC;
  HBITMAP     hOrigBitmap;
  BITMAP      bm;
  int         i, j;


  GetObject(hBitmap, sizeof(BITMAP), &bm);

  hDC = GetDC(ghWndMain);

  hMemDC = CreateCompatibleDC(hDC);

  hOrigBitmap = SelectObject(hMemDC, hBitmap);

  for (i = 0; i < nColumns; i++)
    for (j = 0; j < nRows; j++)
       BitBlt(hDC, i*bm.bmWidth, j*bm.bmHeight, bm.bmWidth, bm.bmHeight,
              hMemDC, 0, 0, SRCCOPY);

  ReleaseDC(ghWndMain, hDC);

  SelectObject(hMemDC, hOrigBitmap);

  DeleteDC(hMemDC);

  return TRUE;
}



//***********************************************************************
// Function: WinMain
//
// Purpose: Called by Windows on app startup.  Initializes everything,
//          and enters a message loop.
//
// Parameters:
//    hInstance     - Handle to _this_ instance.
//    hPrevInstance - Handle to last instance of app.
//    lpCmdLine     - Command Line passed into app.
//    nCmdShow      - How app should come up (i.e. minimized/normal)
//
// Returns: Return value from PostQuitMessage.
//
// Comments:
//
// History:  Date       Author        Reason
//           1/6/92     saraw         Created
//
//*************************************************************

int PASCAL WinMain(HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    MSG msg;
    HWND FirsthWnd, FirstChildhWnd;

    // Only one instance of the client can run, so we check to see
    // if there is another one that is already running.  If there
    // is, then we bring it to the top and do not start the second
    // instance.

    if (FirsthWnd = FindWindow(szMainClass, NULL))
    {
      // Found another running application with the same class
      // name so one instance is already running.
  
      FirstChildhWnd = GetLastActivePopup(FirsthWnd);
      BringWindowToTop(FirsthWnd);      // Bring main window to top.
  
      if (FirsthWnd != FirstChildhWnd)
         BringWindowToTop(FirstChildhWnd); // A pop-up is active so
                                           // bring it to the top too.
  
      return (FALSE);                   // Do not run second instance.
    }

    if (!hPrevInstance && !InitApplication(hInstance))
      return (FALSE);       

    if (!InitInstance(hInstance, nCmdShow))
      return (FALSE);

    while (GetMessage(&msg, NULL, NULL, NULL))
    {
        TranslateMessage(&msg);      
        DispatchMessage(&msg);       
    }
    return (msg.wParam);      

} //*** WinMain()

//*** EOF: main.c
