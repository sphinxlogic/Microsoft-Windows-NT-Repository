//***************************************************************************
//
// File name: Mainwnd.c
//
// This source file provides the message function for HOTSPOTS.EXE.  It is
// designed be a flexable way to determine exactly where the hotspots are
// in gestures.
//
// Description of functions:
//
//   InPenWin() - Loads Penwin.dll and gets the addresses to the functions
//		  that will be used throughout the program.
//   MainWndProc() - Main Window message function.
//
//   CircleFirstHotSpot() - Cirlces the hotspot in the gesture.
//
//   ErrorBox() - Used to output MessageBoxes.
//
// Developed By: David Flenniken, Microsoft Windows Developer Support
//
// THE INFORMATION AND CODE PROVIDED HEREUNDER (COLLECTIVELY REFERRED TO
// AS "SOFTWARE") IS PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. IN
// NO EVENT SHALL MICROSOFT CORPORATION OR ITS SUPPLIERS BE LIABLE FOR
// ANY DAMAGES WHATSOEVER INCLUDING DIRECT, INDIRECT, INCIDENTAL,
// CONSEQUENTIAL, LOSS OF BUSINESS PROFITS OR SPECIAL DAMAGES, EVEN IF
// MICROSOFT CORPORATION OR ITS SUPPLIERS HAVE BEEN ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGES. SOME STATES DO NOT ALLOW THE EXCLUSION OR
// LIMITATION OF LIABILITY FOR CONSEQUENTIAL OR INCIDENTAL DAMAGES SO THE
// FOREGOING LIMITATION MAY NOT APPLY.
//
// This Software may be copied and distributed royalty-free subject to
// the following conditions:
//
// 1. You must copy all Software without modification and must include
//    all pages, if the Software is distributed without inclusion in your
//    software product. If you are incorporating the Software in
//    conjunction with and as a part of your software product which adds
//    substantial value, you may modify and include portions of the
//    Software.
//
// 2. You must place all copyright notices and other protective
//    disclaimers and notices contained on the Software on all copies of
//    the Software and your software product.
//
// 3. Unless the Software is incorporated in your software product which
//    adds substantial value, you may not distribute this Software for
//    profit.
//
// 4. You may not use Microsoft's name, logo, or trademarks to market
//    your software product.
//
// 5. You agree to indemnify, hold harmless, and defend Microsoft and its
//    suppliers from and against any claims or lawsuits, including
//    attorneys' fees, that arise or result from the use or distribution
//    of your software product and any modifications to the Software.
//
//**********************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
#define WIN31
#include "windows.h"
#include "penwin.h"
#include "Globals.h"
#include "mainwnd.h"

//**************************************************************************
//
//  Function: MainWndProc
//
//  Purpose:  Process messages for HotSpots.exe.  See individual messages
//	      below.
//
//  Returns:  Standard return.
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      12/20/91	David Flenniken  Created
//
//*************************************************************************
long FAR PASCAL MainWndProc(HWND hWnd, unsigned message, WORD wParam,
			    LONG lParam)
{
    switch ( message )
        {
        case WM_COMMAND:
            switch ( wParam )
                {
		case IDM_ABOUT:
		  // Displays about box for application
		  {
		    FARPROC  lpProcAbout;
		    char szStr[MSG_SHORT];

		    LoadString(ghInst,IDS_ABOUTBOX,(LPSTR)szStr,MSG_SHORT);
		    lpProcAbout = MakeProcInstance( About, ghInst );
		    DialogBox(ghInst, (LPSTR)szStr, hWnd, lpProcAbout);
		    FreeProcInstance( lpProcAbout );
		  }
		  break;
                }
	    break;

	case WM_CREATE:
	  // Checks for presence for Windows for Pens and inits globals
	  {
	    if(!InPenWin())
	       return -1;

	    gwGestureSet = INT_NOTAGESTURE;
	    ghPen = CreatePen(PS_SOLID,1,RGB(0,0,0));
	    ghPenDataTmp=NULL;
	  }
	  break;

	case WM_LBUTTONDOWN:
	 // distroys old data and calls recognize.
	    {
	       if(ghPenDataTmp)
		  DestroyPenData(ghPenDataTmp);

	       lpfnInitRC(hWnd, &grc);
	       grc.lRcOptions|=RCO_NOPOINTEREVENT;
	       lpfnRecognize(&grc);
	    }
	    break;

	case WM_RCRESULT:
	 // Copies hpendata and offsets it for window.
	 // Checks to see if it's a gesture and sets gwGestureSet accordingly
	  {
	    LPRCRESULT lpRcresult;
	    int i;
	    POINT pnt;

	    if(lpRcresult = (LPRCRESULT)lParam)
	    {
	       ghPenDataTmp=lpfnDuplicatePenData(lpRcresult->hpendata,
						 GMEM_MOVEABLE);
	       pnt.x=0;
	       pnt.y=0;
	       ClientToScreen(hWnd,&pnt);
	       lpfnDPtoTP(&pnt,1);

	       lpfnOffsetPenData(ghPenDataTmp,-pnt.x,-pnt.y);
	    }

	    if(lpRcresult->wResultsType & RCRT_GESTURE)
	    { // it is a gesture...


	       if(lpRcresult->syg.cHotSpot > 0)
	       { // there are hotspots...
		  for(i=0;i<lpRcresult->syg.cHotSpot;i++) {
		     gnNumHotSpots=lpRcresult->syg.cHotSpot;
		     grgpntStrokeHotSpots[i]=lpRcresult->syg.rgpntHotSpots[i];
		     lpfnTPtoDP(&(grgpntStrokeHotSpots[i]), 1);
		     ScreenToClient(hWnd, &(grgpntStrokeHotSpots[i]));
                  }
		  gwGestureSet = INT_HASHOTSPOT ;
	       }
	       else
	       {
		  gnNumHotSpots=0;
		  gwGestureSet=INT_NOHOTSPOT;
	       }
	    }
	    else
	    {
	       gnNumHotSpots=0;
	       gwGestureSet=INT_NOTAGESTURE;
	    }

	    InvalidateRect(hWnd, NULL,TRUE);
	    UpdateWindow(hWnd);
	  }
	  break;

	case WM_PAINT:
	  // draws the ink and circles the hotspot.
	  {
	    HDC hdc;
	    PAINTSTRUCT ps;

	    hdc = BeginPaint(hWnd,&ps);
	    if(ghPenDataTmp)
	    {
	       if(gwGestureSet!=INT_NOTAGESTURE)
	       {
		  lpfnRedisplayPenData(hdc,ghPenDataTmp,NULL,NULL,1,RGB(255,0,0));
		  if(gwGestureSet==INT_HASHOTSPOT)
		  {
		     int i;

		     for(i=0;i<gnNumHotSpots;i++)
			CircleHotSpots(hWnd, hdc,
				      (LPPOINT)&grgpntStrokeHotSpots[i]);
		  }
	       }
	       else
		  lpfnRedisplayPenData(hdc,ghPenDataTmp,NULL,NULL,1,RGB(0,0,0));
	    }
	    EndPaint(hWnd,&ps);
	  }
	  break;

	case WM_DESTROY:
	  // cleans up.
	    if (gwGestureSet)
	       DestroyPenData(ghPenDataTmp);
	    if(ghPen)
	       DeleteObject(ghPen);
            PostQuitMessage(0);
            break;

	case WM_SYSCOMMAND:
	  // changes name of app when minimized or maximized.
	  {
	    WORD wTmp;

	    wTmp=wParam&0xFFF0;
	    switch(wTmp)
	    {
	       case SC_MINIMIZE:
		  {
		     char szTitle[MSG_SHORT];
		     LoadString(ghInst,IDS_MINTITLE,(LPSTR)szTitle,MSG_SHORT);
		     SetWindowText(hWnd,(LPSTR)szTitle);
		  }
		  break;
	       case SC_RESTORE:
		  {
		     char szTitle[MSG_NORMAL];
		     LoadString(ghInst,IDS_TITLE,(LPSTR)szTitle,MSG_NORMAL);
		     SetWindowText(hWnd,(LPSTR)szTitle);
		  }
		  break;
	    }
	    return(DefWindowProc(hWnd,message,wParam,lParam));
	  }
	  break;

        default:
            return (DefWindowProc(hWnd, message, wParam, lParam));
     }

     return (NULL);
}

//**************************************************************************
//
//  Function: CircleHotSpots(HWND,HDC,LPPOINT)
//
//  Purpose:  Circles the hotspot
//
//  Returns:  void
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      12/20/91	David Flenniken  Created
//
//*************************************************************************
void NEAR CircleHotSpots(HWND hWnd,HDC hdc,LPPOINT lpPoints)
{
   HPEN hPenOld;

   hPenOld = SelectObject(hdc,ghPen);
   Ellipse(hdc,lpPoints->x-CIRCLE,lpPoints->y-CIRCLE,
	       lpPoints->x+CIRCLE,lpPoints->y+CIRCLE);
   SelectObject(hdc,hPenOld);
}


//**************************************************************************
//
//  Function: InPenWin(void)
//
//  Purpose:  To determine if we're currently in Windows for Pen Computing.
//	      If so, load the addresses of the functions that we want.
//	      If not, display an error message.
//
//  Returns:  TRUE on success, FALSE otherwise.
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      12/20/91	David Flenniken  Created
//
//*************************************************************************
BOOL FAR PASCAL InPenWin()
{
   BOOL bRet;

   bRet=FALSE;
   if(GetSystemMetrics(SM_PENWINDOWS))
   {
      char szPen[MSG_SHORT];

      // From here on out we know the Pen extensions are installed!
      // There is no reason why this loadlibrary call should fail.
      // But....
      LoadString(ghInst,IDS_PENWIN,(LPSTR)szPen,MSG_SHORT);
      if( (ghPenWinDLL=LoadLibrary((LPSTR)szPen))>32)
      {
	 char szProc[MSG_NORMAL];
	 // Get the address....
	 LoadString(ghInst,IDS_RECOGNIZE,(LPSTR)szProc,MSG_NORMAL);
	 lpfnRecognize=(LPFNRECOGNIZE)GetProcAddress(ghPenWinDLL,(LPSTR)szProc);

	 LoadString(ghInst,IDS_TPTODP,(LPSTR)szProc,MSG_NORMAL);
	 lpfnTPtoDP=(LPFNTPTODP)GetProcAddress(ghPenWinDLL,(LPSTR)szProc);

	 LoadString(ghInst,IDS_INITRC,(LPSTR)szProc,MSG_NORMAL);
	 lpfnInitRC=(LPFNINITRC)GetProcAddress(ghPenWinDLL,(LPSTR)szProc);

	 LoadString(ghInst,IDS_DUPLICATEPENDATA,(LPSTR)szProc,MSG_NORMAL);
	 lpfnDuplicatePenData=(LPFNDUPLICATEPENDATA)GetProcAddress(ghPenWinDLL,(LPSTR)szProc);

	 LoadString(ghInst,IDS_REDISPLAYPENDATA,(LPSTR)szProc,MSG_NORMAL);
	 lpfnRedisplayPenData=(LPFNREDISPLAYPENDATA)GetProcAddress(ghPenWinDLL,(LPSTR)szProc);

	 LoadString(ghInst,IDS_DPTOTP,(LPSTR)szProc,MSG_NORMAL);
	 lpfnDPtoTP=(LPFNDPTOTP)GetProcAddress(ghPenWinDLL,(LPSTR)szProc);

	 LoadString(ghInst,IDS_OFFSETPENDATA,(LPSTR)szProc,MSG_NORMAL);
	 lpfnOffsetPenData=(LPFNOFFSETPENDATA)GetProcAddress(ghPenWinDLL,(LPSTR)szProc);

	 if(lpfnRecognize && lpfnInitRC && lpfnDuplicatePenData &&
	    lpfnTPtoDP && lpfnRedisplayPenData && lpfnOffsetPenData &&
	    lpfnDPtoTP)
	    bRet=TRUE;
      }
   }

   if(!bRet)
      ErrorBox(IDS_NOPENWIN);

   return bRet;
}

//**************************************************************************
//
//  Function: ErrorBox(WORD)
//
//  Purpose:  To display Error Messages
//
//  Returns:  void
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      12/20/91	David Flenniken  Created
//
//*************************************************************************
void FAR PASCAL ErrorBox(WORD wID)
{
   char szTitle[MSG_NORMAL];
   char szMsg[MSG_LONG];

   LoadString(ghInst,wID,      (LPSTR)szMsg,  MSG_LONG);
   LoadString(ghInst,IDS_TITLE,(LPSTR)szTitle,MSG_NORMAL);
   MessageBox(GetFocus(),
	      (LPSTR)szMsg,
	      (LPSTR)szTitle,
	      MB_ICONEXCLAMATION | MB_OK);
}



/* END OF FILE */
