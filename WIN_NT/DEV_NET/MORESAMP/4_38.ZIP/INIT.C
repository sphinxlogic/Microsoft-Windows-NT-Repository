#define WIN31
#include "windows.h"
#include "penwin.h"
#include "globals.h"
#include "init.h"



//**************************************************************************
//
//  Function: WinMain
//
//  Purpose:  Entry point for program
//
//  Returns:
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      12/20/91	David Flenniken  Created
//
//*************************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

int PASCAL WinMain(HANDLE hInstance, HANDLE hPrevInstance,
		   LPSTR lpCmdLine, int nCmdShow)
{
    MSG msg;

    if (!hPrevInstance)
        if (!InitApplication(hInstance))
            return (FALSE);

    if (!InitInstance(hInstance, nCmdShow))
        return (FALSE);

    while (GetMessage(&msg, NULL, NULL, NULL))
        {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
        }

    return (msg.wParam);
}

//**************************************************************************
//
//  Function: InitApplication(HANDLE)
//
//  Purpose:  Register application class
//
//  Returns:  TRUE/FALSE
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      12/20/91	David Flenniken  Created
//
//*************************************************************************
BOOL InitApplication(HANDLE hInstance)
{
    WNDCLASS  wc;
    char szClass[MSG_SHORT];
    char szMenu[MSG_SHORT];

    LoadString(hInstance,IDS_CLASS,(LPSTR)szClass,MSG_SHORT);
    LoadString(hInstance,IDS_MENU,(LPSTR)szMenu,MSG_SHORT);

    wc.style          = NULL;
    wc.lpfnWndProc    = MainWndProc;
    wc.cbClsExtra     = 0;
    wc.cbWndExtra     = 0;
    wc.hInstance      = hInstance;
    wc.hIcon	      = LoadIcon(hInstance, MAKEINTRESOURCE(ID_ICON));
    wc.hCursor	      = LoadCursor(NULL, IDC_PEN);
    wc.hbrBackground  = GetStockObject(WHITE_BRUSH);
    wc.lpszMenuName   = (LPSTR)szMenu;
    wc.lpszClassName  = (LPSTR)szClass;

    return (RegisterClass(&wc));
}


//**************************************************************************
//
//  Function: InitInstance(HANDLE, int)
//
//  Purpose:  Create the window for the application
//
//  Returns:
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      12/20/91	David Flenniken  Created
//
//*************************************************************************
BOOL InitInstance(HANDLE hInstance, int nCmdShow)
{
    char szClass[MSG_SHORT];
    char szTitle[MSG_NORMAL];

    LoadString(hInstance,IDS_CLASS,(LPSTR)szClass,MSG_SHORT);
    LoadString(hInstance,IDS_TITLE,(LPSTR)szTitle,MSG_NORMAL);

    ghInst = hInstance;

    ghwnd = CreateWindow(
	     (LPSTR)szClass,
	     (LPSTR)szTitle,
             WS_OVERLAPPEDWINDOW,
             CW_USEDEFAULT,
             CW_USEDEFAULT,
             CW_USEDEFAULT,
             CW_USEDEFAULT,
             NULL,
             NULL,
             hInstance,
             NULL );

    if ( !ghwnd )
        return ( FALSE );

    ShowWindow(ghwnd, nCmdShow);
    UpdateWindow(ghwnd);
    return (TRUE);
}
