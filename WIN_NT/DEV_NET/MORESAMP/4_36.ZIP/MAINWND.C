//****************************************************************************
// File: mainwnd.c
//
// Purpose: Main overlapped window's message handler
//
// Functions:
//    MainWndProc() - message handler for main overlapped window
//    DoCommands() - called by MainWndProc to handle all WM_COMMAND messages
//
// Development Team:
//
//
// Written by Microsoft Product Support Services, Windows Developer Support
//****************************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <windows.h>
#include <penwin.h>
#include "global.h"
#include "about.h"
#include "mainwnd.h"

// Local function prototypes.
long DoCommands (HWND hWnd,
                 unsigned message,
                 WORD wParam,
                 LONG lParam);
void ProcessLButtonDown(HANDLE, unsigned, WORD, LONG);

//****************************************************************************
// Function: MainWndProc
//
// Purpose: Message handler for main overlapped window.
//
// Parameters:
//    hWnd    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           1/27/92                  Created
//****************************************************************************

long FAR PASCAL MainWndProc (HWND hWnd,
			     UINT message,
			     WPARAM wParam,
			     LPARAM lParam)
{
   switch (message)
   {
      // Pen Processing Time!
      case WM_LBUTTONDOWN:
         ProcessLButtonDown(hWnd, message, wParam, lParam);
         break;


      // Dispatch WM_COMMAND messages to our command handler, DoCommands().
      case WM_COMMAND:
         return DoCommands(hWnd, message, wParam, lParam);


      // On WM_DESTROY, terminate this app by posting a WM_QUIT message.

      case WM_DESTROY:
         PostQuitMessage(0);
         break;


      // We didn't handle, pass to DefWindowProc.

      default:
         return DefWindowProc(hWnd, message, wParam, lParam);
   }


   return (NULL);
}

//****************************************************************************
// Function: DoCommands
//
// Purpose: Called by MainWndProc() to handle all WM_COMMAND messages.
//
// Parameters:
//    hWnd    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns : Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           1/27/92                  Created
//****************************************************************************

long DoCommands (HWND hWnd,
                 unsigned message,
                 WORD wParam,
                 LONG lParam)
{
   switch (wParam)
   {

      case IDM_MENU1:
      {
         FARPROC lpDlgProc;

         lpDlgProc = MakeProcInstance(PenDlg, ghInst);

         DialogBox(ghInst,             // current instance
                   PenBoxName,         // resource to use
                   hWnd,               // parent handle   
                   lpDlgProc);         // About() instance address

         FreeProcInstance(lpDlgProc);
         break;
      }



      // Put up the About box.
      case IDM_ABOUT:
      {
         FARPROC lpDlgProc;

         lpDlgProc = MakeProcInstance(AboutDlg, ghInst);

         DialogBox(ghInst,             // current instance
                   AboutBoxName,       // resource to use 
                   hWnd,               // parent handle   
                   lpDlgProc);         // About() instance address

         FreeProcInstance(lpDlgProc);
         break;
      }


      // User picked File.Exit, terminate this app.

      case IDM_EXIT:
         DestroyWindow(hWnd);
         break;


      // Must be some system command -- pass it on to the default
      //  window procedure.

      default:
         return DefWindowProc(hWnd, message, wParam, lParam);
   }

   return (NULL);
}

//*************************************************************
//
//  ProcessLButtonDown()
//
//  Purpose:
//       Called when a WM_LBUTTONDOWN message is received.
//
//
//  Parameters:
//
//
//      
//
//  Return: (void)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//              1/30/92    Eric Flo   Created
//
//*************************************************************


void ProcessLButtonDown(HANDLE hWnd, unsigned message, WORD wParam, LONG lParam)
{
  RC  rc;


  if (IsPenEvent(message, GetMessageExtraInfo()))
    {
    InitRC (ghWnd, &rc);

    rc.rglpdf[0] = NULL;

    Recognize (&rc);
    }

}
