//****************************************************************************
// File: dynbedit.c
//
// Purpose: Contains main message loop and application entry point
//
// Functions:
//    WinMain() - initializes everything and enters message loop
//
// Development Team:
//
//
// Written by Microsoft Product Support Services, Windows Developer Support
//****************************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <windows.h>
#include <penwin.h>
#include "global.h"
#include "init.h"
#include "dynbedit.h"

// Local function prototypes.
int PASCAL WinMain (HANDLE, HANDLE, LPSTR, int);
BOOL (FAR PASCAL *SetAppRecogHook)(WORD, WORD, HWND);

//***********************************************************************
// Function: WinMain
//
// Purpose: Called by Windows on app startup.  Initializes everything,
//          and enters a message loop.
//
// Parameters:
//    hInstance     == Handle to _this_ instance.
//    hPrevInstance == Handle to last instance of app.
//    lpCmdLine     == Command Line passed into app.
//    nCmdShow      == How app should come up (i.e. minimized/normal)
//
// Returns: Return value from PostQuitMessage.
//
// Comments:
//
// History:  Date       Author        Reason
//           1/27/92                  Created
//****************************************************************************

int PASCAL WinMain (HANDLE hInstance,  // This instance
                    HANDLE hPrevInstance,                  // Last instance
                    LPSTR lpCmdLine,   // Command Line
                    int nCmdShow)      // Minimized or Normal?
{
   MSG msg;
   HANDLE hPenWin;
   VOID (FAR PASCAL *RegisterPenApp)(UINT,BOOL) = NULL;

   if (!hPrevInstance)
      if (!InitApplication(hInstance))
         return (FALSE);

   // Register app for pen windows (if possible)

   bPenWin = FALSE;

   if ((hPenWin = GetSystemMetrics (SM_PENWINDOWS)) != NULL)
      {
      if ((RegisterPenApp =(LPREGISTERPENAPP) GetProcAddress (hPenWin, "RegisterPenApp")) != NULL)
        {
        (*RegisterPenApp)(RPA_DEFAULT, TRUE);
        bPenWin = TRUE;
        }
      }


   if (!InitInstance(hInstance, nCmdShow))
      return (FALSE);

   while (GetMessage(&msg,             // Put Message Here
                     NULL,             // Handle of window receiving msg
                     NULL,             // lowest message to examine
                     NULL))            // highest message to examine
   {
      TranslateMessage(&msg);          // Translates virtual key codes
      DispatchMessage(&msg);           // Dispatches message to window
   }

   // Unregister this app from penwin.dll
   if (RegisterPenApp != NULL)
       (*RegisterPenApp)(RPA_DEFAULT, FALSE);

   return (msg.wParam);                // Returns the value from PostQuitMessage
}
