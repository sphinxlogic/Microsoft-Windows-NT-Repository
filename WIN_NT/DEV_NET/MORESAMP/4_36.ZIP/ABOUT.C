//****************************************************************************
// File: about.c
//
// Purpose : Called by DoCommands() when want About dialog box.
//
// Functions:
//    AboutDlg() - dialog function for about box
//
// Development Team:
//
//
// Written by Microsoft Product Support Services, Windows Developer Support
//****************************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <windows.h>
#include <penwin.h>
#include "about.h"
#include "global.h"

//****************************************************************************
// Function: AboutDlg
//
// Purpose: Called by DoCommands() when want About dialog box.
//
// Parameters:
//    hDlg    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           1/27/92                  Created
//****************************************************************************

BOOL FAR PASCAL AboutDlg (HWND hDlg,
                          unsigned message,
                          WORD wParam,
                          LONG lParam)
{
   switch (message)
   {
      case WM_INITDIALOG:
         return (TRUE);

      case WM_COMMAND:
         if ((wParam == IDOK) ||       // "OK" box selected?        
             (wParam == IDCANCEL))     // System menu close command?
         {
            EndDialog(hDlg, TRUE);     // Exits the dialog box 
            return (TRUE);
         }
         break;
   }

   return (FALSE); // Didn't process a message
}

//****************************************************************************
// Function: PenDlg
//
// Purpose: Called by DoCommands() when want Pen dialog box.
//
// Parameters:
//    hDlg    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           2/4/92     Eric Flo      Created
//****************************************************************************

BOOL FAR PASCAL PenDlg (HWND hDlg,
                          unsigned message,
                          WORD wParam,
                          LONG lParam)
{
   switch (message)
   {
      case WM_INITDIALOG:
         {
         HWND  hEdit, hBEdit;
         char  szBuffer[32];
         RECT  DlgRect, EditRect;
         RECT  rect;
         RC    rc;
         int   NewcyBox;

         // Check to see if Pen Windows is running
         if (!bPenWin)
            return (TRUE);


         // Query the handle to the edit control, the text in the
         // edit control, and the dimensions.

         hEdit = GetDlgItem (hDlg, IDD_BEDIT);
         GetDlgItemText (hDlg, IDD_BEDIT,(LPSTR) szBuffer, sizeof (szBuffer));
         GetWindowRect (hDlg, &DlgRect);
         GetWindowRect (hEdit,&EditRect);
         GetClientRect (hEdit, &rect);

         // Destroy the original edit control
         DestroyWindow (hEdit);


         // Create the new bedit control
         hBEdit = CreateWindow ((LPSTR)"bedit",
                                (LPSTR) szBuffer,
                                ES_AUTOHSCROLL | WS_TABSTOP | WS_BORDER | WS_CHILD | WS_VISIBLE,
                               (EditRect.left - DlgRect.left),
                               (EditRect.top - DlgRect.top),
                               (rect.right - rect.left),
                               (rect.bottom - rect.top),
                                hDlg,
                                IDD_BEDIT,
                                ghInst,
                                NULL);

         if (hBEdit == NULL)
            return (FALSE);


         // Get the RC structure in order to the GUIDE structure.
         SendMessage (hBEdit, WM_HEDITCTL, HE_GETRC, (long)(LPRC) &rc);

         rc.guide.xOrigin = EditRect.left;
         rc.guide.yOrigin = EditRect.top;


         // New cyBox value  (height of one box)
         NewcyBox = (rect.bottom - rect.top);


         // Calc new cxBox value by changing window ratio
         rc.guide.cxBox   = NewcyBox * rc.guide.cxBox / rc.guide.cyBox;


         // Calc the new cyBase (distance from top of box to baseline)
         rc.guide.cyBase  = NewcyBox * rc.guide.cyBase / rc.guide.cyBox;


         // Set new cyBox value
         rc.guide.cyBox   = NewcyBox;


         // Calculate the number of cells that can fit in the bedit control.
         rc.guide.cHorzBox = (rect.right - rect.left) / rc.guide.cxBox;


         // replace the RC structure.
         SendMessage (hBEdit, WM_HEDITCTL, HE_SETRC, (long)(LPRC) &rc);

         }
         return (TRUE);

      case WM_COMMAND:
         if ((wParam == IDOK) ||       // "OK" box selected?        
             (wParam == IDCANCEL))     // System menu close command?
         {
            EndDialog(hDlg, TRUE);     // Exits the dialog box 
            return (TRUE);
         }
         break;
   }

   return (FALSE); // Didn't process a message
}
