/****************************************************************************
Sample App Parser.  A Windows for Pen sample that demonstrates
walking the SYG and SYC arrays to gather character by character ink
information, rather than stroke by stroke.  


Created by: Cynthia Anderson, MS Windows Developer Support
Date:  September, 1992
Completed:  October, 1992; modified from View sample

Generic sample base from Windows SDK 3.1 guide samples.
Convert.c from pen samples.

    PROGRAM: Generic.c

    PURPOSE: Generic template for Windows applications

    FUNCTIONS:

        WinMain() - calls initialization function, processes message loop
        InitApplication() - initializes window data and registers window
        InitInstance() - saves instance handle and creates main window
        MainWndProc() - processes messages
        About() - processes messages for "About" dialog box

    COMMENTS:

        Windows can have several copies of your application running at the
        same time.  The variable hInst keeps track of which instance this
        application is so that processing will be to the correct window.

****************************************************************************/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "windows.h"                /* required for all Windows applications */
#include <penwin.h>
#include "convert.h"                /* for Syv to Char/Gesture conversion */
#include "parser.h"                /* specific to this program              */

HANDLE hInst;                       /* current instance                      */

//pen
static char szSyvBuff[2048];
static char szSyeBuff[2048];
static CHARMAP charmap[MAXCHARMAP+1];  

HPENDATA ghPenData = NULL;
POINT Offset;
BOOL gbDisplay = AsStroke;
BOOL gbReady = TRUE;
HDC ghDC;
int gX, gY;

TIMERPROC lpfnMyTimerProc;
BOOL gbProcessing = FALSE; //initialize for DoSlowDraw proc.


/****************************************************************************

    FUNCTION: WinMain(HANDLE, HANDLE, LPSTR, int)

    PURPOSE: calls initialization function, processes message loop

    COMMENTS:

        Windows recognizes this function by name as the initial entry point 
        for the program.  This function calls the application initialization 
        routine, if no other instance of the program is running, and always 
        calls the instance initialization routine.  It then executes a message 
        retrieval and dispatch loop that is the top-level control structure 
        for the remainder of execution.  The loop is terminated when a WM_QUIT 
        message is received, at which time this function exits the application 
        instance by returning the value passed by PostQuitMessage(). 

        If this function must abort before entering the message loop, it 
        returns the conventional value NULL.  

****************************************************************************/

int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HANDLE hInstance;                            /* current instance             */
HANDLE hPrevInstance;                        /* previous instance            */
LPSTR lpCmdLine;                             /* command line                 */
int nCmdShow;                                /* show-window type (open/icon) */
{
    MSG msg;                                 /* message                      */

    if (!hPrevInstance)                  /* Other instances of app running? */
        if (!InitApplication(hInstance)) /* Initialize shared things */
            return (FALSE);              /* Exits if unable to initialize     */

    /* Perform initializations that apply to a specific instance */

    if (!InitInstance(hInstance, nCmdShow))
        return (FALSE);

    /* Acquire and dispatch messages until a WM_QUIT message is received. */

    while (GetMessage(&msg,        /* message structure                      */
            NULL,                  /* handle of window receiving the message */
            NULL,                  /* lowest message to examine              */
            NULL))                 /* highest message to examine             */
        {
        TranslateMessage(&msg);    /* Translates virtual key codes           */
        DispatchMessage(&msg);     /* Dispatches message to window           */
    }
    return (msg.wParam);           /* Returns the value from PostQuitMessage */
}


/****************************************************************************

    FUNCTION: InitApplication(HANDLE)

    PURPOSE: Initializes window data and registers window class

    COMMENTS:

        This function is called at initialization time only if no other 
        instances of the application are running.  This function performs 
        initialization tasks that can be done once for any number of running 
        instances.  

        In this case, we initialize a window class by filling out a data 
        structure of type WNDCLASS and calling the Windows RegisterClass() 
        function.  Since all instances of this application use the same window 
        class, we only need to do this when the first instance is initialized.  


****************************************************************************/

BOOL InitApplication(hInstance)
HANDLE hInstance;                              /* current instance           */
{
    WNDCLASS  wc;

    /* Fill in window class structure with parameters that describe the       */
    /* main window.                                                           */

    wc.style = NULL;                    /* Class style(s).                    */
    wc.lpfnWndProc = (WNDPROC)MainWndProc;       /* Function to retrieve messages for  */
                                        /* windows of this class.             */
    wc.cbClsExtra = 0;                  /* No per-class extra data.           */
    wc.cbWndExtra = 0;                  /* No per-window extra data.          */
    wc.hInstance = hInstance;           /* Application that owns the class.   */
    wc.hIcon = LoadIcon(hInstance, "PARSER");
    wc.hCursor = LoadCursor(NULL, IDC_PEN);      //pen cursor!
    wc.hbrBackground = GetStockObject(WHITE_BRUSH); 
    wc.lpszMenuName =  "GenericMenu";   /* Name of menu resource in .RC file. */
    wc.lpszClassName = "GenericWClass"; /* Name used in call to CreateWindow. */

    /* Register the window class and return success/failure code. */

    return (RegisterClass(&wc));

}


/****************************************************************************

    FUNCTION:  InitInstance(HANDLE, int)

    PURPOSE:  Saves instance handle and creates main window

    COMMENTS:

        This function is called at initialization time for every instance of 
        this application.  This function performs initialization tasks that 
        cannot be shared by multiple instances.  

        In this case, we save the instance handle in a static variable and 
        create and display the main program window.  
        
****************************************************************************/

BOOL InitInstance(hInstance, nCmdShow)
    HANDLE          hInstance;          /* Current instance identifier.       */
    int             nCmdShow;           /* Param for first ShowWindow() call. */
{
    HWND            hWnd;               /* Main window handle.                */

    /* Save the instance handle in static variable, which will be used in  */
    /* many subsequence calls from this application to Windows.            */

    hInst = hInstance;

    /* Create a main window for this application instance.  */

    hWnd = CreateWindow(
        "GenericWClass",                /* See RegisterClass() call.          */
        "Parsing Ink Sample Application",   /* Text for window title bar.         */
        WS_OVERLAPPEDWINDOW,            /* Window style.                      */
        CW_USEDEFAULT,                  /* Default horizontal position.       */
        CW_USEDEFAULT,                  /* Default vertical position.         */
        CW_USEDEFAULT,                  /* Default width.                     */
        CW_USEDEFAULT,                  /* Default height.                    */
        NULL,                           /* Overlapped windows have no parent. */
        NULL,                           /* Use the window class menu.         */
        hInstance,                      /* This instance owns this window.    */
        NULL                            /* Pointer not needed.                */
    );

    /* If window could not be created, return "failure" */

    if (!hWnd)
        return (FALSE);

    /* Make the window visible; update its client area; and return "success" */

    ShowWindow(hWnd, nCmdShow);  /* Show the window                        */
    UpdateWindow(hWnd);          /* Sends WM_PAINT message                 */
    return (TRUE);               /* Returns the value from PostQuitMessage */

}


/****************************************************************************

    FUNCTION: MainWndProc(HWND, unsigned, WORD, LONG)

    PURPOSE:  Processes messages

    MESSAGES:

        WM_COMMAND    - application menu (About dialog box)
        WM_DESTROY    - destroy window

    COMMENTS:

        To process the IDM_ABOUT message, call MakeProcInstance() to get the
        current instance address of the About() function.  Then call Dialog
        box which will create the box according to the information in your
        view.rc file and turn control over to the About() function.  When
        it returns, free the intance address.

****************************************************************************/

long FAR PASCAL MainWndProc(hWnd, message, wParam, lParam)
HWND hWnd;                                /* window handle                   */
unsigned message;                         /* type of message                 */
WORD wParam;                              /* additional information          */
LONG lParam;                              /* additional information          */
{
    FARPROC lpProcAbout;                  /* pointer to the "About" function */
    RC          rc;
    PAINTSTRUCT ps;
    HDC         hDC;
    POINT       Pos;  
    
    switch (message) {
        case WM_CREATE:
          {
          int i;
          
          for (i=0; i<MAXCHARMAP; i++)
            {
            charmap[i].bData = FALSE;
            charmap[i].szChar[0] = ' ';
            charmap[i].rect.top = charmap[i].rect.bottom= 0;
            charmap[i].rect.left = charmap[i].rect.right = 0;
            }
            
          }
        break;
        
        case WM_COMMAND:           /* message: command from application menu */
            switch (wParam)
            {
             case IDM_ABOUT:
              {
                lpProcAbout = MakeProcInstance(About, hInst);

                DialogBox(hInst,                 /* current instance         */
                    "AboutBox",                  /* resource to use          */
                    hWnd,                        /* parent handle            */
                    lpProcAbout);                /* About() instance address */

                FreeProcInstance(lpProcAbout);
                break;
              }
              
             case IDM_STROKE:
                {
                gbDisplay = AsStroke;
                InvalidateRect(hWnd,NULL,TRUE);
                }
                break;
              
             case IDM_SLOWDRAW:
                {
                gbDisplay = AsSlowDraw;
                DoSlowDraw(hWnd);
                }
                break;
                
             case IDM_TEXT:
                {
                gbDisplay = AsText;
                InvalidateRect(hWnd,NULL,TRUE);
                }
                break;
                    
             default:                 /* Lets Windows process it       */
                return (DefWindowProc(hWnd, message, wParam, lParam));
             } //end of switch on wParam for WM_COMMAND case
            break; 
             
        case WM_LBUTTONDOWN:
           if (IsPenEvent(message, GetMessageExtraInfo()))
              {
              //destroy old pen data if present
              if (ghPenData){
                 DestroyPenData(ghPenData);
                 ghPenData = NULL;
                 }
              
              //initialize RC structure
              InitRC(hWnd, &rc);
              rc.wRcPreferences=RCP_MAPCHAR;
              //Begin recognition
              Recognize(&rc);
              }
           break;
        
        case WM_RCRESULT:
           {
           LPRCRESULT lprcresult = (LPRCRESULT)lParam;
           POINT clientpt;
           
           if (lprcresult == NULL){
              MessageBox(NULL,"lparam=NULL","WM_RCRESULT",MB_OK);
              return FALSE;
              }
           
           // save pen data block
           ghPenData = DuplicatePenData(lprcresult->hpendata, GMEM_MOVEABLE);
           
           //convert pen data block to DISPLAY coordinates
           //I could just convert and offset my copied hpendata,
           //but I wanted to show that you can modify the hpendata
           //associated with RCRESULT structure and use it.  MyConver
           //will directly use this hpendata rather than the globally
           //saved (duplicated) hpendata.

           MetricScalePenData(ghPenData, PDTS_DISPLAY);
           MetricScalePenData(lprcresult->hpendata, PDTS_DISPLAY);
           
           //offset data relative to the client origin
           clientpt.x = clientpt.y = 0;
           ClientToScreen(hWnd, &clientpt);
           OffsetPenData(ghPenData, -clientpt.x, -clientpt.y);
           OffsetPenData(lprcresult->hpendata, -clientpt.x, -clientpt.y);
           
           //get best guess.
           SyvToStr(lprcresult->lpsyv, lprcresult->cSyv, szSyvBuff, sizeof(szSyvBuff)-1,FALSE);
           
           //Convert the symbol graph into ANSI string
           SyvToStr(lprcresult->syg.lpsye, lprcresult->syg.cSye, szSyeBuff, sizeof(szSyeBuff)-1, TRUE);  //true, since this is a symbol graph

           MyConvert(lprcresult, (LPCHARMAP)&charmap, (int)sizeof(charmap));
           
           //paint it!
           InvalidateRect(hWnd,NULL,TRUE);
           } 
           break;  
        
        case WM_MOVE:
           {
           InvalidateRect(hWnd,NULL,TRUE);
           }
           break;   
                        
        case WM_PAINT:
           {
           PENDATAHEADER PenDataHeader;           
           PENINFO PenInfo;
           DWORD dwReserved;
           LPPENDATA lpPenData = NULL;
           HFONT hFont, hOldFont;
           COLORREF crefOld;
           POINT Ht, pt;
           int i;
           
           hDC = BeginPaint(hWnd,&ps);
           
           pt.x = pt.y = 0;
           ClientToScreen(hWnd,&pt);
           if (ghPenData){
           GetPenDataInfo(ghPenData,
                         (LPPENDATAHEADER)&PenDataHeader,
                         (LPPENINFO) &PenInfo,
                         dwReserved);
           switch(gbDisplay)
           {
           
           case AsSlowDraw:
           {
           if (IsWindowEnabled)
              PostMessage(hWnd,WM_COMMAND,IDM_SLOWDRAW, NULL);
           }
           break;
           
           case AsStroke:
           {
               
           if (ghPenData)
              RedisplayPenData(hDC, ghPenData, NULL,NULL,5,RGB(250,0,150));
           } //end case AsStroke
           break;
           
           case AsText:
           {
           //show the graph in upper left hand corner of screen
           TextOut(hDC, 10,10,szSyeBuff,_fstrlen(szSyeBuff));
           Ht.x = 0;
           i = 0;
           //create a font the same size as the ink (per character)
           while (charmap[i].bData) {
              Ht.y = charmap[i].rect.bottom-charmap[i].rect.top;  //first character
              hFont = CreateFont(-Ht.y,
                                 0,0,0,0,0,0,0,ANSI_CHARSET,
                                 OUT_TT_PRECIS, CLIP_TT_ALWAYS,
                                 DRAFT_QUALITY,
                                 FF_DONTCARE|VARIABLE_PITCH,
                                 "Arial");
                                 
              hOldFont = SelectObject(hDC,hFont);
                 
                 //ink is now saved in DISPLAY coordinates & offset
                 //relative to client window, so we don't need to
                 //do any conversions from screen to client, etc.
                 //we're already relative to client now...
                 
                 Pos.y = charmap[i].rect.top; 
                 Pos.x = charmap[i].rect.left; 
                 
              crefOld = SetTextColor(hDC, RGB((150+10*i)%255,i%255,(50+5*i)%255) );   
              SetBkMode(hDC,TRANSPARENT);
              TextOut(hDC,Pos.x,Pos.y,charmap[i].szChar, 1);
              SetTextColor(hDC,crefOld);
              
              SelectObject(hDC, hOldFont);
              DeleteObject(hFont);
              
              i++;
              if (i >= MAXCHARMAP) 
               break;  //over the limit!
               
              } //end of while charmap[i].bData == TRUE
              
           
           }//end case AsText
           break;
           
           } //end switch gbDisplay
           
           } // no ghPenData 
           
           EndPaint(hWnd,&ps);
           
           }
           break;
        
        case WM_DESTROY:                  /* message: window being destroyed */
            {
            PostQuitMessage(0);
            }
            break;

        default:                          /* Passes it on if unproccessed    */
            return (DefWindowProc(hWnd, message, wParam, lParam));
    }
    return (NULL);
}


/*************************************************************************
        FUNCTION:  DoSlowDraw   
        PURPOSE:  Drawing routines for drawing ink slowly..no WM_PAINT
        COMMENTS:  Need to use a timer, so don't want to try this in 
                   a WM_PAINT case...re-entrancy problems
*************************************************************************/
BOOL FAR PASCAL DoSlowDraw(HWND hWnd)
{
PENDATAHEADER PenDataHeader;           
PENINFO PenInfo;
DWORD dwReserved;
LPPENDATA lpPenData = NULL;
COLORREF crefBkgd = RGB(255,255,255);   //initialize to white
LPPOINT lpStrokePts, lpStrokeBeg, lpStrokeEnd;
HGLOBAL hMem;
LPPOINT lpPnt;
STROKEINFO si;
int strokeNum = 0;
int i;
BOOL bSuccess;
HDC hDC;
MSG msg;   // lets us pull messages via PeekMessage
RECT crect;
HBRUSH hBkBrush;
     
     //are we already here..re-entrancy again
     if (gbProcessing)
       return FALSE;
     
     gbProcessing = TRUE;   //start processing of data
                       
     hDC = GetDC(hWnd);
     EnableWindow(hWnd, FALSE);
     
     //wipe out any old ink on the client area..we don't use InvalidateRect
     //because in WM_PAINT we post a message that ends up calling this routine
     //and if we did use InvalidateRect, we'd end up re-entrant.
     
     GetClientRect(hWnd,&crect);
     crefBkgd = GetBkColor(hDC);
     hBkBrush = CreateSolidBrush(crefBkgd);
     FillRect(hDC, &crect, hBkBrush);
                      
           if (ghPenData){
           GetPenDataInfo(ghPenData,
                         (LPPENDATAHEADER)&PenDataHeader,
                         (LPPENINFO) &PenInfo,
                         dwReserved);
           
             
           lpfnMyTimerProc = (TIMERPROC) MakeProcInstance((FARPROC)MyTimerProc, hInst);
           
           SetTimer(hWnd, ID_MYTIMER, 100, lpfnMyTimerProc);

              if (ghPenData)
                {
                hMem = GlobalAlloc(GHND,(sizeof(POINT)*(PenDataHeader.cPntStrokeMax+1)));
                if (hMem)
                  {
                  lpStrokeBeg = (LPPOINT)GlobalLock(hMem);
                  }
                 
                  
                for (i=0; i < (int)(PenDataHeader.cStrokes); i++)
                 {
                   //for each stroke
                  lpPenData = BeginEnumStrokes(ghPenData);
                  if (!lpPenData)  //couldn't lock pen data ..failure..
                    return FALSE;                                       
           
           
                  GetPenDataStroke(lpPenData, strokeNum,
                                   &lpPnt,NULL,
                                   (LPSTROKEINFO) &si);
           
                  bSuccess = GetPointsFromPenData(ghPenData, strokeNum,
                                                  0,si.cPnt-1,lpStrokeBeg);
                  
                  lpStrokePts = lpStrokeBeg;                                
                  lpStrokeEnd = lpStrokeBeg + si.cPnt-1;
                                                   
                  EndEnumStrokes(ghPenData);
                  lpPenData = NULL; //invalidate far pointer to "now" unlocked data

                   if (bSuccess)
                   {                                
                     //get the first point in the structure
                     MoveTo(hDC,lpStrokeBeg->x,lpStrokeBeg->y);
                     lpStrokePts++; //next point
                     
                     while (lpStrokePts < lpStrokeEnd)
                     {
                     //Loop through all the other points
                     gbReady = FALSE;
                     LineTo(hDC,lpStrokePts->x,lpStrokePts->y);
                     
                     while (!gbReady)  //wait for next timer message
                      {
                       // clear out message queue (process any waiting messages)
                       if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
                         {
                           //if (msg == WM_PAINT)
                           TranslateMessage(&msg);
                           DispatchMessage(&msg);
                         }
                      }
                     
                     
                     lpStrokePts++;
                     } // end lineto
                     
                   }//end bSuccess
                   
                strokeNum++;
                   
                } //end each stroke loop
                
                if (hMem)
                   {
                   GlobalUnlock(hMem);
                   GlobalFree(hMem);
                   } //end hMem unlock/free
                   
                } //ghPenData
                
           KillTimer(hWnd, ID_MYTIMER);
           FreeProcInstance(lpfnMyTimerProc);
           }

     ReleaseDC(hWnd, hDC);
     gbProcessing = FALSE;
     EnableWindow(hWnd, TRUE);
     
return TRUE;
}                   


/*************************************************************************
    FUNCTION: 
    PURPOSE:  Timer Callback for Slow Drawing Mode
    COMMENTS:
    
***************************************************************************/
void CALLBACK MyTimerProc(HWND hwnd, UINT msg, UINT idTimer, DWORD dwTime)
{
     if (idTimer == ID_MYTIMER)
     {
     gbReady = TRUE;
     }
 return;
}   

/****************************************************************************

    FUNCTION: About(HWND, unsigned, WORD, LONG)

    PURPOSE:  Processes messages for "About" dialog box

    MESSAGES:

        WM_INITDIALOG - initialize dialog box
        WM_COMMAND    - Input received

    COMMENTS:

        No initialization is needed for this particular dialog box, but TRUE
        must be returned to Windows.

        Wait for user to click on "Ok" button, then close the dialog box.

****************************************************************************/

BOOL FAR PASCAL About(hDlg, message, wParam, lParam)
HWND hDlg;                                /* window handle of the dialog box */
unsigned message;                         /* type of message                 */
WORD wParam;                              /* message-specific information    */
LONG lParam;
{
    switch (message) {
        case WM_INITDIALOG:                /* message: initialize dialog box */
            return (TRUE);

        case WM_COMMAND:                      /* message: received a command */
            if (wParam == IDOK                /* "OK" box selected?          */
                || wParam == IDCANCEL) {      /* System menu close command? */
                EndDialog(hDlg, TRUE);        /* Exits the dialog box        */
                return (TRUE);
            }
            break;
    }
    return (FALSE);                           /* Didn't process a message    */
}
