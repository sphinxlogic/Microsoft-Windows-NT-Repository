// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <string.h>
#include "convert.h"

VOID PASCAL SyvToStr(LPVOID lpData, int cItem, LPSTR lpstr, int cMax, BOOL fSye)
/*******************************************************************************

FUNCTION:       SyvToStr(lpData, cItem, lpstr, cMax, fSye)

PURPOSE:                Converts from SYV to form to ANSI in order to display

COMMENTS:
                                Converts meta symbols SYV_BEGINOR, SYV_ENDOR and SYV_OR
                                to '{', '}' and '|' respectively.
                                Also converts gestures to strings

*******************************************************************************/
        {
        int i, j, cLen;
        SYV syvT;
        char buff[33];

        for(i=j=0; i< cItem; ++i)
                {
                syvT = (fSye)?((LPSYE)lpData)[i].syv : ((LPSYV)lpData)[i];

                cLen = 1;
                switch(syvT)
                        {
                case SYV_BEGINOR:
                        lpstr[j] = '{';
                        break;
                case SYV_ENDOR:
                        lpstr[j] = '}';
                        break;
                case SYV_OR:
                        lpstr[j] = '|';
                        break;
                case SYV_EMPTY:
                        lpstr[j] = '_';
                        break;
                case SYV_SPACENULL:
                        cLen = 0;
                        break;
                case SYV_SOFTNEWLINE:
                        lpstr[j] = ANSI_PARA_MARK;      // paragraph mark
                        break;

                default:
                        //If this is a gesture
                        if(FIsGesture(syvT))
                                {
                                //Convert to string
                                cLen = IGestureString(syvT, buff, sizeof(buff)-1);

                                //And append it to the output buffer.
                                if(cLen)
                                        {
                                        cLen = ((cLen + j) < cMax)?cLen:(cMax-j-1);
                                        if(cLen>0)
                                                _fstrncpy(&lpstr[j], buff, cLen);
                                        }       
                                }
                        //This could just be a SYV for an ANSI character
                        else if(!SymbolToCharacter(&syvT, 1, &lpstr[j], NULL))
                                lpstr[j] = '?';
                        
                        if (lpstr[j] == '\0')
                                cLen = 0;
                        else if (lpstr[j] == ANSI_NEW_LINE)     // New Line
                                lpstr[j] = ANSI_PARA_MARK; // paragraph mark
                        }
                j += cLen;
                }
                lpstr[j] = '\0';
        }


int PASCAL IGestureString(SYV syvGes, LPSTR lpstr, int cMac)
/*****************************************************************************

FUNCTION:       IGestureString(syvGes, lpstr, cMac)

PURPOSE:                Convert the SYV for a gesture to a corresponding string

COMMENTS:

                the rgGestures table above maps the SYVs to the corresponding strings

*****************************************************************************/
        {
        int i, cLen=0;
        BOOL    fFound = FALSE;

        // If this a Circled letter gesture
        if (FIsAppGesture(syvGes))
                {
        // Form a string with "circle -"  prefix

                _fstrncpy(lpstr, szCircleG, sizeof(szCircleG));
                if (syvGes >= SYV_CIRCLEUPA && syvGes <= SYV_CIRCLEUPZ)
                        lpstr[sizeof(szCircleG) - 1] = (BYTE)LOWORD(syvGes - SYV_CIRCLEUPA + 'A');
                else 
                        lpstr[sizeof(szCircleG) - 1] = (BYTE)LOWORD(syvGes - SYV_CIRCLELOA + 'a');
                lpstr[sizeof(szCircleG)] = '\0';
                cLen = sizeof(szCircleG);
                }
        else
                {
        //Must be a command gesture, look in the table
                for(i=0; i<(sizeof(rgGestures)/sizeof(SYVID)); ++i)
                        {
                        if(syvGes == rgGestures[i].syv)
                                {
                                cLen = _fstrlen(rgGestures[i].lpstr);
                                cLen = min(cLen, cMac);
                                _fstrncpy(lpstr, rgGestures[i].lpstr, cLen);
                                fFound = TRUE;
                                break;
                                }
                        }

                }
        return(cLen);
        }


VOID PASCAL MyConvert(LPRCRESULT lprcresult, LPCHARMAP lpCharMap, int cMax)
/*******************************************************************************

FUNCTION:       MyConvert(lpRCresult, lpCharMap, cMax)

PURPOSE:                Walks a symbol graph and returns char/rect struct

COMMENTS:
                                Converts meta symbols SYV_BEGINOR, SYV_ENDOR and SYV_OR
                                to '{', '}' and '|' respectively.
                                Also converts gestures to strings

*******************************************************************************/
        {
        int i, ii;
        SYV syvT;
        BOOL fBeg = TRUE;
        int cItem, cCharMap;
        LPSYE lpmysye;
        LPSYC lpmysyc;
        int iSyc;
        LPCHARMAP lpmycharmap;
        HPENDATA hpendata;
        PENDATAHEADER pendatahdr, newpendatahdr;
        UINT wPdtScale, wStroke;
        STROKEINFO si;
        LPSTROKEINFO lpsiNew;
        LPPENDATA lppendata;
        HPENDATA hNewPenData;
        LPPOINT lpPoint;
        UINT wPntFirst, wPntLast;
        int iNext, iTotal ;
        BOOL bSycContinue =TRUE;
        HGLOBAL hData;
        LPPOINT lpNew;
        BOOL bCharMapGone = FALSE;          
        
        lpsiNew = (LPSTROKEINFO) &si;
        cItem = lprcresult->syg.cSye;
        lpmysye = lprcresult->syg.lpsye;   //SYE array in symbol graph
        lpmysyc = lprcresult->syg.lpsyc;   //SYC array in symbol graph
        lpmycharmap = lpCharMap;
        hpendata= lprcresult->hpendata;
        
        //re-initialize charmap structures
        for (i=0; i<MAXCHARMAP; i++)
         if (lpmycharmap[i].bData)
           {
           lpmycharmap[i].szChar[0] = ' ';  //set to space character
           lpmycharmap[i].bData = FALSE;
           }
           
        lpmycharmap = lpCharMap;  //reset to beginning of lpCharMap structure-array
        cCharMap = 0;
        
        for (i=0; i <cItem; i++)
                {
                //do we have any charmap structures left open in array?
                if (bCharMapGone) //last charmap, we're done
                     break;
                   
                syvT = lpmysye->syv ;    //current symbol value
                iSyc = lpmysye->iSyc;    //current index into SYC array for SYV value
                
                switch(syvT)
                {
                  case SYV_BEGINOR:
                        fBeg = TRUE;
                        break;
                  case SYV_ENDOR:
                        fBeg = TRUE;
                        break;
                  case SYV_OR:
                        fBeg = FALSE;
                        break;
                  case SYV_EMPTY:
                        break;
                  case SYV_SPACENULL:
                        break;
                  case SYV_SOFTNEWLINE:
                        break;

                  default:
                  {//check to see if it is an alphanumeric character
                  
                  if (fBeg)
                  {
                  if (!(FIsGesture(syvT)))
                    if (!SymbolToCharacter(&syvT,1,lpmycharmap->szChar,NULL))
                      lpmycharmap->szChar[0] = '?';
                    
                   
                  //get rectangle size of ink from hpendata for that character
                  //create a new hpendata only with the appropriate strokes needed
                  //and then use the Pendataheader.rectbound information for
                  //the  rectangle values.
                  
                  GetPenDataInfo(hpendata,&pendatahdr,NULL,0L);
                  if (pendatahdr.wPndts & PDTS_ARBITRARY)
                    wPdtScale = PDTS_ARBITRARY;
                  else if (pendatahdr.wPndts & PDTS_DISPLAY)
                    wPdtScale = PDTS_DISPLAY;
                  else if (pendatahdr.wPndts & PDTS_HIENGLISH)
                    wPdtScale = PDTS_HIENGLISH;
                  else if (pendatahdr.wPndts & PDTS_HIMETRIC)
                    wPdtScale = PDTS_HIMETRIC;
                  else if (pendatahdr.wPndts & PDTS_LOMETRIC)
                    wPdtScale = PDTS_LOMETRIC;
                  else if (pendatahdr.wPndts & PDTS_STANDARDSCALE)                    
                    wPdtScale = PDTS_STANDARDSCALE;
                    
                  
                  
                  lppendata = BeginEnumStrokes(hpendata);
                  
                  hNewPenData = CreatePenData(NULL,-1,wPdtScale,GMEM_DDESHARE);
                  //wPdtScale comes from RC in RCRESULT (tablet/display)
                  
                  //loop thru all strokes in this character
                  //get info from SYC value for SYE(syv)
                  
                  
                  bSycContinue = TRUE;
                  iNext = 0;
                  
                  while (bSycContinue) {
                  
                  if (iSyc == iSycNull)
                    break;  //out of loop, no ink is present for this character
                  

                  iTotal = (lpmysyc+iSyc+iNext)->wStrokeLast - (lpmysyc+iSyc+iNext)->wStrokeFirst;
                  
                  for (ii=0; ii<= iTotal; ii++)
                    {
                    wStroke = ((lpmysyc+iSyc+iNext)->wStrokeFirst)+ii;
                    GetPenDataStroke(lppendata,wStroke,(LPPOINT FAR *)&lpPoint,NULL,lpsiNew);
                    
                    if ((lpmysyc+iSyc+iNext)->wPntFirst == wPntAll)
                      {
                      AddPointsPenData(hNewPenData,lpPoint,NULL,lpsiNew);
                      }
                    else
                      { //create lppoint subset from lpPoint
                       wPntFirst = (lpmysyc+iSyc+iNext)->wPntFirst;
                       wPntLast = (lpmysyc+iSyc+iNext)->wPntLast;
                       hData = GlobalAlloc(GHND,(sizeof(POINT)*(wPntLast-wPntFirst+1)) );
                       lpNew = (LPPOINT)GlobalLock(hData);
                       //mem copy from lpPoint to lpNew here
                       _fmemcpy(lpNew,lpPoint,(sizeof(POINT)*(wPntLast-wPntFirst+1)));
                      
                       //need to change lpsi to reflect partial points used for stroke
                       AddPointsPenData(hNewPenData, (LPPOINT)lpNew,NULL,lpsiNew);
                       //release memory used
                       GlobalUnlock(hData);
                       GlobalFree(hData);
                      }     
                      
                    }
                  //check to see if more Syc's follow for this SYE
                  if ((lpmysyc+iSyc+iNext)->fLastSyc == TRUE)  //all done
                    bSycContinue = FALSE;
                  else
                    iNext++;
                    //do next SYC  
                  } //end bSycContinue while loop
                    
                  //end of loop, unlock hpendata structure
                  EndEnumStrokes(hpendata);
                  
                  //assign bounding rect
                  GetPenDataInfo(hNewPenData,&newpendatahdr,NULL,0L);
                  
                  if (iSyc != iSycNull)  //we have ink so we have a rect
                    {
                    lpmycharmap->rect.top = newpendatahdr.rectBound.top;
                    lpmycharmap->rect.left = newpendatahdr.rectBound.left;
                    lpmycharmap->rect.bottom = newpendatahdr.rectBound.bottom;
                    lpmycharmap->rect.right = newpendatahdr.rectBound.right;
                    }
                  
                  lpmycharmap->bData = TRUE;
                  cCharMap++;
                    
                  DestroyPenData(hNewPenData);      //Destroy is a macro that just calls GlobalFree on the handle
                                                    //Warning level 3 complains about a mismatch here, but
                                                    //that's because GlobalFree expects an HGLOBAL not
                                                    //an HPENDATA...nothing to worry about, only irritating.
                  
// want to avoid potential memory trashing here....
      
                  if (cCharMap < MAXCHARMAP) 
                    lpmycharmap++;
                  else          //last charmap, we're done
                    bCharMapGone = TRUE;
                    
                  
                  
                  } //end fBeg if stmt
                  }  //end default case
                  
                       
                }  //end switch stmt
                
                lpmysye++; //next element please!
        }   //end of for loop

        } //end of procedure


