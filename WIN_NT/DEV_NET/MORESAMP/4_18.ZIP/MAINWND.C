//****************************************************************************
// File: mainwnd.c
//
// Purpose: Main overlapped window's message handler
//
// Functions:
//    MainWndProc() - message handler for main overlapped window
//    DoCommands() - called by MainWndProc to handle all WM_COMMAND messages
//
// Development Team: Paul Stafford (Original Author)
//                   Krishna Nareddy (Modified sample to confirm to new coding
//                                    standards )
//
//
// Written by Microsoft Product Support Services, Windows Developer Support
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//****************************************************************************

#include <windows.h>
#include <stdlib.h>
#include "global.h"
#include "dlgprocs.h"
#include "mainwnd.h"

//****************************************************************************
// Function: MainWndProc
//
// Purpose: Message handler for main overlapped window.
//
// Parameters:
//    hWnd    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Messages:
//     WM_CREATE  - Initialize menu checkmarks, inititalize hWndMain
//     WM_DESTROY - PostQuitMessage()
//     WM_SIZE    - update cxClient and cyClient
//
// Comments:
//
// History:  Date       Author        Reason
//           ???        Paul Stafford Created
//           3/5/92     Krishna       Modified to confirm to new coding stds
//****************************************************************************

long FAR PASCAL MainWndProc (HWND hWnd,
                             unsigned message,
                             WORD wParam,
                             LONG lParam)
{
   switch (message)
   {
      // Dispatch WM_COMMAND messages to our command handler, DoCommands().
      case WM_COMMAND:
         return DoCommands(hWnd, message, wParam, lParam);

      case WM_CREATE:
      // Init the various variables that direct the quantity of work done
      // in the background at each time
         lAtATime = STARTINGBATCH;
         nOldCheckBatch = STARTINGCHECKEDBATCH;
         CheckMenuItem(GetMenu(hWnd), nOldCheckBatch, MF_BYCOMMAND | MF_CHECKED);

         lTotalRects = STARTINGTOTAL;
         nOldCheckTotal = STARTINGCHECKEDTOTAL;
         CheckMenuItem(GetMenu(hWnd), nOldCheckTotal, MF_BYCOMMAND | MF_CHECKED);

         ghWnd = hWnd;
         break;

      case WM_DESTROY:
         PostQuitMessage(0);
         break;

      case WM_SIZE:
         gcxClient = LOWORD(lParam);
         gcyClient = HIWORD(lParam);
         break;

      default:
         return (DefWindowProc(hWnd, message, wParam, lParam));
   }

   return (NULL);
}

//****************************************************************************
// Function: DrawTotalRectangles
//
// Purpose: Contains the PeekMessage loop that implements background
//          processing.  In this sample the background processing consists
//          of repeatedly calling DrawAFewRects to draw batches of random
//          rectangles.
//
// Parameters: hWnd - window in which to draw rectangles
//             lToDraw - total number of rectangles to draw,
//                       so this is the size of background job
//             lDrawAtATime - batch size - number of rects to draw each time
//                            through the PeekMessage loop, so this is the
//                            batch size
//
// Returns: None
//
// Comments: 
//   The PeekMessage loop allows us to do our rectangle drawing
//   "in the background." If other apps have messages, Windows
//   will give those apps control. If no apps have messages,
//   PeekMessage will return FALSE and we draw a little bit.
//   If another app is also in a PeekMessage loop we will get
//   time round-robin with them.
//
//   Note that PM_REMOVE must be specified as the final (wRemoveMsg)
//   parameter to PeekMessage(). If it weren't, PeekMessage() would
//   not pull the messages from the queue, therefore our queue would
//   always have messages, PeekMessage would never return FALSE,
//   and we would never get a chance to do background work. Not
//   to mention that we would never yield, because PeekMessage(),
//   like GetMessage() and even Yield(), does not actually yield
//   to other applications unless our queue is empty (actually,
//   there is a slight wrinkle here - WM_PAINT and WM_TIMER messages
//   are considered to be low priority, so we could yield if we
//   only had these two types of messages in the queue).
//
//   Again, the interesting thing here is that changing the
//   "batch size" (the amount of background work we do each time
//   through the PeekMessage loop) can make us either:
//
//     -  an impolite Windows app that gets the background job
//        done quickly, but nobody else can run (if we set
//        the batch size big)
//
//     -  a polite app that just uses "spare" slices of time, gives
//        other apps plenty of shots at the processor, but gets
//        the background job done more slowly because of increased
//        overhead (if we set the batch size small)
//
//   We use IsDialogMessage() so that we can pull the
//   messages for the "cancel" modeless dialog box. We are using a
//   modeless dialog box instead of a modal dialog because a modal
//   dialog would enter into its own message loop and control from
//   the modal dialog will be returned only when it is terminated.
//   Using a modal dialog, therefore, will not give a chance for 
//   the PeekMessage loop to retrieve messages.
//
//   We loop until either
//
//      1. all lToDraw rectangles have been drawn
//
//      2. gbCancel becomes TRUE, which will happen if the user
//         chooses the "Cancel" button in the dialog box. There may
//         be a slight delay from the time the cancel button is hit to
//         the time the computation is actually cancelled. This is 
//         because the application cannot poll the value of gbCancel
//         until it completes the current chunk of computation.
//
//   Also, we send a private message (PM_UPDATESTATUS) to the
//   the dialog whenever "nPercentDrawn", the percentage of the
//   rectangles that have been drawn so far, changes.
//   This lets the dialog provide its "gas gauge" indication of how
//   far the background processing has progressed.
//
//
// History:  Date       Author        Reason
//           ???        Paul Stafford Created
//           3/5/92     Krishna       Modified to confirm to new coding stds
//****************************************************************************

void DrawTotalRectangles (HWND hWnd, long lToDraw, long lDrawAtATime)
{
   FARPROC lpfnCancelDlgProc;     // pointer to the instance thunk for the 
   // dialog procedure for the "Cancel" modeless dialog
   MSG msg;   // lets us pull messages via PeekMessage
   long lDrawn = 0;     // number of rects drawn so far
   int nPercentDrawn = 0;    // percentage of rectangles drawn so far
   int nTemp; // used to calculate/update nPercentDrawn

   // The gbCancel global variable is used to communicate with
   // the modeless dialog box. If the user hits the CANCEL button
   // the dialog sets gbCancel to TRUE, and if our PeekMessage loop
   // hits gbCancel==TRUE we drop out of the loop

   gbCancel = FALSE;

   // launch modeless dialog box that will let the user cancel the
   // rectangle drawing before all of the rectangles are drawn

   lpfnCancelDlgProc = MakeProcInstance(CancelDlgProc, ghInst);
   ghCancelDlg = CreateDialogParam(ghInst, "CancelDlg", hWnd,
                                   lpfnCancelDlgProc,
                                   MAKELONG((int)lToDraw,(int)lDrawAtATime));

   // Here is the important part. This could also be a for loop.
   // While we have background processing to do...
   while ((!gbCancel) && (lDrawn < lToDraw))
   {
      // clear out message queue (process any waiting messages)
      if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
      {
         if ((!ghCancelDlg) || !IsDialogMessage(ghCancelDlg, &msg))
         {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
         }
      }
      else
      {
         // when queue is empty, do a small piece of background processing
         lDrawn = lDrawn + DrawAFewRects(hWnd, min((int)(lToDraw - lDrawn),
                                                   (int)lDrawAtATime));

         // if necessary, update nPercentDrawn and let the cancel dialog
         // know that it has changed
         nTemp = (int)(lDrawn * 100 / lToDraw);
         if (nTemp > nPercentDrawn)
         {
            nPercentDrawn = nTemp;
            SendMessage(ghCancelDlg, PM_UPDATESTATUS, nPercentDrawn, 0L);
         }
      }
   }

   // if we fell out of the loop because we have drawn
   // all of the rectangles, rather than because the dialog
   // was cancelled, we must send the dialog a message to
   // cancel itself
   if ((lDrawn == lToDraw) && !gbCancel)
      SendMessage(ghCancelDlg, WM_COMMAND, IDCANCEL, 0L);

   //clean up proc instance
   FreeProcInstance(lpfnCancelDlgProc);

   // From here, we return to main GetMessage loop, allowing the system
   // to go idle. If we had replaced the main GetMessage loop with our
   // PeekMessage loop, we would have to call WaitMessage here to allow
   // the system to go idle.
}

//****************************************************************************
// Function: DrawAFewRects
//
// Purpose:  Draws one batch of random rectangles.
//
// ARGUMENTS:
//    hWnd   - window to draw in
//    nCount - number of rects to draw
//
// Returns:  long NEAR - number of rects drawn.
//
// Comments: 
//    All of the rectangles in a batch are drawn the same color.
//
//
// History:  Date       Author        Reason
//           ???        Paul Stafford Created
//           3/5/92     Krishna       Modified to confirm to new coding stds
//****************************************************************************

long NEAR PASCAL DrawAFewRects (HWND hWnd, int nCount)
{
   HBRUSH hBrush;
   HDC hdc;
   short xLeft, xRight, yTop, yBottom, nRed, nGreen, nBlue;
   int i;

   // randomly choose a color

   nRed = rand() & 255;
   nGreen = rand() & 255;
   nBlue = rand() & 255;

   hdc = GetDC(hWnd);
   hBrush = CreateSolidBrush(RGB(nRed, nGreen, nBlue));
   SelectObject(hdc, hBrush);

   for (i = 0; i < nCount; i++)
   {
      // Randomly generate the bounds of a rectangle
      xLeft = rand() % gcxClient;
      xRight = rand() % gcxClient;
      yTop = rand() % gcyClient;
      yBottom = rand() % gcyClient;

      Rectangle(hdc, min(xLeft, xRight), min(yTop, yBottom),
                max(xLeft, xRight), max(yTop, yBottom));
   }
   ReleaseDC(hWnd, hdc);
   DeleteObject(hBrush);

   return (long)nCount;
}


//****************************************************************************
// Function: DoCommands
//
// Purpose: Called by MainWndProc() to handle all WM_COMMAND messages.
//
// Parameters:
//    hWnd    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns : Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           1/27/92                  Created
//****************************************************************************

long DoCommands (HWND hWnd,
                 unsigned message,
                 WORD wParam,
                 LONG lParam)
{
   FARPROC lpDlgProc;

   // bUpdateCheckTotal and bUpdateCheckBatch are flags that are
   // set if the Rectangles/Total or Rectangles/At a Time menu checks
   // need to be updated 
   BOOL bUpdateCheckTotal = FALSE, bUpdateCheckBatch = FALSE;

   switch (wParam)
   {
      // Put up the About box.
      case IDM_ABOUT:
         lpDlgProc = MakeProcInstance(AboutDlg, ghInst);

         DialogBox(ghInst,   // current instance
                   (LPSTR)"AboutBox",  // resource to use 
                   hWnd,     // parent handle   
                   lpDlgProc);    // About() instance address

         FreeProcInstance(lpDlgProc);
         break;

      case IDM_DRAW:
      // the PeekMessage loop for background processing
      // is in the DrawTotalRectangles routine
         DrawTotalRectangles(hWnd, lTotalRects, lAtATime);
         InvalidateRect(hWnd, NULL, TRUE);
         UpdateWindow(hWnd);
         break;

      // choices from Rectangles/Total menu..

      case IDM_TOTAL500:
         lTotalRects = 500;
         bUpdateCheckTotal = TRUE;
         break;

      case IDM_TOTAL1000:
         lTotalRects = 1000;
         bUpdateCheckTotal = TRUE;
         break;

      case IDM_TOTAL2000:
         lTotalRects = 2000;
         bUpdateCheckTotal = TRUE;
         break;

      case IDM_TOTAL5000:
         lTotalRects = 5000;
         bUpdateCheckTotal = TRUE;
         break;

      case IDM_TOTAL10000:
         lTotalRects = 10000;
         bUpdateCheckTotal = TRUE;
         break;

      // choices from Rectangles/At a Time menu..

      case IDM_BATCH1:
         lAtATime = 1;
         bUpdateCheckBatch = TRUE;
         break;

      case IDM_BATCH10:
         lAtATime = 10;
         bUpdateCheckBatch = TRUE;
         break;

      case IDM_BATCH50:
         lAtATime = 50;
         bUpdateCheckBatch = TRUE;
         break;

      case IDM_BATCH100:
         lAtATime = 100;
         bUpdateCheckBatch = TRUE;
         break;

      case IDM_BATCH500:
         lAtATime = 500;
         bUpdateCheckBatch = TRUE;
         break;

      case IDM_BATCH1000:
         lAtATime = 1000;
         bUpdateCheckBatch = TRUE;
         break;

      // User picked File.Exit so post WM_CLOSE, causing the default
      // window procedure to call DestroyWindow(). We could process
      // WM_CLOSE for confirmation from user that we should exit.           

      case IDM_EXIT:
         PostMessage(hWnd, WM_CLOSE, 0, 0L);
         break;

      default:
         return (DefWindowProc(hWnd, message, wParam, lParam));
   }

   if (bUpdateCheckTotal)
   // update check on Rectangles/Total menu, if necessary
   {
      CheckMenuItem(GetMenu(hWnd), nOldCheckTotal, MF_BYCOMMAND | MF_UNCHECKED);
      nOldCheckTotal = wParam;
      CheckMenuItem(GetMenu(hWnd), nOldCheckTotal, MF_BYCOMMAND | MF_CHECKED);
   }

   if (bUpdateCheckBatch)
   {
      // update check on Rectangles/At a Time menu, if necessary
      CheckMenuItem(GetMenu(hWnd), nOldCheckBatch, MF_BYCOMMAND | MF_UNCHECKED);
      nOldCheckBatch = wParam;
      CheckMenuItem(GetMenu(hWnd), nOldCheckBatch, MF_BYCOMMAND | MF_CHECKED);
   }
   return (NULL);
}
