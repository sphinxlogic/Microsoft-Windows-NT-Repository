//****************************************************************************
// File: about.c
//
// Purpose : Called by DoCommands() when want About dialog box.
//
// Functions:
//    AboutDlg() - dialog function for about box
//
// Development Team: Paul Stafford (Original Author)
//                   Krishna Nareddy (Modified sample to confirm to new coding
//                                    standards )
//
//
// Written by Microsoft Product Support Services, Windows Developer Support
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//****************************************************************************

#include <windows.h>
#include "dlgprocs.h"
#include "global.h"

//****************************************************************************
// Function: AboutDlg
//
// Purpose: Called by DoCommands() when want About dialog box.
//
// Parameters:
//    hDlg    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           1/27/92                  Created
//****************************************************************************

BOOL FAR PASCAL AboutDlg (HWND hDlg,
                          unsigned message,
                          WORD wParam,
                          LONG lParam)
{
   switch (message)
   {
      case WM_INITDIALOG:
         return (TRUE);

      case WM_COMMAND:
         if ((wParam == IDOK) ||  // "OK" box selected?        
             (wParam == IDCANCEL))     // System menu close command?
         {
            EndDialog(hDlg, TRUE);     // Exits the dialog box 
            return (TRUE);
         }
         break;
   }

   return (FALSE); // Didn't process a message
}

//****************************************************************************
// Function: CancelDlg
//
// Purpose: Dialog procedure for the modeless dialog. Two main purposes are:
// 
//      1. if the user chooses CANCEL we set gbCancel to TRUE,
//         which will end the PeekMessage background processing loop
//
//      2. handle the private PM_UPDATESTATUS message and draw
//         a "gas gauge" indication of how far the background job
//         has progressed
//
// Parameters:
//    hDlg    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Messages:
//      WM_COMMAND      - handle IDCANCEL by setting gbCancel to TRUE
//                        and calling DestroyWindow to end the dialog
//
//      WM_INITDIALOG   - set control text, get coordinates of gas gauge,
//                        disable main window so we look modal
//
//      WM_PAINT        - draw the "gas gauge" control
//
//      PM_UPDATESTATUS - the percentage done has changed, so update
//                        nPercentDrawn and force a repaint
//
//  Comments:
//
//    This dialog disables the app's main window upon entry and reenables
//    it upon exit, so that it looks like a modal dialog box.
//
//    The gbCancel global variable is used to communicate
//    with the main window. If the user chooses to cancel
//    we set gbCancel to TRUE and DrawTotalRectangles() will
//    then fall out of the PeekMessage() loop.
//
//    When we get the private message PM_UPDATESTATUS
//    we update the "gas gauge" control that indicates
//    what percentage of the rectangles have been drawn
//    so far. This shows that we can draw in the dialog
//    as the looping operation progresses.
//
//    The only other point is that in the WM_INITDIALOG case we set the
//    focus to the "Cancel" button so that the user can cancel
//    from the keyboard. Then we return FALSE, which is
//    wierd but is documented in the SDK Reference
//    (return FALSE from the WM_INITDIALOG case when you
//    have explicitly set the focus to one of the dialog
//    controls)
//
// History:  Date       Author        Reason
//           ???        Paul Stafford Created
//           3/5/92     Krishna       Modified to confirm to new coding stds
//****************************************************************************

BOOL FAR PASCAL PASCAL CancelDlgProc (HWND hDlg,
                                      unsigned message,
                                      WORD wParam,
                                      LONG lParam)
{
   static int inPercentDrawn;     // percent drawn so far
   static RECT rectGG;  // GasGauge rectangle

   switch (message)
   {
      case WM_COMMAND:
         if (IDCANCEL == wParam)
         {
            EnableWindow(ghWnd, TRUE); // Enable top-level window to
            // allow menu selections.
            gbCancel = TRUE;
            DestroyWindow(hDlg);
            ghCancelDlg = NULL;
            return TRUE;
         }
         else
            return TRUE;

      case WM_INITDIALOG:
      {
         char szBuffer[80];

         // set static text.
         // example: "Drawing 2000 Rectangles, 10 At a Time"
         //
         // We were called via CreateDialogParam, so at this point
         // LOWORD(lParam) is the total number to draw,
         // HIWORD(lParam) is the batch size

         wsprintf((LPSTR)szBuffer,
                  (LPSTR)"Drawing %d Rectangles, %d At a Time",
                  LOWORD(lParam), HIWORD(lParam));

         SetDlgItemText(hDlg, IDD_MYTEXT, (LPSTR)szBuffer);

         // Get the coordinates of the gas gauge static control rectangle,
         // and convert them to dialog client area coordinates
         GetClientRect(GetDlgItem(hDlg, IDD_GASGAUGE), &rectGG);
         ClientToScreen(GetDlgItem(hDlg, IDD_GASGAUGE), (LPPOINT)&rectGG.left);
         ClientToScreen(GetDlgItem(hDlg, IDD_GASGAUGE), (LPPOINT)&rectGG.right);
         ScreenToClient(hDlg, (LPPOINT)&rectGG.left);
         ScreenToClient(hDlg, (LPPOINT)&rectGG.right);

         inPercentDrawn = 0;
         EnableWindow(ghWnd, FALSE);
         EnableMenuItem(GetSystemMenu(hDlg, FALSE), SC_CLOSE, MF_GRAYED);
         SetFocus(GetDlgItem(hDlg, IDCANCEL));

         return (FALSE);     // because we set the focus
      }

      case WM_PAINT:
      {
         HDC hDC;
         PAINTSTRUCT ps;
         char szBuffer[5];
         DWORD dwExtent;
         int ixText, iyText;
         int inDivideRects;
         RECT rectDone, rectLeftToDo;

         // The gas gauge is drawn by drawing a text string stating
         // what percentage of the job is done into the middle of
         // the gas gauge rectangle, and by separating that rectangle
         // into two parts: rectDone (the left part, filled in blue)
         // and rectLeftToDo(the right part, filled in white).
         // inDivideRects is the x coordinate that divides these two rects.
         //
         // The text in the blue rectangle is drawn white, and vice versa
         // This is easy to do with ExtTextOut()!

         hDC = BeginPaint(hDlg, &ps);

         wsprintf((LPSTR)szBuffer, "%3d%%", inPercentDrawn);
         dwExtent = GetTextExtent(hDC, (LPSTR)szBuffer, lstrlen(szBuffer));
         ixText = rectGG.left
                  + ((rectGG.right - rectGG.left) - LOWORD(dwExtent)) / 2;
         iyText = rectGG.top
                  + ((rectGG.bottom - rectGG.top) - HIWORD(dwExtent)) / 2;

         inDivideRects = ((rectGG.right - rectGG.left) * inPercentDrawn) / 100;

         // Paint in the "done so far" rectangle of the gas
         // gauge with blue background and white text
         SetRect(&rectDone, rectGG.left, rectGG.top,
                 rectGG.left + inDivideRects, rectGG.bottom);
         SetTextColor(hDC, RGB(255, 255, 255));
         SetBkColor(hDC, RGB(0, 0, 255));

         ExtTextOut(hDC, ixText, iyText, ETO_CLIPPED | ETO_OPAQUE,
                    &rectDone, (LPSTR)szBuffer, lstrlen(szBuffer), NULL);

         // Paint in the "still left to do" rectangle of the gas
         // gauge with white background and blue text
         SetRect(&rectLeftToDo, rectGG.left + inDivideRects, rectGG.top,
                 rectGG.right, rectGG.bottom);
         SetTextColor(hDC, RGB(0, 0, 255));
         SetBkColor(hDC, RGB(255, 255, 255));

         ExtTextOut(hDC, ixText, iyText, ETO_CLIPPED | ETO_OPAQUE,
                    &rectLeftToDo, (LPSTR)szBuffer, lstrlen(szBuffer), NULL);

         EndPaint(hDlg, &ps);

         return TRUE;
      }

      case PM_UPDATESTATUS:
         inPercentDrawn = wParam;
         InvalidateRect(hDlg, &rectGG, TRUE);    // Force repaint
         UpdateWindow(hDlg);
         return TRUE;

      default:
         return FALSE;
   }
}
