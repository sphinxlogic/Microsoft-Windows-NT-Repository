//----------------------------------------------------------------------
// File name: about.c                            Creation date: 921009 
//
// Abstract:  The source file for displaying the aboutbox dialog for
//            the ShowGrp sample.  See showgrp.c for information on 
//            the Windows Group File format.
//
// Provides the following functions:
//
//   BOOL FAR PASCAL About() - Dialog function for about box dialog.
//
// Development Team: bts
//
// Written by Microsoft Product Support Services, Windows Developer Support.
//
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//----------------------------------------------------------------------
#include <windows.h>

#include "about.h"

//----------------------------------------------------------------------
//     Function:  BOOL FAR PASCAL About
//
//   Parameters:  HWND hDlg   -  Handle to dialog window
//                WORD wMsg   -  Message value
//                WORD wParam -  WORD parameter
//                LONG lParam -  LONG parameter
// 
//      Purpose:  About box dialog procedure
//
// Return Value:  BOOL indicating success or failure
//--------------------------------------------------------------------
BOOL FAR PASCAL About(HWND hDlg, WORD wMsg, WORD wParam, LONG lParam)
{
  switch (wMsg)
	  {
    case WM_INITDIALOG:
      return (TRUE);

    case WM_COMMAND:    
		  switch(wParam)
			  {
        // Look for okay and cancel to quit the dialog
    		case IDOK:
			  case IDCANCEL:
				  EndDialog(hDlg, TRUE);
				  return TRUE;

			  default:
				  break;
  			}
		  break;

	  default:
		  break;
	  }
  return FALSE;
}


