//----------------------------------------------------------------------
// File name: winmain.c                            Creation date: 921009 
//
// Abstract:  Contains the window portions of the ShowGrp.  This
//            includes WinMain and the Windows procedure.  See the 
//            ShowGrp.c source file a more complete explanation of
//            how ShowGrp gets the group files, the items from the
//            group file, and the item's icon.
//
// Provides the following functions:
//
//    int PASCAL WinMain() - entry point for Windows program.
//    long FAR PASCAL MainWndProc() - Window procedure for the sample
//
// Development Team: bts
//
// Written by Microsoft Product Support Services, Windows Developer Support.
//
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//----------------------------------------------------------------------

#include <Windows.H>
#include <stdlib.h>

#include "global.h"                   // Local header files
#include "winmain.h"                  
#include "init.h"                     // You can use the name of these
#include "showgrp.h"                  // header files to figure out what
#include "about.h"                    // source files, this one is calling
                                      // into.

//----------------------------------------------------------------------
//     Function:  int PASCAL WinMain
//
//   Parameters:  HANDLE hInstance - Handle to this instance
//                HANDLE hPrevInstance - Handle to prev instance, if one
//                LPSTR  lpCmdLine - Command line
//                int    nCmdShow - value to ShowWindow
// 
//      Purpose:  Main entry point into win app
//--------------------------------------------------------------------
int PASCAL WinMain(HANDLE hInstance,
                   HANDLE hPrevInstance,
                   LPSTR  lpCmdLine,
                   int    nCmdShow)
{
  MSG msg;

  // Register the Window class and take care of any application
  // intitialization that needs to be done.

  if (!InitApplication (hInstance, hPrevInstance))
    return FALSE;

  // Create the Window and show it.  Take care of any instance
  // initialization that needs to be done.

  if (!InitInstance (hInstance, nCmdShow))
    return FALSE;

  // Main message loop.  Keeps going until GetMessage returns
  // a NULL.  GetMessage when WM_QUIT is received.

  while (GetMessage(&msg,NULL,NULL,NULL))              
    {
    TranslateMessage(&msg);   
    DispatchMessage(&msg);    
    }

  return (msg.wParam);          
}

//----------------------------------------------------------------------
//     Function:  long FAR PASCAL MainWndProc
//
//   Parameters:  HWND hWnd   - Window handle
//                WORD wMsg   - Message value
//                WORD wParam - WORD parameter
//                LONG lParam - LONG parameter
// 
//      Purpose:  Main window procedure.  Handles messages which come
//                into the application.  The important message that
//                comes into this function is the WM_COMMAND message
//                with the wParam == IDL_PMGROUP and the high word of
//                the lParam == LBN_DBLCLICK.  This means that the user
//                has double clicked on one of the items in the opening 
//                list box.
//--------------------------------------------------------------------
long FAR PASCAL MainWndProc(HWND hWnd,
                            WORD wMsg,
                            WORD wParam,
                            LONG lParam)
{
  FARPROC       lpProcAbout;          // Pointer to my about dlg proc
  FARPROC       lpProcPMItems;        // Pointer to my PM items dlg proc
  WORD          wIndex;               // For index of selected item in lbox
                                      // To hold path to group file
  char          lpszFileName [_MAX_FNAME];   
  WORD          i;                    
  char          szUserMsg [BUFSIZE];  // For holding messages to user
  static  HWND  hWndList;             // Handle to group list box window
  HGLOBAL       ghMemGroupFileData;   // Handle to global memory which
                                      // holds the group file data.

  switch (wMsg)
    {
    case WM_CREATE:

      // Create the list box and then initialize it with the group 
      // file information.

      hWndList = ListGroupInfo (hWnd);
      break;

    case WM_SIZE:

      // Be sure to show the list box window.
      MoveWindow (hWndList, 0, 0, LOWORD (lParam), HIWORD (lParam), TRUE);
      break;

    case WM_SETFOCUS:

      // Upon receiving this message, throw the focus to the list box
      SetFocus (hWndList);
      break;

    case WM_SYSCOMMAND:
	    switch (wParam)
		    {
        case SC_MINIMIZE:

          // When the window is minimized, show just the application
          // name: ShowGroup.  

          SendMessage (hWnd, WM_SETTEXT, 0, (LONG) (LPSTR) gszAppName);
          InvalidateRect (hWnd, NULL, TRUE);
          break;

        case SC_MAXIMIZE:
        case SC_RESTORE:

          // When the window is maximized, show the application name
          // along with the double click instruction.

          SendMessage (hWnd, WM_SETTEXT, 0, (LONG) (LPSTR) gszDblClickAppName);
          InvalidateRect (hWnd, NULL, TRUE);
          break;

        default:
          return (DefWindowProc(hWnd, wMsg, wParam, lParam));
        }
      break;

    case WM_COMMAND:       
	    switch (wParam)
		    {
		    case IDM_ABOUT:

          // Do the about dialog
          lpProcAbout = MakeProcInstance(About, ghInst);
          DialogBox(ghInst, "AboutBox", hWnd, lpProcAbout);              
          FreeProcInstance(lpProcAbout);
          break;

        case IDL_PMGROUP:

          // *************************************************************
          // The user double clicked on the group list box.  The strategy
          // here is to figure out what item the user has clicked on via
          // the list box notification.
          // *************************************************************

          if (HIWORD (lParam) == LBN_DBLCLK)
            {

            // *************************************************************
            // Make sure they haven't clicked on the headers - that is the
            // first item in the list box (0 based index).
            // *************************************************************

            if ((wIndex = (WORD) SendMessage (hWndList, LB_GETCURSEL, 0, 0L)) != 0)
              {

              // ******************************************************
              // Get the file name - it is the first thing in the list
              // box string.  Delineated by the first string.
              // ******************************************************

              SendMessage (hWndList,
                           LB_GETTEXT,
                           wIndex, (LONG) (LPSTR) lpszFileName);
              i = 0;
              while (lpszFileName [i++] != ' ');
              lpszFileName [i] = NULL;

              // Read in the entire group file 
              if (!ReadGroupFile ((LPSTR) lpszFileName, &ghMemGroupFileData))
                {
                // Check for errors reading the group file
                LoadString (ghInst, IDS_GFREADERR, szUserMsg, BUFSIZE);
                MessageBox (hWnd,
                            (LPSTR) szUserMsg,
                            (LPSTR) gszAppName,
                            MB_ICONSTOP);
                }

              else                    
                {
                //  *****************************************************
                //  Okay, so we've read in the group file and made sure
                //  the global lpGroupFileData points to a copy of the
                //  bytes in the file.  Now we have to show the items 
                //  in the group in the PM item dialog.
                //  *****************************************************

                lpProcPMItems = MakeProcInstance (PMItemsDlg, ghInst);
                DialogBox (ghInst, "PMItems", hWnd, lpProcPMItems);
                FreeProcInstance (lpProcPMItems);

                // Let go of the memory allocated in ReadGroupFile
                if (GlobalUnlock (ghMemGroupFileData))
                  GlobalFree (ghMemGroupFileData);
                }
              }
            }
          break;

        default:
          return (DefWindowProc(hWnd, wMsg, wParam, lParam));
		    }
	    break;

    case WM_DESTROY:                 
      PostQuitMessage(0);
      break;

    default:                        
      return (DefWindowProc(hWnd, wMsg, wParam, lParam));
    }

  return (NULL);
}
