//----------------------------------------------------------------------
// File name: init.c                            Creation date: 921009 
//
// Abstract:  Contains the initialization code for ShowGrp.
//
// Provides the following functions:
//
//    InitApplication () - Initializes application specific data.
//    InitInstance () - Initializes instance specific data.
//
// Development Team: bts
//
// Written by Microsoft Product Support Services, Windows Developer Support.
//
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//----------------------------------------------------------------------

#define IN_INIT

#include <windows.h>
#include "global.h"
#include "init.h"
#include "winmain.h"


//----------------------------------------------------------------------
//     Function:  BOOL InitApplication 
//
//   Parameters:  HANDLE hInstance - Handle to this instance
//                HANDLE hPrevInstance - Handle to previous instance,
//                                       if there is one.
// 
//      Purpose:  Initializes all of the application specific data.
//
// Return Value:  Keys off the hPrevInstance to determine whether or
//                or not to make the call to RegisterClass.  The only
//                way for this function to fail would be if the intial 
//                instance failed to register a window class.
//--------------------------------------------------------------------
BOOL InitApplication (HANDLE hInstance, HANDLE hPrevInstance)
{
  WNDCLASS  WndClass;
  char      szMenuName  [BUFSIZE];    // These are to hold the strings

  // *****************************************************************
  // Load strings from string table.  We're loading them from string 
  // tables to demonstrate how one could pull these names out of
  // the resouce file if they wanted to.
  // *****************************************************************

  LoadString (hInstance, IDS_MAINCLASSNAME, gszClassName,  BUFSIZE);
  LoadString (hInstance, IDS_MAINMENUNAME,  szMenuName,   BUFSIZE);

  // *****************************************************************
  // Check from previous instance.  We want to make sure we don't
  // try to register the window class more than once.
  // *****************************************************************

  if (!hPrevInstance)
    {
    WndClass.style          = NULL;                  
    WndClass.lpfnWndProc    = (WNDPROC) MainWndProc;      
    WndClass.cbClsExtra     = 0;                
    WndClass.cbWndExtra     = 0;                
    WndClass.hInstance      = hInstance;          
    WndClass.hIcon          = LoadIcon (hInstance, "ShowGroupIcon");
    WndClass.hCursor        = LoadCursor(NULL, IDC_ARROW);
    WndClass.hbrBackground  = COLOR_WINDOW+1;
    WndClass.lpszMenuName   = szMenuName;  
    WndClass.lpszClassName  = gszClassName;


    // The only way this function returns FALSE is if the RegisterClass
    // call fails on the first instance of the application.

    if (!RegisterClass (&WndClass))
      return FALSE;
    }

  // If there's a previous instance, we'll just use the Window class
  // that was registered then.

  return TRUE;          
}

//----------------------------------------------------------------------
//     Function:  BOOL InitInstance 
//
//   Parameters:  HANDLE hInstance - Handle to this instance
// 
//      Purpose:  Initialize instance specific information
//
// Return Value:  BOOL indicating success or failure.
//--------------------------------------------------------------------
BOOL InitInstance (HANDLE hInstance, int nCmdShow)
{
  HWND      hWnd;

  // *****************************************************************
  // Load strings from string table.  We're loading them from string 
  // tables to demonstrate how one could localize thier application.  
  // There are actually two parts to the application name because I 
  // want to show the double click message when the app is shown 
  // normal and I want to get rid of it when it is minimized.
  // *****************************************************************

  LoadString (hInstance, IDS_APPNAME,   gszAppName,         BUFSIZE);
  LoadString (hInstance, IDS_DBLCLICK,  gszDblClickAppName, BUFSIZE);

  // *****************************************************************
  // The double click version of the appname becomes the main window
  // title.  The vanilla version of the appname becomes the title for
  // the icon when the application in minimized.
  // *****************************************************************

  lstrcat (gszDblClickAppName, gszAppName);

  ghInst = hInstance;                  // Globalize the instance

  hWnd = CreateWindow(gszClassName,               
                      gszDblClickAppName,  
                      WS_OVERLAPPEDWINDOW,           
                      CW_USEDEFAULT,                 
                      CW_USEDEFAULT,                 
                      CW_USEDEFAULT,                
                      CW_USEDEFAULT,                 
                      NULL,                          
                      NULL,                         
                      hInstance,                     
                      NULL);

  if (!hWnd)                          // If the window isn't created,
    return (FALSE);                   // give up and go home.

  ShowWindow(hWnd, nCmdShow);  
  UpdateWindow(hWnd);
  return TRUE;
}
