//----------------------------------------------------------------------
// File name: showgrp.c                            Creation date: 921006 
//
// Abstract:  This is a source file to show how to read the Windows 
//            3.1 group file.  Please note that all of this may change 
//            in a future release of the Windows operating system.
//    
//            This program works by going out and finding the PROGMAN.INI
//            file.  A sample PROGMAN.INI file looks like the following:
//
//            [Settings]
//              Window=428 465 1011 733 1
//              SaveSettings=0
//              display.drv=8514.drv
//              Order= 6 4 2 9 3 8 1 7 5
//            [Groups]
//              Group1=C:\WINDOWS\MAIN0.GRP
//              Group2=C:\WINDOWS\ACCESSO0.GRP
//              Group4=C:\WINDOWS\STARTUP.GRP
//              Group5=C:\WINDOWS\DOSAPPS.GRP
//              Group8=C:\WINDOWS\MICROSOF.GRP
//              Group9=C:\WINDEV\SDKTOOLS.GRP
//
//            It uses the information in the PROGMAN.INI file to list 
//            the information in the opening listbox.  In order to get 
//            information about items in the group, the program opens 
//            the file listed in this list box.
//
//            The program then goes out and reads in the entire group
//            file specified in the opening list box and displays the
//            items in a secondary list box.  It uses structures 
//            specified in the group file format document in the 
//            Windows 3.1 SDK to find where the items are located 
//            within the file.  To demonstrate how to read an item,
//            ShowGrp reads in the item's icon and displays it in a 
//            dialog box.
//
// Provides the following functions:
//    
//    ListGroupInfo - List group information in a list box created in
//                    a dialog box window.
//    SetGroupInfo - Initializes the data in a list box with group info
//    PMItemsDlg - Dialog procedure for showing the items of a group file
//    SetItemInfo - Initializes the item information in a list box.
//    PMIconDlg - Dialog procedure for showing the item's icon.
//    ReadGroupFile - Reads in the group file specified in the file name
//                    parameter.
//    GetIcon - Gets the handle to the icon specified by the item index 
//              into the group file.
//
// Development Team: bts
//
// Written by Microsoft Product Support Services, Windows Developer Support.
//
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//----------------------------------------------------------------------
#include <Windows.H>
#include <stdlib.h>
#include <memory.h>
#include <string.h>
#include "global.h"
#include "showgrp.h"

//----------------------------------------------------------------------
//     Function:  HWND ListGroupInfo 
//
//   Parameters:  hWnd - Handle to the window in which the list box
//                       containing the groups is created.
// 
//      Purpose:  List the group information on the screen after
//                creating a list box in the given Window.  All we
//                do here is create the list box and then pass the
//                handle to the listbox to SetGroupInfo.  This
//                function fills in the list box with the group 
//                file information.
//
// Return Value:  The window handle of the list box
//--------------------------------------------------------------------
HWND ListGroupInfo (HWND hWnd)
{
  HWND  hwndList;                     // Window handle to list box 
  int   TabStopList[4];               // Array to store tab stops

  // Create the group list box window
  hwndList = CreateWindow ("LISTBOX", NULL,
                            WS_CHILD   | WS_VISIBLE | WS_BORDER |
                            WS_VSCROLL | LBS_NOINTEGRALHEIGHT |
                            LBS_NOTIFY | LBS_USETABSTOPS,
                            0, 0, 0, 0,
                            hWnd, IDL_PMGROUP,
                            GetWindowWord (hWnd, GWW_HINSTANCE),
                            NULL);

  // Set the tab stops 
  TabStopList[0] = FIRSTTABSTOP;
  TabStopList[1] = SECONDTABSTOP;
  TabStopList[2] = THIRDTABSTOP;

  SendMessage(hwndList,
              LB_SETTABSTOPS,
              TABSTOPS,
              (LONG)(LPSTR)TabStopList);

  // Fill in the group file information
  SetGroupInfo (hwndList);
  return hwndList;
}

//----------------------------------------------------------------------
//     Function:  SetGroupInfo 
//
//   Parameters:  HWND hWnd - Window handle to the list box.
// 
//      Purpose:  This function sets the group into the list box.
//                It does this by looking in the PROGMAN.INI file
//                under the [Groups] section.  It also looks into
//                the group file to figure out how many items are
//                in the group file.  
//
// Return Value:  Return indicates success or failure
//--------------------------------------------------------------------
BOOL SetGroupInfo (HWND hWndListBox)
{
  PMGROUPHEADER FAR *PMGroupHeader;       //  To hold group header  
  LPSTR             lpszGroupNames;       //  Group names
  char              *szUserMsg;           
  char              *szGroupName;
  char              *szFileName;          //  GroupFile name
  char              szGroupHeader [BUFSIZE];
  HGLOBAL           ghMemGroupFileData;   // Handle to global memory which
                                          // holds the group file data.

  HGLOBAL           hglbGroupName;        //  various mem handles
  HLOCAL            hlocUserMsg;          //  Message to user
  HLOCAL            hlocGroupName;
  HLOCAL            hlocFileName;
  WORD          FAR *rgiItems;            //  Array of offsets in group file
  WORD              i;                    //  index
  WORD              cItems;               //  Count of items in group file  

  // Allocate and lock variables.
  hglbGroupName = GlobalAlloc (GMEM_MOVEABLE, MAXSECTIONSIZE);
  lpszGroupNames = GlobalLock (hglbGroupName);

  hlocUserMsg = LocalAlloc (LPTR, BUFSIZE);
  szUserMsg   = LocalLock (hlocUserMsg);

  hlocGroupName = LocalAlloc (LPTR, BUFSIZE);
  szGroupName = LocalLock (hlocGroupName);

  hlocFileName = LocalAlloc (LPTR, _MAX_FNAME);
  szFileName  = LocalLock (hlocFileName);

  // Show headers in list box
  LoadString (ghInst, IDS_GROUPHEADER, szGroupHeader, BUFSIZE);
  SendMessage (hWndListBox, LB_ADDSTRING, 0, (LONG) (LPSTR) szGroupHeader);

  // **********************************************************************
  // Group file names are in progman.ini under the [groups] section.  Here
  // we are reading them all in at once because we have left lpszEntry
  // parameter in the call to GPPS set to NULL.  Doing this causes 
  // lpszGroupNames to be a series of NULL terminated strings ending with 
  // a double NULL at the end.
  // **********************************************************************

  GetPrivateProfileString ((LPSTR) "Groups",
                           (LPSTR) NULL,
                           (LPSTR) "Default Group",
                            lpszGroupNames,
                            MAXSECTIONSIZE,
                           (LPSTR) "Progman.ini");

  // **********************************************************************
  // Go through the group names and fill in the list box
  // with the appropriate information
  // **********************************************************************

  while (*lpszGroupNames)
    {
    GetPrivateProfileString ((LPSTR) "Groups",
                             lpszGroupNames,
                             (LPSTR) "=Default File Name",
                              szFileName,
                              _MAX_FNAME,
                             (LPSTR) "Progman.ini");
                           
    szFileName = strtok (szFileName, "=");

    // ********************************************************************
    // We have to go into the group file to determine how many actual 
    // items there are.  The reason that we have to do this is because 
    // the member in the header does not get fully updated if you 
    // delete an item.  Instead, Windows just zeroes out the entry.
    // ********************************************************************

    if (!ReadGroupFile ((LPSTR) szFileName, &ghMemGroupFileData))
      {
      // Check for errors reading the group file
      LoadString (ghInst, IDS_GFREADERR, szUserMsg, BUFSIZE);
      MessageBox (hWndListBox,
                  (LPSTR) szUserMsg,
                  (LPSTR) gszAppName,
                  MB_ICONSTOP);
      return FALSE;
      }

    else                    
      {
      // ******************************************************************
      // We read the file okay, now it's time to see how many items
      // are in the group file.  We do this by getting a pointer to the
      // group file header.  At the back end of this header is the array
      // of offsets to each of the items in the file - rgiItems.  Then 
      // we have to go through and see how many of the offsets are 
      // actually valid.
      // ******************************************************************

      // Set the pointer to the array of item offsets 
      PMGroupHeader = (PMGROUPHEADER FAR *)lpGroupFileData;
      rgiItems = (WORD FAR *) &lpGroupFileData [sizeof (PMGROUPHEADER)];

      // ******************************************************************
      // Initialize the counts.  The whole purpose of this is to get a
      // valid count in the list box. 
      // ******************************************************************
      i = cItems = 0;       
      while (i++ < PMGroupHeader->cItems)
        {
        if (*rgiItems)                // If there is an offset,
          cItems++;                   // bump the count
        rgiItems++;
        }

      wsprintf ((LPSTR) szUserMsg, (LPSTR) "%.30s \t%.30s \t%d",
                (LPSTR) szFileName,
                (LPSTR) &lpGroupFileData [PMGroupHeader->pName],
                cItems);
      SendMessage (hWndListBox, LB_ADDSTRING, 0, (LONG) (LPSTR) szUserMsg);
      lpszGroupNames += lstrlen (lpszGroupNames) + 1;
                    
  
      // Let go of the memory allocated in ReadGroupFile
                      
      if (GlobalUnlock (ghMemGroupFileData))
        GlobalFree (ghMemGroupFileData);
      }
    }

  // Free global memory
  GlobalFree (hglbGroupName);

  // Free local memory
  LocalFree  (LocalHandle (hlocUserMsg));
  LocalFree  (LocalHandle (hlocGroupName));
  LocalFree  (LocalHandle (hlocFileName));

  // Set cursor and selection to first item in list box
  SendMessage (hWndListBox, LB_SETCURSEL, 1, 0L);
  return TRUE;
}

//----------------------------------------------------------------------
//
//     Function:  BOOL FAR PASCAL PMItemsDlg 
//
//   Parameters:  HWND hDlg     - Handle to dialog
//                WORD wMsg     - Message value
//                WORD wParam   - WORD parameter
//                LONG lParam   - LONG parameter
// 
//      Purpose:  Dialog procedure for handling PM items.  This dialog
//                lists the items out in the list box and asks the user
//                to double click the item to see the item's icon.  The
//                important message to look for in the dialog is the 
//                WM_COMMAND message with wParam == IDL_PMITEM and the
//                high word of lParam == LBN_DBLCLICK.  When the dialog
//                box gets this notification, it reads the item's
//                icon and displays it in a subsequent dialog box.
//--------------------------------------------------------------------
BOOL FAR PASCAL PMItemsDlg (HWND hDlg, WORD wMsg, WORD wParam, LONG lParam)
{
  static HWND   hwndDlgList;          // Window handle to item list box

  PMGROUPHEADER FAR *PMGroupHeader;   // ptr to group file header
  char          FAR *szGroupName;     // ptr to group name
  char               szUserMsg [BUFSIZE];
  char               szFormat [BUFSIZE];

  FARPROC       lpProcPMIcon;         // Address of icon dialog
  POINT         ptTop;
  RECT          rc;
  HWND          hwndParent;
  int           TabStopList[8];       //  Array to store tabs
  static HICON  hIcon;

  switch (wMsg)
	  {
    case WM_INITDIALOG:

      hIcon = LoadIcon (ghInst, "ShowGroupIcon");


      // Doing this for clarity - that is, setting header pointer
      // to the beginning of the group file data
      PMGroupHeader = (PMGROUPHEADER FAR *) lpGroupFileData;

      hwndDlgList = CreateWindow ("LISTBOX", NULL,
                            WS_CHILD   | WS_VISIBLE | WS_BORDER |
                            WS_VSCROLL | LBS_NOINTEGRALHEIGHT |
                            LBS_NOTIFY | LBS_USETABSTOPS,
                            0, 0, 0, 0,
                            hDlg, IDL_PMITEM,
                            ghInst,
                            NULL);

      // Set the tab stops for the item list box
      TabStopList[0] = FIRSTTABSTOP;
      TabStopList[1] = SECONDTABSTOP;
      TabStopList[2] = THIRDTABSTOP;

      SendMessage(hwndDlgList,
                  LB_SETTABSTOPS,
                  TABSTOPS,
                  (LONG)(LPSTR)TabStopList);

      // Set the window caption to the group name
      szGroupName = &lpGroupFileData [PMGroupHeader->pName];

      LoadString (ghInst, IDS_DBLICON, szFormat, BUFSIZE);
      wsprintf ((LPSTR) szUserMsg,
                szFormat,
                (LPSTR) szGroupName);
      SendMessage (hDlg, WM_SETTEXT, 0, (LONG) (LPSTR) szUserMsg);

      // *************************************************************
      // The SetItemInfo function sets the information about the 
      // individual items into the list box.
      // *************************************************************

      SetItemInfo (hwndDlgList);

      // *************************************************************
      // Size the list box so that it fits inside of the parent
      // window.
      // *************************************************************

      hwndParent = GetWindowWord (hDlg, GWW_HWNDPARENT);
      GetClientRect (hwndParent, (LPRECT) &rc);
      ptTop.x     = rc.top;     ptTop.y     = rc.left;
      ClientToScreen (hwndParent, &ptTop);
      MoveWindow (hDlg,
                  ptTop.x + 10, ptTop.y + 10,
                  rc.right - 20, rc.bottom - 20, TRUE);
      GetClientRect (hDlg, (LPRECT) &rc);
      MoveWindow (hwndDlgList, 0, 0, rc.right, rc.bottom, TRUE);

      return (TRUE);

   case WM_PAINT:
      {
      PAINTSTRUCT ps;

      if (IsIconic(hDlg))
         {
         BeginPaint(hDlg, (LPPAINTSTRUCT)&ps);

         // Paint the desktop window background.
         DefDlgProc(hDlg, WM_ICONERASEBKGND, (WORD)ps.hdc, 0L);

         // Draw the icon on top of it.
         DrawIcon(ps.hdc, 0,0, hIcon);

         EndPaint(hDlg, (LPPAINTSTRUCT)&ps);
         }
      else
         return FALSE;
      }

    case WM_ERASEBKGND:
      if (IsIconic(hDlg))
         // Do not erase the background now. When the application
         // paints its icon, it will erase the background.
         return TRUE;
      else
         return FALSE;

    case WM_SIZE:

      // Make sure the list box gets drawn

      MoveWindow (hwndDlgList, 0, 0, LOWORD (lParam), HIWORD (lParam), TRUE);
      return (TRUE);

    case WM_SYSCOMMAND:
	    switch (wParam)
		    {
        case SC_MINIMIZE:

          // When the window is minimized, show just the application
          // name: ShowGroup.  

          SendMessage (hDlg, WM_SETTEXT, 0, (LONG) (LPSTR) gszAppName);
          InvalidateRect (hDlg, NULL, TRUE);
          break;

        case SC_MAXIMIZE:
        case SC_RESTORE:

          // When the window is maximized, show the application name
          // along with the double click instruction.
          SendMessage (hDlg, WM_SETTEXT, 0, (LONG) (LPSTR) gszDblClickAppName);
          InvalidateRect (hDlg, NULL, TRUE);
          break;

        }
        return FALSE;


    case WM_COMMAND:    
		  switch(wParam)
			  {
        case IDL_PMITEM:

          // ***********************************************************
          // See if the user has doubled clicked on an item. If the
          // user has double clicked on an item, then the icon dialog
          // gets the icon and shows it to the user along with the
          // XOR and AND bits.
          // ***********************************************************

          if (HIWORD (lParam) == LBN_DBLCLK)
            {
            if (!(SendMessage (LOWORD (lParam), LB_GETCURSEL, 0, 0L) == 0))
              {
              lpProcPMIcon = MakeProcInstance(PMIconDlg, ghInst);
              DialogBoxParam (ghInst, "PMIcons", hDlg,
                              lpProcPMIcon, (LPARAM) (hDlg << 16) + hwndDlgList);
              FreeProcInstance(lpProcPMIcon);
              }
            }
          return TRUE;

    		case IDOK:
			  case IDCANCEL:
				  EndDialog(hDlg, TRUE);
				  return TRUE;

			  default:
				  break;
  			}
		  break;

	  default:
		  break;
	  }
  return FALSE;
}

//----------------------------------------------------------------------
//     Function:  SetItemInfo 
//
//   Parameters:  HWND hWndList - Handle to the list box whic holds
//                                the item information.
// 
//      Purpose:  Fills in item data into the list box specified
//                by the hWndList parameter
//
// Return Value:  void 
//--------------------------------------------------------------------
void SetItemInfo (HWND hWndList)
{
  PMGROUPHEADER PMGroupHeader;        // Header for the group file
  PMITEMDATA    PMItemData;           // Pointer to the group file data
  WORD      FAR *rgiItems;            // Array of item offset in group file
  WORD          cItems;               // Count of items 
  WORD          i;                    // Generic counter
  char          szItemName [BUFSIZE]; // Buffer to hold item name
  char          szIconPath [BUFSIZE]; // Buffer to hold path to icon
  char          szCommand [BUFSIZE];  // Buffer to hold command  
  char          UserMsg[BUFSIZE];     // Generic message buffer
  char          szItemHeader[BUFSIZE];// To hold the item lb header
  char          *szTemp;              // Temporary char pointer

  // Set the listbox headers
  LoadString (ghInst, IDS_ITEMHEADER, szItemHeader, BUFSIZE);
  SendMessage (hWndList, LB_ADDSTRING, 0, (LONG) (LPSTR) szItemHeader);

  // Get the Group File header information

  //**************************************************************
  //  The rgiItems array in the group file may not have valid
  //  information in it because it doesn't get updated fully
  //  when the the user deletes an item from the group file.  That
  //  is, the array doesn't get closed up to only include valid
  //  offsets.  Instead, Windows puts 0 in the offset for the
  //  deleted item.  So, what we're doing here is looking down the 
  //  for non-zero entries in the array to get a true count (cItems)
  //  of items in it.  In this way, we can use cItems as a limit in
  //  the while loop below.
  //**************************************************************

  _fmemcpy (&PMGroupHeader, lpGroupFileData, sizeof (PMGROUPHEADER));

  rgiItems = (WORD FAR *) &lpGroupFileData [sizeof (PMGROUPHEADER)];
  i = cItems = 0;
  while (i++ < PMGroupHeader.cItems)
    {
    if (*rgiItems)
      cItems++;
    rgiItems++;
    }

  i = 0;
  rgiItems = (WORD FAR *) &lpGroupFileData [sizeof (PMGROUPHEADER)];

  //  **************************************************************
  //  Now that we have the count of valid items in the group file,
  //  we cand go through and add the strings to the item list box.
  //  **************************************************************
  while (i < cItems)
    {
    if (*rgiItems)
      {
      i++;
      // Get the item structure filled in
      _fmemcpy (&PMItemData,
                &lpGroupFileData [*rgiItems],
                sizeof (PMITEMDATA));

      // Get the item name filled in
      szTemp = szItemName;
      do
        *szTemp = lpGroupFileData [PMItemData.pName++];
      while (*(szTemp++));

      //  Do the item command
      szTemp = szCommand;
      do
        *szTemp = lpGroupFileData [PMItemData.pCommand++];
      while (*(szTemp++));

      //  Fill in the icon path
      szTemp = szIconPath;
      do
        *szTemp = lpGroupFileData [PMItemData.pIconPath++];
      while (*(szTemp++));

      //  Add the information to the list box.

      wsprintf ((LPSTR) UserMsg, (LPSTR) "%.30s \t%.30s \t%.22s",
                (LPSTR) szItemName,
                (LPSTR) szIconPath,
                (LPSTR) szCommand);
      SendMessage (hWndList, LB_ADDSTRING, 0, (LONG) (LPSTR) UserMsg);
      }

    rgiItems++;
    }

  //  Set the list box cursor on the first item in the list box.
  SendMessage (hWndList, LB_SETCURSEL, 1, 0L);
}

//----------------------------------------------------------------------
//     Function:  BOOL FAR PASCAL PMIconDlg
//
//   Parameters:  HWND hDlg - Handle to the dialog window
//                WORD wMsg - Message parameter
//                WORD wParam - WORD parameter
//                LONG lParam - LONG parameter
// 
//      Purpose:  Pulls the icon from the group file and shows it in 
//                the dialog box.  The program does this by calling
//                GetIcon which takes the window handle and the index
//                of the chosem item, that is the index within the
//                group file, not the index within the listbox.  
//
// Return Value:  BOOL
//--------------------------------------------------------------------
BOOL FAR PASCAL PMIconDlg (HWND hDlg,   WORD wMsg,
                           WORD wParam, LONG lParam)
{
  WORD          wIndex;
  static WORD   x, y;
  HDC           hdc;
  PAINTSTRUCT   ps;
  static HICON  hItemIcon;

  switch (wMsg)
	  {
    case WM_INITDIALOG:

      // Get the index of the chosen item

      wIndex = (WORD) SendMessage (LOWORD (lParam), LB_GETCURSEL, 0, 0L);
      hItemIcon = GetIcon (hDlg, wIndex);

      return (TRUE);

    case WM_PAINT:

      // Paint the icon in the dialog box - the icon is set during
      // the dialog's intialization.

      LockResource (hItemIcon);
      hdc = BeginPaint (hDlg, &ps);

      hdc = GetDC (hDlg);
      SetMapMode (hdc, MM_TEXT);
      DrawIcon (hdc, 10, 10, hItemIcon);
        
      ReleaseDC (hDlg, hdc);
      EndPaint (hDlg, &ps);
      break;

    case WM_COMMAND:    
		  switch(wParam)
			  {
    		case IDOK:
			  case IDCANCEL:
				  EndDialog(hDlg, TRUE);
				  return TRUE;

			  default:
				  break;
  			}
		  break;

	  default:
		  break;
	  }
  return FALSE;
}

//----------------------------------------------------------------------
//     Function:  BOOL ReadGroupFile 
//
//   Parameters:  LPSTR lpszGroupFileName - Pointer to group file name
//                *HGLOBAL ghMemGroupFileData - a pointer to the memory
//                                              handle used to keep track
//                                              of the global memory 
//                                              allocated in this routine.
// 
//      Purpose:  Reads in the group file all at once. 
//
// Return Value:  Boolean indicating success or failure
//--------------------------------------------------------------------
BOOL ReadGroupFile (LPSTR lpszGroupFileName, PHANDLE ghMemGroupFileData)
{
  HFILE         fhGroupFile;
  WORD          cbGroup;
  OFSTRUCT      OpenBuff;

  
  // Get a handle to the group file

  if ((fhGroupFile = OpenFile (lpszGroupFileName, &OpenBuff, OF_READ)) == NULL)
    return FALSE;

  // ******************************************************************
  // Find out how much memory to allocate to hold the group file by
  // seeking to the end of the file.  This gives us the number of 
  // bytes that we have to allocate in the call to GlobalAlloc.
  // ******************************************************************

  cbGroup = (WORD) _llseek (fhGroupFile, 0L, 2);
  _llseek (fhGroupFile, 0L, 0);

  *ghMemGroupFileData = GlobalAlloc (GMEM_MOVEABLE, cbGroup);
  lpGroupFileData = GlobalLock (*ghMemGroupFileData);
  if (!lpGroupFileData)
    {
    _lclose (fhGroupFile);
    return FALSE;
    }

  if (!_lread (fhGroupFile, lpGroupFileData, cbGroup))
    {
    _lclose (fhGroupFile);

    if (GlobalUnlock (*ghMemGroupFileData))
      GlobalFree (*ghMemGroupFileData);

    return FALSE;
    }

  _lclose (fhGroupFile);
  return TRUE;
}

//----------------------------------------------------------------------
//     Function:  HANDLE GetIcon 
//
//   Parameters:  hWnd - handle to the dialog window
//                wItemIndex - index of item in group file, not the
//                             the index of the list box.
// 
//      Purpose:  Get the handle to the icon pointed to by the item
//                index.  The device dependent image of the icon
//                is actually stored in the group file.  To get
//                a handle to the icon, we use the bytes stored in
//                the AND and XOR planes.
//--------------------------------------------------------------------
HANDLE GetIcon (HWND hWnd, WORD wItemIndex)
{
  PMGROUPHEADER PMGroupHeader;
  PMITEMDATA    PMItemData;
  WORD          wTemp [80];
  HANDLE        hIcon;
  char          szUserMsg [80];

  // Get the group file header information

  _fmemcpy (&PMGroupHeader, lpGroupFileData, sizeof (PMGROUPHEADER));

  // Get the count of items

  _fmemcpy (wTemp,
            &lpGroupFileData [sizeof (PMGROUPHEADER)],
            PMGroupHeader.cItems * sizeof (WORD));

  // Get the item data for the index 

  _fmemcpy (&PMItemData,
            &lpGroupFileData [wTemp [wItemIndex - 1]],
            sizeof (PMITEMDATA));

  SendMessage (hWnd, WM_SETTEXT, 0,
    (LONG) (LPSTR) &lpGroupFileData [PMItemData.pName]);

  // Use the item information to create an icon

  hIcon = CreateIcon (ghInst,
                      PMGroupHeader.wLogPixelsX,
                      PMGroupHeader.wLogPixelsY,
                      HIBYTE (PMGroupHeader.wIconFormat),
                      LOBYTE (PMGroupHeader.wIconFormat),
                      &lpGroupFileData [PMItemData.pANDPlane],
                      &lpGroupFileData [PMItemData.pXORPlane]);

  // Fill in the information about the icon in the dialog box.

  wsprintf (szUserMsg,
            "Icon.pt = (%d, %d)",
            PMItemData.pt.x, PMItemData.pt.y);
  SetDlgItemText (hWnd, IDC_ICONXY, (LPSTR) szUserMsg);

  wsprintf (szUserMsg, "AND Bytes = %d", PMItemData.cbANDPlane);
  SetDlgItemText (hWnd, IDC_ANDBYTES, (LPSTR) szUserMsg);

  wsprintf (szUserMsg, "XOR Bytes = %d", PMItemData.cbXORPlane);
  SetDlgItemText (hWnd, IDC_XORBYTES, (LPSTR) szUserMsg);

  UnlockResource(hIcon);
  return hIcon;
}
