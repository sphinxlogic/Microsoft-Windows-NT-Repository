// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <windows.h>
#include <toolhelp.h>
#include <string.h>
#include <memory.h>
#include "gdiwatch.h"

#define MAXPTRS 400
#define LPLOCALENTRY (LOCALENTRY FAR *)

SYSHEAPINFO shiMain;
char szBuf[60];
int iMaxObjects;
HANDLE hObjects[MAXPTRS];


char GDITypes[11][12] =
{"Reserved   ","PEN        ","BRUSH      ",
 "FONT       ","PALETTE    ","BITMAP     ",
 "RGN        ","DC         ","DISABLED_DC",
 "METADC     ","METAFILE   " };

char UserTypes[32][19] =
{"Reserved          ","CLASS             ","WND               ",
 "STRING            ","MENU              ","CLIP              ",
 "CBOX              ","PALETTE           ","ED                ",
 "BWL               ","OWNERDRAW         ","SPB               ",
 "CHECKPOINT        ","DCE               ","MWP               ",
 "PROP              ","LBIV              ","MISC              ",
 "ATOMS             ","LOCKINPUTSTATE    ","HOOKLIST          ",
 "USERSEEUSERDOALLOC","HOTKEYLIST        ","POPUPMENU         ","","",""
 "","","","","","HANDLETABLE       "
};


int FAR PASCAL LibMain(hModule, wDataSeg, cbHeapSize, lpszCmdLine)
HANDLE  hModule;
WORD    wDataSeg;
WORD    cbHeapSize;
LPSTR   lpszCmdLine;
{
    return(1);
}

int FAR PASCAL WEP (bSystemExit)
int  bSystemExit;
{
    return(1);
}

/* The API is simple as can be: Both functions will call the main Window
   with WM_CREATED or WM_DELETED and lParam = String to process.
   It is up to the app then to further process the string. */

void FAR PASCAL TakeSnapShot(HWND hWnd, int iHeapMarker)
{ HGLOBAL hSystemHeap;
  static LOCALENTRY leTemp;
  HLOCAL hNextObject;
  LOCALENTRY FAR *lpNextObject;
  int iObjectCt = 0;
iMaxObjects = 0;

shiMain.dwSize = sizeof(SYSHEAPINFO);
leTemp.dwSize = sizeof(LOCALENTRY);
SystemHeapInfo((SYSHEAPINFO FAR *)&shiMain);
hSystemHeap = (iHeapMarker == IDM_GDIHEAP) ? shiMain.hGDISegment: shiMain.hUserSegment;
LocalFirst((LOCALENTRY FAR *)&leTemp,hSystemHeap);
do {
/* The LocalNext() routine will set the handle of a free block to 0,
   so no use to keep these around...  */
if (!leTemp.hHandle) continue;
hNextObject = LocalAlloc(LMEM_MOVEABLE,sizeof(LOCALENTRY));
if (!hNextObject) { MessageBox(hWnd,"Allocating Memory","!!",0);
                                        PostQuitMessage(0);
                                  };
lpNextObject = (LOCALENTRY FAR *)LocalLock(hNextObject);
_fmemcpy((char *)lpNextObject,(char *)&leTemp,sizeof(LOCALENTRY));
hObjects[iObjectCt] = hNextObject;
iObjectCt++;
if (iObjectCt >= MAXPTRS) { MessageBox(hWnd,"No space...","!!",0);
                                                           PostQuitMessage(0);
                                                         };
LocalUnlock(hNextObject);
}

while (LocalNext((LOCALENTRY FAR *)&leTemp));
iMaxObjects = iObjectCt;
}

void FAR PASCAL Compare(HWND hWnd, int iHeapMarker, int wNewMessage)
{ HGLOBAL hSystemHeap;
  LOCALENTRY leTemp;
  LOCALENTRY  *lpNextObject;
  int iObjectCt = 0;
shiMain.dwSize = sizeof(SYSHEAPINFO);
leTemp.dwSize = sizeof(LOCALENTRY);
SystemHeapInfo((SYSHEAPINFO FAR *)&shiMain);
hSystemHeap = (iHeapMarker == IDM_GDIHEAP) ? shiMain.hGDISegment : shiMain.hUserSegment;
LocalFirst((LOCALENTRY FAR *)&leTemp,hSystemHeap);
do {
/* Brute force: Scan list for every object on the new list... */
 for (iObjectCt = 0;iObjectCt <= iMaxObjects; iObjectCt++)
     if (hObjects[iObjectCt])
        { lpNextObject = (LOCALENTRY *)LocalLock(hObjects[iObjectCt]);
          if (leTemp.hHandle == lpNextObject->hHandle)
             {
               LocalUnlock(hObjects[iObjectCt]);
               LocalFree(hObjects[iObjectCt]);
               hObjects[iObjectCt] = 0;
               leTemp.hHandle = 0;
               break;
             }
             else LocalUnlock(hObjects[iObjectCt]);
         };
/* Now either the object was matched (in which case we nuked both the
   original object and nullified the handle in leTemp) or not at all
   (in which case we display it here)    */
if (leTemp.hHandle)
{
/* I know this is inefficient as hell, but C offers little abstraction
   mechanisms to catch this... */

 LPSTR lpTypeName = (leTemp.wType<0) ? "Free" :
                    (iHeapMarker == IDM_GDIHEAP) ?
                    (LPSTR)GDITypes[leTemp.wType] :
                    (LPSTR)UserTypes[leTemp.wType];
 wsprintf(szBuf,"%4x @ %4x, Size %4x, Type: %s",  leTemp.hHandle,
                                                leTemp.wAddress,
                                                leTemp.wSize,
                                                lpTypeName);
 SendMessage(hWnd,wNewMessage,IDM_OBJCREATED,(LONG)(LPSTR)szBuf);
};
}
while (LocalNext((LOCALENTRY FAR *)&leTemp));
/* Now display the rest of the old local heap. */
 for (iObjectCt = 0;iObjectCt <= iMaxObjects; iObjectCt++)
   if (hObjects[iObjectCt])
        { LPSTR lpTypeName = (lpNextObject->wType<0) ? "Free" :
                             (iHeapMarker == IDM_GDIHEAP) ?
                             (LPSTR)GDITypes[lpNextObject->wType] :
                             (LPSTR)UserTypes[lpNextObject->wType];
                lpNextObject = (LOCALENTRY FAR *)LocalLock(hObjects[iObjectCt]);
                wsprintf(szBuf,"%4x @ %4x, Size %4x, Type: %s",
                                                lpNextObject->hHandle,
                                                lpNextObject->wAddress,
                                                lpNextObject->wSize,
                                                lpTypeName);
                SendMessage(hWnd,wNewMessage,IDM_OBJDELETED,(LONG)(LPSTR)szBuf);
                LocalUnlock(hObjects[iObjectCt]);
                LocalFree(hObjects[iObjectCt]);
                hObjects[iObjectCt] = 0;
         };


}


