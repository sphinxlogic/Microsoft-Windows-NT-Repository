/*--------------------------------------------------------------*/
/*     Template for a generic Windows app                       */
/*--------------------------------------------------------------*/  

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "windows.h"
#include "commdlg.h"
#include <string.h>
#include <memory.h>
#include "gdiwatch.h"
#define WNDCLSNAME "GDIWatchClass"
#define CAPTIONTEXT "GDI Local Heap Display"

void FAR PASCAL TakeSnapShot(HWND,int);
void FAR PASCAL Compare(HWND,int, int);


HWND hWndHitBox, hWndFileBox;
HANDLE hInst;


LRESULT CALLBACK MainWndProc (HWND,UINT,WPARAM,LPARAM) ;

/* Just copy all objects into local memory  */

HFONT GetFont(void)
  {
    static LOGFONT logfont;

    logfont.lfHeight=14;
    logfont.lfCharSet=ANSI_CHARSET;
    logfont.lfQuality=DEFAULT_QUALITY;
    logfont.lfPitchAndFamily=FF_MODERN;
    lstrcpy((LPSTR)&logfont.lfFaceName,(LPSTR)"Courier New");

    return CreateFontIndirect(&logfont);
  }

BOOL CallUpDlgBox(HWND hWnd,FARPROC DlgBoxProc,LPSTR Template,LPARAM lParam)
  {
    DLGPROC     lpProcAbout;
    BOOL        result;
    HINSTANCE   hInst;

    hInst=(HINSTANCE)GetWindowWord(hWnd,GWW_HINSTANCE);
    lpProcAbout =(DLGPROC) MakeProcInstance (DlgBoxProc, hInst);

    result=DialogBoxParam(hInst,
			  Template,
			  hWnd,
			  lpProcAbout,
			  lParam);

    FreeProcInstance((FARPROC)lpProcAbout);
    return  result;
  }


BOOL FAR PASCAL AboutBoxProc(HWND hdlg, WORD message, WORD wParam, LONG lParam)
  {
    switch (message)
      {
	case WM_INITDIALOG:
	  return 1;

	case WM_COMMAND:
	  switch (wParam)
	    {
	      case IDM_OK:
		EndDialog (hdlg,TRUE);
		return 1;

	      default:
		return 0;
	    }
      }
    return 0;
  }


/*--------------------------------------------------------------*/
/*              Win Main Definition                             */
/*--------------------------------------------------------------*/

int PASCAL WinMain (hInstance,hPrevInstance, lpszCmdLine,nCmdShow)
	HANDLE hInstance, hPrevInstance ;
	LPSTR lpszCmdLine ;
	int nCmdShow;
	{
	static char szAppName [] = WNDCLSNAME ;
	HWND hWnd;
	MSG msg;
	WNDCLASS wndclass ;

/*--------------------------------------------------------------*/
/* Definition of the Window classe(s) follow up here            */
/*--------------------------------------------------------------*/
    hInst = hInstance;
	if (!hPrevInstance)
		{
		wndclass.style          = CS_HREDRAW | CS_VREDRAW ;
		wndclass.lpfnWndProc= MainWndProc ;
		wndclass.cbClsExtra = 0;
		wndclass.cbWndExtra = 0;
		wndclass.hInstance  = hInstance;
		wndclass.hIcon          = LoadIcon (NULL, IDI_APPLICATION);
		wndclass.hCursor    = LoadCursor (NULL, IDC_ARROW);
		wndclass.hbrBackground = GetStockObject (WHITE_BRUSH) ;
		wndclass.lpszMenuName  = "MainMenu";
		wndclass.lpszClassName = szAppName;

		if (!RegisterClass (&wndclass))
			return FALSE ;
		}

/*--------------------------------------------------------------*/
/*     Main Window is defined here                              */
/*--------------------------------------------------------------*/
	hWnd = CreateWindow (szAppName,
					CAPTIONTEXT,
					WS_OVERLAPPEDWINDOW,
					CW_USEDEFAULT,
					0,
					CW_USEDEFAULT,
					0,
					NULL,
					NULL,
					hInstance,
					NULL);
	ShowWindow (hWnd, nCmdShow) ;
	UpdateWindow (hWnd) ;

/*--------------------------------------------------------------*/
/*     Entering Message Processing Loop                         */
/*--------------------------------------------------------------*/

	while (GetMessage (&msg, NULL, 0, 0))
		 {
		 TranslateMessage (&msg) ;
		 DispatchMessage (&msg);
		 }
	return msg.wParam ;
	}

/*--------------------------------------------------------------*/
/* Window procedure for the main window        */
/*--------------------------------------------------------------*/

LRESULT CALLBACK MainWndProc (hWnd, iMessage, wParam, lParam)
	HWND hWnd;
	UINT iMessage;
	WPARAM wParam;
	LPARAM lParam;
/*--------------------------------------------------------------*/
/* local variables follow here                                  */
/*--------------------------------------------------------------*/
	{
	static short xChar,yChar;
	static HPEN hPen,hPenDefault;
	static int iHeapMarker;
    RECT   rcClient;
    static HFONT hNewFont;
    static int iOutputType;
    static HANDLE hFile;
    static char szLFBuf[]="\n\r";

/*-------------------------------------------------------------*/
/*  Body of the window procedure: Message Processing           */
/*-------------------------------------------------------------*/
	switch (iMessage)
		{
		case WM_COMMAND:
			switch (wParam)
			{ case IDM_SNAPSH:
				   EnableMenuItem(GetMenu(hWnd),1,MF_BYPOSITION|MF_GRAYED);
				   EnableMenuItem(GetMenu(hWnd),IDM_COMPARE,MF_ENABLED);
				   DrawMenuBar(hWnd);
				   SendMessage(hWndFileBox,LB_RESETCONTENT,0,0L);
				   SendMessage(hWndHitBox,LB_RESETCONTENT,0,0L);
				   if (iOutputType == IDM_SCREENOUTPUT)
				   {
		   SendMessage(hWndFileBox,LB_ADDSTRING,0,(LONG)(LPSTR)"    Objects created between Snapshot and Compare:");
		   SendMessage(hWndHitBox,LB_ADDSTRING,0,(LONG)(LPSTR)"    Objects deleted between Snapshot and Compare:");
		   }
		   else
		     _lwrite(hFile,"Snapshot taken...\n\r",19);
				   TakeSnapShot(hWnd,iHeapMarker);
				   break;
			  case IDM_COMPARE:
				   if (iOutputType == IDM_FILEOUTPUT)
				     _lwrite(hFile,"Comparing...\n\r",14);
				   Compare(hWnd,iHeapMarker,WM_OBJCHANGED);
				   EnableMenuItem(GetMenu(hWnd),1,MF_BYPOSITION|MF_ENABLED);
				   EnableMenuItem(GetMenu(hWnd),IDM_COMPARE,MF_GRAYED);
				   DrawMenuBar(hWnd);
				   break;
			  case IDM_USERHEAP:
				   SetWindowText(hWnd,"Watching USER...");
				   CheckMenuItem(GetMenu(hWnd),IDM_USERHEAP,MF_CHECKED);
				   CheckMenuItem(GetMenu(hWnd),IDM_GDIHEAP,MF_UNCHECKED);
				   iHeapMarker = wParam;
				   break;
			  case IDM_GDIHEAP:
				   SetWindowText(hWnd,"Watching GDI...");
				   CheckMenuItem(GetMenu(hWnd),IDM_GDIHEAP,MF_CHECKED);
				   CheckMenuItem(GetMenu(hWnd),IDM_USERHEAP,MF_UNCHECKED);
				   iHeapMarker = wParam;
				   break;
			  case IDM_SCREENOUTPUT:
			  case IDM_FILEOUTPUT:
					if (hFile)
					 {
				     _lclose(hFile);
				     hFile = 0;
				     };
				   iOutputType = wParam;
				   CheckMenuItem(GetMenu(hWnd),wParam,MF_CHECKED);
				   CheckMenuItem(GetMenu(hWnd),(wParam == IDM_SCREENOUTPUT) ?
											   IDM_FILEOUTPUT : IDM_SCREENOUTPUT,MF_UNCHECKED);
				   if (wParam == IDM_FILEOUTPUT)
				     {  static OPENFILENAME opfnFilName;
					static char szBuf[256];
					OFSTRUCT ofTargetFile;
					memset(&opfnFilName,0,sizeof(OPENFILENAME));
					opfnFilName.lStructSize = sizeof(OPENFILENAME);
					opfnFilName.hwndOwner = hWnd;
					opfnFilName.lpstrFile = (LPSTR)szBuf;
					opfnFilName.nMaxFile = 256;
					opfnFilName.lpstrTitle = "Protocol to File:";
					if (!GetOpenFileName(&opfnFilName) ||
					    ((hFile = OpenFile(szBuf,&ofTargetFile,OF_CREATE|OF_WRITE))
					      == HFILE_ERROR))
						{MessageBox(hWnd,"Error opening file","Heap Watcher",MB_OK);
						 hFile = 0;
						};

		      };
				   break;

		  case IDM_ABOUT:
					CallUpDlgBox(hWnd,
					AboutBoxProc,
					"ABOUT",
					(LPARAM)0l);

			  default: break;
			};
	case WM_SIZE:
	    GetClientRect(hWnd,&rcClient);
	    MoveWindow(hWndFileBox,rcClient.left,rcClient.top,
				   rcClient.right,rcClient.bottom/2, TRUE);
	    MoveWindow(hWndHitBox,rcClient.left,rcClient.bottom/2,
				   rcClient.right, rcClient.bottom/2, TRUE);
	    break;

	case WM_CREATE:
		hNewFont = GetFont();
	    hWndHitBox = CreateWindow("LISTBOX","",WS_CHILD | WS_VISIBLE | LBS_USETABSTOPS |
					       LBS_NOTIFY | WS_BORDER | WS_VSCROLL,
						 0,0,1,1,hWnd, NULL, hInst,
						 NULL);
	    hWndFileBox = CreateWindow("LISTBOX","",WS_CHILD | WS_VISIBLE | LBS_USETABSTOPS
						   | LBS_STANDARD,
						 0,0,1,1,hWnd, NULL, hInst,
						 NULL);

	  if (!hWndHitBox || !hWndFileBox)
	     {MessageBox(hWnd,"Unable to create Child Windows!","GdiWatch",MB_OK);
	      PostQuitMessage(0);
	     };
	  SendMessage(hWndHitBox,WM_SETFONT,hNewFont,0);
	  SendMessage(hWndFileBox,WM_SETFONT,hNewFont,0);
	  iHeapMarker = IDM_GDIHEAP;
	  SetWindowText(hWnd,"Watching GDI...");
      iOutputType = IDM_SCREENOUTPUT;
			break;
		case WM_OBJCHANGED:
			if (wParam==IDM_OBJCREATED)
			 {if (iOutputType == IDM_SCREENOUTPUT)
				SendMessage(hWndFileBox,LB_ADDSTRING,0,lParam);
			  else
			    {_lwrite(hFile,"Created: ",9);
			     _lwrite(hFile,(LPSTR)lParam,lstrlen((LPSTR)lParam));
			     _lwrite(hFile,szLFBuf,strlen(szLFBuf));
			    };
			  }
			else
			 {if (iOutputType == IDM_SCREENOUTPUT)
			SendMessage(hWndHitBox,LB_ADDSTRING,0,lParam);
			  else
			    {_lwrite(hFile,"Deleted: ",9);
			     _lwrite(hFile,(LPSTR)lParam,lstrlen((LPSTR)lParam));
			     _lwrite(hFile,szLFBuf,strlen(szLFBuf));
			    };
			  };

			break;
		case WM_DESTROY:
			if (hFile) _lclose(hFile);
			DeleteObject(hNewFont);
			PostQuitMessage (0);
			break ;

		default:
			return DefWindowProc (hWnd, iMessage, wParam, lParam);
		}
	return 0L ;
	}
