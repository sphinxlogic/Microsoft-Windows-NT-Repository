/*  
 *  FileName: WNDPROC.C                                                       
 *                                                                            
 *  Source file for the application's window procedure and About Box.         
 *                                                                            
 *  Description of Functions:                                                 
 *      StretchBitmap ()- Stretches the ball's bitmap 
 *      ResizeClient()  - Resizes the CLIENT's window whenever the            
 *                        application's window is resized.                    
 *      MainWndProc()   - The application's window procedure that processes   
 *                        all messages passed to it.                          
 *      FillMyAboutBox()- Fills in the details of window's AboutBox.          
 *      About ()        - AboutBox's window procedure                         
 *                                                                            
 *  Developed by:  Lanie Biagan                                               
 *  Written by Microsoft Product Support Services, Windows Developer Support  
 *                                                                            
 *  Copyright (C) 1991 Microsoft Corporation.  All rights reserved.           
 */
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <WINDOWS.H>
#include <DDEML.H>
#include <STDLIB.H>
#include <STDIO.H>
#include "BALLSRV.H"
#include "GLOBALS.H"
#include "DDEPROC.H"
#include "WNDPROC.H"                              

#define VER_MAJOR   1          
#define VER_MINOR   0
#define GETHINST( hWnd ) (GetWindowWord( hWnd, GWW_HINSTANCE ))

  
HDC     hDC; 
HBITMAP hBmpBall=NULL,  hBmpStretchedBall=NULL,
        hBmpBall2=NULL, hBmpStretchedBall2=NULL;
int     cxFrame, cyFrame, cyMenu,cyCaption;
float   someIncrement,
        someIncrement2;
float   x1Center,  y1Center, x2Center, y2Center,
        cx1Move,   cy1Move,  cx2Move,  cy2Move,
        cx1Total,  cy1Total, cx2Total, cy2Total;
BOOL    DrawMyBall     = TRUE, 
        DrawOtherBall  = FALSE;
BOOL    bStopAdvising  = TRUE,
        bStopAdvising2 = TRUE,
        SentMessage    = FALSE,
        SentMessage2   = TRUE;
short   SpeedDiv=DivFast;
short   cxRadius, cyRadius,
        cxClient, cyClient;


/***********************************************************************
 *  Title:                                                                    
 *      StretchBitmap ()                                                      
 *                                                                            
 *  Parameters:                                                               
 *      hBmpBall        - Handle to original ball bitmap                      
 *      nWidth          - Stretched bitmap width                              
 *      nHeight         - Stretched bitmap height                             
 *                                                                            
 *  Purpose:                                                                  
 *      Stretched the ball's bitmap whenever the SERVER gets resized.         
 ***********************************************************************/

HBITMAP StretchBitmap (HBITMAP hBmpBall, int nWidth, int nHeight)
{
  HDC   hMemoryDC, hMemoryDC2;
  HBITMAP  hOldBitmap, hOldBitmap2, hBmpStretchedBall;

  hBmpStretchedBall = CreateCompatibleBitmap (hDC, nWidth,nHeight);

  hMemoryDC   = CreateCompatibleDC (hDC);
  hOldBitmap  = SelectObject (hMemoryDC, hBmpBall);
  hMemoryDC2  = CreateCompatibleDC (hDC);
  hOldBitmap2 = SelectObject (hMemoryDC2, hBmpStretchedBall);

  SetStretchBltMode(hMemoryDC2, COLORONCOLOR);
  StretchBlt (hMemoryDC2, 0, 0, nWidth, nHeight,
              hMemoryDC,  0, 0, 72,72, SRCCOPY);
 
  SelectObject (hMemoryDC, hOldBitmap);
  DeleteDC (hMemoryDC);
  SelectObject (hMemoryDC2, hOldBitmap2);
  DeleteDC (hMemoryDC2);

  return (hBmpStretchedBall);
}

/***********************************************************************
 *  Title:                                                                    
 *      ResizeClient ()                                                       
 *                                                                            
 *  Parameters:                                                               
 *      wParam          - Derived from WM_SIZE's passed wParam                
 *      dumWidth        - Window's new width                                  
 *      dumHeight       - Window's new height                                 
 *                                                                            
 *  Purpose:                                                                  
 *      Resizes the clien't window, whenever the SERVER's gets resized.       
 ***********************************************************************/

void ResizeClient (WORD wParam)
{
   HWND     hOtherWindow;
   RECT     r;

   hOtherWindow = FindWindow ("ClientClass",     // Name of the window's class
                              "CLIENT App");     // Window's caption
   if (hOtherWindow)
   {                                        
      // if Window is to be iconized, things are handled differently.
      if (wParam == SIZEICONIC)
        ShowWindow (hOtherWindow, SW_MINIMIZE); 
      else
      {
        // if Window to be resized is coming from an ICONIZED or
        // MAXIMIZED state, we'll have to RESTORE it first.
        if (IsIconic(hOtherWindow) || IsZoomed(hOtherWindow))
          ShowWindow (hOtherWindow, SW_RESTORE);

        // Get window's new dimensions to be used in resizing below.
        GetWindowRect (ghWnd, &r);

        SetWindowPos (hOtherWindow, NULL, r.right + 15, 
                                          r.top,
                      r.right - r.left,      // new window's width
                      r.bottom - r.top,      // new window's height
                      SWP_DRAWFRAME| SWP_NOACTIVATE| SWP_NOZORDER);
        
        ShowWindow (hOtherWindow, SW_SHOWNA);  
      }  
    }  
}

/***********************************************************************
 *  Title:                                                                    
 *      MainWndProc                                                           
 *                                                                            
 *  Parameters:                                                               
 *      hWnd            - Handle to the message's destination window          
 *      wMessage        - Message number of the current message               
 *      wParam          - Additional info associated with the message         
 *      lParam          - Additional info associated with the message         
 *                                                                            
 *  Purpose:                                                                  
 *      This is the window procedure for the application's main window.       
 ***********************************************************************/

long FAR PASCAL MainWndProc(HWND    hWnd,       
			    UINT    wMessage,
			    WPARAM  wParam,
			    LPARAM  lParam)
{
    FARPROC lpProcAbout;
    
    
    switch (wMessage)
        {
         static short    xPixel,   yPixel;
                         
         static short    oldX = -100, oldX2=-100,
                         oldY = -100, oldY2=-100;
         static HANDLE   hIcon;
                HMENU    hMenu;
                short    nScale;
         static HMENU    hSpeedMenu;

         case WM_CREATE:
         
            cxFrame  = GetSystemMetrics (SM_CXFRAME);
            cyFrame  = GetSystemMetrics (SM_CYFRAME);
            cyCaption= GetSystemMetrics (SM_CYCAPTION);
            cyMenu   = GetSystemMetrics (SM_CYMENU);
            
         
            hMenu = GetSystemMenu (hWnd, FALSE);
            AppendMenu (hMenu, MF_SEPARATOR, 0, NULL);
	    AppendMenu (hMenu, MF_STRING, IDM_ABOUT, "&About DDEML BALLSRV");
         
            
            hSpeedMenu = GetSubMenu (GetMenu (hWnd), 0);   // Get a handle to the Speed menu.
            CheckMenuItem (hSpeedMenu, IDM_FAST,           // Server's Speed defaults to FAST 
                           MF_BYCOMMAND | MF_CHECKED);
            
            hIcon = LoadIcon(ghInstance, "LBIcon");        // This icon will be used only for dragging
                      
         
            hDC         = GetDC (hWnd);

            xPixel      = GetDeviceCaps (hDC, ASPECTX);
            yPixel      = GetDeviceCaps (hDC, ASPECTY);
           
            ReleaseDC (hWnd, hDC);
            
            if (hBmpBall)
               DeleteObject (hBmpBall);
               
            hBmpBall    = LoadBitmap (ghInstance, "Ball1Bmp");
            hBmpBall2   = LoadBitmap (ghInstance, "OtherBallBmp");
            
            someIncrement  = (float)IncrFast;
            someIncrement2 = (float)IncrMedium;

            break;   
         
         case WM_QUERYDRAGICON:
           return (LONG)(WORD)hIcon;

         case WM_GETMINMAXINFO:      // Sent before window is resized           
            {
            LPPOINT lpptTemp;       // Pointer to allow clean array access
            
            lpptTemp = (LPPOINT) lParam;    // Initialize the array pointer
            
            lpptTemp [3].x = 100;      // minimum width
            lpptTemp [3].y = 100;      //         height
            lpptTemp [4].x = 200;      // maximum width
            lpptTemp [4].y = 500;      //         height
            }
            break;                  // Break so that non-default value is used

         // Move CLIENT's window when SERVER's window is moved.
         case WM_MOVE:
         {
             HWND     hOtherWindow;
             int      xPos, yPos;
             RECT     r;
                                                                                                 
             hOtherWindow = FindWindow ("ClientClass",   // Name of the window's class  
                                        "CLIENT App");   // Window's caption           
                                    
                                        
             if ((!hOtherWindow) ||
                 (IsIconic (hWnd)) ||
                 (IsIconic (hOtherWindow))
                )
               return (DefWindowProc(hWnd, wMessage, wParam, lParam));
             
             xPos = LOWORD (lParam) + cxFrame + cxClient + 15;
             yPos = HIWORD (lParam) - (cyMenu + cyCaption + cyFrame);                           

             GetWindowRect (hWnd, &r);
               
             if (hOtherWindow)
             SetWindowPos (hOtherWindow, NULL, r.right + 15, r.top,
                                         r.right  - r.left,    // Same window's width
                                         r.bottom - r.top,     // Same window's heig
                                         SWP_DRAWFRAME| SWP_NOACTIVATE| SWP_NOZORDER);
               
            
             return (DefWindowProc(hWnd, wMessage, wParam, lParam));  
         }
      
         case WM_SIZE:
             // Resize SERVER window whenever client is resized.
             ResizeClient (wParam);         

             hDC = GetDC (hWnd);

   // Clear client area everytime window gets resized.
             if ((oldX != -100) && (oldY != -100))          // This is supposed to take care of
             {                                              // bug where if ball is at the edge of window
                if ((DrawMyBall) &&                         // and window gets resized, ball appears
                    ((x1Center + cxRadius > cxClient) &&    // on both windows.
                     (cx1Move > 0)))
                  DrawMyBall = FALSE;

                if ((DrawOtherBall) && 
                    ((x2Center + cxRadius >= cxClient) &&
                     (cx2Move > 0)))
                  DrawOtherBall = FALSE;
             }

   // Update variables (associated with PURPLE ball) 
   // whenever SERVER's window gets resized.            

             cxClient = LOWORD (lParam);
             cyClient = HIWORD (lParam);
            
             PatBlt (hDC, 0, 0, cxClient, cyClient, BLACKNESS);
             
             nScale = min (cxClient * xPixel, cyClient * yPixel) / 8;

             cxRadius = nScale / xPixel ;
             cyRadius = nScale / yPixel ;
             
             x1Center = cxRadius;
             y1Center = cyRadius;
             
             cx1Move = max (1, cxRadius / SpeedDiv);
             cy1Move = someIncrement; 

             cx1Total = 2 * (cxRadius + max (1, cxRadius/DivFast)) ;
             cy1Total = 2 * (cyRadius + max (1, cyRadius/DivFast)) ;
             

// STRETCH (or COMPRESS, as the case may be) Purple Ball bitmap accordingly. 
             hBmpStretchedBall = StretchBitmap (hBmpBall, (int)cx1Total,
                                                          (int)cy1Total);
            
             
   // Update variables (associated with PURPLE ball) 
   // whenever SERVER's window gets resized.            

             x2Center = cxClient - cxRadius;
             y2Center = cyRadius; //cyClient / 4;
             
             cx2Move = -max (1, cxRadius / SpeedDiv);

             cx2Total = 2 * (cxRadius + max (1, cxRadius/DivFast)) ;
             cy2Total = 2 * (cyRadius + max (1, cyRadius/DivFast)) ;
             
   // STRETCH (or COMPRESS, as the case may be) Green Ball bitmap accordingly. 
             hBmpStretchedBall2 = StretchBitmap (hBmpBall2, (int)cx2Total,
                                                            (int)cy2Total);
            
            
            
            
             ReleaseDC (hWnd, hDC);

             if (DrawMyBall)    SentMessage = FALSE;
             if (DrawOtherBall) SentMessage2 = FALSE;
             break;
               

         case WM_TIMER:
         {
             HDC      hMemoryDC;
             HBITMAP  hOldBitmap;


             // if (hConvServer) means CLIENT already established a conversation
             //                  with the SERVER.  The SERVER, then takes that as
             //                  a hint that the CLIENT is already available for a
             //                  a conversation with him, and tries to re-connect
             //                  with him.
             // if (!hConvClient) means that the SERVER tried to connect with the
             //                   CLIENT before (see InitProc.c) but didn't get a
             //                   valid handle.  SERVER tries again at this point.
             if ((hConvServer) && (!hConvClient))
               DdeML_ConnectWithClient (hWnd);
             
         // SERVER:  Is the PURPLE Ball currently bouncing in my window?    
         //          If it isn't, we dont BLT its bitmap here.
             if (DrawMyBall)
             {
              
               if (!hBmpStretchedBall)
                 break;
          
               hDC=GetDC (hWnd);
          
               PatBlt (hDC, oldX, oldY, (int)cx1Total, (int)cy1Total, BLACKNESS);
          
               oldX = (int)(x1Center - cx1Total / 2);
               oldY = (int)(y1Center - cy1Total / 2);
          

               hMemoryDC = CreateCompatibleDC (hDC);
               hOldBitmap= SelectObject (hMemoryDC, hBmpStretchedBall);
               
               BitBlt (hDC, oldX, oldY, (int)cx1Total, (int)cy1Total, 
                       hMemoryDC, 0,0, SRCCOPY);
               
             
            
               x1Center += cx1Move;
               y1Center += cy1Move;

               cy1Move  += someIncrement;               
               
               
               if (hConvServer)
               {
                 if ((!bStopAdvising) && 
                     (x1Center + cxRadius >= cxClient) && 
                     (!SentMessage))
                 {
                   SentMessage = TRUE;

    // SERVER:  Okay, the PURPLE BALL is about to bounce onto the CLIENT's window.
    // Refer to DdeCallback's XTYP_ADVREQ hszFS_1 case in DdeProc.C
    // for actual passing off data to the CLIENT.

                   if (!DdePostAdvise (idInst, hszTopicName, hszFS_1))
                     DdeML_HandleError ();

                 }  
                 if (x1Center  >= cxClient + 2*cxRadius) 
                 {
                   PatBlt (hDC, oldX, oldY, (int)cx1Total, (int)cy1Total, BLACKNESS);                 
                   DrawMyBall = FALSE;
                   SentMessage = FALSE;
                 } 
               }
               else if (x1Center + cxRadius >= cxClient )
                 cx1Move = -cx1Move;
                 
               if (x1Center - cxRadius <= 0)
               {
                 cx1Move   = -cx1Move ;
                 SentMessage = FALSE;
               }

                

               if ((y1Center + cyRadius >= cyClient) && (cy1Move > 0))
                 {
                 cy1Move  = -cy1Move;
                 //y1Center += cy1Move ;
                 }
                 
               //cy1Move  += someIncrement;

               if ((y1Center+cy1Move+someIncrement - cyRadius <= 0) && (cy1Move  < 0))
                  cy1Move = 0;   


               SelectObject (hMemoryDC, hOldBitmap);
               DeleteDC  (hMemoryDC);   
               ReleaseDC (hWnd, hDC);   
             }   
              

         // SERVER:  Is the GREEN Ball currently bouncing in my window?    
         //          If it isn't, we dont BLT its bitmap here.
             if (DrawOtherBall)
             {
              
               if (!hBmpStretchedBall2)
                 break;
          
               hDC=GetDC (hWnd);
               PatBlt (hDC, oldX2, oldY2, (int)cx2Total, (int)cy2Total, BLACKNESS);
               
               oldX2= (int)(x2Center - cx2Total / 2);
               oldY2= (int)(y2Center - cy2Total / 2);
          

               hMemoryDC = CreateCompatibleDC (hDC);
               hOldBitmap= SelectObject (hMemoryDC, hBmpStretchedBall2);
                
               BitBlt (hDC, oldX2, oldY2, (int)cx2Total, (int)cy2Total, 
                       hMemoryDC, 0,0, SRCCOPY);
               
             
            
               x2Center += cx2Move;
               y2Center += cy2Move;
               cy2Move  += someIncrement2;
               
             
               if (hConvServer)
               {
                 if ((!bStopAdvising) && 
                     (x2Center + cxRadius >= cxClient) && 
                     (!SentMessage2))
                 {
                   SentMessage2 = TRUE;

    // SERVER:  Okay, the GREEN BALL is about to bounce back to the CLIENT's window.
    // Refer to DdeCallback's XTYP_ADVREQ hszFS_2 case in DdeProc.C
    // for actual passing off data to the CLIENT.

                   if (!DdePostAdvise (idInst, hszTopicName, hszFS_2))
                     DdeML_HandleError ();

                 }  
                 if (x2Center  >= cxClient + 2*cxRadius) 
                 {
                   PatBlt (hDC, oldX2, oldY2, (int)cx2Total, (int)cy2Total, BLACKNESS);
                   DrawOtherBall = FALSE;
                   SentMessage2 = FALSE;
                 }  
               }

               if (x2Center - cxRadius <= 0)
               {
                 cx2Move   = -cx2Move ;
                 SentMessage2 = FALSE;
               }

  
               if ((y2Center + cyRadius >= cyClient) && (cy2Move > 0)) 
               {
                  cy2Move = -cy2Move ;   
               //   y2Center += cy2Move;
               }
               
               //cy2Move  += someIncrement2;
               
               if ((y2Center+cy2Move+someIncrement2 - cyRadius <= 0) && (cy2Move < 0))
                  cy2Move = 0;
                  
               SelectObject (hMemoryDC, hOldBitmap);
               DeleteDC  (hMemoryDC);   
               ReleaseDC (hWnd, hDC);   

             }   
             break;

         }      
               
             
         case WM_SYSCOMMAND:
            switch (wParam)
            {
              // About Box option selected from SysMenu.
              case IDM_ABOUT:
                lpProcAbout = MakeProcInstance(AboutBox, ghInstance);

                DialogBox(ghInstance,
                    "AboutBox",
                    hWnd,
                    lpProcAbout);

                FreeProcInstance(lpProcAbout);
                break;
                
              default:
                return (DefWindowProc(hWnd, wMessage, wParam, lParam));  
            
            }
            break;
            
               
         case WM_COMMAND:
         {
            if ((wParam==IDM_SLOW)   ||
                (wParam==IDM_MEDIUM) ||
                (wParam==IDM_FAST))
             {
                 // Uncheck all the items...
                 CheckMenuItem (hSpeedMenu, IDM_SLOW,  MF_BYCOMMAND | MF_UNCHECKED);
                 CheckMenuItem (hSpeedMenu, IDM_MEDIUM,MF_BYCOMMAND | MF_UNCHECKED);
                 CheckMenuItem (hSpeedMenu, IDM_FAST,  MF_BYCOMMAND | MF_UNCHECKED);

                 // ...and just check the selected one 
                 CheckMenuItem (hSpeedMenu, wParam,
                                MF_BYCOMMAND | MF_CHECKED);
             }
             
            switch (wParam)
            {
        
              case IDM_ABOUT:
                lpProcAbout = MakeProcInstance(AboutBox, ghInstance);

                DialogBox(ghInstance,
                    "AboutBox",
                    hWnd,
                    lpProcAbout);

                FreeProcInstance(lpProcAbout);
                break;
            
                                
              case IDM_SLOW:
                SpeedDiv = DivSlow;
                if (cx1Move > 0) cx1Move =  max (1, cxRadius / DivSlow);
                            else cx1Move = -max (1, cxRadius / DivSlow);
                someIncrement = (float)IncrSlow;           

    // SERVER:  Okay, the PURPLE ball's speed has changed to SLOW.
    //          Refer to DdeCallback's XTYP_ADVREQ hszFS_3 case in DdeProc.C
    //          for actual passing off data to the CLIENT.

                if ((!bStopAdvising) && (!DrawMyBall))
                {
                  if (!DdePostAdvise (idInst, hszTopicName, hszFS_3))
                     DdeML_HandleError ();
                }

                break;
                
              case IDM_MEDIUM:
                SpeedDiv = DivMedium; 
                if (cx1Move > 0) cx1Move =  max (1, cxRadius / DivMedium);
                            else cx1Move = -max (1, cxRadius / DivMedium);
                someIncrement = (float)IncrMedium;           
               
    // SERVER:  Okay, the PURPLE ball's speed has changed to MEDIUM.
    //          Refer to DdeCallback's XTYP_ADVREQ hszFS_3 case in DdeProc.C
    //          for actual passing off data to the CLIENT.

                if ((!bStopAdvising) && (!DrawMyBall))
                  if (!DdePostAdvise (idInst, hszTopicName, hszFS_3))
                     DdeML_HandleError ();
                    
                break;  
                
              case IDM_FAST:
                SpeedDiv = DivFast;
                if (cx1Move > 0) cx1Move =  max (1, cxRadius / DivFast);
                            else cx1Move = -max (1, cxRadius / DivFast);
                someIncrement = (float)IncrFast;           
               
    // SERVER:  Okay, the PURPLE ball's speed has changed to FAST.
    //          Refer to DdeCallback's XTYP_ADVREQ hszFS_3 case in DdeProc.C
    //          for actual passing off data to the CLIENT.

                if ((!bStopAdvising) && (!DrawMyBall))
                  if (!DdePostAdvise (idInst, hszTopicName, hszFS_3))
                    DdeML_HandleError ();
                break;  
                
            
            default:
                return (DefWindowProc(hWnd, wMessage, wParam, lParam));
            }
            break;
        }    
        case WM_PAINT:
           return DefWindowProc(hWnd, wMessage, wParam, lParam);
                
        
        case WM_DESTROY:       

            if (hBmpBall)           DeleteObject (hBmpBall);
            if (hBmpStretchedBall)  DeleteObject (hBmpStretchedBall);            


            if (hBmpBall2)          DeleteObject (hBmpBall2);
            if (hBmpStretchedBall2) DeleteObject (hBmpStretchedBall2);   
            
            KillTimer (hWnd, 1);         // Stop the timer: Bouncing over!!
        
            DdeML_CleanupStuff (hWnd);   // DDEML exit routines here.
                                         // Defined in DDEProc.C 
        
        
            PostQuitMessage(0);   // Indicate that message loop should exit
            break;                //   since the main window is being destroyed

        default:                  // Pass message on for default proccessing
            return DefWindowProc(hWnd, wMessage, wParam, lParam);
        }

    // If we performed non-default processing on the message, return FALSE
    return FALSE;
 }
       

/***********************************************************************
 *  Title:                                                                    
 *      FillMyAboutBox ()                                                     
 *                                                                            
 *  Parameters:                                                               
 *      hDlg            - Handle to the message's destination window          
 *                                                                            
 *  Purpose:                                                                  
 *      Fills in the details of the window's About Box, such as the           
 *      developer's name and application's version number.                    
 ***********************************************************************/

void FillMyAboutBox (HWND hDlg)
{
    char   szBuffer[ 81 ], szTemp[ 81 ] ;

  LoadString( GETHINST( hDlg ), IDS_BYLINE, szBuffer, sizeof(szBuffer)) ;
  SetDlgItemText( hDlg, IDD_BYLINE, szBuffer ) ;
  LoadString( GETHINST( hDlg ), IDS_BYLINE2, szBuffer, sizeof(szBuffer)) ;
  SetDlgItemText( hDlg, IDD_BYLINE2, szBuffer ) ;

  // sets up version number for DDEML BALLSRV Sample
  
  GetDlgItemText( hDlg, IDD_VERSION, szTemp, sizeof( szTemp ) ) ;
  wsprintf( szBuffer, szTemp, VER_MAJOR, VER_MINOR) ;
  SetDlgItemText( hDlg, IDD_VERSION, (LPSTR) szBuffer ) ;

}

/***********************************************************************
 *  Title:                                                                  
 *      AboutBox()                                                            
 *                                                                            
 *  Parameters:                                                               
 *      hDlg            - Handle to the message's destination window          
 *      Message         - Message number of the current message               
 *      wParam          - Additional info associated with the message         
 *      lParam          - Additional info associated with the message         
 *                                                                            
 *  Purpose:                                                                  
 *      This is the window procedure for the application's About Box.         
 *  This particular About Box tries to simulate, also with a timer, the app's 
 *  bouncing ball, as its icon.   Bouncing is implemented much like the       
 *  application window does.                                                  
 ***********************************************************************/

BOOL FAR PASCAL AboutBox (HWND hDlg,
                          WORD message,
                          WORD wParam,
                          LONG lParam)
{
           HDC     hDC;
    static RECT    rect;
    static HDC     hMemoryDC2;
    static HBITMAP hBmpBall, hOldBitmap2;
    static int     nTimerID;       
    static HWND    hIconBlock;
    static short   cxRadius,cyRadius,
                   cxClient,cyClient,
                   xCenter, yCenter,
                   cxTotal, cyTotal,                   
                   cxMove,  cyMove;


    switch (message) 
    {
        case WM_INITDIALOG:
            nTimerID = SetTimer (hDlg, 1, 20, NULL);        // Start the timer.
            if (!nTimerID)                                
            {
               MessageBox (hDlg, "Too many clocks or timers!!",
                           NULL, MB_ICONEXCLAMATION|MB_OK);
               return FALSE;
            }

            // Fill in About Box details.
            FillMyAboutBox (hDlg);
    
            hBmpBall   = LoadBitmap (ghInstance, "SmallBmp");      // Load SmallBall bitmap
            hIconBlock = GetDlgItem (hDlg, IDD_PAINT);             // Get handle to Static Control for "Icon"
            GetClientRect (hIconBlock, &rect);                     // Get Static Control dimensions
            
            hDC = GetDC(hIconBlock);

            // Create a DC to store Ball bitmap    
            hMemoryDC2 = CreateCompatibleDC(hDC);                  

            ReleaseDC(hIconBlock, hDC);
            
            // Select SmallBall bitmap to DC; store in memory DC first
            // and blt later.
            hOldBitmap2 = SelectObject(hMemoryDC2,  hBmpBall);     

            // Initialize variables here, just like the app's main window proc.
            // did to implement its bouncing ball.
                                                        
            cxClient = (rect.right - rect.left) ;
            cyClient = (rect.bottom- rect.top);
        
            cxRadius = 10;
            cyRadius = 10;
            
            xCenter = cxRadius;
            yCenter = cyClient /2;
            
            cxMove = 1;  
            cyMove = 1;  
            
            cxTotal = 2 * (cxRadius + cxMove) ;
            cyTotal = 2 * (cyRadius + cyMove) ;
       
            return (TRUE);

        case WM_TIMER:
         {                  
             //Get a handle to the Icon Window's DC.
             hDC=GetDC (hIconBlock);

             // Blt the ball's bitmap onto the little icon window.
             BitBlt (hDC, max (0, (int)(xCenter - cxTotal / 2)), 
                          max (0, (int)(yCenter - cyTotal / 2)), 
                          (int)cxTotal, (int)cyTotal, 
                     hMemoryDC2, 0,0, SRCCOPY);

             ReleaseDC (hIconBlock,hDC);
             
            
             xCenter += cxMove;
             yCenter += cyMove;

             if ((xCenter + (cxRadius) >= cxClient) || (xCenter - (cxRadius) <= 0))
                cxMove = -cxMove ;
                
             if ((yCenter + (cyRadius) >= cyClient) || (yCenter - (cyRadius) <= 0))
                cyMove = -cyMove ;   
                
                
             break;
         }  

        case WM_COMMAND:
            if (wParam == IDOK  || wParam == IDCANCEL) 
            {
                EndDialog(hDlg, TRUE);
                return (TRUE);
            }
            break;
            
        case WM_DESTROY:
          KillTimer (hDlg, nTimerID);                // Stop the timer
          
          SelectObject(hMemoryDC2, hOldBitmap2);     // Select OldBitmap back to memory DC
          DeleteDC(hMemoryDC2);                      // Delete memory DC
           
          if (hBmpBall)
            DeleteObject (hBmpBall);                 // Clean up SmallBall bitmap
            
            
          break;
   
    }
    return (FALSE);
}


