/*
 *  FileName: BALLSRV.C
 *                                                                            
 *  Source file for the main message loop and the app's entry point.          
 *                                                                            
 *  Description of Functions:                                                 
 *                                                                            
 *      WinMain()     - program's entry point                                 
 *      DoMain()      - main message loop for the application.                
 *                                                                            
 *  Developed by:  Lanie Biagan                                               
 *  Written by Microsoft Product Support Services, Windows Developer Support  
 *                                                                            
 *  Copyright (C) 1991 Microsoft Corporation.  All rights reserved.           
 */
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <WINDOWS.H>
#include <DDEML.H>
#include "BALLSRV.H"
#include "INITPROC.H"
#include "WNDPROC.H"

//--- All global variables used in the app follows: --------------------------//
HWND    ghWnd;
HANDLE  ghInstance;

//--- DDEML-specific stuff... ------------------------------------------------//
DWORD   idInst=0;           // DDE instance identifier
FARPROC lpDdeProc;          // Callback procedure instance address
HSZ     hszAppName=NULL;    // Service Name
HSZ     hszTopicName;       // TopicName
HSZ     hszSvrAppName=NULL; // Service Name
HSZ     hszSvrTopicName;    // TopicName
HCONV   hConvServer;        // Handle to conversation as SERVER
HCONV   hConvClient;        // Handle to conversation as CLIENT

HSZ     hszFS_1;            // Item Name #1: FromServer (Purple Ball)
HSZ     hszFS_2;            // Item Name #2: FromServer (Green Ball)
HSZ     hszFS_3;            // Item Name #3: FromServer (Purple Ball speed chg)
HSZ     hszFS_4;            // Item Name #3: FromServer Window RESIZED
HSZ     hszFC_1;            // Item Name #1: FromClient (Green Ball)
HSZ     hszFC_2;            // Item Name #2: FromClient (Purple Ball)
HSZ     hszFC_3;            // Item Name #3: FromClient (Green Ball speed chg)


/***********************************************************************
 *  Title:                                                                   
 *      WinMain                                                              
 *                                                                           
 *  Parameters:                                                              
 *      hInstance       - Integer which uniquely identifies this instance    
 *                          of the application (hInstance > 0)               
 *      hPrevInstance   - Integer identifier of a previous instance of the   
 *                          application (hPrevInstance == NULL if no         
 *                          previous instance exists)                        
 *      lpszCmdLine     - Long pointer to command line info                  
 *      nCmdShow        - Integer value specifying how to start app         
 ***********************************************************************/
int PASCAL WinMain (    HANDLE hInstance,
                        HANDLE hPrevInstance, 
                        LPSTR  lpszCmdLine,
                        int    nCmdShow)
{
    int iResult;

    if (InitApplication(hInstance, hPrevInstance))
       if (InitInstance(hInstance, nCmdShow))
           iResult = DoMain();

    return iResult;
}



/***********************************************************************
 *  Title:                                                                 
 *      DoMain                                                             
 *                                                                         
 *  Parameters:                                                            
 *      None                                                               
 *                                                                         
 *  Purpose:                                                               
 *      This is the main message loop for the application.  It retrieves   
 *      messages from the application's message queue, and dispatches      
 *      the messages to the appropriate window procedure(s).               
 ***********************************************************************/
int  DoMain(void)
{
    MSG msg;
    
    while (GetMessage(  &msg,     // message structure   
                        NULL,     // handle of window receiving the message
                        NULL,     // lowest message to examine
                        NULL))    // highest message to examine
        {
        TranslateMessage(&msg);   // Translates virtual key codes
        DispatchMessage(&msg);    // Dispatches message to window procedure 
        }

    return ((int) msg.wParam);    // Returns the value from PostQuitMessage
}


