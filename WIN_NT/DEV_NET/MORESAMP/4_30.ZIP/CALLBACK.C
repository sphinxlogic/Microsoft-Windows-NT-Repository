//****************************************************************************
// File: callback.c
//
// Purpose: callback funtions including notification call back
//
// Functions:
//    MainWndProc - message handler for Main window
//    NotifyRegisterCallback - callback for NotifyRegister
//    AfterChildHasTerminated - code to be executed after child has terminated
//    AboutDlg    - dialog function for about box
//
// Development Team:
//     Vinoo Cherian
//
// Written by Microsoft Product Support Services, Windows Developer Support
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//****************************************************************************
#include <windows.h>
#include <toolhelp.h>
#include <stdlib.h>
#include "termwait.h"

// Globals
HTASK ghtaskParent;
BOOL bChildIsExecuting = FALSE;
HINSTANCE ghInstChild;

// Local function prototypes
BOOL FAR PASCAL NotifyRegisterCallback (WORD, DWORD);
BOOL CALLBACK AboutDlg (HWND , UINT, WPARAM, LPARAM);
void AfterChildHasTerminated(HWND);

//****************************************************************************
// Function: MainWndProc
//
// Purpose: Message handler for main overlapped window.
//
// Parameters:
//    hwnd    == Handle to _this_ window.
//    msg == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//
// History:  Date       Author              Reason
//           4/17/92    Vinoo Cherian       Created
//****************************************************************************
LRESULT CALLBACK MainWndProc (HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
   static LPFNNOTIFYCALLBACK lpfnCallback;
   
   switch (msg)
   {
      case WM_CREATE:      
         ghtaskParent = GetCurrentTask();
         return 0;
         
      case WM_COMMAND:
         switch (wParam)
         { 
            case IDM_WINEXECNOTEPAD:
            {      
               // Install notification callback
               lpfnCallback = (LPFNNOTIFYCALLBACK)MakeProcInstance((FARPROC)NotifyRegisterCallback, ghInst);
               if (!NotifyRegister(NULL, lpfnCallback, NF_NORMAL))
               {   
                   MessageBox(hwnd, "NotifyRegister Failed", "Error", MB_OK); 
                   FreeProcInstance(lpfnCallback);
                   break;
               }
              
               // Winexec child
               // bChildIsExecuting can used to determine if the child is executing.
               // Any code that should not be executed while the child is executing
               // can check the value of bChildIsExecuting. 
               bChildIsExecuting = TRUE;                   
               if ((ghInstChild = (HINSTANCE)WinExec("notepad.exe", SW_SHOW)) < 32 )
               {
                  char achMes[30];
                  
                  bChildIsExecuting = FALSE;
                  NotifyUnRegister(NULL);
                  FreeProcInstance(lpfnCallback);
                  wsprintf((LPSTR)achMes, "WinExec failed. Error code : %d", (int)ghInstChild);
                  MessageBox(hwnd, achMes,"Error", MB_OK);
                  break;
               }
               break;
            }

            case IDM_ABOUT:
            {
               DLGPROC lpDlgProc;
               char szAboutBoxName[STR_LEN];

               LoadString(ghInst, IDS_ABOUTBOXNAME, szAboutBoxName, STR_LEN);
               lpDlgProc = MakeProcInstance(AboutDlg, ghInst);

               DialogBox(ghInst, szAboutBoxName, hwnd, lpDlgProc);
               FreeProcInstance(lpDlgProc);
               break;
            }
         }
         return 0;

     
      case PM_TASKEND:
         // Child has terminated
         bChildIsExecuting = FALSE;
         NotifyUnRegister(NULL); 
         FreeProcInstance(lpfnCallback);
         // Do the processing that MUST be done after the child terminates
         AfterChildHasTerminated(hwnd);
         break;

      case WM_INITMENU:
         // Gray any menuitems that may cause reentrancy problems, while
         // waiting for the child to terminate
         if (bChildIsExecuting)
            EnableMenuItem((HMENU)wParam, IDM_WINEXECNOTEPAD, MF_GRAYED);
         else EnableMenuItem((HMENU)wParam, IDM_WINEXECNOTEPAD,  MF_ENABLED);
         break;
          
      case WM_DESTROY:
         PostQuitMessage(0);
         return 0;
   }
   return DefWindowProc(hwnd, msg, wParam, lParam);
}

//*************************************************************
//  NotifyRegisterCallback
//
//  Purpose: Callback procedure for NotifyRegister
//
//  Parameters:
//      wID  = Type of notification
//     dwData = data or pointer to data depending on value of wID
//
// Comments:
//
// History:  Date       Author              Reason
//           4/17/92    Vinoo Cherian       Created
//****************************************************************************

BOOL FAR PASCAL NotifyRegisterCallback (WORD wID, DWORD dwData)
{
    HTASK hTask;     // handle of the task that called the notification call back
    TASKENTRY te;
   
 
    // Check for task exiting
    switch (wID)
    {
       case NFY_EXITTASK:
          // Obtain info about the task that is terminating
          hTask = GetCurrentTask();
          te.dwSize = sizeof(TASKENTRY);
          TaskFindHandle(&te, hTask);
       
          // Check if the task that is terminating is our child task.   
          // Also check if the hInstance of the task that is terminating
          // in the same as the hInstance of the task that was WinExec'd by us
          // earlier in this file. This additional check is added because 
          // the Task List that is brought up by selecting 'Switch To ...'
          // from the system menu is also run as a child task of the application and
          // consequently the hInstance needs to be checked to determine which
          // child task is terminating.
            
          if (te.hTaskParent == ghtaskParent && te.hInst == ghInstChild)
             PostMessage(ghwnd, PM_TASKEND, (WORD)hTask, dwData );
          break;
          
        default:
           break;
    }

    // Pass notification to other callback functions
    return FALSE;

}

//****************************************************************************
// Function: AfterChildHasTerminated
//
// Purpose:  Code that MUST be executed after child has terminated
//
// Parameters:
//    hwnd == handle to window
//
// History:  Date       Author          Reason
//           4/17/92    Vinoo Cherian   Created
//****************************************************************************

void AfterChildHasTerminated(HWND hwnd)
{
   MessageBox(hwnd, "Notepad, which I launched, has been terminated",
              "Notification", MB_OK);
}

//****************************************************************************
// Function: AboutDlg
//
// Purpose:  About dialog box function.
//
// Parameters:
//    hwndDlg    == Handle to _this_ window.
//    msg == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           1/27/92                  Created
//****************************************************************************

BOOL CALLBACK AboutDlg (HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
   switch (msg)
   {
      case WM_INITDIALOG:
         return (TRUE);

      case WM_COMMAND:
         if ((wParam == IDOK) ||  // "OK" box selected?        
             (wParam == IDCANCEL))     // System menu close command?
         {
            EndDialog(hwndDlg, TRUE);     // Exits the dialog box 
            return (TRUE);
         }
         break;
   }

   return (FALSE); // Didn't process a message
}
