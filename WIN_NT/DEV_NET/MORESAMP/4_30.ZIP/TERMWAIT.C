//****************************************************************************
// File: termwait.c
//
// Purpose: Contains main message loop, application entry point and intialization functions
//
// Functions:
//    WinMain() - initializes everything and enters message loop
//    InitApplication() - registers the window class for first instance of app
//    InitInstance() - creates and displays main window
//
//
// Development Team:
//     Vinoo Cherian
//
// Written by Microsoft Product Support Services, Windows Developer Support
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//****************************************************************************

#include <windows.h>
#include <toolhelp.h>
#include "termwait.h"

// Local function prototypes.
int PASCAL WinMain (HINSTANCE, HINSTANCE, LPSTR, int);
BOOL InitApplication (HINSTANCE);
BOOL InitInstance (HINSTANCE, int);

//Globals

HINSTANCE ghInst;
HWND ghwnd;
char szWndClassName[STR_LEN];
char szTitle[STR_LEN];
char szMenuName[STR_LEN];
char szIconName[STR_LEN];


//***********************************************************************
// Function: WinMain
//
// Purpose: Called by Windows on app startup.  Initializes everything,
//          and enters a message loop.
//
// Parameters:
//    hInstance     == Handle to _this_ instance.
//    hPrevInstance == Handle to last instance of app.
//    lpCmdLine     == Command Line passed into app.
//    nCmdShow      == How app should come up (i.e. minimized/normal)
//
// Returns: Return value from PostQuitMessage.
//
// Comments:
//
// History:  Date       Author          Reason
//           4/17/92    Vinoo Cherian   Created
//****************************************************************************

int PASCAL WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
   MSG msg;

   LoadString(hInstance, IDS_WNDCLASSNAME, szWndClassName, STR_LEN);
   LoadString(hInstance, IDS_PROGNAME, szTitle, STR_LEN);
   LoadString(hInstance, IDS_MAINMENUNAME, szMenuName, STR_LEN);
   LoadString(hInstance, IDS_ICONNAME, szIconName, STR_LEN);
   
   if (!hPrevInstance)
      if (!InitApplication(hInstance))
         return (FALSE);

   if (!InitInstance(hInstance, nCmdShow))
      return (FALSE);

   while (GetMessage(&msg, NULL, NULL, NULL))
   {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   }
   
   // If the child task is still executing and this application
   // has been terminated, restore the default notification handler
   if (bChildIsExecuting)                 
     NotifyUnRegister(NULL);

   return (msg.wParam); // Returns the value from PostQuitMessage
}

//****************************************************************************
// Function: InitApplication
//
// Purpose: Called by WinMain on first instance of app.  Registers
//          the window class.
//
// Parameters:
//    hInstance == Handle to _this_ instance.
//
// Returns: TRUE on success, FALSE otherwise.
//
// Comments:
//
// History:  Date       Author          Reason
//           4/17/92    Vinoo Cherian   Created
//****************************************************************************

BOOL InitApplication (HINSTANCE hInstance)
{
   WNDCLASS wc;


   wc.style = 0;
   wc.lpfnWndProc = MainWndProc;
   wc.cbClsExtra = 0;
   wc.cbWndExtra = 0;
   wc.hInstance = hInstance;
   wc.hIcon = LoadIcon(hInstance, szIconName);
   wc.hCursor = LoadCursor(NULL, IDC_ARROW);
   wc.hbrBackground = COLOR_WINDOW + 1;
   wc.lpszMenuName = szMenuName;
   wc.lpszClassName = szWndClassName;
     
   return RegisterClass(&wc);
 
}

//****************************************************************************
// Function: InitInstance
//
// Purpose: Called by WinMain on instance startup.  Creates and
//            displays the main, overlapped window.
//
// Parameters:
//    hInstance     == Handle to _this_ instance.
//    nCmdShow      == How app should come up (i.e. minimized/normal)
//
// Returns: TRUE on success, FALSE otherwise.
//
// Comments:
//
// History:  Date       Author           Reason
//           4/17/92    Vinoo Cherian    Created
//****************************************************************************

BOOL InitInstance (HINSTANCE hInstance, int nCmdShow)
{
  
   ghInst = hInstance;
   // Create Main Window
   ghwnd = CreateWindow(szWndClassName, szTitle,
                       WS_OVERLAPPEDWINDOW,
                       CW_USEDEFAULT, CW_USEDEFAULT,
                       500, 400,
                       NULL, NULL, hInstance, NULL);
   if (!ghwnd)
      return FALSE;
   
   ShowWindow(ghwnd, nCmdShow);    // Show the window                        
   UpdateWindow(ghwnd);  // Sends WM_PAINT message
}
