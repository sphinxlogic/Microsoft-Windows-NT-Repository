// -----------------------------------------------------------------
// File name:  INIT.C
//
// This file contains the application's initialization code.
//
// Description of functions:
//
//    InitApplication   -  This function registers the application's
//                         main window class.
//    InitInstance      -  This function initializes an instance of
//                         the application by creating and displaying
//                         a window for for the new instance.
//
// Development Team:  Dan Ruder
//
// Written by Microsoft Product Support Services, Windows Developer Support.
//
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
// -----------------------------------------------------------------


#include <windows.h>
#include "globals.h"
#include "mainwnd.h"
#include "init.h"


   // Default string length
#define STR_LEN   50


//-----------------------------------------------------------------------
//  Function: InitApplication
//
//  Purpose : Called by WinMain on first instance of app.  Registers
//            the main window class of the application.
//
//  Parms   : hInst == Handle to _this_ instance
//
//  Returns : TRUE on success, FALSE otherwise.
//-----------------------------------------------------------------------

BOOL InitApplication (HANDLE hInst)
   {
   WNDCLASS  wc;
   char      szMenuName [STR_LEN];
   char      szClassName [STR_LEN];


   LoadString (hInst, IDS_MAINMENUNAME,  szMenuName,  STR_LEN);
   LoadString (hInst, IDS_MAINCLASSNAME, szClassName, STR_LEN);

   wc.style          = CS_HREDRAW |
                       CS_VREDRAW;
   wc.lpfnWndProc    = MainWndProc;
   wc.cbClsExtra     = 0;
   wc.cbWndExtra     = 0;
   wc.hInstance      = hInst;
   wc.hIcon          = LoadIcon (NULL, IDI_APPLICATION);
   wc.hCursor        = LoadCursor (NULL, IDC_ARROW);
   wc.hbrBackground  = COLOR_WINDOW + 1;
   wc.lpszMenuName   = szMenuName;
   wc.lpszClassName  = szClassName;


      // Register the window class and return success/failure code.

   return (RegisterClass (&wc));
   }


//-----------------------------------------------------------------------
//  Function: InitInstance
//
//  Purpose : Called by WinMain on instance startup.  Creates and
//            displays the main, overlapped window.
//
//  Parms   : hInstance     == Handle to _this_ instance
//            nCmdShow      == How app should come up (i.e. minimized/normal)
//
//  Returns : TRUE on success, FALSE otherwise.
//-----------------------------------------------------------------------

BOOL InitInstance (HANDLE hInstance,
                   int    nCmdShow)
   {
   HWND hWnd;
   char szTitle [STR_LEN];
   char szClassName [STR_LEN];


         // Load some necessary strings from the string table.

   LoadString (hInstance, IDS_PROGNAME,      szTitle,     STR_LEN);
   LoadString (hInstance, IDS_MAINCLASSNAME, szClassName, STR_LEN);


      // Create a main window for this application instance.

   hWnd = CreateWindow (szClassName,          // See RegisterClass() call
                        szTitle,              // Text for window title bar
                        WS_OVERLAPPEDWINDOW,  // Window style
                        CW_USEDEFAULT,        // Default horizontal position
                        CW_USEDEFAULT,        // Default vertical position
                        CW_USEDEFAULT,        // Default width
                        CW_USEDEFAULT,        // Default height
                        NULL,                 // Overlapped win has no parent
                        NULL,                 // Use the window class menu
                        hInstance,            // This instance owns this window
                        NULL);                // Pointer not used


      // Save the instance handle in static variable, which will be used in
      // many subsequence calls from this application to Windows.

   ghInst = hInstance;

      // We'll keep a global of the main window's handle.  This is useful
      //  for calls to MessageBox(), etc.

   ghWnd = hWnd;


      // If window could not be created, return "failure"

   if (!hWnd)
      return (FALSE);


      // Make the window visible; update its client area; and return "success"

   ShowWindow (hWnd, nCmdShow);           // Show the window
   UpdateWindow (hWnd);                   // Sends WM_PAINT message

   return (TRUE);
   }
