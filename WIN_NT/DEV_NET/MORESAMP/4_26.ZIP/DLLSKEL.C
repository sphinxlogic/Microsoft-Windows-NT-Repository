// -----------------------------------------------------------------
// File name:  DLLSKEL.C
//
// This is the main DLL source file.  It contains LibMain, the DLL's
// entry point.
//
// Description of functions:
//
//    LibMain          -  This DLL's entry point.  Analogous to WinMain.
//    PascalCallFunc   -  A function exported by this DLL that uses the
//                        Pascal calling convention
//    CCallFunc        -  A function exported by this DLL that uses the
//                        C calling convention
//
// Development Team:  Dan Ruder
//
// Written by Microsoft Product Support Services, Windows Developer Support.
//
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
// -----------------------------------------------------------------


#include<windows.h>
#include "dllskel.h"

// Global Variable to store the DLL's Instance handle

HANDLE ghDLLInst;


// -----------------------------------------------------------------
//
// Function: LibMain
//
// Purpose : This is the DLL's entry point.  It is analogous to WinMain
//           for applications.
//
// Params  : hInstance   ==  The handle to the DLL's instance.
//           wDataSeg    ==  Basically it is a pointer to the DLL's
//                           data segment.
//           wHeapSize   ==  Size of the DLL's heap in bytes.
//           lpszCmdLine ==  The command line passed to the DLL
//                           by Windows.  This is rarely used.
//
// Returns : 1 indicating DLL initialization is successful.
//
// Comments: LibMain is called by Windows.  Do not call it in your
//           application!
// -----------------------------------------------------------------

int FAR PASCAL LibMain (HANDLE hInstance,
                        WORD   wDataSeg,
                        WORD   wHeapSize,
                        LPSTR  lpszCmdLine)
   {
   ghDLLInst = hInstance;

   if (wHeapSize != 0)   // If DLL data seg is MOVEABLE
      UnlockData (0);

   return (1);
   }


// -----------------------------------------------------------------
//
// Function: PascalCallFunc
//
// Purpose : This is a simple function that shows how to declare a
//           function in a DLL so that the function can be called
//           by an application.
//           This function displays a message box to let the user know
//           that it has been called from a DLL by an application.
//
// Params  : None.
//
// Returns : Always returns TRUE.
//
// Comments: This function is an example of a function defined in
//           a DLL that gets called by an application.  Note that
//           that it is declared as FAR PASCAL.

//           All functions exported by DLLs must be declared as FAR
//           because they do not reside in the application's code
//           segment(s).  While functions that applications call are
//           not required to be declared as PASCAL, functions that
//           Windows calls must be both FAR and PASCAL.
// -----------------------------------------------------------------

int FAR PASCAL PascalCallFunc (void)
    {
    MessageBox (NULL, "This DLL function uses the Pascal calling convention",
                "PascalCallFunc()", MB_OK);
    return (TRUE);
    }


// -----------------------------------------------------------------
//
// Function: CCallFunc
//
// Purpose : This is a simple function that shows how to declare a
//           function in a DLL so that the function can be called
//           by an application.
//           This function displays a message box to let the user know
//           that it has been called from a DLL by an application.
//
// Params  : None.
//
// Returns : Always returns TRUE.
//
// Comments: This function is an example of a function defined in
//           a DLL that gets called by an application.  Because it
//           is declared as FAR instead of FAR PASCAL, it will use
//           the C calling convention.
//
//           All functions exported by DLLs must be declared as FAR
//           because they do not reside in the application's code
//           segment(s).  While functions that applications call are
//           not required to be declared as PASCAL, functions that
//           Windows calls must be both FAR and PASCAL.
// -----------------------------------------------------------------

int FAR CCallFunc (void)
    {
    MessageBox (NULL, "This DLL function uses the C calling convention",
                "CCallFunc()", MB_OK);
    return (TRUE);
    }
