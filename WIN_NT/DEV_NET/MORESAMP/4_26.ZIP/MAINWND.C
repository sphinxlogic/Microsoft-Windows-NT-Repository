// -----------------------------------------------------------------
// File name:  MAINWND.C
//
// This file contains the application's main window procedure, which
// responds to input to the application's main window.
//
// Description of functions:
//
//   MainWndProc     -     Responds to input to the application's main
//                         window
//   DoCommands      -     Processes WM_COMMAND messages sent to the
//                         application's main window
//
// Development Team:  Dan Ruder
//
// Written by Microsoft Product Support Services, Windows Developer Support.
//
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
// -----------------------------------------------------------------


#include <windows.h>
#include "globals.h"
#include "about.h"
#include "mainwnd.h"
#include "dllskel.h"

   // Local function prototypes.

LRESULT DoCommands (HWND   hWnd,
                    UINT   message,
                    WPARAM wParam,
                    LPARAM lParam);


//-----------------------------------------------------------------------
//  Function: MainWndProc
//
//  Purpose : Message handler for main, overlapped window.
//
//  Parms   : hWnd    == Handle to _this_ window
//            message == Message to process
//            wParam  == WORD parameter -- depends on message
//            lParam  == LONG parameter -- depends on message
//
//  Returns : Depends on message.
//-----------------------------------------------------------------------

LRESULT CALLBACK MainWndProc (HWND hWnd,
                              UINT message,
                              WPARAM wParam,
                              LPARAM lParam)
   {
   switch (message)
      {
         // Dispatch WM_COMMAND messages to our command handler, DoCommands().

      case WM_COMMAND:
         return (DoCommands (hWnd, message, wParam, lParam));


         // On WM_DESTROY, terminate this app by posting a WM_QUIT message.

      case WM_DESTROY:
         PostQuitMessage (0);
         break;


         // We didn't handle, pass to DefWindowProc.

      default:
         return (DefWindowProc (hWnd, message, wParam, lParam));
      }

   return (NULL);
   }


//-----------------------------------------------------------------------
//  Function: DoCommands
//
//  Purpose : Called by MainWndProc() to handle all WM_COMMAND type
//            messages.
//
//  Parms   : hWnd    == Handle to _this_ window
//            message == Message to process
//            wParam  == WORD parameter -- depends on message
//            lParam  == LONG parameter -- depends on message
//
//  Returns : Depends on message.
//-----------------------------------------------------------------------

LRESULT DoCommands (HWND   hWnd,
                    UINT   message,
                    WPARAM wParam,
                    LPARAM lParam)
   {
   switch (wParam)
      {
            // Put up the About box.

      case IDM_ABOUT:
         {
         FARPROC lpDlgProc;

         lpDlgProc = MakeProcInstance (AboutDlg, ghInst);

         DialogBox (ghInst,            // current instance
                    AboutBoxName,      // resource to use
                    hWnd,              // parent handle
                    lpDlgProc);        // About() instance address

         FreeProcInstance (lpDlgProc);
         break;
         }


         // User picked File.C Function.  Call a user-defined function.

      case IDM_CFUNC:
         CCallFunc();

         break;


         // User picked File.Pascal Function.  Call a user-defined function.

      case IDM_PASCALFUNC:
         PascalCallFunc();

         break;


         // User picked File.Exit, terminate this app.

      case IDM_EXIT:
         DestroyWindow (hWnd);
         break;


         // Must be some system command -- pass it on to the default
         // window procedure.

      default:
         return (DefWindowProc (hWnd, message, wParam, lParam));
      }

   return (NULL);
   }
