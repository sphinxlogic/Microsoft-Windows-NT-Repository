#define WIN31

#include "windows.h"
#include "penwin.h"
#include "video.h"
#include "Globals.h"

//**************************************************************************
//
//  Function: DrawNeedle
//
//  Purpose:  This function erases and draws the "needle" on the sliding
//	      scale.  If bErase is set to TRUE is erases the old needle
//	      and then draws the new one, else it only draws the new one.
//	      It's called from the processing of the mouse messages.
//
//  Returns:  TRUE
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      12/20/91	David Flenniken  Created
//
//*************************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
int NEAR PASCAL DrawNeedle(HDC hdc,BOOL bErase)
{
   int	  iOldFillMode;
   HBRUSH hOldBrush;
   HPEN   hOldPen;
   POINT  rgptLocNeedle[3];

   iOldFillMode=SetPolyFillMode(hdc,WINDING);

   if(bErase)
   {
      hOldPen=(HPEN)SelectObject(hdc,ghErasePen);
      hOldBrush=(HBRUSH)SelectObject(hdc,ghEraseBrush);

      rgptLocNeedle[0].x=gpts[0].x;
      rgptLocNeedle[0].y=gpts[0].y+giOldPos;
      rgptLocNeedle[1].x=gpts[1].x;
      rgptLocNeedle[1].y=gpts[1].y+giOldPos;
      rgptLocNeedle[2].x=gpts[2].x;
      rgptLocNeedle[2].y=gpts[2].y+giOldPos;

      Polygon(hdc,&rgptLocNeedle[0],3);

      SelectObject(hdc,hOldPen);
      SelectObject(hdc,hOldBrush);
   }

   hOldPen=(HPEN)SelectObject(hdc,ghDrawPen);
   hOldBrush=(HBRUSH)SelectObject(hdc,ghDrawBrush);

   rgptLocNeedle[0].x=gpts[0].x;
   rgptLocNeedle[0].y=gpts[0].y+giCurPos;
   rgptLocNeedle[1].x=gpts[1].x;
   rgptLocNeedle[1].y=gpts[1].y+giCurPos;
   rgptLocNeedle[2].x=gpts[2].x;
   rgptLocNeedle[2].y=gpts[2].y+giCurPos;

   Polygon(hdc,&rgptLocNeedle[0],3);

   SelectObject(hdc,hOldPen);
   SelectObject(hdc,hOldBrush);

   SetPolyFillMode(hdc,iOldFillMode);
   return (int)TRUE;
}


//**************************************************************************
//
//  Function: DrawScale(HDC hdc)
//
//  Purpose:  This function draws the scale for the needle to run up and
//	      Down on.	It's called from the WM_PAINT processing.
//
//  Returns:  TRUE
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      12/20/91	David Flenniken  Created
//
//*************************************************************************
int NEAR PASCAL DrawScale(HDC hdc)
{
   WORD wTextAlign;
   char szZero[MSG_SHORT];
   char szMax[MSG_SHORT];

   // Draw Vertical...
   MoveTo(hdc,gptTopCenter.x,gptTopCenter.y);
   LineTo(hdc,gptBotCenter.x,gptBotCenter.y);
   // Draw Top...
   MoveTo(hdc,gptLeftMost.x,gptTopCenter.y);
   LineTo(hdc,gptRightMost.x,gptTopCenter.y);
   // Draw Bottom...
   MoveTo(hdc,gptLeftMost.x,gptBotCenter.y);
   LineTo(hdc,gptRightMost.x,gptBotCenter.y);

   // write "Zero" & "Max"
   LoadString(ghInst,IDS_ZERO,(LPSTR)szZero,MSG_SHORT);
   LoadString(ghInst,IDS_MAX ,(LPSTR)szMax ,MSG_SHORT);

   wTextAlign=SetTextAlign(hdc,TA_RIGHT|TA_BOTTOM);
   TextOut(hdc,gptTextRight.x,
	   gptBotCenter.y+giTextCenter,
	   (LPSTR)szZero,lstrlen((LPSTR)szZero));
   SetTextAlign(hdc,TA_RIGHT|TA_TOP);
   TextOut(hdc,gptTextRight.x,
	   gptTopCenter.y-+giTextCenter,
	   (LPSTR)szMax,lstrlen((LPSTR)szMax));
   SetTextAlign(hdc,wTextAlign);
   return (int)TRUE;
}

// End-Of-File
