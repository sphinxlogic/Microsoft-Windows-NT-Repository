#define WIN31

#include "windows.h"
#include "penwin.h"
#include "globals.h"
#include "init.h"

//**************************************************************************
//
//  Function: WinMain
//
//  Purpose:  Entry point for program
//
//  Returns:  FALSE if error incountered
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      12/20/91	David Flenniken  Created
//
//*************************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HANDLE hInstance;
HANDLE hPrevInstance;
LPSTR lpCmdLine;
int nCmdShow;
{
   MSG msg;

   if (!hPrevInstance)
      if (!InitApplication(hInstance))
	 return (FALSE);

   if (!InitInstance(hInstance, nCmdShow))
      return (FALSE);

   while (GetMessage(&msg, NULL, NULL, NULL))
   {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   }

   return (msg.wParam);
}


//**************************************************************************
//
//  Function: InitApplication(HANDLE)
//
//  Purpose:  Register the class for the Window
//
//  Returns:  TRUE for FALSE
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      12/20/91	David Flenniken  Created
//
//*************************************************************************
BOOL InitApplication(hInstance)
HANDLE hInstance;
{
    char szClass[MSG_SHORT];
    char szMenu[MSG_SHORT];
    WNDCLASS  wc;

    LoadString(hInstance,IDS_CLASS,(LPSTR)szClass,MSG_SHORT);
    LoadString(hInstance,IDS_MENU, (LPSTR)szMenu, MSG_SHORT);

    wc.style          = NULL;
    wc.lpfnWndProc    = MainWndProc;
    wc.cbClsExtra     = (int)0;
    wc.cbWndExtra     = (int)0;
    wc.hInstance      = hInstance;
    wc.hIcon	      = LoadIcon(hInstance, MAKEINTRESOURCE(ID_ICON));
    wc.hCursor	      = LoadCursor(NULL, IDC_PEN);
    wc.hbrBackground  = GetStockObject(WHITE_BRUSH);
    wc.lpszMenuName   = (LPSTR)szMenu;
    wc.lpszClassName  = (LPSTR)szClass;

    return (RegisterClass(&wc));
}


//**************************************************************************
//
//  Function: InitInstance(HANDLE, int)
//
//  Purpose:  to create the Windows and show it.
//
//  Returns:  TRUE or FALSE
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      12/20/91	David Flenniken  Created
//
//*************************************************************************
BOOL InitInstance(hInstance, nCmdShow)
HANDLE          hInstance;
int             nCmdShow;
{
    char szClass[MSG_SHORT];
    char szTitle[MSG_NORMAL];

    ghInst = hInstance;

    LoadString(ghInst,IDS_CLASS,(LPSTR)szClass,MSG_SHORT);
    LoadString(ghInst,IDS_TITLE, (LPSTR)szTitle, MSG_NORMAL);

    ghwnd = CreateWindow(
	     (LPSTR)szClass,
	     (LPSTR)szTitle,
	     WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,
	     0,0,0,0,
             NULL,
             NULL,
             hInstance,
	     NULL );

    if ( !ghwnd )
        return ( FALSE );

    ShowWindow(ghwnd, nCmdShow);
    UpdateWindow(ghwnd);
    return (TRUE);
}

// End-of-File
