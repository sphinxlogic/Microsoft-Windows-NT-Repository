//***************************************************************************
//
// File name: MainWnd.c
//
// This source file provides the message function for PRESSURE.EXE.  It is
// designed to demonstrate one way of capturing pressure information from
// Windows for Pens using GetPenHwEventData().
//
// Description of functions:
//
//   InPenWin() - Loads Penwin.dll and gets the addresses to the functions
//		  that will be used throughout the program.
//   MainWndProc() - Main Window message function.
//
// Developed By: David Flenniken, Microsoft Windows Developer Support
//
// THE INFORMATION AND CODE PROVIDED HEREUNDER (COLLECTIVELY REFERRED TO
// AS "SOFTWARE") IS PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. IN
// NO EVENT SHALL MICROSOFT CORPORATION OR ITS SUPPLIERS BE LIABLE FOR
// ANY DAMAGES WHATSOEVER INCLUDING DIRECT, INDIRECT, INCIDENTAL,
// CONSEQUENTIAL, LOSS OF BUSINESS PROFITS OR SPECIAL DAMAGES, EVEN IF
// MICROSOFT CORPORATION OR ITS SUPPLIERS HAVE BEEN ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGES. SOME STATES DO NOT ALLOW THE EXCLUSION OR
// LIMITATION OF LIABILITY FOR CONSEQUENTIAL OR INCIDENTAL DAMAGES SO THE
// FOREGOING LIMITATION MAY NOT APPLY.
//
// This Software may be copied and distributed royalty-free subject to
// the following conditions:
//
// 1. You must copy all Software without modification and must include
//    all pages, if the Software is distributed without inclusion in your
//    software product. If you are incorporating the Software in
//    conjunction with and as a part of your software product which adds
//    substantial value, you may modify and include portions of the
//    Software.
//
// 2. You must place all copyright notices and other protective
//    disclaimers and notices contained on the Software on all copies of
//    the Software and your software product.
//
// 3. Unless the Software is incorporated in your software product which
//    adds substantial value, you may not distribute this Software for
//    profit.
//
// 4. You may not use Microsoft's name, logo, or trademarks to market
//    your software product.
//
// 5. You agree to indemnify, hold harmless, and defend Microsoft and its
//    suppliers from and against any claims or lawsuits, including
//    attorneys' fees, that arise or result from the use or distribution
//    of your software product and any modifications to the Software.
//
//**********************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#define WIN31

#include "windows.h"
#include "penwin.h"
#include "globals.h"
#include "mainwnd.h"

// If the following variable is defined this sample will display the current
// pressure reading and the needle position on a debug terminal.
//#define DEBUGGING

#ifdef DEBUGGING
char szOutput[MSG_NORMAL];
#endif

//****************************************************************************
//
// MainWndProc()
//
// Purpose: To handle the messages for PRESSURE.EXE
//
// Parameters: See standard Windows manual.
//
// Return Value: See standard Windows manual.
//
// Comments:
//
//   MESSAGES:
//
//	  WM_CREATE	 - See each message below.
//	  WM_LBUTTONDOWN
//	  WM_MOUSEMOVE
//	  WM_LBUTTONUP
//	  WM_SYSCOMMAND
//	  WM_PAINT
//	  WM_COMMAND
//	  WM_DESTROY
//
//
//	  WM_COMMAND processing:
//
//	      IDM_ABOUT  - display "About" box.
//
//****************************************************************************

LRESULT CALLBACK MainWndProc(hWnd, message, wParam, lParam)
HWND hWnd;
UINT message;
WPARAM wParam;
LPARAM lParam;
{
   switch ( message )
   {
      case WM_CREATE:
	 {
	    PENINFO    PenInfo;
	    BOOL       bPressure;
	    RECT       rectWin;

	    // determine if Running in Windows for Pens...
	    if(!InPenWin())
	       {
	       ErrorBox(IDS_NOPENWIN);
	       return -1;
	       }

	    // Open the pen driver....
	    if(!(hDriverPen=OpenDriver("pen",0,0)))
	    {
	       ErrorBox(IDS_NOPENWIN);
	       return -1;
	    }

	    // Check to see if the tablet supports pressure.
	    bPressure=FALSE;
	    if( LOWORD(SendDriverMessage(hDriverPen,
					 DRV_GetPenInfo,
					 (DWORD)(LPPENINFO)(&PenInfo),0)) )
	    {
	       // set the index into the OEM data. This will end up being
	       // the index to the Pressure location.
	       giOEMPressureIndex=0;
	       while(PenInfo.rgoempeninfo[giOEMPressureIndex].wPdt!=PDT_NULL)
	       {
		  if(PenInfo.rgoempeninfo[giOEMPressureIndex].wPdt=PDT_PRESSURE)
		  {
		     // giOEMPressureIndex now points the the pressure
		     // value location.  Now grab maximum pressure value
		     // for Window calculation.
		     giMaxPressure=PenInfo.rgoempeninfo[giOEMPressureIndex].wValueMax;

		     // and yes, the tablet supports pressure...
		     bPressure=TRUE;
		     break;
		  }
		  giOEMPressureIndex++;
	       }
	    }

	    if(!bPressure)    // tablet doesn't support presure
	    {
	       ErrorBox(IDS_NOPENWIN);
	       return -1;
	    }

	    // create Pen and Brush for needle
	    ghErasePen=CreatePen(PS_SOLID,1,RGB(255,255,255));
	    ghDrawPen=CreatePen(PS_SOLID,1,RGB(0,0,0));
	    ghEraseBrush=CreateSolidBrush(RGB(255,255,255));
	    ghDrawBrush=CreateSolidBrush(RGB(0,0,0));

	    InitializeData(&rectWin);

	    //position the Window in the center of the screen
	    MoveWindow(hWnd,rectWin.left,
			    rectWin.top,
			    rectWin.right,
			    rectWin.bottom,
			    FALSE);

	    // Set needle location, this is the rest position.
	    gpts[0].x=gptBotCenter.x+CX_TIP;
	    gpts[0].y=gptBotCenter.y+CY_TIP;
	    gpts[1].x=gptBotCenter.x+CX_BOTTOM;
	    gpts[1].y=gptBotCenter.y+CY_BOTTOM;
	    gpts[2].x=gptBotCenter.x+CX_TOP;
	    gpts[2].y=gptBotCenter.y+CY_TOP;

	    giCurPos=0;
	    giOldPos=0;
	 }
	 break;

      case WM_PAINT:
	 {
	    PAINTSTRUCT ps;
	    HDC  hdc;

	    hdc=BeginPaint(hWnd,&ps);

	    DrawScale(hdc);
	    DrawNeedle(hdc,TRUE);

	    EndPaint(hWnd,&ps);
	 }
	 break;


      case WM_LBUTTONDOWN:
      case WM_MOUSEMOVE:
      case WM_LBUTTONUP:
	 {
	    // Overview: If one of the above messages is generated from the
	    //		 PEN then update globals regarding the pressure
	    //		 information and draw the needle at the new location.

	    POINT      ptTmp;
	    STROKEINFO si;
	    DWORD      dwEventRef;
	    int        iCurPressure,i;
	    HDC        hdc;
	    OEMPENINFO rgTmpPI[MAXOEMDATAWORDS];

	    dwEventRef=GetMessageExtraInfo();
	    if(lpfnIsPenEvent(message,dwEventRef))
	    {
	       i=giCurPos;
	       lpfnGetPenHwEventData(LOWORD(dwEventRef),
				     LOWORD(dwEventRef),&ptTmp,
				     (LPVOID)&rgTmpPI,
				     1,&si);
	       iCurPressure=rgTmpPI[giOEMPressureIndex].wPdt;


	       giCurPos=-(int)(((long)iCurPressure*(long)SCALEHEIGHT)
						     /(long)giMaxPressure);
#ifdef DEBUGGING
	       wsprintf((LPSTR)szOutput,"Pressure: %i, Position: %i\n\r\0",
			iCurPressure,giCurPos);
	       OutputDebugString((LPSTR)szOutput);
#endif
	       if(i!=giCurPos)
	       {
		  hdc=GetDC(hWnd);
		  DrawNeedle(hdc,TRUE);
		  ReleaseDC(hWnd,hdc);
		  giOldPos=giCurPos;
	       }
	     }
	 }
	 break;

      case WM_COMMAND:
            switch ( wParam )
                {
		case IDM_ABOUT:
		   {
		     FARPROC	lpProcAbout;
		     char szStr[MSG_SHORT];

		     LoadString(ghInst,IDS_ABOUTBOX,(LPSTR)szStr,MSG_SHORT);
		     lpProcAbout = MakeProcInstance( About, ghInst );
		     DialogBox(ghInst, (LPSTR)szStr, hWnd, lpProcAbout);
		     FreeProcInstance( lpProcAbout );
		    }
		    break;
                }
	 break;
      case WM_DESTROY:
	 {
	    if(ghErasePen)
	       DeleteObject(ghErasePen);
	    if(ghDrawPen)
	       DeleteObject(ghDrawPen);
	    if(ghEraseBrush)
	       DeleteObject(ghEraseBrush);
	    if(ghDrawBrush)
	       DeleteObject(ghDrawBrush);

	    if(hDriverPen)
	       CloseDriver(hDriverPen,0,0);

	    PostQuitMessage(0);
	 }
	 break;

      case WM_SYSCOMMAND:
      // For looks, when the window is minimized the title is changed.
      // Same for Maximization.
	 {
	    WORD wTmp;

	    wTmp=wParam&0xFFF0;
	    switch(wTmp)
	    {
	       case SC_MINIMIZE:
		  {
		     char szTitle[MSG_SHORT];
		     LoadString(ghInst,IDS_MINTITLE,(LPSTR)szTitle,MSG_SHORT);
		     SetWindowText(hWnd,(LPSTR)szTitle);
		  }
		  break;
	       case SC_RESTORE:
		  {
		     char szTitle[MSG_NORMAL];
		     LoadString(ghInst,IDS_TITLE,(LPSTR)szTitle,MSG_NORMAL);
		     SetWindowText(hWnd,(LPSTR)szTitle);
		  }
		  break;
	    }
	    return(DefWindowProc(hWnd,message,wParam,lParam));
	 }
	 break;

      default:
	 return (DefWindowProc(hWnd, message, wParam, lParam));
   }

   return (NULL);
}

//**************************************************************************
//
//  Function: ErrorBox(WORD)
//
//  Purpose:  To display Error Messages
//
//  Returns:  void
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      12/20/91	David Flenniken  Created
//
//*************************************************************************
void FAR PASCAL ErrorBox(WORD wID)
{
   char szTitle[MSG_NORMAL];
   char szMsg[MSG_LONG];

   LoadString(ghInst,wID,      (LPSTR)szMsg,  MSG_LONG);
   LoadString(ghInst,IDS_TITLE,(LPSTR)szTitle,MSG_NORMAL);
   MessageBox(GetFocus(),
	      (LPSTR)szMsg,
	      (LPSTR)szTitle,
	      MB_ICONEXCLAMATION | MB_OK);
}

//**************************************************************************
//
//  Function: InPenWin(void)
//
//  Purpose:  To determine if we're currently in Windows for Pen Computing.
//	      If so, load the addresses of the functions that we want.
//	      If not, display an error message.
//
//  Returns:  TRUE on success, FALSE otherwise.
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      12/20/91	David Flenniken  Created
//
//*************************************************************************
BOOL FAR PASCAL InPenWin()
{
   HINSTANCE hPenWin;
   char szProc[MSG_NORMAL];

   if(hPenWin=(HANDLE)GetSystemMetrics(SM_PENWINDOWS))
   {
      // Get the address of GetPenHwEventData() and IsPenEvent()
      LoadString(ghInst,IDS_GETPENHWEVENTDATA,(LPSTR)szProc,MSG_NORMAL);
      if(!(lpfnGetPenHwEventData=(LPFNGETPENHWEVENTDATA)GetProcAddress(hPenWin,(LPSTR)szProc)))
	 return FALSE;
      LoadString(ghInst,IDS_ISPENEVENT,(LPSTR)szProc,MSG_NORMAL);
      if(!(lpfnIsPenEvent=(LPFNISPENEVENT)GetProcAddress(hPenWin,(LPSTR)szProc)))
	 return FALSE;
   }
   return TRUE;
}

//**************************************************************************
//
//  Function: InitializeData(LPRECT)
//
//  Purpose:  Determines the position of the scale in the client area along
//	      calculating the client area size.
//
//  Returns:  Returns the size of the window in lprect. Upper left hand
//	      corner, width and height.
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      1/10/91  David Flenniken	Created
//
//*************************************************************************
void FAR PASCAL InitializeData(LPRECT lprect)
{
   int	      iScrnWidth,iScrnHeight,iWinWidth,iWinHeight;
   HDC	      hdc;
   TEXTMETRIC tm;
   char       szTitle[MSG_NORMAL];


   // determine the title length and text metrics
   LoadString(ghInst,IDS_TITLE,(LPSTR)szTitle,MSG_NORMAL);
   hdc=GetDC(ghwnd);
   iWinWidth=LOWORD(GetTextExtent(hdc,(LPSTR)szTitle,
			     lstrlen((LPSTR)szTitle)));
   GetTextMetrics(hdc,&tm);
   ReleaseDC(ghwnd,hdc);

   // for centering text around top and bottom.
   giTextCenter=tm.tmHeight/2;

   // add mintrack to width
   iWinWidth+=GetSystemMetrics(SM_CXMINTRACK);

   // set window height
   iWinHeight=GetSystemMetrics(SM_CYMINTRACK)+CY_CLIENTAREA;

   // position scale
   gptTopCenter.x=iWinWidth/2;
   gptTopCenter.y=CY_TOPOFSCALE;
   gptBotCenter.x=iWinWidth/2;
   gptBotCenter.y=CY_TOPOFSCALE+SCALEHEIGHT;

   gptLeftMost.x=gptTopCenter.x-CX_TOPOFSCALE;
   gptLeftMost.y=0;
   gptRightMost.x=gptTopCenter.x+CX_TOPOFSCALE;
   gptRightMost.y=0;

   gptTextRight.x=gptTopCenter.x-CX_RIGHTOFTEXT;
   gptTextRight.y=0;

   // get full screen dimensions
   iScrnWidth=GetSystemMetrics(SM_CXFULLSCREEN);
   iScrnHeight=GetSystemMetrics(SM_CYFULLSCREEN);

   // determine Window position.
   lprect->left  =iScrnWidth/2-iWinWidth/2;
   lprect->top	 =iScrnHeight/2-iWinHeight/2;
   lprect->right =iWinWidth;
   lprect->bottom=iWinHeight;
}



// End-Of-File
