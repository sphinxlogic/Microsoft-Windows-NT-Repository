//*-------------------------------------------------------------------------
//| Title:
//|     WNDPROC.C
//|
//| Contents:
//|     MainWndProc()
//*-------------------------------------------------------------------------

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <WINDOWS.H>
#include "WNDPROC.H"
#include "DynDlg.H"
#include "GLOBALS.H"

//*-------------------------------------------------------------------------
//| Title:
//|     MainWndProc
//|
//| Parameters:
//|     hWnd            - Handle to the message's destination window
//|     wMessage        - Message number of the current message
//|     wParam          - Additional info associated with the message
//|     lParam          - Additional info associated with the message
//|
//| Purpose:
//|     This is the window procedure for the application's main window.
//*-------------------------------------------------------------------------
LRESULT FAR PASCAL MainWndProc(HWND    hWnd,       
                               UINT    wMessage,   
                               WPARAM  wParam,     
                               LPARAM  lParam)     
{
    switch (wMessage)
        {

        case WM_COMMAND:
        {
            FARPROC lpProcDlg;

            if (wParam == IDM_ABOUT) {
                lpProcDlg = MakeProcInstance(AboutBox, ghInstance);

                DialogBox(ghInstance,
                    "AboutBox",
                    hWnd,
                    lpProcDlg);

                FreeProcInstance(lpProcDlg);
                break;
            }
            else
            if (wParam == IDM_DIALOG) {
                lpProcDlg = MakeProcInstance(SpecialDlgBox, ghInstance);

                DialogBox(ghInstance,
                    "SpecialDlgBox",
                    hWnd,
                    lpProcDlg);

                FreeProcInstance(lpProcDlg);
                break;
            }
            else
                return (LRESULT)(DefWindowProc(hWnd, wMessage, wParam, lParam));
        }

        case WM_DESTROY:          // sent when window about to be destroyed
            PostQuitMessage(0);   // Indicate that message loop should exit
            break;                //   since the main window is being destroyed

        default:                  // Pass message on for default proccessing
            return (LRESULT)DefWindowProc(hWnd, wMessage, wParam, lParam);
        }

    // If we performed non-default processing on the message, return FALSE
    return (LRESULT)FALSE;
}


BOOL FAR PASCAL AboutBox (HWND hDlg,
                          WORD message,
                          WORD wParam,
                          LONG lParam)
{

    switch (message) 
    {

        case WM_INITDIALOG:
            return (TRUE);
  
        case WM_COMMAND:
            if (wParam == IDOK  || wParam == IDCANCEL) 
            {
                EndDialog(hDlg, TRUE);
                return (TRUE);
            }
            break;
            
    }
    return (FALSE);
}

void ShowAllControls (HWND hDlg, int iFirst, int iLast, BOOL bShow)
{
  int  i;
  HWND hFrame;


  hFrame = GetDlgItem (hDlg, ID_FRAME);
  SendMessage (hFrame, WM_SETREDRAW, FALSE, 0L);

  for (i = iFirst; i < iLast; i++)
    ShowWindow (GetDlgItem (hDlg, i), bShow);

//InvalidateRect (hFrame, NULL, TRUE);
  SendMessage (hFrame, WM_SETREDRAW, TRUE, 0L);
}


void AddIconToListBox (HWND hDlg, LPSTR myStr, HICON hIcon)
{
   DWORD dwIndex;

   dwIndex = SendDlgItemMessage (hDlg, ID_LISTBOX, LB_ADDSTRING, 0, (LONG)myStr);
   if ((dwIndex != LB_ERR) && (dwIndex != LB_ERRSPACE))
     SendDlgItemMessage (hDlg, ID_LISTBOX, LB_SETITEMDATA, (WPARAM)dwIndex, MAKELONG (hIcon, 0));
} 


void DrawItem (HWND hDlg, LPDRAWITEMSTRUCT lpdis)
{
   char       szItemString [15];
   HICON      hIcon;
   int        cxIcon, cyIcon;
   RECT       lbRect, textRect;
   TEXTMETRIC tm;

   cxIcon = GetSystemMetrics (SM_CXICON);
   cyIcon = GetSystemMetrics (SM_CYICON);
   GetTextMetrics (lpdis->hDC, &tm);

   SendDlgItemMessage (hDlg, ID_LISTBOX, LB_GETTEXT, lpdis->itemID,
                      (LONG)(LPSTR)szItemString);
   hIcon = (HICON)LOWORD (SendDlgItemMessage (hDlg, ID_LISTBOX, LB_GETITEMDATA,
                       lpdis->itemID, 0L));

   GetClientRect (GetDlgItem (hDlg, ID_LISTBOX), &lbRect);
   
   DrawIcon(lpdis->hDC, lpdis->rcItem.left+(lbRect.right/2) - (cxIcon/2), 
                        lpdis->rcItem.top + (tm.tmHeight/4), hIcon);

   textRect.left  = lpdis->rcItem.left;
   textRect.top   = lpdis->rcItem.top + cyIcon + (tm.tmHeight/4);
   textRect.right = lpdis->rcItem.right;    
   textRect.bottom= lpdis->rcItem.bottom;
   DrawText (lpdis->hDC, szItemString, lstrlen (szItemString),
             &textRect, DT_CENTER);


}


BOOL FAR PASCAL SpecialDlgBox (HWND hDlg,
                               WORD message,
                               WORD wParam,
                               LONG lParam)
{
    static int curFirst, curLast;
    switch (message) 
    {
        case WM_INITDIALOG:
            AddIconToListBox (hDlg, "FileOpen",     LoadIcon (ghInstance, "FOpenIcon"  ));
            AddIconToListBox (hDlg, "Font",         LoadIcon (ghInstance, "FontIcon"   ));
            AddIconToListBox (hDlg, "PrintSetup",   LoadIcon (ghInstance, "PrSetupIcon"));
            AddIconToListBox (hDlg, "Print",        LoadIcon (ghInstance, "PrintIcon"  ));
            AddIconToListBox (hDlg, "Find",         LoadIcon (ghInstance, "FindIcon"   ));
            AddIconToListBox (hDlg, "Find/Replace", LoadIcon (ghInstance, "FindRepIcon"));

            ShowAllControls (hDlg,IDCD_FONTFIRST,    IDCD_FONTLAST,    SW_HIDE);
            ShowAllControls (hDlg,IDCD_PRSETUPFIRST, IDCD_PRSETUPLAST, SW_HIDE);
            ShowAllControls (hDlg,IDCD_PRINTFIRST,   IDCD_PRINTLAST,   SW_HIDE);
            ShowAllControls (hDlg,IDCD_FINDFIRST,    IDCD_FINDLAST,    SW_HIDE);
            ShowAllControls (hDlg,IDCD_REPFIRST,     IDCD_REPLAST,     SW_HIDE);

            curFirst = IDCD_FOPENFIRST;
            curLast  = IDCD_FOPENLAST;
            return TRUE;

        case WM_MEASUREITEM:
           {
             MEASUREITEMSTRUCT *ms;
             TEXTMETRIC tm;
             HDC  hDC;
             int  cy;

             ms = (MEASUREITEMSTRUCT *)lParam;

             if (ms->CtlID == ID_LISTBOX)
             {
               cy = GetSystemMetrics (SM_CYICON);
  
               hDC = GetDC (hDlg);
               GetTextMetrics (hDC, &tm);
               ReleaseDC (hDlg, hDC);
  
               ms->itemHeight = cy + (3*tm.tmHeight/2);
               ms->itemWidth  = 58;
             }
           } 
           break;

        case WM_DRAWITEM:
           {
             LPDRAWITEMSTRUCT lpdis;

             lpdis = (LPDRAWITEMSTRUCT)lParam;

             if (lpdis->CtlID == ID_LISTBOX)
             {            
               DWORD  dwBkColor, dwOldBkColor, dwTextColor;
               HBRUSH hBrush, hOldBrush;

               if (lpdis->itemID == -1)
                 DrawFocusRect (lpdis->hDC, (LPRECT)&lpdis->rcItem);

               if ((lpdis->itemAction & ODA_FOCUS) && 
                   (!lpdis->itemState  & ODS_FOCUS))
                 DrawFocusRect (lpdis->hDC, (LPRECT)&lpdis->rcItem);


               if (lpdis->itemState & ODS_SELECTED)
//                 InvertRect   (lpdis->hDC, (LPRECT)&lpdis->rcItem);
               {
                 dwBkColor = GetSysColor (COLOR_HIGHLIGHT);
                 dwTextColor=GetSysColor (COLOR_HIGHLIGHTTEXT);
               } 
               else
               { 
                 dwBkColor = GetSysColor (COLOR_WINDOW);
                 dwTextColor=GetSysColor (COLOR_WINDOWTEXT);
               }

               dwOldBkColor = SetBkColor (lpdis->hDC, dwBkColor);
               SetTextColor (lpdis->hDC, dwTextColor);
 
               hBrush = CreateSolidBrush (dwBkColor);
               hOldBrush = SelectObject (lpdis->hDC, hBrush);

               PatBlt (lpdis->hDC, lpdis->rcItem.left, lpdis->rcItem.top,
                                   lpdis->rcItem.right  - lpdis->rcItem.left,
                                   lpdis->rcItem.bottom - lpdis->rcItem.top,
                                   PATCOPY);

               DrawItem (hDlg, lpdis);

               SetBkColor (lpdis->hDC, dwOldBkColor);       // Reset background color
               DeleteObject (SelectObject (lpdis->hDC, hOldBrush));

               if ((lpdis->itemAction & ODA_FOCUS) && 
                   (lpdis->itemState  & ODS_FOCUS))
                 DrawFocusRect (lpdis->hDC, (LPRECT)&lpdis->rcItem);


             }             
           }
           return TRUE;

        case WM_COMMAND:  // wParam == IDOK || IDCANCEL
            if (wParam == IDCD_FOPEN11   || wParam == IDCD_FOPEN12  ||
                wParam == IDCD_FONT7     || wParam == IDCD_FONT8    ||
                wParam == IDCD_PRINT17   || wParam == IDCD_PRINT18  ||
                wParam == IDCD_REP7      || wParam == IDCD_REP10    ||
                wParam == IDCD_FIND8     || wParam == IDCD_FIND9    ||
                wParam == IDCD_PRSETUP15 || wParam == IDCD_PRSETUP16)             
            {
                EndDialog(hDlg, TRUE);
                return (TRUE);
            }

            if (HIWORD(lParam) == LBN_SELCHANGE)
            {
               DWORD dwIndex;
               dwIndex = SendDlgItemMessage (hDlg, ID_LISTBOX, LB_GETCURSEL, 0, 0L);
               if (dwIndex == LB_ERR) break;


               switch (dwIndex)
               {
                  case IDI_FILEOPEN:
                     if (curFirst == IDCD_FOPENFIRST) return (FALSE);
                     ShowAllControls (hDlg, curFirst, curLast, SW_HIDE);
                     curFirst = IDCD_FOPENFIRST;
                     curLast  = IDCD_FOPENLAST;     
                     break;

                  case IDI_FONT:
                     if (curFirst == IDCD_FONTFIRST) return (FALSE);
                     ShowAllControls (hDlg, curFirst, curLast, SW_HIDE);
                     curFirst = IDCD_FONTFIRST;
                     curLast  = IDCD_FONTLAST;     
                     break;

                  case IDI_PRSETUP:
                     if (curFirst == IDCD_PRSETUPFIRST) return (FALSE);
                     ShowAllControls (hDlg, curFirst, curLast, SW_HIDE);
                     curFirst = IDCD_PRSETUPFIRST;
                     curLast  = IDCD_PRSETUPLAST;     
                     break;

                  case IDI_PRINT:
                     if (curFirst == IDCD_PRINTFIRST) return (FALSE);
                     ShowAllControls (hDlg, curFirst, curLast, SW_HIDE);
                     curFirst = IDCD_PRINTFIRST;
                     curLast  = IDCD_PRINTLAST;     
                     break;

                  case IDI_FIND:
                     if (curFirst == IDCD_FINDFIRST) return (FALSE);
                     ShowAllControls (hDlg, curFirst, curLast, SW_HIDE);
                     curFirst = IDCD_FINDFIRST;
                     curLast  = IDCD_FINDLAST;     
                     break;

                  case IDI_REPLACE:
                     if (curFirst == IDCD_REPFIRST) return (FALSE);
                     ShowAllControls (hDlg, curFirst, curLast, SW_HIDE);
                     curFirst = IDCD_REPFIRST;
                     curLast  = IDCD_REPLAST;     
                     break;

                  default : break;
               }
               ShowAllControls (hDlg, curFirst,  curLast,  SW_SHOW);
//             UpdateWindow( GetDlgItem(hDlg,ID_FRAME) );                  

               {
/* DaveE Stuff...
               RECT lbRect, dlgRect;
               GetClientRect (GetDlgItem (hDlg, ID_LISTBOX), &lbRect);

               // This hack eliminates flicker

               ValidateRect (hDlg, NULL );              // First, validate everything

               GetClientRect (hDlg, &dlgRect);          // Then get dlg rect
               dlgRect.left = lbRect.right + 1;         // trim off left listbox
               InvalidateRect (hDlg, &dlgRect, FALSE);  // invalidate the rest
*/
               InvalidateRect (GetDlgItem (hDlg, ID_FRAME), NULL, FALSE);  // invalidate the rest
               }
            }
            break;

       case WM_CLOSE:
            EndDialog(hDlg, TRUE);
            return TRUE;
            
    }
    return (FALSE);
}


