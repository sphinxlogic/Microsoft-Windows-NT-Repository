//*-------------------------------------------------------------------------
//|  Title:
//|     INITPROC.C
//|
//|  Contents:
//|     InitApplication()
//|     InitInstance()   
//*-------------------------------------------------------------------------

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <WINDOWS.H>
#include "INITPROC.H"
#include "WNDPROC.H"
#include "GLOBALS.H"


HANDLE ghInstance = NULL;


//*----------------------------------------------------------------------------
//| Title:
//|     InitApplication
//|
//| Parameters:
//|     hInstance       - Integer which uniquely identifies this instance
//|                         of the application (hInstance > 0)
//|     hPrevInstance   - Integer identifier of a previous instance of the
//|                         application (hPrevInstance == NULL if no previous
//|                         instance exists)
//|
//| Purpose:
//|     Registers the applications window class(es) if no previous instance of
//|     the application has already done so.
//*----------------------------------------------------------------------------
#define DEFBKGDCOLOR (COLOR_WINDOW + 1)
BOOL InitApplication(HANDLE hInstance,
                     HANDLE hPrevInstance)
{
    WNDCLASS  wc;

    // If a previous instance of this application is already loaded,
    // then the window class is already registered and we are happy.
    if (hPrevInstance)
        return TRUE;

    // The window class is not registered yet, so we have to fill a
    // window class structure with parameters that describe the       
    // window class.                                                           
    wc.lpszClassName = "BaseWndClass";  // String identifier for the class  
    wc.lpfnWndProc = MainWndProc;       // Message handling procedure used
                                        //    by windows of this class
    wc.style = 0;                       // Use default class styles
    wc.lpszMenuName = (LPSTR)"MyMenu";  // Use menu 
    wc.hIcon   = LoadIcon  (NULL, IDI_APPLICATION); // Use a pre-defined icon
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);       // Use a pre-defined cursor
    wc.hbrBackground = DEFBKGDCOLOR;    // Use default window background color
    wc.hInstance = hInstance;           // Instance which registered the class
    wc.cbClsExtra = 0;                  // No user-defined extra-bytes
                                        //    associated with this class
    wc.cbWndExtra = 0;                  // No user-defined extra-bytes
                                        //    associated with each window of
                                        //    this class

    // Register the window class and return success/failure code.
    return (RegisterClass(&wc));
}



//*----------------------------------------------------------------------------
//| Title:
//|     InitInstance
//|
//| Parameters:
//|     hInstance   - Integer which uniquely identifies this instance
//|                         of the application (hInstance > 0)
//|     nCmdShow    - Integer value specifying how to start app.,
//|                         (Iconic [7] or Normal [1,5])
//|
//| Purpose:
//|     Creates and displays the application's initial window(s).
//*----------------------------------------------------------------------------

BOOL InitInstance(  HANDLE  hInstance,
                    int     nCmdShow)
{
    HWND    hWnd;                       // temporary window handle             
    BOOL    bStatus = FALSE;            // holds return status for function
    
    // Save the instance handle in global variable, which will be used in  
    // many subsequent calls from this application to Windows            
    ghInstance = hInstance;

    // Create a main window for this application instance
    hWnd = CreateWindow(
        "BaseWndClass",                 // Name of the window's class
        "Sample Application",           // Text for window caption        
        WS_OVERLAPPEDWINDOW,            // Window style                     
        CW_USEDEFAULT,                  // Default horizontal position      
        CW_USEDEFAULT,                  // Default vertical position        
        700,                            // Default width                   
        500,                            // Default height                   
        NULL,                           // Overlapped windows have no parent
        NULL,                           // Use the window class menu        
        hInstance,                      // This instance owns this window  
        NULL                            // Pointer (not used)
    );

    // If the window was successfully created, make the window visible,
    // update its client area, and return "success".  If the window
    // was not created, return "failure"
   if (hWnd)
        { 
        ShowWindow(hWnd, nCmdShow); // Set to visible & paint non-client area
        UpdateWindow(hWnd);         // Tell window to paint client area
        
        bStatus = TRUE;             // Indicate success, default is failure
        }

   return bStatus;                  // Return status code
}




