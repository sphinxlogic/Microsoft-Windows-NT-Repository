// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "convert.h"

VOID PASCAL SyvToStr(LPVOID lpData, int cItem, LPSTR lpstr, int cMax, BOOL fSye)
/*******************************************************************************

FUNCTION:       SyvToStr(lpData, cItem, lpstr, cMax, fSye)

PURPOSE:                Converts from SYV to form to ANSI in order to display

COMMENTS:
                                Converts meta symbols SYV_BEGINOR, SYV_ENDOR and SYV_OR
                                to '{', '}' and '|' respectively.
                                Also converts gestures to strings

*******************************************************************************/
        {
        int i, j, cLen;
        SYV syvT;
        char buff[33];

        for(i=j=0; i< cItem; ++i)
                {
                syvT = (fSye)?((LPSYE)lpData)[i].syv : ((LPSYV)lpData)[i];

                cLen = 1;
                switch(syvT)
                        {
                case SYV_BEGINOR:
                        lpstr[j] = '{';
                        break;
                case SYV_ENDOR:
                        lpstr[j] = '}';
                        break;
                case SYV_OR:
                        lpstr[j] = '|';
                        break;
                case SYV_EMPTY:
                        lpstr[j] = '_';
                        break;
                case SYV_SPACENULL:
                        cLen = 0;
                        break;
                case SYV_SOFTNEWLINE:
                        lpstr[j] = ANSI_PARA_MARK;      // parragraph mark
                        break;

                default:
                        //If this is a gesture
                        if(FIsGesture(syvT))
                                {
                                //Convert to string
                                cLen = IGestureString(syvT, buff, sizeof(buff)-1);

                                //And append it to the output buffer.
                                if(cLen)
                                        {
                                        cLen = ((cLen + j) < cMax)?cLen:(cMax-j-1);
                                        if(cLen>0)
                                                _fstrncpy(&lpstr[j], buff, cLen);
                                        }       
                                }
                        //This could just be a SYV for an ANSI character
                        else if(!SymbolToCharacter(&syvT, 1, &lpstr[j], NULL))
                                lpstr[j] = '?';
                        
                        if (lpstr[j] == '\0')
                                cLen = 0;
                        else if (lpstr[j] == ANSI_NEW_LINE)     // New Line
                                lpstr[j] = ANSI_PARA_MARK; // parragraph mark
                        }
                j += cLen;
                }
                lpstr[j] = '\0';
        }


int PASCAL IGestureString(SYV syvGes, LPSTR lpstr, int cMac)
/*****************************************************************************

FUNCTION:       IGestureString(syvGes, lpstr, cMac)

PURPOSE:                Convert the SYV for a gesture to a corresponding string

COMMENTS:

                the rgGestures table above maps the SYVs to the corresponding strings

*****************************************************************************/
        {
        int i, cLen=0;
        BOOL    fFound = FALSE;

        // If this a Circled letter gesture
        if (FIsAppGesture(syvGes))
                {
        // Form a string with "circle -"  prefix

                _fstrncpy(lpstr, szCircleG, sizeof(szCircleG));
                if (syvGes >= SYV_CIRCLEUPA && syvGes <= SYV_CIRCLEUPZ)
                        lpstr[sizeof(szCircleG) - 1] = (BYTE)LOWORD(syvGes - SYV_CIRCLEUPA + 'A');
                else 
                        lpstr[sizeof(szCircleG) - 1] = (BYTE)LOWORD(syvGes - SYV_CIRCLELOA + 'a');
                lpstr[sizeof(szCircleG)] = '\0';
                cLen = sizeof(szCircleG);
                }
        else
                {
        //Must be a command gesture, look in the table
                for(i=0; i<(sizeof(rgGestures)/sizeof(SYVID)); ++i)
                        {
                        if(syvGes == rgGestures[i].syv)
                                {
                                cLen = _fstrlen(rgGestures[i].lpstr);
                                cLen = min(cLen, cMac);
                                _fstrncpy(lpstr, rgGestures[i].lpstr, cLen);
                                fFound = TRUE;
                                break;
                                }
                        }

                }
        return(cLen);
        }


