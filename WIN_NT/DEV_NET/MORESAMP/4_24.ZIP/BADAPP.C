/***    BADAPP.C -- Ill-Behaved Windows Application
 *      (c) 1991-1992, Microsoft Corporation (bens)
 *
 *      History:
 *      17-Sep-1991 bens Added menus, and hang option.
 *      11-Mar-1992 bens 2.00
 *          Added bitmaps animation for GP-Fault.
 *      13-Mar-1992 bens 2.03
 *          Animate bitmaps for hang, add zoom option, add timer.
 *      16-Mar-1992 bens 2.04
 *          Fix bug: don't allow another fuse burn request to start until
 *                   current one completes!
 *      16-Mar-1992 bens 2.05
 *          Add explosion bitmaps from t-richo.
 *	24-Mar-1992 bens
 *          Add sound!
 *	25-Mar-1992 bens 2.06
 *	    Prevent dialog if MMSYSTEM is not found.
 *	25-Mar-1992 bens 2.07
 *	    Allow user to disable sound.
 *	25-Mar-1992 bens 2.08
 *	    Allow user to change visibile application name.
 *	    Fix bug introduced in 2.07 where MMSYSTEM was freed one
 *	    extra time, thus crashing system quite soon thereafter.
 */
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1992.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <windows.h>
#include <mmsystem.h>
#include <stdlib.h>
#include <string.h>
#include "badapp.h"

#define MIR(x)  MAKEINTRESOURCE(x)  // Make DialogBox lines shorter

#define cxBitmap     32             // Width of bitmaps
#define cyBitmap     32             // Height of bitmaps

#define maxMulZoom   10             // Maximum magnification

#define ID_TIMER     1              // Our timer
#define msTimer      100            // 1/10th second between bitmap frames

#define szAppName   "BadApp"        // WIN.INI app name
#define szKeyZoom   "ZoomFactor"    // WIN.INI key name for zoom factor
#define szKeySound  "Sound"	    // WIN.INI key name for sound flag
#define szKeyTitle  "Title"	    // WIN.INI key name for title string

#define cbTitleMax   8		    // Maximum length of title string

// Function to call when fuse is done
typedef VOID (*PFNFUSE)(VOID);


// Function type for sndPlaySound
typedef BOOL (WINAPI *LPFNSNDPLAYSOUND)(LPCSTR lpszSoundName, UINT uFlags);
typedef UINT (WINAPI *LPWOGDC)(UINT , LPWAVEOUTCAPS ,UINT );


// Sound record
typedef struct sound_ { /* sound */
    int     id;         // Resource ID
    HANDLE  hresWave;   // Resource handle
    LPSTR   lpWave;     // Long Pointer to waveform
} SOUND;
typedef SOUND *PSOUND;


// Global variables
typedef struct _global {
    char       ach[100];		// Work buffer
    char       ach2[100];		// Work buffer
    char       achTitle[cbTitleMax+1];	// Visible app title
    int        cxWindow;                // Window width
    int        cyWindow;                // Window height
    BOOL       fUIEnabled;              // TRUE => OK to start a fuse
    BOOL       fBusyTimer;              // TRUE => timer must show busy cursor
    BOOL       fSound;			// TRUE => Use sound in animation
    BOOL       fSoundPresent;		// TRUE => Sound hardware present
    BOOL       fZoom;                   // TRUE => Show bitmaps enlarged!
    HCURSOR    hcurSave;                // HCUR for fuse burn save
    HDC        hdcFuse;                 // HDC for fuse burn
    HANDLE     hInstance;               // Application instance
    HINSTANCE  hinstMMSYS;              // Hinst of MMSYSTEM, if available
    HWND       hwnd;                    // HWND of main window
    int        iFuse;                   // Bitmap index for fuse burn
    int        mulZoom;                 // Magnification
    WORD       wTimer;                  // Timer ID
    PFNFUSE    pfnFuse;                 // Function to call when fuse is done

} GLOBAL;

// Global variables
GLOBAL  g;

LPFNSNDPLAYSOUND    lpfnSndPlaySound;

// Sound database
#define isndFuse    0
#define isndBoom    1
static SOUND asound[] = {
    { IDW_FUSE, 0, 0},
    { IDW_BOOM, 0, 0},
};
#define csound  (sizeof(asound)/sizeof(SOUND))


// Function prototypes
BOOL	    BurnFuse(PFNFUSE pfn,BOOL fBusy);
VOID	    CalcWindowSize(VOID);
VOID	    DoHang(VOID);
VOID	    DoGPFault(VOID);
#ifdef  DIVIDEBY0
VOID	    DoDivideByZero(VOID);
#endif
BOOL	    DrawBitmap(HWND hwnd,HDC hdc,int idBitmap);
WORD	    DummyFunction(VOID);
BOOL	    EnableUI(BOOL fEnable);
void	    LoadSound(void);
BOOL WINAPI MySndPlaySound(LPCSTR lpszSoundName, UINT uFlags);
void	    ParseConfiguration(LPSTR lpszCmdLine);
BOOL	    StepFuse(void);
void	    UnloadSound(void);

BOOL FAR PASCAL AboutDlgProc(HWND hDlg,WORD msg,WORD wParam,LONG lParam);
long FAR PASCAL WndProc(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam);
BOOL FAR PASCAL OptionsDlgProc(HWND hDlg,WORD msg,WORD wParam,LONG lParam);


/***    WinMain - Main program
 *
 */
int PASCAL WinMain(HANDLE hInstance,
                    HANDLE hPrevInstance,
                    LPSTR lpszCmdLine,
                    int nCmdShow)
{
    DWORD       dwStyle;
    MSG         msg;
    WNDCLASS    wndclass;

    g.wTimer = 0;                       // No timer created, yet
    g.fUIEnabled = TRUE;                // No fuse right now
    g.fSoundPresent = FALSE;		// No sound hardware detected

    if (!hPrevInstance)
        {
        wndclass.style         = CS_HREDRAW | CS_VREDRAW;
        wndclass.lpfnWndProc   = WndProc;
        wndclass.cbClsExtra    = 0;
        wndclass.cbWndExtra    = 0;
        wndclass.hInstance     = hInstance;
        wndclass.hIcon         = LoadIcon(hInstance, MIR(IDC_APP));
        wndclass.hCursor       = LoadCursor(NULL,IDC_ARROW);
        wndclass.hbrBackground = GetStockObject(WHITE_BRUSH);
        wndclass.lpszMenuName  = szAppName;
        wndclass.lpszClassName = szAppName;

        RegisterClass(&wndclass);
        }

    g.hInstance = hInstance;

    // Get sound bites
    LoadSound();

    // Process command line args and WIN.INI switches
    ParseConfiguration(lpszCmdLine);

    // Create main window
    dwStyle = WS_OVERLAPPED |
              WS_CAPTION |
              WS_SYSMENU |
              WS_BORDER |
              WS_MINIMIZEBOX;
    g.hwnd = CreateWindow(szAppName,g.achTitle,
                          dwStyle,
                          CW_USEDEFAULT,CW_USEDEFAULT,
                          g.cxWindow,g.cyWindow,
                          NULL,NULL,hInstance,NULL);

    ShowWindow(g.hwnd,nCmdShow);
    UpdateWindow(g.hwnd);

    while(GetMessage(&msg,NULL,0,0))
        {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
        }
    return msg.wParam;
}


/***    WndProc - Main window procedure
 *
 */
long FAR PASCAL WndProc(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam)
    {
    BOOL            f;
    HDC             hdc;
    static FARPROC  lpfnAboutDlgProc;
    static FARPROC  lpfnOptionsDlgProc;
    PAINTSTRUCT     ps;

    switch(msg) {

    case WM_CREATE:
        lpfnAboutDlgProc = MakeProcInstance(AboutDlgProc,g.hInstance);
	lpfnOptionsDlgProc = MakeProcInstance(OptionsDlgProc,g.hInstance);
        return 0;

    case WM_COMMAND:
        switch (wParam) {

        case IDM_ABOUT:
            DialogBox(g.hInstance,MIR(IDD_ABOUT),hwnd,lpfnAboutDlgProc);
            return 0;

#ifdef  DIVIDEBY0
        case IDM_DIV0:
            DoDivideByZero();
            return 0;
#endif

        case IDM_FAULT:
            g.hcurSave = NULL;          // No change to cursor
            // Give RichT time to explain what is happening
            if (!BurnFuse(DoGPFault,FALSE)) { // Have to fault here
                DoGPFault();            // Fault-O-Rama!
                InvalidateRect(hwnd,NULL,TRUE);     // Force window repaint
            }
            return 0;

        case IDM_HANG:
            // Give RichT time to explain what is happening
            if (!BurnFuse(DoHang,TRUE)) {
                // Hang-O-Rama!
                DoHang();

                // NOTE: We should never get here, but just in case...
                InvalidateRect(hwnd,NULL,TRUE);  // Force repaint
                // Restore normal cursor
                SetCursor(g.hcurSave);
                EnableUI(TRUE);
            }
            return 0;

	case IDM_OPTIONS:
	    f = DialogBox(g.hInstance,MIR(IDD_OPTIONS),hwnd,lpfnOptionsDlgProc);
            if (f) {            // Zoom changed
                // Write new factor to WIN.INI
                itoa(g.mulZoom,g.ach,10);
		WriteProfileString(szAppName,szKeyZoom,g.ach);

                // Resize window
                CalcWindowSize();  // Compute new size;
                SetWindowPos(hwnd,0,0,0,g.cxWindow,g.cyWindow,
                    SWP_NOMOVE | SWP_NOZORDER);
            }
            return 0;
        }
        break;

    case WM_PAINT:
        hdc = BeginPaint(hwnd, &ps);
        DrawBitmap(hwnd,hdc,IDB_FUSE);
        EndPaint(hwnd, &ps);
        return 0;

    case WM_LBUTTONDOWN:
    case WM_LBUTTONDBLCLK:
        // Handle left button as if GP-Fault was requested
        if (g.fUIEnabled)           // Only if we're not already crashing!
            SendMessage(hwnd,WM_COMMAND,IDM_FAULT,0L);
        return 0;

#ifdef  DIVIDEBY0
    case WM_RBUTTONDOWN:
    case WM_RBUTTONDBLCLK:
        if (g.fUIEnabled)           // Only if we're not already crashing!
            SendMessage(hwnd,WM_COMMAND,IDM_DIV0,0L);
        return 0;
#endif

    case WM_TIMER:
        if (wParam == ID_TIMER) {
            if (StepFuse()) {
                // Nothing to do, StepFuse did it all!
            }
            else {                      // BOOM done, Time to be bad
                KillTimer(hwnd,g.wTimer); // Done with timer
                g.wTimer = 0;           // Timer no longer allocated
                ReleaseDC(hwnd,g.hdcFuse);

                // Stop sound
                MySndPlaySound(NULL,0);

                if (g.fBusyTimer) {     // Make app look like it is busy
                    g.hcurSave = SetCursor(LoadCursor(NULL,IDC_WAIT));
                }

                (*g.pfnFuse)();         // Do bad function!
                // If we get back, fix up display
                InvalidateRect(hwnd,NULL,TRUE);
                SendMessage(hwnd,WM_PAINT,NULL,NULL);
                // Restore normal cursor, if necessary
                if (g.hcurSave)
                    SetCursor(g.hcurSave);
                EnableUI(TRUE);         // No longer burning
            }
            return 0;
        }
        break;

    case WM_DESTROY:
        // If we are killed while timing, make sure we free timer and hdc!
        if (g.wTimer)
            KillTimer(hwnd,g.wTimer);
        if (g.hdcFuse)
            ReleaseDC(hwnd,g.hdcFuse);
        FreeProcInstance(lpfnAboutDlgProc);
	FreeProcInstance(lpfnOptionsDlgProc);
        UnloadSound();
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hwnd,msg,wParam,lParam);
}


/***	AboutDlgProc - Display about box
 *
 */
BOOL FAR PASCAL AboutDlgProc(HWND hDlg,WORD msg,WORD wParam,LONG lParam)
{
    switch (msg)
        {
        case WM_INITDIALOG:
	    // Set dialog title
	    LoadString(g.hInstance,IDS_ABOUT,g.ach,sizeof(g.ach));
	    strcat(g.ach,g.achTitle);	// Get title
	    SetWindowText(hDlg,g.ach);	// Set dialog title

	    // Set version text
	    LoadString(g.hInstance,IDS_VERSION,g.ach,sizeof(g.ach));
	    strcpy(g.ach2,g.achTitle);	// Get title
	    strcat(g.ach2,g.ach);	// Append version
	    SetDlgItemText(hDlg,IDC_VERSION,g.ach2); // Set version
            return TRUE;

        case WM_COMMAND:
            switch (wParam)
                {
                case IDOK:
                case IDCANCEL:
                    EndDialog(hDlg, 0);
                    return TRUE;
                }
            break;
        }
    return FALSE;
}


/***    BurnFuse - Animate bitmaps
 *
 *      Entry:
 *          pfn - fuse function
 *          fBusy - TRUE => show busy cursor after fuse burns
 *
 *      Exit:
 *          TRUE - timer started
 *          FALSE - no timers, so fuse already burned
 */
BOOL BurnFuse(PFNFUSE pfn,BOOL fBusy)
{
    int     j;
    RECT    rect;

    // Disable UI from starting another fuse
    EnableUI(FALSE);

    // Set up for timer
    g.fBusyTimer = fBusy;
    g.hdcFuse = GetDC(g.hwnd);
    g.iFuse = IDB_FUSE;
    g.pfnFuse = pfn;

    // Start fuse burning
    MySndPlaySound(asound[isndFuse].lpWave,
            SND_ASYNC | SND_MEMORY | SND_NODEFAULT | SND_LOOP);

    // Try to create timer
    g.wTimer = SetTimer(g.hwnd,ID_TIMER,msTimer,NULL);
    if (g.wTimer)                   // Timer started
        return TRUE;

    // Could not get timer, Do it the stupid, timing-loop way
    while (StepFuse()) {
        // Delay
        for (j=0; j<6000; j++) {
            GetClientRect(g.hwnd,&rect); // Use up some time!
        }
    }
    ReleaseDC(g.hwnd,g.hdcFuse);

    // Stop sound
    MySndPlaySound(NULL,0);

    if (fBusy) {                    // Make app look like it is busy
        g.hcurSave = SetCursor(LoadCursor(NULL,IDC_WAIT));
    }
    return FALSE;
}


/***    CalcWindowSize - Calculate client window size
 *
 */
VOID CalcWindowSize(VOID)
{
    // Set flag if zoom is on
    if (g.mulZoom > 1)
        g.fZoom = TRUE;

    // Give 1/2 bitmap size border, and ensure big enough for menus/title bar

    g.cxWindow = max((g.mulZoom+1)*cxBitmap + GetSystemMetrics(SM_CXBORDER),
                     150);

    g.cyWindow = max((g.mulZoom+1)*cyBitmap +
                     GetSystemMetrics(SM_CYBORDER) +
                     GetSystemMetrics(SM_CYCAPTION) +
                     GetSystemMetrics(SM_CYMENU),

                     100);
}


#ifdef  DIVIDEBY0
/***    DoDivideByZero - cause divide by 0
 *
 */
VOID DoDivideByZero(VOID)
{
    int i1;
    int i2;

    // Time to divide by 0!
    i2 = i1;
    i2 = i2 - i1;           // Make it 0 (have to trick compiler!)
    i1 = i1/i2;             // Fault-o-Rama
}
#endif


/***    DoGPFault - generate a GP-Fault
 *
 */
VOID DoGPFault(VOID)
{
    LPSTR   lpstr;

    lpstr = (LPSTR)0L;      // Null pointer
    *lpstr = '\0';          // Fault-o-Rama!
}


/***    DoHang - cause app to hang
 *
 *      Just inifinite loop.
 */
VOID DoHang(VOID)
{
    WORD    junk;

    // Make sure compiler does not optimize loop away!

    for (;;) {
        junk = DummyFunction();
    }
}


/***    DrawBitmap - Draw a single bitmap
 *
 *      Entry:
 *          hwnd    - hwnd of client area
 *          hdc     - hdc of client area
 *          iBitmap - id of bitmap to draw
 *      Exit:
 *          TRUE - bitmap drawn
 *          FALSE - bitmap does not exist
 *
 */
BOOL DrawBitmap(HWND hwnd,HDC hdc,int idBitmap)
{
    HBITMAP hbm;
    HBITMAP hbmSave;
    HDC     hdcMem;
    RECT    rect;
    int     x;
    int     y;

    // Load bitmap
    hbm = LoadBitmap(g.hInstance,MIR(idBitmap));
    if (hbm == 0)                       // Did not exist
        return FALSE;                   // Indicate failure

    // Draw bitmap
    GetClientRect(hwnd, &rect);

    x = (rect.right - rect.left - cxBitmap*g.mulZoom) / 2;
    y = (rect.bottom - rect.top - cyBitmap*g.mulZoom) / 2;

    hdcMem = CreateCompatibleDC(hdc);
    hbmSave =  SelectObject(hdcMem,hbm); // Save, to restore later
    if (g.fZoom) {
        StretchBlt(hdc,x,y,cxBitmap*g.mulZoom,cyBitmap*g.mulZoom,
            hdcMem,0,0,cxBitmap,cyBitmap,SRCCOPY);
    }
    else {
        BitBlt(hdc,x,y,cxBitmap,cyBitmap,hdcMem,0,0,SRCCOPY);
    }
    SelectObject(hdcMem,hbmSave);   // Restore original object
    DeleteDC(hdcMem);               // Delete memory DC
    DeleteObject(hbm);              // Delete loaded bitmap
    return TRUE;                    // Indicate success
}


/***    DummyFunction - do nothing
 *
 */
WORD DummyFunction(VOID)
{
    return 0;
}


/***    EnableUI - Control ability of UI to cause fuse/zoom requests
 *
 *      Entry:
 *          fEnable - TRUE => enable; FALSE => disable
 *
 *      Exit:
 *          Returns previous enable setting.
 */
BOOL EnableUI(BOOL fEnable)
{
    HMENU   hmenu;
    WORD    wEnable;

    if (g.fUIEnabled == fEnable)        // Already at requested state
        return fEnable;                 // Do nothing

    wEnable = (fEnable ? MF_ENABLED : MF_GRAYED);

    hmenu = GetMenu(g.hwnd);
    EnableMenuItem(hmenu,IDM_FAULT,wEnable);
    EnableMenuItem(hmenu,IDM_HANG ,wEnable);
    EnableMenuItem(hmenu,IDM_OPTIONS,wEnable);
#ifdef DIVIDEBY0
    EnableMenuItem(hmenu,IDM_DIV0 ,wEnable);
#endif
    g.fUIEnabled = fEnable;             // Remember new state
}


/***    LoadSound - Load and lock sound resources
 *
 */
void LoadSound(void)
{
    int         i;
    HANDLE      hresInfo;
    UINT (WINAPI *lpfnWOGDC)(UINT uDeviceID, LPWAVEOUTCAPS lpCaps,UINT uSize);
    UINT	ui;
    WAVEOUTCAPS woc;

    // Assume no sound hardware
    g.fSoundPresent = FALSE;

    // Prevent dialog if file not found
    ui = SetErrorMode(SEM_NOOPENFILEERRORBOX);

    // Test if sound hardware present
    g.hinstMMSYS = LoadLibrary("MMSYSTEM");

    // Revert to previous behavior
    SetErrorMode(ui);

    if (g.hinstMMSYS > 32) {		// MMSYSTEM present
	// Make sure routines are present, and capable sound driver installed
	if (
	    (lpfnSndPlaySound =(LPFNSNDPLAYSOUND) GetProcAddress(g.hinstMMSYS,"SNDPLAYSOUND")) &&
	    (lpfnWOGDC = (LPWOGDC)GetProcAddress(g.hinstMMSYS,"WAVEOUTGETDEVCAPS")) &&
	    (!(*lpfnWOGDC)(0,&woc,sizeof(woc)))
	   ) {
	    g.fSoundPresent = TRUE;	// We have sound!
	}
	else {				// No sound driver
	    FreeLibrary(g.hinstMMSYS);  // Get rid of library reference
	}
    }

    if (!g.fSoundPresent) {
	g.hinstMMSYS = 0;		// MMSYSTEM is not loaded!
	return;
    }

    // Load sounds
    for (i=0; i<csound; i++) {
        // Load and lock the sound resources
        if(hresInfo = FindResource(g.hInstance,MIR(asound[i].id), "WAVE")) {
            if(asound[i].hresWave = LoadResource(g.hInstance,hresInfo)) {
                asound[i].lpWave = LockResource(asound[i].hresWave);
            }
        }
    }
}


/***    MySndPlaySound - Play sound, if available
 *
 *      If sound is not available, then simulate the IDW_BOOM sound
 *      lasting for 12 timer ticks.
 */
BOOL WINAPI MySndPlaySound(LPCSTR lpszSoundName, UINT uFlags)
{
    static int cTicks;

    if (g.fSound) {
        return (*lpfnSndPlaySound)(lpszSoundName,uFlags);
    }
    else if (uFlags & SND_LOOP) {   // Request for IDW_FUSE
        return TRUE;                // Pretend it worked
    }
    else if (uFlags & SND_NOSTOP) { // Query if IDW_BOOM done
        cTicks++;                   // Simulate playing boom
	return (cTicks > 12);	    // Return completion status
    }
    else {			    // Request for IDW_BOOM
        cTicks = 0;                 // Start counting
        return TRUE;                // Pretend we are playing
    }
}


/***	OptionsDlgProc - Display Options dialog box
 *
 */
BOOL FAR PASCAL OptionsDlgProc(HWND hDlg,WORD msg,WORD wParam,LONG lParam)
{
    static int  factor;
	   BOOL fSoundNew;
    static HWND hctl;

    switch (msg)
        {
        case WM_INITDIALOG:
	    // Set factor and scroll bars
            factor = g.mulZoom;
            hctl = GetDlgItem(hDlg,IDC_SCROLL);
            SetScrollRange(hctl,SB_CTL,1,maxMulZoom,FALSE);
            SetScrollPos(hctl,SB_CTL,factor,FALSE);
            SetDlgItemInt(hDlg,IDC_FACTOR,factor,FALSE);

	    // Set sound state
	    CheckDlgButton(hDlg,IDC_SOUND,g.fSound); // Show user setting
	    hctl = GetDlgItem(hDlg,IDC_SOUND);
	    EnableWindow(hctl,g.fSoundPresent); // Only enable for sound h/w

	    // Set current title, and limit length to user
	    SetDlgItemText(hDlg,IDC_TITLE,g.achTitle);
	    SendDlgItemMessage(hDlg,IDC_TITLE,EM_LIMITTEXT,cbTitleMax,0);
            return TRUE;

        case WM_VSCROLL:
            switch (wParam) {
                case SB_LINEDOWN:
                    factor--;
                    break;

                case SB_LINEUP:
                    factor++;
            }
            factor = min(max(factor,1),maxMulZoom); // Keep in range
            SetDlgItemInt(hDlg,IDC_FACTOR,factor,FALSE);
            break;

        case WM_COMMAND:
            switch (wParam)
                {
                case IDOK:
		    // Get sound setting
		    fSoundNew = (BOOL)SendDlgItemMessage(hDlg,IDC_SOUND,
		    			BM_GETCHECK,0,0);
		    if (fSoundNew != g.fSound) { // User changed state
			g.fSound = fSoundNew;
			// Write new setting to WIN.INI
			itoa(g.fSound,g.ach,10);
			WriteProfileString(szAppName,szKeySound,g.ach);
		    }

		    // Get title setting
		    GetDlgItemText(hDlg,IDC_TITLE,g.ach,sizeof(g.ach));
		    if (stricmp(g.ach,g.achTitle)) { // Title changed
			WriteProfileString(szAppName,szKeyTitle,g.ach);
			// Change title everywhere
			strcpy(g.achTitle,g.ach);
			SetWindowText(g.hwnd,g.achTitle);
		    }

		    // Get zoom setting
                    if (factor != g.mulZoom) { // Zoom changed
                        g.mulZoom = factor;   // Change factor
                        EndDialog(hDlg, TRUE);
                        return TRUE;
                    }
                    // Fall through to no-change case

                case IDCANCEL:
                    EndDialog(hDlg, FALSE);
                    return TRUE;
                }
            break;
        }
    return FALSE;
}


/***	ParseConfiguration - Parse command line and WIN.INI settings
 *
 *	NOTE: LoadSound() must be called before calling this routine!
 */
void ParseConfiguration(LPSTR lpszCmdLine)
{
    /*
     *	Get sound preference
     */

    // NOTE: If not present, default is suggested by LoadSound()
    g.fSound = GetProfileInt(szAppName,szKeySound,g.fSoundPresent);

    /*
     *	Get zoom setting
     */

    // See if numeric command line arg for zoom multiplier
    _fstrcpy((char far *)g.ach,lpszCmdLine);  // Get near copy to play with
    g.mulZoom = atoi(g.ach);            // Get factor

    // If no command-line argument, use default from WIN.INI
    if (g.mulZoom == 0)
	g.mulZoom = GetProfileInt(szAppName,szKeyZoom,1); // Default to zoom 1

    // Put in multiplier in range
    g.mulZoom = min(max(g.mulZoom,1),maxMulZoom);

    // Compute window size based on zoom multiplier
    CalcWindowSize();

    /*
     *	Get Application title
     */

    // Get default app title
    LoadString(g.hInstance,IDS_APP_TITLE,g.ach,sizeof(g.ach));
    // Get title from WIN.INI (supplying our default title)
    GetProfileString(szAppName,szKeyTitle,g.ach,g.achTitle,sizeof(g.achTitle));
}


/***    StepFuse - Do another step of fuse burn/explosion
 *
 */
BOOL StepFuse(void)
{
    if (g.iFuse < IDB_BOOM) {           // Still burning fuse
        if (DrawBitmap(g.hwnd,g.hdcFuse,g.iFuse)) {  // Draw bitmap, if there
            // It was
            g.iFuse++;                  // Next bitmap
        }
        else {                          // Time to do explosion
            g.iFuse = IDB_BOOM;
            MySndPlaySound(asound[isndBoom].lpWave,
                    SND_ASYNC | SND_MEMORY | SND_NODEFAULT);
            DrawBitmap(g.hwnd,g.hdcFuse,g.iFuse);
            g.iFuse++;
        }
        return TRUE;                    // Step accomplished
    }
    // We are exploding now
    else if (!MySndPlaySound(asound[isndBoom].lpWave,
                SND_ASYNC | SND_MEMORY | SND_NODEFAULT | SND_NOSTOP)) {
        // Sound is still going
        if (DrawBitmap(g.hwnd,g.hdcFuse,g.iFuse)) { // Draw bitmap, if there
            // It was
            g.iFuse++;
        }
        else {                          // Reset to front of boom bitmaps
            g.iFuse = IDB_BOOM+1;       // Skip first one
            DrawBitmap(g.hwnd,g.hdcFuse,g.iFuse);
        }
        return TRUE;                    // Step accomplished
    }
    else                                // BOOM done, Time to be bad
        return FALSE;                   // No more steps
}


/***    UnloadSound - Release sound resources
 *
 */
void UnloadSound(void)
{
    int     i;

    // Stop any sound in progress
    MySndPlaySound(NULL,0);

    // Free sound resources
    for (i=0; i<csound; i++) {
        // Unlock and free sound resources
        if (asound[i].lpWave)
            UnlockResource(asound[i].hresWave);
        if (asound[i].hresWave)
            FreeResource(asound[i].hresWave);
    }

    if (g.hinstMMSYS)
        FreeLibrary(g.hinstMMSYS);
}
