// -----------------------------------------------------------------
// File name:  ABOUT.C
//
// This file contains the dialog function for the about box.
//
// Description of functions:
//
//   AboutDlg()        - Dialog function for the About box.
//
//
// Written by Microsoft Product Support Services, Windows Developer Support.
//
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
// -----------------------------------------------------------------

#include <windows.h>
#include "about.h"

//-----------------------------------------------------------------------
//  AboutDlg ()
//
//  Purpose:  Controls actions that About dialog box can perform.
//
//  Parameters:  HWND      hDlg     -  Handle to this window
//               unsigned  message  -  Message to process
//               WORD      wParam   -  WORD parameter, depends on message
//               LONG      lParam   -  LONG parameter, depends on message
//
//  Return Value:  Depends on message.
//-----------------------------------------------------------------------

BOOL FAR PASCAL AboutDlg (HWND hDlg,
                          unsigned message,
                          WORD wParam,
                          LONG lParam)
{
   switch (message)
   {
      case WM_INITDIALOG:
         return (TRUE);

      case WM_COMMAND:
         if ((wParam == IDOK) ||  // "OK" box selected?        
             (wParam == IDCANCEL))     // System menu close command?
         {
            EndDialog(hDlg, TRUE);     // Exits the dialog box 
            return (TRUE);
         }
         break;
   }
   return (FALSE); // Didn't process a message
}
