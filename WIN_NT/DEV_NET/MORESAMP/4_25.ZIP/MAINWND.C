// -----------------------------------------------------------------
// File name:  MAINWND.C
//
// This file contains the application's main window procedure, which
// responds to input to the application's main window.
//
// Description of functions:
//
//   MainWndProc     -     Responds to input to the application's main
//                         window.
//   DoCommands      -     Processes WM_COMMAND messages sent to the
//                         application's main window.
//
// Written by Microsoft Product Support Services, Windows Developer Support.
//
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
// -----------------------------------------------------------------


#include <windows.h>
#include <stdio.h>
#include "globals.h"
#include "about.h"
#include "mainwnd.h"
#include "dllfloat.h"

HWND hFloatWnd;
char szTitle[] = "      Returned by sprintf()      Returned By ConvertToFlt()";
char szDash[] = " ---------------------------     --------------------------";

#define MAX_FLOAT_ARRAY 8

//-----------------------------------------------------------------------
//  MainWndProc ()
//
//  Purpose:  Message handler for main, overlapped window.
//
//  Parameters:  HWND      hWnd     -   Handle to this window
//               unsigned  message  -   Message to process
//               WORD      wParam   -   WORD parameter, depends on message
//               LONG      lParam   -   LONG parameter, depends on message
//
//  Return Value:  Depends on message.
//-----------------------------------------------------------------------

long FAR PASCAL MainWndProc (HWND hWnd,
                             unsigned message,
                             WORD wParam,
                             LONG lParam)
{
   switch (message)
   {
      case WM_CREATE:
      {

         // Create listbox window
         RECT rect;
         int i;
         char MessageString[80], ConvertString[50];
         double AppsFloat[MAX_FLOAT_ARRAY] =
         {
            100.06,
            -5657E10,
            0.0,
            -4.1,
            1234.5678,
            -89475.00,
            3.5E-6,
            3412.566E+14
         };

         // Create a listbox to cover the client area

         GetClientRect(hWnd, &rect);
         hFloatWnd = CreateWindow("ListBox",
                                  NULL,     // Text for window title bar.
                                  WS_CHILD | LBS_USETABSTOPS,   // Window style.
                                  0,
                                  0,
                                  rect.right - rect.left,
                                  rect.bottom - rect.top,
                                  hWnd,     // Overlapped windows have no parent.
                                  NULL,     // Use the window class menu.        
                                  ghInst,   // This instance owns this window.   
                                  NULL);    // Pointer not used.

         // Use a non-proportional font 
         SendMessage(hFloatWnd, WM_SETFONT, GetStockObject(SYSTEM_FIXED_FONT), 0);
         ShowWindow(hFloatWnd, SW_SHOW);


         SendMessage(hFloatWnd, LB_ADDSTRING, 0, (DWORD)(LPSTR)szTitle);

         SendMessage(hFloatWnd, LB_ADDSTRING, 0, (DWORD)(LPSTR)szDash);

         // Convert test floats to strings using both sprintf &
         // ConvertFltToString, and display in listbox.
         for (i = 0; i < MAX_FLOAT_ARRAY; i++)
         {
            ConvertFltToStr(AppsFloat[i], ConvertString);
            sprintf(MessageString, "%26.6f        %18s", AppsFloat[i], ConvertString);
            SendMessage(hFloatWnd, LB_ADDSTRING, 0, (DWORD)(LPSTR)MessageString);
         }
         break;
      }

      // Size listbox window

      case WM_SIZE:
      {
         RECT rect;

         GetClientRect(hWnd, &rect);
         MoveWindow(hFloatWnd,
                    0,
                    0,
                    rect.right - rect.left,
                    rect.bottom - rect.top,
                    FALSE);
         break;
      }

      // Dispatch WM_COMMAND messages to our command handler, DoCommands().

      case WM_COMMAND:
         return (DoCommands(hWnd, message, wParam, lParam));

      // On WM_DESTROY, terminate this app by posting a WM_QUIT message.

      case WM_DESTROY:
         PostQuitMessage(0);
         break;


      // We didn't handle, pass to DefWindowProc.

      default:
         return (DefWindowProc(hWnd, message, wParam, lParam));
   }
   return (NULL);
}


//-----------------------------------------------------------------------
//  DoCommands ()
//
//  Purpose:  Called by MainWndProc() to handle all WM_COMMAND type
//            messages.
//
//  Parameters:  HWND      hWnd     -  Handle to this window
//               unsigned  message  -  Message to process
//               WORD      wParam   -  WORD parameter, depends on message
//               LONG      lParam   -  LONG parameter, depends on message
//
//  Return Value:  Depends on message.
//-----------------------------------------------------------------------

long DoCommands (HWND hWnd,
                 unsigned message,
                 WORD wParam,
                 LONG lParam)
{
   switch (wParam)
   {
      // User picked File.About.  Put up the About box.
      case IDM_ABOUT:
      {
         FARPROC lpDlgProc;

         lpDlgProc = MakeProcInstance(AboutDlg, ghInst);
         DialogBox(ghInst,   // current instance
                   AboutBoxName,  // resource to use 
                   hWnd,     // parent handle   
                   lpDlgProc);    // About() instance address

         FreeProcInstance(lpDlgProc);
         break;
      }

      // User picked File.Exit.  Terminate this app.

      case IDM_EXIT:
         DestroyWindow(hWnd);
         break;

      // Must be some system command -- pass it on to the default
      // window procedure.

      default:
         return (DefWindowProc(hWnd, message, wParam, lParam));
   }
   return (NULL);
}
