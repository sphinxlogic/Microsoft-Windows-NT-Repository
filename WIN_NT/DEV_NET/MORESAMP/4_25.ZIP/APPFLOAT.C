// -----------------------------------------------------------------
// File name:  APPFLOAT.C
//
// This file contains the entry point, WinMain, to the application.
//
// Description of functions:
//
//   WinMain   -  The application's entry point function.
//
//
// Written by Microsoft Product Support Services, Windows Developer Support.
//
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
// -----------------------------------------------------------------

#include <windows.h>
#include "globals.h"
#include "init.h"
#include "appfloat.h"


//-----------------------------------------------------------------------
//  WinMain ()
//
//  Purpose:  Called by Windows on app startup.  Initializes everything,
//            and enters the application's message loop.
//
//  Parameters:  HANDLE  hInstance      -   Handle to this instance.
//               HANDLE  hPrevInstance  -   Handle to last instance of app.
//               LPSTR   lpCmdLine      -   Command Line passed into app.
//               int     nCmdShow       -   How app should come up (i.e. 
//                                          minimized/normal)
//
//  Returns Value:  Returns the return value of PostQuitMessage.
//-----------------------------------------------------------------------

int PASCAL WinMain (HANDLE hInstance,  // This instance
                    HANDLE hPrevInstance,   // Last instance
                    LPSTR lpCmdLine,   // Command Line
                    int nCmdShow) // How the window is displayed
{
   MSG msg;

   // Initialize the application if this is the first instance.

   if (!hPrevInstance)
      if (!InitApplication(hInstance))
         return (FALSE);

   // Initialize this instance of the application.
   if (!InitInstance(hInstance, nCmdShow))
      return (FALSE);

   // This is the application's message loop.  It examines all
   // messages.
   while (GetMessage(&msg,   // Put Message Here
                     NULL,   // Handle of win receiving msg
                     NULL,   // lowest message to examine
                     NULL))  // highest message to examine
   {
      TranslateMessage(&msg);     // Translates virtual key codes
      DispatchMessage(&msg); // Dispatches message to window
   }

   return (msg.wParam); // Returns the value from PostQuitMessage
}
