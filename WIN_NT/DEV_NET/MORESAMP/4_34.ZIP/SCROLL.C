/*************************************************************************

      File:  scroll.C

   Purpose:  Contains procedures used for scroll bar manipulation.
             Contains painting procedures for both text and ink, and
             contains RCRESULT and Recognition procedures for use
             with pen ink.

 Functions:     SetupText();        //WM_CREATE scrolling/etc initialization
                UpdateScrollSize();  //WM_SIZE scrolling changes
                DoVScroll();     //process Vertical Scrolling
                DoHScroll();     //process Horizontal Scrolling
                BeginPen();      //WM_LBUTTONDOWN pen activation message
                DoRCResult();     //process RCRESULT message
                DoPaint();        //WM_PAINT case routine
                FileLinesInMemory();  //number of lines in file
  Comments:  

   History:   Date     Reason

             2/20/92   Created  by Cynthia Anderson
   
   Written by Microsoft Product Support Services, Developer Support.
 
*************************************************************************/
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//


#include "windows.h"
#include "penwin.h"
#include "assert.h"
#include "stdio.h"
#include "scroll.h"
#include "globals.h"

extern HPENDATA ghPenData;



//WM_CREATE CASE         
BOOL FAR PASCAL SetupText(hwnd)
HWND hwnd;
{          
               alpha = beta = 0;
               hdc = GetDC (hwnd) ;

               GetTextMetrics (hdc, &tm) ;
               cxChar = tm.tmAveCharWidth ;
               cxCaps = (tm.tmPitchAndFamily & 1 ? 3 : 2) * cxChar / 2 ;
               cyChar = tm.tmHeight + tm.tmExternalLeading ;

               ReleaseDC (hwnd, hdc) ;

               nMaxWidth = 40 * cxChar + 18 * cxCaps ;
               return TRUE ;
}
               
//WM_SIZE
BOOL FAR PASCAL UpdateScrollSize(hwnd, lParam)
HWND hwnd;
LONG lParam;
{
               cyClient = HIWORD (lParam) ;
               cxClient = LOWORD (lParam) ;

               if (!NUMLINES)
                 NUMLINES = MAXNUMLINES;
               nVscrollMax = max (0, NUMLINES) ;
               nVscrollPos = min (nVscrollPos, nVscrollMax) ;

               SetScrollRange (hwnd, SB_VERT, 0, nVscrollMax, FALSE) ;
               SetScrollPos   (hwnd, SB_VERT, nVscrollPos, TRUE) ;

               nHscrollMax = max (0, nMaxWidth/ cxChar) ;
               nHscrollPos = min (nHscrollPos, nHscrollMax) ;

               SetScrollRange (hwnd, SB_HORZ, 0, nHscrollMax, FALSE) ;
               SetScrollPos   (hwnd, SB_HORZ, nHscrollPos, TRUE) ;
               return TRUE ;
}

               

BOOL FAR PASCAL DoVScroll(hwnd, lParam, wParam)
HWND hwnd;
LONG lParam;
WORD wParam;
{
               switch (wParam)
                    {
                    case SB_TOP:
                         nVscrollInc = -nVscrollPos ;
                         break ;

                    case SB_BOTTOM:
                         nVscrollInc = nVscrollMax - nVscrollPos ;
                         break ;

                    case SB_LINEUP:
                         nVscrollInc = -1 ;
                         break ;

                    case SB_LINEDOWN:
                         nVscrollInc = 1 ;
                         break ;

                    case SB_PAGEUP:
                         nVscrollInc = min (-1, -cyClient / cyChar) ;
                         break ;

                    case SB_PAGEDOWN:
                         nVscrollInc = max (1, cyClient / cyChar) ;
                         break ;

                    case SB_THUMBTRACK:
                         nVscrollInc = LOWORD (lParam) - nVscrollPos ;
                         break ;

                    default:
                         nVscrollInc = 0 ;
                    }
               if (nVscrollInc = max (-nVscrollPos,
                         min (nVscrollInc, nVscrollMax - nVscrollPos)))
                    {
                    nVscrollPos += nVscrollInc ;
                    ScrollWindow (hwnd, 0, -cyChar * nVscrollInc, NULL, NULL) ;
                    SetScrollPos (hwnd, SB_VERT, nVscrollPos, TRUE) ;
                    
                    beta += cyChar*nVscrollInc;

		    }
               return TRUE ;
}
               

BOOL FAR PASCAL DoHScroll(hwnd, lParam, wParam)
HWND hwnd;
LONG lParam;
WORD wParam;
{
               switch (wParam)
                    {
                    case SB_LINEUP:
                         nHscrollInc = -1 ;
                         break ;

                    case SB_LINEDOWN:
                         nHscrollInc = 1 ;
                         break ;

                    case SB_PAGEUP:
                         nHscrollInc = -8 ;
                         break ;

                    case SB_PAGEDOWN:
                         nHscrollInc = 8 ;
                         break ;

                    case SB_THUMBTRACK: //POSITION:
                         nHscrollInc = LOWORD (lParam) - nHscrollPos ;
                         break ;

                    default:
                         nHscrollInc = 0 ;
                    }
               if (nHscrollInc = max (-nHscrollPos,
                         min (nHscrollInc, nHscrollMax - nHscrollPos)))
                    {
                    nHscrollPos += nHscrollInc ;
                    ScrollWindow (hwnd, -cxChar * nHscrollInc, 0, NULL, NULL) ;
                    SetScrollPos (hwnd, SB_HORZ, nHscrollPos, TRUE) ;
                    
                    alpha += cxChar*nHscrollInc;

		    }
               return TRUE ;
}

               
//WM_LBUTTONDOWN        
BOOL FAR PASCAL BeginPen(hwnd, message)
HWND hwnd;
WORD message;
{
        if (IsPenEvent(message, GetMessageExtraInfo()))
              {
              alpha =beta = 0;
              //destroy old pen data if present
              if (ghPenData){
                 DestroyPenData(ghPenData);
                 ghPenData = NULL;
                 InvalidateRect(hwnd,NULL,TRUE);
                 }
              //initialize RC structure
              InitRC(hwnd, &rc);
              rc.hrec=NULL;
              
              if (nInkWidth)
                rc.nInkWidth = nInkWidth;
              if (rgbColor)
                rc.rgbInk = rgbColor;
              
              //Begin recognition
              Recognize(&rc);
              }

return TRUE;
}


BOOL FAR PASCAL DoRCResult(hwnd, lParam)
HWND hwnd;
LONG lParam;
{
 POINT pt;
 LPRCRESULT lprcresult = (LPRCRESULT)lParam;
           
           if (lprcresult == NULL){
              MessageBox(NULL,"lparam=NULL","WM_RCRESULT",MB_OK);
              return FALSE;
              }
           
           // save pen data block
           ghPenData = DuplicatePenData(lprcresult->hpendata, GMEM_MOVEABLE);
           
           //convert pen data block to DISPLAY coordinates
           MetricScalePenData(ghPenData, PDTS_DISPLAY);
         
           //remove duplicate points from pen data block
           //we aren't going to worry about re-recoginizing the data
           CompactPenData(ghPenData, PDTT_COLINEAR);
           pt.x = pt.y = 0;
           ClientToScreen(hwnd, &pt);
           OffsetPenData(ghPenData, -pt.x, -pt.y);
              
           return TRUE;
} 
  
        

BOOL FAR PASCAL DoPaint(hwnd)
HWND hwnd;
{
           HDC hdc;
           LPSTR lpStrBase, lpStrBeg, lpStrEnd;
           PAINTSTRUCT ps;  
           PENDATAHEADER PenDataHeader;
           PENINFO PenInfo;
           DWORD dwReserved;
           LPPENDATA lpPenData = NULL;
           POINT pt;
           int line;
           
                
           hdc = BeginPaint (hwnd, &ps) ;
           
           if (hData) 
           {
           
           
           lpStrBase = GlobalLock(hData);
           lpStrBeg = lpStrBase;
           lpStrEnd = lpStrBase;
              
           nPaintBeg = max (0, nVscrollPos + ps.rcPaint.top / cyChar - 1) ;
           nPaintEnd = min (NUMLINES,
                            nVscrollPos + ps.rcPaint.bottom / cyChar) ;

           i = nPaintBeg;
           {
                   x = cxChar * (1 - nHscrollPos) ;
                   y = cyChar * (1 - nVscrollPos + i) ;

                 line = 0;
                 if (((DWORD)(lpStrEnd-lpStrBase) < dwSize) && (line !=i))
                 {
                  //scan forward to i-th line
                  while (line != i)
                  {
                    while ((*(lpStrEnd+1) != '\n') && ((DWORD)(lpStrEnd-lpStrBase) < dwSize))
                      {
                      lpStrEnd++;
                      }
                      
                      line++;
                      
                      if (((DWORD)(lpStrEnd-lpStrBase) < dwSize) && ((DWORD)(lpStrEnd-lpStrBase)+1 < dwSize))
                      {
                       lpStrBeg = (lpStrEnd+2); //skip '\n' character
                       lpStrEnd = (lpStrEnd+2);  //move end to same point as Begin
                      }
                  } 
                }
                
                while ((DWORD)(lpStrEnd-lpStrBase) < dwSize)
                {
                  
                  if (((DWORD)(lpStrEnd-lpStrBase) < dwSize) && (*(lpStrEnd+1) != '\n'))
                    {
                    //continue scanning
                    lpStrEnd++; 
                    }
                  else
                    {
                    //found \n or EOF
                    TextOut(hdc,x,y,lpStrBeg,(int)(lpStrEnd-lpStrBeg));
                    i++;
                    y = cyChar * (1 - nVscrollPos + i) ;
                    if (((DWORD)(lpStrEnd-lpStrBase) < dwSize) && ((DWORD)(lpStrEnd-lpStrBase)+1 < dwSize))
                      {
                       lpStrBeg = (lpStrEnd+2); //skip '\n' character
                       lpStrEnd = (lpStrEnd+2);  //move end to same point as Begin
                      }
                    }
                    
                  }
                  
                    GlobalUnlock(hData);
             
         }
         }  //end hData conditional
         
//annotate
        pt.x = alpha;
        pt.y = beta;
	if (ghPenData)
          {
           GetPenDataInfo(ghPenData,
                         (LPPENDATAHEADER)&PenDataHeader,
                         (LPPENINFO) &PenInfo,
                         dwReserved);
 
           if (ghPenData)
              RedisplayPenData(hdc, ghPenData, &pt,NULL,
                               PenDataHeader.nInkWidth,  //2,
                               PenDataHeader.rgbInk);    //RGB(250,0,0));
          }
  
        EndPaint (hwnd, &ps) ;
          
return TRUE;
}
          
int FAR PASCAL FileLinesInMemory(hData, dwSize)
HANDLE hData;
DWORD dwSize;
{
       int line = 0;
       LPSTR lpStrBase, lpStrEnd, lpStrBeg;
       
       lpStrBase = GlobalLock(hData);
       lpStrEnd = lpStrBeg = lpStrBase;
       
       assert(lpStrBase != NULL);
       
       while ((DWORD)(lpStrEnd-lpStrBase) < dwSize)
       {
       //scan forward 
           while ((*(lpStrEnd+1) != '\n') && ((DWORD)(lpStrEnd-lpStrBase) < dwSize))
             {
             lpStrEnd++;
             }
                      
             line++;
                      
             if (((DWORD)(lpStrEnd-lpStrBase) < dwSize) && ((DWORD)(lpStrEnd-lpStrBase)+1 < dwSize))
             {
             lpStrBeg = (lpStrEnd+2); //skip '\n' character
             lpStrEnd = (lpStrEnd+2);  //move end to same point as Begin
             }
      }
      
      GlobalUnlock(hData);
      
return line;
}
                
