/*************************************************************************

      File:  Annotate.C

   Purpose:  Demonstrates FileOpen Common Dialog and Annotation of
             of text files with Windows for Pen.

 Functions:     WinMain() - calls initialization function, processes message loop
                InitApplication() - initializes window data and registers window
                InitInstance() - saves instance handle and creates main window
                MainWndProc() - processes messages
                About() - processes messages for "About" dialog box
                ReadData() - Reads in a file to global memory

  Comments:  

   History:   Date     Reason

             2/20/92   Created  by Cynthia Anderson
   
   Written by Microsoft Product Support Services, Developer Support.
 
*************************************************************************/
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "windows.h"
#include "penwin.h"
#include "assert.h"
#include "stdio.h"
#include "annotate.h"
#include "commdlg.h"
#include "globals.h"
#include "scroll.h"

HPENDATA ghPenData = NULL;



HANDLE hInst;

HANDLE hAccTable;                               /* handle to accelerator table */
HWND hwnd;                                      /* handle to main window */

/* new variables for common dialogs */

OPENFILENAME ofn;
char szFilterSpec [128] =                       /* file type filters */
             "Text Files (*.TXT)\0*.TXT\0All Files (*.*)\0*.*\0";

char szFileName[MAXFILENAME];
char szFileTitle[MAXFILENAME];

char szBaseWindowTitle[] = "Annotation Sample Application";
char szWindowTitle[80];

//**************************************************************************
//
//  Function:  ReadData(hFile, dwSize)
//
//   Purpose:  To read a specific file and fill global variables.
//
//   Returns:  handle to global memory
//
//   History:  Date      Reason
//             --------  -----------------------------------
//
//             2/18/92  Created
//
//*************************************************************************
HANDLE NEAR PASCAL ReadData(hFile, dwSize)
HFILE hFile;
DWORD * dwSize;
{
   HANDLE  hData;

         (*dwSize) =2048L;
         if( (hData=GlobalAlloc(GMEM_MOVEABLE | GMEM_ZEROINIT,(*dwSize) )) )
         {
            LPSTR lpStr;
            int nRead;

            lpStr=GlobalLock(hData);

            (*dwSize) =0;
            while( (nRead=_lread(hFile,lpStr,2048))==2048 ) // read in 2K blocks
            { // full buffer
               (*dwSize)+=nRead;
               GlobalUnlock(hData);
               hData = GlobalReAlloc(hData,(*dwSize)+2048L,GMEM_MOVEABLE);
               assert(hData != NULL);
               lpStr=GlobalLock(hData);
               lpStr+=(int)(*dwSize);
            }
            (*dwSize)+=nRead;
            GlobalUnlock(hData);
            hData = GlobalReAlloc(hData,(*dwSize),GMEM_MOVEABLE);
            assert(hData != NULL);
         }
         _lclose(hFile);        
       
         if ((*dwSize) > 65536)  //File too big, would cross segment boundaries
            {
            GlobalFree(hData);
            MessageBox(NULL,"File Too Large",">64K",MB_OK);
            hData = NULL;
            }
            
         NUMLINES = 0;
         if (hData)
             NUMLINES = (int) FileLinesInMemory(hData, (*dwSize));
         if (!NUMLINES)
            NUMLINES = MAXNUMLINES;
         
         //new file? then, wipe the old annotation ink
         if (ghPenData)
           {
           DestroyPenData(ghPenData);
           ghPenData = NULL;
           }
           
           
 
   return hData;
}

/****************************************************************************

    FUNCTION: WinMain(HANDLE, HANDLE, LPSTR, int)

    PURPOSE: calls initialization function, processes message loop

****************************************************************************/

int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HANDLE hInstance;
HANDLE hPrevInstance;
LPSTR lpCmdLine;
int nCmdShow;
{
    MSG msg;

    if (!hPrevInstance)
        if (!InitApplication(hInstance))
            return (FALSE);

    if (!InitInstance(hInstance, nCmdShow))
        return (FALSE);

    while (GetMessage(&msg, NULL, NULL, NULL)) {

    /* Only translate message if it is not an accelerator message */

        if (!TranslateAccelerator(hwnd, hAccTable, &msg)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg); 
        }
    }
    return (msg.wParam);
}


/****************************************************************************

    FUNCTION: InitApplication(HANDLE)

    PURPOSE: Initializes window data and registers window class

****************************************************************************/

BOOL InitApplication(hInstance)
HANDLE hInstance;
{
    WNDCLASS  wc;

    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = MainWndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(hInstance, "ANNOTATE");
    wc.hCursor = LoadCursor(NULL, IDC_PEN);
    wc.hbrBackground = GetStockObject(WHITE_BRUSH); 
    wc.lpszMenuName =  "FileOpenMenu";
    wc.lpszClassName = "FileOpenWClass";

    return (RegisterClass(&wc));
}


/****************************************************************************

    FUNCTION:  InitInstance(HANDLE, int)

    PURPOSE:  Saves instance handle and creates main window

****************************************************************************/

BOOL InitInstance(hInstance, nCmdShow)
    HANDLE          hInstance;
    int             nCmdShow;
{
    RECT            Rect;

    hInst = hInstance;

    hAccTable = LoadAccelerators(hInst, "FileOpenAcc");

    hwnd = CreateWindow(
        "FileOpenWClass",
        szBaseWindowTitle,
        WS_OVERLAPPEDWINDOW | WS_VSCROLL | WS_HSCROLL,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        NULL,
        NULL,
        hInstance,
        NULL
    );

    if (!hwnd)
        return (FALSE);

    GetClientRect(hwnd, (LPRECT) &Rect);

    /* Create a child window */


    /* fill in non-variant fields of OPENFILENAME struct. */
    ofn.lStructSize       = sizeof(OPENFILENAME);
    ofn.hwndOwner         = hwnd;
    ofn.lpstrFilter       = szFilterSpec;
    ofn.lpstrCustomFilter = NULL;
    ofn.nMaxCustFilter    = 0;
    ofn.nFilterIndex      = 1;
    ofn.lpstrFile         = szFileName;
    ofn.nMaxFile          = MAXFILENAME;
    ofn.lpstrInitialDir   = NULL;
    ofn.lpstrFileTitle    = szFileTitle;
    ofn.nMaxFileTitle     = MAXFILENAME;
    ofn.lpstrTitle        = NULL;
    ofn.lpstrDefExt       = "TXT";
    ofn.Flags             = 0;

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);
    return (TRUE);

}

/****************************************************************************

    FUNCTION: MainWndProc(HWND, UINT, WPARAM, LPARAM)

    PURPOSE:  Processes messages

    MESSAGES:

        WM_COMMAND    - application menu (About dialog box)
        WM_DESTROY    - destroy window

    COMMENTS:

        WM_COMMAND processing:

            IDM_OPEN - query to save current file if there is one and it
                       has been changed, open a new file.

            IDM_ABOUT - display "About" box.

****************************************************************************/

long FAR PASCAL MainWndProc(hWnd, message, wParam, lParam)
HWND hWnd;
UINT message;
WPARAM wParam;
LPARAM lParam;
{
    FARPROC lpProcAbout;

    switch (message) {
        case WM_CREATE:
           /* initialize Ink parameters for menus */
           nInkWidth = 0;
           rgbColor = 0;
           SetupText(hWnd);
        break;
        
        case WM_COMMAND:
            switch (wParam) 
            {  
                case IDM_REDINK:                    
                    rgbColor = RGB(255,0,0);
                    break;
                case IDM_BLUEINK:
                    rgbColor = RGB(0,0,255);
                    break;
                case IDM_GREENINK:
                    rgbColor = RGB(0,255,0);
                    break;
                case IDM_PURPLEINK:
                    rgbColor = RGB(155,0,100);
                    break;
                case IDM_INKWIDTH1:
                    nInkWidth = 1;
                    break;
                case IDM_INKWIDTH2:
                    nInkWidth = 2;
                    break;
                case IDM_INKWIDTH3:
                    nInkWidth = 3;
                    break;
    
              
                case IDM_ABOUT:
                    lpProcAbout = MakeProcInstance(About, hInst);
                    DialogBox(hInst, "AboutBox", hWnd, lpProcAbout);
                    FreeProcInstance(lpProcAbout);
                    break;

                case IDM_OPEN:
                 if (hData)
                    GlobalFree(hData);

                    /* Use standard open dialog */

                    if (!GetOpenFileName ((LPOPENFILENAME)&ofn))
                        return FALSE;

                    lstrcpy(szWindowTitle, szBaseWindowTitle);
                    lstrcat(szWindowTitle, " - ");
                    lstrcat(szWindowTitle, szFileTitle);
                    SetWindowText(hWnd, szWindowTitle);

                    hFile = _lopen(ofn.lpstrFile,OF_READ);
                    if (hFile != -1)
                       hData = ReadData(hFile, &dwSize);
                       
                    if (hData == NULL)
                       MessageBox(NULL,"Could Not Open File", "File Error", MB_OK);

                    InvalidateRect(hWnd,NULL,TRUE);

                   break;

                case IDM_SAVEAS:

                    /* Use standard save dialog */
                    //not implemented yet

           //         if (!GetSaveFileName ((LPOPENFILENAME)&ofn))
           //             return FALSE;

           //         lstrcpy(szWindowTitle, szBaseWindowTitle);
          //         lstrcat(szWindowTitle, " - ");
          //          lstrcat(szWindowTitle, szFileTitle);
          //          SetWindowText(hWnd, szWindowTitle);
                   break;

                case IDM_NEW:
                case IDM_SAVE:
                case IDM_PRINT:
                    break;  

                case IDM_EXIT:
                    DestroyWindow(hWnd);
                    break;
    
                /* edit menu commands */

                case IDM_UNDO:
                case IDM_CUT:
                case IDM_COPY:
                case IDM_PASTE:
                case IDM_CLEAR:
                    MessageBox (
                          GetFocus(),
                          "Command not implemented",
                          "FileOpen Sample Application",
                          MB_ICONASTERISK | MB_OK);
                    break;  

                case IDC_EDIT:
                    if (HIWORD (lParam) == EN_ERRSPACE) {
                        MessageBox (
                              GetFocus ()
                            , "Out of memory."
                            , "FileOpen Sample Application"
                            , MB_ICONHAND | MB_OK
                        );
                    }
                    break;
                    
                   
            } 
            break;

        case WM_MOVE:
          InvalidateRect(hWnd,NULL,TRUE);
        break;

        case WM_SIZE:
          UpdateScrollSize(hWnd, lParam);
          break;
        
        case WM_LBUTTONDOWN:
          BeginPen(hWnd, message);
        break;
        
        case WM_RCRESULT:
          DoRCResult(hWnd, lParam);
        break;
        
        case WM_PAINT:
          DoPaint(hWnd);  
        break;
        
        case WM_VSCROLL:
          DoVScroll(hWnd, lParam, wParam);
        break;
        
        case WM_HSCROLL:
          DoHScroll(hWnd, lParam, wParam);
        break; 
            
        case WM_DESTROY:
            if (ghPenData)
               {
               DestroyPenData(ghPenData);
               ghPenData = NULL;
               }
            if (hData)
              GlobalFree(hData);
            PostQuitMessage(0);
            break;

        default:
            return (DefWindowProc(hWnd, message, wParam, lParam));
    }
    return (NULL);
}

/****************************************************************************

    FUNCTION: About(HWND, unsigned, WORD, LONG)

    PURPOSE:  Processes messages for "About" dialog box

    MESSAGES:

        WM_INITDIALOG - initialize dialog box
        WM_COMMAND    - Input received

****************************************************************************/

BOOL FAR PASCAL About(hDlg, message, wParam, lParam)
HWND hDlg;
unsigned message;
WORD wParam;
LONG lParam;
{
    switch (message) {
        case WM_INITDIALOG:
            return (TRUE);

        case WM_COMMAND:
            if (wParam == IDOK
                || wParam == IDCANCEL) {
                EndDialog(hDlg, TRUE);
                return (TRUE);
            }
            break;
    }
    return (FALSE);
}
