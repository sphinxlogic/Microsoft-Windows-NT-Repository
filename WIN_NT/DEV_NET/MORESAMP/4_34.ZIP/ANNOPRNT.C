/*************************************************************************

      File:  Annoprnt.C

   Purpose:  Demonstrates FileOpen Common Dialog and Annotation of
             of text files with Windows for Pen and the printing of
             that annotation.

 Functions:     WinMain() - calls initialization function, processes message loop
                InitApplication() - initializes window data and registers window
                InitInstance() - saves instance handle and creates main window
                MainWndProc() - processes messages
                About() - processes messages for "About" dialog box
                ReadData() - Reads in a file to global memory

  Comments:  

   History:   Date     Reason

             2/20/92   Created  by Cynthia Anderson
             7/1/92    completed modifications for printing
   
   Written by Microsoft Product Support Services, Developer Support.
  
*************************************************************************/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "windows.h"
#include "penwin.h"
#include "drivinit.h"
#include "string.h"
#include "assert.h"
#include "stdio.h"
#include "annoprnt.h"
#include "commdlg.h"
#include "globals.h"
#include "scroll.h"
#include "print.h"

HPENDATA ghPenData = NULL;



HANDLE hInst;

HANDLE hAccTable;                               /* handle to accelerator table */
HWND hWnd;                                      /* handle to main window */

/* new variables for common dialogs */

char szTemp[128];
HANDLE hHourGlass;                        /* handle to hourglass cursor      */
HANDLE hSaveCursor;                       /* current cursor handle      */

PRINTDLG pd;                        /* Common print dialog structure */

OPENFILENAME ofn;
char szFilterSpec [128] =                       /* file type filters */
             "Text Files (*.TXT)\0*.TXT\0All Files (*.*)\0*.*\0";

char szFileName[MAXFILENAME];
char szFileTitle[MAXFILENAME];

char szBaseWindowTitle[] = "Annotation Sample Application";
char szWindowTitle[80];

          
int FAR PASCAL FileLinesInMemory(hData, dwSize)
HANDLE hData;
DWORD dwSize;
{
       int line = 0;
       LPSTR lpStrBase, lpStrEnd, lpStrBeg;
       
       lpStrBase = GlobalLock(hData);
       lpStrEnd = lpStrBeg = lpStrBase;
       
       assert(lpStrBase != NULL);
       
       while ((DWORD)(lpStrEnd-lpStrBase) < dwSize)
       {
       //scan forward 
           while ((*(lpStrEnd+1) != '\n') && ((DWORD)(lpStrEnd-lpStrBase) < dwSize))
             {
             lpStrEnd++;
             }
                      
             line++;
                      
             if (((DWORD)(lpStrEnd-lpStrBase) < dwSize) && ((DWORD)(lpStrEnd-lpStrBase)+1 < dwSize))
             {
             lpStrBeg = (lpStrEnd+2); //skip '\n' character
             lpStrEnd = (lpStrEnd+2);  //move end to same point as Begin
             }
      }
      
      GlobalUnlock(hData);
      
return line;
}

BOOL FAR PASCAL DoAnnotation(HDC hPr)
{
           PENDATAHEADER PenDataHeader;
           PENINFO PenInfo;
           DWORD dwReserved;
           LPPENDATA lpPenData = NULL;
           HDC hDisplayDC = NULL;
           int nDisplayPageSize = 5;
           int nDisplayPageWidth = 5;
           float nXFactor, nYFactor;
           HPEN hInkPen = NULL;
           HPEN hOldPen;
           
//annoprnt
        if (ghPenData)
          {
           GetPenDataInfo(ghPenData,
                         (LPPENDATAHEADER)&PenDataHeader,
                         (LPPENINFO) &PenInfo,
                         dwReserved);
 
           hDisplayDC = GetDC(hWnd);
           nDisplayPageSize = GetDeviceCaps (hDisplayDC, VERTRES);
           nDisplayPageWidth = GetDeviceCaps (hDisplayDC, HORZRES);
           ReleaseDC(hWnd, hDisplayDC);
           nPageSize = GetDeviceCaps (hPr, VERTRES);
           nPageWidth = GetDeviceCaps (hPr, HORZRES);
           
           nXFactor = (float)nPageWidth/nDisplayPageWidth;
           nYFactor = (float)nPageSize/nDisplayPageSize;
           
           penrect.top = (int)PenDataHeader.rectBound.top ;
           penrect.left = (int)PenDataHeader.rectBound.left ;
           penrect.right = (int)PenDataHeader.rectBound.right ;
           penrect.bottom = (int)PenDataHeader.rectBound.bottom ;
           
        //create a pen the same color and width of pen used in annotation
           hInkPen = CreatePen(PS_SOLID,
                               PenDataHeader.nInkWidth,  
                               (COLORREF)PenDataHeader.rgbInk);
           if (hInkPen)
              hOldPen = SelectObject(hPr, hInkPen); 
           DrawPenData(hPr, NULL, ghPenData);
           SelectObject(hPr, hOldPen);
           DeleteObject(hInkPen); 
          }
  
return TRUE;
}

BOOL FAR PASCAL DoPrint(hWnd)
HWND hWnd;
{
          
           LPSTR lpStrBase, lpStrBeg, lpStrEnd;
           HDC hDC;
           int cxScreenInch, cyScreenInch, cxPrintInch, cyPrintInch;
           static HFONT hPrFont, hOldFont;
                    
           hSaveCursor = SetCursor(hHourGlass);
           hPr = GetPrinterDC();
           if (!hPr) 
              {
              sprintf(szTemp, "Cannot print %s", szFileName);
              MessageBox(hWnd, szTemp, NULL, MB_OK | MB_ICONHAND);
              return (NULL);
              }

           //set up Printer Device Context
           hDC = GetDC(hWnd);
           cxScreenInch = GetDeviceCaps(hDC, LOGPIXELSX);
           cyScreenInch = GetDeviceCaps(hDC, LOGPIXELSY);
           ReleaseDC(hWnd, hDC);
           
           
           cxPrintInch = GetDeviceCaps(hPr, LOGPIXELSX);
           cyPrintInch = GetDeviceCaps(hPr, LOGPIXELSY);
           
           SetBkMode(hPr, TRANSPARENT);
           SetMapMode(hPr, MM_ANISOTROPIC);
           SetWindowExt(hPr, cxScreenInch, cyScreenInch);
           SetViewportExt(hPr, cxPrintInch, cyPrintInch);
           
           hPrFont = CreateFontIndirect((PLOGFONT)&gTTlogfont);
           hOldFont = SelectObject(hPr, hPrFont);
           
              lpAbortDlg =  MakeProcInstance(AbortDlg, hInst);
              lpAbortProc = MakeProcInstance(AbortProc, hInst);

              /* Define the abort function */

              Escape(hPr, SETABORTPROC, NULL,
                        (LPSTR)  lpAbortProc,
                        (LPSTR) NULL);

              if (Escape(hPr, STARTDOC, 14, "PrntFile text",
                      (LPSTR) NULL) < 0) 
                 {
                 MessageBox(hWnd, "Unable to start print job",
                            NULL, MB_OK | MB_ICONHAND);
                 FreeProcInstance(lpAbortDlg);
                 FreeProcInstance(lpAbortProc);
                 DeleteDC(hPr);
                 }

              bAbort = FALSE; /* Clears the abort flag  */

              /* Create the Abort dialog box (modeless) */

              hAbortDlgWnd = CreateDialog(hInst, "AbortDlg",
                        hWnd, lpAbortDlg);

              if (!hAbortDlgWnd) 
                  {
                  SetCursor(hSaveCursor);      /* Remove the hourglass */
                  MessageBox(hWnd, "NULL Abort window handle",
                            NULL, MB_OK | MB_ICONHAND);
                  return (FALSE);
                  }
                    
              /* Now show Abort dialog */

              ShowWindow (hAbortDlgWnd, SW_NORMAL);

              /* Disable the main window to avoid reentrancy problems */

              EnableWindow(hWnd, FALSE);
              SetCursor(hSaveCursor);      /* Remove the hourglass */

                    /* Since you may have more than one line, you need to
                     * compute the spacing between lines.  You can do that by
                     * retrieving the height of the characters you are printing
                     * and advancing their height plus the recommended external
                     * leading height.
                     */

                    GetTextMetrics(hPr, &TextMetric);
                    LineSpace = TextMetric.tmHeight +
                        TextMetric.tmExternalLeading;

                    /* Since you may have more lines than can fit on one
                     * page, you need to compute the number of lines you can
                     * print per page.  You can do that by retrieving the
                     * dimensions of the page and dividing the height
                     * by the line spacing.
                     */

                    nPageSize = GetDeviceCaps (hPr, VERTRES);
                    nPageWidth = GetDeviceCaps (hPr, HORZRES);
                    LinesPerPage = nPageSize / LineSpace - 1;


                    /* You can output only one line at a time, so you need a
                     * count of the number of lines to print. */

                   // wLines = FileLinesInMemory();

                    /* Keep track of the current line on the current page */

                    CurrentLine = 1;

                    /* One way to output one line at a time is to retrieve
                     * one line at a time from the memory and write it
                     * using the TextOut function.  For each line you need to
                     * advance one line space.  Also, you need to check for the
                     * end of the page and start a new page if necessary.
                     */

           
         if (hData) 
           {
           lpStrBase = GlobalLock(hData);
           lpStrBeg = lpStrBase;
           lpStrEnd = lpStrBase;
       
           while ((DWORD)(lpStrEnd-lpStrBase) < dwSize)
                {
                if (((DWORD)(lpStrEnd-lpStrBase) < dwSize) && (*(lpStrEnd+1) != '\n'))
                    {
                    //continue scanning
                    lpStrEnd++; 
                    }
                  else
                    {
                    //found \n or EOF
                    TextOut(hPr,0, CurrentLine*LineSpace,
                            lpStrBeg,(int)(lpStrEnd-lpStrBeg));
                    
                    if (++CurrentLine > LinesPerPage)
                      {
                      DoAnnotation(hPr);
                      CurrentLine = 1;
                      Status = Escape(hPr, NEWFRAME, 0,0L,0L);
                      if (Status < 0 || bAbort)
                         break;
                      }
                    if (((DWORD)(lpStrEnd-lpStrBase) < dwSize) && ((DWORD)(lpStrEnd-lpStrBase)+1 < dwSize))
                      {
                       lpStrBeg = (lpStrEnd+2); //skip '\n' character
                       lpStrEnd = (lpStrEnd+2);  //move end to same point as Begin
                      }
                    }
                 }
                 GlobalUnlock(hData);
             
         }  //end hData conditional
       
       
                    DoAnnotation(hPr);
                    if (Status >= 0 && !bAbort) {
                        Escape(hPr, NEWFRAME, 0, 0L, 0L);
                        Escape(hPr, ENDDOC, 0, 0L, 0L);
                    }
                    EnableWindow(hWnd, TRUE);

                    /* Destroy the Abort dialog box */

                    DestroyWindow(hAbortDlgWnd);
                    FreeProcInstance(lpAbortDlg);
                    FreeProcInstance(lpAbortProc);
                    
                    SelectObject(hPr, hOldFont);
                    DeleteObject(hPrFont);
                    DeleteDC(hPr);
        
return TRUE;
}
 
 
 

/****************************************************************************

    FUNCTION: GetPrinterDC()

    PURPOSE:  Get hDc for current device on current output port according to
              info in WIN.INI.

    COMMENTS:

        Searches WIN.INI for information about what printer is connected, and
        if found, creates a DC for the printer.

        returns
            hDC > 0 if success
            hDC = 0 if failure

****************************************************************************/

HDC GetPrinterDC(void)
{

    HDC         hDC;
    LPDEVMODE   lpDevMode = NULL;
    LPDEVNAMES  lpDevNames;
    LPSTR       lpszDriverName;
    LPSTR       lpszDeviceName;
    LPSTR       lpszPortName;

    if (!PrintDlg((LPPRINTDLG)&pd))
        return(NULL);

    if (pd.hDC)
      {
        hDC = pd.hDC;
      }
    else
      {

        if (!pd.hDevNames)
            return(NULL);

        lpDevNames = (LPDEVNAMES)GlobalLock(pd.hDevNames);
        lpszDriverName = (LPSTR)lpDevNames + lpDevNames->wDriverOffset;
        lpszDeviceName = (LPSTR)lpDevNames + lpDevNames->wDeviceOffset;
        lpszPortName   = (LPSTR)lpDevNames + lpDevNames->wOutputOffset;
        GlobalUnlock(pd.hDevNames);

        if (pd.hDevMode)
            lpDevMode = (LPDEVMODE)GlobalLock(pd.hDevMode);

        hDC = CreateDC(lpszDriverName, lpszDeviceName, lpszPortName, (LPSTR)lpDevMode);

        if (pd.hDevMode && lpDevMode)
            GlobalUnlock(pd.hDevMode);
      }

    if (pd.hDevNames)
        {
        GlobalFree(pd.hDevNames);
        pd.hDevNames=NULL;
        }
    if (pd.hDevMode)
       {
       GlobalFree(pd.hDevMode);
       pd.hDevMode=NULL;
       }
    return(hDC);
}

/****************************************************************************

    FUNCTION: AbortProc()

    PURPOSE:  Processes messages for the Abort Dialog box

****************************************************************************/

int FAR PASCAL AbortProc(hPr, Code)
HDC hPr;                            /* for multiple printer display contexts */
int Code;                           /* printing status                */
{
    MSG msg;

    if (!hAbortDlgWnd)              /* If the abort dialog isn't up yet */
        return(TRUE);

    /* Process messages intended for the abort dialog box */

    while (!bAbort && PeekMessage(&msg, NULL, NULL, NULL, TRUE))
        if (!IsDialogMessage(hAbortDlgWnd, &msg)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }

    /* bAbort is TRUE (return is FALSE) if the user has aborted */

    return (!bAbort);
}

/****************************************************************************

    FUNCTION: AbortDlg(HWND, unsigned, WORD, LONG)

    PURPOSE:  Processes messages for printer abort dialog box

    MESSAGES:

        WM_INITDIALOG - initialize dialog box
        WM_COMMAND    - Input received

    COMMENTS

        This dialog box is created while the program is printing, and allows
        the user to cancel the printing process.

****************************************************************************/

int FAR PASCAL AbortDlg(hDlg, msg, wParam, lParam)
HWND hDlg;
unsigned msg;
WORD wParam;
LONG lParam;
{
    switch(msg) {

        /* Watch for Cancel button, RETURN key, ESCAPE key, or SPACE BAR */

        case WM_COMMAND:
            return (bAbort = TRUE);

        case WM_INITDIALOG:

            /* Set the focus to the Cancel box of the dialog */

            SetFocus(GetDlgItem(hDlg, IDCANCEL));
            SetDlgItemText(hDlg, IDC_FILENAME, szFileName);
            return (TRUE);
        }
    return (FALSE);
}


//**************************************************************************
//
//  Function:  ReadData(hFile, dwSize)
//
//   Purpose:  To read a specific file and fill global variables.
//
//   Returns:  handle to global memory
//
//   History:  Date      Reason
//             --------  -----------------------------------
//
//             2/18/92  Created
//
//*************************************************************************
HANDLE NEAR PASCAL ReadData(hFile, dwSize)
HFILE hFile;
DWORD * dwSize;
{
   HANDLE  hData;

         (*dwSize) =2048L;
         if( (hData=GlobalAlloc(GMEM_MOVEABLE | GMEM_ZEROINIT,(*dwSize) )) )
         {
            LPSTR lpStr;
            int nRead;

            lpStr=GlobalLock(hData);

            (*dwSize) =0;
            while( (nRead=_lread(hFile,lpStr,2048))==2048 ) // read in 2K blocks
            { // full buffer
               (*dwSize)+=nRead;
               GlobalUnlock(hData);
               hData = GlobalReAlloc(hData,(*dwSize)+2048L,GMEM_MOVEABLE);
               assert(hData != NULL);
               lpStr=GlobalLock(hData);
               lpStr+=(int)(*dwSize);
            }
            (*dwSize)+=nRead;
            GlobalUnlock(hData);
            hData = GlobalReAlloc(hData,(*dwSize),GMEM_MOVEABLE);
            assert(hData != NULL);
         }
         _lclose(hFile);        
       
         if ((*dwSize) > 65536)  //File too big, would cross segment boundaries
            {
            GlobalFree(hData);
            MessageBox(NULL,"File Too Large",">64K",MB_OK);
            hData = NULL;
            }
            
         NUMLINES = 0;
         if (hData)
             NUMLINES = (int) FileLinesInMemory(hData, (*dwSize));
         if (!NUMLINES)
            NUMLINES = MAXNUMLINES;
         
         //new file? then, wipe the old annotation ink
         if (ghPenData)
           {
           DestroyPenData(ghPenData);
           ghPenData = NULL;
           }
           
           
 
   return hData;
}

/****************************************************************************

    FUNCTION: WinMain(HANDLE, HANDLE, LPSTR, int)

    PURPOSE: calls initialization function, processes message loop

****************************************************************************/

int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HANDLE hInstance;
HANDLE hPrevInstance;
LPSTR lpCmdLine;
int nCmdShow;
{
    MSG msg;

    if (!hPrevInstance)
        if (!InitApplication(hInstance))
            return (FALSE);

    if (!InitInstance(hInstance, nCmdShow))
        return (FALSE);

    while (GetMessage(&msg, NULL, NULL, NULL)) {

    /* Only translate message if it is not an accelerator message */

        if (!TranslateAccelerator(hWnd, hAccTable, &msg)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg); 
        }
    }
    return (msg.wParam);
}


/****************************************************************************

    FUNCTION: InitApplication(HANDLE)

    PURPOSE: Initializes window data and registers window class

****************************************************************************/

BOOL InitApplication(hInstance)
HANDLE hInstance;
{
    WNDCLASS  wc;

    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = (WNDPROC) MainWndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(hInstance, "ANNOPRNT");
    wc.hCursor = LoadCursor(NULL, IDC_PEN);
    wc.hbrBackground = GetStockObject(WHITE_BRUSH); 
    wc.lpszMenuName =  "FileOpenMenu";
    wc.lpszClassName = "FileOpenWClass";

    return (RegisterClass(&wc));
}


/****************************************************************************

    FUNCTION:  InitInstance(HANDLE, int)

    PURPOSE:  Saves instance handle and creates main window

****************************************************************************/

BOOL InitInstance(hInstance, nCmdShow)
    HANDLE          hInstance;
    int             nCmdShow;
{
    RECT            Rect;

    hInst = hInstance;

    hAccTable = LoadAccelerators(hInst, "FileOpenAcc");

    hWnd = CreateWindow(
        "FileOpenWClass",
        szBaseWindowTitle,
        WS_OVERLAPPEDWINDOW | WS_VSCROLL | WS_HSCROLL,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        NULL,
        NULL,
        hInstance,
        NULL
    );

    if (!hWnd)
        return (FALSE);

    GetClientRect(hWnd, (LPRECT) &Rect);

    /* Get an hourglass cursor to use during printing */

    hHourGlass = LoadCursor(NULL, IDC_WAIT);


    /* fill in non-variant fields of OPENFILENAME struct. */
    ofn.lStructSize       = sizeof(OPENFILENAME);
    ofn.hwndOwner         = hWnd;
    ofn.lpstrFilter       = szFilterSpec;
    ofn.lpstrCustomFilter = NULL;
    ofn.nMaxCustFilter    = 0;
    ofn.nFilterIndex      = 1;
    ofn.lpstrFile         = szFileName;
    ofn.nMaxFile          = MAXFILENAME;
    ofn.lpstrInitialDir   = NULL;
    ofn.lpstrFileTitle    = szFileTitle;
    ofn.nMaxFileTitle     = MAXFILENAME;
    ofn.lpstrTitle        = NULL;
    ofn.lpstrDefExt       = "TXT";
    ofn.Flags             = 0;

    /* fill in non-variant fields of PRINTDLG struct. */

    pd.lStructSize    = sizeof(PRINTDLG);
    pd.hwndOwner      = hWnd;
    pd.hDevMode       = NULL;
    pd.hDevNames      = NULL;
    pd.Flags          = PD_RETURNDC | PD_NOSELECTION | PD_NOPAGENUMS;
    pd.nCopies        = 1;

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);
    return (TRUE);

}

/****************************************************************************

    FUNCTION: MainWndProc(HWND, unsigned, WORD, LONG)

    PURPOSE:  Processes messages

    MESSAGES:

        WM_COMMAND    - application menu (About dialog box)
        WM_DESTROY    - destroy window

    COMMENTS:

        WM_COMMAND processing:

            IDM_OPEN - query to save current file if there is one and it
                       has been changed, open a new file.

            IDM_ABOUT - display "About" box.

****************************************************************************/

long FAR PASCAL MainWndProc(hWnd, message, wParam, lParam)
HWND hWnd;
unsigned message;
WORD wParam;
LONG lParam;
{
    FARPROC lpProcAbout;
    DWORD FlagSave;


    switch (message) {
        case WM_CREATE:
           /* initialize Ink parameters for menus */
           nInkWidth = 0;
           rgbColor = 0;
           SetupText(hWnd);
           
           /* initialize logfont parameters for display and printer */
           gTTlogfont.lfHeight = -15;                    /* font height*/
           gTTlogfont.lfWidth = 0;                     /* character width*/
           gTTlogfont.lfEscapement = 0;                /* escapement of line of text*/
           gTTlogfont.lfOrientation = 0;               /* angle of base line and x-axis*/
           gTTlogfont.lfWeight = 400;                   /* font weight*/
           gTTlogfont.lfItalic = 0;                   /* flag for italic attribute*/
           gTTlogfont.lfUnderline = 0;                /* flag for underline attribute*/
           gTTlogfont.lfStrikeOut = 0;                /* flag for strikeout attribute*/
           gTTlogfont.lfCharSet = 0;                  /* character set*/
           gTTlogfont.lfOutPrecision = 1;          /* output precision*/
           gTTlogfont.lfClipPrecision = 2;            /* clipping precision*/
           gTTlogfont.lfQuality = 1;                  /* output quality*/
           gTTlogfont.lfPitchAndFamily = 26;           /* pitch and family*/
           lstrcpy(gTTlogfont.lfFaceName,"Arial");                   /* address of typeface name*/

        break;
        
        case WM_COMMAND:
            switch (wParam) 
            {  
                case IDM_REDINK:                    
                    rgbColor = RGB(255,0,0);
                    break;
                case IDM_BLUEINK:
                    rgbColor = RGB(0,0,255);
                    break;
                case IDM_GREENINK:
                    rgbColor = RGB(0,255,0);
                    break;
                case IDM_PURPLEINK:
                    rgbColor = RGB(155,0,100);
                    break;
                case IDM_INKWIDTH1:
                    nInkWidth = 1;
                    break;
                case IDM_INKWIDTH2:
                    nInkWidth = 2;
                    break;
                case IDM_INKWIDTH3:
                    nInkWidth = 3;
                    break;
    
              
                case IDM_ABOUT:
                    lpProcAbout = MakeProcInstance(About, hInst);
                    DialogBox(hInst, "AboutBox", hWnd, lpProcAbout);
                    FreeProcInstance(lpProcAbout);
                    break;

                case IDM_OPEN:
                 if (hData)
                    GlobalFree(hData);

                    /* Use standard open dialog */

                    if (!GetOpenFileName ((LPOPENFILENAME)&ofn))
                        return FALSE;

                    lstrcpy(szWindowTitle, szBaseWindowTitle);
                    lstrcat(szWindowTitle, " - ");
                    lstrcat(szWindowTitle, szFileTitle);
                    SetWindowText(hWnd, szWindowTitle);

                    hFile = _lopen(ofn.lpstrFile,OF_READ);
                    if (hFile != -1)
                       hData = ReadData(hFile, &dwSize);
                       
                    if (hData == NULL)
                       MessageBox(NULL,"Could Not Open File", "File Error", MB_OK);

                    InvalidateRect(hWnd,NULL,TRUE);

                   break;

                case IDM_SAVEAS:
                case IDM_NEW:
                case IDM_SAVE:
                    break;
                    
                case IDM_EXIT:
                    DestroyWindow(hWnd);
                    break;
                
                case IDM_PRINT:
                    DoPrint(hWnd);
                    break;
                    
                case IDM_PRINTSETUP:
                    FlagSave = pd.Flags;
                    pd.Flags |= PD_PRINTSETUP;    /* Set option */
                    PrintDlg((LPPRINTDLG)&pd);
                    pd.Flags = FlagSave;          /* Remove option */
                    break;

                /* edit menu commands */

                case IDM_UNDO:
                case IDM_CUT:
                case IDM_COPY:
                case IDM_PASTE:
                case IDM_CLEAR:
                    MessageBox (
                          GetFocus(),
                          "Command not implemented",
                          "FileOpen Sample Application",
                          MB_ICONASTERISK | MB_OK);
                    break;  

                case IDC_EDIT:
                    if (HIWORD (lParam) == EN_ERRSPACE) {
                        MessageBox (
                              GetFocus ()
                            , "Out of memory."
                            , "FileOpen Sample Application"
                            , MB_ICONHAND | MB_OK
                        );
                    }
                    break;
                    
                   
            } 
            break;

        case WM_MOVE:
          InvalidateRect(hWnd,NULL,TRUE);
        break;

        case WM_SIZE:
          UpdateScrollSize(hWnd, lParam);
          break;
        
        case WM_LBUTTONDOWN:
          BeginPen(hWnd, message);
        break;
        
        case WM_RCRESULT:
          DoRCResult(hWnd, lParam);
        break;
        
        case WM_PAINT:
          DoPaint(hWnd);  
        break;
        
        case WM_VSCROLL:
          DoVScroll(hWnd, lParam, wParam);
        break;
        
        case WM_HSCROLL:
          DoHScroll(hWnd, lParam, wParam);
        break; 
            
        case WM_DESTROY:
            if (ghPenData)
               {
               DestroyPenData(ghPenData);
               ghPenData = NULL;
               }
            if (hData)
              GlobalFree(hData);
            PostQuitMessage(0);
            break;

        default:
            return (DefWindowProc(hWnd, message, wParam, lParam));
    }
    return (NULL);
}

/****************************************************************************

    FUNCTION: About(HWND, unsigned, WORD, LONG)

    PURPOSE:  Processes messages for "About" dialog box

    MESSAGES:

        WM_INITDIALOG - initialize dialog box
        WM_COMMAND    - Input received

****************************************************************************/

BOOL FAR PASCAL About(hDlg, message, wParam, lParam)
HWND hDlg;
unsigned message;
WORD wParam;
LONG lParam;
{
    switch (message) {
        case WM_INITDIALOG:
            return (TRUE);

        case WM_COMMAND:
            if (wParam == IDOK
                || wParam == IDCANCEL) {
                EndDialog(hDlg, TRUE);
                return (TRUE);
            }
            break;
    }
    return (FALSE);
}
