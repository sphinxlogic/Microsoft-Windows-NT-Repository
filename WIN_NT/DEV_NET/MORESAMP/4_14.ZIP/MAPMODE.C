/*
 * MapMode can be used to experiment with the mapping mode attributes
 * of a Device Context.
 * The attributes that can be changed are the mapping mode, window origin,
 * window extents, viewport origin and viewport extents.
 * 
 * The user can alter these attributes by using the controls in
 * the "Mapping Mode Settings" modeless dialog box.
 * 
 * The changes show up in MapMode's main window.
 * The mapping mode attribute values are displayed, along with
 * the current dimensions of the client area (in both logical and
 * device units) and the current mouse location (in both logical and
 * device units, and tracked dynamically.
 * So a typical display would look something like this:
 * 
 * 
 *     
 *                            Device Units        Logical Units
 * 
 *    Mouse Location:         ( 115, 1 )          ( 115, 1 )
 *    Bitmap Coordinates:     ( 0, 0, 100, 100 )
 *    Client Area Dimensions: ( 485, 276 )        ( 485, 276 )
 * 
 * 
 *    Mapping Mode:       MM_TEXT
 *    WindowOrg:          (  0,  0)
 *    WindowExt:          (  1,  1)
 *    ViewportOrg:        (  0,  0)
 *    ViewportExt:        (  1,  1)
 * 
 *  
 * 
 * The effects of changing the mapping mode attributes can also seen
 * by the location of the dog bitmap.  
 * StretchBlt is used to draw the dog, so when mapping mode attributes are
 * changed the dog is likely to move and grow.
 * 
 * The user can change the logical rectangle into which the dog is
 * StretchBlted by using the edit controls in the "Bitmap Coordinates"
 * modeless dialog.
 * 
 * The user can choose to display the dog, the current attribute values,
 * or both.
 * 
 * The dimensions of the client area are shown so that the user can
 * set the origin to the middle of the client area, a corner, etc
 * 
 * 
 * 
 * MENU ITEMS:
 *   Test/Mapping Mode.. - modeless dialog to change attributes"      
 *   Test/Bitmap Coordinates - modeless dialog to change bitmap coordinates"
 *   Display/Dog - show the dog bitmap"                                     
 *   Display/Values - show the current mapping mode attributes"             
 *   Display/Both - show both the dog and the values"
 *   Help/Help.. - a Help box explaining the menu choices
 *   Help/About.. - stock about box
 * 
 * 
 * IMPLEMENTATION:
 * 
 *   The main point is that the main overlapped window of the app,
 *   (whose HWND is kept as the global hWndMain), is created with
 *   a private DC by registering the clas with the CS_OWNDC style.
 *   The user can make changes to this DC by using the "Mapping
 *   Mode Settings" modeless dialog, which is implemented with
 *   MMDlgProc.  When the user hits APPLY or OK, we get the DC for
 *   hWndMain, update the values, and force a repaint. Since the window
 *   has CS_OWNDC these new settings stay in effect until the user
 *   changes them again.
 * 
 *   The bounding rectangle for the dog bitmap is kept in the global
 *   rectBM. The user can modify this rectangle with the "Bitmap
 *   Coordinates" modeless dialog, which is implemented with
 *   RectDlgProc. When the user selects APPLY or OK we update the global
 *   and force a repaint, and the new values stay in effect until the
 *   user makes further changes.
 *
 *   So the two main globals are hWndMain and rectBM and the three main
 *   routines are hWndMain, MMDlgProc and RectDlgProc
 */   

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//


/*-------------------- #includes  ------------------------------------------*/


#include "windows.h"               
#include "mapmode.h"                
#include "mmdlg.h"
#include "rectdlg.h"


/*-------------------  Global Variables ------------------------------------*/

/*
 * - hInst is our instance handle
 * - hWndMain is global because it is needed by the Mapping Mode dialog
 * - hDlgCurrent is used because we often have two modeless dialogs
 *   up simultaneously, hDlgCurrent is always updated to be the currently
 *   active modeless dialog (if there is one), and so we can safely use
 *   it in the IsDialogMessage call that is spliced into the main
 *   GetMessage loop
 * - lpfnMMDlgProc is the instance thunk for the Mapping Mode modeless dialog
 * - lpfnRectDlgProc is the instance thunk for the Bitmap Coordinates
 *   modeless dialog
 * - rectBM is the bounding rectangle into which we StretchBlt the dog bitmap
 *   the user can alter this rectangle from the Bitmap Coordinates dialog 
 */

HANDLE  hInst;
HWND    hWndMain;
HWND    hDlgCurrent = NULL;
FARPROC lpfnMMDlgProc;
FARPROC lpfnRectDlgProc;
RECT    rectBM;


/*
 * all these integers are just used to calculate where to print out
 * the status information in a device independent way
 * (in the DisplayValues routine and the WM_MOUSEMOVE case)
 *
 * See the comments for the DisplayValues routine for an illustration
 * of the display layout. looking at the layout should make these magic
 * numbers fairly clear
 */

int    xDevice, xLogical, xMMInfo, xLabel;
int    yClientDim, yMouseLoc, yHeader, yRectCoord;
int    yMapMode, yWindExt, yWindOrg, yViewExt, yViewOrg;




/*-----------------  WinMain()  --------------------------------------------*/

// pretty much stock GENERIC
// create proc instances for MMDlgProc and RectDlgProc 

int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HANDLE hInstance;                          
HANDLE hPrevInstance;                       
LPSTR  lpCmdLine;                           
int    nCmdShow;                              
{
   MSG msg;                            

   if (!hPrevInstance)                 
      if (!InitApplication(hInstance))
            return (FALSE);             
   if (!InitInstance(hInstance, nCmdShow))
       return (FALSE);

   lpfnMMDlgProc   = MakeProcInstance( MMDlgProc, hInstance );
   lpfnRectDlgProc = MakeProcInstance( RectDlgProc, hInstance );

   while (GetMessage(&msg,NULL,NULL,NULL))
        {
        if (hDlgCurrent == NULL || !IsDialogMessage( hDlgCurrent, &msg))
            {
            TranslateMessage(&msg);   
            DispatchMessage(&msg);    
            }
        }

    FreeProcInstance( lpfnMMDlgProc   );
    FreeProcInstance( lpfnRectDlgProc );

    return (msg.wParam);          
}


/*------------------  InitApplication()  -----------------------------------*/

// stock GENERIC

BOOL InitApplication(hInstance)
HANDLE hInstance;                              
{
    WNDCLASS  wc;

    wc.style            = CS_OWNDC|CS_HREDRAW|CS_VREDRAW;                  
    wc.lpfnWndProc      = MainWndProc;      
                                       
    wc.cbClsExtra       = 0;                
    wc.cbWndExtra       = 0;                
    wc.hInstance        = hInstance;          
    wc.hIcon            = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor          = LoadCursor(NULL, IDC_CROSS);
    wc.hbrBackground    = COLOR_WINDOW+1;
    wc.lpszMenuName     =  "MapModeMenu";  
    wc.lpszClassName    = "MapModeWClass"; 

    return (RegisterClass(&wc));
}


/*-----------------  InitInstance()  ---------------------------------------*/

// stock GENERIC

BOOL InitInstance(hInstance, nCmdShow)
    HANDLE          hInstance;         
    int             nCmdShow;       
{
    HWND            hWnd;              

    hInst = hInstance;

    hWnd = CreateWindow(
        "MapModeWClass",               
        "MapMode Sample - Displaying Both",  
        WS_OVERLAPPEDWINDOW,           
        CW_USEDEFAULT,                 
        CW_USEDEFAULT,                 
        CW_USEDEFAULT,                
        CW_USEDEFAULT,                 
        NULL,                          
        NULL,                         
        hInstance,                     
        NULL                           
    );

    if (!hWnd)
        return (FALSE);

    hWndMain = hWnd;
    ShowWindow  (hWnd, nCmdShow);  
    UpdateWindow(hWnd);         
    return      (TRUE);             
}


/*--------------------  MainWndProc
 * 
 *  DESCRIPTION:
 *    Window procedure for the main overlapped window
 * 
 *  ARGUMENTS:
 *    stock windproc arguments 
 * 
 *  RETURN VALUE:
 *    depends on the message handled. messages not explicitly handled
 *    are passed to DefWindowProc
 * 
 *  GLOBALS READ:
 *    hInst, lpfnMMDlgProc, lpfnRectDlgProc
 *    xDevice, xLogical, yMouseLoc
 * 
 *  GLOBALS WRITTEN:
 *    none
 *
 *  HELPER FUNCTIONS:
 *    InitRectBM, InitDisplayValues, DrawMyBitmap, DisplayValues, GetMMData
 * 
 *  NOTES:
 *    The main thing about hWndMain is that we registered its class
 *    with a CS_OWNDC.
 */ 

long FAR PASCAL MainWndProc(hWnd, message, wParam, lParam)
HWND        hWnd;                              
unsigned    message;                        
WORD        wParam;                             
LONG        lParam;                            
{
   FARPROC      lpProcAbout;
   HDC          hDC;
   PAINTSTRUCT  ps;
   POINT        ptLogical;
   TEXTMETRIC   tm;
   char         buffer[80];
   int          xChar, yChar;

   /*
    * hBitmapDog - we load the dog bitmap at WM_CREATE time and keep it around
    * nDisplay   - the users current display choice, can be IDM_DISPLAYVALUES,
    *              IDM_DISPLAYDOG or IDM_DISPLAYBOTH
    * szTitles[] - title text strings for hWndMain's title bar - we update
    *              the title when the user switchs nDisplay
    */

   static HBITMAP hBitmapDog;
   static int     nDisplay = IDM_DISPLAYBOTH;

   static char *szTitles[] = {"MapMode Sample - Displaying Dog",
                              "MapMode Sample - Displaying Values",
                              "MapMode Sample - Displaying Dog and Values" };

    switch (message)
      {
    case WM_COMMAND:       
	    switch (wParam)
	        {
	    case IDM_ABOUT:
            lpProcAbout = MakeProcInstance( About, hInst );
            DialogBox       (hInst, "AboutBox", hWnd, lpProcAbout);              
            FreeProcInstance(lpProcAbout);
            break;

        case IDM_HELP:
            lpProcAbout = MakeProcInstance( About, hInst );
            DialogBox       (hInst, "HelpBox", hWnd, lpProcAbout);              
            FreeProcInstance(lpProcAbout);
            break;

        case IDM_TESTMM:
            CreateDialog  ( hInst, "MMDialog", hWnd, lpfnMMDlgProc );
            EnableMenuItem( GetMenu( hWnd ), IDM_TESTMM, MF_BYCOMMAND|MF_GRAYED );
            DrawMenuBar   ( hWnd );
            break;

        case IDM_TESTRECT:
            CreateDialog  ( hInst, "RectDlg", hWnd, lpfnRectDlgProc );
            EnableMenuItem( GetMenu( hWnd ), IDM_TESTRECT, MF_BYCOMMAND|MF_GRAYED );
            DrawMenuBar   ( hWnd );
            break;

        case IDM_DISPLAYDOG:
        case IDM_DISPLAYVALUES:
        case IDM_DISPLAYBOTH:
            CheckMenuItem ( GetMenu( hWnd ), nDisplay, MF_UNCHECKED );
            nDisplay = wParam;
            CheckMenuItem ( GetMenu( hWnd ), nDisplay, MF_CHECKED );
            InvalidateRect( hWnd, NULL, TRUE );
            UpdateWindow  ( hWnd );
            SetWindowText ( hWnd, szTitles[wParam-IDM_DISPLAYDOG] );
            break;

        default:
            return (DefWindowProc(hWnd, message, wParam, lParam));
	        }

	    break;

    case WM_CREATE:
        // we set the background color to COLOR_WINDOW so that our
        // text background matches the window and looks better
        // since we have a private DC we just have to do this
        // once, which is nice..
        //
        // InitRectBM initializes rectBM to programmer-arbitrary values
        // InitDisplayCoordinates initializes all of the global magic
        // numbers that we use for device-independent display..

        hDC = GetDC   ( hWnd );
        SetBkColor    ( hDC, GetSysColor( COLOR_WINDOW ) );
        GetTextMetrics( hDC, &tm );
        ReleaseDC     ( hWnd, hDC );

        InitRectBM();
        InitDisplayCoordinates( tm.tmAveCharWidth,
                                tm.tmHeight + tm.tmExternalLeading );

        hBitmapDog = LoadBitmap( hInst, "dog" );

        break;

    case WM_DESTROY:                 
        PostQuitMessage(0);
        break;

    case WM_MOUSEMOVE:
        // display the mouse position in both logical and device units.
        // see the comments for the DisplayValues routine for the layout
        // of the display 
        //
        // we switch over to MM_TEXT to write our values, then switch
        // back when we are done. that way the magic numbers (xDevice,
        // yMouseLoc etc) never have to be recalculated

        if ((IDM_DISPLAYVALUES==nDisplay) || (IDM_DISPLAYBOTH==nDisplay))
            {       
            hDC = GetDC( hWnd );

            ptLogical = MAKEPOINT(lParam);
            DPtoLP( hDC, &ptLogical, 1 );

            SaveDC        ( hDC );
            SetMapMode    ( hDC, MM_TEXT );
            SetWindowOrg  ( hDC, 0, 0 );
            SetViewportOrg( hDC, 0, 0 ); 
    
            wsprintf( buffer, "(%6d,%6d)    ", LOWORD(lParam), HIWORD(lParam)  );
            TextOut ( hDC, xDevice, yMouseLoc, buffer, lstrlen( buffer ) );

            wsprintf( buffer, "(%6d,%6d)    ", ptLogical.x, ptLogical.y  );
            TextOut ( hDC, xLogical, yMouseLoc, buffer, lstrlen( buffer ) );

            RestoreDC( hDC, -1 );
            }
        break;

    case WM_PAINT:
        hDC = BeginPaint( hWnd, &ps );

        if ((IDM_DISPLAYDOG==nDisplay) || (IDM_DISPLAYBOTH==nDisplay))
            DrawMyBitmap( hDC, hBitmapDog, &rectBM );
        if ((IDM_DISPLAYVALUES==nDisplay) || (IDM_DISPLAYBOTH==nDisplay))
            DisplayValues ( hWnd, hDC );

        EndPaint( hWnd, &ps );

        break;

    default:                        
        return (DefWindowProc(hWnd, message, wParam, lParam));
    }
   return (NULL);
}



/*--------------------  InitRectBM
 *
 *  DESCRIPTION:
 *    initialize rectBM to arbitrary values. the user can update
 *    rectBM from the Bitmap Coordinates modeless dialog
 * 
 *  ARGUMENTS:
 *    none
 * 
 *  RETURN VALUE:
 *    void
 * 
 *  GLOBALS READ:
 *    none
 * 
 *  GLOBALS WRITTEN:
 *    rectBM
 * 
 *  NOTES:
 */ 

void NEAR PASCAL InitRectBM()
{
    rectBM.left   = 0;
    rectBM.top    = 0;
    rectBM.right  = 100;
    rectBM.bottom = 100;
}




/*---------------------   InitDisplayValues
 * 
 *  DESCRIPTION:
 *    initialize the global magic numbers that allow device-independent display.
 *    these values are used by the DisplayValues routine and by the WM_MOUSEMOVE
 *    case of MainWndProc
 * 
 *  ARGUMENTS:
 *    xChar - average char width 
 *    yChar - char height + external leading 
 * 
 *  RETURN VALUE:
 *    void
 * 
 *  GLOBALS READ:
 *    none
 * 
 *  GLOBALS WRITTEN:
 *    xDevice, etc etc
 * 
 *  NOTES:
 *    there is a sample display layout in the comments to the DisplayValues
 *    routine   
 */ 

void NEAR PASCAL InitDisplayCoordinates( int xChar, int yChar )
{
    xDevice    = xChar * COLDEVICE;
    xLogical   = xChar * COLLOGICAL;
    xMMInfo    = xChar * COLMAPMODE;
    xLabel     = xChar * COLLABEL;
    yHeader    = yChar * ROWHEADER;
    yMouseLoc  = yChar * ROWMOUSELOC;
    yRectCoord = yChar * ROWRECTCOORD;
    yClientDim = yChar * ROWCLIENTDIM;
    yMapMode   = yChar * ROWMAPMODE;
    yWindOrg   = yChar * ROWWINDORG;
    yWindExt   = yChar * ROWWINDEXT;
    yViewOrg   = yChar * ROWVIEWORG;
    yViewExt   = yChar * ROWVIEWEXT;
}


/*-------------  DrawMyBitmap 
 * 
 *  DESCRIPTION:
 *    StrechBlt a bitmap
 * 
 *  ARGUMENTS:
 *     hDC    - destination DC
 *     hbm    - device dependent bitmap to display
 *     lprect - bounding rectangle into which we StrechBlt the bitmap
 * 
 *  RETURN VALUE:
 *     void
 * 
 *  GLOBALS READ:
 *     none
 * 
 *  GLOBALS WRITTEN:
 *     none
 * 
 *  NOTES:
 */ 


void NEAR PASCAL DrawMyBitmap( HDC hDC, HBITMAP hbm, LPRECT lprect )
{
    HDC     hMemDC;
    HBITMAP hbmOld;
    BITMAP  bm;
    POINT   pt;

    hMemDC = CreateCompatibleDC( hDC );
    hbmOld = SelectObject( hMemDC, hbm );
    GetObject( hbm, sizeof(BITMAP), (LPSTR)&bm );
    pt.x   = bm.bmWidth;
    pt.y   = bm.bmHeight;

    StretchBlt  ( hDC, lprect->left, lprect->top,
                  lprect->right-lprect->left, lprect->bottom-lprect->top,
                  hMemDC, 0,0,pt.x,pt.y,SRCCOPY );
    SelectObject( hMemDC, hbmOld );
    DeleteDC    ( hMemDC );
}




/*----------------  DisplayValues 
 * 
 *
 *  DESCRIPTION:
 *    display mapping mode data (see sample layout below for data displayed)
 * 
 *  ARGUMENTS:
 *    hWnd - hWnd that we are interested in 
 *    hDC  - hDC for hWnd. we need this to get the current mapping mode
 *           info and also to draw into
 * 
 *  RETURN VALUE:
 *    none
 * 
 *  GLOBALS READ:
 *    none
 * 
 *  GLOBALS WRITTEN:
 *    xDevice, yHeader, etc etc..
 * 
 *  NOTES:
 * 
 *    we declared a bunch of magic numbers globally, and initialized them
 *    in InitDisplayCoordinates, so that when we get here we can print
 *    out our values in a way thats device independent. we also switch
 *    to MM_TEXT so that we don't have to remap to the current mapping mode.
 *    of course we switch back to the saved mapping mode when we are done.
 * 
 *    the magic numbers should be clear enough, given this sample display...
 * 
 *     
 *                            Device Units        Logical Units
 * 
 *    Mouse Location:         ( 115, 1 )          ( 115, 1 )
 *    Bitmap Coordinates:     ( 0, 0, 100, 100 )
 *    Client Area Dimensions: ( 485, 276 )        ( 485, 276 )
 * 
 * 
 *    Mapping Mode:       MM_TEXT
 *    WindowOrg:          (  0,  0)
 *    WindowExt:          (  1,  1)
 *    ViewportOrg:        (  0,  0)
 *    ViewportExt:        (  1,  1)
 * 
 * 
 *    Note that we display all of this information in this routine EXCEPT
 *    the mouse location, which is drawn from the WM_MOUSEMOVE case of
 *    MainWndProc
 */ 

void NEAR PASCAL DisplayValues( HWND hWnd, HDC hDC )
{
    /*
     * the RECTS are for getting our client area coordinates
     * mmd is for the current mapping mode data
     * szMMStrings are just strings for the display (see sample below)
     */

    RECT    rectDevice, rectLogical;   
    char    buffer[80];
    MMDATA  mmd;                       

    static char * szMMStrings[] = { "MM_TEXT",
                                    "MM_LOMETRIC",
                                    "MM_HIMETRIC",
                                    "MM_LOENGLISH",
                                    "MM_HIENGLISH",
                                    "MM_TWIPS",
                                    "MM_ISOTROPIC",
                                    "MM_ANISOTROPIC" };

    GetClientRect( hWnd, &rectDevice );
    GetClientRect( hWnd, &rectLogical );
    DPtoLP       ( hDC, (LPPOINT)&rectLogical, 2 );
    
    GetMMData( hDC, (NPMMDATA)&mmd );

    // put DC in MM_TEXT mode to make text display easier
    // switch back when we are done..

    SaveDC        ( hDC );
    SetMapMode    ( hDC, MM_TEXT );
    SetWindowOrg  ( hDC, 0, 0 );
    SetViewportOrg( hDC, 0, 0 );

    // here comes the grunt work..

    wsprintf( buffer, "Device Units" );
    TextOut ( hDC, xDevice, yHeader, buffer, lstrlen( buffer ) );
    
    wsprintf( buffer, "Logical Units" );
    TextOut ( hDC, xLogical, yHeader, buffer, lstrlen( buffer ) );

    wsprintf( buffer, "Mouse Location:" );
    TextOut ( hDC, xLabel, yMouseLoc, buffer, lstrlen( buffer ) );

    wsprintf( buffer, "Bitmap Coordinates:" );
    TextOut ( hDC, xLabel, yRectCoord, buffer, lstrlen( buffer ) );

    wsprintf( buffer, "(%6d,%6d, %6d, %6d)",
        rectBM.left, rectBM.top, rectBM.right, rectBM.bottom );
    TextOut ( hDC, xDevice, yRectCoord, buffer, lstrlen( buffer ) );

    wsprintf( buffer, "Client Area Dimensions:" );
    TextOut ( hDC, xLabel, yClientDim, buffer, lstrlen( buffer ) );
    
    wsprintf( buffer, "(%6d,%6d)", rectDevice.right, rectDevice.bottom );
    TextOut ( hDC, xDevice, yClientDim, buffer, lstrlen( buffer ) );

    wsprintf( buffer, "(%6d,%6d)", rectLogical.right, rectLogical.bottom );
    TextOut ( hDC, xLogical, yClientDim, buffer, lstrlen( buffer ) );
    
    wsprintf( buffer, "Mapping Mode:" );
    TextOut ( hDC, xLabel, yMapMode, buffer, lstrlen(buffer) );

    wsprintf( buffer, szMMStrings[mmd.mapMode - MM_TEXT] );
    TextOut ( hDC, xMMInfo, yMapMode, buffer, lstrlen(buffer) );

    wsprintf( buffer, "WindowOrg:" );
    TextOut ( hDC, xLabel, yWindOrg, buffer, lstrlen(buffer) );

    wsprintf( buffer, "(%6d,%6d)", LOWORD(mmd.windOrg), HIWORD(mmd.windOrg) );
    TextOut ( hDC, xMMInfo, yWindOrg, buffer, lstrlen(buffer) );

    wsprintf( buffer, "WindowExt:" );
    TextOut ( hDC, xLabel, yWindExt, buffer, lstrlen(buffer) );

    wsprintf( buffer, "(%6d,%6d)", LOWORD(mmd.windExt), HIWORD(mmd.windExt) );
    TextOut ( hDC, xMMInfo, yWindExt, buffer, lstrlen(buffer) );

    wsprintf( buffer, "ViewportOrg:" );
    TextOut ( hDC, xLabel, yViewOrg, buffer, lstrlen(buffer) );

    wsprintf( buffer, "(%6d,%6d)", LOWORD(mmd.viewOrg), HIWORD(mmd.viewOrg) );
    TextOut ( hDC, xMMInfo, yViewOrg, buffer, lstrlen(buffer) );

    wsprintf( buffer, "ViewportExt:" );
    TextOut ( hDC, xLabel, yViewExt, buffer, lstrlen(buffer) );

    wsprintf( buffer, "(%6d,%6d)", LOWORD(mmd.viewExt), HIWORD(mmd.viewExt) );
    TextOut ( hDC, xMMInfo, yViewExt, buffer, lstrlen(buffer) );

    RestoreDC( hDC, -1 );
    ReleaseDC( hWnd, hDC );
}


/*----------  GetMMData 
 * 
 *  DESCRIPTION:
 *    load up a MMDATA data struct (see mapmode.h) with the mapping mode
 *    values for a given DC
 * 
 *  ARGUMENTS:
 *    hDC  - the DC for which we want all the values
 *    pmmd - *MMDATA struct for us to load up
 * 
 *  RETURN VALUE:
 *    void
 * 
 *  GLOBALS READ:
 *    none
 * 
 *  GLOBALS WRITTEN:
 *    none
 * 
 *  NOTES:
 */ 

void NEAR PASCAL GetMMData( HDC hDC, NPMMDATA pmmd )
{
    pmmd->mapMode = GetMapMode    ( hDC );
    pmmd->windOrg = GetWindowOrg  ( hDC );
    pmmd->windExt = GetWindowExt  ( hDC );
    pmmd->viewOrg = GetViewportOrg( hDC );
    pmmd->viewExt = GetViewportExt( hDC );
}


/*------------- ApplyMMData
 * 
 *  DESCRIPTION:
 *    change the mapping mode, origins and extents of a given DC
 * 
 *  ARGUMENTS:
 *    hDC  - DC to change
 *    pmmd - *MMDATA structure that contains the new mapping mode,
 *           origin and extent values
 * 
 *  RETURN VALUE:
 *    none
 * 
 *  GLOBALS READ:
 *    none
 * 
 *  GLOBALS WRITTEN:
 *    none
 * 
 *  NOTES:
 *    note - SetWindowExt and SetViewportExt have no effect unless
 *    the mapping mode is either MM_ISOTROPIC or MM_ANISOTROPIC.
 *    so for the other mapping modes we won't bother to call them...
 */ 

void NEAR PASCAL ApplyMMData( HDC hDC, NPMMDATA pmmd )
{
    SetMapMode    ( hDC, pmmd->mapMode );

    SetWindowOrg  ( hDC, LOWORD(pmmd->windOrg), HIWORD(pmmd->windOrg) );
    SetViewportOrg( hDC, LOWORD(pmmd->viewOrg), HIWORD(pmmd->viewOrg) );
    
    if ((MM_ISOTROPIC==pmmd->mapMode)||(MM_ANISOTROPIC==pmmd->mapMode))
        {
        SetWindowExt  ( hDC, LOWORD(pmmd->windExt), HIWORD(pmmd->windExt) );
        SetViewportExt( hDC, LOWORD(pmmd->viewExt), HIWORD(pmmd->viewExt) );
        }
}




/*---------------------------  MMDlgProc() 
 * 
 * 
 *  DESCRIPTION:
 *    Dialog procedure for the "Mapping Mode Settings" modeless dialog box.
 * 
 *  ARGUMENTS:
 *    stock dialog proc args
 * 
 *  RETURN VALUE:
 *    usually TRUE if we handled the message, FALSE if we do not
 *    return FALSE from WM_INITDIALOG because we set the initial focus 
 * 
 *  GLOBALS READ:
 *     hWndMain
 * 
 *  GLOBALS WRITTEN:
 *    hDlgCurrent, 
 *
 *  HELPER FUNCTIONS CALLED:
 *    GetDlgControlValues, SetDlgControlValues, ApplyMMData
 *
 *  NOTES:
 *    The user can use this dialog to dynamically alter the mapping mode
 *    for hWndMain.
 * 
 *    This dialog contains radio buttons for the 7 mapping modes,
 *    and edit controls to alter the window origin, window extent,
 *    viewport origin and viewport extent.
 * 
 *    It has 4 command buttons:
 * 
 *         APPLY:   if the current control settings are legitimate mapping mode
 *                  values, apply them to hWndMain's DC
 *         RESTORE: reset hWndMain's DC mapping mode values to what they were
 *                  when this dialog first came up
 *         OK:      the same as APPLY, plus end the dialog
 *         CANCEL:  the same as RESTORE, plus end the dialog
 *  
 */ 




BOOL FAR PASCAL MMDlgProc(hDlg, message, wParam, lParam)
HWND        hDlg;                               
unsigned    message;                       
WORD        wParam;                             
LONG        lParam;
{

   /*
    *  hDCMain    - the DC for hWndMain - we need to update that DC
    *  mmdStart   - we keep the mapping mode info that is in use at the
    *               time this dialog begins, so that we can reset to
    *               those values if the user gives us IDM_RESET or IDCANCEL
    *  mmdCurrent - the current map mode values, which we use when the user
    *               gives us IDM_APPLY or IDOK
    *  bValuesOK  - we get this as a return from GetDlgControlValues, which
    *               allows us to spot bogus values from the edit controls
    */

          HDC    hDCMain;
   static MMDATA mmdStart, mmdCurrent;
          BOOL   bValuesOK;

   switch (message)
	   {
   case WM_ACTIVATE:
     // this case allow us to operate multiple modeless dialogs with
     // only one call to IsDialogMessage in the main GetMessage loop..

     if (0==wParam)
        hDlgCurrent = NULL;
     else
        hDlgCurrent = hDlg;

     return FALSE;
    

   case WM_INITDIALOG:
        // get the map mode info that we start with,
        // that way we can "Revert" or "Cancel".
        // call SetDlgControlValues to use these values to 
        // initiate our controls.
        // set the focus  to the OK button and return FALSE to indicate
        // that we explicitly set the initial focus

        hDCMain = GetDC( hWndMain );
        GetMMData( hDCMain, &mmdStart );
        ReleaseDC( hWndMain, hDCMain );
        
        SetDlgControlValues( hDlg, &mmdStart );
        SetFocus( GetDlgItem( hDlg, IDOK ) );
        return (FALSE);                      

   case WM_CLOSE:
        // when we close out, re-enable the "Test/Mapping Mode.." menu
        // item so that the user can bring us back up..

        DestroyWindow ( hDlg );
        EnableMenuItem( GetMenu( hWndMain ), IDM_TESTMM, MF_BYCOMMAND|MF_ENABLED );
        DrawMenuBar   ( hWndMain );
        return TRUE;


   case WM_COMMAND:
        // here is where all the work is - handle the various button clicks
        //
        // first, see if a radio button was clicked.
        // for the MM_ISOTROPIC and MM_ANISOPTROPIC mapping modes,
        // we enable the edit controls that allow the user to change
        // the window extent and the viewport extent
        // for the other radio buttons/mapping modes we disable those edit
        // edit controls because these extents cannot be set programmatically
        // in those mapping modes


        if (HIWORD(lParam) == BN_CLICKED)
            {
            switch (wParam)
                {
            case IDB_MM_TEXT:
            case IDB_MM_LOENGLISH:
            case IDB_MM_HIENGLISH:
            case IDB_MM_LOMETRIC:
            case IDB_MM_HIMETRIC:
            case IDB_MM_TWIPS:
                EnableWindow( GetDlgItem( hDlg, IDS_WINDOWEXT ), FALSE );
                EnableWindow( GetDlgItem( hDlg, IDS_VIEWPORTEXT ), FALSE );
                EnableWindow( GetDlgItem( hDlg, IDE_WINDEXTX ), FALSE );
                EnableWindow( GetDlgItem( hDlg, IDE_WINDEXTY ), FALSE );
                EnableWindow( GetDlgItem( hDlg, IDE_VIEWEXTX ), FALSE );
                EnableWindow( GetDlgItem( hDlg, IDE_VIEWEXTY ), FALSE );

                break;

            case IDB_MM_ISOTROPIC:
            case IDB_MM_ANISOTROPIC:
                EnableWindow( GetDlgItem( hDlg, IDS_WINDOWEXT ), TRUE );
                EnableWindow( GetDlgItem( hDlg, IDS_VIEWPORTEXT ), TRUE );
                EnableWindow( GetDlgItem( hDlg, IDE_WINDEXTX ), TRUE );
                EnableWindow( GetDlgItem( hDlg, IDE_WINDEXTY ), TRUE );
                EnableWindow( GetDlgItem( hDlg, IDE_VIEWEXTX ), TRUE );
                EnableWindow( GetDlgItem( hDlg, IDE_VIEWEXTY ), TRUE );

                break;

            default:
                break;
                }      // end switch
            }          // end if

        // if not a radio button, was it Apply, Restore, OK, or Cancel?
		switch(wParam)
		    {
        case IDB_APPLY:
            // get current control values. if they are OK update
            // hWndMain's DC and force a complete repaint

            bValuesOK = GetDlgControlValues( hDlg, &mmdCurrent );
            if (bValuesOK)
                {
                hDCMain = GetDC( hWndMain );
                ApplyMMData( hDCMain, &mmdCurrent );
                ReleaseDC  ( hWndMain, hDCMain );
        
                InvalidateRect( hWndMain, NULL, TRUE );
                UpdateWindow  ( hWndMain );
                }
            else
                MessageBox( hDlg,
                            "Origin and Extent Values must be between -32767 and 32767",
                            "Cannot Apply Mapping Mode",
                            MB_OK );

            return TRUE;

        case IDB_RESTORE:
            // reset hWndMain's DC mapping mode values to what they were
            // when this dialog came up
            // also, reset our controls..

            SetDlgControlValues( hDlg, &mmdStart );
            hDCMain = GetDC( hWndMain );
            ApplyMMData( hDCMain, &mmdStart );
            ReleaseDC  ( hWndMain, hDCMain );
            InvalidateRect( hWndMain, NULL, TRUE );
            UpdateWindow  ( hWndMain );

            return TRUE;

	    case IDOK:
            // same as IDB_APPLY, except we also end this dialog

            bValuesOK = GetDlgControlValues( hDlg, &mmdCurrent );
            
            if (bValuesOK)
                {
                hDCMain = GetDC( hWndMain );
                ApplyMMData( hDCMain, &mmdCurrent );
                ReleaseDC  ( hWndMain, hDCMain );

                InvalidateRect( hWndMain, NULL, TRUE);
                UpdateWindow  ( hWndMain );
                }
            else
                MessageBox( hDlg,
                            "Origin and Extent Values must be between -32767 and 32767",
                            "Cannot Apply Mapping Mode",
                            MB_OK );

            PostMessage( hDlg, WM_CLOSE, 0, 0L );
			
            return TRUE;

        case IDCANCEL:
            // same as IDB_RESTORE, except we do not bother to reset
            // our controls and we do bother to quit this dialog..

            hDCMain = GetDC( hWndMain );
            ApplyMMData( hDCMain, &mmdStart );
            ReleaseDC  ( hWndMain, hDCMain );
            
            InvalidateRect( hWndMain, NULL, TRUE);
            UpdateWindow  ( hWndMain );

            PostMessage( hDlg, WM_CLOSE, 0, 0L );

			return TRUE;

	    default:
				break;
  			}            // end switch (wParam)
		   
        break;

   default:
		break;
                        
	   }                    // end switch(message)
return FALSE;
}



/*----------  GetDlgControlValues
 * 
 * 
 *  DESCRIPTION:
 *    Helper function for MMDialogProc. loads up a MMDATA structure
 *    with mapping mode values based on the current settings of the
 *    dialog's controls
 * 
 *  ARGUMENTS:
 *    hDlg  - HWND for the "Mapping Mode Settings" modeless dialog
 *    npmmd - *MMDATA that we will load up
 *
 *  RETURN VALUE:
 *    TRUE  - values were set and all values were OK
 *    FALSE - some control value was bogus, most probably an origin
 *            or extent that was too large or small
 * 
 *  GLOBALS READ:
 *    none
 * 
 *  GLOBALS WRITTEN:
 *    none
 * 
 *  NOTES:
 *    BUTTONIDTOMAPMODE == MM_TEXT - IDB_MM_TEXT. just a magic
 *    number to convert from the predefined constants for the
 *    mapping modes and our radio button IDs
 */ 

BOOL NEAR PASCAL GetDlgControlValues( HWND hDlg, NPMMDATA npmmd )
{
    BOOL bGotIntOK, bValuesOK = TRUE;
    int  nLo, nHi, i;
    
    nLo = GetDlgItemInt( hDlg, IDE_WINDORGX, &bGotIntOK, TRUE );
    if (!bGotIntOK)
        bValuesOK = FALSE;
    nHi = GetDlgItemInt( hDlg, IDE_WINDORGY, &bGotIntOK, TRUE );
    if (!bGotIntOK)
        bValuesOK = FALSE;
    npmmd->windOrg = MAKELONG( nLo, nHi );

    nLo = GetDlgItemInt( hDlg, IDE_VIEWORGX, &bGotIntOK, TRUE );
    if (!bGotIntOK)
        bValuesOK = FALSE;
    nHi = GetDlgItemInt( hDlg, IDE_VIEWORGY, &bGotIntOK, TRUE );
    if (!bGotIntOK)
        bValuesOK = FALSE;
    npmmd->viewOrg = MAKELONG( nLo, nHi );

    nLo = GetDlgItemInt( hDlg, IDE_WINDEXTX, &bGotIntOK, TRUE );
    if (!bGotIntOK)
        bValuesOK = FALSE;
    nHi = GetDlgItemInt( hDlg, IDE_WINDEXTY, &bGotIntOK, TRUE );
    if (!bGotIntOK)
        bValuesOK = FALSE;
    npmmd->windExt = MAKELONG( nLo, nHi );

    nLo = GetDlgItemInt( hDlg, IDE_VIEWEXTX, &bGotIntOK, TRUE );
    if (!bGotIntOK)
        bValuesOK = FALSE;
    nHi = GetDlgItemInt( hDlg, IDE_VIEWEXTY, &bGotIntOK, TRUE );
    if (!bGotIntOK)
        bValuesOK = FALSE;
    npmmd->viewExt = MAKELONG( nLo, nHi );

    for (i=IDB_MM_TEXT; i<=IDB_MM_ANISOTROPIC; i++)
        {
        if (IsDlgButtonChecked( hDlg, i))
            npmmd->mapMode = i + BUTTONIDTOMAPMODE;
        }

    return bValuesOK;

}



/*----------  SetDlgControlValues
 * 
 * 
 *  DESCRIPTION:
 *    Helper function for MMDialogProc. sets the dialog's controls
 *    based on the mapping mode values
 * 
 *  ARGUMENTS:
 *    hDlg  - HWND for the "Mapping Mode Settings" modeless dialog
 * 
 *  RETURN VALUE:
 *    TRUE  - values were set and all values were OK
 *    FALSE - some control value was bogus, most probably an origin
 *            or extent that was too large or small
 * 
 *  GLOBALS READ:
 *    none
 * 
 *  GLOBALS WRITTEN:
 *    none
 * 
 *  NOTES:
 *    MAPMODETOBUTTONID == IDB_MM_TEXT- MM_TEXT. just a magic
 *    number to convert between the predefined constants for the
 *    mapping modes and our radio button IDs
 */ 



BOOL NEAR PASCAL SetDlgControlValues( HWND hDlg, NPMMDATA npmmd )
{
    
    SetDlgItemInt( hDlg, IDE_WINDORGX, LOWORD(npmmd->windOrg), TRUE );
    SetDlgItemInt( hDlg, IDE_WINDORGY, HIWORD(npmmd->windOrg), TRUE );

    SetDlgItemInt( hDlg, IDE_VIEWORGX, LOWORD(npmmd->viewOrg), TRUE );
    SetDlgItemInt( hDlg, IDE_VIEWORGY, HIWORD(npmmd->viewOrg), TRUE );

    SetDlgItemInt( hDlg, IDE_WINDEXTX, LOWORD(npmmd->windExt), TRUE );
    SetDlgItemInt( hDlg, IDE_WINDEXTY, HIWORD(npmmd->windExt), TRUE );

    SetDlgItemInt( hDlg, IDE_VIEWEXTX, LOWORD(npmmd->viewExt), TRUE );
    SetDlgItemInt( hDlg, IDE_VIEWEXTY, HIWORD(npmmd->viewExt), TRUE );

    CheckRadioButton( hDlg, IDB_MM_TEXT,
                        IDB_MM_ANISOTROPIC, npmmd->mapMode+MAPMODETOBUTTONID );

    switch (npmmd->mapMode)
        {
    case MM_TEXT:
    case MM_LOENGLISH:
    case MM_HIENGLISH:
    case MM_LOMETRIC:
    case MM_HIMETRIC:
    case MM_TWIPS:
        EnableWindow( GetDlgItem( hDlg, IDS_WINDOWEXT ), FALSE );
        EnableWindow( GetDlgItem( hDlg, IDS_VIEWPORTEXT ), FALSE );
        EnableWindow( GetDlgItem( hDlg, IDE_WINDEXTX ), FALSE );
        EnableWindow( GetDlgItem( hDlg, IDE_WINDEXTY ), FALSE );
        EnableWindow( GetDlgItem( hDlg, IDE_VIEWEXTX ), FALSE );
        EnableWindow( GetDlgItem( hDlg, IDE_VIEWEXTY ), FALSE );
        break;
        }

    return TRUE;
}


/*---------------------  RectDlgProc 
 * 
 *  DESCRIPTION:
 *    Dialog procedure for the "Bitmap Coordinates" dialog
 * 
 *  ARGUMENTS:
 *    stock dialog proc args
 * 
 *  RETURN VALUE:
 *    stock - TRUE if we handle the message, FALSE to continue
 *            stock dialog handling
 *            FALSE from WM_INITDIALOG because we set initial focus
 * 
 *  GLOBALS READ:
 *    hWndMain
 * 
 *  GLOBALS WRITTEN:
 *    hDlgCurrent, rectBM
 * 
 *  HELPER FUNCTIONS:
 *    GetEditValues, SetEditValues
 * 
 * 
 *  NOTES:
 *    This dialog allows the user to dynamically alter rectBM, the bounding
 *    rectangle into which the dog bitmap is StretchBlt'ed.
 * 
 *    The dialog contains 4 edit controls corresponding to the rect coordinates
 * 
 *    When the dialog starts we get and save the initial value of rectBM
 *    so that we can RESTORE and CANCEL
 * 
 *    Commands:
 *      APPLY   : apply the new rectBM values and force hWndMain to repaint
 *      RESTORE : restore original rectBM values and force a repaint
 *      OK      : same as APPLY plus end the dialog
 *      CANCEL  : same as RESTORE plus cancel
 */ 

BOOL FAR PASCAL RectDlgProc(hDlg, message, wParam, lParam)
HWND        hDlg;                               
unsigned    message;                       
WORD        wParam;                             
LONG        lParam;
{
    static RECT rectSave;
    RECT rectTemp;
    BOOL bValuesOK;

    switch (message)
        {
    case WM_ACTIVATE:
        // this case lets us implement multiple modeless dialogs

        if (0==wParam)
            hDlgCurrent = NULL;
        else
            hDlgCurrent = hDlg;

        return FALSE;

    case WM_INITDIALOG:
        // save initial setting so that we can RESTORE or CANCEL
        // set the edit control values
        // return FALSE becuase we explicitly set the focus

        rectSave = rectBM;
        SetEditValues( hDlg, &rectSave );
        SetFocus( GetDlgItem( hDlg, IDOK ) );
        
        return FALSE;

    case WM_CLOSE:
        // closed dialog and re-enable the "Test/Bitmap Coordinates.." menu item

        DestroyWindow ( hDlg );
        EnableMenuItem( GetMenu( hWndMain ), IDM_TESTRECT, MF_BYCOMMAND|MF_ENABLED );
        DrawMenuBar   ( hWndMain );
        return TRUE;

    case WM_COMMAND:
        switch (wParam)
            {
        case IDB_RECTAPPLY:
            // get edit control values
            // if they are OK, update rectBM and force a repaint
            // if not, pop up a warning

            bValuesOK = GetEditValues( hDlg, &rectTemp );
            if (bValuesOK)
                {
                rectBM = rectTemp;
                InvalidateRect( hWndMain, NULL, TRUE );
                UpdateWindow  ( hWndMain );
                }
            else
                MessageBox( hDlg, "Illegal Values",
                            "Cannot Draw This Rect", MB_OK );
            return TRUE;

        case IDB_RECTRESTORE:
            // reset rectBM to what it was when the dialog came up
            // and reset our control accordingly
            // then force a repaint of hWndMain

            SetEditValues( hDlg, &rectSave );
            rectBM = rectSave;
            InvalidateRect( hWndMain, NULL, TRUE );
            UpdateWindow  ( hWndMain );
            return TRUE;

        case IDOK:
            // same as IDB_RECTAPPLY plus end dialog

            bValuesOK = GetEditValues( hDlg, &rectTemp );
            if (bValuesOK)
                {
                rectBM = rectTemp;
                InvalidateRect( hWndMain, NULL, TRUE );
                UpdateWindow  ( hWndMain );
                }
            else
                MessageBox( hDlg, "Illegal Values",
                            "Cannot Draw This Rect", MB_OK );
            PostMessage( hDlg, WM_CLOSE, 0, 0L );
            return TRUE;

        case IDCANCEL:
            // same as IDB_RECTRESTORE plus end dialog

            rectBM = rectSave;
            InvalidateRect( hWndMain, NULL, TRUE );
            UpdateWindow  ( hWndMain );
            PostMessage( hDlg, WM_CLOSE, 0, 0L );
            return TRUE;
            }

    default:
        break;
        }
    return FALSE;
}


/*---------------------  SetEditValues  ------------------------------------*/

// helper function for RectDlgProc
// sets the values of the 4 edit controls for the rect coordinates

void NEAR PASCAL SetEditValues( HWND hDlg, LPRECT lprect )
{
    SetDlgItemInt( hDlg, IDE_RECTLEFT,   lprect->left,   TRUE );
    SetDlgItemInt( hDlg, IDE_RECTTOP,    lprect->top,    TRUE );
    SetDlgItemInt( hDlg, IDE_RECTRIGHT,  lprect->right,  TRUE );
    SetDlgItemInt( hDlg, IDE_RECTBOTTOM, lprect->bottom, TRUE );
}


/*---------------------  GetEditValues  ------------------------------------*/

// helper function for RectDlgProc
// gets the values from the four edit controls and loads them into rect

// RETURN VALUE:
//   TRUE if all values OK
//   FALSE if there is a bogus value

BOOL NEAR PASCAL GetEditValues ( HWND hDlg, LPRECT prect )
{
    BOOL bOK, bValuesOK = TRUE;

    prect->left   = GetDlgItemInt( hDlg, IDE_RECTLEFT, &bOK, TRUE );
    if (!bOK)
        bValuesOK = FALSE;
    prect->top    = GetDlgItemInt( hDlg, IDE_RECTTOP, &bOK, TRUE );
    if (!bOK)
        bValuesOK = FALSE;
    prect->right  = GetDlgItemInt( hDlg, IDE_RECTRIGHT, &bOK, TRUE );
    if (!bOK)
        bValuesOK = FALSE;
    prect->bottom = GetDlgItemInt( hDlg, IDE_RECTBOTTOM, &bOK, TRUE );
    if (!bOK)
        bValuesOK = FALSE;

    return bValuesOK;
}


/*---------------------------  About()  ------ -----------------------------*/

// stock GENERIC to handle the About dialog box

BOOL FAR PASCAL About(hDlg, message, wParam, lParam)
HWND        hDlg;                               
unsigned    message;                       
WORD        wParam;                             
LONG        lParam;
{
   switch (message)
	   {
      case WM_INITDIALOG:               
         return (TRUE);

      case WM_COMMAND:    
		   switch(wParam)
			   {
			   case IDOK:
			   case IDCANCEL:
				   EndDialog( hDlg, TRUE );
				   return TRUE;
			   default:
				   break;
  			   }
		   break;

	   default:
		   break;
                        
	   }
return FALSE;
}


