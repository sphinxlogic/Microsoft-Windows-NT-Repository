//*****************************************************************************
//* File Name : bmp.c                                                         *
//* Purpose : Ruotines that read resources from files and return bitmap       *
//*           handles reside here.                                            *
//* Functions : ReadBmpFile() - Calls ReadDIB and DIBToBitmap to read a  DIB  *
//*                             and create a Device Dependent Bitmap.         *
//*             ReadDIB() - Reads a DIB source file (Windows 3.0 or OS/2 style*
//*                         DIBs) and converts the DIB file, if necessary, to *
//*                         a Windows 3.0 style DIB. Returns a handle to the  *
//*                         Win 3.0 style DIB.                                *
//*             CursorToBitmap() - Reads a cursor resource file and converts  *
//*                                it to a device dependent bitmap.           *
//*             IconToBitmap() - Reads an icon resource file and converts it  *
//*                              to a device dependent bitmap.                *
//*             ReadDibBitmapInfo() -  Used by ReadDIB.                       *
//*             DIBToBitmap() - Converts a device independent bitmap to a     *
//*                             device dependent bitmap.                      *
//*             PaletteSize() - Calculates the size of the palette in bytes.  *
//*             DIBNumColors() - Determines the number of colors used in a DIB*
//*             mylread() - Reads in a file in large chunks. Used to read a   *
//*                         file larger than 64K bytes.                       *
//*                                                                           *
//* Development Team : Krishna Nareddy                                        *
//*                    Mark Bader                                             *
//*                                                                           *
//* Comments : The goal of the routines in this file is to be simple to read  *
//*            and understand, rather than to be computationally efficient.   *
//*                                                                           *
//* Written by Microsoft Product Support Services, Windows Developer Support. *
//*****************************************************************************

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <io.h>
#include "windows.h"
#include "bmp.h"
#include "icon.h"
#include "cur.h"

//*****************************************************************************
//* Function : ReadBmpFile()                                                  *
//* Purpose  : Reads a DIB resource file and creates a device dependent bitmap*
//*            based on that information.                                     *
//* Parameters : LPSTR szFileName - The DIB resource file.                    *
//* Returns :  A handle to a bitmap. The handle will be NULL if a bitmap can't*
//*            be created for any reason.                                     *
//* Comments : Reads both win 3.0 style and OS/2 style DIBS. Converts OS/2    *
//*            style DIBs to Win 3.0 DIBs and then converts the DIB to DDB.   *
//* History :  Date          Author            Reason                         *
//*            2/25/92       Krishna           Created                        *
//*****************************************************************************

HBITMAP ReadBmpFile (LPSTR szFileName)
{
   HANDLE hDIB;
   HBITMAP hBitmap;

   hDIB = ReadDIB(szFileName);    // Read the DIB from file and return a handle
   if (hDIB == NULL)
      return (NULL);

   hBitmap = DIBToBitmap(hDIB);   // Create a DD bitmap out of the DIB info

   GlobalFree(hDIB);
   return (hBitmap);
}

//*****************************************************************************
//* Function : CursorToBitmap()                                               *
//* Purpose  : Reads a cursor resource file and creates a bitmap based on that*
//*            information.                                                   *
//* Parameters : LPSTR szFileName - The cursor resource file.                 *
//* Returns :  A handle to a bitmap. The handle will be NULL if a bitmap can't*
//*            be created for any reason.                                     *
//* Comments : A cursor's DIB has both the XOR and AND bitmaps. Take only the *
//*            XOR bitmap. This bitmap will be monochrome.                    *
//* History :  Date          Author            Reason                         *
//*            2/25/92       Krishna           Created                        *
//*****************************************************************************

HBITMAP CursorToBitmap (LPSTR szFileName)
{
   HANDLE hDIB;    // Handle to DIB memory
   HBITMAP hBitmap;
   LPBITMAPINFO lpDIB;

   hDIB = ReadCur(szFileName, NULL);    // Read cursor DIB from file
   if (hDIB == NULL)
      return NULL;

   lpDIB = (LPBITMAPINFO)GlobalLock(hDIB);  // obtain a pointer to the DIB

   // We need only the XOR part of the Cursor DIB. So use just the top half of
   // the DIB
   lpDIB->bmiHeader.biHeight /= 2;

   GlobalUnlock(hDIB);
   hBitmap = DIBToBitmap(hDIB);         // Convert the DIB to DD bitmap.

   GlobalUnlock(hDIB);
   GlobalFree(hDIB);
   return (hBitmap);
}

//*****************************************************************************
//* Function : IconToBitmap()                                                 *
//* Purpose  : Reads an icon resource file and creates a bitmap based on that *
//*            information.                                                   *
//* Parameters : LPSTR szFileName - The icon resource file.                   *
//* Returns :  A handle to a bitmap. The handle will be NULL if a bitmap can't*
//*            be created for any reason.                                     *
//* Comments : An icon's DIB has both the XOR and AND bitmaps. Take only the  *
//*            XOR bitmap.                                                    *
//* History :  Date          Author            Reason                         *
//*            2/25/92       Krishna           Created                        *
//*****************************************************************************

HBITMAP IconToBitmap (LPSTR szFileName)
{
   HANDLE hDIB;    // Handle to DIB memory
   HBITMAP hBitmap;
   LPBITMAPINFO lpDIB;

   hDIB = ReadIcon(szFileName);     // Read the icon DIB from the file
   if (hDIB == NULL)
      return NULL;

   lpDIB = (LPBITMAPINFO)GlobalLock(hDIB);

   // We need only the XOR part of the Icon DIB. So use just the top half of
   // the DIB
   lpDIB->bmiHeader.biHeight /= 2;

   GlobalUnlock(hDIB);
   hBitmap = DIBToBitmap(hDIB);      // Convert the DIB to DD bitmap

   GlobalUnlock(hDIB);
   GlobalFree(hDIB);
   return (hBitmap);
}

//*****************************************************************************
//* Function : ReadDIB()                                                      *
//* Purpose  : Reads a DIB file and creates a MEMORY DIB, a memory handle     *
//*            containing BITMAPINFO, palette data and the bits.              *
//* Parameters : LPSTR szFileName - The cursor resource file.                 *
//* Returns :  A handle to a bitmap. The handle will be NULL if a bitmap can't*
//*            be created for any reason.                                     *
//* Comments : Reads both win 3.0 style and OS/2 style DIBS. Converts OS/2    *
//*            style DIBs to Win 3.0 DIB.                                     *
//* History :  Date          Author            Reason                         *
//*            ???           ???               Created (ShowDIB SDK sample)   *
//*            2/25/92       Krishna           Added header.                  *
//*****************************************************************************

HANDLE ReadDIB (LPSTR szFile)
{
   unsigned fh;
   BITMAPINFOHEADER bi;
   LPBITMAPINFOHEADER lpbi;
   DWORD dwLen = 0;
   DWORD dwBits;
   HANDLE hdib;
   HANDLE h;
   OFSTRUCT of;

   // Open the file and read the DIB information 

   fh = OpenFile(szFile, &of, OF_READ);
   if (fh == -1)
      return NULL;

   hdib = ReadDibBitmapInfo(fh);
   if (!hdib)
      return NULL;

   DibInfo(hdib, &bi);

   // Calculate the memory needed to hold the DIB
   dwBits = bi.biSizeImage;
   dwLen = bi.biSize + (DWORD)PaletteSize((LPSTR)&bi) + dwBits;

   // Try to increase the size of the bitmap info. buffer to hold the DIB
   h = GlobalReAlloc(hdib, dwLen, GHND);
   if (!h)
   {
      GlobalFree(hdib);
      hdib = NULL;
   }
   else
      hdib = h;

   // Read in the bits
   if (hdib)
   {
      lpbi = (VOID FAR *)GlobalLock(hdib);
      mylread(fh, (LPSTR)lpbi + (WORD)lpbi->biSize + PaletteSize((LPSTR)lpbi), dwBits);
      GlobalUnlock(hdib);
   }
   _lclose(fh);

   return hdib;
}

//*****************************************************************************
//* Function : ReadDibBitmapInfo()                                            *
//* Purpose  : Reads a file in DIB format and returns a global HANDLE to its  *
//*            BITMAPINFO.  This function will work with both "old"           *
//*            (BITMAPCOREHEADER, OS/2 style) and "new" (BITMAPINFOHEADER,    *
//*            Win 3.0 style) bitmap formats, but will always return a "new"  *
//*            BITMAPINFO (Win 3.0 style).                                    *
//* Parameters : int fh - File handle to the DIB file.                        *
//* Returns :  A handle to BITMAPINFO in the DIB file. The handle will be NULL*
//*            if the BITMAPINFO cannot be created and filled for any reason. *
//* Comments :                                                                *
//* History :  Date          Author            Reason                         *
//*            ???           ???               Created (ShowDIB SDK sample)   *
//*            2/25/92       Krishna           Added header.                  *
//***************************************************************************** 

HANDLE ReadDibBitmapInfo (int fh)
{
   DWORD off;
   HANDLE hbi = NULL;
   int size;
   int i;
   WORD nNumColors;

   RGBQUAD FAR *pRgb;
   BITMAPINFOHEADER bi;
   BITMAPCOREHEADER bc;
   LPBITMAPINFOHEADER lpbi;
   BITMAPFILEHEADER bf;
   DWORD dwWidth = 0;
   DWORD dwHeight = 0;
   WORD wPlanes, wBitCount;

   // Reset file pointer and read file header

   off = _llseek(fh, 0L, SEEK_CUR);
   if (sizeof(bf) != _lread(fh, (LPSTR)&bf, sizeof(bf)))
   {
      Error(ERR_BADBMPHEADER);
      return NULL;
   }

   // Do we have a RC HEADER?
   if (!ISDIB (bf.bfType))
   {
      bf.bfOffBits = 0L;
      _llseek(fh, off, SEEK_SET);
   }
   if (sizeof(bi) != _lread(fh, (LPSTR)&bi, sizeof(bi)))
   {
      Error(ERR_BADBMPHEADER);
      return NULL;
   }

   nNumColors = DIBNumColors((LPSTR)&bi);

   // Check the nature (BITMAPINFO or BITMAPCORE) of the info. block
   // and extract the field information accordingly. If a BITMAPCOREHEADER,
   // transfer it's field information to a BITMAPINFOHEADER-style block

   switch (size = (int)bi.biSize)
   {
      case sizeof(BITMAPINFOHEADER):
         break;

      case sizeof(BITMAPCOREHEADER):
         bc = *(BITMAPCOREHEADER *)&bi;

         dwWidth = (DWORD)bc.bcWidth;             // width in pixels
         dwHeight = (DWORD)bc.bcHeight;           // height in pixels
         wPlanes = bc.bcPlanes;                   // # of planes. Always 1 for DIB
         wBitCount = bc.bcBitCount;               // color bits per pixel.
         bi.biSize = sizeof(BITMAPINFOHEADER);    // size of this structure
         bi.biWidth = dwWidth;                    
         bi.biHeight = dwHeight;
         bi.biPlanes = wPlanes;
         bi.biBitCount = wBitCount;
         bi.biCompression = BI_RGB;               // no compression
         bi.biSizeImage = 0;                      // 0 == default size
         bi.biXPelsPerMeter = 0;                  // not used for this app
         bi.biYPelsPerMeter = 0;                  // not used for this app
         bi.biClrUsed = nNumColors;               // # of colors used.
         bi.biClrImportant = nNumColors;          // # of important colors

         _llseek(fh, (LONG)sizeof(BITMAPCOREHEADER) - sizeof(BITMAPINFOHEADER), SEEK_CUR);
         break;

      default:
      {
         Error(ERR_BADBMPRSRC);
         return NULL;
      }
   }

   // Fill in some default values if they are zero
   if (bi.biSizeImage == 0)                       // compute size of the image
      bi.biSizeImage = WIDTHBYTES ((DWORD)bi.biWidth * bi.biBitCount) * bi.biHeight;
   if (bi.biClrUsed == 0)                         // compute the # of colors used
      bi.biClrUsed = DIBNumColors((LPSTR)&bi);

   // Allocate for the BITMAPINFO structure and the color table.
   hbi = GlobalAlloc(GHND, (LONG)bi.biSize + nNumColors * sizeof(RGBQUAD));
   if (hbi == NULL)
   {
      Error(ERR_NOMEMALLOC);
      return NULL;
   }
   lpbi = (VOID FAR *)GlobalLock(hbi);
   *lpbi = bi;

   // Get a pointer to the color table
   pRgb = (RGBQUAD FAR *)((LPSTR)lpbi + bi.biSize);
   if (nNumColors)
   {
      if (size == sizeof(BITMAPCOREHEADER))
      {
      // Convert a old color table (3 byte RGBTRIPLEs) to a new
      // color table (4 byte RGBQUADs)
         _lread(fh, (LPSTR)pRgb, nNumColors * sizeof(RGBTRIPLE));

         for (i = nNumColors - 1; i >= 0; i--)
         {
            RGBQUAD rgb;

            rgb.rgbRed = ((RGBTRIPLE FAR *)pRgb)[i].rgbtRed;
            rgb.rgbBlue = ((RGBTRIPLE FAR *)pRgb)[i].rgbtBlue;
            rgb.rgbGreen = ((RGBTRIPLE FAR *)pRgb)[i].rgbtGreen;
            rgb.rgbReserved = (BYTE)0;

            pRgb[i] = rgb;
         }
      }
      else
         _lread(fh, (LPSTR)pRgb, nNumColors * sizeof(RGBQUAD));
   }

   if (bf.bfOffBits != 0L)
      _llseek(fh, off + bf.bfOffBits, SEEK_SET);

   GlobalUnlock(hbi);
   return hbi;
}

//*****************************************************************************
//* Function : DibToBitmap()                                                  *
//* Purpose  : Creates a bitmap from a DIB.                                   *
//* Parameters : HANDLE hDIB - specifies the DIB to convert.                  *
//* Returns :  A handle to a device dependent bitmap. The handle will be NULL *
//*            if the handle cannot be created for any reason.                *
//* Comments : To keep code simple, palettes have not been used/created. If   *
//*            want to know how to preserve the colors of a 256 bitmap (by    *
//*            using a Palatte) please see the samples DIBView and WINCAP.    *
//* History:   Date      Author      Reason                                   *
//*            6/01/91   GarrettM    Created                                  *
//*            9/15/91   PatSch      Added header and comments                *
//*            2/25/92   Krishna     Made some changes                        *
//***************************************************************************** 

HBITMAP DIBToBitmap (HANDLE hDIB)
{
   LPSTR lpDIBHdr, lpDIBBits;     // pointer to DIB header, pointer to DIB bits
   HBITMAP hBitmap;
   HDC hDC;

   lpDIBHdr = GlobalLock(hDIB);

   // Get a pointer to the DIB bits
   lpDIBBits = lpDIBHdr + *(LPDWORD)lpDIBHdr + PaletteSize((LPSTR)lpDIBHdr);

   hDC = GetDC(NULL);
   if (!hDC)
   {
      GlobalUnlock(hDIB);
      return NULL;
   }

   // create bitmap from DIB info. and bits 
   hBitmap = CreateDIBitmap(hDC, (LPBITMAPINFOHEADER)lpDIBHdr, CBM_INIT,
                            lpDIBBits, (LPBITMAPINFO)lpDIBHdr, DIB_RGB_COLORS);

   ReleaseDC(NULL, hDC);
   GlobalUnlock(hDIB);

   return hBitmap;
}

//*****************************************************************************
//* Function : PaletteSize()                                                  *
//* Purpose  : Calculates the palette size in bytes. If the info. block is of *
//*            the BITMAPCOREHEADER type, the number of colors is multiplied  *
//*            by sizeof(RGBTRIPLE) to give the palette size, otherwise the   *
//*            number of colors is multiplied by sizeof(RGBQUAD).             *
//* Parameters : LPSTR pv - pointer to the BITMAPINFOHEADER                   *
//* Returns :  The size of the palette.                                       *
//* Comments :                                                                *
//* History :  Date          Author            Reason                         *
//*            ???           ???               Created (ShowDIB SDK sample)   *
//*            2/25/92       Krishna           Added header.                  *
//***************************************************************************** 

WORD PaletteSize (LPSTR pv)
{
   LPBITMAPINFOHEADER lpbi;
   WORD NumColors;

   lpbi = (LPBITMAPINFOHEADER)pv;
   NumColors = DIBNumColors((LPSTR)lpbi);

   if (lpbi->biSize == sizeof(BITMAPCOREHEADER))  // OS/2 style DIBs
      return NumColors * sizeof(RGBTRIPLE);
   else
      return NumColors * sizeof(RGBQUAD);
}

//*****************************************************************************
//* Function : DIBNumColors()                                                 *
//* Purpose  : This function calculates the number of colors in the DIB's     *
//*            color table by finding the bits per pixel for the DIB (whether *
//*            Win3.0 or OS/2-style DIB). If bits per pixel is 1: colors=2,   *
//*            if 4: colors=16, if 8: colors=256, if 24, no colors in color   *
//*            table.                                                         *
//* Parameters : LPSTR lpbi - pointer to packed-DIB memory block.             *
//* Returns :  The number of colors in the color table.                       *
//* Comments :                                                                *
//* History :  Date          Author            Reason                         *
//*            ???           ???               Created (ShowDIB SDK sample)   *
//*            2/25/92       Krishna           Added header.                  *
//*****************************************************************************

WORD DIBNumColors (LPSTR pv)
{
   int bits;
   LPBITMAPINFOHEADER lpbi;
   LPBITMAPCOREHEADER lpbc;

   lpbi = ((LPBITMAPINFOHEADER)pv);     // assume win 3.0 style DIBs
   lpbc = ((LPBITMAPCOREHEADER)pv);     // assume OS/2 style DIBs

   // With the BITMAPINFO format headers, the size of the palette
   // is in biClrUsed, whereas in the BITMAPCORE - style headers, it
   // is dependent on the bits per pixel ( = 2 raised to the power of
   // bits/pixel).

   if (lpbi->biSize != sizeof(BITMAPCOREHEADER))
   {
      if (lpbi->biClrUsed != 0)
         return (WORD)lpbi->biClrUsed;
      bits = lpbi->biBitCount;
   }
   else
      bits = lpbc->bcBitCount;

   switch (bits)
   {
      case 1:
         return 2;

      case 4:
         return 16;

      case 8:
         return 256;

      default:
         // A 24 bitcount DIB has no color table
         return 0;
   }
}

//*****************************************************************************
//* Function : DIBInfo()                                                      *
//* Purpose  : This function fills in the DIB info header's default fields.   *
//*            table.                                                         *
//* Parameters : LPSTR lpbi - pointer to packed-DIB memory block.             *
//*              HANDLE hbi - handle to packed-DIB memory block.              *
//* Returns :  The number of colors in the color table.                       *
//* Comments :                                                                *
//* History :  Date          Author            Reason                         *
//*            ???           ???               Created (ShowDIB SDK sample)   *
//*            2/25/92       Krishna           Added header.                  *
//*****************************************************************************

BOOL DibInfo (HANDLE hbi, LPBITMAPINFOHEADER lpbi)
{
   if (hbi)
   {
      *lpbi = *(LPBITMAPINFOHEADER)GlobalLock(hbi);

      // fill in the default fields
      if (lpbi->biSize != sizeof(BITMAPCOREHEADER))   // If not OS/2 style 
      {
         if (lpbi->biSizeImage == 0L)
            lpbi->biSizeImage =            // determine image size in bytes
                  WIDTHBYTES(lpbi->biWidth*lpbi->biBitCount) * lpbi->biHeight;

         if (lpbi->biClrUsed == 0L)        // determine number of colors
            lpbi->biClrUsed = DIBNumColors((LPSTR)lpbi);
      }
      GlobalUnlock(hbi);
      return TRUE;
   }
   return FALSE;
}

//*****************************************************************************
//* Function : mylread()                                                      *
//* Purpose  : Reads data in steps of MAXREAD bytes till all the data has been*
//*            read                                                           *
//* Parameters : int fh - Handle of the file to be read in.                   *
//*              void far *pv - structure to be filled with the data read.    *
//*              DWORD ul - Number of bytes to read.                          * 
//* Returns :  The number of bytes read. 0, if read did not proceed properly. *                       *
//* Comments : PRIVATE ROUTINE TO READ MORE THAN 64K.                         *
//* History :  Date          Author            Reason                         *
//*            ???           ???               Created (ShowDIB SDK sample)   *
//*            2/25/92       Krishna           Added header.                  *
//*****************************************************************************

DWORD PASCAL mylread (int fh, VOID FAR *pv, DWORD ul)
{
   DWORD ulT = ul;
   BYTE huge *hp = pv;

   while (ul > (DWORD)MAXREAD)
   {
      if (_lread(fh, (LPSTR)hp, (WORD)MAXREAD) != MAXREAD)
         return 0;
      ul -= MAXREAD;
      hp += MAXREAD;
   }
   if (_lread(fh, (LPSTR)hp, (WORD)ul) != (WORD)ul)
      return 0;    // failure. return 0

   // successfully completed reading the file. Return # of bytes read.
   return ulT;
}
