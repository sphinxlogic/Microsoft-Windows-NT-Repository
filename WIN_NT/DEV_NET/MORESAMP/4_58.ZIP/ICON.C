//*****************************************************************************
//* File Name : icon.c                                                        *
//* Purpose : Ruotines that read resources from files and return icon handles *
//*           reside here.                                                    *
//* Functions : ReadIconFile() - Calls ReadIcon and MakeIcon to create an icon*
//*             ReadIcon() - Reads an icon file and returns a handle to the   *
//*                          icon's DIB.                                      *
//*             MakeIcon() - Takes a DIB and creates an icon.                 *
//*             BitmapToIcon() - Reads a bitmap file and uses that DIB to     *
//*                              create an icon.                              *
//*             CursorToIcon() - Reads a cursor file and uses that DIB to     *
//*                              create an icon.                              *
//*                                                                           *
//* Development Team : Krishna Nareddy                                        *
//*                    Mark Bader                                             *
//*                                                                           *
//* Comments : The goal of the routines in this file is to be simple to read  *
//*            and understand, rather than to be computationally efficient.   *
//*                                                                           *
//* Written by Microsoft Product Support Services, Windows Developer Support. *
//*****************************************************************************

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <io.h>
#include "windows.h"
#include "icon.h"
#include "cur.h"
#include "bmp.h"

//*****************************************************************************
//* Function : ReadIconFile()                                                 *
//* Purpose  : Reads an icon resource file and creates an icon based on that  *
//*            information.                                                   *
//* Parameters : LPSTR szFileName - The icon resource file.                   *
//* Returns :  A handle to an icon. The handle will be NULL if an icon cannot *
//*            be created for any reason.                                     *
//* Comments : Only the first icon in a given file is read. To modify this    *
//*            procedure to read in all the icons in the .ICO file, you must  *
//*            read in the entire icon resource directory, and find the bits  *
//*            to each icon.  See "Reference - Volume 2" for a description of *
//*            the icon file.                                                 *
//* History :  Date          Author            Reason                         *
//*            2/25/92       Krishna           Created                        *
//*****************************************************************************

HICON ReadIconFile (LPSTR szFileName)
{
   HICON hIcon;
   HANDLE hDIB;

   hDIB = ReadIcon(szFileName);    // read the icon DIB from file
   if (hDIB == NULL)
      return NULL;

   hIcon = MakeIcon(hDIB);         // create an icon from DIB

   GlobalFree(hDIB);
   return hIcon;
}

//*****************************************************************************
//* Function : BitmapToIcon()                                                 *
//* Purpose  : Reads a bitmap resource file and creates an icon based on that *
//*            information.                                                   *
//* Parameters : LPSTR szFileName - The bitmap resource file.                 *
//* Returns :  A handle to an icon. The handle will be NULL if an icon cannot *
//*            be created for any reason.                                     *
//* Comments : The bitmap only provides the XOR mask for the icon. The AND    *
//*            mask has to created by the app. at its discretion.             *
//* Steps : 1) Obtain a handle to the bitmap's DIB.                           *
//*         2) Shrink / expand the bitmap to create an XOR bitmap as the same *
//*            size as that of an icon supported by the system.               *
//*         3) Save the XOR bits in memory.                                   *
//*         4) Create a monochrome bitmap for the AND mask and fill it with a *
//*            pattern of your choice.                                        *
//*         5) Save the AND bits in memory.                                   *
//*         6) Use the XOR and AND masks and create an icon using CreateIcon. *
//* History :  Date          Author            Reason                         *
//*            2/25/92       Krishna           Created                        *
//*****************************************************************************

HICON BitmapToIcon (LPSTR szFileName)
{
   HBITMAP hBitmap, hXorBitmap, hAndBitmap, hOldBmp1, hOldBmp2, hOldBmp3;
   BITMAP XorBitmap, AndBitmap;
   LPSTR lpAndBits, lpXorBits;
   HANDLE hAndBits, hXorBits;
   HDC hdcSrc, hdcDst, hdc, hdcTmp;
   int iIconWidth, iIconHeight;
   HICON hIcon;
   DWORD dwNumBytes;

   // 1) Obtain a handle to the bitmap's DIB.    

   hBitmap = ReadBmpFile(szFileName);
   if (hBitmap == NULL)
      return NULL;

   // Get the icon's dimensions
   iIconWidth = GetSystemMetrics(SM_CXICON);
   iIconHeight = GetSystemMetrics(SM_CYICON);

   // Create two DCs to shrink/expand the bitmap to fit the Icon's dimensions
   // We need one DC to hold our source bitmap, and one to hold our 
   // destination bitmap (which is the size of our icon).

   hdc = CreateDC("DISPLAY", NULL, NULL, NULL);
   hdcSrc = CreateCompatibleDC(hdc);   // create mem DC
   hOldBmp1 = SelectObject(hdcSrc, hBitmap);   // select source bitmap
   hdcDst = CreateCompatibleDC(hdc);   // create another mem DC
   hXorBitmap = CreateCompatibleBitmap(hdc, iIconWidth, iIconHeight);
   hOldBmp2 = SelectObject(hdcDst, hXorBitmap);  // select dest bitmap
   DeleteObject(hOldBmp1);
   DeleteObject(hOldBmp2);
   GetObject(hBitmap, sizeof(BITMAP), (VOID FAR *)&XorBitmap);

   // 2) Shrink / expand the bitmap to create an XOR bitmap as the same 
   //    size as that of an icon supported by the system.

   StretchBlt(hdcDst, 0, 0, iIconWidth, iIconHeight,
              hdcSrc, 0, 0, XorBitmap.bmWidth, XorBitmap.bmHeight, SRCCOPY);
   DeleteDC(hdcSrc);

   // Get the expanded/shrunk XorBitmap
   GetObject(hXorBitmap, sizeof(BITMAP), (VOID FAR *)&XorBitmap);

   // Create storage for the set of bytes to be used as the XOR mask for the icon           
   dwNumBytes = (DWORD)(XorBitmap.bmWidthBytes * XorBitmap.bmHeight * XorBitmap.bmPlanes);
   hXorBits = GlobalAlloc(GHND, dwNumBytes);
   if (hXorBits == NULL)
   {
      // clean up before quitting
      Error(ERR_NOMEMALLOC);
      DeleteDC(hdc);      
      DeleteObject(hBitmap);
      DeleteDC(hdcDst);            
      DeleteObject(hXorBitmap);      
      return NULL;
   }
   lpXorBits = GlobalLock(hXorBits);

   // 3) Save the XOR bits in memory.    
   GetBitmapBits(hXorBitmap, dwNumBytes, lpXorBits);

   // 4) Create a monochrome bitmap for the AND mask and fill it with a 
   //    pattern of your choice.

   hAndBitmap = CreateBitmap(iIconWidth, iIconHeight, 1, 1, NULL);
   GetObject(hAndBitmap, sizeof(BITMAP), (VOID FAR *)&AndBitmap);
   dwNumBytes = (DWORD)(AndBitmap.bmWidthBytes * AndBitmap.bmHeight * AndBitmap.bmPlanes);
   hdcTmp = CreateCompatibleDC(hdc);
   hOldBmp3 = SelectObject(hdcTmp, hAndBitmap);
   DeleteObject(hOldBmp3);
   DeleteDC(hdc);

   // Fill the And bitmap with all 0s.  This will make all non-zero
   // colors in our XOR bitmap show through in the original color,
   // and all zero values (black) will show through as black.  Note
   // that since we don't know which part of the bitmap to make 
   // transparent, our AND mask dosen't represent any transparency.

   PatBlt(hdcTmp, 0, 0, iIconWidth, iIconHeight, BLACKNESS);
   hAndBits = GlobalAlloc(GHND, dwNumBytes);
   if (hAndBits == NULL)
   {
      // clean up before quitting
      Error(ERR_NOMEMALLOC);
      GlobalUnlock(hXorBits);
      GlobalFree(hXorBits);
      DeleteDC(hdcDst);
      DeleteDC(hdcTmp);            
      DeleteObject(hBitmap);
      DeleteObject(hAndBitmap);
      DeleteObject(hXorBitmap);      
      return NULL;
   }
   lpAndBits = GlobalLock(hAndBits);

   // 5) Save the AND bits in memory.    
   GetBitmapBits(hAndBitmap, dwNumBytes, lpAndBits);

   // 6) Use the XOR and AND masks and create an icon using CreateIcon.    
   hIcon = CreateIcon(ghInst, iIconWidth, iIconHeight, XorBitmap.bmPlanes,
                      XorBitmap.bmBitsPixel, lpAndBits, lpXorBits);

   // Clean up before exiting.
   GlobalUnlock(hXorBits);
   GlobalFree(hXorBits);
   GlobalUnlock(hAndBits);
   GlobalFree(hAndBits);
   DeleteDC(hdcDst);
   DeleteDC(hdcTmp);
   DeleteObject(hAndBitmap);
   DeleteObject(hBitmap);
   DeleteObject(hXorBitmap);

   return hIcon;
}

//*****************************************************************************
//* Function : CursorToIcon()                                                 *
//* Purpose  : Reads a cursor resource file and creates an icon based on that *
//*            information.                                                   *
//* Parameters : LPSTR szFileName - The cursor resource file.                 *
//* Returns :  A handle to an icon. The handle will be NULL if an icon cannot *
//*            be created for any reason.                                     *
//* Comments : A cursor is monochrome. So, the resulting icon will also be    *
//*            monochrome.                                                    *
//* History :  Date          Author            Reason                         *
//*            2/25/92       Krishna           Created                        *
//*****************************************************************************

HICON CursorToIcon (LPSTR szFileName)
{
   HANDLE hDIB;    // Handle to DIB memory
   HICON hIcon;    // Handle to Icon

   hDIB = ReadCur(szFileName, NULL);   // Read cursor DIB
   if (hDIB == NULL)
      return NULL;

   hIcon = MakeIcon(hDIB);             // make icon from cursor DIB

   GlobalFree(hDIB);
   return hIcon;
}

//*****************************************************************************
//* Function : ReadIcon()                                                     *
//* Purpose  : Reads an icon resource file and extracts the DIB information.  *
//* Parameters : LPSTR szFileName - The icon resource file.                   *
//* Returns :  A handle to a DIB. The handle will be NULL if the resource file*
//*            is corrupt or if memory cannot be allocated for the DIB info.  *
//* Comments : Only the first icon in a given file is read. To modify this    *
//*            procedure to read in all the icons in the .ICO file, you must  *
//*            read in the entire icon resource directory, and find the bits  *
//*            to each icon.  See "Reference - Volume 2" for a description of *
//*            the icon file.                                                 *
//* History :  Date          Author            Reason                         *
//*            2/25/92       Krishna           Created                        *
//*****************************************************************************

HANDLE ReadIcon (LPSTR szFileName)
{
   ICONFILEHEADER iconFileHead;   // ICON file header structure
   ICONFILERES iconFileRes;  // ICON file resource
   WORD cbHead, cbRes, cbBits;    // Used for reading in file
   int hFile; // File handle
   LPBITMAPINFO lpDIB;  // Pointer to DIB memory
   HANDLE hDIB;

   // Open and read the .ICO file header and the first ICONFILERES

   hFile = _lopen(szFileName, OF_READ);
   cbHead = _lread(hFile, (LPSTR)&iconFileHead, sizeof(ICONFILEHEADER));
   cbRes = _lread(hFile, (LPSTR)&iconFileRes, sizeof(ICONFILERES));

   if ((cbHead != sizeof(ICONFILEHEADER)) || (cbRes != sizeof(ICONFILERES)))
   {
      Error(ERR_BADICONHEADER);
      return NULL;
   }

   // Verify that it's an .ICON file

   if (iconFileHead.wResourceType != 1)
   {
      Error(ERR_BADICONRSRC);
      return NULL;
   }

   // Allocate and lock memory to read in the DIB
   hDIB = GlobalAlloc(GHND, iconFileRes.dwDIBSize);
   if (hDIB == NULL)
   {
      Error(ERR_NOMEMALLOC);
      return NULL;
   }
   lpDIB = (LPBITMAPINFO)GlobalLock(hDIB);

   // Now read the DIB portion of the file, which follows the 
   // end of icon resource table
   _llseek(hFile, iconFileRes.dwDIBOffset, 0);
   cbBits = _lread(hFile, (LPSTR)lpDIB, (WORD)iconFileRes.dwDIBSize);

   // Done reading file
   _lclose(hFile);

   if ((DWORD)cbBits != iconFileRes.dwDIBSize)
   {
      GlobalUnlock(hDIB);
      GlobalFree(hDIB);
      return NULL;
   }
   GlobalUnlock(hDIB);
   return hDIB;
}

//*****************************************************************************
//* Function : MakeIcon()                                                     *
//* Purpose  : Creates an icon based on the DIB info. returned by ReadIcon.   *
//* Parameters : HANDLE hDIB - A handle to the icon's DIB information.        *
//* Returns :  A handle to an Icon. NULL is returned if an icon cannot be     *
//*            successfully created.                                          *
//* Comments : The steps involved in making an icon from a DIB are very       *
//*            similar to those involved in making a cursor from a DIB.       *
//* Steps : 1) Obtain a pointer to the Icon's DIB bits.                       *
//*         2) Divide the DIB'd height with 2 to account for the fact that the*
//*            DIB stores both the XOR and the AND masks, one after the other.*
//*         3) Determine the offset to the XOR bits.                          *
//*         4) Determine the offset to the AND bits.                          *
//*         5) Create a device dependent bitmap with the XOR bits.            *
//*         6) Obtain the device dependent XOR bitmask and save in memory.    *
//*            The AND bitmask is monochrome. Monochrome bits are identical   *
//*            in both the device dependent bitmaps and device independent    *
//*            bitmaps. So, no need to convert the AND bitmask.               *
//*         7) Since a DIB is stored upside down, flip the monochrome AND bits*
//*            by scanlines.                                                  *
//*         8) Use the XOR and AND bits and create an icon with CreateIcon.   * 
//* History :  Date          Author            Reason                         *
//*            2/25/92       Krishna           Created                        *
//*****************************************************************************

HICON MakeIcon (HANDLE hDIB)
{
   LPSTR lpXORbits, lpANDbits;    // Pointer to XOR and AND bits
   HBITMAP hbmXor; // handle to XOR bitmap
   BITMAP bmpXor;  // Used to manipulate XOR bitmap    
   DWORD dwBmpSize;     // Size of XOR bitmap   
   HANDLE hXorDDB;
   LPSTR lpXorDDB;
   LONG szFlip[32];
   int j, k;
   HDC hDC;
   HICON hIcon;
   LPBITMAPINFO lpDIB;

   // 1) Obtain a pointer to the Icon's DIB bits.

   lpDIB = (LPBITMAPINFO)GlobalLock(hDIB);

   // 2) Divide the DIB'd height with 2 to account for the fact that the
   //    DIB stores both the XOR and the AND masks, one after the other.   
   lpDIB->bmiHeader.biHeight /= 2;

   // 3) Determine the offset to the XOR bits.  
   // To obtain this value, we have to skip the header, and color table
   lpXORbits = (LPSTR)lpDIB + lpDIB->bmiHeader.biSize +
               (DIBNumColors((LPSTR)lpDIB) * sizeof(RGBQUAD));

   // 4) Determine the offset to the AND bits.
   //    To obtain this value, skip the XOR bits   
   lpANDbits = lpXORbits + lpDIB->bmiHeader.biHeight *
               (WIDTHBYTES (lpDIB->bmiHeader.biWidth * lpDIB->bmiHeader.biBitCount));

   // Get a hDC so we can create a bitmap compatible with it
   hDC = CreateDC("DISPLAY", NULL, NULL, NULL);

   // 5) Create a device dependent bitmap with the XOR bits.
   hbmXor = CreateDIBitmap(hDC, (LPBITMAPINFOHEADER)&(lpDIB->bmiHeader),
                           CBM_INIT, lpXORbits, lpDIB, DIB_RGB_COLORS);

   GetObject(hbmXor, sizeof(BITMAP), (LPSTR)&bmpXor);

   dwBmpSize = (DWORD)(bmpXor.bmWidthBytes * bmpXor.bmHeight * bmpXor.bmPlanes);
   hXorDDB = GlobalAlloc(GHND, dwBmpSize);
   if (hXorDDB == NULL)
   {
      // clean up before quitting
      Error(ERR_NOMEMALLOC);
      DeleteObject(hbmXor);
      DeleteDC(hDC);
      GlobalUnlock(hDIB);      
      return NULL;
   }
   lpXorDDB = GlobalLock(hXorDDB);

   // 6) Obtain the device dependent XOR bitmask and save in memory.
   // The AND bitmask is monochrome. Monochrome bits are identical
   // in both the device dependent bitmaps and device independent
   // bitmaps. So, no need to convert the AND bitmask.   
   GetBitmapBits(hbmXor, dwBmpSize, lpXorDDB);

   // 7) Since a DIB is stored upside down, flip the monochrome AND bits by scanlines.
   k = (int)lpDIB->bmiHeader.biHeight;
   for (j = 0; j < k; j++, lpANDbits += sizeof(DWORD))
      szFlip[(k - 1) - j] = *(DWORD FAR *)lpANDbits;

   // 8) Use the XOR and AND bits and create an icon with CreateIcon.
   hIcon = CreateIcon(ghInst, bmpXor.bmWidth, bmpXor.bmHeight, bmpXor.bmPlanes,
                      bmpXor.bmBitsPixel, (LPSTR)szFlip, lpXorDDB);

   // Clean up before exiting.                   
   DeleteObject(hbmXor);
   GlobalUnlock(hXorDDB);
   GlobalFree(hXorDDB);
   DeleteDC(hDC);
   GlobalUnlock(hDIB);

   return hIcon;
}
