//****************************************************************************
// File: dlgprocs.c
//
// Purpose : Called by DoCommands() when want About dialog box.
//
// Functions:
//    AboutDlg() - dialog function for about box
//
// Development Team: Krishna Nareddy
//                   Mark Bader
//
// Written by Microsoft Product Support Services, Windows Developer Support
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//****************************************************************************

#include <windows.h>
#include "dlgprocs.h"
#include "global.h"

//****************************************************************************
// Function: AboutDlg
//
// Purpose: Called by DoCommands() when want About dialog box.
//
// Parameters:
//    hDlg    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           1/27/92    Krishna       Created
//****************************************************************************

BOOL FAR PASCAL AboutDlg (HWND hDlg,
                          unsigned message,
                          WORD wParam,
                          LONG lParam)
{
   switch (message)
   {
      case WM_INITDIALOG:
         return TRUE;

      case WM_COMMAND:
         if ((wParam == IDOK) ||  // "OK" box selected?        
             (wParam == IDCANCEL))     // System menu close command?
         {
            EndDialog(hDlg, TRUE);     // Exits the dialog box 
            return TRUE;
         }
         break;
   }

   return (FALSE); // Didn't process a message
}

//****************************************************************************
// Function: ViewCurDlgProc
//
// Purpose: Called by DoCommands() when one wants to view a cursor.
//
// Parameters:
//    hDlg    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           2/25/92    Krishna       Created
//****************************************************************************

BOOL FAR PASCAL ViewCurDlgProc (HWND hDlg,
                                unsigned message,
                                WORD wParam,
                                LONG lParam)
{
   PAINTSTRUCT ps;
   static HCURSOR hCursor = NULL;
   char szBuffer[250];
   RECT rc;

   switch (message)
   {
      case WM_INITDIALOG:
         hCursor = (HCURSOR)LOWORD(lParam);   // Retrieve the cursor
         LoadString(ghInst, IDS_CURDLG, (LPSTR)szBuffer, 200);  // Load caption
         lstrcat((LPSTR)szBuffer, (LPSTR)gszFileName);
         SetWindowText(hDlg, (LPSTR)szBuffer);      // set caption
         return TRUE;

      case WM_PAINT:
         BeginPaint(hDlg, &ps);
         GetClientRect(hDlg, &rc);
         // Paint the cursor
         DrawIcon(ps.hdc, (rc.right - GetSystemMetrics(SM_CXCURSOR)) / 2, 20, hCursor);
         EndPaint(hDlg, &ps);
         break;

      case WM_COMMAND:
         if (wParam == IDOK)
         {
            DestroyCursor(hCursor);    // Free the memory associated with the cursor
            EndDialog(hDlg, TRUE);     // Exits the dialog box 
            return TRUE;
         }
         break;
   }

   return (FALSE); // Didn't process a message
}

//****************************************************************************
// Function: ViewIconDlgProc
//
// Purpose: Called by DoCommands() when one wants to view an icon.
//
// Parameters:
//    hDlg    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           2/25/92    Krishna       Created
//****************************************************************************

BOOL FAR PASCAL ViewIconDlgProc (HWND hDlg,
                                 unsigned message,
                                 WORD wParam,
                                 LONG lParam)
{
   PAINTSTRUCT ps;
   static HICON hIcon;
   char szBuffer[250];
   RECT rc;

   switch (message)
   {
      case WM_INITDIALOG:
         hIcon = (HICON)LOWORD(lParam);  // Retrieve the icon
         LoadString(ghInst, IDS_ICONDLG, (LPSTR)szBuffer, 200); // load caption
         lstrcat((LPSTR)szBuffer, (LPSTR)gszFileName); 
         SetWindowText(hDlg, (LPSTR)szBuffer);  // set caption
         return TRUE;

      case WM_PAINT:
         BeginPaint(hDlg, &ps);
         GetClientRect(hDlg, &rc);
         // Draw the icon
         DrawIcon(ps.hdc, (rc.right - GetSystemMetrics(SM_CXICON)) / 2, 20, hIcon);
         EndPaint(hDlg, &ps);
         break;

      case WM_COMMAND:
         if (wParam == IDOK)
         {
            DestroyIcon(hIcon);   // Free the memory associated with the icon         
            EndDialog(hDlg, TRUE);     // Exits the dialog box 
            return TRUE;
         }
         break;
   }

   return (FALSE); // Didn't process a message
}

//****************************************************************************
// Function: ViewBmpDlgProc
//
// Purpose: Called by DoCommands() when one wants to view a bitmap.
//
// Parameters:
//    hDlg    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           2/25/92    Krishna       Created
//****************************************************************************

BOOL FAR PASCAL ViewBmpDlgProc (HWND hDlg,
                                unsigned message,
                                WORD wParam,
                                LONG lParam)
{
   PAINTSTRUCT ps;
   static HBITMAP hBmp;
   HBITMAP hOldBmp;
   char szBuffer[250];
   RECT rc;
   HDC hMemDC;
   BITMAP bmp;

   switch (message)
   {
      case WM_INITDIALOG:
         hBmp = (HBITMAP)LOWORD(lParam); // Retrieve the bitmap
         LoadString(ghInst, IDS_BMPDLG, (LPSTR)szBuffer, 200); // load caption
         lstrcat((LPSTR)szBuffer, (LPSTR)gszFileName);
         SetWindowText(hDlg, (LPSTR)szBuffer); // set caption
         return TRUE;

      case WM_PAINT:
         BeginPaint(hDlg, &ps);
         GetClientRect(hDlg, &rc);
         GetObject(hBmp, sizeof(BITMAP), (LPSTR)&bmp);
         hMemDC = CreateCompatibleDC(ps.hdc); // create a mem DC
         hOldBmp = SelectObject(hMemDC, hBmp);  // select bitmap to be displayed
         // Copy the bitmap from memory to the screen (using hdc given in paintstruct)
         BitBlt(ps.hdc, (rc.right - bmp.bmWidth) / 2, (rc.bottom - bmp.bmHeight - 40)/2,
                bmp.bmWidth, bmp.bmHeight, hMemDC, 0, 0, SRCCOPY);
         DeleteObject(SelectObject(hMemDC, hOldBmp));
         DeleteDC(hMemDC);   // Also deletes the Bitmap selected into it
         EndPaint(hDlg, &ps);
         break;

      case WM_COMMAND:
         if (wParam == IDOK)
         {
            EndDialog(hDlg, TRUE);     // Exits the dialog box 
            return TRUE;
         }
         break;
   }

   return (FALSE); // Didn't process a message
}

//****************************************************************************
// Function: ViewIconCurDlgProc
//
// Purpose: Called by DoCommands() when one wants to view a cursor read from
//          an icon resource file (converted from icon to cursor)
//
// Parameters:
//    hDlg    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           2/25/92    Krishna       Created
//****************************************************************************

BOOL FAR PASCAL ViewIconCurDlgProc (HWND hDlg,
                                    unsigned message,
                                    WORD wParam,
                                    LONG lParam)
{
   PAINTSTRUCT ps;
   static HCURSOR hCursor = NULL;
   static HICON hIcon;
   char szBuffer[250];
   RECT rc;

   switch (message)
   {
      case WM_INITDIALOG:
         hCursor = (HCURSOR)LOWORD(lParam);   // Retrieve the cursor
         return TRUE;

      case WM_PAINT:
         BeginPaint(hDlg, &ps);
         GetClientRect(hDlg, &rc);
         // Get the icon from which the cursor was made
         hIcon = ReadIconFile((LPSTR)gszFileName);
         LoadString(ghInst, IDS_ICONCURDLG, (LPSTR)szBuffer, 200);
         lstrcat((LPSTR)szBuffer, (LPSTR)gszFileName);
         SetWindowText(hDlg, (LPSTR)szBuffer);
         // Draw the icon on the left half of the dialog
         DrawIcon(ps.hdc, (rc.right / 2 - GetSystemMetrics(SM_CXICON)) / 2, 20, hIcon);
         // Draw the cursor on the right half of the dialog
         DrawIcon(ps.hdc, (3 * rc.right - 2 * GetSystemMetrics(SM_CXICON)) / 4, 20, hCursor);
         EndPaint(hDlg, &ps);
         break;

      case WM_COMMAND:
         if (wParam == IDOK)
         {
            DestroyCursor(hCursor);    // Free the memory associated with the cursor         
            DestroyIcon(hIcon);   // Free the memory associated with the icon            
            EndDialog(hDlg, TRUE);     // Exits the dialog box 
            return TRUE;
         }
         break;
   }

   return (FALSE); // Didn't process a message
}

//****************************************************************************
// Function: ViewCurIconDlgProc
//
// Purpose: Called by DoCommands() when one wants to view an icon read from
//          a cursor resource file (converted from cursor to icon)
//
// Parameters:
//    hDlg    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           2/25/92    Krishna       Created
//****************************************************************************

BOOL FAR PASCAL ViewCurIconDlgProc (HWND hDlg,
                                    unsigned message,
                                    WORD wParam,
                                    LONG lParam)
{
   PAINTSTRUCT ps;
   static HICON hIcon = NULL;
   static HCURSOR hCursor;
   char szBuffer[250];
   RECT rc;

   switch (message)
   {
      case WM_INITDIALOG:
         hIcon = (HICON)LOWORD(lParam);  // Retrieve the icon
         return TRUE;

      case WM_PAINT:
         BeginPaint(hDlg, &ps);
         GetClientRect(hDlg, &rc);
         // get the cursor from which this icon was created
         hCursor = ReadCursorFile((LPSTR)gszFileName);
         LoadString(ghInst, IDS_CURICONDLG, (LPSTR)szBuffer, 200);
         lstrcat((LPSTR)szBuffer, (LPSTR)gszFileName);
         SetWindowText(hDlg, (LPSTR)szBuffer);
         // draw the cursor on the left half of the screen
         DrawIcon(ps.hdc, (rc.right / 2 - GetSystemMetrics(SM_CXICON)) / 2, 20, hCursor);
         // draw the icon on the right half of the screen
         DrawIcon(ps.hdc, (3 * rc.right - 2 * GetSystemMetrics(SM_CXICON)) / 4, 20, hIcon);
         EndPaint(hDlg, &ps);
         break;

      case WM_COMMAND:
         if (wParam == IDOK)
         {
            DestroyCursor(hCursor);    // Free the memory associated with the cursor         
            DestroyIcon(hIcon);   // Free the memory associated with the icon         
            EndDialog(hDlg, TRUE);     // Exits the dialog box 
            return TRUE;
         }
         break;
   }

   return (FALSE); // Didn't process a message
}

//****************************************************************************
// Function: ViewBmpIconDlgProc
//
// Purpose: Called by DoCommands() when one wants to view an icon read from
//          a bitmap resource file (converted from bitmap to icon)
//
// Parameters:
//    hDlg    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           2/25/92    Krishna       Created
//****************************************************************************

BOOL FAR PASCAL ViewBmpIconDlgProc (HWND hDlg,
                                    unsigned message,
                                    WORD wParam,
                                    LONG lParam)
{
   PAINTSTRUCT ps;
   static HICON hIcon = NULL;
   static HBITMAP hBmp = NULL;
   HBITMAP hOldBmp;
   BITMAP bmp;
   char szBuffer[250];
   RECT rc;
   HDC hMemDC;
   int iIconWidth, iIconHeight;

   switch (message)
   {
      case WM_INITDIALOG:
         hIcon = (HICON)LOWORD(lParam);   // retrieve the icon
         return TRUE;

      case WM_PAINT:
         BeginPaint(hDlg, &ps);
         GetClientRect(hDlg, &rc);
         // get the icon's dimensions
         iIconWidth = GetSystemMetrics(SM_CXICON);
         iIconHeight = GetSystemMetrics(SM_CYICON);
         // get the bitmap from which the icon was created
         hBmp = ReadBmpFile((LPSTR)gszFileName);
         LoadString(ghInst, IDS_BMPICONDLG, (LPSTR)szBuffer, 200);
         lstrcat((LPSTR)szBuffer, (LPSTR)gszFileName);
         SetWindowText(hDlg, (LPSTR)szBuffer);
         GetObject(hBmp, sizeof(BITMAP), (LPSTR)&bmp);
         hMemDC = CreateCompatibleDC(ps.hdc); // create mem DC
         hOldBmp = SelectObject(hMemDC, hBmp); // select bitmap to be shown
         
         // draw the bitmap on the left side of the dialog 
         BitBlt(ps.hdc, (rc.right - bmp.bmHeight - iIconWidth - 20) / 2,
                (rc.bottom - bmp.bmHeight) / 2, bmp.bmWidth,
                bmp.bmHeight, hMemDC, 0, 0, SRCCOPY);
         hBmp = SelectObject(hMemDC, hOldBmp);
         DeleteObject(hBmp);
         DeleteDC(hMemDC);
         
         // draw the icon on the right side of the dialog
         DrawIcon(ps.hdc, rc.right - iIconWidth - 10,
                  (rc.bottom - iIconHeight) / 2, hIcon);
         EndPaint(hDlg, &ps);
         break;

      case WM_COMMAND:
         if (wParam == IDOK)
         {
            DestroyIcon(hIcon);   // Free the memory associated with the icon         
            EndDialog(hDlg, TRUE);     // Exits the dialog box 
            return TRUE;
         }
         break;
   }

   return FALSE;   // Didn't process a message
}

//****************************************************************************
// Function: ViewBmpCurDlgProc
//
// Purpose: Called by DoCommands() when one wants to view a cursor read from
//          a bitmap resource file (converted from bitmap to cursor)
//
// Parameters:
//    hDlg    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           2/25/92    Krishna       Created
//****************************************************************************

BOOL FAR PASCAL ViewBmpCurDlgProc (HWND hDlg,
                                   unsigned message,
                                   WORD wParam,
                                   LONG lParam)
{
   PAINTSTRUCT ps;
   static HCURSOR hCursor = NULL;
   static HBITMAP hBmp = NULL;
   HBITMAP hOldBmp;
   BITMAP bmp;
   char szBuffer[250];
   RECT rc;
   HDC hMemDC;
   int iCurWidth, iCurHeight;

   switch (message)
   {
      case WM_INITDIALOG:
         hCursor = (HCURSOR)LOWORD(lParam); // Retrieve the cursor
         return TRUE;

      case WM_PAINT:
         BeginPaint(hDlg, &ps);
         GetClientRect(hDlg, &rc);
         // Get the cursor's dimensions
         iCurWidth = GetSystemMetrics(SM_CXCURSOR);
         iCurHeight = GetSystemMetrics(SM_CYCURSOR);
         
         // get the bitmap from which this cursor was created
         hBmp = ReadBmpFile((LPSTR)gszFileName);
         LoadString(ghInst, IDS_BMPCURDLG, (LPSTR)szBuffer, 200);
         lstrcat((LPSTR)szBuffer, (LPSTR)gszFileName);
         SetWindowText(hDlg, (LPSTR)szBuffer);
         GetObject(hBmp, sizeof(BITMAP), (LPSTR)&bmp);
         // prepare to display the bitmap
         hMemDC = CreateCompatibleDC(ps.hdc);
         hOldBmp = SelectObject(hMemDC, hBmp);
         
         // display the bitmap on the left side of the dialog
         BitBlt(ps.hdc, (rc.right - bmp.bmHeight - iCurWidth - 20) / 2,
                (rc.bottom - bmp.bmHeight) / 2, bmp.bmWidth,
                bmp.bmHeight, hMemDC, 0, 0, SRCCOPY);
         hBmp = SelectObject(hMemDC, hOldBmp);
         DeleteObject(hBmp);
         DeleteDC(hMemDC);
         
         // display the cursor on the right side of the dialog
         DrawIcon(ps.hdc, rc.right - iCurWidth - 10, (rc.bottom - iCurHeight) / 2, hCursor);
         EndPaint(hDlg, &ps);
         break;

      case WM_COMMAND:
         if (wParam == IDOK)
         {
            DestroyCursor(hCursor);    // Free the memory associated with the cursor         
            EndDialog(hDlg, TRUE);     // Exits the dialog box 
            return TRUE;
         }
         break;
   }

   return FALSE;   // Didn't process a message
}

//****************************************************************************
// Function: ViewCurBmpDlgProc
//
// Purpose: Called by DoCommands() when one wants to view a bitmap read from
//          a cursor resource file (converted from cursor to bitmap)
//
// Parameters:
//    hDlg    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           2/25/92    Krishna       Created
//****************************************************************************

BOOL FAR PASCAL ViewCurBmpDlgProc (HWND hDlg,
                                   unsigned message,
                                   WORD wParam,
                                   LONG lParam)
{
   PAINTSTRUCT ps;
   static HCURSOR hCursor = NULL;
   static HBITMAP hBmp = NULL;
   HBITMAP hOldBmp;
   BITMAP bmp;
   char szBuffer[250];
   RECT rc;
   HDC hMemDC;
   int iCurWidth, iCurHeight;

   switch (message)
   {
      case WM_INITDIALOG:
         hBmp = (HBITMAP)LOWORD(lParam);    // Retrieve the bitmap
         return TRUE;

      case WM_PAINT:
         BeginPaint(hDlg, &ps);
         GetClientRect(hDlg, &rc);
         // find the cursor dimensions
         iCurWidth = GetSystemMetrics(SM_CXCURSOR);
         iCurHeight = GetSystemMetrics(SM_CYCURSOR);
         // get the cursor from which this bitmap was created
         hCursor = ReadCursorFile((LPSTR)gszFileName);
         LoadString(ghInst, IDS_CURBMPDLG, (LPSTR)szBuffer, 200);
         lstrcat((LPSTR)szBuffer, (LPSTR)gszFileName);
         SetWindowText(hDlg, (LPSTR)szBuffer);
         GetObject(hBmp, sizeof(BITMAP), (LPSTR)&bmp);
         
         // prepare to display the bitmap
         hMemDC = CreateCompatibleDC(ps.hdc);
         hOldBmp = SelectObject(hMemDC, hBmp);
         
         // display the bitmap on the right side of the screen
         BitBlt(ps.hdc, rc.right / 2 + (rc.right / 2 - iCurWidth) / 2,
                (rc.bottom - iCurHeight) / 2 - 30, bmp.bmWidth, bmp.bmHeight,
                hMemDC, 0, 0, SRCCOPY);
         hBmp = SelectObject(hMemDC, hOldBmp);
         DeleteObject(hBmp);
         DeleteDC(hMemDC);
         
         // display the cursor on the left side of the screen
         DrawIcon(ps.hdc, (rc.right / 2 - iCurWidth) / 2,
                  (rc.bottom - iCurHeight) / 2 - 30, hCursor);
         EndPaint(hDlg, &ps);
         break;

      case WM_COMMAND:
         if (wParam == IDOK)
         {
            DestroyCursor(hCursor);    // Free the memory associated with the cursor         
            EndDialog(hDlg, TRUE);     // Exits the dialog box 
            return TRUE;
         }
         break;
   }

   return FALSE;   // Didn't process a message
}

//****************************************************************************
// Function: ViewIconBmpDlgProc
//
// Purpose: Called by DoCommands() when one wants to view a bitmap read from
//          an icon resource file (converted from cursor to icon)
//
// Parameters:
//    hDlg    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           2/25/92    Krishna       Created
//****************************************************************************

BOOL FAR PASCAL ViewIconBmpDlgProc (HWND hDlg,
                                    unsigned message,
                                    WORD wParam,
                                    LONG lParam)
{
   PAINTSTRUCT ps;
   static HICON hIcon = NULL;
   static HBITMAP hBmp = NULL;
   HBITMAP hOldBmp;
   BITMAP bmp;
   char szBuffer[250];
   RECT rc;
   HDC hMemDC;
   int iIconWidth, iIconHeight;

   switch (message)
   {
      case WM_INITDIALOG:
         hBmp = (HBITMAP)LOWORD(lParam);   // Retrieve the bitmap
         return TRUE;

      case WM_PAINT:
         BeginPaint(hDlg, &ps);
         GetClientRect(hDlg, &rc);
         // Get the icon's dimensions
         iIconWidth = GetSystemMetrics(SM_CXICON);
         iIconHeight = GetSystemMetrics(SM_CYICON);
         hIcon = ReadIconFile((LPSTR)gszFileName);
         LoadString(ghInst, IDS_ICONBMPDLG, (LPSTR)szBuffer, 200);
         lstrcat((LPSTR)szBuffer, (LPSTR)gszFileName);
         SetWindowText(hDlg, (LPSTR)szBuffer);
         GetObject(hBmp, sizeof(BITMAP), (LPSTR)&bmp);
         
         // prepare to display the bitmap
         hMemDC = CreateCompatibleDC(ps.hdc);
         hOldBmp = SelectObject(hMemDC, hBmp);
         
         // Display the bitmap on the right side of the dialog
         BitBlt(ps.hdc, rc.right / 2 + (rc.right / 2 - iIconWidth) / 2,
                (rc.bottom - iIconHeight) / 2 - 30, bmp.bmWidth, bmp.bmHeight,
                hMemDC, 0, 0, SRCCOPY);
         hBmp = SelectObject(hMemDC, hOldBmp);
         DeleteObject(hBmp);
         DeleteDC(hMemDC);
         
         // display the icon on the left side of the dialog
         DrawIcon(ps.hdc, (rc.right / 2 - iIconWidth) / 2,
                  (rc.bottom - iIconHeight) / 2 - 30, hIcon);
         EndPaint(hDlg, &ps);
         break;

      case WM_COMMAND:
         if (wParam == IDOK)
         {
            DestroyIcon(hIcon);   // Free the memory associated with the icon         
            EndDialog(hDlg, TRUE);     // Exits the dialog box 
            return TRUE;
         }
         break;
   }

   return FALSE;   // Didn't process a message
}
