//*****************************************************************************
//* File Name : dlgopen.c                                                     *
//* Purpose : Ruotines that present file open dialog boxes.                   *
//* Functions : DlgOpenFile() - Open and close the file open dialog box.      *
//*             DlgFnOpen() - File open dialog box's procedure.               *
//*                                                                           *
//* Development Team : Krishna Nareddy                                        *
//*                    Mark Bader                                             *
//*                                                                           *
//* Comments : The goal of the routines in this file is to be simple to read  *
//*            and understand, rather than to be computationally efficient.   *
//*                                                                           *
//* Written by Microsoft Product Support Services, Windows Developer Support. *
//*****************************************************************************

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <windows.h>
#include "dlgopen.h"
#include "global.h"

// szOpenFile is the buffer where we will place the file name that the
// user selected.  We then will pass back a pointer to this buffer.
static char szOpenFile[MAXFILENAMELEN];
static char achWild[MAXFILENAMELEN];   // Used to keep track of wild cards
static char achTitle[50];    // Title for dialog box
static WORD fOpt;  // Local copy of options

//*****************************************************************************
//* Function : DlgOpenFile()                                                  *
//* Purpose  : Opens up a File/Save dialog box and passes back the selected   *
//*            filename (or NULL if user selected cancel.)                    *
//* Parameters : HWND hwndParent - Handle to parent window (after all, we're  *
//*              calling up a dialog box, and they all need parents)          *
//*              LPSTR szTitleIn - Title to be placed in caption of dialog box*
//*              LPSTR szExtIn - File wildcards to list (e.g. "*.BMP")        *
//* Returns :  Pointer to filename if successful, NULL if user pressed cancel.*
//* Comments : A cursor's DIB has both the XOR and AND bitmaps. Take only the *
//*            XOR bitmap. This bitmap will be monochrome.                    *
//* History :  Date          Author            Reason                         *
//*            12/11/91      Mark Bader        Created from ShowDIB SDK sample*
//*****************************************************************************

LPSTR FAR PASCAL DlgOpenFile (HWND hwndParent,
                              LPSTR szTitleIn,
                              LPSTR szExtIn)
{
   FARPROC lpProc;
   HANDLE hInstance;
   int nReturn;
   WORD w = 0;

   // Copy parameters to static globals

   lstrcpy(achWild, szExtIn);
   lstrcpy(achTitle, szTitleIn);

   hInstance = GetWindowWord(hwndParent, GWW_HINSTANCE);

   // Show the dialog box
   lpProc = MakeProcInstance((FARPROC)DlgFnOpen, hInstance);
   nReturn = DialogBox(hInstance, "DLGOPEN", hwndParent, lpProc);
   FreeProcInstance(lpProc);

   if (nReturn == FALSE)
      return (LPSTR)"";
   else
      return (LPSTR)szOpenFile;
}

//*****************************************************************************
//* Function : DlgFnOpen()                                                    *
//* Purpose  : Main window procedure for the file open dialog box.            *
//*            filename (or NULL if user selected cancel.)                    *
//* Parameters : (Regular)                                                    *
//* Returns :  (Regular)                                                      *
//* Comments :                                                                *
//* History :  Date          Author            Reason                         *
//*            12/11/91      Mark Bader        Created from ShowDIB SDK sample*
//*****************************************************************************

BOOL FAR PASCAL DlgFnOpen (HWND hDlg, WORD msg, WORD wParam, LONG lParam)
{
   RECT rc, rcCtl;

   switch (msg)
   {
      case WM_INITDIALOG:
      {
         HWND hCtl;
         HWND hWndT;

         // Shrink dialog box.  The way we do this is to have 2 "hidden"
         // controls in our dialog box which define where the big and
         // small size of the dialog box is to be.  

         if (hWndT = GetDlgItem(hDlg, DLGOPEN_SMALL))
         {
            GetWindowRect(hDlg, &rc);
            GetWindowRect(GetDlgItem(hDlg, DLGOPEN_SMALL), &rcCtl);

            SetWindowPos(hDlg,
                         NULL,
                         0,
                         0,
                         rcCtl.left - rc.left,
                         rc.bottom - rc.top,
                         SWP_NOZORDER | SWP_NOMOVE);
         }

         // Initialize Directory Listing
         DlgDirList(hDlg,
                    achWild,
                    DLGOPEN_DIR_LISTBOX,
                    DLGOPEN_PATH,
                    0xC010);

         // Initialize File Listing
         DlgDirList(hDlg,
                    achWild,
                    DLGOPEN_FILE_LISTBOX,
                    DLGOPEN_PATH,
                    0);

         // Limit Text Length in Edit Control
         hCtl = GetDlgItem(hDlg, DLGOPEN_EDIT);
         SendMessage(hCtl,
                     EM_LIMITTEXT,
                     MAXFILENAMELEN,
                     0);

         // Put Wild Card into Edit Control
         SendMessage(hCtl,
                     WM_SETTEXT,
                     0,
                     (LONG)(LPSTR)achWild);

         // Select Text in Edit Control
         SendMessage(hCtl,
                     EM_SETSEL,
                     0,
                     MAKELONG(0,MAXFILENAMELEN));


         // Set Window Text
         SetWindowText(hDlg, achTitle);
      }
         return TRUE;
         break;

      case WM_COMMAND:
      {
         BOOL bWild;
         char achBuf[MAXFILENAMELEN];
         HWND hCtl;
         int cc;
         PSTR p;
         WORD wNotify;

         wNotify = HIWORD(lParam);
         hCtl = LOWORD(lParam);

         switch (wParam)
         {
            case IDOK:

               // Read file name from the Edit Control
               DoOK:
               hCtl = GetDlgItem(hDlg, DLGOPEN_EDIT);
               SendMessage(hCtl,
                           WM_GETTEXT,
                           MAXFILENAMELEN,
                           (LONG)(LPSTR)achBuf);

               // Trim Leading Blanks from File Name

               p = achBuf;
               while (*p == ' ')
                  p++;
               if (p != achBuf)
                  lstrcpy(achBuf, p);

               // Trim Trailing Blanks From File Name

               cc = lstrlen(achBuf);
               for (p = achBuf + cc - 1; *p == ' '; p--)
                  *p = 0;

               // Check for Wild Cards

               bWild = FALSE;

               for (p = achBuf; *p != NULL; p++)
               {
                  if (*p == '?' || *p == '*')
                  {
                     bWild = TRUE;
                     break;
                  }
               }

               // If no Wild Card then check to see if it exists --
               // if so, ask for confirmation

               if (!bWild)
               {
                  // Pass back the filename.
                  lstrcpy(szOpenFile, achBuf);   // store filename
                  EndDialog(hDlg, TRUE);
                  break;
               }
               else
               {
                  Error(ERR_NOFILENAME);
                  return FALSE;
               }

               break;

            case IDCANCEL:
               EndDialog(hDlg, FALSE);
               break;

            case DLGOPEN_EDIT:
               if (wNotify == EN_CHANGE)
               {
               // Enable or Disable the PushButton
               // based on whether Edit Control is
               // Empty or Not
                  cc = (int)SendMessage(hCtl,
                                        WM_GETTEXTLENGTH,
                                        0,
                                        0L);

                  hCtl = GetDlgItem(hDlg, IDOK);
                  EnableWindow(hCtl, cc);
               }
               break;

            case DLGOPEN_FILE_LISTBOX:
               if (wNotify == LBN_SELCHANGE)
               {
                  DlgDirSelect(hDlg,
                               achBuf,
                               DLGOPEN_FILE_LISTBOX);

                  hCtl = GetDlgItem(hDlg, DLGOPEN_EDIT);

                  SendMessage(hCtl,
                              WM_SETTEXT,
                              0,
                              (LONG)(LPSTR)achBuf);
               }

               if (wNotify == LBN_DBLCLK)
                  goto DoOK;
               break;

            case DLGOPEN_FOLDOUT:
               GetWindowRect(hDlg, &rc);
               GetWindowRect(GetDlgItem(hDlg, DLGOPEN_BIG), &rcCtl);

               if ((rcCtl.left <= rc.right) && (rcCtl.top <= rc.bottom))
                  GetWindowRect(GetDlgItem(hDlg, DLGOPEN_SMALL), &rcCtl);

               SetWindowPos(hDlg,
                            NULL,
                            0,
                            0,
                            rcCtl.left - rc.left,
                            rc.bottom - rc.top,
                            SWP_NOZORDER | SWP_NOMOVE);

               // Gray out "Fold >>" Box
               EnableWindow(GetDlgItem(hDlg, DLGOPEN_FOLDOUT), FALSE);

               break;

            case DLGOPEN_DIR_LISTBOX:
               if (wNotify == LBN_SELCHANGE)
               {
                  DlgDirSelect(hDlg,
                               achBuf,
                               DLGOPEN_DIR_LISTBOX);

                  hCtl = GetDlgItem(hDlg, DLGOPEN_EDIT);

                  lstrcat(achBuf, achWild);

                  SendMessage(hCtl,
                              WM_SETTEXT,
                              0,
                              (LONG)(LPSTR)achBuf);
               }

               if (wNotify == LBN_DBLCLK)
               {
                  DlgDirSelect(hDlg,
                               achBuf,
                               DLGOPEN_DIR_LISTBOX);

                  DlgDirList(hDlg,
                             achBuf,
                             DLGOPEN_DIR_LISTBOX,
                             DLGOPEN_PATH,
                             0xC010);

                  // Initialize File Listing

                  DlgDirList(hDlg,
                             achWild,
                             DLGOPEN_FILE_LISTBOX,
                             DLGOPEN_PATH,
                             0);


                  // Put Wild Card into Edit Control

                  hCtl = GetDlgItem(hDlg, DLGOPEN_EDIT);

                  SendMessage(hCtl,
                              WM_SETTEXT,
                              0,
                              (LONG)(LPSTR)achWild);

                  // Select all text in Edit Control

                  SendMessage(hCtl,
                              EM_SETSEL,
                              0,
                              MAKELONG(0,MAXFILENAMELEN));

                  // Give keyboard to Edit control

                  SetFocus(hCtl);
               }

               return TRUE;
               break;
         }
      }
         return TRUE;

      default:
         return FALSE;
   }
}
