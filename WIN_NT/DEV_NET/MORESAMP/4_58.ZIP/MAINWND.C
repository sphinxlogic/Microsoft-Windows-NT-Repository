//****************************************************************************
// File: mainwnd.c
//
// Purpose: Main overlapped window's message handler
//
// Functions:
//    MainWndProc() - message handler for main overlapped window
//    DoCommands() - called by MainWndProc to handle all WM_COMMAND messages
//
// Development Team: Krishna Nareddy
//                   Mark Bader
//
// Written by Microsoft Product Support Services, Windows Developer Support
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//****************************************************************************

#include <windows.h>
#include "dlgprocs.h"
#include "dlgopen.h"
#include "mainwnd.h"

// Local function prototypes.
long DoCommands (HWND hWnd,
                 unsigned message,
                 WORD wParam,
                 LONG lParam);

//****************************************************************************
// Function: MainWndProc
//
// Purpose: Message handler for main overlapped window.
//
// Parameters:
//    hWnd    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           2/25/92    Krishna       Created
//****************************************************************************

long FAR PASCAL MainWndProc (HWND hWnd,
                             unsigned message,
                             WORD wParam,
                             LONG lParam)
{
   switch (message)
   {
      // Dispatch WM_COMMAND messages to our command handler, DoCommands().
      case WM_COMMAND:
         return DoCommands(hWnd, message, wParam, lParam);

      // On WM_DESTROY, terminate this app by posting a WM_QUIT message.

      case WM_DESTROY:
         PostQuitMessage(0);
         break;


      // We didn't handle, pass to DefWindowProc.

      default:
         return DefWindowProc(hWnd, message, wParam, lParam);
   }

   return (NULL);
}

//****************************************************************************
// Function: DoCommands
//
// Purpose: Called by MainWndProc() to handle all WM_COMMAND messages.
//
// Parameters:
//    hWnd    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns : Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           2/25/92    Krishna       Created
//****************************************************************************

long DoCommands (HWND hWnd,
                 unsigned message,
                 WORD wParam,
                 LONG lParam)
{
   static FARPROC lpDlgProc;

   switch (wParam)
   {
      // Put up the About box.
      case IDM_ABOUT:
      {
         lpDlgProc = MakeProcInstance(AboutDlg, ghInst);

         DialogBox(ghInst,   // current instance
                   AboutBoxName,  // resource to use 
                   hWnd,     // parent handle   
                   lpDlgProc);    // About() instance address

         FreeProcInstance(lpDlgProc);
         break;
      }

      case IDM_OPENICON:
      {
         HICON hIcon;

         // obtain the file in which the resource exists
         lstrcpy((LPSTR)gszFileName, DlgOpenFile(hWnd, (LPSTR)"Open Icon File", (LPSTR)"*.ICO"));
         if (gszFileName[0] == '\0')   // if file name is empty
            break;
         hIcon = ReadIconFile((LPSTR)gszFileName); // create an icon from the file
         if (hIcon == NULL)
            break;
         lpDlgProc = MakeProcInstance(ViewIconDlgProc, ghInst);
         // display the icon
         DialogBoxParam(ghInst, "ViewIconDlg", hWnd, lpDlgProc, MAKELONG((WORD)hIcon, 0));
         FreeProcInstance(lpDlgProc);
         break;
      }

      case IDM_OPENCUR:
      {
         HCURSOR hCursor;

         // obtain the file in which the resource exists
         lstrcpy((LPSTR)gszFileName, DlgOpenFile(hWnd, (LPSTR)"Open Cursor File", (LPSTR)"*.CUR"));
         if (gszFileName[0] == '\0')   // if file name is empty
            break;
         hCursor = ReadCursorFile((LPSTR)gszFileName);  // create a cursor from the file
         if (hCursor == NULL)
            break;
         lpDlgProc = MakeProcInstance(ViewCurDlgProc, ghInst);
         // display the cursor
         DialogBoxParam(ghInst, "ViewCurDlg", hWnd, lpDlgProc, MAKELONG((WORD)hCursor, 0));
         FreeProcInstance(lpDlgProc);
         break;
      }

      case IDM_OPENBMP:
      {
         HBITMAP hBitmap;

         // obtain the file in which the resource exists        
         lstrcpy((LPSTR)gszFileName, DlgOpenFile(hWnd, (LPSTR)"Open Bitmap File", (LPSTR)"*.BMP"));
         if (gszFileName[0] == '\0')   // if file name is empty
            break;
         hBitmap = ReadBmpFile((LPSTR)gszFileName);   // create a bitmap from the file
         if (hBitmap == NULL)
            break;
         lpDlgProc = MakeProcInstance(ViewBmpDlgProc, ghInst);
         // display the bitmap
         DialogBoxParam(ghInst, "ViewBmpDlg", hWnd, lpDlgProc, MAKELONG((WORD)hBitmap, 0));
         FreeProcInstance(lpDlgProc);
         break;
      }

      case IDM_ICONTOCUR:
      {
         HCURSOR hCursor;

         // obtain the file in which the resource exists
         lstrcpy((LPSTR)gszFileName, DlgOpenFile(hWnd, (LPSTR)"Open Icon File", (LPSTR)"*.ICO"));
         if (gszFileName[0] == '\0')   // if file name is empty
            break;
         hCursor = IconToCursor((LPSTR)gszFileName);  // create a cursor from the icon resource
         if (hCursor == NULL)
            break;
         lpDlgProc = MakeProcInstance(ViewIconCurDlgProc, ghInst);
         
         // display the icon and the cursor
         DialogBoxParam(ghInst, "ViewIconCurDlg", hWnd, lpDlgProc, MAKELONG((WORD)hCursor, 0));
         FreeProcInstance(lpDlgProc);
         break;
      }

      case IDM_CURTOICON:
      {
         HICON hIcon;

         // obtain the file in which the resource exists
         lstrcpy((LPSTR)gszFileName, DlgOpenFile(hWnd, (LPSTR)"Open Cursor File", (LPSTR)"*.CUR"));
         if (gszFileName[0] == '\0')   // if file name is empty
            break;
         hIcon = CursorToIcon((LPSTR)gszFileName); // create an icon from the cursor resource
         if (hIcon == NULL)
            break;
         lpDlgProc = MakeProcInstance(ViewCurIconDlgProc, ghInst);
         
         // display the cursor and the icon 
         DialogBoxParam(ghInst, "ViewCurIconDlg", hWnd, lpDlgProc, MAKELONG((WORD)hIcon, 0));
         FreeProcInstance(lpDlgProc);
         break;
      }

      case IDM_BMPTOICON:
      {
         HICON hIcon;

         // obtain the file in which the resource exists
         lstrcpy((LPSTR)gszFileName, DlgOpenFile(hWnd, (LPSTR)"Open Bitmap File", (LPSTR)"*.BMP"));
         if (gszFileName[0] == '\0')   // if file name is empty
            break;
         hIcon = BitmapToIcon((LPSTR)gszFileName); // create a bitmap from the icon resource
         if (hIcon == NULL)
            break;
         lpDlgProc = MakeProcInstance(ViewBmpIconDlgProc, ghInst);
         // display the bitmap and the icon
         DialogBoxParam(ghInst, "ViewBmpIconDlg", hWnd, lpDlgProc, MAKELONG((WORD)hIcon, 0));
         FreeProcInstance(lpDlgProc);
         break;
      }

      case IDM_BMPTOCUR:
      {
         HCURSOR hCursor;

         // obtain the file in which the resource exists
         lstrcpy((LPSTR)gszFileName, DlgOpenFile(hWnd, (LPSTR)"Open Bitmap File", (LPSTR)"*.BMP"));
         if (gszFileName[0] == '\0')   // if file name is empty
            break;
         hCursor = BitmapToCursor((LPSTR)gszFileName);    // create a bitmap from cursor resource
         if (hCursor == NULL)
            break;
         lpDlgProc = MakeProcInstance(ViewBmpCurDlgProc, ghInst);
         // display the bitmap and the cursor
         DialogBoxParam(ghInst, "ViewBmpCurDlg", hWnd, lpDlgProc, MAKELONG((WORD)hCursor, 0));
         FreeProcInstance(lpDlgProc);
         break;
      }

      case IDM_CURTOBMP:
      {
         HBITMAP hBitmap;

         // obtain the file in which the resource exists
         lstrcpy((LPSTR)gszFileName, DlgOpenFile(hWnd, (LPSTR)"Open Cursor File", (LPSTR)"*.CUR"));
         if (gszFileName[0] == '\0')   // if file name is empty
            break;
         hBitmap = CursorToBitmap((LPSTR)gszFileName); // create a cursor from bitmap resource
         if (hBitmap == NULL)
            break;
         lpDlgProc = MakeProcInstance(ViewCurBmpDlgProc, ghInst);
         // display both the cursor and the bitmap
         DialogBoxParam(ghInst, "ViewCurBmpDlg", hWnd, lpDlgProc, MAKELONG((WORD)hBitmap, 0));
         FreeProcInstance(lpDlgProc);
         break;
      }

      case IDM_ICONTOBMP:
      {
         HBITMAP hBitmap;

         // obtain the file in which the resource exists
         lstrcpy((LPSTR)gszFileName, DlgOpenFile(hWnd, (LPSTR)"Open Icon File", (LPSTR)"*.ICO"));
         if (gszFileName[0] == '\0')   // if file name is empty
            break;
         hBitmap = IconToBitmap((LPSTR)gszFileName);  // create an icon form the bitmap resource
         if (hBitmap == NULL)
            break;
         lpDlgProc = MakeProcInstance(ViewIconBmpDlgProc, ghInst);
         
         // display the icon and the bitmap
         DialogBoxParam(ghInst, "ViewIconBmpDlg", hWnd, lpDlgProc, MAKELONG((WORD)hBitmap, 0));
         FreeProcInstance(lpDlgProc);
         break;
      }

      // User picked File.Exit, terminate this app.

      case IDM_EXIT:
         DestroyWindow(hWnd);
         break;

      default:
         return DefWindowProc(hWnd, message, wParam, lParam);
   }

   return (NULL);
}
