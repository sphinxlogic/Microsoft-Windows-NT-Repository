//*****************************************************************************
//* File Name : cur.c                                                         *
//* Purpose : Ruotines that read resources from files and return cursor       *
//*           handles reside here.                                            *
//* Functions : ReadCursorFile() - Calls ReadCursor and MakeCursor to read a  *
//*                                a cursor resource and create a cursor.     *
//*             ReadCursor() - Reads a cursor file and returns a handle to the*
//*                            cursor's DIB.                                  *
//*             MakeCursor() - Takes a DIB and creates a cursor.              *
//*             BitmapToCursor() - Reads a bitmap file and uses that DIB to   *
//*                                create a cursor.                           *
//*             IconToCursor() - Reads an icon file and uses that DIB to      *
//*                              create a cursor.                             *
//*             ColorDDBToMonoDDB() - Converts a color bitmap to a monochrome.*
//*                                                                           *
//* Development Team : Krishna Nareddy                                        *
//*                    Mark Bader                                             *
//*                                                                           *
//* Comments : The goal of the routines in this file is to be simple to read  *
//*            and understand, rather than to be computationally efficient.   *
//*                                                                           *
//* Written by Microsoft Product Support Services, Windows Developer Support. *
//*****************************************************************************

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <io.h>
#include "windows.h"
#include "cur.h"
#include "icon.h"
#include "bmp.h"

//*****************************************************************************
//* Function : ReadCursorFile()                                               *
//* Purpose  : Reads a cursor resource file and creates a cursor based on that*
//*            information.                                                   *
//* Parameters : LPSTR szFileName - The cursor resource file.                 *
//* Returns :  A handle to a cursor. The handle will be NULL if a cursor can't*
//*            be created for any reason.                                     *
//* Comments : See "Reference - Volume 2" for a description of the cursor file*
//* History :  Date          Author            Reason                         *
//*            2/25/92       Krishna           Created                        *
//*****************************************************************************

HCURSOR ReadCursorFile (LPSTR szFileName)
{
   HANDLE hDIB;    // Handle to DIB memory
   HCURSOR hCursor;
   POINT ptHotSpot;

   hDIB = ReadCur(szFileName, (LPPOINT)&ptHotSpot);  // read cur DIB from file
   if (hDIB == NULL)
      return NULL;

   hCursor = MakeCursor(hDIB, (LPPOINT)&ptHotSpot);  // create cur from DIB

   GlobalFree(hDIB);
   return (hCursor);
}

//*****************************************************************************
//* Function : BitmapToCursor()                                               *
//* Purpose  : Reads a bitmap resource file and creates a cursor based on that*
//*            information.                                                   *
//* Parameters : LPSTR szFileName - The bitmap resource file.                 *
//* Returns :  A handle to a cursor. The handle will be NULL if a cursor can't*
//*            be created for any reason.                                     *
//* Comments : The bitmap only provides the XOR mask for the cursor. The AND  *
//*            mask has to created by the app. at its discretion.             *
//* Steps : 1) Obtain a handle to the bitmap's DIB.                           *
//*         2) Shrink / expand the bitmap to create an XOR bitmap as the same *
//*            size as that of a cursor supported by the system.              *
//*         3) Convert the possibly color bitmap to monochrome. This is done  *
//*            because a cursor has to be monochrome.                         *
//*         4) Save the XOR bits in memory.                                   *
//*         5) Create a monochrome bitmap for the AND mask and fill it with a *
//*            pattern of your choice.                                        *
//*         6) Save the AND bits in memory.                                   *
//*         7) Use the XOR and AND masks and create a cursor with CreateCursor*
//* History :  Date          Author            Reason                         *
//*            2/25/92       Krishna           Created                        *
//*****************************************************************************

HCURSOR BitmapToCursor (LPSTR szFileName)
{
   HBITMAP hBitmap, hTmpBitmap, hXorBitmap, hAndBitmap;
   HBITMAP hOldBmp1, hOldBmp2, hOldBmp3;
   BITMAP XorBitmap, AndBitmap;
   LPSTR lpAndBits, lpXorBits;
   HANDLE hAndBits, hXorBits;
   HDC hdcSrc, hdcDst, hdc, hdcTmp;
   int iCurWidth, iCurHeight;
   HCURSOR hCursor;
   DWORD dwNumBytes;

   // 1) Obtain a handle to the bitmap's DIB.    

   hBitmap = ReadBmpFile(szFileName);
   if (hBitmap == NULL)
      return NULL;

   // Obtain the cursor's dimensions
   iCurWidth = GetSystemMetrics(SM_CXCURSOR);
   iCurHeight = GetSystemMetrics(SM_CYCURSOR);

   // create two memory DCs to shrink/expand the bitmap to fit the cursor's 
   // dimensions.  We need one DC to hold the source bitmap, and one
   // to hold the bitmap the size of the cursor.

   hdc = CreateDC("DISPLAY", NULL, NULL, NULL);
   hdcSrc = CreateCompatibleDC(hdc);       // create mem DC 
   hOldBmp1 = SelectObject(hdcSrc, hBitmap);  // select source bitmap
   hdcDst = CreateCompatibleDC(hdc);       // create another DC
   hXorBitmap = CreateCompatibleBitmap(hdc, iCurWidth, iCurHeight);   
   hOldBmp2 = SelectObject(hdcDst, hXorBitmap); // select dest. bitmap
   DeleteObject(hOldBmp1);
   DeleteObject(hOldBmp2);   
   GetObject(hBitmap, sizeof(BITMAP), (VOID FAR *)&XorBitmap);

   // 2) Shrink / expand the bitmap to create an XOR bitmap as the same
   //    size as that of a cursor supported by the system.
   StretchBlt(hdcDst, 0, 0, iCurWidth, iCurHeight, hdcSrc, 0, 0,
              XorBitmap.bmWidth, XorBitmap.bmHeight, SRCCOPY);
   DeleteDC(hdcSrc);              

   // 3) Convert the possibly color bitmap to a monochrome. This is done
   //    because the cursor has to be monochrome 
   hTmpBitmap = ColorDDBToMonoDDB(hXorBitmap);
   
   // Get the expanded/shrunk XorBitmap
   GetObject(hTmpBitmap, sizeof(BITMAP), (VOID FAR *)&XorBitmap);

   // Create storage for the set of bytes to be used as the XOR mask for the icon           
   dwNumBytes = (DWORD)(XorBitmap.bmWidthBytes * XorBitmap.bmHeight * XorBitmap.bmPlanes);
   hXorBits = GlobalAlloc(GHND, dwNumBytes);
   if (hXorBits == NULL)
   {
      // clean up before quitting
      Error(ERR_NOMEMALLOC);
      DeleteDC(hdc);      
      DeleteObject(hBitmap);
      DeleteDC(hdcDst);      
      DeleteObject(hTmpBitmap);      
      DeleteObject(hXorBitmap);      
      return NULL;
   }
   lpXorBits = GlobalLock(hXorBits);

   // 4) Save the XOR bits in memory    
   GetBitmapBits(hTmpBitmap, dwNumBytes, lpXorBits);
   DeleteObject(hTmpBitmap);   

   // 5) Create a monochrome bitmap for the AND mask and fill it with a
   //    pattern of your choice.    
   hAndBitmap = CreateBitmap(iCurWidth, iCurHeight, 1, 1, NULL);
   GetObject(hAndBitmap, sizeof(BITMAP), (VOID FAR *)&AndBitmap);
   dwNumBytes = (DWORD)(AndBitmap.bmWidthBytes * AndBitmap.bmHeight * AndBitmap.bmPlanes);
   hdcTmp = CreateCompatibleDC(hdc);
   hOldBmp3 = SelectObject(hdcTmp, hAndBitmap);
   DeleteObject(hOldBmp3);
   DeleteDC(hdc);   
   // Fill the And bitmap with all 0s.  This will make all non-zero
   // colors in our XOR bitmap show through in the original color,
   // and all zero values (black) will show through as black.  Note
   // that since we don't know which part of the bitmap to make 
   // transparent, our AND mask dosen't represent any transparency.
   PatBlt(hdcTmp, 0, 0, iCurWidth, iCurHeight, BLACKNESS);  
   hAndBits = GlobalAlloc(GHND, dwNumBytes);
   if (hAndBits == NULL)
   {
      // clean up before quitting
      Error(ERR_NOMEMALLOC);   
      GlobalUnlock(hXorBits);
      GlobalFree(hXorBits);
      DeleteDC(hdcDst);      
      DeleteDC(hdcTmp);      
      DeleteObject(hBitmap);
      DeleteObject(hAndBitmap);
      DeleteObject(hXorBitmap);         
      return NULL;
   }
   lpAndBits = GlobalLock(hAndBits);

   // 6) Save the AND bits in memory.    
   GetBitmapBits(hAndBitmap, dwNumBytes, lpAndBits);

   // 7) Use the XOR and AND masks and create a cursor with CreateCursor    
   hCursor = CreateCursor(ghInst, 0, 0, iCurWidth, iCurHeight, lpAndBits, lpXorBits);

   // Clean up before exiting.
   DeleteDC(hdcTmp);
   DeleteDC(hdcDst);      
   GlobalUnlock(hXorBits);
   GlobalFree(hXorBits);
   GlobalUnlock(hAndBits);
   GlobalFree(hAndBits);
   DeleteObject(hBitmap);
   DeleteObject(hAndBitmap);
   DeleteObject(hXorBitmap);

   return hCursor;
}

//*****************************************************************************
//* Function : IconToCursor()                                                 *
//* Purpose  : Reads an icon resource file and creates a cursor based on that *
//*            information.                                                   *
//* Parameters : LPSTR szFileName - The icon resource file.                   *
//* Returns :  A handle to a cursor. The handle will be NULL if a cursor can't*
//*            be created for any reason.                                     *
//* Comments : An icon may be in color. So, the DIB has to be forced to be    *
//*            monochrome.                                                    *
//* History :  Date          Author            Reason                         *
//*            2/25/92       Krishna           Created                        *
//*****************************************************************************

HCURSOR IconToCursor (LPSTR szFileName)
{
   HCURSOR hCursor;
   HANDLE hDIB;
   POINT ptHotSpot;

   hDIB = ReadIcon(szFileName);      // read icon file to obtain the icon DIB
   if (hDIB == NULL)
      return NULL;

   // Set the hot spot of the cursor
   ptHotSpot.x = ptHotSpot.y = 0;
   hCursor = MakeCursor(hDIB, (LPPOINT)&ptHotSpot);  // create cursor from DIB

   GlobalFree(hDIB);
   return hCursor;
}

//*****************************************************************************
//* Function : ReadCur()                                                      *
//* Purpose  : Reads a cursor resource file and extracts the DIB information. *
//* Parameters : LPSTR szFileName - The cursor resource file.                 *
//* Returns :  A handle to a DIB. The handle will be NULL if the resource file*
//*            is corrupt or if memory cannot be allocated for the DIB info.  *
//* Comments : See "Reference - Volume 2" for a description of the cursor file*
//* History :  Date          Author            Reason                         *
//*            2/25/92       Krishna           Created                        *
//*****************************************************************************

HANDLE ReadCur (LPSTR szFileName, LPPOINT lpptHotSpot)
{
   CURFILEHEADER curFileHead;     // CURSOR file header structure
   CURFILERES curFileRes;    // CURSOR file resource
   WORD cbHead, cbRes, cbBits;    // Used for reading in file
   LPBITMAPINFO lpDIB;  // Pointer to DIB memory
   int hFile; // Handle to File
   HANDLE hDIB;

   // Open and read the .ICO file header and the first ICONFILERES

   hFile = _lopen(szFileName, OF_READ);
   cbHead = _lread(hFile, (LPSTR)&curFileHead, sizeof(CURFILEHEADER));
   cbRes = _lread(hFile, (LPSTR)&curFileRes, sizeof(CURFILERES));

   if ((cbHead != sizeof(CURFILEHEADER)) || (cbRes != sizeof(CURFILERES)))
   {
      Error(ERR_BADCURHEADER);
      return NULL;
   }

   // Verify that it's an .CUR file
   if ((curFileRes.bReserved1 != 0) || (curFileHead.wResourceType != 2))
   {
      Error(ERR_BADCURRSRC);
      return NULL;
   }

   // Allocate & lock memory to read in the DIB
   hDIB = GlobalAlloc(GHND, curFileRes.dwDIBSize);
   if (hDIB == NULL)
   {
      Error(ERR_NOMEMALLOC);
      return NULL;
   }
   lpDIB = (LPBITMAPINFO)GlobalLock(hDIB);

   // Now read the DIB portion of the file, which follows the 
   // end of icon resource table
   _llseek(hFile, curFileRes.dwDIBOffset, 0);
   cbBits = _lread(hFile, (LPSTR)lpDIB, (WORD)curFileRes.dwDIBSize);

   // Done reading file
   _lclose(hFile);

   if ((DWORD)cbBits != curFileRes.dwDIBSize)
   {
      GlobalUnlock(hDIB);
      GlobalFree(hDIB);
      return NULL;
   }
   if (lpptHotSpot != NULL)  // If it is necessary to know the hot spot
   {
      lpptHotSpot->x = (int)curFileRes.wXHotspot;
      lpptHotSpot->y = (int)curFileRes.wYHotspot;
   }
   GlobalUnlock(hDIB);
   return (hDIB);
}

//*****************************************************************************
//* Function : ColorDDBToMonoDDB()                                            *
//* Purpose  : Converts a color bitmap to a monochrome bitmap.                *
//* Parameters : HBITMAP hbm - The color bitmap.                              *
//* Returns :  A handle to a monochrome bitmap.                               *
//* Comments :                                                                *
//* History :  Date          Author            Reason                         *
//*            ???           ???               Created (Adapted from ShowDib) *
//*            2/25/92       Krishna           Modified to suit my needs      *
//*****************************************************************************

HBITMAP ColorDDBToMonoDDB (HBITMAP hbm)
{
   BITMAP bm;
   BITMAPINFOHEADER bi;
   LPBITMAPINFOHEADER lpbi;
   DWORD dwLen;
   HANDLE hdib;
   HANDLE h;
   HDC hdc;
   HBITMAP hbmMono;

   GetObject(hbm, sizeof(bm), (LPSTR)&bm);

   bi.biSize = sizeof(BITMAPINFOHEADER);        // size of this structure
   bi.biWidth = bm.bmWidth;                     // bitmap width in pixels
   bi.biHeight = bm.bmHeight;                   // bitmap height in pixels
   bi.biPlanes = 1;                             // # of planes always 1 for DIBs
   bi.biBitCount = bm.bmPlanes * bm.bmBitsPixel; // color bits per pixel
   bi.biCompression = BI_RGB;                   // no compression
   bi.biSizeImage = 0;                          // 0 means default size
   bi.biXPelsPerMeter = 0;                      // not used by my app
   bi.biYPelsPerMeter = 0;                      // not used by my app
   bi.biClrUsed = 0;                            // 0 means default colors
   bi.biClrImportant = 0;                       // 0 means defaults

   dwLen = bi.biSize + PaletteSize((LPSTR)&bi);

   hdc = GetDC(NULL);

   hdib = GlobalAlloc(GHND, dwLen);

   if (hdib == NULL)
   {
      Error(ERR_NOMEMALLOC);
      ReleaseDC(NULL, hdc);
      return NULL;
   }

   lpbi = (VOID FAR *)GlobalLock(hdib);
   *lpbi = bi;

   // Call GetDIBits with a NULL lpBits parameter; it will calculate
   // the biSizeImage field.
   GetDIBits(hdc, hbm, 0, (WORD)bi.biHeight,
             NULL, (LPBITMAPINFO)lpbi, DIB_RGB_COLORS);

   bi = *lpbi;
   GlobalUnlock(hdib);

   // If the driver did not fill in the biSizeImage field, make one up.
   if (bi.biSizeImage == 0)
      bi.biSizeImage = WIDTHBYTES((DWORD)bm.bmWidth * bi.biBitCount) * bm.bmHeight;

   // Reallocate the buffer big enough to hold all the bits.
   dwLen = bi.biSize + PaletteSize((LPSTR)&bi) + bi.biSizeImage;
   if ((h = GlobalReAlloc(hdib, dwLen, 0)))
      hdib = h;
   else
   {
      GlobalFree(hdib);
      ReleaseDC(NULL, hdc);
      return NULL;
   }

   // Call GetDIBits with a NON-NULL lpBits parameter, to actually
   // get the bits this time.
   lpbi = (VOID FAR *)GlobalLock(hdib);

   if (GetDIBits(hdc, hbm, 0, (WORD)bi.biHeight,
                 (LPSTR)lpbi + (WORD)lpbi->biSize + PaletteSize((LPSTR)lpbi),
                 (LPBITMAPINFO)lpbi, DIB_RGB_COLORS) == 0)
   {
      GlobalUnlock(hdib);
      hdib = NULL;
      ReleaseDC(NULL, hdc);
      return NULL;
   }

   // Finally, create a monochrome DDB, and put the DIB into
   // it. SetDIBits does smart color conversion.
   hbmMono = CreateBitmap((WORD)lpbi->biWidth, (WORD)lpbi->biHeight, 1, 1, NULL);
   SetDIBits(hdc, hbmMono, (WORD)0, (WORD)lpbi->biHeight,
             (LPSTR)lpbi + lpbi->biSize + PaletteSize((LPSTR)lpbi),
             (LPBITMAPINFO)lpbi, DIB_RGB_COLORS);

   bi = *lpbi;
   GlobalUnlock(hdib);
   GlobalFree(hdib);

   ReleaseDC(NULL, hdc);
   return hbmMono;
}

//*****************************************************************************
//* Function : MakeCursor()                                                   *
//* Purpose  : Creates a cursor based on the DIB info. returned by ReadCursor.*
//* Parameters : HANDLE hDIB - A handle to the cursor's DIB information.      *
//*              LPPOINT lppt - A pointer to a point struct. indicating the   *
//*                             location of the Cursor's hot spot.            *
//* Returns :  A handle to a cursor. NULL is returned if a cursor cannot be   *
//*            successfully created.                                          *
//* Comments : The steps involved in making a cursor from a DIB are very      *
//*            similar to those involved in making an icon from a DIB.        *
//* Steps : 1) Obtain a pointer to the Cursor's DIB bits.                     *
//*         2) Divide the DIB's height with 2 to account for the fact that the*
//*            DIB stores both the XOR and the AND masks, one after the other.*
//*         3) Determine the offset to the XOR bits.                          *
//*         4) Determine the offset to the AND bits.                          *
//*         5) Create a device dependent bitmap with the XOR bits.            *
//*         6) Obtain the device dependent XOR bitmask and save in memory.    *
//*            The AND bitmask is monochrome. Monochrome bits are identical   *
//*            in both the device dependent bitmaps and device independent    *
//*            bitmaps. So, no need to convert the AND bitmask.               *
//*         7) Since a DIB is stored upside down, flip the monochrome AND bits*
//*            by scanlines.                                                  *
//*         8) Use the XOR and AND bits and create a cursor with CreateCursor.* 
//* History :  Date          Author            Reason                         *
//*            2/25/92       Krishna           Created                        *
//*****************************************************************************

HCURSOR MakeCursor (HANDLE hDIB, LPPOINT lpptHotSpot)
{
   LPSTR lpXORbits, lpANDbits;    // Pointer to XOR and AND bits
   HBITMAP hbmXor; // handle to XOR bitmap
   BITMAP bmpXor;  // Used to manipulate XOR bitmap    
   DWORD dwBmpSize;     // Size of XOR bitmap
   HCURSOR hCursor;
   HANDLE hXorDDB;
   LPSTR lpXorDDB;
   LONG szFlip[32];
   int j, k;
   HDC hDC;
   LPBITMAPINFO lpDIB;

   // 1) Obtain a pointer to the Cursor's DIB bits.    

   lpDIB = (LPBITMAPINFO)GlobalLock(hDIB);

   // 2) Divide the DIB's height with 2 to account for the fact that the
   //    DIB stores both the XOR and the AND masks, one after the other.
   lpDIB->bmiHeader.biHeight /= 2;

   // 3) Determine the offset to the XOR bits.     
   //    To obtain this value, we have to skip the header, and color table
   lpXORbits = (LPSTR)lpDIB + lpDIB->bmiHeader.biSize +
               (DIBNumColors((LPSTR)lpDIB) * sizeof(RGBQUAD));

   // 4) Determine the offset to the AND bits
   //    To obtain this value, skip the XOR bits
   lpANDbits = lpXORbits + lpDIB->bmiHeader.biHeight *
               (WIDTHBYTES (lpDIB->bmiHeader.biWidth * lpDIB->bmiHeader.biBitCount));

   // Get a hDC so we can create a bitmap compatible with it
   hDC = CreateDC("DISPLAY", NULL, NULL, NULL);

   // 5) Create a device dependent bitmap with the XOR bits.
   hbmXor = CreateBitmap((int)lpDIB->bmiHeader.biWidth,
                         (int)lpDIB->bmiHeader.biHeight, 1, 1, NULL);
   SetDIBits(hDC, hbmXor, 0, (WORD)lpDIB->bmiHeader.biHeight, lpXORbits, lpDIB, DIB_RGB_COLORS);
   GetObject(hbmXor, sizeof(BITMAP), (LPSTR)&bmpXor);

   dwBmpSize = (DWORD)(bmpXor.bmWidthBytes * bmpXor.bmHeight * bmpXor.bmPlanes);
   hXorDDB = GlobalAlloc(GHND, dwBmpSize);
   if (hXorDDB == NULL)
   {
      // clean up before quitting
      Error(ERR_NOMEMALLOC);
      DeleteObject(hbmXor);
      DeleteDC(hDC);
      GlobalUnlock(hDIB);      
      return NULL;
   }
   lpXorDDB = GlobalLock(hXorDDB);

   // 6) Obtain the device dependent XOR bitmask and save in memory.
   //    The AND bitmask is monochrome. Monochrome bits are identical
   //    in both the device dependent bitmaps and device independent
   //    bitmaps. So, no need to convert the AND bitmask.   
   GetBitmapBits(hbmXor, dwBmpSize, lpXorDDB);

   // 7) Since a DIB is stored upside down, flip the monochrome AND bits by scanlines.
   k = (int)lpDIB->bmiHeader.biHeight;
   for (j = 0; j < k; j++, lpANDbits += sizeof(DWORD))
      szFlip[(k - 1) - j] = *(DWORD FAR *)lpANDbits;

   // 8) Use the XOR and AND bits and create a cursor with CreateCursor.
   hCursor = CreateCursor(ghInst, lpptHotSpot->x, lpptHotSpot->y,
                          bmpXor.bmWidth, bmpXor.bmHeight, (LPSTR)szFlip, lpXorDDB);

   // Clean up before exiting.                          
   DeleteObject(hbmXor);
   GlobalUnlock(hXorDDB);
   GlobalFree(hXorDDB);
   DeleteDC(hDC);
   GlobalUnlock(hDIB);

   return hCursor;
}
