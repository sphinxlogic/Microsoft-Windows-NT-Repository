//*-------------------------------------------------------------------------
//| Title:
//|     ABOUT.C
//|
//| Contents:
//|     AboutBox ()
//*-------------------------------------------------------------------------

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <WINDOWS.H>
#include "HitTest.h"
#include "GLOBALS.H"

BOOL FAR PASCAL AboutBox (HWND hDlg,
                          WORD message,
                          WORD wParam,
                          LONG lParam)
{

    switch (message) 
    {

        case WM_INITDIALOG:
           {
             return (TRUE);
           }
  
        case WM_COMMAND:
            if (wParam == IDOK  || wParam == IDCANCEL) 
            {
                EndDialog(hDlg, TRUE);
                return (TRUE);
            }
            break;
            
    }
    return (FALSE);
}



void near PASCAL InitDlg (HWND hDlg, LPSTR szIconName, int iStart, int iEnd)
{
   char  szTemp[40];
   int   wIndex;


   lstrcpy (szTemp, "About ");
   lstrcat (szTemp, szIconName);

   SetWindowText (hDlg, szTemp);

   for (wIndex = iStart; wIndex <= iEnd; wIndex++)
   { 
     LoadString (ghInstance, wIndex, szTemp, sizeof(szTemp)) ;
     SetDlgItemText (hDlg, ID_STATIC1 + wIndex - iStart, szTemp);
   }

}


void DrawTransparentBitmap(HDC hdc, HBITMAP hBitmap, short xStart,
                           short yStart, COLORREF cTransparentColor)
   {
   BITMAP     bm;
   COLORREF   cColor;
   HBITMAP    bmAndBack, bmAndObject, bmAndMem, bmSave;
   HBITMAP    bmBackOld, bmObjectOld, bmMemOld, bmSaveOld;
   HDC        hdcMem, hdcBack, hdcObject, hdcTemp, hdcSave;
   POINT      ptSize;

   hdcTemp = CreateCompatibleDC(hdc);
   SelectObject(hdcTemp, hBitmap);   // Select the bitmap

   GetObject(hBitmap, sizeof(BITMAP), (LPSTR)&bm);
   ptSize.x = bm.bmWidth;            // Get width of bitmap
   ptSize.y = bm.bmHeight;           // Get height of bitmap
   DPtoLP(hdcTemp, &ptSize, 1);      // Convert from device
                                     // to logical points

   // Create some DCs to hold temporary data.
   hdcBack   = CreateCompatibleDC(hdc);
   hdcObject = CreateCompatibleDC(hdc);
   hdcMem    = CreateCompatibleDC(hdc);
   hdcSave   = CreateCompatibleDC(hdc);

   // Create a bitmap for each DC. DCs are required for a number of
   // GDI functions.

   // Monochrome DC
   bmAndBack   = CreateBitmap(ptSize.x, ptSize.y, 1, 1, NULL);

   // Monochrome DC
   bmAndObject = CreateBitmap(ptSize.x, ptSize.y, 1, 1, NULL);

   bmAndMem    = CreateCompatibleBitmap(hdc, ptSize.x, ptSize.y);
   bmSave      = CreateCompatibleBitmap(hdc, ptSize.x, ptSize.y);

   // Each DC must select a bitmap object to store pixel data.
   bmBackOld   = SelectObject(hdcBack, bmAndBack);
   bmObjectOld = SelectObject(hdcObject, bmAndObject);
   bmMemOld    = SelectObject(hdcMem, bmAndMem);
   bmSaveOld   = SelectObject(hdcSave, bmSave);

   // Set proper mapping mode.
   SetMapMode(hdcTemp, GetMapMode(hdc));

   // Save the bitmap sent here, because it will be overwritten.
   BitBlt(hdcSave, 0, 0, ptSize.x, ptSize.y, hdcTemp, 0, 0, SRCCOPY);

   // Set the background color of the source DC to the color.
   // contained in the parts of the bitmap that should be transparent
   cColor = SetBkColor(hdcTemp, cTransparentColor);

   // Create the object mask for the bitmap by performing a BitBlt
   // from the source bitmap to a monochrome bitmap.
   BitBlt(hdcObject, 0, 0, ptSize.x, ptSize.y, hdcTemp, 0, 0,
          SRCCOPY);

   // Set the background color of the source DC back to the original
   // color.
   SetBkColor(hdcTemp, cColor);

   // Create the inverse of the object mask.
   BitBlt(hdcBack, 0, 0, ptSize.x, ptSize.y, hdcObject, 0, 0,
          NOTSRCCOPY);

   // Copy the background of the main DC to the destination.
   BitBlt(hdcMem, 0, 0, ptSize.x, ptSize.y, hdc, xStart, yStart,
          SRCCOPY);

   // Mask out the places where the bitmap will be placed.
   BitBlt(hdcMem, 0, 0, ptSize.x, ptSize.y, hdcObject, 0, 0, SRCAND);

   // Mask out the transparent colored pixels on the bitmap.
   BitBlt(hdcTemp, 0, 0, ptSize.x, ptSize.y, hdcBack, 0, 0, SRCAND);

   // XOR the bitmap with the background on the destination DC.
   BitBlt(hdcMem, 0, 0, ptSize.x, ptSize.y, hdcTemp, 0, 0, SRCPAINT);

   // Copy the destination to the screen.
   BitBlt(hdc, xStart, yStart, ptSize.x, ptSize.y, hdcMem, 0, 0,
          SRCCOPY);

   // Place the original bitmap back into the bitmap sent here.
   BitBlt(hdcTemp, 0, 0, ptSize.x, ptSize.y, hdcSave, 0, 0, SRCCOPY);

   // Delete the memory bitmaps.
   DeleteObject(SelectObject(hdcBack, bmBackOld));
   DeleteObject(SelectObject(hdcObject, bmObjectOld));
   DeleteObject(SelectObject(hdcMem, bmMemOld));
   DeleteObject(SelectObject(hdcSave, bmSaveOld));

   // Delete the memory DCs.
   DeleteDC(hdcMem);
   DeleteDC(hdcBack);
   DeleteDC(hdcObject);
   DeleteDC(hdcSave);
   DeleteDC(hdcTemp);
   }


BOOL FAR PASCAL GenericAboutBox (HWND hDlg,
                                 WORD message,
                                 WORD wParam,
                                 LONG lParam)
{
    #define BACK_COLOR     RGB (  0,  0,  0)
    #define TEXT_COLOR     RGB (255,255,255)

    static HBITMAP hBmp;
    static HBRUSH  hBackBrush;


    switch (message) 
    {
        case WM_INITDIALOG:
           {
            char szTemp [40];
            LPPASSITEMSTRUCT lppis;    // pointer to structure passed
                                       // to DialogBoxParam()

            lppis = (LPPASSITEMSTRUCT)lParam;
            hBackBrush  = GetStockObject (BLACK_BRUSH);

            InitDlg (hDlg, lppis->szItemString, 
                           lppis->iStrTableStart, 
                           lppis->iStrTableEnd);

            lstrcpy (szTemp,lppis->szItemString);
            lstrcat (szTemp, "Bmp");
            hBmp    = LoadBitmap (ghInstance, szTemp);

            return (TRUE);
           }

        case WM_PAINT:
           {
             PAINTSTRUCT ps;
             HDC         hDC;

             hDC = BeginPaint (hDlg, &ps);
             DrawTransparentBitmap(hDC,         // The destination DC.
                                   hBmp,        // The bitmap to be drawn.
                                   20,          // X coordinate.
                                   20,          // Y coordinate.
                                   0x00000000); // The color for transparent
                                                // pixels (white, in this
                                                // example).

             EndPaint (hDlg, &ps);
           } 
            break;

        case WM_CTLCOLOR:
              if ((HIWORD (lParam) == CTLCOLOR_DLG) ||
                  (HIWORD (lParam) == CTLCOLOR_STATIC))
              {
                   UnrealizeObject( hBackBrush );
                   SelectObject((HDC)wParam, hBackBrush );
                   SetBrushOrg ((HDC)wParam, 0 , 0      );
                   SetBkMode   ((HDC)wParam, TRANSPARENT);
                   SetBkColor  ((HDC)wParam, BACK_COLOR );
                   SetTextColor((HDC)wParam, TEXT_COLOR );

                   return (BOOL)hBackBrush;
             }
             else if (HIWORD (lParam) == CTLCOLOR_BTN)
                return (GetStockObject (BLACK_BRUSH));
             else 
                return (HBRUSH)NULL;

 

        case WM_COMMAND:
            if (wParam == IDOK  || wParam == IDCANCEL) 
            {
                DeleteObject (hBmp);
                EndDialog(hDlg, TRUE);
                return (TRUE);
            }
            break;
            
    }
    return (FALSE);
}


