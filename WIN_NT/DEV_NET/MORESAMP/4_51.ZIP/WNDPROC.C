//*-------------------------------------------------------------------------
//| Title:
//|     WNDPROC.C
//|
//| Contents:
//|     MainWndProc()
//*-------------------------------------------------------------------------

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <WINDOWS.H>
#include "WNDPROC.H"
#include "HitTest.h"
#include "GLOBALS.H"
#define TOTNUMITEMS 12             // Total Number of Icons displayed


typedef struct tagITEMSTRUCT
      {
        char szItemString[10];
        int   x, y;
        HICON hIcon;
      } ITEMSTRUCT;



#define TOTNUMITEMS 12            // Total Number of Icons displayed
ITEMSTRUCT is[TOTNUMITEMS];       // defines a global array 
                                  // to hold information for every icon

int curIndex   = -1;              // save Currently selected icon
int curClicked = -1;              // save Currently CLICKED icon
int gtmHeight;                    // save tm.tmHeight in a global

/***********************************************************************
 * Title      : FillPassItemStruct (WORD wIndex)
 *                                                                            
 * Parameters : WORD wIndex - index to the ITEMSTRUCT array
 *                                                             
 * Description: Fills in all 4 fields of the ITEMSTRUCT
 **********************************************************************/
void near PASCAL FillPassItemStruct (WORD wIndex, LPPASSITEMSTRUCT lppis)
{

  lstrcpy (lppis->szItemString, is[wIndex].szItemString);

   switch (wIndex)
  {
      case ID_BLANDMDI:  
        lppis->iStrTableStart = IDS_BLANDMDISTART;
        lppis->iStrTableEnd   = IDS_BLANDMDIEND;
        break;

      case ID_DIBVIEW:  
        lppis->iStrTableStart = IDS_DIBVIEWSTART;
        lppis->iStrTableEnd   = IDS_DIBVIEWEND;
        break;

      case ID_FONTEST:  
        lppis->iStrTableStart = IDS_FONTESTSTART;
        lppis->iStrTableEnd   = IDS_FONTESTEND;
        break;

      case ID_MAKEAPP:  
        lppis->iStrTableStart = IDS_MAKEAPPSTART;
        lppis->iStrTableEnd   = IDS_MAKEAPPEND;
        break;

      case ID_MCITEST:  
        lppis->iStrTableStart = IDS_MCITESTSTART;
        lppis->iStrTableEnd   = IDS_MCITESTEND;
        break;

      case ID_MUSCROLL:  
        lppis->iStrTableStart = IDS_MUSCROLLSTART;
        lppis->iStrTableEnd   = IDS_MUSCROLLEND;
        break;

      case ID_ICON:  
        lppis->iStrTableStart = IDS_ICONSTART;
        lppis->iStrTableEnd   = IDS_ICONEND;
        break;

      case ID_OWNCOMBO:  
        lppis->iStrTableStart = IDS_OWNCOMBOSTART;
        lppis->iStrTableEnd   = IDS_OWNCOMBOEND;
        break;

      case ID_PENPAD:  
        lppis->iStrTableStart = IDS_PENPADSTART;
        lppis->iStrTableEnd   = IDS_PENPADEND;
        break;

      case ID_PALETTE:  
        lppis->iStrTableStart = IDS_PALETTESTART;
        lppis->iStrTableEnd   = IDS_PALETTEEND;
        break;

     case ID_SHOWGDI:  
        lppis->iStrTableStart = IDS_SHOWGDISTART;
        lppis->iStrTableEnd   = IDS_SHOWGDIEND;
        break;

      case ID_XTENSION:  
        lppis->iStrTableStart = IDS_XTENSIONSTART;
        lppis->iStrTableEnd   = IDS_XTENSIONEND;
        break;

      default: break;
  }


    
}

/***********************************************************************
 * Title      : FillItemStruct (WORD wIndex)
 *                                                                            
 * Parameters : WORD wIndex - index to the ITEMSTRUCT array
 *                                                             
 * Description: Fills in all 4 fields of the ITEMSTRUCT
 **********************************************************************/
void near PASCAL FillItemStruct (WORD wIndex, RECT rect)
{
   int  cxIcon = GetSystemMetrics (SM_CXICON);
   int  cyIcon = GetSystemMetrics (SM_CYICON);


  /*
   *  Fills in the szItemString field of the ITEMSTRUCT
   */
  LoadString (ghInstance, IDS_ICONNAMEFIRST + wIndex, 

              is[wIndex].szItemString, sizeof(is[wIndex].szItemString)) ;
  /*
   *  Fills in the x and y fields of the ITEMSTRUCT
   */
  if (wIndex < TOTNUMITEMS/2)
   {
     is[wIndex].x = rect.left + cxIcon * (1 +  2*(wIndex));
     is[wIndex].y = rect.top  + cyIcon;
   }
   else
   {
     is[wIndex].x = rect.left + cxIcon * (1 +  2*(wIndex -(TOTNUMITEMS/2)));
     is[wIndex].y = rect.top  + 3*cyIcon;
   }

  is[wIndex].hIcon = LoadIcon (ghInstance, is[wIndex].szItemString);
}


/***********************************************************************
 * Title      : DrawItemText
 *                                                                            
 * Parameters : hDC - handle to the DeviceContext
 *                    We'll need this for DrawText() later.                    
 *              wIndex - index to the ITEMSTRUCT structure
 *              bInvert- whether or not the text is highlighted
 *                                                             
 * Description: Draws the text under the icon
 **********************************************************************/

void near PASCAL DrawItemText (HDC hDC, WORD wIndex, BOOL bInvert)
{
   RECT       textRect;
   COLORREF   crBkColor, crTxtColor;

   int  cxIcon = GetSystemMetrics (SM_CXICON);
   int  cyIcon = GetSystemMetrics (SM_CYICON);



   textRect.left  = is[wIndex].x  - cxIcon/2;
   textRect.top   = is[wIndex].y  + cyIcon;
   textRect.right = textRect.left + 2*cxIcon;    
   textRect.bottom= textRect.top  + gtmHeight;

   if (bInvert)
     {
       crBkColor = SetBkColor  (hDC, GetSysColor (COLOR_HIGHLIGHT));
       crTxtColor= SetTextColor(hDC, GetSysColor (COLOR_HIGHLIGHTTEXT)); 
     }

   DrawText (hDC, is[wIndex].szItemString, lstrlen (is[wIndex].szItemString),
             &textRect, DT_CENTER);

   if (bInvert)
     {
       SetBkColor  (hDC, crBkColor );
       SetTextColor(hDC, crTxtColor); 
     }
}


/***********************************************************************
 * Title      : FindWhichIconGotClicked (int xPos, int yPos)
 *                                                                            
 * Parameters : xPos - x coordinate of the cursor
 *              yPos - y coordinate of the cursor
 *                                                             
 * Description: Determines which icon received got clicked
 **********************************************************************/
int near PASCAL FindWhichIconGotClicked (int xPos, int yPos)
{
   int   wIndex = -1;
   int   xTmp, yTmp;
   int   cxIcon = GetSystemMetrics (SM_CXICON);
   int   cyIcon = GetSystemMetrics (SM_CYICON);


   xTmp = xPos / cxIcon;
   if (xTmp % 2)             // if you get an ODD number, (ie Remainder <> 0)
     wIndex = xTmp / 2;      // BINGO! an icon got clicked!!
   else
     return (-1);            // else. no icon got clicked. (return -1)


   yTmp = yPos / cyIcon;
   if (yTmp > 4)             
     return -1;

   if (yTmp % 2)             // if ODD number, (ie Remainder <> 0) icon clicked.
    {
      if (yTmp == 1)
        return (wIndex);
      else 
        return (wIndex + (TOTNUMITEMS/2));
    }
   else                      // if EVEN number, icon NOT clicked
   {
     if (yTmp == 0) return -1;

     if (yPos <= (yTmp*cyIcon + gtmHeight))      // Check if clicked on text
     {
      if (yTmp == 2)
        return (wIndex);
      else 
        return (wIndex + (TOTNUMITEMS/2));
     }  
   }

   return (-1);              // all else failed, return -1
}


//*-------------------------------------------------------------------------
//| Title:
//|     MainWndProc
//|
//| Parameters:
//|     hWnd            - Handle to the message's destination window
//|     wMessage        - Message number of the current message
//|     wParam          - Additional info associated with the message
//|     lParam          - Additional info associated with the message
//|
//| Purpose:
//|     This is the window procedure for the application's main window.
//*-------------------------------------------------------------------------
LRESULT FAR PASCAL MainWndProc(HWND    hWnd,       
                               UINT    wMessage,   
                               WPARAM  wParam,     
                               LPARAM  lParam)     
{
    static HDC      hMemoryDC;        // MemoryDC Stuff
    static COLORREF crBkColor;
    static HFONT    hOldFont;
    static HBITMAP  hOldBmp, hNewBmp;

    static RECT     wndRect;
    static PASSITEMSTRUCT pis;        // structure to be passed
                                      // to DialogBoxParam()
    switch (wMessage)
        {

        /* 
         * All nasty initialization stuff goes here.
         */
        case WM_CREATE:
          {
             int  i;
             TEXTMETRIC tm;
             HDC  hDC;

             GetClientRect (hWnd, &wndRect);

             hDC = GetDC (hWnd);

             GetTextMetrics (hDC, &tm);
             gtmHeight = tm.tmHeight;   // save in global for later.

             hMemoryDC = CreateCompatibleDC (hDC);

             /*
              * Create a bitmap as big as the main window's 
              * client area, and select into that memory DC.
              */
             hNewBmp   = CreateCompatibleBitmap (hDC, wndRect.right,
                                                      wndRect.bottom);
             hOldBmp   = SelectObject (hMemoryDC, hNewBmp);


             crBkColor = SetBkColor  (hMemoryDC, 
                                      MYBACKGROUNDCOLOR);
             FillRect (hMemoryDC, &wndRect, 
                      (HBRUSH)GetClassWord (hWnd, GCW_HBRBACKGROUND));

             hOldFont = SelectObject (hMemoryDC, GetStockObject (ANSI_VAR_FONT));

             for (i=0; i<TOTNUMITEMS; i++)
             {
                FillItemStruct (i, wndRect);


                /* Calling DrawIcon() directly to the screen's DC is slow,
                 * We then need to draw everything into a memory DC first,
                 * and do a BitBlt() later in the WM_PAINT case.
                 * to speed up painting.
                 */
                DrawIcon (hMemoryDC, is[i].x, is[i].y, is[i].hIcon);
                DrawItemText (hMemoryDC, i, FALSE);
            }

             ReleaseDC (hWnd, hDC);

          }
             break;                                

      /*
       * In order to make life much easier, we want to limit
       * the size of the window, that way we don't need to
       * move the icons around.
       */

       case WM_GETMINMAXINFO:
          {
            MINMAXINFO FAR* lpmmi;

            lpmmi = (MINMAXINFO FAR*)lParam;
            lpmmi->ptMinTrackSize.x = maxWidth;
            lpmmi->ptMinTrackSize.y = maxHeight;
            lpmmi->ptMaxTrackSize.x = maxWidth;
            lpmmi->ptMaxTrackSize.y = maxHeight;
          }
          break;

        case WM_LBUTTONDBLCLK:
          {
             FARPROC lpProcAbout;

             if (curClicked == -1) break;

             FillPassItemStruct (curIndex, &pis);    // Fill that piece of memory
                                                     // with valuable info
                                                     // we want to pass DialogBoxParam()
             lpProcAbout = MakeProcInstance(GenericAboutBox, ghInstance);
             DialogBoxParam(ghInstance,
                            "GenericAboutBox",
                            hWnd,
                            lpProcAbout,
                            (LPARAM)(LPPASSITEMSTRUCT)&pis);

              FreeProcInstance(lpProcAbout);
          }

             return 0L;

        case WM_LBUTTONDOWN:
          {
             HDC    hDC;
             HFONT  hOldFont;

             curClicked = FindWhichIconGotClicked (LOWORD (lParam), 
                                                   HIWORD (lParam));
             if (curClicked == -1)  // None got clicked.
                return 0L;

             hDC = GetDC (hWnd);

             hOldFont = SelectObject (hDC, GetStockObject (ANSI_VAR_FONT));
             if (curIndex != -1)
             {
               COLORREF crBkColor;

               crBkColor = SetBkColor  (hDC, MYBACKGROUNDCOLOR);
               DrawItemText(hDC, curIndex, FALSE);     // Deselect curIndex
               SetBkColor  (hDC, crBkColor);           // Restore BkColor
             }

             curIndex = curClicked;
             DrawItemText (hDC, curIndex, TRUE);

             SelectObject (hDC, hOldFont);
             ReleaseDC (hWnd, hDC);
          }
             return 0L;
             

        case WM_PAINT:
          {
             HDC  hDC;
             PAINTSTRUCT ps;
             HFONT hOldFont;

             hDC = BeginPaint (hWnd, &ps);

             BitBlt (hDC, 0,0, wndRect.right, wndRect.bottom, 
                     hMemoryDC, 0,0, SRCCOPY);

             hOldFont = SelectObject (hDC, GetStockObject (ANSI_VAR_FONT));
             DrawItemText (hDC, curIndex, TRUE);
             SelectObject (hDC, hOldFont);


             EndPaint (hWnd, &ps);
          }

            return 0L;

        case WM_COMMAND:
        {
            FARPROC lpProcAbout;

            if (wParam == IDM_ABOUT) {
                lpProcAbout = MakeProcInstance(AboutBox, ghInstance);

                DialogBox(ghInstance,
                    "AboutBox",
                    hWnd,
                    lpProcAbout);

                FreeProcInstance(lpProcAbout);
                break;
            }
            else
                return (LRESULT)(DefWindowProc(hWnd, wMessage, wParam, lParam));
        }

        case WM_DESTROY:          // sent when window about to be destroyed

            SelectObject (hMemoryDC, hOldFont);    // restore MemDC's font
            SetBkColor   (hMemoryDC, crBkColor);   // restore MemDC's BkColor
            DeleteObject (SelectObject (hMemoryDC, hOldBmp));

            DeleteDC (hMemoryDC);                  // Delete MemDC


            PostQuitMessage(0);   // Indicate that message loop should exit
            break;                //   since the main window is being destroyed

        default:                  // Pass message on for default proccessing
            return (LRESULT)DefWindowProc(hWnd, wMessage, wParam, lParam);
        }

    // If we performed non-default processing on the message, return FALSE
    return (LRESULT)FALSE;
}


