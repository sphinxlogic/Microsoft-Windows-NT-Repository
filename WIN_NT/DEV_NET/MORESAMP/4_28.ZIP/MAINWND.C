//****************************************************************************
// File: mainwnd.c
//
// Purpose: 
//    Main overlapped window's message handler
//
// Functions:
//    MainWndProc() - message handler for main overlapped window
//    DoCommands() - called by MainWndProc to handle all WM_COMMAND messages
//    AboutDlgProc() - Dialog proc for the About Dialog box
//
// Development Team:    
//   DavidFl and MSS
//
//
// Written by Microsoft Product Support Services, Windows Developer Support
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//****************************************************************************

#include <windows.h>
#include "handle.h"

// The following #define is used by HANDLE.H -- it tells it that we
// want the globals _declared_ in this module. 
// #define IN_INIT

// Local function prototypes.
long DoCommands (HWND, UINT, WORD, LONG);

BOOL (FAR PASCAL *lpfnIsLocalHandle)(WORD, HANDLE);
BOOL (FAR PASCAL *lpfnIsGlobalHandle)(HANDLE);
WORD wHeap;              //global handle to the local heap


//****************************************************************************
// Function: MainWndProc
//
// Purpose: 
//   Message handler for main overlapped window.
//
// Parameters:
//   hWnd    == Handle to _this_ window.
//   message == Message to process.
//   wParam  == WORD parameter -- depends on message
//   lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//       Date         Author                  Reason
//       6/23/92      DavidFl                Created
//       6/23/92       MSS                    Modified to code standards
//****************************************************************************

long FAR PASCAL MainWndProc (HWND hWnd,
                             UINT message,
                             WPARAM wParam,
                             LPARAM lParam)
{
   static HANDLE hIsHandleDLL;

   switch (message)
   {   
      case WM_CREATE:
         if ((hIsHandleDLL = LoadLibrary((LPSTR)"ISHANDLE.DLL")) < 32)
            return -1;  
            
         // get the function pointers from the IsHandle DLL           
         lpfnIsLocalHandle = GetProcAddress(hIsHandleDLL, 
             (LPCSTR)"IsLocalHandle");
         lpfnIsGlobalHandle = GetProcAddress(hIsHandleDLL,
             (LPCSTR)"IsGlobalHandle");

         // Get this app's selector to the heap.
         // Can't use hInst b'cos in Windows 3.0 hInst is NOT guaranteed 
         // to be the DS always
         _asm mov ax, ds
         _asm mov wHeap, ax
         
         break;
   
      // Dispatch WM_COMMAND messages to our command handler, DoCommands().
      case WM_COMMAND:
         return DoCommands(hWnd, message, wParam, lParam);


      // On WM_DESTROY, free the library if loaded successfully, before
      // quitting the app.

      case WM_DESTROY:
         if (hIsHandleDLL > 32)
            FreeLibrary(hIsHandleDLL);
         PostQuitMessage(0);
         break;

      // We didn't handle, pass to DefWindowProc.
      default:
         return DefWindowProc(hWnd, message, wParam, lParam);
   }

   return (NULL);
}

//****************************************************************************
// Function: DoCommands
//
// Purpose: 
//    Called by MainWndProc() to handle all WM_COMMAND messages.
//
// Parameters:
//    hWnd    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns : Depends on message.
//
// Comments:
//
// History:  Date       Author                  Reason
//                      DavidFl                 Created
//           6/23/92     MSS                    Modified
//****************************************************************************

long DoCommands (HWND hWnd,
                 UINT message,
                 WORD wParam,
                 LONG lParam)
{
   HANDLE hLocal;            
   HANDLE hGlobal;
   char lpLocalTest[] = "Local Handle Test";   
   char lpGlobalTest[] = "Global Handle Test";   
    
   switch (wParam)
   {   
         case IDM_GOODHANDLE:
          // Allocate a valid local memory object and check its
          // local handle using the new API on local handles
          
          if (hLocal = LocalAlloc(LMEM_MOVEABLE, 16))
          {
            if (lpfnIsLocalHandle(wHeap, hLocal))
               MessageBox(GetFocus(), (LPSTR)"Worked! Good handle",
                   lpLocalTest, MB_OK);
            else
               MessageBox(GetFocus(), (LPSTR)"Failed! Bad Handle", 
                   lpLocalTest, MB_OK);

             hLocal = LocalFree(hLocal);
          }
          else 
            MessageBox(ghWnd, (LPSTR)"LocalAlloc Failed", 
                   lpLocalTest, MB_OK);
          
          break;

          case IDM_BADHANDLE:
            // Test our API on an invalid local handle 
          
            if (lpfnIsLocalHandle(wHeap, (HANDLE)1))
               MessageBox(GetFocus(), (LPSTR)"Worked! Good handle",
                   lpLocalTest, MB_OK);
            else
             MessageBox(GetFocus(), (LPSTR)"Failed! Bad Handle",
                   lpLocalTest, MB_OK);
            break;

          case IDM_GLOBALGOOD:
          // Allocate a valid global memory object and check its
          // global handle using the new API on global handles
         
          if (hGlobal = GlobalAlloc(GMEM_MOVEABLE, 1024))
          {
            if (lpfnIsGlobalHandle(hGlobal))
               MessageBox(ghWnd, (LPSTR)"Worked! Good handle",
                   lpGlobalTest, MB_OK);
            else
               MessageBox(ghWnd, (LPSTR)"Failed! Bad Handle",
                   lpGlobalTest, MB_OK);

            GlobalFree(hGlobal);
          }
          else 
            MessageBox(ghWnd, (LPSTR)"GlobalAlloc Failed", 
                   lpGlobalTest, MB_OK);
          break;

          case IDM_GLOBALBAD:
          // Test the API on an invalid global handle 
          
           if (hGlobal = GlobalAlloc(GMEM_MOVEABLE, 1024))
           {
            if (lpfnIsGlobalHandle(hGlobal+5))
             MessageBox(ghWnd, (LPSTR)"Worked! Good handle",
                   lpGlobalTest, MB_OK);
            else
             MessageBox(ghWnd, (LPSTR)"Failed! Bad Handle",
                   lpGlobalTest, MB_OK);

            GlobalFree(hGlobal);
           }
           else 
             MessageBox(ghWnd, (LPSTR)"GlobalAlloc Failed",
                   lpGlobalTest, MB_OK);
           
           break;
        
          // Put up the About box.
          case IDM_ABOUT:
          {
           FARPROC lpAboutDlgProc;

           lpAboutDlgProc = MakeProcInstance((FARPROC) AboutDlgProc, ghInst);

           DialogBox(ghInst,              // current instance
                   AboutBoxName,            // resource to use 
                   hWnd,                // parent handle   
                   lpAboutDlgProc);     // About() instance address

           FreeProcInstance(lpAboutDlgProc);
           break;
          }

          // User picked File.Exit, terminate this app.
          case IDM_EXIT:
           DestroyWindow(hWnd);
           break;


          // Must be some system command -- pass it on to the default
          //  window procedure.
          default:
          return DefWindowProc(hWnd, message, wParam, lParam);
   }

   return (NULL);
}


//****************************************************************************
// Function: AboutDlgProc
//
// Purpose: 
//   Called by DoCommands() when the About dialog box is wanted
//
// Parameters:
//    hDlg    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// History:  Date       Author                    Reason
//
//****************************************************************************

BOOL FAR PASCAL AboutDlgProc (HWND hDlg,
                          UINT message,
                          WPARAM wParam,
                          LPARAM lParam)
{
   switch (message)
   {
      case WM_INITDIALOG:
         return (TRUE);

      case WM_COMMAND:
         if ((wParam == IDOK) ||       // "OK" box selected?        
             (wParam == IDCANCEL))     // System menu close command?
         {
            EndDialog(hDlg, TRUE);     // Exits the dialog box 
            return (TRUE);
         }
         break;
   }

   return (FALSE); // Didn't process a message
}
