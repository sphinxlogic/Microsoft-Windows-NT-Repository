//****************************************************************************
// File: IsHandle.c
//
// Purpose:  
//   This is the DLL to which an application can link, and use the two 
//   exported functions, IsLocalHandle and IsGlobalHandle to validate the
//   handle of a local memory or gloabl memory
//
// Functions:
//   IsLocalHandle()
//   IsGlobalHandle()
//   LibMain()
//   WEP()
//
// Development Team:
//   DavidFl and MSS
//
// Written by Microsoft Product Support Services, Windows Developer Support
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//****************************************************************************


#include "windows.h"
#include "toolhelp.h"
#include "ishandle.h"

//*****************************************************************************
//   FUNCTION: LibMain(HANDLE, WORD, WORD, LPSTR)
//
//   PURPOSE :  Is called by LibEntry.  LibEntry is called by Windows when
//              the DLL is loaded
//
//   Comments:
//
//   History:  Date       Author        Reason
//             4/15/92  DavidFl & MSS   Created        
//            
//*****************************************************************************

int FAR PASCAL LibMain(hModule, wDataSeg, cbHeapSize, lpszCmdLine)
HANDLE hModule;
WORD   wDataSeg;
WORD   cbHeapSize;
LPSTR  lpszCmdLine;
{
   return 1;
}

//****************************************************************************
//    FUNCTION:  WEP(int)
//
//    PURPOSE:  Performs cleanup tasks when the DLL is unloaded.
//*****************************************************************************

int FAR PASCAL WEP (bSystemExit)
int  bSystemExit;
{
    return(1);
}


//*****************************************************************************
//   FUNCTION: IsLocalHandle
//
//   PURPOSE : Validates the handle of a local memory object by walking 
//             the local heap
//
//   PARAMETERS:
//            wHeap - Handle to the local heap
//     hLocalHandle - Handle to be validated
//
//   RETURN:
//          TRUE if handle found in the heap, else FALSE
//
//   Comments:
//
//   History:  Date       Author        Reason
//             4/15/92    DavidFl       Created
//             6/23/92     MSS          Modified
//*****************************************************************************

BOOL FAR PASCAL IsLocalHandle(WORD wHeap, HANDLE hLocalHandle)
{
    LOCALENTRY LEntry;           // structure for Heap information
    HCURSOR hWaitCursor;        // Hour glass cursor handle
    BOOL bFound = FALSE;        // flag to indicate if handle found or not

    /* Turn on the hourglass, This might take a while... */
    hWaitCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));
    ShowCursor(TRUE);

    /* Initialize the structure before starting the walk */
    LEntry.dwSize = sizeof(LOCALENTRY);
    
    /* Walk the local heap until the desired handle found */    
    if (LocalFirst(&LEntry, wHeap))
    {
       do 
       {
          if (LEntry.hHandle==hLocalHandle)
          {
             bFound = TRUE;
             break;
          }
       } while (LocalNext(&LEntry));
    }

    /* Done with hourglass */
    ShowCursor(FALSE);
    SetCursor(hWaitCursor);

    if (bFound)
       return hLocalHandle;
    else
       return NULL;
}


//*****************************************************************************
//   FUNCTION: IsGlobalHandle
//
//   PURPOSE : Validates the handle of a global memory object by walking 
//             the global heap
//
//   PARAMETERS
//     hGlobalHandle - Handle to be validated
//
//   RETURN:
//          TRUE if handle found in the global heap, else FALSE
//
//   Comments:
//
//   History:  Date       Author        Reason
//             4/15/92    DavidFl       Created
//             6/23/92     MSS          Modified
//*****************************************************************************

BOOL FAR PASCAL IsGlobalHandle(HANDLE hGlobalHandle)
{
    GLOBALENTRY GEntry;
    HCURSOR hWaitCursor;
    BOOL bFound = FALSE;

    /* Turn on the hourglass */
    hWaitCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));
    ShowCursor(TRUE);

    /* Initialize the structure before starting the Global walk */
    GEntry.dwSize = sizeof(GLOBALENTRY);
    
    /* Walk the global heap until hGlobalHandle is found */    
    if (GlobalFirst(&GEntry, GLOBAL_ALL))
       {
       do
          {
          if (GEntry.hBlock == hGlobalHandle)
             {
             bFound = TRUE;
             break;
             }
          } while (GlobalNext(&GEntry,GLOBAL_ALL));
       }

    /* Done with hourglass */
    ShowCursor(FALSE);
    SetCursor(hWaitCursor);

    if (bFound)
       return hGlobalHandle;
    else
       return NULL;
}

