//****************************************************************************
// File: Handle.c
//
// Purpose: 
//   Contains main message loop and application entry point
//
// Functions:
//    WinMain() - initializes everything and enters message loop
//
// Development Team:    
//   DavidFl and MSS
//
// Written by Microsoft Product Support Services, Windows Developer Support
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//****************************************************************************

// The following #define is used by HANDLE.H -- it tells it that we
// want the globals _declared_ in this module. 
#define IN_INIT

#include <windows.h>
#include "handle.h"

//***********************************************************************
// Function: WinMain
//
// Purpose: Called by Windows on app startup.  Initializes everything,
//          and enters a message loop.
//
// Parameters:
//    hInstance     == Handle to _this_ instance.
//    hPrevInstance == Handle to last instance of app.
//    lpCmdLine     == Command Line passed into app.
//    nCmdShow      == How app should come up (i.e. minimized/normal)
//
// Returns: Return value from PostQuitMessage.
//
// Comments:
//
// History:  Date       Author                  Reason
//           3/23/92  DavidFl & MSS            Created
//****************************************************************************

int PASCAL WinMain (HANDLE hInstance,           // This instance
                    HANDLE hPrevInstance,       // Last instance
                    LPSTR lpCmdLine,            // Command Line
                    int nCmdShow)               // Minimized or Normal?
{
   MSG msg;
   
   if (!hPrevInstance)
      if (!InitApplication(hInstance))
         return (FALSE);

   if (!InitInstance(hInstance, nCmdShow))
      return (FALSE);
      
   while (GetMessage(&msg,             // Put Message Here
                     NULL,             // Handle of window receiving msg
                     NULL,             // lowest message to examine
                     NULL))            // highest message to examine
   {
      TranslateMessage(&msg);          // Translates virtual key codes
      DispatchMessage(&msg);           // Dispatches message to window
   }
   
   return (msg.wParam);                // Returns the value from PostQuitMessage
}


//**************************************************************************
//
// Function: InitApplication
//
// Purpose: Called by WinMain on first instance of app.  Registers
//          the window class.
//
// Parameters:
//    hInst == Handle to _this_ instance.
//
// Returns: TRUE on success, FALSE otherwise.
//
// Comments:
//
// History:  Date       Author                  Reason
//           6/23/92  DavidFl & MSS             Created
//****************************************************************************

BOOL InitApplication (HANDLE hInst)
{
   WNDCLASS wc;
   char szMenuName[STR_LEN];
   char szClassName[STR_LEN];

   LoadString(hInst, IDS_MAINMENUNAME, szMenuName, STR_LEN);
   LoadString(hInst, IDS_MAINCLASSNAME, szClassName, STR_LEN);
   
   wc.style = CS_HREDRAW |
              CS_VREDRAW;
   wc.lpfnWndProc = MainWndProc;
   wc.cbClsExtra = 0;
   wc.cbWndExtra = 0;
   wc.hInstance = hInst;
   wc.hIcon = LoadIcon(hInst, IDI_APPLICATION);
   wc.hCursor = LoadCursor(NULL, IDC_ARROW);
   wc.hbrBackground = GetStockObject(WHITE_BRUSH);
   wc.lpszMenuName = szMenuName;
   wc.lpszClassName = szClassName;

   // Register the window class and return success/failure code.
   return RegisterClass(&wc);
}


//****************************************************************************
// Function: InitInstance
//
// Purpose: Called by WinMain on instance startup.  Creates and
//            displays the main, overlapped window.
//
// Parameters:
//    hInstance     == Handle to _this_ instance.
//    nCmdShow      == How app should come up (i.e. minimized/normal)
//
// Returns: TRUE on success, FALSE otherwise.
//
// Comments:
//
// History:  Date       Author                  Reason
//           3/23/92  DavidFL & MSS             Created
//****************************************************************************

BOOL InitInstance (HANDLE hInstance,
                   int nCmdShow)
{
   HWND hWnd;
   char szTitle[STR_LEN];
   char szClassName[STR_LEN];

   // Load some necessary strings from the string table.
   LoadString(hInstance, IDS_PROGNAME, szTitle, STR_LEN);
   LoadString(hInstance, IDS_MAINCLASSNAME, szClassName, STR_LEN);
   
   // Save the instance handle in global variable, which will be used in
   // many subsequence calls from this application to Windows.          
   ghInst = hInstance;


   // Create a main window for this application instance.
   hWnd = CreateWindow(szClassName,    // See RegisterClass() call.
                       szTitle,        // Text for window title bar.
                       WS_OVERLAPPEDWINDOW,                // Window style.
                       CW_USEDEFAULT,  // Default horizontal position.
                       CW_USEDEFAULT,  // Default vertical position.
                       CW_USEDEFAULT,  // Default width.
                       CW_USEDEFAULT,  // Default height.
                       NULL,           // Overlapped windows have no parent.
                       NULL,           // Use the window class menu.        
                       hInstance,      // This instance owns this window.   
                       NULL);          // Pointer not used.               


   // We'll keep a global of the main window's handle.  This is useful
   //  for calls to MessageBox(), etc., if needed
   ghWnd = hWnd;

   // If window could not be created, return "failure"
   if (!hWnd)
      return (FALSE);

   // Make the window visible; update its client area; and return "success"
   ShowWindow(hWnd, nCmdShow);         // Show the window                        
   UpdateWindow(hWnd);                 // Sends WM_PAINT message
}

