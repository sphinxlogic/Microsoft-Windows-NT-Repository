//**************************************************************************
//
//  APPLICATION: 
//      HotKeyEd.exe                                               
//
//  FILE:
//      hotkeyed.c
//
//  AUTHOR:
//      Irfan Gowani - Windows Developer Support,
//                     Microsoft Product Support Services.
//
//  CREATION DATE:
//      2-25-92
//    
//
//  PURPOSE:
//      This application demonstrates the implementation of a shortcut key
//      (hot key) edit control.  The application contains a dialog box that
//      allows the user to specify which hot key the application will use. 
//      This dialog box uses a subclasses edit control to display the name
//      of the hot key as it is entered.  The edit control checks that the 
//      that the hotkey is valid before displaying it, and will not allow 
//      the user to enter invalid hot keys.  GetKeyNameText() is used to get
//      the names of the keys. 
//
//      When the user enters a valid shortcut key, it also lets the user 
//      install that shortcut key.  To install the shortcut key, the app 
//      uses the Windows 3.1 hook function SetWindowsHookEx() to install 
//      a task specific keyboard hook.  The shortcut key can also be 
//      removed by the user by menu selection or exiting the app.
//
//      When the shortcut key is installed, the caption is flashed to let 
//      the user know that a hot key has been installed.  The caption keeps 
//      on flashing until the removal of the shortcut key.  When the shortcut 
//      key is pressed by the user, the main window's background color is
//      toggled.
//
//      A shortcut key must have an ALT or/and CTRL modifier.  A shift can 
//      also be specified but not by itself.  To erase a key combination from 
//      the edit control, use BACKSPACE or enter another key combination.
//      ESC, ENTER, TAB, SPACEBAR, and PRINT SCREEN keys are not allowed.
//
//
//  FUNCTIONS:                                                              
//
//  WinMain()            - Registers a window class.
//                       - Creates the main window.
//                       - Enters the message loop.                                
//                       
//  MainWndProc()        - Processes the main window's messages.                       
//
//  HotKeyEditProc()     - Processes the Shortcut edit control's messages.
// 
//  AboutDlgProc()       - Processes the "About" dialog's messages.                  
// 
//  HotKeyEditDlgProc()  - Processes the HotKeyEdit" dialog messages.
//
//  HandleKeyDowns()     - Handles key downs for the shortcut key edit control.
//
//  HandleKeyUps()       - Handles key ups for the shortcut key edit control.
//
//  InstallHotKey()      - Installs keyboard hook.
//
//  RemoveHotKey()       - Removes the keyboard hook.
//
//  HotKeyHookCallback() - Keyboard hook callback.
//
//  DisplayHotKey()      - Creates and displays the shortcut key string.
//
//  DoErasingStuff()     - Initializes the shortcut key structure and
//                         blanks-out the shortcut key edit control.
//
//
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//**************************************************************************

#include <windows.h>
#include "HotKeyEd.h"

HANDLE          ghInst;                 // Application's instance handle
FARPROC         glpOldHotKeyEditProc;   // Original function address of the edit control
HWND            ghwndMain;              // Handle to the main window
HOTKEYSTRUCT    ghksHotKey;             // Shortcut key info
HHOOK           ghHotKeyHook = 0;       // Shortcut key hook
BOOL            gbWindowNotActive;      // Caption's state for flashing

//**************************************************************************
//
//  WinMain()                                                     
//
//  PURPOSE:                                                                
//      This function registers a window class, creates
//      the main window, and enters the message loop.
//
//  FUNCTION CALLS:
//      None
//
//  GLOBAL VARIABLES MODIFIED:
//      ghwndMain
//      ghInst
//
//**************************************************************************

int PASCAL WinMain (HANDLE hInstance, HANDLE hPrevInstance,
                    LPSTR lpCmdLine,  int nCmdShow)
{
    MSG         msg;
    WNDCLASS    wc;

    if (!hPrevInstance)
    {
        wc.style = NULL;
        wc.lpfnWndProc = MainWndProc;
        wc.cbClsExtra = 0;
        wc.cbWndExtra = 0;
        wc.hInstance = hInstance;
        wc.hIcon = LoadIcon (hInstance, "HotKeyEditIcon");
        wc.hCursor = LoadCursor (NULL, IDC_ARROW);
        wc.hbrBackground = (HBRUSH) COLOR_WINDOW + 1;
        wc.lpszMenuName =  "HotKeyEditMenu";
        wc.lpszClassName = "HotKeyEditWClass";

        if (!RegisterClass (&wc))
            return (FALSE);
    } // if

    ghwndMain = CreateWindow ("HotKeyEditWClass",
                              "Shortcut Edit and Install Sample - Shortcut Key = None",
                              WS_OVERLAPPEDWINDOW | WS_VISIBLE,
                              CW_USEDEFAULT,
                              CW_USEDEFAULT,
                              CW_USEDEFAULT,
                              CW_USEDEFAULT,
                              NULL,
                              NULL,
                              hInstance,
                              NULL);

    if (!ghwndMain)
        return (FALSE);

    ghInst = hInstance;

    while (GetMessage (&msg,
                        NULL,
                        NULL,
                        NULL))
    {
        TranslateMessage (&msg);
        DispatchMessage (&msg);
    } // while

    return (msg.wParam);
} // WinMain()


//**************************************************************************
//
//  WNDPROC:
//      MainWndProc()                                                     
//
//  PURPOSE:                                                                
//      This function handles messages belonging to the main window.
//      It lets the user edit, install, and remove a shortcut key; and it
//      also displays the About dialog box.
//
//  MESSAGES:
//
//      WM_CREATE:  Creates a gray and a red brush, and sets gray brush 
//                  as the background brush of the main window.
//
//      WM_HOTKEY:  A private messages sent by the hook callback when
//                  the shortcut key is pressed.  Background brush is toggled.
//
//      WM_COMMAND: Menu options.
//
//      WM_DESTROY: Shortcut key hook is removed, the second brush is deleted,
//                  and PostQuitMessage().
//
//  FUNCTION CALLS:
//      RemoveHotKey()
//      HotKeyEditDlgProc() - Indirectly
//      AboutDlgProc()      - Indirectly
//
//  CALLED BY:
//      Windows
//
//  GLOBAL VARIABLES MODIFIED:
//      gbWindowNotActive
//
//**************************************************************************

long FAR PASCAL MainWndProc (HWND hWnd,   unsigned uMessage,
                             WORD wParam, LONG lParam)
{
            FARPROC lpDialogProc;
    static  HBRUSH  hbrGray, hbrRed;
    static  BOOL    bGrayBackground;
    static  HMENU   hMenu;

    switch (uMessage)
    {
        case WM_CREATE:
            hbrGray = CreateSolidBrush (RGB (192, 192, 192));
            hbrRed  = CreateSolidBrush (RGB (255, 0, 0));

            SetClassWord (hWnd, GCW_HBRBACKGROUND, hbrGray);
            bGrayBackground = TRUE;

            hMenu = GetMenu (hWnd);

            break;

        case WM_HOTKEY:   // Our private message

            // Toggle the color - Gray/Red

            if (bGrayBackground)
                SetClassWord (hWnd, GCW_HBRBACKGROUND, hbrRed);
            else
                SetClassWord (hWnd, GCW_HBRBACKGROUND, hbrGray);

            InvalidateRect (hWnd, NULL, TRUE);
            UpdateWindow (hWnd);

            bGrayBackground = !bGrayBackground;

            break;

        case WM_TIMER:
            if (wParam == HOTKEY_TIMER)
                gbWindowNotActive = FlashWindow (hWnd, TRUE);

            break;

        case WM_COMMAND:
            switch (wParam)
            {
                case IDM_EDITINSTALLHOTKEY:
                    lpDialogProc = MakeProcInstance (HotKeyEditDlgProc, ghInst);

                    // If the user doesn't install the shortcut key...

                    if (DialogBox (ghInst,
                                   "HotKeyEditBox",
                                   hWnd,
                                   lpDialogProc))
                        EnableMenuItem (hMenu, IDM_REMOVEHOTKEY,
                                        MF_BYCOMMAND | MF_ENABLED);

                    FreeProcInstance (lpDialogProc);

                    break;

                case IDM_REMOVEHOTKEY:
                    RemoveHotKey ();

                    EnableMenuItem (hMenu, IDM_REMOVEHOTKEY,
                                 MF_BYCOMMAND | MF_GRAYED);

                    break;

                case IDM_ABOUT:
                    lpDialogProc = MakeProcInstance (AboutDlgProc, ghInst);
                    DialogBox (ghInst,
                                "AboutBox",
                                hWnd,
                                lpDialogProc);
                    FreeProcInstance (lpDialogProc);

                    break;

                default:
                    return (DefWindowProc (hWnd, uMessage, wParam, lParam));
            } // switch (wParam)
            break;

        case WM_DESTROY:
            RemoveHotKey ();

            // Delete the brush that is not selected
            if (bGrayBackground)
                DeleteObject (hbrRed);
            else
                DeleteObject (hbrGray);

            PostQuitMessage (0);

            break;

        default:
            return (DefWindowProc (hWnd, uMessage, wParam, lParam));
    } // switch (uMessage)

    return (0);

} // MainWndProc()


//**************************************************************************
//
//  WNDPROC:
//      HotKeyEditProc()
//
//  PURPOSE:
//
//      This is a subclassed function that handles messages belonging to 
//      the Shortcut edit control.
//
//  MESSAGES:
//
//      WM_KEYDOWN:
//          WM_SYSKEYDOWN:
//          Calls HandleKeyDowns().
//
//          WM_KEYUP:
//          WM_SYSKEYUP:
//          WM_SYSCHAR:
//          WM_CHAR:
//          Calls HandleKeyUps().
//
//  FUNCTION CALLS:
//      HandleKeyDowns()
//      HandleKeyUps()
//
//  CALLED BY:
//      Windows
//
//**************************************************************************

long FAR PASCAL HotKeyEditProc (HWND hHotKeyEdit, unsigned uMessage,
                                WORD wParam,      LONG lParam)
{
    static  WORD    wModifierKeys;

    switch (uMessage)
    {
        case WM_KEYDOWN:
        case WM_SYSKEYDOWN:
            return (HandleKeyDowns (hHotKeyEdit, uMessage, wParam,
                                    lParam, &wModifierKeys));

        case WM_KEYUP:
        case WM_SYSKEYUP:
        case WM_SYSCHAR:
        case WM_CHAR:
            return (HandleKeyUps (hHotKeyEdit, uMessage, wParam,
                                  lParam, wModifierKeys));

                default:
                        return (CallWindowProc (glpOldHotKeyEditProc, hHotKeyEdit, uMessage,
                                    wParam, lParam));

    } // switch (uMessage)

    return (0);

} // HotKeyEditProc


//**************************************************************************
//
//  DIALOGPROC:
//      AboutDlgProc()                                                     
//
//  PURPOSE:                                                                
//      This function handles messages belonging to the "About" dialog box.
//      The only message that it looks for is WM_COMMAND, indicating that the
//      user has pressed the "OK" button or hit <Esc>.  When this happens, 
//      it takes down the dialog box.
//
//  MESSAGES:
//  
//      WM_INITDIALOG:  return (TRUE).
//
//      WM_COMMAND:     Dialog is terminated upon Cancel or OK.
//
//  FUNCTION CALLS:
//      None
//
//  CALLED BY:
//      MainWndProc() - Indirectly
//
//**************************************************************************

BOOL FAR PASCAL AboutDlgProc (HWND hDlg,   unsigned uMessage,
                       WORD wParam, LONG lParam)
{
    switch (uMessage)
    {
        case WM_INITDIALOG:
            return (TRUE);

        case WM_COMMAND:
            switch (wParam)
            {
                case IDOK:
                case IDCANCEL:
                    EndDialog (hDlg, TRUE);
                    return (TRUE);

                default:
                    break;
            } /* switch (wParam) */
    } // switch (uMessage)

    return (FALSE);

} // AboutDlgProc()


//**************************************************************************
//
//  DIALOGPROC:
//      HotKeyEditDlgProc()                                                     
//
//  PURPOSE:                                                                
//                                                                           
//      This function handles messages belonging to the "HotKeyEdit" dialog
//      box.  
//
//  MESSAGES:
//  
//      WM_INITDIALOG:  Subclasses the shortcut key edit control.
//
//      WM_COMMAND:     - Installs a valid shortcut key.  
//                      - Dialog is terminated upon Cancel or Install.
//                      - Upon Cancel, EndDialog() is returned with a FALSE;
//                        so the calling function would know that the hook
//                        was not installed.
//
//  FUNCTION CALLS:
//      None
//
//  CALLED BY:
//      MainWndProc() - Indirectly
//  
//  GLOBAL VARIABLES MODIFIED:
//      glpOldHotKeyEditProc
//
//**************************************************************************

BOOL FAR PASCAL HotKeyEditDlgProc (HWND hDlg,   unsigned uMessage,
                                   WORD wParam, LONG lParam)
{
            FARPROC lpHotKeyEditProc;
    static  HWND    hHotKeyEdit;

    switch (uMessage)
    {
        case WM_INITDIALOG:
            hHotKeyEdit = GetDlgItem (hDlg, IDD_HOTKEYEDIT);

                lpHotKeyEditProc = MakeProcInstance ((FARPROC) HotKeyEditProc,
                                                  ghInst);

                glpOldHotKeyEditProc = (FARPROC)
                                    SetWindowLong (hHotKeyEdit,
                                                   GWL_WNDPROC,
                                                   (DWORD) lpHotKeyEditProc);
            return (TRUE);

        case WM_COMMAND:
            switch (wParam)
            {
                case IDD_INSTALL:
                    GetWindowText (hHotKeyEdit,
                                   (LPSTR) ghksHotKey.szText,
                                   STR_LEN);

                    InstallHotKey ();

                    EndDialog (hDlg, TRUE);
                    return (TRUE);

                case IDCANCEL:
                    // Return FALSE since the user canceled it
                    EndDialog (hDlg, FALSE);
                    return (TRUE);

                default:
                    break;
            } /* switch (wParam) */
    } // switch (uMessage)

    return (FALSE);

} // HotKeyEditDlgProc()



//***************************************************************************
//
//  FUNCTION:
//      HandleKeyDowns()
//
//  PURPOSE:
//      This function handles key downs for the shortcut key edit control.
//      It sets and displays the shortcut key in the edit control.
//      
//
//  PARAMETERS:
//
//      IN:
//          hHotKeyEdit    - Shortcut key's edit control's handle
//          uMessage       - Control's message
//          wParam         - Message information
//          lParam         - Additional message information
//          pwModifierKeys - N/A
//
//      OUT:
//          pwModifierKeys - Modifier (ALT, CONTROL, SHIFT) bits
//                           if they are pressed
//
//
//  RETURN VALUE:
//      Appropriate value if key belongs to Windows; otherwise 0.
//
//  FUNCTION CALLS:
//      DoErasingStuff()
//      DisplayHotKey()
//
//  CALLED BY:
//      MainWndProc()
//
//***************************************************************************

long HandleKeyDowns (HWND hHotKeyEdit, unsigned uMessage,  WORD  wParam,
                    LONG  lParam,      PWORD pwModifierKeys)
{
    *pwModifierKeys = 0;

    // Set wModifierKeys according to the modifier keys down

    if (GetKeyState (VK_CONTROL) & 0x1000)
        *pwModifierKeys |= CONTROL_BIT;

    if (GetKeyState (VK_SHIFT) & 0x1000)
        *pwModifierKeys |= SHIFT_BIT;

    if (lParam & 0x20000000)
        *pwModifierKeys |= MENU_BIT;

    // If the keys are for the dialog box or Windows, pass them

    if (wParam == VK_TAB || wParam == VK_ESCAPE
    || wParam == VK_RETURN || wParam == VK_SPACE)
    {
        DoErasingStuff (hHotKeyEdit);
            return (CallWindowProc (glpOldHotKeyEditProc, hHotKeyEdit, uMessage,
                                wParam, lParam));
    }
    else if (wParam == VK_BACK && *pwModifierKeys == 0)
    {
        // If BACKSPACE, then erase the edit control and the shortcut key structure;
        // and make the INSTALL button disabled.

        DoErasingStuff (hHotKeyEdit);
        EnableWindow (GetDlgItem (GetParent (hHotKeyEdit), IDD_INSTALL), FALSE);

        return (0);
    }
    else if (*pwModifierKeys)
    {
        // Display the keys but only if the modifier(s) present

        DisplayHotKey (GetParent (hHotKeyEdit), *pwModifierKeys, wParam, lParam);
        return (0);

    }

} // HandleKeyDowns()


//***************************************************************************
//
//  FUNCTION:
//      HandleKeyUps()
//
//  PURPOSE:
//      This function handles key ups for the shortcut key edit control.
//      If the shortcut key is not valid, it blanks-out the edit control.w
//
//  PARAMETERS:
//
//      IN:
//          hHotKeyEdit   - Shortcut key's edit control's handle
//          uMessage      - Control's message
//          wParam        - Message information
//          lParam        - Additional message information
//          wModifierKeys - ALT, CONTROL, SHIFT bits if they are pressed
//
//      OUT:
//          N/A
//
//  RETURN VALUE:
//
//
//  FUNCTION CALLS:
//      DoErasingStuff()
//
//  CALLED BY:
//      MainWndProc()
//
//***************************************************************************

long HandleKeyUps (HWND hHotKeyEdit, unsigned uMessage,     WORD  wParam,
                   LONG  lParam,     WORD     wModifierKeys)

{
    switch (wParam)
    {
        // If it's a restricted key, then pass it to windows
        case VK_RETURN:
        case VK_ESCAPE:
        case VK_TAB:
                        return (CallWindowProc (glpOldHotKeyEditProc, hHotKeyEdit, uMessage,
                                    wParam, lParam));

            default:
                // If only the modifier keys were pressed, 
                // OR
                // If SHIFT is the only modifier key with a valid key,
                // then erase and initialize the edit control
                if (ghksHotKey.uKey == 0 ||
                (wModifierKeys == SHIFT_BIT && uMessage == WM_KEYUP))
                    DoErasingStuff (hHotKeyEdit);

                return (0);
    }
} // HandleLeyUps()

//***************************************************************************
//
//  FUNCTION:
//      InstallHotKey()
//
//  PURPOSE:
//      - Installs a task specific keyboard hook.
//      - Sets timer to flash window caption.
//      - Sets window caption to reflect the new shortcut key.
//
//  PARAMETERS:
//      void
//
//  RETURN VALUE:
//      void
//
//  FUNCTION CALLS:
//      None
//
//  CALLED BY:
//      HotKeyEditDlgProc()
//
//  GLOBAL VARIABLES MODOFIED:
//      ghHotKeyHook
//
//***************************************************************************

void InstallHotKey (void)
{
    char    szCaption [CAPTION_LEN];

    // If there is already a hook installed, then don't do it again.
    if (!ghHotKeyHook)
        ghHotKeyHook = SetWindowsHookEx (WH_KEYBOARD,
                                   (FARPROC) HotKeyHookCallback,
                                   ghInst,
                                   GetCurrentTask ());
    wsprintf ((LPSTR) szCaption,
              "Shortcut Edit and Install Sample - Shortcut Key = %s",
              (LPSTR) ghksHotKey.szText);

    SetTimer (ghwndMain, HOTKEY_TIMER, TIME_OUT, NULL);

    SetWindowText (ghwndMain, (LPSTR) szCaption);

} // InstallHotKey()

//***************************************************************************
//
//  WNDPROC:
//      RemoveHotKey()
//
//  PURPOSE:
//      - Removes the keyboard hook.
//      - Sets the window caption to refelect no shortcut key.
//      - Kills the timer that's used for flashing the window caption
//      
//
//  PARAMETERS:
//      void
//
//  RETURN VALUE:
//      void
//
//  FUNCTION CALLS:
//      None
//
//  CALLED BY:
//      MainWndProc()
//
//  GLOBAL VARIABLES MODOFIED:
//      ghHotKeyHook
//
//***************************************************************************

void RemoveHotKey (void)
{
    if (ghHotKeyHook)
        UnhookWindowsHookEx (ghHotKeyHook);

    ghHotKeyHook = 0;

    SetWindowText (ghwndMain,
                   "Shortcut Edit and Install Sample - Shortcut Key = None");

    KillTimer (ghwndMain, HOTKEY_TIMER);

    // Highlight the caption if now it's inactive
    if (gbWindowNotActive)
        FlashWindow (ghwndMain, FALSE);

} // RemoveHotKey()


//***************************************************************************
//
//  FUNCTION:
//      DisplayHotKey()
//
//  PURPOSE:
//      - Creates the shortcut key string and displays it.
//      - Sets the global shortcut key structure.
//
//  PARAMETERS:
//
//      IN:
//          hDlg          - Shortcut Key edit control's parent dialog
//          wModifierKeys - ALT, CONTROL, SHIFT bits if they are pressed
//          wKeyNum       - The pressed key
//          lKeyInfo      - Additional key info
//
//      OUT:
//          N/A
//
//  RETURN VALUE:
//      void
//
//  FUNCTION CALLS:
//      None
//
//  CALLED BY:
//      HandleKeyDowns()
//
//  GLOBAL VARIABLES MODIFIED:
//      ghksHotKey
//
//***************************************************************************

void DisplayHotKey (HWND hDlg,    WORD wModifierKeys,
                    WORD wKeyNum, LONG lKeyInfo)
{
    char    szHotKey [STR_LEN];
    char    szKeyName [STR_LEN];
    int     iHotKeyStrLen;
    HWND    hHotKeyEdit = GetDlgItem (hDlg, IDD_HOTKEYEDIT);

    szHotKey [0] = 0;

    // Disable the button if it was enabled.
    EnableWindow (GetDlgItem (hDlg, IDD_INSTALL), FALSE);

    // Create the string to display the modifier keys.

    if (wModifierKeys & MENU_BIT)
        wsprintf ((LPSTR) szHotKey, "Alt");

    if (wModifierKeys & CONTROL_BIT)
        if (wModifierKeys & MENU_BIT)
            lstrcat ((LPSTR) szHotKey, (LPSTR) "+Ctrl");
        else
            lstrcat ((LPSTR) szHotKey, (LPSTR) "Ctrl");

    if (wModifierKeys & SHIFT_BIT)
        if (wModifierKeys & MENU_BIT || wModifierKeys & CONTROL_BIT)
            lstrcat ((LPSTR) szHotKey, (LPSTR) "+Shift");
        else
            lstrcat ((LPSTR) szHotKey, (LPSTR) "Shift");


    // Display modifier keys

    SetWindowText (hHotKeyEdit, (LPSTR) szHotKey);
    
    // Save the keys

    ghksHotKey.wModifierKeys = wModifierKeys;
    ghksHotKey.uKey = 0;

    // Set the cursor at the end of the text
    iHotKeyStrLen = lstrlen ((LPSTR) szHotKey);

    SendMessage (hHotKeyEdit, EM_SETSEL, 0, 
                MAKELONG (iHotKeyStrLen, iHotKeyStrLen));


    // Add the character key and then display it.

    if (GetKeyNameText (lKeyInfo, (LPSTR) szKeyName, STR_LEN)
    && (wKeyNum != VK_MENU && wKeyNum != VK_CONTROL && wKeyNum != VK_SHIFT))
    {
        lstrcat ((LPSTR) szHotKey, (LPSTR) "+");
        lstrcat ((LPSTR) szHotKey, (LPSTR) szKeyName);

        // Save the character key

        ghksHotKey.uKey = wKeyNum;

        // Display rest of the shortcut key

        SetWindowText (hHotKeyEdit, (LPSTR) szHotKey);

        // Let the user Install the shortcut key
        // if it's a valid shortcut key
        if (wModifierKeys != SHIFT_BIT)
            EnableWindow (GetDlgItem (hDlg, IDD_INSTALL), TRUE);

        // Set the cursor at the end of the text
        iHotKeyStrLen = lstrlen ((LPSTR) szHotKey);

        SendMessage (hHotKeyEdit, EM_SETSEL, 0, 
                    MAKELONG (iHotKeyStrLen, iHotKeyStrLen));
    }

} // DisplayHotKey()

//**************************************************************************
//
//  CALLBACK:
//      HotKeyHookCallback()
//
//  PURPOSE:
//
//      This function is a keyboard filter for this application.
//      It checks whethter the user-specified shortcut key has been pressed
//      or not.  In case of the shortcut key, the main window is sent a private
//      message so it can change the main-window background color.
//
//  GLOBAL VARIABLES MODIFIED:
//      ghksHotKey
//
//**************************************************************************

DWORD FAR PASCAL HotKeyHookCallback (int     nCode,
                                     WORD    wParam,
                                     DWORD   lParam)
{
    // If the key pressed is part of the shortcut key
    // and nCode is ours to process, then look for 
    // modifier keys for the shortcut key.  If the shortcut key
    // was pressed, then post the main window a message
    // so it should change the main-window background color.

    if (nCode == HC_ACTION && ghksHotKey.uKey == wParam)
    {
        // Skip if the key was released or if it's a repeat
        if (lParam & 0x80000000 || lParam & 0x40000000)
            goto Exit;

        // Check to see if ALT is part of the shortcut key and pressed
        if (ghksHotKey.wModifierKeys & MENU_BIT)
            if (!(lParam & 0x20000000))
                goto Exit;
        
        // Check to see if CONTROL is part of the shortcut key and pressed
        if (ghksHotKey.wModifierKeys & CONTROL_BIT)
            if (!(GetKeyState (VK_CONTROL) & 0x1000))
                goto Exit;

        // Check to see if SHIFT is part of the shortcut key and pressed
        if (ghksHotKey.wModifierKeys & SHIFT_BIT)
            if (!(GetKeyState (VK_SHIFT) & 0x1000))
                goto Exit;

        PostMessage (ghwndMain, WM_HOTKEY, 0, 0L);
    }

Exit:

    return (CallNextHookEx (ghHotKeyHook,
                            nCode,
                            wParam,
                            (LONG)lParam));
} // HotKeyHookCallback()


//***************************************************************************
//
//  FUNCTION:
//      DoErasingStuff()
//
//  PURPOSE:
//      - Blanks-out the shortcut key edit control.
//      - Initializes the global shortcut key structure.
//
//  PARAMETERS:
//
//      IN:
//          hHotKeyEdit  - Shortcut key's edit control's handle
//
//      OUT:
//          N/A
//
//  RETURN VALUE:
//      void
//
//  FUNCTION CALLS:
//      None
//
//  CALLED BY:
//      HandleKeyDowns()
//      HandleKeyUps()
//
//  GLOBAL VARIABLES MODIFIED:
//      ghksHotKey
//
//***************************************************************************

void DoErasingStuff (HWND hHotKeyEdit)
{
    SetWindowText (hHotKeyEdit, (LPSTR) '\0');
    ghksHotKey.wModifierKeys = 0;
    ghksHotKey.uKey = 0;
} // DoErasingStuff()
