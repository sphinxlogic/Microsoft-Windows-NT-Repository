//----------------------------------------------------------------------------//
//  FileName: DDEPROC.C                                                       //
//                                                                            //
//  Source file for all DDEML-related routines necessary in this              //
//  particular application.                                                   //
//                                                                            //
//  Description of Functions:                                                 //
//                                                                            //
//      DdeML_InitStuff ()          - Performs all initialization stuff       //
//                                    required to get a DDEML conversation    //
//				      with a BALLCLI going.		      //
//      DdeML_CleanupStuff ()       - Corresponding to the former, cleans up  //
//                                    all handles, etc. created @ initial'zn  //
//                                    time.                                   //
//      DdeML_ConnectWithServer ()  - Establishes a conversation with the     //
//                                    SERVER and issues ADVISE transactions   //
//                                    requesting data from the SERVER.        //
//      DdeCallback ()              - Processes DDE transactions affecting    //
//                                    the application.                        //
//                                                                            //
//  Developed by:  Lanie Biagan                                               //
//  Written by Microsoft Product Support Services, Windows Developer Support  //
//                                                                            //
//  Copyright (C) 1991 Microsoft Corporation.  All rights reserved.           //
//----------------------------------------------------------------------------//
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//


#include <WINDOWS.H>
#include <DDEML.H>
#include "GLOBALS.H"
#include "BALLCLI.H"
#include "WNDPROC.H"


//-- The following variables are defined in Wndproc.C ------------------------//
extern HDC     hDC;
extern BOOL    DrawMyBall,      DrawOtherBall;
extern BOOL    bStopAdvising,   bStopAdvising2 ,
               SentMessage,     SentMessage2;
extern float   someIncrement,   someIncrement2,
               x1Center,        y1Center, 
               x2Center,        y2Center,
               cx1Move,         cy1Move,  
               cx2Move,         cy2Move,
               cx1Total,        cy1Total, 
               cx2Total,        cy2Total;
extern short   cxRadius,        cyRadius,
               cxClient,        cyClient;
extern short   SpeedDiv;
extern int     cxFrame, cyFrame, cyMenu,cyCaption;


//--- Prototype for our DDE Callback function --------------------------------//
HDDEDATA EXPENTRY DdeCallback (UINT wType,      // transaction type
                               UINT wFmt,       // clipboard data format
                               HCONV hConv,     // handle to the conversation
                               HSZ hsz1,        // handle to a string
                               HSZ hsz2,        // handle to a string
                               HDDEDATA hData,  // handle to a global memory object
                               DWORD dwData1,   // transaction-specific data
                               DWORD dwData2);  // transaction-specific data


/***********************************************************************
 *  Title:                                                                   
 *      DdeML_HandleError
 *                                                                           
 *  Purpose:                                                                 
 *      Handles Error with DDEML function failure.
 ***********************************************************************/

void DdeML_HandleError ()
{
   char  szBuffer [81];
   UINT  ErrCode = 0, StrTableIdx;

   ErrCode = DdeGetLastError (idInst);
   switch (ErrCode)
   {
     case DMLERR_ADVACKTIMEOUT       : StrTableIdx = IDS_DDE1; break;
     case DMLERR_BUSY                : StrTableIdx = IDS_DDE2; break;
     case DMLERR_DATAACKTIMEOUT      : StrTableIdx = IDS_DDE3; break;
     case DMLERR_DLL_NOT_INITIALIZED : StrTableIdx = IDS_DDE4; break;
     case DMLERR_DLL_USAGE           : StrTableIdx = IDS_DDE5; break;
     case DMLERR_EXECACKTIMEOUT      : StrTableIdx = IDS_DDE6; break;
     case DMLERR_INVALIDPARAMETER    : StrTableIdx = IDS_DDE7; break;
     case DMLERR_LOW_MEMORY          : StrTableIdx = IDS_DDE8; break;
     case DMLERR_MEMORY_ERROR        : StrTableIdx = IDS_DDE9; break;
     case DMLERR_NOTPROCESSED        : StrTableIdx = IDS_DDE10; break;
     case DMLERR_NO_CONV_ESTABLISHED : StrTableIdx = IDS_DDE11; break;
     case DMLERR_POKEACKTIMEOUT      : StrTableIdx = IDS_DDE12; break;
     case DMLERR_POSTMSG_FAILED      : StrTableIdx = IDS_DDE13; break;
     case DMLERR_REENTRANCY          : StrTableIdx = IDS_DDE14; break;
     case DMLERR_SERVER_DIED         : StrTableIdx = IDS_DDE15; break;
     case DMLERR_SYS_ERROR           : StrTableIdx = IDS_DDE16; break;
     case DMLERR_UNADVACKTIMEOUT     : StrTableIdx = IDS_DDE17; break;
     case DMLERR_UNFOUND_QUEUE_ID    : StrTableIdx = IDS_DDE18; break;
   }

   if (!ErrCode)
   {
     LoadString (ghInstance, StrTableIdx, szBuffer, sizeof(szBuffer)) ;
     MessageBeep (MB_ICONEXCLAMATION);
     MessageBox (NULL, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
   }
}

//---------------------------------------------------------------------------//
//  Title:                                                                   //
//      DdeML_ConnectWithServer                                              //
//                                                                           //
//  Parameters:                                                              //
//      hWnd - handle to the Window                                          //
//                                                                           //
//  Purpose:                                                                 //
//      Establishes a conversation with, and then issues an  ADVISE          //
//  transaction to, the SERVER, requesting periodic updates on the status    //
//  of the ball.                                                             //
//---------------------------------------------------------------------------//

void DdeML_ConnectWithServer (HWND hWnd)
{
   char   szBuffer [81];


   // Establish conversation with the SERVER
   hConvClient = DdeConnect (idInst,
                             hszSvrAppName,
                             hszSvrTopicName,
                             (LPVOID)NULL);
   if (!hConvClient)
   {
//  CLIENT:  Uh oh... SERVER doesn't want to talk to me.
//           (possibly unavailable, or does not support Service/Topic name
//           pair passed as parameters).

//  I commented out this call to MessageBox() below to allow the CLIENT to 
//  function alone, even without the server.  The ball, in which case, will
//  just bounce w/in the CLIENT's window.  Needless to say, no conversation is
//  established at this point.

//    MessageBox (hWnd, "LBs_Server is unavailable for a conversation.",
//                        "Oops!!", MB_ICONEXCLAMATION|MB_OK);
    }
    else
    {
//--- Seek advise on Item #1 -------------------------------------------------//
//    CLIENT:  Server, please advise me whenever the PURPLE ball is about to 
//             bounce to my window.

      if (!DdeClientTransaction (NULL,             // pointer to data passed to server
                                 0,                // data length
                                 hConvClient,      // conversation handle
                                 hszFS_1,          // item name
                                 CF_TEXT,          // clipboard format
                                 XTYP_ADVSTART |
                                 XTYPF_ACKREQ,     // start an ADVISE loop
                                 1000,             // time-out in one second
                                 NULL              // points to result flags
                                ))
      {
        LoadString (ghInstance, IDS_MSG6, szBuffer, sizeof(szBuffer)) ;
        MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
        DdeML_HandleError ();
      }

//--- Seek advise on Item #2 -------------------------------------------------//
//    CLIENT:  Server, please advise me whenever the GREEN  ball I bounced off
//             to you is about to bounce back to my window.

      if (!DdeClientTransaction (NULL,             // pointer to data passed to server
                                 0,                // data length
                                 hConvClient,      // conversation handle
                                 hszFS_2,          // item name
                                 CF_TEXT,          // clipboard format
                                 XTYP_ADVSTART |
                                 XTYPF_ACKREQ,     // start an ADVISE loop
                                 1000,             // time-out in one second
                                 NULL              // points to result flags
                                ))
      {
        LoadString (ghInstance, IDS_MSG7, szBuffer, sizeof(szBuffer)) ;
        MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
        DdeML_HandleError ();
      }

//--- Seek advise on Item #3 -------------------------------------------------//
//    CLIENT:  Server, please advise me whenever the PURPLE ball's speed changes.

      if (!DdeClientTransaction (NULL,             // pointer to data passed to server
                                 0,                // data length
                                 hConvClient,      // conversation handle
                                 hszFS_3,          // item name
                                 CF_TEXT,          // clipboard format
                                 XTYP_ADVSTART |
                                 XTYPF_ACKREQ,     // start an ADVISE loop
                                 1000,             // time-out in one second
                                 NULL              // points to result flags
                                ))
      {
        LoadString (ghInstance, IDS_MSG8, szBuffer, sizeof(szBuffer)) ;
        MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
        DdeML_HandleError ();
      }
     }

}


//---------------------------------------------------------------------------//
//  Title:                                                                   //
//      DdeML_InitStuff()                                                    //
//                                                                           //
//  Parameters:                                                              //
//      hWnd            - handle to the Window                               //
//                                                                           //
//  Return Value:                                                            //
//      FALSE if an error occurs.                                            //
//      Otherwise, defaults to TRUE.                                         //
//                                                                           //
//  Purpose:                                                                 //
//      DDEML Initialize routines.                                           //
//                                                                           //
//*--------------------------------------------------------------------------//

BOOL DdeML_InitStuff (HWND hWnd)
{
   char   szBuffer [81];

   lpDdeProc=MakeProcInstance ((FARPROC) DdeCallback, ghInstance);

   // Register CLIENT application with the DDEML.
   if (!DdeInitialize (&idInst,                   //pointer to instance identifier
                       (PFNCALLBACK)lpDdeProc,    //points to Callback function 
                       APPCMD_FILTERINITS|
                       CBF_FAIL_SELFCONNECTIONS|
                       CBF_FAIL_EXECUTES,         // array of command/filter flags
                       NULL))                     //RESERVED
   {
     // Create a handle for application's SERVICE Name.
     hszAppName= DdeCreateStringHandle (idInst, "LBs_Client", NULL);
     if (hszAppName == 0)
     {
       LoadString (ghInstance, IDS_CREATEMSG1, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer,"Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
       return FALSE;
     }

     // Create a handle for application's supported TOPIC Name.
     hszTopicName= DdeCreateStringHandle (idInst, "LBs_BallC", NULL);
     if (hszTopicName == 0)
     {
       LoadString (ghInstance, IDS_CREATEMSG2, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
       return FALSE;
     }

     // Create a handle for application's supported 1st ITEM Name.
     // This particular item is for the GREEN ball;
     // The server gets advised whenever the GREEN  ball hits the left  edge
     // of the CLIENT's window, about to bounce to the SERVER's window.

     hszFC_1= DdeCreateStringHandle (idInst, "FC_1", NULL);
     if (hszFC_1 == 0)   { LoadString (ghInstance, IDS_CREATEMSG3, szBuffer, sizeof(szBuffer)) ;
                           MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
                           DdeML_HandleError ();
                           return FALSE;
                         }
    
     // Create a handle for application's supported 2nd ITEM Name.
     // This particular item is for the PURPLE ball;
     // The server gets advised whenever the PURPLE ball hits the LEFT edge
     // of the CLIENT's window, about to bounce back to the SERVER's window.

     hszFC_2= DdeCreateStringHandle (idInst, "FC_2", NULL);
     if (hszFC_2 == 0)   { LoadString (ghInstance, IDS_CREATEMSG4, szBuffer, sizeof(szBuffer)) ;
                           MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
                           DdeML_HandleError ();
                           return FALSE;
                         }
  
     // Create a handle for application's supported 3rd ITEM Name.
     // This particular item is for the GREEN  ball's speed;
     // The server gets advised whenever the GREEN ball's speed changes.

     hszFC_3= DdeCreateStringHandle (idInst, "FC_3", NULL);
     if (hszFC_3 == 0)   { LoadString (ghInstance, IDS_CREATEMSG5, szBuffer, sizeof(szBuffer)) ;
                           MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
                           DdeML_HandleError ();
                           return FALSE;
                         }

      // Register the CLIENT's supported Service Name here.
      if (!DdeNameService (idInst,                 //instance identifier
                          hszAppName,             //string specifying SERVICE NAME
                          NULL,                   //RESERVED
                          DNS_REGISTER))          //Name-Service flags         
      {
        LoadString (ghInstance, IDS_MSG1, szBuffer, sizeof(szBuffer)) ;
        MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
        DdeML_HandleError ();
        return FALSE;
      } 

   //--- SERVER Stuff here... -------------------------------------// 

     // Create a handle for SERVER application's SERVICE Name.
     hszSvrAppName   = DdeCreateStringHandle (idInst, "LBs_Server", NULL);
     if (hszSvrAppName == 0)
     {
       LoadString (ghInstance, IDS_CREATEMSG6, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer,"Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
     }

     // Create a handle for SERVER application's TOPIC Name.
      hszSvrTopicName = DdeCreateStringHandle (idInst, "LBs_BallS" , NULL);
     if (hszSvrTopicName == 0)
     {
       LoadString (ghInstance, IDS_CREATEMSG7, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer,"Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
     }

     // Create a handle for SERVER's supported 1st ITEM Name.
     // This particular item is for the PURPLE ball;
     // The client wants to be advised whenever the PURPLE ball hits the right edge
     // of the SERVER's window, about to bounce to the CLIENT's window.

     hszFS_1         = DdeCreateStringHandle (idInst, "FS_1",       NULL);
     if (hszFS_1 == 0)
     {
       LoadString (ghInstance, IDS_CREATEMSG8, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer,"Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
     }
 
     // Create a handle for SERVER's supported 2nd ITEM Name.
     // This particular item is for the GREEN ball;
     // The client wants to be advised whenever the GREEN ball hits the right edge
     // of the SERVER's window, about to bounce back to the CLIENT's window.

     hszFS_2         = DdeCreateStringHandle (idInst, "FS_2",       NULL);
     if (hszFS_2 == 0)
     {
       LoadString (ghInstance, IDS_CREATEMSG9, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer,"Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
     }
 
     // Create a handle for SERVER's supported 3rd ITEM Name.
     // This particular item is for the PURPLE ball's speed;
     // The client wants to be advised whenever the PURPLE ball's speed changes.

     hszFS_3         = DdeCreateStringHandle (idInst, "FS_3",       NULL);
     if (hszFS_3 == 0)
     {
       LoadString (ghInstance, IDS_CREATEMSG10, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer,"Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
     }
 
     // After all string handles are created, we are ready to establish
     // our links with the CLIENT.

     DdeML_ConnectWithServer (hWnd);

   }
   else 
   {
     DdeML_HandleError ();
     return (FALSE);
   }



   return TRUE;
 }



//---------------------------------------------------------------------------//
//  Title:                                                                   //
//      DdeML_CleanupStuff ()                                                //
//                                                                           //
//  Parameters:                                                              //
//      hWnd            - handle to the Window                               //
//                                                                           //
//  Purpose:                                                                 //
//      DDEML exit routines.                                                 //
//                                                                           //
//*--------------------------------------------------------------------------//

void DdeML_CleanupStuff (HWND hWnd)
{
   char   szBuffer [81];

   if (hConvClient)                    // No need to disconnect if no conversation 
   {                                   // was established to begin with.

//--- Stop seeking advise on Item #1 -----------------------------------------//
//    CLIENT:  Server, will you please QUIT advising me on the PURPLE ball!!

        if (!DdeClientTransaction (NULL,             // pointer to data passed to server
                                   0,                // data length
                                   hConvClient,      // conversation handle
                                   hszFS_1,          // item name
                                   CF_TEXT,          // clipboard format
                                   XTYP_ADVSTOP,
                                   1000,             // time-out in one second
                                   NULL              // points to result flags
                                   ))
        {
          LoadString (ghInstance, IDS_MSG9, szBuffer, sizeof(szBuffer)) ;
          MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
          DdeML_HandleError ();
        }

//--- Stop seeking advise on Item #2 -----------------------------------------//
//    CLIENT:  Server, will you please QUIT advising me on the GREEN ball!!

        if (!DdeClientTransaction (NULL,             // pointer to data passed to server
                                   0,                // data length
                                   hConvClient,      // conversation handle
                                   hszFS_2,          // item name
                                   CF_TEXT,          // clipboard format
                                   XTYP_ADVSTOP,
                                   1000,             // time-out in one second
                                   NULL              // points to result flags
                                   ))
        {
          LoadString (ghInstance, IDS_MSG10, szBuffer, sizeof(szBuffer)) ;
          MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
          DdeML_HandleError ();
        }

//--- Stop seeking advise on Item #2 -----------------------------------------//
//    CLIENT:  Server, will you please QUIT advising me on the GREEN ball's   //
//             speed change!!                                                 //

        if (!DdeClientTransaction (NULL,             // pointer to data passed to server
                                   0,                // data length
                                   hConvClient,      // conversation handle
                                   hszFS_3,          // item name
                                   CF_TEXT,          // clipboard format
                                   XTYP_ADVSTOP,
                                   1000,             // time-out in one second
                                   NULL              // points to result flags
                                   ))
        {
          LoadString (ghInstance, IDS_MSG11, szBuffer, sizeof(szBuffer)) ;
          MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
          DdeML_HandleError ();
        }

     // Terminate conversation established above with SERVER.
     if (!DdeDisconnect (hConvClient))
     {
        LoadString (ghInstance, IDS_MSG3, szBuffer, sizeof(szBuffer)) ;
        MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
        DdeML_HandleError ();
     }
   }


// Whether or not a conv established, we'll have to delete string handles
// here anyway...

   // Free ServiceName string handle
   if (!DdeFreeStringHandle (idInst, hszSvrAppName))
   {
       LoadString (ghInstance, IDS_FREEMSG6, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
   }
                                                     
   // Free TopicName string handle
   if (!DdeFreeStringHandle (idInst, hszSvrTopicName))
   {
       LoadString (ghInstance, IDS_FREEMSG7, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
   }

   // Free SERVER's ItemName#1 string handle
   if (!DdeFreeStringHandle (idInst, hszFS_1))
   {
       LoadString (ghInstance, IDS_FREEMSG8, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
   }

   // Free SERVER's ItemName#2 string handle
   if (!DdeFreeStringHandle (idInst, hszFS_2))
   {
       LoadString (ghInstance, IDS_FREEMSG9, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
   }

   // Free SERVER's ItemName#3 string handle
   if (!DdeFreeStringHandle (idInst, hszFS_3))
   {
       LoadString (ghInstance, IDS_FREEMSG10, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
   }

   //------ CLIENT Stuff here... ------------------------------------//

   if (hConvServer)                    // If CLIENT will be destroyed, while Conv
                                       // with SERVER still on, will have to disconnect.
   {                                  
     // Terminate conversation established by the SERVER.
     if (!DdeDisconnect (hConvServer))
     {
        LoadString (ghInstance, IDS_MSG4, szBuffer, sizeof(szBuffer)) ;
        MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
        DdeML_HandleError ();
     }
   }
   
   
   // Unregister application's Service Name with the DDEML.
   if (!DdeNameService (idInst,                 //instance identifier
                        hszAppName,             //string specifying SERVICE NAME
                        NULL,                   //RESERVED
                        DNS_UNREGISTER))        //Name-Service flags 
   {                    
       LoadString (ghInstance, IDS_MSG2, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
   }

   // Free CLIENT's ServiceName string handle
   if (!DdeFreeStringHandle (idInst, hszAppName))
   {
       LoadString (ghInstance, IDS_FREEMSG1, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
   }

   // Free CLIENT's TopicName string handle
   if (!DdeFreeStringHandle (idInst, hszTopicName))
   {
       LoadString (ghInstance, IDS_FREEMSG2, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
   }
   
   // Free ItemName#1 string handle
   if (!DdeFreeStringHandle (idInst, hszFC_1))
   {
       LoadString (ghInstance, IDS_FREEMSG3, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
   }

   // Free ItemName#2 string handle
   if (!DdeFreeStringHandle (idInst, hszFC_2))
   {
       LoadString (ghInstance, IDS_FREEMSG4, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
   }

   // Free ItemName#3 string handle
   if (!DdeFreeStringHandle (idInst, hszFC_3))
   {
       LoadString (ghInstance, IDS_FREEMSG5, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
   }

   // Free up resources DDEML allocated for the application.
    if (!DdeUninitialize(idInst))
   {
       LoadString (ghInstance, IDS_MSG5, szBuffer, sizeof(szBuffer)) ;
       MessageBox (hWnd, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
       DdeML_HandleError ();
   }
 }



//---------------------------------------------------------------------------//
//  Title:                                                                   //
//      DdeCallback ()                                                       //
//                                                                           //
//  Parameters:                                                              //
//      wType       - transaction type                                       //
//      wFmt        - clipboard data format                                  //
//      hConv       - handle to the conversation                             //
//      hsz1        - handle to a string                                     //
//      hsz2        - handle to a string                                     //
//      hData       - handle to a global memory object                       //
//      dwData1     - transaction-specific data                              //
//      dwData2     - transaction-specific data                              //
//                                                                           //
//  Purpose:                                                                 //
//      The DDE Callback Function that processes all transactions passed     //
//  by the DDEML.                                                            //
//      This is the equivalent of a window's Window procedure that processes //
//  all messages passed to it by the Windows manager.                        //
//*--------------------------------------------------------------------------//


HDDEDATA EXPENTRY DdeCallback (UINT wType,      // transaction type
                               UINT wFmt,       // clipboard data format
                               HCONV hConv,     // handle to the conversation
                               HSZ hsz1,        // handle to a string
                               HSZ hsz2,        // handle to a string
                               HDDEDATA hData,  // handle to a global memory object
                               DWORD dwData1,   // transaction-specific data
                               DWORD dwData2)  // transaction-specific data
{
 typedef struct tagBALLPROP {
        float _yCenter;  
        float _cxMove;
        float _cyMove;
        float _someIncr;
       } BALLPROP;

 BALLPROP    FS_Ball;

  switch (wType)
  {
    case XTYP_DISCONNECT: 
     DrawOtherBall = FALSE;                // Update variables used internally
     bStopAdvising = TRUE;                 // when notified of the end of conversation.

     cx1Move =  max (1, cxRadius / SpeedDiv);                 
     if (!DrawMyBall)
     {
       DrawMyBall = TRUE;
       x1Center   = cxRadius;        
     }
     else if (x1Center - cxRadius <= 0)
       x1Center = cxRadius;

     if (hConvServer == hConv)        // Conversation with server as SERVER
        hConvServer = 0;              // is about to be disconnected.

     else if (hConvClient == hConv)   // Conversation with server as CLIENT
        hConvClient = 0;              // is about to be disconnected.

     return (HDDEDATA) NULL;

    case XTYP_CONNECT :               // hsz1 = Topic Name;  
                                      // hsz2 = Service name
      if ((!DdeCmpStringHandles (hsz1, hszTopicName)) && 
          (!DdeCmpStringHandles (hsz2, hszAppName)))       
         return (TRUE);               // CLIENT says OK to conversation.  
      else 
         return (FALSE);

    case XTYP_CONNECT_CONFIRM:        // Follow-up transaction to XTYP_CONNECT
      hConvServer = hConv;            // Save handle to conversation.
      return (HDDEDATA) NULL;
 
    // Sent in response to SERVER's request for an XTYP_ADVSTART 
    case XTYP_ADVSTART:
      if ((hConvServer == hConv) &&         // hConv = handle to conversation
          (!DdeCmpStringHandles (hsz1,      // hsz1  = topic name
                                 hszTopicName)) &&         
                                            // hsz2  = Item name
          ((!DdeCmpStringHandles (hsz2, hszFC_1)) ||
           (!DdeCmpStringHandles (hsz2, hszFC_2)) ||
           (!DdeCmpStringHandles (hsz2, hszFC_3)))
         )
      {
        bStopAdvising = FALSE;
        return (TRUE);                 // CLIENT:  Yes, I support this Topic/Item
      }                                //          name pair you want to be advised on.
      else
                                       // CLIENT:  Sorry, I don't support that.
        return (FALSE);


    // Sent in response to SERVER's request for an XTYP_ADVSTOP 
    case XTYP_ADVSTOP:
      DrawOtherBall  = FALSE;         // Updating all my variables here...
      bStopAdvising  = TRUE;

      hDC = GetDC (ghWnd);           // Erase SERVER's ball on CLIENT's window.
      PatBlt (hDC, (int)(x2Center -cx2Move - cx2Total / 2), 
                   (int)(y2Center -cy2Move - cy2Total / 2), 
                   (int)cx2Total, (int)cy2Total, BLACKNESS);
      ReleaseDC (ghWnd, hDC);

      return (HDDEDATA) NULL;

    // Sent when CLIENT calls DdePostAdvise() to advise the SERVER on
    // some data change.
    case XTYP_ADVREQ:
    {  
      HDDEDATA  tmphData;

      if ((hConvServer == hConv) &&         // hConv = handle to conversation
          (!DdeCmpStringHandles (hsz1,      // hsz1  = topic name
                                 hszTopicName)) &&         
          (!DdeCmpStringHandles (hsz2,      // hsz2  = Item name
                                 hszFC_1)))                
      { 
       FS_Ball._yCenter = y1Center;
       FS_Ball._cxMove  = cx1Move;
       FS_Ball._cyMove  = cy1Move;
       FS_Ball._someIncr = someIncrement;
  
      // CLIENT:  Server, here's the data you requested on the GREEN  Ball.
       tmphData = DdeCreateDataHandle (idInst,
                                    (LPBYTE)&FS_Ball,
                                    sizeof (FS_Ball),
                                    0L,
                                    (HSZ)hszFC_1,
                                    CF_TEXT,
                                    0);
       if (!tmphData)
       {
         DdeML_HandleError ();
         break;
       }
                
       return (tmphData);
       break;
      } 

      if ((hConvServer == hConv) &&         // hConv = handle to conversation
          (!DdeCmpStringHandles (hsz1,      // hsz1  = topic name
                                 hszTopicName)) &&         
          (!DdeCmpStringHandles (hsz2,      // hsz2  = Item name
                                 hszFC_2)))                
      { 
       FS_Ball._yCenter = y2Center;
       FS_Ball._cxMove  = cx2Move;
       FS_Ball._cyMove  = cy2Move;
       FS_Ball._someIncr = someIncrement2;
  
      // CLIENT:  Server, here's the data you requested on the PURPLE Ball.
       tmphData = DdeCreateDataHandle (idInst,
                                    (LPBYTE)&FS_Ball,
                                    sizeof (FS_Ball),
                                    0L,
                                    (HSZ)hszFC_2,
                                    CF_TEXT,
                                    0);
       if (!tmphData)
       {
         DdeML_HandleError ();
         break;
       }
                
       return (tmphData);
       break;
      } 

      if ((hConvServer == hConv) &&         // hConv = handle to conversation
          (!DdeCmpStringHandles (hsz1,      // hsz1  = topic name
                                 hszTopicName)) &&         
          (!DdeCmpStringHandles (hsz2,      // hsz2  = Item name
                                 hszFC_3)))                
      { 
       FS_Ball._cxMove   = cx1Move;
       FS_Ball._someIncr = someIncrement;
  
      // CLIENT:  Server, here's the data you requested on the GREEN Ball's
      //          speed change.
       tmphData = DdeCreateDataHandle (idInst,
                                    (LPBYTE)&FS_Ball,
                                    sizeof (FS_Ball),
                                    0L,
                                    (HSZ)hszFC_3,
                                    CF_TEXT,
                                    0);
       if (!tmphData)
       {
         DdeML_HandleError ();
         break;
       }
                
       return (tmphData);
       break;
      } 

     return (HDDEDATA) NULL;

      }      


   case XTYP_ADVDATA:
    {
       if ((hConvClient == hConv) &&      // Handle to Conversation
           (!DdeCmpStringHandles (hsz1, 
                                  hszSvrTopicName)) &&   
           (!DdeCmpStringHandles (hsz2, 
                                  hszFS_1)))
       {
         DdeGetData (hData,               // Copy the data CLIENT sent me
                     (LPBYTE)&FS_Ball,    // to my local structure FS_Ball.
                      sizeof (FS_Ball),
                      0);

          y2Center       = FS_Ball._yCenter;   // CLIENT updates its variables
          cx2Move        = FS_Ball._cxMove;    // here accordingly.
          cy2Move        = FS_Ball._cyMove;  
          someIncrement2 = FS_Ball._someIncr;

          SentMessage2   = TRUE;
          DrawOtherBall  = TRUE;
          x2Center       = -cxRadius;
       }

       if ((hConvClient == hConv) &&      // Handle to Conversation
           (!DdeCmpStringHandles (hsz1, 
                                  hszSvrTopicName)) && 
           (!DdeCmpStringHandles (hsz2, hszFS_2)))
       {
         DdeGetData (hData,               // Copy the data SERVER sent me
                     (LPBYTE)&FS_Ball,    // to my local structure FS_Ball.
                      sizeof (FS_Ball),
                      0);

          y1Center       = FS_Ball._yCenter;   // CLIENT updates its variables
          cx1Move        = FS_Ball._cxMove;    // here accordingly.
          cy1Move        = FS_Ball._cyMove;  
          someIncrement  = FS_Ball._someIncr;

          SentMessage    = TRUE;
          DrawMyBall     = TRUE;
          x1Center       = -cxRadius;
       }

       if ((hConvClient == hConv) &&      // Handle to Conversation
           (!DdeCmpStringHandles (hsz1, 
                                  hszSvrTopicName)) &&   
           (!DdeCmpStringHandles (hsz2, hszFS_3)))
       {
         DdeGetData (hData,               // Copy the data SERVER sent me
                     (LPBYTE)&FS_Ball,    // to my local structure FS_Ball.
                      sizeof (FS_Ball),
                      0);
                                                       

          // cxMove coming from SERVER is always >0
          // Change here if appropriate.          

          if (cx2Move < 0) cx2Move = -FS_Ball._cxMove; 
                     else  cx2Move =  FS_Ball._cxMove;  

          someIncrement2 = FS_Ball._someIncr;
       }

       // CLIENT:  Okay, Server, I received your data fine.
        return (DDE_FACK);
     }              
              
    default: return (HDDEDATA)NULL;
  }
}





