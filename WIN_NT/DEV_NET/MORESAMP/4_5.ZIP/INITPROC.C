//----------------------------------------------------------------------------//
//  FileName: INITPROC.C                                                      //
//                                                                            //
//  Source file for all initialization stuff.                                 //
//                                                                            //
//  Description of Functions:                                                 //
//                                                                            //
//      InitApplication() - Registers the app's window class.                 //
//      InitInstance()    - Creates and displays the app's initial window.    //
//                          All DDEML initialization routines are done here.  //
//                                                                            //
//  Developed by:  Lanie Biagan                                               //
//  Written by Microsoft Product Support Services, Windows Developer Support  //
//                                                                            //
//  Copyright (C) 1991 Microsoft Corporation.  All rights reserved.           //
//----------------------------------------------------------------------------//
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <WINDOWS.H>
#include <DDEML.H>
#include "GLOBALS.H"
#include "BALLCLI.H"
#include "INITPROC.H"
#include "WNDPROC.H"
#include "DdePROC.H"

//*--------------------------------------------------------------------------*//
//| Title:                                                                   *//
//|    InitApplication                                                       *//
//|                                                                          *//
//| Parameters:                                                              *//
//|    hInstance       - Integer which uniquely identifies this instance     *//
//|                        of the application (hInstance > 0)                *//
//|    hPrevInstance   - Integer identifier of a previous instance of the    *//
//|                        application (hPrevInstance == NULL if no previous *//
//|                        instance exists)                                  *//
//|                                                                           *//
//| Purpose:                                                                 *//
//|    Registers the applications window class(es) if no previous instance of*//
//|    the application has already done so.                                  *//
//*--------------------------------------------------------------------------*//


#define DEFBKGDCOLOR (COLOR_WINDOW + 1)
BOOL InitApplication(HANDLE hInstance,
                     HANDLE hPrevInstance)
{
    WNDCLASS  wc;
    char   szBuffer [81];

    
    // If a previous instance of this application is already loaded,
    // then exit:  let's make life a little simple here.
    if (hPrevInstance)
    {
        LoadString (hInstance, IDS_MSG12, szBuffer, sizeof(szBuffer)) ;
        MessageBox (NULL, szBuffer, "Oops!!", MB_ICONEXCLAMATION|MB_OK);
        return FALSE;
    }
    

    // The window class is not registered yet, so we have to fill a
    // window class structure with parameters that describe the       
    // window class.                                                           
    wc.lpszClassName = "ClientClass";   // String identifier for the class  
    wc.lpfnWndProc = MainWndProc;       // Message handling procedure used
                                        //    by windows of this class
    wc.style = 0;                       // Use default class styles
    wc.lpszMenuName = "MyMenu";         // Default menu for this class
    wc.hIcon = NULL;                    // NULL Icon will send WM_PAINT message
                                        // to your window even if it's ICONized,
                                        // and we'd like to have that feature!!

    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);  // Use a pre-defined cursor
    wc.hbrBackground = GetStockObject (BLACK_BRUSH); // Use Black bkgd color
    wc.hInstance     = hInstance;       // Instance which registered the class
    wc.cbClsExtra    = 0;               // No user-defined extra-bytes
                                        //    associated with this class
    wc.cbWndExtra    = 0;               // No user-defined extra-bytes
                                        //    associated with each window of
                                        //    this class

    // Register the window class and return success/failure code.
    return (RegisterClass(&wc));
}



//*--------------------------------------------------------------------------*//
//| Title:                                                                   *//
//|     InitInstance                                                         *//
//|                                                                          *//
//| Parameters:                                                              *//
//|     hInstance   - Integer which uniquely identifies this instance        *//
//|                         of the application (hInstance > 0)               *//
//|     nCmdShow    - Integer value specifying how to start app.,            *//
//|                         (Iconic [7] or Normal [1,5])                     *//
//|                                                                          *//
//| Purpose:                                                                 *//
//|     Creates and displays the application's initial window(s).            *//
//*--------------------------------------------------------------------------*//

BOOL InitInstance(  HANDLE  hInstance,
                    int     nCmdShow)
{
    HWND    hWnd;                       // temporary window handle             
    BOOL    bStatus = FALSE;            // holds return status for function
    
    // Save the instance handle in global variable, which will be used in  
    // many subsequent calls from this application to Windows            
    ghInstance = hInstance;

    // Create a main window for this application instance
    hWnd = CreateWindow(
        "ClientClass",                  // Name of the window's class
	"BALLCLI CLIENT App",			// Text for window caption
        WS_OVERLAPPED |
        WS_CAPTION |
        WS_SYSMENU |
        WS_THICKFRAME |
        WS_MINIMIZEBOX,                 // Window style   (No MAX Button!)                  
        215,                            // Default horizontal position      
        100,                            // Default vertical position        
        100,                            // Default width                   
        300,                            // Default height                   
        NULL,                           // Overlapped windows have no parent
        NULL,                           // Use the window class menu        
        hInstance,                      // This instance owns this window  
        NULL                            // Pointer (not used)
    );

   if (!SetTimer (hWnd, 1, 20, NULL))
   {
       MessageBox (hWnd, "Too many clocks or timers!!",
                         NULL, MB_ICONEXCLAMATION|MB_OK);
       return FALSE;
   }
   
   if (!DdeML_InitStuff (hWnd))        // All initialization routines for DDEML
       return FALSE;                   // defined in DDEProc.C module.


    // If the window was successfully created, make the window visible,
    // update its client area, and return "success".  If the window
    // was not created, return "failure"
   if (hWnd)
        { 
        ghWnd = hWnd;

        ShowWindow (hWnd, nCmdShow); 
        UpdateWindow(hWnd);         // Tell window to paint client area
        
        bStatus = TRUE;             // Indicate success, default is failure
        }

   return bStatus;                  // Return status code
}




