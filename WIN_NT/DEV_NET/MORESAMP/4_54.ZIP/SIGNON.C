//*************************************************************
//  File name: main.c
//
//  Description: 
//      WinMain and the WndProcs
//
//  History:    Date       Author     Comment
//              12/12/91   MSM        Created
//
// Written by Microsoft Product Support Services, Windows Developer Support
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//*************************************************************

#include "global.h"

HANDLE  ghInst      = NULL;
HWND    ghWndMain   = NULL;

char    szMainMenu[]    = "MainMenu";
char    szMainClass[]   = "MainClass";

//*************************************************************
//
//  WinMain
//
//  Purpose:
//              Entry point for all windows apps
//
//
//  Parameters:
//      HANDLE hInstance
//      HANDLE hPrevInstance
//      LPSTR lpCmdLine
//      int nCmdShow
//      
//
//  Return: (int PASCAL)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//              12/12/91   MSM        Created
//
//*************************************************************

int PASCAL WinMain (HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    MSG msg;
    HWND hDlg;
    FARPROC lpProc;

    if (!hPrevInstance && !InitApplication(hInstance))
            return (FALSE);       

    if (!InitInstance(hInstance, nCmdShow))
        return (FALSE);

    // Create a modeless dialog that contains the sign on screen
    lpProc = MakeProcInstance(Signon, hInstance);
    hDlg = CreateDialog( hInstance, "SIGNON_DLG", ghWndMain, lpProc );
    if (hDlg)
    {
        // Show the dialog and then return activation back to the parent
        ShowWindow( hDlg, SW_SHOWNORMAL );
        SetActiveWindow( ghWndMain );
    }
    else
        return FALSE;

    // Do message loop
    while (GetMessage(&msg, NULL, NULL, NULL))
    {
        // Watch for all messages that are for the signon dialog
        if (hDlg && IsDialogMessage(hDlg, &msg))    // Is for the dialog
            continue;                               // Then skip Trans/Disp

        if (hDlg)                                   // Is the dialog still up
        {
            switch (msg.message)                    // Then look for msgs
            {                                       // That will cause the
                case WM_LBUTTONDOWN:                // signon to go away
                case WM_RBUTTONDOWN:
                case WM_NCLBUTTONDOWN:
                case WM_NCRBUTTONDOWN:
                case WM_KEYDOWN:
                case WM_SYSKEYDOWN:
                    // Kill the sigon dialog
                    DestroyWindow( hDlg );
                    hDlg = NULL;
                    FreeProcInstance( lpProc );
                break;
            }
        }
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return (msg.wParam);

} //*** WinMain

//*************************************************************
//
//  MainWndProc
//
//  Purpose:
//              Main Window procedure
//
//
//  Parameters:
//      HWND hWnd
//      unsigned msg
//      WORD wParam
//      LONG lParam
//      
//
//  Return: (long FAR PASCAL)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//              12/12/91   MSM        Created
//
//*************************************************************

long FAR PASCAL MainWndProc (HWND hWnd, unsigned msg, WORD wParam, LONG lParam)
{
    FARPROC lpProc;

    switch (msg) 
    {
        case WM_COMMAND: 
            switch ( wParam )
            {
                case IDM_ABOUT:
                    // Bring up the about box
                    lpProc = MakeProcInstance(About, ghInst);
                    DialogBox(ghInst, "AboutBox", hWnd, lpProc);    
                    FreeProcInstance(lpProc);
                break;
            }
        break;

        case WM_DESTROY:
            PostQuitMessage(0);
        break;
    }
    return (DefWindowProc(hWnd, msg, wParam, lParam));

} //*** MainWndProc

//*************************************************************
//
//  About
//
//  Purpose:
//              the About dialog box procedure
//
//
//  Parameters:
//      HWND hDlg
//      unsigned msg
//      WORD wParam
//      LONG lParam
//      
//
//  Return: (BOOL FAR PASCAL)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//              12/12/91   MSM        Created
//
//*************************************************************

BOOL FAR PASCAL About (HWND hDlg, unsigned msg, WORD wParam, LONG lParam)
{
    switch (msg) 
    {
        case WM_INITDIALOG: 
            return (TRUE);

        case WM_COMMAND:
            if (wParam == IDOK || wParam == IDCANCEL) 
            {
                EndDialog(hDlg, TRUE);         
                return (TRUE);
            }
        break;
    }
    return (FALSE);                  /* Didn't process a message    */

} //*** About

//*************************************************************
//
//  Signon
//
//  Purpose:
//              the Signon dialog box procedure
//
//
//  Parameters:
//      HWND hDlg
//      unsigned msg
//      WORD wParam
//      LONG lParam
//      
//
//  Return: (BOOL FAR PASCAL)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//              12/12/91   MSM        Created
//
//*************************************************************

BOOL FAR PASCAL Signon (HWND hDlg, unsigned msg, WORD wParam, LONG lParam)
{
    if (msg==WM_INITDIALOG) 
        return TRUE;

    return FALSE;

} //*** Signon

//*** EOF: main.c
