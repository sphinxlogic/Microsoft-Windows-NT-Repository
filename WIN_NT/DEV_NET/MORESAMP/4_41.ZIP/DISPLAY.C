/****************************************************************************

	 FILE: DISPLAY.C

      PURPOSE: Handles of the output to the listbox in the main window.

    FUNCTIONS: DisplayResult - Main function that contains the loop that
			       ultimately gets the information displayed.

	       IntData	     - The following function support DisplayResult
	       WordData      - for each individual data type.  The are
	       DWordData     - logically grouped (See loop below).
	       PointData     -
	       RectData      -
	       GuideData     -

	       Language      -
	       User	     -
	       SYEData	     -
		 ConvertSYEArray - These two support the function SYEData.
		 ConvertSYV	 -
	       SYCData	     -
	       SYVData	     -

	       rgbfAlcData   -
	       rglpdfData    -
	       ReservedData  -
	       HotSpots      -


****************************************************************************/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "windows.h"
#include "penwin.h"
#include "globals.h"
#include "protos.h"

//**************************************************************************
// Private global variables used only in this file.

// This variable is used to keep track of the horizontal extent of a string
// that will be displayed.  Each time through the loop the length of the
// current string is checked against this value to determine if a horizontal
// scroll bar should be displayed or not.
DWORD gdwExtent=0;
//**************************************************************************

//**************************************************************************
//
//  Function: DisplayResult
//
//   Purpose: To loop through all the possible selections and display the
//	      ones that are selected.
//
//   Returns: retruns TRUE
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
BOOL NEAR PASCAL DisplayResult(void)
{
   int iMain,iTimes;	 // counters for loop
   LPOPTIONS lpDisplay;  // pntr to information
   HDC hdc=GetDC(ghwnd); // needs this
   BOOL bDone=FALSE;	 // First RC options, second RCRESULT options

   gdwExtent=0;  // initialize to zero length

   // Set up the main list box so it will recieve information
   SendMessage(ghLB,LB_RESETCONTENT,0,0L);
   SendMessage(ghLB,WM_SETREDRAW,FALSE,0L);
   SendMessage(ghLB,LB_SETHORIZONTALEXTENT,0,0L);

Back_Again:
   if(!bDone)
   {
      iTimes=NUMOF_RC_OPTIONS;
      lpDisplay=gRc_Opt;
   }
   else
   {
      iTimes=NUMOF_RCR_OPTIONS;
      lpDisplay=gRcR_Opt;
   }

   for(iMain=0;iMain<iTimes;iMain++)
   {
      if(lpDisplay[iMain].bSelect)  // then display item...
      {
	 WORD wMajorType,wMinorType,wFlags;

	 wMajorType=lpDisplay[iMain].wType&(~TYPE_FLAGS)&TYPE_MAJOR;
	 wMinorType=lpDisplay[iMain].wType&(~TYPE_FLAGS)&(~TYPE_MAJOR);
	 wFlags    =lpDisplay[iMain].wType&TYPE_FLAGS;
	 switch(wMajorType)
	 {
	    case TYPE_BASIC:
	    case TYPE_HEX:
	       switch(wMinorType)
	       {
		  case TYPE_INT:
		     IntData(&lpDisplay[iMain],hdc,wFlags);
		     break;
		  case TYPE_WORD:
		     WordData(&lpDisplay[iMain],hdc,wFlags);
		     break;
		  case TYPE_DWORD:
		     DWordData(&lpDisplay[iMain],hdc,wFlags);
		     break;
		  case TYPE_POINT:
		     PointData(&lpDisplay[iMain],hdc,wFlags);
		     break;
		  case TYPE_RECT:
		     RectData(&lpDisplay[iMain],hdc,wFlags);
		     break;
		  case TYPE_GUIDE:
		     GuideData(&lpDisplay[iMain],hdc,wFlags);
		     break;
	       }
	       break;
/*
	    case TYPE_HEX:
	       {
		  switch(wMinorType)
		  {
		     case TYPE_WORD:
			WordData(&lpDisplay[iMain],hdc,wFlags);
			break;
		     case TYPE_DWORD:
			DWordData(&lpDisplay[iMain],hdc,wFlags);
			break;
		     default:
			break;
		  }
	       }
	       break;
*/
	    case TYPE_POINTER:
	       {
		  switch(wMinorType)
		  {
		     case TYPE_LANGUAGE:
			Language(&lpDisplay[iMain],hdc,wFlags);
			break;
		     case TYPE_USER:
			User(&lpDisplay[iMain],hdc,wFlags);
			break;
		     case TYPE_SYE:
			SYEData(&lpDisplay[iMain],hdc,wFlags);
			break;
		     case TYPE_SYC:
			SYCData(&lpDisplay[iMain],hdc,wFlags);
			break;
		     case TYPE_SYV:
			SYVData(&lpDisplay[iMain],hdc,wFlags);
			break;
		     default:
			break;
		  }
	       }
	       break;
	    case TYPE_OTHER:
	       {
		  switch(wMinorType)
		  {
		     case TYPE_ALC:
			rgbfAlcData(&lpDisplay[iMain],hdc,wFlags);
			break;
		     case TYPE_DF:
			rglpdfData(&lpDisplay[iMain],hdc,wFlags);
			break;
		     case TYPE_RES:
			ReservedData(&lpDisplay[iMain],hdc,wFlags);
			break;
		     case TYPE_HOT:  // RCRESULT structure element
			HotSpots(&lpDisplay[iMain],hdc,wFlags);
			break;
		     default:
			break;
		  }
	       }
	       break;
	    default:
	       break;
	 }
      }
   }
   // After displaying all the RC options go back and display the RCRESULT options
   if(!bDone)
   {
      bDone=TRUE;
      goto Back_Again;
   }

   // retore and return
   ReleaseDC(ghwnd,hdc);
   SendMessage(ghLB,LB_SETHORIZONTALEXTENT,(WPARAM)(gdwExtent+10),0L);
   SendMessage(ghLB,WM_SETREDRAW,TRUE,0L);
   return TRUE;
}

//**************************************************************************
//
// The following six functions fupport TYPE_BASIC & TYPE_HEX.
//
//**************************************************************************



//**************************************************************************
//
//  Function: IntData
//
//   Purpose: Supports the DisplayResult function
//
//   Returns: retruns void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL IntData(LPOPTIONS lpChoice,HDC hdc,WORD wFlags)
{
   char szOut[80],szTmp[80];
   int info=*(int far *)lpChoice->lpData;

   wsprintf((LPSTR)szOut,(LPSTR)lpChoice->npStr);
   lstrcat((LPSTR)szOut,"  ");

   wsprintf((LPSTR)szTmp,(LPSTR)lpChoice->npFrmtStr,info);
   lstrcat((LPSTR)szOut,(LPSTR)szTmp);
   SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
   gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
			      lstrlen((LPSTR)szOut)),
		gdwExtent);

   if( gbFullDis && wFlags )
   {
      NPOPTION_STR npStrings=lpChoice->npAlphaStr;
      while(npStrings->npStr!=NULL)
      {
	 if(npStrings->wValue==(npStrings->wValue & info))
	 {
	    wsprintf((LPSTR)szOut,"        ");
	    lstrcat((LPSTR)szOut,(LPSTR)npStrings->npStr);
	    gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
				       lstrlen((LPSTR)szOut)),
			 gdwExtent);

	    SendMessage(ghLB,LB_ADDSTRING,0,
			(LONG)(LPSTR)szOut);
	 }
	 npStrings++;
      }
   }

}

//**************************************************************************
//
//  Function: WordData
//
//   Purpose: Supports the DisplayResult function
//
//   Returns: retruns void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL WordData(LPOPTIONS lpChoice,HDC hdc,WORD wFlags)
{
   char szOut[80],szTmp[80];
   WORD winfo=*(WORD far *)lpChoice->lpData;

   wsprintf((LPSTR)szOut,(LPSTR)lpChoice->npStr);
   lstrcat((LPSTR)szOut,"  ");

   wsprintf((LPSTR)szTmp,(LPSTR)lpChoice->npFrmtStr,winfo);
   lstrcat((LPSTR)szOut,(LPSTR)szTmp);
   SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
   gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
			      lstrlen((LPSTR)szOut)),
		gdwExtent);

   if( gbFullDis && wFlags )
   {
      NPOPTION_STR npStrings=lpChoice->npAlphaStr;
      while(npStrings->npStr!=NULL)
      {
	 if(npStrings->wValue==0)
	 {
	    if(npStrings->wValue==winfo)
	    {
	       wsprintf((LPSTR)szOut,"        ");
	       lstrcat((LPSTR)szOut,(LPSTR)npStrings->npStr);
	       gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
					  lstrlen((LPSTR)szOut)),
			    gdwExtent);

	       SendMessage(ghLB,LB_ADDSTRING,0,
			   (LONG)(LPSTR)szOut);
	    }
	    npStrings++;
	 }
	 else
	 {
	    if(npStrings->wValue==(npStrings->wValue & winfo))
	    {
	       wsprintf((LPSTR)szOut,"        ");
	       lstrcat((LPSTR)szOut,(LPSTR)npStrings->npStr);
	       gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
					  lstrlen((LPSTR)szOut)),
			    gdwExtent);

	       SendMessage(ghLB,LB_ADDSTRING,0,
			   (LONG)(LPSTR)szOut);
	    }
	    npStrings++;
	 }
      }
   }

}

//**************************************************************************
//
//  Function: DWordData
//
//   Purpose: Supports the DisplayResult function
//
//   Returns: retruns void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL DWordData(LPOPTIONS lpChoice,HDC hdc,WORD wFlags)
{
   char szOut[80],szTmp[80];
   DWORD dwinfo=*(DWORD far *)lpChoice->lpData;

   wsprintf((LPSTR)szOut,(LPSTR)lpChoice->npStr);
   lstrcat((LPSTR)szOut,"  ");

   wsprintf((LPSTR)szTmp,(LPSTR)lpChoice->npFrmtStr,dwinfo);
   lstrcat((LPSTR)szOut,(LPSTR)szTmp);
   SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
   gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
			      lstrlen((LPSTR)szOut)),
		gdwExtent);

   if( gbFullDis && wFlags )
   {
      NPOPTION_STR npStrings=lpChoice->npAlphaStr;
      while(npStrings->npStr!=NULL)
      {
	 if(npStrings->wValue==0)
	 {
	    if(npStrings->wValue==dwinfo)
	    {
	       wsprintf((LPSTR)szOut,"        ");
	       lstrcat((LPSTR)szOut,(LPSTR)npStrings->npStr);
	       gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
					  lstrlen((LPSTR)szOut)),
			    gdwExtent);

	       SendMessage(ghLB,LB_ADDSTRING,0,
			   (LONG)(LPSTR)szOut);
	    }
	    npStrings++;
	 }
	 else
	 {
	    if(npStrings->wValue==(npStrings->wValue & dwinfo))
	    {
	       wsprintf((LPSTR)szOut,"        ");
	       lstrcat((LPSTR)szOut,(LPSTR)npStrings->npStr);
	       gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
					  lstrlen((LPSTR)szOut)),
			    gdwExtent);

	       SendMessage(ghLB,LB_ADDSTRING,0,
			   (LONG)(LPSTR)szOut);
	    }
	    npStrings++;
	 }
      }
   }

}

//**************************************************************************
//
//  Function: PointData
//
//   Purpose: Supports the DisplayResult function
//
//   Returns: retruns void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL PointData(LPOPTIONS lpChoice,HDC hdc,WORD wFlags)
{
   char szOut[80],szTmp[80];
   LPPOINT lppnt=(LPPOINT)lpChoice->lpData;

   wsprintf((LPSTR)szOut,(LPSTR)lpChoice->npStr);
   lstrcat((LPSTR)szOut,"  ");

   wsprintf((LPSTR)szTmp,(LPSTR)lpChoice->npFrmtStr,
	    lppnt->x,lppnt->y);
   lstrcat((LPSTR)szOut,(LPSTR)szTmp);
   SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
   gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
			      lstrlen((LPSTR)szOut)),
		gdwExtent);
}

//**************************************************************************
//
//  Function: RectData
//
//   Purpose: Supports the DisplayResult function
//
//   Returns: retruns void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL RectData(LPOPTIONS lpChoice,HDC hdc,WORD wFlags)
{
   char szOut[80],szTmp[80];
   LPRECT lprect=(LPRECT)lpChoice->lpData;

   wsprintf((LPSTR)szOut,(LPSTR)lpChoice->npStr);
   lstrcat((LPSTR)szOut,"  ");

   wsprintf((LPSTR)szTmp,(LPSTR)lpChoice->npFrmtStr,
	    lprect->top,lprect->left,
	    lprect->right,lprect->bottom);

   lstrcat((LPSTR)szOut,(LPSTR)szTmp);
   SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
   gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
			      lstrlen((LPSTR)szOut)),
		gdwExtent);
}

//**************************************************************************
//
//  Function: GuideData
//
//   Purpose: Supports the DisplayResult function
//
//   Returns: retruns void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL GuideData(LPOPTIONS lpChoice,HDC hdc,WORD wFlags)
{
   char szOut[80],szTmp[80];
   NPOPTION_STR npOptStrs;

   wsprintf((LPSTR)szOut,(LPSTR)lpChoice->npStr);
   SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
   gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
			      lstrlen((LPSTR)szOut)),
		gdwExtent);

   if(gbFullDis)
   {
      int k=0;
      UINT far *lpi=(UINT far *)lpChoice->lpData;
      npOptStrs=(NPOPTION_STR)lpChoice->npAlphaStr;
      while(npOptStrs[k].wValue)
      {
	 // walk through the alpha string structure extracting
	 // the text for the field and then fill in the value
	 // associated with it before it's displayed.

	 lstrcpy((LPSTR)szOut,(LPSTR)npOptStrs[k].npStr);
	 lstrcat((LPSTR)szOut,(LPSTR)"  ");
	 wsprintf((LPSTR)szTmp,"%i",lpi[k]);
	 lstrcat((LPSTR)szOut,(LPSTR)szTmp);
	 SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
	 gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
				    lstrlen((LPSTR)szOut)),
		      gdwExtent);
	 k++;
      }

   }
}



//**************************************************************************
//
// The following Seven functions support TYPE_POINTER.	(Two support the
// SYEData function.
//
//**************************************************************************

//**************************************************************************
//
//  Function: Language
//
//   Purpose: Supports the DisplayResult function
//
//   Returns: retruns void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL Language(LPOPTIONS lpChoice,HDC hdc,WORD wFlags)
{
   char szOut[80+80];
   LPSTR lpi=(LPSTR)lpChoice->lpData;
   LPSTR lpOut=&szOut[0];

   wsprintf((LPSTR)szOut,(LPSTR)lpChoice->npStr);
   lstrcat((LPSTR)szOut,"  ");

   lpOut+=lstrlen(lpOut);
   while(*lpi!=NULL)
   {
      if( (*lpi<' ')||(*lpi>'~') )
	 *lpOut='.';
      else
	 *lpOut=*lpi;

      lpOut++;
      lpi++;
   }
   *lpOut=NULL;
   gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
			       lstrlen((LPSTR)szOut)),
		gdwExtent);
   SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
}


//**************************************************************************
//
//  Function: User
//
//   Purpose: Supports the DisplayResult function
//
//   Returns: retruns void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL User(LPOPTIONS lpChoice,HDC hdc,WORD wFlags)
{
   char szOut[80+80];
   LPSTR lpi=(LPSTR)lpChoice->lpData;
   LPSTR lpOut=&szOut[0];

   wsprintf((LPSTR)szOut,(LPSTR)lpChoice->npStr);
   lstrcat((LPSTR)szOut,"  ");

   lpOut+=lstrlen(lpOut);
   while(*lpi!=NULL)
   {
      if( (*lpi<' ')||(*lpi>'~') )
	 *lpOut='.';
      else
	 *lpOut=*lpi;
      lpOut++;
      lpi++;
   }
   *lpOut=NULL;
   gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
			       lstrlen((LPSTR)szOut)),
		gdwExtent);
   SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
}

//**************************************************************************
//
//  Function: SYEData
//
//   Purpose: Supports the DisplayResult function
//
//   Returns: retruns void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL SYEData(LPOPTIONS lpChoice,HDC hdc,WORD wFlags)
{
   char szOut[80+80],szTmp[80];
   int iNum=*(int far *)lpChoice->lpDataTmp;
   DWORD dwinfo=*(DWORD far *)lpChoice->lpData;
   LPSYE lpsye=(LPSYE)(dwinfo);

   wsprintf((LPSTR)szOut,(LPSTR)lpChoice->npStr);
   lstrcat((LPSTR)szOut,"  ");

   wsprintf((LPSTR)szTmp,(LPSTR)lpChoice->npFrmtStr,dwinfo);
   lstrcat((LPSTR)szOut,(LPSTR)szTmp);
   lstrcat((LPSTR)szOut," -> ");

   if(lpsye)
   {
      ConvertSYEArray(lpsye, (LPSTR)szTmp, min(iNum,80));
      //wsprintf((LPSTR)szTmp,"Not expanded yet!");

      lstrcat((LPSTR)szOut,(LPSTR)szTmp);

      gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
				 lstrlen((LPSTR)szOut)),
		   gdwExtent);
      SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
   }
   else
   {
      SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
      gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
				  lstrlen((LPSTR)szOut)),
		    gdwExtent);
   }


   if(gbFullDis)  // display each SYE...
   {
      int k;
      for(k=0;k<iNum;k++)
      {
	 wsprintf((LPSTR)szOut,"        lpsye[%i]=%#9.8lx,%#9.8lx,%i,%i",
		  k,lpsye[k].syv,lpsye[k].lRecogVal,
		  lpsye[k].cl,lpsye[k].iSyc);
	 SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
	 gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
				     lstrlen((LPSTR)szOut)),
		       gdwExtent);
      }
   }
}

//**************************************************************************
//
//  Function: ConvertSYEArray
//
//   Purpose: Supports the DisplayResult function
//
//   Comment: This function is only called from SYEData.
//
//   Returns: retruns void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
int NEAR PASCAL ConvertSYEArray(LPSYE lpSye, LPSTR lpBuf, int c)
{
   int i;
   char ch;

   for(i=0;i<c;i++)
   {
      ch=ConvertSYV(lpSye[i].syv);
      if(!ch)
	 ch='.';
      lpBuf[i]=ch;
   }
   lpBuf[i]=(char)NULL;

   return c+1;
}

//**************************************************************************
//
//  Function: ConvertSYV
//
//   Purpose: Supports the DisplayResult function
//
//   Comment: This function is only called from ConvertSYEArray.
//
//   Returns: retruns void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
char NEAR PASCAL ConvertSYV(SYV syv)
{
   char c;

   if(FIsSpecial(syv))
   {
      switch(syv)
      {
	 case SYV_NULL:
	 case SYV_UNKNOWN:
	 case SYV_EMPTY:
	    c='.';
	    break;
	 case SYV_SPACENULL:
	    c=' ';
	    break;
	 case SYV_BEGINOR:
	    c='{';
	    break;
	 case SYV_ENDOR:
	    c='}';
	    break;
	 case SYV_OR:
	    c='|';
	    break;
	 case SYV_SOFTNEWLINE:
	    c='.';
	    break;
	 default:
	    c='.';
	    break;
      }
   }
   else
      if(FIsAnsi(syv))
	 c=ChSyvToAnsi(syv);
      else
	 c='.';

   return c;
}


//**************************************************************************
//
//  Function: SYCData
//
//   Purpose: Supports the DisplayResult function
//
//   Returns: retruns void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL SYCData(LPOPTIONS lpChoice,HDC hdc,WORD wFlags)
{
   char szOut[80+80],szTmp[80];
   int iNum=*(int far *)lpChoice->lpDataTmp;
   DWORD dwinfo=*(DWORD far *)lpChoice->lpData;
   LPSYC lpsyc=(LPSYC)(dwinfo);

   wsprintf((LPSTR)szOut,(LPSTR)lpChoice->npStr);
   lstrcat((LPSTR)szOut,"  ");

   wsprintf((LPSTR)szTmp,(LPSTR)lpChoice->npFrmtStr,dwinfo);
   lstrcat((LPSTR)szOut,(LPSTR)szTmp);

   gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
			       lstrlen((LPSTR)szOut)),
		gdwExtent);
   SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);

   if((lpsyc)&&(gbFullDis))  // display each SYC...
   {
      int k;
      for(k=0;k<iNum;k++)
      {
	 wsprintf((LPSTR)szOut,
		  "        lpsyc[%i]=%i,%i,%i,%i,%i",
		  k,lpsyc[k].wStrokeFirst,
		    lpsyc[k].wPntFirst,
		    lpsyc[k].wStrokeLast,
		    lpsyc[k].wPntLast,
		    lpsyc[k].fLastSyc);
	 SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
	 gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
				     lstrlen((LPSTR)szOut)),
		       gdwExtent);
      }
   }
}

//**************************************************************************
//
//  Function: SYVData
//
//   Purpose: Supports the DisplayResult function
//
//   Returns: retruns void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL SYVData(LPOPTIONS lpChoice,HDC hdc,WORD wFlags)
{
   char szOut[80+80],szTmp[80];
   int iNum=*(int far *)lpChoice->lpDataTmp;
   DWORD dwinfo=*(DWORD far *)lpChoice->lpData;
   LPSYV lpsyv=(LPSYV)dwinfo;

   wsprintf((LPSTR)szOut,(LPSTR)lpChoice->npStr);
   lstrcat((LPSTR)szOut,"  ");

   wsprintf((LPSTR)szTmp,(LPSTR)lpChoice->npFrmtStr,dwinfo);
   lstrcat((LPSTR)szOut,(LPSTR)szTmp);
   lstrcat((LPSTR)szOut," -> ");

   if(lpsyv)
   {
      SymbolToCharacter(lpsyv,min(iNum+1,80),(LPSTR)szTmp,NULL);

      lstrcat((LPSTR)szOut,(LPSTR)szTmp);

      gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
				 lstrlen((LPSTR)szOut)),
		   gdwExtent);
      SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
   }
   else
   {
      SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
      gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
				  lstrlen((LPSTR)szOut)),
		    gdwExtent);
   }


   if(gbFullDis)  // display each SYV...
   {
      int k;
      for(k=0;k<iNum;k++)
      {
	 wsprintf((LPSTR)szOut,"        lpsyv[%i]=%#9.8lx",k,lpsyv[k]);
	 SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
	 gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
				     lstrlen((LPSTR)szOut)),
		       gdwExtent);
      }
   }
}



//**************************************************************************
//
// The next four functions support TYPE_OTHER.
//
//**************************************************************************

//**************************************************************************
//
//  Function: rgbfAlcData
//
//   Purpose: Supports the DisplayResult function
//
//   Returns: retruns void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL rgbfAlcData(LPOPTIONS lpChoice,HDC hdc,WORD wFlags)
{
   char szOut[80];
   int k;
   // This next line generates a compile warning yet it works just fine...
   DWORD dwInfo=(DWORD far *)lpChoice->lpData;
   BYTE far *lpByte=(BYTE far *)dwInfo;

   wsprintf((LPSTR)szOut,(LPSTR)lpChoice->npStr);
   SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
   gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
			       lstrlen((LPSTR)szOut)),
		 gdwExtent);

   if(gbFullDis)
   {
      for(k=0;k<cbRcrgbfAlcMax;k++)
      {
	 wsprintf((LPSTR)szOut,"        rgbfAlc[%i]=%2.2x",k,lpByte[k]);
	 SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
	 gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
				    lstrlen((LPSTR)szOut)),
		      gdwExtent);
      }
   }
}
//**************************************************************************
//
//  Function: rglpdfData
//
//   Purpose: Supports the DisplayResult function
//
//   Returns: retruns void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL rglpdfData(LPOPTIONS lpChoice,HDC hdc,WORD wFlags)
{
   char szOut[80];
   int k;
   // This next line generates a compile warning yet it works just fine...
   DWORD dwInfo=(DWORD far *)lpChoice->lpData;
   DWORD far *lpdw=(DWORD far *)dwInfo;

   wsprintf((LPSTR)szOut,(LPSTR)lpChoice->npStr);
   SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
   gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
			       lstrlen((LPSTR)szOut)),
		 gdwExtent);

   if(gbFullDis)
   {
      for(k=0;k<MAXDICTIONARIES;k++)
      {
	 wsprintf((LPSTR)szOut,"        rglpdf[%i]=%8.8lx",k,lpdw[k]);
	 SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
	 gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
				    lstrlen((LPSTR)szOut)),
		      gdwExtent);
      }
   }
}

//**************************************************************************
//
//  Function: ReservedData
//
//   Purpose: Supports the DisplayResult function
//
//   Returns: retruns void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL ReservedData(LPOPTIONS lpChoice,HDC hdc,WORD wFlags)
{
   char szOut[80];
   int k;
   // This next line generates a compile warning yet it works just fine...
   DWORD dwInfo=(DWORD far *)lpChoice->lpData;
   WORD far *lpw=(WORD far *)dwInfo;

   wsprintf((LPSTR)szOut,(LPSTR)lpChoice->npStr);
   SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
   gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
			       lstrlen((LPSTR)szOut)),
		 gdwExtent);

   if(gbFullDis)
   {
      for(k=0;k<cwRcReservedMax;k++)
      {
	 wsprintf((LPSTR)szOut,"        rgwReserved[%i]=%4.4x",k,lpw[k]);
	 SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
	 gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
				    lstrlen((LPSTR)szOut)),
		      gdwExtent);
      }
   }
}

//**************************************************************************
//
//  Function: HotSpots
//
//   Purpose: Supports the DisplayResult function
//
//   Returns: retruns void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL HotSpots(LPOPTIONS lpChoice,HDC hdc,WORD wFlags)
{
   char szOut[80+80];
   int index;
   LPPOINT lppnt;
   lppnt=(POINT far *)lpChoice->lpData;

   wsprintf((LPSTR)szOut,(LPSTR)lpChoice->npStr);
   SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
   gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
			      lstrlen((LPSTR)szOut)),
		gdwExtent);

   if(gbFullDis)
   {
      for(index=0;index<MAXHOTSPOT;index++)
      {
	 wsprintf((LPSTR)szOut,"       rgpntHotSpots[%i]=(%i,%i)",
			  index,lppnt[index].x,lppnt[index].y);
	 SendMessage(ghLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
	 gdwExtent=max(GetTextExtent(hdc,(LPSTR)szOut,
				    lstrlen((LPSTR)szOut)),
		      gdwExtent);
      }
   }
}





// End-of-File
