/****************************************************************************

	 FILE: INIT.C

      PURPOSE: Handles the initialization code for application and contains
	       the main GetMessage Loop.

    FUNCTIONS: WinMain
	       InitApplication
	       InitInstance

****************************************************************************/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "windows.h"
//#include "commdlg.h"
#include "penwin.h"
#include "globals.h"
#include "init.h"
#include "protos.h"

//**************************************************************************
//
//  Function: WinMain
//
//   Purpose: Main GetMessage Loop
//
//   Returns: Standard return
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************

int PASCAL WinMain(HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpCmdLine,
		   int nCmdShow)
{
    MSG msg;

    if (!hPrevInstance)
        if (!InitApplication(hInstance))
            return (FALSE);

    if (!InitInstance(hInstance, nCmdShow))
        return (FALSE);

    while (GetMessage(&msg, NULL, NULL, NULL))
    {
       if (NULL == ghDlgCurrent || !IsDialogMessage(ghDlgCurrent,&msg))
       {
	  TranslateMessage(&msg);
	  DispatchMessage(&msg);
       }
    }

    return (msg.wParam);
}


//**************************************************************************
//
//  Function: InitApplication
//
//   Purpose: Sets up Windows Class
//
//   Returns: The value returned by RegisterClass
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
BOOL InitApplication(HANDLE hInstance)
{
   char szClass[MSG_SHORT];
   char szMenu[MSG_SHORT];
   WNDCLASS  wc;

   LoadString(hInstance,IDS_CLASS,(LPSTR)szClass,MSG_SHORT);
   LoadString(hInstance,IDS_MENU,(LPSTR)szMenu,MSG_SHORT);

   wc.style	     = NULL;
   wc.lpfnWndProc    = (WNDPROC)MainWndProc;
   wc.cbClsExtra     = 0;
   wc.cbWndExtra     = 0;
   wc.hInstance      = hInstance;
   wc.hIcon	     = LoadIcon(hInstance, MAKEINTRESOURCE(ID_Icon));
   wc.hCursor	     = LoadCursor(NULL, IDC_ARROW);
   wc.hbrBackground  = GetStockObject(WHITE_BRUSH);
   wc.lpszMenuName   = (LPSTR)szMenu;
   wc.lpszClassName  = (LPSTR)szClass;

   return (RegisterClass(&wc));
}


//**************************************************************************
//
//  Function: InitInstance
//
//   Purpose: Creates main window
//
//   Returns: Success or Failure
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
BOOL InitInstance(HANDLE hInstance, int nCmdShow)
{
   char szClass[MSG_SHORT];
   char szTitle[MSG_SHORT];

   ghInst = hInstance;

   LoadString(ghInst,IDS_CLASS,(LPSTR)szClass,MSG_SHORT);
   LoadString(ghInst,IDS_TITLE,(LPSTR)szTitle,MSG_SHORT);

   ghwnd = CreateWindow(
	     (LPSTR)szClass,
	     (LPSTR)szTitle,
             WS_OVERLAPPEDWINDOW,
             CW_USEDEFAULT,
             CW_USEDEFAULT,
             CW_USEDEFAULT,
             CW_USEDEFAULT,
             NULL,
             NULL,
             hInstance,
             NULL );

   if ( !ghwnd )
      return ( FALSE );

   ShowWindow(ghwnd, nCmdShow);
   UpdateWindow(ghwnd);
   return (TRUE);
}

// End-Of-File
