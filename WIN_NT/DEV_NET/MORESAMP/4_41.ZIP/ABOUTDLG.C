/****************************************************************************

	 FILE: ABOUTDLG.C

      PURPOSE: Handles About dialog messages

    FUNCTIONS: About

****************************************************************************/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "windows.h"
#include "penwin.h"
#include "globals.h"
#include "protos.h"

//**************************************************************************
//
//  Function: About
//
//   Purpose: Handles About Dialog messages
//
//   Returns: standard return
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
BOOL FAR PASCAL About(HWND hDlg, unsigned message, WORD wParam, LONG lParam)
{
    switch (message)
        {
	case WM_COMMAND:
            if (wParam == IDOK || wParam == IDCANCEL)
                {
                EndDialog(hDlg, TRUE);
                return (TRUE);
                }
            break;
        }
    return (FALSE);
}
