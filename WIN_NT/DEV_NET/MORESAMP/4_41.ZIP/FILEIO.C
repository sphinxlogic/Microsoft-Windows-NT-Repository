/****************************************************************************

	 FILE: FILEIO.C

      PURPOSE: Performs all file io

    FUNCTIONS: AllocAndLockMem
	       InitOpenStruct
	       InitSaveStruct
	       FormatFilterString
	       FetchSavedSettings
	       SaveTheSettings

****************************************************************************/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "windows.h"
#include "commdlg.h"
#include "penwin.h"
#include "globals.h"
#include "fileio.h"
#include "protos.h"

/**************************************************************************
*									  *
*  Function:  AllocAndLockMem(HANDLE *, WORD)                             *
*                                                                         *
*   Purpose:  To allocate and lock a chunk of memory for the CD           *
*             structure.                                                  *
*                                                                         *
*   Returns:  LPSTR                                                       *
*                                                                         *
*  Comments:                                                              *
*                                                                         *
*   History:  Date      Reason                                            *
*             --------  -----------------------------------               *
*                                                                         *
*             10/01/91  Created                                           *
*                                                                         *
**************************************************************************/
LPSTR NEAR PASCAL AllocAndLockMem(HANDLE *hChunk, WORD wSize)
{
   LPSTR lpChunk;

   *hChunk = GlobalAlloc(GMEM_FIXED, wSize);

   if (*hChunk)
      {
         lpChunk = GlobalLock(*hChunk);
         if (!lpChunk)
            {
               GlobalFree(*hChunk);
	       lpChunk=NULL;
            }
      }
   else
      {
	 lpChunk=NULL;
      }
   return(lpChunk);
}



/**************************************************************************
*                                                                         *
*  Function:  InitOpenStruct(WORD, LPSTR)				  *
*                                                                         *
*   Purpose:  To initialize a structure for the current common dialog.    *
*             This routine is called just before the common dialogs       *
*             API is called.                                              *
*                                                                         *
*   Returns:  void                                                        *
*                                                                         *
*  Comments:                                                              *
*                                                                         *
*   History:  Date      Reason                                            *
*             --------  -----------------------------------               *
*                                                                         *
*             10/01/91  Created                                           *
*                                                                         *
**************************************************************************/
void NEAR PASCAL InitOpenStruct(LPFOCHUNK lpFOChunk)
{
   GetWindowsDirectory(gszBuffer, sizeof(gszBuffer));

   FormatFilterString();  //Formats gszFilter with strings

   *(lpFOChunk->szFile) 	   = 0;
   *(lpFOChunk->szFileTitle)	   = 0;

   lpFOChunk->of.lStructSize	   = sizeof(OPENFILENAME);
   lpFOChunk->of.hwndOwner	   = (HWND)ghwnd;
   lpFOChunk->of.hInstance	   = (HANDLE)NULL;
   lpFOChunk->of.lpstrFilter	   = gszFilter;
   lpFOChunk->of.lpstrCustomFilter = (LPSTR)NULL;
   lpFOChunk->of.nMaxCustFilter    = 0L;
   lpFOChunk->of.nFilterIndex	   = 1L;
   lpFOChunk->of.lpstrFile	   = lpFOChunk->szFile;
   lpFOChunk->of.nMaxFile	   = (DWORD)sizeof(lpFOChunk->szFile);
   lpFOChunk->of.lpstrFileTitle    = lpFOChunk->szFileTitle;
   lpFOChunk->of.nMaxFileTitle	   = MAXFILETITLELEN;
   lpFOChunk->of.lpstrInitialDir   = gszBuffer;
   lpFOChunk->of.lpstrTitle	   = (LPSTR)NULL;
   lpFOChunk->of.Flags		   = OFN_HIDEREADONLY |
				      OFN_PATHMUSTEXIST |
				      OFN_FILEMUSTEXIST;
   lpFOChunk->of.nFileOffset	   = 0;
   lpFOChunk->of.nFileExtension    = 0;
   lpFOChunk->of.lpstrDefExt	   = (LPSTR)NULL;
   lpFOChunk->of.lCustData	   = 0L;
   (FARPROC)lpFOChunk->of.lpfnHook = (FARPROC)NULL;
   lpFOChunk->of.lpTemplateName    = (LPSTR)NULL;

   return;

}



/**************************************************************************
*                                                                         *
*  Function:  InitSaveStruct(WORD, LPSTR)				*
*                                                                         *
*   Purpose:  To initialize a structure for the current common dialog.    *
*             This routine is called just before the common dialogs       *
*             API is called.                                              *
*                                                                         *
*   Returns:  void                                                        *
*                                                                         *
*  Comments:                                                              *
*                                                                         *
*   History:  Date      Reason                                            *
*             --------  -----------------------------------               *
*                                                                         *
*             10/01/91  Created                                           *
*                                                                         *
**************************************************************************/
void NEAR PASCAL InitSaveStruct(LPFSCHUNK lpFSChunk)
{
   GetWindowsDirectory(gszBuffer, sizeof(gszBuffer));

   FormatFilterString();  //Formats gszFilter with strings

   *(lpFSChunk->szFile) 	   = 0;
   lpFSChunk->of.lStructSize	   = sizeof(OPENFILENAME);
   lpFSChunk->of.hwndOwner	   = (HWND)ghwnd;
   lpFSChunk->of.hInstance	   = (HANDLE)NULL;
   lpFSChunk->of.lpstrFilter	   = gszFilter;
   lpFSChunk->of.lpstrCustomFilter = (LPSTR)NULL;
   lpFSChunk->of.nMaxCustFilter    = 0L;
   lpFSChunk->of.nFilterIndex	   = 1L;
   lpFSChunk->of.lpstrFile	   = lpFSChunk->szFile;
   lpFSChunk->of.nMaxFile	   = (DWORD)sizeof(lpFSChunk->szFile);
   lpFSChunk->of.lpstrFileTitle    = lpFSChunk->szFileTitle;
   lpFSChunk->of.nMaxFileTitle	   = MAXFILETITLELEN;
   lpFSChunk->of.lpstrInitialDir   = gszBuffer;
   lpFSChunk->of.lpstrTitle	   = (LPSTR)NULL;
   lpFSChunk->of.Flags		   = OFN_OVERWRITEPROMPT; //OFN_SHOWHELP |
   lpFSChunk->of.nFileOffset	   = 0;
   lpFSChunk->of.nFileExtension    = 0;
   lpFSChunk->of.lpstrDefExt	   = (LPSTR)"TXT";
   lpFSChunk->of.lCustData	   = 0L;
   (FARPROC)lpFSChunk->of.lpfnHook = (FARPROC)NULL;
   lpFSChunk->of.lpTemplateName    = (LPSTR)NULL;

   return;

}


/**************************************************************************
*                                                                         *
*  Function:  FormatFilterString(void)                                    *
*                                                                         *
*   Purpose:  To initialize the gszFilter variable with strings from      *
*             the string table.  This method of initializing gszBuffer    *
*             is necessary to ensure that the strings are contiguous      *
*             in memory--which is what COMMDLG.DLL requires.              *
*                                                                         *
*   Returns:  BOOL  TRUE if successful, FALSE if failure loading string   *
*                                                                         *
*  Comments:  The string loaded from the string table has some wild       *
*             character in it.  This wild character is then replaced      *
*             with NULL.  Note that the wild char can be any unique       *
*             character the developer chooses, and must be included       *
*             as the last character of the string.  A typical string      *
*             might look like "Write Files(*.WRI)|*.WRI|" where | is      *
*             the wild character in this case.  Implementing it this      *
*             way also ensures the string is doubly NULL terminated,      *
*             which is also a requirement of this lovely string.          *
*                                                                         *
*   History:  Date      Reason                                            *
*             --------  -----------------------------------               *
*                                                                         *
*             11/19/91  Created                                           *
*                                                                         *
**************************************************************************/
BOOL NEAR PASCAL FormatFilterString(void)
{
   WORD  wStringLen;	// wCtr,

   *gszFilter=0;

   if (!(wStringLen=LoadString(ghInst, IDS_FILTERSTR, gszFilter, sizeof(gszFilter))))
   {
      ErrorBox(IDS_ERRFILTER);
      return(FALSE);
   }
   gszFilter[wStringLen-1]=(char)NULL;
   gszFilter[wStringLen-7]=(char)NULL;

   return(TRUE);
}



//**************************************************************************
//
//  Function: FetchSavedSettings
//
//   Purpose: Reads INI file and sets globals variables.
//
//   Returns: TRUE
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
BOOL NEAR PASCAL FetchSavedSettings(HWND hwnd)
{
   char szFile[MSG_SHORT];
   char szSec[MSG_SHORT];
   char szKey[MSG_SHORT];
   int nwidth,nheight;
   int i;

   LoadString(ghInst,IDS_FILENAME,(LPSTR)&szFile,MSG_SHORT);
   LoadString(ghInst,IDS_SECTION,(LPSTR)&szSec,MSG_SHORT);
   LoadString(ghInst,IDS_TOP,(LPSTR)&szKey,MSG_SHORT);

   nwidth=GetSystemMetrics(SM_CXFULLSCREEN);
   nheight=GetSystemMetrics(SM_CYFULLSCREEN)/3;

   LoadString(ghInst,IDS_TOP,(LPSTR)&szKey,MSG_SHORT);
   grect.top=GetPrivateProfileInt((LPSTR)szSec,(LPSTR)szKey,
				 0,(LPSTR)szFile);
   LoadString(ghInst,IDS_LEFT,(LPSTR)&szKey,MSG_SHORT);
   grect.left=GetPrivateProfileInt((LPSTR)szSec,(LPSTR)szKey,
				  0,(LPSTR)szFile);
   LoadString(ghInst,IDS_BOTTOM,(LPSTR)&szKey,MSG_SHORT);
   grect.bottom=GetPrivateProfileInt((LPSTR)szSec,(LPSTR)szKey,
				    nheight,(LPSTR)szFile);
   LoadString(ghInst,IDS_RIGHT,(LPSTR)&szKey,MSG_SHORT);
   grect.right=GetPrivateProfileInt((LPSTR)szSec,(LPSTR)szKey,
				   nwidth,(LPSTR)szFile);


   LoadString(ghInst,IDS_GBHOOK,(LPSTR)&szKey,MSG_SHORT);
   gbHook=GetPrivateProfileInt((LPSTR)szSec,(LPSTR)szKey,
			       1,(LPSTR)szFile);
   LoadString(ghInst,IDS_GBSAVESETTINGS,(LPSTR)&szKey,MSG_SHORT);
   gbSaveSettings=GetPrivateProfileInt((LPSTR)szSec,(LPSTR)szKey,
				       1,(LPSTR)szFile);

   LoadString(ghInst,IDS_GBFULLDIS,(LPSTR)&szKey,MSG_SHORT);
   gbFullDis=GetPrivateProfileInt((LPSTR)szSec,(LPSTR)szKey,
				     0,(LPSTR)szFile);

   // Dialog boxes are next
   LoadString(ghInst,IDS_SETDLG,(LPSTR)&szKey,MSG_SHORT);
   if( GetPrivateProfileInt((LPSTR)szSec,(LPSTR)szKey,
				     0,(LPSTR)szFile) )
      PostMessage(hwnd,WM_COMMAND,IDM_SETDLG,MAKELONG(hwnd,0));

   LoadString(ghInst,IDS_VIEWDLG,(LPSTR)&szKey,MSG_SHORT);
   if( GetPrivateProfileInt((LPSTR)szSec,(LPSTR)szKey,
				     0,(LPSTR)szFile) )
      PostMessage(hwnd,WM_COMMAND,IDM_VIEWDLG,MAKELONG(hwnd,0));

   LoadString(ghInst,IDS_TESTDLG,(LPSTR)&szKey,MSG_SHORT);
   if( GetPrivateProfileInt((LPSTR)szSec,(LPSTR)szKey,
				     0,(LPSTR)szFile) )
      PostMessage(hwnd,WM_COMMAND,IDM_TESTDLG,MAKELONG(hwnd,0));

   giSetx=GetPrivateProfileInt((LPSTR)szSec,"giSetx",
				     0,(LPSTR)szFile);
   giSety=GetPrivateProfileInt((LPSTR)szSec,"giSety",
				     0,(LPSTR)szFile);
   giTestx=GetPrivateProfileInt((LPSTR)szSec,"giTestx",
				     0,(LPSTR)szFile);
   giTesty=GetPrivateProfileInt((LPSTR)szSec,"giTesty",
				     0,(LPSTR)szFile);
   giViewx=GetPrivateProfileInt((LPSTR)szSec,"giViewx",
				     0,(LPSTR)szFile);
   giViewy=GetPrivateProfileInt((LPSTR)szSec,"giViewy",
				     0,(LPSTR)szFile);

   for(i=0;i<NUMOF_RC_OPTIONS;i++)
   {
      wsprintf((LPSTR)szKey,"%i",i);
      gRc_Opt[i].bSelect=GetPrivateProfileInt((LPSTR)szSec,(LPSTR)szKey,
					0,(LPSTR)szFile);
   }
   for(i=0;i<NUMOF_RCR_OPTIONS;i++)
   {
      wsprintf((LPSTR)szKey,"%i",i+NUMOF_RC_OPTIONS);
      gRcR_Opt[i].bSelect=GetPrivateProfileInt((LPSTR)szSec,(LPSTR)szKey,
					0,(LPSTR)szFile);
   }
   return TRUE;
}

//**************************************************************************
//
//  Function: SaveTheSettings
//
//   Purpose: Save settings in INI file
//
//   Returns: TRUE
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
BOOL NEAR PASCAL SaveTheSettings(void)
{
   char szFile[MSG_SHORT];
   char szSec[MSG_SHORT];
   char szKey[MSG_SHORT];
   char szTmp[MSG_SHORT];
   int i;

   LoadString(ghInst,IDS_FILENAME,(LPSTR)&szFile,MSG_SHORT);
   LoadString(ghInst,IDS_SECTION,(LPSTR)&szSec,MSG_SHORT);

   LoadString(ghInst,IDS_TOP,(LPSTR)&szKey,MSG_SHORT);
   wsprintf((LPSTR)szTmp,"%i",grect.top);
   WritePrivateProfileString( (LPSTR)szSec,(LPSTR)szKey,(LPSTR)szTmp,
			      (LPSTR)szFile );
   LoadString(ghInst,IDS_LEFT,(LPSTR)&szKey,MSG_SHORT);
   wsprintf((LPSTR)szTmp,"%i",grect.left);
   WritePrivateProfileString((LPSTR)szSec,(LPSTR)szKey,(LPSTR)szTmp,
			     (LPSTR)szFile);
   LoadString(ghInst,IDS_BOTTOM,(LPSTR)&szKey,MSG_SHORT);
   wsprintf((LPSTR)szTmp,"%i",grect.bottom);
   WritePrivateProfileString((LPSTR)szSec,(LPSTR)szKey,(LPSTR)szTmp,
			     (LPSTR)szFile);
   LoadString(ghInst,IDS_RIGHT,(LPSTR)&szKey,MSG_SHORT);
   wsprintf((LPSTR)szTmp,"%i",grect.right);
   WritePrivateProfileString((LPSTR)szSec,(LPSTR)szKey,(LPSTR)szTmp,
			     (LPSTR)szFile);

   LoadString(ghInst,IDS_GBHOOK,(LPSTR)szKey,MSG_SHORT);
   wsprintf((LPSTR)szTmp,"%i",gbHook);
   WritePrivateProfileString((LPSTR)szSec,(LPSTR)szKey,(LPSTR)szTmp,
			     (LPSTR)szFile);
   LoadString(ghInst,IDS_GBSAVESETTINGS,(LPSTR)&szKey,MSG_SHORT);
   wsprintf((LPSTR)szTmp,"%i",gbSaveSettings);
   WritePrivateProfileString((LPSTR)szSec,(LPSTR)szKey,(LPSTR)szTmp,
			     (LPSTR)szFile);

   LoadString(ghInst,IDS_GBFULLDIS,(LPSTR)&szKey,MSG_SHORT);
   wsprintf((LPSTR)szTmp,"%i",gbFullDis);
   WritePrivateProfileString((LPSTR)szSec,(LPSTR)szKey,(LPSTR)szTmp,
			     (LPSTR)szFile);

   // Save the Dialog boxes that are up...
   LoadString(ghInst,IDS_SETDLG,(LPSTR)&szKey,MSG_SHORT);
   if(ghwndSet)
   {
#ifdef DEBUG
      OutputDebugString("RCDUMP: fileio.c: ghwndSet!=0\n\r\0");
#endif
      wsprintf((LPSTR)szTmp,"%i",1);
   }
   else
   {
#ifdef DEBUG
      OutputDebugString("RCDUMP: fileio.c: ghwndSet==0\n\r\0");
#endif
      wsprintf((LPSTR)szTmp,"%i",0);
   }
   WritePrivateProfileString((LPSTR)szSec,(LPSTR)szKey,(LPSTR)szTmp,
			     (LPSTR)szFile);
   LoadString(ghInst,IDS_VIEWDLG,(LPSTR)&szKey,MSG_SHORT);
   wsprintf((LPSTR)szTmp,"%i",(ghwndView==0 ? FALSE : TRUE));
   WritePrivateProfileString((LPSTR)szSec,(LPSTR)szKey,(LPSTR)szTmp,
			     (LPSTR)szFile);
   LoadString(ghInst,IDS_TESTDLG,(LPSTR)&szKey,MSG_SHORT);
   wsprintf((LPSTR)szTmp,"%i",(ghwndTest==0 ? FALSE : TRUE));
   WritePrivateProfileString((LPSTR)szSec,(LPSTR)szKey,(LPSTR)szTmp,
			     (LPSTR)szFile);

   lstrcpy((LPSTR)szKey,"giSetx");
   wsprintf((LPSTR)szTmp,"%i",giSetx);
   WritePrivateProfileString((LPSTR)szSec,(LPSTR)szKey,(LPSTR)szTmp,
			     (LPSTR)szFile);
   lstrcpy((LPSTR)szKey,"giSety");
   wsprintf((LPSTR)szTmp,"%i",giSety);
   WritePrivateProfileString((LPSTR)szSec,(LPSTR)szKey,(LPSTR)szTmp,
			     (LPSTR)szFile);
   lstrcpy((LPSTR)szKey,"giTestx");
   wsprintf((LPSTR)szTmp,"%i",giTestx);
   WritePrivateProfileString((LPSTR)szSec,(LPSTR)szKey,(LPSTR)szTmp,
			     (LPSTR)szFile);
   lstrcpy((LPSTR)szKey,"giTesty");
   wsprintf((LPSTR)szTmp,"%i",giTesty);
   WritePrivateProfileString((LPSTR)szSec,(LPSTR)szKey,(LPSTR)szTmp,
			     (LPSTR)szFile);
   lstrcpy((LPSTR)szKey,"giViewx");
   wsprintf((LPSTR)szTmp,"%i",giViewx);
   WritePrivateProfileString((LPSTR)szSec,(LPSTR)szKey,(LPSTR)szTmp,
			     (LPSTR)szFile);
   lstrcpy((LPSTR)szKey,"giViewy");
   wsprintf((LPSTR)szTmp,"%i",giViewy);
   WritePrivateProfileString((LPSTR)szSec,(LPSTR)szKey,(LPSTR)szTmp,
			     (LPSTR)szFile);


   for(i=0;i<NUMOF_RC_OPTIONS;i++)
   {
      wsprintf((LPSTR)szKey,"%i",i);
      wsprintf((LPSTR)szTmp,"%i",gRc_Opt[i].bSelect);
      WritePrivateProfileString((LPSTR)szSec,(LPSTR)szKey,
				(LPSTR)szTmp,(LPSTR)szFile);
   }
   for(i=0;i<NUMOF_RCR_OPTIONS;i++)
   {
      wsprintf((LPSTR)szKey,"%i",i+NUMOF_RC_OPTIONS);
      wsprintf((LPSTR)szTmp,"%i",gRcR_Opt[i].bSelect);
      WritePrivateProfileString((LPSTR)szSec,(LPSTR)szKey,
				(LPSTR)szTmp,(LPSTR)szFile);
   }
   return TRUE;
}

// End-of-File
