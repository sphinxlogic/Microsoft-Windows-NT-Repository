/****************************************************************************

	 FILE: RCTLHLP.C

      PURPOSE:

    FUNCTIONS: InitializeThDLL - Loads TOOLHELP.DLL and fetches function
				 addresses.
	       UnInstallThDLL  - Uninstalls TOOLHELP.DLL
	       IsGlobalHandle  - Validates Global Handles
	       IsFarPointer    - Valiates Far Pointers

****************************************************************************/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "windows.h"
#include "penwin.h"
#include "toolhelp.h"
//#include "commdlg.h"
#include "globals.h"
#include "rctlhlp.h"
#include "Protos.h"

//**************************************************************************
//
//  Function: InitializeThDLL
//
//   Purpose: Loads TOOLHELP.DLL and gets function addresses
//
//   Returns: success or failure
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
BOOL FAR PASCAL InitializeThDLL()
{
   char szStr[MSG_SHORT];

   LoadString(ghInst,IDS_TOOLHELP,(LPSTR)szStr,MSG_SHORT);
   if((ghToolHelpDll=LoadLibrary((LPSTR)szStr))<32)
   {
      ErrorBox(IDS_ERR_NOTOOLHELP);
      return FALSE;
   }

   LoadString(ghInst,IDS_GLOBALINFO,(LPSTR)szStr,MSG_SHORT);
   (FARPROC)lpfnGlobalInfo=GetProcAddress(ghToolHelpDll,(LPSTR)szStr);
   LoadString(ghInst,IDS_GLOBALFIRST,(LPSTR)szStr,MSG_SHORT);
   (FARPROC)lpfnGlobalFirst=GetProcAddress(ghToolHelpDll,(LPSTR)szStr);
   LoadString(ghInst,IDS_GLOBALNEXT,(LPSTR)szStr,MSG_SHORT);
   (FARPROC)lpfnGlobalNext=GetProcAddress(ghToolHelpDll,(LPSTR)szStr);

   if(!lpfnGlobalInfo || !lpfnGlobalFirst || !lpfnGlobalNext)
   {
      ErrorBox(IDS_ERR_BADADDRESS);
      FreeLibrary(ghToolHelpDll);
      return FALSE;
   }

   return TRUE;
}


//**************************************************************************
//
//  Function: UnInstallThDLL
//
//   Purpose: Frees TOOLHELP.DLL
//
//   Returns: TRUE
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
BOOL FAR PASCAL UnInstallThDLL()
{
   if(ghToolHelpDll)
      FreeLibrary(ghToolHelpDll);
   return TRUE;
}


//**************************************************************************
//
//  Function: IsGlobalHandle
//
//   Purpose: Walks global arena and looks for handle
//
//   Returns: Valid handle or NULL
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
HANDLE FAR PASCAL IsGlobalHandle(HANDLE hGlobalHandle)
{
    GLOBALENTRY Global;
    GLOBALINFO GlobalInf;
    BOOL bFound=FALSE;


    /* Allocate a buffer to do the Global walk */
    GlobalInf.dwSize = sizeof (GLOBALINFO);
    lpfnGlobalInfo(&GlobalInf);

    /* Loop through the heap */
    Global.dwSize = sizeof (GLOBALENTRY);
    if (lpfnGlobalFirst(&Global, GLOBAL_ALL))
    {
        do
	{
	    if(Global.hBlock==hGlobalHandle)
	    {
	       bFound=TRUE;
	       break;
	    }
	}
	while (lpfnGlobalNext(&Global,GLOBAL_ALL));
    }

    if(bFound)
       return hGlobalHandle;
    else
       return NULL;
}


//**************************************************************************
//
//  Function: IsFarPointer
//
//   Purpose: Checks validity of handle and insures that offset points
//	      into the block, it doesn't exceed it.
//
//   Returns: a Valid far pointer or NULL
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
LPSTR FAR PASCAL IsFarPointer(LPSTR lpPtr)
{
   DWORD dwSize;
   HANDLE hMem;

   // If the block has been freed GlobalHandle will return a valid
   // handle but zero for the selector.

   //hMem=GlobalHandle(HIWORD(lpPtr));

   // ******* sleazy hack *******
   // When calling IsGlobalHandle I'm passing in a decremented selector
   // instead of a handle.  The reason for this is that GlobalHandle
   // will cause a stack dump when called with an invalid handle.  I
   // don't want this!!!  Maybe in the future we'll change this to
   // use GlobalHandle.
   if( hMem=IsGlobalHandle((HIWORD(lpPtr)-1)) )
   {
      dwSize=MAKELONG(LOWORD(lpPtr),0);
      if( dwSize < GlobalSize(hMem) )
	 return lpPtr;
   }
   return (LPSTR)NULL;
}

// End-of-File
