/****************************************************************************

	 FILE: MAINWND.C

      PURPOSE: Handles the basic processing for the Main Window.  This
	       includes the hooking of the WM_RCRESULT and the menu items.

    FUNCTIONS: MainWndProc
	       ErrorBox


****************************************************************************/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "windows.h"
#include "penwin.h"
#include "globals.h"
#include "mainwnd.h"
#include "Protos.h"

#include "initial.inc"
#include "tables.inc"


//**************************************************************************
//
// Globals to this file
//
#ifdef DEBUG
char szDebugStr[80];
#endif
//**************************************************************************


//**************************************************************************
//
//  Function: MainWndProc
//
//   Purpose: Handles messages for the main window.
//
//  Messages: gwAppComMessage - Handles inter application communication
//		IDX_REGISTERAPP
//		IDX_UPDATERC
//		IDX_INITIALRC
//	      WM_COMMAND      - passes to DoCommand
//	      WM_CREATE       -
//	      WM_SIZE	      -
//	      WM_MOVE	      -
//	      WM_HOOKRCRESULT -
//	      WM_SYSCOMMAND   -
//	      WM_DESTROY      -
//
//   Returns: Standard return
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
long FAR PASCAL MainWndProc(HWND hWnd, unsigned message, WORD wParam, LONG lParam)
{
  /*
     Notice that the first thing this application looks for is the message
     that is dynamically created at run time thus the if statement (This
     message is not constant thus it can not be part of the standard
     switch statement).  If the current message is the application defined
     communcation message it checks the notification and executes it.
  */
  if(message==gwAppComMessage)
  {
    switch(wParam)
    {
       // an application wants to be registered for message communication
       case IDX_REGISTERAPP:
	 if((ghAppComWin!=NULL) && (LOWORD(lParam)==0))
	 {
#ifdef DEBUG
	    OutputDebugString("RCDUMP: IDX_REGISTERAPP: Terminating");
#endif
	    // Then other app is terminating thus change RC structure used.
	    InitRC(hWnd,&grc);
	    // PostMessage for Displaying
	    PostMessage(hWnd,WM_COMMAND,INT_DISPLAY,MAKELONG(hWnd,0));
	 }
	 ghAppComWin=(HANDLE)LOWORD(lParam);
	 if(IsWindow(ghAppComWin))
	 {
#ifdef DEBUG
	    OutputDebugString("RCDUMP: IDX_REGISTERAPP: Posting IDX_REGISTERAPP");
#endif
	    PostMessage(ghAppComWin,gwAppComMessage,IDX_REGISTERAPP,
			MAKELONG(hWnd,0));
	 }
	 break;
       case IDX_UPDATERC:
	 // copy RC structure into grc location...
	 if(lParam)
	 {
	    grc=*(LPRC)lParam;
#ifdef DEBUG
	    wsprintf((LPSTR)szDebugStr,"RCDUMP: IDX_UPDATERC: Copied RC, grc.hwnd=%x\n\r\0",grc.hwnd);
	    OutputDebugString((LPSTR)szDebugStr);
#endif
	 }
	 break;
       case IDX_INITIALRC:
	 // copy RC structure into grc location and display...
	 if(lParam)
	 {
	    grc=*(LPRC)lParam;
#ifdef DEBUG
	    wsprintf((LPSTR)szDebugStr,"RCDUMP: IDX_INITIALRC: Copied RC, grc.hwnd=%x\n\r\0",grc.hwnd);
	    OutputDebugString((LPSTR)szDebugStr);
#endif
	 }
	 // PostMessage for Displaying
	 PostMessage(hWnd,WM_COMMAND,INT_DISPLAY,MAKELONG(hWnd,0));
	 break;
    }
  }
  else
  {
    switch ( message )
        {
	case WM_COMMAND:
	    // Punt to DoCommand
	    DoCommand(hWnd,message,wParam,lParam);
	    break;

	case WM_CREATE:
	    {
	       LPCREATESTRUCT lpcs;
	       RECT rectTmp;

	       // Save the Menu handle for checking of menu items
	       lpcs=(LPCREATESTRUCT)lParam;
	       ghMenu=lpcs->hMenu;

	       // get the resource
	       ghRcWaitCursor=LoadCursor(ghInst,MAKEINTRESOURCE(ID_RcWait));

	       // used for Modeless dialogs
	       glpSetDlg  = MakeProcInstance( SetDlg, ghInst );
	       glpTestDlg = MakeProcInstance( TestDlg, ghInst );
	       glpViewDlg = MakeProcInstance( View, ghInst );
	       ghwndSet  = NULL;
	       ghwndView = NULL;
	       ghwndTest = NULL;

	       // Load into memory toolhelp.dll
	       if(!InitializeThDLL())
		  return -1;

	       // Read from .INI file
	       SendMessage(hWnd,WM_COMMAND,INT_GETSAVESETTINGS,
			   MAKELONG(hWnd,0));

	       // check marks on menu if needed.
	       gbHook=!gbHook;
	       SendMessage(hWnd,WM_COMMAND,IDM_HOOK,MAKELONG(hWnd,0));

	       if(gbSaveSettings)
		  CheckMenuItem(ghMenu,IDM_SAVEONEXIT,MF_CHECKED);
	       if(gbFullDis)
		  CheckMenuItem(ghMenu,IDM_FULLDIS,MF_CHECKED);

	       // Set size and position the window from grect that gets
	       // initialized when reading from the .INI file.
	       MoveWindow(hWnd,grect.left,grect.top,
			  grect.right-grect.left,
			  grect.bottom-grect.top,FALSE);

	       // create the listbox for dispalayed information
	       GetClientRect(hWnd,&rectTmp);

	       ghLB = CreateWindow("listbox",
				   "",
				   MAIN_LBOPTS,
				   2,
				   2,
				   (rectTmp.right-rectTmp.left)-4,
				   (rectTmp.bottom-rectTmp.top)-4,
				   hWnd,
				   NULL,
				   ghInst,
				   NULL );

	       // Need to have an initial RC structure.
	       InitRC(hWnd,&grc);

	       // register unique message for inter application communication
	       gwAppComMessage=RegisterWindowMessage("WM_RCDUMP");
	    }
	    break;

	case WM_SIZE:
	case WM_MOVE:
	    {
	       RECT rectTmp;

	       // Save window position if not iconic
	       if(!IsIconic(hWnd))
	       {
		  GetWindowRect(hWnd,&grect);
		  GetClientRect(hWnd,&rectTmp);

		  if(ghLB)
		     MoveWindow(ghLB,2,2,(rectTmp.right-rectTmp.left)-4,
				(rectTmp.bottom-rectTmp.top)-4,TRUE);
	       }
	    }
	    break;

	case WM_HOOKRCRESULT:
	    {
	       LPRCRESULT lprcr;

	       if( lprcr=(LPRCRESULT)lParam )
	       {
		  // Free any memory associated with previosly hooked RCRESULT
		  CleanUpPreviousRcresult();

		  // Copy all the information into global variable
		  CopyRcresult(lprcr);

		  // PostMessage for Displaying
		  PostMessage(hWnd,WM_COMMAND,INT_DISPLAY,MAKELONG(hWnd,0));
		  gbFirstTime=FALSE;
	       }
	    }
	    break;


	case WM_SYSCOMMAND:
	    {
	       HCURSOR hCursor;
	       WORD wCase=wParam&0xFFF0;

	       hCursor=SetCursor(ghRcWaitCursor);
	       ShowCursor(TRUE);

	       switch(wCase)
	       {
		  case SC_MINIMIZE:

		     if(ghwndSet)
			ShowWindow(ghwndSet,SW_HIDE);
		     if(ghwndTest)
			ShowWindow(ghwndTest,SW_HIDE);
		     if(ghwndView)
			ShowWindow(ghwndView,SW_HIDE);
		     break;
		  case SC_RESTORE:
		     if(ghwndSet)
			ShowWindow(ghwndSet,SW_SHOW);
		     if(ghwndTest)
			ShowWindow(ghwndTest,SW_SHOW);
		     if(ghwndView)
			ShowWindow(ghwndView,SW_SHOW);
		     break;
	       }

	       SetCursor(hCursor);
	       ShowCursor(FALSE);

	       return (DefWindowProc(hWnd, message, wParam, lParam));
	    }
	    break;

	case WM_DESTROY:
	    {
	       HCURSOR hCursor;

	       hCursor=SetCursor(ghRcWaitCursor);
	       ShowCursor(TRUE);

#ifdef DEBUG
	       wsprintf((LPSTR)szDebugStr,"RCDUMP: WM_DESTROY: ghwndSet=%x\n\r\0",ghwndSet);
	       OutputDebugString((LPSTR)szDebugStr);
#endif

	       if(gbSaveSettings)
		  SendMessage(hWnd,WM_COMMAND,INT_SAVESETTINGS,MAKELONG(hWnd,0));

	       if(gbHook)
		  SendMessage(hWnd,WM_COMMAND,IDM_HOOK,MAKELONG(hWnd,0));

	       CleanUpPreviousRcresult();

	       // Unload toolhelp.dll
	       UnInstallThDLL();

	       // remove the dislog window and free the thunks
	       if(ghwndSet)
		  SendMessage(ghwndSet,WM_CLOSE,0,0L);
	       if(ghwndTest)
		  SendMessage(ghwndTest,WM_CLOSE,0,0L);
	       if(ghwndView)
		  SendMessage(ghwndView,WM_CLOSE,0,0L);

	       FreeProcInstance( glpSetDlg );
	       FreeProcInstance( glpTestDlg );
	       FreeProcInstance( glpViewDlg );

	       SetCursor(hCursor);
	       ShowCursor(FALSE);

	       // All done...
	       PostQuitMessage(0);
	    }
            break;

        default:
	    return (DefWindowProc(hWnd, message, wParam, lParam));
     }
  }
  return (NULL);
}

//**************************************************************************
//
//  Function: ErrorBox
//
//   Purpose: Displays error messages
//
//   Returns: TRUE
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
BOOL NEAR PASCAL ErrorBox(WORD wIDS)
{
   char  szErrorBuf[MSG_LONG];
   char  szTitle[MSG_NORMAL];

   LoadString(ghInst,wIDS,(LPSTR)&szErrorBuf,MSG_LONG);
   LoadString(ghInst,IDS_TITLE,(LPSTR)&szTitle,MSG_NORMAL);
   MessageBox(GetFocus(),(LPSTR)&szErrorBuf,(LPSTR)&szTitle,
	      MB_OK | MB_ICONEXCLAMATION);
   return(TRUE);
}

//**************************************************************************
//
//  Function: CopyRcresult
//
//   Purpose: Just that...
//
//   Returns: void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL CopyRcresult(LPRCRESULT lprcr)
{
   int i;
   DWORD dwSize;
   // The lprcr pointer is assumed to be valid.  Let's copy everthing in
   // order for simplicity...

   // First copy the syg components starting with the hotspots
   for(i=0;i<MAXHOTSPOT;i++)
      gresult.syg.rgpntHotSpots[i]=lprcr->syg.rgpntHotSpots[i];

   gresult.syg.cHotSpot=lprcr->syg.cHotSpot;
   gresult.syg.nFirstBox=lprcr->syg.nFirstBox;
   gresult.syg.lRecogVal=lprcr->syg.lRecogVal;

   // allocate memory for sye array and copy it too.
   dwSize=sizeof(SYE)*lprcr->syg.cSye+sizeof(SYE);
   if(ghsyeMem=GlobalAlloc(GMEM_MOVEABLE,dwSize))
      gresult.syg.lpsye=(LPSYE)GlobalLock(ghsyeMem);

   if(ValidPtr((LPSTR)lprcr->syg.lpsye))
      MemCopy((LPSTR)gresult.syg.lpsye,(LPSTR)lprcr->syg.lpsye,(int)dwSize);
   else
      gresult.syg.lpsye=NULL;
   gresult.syg.cSye=lprcr->syg.cSye;

   // allocate memory for syc array and copy it too
   dwSize=sizeof(SYC)*lprcr->syg.cSyc;
   if(ghsycMem=GlobalAlloc(GMEM_MOVEABLE,dwSize))
      gresult.syg.lpsyc=(LPSYC)GlobalLock(ghsycMem);

   if(ValidPtr((LPSTR)lprcr->syg.lpsyc))
      MemCopy((LPSTR)gresult.syg.lpsyc,(LPSTR)lprcr->syg.lpsyc,(int)dwSize);
   else
      gresult.syg.lpsyc=NULL;
   gresult.syg.cSyc=lprcr->syg.cSyc;

   // Next the wResultsType
   gresult.wResultsType=lprcr->wResultsType;

   // Let's get the best guess, keep the old handle...
   gresult.hSyv=lprcr->hSyv;
   // Allocate memory for the best guess...
   dwSize=sizeof(SYV)*lprcr->cSyv+sizeof(SYV); // leave room of the terminater
   if(ghsyvMem=GlobalAlloc(GMEM_MOVEABLE,dwSize))
      gresult.lpsyv=(LPSYV)GlobalLock(ghsyvMem);

   if(ValidPtr((LPSTR)lprcr->lpsyv))
      MemCopy((LPSTR)gresult.lpsyv,(LPSTR)lprcr->lpsyv,(int)dwSize);
   else
      gresult.lpsyv=NULL;
   gresult.cSyv=lprcr->cSyv;

   // nBaseLine and nMidLine
   gresult.nBaseLine=lprcr->nBaseLine;
   gresult.nMidLine=lprcr->nMidLine;

   // What about the raw data?	copy it to a global
   ghpendata=(HANDLE)DuplicatePenData(lprcr->hpendata,NULL);
   // and then record the original value
   gresult.hpendata=lprcr->hpendata;

   // other trash
   gresult.rectBoundInk=lprcr->rectBoundInk;
   gresult.pntEnd=lprcr->pntEnd;

   // the RC structure that started it all...I should already have this.
   //gresult.lprc=lprcr->lprc;
   grc=*(lprcr->lprc);
}

//**************************************************************************
//
//  Function: CleanUpPreviousRcresult
//
//   Purpose: Free memory held by RcResult structure
//
//   Returns: void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL CleanUpPreviousRcresult()
{
   if(ghsyeMem)
   {
      GlobalUnlock(ghsyeMem);
      ghsyeMem=GlobalFree(ghsyeMem);
   }
   if(ghsycMem)
   {
      GlobalUnlock(ghsycMem);
      ghsycMem=GlobalFree(ghsycMem);
   }
   if(ghsyvMem)
   {
      GlobalUnlock(ghsyvMem);
      ghsyvMem=GlobalFree(ghsyvMem);
   }
   if(ghpendata)
      ghpendata=GlobalFree(ghpendata);
}


//**************************************************************************
//
//  Function: ValidePtr
//
//   Purpose: calls functions that use TOOLHELP.DLL
//
//   Returns: Success or failure
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
BOOL NEAR PASCAL ValidPtr(LPSTR lp)
{
   if(IsFarPointer(lp))
      return TRUE;
   else
      return FALSE;
}

//**************************************************************************
//
//  Function: DoCommand
//
//   Purpose: Handles app sepcific messages
//
//   Returns: void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL DoCommand(HWND hWnd,unsigned message,WORD wParam, LONG lParam)
{
   FARPROC  lpProcAbout;

   switch ( wParam )
   {
      case IDM_EXIT:
	 PostMessage(hWnd,WM_DESTROY,0,0L);
	 break;

      case IDM_SETDLG:
	 if(!ghwndSet)
	    ghwndSet=CreateDialog(ghInst, "SetDlg", GetDesktopWindow(), glpSetDlg);
	 else
	    SetFocus(ghwndSet);
	 break;

      case IDM_TESTDLG:
	 if(!ghwndTest)
	    ghwndTest=CreateDialog(ghInst, "TestDlg", GetDesktopWindow(), glpTestDlg);
	 else
	    SetFocus(ghwndTest);
	 break;

      case IDM_VIEWDLG:
	 if(!ghwndView)
	    ghwndView=CreateDialog(ghInst, "View", GetDesktopWindow(), glpViewDlg);
	 else
	    SetFocus(ghwndView);
	 break;

      case IDM_HPENDATA:
	 if(ghpendata)
	 {
	    lpProcAbout = MakeProcInstance( PenData, ghInst );
	    DialogBox(ghInst, "PenData", hWnd, lpProcAbout);
	    FreeProcInstance( lpProcAbout );
	 }
	 else
	    MessageBox(hWnd,"No Raw Data to view!","Raw Data",
		       MB_OK|MB_ICONEXCLAMATION);
	 break;
      case IDM_FULLDIS:
	 {
	    if(gbFullDis)
	    {
	       gbFullDis=FALSE;
	       CheckMenuItem(ghMenu,IDM_FULLDIS,MF_UNCHECKED);
	    }
	    else
	    {
	       gbFullDis=TRUE;
	       CheckMenuItem(ghMenu,IDM_FULLDIS,MF_CHECKED);
	    }
	    DrawMenuBar(hWnd);
	    PostMessage(hWnd,WM_COMMAND,INT_DISPLAY,MAKELONG(hWnd,0));
	 }
	 break;
      case IDM_SAVEONEXIT:
	 {
	    if(gbSaveSettings)
	    {
	       gbSaveSettings=FALSE;
	       CheckMenuItem(ghMenu,IDM_SAVEONEXIT,MF_UNCHECKED);
	    }
	    else
	    {
	       gbSaveSettings=TRUE;
	       CheckMenuItem(ghMenu,IDM_SAVEONEXIT,MF_CHECKED);
	    }
	    DrawMenuBar(hWnd);
	 }
	 break;
      case IDM_HOOK:
	 {
	 if(gbHook)
	 {
	    if(!SetRecogHook(HWR_RESULTS,HKP_UNHOOK,hWnd))
	    {
	       ErrorBox(IDS_ERRCANTUNHOOK);
	       gbHook=TRUE;
	       CheckMenuItem(ghMenu,IDM_HOOK,MF_CHECKED);
	    }
	    else
	    {
	       gbHook=FALSE;
	       CheckMenuItem(ghMenu,IDM_HOOK,MF_UNCHECKED);
	    }
	 }
	 else
	 {
	    if(!SetRecogHook(HWR_RESULTS,HKP_SETHOOK,hWnd))
	    {
	       ErrorBox(IDS_ERRCANTHOOK);
	       gbHook=FALSE;
	       CheckMenuItem(ghMenu,IDM_HOOK,MF_UNCHECKED);
	    }
	    else
	    {
	       gbHook=TRUE;
	       CheckMenuItem(ghMenu,IDM_HOOK,MF_CHECKED);
	    }
	 }
	 DrawMenuBar(hWnd);
	 }

	 break;

      case IDM_ABOUT:
	 lpProcAbout = MakeProcInstance( About, ghInst );
	 DialogBox(ghInst, "AboutBox", hWnd, lpProcAbout);
	 FreeProcInstance( lpProcAbout );
	 break;

      case INT_GETSAVESETTINGS:
	 FetchSavedSettings(hWnd);
	 break;

      case INT_SAVESETTINGS:
	 SaveTheSettings();
	 break;
      case INT_DISPLAY:
	 {
	    HCURSOR hCursor;

	    hCursor=SetCursor(ghRcWaitCursor);
	    ShowCursor(TRUE);

	    if(DisplayResult())
	    {
	       InvalidateRect(hWnd,NULL,TRUE);
	    }

	    SetCursor(hCursor);
	    ShowCursor(FALSE);
	 }
	 break;
   }
}

//**************************************************************************
//
//  Function: MemCopy
//
//   Purpose: copies memroy
//
//   Returns: far pointer
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
LPSTR NEAR PASCAL MemCopy(LPSTR lpDest, LPSTR lpSource, int iSize)
{
   _asm {
      push cx
      push si
      push di
      push es
      push ds

      cld
      mov cx,iSize
      shr cx,1
      les di,lpDest
      lds si,lpSource
      rep movsw
      rcl cx,1
      rep movsb

      pop ds
      pop es
      pop di
      pop si
      pop cx
      }
   return (lpDest+iSize);
}

// End-of-File
