/****************************************************************************

	 FILE: SETDLG.C

      PURPOSE: Handles all the messages and functionality of the set dialog

    FUNCTIONS: SetDlg	       - Main message handling function

	       SaveInfo        - Each one of this function is built around
	       SetFlag	       - a switch statement so it can one functionality
	       IncorporateFlag - on many different data types.
	       CopyData
	       WindowLayout
	       StuffData

	       Scrollrglpdf    - supporting functions for scrolling data
	       ScrollrgfAlc
	       ScrollGuide
	       ScrollrgwReserved

	       UpDateFlags     - supporting function

	       HexStr_to_long  - Data conversion functions
	       HexStr_to_word
	       GetDecimal
	       IntStr_to_int


****************************************************************************/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "windows.h"
//#include "commdlg.h"
#include "penwin.h"
#include "globals.h"
#include "setdlg.h"
#include "protos.h"
#include <stdlib.h>

//**************************************************************************
//
//  Function: SetDlg
//
//   Purpose: Handles the message for the Set Dialog
//
//  Messages: WM_ACTIVATE
//	      WM_CLOSE
//	      WM_INITDIALOG
//	      WM_MOVE
//	      WM_COMMAND
//		IDDS_FLAGS
//		IDDS_RC
//		IDDS_RESTORE
//		IDOK
//		IDCANCEL
//	      WM_VSCROLL
//
//   Returns: Standard return
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
BOOL FAR PASCAL SetDlg(hDlg, message, wParam, lParam)
HWND hDlg;
unsigned message;
WORD wParam;
LONG lParam;
{
    int i;  // temp counting variable for for loops

    switch (message)
	{
	case WM_ACTIVATE:
	   // If the window is becoming inactive the current settings will
	   // be saved and everyone will be updated if needed.	If the user
	   // quit the Dialog we'll simply exit.
	   if( (wParam==WA_INACTIVE) && (!gbCanceled) )
	   {
	      HCURSOR hCursor;

	      // get last data...
	      int giCurPos=LOWORD(SendMessage(GetDlgItem(hDlg,IDDS_RC),
				  LB_GETCARETINDEX,0,0L) );

	      hCursor=SetCursor(ghRcWaitCursor);
	      ShowCursor(TRUE);

	      SaveInfo(hDlg,giCurPos);
	      StuffData(hDlg,giCurPos);

	      // Save the settings and ...
	      CopyData(COPY_FROM_TEMP_RC,ALL_OF_IT);
	      ghDlgCurrent=NULL;

	      // ...notify any apps that are waiting for this info.
	      if(IsWindow(ghAppComWin))
		 SendMessage(ghAppComWin,gwAppComMessage,IDX_CUSTOMRCCHANGED,
			     (LONG)(LPRC)&grc);

	      SetCursor(hCursor);
	      ShowCursor(FALSE);

	   }
	   else
	   {
	      ghDlgCurrent=hDlg;
	      gbCanceled=FALSE;
	   }
	   break;

	case WM_CLOSE:
	   DestroyWindow(hDlg);
	   ghwndSet=NULL;
	   ghDlgCurrent=NULL;
	   return TRUE;
	   break;
	case WM_INITDIALOG:
	   {
	      char szOut[80];
	      HWND hwnd;
	      RECT rect;

	      // get the control handles and store them for future use
	      grgControls[0].Label=GetDlgItem(hDlg,IDDS_TEXT0);
	      grgControls[0].Control=GetDlgItem(hDlg,IDDS_0);
	      grgControls[1].Label=GetDlgItem(hDlg,IDDS_TEXT1);
	      grgControls[1].Control=GetDlgItem(hDlg,IDDS_1);
	      grgControls[2].Label=GetDlgItem(hDlg,IDDS_TEXT2);
	      grgControls[2].Control=GetDlgItem(hDlg,IDDS_2);
	      grgControls[3].Label=GetDlgItem(hDlg,IDDS_TEXT3);
	      grgControls[3].Control=GetDlgItem(hDlg,IDDS_3);
	      grgControls[4].Label=GetDlgItem(hDlg,IDDS_TEXT4);
	      grgControls[4].Control=GetDlgItem(hDlg,IDDS_4);
	      grgControls[5].Label=GetDlgItem(hDlg,IDDS_TEXT5);
	      grgControls[5].Control=GetDlgItem(hDlg,IDDS_5);
	      grgControls[6].Label=GetDlgItem(hDlg,IDDS_TEXT6);
	      grgControls[6].Control=GetDlgItem(hDlg,IDDS_6);
	      ghScroll=GetDlgItem(hDlg,IDDS_SCROLL);
	      ghList=GetDlgItem(hDlg,IDDS_FLAGS);

	      // set up list box for strings...
	      hwnd=GetDlgItem(hDlg,IDDS_RC);
	      SendMessage(hwnd,WM_SETREDRAW,FALSE,0L);

	      // ...and fill it.
	      wsprintf((LPSTR)szOut,"X...");
	      lstrcat((LPSTR)szOut,(LPSTR)gRc_Opt[0].npStr);
	      SendMessage(hwnd,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);

	      i=1;
	      while(gRc_Opt[i].npStr!=NULL)
	      {
		 wsprintf((LPSTR)szOut,".....");
		 lstrcat((LPSTR)szOut,(LPSTR)gRc_Opt[i].npStr);
		 SendMessage(hwnd,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);
		 i++;
	      }
	      SendMessage(hwnd,WM_SETREDRAW,TRUE,0L);

	      // Nothing was previously selected
	      giOldPos=0;
	      giCurPos=0;

	      // display option windows according to rc option chosen.
	      WindowLayout(hDlg,giCurPos);

	      // First time through
	      bJustChanged=FALSE;
	      bFirstTime=TRUE;

	      // Copy the global settings into the temparay RC structure
	      // so they can be manipuated
	      CopyData(COPY_TO_TEMP_RC,ALL_OF_IT);
	      StuffData(hDlg,giCurPos);

	      // position the window
	      GetWindowRect(hDlg,&rect);
	      MoveWindow(hDlg,giSetx,giSety,rect.right-rect.left,
			 rect.bottom-rect.top,TRUE);

	      // We're not done...
	      gbCanceled=FALSE;
	   }
	   break;
	case WM_MOVE:
	   {
	      RECT rect;

	      // record window position so it can be displayed in the same spot
	      // the next time.
	      GetWindowRect(hDlg,&rect);
	      giSetx=rect.left;
	      giSety=rect.top;
	   }
	   break;
	case WM_COMMAND:
	  {
	    switch(wParam)
	    {
	       // Any time teh user makes a selection from the flags list box
	       // we'll trap and update what the user sees along with updating
	       // the value of the option.
	       case IDDS_FLAGS:
		  {
		     WORD wNotification=HIWORD(lParam);
		     HANDLE hControl=(HWND)LOWORD(lParam);
		     int iSelection;
		     int giCurPos=LOWORD(SendMessage(GetDlgItem(hDlg,IDDS_RC),
					 LB_GETCARETINDEX,0,0L) );

		     switch(wNotification)
		     {
			case LBN_SELCHANGE:
			   // Incorporate Flag setting into temporary rc struct
			   iSelection=LOWORD(SendMessage(hControl,LB_GETCARETINDEX,0,0L));
			   IncorporateFlag(hDlg,giCurPos,iSelection);
			   SendMessage(hControl,LB_SETCARETINDEX,
				       (WPARAM)iSelection,0L);

			   // update the hedit control with info
			   StuffData(hDlg,giCurPos);
			   UpDateFlags(giCurPos,FALSE);
			   break;
		     }
		  }
		  break;
	       // Each time the user selects a New RC option to toggle we'll
	       // trap and update the dialog so that the proper information
	       // is displayed.
	       case IDDS_RC:
		  {
		     HWND hControl=(HWND)LOWORD(lParam);
		     WORD wNotification=HIWORD(lParam);

		     SendMessage(hControl,WM_SETREDRAW,FALSE,0L);
		     if(wNotification==LBN_SELCHANGE)
		     {
			int giCurPos=LOWORD( SendMessage(hControl,
					 LB_GETCARETINDEX,0,0L) );

			if(giCurPos != giOldPos)
			{
			   char szOut[80];

			   // Set the "X" for the string...
			   wsprintf((LPSTR)szOut,".....");
			   lstrcat((LPSTR)szOut,(LPSTR)gRc_Opt[giOldPos].npStr);

			   SendMessage(hControl,LB_DELETESTRING,giOldPos,0L);
			   SendMessage(hControl,LB_INSERTSTRING,giOldPos,
				       (LONG)(LPSTR)szOut);

			   wsprintf((LPSTR)szOut,"X...");
			   lstrcat((LPSTR)szOut,(LPSTR)gRc_Opt[giCurPos].npStr);

			   SendMessage(hControl,LB_DELETESTRING,giCurPos,0L);
			   SendMessage(hControl,LB_INSERTSTRING,giCurPos,
				       (LONG)(LPSTR)szOut);

			   SendMessage(hControl,LB_SETCARETINDEX,giCurPos,0L);

			   // save the data into the tmp spot
			   if(!bFirstTime)
			      SaveInfo(hDlg,giOldPos);
			   bFirstTime=FALSE;

			   // always save the previous position
			   giOldPos=giCurPos;

			   bJustChanged=TRUE;
			   // Change the window layout and display the data
			   // in the appropriate windows.
			   WindowLayout(hDlg,giCurPos);
			   StuffData(hDlg,giCurPos);
			}
		     }
		     SendMessage(hControl,WM_SETREDRAW,TRUE,0L);
		  }
		  break;

	       // button message that allows the user to restore the previously
	       // set values.
	       case IDDS_RESTORE:
		  {
		     int giCurPos=LOWORD(SendMessage(GetDlgItem(hDlg,IDDS_RC),
					 LB_GETCARETINDEX,0,0L) );

		     CopyData(COPY_TO_TEMP_RC,ALL_OF_IT);
		     StuffData(hDlg,giCurPos);
		  }
		  break;

	       case IDOK:
		  // Save the settings and leave
		  CopyData(COPY_FROM_TEMP_RC,ALL_OF_IT);

	       case IDCANCEL:
		  gbCanceled=TRUE;
		  DestroyWindow(hDlg);
		  ghwndSet=NULL;
		  ghDlgCurrent=NULL;
		  return (TRUE);
		  break;

	       default:
		  break;
	    }

	  }
	case WM_VSCROLL:
	   {
	      BOOL bUpdate=FALSE;
	      switch(wParam)
	      {
		 case SB_LINEDOWN:
		    if(giScrollPos!=giScrollExtent)
		       bUpdate=TRUE;
		    giScrollOld=giScrollPos;
		    giScrollPos++;
		    break;
		 case SB_LINEUP:
		    if(giScrollPos>0)
		       bUpdate=TRUE;
		    giScrollOld=giScrollPos;
		    giScrollPos--;
		    break;
		 case SB_PAGEDOWN:
		    bUpdate=TRUE;
		    giScrollOld=giScrollPos;
		    giScrollPos+=7;
		    break;
		 case SB_PAGEUP:
		    bUpdate=TRUE;
		    giScrollOld=giScrollPos;
		    giScrollPos-=7;
		    break;
		 case SB_THUMBPOSITION:
		    if(giScrollPos!=(int)LOWORD(lParam))
		       bUpdate=TRUE;
		    giScrollOld=giScrollPos;
		    giScrollPos=(int)LOWORD(lParam);
		    break;
		 case SB_THUMBTRACK:
		    break;
	      }
	      if(giScrollPos<0)
		 giScrollPos=0;
	      if(giScrollPos>giScrollExtent)
		 giScrollPos=giScrollExtent;

	      if(bUpdate)
	      {
		 int giCurPos=LOWORD(SendMessage(GetDlgItem(hDlg,IDDS_RC),
				     LB_GETCARETINDEX,0,0L) );
		 SetScrollPos(ghScroll,SB_CTL,giScrollPos,TRUE);
		 StuffData(hDlg,giCurPos);
	      }
	   }
	   break;
	}
    return (FALSE);
}

//**************************************************************************
//
// Note:  The following few functions have the same form.  Each one contains
//	  a switch statement that allows the function to focus on the
//	  particular data type when performing it's manipulations on the
//	  data or whatever.
//
//
//**************************************************************************


//**************************************************************************
//
//  Function: SaveInfo
//
//   Purpose: Grabs the information that the user entered into the controls
//	      and stores it in the temparary RC location.
//
//   Returns: void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL SaveInfo(HWND hDlg,int index)
{
   char szInput[80];
   WORD wMajorType=gRc_Opt[index].wType&TYPE_MAJOR&(~TYPE_FLAGS);
   WORD wMinorType=gRc_Opt[index].wType&(~TYPE_MAJOR)&(~TYPE_FLAGS);
   WORD wFlags	  =gRc_Opt[index].wType&TYPE_FLAGS;

   switch(wMajorType)
   {
      case TYPE_BASIC:
	switch(wMinorType)
	{
	   case TYPE_INT:
	      GetWindowText(grgControls[0].Control,(LPSTR)szInput,BUFMAX);
	      *(int far *)gRc_Opt[index].lpDataTmp=IntStr_to_int((NPSTR)&szInput);
	      break;
	   case TYPE_RECT:
	      {
		 RECT rect;

		 GetWindowText(grgControls[0].Control,(LPSTR)szInput,BUFMAX);
		 rect.left=IntStr_to_int((NPSTR)&szInput);
		 GetWindowText(grgControls[1].Control,(LPSTR)szInput,BUFMAX);
		 rect.top=IntStr_to_int((NPSTR)&szInput);
		 GetWindowText(grgControls[2].Control,(LPSTR)szInput,BUFMAX);
		 rect.right=IntStr_to_int((NPSTR)&szInput);
		 GetWindowText(grgControls[3].Control,(LPSTR)szInput,BUFMAX);
		 rect.bottom=IntStr_to_int((NPSTR)&szInput);
		 *(LPRECT)gRc_Opt[index].lpDataTmp=rect;
	      }
	      break;
	   case TYPE_GUIDE:
	      StuffData(hDlg,index);
	      break;
	}
	break;
      case TYPE_HEX:
	switch(wMinorType)
	{
	   case TYPE_WORD:
	      GetWindowText(grgControls[0].Control,(LPSTR)szInput,BUFMAX);
	      *(WORD far *)gRc_Opt[index].lpDataTmp=HexStr_to_word((LPSTR)&szInput);
	      break;
	   case TYPE_DWORD:
	      GetWindowText(grgControls[0].Control,(LPSTR)szInput,BUFMAX);
	      *(DWORD far *)gRc_Opt[index].lpDataTmp=HexStr_to_long((LPSTR)&szInput);
	      break;
	}
	break;
     case TYPE_POINTER:
	switch(wMinorType)
	{
	   case TYPE_LANGUAGE:
	      {
		 int i=0;
		 LPSTR lpi=(LPSTR)gRc_Opt[index].lpDataTmp;

		 GetWindowText(grgControls[0].Control,(LPSTR)szInput,BUFMAX);

		 while(szInput[i]!=(char)NULL)
		 {
		    *lpi=szInput[i];
		    i++;
		    lpi++;
		 }
		 *lpi=(char)NULL;
	      }
	      break;
	   case TYPE_USER:
	      {
		 int i=0;
		 LPSTR lpi=(LPSTR)gRc_Opt[index].lpDataTmp;

		 GetWindowText(grgControls[0].Control,(LPSTR)szInput,BUFMAX);

		 while(szInput[i]!=(char)NULL)
		 {
		    *lpi=szInput[i];
		    i++;
		    lpi++;
		 }

		 *lpi=(char)NULL;
	      }
	      break;
	}
	break;
     case TYPE_OTHER:
	switch(wMinorType)
	{
	   case TYPE_ALC:
	   case TYPE_DF:
	   case TYPE_RES:
	      StuffData(hDlg,index);
	      break;
	}
	break;
   }
   if(wFlags)
      SendMessage(ghList,LB_RESETCONTENT,0,0L);
}


//**************************************************************************
//
//  Function: SetFlag
//
//   Purpose: Sets the selection of the flags in the flags list box
//
//   Returns: void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL SetFlag(HWND hControl,int index,int iFlag)
{
   WORD wMajorType=gRc_Opt[index].wType&TYPE_MAJOR&(~TYPE_FLAGS);
   WORD wMinorType=gRc_Opt[index].wType&(~TYPE_MAJOR)&(~TYPE_FLAGS);

   switch(wMajorType)
   {
      case TYPE_BASIC:
	switch(wMinorType)
	{
	   case TYPE_INT:
	      {
		 NPOPTION_STR npOption_Str=(NPOPTION_STR)gRc_Opt[index].npAlphaStr;
		 int wValue=*(int far *)gRc_Opt[index].lpDataTmp;

		 if(wValue==(int)npOption_Str[iFlag].wValue)
		    // Set the flag ...
		    SendMessage(hControl,LB_SETSEL,TRUE,MAKELONG(iFlag,0));
		 else
		    SendMessage(hControl,LB_SETSEL,FALSE,MAKELONG(iFlag,0));
	      }
	      break;
	   case TYPE_RECT:
	      break;
	   case TYPE_GUIDE:
	      break;
	}
	break;
      case TYPE_HEX:
	switch(wMinorType)
	{
	   case TYPE_WORD:
	      {
		 NPOPTION_STR npOption_Str=(NPOPTION_STR)gRc_Opt[index].npAlphaStr;
		 WORD wValue=*(WORD far *)gRc_Opt[index].lpDataTmp;

		 if(LOWORD(npOption_Str[iFlag].wValue)==0)
		 {
		    if(wValue==LOWORD(npOption_Str[iFlag].wValue))
		    // Set the flag ...
		       SendMessage(hControl,LB_SETSEL,TRUE,MAKELONG(iFlag,0));
		    else
		       SendMessage(hControl,LB_SETSEL,FALSE,MAKELONG(iFlag,0));
		 }
		 else
		 {
		    if(LOWORD(npOption_Str[iFlag].wValue)==
				 (wValue&LOWORD(npOption_Str[iFlag].wValue)))
		       // Set the flag ...
		       SendMessage(hControl,LB_SETSEL,TRUE,MAKELONG(iFlag,0));
		    else
		       SendMessage(hControl,LB_SETSEL,FALSE,MAKELONG(iFlag,0));
		 }
	      }
	      break;
	   case TYPE_DWORD:
	      {
		 DWORD dwValue,dwAndedValue;
		 NPOPTION_STR npOption_Str=(NPOPTION_STR)gRc_Opt[index].npAlphaStr;
		 dwValue=*(DWORD far *)gRc_Opt[index].lpDataTmp;

		 dwAndedValue=dwValue&npOption_Str[iFlag].wValue;

		 // Special case zero
		 if(npOption_Str[iFlag].wValue==0)
		 {
		    if(npOption_Str[iFlag].wValue==dwValue)
		       SendMessage(hControl,LB_SETSEL,TRUE,MAKELONG(iFlag,0));
		    else
		       SendMessage(hControl,LB_SETSEL,FALSE,MAKELONG(iFlag,0));
		 }
		 else
		 {
		    // If exact match, Set the flag ...
		    if(npOption_Str[iFlag].wValue==dwAndedValue)
		       SendMessage(hControl,LB_SETSEL,TRUE,MAKELONG(iFlag,0));
		    else
		       SendMessage(hControl,LB_SETSEL,FALSE,MAKELONG(iFlag,0));
		 }
	      }
	      break;
	}
	break;
     case TYPE_POINTER:
	switch(wMinorType)
	{
	   case TYPE_LANGUAGE:
	      break;
	   case TYPE_USER:
	      break;
	}
	break;
     case TYPE_OTHER:
	switch(wMinorType)
	{
	   case TYPE_ALC:
	      break;
	   case TYPE_DF:
	      break;
	   case TYPE_RES:
	      break;
	}
	break;
   }
}


//**************************************************************************
//
//  Function: IncorporateFlag
//
//   Purpose: Changes the actual value in the Temparary RC structure depending
//	      on the flag selected.
//
//   Returns: void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL IncorporateFlag(HWND hDlg,int index,int iFlag)
{
   WORD wMajorType=gRc_Opt[index].wType&TYPE_MAJOR&(~TYPE_FLAGS);
   WORD wMinorType=gRc_Opt[index].wType&(~TYPE_MAJOR)&(~TYPE_FLAGS);

   switch(wMajorType)
   {
      case TYPE_BASIC:
	switch(wMinorType)
	{
	   case TYPE_INT:
	      {
		 NPOPTION_STR npOption_Str=(NPOPTION_STR)gRc_Opt[index].npAlphaStr;
		 int wValue=*(int far *)gRc_Opt[index].lpDataTmp;

		 if(wValue==(int)npOption_Str[iFlag].wValue)
		    // remove the flag value...
		    *(int far *)gRc_Opt[index].lpDataTmp=0;
		 else
		    // set the flag value...
		    *(int far *)gRc_Opt[index].lpDataTmp=(int)npOption_Str[iFlag].wValue;
	      }
	      break;
	   case TYPE_RECT:
	      break;
	   case TYPE_GUIDE:
	      break;
	}
	break;
      case TYPE_HEX:
	switch(wMinorType)
	{
	   case TYPE_WORD:
	      {
		 NPOPTION_STR npOption_Str=(NPOPTION_STR)gRc_Opt[index].npAlphaStr;
		 WORD wValue=*(WORD far *)gRc_Opt[index].lpDataTmp;

		 if(wValue&LOWORD(npOption_Str[iFlag].wValue))
		    // remove the flag value...
		    *(WORD far *)gRc_Opt[index].lpDataTmp&=
				      (~(LOWORD(npOption_Str[iFlag].wValue)));
		 else
		    // set the flag value...
		    *(WORD far *)gRc_Opt[index].lpDataTmp|=
					  (LOWORD(npOption_Str[iFlag].wValue));
	      }
	      break;
	   case TYPE_DWORD:
	      {
		 NPOPTION_STR npOption_Str=(NPOPTION_STR)gRc_Opt[index].npAlphaStr;
		 DWORD dwValue=*(DWORD far *)gRc_Opt[index].lpDataTmp;

		 // Special case zero
		 if(npOption_Str[iFlag].wValue==0)
		    *(DWORD far *)gRc_Opt[index].lpDataTmp=0L;

		 else
		 {
		    // if exact match remove...
		    DWORD dwFlagValue=npOption_Str[iFlag].wValue;
		    if(dwFlagValue==(dwValue&dwFlagValue))
		       // remove the flag value...
		       *(DWORD far *)gRc_Opt[index].lpDataTmp&=
					     (~npOption_Str[iFlag].wValue);
		    else
		       // set the flag value...
		       *(DWORD far *)gRc_Opt[index].lpDataTmp|=
					     npOption_Str[iFlag].wValue;
		 }
	      }
	      break;
	}
	break;
     case TYPE_POINTER:
	switch(wMinorType)
	{
	   case TYPE_LANGUAGE:
	      break;
	   case TYPE_USER:
	      break;
	}
	break;
     case TYPE_OTHER:
	switch(wMinorType)
	{
	   case TYPE_ALC:
	      break;
	   case TYPE_DF:
	      break;
	   case TYPE_RES:
	      break;
	}
	break;
   }
}


// If iposition=-1 (or ALL_OF_IT) then copy all, else only copy the one
// position...
//**************************************************************************
//
//  Function: CopyData
//
//   Purpose: Copies the information from the temp location to the global
//	      location (or the other way).
//
//   Returns: void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL CopyData(BOOL bToTemp,int iposition)
{
   WORD wMajorType;
   WORD wMinorType;
   int index;

   if(iposition==-1)
      index=0;
   else
      index=iposition;

   while(gRc_Opt[index].npStr!=NULL)  // there exists some data
   {
      wMajorType=gRc_Opt[index].wType&TYPE_MAJOR&(~TYPE_FLAGS);
      wMinorType=gRc_Opt[index].wType&(~TYPE_MAJOR)&(~TYPE_FLAGS);

      switch(wMajorType)
      {
	 case TYPE_BASIC:
	 case TYPE_HEX:
	   switch(wMinorType)
	   {
	      case TYPE_INT:
		 if(bToTemp)
		    *(int far *)(gRc_Opt[index].lpDataTmp)=*(int far *)(gRc_Opt[index].lpData);
		 else
		    *(int far *)(gRc_Opt[index].lpData)=*(int far *)(gRc_Opt[index].lpDataTmp);
		 break;
	      case TYPE_WORD:
		 if(bToTemp)
		    *(WORD far *)(gRc_Opt[index].lpDataTmp)=*(WORD far *)(gRc_Opt[index].lpData);
		 else
		    *(WORD far *)(gRc_Opt[index].lpData)=*(WORD far *)(gRc_Opt[index].lpDataTmp);
		 break;
	      case TYPE_DWORD:
		 if(bToTemp)
		    *(DWORD far *)(gRc_Opt[index].lpDataTmp)=*(DWORD far *)(gRc_Opt[index].lpData);
		 else
		    *(DWORD far *)(gRc_Opt[index].lpData)=*(DWORD far *)(gRc_Opt[index].lpDataTmp);
		 break;
	      case TYPE_POINT:
		 if(bToTemp)
		    *(POINT far *)(gRc_Opt[index].lpDataTmp)=*(POINT far *)(gRc_Opt[index].lpData);
		 else
		    *(POINT far *)(gRc_Opt[index].lpData)=*(POINT far *)(gRc_Opt[index].lpDataTmp);
		 break;
	      case TYPE_RECT:
		 if(bToTemp)
		    *(RECT far *)(gRc_Opt[index].lpDataTmp)=*(RECT far *)(gRc_Opt[index].lpData);
		 else
		    *(RECT far *)(gRc_Opt[index].lpData)=*(RECT far *)(gRc_Opt[index].lpDataTmp);
		 break;
	      case TYPE_GUIDE:
		 {
		    int i;
		    UINT far *lpiTmp=(UINT far *)gRc_Opt[index].lpDataTmp;
		    UINT far *lpi=(UINT far *)gRc_Opt[index].lpData;

		    if(bToTemp)
		    {
		       for(i=0;i<GUIDE_STRMAX-1;i++)
			  lpiTmp[i]=lpi[i];
		    }
		    else
		    {
		       for(i=0;i<GUIDE_STRMAX-1;i++)
			  lpi[i]=lpiTmp[i];
		    }
		 }
		 break;
	   }
	   break;
	case TYPE_POINTER:
	   switch(wMinorType)
	   {
	      case TYPE_LANGUAGE:
	      case TYPE_USER:
		 {
		    LPSTR lpSource=(LPSTR)gRc_Opt[index].lpDataTmp;
		    LPSTR lpDest=(LPSTR)gRc_Opt[index].lpData;
		    lstrcpy(lpDest,lpSource);
		 }
		 break;
	   }
	   break;
	case TYPE_OTHER:
	   switch(wMinorType)
	   {
	      case TYPE_ALC:
		 {
		    int i;
		    BYTE far *lpiTmp=(BYTE far *)gRc_Opt[index].lpDataTmp;
		    BYTE far *lpi=(BYTE far *)gRc_Opt[index].lpData;

		    if(bToTemp)
		    {
		       for(i=0;i<RGBFALC_STRMAX-1;i++)
			  lpiTmp[i]=lpi[i];
		    }
		    else
		    {
		       for(i=0;i<RGBFALC_STRMAX-1;i++)
			  lpi[i]=lpiTmp[i];
		    }
		 }
		 break;
	      case TYPE_DF:
		 {
		    int i;
		    DWORD far *lpdwTmp=(DWORD far *)gRc_Opt[index].lpDataTmp;
		    DWORD far *lpdw=(DWORD far *)gRc_Opt[index].lpData;

		    if(bToTemp)
		    {
		       for(i=0;i<RGLPDF_STRMAX-1;i++)
			  lpdwTmp[i]=lpdw[i];
		    }
		    else
		    {
		       for(i=0;i<RGLPDF_STRMAX-1;i++)
			  lpdw[i]=lpdwTmp[i];
		    }
		 }
		 break;
	      case TYPE_RES:
		 {
		    int i;
		    WORD far *lpwTmp=(WORD far *)gRc_Opt[index].lpDataTmp;
		    WORD far *lpw=(WORD far *)gRc_Opt[index].lpData;

		    if(bToTemp)
		    {
		       for(i=0;i<RESERVED_STRMAX-1;i++)
			  lpwTmp[i]=lpw[i];
		    }
		    else
		    {
		       for(i=0;i<RESERVED_STRMAX-1;i++)
			  lpw[i]=lpwTmp[i];
		    }
		 }
		 break;
	   }
	   break;
      }
      if(iposition!=-1)
	 break;
      index++;
   }
}


//**************************************************************************
//
//  Function: WindowLayout
//
//   Purpose: Dynamically shows and hides the controls on the right hand
//	      side of the dialog box.
//
//   Returns: void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL WindowLayout(HWND hDlg,int index)
{

   int i;
   NPLABEL_STR nplabels=(NPLABEL_STR)gRc_Opt[index].lplabels;
   WORD wMajorType=gRc_Opt[index].wType&TYPE_MAJOR&(~TYPE_FLAGS);
   WORD wMinorType=gRc_Opt[index].wType&(~TYPE_MAJOR)&(~TYPE_FLAGS);
   WORD wFlags	  =gRc_Opt[index].wType&TYPE_FLAGS;

   // Hide Controls
   for(i=0;i<7;i++)
   {
      ShowWindow(grgControls[i].Label,SW_HIDE);
      ShowWindow(grgControls[i].Control,SW_HIDE);
   }
   ShowWindow(ghScroll,SW_HIDE);
   ShowWindow(ghList,SW_HIDE);

   // nine major cases to check for...
   switch(wMajorType)
   {
      case TYPE_BASIC:
      case TYPE_HEX:
	switch(wMinorType)
	{
	   case TYPE_INT:
	   case TYPE_WORD:
	   case TYPE_DWORD:
	      {
		 if(nplabels[0].lpStr!=NULL)
		    SetWindowText(grgControls[0].Label,nplabels[0].lpStr);

		 ShowWindow(grgControls[0].Label,SW_SHOW);
		 ShowWindow(grgControls[0].Control,SW_SHOW);
	      }
	      break;
	   case TYPE_POINT:
	      break;
	   case TYPE_RECT:
	      {
		 for(i=0;i<4;i++)
		 {
		    if(nplabels[i].lpStr!=NULL)
		       SetWindowText(grgControls[i].Label,nplabels[i].lpStr);

		    ShowWindow(grgControls[i].Label,SW_SHOW);
		    ShowWindow(grgControls[i].Control,SW_SHOW);
		 }
	      }
	      break;
	   case TYPE_GUIDE:
	      {
		 for(i=0;i<7;i++)
		 {
		    if(nplabels[i].lpStr!=NULL)
		       SetWindowText(grgControls[i].Label,nplabels[i].lpStr);

		    ShowWindow(grgControls[i].Label,SW_SHOW);
		    ShowWindow(grgControls[i].Control,SW_SHOW);
		 }
		 // set up scroll bar
		 giScrollOld=0;
		 giScrollPos=0;
		 giScrollExtent=GUIDE_STRMAX-7-1;
		 SetScrollRange(ghScroll,SB_CTL,0,giScrollExtent,FALSE);
		 SetScrollPos(ghScroll,SB_CTL,0,TRUE);
		 ShowWindow(ghScroll,SW_SHOW);
	      }
	      break;
	}
	break;
     case TYPE_POINTER:
	switch(wMinorType)
	{
	   case TYPE_LANGUAGE:
	   case TYPE_USER:
	      {
		 if(nplabels[0].lpStr!=NULL)
		    SetWindowText(grgControls[0].Label,nplabels[0].lpStr);

		 ShowWindow(grgControls[0].Label,SW_SHOW);
		 ShowWindow(grgControls[0].Control,SW_SHOW);
	      }
	      break;
	}
	break;
     case TYPE_OTHER:
	switch(wMinorType)
	{
	   case TYPE_ALC:
	   case TYPE_DF:
	   case TYPE_RES:
	      {
		 for(i=0;i<7;i++)
		 {
		    if(nplabels[i].lpStr!=NULL)
		       SetWindowText(grgControls[i].Label,nplabels[i].lpStr);

		    ShowWindow(grgControls[i].Label,SW_SHOW);
		    ShowWindow(grgControls[i].Control,SW_SHOW);
		 }
		 // set up scroll bar
		 giScrollOld=0;
		 giScrollPos=0;
		 if(wMinorType&TYPE_ALC)
		    giScrollExtent=RGBFALC_STRMAX-7-1;
		 if(wMinorType&TYPE_DF)
		    giScrollExtent=RGLPDF_STRMAX-7-1;
		 if(wMinorType&TYPE_RES)
		    giScrollExtent=RESERVED_STRMAX-7-1;
		 SetScrollRange(ghScroll,SB_CTL,0,giScrollExtent,FALSE);
		 SetScrollPos(ghScroll,SB_CTL,0,TRUE);
		 ShowWindow(ghScroll,SW_SHOW);
	      }
	      break;
	}
	break;
   }
   if(wFlags)
   {
      ShowWindow(ghList,SW_SHOW);
   }
}


//**************************************************************************
//
//  Function: StuffData
//
//   Purpose: Handles placing the current value in either the top right-hand
//	      side control or, if there are multiple values, it calls a
//	      function to do this for it.
//
//   Returns: void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL StuffData(HWND hDlg,int index)
{
   char szOutput[80];
   int i;
   WORD wMajorType=gRc_Opt[index].wType&TYPE_MAJOR&(~TYPE_FLAGS);
   WORD wMinorType=gRc_Opt[index].wType&(~TYPE_MAJOR)&(~TYPE_FLAGS);
   WORD wFlags	  =gRc_Opt[index].wType&TYPE_FLAGS;

   switch(wMajorType)
   {
      case TYPE_BASIC:
      case TYPE_HEX:
	switch(wMinorType)
	{
	   case TYPE_INT:
	      wsprintf((LPSTR)szOutput,"%i",
		       *(int far *)gRc_Opt[index].lpDataTmp);
	      SetWindowText(grgControls[0].Control,(LPSTR)szOutput);
	      break;
	   case TYPE_WORD:
	      wsprintf((LPSTR)szOutput,"%4.4x",
		       *(WORD far *)gRc_Opt[index].lpDataTmp);
	      SetWindowText(grgControls[0].Control,(LPSTR)szOutput);
	      break;
	   case TYPE_DWORD:
	      wsprintf((LPSTR)szOutput,"%8.8lx",
		       *(DWORD far *)gRc_Opt[index].lpDataTmp);
	      SetWindowText(grgControls[0].Control,(LPSTR)szOutput);
	      break;
	   case TYPE_POINT:
	      break;
	   case TYPE_RECT:
	      {
		 int far *lpi=(int far *)gRc_Opt[index].lpDataTmp;

		 for(i=0;i<4;i++)
		 {
		    wsprintf((LPSTR)szOutput,"%i",*lpi++);
		    SetWindowText(grgControls[i].Control,(LPSTR)szOutput);
		 }
	      }
	      break;
	   case TYPE_GUIDE:
	      {
		 ScrollGuide(index,giScrollPos,giScrollOld);
	      }
	      break;
	}
	break;
     case TYPE_POINTER:
	switch(wMinorType)
	{
	   case TYPE_LANGUAGE:
	      {
		 LPSTR lpi=(LPSTR)gRc_Opt[index].lpDataTmp;
		 LPSTR lpOutput=&szOutput[0];

		 while(*lpi!=NULL)
		 {
		    *lpOutput=*lpi;

		    lpOutput++;
		    lpi++;
		 }
		 *lpOutput=NULL;

		 SetWindowText(grgControls[0].Control,(LPSTR)szOutput);
	      }
	      break;
	   case TYPE_USER:
	      {
		 LPSTR lpi=(LPSTR)gRc_Opt[index].lpDataTmp;
		 LPSTR lpOutput=&szOutput[0];

		 if(*lpi==NULL)
		    *lpOutput=NULL;
		 else
		    lstrcpy(lpOutput,lpi);

		 SetWindowText(grgControls[0].Control,(LPSTR)szOutput);
	      }
	      break;
	}
	break;
     case TYPE_OTHER:
	switch(wMinorType)
	{
	   case TYPE_ALC:
	      ScrollrgfAlc(index,giScrollPos,giScrollOld);
	      break;
	   case TYPE_DF:
	      Scrollrglpdf(index,giScrollPos,giScrollOld);
	      break;
	   case TYPE_RES:
	      ScrollrgwReserved(index,giScrollPos,giScrollOld);
	      break;
	}
	break;
   }

   // If Flags listbox is available fill it with the flags...
   if(wFlags)
      UpDateFlags(index,TRUE);

}


//**************************************************************************
//
// Note:  The following function provide support for the above functions.
//
//**************************************************************************



//**************************************************************************
//
//  Function: Scrollrglpdf
//
//   Purpose: Makes the lpdf controls appear to scroll when the scroll
//	      bar is used.
//
//   Returns: void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL Scrollrglpdf(int index,int iStart,int iOldLoc)
{
   int i;
   char szOutput[80],szInput[80];
   NPLABEL_STR nplabels=(NPLABEL_STR)gRc_Opt[index].lplabels;
   DWORD far *lpdw=(DWORD far *)gRc_Opt[index].lpDataTmp;

   if(!bJustChanged    )
   {
      for(i=0;i<7;i++)
      {
	 // extract information from controls
	 GetWindowText(grgControls[i].Control,(LPSTR)szInput,BUFMAX);
	 lpdw[iOldLoc]=HexStr_to_long((NPSTR)szInput);
	 iOldLoc++;
      }
   }
   bJustChanged    =FALSE;
   for(i=0;i<7;i++)
   {
      if(nplabels[iStart].lpStr!=NULL)
	 SetWindowText(grgControls[i].Label,nplabels[iStart].lpStr);

      wsprintf((LPSTR)szOutput,"%8.8lx",lpdw[iStart]);
      SetWindowText(grgControls[i].Control,(LPSTR)szOutput);
      iStart++;
   }
}

//**************************************************************************
//
//  Function: ScrollrgfAlc
//
//   Purpose: makes the ALC values appear to scroll
//
//   Returns: void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL ScrollrgfAlc(int index,int iStart,int iOldLoc)
{
   int i;
   char szOutput[80],szInput[80];
   BYTE far *lpi=(BYTE far *)gRc_Opt[index].lpDataTmp;
   NPLABEL_STR nplabels=(NPLABEL_STR)gRc_Opt[index].lplabels;

   if(!bJustChanged    )
   {
      for(i=0;i<7;i++)
      {
	 // extract information from controls
	 GetWindowText(grgControls[i].Control,(LPSTR)szInput,BUFMAX);
	 lpi[iOldLoc]=(BYTE)HexStr_to_word((NPSTR)szInput);
	 iOldLoc++;
      }
   }
   bJustChanged    =FALSE;
   for(i=0;i<7;i++)
   {
      if(nplabels[iStart].lpStr!=NULL)
	 SetWindowText(grgControls[i].Label,nplabels[iStart].lpStr);

      wsprintf((LPSTR)szOutput,"%2.2x",lpi[iStart]);
      SetWindowText(grgControls[i].Control,(LPSTR)szOutput);
      iStart++;
   }
}

//**************************************************************************
//
//  Function: ScrollGuide
//
//   Purpose: Makes the Guide Structure appear to scroll.
//
//   Returns: void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL ScrollGuide(int index,int iStart,int iOldLoc)
{
   int i;
   char szOutput[80],szInput[80];
   int far *lpi=(int far *)gRc_Opt[index].lpDataTmp;
   NPLABEL_STR nplabels=(NPLABEL_STR)gRc_Opt[index].lplabels;

   if(!bJustChanged    )
   {
      for(i=0;i<7;i++)
      {
	 // extract information from controls
	 GetWindowText(grgControls[i].Control,(LPSTR)szInput,BUFMAX);
	 lpi[iOldLoc]=IntStr_to_int((NPSTR)szInput);
	 iOldLoc++;
      }
   }
   bJustChanged=FALSE;

   for(i=0;i<7;i++)
   {
      if(nplabels[iStart].lpStr!=NULL)
	 SetWindowText(grgControls[i].Label,nplabels[iStart].lpStr);

      wsprintf((LPSTR)szOutput,"%i",lpi[iStart]);
      SetWindowText(grgControls[i].Control,(LPSTR)szOutput);
      iStart++;
      iOldLoc++;
   }
}

//**************************************************************************
//
//  Function: ScrollrgwReserved
//
//   Purpose: Makes teh Reserved values appear to scroll
//
//   Returns: void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL ScrollrgwReserved(int index,int iStart,int iOldLoc)
{
   int i;
   char szOutput[80],szInput[80];
   WORD far *lpi=(WORD far *)gRc_Opt[index].lpDataTmp;
   NPLABEL_STR nplabels=(NPLABEL_STR)gRc_Opt[index].lplabels;

   if(!bJustChanged    )
   {
      for(i=0;i<7;i++)
      {
	 // extract information from controls
	 GetWindowText(grgControls[i].Control,(LPSTR)szInput,BUFMAX);
	 lpi[iOldLoc]=HexStr_to_word((NPSTR)szInput);
	 iOldLoc++;
      }
   }
   bJustChanged    =FALSE;

   for(i=0;i<7;i++)
   {
      if(nplabels[iStart].lpStr!=NULL)
	 SetWindowText(grgControls[i].Label,nplabels[iStart].lpStr);

      wsprintf((LPSTR)szOutput,"%4.4x",lpi[iStart]);
      SetWindowText(grgControls[i].Control,(LPSTR)szOutput);
      iStart++;
   }
}



//**************************************************************************
//
//  Function: UpDateFlags
//
//   Purpose: either fills the Flags list box or just sets the hilight
//
//   Returns: void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL UpDateFlags(int index,BOOL bAddFlags)
{
   NPOPTION_STR npOption_Str=(NPOPTION_STR)gRc_Opt[index].npAlphaStr;

   int iCaret=LOWORD(SendMessage(ghList,LB_GETCARETINDEX,0,0L));
   int iTop=LOWORD(SendMessage(ghList,LB_GETTOPINDEX,0,0L));
   int i=0;

   SendMessage(ghList,WM_SETREDRAW,FALSE,0L);
   if(bAddFlags)
      SendMessage(ghList,LB_RESETCONTENT,0,0L);
   while(*npOption_Str[i].npStr!=NULL)
   {
      if(bAddFlags)
	 SendMessage(ghList,LB_ADDSTRING,0,
		     (LONG)(LPSTR)npOption_Str[i].npStr);
      SetFlag(ghList,index,i);
      i++;
   }

   SendMessage(ghList,LB_SETTOPINDEX,(WPARAM)iTop,0L);
   SendMessage(ghList,LB_SETCARETINDEX,(WPARAM)iCaret,0L);
   SendMessage(ghList,WM_SETREDRAW,TRUE,0L);
}


//**************************************************************************
//
//  Function: HexStr_to_long
//
//   Purpose: Converts a string into a Long hex value.	Notice that there
//	      really isn't any error checking in this routine.  Bummer.
//
//   Returns: DWORD, the hex value of the string.
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
DWORD NEAR HexStr_to_long(LPSTR lpString)
{
   WORD    wStrLen;
   DWORD    dwNumber;
   DWORD    dwNumberTmp;
   WORD    wPosition;

   wStrLen = lstrlen(lpString);

   dwNumber=0;
   wPosition=0;
   while (wStrLen > 0)
   {
      dwNumberTmp=GetDecimal(lpString[wStrLen-1]);

      if(wPosition==0)
	 dwNumber=dwNumberTmp;
      else
	 if(wPosition==1)
	    dwNumber += 0x00000010*dwNumberTmp;
	 else
	    if(wPosition==2)
	       dwNumber += 0x00000100*dwNumberTmp;
	    else
	       if(wPosition==3)
		  dwNumber += 0x00001000*dwNumberTmp;
	       else
		  if(wPosition==4)
		     dwNumber += 0x00010000*dwNumberTmp;
		  else
		     if(wPosition==5)
			dwNumber += 0x00100000*dwNumberTmp;
		     else
			if(wPosition==6)
			   dwNumber += 0x01000000*dwNumberTmp;
			else
			   dwNumber += 0x10000000*dwNumberTmp;
      wPosition++;
      wStrLen--;
   }

   return dwNumber;
}

//**************************************************************************
//
//  Function: HexStr_to_word
//
//   Purpose: Converts a string in Hex form to a WORD.	Also notice there
//	      really isn't any error checking.
//
//   Returns: WORD, the hex value in WORD form.
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
WORD NEAR HexStr_to_word(LPSTR lpString)
{
   WORD    wStrLen;
   WORD    wNumber;
   WORD    wNumberTmp;
   WORD    wPosition;

   wStrLen = lstrlen(lpString);

   wNumber=0;
   wPosition=0;
   while (wStrLen > 0)
   {
      wNumberTmp=GetDecimal(lpString[wStrLen-1]);

      if(wPosition==0)
	 wNumber=wNumberTmp;
      else
	 if(wPosition==1)
	    wNumber += 16*wNumberTmp;
	 else
	    if(wPosition==2)
	       wNumber += (16*16)*wNumberTmp;
	    else
	       wNumber += (16*16*16)*wNumberTmp;


      wPosition++;
      wStrLen--;
   }

   return wNumber;
}

//**************************************************************************
//
//  Function: GetDecimal
//
//   Purpose: converts characters in values.
//
//   Returns: returns the value, int.
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
int NEAR GetDecimal(char c)
{
    if (c >= '0' && c <= '9')
	return ((WORD) c - 48);

    if (c >= 'a' && c <= 'f')
	return ((WORD) c - 97 + 10);

    if (c >= 'A' && c <= 'F')
        return ((WORD) c - 65 + 10);

    if(c==' ')
       return 0;
    return (0);
}

// takes a string from the stack and converts it
//**************************************************************************
//
//  Function: IntStr_to_int
//
//   Purpose: converts a string into an integer.
//
//   Returns: the integer.
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
int NEAR IntStr_to_int(NPSTR npBuf)
{
   return atoi(npBuf);
}


// End-Of-File
