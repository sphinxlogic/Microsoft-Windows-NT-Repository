/****************************************************************************

	 FILE: VIEWDLG.C

      PURPOSE: Handles all the messages and functionality of the VIEW Dialog
	       Box.

    FUNCTIONS: View	   - Main messge handler
	       ChangeAll   - Changes the state of all the items in the
			     List box (Either adds "X" or removes it.)
	       ChangeState - Changes the state of a selected item.
	       AddStrings  - Adds the strings associated with the flags
			     in the flags list box.

****************************************************************************/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "windows.h"
//#include "commdlg.h"
#include "penwin.h"
#include "globals.h"
#include "viewdlg.h"
#include "protos.h"

//**************************************************************************
//
//  Function: View(HWND, unsigned, WORD, LONG)
//
//   Purpose: Handles the messages for the View Dialog
//
//  Messages: WM_ACTIVATE
//	      WM_CLOSE
//	      WM_INITDIALOG
//	      WM_MOVE
//	      WM_COMMAND
//		 IDV_RC
//		 IDV_RCR
//		 IDV_ALLRC
//		 IDV_CLEARALLRC
//		 IDV_RESETALLRC
//		 IDV_ALLRCR
//		 IDV_CLEARALLRCR
//		 IDV_RESETALLRCR
//		 IDV_DONE
//		 IDOK
//		 IDCANCEL
//
//   Returns: Standard return
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
BOOL FAR PASCAL View(hDlg, message, wParam, lParam)
HWND hDlg;
unsigned message;
WORD wParam;
LONG lParam;
{
    int i;

    switch (message)
	{
	/*
	   When the View dialog losses focus, it saves the settings and
	   updates the Main window's list box.  (This doesn't happen when
	   the Cancel button is pressed and the display is not updated the
	   first time through.
	   If the Dialog is just getting the focus ghDlgCurrent is updated
	   so the main message loop in INIT.C will handle the dialog messages
	   correctly.
	*/
	case WM_ACTIVATE:
	   if( (wParam==WA_INACTIVE) && (ghRC_Mem) && (ghRCR_Mem) && (!gbCanceled) )
	   {
	      // save state because we're just loosing focus
	      for(i=0;i<NUMOF_RC_OPTIONS;i++)
		 gRc_Opt[i].bSelect=glpRc_Tmp[i].bSelect;
	      for(i=0;i<NUMOF_RCR_OPTIONS;i++)
		 gRcR_Opt[i].bSelect=glpRcr_Tmp[i].bSelect;
	      ghDlgCurrent=NULL;

	      if(!gbFirstTime)
		 PostMessage(ghwnd,WM_COMMAND,INT_DISPLAY,MAKELONG(ghwnd,0));

	   }
	   else
	      ghDlgCurrent=hDlg;
	   break;
	case WM_CLOSE:
	   DestroyWindow(hDlg);
	   ghwndView=NULL;
	   ghDlgCurrent=NULL;
	   return TRUE;
	   break;
	case WM_INITDIALOG:
	   {
	      RECT rect;

	      // allocate and initialize a dummy array for the options being
	      //  selected.  This memory only exists as long as the dialog does.
	      if( ghRC_Mem=GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT,
				      sizeof(OPTIONS)*NUMOF_RC_OPTIONS) )
	      {
		 if( !(glpRc_Tmp=(LPOPTIONS)GlobalLock(ghRC_Mem)) )
		 {
		    GlobalFree(ghRC_Mem);
		    ErrorBox(IDS_ERRVLOCKINGMEMORY);
		    return FALSE;
		 }
	      }
	      else
	      {
		 ErrorBox(IDS_ERRVOUTOFMEMORY);
		 return FALSE;
	      }

	      // same here...
	      if( ghRCR_Mem=GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT,
				      sizeof(OPTIONS)*NUMOF_RCR_OPTIONS) )
	      {
		 if( !(glpRcr_Tmp=(LPOPTIONS)GlobalLock(ghRCR_Mem)) )
		 {
		    GlobalFree(ghRCR_Mem);
		    ErrorBox(IDS_ERRVLOCKINGMEMORY);
		    return FALSE;
		 }
	      }
	      else
	      {
		 ErrorBox(IDS_ERRVOUTOFMEMORY);
		 return FALSE;
	      }

	      // Have memory by this point.  Now let's initialize it to
	      //  the current global settings...
	      for(i=0;i<NUMOF_RC_OPTIONS;i++)
		 glpRc_Tmp[i].bSelect=gRc_Opt[i].bSelect;

	      for(i=0;i<NUMOF_RCR_OPTIONS;i++)
		 glpRcr_Tmp[i].bSelect=gRcR_Opt[i].bSelect;


	      // Display the options and show which ones are selected.
	      AddStrings(GetDlgItem(hDlg,IDV_RC),(LPOPTIONS)&gRc_Opt);
	      AddStrings(GetDlgItem(hDlg,IDV_RCR),(LPOPTIONS)&gRcR_Opt);

	      // Position the window to the last place it was located.
	      GetWindowRect(hDlg,&rect);
	      MoveWindow(hDlg,giViewx,giViewy,rect.right-rect.left,
			 rect.bottom-rect.top,TRUE);

	      // Set up global.  We have not canceled the dialog yet.
	      gbCanceled=FALSE;
	   }
	   break;
	case WM_MOVE:
	   {
	      RECT rect;

	      // update these two globals so when the dialog is terminated
	      // we will be able to reposition it in the same spot.
	      GetWindowRect(hDlg,&rect);
	      giViewx=rect.left;
	      giViewy=rect.top;
	   }
	   break;
	case WM_COMMAND:
	  {
	    switch(wParam)
	    {
	       case IDV_RC:
		  {
		     if(HIWORD(lParam)==LBN_SELCHANGE)
		     {
			int i;
			i=LOWORD( SendMessage((HWND)LOWORD(lParam),LB_GETCARETINDEX,
					      0,0L) );
			if( SendMessage((HWND)LOWORD(lParam),LB_GETSEL,i,0L)  )
			{
			   ChangeState((HWND)LOWORD(lParam),i,gRc_Opt,glpRc_Tmp);
			}
		     }
		  }
		  break;
	       case IDV_RCR:
		  {
		     if(HIWORD(lParam)==LBN_SELCHANGE)
		     {
			int i;
			i=LOWORD( SendMessage((HWND)LOWORD(lParam),LB_GETCARETINDEX,
					      0,0L) );
			if( SendMessage((HWND)LOWORD(lParam),LB_GETSEL,i,0L)  )
			{
			   ChangeState((HWND)LOWORD(lParam),i,gRcR_Opt,glpRcr_Tmp);
			}
		     }
		  }
		  break;

	       case IDV_ALLRC:
		  //Set all to TRUE....
		  for(i=0;i<NUMOF_RC_OPTIONS;i++)
		     glpRc_Tmp[i].bSelect=TRUE;
		  ChangeAll(GetDlgItem(hDlg,IDV_RC),gRc_Opt,glpRc_Tmp);
		  break;
	       case IDV_CLEARALLRC:
		  //Set all to FALSE....
		  for(i=0;i<NUMOF_RC_OPTIONS;i++)
		     glpRc_Tmp[i].bSelect=FALSE;
		  ChangeAll(GetDlgItem(hDlg,IDV_RC),gRc_Opt,glpRc_Tmp);
		  break;
	       case IDV_RESETALLRC:
		  for(i=0;i<NUMOF_RC_OPTIONS;i++)
		     glpRc_Tmp[i].bSelect=gRc_Opt[i].bSelect;
		  ChangeAll(GetDlgItem(hDlg,IDV_RC),gRc_Opt,glpRc_Tmp);
		  break;

	       case IDV_ALLRCR:
		  //Set all to TRUE...
		  for(i=0;i<NUMOF_RCR_OPTIONS;i++)
		     glpRcr_Tmp[i].bSelect=TRUE;
		  ChangeAll(GetDlgItem(hDlg,IDV_RCR),gRcR_Opt,glpRcr_Tmp);
		  break;
	       case IDV_CLEARALLRCR:
		  for(i=0;i<NUMOF_RCR_OPTIONS;i++)
		     glpRcr_Tmp[i].bSelect=FALSE;
		  ChangeAll(GetDlgItem(hDlg,IDV_RCR),gRcR_Opt,glpRcr_Tmp);
		  break;
	       case IDV_RESETALLRCR:
		  for(i=0;i<NUMOF_RCR_OPTIONS;i++)
		     glpRcr_Tmp[i].bSelect=gRcR_Opt[i].bSelect;
		  ChangeAll(GetDlgItem(hDlg,IDV_RCR),gRcR_Opt,glpRcr_Tmp);
		  break;

	       case IDOK:   // button outside the window for Enter key
	       case IDV_DONE:
		  // save state and exit - fall through to IDCANCEL
		  for(i=0;i<NUMOF_RC_OPTIONS;i++)
		     gRc_Opt[i].bSelect=glpRc_Tmp[i].bSelect;
		  for(i=0;i<NUMOF_RCR_OPTIONS;i++)
		     gRcR_Opt[i].bSelect=glpRcr_Tmp[i].bSelect;


	       case IDCANCEL:

		  // we are canceling and leaving...
		  gbCanceled=TRUE;
		  GlobalUnlock(ghRC_Mem);
		  ghRC_Mem=GlobalFree(ghRC_Mem);
		  GlobalUnlock(ghRCR_Mem);
		  ghRCR_Mem=GlobalFree(ghRCR_Mem);

		  DestroyWindow(hDlg);
		  ghwndView=NULL;
		  ghDlgCurrent=NULL;
		  return (TRUE);
		  break;

	       default:
		  break;
	    }
	  }
	}
    return (FALSE);
}

//**************************************************************************
//
//  Function: ChangeAll
//
//   Purpose: Changes the state of all the items in the List box (Either
//	      adds "X" or removes it.)
//
//   Returns: void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL ChangeAll(HWND hwnd,LPOPTIONS lpStrings,LPOPTIONS lpSelect)
{
   int i;
   char szOut[80];
   int iTop,iCaret;


   iCaret=LOWORD(SendMessage(hwnd,LB_GETCARETINDEX,0,0L));
   iTop=LOWORD(SendMessage(hwnd,LB_GETTOPINDEX,0,0L));
   SendMessage(hwnd,WM_SETREDRAW,FALSE,0L);

   i=0;
   while(lpStrings[i].npStr!=NULL)
   {
      if(lpSelect[i].bSelect)  //=true
	 wsprintf((LPSTR)szOut,"X...");
      else
	 wsprintf((LPSTR)szOut,".....");

      lstrcat((LPSTR)szOut,(LPSTR)lpStrings[i].npStr);

      SendMessage(hwnd,LB_DELETESTRING,i,0L);
      SendMessage(hwnd,LB_INSERTSTRING,i,(LONG)(LPSTR)szOut);
      i++;
   }
   SendMessage(hwnd,LB_SETCARETINDEX,iCaret,0L);
   SendMessage(hwnd,LB_SETTOPINDEX,iTop,0L);
   SendMessage(hwnd,WM_SETREDRAW,TRUE,0L);
}

//**************************************************************************
//
//  Function: ChangeState
//
//   Purpose: Changes the state of a selected item.
//
//   Returns: void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL ChangeState(HWND hwnd,int iPos,LPOPTIONS glpStrings,
			     LPOPTIONS glpSelect)
{
   char szOut[80];

   // change the state
   glpSelect[iPos].bSelect=!glpSelect[iPos].bSelect;

   if(glpSelect[iPos].bSelect)	//=true
      wsprintf((LPSTR)szOut,"X...");
   else
      wsprintf((LPSTR)szOut,".....");

   lstrcat((LPSTR)szOut,(LPSTR)glpStrings[iPos].npStr);

   SendMessage(hwnd,WM_SETREDRAW,FALSE,0L);
   SendMessage(hwnd,LB_DELETESTRING,iPos,0L);
   SendMessage(hwnd,LB_INSERTSTRING,iPos,
	       (LONG)(LPSTR)szOut);
   SendMessage(hwnd,LB_SETCARETINDEX,iPos,0L);
   SendMessage(hwnd,WM_SETREDRAW,TRUE,0L);
}


//**************************************************************************
//
//  Function: AddStrings
//
//   Purpose: Adds the strings associated with the flags
//	      in the flags list box.
//
//   Returns: void
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
void NEAR PASCAL AddStrings(HWND hwndLB,LPOPTIONS glpOptions)
{
   char szOut[80];
   int i;

   SendMessage(hwndLB,LB_RESETCONTENT,0,0L);
   SendMessage(hwndLB,WM_SETREDRAW,FALSE,0L);

   i=0;
   while(*glpOptions[i].npStr!=NULL)
   {
      if(glpOptions[i].bSelect)  //=true
	 wsprintf((LPSTR)szOut,"X...");
      else
	 wsprintf((LPSTR)szOut,".....");

      lstrcat((LPSTR)szOut,(LPSTR)glpOptions[i].npStr);

      SendMessage(hwndLB,LB_ADDSTRING,0,(LONG)(LPSTR)szOut);

      i++;
   }

   SendMessage(hwndLB,WM_SETREDRAW,TRUE,0L);
}

// End-Of-File
