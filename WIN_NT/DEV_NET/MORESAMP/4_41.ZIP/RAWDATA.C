/****************************************************************************

	 FILE: RAWDATA.C

      PURPOSE: Handles diplaying the Raw data.

    FUNCTIONS: PenData


****************************************************************************/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "windows.h"
#include "penwin.h"
#include "globals.h"
#include "protos.h"

//**************************************************************************
//
// Private global variable.
//
PENDATAHEADER gpdh;
//
//**************************************************************************

//**************************************************************************
//
//  Function: PenData
//
//   Purpose: Handles messages for Raw Data window
//
//  Messages: WM_INITDIALOG
//	      WM_PAINT
//	      WM_COMMAND
//
//   Returns: Standard return
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
BOOL FAR PASCAL PenData(HWND hDlg, unsigned message, WORD wParam, LONG lParam)
{
   switch (message)
   {
      case WM_INITDIALOG:
	 {
	    int iHeight, iWidth;

	    GetPenDataInfo(ghpendata,&gpdh,NULL,0L);
	    TPtoDP((LPPOINT)&gpdh.rectBound,2);

	    // determine the complete height and width
	    iWidth=(gpdh.rectBound.right-gpdh.rectBound.left)+
		     2*GetSystemMetrics(SM_CXBORDER);
	    iHeight=gpdh.rectBound.bottom-gpdh.rectBound.top+
		   2*GetSystemMetrics(SM_CYBORDER)+
		   GetSystemMetrics(SM_CYCAPTION);

	    // determine the positioning
	    gpdh.rectBound.top-=(GetSystemMetrics(SM_CYBORDER)+
				GetSystemMetrics(SM_CYCAPTION));
	    gpdh.rectBound.left-=GetSystemMetrics(SM_CXBORDER);

	    MoveWindow(hDlg,gpdh.rectBound.left,gpdh.rectBound.top,
		       max(iWidth,100),
		       max(iHeight,50),TRUE);
	 }
	 break;
      case WM_PAINT:
	 {
	    HDC hdc;
	    PAINTSTRUCT ps;
	    POINT pnt;

	    hdc=BeginPaint(hDlg,&ps);

	    pnt.x=0;
	    pnt.y=0;
	    ClientToScreen(hDlg,&pnt);

	    RedisplayPenData(hdc,ghpendata,&pnt,NULL,1,0xFFFFFFFF);
	    EndPaint(hDlg,&ps);
	 }
	 break;

      case WM_COMMAND:
	 {
	    switch(wParam)
	    {
	       case IDOK:
	       case IDCANCEL:
		  EndDialog(hDlg,TRUE);
		  return TRUE;
		  break;
	    }
	 }
	 break;
   }
   return (FALSE);
}
