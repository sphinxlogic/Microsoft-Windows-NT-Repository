/****************************************************************************

	 FILE: TESTDLG.C

      PURPOSE: Handles of the output to the Test dialog.

    FUNCTIONS: TestDlg

****************************************************************************/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "windows.h"
#include "penwin.h"
#include "globals.h"
#include "testdlg.h"
#include "protos.h"


//**************************************************************************
//
//  Function: TestDlg
//
//   Purpose: Handles message for the Test Dialog
//
//  Messages: WM_ACTIVATE
//	      WM_CLOSE
//	      WM_INITDIALOG
//	      WM_MOVE
//	      WM_COMMAND
//
//   Returns: Standard return
//																		    *
//   History: Date	Author		 Reason
//	      --------	---------------  -------
//	      9/30/92	David Flenniken  create/modified
//
//*************************************************************************
BOOL FAR PASCAL TestDlg(hDlg, message, wParam, lParam)
HWND hDlg;
unsigned message;
WORD wParam;
LONG lParam;
{
    switch (message)
	{
	case WM_ACTIVATE:
	   // This is done for Modeless dialog messgae handling in INIT.C
	   ghDlgCurrent=(wParam==WA_INACTIVE) ? NULL : hDlg;

	   // Set the RC structure every time it gets the focus
	   SendMessage(GetDlgItem(hDlg,IDDT_HEDIT),WM_HEDITCTL,
		       HE_SETRC,(LONG)(LPRC)&grc);
	   SendMessage(GetDlgItem(hDlg,IDDT_BEDIT),WM_HEDITCTL,
		       HE_SETRC,(LONG)(LPRC)&grc);
	   break;
	case WM_CLOSE:
	   DestroyWindow(hDlg);
	   ghwndTest=NULL;
	   ghDlgCurrent=NULL;
	   return TRUE;
	   break;

	case WM_INITDIALOG:
	   {
	      RECT rect;

	      SendMessage(GetDlgItem(hDlg,IDDT_HEDIT),WM_HEDITCTL,
			  HE_SETRC,(LONG)(LPRC)&grc);
	      SendMessage(GetDlgItem(hDlg,IDDT_BEDIT),WM_HEDITCTL,
			  HE_SETRC,(LONG)(LPRC)&grc);

	      // restore to old location
	      GetWindowRect(hDlg,&rect);
	      MoveWindow(hDlg,giTestx,giTesty,rect.right-rect.left,
			 rect.bottom-rect.top,TRUE);
	   }
	   break;

	case WM_MOVE:
	   {
	      RECT rect;

	      // Update window postion state so that the next time it's
	      // displayed it will be in the same location.
	      GetWindowRect(hDlg,&rect);
	      giTestx=rect.left;
	      giTesty=rect.top;
	   }
	   break;
	case WM_COMMAND:
	  {
	  switch(wParam)
	     {
	     case IDOK:
	     case IDCANCEL:
		DestroyWindow(hDlg);
		ghwndTest=NULL;
		ghDlgCurrent=NULL;
		return (TRUE);
		break;

	     default:
		break;
	     }
	  }
	}
    return (FALSE);
}

// End-Of-File
