//***************************************************************************
//
//  PROGRAM:    WinQuery.c
//
//  PURPOSE:    Windows DB-Library Query Application
//
//  FUNCTIONS:
//
//      WinMain() - calls initialization function, processes message loop
//      InitApplication() - initializes window data and registers window
//      InitInstance() - saves instance handle and creates main window
//      DoBackgroundPart() - do background processing
//      MainWndProc() - processes messages
//      StatusWndProc() - processes status bar messages
//      InitDblib() - initializes DB-Library
//      ExitDblib() - exits DB-Library
//      SendQuery() - sends the entire query script to the server
//      BuildCommand() - builds query batch
//      CancelQuery() - cancels the current query
//      ProcessQuery() - processes a small part of the current query
//      BuildRow() - builds a result row
//      BuildHeader() - builds the result header
//      DetermineRowSize() - returns the size of an entire row
//      DetermineColSize() - returns the size of a column
//      Connect() - processes messages for "Connect" dialog box
//      About() - processes messages for "About" dialog box
//      PadCol() - pad with spaces
//      ErrorHandler() - processes DB-Library errors
//      MessageHandler() - processes SQL Server messages
//
//  COMMENTS:
// 
//  COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//***************************************************************************

#define STRICT
#include <windows.h>            // standard Windows include file
#include <commdlg.h>            // common dialog include file
#include <string.h>             // standard C string include file
#define DBMSWIN                 // needed to define environment
#include <sqlfront.h>           // standard dblib include file
#include <sqldb.h>              // standard dblib include file
#include "winutil.h"            // utility function include file
#include "winquery.h"           // specific to this program
#include "windlg.h"             // dialogs include file


// GLOBAL VARIABLES
// connection to SQL Server
DBPROCESS *pDbproc = (DBPROCESS *)NULL; 

char szAppName[] = "WinQuery";          // application name
char szStatusName[] = "WQStatusBar";    // status bar name
char szDblibVersion[50] = "";           // DB-Library version string

FARPROC lpMessageHandler,               // pointer to MessageHandler
    lpErrorHandler;                     // pointer to ErrorHandler
HINSTANCE hInst;                        // current instance
HWND hWnd;                              // current window
HWND hQuery,                            // handle to query edit control
    hResult,                            // handle to result edit control 
    hStatus;                            // handle to status bar

HGLOBAL hResultDS;
LPSTR lpResultDS;
HGLOBAL hQueryDS;
LPSTR lpQueryDS;

BOOL bQueryPending = FALSE;         // query pending
int iProcessQueryAction;            // next process query action
int iSendQueryAction;               // next send query script action
int iDoBackgroundPartAction;        // next background processing action

char szSQLServer[MAX_NAME+1] = "";      // name of current SQL Server
char szStatus[100] = "Ready";           // string displayed on status bar

HCURSOR hHourGlass, hSaveCursor;

GLOBALMEM glbmemResult, 
    glbmemSend, 
    glbmemRow, 
    glbmemHeader, 
    glbmemUnderline;

//HGLOBAL hResultBuffer;                  // handle to result buffer
//LPSTR lpResultBuffer;                   // long pointer to result buffer

// Variables for file I/O and common dialogs
OPENFILENAME ofnQuery;
OPENFILENAME ofnResult;

char lpstrFilterQuery[128] = "SQL File (*.sql)\0*.sql\0All Files (*.*)\0*.*\0";
char lpstrCustomFilterQuery[128] = "";
char lpstrInitDirQuery[128] = "\0";
char lpstrFileQuery[128] = "\0";

char lpstrFilterResult[128] = "Result File (*.res)\0*.res\0All Files (*.*)\0*.*\0";
char lpstrCustomFilterResult[128] = "";
char lpstrInitDirResult[128] = "\0";
char lpstrFileResult[128] = "\0";


//***************************************************************************
//
//  FUNCTION:   WinMain()
//
//  PURPOSE:    Calls initialization function, processes message loop
//
//  COMMENTS:
//
//***************************************************************************

int PASCAL WinMain(
    HINSTANCE hInstance,
    HINSTANCE hPrevInstance,
    LPSTR lpCmdLine,
    int nCmdShow)
{
    MSG msg;            // message
    HACCEL hAccel;      // handle to accelerator table

    if (!hPrevInstance)
        // Initialize shared things
        if (!InitApplication(hInstance))
            return (FALSE);

    // Perform initializations that apply to a specific instance
    if (!InitInstance(hInstance, nCmdShow))
        return (FALSE);

    hAccel = LoadAccelerators (hInstance, "WinQueryAccelerators");

    while (TRUE)
    {
        if (PeekMessage(&msg,
            NULL,
            0,
            0,
            PM_REMOVE))
        {
            // Message in queue, process it
            if (msg.message != WM_QUIT)
            {
                if (!TranslateAccelerator (hWnd, hAccel, &msg))
                {
                    TranslateMessage(&msg); // Translates virtual key codes
                    DispatchMessage(&msg);  // Dispatches message to window
                }
            }
            else // WM_QUIT message
            {
                break; // while loop
            }
        }
        else // no message in queue */
        {
            // Do background processing if necessary
            if (!DoBackgroundPart())
            {
                WaitMessage();
            }
        }
    }

    return (msg.wParam);        // Returns the value from PostQuitMessage
}

//***************************************************************************
//
//  FUNCTION:   InitApplication()
//
//  PURPOSE:    Initializes window data and registers window class
//
//  COMMENTS:
//
//***************************************************************************

BOOL InitApplication(
    HINSTANCE hInstance)
{
    WNDCLASS  wcMain, wcStat;

    // Fill in window class structure with parameters that describe the
    // main window.
    wcMain.style = NULL;                    // Class style(s)
    // Function to retrieve messages for windows of this class
    wcMain.lpfnWndProc = (WNDPROC) MainWndProc;
    wcMain.cbClsExtra = 0;                  // No per-class extra data
    wcMain.cbWndExtra = 0;                  // No per-window extra data
    wcMain.hInstance = hInstance;           // Application that owns the class
    wcMain.hIcon = LoadIcon(hInstance, "WinQueryIcon"); // winquery icon
    wcMain.hCursor = LoadCursor(NULL, IDC_ARROW);       // arrow cursor
    wcMain.hbrBackground = GetStockObject(WHITE_BRUSH); // white background
    wcMain.lpszMenuName =  "WinQueryMenu";  // Name of menu resource in .RC file
    wcMain.lpszClassName = szAppName;       // Name used in call to CreateWindow

    // Register the window class and return success/failure code
    if (!RegisterClass(&wcMain))
        return (FALSE);

    // Fill in window class structure with parameters that describe the
    // status bar window.
    wcStat.style = CS_OWNDC | CS_HREDRAW | CS_VREDRAW;  // Class style(s)
    // Function to retrieve messages for windows of this class
    wcStat.lpfnWndProc = StatusWndProc;
    wcStat.cbClsExtra = 0;                  // No per-class extra data
    wcStat.cbWndExtra = 0;                  // No per-window extra data
    wcStat.hInstance = hInstance;           // Application that owns the class
    wcStat.hIcon = NULL;                    // no icon
    wcStat.hCursor = LoadCursor(NULL, IDC_ARROW);       // arrow cursor
    wcStat.hbrBackground = GetStockObject(WHITE_BRUSH); // white background
    wcStat.lpszMenuName =  NULL;            // Name of menu resource in .RC file
    wcStat.lpszClassName = szStatusName;    // Name used in call to CreateWindow

    if (!RegisterClass(&wcStat))
        return (FALSE);

    return (TRUE);

}

//***************************************************************************
//
//  FUNCTION:   InitInstance()
//
//  PURPOSE:    Saves instance handle and creates main window
//
//  COMMENTS:
//
//**************************************************************************

BOOL InitInstance(
    HINSTANCE hInstance,
    int nCmdShow)
{
    DWORD dwEditStyle;      // style bits for edit controls
    HFONT hFixedFont;       // handle to stock fixed font

    // Save the instance handle in static variable, which will be used in
    // many subsequent calls from this application to Windows.
    hInst = hInstance;

    // Create a main window for this application instance
    hWnd = CreateWindow(szAppName,  // Class to use
        "WinQuery",                 // Text for window title bar
        WS_OVERLAPPEDWINDOW,        // Window style
        CW_USEDEFAULT,              // Default horizontal position
        CW_USEDEFAULT,              // Default vertical position
        CW_USEDEFAULT,              // Default width
        CW_USEDEFAULT,              // Default height
        NULL,                       // Overlapped windows have no parent
        NULL,                       // Use the window class menu
        hInstance,                  // This instance owns this window
        NULL);                      // Pointer not needed

    // If window could not be created, return "failure"
    if (!hWnd)
        return (FALSE);

    // Set style bit for edit controls
    dwEditStyle = WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL |
        ES_LEFT | ES_MULTILINE | ES_AUTOHSCROLL | ES_AUTOVSCROLL;


#if defined (WIN32)
    // Create query edit window
    hQuery = CreateWindow("edit",   // edit control class
        NULL,                       // text of control
        dwEditStyle,                // style params
        0, 0, 0, 0,                 // initial dimensions all 0
        hWnd,                       // parent handle
        (HMENU) IDE_QUERY,          // unique child-window identifier
        hInst,                      // instance handle
        NULL);

    // Create result edit window
    hResult = CreateWindow("edit",  // edit control class
        NULL,                       // text of control
        dwEditStyle,                // style params
        0, 0, 0, 0,                 // initial dimensions all 0
        hWnd,                       // parent handle
        (HMENU) IDE_RESULT,         // unique child-window identifier
        hInst,                      // instance handle
        NULL);

#else
    hResultDS = GlobalAlloc (GMEM_DDESHARE | GMEM_MOVEABLE | GMEM_ZEROINIT,
        MAX_EDIT_SIZE);

    if (hResultDS)
    {
        lpResultDS = GlobalLock (hResultDS);
        if (lpResultDS)
        {
            lpResultDS = GlobalLock (hResultDS);
            LocalInit (HIWORD((LONG)lpResultDS),
                0,
                (UINT)(GlobalSize(hResultDS) - 16));
            UnlockSegment (HIWORD((LONG)lpResultDS));
    
            // Create result edit window
            hResult = CreateWindow("edit",  // edit control class
                NULL,                       // text of control
                dwEditStyle,                // style params
                0, 0, 0, 0,                 // initial dimensions all 0
                hWnd,                       // parent handle
                (HMENU) IDE_RESULT,         // unique child-window identifier
                (HINSTANCE) HIWORD((LONG)lpResultDS),     // instance handle
                NULL);
        }
    }
    if (!hResultDS || !lpResultDS)
    {
        ERRBOX (hWnd, "Result window will have limited space available");
        // Create result edit window
        hResult = CreateWindow("edit",  // edit control class
            NULL,                       // text of control
            dwEditStyle,                // style params
            0, 0, 0, 0,                 // initial dimensions all 0
            hWnd,                       // parent handle
            (HMENU) IDE_RESULT,         // unique child-window identifier
            hInst,                      // instance handle
            NULL);
    }

    hQueryDS = GlobalAlloc (GMEM_DDESHARE | GMEM_MOVEABLE | GMEM_ZEROINIT,
        MAX_EDIT_SIZE);

    if (hQueryDS)
    {
        lpQueryDS = GlobalLock (hQueryDS);
        if (lpQueryDS)
        {
            LocalInit (HIWORD((LONG)lpQueryDS),
                0,
                (UINT)(GlobalSize(hQueryDS) - 16));
            UnlockSegment (HIWORD((LONG)lpQueryDS));
    
            // Create query edit window
            hQuery = CreateWindow("edit",   // edit control class
                NULL,                       // text of control
                dwEditStyle,                // style params
                0, 0, 0, 0,                 // initial dimensions all 0
                hWnd,                       // parent handle
                (HMENU) IDE_QUERY,          // unique child-window identifier
                (HINSTANCE) HIWORD((LONG)lpQueryDS),      // instance handle
                NULL);
        }
    }    
    if (!hQueryDS || !lpQueryDS)
    {
        ERRBOX (hWnd, "Query window will have limited space available");
        // Create query edit window
        hQuery = CreateWindow("edit",   // edit control class
            NULL,                       // text of control
            dwEditStyle,                // style params
            0, 0, 0, 0,                 // initial dimensions all 0
            hWnd,                       // parent handle
            (HMENU) IDE_QUERY,          // unique child-window identifier
            hInst,                      // instance handle
            NULL);
    }

#endif

    SendMessage (hQuery,
        EM_LIMITTEXT,
        (WPARAM)MAX_EDIT_SIZE,
        0);
        
    SendMessage (hResult,
        EM_LIMITTEXT,
        (WPARAM)MAX_EDIT_SIZE,
        0);

    // Create status bar window
    hStatus = CreateWindow(szStatusName,    // edit control class
        NULL,                               // text of control
        WS_CHILD | WS_VISIBLE | WS_BORDER,  // style params
        0, 0, 0, 0,                         // initial dimensions all 0
        hWnd,                               // parent handle
        (HMENU) IDE_STATUS,                 // unique child-window identifier
        hInst,                              // instance handle
        NULL);

    // Get stock fixed font, set both edit controls to this fixed font
    hFixedFont = GetStockObject (ANSI_FIXED_FONT);
    SendMessage(hQuery,
        WM_SETFONT,
        (WPARAM)hFixedFont,
        FALSE);
    SendMessage(hResult,
        WM_SETFONT,
        (WPARAM)hFixedFont,
        FALSE);

    // Initialize edit controls window text
    SetWindowText (hQuery, "");
    SetWindowText (hResult, "");

    SetFocus (hQuery);

    hHourGlass = LoadCursor (NULL, IDC_WAIT);

    // Fill in OPENFILENAME struct
    ofnQuery.lStructSize = sizeof(OPENFILENAME);
    ofnQuery.hwndOwner = hWnd;
    ofnQuery.lpstrFilter = lpstrFilterQuery;
    ofnQuery.nFilterIndex = 1;
    ofnQuery.lpstrFile = lpstrFileQuery;
    ofnQuery.nMaxFile = sizeof(lpstrFileQuery);
    ofnQuery.lpstrCustomFilter = lpstrCustomFilterQuery;
    ofnQuery.nMaxCustFilter = sizeof(lpstrCustomFilterQuery);
    ofnQuery.lpstrInitialDir = lpstrInitDirQuery;
    ofnQuery.Flags = OFN_FILEMUSTEXIST | OFN_OVERWRITEPROMPT;
    ofnQuery.lpfnHook = NULL;
    ofnQuery.lpstrTitle = NULL;

    ofnResult.lStructSize = sizeof(OPENFILENAME);
    ofnResult.hwndOwner = hWnd;
    ofnResult.lpstrFilter = lpstrFilterResult;
    ofnResult.nFilterIndex = 1;
    ofnResult.lpstrFile = lpstrFileResult;
    ofnResult.nMaxFile = sizeof(lpstrFileResult);
    ofnResult.lpstrCustomFilter = lpstrCustomFilterResult;
    ofnResult.nMaxCustFilter = sizeof(lpstrCustomFilterResult);
    ofnResult.lpstrInitialDir = lpstrInitDirResult;
    ofnResult.Flags = OFN_FILEMUSTEXIST | OFN_OVERWRITEPROMPT;
    ofnResult.lpfnHook = NULL;
    ofnResult.lpstrTitle = NULL;

    AllocMem (&glbmemResult);
    AllocMem (&glbmemSend);
    AllocMem (&glbmemRow);
    AllocMem (&glbmemHeader);
    AllocMem (&glbmemUnderline);
    //MemAlloc (&hResultBuffer, &lpResultBuffer);

    ShowWindow(hWnd, nCmdShow);     // Show the window
    UpdateWindow(hWnd);             // Sends WM_PAINT message
    return (TRUE);
}

//***************************************************************************
//
//  FUNCTION:   MainWndProc()
//
//  PURPOSE:    Processes messages
//
//  MESSAGES:
//
//      WM_COMMAND - application menu
//      WM_CREATE - create window
//      WM_DESTROY - destroy window
//      WM_SETFOCUS - window got focus
//      WM_SIZE - size window
//
//  COMMENTS:
//
//**************************************************************************

LRESULT CALLBACK MainWndProc(
    HWND hWindow,
    UINT message,
    WPARAM wParam,
    LPARAM lParam)
{
    DLGPROC lpDlgProc;              // pointer to dialog function
    HDC hDC;
    TEXTMETRIC tm;
    int nWidth, nHeight;            // width and height of window
    int yQuery, yResult, nHeightQuery, nHeightResult;
    RECT rect;
    static int nWindowState;
    static HWND hCurrentFocus;      // handle of edit control with focus
    static int wCharHeight;
    OPENFILENAME *pofn;

    switch (message)
    {
    case WM_COMMAND:    // message: command from application menu
        switch (LOWORD(wParam))
        {
        case IDM_OPEN:
            if (hCurrentFocus == hQuery)
            {
                pofn = &ofnQuery;
            }
            else
            {
                pofn = &ofnResult;
            }

            if (GetOpenFileName (pofn))
            {
                if (!ReadFileIntoEdit (hCurrentFocus, pofn->lpstrFile))
                {
                    ERRBOX (hWindow, "Error opening file");
                    pofn->lpstrFile[0] = '\0';
                }
            }

            break;

        case IDM_SAVE:
            if (hCurrentFocus == hQuery)
            {
                pofn = &ofnQuery;
            }
            else
            {
                pofn = &ofnResult;
            }

            if (pofn->lpstrFile[0] != '\0')
            {
                if (!WriteFileFromEdit (hCurrentFocus, pofn->lpstrFile))
                {
                    ERRBOX (hWindow, "Error writing to file");
                    pofn->lpstrFile[0] = '\0';
                }
                break;
            }
            // fall through to Save As processing 
            // break;

        case IDM_SAVEAS:
            if (hCurrentFocus == hQuery)
            {
                pofn = &ofnQuery;
            }
            else
            {
                pofn = &ofnResult;
            }

            if (GetSaveFileName (pofn))
            {
                if (!WriteFileFromEdit (hCurrentFocus, pofn->lpstrFile))
                {
                    ERRBOX (hWindow, "Error writing to file");
                    pofn->lpstrFile[0] = '\0';
                }
            }
            break;

        case IDM_EXIT:
            DestroyWindow (hWindow);
            break;

        case IDM_UNDO:
            // Undo last change in edit control
            SendMessage (hCurrentFocus, WM_UNDO, 0, 0L);
            break;

        case IDM_CUT:
            // Cut selected text from edit control
            SendMessage (hCurrentFocus, WM_CUT, 0, 0L);
            break;

        case IDM_COPY:
            // Copy selected text from edit control
            SendMessage (hCurrentFocus, WM_COPY, 0, 0L);
            break;

        case IDM_PASTE:
            // Paste text from clipboard into edit control
            SendMessage (hCurrentFocus, WM_PASTE, 0, 0L);
            break;

        case IDM_DELETE:
            // Delete text from edit control
            SendMessage (hCurrentFocus, WM_CLEAR, 0, 0L);
            break;

        case IDM_CONNECT:
            lpDlgProc = (DLGPROC) MakeProcInstance((FARPROC)Connect, hInst);

            DialogBox(hInst,        // current instance
                "ConnectBox",       // resource to use
                hWindow,            // parent handle
                lpDlgProc);         // Connect() instance address

            FreeProcInstance((FARPROC)lpDlgProc);
            break;

        case IDM_EXECUTE:
            if (pDbproc != (DBPROCESS *)NULL)
            {
                if (!bQueryPending)
                {
                    FreeMem (&glbmemResult);
                    AllocMem (&glbmemResult);
                    //SetWindowText (hResult, glbmemResult.lpvMem);
                    SetWindowText (hResult, "");
                    
                    // tell DoBackgroundPart() what to do
                    bQueryPending = TRUE;
                    iDoBackgroundPartAction = DO_SEND;
                    // tell SendQuery() what to do
                    iSendQueryAction = DO_FIRSTQUERY;
                }
                else // query pending
                {
                    ERRBOX (hWindow, "Query still pending");
                }
            }
            else // null dbproc
            {
                ERRBOX(hWindow, "No connection available");
            }
            break;

        case IDM_CANCEL:
            if (pDbproc != (DBPROCESS *)NULL)
            {
                CancelQuery (pDbproc);
            }
            else // null dbproc
            {
                ERRBOX(hWindow, "No connection available");
            }
            break;

        case IDM_CLEAR:
            if (!bQueryPending)
            {
                ofnQuery.lpstrFile[0] = '\0';
                ofnResult.lpstrFile[0] = '\0';
                SetWindowText (hQuery, "");

                FreeMem (&glbmemResult);
                AllocMem (&glbmemResult);
                //SetWindowText (hResult, glbmemResult.lpvMem);
                SetWindowText (hResult, "");
            }
            else // query pending
            {
                ERRBOX (hWindow, "Query still pending.");
            }
            break;

        case IDM_FOCUSQUERY:
            nWindowState = WIN_SPLIT;
            hCurrentFocus = hQuery;
            GetClientRect(hWindow, &rect);
            SendMessage (hWindow,
                WM_SIZE,
                (WPARAM)SIZE_RESTORED,
                (LPARAM)MAKELONG(rect.right, rect.bottom));
            break;

        case IDM_FOCUSRESULT:
            nWindowState = WIN_SPLIT;
            hCurrentFocus = hResult;
            GetClientRect(hWindow, &rect);
            SendMessage (hWindow,
                WM_SIZE,
                (WPARAM)SIZE_RESTORED,
                (LPARAM)MAKELONG(rect.right, rect.bottom));
            break;

        case IDM_MAXQUERY:
            nWindowState = WIN_MAXQUERY;
            hCurrentFocus = hQuery;
            GetClientRect(hWindow, &rect);
            SendMessage (hWindow,
                WM_SIZE,
                (WPARAM)SIZE_RESTORED,
                (LPARAM)MAKELONG(rect.right, rect.bottom));
            break;

        case IDM_MAXRESULT:
            nWindowState = WIN_MAXRESULT;
            hCurrentFocus = hResult;
            GetClientRect(hWindow, &rect);
            SendMessage (hWindow,
                WM_SIZE,
                (WPARAM)SIZE_RESTORED,
                (LPARAM)MAKELONG(rect.right, rect.bottom));
            break;

        case IDM_CYCLE:
            if (nWindowState == WIN_SPLIT)
            {
                nWindowState = WIN_MAXRESULT;
                hCurrentFocus = hResult;
            }
            else
            {
                if (nWindowState == WIN_MAXQUERY)
                {
                    nWindowState = WIN_SPLIT;
                    hCurrentFocus = hQuery;
                }
                else
                {
                    if (nWindowState == WIN_MAXRESULT)
                    {
                        nWindowState = WIN_MAXQUERY;
                        hCurrentFocus = hQuery;
                    }
                }
            }

            GetClientRect(hWindow, &rect);
            SendMessage (hWindow,
                WM_SIZE,
                (WPARAM)SIZE_RESTORED,
                (LPARAM)MAKELONG(rect.right, rect.bottom));
            break;

        case IDM_ABOUT:
            lpDlgProc = (DLGPROC) MakeProcInstance((FARPROC)About, hInst);

            DialogBox(hInst,        // current instance
                "AboutBox",         // resource to use
                hWindow,            // parent handle
                lpDlgProc);         // About() instance address

            FreeProcInstance((FARPROC)lpDlgProc);
            break;

        case IDE_QUERY:
#if defined (WIN32)
            switch (HIWORD(wParam))
#else
            switch (HIWORD(lParam))
#endif
            {
            case EN_ERRSPACE:
                MSGBOX (hWindow, "Query edit control out of space");
                //CancelQuery(pDbproc);
                break;
            case EN_SETFOCUS:
                hCurrentFocus = hQuery;
                break;
            }
            break;

        case IDE_RESULT:
#if defined (WIN32)
            switch (HIWORD(wParam))
#else
            switch (HIWORD(lParam))
#endif
            {
            case EN_ERRSPACE:
                MSGBOX (hWindow, "Result edit control out of space");
                //CancelQuery(pDbproc);
                break;
            case EN_SETFOCUS:
                hCurrentFocus = hResult;
                break;
            }
            break;

        default:
            // Pass it on if unproccessed
            return (DefWindowProc(hWindow, message, wParam, lParam));

        }
        break; // case WM_COMMAND

    case WM_CREATE:     // message: window being created
        hCurrentFocus = hQuery;
        nWindowState = WIN_SPLIT;

        hDC = GetDC (hWindow);
        GetTextMetrics (hDC, &tm);
        wCharHeight = tm.tmHeight + tm.tmExternalLeading + 4;
        ReleaseDC (hWindow, hDC);

        if (!InitDblib())
        {
            ERRBOX(hWindow, "Failed to initialize DB-Library");
        }
        break; // case WM_CREATE

    case WM_QUERYENDSESSION:    // message: OK to exit Windows?
        return (TRUE);
        break; // case WM_QUERYENDSESSION
        
    case WM_CLOSE:      // message: window being closed
        DestroyWindow (hWnd);
        break; // case WM_CLOSE
        
    case WM_DESTROY:    // message: window being destroyed
        ExitDblib();
        FreeMem (&glbmemResult);
        FreeMem (&glbmemSend);
        FreeMem (&glbmemRow);
        FreeMem (&glbmemHeader);
        FreeMem (&glbmemUnderline);

        PostQuitMessage(0);
        break; // case WM_DESTORY

    case WM_SETFOCUS:   // message: window now has focus
        SetFocus (hCurrentFocus);
        break; // case WM_SETFOCUS

    case WM_SIZE:       // message: window resized
        // Resize query and result windows to take up half of window
        nWidth = LOWORD(lParam);
        nHeight = HIWORD(lParam);
        
        if (nWindowState == WIN_SPLIT)
        {
            yQuery = 0;
            yResult = (nHeight/2)-(wCharHeight/2);
            nHeightQuery = (nHeight/2)-(wCharHeight/2);
            nHeightResult = (nHeight/2)-(wCharHeight/2);
        }

        if (nWindowState == WIN_MAXQUERY)
        {
            yQuery = 0;
            yResult = 0;
            nHeightQuery = nHeight-wCharHeight;
            nHeightResult = 0;
        }
        
        if (nWindowState == WIN_MAXRESULT)
        {
            yQuery = 0;
            yResult = 0;
            nHeightQuery = 0;
            nHeightResult = nHeight-wCharHeight;
        }
        
        MoveWindow(hQuery,      // window to move
            0,                  // x coord
            yQuery,             // y coord
            nWidth,             // width
            nHeightQuery,       // height
            TRUE);              // repaint

        MoveWindow(hResult,     // window to move
            0,                  // x coord
            yResult,            // y coord
            nWidth,             // width
            nHeightResult,      // height
            TRUE);              // repaint

        MoveWindow(hStatus,         // window to move
            0,                      // x coord
            nHeight-wCharHeight,    // y coord
            nWidth,                 // width
            wCharHeight,            // height
            TRUE);                  // repaint
            
        SetFocus (hCurrentFocus);
            
        /*
        if (bQueryPending)
        {
            SendMessage (hResult,
                WM_SETREDRAW,
                TRUE,
                0);
            InvalidateRect (hResult, NULL, TRUE);
            UpdateWindow (hResult);
            SendMessage (hResult,
                WM_SETREDRAW,
                FALSE,
                0);
        }
        else
        {
            InvalidateRect (hResult, NULL, TRUE);
            UpdateWindow (hResult);
        }
        */

        break; // case WM_SIZE

    default:
        // Pass it on if unproccessed
        return (DefWindowProc(hWindow, message, wParam, lParam));
    }
    return (NULL);
}

//***************************************************************************
//
//  FUNCTION:   StatusWndProc()
//
//  PURPOSE:    Processes messages
//
//  MESSAGES:
//
//      WM_PAINT -
//
//  COMMENTS:
//
//**************************************************************************

LRESULT CALLBACK StatusWndProc(
    HWND hWindow,
    UINT message,
    WPARAM wParam,
    LPARAM lParam)
{
    PAINTSTRUCT ps;
    TEXTMETRIC tm;
    char szStr[100];
    int wCharWidth;

    switch (message)
    {
    case WM_PAINT:    // message: repaint status bar window
        BeginPaint (hWindow, &ps);
        SetBkMode (ps.hdc, TRANSPARENT);
        GetTextMetrics (ps.hdc, &tm);
        wCharWidth = tm.tmAveCharWidth;
        wsprintf (szStr, szStatus);
        TextOut (ps.hdc, 0, 0, szStr, lstrlen(szStr));
        if (szSQLServer[0] == '\0')
            wsprintf (szStr, "Server: %s", (LPSTR)"(none)");
        else
            wsprintf (szStr, "Server: %s", (LPSTR)szSQLServer);
        TextOut (ps.hdc, wCharWidth*20, 0, szStr, lstrlen(szStr));
        if (pDbproc == (DBPROCESS *)NULL)
            wsprintf (szStr, "Database: %s", (LPSTR)"(none)");
        else
            wsprintf (szStr, "Database: %s", (LPSTR)dbname(pDbproc));
        TextOut (ps.hdc, wCharWidth*50, 0, szStr, lstrlen(szStr));
        EndPaint (hWindow, &ps);
        break;
    default:
        return (DefWindowProc(hWindow, message, wParam, lParam));
    }
    return (NULL);
}

//***************************************************************************
//
//  FUNCTION:   DoBackgroundPart()
//
//  PURPOSE:    Do background processing
//
//  COMMENTS:
//
//**************************************************************************

BOOL DoBackgroundPart (void)
{
    BOOL bContinue;     // continue background processing

    if (bQueryPending)
    {
        switch (iDoBackgroundPartAction)
        {
        case DO_SEND:
            if (SendQuery(pDbproc))
            {
                iDoBackgroundPartAction = DO_PROCESS;
                bContinue = TRUE;
                /*
                SendMessage (hResult,
                    WM_SETREDRAW,
                    FALSE,
                    0);
                */
                wsprintf (szStatus, "Processing...");
                InvalidateRect (hStatus, NULL, TRUE);
                UpdateWindow (hStatus);
            }
            else
            {
                iDoBackgroundPartAction = DO_SEND;
                bContinue = FALSE;
                /*
                SendMessage (hResult,
                    WM_SETREDRAW,
                    TRUE,
                    0);
                */
                wsprintf (szStatus, "Ready");
                InvalidateRect (hStatus, NULL, TRUE);
                UpdateWindow (hStatus);
            }
            break;

        case DO_PROCESS:
            bContinue = TRUE;
            if (ProcessQuery(pDbproc))
            {
                iDoBackgroundPartAction = DO_PROCESS;
            }
            else
            {
                iDoBackgroundPartAction = DO_SEND;
                /*
                SendMessage (hResult,
                    WM_SETREDRAW,
                    TRUE,
                    0);
                */
            }
            break;
        }
    }
    else
    {
        bContinue = FALSE;
    }

    bQueryPending = bContinue;

    return (bContinue);

}

//***************************************************************************
//
//  FUNCTION:   InitDblib()
//
//  PURPOSE:    Initialize DB-Library
//
//  COMMENTS:
//
//**************************************************************************

BOOL InitDblib (void)
{
    DBLOCKLIB();
    // Initialize DB-Library
    wsprintf(szDblibVersion, "%s", dbinit());
    if (szDblibVersion[0] == '\0')
        return (FALSE);

    // Get procedure instances
    lpErrorHandler = MakeProcInstance((FARPROC)ErrorHandler, hInst);
    lpMessageHandler = MakeProcInstance((FARPROC)MessageHandler, hInst);
    // Register handlers with DB-Library
    dberrhandle(lpErrorHandler);
    dbmsghandle(lpMessageHandler);
    // Set DB-Library options
    dbsetlogintime(10);
    dbsettime(100);
    return (TRUE);
}

//***************************************************************************
//
//  FUNCTION:   ExitDblib()
//
//  PURPOSE:    Exit from DB-Library
//
//  COMMENTS:
//
//**************************************************************************

BOOL ExitDblib (void)
{
    // Close connection to SQL Server if open
    if (pDbproc != (DBPROCESS *)NULL)
    {
        dbclose(pDbproc);
    }
    dbwinexit();
    DBUNLOCKLIB();
    // Free procedure instances
    FreeProcInstance(lpErrorHandler);
    FreeProcInstance(lpMessageHandler);
    return (TRUE);
}

//***************************************************************************
//
//  FUNCTION:   SendQuery()
//
//  PURPOSE:    Sends the query to the server
//
//  COMMENTS:
//
//**************************************************************************

BOOL SendQuery (
    DBPROCESS *pDbproc)
{
    BOOL bContinue;
    static int iNextLine;

    switch (iSendQueryAction)
    {
    case DO_FIRSTQUERY:
        // new query
        iNextLine = BuildCommand (pDbproc, hQuery, 0);
        break;

    case DO_NEXTQUERY:
        // next query
        iNextLine = BuildCommand (pDbproc, hQuery, iNextLine);
        break;
    }

    if (iNextLine)
    {
        // query built, so send it
        iSendQueryAction = DO_NEXTQUERY;
        switch (dbsqlsend(pDbproc))
        {
        case SUCCEED:
            bContinue = TRUE;
            // tell ProcessQuery() what to do
            iProcessQueryAction = DO_DBDATAREADY;
           break;
        case FAIL:
            ERRBOX(hWnd, "Query could not be sent");
            bContinue = FALSE;
            break;
        }

    }
    else
    {
        // no query built, nothing more to send
        bContinue = FALSE;
        iSendQueryAction = DO_FIRSTQUERY;
    }

    return (bContinue);

}

//***************************************************************************
//
//  FUNCTION:   BuildCommand()
//
//  PURPOSE:    Sends a command to the server
//
//  COMMENTS:
//
//  RETURN:     The next line to start with, or 0 if finished
//
//**************************************************************************

int BuildCommand(
    DBPROCESS *pDbproc,
    HWND hEdit,
    int iStartLine)
{
    LRESULT dwLines,            // lines in edit control
        dwBytesCopied,          // bytes copied from edit control
        dwCharIndex,            // index to char in edit control
        dwLineLen,              // length of line in edit control
        wRow;                   // current line of edit control
    int iNextLine;

    // get number of lines in query edit control
    dwLines = SendMessage(hEdit,                
        EM_GETLINECOUNT,
        0,
        0);

    if (iStartLine < (int)dwLines)
    {
        iNextLine = iStartLine;

        for (wRow=iStartLine;
            wRow < dwLines;
            wRow++)
        {
            // get index of first char in current line
            dwCharIndex = SendMessage (hEdit,
                EM_LINEINDEX,
                (WPARAM)wRow,
                0);

            // get length of current line
            dwLineLen = SendMessage (hEdit,
                EM_LINELENGTH,
                (WPARAM)dwCharIndex,
                0);

            // reallocate memory for new line length
            ReAllocMem (&glbmemSend, dwLineLen);

            // set first word of buffer to line length, required by EM_GETLINE
            *(WORD FAR *)(glbmemSend.lpvMem) = (WORD)dwLineLen;
            // copy line from edit control to query buffer
            dwBytesCopied = SendMessage(hEdit,
                EM_GETLINE,
                (WPARAM)wRow,
                (LPARAM)(glbmemSend.lpvMem));
            ((LPSTR)(glbmemSend.lpvMem))[dwBytesCopied] = '\0';

            iNextLine = (int) (wRow + 1);

            if (dwBytesCopied > 2)
            {
#if defined (WIN32)
                if (strnicmp (glbmemSend.lpvMem,"go ", 3)==0)
#else
                if (_fstrnicmp (glbmemSend.lpvMem,"go ", 3)==0)
#endif
                {
                    break;  // for loop
                }
            }
            else
            {
#if defined (WIN32)
                if (strnicmp (glbmemSend.lpvMem,"go", 2)==0)
#else
                if (_fstrnicmp (glbmemSend.lpvMem,"go", 2)==0)
#endif
                {
                    break;  // for loop
                }
            }

            // add space, then current line, to query batch
            dbcmd(pDbproc, " ");
            dbcmd(pDbproc, glbmemSend.lpvMem);
        }

    }
    else
    {
        iNextLine = 0;
    }

    return (iNextLine);
}


//***************************************************************************
//
//  FUNCTION:   CancelQuery()
//
//  PURPOSE:    Cancels the current query
//
//  COMMENTS:
//
//**************************************************************************

BOOL CancelQuery (
    DBPROCESS *pDbproc)
{
    switch (dbcancel(pDbproc))
    {
    case SUCCEED:
        /*
        SendMessage (hResult,
            WM_SETREDRAW,
            TRUE,
            0);
        */
        wsprintf (szStatus, "Ready");
        InvalidateRect (hStatus, NULL, TRUE);
        UpdateWindow (hStatus);

        MSGBOX(hWnd, "Query execution canceled");
        bQueryPending = FALSE;
        return (TRUE);
        break;
    case FAIL:
        ERRBOX(hWnd, "Query execution could NOT be canceled");
        return (FALSE);
        break;
    }
}

//***************************************************************************
//
//  FUNCTION:   ProcessQuery()
//
//  PURPOSE:    Processes a small part of the current query
//
//  COMMENTS:
//
//**************************************************************************

BOOL ProcessQuery (
    DBPROCESS *pDbproc)
{
    BOOL bContinue = FALSE;     // continue processing query
    STATUS s;                   // status from dbnextrow
    char szStr[100];            // scratch string

    switch (iProcessQueryAction)
    {
    case DO_DBDATAREADY:
        // Call dbdataready() to see if query has completed
        if (dbdataready(pDbproc))
        {
            iProcessQueryAction = DO_DBSQLOK;
            bContinue = TRUE;
        }
        else
        {
            bContinue = TRUE;
        }
        break; // DO_DBDATAREADY

    case DO_DBSQLOK:
        switch (dbsqlok(pDbproc))
        {
        case SUCCEED:
            // Query execution succeeded
            iProcessQueryAction = DO_DBRESULTS;
            bContinue = TRUE;
            break;
        case FAIL:
            ERRBOX (hWnd, "Failed to execute query");
            bContinue = FALSE;
            break;
        }
        break; // DO_DBSQLOK    

    case DO_DBRESULTS:
        switch (dbresults(pDbproc))
        {
        case SUCCEED:
            if (DBROWS (pDbproc) == SUCCEED)
                BuildHeader(pDbproc, REG_ROW);
            iProcessQueryAction = DO_DBNEXTROW;
            bContinue = TRUE;
            break;
        case NO_MORE_RESULTS:
            //MSGBOX(hWnd, "Query execution completed");
            SetWindowText (hResult, glbmemResult.lpvMem);

            bContinue = FALSE;
            break;
        case FAIL:
            ERRBOX(hWnd, "dbresults() returned FAIL");
            bContinue = FALSE;
            break;
        }
        break; // DO_DBRESULTS

    case DO_DBNEXTROW:
        switch (s=dbnextrow(pDbproc))
        {
        case REG_ROW:
            BuildRow(pDbproc, s);
            bContinue = TRUE;
            break;

        case NO_MORE_ROWS:
            wsprintf (szStr, "(%li rows affected)", DBCOUNT (pDbproc));
            AddLineToMem (&glbmemResult, szStr);
            AddLineToMem (&glbmemResult, "");
            iProcessQueryAction = DO_DBRESULTS;
            bContinue = TRUE;
            break;
        case BUF_FULL:
            // clear buffer
            bContinue = TRUE;
            break;
        case FAIL:
            ERRBOX(hWnd, "dbnextrow() returned FAIL");
            bContinue = FALSE;
            break;
        default:
            AddLineToMem (&glbmemResult, "");
            BuildHeader(pDbproc, s);
            BuildRow(pDbproc, s);
            AddLineToMem (&glbmemResult, "");
            bContinue = TRUE;
            break;
        }
        break; // DO_DBNEXTROW
    }

    return (bContinue);
}

//***************************************************************************
//
//  FUNCTION:   BuildRow()
//
//  PURPOSE:    Builds a result row
//
//  COMMENTS:
//
//**************************************************************************

BOOL BuildRow(
    DBPROCESS *pDbproc,
    STATUS s)
{
    LPSTR lpPtr;            // scratch pointer
    int iNumCols,           // number of columns in row
        iColType,           // column type
        iCol,               // current column
        iColSize,           // column size
        iRowSize,           // size of entire row
        iConvertLen,        // length of column data converted to char
        iComputeID;         // compute ID for compute row
    DBINT lColDataLen,      // length of column data
        lColMaxLen;         // max length of column
    BYTE far *pColData;     // pointer to column data

    // determine number of regular or compute columns
    if (s == REG_ROW)
    {
        iNumCols = dbnumcols(pDbproc);
    }
    else
    {
        iComputeID = s;
        iNumCols = dbnumalts(pDbproc, iComputeID);
    }

    // allocate memory for entire result row
    iRowSize = DetermineRowSize (pDbproc, s);
    ReAllocMem (&glbmemRow, iRowSize);

    ((LPSTR)(glbmemRow.lpvMem))[0] = '\0';

    for (iCol=1;iCol<=iNumCols;iCol++)
    {
        if (s == REG_ROW)
        {
            // Get column type, data length, max data length and pointer
            // to the data for this regular row
            iColType = dbcoltype(pDbproc, iCol);
            lColDataLen = dbdatlen(pDbproc, iCol);
            lColMaxLen = dbcollen(pDbproc, iCol);
            pColData = dbdata(pDbproc, iCol);
        }
        else
        {
            // Get column type, data length, max data length and pointer
            // to the data for this compute row
            iColType = dbalttype(pDbproc, iComputeID, iCol);
            lColDataLen = dbadlen(pDbproc, iComputeID, iCol);
            lColMaxLen = dbaltlen(pDbproc, iComputeID, iCol);
            pColData = dbadata(pDbproc, iComputeID, iCol);
        }

        iColSize = DetermineColSize (pDbproc, s, iCol);

        if (lColDataLen)
        {
            // this column is not NULL, so convert to character
            lpPtr = ((LPSTR)(glbmemRow.lpvMem)) + lstrlen (glbmemRow.lpvMem);            

            iConvertLen = dbconvert (pDbproc,
                iColType,
                pColData,
                lColDataLen,
                SQLCHAR,
                lpPtr,
                -1);

            PadCol (glbmemRow.lpvMem, ' ', iColSize-iConvertLen);
        }
        else // NULL column
        {
            lstrcat (glbmemRow.lpvMem, "NULL");
            PadCol (glbmemRow.lpvMem, ' ', iColSize-4);
        }
    }

    AddLineToMem (&glbmemResult, glbmemRow.lpvMem);

    return (TRUE);
}

//***************************************************************************
//
//  FUNCTION:   BuildHeader()
//
//  PURPOSE:    This function builds the string that contains the names
//              of each column. It does this by finding the print size of
//              each column, allocating a buffer to hold all column names
//              plus one space between each column name, then copying that
//              name into the appropriate location into the buffer.
//
//              It also builds an appropriate underline string for the
//              column names.
//
//  COMMENTS:
//
//***************************************************************************

BOOL BuildHeader(
    DBPROCESS *pDbproc,
    STATUS s)
{
    LPSTR lpColName;            // long point to column name
    int iCol,                   // current column
        iNumCols,               // number of columns in row
        iHeaderSize,            // size of header buffer
        iColSize;               // size of column
    STATUS iComputeID;           

    // Get number of columns
    if (s == REG_ROW)
    {
        iNumCols = dbnumcols(pDbproc);
    }
    else
    {
        iComputeID = s;
        iNumCols = dbnumalts(pDbproc, iComputeID);
    }

    // Get row size and allocate memory for buffer
    iHeaderSize = DetermineRowSize(pDbproc, s);
    ReAllocMem (&glbmemHeader, iHeaderSize);
    ReAllocMem (&glbmemUnderline, iHeaderSize);
    
    ((LPSTR)(glbmemHeader.lpvMem))[0] = '\0';
    ((LPSTR)(glbmemUnderline.lpvMem))[0] = '\0';

    for (iCol=1;
        iCol <= iNumCols;
        iCol++)
    {
        iColSize = DetermineColSize (pDbproc, s, iCol);

        if (s == REG_ROW)
        {
            lpColName = dbcolname (pDbproc, iCol);
        }
        else
        {
            lpColName = dbprtype (dbaltop (pDbproc, iComputeID, iCol));
        }

        // Append column name and extra spaces to row header
        lstrcat (glbmemHeader.lpvMem, lpColName);
        PadCol (glbmemHeader.lpvMem, ' ', iColSize-lstrlen(lpColName));

        // Append column underline and extra space to underline header
        PadCol (glbmemUnderline.lpvMem, '-', iColSize);
    }

    AddLineToMem (&glbmemResult, glbmemHeader.lpvMem);
    AddLineToMem (&glbmemResult, glbmemUnderline.lpvMem);

    return(TRUE);
}

//***************************************************************************
//
//  FUNCTION:   DetermineRowSize()
//
//  PURPOSE:    This function is used to determine the size of an entire
//              row, with one space between each column.
//
//  RETURN:     The size of the entire row is returned.
//
//  COMMENTS:
//
//**************************************************************************

int DetermineRowSize(
    DBPROCESS *pDbproc,
    STATUS s)
{
    int iLength = 0,        // total length of column or row
        iNumCols,           // number of columns
        iColLen,            // length of current column
        iCol;               // current column
    STATUS iComputeID;

    if (s == REG_ROW)
    {
        iNumCols = dbnumcols(pDbproc);
    }
    else
    {
        iComputeID = s;
        iNumCols = dbnumalts(pDbproc, iComputeID);
    }

    for (iCol=1;
        iCol <= iNumCols;
        iCol++)
    {
        iColLen = DetermineColSize (pDbproc, s, iCol);
        // Set field length to column length plus one space
        iLength += iColLen+1;
    }

    // Add one byte for null termination
    iLength++;

    // Return the entire row length including extra spaces
    return (iLength);
}

//***************************************************************************
//
//  FUNCTION:   DetermineColSize()
//
//  PURPOSE:    This function is used to determine the size of a single column
//              in the current row.
//
//  RETURN:     The size of that column alone is returned.
//
//  COMMENTS:
//
//**************************************************************************

int DetermineColSize(
    DBPROCESS *pDbproc,
    STATUS s,
    int iCol)
{
    int iColType,
        iNameLen,           // length of column name
        iPrintLen,          // printable length of column data
        iColLen;            // length of current column
    DBINT lColMaxLen;
    STATUS iComputeID;

    if (s == REG_ROW)
    {
        iColType = dbcoltype(pDbproc, iCol);
        lColMaxLen = dbcollen (pDbproc, iCol);
    }
    else
    {
        iComputeID = s;
        iColType = dbalttype(pDbproc, iComputeID, iCol);
        lColMaxLen = dbaltlen (pDbproc, iComputeID, iCol);
    }

    // Get maximum printable length of the column data
    switch(iColType)
    {
    case SQLBIT:
        iPrintLen = PRBIT;
        break;
    case SQLINT1:
        iPrintLen = PRINT1;
        break;
    case SQLINT2:
        iPrintLen = PRINT2;
        break;
    case SQLINT4:
        iPrintLen = PRINT4;
        break;
    case SQLFLT8:
        // note kludge becuase PRFLT8 isn't enough
        iPrintLen = PRFLT8 + 10;
        break;
    case SQLDATETIME:
        iPrintLen = PRDATETIME;
        break;
    case SQLMONEY:
        iPrintLen = PRMONEY;
        break;
    // With VARBINARY, BINARY, and IMAGE data, each byte converts
    // to two hex characters
    case SQLVARBINARY :
    case SQLBINARY:
    case SQLIMAGE:
        iPrintLen = (int) (lColMaxLen * 2);
        break;
    // Other types are maximum of actual column length
    default :
        iPrintLen = (int) (lColMaxLen);
        break;
    }

    // Get length of column name
    if (s == REG_ROW)
    {
        iNameLen = lstrlen (dbcolname (pDbproc, iCol));
    }
    else
    {
        iNameLen = lstrlen (dbprtype (dbaltop (pDbproc, iComputeID, iCol)));
    }

    // Column length is maximum of column name length or maximum printable
    // column data length
    if(iNameLen > iPrintLen)
    {
        iColLen = iNameLen;
    }
    else
    {
        iColLen = iPrintLen;
    }

    // Column may contain NULL values
    if (iColLen < 4)
    {
        iColLen = 4;
    }

    // Return the column length
    return (iColLen);
}

//***************************************************************************
//
//  FUNCTION:   Connect()
//
//  PURPOSE:    Processes messages for "Connect" dialog box
//
//  MESSAGES:
//
//      WM_INITDIALOG - initialize dialog box
//      WM_COMMAND    - Input received
//
//  COMMENTS:   TRUE must be returned to Windows.
//
//**************************************************************************

BOOL FAR PASCAL Connect(
    HWND hDlg,
    UINT message,
    WPARAM wParam,
    LPARAM lParam)
{
    char szSQLServerName[MAX_NAME+1],
        szSQLLogin[MAX_NAME+1],
        szSQLPassword[MAX_NAME+1];
    LOGINREC *pLoginRec;
    char szStr[100];

    switch (message)
    {
    case WM_INITDIALOG:     // message: initialize dialog box
        SetDlgItemText(hDlg,
            SQL_LOGIN,
            "sa");
        return (TRUE);
        break;

    case WM_COMMAND:    // message: received a command
        switch (wParam)
        {
        case IDOK:
            // get server name, login, and password
            GetDlgItemText(hDlg,
                SQL_SERVER,
                szSQLServerName,
                MAX_NAME);
            GetDlgItemText(hDlg,
                SQL_LOGIN,
                szSQLLogin,
                MAX_NAME);
            GetDlgItemText(hDlg,
                SQL_PASSWORD,
                szSQLPassword,
                MAX_NAME);

            if(pDbproc != (DBPROCESS *)NULL)
            {
                dbclose(pDbproc);
            }
            pLoginRec = dblogin();
            if (pLoginRec != (LOGINREC *)NULL)
            {
                DBSETLUSER(pLoginRec, szSQLLogin);
                DBSETLPWD(pLoginRec, szSQLPassword);
                DBSETLHOST(pLoginRec, szAppName);
                wsprintf (szStatus, "Login...");
                InvalidateRect (hStatus, NULL, TRUE);
                UpdateWindow (hStatus);

                pDbproc = dbopen(pLoginRec, szSQLServerName);
                if (pDbproc != (DBPROCESS *)NULL)
                {
                    // copy server name for status bar display
                    wsprintf (szSQLServer, szSQLServerName);
                    wsprintf (szStr, "Connected to SQL Server %s", (LPSTR)szSQLServer);
                    AddLineToMem (&glbmemResult, szStr);
                    SetWindowText (hResult, glbmemResult.lpvMem);
                    bQueryPending = FALSE;
                }
                else // dbopen() failed
                {
                    ERRBOX(hDlg, "Failed to connect to SQL Server");
                    wsprintf (szSQLServer, "");
                }
                wsprintf (szStatus, "Ready");
                InvalidateRect (hStatus, NULL, TRUE);
                UpdateWindow (hStatus);
            }
            else // dblogin() failed
            {
                ERRBOX(hDlg, "Failed to allocate login record");
            }
            dbfreelogin(pLoginRec);

            EndDialog(hDlg, TRUE);
            return (TRUE);
            break;

        case IDCANCEL:
            EndDialog(hDlg, TRUE);
            return (TRUE);
            break;
        }
        break;
    }
    return (FALSE);     // Didn't process a message
}

//****************************************************************************
//
//  FUNCTION:   About()
//
//  PURPOSE:    Processes messages for "About" dialog box
//
//  MESSAGES:
//
//      WM_INITDIALOG - initialize dialog box
//      WM_COMMAND    - Input received
//
//  COMMENTS:   TRUE must be returned to Windows.
//
//**************************************************************************

BOOL FAR PASCAL About(
    HWND hDlg,
    UINT message,
    WPARAM wParam,
    LPARAM lParam)
{
    switch (message)
    {
    case WM_INITDIALOG:     // message: initialize dialog box
        SetDlgItemText(hDlg,
            SQL_DBLIBVERSION,
            szDblibVersion);
        return (TRUE);

    case WM_COMMAND:    // message: received a command

        switch (wParam)
        {
        case IDOK:
        case IDCANCEL:
            EndDialog(hDlg, TRUE);
            return (TRUE);
            break;
        }
        break;
    }
    return (FALSE);     // Didn't process a message
}

//***************************************************************************
//
//  FUNCTION:   PadCol()
//
//  PURPOSE:    Pad string with extra spaces, then add one space
//
//  COMMENTS:
//
//**************************************************************************

BOOL PadCol(
    LPSTR lpBuffer,
    char chPadChar,
    int iNumPadChars)
{
    LPSTR lpPtr;        // scratch pointer

    lpPtr = lpBuffer + lstrlen(lpBuffer);
#if defined (WIN32)
    memset (lpPtr, chPadChar, iNumPadChars);
#else
    _fmemset (lpPtr, chPadChar, iNumPadChars);
#endif
    lpPtr += iNumPadChars;
    *lpPtr = ' ';
    lpPtr++;
    *lpPtr = '\0';

    return (TRUE);
}

//***************************************************************************
//
//  FUNCTION:   ErrorHandler()
//
//  PURPOSE:    Processes DB-Library errors.
//
//  RETURN:     Return continuation code.
//
//  COMMENTS:   Must be declared FAR cdecl.  Must return either INT_CANCEL,
//              INT_CONTINUE, or INT_EXIT to DB-Library.
//
//**************************************************************************

int FAR ErrorHandler(
    DBPROCESS *pDbproc,
    DBSMALLINT iDbErrSev,
    DBSMALLINT iDbErrNumber,
    DBSMALLINT iOSErrNumber,
    LPSTR szDbErr,
    LPSTR szOSErr)
{
    char szStr[100];

    wsprintf (szStr, "DB-Library Error %i: ", iDbErrNumber);
    AddStrToMem (&glbmemResult, szStr);
    AddLineToMem (&glbmemResult, szDbErr);

    if (iOSErrNumber != DBNOERR)       // operating system error
    {
        wsprintf (szStr, "Operating System Error %i: ", iOSErrNumber);
        AddStrToMem (&glbmemResult, szStr);
        AddLineToMem (&glbmemResult, szOSErr);
    }

    SetWindowText (hResult, glbmemResult.lpvMem);

    // this will cause the offending DB-Library function to return FAIL
    return(INT_CANCEL);
}

//***************************************************************************
//
//  FUNCTION:   MessageHandler()
//
//  PURPOSE:    Processes SQL Server messages.
//
//  RETURN:     Return 0
//
//  COMMENTS:   Must be declared FAR cdecl.
//
//**************************************************************************

int FAR MessageHandler(
    DBPROCESS *pDbproc,
    DBINT lMsgNumber,
    DBSMALLINT iMsgState,
    DBSMALLINT iMsgSeverity,
    LPSTR szMsg)
{
    char szStr[100];

    if (lMsgNumber != 0 && iMsgSeverity != 0)
    {
        wsprintf (szStr, "SQL Server Message %li: ", lMsgNumber);

        AddStrToMem (&glbmemResult, szStr);
        AddLineToMem (&glbmemResult, szMsg);
    }
    else
    {
        // dbcc message
        AddLineToMem (&glbmemResult, szMsg);
    }

    SetWindowText (hResult, glbmemResult.lpvMem);

    return(0);
}
