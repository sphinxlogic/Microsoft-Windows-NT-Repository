//*************************************************************
//  File name: callback.c
//
//  Purpose:
//      Contains callback procedure for server application
//
//  Functions:
//      DdeCallBack() - Handles transaction processing for server
//
// Development Team:
//      Sara Williams
//
// Written by Microsoft Product Support Services, Windows Developer Support
// Copyright (c) 1992 Microsoft Corporation. All rights reserved.
//*************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "global.h"

//*************************************************************
//
//  Function: DdeCallBack()
//
//  Purpose:
//        Handles DDEML transaction processing for the server
//
//
//  Parameters:
//
//        WORD     wType    // type of transaction
//        WORD     wFmt     // clipboard format
//        HCONV    hConv    // handle of the conversation
//        HSZ      hsz1     // string handle
//        HSZ      hsz2     // string handle
//        HDDEDATA hDDEData // handle of a global memory object
//        DWORD    dwData1  // transaction-specific data
//        DWORD    dwData2  // transaction-specific data
//
//  Return: HDDEDATA
//        dependent on transaction
//
//  Comments:
//
//  History:    Date       Author     Comment
//              1/6/92     saraw      Created
//*************************************************************
HDDEDATA EXPENTRY DdeCallBack(WORD     wType,
                              WORD     wFmt,
                              HCONV    hConv,
                              HSZ      hsz1,
                              HSZ      hsz2,
                              HDDEDATA hDDEData,
                              DWORD    dwData1,
                              DWORD    dwData2)
{
  // The callback function allows the server to communicate 
  // with the DDEML, and thus, to the client.  When the DDEML
  // has something to tell the server, it calls the server's 
  // callback function. When the server has something to tell
  // the DDEML (or the client), it does it through the callback
  // function.

  switch(wType)
  {
    case XTYP_ADVSTART:  

        // The server gets an XTYP_ADVSTART when the client requests an
        // advise loop.  The server should check the wFmt and the topic
        // to make sure that the client is requesting an advise loop on 
        // a topic (and in a format) that the server supports.
    {
         if ((wFmt != CF_BITMAP) || 
                 (DdeCmpStringHandles(hsz1, ghszTopics[SAMPLE]) != 0))
            return FALSE;

         bAdviseLoopActive = TRUE;
    }
    return TRUE;


    case XTYP_ADVREQ:

        // The server gets an XTYP_ADVREQ when the server calls DdePostAdvise.
        // The server calls DdePostAdvise whenever the data associated with
        // an advise loop has changed.

    {
        return (gBitmapHandles[iSelectedBitmap].hData);

    }


    case XTYP_ADVSTOP:
    {
        // The server gets an XTYP_ADVSTOP when the client terminates an 
        // advise loop (via DdeClientTransactions(...XTYP_ADVSTOP).

        bAdviseLoopActive = FALSE;

    }
    return (HDDEDATA)NULL;


    case XTYP_CONNECT:
    {
        // The server gets an XTYP_CONNECT when the client requests a
        // conversation (via DdeConnect).  The server should return TRUE
        // if it supports the topic, and FALSE otherwise.

        WORD i; // loop counter

        // Check to see if the topic matches any that we support.
       

        for (i = 0; i < TOPICS; i++)
        {
          if (!DdeCmpStringHandles(hsz1, ghszTopics[i]))
              return TRUE;
        }
        return FALSE;  // Topics passed doesn't match supported topics - deny conversation.
    }


    case XTYP_WILDCONNECT:

        // The server gets an XTYP_WILDCONNECT when the client specifies
        // a NULL service or topic name in a call to DdeConnect(). 

        // The server should return NULL to refuse an XTYP_WILDCONNECT.
        // If the server accepts the XTYP_WILDCONNECT, it should return
        // an array of HSZPAIR structures, containing an HSZPAIR for
        // each matched service/topic item.
    {
        int     i, j;                 // loop control variables
        HSZPAIR ahszp[(TOPICS + 1)];  // for the HSZPAIRS that we need to
                                      // return to the DDEML.

        if ((hsz2 != ghszDDEMLDemo) && (hsz2 != NULL)) 
        {
            // we only support the DDEMLDemo service
            return (HDDEDATA)NULL;
        }

        // scan the topic table and create hsz pairs

        j = 0;

        for (i = 0; i < TOPICS; i++) 
        {
            if (!DdeCmpStringHandles(hsz1, ghszTopics[i]))
            {
                ahszp[j].hszSvc = ghszDDEMLDemo;
                ahszp[j].hszTopic = ghszTopics[i];
                j++;
            }
        }

        // The array of hszpairs should end with NULL string handles
        ahszp[j].hszSvc = ahszp[j].hszTopic = NULL;
        j++;

        // send it back
        return(DdeCreateDataHandle(idInst, 
                                   (LPBYTE)&ahszp[0], 
                                   sizeof(HSZPAIR) * j, 
                                   0L, 
                                   0, 
                                   wFmt, 
                                   0));
    }


    case XTYP_REQUEST:
    {
        // The server gets an XTYP_REQUEST when the client requests 
        // information via DdeClientTransaction(...XTYP_REQUEST).
        // This transaction must be handled differently for each 
        // topic and format.


        // Is this a request on the System topic?
        if (!DdeCmpStringHandles(hsz1, ghszTopics[SYSTEM]))
        {
             int i;  // loop control variable

             for (i = 0; i < SYSITEMS; i++)
             {
               // Here, we plow through the structure of item-data
               // pairs that we initialized at creation.  When we
               // find the string handle that matches that of the
               // requested item, we just return the associated data.

               if (!DdeCmpStringHandles(hsz2, gIDSysItems[i].hszitem))
                   return (gIDSysItems[i].hData);
             }
             return (HDDEDATA)NULL;  // no match
        }

        // Is this a CF_TEXT-format request on the item?
        if ((wFmt == CF_TEXT) && (!DdeCmpStringHandles(hsz2, ghszItems[NUMBER])))
        {
           HDDEDATA hReturn;
           int      nValue = NULL;   // Value passed back from dialog box
           
           // Put up a dialog box asking for user input.  Save value
           // returned (user's input).
           nValue = DialogBox(ghInst, "REQUESTDLG", ghWndMain, 
                              lpfnRequestDialogProc);

           // Create data handle for the number the user selected to
           // pass on to the client.
           hReturn = DdeCreateDataHandle(idInst,  // instance identifier
                               (LPBYTE)&nValue,   // source buffer
                               sizeof(int),       // length of object
                               0,                 // offset into source buffer
                               hsz2,              // handle to item-name string
                               wFmt,              // clipboard data format
                               0);                // creation flags
           if (!hReturn)
           {
              // DdeCreateDataHandle failed, so we do error handling
              WORD wError;
              char szBuffer[128];

              wError = DdeGetLastError(idInst);
              wsprintf(szBuffer, "DdeCreateDataHandle failed. Error #%#0x", wError);
              MessageBox(ghWndMain, szBuffer, "Error", MB_OK);
              return (HDDEDATA)NULL;

            }

            // send handle to the requested data back to client
            return hReturn;     
        }

        // Is this a CF_BITMAP-format request on the GENERAL topic?
        if ((wFmt == CF_BITMAP) && (!DdeCmpStringHandles(hsz2, ghszItems[CHANGEBMP])))
        {    
           // The client has requested the changed bitmap.
           // When client has a warm advise loop (ie., the DDEML only
           // notifies the client that the data has changed, without 
           // sending the actual data.), the client can send the server
           // a request for the changed data.  That's what this is.

           // Send the client a handle to the bitmap.
           return (gBitmapHandles[iSelectedBitmap].hData);
        }
          
        else
        {  
           // Request on unsupported topic and/or format.
           return (HDDEDATA)NULL;
        }
    }
    return (HDDEDATA)NULL;

     
    case XTYP_CONNECT_CONFIRM:

        // The server gets an XTYP_CONNECT_CONFIRM after a
        // XTYP_CONNECT or an XTYP_WILD_CONNECT.  This transaction
        // privides the server with the conversation handle.

        // This transaction should return NULL, whether or not it gets
        // processed.

    return (HDDEDATA)NULL;    

    case XTYP_POKE:

        // The server gets this transaction when the client calls
        // DdeClientTransaction(...XTYP_POKE...).  If the server
        // processes this message, it should return DDE_FACK.  If the
        // server is too busy to process the transaction, it should
        // return DDE_FBUSY.  If the server does not process the
        // transaction, it should return DDE_FNOTPROCESSED.

    return (HDDEDATA)DDE_FNOTPROCESSED;     

    case XTYP_REGISTER:

        // The server gets an XTYP_REGISTER whenever a DDEML application
        // calls DdeNameService to register the name of a service.  It
        // is also received when a non-DDEML application that supports
        // the system topic is started.

    return (HDDEDATA)NULL;

    case XTYP_UNREGISTER:

        // The server gets an XTYP_UNREGISTER whenever a DDEML application
        // calls DdeNameService to unregister the name of a service.  It
        // is also received when a non-DDEML application that supports
        // the system topic is terminated.

    return (HDDEDATA)NULL;

    case XTYP_DISCONNECT:

        // The server gets an XTYP_DISCONNECT when the client uses
        // DdeDisconnect to terminate a conversation.

    return (HDDEDATA)NULL;

    case XTYP_EXECUTE:

        // The server gets an XTYP_EXECUTE when the client uses 
        // DdeClientTransaction(...XTYP_EXECUTE...) to send a
        // string command to the server.

        // The server should return DDE_FACK if it processes the
        // execute, DDE_FBUSY if it is too busy to process the
        // execute, and DDE_FNOTPROCESSED if it rejects the execute.

    return DDE_FNOTPROCESSED;     
    
    default:
          return (HDDEDATA)NULL;

  }  // end switch

}    // end DdeCallBack



//*** EOF: callback.c
