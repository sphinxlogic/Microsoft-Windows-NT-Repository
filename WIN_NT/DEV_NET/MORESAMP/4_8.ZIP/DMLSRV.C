//*************************************************************
//  File name: DMLSRV.C
//
//  Purpose:
//      Contains main message processing function, entry point, 
//
//  Functions:
//      MainWndProc() - Handles message processing for server's
//                      main window.
//      WinMain()     - initializes everything and enters message loop
//
// Development Team:
//      Sara Williams
//
// Written by Microsoft Product Support Services, Windows Developer Support
// Copyright (c) 1992 Microsoft Corporation. All rights reserved.
//*************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "global.h"

HANDLE  ghInst    = NULL;    // handle to this instance
HWND    ghWndMain = NULL;    // handle to main window

HBITMAPDATA gBitmapHandles[BITMAPS];  // array of hBitmaps and hDatas 
                                      // to send to the client.


char    szMainMenu[]    = "MainMenu";
char    szMainClass[]   = "ServerClass";

int      iSelectedBitmap = 0;         // index of the currently selected bitmap
DWORD    idInst = 0L;                 // instance identifier
HSZ      ghszDDEMLDemo = NULL;        // Service name
HSZ      ghszTopics[TOPICS];          // topics the server supports
HSZ      ghszItems[ITEMS];            // items the server supports

BOOL     bAdviseLoopActive = FALSE;   // Is there an advise loop active?

FARPROC  lpfnRequestDialogProc;       // request dialog box procedure
FARPROC  lpfnSelectDialogProc;        // select dialog box procedure


//*************************************************************
//
//  Function: MainWndProc()
//
//  Purpose:
//        Main Window procedure
//
//
//  Parameters:
//      HWND hWnd     // handle to the main window
//      unsigned msg  // current message
//      WORD wParam   // additional information
//      LONG lParam   // additional information
//
//  Return: (long FAR PASCAL)
//
//  Comments:
//
//  History:    Date       Author     Comment
//              1/6/92     saraw      Created
//*************************************************************
long FAR PASCAL MainWndProc(HWND hWnd, 
			    UINT msg,
			    WPARAM wParam,
			    LPARAM lParam)
{
    FARPROC  lpProc;

    switch (msg) 
    {
      case WM_CREATE:
      {

          FARPROC lpfnDdeCallBack;    
          int     i;                // loop control variable
          char    szBuffer[256];    // used for LoadString calls


          lpfnDdeCallBack = MakeProcInstance((FARPROC)DdeCallBack, ghInst);

          // Ddeml initialization - DdeInitialize must be called before
          // any other ddeml functions.
          
          if(DdeInitialize(&idInst, (PFNCALLBACK)lpfnDdeCallBack,
                           APPCLASS_STANDARD, 0L))
            return FALSE;

          // Initialize structure to support SYSTEM topic
          InitSystemItems();

          // Create string handle for the Service name

          LoadString(ghInst, IDS_SERVICENAME, szBuffer, 256);
          ghszDDEMLDemo = DdeCreateStringHandle(idInst, (LPSTR)szBuffer, CP_WINANSI);

          if (!ghszDDEMLDemo)
             return FALSE;

          // Create string handles to the Topic names
          LoadString(ghInst, IDS_SAMPLETOPIC, szBuffer, 256);
          ghszTopics[SAMPLE] = DdeCreateStringHandle(idInst, (LPSTR)szBuffer, CP_WINANSI);
          ghszTopics[SYSTEM] = DdeCreateStringHandle(idInst, (LPSTR)SZDDESYS_TOPIC, CP_WINANSI);

          // Create string handles for the Item names
          LoadString(ghInst, IDS_NWDITEM, szBuffer, 256);
          ghszItems[NUMBER] = DdeCreateStringHandle(idInst, (LPSTR)szBuffer, CP_WINANSI);

          LoadString(ghInst, IDS_CHANGEBMPITEM, szBuffer, 256);
          ghszItems[CHANGEBMP] = DdeCreateStringHandle(idInst, (LPSTR)szBuffer, CP_WINANSI);
          
          // Register the service
          if (!DdeNameService(idInst, ghszDDEMLDemo, NULL, DNS_REGISTER))
             return FALSE;

          // Finish initializing bitmap structure to include data handles 
          // for each bitmap.

          for (i = CIRCLES; i <= STRMERS; i++)
          {
            // These handles are appowned so that the server won't have
            // to create one each time it needs to send the hBitmap to
            // the client.

            gBitmapHandles[i].hData = DdeCreateDataHandle(idInst,
                                          (LPBYTE)&gBitmapHandles[i].hBitmap,
                                          sizeof(HBITMAP),
                                          0, 
                                          ghszItems[CHANGEBMP], 
                                          CF_BITMAP,
                                          HDATA_APPOWNED);
          }

          // Make thunks for dialog box procedures we'll use.

          lpfnRequestDialogProc = MakeProcInstance((FARPROC)RequestDialogProc, ghInst);
          lpfnSelectDialogProc = MakeProcInstance((FARPROC)SelectDialogProc, ghInst);

      }
      break;

      case WM_COMMAND: 
          switch ( wParam )
          {
            case IDM_ABOUT:
                // Show the about box. Wow.
                lpProc = MakeProcInstance(About, ghInst);
                DialogBox(ghInst, "AboutBox", hWnd, lpProc);    
                FreeProcInstance(lpProc);
            break;

            case IDM_SELECTBM:
            {
                // Show the "Select Bitmap" dialog box, which lets
                // the user select a bitmap for the server to display,
                // and to send to the client if an advise loop is 
                // active.

                HDC     hDC, hMemDC;
                HBITMAP hOrigBitmap;
                RECT    Rect;
                BITMAP  bm;

                // let the user pick a bitmap.

                iSelectedBitmap = DialogBox(ghInst,"SELECTDLG",hWnd,
                                            lpfnSelectDialogProc);

                // display the bitmap in the server's client area

                GetClientRect(hWnd, &Rect);

                GetObject(gBitmapHandles[iSelectedBitmap].hBitmap, 
                          sizeof(BITMAP), &bm);

                hDC = GetDC(hWnd);

                hMemDC = CreateCompatibleDC(hDC);

                hOrigBitmap = SelectObject(hMemDC, 
                                           gBitmapHandles[iSelectedBitmap].hBitmap);

                StretchBlt(hDC, 0, 0, Rect.right, Rect.bottom,
                           hMemDC, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY);

                // Clean up our mess.
                SelectObject(hMemDC, hOrigBitmap);
                DeleteObject(hMemDC);
                ReleaseDC(hWnd, hDC);

                // If there's an advise loop (hot or warm), we call
                // DdePostAdvise, which tells the DDEML to send the
                // server's callback an XTYP_ADVREQ, which sends 
                // the data to the client.

                if (bAdviseLoopActive)
                      // send XTYP_ADVREQ to own callback
                  if (!DdePostAdvise(idInst, ghszTopics[SAMPLE], ghszItems[CHANGEBMP]))
                         return FALSE;
            }
            break;

          }
      break;

      case WM_PAINT:
      {
         HDC         hDC, hMemDC;
         HBITMAP     hOrigBitmap;
         RECT        Rect;
         PAINTSTRUCT ps;
         BITMAP      bm;

         if (!iSelectedBitmap)
            return DefWindowProc(hWnd, msg, wParam, lParam);

         // redraw the selected bitmap on the server window's client area
         GetClientRect(hWnd, &Rect);

         GetObject(gBitmapHandles[iSelectedBitmap].hBitmap, sizeof(BITMAP), &bm);

         hDC = BeginPaint(hWnd, &ps);

         hMemDC = CreateCompatibleDC(hDC);

         hOrigBitmap = SelectObject(hMemDC, 
                                    gBitmapHandles[iSelectedBitmap].hBitmap);

         StretchBlt(hDC, 0, 0, Rect.right, Rect.bottom, 
                    hMemDC, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY);

         // Clean up our mess.
         SelectObject(hMemDC, hOrigBitmap);

         DeleteObject(hMemDC);

         EndPaint(hWnd, &ps);
      }
      break;

      case WM_SIZE:
      {
         // Force a repaint.

         InvalidateRect(hWnd, NULL, TRUE);
         return DefWindowProc(hWnd, msg, wParam, lParam);
      }
      break;


      case WM_DESTROY:
      {  
         // General clean-up
         int i;

         // Unregister the service
         DdeNameService(idInst, ghszDDEMLDemo, NULL, DNS_UNREGISTER);

         // Free all the string handles and data handles we used
         // to support the system topic.  Since we created the data 
         // handles as appowned, we have to free them.

         for (i = 0; i < SYSITEMS; i++)
         {
            // clean up system structure
            DdeFreeStringHandle(idInst, gIDSysItems[i].hszitem);
            DdeFreeDataHandle(gIDSysItems[i].hData);
         }

         // Free the data handles we used to pass hBitmaps to the
         // client.  Since we created them as appowned, we have
         // to free them.

         for (i = CIRCLES; i <= STRMERS; i++)
            DdeFreeDataHandle(gBitmapHandles[i].hData);

         // Free the string handles we used.
         DdeFreeStringHandle(idInst, ghszDDEMLDemo);
         DdeFreeStringHandle(idInst, ghszTopics[SAMPLE]);
         DdeFreeStringHandle(idInst, ghszTopics[SYSTEM]);
         DdeFreeStringHandle(idInst, ghszItems[NUMBER]);
         DdeFreeStringHandle(idInst, ghszItems[CHANGEBMP]);

         // terminate all conversations
         DdeUninitialize(idInst);
         FreeProcInstance(lpfnRequestDialogProc);
         FreeProcInstance(lpfnSelectDialogProc);

         PostQuitMessage(0);
      }
      break;
    }
    return (DefWindowProc(hWnd, msg, wParam, lParam));

} //*** MainWndProc()



//*************************************************************
//
//  Function: WinMain()
//
//  Purpose: Called by Windows on app startup.  Initializes everything,
//           and enters a message loop.
//
//  Parameters:
//    hInstance     - Handle to _this_ instance.
//    hPrevInstance - Handle to last instance of app.
//    lpCmdLine     - Command Line passed into app.
//    nCmdShow      - How app should come up (i.e. minimized/normal)
//
//  Returns: Return value from PostQuitMessage.
//
//  Comments:
//
//  History:    Date       Author     Comment
//              1/6/92     saraw      Created
//*************************************************************
int PASCAL WinMain(HANDLE hInstance, 
                   HANDLE hPrevInstance, 
                   LPSTR lpCmdLine, 
                   int nCmdShow)
{
    MSG msg;


    if (!hPrevInstance && !InitApplication(hInstance))
      return (FALSE);       

    if (!InitInstance(hInstance, nCmdShow))
      return (FALSE);

    while (GetMessage(&msg, NULL, NULL, NULL))
    {
      TranslateMessage(&msg);      
      DispatchMessage(&msg);       
    }
    return (msg.wParam);      

} //*** WinMain()

//*** EOF: DMLSRV.C
