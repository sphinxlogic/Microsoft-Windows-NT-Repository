//*************************************************************
// File name: init.c
//
// Purpose:
//    Initializes the app and instance
//
// Functions:
//    InitSystemItems() - initializes structure used for SYSTEM topic support
//    InitApplication() - registers classes
//    InitInstance()    - loads bitmaps, creates window
//
// Development Team:
//    Sara Williams
//
// Written by Microsoft Product Support Services, Windows Developer Support
// Copyright (c) 1992 Microsoft Corporation. All rights reserved.
//*************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
#include "global.h"

#define MAXSIZE 256   // maximum size for character buffer

// Support structure for System Topic
ITEMDATA gIDSysItems[SYSITEMS];

//*************************************************************
//
//  Function: InitSystemItems()
//
//  Purpose:
//    Initializes the ITEMDATA structure that associates a system
//    item with the appropriate return data.
//
//  Parameters:
//    None
//      
//  Return: VOID
//
//  Comments:
//
//  History:    Date       Author     Comment
//              2/7/92     saraw      Created
//*************************************************************
void InitSystemItems ()
{

// for reference...
//   typedef struct _ITEMDATA {
//                     HSZ hszitem;
//                     HDDEDATA hData
//                  } ITEMDATA;
//

   // Here, we initialize a structure that makes supporting the 
   // system topic pretty painless.  Each element in the array
   // is an ITEMDATA structure that consists of a string handle
   // and a data handle.  This way, when we get a request on the
   // system topic, all we have to do is find the matching item
   // in the array and return the corresponding data handle.

   // NOTE:  All the data handles are appowned.  This is so the
   // server can send them as many times as necessary without
   // ever having to recreate them.  But, it is important to
   // remember to free them when the server terminates.

   static char szBuffer[MAXSIZE];

   gIDSysItems[0].hszitem = DdeCreateStringHandle(idInst, SZDDESYS_ITEM_FORMATS,
                                                  CP_WINANSI);

   LoadString(ghInst, IDS_FORMATS, szBuffer, MAXSIZE);

   gIDSysItems[0].hData = DdeCreateDataHandle(idInst, szBuffer,
                                              lstrlen(szBuffer) + 1, 0,
                                              gIDSysItems[0].hszitem,
                                              CF_TEXT, HDATA_APPOWNED);


   gIDSysItems[1].hszitem = DdeCreateStringHandle(idInst, SZDDESYS_ITEM_HELP,
                                                  CP_WINANSI);

   LoadString(ghInst, IDS_HELP, szBuffer, MAXSIZE);

   gIDSysItems[1].hData = DdeCreateDataHandle(idInst, szBuffer,
                                              lstrlen(szBuffer) + 1, 0,
                                              gIDSysItems[1].hszitem,
                                              CF_TEXT, HDATA_APPOWNED);


   gIDSysItems[2].hszitem = DdeCreateStringHandle(idInst, SZDDE_ITEM_ITEMLIST,
                                                  CP_WINANSI);

   LoadString(ghInst, IDS_ITEMLIST, szBuffer, MAXSIZE);

   gIDSysItems[2].hData = DdeCreateDataHandle(idInst, szBuffer,
                                              lstrlen(szBuffer) + 1, 0,
                                              gIDSysItems[2].hszitem,
                                              CF_TEXT, HDATA_APPOWNED);


   gIDSysItems[3].hszitem = DdeCreateStringHandle(idInst, SZDDESYS_ITEM_RTNMSG,
                                                  CP_WINANSI);

   LoadString(ghInst, IDS_RTNMSG, szBuffer, MAXSIZE);

   gIDSysItems[3].hData = DdeCreateDataHandle(idInst, szBuffer,
                                              lstrlen(szBuffer) + 1, 0,
                                              gIDSysItems[3].hszitem,
                                              CF_TEXT, HDATA_APPOWNED);


   gIDSysItems[4].hszitem = DdeCreateStringHandle(idInst, SZDDESYS_ITEM_STATUS,
                                                  CP_WINANSI);

   LoadString(ghInst, IDS_STATUS, szBuffer, MAXSIZE);

   gIDSysItems[4].hData = DdeCreateDataHandle(idInst, szBuffer,
                                              lstrlen(szBuffer) + 1, 0,
                                              gIDSysItems[4].hszitem,
                                              CF_TEXT, HDATA_APPOWNED);


   gIDSysItems[5].hszitem = DdeCreateStringHandle(idInst, SZDDESYS_ITEM_SYSITEMS,
                                                  CP_WINANSI);

   LoadString(ghInst, IDS_SYSITEMS, szBuffer, MAXSIZE);

   gIDSysItems[5].hData = DdeCreateDataHandle(idInst, szBuffer,
                                              lstrlen(szBuffer) + 1, 0,
                                              gIDSysItems[5].hszitem,
                                              CF_TEXT, HDATA_APPOWNED);


   gIDSysItems[6].hszitem = DdeCreateStringHandle(idInst, SZDDESYS_ITEM_TOPICS,
                                                  CP_WINANSI);

   LoadString(ghInst, IDS_TOPICS, szBuffer, MAXSIZE);

   gIDSysItems[6].hData = DdeCreateDataHandle(idInst, szBuffer,
                                              lstrlen(szBuffer) + 1, 0,
                                              gIDSysItems[6].hszitem,
                                              CF_TEXT, HDATA_APPOWNED);
}




//*************************************************************
//
//  Function: InitApplication()
//
//  Purpose:
//      Initializes the application (window classes)
//
//  Parameters:
//      HANDLE hInstance - hInstance from WinMain
//      
//  Return: (BOOL)
//      Returns TRUE if successful, FALSE otherwise.
//
//  Comments:
//
//  History:    Date       Author     Comment
//              1/6/92     saraw      Created
//*************************************************************
BOOL InitApplication (HANDLE hInstance)
{

   // All the standard stuff...

   WNDCLASS wc;

   wc.style = NULL;
   wc.lpfnWndProc = MainWndProc;

   wc.cbClsExtra = 0;
   wc.cbWndExtra = 0;
   wc.hInstance = hInstance;
   wc.hIcon = LoadIcon(hInstance, "MAINICON");
   wc.hCursor = LoadCursor(NULL, IDC_ARROW);
   wc.hbrBackground = COLOR_APPWORKSPACE + 1;
   wc.lpszMenuName = szMainMenu;
   wc.lpszClassName = szMainClass;

   if (!RegisterClass(&wc))
      return FALSE;

   return TRUE;
}   //*** InitApplication()


//*************************************************************
//
//  Function: InitInstance()
//
//  Purpose:
//        Initializes each instance (window creation)
//
//  Parameters:
//      HANDLE hInstance - handle to this instance.
//      int nCmdShow     - command line
//      
//  Return: (BOOL)
//      Returns TRUE if successful, FALSE otherwise.
//
//  Comments:
//
//  History:    Date       Author     Comment
//              1/6/92     saraw      Created
//*************************************************************
BOOL InitInstance (HANDLE hInstance, int nCmdShow)
{
   BITMAP bm;
   int iScreenWidth, iScreenHeight;    // width & height of current screen
   WORD wBitmapWidth, wBitmapHeight;

   ghInst = hInstance;

   // Load bitmaps in bitmap structure - wait until server is
   // registered (ie., we have a valid idInst) to load the 
   // data handles into the bitmap structure.

   gBitmapHandles[CIRCLES].hBitmap = LoadBitmap(ghInst, "CIRCLE");
   gBitmapHandles[STRMERS].hBitmap = LoadBitmap(ghInst, "STREAMERS");
   gBitmapHandles[SHAPES].hBitmap = LoadBitmap(ghInst, "SHAPE");

   // Server's main window is sized according to the size of a
   // bitmap.  This way, the StretchBlt()s are really just 
   // BitBlt()s unless the user sizes the window.

   GetObject(gBitmapHandles[0].hBitmap, sizeof(BITMAP), &bm);

   wBitmapWidth = bm.bmWidth;
   wBitmapHeight = bm.bmHeight;

   iScreenWidth = GetSystemMetrics(SM_CXSCREEN);
   iScreenHeight = GetSystemMetrics(SM_CYSCREEN);

   // Server's main window is also scaled according to the type
   // of display.

   if ((iScreenWidth != STNDWIDTH) | (iScreenHeight != STNDHEIGHT))
   {
      // scaling is required.
      wBitmapWidth = MulDiv(bm.bmWidth, iScreenWidth, STNDWIDTH);
      wBitmapHeight = MulDiv(bm.bmHeight, iScreenHeight, STNDHEIGHT);
   }
   ghWndMain = CreateWindow(szMainClass,
			    "Sample DMLSRV Application",
                            WS_OVERLAPPEDWINDOW,
                            GetSystemMetrics(SM_CXSCREEN) - (wBitmapWidth + 10),
                            20,
                            wBitmapWidth + 2 * GetSystemMetrics(SM_CXFRAME),
                            wBitmapHeight + 2 * GetSystemMetrics(SM_CYFRAME)
                            + GetSystemMetrics(SM_CYMENU)
                            + GetSystemMetrics(SM_CYCAPTION) - 1,
                            NULL, NULL, hInstance, NULL);

   if (!ghWndMain)
      return (FALSE);

   ShowWindow(ghWndMain, nCmdShow);
//   UpdateWindow(ghWndMain);
   return (TRUE);
}   //*** InitInstance()

//*** EOF: init.c
