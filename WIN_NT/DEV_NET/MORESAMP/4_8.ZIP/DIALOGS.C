//*************************************************************
//  File name: dialogs.c
//
//  Purpose:
//      dialog procedures for server
//
// Functions:
//    SelectDialogProc()  - handles messages for Select dialog box
//    RequestDialogProc() - handles messages for Request dialog box
//    About()             - handles messages for the about box
//
// Development Team:
//    Sara Williams
//
// Written by Microsoft Product Support Services, Windows Developer Support
// Copyright (c) 1992 Microsoft Corporation. All rights reserved.
//*************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "global.h"

//*************************************************************
//
//  Function: SelectDialogProc()
//
//  Purpose:
//    Dialog box procedure for select data dialog box
//
//
//  Parameters:
//    HWND hDlg         - handle to dialog box window
//    unsigned uMessage - current message
//    WORD wParam       - additional information
//    LONG lParam       - additional information
//
//  Return: (BOOL PASCAL)
//    Returns TRUE if message was processed, FALSE if the message was not
//    processed.  EndDialog() returns the index of the bitmap that the 
//    user selected.
//
//  Comments:  
//    The user selects the bitmap to transfer (in a hot or warm advise loop)
//    to the client in this dialog box.
//
//  History:    Date       Author     Comment
//              1/23/92    saraw      Created
//*************************************************************
BOOL FAR PASCAL SelectDialogProc (HWND hDlg,
                                  unsigned uMessage,
                                  WORD wParam,
                                  LONG lParam)
{
   // This dialog box allows the user to select a bitmap.  The
   // server displays the selected bitmap and lets the client know
   // that the bitmap has changed.

   static int iSelected;     // bitmap the user selected.

   switch (uMessage)
   {
      case WM_INITDIALOG:
         CheckRadioButton(hDlg, IDC_STREAMERS, IDC_SHAPES, IDC_SHAPES);
         iSelected = SHAPES;
      return TRUE;

      case WM_COMMAND:
         if (wParam == IDOK)    // user clicked the ok button.
         {
            EndDialog(hDlg, iSelected);
            return TRUE;
         }

         else
         {
            if (HIWORD(lParam) != BN_CLICKED)
               return FALSE;
            else   // User clicked on one of the radio buttons
            {
               switch (wParam)
               {
                  case IDC_STREAMERS:
                     iSelected = STRMERS;
                  break;

                  case IDC_CIRCLES:
                     iSelected = CIRCLES;
                  break;

                  case IDC_SHAPES:
                  default:
                     iSelected = SHAPES;
                  break;
                }
                return TRUE;
            }
         }
         break;

      default:
         return FALSE;  // let dialog manager process this message.
   }

   return TRUE;
}



//*************************************************************
//
//  Function: RequestDialogProc()
//
//  Purpose:
//    Dialog box procedure for request data dialog box
//
//
//  Parameters:
//    HWND hDlg         - handle to dialog box window
//    unsigned uMessage - current message 
//    WORD wParam       - additional information
//    LONG lParam       - additional information
//      
//
//  Return: (BOOL PASCAL)
//
//  Comments:
//    The user selects a number to pass back to the client (via an 
//    asynchronous transaction) in this dialog box.
//
//  History:    Date       Author     Comment
//              1/16/92    saraw      Created
//*************************************************************
BOOL FAR PASCAL RequestDialogProc (HWND hDlg,
                                   unsigned uMessage,
                                   WORD wParam,
                                   LONG lParam)
{
   // This dialog box allows the user to select a number.  The
   // number is then passed on to the client in an asynchronous
   // transaction.  The client then uses that number to display
   // copies of a really cool bitmap in its client area.

   static WORD wLastNumberSelected = 1;

   switch (uMessage)
   {
      case WM_INITDIALOG:
         CheckRadioButton(hDlg, IDC_ONE, IDC_TWENTYFIVE, IDC_ONE);
         wLastNumberSelected = IDC_ONE - CONTROL_FACTOR;
         return TRUE;

      case WM_COMMAND:
         if (wParam == IDOK)  // User clicked on the ok button.
         {
            EndDialog(hDlg, wLastNumberSelected);  // return the number the
            return TRUE;                           // user selected to the
         }                                         // mainwndproc.
         else
         {
            if (HIWORD(lParam) != BN_CLICKED)
               return FALSE;

            else   // User clicked on one of the radio buttons
            {
               wLastNumberSelected = wParam - CONTROL_FACTOR;
               return TRUE;
            }
         }
         break;

      case WM_DESTROY:
         return TRUE;

      default:
         return FALSE;
   }

   return TRUE;
}



//*************************************************************
//
//  Function: About()
//
//  Purpose:
//      About dialog box procedure
//
//
//  Parameters:
//      HWND hDlg      - handle to dialog box window
//      unsigned msg   - current message 
//      WORD wParam    - additional information
//      LONG lParam    - additional information
//      
//
//  Return: (BOOL FAR PASCAL)
//      Returns TRUE if the message is processed and FALSE if 
//      the message is not processed.
//
//  Comments:
//
//  History:    Date       Author     Comment
//              1/6/92     saraw      Created
//*************************************************************

BOOL FAR PASCAL About (HWND hDlg, unsigned msg, WORD wParam, LONG lParam)
{
   switch (msg)
   {
      case WM_INITDIALOG:
         return (TRUE);

      case WM_COMMAND:
         if (wParam == IDOK || wParam == IDCANCEL)
         {
            EndDialog(hDlg, TRUE);
            return (TRUE);
         }
         break;
   }
   return (FALSE); /* Didn't process a message    */
}   //*** About()
