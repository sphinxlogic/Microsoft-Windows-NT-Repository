//****************************************************************************
//    File name: WEP.C
//
//    Contains the WEP function.  This is in a separate file so that the 
//    WEP can be put into a fixed segment.
//
//    Written by Microsoft Product Support Services, Windows Developer Support
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
// ***************************************************************************

#include <windows.h>
#include "MULTINST.h"
#include <memory.h>
#include "globals.h"

//****************************************************************************
//    FUNCTION:  WEP(int)
//
//    PURPOSE:  Performs cleanup tasks when the DLL is unloaded.
//
//    Written by Microsoft Product Support Services, Windows Developer Support
//    Copyright (c)  1991-1992 Microsoft Corporation.  All rights reserved.
//*****************************************************************************

int FAR PASCAL WEP (bSystemExit)
int bSystemExit;
{
   return (1);
}
