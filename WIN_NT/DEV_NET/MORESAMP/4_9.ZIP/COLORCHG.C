/************************************************************************
 *
 * File Name: colorchg.c
 *
 *    This module contains the routines to do the color manipulation
 *    of the bitmaps, and a few utility funtions.
 *
 * Functions:
 *
 *    ChangeBitmapColor()   - Changes a single color in bitmap
 *    SwapBitmapColors()    - Swaps two colors in a bitmap
 *    CopyBitmap()          - Makes a copy of a bitmap, including the bits
 *
 * Development Team: Mark Bader
 *                   Charlie Kindel
 *
 * Written by Microsoft Product Support Services, Developer Support.
 *********************************************************************/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <windows.h>
#include <ctype.h>
#include "colorchg.h"

//
// The following mnmemonics represent ROP codes.  The syntax is 
// reverse polish notation.  For example DSa means that source and
// desitination are AND'd (&) together.  See page 11-4 of the SDK
// "Reference -- Volume 2" for more information about Ternary
// Raster-Operation Codes.
//

#define DSa       0x008800C6L
#define DSo       0x00EE0086L
#define DSx       0x00660045L
#define DSPDxax   0x00E20746L

#define RGBBLACK     RGB(0,0,0)
#define RGBWHITE     RGB(255,255,255)

// Local function prototypes
VOID FAR PASCAL ChangeBitmapColorDC (HDC hdcBM, LPBITMAP lpBM,
                                     COLORREF rgbOld, COLORREF rgbNew);

/*************************************************************************
 *
 * CopyBitmap()
 *
 * This function makes a copy of a bitmap.
 *
 * Parameters:
 *
 *    HBITMAP hbmSrc - Handle to source bitmap
 *
 * Return value:
 *
 *    Handle to the new bitmap if successful, or NULL if not.
 *
 * History:   
 *            
 *    Date      Author             Reason        
 *    6/10/91   Charlie Kindel     Created
 *    3/26/92   Mark Bader         Fixed allocated size, commented
 *
 *************************************************************************/

HBITMAP FAR PASCAL CopyBitmap(HBITMAP hbmSrc)
{
   HBITMAP hbmDest = NULL;
   BITMAP BM;
   LPSTR lpBits;
   DWORD dwNumBytes;
   GLOBALHANDLE hMem;

   if (!hbmSrc)
      return NULL;

   // Get BITMAP structure from source bitmap
   GetObject(hbmSrc, sizeof(BITMAP), (LPSTR)&BM);

   // Figure out how much space we need for the
   // bitmap bits, and alloc the space

   dwNumBytes = (DWORD)BM.bmHeight * BM.bmWidthBytes;

   if (hMem = GlobalAlloc(GHND, dwNumBytes))
   {
      // Make a new bitmap the same as the source (except this call
      // does not copy the bits, we have to do that ourselves)

      if (hbmDest = CreateBitmapIndirect(&BM))
      {
         if (!(lpBits = GlobalLock(hMem)))
         {
            DeleteObject(hbmDest);
            return NULL;
         }

         // Now copy the bits

         GetBitmapBits(hbmSrc, dwNumBytes, lpBits);
         SetBitmapBits(hbmDest, dwNumBytes, lpBits);

         GlobalUnlock(hMem);
         GlobalFree(hMem);
      }
      else
      {
         GlobalFree(hMem);
         return NULL;
      }
   }
   else
      return NULL;

   return hbmDest;
}                  /* CopyBitmap()  */


/*************************************************************************
 *
 * ChangeBitmapColor()
 *
 *    This function translates the colors in a bitmap from one
 *    to another.
 *
 * Parameters:
 *
 *    HBITMAP hbmSrc  - Bitmap to process
 *    COLORREF rgbOld - Source color
 *    COLORREF rgbNew - Destination color
 *
 * Return value: none.
 *
 * History:   Date      Author      Reason
 *            6/10/91   CKindel     Created
 *            1/28/92   MarkBad     Split "Graying" functionality out into
 *                                    separate API, added palette param
 *
 *************************************************************************/

VOID FAR PASCAL ChangeBitmapColor (HBITMAP hbmSrc, COLORREF rgbOld,
                                   COLORREF rgbNew, HPALETTE hPal)
{
   HDC hDC;
   HDC hdcMem;
   BITMAP bmBits;

   if (hDC = GetDC(NULL))
   {
      if (hdcMem = CreateCompatibleDC(hDC))
      {
      //
      // Get the bitmap struct needed by ChangeBitmapColorDC()
      //
         GetObject(hbmSrc, sizeof(BITMAP), (LPSTR)&bmBits);

         //
         // Select our bitmap into the memory DC
         //
         hbmSrc = SelectObject(hdcMem, hbmSrc);

         // Select in our palette so our RGB references will come
         // out correctly

         if (hPal) {
            SelectPalette(hdcMem, hPal, FALSE);
            RealizePalette(hdcMem);
            }

         //
         // Translate the sucker
         //
         ChangeBitmapColorDC(hdcMem, &bmBits, rgbOld, rgbNew);

         //
         // Unselect our bitmap before deleting the DC
         //
         hbmSrc = SelectObject(hdcMem, hbmSrc);

         DeleteDC(hdcMem);
      }

      ReleaseDC(NULL, hDC);
   }
}                  /* ChangeBitmapColor()  */


/*************************************************************************
 *
 * ChangeBitmapColorDC()
 *
 * This function makes all pixels in the given DC that have the
 * color rgbOld have the color rgbNew.  This function is used by
 * ChangeBitmapColor().
 *
 * Parameters:
 *
 * HDC hdcBM        - Memory DC containing bitmap
 * LPBITMAP lpBM    - Long pointer to bitmap structure from hdcBM
 * COLORREF rgbOld  - Source color
 * COLORREF rgbNew  - Destination color
 *
 * Return value: none.
 *
 * History:   Date      Author      Reason
 *            6/10/91   CKindel     Created
 *            1/23/92   MarkBad     Added big nifty comments which explain
 *                                  how this works, split bitmap graying 
 *                                  code out
 *
 *************************************************************************/

VOID FAR PASCAL ChangeBitmapColorDC (HDC hdcBM, LPBITMAP lpBM,
                                     COLORREF rgbOld, COLORREF rgbNew)
{
   HDC hdcMask;
   HBITMAP hbmMask, hbmOld;
   HBRUSH hbrOld;

   if (!lpBM)
      return;

   //
   // if the bitmap is mono we have nothing to do
   //

   if (lpBM->bmPlanes == 1 && lpBM->bmBitsPixel == 1)
      return;

   //
   // To perform the color switching, we need to create a monochrome 
   // "mask" which is the same size as our color bitmap, but has all 
   // pixels which match the old color (rgbOld) in the bitmap set to 1.  
   // 
   // We then use the ROP code "DSPDxax" to Blt our monochrome 
   // bitmap to the color bitmap.  "D" is the Destination color 
   // bitmap, "S" is the source monochrome bitmap, and "P" is the 
   // selected brush (which is set to the replacement color (rgbNew)).  
   // "x" and "a" represent the XOR and AND operators, respectively.
   // 
   // The DSPDxax ROP code can be explained as having the following 
   // effect:
   // 
   // "Every place the Source bitmap is 1, we want to replace the 
   // same location in our color bitmap with the new color.  All 
   // other colors we leave as is."
   // 
   // The truth table for DSPDxax is as follows:
   // 
   //       D S P Result
   //       - - - ------
   //       0 0 0   0
   //       0 0 1   0
   //       0 1 0   0
   //       0 1 1   1
   //       1 0 0   1
   //       1 0 1   1
   //       1 1 0   0
   //       1 1 1   1
   // 
   // (Even though the table is assuming monochrome D (Destination color), 
   // S (Source color), & P's (Pattern color), the results apply to color 
   // bitmaps also). 
   //
   // By examining the table, every place that the Source is 1 
   // (source bitmap contains a 1), the result is equal to the 
   // Pattern at that location.  Where S is zero, the result equals 
   // the Destination.  
   // 
   // See Section 11.2 (page 11-4) of the "Reference -- Volume 2" for more
   // information on the Termary Raster Operation codes.
   //

   if (hbmMask = CreateBitmap(lpBM->bmWidth, lpBM->bmHeight, 1, 1, NULL))
   {
      if (hdcMask = CreateCompatibleDC(hdcBM))
      {
      //
      // Select th mask bitmap into the mono DC
      //
         hbmOld = SelectObject(hdcMask, hbmMask);

         // 
         // Create the brush and select it into the source color DC --
         // this is our "Pattern" or "P" color in our DSPDxax ROP.
         //

         hbrOld = SelectObject(hdcBM, CreateSolidBrush(rgbNew));

         // 
         // To create the mask, we will use a feature of BitBlt -- when
         // converting from Color to Mono bitmaps, all Pixels of the
         // background colors are set to WHITE (1), and all other pixels
         // are set to BLACK (0).  So all pixels in our bitmap that are
         // rgbOld color, we set to 1.
         //

         SetBkColor(hdcBM, rgbOld);
         BitBlt(hdcMask, 0, 0, lpBM->bmWidth, lpBM->bmHeight,
                hdcBM, 0, 0, SRCCOPY);

         //
         // Where the mask is 1, lay down the brush, where it is 0, leave
         // the destination.
         //

         SetBkColor(hdcBM, RGBWHITE);
         SetTextColor(hdcBM, RGBBLACK);

         BitBlt(hdcBM, 0, 0, lpBM->bmWidth, lpBM->bmHeight,
                hdcMask, 0, 0, DSPDxax);

         SelectObject(hdcMask, hbmOld);

         hbrOld = SelectObject(hdcBM, hbrOld);
         DeleteObject(hbrOld);

         DeleteDC(hdcMask);
      }
      else
         return;

      DeleteObject(hbmMask);
   }
   else
      return;
}                  /* ChangeBitmapColorDC()  */



//**************************************************************************
//
// SwapBitmapColors()
//
// Purpose:
//   
//   Exchanges all colors in bitmap with color "cr1" with color "cr2".
//   
// Parameters:
//
// HDC hdcBM        - Memory DC containing bitmap
// LPBITMAP lpBM    - Long pointer to bitmap structure from hdcBM
// COLORREF rgbOld  - Source color
// COLORREF rgbNew  - Destination color
//
// Return value: none.
//
// Comments:
//
// The way this function works is by creating 2 monochrome "masks" 
// which will be used to "cut out" the first and second colors:
//
// 1. Our first mask will have all pixels of Color #1 turned into 
// WHITE (1) in the mask, and all other pixels turned to BLACK (0).  
//
// 2. Our second mask will have all pixels of Color #2 turned into 
// WHITE (1) in the mask, and all other pixels turned to BLACK (0).
//
// With the above 2 masks, we call BitBlt with the DSPDxax ROP code
// twice to do the work.  For an explanation of the DSPDxax ROP code
// and how it works, see the function ChangeBitmapColorDC() above.
//
// History:    Date       Author        Comment
//             3/26/92    Mark Bader    Created it!
//
//**************************************************************************

VOID FAR PASCAL SwapBitmapColors (HBITMAP hBmSource, COLORREF cr1,
                                    COLORREF cr2, HPALETTE hPal) {

  HDC hDCMask1,          // hDC for Mask #1
      hDCMask2,          // hDC for Mask #2
      hDCSource;         // hDC which contains original bitmap

  HPALETTE hOldPal;      // Keeps track of old palette

  HBITMAP hBmMask1,      // Bitmap for Mask 1
          hBmMask2,      // Bitmap for Mask 2
          hBmOldSource,  // Old bitmaps
          hBmOld1,
          hBmOld2;

  int bmW, bmH;          // Bitmap Width & Height
  HDC hDC;
  BITMAP bm;

  HBRUSH hBr1, hBr2, hBrOld;

  // Create DCs for each of our bitmaps we are going to manipulate

  hDC = GetDC(NULL);
  hDCMask1 = CreateCompatibleDC(hDC);
  hDCSource = CreateCompatibleDC(hDC);
  hDCMask2 = CreateCompatibleDC(hDC);

  // hDCSource will just contain our original bitmap.

  hBmOldSource = SelectObject(hDCSource, hBmSource);

     // Select in our palette so our RGB references will come
     // out correctly

     if (hPal) {
        hOldPal = SelectPalette(hDCSource, hPal, FALSE);
        RealizePalette(hDCSource);
        }


  GetObject(hBmSource, sizeof(BITMAP), &bm);

  bmW = bm.bmWidth;
  bmH = bm.bmHeight;

  // Create MONO bitmaps for each of the masks

  hBmMask1 = CreateBitmap(bmW, bmH, 1, 1, NULL);
  hBmMask2 = CreateBitmap(bmW, bmH, 1, 1, NULL);

  hBmOld1 = SelectObject(hDCMask1, hBmMask1);
  hBmOld2 = SelectObject(hDCMask2, hBmMask2);

  ReleaseDC(NULL, hDC);

  // To create the masks, we will use a feature of BitBlt -- when
  // converting from Color to Mono bitmaps, all Pixels of the
  // background colors are set to WHITE (1), and all other pixels
  // are set to BLACK (0).  This is how we will create the two
  // masks.

  // Transform into a Mono bitmap with all pixels of color "cr1"
  // in the color bitmap being WHITE in the new bitmap (all else is black)

  SetBkColor(hDCSource, cr1);
  BitBlt(hDCMask1, 0, 0, bmW, bmH, hDCSource, 0, 0, SRCCOPY);

  // Get second mono mask same way, but with color 2

  SetBkColor(hDCSource, cr2);
  BitBlt(hDCMask2, 0, 0, bmW, bmH, hDCSource, 0, 0, SRCCOPY);


  // Now apply the magic ROP code

  hBr2 = CreateSolidBrush(cr2);

  hBrOld = SelectObject(hDCSource, hBr2);

  SetBkColor(hDCSource, RGBWHITE);
  SetTextColor(hDCSource, RGBBLACK);

  BitBlt(hDCSource, 0, 0, bmW, bmH, hDCMask1, 0, 0, DSPDxax);

  hBr1 = CreateSolidBrush(cr1);
  SelectObject(hDCSource, hBr1);

  BitBlt(hDCSource, 0, 0, bmW, bmH, hDCMask2, 0, 0, DSPDxax);

  // Clean up

  SelectObject(hDCSource, hBrOld);
  DeleteObject(hBr1);
  DeleteObject(hBr2);

  SelectObject(hDCMask1, hBmOld1);
  DeleteObject(hBmMask1);

  SelectObject(hDCMask2, hBmOld2);
  DeleteObject(hBmMask2);

  SelectObject(hDCSource, hBmOldSource);
  // Don't Delete hBmSource!

  SelectPalette(hDCSource, hOldPal, FALSE);
  // Don't delete hPal!

  DeleteDC(hDCMask1);
  DeleteDC(hDCMask2);
  DeleteDC(hDCSource);
     
}
