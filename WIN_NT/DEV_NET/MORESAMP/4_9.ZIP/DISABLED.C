/*********************************************************************
 *
 * File Name: disabled.c
 *
 *   This module contains a routine which will turn a color bitmap
 *   into a "disabled" or "grayed" bitmap.
 *
 * Functions:
 *
 *   CreateDisabledBitmap() - makes a "disabled" bitmap from a color one
 *
 * Development Team: Bryan Woodruff
 *                   Mark Bader
 *
 * Written by Microsoft Product Support Services, Developer Support.
 *********************************************************************/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <windows.h>

#define RGB_BTNFACE       GetSysColor( COLOR_BTNFACE )
#define RGB_BTNSHADOW     GetSysColor( COLOR_BTNSHADOW )
#define RGB_BTNHIGHLIGHT  GetSysColor( COLOR_BTNHIGHLIGHT )
#define RGB_WHITE         RGB( 255, 255, 255 )
#define RGB_BLACK         RGB( 0, 0, 0 )

#define PSDPxax 0x00B8074A

//**************************************************************************
//
// CreateDisabledBitmap()
//
// Purpose:
//   
//   Creates a "disabled" bitmap (or "tinfoil" effect) using the 
//   specified bitmap.
//   
// Parameters:
//
//   HBITMAP  - the source bitmap to "disable".  This bitmap must not
//              be currently selected into a DC.
//
// Return:
//
//   HBITMAP  - the "disabled" bitmap
//
// Comments:
//
//   The source bitmap can be any color format, or monochrome.  This
//   routine will essentially map the color bitmap down to a few shades
//   of gray, black, and white which represents the original bitmap in a
//   raised, 3-D effect.  Borders of contrasting colors in the original 
//   bitmap will show up as lines of "shadow" in the resulting bitmap.  
//
//   This routine does not destroy the original bitmap.
//   
//
// History:    Date       Author           Comment
//             2/10/92    Bryan Woodruff   Wrote it.
//
//**************************************************************************

HBITMAP CreateDisabledBitmap( HBITMAP hBitmap )
{
   BITMAP   bmInfo ;
   HBITMAP  hbmOld, hbmShadow, hbmHighlight, hbmDisable ;
   HBRUSH   hbrPat ;
   HDC      hDC, hColorDC, hMonoDC ;

   // We essentially need to create 2 monochrome bitmaps:  one defining the 
   // "highlight" area on the bitmap, and one defining the "shadow"
   // area, which is how we make the resulting bitmap look 3-D.  Both
   // the highlight and shadow bitmaps are created by offsetting
   // calls to BitBlt() using various ROP codes.  hbmDisable is our 
   // result bitmap.

   hbmDisable = NULL ;
   hDC = GetDC( NULL ) ;
   if (NULL != (hMonoDC = CreateCompatibleDC( hDC )) &&
       NULL != (hColorDC = CreateCompatibleDC( hDC )))
   {
      // create the monochrome and color bitmaps and
      // necessary DCs

      GetObject( hBitmap, sizeof( BITMAP ), (LPSTR) &bmInfo ) ;
      hbmShadow =
         CreateBitmap( bmInfo.bmWidth, bmInfo.bmHeight, 1, 1, NULL ) ;
      hbmHighlight =
         CreateBitmap( bmInfo.bmWidth, bmInfo.bmHeight, 1, 1, NULL ) ;
      hbmDisable =
         CreateCompatibleBitmap( hDC, bmInfo.bmWidth, bmInfo.bmHeight ) ;

      hbmOld = SelectObject( hColorDC, hBitmap ) ;

      // set background color of bitmap for mono conversion

      SetBkColor( hColorDC, GetPixel( hColorDC, 0, 0 ) ) ;

      // Create the shadow bitmap.

      hbmShadow = SelectObject( hMonoDC, (HGDIOBJ) hbmShadow ) ;
      PatBlt( hMonoDC, 0, 0, bmInfo.bmWidth, bmInfo.bmHeight, WHITENESS ) ;
      BitBlt( hMonoDC, 0, 0, bmInfo.bmWidth - 1, bmInfo.bmHeight - 1,
              hColorDC, 1, 1, SRCCOPY ) ;
      BitBlt( hMonoDC, 0, 0, bmInfo.bmWidth, bmInfo.bmHeight,
              hColorDC, 0, 0, MERGEPAINT ) ;

      hbmShadow = SelectObject( hMonoDC, (HGDIOBJ) hbmShadow ) ;

      // create the highlight bitmap

      hbmHighlight = SelectObject( hMonoDC, (HGDIOBJ) hbmHighlight ) ;
      BitBlt( hMonoDC, 0, 0, bmInfo.bmWidth, bmInfo.bmHeight,
              hColorDC, 0, 0, SRCCOPY ) ;
      BitBlt( hMonoDC, 0, 0, bmInfo.bmWidth- 1, bmInfo.bmHeight - 1,
              hColorDC, 1, 1, MERGEPAINT ) ;
      hbmHighlight = SelectObject( hMonoDC, (HGDIOBJ) hbmHighlight ) ;

      // select old bitmap into color DC

      SelectObject( hColorDC, hbmOld ) ;

      // clear the background for the disabled bitmap

      SelectObject( hColorDC, hbmDisable ) ;

      hbrPat = CreateSolidBrush( RGB_BTNFACE ) ;
      hbrPat = SelectObject( hColorDC, hbrPat ) ;
      PatBlt( hColorDC, 0, 0, bmInfo.bmWidth, bmInfo.bmHeight, PATCOPY ) ;
      DeleteObject( SelectObject( hColorDC, hbrPat ) ) ;
      SetBkColor( hColorDC, RGB_WHITE ) ;
      SetTextColor( hColorDC, RGB_BLACK ) ;

      // blt the highlight edge

      hbrPat = CreateSolidBrush( RGB_BTNHIGHLIGHT ) ;
      hbrPat = SelectObject( hColorDC, hbrPat ) ;
      hbmHighlight = SelectObject( hMonoDC, (HGDIOBJ) hbmHighlight ) ;
      BitBlt( hColorDC, 0, 0, bmInfo.bmWidth, bmInfo.bmHeight,
              hMonoDC, 0, 0, PSDPxax ) ;
      DeleteObject( SelectObject( hColorDC, hbrPat ) ) ;
      hbmHighlight = SelectObject( hMonoDC, (HGDIOBJ) hbmHighlight ) ;

      // blt the shadow edge

      hbrPat = CreateSolidBrush( RGB_BTNSHADOW ) ;
      hbrPat = SelectObject( hColorDC, hbrPat ) ;
      hbmShadow = SelectObject( hMonoDC, (HGDIOBJ) hbmShadow ) ;
      BitBlt( hColorDC, 0, 0, bmInfo.bmWidth, bmInfo.bmHeight,
              hMonoDC, 0, 0, PSDPxax ) ;
      DeleteObject( SelectObject( hColorDC, hbrPat ) ) ;
      hbmShadow = SelectObject( hMonoDC, (HGDIOBJ) hbmShadow ) ;

      // select old bitmap into color DC - hbmColor now
      // contains the "tinfoil'd" bitmap

      SelectObject( hColorDC, hbmOld ) ;

      DeleteObject( (HGDIOBJ) hbmShadow ) ;
      DeleteObject( (HGDIOBJ) hbmHighlight ) ;

      ReleaseDC( NULL, hDC ) ;
   }
   if (hMonoDC)
      DeleteDC( hMonoDC ) ;
   if (hColorDC)
      DeleteDC( hColorDC ) ;

   return ( hbmDisable ) ;

} // end of CreateDisabledBitmap()
