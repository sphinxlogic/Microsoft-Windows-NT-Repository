//****************************************************************************
// File: DITHER.C
//
//    This module provides the bitmap dithering functions.
//
//    MonoDitherBitmap() -- Dithers color to mono bitmap
//
// Development Team:
//     
//          Mark Bader
//
// Written by Microsoft Product Support Services, Windows Developer Support
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//****************************************************************************

#include <windows.h>

#include <memory.h>
#include <string.h>
#include "dibapi.h"
#include "bmutil.h"
#include "colorchg.h"  // for CopyBitmap()

// NOTE:
// The following code is a Windows implementaion of the Bayer-method 
// ordered dither for a monochrome bitmap, and is intended as a 
// demonstration of the direct manipulation of the bits in a Windows 
// DIB rather than a demonstration of the dithering technique.  
// Since this dithering technique was not designed by Microsoft and 
// is in the public domain, Microsoft cannot support issues in 
// dealing with the dithering technique itself, and cannot answer 
// questions about this algorithm.

// The text file included with this sample, DITHER.TXT explains various 
// dithering techniques, and should help point you to other sources of 
// information about dithering.  As with the dithering technique, 
// this included text file is not written by Microsoft but is in 
// the public domain, and therefore we cannot field questions about 
// the document.  It is included only as a convenience.


int pattern[8][8] = {
    { 0, 32,  8, 40,  2, 34, 10, 42},   /* 8x8 Bayer ordered dithering  */
    {48, 16, 56, 24, 50, 18, 58, 26},   /* pattern.  Each input pixel   */
    {12, 44,  4, 36, 14, 46,  6, 38},   /* is scaled to the 0..63 range */
    {60, 28, 52, 20, 62, 30, 54, 22},   /* before looking in this table */
    { 3, 35, 11, 43,  1, 33,  9, 41},   /* to determine the action.     */
    {51, 19, 59, 27, 49, 17, 57, 25},
    {15, 47,  7, 39, 13, 45,  5, 37},
    {63, 31, 55, 23, 61, 29, 53, 21} };


// Local prototype
void SetMonoPixel(LPSTR lpScanLine, int x);
HBITMAP ConvertMonoDIBToMonoBitmap(HDIB);

//**************************************************************************
//
// MonoDitherBitmap()
//
// Purpose:
//   
//   Dithers the specified color bitmap to a monochrome bitmap, using the
//   Bayer ordered dithering technique.
//   
// Parameters:
//
//   HBITMAP - Bitmap to operate on
//   HPALETTE - Palette of the bitmap
//
// Return:
//
//   HBITMAP - a monochrome dithered bitmap representing the input bitmap.
//
// Comments:
//
//   Does not destroy the HBITMAP or HPALETTE passed in as parameters.  For
//   speed reasons, this function uses DIBs internally to get the work
//   done.
//
// History:    Date       Author        Comment
//             3/26/92    Mark Bader    Created based on code in DITHER.TXT
//
//**************************************************************************


// This function is a Windows implementation of the Bayer-method ordered
// dithering technique.  The intent of this code is not to explain
// the technique, but to explain how we do it with a DIB.  Here's
// the basic Bayer algorithm:
//
// int getline();               // Function to read line[] from image
//                              //    file; must return EOF when done.
// putdot(int x, int y);        // Plot white dot at given x, y.
//
// int line[WIDTH];             // Contains pixel intensities from 0..255
// int pattern[8][8];           // Pattern matrix.  Defined above.
//
//  while (getline() != EOF) {
//      for (x=0; x<WIDTH; ++x) {
//          c = line[x] >> 2;           /* Scale value to 0..63 range   */
//   
//          if (c > pattern[x & 7][y & 7]) putdot(x, y);
//      }
//      ++y;
//  }
//
// If we were using GetPixel/SetPixel, this algorithm would be pretty
// straight-forward to implement.  But since the overhead for every
// GetPixel or SetPixel is pretty high, the dithering would be
// VERY slow.  A better way to do this would be to convert the 
// HBITMAP to a DIB, dither this DIB to a monochrome DIB, then convert 
// back to a monochrome bitmap.  This is what we'll use.  
//
// Using a DIB is a bit more complicated, because getting to the RGB
// values for each pixel involves the following:
//
// *  Get the color table index from the bitmap bits.  Also need
//    to take into account the number of bits per pixel here
//
// *  Go into the DIB color table, and get the R, G and B values
//    for the specified color
//
// Once we have the RGB values, we can determine "c" in the algorithm
// (which we will call "Intensity") by using the R, G, and B values.  
// Currently, the formula is (R+G+B)/3.
//
// Then from this Intensity, we:
//
// *  Determine if our intensity is greater than the dither pattern
//    matrix.  If so, put a white dot down.
//
// It's as simple as that!
//
//     -Mark Bader    3/26/92


HBITMAP MonoDitherBitmap(HBITMAP hSourceBitmap, HPALETTE hPalette) {

    WORD x, y;                // Used to traverse DIB, x = width, y = height
    int nBits;                // Bit count for DIB
    WORD nWidth, nHeight;     // Width & Height for DIB
    int Intensity;            // Intensity value ("c" in algorithm above)
    BYTE nCTIndex1,nCTIndex2; // Color Table Indicies
    HBITMAP hBitmapRet;       // HBITMAP returned from this function
    BITMAP bm;                // Used to check out source bitmap

    HDIB hDib, hDibMono;      // Handles to our 2 DIBs

    LPBITMAPINFOHEADER lpbi;  // Info for COLOR DIB:
    int nWidthBytes;             // Width in bytes of each scanline
    char _huge *lpCurPos;        // Huge pointer to scanline and bits --
    char _huge *lpbits;          //    we wouldn't want these to segment wrap
    RGBQUAD FAR *lpct;           // Pointer to color table


    LPBITMAPINFOHEADER lpbiMono; // Same info, but for Monochrome DIB
    int nWidthBytesMono;
    char _huge *lpCurPosMono;
    char _huge *lpbitsMono;
    RGBQUAD FAR *lpctMono;


    // Parameter checking
    if (!hSourceBitmap) return NULL;

    // Optimization - if bitmap is already mono, just return a copy 
    GetObject(hSourceBitmap, sizeof(BITMAP), &bm);

    if (bm.bmPlanes == 1 && bm.bmBitsPixel == 1)
        return (CopyBitmap(hSourceBitmap));

    // Convert bitmap to DIB, and get pointer to DIB
    hDib = BitmapToDIB(hSourceBitmap, hPalette);
    if (!(lpbi = (LPBITMAPINFOHEADER)GlobalLock(hDib)))
      return (NULL);

    // Find pointers to the bits and color table, respectively
    lpbits = (char huge *)FindDIBBits((LPSTR)lpbi);
    lpct = (RGBQUAD FAR *)((LPSTR)lpbi + sizeof(BITMAPINFOHEADER));

    // Get some info from DIB
    nBits = lpbi->biBitCount;
    nHeight = (WORD)(lpbi->biHeight);
    nWidth = (WORD)(lpbi->biWidth);
    nWidthBytes = (int)WIDTHBYTES(nWidth * nBits);

    // Create a Monochrome DIB to hold our resulting dithered
    // bitmap, and find the same information about the DIB -- 
    // pointer to color table, pointer to bits, width of scanline.

    hDibMono = CreateDIB(nWidth, nHeight, 1);
    lpbiMono = (LPBITMAPINFOHEADER)GlobalLock(hDibMono);
    lpbitsMono = (char _huge *)FindDIBBits((LPSTR)lpbiMono);
    lpctMono = (RGBQUAD FAR *)((LPSTR)lpbiMono + sizeof(BITMAPINFOHEADER));
    nWidthBytesMono = (int)WIDTHBYTES(nWidth * 1);

    // Set the bits in the bitmap to all zeros -- this essentially
    // paints our bitmap all black because the zero will point to
    // colortable entry 0, which is black.  

    _fmemset((LPSTR)lpbitsMono, 0, nWidthBytesMono * nHeight);

    // Fill in colortable.  entry 0 == black, entry 1 == white.
    lpctMono[0].rgbRed = lpctMono[0].rgbGreen = lpctMono[0].rgbBlue = 0;
    lpctMono[1].rgbRed = lpctMono[1].rgbGreen = lpctMono[1].rgbBlue = 255;

    // Perform the dithering.  See above algorithm for compressed version.
    
    for (y=0;y<nHeight;y++) {  // y = line number
    
        // Get pointer to current scanlines for both the source color
        // and destination monochrome DIB, accounting for DWORD padding.
        // Since these are huge pointers, we don't have to worry about
        // segment wrapping.

        lpCurPos = lpbits + (LONG)((LONG)y * (LONG)nWidthBytes);
        lpCurPosMono = lpbitsMono + (LONG)((LONG)y * (LONG)nWidthBytesMono);

        // Traverse our scanline.  The monochrome case is already taken
        // care of above.  If the source is a 4bpp DIB, we do 2 pixels per
        // byte.  8bpp is easy.  24bpp requires us to process 1 pixel
        // per 3 bytes.  This is all taken care of in the case statement
        // below.

        x = 0;
        while (x < nWidth) {
          switch(nBits) {

            // We already handled the nBits == 1 case above.  
    
            case 4:
    
               // 1. Get the color table index from the bitmap bits.
    
               // Do 2 pixels at a time (since 2 pixels squeeze into 1 byte)
               nCTIndex1 = ((*lpCurPos) >> 4) & 0x0F;
               nCTIndex2 = (*lpCurPos) & 0x0F;
    
               // 2. Go into the DIB color table, and get the R, G and B values
               //    for the specified color
               // 3. Determine the intensity from the RGB colors.
    
               Intensity = ((lpct[nCTIndex1].rgbBlue + 
                            lpct[nCTIndex1].rgbRed +
                            lpct[nCTIndex1].rgbGreen)) /3 >> 2;
    
               // 4. Determine if our intensity is greater than the dither pattern
               //    matrix.  If so, put a white dot down.
    
               if (Intensity > pattern[x & 7][y & 7]) 
                    SetMonoPixel(lpCurPosMono, x);
    
               // Go to next pixel in destination bitmap
               x++;
    
               // Do the same for the second pixel
    
               Intensity = ((lpct[nCTIndex2].rgbBlue + 
                            lpct[nCTIndex2].rgbRed +
                            lpct[nCTIndex2].rgbGreen)) /3 >> 2;
    
               if (Intensity > pattern[x & 7][y & 7]) 
                    SetMonoPixel(lpCurPosMono, x);
    
               x++;
    
               // Since we're done with two pixels, we can go 
               // to the next byte
    
               lpCurPos++;
               break;
    
    
            case 8:
               // Same thing, but one pixel per byte
               nCTIndex1 = *lpCurPos;
               Intensity = ((lpct[nCTIndex1].rgbBlue + 
                            lpct[nCTIndex1].rgbRed +
                            lpct[nCTIndex1].rgbGreen)/3) >> 2;
               if (Intensity > pattern[x & 7][y & 7])
                    SetMonoPixel(lpCurPosMono, x);
               x++;
               lpCurPos++;
               break;
    
    
             case 24:
               // Same thing again, but 3 bytes per pixel
               Intensity = ((*lpCurPos + *(lpCurPos+1) +
                             *(lpCurPos+2)) / 3) >> 2;
               if (Intensity > pattern[x & 7][y & 7]) 
                    SetMonoPixel(lpCurPosMono, x);
               x++;
               lpCurPos += 3;
               break;
            }
    
          }
        }

    // We're finished with our source DIB
    GlobalUnlock(hDib);
    DestroyDIB(hDib);

    // Convert destination DIB to mono, and destroy it when done

    // Call the conversion function.  Normally, we'd call the
    // DIBAPI function DIBToBitmap(), but this function won't work
    // for us in this case:  the DIBToBitmap() function eventually
    // calls CreateDIBitmap(), which always creates a bitmap compatible
    // with the screen.  Since we want our result to be a MONO
    // HBITMAP (not a color one, like the compatible ones would be), 
    // we must use our own function.

    hBitmapRet = ConvertMonoDIBToMonoBitmap(hDibMono);

    GlobalUnlock(hDibMono);
    DestroyDIB(hDibMono);
    return hBitmapRet;

}

//**************************************************************************
//
// ConvertMonoDIBToMonoBitmap()
//
// Purpose:
//   
//   Converts a monochrome DIB to a monochrome bitmap, and returns the
//   monochrome HBITMAP.
//   
// Parameters:
//
//   HDIB   - a Handle to a monochrome DIB
//
// Return:
//
//   HBITMAP - a handle to a monochrome BITMAP
//
// Comments:
//  
//   Normally, we'd call use the DIBAPI function DIBToBitmap() to do
//   this conversion, but this function dosen't work in converting to
//   a monochrome HBITMAP.  The reason is that the DIBToBitmap() function 
//   eventually calls the Windows API CreateDIBitmap(), which always 
//   creates a bitmap compatible with the screen.  Since we want our 
//   result to be a MONO HBITMAP (not a color one, like the compatible 
//   ones would be), we must use our own function.
//
//   Does not destroy source DIB.
//
// History:    Date       Author        Comment
//             3/26/92    Mark Bader    Created
//
//**************************************************************************

HBITMAP ConvertMonoDIBToMonoBitmap(HDIB hDib) {

   LPBITMAPINFOHEADER lpbi;
   LPSTR lpbits;
   static HBITMAP hBitmap;
   HDC hDC, hDCMem;
   HBITMAP hBmOld;


   if (!(lpbi = (LPBITMAPINFOHEADER)GlobalLock(hDib)))
     return NULL;

   // Must be a MONO DIB
   if (lpbi->biBitCount != 1) {
     GlobalUnlock(hDib);
     return NULL;
     }

   lpbits = (LPSTR)FindDIBBits((LPSTR)lpbi);

   // Create our Mono HBITMAP the same size as the DIB

   hBitmap = CreateBitmap((int)lpbi->biWidth, 
                          (int)lpbi->biHeight, 
                          1, 1, NULL);
   hDC = GetDC(NULL);
   hDCMem = CreateCompatibleDC(hDC);
   ReleaseDC(NULL, hDC);

   hBmOld = SelectObject(hDCMem, hBitmap);

   // Call the Windows API SetDIBits(), which copies the DIB bits
   // to the bitmap.

   if (!(SetDIBits(hDCMem, hBitmap, 0, (UINT)lpbi->biHeight, lpbits,
                    (void FAR *)lpbi, DIB_RGB_COLORS))) {
      SelectObject(hDCMem, hBmOld);
      DeleteObject(hBitmap);
      DeleteDC(hDCMem);
      GlobalUnlock(hDib);
      return (NULL);
      }

   SelectObject(hDCMem, hBmOld);
   DeleteDC(hDCMem);
   GlobalUnlock(hDib);
   return (hBitmap);

}




//**************************************************************************
//
// SetMonoPixel()
//
// Purpose:
//   
//   Sets the specified pixel to 1 in the specified scanline.
//   
//   
// Parameters:
//
//   LPSTR    - long pointer to scanline of monochrome DIB
//   int      - pixel number to set to "1"
//
// Comments:
//
//   This funciton actually sets a bit in the correct byte of the
//   scanline for a monochrome DIB.  In a monochrome DIB, each pixel
//   is represented as one bit, so there are 8 pixels per byte.
//
//   To do the "SetPixel", we have to first determine which byte of 
//   the scanline the pixel postion falls (assuming 8 bits per byte).  
//   Once we have this, we need to get the byte pattern at that 
//   location.  We then make a new byte pattern that contains our
//   new pixel turned on, OR it with the old byte pattern, and write
//   it all back to the pointer.  Take a look at the psuedo-code below.
//
//   This should probably be done as a #define, but what if someone
//   does "SetMonoPixel(lp, x++)"??
// 
// History:    Date       Author        Comment
//             3/26/92    Mark Bader    Created
//
//**************************************************************************

// Sets the pixel in scanline lpScanLine at location X to value bValue
// This is for a mono DIB

void SetMonoPixel(LPSTR lpScanLine, int x) {

// Pseudo-code (works fine, but runs a bit slower):
// 
// BYTE bTmp;     // Holds temporary byte
// WORD wByteNum; // Holds byte number of the scan line our x coord. is in
// BYTE wBitNum;  // Bit number within the byte
// BYTE bPattern; // Bit pattern to set byte to
//
// wByteNum = x >> 3;
// wBitNum = 7 - (x % 8);
//     
// bTmp = *(lpScanLine + wByteNum);   // Get existing bit pattern at byte
// bPattern = 0x01 << wBitNum;        // This will be the new bit pattern
// *(lpScanLine + wByteNum) = bPattern | bTmp;   // OR patterns to "set" bit
//
// This code can be reduced to one line:

*(lpScanLine + (x >> 3)) |= (0x01 << (7 - (x % 8)));

}
