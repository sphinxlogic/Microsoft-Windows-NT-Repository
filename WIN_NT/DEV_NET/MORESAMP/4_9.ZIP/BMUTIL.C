/*********************************************************************
 *
 * File Name: bmutil.c
 *
 * Color Change Sample Application
 *
 * Description:
 * ------------
 *
 * Demonstration program of bitmap utilities.  The various APIs allow you
 * to change a single color in a bitmap, create a "gray" or "disabled"
 * bitmap from a color bitmap, and dither a color bitmap to a monochrome
 * bitmap.  These techniques are accomplshed using BitBlt() ROP codes
 * and DIBs.
 *
 *
 * This file defines the following functions:
 *
 *    WinMain           - Application Entry Point
 *    InitApplication   - Application Initialization routine
 *    InitInstance      - Create's main window
 *    MainWndProc       - Main Window Procedure
 *    About             - Handles "About" dialog box
 *    Change            - Handles "Color Change" dialog
 *    DrawArrow         - Draws arrow on Color Change dialog
 *    OpenBmpFile       - Calls Common Dialog to open new bitmap file
 *    WaitCursor        - Sets cursor to hourglass
 *    RestoreCursor     - resets cursor
 *
 * Development Team: Mark Bader
 *
 * Written by Microsoft Product Support Services, Developer Support.
 *********************************************************************/
 
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
// 

#include <windows.h>

#include <commdlg.h>
#include <string.h>    // _fstrncpy

#include "bmutil.h"    
#include "dialogs.h"   
#include "dibapi.h"

#include "colorchg.h"
#include "disabled.h"
#include "dither.h"


// Local function prototypes
void DrawArrow (HDC, POINT, POINT);
void OpenBmpFile(void);
void SaveBmpFile(void);
void WaitCursor(void);
void RestoreCursor(void);

// Global Variables
static HANDLE ghInst;  /* app's instance */
static HWND hwnd;      /* handle to main window */

#define MAXFILENAMELEN 255

static HBITMAP ghBitmap = NULL;      // Handle to our bitmap to display
static HPALETTE ghPalette = NULL;    // Palette for the bitmap
static int numColors;                // Number of colors in palette
static int gDibBits = 0;             // Number of bits per pixel in DIB
static HCURSOR hCurSave = NULL;      // Cursor used in WaitCursor/RestoreCursor
static char gszFileName[MAXFILENAMELEN];  // Name of file to open

/****************************************************************************

    FUNCTION: WinMain(HANDLE, HANDLE, LPSTR, int)

    PURPOSE: calls initialization function, processes message loop

****************************************************************************/

int PASCAL WinMain (HANDLE hInstance, HANDLE hPrevInstance,
                     LPSTR lpCmdLine, int nCmdShow)
{
   MSG msg;

   if (hPrevInstance == 0)
      if (InitApplication(hInstance) == 0)
         return (FALSE);

   if (InitInstance(hInstance, nCmdShow) == 0)
      return (FALSE);

   while (GetMessage(&msg, 0, 0, 0) != 0)
   {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   }

   return (msg.wParam);
}


/****************************************************************************

    FUNCTION: InitApplication(HANDLE)

    PURPOSE: Initializes window data and registers window class

****************************************************************************/

static BOOL InitApplication (HANDLE hInstance)
{
   WNDCLASS wc;

   wc.style = CS_BYTEALIGNWINDOW;   // Makes BitBlt happen faster
   wc.lpfnWndProc = (WNDPROC)MainWndProc;
   wc.cbClsExtra = 0;
   wc.cbWndExtra = 0;
   wc.hInstance = hInstance;
   wc.hIcon = LoadIcon(hInstance, "APPICON");
   wc.hCursor = LoadCursor(0, IDC_ARROW);
   wc.hbrBackground = GetStockObject(WHITE_BRUSH);
   wc.lpszMenuName = (LPSTR)"SampleMenu";
   wc.lpszClassName = (LPSTR)"SampleClass";

   return (RegisterClass(&wc));
}


/****************************************************************************

    FUNCTION:  InitInstance(HANDLE, int)

    PURPOSE:  Saves instance handle and creates main window

****************************************************************************/

static BOOL InitInstance (HANDLE hInstance, int nCmdShow)
{
   ghInst = hInstance;

   hwnd = CreateWindow(
          "SampleClass",
          "Bitmap Utilities Sample",
          WS_OVERLAPPEDWINDOW,
          CW_USEDEFAULT,
          CW_USEDEFAULT,
          450,
          300,
          0,
          0,
          hInstance,
          0);

   if (hwnd == 0)
      return (FALSE);

   ShowWindow(hwnd, nCmdShow);
   UpdateWindow(hwnd);
   return (TRUE);
}


/****************************************************************************

    FUNCTION: MainWndProc(HWND, unsigned, WORD, LONG)

    PURPOSE:  Processes messages

    MESSAGES:

        WM_COMMAND    - application menu (About dialog box)
        WM_DESTROY    - destroy window

    COMMENTS:

        WM_COMMAND processing:

            IDM_ABOUT - display "About" box.
            IDM_TEST  - Test Procedure.

****************************************************************************/

long _far _pascal MainWndProc (HWND hWnd, unsigned message,
                               WORD wParam, LONG lParam)
{

   FARPROC lpDialogProc;

   switch (message)
   {
      case WM_CREATE:
      {
         HDIB hDIB;
         LPBITMAPINFOHEADER lpbi;

         lstrcpy(gszFileName, "eagle.bmp");  // Set up default dib

         // Call our DIBAPI function LoadDIB (contained in DIBAPI.DLL) to
         // read our .BMP file into memory

         hDIB = LoadDIB((LPSTR)gszFileName); 

         // If the loading worked, get some information from the DIB, like
         // a palette and the number of colors in the colortable, and 
         // then convert it to a HBITMAP.

         if (hDIB)
         {
            // Use DIBAPI function CreateDIBPalette to create a HPALETTE
            // from our HDIB
            ghPalette = CreateDIBPalette(hDIB);

            // Convert DIB to bitmap using DIBAPI funciton
            ghBitmap = DIBToBitmap(hDIB, ghPalette);

            // Use DIBAPI function DIBNumColors to get number of colors
            // in DIB
            lpbi = (LPBITMAPINFOHEADER)GlobalLock(hDIB);
            numColors = DIBNumColors((LPSTR)lpbi);
            gDibBits = lpbi->biBitCount;

            GlobalUnlock(hDIB);
            DestroyDIB(hDIB);
         }

      }
         break;

      case WM_PAINT:
      {
         PAINTSTRUCT ps;
         BITMAP bm;
         RECT r;

         BeginPaint(hWnd, &ps);
         GetObject(ghBitmap, sizeof(BITMAP), &bm);
         r.left = r.top = 0;
         r.right = bm.bmWidth;
         r.bottom = bm.bmHeight;

         // Use DIBAPI function to paint bitmap onto screen

         PaintBitmap(ps.hdc, &r, ghBitmap, &r, ghPalette);
         EndPaint(hWnd, &ps);
      }
         break;

      case WM_COMMAND:
         switch (wParam)
         {
            case IDM_OPEN:
               OpenBmpFile();
               break;

            case IDM_SAVE:
               SaveBmpFile();
               break;

            case IDM_ABOUT:
               lpDialogProc = MakeProcInstance(About, ghInst);
               DialogBox(ghInst, "About", hWnd, lpDialogProc);
               FreeProcInstance(lpDialogProc);
               break;


            // User selected "Change Bitmap Color..."
            case IDM_CHANGE:
            {
               OPTS opts;
               int iReturn;

               // Call up dialog to allow selection of 2 colors

               lpDialogProc = MakeProcInstance(Change, ghInst);
               iReturn = DialogBoxParam(ghInst, "Change", hWnd, lpDialogProc,
                                        (LONG)(LPOPTS)&opts);
               FreeProcInstance(lpDialogProc);

               if (iReturn)
               {
               WaitCursor();

               if (opts.bSwap)
                  SwapBitmapColors(ghBitmap,
                                     PALETTEINDEX(opts.iColor1),
                                     PALETTEINDEX(opts.iColor2),
                                     ghPalette);

               else

                  // Call function (from bmutil.c) to change first
                  // color in bitmap to second color

                  ChangeBitmapColor(ghBitmap,
                                     PALETTEINDEX(opts.iColor1),
                                     PALETTEINDEX(opts.iColor2),
                                     ghPalette);
                
                  // Now, invalidate so we repaint
                InvalidateRect(hWnd, NULL, FALSE);
                RestoreCursor();

               }

            }
               break;

            // User selected "Gray Bitmap" or "Monochrome Dither" --
            // since the functions which accomplish both of these
            // are very similar in their use, we can combine these
            // two into a single message case:

            case IDM_GRAY:
            case IDM_MONODITHER:
                {
                HBITMAP hBM = NULL;
                WaitCursor();

                // Call correct function to modify bitmap

                if (wParam == IDM_GRAY)
                    hBM = CreateDisabledBitmap(ghBitmap);
                else
                    hBM = MonoDitherBitmap(ghBitmap, ghPalette);
                    
                RestoreCursor();

                // If we have a new bitmap (e.g. function didn't choke),
                // the let's use it, remembering to delete old one.

                if (hBM) {
                    DeleteObject(ghBitmap);
                    ghBitmap = hBM;
                    InvalidateRect(hWnd, NULL, FALSE);
                    }
                else
                    MessageBox(hWnd, "Could not create new bitmap",
                               "Bitmap Process", MB_ICONEXCLAMATION);

                }
                break;


            // Restore bitmap to original -- read from disk again
            case IDM_RESTORE:
            {
               HDIB hDIB;
               LPBITMAPINFOHEADER lpbi;

               if (ghBitmap)
               {
                  DeleteObject(ghBitmap);
                  ghBitmap = 0;
               }

               if (ghPalette)
               {
                  DeleteObject(ghPalette);
                  ghPalette = 0;
               }

               // Use our DIBAPI function to do all the work here.

               hDIB = LoadDIB((LPSTR)gszFileName);

               if (hDIB)
               {
                  ghPalette = CreateDIBPalette(hDIB);
                  ghBitmap = DIBToBitmap(hDIB, ghPalette);
                  lpbi = (LPBITMAPINFOHEADER)GlobalLock(hDIB);
                  numColors = DIBNumColors((LPSTR)lpbi);
                  gDibBits = lpbi->biBitCount;
                  GlobalUnlock(hDIB);
                  DestroyDIB(hDIB);
               }
                else
                    MessageBox(hWnd, "Could not re-load bitmap",
                               "Bitmap Load", MB_ICONEXCLAMATION);
            }
               // Now, invalidate so we repaint
               InvalidateRect(hWnd, NULL, FALSE);
               break;

            case IDM_EXIT:
               PostMessage(hWnd, WM_CLOSE, 0, 0L);
               break;
         }
         break;

      case WM_DESTROY:
         DeleteObject(ghBitmap);       // Delete our global bitmap & palette
         DeleteObject(ghPalette);
         PostQuitMessage(0);
         break;


      // The WM_PALETTECHANGED message informs all windows that the window with
      // input focus has realized its logical palette, thereby changing the
      // system palette. This message allows a window without input focus that
      // uses a color palette to realize its logical palettes and update its
      // client area.
      // 
      // This message is sent to all windows, including the one that changed
      // the system palette and caused this message to be sent. The wParam of
      // this message contains the handle of the window that caused the system
      // palette to change. To avoid an infinite loop, care must be taken to
      // check that the wParam of this message does not match the window's
      // handle. 

      case WM_PALETTECHANGED:
      {
         HDC hDC;  // Handle to device context
         HPALETTE hOldPal;             // Handle to previous logical palette

         // Before processing this message, make sure we
         // are indeed using a palette

         if (ghPalette)
         {
         // If this application did not change the palette, select
         // and realize this application's palette
            if (wParam != hWnd)
            {
               // Need the window's DC for SelectPalette/RealizePalette
               hDC = GetDC(hWnd);

               // Select and realize our palette
               hOldPal = SelectPalette(hDC, ghPalette, FALSE);
               RealizePalette(hDC);

               // WHen updating the colors for an inactive window,
               // UpdateColors can be called because it is faster than
               // redrawing the client area (even though the results are
               // not as good)
               UpdateColors(hDC);

               // Clean up
               if (hOldPal)
                  SelectPalette(hDC, hOldPal, FALSE);
               ReleaseDC(hWnd, hDC);
            }
         }
      }
         break;


      // The WM_QUERYNEWPALETTE message informs a window that it is about to
      // receive input focus. In response, the window receiving focus should
      // realize its palette as a foreground palette and update its client
      // area. If the window realizes its palette, it should return TRUE;
      // otherwise, it should return FALSE. 

      case WM_QUERYNEWPALETTE:
      {
         HDC hDC;  // Handle to device context
         HPALETTE hOldPal;             // Handle to previous logical palette

         // Before processing this message, make sure we
         // are indeed using a palette

         if (ghPalette)
         {
            // Need the window's DC for SelectPalette/RealizePalette
            hDC = GetDC(hWnd);

            // Select and realize our palette
            hOldPal = SelectPalette(hDC, ghPalette, FALSE);
            RealizePalette(hDC);

            // Redraw the entire client area
            InvalidateRect(hWnd, NULL, FALSE);
            UpdateWindow(hWnd);

            // Clean up
            if (hOldPal)
               SelectPalette(hDC, hOldPal, FALSE);
            ReleaseDC(hWnd, hDC);

            // Message processed, return TRUE
            return TRUE;
         }
         // Message not processed, return FALSE
         return FALSE;
      }
         break;

      default:
         return (DefWindowProc(hWnd, message, wParam, lParam));
   }

   return (FALSE);
}

//*************************************************************************
//
//  About()
//
//  Processes messages for "About" dialog box
//
//  Parameters:
//
//     Standard Window Procedure
//
//  History:    Date       Author        Comment
//              3/26/92    Mark Bader    Created
//
//**************************************************************************

BOOL _far _pascal About (HWND hDlg, unsigned message, WORD wParam, LONG lParam)
{

   switch (message)
   {

      case WM_COMMAND:
         if (wParam == IDOK || wParam == IDCANCEL)
         {
            EndDialog(hDlg, TRUE);
            return (TRUE);
         }
         break;
   }
   return (FALSE);
}

//**************************************************************************
//
// Change()
//
// Purpose:
//   
//   Processes messages for Change() dialog. 
//   
// Comments:
//
//   This dialog contains two owner-draw listboxes which get filled with
//   different colors rather than text.  These listboxes allow the user
//   to select two colors.  The WM_DRAWITEM message is trapped so we can
//   do the owner-draw.  
//
//   This dialog also sets the system palette if ghPalette is defined.  We
//   do this because each listbox item is drawn with a palette index color
//   (using PALETTEINDEX()) rather than an RGB value.  For this to work
//   correctly, we've got to Select and Realize our palette.  And since
//   we can potentially change the system palette, we've got to also
//   take care of the WM_QUERYNEWPALETTE and WM_PALETTECHANGED messages
//   in the case that someone else changed the system palette (e.g. our
//   app loses focus as this dialog box is up).
//
//
// History:    Date       Author        Comment
//             3/26/92    Mark Bader    Created
//             3/27/92    Mark Bader    Added palette messages
//
//**************************************************************************

BOOL _far _pascal Change (HWND hDlg, unsigned message, WORD wParam, LONG lParam)
{
   int i;
   LPDRAWITEMSTRUCT pDIS;
   static char szMsg[150];
   RECT rect;
   static LPOPTS lpOpts;

   switch (message)
   {
      case WM_INITDIALOG:

         // lParam contains pointer to our OPTS structure.  Save it.
         lpOpts = (LPOPTS)lParam;

         // Initialize list boxes
         SendDlgItemMessage(hDlg, IDC_SOURCECOLOR, WM_SETREDRAW, FALSE, 0L);
         SendDlgItemMessage(hDlg, IDC_DESTCOLOR, WM_SETREDRAW, FALSE, 0L);

         // Fill in a string to each list box item for debugging purposes
         for (i = 0; i < numColors; i++)
         {
            wsprintf(szMsg, (LPSTR)"Line #%d", i + 1);
            SendDlgItemMessage(hDlg, IDC_SOURCECOLOR, LB_ADDSTRING, 0,
                               (LONG)(LPSTR)szMsg);
            SendDlgItemMessage(hDlg, IDC_DESTCOLOR, LB_ADDSTRING, 0,
                               (LONG)(LPSTR)szMsg);
         }

         wsprintf(szMsg, "DIB color table contains %d entries", numColors);
         SendDlgItemMessage(hDlg, IDC_BOXTEXT, WM_SETTEXT, 0, (LONG)(LPSTR)szMsg);

         wsprintf(szMsg, "DIB biBitCount is %d (%d colors)", gDibBits, 0x01 << gDibBits);
         SendDlgItemMessage(hDlg, IDC_BOXTEXT2, WM_SETTEXT, 0, (LONG)(LPSTR)szMsg);

         SendDlgItemMessage(hDlg, IDC_SOURCECOLOR, WM_SETREDRAW, TRUE, 0L);
         SendDlgItemMessage(hDlg, IDC_DESTCOLOR, WM_SETREDRAW, TRUE, 0L);

         InvalidateRect(GetDlgItem(hDlg, IDC_SOURCECOLOR), NULL, TRUE);
         InvalidateRect(GetDlgItem(hDlg, IDC_DESTCOLOR), NULL, TRUE);

         break;

      case WM_DRAWITEM:
      {
         HBRUSH hBr, hBrOld;
         HPEN hPen, hPenOld;
         HPALETTE hOldPal;

         pDIS = (LPDRAWITEMSTRUCT)lParam;

         // If we're using a palette, select it into our DC that we are
         // drawing onto so our palette indicies will come out the correct
         // color.  The reason we need to do this is that we draw
         // based on the palette index rather than the RGB value.

         if (ghPalette)
         {
            hOldPal = SelectPalette(pDIS->hDC, ghPalette, FALSE);
            RealizePalette(pDIS->hDC);
         }

         // If it's not one of our listboxes, return

         if (pDIS->CtlType != ODT_LISTBOX)
            return FALSE;
         if ((pDIS->CtlID != IDC_SOURCECOLOR) &&
             (pDIS->CtlID != IDC_DESTCOLOR))
            return FALSE;

         if ((pDIS->itemState) & (ODS_SELECTED))
         {
            hPen = CreatePen(PS_INSIDEFRAME, 3, RGB(0,0,0));
            hPenOld = SelectObject(pDIS->hDC, hPen);
         }

         // if we are losing focus, remove the focus rect BEFORE drawing
         // the box

         if ((pDIS->itemAction) & (ODA_FOCUS))
            if (!((pDIS->itemState) & (ODS_FOCUS)))
               DrawFocusRect(pDIS->hDC, (LPRECT)&(pDIS->rcItem));


         // Draw the rectangle

         rect = pDIS->rcItem;
         InflateRect(&rect, -1, -1);

         if ((pDIS->itemID) < 0)       // Watch out -- itemID can be -1
            hBr = CreateSolidBrush(RGB(255,255,255));
         else
            hBr = CreateSolidBrush(PALETTEINDEX(pDIS->itemID));

         hBrOld = SelectObject(pDIS->hDC, hBr);

         Rectangle(pDIS->hDC,
                   rect.left, rect.top,
                   rect.right, rect.bottom);

         // If we are gaining focus, draw the focus rect AFTER drawing the
         // box. 

         if ((pDIS->itemAction) & (ODA_FOCUS))
            if ((pDIS->itemState) & (ODS_FOCUS))
               DrawFocusRect(pDIS->hDC, (LPRECT)&(pDIS->rcItem));

         // Reset DC to previous state

         if ((pDIS->itemState) & (ODS_SELECTED))
         {
            SelectObject(pDIS->hDC, hPenOld);
            DeleteObject(hPen);
         }

         SelectObject(pDIS->hDC, hBrOld);
         DeleteObject(hBr);

         if (ghPalette)
         {
            SelectPalette(pDIS->hDC, hOldPal, FALSE);
         }
      }

         return TRUE;

      case WM_PAINT:
          {

          // Use this paint case to draw the arrow between the two
          // listboxes.  
          //
          // Let's center the arrow between the two listboxes.  For us to
          // draw directly on our dialog's client area like this, we have to
          // be absolutely certain that we aren't drawing over anything.
          // To make sure this is true, let's get the rects for the two
          // listboxes, and draw the arrow between the listboxes.

              PAINTSTRUCT ps;   
              RECT r1,r2;          // Coordinates of list boxes
              POINT p1,p2;         // Used to convert screen to client coords
                      
              BeginPaint(hDlg, &ps);

              // Get locations of the two listboxes

              GetWindowRect(GetDlgItem(hDlg, IDC_SOURCECOLOR), &r1);
              GetWindowRect(GetDlgItem(hDlg, IDC_DESTCOLOR), &r2);

              // Determine location of arrow

              p1.x = r1.right + 20;
              p1.y = r1.top + (r1.bottom - r1.top) / 3;

              p2.x = r2.left - 20;
              p2.y = r1.bottom - (r1.bottom - r1.top) / 3;

              // Convert screen coordinates to client coordinates

              ScreenToClient(hDlg, &p1);
              ScreenToClient(hDlg, &p2);

              // p1 now describes the location of upper-left corner
              // for the arrow, p2 is the lower-right.  Let's draw
              // the arrow.

              DrawArrow(ps.hdc, p1, p2);

              EndPaint(hDlg, &ps);
              break;
           }

      case WM_COMMAND:
         switch (wParam)
         {
            case IDOK:
               if (!lpOpts)
               {
                  EndDialog(hDlg, TRUE);
                  return (FALSE);
               }

               // Extract selections from dialog

               lpOpts->bSwap = (IsDlgButtonChecked(hDlg, IDC_SWAPCOLORS) != 0);

            // typedef struct tagOPTS {
            //    int iColor1;
            //    int iColor2;
            //    BOOL bSwap; // TRUE if swap button is checked
            //    } OPTS;
               lpOpts->iColor1 = (WORD)SendDlgItemMessage(hDlg,
                                                          IDC_SOURCECOLOR, LB_GETCURSEL,
                                                          0, 0L);

               lpOpts->iColor2 = (WORD)SendDlgItemMessage(hDlg,
                                                          IDC_DESTCOLOR, LB_GETCURSEL, 0,
                                                          0L);

               // Make sure the user selected one color from each listbox
               if ((lpOpts->iColor1 == -1) || (lpOpts->iColor2 == -1))
               {
                  MessageBox(hDlg,
                             "You must select one color from the source list "
                             "and one from the destination list.", "Try Again",
                             MB_ICONSTOP);
                  return (TRUE);
               }



               EndDialog(hDlg, TRUE);
               return (TRUE);
               break;

            case IDCANCEL:
               EndDialog(hDlg, FALSE);
               return (TRUE);
               break;

            default:
               return (FALSE);
         }
         break;


      // The WM_PALETTECHANGED message informs all windows that the window with
      // input focus has realized its logical palette, thereby changing the
      // system palette. This message allows a window without input focus that
      // uses a color palette to realize its logical palettes and update its
      // client area.
      // 
      // This message is sent to all windows, including the one that changed
      // the system palette and caused this message to be sent. The wParam of
      // this message contains the handle of the window that caused the system
      // palette to change. To avoid an infinite loop, care must be taken to
      // check that the wParam of this message does not match the window's
      // handle. 

      case WM_PALETTECHANGED:
      {
         HDC hDC;  // Handle to device context
         HPALETTE hOldPal;             // Handle to previous logical palette

         // Before processing this message, make sure we
         // are indeed using a palette

         if (ghPalette)
         {
         // If this application did not change the palette, select
         // and realize this application's palette
            if (wParam != hDlg)
            {
               // Need the window's DC for SelectPalette/RealizePalette
               hDC = GetDC(hDlg);

               // Select and realize our palette
               hOldPal = SelectPalette(hDC, ghPalette, FALSE);
               RealizePalette(hDC);

               // WHen updating the colors for an inactive window,
               // UpdateColors can be called because it is faster than
               // redrawing the client area (even though the results are
               // not as good)
               UpdateColors(hDC);

               // Clean up
               if (hOldPal)
                  SelectPalette(hDC, hOldPal, FALSE);
               ReleaseDC(hDlg, hDC);
            }
         }
      }
         break;


      // The WM_QUERYNEWPALETTE message informs a window that it is about to
      // receive input focus. In response, the window receiving focus should
      // realize its palette as a foreground palette and update its client
      // area. If the window realizes its palette, it should return TRUE;
      // otherwise, it should return FALSE. 

      case WM_QUERYNEWPALETTE:
      {
         HDC hDC;  // Handle to device context
         HPALETTE hOldPal;             // Handle to previous logical palette

         // Before processing this message, make sure we
         // are indeed using a palette

         if (ghPalette)
         {
            // Need the window's DC for SelectPalette/RealizePalette
            hDC = GetDC(hDlg);

            // Select and realize our palette
            hOldPal = SelectPalette(hDC, ghPalette, FALSE);
            RealizePalette(hDC);

            // Redraw the entire client area
            InvalidateRect(hDlg, NULL, FALSE);
            UpdateWindow(hDlg);

            // Clean up
            if (hOldPal)
               SelectPalette(hDC, hOldPal, FALSE);
            ReleaseDC(hDlg, hDC);

            // Message processed, return TRUE
            return TRUE;
         }
         // Message not processed, return FALSE
         return FALSE;
      }
         break;


      default:
         return FALSE;
   }

   return TRUE;
}


//**************************************************************************
//
// DrawArrow()
//
// Purpose:
// 
//   Draws nifty right arrow with the specified upper-left and lower-right
//   points.  Used in the WM_PAINT case of the "Change" dialog procedure
//   above.
//   
// Parameters:
//  
//   HDC   hDC - hDC to paint onto
//   POINT p1  - upper-left point of arrow in client coords
//   POINT p2  - lower-right corner of arrow in client coords
//
// Return:
//
//   Nothing
//
// History:    Date       Author        Comment
//             3/26/92    Mark Bader    Created
//
//**************************************************************************


void DrawArrow (HDC hDC, POINT p1, POINT p2)
{
   HBRUSH hBr, hBrOld;
   POINT pt[3];

   hBr = CreateSolidBrush(RGB(0,0,0)); // Paint the arrow black
   hBrOld = SelectObject(hDC, hBr);

   // Draw box of arrow
   PatBlt(hDC, p1.x, 
               p1.y + (p2.y - p1.y) / 3, 
               (p2.x - p1.x) / 2,
               (p2.y - p1.y) / 3,
               BLACKNESS);

   // Draw triangle
   pt[0].x = pt[2].x = p1.x + (p2.x - p1.x) / 2;
   pt[0].y = p1.y;
   pt[1].x = p2.x;
   pt[1].y = p1.y + (p2.y - p1.y) / 2;
   pt[2].y = p2.y;
   Polygon(hDC, (LPPOINT)&pt, 3);

   SelectObject(hDC, hBrOld);
   DeleteObject(hBr);

}



//**************************************************************************
//
// OpenBmpFile()
//
// Purpose:
//   
//    Calls Common Dialog GetOpenFile() to get bitmap filename, then
//    loads the specified bitmap file.
//   
// Parameters:
//
//    None.
//
// Return:
//
//    None.
//
// Comments:
//
//    Sets global variables:
// 
//       ghBitmap    -  Global Handle to our bitmap object
//       ghPalette   -  Handle to DIB's palette used for display
//       numColors   -  Number of colors in DIB's color table -- used for
//                      Change() dialog box
//       gszFileName -  File name for current file.  Used for "reloading"
//                      DIB from file (select "Restore Bitmap" menuitem).
//
// History:    Date       Author        Comment
//             3/26/92    Mark Bader    Created
//
//**************************************************************************

void OpenBmpFile() {

 HDIB hDIB;                  // Handle to DIB, used to read DIB from file
 LPBITMAPINFOHEADER lpbi;    // Used to get info from DIB
 OPENFILENAME of;            // Used for comm dialog
 static char szFile[MAXFILENAMELEN];

 of.lStructSize       = sizeof (OPENFILENAME);
 of.hwndOwner         = hwnd;
 of.hInstance         = ghInst;
 of.lpstrFilter       = (LPSTR)"Bitmaps\0*.bmp;*.dib;*.rle\0";
 of.lpstrCustomFilter = NULL;
 of.nMaxCustFilter    = 0L;
 of.nFilterIndex      = 1L;
 of.lpstrFile         = szFile;
 of.nMaxFile          = sizeof (szFile);
 of.lpstrFileTitle    = NULL;
 of.nMaxFileTitle     = 0;
 of.lpstrInitialDir   = NULL;
 of.lpstrTitle        = NULL;
 of.Flags             = OFN_HIDEREADONLY;
 of.nFileOffset       = 0;
 of.nFileExtension    = 0;
 of.lpstrDefExt       = NULL;
 of.lpfnHook          = NULL;
 of.lpTemplateName    = NULL;
 of.lCustData         = 0;

 if (GetOpenFileName(&of)) {
    // User pressed OK, continue on

   hDIB = LoadDIB((LPSTR)szFile);                // Load our DIB

   // If the loading worked, get some information from the DIB, like
   // a palette and the number of colors in the colortable, and 
   // then convert it to a HBITMAP.

   if (hDIB)
   {

    // Clean up old bitmap, if it exists
    if (ghPalette) DeleteObject(ghPalette);
    if (ghBitmap) DeleteObject(ghBitmap);

      ghPalette = CreateDIBPalette(hDIB);
      ghBitmap = DIBToBitmap(hDIB, ghPalette);
      lpbi = (LPBITMAPINFOHEADER)GlobalLock(hDIB);
      numColors = DIBNumColors((LPSTR)lpbi);
      gDibBits = lpbi->biBitCount;
      GlobalUnlock(hDIB);
      DestroyDIB(hDIB);
   }

 }
 
 // Invalidate our rect so we will repaint with new bitmap
 InvalidateRect(hwnd, NULL, TRUE);

 // Save filename in global variable
 _fstrncpy((LPSTR)gszFileName, (LPSTR)szFile, MAXFILENAMELEN);
}




//**************************************************************************
//
// SaveBmpFile()
//
// Purpose:
//   
//    Calls Common Dialog GetSaveFile() to get bitmap filename, then
//    saves the current bitmap to the specified .BMP file.
//   
// Parameters:
//
//    None.
//
// Return:
//
//    None.
//
// Comments:
//
//    Uses the followint global variables to get current bitmap:
// 
//       ghBitmap    -  Global Handle to our bitmap object
//       ghPalette   -  Handle to DIB's palette used for display
//       gszFileName -  File name for current file.  Used for displaying
//                      default choice to user.
//
// History:    Date       Author        Comment
//             3/27/92    Mark Bader    Created
//
//**************************************************************************

void SaveBmpFile() {

 HDIB hDIB;                  // Handle to DIB, used to save DIB to file
 OPENFILENAME of;            // Used for common dialog
 static char szFile[MAXFILENAMELEN];

 // Copy filename from global variable
 _fstrncpy((LPSTR)szFile, (LPSTR)gszFileName, MAXFILENAMELEN);

 of.lStructSize       = sizeof (OPENFILENAME);
 of.hwndOwner         = hwnd;
 of.hInstance         = ghInst;
 of.lpstrFilter       = (LPSTR)"Windows RGB Bitmap\0*.bmp;*.dib;*.rle\0";
 of.lpstrCustomFilter = NULL;
 of.nMaxCustFilter    = 0L;
 of.nFilterIndex      = 1L;
 of.lpstrFile         = szFile;
 of.nMaxFile          = sizeof (szFile);
 of.lpstrFileTitle    = NULL;
 of.nMaxFileTitle     = 0;
 of.lpstrInitialDir   = NULL;
 of.lpstrTitle        = NULL;
 of.Flags             = OFN_HIDEREADONLY | 
                        OFN_NOREADONLYRETURN |
                        OFN_OVERWRITEPROMPT;
 of.nFileOffset       = 0;
 of.nFileExtension    = 0;
 of.lpstrDefExt       = NULL;
 of.lpfnHook          = NULL;
 of.lpTemplateName    = NULL;
 of.lCustData         = 0;

 if (GetSaveFileName(&of)) {
    // User pressed OK, continue on

    hDIB = BitmapToDIB(ghBitmap, ghPalette);

    if (hDIB) {

        if ((SaveDIB(hDIB, (LPSTR)szFile)) != 0) {
            MessageBox(hwnd, "Could not save bitmap file!", "BMUtil", 
                        MB_ICONEXCLAMATION);
            }

        DestroyDIB(hDIB);
        }
    }
}



//**************************************************************************
//
// WaitCursor() and RestoreCursor()
//
// Purpose:
//   
//   Makes cursor the hourglass and restores old cursor
//   
// Comments:
//
//   Uses global variable hCurSave to keep track of previous cursor
//
//
// History:    Date       Author        Comment
//             3/26/92    Mark Bader    Created
//
//**************************************************************************


void WaitCursor() {
    hCurSave = SetCursor(LoadCursor(NULL,IDC_WAIT));
    }

void RestoreCursor() {
    if (hCurSave)
        SetCursor(hCurSave);
    }
