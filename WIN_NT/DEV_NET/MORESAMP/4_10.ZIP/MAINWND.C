//****************************************************************************
// File: mainwnd.c
//
// Purpose: Main overlapped window's message handler
//
// Functions:
//    MainWndProc() - message handler for main overlapped window
//    DoCommands() - called by MainWndProc to handle all WM_COMMAND messages
//
// Development Team:
//
//
// Written by Microsoft Product Support Services, Windows Developer Support
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//****************************************************************************

#include <windows.h>
#include "global.h"
#include "about.h"
#include "drag.h"
#include "mainwnd.h"

// Local function prototypes.
long DoCommands (HWND hWnd,
                 unsigned message,
                 WORD wParam,
                 LONG lParam);

// Local variables
BOOL    bImageDrawn=FALSE;         // Has the image been drawn?
HBITMAP hbmImg=NULL, hbmBk=NULL;   // Handles to image and backdrop


//****************************************************************************
// Function: MainWndProc
//
// Purpose: Message handler for main overlapped window.
//
// Parameters:
//    hWnd    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns: Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           1/27/92                  Created
//           3/9/92     PES           Added WM_CREATE, WM_PAINT,
//                                    WM_LBUTTONDOWN, WM_LBUTTONUP,
//                                    WM_MOUSEMOVE, and WM_CLOSE cases.
//****************************************************************************

long FAR PASCAL MainWndProc (HWND hWnd,
                             unsigned message,
                             WORD wParam,
                             LONG lParam)
{
   static BOOL bSelected=FALSE;

   switch (message)
   {
      // On WM_CREATE, load our resources

      case WM_CREATE:
         // Load image and backdrop bitmaps
         hbmImg = LoadBitmap(ghInst, (LPSTR)"Object");
         hbmBk  = LoadBitmap(ghInst, (LPSTR)"Backdrop");
         break;

      // Dispatch WM_COMMAND messages to our command handler, DoCommands().

      case WM_COMMAND:
         return DoCommands(hWnd, message, wParam, lParam);

      // Process left mouse button down messages

      case WM_LBUTTONDOWN:
         if (bImageDrawn)
         {
            bSelected = IsSelected(LOWORD(lParam), HIWORD(lParam));
            if (bSelected)
               BeginDrag(hWnd, LOWORD(lParam), HIWORD(lParam));
         }
         break;

      // Process mouse move messages

      case WM_MOUSEMOVE:
         if (bSelected)
            Drag(hWnd, LOWORD(lParam), HIWORD(lParam));
         break;

      // Process left mouse button up messages

      case WM_LBUTTONUP:
         if (bSelected)
         {
            EndDrag(hWnd, LOWORD(lParam), HIWORD(lParam));
            bSelected = FALSE;
         }
         break;

      // Do any painting

      case WM_PAINT:
         {
            PAINTSTRUCT ps;

            BeginPaint(hWnd, &ps);

            if (hbmBk)
               DrawBackdrop(ps.hdc, hbmBk);
            if (bImageDrawn)
               DrawImage(ps.hdc);

            EndPaint(hWnd, &ps);
         }
         break;

      // On WM_CLOSE, clean up resources

      case WM_CLOSE:
         // Tidy up
         if (hbmImg)
         {
            if (bImageDrawn)
               DeleteImage();
            else
               DeleteObject(hbmImg);
         }
         if (hbmBk)
            DeleteObject(hbmBk);

         DestroyWindow(hWnd);
         break;

      // On WM_DESTROY, terminate this app by posting a WM_QUIT message.

      case WM_DESTROY:
         PostQuitMessage(0);
         break;


      // We didn't handle, pass to DefWindowProc.

      default:
         return DefWindowProc(hWnd, message, wParam, lParam);
   }


   return (NULL);
}

//****************************************************************************
// Function: DoCommands
//
// Purpose: Called by MainWndProc() to handle all WM_COMMAND messages.
//
// Parameters:
//    hWnd    == Handle to _this_ window.
//    message == Message to process.
//    wParam  == WORD parameter -- depends on message
//    lParam  == LONG parameter -- depends on message
//
// Returns : Depends on message.
//
// Comments:
//
// History:  Date       Author        Reason
//           1/27/92                  Created
//           3/9/92     PES           Added IDM_DRAWBMP case.
//****************************************************************************

long DoCommands (HWND hWnd,
                 unsigned message,
                 WORD wParam,
                 LONG lParam)
{
   switch (wParam)
   {
      // Draw our image on the screen
      case IDM_DRAWBMP:
         {
            HMENU hMenu;

            // Initialize our image info
            bImageDrawn = TRUE;
            InitImageInfo(hWnd, hbmImg, 0, 0);

            // Once drawn, disable and gray this menuitem
            hMenu = GetMenu(hWnd);
            EnableMenuItem(hMenu,
                           IDM_DRAWBMP,
                           MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
            DrawMenuBar(hWnd);
         }
         break;

      // Put up the About box.

      case IDM_ABOUT:
      {
         FARPROC lpDlgProc;

         lpDlgProc = MakeProcInstance(AboutDlg, ghInst);

         DialogBox(ghInst,             // current instance
                   AboutBoxName,       // resource to use 
                   hWnd,               // parent handle   
                   lpDlgProc);         // About() instance address

         FreeProcInstance(lpDlgProc);
         break;
      }


      // User picked File.Exit, terminate this app.

      case IDM_EXIT:
         SendMessage(hWnd, WM_CLOSE, 0, 0L);
         break;


      // Must be some system command -- pass it on to the default
      //  window procedure.

      default:
         return DefWindowProc(hWnd, message, wParam, lParam);
   }

   return (NULL);
}
