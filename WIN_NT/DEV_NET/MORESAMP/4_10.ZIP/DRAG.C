//****************************************************************************
// File: drag.c
//
// Purpose: Contains the bitmap dragging routines.
//
// Functions:
//    InitImageInfo()
//    DrawImage()
//    DeleteImage()
//    DrawBackdrop()
//    IsSelected()
//    BeginDrag()
//    Drag()
//    EndDrag()
//
// Development Team:
//    Patrick Schreiber
//
// Written by Microsoft Product Support Services, Windows Developer Support
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//****************************************************************************

#include <windows.h>
#include "drag.h"

// Image data structure
struct IMAGE
{
   int     bmX;         // Bitmap origin
   int     bmY;         // Bitmap origin
   int     bmWidth;     // Bitmap width
   int     bmHeight;    // Bitmap height
   HBITMAP hbmImage;    // Image's bitmap
   HBITMAP hbmBkg;      // What's behind our image
};

// Global variables to this module
struct IMAGE domino;            // Image's info
int          xPrev=0, yPrev=0;  // Previous mouse position
RECT         rcClient;          // Client area bounding rectangle


//****************************************************************************
// Function: InitImageInfo()
//
// Purpose:  Initialize info for our object.
//
// Parameters:
//    HDC  hdc    - Handle to window dc
//    int  nX     - X-coordinate of object origin
//    int  nY     - Y-coordinate of object origin
//
// Returns:
//    No return value.
//
// Comments:
//
// History:  Date       Author      Reason
//           3/9/92     PES         Created
//
//****************************************************************************

void InitImageInfo (HWND hWnd, HBITMAP hbm, int nX, int nY)
{
   HDC     hdc, hdcMem;       // Handles to window and memory dcs
   HBITMAP hbmNew, hbmPrev;   // Handles to bitmaps
   BITMAP  bm;                // BITMAP data structure
   RECT    rect;              // Invalid rectangle

   // Get window and memory dcs
   hdc    = GetDC(hWnd);
   hdcMem = CreateCompatibleDC(hdc);

   // Get width and height of bitmap
   GetObject(hbm, sizeof(BITMAP), (LPSTR)&bm);

   // Initialize image's info and store rect for updating
   rect.left    = domino.bmX      = nX;
   rect.top     = domino.bmY      = nY;
   rect.right   = domino.bmWidth  = bm.bmWidth;
   rect.bottom  = domino.bmHeight = bm.bmHeight;
   domino.hbmImage = hbm;

   // Create and select a new bitmap to store our background
   hbmNew  = CreateCompatibleBitmap(hdc, bm.bmWidth, bm.bmHeight);
   hbmPrev = SelectObject(hdcMem, hbmNew);

   // Get the background from the screen
   BitBlt(hdcMem, 0, 0, domino.bmWidth, domino.bmHeight,
          hdc, domino.bmX, domino.bmY, SRCCOPY);

   // Tidy up
   SelectObject(hdcMem, hbmPrev);
   DeleteDC(hdcMem);
   ReleaseDC(hWnd, hdc);

   // Store the new background bitmap
   domino.hbmBkg = hbmNew;

   // Update client area where image is
   InvalidateRect(hWnd, &rect, FALSE);
   UpdateWindow(hWnd);
}


//****************************************************************************
// Function: DeleteImage()
//
// Purpose:  Delete image and background bitmaps.
//
// Parameters:
//    None.
//
// Returns:
//    No return value.
//
// Comments:
//
// History:  Date       Author      Reason
//           3/9/92     PES         Created
//
//****************************************************************************

void DeleteImage ()
{
   if (domino.hbmImage)
      DeleteObject(domino.hbmImage);
   if (domino.hbmBkg)
      DeleteObject(domino.hbmBkg);
}


//****************************************************************************
// Function: DrawImage()
//
// Purpose:  Draws image at it's current position.
//
// Parameters:
//    HDC hdc     - Handle to window dc
//
// Returns:
//    No return value.
//
// Comments:
//
// History:  Date       Author      Reason
//           3/9/92     PES         Created
//
//****************************************************************************

void DrawImage (HDC hdc)
{
   HDC     hdcMem;   // Handle to memory dc
   HBITMAP hbmPrev;  // Handle to previous bitmap

   // Create a memory dc and select our object's bitmap into it
   hdcMem  = CreateCompatibleDC(hdc);
   hbmPrev = SelectObject(hdcMem, domino.hbmImage);

   // BitBlt it to the screen
   BitBlt(hdc, domino.bmX, domino.bmY, domino.bmWidth, domino.bmHeight,
          hdcMem, 0, 0, SRCCOPY);

   // Tidy up
   SelectObject(hdcMem, hbmPrev);
   DeleteDC(hdcMem);
}


//****************************************************************************
// Function: DrawBackdrop()
//
// Purpose:  Draws the backdrop bitmap so we know this bitmap dragging
//    technique really works for any background.
//
// Parameters:
//    HDC hdc     - Handle to window dc
//    HBITMAP hbm - Handle to backdrop bitmap
//
// Returns:
//    No return value.
//
// Comments:
//
// History:  Date       Author      Reason
//           3/9/92     PES         Created
//
//****************************************************************************

void DrawBackdrop (HDC hdc, HBITMAP hbm)
{
   HDC     hdcMem;   // Handle to memry dc
   HBITMAP hbmPrev;  // Handle to previous bitmap
   BITMAP  bm;       // BITMAP data structure

   // Get dimensions of backdrop bitmap
   GetObject(hbm, sizeof(BITMAP), (LPSTR)&bm);

   // Create a memory dc and select our backdrop's bitmap into it
   hdcMem  = CreateCompatibleDC(hdc);
   hbmPrev = SelectObject(hdcMem, hbm);

   // BitBlt it to the upper-left part of client area
   BitBlt(hdc, 0, 0, bm.bmWidth, bm.bmHeight,
          hdcMem, 0, 0, SRCCOPY);

   // Tidy up
   SelectObject(hdcMem, hbmPrev);
   DeleteDC(hdcMem);
}


//****************************************************************************
// Function: IsSelected()
//
// Purpose:  Specifies whether our image has been selected for dragging.
//
// Parameters:
//    WORD wX     - X-coordinate of mouse position
//    WORD wY     - Y-coordinate of mouse position
//
// Returns:
//    Returns TRUE if specified point is in object's bounding rectangle,
//    FALSE otherwise.
//
// Comments:
//
// History:  Date       Author      Reason
//           3/9/92     PES         Created
//
//****************************************************************************

BOOL IsSelected (int nX, int nY)
{
   POINT pt;      // POINT data structure
   RECT  rect;    // RECT data structure

   // Current mouse position
   pt.x = nX;
   pt.y = nY;

   // Current bitmap position
   rect.left   = domino.bmX;
   rect.top    = domino.bmY;
   rect.right  = domino.bmX + domino.bmWidth;
   rect.bottom = domino.bmY + domino.bmHeight;

   // Return TRUE if pt in rect of image
   return PtInRect(&rect, pt);
}


//****************************************************************************
// Function: BeginDrag()
//
// Purpose:  Starts the bitmap dragging process.
//
// Parameters:
//    HWND hWnd   - Handle to window
//    int  nX     - X-coordinate of mouse position
//    int  nY     - Y-coordinate of mouse position
//
// Returns:
//    No return value.
//
// Comments:
//
// History:  Date       Author      Reason
//           3/9/92     PES         Created
//
//****************************************************************************

void BeginDrag (HWND hWnd, int nX, int nY)
{
   // Get all mouse messages
   SetCapture(hWnd);

   // Save previous mouse position
   xPrev = nX;
   yPrev = nY;

   // Get client area rect
   GetClientRect(hWnd, &rcClient);
}


//****************************************************************************
// Function: Drag()
//
// Purpose:  Perform the bitmap dragging.
//
// Parameters:
//    HWND hWnd   - Handle to window
//    int  nX     - X-coordinate of mouse position
//    int  nY     - Y-coordinate of mouse position
//
// Returns:
//    No return value.
//
// Comments:
//
// History:  Date       Author      Reason
//           3/9/92     PES         Created
//
//****************************************************************************

void Drag (HWND hWnd, int nX, int nY)
{
   HDC     hdc, hdcMem;                // Handles to dcs
   HDC     hdcNewBkg, hdcOldBkg;       // Handles to dcs
   HBITMAP hbmNew, hbmNPrev;           // Handles to bitmaps
   HBITMAP hbmOPrev, hbmPrev, hbmTemp; // Handles to bitmaps
   int     dx, dy;                     // Mouse delta x and delta y

   // Get window and memory dcs for our BitBlt'ing
   hdc       = GetDC(hWnd);
   hdcMem    = CreateCompatibleDC(hdc);
   hdcNewBkg = CreateCompatibleDC(hdc);
   hdcOldBkg = CreateCompatibleDC(hdc);

   // Create a temp bitmap for our new background
   hbmNew    = CreateCompatibleBitmap(hdc, domino.bmWidth, domino.bmHeight);

   // Select our bitmaps
   hbmPrev  = SelectObject(hdcMem, domino.hbmImage);
   hbmNPrev = SelectObject(hdcNewBkg, hbmNew);
   hbmOPrev = SelectObject(hdcOldBkg, domino.hbmBkg);

   // Calculate delta x and delta y
   dx = xPrev - nX;
   dy = yPrev - nY;

   // Save previous mouse position
   xPrev = nX;
   yPrev = nY;

   // Update image's position
   domino.bmX -= dx;
   domino.bmY -= dy;

   // Copy screen to new background
   BitBlt(hdcNewBkg, 0, 0, domino.bmWidth, domino.bmHeight,
          hdc, domino.bmX, domino.bmY, SRCCOPY);   

   // Replace part of new bkg with old background
   BitBlt(hdcNewBkg, dx, dy, domino.bmWidth, domino.bmHeight,
          hdcOldBkg, 0, 0, SRCCOPY);

   // Copy image to old background
   BitBlt(hdcOldBkg, -dx, -dy, domino.bmWidth, domino.bmHeight,
          hdcMem, 0, 0, SRCCOPY);

   // Copy image to screen
   BitBlt(hdc, domino.bmX, domino.bmY, domino.bmWidth, domino.bmHeight,
          hdcMem, 0, 0, SRCCOPY);

   // Copy old background to screen
   BitBlt(hdc, domino.bmX+dx, domino.bmY+dy, domino.bmWidth, domino.bmHeight,
          hdcOldBkg, 0, 0, SRCCOPY);

   // Tidy up
   SelectObject(hdcMem, hbmPrev);
   SelectObject(hdcNewBkg, hbmNPrev);
   SelectObject(hdcOldBkg, hbmOPrev);

   // Swap old with new background
   hbmTemp    = domino.hbmBkg;
   domino.hbmBkg = hbmNew;
   hbmNew     = hbmTemp;
   DeleteObject(hbmNew);

   // Tidy up some more
   DeleteDC(hdcMem);
   DeleteDC(hdcNewBkg);
   DeleteDC(hdcOldBkg);
   ReleaseDC(hWnd, hdc);
}


//****************************************************************************
// Function: EndDrag()
//
// Purpose:  Ends the bitmap dragging process.
//
// Parameters:
//    HWND hWnd   - Handle to window
//    int  nX     - X-coordinate of mouse position
//    int  nY     - Y-coordinate of mouse position
//
// Returns:
//    No return value.
//
// Comments:
//
// History:  Date       Author      Reason
//           3/9/92     PES         Created
//           3/12/92    PES         Added code to restrict domino to visible
//                                  area of screen.
//
//****************************************************************************

void EndDrag (HWND hWnd, int nX, int nY)
{
   HDC     hdc, hdcMem;                // Handles to dcs
   HDC     hdcNewBkg, hdcOldBkg;       // Handles to dcs
   HBITMAP hbmNew, hbmNPrev;           // Handles to bitmaps
   HBITMAP hbmOPrev, hbmPrev, hbmTemp; // Handles to dcs
   int     dx, dy;                     // Delta x and delta y of mouse
   int     x, y;                       // X and y for position correction

   // Calculate delta x and delta y
   dx = xPrev - nX;
   dy = yPrev - nY;

   // Check if we've moved since last time
   if (dx != 0 || dy != 0)
   {
      // Get window and memory dcs
      hdc       = GetDC(hWnd);
      hdcMem    = CreateCompatibleDC(hdc);
      hdcNewBkg = CreateCompatibleDC(hdc);
      hdcOldBkg = CreateCompatibleDC(hdc);

      // Create a temp bitmap for our new background
      hbmNew    = CreateCompatibleBitmap(hdc, domino.bmWidth, domino.bmHeight);

      // Select our bitmaps
      hbmPrev   = SelectObject(hdcMem, domino.hbmImage);
      hbmNPrev  = SelectObject(hdcNewBkg, hbmNew);
      hbmOPrev  = SelectObject(hdcOldBkg, domino.hbmBkg);

      // Update bitmap's position
      domino.bmX -= dx;
      domino.bmY -= dy;

      // Copy screen to new background
      BitBlt(hdcNewBkg, 0, 0, domino.bmWidth, domino.bmHeight,
             hdc, domino.bmX, domino.bmY, SRCCOPY);   

      // Replace part of new bkg with old background
      BitBlt(hdcNewBkg, dx, dy, domino.bmWidth, domino.bmHeight,
             hdcOldBkg, 0, 0, SRCCOPY);

      // Copy image to old background
      BitBlt(hdcOldBkg, -dx, -dy, domino.bmWidth, domino.bmHeight,
             hdcMem, 0, 0, SRCCOPY);

      // Copy image to screen
      BitBlt(hdc, domino.bmX, domino.bmY, domino.bmWidth, domino.bmHeight,
             hdcMem, 0, 0, SRCCOPY);

      // Copy old background to screen
      BitBlt(hdc,
             domino.bmX + dx,
             domino.bmY + dy,
             domino.bmWidth,
             domino.bmHeight,
             hdcOldBkg, 0, 0, SRCCOPY);

      // Clean up
      SelectObject(hdcMem, hbmPrev);
      SelectObject(hdcNewBkg, hbmNPrev);
      SelectObject(hdcOldBkg, hbmOPrev);

      // Swap old with new background
      hbmTemp       = domino.hbmBkg;
      domino.hbmBkg = hbmNew;
      hbmNew        = hbmTemp;
      DeleteObject(hbmNew);

      // Tidy up
      DeleteDC(hdcMem);
      DeleteDC(hdcNewBkg);
      DeleteDC(hdcOldBkg);
      ReleaseDC(hWnd, hdc);
   }

   // Reset previous mouse position
   xPrev = 0;
   yPrev = 0;

   // Release mouse capture
   ReleaseCapture();

   // Make sure our domino stays completely visible
   if (domino.bmX < 0)
      x = 0;
   else if (domino.bmX + domino.bmWidth > rcClient.right)
      x = rcClient.right - domino.bmWidth;
   else
      x = domino.bmX;

   if (domino.bmY < 0)
      y = 0;
   else if (domino.bmY + domino.bmHeight > rcClient.bottom)
      y = rcClient.bottom - domino.bmHeight;
   else
      y = domino.bmY;

   if (x != domino.bmX || y != domino.bmY)
   {
      xPrev = domino.bmX;
      yPrev = domino.bmY;
      Drag(hWnd, x, y);
      xPrev = yPrev = 0;
   }
}
