//*************************************************************
//  File name: main.c
//
//  Description: 
//      WinMain and the WndProcs
//
//  History:    Date       Author     Comment
//              12/12/91   MSM        Created
//
// Written by Microsoft Product Support Services, Windows Developer Support
//*************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "global.h"
#include <commdlg.h>
#include <memory.h>

HANDLE  ghInst      = NULL;
HWND    ghWndMain   = NULL;

char    szMainMenu[]    = "MainMenu";
char    szMainClass[]   = "MainClass";

//*************************************************************
//
//  WinMain
//
//  Purpose:
//		Entry point for all windows apps
//
//
//  Parameters:
//      HANDLE hInstance
//      HANDLE hPrevInstance
//      LPSTR lpCmdLine
//      int nCmdShow
//      
//
//  Return: (int PASCAL)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//              12/12/91   MSM        Created
//
//*************************************************************

int PASCAL WinMain (HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    MSG msg;

    if (!hPrevInstance && !InitApplication(hInstance))
            return (FALSE);       

    if (!InitInstance(hInstance, nCmdShow))
        return (FALSE);

    while (GetMessage(&msg, NULL, NULL, NULL))
    {
        TranslateMessage(&msg);      
        DispatchMessage(&msg);       
    }
    return (msg.wParam);      

} //*** WinMain

//*************************************************************
//
//  MainWndProc
//
//  Purpose:
//		Main Window procedure
//
//
//  Parameters:
//      HWND hWnd
//      unsigned msg
//      WORD wParam
//      LONG lParam
//      
//
//  Return: (long FAR PASCAL)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//              12/12/91   MSM        Created
//
//*************************************************************

long FAR PASCAL MainWndProc (HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    FARPROC lpProc;

    switch (msg) 
    {
        case WM_WININICHANGE:
            // Repaint on a win.ini change
            InvalidateRect( hWnd, NULL, TRUE );
            UpdateWindow( hWnd );
        break;

        case WM_INITMENUPOPUP:
        {
        // Checks or unchecks all the menu options based on current settings
            if (!HIWORD(lParam))     // Make sure its not the system menu
                if (!LOWORD(lParam)) // Set Params Menu postion
                    InitSetMenu(wParam);
        }
        break;

        case WM_PAINT:
        {
            PAINTSTRUCT ps;
            LOGFONT     lf;
            int         iVal, Mouse[3];
            WORD        wY = 5;
            char        szLeft[40], szRight[40];
            TEXTMETRIC  tm;

// Use a macro to save typing
#define PRINTTEXT(X) lstrcpy( szRight, (LPSTR)X );\
                     TextOut(ps.hdc,4,wY,szLeft,lstrlen(szLeft));\
                     TextOut(ps.hdc,150,wY,szRight,lstrlen(szRight));\
                     wY += tm.tmHeight;


            // Paint all the 'Get' type params
            BeginPaint( hWnd, &ps );
            GetTextMetrics( ps.hdc, &tm );
            
            SystemParametersInfo( SPI_GETBEEP, 0, (LPINT)&iVal, 0 );
            lstrcpy( szLeft, (iVal)?"ON":"OFF" );
            PRINTTEXT("SPI_GETBEEP");

            SystemParametersInfo( SPI_GETBORDER, 0, (LPINT)&iVal, 0 );
            wsprintf( szLeft, "%d", iVal );
            PRINTTEXT("SPI_GETBORDER");

            SystemParametersInfo( SPI_GETFASTTASKSWITCH, 0, (LPINT)&iVal,0);
            lstrcpy( szLeft, (iVal)?"ON":"OFF" );
            PRINTTEXT("SPI_GETFASTTASKSWITCH");

            SystemParametersInfo( SPI_GETGRIDGRANULARITY, 0,(LPINT)&iVal,0);
            wsprintf( szLeft, "%d", iVal );
            PRINTTEXT("SPI_GETGRIDGRANULARITY");

            SystemParametersInfo( SPI_GETICONTITLELOGFONT, 
                    sizeof(LOGFONT),(LPSTR)&lf,0);
            wsprintf( szLeft, "%s", (LPSTR)lf.lfFaceName );
            PRINTTEXT("SPI_GETICONTITLELOGFONT");

            SystemParametersInfo( SPI_GETICONTITLEWRAP, 0, (LPINT)&iVal, 0 );
            lstrcpy( szLeft, (iVal)?"ON":"OFF" );
            PRINTTEXT("SPI_GETICONTITLEWRAP");

            SystemParametersInfo( SPI_GETKEYBOARDDELAY, 0, (LPINT)&iVal, 0 );
            wsprintf( szLeft, "%d", iVal );
            PRINTTEXT("SPI_GETKEYBOARDDELAY");

            SystemParametersInfo( SPI_GETKEYBOARDSPEED, 0, (LPINT)&iVal, 0 );
            wsprintf( szLeft, "%u", iVal );
            PRINTTEXT("SPI_GETKEYBOARDSPEED");

            SystemParametersInfo( SPI_GETMENUDROPALIGNMENT,0,(LPINT)&iVal,0);
            lstrcpy( szLeft, (iVal)?"RIGHT":"LEFT" );
            PRINTTEXT("SPI_GETMENUDROPALIGNMENT");

            SystemParametersInfo( SPI_GETMOUSE,0,(LPINT)Mouse,0);
            wsprintf( szLeft, "%d", Mouse[0] );
            PRINTTEXT("SPI_GETMOUSE (MouseThreshold1)");
            wsprintf( szLeft, "%d", Mouse[1] );
            PRINTTEXT("SPI_GETMOUSE (MouseThreshold2)");
            wsprintf( szLeft, "%d", Mouse[2] );
            PRINTTEXT("SPI_GETMOUSE (MouseSpeed)");

            SystemParametersInfo( SPI_GETSCREENSAVEACTIVE,0,(LPINT)&iVal,0);
            lstrcpy( szLeft, (iVal)?"ON":"OFF" );
            PRINTTEXT("SPI_GETSCREENSAVEACTIVE");

            SystemParametersInfo( SPI_GETSCREENSAVETIMEOUT,0,(LPINT)&iVal,0);
            wsprintf( szLeft, "%d", iVal );
            PRINTTEXT("SPI_GETSCREENSAVETIMEOUT");

            SystemParametersInfo( SPI_ICONHORIZONTALSPACING,0,(LPINT)&iVal,0);
            wsprintf( szLeft, "%d", iVal );
            PRINTTEXT("SPI_ICONHORIZONTALSPACING");

            SystemParametersInfo( SPI_ICONVERTICALSPACING,0,(LPINT)&iVal,0);
            wsprintf( szLeft, "%d", iVal );
            PRINTTEXT("SPI_ICONVERTICALSPACING");

            EndPaint( hWnd, &ps );
            return 0L;
        }
        break;

        case WM_COMMAND: 
            switch ( wParam )
            {
                case IDM_ICONH:     // Horizontal spacing
                {
                    int nH;

                    SystemParametersInfo( SPI_ICONHORIZONTALSPACING,0,
                        (LPINT)&nH,0);
                    if (GetValue( "SPI_ICONHORIZONTALSPACING", &nH ))
                    {
                        SystemParametersInfo(SPI_ICONHORIZONTALSPACING,nH,
                            NULL,SPIF_UPDATEINIFILE|SPIF_SENDWININICHANGE);
                    }
                }
                break;

                case IDM_ICONV:     // Vertical spacing
                {
                    int nH;

                    SystemParametersInfo( SPI_ICONVERTICALSPACING,0,
                        (LPINT)&nH,0);
                    if (GetValue( "SPI_ICONVERTICALSPACING", &nH ))
                    {
                        SystemParametersInfo(SPI_ICONVERTICALSPACING,nH,
                            NULL,SPIF_UPDATEINIFILE|SPIF_SENDWININICHANGE);
                    }
                }
                break;

                case IDM_LANGDRV:
                {
                    OPENFILENAME of;
                    char         szFile[120];

                    memset( &of, 0, sizeof(OPENFILENAME) );

                    szFile[0] = 0;

                    of.lStructSize  = sizeof(OPENFILENAME);
                    of.hwndOwner    = ghWndMain;
                    of.hInstance    = ghInst;
                    of.lpstrFilter  = (LPSTR)"Language Driver\0*.DLL\0\0";
                    of.nFilterIndex = 0;
                    of.lpstrFile    = (LPSTR)szFile;
                    of.nMaxFile     = (DWORD)256;
                    of.lpstrTitle   = (LPSTR)"New Language Driver";
                    of.Flags        = OFN_HIDEREADONLY|OFN_FILEMUSTEXIST;
                    of.lpstrDefExt  = (LPSTR)"DLL";

                    // Use commdlgs to get a filename
                    if( GetOpenFileName( &of ) )
                    {
                        SystemParametersInfo(SPI_LANGDRIVER,0,(LPSTR)szFile,
                            SPIF_UPDATEINIFILE|SPIF_SENDWININICHANGE);
                    }
                }
                break;

                case IDM_SETBEEP:   // System beep setting
                {
                    int iVal;

                    SystemParametersInfo( SPI_GETBEEP, 0, (LPINT)&iVal, 0 );
                    iVal = !iVal;
                    SystemParametersInfo( SPI_SETBEEP, iVal,
                        NULL,SPIF_UPDATEINIFILE|SPIF_SENDWININICHANGE);
                }
                break;

                case IDM_SETBORDER: // Set border width
                {
                    int iVal;

                    SystemParametersInfo( SPI_GETBORDER, 0, (LPINT)&iVal, 0 );
                    if (GetValue( "SPI_SETBORDER", &iVal ))
                    {
                        SystemParametersInfo( SPI_SETBORDER, iVal,
                            NULL,SPIF_UPDATEINIFILE|SPIF_SENDWININICHANGE);
                    }
                }
                break;

                case IDM_SETDWP:    // Set the wallpaper
                {
                    OPENFILENAME of;
                    char         szFile[120];

                    memset( &of, 0, sizeof(OPENFILENAME) );

                    szFile[0] = 0;

                    of.lStructSize  = sizeof(OPENFILENAME);
                    of.hwndOwner    = ghWndMain;
                    of.hInstance    = ghInst;
                    of.lpstrFilter  = (LPSTR)"Wallpaper\0*.BMP\0\0";
                    of.nFilterIndex = 0;
                    of.lpstrFile    = (LPSTR)szFile;
                    of.nMaxFile     = (DWORD)256;
                    of.lpstrTitle   = (LPSTR)"New Wallpaper";
                    of.Flags        = OFN_HIDEREADONLY|OFN_FILEMUSTEXIST;
                    of.lpstrDefExt  = (LPSTR)"BMP";

                    // Use commdlgs to retrieve a BMP name
                    if( GetOpenFileName( &of ) )
                    {
                        SystemParametersInfo(SPI_SETDESKWALLPAPER,0,
                            (LPSTR)szFile,SPIF_UPDATEINIFILE|SPIF_SENDWININICHANGE);
                    }
                }
                break;

                case IDM_SETFASTTASKSW: // New fast task switcher
                {
                    int iVal;

                    SystemParametersInfo(SPI_GETFASTTASKSWITCH,0,(LPINT)&iVal,0);
                    iVal = !iVal;
                    SystemParametersInfo(SPI_SETFASTTASKSWITCH,iVal,
                        NULL,SPIF_UPDATEINIFILE|SPIF_SENDWININICHANGE);
                }
                break;

                case IDM_SETMENUALIGN:  // Menu alignment
                {
                    int iVal;

                    SystemParametersInfo( SPI_GETMENUDROPALIGNMENT,0,(LPINT)&iVal,0);
                    iVal = !iVal;
                    SystemParametersInfo(SPI_SETMENUDROPALIGNMENT,iVal,
                        NULL,SPIF_UPDATEINIFILE|SPIF_SENDWININICHANGE);
                }
                break;

                case IDM_SETGRIDGRAN:   // Grid granularity
                {
                    int iVal;

                    SystemParametersInfo( SPI_GETGRIDGRANULARITY,0,(LPINT)&iVal, 0 );
                    if (GetValue( "SPI_SETGRIDGRANULARITY", &iVal ))
                    {
                        SystemParametersInfo( SPI_SETGRIDGRANULARITY, iVal,
                            NULL,SPIF_UPDATEINIFILE|SPIF_SENDWININICHANGE);
                    }
                }
                break;

                case IDM_SETICONFONT:   // Set Icon title font
                {
                    CHOOSEFONT cf;
                    LOGFONT    lf;

                    SystemParametersInfo( SPI_GETICONTITLELOGFONT, 
                            sizeof(LOGFONT),(LPSTR)&lf,0);

                    cf.lStructSize = (DWORD)sizeof(CHOOSEFONT);
                    cf.hwndOwner = hWnd;
                    cf.hDC = GetDC(hWnd);
                    cf.lpLogFont = (LPLOGFONT)&lf;
                    cf.rgbColors = 0L;
                    cf.Flags = CF_SCREENFONTS|CF_FORCEFONTEXIST|CF_INITTOLOGFONTSTRUCT;
                    cf.lpfnHook = NULL;
                    cf.lpTemplateName = NULL;
                    cf.hInstance      = NULL;

                    // Use commdlg to choose a font
                    if( ChooseFont( &cf ) )
                        SystemParametersInfo( SPI_SETICONTITLELOGFONT, 
                            sizeof(LOGFONT),(LPSTR)&lf,
                            SPIF_UPDATEINIFILE|SPIF_SENDWININICHANGE);

                    ReleaseDC( hWnd, cf.hDC );
                }
                break;

                case IDM_SETKBDELAY:    // Delay before repeating
                {
                    int iVal;

                    SystemParametersInfo( SPI_GETKEYBOARDDELAY,0,(LPINT)&iVal, 0 );
                    if (GetValue( "SPI_SETKEYBOARDDELAY", &iVal ))
                    {
                        SystemParametersInfo( SPI_SETKEYBOARDDELAY, iVal,
                            NULL,SPIF_UPDATEINIFILE|SPIF_SENDWININICHANGE);
                    }
                }
                break;

                case IDM_SETKBSPEED:    // Repeat speed
                {
                    int iVal;

                    SystemParametersInfo( SPI_GETKEYBOARDSPEED,0,(LPINT)&iVal, 0 );
                    if (GetValue( "SPI_SETKEYBOARDSPEED", &iVal ))
                    {
                        SystemParametersInfo( SPI_SETKEYBOARDSPEED, iVal,
                            NULL,SPIF_UPDATEINIFILE|SPIF_SENDWININICHANGE);
                    }
                }
                break;

                case IDM_SETICONWRAP:   // Icon title wrapping
                {
                    int iVal;

                    SystemParametersInfo(SPI_GETICONTITLEWRAP,0,(LPINT)&iVal,0);
                    iVal = !iVal;
                    SystemParametersInfo(SPI_SETICONTITLEWRAP,iVal,
                        NULL,SPIF_UPDATEINIFILE|SPIF_SENDWININICHANGE);
                }
                break;

                case IDM_SETSAVEACTIVE: // Screen saver status
                {
                    int iVal;

                    SystemParametersInfo( SPI_GETSCREENSAVEACTIVE,0,(LPINT)&iVal,0);
                    iVal = !iVal;
                    SystemParametersInfo( SPI_SETSCREENSAVEACTIVE,iVal,
                        NULL,SPIF_UPDATEINIFILE|SPIF_SENDWININICHANGE);
                }
                break;

                case IDM_SETSAVETIMEOUT: // Screen saver time out
                {
                    int iVal;

                    SystemParametersInfo( SPI_GETSCREENSAVETIMEOUT,0,(LPINT)&iVal, 0 );
                    if (GetValue( "SPI_SETSCREENSAVETIMEOUT", &iVal ))
                    {
                        SystemParametersInfo( SPI_SETSCREENSAVETIMEOUT, iVal,
                            NULL,SPIF_UPDATEINIFILE|SPIF_SENDWININICHANGE);
                    }
                }
                break;

                case IDM_ABOUT:
                    // Bring up about box
                    lpProc = MakeProcInstance(About, ghInst);
                    DialogBox(ghInst, "AboutBox", hWnd, lpProc);    
                    FreeProcInstance(lpProc);
                break;
            }
        break;

        case WM_DESTROY:
            PostQuitMessage(0);
        break;
    }
    return DefWindowProc(hWnd, msg, wParam, lParam);

} //*** MainWndProc

//*************************************************************
//
//  InitSetMenu
//
//  Purpose:
//      Initializes the Set Params menu
//
//
//  Parameters:
//      HMENU hMenu
//      
//
//  Return: (VOID)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//               1/ 3/92   MSM        Created
//
//*************************************************************

VOID InitSetMenu (HMENU hMenu)
{
    int iVal;

    // Checks or unchecks all the menu options based on current settings
    
    SystemParametersInfo( SPI_GETBEEP, 0, (LPINT)&iVal, 0 );
    if (iVal)
        CheckMenuItem( hMenu, IDM_SETBEEP, MF_BYCOMMAND|MF_CHECKED);
    else
        CheckMenuItem( hMenu,  IDM_SETBEEP, MF_BYCOMMAND|MF_UNCHECKED);

    SystemParametersInfo( SPI_GETFASTTASKSWITCH, 0, (LPINT)&iVal,0);
    if (iVal)
        CheckMenuItem( hMenu, IDM_SETFASTTASKSW, MF_BYCOMMAND|MF_CHECKED);
    else
        CheckMenuItem( hMenu, IDM_SETFASTTASKSW, MF_BYCOMMAND|MF_UNCHECKED);

    SystemParametersInfo( SPI_GETICONTITLEWRAP, 0, (LPINT)&iVal, 0 );
    if (iVal)
        CheckMenuItem( hMenu, IDM_SETICONWRAP, MF_BYCOMMAND|MF_CHECKED);
    else
        CheckMenuItem( hMenu, IDM_SETICONWRAP, MF_BYCOMMAND|MF_UNCHECKED);

    SystemParametersInfo( SPI_GETMENUDROPALIGNMENT,0,(LPINT)&iVal,0);
    if (iVal)
        CheckMenuItem( hMenu, IDM_SETMENUALIGN, MF_BYCOMMAND|MF_CHECKED);
    else
        CheckMenuItem( hMenu, IDM_SETMENUALIGN, MF_BYCOMMAND|MF_UNCHECKED);

    SystemParametersInfo( SPI_GETSCREENSAVEACTIVE,0,(LPINT)&iVal,0);
    if (iVal)
        CheckMenuItem( hMenu, IDM_SETSAVEACTIVE, MF_BYCOMMAND|MF_CHECKED);
    else
        CheckMenuItem( hMenu, IDM_SETSAVEACTIVE, MF_BYCOMMAND|MF_UNCHECKED);
                                  
} //*** InitMenu

//*************************************************************
//
//  About
//
//  Purpose:
//		the About dialog box procedure
//
//
//  Parameters:
//      HWND hDlg
//      unsigned msg
//      WORD wParam
//      LONG lParam
//      
//
//  Return: (BOOL FAR PASCAL)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//              12/12/91   MSM        Created
//
//*************************************************************

BOOL FAR PASCAL About (HWND hDlg, unsigned msg, WORD wParam, LONG lParam)
{
    switch (msg) 
    {
        case WM_INITDIALOG: 
            return (TRUE);

        case WM_COMMAND:
            if (wParam == IDOK || wParam == IDCANCEL) 
            {
                EndDialog(hDlg, TRUE);         
                return (TRUE);
            }
        break;
    }
    return (FALSE);                  //*** Didn't process a message

} //*** About

//*************************************************************
//
//  GetValue
//
//  Purpose:
//      Retrieves a value from the user
//
//
//  Parameters:
//      LPSTR lpTitle
//      LPINT lpValue
//      
//
//  Return: (BOOL)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//               1/ 3/92   MSM        Created
//
//*************************************************************

BOOL GetValue ( LPSTR lpTitle, LPINT lpValue )
{
    FARPROC lpProc;
    BOOL    fRet;

    // Use near pointers to pass 2 long pointers to the dialog
    lpProc = MakeProcInstance(ValueDlgProc, ghInst);

    // Get a value
    fRet = DialogBoxParam(ghInst, "VALUE_DLG", ghWndMain, lpProc,
        MAKELONG( (WORD)&lpTitle, (WORD)&lpValue ) );
    FreeProcInstance(lpProc);

    return fRet;

} //*** GetValue

//*************************************************************
//
//  ValueDlgProc
//
//  Purpose:
//      Dialog box procedure for the ValueDlg
//
//
//  Parameters:
//      HWND hDlg
//      unsigned msg
//      WORD wParam
//      LONG lParam
//      
//
//  Return: (BOOL FAR PASCAL)
//
//
//  Comments:
//
//
//  History:    Date       Author     Comment
//
//*************************************************************

BOOL FAR PASCAL ValueDlgProc (HWND hDlg, unsigned msg, WORD wParam, LONG lParam)
{
    static LPINT lpValue;

    switch (msg)
    {
        case WM_INITDIALOG:
        //  LOWORD of lParam is near pointer to a far pointer to a character
        //  HIWORD of lParam is near pointer to a far pointer to a integer  

            lpValue = *(LPINT *)(HIWORD(lParam));
            SetDlgItemInt( hDlg, IDE_VALUE, *lpValue, FALSE );
            SetWindowText( hDlg, *(LPSTR *)(LOWORD(lParam)) );
            return TRUE;
        break;

        case WM_COMMAND:
        {
            if (wParam==IDOK)
            {
                BOOL fTrans;
                int  iVal;

                iVal = GetDlgItemInt( hDlg, IDE_VALUE, &fTrans, FALSE );
                if (!fTrans)    // Invalid number
                {
                    MessageBeep(0);
                    return TRUE;
                }
                // Number is OK, return it
                *lpValue = iVal;
                EndDialog( hDlg, TRUE );
                return TRUE;
            }

            if (wParam==IDCANCEL)
            {
                EndDialog( hDlg, FALSE );
                return TRUE;
            }
        }
        break;
    }
    return FALSE;

} //*** ValueDlgProc

//*** EOF: main.c
