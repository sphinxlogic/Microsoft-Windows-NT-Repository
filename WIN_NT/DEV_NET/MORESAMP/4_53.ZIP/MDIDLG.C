//---------------------------------------------------------------------------
//
//  Module:   mdidlg.c
//
//  Purpose:
//     Provides an API to create MDI "modeless dialog boxes".
//
//
//  Description of functions:
//     CreateMDIDialogParam()  -  Creates an MDI child which simulates
//                                a modeless dialog box.  The parameters
//                                are similar to that of the
//                                CreateDialogParam() function.
//
//  Comments:
//     NOTE:  The dialog procedure that is called by the MDI dialog
//            window must destroy itself by sending an WM_MDIDESTROY
//            to the MDI client.  _DO NOT USE_ DestroyWindow() in the
//            dialog procedure!!!
//
//  Development Team:
//     Bryan A. Woodruff
//
//  History:   Date       Author      Comment
//              4/ 5/92   BryanW      Extracted for sample code.
//              4/13/92   BryanW      Bug fixes - fixed WM_ERASEBKGROUND
//                                    processing for non-CTLCOLOR dialogs
//                                    and changed the processing of
//                                    the WM_CLOSE message.
//              4/22/92   BryanW      More bug fixes... now using
//                                    DefDlgProc() for proper focus handling.
//              4/22/92   BryanW      WM_CLOSE now checks for IDCANCEL
//                                    control.
//
//---------------------------------------------------------------------------
//
//  Written by Microsoft Product Support Services, Windows Developer Support.
//
//---------------------------------------------------------------------------
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#ifndef _INC_WINDOWS
#include <windows.h>
#endif

#include <memory.h>

#include "mdidlg.h"
#include "resource.h"

// global definitions

char szMDIDialogClass[] = "MDIDialogClass" ;

//---------------------------------------------------------------------------
//  BOOL FAR PASCAL RegisterMDIDialog( HINSTANCE hInstance )
//
//  Description:
//     Registers the "MDIDialog" class.
//
//  Parameters:
//     HINSTANCE hInstance
//        handle to instance
//
//  History:   Date       Author      Comment
//              4/ 5/92   BryanW      Extracted for sample.
//
//---------------------------------------------------------------------------

BOOL FAR PASCAL RegisterMDIDialog( HINSTANCE hInstance )
{
   WNDCLASS  wc ;

   // register MDIDialog window class

   wc.style =         0 ;
   wc.lpfnWndProc =   MDIDialogProc ;
   wc.cbClsExtra =    0 ;
   wc.cbWndExtra =    DLGWINDOWEXTRA + GWW_MDIDIALOGEXTRABYTES ;
   wc.hInstance =     hInstance ;
   wc.hIcon =         LoadIcon( hInstance, 
                                MAKEINTRESOURCE( DIALOGICON  )) ;
   wc.hCursor =       LoadCursor( NULL, IDC_ARROW ) ;
   wc.hbrBackground = (HBRUSH) (COLOR_WINDOW + 1) ;
   wc.lpszMenuName =  NULL ;
   wc.lpszClassName = szMDIDialogClass ;

   return ( RegisterClass( &wc ) ) ;

} // end of RegisterMDIDialog()

//------------------------------------------------------------------------
//  HWND FAR PASCAL CreateMDIDialogParam( HINSTANCE hInstance,
//                                        LPCSTR lpTemplateName,
//                                        HWND hClientWnd,
//                                        DLGPROC lpDialogProc,
//                                        LPARAM lParam )
//
//  Description:
//     This function creates an MDI child of the "MDIDialog"
//     class.
//
//  Parameters:
//     HINSTANCE  hInstance
//        handle to instance
//
//     LPCSTR lpTemplateName
//        pointer to template name
//
//     HWND hClientWnd
//        handle to MDI client window
//
//     DLGPROC lpDialogProc
//        pointer to dialog procedure
//
//     LPARAM lParam
//        dword parameter passed in WM_INITDIALOG to dialog procedure
//
//  History:   Date       Author      Comment
//              3/24/92   BryanW      Wrote it.
//
//------------------------------------------------------------------------

HWND FAR PASCAL CreateMDIDialogParam( HINSTANCE hInstance,
                                      LPCSTR lpTemplateName,
                                      HWND hClientWnd,
                                      DLGPROC lpDialogProc,
                                      LPARAM lParam )
{

   int                      i ;
   char                     ch ;
   HDC                      hDC ;
   HFONT                    hFont, hOldFont ;
   HGLOBAL                  hRes ;
   HRSRC                    hDlgRes ;
   HWND                     hDlg ;
   LOGFONT                  lf ;
   LPSTR                    lpDlgRes ;
   MDICREATESTRUCT          MDIcs ;
   MDIDIALOGINFO            MDIdi ;
   RECT                     rcWnd ;
   TEXTMETRIC               tm ;
   WORD                     wUnitsX, wUnitsY ;

   // local variables used when parsing the dialog template

   int                      dtX, dtY, dtCX, dtCY ;
   char                     dtMenuName[ MAXLEN_MENUNAME ],
                            dtClassName[ MAXLEN_CLASSNAME ],
                            dtCaptionText[ MAXLEN_CAPTIONTEXT ],
                            dtTypeFace[ MAXLEN_TYPEFACE ] ;
   BYTE                     dtItemCount ;
   DWORD                    dtStyle ;
   WORD                     dtPointSize ;


   hDlgRes = FindResource( hInstance, lpTemplateName, RT_DIALOG ) ;
   hRes = LoadResource( hInstance, hDlgRes ) ;
   lpDlgRes = LockResource( hRes ) ;

   // get style, item count, and initial position, size

   dtStyle = *((DWORD FAR *) lpDlgRes)++ ;
   dtItemCount = *((BYTE FAR *) lpDlgRes)++ ;
   dtX = *((int FAR *) lpDlgRes)++ ;
   dtY = *((int FAR *) lpDlgRes)++ ;
   dtCX = *((int FAR *) lpDlgRes)++ ;
   dtCY = *((int FAR *) lpDlgRes)++ ;

   // get menu name

   i = 0 ;
   while (ch = *lpDlgRes++)
      dtMenuName[ i++ ] = ch ;
   dtMenuName[ i ] = NULL ;

   // get class name

   i = 0 ;
   while (ch = *lpDlgRes++)
      dtClassName[ i++ ] = ch ;
   dtClassName[ i ] = NULL ;

   // get caption text

   i = 0 ;
   while (ch = *lpDlgRes++)
      dtCaptionText[ i++ ] = ch ;
   dtCaptionText[ i ] = NULL ;

   // get point size

   dtPointSize = *((WORD FAR *) lpDlgRes)++ ;

   // get face name

   i = 0 ;
   while (ch = *lpDlgRes++)
      dtTypeFace[ i++ ] = ch ;
   dtTypeFace[ i ] = NULL ;

   hDC = GetDC( NULL ) ;
   _fmemset( &lf, 0, sizeof( LOGFONT ) ) ;
   lstrcpy( lf.lfFaceName, dtTypeFace ) ;
   lf.lfHeight = -MulDiv( dtPointSize,
                          GetDeviceCaps( hDC, LOGPIXELSY ),
                          72 )  ;
   lf.lfWeight = FW_BOLD ;
   hFont = CreateFontIndirect( &lf ) ;
   hOldFont = SelectObject( hDC, hFont ) ;
   GetTextMetrics( hDC, &tm ) ;
   wUnitsX = LOWORD( GetTextExtent( hDC, WIDTHSTRING, 52 ) ) / 52 ;
   wUnitsY = tm.tmHeight ;
   SelectObject( hDC, hOldFont ) ;
   ReleaseDC( NULL, hDC ) ;

   rcWnd.left = 0 ;
   rcWnd.top = 0 ;
   rcWnd.right = DLGTOCLIENTX( dtCX, wUnitsX ) ;
   rcWnd.bottom = DLGTOCLIENTY( dtCY, wUnitsY ) ;
   AdjustWindowRect( &rcWnd, dtStyle, FALSE ) ;

   // create the MDI dialog window

   MDIdi.hFont =        hFont ;
   MDIdi.lpDialogProc = lpDialogProc ;
   MDIdi.lpDlgItems =   lpDlgRes ;
   MDIdi.wUnitsX =      wUnitsX ;
   MDIdi.wUnitsY =      wUnitsY ;
   MDIdi.dtItemCount =  (int) dtItemCount ;
   MDIdi.lParam =       lParam ;

   MDIcs.szClass =      szMDIDialogClass ;
   MDIcs.szTitle =      dtCaptionText ;
   MDIcs.hOwner =       hInstance ;
   MDIcs.x =            CW_USEDEFAULT ;
   MDIcs.y =            CW_USEDEFAULT ;
   MDIcs.cx =           rcWnd.right - rcWnd.left ;
   MDIcs.cy =           rcWnd.bottom - rcWnd.top ;
   MDIcs.style =        dtStyle ;
   MDIcs.lParam =       (LPARAM) (LPMDIDIALOGINFO) &MDIdi ;

   hDlg =
      (HWND) LOWORD( SendMessage( hClientWnd, WM_MDICREATE, 0,
                                  (LPARAM) (LPMDICREATESTRUCT) &MDIcs ) ) ;

   UnlockResource( hRes ) ;
   FreeResource( hRes ) ;

   return ( hDlg ) ;

} // end of CreateMDIDialogParam()

//------------------------------------------------------------------------
//  BOOL NEAR CreateMDIDialogChildren( HWND hDlg, LPSTR lpDlgItems,
//                                     int dtItemCount, HFONT hFont,
//                                     WORD wUnitsX, WORD wUnitsY )
//
//  Description:
//     This function is used during the WM_CREATE of the MDIDialogProc().
//
//  Parameters:
//     HWND hDlg
//        handle to MDI dialog window
//
//     LPSTR lpDlgItems
//        pointer to dialog items
//
//     int dtItemCount
//        count of dialog items
//
//     HFONT hFont
//        handle to dialog font
//
//     WORD wUnitsX
//        size of dialog units (X)
//
//     WORD wUnitsY
//        size of dialog units (Y)
//
//  History:   Date       Author      Comment
//              3/25/92   BryanW      Wrote it.
//
//------------------------------------------------------------------------

BOOL NEAR CreateMDIDialogChildren( HWND hDlg, LPSTR lpDlgItems,
                                   int dtItemCount, HFONT hFont,
                                   WORD wUnitsX, WORD wUnitsY )
{
   int      i, nCtl ;
   char     ch ;
   HWND     hCtl ;

   // local vars used when parsing the dialog template

   int      dtID, dtX, dtY, dtCX, dtCY ;
   char     dtClassName[ MAXLEN_CLASSNAME ],
            dtCaptionText[ MAXLEN_CAPTIONTEXT ] ;
   BYTE     dtInfoSize ;
   DWORD    dtStyle ;

   for (nCtl = 0; nCtl < dtItemCount; nCtl++)
   {
      dtX = *((int FAR *) lpDlgItems)++ ;
      dtY = *((int FAR *) lpDlgItems)++ ;
      dtCX = *((int FAR *) lpDlgItems)++ ;
      dtCY = *((int FAR *) lpDlgItems)++ ;
      dtID = *((int FAR *) lpDlgItems)++ ;
      dtStyle = *((DWORD FAR *) lpDlgItems)++ ;

      // get class name

      i = 0 ;
      while (ch = *lpDlgItems++)
      {
         dtClassName[ i++ ] = ch ;
         if (ch & 0x80)
            break ;
      }
      if (ch & 0x80)
      {
         switch (ch & 0x7F)
         {
            case 0:
               lstrcpy( dtClassName, "BUTTON" ) ;
               break ;

            case 1:
               lstrcpy( dtClassName, "EDIT" ) ;
               break ;

            case 2:
               lstrcpy( dtClassName, "STATIC" ) ;
               break ;

            case 3:
               lstrcpy( dtClassName, "LISTBOX" ) ;
               break ;

            case 4:
               lstrcpy( dtClassName, "SCROLLBAR" ) ;
               break ;

            case 5:
               lstrcpy( dtClassName, "COMBOBOX" ) ;
               break ;
         }
      }
      else
         dtClassName[ i ] = NULL ;

      // get caption text

      i = 0 ;
      while (ch = *lpDlgItems++)
         dtCaptionText[ i++ ] = ch ;
      dtCaptionText[ i ] = NULL ;

      dtInfoSize = *((BYTE FAR *) lpDlgItems)++ ;

      hCtl = CreateWindow( dtClassName, dtCaptionText, dtStyle,
                           DLGTOCLIENTX( dtX, wUnitsX ),
                           DLGTOCLIENTY( dtY, wUnitsY ),
                           DLGTOCLIENTX( dtCX, wUnitsX ),
                           DLGTOCLIENTY( dtCY, wUnitsY ),
                           hDlg, (HMENU) dtID, GETHINST( hDlg ),
                           (dtInfoSize == 0) ? NULL : (VOID FAR *) lpDlgItems ) ;
      SendMessage( hCtl, WM_SETFONT, (WPARAM) hFont, (LPARAM) FALSE ) ;

      // bounce over child info structure

      lpDlgItems += dtInfoSize ;
   }
   return ( TRUE ) ;

} // end of CreateMDIDialogChildren()

//------------------------------------------------------------------------
//  LRESULT FAR PASCAL MDIDialogProc( HWND hDlg, UINT uMsg,
//                                    WPARAM wParam, LPARAM lParam )
//
//  Description:
//     This is the MDI dialog procedure.
//
//  Parameters:
//     HWND hDlg
//        handle to MDI dialog window
//
//     UINT uMsg
//        current message
//
//     WPARAM wParam
//        word parameter
//
//     LPARAM lParam
//        dword parameter
//
//  Comments:
//     NOTE:  This function should be updated to account for
//            menus associated with a given MDI dialog window.
//            Code has been commented out where notifications
//            are sent to the MDI frame window to change the
//            menu - this should be updated to account for your
//            menu structure.
//
//  History:   Date       Author      Comment
//              3/22/92   BryanW      Wrote it.
//
//------------------------------------------------------------------------

LRESULT FAR PASCAL MDIDialogProc( HWND hDlg, UINT uMsg,
                                  WPARAM wParam, LPARAM lParam )
{
   switch (uMsg)
   {
      case WM_CREATE:
      {
         LPMDIDIALOGINFO  lpMDIdi ;

         lParam = (LPARAM) ((LPCREATESTRUCT) lParam) -> lpCreateParams ;
         lpMDIdi =
            (LPMDIDIALOGINFO) ((LPMDICREATESTRUCT) lParam) -> lParam ;

         SetWindowLong( hDlg, DLGWINDOWEXTRA + GWL_MDIDIALOGPROC,
                        (LONG) lpMDIdi -> lpDialogProc ) ;
         SetWindowWord( hDlg, DLGWINDOWEXTRA + GWW_MDIDIALOGFONT,
                        (WORD) lpMDIdi -> hFont ) ;

         // send font notification

         lpMDIdi -> lpDialogProc( hDlg, WM_SETFONT,
                                  (WPARAM) lpMDIdi -> hFont,
                                  (LPARAM) FALSE ) ;

         // create dialog children

         CreateMDIDialogChildren( hDlg, lpMDIdi -> lpDlgItems,
                                  lpMDIdi -> dtItemCount,
                                  lpMDIdi -> hFont,
                                  lpMDIdi -> wUnitsX,
                                  lpMDIdi -> wUnitsY ) ;

         // send WM_INITDIALOG notification

         lpMDIdi -> lpDialogProc( hDlg, WM_INITDIALOG, NULL,
                                  lpMDIdi -> lParam ) ;

         return ( 0 ) ;
      }

      case WM_MDIACTIVATE:
         if (TRUE == wParam)
         {
//          PostMessage( hFrameWnd, WM_COMMAND, IDM_MENUCHANGE,
//                       MAKELONG( hMenuDlg, hMenuDlgWindow ) ) ;
            if (!IsIconic( hDlg ))
               SetFocus( hDlg ) ;
         }
//       if (FALSE == wParam)
//            PostMessage( hFrameWnd, WM_COMMAND, IDM_MENUCHANGE,
//                         MAKELONG( hMenuInit, hMenuInitWindow ) ) ;
         return 0 ;

      case WM_ERASEBKGND:
      {
         DLGPROC          lpDialogProc ;
         HBRUSH           hbrBG, hbrOld ;
         LRESULT          lResult ;

         lpDialogProc = (DLGPROC) GetWindowLong( hDlg, DLGWINDOWEXTRA +
                                                       GWL_MDIDIALOGPROC ) ;
         if (NULL != lpDialogProc)
         {
            hbrBG =
               (HBRUSH) lpDialogProc( hDlg, WM_CTLCOLOR, wParam,
                                      MAKELONG( hDlg, CTLCOLOR_DLG ) ) ;
            if (NULL != hbrBG)
            {
               hbrOld = (HBRUSH) SetClassWord( hDlg, GCW_HBRBACKGROUND,
                                               (WORD) hbrBG ) ;
               lResult = DefWindowProc( hDlg, uMsg, wParam, lParam ) ;
               SetClassWord( hDlg, GCW_HBRBACKGROUND, (WORD) hbrOld ) ;
            }
            else
               lResult = DefWindowProc( hDlg, uMsg, wParam, lParam ) ;

            return ( (LRESULT) lResult ) ;
         }
         else
            return ( DefWindowProc( hDlg, uMsg, wParam, lParam ) ) ;
      }
      break ;


      case WM_CLOSE:
      {
         DLGPROC  lpDialogProc ;
         HWND     hCtlCancel ;

         lpDialogProc = (DLGPROC) GetWindowLong( hDlg, DLGWINDOWEXTRA +
                                                       GWL_MDIDIALOGPROC ) ;
         hCtlCancel = GetDlgItem( hDlg, IDCANCEL ) ;
         if (hCtlCancel)
         {
            if (IsWindowEnabled( hCtlCancel ))
            {
               // just force a cancel to the dialog proc
      
               SendMessage( GetParent( hDlg ), WM_MDIRESTORE,
                            (WPARAM) hDlg, 0L ) ;
               if (NULL != lpDialogProc)
                  lpDialogProc( hDlg, WM_COMMAND, (WPARAM) IDCANCEL,
                                (LPARAM) NULL ) ;
            }
            return ( NULL ) ;
         }
         else
            return ( DefMDIChildProc( hDlg, uMsg, wParam, lParam ) ) ;
      }

      case WM_SYSCOMMAND:
      case WM_MENUCHAR:
      case WM_SETTEXT:
      case WM_CHILDACTIVATE:
         return ( DefMDIChildProc( hDlg, uMsg, wParam, lParam ) ) ;

      case WM_GETMINMAXINFO:
      case WM_SIZE:
      case WM_MOVE:
      {
         DLGPROC  lpDialogProc ;
         LRESULT  lResult ;

         lResult = DefMDIChildProc( hDlg, uMsg, wParam, lParam ) ;
         lpDialogProc = (DLGPROC) GetWindowLong( hDlg, DLGWINDOWEXTRA +
                                                       GWL_MDIDIALOGPROC ) ;
         if (lpDialogProc != NULL)
            lpDialogProc( hDlg, uMsg, wParam, lParam ) ;
         return ( lResult ) ;
      }

      case WM_NCDESTROY:
      {
         DLGPROC  lpDialogProc ;
         HFONT  hFont ;


         lpDialogProc = (DLGPROC) GetWindowLong( hDlg, DLGWINDOWEXTRA +
                                                       GWL_MDIDIALOGPROC ) ;
         if (NULL != lpDialogProc)
            lpDialogProc( hDlg, uMsg, wParam, lParam ) ;
         hFont =
            (HFONT) GetWindowWord( hDlg, DLGWINDOWEXTRA + GWW_MDIDIALOGFONT ) ;
         DeleteObject( hFont ) ;
         return ( DefDlgProc( hDlg, uMsg, wParam, lParam ) ) ;
      }

      default:
      {
         BOOL     fResult = FALSE ;
         DLGPROC  lpDialogProc ;

         lpDialogProc = (DLGPROC) GetWindowLong( hDlg, DLGWINDOWEXTRA +
                                                       GWL_MDIDIALOGPROC ) ;
         if (lpDialogProc != NULL)
         {
            fResult = lpDialogProc( hDlg, uMsg, wParam, lParam ) ;
            if (!fResult)
               return ( DefDlgProc( hDlg, uMsg, wParam, lParam ) ) ;
            else
               return ( (LRESULT) fResult ) ;
         }
         else
            return( DefDlgProc( hDlg, uMsg, wParam, lParam ) ) ;
      }
   }
   return ( DefMDIChildProc( hDlg, uMsg, wParam, lParam ) ) ;
                                        
} // end of MDIDialogProc()

//---------------------------------------------------------------------------
//  End of File: mdidlg.c
//---------------------------------------------------------------------------

