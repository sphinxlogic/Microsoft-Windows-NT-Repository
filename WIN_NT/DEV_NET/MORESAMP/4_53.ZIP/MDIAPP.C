//---------------------------------------------------------------------------
//
//  Module:   mdiapp.c
//
//  Purpose:
//     Simple MDI interface to demonstrate MDI dialog functions.
//
//
//  Development Team:
//     Bryan A. Woodruff
//
//  History:   Date       Author      Comment
//              4/13/92   BryanW      Wrote it.
//
//---------------------------------------------------------------------------
//
//  Written by Microsoft Product Support Service, Windows Developer Support.
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
//---------------------------------------------------------------------------
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1992.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#define GLOBALDEFS    // global definitions in this module

#include "mdiapp.h"

//------------------------------------------------------------------------
//  int FAR PASCAL WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance,
//                          LPSTR lpCmdLine, int nCmdShow )
//
//  Description:
//     Main entry point.
//
//  Parameters:
//     Same as all standard WinMain()'s.
//
//
//  History:   Date       Author      Comment
//              4/13/92   BryanW      Wrote it.
//
//------------------------------------------------------------------------

int FAR PASCAL WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance,
                        LPSTR lpCmdLine, int nCmdShow )
{
   int   i ;
   BOOL  fTranslated ;
   MSG   msg ;

   if (!hPrevInstance)
      if (!InitApplication( hInstance ))
         return ( FALSE ) ;

   if (!InitInstance( hInstance, lpCmdLine, nCmdShow ))
      return ( FALSE ) ;

   while (GetMessage( &msg, NULL, NULL, NULL ))
   {
      fTranslated = FALSE ;
      if (!(fTranslated = TranslateMDISysAccel( hMDIClient, &msg )))
      {
         for (i = 0; i < MAXLEN_DIALOGS && !fTranslated; i++)
         {
            if (NULL != ModelessDialogs[ i ].hDlg)
               fTranslated = (IsWindow( ModelessDialogs[ i ].hDlg ) &&
                              IsDialogMessage( ModelessDialogs[ i ].hDlg,
                                             &msg )) ;
         }
      }
      if (!fTranslated)
      {
         TranslateMessage( &msg ) ;
         DispatchMessage( &msg ) ;
      }
   }
   return ( msg.wParam ) ;

} // end of WinMain()

//------------------------------------------------------------------------
//  BOOL NEAR InitApplication( HINSTANCE hInstance )
//
//  Description:
//     Performs application (first time) initialization.
//
//  Parameters:
//     HINSTANCE hInstance
//        handle to instance   
//
//  History:   Date       Author      Comment
//              4/13/92   BryanW      Wrote it.
//
//------------------------------------------------------------------------

BOOL NEAR InitApplication( HINSTANCE hInstance )
{
   WNDCLASS  wc ;

   wc.style     =      0 ;
   wc.lpfnWndProc =    MDIFrameWndProc ;
   wc.cbClsExtra =     0 ;
   wc.cbWndExtra =     0 ;
   wc.hInstance =      hInstance ;
   wc.hIcon =          LoadIcon( hInstance, MAKEINTRESOURCE( FRAMEICON ) ) ;
   wc.hCursor =        LoadCursor( NULL, IDC_ARROW ) ;
   wc.hbrBackground =  (HBRUSH) (COLOR_APPWORKSPACE + 1) ;
   wc.lpszMenuName =   MAKEINTRESOURCE( MDIMENU ) ;
   wc.lpszClassName =  "Sample:MDIFrame" ;
 
   RegisterClass( &wc ) ;

   RegisterMDIDialog( hInstance ) ;

   return ( TRUE ) ;

} // end of InitApplication()

//------------------------------------------------------------------------
//  BOOL NEAR InitInstance( HINSTANCE hInstance, LPSTR lpCmdLine,
//                          int nCmdShow )
//
//  Description:
//     Performs instance specific initialization.
//
//  Parameters:
//     HINSTANCE hInstance
//        handle to instance
//
//     LPSTR lpCmdLine
//        pointer to command line buffer
//
//     int nCmdShow
//        how do we display the window?
//
//  History:   Date       Author      Comment
//              4/13/92   BryanW      Wrote it.
//
//------------------------------------------------------------------------

BOOL NEAR InitInstance( HINSTANCE hInstance, LPSTR lpCmdLine,
                        int nCmdShow )
{
   int  i ;

   for (i = 0; i < MAXLEN_DIALOGS; i++)
   {
      ModelessDialogs[ i ].hDlg = NULL ;
      ModelessDialogs[ i ].lpDialogProc = NULL ;
   }

   hMDIFrame = CreateWindow( "Sample:MDIFrame", "MDI Dialog Sample",
                             WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
                             CW_USEDEFAULT, CW_USEDEFAULT,
                             CW_USEDEFAULT, CW_USEDEFAULT,
                             NULL, NULL, hInstance, NULL ) ;
   if (hMDIFrame && hMDIClient)
   {
      ShowWindow( hMDIFrame, nCmdShow ) ;
      UpdateWindow( hMDIFrame ) ;
      return ( TRUE ) ;
   }
   return ( FALSE ) ;

} // end of InitInstance()

//------------------------------------------------------------------------
//  BOOL NEAR AddModelessDialog( HWND hDlg, DLGPROC lpDialogProc )
//
//  Description:
//     Adds a modeless dialog box to the dialog list.
//
//  Parameters:
//     HWND hDlg
//        handle to "dialog" window.
//
//     DLGPROC lpDialogProc
//        pointer to dialog procedure (MPI'd)
//
//  History:   Date       Author      Comment
//              4/13/92   BryanW      Wrote it.
//
//------------------------------------------------------------------------

BOOL NEAR AddModelessDialog( HWND hDlg, DLGPROC lpDialogProc )
{
   int  i ;

   for (i = 0; i < MAXLEN_DIALOGS; i++)
   {
      if (NULL == ModelessDialogs[ i ].hDlg)
      {
         ModelessDialogs[ i ].hDlg = hDlg ;
         ModelessDialogs[ i ].lpDialogProc = lpDialogProc ;
         return ( TRUE ) ;
      }
   }
   return ( FALSE ) ;

} // end of AddModelessDialog()

//------------------------------------------------------------------------
//  DLGPROC NEAR RemoveModelessDialog( HWND hDlg )
//
//  Description:
//     Removes a modeless dialog box from the dialog list and 
//     returns the associated dialog procedure pointer.
//
//  Parameters:
//     HWND hDlg
//        handle to "dialog box"
//
//  History:   Date       Author      Comment
//              4/13/92   BryanW      Wrote it.
//
//------------------------------------------------------------------------

DLGPROC NEAR RemoveModelessDialog( HWND hDlg )
{
   int      i ;         
   DLGPROC  lpDialogProc ;

   for (i = 0; i < MAXLEN_DIALOGS; i++)
   {
      if (hDlg == ModelessDialogs[ i ].hDlg)
      {
         ModelessDialogs[ i ].hDlg = NULL ;
         lpDialogProc = ModelessDialogs[ i ].lpDialogProc ;
         ModelessDialogs[ i ].lpDialogProc = NULL ;

         return ( lpDialogProc ) ;
      }
   }
   return ( NULL ) ;

} // end of RemoveModelessDialog()

//------------------------------------------------------------------------
//  LRESULT FAR PASCAL MDIFrameWndProc( HWND hWnd, UINT uMsg,
//                                      WPARAM wParam, LPARAM lParam )
//
//  Description:
//     This is the MDI Frame Window.
//
//  Parameters:
//     HWND hWnd
//        handle to frame window
//
//     UINT uMsg
//        message
//
//     WPARAM wParam
//        word parameter
//
//     LPARAM lParam
//        long (dword) parameter
//
//  History:   Date       Author      Comment
//              4/13/92   BryanW      Wrote it.
//
//------------------------------------------------------------------------

LRESULT FAR PASCAL MDIFrameWndProc( HWND hWnd, UINT uMsg,
                                    WPARAM wParam, LPARAM lParam )
{
   switch (uMsg)
   {
      case WM_CREATE:
      {
         CLIENTCREATESTRUCT  ccs ;

         ccs.hWindowMenu = GetSubMenu( GetMenu( hWnd ), WINDOWMENU ) ;
         ccs.idFirstChild = IDM_WINDOWCHILD ;

         hMDIClient = CreateWindow( "MDICLIENT", NULL,
                                    WS_CHILD | WS_CLIPCHILDREN,
                                    0, 0, 0, 0, hWnd, 0,
                                    GETHINST( hWnd ), (LPSTR) &ccs ) ;
         ShowWindow( hMDIClient, SW_SHOW ) ;
      }
      break ;

      case WM_COMMAND:
      {
         switch (wParam)
         {
            case SAMPLEDLG:
            {
               switch (HIWORD( lParam ))
               {
                  case DN_ENDDIALOG:   
                  {
                     DLGPROC  lpDialogProc ;

                     lpDialogProc = RemoveModelessDialog( LOWORD( lParam ) ) ;
                     if (lpDialogProc)
                        FreeProcInstance( (FARPROC) lpDialogProc ) ;
                  }
                  break ;
               }
            }
            break ;

            case IDM_FILENEW:
            {
               HWND     hMDIDialog ;
               DLGPROC  lpDialogProc ;

               lpDialogProc = (DLGPROC) MakeProcInstance( DialogProc,
                                                          GETHINST( hWnd ) ) ;
               hMDIDialog =
                  CreateMDIDialogParam( GETHINST( hWnd ),
                                        MAKEINTRESOURCE( SAMPLEDLG ),
                                        hMDIClient, lpDialogProc,
                                        MAKELONG( hWnd, NULL ) ) ;
               AddModelessDialog( hMDIDialog, lpDialogProc ) ;
            }
            break ;

            case IDM_FILEEXIT:
               PostMessage( hWnd, WM_CLOSE, NULL, NULL ) ;
               break;

            case IDM_WINDOWTILE:
               SendMessage( hMDIClient, WM_MDITILE, 0, 0L ) ;
               break ;

            case IDM_WINDOWCASCADE:
               SendMessage( hMDIClient, WM_MDICASCADE, 0, 0L ) ;
               break ;

            case IDM_WINDOWICONS:
               SendMessage( hMDIClient, WM_MDIICONARRANGE, 0, 0L ) ;
               break ;

            case IDM_WINDOWCLOSEALL:
               CloseAllChildren();
               break ;

            default:
               return ( DefFrameProc( hWnd, hMDIClient, WM_COMMAND,
                                      wParam, lParam ) ) ;
         }
      }
      break ;

      case WM_CLOSE:
         DestroyWindow( hWnd ) ;
         break ;

      case WM_DESTROY:
         PostQuitMessage( 0 ) ;
         break ;

      default:
         return ( DefFrameProc( hWnd, hMDIClient, uMsg, wParam, lParam ) ) ;
   }

} // end of MDIFrameWndProc()

//------------------------------------------------------------------------
//  VOID NEAR CloseAllChildren( VOID )
//
//  Description:
//     Closes all MDI children.
//
//  Parameters:
//     NONE.
//
//  History:   Date       Author      Comment
//              4/13/92   BryanW      Wrote it.
//
//------------------------------------------------------------------------

VOID NEAR CloseAllChildren( VOID )
{
   HWND  hWndTemp ;

   ShowWindow( hMDIClient, SW_HIDE ) ;

   while (hWndTemp = GetWindow( hMDIClient, GW_CHILD ))
   {
      while (hWndTemp && GetWindow( hWndTemp, GW_OWNER ))
         hWndTemp = GetWindow( hWndTemp, GW_HWNDNEXT ) ;
      if (hWndTemp)
         SendMessage( hMDIClient, WM_MDIDESTROY, (WPARAM) hWndTemp, NULL ) ;
      else
         break ;
   }

   ShowWindow( hMDIClient, SW_SHOW ) ;

} // end of CloseAllChildren()

//------------------------------------------------------------------------
//  BOOL FAR PASCAL DialogProc( HWND hDlg, UINT uMsg,
//                              WPARAM wParam, LPARAM lParam )
//
//  Description:
//     A simple dialog procedure used in demonstration.
//
//  Parameters:
//     HWND hDlg
//        handle to dialog box
//
//     UINT uMsg
//        message
//
//     WPARAM wParam
//        word parameter
//
//     LPARAM lParam
//        long (dword) parameter
//
//  History:   Date       Author      Comment
//              4/13/92   BryanW      Wrote it.
//
//------------------------------------------------------------------------

BOOL FAR PASCAL DialogProc( HWND hDlg, UINT uMsg,
                            WPARAM wParam, LPARAM lParam )
{
   switch (uMsg)
   {
      case WM_INITDIALOG:
         SET_PROP( hDlg, ATOM_NOTIFYWND, LOWORD( lParam ) ) ;
         break ;

      case WM_COMMAND:
         switch (wParam)
         {
            case IDOK:
            case IDCANCEL:
            {
               HWND  hNotifyWnd ;

               // notify "notification" window that we are shutting down

               hNotifyWnd = (HWND) GET_PROP( hDlg, ATOM_NOTIFYWND ) ;
               PostMessage( hNotifyWnd, WM_COMMAND, SAMPLEDLG,
                            MAKELONG( hDlg, DN_ENDDIALOG ) ) ;

               // NOTE:  we must destroy the MDI dialog
               // child with WM_MDIDESTROY!!!

               SendMessage( hMDIClient, WM_MDIDESTROY, (WPARAM) hDlg, NULL ) ;
               return ( TRUE ) ;
            }
         }
         break ;

      case WM_DESTROY:
         REMOVE_PROP( hDlg, ATOM_NOTIFYWND ) ;
         break ;
   }
   return ( FALSE ) ;

} // end of DialogProc()

//---------------------------------------------------------------------------
//  End of File: mdiapp.c
//---------------------------------------------------------------------------

