//***************************************************************************
//
// File name: Mainwnd.c
//
// This source file provides the message function for grid.EXE.  It is
// designed be a flexable way to determine exactly where the grid are
// in gestures.
//
// Description of functions:
//
//  Function: MainWndProc - Process messages for grid.exe.  See individual
//	      messages below.
//
//  Function: Node - To return the index into the cell array where the cell
//	      information is for that cell
//
//  Function: BuildBoundingRect - To build bounding rectangle for recognition
//
//  Function: CurrentCell - To calculate the cell that the cursor is in.
//
//  Function: OnColumnBoundry - To determine if the mouse cursor is on a
//	      vertical cell Boundry.
//
//  Function: OnRowBoundry - To determine if the mouse cursor is on a cell
//	      row boundry.
//
//  Function: DrawGrid - To draw the grid on the screen
//
//  Function: DisplayResults - Blindly displays the contents of every cell.
//
//  Function: ErrorBox(WORD) - To display Error Messages
//
// Developed By: David Flenniken, Microsoft Windows Developer Support
//
//**********************************************************************
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
#include "windows.h"
#include "penwin.h"
#include "Globals.h"
#include "mainwnd.h"

//**************************************************************************
//
//  Function: MainWndProc
//
//  Purpose:  Process messages for grid.exe.  See individual messages
//	      below.
//
//  Returns:  Standard return.
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      12/20/91	David Flenniken  Created
//
//*************************************************************************
long FAR PASCAL MainWndProc(HWND hWnd, UINT message, WPARAM wParam,
			    LPARAM lParam)
{
    switch ( message )
	{

	case WM_SETCURSOR:
	    if( !(gwStateOfApp & STATE_CRITICAL) )
	    {
	       switch(gwStateOfApp & (STATE_CRITICAL | STATE_ROW | STATE_COLUMN | STATE_SYSMENU))
	       {
		  case (STATE_ROW | STATE_COLUMN):
		     ghGlobalCursor=ghJunction;
		     break;
		  case STATE_ROW:
		     ghGlobalCursor=ghUpDown;
		     break;
		  case STATE_COLUMN:
		     ghGlobalCursor=ghLeftRight;
		     break;
		  case STATE_SYSMENU:
		     ghGlobalCursor=ghArrow;
		     break;
		  default:
		     // get the cell state and set cursor from that...
		     if(  glpCells[Node(grc.dwAppParam)].wState & STATE_TEXT )
			ghGlobalCursor=ghCellFull;
		     else
			ghGlobalCursor=ghPen;
		     break;
	       }
	    }
	    else
	       if(gwStateOfApp & STATE_ALTSELECT)
		  ghGlobalCursor=ghAltSelect;

	    SetCursor(ghGlobalCursor);
	    break;

	case WM_MOUSEMOVE:
	    {
	      // If we haven't clicked down and entered a critical section
	      // then we drop in and set the state...
	      if( !(gwStateOfApp & STATE_CRITICAL) )
	      {
		 if(OnRowBoundry(HIWORD(lParam)))
		    gwStateOfApp|=STATE_ROW;
		 else
		    gwStateOfApp&=~STATE_ROW;

		 if(OnColumnBoundry(LOWORD(lParam)))
		    gwStateOfApp|=STATE_COLUMN;
		 else
		    gwStateOfApp&=~STATE_COLUMN;

		 if( !(gwStateOfApp & (STATE_COLUMN | STATE_ROW)) )
		 {
		    gwStateOfApp&=~STATE_SYSMENU;  // not in system menu
		    grc.dwAppParam=CurrentCell(LOWORD(lParam),HIWORD(lParam)); // x,y

		    BuildBoundingRect(&grc.rectBound,LOWORD(lParam),HIWORD(lParam)); // x,y
		 }
	      }
	    }
	    break;

	case WM_LBUTTONDOWN:
	    {
	       REC rec;

	       if( !(gwStateOfApp & (STATE_CRITICAL|STATE_ROW|STATE_COLUMN)) )
	       {
		  // Always need to set up a bounding rectangle.  It was
		  // stored in client coordinates so convert to Window...
		  ClientToScreen(hWnd,(LPPOINT)&grc.rectBound);
		  ClientToScreen(hWnd,(LPPOINT)&grc.rectBound.right);

		  grc.lRcOptions|=RCO_NOFLASHUNKNOWN | RCO_DISABLEGESMAP;

		  switch(glpCells[Node(grc.dwAppParam)].wState)
		  {
		     case STATE_INK:
			grc.alc=ALC_SYSMINIMUM;  //ALC_GESTURE | ALC_NUMERIC;
			//grc.alcPriority=ALC_NUMERIC;
			break;
		     case STATE_TEXT:
			grc.alc=ALC_GESTURE;
			grc.alcPriority=ALC_GESTURE;
			break;
		     default:  //else STATE_CLEAN
			grc.alc=ALC_SYSMINIMUM;  //ALC_GESTURE | ALC_NUMERIC;
			//grc.alcPriority=ALC_NUMERIC;
			break;
		  }

		  rec=Recognize(&grc);	// call for recognition

		  if(rec==REC_POINTEREVENT)
		  {
		     RECT rectTmp;
		     int index; //,iTmp;
		     HDC hdc;

		     if( GetAsyncKeyState(VK_LBUTTON) & 0x8000 )  // pen is still in contact
		     {
			gwStateOfApp|=(STATE_CRITICAL |STATE_ALTSELECT);
			BuildBoundingRect(&grectAltSel, LOWORD(lParam),
					 HIWORD(lParam));
			hdc=GetDC(hWnd);
			PatBlt(hdc,grectAltSel.left,grectAltSel.top,
			       grectAltSel.right-grectAltSel.left,
			       grectAltSel.bottom-grectAltSel.top,
			       PATINVERT);
			ReleaseDC(hWnd,hdc);
		     }
		     else  // tap
		     {
			index=Node(grc.dwAppParam);
			if(glpCells[index].wState & (STATE_TEXT | STATE_INK) )
			{
			   if(glpCells[index].wState&STATE_TEXT)
			   {
			      glpCells[index].wState&=~STATE_TEXT;
			      glpCells[index].wState|=STATE_INK;
			   }
			   else  // ink state
			   {
			      glpCells[index].wState&=~STATE_INK;
			      glpCells[index].wState|=STATE_TEXT;
			   }

			   // only invalidate the cell
			   BuildBoundingRect(&rectTmp,
					     LOWORD(lParam),
					     HIWORD(lParam)); // x,y
			   InvalidateRect(hWnd,&rectTmp,TRUE);
			}
		     }
		  }
	       }
	       else
		  gwStateOfApp|=STATE_CRITICAL;
	    }
	    break;

	case WM_LBUTTONUP:
	    if(gwStateOfApp & STATE_ALTSELECT)
	    {
	       HDC hdc;

	       hdc=GetDC(hWnd);
	       PatBlt(hdc,grectAltSel.left,grectAltSel.top,
		      grectAltSel.right-grectAltSel.left,
		      grectAltSel.bottom-grectAltSel.top,
		      PATINVERT);
	       ReleaseDC(hWnd,hdc);
	    }
	    gwStateOfApp&=(~(STATE_CRITICAL | STATE_ALTSELECT));
	    break;

	case WM_RCRESULT:
	  {
	    LPRCRESULT lprcr;

	    if(lprcr = (LPRCRESULT)lParam)
	    {
	       int index;
	       //POINT pnt;
	       RECT rectTmp;

	       // Find out what cell the recognition was done in.
	       index=Node(grc.dwAppParam);

		  // check for gestures only.
		  if(lprcr->wResultsType & RCRT_GESTURE)
		  {
		     if(*lprcr->lpsyv == SYV_CORRECT)
			PostMessage(hWnd,WM_COMMAND,GESTURE_CORRECT,
				       lprcr->lprc->dwAppParam);
		     if(*lprcr->lpsyv == SYV_CLEAR)
			PostMessage(hWnd,WM_COMMAND,GESTURE_CLEAR,
				    lprcr->lprc->dwAppParam);
		     if( (*lprcr->lpsyv == SYV_COPY) ||
			 (*lprcr->lpsyv == MY_SYV_CIRCLELOC) )
			PostMessage(hWnd,WM_COMMAND,GESTURE_COPY,
				    lprcr->lprc->dwAppParam);
		     if( (*lprcr->lpsyv == SYV_CUT) ||
			 (*lprcr->lpsyv == MY_SYV_CIRCLELOX) )
		     {
			PostMessage(hWnd,WM_COMMAND,GESTURE_COPY,
				    lprcr->lprc->dwAppParam);
			PostMessage(hWnd,WM_COMMAND,GESTURE_CLEAR,
				    lprcr->lprc->dwAppParam);
		     }
		     if( (*lprcr->lpsyv == SYV_PASTE) ||
			 (*lprcr->lpsyv == MY_SYV_CIRCLELOP) )
			PostMessage(hWnd,WM_COMMAND,GESTURE_PASTE,
				    lprcr->lprc->dwAppParam);
		     if(*lprcr->lpsyv == MY_SYV_CIRCLELOA)
			PostMessage(hWnd,WM_COMMAND,IDM_ABOUT,0L);

		  }
		  else
		  {
		     // store the ink handle
		     glpCells[index].hpendata=DuplicatePenData(lprcr->hpendata,
							       GMEM_MOVEABLE);
		     // Offset the ink in the control so that it is relative
		     // to the upper left hand corner of the cell.

		     // Start converting it so that it is owned by the
		     // Cell.  rectTmp gets the cell location in client coords
		     rectTmp=lprcr->lprc->rectBound;

		     // ClientToScreen(hWnd,(LPPOINT)&rectTmp);
		     // get the distance in tablet coordinates from the upper
		     // left hand corner of the window's client and the cell.
		     // DPtoTP((LPPOINT)&rectTmp,1);
		     // Offset the ink so that the hpendata points are relative
		     // to the upper left hand corner of the client area.
		     OffsetPenData(glpCells[index].hpendata,-rectTmp.left,
				   -rectTmp.top);

		     // This is the location where the ink is located
		     // in the client area in tablet coordinates...
		     // Store it for future painting.
		     glpCells[index].pntOffset.x=rectTmp.left;
		     glpCells[index].pntOffset.y=rectTmp.top;


		     // fill text buffer with string.
		     SymbolToCharacter(lprcr->lpsyv,
				    min(lprcr->cSyv,MAXTEXTLENGTH-1),
				    glpCells[index].szText,NULL);
		     glpCells[index].szText[min(lprcr->cSyv,MAXTEXTLENGTH-1)]=(char)NULL;
		     glpCells[index].cText =min(lprcr->cSyv,MAXTEXTLENGTH-1); //   lstrlen(glpCells[index].szText);


		     if(  lprcr->wResultsType &
			  (RCRT_NOSYMBOLMATCH || RCRT_UNIDENTIFIED))
			glpCells[index].wState=STATE_INK;
		     else
			glpCells[index].wState=STATE_TEXT;

		     glpCells[index].hCursor=ghCellFull;
		  }

	       // always clean up after recognition.

	       // only invalidate the cell
	       TPtoDP((LPPOINT)&lprcr->lprc->rectBound,2);
	       ScreenToClient(hWnd,(LPPOINT)&lprcr->lprc->rectBound);
	       ScreenToClient(hWnd,(LPPOINT)&lprcr->lprc->rectBound.right);
	       InvalidateRect(hWnd,&lprcr->lprc->rectBound,TRUE);
	    }
	  }
	  break;

	case WM_PAINT:
	  {
	    HDC hdc;
	    PAINTSTRUCT ps;

	    hdc = BeginPaint(hWnd,&ps);

	    // paint the grid on the screen
	    DrawGrid(hdc,hWnd);

	    // Output Text or ink
	    DisplayResults(hdc,hWnd);

	    EndPaint(hWnd,&ps);
	  }
	  break;


	case WM_DESTROY:
	    ghCells=GlobalFree(ghCells);

	    PostQuitMessage(0);
            break;

	case WM_NCHITTEST:
	    {
	       //return WhereIsTheCursor(lParam);
	       lRetVal=DefWindowProc(hWnd,message,wParam,lParam);
	       if( lRetVal != HTCLIENT)
	       {
		  if( !(gwStateOfApp & STATE_CRITICAL) )
		     gwStateOfApp|=STATE_SYSMENU;
	       }
	       return lRetVal;
	    }
	    break;

	case WM_CREATE:
	   {
	      TEXTMETRIC tm;
	      HDC hdc;
	      WORD wXOrigin,wYOrigin;

	      hdc=GetDC(hWnd);

	      GetTextMetrics(hdc,&tm);

	      ReleaseDC(hWnd,hdc);

	      gwRowHeight=tm.tmHeight*2;
	      gwColumnWidth=tm.tmAveCharWidth * COLUMNS;

	      gwWindowWidth=GetSystemMetrics(SM_CXBORDER)*2+
			      gwColumnWidth*NUMCOLS;

	      gwWindowHeight=GetSystemMetrics(SM_CYBORDER)*2+
			       GetSystemMetrics(SM_CYCAPTION)+
			       gwRowHeight*ROWS;
			       // GetSystemMetrics(SM_CYMENU)+

	      // Center window on screen
	      wXOrigin=(GetSystemMetrics(SM_CXSCREEN)-gwWindowWidth)/2;
	      wYOrigin=(GetSystemMetrics(SM_CYSCREEN)-gwWindowHeight)/2;

	      MoveWindow(hWnd,wXOrigin,wYOrigin,
			 gwWindowWidth,gwWindowHeight,TRUE);

	      // Set up mouse cursor and set up others...
	      ghGlobalCursor=ghPen;
	      gwStateOfApp=STATE_CLEAN;

	      ghLeftRight=LoadCursor(ghInst,MAKEINTRESOURCE(GRID_IDC_LEFTRIGHT));
	      ghUpDown=LoadCursor(ghInst,MAKEINTRESOURCE(GRID_IDC_UPDOWN));
	      ghJunction=LoadCursor(ghInst,MAKEINTRESOURCE(GRID_IDC_JUNCTION));
	      ghCellFull=LoadCursor(ghInst,MAKEINTRESOURCE(GRID_IDC_CELLFULL));

	      ghPenDLL = GetSystemMetrics(SM_PENWINDOWS);

	      ghAltSelect=LoadCursor(ghPenDLL,IDC_ALTSELECT);
	      ghArrow=LoadCursor(NULL,IDC_ARROW);

	      // initialize rc structure
	      InitRC(hWnd,&grc);

	      // Set up data nodes
	      if( (ghCells=GlobalAlloc(GMEM_MOVEABLE | GMEM_ZEROINIT,
				      NUMCOLS*ROWS*sizeof(CELLNODE))) != NULL )
	      {
		 if( !(glpCells=(LPCELLNODE)GlobalLock(ghCells)) )
		 {
		    ErrorBox(IDS_CANNOTLOCK);
		    ghCells=GlobalFree(ghCells);
		    return -1;
		 }
	      }
	      else
	      {
		 ErrorBox(IDS_NOTENOUGHMEMORY);
		 return -1;
	      }

	   }
	   break;


	case WM_COMMAND:
            switch ( wParam )
		{
		case GESTURE_CORRECT:
		  {
		     int index;

		     index=Node(lParam);
		     // allow for numeric input
		     grc.alc|=ALC_NUMERIC;
		     // Call up Edit box
		     CorrectWriting(hWnd,
				    glpCells[index].szText,
				    MAXTEXTLENGTH,
				    &grc,
				    NULL,NULL);
		     glpCells[index].cText=lstrlen(glpCells[index].szText);
		     // restore alc values
		     grc.alc&=~ALC_NUMERIC;
		     InvalidateRect(hWnd,NULL,TRUE);
		  }
		  break;
		case GESTURE_COPY:
		  {
		     HANDLE hMem;
		     LPSTR lpMem;
		     WORD wFlags = GMEM_DDESHARE | GMEM_MOVEABLE | GMEM_ZEROINIT;
		     int index;

		     index=Node(lParam);

		     OpenClipboard(hWnd);
		     EmptyClipboard();

		     if( glpCells[index].hpendata )
		     {
			if(hMem=DuplicatePenData(glpCells[index].hpendata,GMEM_DDESHARE))
			{
			   RECT rectTmp;

			   BuildBoundingRect(&rectTmp, LOWORD(lParam),
					     HIWORD(lParam));
			   SetClipboardData(CF_PENDATA,hMem);
			}
			else
			{
			   ErrorBox(IDS_NOTENOUGHMEMORY);
			   return FALSE;
			}
		     }
		     if( glpCells[index].cText )
		     {
			if(hMem=GlobalAlloc(wFlags,MAXTEXTLENGTH))
			{
			   if(lpMem=GlobalLock(hMem))
			   {
			      lstrcpy(lpMem,glpCells[index].szText);
			      SetClipboardData(CF_TEXT,hMem);
			      GlobalUnlock(hMem);
			   }
			}
			else
			{
			   ErrorBox(IDS_NOTENOUGHMEMORY);
			   GlobalFree(hMem);
			   return FALSE;
			}
		     }

		     CloseClipboard();
		  }
		  break;
		case GESTURE_PASTE:
		  {
		     HANDLE hMem;
		     LPSTR lpStr;
		     int index;
		     RECT rectTmp;

		     index=Node(lParam);

		     if( glpCells[index].wState & (STATE_TEXT || STATE_INK) )
		     {
			glpCells[index].hpendata=GlobalFree(glpCells[index].hpendata);
			glpCells[index].wState=STATE_CLEAN;
			glpCells[index].cText=0;
			glpCells[index].szText[0]=(char)NULL;
		     }

		     OpenClipboard(hWnd);
		     if(IsClipboardFormatAvailable(CF_TEXT))
		     {
			if(hMem=GetClipboardData(CF_TEXT))
			{
			   lpStr=GlobalLock(hMem);

			   // copy the contents
			   lstrcpy(glpCells[index].szText,lpStr);
			   glpCells[index].cText=lstrlen(lpStr);

			   GlobalUnlock(hMem);
			}
			else
			   MessageBeep(0);
		     }

		     if( IsClipboardFormatAvailable(CF_PENDATA) )
		     {
			if(hMem=GetClipboardData(CF_PENDATA))
			{
			   glpCells[index].hpendata=DuplicatePenData(hMem,GMEM_DDESHARE);
			   glpCells[index].wState=STATE_INK;
			}
		     }

		     CloseClipboard();

		     if(!(glpCells[index].wState & STATE_INK))
			 glpCells[index].wState=STATE_TEXT;

		     // only invalidate the cell
		     BuildBoundingRect(&rectTmp,
				       LOWORD(lParam),
				       HIWORD(lParam)); // x,y
		     InvalidateRect(hWnd,&rectTmp,TRUE);
		     //InvalidateRect(hWnd,NULL,TRUE);
		  }
		  break;
		case GESTURE_CLEAR:
		  {
		     int index;
		     RECT rectTmp;

		     index=Node(lParam);
		     // Clear cell
		     lstrcpy(glpCells[index].szText,(LPSTR)"");
		     if(glpCells[index].hpendata)
			glpCells[index].hpendata=GlobalFree(glpCells[index].hpendata);
		     glpCells[index].cText=0;
		     glpCells[index].wState|=STATE_CLEAN;
		     glpCells[index].wState&=~(STATE_TEXT | STATE_INK);


		     // only invalidate the cell
		     BuildBoundingRect(&rectTmp,
				       LOWORD(lParam),
				       HIWORD(lParam)); // x,y
		     InvalidateRect(hWnd,&rectTmp,TRUE);


		     //InvalidateRect(hWnd,NULL,TRUE);
		  }
		  break;
		case IDM_ABOUT:
		  // Displays about box for application
		  {
		    FARPROC  lpProcAbout;
		    char szStr[MSG_SHORT];

		    LoadString(ghInst,IDS_ABOUTBOX,(LPSTR)szStr,MSG_SHORT);
		    lpProcAbout = MakeProcInstance( About, ghInst );
		    DialogBox(ghInst, (LPSTR)szStr, hWnd, lpProcAbout);
		    FreeProcInstance( lpProcAbout );
		  }
		  break;
                }
	    break;

	case WM_SYSCOMMAND:
	  // changes name of app when minimized or maximized.
	  {
	    WORD wTmp;

	    wTmp=wParam&0xFFF0;
	    switch(wTmp)
	    {
	       case SC_MINIMIZE:
		  {
		     char szTitle[MSG_SHORT];
		     LoadString(ghInst,IDS_MINTITLE,(LPSTR)szTitle,MSG_SHORT);
		     SetWindowText(hWnd,(LPSTR)szTitle);
		  }
		  break;
	       case SC_RESTORE:
		  {
		     char szTitle[MSG_NORMAL];
		     LoadString(ghInst,IDS_TITLE,(LPSTR)szTitle,MSG_NORMAL);
		     SetWindowText(hWnd,(LPSTR)szTitle);
		  }
		  break;
	    }
	    return(DefWindowProc(hWnd,message,wParam,lParam));
	  }
	  break;

        default:
            return (DefWindowProc(hWnd, message, wParam, lParam));
     }

     return (NULL);
}


//**************************************************************************
//
//  Function: Node
//	       HIWORD(l) contains the cell row number
//	       LOWROD(l) contains the cell column number
//
//  Purpose:  To return the index into the cell array where the cell
//	      information is for that cell
//
//
//  Returns:  integer index.
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      4/20/92	David Flenniken  Created
//
//*************************************************************************
int NEAR PASCAL Node(LONG l)
{
   return (int)((ROWS*LOWORD(l))+ HIWORD(l));
}
//**************************************************************************
//
//  Function: BuildBoundingRect
//		 RECT Pointer r points to rectangle to fill
//		 WORD x is x coordinate of mouse cursor
//		 WORD y is y coordinate of mouse cursor
//
//  Purpose:  To build bounding rectangle for recognition
//
//  Returns:  A LONG where the LOWORD is the column number and the HIWORD
//	      is the row number.
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      4/20/92	David Flenniken  Created
//
//*************************************************************************
LONG NEAR PASCAL BuildBoundingRect(RECT *r, WORD x, WORD y)
{
   r->left   =(x/gwColumnWidth)*gwColumnWidth;
   r->top    =(y/gwRowHeight)*gwRowHeight;
   r->right  =r->left+gwColumnWidth;
   r->bottom =r->top+gwRowHeight;

   // return the cell we're in column in LOWORD, row in HIWORD
   return CurrentCell(x,y);
}

//**************************************************************************
//
//  Function: CurrentCell
//		 WORD x coordinate of cursor
//		 WORD y coordinate of cursor
//
//  Purpose:  To calculate the cell that the cursor is in.
//
//  Returns:  A LONG where the LOWORD is the column number and the HIWORD
//	      is the row number.
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      4/20/92	David Flenniken  Created
//
//*************************************************************************
LONG NEAR PASCAL CurrentCell(WORD x, WORD y)
{
   if( (y>=(WORD)(ROWS*gwRowHeight)) )	 // then on border
      return MAKELONG(x/gwColumnWidth,(ROWS*gwRowHeight-1)/gwRowHeight);
   return MAKELONG(x/gwColumnWidth,y/gwRowHeight);
}

//**************************************************************************
//
//  Function: OnColumnBoundry
//		  WORD xActual is the x coordinate of the mouse cursor.
//
//  Purpose:  To determine if the mouse cursor is on a vertical cell
//	      Boundry.
//
//  Returns:  TRUE or FALSE.
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      4/20/92	David Flenniken  Created
//
//*************************************************************************
int NEAR PASCAL OnColumnBoundry(WORD xActual)
{
   int xDelta;

   xDelta=(int)xActual-((int)xActual/(int)gwColumnWidth)*(int)gwColumnWidth;
   if( ((WORD)xDelta <= SLACK) || ((WORD)xDelta >= gwColumnWidth-SLACK) )
   {
      // Looking good, check for Window boundry conditions...
      if( (xActual > SLACK) && (xActual < gwColumnWidth*NUMCOLS-SLACK) )
	 return TRUE;
   }
   return FALSE;
}

//**************************************************************************
//
//  Function: OnRowBoundry
//		WORD yActual the y coordinate of mouse cursor
//
//  Purpose:  To determine if the mouse cursor is on a cell row boundry.
//
//  Returns:  TRUE or FALSE
//
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      4/20/92	David Flenniken  Created
//
//*************************************************************************
int NEAR PASCAL OnRowBoundry(WORD yActual)
{
   int yDelta;

   yDelta=(int)yActual-((int)yActual/(int)gwRowHeight)*(int)gwRowHeight;
   if( ((WORD)yDelta <= SLACK) || ((WORD)yDelta >= gwRowHeight-SLACK) )
   {
      // Looking good, check for Window boundry conditions...
      if( (yActual > SLACK) && (yActual < gwRowHeight*ROWS-SLACK) )
	 return TRUE;
   }
   return FALSE;
}



//**************************************************************************
//
//  Function: DrawGrid
//		 HDC hdc - device context for painting
//		 HWND hwnd the window handle.
//
//  Purpose:  To draw the grid on the screen
//
//  Returns:  A bogus TRUE
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      12/20/91	David Flenniken  Created
//
//*************************************************************************

int NEAR PASCAL DrawGrid(HDC hdc,HWND hWnd)
{
   int i;
   WORD wStart,wEnd;
   WORD wLine;

   // draw Columns....
   wStart=0;
   wEnd=gwWindowHeight;
   for(i=1;i<NUMCOLS;i++)
   {
      wLine=gwColumnWidth*i;
      MoveTo(hdc,wLine,wStart);
      LineTo(hdc,wLine,wEnd);
   }

   // draw Rows....
   wStart=0;
   wEnd=gwWindowWidth;
   for(i=1;i<ROWS;i++)
   {
      wLine=gwRowHeight*i;
      MoveTo(hdc,wStart,wLine);
      LineTo(hdc,wEnd,wLine);
   }
   return (int)TRUE;
}



//**************************************************************************
//
//  Function: DisplayResults
//		  HDC hdc
//		  HWND hwnd
//
//  Purpose:  Blindly displays the contents of every cell.
//
//  Returns:  void
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      4/20/92	David Flenniken  Created
//
//*************************************************************************
void NEAR PASCAL DisplayResults(HDC hdc,HWND hWnd)
{
   int i,j,k;
   int xStart,yStart,yShift;
   POINT pnt;

   yShift = (gwRowHeight/4);  // display a little down...
   k=0;
   for(i=0;i<NUMCOLS;i++)  // for each column...
   {
						    // calculate column
      xStart=i*gwColumnWidth + (gwColumnWidth/10);  // display a little from left

      for(j=0;j<ROWS;j++)  // ...draw every row in the column.
      {
	 if(glpCells[k].wState & STATE_TEXT)  // it was recognized
	 {
	    yStart = j*gwRowHeight + yShift;  // calculate row

	    TextOut(hdc,xStart,yStart,glpCells[k].szText,
		    min(glpCells[k].cText,MAXSTRLEN));
	 }
	 else  // display the ink
	 {
	    if(glpCells[k].hpendata)
	    {
	       pnt.x=~(i*gwColumnWidth);
	       pnt.y=~(j*gwRowHeight);

	       if(!RedisplayPenData(hdc,glpCells[k].hpendata,
				&pnt,(LPPOINT)NULL,(int)-1,(WORD)-1))
		  MessageBeep(0);
	    }
	 }
	 k++;  // always update the index
      }
   }
}





//**************************************************************************
//
//  Function: ErrorBox(WORD)
//
//  Purpose:  To display Error Messages
//
//  Returns:  void
//																		    *
//  History:  Date	Author		 Reason
//	      --------	---------------  -------
//
//	      4/20/92	David Flenniken  Created
//
//*************************************************************************
void FAR PASCAL ErrorBox(WORD wID)
{
   char szTitle[MSG_NORMAL];
   char szMsg[MSG_LONG];

   LoadString(ghInst,wID,      (LPSTR)szMsg,  MSG_LONG);
   LoadString(ghInst,IDS_TITLE,(LPSTR)szTitle,MSG_NORMAL);
   MessageBox(GetFocus(),
	      (LPSTR)szMsg,
	      (LPSTR)szTitle,
	      MB_ICONEXCLAMATION | MB_OK);
}



/* END OF FILE */
