/*
 * OLEGLOBL.C
 *
 * Declarations of OLE-specific global variables.
 *
 */
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.



#ifdef MAKEOLESERVER

#include <windows.h>
#include <ole.h>
#include "schmoo.h"
#include "oleglobl.h"


XOLEGLOBALS      stOLE;
LPXOLEGLOBALS    pOLE=&stOLE;


#endif //MAKEOLESERVER
