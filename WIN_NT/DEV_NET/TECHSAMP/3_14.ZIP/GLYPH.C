// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
/****************************************************************************

    PROGRAM: glyph.c

    PURPOSE: glyph template for Windows applications

    FUNCTIONS:

	WinMain() - calls initialization function, processes message loop
	InitApplication() - initializes window data and registers window
	InitInstance() - saves instance handle and creates main window
	MainWndProc() - processes messages
	About() - processes messages for "About" dialog box

    COMMENTS:

        Windows can have several copies of your application running at the
        same time.  The variable hInst keeps track of which instance this
        application is so that processing will be to the correct window.

****************************************************************************/

#include <math.h>
#include "windows.h"		    /* required for all Windows applications */
#include "commdlg.h"
#include "glyph.h"		    /* specific to this program		     */

HANDLE hInst;			    /* current instance			     */
HWND hMyWnd;

HFONT hMyFont;			// Current font being used.
WORD wGlyph = IDM_BITMAP;	// Current glyph format to display.
WORD wEffect = IDM_IDENTITY;	// Current matrix type to use.

HBITMAP hbmDefault;		// Stock bitmap object.
HDC hdcMem;			// Memory DC for general use.

void PASCAL NEAR PaintIt(HWND);
void PASCAL NEAR OutputGlyph(HDC, UINT, WORD, WORD, WORD);

FIXED PASCAL NEAR FixedFromDouble(double);

/****************************************************************************

    FUNCTION: WinMain(HANDLE, HANDLE, LPSTR, int)

    PURPOSE: calls initialization function, processes message loop

    COMMENTS:

        Windows recognizes this function by name as the initial entry point 
        for the program.  This function calls the application initialization 
        routine, if no other instance of the program is running, and always 
        calls the instance initialization routine.  It then executes a message 
        retrieval and dispatch loop that is the top-level control structure 
        for the remainder of execution.  The loop is terminated when a WM_QUIT 
        message is received, at which time this function exits the application 
        instance by returning the value passed by PostQuitMessage(). 

        If this function must abort before entering the message loop, it 
        returns the conventional value NULL.  

****************************************************************************/

int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HANDLE hInstance;			     /* current instance	     */
HANDLE hPrevInstance;			     /* previous instance	     */
LPSTR lpCmdLine;			     /* command line		     */
int nCmdShow;				     /* show-window type (open/icon) */
{
    MSG msg;				     /* message			     */

    if (!hPrevInstance)			 /* Other instances of app running? */
	if (!InitApplication(hInstance)) /* Initialize shared things */
	    return (FALSE);		 /* Exits if unable to initialize     */

    /* Perform initializations that apply to a specific instance */

    if (!InitInstance(hInstance, nCmdShow))
        return (FALSE);

    /* Acquire and dispatch messages until a WM_QUIT message is received. */

    while (GetMessage(&msg,	   /* message structure			     */
	    NULL,		   /* handle of window receiving the message */
	    NULL,		   /* lowest message to examine		     */
	    NULL))		   /* highest message to examine	     */
	{
	TranslateMessage(&msg);	   /* Translates virtual key codes	     */
	DispatchMessage(&msg);	   /* Dispatches message to window	     */
    }
    return (msg.wParam);	   /* Returns the value from PostQuitMessage */
}


/****************************************************************************

    FUNCTION: InitApplication(HANDLE)

    PURPOSE: Initializes window data and registers window class

    COMMENTS:

        This function is called at initialization time only if no other 
        instances of the application are running.  This function performs 
        initialization tasks that can be done once for any number of running 
        instances.  

        In this case, we initialize a window class by filling out a data 
        structure of type WNDCLASS and calling the Windows RegisterClass() 
        function.  Since all instances of this application use the same window 
        class, we only need to do this when the first instance is initialized.  


****************************************************************************/

BOOL InitApplication(hInstance)
HANDLE hInstance;			       /* current instance	     */
{
    WNDCLASS  wc;

    /* Fill in window class structure with parameters that describe the       */
    /* main window.                                                           */

    wc.style = NULL;                    /* Class style(s).                    */
    wc.lpfnWndProc = (WNDPROC) MainWndProc;
                                        /* windows of this class.             */
    wc.cbClsExtra = 0;                  /* No per-class extra data.           */
    wc.cbWndExtra = 0;                  /* No per-window extra data.          */
    wc.hInstance = hInstance;           /* Application that owns the class.   */
    wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = GetStockObject(WHITE_BRUSH); 
    wc.lpszMenuName =  "glyphMenu";   /* Name of menu resource in .RC file. */
    wc.lpszClassName = "glyphWClass"; /* Name used in call to CreateWindow. */

    /* Register the window class and return success/failure code. */

    return (RegisterClass(&wc));

}


/****************************************************************************

    FUNCTION:  InitInstance(HANDLE, int)

    PURPOSE:  Saves instance handle and creates main window

    COMMENTS:

        This function is called at initialization time for every instance of 
        this application.  This function performs initialization tasks that 
        cannot be shared by multiple instances.  

        In this case, we save the instance handle in a static variable and 
        create and display the main program window.  
        
****************************************************************************/

BOOL InitInstance(hInstance, nCmdShow)
    HANDLE          hInstance;          /* Current instance identifier.       */
    int             nCmdShow;           /* Param for first ShowWindow() call. */
{
    HWND            hWnd;               /* Main window handle.                */

    /* Save the instance handle in static variable, which will be used in  */
    /* many subsequence calls from this application to Windows.            */

    hInst = hInstance;

    /* Create a main window for this application instance.  */

    hMyWnd = hWnd = CreateWindow(
        "glyphWClass",                /* See RegisterClass() call.          */
        "glyph Sample Application",   /* Text for window title bar.         */
        WS_OVERLAPPEDWINDOW,            /* Window style.                      */
        CW_USEDEFAULT,                  /* Default horizontal position.       */
        CW_USEDEFAULT,                  /* Default vertical position.         */
        CW_USEDEFAULT,                  /* Default width.                     */
        CW_USEDEFAULT,                  /* Default height.                    */
        NULL,                           /* Overlapped windows have no parent. */
        NULL,                           /* Use the window class menu.         */
        hInstance,                      /* This instance owns this window.    */
        NULL                            /* Pointer not needed.                */
    );

    /* If window could not be created, return "failure" */

    if (!hWnd)
        return (FALSE);

    /* Make the window visible; update its client area; and return "success" */

    ShowWindow(hWnd, nCmdShow);  /* Show the window                        */
    UpdateWindow(hWnd);          /* Sends WM_PAINT message                 */
    return (TRUE);               /* Returns the value from PostQuitMessage */

}

/****************************************************************************

    FUNCTION: MainWndProc(HWND, unsigned, WORD, LONG)

    PURPOSE:  Processes messages

    MESSAGES:

	WM_COMMAND    - application menu (About dialog box)
	WM_DESTROY    - destroy window

    COMMENTS:

	To process the IDM_ABOUT message, call MakeProcInstance() to get the
	current instance address of the About() function.  Then call Dialog
	box which will create the box according to the information in your
	glyph.rc file and turn control over to the About() function.	When
	it returns, free the intance address.

****************************************************************************/

long FAR PASCAL MainWndProc(hWnd, message, wParam, lParam)
HWND hWnd;				  /* window handle		     */
unsigned message;			  /* type of message		     */
WORD wParam;				  /* additional information	     */
LONG lParam;				  /* additional information	     */
{
    FARPROC lpProcAbout;		  /* pointer to the "About" function */
    HDC hdc;
    HBITMAP hbm;
    static LOGFONT lf;
    CHOOSEFONT cf;

    switch (message) {

	// Get the basic demo setup ready.  Create utility memory DC,
	// get handle to stock bitmap, build a default TrueType font
	// for initial display.
	case WM_CREATE:
	    hdc = GetDC(NULL);
	    hdcMem = CreateCompatibleDC(hdc);
	    ReleaseDC(NULL, hdc);
	    hbm = CreateCompatibleBitmap(hdcMem, 1, 1);
	    hbmDefault = SelectObject(hdcMem, hbm);
	    SelectObject(hdcMem, hbmDefault);
	    DeleteObject(hbm);

	    // build a TrueType font.
	    GetObject(GetStockObject(SYSTEM_FONT), sizeof(lf), &lf);
	    lf.lfHeight = 45;
	    lf.lfWidth = 0;
	    strcpy(&lf.lfFaceName, "Times New Roman");
	    hMyFont = CreateFontIndirect(&lf);

	    break;

	case WM_INITMENU:
	    CheckMenuItem(wParam, wGlyph, MF_CHECKED);
	    CheckMenuItem(wParam, wEffect, MF_CHECKED);
	    break;

	case WM_COMMAND:	   /* message: command from application menu */
	    switch (wParam)
	    {
		case IDM_ABOUT:
		{
		    lpProcAbout = MakeProcInstance(About, hInst);

		    DialogBox(hInst,		 /* current instance	     */
		    "AboutBox",			 /* resource to use	     */
		    hWnd,			 /* parent handle	     */
		    lpProcAbout);		 /* About() instance address */

		    FreeProcInstance(lpProcAbout);
		    break;
		}

		case IDM_CHOOSE:
		    memset(&cf, 0, sizeof(cf));
		    cf.lStructSize = sizeof(cf);
		    cf.hwndOwner = hWnd;
		    cf.lpLogFont = &lf;
		    cf.Flags = CF_SCREENFONTS | CF_TTONLY | CF_INITTOLOGFONTSTRUCT;
		    cf.lpfnHook = NULL;
		    if (ChooseFont(&cf))
		    {
			DeleteObject(hMyFont);
			hMyFont = CreateFontIndirect(&lf);
			InvalidateRect(hWnd, NULL, TRUE);
		    }
		break;

		case IDM_TEXTOUT:
		case IDM_BITMAP:
		case IDM_OUTLINE:
		    if (wParam != wGlyph)
		    {
			CheckMenuItem(GetMenu(hWnd), wGlyph, MF_UNCHECKED);
			wGlyph = wParam;
			CheckMenuItem(GetMenu(hWnd), wGlyph, MF_CHECKED);
			InvalidateRect(hWnd, NULL, TRUE);
		    }
		    break;

		case IDM_IDENTITY:
		case IDM_ROTATE60:
		case IDM_SHEAR:
		    if (wParam != wEffect)
		    {
			CheckMenuItem(GetMenu(hWnd), wEffect, MF_UNCHECKED);
			wEffect = wParam;
			CheckMenuItem(GetMenu(hWnd), wEffect, MF_CHECKED);
			InvalidateRect(hWnd, NULL, TRUE);
		    }
		    break;

		default: /* Lets Windows process it	     */
		    return (DefWindowProc(hWnd, message, wParam, lParam));
	    }
	    break;

	case WM_PAINT:
	    PaintIt(hWnd);
	    break;

	case WM_DESTROY:		  /* message: window being destroyed */
	    DeleteDC(hdcMem);
	    DeleteObject(hMyFont);
	    PostQuitMessage(0);
	    break;

	default:			  /* Passes it on if unproccessed    */
	    return (DefWindowProc(hWnd, message, wParam, lParam));
    }
    return (NULL);
}


/****************************************************************************

    FUNCTION: About(HWND, unsigned, WORD, LONG)

    PURPOSE:  Processes messages for "About" dialog box

    MESSAGES:

	WM_INITDIALOG - initialize dialog box
	WM_COMMAND    - Input received

    COMMENTS:

	No initialization is needed for this particular dialog box, but TRUE
	must be returned to Windows.

	Wait for user to click on "Ok" button, then close the dialog box.

****************************************************************************/

BOOL FAR PASCAL About(hDlg, message, wParam, lParam)
HWND hDlg;                                /* window handle of the dialog box */
unsigned message;                         /* type of message                 */
WORD wParam;                              /* message-specific information    */
LONG lParam;
{
    switch (message) {
	case WM_INITDIALOG:		   /* message: initialize dialog box */
	    return (TRUE);

	case WM_COMMAND:		      /* message: received a command */
	    if (wParam == IDOK                /* "OK" box selected?	     */
                || wParam == IDCANCEL) {      /* System menu close command? */
		EndDialog(hDlg, TRUE);	      /* Exits the dialog box	     */
		return (TRUE);
	    }
	    break;
    }
    return (FALSE);			      /* Didn't process a message    */
}

/****************************************************************************
 *
 *  FUNCTION   : PaintIt(hWnd)
 *
 *  PURPOSE    : Demonstrate getting the glyph information by filling the 
 *               window with a whole bunch of characters.  Very simplistic
 *               character placement is used.
 *
 *  RETURNS    : None.
 *
 ****************************************************************************/
void PASCAL NEAR PaintIt(HWND hWnd)
{
    PAINTSTRUCT ps;
    HDC hdcScreen;
    LOGFONT lf;
    TEXTMETRIC tm;
    WORD x = 0, y = 0;
    UINT i;
    HFONT hfOld;

    hdcScreen = BeginPaint(hWnd, &ps);
    hfOld = SelectObject(hdcScreen, hMyFont);
    GetTextMetrics(hdcScreen, &tm);

    for (i = 32; i < 128; i++)
    {
	OutputGlyph(hdcScreen, i, x, y, tm.tmAscent);
	x += tm.tmMaxCharWidth+2;
	if (x > 600)     // Extremely arbitrary hardcoded width.
	{
	    x = 0;
	    y += tm.tmHeight + 5;
	}
    }

    SelectObject(hdcScreen, hfOld);
    EndPaint(hWnd, &ps);
}

// Convert degrees to radians for math functions.
#define RAD(x) ((x) * 3.1415927 / 180)

/****************************************************************************
 *  FUNCTION   : FixedFromDouble
 *  RETURNS    : FIXED value representing the given double.
 ****************************************************************************/
FIXED PASCAL NEAR FixedFromDouble(double d)
{
    long l;

    l = (long) (d * 65536L);
    return *(FIXED *)&l;
}

/****************************************************************************
 *  FUNCTION   : IntFromFixed
 *  RETURNS    : int value approximating the FIXED value.
 ****************************************************************************/
int PASCAL NEAR IntFromFixed(FIXED f)
{
    if (f.fract >= 0x8000)
	return(f.value + 1);
    else
	return(f.value);
}

/****************************************************************************
 *  FUNCTION   : fxDiv2
 *  RETURNS    : (val1 + val2)/2 for FIXED values
 ****************************************************************************/
FIXED PASCAL NEAR fxDiv2(FIXED fxVal1, FIXED fxVal2)
{
    long l;

    l = (*((long far *)&(fxVal1)) + *((long far *)&(fxVal2)))/2;
    return(*(FIXED *)&l);
}

/****************************************************************************
 *  FUNCTION   : MakeRotationMat
 *  PURPOSE    : Fill in a rotation matrix based on the given angle.
 *  RETURNS    : none.
 ****************************************************************************/
MakeRotationMat(LPMAT2 lpMat, double dAngle)
{
    lpMat->eM11 = FixedFromDouble(cos(RAD(dAngle)));
    lpMat->eM12 = FixedFromDouble(sin(RAD(dAngle)));
    lpMat->eM21 = FixedFromDouble(-sin(RAD(dAngle)));
    lpMat->eM22 = FixedFromDouble(cos(RAD(dAngle)));
}

/****************************************************************************
 *  FUNCTION   : ShearMat
 *  PURPOSE    : Fill in a 0.25 horizontal shear matrix.
 *  RETURNS    : none.
 ****************************************************************************/
ShearMat(LPMAT2 lpMat)
{
    lpMat->eM11 = FixedFromDouble(1);
    lpMat->eM12 = FixedFromDouble(0);
    lpMat->eM21 = FixedFromDouble(0.25);
    lpMat->eM22 = FixedFromDouble(1);
}
/****************************************************************************
 *  FUNCTION   : IdentityMat
 *  PURPOSE    : Fill in matrix to be the identity matrix.
 *  RETURNS    : none.
 ****************************************************************************/
IdentityMat(LPMAT2 lpMat)
{
    lpMat->eM11 = FixedFromDouble(1);
    lpMat->eM12 = FixedFromDouble(0);
    lpMat->eM21 = FixedFromDouble(0);
    lpMat->eM22 = FixedFromDouble(1);
}

/****************************************************************************
 *
 *  FUNCTION   : BitmapFromT2Bitmap
 *
 *  PURPOSE    : Create a Windows bitmap from the GGO_BITMAP format.
 *               Two methods are provided:
 *                 1) create a DWORD-aligned bitmap by setting WidthBytes.
 *                 2) WORD-align the bits and create conventional bitmap.
 *
 *  RETURNS    : Handle to a Windows bitmap object
 *
 ****************************************************************************/
HBITMAP BitmapFromT2Bitmap(void FAR *lpBits, WORD width, WORD height)
{
#if 1
{
// Create a DWORD-aligned Windows bitmap.  By building up a BITMAP structure
// with the bmWidthBytes field corresponding to DWORD-alignment and using
// CreateBitmapIndirect, a bitmap that is DWORD-aligned can be read by 
// the device driver.
    BITMAP bm;

    bm.bmType = 0;
    bm.bmWidth = width;
    bm.bmHeight = height;
    bm.bmWidthBytes = ((width + 31) >> 5) << 2;
    bm.bmPlanes = 1;
    bm.bmBitsPixel = 1;
    bm.bmBits = lpBits;
    return (CreateBitmapIndirect(&bm));
}
#else
{
// Create a WORD-aligned (conventional alignment) bitmap by WORD-aligning
// the GGO_BITMAP format bits.  The bits are not touched if the bitmap
// is already WORD-aligned.

    WORD WordWidth;

    // if word align is same as dword align, bitmap is ready.
    // if not, eliminate the extra word buffer.
    WordWidth = (width + 15) >> 4;
    if (WordWidth != ((width + 31) >> 5) << 1)
    {
	_asm 
	{
	push	ds
	les	di,lpBits;
	lds	si,lpBits;
	mov	dx,height

copy_row:
	mov	cx,WordWidth
	rep	movsw		; copy relevant words
	inc	si
	inc	si		; skip over excess WORD
	dec	dx		; one more scanline compacted
	jnz	copy_row
	pop	ds
	}	       
    }
    return(CreateBitmap(width, height, 1, 1, lpBits));
}
#endif
}

/****************************************************************************
 *
 *  FUNCTION   : QSpline2Polyline
 *
 *  PURPOSE    : Fake spline cracker.  All it really does is take 
 *               the A, B, and C points and pretend they are a polyline,
 *               creating a very unsmooth curve.
 *
 *               In real life, the spline would be digitized.
 *
 *               The calculated points are stored in the given array.
 *
 *  RETURNS    : Number of points added to lpptPolygon.
 *
 *  BONUS INFO : Here is a description of an algorithm to implement
 *               this functionality.  
 *
 *** To break up a parabola defined by three points (A,B,C) into straight 
 *** line vectors given a maximium error. The maximum error is
 *** 1/resolution * 1/ERRDIV.
 ***
 ***           
 ***         B *-_
 ***          /   `-_
 ***         /       `-_
 ***        /           `-_ 
 ***       /               `-_
 ***      /                   `* C
 ***   A *
 ***
 *** PARAMETERS:
 ***
 *** Ax, Ay contains the x and y coordinates for point A. 
 *** Bx, By contains the x and y coordinates for point B. 
 *** Cx, Cy contains the x and y coordinates for point C.
 *** hX, hY are handles to the areas where the straight line vectors are going to be put.
 *** count is pointer to a count of how much data has been put into *hX, and *hY.
 ***
 *** F (t) = (1-t)^2 * A + 2 * t * (1-t) * B + t * t * C, t = 0... 1 =>
 *** F (t) = t * t * (A - 2B + C) + t * (2B - 2A) + A  =>
 *** F (t) = alfa * t * t + beta * t + A
 *** Now say that s goes from 0...N, => t = s/N
 *** set: G (s) = N * N * F (s/N)
 *** G (s) = s * s * (A - 2B + C) + s * N * 2 * (B - A) + N * N * A
 *** => G (0) = N * N * A
 *** => G (1) = (A - 2B + C) + N * 2 * (B - A) + G (0)
 *** => G (2) = 4 * (A - 2B + C) + N * 4 * (B - A) + G (0) =
 ***           3 * (A - 2B + C) + 2 * N * (B - A) + G (1)
 ***
 *** D (G (0)) = G (1) - G (0) = (A - 2B + C) + 2 * N * (B - A)
 *** D (G (1)) = G (2) - G (1) = 3 * (A - 2B + C) + 2 * N * (B - A)
 *** DD (G)   = D (G (1)) - D (G (0)) = 2 * (A - 2B + C)
 *** Also, error = DD (G) / 8 .
 *** Also, a subdivided DD = old DD/4.
 ***
 ****************************************************************************/
int NEAR PASCAL QSpline2Polyline(LPPOINT lpptPolygon, LPPOINTFX lppfSpline)
{
    // Skip over A point.  It is already in the polygon.
    lppfSpline++;

    // Store the B point.
    lpptPolygon->x = IntFromFixed(lppfSpline->x);
    lpptPolygon->y = IntFromFixed(lppfSpline->y);
    lppfSpline++;
    lpptPolygon++;

    // Store the C point.
    lpptPolygon->x = IntFromFixed(lppfSpline->x);
    lpptPolygon->y = IntFromFixed(lppfSpline->y);

    return(2);	// Two points added to polygon.
}

/****************************************************************************
 *  FUNCTION   : DrawT2Outline
 *
 *  PURPOSE    : Decode the GGO_NATIVE outline, create a polypolygon from it,
 *               and draw it using PolyPolygon.  Color and relative 
 *               positioning provided by caller.
 *
 *               Polygon is not actually returned as would be more common
 *               in real usage.  Also, an arbitrary size for the polygon
 *               is specified instead of actually expanding on a need-to-
 *               grow basis.
 *
 *               Error conditions are not handled.
 *
 *  RETURNS    : none.
 ****************************************************************************/
void DrawT2Outline(HDC hDC, LPTTPOLYGONHEADER lpHeader, DWORD size) 
{
    LPTTPOLYGONHEADER lpStart;
    LPTTPOLYCURVE lpCurve;
    POINT pt[500];
    WORD count[50];
    WORD cTotal = 0;	// Total number of points in polypolygon.
    WORD cInCurve; 	// Number of points in current curve.
    WORD cCurves = 0;	// Number of curves in polypolygon.
    WORD cInSpline;	// Number of points in digitized spline curve.
    WORD iFirstCurve;	// Index to start point of first curve.
    WORD i;
    POINTFX spline[3];

    lpStart = lpHeader;
    while ((DWORD)lpHeader < (DWORD)(((LPSTR)lpStart) + size))
    {
	if (lpHeader->dwType == TT_POLYGON_TYPE)
	{
	    cInCurve = 0;

	    // Get to first curve.
	    lpCurve = (LPTTPOLYCURVE) (lpHeader + 1);
	    iFirstCurve = cTotal;

	    while ((DWORD)lpCurve < (DWORD)(((LPSTR)lpHeader) + lpHeader->cb))
	    {
		if (lpCurve->wType == TT_PRIM_LINE)
		{
		    for (i = 0; i < lpCurve->cpfx; i++)
		    {
			pt[cTotal].x = IntFromFixed(lpCurve->apfx[i].x);
			pt[cTotal].y = IntFromFixed(lpCurve->apfx[i].y);
			cTotal++;
			cInCurve++;
		    }
		}
		else if (lpCurve->wType == TT_PRIM_QSPLINE)
		{
		    //**********************************************
		    // Format assumption:
		    //   The bytes immediately preceding a POLYCURVE
		    //   structure contain a valid POINTFX.
		    //
		    //   If this is first curve, this points to the 
		    //      pfxStart of the POLYGONHEADER.
		    //   Otherwise, this points to the last point of
		    //      the previous POLYCURVE.
		    //
		    //	 In either case, this is representative of the
		    //      previous curve's last point.
		    //**********************************************
		    spline[0] = *(LPPOINTFX)((LPSTR)lpCurve - sizeof(POINTFX));
	
		    for (i = 0; i < lpCurve->cpfx;)
		    {
		        // The B point.
			spline[1] = lpCurve->apfx[i++];

			// Calculate the C point.
			if (i == (lpCurve->cpfx - 1))
			{
			    spline[2] = lpCurve->apfx[i++];
			}     
			else
			{
			    // C is midpoint between B and next point.
			    spline[2].x = fxDiv2(lpCurve->apfx[i-1].x,
			    				lpCurve->apfx[i].x);
			    spline[2].y = fxDiv2(lpCurve->apfx[i-1].y,
			    				lpCurve->apfx[i].y);
			}

			cInSpline = QSpline2Polyline((LPPOINT)&(pt[cTotal]), spline);
			cTotal += cInSpline;
			cInCurve += cInSpline;

			// New A point for next slice of spline.
			spline[0] = spline[2];
		    }
		}
		else
		; // error, error, error

		// Move on to next curve.
		lpCurve = (LPTTPOLYCURVE)&(lpCurve->apfx[i]);
	    }

	    // Add points to close curve.
	    // Depending on the specific font and glyph being used, these
	    // may not always be needed, but it never hurts.
	    pt[cTotal].x = lpHeader->pfxStart.x.value;
	    pt[cTotal].y = lpHeader->pfxStart.y.value;
	    cInCurve++;
	    cTotal++;
	    pt[cTotal].x = pt[iFirstCurve].x;
	    pt[cTotal].y = pt[iFirstCurve].y;
	    cInCurve++;
	    cTotal++;
	    count[cCurves++] = cInCurve;

	    // Move on to next polygon.
	    lpHeader = (LPTTPOLYGONHEADER)(((LPSTR)lpHeader) + lpHeader->cb);
	}
	else
	; // error, error, error
    }

    // flip coordinates to get glyph right side up (Windows coordinates)
    for (i = 0; i < cTotal; i++)
	pt[i].y = 0 - pt[i].y;

    PolyPolygon(hDC, pt, count, cCurves);
}

/****************************************************************************
 *  FUNCTION   : OutputGlyph
 *
 *  PURPOSE    : Output a character glyph at a given position.
 *
 *               Depending on user choices, the glyph is either retrieved
 *               as a bitmap or an outline or is output with TextOut.
 *
 *  RETURNS    : none.
 ****************************************************************************/
void PASCAL NEAR OutputGlyph(HDC hDC, UINT letter, WORD x, WORD y, WORD ascent)
{
    GLYPHMETRICS gm;
    MAT2 mat;
    DWORD size;
    HANDLE hBits;
    LPSTR lpBits;
    WORD flag;
    HBITMAP hbm;
    HBRUSH hbr;
    DWORD oldOrg;

    // Simply output the character.  The matrix setting does not affect
    // this output.
    if (wGlyph == IDM_TEXTOUT)
    {
	TextOut(hDC, x, y, (LPSTR)&letter, 1);
	return;
    }
	       
    // make the 2x2 matrix
    // these are simply hardcoded examples.
    if (wEffect == IDM_IDENTITY)
	IdentityMat(&mat);
    else if (wEffect == IDM_ROTATE60)
	MakeRotationMat(&mat, 60);
    else if (wEffect == IDM_SHEAR)
	ShearMat(&mat);

    flag = (wGlyph == IDM_BITMAP) ? GGO_BITMAP : GGO_NATIVE;

    // allocate space for the bitmap/outline
    size = GetGlyphOutline(hDC, letter, flag, &gm, 0, NULL, &mat);
    hBits = GlobalAlloc(GHND, size);
    lpBits = GlobalLock(hBits);

    if ((GetGlyphOutline(hDC, letter, flag, &gm, size, lpBits, &mat)) != size)
    {
	MessageBox(hMyWnd, "Won't get it", "foo", MB_OK);
	return;
    }

    // Get the glyph in Windows bitmap format and blt to the screen.
    // Alignment is done in the blting.
    if (wGlyph == IDM_BITMAP)
    {
	hbm = BitmapFromT2Bitmap(lpBits, gm.gmBlackBoxX, gm.gmBlackBoxY);
	SelectObject(hdcMem, hbm);

	BitBlt(hDC, x + gm.gmptGlyphOrigin.x, y + (ascent - gm.gmptGlyphOrigin.y), 
		gm.gmBlackBoxX, gm.gmBlackBoxY, hdcMem, 0, 0, SRCCOPY);
	SelectObject(hdcMem, hbmDefault);
	DeleteObject(hbm);
    }
    // Glyph is in outline format.  Set up viewport origin to align the
    // glyph and draw it.  Actual decoding and drawing is done in 
    // DrawT2Outline.
    else if (wGlyph == IDM_OUTLINE)
    {
	hbr = CreateSolidBrush(RGB(255, 0, 255));
	hbr = SelectObject(hDC, hbr);
	
	oldOrg = GetViewportOrg(hDC);

	// Align based on cell origin.
	OffsetViewportOrg(hDC, x, y + ascent);
	DrawT2Outline(hDC, (LPTTPOLYGONHEADER)lpBits, size);

	SetViewportOrg(hDC, LOWORD(oldOrg), HIWORD(oldOrg));

	hbr = SelectObject(hDC, hbr);
	DeleteObject(hbr);
    }

    GlobalUnlock(hBits);
    GlobalFree(hBits);
}
