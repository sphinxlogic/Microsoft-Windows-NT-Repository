#include "minmax.h"
#include "stdlib.h"
#include "stdio.h"

// Set Values Dialog Box
//
void SetValuesDlg_Do(HWND hwndOwner)
{
    DLGPROC pfndp;

    pfndp = (DLGPROC)MakeProcInstance((FARPROC)SetValuesDlg_OldDlgProc, g_hinst);
    DialogBoxParam(g_hinst, MAKEINTRESOURCE(IDR_SETVALUEDLG), hwndOwner, pfndp, 0L);
    FreeProcInstance((FARPROC)pfndp);
}

BOOL CALLBACK SetValuesDlg_OldDlgProc(HWND hwnd, WORD msg, WPARAM wParam, LPARAM lParam)
{
    return SetDlgMsgResult(hwnd, msg, SetValuesDlg_DlgProc(hwnd, msg, wParam, lParam));
}

LRESULT SetValuesDlg_DlgProc(HWND hwnd, WORD msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
	HANDLE_MSG(hwnd, WM_INITDIALOG, SetValuesDlg_OnInitDialog);
	HANDLE_MSG(hwnd, WM_COMMAND, SetValuesDlg_OnCommand);
    default:
	return DefDialogProc(hwnd, msg, wParam, lParam);
    }
}

BOOL SetValuesDlg_OnInitDialog(HWND hwndDlg, HWND hwndFocus, LPARAM lParam)
{
    char szBuffer[32];

    _itoa(g_ptMaxSize.x, szBuffer, 10);
    Edit_SetText(GetDlgItem(hwndDlg, CTL_MAXSIZEX),szBuffer);

    _itoa(g_ptMaxSize.y, szBuffer, 10);
    Edit_SetText(GetDlgItem(hwndDlg, CTL_MAXSIZEY),szBuffer);

    _itoa(g_ptMaxPosition.x, szBuffer, 10);
    Edit_SetText(GetDlgItem(hwndDlg, CTL_MAXPOSX),szBuffer);

    _itoa(g_ptMaxPosition.y, szBuffer, 10);
    Edit_SetText(GetDlgItem(hwndDlg, CTL_MAXPOSY),szBuffer);

    _itoa(g_ptMinTrackSize.x, szBuffer, 10);
    Edit_SetText(GetDlgItem(hwndDlg, CTL_MAXX),szBuffer);

    _itoa(g_ptMinTrackSize.y, szBuffer, 10);
    Edit_SetText(GetDlgItem(hwndDlg, CTL_MAXY),szBuffer);

    _itoa(g_ptMaxTrackSize.x, szBuffer, 10);
    Edit_SetText(GetDlgItem(hwndDlg, CTL_MINX),szBuffer);

    _itoa(g_ptMaxTrackSize.y, szBuffer, 10);
    Edit_SetText(GetDlgItem(hwndDlg, CTL_MINY),szBuffer);

    _itoa(g_ptDefaultMaxSize.x, szBuffer, 10);
    Edit_SetText(GetDlgItem(hwndDlg, CTL_DEFMAXSIZEX),szBuffer);

    _itoa(g_ptDefaultMaxSize.y, szBuffer, 10);
    Edit_SetText(GetDlgItem(hwndDlg, CTL_DEFMAXSIZEY),szBuffer);

    _itoa(g_ptDefaultMaxPosition.x, szBuffer, 10);
    Edit_SetText(GetDlgItem(hwndDlg, CTL_DEFMAXPOSX),szBuffer);

    _itoa(g_ptDefaultMaxPosition.y, szBuffer, 10);
    Edit_SetText(GetDlgItem(hwndDlg, CTL_DEFMAXPOSY),szBuffer);

    _itoa(g_ptDefaultMinTrackSize.x, szBuffer, 10);
    Edit_SetText(GetDlgItem(hwndDlg, CTL_DEFMAXX),szBuffer);

    _itoa(g_ptDefaultMinTrackSize.y, szBuffer, 10);
    Edit_SetText(GetDlgItem(hwndDlg, CTL_DEFMAXY),szBuffer);

    _itoa(g_ptDefaultMaxTrackSize.x, szBuffer, 10);
    Edit_SetText(GetDlgItem(hwndDlg, CTL_DEFMINX),szBuffer);

    _itoa(g_ptDefaultMaxTrackSize.y, szBuffer, 10);
    Edit_SetText(GetDlgItem(hwndDlg, CTL_DEFMINY),szBuffer);

    return TRUE;
}

VOID SetValuesDlg_OnCommand(HWND hwndDlg, WORD id, HWND hwndCtl, WORD code)
{
    char szBuffer[32];

    if (id == CTL_OK && code == BN_CLICKED) {
	Edit_GetText(GetDlgItem(hwndDlg, CTL_MAXSIZEX),szBuffer, 32);
	g_ptMaxSize.x	   = atoi(szBuffer);

	Edit_GetText(GetDlgItem(hwndDlg, CTL_MAXSIZEY),szBuffer, 32);
	g_ptMaxSize.y	   = atoi(szBuffer);

	Edit_GetText(GetDlgItem(hwndDlg, CTL_MAXPOSX),szBuffer, 32);
	g_ptMaxPosition.x  = atoi(szBuffer);

	Edit_GetText(GetDlgItem(hwndDlg, CTL_MAXPOSY),szBuffer, 32);
	g_ptMaxPosition.y  = atoi(szBuffer);

	Edit_GetText(GetDlgItem(hwndDlg, CTL_MAXX),szBuffer, 32);
	g_ptMinTrackSize.x = atoi(szBuffer);

	Edit_GetText(GetDlgItem(hwndDlg, CTL_MAXY),szBuffer, 32);
	g_ptMinTrackSize.y = atoi(szBuffer);

	Edit_GetText(GetDlgItem(hwndDlg, CTL_MINX),szBuffer, 32);
	g_ptMaxTrackSize.x = atoi(szBuffer);

	Edit_GetText(GetDlgItem(hwndDlg, CTL_MINY),szBuffer, 32);
	g_ptMaxTrackSize.y = atoi(szBuffer);

	EndDialog(hwndDlg, TRUE);
    }
    else if (id == CTL_CANCEL && code == BN_CLICKED) {
	EndDialog(hwndDlg, TRUE);
    }
    else if (id == IDUSEDEFAULTS && code == BN_CLICKED) {
	g_ptMaxSize.x	   = g_ptDefaultMaxSize.x     ;
	g_ptMaxSize.y	   = g_ptDefaultMaxSize.y     ;
	g_ptMaxPosition.x  = g_ptDefaultMaxPosition.x ;
	g_ptMaxPosition.y  = g_ptDefaultMaxPosition.y ;
	g_ptMinTrackSize.x = g_ptDefaultMinTrackSize.x;
	g_ptMinTrackSize.y = g_ptDefaultMinTrackSize.y;
	g_ptMaxTrackSize.x = g_ptDefaultMaxTrackSize.x;
	g_ptMaxTrackSize.y = g_ptDefaultMaxTrackSize.y;
	EndDialog(hwndDlg, TRUE);
    }
}
