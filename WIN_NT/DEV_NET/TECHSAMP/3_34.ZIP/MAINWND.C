#include "minmax.h"

BOOL MinMax_Register(HINSTANCE hInstance)
{
    WNDCLASS cls;

    cls.hCursor 	= LoadCursor(NULL, IDC_ARROW);
    cls.hIcon		= LoadIcon(g_hinst, MAKEINTRESOURCE(IDR_APPICON));
    cls.lpszMenuName	= MAKEINTRESOURCE(IDR_MAINMENU);
    cls.hInstance	= hInstance;
    cls.lpszClassName	= "MinMax";
    cls.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
    cls.lpfnWndProc	= (WNDPROC) MinMax_WndProc;
    cls.style		= 0L;
    cls.cbWndExtra	= sizeof(HWND);
    cls.cbClsExtra	= 0;

    return RegisterClass(&cls);
}

LRESULT CALLBACK MinMax_WndProc(HWND hwnd, WORD msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
	HANDLE_MSG(hwnd, WM_GETMINMAXINFO, MinMax_OnGetMinMaxInfo);
	HANDLE_MSG(hwnd, WM_PAINT, MinMax_OnPaint);
	HANDLE_MSG(hwnd, WM_COMMAND, MinMax_OnCommand);
	HANDLE_MSG(hwnd, WM_DESTROY, MinMax_OnDestroy);
    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }
}

VOID MinMax_OnCommand(HWND hwnd, int id, HWND hwndCtl, WORD code)
{
    switch (id)
    {
    case CMD_FILEEXIT:
	PostQuitMessage(0);
	break;

    case CMD_HELPABOUT:
	AboutDlg_Do(hwnd);
	break;

    case CMD_FILESETVALUES:
	SetValuesDlg_Do(hwnd);
	break;

    default:
	break;
    }
}

VOID MinMax_OnPaint(HWND hwnd)
{
    PAINTSTRUCT ps;
    HDC hdc;
    RECT rc;

    hdc = BeginPaint(hwnd, &ps);

    GetClientRect(hwnd, &rc);

    FillRect(hdc, &rc, (HBRUSH)GetStockObject(GRAY_BRUSH));

    EndPaint(hwnd, &ps);
}



VOID MinMax_OnDestroy(HWND hwnd)
{
    PostQuitMessage(0);
}


VOID MinMax_OnGetMinMaxInfo(HWND hwnd, MINMAXINFO FAR* lpMinMaxInfo)
{
   if ( g_bFirstMinMax ) {
      g_bFirstMinMax = FALSE;
      //
      // First Time set Use Values
      //
      g_ptMaxSize.x      = lpMinMaxInfo->ptMaxSize.x;
      g_ptMaxSize.y      = lpMinMaxInfo->ptMaxSize.y;
      g_ptMaxPosition.x  = lpMinMaxInfo->ptMaxPosition.x;
      g_ptMaxPosition.y  = lpMinMaxInfo->ptMaxPosition.y;
      g_ptMinTrackSize.x = lpMinMaxInfo->ptMinTrackSize.x;
      g_ptMinTrackSize.y = lpMinMaxInfo->ptMinTrackSize.y;
      g_ptMaxTrackSize.x = lpMinMaxInfo->ptMaxTrackSize.x;
      g_ptMaxTrackSize.y = lpMinMaxInfo->ptMaxTrackSize.y;
   }

   //
   // Windows sends defaults each WM_GETMINMAXINFO Message
   //
   g_ptDefaultMaxSize.x      = lpMinMaxInfo->ptMaxSize.x;
   g_ptDefaultMaxSize.y      = lpMinMaxInfo->ptMaxSize.y;
   g_ptDefaultMaxPosition.x  = lpMinMaxInfo->ptMaxPosition.x;
   g_ptDefaultMaxPosition.y  = lpMinMaxInfo->ptMaxPosition.y;
   g_ptDefaultMinTrackSize.x = lpMinMaxInfo->ptMinTrackSize.x;
   g_ptDefaultMinTrackSize.y = lpMinMaxInfo->ptMinTrackSize.y;
   g_ptDefaultMaxTrackSize.x = lpMinMaxInfo->ptMaxTrackSize.x;
   g_ptDefaultMaxTrackSize.y = lpMinMaxInfo->ptMaxTrackSize.y;

   // maximized width and height
   lpMinMaxInfo->ptMaxSize.x	  = g_ptMaxSize.x;
   lpMinMaxInfo->ptMaxSize.y	  = g_ptMaxSize.y;

   // maximized position of top left
   lpMinMaxInfo->ptMaxPosition.x  = g_ptMaxPosition.x;
   lpMinMaxInfo->ptMaxPosition.y  = g_ptMaxPosition.y;

   // minimium width and height for sizing
   lpMinMaxInfo->ptMinTrackSize.x = g_ptMinTrackSize.x;
   lpMinMaxInfo->ptMinTrackSize.y = g_ptMinTrackSize.y;

   // maximium width and height for sizing
   lpMinMaxInfo->ptMaxTrackSize.x = g_ptMaxTrackSize.x;
   lpMinMaxInfo->ptMaxTrackSize.y = g_ptMaxTrackSize.y;

   return;
}
