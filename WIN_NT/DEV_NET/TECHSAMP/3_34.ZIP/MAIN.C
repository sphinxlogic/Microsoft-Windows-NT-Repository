#include "minmax.h"

// Globals

HINSTANCE   g_hinst                 = NULL;
HINSTANCE   g_hinstPrev             = NULL;
LPCSTR      g_lpCmdLine             = NULL;
int         g_nCmdShow              = 0;
HMODULE     g_hmod                  = NULL;
HTASK       g_htask                 = NULL;

HWND        g_hwndFrame             = NULL;

POINT       g_ptMaxSize             = {0,0};
POINT       g_ptMaxPosition         = {0,0};
POINT       g_ptMinTrackSize        = {0,0};
POINT       g_ptMaxTrackSize        = {0,0};

POINT	    g_ptDefaultMaxSize	    = {0,0};
POINT	    g_ptDefaultMaxPosition  = {0,0};
POINT	    g_ptDefaultMinTrackSize = {0,0};
POINT	    g_ptDefaultMaxTrackSize = {0,0};

BOOL	    g_bFirstMinMax	    = TRUE;

//===========================================================================

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
	LPSTR lpCmdLine, int nCmdShow)
{
    int code;

    g_hinst	= hInstance;
    g_hinstPrev = hPrevInstance;
    g_lpCmdLine = lpCmdLine;
    g_nCmdShow	= nCmdShow;

    g_hmod	= GetInstanceModule(g_hinst);
    g_htask	= GetCurrentTask();

    if (!App_Initialize())
	return 1;

    code = App_Main();

    return code;
}

BOOL App_Initialize(void)
{
    if (!MinMax_Register(g_hinst))
	return FALSE;

    g_hwndFrame = CreateWindowEx(
	    0L, 			    // extendedStyle
	    "MinMax",			    // class name
	    "MinMax Application", 	    // text
	    WS_POPUP |
	    // WS_OVERLAPPED |
		WS_CAPTION |
		WS_SYSMENU |
		WS_THICKFRAME |
		WS_MINIMIZEBOX |
		WS_MAXIMIZEBOX, 	    // style
	    100, 100,	// x, y
	    200, 200,	// cx, cy
	    NULL,			    // hwndParent
	    NULL,			    // hmenu
	    g_hinst,			    // hInstance
	    NULL);			    // lpParam

    if (g_hwndFrame == NULL)
	return FALSE;

    ShowWindow(g_hwndFrame, g_nCmdShow);

    return TRUE;
}

int App_Main(void)
{
    MSG msg;

    while (GetMessage(&msg, NULL, 0, 0))
    {
	TranslateMessage(&msg);
	DispatchMessage(&msg);
    }
    return (int)msg.wParam;
}
