#include "statbar.h"

LRESULT DefDialogProc(HWND hwnd, WORD msg, WPARAM wParam, LPARAM lParam)
{
    DLGPROC lpfndp = SubclassDialog(hwnd, NULL);
    LRESULT result = DefDlgProc(hwnd, msg, wParam, lParam);
    SubclassDialog(hwnd, lpfndp);
    return result;
}

// About dialog box
//
void AboutDlg_Do(HWND hwndOwner)
{
    DLGPROC pfndp;

    pfndp = (DLGPROC)MakeProcInstance((FARPROC)SimpleDlg_OldDlgProc, g_hinst);
    DialogBoxParam(g_hinst, MAKEINTRESOURCE(IDR_ABOUTDLG), hwndOwner, pfndp, 0L);
    FreeProcInstance((FARPROC)pfndp);
}


BOOL CALLBACK SimpleDlg_OldDlgProc(HWND hwnd, WORD msg, WPARAM wParam, LPARAM lParam)
{
    return SetDlgMsgResult(hwnd, msg, SimpleDlg_DlgProc(hwnd, msg, wParam, lParam));
}

LRESULT SimpleDlg_DlgProc(HWND hwnd, WORD msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
        HANDLE_MSG(hwnd, WM_COMMAND, SimpleDlg_OnCommand);
    default:
	return DefDialogProc(hwnd, msg, wParam, lParam);
    }
}

VOID SimpleDlg_OnCommand(HWND hwndDlg, WORD id, HWND hwndCtl, WORD code)
{
    if ((id == CTL_OK || id == CTL_CANCEL) && code == BN_CLICKED)
    {
	EndDialog(hwndDlg, TRUE);
    }
}
