/*
 * OLELIB.C
 *
 * Miscellaneous library functions necessary for OLE.  Does not
 * make any OLE calls.
 *
 */
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <windows.h>
#include <ole.h>
#include <commdlg.h>
#include <string.h>
#include "oclient.h"
#include "patron.h"


/*
 * FSaveOpenDialog
 *
 * Purpose:
 *  Invokes the COMMDLG.DLL GetOpenFileName dialog and retrieves
 *  a filename for saving or opening.
 *
 * Parameters:
 *  hWnd            HWND of the owning application.
 *  pszFile         LPSTR buffer to receive the entered filename.
 *  cchFile         UINT length of pszFile
 *  pszCaption      Caption bar for the dialog.
 *  fOpen           BOOL indicating if we want file open or save.
 *
 * Return Value:
 *  BOOL            TRUE if the function retrieved a filename,
 *                  FALSE if the user pressed CANCEL.
 */

BOOL FAR PASCAL FSaveOpenDialog(HWND hWnd, LPSTR pszFile, UINT cchFile,
                                LPSTR pszCaption, BOOL fOpen)
    {
    BOOL                fRet;
    OPENFILENAME        ofn;
    char                szFile[CCHPATHMAX];
    char                szFilter[80];
    WORD                cch;

    memset(&ofn, 0, sizeof(OPENFILENAME));
    ofn.lStructSize      =sizeof(OPENFILENAME);
    ofn.hwndOwner        =hWnd;

    lstrcpy(szFilter, rgpsz[IDS_FILEOPENFILTER]);
    cch=lstrlen(szFilter);
    ReplaceCharWithNull(szFilter, szFilter[cch-1]);

    ofn.lpstrFilter      =szFilter;
    ofn.nFilterIndex     =1L;                //We only have 1 file type.

    ofn.lpstrTitle       =pszCaption;

    szFile[0]=0;

    if (lstrcmp(rgpsz[IDS_UNTITLED], pszFile))
        lstrcpy(szFile, pszFile);

    ofn.lpstrFile        =szFile;
    ofn.nMaxFile         =cchFile;

    ofn.lpstrDefExt      =rgpsz[IDS_DEFEXT];

    if (fOpen)
        {
        ofn.Flags=OFN_HIDEREADONLY | OFN_FILEMUSTEXIST;
        fRet=GetOpenFileName(&ofn);
        }
    else
        {
        ofn.Flags=OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
        fRet=GetSaveFileName(&ofn);
        }

    if (fRet)
        lstrcpy(pszFile, szFile);

    return fRet;
    }





/*
 * ReplaceCharWithNull
 *
 * Purpose:
 *  Walks a null-terminated string and replaces a given character
 *  with a zero.
 *
 * Parameters:
 *  psz             LPSTR to the string to process.
 *  ch              int character to replace.
 *
 * Return Value:
 *  int             Number of characters replaced.  -1 if psz is NULL.
 */

UINT FAR PASCAL ReplaceCharWithNull(LPSTR psz, int ch)
    {
    UINT            cChanged=0;

    if (NULL==psz)
        return 0;

    while (0!=*psz)
        {
        if (ch==*psz)
            {
            *psz=0;
            cChanged++;
            }

        psz++;
        }

    return cChanged;
    }






/*
 * PszFileFromPath
 *
 * Purpose:
 *  Returns a pointer within an existing pathname string to the
 *  last file of that string.  Used to extract the filename from
 *  a path for use in window titles and message boxes.
 *
 *  Note:  This function does character comparisons to '\' and so
 *  may require more work to localize.
 *
 * Parameters:
 *  pszPath         LPSTR pointer to full pathname.
 *
 * Return Value:
 *  LPSTR           Pointer to a filename within pszPath or NULL if
 *                  there is an error.
 */

LPSTR FAR PASCAL PszFileFromPath(LPSTR pszPath)
    {
    LPSTR   psz=NULL;

    if (NULL!=pszPath)
        {
        psz=pszPath + lstrlen(pszPath)-1;

        while ((psz > pszPath) && (psz[-1]!='\\'))
            psz--;
        }

    return psz;
    }



/*
 * PszExtensionFromFile
 *
 * Purpose:
 *  Returns a pointer within an existing filename string to the
 *  extension of that file.  Used to extract the extension from a file
 *  for use in File dialogs and so forth.  The file is scanned backwards
 *  looking for a '.' or '\'.  If no '.' is found before a '\' then
 *  this function returns a pointer to the null terminator.
 *
 *  Note:  This function does character comparisons to '.' and '\' and so
 *  may require more work to localize.
 *
 * Parameters:
 *  pszFile         LPSTR pointer to a filename.
 *
 * Return Value:
 *  LPSTR           Pointer to an extension (starting with the .) within
 *                  pszFile or NULL if there is an error.
 */

LPSTR FAR PASCAL PszExtensionFromFile(LPSTR pszFile)
    {
    LPSTR   psz;
    LPSTR   pszT=NULL;

    if (NULL!=pszFile)
        {
        //Point to null terminator.
        pszT=pszFile + lstrlen(pszFile);
        psz =pszT-1;

        while ((psz > pszFile) && (psz[-1]!='\\') && (psz[-1]!='.'))
            psz--;

        if ('.'==psz[-1])
            return --psz;
        }

    return pszT;
    }





/*
 * PszWhiteSpaceScan
 *
 * Purpose:
 *  Skips characters in a string until a whitespace or non-whitespace
 *  character is seen.  Whitespace is defined as \n, \r, \t, or ' '.
 *
 * NOTE:  This function is not extremely well suited to localization.
 *        It assumes that an existing application seeking to become
 *        and OLE client probably already has such a string function
 *        available.
 *
 * Parameters:
 *  psz             LPSTR to string to manipulate
 *  fSkip           BOOL  TRUE if we want to skip whitespace.
 *                  FALSE if we want to skip anything but whitespace.
 *
 * Return Value:
 *  LPSTR           Pointer to first character in the string that either
 *                  non-whitespace (fSkip=TRUE) or whitespace (fSkip=FALSE),
 *                  which may be the null terminator.
 */

LPSTR FAR PASCAL PszWhiteSpaceScan(LPSTR psz, BOOL fSkip)
    {
    char        ch;
    BOOL        fWhite;

    while (ch=*psz)
        {
        fWhite=('\n'==ch || '\r'==ch || '\t'==ch || ' '==ch);

        //Too bad C doesn't have a logical XOR (^^) operator.
        if ((fSkip && !fWhite) || (!fSkip && fWhite))
            break;

        psz++;
        }

    return psz;
    }





/*
 * RectConvertMappings
 *
 * Purpose:
 *  Converts the contents of a rectangle from one logical mapping
 *  into another.  This function is useful since you have to convert
 *  logical->device then device->logical to do this transformation.
 *
 * Parameters:
 *  pRect           LPRECT containing the rectangle to convert.
 *  mm              WORD mapping mode or source rectangle.
 *
 * Return Value:
 *  None.
 */

void FAR PASCAL RectConvertMappings(LPRECT pRect, UINT mmSrc, UINT mmDst)
    {
    HDC      hDC;
    POINT    rgpt[2];
    UINT     mmTemp;

    if (NULL==pRect)
        return;

    hDC=GetDC(NULL);

    rgpt[0].x=pRect->left;
    rgpt[0].y=pRect->top;
    rgpt[1].x=pRect->right;
    rgpt[1].y=pRect->bottom;

    //Convert the source units into device units.
    mmTemp=SetMapMode(hDC, mmSrc);
    LPtoDP(hDC, rgpt, 2);

    //Convert the device units into the destination units.
    SetMapMode(hDC, mmDst);
    DPtoLP(hDC, rgpt, 2);

    pRect->left   =rgpt[0].x;
    pRect->top    =rgpt[0].y;
    pRect->right  =rgpt[1].x;
    pRect->bottom =rgpt[1].y;

    //Cleanup and return.
    SetMapMode(hDC, mmTemp);
    ReleaseDC(NULL, hDC);
    return;
    }
