/*
 * OLEINS.C
 *
 * Functions to handle the Insert Object command as well as the
 * Insert Object dialog.  Calls functions in REGISTER.C to query
 * the registration database for object classnames.
 *
 * Also contains the FObjectsFromDropFiles function to create embedded
 * Packager objects from files dropped from File Manager.
 *
 */
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <windows.h>
#include <ole.h>
#include "register.h"
#include "oclient.h"



/*
 * PObjectInsertDialog
 *
 * Purpose:
 *  Displays the Insert Object dialog and creates an object of the
 *  selected name.  The caller must provide the name of the object
 *  to create.  NOTE:  Uses pDoc->pszData1.
 *
 * Parameters:
 *  hWnd            HWND parent of the dialog box.
 *  hInst           HANDLE of the application instance.
 *  pDoc            LPDOCUMENT identifying OLE data.
 *  pszObject       LPSTR to the name for a new object.
 *
 * Return Value:
 *  LPOBJECT        Pointer to a new OBJECT if the function succeeds.
 *                  NULL otherwise or if the user pressed Cancel.
 */

LPOBJECT FAR PASCAL PObjectInsertDialog(HWND hWnd, HANDLE hInst,
                                        LPDOCUMENT pDoc, LPSTR pszObject)
    {
    FARPROC         lpfn;
    UINT            uTemp;
    BOOL            fTemp;
    LPOBJECT        pObj;
    OLESTATUS       os;

    if (NULL==pszObject)
        return NULL;

    /*
     * Pass a string pointer to the dialog in which the it will return
     * the object class name.
     */

    lpfn=MakeProcInstance(InsertObjectProc, hInst);
    uTemp=DialogBoxParam(hInst, MAKEINTRESOURCE(IDD_INSERTOBJECT), hWnd,
                         lpfn, (LONG)pDoc->pszData1);
    FreeProcInstance(lpfn);

    //Out of memory==-1, User pressed cancel==0
    if (1!=uTemp)
        return NULL;

    pObj=PObjectAllocate(&fTemp, pDoc);

    if (!fTemp)
        {
        PObjectFree(pDoc, pObj);
        return NULL;
        }

    //Attempt to launch the server to give us the object.
    os=OleCreate(PSZOLE(IDS_STDFILEEDITING), (LPOLECLIENT)pObj, pDoc->pszData1,
                 pDoc->lh, pszObject, &pObj->pObj, olerender_draw, 0);

    if (OLE_OK!=OsError(os, pDoc, pObj, TRUE))
        {
        MessageBox(hWnd, PSZOLE(IDS_NOINSERT), PSZOLE(IDS_INSERTTITLE),
                   MB_OK | MB_ICONEXCLAMATION);

        PObjectFree(pDoc, pObj);
        return NULL;
        }
    else
        {
        //Mark this guy as open.
        pObj->fOpen=TRUE;
        }

    return pObj;
    }





/*
 * InsertObjectProc
 *
 * Purpose:
 *  Dialog procedure for the Insert Object dialog.
 *
 * Parameters:
 *  The standard.
 *
 * Return Value:
 *  The value to be returned through the DialogBox call that
 *  created the dialog.
 *
 */

BOOL FAR PASCAL InsertObjectProc(HWND hDlg, UINT iMsg, UINT wParam, LONG lParam)
    {
    static LPSTR    pszObject;
    UINT            i;
    UINT            cb;
    HWND            hList;
    char            szTemp[256];

    HWND            hWndMsg;
    WORD            wID;
    WORD            wCode;

    hWndMsg=(HWND)(UINT)lParam;
    wID=LOWORD(wParam);
    #ifdef WIN32
        wCode=HIWORD(wParam);
    #else
        wCode=HIWORD(lParam);
    #endif

    switch (iMsg)
        {
        case WM_INITDIALOG:
            pszObject=(LPSTR)lParam;

            //Go fill the listbox with names from the registration database.
            hList=GetDlgItem(hDlg, ID_OBJECTLIST);
            UFillClassList(hList);
            return TRUE;


        case WM_COMMAND:
            switch (wID)
                {
                case IDCANCEL:
                    EndDialog(hDlg, FALSE);
                    break;

                //Double-clicking is the same as hitting OK.
                case ID_OBJECTLIST:
                    if (LBN_DBLCLK!=wCode)
                        break;

                    //FALL THROUGH.

                case IDOK:
                    hList=GetDlgItem(hDlg, ID_OBJECTLIST);
                    i=(UINT)SendMessage(hList, LB_GETCURSEL, 0, 0L);

                    //Convert the descriptive name to a real classname.
                    SendMessage(hList, LB_GETTEXT, i, (LONG)(LPSTR)szTemp);
                    cb=UClassFromDescription(szTemp, pszObject, 256);

                    EndDialog(hDlg, TRUE);
                    break;
                }
            break;
        }
    return FALSE;
    }
