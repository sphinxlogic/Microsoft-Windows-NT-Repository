#include <windows.h>
#include <windowsx.h>

#include "msdntb.h"

#include "tooltest.h"

// Public globals
const HINSTANCE _hInstance;
const HINSTANCE _hPrevInstance;
const LPSTR _lpszCmdLine;
const int _cmdShow;
HWND g_hWndMain;
char szString[128];
char szAppName[20];

#define CMD_TB_BASE 400

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow)
{
 MSG        msg;           /* MSG structure to store your messages        */
 int        nRc;           /* return value from Register Classes          */
 TBBUTTON tbButton[8];
 int i;
 HWND hWndTB;


 lstrcpy(szAppName, "TOOLTEST");

 if(!hPrevInstance)
   {
    /* register window classes if first instance of application         */
    if ((nRc = nCwRegisterClasses()) == -1)
      {
       /* registering one of the windows failed                         */
       LoadString(_hInstance, IDS_ERR_REGISTER_CLASS, szString, sizeof(szString));
       MessageBox(NULL, szString, NULL, MB_ICONEXCLAMATION);
       return nRc;
      }
   }

 /* create application's Main window                                    */
 g_hWndMain = CreateWindow(
                szAppName,               /* Window class name           */
                szAppName,
                WS_CAPTION      |        /* Title and Min/Max           */
                WS_SYSMENU      |        /* Add system menu box         */
                WS_MINIMIZEBOX  |        /* Add minimize box            */
                WS_MAXIMIZEBOX  |        /* Add maximize box            */
                WS_THICKFRAME   |        /* thick sizeable frame        */
                WS_CLIPCHILDREN |         /* don't draw in child windows areas */
                WS_OVERLAPPED,
                CW_USEDEFAULT, 0,        /* Use default X, Y            */
                CW_USEDEFAULT, 0,        /* Use default X, Y            */
                NULL,                    /* Parent window's handle      */
                NULL,                    /* Default to Class Menu       */
                _hInstance,              /* Instance of window          */
                NULL);                   /* Create struct for WM_CREATE */


 if(g_hWndMain == NULL)
   {
    LoadString(_hInstance, IDS_ERR_CREATE_WINDOW, szString, sizeof(szString));
    MessageBox(NULL, szString, NULL, MB_ICONEXCLAMATION);
    return IDS_ERR_CREATE_WINDOW;
   }

 ShowWindow(g_hWndMain, nCmdShow);            /* display main window      */

 for ( i = 0; i < 8; i++ ) {
    tbButton[i].iBitmap=i;
    tbButton[i].idCommand=i+CMD_TB_BASE+1;
    tbButton[i].fsState = TBSTATE_ENABLED;
    tbButton[i].fsStyle = TBSTYLE_BUTTON;
 }

 hWndTB = CreateToolbar(g_hWndMain,
               WS_BORDER|WS_VISIBLE,
               CMD_TB_BASE,
               9,
               _hInstance,
               IDR_TOOLICONS,
               tbButton,
               8);

 while(GetMessage(&msg, NULL, 0, 0))        /* Until WM_QUIT message    */
   {
    TranslateMessage(&msg);
    DispatchMessage(&msg);
   }

 /* Do clean up before exiting from the application                     */
 CwUnRegisterClasses();
 return msg.wParam;
}

void PrintIt(HWND hWnd, char *szString)
{
 RECT       rc;
 HDC        hdc;

 hdc = GetDC(hWnd);
 rc.left   = 10;
 rc.top    = 40;
 rc.right  = 325;
 rc.bottom = 60;
 ExtTextOut(hdc,10,40,ETO_OPAQUE,&rc,szString,_fstrlen(szString),NULL);
 ReleaseDC(hWnd, hdc);
}

LONG FAR PASCAL WndProc(HWND hWnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HMENU      hMenu=0;            /* handle for the menu                 */
 int        nRc=0;              /* return code                         */

 switch (Message)
   {
    case WM_COMMAND:
         switch (wParam)
           {
            case CMD_FILEEXIT:
                 PostQuitMessage(0);
            break;

            case 401:
                 PrintIt(hWnd, "Cut   - Your mother wears army boots           ");
            break;

            case 402:
                 PrintIt(hWnd, "Copy  - Right                                  ");
            break;

            case 403:
                 PrintIt(hWnd, "Paste - Yuck                                   ");
            break;

            case 404:
                 PrintIt(hWnd, "New   - There is nothing new in this world     ");
            break;

            case 405:
                 PrintIt(hWnd, "Open  - Looks like an open and shut case       ");
            break;

            case 406:
                 PrintIt(hWnd, "Save  - A penny saved is a penny earned        ");
            break;

            case 407:
                 PrintIt(hWnd, "Print - All the news that's fit to print       ");
            break;

            case 408:
            case CMD_HELPABOUT:
                 AboutDlg_Do(hWnd);
            break;

            case CMD_DIALOG:
                 {
                  DLGPROC lpfnDIALOGSMsgProc;

                  lpfnDIALOGSMsgProc = (DLGPROC)MakeProcInstance((FARPROC)DIALOGSMsgProc, _hInstance);
                  nRc = DialogBox(_hInstance, MAKEINTRESOURCE(100), hWnd, lpfnDIALOGSMsgProc);
                  FreeProcInstance((FARPROC)lpfnDIALOGSMsgProc);
                 }
                 break;

            default:
                return DefWindowProc(hWnd, Message, wParam, lParam);
           }
         break;        /* End of WM_COMMAND                             */

    case WM_CREATE:
         break;       /*  End of WM_CREATE                              */

    case WM_DESTROY:
         break;

    case WM_CLOSE:  /* close the window                                 */
         /* Destroy child windows, modeless dialogs, then, this window  */
         DestroyWindow(hWnd);
         if (hWnd == g_hWndMain)
           PostQuitMessage(0);  /* Quit the application                 */
        break;

    default:
         return DefWindowProc(hWnd, Message, wParam, lParam);
   }
 return 0L;
}


BOOL FAR PASCAL DIALOGSMsgProc(HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HWND hWndTB;

 switch(Message)
   {
    case WM_INITDIALOG:
       {
         TBBUTTON tbButton[8];
         cwCenter(hWndDlg, 0);

         hWndTB = GetDlgItem(hWndDlg, 101);

         SendMessage(hWndTB,TB_ADDBITMAP,9,MAKELONG(_hInstance,IDR_TOOLICONS));

         tbButton[0].iBitmap=4;
         tbButton[0].idCommand=200;
         tbButton[0].fsState = TBSTATE_ENABLED|TBSTATE_CHECKED;
         tbButton[0].fsStyle = TBSTYLE_CHECK;

         tbButton[1].iBitmap=7;
         tbButton[1].idCommand=201;
         tbButton[1].fsState = TBSTATE_ENABLED;
         tbButton[1].fsStyle = TBSTYLE_BUTTON;

         tbButton[2].iBitmap=-1;
         tbButton[2].idCommand=202;
         tbButton[2].fsState = TBSTATE_ENABLED;
         tbButton[2].fsStyle = TBSTYLE_SEP;

         tbButton[3].iBitmap=0;
         tbButton[3].idCommand=203;
         tbButton[3].fsState = TBSTATE_ENABLED;
         tbButton[3].fsStyle = TBSTYLE_CHECKGROUP;

         tbButton[4].iBitmap=1;
         tbButton[4].idCommand=204;
         tbButton[4].fsState = TBSTATE_ENABLED;
         tbButton[4].fsStyle = TBSTYLE_CHECKGROUP;

         tbButton[5].iBitmap=2;
         tbButton[5].idCommand=205;
         tbButton[5].fsState = TBSTATE_ENABLED;
         tbButton[5].fsStyle = TBSTYLE_CHECKGROUP;

         SendMessage(hWndTB,TB_ADDBUTTONS,6, (LPARAM)(LPTBBUTTON)tbButton);
       }
         break; /* End of WM_INITDIALOG                                 */

    case WM_CLOSE:
         /* Closing the Dialog behaves the same as Cancel               */
         PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
         break; /* End of WM_CLOSE                                      */

    case WM_COMMAND:
         switch(wParam)
           {
            case IDOK:
                 EndDialog(hWndDlg, FALSE);
                 break;

            case 102:
                 SendMessage(GetDlgItem(hWndDlg, 101), TB_ENABLEBUTTON, 201, MAKELONG(FALSE,0));
                 break;

            case 103:
                 SendMessage(GetDlgItem(hWndDlg, 101), TB_ENABLEBUTTON, 201, MAKELONG(TRUE,0));
                 break;
           }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
 return TRUE;
}


int nCwRegisterClasses(void)
{
 WNDCLASS   wndclass;    /* struct to define a window class             */
 memset(&wndclass, 0x00, sizeof(WNDCLASS));


 /* load WNDCLASS with window's characteristics                         */
 wndclass.style = CS_HREDRAW | CS_VREDRAW | CS_BYTEALIGNWINDOW;
 wndclass.lpfnWndProc = WndProc;
 /* Extra storage for Class and Window objects                          */
 wndclass.cbClsExtra = 0;
 wndclass.cbWndExtra = 0;
 wndclass.hInstance = _hInstance;
 wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
 wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
 /* Create brush for erasing background                                 */
 wndclass.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
 wndclass.lpszMenuName = szAppName;   /* Menu Name is App Name */
 wndclass.lpszClassName = szAppName; /* Class Name is App Name */
 if(!RegisterClass(&wndclass))
   return -1;


 return(0);
}

void cwCenter(hWnd, top)
HWND hWnd;
int top;
{
 POINT      pt;
 RECT       swp;
 RECT       rParent;
 int        iwidth;
 int        iheight;

 /* get the rectangles for the parent and the child                     */
 GetWindowRect(hWnd, &swp);
 GetClientRect(g_hWndMain, &rParent);

 /* calculate the height and width for MoveWindow                       */
 iwidth = swp.right - swp.left;
 iheight = swp.bottom - swp.top;

 /* find the center point and convert to screen coordinates             */
 pt.x = (rParent.right - rParent.left) / 2;
 pt.y = (rParent.bottom - rParent.top) / 2;
 ClientToScreen(g_hWndMain, &pt);

 /* calculate the new x, y starting point                               */
 pt.x = pt.x - (iwidth / 2);
 pt.y = pt.y - (iheight / 2);

 /* top will adjust the window position, up or down                     */
 if(top)
   pt.y = pt.y + top;

 /* move the window                                                     */
 MoveWindow(hWnd, pt.x, pt.y, iwidth, iheight, FALSE);
}

void CwUnRegisterClasses(void)
{
 WNDCLASS   wndclass;    /* struct to define a window class             */
 memset(&wndclass, 0x00, sizeof(WNDCLASS));

 UnregisterClass(szAppName, _hInstance);
}

// Simple Help About box
//
VOID AboutDlg_Do(HWND hwndOwner)
{
    DLGPROC lpfndp;

    lpfndp = (DLGPROC)MakeProcInstance((FARPROC)AboutDlg_DlgProc, _hInstance);

    if (!lpfndp)
        return;

    DialogBoxParam(_hInstance, MAKEINTRESOURCE(IDR_ABOUTDLG),
            hwndOwner, lpfndp, 0L);

    FreeProcInstance((FARPROC)lpfndp);
}

BOOL CALLBACK _export AboutDlg_DlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_COMMAND:
        if (wParam == IDOK || wParam == IDCANCEL)
            EndDialog(hwndDlg, TRUE);
        return TRUE;
        break;

    case WM_INITDIALOG:
        return TRUE;
    }
    return FALSE;
}
