//***************************************************************************
//
//  Module:   modrept.c
//
//  Purpose:
//      Issues a report on the debugging output monitor containing
//      information about the current module, including task handle,
//      instance handle, module handle, module filename, and module 
//      usage count.
//
//  Description of functions:
//      ModuleReport - given an hInstance, reports on current module.
//
//---------------------------------------------------------------------------
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#define NOGDI               // speed up compilation by excluding     
#define NOSOUND             // unused definitions from WINDOWS.H
#define NOCOMM              // ...
#define NODRIVERS           // ...
#define STRICT              // increased error checking
#include <windows.h>    
#include "modrept.h"        // module reporting function
                            
#define BUFF_SIZE 160   

BOOL ModuleReport(HINSTANCE hInstance)
{
    char szBuff[BUFF_SIZE];
    char szModuleName[BUFF_SIZE];
    HMODULE hModule;
    HTASK hTask;
    int cModuleUsage;

// We know the hInstance.  Get the task handle, module handle, 
// module usage count, and module filename...
    if ((hTask = GetCurrentTask()) == NULL)
        OutputDebugString("GetCurrentTask() failed\n\r");
    if ((hModule = GetModuleHandle(MAKELP(NULL, hInstance))) == NULL)
        OutputDebugString("GetModuleHandle() failed\n\r");
    cModuleUsage = GetModuleUsage (hModule);
    if ((GetModuleFileName(hModule, szModuleName, BUFF_SIZE)) == NULL)
        OutputDebugString("GetModuleFileName failed\n\r");
        
// Output the fully-qualified module file name...
    wsprintf (szBuff, "Module: %ls\n\r", (LPSTR) szModuleName);
    OutputDebugString (szBuff);

// Output the task, instance, and module handles, and usage count...
    wsprintf(szBuff, "hTask\thInst\thModule\tUsage\n\r%X\t%X\t%X\t%d\n\r",
             hTask, hInstance, hModule, cModuleUsage);
    OutputDebugString(szBuff);
    return TRUE;
}

//***************************************************************************
//  End of File: modrept.c
//***************************************************************************

