//***************************************************************************
//
//  Module:   lib1.c
//
//  Purpose:
//  	Extremely simple Windows library which reports
//      module, instance, and task information on the debugging monitor,
//      then calls a similar function in LIB2.DLL.
//
//      This module calls LIB2.DLL
//
//      Run DBWin to see the debugging output.
//  	
//  Description of functions:
//      Lib1Func()  The DLL's exported function.  Called by APP1.EXE.
//      LibMain()   The DLL initialization function (called by LibEntry)
//      WEP()       The DLL termination function.
//
//---------------------------------------------------------------------------
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#define NOUSER
#define NOGDI           // speed up compilation by excluding 
#define NOSOUND         // unused definitions from WINDOWS.H
#define NOCOMM          // ...
#define NODRIVERS       // ...
#define STRICT          // increased error checking
#include <windows.h>
#include "lib2.h"       // exported symbols from LIB2.DLL
#include "modrept.h"    // module reporting function

// Function prototypes local to this module...
int FAR PASCAL LibMain (HINSTANCE, WORD, WORD, LPSTR);
int __export FAR PASCAL WEP (int);

// Global variables for this module...
HINSTANCE hLibInstance = NULL;


//************************************************************************
//  int __export FAR PASCAL Lib1Func(void)
//
//  Description:
//      The exported DLL function to be called by outside modules.
//      Reports instance, task, module information then calls the
//      next DLL.
//
//************************************************************************

int __export FAR PASCAL Lib1Func(void)
{
    OutputDebugString("***Lib1Func()\n\r");
    ModuleReport(hLibInstance);
    Lib2Func();
    return(1);
} // end of Lib1Func()

//************************************************************************
//  int FAR PASCAL LibMain(hModule, wDataSeg, cbHeapSize, lpszCmdLine)
//
//  Description:
//      The DLL's initialization function.  Called by LibEntry().
//
//  Comments:
//      Uses #pragma alloc_text to force function into INIT_TEXT segment.
//      This segment is marked PRELOAD MOVEABLE DISCARDABLE in .DEF file.
//
//************************************************************************

#pragma alloc_text (INIT_TEXT, LibMain)

int FAR PASCAL LibMain(hModule, wDataSeg, cbHeapSize, lpszCmdLine)
HINSTANCE   hModule;
WORD        wDataSeg;
WORD        cbHeapSize;
LPSTR       lpszCmdLine;
{
    hLibInstance = hModule;  // Remember our library's instance handle
    OutputDebugString("***LibMain of LIB1\n\r");
    return (1);
} // end of LibMain()


//************************************************************************
//  int __export FAR PASCAL WEP (bSystemExit)
//
//  Description:
//      The DLL's termination function.  Called when DLL is shutting down.
//
//  Comments:
//      Uses #pragma alloc_text to force function into WEP_TEXT segment.
//      This segment is marked PRELOAD FIXED in .DEF file.
//
//************************************************************************

#pragma alloc_text (WEP_TEXT, WEP)

int __export FAR PASCAL WEP (bSystemExit)
int  bSystemExit;
{
    OutputDebugString("***WEP of LIB1\n\r");
    return(1);
} // end of WEP()

//***************************************************************************
//  End of File: lib1.c
//***************************************************************************

