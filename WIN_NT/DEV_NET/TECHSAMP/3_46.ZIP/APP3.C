//***************************************************************************
//
//  Module:   app3.c
//
//  Purpose:
//  	Extremely simple (1-function) Windows application which reports
//      module, instance, and task information on the debugging monitor,
//      calls a DLL function which does the same, puts up a MessageBox
//      to wait for user response, then terminates.  
//
//      This module calls LIB3.DLL
//  
//      Run DBWin to see the debugging output.
//
//  Description of functions:
//      WinMain()       This time it's WinMain-Lite (it does very little).
//
//---------------------------------------------------------------------------
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#define NOGDI           // speed up compilation by excluding 
#define NOSOUND         // unused definitions from WINDOWS.H
#define NOCOMM          // ...
#define NODRIVERS       // ...
#define STRICT          // increased error checking
#include <windows.h>
#include "lib3.h"       // exported symbols from LIB3.DLL
#include "modrept.h"    // module reporting function

char szMsg[80];         // used for outputting strings to debug monitor

int PASCAL WinMain (HINSTANCE hInst,
                    HINSTANCE hPrev,
                    LPSTR lpszCmd,
                    int nCmd)
{
    OutputDebugString("***App3: Entering WinMain\n\r");
    ModuleReport(hInst);
    Lib3Func();
    wsprintf(szMsg, "hInst %X Yielding", hInst);
    MessageBox(NULL, "App3 WinMain\n(watch debugging monitor)", szMsg, MB_OK);
    OutputDebugString("***App3: Exiting WinMain\n\r\n\r");
    return(0);
}

//***************************************************************************
//  End of File: app3.c
//***************************************************************************
