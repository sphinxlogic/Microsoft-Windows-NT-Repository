/****************************************************************************

    PROGRAM: CountDOS.c

    PURPOSE: Communicates with a TSR and counts number of DOS calls

    FUNCTIONS:

	WinMain() - calls initialization function, processes message loop
	InitApplication() - initializes window data and registers window
	InitInstance() - saves instance handle and creates main window
	MainWndProc() - processes messages
	About() - processes messages for "About" dialog box

    COMMENTS:

        Windows can have several copies of your application running at the
        same time.  The variable hInst keeps track of which instance this
        application is so that processing will be to the correct window.

****************************************************************************/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//   

#include "windows.h"		    /* required for all Windows applications */

#include "countdos.h"		    /* specific to this program 	     */
#include "wintime.h"		    /* time formatting routines 	     */

extern InstallConfirmProc();	    /* these functions are in...	     */
extern RemoveConfirmProc();	    /* ...callback.asm (assembler routines)  */

HANDLE hInst;			    /* current instance			     */

WORD   Selector = 0;		    /* selector to TSR's data block          */
extern WORD Selector;

char   szStatusText[128];	    /* text in status bar		     */
int    iStatusPrefLen;		    /* length of constant prefix of status   */

/****************************************************************************

    FUNCTION: BOOL ascii_to_hex(LPSTR, LPINT)

    PURPOSE: converts an ascii representation of a word to an integer

    COMMENTS:

	The string must contain a 4-character ascii representation of an
	integer (in hexadecimal format).
	The result is stored in the integer pointed to by the second parameter.

	Returns TRUE if conversion succesful, FALSE otherwise.

****************************************************************************/

BOOL ascii_to_hex( LPSTR ascii, LPINT hex )
{
    int i,j;

    for( i=0,j=0; j < 4; j++ )
    {
	i = i << 4;
	if( (ascii[j] >= '0') && (ascii[j] <= '9') )
	    i += ascii[j] - '0';
	else if( (ascii[j] >= 'a') && (ascii[j] <= 'f') )
	    i += 10 + ascii[j] - 'a';
	else if( (ascii[j] >= 'A') && (ascii[j] <= 'F') )
	    i += 10 + ascii[j] - 'A';
	else
	    j = 5;
    }
    if( j < 5 )
    {
	*hex = i;
	return( TRUE );
    } else
	return( FALSE );
}


/****************************************************************************

    FUNCTION: RefreshCount( HWND hWnd )

    PURPOSE:  Update data on DOS calls

    COMMENTS:

****************************************************************************/

void NEAR RefreshCount( HWND hWnd, BOOL bRefresh )
{
    static  unsigned long    lTotal;
    char    szLine[128];
    LPSTR   lpszName;
    WORD i;
    static unsigned long    lCounts[256];
    extern PSTR DOScall_Name_Off_Table[];
    extern PSTR Unknown_DOScall;
    extern WORD LastKnownCall;

    if( bRefresh )
    {
	TimeGetCurTime( szStatusText+iStatusPrefLen, 0 );

	for( i=0; i < 256; i++ )
	    lCounts[i] = *((unsigned long far *)(MAKELONG( i*4, Selector )));
    }

    for( i=0,lTotal=0; i < 256; i++ )
	lTotal += lCounts[i];

    SendMessage( hWnd, WM_SETREDRAW, FALSE, 0L );
    SendMessage( hWnd, LB_RESETCONTENT, 0, 0L );
    for( i=0; i < 256; i++ )
    {
	unsigned int	 iPercent;

	if( !lCounts[i] )
    continue;

	if( i > LastKnownCall )
	    lpszName = (LPSTR)Unknown_DOScall;
	else
	    lpszName = (LPSTR)(DOScall_Name_Off_Table[i]);

	iPercent = (unsigned int)( 100 * lCounts[i] / lTotal );
	wsprintf( szLine, "%02X\t%10lu\t%3u%%\t%s",
		i, lCounts[i], iPercent, lpszName );
	SendMessage( hWnd, LB_ADDSTRING, 0, (LONG)(LPSTR)szLine );
    }

    wsprintf( szLine, "TOTAL DOS CALLS    %10lu", lTotal );
    SendMessage( hWnd, WM_SETREDRAW, TRUE, 0L );
    SendMessage( hWnd, LB_ADDSTRING, 0, (LONG)(LPSTR)szLine );

    return;
}

/****************************************************************************

    FUNCTION: ResetCount()

    PURPOSE:  Reset all DOS call counts to 0

    COMMENTS:

****************************************************************************/

void NEAR ResetCount()
{
    int     i;

    for( i=0; i < 256; i++ )
	*(LPINT)(MAKELONG( i*4, Selector ))=0L;

    return;
}


/****************************************************************************

    FUNCTION: ConfirmDelete( LPSTR lpfile )

    PURPOSE:  Ask the user to confirm deletion of specified file

    COMMENTS:
	    return TRUE if delete is confirmed,
	    FALSE otherwise

****************************************************************************/

BOOL NEAR PASCAL ConfirmDelete( LPSTR lpfile )
{
    char    szText[ 128 ];
    static char szCaption[] = "Confirm Delete";

    wsprintf( szText, "Delete file %s ?", lpfile );
    if( MessageBox( NULL, szText, szCaption, MB_YESNO | MB_ICONHAND | MB_SYSTEMMODAL)
	== IDNO )
	return( FALSE );
    else
	return( TRUE );
}



/****************************************************************************

    FUNCTION: WinMain(HANDLE, HANDLE, LPSTR, int)

    PURPOSE: calls initialization function, processes message loop

    COMMENTS:

        Windows recognizes this function by name as the initial entry point 
        for the program.  This function calls the application initialization 
        routine, if no other instance of the program is running, and always 
        calls the instance initialization routine.  It then executes a message 
        retrieval and dispatch loop that is the top-level control structure 
        for the remainder of execution.  The loop is terminated when a WM_QUIT 
        message is received, at which time this function exits the application 
        instance by returning the value passed by PostQuitMessage(). 

        If this function must abort before entering the message loop, it 
        returns the conventional value NULL.  

****************************************************************************/

int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HINSTANCE hInstance;			/* current instance	     */
HINSTANCE hPrevInstance;        /* previous instance	     */
LPSTR lpCmdLine;			    /* command line		     */
int nCmdShow;				    /* show-window type (open/icon) */
{
    MSG msg;				    /* message			     */

    if (!hPrevInstance)			 /* Other instances of app running? */
	if (!InitApplication(hInstance)) /* Initialize shared things */
	    return (FALSE);		 /* Exits if unable to initialize     */

    /* parse command line, if any */
    if( lpCmdLine && (lpCmdLine[0] == '/') && (lstrlen( lpCmdLine ) >= 9) )
    {
	WORD   TSRData_seg, TSRData_off;

	if( ascii_to_hex( lpCmdLine+1, &TSRData_seg ) &&
	    ascii_to_hex( lpCmdLine+6, &TSRData_off ) )
	{
	    DWORD   linaddr;

	    if( Selector = AllocSelector( HIWORD( (LPSTR)szStatusText ) ) )
	    {
		/* set selector limit to 64K - returns 0 on success */
		if( SetSelectorLimit( Selector, 0xFFFFL ) )
		{
		    FreeSelector( Selector );
		    Selector = 0;
		} else {
		    linaddr = ((DWORD)TSRData_seg << 4) + (DWORD)TSRData_off;
		    if( !SetSelectorBase( Selector, linaddr ) )
		    {
			FreeSelector( Selector );
			Selector = 0;
		    } /* if */
		} /* else */
	    } /* if */
	} /* if */
    } /* if */

    if (!InitInstance(hInstance, nCmdShow ))
        return (FALSE);

    /* Acquire and dispatch messages until a WM_QUIT message is received. */

    while (GetMessage(&msg,	   /* message structure			     */
	    NULL,		   /* handle of window receiving the message */
	    NULL,		   /* lowest message to examine		     */
	    NULL))		   /* highest message to examine	     */
	{
	TranslateMessage(&msg);	   /* Translates virtual key codes	     */
	DispatchMessage(&msg);	   /* Dispatches message to window	     */
    }
    return (msg.wParam);	   /* Returns the value from PostQuitMessage */
}


/****************************************************************************

    FUNCTION: InitApplication(HANDLE)

    PURPOSE: Initializes window data and registers window class

    COMMENTS:

        This function is called at initialization time only if no other 
        instances of the application are running.  This function performs 
        initialization tasks that can be done once for any number of running 
        instances.  

        In this case, we initialize a window class by filling out a data 
        structure of type WNDCLASS and calling the Windows RegisterClass() 
        function.  Since all instances of this application use the same window 
        class, we only need to do this when the first instance is initialized.  


****************************************************************************/

BOOL InitApplication(hInstance)
HANDLE hInstance;			       /* current instance	     */
{
    WNDCLASS  wc;

    /* Fill in window class structure with parameters that describe the       */
    /* main window.                                                           */

    wc.style = NULL;                    /* Class style(s).                    */
    wc.lpfnWndProc = MainWndProc;       /* Function to retrieve messages for  */
                                        /* windows of this class.             */
    wc.cbClsExtra = 0;                  /* No per-class extra data.           */
    wc.cbWndExtra = 0;                  /* No per-window extra data.          */
    wc.hInstance = hInstance;           /* Application that owns the class.   */
    wc.hIcon = LoadIcon(hInstance, "CountDOSIcon");
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = GetStockObject(WHITE_BRUSH); 
    wc.lpszMenuName =  "CountDOSMenu";	 /* Name of menu resource in .RC file. */
    wc.lpszClassName = "CountDOSWClass"; /* Name used in call to CreateWindow. */

    /* Register the window class and return success/failure code. */

    return (RegisterClass(&wc));

}


/****************************************************************************

    FUNCTION:  InitInstance(HANDLE, int )

    PURPOSE:  Saves instance handle and creates main window

    COMMENTS:

        This function is called at initialization time for every instance of 
        this application.  This function performs initialization tasks that 
        cannot be shared by multiple instances.  

        In this case, we save the instance handle in a static variable and 
	create and display the main program window.

****************************************************************************/

BOOL InitInstance(hInstance, nCmdShow )
    HANDLE	    hInstance;		/* Current instance identifier.      */
    int 	    nCmdShow;		/* Param for first ShowWindow() call.*/
{
    HWND	    hWnd;		/* Main window handle.		     */
    char	    szWinTitle[128];	/* Window Title 		     */

    /* Save the instance handle in static variable, which will be used in    */
    /* many subsequence calls from this application to Windows. 	     */

    hInst = hInstance;

    /* load strings from resource file */
    LoadString( hInst, IDS_APPNAME, szWinTitle, 127 );

    if( !Selector )
    {
	char  szErrorMsg[128];

	LoadString( hInst, IDS_NOTTSR, szErrorMsg, 127 );
	MessageBox( NULL, szErrorMsg, szWinTitle, MB_OK );
	return( FALSE );
    }

    LoadString( hInst, IDS_STATUSMSG, szStatusText, 127 );
    iStatusPrefLen = lstrlen( szStatusText );

    /* initialize time-formatting routines */
    TimeResetInternational();

    /* Create a main window for this application instance.  */

    hWnd = CreateWindow(
	"CountDOSWClass",	       /* See RegisterClass() call.	     */
	szWinTitle,		      /* Text for window title bar.	    */
	WS_OVERLAPPEDWINDOW,	      /* Window style.			    */
	CW_USEDEFAULT,		      /* Default horizontal position.	    */
	CW_USEDEFAULT,		      /* Default vertical position.	    */
	CW_USEDEFAULT,		      /* Default width. 		    */
	CW_USEDEFAULT,		      /* Default height.		    */
	NULL,			      /* Overlapped windows have no parent. */
	NULL,			      /* Use the window class menu.	    */
	hInstance,		      /* This instance owns this window.    */
	NULL			      /* Pointer not needed.		    */
    );

    /* If window could not be created, return "failure" */

    if (!hWnd)
        return (FALSE);

    /* reset the 'Windows starting up' flag in the TSR. This will indicate
     * that the TSR can do deletion confirmation again
     */

    *((LPWORD)MAKELONG( 257*4, Selector )) = 0;

    /* If Confirm Delete is currently active, allocate the call-back and
     * check the menu item
     */

    if( *((LPDWORD)MAKELONG( 256*4, Selector )))
    {
	HMENU	hMenu;

	InstallConfirmProc();
	hMenu = GetMenu( hWnd );
	CheckMenuItem( hMenu, IDM_CONFIRM, MF_BYCOMMAND | MF_CHECKED );
    }

    /* Make the window visible; update its client area; and return "success" */

    ShowWindow(hWnd, nCmdShow);  /* Show the window                        */
    UpdateWindow(hWnd);          /* Sends WM_PAINT message                 */
    return (TRUE);               /* Returns the value from PostQuitMessage */

}

/****************************************************************************

    FUNCTION: CountDOSPaint(HWND, HDC)

    PURPOSE:  Re-paint Window

    COMMENTS:


****************************************************************************/

void NEAR PASCAL CountDOSPaint( HWND hwnd, HDC hdc )
{
    RECT    sRect;
    DWORD   dTextExt;
    HBRUSH  hOldBrush;
    int     iOldMode;
    static  char    szHeader[128];
    static  int     iHeaderLen = 0;

    if( !iHeaderLen )
    {
    LoadString( hInst, IDS_HEADER, szHeader, 127 );
	iHeaderLen = lstrlen( szHeader );
    }

    dTextExt = GetTextExtent( hdc, szStatusText, lstrlen( szStatusText ) );
    GetClientRect( hwnd, &sRect );
    sRect.bottom = sRect.top + 2*(Y_INSIDE+Y_OUTSIDE) + HIWORD( dTextExt );
    FillRect( hdc, &sRect, GetStockObject( LTGRAY_BRUSH ) );
    hOldBrush = SelectObject( hdc, GetStockObject( BLACK_BRUSH ) );
    /* black line between status bar and column captions */
    PatBlt( hdc, 0, sRect.bottom, sRect.right, 1, PATCOPY );

    PatBlt( hdc, X_OUTSIDE, Y_OUTSIDE, LOWORD( dTextExt ) + 2*X_INSIDE, 1, PATCOPY );
    PatBlt( hdc, X_OUTSIDE, Y_OUTSIDE, 1, HIWORD( dTextExt ) + 2*Y_INSIDE, PATCOPY );

    SelectObject( hdc, GetStockObject( WHITE_BRUSH ) );
    PatBlt( hdc, X_OUTSIDE, sRect.bottom - Y_OUTSIDE, LOWORD( dTextExt ) + 2*X_INSIDE, 1, PATCOPY );
    PatBlt( hdc, LOWORD( dTextExt ) + X_OUTSIDE + 2*X_INSIDE, Y_OUTSIDE, 1, HIWORD( dTextExt ) + 2*Y_INSIDE, PATCOPY );

    SelectObject( hdc, GetStockObject( GRAY_BRUSH ) );
    PatBlt( hdc, X_OUTSIDE, Y_OUTSIDE-1, LOWORD( dTextExt ) + 2*X_INSIDE, 1, PATCOPY );
    PatBlt( hdc, X_OUTSIDE-1, Y_OUTSIDE, 1, HIWORD( dTextExt ) + 2*Y_INSIDE, PATCOPY );

    /* color in column header section */
    PatBlt( hdc, sRect.left, sRect.bottom+1, sRect.right - sRect.left,
	    HIWORD( dTextExt )+2*Y_INSIDE, PATCOPY );
    SelectObject( hdc, hOldBrush );
    iOldMode = SetBkMode( hdc, TRANSPARENT );
    TextOut( hdc, X_INSIDE+X_OUTSIDE, Y_INSIDE+Y_OUTSIDE, szStatusText, lstrlen( szStatusText ) );
    TextOut( hdc, X_INSIDE+X_OUTSIDE, sRect.bottom+1+Y_INSIDE, szHeader, iHeaderLen );
    if( iOldMode != TRANSPARENT )
	SetBkMode( hdc, iOldMode );

    return;
}

HWND NewListBox( HWND hParent, int width, int height, int TextHt )
{
    HWND    hwndList;
    int     iTabs[] = {25, 80, 110};
    int     left, top;

    left = X_INSIDE+X_OUTSIDE;
    width -= left;
    top = 2*TextHt + 5*Y_INSIDE + 2*Y_OUTSIDE - 1;
    height -= top;

    hwndList = CreateWindow( "listbox", NULL,
		 WS_CHILD | WS_VISIBLE | LBS_USETABSTOPS | WS_VSCROLL | LBS_NOINTEGRALHEIGHT,
		 left, top, width, height, hParent, (HMENU) 1, hInst, NULL );
    SendMessage( hwndList, LB_SETTABSTOPS, 3, (long)(LPINT)iTabs );

    return hwndList;
}

/****************************************************************************

    FUNCTION: MainWndProc( HWND, UINT, WPARAM, LPARAM);

    PURPOSE:  Processes messages

    MESSAGES:

	WM_COMMAND    - application menu (About dialog box)
	WM_DESTROY    - destroy window
	WM_PAINT      - paint window

    COMMENTS:

	To process the IDM_ABOUT message, call MakeProcInstance() to get the
	current instance address of the About() function.  Then call Dialog
	box which will create the box according to the information in your
	countDOS.rc file and turn control over to the About() function.  When
	it returns, free the intance address.

****************************************************************************/

LRESULT CALLBACK MainWndProc(hWnd, message, wParam, lParam)
HWND    hWnd;				  /* window handle		     */
UINT    message;			  /* type of message		     */
WPARAM  wParam;				  /* additional information	     */
LPARAM  lParam;				  /* additional information	     */
{
    DLGPROC lpProcAbout;		  /* pointer to the "About" function */
    PAINTSTRUCT  ps;
    static  HWND    hwndList = NULL;	  /* list box window handle	     */
    static  int     TextHt;

    switch (message) {
	case WM_COMMAND:	   /* message: command from application menu */
	    switch( wParam )
	    {
	        case IDM_ABOUT:
		        lpProcAbout = (DLGPROC) MakeProcInstance( (FARPROC) About,
                                            hInst);
		        DialogBox(hInst,		 /* current instance	     */
		            "AboutBox",			 /* resource to use	     */
		            hWnd,			     /* parent handle	     */
		            lpProcAbout);		 /* About() instance address */

		        FreeProcInstance((FARPROC)lpProcAbout);
		        break;

	        case IDM_RESET:
		        ResetCount();

		        /* fall through, and refresh too */

	        case IDM_REFRESH:
		        InvalidateRect( hWnd, NULL, FALSE );
		        RefreshCount( hwndList, TRUE );
		        break;

	        case IDM_CONFIRM:
		    {
		        HMENU hMenu;

		        hMenu = GetMenu( hWnd );
		        if( CheckMenuItem( hMenu, IDM_CONFIRM,
			        MF_BYCOMMAND | MF_CHECKED ) == MF_CHECKED )
		        {
			        CheckMenuItem( hMenu, IDM_CONFIRM,
			            MF_BYCOMMAND | MF_UNCHECKED );
			        RemoveConfirmProc();
		        } else
			        InstallConfirmProc();
		    }
		    break;

	        default:			    /* Lets Windows process it	     */
		        return (DefWindowProc(hWnd, message, wParam, lParam));
	    } //end WM_COMMAND
	    break;

	case WM_CREATE:
	    {
		HDC	hdc;
		RECT	sRect;

		hdc = GetDC( hWnd );
		TextHt = HIWORD( GetTextExtent( hdc, szStatusText,
				 lstrlen( szStatusText ) ) );
		ReleaseDC( hWnd, hdc );
		GetClientRect( hWnd, &sRect );
		hwndList = NewListBox( hWnd, sRect.right, sRect.bottom, TextHt );
		SendMessage( hWnd, WM_COMMAND, IDM_REFRESH, 0L );
	    }
	    break;

	case WM_SIZE:
	    {
		if( hwndList )
		    DestroyWindow( hwndList );

		hwndList = NewListBox( hWnd, LOWORD( lParam ), HIWORD( lParam ),
			    TextHt );
		RefreshCount( hwndList, FALSE );
	    }
	    break;

	case WM_DESTROY:		  /* message: window being destroyed */
	    PostQuitMessage(0);
	    RemoveConfirmProc();
	    break;

	case WM_ENDSESSION:
	    if( wParam )
		RemoveConfirmProc();
	    break;

	case WM_PAINT:
	    BeginPaint(hWnd, &ps);
	    CountDOSPaint(hWnd, ps.hdc);
	    EndPaint(hWnd, &ps);
            break;

	default:			  /* Passes it on if unproccessed    */
	    return (DefWindowProc(hWnd, message, wParam, lParam));
    }
    return (NULL);
}


/****************************************************************************

    FUNCTION: About(HWND, UINT, WPARAM, LPARAM)

    PURPOSE:  Processes messages for "About" dialog box

    MESSAGES:

	WM_INITDIALOG - initialize dialog box
	WM_COMMAND    - Input received

    COMMENTS:

	No initialization is needed for this particular dialog box, but TRUE
	must be returned to Windows.

	Wait for user to click on "Ok" button, then close the dialog box.

****************************************************************************/

BOOL CALLBACK About(hDlg, message, wParam, lParam)
HWND hDlg;                            /* window handle of the dialog box */
UINT message;                         /* type of message                 */
WPARAM wParam;                        /* message-specific information    */
LPARAM lParam;
{
    switch (message) {
	case WM_INITDIALOG:		   /* message: initialize dialog box */
	    return (TRUE);

	case WM_COMMAND:		      /* message: received a command */
	    if (wParam == IDOK                /* "OK" box selected?	     */
                || wParam == IDCANCEL) {      /* System menu close command? */
		EndDialog(hDlg, TRUE);	      /* Exits the dialog box	     */
		return (TRUE);
	    }
	    break;
    }
    return (FALSE);			      /* Didn't process a message    */
}
