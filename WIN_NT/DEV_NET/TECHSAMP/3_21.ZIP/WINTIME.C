/************************************************************************
 *
 *      Module:  WINTIME.C
 *
 *
 *     Remarks:
 *
 *    This module contains functions for managing time and date strings
 *    using internationalization.
 *
 *    The functions in this module assume that all WIN.INI international
 *    settings are valid.  If the settings are not there (which is the
 *    case until a change is made through control panel) defaults are
 *    used.
 *
 *    If the WIN.INI strings (such as the sLongDate string) is invalid
 *    in someway (i.e. it was NOT written by Control Panel) this code
 *    will probably break.
 *
 ************************************************************************/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

// #define WINDLL
#include "windows.h"
#include "time.h"
#include "string.h"

#include "WINTIME.H"

/************************************************************************
 * Imported variables
 ************************************************************************/
//
// This should be the hInst of the module that contains the string
// resources for the day and month strings.  If these functions are
// put into a DLL, hInst should be the hModule passed to LibMain
//
extern HANDLE hInst ;

/************************************************************************
 * Local Defines
 ************************************************************************/
#define SZDEF_LONGDATE  "ddd', 'MMMM' 'dd', 'yyyy"
#define LEN_LONGDATE    34

#define SZDEF_SHORTDATE "MM/dd/yy"
#define LEN_SHORTDATE   11

/************************************************************************
 * Macros 
 ************************************************************************/
#define YEAR(datetime)  (datetime -> tm_year % 100)
#define MONTH(datetime) (datetime -> tm_mon  + 1)
#define MDAY(datetime)  (datetime -> tm_mday)
#define WDAY(datetime)  (datetime -> tm_wday)
#define HOUR(datetime)  (datetime -> tm_hour)
#define MIN(datetime)   (datetime -> tm_min)
#define SEC(datetime)   (datetime -> tm_sec)

/************************************************************************
 * Internal APIs and data structures
 ************************************************************************/
LPSTR NEAR PASCAL TimeFormatLongDate( LPSTR lpszDate,
                                      struct tm FAR *lpTM, WORD wFlags ) ;

LPSTR NEAR PASCAL TimeFormatShortDate( LPSTR lpszDate,
                                       struct tm FAR *lpTM, WORD wFlags ) ;

/************************************************************************
 * Local Variables
 *
 * Remember:  If this code goes into a DLL these variables will reside in
 * the DLLs data segment.  Thus 1) The DLL should NOT be a CODE only DLL,
 * and 2) these variables will be shared by all applications using the DLL.
 *
 *    These variables must be initialized by calling the
 *    TimeResetInternational() function.  If you are putting this in
 *    in a DLL then call this function in your LibMain.
 *
 *    Then, in your application, call TimeResetInternational everytime
 *    you detect that the [intl] section of the WIN.INI has changed.
 *    You do this by processing the WM_WININICHANGE message and
 *    comparing (LPSTR)lParam to "intl".
 *
 ************************************************************************/
char  sDate[3],
      sTime[3],
      sAMPM[3][6] ;

char  sShortDate[LEN_SHORTDATE+1] ;
char  sLongDate[LEN_LONGDATE+1] ;

int   iTime,
      iTLzero ;

char  szWday[7][13], szShortWday[7][5],
      szMonth[12][13], szShortMonth[12][5] ;

LONG        lTime ;
struct tm FAR *lpTM ;

/************************************************************************
 * Exported Functions
 ************************************************************************/
/*************************************************************************
 *  LPSTR FAR PASCAL TimeGetCurDate( LPSTR lpszDate, WORD wFlags )
 *
 *  Description:
 *    Function returns the current date, formatted the way windows
 *    wants it!
 *
 *  Arguments:
 *    Type/Name
 *             Description
 *
 *    LPSTR lpszDate
 *             Points to a buffer that is to recieve the date.  Must be
 *             large enough to hold the longest date possible (64 bytes
 *             should do it).
 *
 *    WORD  wFlags
 *             Specifies flags that modify the behavior of the function.
 *             May be any of the following.
 *
 *          Flag              Meaning
 *          0                 The date will be formatted exactly the way
 *                            Control Panel does it, using Windows'
 *                            international settings.  The date will be in
 *                            the Long Date format (Sunday, January 1, 1991).
 *
 *          DATE_SHORTDATE    Forces the date to be formatted using the
 *                            Short Date Format (1/01/91).
 *
 *          DATE_NODAYOFWEEK  The date will be formatted without the
 *                            day of week.  This flag may not be used with
 *                            the DATE_SHORTDATE flag.
 *                            (i.e. January 1, 1991)
 *
 *  Comments:
 *
 *************************************************************************/
LPSTR FAR PASCAL TimeGetCurDate( LPSTR lpszDate, WORD wFlags )
{
   time( &lTime ) ;
   lpTM = localtime( &lTime ) ;
   return TimeFormatDate( lpszDate, lpTM, wFlags ) ;
}

/*************************************************************************
 *  LPSTR FAR PASCAL TimeFormatDate( LPSTR lpszDate,
 *                                   struct tm FAR *lpTM,
 *                                   WORD wFlags )
 *
 *  Description:
 *    Function returns the date, specified in the tm structure,
 *    formatted the way windows
 *    wants it!
 *
 *  Arguments:
 *    Type/Name
 *             Description
 *
 *    LPSTR lpszDate
 *             Points to a buffer that is to recieve the date.  Must be
 *             large enough to hold the longest date possible (64 bytes
 *             should do it).
 *
 *    struct tm *lpTM
 *             Pointer to a "tm" structure (from time.h) that contains
 *             the time and date you want formatted.
 *
 *    WORD  wFlags
 *             Specifies flags that modify the behavior of the function.
 *             May be any of the following.
 *
 *          Flag              Meaning
 *          0                 The date will be formatted exactly the way
 *                            Control Panel does it, using Windows'
 *                            international settings.  The date will be in
 *                            the Long Date format (Sunday, January 1, 1991).
 *
 *          DATE_SHORTDATE    Forces the date to be formatted using the
 *                            Short Date Format (1/01/91).
 *
 *          DATE_NODAYOFWEEK  The date will be formatted without the
 *                            day of week.  This flag may not be used with
 *                            the DATE_SHORTDATE flag.
 *                            (i.e. January 1, 1991)
 *
 *  Comments:
 *    The functions related to this are long and complex.
 *    Because of the way Windows
 *    stores the internationalization info in the WIN.INI there is
 *    really no elegant way of doing this.  If you come up with
 *    a cleaner way please let me know.
 *
 *************************************************************************/
LPSTR FAR PASCAL TimeFormatDate( LPSTR lpszDate,
                                 struct tm FAR *lpTM,
                                 WORD wFlags )
{                               
   // 
   // See if it's to be short or long
   //
   if (wFlags & DATE_SHORTDATE)
      TimeFormatShortDate( lpszDate, lpTM, wFlags ) ;
   else  // Longdate
      TimeFormatLongDate( lpszDate, lpTM, wFlags ) ;

   return lpszDate ;

}/* TimeFormatDate() */

/*************************************************************************
 *  LPSTR FAR PASCAL TimeGetCurTime( LPSTR lpszTime, WORD wFlags )
 *
 *  Description: 
 *    Function returns the current time, formatted the way windows
 *    wants it!
 *
 *  Arguments:
 *    Type/Name
 *             Description
 *
 *    LPSTR lpszTime
 *             Points to a buffer that is to recieve the formatted time.
 *             Must be large enough to hold the longest date possible
 *             (64 bytes should do it).
 *
 *    WORD  wFlags
 *             Specifies flags that modify the behavior of the function.
 *             May be any of the following.
 *
 *          Flag              Meaning
 *          0                 The time will be formatted exactly the way
 *                            Control Panel does it, using Windows'
 *                            international settings. (i.e. 1:00:00 AM)
 *
 *          TIME_12HOUR       The time will be formatted in 12 hour format
 *                            regardless of the WIN.INI internationalization
 *                            settings.  This flag may not be used with the
 *                            TIME_24HOUR flag. (i.e. 2:32:10 PM)
 *                            
 *          TIME_24HOUR       The time will be formatted in 24 hour format
 *                            regardless of the WIN.INI internationalization
 *                            settings.  This flag may not be used with the
 *                            TIME_12HOUR flag. (i.e. 14:32:10)
 *
 *          TIME_NOSECONDS    The time will be formatted without seconds.
 *                            (i.e. 2:32 PM)
 *
 *  Comments:
 *
 *************************************************************************/
LPSTR FAR PASCAL TimeGetCurTime( LPSTR lpszTime, WORD wFlags )
{
   // 
   // Get current time
   //
   time( &lTime ) ;
   lpTM = localtime( &lTime ) ;

   return TimeFormatTime( lpszTime, lpTM, wFlags ) ;
}


/*************************************************************************
 *  LPSTR FAR PASCAL TimeFormatTime( LPSTR lpszTime,
 *                                   struct tm FAR *lpTM,
 *                                   WORD wFlags )
 *
 *  Description:
 *    Function returns the time, specified in the tm structure,
 *    formatted the way windows
 *    wants it!
 *
 *  Arguments:
 *    Type/Name
 *             Description
 *
 *    LPSTR lpszTime
 *             Points to a buffer that is to recieve the formatted time.
 *             Must be large enough to hold the longest date possible
 *             (64 bytes should do it).
 *
 *    struct tm *lpTM
 *             Pointer to a "tm" structure (from time.h) that contains
 *             the time and date you want formatted.
 *
 *    WORD  wFlags
 *             Specifies flags that modify the behavior of the function.
 *             May be any of the following.
 *
 *          Flag              Meaning
 *          0                 The time will be formatted exactly the way
 *                            Control Panel does it, using Windows'
 *                            international settings. (i.e. 1:00:00 AM)
 *
 *          TIME_12HOUR       The time will be formatted in 12 hour format
 *                            regardless of the WIN.INI internationalization
 *                            settings.  This flag may not be used with the
 *                            TIME_24HOUR flag. (i.e. 2:32:10 PM)
 *                            
 *          TIME_24HOUR       The time will be formatted in 24 hour format
 *                            regardless of the WIN.INI internationalization
 *                            settings.  This flag may not be used with the
 *                            TIME_12HOUR flag. (i.e. 14:32:10)
 *
 *          TIME_NOSECONDS    The time will be formatted without seconds.
 *                            (i.e. 2:32 PM)
 *
 *  Comments:
 *
 *************************************************************************/
LPSTR FAR PASCAL TimeFormatTime( LPSTR lpszTime, struct tm FAR *lpTM, WORD wFlags )
{
   char szFmt[32] ;
   char szTemp[32] ;
   LPSTR lpTemp;
   int	i;

   //
   // Leading zero?
   //
   if (iTLzero)
      lstrcpy( szFmt, "%02d" ) ;
   else
      lstrcpy( szFmt, "%d" ) ;

   //
   // See if we want seconds...
   // 
   if (wFlags & TIME_NOSECONDS)
   {
      wsprintf( szTemp, "%s%s%s",
               (LPSTR)szFmt,
               (LPSTR)sTime,
	       (LPSTR)"%02d " ) ;
   }
   else               // HH :MM :SS
      wsprintf( szTemp, "%s%s%s%s%s",
               (LPSTR)szFmt,
               (LPSTR)sTime,
               (LPSTR)"%02d",
               (LPSTR)sTime,
	       (LPSTR)"%02d " ) ;

   //
   // see if we want 12 hour or 24 hour format.
   //
   if (wFlags & TIME_24HOUR || iTime)
   {
      if (wFlags & TIME_NOSECONDS)
	 wsprintf( lpszTime, szTemp, HOUR( lpTM ), MIN( lpTM ) ) ;
      else
	 wsprintf( lpszTime, szTemp, HOUR( lpTM ), MIN( lpTM ), SEC( lpTM ) ) ;
      if( iTime )
	 lpTemp = sAMPM[1];	// could be 'GMT'-type suffix
      else
	 lpTemp = NULL; 	// we are forcing 24-hour, so the suffix
				// is wrong (ie: 'PM' instead of 'GMT').
				// Better to use nothing at all in this case.
   }
   else
   {
      if (wFlags & TIME_NOSECONDS)
         wsprintf( lpszTime, szTemp,
		   (HOUR( lpTM ) % 12) ? (HOUR( lpTM ) % 12) : 12,
		   MIN( lpTM ) ) ;
      else
         wsprintf( lpszTime, szTemp,
                   (HOUR( lpTM ) % 12) ? (HOUR( lpTM ) % 12) : 12,
		   MIN( lpTM ), SEC( lpTM ) ) ;
      lpTemp = sAMPM[HOUR( lpTM ) / 12] ;
   }

   if( lpTemp )
      lstrcat( lpszTime, lpTemp );

   //
   // remove trailing blanks
   //
   i = lstrlen( lpszTime ) - 1;
   while( lpszTime[i] == ' ' )
      lpszTime[i--] = 0;

   return lpszTime ;   

}/* TimeGetCurTime() */


/*************************************************************************
 *  void FAR PASCAL TimeResetInternational( void ) ;
 *
 *  Description:
 *    This function sets some local static variables to Windows' current
 *    time and date settings.
 *
 *    It should be called everytime a WM_WININICHANGE is sent for the
 *    intl section.
 *
 *    The variables here are in the DLLs data segment so if one app
 *    changes the stuff, the others will see it.
 *
 *  Comments:
 *
 *************************************************************************/
void FAR PASCAL TimeResetInternational( void )
{
   static char szIntl[] = "intl" ;

   iTime = GetProfileInt( szIntl, "iTime", 0 ) ;
   iTLzero = GetProfileInt( szIntl, "iTLzero", 1 ) ;

   GetProfileString( szIntl, "sDate", "/", sDate,  2 ) ;

   GetProfileString( szIntl, "sTime", ":", sTime,  2 ) ;

   GetProfileString( szIntl, "s1159", "AM", sAMPM[0],  5 ) ;

   GetProfileString( szIntl, "s2359", "PM", sAMPM[1],  5 ) ;

   GetProfileString( szIntl, "sShortDate", SZDEF_SHORTDATE, sShortDate,
      LEN_SHORTDATE ) ;

   GetProfileString( szIntl, "sLongDate", SZDEF_LONGDATE, sLongDate,
      LEN_LONGDATE ) ;

   if (*szWday[0] == '\0')
   {
      WORD i ;

      for (i = 0 ; i <= 6 ; i++)
         LoadString( hInst, IDS_SUNDAY + i, szWday[i], 12 ) ;

      //
      // In an international setting "Sunday" may not be abbrieviated
      // as "Sun".
      //
      for (i = 0 ; i <= 6 ; i++)
         LoadString( hInst, IDS_SUNDAY_SHORT + i, szShortWday[i], 4 ) ;

      for (i = 0 ; i <= 11 ; i++)
         LoadString( hInst, IDS_JANUARY + i, szMonth[i],  12 ) ;

      for (i = 0 ; i <= 11 ; i++)
         LoadString( hInst, IDS_JANUARY_SHORT + i, szShortMonth[i],  4 ) ;
   }

}/* TimeResetInternational() */

/************************************************************************
 * Local Functions
 ************************************************************************/

/*************************************************************************
 *
 *  LPSTR NEAR PASCAL TimeFormatShortDate
 *
 *************************************************************************/
LPSTR NEAR PASCAL
TimeFormatShortDate( LPSTR lpszDate, struct tm FAR *lpTM, WORD wFlags )
{
    int i=0,j=0;
    BOOL  bLead;
    char  cSep;

    while( sShortDate[i] )
    {
	bLead = FALSE;
	switch( cSep = sShortDate[i++] ) {
	    case 'd':
		if( sShortDate[i] == 'd' )
		{
		    bLead = TRUE;
		    i++;
		}
		if( bLead || (MDAY(lpTM) / 10) )
		    lpszDate[j++] = '0' + (char)( MDAY(lpTM) / 10 );
		lpszDate[j++] = '0' + (char)( MDAY(lpTM) % 10 );
	    break;

	    case 'M':
		if( sShortDate[i] == 'M' )
		{
		    bLead = TRUE;
		    i++;
		}
		if( bLead || (MONTH(lpTM) / 10) )
		    lpszDate[j++] = '0' + (char)( MONTH(lpTM) / 10 );
		lpszDate[j++] = '0' + (char)( MONTH(lpTM) % 10 );
	    break;

	    case 'y':
		i++;
		if( sShortDate[i] == 'y' )
		{
		    bLead = TRUE;
		    i+=2;
		}
		if( bLead )
		{
		    lpszDate[j++] = (lpTM->tm_year < 2000 ? '1' : '2');
		    lpszDate[j++] = (lpTM->tm_year < 2000 ? '9' : '0');
		}
		lpszDate[j++] = '0' + YEAR(lpTM) / 10;
		lpszDate[j++] = '0' + YEAR(lpTM) % 10;
	    break;

	    default:
		/* copy the current character into the formatted string - it
		 * is a separator.
		 */
		 lpszDate[j++] = cSep;
	    break;
	}
    }
    lpszDate[j] = 0;

   return lpszDate ;
}

/*************************************************************************
 *
 *  LPSTR NEAR PASCAL TimeFormatLongDate
 *
 *************************************************************************/
LPSTR NEAR PASCAL
TimeFormatLongDate( LPSTR lpszDate, struct tm FAR *lpTM, WORD wFlags ) 
{
   LPSTR lpCur, lpEnd ;
   BYTE  bMo = 4 ;
   BYTE  fShortDay ;
   char  szSep1[16], szSep2[16], szSep3[16] ;
   char  szMo[16], szDay[3], szYr[5], szFullDay[16] ;
   char  szDate[LEN_LONGDATE+1] ;

   //
   //  number of month digits.
   //
   if (lpCur = _fstrchr( sLongDate, 'M' ))
      for ( bMo = 0 ; lpCur ; lpCur = _fstrchr( lpCur+1, 'M' ) )
         bMo++ ;
   switch (bMo)
   {
      case 1:
         wsprintf( szMo, "%d", MONTH( lpTM ) ) ;
         break ;

      case 2:
         wsprintf( szMo, "%02d", MONTH( lpTM ) ) ;
         break ;

      case 3:
         wsprintf( szMo, "%s", (LPSTR)szShortMonth[ MONTH( lpTM )-1] ) ;
         break ;

      case 4:
         wsprintf( szMo, "%s", (LPSTR)szMonth[ MONTH( lpTM )-1 ] ) ;
         break ;
   }

   //
   // number of year digits
   //
   if (lpCur = _fstrchr( sLongDate, 'y' ))
      if (*(lpCur+2) == 'y')
         wsprintf( szYr, "%d", YEAR( lpTM ) + 1900 ) ;
      else
         wsprintf( szYr, "%d", YEAR( lpTM ) ) ;


   //
   // full day strings or just 3 characters?
   //
   if (*sLongDate == 'd')
   {
      if (*(sLongDate+3) == 'd')
      {
         fShortDay = FALSE ;
         wsprintf( szFullDay, "%s", (LPSTR)szWday[ WDAY( lpTM ) ] ) ;
      }
      else
      {
         fShortDay = TRUE ;
         wsprintf( szFullDay, "%s", (LPSTR)szShortWday[ WDAY( lpTM ) ] ) ;
      }
   }
   else
      szFullDay[0] = '\0' ;

   //
   // number of day digits
   //
   lpCur = sLongDate + (fShortDay ? 3 : 4) ;
   if (lpCur = _fstrchr( lpCur, 'd' ))
      if (*(lpCur+1) == 'd')
         wsprintf( szDay, "%02d", MDAY( lpTM ) ) ;
      else
         wsprintf( szDay, "%d", MDAY( lpTM ) ) ;

   //
   // Get the separator strings
   //
   lpCur = _fstrchr( sLongDate, '\'' ) + 1;
   lpEnd = _fstrchr( lpCur, '\'' ) ;

   _fstrncpy( szSep1, lpCur, lpEnd - lpCur ) ;
   szSep1[lpEnd - lpCur] = '\0' ;

   lpCur = _fstrchr( lpEnd+1, '\'' ) + 1 ;
   lpEnd = _fstrchr( lpCur, '\'' ) ;

   _fstrncpy( szSep2, lpCur, lpEnd - lpCur ) ;
   szSep2[lpEnd - lpCur] = '\0' ;

   lpCur = _fstrchr( lpEnd+1, '\'' ) + 1 ;
   lpEnd = _fstrchr( lpCur, '\'' ) ;

   _fstrncpy( szSep3, lpCur, lpEnd - lpCur ) ;
   szSep3[lpEnd - lpCur] = '\0' ;

   //
   // Now we have fully parsed the format string.  The only thing that is
   // missing is  the order (MMMM, dd, yyyy/ dd MMMM yyyy / yyyy MMMM dd)
   //
   lpCur = _fstrchr( sLongDate, '\'') ;
   lpCur = _fstrchr( lpCur+1, '\'') + 1 ;
   switch (*lpCur)
   {
      case 'd':  //              ,   ,
         wsprintf( szDate, "%s%s%s%s%s",
                     (LPSTR)szDay, (LPSTR)szSep2,
                     (LPSTR)szMo, (LPSTR)szSep3,
                     (LPSTR)szYr ) ;
      break ;

      case 'y':  //              ,   ,
         wsprintf( szDate, "%s%s%s%s%s",
                     (LPSTR)szYr, (LPSTR)szSep2,
                     (LPSTR)szMo, (LPSTR)szSep3,
                     (LPSTR)szDay ) ;
      break ;

      case 'M':
      default:
         wsprintf( szDate, "%s%s%s%s%s",
                     (LPSTR)szMo, (LPSTR)szSep2,
                     (LPSTR)szDay, (LPSTR)szSep3,
                     (LPSTR)szYr ) ;
      break ;
   }

   if (!(wFlags & DATE_NODAYOFWEEK))
   {
      lstrcat( szFullDay, szSep1 ) ;
      wsprintf( lpszDate, "%s%s",
                     (LPSTR)szFullDay, (LPSTR)szDate ) ;
   }
   else
      lstrcpy( lpszDate, szDate ) ;

   return lpszDate ;
}

/************************************************************************
 * End of File: time.c
 ************************************************************************/
