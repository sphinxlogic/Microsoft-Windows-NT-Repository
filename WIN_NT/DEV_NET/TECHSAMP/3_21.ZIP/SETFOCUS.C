//  SETFOCUS.C
//
//  Simple application that uses Interrupt 2Fh Function 168Bh to
//  set the focus to a particular Virtual Machine (VM).  Also uses
//  Interrupt 2Fh Function 1683h to find out what the current VM's
//  ID is.  
//
//  Here's how to use this application:
//  
//  1.  Start up at least 2 VMs (run COMMAND from Program Manager).
//  2.  Run SETFOCUS in each VM.  Note the VM id printed on the screen.
//  3.  Set the prompt in each VM to indicate what its VMid is.  For 
//      example:
//
//          c:> prompt (VM 3)
//
//  4.  Run SETFOCUS VMid to switch to different VMs.  For example, if
//      you created 2 COMMAND.COM VMs with ids 3 and 4, and you're
//      currently in VM 3, execute SETFOCUS 4. Then execute SETFOCUS 3
//      to switch back to the previous VM.            
//***************************************************************************

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <stdio.h>
#include <conio.h>

// Have to declare our boolean types because we don't have WINDOWS.H...
typedef int BOOL;
#define TRUE  1
#define FALSE 0

// The following defines are adapted from the MASM-oriented INT2FAPI.INC.

#define W386_API_Int            0x2F
#define W386_Get_Version        0x00  // Install check/Get version
#define W386_Int_Multiplex      0x16
#define W386_Get_Cur_VMID       0x83  // Returns BX = ID of current VM
#define W386_Set_Focus          0x8B

#define W386_Success            0x00  // These are local defines...
#define W386_Present            0x7F  // not from INT2FAPI.INC.

// Forward-declare functions...
BOOL TestWin386Present();

main( int argc, char ** argv )
{
    int wStatus = 0;
    unsigned int wVMID;
    unsigned int wCurVMID;
    char szCurVMID[4];
    int bWin386Present;

//  First make sure we're running in Win386...
    if ( !TestWin386Present() )
    {
        puts( "This program must be run under Windows Enhanced Mode." );
        exit(1);
    }

//  If so, find out what the current VM ID is and report it...
    _asm
    {
        mov ah, W386_Int_Multiplex
        mov al, W386_Get_Cur_VMID
        int W386_API_Int
        mov wCurVMID, bx           
    }
    _cputs( "Current VM is " );       // _cputs() doesn't add CR/LF
    itoa( wCurVMID, szCurVMID, 10 );
    puts( szCurVMID );
    puts( "");

//  If there wasn't a command-line VMID, tell user the syntax...
    if( argc != 2 )
    {
        puts( "Syntax: SETFOCUS virtual-machine-ID" );
        puts( "Sets the input focus to the specified virtual machine." );
        puts( "Virtual-machine-ID is a number in decimal." );
        exit(1);
    }

//  Otherwise, SetFocus to the specified VM...
    wVMID = atoi( argv[1] );
    _asm
    {
        mov ah, W386_Int_Multiplex
        mov al, W386_Set_Focus
        mov bx, wVMID
        int W386_API_Int
        mov wStatus, ax
    }
    if( (wStatus & 0x00FF) == W386_Success )    // only care about low byte
        printf( "Successfully set focus to VM %u.", wVMID );
    else
    {
        printf( "Could not set focus to VM %u.\nThere may be no such VM running.\n", wVMID );
        printf( "Error #%X\n", wStatus );
    }
}

//************************************************************************
//  BOOL TestWin386Present()
//
//  Description:
//      Uses Interrupt 2Fh function 1600h (Get Enhanced Mode Windows
//      Installed State) to find out if Win386 is running.
//
//  Returns:
//      TRUE if Win386 running; FALSE if not.
//
//  Comments:
//      Uses _asm directive; generates compiler warnings because
//      AX register return value set in assembly, so compiler worries.
//
//  History:   Date       Author      Comment
//             11/ 1/92   DavidL      Wrote it.
//************************************************************************

BOOL TestWin386Present()
{
    _asm
    {
        mov ah, W386_Int_Multiplex
        mov al, W386_Get_Version
        int W386_API_Int
        test al, W386_Present
        jz NoWin386
        mov ax, TRUE
        jmp Return
NoWin386:
        mov ax, FALSE
Return:
    }
} // end of TestWin386Present()
