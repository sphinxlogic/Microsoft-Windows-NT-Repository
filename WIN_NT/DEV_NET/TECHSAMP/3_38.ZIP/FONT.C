/************************************************************************
 *
 *     Project:  Font 
 *
 *      Module:  Font.c
 *
 *   Revisions:  
 *       8/13/92   cek   Wrote it.
 *
 ***********************************************************************/
#ifdef WIN32
#define NO_STRICT
#else
#define STRICT
#endif

#include <windows.h>
#include <windowsx.h>
#include <commdlg.h>

#include "version.h"

#include "Font.h"

#include "fontutil.h"

/*
 * Global variables extern'd in Font.h
 */
HWND        hwndApp ;
HINSTANCE   hmodApp ;
LPSTR       rglpsz[LAST_IDS - FIRST_IDS + 1] ;
char        szVerNum[80] ;

static char szCurChar[] = "AbCcDeWF" ;

/*
 * Variables local to this module.
 */ 
static HCURSOR    hcurWait ;
static HCURSOR    hcurNorm ;
static HCURSOR    hcurSave ;
static UINT       fWaitCursor ;
static HFONT      hfontTest ;

int FAR PASCAL MessageLoop( VOID ) ;
BOOL WINAPI InitClass( HINSTANCE hInstance ) ;
HWND WINAPI CreateMain( VOID ) ;
GLOBALHANDLE WINAPI GetStrings( HINSTANCE hInst ) ;
short FAR _cdecl ErrorResBox( HWND hwnd, HINSTANCE hInst, UINT flags,
                                        UINT idAppName, UINT idErrorStr, ...) ;
BOOL WINAPI DoAboutBox( VOID ) ;


/****************************************************************
 *  LRESULT FAR PASCAL
 *    fnMainWnd( HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam )
 *
 *  Description: 
 *
 *    Main Window procedure.
 *
 *  Comments:
 *
 ****************************************************************/

LRESULT CALLBACK fnMainWnd( HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam )
{
   char szFace[LF_FACESIZE], szStyle[LF_FACESIZE] ;

   switch( uiMsg )
   {
      case WM_CREATE:
      {
         HDC hdc ;

         hwndApp = hWnd ;

         hdc = GetDC( hWnd ) ;
         hfontTest = ReallyCreateFont( hdc, "Times New Roman", "Bold Italic", 48, 0 );

         hfontTest = SelectObject( hdc, hfontTest ) ;
         GetTextFace( hdc, 255, szFace ) ;
         GetTextStyle( hdc, 255, szStyle ) ;

         hfontTest = SelectObject( hdc, hfontTest ) ;

         ReleaseDC( hWnd, hdc ) ;
      }
      break ;

      case WM_CHAR:
         *szCurChar = (char)wParam ;
         InvalidateRect( hWnd, NULL, TRUE ) ;
      break ;

      case WM_COMMAND:
      {
         #ifdef WIN32
         WORD wNotifyCode = HIWORD(wParam);  
         WORD wID = LOWORD(wParam);         
         HWND hwndCtl = (HWND) lParam;      
         #else
         WORD wNotifyCode = HIWORD(lParam) ;
         WORD wID = wParam ;
         HWND hwndCtl = (HWND)LOWORD(lParam) ;
         #endif

         switch (wID)
         {
            case IDM_HELP_ABOUT:
               DoAboutBox() ;
            break ;

            case IDM_CHOOSEFONT:
            {
               HDC hdc;
               LOGFONT lf;
               CHOOSEFONT chf;

               hdc = GetDC(hWnd);
               chf.hDC = CreateCompatibleDC(hdc);
               ReleaseDC(hWnd, hdc);

               GetObject( hfontTest, sizeof( LOGFONT ), (LPSTR)&lf ) ;

               chf.lStructSize = sizeof( CHOOSEFONT ) ;
               chf.hwndOwner = hWnd ;
               chf.lpLogFont = &lf ;
               chf.Flags = CF_SCREENFONTS |
                           CF_INITTOLOGFONTSTRUCT ;
               chf.rgbColors = 0L ;
               chf.lCustData = 0L ;
               chf.lpfnHook = (UINT (CALLBACK*)(HWND, UINT, WPARAM, LPARAM))NULL ;
               chf.lpTemplateName = (LPSTR) NULL ;
               chf.hInstance = (HANDLE) NULL ;
               chf.iPointSize = 0 ;
               chf.lpszStyle = (LPSTR)NULL ;
               chf.nFontType = 0 ;
               chf.nSizeMin = 0 ;
               chf.nSizeMax = 0 ;

               if (ChooseFont(&chf))
               {
                  DeleteObject( hfontTest ) ;

                  hfontTest = CreateFontIndirect( &lf ) ;

                  hfontTest = SelectObject( chf.hDC, hfontTest ) ;
                  GetTextFace( chf.hDC, 255, szFace ) ;
                  GetTextStyle( chf.hDC, 255, szStyle ) ;

                  hfontTest = SelectObject( chf.hDC, hfontTest ) ;
               }

               DeleteDC( chf.hDC ) ;
      			InvalidateRect( hWnd, NULL, TRUE ) ;
            }
            break ;

            case IDM_FILE_EXIT:
               SendMessage( hWnd, WM_CLOSE, 0, 0L ) ;
            break ;

         }
      }
      break ;

      case WM_PAINT:
      {
         short       x = 25 ;
         short       y = 5 ;
         short       cyChar ;
         UINT        uiStart ;
         RECT        rc ;
         SIZE        Size ;
         char        szBuf[256] ;
         char        szFullName[256] ;
         char        szFace[LF_FACESIZE+1] ;
         char        szStyle[LF_FACESIZE+1] ;
         int         nPtSize ;
         TEXTMETRIC  tm ;
         PAINTSTRUCT ps ;
         HPEN        hpen ;

         if (!BeginPaint( hWnd, &ps ))
            return FALSE ;

         GetTextMetrics( ps.hdc, &tm ) ;
         cyChar = tm.tmHeight + tm.tmInternalLeading ;

         hpen = SelectObject( ps.hdc, CreatePen( PS_SOLID, 1, GetSysColor( COLOR_ACTIVEBORDER ) ) ) ;

         SetTextColor( ps.hdc, GetSysColor( COLOR_WINDOWTEXT ) ) ;
         SetBkColor( ps.hdc, GetSysColor( COLOR_WINDOW ) ) ;

         hfontTest = SelectObject( ps.hdc, hfontTest ) ;

         GetTextFullName( ps.hdc, 255, szFullName ) ;
         GetTextFace( ps.hdc, LF_FACESIZE, szFace ) ;
         GetTextStyle( ps.hdc, LF_FACESIZE, szStyle ) ;
         nPtSize = GetTextPointSize( ps.hdc ) ;
         
         hfontTest = SelectObject( ps.hdc, hfontTest ) ;

         wsprintf( szBuf, "%s %s %d point.  Current Text : '%s'",
                   (LPSTR)szFace,
                   (LPSTR)szStyle,
                   nPtSize,
                   (LPSTR)szCurChar ) ;
         TextOut( ps.hdc, x, y, szBuf, lstrlen( szBuf ) ) ;

         y += + cyChar ;
         wsprintf( szBuf, "The Full Name for this font is: %s.", (LPSTR)szFullName ) ;
         TextOut( ps.hdc, x, y, szBuf, lstrlen( szBuf ) ) ;

         y += + cyChar ;
         SelectObject( ps.hdc, GetStockObject( NULL_BRUSH ) ) ;

         /*
          * Show what it looks like if we are nieve.
          *
          * (i.e. the whole point of doing this is because
          *  GetTextExtent does not know about abc widths)
          */
         SetBkColor( ps.hdc, GetSysColor( COLOR_WINDOW ) ) ;
         SetTextColor( ps.hdc, GetSysColor( COLOR_WINDOWTEXT ) ) ;

         wsprintf( szBuf, "Using GetTextExtentPoint:" ) ;
         TextOut( ps.hdc, x, y, szBuf, lstrlen( szBuf ) ) ;
         y += cyChar ;

         hfontTest = SelectObject( ps.hdc, hfontTest ) ;
         SetBkColor( ps.hdc, GetSysColor( COLOR_HIGHLIGHT ) ) ;
         SetTextColor( ps.hdc, GetSysColor( COLOR_HIGHLIGHTTEXT ) ) ;

         GetTextExtentPoint( ps.hdc, szCurChar, lstrlen(szCurChar), &Size ) ;

         rc.left = x ;
         rc.top = y ;
         rc.right = rc.left + Size.cx ;
         rc.bottom = rc.top + Size.cy ;

         ExtTextOut( ps.hdc,
                     x,
                     y,
                     ETO_OPAQUE | ETO_CLIPPED,
                     &rc, szCurChar,
                     lstrlen( szCurChar ),
                     NULL ) ;

         Rectangle( ps.hdc, x-1, y-1,
                  x + Size.cx + 1,
                  y + Size.cy + 1 ) ;


         hfontTest = SelectObject( ps.hdc, hfontTest ) ;

         y += Size.cy + cyChar ;

        /* Now do it using GetCharABCWidths() 
         */
         wsprintf( szBuf, "Using GetTextExtentABCPoint() and using return value for offset:" ) ;
         SetBkColor( ps.hdc, GetSysColor( COLOR_WINDOW ) ) ;
         SetTextColor( ps.hdc, GetSysColor( COLOR_WINDOWTEXT ) ) ;
         TextOut( ps.hdc, x, y, szBuf, lstrlen( szBuf ) ) ;
         y += cyChar ;

         hfontTest = SelectObject( ps.hdc, hfontTest ) ;
         SetBkColor( ps.hdc, GetSysColor( COLOR_HIGHLIGHT ) ) ;
         SetTextColor( ps.hdc, GetSysColor( COLOR_HIGHLIGHTTEXT ) ) ;

         uiStart = GetTextExtentABCPoint( ps.hdc,
                           szCurChar, lstrlen( szCurChar ),
                           &Size ) ;

         rc.left = x ;
         rc.top = y ;
         rc.right = rc.left + Size.cx ;
         rc.bottom = rc.top + Size.cy ;

         ExtTextOut( ps.hdc,
                     x + uiStart,
                     y,
                     ETO_OPAQUE | ETO_CLIPPED,
                     &rc, szCurChar,
                     lstrlen( szCurChar ),
                     NULL ) ;

         Rectangle( ps.hdc, x-1, y-1,
                  x + Size.cx + 1,
                  y + Size.cy + 1 ) ;

         hfontTest = SelectObject( ps.hdc, hfontTest ) ;


         /*
          *  Use GetTextExtentABCPoint() which is a semi-cool function
          */
         SetBkColor( ps.hdc, GetSysColor( COLOR_WINDOW ) ) ;
         SetTextColor( ps.hdc, GetSysColor( COLOR_WINDOWTEXT ) ) ;

         y += Size.cy + cyChar ;
         wsprintf( szBuf, "Using GetTextExtentABCPoint() but ignoring return value:" ) ;
         TextOut( ps.hdc, x, y, szBuf, lstrlen( szBuf ) ) ;

         hfontTest = SelectObject( ps.hdc, hfontTest ) ;
         SetBkColor( ps.hdc, GetSysColor( COLOR_HIGHLIGHT ) ) ;
         SetTextColor( ps.hdc, GetSysColor( COLOR_HIGHLIGHTTEXT ) ) ;

         GetTextExtentABCPoint( ps.hdc, szCurChar, lstrlen(szCurChar), &Size ) ;

         y += cyChar ;

         rc.left = x ;
         rc.top = y ;
         rc.right = rc.left + Size.cx ;
         rc.bottom = rc.top + Size.cy ;

         ExtTextOut( ps.hdc,
                     x,
                     y,
                     ETO_OPAQUE | ETO_CLIPPED,
                     &rc, szCurChar,
                     lstrlen( szCurChar ),
                     NULL ) ;

         Rectangle( ps.hdc, x-1, y-1,
                  x + Size.cx + 1,
                  y + Size.cy + 1 ) ;

         hfontTest = SelectObject( ps.hdc, hfontTest ) ;

         hpen = SelectObject( ps.hdc, hpen ) ;
         DeleteObject( hpen ) ;

	      EndPaint( hWnd, &ps ) ;
         return TRUE ;

      }
      break ;

      case WM_DESTROY:
         if (hfontTest)
            DeleteObject( hfontTest ) ;
         PostQuitMessage( 0 ) ;
      break ;

      default:
         return DefWindowProc( hWnd, uiMsg, wParam, lParam ) ;
   }

   return 0L ;

} /* fnMainWnd()  */

BOOL CALLBACK fnAbout( HWND hDlg, UINT wMsg, WPARAM wParam, LPARAM lParam) ;

BOOL WINAPI DoAboutBox( VOID )
{
   DLGPROC  lpfnDlgProc ;

   (FARPROC)lpfnDlgProc = MakeProcInstance( (FARPROC)fnAbout, hmodApp ) ;
   DialogBox( hmodApp,
              MAKEINTRESOURCE( DLG_ABOUTBOX ),
              hwndApp,
              lpfnDlgProc ) ;
   FreeProcInstance( (FARPROC)lpfnDlgProc ) ;

   return TRUE ;
}

BOOL CALLBACK fnAbout( HWND hDlg, UINT wMsg, WPARAM wParam, LPARAM lParam ) 
{
   char  szTemp [256] ;

   switch (wMsg)
   {
      case WM_INITDIALOG:

         #ifdef WIN32
         wsprintf( szTemp, "%s %s (Win32) - %s",
                   (LPSTR)rglpsz[IDS_VERSION], (LPSTR)szVerNum,
                   (LPSTR)__DATE__ ) ;
         #else
         wsprintf( szTemp, "%s %s (Win16) - %s",
                   (LPSTR)rglpsz[IDS_VERSION], (LPSTR)szVerNum,
                   (LPSTR)__DATE__ ) ;
         #endif
         SetDlgItemText (hDlg, IDD_VERSION, szTemp ) ;

         break ;

      case WM_COMMAND:
      {
         #ifdef WIN32
         WORD wNotifyCode = HIWORD(wParam);  
         WORD wID = LOWORD(wParam);         
         HWND hwndCtl = (HWND) lParam;      
         #else
         WORD wNotifyCode = HIWORD(lParam) ;
         WORD wID = wParam ;
         HWND hwndCtl = (HWND)LOWORD(lParam) ;
         #endif

         switch (wID)
         {
            case IDOK:
            case IDCANCEL:
               EndDialog (hDlg, wID) ;
            break ;

            default :
               return FALSE ;
         }
         break ;
      }
      break ;

   }
   return FALSE ;
}


/****************************************************************
 *  VOID WINAPI SetWaitCursor( VOID )
 *
 *  Description: 
 *
 *
 *
 *  Comments:
 *
 ****************************************************************/
UINT nCurCount ;

VOID WINAPI SetWaitCursor( VOID )
{
   if (!hcurWait)
      hcurWait = LoadCursor( NULL, IDC_WAIT ) ;

   fWaitCursor++ ;

   SetCursor( hcurWait ) ;

} /* SetWaitCursor()  */

/****************************************************************
 *  VOID WINAPI SetNormalCursor( VOID )
 *
 *  Description: 
 *
 *
 *
 *  Comments:
 *
 ****************************************************************/
VOID WINAPI SetNormalCursor( VOID )
{
   if (!hcurNorm)
      hcurNorm = LoadCursor( NULL, IDC_ARROW ) ;

   fWaitCursor-- ;

   if (fWaitCursor)
      return ;

   SetCursor( hcurNorm ) ;

} /* SetNormalCursor()  */

/****************************************************************
 *  int FAR PASCAL MessageLoop( HACCEL haccl )
 *
 *  Description: 
 *
 *
 *  Comments:
 *
 ****************************************************************/
int FAR PASCAL MessageLoop( VOID )
{
   MSG            msg ;

   while (GetMessage (&msg, NULL, 0, 0))
   {
      TranslateMessage( &msg ) ;
      DispatchMessage( &msg ) ;
   }

   return (int)msg.wParam ;

} /* MessageLoop()  */

/****************************************************************
 *  int PASCAL
 *    WinMain( HANDLE hinst, HANDLE hinstPrev, LPSTR lpszCmd, in nCmdShow )
 *
 *  Description: 
 *
 *
 *
 *  Comments:
 *
 ****************************************************************/
int PASCAL WinMain( HINSTANCE hinst, HINSTANCE hinstPrev, LPSTR lpszCmd, int nCmdShow )
{
   GLOBALHANDLE   gh ;
   int            n ;

   hmodApp = hinst ;

   SetWaitCursor() ;

   if (!(gh = GetStrings( hinst )))
   {
      SetNormalCursor() ;

      ErrorResBox( NULL, hinst,
                   MB_ICONHAND, IDS_APPTITLE, IDS_ERR_STRINGLOAD ) ;
      return FALSE ;
   }


   if ( VER_BUILD )
      wsprintf( szVerNum, (LPSTR)"%d.%.2d.%.3d",
                VER_MAJOR, VER_MINOR, VER_BUILD ) ;
   else
      wsprintf( szVerNum, (LPSTR)"%d.%.2d", VER_MAJOR, VER_MINOR ) ;

   /*
    * If there is already an instance running, bring it to the
    * foreground and close this one.
    *
    * We use the FindWindow method because hPrevInst is always NULL
    * in Windows NT.
    */
   if (hwndApp = FindWindow( rglpsz[IDS_APPNAME], NULL ))
   {
      HWND hwnd2 ;

      hwnd2 = GetLastActivePopup( hwndApp ) ;

      //
      // If it's minimized, restore it.
      //
      if (hwndApp == hwnd2 && IsIconic( hwndApp ))
         SendMessage(hwndApp, WM_SYSCOMMAND, SC_RESTORE, 0) ;

      BringWindowToTop(hwnd2) ;
      SetActiveWindow(hwnd2) ;

      GlobalFree( gh ) ;
      return 0;
   }

   if (!hinstPrev)
      if (!InitClass( hinst ))
      {
         SetNormalCursor() ;

         ErrorResBox( NULL, hinst,
                      MB_ICONHAND,IDS_APPTITLE, 
                      IDS_ERR_INITCLASS ) ;

         goto HellInAHandBasket2 ;
      }

   /*
    * Read defaults
    */
   if (!(hwndApp = CreateMain()))
   {
      SetNormalCursor() ;

      ErrorResBox( NULL, hinst,
                   MB_ICONHAND, IDS_APPTITLE,  IDS_ERR_CREATEWINDOW ) ;

      goto HellInAHandBasket2 ;
   }

   SetNormalCursor() ;

   ShowWindow( hwndApp, nCmdShow ) ;
   UpdateWindow( hwndApp ) ;

   /*
    * Enter message loop.  This is in Font.C so that it is in
    * a preload segment.
    */
   n = MessageLoop(  ) ;

   /*
    * Save defaults
    */
HellInAHandBasket2:
                        
   GlobalUnlock( gh ) ;
   GlobalFree( gh ) ;

   return n ;

} /* MyWinMain()  */


/****************************************************************
 *  BOOL WINAPI InitClass( HINSTANCE hInstance )
 *
 *  Description: 
 *
 *    Registers the window classes.
 *
 *  Comments:
 *
 ****************************************************************/
BOOL WINAPI InitClass( HINSTANCE hInstance )
{
   WNDCLASS    wc ;
   BOOL        f = TRUE ;

   wc.style             = 0L ;
   wc.lpfnWndProc       = fnMainWnd ;
   wc.cbClsExtra        = 0 ;
   wc.cbWndExtra        = 0 ;
   wc.hInstance         = hInstance ;
   wc.hIcon             = LoadIcon( hInstance,
                                    MAKEINTRESOURCE( IDI_Font ) ) ;
   wc.hCursor           = LoadCursor( NULL, IDC_ARROW ) ;
   wc.hbrBackground     = (HBRUSH)(COLOR_WINDOW + 1) ;
   wc.lpszMenuName      = rglpsz[IDS_APPNAME] ;
   wc.lpszClassName     = rglpsz[IDS_APPNAME] ;

   if (!RegisterClass (&wc))
      return FALSE ;

   return TRUE ;


} /* InitClass()  */


/****************************************************************
 *  HWND WINAPI CreateMain( VOID )
 *
 *  Description: 
 *
 *
 *
 *  Comments:
 *
 ****************************************************************/
HWND WINAPI CreateMain( VOID )
{
   HWND hwnd ;

   hwnd = CreateWindow
      (
         rglpsz[IDS_APPNAME],
         rglpsz[IDS_APPTITLE],
         WS_OVERLAPPEDWINDOW |
         WS_CLIPCHILDREN,  
         1,
         1,
         630,
         480 - (480/5),
         NULL,                 
         NULL,                 
         hmodApp,            
         NULL                  
      ) ;

   return hwnd ;

} /* CreateMain()  */


/****************************************************************
 *  GLOBALHANDLE WINAPI GetStrings( hInst )
 *
 *  Description: 
 *
 *    Fills lprgsz[] with resource strings.
 *
 *  Comments:
 *
 ****************************************************************/
GLOBALHANDLE WINAPI GetStrings( HINSTANCE hInst )
{
   GLOBALHANDLE   ghMem ;
   LPSTR          lpMem ;
   LPSTR          lpCur ;
   short          i ;
   short          n ;

   if (ghMem = GlobalAlloc( GHND, (LAST_IDS - FIRST_IDS) * 512 ))
   {
      if (!(lpMem = GlobalLock( ghMem )))
      {
         GlobalFree( ghMem ) ;
         return FALSE ;
      }

      /*
       * Load each string and keep it's pointer
       */
      lpCur = lpMem ;

      for (i = FIRST_IDS ; i <= LAST_IDS ; i++)
      {
         if (n = LoadString( hInst, i, lpCur, 512 ))
         {
            rglpsz[i] = lpCur ;
            lpCur += n + 1 ;
         }
         else
         {
            GlobalUnlock( ghMem ) ;
            GlobalFree( ghMem ) ;
            return NULL ;
         }
      }

      /*
       * Now reallocate the block so it is just big enough
       */
      GlobalReAlloc( ghMem, (lpCur - lpMem + 16), GHND ) ;
      GlobalLock( ghMem ) ;

      return ghMem ;
   }
   else
   {
      return NULL ;
   }

   return NULL ;

} /* GetStrings()  */

#define MAX_STRLEN   2048      // Maximum characters for ErrorResBox


/*************************************************************************
 *  short FAR _cdecl ErrorResBox( HWND hWnd, HANDLE hInst, UINT wFlags,
 *                                UINT idAppName, UINT idErrorStr,
 *                                LPSTR lpszParams, ... ) ;
 *
 *  Description:
 *
 *  This function displays a message box using program resource strings.
 *       
 *  Type/Parameter
 *          Description
 *
 *      HWND hWnd
 *            Specifies the message box parent window.
 *
 *      HANDLE hInst
 *            Specifies the handle to the module that contains the resource
 *            strings specified by idAppName and idErrorStr.  If this value
 *            is NULL, the instance handle is obtained from hWnd (in which
 *            case hWnd may not be NULL).
 *
 *      UINT wFlags
 *            Specifies message box types controlloing the message box
 *            appearance.  All message box types valid for MessageBox are valid.
 *      
 *      UINT idAPpName
 *            Specifies the resource ID of a string that
 *            is to be used as the message box caption.
 * 
 *      UINT idErrorStr
 *             Specifies the resource ID of a error message format string.
 *             This string is of the style passed to wsprintf(),
 *             containing the standard C argument formatting
 *             characters.  Any procedure parameters following
 *             idErrorStr will be taken as arguments for this format
 *             string.
 * 
 *      arguments [ arguments, ... ]
 *             Specifies additional arguments corresponding to the
 *             format specification given by idErrorStr.  All
 *             string arguments must be FAR pointers.
 * 
 * 
 *  Return Value
 *    Returns the result of the call to MessageBox().  If an
 *    error occurs, returns zero.
 *
 *  Comment:
 *       This is a variable arguments function, the parameters after
 *       idErrorStr being taken for arguments to the printf() format
 *       string specified by idErrorStr.  The string resources specified
 *       by idAppName and idErrorStr must be loadable using the
 *       instance handle hInst.  If the strings cannot be
 *       loaded, or hwnd is not valid, the function will fail and return
 *       zero.
 *
 *************************************************************************/
short FAR _cdecl ErrorResBox( HWND hwnd, HINSTANCE hInst, UINT flags,
                                        UINT idAppName, UINT idErrorStr, ...)
{
   LPSTR        sz = NULL ;
   LPSTR        szFmt = NULL ;
   UINT w ;

   if (!hInst)
   {
      if (!hwnd)
      {
         MessageBeep( 0 ) ;
         return FALSE ;
      }

      hInst = (HINSTANCE)GetWindowInstance( hwnd ) ;
   }

   if (szFmt = GlobalAllocPtr( GHND, 256 + 1 ))
   {
      if (!LoadString( hInst, idErrorStr, szFmt, 256 ))
         goto ExitError ;

      if (sz = GlobalAllocPtr( GHND, MAX_STRLEN ))
      {
         w = 0 ;

         wvsprintf( sz, szFmt, (LPSTR)(((UINT FAR *)&idErrorStr) + 1) ) ;

         if (!LoadString( hInst, idAppName, szFmt, 256 ))
            goto ExitError ;

         w = MessageBox( hwnd, sz, szFmt, flags ) ;

      }
   }

ExitError :
   if (sz)
      GlobalFreePtr( sz ) ;

   if (szFmt)
      GlobalFreePtr( szFmt ) ;

   return w ;

}/* ErrorResBox() */


/************************************************************************
 * End of File: Font.c
 ***********************************************************************/
