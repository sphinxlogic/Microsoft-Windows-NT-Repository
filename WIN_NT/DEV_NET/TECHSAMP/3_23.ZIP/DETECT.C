/* detect.c - WinMain() and WndProc() for DETECT, along with
 *      initialization and support code.
 *
 * DETECT is a Windows with Multimedia sample application that 
 *  illustrates how to write an application that can detect if
 *  the Multimedia Extensions are installed. The code that actually
 *  detects the presence of the Extensions resides in MMAWARE.ASM.
 *  Refer to MMAWARE.ASM for additional information.
 *
 *
 *    (C) Copyright Microsoft Corp. 1993.  All rights reserved.
 *
 *    You have a royalty-free right to use, modify, reproduce and 
 *    distribute the Sample Files (and/or any modified version) in 
 *    any way you find useful, provided that you agree that 
 *    Microsoft has no warranty obligations or liability for any 
 *    Sample Application Files which are modified. 
 *
 */

#include <windows.h>
#include <mmsystem.h>
#include "detect.h"

/* Globals
 */
char    szAppName[] = "Detect";
HANDLE  hInstApp;
HWND    hwndApp;
WORD    wMMVersion;


/* WinMain - Entry point for Detect.
 */
int PASCAL WinMain(HANDLE hInst, HANDLE hPrev, LPSTR szCmdLine, WORD nCmdShow)
{
    MSG msg;

    /* Save instance handle.
     */
    hInstApp = hInst;
    
    /* If no previous instance already running, initialize application.
     */
    if (!hPrev)
    {
        if (!AppInit(hInst, hPrev, nCmdShow, szCmdLine))
            return FALSE;
    }

    /* Get the version of the Multimedia Extensions that are installed.
     * If extensions are not installed, mmsystemGetVersion() returns zero.
     */
    if(!(wMMVersion = mmsystemGetVersion()))
        MessageBox(NULL, "The Multimedia Extensions are not installed.",
                   szAppName, MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL);

    /* Create and show the main window.
     */
    hwndApp = CreateWindow (MAKEINTATOM(ID_APP),
                            szAppName,
                            WS_OVERLAPPEDWINDOW,
                            CW_USEDEFAULT, 0,
                            GetSystemMetrics(SM_CXSCREEN) / 2,
                            GetSystemMetrics(SM_CYSCREEN) / 2,
                            (HWND)NULL,
                            (HMENU)NULL,
                            (HANDLE)hInst,
                            (LPSTR)NULL);
    ShowWindow(hwndApp, nCmdShow);

    /* The main message processing loop.
     */
    while (GetMessage(&msg, NULL, 0, 0))  
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return msg.wParam;
}


/* WndProc - Main window procedure function.
 *
 * Params:  Standard window procedure parameters.
 *
 * Returns: The return value is message dependent.
 */
LONG FAR PASCAL WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    HDC hdc;
    char szTimeString[32];

    switch (msg) 
    {
    case WM_CREATE:
        /* Set a 100 millisecond Windows event timer.
         */
        SetTimer(hWnd, 1, 100, NULL);
        break;

    case WM_TIMER:
        /* Process the Windows event timer message--call timeGetTime() to
         * get the current system time and show this time in the main window.
         * Note that the Multimedia Extensions function timeGetTime() is
         * available when the Extensions are not installed, though it is less
         * accurate. Refer to the MMAWARE.ASM module for more information.
         */
        hdc=GetDC(hWnd);
        TextOut(hdc,
                0, 0,
                szTimeString,
                wsprintf(szTimeString,
                         "Current System Time: %08lX ", timeGetTime())
                );
        ReleaseDC(hWnd,hdc);
        break;

    case WM_INITMENU:
        /* Disable actions if Multimedia Extensions are not installed.
         */
        if (!wMMVersion)
            EnableMenuItem((HMENU)wParam, IDM_DING, MF_GRAYED);
        break;
        
    case WM_COMMAND:
        return AppCommand(hWnd, msg, wParam, lParam);

    case WM_DESTROY:
        /* Stop the Windows event timer and post a quit message.
         */
        KillTimer(hWnd,1);
        PostQuitMessage(0);
        break;
    }
    
    return DefWindowProc(hWnd, msg, wParam, lParam);
}


/* AppCommand - Called by a window procedure function to process the
 *   application's WM_COMMAND messages.
 *
 * Params:  Standard window procedure parameters.
 *
 * Returns: The return value is message dependent. This return value
 *          will be used as the return value from the calling window
 *          procedure function.
 */
LONG NEAR PASCAL AppCommand(HWND hWnd, unsigned msg, WORD wParam, LONG lParam)
{
    FARPROC fpfn;

    switch (wParam) 
    {
    /* The IDM_HAND, IDM_QUESTION, IDM_EXCLAMATION, IDM_ASTERISK, menu items
     * illustrate the use of MessageBeep and MessageBox. If the Multimedia
     * Extensions are not installed, the Windows MessageBeep function will
     * be used instead of the multimedia MessageBeep.
     */
    case IDM_HAND:
        MessageBeep(MB_ICONHAND);
        MessageBox(hWnd, "SystemHand", "MB_ICONHAND",
                   MB_OK | MB_ICONHAND);
        break;

    case IDM_QUESTION:
        MessageBeep(MB_ICONQUESTION);
        MessageBox(hWnd, "SystemQuestion", "MB_ICONQUESTION",
                   MB_OK | MB_ICONQUESTION);
        break;

    case IDM_EXCLAMATION:
        MessageBeep(MB_ICONEXCLAMATION);
        MessageBox(hWnd, "SystemExclamation", "MB_ICONEXCLAMATION",
                   MB_OK | MB_ICONEXCLAMATION);
        break;

    case IDM_ASTERISK:
        MessageBeep(MB_ICONASTERISK);
        MessageBox(hWnd, "SystemAsterisk", "MB_ICONASTERISK",
                   MB_OK | MB_ICONASTERISK);
        break;

    case IDM_DING:
        /* Play a waveform audio resource.
         */
        PlayResource("Ding");
        break;

    case IDM_ABOUT:
        /* Put up the 'About' dialog box.
         */
        fpfn  = MakeProcInstance((FARPROC)AppAbout, hInstApp);
        DialogBox(hInstApp, MAKEINTRESOURCE(ABOUTBOX), hWnd, fpfn);
        FreeProcInstance(fpfn);
        break;

    case IDM_EXIT:
        PostMessage(hWnd, WM_CLOSE, 0, 0L);
        break;
    }
    
    return 0L;
}


/* AppInit - Performs one-time application initialization.
 *   This routine should only be called the first time the application
 *   is launched.
 *
 * Params:  Same as those passed to WinMain() entry point.
 *
 * Returns: FALSE on failure, TRUE on success.
 */
BOOL AppInit(HANDLE hInst, HANDLE hPrev, WORD nCmdShow, LPSTR szCmdLine)
{
    WNDCLASS wc;
    
    /* Register a class for the main application window.
     */
    wc.hCursor        = LoadCursor(NULL, IDC_ARROW);
    wc.hIcon          = LoadIcon(hInst, MAKEINTATOM(ID_APP));
    wc.lpszMenuName   = MAKEINTATOM(ID_APP);
    wc.lpszClassName  = MAKEINTATOM(ID_APP);
    wc.hbrBackground  = (HBRUSH)COLOR_WINDOW + 1;
    wc.hInstance      = hInst;
    wc.style          = CS_BYTEALIGNCLIENT | CS_VREDRAW | CS_HREDRAW;
    wc.lpfnWndProc    = WndProc;
    wc.cbWndExtra     = 0;
    wc.cbClsExtra     = 0;

    if (!RegisterClass(&wc))
        return FALSE;

    return TRUE;
}


/* AppAbout - Dialog procedure for ABOUTBOX dialog box.
 */
BOOL FAR PASCAL AppAbout(HWND hDlg, unsigned msg, WORD wParam, LONG lParam)
{
    switch (msg) 
    {
    case WM_COMMAND:
        if (wParam == IDOK)
            EndDialog(hDlg, TRUE);
        break;

    case WM_INITDIALOG:
        return TRUE;
    }
    return FALSE;
}


/* PlayResource - Plays a waveform audio (WAVE) resource.
 *
 * Params:  A pointer to a null-terminated string containing the name of
 *          the resource.
 *
 * Return:  void
 */
void PlayResource(LPSTR lpName)
{
    HANDLE hResInfo, hRes;
    LPSTR lpRes;

    /* Find and load the resource.
     */
    if (!(hResInfo = FindResource(hInstApp, lpName, "WAVE")))
        return;
    if (!(hRes = LoadResource(hInstApp, hResInfo)))
        return;

    /* Lock the resource. If the lock is successful,
     * play the resource and then unlock it.
     */
    lpRes = LockResource(hRes);
    if (lpRes) 
    {
        sndPlaySound(lpRes, SND_MEMORY | SND_SYNC | SND_NODEFAULT);
        UnlockResource(hRes);
    }

    /* Free the resource.
     */
    FreeResource(hRes);
}
