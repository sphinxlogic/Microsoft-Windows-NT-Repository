/*
    timeacd.c

    Sing along with your favorite CD Authoring app

    Another fine Herman Rodent production

*/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "timeacd.h"
#include <stdio.h>

//
// global data
//

char *szAppName = "TimeaCD";        // app name
HINSTANCE hInst;                    // app instance
HWND hwndMain;                      // main window handle
UINT uiTimerId;                     // update timer
TEXTMETRIC tmSysFont;               // system font metrics
UINT uiButtonHeight;                // height of a button
LPSTR lpCurrentLine;                // pointer to current song line
HPEN hpenRed;
HBRUSH hbrRed;
HWND hwndList;
char szFileName[_MAX_PATH];
DWORD dwCurrentIndex;

//
// local functions
//

static void Command(HWND hWnd, WPARAM wParam, LPARAM lParam);
static BOOL Init(HANDLE hInstance, int cmdShow);
static void Terminate(void);
static void Update(void);
static void MeasureListItem(HWND hWnd, LPMEASUREITEMSTRUCT lpMIS);
static void DrawListItem(HWND hWnd, LPDRAWITEMSTRUCT lpDI);
static void SetCurrentTime(void);
static void Save(void);
static LPSONGLINE FindLine(DWORD dwPos);

//
// Entry point
//

int PASCAL WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpszCmdLine,
                   int cmdShow)
{
    MSG msg;

    hInst = hInstance;

    //
    // We only allow one instance
    //

    if (hPrevInstance) {

        BringWindowToTop(FindWindow(szAppName, NULL));
        return 1;
    }

    //
    // Do the initialization
    //

    if (!Init(hInstance, cmdShow)) {
        return 1;
    }

    //
    // Check for messages from Windows and process them.
    // If no messages, perform some idle function
    // 

    while (GetMessage(&msg, NULL, 0, 0)) {

        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return (msg.wParam);
}
    
//
// main window message handler
//

LRESULT CALLBACK MainWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    PAINTSTRUCT ps;

    switch(msg) {
    case WM_CREATE:
        break;

    case WM_COMMAND:
        Command(hWnd, wParam, lParam); 
        break;

    case WM_PAINT:
        BeginPaint(hWnd, &ps);
        EndPaint(hWnd, &ps);
        break;

    case WM_TIMER:
        Update();
        break;

    case WM_MEASUREITEM:
        MeasureListItem(hWnd, (LPMEASUREITEMSTRUCT)lParam);
        return (LRESULT) TRUE;

    case WM_DRAWITEM:
        DrawListItem(hWnd, (LPDRAWITEMSTRUCT)lParam);
        break;

    case WM_SETFOCUS:
        if (hwndList) SetFocus(hwndList);
        break;

    case WM_DESTROY:

        Terminate();
        PostQuitMessage(0);
        break;

    default:
        return DefWindowProc(hWnd, msg, wParam, lParam);
        break;
    }
    return NULL;
}

static void Command(HWND hWnd, WPARAM wParam, LPARAM lParam) 
{
    char szCaption[256];

    switch (wParam) {
    case IDM_OPEN:
        if (_FileDlg(hWnd,
                    "Open File",
                    "Lyric files (*.lyr)|*.lyr|Text files (*.txt)|*.txt",
                    "*.lyr|*.txt",
                    szFileName,
                    sizeof(szFileName),
                    szAppName)) {

            //
            // Try reading the file
            //

            szTitle[0] = '\0';
            szArtist[0] = '\0';
            if (ReadFile(szFileName)) {

                //
                // Construct the caption
                //

                wsprintf(szCaption, 
                         "%s - %s",
                         (LPSTR)szArtist, 
                         (LPSTR)szTitle);
                SetWindowText(hwndMain, szCaption);
            } else {
                SetWindowText(hwndMain, szAppName);
            }
        }
        break;

    case IDM_SAVE:
        Save();
        break;

    case IDC_LIST:
        switch(HIWORD(lParam)) {
        case LBN_SELCHANGE:
            SetCurrentTime();
            break;

        default:
            break;
        }
        break;

    case IDM_EXIT:
        PostMessage(hWnd, WM_CLOSE, 0, 0l);
        break;

    default:
        break;
    }
}

//
// Initialise the app
//

static BOOL Init(HANDLE hInstance, int cmdShow)
{
    WNDCLASS wc;
    DWORD dwResult;
    MCI_SET_PARMS set;
    HDC hDC;
    RECT rc;

    //
    // define the class of window we want to register
    //

    wc.lpszClassName    = szAppName;
    wc.style            = CS_HREDRAW | CS_VREDRAW;
    wc.hCursor          = LoadCursor(NULL, IDC_ARROW);
    wc.hIcon            = LoadIcon(hInstance,"Icon");
    wc.lpszMenuName     = "Menu";
    wc.hbrBackground    = GetStockObject(WHITE_BRUSH);
    wc.hInstance        = hInstance;
    wc.lpfnWndProc      = MainWndProc;
    wc.cbClsExtra       = 0;
    wc.cbWndExtra       = 0;
    
    if (!RegisterClass(&wc)) {
        return FALSE;
    }

    //
    // Get any system metrics we care about
    //

    hDC = GetDC(NULL);
    GetTextMetrics(hDC, &tmSysFont);
    ReleaseDC(NULL, hDC);
    uiButtonHeight = 12 * tmSysFont.tmHeight / 8;

    //
    // Create GDI objects we use a lot
    //

    hpenRed = CreatePen(PS_SOLID, 1, RGB(255,0,0));
    hbrRed = CreateSolidBrush(RGB(255,0,0));

    //
    // Create the main window
    //

    hwndMain = CreateWindow(szAppName,
                            "Time-a-CD",
                            WS_OVERLAPPED | WS_VISIBLE | WS_CAPTION
                            | WS_SYSMENU | WS_MINIMIZEBOX,
                            CW_USEDEFAULT,
                            0,
                            GetSystemMetrics(SM_CXSCREEN) / 2,
                            GetSystemMetrics(SM_CYSCREEN),
                            (HWND)NULL,
                            (HMENU)NULL,
                            hInstance,
                            (LPSTR)NULL
                            );
    
    if (!hwndMain) {
        return FALSE;
    }

    GetClientRect(hwndMain, &rc);

    //
    // Create the listbox
    //

    hwndList = CreateWindow("Listbox",
                 "",
                 WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL
                 | LBS_NOINTEGRALHEIGHT | LBS_OWNERDRAWFIXED
                 | LBS_NOTIFY | LBS_DISABLENOSCROLL,
                 0, uiButtonHeight + 1,
                 rc.right - 1, rc.bottom - uiButtonHeight - 1,
                 hwndMain,
                 (HMENU)IDC_LIST,
                 hInstance,
                 (LPSTR)NULL);

    ShowWindow(hwndMain, cmdShow);
    UpdateWindow(hwndMain);

    //
    // Try to open the cdaudio device in shared mode
    //

    OpenParams.lpstrDeviceType = "cdaudio";
    OpenParams.wDeviceID = 0;
    dwResult = mciSendCommand(0,
                              MCI_OPEN,
                              MCI_WAIT | MCI_OPEN_SHAREABLE | MCI_OPEN_TYPE,
                              (DWORD)(LPVOID)&OpenParams);
    if (dwResult != 0) {
        MCIError(dwResult);
        return FALSE;
    }

    //
    // Set the time format we want
    //

    set.dwTimeFormat = MCI_FORMAT_TMSF;
    dwResult = mciSendCommand(OpenParams.wDeviceID,
                              MCI_SET,
                              MCI_WAIT | MCI_SET_TIME_FORMAT,
                              (DWORD)(LPVOID)&set);
    if (dwResult != 0) {
        MCIError(dwResult);
        return FALSE;
    }

    //
    // Start the update timer
    //

    uiTimerId = SetTimer(hwndMain, 1, 100, NULL);

    //
    // Launch the control app
    //

    WinExec("PLAYACD.EXE", SW_NORMAL);

    return TRUE;
}

//
// Close down and tidy up
//

static void Terminate(void)
{
    MCI_GENERIC_PARMS gp;
    DWORD dwResult;

    //
    // Nuke the timer
    //

    if (uiTimerId) {
        KillTimer(hwndMain, uiTimerId);
    }

    //
    // Close the MCI device
    //

    if (OpenParams.wDeviceID) {

        dwResult = mciSendCommand(OpenParams.wDeviceID,
                                  MCI_CLOSE,
                                  MCI_WAIT,
                                  (DWORD)(LPVOID)&gp);
        if (dwResult != 0) {
            MCIError(dwResult);
        }
    }

    //
    // Destroy GDI objects
    //

    DeleteObject(hpenRed);
    DeleteObject(hbrRed);

}

//
// Update the display with the current position
//

static void Update(void)
{
    MCI_STATUS_PARMS status;
    char buf[256];
    RECT rc;
    HDC hDC;
    LPSONGLINE lpLine;
    DWORD dwIndex;

    //
    // Get the current CD position
    //

    status.dwItem = MCI_STATUS_POSITION;
    if (mciSendCommand(OpenParams.wDeviceID,
                       MCI_STATUS,
                       MCI_WAIT | MCI_STATUS_ITEM,
                       (DWORD)(LPVOID)&status) != 0) {
        return;
    }

    dwPosition = status.dwReturn;

    //
    // erase any old line marker
    //

    SendMessage(hwndList, 
                LB_GETITEMRECT, 
                (WPARAM)LOWORD(dwCurrentIndex), 
                (LPARAM)(LPSTR)&rc);
    InvalidateRect(hwndList, &rc, FALSE);

    //
    // Find the current line of text to display
    //

    lpLine = FindLine(dwPosition);

    if (lpLine 
    && lpLine->lpText) {

        //
        // Find the text line which matches
        //

        dwIndex = SendMessage(hwndList,
                              LB_FINDSTRING,
                              0,
                              (LPARAM)lpLine);
        if ((dwIndex != LB_ERR)
        && (dwIndex != dwCurrentIndex)) {
            dwCurrentIndex = dwIndex;
            // force a redraw
            SendMessage(hwndList, 
                        LB_GETITEMRECT, 
                        (WPARAM)LOWORD(dwIndex), 
                        (LPARAM)(LPSTR)&rc);
            InvalidateRect(hwndList, &rc, FALSE);
        }
    } else {
        dwCurrentIndex = 0;
    }


    GetClientRect(hwndMain, &rc);
    rc.bottom = rc.top + uiButtonHeight;
    hDC = GetDC(hwndMain);

    wsprintf(buf,
             "%u, %u:%2.2u",
             (UINT)(dwPosition & 0xFF),
             (UINT)((dwPosition >> 8) & 0xFF),
             (UINT)((dwPosition >> 16) & 0xFF));

    ExtTextOut(hDC,
               12, uiButtonHeight - tmSysFont.tmHeight - 1,
               ETO_OPAQUE,
               &rc,
               buf,
               lstrlen(buf),
               NULL);

    ReleaseDC(hwndMain, hDC);
}

//
// Measure an item in our listbox
//

static void MeasureListItem(HWND hWnd, LPMEASUREITEMSTRUCT lpMIS)
{
    TEXTMETRIC tm;
    HDC hDC;


    hDC = GetDC(hWnd);
    GetTextMetrics(hDC, &tm);
    ReleaseDC(hWnd, hDC);
    lpMIS->itemHeight = tm.tmHeight;
}

//
// Display an item in our owner draw list box
//

static void DrawListItem(HWND hWnd, LPDRAWITEMSTRUCT lpDI)
{
    HBRUSH hbrBkGnd;
    RECT rc;
    HDC hDC;
    char buf[256];
    LPSONGLINE lpS;
    int x, y, d;
    
    hDC = lpDI->hDC;
    rc = lpDI->rcItem;

    switch (lpDI->itemAction) {

    case ODA_DRAWENTIRE:

        //
        // erase the rectangle
        //

        hbrBkGnd = CreateSolidBrush(GetSysColor(COLOR_WINDOW));
        FillRect(hDC, &rc, hbrBkGnd);
        DeleteObject(hbrBkGnd);

        //
        // show the info
        //
    
        SetBkMode(hDC, TRANSPARENT);
    
        lpS = (LPSONGLINE) lpDI->itemData;
        if (lpS) {

            wsprintf(buf,
                     "%u, %u:%2.2u - %s",
                     (UINT)(lpS->dwPosition & 0xFF),
                     (UINT)((lpS->dwPosition >> 8) & 0xFF),
                     (UINT)((lpS->dwPosition >> 16) & 0xFF),
                     lpS->lpText);

            ExtTextOut(hDC, 
                       rc.left+12, rc.top,
                       ETO_CLIPPED,
                       &rc, 
                       buf,
                       lstrlen(buf), 
                       NULL);
        }

        if (dwCurrentIndex == lpDI->itemID) {

            x = rc.left+4;
            y = rc.top+4;
            d = rc.bottom - rc.top - 8;
            Ellipse(hDC, 
                    x, y,
                    x + d, y + d);
        }

        if (lpDI->itemState & ODS_SELECTED) {
            InvertRect(hDC, &rc);
        }
        if (lpDI->itemState & ODS_FOCUS) {
            DrawFocusRect(hDC, &rc);
        }
        break;
    
    case ODA_SELECT:
        InvertRect(hDC, &rc);
        break;

    case ODA_FOCUS:
        DrawFocusRect(hDC, &rc);
        break;
    }
}

//
// Set the current time 
//

static void SetCurrentTime()
{
    UINT uiSel;
    LPSONGLINE lpS;
    RECT rc;

    //
    // Get the current listbox selection
    //

    uiSel = (UINT) SendMessage(hwndList, LB_GETCURSEL, 0, 0);
    if (uiSel == LB_ERR) return;

    //
    // Get the item data pointer
    //

    lpS = (LPSONGLINE) SendMessage(hwndList, LB_GETITEMDATA, uiSel, 0);
    if (lpS) {
        lpS->dwPosition = dwPosition;

        // force a redraw
        SendMessage(hwndList, LB_GETITEMRECT, uiSel, (LPARAM)(LPSTR)&rc);
        InvalidateRect(hwndList, &rc, FALSE);
    }
}

//
// Save to an output file
//

static void Save()
{
    char szFile[_MAX_PATH];
    char szDrive[_MAX_DRIVE];
    char szDir[_MAX_DIR];
    char szFname[_MAX_FNAME];
    char szExt[_MAX_EXT];
    FILE *fp;
    LPSONGLINE lpS;
    char buf[512];

    //
    // Create the name of the outpuit file
    //

    _splitpath(szFileName, szDrive, szDir, szFname, szExt);
    _makepath(szFile, szDrive, szDir, szFname, "LYR");

    fp = fopen(szFile, "w");
    if (!fp) return;

    fprintf(fp, "ARTIST  %s\n", szArtist);
    fprintf(fp, "TITLE   %s\n", szTitle);
    fprintf(fp, " \n");

    lpS = lpLyrics;
    while (lpS && lpS->lpText) {

        wsprintf(buf,
                "%2.2u,%2.2u:%2.2u.%2.2u  %s\n",
                (UINT)(lpS->dwPosition & 0xFF),
                (UINT)((lpS->dwPosition >> 8) & 0xFF),
                (UINT)((lpS->dwPosition >> 16) & 0xFF),
                (UINT)((lpS->dwPosition >> 24) & 0xFF),
                lpS->lpText);
        fprintf(fp, buf);

        lpS++;
    }

    fclose(fp);
}

//
// Find the current text line
//

static LPSONGLINE FindLine(DWORD dwPos)
{
    LPSONGLINE lpS;

    lpS = lpLyrics;
    if (!lpS) return NULL;

    while (lpS->lpText) {
        if (CompareTime(lpS->dwPosition, dwPos) <= 0) {

            //
            // This might be it.  See if the next line also might be it
            //

            if (lpS[1].lpText 
            && (CompareTime(lpS[1].dwPosition, dwPos) >= 0)) {
                break; // we found it
            }
        }
        lpS++;
    }
    return lpS;
}
