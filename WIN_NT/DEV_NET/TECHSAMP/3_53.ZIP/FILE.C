/*
    file.c

    File i/o stuff
*/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "common.h"

//
// global data
//

LPSONGLINE lpLyrics;                // pointer to lyric info
char szArtist[256];
char szTitle[256];

//
// Show a file open dialog
//

BOOL FAR PASCAL _FileDlg(HWND hWnd, 
                         LPSTR szTitle, 
                         LPSTR szFilter, 
                         LPSTR szExt,
                         LPSTR szFilePath, 
                         WORD nSizePath,
                         LPSTR lpszAppName)
{
    OPENFILENAME of;
    BOOL bResult;
    char szFileTitle[_MAX_FNAME+_MAX_EXT+2];
    char szFil[1024];
    LPSTR pS, pD;

    // copy the filter changing '|' for '\0' and tag an extra '\0' on

    if (szFilter == NULL) {
        pS = "All files|*.*";
    } else {
        pS = szFilter;
    }
    pD = szFil;
    while (*pS) {
        if (*pS == '|') {
            *pD = '\0';
        } else {
            *pD = *pS;
        }
        pD++;
        pS++;
    }
    *pD++ = '\0';
    *pD = '\0';

    szFilePath[0] = '\0';

    of.lStructSize      = sizeof(of);
    of.hwndOwner        = hWnd;
    of.hInstance        = NULL; // only used if OFN_ENABLETEMPLATE set
    of.lpstrFilter      = szFil;
    of.nFilterIndex     = 1;
    of.lpstrCustomFilter= NULL;
    of.nMaxCustFilter   = 0;
    of.lpstrFile        = szFilePath;
    of.nMaxFile         = nSizePath;
    of.lpstrFileTitle   = szFileTitle; // name and extension only
    of.nMaxFileTitle    = sizeof(szFileTitle);
    of.lpstrInitialDir  = NULL; // use current dir
    of.lpstrTitle       = szTitle;
    of.Flags            = OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT;
    of.nFileOffset      = 0;
    of.nFileExtension   = 0;
    of.lpstrDefExt      = szExt;
    of.lCustData        = 0;  
    of.lpfnHook         = NULL;
    of.lpTemplateName   = NULL;

    bResult = GetOpenFileName(&of);

    return bResult;
}

//
// Count the number of lines in a file
//

DWORD CountLines(int fd)
{
    char buf[1024];
    UINT uiBytes;
    DWORD dwLines = 0l;
    LPSTR lpBuf;

    while (uiBytes = _lread(fd, buf, sizeof(buf))) {
        lpBuf = buf;
        while (uiBytes--) {
            if (*lpBuf == '\n') dwLines++;
            lpBuf++;
        }
    }
    _llseek(fd, 0, SEEK_SET);
    return dwLines;
}

//
// Nuke an existing lyric list
//

void NukeLyrics()
{
    LPSONGLINE lp;

    if (hwndList) {
        SendMessage(hwndList, LB_RESETCONTENT, 0, 0);
    }
    if (!lpLyrics) return;
    lp = lpLyrics;
    while (lp->lpText) {
        _ffree(lp->lpText);
        lp++;
    }

    _ffree(lpLyrics);
    lpLyrics = NULL;
}

//
// Parse a lyric file line. Returns TRUE if a songline was parsed
// If the numeric value at the start of a songline has TMSF format
// it's decoded as that. Otherwise it's decoded as milliseconds
//

static BOOL ParseLyricLine(LPSTR lpLine, LPSONGLINE lpSongLine)
{
    DWORD track;
    UINT mins, secs, frames;
   

    while (*lpLine && isspace(*lpLine)) lpLine++; // skip spaces

    //
    // See if it's a tagged field we want
    //

    if (_fstrnicmp(lpLine, "ARTIST", 6) == 0) {
        lpLine += 6;
        while (*lpLine && isspace(*lpLine)) lpLine++; // skip spaces
        _fstrcpy(szArtist, lpLine);
        return FALSE;
    }

    if (_fstrnicmp(lpLine, "TITLE", 5) == 0) {
        lpLine += 5;
        while (*lpLine && isspace(*lpLine)) lpLine++; // skip spaces
        _fstrcpy(szTitle, lpLine);
        return FALSE;
    }

    //
    // If it's numeric it's a song line, otherwise ignore it
    //

    if (!isdigit(*lpLine)) return FALSE;

    //
    // Assume it's TMSF and collect the track, mins, secs and frames
    //

    track = 0;
    while (isdigit(*lpLine)) {
        track *= 10;
        track += (DWORD)(*lpLine - '0');
        lpLine++;
    }

    //
    // See if it really is TMSF
    //

    if (*lpLine == ',') {

        //
        // Collect the rest of the TMSF value
        //

        lpLine++;
        mins = 0;
        while (isdigit(*lpLine)) {
            mins *= 10;
            mins += *lpLine - '0';
            lpLine++;
        }
        if (*lpLine != ':') return FALSE;
        lpLine++;
        secs = 0;
        while (isdigit(*lpLine)) {
            secs *= 10;
            secs += *lpLine - '0';
            lpLine++;
        }
        if (*lpLine != '.') return FALSE;
        lpLine++;
        frames = 0;
        while (isdigit(*lpLine)) {
            frames *= 10;
            frames += *lpLine - '0';
            lpLine++;
        }
    
        lpSongLine->dwPosition = MCI_MAKE_TMSF(track,mins,secs,frames);

    } else {

        //
        // Assume it was a millisecond value
        //

        lpSongLine->dwPosition = track;

    }

    //
    // skip trailing white space
    // 

    while (*lpLine && isspace(*lpLine)) lpLine++;

    //
    // Allocate some memory for the text and copy it
    //

    lpSongLine->lpText = _fcalloc(lstrlen(lpLine)+1, sizeof(char));
    if (!lpSongLine->lpText) return FALSE;

    lstrcpy(lpSongLine->lpText, lpLine);

    //
    // Add an entry to the listbox
    //

    if (hwndList) {
        SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM)(LPSTR)lpSongLine);
    }
    return TRUE;
}

//
// Read a lyric file and build a new info list
//

BOOL ReadLyrics(LPSTR lpFile)
{
    int fd;
    OFSTRUCT os;
    DWORD dwLines;
    char buf[1024];
    char line[1024];
    UINT uiBytes;
    LPSTR lpBuf, lpLine;
    LPSONGLINE lpSongLine;

    //
    // open the file and count the lines in it
    // (this ignores the fact that some lines have
    // irrelavant info in them)
    //

    fd = OpenFile(lpFile, &os, OF_READ);
    if (fd < 1) {
        return FALSE;
    }

    dwLines = CountLines(fd);

    if (!dwLines) return FALSE;

    NukeLyrics(); // get rid of any old ones

    //
    // Allocate a new array for the info
    //

    lpLyrics = (LPSONGLINE) _fcalloc(LOWORD(dwLines)+1, sizeof(SONGLINE));
    if (!lpLyrics) return FALSE;

    //
    // Read each line and fill out the info for each one
    //

    lpSongLine = lpLyrics;
    lpLine = line;
    while (uiBytes = _lread(fd, buf, sizeof(buf))) {
        lpBuf = buf;
        while (uiBytes--) {

            switch (*lpBuf) {
            case '\n':
                *lpLine = '\0';

                // parse it and add to the info
                if (ParseLyricLine(line, lpSongLine)) {
                    lpSongLine++;
                }
                lpLine = line;
                break;

            case '\r':
                break;

            default:
                *lpLine++ = *lpBuf;
                break;
            }

            lpBuf++;
        }
    }

    _lclose(fd);

    return TRUE;
}

//
// Parse a text file line. Returns TRUE if a songline was parsed
//

static BOOL ParseTextLine(LPSTR lpLine, LPSONGLINE lpSongLine)
{

    while (*lpLine && isspace(*lpLine)) lpLine++; // skip spaces

    //
    // See if it's a tagged field we want
    //

    if (_fstrnicmp(lpLine, "ARTIST", 6) == 0) {
        lpLine += 6;
        while (*lpLine && isspace(*lpLine)) lpLine++; // skip spaces
        _fstrcpy(szArtist, lpLine);
        return FALSE;
    }

    if (_fstrnicmp(lpLine, "TITLE", 5) == 0) {
        lpLine += 5;
        while (*lpLine && isspace(*lpLine)) lpLine++; // skip spaces
        _fstrcpy(szTitle, lpLine);
        return FALSE;
    }

    //
    // Assume it's a song line
    //

    lpSongLine->dwPosition = MCI_MAKE_TMSF(0,0,0,0);

    //
    // Allocate some memory for the text and copy it
    //

    lpSongLine->lpText = _fcalloc(lstrlen(lpLine)+1, sizeof(char));
    if (!lpSongLine->lpText) return FALSE;

    lstrcpy(lpSongLine->lpText, lpLine);

    //
    // Add an entry to the listbox
    //

    if (hwndList) {
        SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM)(LPSTR)lpSongLine);
    }
    return TRUE;
}

//
// Read a text file and build a new info list
//

BOOL ReadText(LPSTR lpFile)
{
    int fd;
    OFSTRUCT os;
    DWORD dwLines;
    char buf[1024];
    char line[1024];
    UINT uiBytes;
    LPSTR lpBuf, lpLine;
    LPSONGLINE lpSongLine;

    //
    // open the file and count the lines in it
    // (this ignores the fact that some lines have
    // irrelavant info in them)
    //

    fd = OpenFile(lpFile, &os, OF_READ);
    if (fd < 1) {
        return FALSE;
    }

    dwLines = CountLines(fd);

    if (!dwLines) return FALSE;

    NukeLyrics(); // get rid of any old ones

    //
    // Allocate a new array for the info
    //

    lpLyrics = (LPSONGLINE) _fcalloc(LOWORD(dwLines)+1, sizeof(SONGLINE));
    if (!lpLyrics) return FALSE;

    //
    // Read each line and fill out the info for each one
    //

    lpSongLine = lpLyrics;
    lpLine = line;
    while (uiBytes = _lread(fd, buf, sizeof(buf))) {
        lpBuf = buf;
        while (uiBytes--) {

            switch (*lpBuf) {
            case '\n':
                *lpLine = '\0';

                // parse it and add to the info
                if (ParseTextLine(line, lpSongLine)) {
                    lpSongLine++;
                }
                lpLine = line;
                break;

            case '\r':
                break;

            default:
                *lpLine++ = *lpBuf;
                break;
            }

            lpBuf++;
        }
    }

    _lclose(fd);

    return TRUE;
}

//
// Read a text or lyric file
//

BOOL ReadFile(char *szFile)
{
    char szExt[_MAX_EXT];

    //
    // see what extension it is
    //

    _splitpath(szFile, NULL, NULL, NULL, szExt);
    if (_fstrnicmp(szExt, ".LYR", 3) == 0) {
        return ReadLyrics(szFile);
    }

    return ReadText(szFile);
}
