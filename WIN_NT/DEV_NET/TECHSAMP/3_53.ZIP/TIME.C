/*
    time.c

    Time functions

*/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "common.h"

//
// Compare two times
// Returns 1 if A>B, 0 if A=B, -1 if A<B
//

int CompareTime(DWORD dwA, DWORD dwB)
{
    if (MCI_TMSF_TRACK(dwA) > MCI_TMSF_TRACK(dwB)) return 1;
    if (MCI_TMSF_TRACK(dwA) < MCI_TMSF_TRACK(dwB)) return -1;
    if (MCI_TMSF_MINUTE(dwA) > MCI_TMSF_MINUTE(dwB)) return 1;
    if (MCI_TMSF_MINUTE(dwA) < MCI_TMSF_MINUTE(dwB)) return -1;
    if (MCI_TMSF_SECOND(dwA) > MCI_TMSF_SECOND(dwB)) return 1;
    if (MCI_TMSF_SECOND(dwA) < MCI_TMSF_SECOND(dwB)) return -1;
    if (MCI_TMSF_FRAME(dwA) > MCI_TMSF_FRAME(dwB)) return 1;
    if (MCI_TMSF_FRAME(dwA) < MCI_TMSF_FRAME(dwB)) return -1;
    return 0;
}

//
// Subtract time B from time A and return result in frames
//

DWORD TimeDiff(DWORD dwA, DWORD dwB)
{
    DWORD dwDiff;

    if (MCI_TMSF_TRACK(dwA) != MCI_TMSF_TRACK(dwB)) return 1; // hack

    dwDiff = (MCI_TMSF_MINUTE(dwA) - MCI_TMSF_MINUTE(dwB)) * 60 * 75;
    dwDiff += (MCI_TMSF_SECOND(dwA) - MCI_TMSF_SECOND(dwB)) * 75;
    dwDiff += MCI_TMSF_FRAME(dwA) - MCI_TMSF_FRAME(dwB);

    return dwDiff;
}
