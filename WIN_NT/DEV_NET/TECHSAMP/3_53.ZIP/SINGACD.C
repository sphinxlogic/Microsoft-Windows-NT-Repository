/*
    singacd.c

    Sing along with your favorite CD

    Another fine Herman Rodent production

*/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "singacd.h"

//
// global data
//

char *szAppName = "SingaCD";        // app name
HINSTANCE hInst;                    // app instance
HWND hwndMain;                      // main window handle
UINT uiTimerId;                     // update timer
TEXTMETRIC tmSysFont;               // system font metrics
UINT uiButtonHeight;                // height of a button
LPSONGLINE lpCurrentLine;           // pointer to current song line
HPEN hpenRed;
HBRUSH hbrRed;
HWND hwndList;


//
// local functions
//

static BOOL Init(HANDLE hInstance, int cmdShow);
static void Terminate(void);
static void Update(void);
static LPSONGLINE FindLine(DWORD dwPos);

//
// Entry point
//

int PASCAL WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpszCmdLine,
                   int cmdShow)
{
    MSG msg;
    HMENU hMenu;

    hInst = hInstance;

    //
    // We only allow one instance
    //

    if (hPrevInstance) {

        BringWindowToTop(FindWindow(szAppName, NULL));
        return 1;
    }

    //
    // Do the initialization
    //

    if (!Init(hInstance, cmdShow)) {
        return 1;
    }

    //
    // Add the file open item to the system menu
    //

    hMenu = GetSystemMenu(hwndMain, FALSE);
    AppendMenu(hMenu, MF_ENABLED | MF_STRING, IDM_OPEN, "Open File...");

    //
    // Check for messages from Windows and process them.
    // If no messages, perform some idle function
    // 

    while (GetMessage(&msg, NULL, 0, 0)) {

        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return (msg.wParam);
}
    
//
// main window message handler
//

LRESULT CALLBACK MainWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    PAINTSTRUCT ps;
    char szFileName[_MAX_PATH];
    char szCaption[256];


    switch(msg) {
    case WM_CREATE:
        break;

    case WM_SYSCOMMAND:
        if (wParam == IDM_OPEN) {
            if (_FileDlg(hWnd,
                        "Open File",
                        "Lyric files (*.lyr)|*.lyr",
                        "*.lyr",
                        szFileName,
                        sizeof(szFileName),
                        szAppName)) {
    
                //
                // Try reading the file
                //
    
                szTitle[0] = '\0';
                szArtist[0] = '\0';
                if (ReadLyrics(szFileName)) {
    
                    //
                    // Construct the caption
                    //
    
                    wsprintf(szCaption, 
                             "%s - %s",
                             (LPSTR)szArtist, 
                             (LPSTR)szTitle);
                    SetWindowText(hwndMain, szCaption);
                } else {
                    SetWindowText(hwndMain, szAppName);
                }
            }


        } else {
            return DefWindowProc(hWnd, msg, wParam, lParam);
        }
        break;

    case WM_PAINT:
        BeginPaint(hWnd, &ps);
        EndPaint(hWnd, &ps);
        break;

    case WM_TIMER:
        Update();
        break;

    case WM_DESTROY:

        Terminate();
        PostQuitMessage(0);
        break;

    default:
        return DefWindowProc(hWnd, msg, wParam, lParam);
        break;
    }
    return NULL;
}

//
// Initialise the app
//

static BOOL Init(HANDLE hInstance, int cmdShow)
{
    WNDCLASS wc;
    DWORD dwResult;
    MCI_SET_PARMS set;
    HDC hDC;

    //
    // define the class of window we want to register
    //

    wc.lpszClassName    = szAppName;
    wc.style            = CS_HREDRAW | CS_VREDRAW;
    wc.hCursor          = LoadCursor(NULL, IDC_ARROW);
    wc.hIcon            = LoadIcon(hInstance,"Icon");
    wc.lpszMenuName     = NULL;
    wc.hbrBackground    = GetStockObject(WHITE_BRUSH);
    wc.hInstance        = hInstance;
    wc.lpfnWndProc      = MainWndProc;
    wc.cbClsExtra       = 0;
    wc.cbWndExtra       = 0;
    
    if (!RegisterClass(&wc)) {
        return FALSE;
    }

    //
    // Get any system metrics we care about
    //

    hDC = GetDC(NULL);
    GetTextMetrics(hDC, &tmSysFont);
    ReleaseDC(NULL, hDC);
    uiButtonHeight = 12 * tmSysFont.tmHeight / 8;

    //
    // Create GDI objects we use a lot
    //

    hpenRed = CreatePen(PS_SOLID, 1, RGB(255,0,0));
    hbrRed = CreateSolidBrush(RGB(255,0,0));

    //
    // Create the main window
    //

    hwndMain = CreateWindow(szAppName,
                            "Sing-a-CD",
                            WS_OVERLAPPED | WS_VISIBLE | WS_CAPTION
                            | WS_SYSMENU | WS_MINIMIZEBOX,
                            CW_USEDEFAULT,
                            0,
                            GetSystemMetrics(SM_CXSCREEN) / 2,
                            GetSystemMetrics(SM_CYCAPTION)
                            + uiButtonHeight + 1,
                            (HWND)NULL,
                            (HMENU)NULL,
                            hInstance,
                            (LPSTR)NULL
                            );
    
    if (!hwndMain) {
        return FALSE;
    }

    ShowWindow(hwndMain, cmdShow);
    UpdateWindow(hwndMain);

    //
    // Try to open the cdaudio device in shared mode
    //

    OpenParams.lpstrDeviceType = "cdaudio";
    OpenParams.wDeviceID = 0;
    dwResult = mciSendCommand(0,
                              MCI_OPEN,
                              MCI_WAIT | MCI_OPEN_SHAREABLE | MCI_OPEN_TYPE,
                              (DWORD)(LPVOID)&OpenParams);
    if (dwResult != 0) {
        MCIError(dwResult);
        return FALSE;
    }

    //
    // Set the time format we want
    //

    set.dwTimeFormat = MCI_FORMAT_TMSF;
    dwResult = mciSendCommand(OpenParams.wDeviceID,
                              MCI_SET,
                              MCI_WAIT | MCI_SET_TIME_FORMAT,
                              (DWORD)(LPVOID)&set);
    if (dwResult != 0) {
        MCIError(dwResult);
        return FALSE;
    }

    //
    // Start the update timer
    //

    uiTimerId = SetTimer(hwndMain, 1, 100, NULL);

    //
    // Launch the control app
    //

    WinExec("PLAYACD.EXE", SW_NORMAL);


    return TRUE;
}

//
// Close down and tidy up
//

static void Terminate(void)
{
    MCI_GENERIC_PARMS gp;
    DWORD dwResult;

    //
    // Nuke the timer
    //

    if (uiTimerId) {
        KillTimer(hwndMain, uiTimerId);
    }

    //
    // Close the MCI device
    //

    if (OpenParams.wDeviceID) {

        dwResult = mciSendCommand(OpenParams.wDeviceID,
                                  MCI_CLOSE,
                                  MCI_WAIT,
                                  (DWORD)(LPVOID)&gp);
        if (dwResult != 0) {
            MCIError(dwResult);
        }
    }

    //
    // Destroy GDI objects
    //

    DeleteObject(hpenRed);
    DeleteObject(hbrRed);

}

//
// Update the display
//

static void Update(void)
{
    MCI_STATUS_PARMS status;
    char buf[256];
    RECT rc;
    HDC hDC;
    DWORD dwExt;
    LPSTR lpB;
    LPSONGLINE lpLine;
    int x, y, dia;
    HBRUSH hbrOld;
    HPEN hpenOld;

    //
    // Get the current CD position
    //

    status.dwItem = MCI_STATUS_POSITION;
    if (mciSendCommand(OpenParams.wDeviceID,
                       MCI_STATUS,
                       MCI_WAIT | MCI_STATUS_ITEM,
                       (DWORD)(LPVOID)&status) != 0) {
        return;
    }

    dwPosition = status.dwReturn;

    GetClientRect(hwndMain, &rc);
    rc.bottom = rc.top + uiButtonHeight;
    hDC = GetDC(hwndMain);

    //
    // Find the current line of text to display
    //

    lpLine = FindLine(dwPosition);

    if (lpLine && lpLine->lpText) {

        lpCurrentLine = lpLine;

    } else {
        lpCurrentLine = NULL;
    }

    wsprintf(buf,
             "%s",
             (lpCurrentLine && lpCurrentLine->lpText) 
                ? lpCurrentLine->lpText 
                : (LPSTR)"(no lyrics)");

    ExtTextOut(hDC,
               2, uiButtonHeight - tmSysFont.tmHeight - 1,
               ETO_OPAQUE,
               &rc,
               buf,
               lstrlen(buf),
               NULL);

    //
    // Work out where to put the ball
    //

    if (lpCurrentLine 
    && lpCurrentLine->lpText
    && (lpCurrentLine->lpText[0] != COMMENTCHAR)
    && lstrlen(lpCurrentLine->lpText)) {

        lpB = buf;

        //
        // Draw the ball at the start of the word
        //

        dia = uiButtonHeight - tmSysFont.tmHeight;
        x = 2;

        //
        // Put the ball proportionately along the line
        //

        dwExt = GetTextExtent(hDC, lpB, lstrlen(lpB));
        x += (int) ((DWORD) LOWORD(dwExt) 
             * TimeDiff(dwPosition, lpLine->dwPosition)
             / TimeDiff(lpLine[1].dwPosition, lpLine->dwPosition));

        y = 1;
        hpenOld = SelectObject(hDC, hpenRed);
        hbrOld = SelectObject(hDC, hbrRed);

        Ellipse(hDC, x, y, x+dia, y+dia);

        SelectObject(hDC, hpenOld);
        SelectObject(hDC, hbrOld);


    }
    ReleaseDC(hwndMain, hDC);
}

//
// Find the current text line
//

static LPSONGLINE FindLine(DWORD dwPos)
{
    LPSONGLINE lpS;

    lpS = lpLyrics;
    if (!lpS) return NULL;

    while (lpS->lpText) {
        if (CompareTime(lpS->dwPosition, dwPos) <= 0) {

            //
            // This might be it.  See if the next line also might be it
            //

            if (lpS[1].lpText 
            && (CompareTime(lpS[1].dwPosition, dwPos) >= 0)) {
                break; // we found it
            }
        }
        lpS++;
    }
    return lpS;
}

