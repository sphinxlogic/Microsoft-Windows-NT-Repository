/*
    mci.c

    Common routines to interface with MCI
*/
 
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
// 
 
#include "common.h"

//
// global data
//

MCI_OPEN_PARMS OpenParams;          // MCI params for cdaudio device
DWORD dwPosition;                   // current position

//
// Get the current mode
//

DWORD GetMode()
{
    MCI_STATUS_PARMS status;
    DWORD dwResult;

    //
    // get the current status
    //

    status.dwItem = MCI_STATUS_MODE;
    dwResult = mciSendCommand(OpenParams.wDeviceID,
                              MCI_STATUS,
                              MCI_WAIT | MCI_STATUS_ITEM,
                              (DWORD)(LPVOID)&status);
    if (dwResult == 0) {
        return status.dwReturn;
    }
    MCIError(dwResult);
    return MCI_MODE_NOT_READY; // slightly bogus
}

//
// Start playing
//

void Play()
{
    MCI_PLAY_PARMS play;
    DWORD dwResult;

    dwResult = mciSendCommand(OpenParams.wDeviceID,
                              MCI_PLAY,
                              NULL,
                              (DWORD)(LPVOID)&play);
    if (dwResult != 0) {
        MCIError(dwResult);
    }
}

//
// Stop playing
//

void Stop()
{
    DWORD dwResult;

    dwResult = mciSendCommand(OpenParams.wDeviceID,
                              MCI_STOP,
                              MCI_WAIT,
                              (DWORD)(LPVOID)NULL);
    if (dwResult != 0) {
        MCIError(dwResult);
    }
}

//
// Skip to the next track
//

void Skip()
{
    MCI_SEEK_PARMS seek;
    DWORD dwResult, dwMode;

    //
    // get the current mode
    //

    dwMode = GetMode();

    //
    // Seek to the next track
    //

    seek.dwTo = MCI_MAKE_TMSF(MCI_TMSF_TRACK(dwPosition)+1,0,0,0);
    dwResult = mciSendCommand(OpenParams.wDeviceID,
                              MCI_SEEK,
                              MCI_WAIT | MCI_TO,
                              (DWORD)(LPVOID)&seek);
    if (dwResult != 0) {
        MCIError(dwResult);
    } else {
        dwPosition = seek.dwTo;
        if (dwMode == MCI_MODE_PLAY) {
            Play(); // restart the play
        }
    }
}

//
// Go back to the start of this or the previous track
//

void Back()
{
    MCI_SEEK_PARMS seek;
    DWORD dwResult, dwMode, dwTrack;

    //
    // get the current mode
    //

    dwMode = GetMode();

    //
    // if the minutes and seconds of the current track position are 
    // both zero then go back to the start of the previous track,
    // otherwise just go back to the start of the current track
    //

    dwTrack = MCI_TMSF_TRACK(dwPosition);

    if (MCI_TMSF_MINUTE(dwPosition) || MCI_TMSF_SECOND(dwPosition)) {

        //
        // Go back to the start of the current track
        //

        seek.dwTo = MCI_MAKE_TMSF(dwTrack, 0, 0, 0);

    } else {

        //
        // Go back to the start of the previous track
        //

        if (dwTrack == 1) return; // no prev track

        seek.dwTo = MCI_MAKE_TMSF(dwTrack - 1, 0, 0, 0);

    }

    //
    // Seek to the new position
    //

    dwResult = mciSendCommand(OpenParams.wDeviceID,
                              MCI_SEEK,
                              MCI_WAIT | MCI_TO,
                              (DWORD)(LPVOID)&seek);
    if (dwResult != 0) {
        MCIError(dwResult);
    } else {
        if (dwMode == MCI_MODE_PLAY) {
            Play(); // restart the play
        }
    }
}

//
// Show an MCI error string
//

void MCIError(DWORD dwErr)
{
    char buf[256];

    buf[0] = '\0';
    mciGetErrorString(dwErr, buf, sizeof(buf));
    if (!lstrlen(buf)) {
        lstrcpy(buf, "Unknown error");
    }
    MessageBox(hwndMain, buf, "Sing-a-CD MCI Error", MB_OK);
}

//
// Seek back ten seconds
//

void SeekBack()
{
    MCI_SEEK_PARMS seek;
    DWORD dwResult, dwMode, dwTrack, dwMins, dwSecs;

    //
    // get the current mode
    //

    dwMode = GetMode();

    dwTrack = MCI_TMSF_TRACK(dwPosition);
    dwMins = MCI_TMSF_MINUTE(dwPosition);
    dwSecs = MCI_TMSF_SECOND(dwPosition);

    if ((dwMins == 0)
    && (dwSecs == 0)) {
        return;
    }

    if (dwSecs >= 10) {
        dwSecs -= 10;
    } else {
        if (dwMins > 0) {
            dwMins--;
            dwSecs += 50;
        } else {
            dwSecs = 0;
        }
    }

    seek.dwTo = MCI_MAKE_TMSF(dwTrack, dwMins, dwSecs, 0);

    //
    // Seek to the new position
    //

    dwResult = mciSendCommand(OpenParams.wDeviceID,
                              MCI_SEEK,
                              MCI_WAIT | MCI_TO,
                              (DWORD)(LPVOID)&seek);
    if (dwResult == 0) {
        if (dwMode == MCI_MODE_PLAY) {
            Play(); // restart the play
        }
    } else {
        MCIError(dwResult);
    }
}

//
// Seek forward ten seconds
//

void SeekForward()
{
    MCI_SEEK_PARMS seek;
    DWORD dwResult, dwMode, dwTrack, dwMins, dwSecs;

    //
    // get the current mode
    //

    dwMode = GetMode();

    dwTrack = MCI_TMSF_TRACK(dwPosition);
    dwMins = MCI_TMSF_MINUTE(dwPosition);
    dwSecs = MCI_TMSF_SECOND(dwPosition);

    dwSecs += 10;

    if (dwSecs >= 60) {
        dwSecs -= 60;
        dwMins++;
    }

    seek.dwTo = MCI_MAKE_TMSF(dwTrack, dwMins, dwSecs, 0);

    //
    // Seek to the new position
    //

    dwResult = mciSendCommand(OpenParams.wDeviceID,
                              MCI_SEEK,
                              MCI_WAIT | MCI_TO,
                              (DWORD)(LPVOID)&seek);
    if (dwResult == 0) {
        if (dwMode == MCI_MODE_PLAY) {
            Play(); // restart the play
        }
    } else {
        MCIError(dwResult);
    }
}
