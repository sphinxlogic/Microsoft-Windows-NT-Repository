/*
    playacd.c

    Simple CD player

    Another fine Herman Rodent production

*/

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "playacd.h"

//
// global data
//

char *szAppName = "PlayaCD";        // app name
HINSTANCE hInst;                    // app instance
HWND hwndMain;                      // main window handle
UINT uiTimerId;                     // update timer
UINT uiRepeatTimerId;
HBITMAP hbmButtons;                 // button images
UINT uiRepeatCount;

//
// local functions
//

static void Command(HWND hWnd, WPARAM wParam, LPARAM lParam);
static BOOL Init(HANDLE hInstance, int cmdShow);
static void Terminate(void);
static void Update(void);
static void DrawButton(HWND hWnd, LPDRAWITEMSTRUCT lpDI);
static void Repeat(UINT uiID);

//
// Entry point
//

int PASCAL WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpszCmdLine,
                   int cmdShow)
{
    MSG msg;

    hInst = hInstance;

    //
    // We only allow one instance
    //

    if (hPrevInstance) {

        BringWindowToTop(FindWindow(szAppName, NULL));
        return 1;
    }

    //
    // Do the initialization
    //

    if (!Init(hInstance, cmdShow)) {
        return 1;
    }

    //
    // Check for messages from Windows and process them.
    // If no messages, perform some idle function
    // 

    while (GetMessage(&msg, NULL, 0, 0)) {

        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return (msg.wParam);
}
    
//
// main window message handler
//

LRESULT CALLBACK MainWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    PAINTSTRUCT ps;

    switch(msg) {
    case WM_CREATE:
        break;

    case WM_COMMAND:
        Command(hWnd, wParam, lParam); 
        break;

    case WM_PAINT:
        BeginPaint(hWnd, &ps);
        EndPaint(hWnd, &ps);
        break;

    case WM_DRAWITEM:
        DrawButton(hWnd, (LPDRAWITEMSTRUCT)lParam);
        break;

    case WM_TIMER:
        switch (wParam & TIMERMASK) {
        case UPDATETIMER:
            Update();
            break;

        case REPEATTIMER:
            Repeat(wParam & REPEATMASK);
            break;

        default:
            break;
        }
        break;

    case WM_DESTROY:
        Terminate();
        PostQuitMessage(0);
        break;

    default:
        return DefWindowProc(hWnd, msg, wParam, lParam);
        break;
    }
    return NULL;
}

static void Command(HWND hWnd, WPARAM wParam, LPARAM lParam) 
{
    switch (wParam) {
    case IDC_PLAY:
        Play();
        break;

    case IDC_STOP:
        Stop();
        break;

    case IDC_BACK:
        Back();
        break;

    case IDC_FORWARD:
        Skip();
        break;

    case IDC_SEEKBACK:
        if (uiRepeatCount == 0) SeekBack();
        break;

    case IDC_SEEKFORWARD:
        if (uiRepeatCount == 0) SeekForward();
        break;

    default:
        break;
    }
}

//
// Initialise the app
//

static BOOL Init(HANDLE hInstance, int cmdShow)
{
    WNDCLASS wc;
    DWORD dwResult;
    MCI_SET_PARMS set;
    int x, y;

    //
    // define the class of window we want to register
    //

    wc.lpszClassName    = szAppName;
    wc.style            = CS_HREDRAW | CS_VREDRAW;
    wc.hCursor          = LoadCursor(NULL, IDC_ARROW);
    wc.hIcon            = LoadIcon(hInstance,"Icon");
    wc.lpszMenuName     = NULL;
    wc.hbrBackground    = GetStockObject(WHITE_BRUSH);
    wc.hInstance        = hInstance;
    wc.lpfnWndProc      = MainWndProc;
    wc.cbClsExtra       = 0;
    wc.cbWndExtra       = 0;
    
    if (!RegisterClass(&wc)) {
        return FALSE;
    }

    //
    // Load the button images
    //

    hbmButtons = LoadBitmap(hInstance, "Buttons");

    //
    // Create the main window
    //

    hwndMain = CreateWindow(szAppName,
                            "Play-a-CD",
                            WS_OVERLAPPED | WS_VISIBLE | WS_CAPTION
                            | WS_SYSMENU,
                            CW_USEDEFAULT,
                            0,
                            BUTTONWIDTH * 6 + 1,
                            GetSystemMetrics(SM_CYCAPTION)
                            + BUTTONHEIGHT + 1,
                            (HWND)NULL,
                            (HMENU)NULL,
                            hInstance,
                            (LPSTR)NULL
                            );
    
    if (!hwndMain) {
        return FALSE;
    }

    //
    // Create the buttons
    //

    x = 0;
    y = 0;
    CreateWindow("Button",
                 "B",
                 WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW,
                 x, y,
                 BUTTONWIDTH, BUTTONHEIGHT,
                 hwndMain,
                 (HMENU)IDC_BACK,
                 hInstance,
                 (LPSTR)NULL);
    x += BUTTONWIDTH;
    CreateWindow("Button",
                 "F",
                 WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW,
                 x, y,
                 BUTTONWIDTH, BUTTONHEIGHT,
                 hwndMain,
                 (HMENU)IDC_FORWARD,
                 hInstance,
                 (LPSTR)NULL);
    x += BUTTONWIDTH;
    CreateWindow("Button",
                 "<",
                 WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW,
                 x, y,
                 BUTTONWIDTH, BUTTONHEIGHT,
                 hwndMain,
                 (HMENU)IDC_SEEKBACK,
                 hInstance,
                 (LPSTR)NULL);
    x += BUTTONWIDTH;
    CreateWindow("Button",
                 ">",
                 WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW,
                 x, y,
                 BUTTONWIDTH, BUTTONHEIGHT,
                 hwndMain,
                 (HMENU)IDC_SEEKFORWARD,
                 hInstance,
                 (LPSTR)NULL);
    x += BUTTONWIDTH;
    CreateWindow("Button",
                 "P",
                 WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW,
                 x, y,
                 BUTTONWIDTH, BUTTONHEIGHT,
                 hwndMain,
                 (HMENU)IDC_PLAY,
                 hInstance,
                 (LPSTR)NULL);
    x += BUTTONWIDTH;
    CreateWindow("Button",
                 "S",
                 WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW,
                 x, y,
                 BUTTONWIDTH, BUTTONHEIGHT,
                 hwndMain,
                 (HMENU)IDC_STOP,
                 hInstance,
                 (LPSTR)NULL);

    ShowWindow(hwndMain, cmdShow);
    UpdateWindow(hwndMain);

    //
    // Try to open the cdaudio device in shared mode
    //

    OpenParams.lpstrDeviceType = "cdaudio";
    OpenParams.wDeviceID = 0;
    dwResult = mciSendCommand(0,
                              MCI_OPEN,
                              MCI_WAIT | MCI_OPEN_SHAREABLE | MCI_OPEN_TYPE,
                              (DWORD)(LPVOID)&OpenParams);
    if (dwResult != 0) {
        MCIError(dwResult);
        return FALSE;
    }

    //
    // Set the time format we want
    //

    set.dwTimeFormat = MCI_FORMAT_TMSF;
    dwResult = mciSendCommand(OpenParams.wDeviceID,
                              MCI_SET,
                              MCI_WAIT | MCI_SET_TIME_FORMAT,
                              (DWORD)(LPVOID)&set);
    if (dwResult != 0) {
        MCIError(dwResult);
        return FALSE;
    }

    //
    // Start the update timer
    //

    uiTimerId = SetTimer(hwndMain, UPDATETIMER, 300, NULL);

    return TRUE;
}

//
// Close down and tidy up
//

static void Terminate(void)
{
    MCI_GENERIC_PARMS gp;
    DWORD dwResult;

    //
    // Nuke the timer
    //

    if (uiTimerId) {
        KillTimer(hwndMain, uiTimerId);
    }

    //
    // Close the MCI device
    //

    if (OpenParams.wDeviceID) {

        dwResult = mciSendCommand(OpenParams.wDeviceID,
                                  MCI_CLOSE,
                                  MCI_WAIT,
                                  (DWORD)(LPVOID)&gp);
        if (dwResult != 0) {
            MCIError(dwResult);
        }
    }

    //
    // Nuke any GDI objects
    //

    if (hbmButtons) DeleteObject(hbmButtons);

}

//
// Update the display
//

static void Update(void)
{
    MCI_STATUS_PARMS status;
    char buf[256];

    //
    // Get the current CD position
    //

    status.dwItem = MCI_STATUS_POSITION;
    if (mciSendCommand(OpenParams.wDeviceID,
                       MCI_STATUS,
                       MCI_WAIT | MCI_STATUS_ITEM,
                       (DWORD)(LPVOID)&status) != 0) {
        return;
    }

    dwPosition = status.dwReturn;

    wsprintf(buf,
             "%u, %u:%2.2u",
             (UINT)(dwPosition & 0xFF),
             (UINT)((dwPosition >> 8) & 0xFF),
             (UINT)((dwPosition >> 16) & 0xFF));

    SetWindowText(hwndMain, buf);
}

//
// Display a button.  We also use the up/down transitions to
// enable the repeat timer.
//

static void DrawButton(HWND hWnd, LPDRAWITEMSTRUCT lpDI)
{
    RECT rc;
    HDC hDC, hdcBtn;
    int iXBtn, iYBtn;
    
    hDC = lpDI->hDC;
    rc = lpDI->rcItem;

    switch (lpDI->itemAction) {

    case ODA_DRAWENTIRE:
    case ODA_SELECT:
    case ODA_FOCUS:

        hdcBtn = CreateCompatibleDC(hDC);
        SelectObject(hdcBtn, hbmButtons);

        //
        // figure out which button image to use
        //

        switch (lpDI->CtlID) {
        case IDC_BACK:
            iXBtn = 0;
            break;

        case IDC_FORWARD:
            iXBtn = BUTTONWIDTH;
            break;

        case IDC_SEEKBACK:
            iXBtn = BUTTONWIDTH * 4;
            break;

        case IDC_SEEKFORWARD:
            iXBtn = BUTTONWIDTH * 5;
            break;

        case IDC_PLAY:
            iXBtn = BUTTONWIDTH * 3;
            break;

        case IDC_STOP:
        default:
            iXBtn = BUTTONWIDTH * 2;
            break;
        }
        
        //
        // figure out the button's state 
        // and enable the repeat timer for down buttons
        //

        if (lpDI->itemState & ODS_SELECTED) {
            iYBtn = BUTTONHEIGHT;

            // enable the repeat timer
            uiRepeatCount = 0;
            uiRepeatTimerId = SetTimer(hwndMain,
                                       REPEATTIMER | lpDI->CtlID,
                                       1000,
                                       NULL);
        } else {
            iYBtn = 0;

            // stop the repeat timer
            if (uiRepeatTimerId) {
                KillTimer(hwndMain, uiRepeatTimerId);
                uiRepeatTimerId = 0;
            }

        }

        BitBlt(hDC, 
               0, 0,
               BUTTONWIDTH, BUTTONHEIGHT,
               hdcBtn, 
               iXBtn, iYBtn,
               SRCCOPY);
    
        DeleteDC(hdcBtn);

        break;
    }
}

//
// Repeat a button action
//

static void Repeat(UINT uiID)
{
    switch (uiID) {
    case IDC_SEEKBACK:
        SeekBack();
        break;

    case IDC_SEEKFORWARD:
        SeekForward();
        break;

    default:
        break;
    }
}
