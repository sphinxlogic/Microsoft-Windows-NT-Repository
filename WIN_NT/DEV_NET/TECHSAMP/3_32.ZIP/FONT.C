/*
 * FONT.C
 *
 * Code demonstrating the various uses of the ChooseFont common dialog.
 *
 *
 * Kraig Brockschmidt, Software Design Engineer
 * Microsoft Systems Developer Relations
 * One Microsoft Way
 * Redmond, WA  98052
 *
 * Internet  :  kraigb@microsoft.com
 * Compuserve:  70750,2344
 * Fax       :  (206)936-7329
 */

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <windows.h>
#include <commdlg.h>
#include <dlgs.h>
#include <memory.h>
#include "dialogs.h"


//Contains the last choice of the user in the Font dialog
HANDLE          hgFont=NULL;
COLORREF        crgFont=0L;


//Flags of selected font types.
DWORD           dwFlags=CF_SCREENFONTS;


/*
 * These are global so our hook can use it and so they don't go out of
 * scope when we're executing a modeless variation.
 */
CHOOSEFONT      cf;
LOGFONT         lf;





/*
 * FontDialogs
 *
 * Purpose:
 *  Invokes variations on the ChooseFont common dialog depending
 *  on the menu selection.  After closing, we create the selected
 *  font and save a handle to it for use in the Print dialogs.
 *
 * Parameters:
 *  hWndOwner       HWND to use as the owner of the dialog.
 *  iDialog         WORD indicating which dialog variation to invoke.
 *  dwFlags         DWORD flags to use to select which fonts are shown.
 *
 * Return Value:
 *  BOOL            TRUE if OK was used in the dialog, FALSE otherwise.
 */

BOOL PASCAL FontDialogs(HWND hWndOwner, WORD iDialog, DWORD dwFlags)
    {
    static BOOL     fModeless=FALSE;
    BOOL            fRet=FALSE;

    //Prevent reentrancy
    if (fModeless)
        {
        MessageBox(hWndOwner, "Font Dialog is already open", "ChooseFont", MB_OK);
        return FALSE;
        }


    /*
     * If the combination of flags (in dwFlags) is such that no fonts
     * would show, then ChooseFont will display a message reading
     * "No fonts installed.  Run Control Panel to install fonts."
     */


    /*
     * Standard initialization:  NULL all the fields in the CHOOSEFONT
     * structure, set lStructSize, set hwndOwner (optional, but typically
     * what you want), and set lpLogFont to point to a valid LOGFONT
     * structure lest ye GP Fault.
     */
    memset(&cf, 0, sizeof(CHOOSEFONT));
    cf.lStructSize=sizeof(CHOOSEFONT);
    cf.hwndOwner=hWndOwner;
    cf.lpLogFont=&lf;

    /*
     * For cases below where we use the CF_INITTOLOGFONT structure, we
     * need some information in the LOGFONT struct to use as initializers:
     *
     *  lfFaceName      Initial face name, ignored if CF_NOFACESEL is set.
     *
     *  lfHeight        Initial point size, ignored if CF_NOSIZESEL is set.
     *
     *  lfItalic        Initial font attributes, ignored if CF_NOSTYLESEL
     *  lfBold          is set.  You can also initialize the style with
     *                  the lpszStyle string in the CHOOSEFONT structure and
     *                  the CF_USESTYLE flag, but that option is not exercised
     *                  in this code.
     *
     *  lfStrikeout     Initial state of the Strikeout checkbox if CF_EFFECTS
     *                  is used.
     *
     *  lfUnderline     Initial state of the Underline checkbox if CF_EFFECTS
     *                  is used.
     *
     *
     * Our defaults will be 10pt Times New Roman bold underlined
     */
    lstrcpy(lf.lfFaceName, "Times New Roman");
    lf.lfHeight=10;
    lf.lfItalic=FALSE;
    lf.lfWeight=FW_BOLD;
    lf.lfStrikeOut=FALSE;
    lf.lfUnderline=TRUE;

    /*
     * Initial color default, shown as Fuschia in the color combobox when
     * CF_EFFECTS is set.
     */
    cf.rgbColors=RGB(255, 0, 255);



    /*
     * If dwFlags contains CF_PRINTERFONTS, we need an hDC to specify
     * the printer.  We get one by calling PrintDlg (COMMDLG.DLL) with
     * PD_RETURNDEFAULT to get a DC for the default printer.
     */
    if (CF_PRINTERFONTS & dwFlags)
        {
        PRINTDLG        pd;

        memset(&pd, 0, sizeof(PRINTDLG));
        pd.lStructSize=sizeof(PRINTDLG);
        pd.Flags =PD_RETURNDC | PD_RETURNDEFAULT;

        //If there's no default printer, PrintDlg will fail.
        if (!PrintDlg(&pd))
            {
            MessageBox(hWndOwner, "Cannot use printer fonts:  no default printer."
                       , "ChooseFont", MB_OK);
            return FALSE;
            }

        //Cleanup.  See code in PRINT.C for more information.
        if (NULL!=pd.hDevMode)
            GlobalFree(pd.hDevMode);

        if (NULL!=pd.hDevNames)
            GlobalFree(pd.hDevNames);

        cf.hDC=pd.hDC;
        }


    switch (iDialog)
        {
        case IDM_FONTBASIC:
            /*
             * For a functional dialog, we set the appropriate fields in
             * the LOGFONT structure as above and use CD_INITTOLOGFONTSTRUCT.
             * CF_FORCEFONTEXIST causes ChooseFont to fail if the font
             * is not actually available.
             */
            cf.Flags=dwFlags | CF_INITTOLOGFONTSTRUCT | CF_FORCEFONTEXIST;
            fRet=ChooseFont(&cf);
            break;


        case IDM_FONTEFFECTS:
            /*
             * For CF_EFFECTS, we make sure, as above, to initialize the
             * LOGFONT's lfStrikeOut and lfUnderline fields as well as specifying
             * an initial color in cf.rgbColors.
             */
            cf.Flags=dwFlags | CF_EFFECTS | CF_INITTOLOGFONTSTRUCT;
            fRet=ChooseFont(&cf);
            break;


        case IDM_FONTHOOKEDHIDECOLOR:
            /*
             * In the hook procedure we hide the color controls, so we make
             * sure to specify the best default color here.
             */
            cf.rgbColors=GetSysColor(COLOR_WINDOWTEXT);

            cf.Flags=dwFlags | CF_EFFECTS | CF_SHOWHELP
                             | CF_INITTOLOGFONTSTRUCT | CF_ENABLEHOOK;

            //DLGHOOKPROC is defined in dialogs.h
            cf.lpfnHook=(DLGHOOKPROC)MakeProcInstance(FontHook, hgInst);

            fRet=ChooseFont(&cf);

            FreeProcInstance((FARPROC)cf.lpfnHook);
            break;


        case IDM_FONTMODELESS:
            /*
             * We do everything as before setting up a hook, but we use
             * lCustData to pass the owning window handle and leave
             * hwndOwner NULL.  We pass the window handle so we can position
             * ourselves relative to the window at the same postion that the
             * dialog will, by default, be positioned relative to the screen.
             */
            cf.lCustData=hWndOwner;
            cf.hwndOwner=CreateWindow("ModelessPopup", "Parent"
                      , WS_POPUP
                      , 0, 0, 100, 100
                      , hWndOwner, NULL, hgInst, NULL);


            /*
             * The hook will process the Apply button and send a message
             * to the popup which will recreate and repaint the font
             * in the top-level window.  DLGHOOKPROC is defined in dialogs.h
             */
            cf.lpfnHook=(DLGHOOKPROC)MakeProcInstance(FontHook, hgInst);

            //CF_APPLY shows an Apply button that we process in the hook.
            cf.Flags=dwFlags | CF_EFFECTS | CF_INITTOLOGFONTSTRUCT
                             | CF_ENABLEHOOK | CF_APPLY;

            fModeless=TRUE;
            fRet=ChooseFont(&cf);
            fModeless=FALSE;

            FreeProcInstance((FARPROC)cf.lpfnHook);
            DestroyWindow(cf.hwndOwner);
            break;

        }

    //Must clean up after PrintDlg.
    if (NULL!=cf.hDC)
        DeleteDC(cf.hDC);

    //If we pressed OK, then create the font for later use.
    if (fRet)
        {
        if (NULL!=hgFont)
            DeleteObject(hgFont);

        hgFont=CreateFontIndirect(&lf);

        //Remember the color as well.
        crgFont=cf.rgbColors;
        }

    return fRet;
    }







/*
 * FontHook
 *
 * Purpose:
 *  Dialog procedure hook for the ChooseFont dialogs.  We use the
 *  hook to hide the color combobox and to process the Apply button.
 *
 * Parameters:
 *  Standard parameter list for a dialog box.
 *
 * Return Value:
 *  UINT            Non-Zero or Zero, indicating if the common dialog should
 *                  SKIP the message (non-zero) or not (zero).  Don't confuse
 *                  with typical dialog box return values.
 */

UINT FAR PASCAL FontHook(HWND hDlg, UINT iMsg, UINT wParam, LONG lParam)
    {
    static HWND         hWndTop;
    RECT                rc;
    POINT               pt;
    UINT                i;

    switch (iMsg)
        {
        case WM_INITDIALOG:
            if (0L==cf.lCustData)
                {
                //Hide the color controls in the IDM_FONTHOOKEDHIDECOLOR case.
                ShowWindow(GetDlgItem(hDlg, stc4), SW_HIDE);
                ShowWindow(GetDlgItem(hDlg, cmb4), SW_HIDE);
                hWndTop=NULL;
                }
            else
                {
                /*
                 * Reposition the window relative to the parent whose
                 * handle is in LOWORD(cf.lCustData)
                 */
                hWndTop=LOWORD(cf.lCustData);
                pt.x=0;
                pt.y=0;
                ClientToScreen(hWndTop, &pt);
                GetWindowRect(hDlg, &rc);

                SetWindowPos(hDlg, NULL, pt.x+rc.left, pt.y+rc.top
                             , 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);

                //Change OK to Close
                SetDlgItemText(hDlg, IDOK, "Close");
                }
            return TRUE;


        //This is only used in the modeless case as hWndTop is NULL otherwise.
        case WM_COMMAND:
            if (NULL==hWndTop)
                break;

            switch (LOWORD(wParam))
                {
                case psh3:  //Apply button
                    //Treat this like we pressed OK in a modal case.
                    if (NULL!=hgFont)
                        DeleteObject(hgFont);

                    /*
                     * Ask the dialog for the LOGFONT structure through
                     * the new WM_CHOOSEFONT_GETLOGFONT message documented
                     * in the Windows 3.1 SDK.
                     */
                    SendMessage(hDlg, WM_CHOOSEFONT_GETLOGFONT, 0, (LONG)(LPSTR)&lf);
                    hgFont=CreateFontIndirect(&lf);

                    /*
                     * Although currently undocumented, the OFFICIAL method to
                     * retrieve the current color in the color combobox is to
                     * use CB_GETITEMDATA which returns the RGB color for the
                     * specified item that we retrieve with CB_GETCURSEL.
                     */
                    i=(UINT)SendDlgItemMessage(hDlg, cmb4, CB_GETCURSEL, 0, 0L);

                    if (CB_ERR!=i)
                        crgFont=SendDlgItemMessage(hDlg, cmb4, CB_GETITEMDATA, i, 0L);

                    //Instruct the top-level window to repaint.
                    InvalidateRect(hWndTop, NULL, TRUE);
                    UpdateWindow(hWndTop);
                    return TRUE;
                }
            break;
        }

    return FALSE;
    }
