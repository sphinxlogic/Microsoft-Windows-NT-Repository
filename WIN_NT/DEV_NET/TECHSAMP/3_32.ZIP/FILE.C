/*
 * FILE.C
 *
 * Code demonstrating the various uses of the GetOpenFileName and
 * GetSaveFileName common dialogs.
 *
 *
 * Kraig Brockschmidt, Software Design Engineer
 * Microsoft Systems Developer Relations
 * One Microsoft Way
 * Redmond, WA  98052
 *
 * Internet  :  kraigb@microsoft.com
 * Compuserve:  70750,2344
 * Fax       :  (206)936-7329
 */

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <windows.h>
#include <commdlg.h>
#include <dlgs.h>
#include <memory.h>
#include "dialogs.h"




/*
 * ReplaceCharWithNull
 *
 * Purpose:
 *  Walks a null-terminated string and replaces a given character
 *  with a zero.  Used to turn a single string for file open/save
 *  filters into the appropriate filter string as required by the
 *  common dialog API.
 *
 * Parameters:
 *  psz             LPSTR to the string to process.
 *  ch              int character to replace.
 *
 * Return Value:
 *  int             Number of characters replaced.  -1 if psz is NULL.
 */

int FAR PASCAL ReplaceCharWithNull(LPSTR psz, int ch)
    {
    int             cChanged=-1;

    if (NULL!=psz)
        {
        while (0!=*psz)
            {
            if (ch==*psz)
                {
                *psz=0;
                cChanged++;
                }
            psz++;
            }
        }
    return cChanged;
    }





/*
 * FileDialogs
 *
 * Purpose:
 *  Invokes variations on the GetOpenFileName and GetSaveFileName
 *  common dialogs.
 *
 * Parameters:
 *  hWndOwner       HWND to use as the owner of the dialog.
 *  iDialog         WORD indicating which dialog variation to invoke.
 *
 * Return Value:
 *  BOOL            TRUE if the function was successful, FALSE otherwise.
 */

BOOL PASCAL FileDialogs(HWND hWndOwner, WORD iDialog)
    {
    OPENFILENAME        ofn;
    BOOL                fRet=FALSE;
    int                 cch;
    char                szDefExt[5];        //Default extension
    char                szFile[256];        //Filename buffer
    char                szFilters[256];     //Standard filters string
    char                szCFilter[256];     //Custom filter string


    /*
     * Standard initialization is clearing the filename buffer, loading
     * the default extension string, and loading the default filter string.
     * To simplify filter string initialization, we define a single string
     * in the stringtable with embedded '|' characters where there should
     * be zeros.  By placing the character to replace at the end of the
     * string, we can dynamically pass it (szFilters[cch-1] to
     * ReplaceCharWithNull that embeds the zeros for us.
     */
    szFile[0]=0;
    LoadString(hgInst, IDS_DEFEXT,  szDefExt, 5);

    LoadString(hgInst, IDS_FILTERS, szFilters, sizeof(szFilters));
    cch=lstrlen(szFilters);
    ReplaceCharWithNull(szFilters, szFilters[cch-1]);


    /*
     * Standard Initialization for all invocations.  This represents
     * the minimal initialization for a functional GetOpenFileName call,
     * with exception of the Flags that we set in the cases below.
     */
    memset(&ofn, 0, sizeof(OPENFILENAME));
    ofn.lStructSize =sizeof(OPENFILENAME);
    ofn.hwndOwner   =hWndOwner;
    ofn.lpstrFile   =szFile;          //Gotta have somewhere to put a filename
    ofn.nMaxFile    =sizeof(szFile);
    ofn.lpstrDefExt =szDefExt;
    ofn.lpstrFilter =szFilters;
    ofn.nFilterIndex=1;               //Selects the first filter in lpstrFilter


    switch (iDialog)
        {
        case IDM_FILEFUNCTIONALOPEN:
            //Hide the Read-Only checkbox and insist on returning a real file.
            ofn.Flags=OFN_FILEMUSTEXIST | OFN_SHOWHELP; //OFN_HIDEREADONLY |
            fRet=GetOpenFileName(&ofn);

            /*
             * At this point szFile will contain the selected filename
             * including the entire path.  nFilterIndex will contain the
             * last selected filter index.
             */
            break;


        case IDM_FILEFUNCTIONALSAVEAS:
            /*
             * Only difference between this and Open above is the API call.
             * We also add the OFN_CREATEPROMPT to this call to have the
             * dialog actually create a file if the given name does not exist.
             * OFN_CREATEPROMPT automatically enforces file existence.
             *
             * We also hook this invocation to show processing of the
             * registered messages.
             */
            ofn.lpfnHook=(DLGHOOKPROC)MakeProcInstance(FileHook, hgInst);
            ofn.Flags=OFN_HIDEREADONLY | OFN_CREATEPROMPT | OFN_ENABLEHOOK;

            fRet=GetSaveFileName(&ofn);

            FreeProcInstance((FARPROC)ofn.lpfnHook);
            break;


        case IDM_FILECUSTOMFILTER:
            ofn.Flags=OFN_HIDEREADONLY | OFN_FILEMUSTEXIST;

            //Load and initialize the single custom filter we'll use.
            LoadString(hgInst, IDS_CUSTOMFILTER, szCFilter, sizeof(szCFilter));
            cch=lstrlen(szCFilter);
            ReplaceCharWithNull(szCFilter, szCFilter[cch-1]);

            ofn.lpstrCustomFilter=szCFilter;
            ofn.nMaxCustFilter   =sizeof(szCFilter);

            //Must specify zero here to use and enable the custom filter
            ofn.nFilterIndex=0;

            fRet=GetOpenFileName(&ofn);
            break;


        case IDM_FILEEXTRAINITIALVALUES:
            /*
             * A few additional thing you can do:  show the read-only
             * checkbox by excluding OFN_HIDEREADONLY and check it with
             * OFN_READONLY.  Also specify an initial directory and a
             * replacement title bar.
             */
            ofn.Flags     =OFN_FILEMUSTEXIST | OFN_READONLY;
            ofn.lpstrTitle="File Open";

            //We're using szCFilter here as a scratch buffer
            GetWindowsDirectory(szCFilter, sizeof(szCFilter));
            ofn.lpstrInitialDir=szCFilter;

            fRet=GetOpenFileName(&ofn);
            break;
        }

    return fRet;
    }




/*
 * FileHook
 *
 * Purpose:
 *  Processes messages from the common File Open dialog to demonstrate
 *  processing of registered SHAREVISTRING and FILEOKSTRING messages.
 *
 * Parameters:
 *  hDlg            HWND of the dialog box.
 *  iMsg            UINT message number.
 *  wParam          UINT parameter.
 *  lParam          LONG parameter.
 *
 * Return Value:
 *  UINT            Non-Zero or Zero, indicating if the common dialog should
 *                  SKIP the message (non-zero) or not (zero).  Don't confuse
 *                  with typical dialog box return values.
 */

UINT FAR PASCAL FileHook(HWND hDlg, UINT iMsg, UINT wParam, LONG lParam)
    {
    LPOPENFILENAME  pOFN;
    char            szTemp[128];
    char            szTitle[15];

    if (iMSGShareViolation==iMsg)
        {
        /*
         * When the OK button is pressed, the file dialog may attempt
         * to create a file on a protected share, or may attempt to
         * open a locked file.  If the dialog did not have the
         * OFN_SHAREAWARE flag, then the SHAREVISTRING message is sent
         * to the hook.
         *
         * The return value is either OFN_SHAREFALLTHROUGH meaning that
         * the dialog ignores the sharing violation and returns the
         * filename to the caller anyway.  OFN_SHARENOWARN causes the
         * call to fail but nothing else happens.  OFN_SHAREWARN causes
         * the dialog to display a warning message, as if there were no
         * hook.
         */

        pOFN=(LPOPENFILENAME)lParam;

        //Get the filename without the path with this COMMDLG helper.
        GetFileTitle(pOFN->lpstrFile, szTitle, 15);
        wsprintf(szTemp, "Sharing Violation on %s.  Ignore?", (LPSTR)szTitle);
        wParam=MessageBox(hDlg, szTemp, "GetOpenFileName", MB_YESNO);

        if (IDYES==wParam)
            return OFN_SHAREFALLTHROUGH;    //Or OFN_SHARENOWARN.
        else
            return OFN_SHAREWARN;
        }

    if (iMSGFileOK==iMsg)
        {
        /*
         * User pressed the OK button and the dialog is ready to close.
         * lParam is a pointer to the OPENFILENAME structure, so here
         * we can validate the filename in lpstrFile or lpstrFileTitle
         * and prevent the dialog from closing by returning TRUE.
         *
         * We do it the cheap way and just ask the user to visually
         * validate.
         */

        pOFN=(LPOPENFILENAME)lParam;

        //Get the filename without the path with this COMMDLG helper.
        GetFileTitle(pOFN->lpstrFile, szTitle, 15);
        wsprintf(szTemp, "Is %s a valid filename?", (LPSTR)szTitle);

        wParam=MessageBox(hDlg, szTemp, "GetOpenFileName", MB_YESNO);

        //If the user said the filename is NOT valid, prevent dialog closure.
        if (IDNO==wParam)
            return TRUE;
        }

    return FALSE;
    }
