/*
 * DIALOGS.C
 *
 * Main entry code for application to use each one of the Common Dialogs
 * in the Windows 3.1 COMMDLG.DLL.  Code in this file simply calls code
 * in one of the other files that deals specifically with a single
 * common dialog.
 *
 *
 * Kraig Brockschmidt, Software Design Engineer
 * Microsoft Systems Developer Relations
 * One Microsoft Way
 * Redmond, WA  98052
 *
 * Internet  :  kraigb@microsoft.com
 * Compuserve:  70750,2344
 * Fax       :  (206)936-7329
 */
 
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
// 

//We need commdlg.h for registered message strings.
#include <windows.h>
#include <commdlg.h>
#include "dialogs.h"



HWND        hgWnd;          //Main window
HANDLE      hgInst;         //Application instance needed to load resources
HANDLE      hBrush=NULL;    //Main window class background brush


//Specific registered messages that the Common Dialogs might send
UINT        iMSGHelp;
UINT        iMSGFind;
UINT        iMSGShareViolation;
UINT        iMSGFileOK;
UINT        iMSGListboxChange;
UINT        iMSGColorOK;
UINT        iMSGSetRGB;





/*
 * WinMain
 *
 * Purpose:
 *  Main entry point of application.   Should register the app class
 *  if a previous instance has not done so and do any other one-time
 *  initializations.
 *
 * Parameters:
 *  Standard
 *
 * Return Value:
 *  Value to return to Windows--termination code.
 */

int PASCAL WinMain (HANDLE hInst, HANDLE hPrevInst, LPSTR pszCmd, int nCmdShow)
    {
    WNDCLASS        wc;
    HWND            hWnd;
    MSG             msg;

    hgInst=hInst;
    hBrush=CreateSolidBrush(GetSysColor(COLOR_APPWORKSPACE));

    if (!hPrevInst)
        {
        //Main window class
        wc.style          = CS_HREDRAW | CS_VREDRAW;
        wc.lpfnWndProc    = DialogsWndProc;
        wc.cbClsExtra     = 0;
        wc.cbWndExtra     = 0;
        wc.hInstance      = hInst;
        wc.hIcon          = LoadIcon(hInst, "Icon");
        wc.hCursor        = LoadCursor(NULL, IDC_ARROW);
        wc.hbrBackground  = hBrush;
        wc.lpszMenuName   = MAKEINTRESOURCE(IDR_MENU);
        wc.lpszClassName  = "Dialogs";

        if (!RegisterClass(&wc))
            return FALSE;

        //Hidden popup class for creating modeless dialogs.
        wc.lpfnWndProc    = PopupWndProc;
        wc.hIcon          = NULL;
        wc.hbrBackground  = COLOR_WINDOW+1;
        wc.lpszMenuName   = NULL;
        wc.lpszClassName  = "ModelessPopup";

        if (!RegisterClass(&wc))
            return FALSE;
        }


    /*
     * Register common dialog specific messages using strings defined in
     * COMMDLG.H.  Only the Help and Find messages are sent to our main
     * window procedure (the owner of the dialog box requesting help).
     * All others are sent to a dialog's hook procedure if one exists.
     */
    iMSGHelp          =RegisterWindowMessage(HELPMSGSTRING);  //All Dialogs
    iMSGFind          =RegisterWindowMessage(FINDMSGSTRING);  //Find & Replace
    iMSGShareViolation=RegisterWindowMessage(SHAREVISTRING);  //Open & Save
    iMSGFileOK        =RegisterWindowMessage(FILEOKSTRING);   //Open & Save
    iMSGListboxChange =RegisterWindowMessage(LBSELCHSTRING);  //Open & Save
    iMSGColorOK       =RegisterWindowMessage(COLOROKSTRING);  //Color
    iMSGSetRGB        =RegisterWindowMessage(SETRGBSTRING);   //Color


    hWnd=CreateWindow("Dialogs", "Common Dialogs"
                      , WS_MINIMIZEBOX | WS_OVERLAPPEDWINDOW
                      , 35, 35, 400, 250
                      , NULL, NULL, hInst, NULL);

    hgWnd=hWnd;
    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    while (GetMessage(&msg, NULL, 0,0 ))
        {
        /*
         * Find and replace are modeless dialogs requiring us to call
         * IsDialogMessage for each.  We use the dialog handles here to
         * determine if that dialog is active or not.  The handles are
         * set in functions in search.c.
         */
        if (NULL!=hDlgFind && IsDialogMessage(hDlgFind, &msg))
            continue;

        if (NULL!=hDlgReplace && IsDialogMessage(hDlgReplace, &msg))
            continue;

        TranslateMessage(&msg);
        DispatchMessage(&msg);
        }

    if (NULL!=hgFont)
        DeleteObject(hgFont);

    DeleteObject(hBrush);
    return msg.wParam;
    }






/*
 * DialogsWndProc
 *
 * Purpose:
 *  Window class procedure.  Standard callback.
 *
 * Parameters:
 *  Standard.
 *
 * Return Value:
 *  Standard.
 */

LONG FAR PASCAL DialogsWndProc(HWND hWnd, UINT iMsg, UINT wParam, LONG lParam)
    {
    COLORREF        cr;
    HBRUSH          hBrT;
    HFONT           hFontT;
    PAINTSTRUCT     ps;
    FARPROC         pfn;

    WORD            wID;

    /*
     * We receive this message whenever help is enabled in any dialog,
     * regardless of whether or not you have a hook installed.  Therefore
     * you have to be careful that this message processing and the hook
     * don't BOTH attempt to provide help, such as calling WinHelp.
     */
    if (iMSGHelp==iMsg)
        {
        MessageBeep(0);
        return 0L;
        }


    /*
     * If we get the Find/Replace message, pass it to a handler doing
     * the appropriate typecast of lParam to a pointer to a FINDREPLACE.
     */
    if (iMSGFind==iMsg)
        return LSearchMessageHandler(hWnd, (LPFINDREPLACE)lParam);


    switch (iMsg)
        {
        case WM_PAINT:
            /*
             * Draw some text using the last font & color selected in
             * a ChooseFont dialog.  The background is automatically
             * painted with the window class background brush that is
             * changed in the ColorDialogs case below.
             */
            BeginPaint(hWnd, &ps);
            SetTextColor(ps.hdc, crgFont);      //crgFont in COLOR.C
            SetBkMode(ps.hdc, TRANSPARENT);

            if (NULL!=hgFont)
                hFontT=SelectObject(ps.hdc, hgFont);

            TextOut(ps.hdc, 10, 10, "Change This Font...", 19);

            if (NULL!=hgFont)
                SelectObject(ps.hdc, hFontT);

            EndPaint(hWnd, &ps);
            break;


        case WM_DESTROY:
            PostQuitMessage(0);
            break;


        case USER_CHANGECOLOR:
            /*
             * We send this message to ourselves with an RGB value in
             * lParam to change the background window color.  We use
             * it both from the WM_COMMAND case for ChooseColor below
             * and from the ColorModelessHook in COLOR.C.
             *
             * Replace the current background brush with one of the
             * newly selected color.
             */
            hBrush=CreateSolidBrush((COLORREF)lParam);
            hBrT=SetClassWord(hWnd, GCW_HBRBACKGROUND, (WORD)hBrush);
            DeleteObject(hBrT);

            InvalidateRect(hWnd, NULL, TRUE);
            UpdateWindow(hWnd);
            break;



        case WM_COMMAND:
            /*
             * In Win32 wParam is packed with the ID and the notification
             * unlike Win16 where a notification is always in HIWORD(lParam).
             * LOWORD(wParam) gives us the command ID in either case.
             */
            wID=LOWORD(wParam);

            /*
             * Since we have ranges of commands to dispatch to the various
             * functions in other modules, checking ranges with if statements
             * is a little more convenient than a bunch of switch/case
             * statements.
             */
            if (wID >=IDM_COLORMIN && wID <=IDM_COLORMAX)
                {
                cr=ColorDialogs(hWnd, wID);

                if (0xFFFFFFFF!=cr)
                    SendMessage(hWnd, USER_CHANGECOLOR, 0, (LONG)cr);

                break;
                }


            if (wID >=IDM_FONTMIN && wID <=IDM_FONTMAX)
                {
                if (FontDialogs(hWnd, wID, dwFlags))
                    {
                    InvalidateRect(hWnd, NULL, TRUE);
                    UpdateWindow(hWnd);
                    }
                break;
                }


            if (wID >=IDM_FILEMIN && wID <=IDM_FILEMAX)
                {
                FileDialogs(hWnd, wID);
                break;
                }


            if (wID >=IDM_PRINTMIN && wID <=IDM_PRINTMAX)
                {
                PrintDialogs(hWnd, wID);
                break;
                }


            if (wID >=IDM_SEARCHMIN && wID <=IDM_SEARCHMAX)
                {
                SearchDialogs(hWnd, wID);
                break;
                }


            switch (wID)
                {
                case IDM_EXIT:
                    PostMessage(hWnd, WM_CLOSE, 0, 0L);
                    break;

                case IDM_FONTSELECTFLAGS:
                    /*
                     * Display a dialog in which the user specifies which
                     * flags to use in the next call to ChooseFont.  The
                     * dialog procedure SelectFontFlagsProc below maniuplates
                     * the global varaible dwFlags (defined in FONT.C).
                     */
                    pfn=MakeProcInstance(SelectFontFlagsProc, hgInst);
                    DialogBox(hgInst, MAKEINTRESOURCE(IDD_SELECTFONTFLAGS), hWnd, pfn);
                    FreeProcInstance(pfn);
                    break;

                case IDM_HELPABOUT:
                    pfn=MakeProcInstance(AboutProc, hgInst);
                    DialogBox(hgInst, MAKEINTRESOURCE(IDD_ABOUT), hWnd, pfn);
                    FreeProcInstance(pfn);
                    break;
                }

        default:
            return (DefWindowProc(hWnd, iMsg, wParam, lParam));
        }

    return 0L;
    }





/*
 * SelectFontFlagsProc
 *
 * Purpose:
 *  Handles the dialog to select various flags that affect which fonts
 *  are shown in the ChooseFont dialog.  The results of this dialog
 *  are combined into the dwFlags global variable.
 *
 * Parameters:
 *  Standard
 *
 * Return Value:
 *  Standard
 */

BOOL FAR PASCAL SelectFontFlagsProc(HWND hDlg, UINT iMsg, UINT wParam, LONG lParam)
    {
    UINT            i;

    //Mapping from control ID-3 to ChooseFont flag.
    static DWORD    mpIDFlag[7]={CF_ANSIONLY, CF_FIXEDPITCHONLY,
                                 CF_NOVECTORFONTS, CF_NOSIMULATIONS,
                                 CF_SCALABLEONLY, CF_TTONLY, CF_WYSIWYG};


    switch (iMsg)
        {
        case WM_INITDIALOG:
            //Set the appropriate Printer, Screen, or Both radiobutton
            if (CF_BOTH==(dwFlags & CF_BOTH))
                i=ID_BOTH;
            else
                i=(dwFlags & CF_PRINTERFONTS) ? ID_PRINTERFONTS : ID_SCREENFONTS;

            CheckRadioButton(hDlg, ID_PRINTERFONTS, ID_BOTH, i);

            //Loop through dwFlags and check boxes for whatever is set.
            for (i=0; i<7; i++)
                {
                if (dwFlags & mpIDFlag[i])
                    CheckDlgButton(hDlg, i+3, TRUE);
                }
            return TRUE;


        case WM_COMMAND:
            switch (LOWORD(wParam))
                {
                case IDOK:
                    dwFlags=0;

                    //Get the required flags.
                    if (IsDlgButtonChecked(hDlg, ID_BOTH))
                        dwFlags=CF_BOTH;
                    else
                        {
                        if (IsDlgButtonChecked(hDlg, ID_PRINTERFONTS))
                            dwFlags=CF_PRINTERFONTS;
                        else
                            dwFlags=CF_SCREENFONTS;
                        }


                    //Loop through the options and twiddle dwFlags as necessary.
                    for (i=0; i<7; i++)
                        {
                        if (IsDlgButtonChecked(hDlg, i+3))
                            dwFlags|=mpIDFlag[i];
                        }

                    EndDialog(hDlg, TRUE);
                    break;
                }
            break;

        default:
            break;
        }

    return FALSE;
    }






/*
 * PopupWndProc
 *
 * Purpose:
 *  Window class procedure for a popup window used as the owner of
 *  dialogs that we want to behave as modeless.  Does nothing since
 *  we never show it.
 *
 * Parameters:
 *  Standard.
 *
 * Return Value:
 *  Standard.
 */

LONG FAR PASCAL PopupWndProc(HWND hWnd, UINT iMsg, UINT wParam, LONG lParam)
    {
    return (DefWindowProc(hWnd, iMsg, wParam, lParam));
    }



/*
 * AboutProc
 *
 * Purpose:
 *  Dialog procedure for the ubiquitous About box.
 *
 * Parameters:
 *  The standard.
 *
 * Return Value:
 *  The value to be returned through the DialogBox call that
 *  created the dialog.
 *
 */

BOOL FAR PASCAL AboutProc(HWND hDlg, UINT iMsg, UINT wParam, LONG lParam)
    {
    switch (iMsg)
        {
        case WM_INITDIALOG:
            return TRUE;

        case WM_COMMAND:
            /*
             * Only the OK button can send WM_COMMAND, so we ignore what
             * the id in LOWORD(wParam) really is.
             */
            EndDialog(hDlg, TRUE);
            break;
        }

    return FALSE;
    }
