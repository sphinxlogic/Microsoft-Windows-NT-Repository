/*
 * PRINT.C
 *
 * Code demonstrating the various uses of the PrintDlg common dialog.
 *
 *
 * Kraig Brockschmidt, Software Design Engineer
 * Microsoft Systems Developer Relations
 * One Microsoft Way
 * Redmond, WA  98052
 *
 * Internet  :  kraigb@microsoft.com
 * Compuserve:  70750,2344
 * Fax       :  (206)936-7329
 */

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <windows.h>
#include <commdlg.h>
#include <dlgs.h>
#include <memory.h>
#include "dialogs.h"





/*
 * PrintDialogs
 *
 * Purpose:
 *  Invokes variations on the PrintDlg common dialog depending
 *  on the menu selection.  For print, we use the hDC we get back
 *  when the user chooses OK to print some text in the last font
 *  selected in the fonts dialog (as held in the hgFont global).
 *
 * Parameters:
 *  hWndOwner       HWND to use as the owner of the dialog.
 *  iDialog         WORD indicating which dialog variation to invoke.
 *
 * Return Value:
 *  BOOL            TRUE if OK was used in the dialog, FALSE otherwise.
 */

BOOL PASCAL PrintDialogs(HWND hWndOwner, WORD iDialog)
    {
    PRINTDLG        pd;
    BOOL            fRet=FALSE;
    HFONT           hFontT=NULL;


    /*
     * Standard initialization:  NULL all fields in the structure,
     * fill lStructSize, and set the owner window (the owner is
     * strictly unecessary, but give the dialog its modal behavior
     * like it should have).
     */
    memset(&pd, 0, sizeof(PRINTDLG));
    pd.lStructSize=sizeof(PRINTDLG);
    pd.hwndOwner=hWndOwner;

    switch (iDialog)
        {
        case IDM_PRINTPRINT:
            /*
             * These flags instruct the dialog to return a DC for the printer,
             * select the All Pages radiobutton, check the Collate Copies
             * checkbox, and disable the Print to File checkbox.
             */
            pd.Flags =PD_RETURNDC | PD_ALLPAGES | PD_COLLATE | PD_DISABLEPRINTTOFILE;

            pd.nCopies=1;       //Initial contents of the Copies edit control.
            pd.nFromPage=1;     //Initial contents of the From edit control.
            pd.nToPage=25;      //Initial contents of the To edit control.
            pd.nMinPage=1;      //Lowest possible number in the From/To edits.
            pd.nMaxPage=25;     //Highest possible number in the From/To edits.

            fRet=PrintDlg(&pd);

            if (fRet)
                {
                /*
                 * Print something useless...note that this code
                 * ignores trying to make the point size in the
                 * font match the point size on the printed page.
                 * This is simply to demonstrate that the hDC is
                 * immediately available for printing.
                 */
                if (NULL!=hgFont)
                    hFontT=SelectObject(pd.hDC, hgFont);

                Escape(pd.hDC, STARTDOC, 14, "PrintDlg Test", NULL);
                TextOut(pd.hDC, 50, 50, "My hovercraft is full of eels", 28);
                Escape(pd.hDC, NEWFRAME, 0, NULL, NULL);
                Escape(pd.hDC, ENDDOC, 0, NULL, NULL);

                //Cleanup
                if (NULL!=hFontT)
                    SelectObject(pd.hDC, hFontT);
                }
            break;


        case IDM_PRINTPRINTERSETUP:
            /*
             * Do Printer Setup only with PD_PRINTSETUP.  You can still
             * retrieve the DC/IC from this with PD_RETURNDC or PD_RETURNIC.
             */
            pd.Flags=PD_RETURNIC | PD_PRINTSETUP;
            fRet=PrintDlg(&pd);
            break;
        }


    /*
     * Cleanup:  Delete any DC or IC created by PrintDlg and free the
     * allocated handles hDevMode and hDevNames.  The caller is responsible
     * to perform this cleanup once it is finished using the DC or the data.
     */

    if (NULL!=pd.hDC)
        DeleteDC(pd.hDC);

    if (NULL!=pd.hDevMode)
        GlobalFree(pd.hDevMode);

    if (NULL!=pd.hDevNames)
        GlobalFree(pd.hDevNames);

    return fRet;
    }
