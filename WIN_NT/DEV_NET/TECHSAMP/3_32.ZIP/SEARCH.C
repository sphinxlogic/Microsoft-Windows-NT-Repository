/*
 * SEARCH.C
 *
 * Code demonstrating the various uses of the FindText and ReplaceText
 * common dialogs.
 *
 *
 * Kraig Brockschmidt, Software Design Engineer
 * Microsoft Systems Developer Relations
 * One Microsoft Way
 * Redmond, WA  98052
 *
 * Internet  :  kraigb@microsoft.com
 * Compuserve:  70750,2344
 * Fax       :  (206)936-7329
 */  

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
// 

#include <windows.h>
#include <commdlg.h>
#include <dlgs.h>
#include <memory.h>
#include "dialogs.h"


HWND            hDlgFind;               //FindText modeless dialog handle
FINDREPLACE     frFind;                 //Persistent structure for FindText
char            szFind[256];            //Search string for FindText

HWND            hDlgReplace;            //ReplaceText modeless dialog handle
FINDREPLACE     frReplace;              //Persistent structure for ReplaceText
char            szReplaceFind[256];     //Search string for ReplaceText
char            szReplace[256];         //Replace string for ReplaceText





/*
 * LSearchMessageHandler
 *
 * Purpose:
 *  Processes the FINDMSGSTRING registered message sent from the
 *  find and replace modeless dialogs.  Various bits in pFR->Flags
 *  instruct us what to do, that is, terminate the dialog, find
 *  the next occurance in the search, replace an occurance, or
 *  replace all occurances.  Simply put, these flags indicate which
 *  button the user pressed.
 *
 * Parameters:
 *  hWnd            HWND of the parent window.
 *  pFR             LPFINDREPLACE pointer to either the frFind or
 *                  frReplace globals we used to call FindText or
 *                  ReplaceText, depending on which dialog box
 *                  originated this message.
 *
 * Return Value:
 *  LONG            Value to return from the main window procedure.
 */

LONG PASCAL LSearchMessageHandler(HWND hWnd, LPFINDREPLACE pFR)
    {
    char            szFindMsg[512];

    if (FR_DIALOGTERM & pFR->Flags)
        {
        /*
         * The dialog is closing on the Close button.  Therefore we must
         * invalidate the handle we saved from FindText or ReplaceText.
         * Since we have two window handles for these dialogs we have to
         * determine which one to invalidate.  Since the FINDMSGSTRING
         * message does not distinguish the two dialogs, we have stored
         * a non-zero in the FINDREPLACE structure's lCustData for
         * FindText and a zero for ReplaceText.
         */
        if (pFR->lCustData)
            hDlgFind=NULL;
        else
            hDlgReplace=NULL;

        return 0L;
        }


    /*
     * Perform your searching here.  For this example we'll simply report
     * the state of the various flags.  This is really dull code, don't
     * you think?
     */
    lstrcpy(szFindMsg, "Dialog:\t");
    lstrcat(szFindMsg, (0==pFR->lCustData) ? "Replace\n" : "Find\n");

    lstrcat(szFindMsg, "Button:\t");
    if (FR_FINDNEXT   & pFR->Flags) lstrcat(szFindMsg, "Find Next\n");
    if (FR_REPLACE    & pFR->Flags) lstrcat(szFindMsg, "Replace\n");
    if (FR_REPLACEALL & pFR->Flags) lstrcat(szFindMsg, "Replace All\n");

    lstrcat(szFindMsg, "Up/Down:\t");
    lstrcat(szFindMsg, (FR_DOWN & pFR->Flags) ? "Down\n" : "Up\n");

    lstrcat(szFindMsg, "Whole Word:\t");
    lstrcat(szFindMsg, (FR_WHOLEWORD & pFR->Flags) ? "On\n" : "Off\n");

    lstrcat(szFindMsg, "Match Case:\t");
    lstrcat(szFindMsg, (FR_MATCHCASE & pFR->Flags) ? "On\n" : "Off\n");

    MessageBox(hWnd, szFindMsg, "Find/Replace Message", MB_OK);
    return 0L;
    }







/*
 * SearchDialogs
 *
 * Purpose:
 *  Invokes the FindText and ReplaceText common dialogs.
 *
 * Parameters:
 *  hWndOwner       HWND to use as the owner of the dialog.
 *  iDialog         WORD indicating which dialog variation to invoke.
 *
 * Return Value:
 *  HWND            Handle to the invoked dialog, NULL on failure.
 */

HWND PASCAL SearchDialogs(HWND hWndOwner, WORD iDialog)
    {
    HWND            hDlg=NULL;

    /*
     * NOTE:  Since we pass a pointer to the FINDREPLACE structure for
     * a modeless dialog, the structure must persist outside the scope of
     * this function, that is, it must be static or global.  We use a
     * different structure for FindText and ReplaceText since we allow
     * both dialogs to be active at one time.
     */

    switch (iDialog)
        {
        case IDM_SEARCHFIND:
            if (hDlgFind)
                break;

            memset(&frFind, 0, sizeof(FINDREPLACE));
            frFind.lStructSize=sizeof(FINDREPLACE);
            frFind.hwndOwner=hWndOwner;

            lstrcpy(szFind, "Search String");
            frFind.lpstrFindWhat=szFind;
            frFind.wFindWhatLen=sizeof(szFind);

            frFind.Flags=FR_DOWN | FR_MATCHCASE | FR_WHOLEWORD;

            /*
             * For our own purposes, use lCustData to distinguish
             * an invocation of Find vs. and invocation or Replace
             * within the message processing for FINDMSGSTRING.  Otherwise
             * there's no way to distinguish where that message originated.
             */
            frFind.lCustData=1L;

            hDlgFind=FindText(&frFind);
            hDlg=hDlgFind;
            /*
             * FindText returns as soon as the dialog is up. Therefore we
             * have to manage memory and so forth when we are told it's
             * closing.  Memory for the FINDREPLACE structure and the
             * lpstrFindWhat string both must be global or static.
             */
            break;


        case IDM_SEARCHREPLACE:
            if (hDlgReplace)
                break;

            memset(&frReplace, 0, sizeof(FINDREPLACE));
            frReplace.lStructSize=sizeof(FINDREPLACE);
            frReplace.hwndOwner=hWndOwner;

            lstrcpy(szReplaceFind, "Search String");
            frReplace.lpstrFindWhat=szReplaceFind;
            frReplace.wFindWhatLen=sizeof(szReplaceFind);

            lstrcpy(szReplace, "Replace String");
            frReplace.lpstrReplaceWith=szReplace;
            frReplace.wReplaceWithLen=sizeof(szReplace);

            frReplace.Flags=FR_WHOLEWORD;
            frReplace.lCustData=0L;

            hDlgReplace=ReplaceText(&frReplace);
            hDlg=hDlgReplace;
            break;
        }

    return hDlg;
    }
