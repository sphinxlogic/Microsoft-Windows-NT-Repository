/***    DRVINFO.C - IsDoubleSpaceDrive function
 *
 *      Version 1.00.03 - 5 January 1993
 */

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include "drvinfo.h"


/***    IsDoubleSpaceDrive - Get information on a DoubleSpace drive
 *
 *      Entry:
 *          drive     - Drive to test (0=A, 1=B, etc.)
 *                      NOTE: No parameter checking is done on drive.
 *          pdrHost   - Receives drive number of host drive
 *          pfSwapped - Receives TRUE/FALSE indicating if drive is swapped.
 *          pseq      - Receives CVFs sequence number if DoubleSpace drive
 *
 *      Exit:
 *          returns TRUE, if DoubleSpace drive:
 *              *pdrHost   = current drive number of host drive (0=A,...)
 *              *pfSwapped = TRUE, if drive is swapped with host,
 *                           FALSE, if drive is not swapped with host
 *              *pseq      = CVF sequence number (always zero if swapped
 *                             with host drive)
 *
 *                           NOTE: The full file name of the CVF is:
 *                                   *pdrHost:\DBLSPACE.*pseq
 *
 *                               pdrHost  pseq  Full Path
 *                               -------  ----  -----------
 *                                  0       1   a:\dblspace.001
 *                                  3       0   d:\dblspace.000
 *
 *          returns FALSE, if *not* DoubleSpace drive:
 *              *pdrHost   = drive number of host drive at boot time
 *              *pfSwapped = TRUE, if swapped with a DoubleSpace drive
 *                           FALSE, if not swapped with a DoubleSpace drive
 */
BOOL IsDoubleSpaceDrive(BYTE drive, BOOL *pfSwapped, BYTE *pdrHost, int *pseq)
{
    BYTE        seq;
    BYTE        drHost;
    BOOL        fSwapped;
    BOOL        fDoubleSpace;

    // Assume drive is a normal, non-host drive
    drHost = drive;
    fSwapped = FALSE;
    fDoubleSpace = FALSE;
    seq = 0;

    _asm
    {
        mov     ax,4A11h        ; DBLSPACE.BIN INT 2F number
        mov     bx,1            ; bx = GetDriveMap function
        mov     dl,drive        ;
        int     2Fh             ; (bl AND 80h) == DS drive flag
                                ; (bl AND 7Fh) == host drive

        or      ax,ax           ; Success?
        jnz     gdiExit         ;    NO, DoubleSpace not installed

        test    bl,80h          ; Is the drive compressed?
        jz      gdiHost         ;    NO, could be host drive

        ; We have a DoubleSpace Drive, need to figure out host drive.
        ;
        ; This is tricky because of the manner in which DBLSPACE.BIN
        ; keeps track of drives.
        ;
        ; For a swapped CVF, the current drive number of the host
        ; drive is returned by the first GetDriveMap call.  But for
        ; an unswapped CVF, we must make a second GetDriveMap call
        ; on the "host" drive returned by the first call.  But, to
        ; distinguish between swapped and unswapped CVFs, we must
        ; make both of these calls.  So, we make them, and then check
        ; the results.

        mov     fDoubleSpace,TRUE ; Drive is DS drive
        mov     seq,bh          ; Save sequence number

        and     bl,7Fh          ; bl = "host" drive number
        mov     drHost,bl       ; Save 1st host drive
        mov     dl,bl           ; Set up for query of "host" drive

        mov     ax,4A11h        ; DBLSPACE.BIN INT 2F number
        mov     bx,1            ; bx = GetDriveMap function
        int     2Fh             ; (bl AND 7Fh) == 2nd host drive

        and     bl,7Fh          ; bl = 2nd host drive
        cmp     bl,drive        ; Is host of host of drive itself?
        mov     fSwapped,TRUE   ; Assume CVF is swapped
        je      gdiExit         ;   YES, CVF is swapped

        mov     fSwapped,FALSE  ;   NO, CVF is not swapped
        mov     drHost,bl       ; True host is 2nd host drive
        jmp     short gdiExit

    gdiHost:
        and     bl,7Fh          ; bl = host drive number
        cmp     bl,dl           ; Is drive swapped?
        je      gdiExit         ;    NO

        mov     fSwapped,TRUE   ;    YES
        mov     drHost,bl       ; Set boot drive number

    gdiExit:
    }

    *pdrHost   = drHost;
    *pfSwapped = fSwapped;
    *pseq      = seq;
    return fDoubleSpace;
}
