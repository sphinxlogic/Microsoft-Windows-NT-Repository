/***    TEST.C - Test IsDoubleSpaceDrive function.
 *
 *      Version 1.00.02 - 5 January 1993
 */
 
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//
 
#include "drvinfo.h"
#include <stdio.h>

void cdecl main ()
{
    BYTE    dr;
    int     fSwapped;
    BYTE    drHost;
    int     seq;

    for (dr=0; dr<26; dr++) {
        printf("%c: ",dr+'A');

        if (IsDoubleSpaceDrive(dr,&fSwapped,&drHost,&seq)) {
            printf("Compressed");
            if (fSwapped)
                printf(" and Swapped from");
            else
                printf(" and Mounted from");
            printf(" %c:\\DBLSPACE.%03d\n",drHost+'A',seq);
        }
        else if (fSwapped)
            printf("Swapped with %c:\n",drHost+'A');
        else
            printf("Normal\n");
    }
}
