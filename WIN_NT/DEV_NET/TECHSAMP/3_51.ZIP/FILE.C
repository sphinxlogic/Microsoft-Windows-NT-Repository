/*
    file.c

    File open/close functions

    An open file is read into a memory block pointed to by pFileData
    and of length dwFileLength;



*/

#include "global.h"

//
// local defines
//

// <dwFlags> for PromptForFileName()
#define PFFN_OPENFILE        0x0001    // prompt to open a file
#define PFFN_SAVEFILE        0x0002    // prompt to save a file
#define PFFN_SHOWDEFAULT     0x0004    // init. show what's in <achFileName>
#define PFFN_OVERWRITEPROMPT 0x0008    // prompt the user about overwriting
#define PFFN_UPPERCASE       0x0010    // make the name uppercase

//
// local data
//

static char *szUntitled = "(Untitled)";
static char *szOpenFilter = "Text Files (*.txt)\0*.txt\0"
                            "All Files (*.*)\0*.*\0"
                            "\0";

//
// local functions
//

BOOL PromptForFileName(HWND hwndOwner,   // window that will own dialog box
                       HANDLE hInst,     // module that contains the resources
                       LPSTR achFileName,// where to put file name
                       WORD cchFileName, // size of <achFileName>
                       LPSTR szCaption,  // caption string
                       LPSTR szFilter,   // file filter
                       LPSTR szDefExt,   // default extension
                       DWORD dwFlags);   // random flags


//
// If the file is dirty (modified), ask the user "Save before closing?".
// Return TRUE if it's okay to continue, FALSE if the caller should cancel
// whatever it's doing.
// 

BOOL PromptToSave()
{
    WORD        wID;
    char buf[256];

    if (!gfDirty) return TRUE;

    wsprintf(buf, "Save the changes to %s ?", (LPSTR)gachFileName);
    wID = MessageBox(hwndMain,
                     buf,
                     szAppName,
                     MB_ICONQUESTION | MB_YESNOCANCEL);
    if (wID == IDCANCEL) return FALSE;
    if (wID == IDYES) {
        if (!FileSave(FALSE)) return FALSE;
    }
    return TRUE;
}

//
// Set the caption of the app window.
//

void UpdateCaption(void)
{
    char achCaption[_MAX_PATH + 30]; // caption
    char achDrive[_MAX_DRIVE];    // drive
    char achDir[_MAX_DIR];    // directory path
    char achFname[_MAX_PATH];    // file name
    char achExt[_MAX_EXT];    // file name extension

    /* put file name (or "(Untitled)") in <achFname> */
    if (gfUntitled)
        lstrcpy(achFname, gachFileName);
    else
    {
        _splitpath(gachFileName, achDrive, achDir, achFname, achExt);
        lstrcat(achFname, achExt);
    }

    /* set the caption */
    wsprintf(achCaption, "%s - %s", (LPSTR) szAppName, (LPSTR) achFname);
    SetWindowText(hwndMain, achCaption);
}


/* fOK = FileNew(fPrompt, fUpdateDisplay)
 *
 * Make a blank document, after asking the user to save modifications
 * (if any).  If <fPrompt> is TRUE, then prompt to save changes before
 * destroying file.  If <fUpdateDisplay> is TRUE, then update the display
 * after creating a new file.
 */

// Flags:
//      FILE_PROMPT_FOR_SAVE
//      FILE_UPDATE_CAPTION
//

BOOL FileNew(WORD wFlags)
{
    dprintf2("FileNew");
    if (wFlags & FILE_PROMPT_FOR_SAVE)
    {
        if (!PromptToSave()) return FALSE;
    }

    //
    // Reset the display and whatever uses the file data
    //

    if (pFileData) {
        GlobalUnlock((HANDLE)HIWORD(pFileData));
        GlobalFree((HANDLE)HIWORD(pFileData));
        pFileData = NULL;
        dwFileLength = 0;
    }

    //
    // update state variables 
    //

    gfDirty = FALSE;        // untitled document is not dirty yet
    gfUntitled = TRUE;      // file has no name
    gachFileName[0] = 0;    // in case of error
    lstrcpy(gachFileName, szUntitled);

    //
    // update the display 
    //

    if (wFlags & FILE_UPDATE_CAPTION) {
        UpdateCaption();
    }
    return TRUE;
}


/* fOK = FileOpen(szFileName)
 *
 * If <szFileName> is NULL, do a File/Open command.  Otherwise, open
 * <szFileName>.  Return TRUE unless the user cancelled or the operation
 * failed.
 */

BOOL FileOpen(LPSTR szFileName)
{
    BOOL        fOK = TRUE;    // function succeeded?
    char        achFileName[_MAX_PATH]; // user-specified file name
    int        fh = -1;    // DOS file handle
    HCURSOR        hcurPrev = NULL; // cursor before hourglass
    long        lFileLength;    // length of the file
    GLOBALHANDLE hFileImage;
    LPSTR        pFileImage;    // memory block to hold file image

    dprintf2("FileOpen");

    /* give user a chance to save this file (if it was modified) */
    if (!PromptToSave())
        goto RETURN_ERROR;

    /* put file name into <achFileName> (get from user or <szFileName>) */
    if (szFileName == NULL)
    {
        /* prompt the user for the name of the file to open */
        if (!PromptForFileName(hwndMain, 
                               hAppInstance, 
                               achFileName,
                               sizeof(achFileName), 
                               "Open File", 
                               szOpenFilter,
                               "txt",
                               PFFN_OPENFILE | PFFN_UPPERCASE))
            goto RETURN_ERROR;
    }
    else
        lstrcpy(achFileName, szFileName);

    /* empty the file */
    if (!FileNew(0))
        goto RETURN_ERROR;

    /* switch to new file */
    lstrcpy(gachFileName, achFileName);
    gfUntitled = FALSE;

    /* show hourglass cursor */
    hcurPrev = SetCursor(LoadCursor(NULL, IDC_WAIT));

    /* open the file */
    dprintf3("Opening %s", (LPSTR)gachFileName);
    if ((fh = _lopen(gachFileName, READ)) < 0)
        goto ERROR_OPENING;

    /* read the file; for now, don't worry about files that are too big */

    /* determine the length of the file */
    if ((lFileLength = _llseek(fh, 0L, SEEK_END)) == -1)
        goto ERROR_OPENING;

    /* allocate memory to hold the file plus a terminating NULL */
    if ((hFileImage = GlobalAlloc(GMEM_MOVEABLE, lFileLength + 1)) == NULL)
        goto ERROR_OPENING;
    pFileImage = GlobalLock(hFileImage);

    /* read the file (at most 64K bytes) */
    if (_llseek(fh, 0L, SEEK_SET) == -1)
        goto ERROR_OPENING;
    if ((long) _lread(fh, pFileImage, (int) lFileLength) != lFileLength)
        goto ERROR_OPENING;
    pFileImage[lFileLength] = 0;    // null-terminate the file

    //
    // set the contents of whatever uses the data
    //

    pFileData = pFileImage;
    dwFileLength = lFileLength;
    dprintf3("%lu bytes", dwFileLength);


    gfDirty = FALSE;

    goto RETURN_SUCCESS;

ERROR_OPENING:                // display generic error message

    Message(0, "Error opening %s", (LPSTR) gachFileName);
    FileNew(FILE_DONT_PROMPT_FOR_SAVE | FILE_DONT_UPDATE_CAPTION);
    goto RETURN_ERROR;

RETURN_ERROR:                // do error exit without error message

    fOK = FALSE;

RETURN_SUCCESS:                // normal exit

    if (hcurPrev != NULL)
        SetCursor(hcurPrev);

    if (fh >= 0)
        _lclose(fh);

    UpdateCaption();

    return fOK;
}


/* fOK = FileSave(fSaveAs)
 *
 * Do a File/Save operation (if <fSaveAs> is FALSE) or a File/SaveAs
 * operation (if <fSaveAs> is TRUE).  Return TRUE unless the user cancelled
 * or the operation failed.
 */
BOOL FileSave(WORD wFlags)
{
    BOOL        fOK = TRUE;    // function succeeded?
    int        fh = -1;    // DOS file handle
    char        achFileName[_MAX_PATH]; // user-specified file name
    HCURSOR        hcurPrev = NULL; // cursor before hourglass
    long        lFileLength;    // length of the file
    LPSTR        pFileImage;    // memory block to hold file image

    dprintf2("FileSave");

    if (!pFileData || !dwFileLength) {
        Message(0, "There is nothing to save");
        return FALSE;
    }

    if ((wFlags & FILE_SAVE_AS) || gfUntitled)
    {
        /* set up the default file name */
        if (gfUntitled)
            achFileName[0] = 0;
        else
            lstrcpy(achFileName, gachFileName);

        /* prompt the user for the name of the file to save to */
        if (!PromptForFileName(hwndMain, 
                               hAppInstance,
                               achFileName,
                               sizeof(achFileName), 
                               "Save File",
                               szOpenFilter,
                               "txt",
                               PFFN_SAVEFILE | PFFN_SHOWDEFAULT |
                                PFFN_OVERWRITEPROMPT | PFFN_UPPERCASE))
            goto RETURN_ERROR;

        /* switch to the new file name */
        lstrcpy(gachFileName, achFileName);
        gfUntitled = FALSE;
        UpdateCaption();
    }

    /* show hourglass cursor */
    hcurPrev = SetCursor(LoadCursor(NULL, IDC_WAIT));

    /* open the file -- if it already exists, truncate it to zero bytes */
    if ((fh = _lcreat(gachFileName, 0)) < 0)
        goto ERROR_SAVING;

    /* write the file... */

    //
    // determine the length of the file 
    //

    lFileLength = dwFileLength;

    //
    // get the contents of the file to save
    //

    pFileImage = pFileData;


    /* write the file (at most 64K bytes) */
    dprintf3("writing %lu bytes", lFileLength);
    if ((long) _lwrite(fh, pFileImage, (int) lFileLength) != lFileLength)
        goto ERROR_SAVING;

    goto RETURN_SUCCESS;

ERROR_SAVING:                // display generic error message

    Message(0, "Error saving %s", (LPSTR) gachFileName);
    goto RETURN_ERROR;

RETURN_ERROR:                // do error exit without error message

    fOK = FALSE;

RETURN_SUCCESS:                // normal exit

    if (hcurPrev != NULL)
        SetCursor(hcurPrev);

    if (fh >= 0)
        _lclose(fh);
    if (fOK)
        gfDirty = FALSE;

    return fOK;
}


/* fOK = PromptForFileName(hwndOwner, hInst, achFileName, cchFileName,
 *                         idCaption, idFilter, idDefExt, dwFlags)
 *
 * Prompt the user for the name of a file to open or save to.  <hwndOwner>
 * is the window that will own the dialog.  <hInst> is the module that the
 * string resources and RCDATA resource (see below) will be loaded from.
 *
 * The returned file name will be placed in <achFileName>, which must
 * have a capacity of at least <cchFileName> bytes.
 *
 * <idCaption> is the string resource id of the caption to display.
 * <idFilter> is the RCDATA resource id that contains the filter spec
 * (in the format used by COMMDLG).  <idDefExt> is the string resource id
 * of the default extension (without the period).  Any or all of these
 * three parameters may be NULL, for default behaviour.
 *
 * <dwFlags> are used as follows:
 *   -- PFFN_OPENFILE: prompt the user for the name of a file to open
 *   -- PFFN_SAVEFILE: prompt the user for the name of a file to save to
 *   -- PFFN_SHOWDEFAULT: on entry, <achFileName> will contain the name
 *      of a file to display as the "default file name"
 *   -- PFFN_OVERWRITEPROMPT: prompt the user before accepting allowing them
 *      to choose an existing file
 *   -- PFFN_UPPERCASE: make <achFileName> uppercase before returning
 */
BOOL
PromptForFileName(hwndOwner, hInst, achFileName, cchFileName,
    szCaption, szFilter, szDefExt, dwFlags)
HWND        hwndOwner;        // window that will own dialog box
HANDLE        hInst;            // module that contains the resources
LPSTR        achFileName;        // where to put file name
WORD        cchFileName;        // size of <achFileName>
LPSTR       szCaption;        // caption string
LPSTR       szFilter;        // file filter
LPSTR       szDefExt;        // default extension
DWORD        dwFlags;        // random flags
{
    OPENFILENAME    ofname;        // parameter block
    BOOL        f;

    /* the initial file name is "" unless PFFN_SHOWDEFAULT is given */
    if (!(dwFlags & PFFN_SHOWDEFAULT))
        achFileName[0] = 0;

    /* fill in the other fields of <ofname> */
    ofname.lpstrFilter = szFilter;
    ofname.lpstrTitle = szCaption;
    ofname.lpstrDefExt = szDefExt;
    ofname.lStructSize = sizeof(ofname);
    ofname.hwndOwner = hwndOwner;
    ofname.hInstance = hInst;
    ofname.lpstrCustomFilter = NULL;
    ofname.nMaxCustFilter = 0;
    ofname.nFilterIndex = 1;
    ofname.lpstrFile = achFileName;
    ofname.nMaxFile = cchFileName;
    ofname.lpstrFileTitle = NULL;
    ofname.nMaxFileTitle = 0;
    ofname.lpstrInitialDir = NULL;
    ofname.Flags = OFN_HIDEREADONLY |
        (dwFlags & PFFN_OVERWRITEPROMPT ? OFN_OVERWRITEPROMPT : 0);
    ofname.lCustData = NULL;
    ofname.lpfnHook = NULL;
    ofname.lpTemplateName = NULL;

    /* prompt the user for the file name */
    if (dwFlags & PFFN_OPENFILE)
        f = GetOpenFileName(&ofname);
    else
        f = GetSaveFileName(&ofname);

    /* make the name uppercase if requested */
    if (f && (dwFlags & PFFN_UPPERCASE))
        AnsiUpper(achFileName);

    return f;
}
