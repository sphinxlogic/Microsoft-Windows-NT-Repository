/*
    main.c

    A sample Windows application

    Another fine Herman Rodent production

*/

#include "global.h"


//
// local functions
//

static void Create(HWND hWnd, LPCREATESTRUCT lpCI);
static void Size(HWND hWnd, UINT uiX, UINT uiY);
static void Command(HWND hWnd, WPARAM wParam, LPARAM lParam);
static void MeasureItem(HWND hWnd, UINT uiCtl, LPMEASUREITEMSTRUCT lpMI);
static void DrawItem(HWND hWnd, UINT uiCtl, LPDRAWITEMSTRUCT lpDI);
static void InitMenuPopup(HMENU hMenu, UINT uiIndex, BOOL bSystem);
static void Paint(HWND hWnd, LPPAINTSTRUCT lpPS);
static void DropFiles(HWND hWnd, HDROP hDrop);

//
// Entry point
//

int PASCAL WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpszCmdLine,
                   int cmdShow)
{
    MSG msg;

    hAppInstance = hInstance;
    szAppName = "W16APP";

#ifdef DEBUG

    //
    // Get the debug level
    //

    __iDebugLevel = GetProfileInt(szAppName, "debug", 1);

#endif // DEBUG

    //
    // We allow multiple instances
    //

    if (!hPrevInstance) {
        if (!InitFirstInstance(hInstance)) {
            return 1;
        }
    }

    //
    // Do the per instance initialization
    //

    if (!InitCurrentInstance(hInstance, lpszCmdLine, cmdShow)) {
        return 1;
    }

    //
    // Check for messages from Windows and process them.
    // If we have nothing else to do, maybe perform some idle function
    // 

    do {
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {

            //
            // got a message to process
            //

            if (msg.message == WM_QUIT) break;

            //
            // Do the accelerator thing
            //

            if (!TranslateAccelerator(hwndMain, hAccTable, &msg)) {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
            }

        } else {

            //
            // perform some idle routine or just give up so Windows
            // can run till our next message.
            //

            WaitMessage();
        }
    } while (1);

    return (msg.wParam);
}
    
//
// main window message handler
//

LRESULT CALLBACK MainWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    PAINTSTRUCT ps;

    switch(msg) {
    case WM_CREATE:
        Create(hWnd, (LPCREATESTRUCT)lParam);
        break;

    case WM_SIZE:
        Size(hWnd, LOWORD(lParam), HIWORD(lParam));
        break;

    case WM_COMMAND:
        Command(hWnd, wParam, lParam); 
        break;

    case WM_MEASUREITEM:
        MeasureItem(hWnd, (UINT)wParam, (LPMEASUREITEMSTRUCT)lParam);
        return (LRESULT) TRUE;

    case WM_DRAWITEM:
        DrawItem(hWnd, (UINT)wParam, (LPDRAWITEMSTRUCT) lParam);
        break;

    case WM_PAINT:
        BeginPaint(hWnd, &ps);
        Paint(hWnd, &ps);
        EndPaint(hWnd, &ps);
        break;

    case WM_INITMENUPOPUP:
        InitMenuPopup((HMENU)wParam, LOWORD(lParam), (BOOL)HIWORD(lParam));
        break;

    case WM_DROPFILES:
        DropFiles(hWnd, (HDROP)wParam);
        break;

    case WM_DESTROY:
        Terminate();
        PostQuitMessage(0);
        break;

    default:
        return DefWindowProc(hWnd, msg, wParam, lParam);
        break;
    }
    return NULL;
}

//
// Process WM_CREATE message
//

static void Create(HWND hWnd, LPCREATESTRUCT lpCI)
{

}

//
// Process WM_SIZE message
//

static void Size(HWND hWnd, UINT uiX, UINT uiY)
{

}

//
// Process WM_COMMAND messages
//

static void Command(HWND hWnd, WPARAM wParam, LPARAM lParam) 
{
    PRINTDLG pd;

    switch (wParam) {
    case IDM_NEW:
        FileNew(FILE_PROMPT_FOR_SAVE | FILE_UPDATE_CAPTION);
        break;

    case IDM_OPEN:
        FileOpen(NULL);
        break;

    case IDM_SAVE:
        FileSave(FILE_SAVE);
        break;

    case IDM_SAVEAS:
        FileSave(FILE_SAVE_AS);
        break;

    case IDM_PRINT:
        memset(&pd, 0, sizeof(pd));
        pd.lStructSize = sizeof(pd);
        pd.hwndOwner = hWnd;
        pd.Flags = PD_RETURNDC;
        if (PrintDlg(&pd)) {
            Print(pd.hDC);
        }
        DeleteDC(pd.hDC);
        if (pd.hDevMode) GlobalFree(pd.hDevMode);
        if (pd.hDevNames) GlobalFree(pd.hDevNames);
        break;

    case IDM_PRINTSETUP:
        memset(&pd, 0, sizeof(pd));
        pd.lStructSize = sizeof(pd);
        pd.hwndOwner = hWnd;
        pd.Flags = PD_PRINTSETUP;
        PrintDlg(&pd);
        break;

    case IDM_EXIT:
        PostMessage(hWnd, WM_CLOSE, 0, 0l);
        break;

    case IDM_CUT:
    case IDM_COPY:
    case IDM_PASTE:
        ClipCommand(hWnd, wParam);
        break;

    case IDM_HELPCONTENTS:
        Help(hWnd, wParam);
        break;

    case IDM_ABOUT:
        About(hWnd);
        break;

#ifdef DEBUG
    case IDM_DEBUG0:
    case IDM_DEBUG1:
    case IDM_DEBUG2:
    case IDM_DEBUG3:
    case IDM_DEBUG4:
        SetDebugLevel(wParam - IDM_DEBUG0);
        break;

    case IDM_DEBUG_DIRTY:
        gfDirty = TRUE;
        break;
#endif

    default:
        break;
    }
}

//
// Process WM_DRAWITEM and WM_MEASUREITEM messages
//

static void MeasureItem(HWND hWnd, UINT uiCtl, LPMEASUREITEMSTRUCT lpMI)
{
    switch (uiCtl) {

    default:

        //
        // Return the height of the system font
        //

        lpMI->itemHeight = tmSysFont.tmHeight;
        break;
    }
}

static void DrawItem(HWND hWnd, UINT uiCtl, LPDRAWITEMSTRUCT lpDI)
{
    switch (uiCtl) {

    default:
        break;
    }
}

//
// Process WM_PAINT messages
//

static void Paint(HWND hWnd, LPPAINTSTRUCT lpPS)
{


}

//
// Process WM_INITMENUPOPUP messages
//

static void InitMenuPopup(HMENU hmenuPopup, UINT uiIndex, BOOL bSystem)
{
    //
    // See if there is anything in the clipboard which
    // we should enable the Paste item for
    //

    InitClipMenu(hmenuPopup);

#ifdef DEBUG
    //
    // Set the state of the dirty flag menu item
    //

    EnableMenuItem(hmenuPopup,
                   IDM_DEBUG_DIRTY,
                   gfDirty ? MF_GRAYED | MF_DISABLED : MF_ENABLED);
#endif // DEBUG
}

//
// Process WM_DROPFILES messages
//

static void DropFiles(HWND hWnd, HDROP hDrop)
{
    UINT ui;
    char szName[_MAX_PATH];

    dprintf2("DropFiles");

    ui = DragQueryFile(hDrop, 0xFFFF, NULL, 0);
    if (ui == 0) {
        DragFinish(hDrop);
        return;
    }
    if (ui > 1) {
        Message(0, "Only the first file will be opened");
    }

    ui = DragQueryFile(hDrop, 0, szName, sizeof(szName));
    if (ui) {
        dprintf3("File: %s", (LPSTR)szName);
        FileOpen(szName);
    }
    DragFinish(hDrop);
}

//
// Show a message box
//

UINT cdecl Message(UINT uiBtns, LPSTR lpFormat, ...) 
{
    char buf[256];

    wvsprintf(buf, lpFormat, (LPSTR)(&lpFormat+1));
    MessageBeep(uiBtns ? uiBtns : MB_ICONEXCLAMATION);
    return (UINT) MessageBox(hwndMain, 
                             buf, 
                             szAppName, 
                             uiBtns ? uiBtns : MB_OK|MB_ICONEXCLAMATION);
}

