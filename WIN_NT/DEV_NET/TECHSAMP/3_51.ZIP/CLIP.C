/*
    clip.c

    Clipboard support

    This does copy and paste operations on the block of data
    addressed by pFileData and dwFileLength.

*/

#include "global.h"

//
// Set the state of the edit menu items
//

void InitClipMenu(HMENU hmenuPopup)
{
    //
    // See if there is anything we have that we might want the
    // user to be able to copy to the clipboard
    //

    if (pFileData && dwFileLength) {
        EnableMenuItem(hmenuPopup, IDM_COPY, MF_ENABLED);
    } else {
        EnableMenuItem(hmenuPopup, IDM_COPY, MF_GRAYED);
    }

    //
    // See if there is anything in the Clipboard which
    // we are capably of pasting
    //

    if (IsClipboardFormatAvailable(CF_TEXT)) {
        EnableMenuItem(hmenuPopup, IDM_PASTE, MF_ENABLED);
    } else {
        EnableMenuItem(hmenuPopup, IDM_PASTE, MF_GRAYED);
    }
}

//
// Create a CF_TEXT Clipboard object from our data
//

static HANDLE CreateCFTEXTObject(LPSTR lpData, DWORD dwLength)
{
    HANDLE hData;
    LPSTR pData = NULL;

    //
    // Allocate the memory block
    //

    hData = GlobalAlloc(GMEM_MOVEABLE | GMEM_ZEROINIT,
                        dwLength);
    if (!hData) {
        Message(0,"Out of memory");
        return NULL;
    }

    pData = GlobalLock(hData);
    _fmemcpy(pData, lpData, LOWORD(dwLength));
    GlobalUnlock(hData);
    return hData;
}

//
// Process a clipboard command
//

void ClipCommand(HWND hWnd, WPARAM wParam)
{
    HANDLE hData, hNewData;
    LPSTR pData = NULL;
    DWORD dwSize;

    switch (wParam) {
    case IDM_COPY:

        ASSERT(pFileData && dwFileLength);
        hData = CreateCFTEXTObject(pFileData, dwFileLength);
        if (!hData) {
            Message(0, "Unable to create Clipboard object");
        } else {
            OpenClipboard(hWnd);
            EmptyClipboard();
            SetClipboardData(CF_TEXT, hData);
            CloseClipboard();
            dprintf2("Copied %lu bytes", dwFileLength);
        }
        break;

    case IDM_PASTE:
        OpenClipboard(hWnd);
        hData = GetClipboardData(CF_TEXT);
        if (hData) {
            pData = GlobalLock(hData);
        }
        if (pData) {
            FileNew(FILE_PROMPT_FOR_SAVE | FILE_UPDATE_CAPTION);
            dwSize = GlobalSize(hData);
            hNewData = GlobalAlloc(GMEM_MOVEABLE | GMEM_ZEROINIT,
                                   dwSize);
            if (!hNewData) {
                Message(0, "Out of memory");
            } else {
                pFileData = GlobalLock(hNewData);
                dwFileLength = dwSize;
                _fmemcpy(pFileData, pData, LOWORD(dwSize));
                dprintf2("Pasted %lu bytes", dwFileLength);
            }
        } else {
            Message(0,"Failed to get Clipboard data");
        }
        CloseClipboard();
        break;

    case IDM_CUT:
        // not implemented, drop through
    default:
        break;
    }
}
