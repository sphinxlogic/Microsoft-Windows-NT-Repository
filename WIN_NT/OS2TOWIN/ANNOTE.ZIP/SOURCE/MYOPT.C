#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "myopt.h"
#define TRUE 1
#define FALSE 0

char *p_optstr;

int my_getopt(int argc, char *argv[], char *optstring)
{
    static index = 1;
    char ch;
    char *pch = NULL;

    p_optstr = NULL;

    if ( ! (index < argc) )
        return(0);

    if (argv[index][0] == '-'
        && isalnum(ch = argv[index][1]))
        {
        if (pch = strchr( optstring, ch))
            {
            // We have an option flag.
            // Does it have an arguement?
            if (*(pch + 1) == ':'
                && index < argc -1)
                {
                // We have an arguement.
                p_optstr = argv[index+1];
                index += 2;
                return((int) ch);
                }
            else
                {
                index++;
                return((int) ch);
                }
            }
        }
    p_optstr = argv[index];
    index++;
    return(-1);
}
