/************************************************************************\
* The enclosed files, "the software," is provided by 
* Microsoft Corporation "as is" without warranty of any kind. 
* MICROSOFT DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR IMPLIED, 
* INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY 
* AND FITNESS FOR A PARTICULAR PURPOSE.  You assume all risks of 
* using the software.
* 
* The software is Copyright (c) 1992 Microsoft Corporation.
* Original Author: John M. Hall, Microsoft SDE  9/1/92
*
* You are granted the right to freely distribute this software.
* You are granted the right to make changes provided this comment block
* is retained without modification and you acknowledge the changes.
* 
\************************************************************************/
#define DEBUG
#include <stdio.h>
#include <assert.h>
#include <windows.h>
#include <string.h>


main()
{
    HKEY hKeyGroup;
    HKEY hKeyMember;
    HKEY hKeyShared;
    DWORD dw;
    LONG lErr;
    LPTSTR lptstr;

    lErr = RegCreateKeyEx( HKEY_LOCAL_MACHINE,
            "Software\\Shareware\\ShrMem\\Groups\\Default", 0, "Class",
            REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hKeyGroup, &dw);

    
    assert( lErr == ERROR_SUCCESS);

    lErr = RegCreateKeyEx( HKEY_LOCAL_MACHINE,
            "Software\\Shareware\\ShrMem\\Members", 0, "Class",
            REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hKeyMember, &dw);

    
    assert( lErr == ERROR_SUCCESS);

    lErr = RegCreateKeyEx( HKEY_LOCAL_MACHINE,
            "Software\\Shareware\\ShrMem", 0, "Class",
            REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hKeyShared, &dw);

    
    assert( lErr == ERROR_SUCCESS);

    dw = 0x01000000;
    lErr = RegSetValueEx( hKeyGroup, "Base", 0, REG_DWORD, (LPBYTE) &dw, sizeof(dw));
    assert( lErr == ERROR_SUCCESS);

    dw = 1024 * 1024;
    lErr = RegSetValueEx( hKeyGroup, "Length", 0, REG_DWORD, (LPBYTE) &dw, sizeof(dw));
    assert( lErr == ERROR_SUCCESS);

    lptstr = "John M. Hall, Microsoft Software Development Engineer";
    dw = strlen(lptstr) + 1;
    lErr = RegSetValueEx( hKeyShared, "Author", 0, REG_SZ, (LPBYTE) lptstr, dw);
    assert( lErr == ERROR_SUCCESS);

    lErr = RegFlushKey(hKeyGroup);
    assert( lErr == ERROR_SUCCESS);
    lErr = RegFlushKey(hKeyMember);
    assert( lErr == ERROR_SUCCESS);
    lErr = RegFlushKey(hKeyShared);
    assert( lErr == ERROR_SUCCESS);

    lErr = RegCloseKey(hKeyGroup);
    assert( lErr == ERROR_SUCCESS);
    lErr = RegCloseKey(hKeyMember);
    assert( lErr == ERROR_SUCCESS);
    lErr = RegCloseKey(hKeyShared);
    assert( lErr == ERROR_SUCCESS);
    return(0);
}
