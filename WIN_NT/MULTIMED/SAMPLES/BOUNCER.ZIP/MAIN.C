/* MAIN.C 
 *
 *  This module allows you to debug your screen saver
 *  using CodeView. When the app is invoked, it creates
 *  the main window, invokes the configuration dialog and then
 *  runs the app in screen saver mode until a key is hit or
 *  a mouse event occurs.
 */

#include    <windows.h>
#include    <scrnsave.h>

#define     THRESHOLD       3

/* Global variables... */

HANDLE      hMainInstance;
HWND        hMainWindow;

/* Local Function definitions... */

int         DoConfigureDialog   ( HANDLE, BOOL );

/* Local variable initialization... */

extern char        szAppName[];

HCURSOR     hcurOld;


int PASCAL WinMain(HANDLE hInst, HANDLE hPrev, LPSTR szCmdLine, WORD sw)
{
    MSG msg;
    WNDCLASS cls;
    FARPROC fpDialog;

    hMainInstance = hInst;

    if(hPrev)                           // Allow only one instance
        return 1;

    if(*szCmdLine && *szCmdLine == '-' || *szCmdLine == '\/')
        szCmdLine++;

    /* Handle command-line switches.
     *
     *    /c, -c, or c:  Display configuration dialog and return.
     *    /s, -s, or s:  Start screen saver.
     *    default:       Display configuration dialog and then start
     *                   screen saver.
     */
    switch(*szCmdLine)
    {
        case 'c':
        case 'C':
            if(fpDialog = MakeProcInstance(ScreenSaverConfigureDialog, hInst))
            {
                if(RegisterDialogClasses(hInst))
                    DialogBox(hInst,"ScreenSaverConfigure",NULL,fpDialog);

                FreeProcInstance(fpDialog);
            }
            return 0;

        case 's':
        case 'S':
            break;

        default:
            if(fpDialog = MakeProcInstance(ScreenSaverConfigureDialog, hInst))
            {
                if(RegisterDialogClasses(hInst))
                    DialogBox(hInst,"ScreenSaverConfigure",NULL,fpDialog);

                FreeProcInstance(fpDialog);
            }
            break;
    }

    //  Register a class for the main window

    cls.hCursor        = NULL;
    cls.hIcon          = LoadIcon(hInst,MAKEINTATOM(ID_APP));
    cls.lpszMenuName   = NULL;
    cls.lpszClassName  = szAppName;
    cls.hbrBackground  = GetStockObject(BLACK_BRUSH);
    cls.hInstance      = hInst;
    cls.style          = CS_VREDRAW | CS_HREDRAW;
    cls.lpfnWndProc    = ScreenSaverProc;
    cls.cbWndExtra     = 0;
    cls.cbClsExtra     = 0;

    if (!RegisterClass(&cls))
        return 1;

    // create the main window

    hMainWindow = CreateWindow (szAppName,              // Class name
                                szAppName,              // Caption
                                WS_POPUP|WS_VISIBLE,    // Style bits
                                0, 0,                   // Position
                                GetSystemMetrics (SM_CXSCREEN), // width
                                GetSystemMetrics (SM_CYSCREEN), // height
                                (HWND)NULL,             // No parent
                                (HMENU)NULL,            // Use class menu
                                (HANDLE)hInst,   // handle to window instance
                                (LPSTR)NULL      // no params to pass on
                           );

    if (!hMainWindow)
        return 1;

    while (GetMessage(&msg,NULL,0,0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return msg.wParam;
}


/* DefScreenSaverProc -- This is a replacement for the Multimedia Windows
 *  default screen saver proc. 
 *
 */

LONG FAR PASCAL DefScreenSaverProc(HWND hWnd, WORD msg, WORD wParam, LONG lParam)
{
static BOOL     fHere;
static POINT    ptLast;
POINT           ptCursor,ptCheck;

    switch (msg) 
    {
        case WM_DESTROY:
            PostQuitMessage(0);
            break;
        case WM_SETCURSOR:
            SetCursor(NULL);
            break;
        case WM_ACTIVATE:
        case WM_ACTIVATEAPP:
            if(wParam != FALSE)
                break;
        case WM_LBUTTONDOWN:
        case WM_MBUTTONDOWN:
        case WM_RBUTTONDOWN:
        case WM_KEYDOWN:
        case WM_SYSKEYDOWN:
            PostMessage(hWnd,WM_CLOSE,0,0l);
            break;
        case WM_MOUSEMOVE:
            if(!fHere)
            {
                GetCursorPos(&ptLast);
                fHere = TRUE;
            }
            else
            {
                GetCursorPos(&ptCheck);
                if(ptCursor.x = ptCheck.x - ptLast.x)
                {
                    if(ptCursor.x < 0)
                        ptCursor.x *= -1;
                }
                if(ptCursor.y = ptCheck.y - ptLast.y)
                {
                    if(ptCursor.y < 0)
                        ptCursor.y *= -1;
                }
                if((ptCursor.x + ptCursor.y) > THRESHOLD)
                    PostMessage(hWnd,WM_CLOSE,0,0l);
            }
            break;
    }
    return DefWindowProc(hWnd,msg,wParam,lParam);
}
