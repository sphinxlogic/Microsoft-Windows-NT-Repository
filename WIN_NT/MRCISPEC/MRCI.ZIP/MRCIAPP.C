/* MRCIAPP.C - MRCI Test app
*
*       MRCI version 1.00.08  02-Apr-1993
*/


#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <malloc.h>
#include <ctype.h>
#include <fcntl.h>
#include <io.h>
#include <sys\types.h>
#include <sys\stat.h>
#include <memory.h>
#include <dos.h>

#include "mrci.h"

//  Local defines/typedefs/structs --------------------------------------

#define TRUE    (1)
#define FALSE   (0)

typedef int BOOL;


//  Function prototypes -------------------------------------------------

void      CheckOptions(int, char **);
void      CleanUp(void);
int       Compress(unsigned short, void *, void *, unsigned short *);
int       Decompress(unsigned short, void *, void *, unsigned short *);
void      DumpData(unsigned short, unsigned char *, char *);
LPMRCINFO MRCIQuery(void);
void      Quit(char *szFmt, ...);
void      Usage(void);


//  Global data ---------------------------------------------------------

LPMRCINFO fpMRCInfo;                    // pointer to MRCInfo struct

#define mi  fpMRCInfo

int fVerbose = 0;                       // -V option
int fCompOnly= 0;                       // -C option

char *pszFile = NULL;                   // file name to compress

int fh = 0;                             // file handle

unsigned short cbBuf;                   // buffer size in use
unsigned short cbCur;                   // cnt bytes data in buffer this time
unsigned short cbData;                  // size of uncompressed data in buffer
unsigned short cbComp;                  // size of compressed data in buffer
unsigned long  cbTotalData;             // total size of uncompressed data
unsigned long  cbTotalComp;             // total size of compressed data

char tagStart[] = "ABCDEFGHIJKLMNOPQRSTUZWXYZ";
unsigned char abBuf1[4*1024];           // buffers for compress/decompress
unsigned char abBuf2[4*1024];
unsigned char abBuf3[4*1024];
char tagEnd[]   = "ABCDEFGHIJKLMNOPQRSTUZWXYZ";


//  Main() --------------------------------------------------------------

int main(int argc, char **argv) {

    unsigned short  i;
    int rc;
    char *cp1, *cp2;

    CheckOptions(argc,argv);            // Process command line options

    // Is an MRCI Server installed?

    if ((fpMRCInfo = MRCIQuery()) == NULL)
        Quit("No MRCI server detected!\n");

    // Pick the buffer size we'll use

    cbBuf = (mi->mi_cbMax < sizeof(abBuf1)) ?
             mi->mi_cbMax : sizeof(abBuf1);

    // Give user some info if verbose mode

    if (fVerbose) {

        printf("MRCI Version %d.%02d, vender %08lxh, vender version %d.%02d\n",
               mi->mi_wMRCIVersion >> 8, mi->mi_wMRCIVersion & 0xFF,
               mi->mi_lVendor, mi->mi_wVendorVersion >> 8,
               mi->mi_wVendorVersion & 0xFF);

        printf("MRCI Capabilities: %xh, max buf size %u\n",
               mi->mi_flCapability, mi->mi_cbMax);

        printf("Using %d buffer size\n", cbBuf);
    }

    // Open the designated file

    if ((fh = open(pszFile, O_RDONLY | O_BINARY)) == -1)
        Quit("Unable to open \"%s\"!\n",pszFile);

    // Compress the file, one buffer at a time

    while (1) {

        // Read a buffer full of data

        if ((cbData = read(fh, abBuf1, cbBuf)) == -1)
            Quit("Error reading file!\n");

        if (cbData == 0)
            break;

        cbTotalData += cbData;
        DumpData(cbData, abBuf1, "Original data    ");

        // Compress the data!

        if (fVerbose)
           printf("Compressing %u bytes\n", cbData);

        cbCur = cbData;
        cbComp = cbBuf;                 // dest buffer size
        rc = Compress(cbData, abBuf1, abBuf2, &cbComp);

        if (rc != MRCI_ERROR_NONE && rc != MRCI_ERROR_NOT_COMPRESSIBLE &&
            rc != MRCI_ERROR_BUFFER_OVERFLOW)
            Quit("Error %d trying to compress data\n",rc);

        if (rc == MRCI_ERROR_NONE) {
            if (fVerbose)
                printf("Data compressed to %u bytes\n",cbComp);
            DumpData(cbComp, abBuf2, "Compressed data  ");
            cbTotalComp += cbComp;
        } else { // MRCI_ERROR_NOT_COMPRESSIBLE || MRCI_ERROR_BUFFER_OVERFLOW
            if (fVerbose)
                printf("Data did not compress\n");
            cbTotalComp += cbData;
        }

        // Decompress the data and compare to inital uncompressed data

        if (rc == MRCI_ERROR_NONE && !fCompOnly) {

            if (fVerbose)
                printf("Decompressing %u bytes\n", cbComp);

            cbData = cbCur;                 // dest buffer size
            rc = Decompress(cbComp, abBuf2, abBuf3, &cbData);

            if (rc != MRCI_ERROR_NONE)
                Quit("Error %d trying to decompress data\n", rc);

            if (fVerbose)
                printf("Data expanded to %u bytes\n", cbData);

            DumpData(cbData, abBuf3, "Uncompressed data");

            if (cbCur != cbData)
                Quit("%u compressed to %u, but expanded to %u!\n",
                     cbCur, cbComp, cbData);

            for (i = 0, cp1 = abBuf1, cp2 = abBuf3; i < cbData; i++, cp1++, cp2++)
                if (*cp1 != *cp2)
                    Quit("Uncompressed data doesn't match original"
                         " at offset %d\n", i);

            if (fVerbose)
                printf("Uncompressed data matches original\n");
        }

    }

    printf("%lu uncompressed bytes, %lu compressed", cbTotalData, cbTotalComp);
    if (cbTotalComp)
        printf(", %u.%u to 1.0 comp ratio",
             (unsigned short)(cbTotalData / cbTotalComp),
             (unsigned short)(((cbTotalData % cbTotalComp) * 10) / cbTotalComp));

    printf("\n");

    if (fVerbose)
        printf("Done.\n");

    close(fh);                          // Close file
    return 0;                           // Success
}


//  C H E C K O P T I O N S ---------------------------------------------

void
CheckOptions(int argc, char **argv) {

    int fGotOpt;
    char ch, *cp;

    while (--argc) {
        if (*(cp = *++argv) == '/' || *cp == '-') {         // option?
            fGotOpt = FALSE;
            while (ch = *++cp) {
                fGotOpt = TRUE;
                switch (tolower(ch)) {
                    case '?':                   // help
                    case 'h':
                        Usage();

                    case 'c':                   // compress only
                        fCompOnly++;
                        break;

                    case 'v':                   // verbose
                        fVerbose++;
                        break;

                    default:
                        Quit("Invalid switch \"%c\".",ch);
                }
            }
            if (!fGotOpt)
                Quit("Invalid or missing switch");
        } else {    // arg doesn't start with - or /
            if (pszFile)
               Quit("Invalid parameter \"%s\"",cp);
            else
                pszFile = cp;
        }
    }

    if (!pszFile)
        Usage();
}


//  CleanUp -------------------------------------------------------------

void CleanUp(void) {
    if (fh)
        close(fh);
}

//  Compress ------------------------------------------------------------

int Compress(unsigned short cbData, void *pInBuf, void *pOutBuf,
                 unsigned short *cbComp) {

    int rc;
    static MRCREQUEST mr;

    // Fill in MRCREQUEST structure

    mr.mr_pbSrc = pInBuf;
    mr.mr_cbSrc = cbData;
    mr.mr_RESERVED = 0;
    mr.mr_pbDst = pOutBuf;
    mr.mr_cbDst = *cbComp;
    mr.mr_cbChunk = 1;

    _asm {

        push    si
        push    di

        mov     ax, micapSTANDARD       ; standard compress
        mov     cx, mcAPPLICATION       ; I'm an application
        les     bx, fpMRCInfo           ; server doesn't need this, but I do
        mov     si, offset mr           ; ds:si -> request packet

;*  Enter a Windows disk critical section.  This must be done to prevent
;   the MCRI server from being reentered if multiple VMs are making MRCI
;   calls under 386 Enhanced mode Windows.  The MRCI server sets the
;   InDOS flag, but that is not enough, as InDOS is a per-VM variable.

        push    ax                      ; NOTE: Use this exact sequence of
        mov     ax,8001h                ;       instructions because Windows
        int     2ah                     ;       expects it and will patch
        pop     ax                      ;       other code here

        push    bp
        call    dword ptr es:[bx].mi_pfnOperate ; Call Server
        pop     bp

;*  Release the disk critical section.  The MRCI server is now available.

        push    ax                      ; NOTE: Use this exact sequence of
        mov     ax,8101h                ;       instructions because Windows
        int     2ah                     ;       expects it and will patch
        pop     ax                      ;       other code here

        mov     rc, ax                  ; save return code

        pop     di
        pop     si
    }

    *cbComp = mr.mr_cbDst;      // size of compressed data if successful,
                                // undefined if not

    return (rc);
}

//  Decompress ----------------------------------------------------------

int Decompress(unsigned short cbComp, void *pInBuf, void *pOutBuf,
               unsigned short *cbData) {

    int rc;
    static MRCREQUEST mr;

    // Fill in MRCREQUEST structure

    mr.mr_pbSrc = pInBuf;
    mr.mr_cbSrc = cbComp;
    mr.mr_RESERVED = 0;
    mr.mr_pbDst = pOutBuf;
    mr.mr_cbDst = *cbData;
    mr.mr_cbChunk = 1;

    _asm {

        push    si
        push    di

        mov     ax, micapDECOMPRESS     ; standard compress
        mov     cx, mcAPPLICATION       ; I'm an application
        les     bx, fpMRCInfo           ; server doesn't need this, but I do
        mov     si, offset mr           ; ds:si -> request packet

;*  Enter a Windows disk critical section.  This must be done to prevent
;   the MCRI server from being reentered if multiple VMs are making MRCI
;   calls under 386 Enhanced mode Windows.  The MRCI server sets the
;   InDOS flag, but that is not enough, as InDOS is a per-VM variable.

        push    ax                      ; NOTE: Use this exact sequence of
        mov     ax,8001h                ;       instructions because Windows
        int     2ah                     ;       expects it and will patch
        pop     ax                      ;       other code here

        push    bp
        call    dword ptr es:[bx].mi_pfnOperate ; Call Server
        pop     bp

;*  Release the disk critical section.  The MRCI server is now available.

        push    ax                      ; NOTE: Use this exact sequence of
        mov     ax,8101h                ;       instructions because Windows
        int     2ah                     ;       expects it and will patch
        pop     ax                      ;       other code here

        mov     rc, ax                  ; save return code

        pop     di
        pop     si
    }

    *cbData = mr.mr_cbDst;      // size of compressed data if successful,
                                // undefined if not

    return (rc);
}

//  DumpData ------------------------------------------------------------

void DumpData(unsigned short cbData, unsigned char *abBuf, char *szText) {

    int i;
    unsigned char *cp;

    if (fVerbose) {
        i = (cbData < 10) ? cbData : 10;
        if (i) {
            printf("%s:", szText);

            for (cp = abBuf; i; i--, cp++)
                printf("  %02X %c", *cp, (*cp < ' ' || *cp > 'z') ? '.' : *cp);

            printf("\n");
        }
    }
}


//  MRCIQuery -----------------------------------------------------------

LPMRCINFO MRCIQuery(void) {

    LPMRCINFO fpMI;

    _asm {

        push    di

        ; We have to check for two MRCI servers.  First check for a
        ; software server, and if none found, check for a ROM based
        ; server.

        xor     ax, ax                      ; check for 0 Int vector
        mov     es, ax
        mov     ax, word ptr es:[intMRCI*4]
        or      ax, word ptr es:[intMRCI*4][2]
        jz      mq_no_SW_MRCI

        mov     ax, mrciDETECT              ; issue detect Int call
        mov     cx, sigOLD_CX
        mov     dx, sigOLD_DX
        int     intMRCI

        cmp     cx, sigNEW_CX               ; proper signature on return?
        jne     mq_no_SW_MRCI
        cmp     dx, sigNEW_DX
        je      mq_got_MRCI

mq_no_SW_MRCI:

        ; Didn't find a software server, check for ROM based server

        xor     ax, ax                      ; check for 0 Int vector
        mov     es, ax
        mov     ax, word ptr es:[intMRCIROM*4]
        or      ax, word ptr es:[intMRCIROM*4][2]
        jz      mq_no_MRCI

        mov     ax, mrciDETECTROM           ; issue detect Int call
        mov     cx, sigOLD_CX
        mov     dx, sigOLD_DX
        int     intMRCIROM

        cmp     cx, sigNEW_CX               ; proper signature on return?
        jne     mq_no_MRCI
        cmp     dx, sigNEW_DX
        je      mq_got_MRCI

mq_no_MRCI:
        xor     di, di                      ; NULL return
        mov     es, di

mq_got_MRCI:
        mov     word ptr [fpMI], di         ; save MRCINFO ptr for return
        mov     word ptr [fpMI+2], es

        pop     di
    }

    return (fpMI);
}



//  Q U I T  ------------------------------------------------------------

void
Quit(char *szFmt, ...) {

    if (szFmt) {

        va_list arg_ptr;

        va_start(arg_ptr,szFmt);
        printf("\n");
        vprintf(szFmt,arg_ptr);
        printf("\n");
        va_end(arg_ptr);
    }

    CleanUp();                      // clean up before terminating

    exit(szFmt != NULL);
}


//  U S A G E  ----------------------------------------------------------

void
Usage(void) {

    fputs("\n",stdout);
    fputs("Usage: mrciapp [-cv] file\n",stdout);
    fputs("     -c = compress only (don't decompress after compress)\n",stdout);
    fputs("     -v = verbose (default off)\n",stdout);
    fputs("     file = name of file to compress\n",stdout);

    Quit(NULL);
}
