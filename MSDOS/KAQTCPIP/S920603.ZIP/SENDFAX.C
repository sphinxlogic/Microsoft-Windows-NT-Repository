/* Experimental FAX interface code
 * Copyright 1991 Phil Karn, KA9Q
 */
#include <stdio.h>
#include "global.h"
#include "smtp.h"

/* Send a mail message by FAX using Gamma Link interface board and software */
int
sendfax(dfile,num)
FILE *dfile;
char *num;
{
	int c;
	FILE *fp;
	long id;
	char tiffile[128];

	id = get_msgid();

	/* Put body of message in temporary file */
	fp = fopen("fax.tmp","w");
	while((c = getc(dfile)) != EOF){
		putc(c,fp);
	}
	fclose(fp);
	fclose(dfile);

	/* Convert message to TIF format and delete original */
	sprintf(tiffile,"\\fax\\faxw fax.tmp %s\\f%ldp001.TIF","\\fax",id);
	printf("system(%s)\n",tiffile);
	system(tiffile);
	unlink("fax.tmp");

	/* Now create the command file */
	fp = fopen("fax.tmp","w");
	printf("fax.tmp:\n");
	fprintf(fp,"send %s\\f%ldp001.TIF\n","\\fax",id);
	printf("send %s\\f%ldp001.TIF\n","\\fax",id);

	/* Note temporary 9 prefix for Centrex line */
	fprintf(fp,"dial =3 9%s\n",num);
	printf("dial =3 9%s\n",num);

	fprintf(fp,"exit\n");
	printf("exit\n");
	fclose(fp);

	/* and give it to gcl */
	printf("system(%s)\n","\\fax\\gcl fax.tmp");
	system("\\fax\\gcl fax.tmp");
	unlink("fax.tmp");

	return 0;
}

