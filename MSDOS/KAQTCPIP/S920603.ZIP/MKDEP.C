/* Simple-minded program that generates dependencies for a makefile.
 * Does not process #ifdefs, so some spurious dependencies may be
 * generated.
 *
 * Copyright 1991 Phil Karn, KA9Q
 */
#include <stdio.h>
#include <string.h>

char include[] = "#include";
main(argc,argv)
int argc;
char *argv[];
{
	int i;
	FILE *fp;
	char buf[512],*cp,*cp1;

	for(i=1;i<argc;i++){
		strcpy(buf,argv[i]);
		if((cp = strchr(buf,'.')) == NULL)
			continue;
		*cp = '\0';
		printf("%s.obj: %s",buf,argv[i]);
		fp = fopen(argv[i],"r");
		if(fp == NULL){
			fprintf(stderr,"Cannot open %s\n",argv[i]);
			continue;
		}
		while(fgets(buf,512,fp) != NULL){
			if(strncmp(buf,include,sizeof(include)-1) != 0)
				continue;
			if((cp = strchr(buf,'\"')) == NULL)
				continue;
			cp++;
			if((cp1 = strchr(cp,'\"')) == NULL)
				continue;
			putchar(' ');
			while(cp != cp1)
				putchar(*cp++);
		}
		putchar('\n');
		fclose(fp);
	}
	return 0;
}
