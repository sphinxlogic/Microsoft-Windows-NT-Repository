/* version control information */
char Version[] = "920603 (KA9Q)";
