
	if (ginon && current->termstate==TEKTYPE) {	/* check for GIN mode for tektronics */
		ch=n_chkchar();
		if (ch!= -1) {
			if ((ch!='\r')&&(ch!='\n')) lch=ch;
			  else if (lch!= -1) {	/* send gin data string */
				mousecl(&m1,&m2,&m3,&m4);       		/* get the mouse's position */
				VGgindata(current->vs,m3,m4,(char) lch,gindata);	/* send the mouse cursor */
													/* position to be translated */
													/* by VGgindata and the */
													/* information returned */
													/* in gindata */
				RSsendstring(current->vs,gindata,5);	/* return GIN data across network */
				lch=-1;									/* clear last char buffer */
				resetgin();								/* reset GIN mode */
		  	  }											/* end if */
	  	}												/* end if */
	}
