/*
 * 	Part of NCSA telnet
 *
 *	These routines are needed by the utilitites other than telnet
 *	to avoid unresolved references.  They may be expanded for
 * 	more funcionatity at a later date.
 *
 *	New - 6/27/91	Jeff Wiedemeier
 */

#include <stdio.h>
#include "externs.h"
#include "windat.h"

/*
 * The following routines are to satisfy look.c and memdebug.c
 */

struct twin fool_them, *console=&fool_them;

void vprint(w,s)
int w;
char *s;
{
	w=w;	/* No warning this way */
#ifdef DEBUG	/* without debug - ignore messages */
	fprintf(stderr, s);
#else
	s = s;	/* no warning */
#endif /* DEBUG */
}

/*
 * None but telnet need inv_port_err (which is called from tcp.c)
 * this prevents unresolved references
 */

void inv_port_err(int service, int port, uint8 *ip)
{
	service=service;
	port=port;
	ip=ip;
}
