/* rebuild.c	Merges the splitted files arrived from SIMTEL 20.
 *		You can easily improve it, passing the INPUT_FILE
 *		and OUTPUT_FILE names in *argv and adding a system(2) 
 *		command to call "uudecode OUTPUT_FILE (in argv)". 
 *		If you do that let me know.
 *
 * MARIO A. Nascimento, 	21/06/90, 	10:11 hs.
 * mario@ntiaa.embrapa.ansp.br 	NTIA-EMBRAPA 	CAMPINAS - SP - BRAZIL
 *
 * Public Domain. Just maintain this note as part of this source program.
 * No warranties. You are on your own, being the only responsible for 
 * using this piece of software.
 * Works fine with MSC 5.0 under DOS 3.3 (and problably others !).
 *
 * Usage: rebuild < INPUT_FILE > OUTPUT_FILE
 */

 /*Usage changed to: rebuild INPUT_FILE OUTPUT_FILE
 * program then does system call to "uudecode" with parameter
 * OUTPUT_FILE. Fixed bug where "end" did not get written to the
 * OUTPUT_FILE when "end" was read by buffer1.
 *
 * Depending on your compiler, you may need to change:
 *      main (int argc, char *argv[])
 *      {
 *	        char    decode[80];
 *  to:
 *      main (argc, *argv[])
 *      {
 *              int     argc;
 *              char    *argv[];
 *	        char    decode[80];
 *
 * Dwight H. Southwick   11/8/90
 * dsouthwick%lynx@helios.northeastern.edu           */

#include	<stdio.h>

main (int argc, char *argv[])
{
	char    decode[80];
	char	buffer1[80], buffer2[80];
	FILE    *input, *output;

/*	if (argc != 1) {
		fprintf(stderr,"Usage: rebuild < INPUT_FILE > OUTPUT_FILE\n");
		fprintf(stderr,"MARIO A. Nascimento,\t\t21/06/90,\t10:11 hs\n");
		fprintf(stderr,"mario@ntiaa.embrapa.ansp.br\tNTIA-EMBRAPA\t");
		fprintf(stderr,"CAMPINAS - SP - BRAZIL\n");
		exit(1);
	}
*/
	if (argc != 3) {
		fprintf(stderr,"Usage: rebuild  INPUT_FILE  OUTPUT_FILE\n");
		fprintf(stderr,"Original code by:\n");
		fprintf(stderr,"MARIO A. Nascimento,\t\t21/06/90,\t10:11 hs\n");
		fprintf(stderr,"mario@ntiaa.embrapa.ansp.br\tNTIA-EMBRAPA\t");
		fprintf(stderr,"CAMPINAS - SP - BRAZIL\n");
		fprintf(stderr,"This revision by:\n");
		fprintf(stderr,"Dwight H. Southwick,\t\t06/10/90,\t10:19 hs\n");
		fprintf(stderr,"dsouthwick%lynx@helios.northeastern.edu\n");
		exit(1);
	}


	input = fopen(argv[1],"r");
	output = fopen(argv[2],"w");
	for(; strcmp(buffer1,"begin"); )
		fscanf(input,"%s",buffer1);

	strcat(buffer1," "); fprintf(output,"%s",buffer1);
	fscanf(input,"%s",buffer1); strcat(buffer1," ");
	fprintf(output,"%s",buffer1); fscanf(input,"%s",buffer1);
	strcat(buffer1,"\n"); fprintf(output,"%s",buffer1);

	fscanf(input,"%s",buffer1); fscanf(input,"%s",buffer2);
	for (; ; ) {
		if (strcmp(buffer1,"----------") && 
		    strcmp(buffer2,"----------")) {
			strcat(buffer1,"\n"); fprintf(output,"%s",buffer1);
			strcat(buffer2,"\n"); fprintf(output,"%s",buffer2);
		}
		else {
			if (!strcmp(buffer2,"----------")) {
				strcat(buffer1,"\n");
				fprintf(output,"%s",buffer1);
			}
			for (fscanf(input,"%s",buffer1);
			     strcmp(buffer1,"--------------");
			     fscanf(input,"%s",buffer1))
				;
			fscanf(input,"%s",buffer2);
			fscanf(input,"%s",buffer2);
			fscanf(input,"%s",buffer2);
			fscanf(input,"%s",buffer2);
			fscanf(input,"%s",buffer2);
		}
		fscanf(input,"%s",buffer1); fscanf(input,"%s",buffer2);
		if (!strcmp(buffer1,"end") || !strcmp(buffer2,"end")) {
			if (strcmp(buffer1,"end"))
				fprintf(output,"%s\nend\n",buffer1);
			else
				fprintf(output,"end\n");
			break;
		}
	}
	fclose(input);
	fclose(output);
	strcpy(decode,"uudecode ");
	strcat(decode,argv[2]);
	system(decode);
	return(0);
}
