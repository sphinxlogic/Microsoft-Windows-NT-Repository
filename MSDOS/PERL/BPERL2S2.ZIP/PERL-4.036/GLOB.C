/******************************************************************************
 * NOTE: This file has been modified for use with MSDOS and the WATCOM C/386
 * compiler.  Darryl Okahata, March 1993.
 *****************************************************************************/

/*
 * Globbing for MS-DOS.  Relies on the expansion done by the library
 * startup code. (dds)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef __TURBOC__
extern unsigned int	_stklen = 16384;
#endif

extern char	*optarg;
extern int	optind;

static s_compare(char **a, char **b)
{
	return (strcmp(*a, *b));
}

main(int argc, char *argv[])
{
	register int	i;
	char		opt;
	int		use_zeroes = 0;

	/* Expand wildcards ... */
	__process_wildcards(&argc, &argv);
	while ((opt = getopt(argc, argv, "z")) != -1) {
		switch (opt) {
		case 'z':
			use_zeroes = 1;
			break;
		default:
			exit(1);
			break;
		}
	}
#if 0
	if (argc > optind) {
		qsort(&argv[optind], argc - optind, sizeof(char *),
                      (int(*)(const void *, const void *))s_compare);
	}
#endif
	for (i = optind; i < argc; i++) {
		fputs(strlwr(argv[i]), stdout);
		if (use_zeroes) {
			putchar(0);
		} else {
			if (i < argc - 1) {
				putchar(' ');
			}
		}
	}
	if (!use_zeroes) {
		putchar('\n');
	}
	exit(0);
}
