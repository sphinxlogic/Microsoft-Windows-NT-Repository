# OS/2 syscall values

$OS2_GetVersion = 0;
$OS2_Shutdown = 1;
$OS2_Beep = 2;
$OS2_PhysicalDisk = 3;
$OS2_Config = 4;
$OS2_IOCtl = 5;
$OS2_QCurDisk = 6;
$OS2_SelectDisk = 7;
$OS2_SetMaxFH = 8;
$OS2_Sleep = 9;
$OS2_StartSession = 10;
$OS2_StopSession = 11;
$OS2_SelectSession = 12;
1;
