usemymalloc=n
mallocsrc=''
mallocobj=''
