ldflags='-L/usr/ucblib'
