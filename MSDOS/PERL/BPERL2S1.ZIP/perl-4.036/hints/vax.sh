teval_cflags='case $cc in *gcc);; *) optimize="-O";; esac'
