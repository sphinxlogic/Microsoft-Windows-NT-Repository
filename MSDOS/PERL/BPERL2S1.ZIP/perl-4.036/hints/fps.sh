ccflags="$ccflags -J -DBADSWITCH"
