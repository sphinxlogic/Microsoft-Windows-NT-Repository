/***********************************************************************/
/* VAX.C -                                                             */
/* This file contains pseudo SystemV functions that are missing on VAX.*/
/***********************************************************************/
/*
 * THE - The Hessling Editor. A text editor similar to VM/CMS xedit.
 * Copyright (C) 1991,1992 Mark Hessling
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to:
 * 
 *    The Free Software Foundation, Inc.
 *    675 Mass Ave,
 *    Cambridge, MA 02139 USA.
 * 
 * 
 * If you make modifications to this software that you feel increases
 * it usefulness for the rest of the community, please email the
 * changes, enhancements, bug fixes as well as any and all ideas to me.
 * This software is going to be maintained and enhanced as deemed 
 * necessary by the community.
 *
 * Mark Hessling                     email: M.Hessling@itc.gu.edu.au
 * 36 David Road                     Phone: +61 7 849 7731
 * Holland Park                      Fax:   +61 7 875 7877
 * QLD 4121
 * Australia
 */
#include <stdio.h>
#include <stdlib.h>
#include <curses.h>

#include "the.h"
/*-------------------------- external data ----------------------------*/
extern VIEW_DETAILS *vd_current,*vd_first;
extern char current_file;                   /* pointer to current file */
/*---------------------- function definitions -------------------------*/
/***********************************************************************/
int reset_shell_mode()
/***********************************************************************/
{
/*--------------------------- local data ------------------------------*/
/*--------------------------- processing ------------------------------*/
 return(0);
}
/***********************************************************************/
int reset_prog_mode()
/***********************************************************************/
{
/*--------------------------- local data ------------------------------*/
/*--------------------------- processing ------------------------------*/
 return(0);
}
/***********************************************************************/
int doupdate()
/***********************************************************************/
{
/*--------------------------- local data ------------------------------*/
 unsigned short y,x;
/*--------------------------- processing ------------------------------*/
 getyx(CURRENT_WINDOW,y,x);
 refresh();
 wmove(CURRENT_WINDOW,y,x);
 wrefresh(CURRENT_WINDOW);
 return(0);
}
/***********************************************************************/
int wnoutrefresh(win)
WINDOW *win;
/***********************************************************************/
{
/*--------------------------- local data ------------------------------*/
/*--------------------------- processing ------------------------------*/
 wrefresh(win);
 return(0);
}
/***********************************************************************/
int notimeout(win,bf)
WINDOW *win;
bool bf;
/***********************************************************************/
{
/*--------------------------- local data ------------------------------*/
/*--------------------------- processing ------------------------------*/
 return(0);
}
/***********************************************************************/
int wattrset(win,attrs)
WINDOW *win;
long attrs;
/***********************************************************************/
{
/*--------------------------- local data ------------------------------*/
#define A_NORMAL        000000000000L
/*--------------------------- processing ------------------------------*/
 if (attrs == A_NORMAL)
    wstandend(win);
 else
    wstandout(win);
 return(0);
}
/*#include "sys$login:vax.i" */
#include iodef
#include descrip
/***********************************************************************/
int keypress()
/***********************************************************************/
{
/*--------------------------- local data ------------------------------*/
struct { long length; char *address; } logical_name;
struct { short status; short length; int remainder; } iosb;
 
static char kb[] = { "sys$input" };
static int chan;
 
static char key = 0;
int new_key;
static int first = 1;
int status;
/*--------------------------- processing ------------------------------*/
 
 key = 0;
 logical_name.length = strlen (kb);
 logical_name.address = kb;
 status = sys$assign (&logical_name, &chan, 0, 0);
 if (status != 1)
   return(-1);
 status = SYS$QIOW(0, chan, IO$_READVBLK | IO$M_NOFILTR | IO$M_NOECHO
        | IO$M_TIMED, &iosb, 0, 0, &key, 1,600, 0,0, 0, 0);
 if (!key)
    return (0);
 new_key = (int)(unsigned)(key);
 status = sys$dassgn (chan);
 return (new_key);
}
