/*
 * Used to return number of bytes member is from start of structure type.
 * This is used because Manx 3.20a can't handle Bob's OFFSET macro 
 */

char *offset_dummy = 0;
