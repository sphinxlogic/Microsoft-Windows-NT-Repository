#include "dos.h"

main(argc, argv)
	char *argv[];
{
	union REGS regs, cregs;
	long i, max;
	int fid;
	
	max = atoi(argv[1]);
	for(i = 0; i < max; ++i) {
		if( argc == 2 ) {
			regs.h.ah = 0x3D;	/* open file */
			regs.h.al = (char)0;
			regs.x.dx = (int)"test.c";
			intdos(&regs, &regs);

			cregs.x.bx = regs.x.ax;
			cregs.h.ah = 0x3E;
			intdos(&cregs, &cregs);
		}
	}
	exit(0);
}
