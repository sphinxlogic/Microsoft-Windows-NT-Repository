#include "dos.h"
#include "stdlib.h"

#define MAXHANDLES 40
unsigned char handleTable[MAXHANDLES];

main(argc, argv)
	char *argv[];
{
	unsigned int far *fp;
	unsigned int far *fp2;
	unsigned char far *oldHandleTable;
	unsigned char far *newHandleTable;
	struct SREGS sr;
	unsigned char fileName[100];
	int fid;
	int i, nOldHandles, nNewHandles;
	union REGS regs;

	segread(&sr);
	printf("cs=0x%X  ds=0x%X\n", sr.cs, sr.ds);
	/* get the old handle table information */
	FP_OFF(fp) = 0x32;
	FP_SEG(fp) = _psp;
	nOldHandles = *fp;
	printf(
	"nOldHandles=%d [0x%X]   offset=%d [0x%X]   segment=%d [0x%X]\n",
		nOldHandles, nOldHandles,
		*(fp+1), *(fp+1), *(fp+2), *(fp+2) );

	/* set oldHandleTable to point to the original handle table */
	FP_OFF(oldHandleTable) = *(fp+1);
	FP_SEG(oldHandleTable) = *(fp+2);
	
	for(i = 0; i < nOldHandles; ++i ) {
		printf("%4d=0x%2X       ", i, oldHandleTable[i]);
	}
	printf("\n");

	for(i = 0; i < nOldHandles; ++i ) {
		handleTable[i] = oldHandleTable[i];
	}
	for(i = nOldHandles; i < MAXHANDLES; ++i)
		handleTable[i] = 0xFF;

	fp2 = (unsigned char far *)(&handleTable[0]);
printf("&handleTable[0]=%lX\n", fp2);
printf("Ready to set up the new handle table\n");
getch();
	*fp = MAXHANDLES;
	*(fp+1) = FP_OFF(fp2);
	*(fp+2) = FP_SEG(fp2);

	nNewHandles = *fp;
	printf(
	"nNewHandles=%d [0x%X]   offset=%d [0x%X]   segment=%d [0x%X]\n",
		nNewHandles, nNewHandles,
		*(fp+1), *(fp+1), *(fp+2), *(fp+2) );
	FP_OFF(newHandleTable) = *(fp+1);
	FP_SEG(newHandleTable) = *(fp+2);
	for(i = 0; i < MAXHANDLES; ++i ) {
		printf("%4d=0x%2X       ", i, newHandleTable[i]);
	}
	printf("\n");

printf("Ready to open some files\n");
getch();
	/* now open some files */
	for(i = 1; i < 25; ++i) {
		sprintf(fileName, "t%02d", i);
		regs.h.ah = 0x3D;	/* open file */
		regs.h.al = (unsigned char)0;
		regs.x.dx = (int)fileName;
		intdos(&regs, &regs);
		fid = regs.x.ax;
		printf("open(%s)=%2d    ", fileName, fid);
	}
	for(i = 0; i < MAXHANDLES; ++i ) {
		printf("%4d=0x%2X       ", i, newHandleTable[i]);
	}
	printf("\n");

printf("\nReady to exit\n");
getch();
}
