#include "stdio.h"
#include "dos.h"
#include "conio.h"

static unsigned char dta[64];
long counts[256];

main(argc, argv)
	int argc;
	char *argv[];
{
	int i, n;
	union REGS rin, rout;
	
	if( argc < 2 ) {
		printf("usage: files filePattern\n");
		exit(1);
	}

	/* set DTA */
	rin.h.ah = 0x1A;
	rin.x.dx = (int)dta;
	intdos(&rin, &rout);
	
	/* find first file */
	rin.h.ah = 0x4E;
	rin.x.cx = 0x0;
	rin.x.dx = (unsigned int)argv[1];
	intdos(&rin, &rout);
	printf("find first: ax=%d cflag=%d", rout.x.ax, rout.x.cflag);
	if( argc > 2 )
		for(i = 0; i < 21; ++i)
			printf("%02X ", dta[i]);
	
	/* loop and find the other files */
	while( (rout.x.cflag & 1) == 0 ) {
		printf("file <%s>\n", &dta[30]);
		
		/* find next files */
		rin.h.ah = 0x4F;
		intdos(&rin, &rout);
		printf("find next: ax=%d cflag=%d", rout.x.ax, rout.x.cflag);
		if( argc > 2 )
			for(i = 0; i < 21; ++i)
				printf("%02X ", dta[i]);
	}
}
