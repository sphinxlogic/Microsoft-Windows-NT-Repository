#include "dos.h"

main(argc, argv)
	char *argv[];
{
	extern unsigned int _psp;
	struct SREGS sr;
	int i, j;
	char far *fp;
	char far *makePointer(unsigned int, unsigned int);
	long longLen, longSum;
	unsigned int *uip, procid, len, seg;
	unsigned char zch, ch, *cp;
	
	segread( &sr );
	fp = makePointer(0, _psp - 1);
	fp = makePointer(0xC3, 0);
	cp = (unsigned char *)&seg;
	*cp++ = *fp++;
	*cp = *fp;
	fp = makePointer(0x24, seg);
	cp = (unsigned char *)&seg;
	*cp++ = *fp++;
	*cp = *fp;
	longSum = 0;
	while( 1 ) {
		fp = makePointer(0, seg);
		zch = *fp;
		cp = (unsigned char *)&procid;
		*cp++ = *(fp+1);
		*cp = *(fp+2);
		cp = (unsigned char *)&len;
		*cp++ = *(fp+3);
		*cp = *(fp+4);
		longLen = 16L * (long)len;
		longSum += longLen;
		printf(
"Block @%04X0: %c  ID=%04X; length = %6ld [=0x%04X0] {%6ld}\n",
			FP_SEG(fp), zch, procid, longLen, len, longSum);
		if( zch == 'Z' )
			break;
		seg += 1 + len;
	}
	exit( 0 );
}

char far *
makePointer(offset, segment)
	unsigned int offset, segment;
{
	unsigned int *uip;
	char far *fp;
	
	uip = (unsigned int *)&fp;
	*uip++ = offset;
	*uip = segment;
	return fp;
}
