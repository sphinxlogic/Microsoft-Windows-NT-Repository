#include "pt.h"

/* copyright message */
static unsigned char *copyRightString =
"(C) Copyright 1989 Charles Crowley d/b/a Lemma Systems 505-265-1188";

/* sign-on message */
unsigned char *copyRightMsg =
"Point Editor Version 2.00h Copyright 1989 Charles Crowley. All Rights Reserved";

/* USER MESSAGES */
/* XTAG:userMessages */
unsigned char *userMessages[] = {

/* NOT USED -- MESSAGE 0 */
"",

/* HANDLEMSG */
"Out of file handles. Cannot open file. Increase FILES=xx in \"config.sys\"",

/* FULLMSG */
"DISK FULL!  Write file with a new name to another diskette. [Press any key]",

/* MENUSPMSG */
"Out of menu space.  Reduce the size of your menus.\r\n",

/* NOSPACEMSG */
"Cannot allocate enough memory for this feature. [Press any key to continue]",

/* LOWSPACEMSG */
"Editing space is low. Save files immediately. [Press any key to continue]",

/* OUTOFWINDOWS */
"Out of window structures [Press any key to continue]",

/* NOBUFFERMEMORY */
"NOT ENOUGH MEMORY! (%u bytes short) Use fewer buffers\r\n",

/* OUTOFFILESTRUCT */
"openFile: out of file structures",

/* CANNOTOPEN */
"Cannot open %s",

/* READONLYFILE */
"File �%s� is read only",

/* WRITINGFILE */
"Writing file �%s� [%ld characters]...",

/* CLOSEFAILED */
"saveFile: close of �%s� failed, ret=%d",

/* RENAMEFAILED */
"Rename of backup of �%s� to �%s� failed, new version in �%s�",

/* DELETEFAILED */
"Delete of old version of �%s� failed; new version in �%s�",

/* RENAMEFAILED2 */
"Rename of �%s�[new version] to �%s�[old version] failed",

/* WRITECANCELLED */
"Write file cancelled",

/* FILEEXISTS */
"File �%s� exists, write over it? (y/n)",

/* XXXXXXXXX */
"",

/* FILEWRITTEN */
"File �%s� written...%ld characters",

/* WRITEFAILED */
"Target disk door open or read-only [Press any key to continue]",

/* CREATEFAILED */
"Could not create �%s�, ret=%d [Press any key to continue]",

/* WRITEPROGRESS */
"File is %d%% written out",

/* WASREADONLY */
"(Esc:cancel, other:no write) �%s� is read only but changed",

/* YTOSAVE */
"y to save �%s�, n to discard edits: ",

/* CLOSECANCELLED */
"Window close and file write cancelled",

/* NOTOPEN */
"closeFile: file �%s� is not open",

/* CLOSEFAILED2 */
"closeFile: close of �%s� failed, ret=%d",

/* REANMEFAILED2 */
"Rename of �%s� to �%s� failed, new version in �%s�",

/* DELETEFAILED2 */
"Delete of �%s� failed; new version in �%s�",

/* RENAMEFAILED3 */
"Rename of �%s�[new version] to �%s�[old version] failed",

}; /* end of USER MESSAGES */

