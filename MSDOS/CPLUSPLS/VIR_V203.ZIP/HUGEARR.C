#include "stdlib.h"
#include "alloc.h"
#include "..\lib\virimg.h"



#define hugh_array(x) *((char *)large_array(x>>16,x&65535))

#define SZ 983040

void main()
{
	long i,j,l;
	initialise_virtual_arrays(3,65536,16,XXMS);
	printf ("Array size %ld chars\n",SZ);
	printf ("Memory still available %ld\n",coreleft());
	printf ("Press a key to check arrays\n");
	getch();

	start_timer();
	printf ("Filling hugh array\n");
	for (i=0;i<SZ;i++)
		hugh_array(i)=(char)i;
	printf ("Checking hugh array\n");
	for (i=0;i<SZ;i++)
		if (hugh_array(i)!=(char)i) goto ERR;
	printf ("hugh array ok\n");
	stop_timer();
	exit(1);
ERR:
	printf ("Error in hugh array");
}
