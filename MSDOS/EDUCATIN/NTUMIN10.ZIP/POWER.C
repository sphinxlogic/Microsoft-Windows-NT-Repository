/******************************************************************************
 *
 *	Program Name : POWER.C
 *
 *	Written By : Eng-Huat Ong and Kian-Mong Low.
 *
 *	This program computes the value 2 raise to the power of n, where
 *	n is the number of variables.
 *
 *	Returns  2 raise to power n
 *
 * --------------------------------------------------------------------------
 *	Copyright (c) 1992. All Rights Reserved. Nanyang Technological
 *	University.
 *
 *	You are free to use, copy and distribute this software and its
 *	documentation providing that:
 *
 *		NO FEE IS CHARGED FOR USE, COPYING OR DISTRIBUTION.
 *
 *		IT IS NOT MODIFIED IN ANY WAY.
 *
 *		THE COPYRIGHT NOTICE APPEAR IN ALL COPIES.
 *
 *	This program is provided "AS IS" without any warranty, expressed or
 *	implied, including but not limited to fitness for any particular
 *	purpose.
 *
 *	If you find NTUMIN fast, easy, and useful, a note or comment would be
 *	appreciated. Please send to:
 *
 *		Boon-Tiong Tan or Othman Bin Ahmad
 *		School of EEE
 *		Nanyang Technological University
 *		Nanyang Avenue
 *		Singapore 2263
 *		Republic of Singapore
 *
 ******************************************************************************/

unsigned long  topow(n)

unsigned char n;                          /* exponent */

{
   unsigned long  x=1, p;                 /* counters */

   for ( p=1; p<=n; p++)                  /* do n times */
      x = x*2;

   return (x);                            /* return 2 raise to power n */
}

