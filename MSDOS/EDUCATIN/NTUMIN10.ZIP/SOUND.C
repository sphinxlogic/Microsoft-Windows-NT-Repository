#include <dos.h>

void    errsound()

{
   sound(262);
   delay(100);
   sound(131);
   delay(200);
   nosound();
}