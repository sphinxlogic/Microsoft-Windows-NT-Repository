/*bui*/
/*ver 1.1 fix the \M \V bug, thanks to hoa */
#include <stdio.h>;

main(argc,argv)
int argc; char *argv[];
{
 FILE *infile; int argno;
 int initial_mode = 1; int find_file = 0;
   for (argno = 1; argno < argc; argno++) {
      if (strcmp(argv[argno],"-M")==0) {initial_mode = 0; continue;}
      if (strcmp(argv[argno],"-m")==0) {initial_mode = 0; continue;}
      if (strcmp(argv[argno],"-V")==0) {initial_mode = 1; continue;}
      if (strcmp(argv[argno],"-v")==0) {initial_mode = 1; continue;}
      if (strcmp(argv[argno],"-L")==0) {initial_mode = 2; continue;}
      if (strcmp(argv[argno],"-l")==0) {initial_mode = 2; continue;}
      if (!find_file) find_file = 1;
      if ((infile = fopen(argv[argno], "r")) == NULL)
      { fprintf(stderr, "%s: Can't open '%s' for input.\n",
        argv[0],argv[argno]);
      }
      else
      { sevento8(infile,initial_mode);
        fclose(infile);
      }
  }/*for*/
  if (!find_file) sevento8(stdin,initial_mode);
} 


sevento8(file,initial_mode)
FILE *file;
int initial_mode;
{
  int c, oldc, cc=0;
  int compose_state=0;
  int vi_mode;
		vi_mode = initial_mode;
		while (1)
                { 
                  if (cc==-2)  cc=0;
                  else 
                      if((c=getc(file)) == EOF) {
                        if (compose_state) printf("%c",oldc);
                        fflush(stdout);break;}

                  if ((vi_mode == 1) && (c=='A' || c=='a' || c=='D'
                      ||c=='d' || c=='E' || c=='e' || c=='O' 
                      ||c=='o' || c=='I' || c=='i' || c=='U'
                      ||c=='u' || c=='Y' || c=='y') )
			if (compose_state==0) compose_state =1; 
                  if (compose_state>=1) { 
                    cc = get_compose(compose_state++,c,&oldc,&vi_mode);
                    if (cc !=  0) compose_state=0;
                    if (cc <  -1) printf("%c",oldc);
                    if (cc >   0) printf("%c",cc);
                  } else if (c == '\\' ) {
                          compose_state=1;
                         }
                         else printf("%c",c);
                } /*while*/
}
