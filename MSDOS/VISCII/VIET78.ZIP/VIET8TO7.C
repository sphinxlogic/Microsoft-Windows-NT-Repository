#include <stdio.h>
main(argc,argv)
int argc; char *argv[];
{
 FILE *infile; int argno;
  if (argc < 2)
    eightto7(stdin);
  else
    for (argno = 1; argno < argc; argno++)
      if ((infile = fopen(argv[argno], "r")) == NULL)
      { fprintf(stderr, "%s: Can't open '%s' for input.\n",
        argv[0], argv[argno]);
      }
      else
      { eightto7(infile);
        fclose(infile);
      }
}


eightto7(file)
FILE *file;
{
char buffer[10];
int i,c,slash,oldc,inc;
  printf("\\V");
  oldc = 0;
  while ((inc=getc(file))!=EOF)
   {
       decompose(inc,oldc,buffer); 
       for (i=0 ;i<3;i++)
           if (buffer[i] == 0 ) break;
           else putc((char)buffer[i],stdout);
       oldc = inc;
   }/*while*/
  printf("\\L");
}
