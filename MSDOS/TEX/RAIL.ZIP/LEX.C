# include "stdio.h"
# define U(x) x
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX BUFSIZ
# define output(c) putc(c,yyout)
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
# define ECHO fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin = {stdin}, *yyout = {stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;

#include "rail.h"
#include "gram.h"

int lex_line;	/* current input line */
int copy;	/* copy to output flag */

#define	COPY	(copy && fputs(yytext,outf))

extern YYSTYPE yylval;

# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:
{
		COPY;
		yylval.id=lookup(yytext);
		return(IDENTIFIER);
}
case 2:
{
		COPY;
		yylval.num=atoi(yytext);
		return(NUMBER);
}
case 3:
{
		COPY;
		return(RAILI);
}
case 4:
{
		COPY;
		return(RAILP);
}
case 5:
{
		COPY;
		return(RAILT);
}
case 6:
	COPY;
break;
case 7:
{		COPY;
		return(RAILCR);
}
case 8:
{
		COPY;
		return(CS);
}
case 9:
{
		COPY;
		return(CS);
}
case 10:
{
		COPY;
		yytext[yyleng-1]='\0';
		yylval.text=mcheck(strdup(yytext+1));
		return(STRING);
}
case 11:
{
		COPY;
		yytext[yyleng-1]='\0';
		yylval.text=mcheck(strdup(yytext+1));
		return(ANNOT);
}
case 12:
{
		COPY;
		yytext[yyleng-1]='\0';
		yylval.text=mcheck(strdup(yytext+1));
		return(STRING);
}
case 13:
{
		COPY;
}
break;
case 14:
{
		COPY;
		lex_line++;
}
break;
case 15:
{
		COPY;
		return(yytext[0]);
}
case -1:
break;
default:
fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */
int yyvstop[] = {
0,

15,
0,

13,
15,
0,

14,
0,

15,
0,

15,
0,

2,
15,
0,

1,
15,
0,

15,
0,

15,
0,

13,
0,

12,
0,

10,
0,

2,
0,

1,
0,

11,
0,

9,
0,

8,
9,
0,

7,
9,
0,

8,
9,
0,

8,
9,
0,

8,
0,

8,
0,

8,
0,

6,
8,
0,

8,
0,

8,
0,

8,
0,

3,
8,
0,

4,
8,
0,

5,
8,
0,
0};
# define YYTYPE char
struct yywork { YYTYPE verify, advance; } yycrank[] = {
0,0,	0,0,	1,3,	0,0,	
0,0,	0,0,	0,0,	0,0,	
6,13,	0,0,	1,4,	1,5,	
7,15,	4,12,	0,0,	0,0,	
6,0,	6,0,	0,0,	0,0,	
7,0,	7,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	1,4,	0,0,	1,6,	
4,12,	13,0,	13,0,	6,13,	
1,7,	6,14,	0,0,	7,15,	
0,0,	7,15,	6,13,	1,3,	
0,0,	1,8,	7,16,	15,0,	
15,0,	6,13,	0,0,	6,13,	
0,0,	7,15,	0,0,	7,15,	
19,0,	19,0,	0,0,	0,0,	
0,0,	1,3,	1,9,	0,0,	
0,0,	0,0,	0,0,	6,13,	
6,13,	0,0,	0,0,	7,15,	
7,15,	8,17,	8,17,	8,17,	
8,17,	8,17,	8,17,	8,17,	
8,17,	8,17,	8,17,	0,0,	
0,0,	0,0,	31,32,	0,0,	
1,10,	1,11,	1,3,	0,0,	
1,9,	2,10,	2,11,	0,0,	
6,13,	0,0,	6,13,	0,0,	
7,15,	9,18,	7,15,	9,18,	
9,18,	9,18,	9,18,	9,18,	
9,18,	9,18,	9,18,	9,18,	
9,18,	0,0,	0,0,	0,0,	
24,27,	25,28,	0,0,	0,0,	
9,18,	9,18,	9,18,	9,18,	
9,18,	9,18,	9,18,	9,18,	
9,18,	9,18,	9,18,	9,18,	
9,18,	9,18,	9,18,	9,18,	
9,18,	9,18,	9,18,	9,18,	
9,18,	9,18,	9,18,	9,18,	
9,18,	9,18,	27,29,	28,30,	
30,31,	0,0,	9,18,	0,0,	
9,18,	9,18,	9,18,	9,18,	
9,18,	9,18,	9,18,	9,18,	
9,18,	9,18,	9,18,	9,18,	
9,18,	9,18,	9,18,	9,18,	
9,18,	9,18,	9,18,	9,18,	
9,18,	9,18,	9,18,	9,18,	
9,18,	9,18,	10,19,	0,0,	
0,0,	32,33,	11,21,	0,0,	
0,0,	0,0,	10,0,	10,0,	
32,34,	0,0,	11,0,	11,0,	
32,35,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	10,19,	0,0,	10,19,	
0,0,	11,0,	0,0,	11,21,	
10,19,	0,0,	0,0,	0,0,	
11,21,	0,0,	0,0,	10,19,	
0,0,	10,19,	0,0,	11,21,	
0,0,	11,21,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	10,19,	10,19,	0,0,	
0,0,	11,22,	11,22,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	10,20,	0,0,	
10,19,	11,23,	11,21,	0,0,	
11,21,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	11,24,	0,0,	11,25,	
22,26,	22,26,	22,26,	22,26,	
22,26,	22,26,	22,26,	22,26,	
22,26,	22,26,	22,26,	22,26,	
22,26,	22,26,	22,26,	22,26,	
22,26,	22,26,	22,26,	22,26,	
22,26,	22,26,	22,26,	22,26,	
22,26,	22,26,	22,26,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	22,26,	22,26,	22,26,	
22,26,	22,26,	22,26,	22,26,	
22,26,	22,26,	22,26,	22,26,	
22,26,	22,26,	22,26,	22,26,	
22,26,	22,26,	22,26,	22,26,	
22,26,	22,26,	22,26,	22,26,	
22,26,	22,26,	22,26,	0,0,	
0,0};
struct yysvf yysvec[] = {
0,	0,	0,
yycrank+-1,	0,		0,	
yycrank+-6,	yysvec+1,	0,	
yycrank+0,	0,		yyvstop+1,
yycrank+4,	0,		yyvstop+3,
yycrank+0,	0,		yyvstop+6,
yycrank+-7,	0,		yyvstop+8,
yycrank+-11,	0,		yyvstop+10,
yycrank+29,	0,		yyvstop+12,
yycrank+59,	0,		yyvstop+15,
yycrank+-181,	0,		yyvstop+18,
yycrank+-185,	0,		yyvstop+20,
yycrank+0,	yysvec+4,	yyvstop+22,
yycrank+-28,	yysvec+6,	0,	
yycrank+0,	0,		yyvstop+24,
yycrank+-42,	yysvec+7,	0,	
yycrank+0,	0,		yyvstop+26,
yycrank+0,	yysvec+8,	yyvstop+28,
yycrank+0,	yysvec+9,	yyvstop+30,
yycrank+-51,	yysvec+10,	0,	
yycrank+0,	0,		yyvstop+32,
yycrank+0,	0,		yyvstop+34,
yycrank+236,	0,		yyvstop+36,
yycrank+0,	0,		yyvstop+39,
yycrank+23,	yysvec+22,	yyvstop+42,
yycrank+24,	yysvec+22,	yyvstop+45,
yycrank+0,	yysvec+22,	yyvstop+48,
yycrank+36,	yysvec+22,	yyvstop+50,
yycrank+46,	yysvec+22,	yyvstop+52,
yycrank+0,	yysvec+22,	yyvstop+54,
yycrank+44,	yysvec+22,	yyvstop+57,
yycrank+26,	yysvec+22,	yyvstop+59,
yycrank+80,	yysvec+22,	yyvstop+61,
yycrank+0,	yysvec+22,	yyvstop+63,
yycrank+0,	yysvec+22,	yyvstop+66,
yycrank+0,	yysvec+22,	yyvstop+69,
0,	0,	0};
struct yywork *yytop = yycrank+358;
struct yysvf *yybgin = yysvec+1;
char yymatch[] = {
00  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,011 ,012 ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
040 ,01  ,'"' ,01  ,01  ,01  ,01  ,047 ,
01  ,01  ,01  ,01  ,01  ,01  ,'.' ,01  ,
'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,
'0' ,'0' ,01  ,01  ,01  ,01  ,01  ,01  ,
'@' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,01  ,01  ,']' ,01  ,'_' ,
01  ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,01  ,01  ,01  ,01  ,01  ,
0};
char yyextra[] = {
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
#ifndef lint
static	char ncform_sccsid[] = "@(#)ncform 1.6 88/02/08 SMI"; /* from S5R2 1.2 */
#endif

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
yylook(){
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych, yyfirst;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	yyfirst=1;
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank && !yyfirst){  /* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
			*yylastch++ = yych = input();
			yyfirst=0;
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
yyback(p, m)
	int *p;
{
if (p==0) return(0);
while (*p)
	{
	if (*p++ == m)
		return(1);
	}
return(0);
}
	/* the following are only used in the lex library */
yyinput(){
	return(input());
	}
yyoutput(c)
  int c; {
	output(c);
	}
yyunput(c)
   int c; {
	unput(c);
	}
