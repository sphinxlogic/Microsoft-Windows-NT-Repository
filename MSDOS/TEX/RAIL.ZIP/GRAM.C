extern char *malloc(), *realloc();

# line 4 "gram.y"

#include <stdio.h>

#include "rail.h"

char optchar;

# define IDENTIFIER 257
# define NUMBER 258
# define ANNOT 259
# define RAILI 260
# define RAILP 261
# define RAILT 262
# define RAILCR 263
# define CS 264
# define STRING 265
#define yyclearin yychar = -1
#define yyerrok yyerrflag = 0
extern int yychar;
extern int yyerrflag;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif
YYSTYPE yylval, yyval;
# define YYERRCODE 256

# line 223 "gram.y"


int yyexca[] ={
-1, 1,
	0, -1,
	-2, 0,
-1, 25,
	125, 43,
	59, 43,
	124, 43,
	-2, 0,
-1, 43,
	124, 43,
	-2, 17,
	};
# define YYNPROD 46
# define YYLAST 246
int yyact[]={

    39,    44,    50,    51,    23,    39,    22,     6,    46,    16,
    39,     3,     4,     5,    14,    39,    43,    64,    19,    39,
    39,    17,    47,    25,    13,    11,     9,    53,    33,    37,
    30,    27,    38,    60,    31,    36,    45,     2,    57,     7,
    20,    18,    15,    12,    10,     8,     1,    34,    35,    26,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,    48,     0,     0,     0,     0,     0,     0,     0,     0,
    52,     0,     0,     0,    54,    56,    59,    55,     0,     0,
    62,    62,    42,    61,    61,    63,    21,    66,    65,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    47,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,    46,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,    49,    24,     0,
     0,    28,    29,    41,    32,    40,     0,    49,    41,    32,
    40,     0,    49,    41,    58,    40,    49,    29,    41,    32,
    40,     0,    41,    41,    40,    40 };
int yypact[]={

  -249,  -249, -1000,   -97,   -98,   -99, -1000, -1000, -1000,  -244,
 -1000, -1000, -1000,  -248,  -104, -1000,  -107, -1000,   -39, -1000,
  -100, -1000, -1000, -1000, -1000,   -35,   -43, -1000, -1000,   -57,
 -1000,  -102,   -21, -1000,   -40, -1000, -1000, -1000,   -36,   -30,
  -251, -1000, -1000,   -20, -1000, -1000, -1000,   -25, -1000,  -251,
   -21,   -21, -1000, -1000,   -24, -1000, -1000,   -30,   -21, -1000,
 -1000, -1000, -1000, -1000, -1000, -1000, -1000 };
int yypgo[]={

     0,    31,    49,    30,    34,    28,    48,    47,    35,    33,
    32,    29,    36,    46,    37,    45,    44,    43,    42,    41,
    40,    38 };
int yyr1[]={

     0,    13,    13,    14,    14,    14,    14,    18,    16,    19,
    19,    19,    19,    17,    20,    15,     2,     2,     2,     2,
    21,     1,     1,     3,     4,     4,     4,     4,     5,     5,
     5,     6,     6,     7,     7,     8,     8,     9,     9,    10,
    10,    10,    10,    11,    12,    12 };
int yyr2[]={

     0,     4,     2,     4,     4,     4,     2,     1,     9,     0,
     5,     5,     5,     7,     1,    15,     7,     5,     2,     3,
     1,     9,     3,     3,     9,     7,     5,     2,     7,     7,
     2,     2,     2,     5,     2,     5,     2,     2,     2,     7,
     5,     5,     3,     1,     3,     1 };
int yychk[]={

 -1000,   -13,   -14,   260,   261,   262,   256,   -14,   -15,   123,
   -16,   123,   -17,   123,   258,   -18,   257,   125,   -19,   125,
   -20,   125,    45,    43,   257,   123,    -2,    -1,   256,   257,
    -3,    -4,   259,    -5,    -7,    -6,    -8,   -11,   -10,    40,
   265,   263,   125,    59,    58,   -12,   259,   124,    -5,   257,
    42,    43,    -8,    63,    -4,   -12,    -1,   -21,   259,    -5,
    -9,   -10,   -11,    -9,    41,    -3,    -5 };
int yydef[]={

     0,    -2,     2,     0,     0,     0,     6,     1,     3,     0,
     4,     7,     5,     0,     0,     9,     0,    14,     0,    13,
     0,     8,    10,    11,    12,    -2,     0,    18,    19,    45,
    22,    23,    43,    27,    31,    30,    34,    32,    36,    43,
    45,    42,    15,    -2,    20,    41,    44,    43,    26,    45,
    43,    43,    33,    35,     0,    40,    16,    43,    43,    25,
    28,    37,    38,    29,    39,    21,    24 };
typedef struct { char *t_name; int t_val; } yytoktype;
#ifndef YYDEBUG
#	define YYDEBUG	0	/* don't allow debugging */
#endif

#if YYDEBUG

yytoktype yytoks[] =
{
	"IDENTIFIER",	257,
	"NUMBER",	258,
	"ANNOT",	259,
	"RAILI",	260,
	"RAILP",	261,
	"RAILT",	262,
	"RAILCR",	263,
	"CS",	264,
	"STRING",	265,
	"-unknown-",	-1	/* ends search */
};

char * yyreds[] =
{
	"-no such reduction-",
	"rails : rails rail",
	"rails : rail",
	"rail : RAILI raili",
	"rail : RAILP railp",
	"rail : RAILT railt",
	"rail : error",
	"railp : '{'",
	"railp : '{' options '}'",
	"options : /* empty */",
	"options : options '-'",
	"options : options '+'",
	"options : options IDENTIFIER",
	"railt : '{' IDENTIFIER '}'",
	"raili : '{' NUMBER '}'",
	"raili : '{' NUMBER '}' '{' rules '}'",
	"rules : rules ';' rule",
	"rules : rules ';'",
	"rules : rule",
	"rules : error",
	"rule : IDENTIFIER ':'",
	"rule : IDENTIFIER ':' body",
	"rule : body",
	"body : body0",
	"body0 : body0 '|' ANNOT body1",
	"body0 : body0 '|' body1",
	"body0 : ANNOT body1",
	"body0 : body1",
	"body1 : body2 '*' body4e",
	"body1 : body2 '+' body4e",
	"body1 : body2e",
	"body2e : body2",
	"body2e : empty",
	"body2 : body2 body3",
	"body2 : body3",
	"body3 : body4 '?'",
	"body3 : body4",
	"body4e : body4",
	"body4e : empty",
	"body4 : '(' body0 ')'",
	"body4 : STRING annot",
	"body4 : IDENTIFIER annot",
	"body4 : RAILCR",
	"empty : /* empty */",
	"annot : ANNOT",
	"annot : /* empty */",
};
#endif /* YYDEBUG */
#line 1 "/usr/lib/yaccpar"
/*	@(#)yaccpar 1.10 89/04/04 SMI; from S5R3 1.10	*/

/*
** Skeleton parser driver for yacc output
*/

/*
** yacc user known macros and defines
*/
#define YYERROR		goto yyerrlab
#define YYACCEPT	{ free(yys); free(yyv); return(0); }
#define YYABORT		{ free(yys); free(yyv); return(1); }
#define YYBACKUP( newtoken, newvalue )\
{\
	if ( yychar >= 0 || ( yyr2[ yytmp ] >> 1 ) != 1 )\
	{\
		yyerror( "syntax error - cannot backup" );\
		goto yyerrlab;\
	}\
	yychar = newtoken;\
	yystate = *yyps;\
	yylval = newvalue;\
	goto yynewstate;\
}
#define YYRECOVERING()	(!!yyerrflag)
#ifndef YYDEBUG
#	define YYDEBUG	1	/* make debugging available */
#endif

/*
** user known globals
*/
int yydebug;			/* set to 1 to get debugging */

/*
** driver internal defines
*/
#define YYFLAG		(-1000)

/*
** static variables used by the parser
*/
static YYSTYPE *yyv;			/* value stack */
static int *yys;			/* state stack */

static YYSTYPE *yypv;			/* top of value stack */
static int *yyps;			/* top of state stack */

static int yystate;			/* current state */
static int yytmp;			/* extra var (lasts between blocks) */

int yynerrs;			/* number of errors */

int yyerrflag;			/* error recovery flag */
int yychar;			/* current input token number */

/* register YYSTYPE *yypvt = 0;	/* top of value stack for $vars */

/*
** yyparse - return 0 if worked, 1 if syntax error not recovered from
*/
int
yyparse()
{
	register YYSTYPE *yypvt = 0;	/**/
	unsigned yymaxdepth = YYMAXDEPTH;

	/*
	** Initialize externals - yyparse may be called more than once
	*/
	yyv = (YYSTYPE*)malloc(yymaxdepth*sizeof(YYSTYPE));
	yys = (int*)malloc(yymaxdepth*sizeof(int));
	if (!yyv || !yys)
	{
		yyerror( "out of memory" );
		return(1);
	}
	yypv = &yyv[-1];
	yyps = &yys[-1];
	yystate = 0;
	yytmp = 0;
	yynerrs = 0;
	yyerrflag = 0;
	yychar = -1;

	goto yystack;
	yynewstate:
	{
		register YYSTYPE *yy_pv;	/* top of value stack */
		register int *yy_ps;		/* top of state stack */
		register int yy_state;		/* current state */
		register int  yy_n;		/* internal state number info */

		/*
		** get globals into registers.
		** branch to here only if YYBACKUP was called.
		*/
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;
		goto yy_newstate;

		/*
		** get globals into registers.
		** either we just started, or we just finished a reduction
		*/
	yystack:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;

		/*
		** top of for (;;) loop while no reductions done
		*/
	yy_stack:
		/*
		** put a state and value onto the stacks
		*/
#if YYDEBUG
		/*
		** if debugging, look up token value in list of value vs.
		** name pairs.  0 and negative (-1) are special values.
		** Note: linear search is used since time is not a real
		** consideration while debugging.
		*/
		if ( yydebug )
		{
			register int yy_i;

			(void)printf( "State %d, token ", yy_state );
			if ( yychar == 0 )
				(void)printf( "end-of-file\n" );
			else if ( yychar < 0 )
				(void)printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				(void)printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ++yy_ps >= &yys[ yymaxdepth ] )	/* room on stack? */
		{
			/*
			** reallocate and recover.  Note that pointers
			** have to be reset, or bad things will happen
			*/
			int yyps_index = (yy_ps - yys);
			int yypv_index = (yy_pv - yyv);
			int yypvt_index = (yypvt - yyv);
			yymaxdepth += YYMAXDEPTH;
			yyv = (YYSTYPE*)realloc((char*)yyv,
				yymaxdepth * sizeof(YYSTYPE));
			yys = (int*)realloc((char*)yys,
				yymaxdepth * sizeof(int));
			if (!yyv || !yys)
			{
				yyerror( "yacc stack overflow" );
				return(1);
			}
			yy_ps = yys + yyps_index;
			yy_pv = yyv + yypv_index;
			yypvt = yyv + yypvt_index;
		}
		*yy_ps = yy_state;
		*++yy_pv = yyval;

		/*
		** we have a new state - find out what to do
		*/
	yy_newstate:
		if ( ( yy_n = yypact[ yy_state ] ) <= YYFLAG )
			goto yydefault;		/* simple state */
#if YYDEBUG
		/*
		** if debugging, need to mark whether new token grabbed
		*/
		yytmp = yychar < 0;
#endif
		if ( ( yychar < 0 ) && ( ( yychar = yylex() ) < 0 ) )
			yychar = 0;		/* reached EOF */
#if YYDEBUG
		if ( yydebug && yytmp )
		{
			register int yy_i;

			(void)printf( "Received token " );
			if ( yychar == 0 )
				(void)printf( "end-of-file\n" );
			else if ( yychar < 0 )
				(void)printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				(void)printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ( ( yy_n += yychar ) < 0 ) || ( yy_n >= YYLAST ) )
			goto yydefault;
		if ( yychk[ yy_n = yyact[ yy_n ] ] == yychar )	/*valid shift*/
		{
			yychar = -1;
			yyval = yylval;
			yy_state = yy_n;
			if ( yyerrflag > 0 )
				yyerrflag--;
			goto yy_stack;
		}

	yydefault:
		if ( ( yy_n = yydef[ yy_state ] ) == -2 )
		{
#if YYDEBUG
			yytmp = yychar < 0;
#endif
			if ( ( yychar < 0 ) && ( ( yychar = yylex() ) < 0 ) )
				yychar = 0;		/* reached EOF */
#if YYDEBUG
			if ( yydebug && yytmp )
			{
				register int yy_i;

				(void)printf( "Received token " );
				if ( yychar == 0 )
					(void)printf( "end-of-file\n" );
				else if ( yychar < 0 )
					(void)printf( "-none-\n" );
				else
				{
					for ( yy_i = 0;
						yytoks[yy_i].t_val >= 0;
						yy_i++ )
					{
						if ( yytoks[yy_i].t_val
							== yychar )
						{
							break;
						}
					}
					(void)printf( "%s\n", yytoks[yy_i].t_name );
				}
			}
#endif /* YYDEBUG */
			/*
			** look through exception table
			*/
			{
				register int *yyxi = yyexca;

				while ( ( *yyxi != -1 ) ||
					( yyxi[1] != yy_state ) )
				{
					yyxi += 2;
				}
				while ( ( *(yyxi += 2) >= 0 ) &&
					( *yyxi != yychar ) )
					;
				if ( ( yy_n = yyxi[1] ) < 0 )
					YYACCEPT;
			}
		}

		/*
		** check for syntax error
		*/
		if ( yy_n == 0 )	/* have an error */
		{
			/* no worry about speed here! */
			switch ( yyerrflag )
			{
			case 0:		/* new error */
				yyerror( "syntax error" );
				goto skip_init;
			yyerrlab:
				/*
				** get globals into registers.
				** we have a user generated syntax type error
				*/
				yy_pv = yypv;
				yy_ps = yyps;
				yy_state = yystate;
				yynerrs++;
			skip_init:
			case 1:
			case 2:		/* incompletely recovered error */
					/* try again... */
				yyerrflag = 3;
				/*
				** find state where "error" is a legal
				** shift action
				*/
				while ( yy_ps >= yys )
				{
					yy_n = yypact[ *yy_ps ] + YYERRCODE;
					if ( yy_n >= 0 && yy_n < YYLAST &&
						yychk[yyact[yy_n]] == YYERRCODE)					{
						/*
						** simulate shift of "error"
						*/
						yy_state = yyact[ yy_n ];
						goto yy_stack;
					}
					/*
					** current state has no shift on
					** "error", pop stack
					*/
#if YYDEBUG
#	define _POP_ "Error recovery pops state %d, uncovers state %d\n"
					if ( yydebug )
						(void)printf( _POP_, *yy_ps,
							yy_ps[-1] );
#	undef _POP_
#endif
					yy_ps--;
					yy_pv--;
				}
				/*
				** there is no state on stack with "error" as
				** a valid shift.  give up.
				*/
				YYABORT;
			case 3:		/* no shift yet; eat a token */
#if YYDEBUG
				/*
				** if debugging, look up token in list of
				** pairs.  0 and negative shouldn't occur,
				** but since timing doesn't matter when
				** debugging, it doesn't hurt to leave the
				** tests here.
				*/
				if ( yydebug )
				{
					register int yy_i;

					(void)printf( "Error recovery discards " );
					if ( yychar == 0 )
						(void)printf( "token end-of-file\n" );
					else if ( yychar < 0 )
						(void)printf( "token -none-\n" );
					else
					{
						for ( yy_i = 0;
							yytoks[yy_i].t_val >= 0;
							yy_i++ )
						{
							if ( yytoks[yy_i].t_val
								== yychar )
							{
								break;
							}
						}
						(void)printf( "token %s\n",
							yytoks[yy_i].t_name );
					}
				}
#endif /* YYDEBUG */
				if ( yychar == 0 )	/* reached EOF. quit */
					YYABORT;
				yychar = -1;
				goto yy_newstate;
			}
		}/* end if ( yy_n == 0 ) */
		/*
		** reduction by production yy_n
		** put stack tops, etc. so things right after switch
		*/
#if YYDEBUG
		/*
		** if debugging, print the string that is the user's
		** specification of the reduction which is just about
		** to be done.
		*/
		if ( yydebug )
			(void)printf( "Reduce by (%d) \"%s\"\n",
				yy_n, yyreds[ yy_n ] );
#endif
		yytmp = yy_n;			/* value to switch over */
		yypvt = yy_pv;			/* $vars top of value stack */
		/*
		** Look in goto table for next state
		** Sorry about using yy_state here as temporary
		** register variable, but why not, if it works...
		** If yyr2[ yy_n ] doesn't have the low order bit
		** set, then there is no action to be done for
		** this reduction.  So, no saving & unsaving of
		** registers done.  The only difference between the
		** code just after the if and the body of the if is
		** the goto yy_stack in the body.  This way the test
		** can be made before the choice of what to do is needed.
		*/
		{
			/* length of production doubled with extra bit */
			register int yy_len = yyr2[ yy_n ];

			if ( !( yy_len & 01 ) )
			{
				yy_len >>= 1;
				yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
				yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
					*( yy_ps -= yy_len ) + 1;
				if ( yy_state >= YYLAST ||
					yychk[ yy_state =
					yyact[ yy_state ] ] != -yy_n )
				{
					yy_state = yyact[ yypgo[ yy_n ] ];
				}
				goto yy_stack;
			}
			yy_len >>= 1;
			yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
			yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
				*( yy_ps -= yy_len ) + 1;
			if ( yy_state >= YYLAST ||
				yychk[ yy_state = yyact[ yy_state ] ] != -yy_n )
			{
				yy_state = yyact[ yypgo[ yy_n ] ];
			}
		}
					/* save until reenter driver code */
		yystate = yy_state;
		yyps = yy_ps;
		yypv = yy_pv;
	}
	/*
	** code supplied by user is placed in this switch
	*/
	switch( yytmp )
	{
		
case 7:
# line 59 "gram.y"
{
			fprintf(outf,"\\rail@p {");
			copy=1;
			optchar = '-'; } break;
case 8:
# line 64 "gram.y"
{
			fprintf(outf,"\n");
			copy=0;
		} break;
case 10:
# line 72 "gram.y"
{ optchar = '-'; } break;
case 11:
# line 74 "gram.y"
{ optchar = '+'; } break;
case 12:
# line 76 "gram.y"
{
			if(setopt(optchar,yypvt[-0].id->name)==0)
				error("unknown option",(char *)NULL);

			if(yypvt[-0].id->kind==UNKNOWN)
				delete(yypvt[-0].id);
		} break;
case 13:
# line 86 "gram.y"
{
			if(yypvt[-1].id->kind==UNKNOWN || yypvt[-1].id->kind==TOKEN)
				yypvt[-1].id->kind=TERM;
			else
				redef(yypvt[-1].id);

			fprintf(outf,"\\rail@t {%s}\n",yypvt[-1].id->name);
		} break;
case 14:
# line 97 "gram.y"
{
			fprintf(outf,"\\rail@i {%d}",yypvt[-1].num);
			copy=1;
		} break;
case 15:
# line 102 "gram.y"
{	copy=0;
			fprintf(outf,"\n");
			fprintf(outf,"\\rail@o {%d}{\n",yypvt[-5].num);
			outrule(yypvt[-1].rule);	/* embedded action is $4 */
			freerule(yypvt[-1].rule);
			fprintf(outf,"}\n");
		} break;
case 16:
# line 112 "gram.y"
{ yyval.rule=addrule(yypvt[-2].rule,yypvt[-0].rule); } break;
case 17:
# line 114 "gram.y"
{ yyval.rule=yypvt[-1].rule; } break;
case 19:
# line 117 "gram.y"
{ yyval.rule=NULL; } break;
case 20:
# line 121 "gram.y"
{ errorid=yypvt[-1].id; } break;
case 21:
# line 123 "gram.y"
{
			if(yypvt[-3].id->kind==UNKNOWN || yypvt[-3].id->kind==TOKEN)
				yypvt[-3].id->kind=NTERM;
			else
				redef(yypvt[-3].id);

		 	yyval.rule=newrule(yypvt[-3].id,yypvt[-0].body);	/* embedded action is $3 */

			errorid=NULL;
		} break;
case 22:
# line 134 "gram.y"
{
			anonymous++;

			yyval.rule=newrule((IDTYPE *)NULL,yypvt[-0].body);
		} break;
case 23:
# line 142 "gram.y"
{ yyval.body=yypvt[-0].body; yyval.body->done=1; } break;
case 24:
# line 146 "gram.y"
{
			yyval.body=newbody(ANNOTE,NULLBODY,NULLBODY);
			yyval.body->text=yypvt[-1].text;
			yyval.body=addbody(CAT,yyval.body,yypvt[-0].body);
			yyval.body=addbody(BAR,yypvt[-3].body,yyval.body);
		} break;
case 25:
# line 153 "gram.y"
{ yyval.body=addbody(BAR,yypvt[-2].body,yypvt[-0].body); } break;
case 26:
# line 155 "gram.y"
{
			yyval.body=newbody(ANNOTE,NULLBODY,NULLBODY);
			yyval.body->text=yypvt[-1].text;
			yyval.body=addbody(CAT,yyval.body,yypvt[-0].body);
		} break;
case 28:
# line 164 "gram.y"
{
			if(altstar && isemptybody(yypvt[-0].body)) {
				yyval.body=newbody(EMPTY,NULLBODY,NULLBODY);
				yyval.body=addbody(PLUS,yyval.body,revbody(yypvt[-2].body));
			} else {
				yyval.body=newbody(EMPTY,NULLBODY,NULLBODY);
				yyval.body=addbody(BAR,yyval.body,addbody(PLUS,yypvt[-2].body,revbody(yypvt[-0].body)));
			}
		} break;
case 29:
# line 174 "gram.y"
{ yyval.body=newbody(PLUS,yypvt[-2].body,revbody(yypvt[-0].body)); } break;
case 33:
# line 181 "gram.y"
{ yyval.body=addbody(CAT,yypvt[-1].body,yypvt[-0].body); } break;
case 35:
# line 186 "gram.y"
{ yyval.body=addbody(BAR,newbody(EMPTY,NULLBODY,NULLBODY),yypvt[-1].body); } break;
case 39:
# line 193 "gram.y"
{ yyval.body=yypvt[-1].body; yyval.body->done=1; } break;
case 40:
# line 195 "gram.y"
{
			yyval.body=newbody(STRNG,NULLBODY,NULLBODY);
			yyval.body->annot=yypvt[-0].text;
			yyval.body->text=yypvt[-1].text;
		} break;
case 41:
# line 201 "gram.y"
{
			if(yypvt[-1].id->kind==UNKNOWN)
				yypvt[-1].id->kind=TOKEN;

			yyval.body=newbody(IDENT,NULLBODY,NULLBODY);
			yyval.body->annot=yypvt[-0].text;
			yyval.body->id=yypvt[-1].id;
		} break;
case 42:
# line 210 "gram.y"
{ yyval.body=newbody(CR,NULLBODY,NULLBODY); } break;
case 43:
# line 214 "gram.y"
{ yyval.body=newbody(EMPTY,NULLBODY,NULLBODY); } break;
case 44:
# line 218 "gram.y"
{ yyval.text=yypvt[-0].text; } break;
case 45:
# line 220 "gram.y"
{ yyval.text=NULL; } break;
	}
	goto yystack;		/* reset registers in driver code */
}
