/****************************************************************************/
/*                                                                          */
/*   This program shows that JMODEM will execute without crashing the       */
/*   system from a DOS Shell executed from any properly written BBS         */
/*   system or BBS window. This program allocates memory just like BBS      */
/*   systems do, it writes to the memory, then spawns JMODEM as a sub-      */
/*   process from a DOS Shell ( Microsoft C _system(); ). Then it returns   */
/*   and the parent process again writes to memory. The program then exits  */
/*   to DOS. There will ne NO errors and NO crashes.                        */
/****************************************************************************/

#include <stdio.h>           /* for _puts()   */
#include <stdlib.h>          /* for _system() */
#if defined (TURBOC)
    #include <alloc.h>
#else
    #include <malloc.h>          /* for _malloc() */
#endif

void main(void);


#define BYTES 32767

void main ()
{
    unsigned short i;
    unsigned char *memory;

    memory = (unsigned char *) malloc(BYTES);  /*  Get some memory (a lot)  */
    if (!memory)
    {
       puts ("Memory allocation failed!");
       return;
    }

    system ("CLS");
    puts ("I am writing to memory I own ...");

    for (i = 0; i< BYTES; i++)
        *memory++ = (unsigned char) i;        /* Write to the memory */

    puts ("Now I'll execute JMODEM ...");
    puts ("Type CTRL-BRK to exit from JMODEM (it will take 5 seconds)....");
    system("JMODEM S1 NUL");

    for (i = 0; i< BYTES; i++)
        *(--memory) = (unsigned char) i;    /* Write to the memory again */

    puts ("\nAs you can see, the system did not crash ....");
    free (memory);
}
