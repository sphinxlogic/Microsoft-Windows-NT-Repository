#! /bin/sh
# A shell script to convert tex.lpro to texc.lpro
#
# To use it, say
#       texc.script tex.lpro texc.lpro
#

rm $2

sed -n -e "/% begin code for uncompressed fonts only/,/% end code for uncompressed fonts only/s/^/% /" -e "/% here's the alternate code for unpacking compressed fonts/,/% end of code for unpacking compressed fonts/s/^% //" -e "w $2" $1
