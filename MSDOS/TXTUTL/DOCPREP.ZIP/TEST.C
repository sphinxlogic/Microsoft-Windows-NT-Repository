main()
{
int array[10];
printf("hello, world!");
putchar('\n');
}

t(>
{
"this isn't right!"
]
