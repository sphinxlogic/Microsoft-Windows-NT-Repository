#include <stdio.h>
#include <graphics.h>
#include "bgi.h"

BGIPREFACE BGIHeader;                           // Header stuff for the BGI
                                                // files created w/ BMP2BGI

extern void ShowBGI(FILE *, char far *VidBuf[5]);

extern _stklen=10240;

void main(int argc, char *argv[])
{
  int gd = DETECT, gm;                          // BGI initgraph vars
  FILE *f;                                      // BGI image file created w/ bmp2bgi.exe
  char far *VidBuf[5];                          // Structure to hold BGI image

                                                
                                                // Dopey, you forgot to tell me
                                                // what image file
  if (argc != 2)
  {
        printf("\a\nUSAGE: showbgi FILE.BGI");
        printf("\n\t where 'FILE.BGI' is the name of the BGI file");
        exit (1);
  }
                
  registerfarbgidriver(EGAVGA_driver_far);      // Initialize graphics
  initgraph(&gd, &gm, "");
                                                
  f = fopen(argv[1], "rb");                     // Open the BGI file

                                                
  fread(&BGIHeader,sizeof(BGIHeader), 1, f);    // Read in the BGI header
                                            
  ShowBGI(f,VidBuf);                            // Now display the image

  fclose(f);                                    // Close image file   
  getch();                                      // Wait for user to catch up
  closegraph();                                 // Shut down graphics mode

}

