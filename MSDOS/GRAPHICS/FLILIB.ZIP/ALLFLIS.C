/* allflis.c Play all the fli's in current directory once and exit. */

#include "aados.h"
#include "aafli.h"

main()
{
Fndata *fn;
int ivmode;
Errval err;

fn = dos_get_dta();
if (dos_first("*.FLI", DOS_ATTR_NORMAL))
	{
	ivmode = dos_get_vmode();
	dos_set_vmode(0x13);
	if (dos_get_vmode() == 0x13)
		{
		for (;;)
			{
			if (dos_key_is())
				{
				dos_key_in();
				break;
				}
			err = fli_once(fn->name);
			if (err < AA_SUCCESS)
				{
				puts(fli_error_message(err));
				}
			if (!dos_next())
				break;
			}
		dos_set_vmode(ivmode);
		}
	else
		{
		puts("Not a VGA/MCGA display");
		}
	}
else
	{
	puts("No .FLI files");
	}
}

