
i86_ptr_seg(int offset, int segment)
{
return(segment);
}

i86_ptr_offset(int offset, int segment)
{
return(offset);
}
