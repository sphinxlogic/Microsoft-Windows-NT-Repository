
#include "jlib.h"

/* Delete a file if possible.  Don't complain if it's not there. */
Boolean dos_delete (title)
char *title;
{
union i86_regs reg;

reg.b.ah = 0x41;
reg.w.dx = i86_ptr_offset(title);
reg.w.ds = i86_ptr_seg(title);
if (i86_sysint(0x21,&reg,&reg)&1)
	return(0);
return(1);
}

