
#include "jlib.h"


/* Open a file that already exists */
Jfile dos_open (title, mode)
char *title;
int mode;
{
union i86_regs reg;

reg.b.ah = 0x3d;	/* open file */
reg.b.al = mode;		/* read/write etc... */
reg.w.dx = i86_ptr_offset(title);
reg.w.ds = i86_ptr_seg(title);
if (i86_sysint(0x21,&reg,&reg)&1)	/* check carry */
	return(0);
else
	return(reg.w.ax);
}

