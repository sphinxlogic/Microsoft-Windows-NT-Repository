
#include "aai86.h"
#include "aados.h"
#include <ctype.h>

/* Hey dos - I want to go to this directory.  Actually this changes
   both device and directory at once.  eg name could be
   		C:\VPAINT\FISHIES  */
Boolean dos_change_dir(char *name)
{
union i86_regs r;
int d,od;

od = dos_get_dev ();
if (!name[0])
	return(1);
if (name[1] == ':')	/* got a device... */
	{
	d = name[0];
	if (islower(d))
		d = _toupper(d);
	d -= 'A';
	if (!dos_valid_device(d))
		return(0);
	if (!dos_change_dev(d))
		return(0);
	name += 2;
	}
if (!name[0])
	return(1);
r.b.ah = 0x3B;	/* change current directory function */
r.w.dx = i86_ptr_offset(name);
r.w.ds = i86_ptr_seg(name);
if (i86_sysint(0x21,&r,&r)&1)	/* check carry flag for error... */
	{
	dos_change_dev(od);	/* change to old device if directory doesn't exist */
	return(0);
	}
return(1);
}


