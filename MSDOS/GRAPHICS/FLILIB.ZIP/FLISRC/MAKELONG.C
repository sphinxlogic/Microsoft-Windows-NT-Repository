
i86_make_long(long l)
{
return(l);
}
