
#include "aatypes.h"
#include "aai86.h"

Boolean dos_del_dir(char *name)
{
union i86_regs r;

r.w.dx = i86_ptr_offset(name);
r.w.ds = i86_ptr_seg(name);
r.b.ah = 0x3a;
if (i86_sysint(0x21, &r, &r) & 1)
	return(FALSE);
else
	return(TRUE);
}

