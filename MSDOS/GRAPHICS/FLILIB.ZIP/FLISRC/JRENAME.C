
#include "jlib.h"

/* Rename a file */
Boolean dos_rename (oldname, newname)
char *oldname, *newname;
{
union i86_regs reg;

reg.b.ah = 0x56;
reg.w.dx = i86_ptr_offset(oldname);
reg.w.ds = i86_ptr_seg(oldname);
reg.w.di = i86_ptr_offset(newname);
reg.w.es = i86_ptr_seg(newname);
if (i86_sysint(0x21,&reg,&reg)&1)
	return(0);
return(1);
}

