
#include "aai86.h"
#include "aados.h"

/* Get the current device and directory into path */
Boolean dos_get_dir (char path[DOS_PATH_SIZE])
{
union i86_regs reg;
char buf[DOS_PATH_SIZE];
int d;

if ((d = dos_get_dev ()) < 0)
	return(FALSE);
reg.b.ah = 0x47;
reg.b.dl = 0;	/* default device ... */
reg.b.si = i86_ptr_offset(buf);
reg.b.ds = i86_ptr_seg(buf);
if (i86_sysint(0x21, &reg, &reg)&1)	/* check carry for error */
	return(FALSE);
sprintf(path,"%c:\\%s", d+'A', buf);
return(TRUE);
}

