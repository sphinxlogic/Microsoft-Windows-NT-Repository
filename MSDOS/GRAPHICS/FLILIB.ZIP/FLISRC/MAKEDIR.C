
#include "aai86.h"
#include "aados.h"

/* Create a directory.  (Don't include device info.  If needed
   do a dos_change_dev(dev) first.) */
Boolean dos_make_dir(char *name)
{
union i86_regs r;

r.b.ah = 0x39;	/* make dir code */
r.w.ds = i86_ptr_seg(name);
r.w.dx = i86_ptr_offset(name);
if (i86_sysint(0x21,&r,&r)&1)	/* check carry flag for error... */
	return(FALSE);
return(TRUE);
}

