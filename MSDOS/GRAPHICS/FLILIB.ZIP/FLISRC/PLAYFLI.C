
#include "aafli.h"

Boolean fli_until_key(int cur_frame, int frame_count, int cur_loop)
{
if (dos_key_is())
	{
	dos_key_in();
	return(FALSE);
	}
else
	return(TRUE);
}

/* Play fli looping forever until any key is hit */
Errval fli_play(char *fliname)
{
return(fli_until(fliname, -1, fli_until_key));
}

