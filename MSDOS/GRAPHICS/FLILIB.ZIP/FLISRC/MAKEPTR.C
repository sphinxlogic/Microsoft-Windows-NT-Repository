
/* just fool compiler into treating offset/seg as a pointer */

void *i86_make_ptr(void *p)
{
return(p);
}

