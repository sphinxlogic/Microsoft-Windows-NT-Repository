
#include "jlib.h"

/* Does file exist? */
Boolean dos_exists (title)
char *title;
{
int f;

if ((f = dos_open (title, DOS_READ_ONLY))!=0)
	{
	dos_close (f);
	return(1);
	}
return(0);
}

