#include <stdio.h>
#include <stdlib.h>
#include "timer.h"

unsigned long sleep();
main (int argc, char ** argv)
	{
	long pause;
	unsigned long time;

	if (argc < 2)
		{
		fprintf (stderr, "Usage: sleep <time in milliseconds>\n");
		exit (0);
		}

	pause = atol (argv[1]);
	time = sleep (pause);
	printf ("%ld\n", time);
	}

unsigned long sleep (long pause)
	{
	long start, stop;
	unsigned long time;
	
	initializetimer ();
	start = readtimer();
	time = 0.0;
	while (elapsedtime (start, stop = readtimer()) < pause)
		;
	restoretimer();
	time = elapsedtime (start, stop);
	return (time);
	}
