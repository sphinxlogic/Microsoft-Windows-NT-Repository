#include	<stdio.h>
#include	<dos.h>
#include	<conio.h>
#include	"timer.h"

void main()
{
	unsigned long	start_time;
	unsigned long	stop_time;
	int i;
	double	time;

	initializetimer();

	start_time=readtimer();
	stop_time=readtimer();
	printf("start_time: %lX\n stop_time: %lX\n",
		start_time,stop_time);
	time = elapsedtime(start_time, stop_time);
	printf("time between successive calls: %f s  (%f ms)\n",
		time/1000.0, time);

	i = 1;
	start_time = readtimer();
	while ( (stop_time = readtimer()) == start_time)
		i++;
	printf("start_time: %lX\n stop_time: %lX\n",
		start_time,stop_time);
	time = elapsedtime(start_time, stop_time);
	printf("nr successive calls: %i\n", i);

	start_time=readtimer();
	delay(2);
	stop_time=readtimer();
	printf("start_time: %lX\n stop_time: %lX\n",
		start_time,stop_time);
	time = elapsedtime(start_time, stop_time);
	printf("time of a 'delay(2)' call   : %f s  (%f ms)\n",
		time/1000.0, time);

	printf("time until you press a key...");
	start_time = readtimer();
	getch();
	stop_time = readtimer();
	time = elapsedtime(start_time, stop_time);
	printf("\b\b\b\b\b\b\b\b\bed a key: %f s  (%f ms)\n",
		time/1000.0, time);

	restoretimer();
}

