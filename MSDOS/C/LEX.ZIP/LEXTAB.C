/*
 * Created by IBM PC LEX from file "lex.lxi"
 *	- for use with standard I/O
 */

#include <stdio.h>
#include <lex.h>
#define LL16BIT int
extern int _lmovb();
extern struct lextab *_tabp;
extern int  yyline;
extern char *llend;
int lexval;
char lbuf[];

LL16BIT _Fletab[] =
   {
   -1, -1,
   };

#line 1

#define	LLTYPE1	char

LLTYPE1 _Nletab[] =
   {
   1,
   };

LLTYPE1 _Cletab[] =
   {
   -1,
   };

LLTYPE1 _Dletab[] =
   {
   1,
   };

LL16BIT _Bletab[] =
   {
   0, 0,
   };

struct lextab letab =	{
			1,		 
			_Dletab,	 
			_Nletab,	 
			_Cletab,	 
			_Bletab,	 
			0,		 
			_lmovb,		 
			_Fletab,	 
			_Aletab,	 

			NULL,   	 
			0,		 
			0,		 
			0,		 
			};

 
FILE *lexin;

llstin()
   {
   if(lexin == NULL)
      lexin = stdin;
   if(_tabp == NULL)
      lexswitch(&letab);
   }

