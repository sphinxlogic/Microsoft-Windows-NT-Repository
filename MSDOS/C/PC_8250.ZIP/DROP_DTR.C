/*
 *                              DROP_DTR.C
 *
 *                           Written for the
 *
 *                              Datalight
 *                           Microsoft V 5.x
 *                                TurboC
 *                                  &
 *                               Zortech
 *
 *                             C Compilers
 *
 *            Copyright (c) John Birchfield 1987, 1988, 1989
 */
#include <stdlib.h>
#include "dependnt.h"
#include "timer.h"
void dtnr (int);

main (int argc, char *argv [])
{
	if (argc > 1)
		dtnr (atoi (argv [1]));
	else
		dtnr (1);
}




/*----------------------------- dtnr () -----------------------------*/
/*
 *
 */
# define MCR              4  /* modem control register */
unsigned PORT_addr;
char     MCR_save  = 0;
void
dtnr (int channel)
{
	int Dos_address;
	unsigned i;
	Dos_address = (channel - 1) * 2;
	DELAY_init ();
	peekmem (0x40, Dos_address, PORT_addr);
	MCR_save = inbyte (PORT_addr+MCR);
	outbyte (PORT_addr+MCR, 0);
	DELAY_loop (1000);
	outbyte (PORT_addr+MCR, MCR_save);
}

