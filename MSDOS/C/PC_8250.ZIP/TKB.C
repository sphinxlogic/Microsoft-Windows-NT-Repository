/*
 *                                TKB.C
 *
 *                  Keyboard input test driver program
 */

#include <stdio.h>
#include "_kb.h"

#if (!defined (TRUE))
#	define TRUE  (1)
#	define FALSE (0)
#endif

main ()
{
    int     i;
    while (TRUE)
    {
        while ((i = _kb ()) == -1);
        if (i == 'q')
            break;
        printf ("_KB () = (%d) [%c]\n", i, i);
    }
}
