void emptyfunc(void)
	{
	}

void testfunc(void)
	{
	puts("Hello, world");
	}
