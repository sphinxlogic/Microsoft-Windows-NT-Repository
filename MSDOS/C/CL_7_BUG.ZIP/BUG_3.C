/*
  Test if intrisinic strlen with doesn't work
  This code works if errmesg isn't near.
 */

#include <stdio.h>
#include <malloc.h>

void print_name(int textnr,char * name,char * formname);
void pack_filename(char * to,char * from,int length);

#define ER(X) errmesg[(X)-3000]

int  s_width=80;
extern char ** near errmesg=0;

int main(int argc,char *argv[])
{
  errmesg=(char**) malloc(sizeof(char *)*200);
  errmesg[118]="Formul�r: %s";
  errmesg[123]="Register: %s  %s";

  puts("The following text should be: 'Register: reg(50)  Formul�r: form'");
  print_name(3123,"reg","form");
  puts("");
  return 0;
}

void print_name(int textnr,char * name,char * formname)
{
  unsigned int length;
  char buff2[81],b_name[81];

  sprintf(buff2,ER(3118),formname);
  length=strlen(buff2);
  sprintf(b_name,"%s(%d)",name,s_width-strlen(ER(textnr))-length);
  printf(ER(textnr),b_name,buff2);
  return;
} /* print_name */
