/* Test function that fails to compile */

#include <stdio.h>
#include <malloc.h>

#define PC_MALLOC 1024
#define PS_MALLOC 1024
#define ADD_TO_PTR(ptr,size,type) (type) ((long) (ptr)+size)
#define PTR_BYTE_DIFF(A,B) ((long) (A) - (long) (B))
#define MALLOC_OVERHEAD 32

typedef unsigned int uint;
typedef char * string;
typedef char byte;
typedef void * gptr;

typedef struct st_typelib {
  int count;
  char * *type_names;
} TYPELIB;

typedef struct st_pointer_array {		/* when using array-strings */
  TYPELIB typelib;				/* Pointer to strings */
  char	*str;					/* Strings is here */
  char	*flag;					/* Flag about each var. */
  int  array_allocs,max_count,length,max_length;
} POINTER_ARRAY;


int insert_pointer_name(pa,name)
register POINTER_ARRAY *pa;
string name;
{
  int i,length,old_count;
  byte *new_pos,**new_array;

  if (! pa->typelib.count)
  {
    if (!(pa->typelib.type_names=(string *)
	  malloc(((PC_MALLOC-MALLOC_OVERHEAD)/
		     (sizeof(string)+sizeof(*pa->flag))*
		     (sizeof(string)+sizeof(*pa->flag))))))
      return(-1);
    if (!(pa->str= (byte*) malloc(PS_MALLOC-MALLOC_OVERHEAD)))
    {
      free((gptr) pa->typelib.type_names);
      return (-1);
    }
    pa->max_count=(PC_MALLOC-MALLOC_OVERHEAD)/(sizeof(byte*)+
					       sizeof(*pa->flag));
    pa->flag= (char*) (pa->typelib.type_names+pa->max_count);
    pa->length=0;
    pa->max_length=PS_MALLOC-MALLOC_OVERHEAD;
    pa->array_allocs=1;
  }
  length=strlen(name)+1;
  if (pa->length+length >= pa->max_length)
  {
    if (!(new_pos= (byte*) realloc((gptr) pa->str,
				      (uint) (pa->max_length+PS_MALLOC))))
      return(1);
    if (new_pos != pa->str)
    {
      long diff= PTR_BYTE_DIFF(new_pos,pa->str);
      for (i=0 ; i < pa->typelib.count ; i++)
	pa->typelib.type_names[i]= ADD_TO_PTR(pa->typelib.type_names[i],diff,
					      char*);
      pa->str=new_pos;
    }
    pa->max_length+=PS_MALLOC;
  }
  if (pa->typelib.count >= pa->max_count-1)
  {
    int len;
    pa->array_allocs++;
    len=(PC_MALLOC*pa->array_allocs - MALLOC_OVERHEAD);
    if (!(new_array=(string*) realloc((gptr) pa->typelib.type_names,
					 (uint) len/
					 (sizeof(byte*)+sizeof(*pa->flag))*
					 (sizeof(byte*)+sizeof(*pa->flag)))))
      return(1);
    pa->typelib.type_names=new_array;
    old_count=pa->max_count;
    pa->max_count=len/(sizeof(byte*) + sizeof(*pa->flag));
    pa->flag= (char*) (pa->typelib.type_names+pa->max_count);
    memcpy((byte*) pa->flag,(string) (pa->typelib.type_names+old_count),
	   old_count*sizeof(*pa->flag));
  }
  pa->flag[pa->typelib.count]=0;			/* Reset flag */
  pa->typelib.type_names[pa->typelib.count++]= pa->str+pa->length;
  pa->typelib.type_names[pa->typelib.count]= 0;	/* Put end-mark */
  VOID(strmov(pa->str+pa->length,name));
  pa->length+=length;
  return(0);
} /* insert_pointer_name */
