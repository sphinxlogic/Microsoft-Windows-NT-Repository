/*
  Tests programs with #pragmas can't be compiled without /Oi switch.
  I like to put a pragma around some code for testing purposes.
  But now I can't compile without optimizing for example codeview
  without removing theese pragmas.
  The actual problem is because intrisinic strlen() can't be trusted,
  I'd like to put "#pragma function (strlen)" in my header file but I can't
  do it if I should want to sometimes compile without optimizing (to find
  more buggs).
 */

#include <stdio.h>

#pragma function (strlen)	/* This dosent work without /Oi */
#pragma intrinsic (strlen)	/* This dosent work without /Oi */

int main(int argc,char *argv[])
{
  puts("I am alive");
  return(0);
}
