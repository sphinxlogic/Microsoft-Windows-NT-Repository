/*
   This program shows how CL can't even handle a simple operation as *pos++=..
   without failing
*/   

#include <stdio.h>

#define MAX_SORT_ORDERS 16

typedef struct st_prt_var {			/* Info p} sista sk{rmen */
   char summaflag[MAX_SORT_ORDERS],repeat[1];
   int sidbyteflag,sidsumma,start_sum,w_page,w_empty,leftmarg,rep_reg,rep_field;
} PRT_VAR;

typedef struct st_predit_param {
  int		max_width;
  int		post_width;
  PRT_VAR	prtvar;				/* Inmatad form-info */
  char		*c_postfix;
} SCREENPARAM;

static void save_var(SCREENPARAM *s,char *forminfo);
static void get_number_or_field(char *repeat,int *rep_reg,int *rep_field);

int main(int argc,char *argv[])
{
  SCREENPARAM s;
  char forminfo[32];

  memset((char*) &forminfo,0,sizeof(forminfo));
  memset((char*) &s,0,sizeof(s));

	/* Fill structure with something */
  memset(s.prtvar.summaflag,'!',16);
  s.prtvar.sidbyteflag='W';
  s.prtvar.sidsumma='O';
  s.prtvar.start_sum='R';
  s.max_width='K';
  s.prtvar.w_page='S';
  s.post_width='!';
  s.prtvar.rep_reg=0;

  save_var(&s,forminfo);
  if (!strcmp(forminfo,"!!!!!!!!!!!!!!!!WORKS!"))
    puts("What a suprise, the function worked");
  else
    printf("This program doesn't work (forminfo= '%s')\n",forminfo);
  return 0;
}
   
static void save_var(s,forminfo)
register SCREENPARAM *s;
register char *forminfo;
{
  char *pos;
  PRT_VAR *prtvar;

  prtvar= &s->prtvar;
  get_number_or_field(prtvar->repeat,&prtvar->rep_reg,&prtvar->rep_field);
  pos=forminfo;
  memcpy(pos,prtvar->summaflag,MAX_SORT_ORDERS);
  pos+=16;
  *pos++= (char) prtvar->sidbyteflag;
  *pos++= (char) prtvar->sidsumma;
  *pos++= (char) prtvar->start_sum;
  *pos++= (char) s->max_width;
  *pos++= (char) prtvar->w_page;
  *pos++= (char) s->post_width;
  *pos++= (char) prtvar->rep_reg;
} /* save_var */

	/* This function is here to confuse CL-7.00 */

static void get_number_or_field(char *repeat,int *rep_reg,int *rep_field)
{
  return;
}
