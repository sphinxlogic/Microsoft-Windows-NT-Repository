/*
  Test if cl alias (?) bugg (there isn't any use of alias in this code)
  or double loop variable bugg (two loops, if the first is removed it works)
 */

#include <stdio.h>

typedef struct fileinfo		/* Struct returned from my_dir & my_stat */
{
  char			*name;
} FILEINFO;

typedef struct my_dir		/* Struct returned from my_dir */
{
  struct fileinfo	*dir_entry;
  int number_off_files;
} MY_DIR;

void test_file(FILEINFO *test);
int get_filename(MY_DIR *dir_info);

	/* This function breaks when compiling with
	   cl -Ox -AL.
	   Code breaks when using test_file() in loop 
	   (possibly alias test in cl) and the result
	   is a loop of garbage. (se bugg_1.cod)
	*/

int main(int argc,char *argv[])
{
  MY_DIR dir_info;
  FILEINFO fileinfo[3];

  fileinfo[0].name="ALLOC";
  fileinfo[1].name="ALLOCA";
  dir_info.dir_entry=fileinfo;
  dir_info.number_off_files=2;
  
  printf("get_filename returns: %d, Should return 5\n",
  	 get_filename(&dir_info));
  return(0);
}

	/* Expand inputed filename */

int get_filename(MY_DIR *dir_info)
{
  register int i;
  int  k_length;
  unsigned int count;
  char *part_name,*pos,*p_pos;
  struct fileinfo *best_info;

  part_name="A";
  count=0; k_length= 1000;

  for (i=0 ; i < dir_info->number_off_files ; i++)
    {
	/* If next for-loop and test is removed the code works */
      for (p_pos=part_name, pos=dir_info->dir_entry[i].name; *p_pos ;
	   pos++,p_pos++)
	if (*pos != *p_pos)
	  break;
      if (!*p_pos)
	{		/* In this example this is allways true */
	  if (count++)
	    {
	      register int j;
	      /* This loop will be garbage */
	      for (j=0 ; j < k_length ; j++)
		if (best_info->name[j] != dir_info->dir_entry[i].name[j])
		  break;
	      k_length=j;
	      /* end garbage */
	    }
	  else
	    {
	      best_info= &(dir_info->dir_entry[i]);
	      k_length= strlen(best_info->name);
	    }
	  /*  If the next row is removed the program works */
	  test_file(&dir_info->dir_entry[i]);
	}
    }

  return k_length;
}

void test_file(FILEINFO *test)
{
  return;
}

