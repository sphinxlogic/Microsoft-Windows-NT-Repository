#include <stdio.h>
main()
{
   int c;

   while ((c=getchar())!=EOF) 
      if (c!='\r' && c!='\032') putchar(c);
}
