/*******************************************************************
* BLANK.C - Call new command processor with a nearly blank 		*
*           environment.                                   		*
*                                                          		*
* To compile: cl BLANK.C                                   		*
*******************************************************************/

#include <stdlib.h>
#include <string.h>
#include <process.h>

void main(void)
	{
   int i,j;
	char *path, *tmp;

	/* Save the current path into variable "path"   */
	path = strdup(getenv("PATH")-strlen("PATH="));

	/* Delete all environment variables             */
	while (environ[0])
		{
		tmp = strdup(environ[0]);
		tmp[strchr(tmp,'=') - tmp + 1] = 0;
		putenv(tmp);
		free(tmp);
		}

	/* Set new PATH and PROMPT environment vars     */
	/* and run a new copy of the command processor  */
	putenv(path);
	putenv("PROMPT=Type EXIT to return > ");
	execlp("command", NULL);
	}
