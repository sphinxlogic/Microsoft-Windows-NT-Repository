#include <stdio.h>
#include <stdlib.h>

/* Return the name of the default target directory */

char	*tmpdir()
{
	static char retbuf[BUFSIZ];

	if (getenv("TMPDIR") == NULL)
	{
		/* Default current directory */
		strcpy (retbuf,".");
	}
	else
	{
		/* If TMPDIR is set use this as default */
		strcpy (retbuf,getenv("TMPDIR"));
	}
	return (retbuf);
}
