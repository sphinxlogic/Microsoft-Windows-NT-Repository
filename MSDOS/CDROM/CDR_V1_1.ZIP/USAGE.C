#include <stdio.h>


/* Print usage of program cdr */

void usage (void)

{
	fprintf (stderr,"-i index.txt             -> index file\n");
	fprintf (stderr,"-s regular expression    -> search for this regular expression \n");
	fprintf (stderr,"-n -s regular expression -> don't match this regular expression\n");
	fprintf (stderr,"-t target dir            -> directory to copy data to\n");
	fprintf (stderr,"-e file name to extract  -> filenames to extract needs -u option\n");
	fprintf (stderr,"-c                       -> copy data matched to target dir\n");
	fprintf (stderr,"-u                       -> unpack data to target dir\n");
	fprintf (stderr,"-d                       -> delete all files and sub directories in target dir\n");
	fprintf (stderr,"-r                       -> force wipe of whole disk or current directory\n");
	fprintf (stderr,"-o                       -> take all search options as an or function\n");
	fprintf (stderr,"-b                       -> use this to create batch files\n");
	fprintf (stderr,"-f                       -> use the file name only in search\n");
	fprintf (stderr,"-h                       -> help\n");
	fprintf (stderr,"-?                       -> help\n");
	fprintf (stderr,"\nEnvironment variables : \n");
	fprintf (stderr,"set CDROM=q:                       cdrom drive letter to use\n");
	fprintf (stderr,"set TMPDIR=e:\\tmp                  default target directory instead of .\n");
	fprintf (stderr,"set INDEX=c:\\simtel20\\index.txt    default index file\n");
	fprintf (stderr,"set UNZIP=c:\\util\\pkunzip -d       default for zip files\n");
	fprintf (stderr,"set UNARC=c:\\util\\pak x            default for arc files\n");
	fprintf (stderr,"set POST=e:\\tbav\\tbscan e:\\tmp     if defined execute command\n");
	fprintf (stderr,"                                   after unpacking or copying data\n");
}