#include <stdio.h>
#include <stdlib.h>

/* Return the default command for unzipping files */

char	*unzip()
{
	extern	char	*cdrom();

	static	char	retbuf[BUFSIZ];

	if (getenv("UNZIP") == NULL)
	{
		sprintf (retbuf,"%s\\pkunzip -d",cdrom());
	}
	else
	{
		sprintf (retbuf,"%s",getenv("UNZIP"));
	}

	return retbuf;
}

/* Returns the default command for unarcing files */

char	*unarc()
{
	extern	char	*cdrom();

	static	char	retbuf[BUFSIZ];

	if (getenv("UNARC") == NULL)
	{
		sprintf (retbuf,"%s\\pkunpak",cdrom());
	}
	else
	{
		sprintf (retbuf,"%s",getenv("UNARC"));
	}

	return retbuf;
}