#include <stdio.h>
#include <stdlib.h>

/* Returns the default index.txt file */

char	*getindex()
{
	extern	char* cdrom();

	static char retbuf[BUFSIZ];

	if (getenv("INDEX") == NULL)
	{
		sprintf (retbuf,"%s\\index.txt",cdrom());
	}
	else
	{
		sprintf (retbuf,"%s",getenv("INDEX"));
	}

	return (retbuf);

}
