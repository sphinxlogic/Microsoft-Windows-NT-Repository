/*
virusdat.c
Stealth Bomber Version 2.2

Kevin Dean
Fairview Mall P.O. Box 55074
1800 Sheppard Avenue East
Willowdale, Ontario
CANADA    M2J 5B9
CompuServe ID: 76336,3114

February 10, 1992

	This module defines the _fcrc array used by the anti-virus CRC check.
The default search string used by the CRCSET.EXE program is _STEALTH but may
be changed by either modifying this file or defining another instance of _fcrc
in another file earlier in the program link.

	This code is public domain.
*/


#include "vircheck.h"


#define STEALTH_NFILES  1


const filecrc _fcrc[STEALTH_NFILES] =
  {
  '_', 'S', 'T', 'E', 'A', 'L', 'T', 'H'
  };
