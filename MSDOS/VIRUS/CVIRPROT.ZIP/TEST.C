

#include "acheck.c"

main (int argc, char *argv[])
{
  char  inchar;

  printf("\nThis code really does nothing\n");
  switch (check (argc, argv)) {
    case 0 : break;  /* everything OK */

    case 1 : {
               printf (" This file was not patched and cannot be");
               puts (" checked for viruses");
               break;
             }
    case 2 : {
               puts (" User turned off virus protection ");
               break;
             }
    case 3 : {
               puts (" \7\n\nA change has been made to the original code, potentially");
               printf ("by a virus.  Continue running the program? ");
               inchar = getche();
               printf("\n\n");
               if (toupper(inchar) != 'Y')
                exit(1);
             }
    }
  puts("This does less");
}