#include "copyleft.h"

/*
    GEPASI - a simulator of metabolic pathways and other dynamical systems
    Copyright (C) 1989, 1992  Pedro Mendes
*/

/*************************************/
/*                                   */
/*         variables for MCA         */
/*                                   */
/*          MICROSOFT C 6.00         */
/*           QuickC/WIN 1.0          */
/*             ULTRIX cc             */
/*              GNU gcc              */
/*                                   */
/*   (include here compilers that    */
/*   compiled GEPASI successfully)   */
/*                                   */
/*************************************/


#include "globals.h"                      /* global symbols                 */

 double Dxv[MAX_STEP][MAX_MET];           /* variable elasticities          */
 double Duv[MAX_STEP][MAX_MET];           /* parameter elasticities         */
 double DuJ[MAX_STEP][MAX_MET];           /* flux response coefficients     */
 double Gamma[MAX_MET][MAX_STEP];         /* [] control coefficients        */
 double C[MAX_STEP][MAX_STEP];            /* J control coefficients         */
 double aux1[MAX_MET][MAX_MET];           /* auxiliar matrices              */
 double aux2[MAX_MET][MAX_MET];           /* auxiliar matrices              */
