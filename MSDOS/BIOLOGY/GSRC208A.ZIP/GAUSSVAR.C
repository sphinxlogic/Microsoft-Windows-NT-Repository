#include "copyleft.h"

/*
    GEPASI - a simulator of metabolic pathways and other dynamical systems
    Copyright (C) 1989, 1992  Pedro Mendes
*/

/*************************************/
/*                                   */
/*  variables for Gaussian reduction */
/*                                   */
/*          MICROSOFT C 6.00         */
/*           QuickC/WIN 1.0          */
/*             ULTRIX cc             */
/*              GNU gcc              */
/*                                   */
/*   (include here compilers that    */
/*   compiled GEPASI successfully)   */
/*                                   */
/*************************************/

#include "globals.h"                              /* global symbols        */

float ml[MAX_MET][MAX_MET];              /* multipliers of gauss reduction */
float lm[MAX_MET][MAX_MET];              /* inverse of ml                  */
float ld[MAX_MET][MAX_MET];              /* metabolite linear dependencies */
float rstoi[MAX_MET][MAX_STEP];          /* reduced stoicheiometric matrix */
