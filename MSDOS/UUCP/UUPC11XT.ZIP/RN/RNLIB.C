#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "lib.h"
#include "hlib.h"
#include "version.h"
#include "timestmp.h"

char **host_argv;


int hostinit(int mode)
{

   banner(host_argv);
   printf("rn %s \n", RN_VERSION);

   if (!configure(B_NEWS))
   {
      return TRUE;           /* Configure failed */
   }
   return FALSE;
}


void gethostname(char *buf, int bufmax)
{

   *buf = '\0';
   if (strlen(E_nodename) < bufmax)
   {
      strcpy(buf, E_nodename);
   }
   return;
}
