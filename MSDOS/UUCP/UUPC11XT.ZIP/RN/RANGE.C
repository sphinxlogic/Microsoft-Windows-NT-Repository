#ifndef lint
static char *rcsid = "$Header: E:\SRC\UUPC\RN\RCS/RANGE.C 1.1 1992/11/21 06:14:58 ahd Exp $";

#endif

/*
***************************************************************************
This work in its current form is Copyright 1989 Stan Barber
This software may be distributed freely as long as no profit is made from
such distribution and this notice is reproducted in whole.
***************************************************************************
This software is provided on an "as is" basis with no guarantee of
usefulness or correctness of operation for any purpose, intended or
otherwise. The author is in no way liable for this software's performance
or any damage it may cause to any data of any kind anywhere.
***************************************************************************
*/
/*
 * $Log: RANGE.C $
 * Revision 1.1  1992/11/21  06:14:58  ahd
 * Initial
 *
 *
 *    Rev 1.0   18 Nov 1990  0:22:26
 * Initial revision.
 * Revision 1.1  89/11/08  03:45:39  sob
 * Initial revision
 *
 *
 */

#include <stdio.h>
extern char *rindex();
char *progname;

main(argc, argv)
   char *argv[];
   int argc;
{
   int x, y, i;


   if ((progname = rindex(argv[0], '/')) == NULL)
      progname = argv[0];
   else
      progname++;


   if (argc != 3)
      usage();
   x = atoi(argv[1]);
   y = atoi(argv[2]);
   if (y < x)
      usage();
   y++;

   for (i = x; i < y; i++)
      printf("%d ", i);
   printf("\n");

   exit(0);
}

usage()
{
   fprintf(stderr, "Usage: %s startnumber endnumber\n", progname);
   exit(-1);
}
