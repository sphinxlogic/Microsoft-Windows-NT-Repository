/*--------------------------------------------------------------------*/
/*    Common global variables for RN under UUPC/extended              */
/*                                                                    */
/*    I suspect I'm missing something if I have to create this        */
/*    file, but pass the chainsaw oil and we'll get down to it...     */
/*                                                                    */
/*       Change History                                               */
/*          24Mar92     Hack into existence                 ahd       */
/*--------------------------------------------------------------------*/

#include "intern.h"

#include "common.h"
#include "rn.h"
