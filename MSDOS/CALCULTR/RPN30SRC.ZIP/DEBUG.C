/*
| debugging code
*/
#define DBG_MAIN
#include "debug.h"	/* is DEBUG defined (in .h), or not? */

#ifdef DEBUG
#include "rpn.h"

void start_debug(void)
{
	errfile = fopen("rpn.err","w");
	fprintf(errfile,"starting rpn version %s\n", version);
}

#endif	/* DEBUG */
