/* SHUFFLE randomizes a range of numbers between lower and higher  */

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <bios.h>

#define SIZE 10000
#define FOR_X(max) for(x=0;x<max;x++)
#define getrandom(min, max) ((rand() % (int)((max) - (min))) + (min) + 1)

int array[SIZE];

void main (int argc, char *argv[])
{
	int x, y = 0, num, count, lower, upper;

	lower = atoi(argv[1]);
	upper = atoi(argv[2]);
   if(lower >= upper)
      {
		puts("SHUFFLE randomizes a range of numbers specified as lower and upper");
		puts("Syntax: SHUFFLE lower upper");
		puts("Maximum range is 10,000 ");
		exit(1);
      }
	count = upper - lower + 1;

	FOR_X(count)
		{
		array[x + 1] = lower++;
		}

	srand((unsigned)time(NULL));
	puts("Hit any key to ABORT.");
	for(x = count; (x > 0) & (_bios_keybrd(_KEYBRD_READY) == 0); x--)
		{
		num = getrandom(0, x);
		printf("%5i ", array[num]);
		array[num] = array[x];
		if(y++ == 12)
			{
			printf("\n");
			y = 0;
			}
		}
   exit(0);
}








