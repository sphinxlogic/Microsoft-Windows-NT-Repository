/* finds out how long the longest line in a file is
 *
 * necessary because dopey Mac laserwriter driver (6.0) generates 
 * lines longer than 255 characters in the xvdocs.ps file.  This exceeds the
 * postscript spec, and no doubt breaks on some printers, hence I have to
 * make sure that there are no long lines when I distribute said PS file.
 *
 *   --jhb, 4/24/92
 */


#include <stdio.h>

main()
{
  int c, longest, count;

  longest = count = 0;

  while ((c=getchar()) != EOF) {
    if (c == '\n') {
      if (count>longest) longest = count;
      count = 0;
    }
    else count++;
  }

  if (count>longest) longest = count;
  printf("Longest line is %d chars long, not counting the NL\n", longest);
}
