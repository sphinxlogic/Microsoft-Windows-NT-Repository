/* written by Reg Clemens  (clemens@plk.af.mil) */

#include <stdio.h>

main()
{
	int     c;

	while ((c=getchar()) != EOF) {
	if (c & 0200)
		printf("\\%o", c);
	else
		putchar(c);
	}
}
