/* GetItLoc.c - GetItLockIt
 */
#include "Aldtypes.h"
#include "ALDMEM.H"
#include "imtypes.h"
#include "immem.h"
#include "ImErr.h"

RC GetItLockIt (dwbytes, ph, plp)
DWORD		dwbytes;
HANDLE		*ph;
BYTE FAR	**plp;
{
		RC err = SUCCESS;
		
		if (!(*ph = MMAlloc (dwbytes))) {
			DBMSG(("GetItLockIt: MMAlloc fail\n"));
			err = IM_MEM_FULL;
			goto cu0;
		}
		if (!(*plp = (BYTE FAR *) MMLock (*ph))) {
			DBMSG(("GetItLockIt: MMLock fail\n"));
			MMFree (*ph);
			*ph = HNULL;
			err = IM_MEM_FAIL;
			goto cu0;
		}
cu0:	return err;
}

void UnlockItFreeIt (h)
HANDLE	h;
{
		MMUnlock (h);
		MMFree (h);
}