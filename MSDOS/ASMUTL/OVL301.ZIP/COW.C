cow_noise()
{
	printf(" goes moo");
}

cow(int i)
{
	printf("\ncow");
	if(i==9)
		cow_noise();
}
