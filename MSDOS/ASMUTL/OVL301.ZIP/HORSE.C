horse_noise()
{
	printf(" goes neigh");
}

horse(int i)
{
	printf("\nhorse");
	if(i==9)
		horse_noise();
}
