piglet_noise()
{
	printf(" goes squeal");
}

piglet(int i)
{
	printf("\npiglet");
	if(i==9)
		piglet_noise();
	return(i+1);
}
