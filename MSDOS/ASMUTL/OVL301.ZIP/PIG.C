pig_noise()
{
	printf(" goes oink");
}

int pig(int i)
{
	printf("\npig");
	if(i==9)
		pig_noise();
	return(piglet(i));
}
