char *strupr(char *str);

main(int argc, char *argv[])
{
	int i;

	if(argc>1 && !strcmp(strupr(argv[1]),"MACDONALD"))
		printf("\nE-I-E-I-O!");	/* macdonald command line argument evokes an appropriate response */
	for(i=0;i<10;i++){
		farm();
		cow(i);
		printf(" rooting around at %d:00 in the morning",pig(i));
		horse(i);
		sheep(i);
	}
}

farm()
{
	printf("\nfarm");
}
