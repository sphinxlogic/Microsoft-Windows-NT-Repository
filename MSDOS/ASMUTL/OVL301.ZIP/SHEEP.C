sheep_noise()
{
	printf(" goes baaaa");
}

sheep(int i)
{
	printf("\nsheep");
	if(i==9)
		sheep_noise();
}
