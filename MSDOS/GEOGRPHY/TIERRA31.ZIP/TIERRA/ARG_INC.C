/* ------------------------------------------------------------------------*/
/* arg_inc.c  6-5-92                                                       */
/* Tierra Simulator V3.11: Copyright (c) 1991, 1992 Tom Ray & Virtual Life */
/* this file is a "nice" way to make the arg binary easier to make         */
/* by Daniel Pirone March 1, 1992                                          */
/* ------------------------------------------------------------------------*/
#include "license.h"
#define ARG
#include "portable.c"
#include "genio.c"

/* ------------------------------------------------------------------------*/
