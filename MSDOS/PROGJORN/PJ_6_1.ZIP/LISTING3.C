  /*  Copyright Frank D. Greco, 1987
   *  Page 50, Volume 6.1 Programmer's Journal
   */
  #define DEBUG                   /* Turn on timing statistics */
  
  #define TIX_PER_SEC         18.20648            /* For the PC */
  #define START()             _t1 = gettime()
  #define STOP()              _t2 = gettime()
  #define TIX_DIFF            (_t2 - _t1)
  #define PRINT_TIME(cp)      fprintf(stderr,"%s: %lf secs.\n",\
                                  cp, TIX_DIFF/TIX_PER_SEC)
  
  #ifdef DEBUG
  #   define TIME(code, string)   START(); code; STOP(); PRINT_TIME(string)
  #else
  #   define TIME(code, string)   code
  #endif
  
  
  static long _t1, _t2;           /* Tick values for calc. elapsed time */
