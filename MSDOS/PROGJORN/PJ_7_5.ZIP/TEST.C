/*
    TEST.C - Test the twll functions
*/


#include "stdio.h"
#include "malloc.h"
#include "coop.h"


/* This is the TWLL header that contains the top of the list pointer */

struct TWLL_HEAD header={0};


main()
{
    int      x;
    struct DATA_TWLL        *twll_item;
    struct MY_DATA_TWLL     *my_twll_item;
    struct OTHER_DATA_TWLL  *other_twll_item;


    /* add 3 entries of each type to the list */
    for (x=3;x;x--) {
        twll_item=                      /* create a new DATA_TWLL */
            (struct DATA_TWLL *)
            calloc(sizeof(struct DATA_TWLL),1);

        add_data_twll(&header,twll_item,DATA);
        twll_item->x=x;                                

        my_twll_item=               /* create a new MY_DATA_TWLL */
             (struct MY_DATA_TWLL *)
            calloc(sizeof(struct MY_DATA_TWLL),1);

        add_data_twll(&header,my_twll_item,MY_DATA);
        strcpy(my_twll_item->a,"Sample.");             

        other_twll_item=                /* create a new OTHER_DATA_TWLL */
             (struct OTHER_DATA_TWLL *)
            calloc(sizeof(struct OTHER_DATA_TWLL),1);

        add_data_twll(&header,other_twll_item,OTHER_DATA);
        other_twll_item->a=x+100;                   
        }


    /* print the contents of the list */
    printf("printing lines in current list \n");
    for(twll_item=header.top;
        twll_item;
        twll_item=twll_item->inherit.next) {

        switch (twll_item->inherit.type) {
            case DATA:
                print_data_twll(twll_item);
                break;
            case MY_DATA:
                print_my_data_twll(twll_item);
                break;
            case OTHER_DATA:
                print_other_data_twll(twll_item);
                break;
            }
        }

    exit(0);        
}   

