/* libgen - generate miscellaneous control files for building library

    usage: libgen *.asm

    Borland   C>tcc libgen.c wildargs.obj
    Microsoft C>cl  libgen.c setargv.obj

    You may have to specify correct path information for the
    wildargs and setargv obj files.

    John Otken, Soft Advances
*/

#include <stdio.h>

/* prototypes begin */
sort(char *(*v)[], int n);
/* prototypes end */

void main(int argc, char *argv[])
{
    char *pt;
    FILE *arf, *mak, *opt;
    int i;

    if (argc < 3) {
        printf("usage: libgen *.asm\n");
        exit(0);
    }

    arf = fopen("lib.arf", "w");
    if (!arf) {
        printf("Error opening lib.arf file\n");
        exit(1);
    }

    mak = fopen("lib.mak", "w");
    if (!mak) {
        printf("Error opening lib.mak file\n");
        exit(1);
    }

    opt = fopen("lib.opt", "w");
    if (!opt) {
        printf("Error opening lib.opt file\n");
        exit(1);
    }

    sort(&argv[1], argc-1);

    fprintf(arf, "lib.lib\ny\n");

    for( i = 1; i < argc; i++) {                       /* for each argument */
        pt = argv[i];                                 /*  change x.asm to x */
        for( ; *pt != '.' && *pt != '\0'; pt++);
        *pt = '\0';
        
        pt = argv[i];                               /*  write response file */
        fprintf(arf, "+%s &\n", pt);                /*  & make file entries */
        fprintf(mak,"%s.obj:\t%s.asm lib.equ\n\tmasm %s/t/z;\n\n",pt,pt,pt);
        fprintf(opt," lib.lib %s.asm lib.equ\n%s /t/z/i \\asm ;\n",pt,pt,pt);
    }

    fprintf(arf, "\nNUL\n");

/*  fprintf(mak, "lib.xxx:\tlib.lib\n\tdelete lib.lib\n\tlib @lib.arf\n"); */
    fclose(arf);
    fclose(mak);
    fclose(opt);
}


sort(char *(*v)[], int n)                    /* sorts pointer array to char */
{
    char *temp;
    int gap, i, j, k;
    
    for (gap = n/2; gap > 0; gap /= 2)
        for (i = gap; i <n; i++)
            for (j = i-gap; j >= 0; j -= gap) {
                k = j + gap;
                if (strcmp((*v)[j], (*v)[k]) <= 0)
                    break;
                temp = (*v)[j];
                (*v)[j] = (*v)[k];
                (*v)[k] = temp;
            }
}
