/* Sample main that uses cursor keys. Interface to mouse on lines 4,8,26. */
#include <stdio.h>
#include <conio.h>
#include "mouse1g.c"

main(){
int row,col,x;
 mousereset(); mousehook();             /* Turn on mouse */
 clrscr(); row=1; col=1; gotoxy(col,row); putch('*'); gotoxy(col,row);
 while(1){
   x=getch();
   if(x==3 || x==27) break;
   if(x==0){
     x=getch();
     switch(x){
       case 'H': /* Up    */ --row; break;
       case 'P': /* Down  */ ++row; break;
       case 'K': /* Left  */ --col; break;
       case 'M': /* Right */ ++col; break;
     }
     if(row < 1) row=1; if(row > 24) row=25;
     if(col<1) col=1; if(col>78) col=79;
     putch(' '); gotoxy(col,row); putch('*'); gotoxy(col,row);
   }
 }
 mousereset();                          /* Turn off mouse */
 clrscr();
}
