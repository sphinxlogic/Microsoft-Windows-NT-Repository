#include <stdio.h>
#include <dos.h>
#include "mouse.h"

main()
	{
	int i = 0;
	int x, y, b, press;

	static unsigned far masks[32] =			/* Graphics cursor masks */
		{
		0xffff, 0xffff, 0xffff, 0xffff,		/* Screen mask */
		0xffff, 0xffff, 0xffff, 0xffff,
		0xffff, 0xffff, 0xffff, 0xffff,
		0xffff, 0xffff, 0xffff, 0xffff,

		0x8000, 0xe000, 0xf800, 0xd800,		/* Cursor mask */
		0x0c00, 0x0600, 0x0300, 0x0000,
		0x0000, 0x0000, 0x0000, 0x0000,
		0x0000, 0x0000, 0x0000, 0x0000
		};

	if((i = CheckMouse()) == 0)
		{
		puts("No mouse found");
		exit(-1);
		}
	else
		printf("Mouse with %d buttons found\n", i);

	puts("Cursor is visible");
	DisplayMCursor(SHOW);
	fprintf(stderr,"Press <Enter> to continue\n");
	getchar();

	TextCursor(1, 12, 13);				/* Text mode underscore cursor */
	PositionMCursor(200, 80);
	puts("Now cursor is at 200, 80 and text mode");
	fprintf(stderr,"Press <Enter> to continue\n");
	getchar();

	while(!kbhit())						/* Display changing locations		*/
		{										/* as mouse is moved					*/
		b = CheckPosition(&x, &y);
		printf("Buttons: %d, mouse at %d col and %d row\r", b, x, y);
		}

	for(i = 0; i < 3; i++)				/* Show mouse location when		*/
		{										/* buttons were pressed				*/
		GetPress(i, &x, &y, &press);
		printf("Button: %d, X: %d, Y: %d, Presses: %d\n", i, x, y, press);
		}

	for(i = 0; i < 3; i++)				/* Show mouse locations when		*/
		{										/* buttons were released			*/
		GetRelease(i, &x, &y, &press);
		printf("Button: %d, X: %d, Y: %d, Releases: %d\n", i, x, y, press);
		}

	LimitCursor(HORIZ, 0, 80);			/* Limit mouse cursor travel		*/
	LimitCursor(VERT,  0, 80);
	puts("Cursor movement is limited to 80 x 80 and full");
	TextCursor(0, 0x77ff, 0x7700);	/* Make cursor a block				*/

	GetMickeys(&x, &y);
	fprintf(stderr,"Press <Enter> to continue\n");
	getchar(); getche();					/* Ecosoft does not use getche() */

	GetMickeys(&x, &y);
	printf("Mickeys since last call - X: %d, Y: %d\n", x, y);
	puts("Cursor is now hidden");
	DisplayMCursor(HIDE);
	getchar();
	}

		