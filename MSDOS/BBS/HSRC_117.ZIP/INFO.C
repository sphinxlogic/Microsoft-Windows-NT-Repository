#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"

/* Info main command; performs various informative functions, gives
   copyright info, general help, etc. */

extern WINDOW *ewnd;


void pascal info (void) {

	int returncode;
	struct ffblk f;
	struct ffblk f1;
	char temp[91];
	char counter;
	word x;
	word y;
	word total;
	long inttotal;
	long prevtotal;
	WINDOW *wnd;

Over:
    wnd=establish_window(2,maxy-7,25,69);
	set_help("infof1    ",18,0);
	set_border(wnd,3);
	set_title(wnd," Quick Information on HeadEdit ");
	set_colors(wnd,BORDER,7,0,0);
	display_window(wnd);
	wcursor(wnd,0,0);
Again:
	wprintf(wnd,"\n  HeadEdit is a message reader for the XBBS(no tm) message base.");
	wprintf(wnd,"\n  XST version 1.9 or higher is needed for FIDO(tm) net/echo mail.");
	wprintf(wnd,"\n\t\t  A FidoNet compatible mailer is also required");
	wprintf(wnd,"\n\t\t[FIDO (c) Tom Jennings   XST (c) Wayne Michaels]");
	wprintf(wnd,"\n Compiled: %s  %s [XBBS (c) M. Kimes (1:380/16)]",__DATE__,__TIME__);
	wprintf(wnd,"\n\n  Memory remaining: %lu bytes",coreleft());
	wprintf(wnd,"\n  Line pointers: %u",maxlines);
	wprintf(wnd,"\n  Current Message Directory:\n %s",path);
	if (!nidxsize) wprintf(wnd,"\n No nodelist in use\n");
	else {
		wprintf(wnd,"\n  %lu Nodes listed in nodelist",nidxsize);
		if (*nodepath) wprintf(wnd," in path:\n %s",nodepath);
		sprintf(temp,"%sFidoUser.IDX",nodepath);
		if (!findfirst(temp,&f,0)) wprintf(wnd,"\n  Indexed");
		else wprintf(wnd,"\n  Unindexed");
		sprintf(temp,"%sFidoUser.LST",nodepath);
		if (findfirst(temp,&f,0)) wprintf(wnd," No ");
		wprintf(wnd," FidoUser.Lst is available");
	}
	wprintf(wnd,"\n\n  Current area attributes: %s (%u)\n\n ",area_attr(),currarea->attr);
	if (currarea->attr & NOORIG) wprintf(wnd,"NoOrigins ");
	if (currarea->attr & ANSI) wprintf(wnd,"ANSI ");
	if (currarea->attr & PRIVATE) wprintf(wnd,"Private ");
	if (currarea->attr & PUBLIC) wprintf(wnd,"Public ");
	if (currarea->attr & ECHO) wprintf(wnd,"Echo ");
	if (currarea->attr & NET) wprintf(wnd,"Net");
	wprintf(wnd,"\n ");
	if (currarea->attr & MCI) wprintf(wnd,"MCI ");
	if (currarea->attr & READONLY) wprintf(wnd,"ReadOnly ");
	if (currarea->attr & ALTERNATE) wprintf(wnd,"Alternate ");
	if (currarea->attr & ALTECHO) wprintf(wnd,"Alt Echo ");
	if (currarea->attr & ANON) wprintf(wnd,"Anonymous ");
	if (currarea->attr & REAL) wprintf(wnd,"Real");
	wprintf(wnd,"\n ");
	if(currarea->attr & EXTERN) wprintf(wnd,"Extern ");
	if(currarea->attr & FORCE) wprintf(wnd,"Force ");
	if(currarea->attr & ASSOC) wprintf(wnd,"Assoc ");
	if(currarea->attr & COMPRESS) wprintf(wnd,"CompOK");
    wprintf(wnd,"\n");
	if(currarea->thisname) wprintf(wnd,"  Area alias: \"%s\"",alias[(currarea->thisname)-1]);
	wprintf(wnd,"\n");
	if(currarea->thisaddr) wprintf(wnd,"  Area addr: %u:%u/%01u.%01u@%s"
		,address[(currarea->thisaddr)-1]->zone,address[(currarea->thisaddr)-1]->net,address[(currarea->thisaddr)-1]->node,address[(currarea->thisaddr)-1]->point,address[(currarea->thisaddr)-1]->domain);
ReMsg:
	any_message(" F1, F2, F3 or Any Key ");
	returncode=generic_mouse_input(ewnd);
	clear_message();
	if(returncode=='1') {
		if (helpfunc) {
			if (!helping) {
				helping=1;
				(*helpfunc)();
				helping=0;
			}
		}
		goto ReMsg;
	}
	delete_window(wnd);
	if(returncode==F2 || returncode==PGUP || returncode=='2') {
		wnd=establish_window(1,1,maxy-1,maxx-1);
		set_help("infof2    ",18,0);
		set_border(wnd,3);
		set_title(wnd," ALT-FKeys ");
		set_colors(wnd,BORDER,7,0,0);
		display_window(wnd);
		wcursor(wnd,0,0);
		for(x=0;x<10;x++) {
			if(fkey[x]) wprintf(wnd,"%02u. %s\n",x+1,fkey[x]);
		}
		any_message(" Any key ");
		pause();
		delete_window(wnd);
		goto Over;
	}
	else if(returncode==F3 || returncode==PGDN || returncode=='3') {
		inttotal=prevtotal=0;
		total=0;
		wnd=establish_window(1,1,maxy-1,maxx-1);
		set_help("infof3    ",18,0);
		set_border(wnd,3);
		set_title(wnd," Msg Area Analysis ");
		set_colors(wnd,BORDER,7,0,0);
		display_window(wnd);
		wcursor(wnd,0,0);
		sprintf(temp,"%sXDATA.*",path);
		if(findfirst(temp,&f1,0)) {
			any_message("No message areas");
			nopause();
			delete_window(wnd);
			goto Over;
		}
		counter=0;
		while (1) {
			sscanf(&f1.ff_name[strlen(f1.ff_name)-3],"%x",&x);
			wprintf(wnd,"Area #%04u: %s: %lu bytes (%lu msgs)",x,f1.ff_name,f1.ff_fsize,f1.ff_fsize/(long)sizeof(struct _xmsg));
			for(y=0;y<maxareas;y++) {
				if (marea[y].number==x) {
                    wprintf(wnd," [%1.12s]",marea[y].name);
					goto SkipIt;
				}
			}
			wprintf(wnd," [Not in MSGAREAS.XBS]");
SkipIt:
			inttotal+=f1.ff_fsize;
			sprintf(temp,"%sXTEXT.%03x",path,x);
			if(!findfirst(temp,&f,0)) {
				wprintf(wnd,"\n            %s: %lu bytes\n",f.ff_name,f.ff_fsize);
				inttotal+=f.ff_fsize;
			}
			else wprintf(wnd,"\n            Missing XTEXT\n");
			sprintf(temp,"%sMDUPS.%03x",path,x);
			if(!findfirst(temp,&f,0)) {
				wprintf(wnd,"            %s: %lu bytes\n",f.ff_name,f.ff_fsize);
				inttotal+=f.ff_fsize;
			}
			else wprintf(wnd,"           Missing MDUPS\n");
			wprintf(wnd,"Total size area #%04u: %lu bytes",x,inttotal-prevtotal);
			prevtotal=inttotal;
			total++;
			if(findnext(&f1)) break;
			if(++counter>=((maxy-2)/4)) {
				counter=0;
				any_message(" More? (Y-n) ");
				returncode=toupper(generic_mouse_input(ewnd));
				if(returncode==ESC || returncode=='N') break;
				clear_message();
			}
			wprintf(wnd,"\n");
		}
		sprintf(temp,"%u message areas occupy %lu bytes",total,inttotal);
		any_message(temp);
		pause();
		delete_window(wnd);
		goto Over;
	}
}

