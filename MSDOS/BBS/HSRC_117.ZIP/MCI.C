/* Message command interpreter function */

#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"


char * pascal mci (char *text) {

	static char s[256];
	char work[81];
	char temp[36];
	char *p;
	register word x=0;
	struct date dos_date;
	struct time dos_time;

	if (!strlen(text)) return text;
	stripcr(text);
	if (!strlen(text)) return "\r\n";
	*work=0;
	if (*text=='^') strcat(work," ");
	strcat(work,text);
	text=work;
	strcpy(s,strtok(text,"^"));
	while ((p=strtok(0,"^"))!=NULL && (strlen(s)+strlen(p)+1)<(256-35)) {
		switch ((int)toupper(*p)) {
			case 'H':   if (!isdigit(p[1])) {
							strcat(s,"\b");
							p++;
							break;
						}
						for (x=0;x<(p[1]-'0');x++) strcat(s,"\b");
						p+=2;
						break;
			case 'U':   strcpy(temp,name);
						if (!isdigit(p[1]) || p[1]=='0') {
							strcat(s,temp);
							if (p[1]!='0') {
								p++;
								break;
							}
						}
						else if (p[1]=='1' || !strchr(temp,' ')) {

							char *pp;

							if(pp=strchr(temp,' ')) *pp=0;
							strcat(s,temp);
						}
						else {
							strtok(temp," ");
							strcat(s,strtok(0," \n"));
						}
						p+=2;
						break;
            case 'B':   if(!nobell)strcat(s,"\x7");
						p++;
						break;
            case 'A':   p++;
                        if(isdigit(*p)) *p=*p-'0';
                        else if(toupper(*p)=='A') {
                            strcat(temp,"\x1b[36m");
                            goto CoitusInterruptus;
                        }
                        else {
                            p--;
                            break;
                        }
                        strcat(temp,"\x1b[");
                        switch((int)(*p)) {
                            case 0: strcat(temp,"0;1;32");
                                    break;
                            case 1: strcat(temp,"1");
                                    break;
                            case 2: strcat(temp,"2");
                                    break;
                            case 3: strcat(temp,"5");
                                    break;
                            case 4: strcat(temp,"7");
                                    break;
                            case 5: strcat(temp,"31");
                                    break;
                            case 6: strcat(temp,"32");
                                    break;
                            case 7: strcat(temp,"33");
                                    break;
                            case 8: strcat(temp,"34");
                                    break;
                            case 9: strcat(temp,"35");
                                    break;
                        }
                        strcat(temp,"m");
CoitusInterruptus:
                        strcat(s,temp);
                        p++;
                        break;
			case 'T':   gettime(&dos_time);
						strcat(s,saytime(&dos_time));
						p++;
						break;
			case 'D':	getdate(&dos_date);
						strcat(s,saydate(&dos_date));
						p++;
						break;
			case 'R':   strcat(s,"unlimited");
						p++;
						break;
            case 'S':   slowprint=1;
                        p++;
                        break;
            default:    break;
		}
		strcat(s,p);
	}
	strcat(s,"\r\n");
	return s;
}


