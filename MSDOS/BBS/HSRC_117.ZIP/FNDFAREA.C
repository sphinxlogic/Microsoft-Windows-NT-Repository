#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"

word pascal find_filearea (void) {

	int handle;
	char s[256];
    char *p;
	struct _fboard fboard;

	if(!flsearch) {
		error_message(" FLSEARCH not defined ");
		nopause();
		return 0;
	}
	if ((handle=_open(flsearch,O_RDONLY | O_TEXT | O_DENYNONE))==-1) {
		error_message(" Can't open flsearch file ");
		nopause();
		return 0;
	}
	while (!eof(handle)) {
		if (!fgetsx(s,256,handle)) break;
		if (*s=='\n' || *s=='\r' || *s==';') continue;
		stripcr(s);
        strncpy(fboard.dpath,strtok(s," "),79);
		fboard.dpath[78]=0;
		if (fboard.dpath[strlen(fboard.dpath)-1]!='\\') strcat(fboard.dpath,"\\");
		strtok(0," ");
        strncpy(fboard.name,strtok(0," "),47);
		fboard.name[46]=0;
		while((p=strchr(fboard.name,'_'))!=NULL) *p=' ';
		if (!stricmp(fboard.name,currarea->name)) break;
	}
	if (eof(handle)) {
		_close(handle);
		return 0;
	}
	_close(handle);
	strcpy(filepath,fboard.dpath);
	return 1;
}

