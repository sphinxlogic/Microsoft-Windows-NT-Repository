/* HeadEdit miscellaneous get/put text & header functions */

#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"

extern WINDOW *ewnd;


char * pascal get_text () {

 char once;
 static char *hold;
 char *tempo;
 word temp=0;
 int  handle;
 char reduced=0;

 sprintf(filename,"%sXTEXT.%03x",path,areano);
 while ((handle=_open(filename,O_RDONLY | O_BINARY | O_DENYNONE))==-1) {
	 if (errno==EACCES) {
		temp++;
		if (temp>2) {
			error_message(" Can't get access ");
			return NULL;
		}
		any_message(" Awaiting access ");
		sleep(1);
	 }
	 else {
		error_message(" Can't open datafile ");
		return NULL;
	 }
 }
 temp=msg.length;
 once=0;
TryThatAgain:
 if (lseek(handle,msg.start,SEEK_SET)==-1) {
	 if (eof(handle)==-1) {
        if (!once) {
			once++;
			goto TryThatAgain;
		}
		else perror (" TEXT SEEK ERROR");
        _close(handle);
        return NULL;
	 }
 }
ReTry:
  hold=(char *)malloc(msg.length+1);
  if (hold==NULL) {
    if (msg.length>1024 && !(msg.m_attr & MSGPACKED)) {
		msg.length-=256;
		any_message(" Reducing text size to fit... ");
		reduced=1;
		goto ReTry;
	}
	else {
        _close(handle);
        return NULL;
	}
  }
  memset(hold,0,msg.length);
  if(_read(handle,hold,msg.length)<msg.length) reduced=1;
  _close(handle);
  hold[msg.length-1]=0;
  hold[msg.length]=0;
  tempo=hold;

  if(!(msg.m_attr & MSGTREATED) && !(currarea->attr & ANSI) &&!(msg.m_attr & MSGPACKED)) {
	  while (*tempo) {
		if(*tempo=='\x8d' || *tempo=='\n') {
			if(*tempo=='\n') memmove(tempo,&tempo[1],msg.length-((word)tempo-(word)hold));
			else {
				if(*(tempo-1)==' ' && tempo>hold) memmove(tempo,&tempo[1],msg.length-((word)tempo-(word)hold));
				else {
					*tempo=' ';
					tempo++;
				}
			}
		}
		else tempo++;
	  }
	  if(*(tempo-1)!='\r' && tempo>hold) {
		*tempo='\r';
		tempo[1]=0;
	  }
	  if(!reduced && temp>((word)strlen(hold)+1) && *hold) {
		msg.length=(word)strlen(hold)+1;
        sprintf(filename,"%sXTEXT.%03x",path,areano);
        if ((handle=_open(filename,O_RDWR | O_BINARY | O_DENYWRITE))==-1) goto OkayThenDont;
		once=0;
TryThatAgain2:
		if (lseek(handle,msg.start,SEEK_SET)==-1) {
		 if (eof(handle)==-1) {
			if (!once) {
				once++;
				goto TryThatAgain;
			}
			else {
				_close(handle);
				goto OkayThenDont;
			}
		 }
		}
		if(_write(handle,hold,(word)strlen(hold))==(word)strlen(hold)) {
			_write(handle,"\0",(word)sizeof(char));
			if(eof(handle)==-1) {
				_close(handle);
				goto OkayThenDont;
			}
			_close(handle);
			msg.m_attr=(msg.m_attr | MSGTREATED);
			put_mess();
			temp=msg.length;
		}
	  }
  }

  if(msg.m_attr & MSGPACKED && !reduced) {
	   if(unpack_msg(&hold)==NULL) {
            if(hold) free(hold);
            msg.length=0;
/* printf("\x1b[KCame back NULL: hold=%p",hold);	*/
			return NULL;
	   }
/*	   printf("\x1b[KCame back ok: hold=%p",hold);	*/
  }

OkayThenDont:
  msg.length=temp;
  return hold;
}



word pascal put_text (char far *hold,char *extra,char *extra1,struct ffblk *f,char *origintext) {

 char once;
 word messlen=0;
 int handle;

 if (hold==NULL || !*hold) return 0;
 sprintf(filename,"%sXTEXT.%03x",path,areano);
 if (findfirst(filename,f,0)) f->ff_fsize=0;

 if ((handle=_open(filename,O_RDWR | O_BINARY | O_APPEND | O_DENYWRITE))==-1) {
	 if((handle=creat(filename,S_IWRITE))==-1) {
		 if (errno==EACCES) error_message(" Access temporarily denied ");
	 }
	 else error_message(" Can't open text database ");
	 pause();
	 return 0;
 }
 once=0;
TryThatAgain:
 if (lseek(handle,0,SEEK_END)==-1) {
	 if (eof(handle)==-1) {
        if (!once) {
			once++;
			goto TryThatAgain;
		}
		else {
			error_message (" Error finding EOF ");
			_close(handle);
			pause();
			return 0;
		}
	 }
 }
  if (*extra && extra) messlen=_write(handle,extra,sizeof(char)*strlen(extra));
  if (*extra1 && extra1) messlen+=_write(handle,extra1,sizeof(char)*strlen(extra1));
  messlen+=_write(handle,hold,sizeof(char)*strlen(hold));
  if(*origintext && origintext) messlen+=_write(handle,origintext,sizeof(char)*strlen(origintext));
  _write(handle,"\0",1);
  messlen+=2;
  _close(handle);
  return (messlen);
}



void pascal get_mess (char which) {

 int handle;
 struct _xmsg *ptr;

 if(!nomess) return;
 sprintf(filename,"%sXDATA.%03x",path,areano);

 if (messno>nomess || messno<1) messno=1;
 if ((handle=_open(filename,O_RDONLY | O_BINARY | O_DENYNONE))==-1) {
	 if (errno==EACCES) error_message("Access temporarily denied.");
	 else error_message("Can't open msg datafile");
	 return;
 }
 ptr = which ? &msg2 : &msg;
 if ((lseek(handle,(long)((long)(messno-1)*(long)sizeof(struct _xmsg)),SEEK_SET)==-1) || (_read(handle,ptr,sizeof(struct _xmsg))<1)) {
	if (eof(handle)==-1) perror ("\nSEEK ERROR");
 }
 _close(handle);
}




void pascal put_mess () {

 int handle;
 register word x=0;

 if (messno>nomess || messno<1) return;
 sprintf(filename,"%sXDATA.%03x",path,areano);

 while ((handle=_open(filename,O_RDWR | O_BINARY | O_DENYNONE))==-1) {
	 if (errno==EACCES) {
		x++;
		if(x>2) {
			error_message(" Got tired of waiting... ");
			pause();
			return;
		}
		any_message(" Awaiting access... ");
		sleep(1);
	 }
	 else {
		if((handle=creat(filename,S_IWRITE))==-1) {
			error_message(" Cannot open message file... ");
			return;
		}
		break;
	 }
 }
 clear_message();
 lock(handle,(long)((long)(messno-1)*(long)sizeof(struct _xmsg)),(long)sizeof(struct _xmsg));
 if ((lseek(handle,(long)((long)(messno-1)*(long)sizeof(struct _xmsg)),SEEK_SET)==(-1)) || (_write(handle,&msg,sizeof(struct _xmsg))<1)) {
	if (eof(handle)==(-1))  {
		error_message(" Seek error! ");
		pause();
	}
 }
 unlock(handle,(long)((long)(messno-1)*(long)sizeof(struct _xmsg)),(long)sizeof(struct _xmsg));
 _close(handle);
}

