#include "msgg.h"
#include "twindow.h"
#include "headedit.h"

extern word threadstart;


/* Prints header info on top few lines */

void pascal show_header (char quick) {

  if(!quick) {
    current_color=readstatcolor + (readstatback * 16);
    dputs(1,5,"��������������������������������������������������������������������������������");
    if(threadstart) dputs(1,5,"=");
    if (msg.attr & MSGPRIVATE) {
        dputs(2,5,"Prv");
    }
    if (msg.m_attr & MSGDELETED) {
        dputs(7,5,"Del");
    }
    if (msg.attr & MSGSENT) {
        dputs(12,5,"Snt");
    }
    if (msg.attr & MSGCRASH) {
        dputs(17,5,"Crsh");
    }
    if (msg.attr & MSGREAD) {
        dputs(23,5,"Rd");
    }
    if (msg.m_attr & MSGANON) {
        dputs(27,5,"Anon");
    }
    if (areano<(totalareas+1) && messno>lastread[areano-1]) {
        dputs(33,5,"New");
    }
    if(msg.m_attr & MSGKEEP) {
        dputs(37,5,"Kp");
    }
    if(msg.m_attr & MSGNET) {
        dputc(41,5,'N');
    }
    if(msg.m_attr & MSGECHO) {
        dputc(41,5,'E');
    }
    if ((currarea->attr & NET) || (currarea->attr & ALTERNATE)) {
        dprintf(43,5,"%u:%u/%u.%01u\x1a%u:%u/%u.%01u",msg.o_zone,msg.orig_net,msg.orig,msg.o_point,msg.d_zone,msg.dest_net,msg.dest,msg.d_point);
    }
  }
  current_color=readheadcolor+(readheadback*16);
  dclrwnd(1,1,maxx,4);
  dprintf(1,1,"Fm: %-35.35s To: %-35.35s",msg.from,msg.to);
  ((msg.attr & MSGFILE) + (msg.attr & MSGURQ) + (msg.attr & MSGFRQ)) ? dputs(1,2,"File: ") : dputs(1,2,"Subj: ");
  dprintf(8,2,"%-63.63s",msg.subj);
  dprintf(1,3,"Date: %-20.20s | #%u of %u in Area #%u",msg.date,messno,nomess,areano);
  dputs(1,4,"Attr:  ");
  dputs(8,4,quick_attr());
  dprintf(62,4,"Area: %1.12s",currarea->name);
}



/* Formatted 'printf-style' output through pd screen writer */

int cdecl dprintf (int x,int y,char *string,...) {

 char buffer[512];

    va_list ap;
    va_start(ap,string);
    vsprintf(buffer,string,ap);
    va_end(ap);
    return(dputs(x,y,buffer));
}

