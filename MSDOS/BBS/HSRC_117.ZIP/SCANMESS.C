#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"

extern WINDOW *ewnd;


void pascal scan_mess (void) {

    char s[60];
    char lowstr[6];
    word low;
    int returncode;
    char counter;
    word tempmess;
    WINDOW *wnd;
    FIELD *fld;

		wnd=establish_window(4,maxy-7,5,32);
        set_border(wnd,3);
        set_title(wnd," Message Scanner ");
        set_colors(wnd,BORDER,7,0,0);
        display_window(wnd);
        wcursor(wnd,0,0);
		wprintfraw(wnd," F10 to scan or ESC to abort");
        if (lastread[areano-1]<nomess) sprintf(lowstr,"%u",lastread[areano-1]);
        else strcpy(lowstr,"1");
        init_template(wnd);
        sprintf(s,"From (1-%05u):",nomess);
        wprompt(wnd,2,2,s);
        fld=establish_field(wnd,18,2,msk5,lowstr,'N');
        field_window(fld,"low       ",40,6);
        prep_template(wnd);
Over:
        returncode=data_entry(wnd);
        if (returncode==ESC) {
            delete_window(wnd);
            return;
        }
        if (returncode!=F10) goto Over;
        low=(word)atol(lowstr);
        if (low>nomess || low<1) {
            error_message(" Invalid. ");
            nopause();
            goto Over;
        }
        delete_window(wnd);
		wnd=establish_window(0,0,maxy,maxx);
        set_border(wnd,1);
        sprintf(s," Scanning Area#%u ",areano);
        set_title(wnd,s);
        display_window(wnd);
        wcursor(wnd,0,0);
        counter=0;
        tempmess=messno;
        while(1) {
            messno=low++;
            get_mess(1);
            reverse_video(wnd);
			wprintfraw(wnd,"%05u Subj: %-63s",messno,msg2.subj);
            normal_video(wnd);
			wputchar(wnd,'\n');
			wprintfraw(wnd,"Fm: %-32s To: %s",msg2.from,msg2.to);
			wputchar(wnd,'\n');
			wprintfraw(wnd,"%s %s",msg2.date,quick_attr());
			wputchar(wnd,'\n');
            counter++;
			if (counter>=((maxy-2)/3) || low>nomess) {
OverAgain:
                any_message(" PageUp/Dn, Home, End, ESC ");
                counter=0;
				returncode=toupper(generic_mouse_input(ewnd));
                clear_message();
                switch (returncode) {
                    case 45:
					case PGUP:  if(low<=(((maxy-2)/3)+1)) goto DoEnd;
								if (low<(((maxy-2)/3)*2)+1) low=1;
								else low-=(((maxy-2)/3)*2);
                                break;
                    case PGDN:
					case 13:    if (low>=nomess) low=1;
								if ((nomess-low)<((maxy-2)/3)) goto DoEnd;
                                break;
                    case 32:
                    case ESC:   goto BreakOut;
					case END:
DoEnd:
								if (nomess>(((maxy-2)/3)-1)) low=nomess-(((maxy-2)/3)-1);
                                else low=1;
                                break;
					case HOME:  low=1;
                                break;
                    default:    bell();
                                goto OverAgain;
                }
                clear_message();
                clear_window(wnd);
                wcursor(wnd,0,0);
            }
        }
BreakOut:
        delete_window(wnd);
        messno=tempmess;
        clear_message();
}

