#include "msgg.h"
#include "twindow.h"
#include "headedit.h"


/* Expand metastrings in passed string */

char * pascal convertstring (char *a) { /* Not reentrant */

 char arg=0;
 char *pp;
 char *p;
 char strr[256];
 char cvstr[364];
 char middle[82];

   strset(strr,0);
   strset(cvstr,0);
   strcpy(strr,a);
   p=strr;
   pp=cvstr;
   while(*p) {
		if (*p=='*' && p[1]) {
		   arg=p[1];
		   p+=2;
		   switch ((int)arg) {
			 case 'F':    /* From Name */
						  strcpy(middle,msg.from);
						  turn_spaces_to_uls(middle);
						  strcat(pp,middle);
						  break;
			 case 'f':	  strcat(p,msg.from);
						  break;
			 case 'T':	  /* To Name */
						  strcpy(middle,msg.to);
						  turn_spaces_to_uls(middle);
						  strcat(pp,middle);
						  break;
			 case 't':	  strcat(pp,msg.to);
						  break;
			 case 'd':	  strcat(pp,msg.date);
						  break;
			 case 'D':	  /* Msg Date */
						  strcpy(middle,msg.date);
						  turn_spaces_to_uls(middle);
						  strcat(pp,middle);
						  break;
			 case 'N':	  strcat(pp,currarea->name);
						  break;
			 case 'A':    /* Area Name */
						  strcpy(middle,currarea->name);
						  turn_spaces_to_uls(middle);
						  strcat(pp,middle);
						  break;
			 case '#':	  sprintf(middle,"%u",messno);
						  strcat(pp,middle);
						  break;
			 case 'a':	  sprintf(middle,"%u",areano);
						  strcat(pp,middle);
						  break;
			 case 'P':	  strcat(pp,path);
						  break;
			 default:     strcat(pp,"*");
						  p--;
						  break;
		   }
		}
		else {
			*pp=*p;
			pp[1]=0;
			p++;
		}
		while(*pp)pp++;
   }
   return (cvstr);
}



void pascal turn_spaces_to_uls (char *a) {

    char *p;

    while (p=strchr(a,' ')) *p='_';
}

