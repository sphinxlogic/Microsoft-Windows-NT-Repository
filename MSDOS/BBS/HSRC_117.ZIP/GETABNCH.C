/* Does 'threading', finds personal msgs, etc. very fast */

#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"

extern WINDOW *ewnd;



word pascal get_abunch (word messno,char type,int direction,char *str) {

 register word x=0;
 register int y;
 int handle;
 int handle2;
 char finished=0;
 word temp;
 static struct _xmsg msgs[5];
 char once;
 char keyhit;

 if(type==1) {
	rstrip(str);
	if(!strnicmp(str,"RE: ",4)) memmove(str,&str[4],strlen(&str[4])+1);
	if(!*str || !str) return 0;
 }
 if(direction>=0) {
	messno++;
	direction=1;
 }
 else direction=(-1);
 sprintf(filename,"%sXDATA.%03x",path,areano);
 while ((handle=_open(filename,O_RDONLY | O_BINARY | O_DENYNONE))==-1) {
	 if (errno==EACCES) {
		x++;
		if(x>2) {
			error_message(" Can't get access ");
			return 0;
		}
		any_message(" Awaiting access ");
		sleep(1);
	 }
	 else  {
		error_message(" Can't open datafile ");
		return 0;
	 }
 }
 if(direction<0) {
	if(messno>6){
		x=5;
		messno-=5;
	}
	else {
		x=messno-1;
		messno=1;
	}
 }
Loop:
 if(kbhit()) {
	keyhit=get_char();
	if(keyhit==' ' || keyhit==ESC) {
		_close(handle);
		return 0;
	}
 }
 if(direction>0) {
	x=(word)(filelength(handle)/(long)sizeof(struct _xmsg));
	if(messno>x || finished) {
		_close(handle);
		return 0;
	 }
     if((x-messno)<6) x-=(messno-1);
	 else x=5;
 }
 if(ewnd) {
	wcursor(ewnd,17,0);
	wprintf(ewnd,"%-5u",messno);
 }

Skip:
 if ((lseek(handle,(long)((long)(messno-1)*(long)sizeof(struct _xmsg)),SEEK_SET)==(-1)) || ((temp=(_read(handle,&msgs,(int)(x * sizeof(struct _xmsg)))))<1)) {
	if (eof(handle)==(-1)) perror ("\nSEEK OR READ ERROR");
	_close(handle);
	return 0;
 }
 if((temp/sizeof(struct _xmsg))<x)x=temp/sizeof(struct _xmsg);
 if(direction<0)y=x-1;
 else y=0;
 if(type==0) {  /* Personal mail check */
#ifdef DEBUG
	printf("\nx=%u  y=%u  dir=%d",x,y,direction);
#endif
	while(1) {
		if((msgs[y].m_attr & MSGDELETED) || (msgs[y].attr & MSGREAD)) goto NoGot;
#ifdef DEBUG
	printf("\nx=%u  y=%u  dir=%d",x,y,direction);
#endif
			rstrip(msgs[y].to);
			if (userno==1 && !stricmp(msgs[y].to,"SYSOP")) goto GotIt;
			if (noalias) {
				for (handle2=0;handle2<(int)noalias;handle2++) {
					if (!stricmp(rstrip(alias[handle2]),msgs[y].to)) goto GotIt;
				}
			goto NoGot;
			}
GotIt:
			_close(handle);
			return (messno+y);
NoGot:
		y+=(direction);
		if(direction<0) {
			if(y<0) break;
		}
		else if(y>=x) break;
	}
 }
 else if (type==1) { /* Subject check */
	temp=(word)strlen(str);
	while(1) {
		if (msgs[y].m_attr & MSGDELETED) goto NoGot2;
		rstrip(msgs[y].subj);
		if(!strnicmp(msgs[y].subj,"RE: ",4)) memmove(msgs[y].subj,&msgs[y].subj[4],strlen(&msgs[y].subj[4])+1);
		handle2=(int)temp;
		if(temp>24) {
			if(strlen(msgs[y].subj)<(int)temp) handle2=strlen(msgs[y].subj);
			if(handle2<24) handle2=temp;
		}
		if(!strnicmp(msgs[y].subj,str,handle2)) {

			_close(handle);
			return (messno+y);
		}
NoGot2:
		y+=(direction);
		if(direction<0) {
			if(y<0) break;
		}
		else if(y>=x) break;
	}
 }
 else if (type==2) { /* Body check */
	 sprintf(filename,"%sXTEXT.%03x",path,areano);
	 temp=0;
	 while ((handle2=_open(filename,O_RDONLY | O_BINARY | O_DENYNONE))==-1) {
		 if (errno==EACCES) {
			temp++;
			if (temp>2) {
				error_message(" Can't get text access ");
				_close(handle);
				return 0;
			}
			any_message(" Awaiting access ");
			sleep(1);
		 }
		 else {
			error_message(" Can't open textfile ");
			_close(handle);
			return 0;
		 }
	 }
	while(1) {
	 if(!msgs[y].length) goto NoGot3;
	 if ((msgs[y].m_attr & MSGDELETED)) goto NoGot3;
	 once=0;
TryThatAgain:
	 if (lseek(handle2,msgs[y].start,SEEK_SET)) {
		 if (eof(handle2)) {
			if (once<2) {
				once++;
				goto TryThatAgain;
			}
			perror (" TEXT SEEK ERROR");
			goto NoGot3;
		 }
	 }
	 *buffer=0;
	 temp=510;
	 if(temp>(msgs[y].length-1)) temp=msgs[y].length-1;
	 temp=_read(handle2,buffer,temp);
	 buffer[temp+1]=0;
	 if(stristr(buffer,str)) {
		_close(handle);
		_close(handle2);
		return (messno+y);
	 }
NoGot3:
	 y+=(direction);
	 if(direction<0) {
		if(y<0) break;
	 }
	 else if(y>=x) break;
}
	_close(handle2);
 }
 if(direction>0) {
	if((long)(messno+x)>65535L) finished++;
	else messno+=x;
 }
 else {
	if((long)(messno-x)<=0L) {
		_close(handle);
		return 0;
	}
	else messno-=x;
	if (messno>5) x=5;
 }
 goto Loop;
}



word pascal thread (char which,char *body) {

    word tempmess;
    int  direction;

    if (nomess<=1) return 0;
    tempmess=messno;
    if (messno>=nomess) which='B';
    if (messno<=1) which='F';
    if (which!='B' && which!='F') which='F';
    if(which=='B')  direction=(-1);
    else direction=1;
    if(!*body || !body) {
        any_message(" Match Scanning:       ");
        messno=get_abunch(messno,1,direction,msg.subj);
    }
    else {
        any_message(" Link Scanning:        ");
        messno=get_abunch(messno,2,direction,body);
    }
    if(!messno) {
        messno=tempmess;
        any_message(" No Thread ");
		pause();
		return 0;
    }
    else clear_message();
    return messno;
}


int pascal isbrktquote (char *line) {

    register char *p;
    register int x=0;

	p=line;
	while(*p && x<6) {	/* Is there a > in the first 6 chars? */
		if(*p=='<') return 0;	/* Maybe <grin> */
		if(*p=='>') return 1;	/* Yep */
        p++;
        x++;
	}
	return 0;	/* Nope */
}


char * pascal make_ansi (char fore, char back) {

	static char scratch[24];
    static char *fa[16]={"2;30","2;34","2;32","2;36","2,31","2,35","2,33",
                         "2;37","1;30","1;34","1;32","1;36","1;31","1;35",
                         "1;33","1;37"};
	static char *ba[7]={"40","44","42","45","41","46","43"};
	char *p,*pp;

	if((fore<1 || fore > 16) || (back<1 || back>7)) {  /* Error checking */
        fore=WHITE;
        back=BLACK;
	}
	else {
		fore--;
		back--;
	}
	strcpy(scratch,"\x1b[0;");
	p=&scratch[4];
	pp=fa[fore];
	while(*pp) {
		*p = *pp;
		p++;
		pp++;
	}
	*p=';';
	p++;
	pp=ba[back];
	while(*pp) {
		*p = *pp;
		p++;
		pp++;
	}
	*p='m';
	p++;
	*p=0;
	return scratch;
}
