#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"


char * pascal next_one(char *,char);

void pascal load_areas (void) {

    register int x;
    int fp;
    struct ffblk f;
    static char string[256];
    word tempareas=0;
    char *p,*pp;
    word zone,net,node,point;

	if(!strchr(msgareas,'/') && !strchr(msgareas,'\\') && !strchr(msgareas,':')) sprintf(string,"%s%s",path,msgareas);
	else strcpy(string,msgareas);
	if(findfirst(string,&f,0)) strcpy(string,searchpath(msgareas));
    if (findfirst(string,&f,0)) return;
    if((fp=(_open(string,O_DENYNONE | O_TEXT | O_RDONLY)))==-1) {
        error_message(" Can't open MSGAREAS.XBS ");
        return;
    }
    while (!eof(fp)) {
        if (!fgetsx(string,255,fp)) break;
        if (*string=='\n' || *string==';') continue;
        maxareas++;
    }
    lseek(fp,0L,SEEK_SET);
    marea=(struct _marea far*)farmalloc((maxareas+1)*sizeof(struct _marea));
    if (marea==NULL) {
        error_message(" No memory for areas ");
        maxareas=0;
        _close(fp);
        return;
    }
	for(x=0;x<maxareas;x++) marea[x].name=NULL;
	while (!eof(fp) && tempareas<maxareas+1) {
        if (!fgetsx(string,255,fp)) break;
        if (*string=='\n' || *string==';') continue;
        stripcr(string);
		marea[tempareas].name=strdup(strtok(string,","));
		marea[tempareas].attr=(word)atoi(strtok(0," ,"));
        marea[tempareas].max=(word)atoi(strtok(0," ,"));
        marea[tempareas].number=(word)atoi(strtok(0," ,"));
		if(!marea[tempareas].name) {
			sprintf(string," No memory for name of area %u",marea[tempareas].number);
			error_message(string);
			sleep(1);
			for(x=0;x<tempareas;x++) {
				if(marea[x].name) free(marea[x].name);
			}
			maxareas=0;
			_close(fp);
			farfree((void far *)marea);
			marea=NULL;
			return;
		}
        marea[tempareas].thisaddr=0;    /* Defaults */
        marea[tempareas].thisname=0;
        p=strtok(0," ,");
        p=strtok(0," ,");
        pp=strtok(0,"\n");
		if(!pp) goto AllForThatOne;
		for(x=0;x<5;x++) {
			p=NULL;
			if(*pp!=',') {
				p=pp;
				while(*pp!=',' && *pp!=0) pp++;
				if(*pp!=0){
					*pp=0;
					pp++;
				}
			}
			else pp++;
		}
        if(p) {
            zone=(word)atol(p);
            p=next_one(p,':');
            net=(word)atol(p);
            p=next_one(p,'/');
            node=(word)atol(p);
            p=next_one(p,'.');
            point=(word)atol(p);
			for(x=0;x<(word)noaddress;x++) {
                if(zone==address[x]->zone && net==address[x]->net && node==address[x]->node && point==address[x]->point) {
					marea[tempareas].thisaddr=(x+1);
                    break;
                }
            }
		}
		p=NULL;
		if(*pp!=',') {
			p=pp;
			while(*pp!=',' && *pp!=0) pp++;
			if(*pp!=0){
				*pp=0;
				pp++;
			}
		}
		else pp++;
		if(p) {
			for(x=0;x<(word)noalias;x++) {
				if(!stricmp(alias[x],p)) {
					marea[tempareas].thisname=(x+1);
					break;
				}
			}
		}
AllForThatOne:
		if (marea[tempareas].number>higharea) higharea=marea[tempareas].number;
        tempareas++;
    }
    if (tempareas<maxareas) maxareas=tempareas;
    _close(fp);
}


char * pascal next_one (char *p,char delim) {

    while(*p && *p!=delim) p++;
    if(*p)p++;
    return p;
}
