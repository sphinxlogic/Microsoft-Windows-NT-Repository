/* HeadEdit's '/' pulldown menu */

#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"

extern void pascal edit_node(void);


char *mainselcs[]={
	" Quit/Cont (ESC) ",
	" Toggle Wrap (^W) ",
	" Toggle Origin (^O) ",
	" Edit Default Origin (aO) ",
	" Toggle Kludge Lines (^T) ",
	" Save LMRs (^S) ",
	" Load LMRs (^A) ",
	" Kill Junk (^K) ",
	" Toggle Current Name (aT) ",
	" Toggle Delete View (aD) ",
	" Change Address (aC) ",
	" NodeList Review (aN) ",
	" DOS Shell (aJ) ",
    " Exit NOW (aX) ",
    " Breakdown Echo ",
    " Edit nodelist entry ",
	" Send complaint to author ",
	NULL
};

char *areaselcs[]={
	" Point & Shoot (aA) ",
	" Enter New # (F8) ",
	" Next (>)",
	" Previous (<) ",
	NULL
};

char *postselcs[]={
	" Reply (R) ",
	" Edit Text (F3) ",
	" Edit Hdr (F7) ",
	" New Msg (W) ",
	" Net Reply To Echo Msg (^R) ",
	NULL
};

char *msgselcs[]={
	" Point & Shoot (aL) ",
	" Enter New # (F9) ",
	" Next (^PGDN) ",
	" Previous (^PGUP) ",
	" Thread Forward (^F) ",
	" Thread Back (^B) ",
	" Selective (F6) ",
	" Next Match (^L) ",
	" Delete (^D) ",
	" Node Info. (^N) ",
	" Edit Hdr (F7) ",
	" Export Msg (^E) ",
	" Print Msgs (+) ",
	" Move/Forward (F10) ",
	" Scan Msgs (F2) ",
	" First Msg (^HOME) ",
	" Last Msg (^END) ",
	" View Assoc File (V) ",
	" Reverse Search (^F6) ",
	NULL
};

char *spawnselcs[]={
	"1               ",
	"2               ",
	"3               ",
	"4               ",
	"5               ",
	"6               ",
	"7               ",
	"8               ",
	"9               ",
	"0               ",
	NULL
};

char *saveposselcs[]={
	"Pos 0",
	"Pos 1",
	"Pos 2",
	"Pos 3",
	"Pos 4",
	"Pos 5",
	"Pos 6",
	"Pos 7",
	"Pos 8",
	"Pos 9",
	NULL
};

char *restoreposselcs[]={
	"Pos 0",
	"Pos 1",
	"Pos 2",
	"Pos 3",
	"Pos 4",
	"Pos 5",
	"Pos 6",
	"Pos 7",
	"Pos 8",
	"Pos 9",
	NULL
};


static int mainkeys[]={ ESC,CTRL_W,CTRL_O,ALT_O,CTRL_T,CTRL_S,1,CTRL_K,
                        ALT_T,ALT_D,ALT_C,ALT_N,ALT_J,ALT_X,258,257,256};
static int areakeys[]={ ALT_A,F8, (int)'>', (int)'<' };
static int postkeys[]={ (int)'R',F3,F7,(int)'W',CTRL_R};
static int msgkeys[]= {ALT_L,F9,CTRL_PGDN,CTRL_PGUP,CTRL_F,CTRL_B,
					   F6,CTRL_L,CTRL_D,CTRL_N,F7,CTRL_E,(int)'+',F10,
					   F2,CTRL_HOME,CTRL_END,'V',CTRL_F6};
static int spawnkeys[]={ALT_F1,ALT_F2,ALT_F3,ALT_F4,ALT_F5,ALT_F6,ALT_F7,
						ALT_F8,ALT_F9,ALT_F10};
static int saveposkeys[]={ALT_0,ALT_1,ALT_2,ALT_3,ALT_4,ALT_5,ALT_6,ALT_7,
						  ALT_8,ALT_9};
static int restoreposkeys[]={(int)'0',(int)'1',(int)'2',(int)'3',(int)'4',
							 (int)'5',(int)'6',(int)'7',(int)'8',(int)'9'};

static KMENU tmn[]={
	{" Msgs ",msgselcs,msgkeys},
	{" Areas ",areaselcs,areakeys},
	{" Post ",postselcs,postkeys},
	{" Spawn ",spawnselcs,spawnkeys},
	{" Save Pos ",saveposselcs,saveposkeys},
	{" Rstr Pos ",restoreposselcs,restoreposkeys},
	{" Misc ",mainselcs,mainkeys},
	{NULL,NULL,NULL}
};


int pascal exec (void) {

    register int x;

	for(x=0;x<10;x++) {
		if(!fkey[x]) strcpy(spawnselcs[x]," Unused ");
		else {
			strcpy(spawnselcs[x]," ");
			if(!strnicmp(fkey[x],"COMMAND.COM /C",14)) {
				strncat(spawnselcs[x],&fkey[x][15],13);
			}
			else strncat(spawnselcs[x],fkey[x],13);
			spawnselcs[x][14]=0;
			strcat(spawnselcs[x]," ");
			spawnselcs[x][15]=0;
		}
	}
    x=kmenu_select(" You rang? ",tmn);
    if(x==256) {
		printf("\x1b[2J\n\x1b[0;2;37m $0.00 <=-Here's your refund.  Don't use it anymore.\n");
        exit(255);
    }
	else if(x==257) {
		edit_node();
		return 0;
	}
    else if(x==258) {
        do_breakdown();
        return 0;
    }
    return x;
}

