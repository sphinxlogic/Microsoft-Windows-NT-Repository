#include <msgg.h>
#include <twindow.h>
#include <keys.h>
#include "headedit.h"
#include "headid.h"

extern word vbase;
extern word maxx;
extern word maxy;
extern char current_color;
extern word videomethod;
extern WINDOW *ewnd;

extern long make_msgid (void);


void pascal post_mess (char *fname) {

 char *p;
 char message[133];
 word lenmess;
 struct date dos_date;
 int handlem;
 int handlet;
 int handlef;
 long mlen;
 long tlen;
 long flen;
 struct ffblk f;
 char level=0;
 char temp;
 struct _carbon *carbon[20]={NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
							 NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL};
 char numcarbons=0;
 WINDOW *carbwnd=NULL;
 struct _bomb_addr *bomb_addr=NULL;
 char lastnumcarbons=0;


EditSomeMore:

 if (!*fname) {
	 strcpy(message,"MSGTMP");
 }
 else strcpy(message,fname);
 *filename=0;
 if ((currarea->attr & ANSI) && ansieditor) strcpy(filename,ansieditor);
 else if (editor) strcpy(filename,editor);
 if(*filename) {
	do_spawn(filename);
 }
 else {
	if(template) {
		strcpy(filename,template);
		do_spawn(filename);
	}
	strcpy(notefile,"MSGTMP");
	notepad();
 }

 if (findfirst(message,&f,0)) level=1;
 else if (f.ff_fsize<3L) level=1;

 if (!level) {
AskAgain:
	set_help ("atpost    ",0,22);
	show_header(0);
	if(carbon) {

		int register x;

		if(lastnumcarbons!=numcarbons) {
			if(carbwnd)	delete_window(carbwnd);
			if((currarea->attr & NET) || (currarea->attr & ALTERNATE)) {
				carbwnd=establish_window(1,maxy-24,21,70);
			}
			else carbwnd=establish_window(1,maxy-24,21,40);
			set_border(carbwnd,3);
			set_title(carbwnd," Carbons ");
			set_colors(carbwnd,BORDER,7,0,0);
			display_window(carbwnd);
			wcursor(carbwnd,0,0);
			for(x=0;x<numcarbons;x++) {
				if((currarea->attr & NET) || (currarea->attr & ALTERNATE)) {
					wprintf(carbwnd," %-36s (%u:%u/%u.%u) %d\x9b",carbon[x]->name,carbon[x]->zone,carbon[x]->net,carbon[x]->node,carbon[x]->point);
				}
				else wprintf(carbwnd," %s",carbon[x]->name);
				if(x<numcarbons-1)wprintf(carbwnd,"\n");
			}
			lastnumcarbons=numcarbons;
		}
	}
    if (msg.d_zone!=msg.o_zone && ((currarea->attr & NET) || (currarea->attr & ALTERNATE))) {
		sprintf(filename," (%u:%u/%u): [S]ave, [A]bort, [C]arbons, [B]omb or [E]dit Header? [S] ",msg.d_zone,msg.dest_net,msg.dest);
        any_message(filename);
	}
	else if(msg.d_zone==msg.o_zone && msg.dest==msg.orig && msg.dest_net==msg.orig_net && msg.d_point==msg.o_point && ((currarea->attr & NET) || (currarea->attr & ALTERNATE))) {
		any_message(" (Misaddressed?) [S]ave, [A]bort, [C]arbons, [B]omb or [E]dit Header? [S] ");
	}
	else if((currarea->attr & NET) || (currarea->attr & ALTERNATE)) {
		any_message("[S]ave, [A]bort, [C]arbons, [B]omb or [E]dit Header? [S] ");
	}
	else if(!(currarea->attr & ECHO) && !(currarea->attr & ALTECHO)) {
		any_message(" [S]ave, [A]bort, [C]arbons or [E]dit Header? [S] ");
	}
	else any_message(" [S]ave, [A]bort, or [E]dit Header? [S] ");
	temp=toupper(generic_mouse_input(ewnd));
	switch ((int)temp) {
		case CTRL_R: clear_message();
					 goto EditSomeMore;
		case ALT_O:  get_origin();
                     goto AskAgain;
        case CTRL_O: usedefault=1-usedefault;
                     if(usedefault) any_message(" Always using default origin line");
                     else any_message(" Looking up origin lines in ORIGINS.BBS ");
                     pause();
                     goto AskAgain;
        case CTRL_W: wrapit=1-wrapit;
                     if(wrapit || !wrapcall) _anymsg(" Toggled Wrapping "," OFF ");
                     else _anymsg(" Toggled Wrapping "," ON ");
                     pause();
                     goto AskAgain;
        case 13:
		case 'S':	break;
		case 'A':	level=1;
					get_rid();
					if(carbwnd)delete_window(carbwnd);
					if(numcarbons) {

						int register x;

						for(x=0;x<numcarbons;x++) if(carbon[x])free(carbon[x]);
					}
					if(bomb_addr)free(bomb_addr);
					return;
		case 'E':   clear_message();
					edit_mess(2);
					goto AskAgain;
		case 'C':   if((currarea->attr & ECHO) || (currarea->attr & ALTECHO)) goto AskAgain;
					if(numcarbons>18) {
						error_message(" Max # of carbons in use--Delete one ");
						nopause();
						goto AskAgain;
					}
					carbon[numcarbons]=(struct _carbon *)malloc(sizeof(struct _carbon));
					if(!carbon[numcarbons]) {
						error_message(" Insufficient memory for carbon ");
						pause();
						goto AskAgain;
					}
					if(!fill_in_carbon(carbon[numcarbons])) {
						free(carbon[numcarbons]);
					}
					else numcarbons++;
					goto AskAgain;
		case 'D':	if(!numcarbons) goto AskAgain;
					else {

						int x;
						int y;

						any_message(" Select carbon.  [Enter] deletes, ESC aborts ");
						sleep(1);
						set_help("delcarbon ",0,23);
						clear_message();
						x=get_selection(carbwnd,numcarbons,NULL);
						if(x && x<numcarbons+1) {
							for(y=(x-1);y<numcarbons;y++) {
								memcpy(carbon[y],carbon[y+1],sizeof(struct _carbon));
							}
							if(carbon[numcarbons-1])free(carbon[numcarbons-1]);
							numcarbons--;
						}
					}
					set_help ("atpost    ",0,23);
					goto AskAgain;
		case 'B':	if((!(currarea->attr & NET) && !(currarea->attr & ALTERNATE)) || !nidxsize || numcarbons) goto AskAgain;
					bomb_addr=(struct _bomb_addr *)malloc(sizeof(struct _bomb_addr *));
					if(!bomb_addr) {
						error_message(" Insufficient memory for bomb run ");
						pause();
						goto AskAgain;
					}
					if(!bomb_who(bomb_addr)) {
						free(bomb_addr);
						bomb_addr=NULL;
						goto AskAgain;
					}
					break;
		default:	goto AskAgain;
	}
 }
 clear_message();
 if(carbwnd) delete_window(carbwnd);
 if (level) {
	if (editor) {
		any_message(" Aborted--Any Key ");
		pause();
	}
    get_rid();
	if(numcarbons) {

		int register x;

		for(x=0;x<numcarbons;x++) if(carbon[x])free(carbon[x]);
	}
	if(bomb_addr)free(bomb_addr);
    return;
 }
 if (wrapcall && !wrapit && editor && !(currarea->attr & ANSI)) {
	do_spawn(wrapcall);
 }
 sprintf(filename,"%sXDATA.%03x",path,areano);
 sprintf(textname,"%sXTEXT.%03x",path,areano);

AccessLoop1:
  if (findfirst(filename,&f,0)) flen=0;
  else flen=f.ff_fsize;
  if ((handlef=_open(filename,O_RDWR | O_BINARY | O_DENYNONE))==-1) {
		if (errno==EACCES) {
			any_message(" Awaiting access... ");
			goto AccessLoop1;
		}
		if((handlef=creat(filename,S_IWRITE))==-1) {
			error_message(" Can't open message base ");
			pause();
            get_rid();
			if(numcarbons) {

				int register x;

				for(x=0;x<numcarbons;x++) if(carbon[x])free(carbon[x]);
			}
			if(bomb_addr)free(bomb_addr);
            return;
		}
  }
  clear_message();
  lock(handlef,flen,(long)sizeof(struct _xmsg));
  lseek(handlef,0L,SEEK_END);

AccessLoop:
  if (findfirst(textname,&f,0))tlen=0;
  else tlen=f.ff_fsize;
  if ((handlet=_open(textname,O_RDWR | O_BINARY | O_DENYNONE))==-1) {
	if (errno==EACCES) {
		any_message(" Awaiting access... ");
		goto AccessLoop;
	}
	if((handlet=creat(textname,S_IWRITE))==-1) {
		error_message(" Can't open message files ");
		_close(handlef);
		pause();
        get_rid();
		if(numcarbons) {

			int register x;

			for(x=0;x<numcarbons;x++) if(carbon[x])free(carbon[x]);
		}
		if(bomb_addr)free(bomb_addr);
		return;
	  }
  }
  clear_message();
  lock(handlet,tlen,65535L);
  lseek(handlet,0L,SEEK_END);

 lenmess=0;

 if (!*fname) {
	 strcpy(message,"MSGTMP");
 }
 else strcpy(message,fname);

 if (findfirst(message,&f,0)) mlen=0;
 else mlen=f.ff_fsize;
 if ((handlem=_open(message,O_RDONLY | O_BINARY | O_DENYNONE))==-1) {
   error_message(" Read error...lost ");
   _close(handlef);
   _close(handlet);
   pause();
   if(numcarbons) {

	  int register x;

	   for(x=0;x<numcarbons;x++) if(carbon[x])free(carbon[x]);
   }
   if(bomb_addr)free(bomb_addr);
   return;
 }
 lock(handlem,0,mlen);
 msg.start=tell(handlet);
 lenmess=0;

 if ((currarea->attr & NET) || (currarea->attr & ALTERNATE)) {

	char mydomain[37];
	char yourdomain[37];

	if (msg.o_point && !nopt)
		lenmess+=ffprintf(handlet,"\01FMPT %01u\r",msg.o_point);

    strcpy(mydomain,curaddress.domain);
	strcpy(yourdomain,to_domain);

	if(msg.d_point && !nopt) lenmess+=ffprintf(handlet,"\01TOPT %01u\r",msg.d_point);

    if (msg.o_zone!=msg.d_zone && msg.d_zone && msg.o_zone && !nointl)
		lenmess+=ffprintf(handlet,"\01INTL %u:%u/%u %u:%u/%u\r",msg.d_zone,msg.dest_net,msg.dest,msg.o_zone,msg.orig_net,msg.orig);

    if(stricmp(mydomain,yourdomain) && !nointl)
        lenmess+=ffprintf(handlet,"\01DOMAIN %s %u:%u/%u.%u %s %u:%u/%u.%u\r",yourdomain,msg.d_zone,msg.dest_net,msg.dest,msg.d_point,mydomain,msg.o_zone,msg.orig_net,msg.orig,msg.o_point);
 }

 lenmess+=ffprintf(handlet,"\01MSGID: %u:%u/%u.%01u@%s %lx\r",msg.o_zone,msg.orig_net,msg.orig,msg.o_point,curaddress.domain,make_msgid());
 if(*replyid) {
	lenmess+=ffprintf(handlet,"\01REPLY: %s\r",replyid);
	*replyid=0;
 }

 if (((currarea->attr & NET) || (currarea->attr & ALTERNATE)) && !numcarbons && !bomb_addr) {
	lenmess+=ffprintf(handlet,"\01MSGTO: %u:%u/%u.%01u@%s\r",msg.d_zone,msg.dest_net,msg.dest,msg.d_point,to_domain);
 }

 if(((currarea->attr & ECHO) || (currarea->attr & ALTECHO)) && (currarea->attr & NOORIG)) {
	lenmess+=ffprintf(handlet,"\01PID: %s\r",PID_ID);
 }

 if(*assocfile && (currarea->attr & ASSOC)) lenmess+=ffprintf(handlet,"\01ASSOC: %s\r",assocfile);
 *assocfile=0;

 while(!eof(handlem)) {
   if (!fgetsx(message,81,handlem)) break;
   while (p=strstr(message,"\r\n")) memmove(&p[1],&p[2],strlen(&p[2])+1);
   while (p=strchr(message,'\n')) *p='\r';
   while (p=strstr(message," \x8d")) memmove(&p[1],&p[2],strlen(&p[2])+1);
   while (p=strchr(message,'\x8d')) *p=' ';
   while (p=strchr(message,'\x1a')) memmove(p,&p[1],strlen(&p[1])+1);
   lenmess+=strlen(message);
   ffprintf(handlet,"%s",message);
   if(lenmess>65100) break;
 }
 unlock(handlem,0,mlen);
 _close(handlem);
 msg.m_attr |= MSGTREATED;

 if(currarea->attr & ANSI) lenmess+=ffprintf(handlet,"\x1b[23;1H\r\n");

 if (((currarea->attr & ECHO) || (currarea->attr & ALTECHO)) && !(currarea->attr & NOORIG)) {
   if(!usedefault) {

	   char noorigin=0;
	   char notear=0;

	   sprintf(message,"%sORIGINS.BBS",path);
	   if((handlem=_open(message,O_RDONLY | O_TEXT | O_DENYNONE))==-1) {
			goto SkipOrigins;
	   }
	   while (!eof(handlem) && (word)atol(message)!=currarea->number) {
		  if(!fgetsx(message,81,handlem)) break;
		  message[66]=0;
		  stripcr(message);
       }
	   _close(handlem);
	   if ((word)atol(message)!=currarea->number) {
			goto SkipOrigins;
	   }
       strtok(message,"; ");
	   stripcr(message);
	   if(!strcmp(message,"NOORIGIN")) {
			noorigin++;
	   }
	   else if (!strncmp(message,"NOTEAR",6)) {
			notear++;
			strtok(0," ");	/* Rest is origin */
	   }
	   else if (!strcmp(message,"NOORIGIN/NOTEAR")) {
			notear++;
			noorigin++;
	   }
	   if(!notear) {
			lenmess+=ffprintf(handlet,"%s",HEADID);
	   }
	   if(!noorigin) {
		   if(msg.o_point)lenmess+=(ffprintf(handlet,"%s%s (%u:%u/%u.%01u)\r",ORIGTXT,strtok(0,"\n"),msg.o_zone,msg.orig_net,msg.orig,msg.o_point));
		   else lenmess+=(ffprintf(handlet,"%s%s (%u:%u/%u)\r",ORIGTXT,strtok(0,"\n"),msg.o_zone,msg.orig_net,msg.orig));
	   }
	   if(noorigin) {
			ffprintf(handlet,"\r");
			lenmess++;
	   }
	   goto GotOrigin;
   }
SkipOrigins:
   if(msg.o_point)lenmess+=(ffprintf(handlet,"%s%s%s (%u:%u/%u.%01u)\r",HEADID,ORIGTXT,origin,msg.o_zone,msg.orig_net,msg.orig,msg.o_point));
   else lenmess+=(ffprintf(handlet,"%s%s%s (%u:%u/%u)\r",HEADID,ORIGTXT,origin,msg.o_zone,msg.orig_net,msg.orig));
 }
 else {
	ffprintf(handlet,"\r");
	lenmess++;
 }

GotOrigin:

 if(numcarbons) {   /* Add carbons to end */

    int register x;

    lenmess+=ffprintf(handlet,"Original: %s\r",msg.to);
    for(x=0;x<numcarbons;x++) {
		lenmess+=ffprintf(handlet,"CC:       %s\r",carbon[x]->name);
    }
 }

   _write(handlet,"\0",1);
   msg.length=lenmess+2;
   unlock(handlet,tlen,65535L);
   strcpy(msg.date,fidodate());
   getdate(&dos_date);
   msg.indate[0]=dos_date.da_year-1989;
   msg.indate[1]=dos_date.da_mon;
   msg.indate[2]=dos_date.da_day;
   msg.indate[3]=0;
   msg.times=0;

   if((currarea->attr & COMPRESS) && msg.length>packsize) {

        char *hold;

        hold=(char *)malloc(msg.length+1);
        if(!hold) {
			error_message(" Can't malloc memory to compress ");
			pause();
		}
        else {
            lseek(handlet,msg.start,SEEK_SET);
			if(_read(handlet,hold,msg.length)<(msg.length-1)) {
				error_message(" Can't compress ");
				pause();
			}
			else {
				hold[msg.length-1]=0;
				hold[msg.length]=0;
				if(strlen(hold)>packsize) {
					hold=pack_msg(hold);
					if(!hold) {
					   error_message(" Compression failed ");
					   pause();
					}
					else {
						lseek(handlet,msg.start,SEEK_SET);
						msg.m_attr = msg.m_attr | MSGPACKED;
						_write(handlet,hold,msg.length);
						free(hold);
					}
				}
				else {
					free(hold);
				}
			}
	   }
   }

   _close(handlet);

   if(bomb_addr) {

		long x;

		for (x=0;x<(nidxsize+1);x++) {
			if (nidx[x].zone==bomb_addr->zone && nidx[x].net==bomb_addr->net) break;
		}
		if(x>nidxsize) {
			error_message(" Lost it in the sun... ");
			pause();
			goto AfterBomb;
		}
		unlock(handlef,flen,(long)sizeof(struct _xmsg));
		while(x<nidxsize && nidx[x].zone==bomb_addr->zone && nidx[x].net==bomb_addr->net) {
			sprintf(message," Bombing %u:%u/%u... ",nidx[x].zone,nidx[x].net,nidx[x].node);
			any_message(message);
			msg.dest=nidx[x].node;
			msg.dest_net=nidx[x].net;
			msg.d_zone=nidx[x].zone;
			lseek(handlef,0L,SEEK_END);
			flen=tell(handlef);
			lock(handlef,flen,(long)sizeof(struct _xmsg));
			_write(handlef,&msg,sizeof(struct _xmsg));
			unlock(handlef,flen,(long)sizeof(struct _xmsg));
			x++;
		}
		clear_message();
		goto AfterBomb;
   }

   lseek(handlef,0L,SEEK_END);
   _write(handlef,&msg,sizeof(struct _xmsg));
   unlock(handlef,flen,(long)sizeof(struct _xmsg));
   if (!findfirst(filename,&f,0)) {
	   if ((word)(f.ff_fsize/(long)sizeof(struct _xmsg)) > currarea->max) {

			struct _xmsg msgtwo;
			long pos;

		 lseek(handlef,(f.ff_fsize-((long)(currarea->max)-1L)*(long)sizeof(struct _xmsg)),SEEK_SET);
		 pos=tell(handlef);
		 if (_read(handlef,&msgtwo,sizeof(struct _xmsg))>1) {
			 if (!(msgtwo.m_attr & MSGKEEP)) {
				 msgtwo.m_attr = msgtwo.m_attr & (~MSGDELETED);
				 lseek(handlef,pos,SEEK_SET);
				 _write(handlef,&msgtwo,sizeof(struct _xmsg));
			 }
		 }
	   }
   }
   if(numcarbons) {

		int register x;

		for(x=0;x<numcarbons;x++) {
			lseek(handlef,0L,SEEK_END);
			flen=tell(handlef);
			lock(handlef,flen,(long)sizeof(struct _xmsg));
			strcpy(msg.to,carbon[x]->name);
			if((currarea->attr & NET) || (currarea->attr & ALTERNATE)) {
				strcpy(msg.to,carbon[x]->name);
				msg.d_zone=carbon[x]->zone;
				msg.d_point=carbon[x]->point;
				msg.dest=carbon[x]->node;
				msg.dest_net=carbon[x]->net;
				msg.cost=carbon[x]->cost;
				sprintf(message," CC: %s (%u:%u/%u.%u)",carbon[x]->name,carbon[x]->zone,carbon[x]->net,carbon[x]->node,carbon[x]->point);
			}
			else {
				sprintf(message," CC: %s ",carbon[x]->name);
			}
			any_message(message);
			_write(handlef,&msg,sizeof(struct _xmsg));
			unlock(handlef,flen,(long)sizeof(struct _xmsg));
		}
		clear_message();
   }
AfterBomb:
   _close(handlef);
   nomess=check_area(areano);
   messno=nomess;
   get_rid();
   posts++;

   if(numcarbons) {

	  int register x;

	   for(x=0;x<numcarbons;x++) if(carbon[x])free(carbon[x]);
   }
   if(bomb_addr)free(bomb_addr);
}
