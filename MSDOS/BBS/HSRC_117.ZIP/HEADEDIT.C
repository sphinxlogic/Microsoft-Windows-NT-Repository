/* XBBS Message Base Reader (C BASES ONLY) for SYSOPS (HeadEdit) */

#include <msgg.h>
#include <twindow.h>
#include <keys.h>
#include "headid.h"

char msk78[]="______________________________________________________________________________";
#define msk35 msk78+43
#define mskst msk35+33
#define mskzip msk35+30
#define mskcit msk35+11
#define msk1 msk78+77
#define msk3 msk35+32
#define msk5 msk35+30
#define msk6 msk35+29
#define msk47 msk78+31
#define msk51 msk78+28
#define msk65 msk78+13
#define msk19 msk78+59
#define msk58 msk78+20
#define msk10 msk78+68

#define QUOTE    1
#define TEXTFILE 0
#define EDITIT   2
#define PRINTIT  4
#define ECHO2NET 8
#define NOQUOTE  16
#define NOINFO	 64
#define INFOONLY 128

#define nopause nopause_msg
#define pause pause_msg

extern void   pascal CLEAROVERLAY(void);
extern char * pascal get_string (char *text,char len,char *deflt,char type);
extern void   pascal show_header (char quick);
extern void   pascal do_spawn (char *dostring);
extern void	  pascal notepad(void);
extern int    pascal bomb_who (struct _bomb_addr *bomb_addr);
extern int    pascal fill_in_carbon (struct _carbon *carbon);
extern int    pascal exec (void);
extern word   pascal get_abunch (word messno,char type,int direction,char *str);
extern int    cdecl  ffprintf(int,char *,...);
extern char * pascal fgetsx(char *,int,int);
extern word   pascal list_areas(void);
extern void   pascal killjunk(void);
extern char   pascal isitme (char);
extern void   pascal import_mail(void);
extern void   pascal export_mail(void);
extern void   pascal node_lister (void);
extern int    pascal nodelist (struct nodeidx *,char);
extern void   pascal make_file (void);
extern char * pascal rstrip (char *);
extern word   pascal list_mess(void);
extern char * pascal lstrip (char *);
extern char * pascal convertstring (char *a);
extern char * pascal saydate (struct date*);
extern char * pascal saytime (struct time*);
extern char * pascal getdttm (void);
extern void   pascal right (char *,char *,int);
extern void   pascal mid (char *,char *,int,int);
extern void   pascal info (void);
extern char * pascal fidodate (void);
extern char * pascal stripcr (char *);
extern void   pascal left (char *,char *,int);
extern int    pascal export (char *,char,char,char *,char *,void *);
extern char   pascal spawnit (char *);
extern int    cdecl  break_handler (void);
extern int    pascal edit_mess (char);
extern word   pascal check_area (word);
extern void   pascal get_mess (char);
extern void   pascal put_mess (void);
extern word   pascal select_mess (void);
extern word   pascal select_area (void);
extern void   pascal read_control (char *,char *);
extern char * pascal get_qstring (char *);
extern word   pascal find_filearea (void);
extern void   pascal select_name (void);
extern char * pascal mci (char *);
extern void   pascal printer (void);
extern int    pascal doswap (char far *, char far *);
extern void   pascal load_lastread(void);
extern void   pascal save_lastread(void);
extern void   pascal switch_dirs(void);
extern void   pascal strip_seenbys (char *);

extern void   pascal print_clock(void);
extern void   pascal get_rid(void);
extern void   pascal strip_blanklines(char *);
extern char * pascal write_line (char **text,word linelen,char ctla);
extern void   pascal check_pos (void);
extern void   pascal bell (void);
extern void   pascal clrr (void);
extern char * pascal area_attr (void);
extern char * pascal quick_attr (void);
extern word   pascal put_text(char far*,char *,char *,struct ffblk *,char *);
extern word   pascal search (char,char);
extern void   pascal update_read (void);
extern void   pascal move_mess (void);
extern void   pascal post_mess (char *);
extern void   pascal edit_text (void);
extern void   pascal scan_mess (void);
extern word   pascal thread (char,char *);
extern char far *    pascal get_text (void);
extern int    pascal display (word *,char);
extern void   pascal read_mess (char,char);
extern void   pascal cls(int,int,int,int,int);
extern void   pascal select_address (void);
extern void   pascal get_origin (void);
extern char * pascal unpack_msg (char **hold);
extern char * pascal pack_msg (char *hold);
extern void   pascal load_areas (void);
extern int    pascal set_header (char,char *,char *,char *);

/* In this module */

void   pascal menu (void);
void   cdecl  deinit(void);
int    pascal find_area (void);

extern unsigned _Cdecl _stklen = 20480;    /* Stack length */

char dest[6];        /* Destination node                              */
char orig[6];        /* Origination node number                       */
char cost[6];        /* Unit cost charged to send the message         */
char orig_net[6];    /* Origination network number                    */
char dest_net[6];    /* Destination network number                    */
char d_zone[6];      /* Destination zone                              */
char o_zone[6];      /* Origination zone                              */
char d_point[6];     /* Destination point                             */
char o_point[6];     /* Origination point                             */

/* References to window library */

extern int helpkey;
extern WINDOW *ewnd;

/* Structures */

struct _carbon {
	char name[36];
	word zone;
	word net;
	word node;
	word point;
	int  cost;
};
struct _bomb_addr {
	word zone;
	word net;
};
struct _address {
	word zone;
	word net;
	word node;
	word point;
	char domain[37];
};

struct _marea {
	char *name;
	word attr;
	word max;
	word number;
    char thisaddr;
    char thisname;
};

char nobell=1;
char lastmsgid[80]="";
char lastreply[80]="";
char replyid[80]="";
char urgent_text[79]="";
char wrapit=0;
char usedefault=0;
struct _address *address[50];
signed char noaddress;
struct _address curaddress;
char origin[60]="";
char path[99]="";
char autocheck=1;
WINDOW *wnd1=NULL;
WINDOW *wnd4=NULL;
WINDOW *wnd6=NULL;
char buffer[514];
struct _xmsg msg;
struct _xmsg msg2;
char ctla=0;
long nidxsize;
struct nodeidx huge *nidx=NULL;
char huge **line;
word higharea=0;
word areano=0;
word messno=0;
word nomess=0;
word userno=0;
char notrack=0;
struct _marea huge *marea;
struct _marea huge *currarea;
struct _marea nullarea;
word maxareas=0;
word totalareas=0;
word netboard=0;
word altboard=0;
char to_domain[37]="";
char *ansieditor=NULL;
char *template=NULL;
char *wrapcall=NULL;
char *editor=NULL;
char *texteditor=NULL;
char filename[127];
char textname[127];
char *flsearch=NULL;
char filepath[79]="";
char *alias[50];
char *nodepath=NULL;
signed char noalias=0;
char name[36];
word defaultattr=MSGLOCAL+MSGPRIVATE+MSGKILL;
word *lastread;
word posts=0;
char nodirs=0;
char *dirs[50];
char *fkey[10];
char makeinfo=0;
char readtextcolor=11;
char readtextback=0;
char readheadcolor=3;
char readheadback=0;
char readstatcolor=0;
char readstatback=3;
word maxlines=10240;
char filenamer[66]="TEMP";
char quotestring[12]=">";
char pagelength=66;
char topmargin=6;
char bottommargin=6;
char leftmargin=6;
char textwidth=68;
char beforeheader[12]="";
char afterheader[12]="";
char aftertext[48]="";
char afterprinting[12]="\xc";
char *spawnview=NULL;
char swapname[64]="HeadSwap.$#$";
char useswapdisk='C';
char LIMEMS=0;
char swap=0;
char screenwidth=80;
char wasdisplay=0;
char *before_quote=NULL;
char *after_before=NULL;
char *after_quote=NULL;
unsigned int textsize,codesize;
unsigned int packsize=2048;
char hilite=0;
char assocfile[133]="";
char notefile[133]="MSGTMP";
char nopt=0;
char nointl=0;
char noclock=0;
char slowprint;
char inbound[80]="";
char outbound[80]="";
char ismail=0;
char msgareas[98]="MSGAREAS.XBS";
char domail=0;

extern char usemouse;
extern word vbase;
extern word maxx;
extern word maxy;
extern char current_color;
extern word videomethod;

char kludge_fore=2;
char kludge_back=0;
char quote_fore=9;
char quote_back=0;
char tear_fore=1;
char tear_back=0;
char orig_fore=6;
char orig_back=0;
char skipdeleted=0;



void cdecl main (int argc,char *argv[]) {

	union REGS r;

    vbase=(vmode()==7 ? 0xb000: 0xb800);
	fputs("\x1b[2J\x1b[0mLoading help...\n",stderr);
	ctrlbrk(break_handler);
	load_help(searchpath("headedit.hlp"));
#ifdef __80X86__
	fputs("80x86 version  ",stdout);
#endif
	printf("Version %s",PID_ID);

	curaddress.zone=0;
	curaddress.net=0;
	curaddress.node=0;
	curaddress.point=0;
	*curaddress.domain=0;

	atexit(deinit);
	if (argc==2) read_control(argv[1],"");
	else if(argc>=3) read_control(argv[1],argv[2]);
	else read_control(searchpath("HeadEdit.CFG"),"");

    r.h.ah = 0x0f;
    int86(0x10,&r,&r);
    if (maxx == 0)
        maxx = (int) r.h.ah;
    if (maxy == 0) {
        r.x.ax = 0x1130;
        r.x.dx = maxy;
        int86(0x10,&r,&r);
        maxy = (r.x.dx == 0) ? 25 : (r.x.dx + 1);
    }

    if(!noalias || !userno) {
		printf("\nName and/or user # missing in config file!\n");
		exit(1);
	}

	if(*inbound) {
		int x=0;
		struct ffblk f;
		char temp[133];

		sprintf(temp,"%s*.PKT",inbound);
		if(!findfirst(temp,&f,0))x++;
		sprintf(temp,"%s*.MO?",inbound);
		if(!findfirst(temp,&f,0))x++;
		sprintf(temp,"%s*.TU?",inbound);
		if(!findfirst(temp,&f,0))x++;
		sprintf(temp,"%s*.WE?",inbound);
		if(!findfirst(temp,&f,0))x++;
		sprintf(temp,"%s*.TH?",inbound);
		if(!findfirst(temp,&f,0))x++;
		sprintf(temp,"%s*.FR?",inbound);
		if(!findfirst(temp,&f,0))x++;
		sprintf(temp,"%s*.SA?",inbound);
		if(!findfirst(temp,&f,0))x++;
		sprintf(temp,"%s*.SU?",inbound);
		if(!findfirst(temp,&f,0))x++;
		if(x) {
			printf("\n   \x1b[0;1;5;31m   Mail present in inbound directory.\x1b[0m\n");
			sleep(1);
			ismail=1;
		}
	}

	if (noaddress) {
		curaddress.zone=address[0]->zone;
		curaddress.net=address[0]->net;
		curaddress.node=address[0]->node;
		curaddress.point=address[0]->point;
		strcpy(curaddress.domain,address[0]->domain);
	}
	strcpy(to_domain,curaddress.domain);
	if (!*origin) strcpy(origin,"UNKNOWN XBBS");
	if(nodirs)strcpy(path,dirs[0]);
	else *path=0;
	strcpy(name,alias[0]);
	nomess=check_area(areano);
    if(usemouse) fputs("\nMouse detected.",stderr);
    load_lastread();
	fputs("\nLoading areas...",stderr);
	load_areas();
	strcpy(nullarea.name,"Unknown");
	nullarea.attr=0;
	nullarea.max=0;
	nullarea.number=0;
	currarea=&nullarea;
	find_area();

	if(domail) {
		switch ((int)domail) {
			case 1:	import_mail();
					break;
			case 2:	import_mail();
					goto DoEnd;
			case 3:	export_mail();
					break;
			case 4:	export_mail();
					goto DoEnd;
			case 5: import_mail();
					export_mail();
					break;
			case 6: import_mail();
					export_mail();
					goto DoEnd;
		}
	}

	nomess=check_area(areano);
	while (line==NULL && maxlines>256) {
		line=(char huge **)farmalloc((long)sizeof(char *)*(long)(maxlines+1));
		if (line==NULL) {
			maxlines/=2;
			fprintf(stderr,"Cutting # of line pointers to %u     \r",maxlines);
		}
	}
	if (line==NULL) {
		fputs("\nScrew it, not enough memory.\n",stderr);
		get_char();
		exit (1);
	}

DoEnd:

	fputs("\n",stderr);
	clear_message();

	clrr();
	menu();
	clrr();
}


void cdecl deinit (void) {

	int register x;

    for(x=5;x<21;x++) _close(x);
    CLEAROVERLAY();
}



void pascal menu (void) {   /* Main menu */

	int s=1;
	int returncode;
	char keys[]="ACEGINOPRSTWQDL+K! MX#J";
	char middle[133];
	char *p;
	char temppath[43];
	word temp;
	word tempmess;
	word temparea;
	struct ffblk f;
	WINDOW *prime;

	#define LEFTT 6
	#define TOP  1
	#define RIGHTT 67
	#define BOTTOM 25

AllOver:

	clear_message();
	prime=establish_window(LEFTT,TOP,BOTTOM,RIGHTT);
	set_border(prime,1);
	sprintf(middle,"%s"," XBBS Reader copyright (c) 1989/90 by M. Kimes ");
	if(ismail) strcat(middle," * ");
	set_title(prime,middle);
	set_colors(prime,ALL,BLACK,WHITE,BRIGHT);
	set_colors(prime,ACCENT,WHITE,BLACK,BRIGHT);
	set_colors(prime,BORDER,BLACK,GREEN,DIM);
	set_colors(prime,TITLE,BLACK,YELLOW,BRIGHT);
	display_window(prime);
ReStart:
	clear_message();
	strncpy(temppath,path,42);
	temppath[42]=0;
	if(!*temppath) strcpy(temppath,"DEFAULT DIR");
	wcursor(prime,0,0);
	sprintf(middle,"[A]rea change (#%u/%1.12s) (%u-%u) %s",areano,currarea->name,(nomess>0),nomess,area_attr());
	wprintf(prime,"%-65.65s\n",middle);
	sprintf(middle,"[C]hange address (%u:%u/%01u.%01u@%-1.24s)",curaddress.zone,curaddress.net,curaddress.node,curaddress.point,curaddress.domain);
	wprintf(prime,"%-65.65s\n",middle);
	wprintf(prime,"[E]dit headers\n");
	wprintf(prime,"[G]lobally read new messages\n");
	wprintf(prime,"[I]nformation\n");
	wprintf(prime,"[N]odelist review\n");
	wprintf(prime,"[O]rigin line edit\n");
	wprintf(prime,"[P]ersonal message check\n");
	wprintf(prime,"[R]ead messages\n");
	wprintf(prime,"[S]can messages\n");
	sprintf(middle,"[T]oggle current name (%s)",name);
	wprintf(prime,"%-65.65s\n",middle);
	wprintf(prime,"[W]rite message\n");
	wprintf(prime,"[Q]uit/Save LMR pointers (or ESC)\n");
	wprintf(prime,"Quit/[D]on't save LMR pointers\n");
	wprintf(prime,"[L]MR Reload\n");
	wprintf(prime,"[+]Print messages\n");
	wprintf(prime,"[K]ill Junk\n");
	sprintf(middle,"[!]Change msg path (%s)",temppath);
	wprintf(prime,"%-65.65s\n",middle);
    wprintf(prime,"Text Editor [SpaceBar]\n");
    wprintf(prime,"I[M]port mail\n");
    wprintf(prime,"E[X]port mail\n");
	wprintf(prime,"[#]Msg Area Maintenance\n");
	wprintf(prime,"[J]ump to DOS");

  while (1) {
	*assocfile=0;
	set_help("mainmenu  ",18,0);
	cursor(0,maxy-1);
	if(s<0 || s>strlen(keys)) s=1;

    s=get_selection(prime,s,keys);
	switch (s) {
		case 0:     save_lastread();
					delete_window(prime);
					return;
		case 1: 	temp=areano;
					areano=list_areas();
					if(temp!=areano && areano) {
						find_area();
						nomess=check_area(areano);
						if(areano<=totalareas) {
							if(lastread[areano-1]<nomess) messno=lastread[areano-1]+1;
							else messno=1;
						}
						else messno=1;
						get_mess(0);
					}
					else {
						find_area();
						nomess=check_area(areano);
					}
					delete_window(prime);
					goto AllOver;		/* ???? */
		case 2:     select_address();
					goto ReStart;
		case 3:     if (!areano) {
						goto SelectAnAreaFirst;
					}
					if (!nomess) {
						goto NoneHere;
					}
					edit_mess(0);
					break;
		case 8:
		case 4:     temparea=areano;
					tempmess=messno;
					delete_window(prime);
					for (areano=1;areano<(totalareas+1);areano++) {
						 if (!ewnd) any_message(" Scanning:             ");
						 wcursor(ewnd,11,0);
						 wprintf(ewnd,"%-5u       ",areano);
						 if (kbhit()) {
							 returncode=(int)get_char();
							 if (returncode==32 || returncode==ESC) goto BreakOut;
						 }
						 sprintf(middle,"%sXDATA.%03x",path,areano);
						 if (findfirst(middle,&f,0)) f.ff_fsize=0;
						 nomess=(word)(f.ff_fsize/(long)sizeof(struct _xmsg));
						 if (lastread[areano-1]>nomess) lastread[areano-1]=nomess;
						 if (!nomess) continue;
						 messno=lastread[areano-1]+1;
						 if (nomess>=messno) {
							if (s==8) {
								messno=get_abunch (messno-1,0,1,"");
								if(!messno) continue;
							}
							find_area();
                            sprintf(middle," %u/%1.12s (%u/%u)--[R]ead [S]kip [I]gnore [A]bort: [R] ",areano,currarea->name,messno,nomess);
							any_message(middle);
Again:
							returncode=(int)toupper(generic_mouse_input(ewnd));
							switch (returncode) {
								case '\r':
								case 'R':   get_mess(0);
											read_mess((char)(s==8),1);
											break;
								case ESC:
								case 'S':   break;
								case 'Q':
								case 'A':   goto BreakOut;
								case 'I':	lastread[areano-1]=nomess;
											break;
								default:	bell();
											goto Again;
							}
							clear_message();
						 }
NotMe:
;
					}
BreakOut:
					clear_message();
					areano=temparea;
					messno=tempmess;
					find_area();
					nomess=check_area(areano);
					get_mess(0);
					goto AllOver;
		case 5:		info();
					break;
		case 6:		node_lister();
					break;
		case 7:     get_origin();
					break;
		case 9:     if (!areano) {
SelectAnAreaFirst:
						any_message(" Select an area first ");
						nopause();
						break;
					}
					if (!nomess) {
NoneHere:
						any_message(" None here ");
						nopause();
						break;
					}
					get_mess(0);
					clear_message();
					read_mess(0,0);
					clear_message();
					get_mess(0);
					goto AllOver;
		case 10:    if (!areano) {
						goto SelectAnAreaFirst;
					}
					if (!nomess) {
						goto NoneHere;
					}
					scan_mess();
					break;
		case 11:    select_name();
					goto ReStart;
		case 12:    if (!areano) {
						goto SelectAnAreaFirst;
					}
					get_rid();
					if (set_header(INFOONLY,"","","")==ESC) {
						get_mess(0);
						break;
					}
					delete_window(prime);
					if(!editor) {
						show_header(0);
					}
					post_mess("");
					clrr();
					get_mess(0);
					goto AllOver;
		case 13:    save_lastread();
		case 14:    delete_window(prime);
					return;
		case 15:    load_lastread();
					break;
		case 16:    if(!nomess) {
						goto NoneHere;
					}
					delete_window(prime);
					printer();
					goto AllOver;
		case 17:    killjunk();
					nomess=check_area(areano);
					break;
		case 18:    switch_dirs();
					goto ReStart;
		case 19:	p=get_string("File to edit:",78,NULL,'A');
					if(!*p) break;
					if(!texteditor) {
						strcpy(notefile,p);
						notepad();
					}
					else {
						sprintf(middle,"%s ",texteditor);
						strncat(middle,p,133-strlen(middle));
						middle[132]=0;
						do_spawn(middle);
					}
					break;
        case 20:    delete_window(prime);
                    import_mail();
                    goto AllOver;
        case 21:    delete_window(prime);
                    export_mail();
                    goto AllOver;
		case 22:    _anymsg(" Select function "," [X]Edit or X[M]sg? (X/M) ");
					returncode=toupper(generic_mouse_input(ewnd));
					clear_message();
					if(returncode!='X' && returncode!='M') break;
					save_lastread();
					if(returncode== 'M') {
						char s[133];

						sprintf(s,"%s /c RUNXMSG.BAT",getenv("COMSPEC"));
						do_spawn(s);
					}
					else do_spawn("XEDIT.EXE");
					load_lastread();
					if(marea){

						register int x;

						for(x=0;x<maxareas;x++) {
							if(marea[x].name) free(marea[x].name);
						}
						farfree((void far *)marea);
					}
					load_areas();
					currarea=&nullarea;
					find_area();
					nomess=check_area(areano);
					if(messno>nomess)messno=nomess;
					goto ReStart;
		case 23:    do_spawn("");
					break;
		case HOME:	areano=2;
		case FWD:
		case PGUP:	areano--;
					if (areano<1) areano=4095;
					find_area();
					nomess=check_area(areano);
					goto ReStart;
		case END:	areano=4094;
		case BS:
		case PGDN:	areano++;
					if (areano>4095) areano=1;
					find_area();
					nomess=check_area(areano);
					goto ReStart;
		case ALT_F1:
        case ALT_F2:
        case ALT_F3:
        case ALT_F4:
        case ALT_F5:
        case ALT_F6:
        case ALT_F7:
        case ALT_F8:
        case ALT_F9:
		case ALT_F10:   do_spawn(convertstring(fkey[s-ALT_F1]));
						break;
		default:	bell();
	}
  }
}
