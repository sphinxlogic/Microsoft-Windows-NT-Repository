#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"



void pascal killjunk (void) {

    static char from[36]="JACK DECKER";
    static char to[36]="";
    static char subj[64]="POLITICS AND RELIGION";
    static char orit[2]="-";
    char listtouse[80]="";
    char area[5]="0";
    word temparea;
    word tempno;
    word tempmess;
    int  returncode;
    word register x;
    char testfrom[36];
    char testto[64];
    char testsubj[64];
    char frommatch;
    char tomatch;
    char subjmatch;
    int  handle=-1;
    char input[133];
    char *p;
    WINDOW *wnd;
    WINDOW *wndd=NULL;
    FIELD *fld;


    wnd=establish_window(1,8,12,79);
    set_border(wnd,3);
    set_title(wnd," Kill Junk Msgs ");
    set_colors(wnd,BORDER,7,0,0);
    display_window(wnd);
    wcursor(wnd,0,0);
	wprintfraw(wnd," F10 to kill or ESC to abort");
    temparea=areano;
    tempno=nomess;
    tempmess=messno;
Again:
    wprompt(wnd,3,2,"From:");
    wprompt(wnd,3,3,"To:");
    wprompt(wnd,3,4,"Subj:");
    wprompt(wnd,3,5,"Area #(0=all):");
    wprompt(wnd,3,6,"Match any: [ ]");
    wprompt(wnd,3,7,"List to use instead:");

    fld=establish_field(wnd,9,2,msk35,from,'A');
    field_window(fld,"killfrom  ",40,5);
    fld=establish_field(wnd,9,3,msk35,to,'A');
    field_window(fld,"killto    ",40,6);
    fld=establish_field(wnd,9,4,msk63,subj,'A');
    field_window(fld,"killsubj  ",40,7);
    fld=establish_field(wnd,18,5,msk4,area,'N');
    field_window(fld,"killarea  ",40,8);
    fld=establish_field(wnd,15,6,msk1,orit,'O');
    field_window(fld,"matchany  ",40,8);
    fld=establish_field(wnd,1,8,msk78,listtouse,'A');
    field_window(fld,"listtouse ",40,5);
    prep_template(wnd);
AskOver:
    returncode=data_entry(wnd);
    if (returncode==ESC) {
        delete_window(wnd);
        clear_message();
        return;
    }
    if (returncode!=F10) goto AskOver;
Quit:
    delete_window(wnd);
    lstrip(listtouse);
    rstrip(listtouse);
    if(*listtouse) {
        handle=_open(listtouse,O_RDONLY | O_BINARY | O_DENYNONE);
        if(handle==-1) {
ErrorHere:
            error_message(" Can't open Junk list file ");
            pause();
            return;
        }
        if(eof(handle)) goto ErrorHere;
    }
ReLoop:
    if(*listtouse) {
        if(eof(handle)) {
            *listtouse=0;
            goto SkipNext;
        }
        if(!fgetsx(input,133,handle)) {
            *listtouse=0;
            goto SkipNext;
        }
        stripcr(input);
        p=strtok(input,"\01");
        strncpy(from,p,36);
        from[35]=0;
        p=strtok(0,"\01");
        if(p) {
            strcpy(to,p);
            to[35]=0;
            p=strtok(0,"\01");
            if(p) {
                strcpy(subj,p);
                subj[63]=0;
                p=strtok(0,"\01");
                if(p) {
                    strncpy(area,p,5);
                    area[4]=0;
                    p=strtok(0,"\01");
                    if(p) {
                        *orit=*p;
                    }
                }
            }
        }
    }
    rstrip(from);
    rstrip(to);
    rstrip(subj);
    if(!strnicmp(subj,"RE:",3)) {
        strcpy(testsubj,&subj[3]);
        strcpy(subj,testsubj);
        lstrip(subj);
    }
    if (!*from && !*to && !*subj) {
        if(!*listtouse) return;
        else goto ReLoop;
    }
    if (atol(area)<0 || atol(area)>4095) {
        error_message(" Invalid area ");
        pause();
        if(*listtouse) goto ReLoop;
        else return;
    }
    if(!wndd) {
		wndd=establish_window(1,4,18,79);
        set_border(wndd,1);
        set_title(wndd," Junk Killing Status (ESC Aborts) ");
        set_colors(wndd,BORDER,7,0,0);
        display_window(wndd);
        wcursor(wndd,0,0);
    }
    if (atol(area)) {
        areano=(word)atol(area);
        find_area();
        nomess=check_area(areano);
        if(!nomess)goto SkipNext;
        goto SkipFor;
    }

    for (x=0;x<(maxareas+1);x++) {
         areano=marea[x].number;
		 currarea=(struct _marea far *)&marea[x];
         nomess=check_area(areano);
         if(!nomess) continue;
SkipFor:
         clear_message();
         wprintf(wndd,"\n\n Scanning area #%u (%1.24s) 1-%u",areano,currarea->name,nomess);
         for (messno=1;messno<(nomess+1);messno++) {
            if (kbhit()) if (get_char()==ESC) {
                *listtouse=0;
                goto SkipNext;
            }
            get_mess(0);

            if (*from) {
                strcpy(testfrom,msg.from);
                if (!stricmp(testfrom,from)) frommatch=1;
                else frommatch=0;
            }
            else if(*orit=='X') frommatch=0;
            else frommatch=1;
            if (*to) {
                strcpy(testto,msg.to);
                if (!stricmp(testto,to)) tomatch=1;
                else tomatch=0;
            }
            else if(*orit=='X') tomatch=0;
            else tomatch=1;
            if(*subj) {
                strcpy(testsubj,msg.subj);
                if(!strnicmp(testsubj,"RE:",3)) {
                    strcpy(testto,&testsubj[3]);
                    strcpy(testsubj,testto);
                    lstrip(testsubj);
                    if(!*testsubj) {
                        subjmatch=1;
                        goto BreakOut;
                    }
                }
                if(!stricmp(testsubj,subj)) subjmatch=1;
                else subjmatch=0;
            }
            else if (*orit=='X') subjmatch=0;
            else subjmatch=1;
BreakOut:

            if((*orit=='X' && (frommatch || tomatch || subjmatch)) || (frommatch && tomatch && subjmatch)) {
                    reverse_video(wndd);
					wputchar(wndd,'\n');
					wprintfraw(wndd,"%05u Subj: %-64s",messno,msg.subj);
                    normal_video(wndd);
					wputchar(wndd,'\n');
					wprintfraw(wndd,"Fm: %-32s To: %s",msg.from,msg.to);
					wputchar(wndd,'\n');
                    wprintf(wndd,"%s %s",msg.date,quick_attr());
                    msg.m_attr = (msg.m_attr | MSGDELETED);
                    put_mess();
            }
         }
         if (atol(area)) goto SkipNext;
    }
SkipNext:
    clear_message();
    if(*listtouse) goto ReLoop;
    if(wndd)delete_window(wndd);
    messno=tempmess;
    nomess=tempno;
    areano=temparea;
    find_area();
    get_mess(0);
    if(handle!=-1) _close(handle);
    return;
}

