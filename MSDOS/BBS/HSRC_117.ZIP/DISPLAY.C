#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"

extern word threadstart;
extern WINDOW *ewnd;
extern int wasconfinedx1,wasconfinedy1,wasconfinedx2,wasconfinedy2;

extern void pascal do_recpt(void);


/* This is the main display function for reading messages
   (see also read_mess()).  This is pretty big and pretty nasty,
   but rather efficient, so what the hell... */


int pascal display (word *lastmess,char type) {

  register word x;
  int  x1;
  int  y1;
  word temp;
  char *hold;
  char *tempo;
  char *p;
  char caret=0;
  char message[133];
  char nextkey;
  char lines;
  char stop;
  word numlines;
  char findend;
  struct nodeidx nid;
  int cx,cy;

  if (kbhit()) {
	nextkey=get_char();
	if (nextkey==CTRL_PGUP || nextkey==CTRL_PGDN) return nextkey;
  }
Toggler:
  highvideo();
  current_color=readtextcolor + (readtextback * 16);
  clear_message();
  dclrwnd(1,6,maxx,maxy-1);
  hold=get_text();
  if (hold==NULL || *hold==0) return 0;
  if(tempo=strstr(hold,"\01URGENT")) {
	  strncpy(urgent_text,&tempo[8],79);
	  urgent_text[78]=0;
	  tempo=strchr(urgent_text,'\r');
	  if(tempo)*tempo=0;
	  lstrip(urgent_text);
	  rstrip(urgent_text);
  }
  else *lastmsgid=0;
  if(!threadstart) {
      if(tempo=strstr(hold,"\01MSGID:")) {
        strncpy(lastmsgid,&tempo[7],80);
        lastmsgid[79]=0;
        tempo=strchr(lastmsgid,'\r');
        if(tempo)*tempo=0;
        lstrip(lastmsgid);
        rstrip(lastmsgid);
      }
      else *lastmsgid=0;
      if(tempo=strstr(hold,"\01REPLY:")) {
        strncpy(lastreply,&tempo[7],80);
        lastreply[79]=0;
        tempo=strchr(lastreply,'\r');
        if(tempo)*tempo=0;
        lstrip(lastreply);
        rstrip(lastreply);
      }
      else *lastreply=0;
  }
  if(tempo=strstr(hold,"\01ASSOC:")) {
	strncpy(assocfile,&tempo[7],80);
	assocfile[132]=0;
    tempo=strchr(assocfile,'\r');
	if(tempo)*tempo=0;
	lstrip(assocfile);
	rstrip(assocfile);
  }
  else *assocfile=0;

  if (!ctla) strip_seenbys(hold);
  strip_blanklines(hold);
  if (hold==NULL || &hold==NULL) return 0;
  if (kbhit()) {
	nextkey=get_char();
	if (nextkey==CTRL_PGUP || nextkey==CTRL_PGDN) return nextkey;
  }
  if (messno>*lastmess) *lastmess=messno;
  numlines=0;
  line[0]=hold;
  lines=findend=stop=0;
  cx=1;
  cy=6;
  p=hold;
  while (1) {
Continuing:
   if (currarea->attr & ANSI) {
	  while(*p) {
		if(*p=='\01' && !ctla) {
			do {
				p++;
			}while(*p!='\r' && *p);
			if(p)p++;
			continue;
		}
		fputc(*p++,stdout);
		if(cy>(maxy)) cy=maxy;
		if(cy<6) cy=6;
		if (kbhit()) {
			nextkey=toupper(get_char());
			if (nextkey==32) break;
			if (nextkey==80) {
				while (!kbhit());
				get_char();
			}
		}
	  }
	  printf("\r%s",make_ansi(readtextcolor,readtextback));
	  goto ReLoop;
   }
   strcpy(message,write_line(&p,maxx,ctla));
   tempo=message;

   if (currarea->attr & MCI) {
	  if (strchr(tempo,'^')) {
		caret++;
		tempo=mci(tempo);
		if (strlen(tempo)>maxx) {
			if (!findend) lines+=(strlen(tempo)/maxx)+1;
			numlines+=(strlen(tempo)/maxx)+1;
		}
	  }
   }
   if (!findend) {

	  char altered=0;

	if(!hilite) {

	  if(*tempo=='\01') {	/* Highlight kludge lines */
        current_color=kludge_fore + (kludge_back * 16);
        if(caret) fputs(make_ansi(kludge_fore,kludge_back),stdout);
		altered++;
	  }
	  else if(isbrktquote(tempo)) {	/* Highlight quotes */
            current_color=quote_fore+(quote_back * 16);
            if(caret)fputs(make_ansi(quote_fore,quote_back),stdout);
			altered++;
	  }
	  else if(currarea->attr & ECHO) {
		if (!strncmp(tempo," * Origin: ",11)) {	/* Highlight origins */
            current_color=orig_fore+(orig_back * 16);
            if(caret)fputs(make_ansi(orig_fore,orig_back),stdout);
			altered++;
		  }
		  else if (!strncmp(tempo,"--- ",4) || !strcmp(message,"---")) {
            lowvideo();
            current_color=tear_fore+(tear_back * 16);
            if(caret)fputs(make_ansi(tear_fore,tear_back),stdout);
			altered++;
		  }
	  }
	}
    if (!caret && !slowprint) {
		dputs(cx,cy,tempo);
		cy++;
	}
    else {
		gotoxy(cx,cy);
		if(slowprint) {

            char *p;
            unsigned long t1;

          p=tempo;
          while(*p) {
             fputc(*p,stdout);
             t1=(unsigned long)biostime(0,0L)+(unsigned long)slowprint;
             while((unsigned long)biostime(0,0L)<t1 && t1<(unsigned long)biostime(0,0L)+256L);
             p++;
          }
		  slowprint=0;
		}
		else fputs(tempo,stdout);
		cy++;
    }

    if(altered) {
        highvideo();
        current_color=readtextcolor + (readtextback * 16);
		if(caret)fputs(make_ansi(readtextcolor,readtextback),stdout);
	}

	caret=0;
	lines++;
   }
   numlines++;
   if (numlines>=(maxlines-1)) numlines=0;
   line[numlines]=p;
EOFF:
   slowprint=0;
   if (currarea->attr & ANSI) goto ReLoop;
   if ((lines>=(maxy-6)-((currarea->attr & MCI)!=0)) || stop || !*p) {
		if (findend) {
			clear_message();
			findend=0;
			numlines-=(maxy-6);
			p=(char *)line[numlines];
			lines=0;
			goto NewPage;
		}
		stop=0;
		if ((numlines>(maxy-6) && lines<(maxy-6)) && !*p) {
			numlines-=(maxy-6);
			p=(char *)line[numlines];
			lines=0;
			goto NewPage;
		}
	   while (kbhit()) get_char();
ReLoop:
       cursor(cx-1,cy-1);
	   fputs("\r\x1b[0m",stderr);
RealEnd:
	   current_color=readheadcolor + (readheadback * 16);
       if (!*p) dputs(70,3," END");
	   else if (numlines<=(maxy-6)) dputs(70,3," TOP");
	   else dputs(70,3,"MORE");
	   dprintf(75,3,"%u",numlines);
FreeKey:
	   if(*urgent_text) {
			_anymsg(" URGENT! ",urgent_text);
			*urgent_text=0;
	   }
	   nextkey=0;
       current_color=readtextcolor + (readtextback * 16);
       set_help ("readkeys  ",0,23);
	   SHOWMOUSE;
	   if(usemouse) {	/* Allow to roam full screen */

		  union REGS rg;

		   rg.x.ax=7;
		   rg.x.cx=0;
		   rg.x.dx=((maxx-1)*8);
		   int86(0x33,&rg,&rg);
		   rg.x.ax=8;
		   rg.x.cx=0;
		   rg.x.dx=((maxy-1)*8);
		   int86(0x33,&rg,&rg);
		   wasconfinedx1=0;
		   wasconfinedy1=0;
		   wasconfinedx2=((maxx-1)*8);
		   wasconfinedy2=((maxy-1)*8);
	   }
	   while(!kbhit()) {
		  if(usemouse) {

                union REGS rg;

				rg.x.ax=3;
				int86(0x33,&rg,&rg);
				move_mouse(rg.x.cx/8,rg.x.dx/8);
                rg.x.ax=5;
                rg.x.bx=0;          /* Check left button */
                int86(0x33,&rg,&rg);
				if(rg.x.bx) {       /* Button pressed */
                    rg.x.cx/=8;     /* Mouse x */
                    rg.x.dx/=8;     /* Mouse y */
                    if(rg.x.dx<=1) {
                            nextkey='/';
							break;
					}
                    if(rg.x.cx==0 && rg.x.dx==(maxy-1)) {
						nextkey=PGDN;
                        break;
                    }
                    if(rg.x.cx==(maxx-1) && rg.x.dx==(maxy-1)) {
						nextkey=PGUP;
                        break;
                    }
					if(rg.x.dx==3 && rg.x.cx>60) {
						nextkey=ALT_A;
						break;
					}
					if(rg.x.dx==2 && rg.x.cx>29 && rg.x.cx<44) {
						nextkey=ALT_L;
						break;
					}
					if(rg.x.dx<4) {
						nextkey=F7;
						break;
					}
					if(rg.x.dx==4) {
						nextkey=CTRL_N;
						break;
					}
					nextkey=toupper(get_screen_char(rg.x.cx,rg.x.dx));
                    switch((int)nextkey) {
						case '':   nextkey=CTRL_PGUP;
                                    break;
                        case 26:    nextkey=CTRL_PGDN;
                                    break;
                        case '':   nextkey=DN;
                                    break;
                        case '':   nextkey=UP;
                                    break;
						case '�':	nextkey=CTRL_F6;
									break;
						case 168:   set_help ("mousekeys  ",0,23);
						case '?':   HIDEMOUSE;
									if (helpfunc) {
                                       if (!helping) {
                                         helping=1;
                                         (*helpfunc)();
                                         helping=0;
                                       }
									}
									SHOWMOUSE;
									rg.x.ax=5;
									rg.x.bx=0;
									int86(0x33,&rg,&rg);	/* Clear buttons */
									rg.x.ax=5;
									rg.x.bx=1;
									int86(0x33,&rg,&rg);	/* Clear buttons */
									rg.x.ax=5;
									rg.x.bx=2;
									int86(0x33,&rg,&rg);	/* Clear buttons */
									nextkey=0;
                                    set_help ("readkeys  ",0,23);
                                    break;
                        case '':   nextkey=F6;
                                    break;
                        case 173:   nextkey=CTRL_L;
                                    break;
                        case 251:   nextkey=ALT_L;
                                    break;
                        case '':   nextkey=PGUP;
                                    break;
                        case '':   nextkey=PGDN;
                                    break;
                        case '�':   nextkey=CTRL_D;
                                    break;
                        case '�':   nextkey=CTRL_F;
                                    break;
                        case '�':   nextkey=CTRL_B;
                                    break;
                        case '':   nextkey=ALT_B;
                                    break;
                        case '':   nextkey=ALT_F;
                                    break;
                    }
                    if(nextkey && nextkey!=' ') break;
                    else nextkey=0;
                }
				rg.x.ax=3;
				int86(0x33,&rg,&rg);
				move_mouse(rg.x.cx/8,rg.x.dx/8);
                rg.x.ax=5;          /* Right button */
				rg.x.bx=1;
				int86(0x33,&rg,&rg);
				if(rg.x.bx) {
                    nextkey=ESC;
					break;
				}
				rg.x.ax=3;
				int86(0x33,&rg,&rg);
				move_mouse(rg.x.cx/8,rg.x.dx/8);
                rg.x.ax=5;          /* Middle button */
                rg.x.bx=2;
				int86(0x33,&rg,&rg);
				if(rg.x.bx) {
                    nextkey=PGDN;
					break;
                }
          }
#ifdef USECLOCK
          print_clock();
#endif
       }
	   HIDEMOUSE;
	   if(!nextkey) nextkey=toupper(get_char());
	   clear_message();
NotFreeKey:
	   current_color=readtextcolor + (readtextback * 16);
       set_help ("readkeys  ",0,23);
	   switch ((int)nextkey) {
			case ALT_D: skipdeleted=1-skipdeleted;
						if(skipdeleted) {
							_anymsg(" Toggled Deleted View "," OFF ");
						}
						else {
							_anymsg(" Toggled Deleted View "," ON ");
						}
						pause();
						goto FreeKey;
			case CTRL_Q:threadstart=0;
                        show_header(0);
                        goto FreeKey;
            case CTRL_A:load_lastread();
						goto FreeKey;
			case CTRL_S:save_lastread();
						goto FreeKey;
			case ALT_X: save_lastread();
						fputs("\x1b[2J",stdout);
						exit(0);
			case '/':	nextkey=exec();
						set_help ("readkeys  ",0,23);
						if(!nextkey) goto FreeKey;
						goto NotFreeKey;
			case ' ':	goto FreeKey;
			case ALT_T: select_name();
						goto ReLoop;
			case ALT_C: select_address();
						goto ReLoop;
			case ALT_N: if(!nidxsize) {
							any_message(" No nodelist available. ");
							nopause();
						}
						else node_lister();
						goto ReLoop;
			case '-':
			case 'P':
			case PGUP:  if (numlines<=(maxy-6)) {
							nextkey=CTRL_PGUP;
							goto EndIt;
						}
						if (numlines<((maxy * 2)-13)) numlines=0;
						else numlines-=((maxy * 2)-14);
						p=(char *)line[numlines];
						break;
			case '\r':
			case 'N':
			case PGDN:
DoPageDown:
						if (!*p) {
							nextkey=CTRL_PGDN;
							goto EndIt;
						}
						break;
			case 24:
			case DN:
DoDown:
						if (!*p) goto ReLoop;
						stop++;
DoEnd:
						dscrollup(1,6,maxx,maxy-1);
						cx=1;
						cy=maxy-1;
						goto Continuing;
			case UP:
						if (numlines>(maxy-6)) {
						  dscrolldn(1,6,maxx,maxy-1);
						  cx=1;
						  cy=6;
						}
DoUp:
						if (numlines>(maxy-6)) {
						  numlines--;
						  p=(char *)line[numlines-(maxy-6)];
						  strcpy(message,write_line(&p,maxx,ctla));
						  dputs(cx,cy,message);
						  p=(char *)line[numlines];
						}
                        goto ReLoop;
			case 'H':
			case HOME:  p=hold;
						numlines=0;
						break;
            case 'E':
            case END:   if (!*p) goto ReLoop;
						findend++;
						lines=0;
						goto Continuing;
			case '+':   _AH=2;
						_DX=0;
						geninterrupt(0x17);
						x=_AH;
						if (x!=144) {
							error_message(" Printer not ready ");
							nopause();
							goto ReLoop;
						}
						if (hold) free(hold);
						any_message(" Printing ");
                        export("PRN",((currarea->attr & ALTERNATE) ||
						  (currarea->attr & NET)),PRINTIT,"","",NULL);
						get_mess(0);
						hold=get_text();
						if (hold==NULL || &hold==NULL) return 0;
						if(!ctla) strip_seenbys(hold);
						strip_blanklines(hold);
						if (hold==NULL || &hold==NULL) return 0;
						any_message(" Complete ");
						nopause();
						goto ReLoop;
			case ALT_O:	get_origin();
						goto ReLoop;
			case CTRL_O: usedefault=1-usedefault;
                         if(usedefault) any_message(" Always using default origin line");
                         else any_message(" Looking up origin lines in ORIGINS.BBS ");
                         nopause();
                         goto ReLoop;
			case CTRL_W: wrapit=1-wrapit;
						 if(wrapit || !wrapcall) _anymsg(" Toggled Wrapping "," OFF ");
						 else _anymsg(" Toggled Wrapping "," ON ");
						 nopause();
						 goto ReLoop;
			case ALT_J:	 do_spawn("");
						 goto ReLoop;
			case ALT_F1:
            case ALT_F2:
            case ALT_F3:
            case ALT_F4:
            case ALT_F5:
            case ALT_F6:
            case ALT_F7:
            case ALT_F8:
            case ALT_F9:
			case ALT_F10: do_spawn(convertstring(fkey[nextkey-ALT_F1]));
						  goto ReLoop;
			case '>':
			case '<':   if (type) goto ReLoop;
			case LEFT:
			case RIGHT:
			case CTRL_PGDN:
			case CTRL_PGUP:
			case F10:
			case 81:
			case ESC:
			case F9:
			case F8:
			case F7:
			case F6:
			case 82:
			case F5:
			case 'W':
			case F4:
			case F3:
			case F2:
			case ALT_L:
			case CTRL_K:
			case CTRL_L:
			case CTRL_E:
			case ALT_1:
			case ALT_2:
			case ALT_3:
			case ALT_4:
			case ALT_5:
			case ALT_6:
			case ALT_7:
			case ALT_8:
			case ALT_9:
			case ALT_0:
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
			case '0':
			case CTRL_R:
			case CTRL_F1:
			case CTRL_F2:
			case CTRL_F3:
			case CTRL_F4:
			case CTRL_F5:
			case CTRL_F6:
			case CTRL_F7:
            case ALT_Q:
            case ALT_A:     goto EndIt;
            case ALT_F:
            case ALT_B:
            case CTRL_F:
			case CTRL_B:    if(!threadstart) threadstart=messno;
                            goto EndIt;
            case CTRL_N:    nid.node=msg.orig;
							nid.net=msg.orig_net;
							nid.zone=msg.o_zone;
							nid.type=255;
							nodelist(&nid,0);
							nopause();
							delete_window(wnd6);
							goto ReLoop;
			case CTRL_T:	ctla=1-ctla;
							if (hold) free(hold);
							goto Toggler;
			case 'V':		if(!*assocfile) any_message (" No Associated File ");
							else if((!strchr(assocfile,':') && !strchr(assocfile,'\\')) && !find_filearea()) any_message(" Associated File Area not found ");
							else {

								struct ffblk f;
								char temp[163];

								if(strchr(assocfile,':') || strchr(assocfile,'\\')) strcpy(temp,assocfile);
								else sprintf(temp,"%s%s",filepath,assocfile);
								if(!findfirst(temp,&f,0)) {
									if(strchr(assocfile,':') || strchr(assocfile,'\\')) sprintf(temp," %s  %lu bytes ",assocfile,f.ff_fsize);
									else sprintf(temp," %s%-13s  %lu bytes ",filepath,f.ff_name,f.ff_fsize);
									any_message(temp);
									if(*spawnview) {
										if(strchr(assocfile,':') || strchr(assocfile,'\\')) strcpy(temp,assocfile);
										else sprintf(temp,"%s%s",filepath,assocfile);
										sprintf(buffer,"%s %s",spawnview,temp);
										do_spawn(buffer);
										goto ReLoop;
									}
								}
								else any_message(" Associated file not found ");
							}
							nopause();
							goto ReLoop;
            case CTRL_D:    if(msg.m_attr & MSGKEEP) bell();
							else {
								msg.m_attr = msg.m_attr ^ MSGDELETED;
								put_mess();
								if (msg.m_attr & MSGDELETED) {
									any_message(" Deleted. ");
									if(*assocfile) {
										if (find_filearea() || strchr(assocfile,':') || strchr(assocfile,'\\')) {

											struct ffblk f;
											char temp[158];

											if(strchr(assocfile,':') || strchr(assocfile,'\\')) strcpy(temp,assocfile);
											else sprintf(temp,"%s%s",filepath,assocfile);
											if(!findfirst(temp,&f,0)) {
												sprintf(temp," Delete %s? (Y-n) ",assocfile);
												any_message(temp);
DeleteLoop:
												nextkey=toupper(generic_mouse_input(ewnd));
												if(nextkey=='Y' || nextkey==13) {
													if(strchr(assocfile,':') || strchr(assocfile,'\\')) strcpy(temp,assocfile);
													else sprintf(temp,"%s%s",filepath,assocfile);
													unlink(temp);
													sprintf(temp," %s is dead. ",assocfile);
													any_message(temp);
												}
												else if (nextkey!='N' && nextkey!=27) {
													bell();
													goto DeleteLoop;
												}
												else any_message(" File remains ");
											}
										}
									}
								}
								else any_message(" UnDeleted. ");
								nopause();
							}
							goto ReLoop;
			case CTRL_END:	messno=nomess;
							get_mess(0);
							return CTRL_END;
			case CTRL_HOME:	messno=1;
							get_mess(0);
							return CTRL_HOME;
			default:	    bell();
							goto ReLoop;
		}
NewPage:
		dclrwnd(1,6,maxx,maxy-1);
		cx=1;
		cy=6;
		lines=0;
	}
	if(cy>(maxy-1)) {
		cy=(maxy-1);
		dscrollup(1,6,maxx,maxy-1);
	}
  }
EndIt:
  if (hold) free(hold);
  if(msg.attr & MSGRRQ) do_recpt();
  return (int)nextkey;
}

