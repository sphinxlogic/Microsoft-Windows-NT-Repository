#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"

extern WINDOW *ewnd;


void pascal do_recpt (void) {

  /* Handle MSGRRQ (return recpt request) bit */

  if(msg.attr & MSGRRQ) {
	if ((currarea->attr & NET) || (currarea->attr & ALTERNATE)) {
		any_message(" Return Receipt Requested...shall I send one? (y/N) ");
		if(toupper(generic_mouse_input(ewnd))=='Y') {

			word tempmess;
			char tempstr[81];
			int temphandle;

			tempmess=messno;
			msg.attr = MSGCPT | MSGLOCAL | MSGKILL | MSGPRIVATE;
			strncpy(msg.to,msg.from,36);
			msg.to[35]=0;
			strncpy(msg.to,name,36);
			sprintf(tempstr,"\rMsg dated %s was received.\r",msg.date);
			strcpy(msg.date,fidodate());
			msg.d_zone=msg.o_zone;
			msg.dest=msg.orig;
			msg.d_point=msg.o_point;
			msg.dest_net=msg.orig_net;
			msg.o_zone=curaddress.zone;
			msg.orig=curaddress.node;
			msg.orig_net=curaddress.net;
			msg.o_point=curaddress.point;
			get_rid();
			temphandle=_creat("MSGTMP",O_RDWR | O_BINARY | O_DENYNONE);
			if(temphandle!= -1) {
				ffprintf(temphandle,"%s",tempstr);
				_close(temphandle);
				post_mess("MSGTMP");
			}
			messno=tempmess;
			get_mess(0);
		}
		clear_message();
		msg.attr &= (~MSGRRQ);
		put_mess();
	}
  }
}