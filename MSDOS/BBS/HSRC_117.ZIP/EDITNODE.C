#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"

#define msk8 msk35+27
#define msk20 msk78+58
#define msk40 msk78+38



	/* Edit a node's entry in QNL_DAT.BBS */

void pascal edit_node (void) {

  WINDOW *wnd;
  FIELD  *fld;
  struct nodeinfo nif;
  static char zone[7]="";
  static char net[7]="";
  static char node[7]="";
  char temp[133];
  char type[5];
  char name[21];
  char city[41];
  char phone[41];
  char password[9];
  char flags[7];
  char baud[7];
  char cost[7];
  long x;
  int handle;
  int len;
  int returncode;

    if(!nidxsize || !nidx) {
		any_message(" No nodelist available. ");
		pause();
		return;
	}
ReStart:
    wnd=establish_window(4,maxy-8,6,32);
    set_border(wnd,3);
    set_title(wnd," Nodelist Editor ");
    set_colors(wnd,BORDER,7,0,0);
    display_window(wnd);
    wcursor(wnd,0,0);
    wprintf(wnd," F10=edit F9=list ESC=abort");
	if (!*zone || !(word)atol(zone)) {
		sprintf(zone,"%u",curaddress.zone);
		sprintf(net,"%u",curaddress.net);
        sprintf(node,"%u",curaddress.node);
    }
    init_template(wnd);
    wprompt(wnd,1,1,"Zone:");
    wprompt(wnd,1,2,"Net:");
    wprompt(wnd,1,3,"Node:");
    fld=establish_field(wnd,7,1,msk5,zone,'N');
    field_window(fld,"zoneedit  ",40,6);
    fld=establish_field(wnd,7,2,msk5,net,'N');
    field_window(fld,"netedit   ",40,5);
    fld=establish_field(wnd,7,3,msk5,node,'N');
    field_window(fld,"nodeedit  ",40,4);
    prep_template(wnd);
NodeOver:
    returncode=data_entry(wnd);
    if (returncode==ESC){
        delete_window(wnd);
        return;
    }
    else if(returncode==F6) {
        node_lister();
        goto NodeOver;
    }
    else if(returncode!=F10) goto NodeOver;

    nif.zone=(word)atol(zone);
    nif.net=(word)atol(net);
    nif.node=(word)atol(node);

    for (x=0;x<(nidxsize+1);x++) {
        if (nidx[x].zone==nif.zone && nidx[x].net==nif.net && nidx[x].node==nif.node) break;
    }
    if(x>nidxsize) {
        any_message(" Can't find requested node. ");
        pause();
        goto NodeOver;
    }

    sprintf(temp,"%sQNL_DAT.BBS",nodepath);
    if ((handle=_open(temp,O_RDONLY | O_BINARY | O_DENYNONE))==-1) {
       error_message(" Can't open QNL_DAT.BBS ");
       pause();
       goto NodeOver;
    }
    lseek(handle,x*(long)sizeof(struct nodeinfo),SEEK_SET);
    if (_read(handle,&nif,sizeof(struct nodeinfo))<1) {
        _close(handle);
        error_message(" Read Error ");
        goto NodeOver;
    }
    _close(handle);
    len=*nif.name;
    memmove(nif.name,&nif.name[1],len);
    nif.name[len]=0;
    len=*nif.city;
    memmove(nif.city,&nif.city[1],len);
    nif.city[len]=0;
    len=*nif.phone;
    memmove(nif.phone,&nif.phone[1],len);
    nif.phone[len]=0;
    len=*nif.password;
    memmove(nif.password,&nif.password[1],len);
    nif.password[len]=0;

    sprintf(type,"%-hu",nif.type);
    sprintf(baud,"%-u",nif.baud);
    sprintf(cost,"%-d",nif.cost);
    sprintf(flags,"%-u",nif.flags);
    strcpy(name,nif.name);
    strcpy(city,nif.city);
    strcpy(phone,nif.phone);
    strcpy(password,nif.password);

    delete_window(wnd);
	wnd=establish_window(4,maxy,14,58);
    set_border(wnd,3);
    set_title(wnd," Nodelist Editor ");
    set_colors(wnd,BORDER,7,0,0);
    display_window(wnd);
    wcursor(wnd,0,0);
    wprintf(wnd," F10 to change or ESC to abort");
	wcursor(wnd,2,10);
	wprintf(wnd,"Editting %u:%u/%01u\n",(word)atol(zone),(word)atol(net),(word)atol(node));
    init_template(wnd);
    wprompt(wnd,1,1,"Type:");
    wprompt(wnd,1,2,"Name:");
    wprompt(wnd,1,3,"City:");
    wprompt(wnd,1,4,"Phone:");
    wprompt(wnd,1,5,"Pwd:");
    wprompt(wnd,1,6,"Flags:");
    wprompt(wnd,1,7,"Baud:");
    wprompt(wnd,1,8,"Cost:");
    fld=establish_field(wnd,9,1,msk3,type,'N');
    field_window(fld,"typeedit  ",40,6);
    fld=establish_field(wnd,9,2,msk20,name,'a');
    field_window(fld,"nameedit  ",40,5);
    fld=establish_field(wnd,9,3,msk40,city,'a');
    field_window(fld,"cityedit  ",40,4);
    fld=establish_field(wnd,9,4,msk40,phone,'N');
    field_window(fld,"phoneedit ",40,3);
    fld=establish_field(wnd,9,5,msk8,password,'a');
    field_window(fld,"passedit  ",40,2);
    fld=establish_field(wnd,9,6,msk5,flags,'N');
    field_window(fld,"flagedit  ",40,1);
    fld=establish_field(wnd,9,7,msk5,baud,'N');
    field_window(fld,"baudedit  ",40,2);
    fld=establish_field(wnd,9,8,msk5,cost,'N');
    field_window(fld,"costedit  ",40,3);
    prep_template(wnd);
NodeOver2:
    returncode=data_entry(wnd);
    if(returncode==ESC) {
        delete_window(wnd);
        goto ReStart;
    }
    else if(returncode!=F10) goto NodeOver2;

	rstrip(name);
	rstrip(city);
	rstrip(phone);
	rstrip(password);

    nif.type=(char)atoi(type);
    nif.baud=(word)atol(baud);
    nif.cost=atoi(cost);
    nif.flags=(word)atol(flags);
    len=strlen(name);
    memcpy(&nif.name[1],name,len);
    *nif.name=len;
    len=strlen(city);
    memcpy(&nif.city[1],city,len);
    *nif.city=len;
    len=strlen(phone);
    memcpy(&nif.phone[1],phone,len);
    *nif.phone=len;
    len=strlen(password);
    memcpy(&nif.password[1],password,len);
    *nif.password=len;

    sprintf(temp,"%sQNL_DAT.BBS",nodepath);
    if ((handle=_open(temp,O_RDWR | O_BINARY | O_DENYREAD))==-1) {
       error_message(" Can't open QNL_DAT.BBS ");
       pause();
       goto NodeOver2;
    }
    lseek(handle,x*(long)sizeof(struct nodeinfo),SEEK_SET);
    if (_write(handle,&nif,sizeof(struct nodeinfo))<1) {
        _close(handle);
        error_message(" Write Error ");
        pause();
        goto NodeOver2;
    }
    _close(handle);
	delete_window(wnd);
	goto ReStart;
}
