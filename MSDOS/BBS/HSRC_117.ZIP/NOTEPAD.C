/* Notepad.C File */

#include <alloc.h>
#include <conio.h>
#include <stdio.h>
#include <mem.h>
#include <string.h>
#include <process.h>
#include <io.h>
#include <fcntl.h>
#include "twindow.h"

char LWID;
char WHT;
int PADHT;

extern unsigned int maxx,maxy;
extern char notefile[];
extern char abortedit;

char *bf;


extern char * pascal rstrip(char *);
extern char * pascal fgetsx(char *,int,int);
extern void pascal save_text(int justblk,int append);
extern void pascal get_rid(void);

void pascal notepad(void);



void pascal notepad (void) {

  WINDOW *wnd;
  char *endtext;
  int wasx,wasy;

  WHT=maxy-7;
  LWID=maxx-2;
  PADHT=32766/LWID;

  curr_cursor(&wasx,&wasy);

  bf=(char *)malloc((unsigned int)((PADHT * LWID)+1));
  if(!bf) {
		printf("\nOut of memory\n");
		get_rid();
		return;
  }

  set_help("edithelp  ",0,0);
  wnd=establish_window((maxx-(LWID+2))/2,(maxy-(WHT+2)),WHT+2,LWID+2);
  set_border(wnd,3);
  set_title(wnd," Mini Text Editor ");
  set_colors(wnd,ALL,BLACK,WHITE,BRIGHT);
  set_colors(wnd,ACCENT,WHITE,BLACK,DIM);
  set_colors(wnd,ACCENT,WHITE,BLUE,DIM);
  set_colors(wnd,BORDER,BLACK,BLUE,BRIGHT);
  set_colors(wnd,TITLE,BLACK,AQUA,BRIGHT);
  display_window(wnd);

  endtext=text_editor(wnd,bf,(unsigned)LWID*PADHT);

  if (abortedit) {   			/* Just quit */
	 if(!stricmp(notefile,"MSGTMP")) unlink(notefile);
	 any_message(" Aborted ");
  }
  else {
	if(endtext!=bf) {
		save_text(0,0);
	}
  }
  free(bf);
  clear_message();
  delete_window(wnd);
  cursor(wasx,wasy);
}
