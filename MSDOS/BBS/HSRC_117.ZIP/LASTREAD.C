#include "msgg.h"
#include "twindow.h"
#include "headedit.h"


void pascal load_lastread (void) {

	int fp;

	if(!totalareas) return;
	sprintf(buffer,"%sLASTREAD.BBS",path);
	if ((fp=_open(buffer,O_RDONLY | O_BINARY | O_DENYNONE))==-1) return;
	lseek(fp,(long)(userno-1)*(long)((long)totalareas*(long)sizeof(word)),SEEK_SET);
	_read(fp,lastread,totalareas*sizeof(word));
	_close(fp);
}



void pascal save_lastread (void) {

	int fp;

	if(!totalareas) return;
	sprintf(buffer,"%sLASTREAD.BBS",path);
	if ((fp=_open(buffer,O_RDWR | O_BINARY | O_DENYNONE))==-1)
		if ((fp=creat(buffer,S_IWRITE))==-1) return;
	lseek(fp,(long)(userno-1)*(long)((long)totalareas*(long)sizeof(word)),SEEK_SET);
	_write(fp,lastread,totalareas*sizeof(word));
	_close(fp);
}

