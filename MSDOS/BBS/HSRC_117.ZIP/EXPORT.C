#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"


/* Export messages */

void pascal make_file (void) {

    char xport[6];
    char s[30];
    word temp;
    int returncode;
    word tempmess;
    struct ffblk f;
    WINDOW *wnd;
    FIELD *fld;

ReStart:
		wnd=establish_window(1,maxy-7,6,80);
        set_border(wnd,3);
        set_title(wnd," Export message ");
        set_colors(wnd,BORDER,7,0,0);
        display_window(wnd);
        wcursor(wnd,0,0);
        wprintf(wnd," F10 to export or ESC to abort");
        sprintf(xport,"%u",messno);
        sprintf(s,"Export #(1-%u):",nomess);
        wprompt(wnd,1,2,s);
        wprompt(wnd,1,3,"Filename:");
        fld=establish_field(wnd,21,2,msk5,xport,'N');
        field_window(fld,"export#   ",40,6);
        fld=establish_field(wnd,11,3,msk65,filenamer,'A');
        field_window(fld,"exportname",40,7);
Over:
        prep_template(wnd);
        returncode=data_entry(wnd);
        if (returncode==ESC) {
            delete_window(wnd);
            return;
        }
        if (returncode!=F10) goto Over;
        returncode=0;
        rstrip(filenamer);
        temp=(word)atol(xport);
        if (!strlen(filenamer) || temp<1 || temp>nomess) {
            error_message(" Invalid parameter ");
            pause();
            goto Over;
        }
        if (!findfirst(filenamer,&f,0)) {
            any_message(" Exists...[O]verwrite [A]ppend [R]eEnter? [A] ");
ReInput:
            returncode=toupper(get_char());
            if (returncode=='R' || returncode==ESC) {
                clear_message();
                goto Over;
            }
            if (returncode=='O') unlink(filenamer);
            else if (returncode!='\r' && returncode!='A') {
                bell();
                goto ReInput;
            }
        }
        clear_message();
        tempmess=messno;
        messno=temp;
		get_mess(0);
		delete_window(wnd);
		wnd=establish_window(0,maxy-7,19,maxx);
        set_border(wnd,3);
		set_title(wnd," Exporting message ");
        set_colors(wnd,BORDER,7,0,0);
        display_window(wnd);
        wcursor(wnd,0,0);
		if (!export(filenamer,((currarea->attr & NET) || (currarea->attr & ALTERNATE)),TEXTFILE,"","",wnd)) {
			delete_window(wnd);
			goto ReStart;
		}
		clear_message();
		delete_window(wnd);
        messno=tempmess;
        get_mess(0);
}


int pascal export (file,net,type,olddate,oldfrom,wndd)

 char *file;
 char net;
 char type;
 char *olddate;
 char *oldfrom;
 void *wndd;

{

 static char text[124];
 static char lines=0;
 WINDOW *wnd;
 register word x;
 int pp;
 char message[82];
 char far *hold;
 char *tempo;
 char *p;
 char width;
 char noquote=0;

 wnd=(WINDOW *)wndd;
 if(!strnicmp(file,"MSGTMP",6)) get_rid();
 if(type != EDITIT) strcpy(to_domain,curaddress.domain);
 *replyid=0;
 if (type==TEXTFILE) width=78;
 else if (type==PRINTIT) {
	width=textwidth;
	if (*olddate) lines=0;
 }
 else if (type==QUOTE || type==ECHO2NET) width=65;
 else if (type==EDITIT) width=71;

 if(type!=NOQUOTE) {
	 if((pp=(_open(file,O_WRONLY | O_BINARY | O_DENYWRITE)))==-1)
	   if((pp=(creat(file,S_IWRITE)))==-1) {
		 sprintf(text,"Cannot open %s",file);
		 error_message(text);
		 pause();
		 return(0);
	 }
 }
 lseek(pp,0L,SEEK_END);
 if (type==TEXTFILE || type==PRINTIT) {
	 if (type==PRINTIT) {
		for (x=0;x<strlen(beforeheader);x++) {
			if (beforeheader[x]=='\n') {
				lines++;
				ffprintf(pp,"\r\n");
				if(wnd)wprintf(wnd,"\n");
			}
			else {
				ffprintf(pp,"%c",beforeheader[x]);
				if(wnd)wprintf(wnd,"\n");
			}
			if(beforeheader[x]=='\xc') lines=0;
		}
	 }
	 if (type==PRINTIT) if((lines+8)>(pagelength-bottommargin)) {
		ffprintf(pp,"\xc\r\n");
		if(wnd)wprintf(wnd,"\n <=-Page Break-=>\n\n");
		lines=1;
	 }
	 if (type==PRINTIT) if (lines<topmargin) {
		for (x=lines;x<topmargin;x++) {
			ffprintf(pp,"\r\n");
			if(wnd)wprintf(wnd,"\n");
		}
		lines=topmargin;
	 }
	 if (type==PRINTIT) {
		for (x=0;x<(word)leftmargin;x++) {
			ffprintf(pp," ");
			if(wnd)wprintf(wnd," ");
		}
	 }
	 lines+=7;
	 ffprintf(pp,"Board #%u  *  Message #%u: ",areano,messno);
	 if(wnd)wprintf(wnd,"Board #%u  *  Message #%u: ",areano,messno);
	 if ((msg.attr & MSGPRIVATE)!=0) {
		if(wnd)wprintf(wnd,"(Priv)");
		ffprintf(pp,"(Priv)");
	 }
	 if ((msg.m_attr & MSGDELETED)!=0) {
		ffprintf(pp,"(Del)");
		if(wnd)wprintf(wnd,"(Del)");
	 }
	 if ((msg.attr & MSGCRASH)!=0) {
		ffprintf(pp,"(CRASH)");
		if(wnd)wprintf(wnd,"(CRASH");
	 }
	 if ((msg.attr & MSGKILL)!=0) {
		ffprintf(pp,"(Kill)");
		if(wnd)wprintf(wnd,"(Kill)");
	 }
	 if ((msg.attr & MSGSENT)!=0) {
		ffprintf(pp,"(Sent)");
		if(wnd)wprintf(wnd,"(Sent)");
	 }
	 if ((msg.attr & MSGFWD)!=0) {
		ffprintf(pp,"(Fwd)");
		if(wnd)wprintf(wnd,"(Fwd)");
	 }
	 if ((msg.attr & MSGREAD)!=0) {
		ffprintf(pp,"(Recd)");
		if(wnd)wprintf(wnd,"(Recd)");
	 }
	 if ((msg.attr & MSGRRQ)!=0) {
		ffprintf(pp,"(Rec.Req)");
		if(wnd)wprintf(wnd,"(Rec.Req)");
	 }
	 if ((msg.attr & MSGCPT)!=0) {
		ffprintf(pp,"(Recpt)");
		if(wnd)wprintf(wnd,"(Recpt)");
	 }
	 if ((msg.attr & MSGARQ)!=0) {
		ffprintf(pp,"(Aud.Req)");
		if(wnd)wprintf(wnd,"(Aud.Req)");
	 }
	 if ((msg.attr & MSGURQ)!=0) {
		ffprintf(pp,"(Up.Req)");
		if(wnd)wprintf(wnd,"(Up.Req)");
	 }
	 ffprintf(pp,"(Read %u times)\r\n",msg.times);
	 if(wnd)wprintf(wnd,"(Read %u times)\n",msg.times);

	 if (type==PRINTIT) {
		for (x=0;x<(word)leftmargin;x++) {
			ffprintf(pp," ");
			if(wnd)wprintf(wnd," ");
		 }
	 }
	 ffprintf(pp,"To:   %s",msg.to);
	 if(wnd)wprintfraw(wnd,"To:   %s",msg.to);
	 if ((net)!=0) {
		ffprintf(pp," (%u/%u)",msg.dest_net,msg.dest);
		if(wnd)wprintf(wnd," (%u/%u)",msg.dest_net,msg.dest);
	 }
	 ffprintf(pp,"\r\n");
	 if(wnd)wprintf(wnd,"\n");
	 if (type==PRINTIT) {
		for (x=0;x<(word)leftmargin;x++) {
			ffprintf(pp," ");
			if(wnd)wprintf(wnd," ");
		}
	 }
	 ffprintf(pp,"From: ");
	 if(wnd)wprintf(wnd,"From: ");
	 if ((msg.m_attr & MSGANON)!=0) {
	   ffprintf(pp,"*Anonymous* (%s)",msg.from);
	   if(wnd)wprintfraw(wnd,"*Anonymous* (%s)",msg.from);
	 }
	 else {
		ffprintf(pp,"%s",msg.from);
		if(wnd)wprintfraw(wnd,"%s",msg.from);
	 }
	 if (net) {
		ffprintf(pp," (%u/%u)",msg.orig_net,msg.orig);
		if(wnd)wprintf(wnd,"(%u/%u)",msg.orig_net,msg.orig);
	 }
	 ffprintf(pp,"\r\n");
	 if(wnd)wprintf(wnd,"\n");
	 if (type==PRINTIT) {
		for (x=0;x<(word)leftmargin;x++) {
			ffprintf(pp," ");
			if(wnd)wprintf(wnd," ");
		}
	 }
	 ffprintf(pp,"On:   ");
	 if(wnd)wprintf(wnd,"On:   ");

	 if ((msg.m_attr & MSGANON)!=0) {
	   ffprintf(pp,"%9.9s",msg.date);
	   if(wnd)wprintfraw(wnd,"%9.9s",msg.date);
	 }
	 else {
		ffprintf(pp,"%s",msg.date);
		if(wnd)wprintfraw(wnd,"%s",msg.date);
	 }
	 ffprintf(pp,"\r\n");
	 if(wnd)wprintf(wnd,"\n");
	 if (type==PRINTIT) {
		for (x=0;x<(word)leftmargin;x++) {
			ffprintf(pp," ");
			if(wnd)wprintf(wnd," ");
		}
	 }

	 if ((msg.attr & MSGFILE)!=0) {
		ffprintf(pp,"File: ");
		if(wnd)wprintf(wnd,"File: ");
	 }
	 else if ((msg.attr & MSGFRQ)!=0) {
		ffprintf(pp,"FReq: ");
		if(wnd)wprintf(wnd,"FReq: ");
	 }
	 else if ((msg.attr & MSGURQ)!=0) {
		ffprintf(pp,"UReq: ");
		if(wnd)wprintf(wnd,"UReq: ");
	 }
	 else {
		ffprintf(pp,"Subj: ");
		if(wnd)wprintf(wnd,"Subj: ");
	 }
	 ffprintf(pp,"%s\r\n\r\n",msg.subj);
	 if(wnd)wprintfraw(wnd,"%s\n\n",msg.subj);
	 if (type==PRINTIT) {
		for (x=0;x<strlen(afterheader);x++) {
			if (afterheader[x]=='\n') {
				lines++;
				ffprintf(pp,"\r\n");
				if(wnd)wprintf(wnd,"\n");
			}
			else {
				ffprintf(pp,"%c",afterheader[x]);
				if(wnd)wprintfraw(wnd,"%c",afterheader[x]);
			}
		}
	 }
 }

 if (type==QUOTE || type==ECHO2NET) {

	if(editor) {
		if (get_qstring(quotestring)==NULL) {
			_close(pp);
			get_rid();
			return 0;
		}
	}
	else *quotestring=0;

	if(!strcmp(quotestring,"NOQUOTE")) {
		*quotestring=0;
		noquote=1;
	}
	if(type==ECHO2NET) {
		ffprintf(pp,"  *Replying to msg in %s\r\n",currarea->name);
		if(*quotestring || noquote) ffprintf(pp,"\r\n");
	}
	if(noquote && msg.o_zone) {
		_close(pp);
		return 1;
	}
	if (!*quotestring && !noquote) {
		if(before_quote) {
			ffprintf(pp,"\r\n");
			ffprintf(pp,before_quote,olddate,msg.from,oldfrom,msg.subj);
		}
		if(after_before) {
			ffprintf(pp,"\r\n");
			ffprintf(pp,after_before,olddate,msg.from,oldfrom,msg.subj);
			ffprintf(pp,"\r\n\r\n");
		}
	}
 }

 hold=get_text();
 if(hold==NULL) return 0;
 if(!ctla) strip_seenbys(hold);
 strip_blanklines(hold);
 if (!*hold) {
	_close(pp);
	free(hold);
	return 0;
 }
 p=hold;

	  while (*p) {
		  if (type==QUOTE || type==ECHO2NET || type==NOQUOTE) {
			if (strcspn(p,">")<6) width=80-(strlen(quotestring) * (strcspn(p,">")<3));
			if(*p=='\01') width=80;
			else width=67;
		  }
		  strcpy(message,write_line(&p,width,1));

		  if (type==ECHO2NET) {
			if(!strncmp(message,PATHSTRING,6)) {
				memmove(&message[2],&message[1],strlen(&message[2]));
				message[1]='R';
				ffprintf(pp,"%s\r\n",message);
				continue;
			}
		  }
		  if (type==QUOTE || type==NOQUOTE || type==ECHO2NET) {
           if (!strncmp(message,PATHSTRING,6) && !ctla) break;
           if(msg.o_zone==0) {
            if (!strncmp(message,FMPTSTRING,5)) {
				msg.o_point=(char)atoi(&message[5]);
				continue;
			}
			else if (!strncmp(message,"\01INTL",5)) {
				strtok(message," :");
				strtok(0," ");
				tempo=strtok(0,":");
				if(tempo) if ((word)atoi(tempo)) msg.o_zone=(word)atol(tempo);
				continue;
			}
			if (!strncmp(message,"\01DOMAIN",7)) {
				strtok(message," ");
				tempo=strtok(0,"\r\n");
				if(tempo) {
					strncpy(to_domain,tempo,37);
					to_domain[36]=0;
				}
				continue;
			}
           }
           if (!strncmp(message,"\01MSGID",6)) {

				char *p;
				char *ispoint;
				char *isdomain;
				char *isnumsign;
				char *mss;

				strncpy(replyid,&message[7],80);
				replyid[79]=0;
				lstrip(replyid);
				rstrip(replyid);
				mss=message;
				ispoint=strchr(mss,'.');
				isdomain=strchr(mss,'@');
				isnumsign=strchr(mss,'#');
				if(isnumsign) {		/* For [user@]domain#z:n/n.p */
					if(isdomain) {
						if(isnumsign<isdomain) {
                            strtok(mss,"@");
							strncpy(msg.to,mss,36);
							msg.to[35]=0;
							mss=strtok(0,"\n");
							isdomain=NULL;	/* Was username */
						}
					}
                    strtok(mss,"#");
					strncpy(to_domain,mss,37);
					to_domain[36]=0;
					mss=strtok(0,"\n");
				}
				strtok(mss," :");
				p=strtok(0,":");
				if(p)msg.o_zone=(word)atol(p);
				p=strtok(0,"/");
				msg.orig_net=(word)atol(p);
				if(ispoint) p=strtok(0,".");
				else if (isdomain) p=strtok(0,"@");
				else p=strtok(0," ");
				if(p)msg.orig=(word)atol(p);
				if(ispoint) {
					p=strtok(0,"@ ");
					if(p && (word)atol(p) && atol(p)<65536L)
						msg.o_point=(word)atol(p);
				}
				if(isdomain) {
					p=strtok(0," \r");
					if(p) strncpy(to_domain,p,37);
					to_domain[36]=0;
				}
				continue;
           }
           if (*message=='\x1' && !ctla) continue;
           if(type==NOQUOTE) continue;
           if (!*message || !strcmp(message," ") || !*quotestring) ffprintf(pp,"%s\r\n",message);
           else if (strcspn(message,">")>3) ffprintf(pp,"%s%s\r\n",quotestring,message);
           else ffprintf(pp," >%s\r\n",message);
		  }
		  else {
			if (type==EDITIT) {
				if(!strncmp(message," * Origin: ",11)) continue;
				if(!strncmp(message,"--- ",4)) continue;
				if(!strncmp(message,"\01REPLY: ",8)) {
					strncpy(replyid,&message[7],80);
					replyid[79]=0;
					lstrip(replyid);
					rstrip(replyid);
					continue;
				}
				if (*message=='\01') continue;
			}
			if (type==PRINTIT) {
				if((lines)>(pagelength-bottommargin)) {
					ffprintf(pp,"\xc");
					if(wnd)wprintf(wnd,"\n<=-Page Break-=>\n");
					for (x=0;x<topmargin;x++) {
						ffprintf(pp,"\r\n");
						if(wnd)wprintf(wnd,"\n");
					}
					lines=topmargin;
				}
			}
			if (type==PRINTIT) {
				for (x=0;x<(word)leftmargin;x++) {
					ffprintf(pp," ");
					if(wnd)wprintf(wnd," ");
				}
			}
			if(!ctla && *message=='\01');
			else {
				ffprintf(pp,"%s\r\n",message);
				if(wnd)wprintfraw(wnd,"%s\n",message);
				lines++;
			}
		  }
	   }
	   if(hold)free(hold);
	   if (type==QUOTE && !*quotestring && !noquote) {
			if(after_quote) {
				ffprintf(pp,after_quote);
				ffprintf(pp,"\r\n\r\n");
			}
	   }
	   if (type==PRINTIT) {
			for (x=0;x<strlen(aftertext);x++) {
				if (aftertext[x]=='\n') {
					lines++;
					ffprintf(pp,"\r\n");
					if(wnd)wprintf(wnd,"\n");
				}
				else {
					ffprintf(pp,"%c",aftertext[x]);
					if(wnd)wprintfraw(wnd,"%c",aftertext[x]);
				}
				if(aftertext[x]=='\xc') lines=0;
			}
	   }
	   if(type!=NOQUOTE)_close(pp);

    return 1;
}

