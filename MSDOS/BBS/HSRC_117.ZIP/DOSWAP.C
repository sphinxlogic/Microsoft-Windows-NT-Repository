#include "stdlib.h"
#include "alloc.h"
#include "stdio.h"
#include "conio.h"
#include "dos.h"
#include "string.h"
#include "mem.h"
#include "io.h"

char   SwapName[66];
extern char   swapname[];
extern char   useswapdisk;
extern char   LIMEMS;
unsigned long BytesSwapped;
unsigned int  PrefixSeg;
char 	      FileAllocated=0;
unsigned int  EmsHandle;
char 		  EmsAllocated;
unsigned int  FrameSeg;
unsigned int  FileHandle;
unsigned 	  EmsPageSize=16384;

#define FALSE 0

extern unsigned cdecl _psp;


/* NOTE!  If you're using this in a memory model other than any of the
**  Large code size models, you'll need to make these all *far* calls!
*/

extern char far pascal ALLOCATESWAPFILE(), far pascal EMSINSTALLED();
extern unsigned far pascal EMSPAGEFRAME(), far pascal ALLOCATEEMSPAGES (unsigned),
  far pascal EXECWITHSWAP (char far *, char far *);
extern void far pascal DEALLOCATEEMSHANDLE(unsigned), huge FIRSTTOSAVE(),
  far pascal DEALLOCATESWAPFILE();


int pascal doswap (char far *command_str, char far *args)

/*
**    The first calling parameter *must* include the complete program name
**  and path, including the program name's file extension!  You can easily
**  get this with "searchpath()"    Example:  p = searchpath("PKZIP.EXE");
**  and then pass "p" as the first parameter to "doswap()".
**
**    The second calling parameter above is a string of parameters to pass
**  to the external program, or "" if none.  With the example given above,
**  you might use "-ex arc-name filesone.ext filestwo.exe" to archive both
**  the "filesone.ext" and "filestwo.exe" into ARC-NAME.ZIP using PKZip.
*/

{
 char exec_tail[128], exec_file[128], far *ivt, huge *end_mem, huge *start_mem,
   far *vptr;
 int swapcode;
 long freefarmem;
 unsigned EMS_pagesneeded;
 extern char **_heaptop;

  for (swapcode= 6; swapcode < 20; swapcode++) {
	  _close(swapcode);
  }
  sprintf(SwapName, "%c:%s",useswapdisk,swapname);
  vptr = MK_FP(0x0000, 0x0000);
  ivt = farmalloc(1024);

/*
THIS IS THE REAL WAY TO DO THE FOLLOWING, BUT UNFORTUNATELY, TURBO C CHEATS
AND CLAIMS *ALL* AVAILABLE RAM AT LOAD TIME, AND DOESN'T HAVE TO BOTHER WITH
ADJUSTING THIS WHEN MEMORY IS DYNAMICALLY ALLOCATED.  THE ONLY TIME IT IS SET
IS WHEN THE "spawnlp()" PROCEDURE SHELLS OUT or "system()" IS USED SO PROGRAMS
HAVE MEMORY AVAILABLE.  Oh, well - so much for "doing it right" <grin>...
        (the unsigned integer at _PSP+2 is supposed to be the
         exact number of paragraphs the program has assigned)


 unsigned last_seg;
 long memallocated;

  last_seg = *((unsigned far *)(MK_FP(_psp, 2)));
  memallocated = 16L * (long)(last_seg - _psp);


Instead I compute the exact size of memory between the _FirstToSwap label in
the SWAP.ASM code and **__heaptop, the end of available memory, then subtract
the amount of available dynamic memory (far heap) and fudge it by 3k hopefully
getting away with there being less than 3k worth of fragmentation from holes
left in that area by freeing pointers.  If less than 3k of far RAM is free, I
swap the whole thing - right to the top of memory but never beyond.

*/

  start_mem = (char huge *) FIRSTTOSAVE;
  end_mem = (char huge *) _heaptop;
  freefarmem = farcoreleft();
  if (freefarmem < 3072)
    freefarmem = 0;
  else
    freefarmem -= 3072;
  BytesSwapped = (unsigned long) (end_mem - start_mem) - freefarmem;

/* ----------------- */

  PrefixSeg = _psp;

  fputs("\n\x1b[K",stdout);
  if ((LIMEMS) && (EMSINSTALLED ()))
  {
	EMS_pagesneeded = (unsigned) ((BytesSwapped + EmsPageSize + 1) / EmsPageSize);
    if ((EmsHandle = ALLOCATEEMSPAGES (EMS_pagesneeded)) != 0xffff)
    {
      EmsAllocated = 1;
      FrameSeg = EMSPAGEFRAME();
	  printf("Swapping %lu bytes to EMS - %u pages (%dk)\n", BytesSwapped, EMS_pagesneeded, 16 * EMS_pagesneeded);
    }
  }
  else
    EmsAllocated = FALSE;
  if (!EmsAllocated && (FileAllocated = ALLOCATESWAPFILE ()) == 0)
  {
	printf("\n\x1b[K");
	printf("ERROR! Cannot Swap to EMS or Disk File `%s'\n", SwapName);
    return(-1);
  }
  if (FileAllocated)
	printf("Swapping %lu bytes to disk file `%s'...\n", BytesSwapped, SwapName);
  strcpy (exec_file, command_str);
  strcpy (exec_tail, " ");
  strcat (exec_tail, args);
  strcat (exec_tail, "\r");
  exec_tail[0] = (char) strlen (exec_tail) - 2;
  disable();
  memcpy((char far *) ivt, (char far *) vptr, 1024);
  enable();
  swapcode = EXECWITHSWAP ((char far *) exec_file, (char far *) exec_tail);
  disable();
  memcpy((char far *) vptr, (char far *) ivt, 1024);
  enable();
  if (EmsAllocated)
  {
    DEALLOCATEEMSHANDLE (EmsHandle);
    EmsAllocated = 0;
  }
  else if (FileAllocated)
  {
    DEALLOCATESWAPFILE ();
    FileAllocated = 0;
  }
  farfree ((char far *) ivt);
  return (swapcode);
}
