/* List-pick functions */

#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"

extern WINDOW *ewnd;


word pascal list_mess (void) {

    char s[60];
    word top;
    word low;
	word counter;
	word tempmess;
	int  selection;
	WINDOW *wnd;

		set_help("messlist  ",18,0);
		clear_message();
        wnd=establish_window(0,0,maxy,maxx);
		set_border(wnd,1);
		sprintf(s," Listing Area#%u for selection -- F10 to jump ",areano);
		set_title(wnd,s);
		display_window(wnd);
		wcursor(wnd,0,0);
		counter=0;
		tempmess=messno;
		low=messno;
OverAgain:
        if(nomess>maxy-3) {
            if ((nomess-low)<maxy-2) low=nomess-(maxy-3);
		}
		else low=1;
		while(1) {
			messno=low++;
			get_mess(1);
			msg2.from[17]=0;
			msg2.to[17]=0;
			msg2.subj[34]=0;
			wprintfraw(wnd,"%05u %-17s %-17s  %s",messno,msg2.from,msg2.to,msg2.subj);
			counter++;
			if (counter>=maxy-2 || low>nomess) break;
			wputchar(wnd,'\n');
		}
Again:
                selection=get_selection(wnd,1,NULL);
                if(selection>0 && selection<maxy-1) {
                    if(nomess>maxy-3)messno=(messno-(maxy-2))+selection;
					else messno=(messno-nomess)+selection;
					if(messno>nomess) messno=nomess;
					clear_message();
					delete_window(wnd);
					return messno;
				}
				counter=0;
                switch (selection) {
					case F10:   low=select_mess();
								break;
					case HOME:	low=1;
								break;
                    case END:   if(nomess>(maxy-3)) low=nomess-(maxy-3);
								else low=1;
								break;
					case PGUP:
                    case BS:    if(low<(maxy) && nomess>(maxy-3)) {
                                    low=nomess-(maxy-3);
									break;
								}
                                if (low<(maxy-1)) break;
                                else if (low<((maxy * 2)-5)) low=1;
                                else low-=((maxy * 2)-6);
								break;
					case PGDN:
					case FWD:   if (low>nomess)	low=1;
                                else if ((nomess-low)<(maxy-2)) {
                                    if (nomess>(maxy-3)) low=nomess-(maxy-3);
									else low=1;
								}
								break;
					case 0: 	goto BreakOut;
					default:	bell();
								break;
				}
				clear_message();
				clear_window(wnd);
				wcursor(wnd,0,0);
				goto OverAgain;
BreakOut:
		clear_message();
		delete_window(wnd);
		messno=tempmess;
		return messno;
}



word pascal list_areas (void) {

	char s[60];
	word lineareas[51];
	word temparea;
    char dirstring[133];
	word counter;
	register word x;
	word temp;
	int  temporary;
    int  selection;
	struct ffblk f;
	WINDOW *wnd;

		set_help("arealist  ",18,0);
		clear_message();
		wnd=establish_window(0,0,maxy,maxx);
        set_border(wnd,1);
		sprintf(s," Listing areas for selection -- F10 to jump ");
        set_title(wnd,s);
        display_window(wnd);
        wcursor(wnd,0,0);
		temparea=areano;
		x=0;
OverAgain:
		counter=0;
		for(temporary=0;temporary<(maxy+1);temporary++)lineareas[temporary]=0;
		while(1) {
				areano=marea[x].number;
				if(areano>4096) break;
				temporary=find_area();
				if(!temporary) break;
				sprintf(dirstring,"%sXDATA.%03x",path,areano);
				if (findfirst(dirstring,&f,0)) temp=0;
				else temp=(word)(f.ff_fsize/(long)sizeof(struct _xmsg));
				lineareas[counter]=areano;
				wprintf(wnd,"Area#%-4u %-16.16s %-5u message(s) ",areano,currarea->name,temp);
                if (temp>lastread[areano-1]+1) wprintf(wnd," --New @ %-5u",lastread[areano-1]+1);
                else if (temp) wprintf(wnd," (None New)   ");
                else wprintf(wnd,"              ");
				wprintf(wnd,"%s",area_attr());
				x++;
				counter++;
				if(counter>=(maxy-2) || x>=maxareas) break;
				wprintf(wnd,"\n");
		}
Again:
                selection=get_selection(wnd,1,NULL);
				if(selection>0 && selection<(maxy-1)) {
					if(lineareas[selection-1])areano=lineareas[selection-1];
					else {
						bell();
						goto Again;
					}
					nomess=check_area(areano);
					find_area();
					clear_message();
					delete_window(wnd);
					return areano;
                }
                switch (selection) {
					case F10:	areano=select_area();
								if(areano) {
									nomess=check_area(areano);
									find_area();
									clear_message();
									delete_window(wnd);
									return areano;
								}
                                break;
					case HOME:  x=0;
                                break;
					case END:   if(maxareas>(maxy-3)) x=maxareas-(maxy-2);
								else x=1;
                                break;
                    case PGUP:
					case BS:    if(x<(maxy-1) && maxareas>(maxy-3)) {
									x=maxareas-(maxy-2);
                                    break;
                                }
								if (x<(maxy-3)) break;
								else if (x<((maxy * 2)-6)) x=0;
								else x-=((maxy * 2)-5);
                                break;
                    case PGDN:
					case FWD:   if (x>=maxareas) x=0;
								else if ((maxareas-x)<(maxy-2)) {
									if (maxareas>(maxy-3)) x=maxareas-(maxy-2);
									else x=0;
                                }
                                break;
                    case 0:     goto BreakOut;
                    default:    bell();
                                break;
                }
				counter=0;
				clear_message();
                clear_window(wnd);
                wcursor(wnd,0,0);
                goto OverAgain;
BreakOut:
		clear_message();
		delete_window(wnd);
		areano=temparea;
		return areano;
}

