#include <time.h>


long make_msgid (void) {

    time_t t;
	static unsigned int counter=0;

    (void)time(&t);
    t = (t<<4) | (counter++ & 15);
    return t;
}
