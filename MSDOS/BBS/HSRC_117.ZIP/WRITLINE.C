#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"


/* Return a line from a message */

char * pascal write_line (char **text,word linelen,char ctla) {

    static char line[133];
	word register x=0;
	char *p;
	char *pp;

	if(!*text) return "";
	if(!**text) return *text;
	p=*text;
	pp=line;
	*pp=0;
	while(++x<(linelen+1) && *p && *p!='\r') {
		if(*p=='\n' || *p=='\x8d') {
			p++;
			continue;
		}
		if((*p=='\01' && (*(p-1)=='\r' || p==*text)) && !ctla) {
			while(*p!='\r' && *p)p++;
			if(*p=='\r') p++;
			continue;
		}
		*pp++=*p++;
		*pp=0;
	}
	if(*p=='\r') {
		*pp=0;
		p++;
	}
	else if(*p==' ') {
		*pp=0;
		while(*p==' ') p++;
	}
	else if(x==(linelen+1)) {
		if(strchr(line,' ')) {
			while(p>*text && *pp!=' ') {
				*pp=0;
				pp--;
				p--;
			}
			if(p==*text) {
				strncpy(line,*text,linelen+1);
				line[linelen+1]=0;
				p=text[linelen+1];
			}
			else p++;
		}
	}
	while(*pp==' ' && pp>line) {	/* Rstrip returned string */
		*pp=0;
		--pp;
	}
	*text=p;
	return line;
}

