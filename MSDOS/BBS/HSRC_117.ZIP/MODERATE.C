#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"

    struct tracker {
        char *str;
        word x;
        struct tracker *next;
    };

extern WINDOW *ewnd;

extern char pascal ask_question(char *);
struct tracker * pascal sort_tracker (struct tracker *);
void pascal free_trackers(struct tracker *);



void pascal do_breakdown (void) {

    WINDOW *wnd;
    char *hold,*tempo,*p;
	char appendto=0;
	struct ffblk f;
	char fname[81];
	char m[81];
	word from,to,tempmessno,percent;
	struct tracker *froms,*tos,*subjs,*origins,*tf,*tt,*ts,*too,*ttt;
	int prnthandle=0;
	long total,counter,scanned;

    froms=tos=subjs=origins=tf=tt=ts=too=NULL;
    sprintf(m,"%01u",messno);
    from=(word)atol(get_string(" Start at which #:",5,m,'N'));
    if(from<1 || from>nomess) return;
    sprintf(m,"%01u",nomess);
    to=(word)atol(get_string(" End at which #:",5,m,'N'));
    if(to<from) to=nomess;
	sprintf(m,"ECHOBDN.%03x",currarea->number);
	strcpy(fname,get_string(" Export filename: ",78,m,'A'));
	if(!findfirst(fname,&f,0)) {
		sprintf(m," %1.55s exists...overwrite? (Y/n)",fname);
		tempmessno=ask_question(m);
		if(tempmessno=='N' || tempmessno==ESC) appendto=1;
		set_help("",0,0);
	}
	tempmessno=messno;

	_anymsg(" Working... ","                    ");
	scanned=0L;
    for(messno=from;messno<(to+1);messno++) {
        wcursor(ewnd,0,0);
		wprintf(ewnd," %01u  %01lu",messno,farcoreleft());
		get_mess(0);
		if(msg.m_attr & MSGDELETED) continue;
		scanned++;
		if((currarea->attr & ECHO) || (currarea->attr & ALTECHO)) {
		  hold=get_text();
		  if(hold) {
			tempo=strstr(hold,"\r * Origin: ");
			if(!tempo)tempo=strstr(hold,"\n * Origin: ");
            if(tempo) {
				tempo+=12;
				p=strchr(tempo,'\r');
                if(p) *p=0;
                tempo=strrchr(tempo,'(');
                if(!tempo) goto SkipOrigins;
				tempo++;
                p=strchr(tempo,')');
                if(p)*p=0;
				rstrip(tempo);
				p=lstrip(tempo);
				while(*p!=' ' && *p)p++;
				if(*p==' ') {
					while(*p==' ')p++;
					tempo=p;
				}
                if(!tempo || !*tempo) goto SkipOrigins;
                if(origins) {
                    ttt=origins;
                    while(ttt) {
                        if(!stricmp(ttt->str,tempo)) {
                            ttt->x++;
                            goto SkipOrigins;
                        }
                        ttt=ttt->next;
                    }
                }
                ttt=(struct tracker *)malloc(sizeof(struct tracker));
                if(!ttt) {

                }
                else {
                    ttt->str=strdup(tempo);
                    ttt->x=1;
                    ttt->next=NULL;
                    if(!origins) {
                        origins=ttt;
                        too=origins;
                    }
                    else {
                        too->next=ttt;
                        too=ttt;
                    }
                }
            }
SkipOrigins:
            if(hold)farfree(hold);
		  }
		}
        if(froms) {
            ttt=froms;
            while(ttt) {
                if(!stricmp(ttt->str,msg.from)) {
                    ttt->x++;
                    goto SkipFroms;
                }
                ttt=ttt->next;
            }
        }
        ttt=(struct tracker *)malloc(sizeof(struct tracker));
        if(!ttt) {

        }
        else {
			ttt->str=strdup(lstrip(rstrip(msg.from)));
            ttt->x=1;
            ttt->next=NULL;
            if(!froms) {
                froms=ttt;
                tf=froms;
            }
            else {
                tf->next=ttt;
                tf=ttt;
            }
        }
SkipFroms:
        if(tos) {
            ttt=tos;
            while(ttt) {
                if(!stricmp(ttt->str,msg.to)) {
                    ttt->x++;
                    goto SkipTos;
                }
                ttt=ttt->next;
            }
        }
        ttt=(struct tracker *)malloc(sizeof(struct tracker));
        if(!ttt) {

        }
        else {
			ttt->str=strdup(lstrip(rstrip(msg.to)));
            ttt->x=1;
            ttt->next=NULL;
            if(!tos) {
                tos=ttt;
                tt=tos;
            }
            else {
                tt->next=ttt;
                tt=ttt;
            }
        }
SkipTos:
        if(subjs) {
            ttt=subjs;
            while(ttt) {
				p=msg.subj;
				while(*p==' ')p++;
				if(!strnicmp(p,"RE:",3)) {
					p+=3;
					while(*p==' ')p++;
				}
				if(!stricmp(ttt->str,p)) {
                    ttt->x++;
                    goto SkipSubjs;
                }
                ttt=ttt->next;
            }
        }
        ttt=(struct tracker *)malloc(sizeof(struct tracker));
        if(!ttt) {

        }
        else {
			p=msg.subj;
			while(*p==' ')p++;
			if(!strnicmp(p,"RE:",3)) {
				p+=3;
				while(*p==' ')p++;
			}
			ttt->str=strdup(lstrip(rstrip(p)));
            ttt->x=1;
            ttt->next=NULL;
            if(!subjs) {
                subjs=ttt;
                ts=subjs;
            }
            else {
                ts->next=ttt;
                ts=ttt;
            }
        }
SkipSubjs:
;
	}

	wprintf(ewnd,"\n Sorting ");
    if(froms) froms=sort_tracker(froms);
    if(tos) tos=sort_tracker(tos);
    if(subjs) subjs=sort_tracker(subjs);
	if(origins) origins=sort_tracker(origins);

    clear_message();
	wnd=establish_window(7,5,maxy-5,80);
	set_title(wnd," Msg area breakdown ");
	set_colors(wnd,ALL,BLACK,WHITE,BRIGHT);
    set_colors(wnd,ACCENT,WHITE,BLACK,BRIGHT);
    set_colors(wnd,BORDER,BLACK,AQUA,DIM);
    set_colors(wnd,TITLE,BLACK,AQUA,BRIGHT);
    display_window(wnd);
    wcursor(wnd,0,0);

    if(!stricmp(fname,"PRN")) {
        _AH=2;
        _DX=0;
        geninterrupt(0x17);
        if (_AH!=144) {
            error_message(" Printer not ready ");
            pause();
            _AH=2;
            _DX=0;
            geninterrupt(0x17);
            if(_AH!=144) prnthandle = -1;
        }
    }
    if(!prnthandle && *fname) {
		if(!appendto)unlink(fname);
		prnthandle=_open(fname,O_WRONLY | O_BINARY | O_DENYWRITE);
		if(prnthandle== -1) prnthandle=creat(fname,S_IWRITE);
    }

    if(prnthandle!= -1) {
		if(stricmp(fname,"PRN") && appendto) lseek(prnthandle,0L,SEEK_END);
		ffprintf(prnthandle,"\r\n\r\n Date:  %s\r\n",fidodate());
		ffprintf(prnthandle,"\r\n Summary of echo area #%u  \"%s\":\r\n Scanned %lu msgs\r\n\r\n",currarea->number,currarea->name,scanned);
    }
    else prnthandle= -1;
	wprintf(wnd,"Summary of echo area #%u  \"%s\":\nScanned %lu msgs\n\n",currarea->number,currarea->name,scanned);

    if(froms) {
        counter=total=0L;
		if(prnthandle!= -1) {
			ffprintf(prnthandle,"Author                                 #posts\r\n");
			ffprintf(prnthandle,"=============================================\r\n");
        }
		wprintf(wnd,"Author                                 #posts\n");
		wprintf(wnd,"=============================================\n");
        tt=froms;
		while(tt) {
		  if(tt->str) {
			if(prnthandle!= -1) {
				ffprintf(prnthandle,"%-40.40s%5u",tt->str,tt->x);
            }
			wprintf(wnd,"%-40.40s%5u",tt->str,tt->x);
			percent=(word)(((long)tt->x * 100L) / scanned);
			if(percent) {
				if(prnthandle!= -1) {
					ffprintf(prnthandle,"  (%u%%)",percent);
				}
				wprintf(wnd,"  (%u%%)",percent);
			}
			if(prnthandle != -1) {
				ffprintf(prnthandle,"\r\n");
			}
			wprintf(wnd,"\n");
			total+=(long)tt->x;
            counter++;
		  }
		  tt=tt->next;
        }
        if(prnthandle!= -1) {
            ffprintf(prnthandle,"=============================================\r\n");
			ffprintf(prnthandle,"Totals:  %5lu                          %5lu\r\n\r\n",counter,total);
        }
        wprintf(wnd,"=============================================\n");
        wprintf(wnd,"Totals:  %5lu                          %5lu\n\n",counter,total);
    }
    if(tos) {
        counter=total=0L;
        if(prnthandle!= -1) {
            ffprintf(prnthandle,"Recipient                               #msgs\r\n");
            ffprintf(prnthandle,"=============================================\r\n");
        }
        wprintf(wnd,"Recipient                               #msgs\n");
        wprintf(wnd,"=============================================\n");
        tt=tos;
        while(tt) {
		  if(tt->str) {
			if(prnthandle!= -1) {
				ffprintf(prnthandle,"%-40.40s%5u",tt->str,tt->x);
            }
			wprintf(wnd,"%-40.40s%5u",tt->str,tt->x);
			percent=(word)(((long)tt->x * 100L) / scanned);
			if(percent) {
				if(prnthandle!= -1) {
					ffprintf(prnthandle,"  (%u%%)",percent);
				}
				wprintf(wnd,"  (%u%%)",percent);
			}
			if(prnthandle != -1) {
				ffprintf(prnthandle,"\r\n");
			}
			wprintf(wnd,"\n");
			total+=(long)tt->x;
            counter++;
		  }
		  tt=tt->next;
		}
        if(prnthandle!= -1) {
            ffprintf(prnthandle,"=============================================\r\n");
			ffprintf(prnthandle,"Totals:  %5lu                          %5lu\r\n\r\n",counter,total);
        }
        wprintf(wnd,"=============================================\n");
        wprintf(wnd,"Totals:  %5lu                          %5lu\n\n",counter,total);
    }
    if(subjs) {
        counter=total=0L;
		if(prnthandle!= -1) {
			ffprintf(prnthandle,"Subject                                                    #times\r\n");
			ffprintf(prnthandle,"=================================================================\r\n");
        }
		wprintf(wnd,"Subject                                                    #times\n");
		wprintf(wnd,"=================================================================\n");
        tt=subjs;
        while(tt) {
		  if(tt->str) {
			if(prnthandle!= -1) {
				ffprintf(prnthandle,"%-60.60s%5u",tt->str,tt->x);
            }
			wprintf(wnd,"%-60.60s%5u",tt->str,tt->x);
			percent=(word)(((long)tt->x * 100L) / scanned);
			if(percent) {
				if(prnthandle!= -1) {
					ffprintf(prnthandle,"  (%u%%)",percent);
				}
				wprintf(wnd,"  (%u%%)",percent);
			}
			if(prnthandle != -1) {
				ffprintf(prnthandle,"\r\n");
			}
			wprintf(wnd,"\n");
			total+=(long)tt->x;
            counter++;
		  }
		  tt=tt->next;
        }
        if(prnthandle!= -1) {
			ffprintf(prnthandle,"=================================================================\r\n");
            ffprintf(prnthandle,"Totals:  %5lu                                              %5lu\r\n\r\n",counter,total);
        }
		wprintf(wnd,"=================================================================\n");
        wprintf(wnd,"Totals:  %5lu                                              %5lu\n\n",counter,total);
    }
    if(origins) {
        counter=total=0L;
		if(prnthandle!= -1) {
			ffprintf(prnthandle,"Origin                       #posts\r\n");
			ffprintf(prnthandle,"===================================\r\n");
        }
		wprintf(wnd,"Origin                       #posts\n");
		wprintf(wnd,"===================================\n");
        tt=origins;
        while(tt) {
		  if(tt->str) {
			if(prnthandle!= -1) {
				ffprintf(prnthandle,"%-30.30s%5u",tt->str,tt->x);
            }
			wprintf(wnd,"%-30.30s%5u",tt->str,tt->x);
			percent=(word)(((long)tt->x * 100L) / scanned);
			if(percent) {
				if(prnthandle!= -1) {
					ffprintf(prnthandle,"  (%u%%)",percent);
				}
				wprintf(wnd,"  (%u%%)",percent);
			}
			if(prnthandle != -1) {
				ffprintf(prnthandle,"\r\n");
			}
			wprintf(wnd,"\n");
			total+=(long)tt->x;
            counter++;
		  }
		  tt=tt->next;
        }
		wprintf(wnd,"===================================\n");
        wprintf(wnd,"Totals:  %5lu                %5lu",counter,total);
		if(prnthandle!= -1) {
			ffprintf(prnthandle,"===================================\r\n");
            ffprintf(prnthandle,"Totals:  %5lu                %5lu\r\n\r\n",counter,total);
		}
    }
    if(prnthandle && prnthandle!= -1)_close(prnthandle);
    if(froms) free_trackers(froms);
    if(tos) free_trackers(tos);
    if(subjs)free_trackers(subjs);
    if(origins)free_trackers(origins);

    _anymsg(" Complete "," Any key ");
    pause();
    delete_window(wnd);
    messno=tempmessno;
    get_mess(0);
}



void pascal free_trackers (struct tracker *t) {

    struct tracker *tt,*ttt;

    if(t) {
        tt=t;
        while(tt) {
            if(tt->str)free(tt->str);
            ttt=tt->next;
            free(tt);
            tt=ttt;
        }
    }
}



struct tracker * pascal sort_tracker (struct tracker *t) {

    struct tracker *tempt,*tempt2,*last;
    char swapped;

	do {        /* Sort by ascending string */
        tempt=t;
        last=NULL;
		swapped=0;
        while(tempt) {
            if(tempt->next) {
                if(stricmp(tempt->str,tempt->next->str)>0) {
                    if(tempt==t) {
                        t=tempt->next;
					}
                    tempt2=tempt->next;
                    tempt->next=tempt->next->next;
                    tempt2->next=tempt;
                    if(last)last->next=tempt2;
                    swapped=1;
				}
            }
            last=tempt;
            tempt=tempt->next;
        }
	} while (swapped);

	do {            /* Then sort by descending quantity */
        tempt=t;
        last=NULL;
        swapped=0;
        while(tempt) {
            if(tempt->next) {
				if(tempt->x < tempt->next->x) {
                    if(tempt==t) {
                        t=tempt->next;
                    }
                    tempt2=tempt->next;
                    tempt->next=tempt->next->next;
                    tempt2->next=tempt;
                    if(last)last->next=tempt2;
                    swapped=1;
				}
            }
            last=tempt;
            tempt=tempt->next;
        }
    } while (swapped);

    return t;
}

