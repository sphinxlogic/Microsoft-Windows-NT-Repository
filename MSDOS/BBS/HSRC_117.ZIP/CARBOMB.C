#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"


int pascal bomb_who (struct _bomb_addr *bomb_addr) {

    long x;
    static char zone[6]="";
    static char net[6]="";
    WINDOW *wndd;
    FIELD *fldd;
    int returncode;

    clear_message();
	wndd=establish_window(4,maxy-7,8,40);
    set_border(wndd,3);
    set_title(wndd," Bomb Run ");
    set_colors(wndd,BORDER,7,0,0);
    display_window(wndd);
    wcursor(wndd,0,0);
    wprintf(wndd," F10 to bomb net shown or ESC to abort");
    if (!*zone || !(word)atol(zone)) {
        sprintf(zone,"%u",curaddress.zone);
    }
    if (!*net || !(word)atol(net)) {
        sprintf(net,"%u",curaddress.net);
    }
    init_template(wndd);
    wprompt(wndd,1,3,"Zone:");
    wprompt(wndd,1,4,"Net:");
    fldd=establish_field(wndd,9,3,msk5,zone,'N');
    field_window(fldd,"bombzone  ",40,5);
    fldd=establish_field(wndd,9,4,msk5,net,'N');
    field_window(fldd,"bombnet   ",40,6);
BombOver:
    returncode=data_entry(wndd);
    if (returncode==ESC){
         delete_window(wndd);
         return 0;
    }
    if (returncode!=F10) goto BombOver;
    if(!*zone || !*net || !(word)atol(zone) || !(word)atol(net)) {
        error_message(" You must fill in all fields! ");
        pause();
        goto BombOver;
    }
    bomb_addr->zone=(word)atol(zone);
    bomb_addr->net=(word)atol(net);
    for (x=0;x<(nidxsize+1);x++) {
        if (nidx[x].zone==bomb_addr->zone && nidx[x].net==bomb_addr->net) break;
    }
    if(x>nidxsize) {
        error_message(" Unknown net--can't bomb ");
        pause();
        goto BombOver;
    }
    any_message(" I sure hope you know what you're doing... ");
    sleep(1);
    delete_window(wndd);
    return 1;
}



int pascal fill_in_carbon (struct _carbon *carbon) {

    char name[36]="";
    WINDOW *wndd;
    FIELD *fldd;
    int returncode;

    clear_message();
    if((currarea->attr & NET) || (currarea->attr & ALTERNATE)) {
		wndd=establish_window(4,maxy-7,12,55);
    }
	else wndd=establish_window(4,maxy-7,6,55);
    set_border(wndd,3);
    set_title(wndd," Who gets this carbon? ");
    set_colors(wndd,BORDER,7,0,0);
    display_window(wndd);
    wcursor(wndd,0,0);
    wprintf(wndd," F10 to accept or ESC to abort");
    *dest=0;
    *dest_net=0;
    *d_zone=0;
    strcpy(d_point,"0");
    strcpy(cost,"0");
    init_template(wndd);
    wprompt(wndd,1,2,"Name:");
    if((currarea->attr & NET) || (currarea->attr & ALTERNATE)) {
        wprompt(wndd,1,3,"Zone:");
        wprompt(wndd,1,4,"Net:");
        wprompt(wndd,1,5,"Node:");
        wprompt(wndd,1,6,"Point:");
        wprompt(wndd,1,7,"Cost:");
    }
    fldd=establish_field(wndd,8,2,msk35,name,'a');
    field_help(fldd,find_sysop);
    if((currarea->attr & NET) || (currarea->attr & ALTERNATE)) {
        fldd=establish_field(wndd,8,3,msk5,d_zone,'N');
        field_window(fldd,"carbzone  ",40,5);
        fldd=establish_field(wndd,8,4,msk5,dest_net,'N');
        field_window(fldd,"carbnet   ",40,5);
        fldd=establish_field(wndd,8,5,msk5,dest,'N');
        field_window(fldd,"carbnode  ",40,6);
        fldd=establish_field(wndd,8,6,msk5,d_point,'N');
        field_validate(fldd,dest_check);
        field_window(fldd,"carbpoint ",40,6);
        fldd=establish_field(wndd,8,7,msk5,cost,'N');
        field_window(fldd,"carbcost  ",40,7);
    }
    prep_template(wndd);
CarbOver:
    returncode=data_entry(wndd);
    if (returncode==ESC){
         delete_window(wndd);
         return 0;
    }
    if (returncode!=F10) goto CarbOver;
    rstrip(name);
    if((currarea->attr & NET) || (currarea->attr & ALTERNATE)) {
        if(!*d_zone || !*dest_net || !*dest || !*d_point || !(word)atol(d_zone) || !(word)atol(dest_net)) {
            error_message(" You must fill in all fields! ");
            pause();
            goto CarbOver;
        }
    }
    else if(!*name) {
        delete_window(wndd);
        return 0;
    }
    strcpy(carbon->name,name);
    if((currarea->attr & NET) || (currarea->attr & ALTERNATE)) {
        carbon->zone=(word)atol(d_zone);
        carbon->net=(word)atol(dest_net);
        carbon->node=(word)atol(dest);
        carbon->point=(word)atol(d_point);
        carbon->cost=atoi(cost);
    }
    delete_window(wndd);
    return 1;
}

