#include "io.h"
#include "stddef.h"
#include "stdarg.h"


/* An fgets() for shared i/o */

char * pascal fgetsx (char *str,int num,int handle) {

	char *p;
	long pos;
	int x;

	if (eof(handle)) {
		*str=0;
		return NULL;
	}
	pos=tell(handle);
	x=_read(handle,str,num-1);
	if (x<1) {
		*str=0;
		return NULL;
	}
	str[x]=0;
	p=str;
	while(*p && *p!='\r' && *p!='\n') p++;
	if(!*p) return str;
	if(*p=='\r') {
		*p='\n';
		if (p[1]=='\n') {
			p++;
			*p=0;
		}
	}
	p++;
	*p=0;
	lseek(handle,pos+((long)((unsigned int)p-(unsigned int)str)),SEEK_SET);
	return str;
}


/* An fprintf() for shared i/o */

int cdecl ffprintf (int handle,char *string,...) {

 unsigned int x;
 char buffer[512];

   va_list ap;
   va_start(ap,string);
   vsprintf(buffer,string,ap);
   va_end(ap);
   x=strlen(buffer);
   _write(handle,buffer,x);
   return x;
}

