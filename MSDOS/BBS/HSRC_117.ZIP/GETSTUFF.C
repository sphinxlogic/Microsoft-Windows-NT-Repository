/* Get origin line and quote string functions */

#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"



void pascal get_origin (void) {

	char temp[60];
	int returncode;
	WINDOW *wnd;
	FIELD *fld;

	strcpy(temp,origin);
	wnd=establish_window(3,maxy-7,6,76);
	set_border(wnd,3);
	set_title(wnd," Default Origin ");
	set_colors(wnd,BORDER,7,0,0);
	display_window(wnd);
	wcursor(wnd,0,0);
	wprintf(wnd," F10 to change or ESC to exit");
Again:
	wprompt(wnd,1,2,"* Origin:");
	fld=establish_field(wnd,14,2,msk59,origin,'a');
	field_window(fld,"changeorig",40,6);
	prep_template(wnd);
AskOver:
	returncode=data_entry(wnd);
	if (returncode==ESC) goto Quit;
	if (returncode!=F10) goto AskOver;
Quit:
	delete_window(wnd);
	rstrip(origin);
	if (!*origin) strcpy(origin,temp);
	return;
}



char * pascal get_qstring (char *quotestring) {

	int returncode;
	static char noquotes[2]="-";
	WINDOW *wnd;
	FIELD *fld;
    char *pp;

	wnd=establish_window(3,maxy-7,7,36);
	set_border(wnd,3);
	set_title(wnd," Quote String ");
	set_colors(wnd,BORDER,7,0,0);
	display_window(wnd);
	wcursor(wnd,0,0);
	wprintf(wnd," F10 to change or ESC for default");

    memset(quotestring,0,10); /* Build quote string */
    *quotestring=' ';
    if(*msg.from) {
          quotestring[1]=*msg.from;
          pp=strchr(msg.from,' ');
          if(pp && pp[1]) quotestring[2]=pp[1];
    }
    strcat(quotestring,"> ");

Again:
	wprompt(wnd,3,2,"String:");
	wprompt(wnd,3,3,"NoQuotes: [ ]");
	fld=establish_field(wnd,11,2,msk11,quotestring,'a');
	field_window(fld,"quotestrng",40,5);
	fld=establish_field(wnd,14,3,msk1,noquotes,'O');
	field_window(fld,"noquotes  ",40,6);
	prep_template(wnd);
AskOver:
	returncode=data_entry(wnd);
	if (returncode==ESC) {
		delete_window(wnd);
		return NULL;
	}
	if (returncode!=F10) goto AskOver;
Quit:
	delete_window(wnd);
	if (*noquotes=='X') return "NOQUOTE";
	rstrip(quotestring);
	return quotestring;
}

