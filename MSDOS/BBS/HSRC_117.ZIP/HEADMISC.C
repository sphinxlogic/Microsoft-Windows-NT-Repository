/* Miscellaneous functions */

#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"



char pascal isitme (char which) {

	register word x;
	char check1[36];
	char check3[36];

	if (!which) strcpy(check3,rstrip(msg.to));
	else strcpy(check3,rstrip(msg2.to));
	if (userno==1 && !stricmp(check3,"SYSOP")) return 1;
	if (noalias) {
		for (x=0;x<noalias;x++) {
			strcpy(check1,rstrip(alias[x]));
			if (!stricmp(check1,check3)) return 1;
		}
	}
	return 0;
}



word pascal check_area (word tempno) {

 struct ffblk f;

 sprintf(filename,"%sXDATA.%03x",path,tempno);
 sprintf(textname,"%sXTEXT.%03x",path,tempno);

 if (findfirst(filename,&f,0)) {
  sprintf(filename," No messages in area #%u ",tempno);
  any_message(filename);
  return 0;
 }

 tempno=(word)(f.ff_fsize/(long)sizeof(struct _xmsg));
 if (f.ff_fsize<(long)sizeof(struct _xmsg) || findfirst(textname,&f,0)){
	sprintf(filename," No messages in area #%u ",tempno);
	any_message(filename);
	return 0;
 }
 return tempno;
}



char * pascal rstrip (char *a) {

  register int x;

  x=strlen(a);
  while (x && a && a[x-1]==' ') a[--x]=0;
  return a;
}



char * pascal lstrip (char *a) {

  register int x;

  x=strlen(a);
  while (x && *a==' ') memmove (a,(a+1),x--);
  return (a);
}


char * pascal stripcr (char *a) {

  register int x;

  x=strlen(a);
  while (x && (a[x-1]=='\n' || a[x-1]=='\r')) a[--x]=0;
  return a;
}




int charlimit (char *bf,int key) {

  if (atoi(bf)<1 or atoi(bf)>255) {
	error_message(" 1-255! ");
	return ERROR;
  }
  return 0;

}


int messlimit (char *bf,int key) {

  char s[78];

  if (atol(bf)<1L or atol(bf)>(long)nomess) {
	sprintf(s," Try keeping it between 1 and %u ",nomess);
	error_message(s);
	return ERROR;
  }
  return 0;

}



char * pascal fidodate (void) {

 char months[12][4]={
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
 };
 static char fdate[20];
 struct date dos_date;
 struct time dos_time;

/* 26 Jul 89  06:23:47 */

 getdate(&dos_date);
 gettime(&dos_time);

 sprintf(fdate,"%02hu %s %02d  %02hu:%02hu:%02hu",dos_date.da_day,months[dos_date.da_mon-1],dos_date.da_year%100,dos_time.ti_hour,dos_time.ti_min,dos_time.ti_sec);
 return(fdate);
}


char * pascal saydate (struct date *a) {

static char xdate[11];

 sprintf(xdate,"%02hu/%02hu/%04u",a->da_mon,a->da_day,a->da_year);
 return(xdate);
}



char * pascal saytime (struct time *a) {

static char xtime[9];

 sprintf(xtime,"%02u:%02u:%02u",a->ti_hour,a->ti_min,a->ti_sec);
 return(xtime);
}




void pascal left(char *a,char *b,int x) {

  int i=0;
  x = (x <= strlen(b)) ? x : strlen(b);
  while (i++ < x) *a++ = *b++;
  *a = '\0';

}



void pascal strip_seenbys (char *hold) {

    char *path=NULL;
    char *seenby=NULL;
    char *origin=NULL;
    char *p;

        origin=strstr(hold,"\r * Origin:");
        if (origin) {
            while((p=strstr(&origin[1],"\r * Origin:"))) origin=p;
            path=strstr(origin,"\r\01PATH:");
            seenby=strstr(origin,"\rSEEN-BY:");
            if (!seenby) seenby=strstr(origin,"\r\01SEEN-BY:");
            if (!path) if (seenby) *seenby=0;
            if (seenby && path) memmove (seenby,path,strlen(path)+1);
        }
}



int yesorno (char *bf,int key) {

  if (*bf!='Y' && *bf!='N') {
	error_message(" Y or N! ");
	return ERROR;
  }
  return 0;

}



int noblank (char *bf,int key) {

  if (!strcspn(bf," ")) {
	error_message("Don't blank this field.");
	return ERROR;
  }
  return 0;
}


int cdecl break_handler (void) {

  clrr();
  return 0;

}



int lessthan256 (char *bf,int key) {

   if(atoi(bf)>255 || atoi(bf)<0) {
		error_message(" 0 to 255! ");
		return ERROR;
   }
   return 0;
}



char * pascal quick_attr (void) {

    word register x;
	word temp;
	static char attrstring[52];

	strcpy(attrstring,"Std->[");
	for (x=0;x<16;x++) {
	   temp=1;
	   temp=temp<<x;
	   (msg.attr & temp) ? strcat(attrstring,"X") : strcat (attrstring,"-");
	}
	strcat(attrstring,"]  Extra->[");
	for (x=0;x<16;x++) {
	   temp=1;
	   temp=temp<<x;
	   (msg.m_attr & temp) ? strcat(attrstring,"X") : strcat (attrstring,"-");
	}
	strcat(attrstring,"]");
	return attrstring;
}



char * pascal area_attr (void) {

    word register x;
	word temp;
	static char attrstring[22];

	strcpy(attrstring,"[");
	for (x=0;x<16;x++) {
	   temp=1;
	   temp=temp<<x;
	   (currarea->attr & temp) ? strcat(attrstring,"X") : strcat (attrstring,"-");
	}
	strcat(attrstring,"]");
	return attrstring;
}
