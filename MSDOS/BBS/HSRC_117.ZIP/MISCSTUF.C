#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"



void pascal strip_blanklines (char *hold) {

	char *p;

	p=&hold[strlen(hold)-1];
	while(*p=='\r' && p>hold) {
		*p=0;
		p--;
	}
}


void pascal get_rid () {

    char temp[86];

	 strcpy(temp,"MSGTMP");
	 unlink(temp);
     strcat(temp,".INF");
     unlink(temp);
}



void pascal print_clock (void) {

	struct time dos_time;
	static struct time hold_time;
	char temp;

	if(noclock) return;
    gettime(&dos_time);
	if (dos_time.ti_sec==hold_time.ti_sec) return;
	gettime(&hold_time);
	temp=current_color;
	current_color=7*16;
	dputs(maxx-9,maxy,saytime(&dos_time));
	current_color=temp;
}



void pascal clrr (void) {
	fputs("\x1b[2J",stdout);
}


void pascal bell (void) {
    if(!nobell)putchar('\07');
}



void pascal update_read (void) {

	msg.attr = msg.attr | MSGREAD;
	msg.times++;
	put_mess();

}


void pascal cls (int x,int y,int x1,int y1,int attr) {

	char temp;

	temp=current_color;
	if(!attr)attr=7;
	current_color=(char)attr;
    dclrwnd(x,y,x1,y1); /* From pd direct screen module */
	current_color=temp;
}

