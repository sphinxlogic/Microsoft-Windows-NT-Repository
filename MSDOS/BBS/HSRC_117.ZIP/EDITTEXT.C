#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"


/* Edit text (creates new msg, deletes old */

void pascal edit_text (void) {

	char tempchar;
	char tempctla;
	word tempnomess;
	word tempmessno;
	char olddate[20];
	char wasdeleted=0;
	char temp[81];

	tempctla=ctla;
	ctla=1;
	tempnomess=nomess;
	tempmessno=messno;
	strcpy(olddate,msg.date);

	strcpy(temp,"MSGTMP");
	get_rid();
	if(msg.m_attr & MSGSCANNED) {
		any_message(" Message already scanned...edit anyway? (y-N) ");
Loop:
		tempchar=(char)toupper(get_char());
		if(tempchar!='Y' && tempchar!='N' && tempchar!=13 && tempchar!=27) {
			bell();
			goto Loop;
		}
		if(tempchar!='Y') {
			clear_message();
			return;
		}
		clear_message();
	}
	if(edit_mess(1)==ESC) return;
	if (export(temp,((currarea->attr & NET) + (currarea->attr & ALTERNATE)),EDITIT,"","",NULL)==0) goto EndIt;
	if (msg.m_attr & MSGDELETED) wasdeleted=1;
	msg.m_attr |= MSGDELETED;
	msg.m_attr |= MSGTREATED;
	put_mess();
	if (!wasdeleted) msg.m_attr=msg.m_attr & (~MSGDELETED);
	strcpy(msg.date,fidodate());
	msg.m_attr |= MSGTREATED;
	post_mess("");
	nomess=check_area(areano);
	if (nomess==tempnomess) {
		msg.m_attr |= MSGTREATED;
		messno=tempmessno;
		strcpy(msg.date,olddate);
		put_mess();
	}

EndIt:
	ctla=tempctla;
}

