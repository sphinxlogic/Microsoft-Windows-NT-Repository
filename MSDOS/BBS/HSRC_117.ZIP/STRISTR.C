#include "stddef.h"


/* insensitive instr() for Turbo C */

char * pascal stristr (char *t, char *s) {

   char *t1;
   char *s1;

   while(*t) {
	  t1=t;
	  s1=s;
	  while(*s1) {
		 if (toupper(*s1)!=toupper(*t)) break;
		 else {
			s1++;
            t++;
         }
      }
	  if (!*s1) return t1;
	  t=t1+1;
   }
   return NULL;
}
