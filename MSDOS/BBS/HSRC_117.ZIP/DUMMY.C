void pascal CLEAROVERLAY(void) {}
void pascal _REINITOVERLAYS(void) {}
