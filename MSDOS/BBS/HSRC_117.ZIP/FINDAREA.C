#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"

int pascal find_area (void) {

    word register x;

	if (areano==0) return 0;
	if (!maxareas) goto NullArea;

	for (x=0;x<maxareas;x++) {
		if (marea[x].number==areano) {
			currarea=(struct _marea far *)&marea[x];
            if(!marea[x].thisname) {
                if(!notrack) {
                    if(noalias>1) {
                        if(marea[x].attr & REAL) strcpy(name,alias[0]);
                        else strcpy(name,alias[1]);
                    }
                }
            }
            else {
				strcpy(name,alias[(marea[x].thisname-1)]);
            }
            if(marea[x].thisaddr) {
                curaddress.zone=address[(marea[x].thisaddr)-1]->zone;
                curaddress.net=address[(marea[x].thisaddr)-1]->net;
                curaddress.node=address[(marea[x].thisaddr)-1]->node;
                curaddress.point=address[(marea[x].thisaddr)-1]->point;
                strcpy(curaddress.domain,address[(marea[x].thisaddr)-1]->domain);
            }
            return 1;
		}
		else if (marea[x].number>higharea) goto NullArea;
	}

NullArea:

	nullarea.attr=12;
	currarea=&nullarea;
	nullarea.number=areano;
    if(!notrack) {
        if(noalias>1)strcpy(name,alias[1]);
        else strcpy(name,alias[0]);
    }
    return 0;
}
