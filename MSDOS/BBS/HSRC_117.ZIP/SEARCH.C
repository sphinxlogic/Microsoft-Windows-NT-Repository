/* Performs search for matching msgs */


#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"

extern WINDOW *ewnd;


word pascal search (char type,char reverse) {

	static char from[36]="";
	static char to[36]="";
	static char subj[64]="";
	static char text[79]="";
	static char text2[79]="";
	static char text3[79]="";
	static char text4[79]="";
	char *textptr;
	static char exclude[2]="-";
	static char tome[2]="-";
	static char orit[2]="-";
	static char direction[2]="-";
	char compare[64];
	char *p;
	char far *hold;
	int returncode;
	word tempmess;
	char got=0;
	char miss=0;
	WINDOW *wnd=NULL;
	FIELD *fld;

	if (nomess<=1) return 0;
	tempmess=messno;
	if (!*from && !*to && !*subj && !*text && *tome!='X' && !*text2 && !*text3 && !*text4) type=0;
	if (!type) {
        wnd=establish_window(1,maxy-11,18,80);
		set_border(wnd,1);
		set_title(wnd," Message Search Criteria ");
		set_colors(wnd,BORDER,7,0,0);
		display_window(wnd);
		wcursor(wnd,0,0);
		wprintf(wnd," ESC to save, F10 to save & search");
		init_template(wnd);
		wprompt(wnd,1,2,"From:");
		wprompt(wnd,1,3,"To:");
		wprompt(wnd,1,4,"Subj:");
		wprompt(wnd,1,5,"Message body text:");
		wprompt(wnd,1,7,"Exclude:  [ ]");
		wprompt(wnd,1,8,"Personal: [ ]");
		wprompt(wnd,1,9,"Match any:[ ]");
		wprompt(wnd,18,9,"Backwards: [ ]");
		wprompt(wnd,1,10,"Additional body text:");
		wprompt(wnd,1,12,"Additional body text:");
		wprompt(wnd,1,14,"Additional body text:");
		fld=establish_field(wnd,7,2,msk35,from,'A');
		field_window(fld,"findfrom  ",40,4);
		fld=establish_field(wnd,7,3,msk35,to,'A');
		field_window(fld,"findto    ",40,4);
		fld=establish_field(wnd,7,4,msk63,subj,'A');
		field_window(fld,"findsubj  ",40,5);
		fld=establish_field(wnd,1,6,msk78,text,'A');
		field_window(fld,"bodytext  ",40,5);
		fld=establish_field(wnd,12,7,msk1,exclude,'O');
		field_window(fld,"exclude   ",40,6);
		fld=establish_field(wnd,12,8,msk1,tome,'O');
		field_window(fld,"tome      ",40,6);
		fld=establish_field(wnd,12,9,msk1,orit,'O');
		field_window(fld,"matchany  ",40,6);
		fld=establish_field(wnd,30,9,msk1,direction,'O');
		field_window(fld,"backward  ",40,6);
		fld=establish_field(wnd,1,11,msk78,text2,'A');
		field_window(fld,"bodytext  ",40,7);
		fld=establish_field(wnd,1,13,msk78,text3,'A');
		field_window(fld,"bodytext  ",40,7);
		fld=establish_field(wnd,1,15,msk78,text4,'A');
		field_window(fld,"bodytext  ",40,7);
		prep_template(wnd);
Over:
		returncode=data_entry(wnd);
		if (returncode!=F10 && returncode!=ESC) goto Over;
		if (returncode==ESC) {
			rstrip(from);
			rstrip(to);
			rstrip(subj);
			rstrip(text);
			rstrip(text2);
			rstrip(text3);
			rstrip(text4);
			clear_message();
			delete_window(wnd);
			return messno;
		}
	}
	else if (reverse) {
		if(*direction=='X') *direction='-';
		else *direction='X';
	}
	clear_message();
	if(wnd)delete_window(wnd);
	rstrip(from);
	rstrip(to);
	rstrip(subj);
	rstrip(text);
	rstrip(text2);
	rstrip(text3);
	rstrip(text4);
	if(*direction!='X')messno++;
	else messno--;
	if(messno>nomess) messno=1;
	while (messno>0 && messno<nomess+1) {
		 if (!ewnd) any_message(" Searching:        ");
		 wcursor(ewnd,12,0);
		 wprintf(ewnd,"%-5u",messno);
		 if (kbhit()) {
			returncode=get_char();
			if (returncode==' ' || returncode==ESC) break;
		 }
		 get_mess(1);
		 if (*tome=='X') {
			if (*exclude=='X') {
				if (isitme(1)) {
					miss++;
					if(*orit!='X') goto IncIt;
				}
				else {
					got++;
					if(*orit=='X') goto ThisOne;
				}
			}
			else {
				if (!isitme(1)) {
					miss++;
					if(*orit!='X') goto IncIt;
				}
				else {
					got++;
					if(*orit=='X') goto ThisOne;
				}
			}
		 }
		 if (*to) {
			 if ((*exclude=='X')==(stricmp(msg2.to,to)==0)) {
				miss++;
				if(*orit!='X') goto IncIt;
			 }
			 else {
				got++;
				if(*orit=='X')goto ThisOne;
			 }
		 }
		 if (*from) {
			 if ((*exclude=='X')==(stricmp(msg2.from,from)==0)) {
				miss++;
				if(*orit!='X') goto IncIt;
			 }
			 else {
				got++;
				if(*orit=='X')goto ThisOne;
			 }
		 }
		 if (*subj) {
			 strcpy(compare,msg2.subj);
			 if (!strnicmp(compare,"RE: ",4)) {
				strcpy(compare,&msg2.subj[4]);
			 }
			 rstrip(compare);
			 if ((*exclude!='X')==(stristr(compare,subj)==NULL)) {
				miss++;
				if(*orit!='X')goto IncIt;
			 }
			 else {
				got++;
				if(*orit=='X')goto ThisOne;
			 }
		 }
		 textptr=text;
		 hold=NULL;
		 if(*text || *text2 || *text3 || *text4) {
			get_mess(0);
			hold=get_text();
			if (!*hold || hold==NULL) goto IncIt;
TextLoop:
			if (*textptr) {
				p=stristr(hold,textptr);
				if (((*exclude!='X') && (p==NULL)) || ((*exclude=='X') && (p!=NULL))) {
					miss++;
					if(*orit!='X') {
						if(hold)free(hold);
						goto IncIt;
					}
				}
				else got++;
			 }
			 if(textptr==text) {
				textptr=text2;
				if(*textptr)goto TextLoop;
			 }
			 if(textptr==text2) {
				textptr=text3;
				if(*textptr)goto TextLoop;
			 }
			 if(textptr==text3) {
				textptr=text4;
				if(*textptr)goto TextLoop;
			 }
			 if(hold)free(hold);
		 }

		 if((*orit!='X' && miss) || !got) goto IncIt;
ThisOne:
		 clear_message();
		 return messno;
IncIt:
		 got=miss=0;
		 if(*direction!='X')messno++;
		 else messno--;
	}
	any_message("Complete.");
	nopause();
	messno=tempmess;
	get_mess(0);
	return messno;
}

