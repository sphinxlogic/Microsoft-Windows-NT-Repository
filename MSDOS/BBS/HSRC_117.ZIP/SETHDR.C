#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"

#include "headid.h"



int pascal set_header (char type,char *odate,char *ofrom,char *oto) {

	static char temp[86];
	word tempmess;
	word tempno;
	char wasprivate=0;
	int pp;
	char oldfrom[36];
	char oldto[36];
	char olddate[36];

	if(ofrom) strcpy(oldfrom,ofrom);
	if(oto)strcpy(oldto,oto);
	if(odate)strcpy(olddate,odate);
	tempmess=messno;
	tempno=nomess;
	nomess++;
	messno=nomess;

	if (type & INFOONLY) {
		strcpy(msg.to,"All");
		strcpy(msg.subj,"Miscellaneous");
		msg.d_point=curaddress.point;
		msg.dest=curaddress.node;
		msg.dest_net=curaddress.net;
		msg.d_zone=curaddress.zone;
		strcpy(to_domain,curaddress.domain);
	}
	else if (type!=NOINFO) {
		strcpy(msg.to,msg.from);
		if (strncmp(msg.subj,"Re: ",4)) {
			msg.subj[58]=0;
			strcpy(temp,msg.subj);
			sprintf(msg.subj,"Re: %s",temp);
		}
		msg.dest=msg.orig;
		msg.dest_net=msg.orig_net;
		msg.d_zone=msg.o_zone;
		msg.d_point=msg.o_point;
	}
	msg.times=0;
	msg.o_zone=curaddress.zone;
	msg.orig=curaddress.node;
	msg.orig_net=curaddress.net;
	msg.o_point=curaddress.point;
	strcpy(msg.date,fidodate());
	strcpy(msg.from,name);
	if ((msg.attr & MSGPRIVATE) && !(currarea->attr & ECHO)) wasprivate++;
	msg.attr=MSGLOCAL;
	msg.m_attr=0;
	if ((currarea->attr & NET) || (currarea->attr & ALTERNATE)) {
		msg.attr=(defaultattr | MSGLOCAL) & (~MSGSENT);
		msg.m_attr = msg.m_attr | MSGNET;
	}
	if (wasprivate) msg.attr=msg.attr | MSGPRIVATE;
	if ((currarea->attr & ECHO) || (currarea->attr & ALTECHO)) msg.m_attr = msg.m_attr | MSGECHO;
	if (msg.d_zone==0) msg.d_zone=curaddress.zone;

	if (edit_mess(2)==ESC) {
		messno=tempmess;
		nomess=tempno;
		return (ESC);
	}
	messno=tempmess;
	nomess=tempno;

	strcpy(temp,"MSGTMP.INF");
	unlink(temp);

	if(makeinfo) {
		if((pp=(_open(temp,O_RDWR | O_BINARY | O_DENYWRITE)))==-1)
		  if((pp=(creat(temp,S_IWRITE)))==-1) {
            error_message(" Cannot open info file... ");
            pause();
			return(F10);
        }
		if((currarea->attr & NET) || (currarea->attr & ALTERNATE)) {
            ffprintf(pp,"NET\r\n");
			ffprintf(pp,"ORIG %01u:%01u/%01u.%01u@%s\r\n",
				msg.o_zone,msg.orig_net,msg.orig,msg.o_point,curaddress.domain);
			ffprintf(pp,"DEST %01u:%01u/%01u.%01u@%s\r\n",
				msg.d_zone,msg.dest_net,msg.dest,msg.d_point,to_domain);
        }
		if(!(type & INFOONLY)) {
			ffprintf(pp,"REPLY\r\n");
			ffprintf(pp,"FROM %s\r\n",oldfrom);
			ffprintf(pp,"DATE %s\r\n",olddate);
			ffprintf(pp,"WASTO %s\r\n",oldto);
		}
        if(type & ECHO2NET) ffprintf(pp,"ECHO2NET\r\n");
        else {
			if((currarea->attr & ECHO) || (currarea->attr & ALTECHO)) {
                ffprintf(pp,"ECHO\r\n");
            }
        }
        ffprintf(pp,"TO %s\r\n",msg.to);
        ffprintf(pp,"SUBJ %s\r\n",msg.subj);
        ffprintf(pp,"WRITER %s\r\n",msg.from);
		ffprintf(pp,"AREANAME %s\r\n",currarea->name);
		ffprintf(pp,"AREA# %01u\r\n",currarea->number);
		ffprintf(pp,"AREAATTRIB %u\r\n",currarea->attr);
		ffprintf(pp,"MSGATTRIB %u\r\n",msg.attr);
		ffprintf(pp,"MSGATTRIB2 %u\r\n",msg.m_attr);
		ffprintf(pp,"READER HeadEdit %s",VERSION_NUMBER);
		_close(pp);
    }

	return (F10);
}
