#include "msgg.h"
#include "twindow.h"
#include "headedit.h"

/* Performs all external calls; preserves screen, swaps if ok */

extern void pascal _REINITOVERLAYS (void);  /* Reinit overlay int vector */


void pascal do_spawn (char *dostring) {

     int  drive;
     char dir[MAXDIR];
     char middle[82];
     char *pp;
     char *screenbuf;
     int *p;
     int oldx,oldy,x,y;

     screenbuf=(char *)malloc((maxx * maxy) * 2);
     if(!screenbuf) {
        error_message(" Not enough memory ");
        pause();
        return;
     }
     curr_cursor(&oldx,&oldy);
     p=(int *)screenbuf;
     for(y=0;y<maxy;y++)
        for(x=0;x<maxx;x++)
           *p++=vpeek(VSG,vad(x,y));
     if(!*dostring || !dostring) {
        fputs("\x1b[2J\x1b[0m`EXIT' to return...'\n",stdout);
     }
     drive=getdisk();
     getcurdir(++drive,dir);
     pp=dostring;
     if(!*dostring || !dostring) {
        pp=getenv("COMSPEC");
        if (!pp) pp="COMMAND.COM";
     }
     spawnit(pp);
     setdisk (--drive);
     strcpy(middle,"\\");
     strcat(middle,dir);
     chdir(middle);
     cursor(oldx,oldy);
     p=(int *)screenbuf;
     for(y=0;y<maxy;y++)
        for(x=0;x<maxx;x++)
           vpoke(VSG,vad(x,y),*p++);
     free(screenbuf);
}



char pascal spawnit (char *strr) {

   char *e[26];
   static char a[256];
   char *p;
   char *pp;
   register word x;
   int level=0;
   union REGS r;

   if(!*strr || strr==NULL) return (level=1);
   strcpy(a,strr);
   if (swap) {
        p=strtok(a," ");
        if (!p) return 99;
        if (!strchr(p,':') && !strchr(p,'\\')) p=searchpath(a);
        if (!p) return 99;
        pp=strtok(0,"\n");
        if (!pp) pp="";
        level=doswap(p,pp);
        if (level!=(-1)) goto Getlevel;
   }
   for (x=0;x<26;x++) e[x]=NULL;
   e[0]=strtok(a," ");
   for (x=1;(e[x]=strtok(0," "));x++) if (x==25) break;
   level=(int)spawnvp(P_WAIT,a,e);
Getlevel:
   if (!level) {
       r.h.ah=77;
       int86(33,&r,&r);
       level=(int)r.h.al;
   }
   _REINITOVERLAYS();
   _AX=0;  /* ReInitialize mouse */
   geninterrupt(0x33);
   if(usemouse) {	/* Make sure mouse cursor stays hidden */
	  _AX=2;
	  geninterrupt(0x33);
   }
   return (char)level;
}

