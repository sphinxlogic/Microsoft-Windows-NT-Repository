/* Editor2.C File */

#include "msgg.h"
#include "twindow.h"
#include "headedit.h"
#include "keys.h"

extern void pascal dcls(void);
extern void pascal dputc(int x, int y, int c);
extern int  pascal dputs(int x, int y, char *s);
extern void pascal dclrwnd(int x1, int y1, int x2, int y2);
extern void pascal dscrollup(int x1, int y1, int x2, int y2);
extern void pascal dscrolldn(int x1, int y1, int x2, int y2);

extern word vbase;
extern word maxx;
extern word maxy;
extern char current_color;
extern word videomethod;

extern char keybuf[256];
extern int VSG;
extern int last_x,last_y;
extern char abortedit;

char * pascal get_string (char *text,char len,char *deflt,char type);
char pascal ask_question (char *text);
int pascal do_macro (int c);



char * pascal get_string (char *text,char len,char *deflt,char type) {

  int c;
  WINDOW *sur;
  FIELD *fld;
  static char s[80];
  char *msk;

  if(len>76) len=76;
  if(strlen(text)>(76))text[76]=0;
  if(!deflt) *s=0;
  else {
	strncpy(s,deflt,len);
	s[len-1]=0;
  }
  if(!type) type='a';
  c=max(strlen(text),len);
  sur=establish_window((80-(c+4))/2,11,4,max(18,c+4));
  set_colors(sur,ALL,RED,YELLOW,BRIGHT);
  set_title(sur," Answer or Die ");
  display_window(sur);
  wprintf(sur," %s",text);
  init_template(sur);
  msk=msk78+(78-len);
  fld=establish_field(sur,1,1,msk,s,type);
  field_window(fld,"",40,6);
  prep_template(sur);
  c=data_entry(sur);
  delete_window(sur);
  if(c!=F10) *s=0;
  rstrip(s);
  return s;
}


/* Ask a question, return Y,N,ESC or \r */

char pascal ask_question (char *text) {

  int c=0,width;
  WINDOW *sur;

  width=max(26,strlen(text)+4);
  width=min(width,80);
  sur=establish_window(28,11,4,width);
  set_help("yesnohelp ",0,0);
  set_colors(sur,ALL,RED,YELLOW,BRIGHT);
  set_title(sur," Yes or No ");
  display_window(sur);
  wprintf(sur,"%s",text);
  while (c!='Y' && c!='N' && c!=ESC && c!='\r') {
	c=get_char();
	c=toupper(c);
  }
  delete_window(sur);
  set_help("edithelp  ",0,0);
  return (char)c;
}


int pascal do_macro (int c) {

	int fp;
	char *p;
	char str[256];

	p=searchpath("HEADMACR.DEF");
	if(!p)p="HEADMACR.DEF";
	fp=_open(p,O_RDONLY | O_DENYNONE | O_BINARY);
	if(fp==-1) {
		error_message(" Unable to open HEADMACR.DEF ");
		pause();
		return -1;
	}
	while(!eof(fp)) {
		if(!fgetsx(str,256,fp)) break;
		str[255]=0;
		if(atoi(str)==c) {
			stripcr(str);
			lstrip(str);
			p=str;
			while(p=strchr(p,'|'))*p='\r';
			p=strchr(str,' ');
			if(p)p++;
			else p=str;
			strncpy(keybuf,convertstring(p),256);
			keybuf[255]=0;
			_close(fp);
			return 1;
		}
	}
	_close(fp);
	return 0;
}
