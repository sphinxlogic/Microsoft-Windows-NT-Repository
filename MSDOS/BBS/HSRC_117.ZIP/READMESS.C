#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"

word threadstart;
extern WINDOW *ewnd;


/* Buffer call before the main display() function */

void pascal read_mess (char type,char global) {

	int what;
	char s[81];
	word lastmess;
	word tempmess;
	word temparea;
	word messmarker[10]={
		0,0,0,0,0,0,0,0,0,0
	};
	word wasdeleted;

  threadstart=0;
  if(!nomess) return;
  if (type) {
	lastmess=messno;
	goto Over;
  }

AllOver:
  if (areano<(totalareas+1)) lastmess=lastread[areano-1];
  if (lastmess<nomess && lastmess>0) {
	tempmess=messno;
	messno=lastmess+1;
	if (tempmess!=messno) get_mess(0);
  }
  if(!messno) messno=1;
  if (messno>nomess) messno=nomess;
  get_mess(0);

Over:

	set_help ("readkeys  ",0,23);
	clear_message();
	current_color=readtextcolor + (readtextback*16);
	dclrwnd(1,6,maxx,maxy);
	current_color=readstatcolor + (readstatback*16);
	if(!usemouse) {
		if (lastmess<nomess) dprintf(2,maxy," F1=help /=menu -- New @ #%05u -- %05u messages -- Area #%04u           ",lastmess+1,nomess,areano);
		else                 dprintf(2,maxy," F1=help /=menu -- No New msgs -- %05u messages -- Area #%04u            ",nomess,areano);
	}
	else dprintf(3,maxy," ?  %c      �   � � � � � � Click at top of screen for menu         ",26);

PartOver:

	current_color=readtextcolor + (readtextback*16);
	dclrwnd(1,6,maxx,maxy-1);
	show_header(0);
	goto JustTheFacts;

Again:

	show_header(0);

JustTheFacts:

    highvideo();
    current_color=readtextcolor+(readtextback*16);
	printf("\r%s",make_ansi(readtextcolor,readtextback));
	if (!(msg.attr & MSGREAD)) if (isitme(0)) update_read();
	clear_message();
	what=display(&lastmess,type);
	switch (what) {
		case ALT_B:		*lastreply=0;
						goto DoBackward;
		case ALT_F:     *lastmsgid=0;
		case CTRL_F:    if(!thread('F',lastmsgid)) if (threadstart==messno) threadstart=0;
						get_mess(0);
						goto Over;
DoBackward:
		case CTRL_B:    if(!thread('B',lastreply)) if (threadstart==messno) threadstart=0;
						get_mess(0);
						goto Over;
        case ALT_Q:     if(threadstart) messno=threadstart;
						threadstart=0;
						get_mess(0);
						goto Over;
	}
	threadstart=0;
	switch(what) {
		case CTRL_PGDN:
		case RIGHT:
						wasdeleted=0;
DownLoop:
						messno++;
						if (messno>nomess) {
							messno=1;
							any_message(" Rollover ");
							if (global) goto QuitNow;
						}
						get_mess(0);
						if(skipdeleted) {
							if((msg.m_attr & MSGDELETED) && !wasdeleted) {
								wasdeleted=messno;
								goto DownLoop;
							}
							if(wasdeleted==messno) {
								any_message(" No undeleted messages this area--View deleted? (y/N) ");
								if(toupper(generic_mouse_input(ewnd))=='Y') {
									skipdeleted=0;
								}
								else goto QuitNow;
							}
						}
						if (type) if (!isitme(0)) goto DownLoop;
						wasdeleted=0;
						goto PartOver;
        case CTRL_PGUP:
		case LEFT:
						wasdeleted=0;
UpLoop:
						if (messno==1) {
							messno=nomess;
							any_message(" Rollback ");
						}
						else messno--;
						get_mess(0);
						if(skipdeleted) {
							if((msg.m_attr & MSGDELETED) && !wasdeleted) {
								wasdeleted=messno;
								goto UpLoop;
							}
							if(wasdeleted==messno) {
								any_message(" No undeleted messages this area--View deleted? (y/N) ");
								if(toupper(generic_mouse_input(ewnd))=='Y') {
									skipdeleted=0;
								}
								else goto QuitNow;
							}
						}
						if (type) if (!isitme(0)) goto UpLoop;
						wasdeleted=0;
						goto PartOver;
QuitNow:
		case 81:
		case ESC:       if (!type) if (areano<(totalareas+1)) lastread[areano-1]=lastmess;
						break;
		case F10:       move_mess();
						get_mess(0);
						goto Over;
		case F9:		messno=select_mess();
						get_mess(0);
						goto Over;
		case '<':
						if (!type) if (areano<(totalareas+1)) lastread[areano-1]=lastmess;
AreaSub:
						areano--;
						if (!areano) areano=4095;
						nomess=check_area(areano);
						if (!nomess) {
							clear_message();
							if (kbhit()) if (get_char()==' ') return;
							goto AreaSub;
						}
						find_area();
						get_mess(0);
						goto AllOver;
		case '>':
						if (!type) if (areano<(totalareas+1)) lastread[areano-1]=lastmess;
AreaAdd:
						areano++;
						if (areano>4095) areano=1;
						nomess=check_area(areano);
						if (!nomess) {
							clear_message();
							if (kbhit()) if (get_char()==' ') return;
							goto AreaAdd;
						}
						find_area();
						get_mess(0);
						goto AllOver;
        case F8:        if (!type) if (areano<(totalareas+1)) lastread[areano-1]=lastmess;
                        areano=select_area();
						get_mess(0);
						goto AllOver;
		case F7:        edit_mess(0);
						goto Over;
		case CTRL_E:    make_file();
						goto Over;
		case F6:        messno=search(0,0);
						get_mess(0);
						goto Over;
		case 'R':
		case F5:    	tempmess=messno;
						strcpy(s,"MSGTMP");
                        get_rid();
                        if(!export(s,((currarea->attr & ALTERNATE) ||
						  (currarea->attr & NET)),QUOTE,msg.date,msg.to,NULL)) {
							messno=tempmess;
							get_mess(0);
							goto Over;
						}
						if (set_header(1,msg.date,msg.from,msg.to)==ESC) {
							get_rid();
							messno=tempmess;
							get_mess(0);
							goto Over;
						}
						show_header(0);
						post_mess("");
						messno=tempmess;
						get_mess(0);
						goto Over;
		case 'W':
		case F4:        *assocfile=0;
						tempmess=messno;
						if (set_header(INFOONLY,"","","")==ESC) {
							get_rid();
							messno=tempmess;
							get_mess(0);
							goto Over;
						}
						show_header(0);
						post_mess("");
						messno=tempmess;
						get_mess(0);
						goto Over;
		case F3:        tempmess=messno;
						edit_text();
						messno=tempmess;
						get_mess(0);
						goto Over;
		case F2:        tempmess=messno;
						scan_mess();
						messno=tempmess;
						get_mess(0);
						goto Again;
        case ALT_A:     if (!type) if (areano<(totalareas+1)) lastread[areano-1]=lastmess;
						tempmess=areano;
						areano=list_areas();
						if(!areano)areano=tempmess;
						find_area();
						nomess=check_area(areano);
                        get_mess(0);
                        goto AllOver;
        case ALT_L:     tempmess=messno;
						messno=list_mess();
						if(!messno) messno=tempmess;
						get_mess(0);
						goto Over;
		case CTRL_K:	killjunk();
						nomess=check_area(areano);
						if(!nomess) return;
						if(messno>nomess) messno=nomess;
						get_mess(0);
						goto Over;
		case CTRL_L:    messno=search(1,0);
						get_mess(0);
						goto Over;
		case CTRL_F6:   messno=search(1,1);
						get_mess(0);
						goto Over;
        case CTRL_END:
		case CTRL_HOME:
						get_mess(0);
						goto PartOver;
		case ALT_1:
		case ALT_2:
		case ALT_3:
		case ALT_4:
		case ALT_5:
		case ALT_6:
		case ALT_7:
		case ALT_8: what-=247;
					goto SetMarkerHere;
		case ALT_9: what=9;
					goto SetMarkerHere;
		case ALT_0: what=0;
SetMarkerHere:
					messmarker[what]=messno;
					goto JustTheFacts;
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
		case '0':   if (!messmarker[what-'0']) goto JustTheFacts;
					messno=messmarker[what-'0'];
					get_mess(0);
					goto PartOver;
		case CTRL_F1:	readtextcolor++;
						if(readtextcolor>15) readtextcolor=0;
						goto Over;
		case CTRL_F2:	readtextback++;
						if(readtextback>7) readtextback=0;
						goto Over;
		case CTRL_F3:   readheadcolor++;
						if(readheadcolor>15) readheadcolor=0;
						goto Over;
		case CTRL_F4:   readheadback++;
						if(readheadback>7) readheadback=0;
						goto Over;
		case CTRL_F5:   readstatcolor++;
						if(readstatcolor>15) readstatcolor=0;
						goto Over;
		case CTRL_F7:   readstatback++;
						if(readstatback>7) readstatback=0;
						goto Over;
		case CTRL_R:    *assocfile=0;
						if(!(currarea->attr & ALTECHO) && !(currarea->attr & ECHO)) {
							any_message(" Not an echo message ");
							pause();
							goto Over;
						}
						if (!altboard) altboard=netboard;
						if(!netboard) {
							any_message(" Don't know what # your net board is ");
							pause();
							goto Over;
						}
						strcpy(s,"MSGTMP");
                        get_rid();
						if(export(s,((currarea->attr & ALTERNATE) ||
						  (currarea->attr & NET)),ECHO2NET,msg.date,msg.to,NULL)) {
							tempmess=messno;
							temparea=areano;
							if(currarea->attr & ALTECHO) areano=altboard;
							else areano=netboard;
							find_area();
							nomess=check_area(areano);
							if (set_header(ECHO2NET,msg.date,msg.from,msg.to)==ESC) {
								messno=tempmess;
								get_rid();
								areano=temparea;
								find_area();
								nomess=check_area(areano);
								get_mess(0);
								goto Over;
							}
							show_header(0);
							post_mess("");
							messno=tempmess;
							areano=temparea;
							find_area();
							nomess=check_area(areano);
						}
						get_mess(0);
						goto Over;
    }
	return;
}

