#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"
#include "headid.h"




void pascal move_mess (void) {

	char message[6];
	char toarea[5];
	static char forward[2]="-";
	static char carbon[2]="-";
	static char carbon_to[36]="";
	static char deleteorig[2]="Y";
	char s[115];
	char s1[303];
	char temporary[30];
	char temporary2[30];
	char temporary3[40];
	char origintext[80]="";
	char far *hold;
	char far *tempo;
	word messlen;
	word temp;
	int returncode;
	word tempmess;
	word temparea;
    struct ffblk f;
	WINDOW *wnd;
	FIELD *fld;

					wnd=establish_window(4,maxy-7,11,62);
					set_border(wnd,3);
					set_title(wnd," Move/Forward/CC Message ");
					set_colors(wnd,BORDER,7,0,0);
					display_window(wnd);
					wcursor(wnd,0,0);
					wprintf(wnd," F10 to move or ESC to abort");
					sprintf(message,"%u",messno);
					if ((areano+1)<4096) sprintf(toarea,"%u",areano+1);
					else strcpy(toarea,"1");
					sprintf(s,"Message #(1-%u):",nomess);
					wprompt(wnd,1,2,s);
					wprompt(wnd,1,3,"To Area #:");
					wprompt(wnd,1,4,"Forward: [ ]");
					wprompt(wnd,1,5,"Carbon:  [ ]");
					wprompt(wnd,1,6,"Delete Original:");
					wprompt(wnd,1,7,"If carbon, to whom?");
					fld=establish_field(wnd,19,2,msk5,message,'N');
					field_window(fld,"movemess  ",40,6);
					fld=establish_field(wnd,19,3,msk5,toarea,'N');
					field_window(fld,"movearea  ",40,5);
					fld=establish_field(wnd,11,4,msk1,forward,'O');
					field_window(fld,"forward   ",40,4);
					fld=establish_field(wnd,11,5,msk1,carbon,'O');
					field_window(fld,"carbon    ",40,4);
					fld=establish_field(wnd,19,6,msk1,deleteorig,'A');
					field_window(fld,"deleteorig",40,3);
					field_validate(fld,yesorno);
					fld=establish_field(wnd,24,7,msk35,carbon_to,'a');
					field_window(fld,"carbonto  ",40,3);
					prep_template(wnd);
Over:
					returncode=data_entry(wnd);
					if (returncode==ESC) {
						delete_window(wnd);
						return;
					}
					if (returncode!=F10) goto Over;
					rstrip(carbon_to);
					if(*carbon=='X' && !*carbon_to) {
						error_message(" Don't know who carbon's for! ");
						pause();
						goto Over;
					}
					temp=(word)atol(message);
					if (temp<1 || temp>nomess) {
						error_message(" Invalid message # ");
						pause();
						goto Over;
					}
					temp=(word)atol(toarea);
					if (temp<1 || temp>4095) {
						error_message(" Invalid area # ");
						pause();
						goto Over;
					}
					delete_window(wnd);
					tempmess=messno;
					temparea=areano;
					messno=(word)atol(message);
					get_mess(0);
					hold=get_text();
					if (hold==NULL || &hold==NULL) return;
					if (*deleteorig!='N') {
						msg.m_attr=msg.m_attr | MSGDELETED;
						put_mess();
						msg.m_attr = msg.m_attr & (~MSGDELETED);
					}
					msg.attr = msg.attr | MSGLOCAL;
                    msg.m_attr = msg.m_attr & (~MSGPACKED);
                    sprintf(temporary3,"%u: %1.12s",currarea->number,currarea->name);
					areano=(word)atol(toarea);
					nomess=check_area(areano);
					find_area();
					clear_message();
					if (tempo=strstr(hold,"\r * Origin: ")) *tempo=0;
					if(!tempo)if (tempo=strstr(hold,"\r\n * Origin: ")) *tempo=0;
					if (*forward=='X' || *carbon=='X') {
/*						while (*hold=='\01') memmove(hold,strchr(&hold[1],'\r')+1,strlen(strchr(&hold[1],'\r'))+1);
						tempo=hold;
						while ((tempo=strstr(tempo,"\r\01"))) memmove(tempo,strchr(&tempo[1],'\r'),strlen(strchr(&tempo[1],'\r'))+1);
						if (!strlen(hold)) {
							any_message(" Stripping kludge lines leaves an empty message! ");
							pause();
							if (hold) farfree(hold);
							goto EndIt;
						}
*/

						if ((msg.m_attr & NET) || (msg.m_attr & ALTERNATE)) {
							sprintf(temporary2,"(%u:%u/%u.%01u) ",msg.d_zone,msg.dest_net,msg.dest,msg.d_point);
							sprintf(temporary,"(%u:%u/%u.%01u) ",msg.o_zone,msg.orig_net,msg.orig,msg.o_point);
						}
						else {
							*temporary=0;
							*temporary2=0;
						}
						msg.m_attr = msg.m_attr & (~MSGSCANNED);
						msg.m_attr = msg.m_attr & (~MSGNET);
						msg.m_attr = msg.m_attr & (~MSGECHO);
						msg.o_zone=curaddress.zone;
						msg.orig_net=curaddress.net;
						msg.orig=curaddress.node;
						if ((currarea->attr & NET) || (currarea->attr & ALTERNATE)) {
							msg.attr=(defaultattr | MSGLOCAL) & (~MSGSENT);
							msg.m_attr = msg.m_attr | MSGNET;
						}
						if ((currarea->attr & ECHO) || (currarea->attr & ALTECHO)) {
							msg.m_attr = msg.m_attr | MSGECHO;
							if(curaddress.point)sprintf(origintext,"%s%s%s (%u:%u/%01u.%01u)\r",HEADID,ORIGTXT,origin,curaddress.zone,curaddress.net,curaddress.node,curaddress.point);
							else sprintf(origintext,"%s%s%s (%u:%u/%01u)\r",HEADID,ORIGTXT,origin,curaddress.zone,curaddress.net,curaddress.node);
						}
						if ((currarea->attr & PUBLIC) && (!(currarea->attr & PRIVATE))) {
							msg.attr = msg.attr & (~MSGPRIVATE);
						}
						if ((!(currarea->attr & PUBLIC)) && (currarea->attr & PRIVATE)) {
							msg.attr = msg.attr | MSGPRIVATE;
						}
						if(*forward=='X') {
							sprintf(s,"\r ** Forwarded on %s from Area #%s **",fidodate(),temporary3);
							sprintf(s1,"\r ** by %s via XBBS (%u:%u/%u.%01u@%s) **\r ** Orig. to: %s %s**\r ** Orig. fm: %s ",name,curaddress.zone,curaddress.net,curaddress.node,curaddress.point,curaddress.domain,msg.to,temporary2,msg.from);
							strcat(s1,temporary);
							strcat(s1," **\r\r");
						}
						else {
							sprintf(s," ** Original to %s (%s)\r",msg.to,temporary);
							sprintf(s1," ** CC: %s\r",carbon_to);
						}
					}
					else {
						*s=0;
						*s1=0;
					}
					messlen=put_text(hold,s,s1,&f,origintext);
					if (hold) farfree(hold);
					if (!messlen) goto EndIt;
					messno=++nomess;
					msg.length=messlen;
					msg.start=f.ff_fsize;
					if (*forward=='X') {
						if (currarea->attr & ECHO) msg.m_attr = msg.m_attr | MSGECHO;
						msg.m_attr = msg.m_attr & (~MSGSCANNED);
					}
					edit_mess(2);
					put_mess();
EndIt:
					areano=temparea;
					nomess=check_area(areano);
					find_area();
					messno=tempmess;
					get_mess(0);
					clear_message();
}

