/* Prints a group of messages */

#include "msgg.h"
#include "twindow.h"
#include "keys.h"
#include "headedit.h"


void pascal printer (void) {

	word x;
    word pglen=0;
    char pl[4];
	char tm[4];
	char bm[4];
	char lm[4];
	char tw[4];
	char reset[2]="-";
	char dosearch[2]="-";
	char headers_only[2]="-";
    char frommess[6];
	char tomess[6];
	char temp[6];
	static char divert[79]="PRN";
	int  returncode;
	char *p;
	int  pp;
	WINDOW *wnd;
	FIELD *fld;

					if(!nomess) return;
					if(!messno)messno=1;
					wnd=establish_window(1,maxy-7,20,80);
					set_border(wnd,3);
					set_title(wnd," Print Messages ");
					set_colors(wnd,BORDER,7,0,0);
					display_window(wnd);
					wcursor(wnd,0,0);
					wprintf(wnd," F10 to print or ESC to abort");
					sprintf(frommess,"%u",messno);
					sprintf(tomess,"%u",nomess);
					sprintf(pl,"%hu",pagelength);
					sprintf(tm,"%hu",topmargin);
					sprintf(bm,"%hu",bottommargin);
					sprintf(lm,"%hu",leftmargin);
					sprintf(tw,"%hu",textwidth);
					while (p=strchr(beforeheader,'\x1b')) *p='~';
					while (p=strchr(afterheader,'\x1b')) *p='~';
					while (p=strchr(aftertext,'\x1b')) *p='~';
					while (p=strchr(afterprinting,'\x1b')) *p='~';
					while (p=strchr(beforeheader,'\n')) *p='`';
					while (p=strchr(afterheader,'\n')) *p='`';
					while (p=strchr(aftertext,'\n')) *p='`';
					while (p=strchr(afterprinting,'\n')) *p='`';
					wprompt(wnd,1,2,"From msg #:");
					wprompt(wnd,1,3,"To msg #:");
					wprompt(wnd,1,4,"Reset:         [ ]");
					wprompt(wnd,1,5,"Page Length:");
					wprompt(wnd,1,6,"Top Margin:");
					wprompt(wnd,1,7,"Bottom Margin:");
					wprompt(wnd,1,8,"Left Margin:");
					wprompt(wnd,1,9,"Text Width:");
					wprompt(wnd,1,10,"Before Header:");
					wprompt(wnd,1,11,"After Header:");
					wprompt(wnd,1,12,"After Text:");
					wprompt(wnd,1,13,"After Printing:");
					wprompt(wnd,1,14,"Print to:");
					wprompt(wnd,1,16,"Search? [ ]");
                    wprompt(wnd,17,16,"Headers Only? [ ]");
					fld=establish_field(wnd,17,2,msk5,frommess,'N');
					field_window(fld,"fromprint ",40,6);
					field_validate(fld,messlimit);
					fld=establish_field(wnd,17,3,msk5,tomess,'N');
					field_window(fld,"toprint   ",40,5);
					field_validate(fld,messlimit);
					fld=establish_field(wnd,17,4,msk1,reset,'O');
					field_window(fld,"reset     ",40,7);
					fld=establish_field(wnd,17,5,msk3,pl,'N');
					field_window(fld,"pagelength",40,4);
					field_validate(fld,charlimit);
					fld=establish_field(wnd,17,6,msk3,tm,'N');
					field_window(fld,"topmargin ",40,3);
					field_validate(fld,charlimit);
					fld=establish_field(wnd,17,7,msk3,bm,'N');
					field_window(fld,"bottommarg",40,2);
					field_validate(fld,charlimit);
					fld=establish_field(wnd,17,8,msk3,lm,'N');
					field_window(fld,"leftmargin",40,1);
					field_validate(fld,charlimit);
					fld=establish_field(wnd,17,9,msk3,tw,'N');
					field_window(fld,"textwidth ",40,2);
					field_validate(fld,charlimit);
					fld=establish_field(wnd,17,10,msk11,beforeheader,'a');
					field_window(fld,"beforehead",40,3);
					fld=establish_field(wnd,17,11,msk11,afterheader,'a');
					field_window(fld,"afterheade",40,4);
					fld=establish_field(wnd,17,12,msk47,aftertext,'a');
					field_window(fld,"aftertext ",40,5);
					fld=establish_field(wnd,17,13,msk11,afterprinting,'a');
					field_window(fld,"afterprint",40,6);
					fld=establish_field(wnd,0,15,msk78,divert,'A');
					field_window(fld,"divert    ",40,7);
					field_validate(fld,noblank);
					fld=establish_field(wnd,10,16,msk1,dosearch,'O');
					field_window(fld,"searchprnt",40,5);
					fld=establish_field(wnd,32,16,msk1,headers_only,'O');
                    field_window(fld,"headonly  ",40,5);
                    prep_template(wnd);
Over:
					returncode=data_entry(wnd);
					rstrip(beforeheader);
					rstrip(afterheader);
					rstrip(aftertext);
					rstrip(afterprinting);
					rstrip(divert);
					while (p=strchr(beforeheader,'~')) *p='\x1b';
					while (p=strchr(afterheader,'~')) *p='\x1b';
					while (p=strchr(aftertext,'~')) *p='\x1b';
					while (p=strchr(afterprinting,'~')) *p='\x1b';
					while (p=strchr(beforeheader,'`')) *p='\n';
					while (p=strchr(afterheader,'`')) *p='\n';
					while (p=strchr(aftertext,'`')) *p='\n';
					while (p=strchr(afterprinting,'`')) *p='\n';
					if (returncode==ESC) {
						delete_window(wnd);
						return;
					}
					if (returncode!=F10) goto Over;
					delete_window(wnd);
					topmargin=(char)atoi(tm);
					pagelength=(char)atoi(pl);
					bottommargin=(char)atoi(bm);
					leftmargin=(char)atoi(lm);
					textwidth=(char)atoi(tw);
					if (atol(frommess)>atol(tomess)) {
						strcpy(temp,frommess);
						strcpy(frommess,tomess);
						strcpy(tomess,temp);
					}

	if (!stricmp(divert,"PRN")) {
		_AH=2;
		_DX=0;
		geninterrupt(0x17);
		if (_AH!=144) {
			error_message(" Printer not ready ");
			pause();
			return;
		}
	}
	if (*reset!='X') *reset=0;

	wnd=establish_window(1,maxy-7,19,maxx);
	set_border(wnd,3);
	set_title(wnd," Printing -- ESCape to abort ");
	set_colors(wnd,BORDER,7,0,0);
	display_window(wnd);
	wcursor(wnd,0,0);
	x=messno;
	if(*dosearch=='X') {
		messno=(word)atol(frommess);
		messno=search(0,0);
		if(messno<=(word)atol(frommess) || messno>(word)atol(tomess) || messno>(nomess)) goto ForgetIt;
	}

    if(*headers_only=='X') {
        pp=_open(divert,O_WRONLY | O_BINARY | O_DENYWRITE);
        if(pp == -1) pp=creat(divert,S_IWRITE);
        if(pp != -1) {
			lseek(pp,0L,SEEK_END);
			for (x=0;x<strlen(beforeheader);x++) {
                if (beforeheader[x]=='\n') {
                    pglen++;
                    ffprintf(pp,"\r\n");
                }
                else {
                    ffprintf(pp,"%c",beforeheader[x]);
                }
                if(beforeheader[x]=='\xc') pglen=0;
            }
            _close(pp);
        }
    }

    for (messno=(word)atol(frommess);messno<((word)atol(tomess)+1) && messno<(nomess+1);messno++) {
		if(*dosearch=='X') {

			word temp;

			temp=messno;
			messno=search(1,0);
			if(temp==messno || messno<(word)atol(frommess) || messno>(word)atol(tomess) || messno>(nomess)) continue;
		}
		get_mess(0);
		print_clock();
		if(msg.m_attr & DELETED) continue;
        if(*headers_only!='X') {
            export (divert,(currarea->attr & NET)||(currarea->attr & ALTERNATE),PRINTIT,reset,"",wnd);
        }
        else {
            if((pp=_open(divert,O_WRONLY | O_BINARY | O_DENYWRITE))!=-1) {
                    if((pglen+4)>(pagelength-bottommargin)) {
                       ffprintf(pp,"\xc\r\n");
                       pglen=1;
                    }
                    if (pglen<topmargin) {
                       for (x=pglen;x<topmargin;x++) {
                           ffprintf(pp,"\r\n");
                       }
                       pglen=topmargin;
                    }
                    lseek(pp,0L,SEEK_END);
					ffprintf(pp,"\r\nFm: %-32.32s  To: %-32.32s\r\n",msg.from,msg.to);
					ffprintf(pp,"Date: %-20.20s   Length: %5u   Addr: %u:%u/%u.%u\r\n",msg.date,msg.length,msg.o_zone,msg.orig_net,msg.orig,msg.o_point);
                    ffprintf(pp,"Subj: %s\r\n",msg.subj);
                    pglen+=4;
                }
                _close(pp);
        }

        if (kbhit()) {
			returncode=get_char();
			if (returncode==' ' || returncode==ESC) break;
		}

	}
	if (areano<(totalareas+1)) if(lastread[areano-1]<messno) lastread[areano-1]=messno;
	if((pp=_open(divert,O_RDWR | O_BINARY | O_DENYWRITE))!=-1) {
        lseek(pp,0L,SEEK_END);
        for(x=0;x<strlen(afterprinting);x++) {
			if(afterprinting[x]=='\n') ffprintf(pp,"\r\n");
			else ffprintf(pp,"%c",afterprinting[x]);
		}
		_close(pp);
	}
ForgetIt:
	messno=x;
	get_mess(0);
	any_message(" Complete ");
	pause();
	delete_window(wnd);
	return;
}


