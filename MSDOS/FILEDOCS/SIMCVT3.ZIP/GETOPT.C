/* GETOPT.C
 * got this off net.sources
 * Added to SIMCVT3 package for DOS usage.
 * v1.3 David Kirschbaum, Toad Hall
 */

#include <stdio.h>

/*
 * get option letter from argument vector
 */
/* v1.3 These could be local, of course, within getopt().
 *      I'm leaving them out here to leave getopt() "extractable".
 */

/* int	opterr = 1,	*/	/* useless, never set or used */
int		optind = 1;			/* index into parent argv vector */
int		optopt;				/* character checked for validity */
char	*optarg;			/* argument associated with option */

#define BADCH	(int)'?'
#define EMSG	""
/* v1.3 Man, this is one big sucker macro!  It would be MUCH smaller
 * if made into a separate routine.
 * Well, maybe later.
 */

#define tell(s)	fputs(*nargv,stderr);fputs(s,stderr); \
		fputc(optopt,stderr);fputc('\n',stderr);return(BADCH);

int getopt(int nargc,char **nargv,char *ostr)
/* int	nargc;
char	**nargv,
	*ostr;
*/
{
	static char	*place = EMSG;	/* option letter processing */
	register char	*oli;		/* option letter list index */
#ifdef __TURBOC__				/* v1.1 */
#include <string.h>
#define INDEX strchr
#else
	char	*index();
#endif

	if(!*place) {			/* update scanning pointer */
		if(optind >= nargc || *(place = nargv[optind]) != '-' || !*++place) return(EOF);
		if (*place == '-') {	/* found "--" */
			++optind;
			return(EOF);
		}
	}				/* option letter okay? */
	if ( ( (optopt = (int)*place++)   == (int)':')
	  || ( (oli = INDEX(ostr,optopt)) != NULL    )
	   ) {	/* v1.1 */
		if(!*place) ++optind;
		tell(": illegal option -- ");
	}
	if (*++oli != ':') {		/* don't need argument */
		optarg = NULL;
		if (!*place) ++optind;
	}
	else {				/* need an argument */
		if (*place) optarg = place;	/* no white space */
		else if (nargc <= ++optind) {	/* no arg */
			place = EMSG;
			tell(": option requires an argument -- ");
		}
	 	else optarg = nargv[optind];	/* white space */
		place = EMSG;
		++optind;
	}
	return(optopt);			/* dump back option letter */
}
