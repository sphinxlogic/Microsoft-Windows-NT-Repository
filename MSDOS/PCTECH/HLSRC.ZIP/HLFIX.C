/*+
    Name:	hlfix.c
    Date:	25-Jun-1988
    Author:	Kent J. Quirk
		(c) Copyright 1988 Ziff Communications Co.
    Abstract:	Fixes the graphics numbers from old versions of hlbench.
    History:	09-Sep-88   kjq     Version 1.00
-*/    

#include <stdio.h>
#include "hltimes.h"

main(int argc, char *argv[])
{
    int i, j, k;
    TIME_REC trec, *trecp;
	
    for (k=1; k<argc; k++)
    {
	if (opentime(argv[k]) == 0)
	{
	    printf("%s: couldn't open\n", argv[k]);
	}   
	else
	{
	    for (i=1; i<7; i++)
	    {
		trecp = readtime(i, 0);
		if (trecp->desc[7] == 'G')	/* if it's 'Graphics' */
		{
		    trec = *trecp;
		    trec.ticks = 0;
		    for (j=1; j<8; j++)
		    {	 
			trecp = readtime(i, j);
			if (trecp->ticks > 0)
			    trec.ticks += trecp->ticks;
		    }
		    savetime(i, 0, &trec);
		    break;
		}
	    }
	    printf("%s: Changed to %ld ticks\n", argv[k], trec.ticks);
	}					/* else... */ 
    }						/* for k... */ 
    return(0);
}
