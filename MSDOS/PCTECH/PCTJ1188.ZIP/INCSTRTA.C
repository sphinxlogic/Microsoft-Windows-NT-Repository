#include        <conio.h> 
 
 
unsigned char SetCRTCReg( int, unsigned char ); 
 
main() 
{ 
        int     i; 
 
 
        /* increment the Start Address value (CRTC registers 0CH and 0DH) */ 
        /*  by 80 in each loop iteration */ 
 
        for( i=0; i<=15; i++ ) 
        { 
          SetCRTCReg( 0x0C, (80*i)>>8 );        /* high-order byte */ 
          SetCRTCReg( 0x0D, (80*i)&0xFF );      /* low-order byte */ 
 
          while( !kbhit() );                    /* wait for a keypress */ 
          getch(); 
        } 
 
        /* restore the screen origin to zero */ 
        SetCRTCReg( 0x0C, 0 ); 
        SetCRTCReg( 0x0D, 0 ); 
} 
 
