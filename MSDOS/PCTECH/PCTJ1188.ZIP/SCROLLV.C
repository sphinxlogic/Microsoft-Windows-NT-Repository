void ScreenOrigin( int, int ); 
 
 
main() 
{ 
        int     y; 
 
        for( y=0; y<100; y++ )          /* scroll down */ 
          ScreenOrigin( 0, y ); 
 
        for( y=100; y>=0; --y )         /* scroll up */ 
          ScreenOrigin( 0, y ); 
} 
