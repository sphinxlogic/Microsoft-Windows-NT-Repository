/*
	Example2.C version 1.0
	by Robert Schmidt of Ztiff Zox Softwear 1993

	Example of making use of a TWEAK file by linking its contents in
	with the program.  This program doesn't need any external files at
	run time.
*/

#include <conio.h>
#include "TwkUser.h"

/*	The following included file defines the Mode320x240 table of Registers.
	The file should be created by running
	TWEAK2C 320x240.256 320x240.c Mode320x240 */

#include "320x240.c"

main()
	{
	/* Note that no initialization is neccessary now.  The Register array
	   is linked in as global data, and is directly accessible.  Take
	   note of the way the number of Register elements in the array is
	   calculated: */

	outRegArray(Mode320x240, sizeof(Mode320x240)/sizeof(Register));

	getch();
	textmode(C80);

	/* Also note that since the array is static, global data, there is
	   no pointer to free(), as was done in Example1.C */

	return 0;
	}
