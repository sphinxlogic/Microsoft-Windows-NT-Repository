/*****************************************************************************/
/*
                                PerlRTE.c

Perl Run-Time Environment.

This scripting environment provides a persistent Perl engine using techniques
described in the 'perlembed' document.  It operates in the CGIplus environment
and relies on a Run-Time Environment mechanism available in WASD HTTPd v7.1.
Two modes are available (mainly due to experimentation, the first is probably
the mode of choice).


PERSISTENT
----------
This approach uses methods and code described in the 'perlembed' document
"Maintaining a persistent interpreter" section, to load and keep cached
multiple script and module sources.  Measurements using the Apache Bench
(AB.EXE) tool indicate for the example Perl script loading the CGI.PM module,
an improvement in the order of a factor of twenty-five!!  I am unsure of
exactly how isolated each script loaded really is.  Each is treated as an
autonomous package and so storage restrictions etc. need to be observed. 
However apart from that it would seem as if any old (perhaps slightly tweaked)
CGI script could be used within this environment.


NON-PERSISTENT
--------------
Each script gets a brand-new, completely fresh interpreter and so execute
completely autonomously.  The saving is in script response latency and system
impact, both due to the need for loading the Perl shareable image and Perl
interpreter only once (a not inconsiderable saving with VMS).  Measurements
using the Apache Bench (AB.EXE) tool indicate for the example Perl scripts an
improvement in the order of a factor of five for simple scripts.


SERVER MAPPING
--------------
This Run-Time Environment can be activated in two ways.

1) HTTPD$MAP

  exec /plrte/* (cgi-bin:[000000]perlrte.exe)/whatever/location/*

2) HTTPD$CONFIG

  [DclScriptRunTime]
  .PL (cgi-bin:[000000]perlrte.exe)
  .CGI (cgi-bin:[000000]perlrte.exe)


CAUTIONS
--------
1) A fair bit of this is "monkey see, monkey do" ... the author, by no means,
being even Perl competant ... let alone a Perl internals expert!  Hence, this
code may be full of bugs, or at the very least, inelegant methods when
interfacing with Perl.  All suggestions gratefully received.

2) It has been acknowleged by the VMS Perl developers that Perl itself leaks
memory with each interpreter construct/destruct (at least up to v5.6).  The
author has confirmed this, at about 40kB per instance (v5.6 compiled using DECC
6.2 on VMS v7.2-1).  It also leaks 4.6kB (a *lot* less) with the persistent
approach.  The /ENOUGH= puts a limit on the number of scripts the RTE will
process before proactively exiting.  This is a default of 100 when using /CLEAN
or 1000 for persistent engines.



QUALIFIERS
----------
/CLEAN         with the persistent engine do not cache any eval()ed scripts
/ENOUGH=       integer (see "cautions" above)
/ENV=          (for Perl 5.6->) uses PERL_ENV_TABLES to confine %ENV hash to
               CLISYM_GLOBAL (default), CLISYM_LOCAL, CRTL_ENV, or other
/HASH=         name of Perl hash into which CGI environment is created
/NOPERSIST     do not use the persistent engine
/PDEBUG        turn on debug statements in the persistent Perl engine package
/PERL=         pass this to the Perl interpreter command line (e.g. "-Dlts")
/TYPE=         default file type (e.g. ".PL", ".CGI")
/NOSOCKET      do not attempt to load the socket (TCP/IP) extension
/WWWPREFIX     by default Perl CGI variables are created without the leading
               "WWW_", this restores this.


LOGICAL NAMES
-------------
PERLRTE$DBUG   turns on all "if (Debug)" statements


BUILD DETAILS
-------------
$ @BUILD_PERLRTE BUILD  !compile+link
$ @BUILD_PERLRTE LINK   !link-only


COPYRIGHT
---------
Copyright (c) 2000 Mark G.Daniel
This program, comes with ABSOLUTELY NO WARRANTY.
This is free software, and you are welcome to redistribute it
under the conditions of the GNU GENERAL PUBLIC LICENSE, version 2.


VERSION HISTORY
---------------
28-OCT-2000  MGD  v1.0.0, initial development
*/

/*****************************************************************************/

#ifdef __ALPHA
#  define SOFTWAREID "PERLRTE AXP-1.0.0"
#else
#  define SOFTWAREID "PERLRTE VAX-1.0.0"
#endif

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* VMS related header files */
#include <descrip.h>
#include <lib$routines.h>
#include <lnmdef.h>
#include <ssdef.h>
#include <stsdef.h>

/* CGILIB header file */
#include <cgilib.h>

/* macros */

#define DEFAULT_CGI_HASH_NAME      "main::ENV"
#define DEFAULT_FILE_TYPE          ".PL"
#define DEFAULT_PERL_ENV_TABLES    "CLISYM_GLOBAL,LNM$PROCESS"
#define DEFAULT_PERSIST_ENOUGH     1000
#define DEFAULT_NONPERSIST_ENOUGH   100

#define FI_LI __FILE__, __LINE__

#define VMSok(x) ((x) & STS$M_SUCCESS)
#define VMSnok(x) !(((x) & STS$M_SUCCESS))

#define boolean int
#define true 1
#define false 0

#define MAX_LNM_EQUIV 8

/* global storage */

boolean  CliCgiPrefix,
         CliNoSocket,
         CliClean,
         CliPerlDebug,
         CliPersistentEngine = true,
         Debug,
         DebugCgiLib;

int  EnoughCount = DEFAULT_PERSIST_ENOUGH,
     UsageCount;

char *CliCgiEnvPtr = DEFAULT_PERL_ENV_TABLES,
     *CliCgiHashNamePtr = DEFAULT_CGI_HASH_NAME,
     *CliFileTypePtr = DEFAULT_FILE_TYPE,
     *CliPerlPtr = "";

char  SoftwareID [48],
      Utility [] = "PERLRTE";

/* externs */

extern char  PackageEmbedPersist[];

/* prototypes */

int sys$crelnm (int, struct dsc$descriptor_s*, struct dsc$descriptor_s*,
                int, void*);
void GetParameters ();
void PerlSysInit3 (int, char**, char**);
void ProcessRequest ();
int PerlPersistEngine (char *);
int PerlNonPersistEngine (char *);
int strsame (char*, char*, int);

/*****************************************************************************/
/*
*/

main (int argc, char** argv, char **env)
       
{
   static $DESCRIPTOR (LogTableDsc, "LNM$PROCESS");
   static $DESCRIPTOR (LogNameDsc, "PERL_ENV_TABLES");

   int  idx, status;
   char  *cptr, *sptr;
   struct {
      short int  buf_len;
      short int  item;
      unsigned char   *buf_addr;
      unsigned short  *ret_len;
   }
   CreLnmItem [MAX_LNM_EQUIV+1];

   /*********/
   /* begin */
   /*********/

   sprintf (SoftwareID, "%s (%s)", SOFTWAREID, CgiLibEnvironmentVersion());

   Debug = /** DebugCgiLib = **/ (getenv ("PERLRTE$DBUG") != NULL);
   CgiLibEnvironmentSetDebug (DebugCgiLib);

   if (!CliPersistentEngine) EnoughCount = DEFAULT_NONPERSIST_ENOUGH;

   CgiLibEnvironmentInit (0, NULL, 0);

   GetParameters ();

   CgiLibResponseSetSoftwareID (SoftwareID);

   if (!CgiLibEnvironmentIsCgiPlus())
   {
      /* just won't behave as expected in a non-CGIplus environment! */
      fprintf (stdout, "%%%s-E-INTERNAL, not executing as CGIplus\n", Utility);
      exit (STS$K_ERROR | STS$M_INHIB_MSG);
   }

   if (CliCgiEnvPtr[0])
   {
      idx = 0;
      cptr = CliCgiEnvPtr;
      while (*cptr && idx < MAX_LNM_EQUIV)
      {
         for (sptr = cptr; *sptr && *sptr != ','; sptr++);
         CreLnmItem[idx].item = LNM$_STRING;
         CreLnmItem[idx].buf_addr = (unsigned char*)cptr;
         CreLnmItem[idx++].buf_len = sptr - cptr;
         if (Debug) fprintf (stdout, "|%.*s|\n", sptr-cptr, cptr); 
         if (*(cptr = sptr)) cptr++;
      }
      memset (&CreLnmItem[idx], 0, sizeof(CreLnmItem[idx]));
      status = sys$crelnm (0, &LogTableDsc, &LogNameDsc, 0, &CreLnmItem);
      if (VMSnok (status)) exit (status);
   }

   PerlSysInit3 (argc, argv, env);

   while (EnoughCount--)
   {
      /* block waiting for the first/next request */
      CgiLibVar ("");
      ProcessRequest ();
      CgiLibCgiPlusEOF ();
   }
}

/*****************************************************************************/
/*
*/

void ProcessRequest ()
       
{
   char  *cptr, *sptr, *zptr,
         *ScriptFileName;
   char  FileName [256];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProcessRequest()\n");

   ScriptFileName = CgiLibVar ("WWW_SCRIPT_FILENAME");
   if (!ScriptFileName[0])
   {
      fprintf (stdout, "%%%s-E-INTERNAL, no \"SCRIPT_FILENAME\"\n", Utility);
      exit (STS$K_ERROR | STS$M_INHIB_MSG);
   }

   /* ensure the script file name has a default extension */
   zptr = (sptr = FileName) + sizeof(FileName);
   for (cptr = ScriptFileName; *cptr && sptr < zptr; *sptr++ = *cptr++);
   if (sptr >= zptr) exit (SS$_BUFFEROVF+1);
   *(cptr = sptr) = '\0';
   while (cptr > FileName && *cptr != '.' && *cptr != ']') cptr--;
   if (*cptr != '.')
   {
      for (cptr = CliFileTypePtr; *cptr && sptr < zptr; *sptr++ = *cptr++);
      if (sptr >= zptr) exit (SS$_BUFFEROVF+1);
      *sptr = '\0';
   }

   UsageCount++;

   if (CliPersistentEngine)
      PerlPersistEngine (FileName);
   else
      PerlNonPersistEngine (FileName);
}

/*****************************************************************************/
/*
Get "command-line" parameters, whether from the command-line or from a
configuration symbol or logical containing the equivalent.
*/

void GetParameters ()

{
   static char  CommandLine [256];
   static unsigned long  Flags = 0;

   int  status;
   unsigned short  Length;
   char  ch;
   char  *aptr, *cptr, *clptr, *sptr;
   $DESCRIPTOR (CommandLineDsc, CommandLine);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "GetParameters()\n");

   if ((clptr = getenv ("PERLRTE$PARAM")) == NULL)
   {
      /* get the entire command line following the verb */
      if (VMSnok (status =
          lib$get_foreign (&CommandLineDsc, 0, &Length, &Flags)))
         exit (status);
      (clptr = CommandLine)[Length] = '\0';
   }

   aptr = NULL;
   ch = *clptr;
   for (;;)
   {
      if (aptr != NULL && *aptr == '/') *aptr = '\0';
      if (!ch || ch == '!') break;

      *clptr = ch;
      if (Debug) fprintf (stdout, "clptr |%s|\n", clptr);
      while (*clptr && isspace(*clptr)) *clptr++ = '\0';
      aptr = clptr;
      if (*clptr == '/') clptr++;
      while (*clptr && !isspace (*clptr) && *clptr != '/')
      {
         if (*clptr != '\"')
         {
            clptr++;
            continue;
         }
         cptr = clptr;
         clptr++;
         while (*clptr)
         {
            if (*clptr == '\"')
               if (*(clptr+1) == '\"')
                  clptr++;
               else
                  break;
            *cptr++ = *clptr++;
         }
         *cptr = '\0';
         if (*clptr) clptr++;
      }
      ch = *clptr;
      if (*clptr) *clptr = '\0';
      if (Debug) fprintf (stdout, "aptr |%s|\n", aptr);
      if (!*aptr) continue;

      /***********/
      /* process */
      /***********/

      if (strsame (aptr, "/CLEAN", 4))
      {
         CliClean = true;
         continue;
      }

      if (strsame (aptr, "/DBUG", -1))
      {
         Debug = true;
         continue;
      }

      if (strsame (aptr, "/ENOUGH=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         EnoughCount = atoi(cptr);
         if (EnoughCount) continue;
         fprintf (stdout, "%%%s-E-IVPARM, invalid parameter\n \\%s\\\n",
                  Utility, aptr+1);
         exit (STS$K_ERROR | STS$M_INHIB_MSG);
      }

      if (strsame (aptr, "/ENV=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (!*cptr) continue;
         CliCgiEnvPtr = cptr+1;
         continue;
      }

      if (strsame (aptr, "/HASH=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (!*cptr) continue;
         CliCgiHashNamePtr = cptr+1;
         continue;
      }

      if (strsame (aptr, "/PACKAGE", -1))
      {
         fputs (PackageEmbedPersist, stdout); 
         exit (SS$_NORMAL);
      }

      if (strsame (aptr, "/PDEBUG", -1))
      {
         CliPerlDebug = true;
         continue;
      }

      if (strsame (aptr, "/PERL=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (!*cptr) continue;
         CliPerlPtr = cptr+1;
         continue;
      }

      if (strsame (aptr, "/NOPERSIST", 6))
      {
         CliPersistentEngine = false;
         continue;
      }

      if (strsame (aptr, "/NOSOCKET", 6))
      {
         CliNoSocket = true;
         continue;
      }

      if (strsame (aptr, "/TYPE=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (!*cptr) continue;
         CliFileTypePtr = cptr+1;
         continue;
      }

      if (strsame (aptr, "/VERSION", 4))
      {
         fprintf (stdout, "%%%s-I-VERSION, %s\n", Utility, SoftwareID);
         exit (SS$_NORMAL);
      }

      if (strsame (aptr, "/WWWPREFIX", 6))
      {
         CliCgiPrefix = true;
         continue;
      }

      if (*aptr == '/')
      {
         fprintf (stdout, "%%%s-E-IVQUAL, unrecognized qualifier\n \\%s\\\n",
                  Utility, aptr+1);
         exit (STS$K_ERROR | STS$M_INHIB_MSG);
      }

      fprintf (stdout, "%%%s-E-MAXPARM, too many parameters\n \\%s\\\n",
               Utility, aptr);
      exit (STS$K_ERROR | STS$M_INHIB_MSG);
   }
}

/****************************************************************************/
/*
Does a case-insensitive, character-by-character string compare and returns 
true if two strings are the same, or false if not.  If a maximum number of 
characters are specified only those will be compared, if the entire strings 
should be compared then specify the number of characters as 0.
*/ 

boolean strsame
(
char *sptr1,
char *sptr2,
int  count
)
{
   while (*sptr1 && *sptr2)
   {
      if (toupper (*sptr1++) != toupper (*sptr2++)) return (false);
      if (count)
         if (!--count) return (true);
   }
   if (*sptr1 || *sptr2)
      return (false);
   else
      return (true);
}

/*****************************************************************************/

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               