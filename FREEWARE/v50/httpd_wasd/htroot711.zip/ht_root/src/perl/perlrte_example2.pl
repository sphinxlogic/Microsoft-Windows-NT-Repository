print "Content-Type: text/plain

Hello out there ... This is PERLRTE_EXAMPLE2.PL

CGI Environment
---------------
";

printf ("perlRTEpersist=\"$main::perlRTEpersist\"\n\n");

if ($ENV{KEY_1}) {
   printf ("exiting ...\n");
   exit (0);
}

my @sortedKeys = sort (keys %ENV);
foreach my $name (@sortedKeys) {
   printf ("$name=\"$ENV{$name}\"\n");
}
