/*****************************************************************************/
/*
                                PerlRTEng.c

Perl Run-Time Environment - Perl engine.  This needs to be coded as a separate
module because the Perl header files seem to interfere something chronic with
at least CGILIB (probably definitions for local getenv(), etc.).


COPYRIGHT
---------
Copyright (c) 2000 Mark G.Daniel
This program, comes with ABSOLUTELY NO WARRANTY.
This is free software, and you are welcome to redistribute it
under the conditions of the GNU GENERAL PUBLIC LICENSE, version 2.


VERSION HISTORY
---------------
See PERLRTE.C
*/
/*****************************************************************************/

/* Perl headers */

#include <EXTERN.h>
#include <perl.h>

#ifdef PERL_GLOBAL_STRUCT
#define PERLVAR(var,type) /**/
#define PERLVARA(var,type) /**/
#define PERLVARI(var,type,init) PL_Vars.var = init;
#define PERLVARIC(var,type,init) PL_Vars.var = init;
#include "perlvars.h"
#undef PERLVAR
#undef PERLVARA
#undef PERLVARI
#undef PERLVARIC
#endif

/* macros */

#define DEFAULT_CGI_PREFIX   "WWW_"
#define CGI_GATEWAY_RTE      "GATEWAY_RTE"
#define WWW_CGI_GATEWAY_RTE  DEFAULT_CGI_PREFIX "GATEWAY_RTE"

/* externs */

extern int  CliClean,
            CliCgiPrefix,
            CliNoSocket,
            CliPerlDebug,
            Debug,
            UsageCount;

extern char  *CliCgiHashNamePtr,
             *CliPerlPtr;

extern char  SoftwareID[],
             Utility[];

/* prototypes */

char* CgiLibVar (char*);
void SetCgiEnv (int);
void XsInit _((void));
I32 hv_iterinit (HV*);
SV* hv_iternextsv (HV*, char**, I32*);
void boot_DynaLoader _((CV* cv));
void boot_Socket _((CV* cv));

/*****************************************************************************/
/*
Essentially a Perl package in a null-terminated string.  Done this way so that
it can be evaluated directly as part of the RTE executable, not needing to be
located as a file somewhere.  Lifted (almost) directly from the 'perlembed'
document (thanks to the authors and maintainers).  To view the package
uncluttered by escape characters do "$ PERLRTE /PACKAGE".
*/

char PackageEmbedPersist [] =

"\
package Embed::Persist;\n\
\n\
use strict;\n\
use vars \'%Cache\';\n\
use Symbol qw(delete_package);\n\
\n\
sub valid_package_name\n\
{\n\
    my($string) = @_;\n\
    $string =~ s/([^A-Za-z0-9\\/])/sprintf(\"_%2x\",unpack(\"C\",$1))/eg;\n\
    # second pass only for words starting with a digit\n\
    $string =~ s|/(\\d)|sprintf(\"/_%2x\",unpack(\"C\",$1))|eg;\n\
\n\
    # Dress it up as a real package name\n\
    $string =~ s|/|::|g;\n\
    return \"Embed\" . $string;\n\
}\n\
\n\
sub eval_file\n\
{\n\
   my ($filename, $delete, $debug) = @_;\n\
   my $package = valid_package_name($filename);\n\
   if ($debug) { printf (\"DEBUG: \\$package |$package|\\n\"); }\n\
   my $mtime = -M $filename;\n\
   if (defined $Cache{$package}{mtime} &&\n\
       $Cache{$package}{mtime} <= $mtime)\n\
   {\n\
      # we have compiled this subroutine already,\n\
      if ($debug) { printf (\"DEBUG: package cached\\n\"); }\n\
   }\n\
   else\n\
   {\n\
      local *FH;\n\
      open FH, $filename or die \"open \'$filename\' $!\";\n\
      local($/) = undef;\n\
      my $sub = <FH>;\n\
      close FH;\n\
\n\
      #wrap the code into a subroutine inside our unique package\n\
      my $eval = qq{package $package; sub handler { $sub; }};\n\
      {\n\
          # hide our variables within this block\n\
          my($filename,$mtime,$package,$sub);\n\
          eval $eval;\n\
      }\n\
      die $@ if $@;\n\
      if ($debug) { printf (\"DEBUG: eval package\\n\"); }\n\
      $Cache{$package}{mtime} = $mtime;\n\
   }\n\
\n\
   #set these global variables for script usage/abuse\n\
   $main::perlRTEdebug = $debug;\n\
   $main::perlRTEpersist = !$delete;\n\
\n\
   eval {$package->handler;};\n\
   die $@ if $@;\n\
\n\
   $delete = !$main::perlRTEpersist if !$delete;\n\
   if ($delete) {\n\
      if ($debug) { printf (\"DEBUG: delete_package($package)\\n\"); }\n\
      delete_package($package);\n\
      delete $Cache{$package}{mtime}\n\
   }\n\
   else {\n\
      if ($debug) { printf (\"DEBUG: package kept\\n\"); }\n\
   }\n\
}\n\
\n\
1;\n\
\n\
__END__\n\
";

/*****************************************************************************/
/*
This function runs the Perl interpreter for a "persistent" Perl Run-Time
Environment.  This uses the "Embed::Persist" package in an attempt to create
a partioned name and execution space for each unique script file passed to it.
*/

int PerlPersistEngine (char *PerlSource)
       
{
   static PerlInterpreter  *PerlIntPtr = NULL;

   int  idx, status;
   char  *PerlArgs [10];

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "PerlPersistEngine() %d |%s|\n",
               UsageCount, PerlSource);

   if (PerlIntPtr == NULL)
   {
      if (Debug) fprintf (stdout, "perl_alloc()\n");
      PerlIntPtr = perl_alloc();

      if (Debug) fprintf (stdout, "perl_contruct()\n");
      perl_construct (PerlIntPtr);
      PL_perl_destruct_level = 0;

      /* load the "Embed::Persist" package (string) above */
      idx = 0;
      PerlArgs[idx++] = "PERLRTENG";
      if (CliPerlPtr[0]) PerlArgs[idx++] = CliPerlPtr;
      PerlArgs[idx++] = "-e";
      PerlArgs[idx++] = PackageEmbedPersist;
      if (Debug) fprintf (stdout, "perl_parse()\n");
      status = perl_parse (PerlIntPtr, XsInit, idx, PerlArgs, (char **)NULL);
      if (Debug) fprintf (stdout, "status: %d\n", status);
      if (status) exit (status);

      if (Debug) fprintf (stdout, "perl_run()\n");
      status = perl_run (PerlIntPtr);
      if (Debug) fprintf (stdout, "status: %d\n", status);
      if (!(status & 1)) exit (status);
   }

   SetCgiEnv (1);

   idx = 0;
   PerlArgs[idx++] = PerlSource;
   PerlArgs[idx++] = CliClean ? "1" : "";
   PerlArgs[idx++] = (Debug || CliPerlDebug) ? "1" : "";
   PerlArgs[idx++] = NULL;
   if (Debug) fprintf (stdout, "perl_call_argv()\n");
   perl_call_argv ("Embed::Persist::eval_file",
                   G_DISCARD | G_EVAL, PerlArgs);

   if (SvTRUE(ERRSV))
      fprintf (stdout, "%%%s-W-CALLARGV, %s\n", Utility, SvPV(ERRSV,PL_na));

   SetCgiEnv (0);

   return (1);
}

/*****************************************************************************/
/*
This function runs a Perl interpreter for a "clean" Perl Run-Time Environment. 
Allows the Perl interpreter to continue between requests, just contructing and
destructing it.  The function also attempts to improve latency by proactively
creating a new Perl environment at the conclusion of a request.  At the start
of the next it only has to parse and run the script.
*/

int PerlNonPersistEngine (char *PerlSource)
       
{
   static PerlInterpreter  *PerlIntPtr = NULL;

   I32  status;
   char  *PerlArgs [3];

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "PerlNonPersistEngine() %d |%s|\n",
               UsageCount, PerlSource);

   if (UsageCount == 1 || PerlIntPtr == NULL || PerlSource[0] == '.')
   {
      if (Debug) fprintf (stdout, "perl_alloc()\n");
      PerlIntPtr = perl_alloc();
   }
   if (UsageCount == 1)
   {
      if (Debug) fprintf (stdout, "perl_contruct()\n");
      perl_construct (PerlIntPtr);
      PL_perl_destruct_level = 0;
   }

   PerlArgs[0] = "PERLRTENG";
   PerlArgs[1] = PerlSource;
   if (Debug) fprintf (stdout, "perl_parse()\n");
   status = perl_parse (PerlIntPtr, XsInit, 2, PerlArgs, (char **)NULL);
   if (Debug) fprintf (stdout, "status: %d\n", status);

   if (!status)
   {
      SetCgiEnv (1);
      if (Debug) fprintf (stdout, "perl_run()\n");
      perl_run (PerlIntPtr);
   }

   if (Debug) fprintf (stdout, "perl_destruct()\n");
   perl_destruct (PerlIntPtr);

   /* proactively create a new Perl environment ready for the next request */
   if (Debug) fprintf (stdout, "perl_alloc()\n");
   PerlIntPtr = perl_alloc();

   if (Debug) fprintf (stdout, "perl_contruct()\n");
   perl_construct (PerlIntPtr);
   PL_perl_destruct_level = 0;

   return (1);
}

/*****************************************************************************/
/*
Monkey see, monkey do ...
*/

void PerlSysInit3
(
int argc,
char **argv,
char **env
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "PerlSysInit3()\n");

   PERL_SYS_INIT3 (&argc, &argv, &env);
}

/*****************************************************************************/
/*
Generate the CGI variables.  If 'SetEnv' is true scan though the CGIplus
variable list creating each of the variables, if false delete each of them. 
With a persistent environment it is necessary to clean up variables created,
lest they interfere with the next script processed.
*/

void SetCgiEnv (int SetEnv)
       
{
   char  *cptr, *sptr;
   char  String [256];
   I32  klen;
   HV  *myEnvHV;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "SetCgiEnv() %d %d |%s|\n",
               SetEnv, CliCgiPrefix, CliCgiHashNamePtr);

   myEnvHV = perl_get_hv (CliCgiHashNamePtr, TRUE);

   while ((cptr = CgiLibVar("*")) != NULL)
   {
      if (Debug) fprintf (stdout, "|%s|\n", cptr);
      for (sptr = cptr; *sptr && *sptr != '='; sptr++);
      /* by default the "WWW_" is removed from the CGI variables */
      if (!CliCgiPrefix) cptr += sizeof(DEFAULT_CGI_PREFIX)-1;
      klen = sptr - cptr;
      if (*sptr) sptr++;
      if (SetEnv)
         hv_store (myEnvHV, cptr, klen, newSVpv(sptr,0), FALSE);
      else
         hv_delete (myEnvHV, cptr, klen, FALSE);
   }

   if (SetEnv)
   {
      sprintf (String, "%s [%d]", SoftwareID, UsageCount);
      if (CliCgiPrefix)
         hv_store (myEnvHV, WWW_CGI_GATEWAY_RTE, sizeof(WWW_CGI_GATEWAY_RTE)-1,
                   newSVpv(String,0), FALSE);
      else
         hv_store (myEnvHV, CGI_GATEWAY_RTE, sizeof(CGI_GATEWAY_RTE)-1,
                   newSVpv(String,0), FALSE);
   }
}

/*****************************************************************************/
/*
*/

void XsInit ()
       
{
   char *file = __FILE__;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "XsInit()\n");

   /* DynaLoader is a special case */
   newXS("DynaLoader::boot_DynaLoader", boot_DynaLoader, file);
   if (!CliNoSocket) newXS("Socket::bootstrap", boot_Socket, file);
}

/*****************************************************************************/

