# require "HT_ROOT:[SCRIPT_LOCAL.CGIPM]CGI.PM"
require CGI;
use CGI qw(:standard);

print "Content-Type: text/plain

Hello out there ... This is PERLRTE_EXAMPLE3.PL

*** LOADS CGI.PM ***

CGI Environment
---------------
";

printf ("perlRTEpersist=\"$main::perlRTEpersist\"\n\n");

if ($ENV{KEY_1}) {
   printf ("exiting ...\n");
   exit (0);
}

my @sortedKeys = sort (keys %ENV);
foreach my $name (@sortedKeys) {
   printf ("$name=\"$ENV{$name}\"\n");
}
