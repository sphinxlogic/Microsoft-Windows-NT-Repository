/*****************************************************************************/
/*
                                 SeSoLa.c


    THE GNU GENERAL PUBLIC LICENSE APPLIES DOUBLY TO ANYTHING TO DO WITH
                    AUTHENTICATION AND AUTHORIZATION!

    This package is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License, or any later
    version.

>   This package is distributed in the hope that it will be useful,
>   but WITHOUT ANY WARRANTY; without even the implied warranty of
>   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
>   GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


Named "SeSoLa" to avoid any confusion and/or conflict with OpenSSL routines.

SSL I/O is implemented as a OpenSSL BIO_METHOD, named "sesola_method". It
provides NON-BLOCKING SSL input/output. All routines that are part of this
functionality are named "sesola_..." and are grouped towards the end of this
module.


OPENSSL
-------
With the retirement of Eric Young from OpenSource software and the creation of
the OpenSSL organisation this module will be based on this group's packages and
in particular the the VMS port supported by Richard Levitte.

  richard@levitte.org
  http://www.free.lp.se/openssl/
  http://www.openssl.org/

The initial development was done using SSLeay v0.8.1
Modified for SSLeay 0.9.0b
A great leap forward with OpenSSL v0.9.3 (thanks Richard)
Tested against OpenSSL v0.9.4
Tested and modified for OpenSSL v0.9.5
Tested against OpenSSL v0.9.6

A general hard-copy reference (and there aren't many around) that has been
interesting and informative is "SSL and TLS, Designing and Building Secure
Systems", Eric Rescorla, 2001, Addison-Wesley (ISBN-201-61598-3).
Though don't blame the book's author for the code author's shortcomings!


SSL COMMAND LINE OPTIONS
------------------------
The /SSL= qualifier allows certain SSL runtime parameters to be set.  The
default is support of SSLv2/SSLv3, certificate file provided by HTTPD$SSL_CERT,
all ciphers, and a session cache of 128.

  /SSL=2                  support only SSLv2 (pre-v6.0.0)
  /SSL=3                  support only SSLv3 (pre-v6.0.0)
  /SSL=23                 support both SSLv2 and SSLv3 (pre-v6.0.0)
  /SSL=SSLv2              support only SSLv2
  /SSL=noSSLv2            turn SSLv2 option off
  /SSL=SSLv3              support only SSLv3
  /SSL=noSSLv3            turn SSLv3 option off
  /SSL=(SSLv2,SSLv3)      support both SSLv2 and SSLv3
  /SSL=TLSv1              support only TLSv1 (etc.)
  /SSL=noTLSv1            turn TLSv1 option off
  /SSL=(OPTIONS=0xnn)     SSL_OP_.. options (see [.INCLUDE.OPENSSL]SSL.H)
  /SSL=(CERT=file)        location of default OpenSSL-PEM certificate file
  /SSL=(CIPHER=list)      semi-colon-separated list of supported ciphers
  /SSL=(CACHE=integer)    size of session cache
  /SSL=(KEY=file)         location of default OpenSSL-PEM private key file
                          (if separate from the certificate information)

Multiple parameters may be included by separating with commas.  Example:

  /SSL=(CERT=HT_ROOT:[LOCAL]SITE.PEM,SSLV2,SSLV3)


CGI VARIABLES
-------------
CGI variables for scripting and SSI environments can be selectively generated
for "https:" requests.  See the mapping SETting "SSLCGI=" in MAPURL.C module. 
The Apache mod_SSL variables are based on the v2.5 documentation by blah
(blah@blah).  The Purveyor variables are based on Purveyor documentation.

  Apache mod_SSL -like SSL variables
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  o  HTTPS .................. "true" indicating it's SSL
  o  SSL_PROTOCOL ........... version (e.g. "SSLv2", "SSLv3")
  o  SSL_SESSION_ID ......... hex-encoded SSL session ID
  o  SSL_CIPHER ............. cipher name (e.g. "RC4-MD5")
  o  SSL_CIPHER_EXPORT ...... "true" if export grade
  o  SSL_CIPHER_USEKEYSIZE .. bits cipher used for session
  o  SSL_CIPHER_ALGKEYSIZE .. bits cipher is capable of supporting
  o  SSL_VERSION_INTERFACE .. WASD server software ID
  o  SSL_VERSION_LIBRARY .... OpenSSL version
  o  SSL_CLIENT_xxx ......... client certs not currently supported
  o  SSL_SERVER_M_VERSION ... server cert version
  o  SSL_SERVER_M_SERIAL .... server cert serial number
  o  SSL_SERVER_S_DN ........ subject cert distinquishing name
  o  SSL_SERVER_S_DN_x509 ... subject cert DN components
  o  SSL_SERVER_I_DN ........ issuer cert distinquishing name
  o  SSL_SERVER_I_DN_x509 ... issuer cert DN components
  o  SSL_SERVER_V_START ..... cert validity start date
  o  SSL_SERVER_V_END ....... cert validity end date
  o  SSL_SERVER_A_SIG ....... server cert signature algorithm
  o  SSL_SERVER_A_KEY ....... server cert public key algorithm
  o  SSL_SERVER_CERT ........ (see note in SeSoLaCgiVariablesApacheModSsl())

  "Purveyor"-like security/SSL variables
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  o  SECURITY_STATUS ........ "NONE" or "SSL"
  o  SSL_CIPHER ............. name of the cipher in use
  o  SSL_CIPHER_KEYSIZE ..... export:40, domestic: 128
  o  SSL_CLIENT_CA .......... client cert authority
  o  SSL_CLIENT_DN .......... client cert distinguished name
  o  SSL_SERVER_CA .......... server cert authority
  o  SSL_SERVER_DN .......... server cert distinguished name
  o  SSL_VERSION ............ SSL version (e.g. "SSLv2")


LOGICAL/SYMBOL NAMES
--------------------
The following logical or symbol names can be used to provide runtime
information to the SSL functionality.  Configuration options provided by /SSL=
and [service] or /SERVICE= parameters override anything provided via these
logical/symbol names.

  HTTPD$SSL_CERT          location of default OpenSSL-PEM certificate file
  HTTPD$SSL_CIPHER        comma-separated list of default supported ciphers
  HTTPD$SSL_KEY           location of default OpenSSL-PEM private key file
  HTTPD$SSL_PARAMS        the equivalent functionality of the /SSL= qualifier


VERSION HISTORY
---------------
01-DEC-2000  MGD  Richard Levitte in a recent email to vms-web-daemon@KJSL.COM
                  points out using SSL_CTX_use_certificate_chain_file() is more
                  versatile than SSL_CTX_use_certificate_file(),
                  changes to SSL_ and BIO_ free() rundown in SeSoLaFree(),
                  bugfix; SesolaCgiVariablesApacheModSsl() 
22-NOV-2000  MGD  where a service-specific certificate is supplied and no
                  service-specific key assume the key is in the specific cert
17-OCT-2000  MGD  modify SSL initialization so that "fallback" conditions
                  (same port on same IP address) are more easily identified
26-SEP-2000  MGD  built and verified against OpenSSL 0.9.6
                  change 'boolean' to 'BOOL' to accomodate new OpenSSL typedef
26-AUG-2000  MGD  SeSoLaWatchPeek()
17-JUN-2000  MGD  modifications for SERVICE.C requirements
06-MAY-2000  MGD  added Apache mod_SSL style CGI variables
05-MAR-2000  MGD  tested against OpenSSL v0.9.5
                  (SSL_OP_NON_EXPORT_FIRST generates error message, removed),
                  use NetWriteFaol(), et.al.
23-DEC-1999  MGD  modify NEEDSTRUCT reported by DECC v6.2 
19-OCT-1999  MGD  SeSoLaInitServiceList() service errors not fatal at startup
11-SEP-1999  MGD  tested against OpenSSL v0.9.4,
                  SSLeay no longer supported
18-AUG-1999  MGD  add certificate CA and DN to SSL report,
                  bugfix; certificate/key pairs when initializing service
12-JUN-1999  MGD  refine SSL connection handling
26-MAY-1999  MGD  allow some SSL options to be set if desired,
                  set SSL_OP_NON_EXPORT_FIRST (for some certificate processing)
18-APR-1999  MGD  improve error reporting during certificate loading
03-APR-1999  MGD  support OpenSSL 0.9.3
                  (with initial, backward support for SSLeay 0.8 & 0.9), 
                  add WATCH callbacks
31-MAR-1999  MGD  bugfix; report request from non-SSL port
20-JAN-1999  MGD  report format refinement
07-NOV-1998  MGD  WATCH facility
24-OCT-1998  MGD  per-service context (implies per-service certificate)
01-JUN-1998  MGD  builds OK with SSLeay 0.9.0b
25-JAN-1998  MGD  initial development for v5.0, SSLeay v0.8.1
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* VMS related header files */
#include <ssdef.h>
#include <stsdef.h>

/* application header files */
#include "sesola.h"

/* OpenSSL 0.9.6 has a typedef boolean - work around this */
#ifdef boolean
#  undef boolean
#  define BOOL int
#endif /* boolean */

#define WASD_MODULE "SESOLA"

/***************************************/
#ifdef SESOLA  /* secure sockets layer */
/***************************************/

/* OpenSSL header files (0.9.3ff) */
#include "openssl/bio.h"
#include "openssl/buffer.h"
#include "openssl/crypto.h"
#include "openssl/err.h"
#include "openssl/ssl.h"
#include "openssl/X509.h"

/**********/
/* macros */
/**********/

#define DEFAULT_SESSION_CACHE_SIZE 128

#define SESOLA_UNDEFINED          0
#define SESOLA_ACCEPT             1
#define SESOLA_SHUTDOWN           2
#define SESOLA_DATA_BLOCKING      3
#define SESOLA_DATA_NON_BLOCKING  4

#define SESOLA_PROTOCOL_SSLV2  0x01
#define SESOLA_PROTOCOL_SSLV3  0x02
#define SESOLA_PROTOCOL_TLSV1  0x04

#define APACHE_MOD_SSL_VERSION_INTERFACE SoftwareID
/* see not below */
#define APACHE_MOD_SSL_SERVER_CERT 0

/*******************/
/* data structures */
/*******************/

#ifdef __ALPHA
#   pragma member_alignment __save
#   pragma member_alignment
#endif

struct SeSoLaStruct
{
   /* OpenSSL structures */
   SSL  *SslPtr;
   BIO  *BioPtr;
   BIO  *BioSslPtr;
   SSL_CTX  *SeSoLaCtx;

   /* pointer back to the request owning this structure */
   struct RequestStruct  *rqptr;

   /*
       These "in-progress" flags are to provide an additional indication of
       when a OpenSSL routine has used non-blocking I/O.  Only valid within
       the single AST-delivery context (i.e. to be checked immediately after
       using an OpenSSL function, before returning out of the current AST
       delivery context), because as soon as the I/O AST is delivered the
       approriate flags will be reset.
   */
   BOOL  ReadInProgress,
         ReadCompleted,
         SSL_accepted,
         WriteInProgress,
         WriteCompleted;

   int  /* */
        AcceptCount,
        /* size of read data buffer (for AST routine) */
        ReadDataSize,
        /* flag indicating purpose and/or type of network read */
        ReadType,
        /* number of characters to be written to network */
        WriteDataLength,
        /* flag indicating purpose and/or type of network write */
        WriteType;

  char  /* during SSL connect accept points to start of buffer */
        *AcceptReadDataPtr,
        /* pointer to read data buffer (for AST routine use) */
        *ReadDataPtr,
        /* pointer to write data buffer (for AST routine use) */
        *WriteDataPtr;

   /* SSL post-processing, stores the pointer to the AST routine */
   void  *ReadAstFunctionPtr,
         *WriteAstFunctionPtr;
};

#ifdef __ALPHA
#   pragma member_alignment __restore
#endif

/******************/
/* global storage */
/******************/

BOOL  ProtocolHttpsAvailable,
      ProtocolHttpsConfigured,
      SeSoLaOptions;

int  SeSoLaSessionCacheSize,
     SeSoLaOptionsOff,
     SeSoLaProtocolVersion;

char  *SeSoLaDefaultCertPtr,
      *SeSoLaDefaultCipherListPtr,
      *SeSoLaDefaultKeyPtr,
      *SeSoLaProtocolsPtr;

char  SeSoLaParams [256] = "";

char  ErrorSslPort [] = "This is an SSL (&quot;https:&quot;) port.",
      ErrorSslReportService [] =
        "This report is only available via an SSL service!",
      HttpdSesola [] = " SSL";

BIO_METHOD  *SesolaBioMemPtr;

static struct SesolaCertDnRecStruct
{
   char *name;
   int length;
}
SesolaCertDnRec [] =
{
   { "/C=", 3 },   /* countryName */
   { "/ST=", 4 },  /* stateOrProvinceName */
   { "/SP=", 4 },  /* stateOrProvinceName */
   { "/L=", 3 },   /* localityName */
   { "/O=", 3 },   /* organizationName */
   { "/OU=", 4 },  /* organizationalUnitName */
   { "/CN=", 4 },  /* commonName */
   { "/T=", 3 },   /* title */
   { "/I=", 3 },   /* initials */
   { "/G=", 3 },   /* givenName */
   { "/S=", 3 },   /* surname */
   { "/D=", 3 },   /* description */
   { "/UID=", 5 },  /* uniqueIdentifier */
   { "/Email=", 7 }, /* pkcs9_emailAddress */
   { NULL, 0 }
};

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern BOOL Debug;
#else
#define Debug 0 
#endif

extern int  WatchEnabled,
            NetReadBufferSize,
            OutputBufferSize;
         
extern char  ErrorSanityCheck[],
             ServerHostPort[],
             SoftwareID[],
             Utility[];

extern struct AccountingStruct  Accounting;
extern struct ConfigStruct  Config;
extern struct MsgStruct  Msgs;
extern struct ServiceStruct  *ServiceListHead;

/**********************************/
/* BIO method function prototypes */
/**********************************/

int sesola_write (BIO*, char*, int);
int sesola_write_ast (struct RequestStruct*);
int sesola_read (BIO*, char*, int);
int sesola_read_ast (struct RequestStruct*);
int sesola_puts (BIO*, char*);
int sesola_gets (BIO*, char*, int);
long sesola_ctrl (BIO*, int, long, char*);
int sesola_new (BIO*);
int sesola_free (BIO*);

int SesolaWatchBioCallback (BIO*, int, char*, int, long, long);
SesolaWatchInfoCallback (SSL*, int, int);

BIO_METHOD *BIO_s_sesola();

BIO_METHOD sesola_method =
{
   BIO_TYPE_FD,
   "WASD SESOLA",
   sesola_write,
   sesola_read,
   sesola_puts,
   sesola_gets,
   sesola_ctrl,
   sesola_new,
   sesola_free,
};

/*****************************************************************************/
/*
*/

SeSoLaInit ()

{
   char  *cptr, *sptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SeSoLaInit()\n");

   fprintf (stdout, "%%%s-I-SSL, %s\n",
            Utility, SSLeay_version(SSLEAY_VERSION));

   /* command-line parameters, if none then use HTTPD$SSL_PARAMS */
   cptr = SeSoLaParams;
   if (!*cptr) cptr = getenv ("HTTPD$SSL_PARAMS");
   if (cptr == NULL) cptr = "";

   if (strsame (cptr, "/NOSSL", -1))
   {
      fprintf (stdout, "%%%s-W-SSL, disabled via /NOSSL\n", Utility);
      return;
   }

   while (*cptr)
   {
      while (*cptr && (*cptr == ',' || *cptr == ')')) cptr++;
      sptr = cptr;
      while (*cptr && *cptr != ',' && *cptr != ')') cptr++;
      if (*cptr) *cptr++ = '\0';
      if (!*sptr) break;
      if (Debug) fprintf (stdout, "sptr |%s|\n", sptr); 

      /* the 'digits' are for backward compatibility with pre-v6.0.0 */
      if (strsame (sptr, "2", -1))
         SeSoLaProtocolVersion |= SESOLA_PROTOCOL_SSLV2;
      else
      if (strsame (sptr, "3", -1))
         SeSoLaProtocolVersion |= SESOLA_PROTOCOL_SSLV3;
      else
      if (strsame (sptr, "23", -1))
         SeSoLaProtocolVersion |= SESOLA_PROTOCOL_SSLV2 |
                                  SESOLA_PROTOCOL_SSLV3;
      else
      if (strsame (sptr, "SSLv2", -1))
         SeSoLaProtocolVersion |= SESOLA_PROTOCOL_SSLV2;
      else
      if (strsame (sptr, "noSSLv2", -1))
         SeSoLaOptionsOff |= SSL_OP_NO_SSLv2;
      else
      if (strsame (sptr, "SSLv3", -1))
         SeSoLaProtocolVersion |= SESOLA_PROTOCOL_SSLV3;
      else
      if (strsame (sptr, "noSSLv3", -1))
         SeSoLaOptionsOff |= SSL_OP_NO_SSLv3;
      else
      if (strsame (sptr, "TLSv1", -1))
         SeSoLaProtocolVersion |= SESOLA_PROTOCOL_TLSV1;
      else
      if (strsame (sptr, "noTLSv1", -1))
         SeSoLaOptionsOff |= SSL_OP_NO_TLSv1;
      else
      if (strsame (sptr, "CERT=", 5))
         SeSoLaDefaultCertPtr = sptr + 5;
      else
      if (strsame (sptr, "CIPHER=", 7))
         SeSoLaDefaultCipherListPtr = sptr + 7;
      else
      if (strsame (sptr, "CACHE=", 6))
         SeSoLaSessionCacheSize = atoi(sptr+6);
      else
      if (strsame (sptr, "KEY=", 4))
         SeSoLaDefaultKeyPtr = sptr + 4;
      else
      if (strsame (sptr, "OPTIONS=", 8))
      {
         if (strsame (sptr+8, "ALL", -1))
            SeSoLaOptions = -1;
         else
            SeSoLaOptions = strtol (sptr+8, NULL, 16);
      }
      else
      {
         fprintf (stdout, "%%%s-E-SSL, unknown SSL parameter\n \\%s\\\n",
                  Utility, sptr);
         exit (STS$K_ERROR | STS$M_INHIB_MSG);
      }
   }

   /* default is to support both SSL v2 and v3 */
   if (!(SeSoLaProtocolVersion & SESOLA_PROTOCOL_SSLV2) &&
       !(SeSoLaProtocolVersion & SESOLA_PROTOCOL_SSLV3) &&
       !(SeSoLaProtocolVersion & SESOLA_PROTOCOL_TLSV1))
      SeSoLaProtocolVersion = SESOLA_PROTOCOL_SSLV2 |
                              SESOLA_PROTOCOL_SSLV3;

   if ((SeSoLaProtocolVersion & SESOLA_PROTOCOL_SSLV2) &&
       (SeSoLaProtocolVersion & SESOLA_PROTOCOL_SSLV3))
      SeSoLaProtocolsPtr = "SSLv2/v3";
   else
   if (SeSoLaProtocolVersion & SESOLA_PROTOCOL_SSLV2)
      SeSoLaProtocolsPtr = "SSLv2";
   else
   if (SeSoLaProtocolVersion & SESOLA_PROTOCOL_SSLV3)
      SeSoLaProtocolsPtr = "SSLv3";
   else
   if (SeSoLaProtocolVersion & SESOLA_PROTOCOL_TLSV1)
      SeSoLaProtocolsPtr = "TLSv1";
   fprintf (stdout, "%%%s-I-SSL, protocol(s) %s\n",
            Utility, SeSoLaProtocolsPtr);

   /* default session cache size */
   if (!SeSoLaSessionCacheSize)
      SeSoLaSessionCacheSize = DEFAULT_SESSION_CACHE_SIZE;

   SSL_load_error_strings ();

   SSL_library_init (); 

   ProtocolHttpsAvailable = true;

   if (SeSoLaDefaultCertPtr == NULL)
      SeSoLaDefaultCertPtr = getenv ("HTTPD$SSL_CERT");

   if (SeSoLaDefaultKeyPtr == NULL)
      SeSoLaDefaultKeyPtr = getenv ("HTTPD$SSL_KEY");

   if (SeSoLaDefaultCipherListPtr == NULL)
      SeSoLaDefaultCipherListPtr = getenv ("HTTPD$SSL_CIPHER");

   SesolaBioMemPtr = BIO_new (BIO_s_mem());
   if (SesolaBioMemPtr == NULL)
   {
      fprintf (stdout, "%%%s-E-SSL, BIO_new(BIO_s_mem()) failed\n", Utility);
      exit (STS$K_ERROR | STS$M_INHIB_MSG);
   }
}

/*****************************************************************************/
/*
Scan through the list of services initializing an SSL context for each SSL
service.
*/

BOOL SeSoLaInitService
(
struct ServiceStruct *svptr,
struct ServiceStruct *csvptr
)
{
   BOOL  CipherListSupplied,
         KeySupplied;
   int  value;
   char  *cptr, *sptr, *zptr;
   SSL_CTX  *SeSoLaCtx;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SeSoLaInitService()\n");

   if (csvptr != NULL)
   {
      /* initialize this new service by "cloning" a "fallback" one */
      if (csvptr->SeSoLaCtx == NULL)
      {
         fprintf (stdout, "-%s-W-SSL, service %s not initialized\n",
                  Utility, svptr->ServerHostPort);
         return (false);
      }
      svptr->SeSoLaCtx = csvptr->SeSoLaCtx;
      svptr->SeSoLaCertPtr = csvptr->SeSoLaCertPtr;
      svptr->SeSoLaKeyPtr = csvptr->SeSoLaKeyPtr;
      svptr->SeSoLaCipherListPtr = csvptr->SeSoLaCipherListPtr;
      return (true);
   }

   fprintf (stdout, "%%%s-I-SSL, %s\n", Utility, svptr->ServerHostPort);

   if (svptr->SSLcert[0])
      svptr->SeSoLaCertPtr = svptr->SSLcert;
   else
   {
      if (SeSoLaDefaultCertPtr == NULL)
      {
         fprintf (stdout,
"-%s-W-SSL, default certificate not specified\n\
-%s-W-SSL, service not configured\n",
                  Utility, Utility);
         return (false);
      }
      svptr->SeSoLaCertPtr = SeSoLaDefaultCertPtr;
   }

   if (svptr->SSLkey[0])
   {
      KeySupplied = true;
      svptr->SeSoLaKeyPtr = svptr->SSLkey;
   }
   else
   {
      if (svptr->SSLcert[0])
      {
         /* service has a specific certificate, assume the key's in that */
         svptr->SeSoLaKeyPtr = svptr->SSLcert;
      }
      else
      if (SeSoLaDefaultKeyPtr == NULL)
      {
         /* if no default key then assume it's in the certificate file */
         KeySupplied = false;
         svptr->SeSoLaKeyPtr = SeSoLaDefaultCertPtr;
      }
      else
      {
         /* use the separately specified key */
         svptr->SeSoLaKeyPtr = SeSoLaDefaultKeyPtr;
      }
   }

   if (svptr->SSLcipherList[0])
   {
      CipherListSupplied = true;
      svptr->SeSoLaCipherListPtr = svptr->SSLcipherList;
   }
   else
   {
      if (SeSoLaDefaultCipherListPtr == NULL)
      {
         CipherListSupplied = false;
         svptr->SeSoLaCipherListPtr = "";
      }
      else
      {
         CipherListSupplied = true;
         svptr->SeSoLaCipherListPtr = SeSoLaDefaultCipherListPtr;
      }
   }

   fprintf (stdout, "-%s-I-CERT, %s\n", Utility, svptr->SeSoLaCertPtr);

   if (KeySupplied)
      fprintf (stdout, "-%s-I-KEY, %s\n", Utility, svptr->SeSoLaKeyPtr);

   if (CipherListSupplied)
      fprintf (stdout, "-%s-I-CIPHER, %s\n",
               Utility, svptr->SeSoLaCipherListPtr);

   if ((SeSoLaProtocolVersion & SESOLA_PROTOCOL_SSLV2) &&
       (SeSoLaProtocolVersion & SESOLA_PROTOCOL_SSLV3))
      SeSoLaCtx = SSL_CTX_new (SSLv23_server_method());
   else
   if (SeSoLaProtocolVersion & SESOLA_PROTOCOL_SSLV2)
      SeSoLaCtx = SSL_CTX_new (SSLv2_server_method());
   else
   if (SeSoLaProtocolVersion & SESOLA_PROTOCOL_SSLV3)
      SeSoLaCtx = SSL_CTX_new (SSLv3_server_method());
   else
   if (SeSoLaProtocolVersion & SESOLA_PROTOCOL_TLSV1)
      SeSoLaCtx = SSL_CTX_new (TLSv1_server_method());

   if (SeSoLaCtx == NULL)
   {
      SeSoLaPrintOpenSslErrorList ();
      ErrorExitVmsStatus (0, "SSL_CTX_new()", FI_LI);
   }

   value = SSL_CTX_use_certificate_chain_file (SeSoLaCtx,
                                               svptr->SeSoLaCertPtr);
   if (!value)
   {
      SeSoLaPrintOpenSslErrorList ();
      fprintf (stdout, "-%s-W-SSL, service not configured\n", Utility);
      return (false);
   }

   value = SSL_CTX_use_RSAPrivateKey_file (SeSoLaCtx,
                                           svptr->SeSoLaKeyPtr,
                                           SSL_FILETYPE_PEM);
   if (!value)
   {
      SeSoLaPrintOpenSslErrorList ();
      fprintf (stdout, "-%s-W-SSL, service not configured\n", Utility);
      return (false);
   }

   value = SSL_CTX_check_private_key (SeSoLaCtx);
   if (!value)
   {
      SeSoLaPrintOpenSslErrorList ();
      fprintf (stdout, "-%s-W-SSL, service not configured\n", Utility);
      return (false);
   }

   if (svptr->SeSoLaCipherListPtr[0])
      SSL_CTX_set_cipher_list (SeSoLaCtx, svptr->SeSoLaCipherListPtr);

   if (SeSoLaSessionCacheSize)
      SSL_CTX_sess_set_cache_size (SeSoLaCtx, SeSoLaSessionCacheSize);

   /* see [.APPS]S_SERVER.C */
   SSL_CTX_set_quiet_shutdown (SeSoLaCtx, 1);

   /* for option values, see [.INCLUDE.OPENSSL]SSL.H */
   if (SeSoLaOptions)
   {
      fprintf (stdout, "-%s-W-SSL, options 0x%08.08x\n",
               Utility, SeSoLaOptions);
      SSL_CTX_set_options (SeSoLaCtx, SeSoLaOptions);
   }
   else
   {
      /* see [.APPS]S_SERVER.C */
      SSL_CTX_set_options (SeSoLaCtx, SSL_OP_ALL);
      SSL_CTX_set_options (SeSoLaCtx, SeSoLaOptionsOff);
      /* no longer an option in v0.9.5 */
      /** SSL_CTX_set_options (SeSoLaCtx, SSL_OP_NON_EXPORT_FIRST); **/
   }

   (SSL_CTX*)svptr->SeSoLaCtx = SeSoLaCtx;

   return (true);
}

/*****************************************************************************/
/*
Print out the OpenSSL error list.  For reporting errors associated with
certificate loading.  Based on [.CRYPTO.ERR]ERR_PRN.C.
*/

SeSoLaPrintOpenSslErrorList ()

{
   int  LineNumber,
        Flags;
   unsigned long  ErrorNumber;
   char  *FileNamePtr,
         *DataStringPtr;
   char  Buffer [200];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SeSoLaPrintOpenSslErrorList()\n");

   while (ErrorNumber =
          ERR_get_error_line_data (&FileNamePtr, &LineNumber,
                                   &DataStringPtr, &Flags))
   {
      fprintf (stdout, "-%s-W-SSL, \"%s\" (%s %d)%s%s%s\n",
               Utility,
               ERR_error_string (ErrorNumber, Buffer),
               FileNamePtr, LineNumber,
               ((Flags & ERR_TXT_STRING) ? " \"" : ""),
               ((Flags & ERR_TXT_STRING) ? DataStringPtr : ""),
               ((Flags & ERR_TXT_STRING) ? "\"" : ""));
   }
}

/*****************************************************************************/
/*
Begin an SSL transaction for a request. Create the SESOLA structure used to
store HTTPd SSL-related used during the transaction, initialize the OpenSSL
structures required, then begin the OpenSSL accept functionality.
*/

SeSoLaBegin (struct RequestStruct *rqptr)

{
   static int  RandSeedCount = 0;

   int  value;
   struct SeSoLaStruct  *sesolaptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SeSoLaBegin() %d\n", rqptr);

   if (rqptr->ServicePtr->SeSoLaCtx == NULL)
   {
      ErrorNoticed (0, "SeSoLaCtx == NULL", FI_LI);
      return;
   }

   /* note that this IS NOT HEAP memory, and must be explicitly VmFree()d */
   rqptr->SeSoLaPtr = sesolaptr =
      (struct SeSoLaStruct*)VmGet (sizeof(struct SeSoLaStruct));

   sesolaptr->SeSoLaCtx = (SSL_CTX*)rqptr->ServicePtr->SeSoLaCtx;

   /* set the SeSoLa structure request pointer */
   sesolaptr->rqptr = rqptr;

   /*
      Fairly efficient and probably an adequate PRNG.
      Comprises the request time structure (62 bytes),
      and a varying portion of the accounting structure (~200 bytes).
   */
   RAND_seed (((char*)&rqptr->rqTime), sizeof(rqptr->rqTime));
   RAND_seed (((char*)&Accounting)+(RandSeedCount++ & 0x7f),
              sizeof(Accounting) - 0x7f);
   if (Debug)
      fprintf (stdout, "accounting RAND_seed(%d,%d)\n",
               ((char*)&Accounting)+(RandSeedCount&0x7f),
               sizeof(Accounting)-0x7f);

   if (Debug) fprintf (stdout, "SSL_new()\n");
   sesolaptr->SslPtr = SSL_new (sesolaptr->SeSoLaCtx);
   if (sesolaptr->SslPtr == NULL)
   {
      fprintf (stdout, "%%%s-W-SSL, SSL_new(sesolaptr->SeSoLaCtx) failed\n",
               Utility);
      SeSoLaFree (rqptr);

      if (rqptr->WatchItem &&
          (WatchEnabled & WATCH_SESOLA))
         WatchThis (rqptr, FI_LI, WATCH_SESOLA, "BEGIN failed");

      return;
   }

   if (Debug) fprintf (stdout, "BIO_new()\n");
   sesolaptr->BioPtr = BIO_new (BIO_s_sesola());
   if (sesolaptr->BioPtr == NULL)
   {
      fprintf (stdout, "%%%s-W-SSL, BIO_new(BIO_s_sesola()) failed\n",
               Utility);
      SeSoLaFree (rqptr);

      if (rqptr->WatchItem &&
          (WatchEnabled & WATCH_SESOLA))
         WatchThis (rqptr, FI_LI, WATCH_SESOLA, "BEGIN failed");

      return;
   }
   /* set the "BIO_s_sesola" pointer to the SESOLA structure */
   sesolaptr->BioPtr->ptr = sesolaptr;

   /* set up the SSL filter */
   if (Debug) fprintf (stdout, "BIO_new()\n");
   sesolaptr->BioSslPtr = BIO_new (BIO_f_ssl());
   if (sesolaptr->BioSslPtr == NULL)
   {
      fprintf (stdout, "%%%s-W-SSL, BIO_new(BIO_f_ssl()) failed\n", Utility);
      SeSoLaFree (rqptr);

      if (rqptr->WatchItem &&
          (WatchEnabled & WATCH_SESOLA))
         WatchThis (rqptr, FI_LI, WATCH_SESOLA, "BEGIN failed");

      return;
   }

   SSL_set_bio (sesolaptr->SslPtr, sesolaptr->BioPtr, sesolaptr->BioPtr);

   SSL_set_accept_state (sesolaptr->SslPtr);

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_SESOLA))
   {
      WatchThis (rqptr, FI_LI, WATCH_SESOLA, "BEGIN");
      /* set the request pointer as the first item of SSL user data */
      SSL_set_ex_data (sesolaptr->SslPtr, 0, rqptr);
      /* set for SSL information and verification callback */
      SSL_CTX_set_info_callback (sesolaptr->SslPtr, &SesolaWatchInfoCallback);
      /* set for BIO callback with the request pointer as it's argurment */
      BIO_set_callback (sesolaptr->BioPtr, &SesolaWatchBioCallback);
      BIO_set_callback_arg (sesolaptr->BioPtr, rqptr);
   }

   /* begin the SSL handshake */
   sesolaptr->SSL_accepted = false;
   SeSoLaAccept (rqptr);
}

/*****************************************************************************/
/*
Shutdown the SSL session with the client (via an SSL alert that we don't wait
around for a response on!)  Return true if RequestEnd() can continue
the request run-down, false if has to abort and wait for some more to happen!
*/

SeSoLaEnd (struct RequestStruct *rqptr)

{
   int  value;
   struct SeSoLaStruct  *sesolaptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SeSoLaEnd() %d\n", rqptr);

   /* the 'rqptr->SeSoLaPtr' is typeless! */
   if ((sesolaptr = (struct SeSoLaStruct*)rqptr->SeSoLaPtr) == NULL) return;

   /* "quiet" shutdown, see [.APPS]S_SERVER.C */
   SSL_set_shutdown (sesolaptr->SslPtr,
                     SSL_SENT_SHUTDOWN | SSL_RECEIVED_SHUTDOWN);

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_SESOLA))
      WatchThis (rqptr, FI_LI, WATCH_SESOLA, "END");

   SeSoLaFree (rqptr);

   RequestEnd (rqptr);
}

/*****************************************************************************/
/*
Free the OpenSSL structures outside of any use of them (early mistake)!
*/

BOOL SeSoLaFree (struct RequestStruct *rqptr)

{
   int  value;
   struct SeSoLaStruct  *sesolaptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SeSoLaFree() %d\n", rqptr);

   /* the 'rqptr->SeSoLaPtr' is typeless! */
   if ((sesolaptr = (struct SeSoLaStruct*)rqptr->SeSoLaPtr) == NULL) return;

   if (sesolaptr->SslPtr != NULL)
   {
      SSL_free (sesolaptr->SslPtr);
      sesolaptr->BioPtr == NULL;
   }
   if (sesolaptr->BioPtr != NULL) BIO_free (sesolaptr->BioPtr);

   /* request has finished with the SESOLA structure */
   VmFree (sesolaptr, FI_LI);
   rqptr->SeSoLaPtr = NULL;
}

/*****************************************************************************/
/*
This establishes the SSL transaction by providing the server "hello",
certificate and key exchange, etc. Due to the non-blocking I/O used by WASD
this function will be called multiple times to complete the OpenSSL accept. 
*/

SeSoLaAccept (struct RequestStruct *rqptr)

{
   int  status,
        value;
   struct SeSoLaStruct  *sesolaptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SeSoLaAccept() %d\n", rqptr);

   /* the 'rqptr->SeSoLaPtr' is typeless! */
   sesolaptr = (struct SeSoLaStruct*)rqptr->SeSoLaPtr;

   sesolaptr->ReadType = sesolaptr->WriteType = SESOLA_ACCEPT;

   if (++sesolaptr->AcceptCount == 2)
   {
      /* just finished the first lot of non-blocking I/O */
      if (!memcmp (sesolaptr->AcceptReadDataPtr, "GET ", 4) ||
          !memcmp (sesolaptr->AcceptReadDataPtr, "HEAD ", 5) ||
          !memcmp (sesolaptr->AcceptReadDataPtr, "POST ", 5) ||
          !memcmp (sesolaptr->AcceptReadDataPtr, "PUT ", 4) ||
          !memcmp (sesolaptr->AcceptReadDataPtr, "DELETE ", 7))
      {
         /* looks like it's a standard HTTP request on the wrong port! */
         rqptr->rqResponse.HttpStatus = 400;
         ErrorGeneral (rqptr, ErrorSslPort, FI_LI);
         SeSoLaFree (rqptr);
         RequestEnd (rqptr);
         return;
      }
   }

   value = SSL_accept (sesolaptr->SslPtr);
   if (Debug) fprintf (stdout, "SSL_accept() %d\n", value);

   /* if non-blocking IO in progress just return and wait for delivery */
   if (sesolaptr->ReadInProgress || sesolaptr->WriteInProgress) return;

   if (value > 0)
   {
      /***********/
      /* success */
      /***********/

      if (rqptr->WatchItem &&
          (WatchEnabled & WATCH_SESOLA))
         SesolaWatchSession (rqptr);

      sesolaptr->SSL_accepted = true;

      rqptr->rqNet.ReadBufferPtr = VmGetHeap (rqptr, NetReadBufferSize);
      rqptr->rqNet.ReadBufferSize = NetReadBufferSize;

      NetRead (rqptr, &RequestGet,
               rqptr->rqNet.ReadBufferPtr, rqptr->rqNet.ReadBufferSize);

      return;
   } 

   /*********/
   /* error */
   /*********/

   if (Debug) ERR_print_errors_fp (stdout);

   /* error, end of request */
   SeSoLaFree (rqptr);
   RequestEnd (rqptr);
}

/*****************************************************************************/
/*
Read application data. This is the equivalent of the general NetRead() function
(and is indeed called from it) in that it reads data from the client via the
network. This function uses SSL_read() to read a stream of encrypted data from
the network then provide it decrypted in the supplied buffer.  This function
provides BLOCKING (non-AST) and NON-BLOCKING I/O conforming to the
functionality provided by NetRead(). The network read I/O status block status
and count fields are valid for the high-level calling routine.
*/

SeSoLaRead
(
struct RequestStruct *rqptr,
void *AstFunctionPtr,
char *DataPtr,
int DataSize
)
{
   int  value;
   struct SeSoLaStruct  *sesolaptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SeSoLaRead() %d %d\n", rqptr, AstFunctionPtr);

   /* the 'rqptr->SeSoLaPtr' is typeless! */
   sesolaptr = (struct SeSoLaStruct*)rqptr->SeSoLaPtr;

   if ((sesolaptr->ReadAstFunctionPtr = AstFunctionPtr) == NULL)
      sesolaptr->ReadType = SESOLA_DATA_BLOCKING;
   else
      sesolaptr->ReadType = SESOLA_DATA_NON_BLOCKING;

   value = SSL_read (sesolaptr->SslPtr,
                     sesolaptr->ReadDataPtr = DataPtr,
                     sesolaptr->ReadDataSize = DataSize);
   if (Debug) fprintf (stdout, "SSL_read() %d\n", value);

   /* if non-blocking IO in progress just return and wait for delivery */
   if (sesolaptr->ReadInProgress) return (SS$_NORMAL);

   /* set the I/O status block count to reflect the decrypted data count */
   if (VMSok (rqptr->rqNet.ReadIOsb.Status))
   {
      /* zero returned if received SSL shutdown */
      if (value > 0)
         rqptr->rqNet.ReadIOsb.Count = value;
      else
      {
         rqptr->rqNet.ReadIOsb.Status = SS$_ABORT;
         rqptr->rqNet.ReadIOsb.Count = 0;
         /* let it believe it's now shutdown!  see [.APPS]S_SERVER.C */
         SSL_set_shutdown (sesolaptr->SslPtr,
                           SSL_SENT_SHUTDOWN | SSL_RECEIVED_SHUTDOWN);
      }
   }
   else
   {
      rqptr->rqNet.ReadIOsb.Count = DataSize;
      /* let it believe it's now shutdown!  see [.APPS]S_SERVER.C */
      SSL_set_shutdown (sesolaptr->SslPtr,
                        SSL_SENT_SHUTDOWN | SSL_RECEIVED_SHUTDOWN);
   }

   if (AstFunctionPtr == NULL) return (rqptr->rqNet.ReadIOsb.Status);

   SysDclAst (AstFunctionPtr, rqptr);

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Write application data. This is the equivalent of the general NetWrite()
function (and is called from it) in that it writes data to the client via the
network. This function uses SSL_write() to write non-encrypted application data
to the network in encrypted form. This function provides BLOCKING (non-AST)
and NON-BLOCKING I/O conforming to the functionality provided by NetWrite().
The network write I/O status block status and count fields are valid for the
high-level calling routine.
*/

int SeSoLaWrite
(
struct RequestStruct *rqptr,
void *AstFunctionPtr,
char *DataPtr,
int DataLength
)
{
   int  value;
   struct SeSoLaStruct  *sesolaptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "SeSoLaWrite() %d %d %d %d\n",
               rqptr, AstFunctionPtr, DataPtr, DataLength);
   /** fprintf (stdout, "|%*.*s|\n", DataLength, DataLength, DataPtr); **/

   /* the 'rqptr->SeSoLaPtr' is typeless! */
   sesolaptr = (struct SeSoLaStruct*)rqptr->SeSoLaPtr;

   if ((sesolaptr->WriteAstFunctionPtr = AstFunctionPtr) == NULL)
      sesolaptr->WriteType = SESOLA_DATA_BLOCKING;
   else
      sesolaptr->WriteType = SESOLA_DATA_NON_BLOCKING;

   value = SSL_write (sesolaptr->SslPtr,
                      sesolaptr->WriteDataPtr = DataPtr,
                      sesolaptr->WriteDataLength = DataLength);
   if (Debug) fprintf (stdout, "SSL_write() %d\n", value);

   /* if non-blocking IO in progress just return and wait for delivery */
   if (sesolaptr->WriteInProgress) return (SS$_NORMAL);

   /* set the I/O status block count to reflect the decrypted data count */
   if (VMSok (rqptr->rqNet.WriteIOsb.Status))
      rqptr->rqNet.WriteIOsb.Count = value;
   else
   {
      rqptr->rqNet.WriteIOsb.Count = 0;
      /* let it believe it's now shutdown!  see [.APPS]S_SERVER.C */
      SSL_set_shutdown (sesolaptr->SslPtr,
                        SSL_SENT_SHUTDOWN | SSL_RECEIVED_SHUTDOWN);
   }

   if (AstFunctionPtr == NULL) return (rqptr->rqNet.WriteIOsb.Status);

   SysDclAst (AstFunctionPtr, rqptr);

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Provides OpenSSL status information at various states of SSL processing via the
WATCH facility.
*/

SesolaWatchInfoCallback
(
SSL *SslPtr,
int WhereExactly,
int Value
)
{
   int  WhereGenerally;
   char  *cptr;
   struct  RequestStruct  *rqptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SesolaWatchInfoCallback()\n");

   rqptr = (struct RequestStruct*)SSL_get_ex_data (SslPtr, 0);

   WhereGenerally = WhereExactly & ~SSL_ST_MASK;

   if (WhereGenerally & SSL_ST_CONNECT)
      cptr = "SSL_CONNECT";
   else
   if (WhereGenerally & SSL_ST_ACCEPT)
      cptr = "SSL_ACCEPT";
   else
      cptr = "UNDEFINED";

   if (WhereExactly & SSL_CB_LOOP)
      WatchThis (rqptr, FI_LI, WATCH_SESOLA,
                 "!AZ !AZ", cptr, SSL_state_string_long(SslPtr));
   else
   if (WhereExactly & SSL_CB_ALERT)
   {
      cptr = (WhereExactly & SSL_CB_READ) ? "read" : "write";
      WatchThis (rqptr, FI_LI, WATCH_SESOLA,
                 "!AZ SSL3 alert !AZ:!AZ",
                 cptr, SSL_alert_type_string_long(Value),
                 SSL_alert_desc_string_long(Value));
   }
   else
   if (WhereExactly & SSL_CB_EXIT)
   {
      if (Value == 0)
         WatchThis (rqptr, FI_LI, WATCH_SESOLA,
                    "!AZ SSL3 alert failed in !AZ",
                    cptr, SSL_state_string_long(SslPtr));
      else
      if (Value < 0)
         WatchThis (rqptr, FI_LI, WATCH_SESOLA,
                    "!AZ error in !AZ",
                    cptr, SSL_state_string_long(SslPtr));
   }
}

/*****************************************************************************/
/*
Provides OpenSSL Input/Output information each time an SSL read or write occurs
via the WATCH facility.
*/

int SesolaWatchBioCallback
(
BIO *bioptr,
int cmd,
char *argp,
int argi,
long argl,
long retval
)
{
   struct  RequestStruct  *rqptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SesolaWatchBioCallback()\n");

   rqptr = (struct RequestStruct*) BIO_get_callback_arg (bioptr);

   if (cmd == (BIO_CB_READ | BIO_CB_RETURN))
   {
      if (retval == -1)
         WatchThis (rqptr, FI_LI, WATCH_SESOLA,
                    "READ !UL bytes non-blocking", argi);
      else
         WatchThis (rqptr, FI_LI, WATCH_SESOLA,
                    "READ !UL bytes done", retval);
      return (retval);
   }
   else
   if (cmd == (BIO_CB_WRITE | BIO_CB_RETURN))
   {
      if (retval == -1)
         WatchThis (rqptr, FI_LI, WATCH_SESOLA,
                    "WRITE !UL bytes non-blocking", argi);
      else
         WatchThis (rqptr, FI_LI, WATCH_SESOLA,
                    "WRITE !UL bytes done", retval);
      return (retval);
   }

   return (retval);
}

/*****************************************************************************/
/*
Provide WATCH information after final SSL session establishment show version
and cipher in use.
*/

SeSoLaWatchSession (struct RequestStruct *rqptr)

{
   int  AlgKeySize,
        UseKeySize;
   char  *CipherNamePtr,
         *VersionNamePtr;
   struct SeSoLaStruct  *sesolaptr;
   SSL  *SslPtr;
   SSL_CIPHER  *CipherPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SeSoLaWatchSession()\n");

   /* the 'rqptr->SeSoLaPtr' is typeless! */
   sesolaptr = (struct SeSoLaStruct*)rqptr->SeSoLaPtr;

   SslPtr = sesolaptr->SslPtr;
   CipherPtr = SSL_get_current_cipher (SslPtr);

   if ((VersionNamePtr = SSL_get_version (SslPtr)) == NULL)
      VersionNamePtr = "(null)";
   if ((CipherPtr = SSL_get_current_cipher (SslPtr)) == NULL)
   {
      CipherNamePtr = "(null)";
      AlgKeySize = UseKeySize = 0;
   }
   else
   {
      CipherNamePtr = SSL_CIPHER_get_name (CipherPtr);
      UseKeySize = SSL_CIPHER_get_bits(CipherPtr, &AlgKeySize);
   }

   WatchThis (rqptr, FI_LI, WATCH_SESOLA,
              "SESSION cached:!AZ protocol:!AZ cipher:!AZ keysize:!UL/!UL",
              SslPtr->hit ? "yes" : "no",
              VersionNamePtr, CipherNamePtr, UseKeySize, AlgKeySize);
}

/*****************************************************************************/
/*
Peek at selected SeSoLaStruct data.  The 'rqptr' is the request doing the
peeking, the 'rqeptr' is the request being peeked at.
*/

SeSoLaWatchPeek
(
struct RequestStruct *rqptr,
struct RequestStruct *rqeptr
)
{
   static char  SeSoLaFao [] = 
"!33<->SSL_accept()ed!> !UL (protocol:!AZ cipher:!AZ keysize:!UL/!UL)\n\
!33<->ReadInProgress!> !UL\n\
!33<->ReadCompleted!> !UL\n\
!33<->WriteInProgress!> !UL\n\
!33<->WriteCompleted!> !UL\n\
\n";

   int  status,
        AlgKeySize,
        UseKeySize;
   unsigned short  Length;
   unsigned long  *vecptr;
   unsigned long  FaoVector [16];
   char  *CipherNamePtr,
         *VersionNamePtr;
   char  Buffer [2048];
   struct SeSoLaStruct  *sesolaptr;
   SSL  *SslPtr;
   SSL_CIPHER  *CipherPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SeSoLaWatchPeek()\n");

   if (rqeptr->SeSoLaPtr == NULL) return;

   /* the 'rqptr->SeSoLaPtr' is typeless! */
   sesolaptr = (struct SeSoLaStruct*)rqeptr->SeSoLaPtr;

   SslPtr = sesolaptr->SslPtr;
   if ((VersionNamePtr = SSL_get_version (SslPtr)) == NULL)
      VersionNamePtr = "(null)";
   if ((CipherPtr = SSL_get_current_cipher (SslPtr)) == NULL)
   {
      CipherNamePtr = "(null)";
      AlgKeySize = UseKeySize = 0;
   }
   else
   {
      CipherNamePtr = SSL_CIPHER_get_name (CipherPtr);
      UseKeySize = SSL_CIPHER_get_bits(CipherPtr, &AlgKeySize);
   }

   vecptr = FaoVector;
   *vecptr++ = sesolaptr->SSL_accepted;
   *vecptr++ = VersionNamePtr;
   *vecptr++ = CipherNamePtr;
   *vecptr++ = UseKeySize;
   *vecptr++ = AlgKeySize;
   *vecptr++ = sesolaptr->ReadInProgress;
   *vecptr++ = sesolaptr->ReadCompleted;
   *vecptr++ = sesolaptr->WriteInProgress;
   *vecptr++ = sesolaptr->WriteCompleted;

   status = WriteFaol (Buffer, sizeof(Buffer), &Length, SeSoLaFao, &FaoVector);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
      ErrorNoticed (status, "WriteFaol()", FI_LI);
   NetWrite (rqptr, 0, Buffer, Length);
}

/*****************************************************************************/
/*
Generate appropriate SSL-related CGI variables.
Called from CgiGenerateVariables().
*/ 

int SesolaCgiGenerateVariables
(
struct RequestStruct *rqptr,
int VarType
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "SesolaCgiGenerateVariables() %d\n",
               rqptr->rqPathSet.SSLCGIvar);

   if (rqptr->SeSoLaPtr == NULL) return (SS$_NORMAL);

   switch (rqptr->rqPathSet.SSLCGIvar)
   {
      case SESOLA_CGI_VAR_APACHE_MOD_SSL :
         return (SesolaCgiVariablesApacheModSsl (rqptr, VarType));
      case SESOLA_CGI_VAR_PURVEYOR :
         return (SesolaCgiVariablesPurveyor (rqptr, VarType));
      default :
         return (SS$_NORMAL);
   }
}

/*****************************************************************************/
/*
Generate some Apache mod_SSL style CGI variables.
*/ 

int SesolaCgiVariablesApacheModSsl
(
struct RequestStruct *rqptr,
int VarType
)
{
   static char  HexDigits [] = "0123456789abcdef";
   static $DESCRIPTOR (NumberFaoDsc, "!UL\0");

   int  cnt, status,
        AlgKeySize,
        ObjNid,
        UseKeySize;
   char  *cptr, *crptr, *sptr, *zptr,
         *CurrentRecordPtr;
   char  CertFingerprint [64],
         String [512],
         VariableName [64],
         VariableValue [256];
   $DESCRIPTOR (StringDsc, String);
   $DESCRIPTOR (VariableNameDsc, VariableName);
   struct SeSoLaStruct  *sesolaptr;
   struct SesolaCertDnRecStruct  *cdnptr;
   SSL  *SslPtr;
   SSL_CIPHER  *CipherPtr;
   SSL_SESSION  *SessionPtr;
   X509  *ClientCertPtr,
         *ServerCertPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SesolaCgiVariablesApacheModSsl()\n");

   sesolaptr = (struct SeSoLaStruct*)rqptr->SeSoLaPtr;
   SslPtr = sesolaptr->SslPtr;
   SessionPtr = SSL_get_session (SslPtr);
   CipherPtr = SSL_get_current_cipher (SslPtr);
   ServerCertPtr = SSL_get_certificate (SslPtr);

   /***************/
   /* basic stuff */
   /***************/

   if (VMSnok (status =
       CgiVariable (rqptr, "HTTPS", "true", VarType)))
      return (status);

   cptr = SSL_get_version (SslPtr);
   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_PROTOCOL", cptr, VarType)))
      return (status);

   zptr = (sptr = String) + sizeof(String)-1;
   for (cnt = 0; cnt < SessionPtr->session_id_length; cnt++)
   {
      if (sptr >= zptr) break;
      *sptr++ = HexDigits[(SessionPtr->session_id[cnt] >> 4) & 0x0f];
      if (sptr >= zptr) break;
      *sptr++ = HexDigits[SessionPtr->session_id[cnt] & 0x0f];
   }
   *sptr = '\0';
   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_SESSION_ID", String, VarType)))
      return (status);

   /* data structure in [.SSL]SSL.H */
   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_CIPHER", CipherPtr->name, VarType)))
      return (status);

   UseKeySize = SSL_CIPHER_get_bits(CipherPtr, &AlgKeySize);

   /* same as "mod_SSL" v2.5 */
   if (UseKeySize < 56)
      if (VMSnok (status =
          CgiVariable (rqptr, "SSL_CIPHER_EXPORT", "true", VarType)))
         return (status);

   sys$fao (&NumberFaoDsc, 0, &StringDsc, UseKeySize);
   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_CIPHER_USEKEYSIZE", String, VarType)))
      return (status);

   sys$fao (&NumberFaoDsc, 0, &StringDsc, AlgKeySize);
   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_CIPHER_ALGKEYSIZE", String, VarType)))
      return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_VERSION_INTERFACE",
                            APACHE_MOD_SSL_VERSION_INTERFACE, VarType)))
      return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_VERSION_LIBRARY",
                    SSLeay_version(SSLEAY_VERSION), VarType)))
      return (status);

   /****************/
   /* client stuff */
   /****************/

   /* not supported in this version */

   /****************/
   /* server stuff */
   /****************/

   sys$fao (&NumberFaoDsc, 0, &StringDsc, X509_get_version(ServerCertPtr)+1);
   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_SERVER_M_VERSION", String, VarType)))
      return (status);

   i2a_ASN1_INTEGER (SesolaBioMemPtr, X509_get_serialNumber(ServerCertPtr));
   BIO_gets (SesolaBioMemPtr, String, sizeof(String));
   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_SERVER_M_SERIAL", String, VarType)))
      return (status);

   X509_NAME_oneline (X509_get_subject_name(ServerCertPtr),
                      String, sizeof(String));
   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_SERVER_S_DN", String, VarType)))
      return (status);

   sptr = VariableName;
   for (cptr = "SSL_SERVER_S_DN_"; *cptr; *sptr++ = *cptr++);
   cptr = String;
   while (*cptr)
   {
      while (*cptr && *cptr != '/') cptr++;
      if (!*cptr) break;
      crptr = cptr;
      for (cdnptr = &SesolaCertDnRec; cdnptr->name != NULL; cdnptr++)
         if (!strncmp (cptr, cdnptr->name, cdnptr->length)) break;
      cptr++;
      if (cdnptr->name == NULL) continue;
      zptr = (sptr = VariableName+16) + sizeof(VariableName)-17;
      while (*cptr && *cptr != '=' && sptr < zptr) *sptr++ = *cptr++;
      if (!*cptr) break;
      cptr++;
      *sptr = '\0';
      zptr = (sptr = VariableValue) + sizeof(VariableValue)-1;
      while (*cptr)
      {
         while (*cptr && *cptr != '/' && sptr < zptr) *sptr++ = *cptr++;
         if (!*cptr) break;
         /* look ahead to make sure the "/" begins a recognised record */
         for (cdnptr = &SesolaCertDnRec; cdnptr->name != NULL; cdnptr++)
            if (!strncmp (cptr, cdnptr->name, cdnptr->length)) break;
         if (cdnptr->name != NULL)
         {
            /* break if it's not another line of the same component */
            if (strncmp (crptr, cdnptr->name, cdnptr->length))
               break;
            cptr += cdnptr->length;
            if (sptr < zptr) *sptr++ = '\n';
         }
         if (*cptr && sptr < zptr) *sptr++ = *cptr++;
      }
      *sptr = '\0';
      if (VMSnok (status =
          CgiVariable (rqptr, VariableName, VariableValue, VarType)))
         return (status);
   }

   X509_NAME_oneline (X509_get_issuer_name(ServerCertPtr),
                      String, sizeof(String));
   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_SERVER_I_DN", String, VarType)))
      return (status);

   sptr = VariableName;
   for (cptr = "SSL_SERVER_I_DN_"; *cptr; *sptr++ = *cptr++);
   cptr = String;
   while (*cptr)
   {
      while (*cptr && *cptr != '/') cptr++;
      if (!*cptr) break;
      crptr = cptr;
      for (cdnptr = &SesolaCertDnRec; cdnptr->name != NULL; cdnptr++)
         if (!strncmp (cptr, cdnptr->name, cdnptr->length)) break;
      cptr++;
      if (cdnptr->name == NULL) continue;
      zptr = (sptr = VariableName+16) + sizeof(VariableName)-17;
      while (*cptr && *cptr != '=' && sptr < zptr) *sptr++ = *cptr++;
      if (!*cptr) break;
      cptr++;
      *sptr = '\0';
      zptr = (sptr = VariableValue) + sizeof(VariableValue)-1;
      while (*cptr)
      {
         while (*cptr && *cptr != '/' && sptr < zptr) *sptr++ = *cptr++;
         if (!*cptr) break;
         /* look ahead to make sure the "/" begins a recognised record */
         for (cdnptr = &SesolaCertDnRec; cdnptr->name != NULL; cdnptr++)
            if (!strncmp (cptr, cdnptr->name, cdnptr->length)) break;
         if (cdnptr->name != NULL)
         {
            /* break if it's not another line of the same component */
            if (strncmp (crptr, cdnptr->name, cdnptr->length))
               break;
            cptr += cdnptr->length;
            if (sptr < zptr) *sptr++ = '\n';
         }
         if (*cptr && sptr < zptr) *sptr++ = *cptr++;
      }
      *sptr = '\0';
      if (VMSnok (status =
          CgiVariable (rqptr, VariableName, VariableValue, VarType)))
         return (status);
   }

   ASN1_UTCTIME_print (SesolaBioMemPtr, X509_get_notBefore(ServerCertPtr));
   BIO_gets (SesolaBioMemPtr, String, sizeof(String));
   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_SERVER_V_START", String, VarType)))
      return (status);

   ASN1_UTCTIME_print (SesolaBioMemPtr, X509_get_notAfter(ServerCertPtr));
   BIO_gets (SesolaBioMemPtr, String, sizeof(String));
   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_SERVER_V_END", String, VarType)))
      return (status);

   ObjNid = OBJ_obj2nid (ServerCertPtr->cert_info->signature->algorithm);
   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_SERVER_A_SIG", 
          ObjNid == NID_undef ? "UNKNOWN" : OBJ_nid2ln(ObjNid), VarType)))
      return (status);

   ObjNid = OBJ_obj2nid (ServerCertPtr->cert_info->key->algor->algorithm);
   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_SERVER_A_KEY",
          ObjNid == NID_undef ? "UNKNOWN" : OBJ_nid2ln(ObjNid), VarType)))
      return (status);

#if APACHE_MOD_SSL_SERVER_CERT
   /*
      This variable is larger than can be support in a DCL symbol.
      It can be support in a CGIplus variable stream, but I imagine
      has a limited range of uses and so is not generated by default.
   */
   if (VarType == CGI_VARIABLE_STREAM)
   {
      PEM_write_bio_X509(SesolaBioMemPtr, ServerCertPtr);
      BIO_read (SesolaBioMemPtr, String, sizeof(String));
      if (VMSnok (status =
          CgiVariable (rqptr, "SSL_SERVER_CERT", String, VarType)))
         return (status);
   }
#endif

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Generate some Purveyor style SSL-related CGI variables.
*/ 

int SesolaCgiVariablesPurveyor
(
struct RequestStruct *rqptr,
int VarType
)
{
   static $DESCRIPTOR (NumberFaoDsc, "!UL\0");

   int  status,
        KeySize;
   char  String [512];
   char  *cptr;
   $DESCRIPTOR (StringDsc, String);
   struct SeSoLaStruct  *sesolaptr;
   SSL  *SslPtr;
   SSL_CIPHER  *CipherPtr;
   SSL_SESSION  *SessionPtr;
   X509  *ServerCertPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SesolaCgiVariablesPurveyor()\n");

   /* the 'rqptr->SeSoLaPtr' is typeless! */
   sesolaptr = (struct SeSoLaStruct*)rqptr->SeSoLaPtr;

   SslPtr = sesolaptr->SslPtr;
   SessionPtr = SSL_get_session (SslPtr);
   CipherPtr = SSL_get_current_cipher (SslPtr);
   ServerCertPtr = SSL_get_certificate (SslPtr);

   cptr = SSL_CIPHER_get_name (CipherPtr);
   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_CIPHER", cptr, VarType)))
      return (status);

   KeySize = SSL_CIPHER_get_bits (CipherPtr, NULL);
   sys$fao (&NumberFaoDsc, 0, &StringDsc, KeySize);
   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_CIPHER_KEYSIZE", String, VarType)))
      return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_CLIENT_DN", "NONE", VarType)))
      return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_CLIENT_CA", "NONE", VarType)))
      return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_CLIENT_AUTHENTICATED", "FALSE", VarType)))
      return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "SECURITY_STATUS", "SSL", VarType)))
      return (status);

   X509_NAME_oneline (X509_get_subject_name(ServerCertPtr),
                      String, sizeof(String));
   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_SERVER_DN", String, VarType)))
      return (status);

   X509_NAME_oneline (X509_get_issuer_name(ServerCertPtr),
                      String, sizeof(String));
   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_SERVER_CA", String, VarType)))
      return (status);

   cptr = SSL_get_version (SslPtr);
   if (VMSnok (status =
       CgiVariable (rqptr, "SSL_VERSION", cptr, VarType)))
      return (status);

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Brief report on this port's SSL context statistics and session information.
*/

SeSoLaReport
(
struct RequestStruct *rqptr,
void *NextTaskFunction
)
{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... SSL Report</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>SSL Report</H3>\n\
!20%W\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>!AZ</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>Version:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Build:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Protocol:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Certificate:</TH><TD>!AZ</TD></TR>\n\
<TR><TH></TH><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=2 BORDER=0>\n\
<TR><TH ALIGN=right VALIGN=top>Issuer:&nbsp;</TH><TD><PRE>!AZ</PRE></TD></TR>\n\
<TR><TH ALIGN=right VALIGN=top>Server:&nbsp;</TH><TD><PRE>!AZ</PRE></TD></TR>\n\
<TR><TH ALIGN=right>Expires:&nbsp;</TH><TD>!AZ</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Private Key:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Cipher List:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right VALIGN=top>Supported Ciphers:</TH><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0>\n\
<TR><TH></TH><TH ALIGN=left>Version</TH><TH ALIGN=left>Name</TH></TR>\n";

   static char  CiphersFao [] =
"<TR><TH ALIGN=right>!UL. &nbsp;</TH>\
<TD><TT>!AZ</TT> &nbsp;</TD>\
<TD><TT>!AZ</TT> &nbsp;</TD>\
</TR>\n";

   static char  CurrentSession1Fao [] =
"</TABLE>\n\
</TD></TR>\n\
<TR><TH ALIGN=right VALIGN=top>Service Accepts:</TH><TD VALIGN=top>\
<TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right>Total:</TH><TD ALIGN=left> &nbsp;!UL</TD></TR>\n\
<TR><TH ALIGN=right> &nbsp;Completed:</TH><TD ALIGN=left> &nbsp;!UL</TD></TR>\n\
</TABLE>\n\
<TR><TH ALIGN=right VALIGN=top>Session Cache:</TH><TD VALIGN=top>\
<TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right>Hits:</TH><TD ALIGN=left> &nbsp;!UL</TD></TR>\n\
<TR><TH ALIGN=right>Misses:</TH><TD ALIGN=left> &nbsp;!UL</TD></TR>\n\
<TR><TH ALIGN=right> &nbsp;Timeouts:</TH><TD ALIGN=left> &nbsp;!UL</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Current Session</TH></TR>\n\
<TR><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>Cache Hit:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Version:</TH><TD><TT>!AZ</TD></TT></TR>\n\
<TR><TH ALIGN=right VALIGN=top>Shared Ciphers:</TH><TD>";

   static char  SharedCipherFao [] =
"!AZ &nbsp;<B>!UL.</B> &nbsp;<TT>!AZ</TT>\n";

   static char  CurrentSession2Fao [] =
"</TD></TR>\n\
<TR><TH ALIGN=right>Session Cipher:</TH><TD><TT>!AZ</TT></TD></TR>\n\
<TR><TH ALIGN=right>Key Size:</TH><TD>!UL / !UL</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
</BODY>\n\
</HTML>\n";

   int  status,
        AlgKeySize,
        Count,
        Total,
        UseKeySize;
   char  *cptr, *sptr, *zptr;
   unsigned long  BinaryTime [2],
                  /* WARNING: really does need to be fairly large!! */
                  FaoVector [256],
                  ResultTime [2];
   unsigned long  *vecptr;
   char  CertString [256],
         CertCaString [256],
         CertDnString [256],
         CertNotAfterString [64],
         SharedCiphers [512];
   struct SeSoLaStruct  *sesolaptr;
   STACK  *StackPtr;
   SSL  *SslPtr;
   SSL_CIPHER  *CipherPtr;
   SSL_SESSION  *SessionPtr;
   X509  *ServerCertPtr;
   X509  *PeerPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SeSolaReport()\n");

   if (rqptr->ServicePtr->RequestScheme != SCHEME_HTTPS)
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, ErrorSslReportService, FI_LI);
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   /* the 'rqptr->SeSoLaPtr' is typeless! */
   sesolaptr = (struct SeSoLaStruct*)rqptr->SeSoLaPtr;

   SslPtr = sesolaptr->SslPtr;
   ServerCertPtr = SSL_get_certificate (SslPtr);

   X509_NAME_oneline (X509_get_issuer_name(ServerCertPtr),
                      CertString, sizeof(CertString));
   SesolaReportFormatCertName (CertString, CertCaString, sizeof(CertCaString));

   X509_NAME_oneline (X509_get_subject_name(ServerCertPtr),
                      CertString, sizeof(CertString));
   SesolaReportFormatCertName (CertString, CertDnString, sizeof(CertDnString));

   ASN1_UTCTIME_print (SesolaBioMemPtr, X509_get_notAfter(ServerCertPtr));
   BIO_gets (SesolaBioMemPtr, CertNotAfterString, sizeof(CertNotAfterString));

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;

   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = &rqptr->rqTime.Vms64bit;

   *vecptr++ = rqptr->ServicePtr->ServerHostPort;
   *vecptr++ = SSLeay_version (SSLEAY_VERSION);
   cptr = SSLeay_version (SSLEAY_BUILT_ON);
   if ((sptr = strstr (cptr, "uilt on")) != NULL)
   {
      cptr = sptr + 7;
      while (*cptr && (*cptr == ' ' || *cptr == ':')) cptr++;
   }
   *vecptr++ = cptr;

   *vecptr++ = SeSoLaProtocolsPtr;
   *vecptr++ = rqptr->ServicePtr->SeSoLaCertPtr;
   *vecptr++ = CertCaString;
   *vecptr++ = CertDnString;
   *vecptr++ = CertNotAfterString;
   *vecptr++ = rqptr->ServicePtr->SeSoLaKeyPtr;
   if (rqptr->ServicePtr->SeSoLaCipherListPtr[0])
      *vecptr++ = rqptr->ServicePtr->SeSoLaCipherListPtr;
   else
      *vecptr++ = "<I>(none)</I>";

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   if (rqptr->ServicePtr->RequestScheme != SCHEME_HTTPS)
   {
      status = NetWriteFaol (rqptr, "</BODY>\n</HTML>\n", NULL);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      return;
   }

   /*********************/
   /* supported ciphers */
   /*********************/

   StackPtr = SSL_get_ciphers (sesolaptr->SslPtr);
   Total = sk_num (StackPtr);
   for (Count = 0; Count < Total; Count++)
   {
      CipherPtr = (SSL_CIPHER *)sk_value (StackPtr, Count);

      vecptr = FaoVector;
      *vecptr++ = Count + 1;
      *vecptr++ = SSL_CIPHER_get_version (CipherPtr);
      *vecptr++ = SSL_CIPHER_get_name (CipherPtr);

      status = NetWriteFaol (rqptr, CiphersFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   vecptr = FaoVector;

   *vecptr++ = SSL_CTX_sess_accept (sesolaptr->SeSoLaCtx);
   *vecptr++ = SSL_CTX_sess_accept_good (sesolaptr->SeSoLaCtx);
   *vecptr++ = SSL_CTX_sess_hits (sesolaptr->SeSoLaCtx);
   *vecptr++ = SSL_CTX_sess_misses (sesolaptr->SeSoLaCtx);
   *vecptr++ = SSL_CTX_sess_timeouts (sesolaptr->SeSoLaCtx);

   /*******************/
   /* current session */
   /*******************/

   if (sesolaptr->SslPtr->hit)
      *vecptr++ = "yes";
   else
      *vecptr++ = "no";

   CipherPtr = SSL_get_current_cipher (sesolaptr->SslPtr);

   /* can't really be null or we would not be here! */
   if (CipherPtr != NULL)
      *vecptr++ = SSL_CIPHER_get_version (CipherPtr);

   cptr = sptr = SSL_get_shared_ciphers (sesolaptr->SslPtr,
                    SharedCiphers, sizeof(SharedCiphers));
   Count = 0;
   /* there has to be at least one or we would not be here! */
   if (cptr != NULL)
   {
      while (*cptr)
      {
         while (*cptr && *cptr != ':') cptr++;
         if (*cptr) cptr++;
         Count++;
      }
   }
   *vecptr++ = Count;

   status = NetWriteFaol (rqptr, CurrentSession1Fao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /* has to be at least one or we would not be here! */
   cptr = sptr;
   if (cptr != NULL)
   {
      Count = 0;
      while (*cptr)
      {
         vecptr = FaoVector;

         sptr = cptr;
         while (*cptr && *cptr != ':') cptr++;
         if (*cptr) *cptr++ = '\0';

         if (Count++)
            *vecptr++ = "<BR>";
         else
            *vecptr++ = "";

         *vecptr++ = Count;
         *vecptr++ = sptr;

         status = NetWriteFaol (rqptr, SharedCipherFao, &FaoVector);
         if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      }
   }

   vecptr = FaoVector;
   *vecptr++ = SSL_CIPHER_get_name (CipherPtr);
   UseKeySize = SSL_CIPHER_get_bits(CipherPtr, &AlgKeySize);
   *vecptr++ = UseKeySize;
   *vecptr++ = AlgKeySize;

   status = NetWriteFaol (rqptr, CurrentSession2Fao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Just put a newline the certificate DN format at each component (meant to be
placed inside <PRE></PRE>.
*/

SesolaReportFormatCertName
(
char *SourceName,
char *FormatName,
int SizeOfFormatName
)
{
   char  *cptr, *sptr, *zptr;
   struct SesolaCertDnRecStruct  *cdnptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "SesolaReportFormatCertName() |%s|\n", SourceName);

   zptr = (sptr = FormatName) + SizeOfFormatName - 1;
   cptr = SourceName;
   while (*cptr && sptr < zptr)
   {
      if (*cptr == '/' && sptr < zptr) *sptr++ = *cptr++;
      while (*cptr && *cptr != '/' && sptr < zptr) *sptr++ = *cptr++;
      if (!cptr) break;
      /* look ahead to make sure the "/" is a "/xx=" */
      for (cdnptr = &SesolaCertDnRec; cdnptr->name != NULL; cdnptr++)
         if (!strncmp (cptr, cdnptr->name, cdnptr->length)) break;
      if (cdnptr->name != NULL && sptr < zptr) *sptr++ = '\n';
   }
   *sptr = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", FormatName);
}

/*****************************************************************************/
/*
This is basically for inclusion in the WATCH report header.
*/

char* SesolaVersion ()

{
   static char  String [64];
   static $DESCRIPTOR (StringDsc, String);
   static $DESCRIPTOR (VersionFaoDsc, "!AZ (!AZ)\n\0");

   char  *cptr, *sptr;

   /*********/
   /* begin */
   /*********/

   if (String[0]) return (String);

   cptr = SSLeay_version (SSLEAY_BUILT_ON);
   if ((sptr = strstr (cptr, "uilt on")) != NULL)
   {
      cptr = sptr + 7;
      while (*cptr && (*cptr == ' ' || *cptr == ':')) cptr++;
   }

   sys$fao (&VersionFaoDsc, 0, &StringDsc,
            SSLeay_version (SSLEAY_VERSION), cptr);
   return (String);
}

/*****************************************************************************/
/*
Implements a required function of a OpenSSL BIO_METHOD.
*/

BIO_METHOD *BIO_s_sesola()
{
   return (&sesola_method);
}

/*****************************************************************************/
/*
Implements a required function of a OpenSSL BIO_METHOD.
*/

int sesola_new (BIO *bioptr)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "sesola_new()\n");

   bioptr->init = 1;
   bioptr->shutdown = 1;
   bioptr->num = 0;
   bioptr->flags = 0;
   /* the BIO pointer is set to the SESOLA structure by the calling routine */
   return (1);
}

/*****************************************************************************/
/*
Implements a required function of a OpenSSL BIO_METHOD.
*/

int sesola_free (BIO *bioptr)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "sesola_free()\n");

   if (bioptr == NULL) return (0);
   /* don't free anything, the BIO pointer is set to the SESOLA structure */
   bioptr->ptr = NULL;
   return (1);
}
	
/*****************************************************************************/
/*
Implements a required function of a OpenSSL BIO_METHOD.
*/

int sesola_read
(
BIO *bioptr,
char *DataPtr,
int DataSize
)
{
   int  status;
   struct SeSoLaStruct  *sesolaptr;
   struct RequestStruct  *rqptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "sesola_read() %d %d\n", DataPtr, DataSize);

   sesolaptr = (struct SeSoLaStruct*)bioptr->ptr;
   rqptr = sesolaptr->rqptr;

   if (Debug)
      fprintf (stdout,
         "ReadCompleted: %d ReadInProgress: %d WriteInProgress: %d\n",
         sesolaptr->ReadCompleted, sesolaptr->ReadInProgress,
         sesolaptr->WriteInProgress);

   if (sesolaptr->ReadInProgress)
   {
      /* asynchronous read in progress, retry next call */
      BIO_set_retry_read (bioptr);
      return (-1);
   }

   if (sesolaptr->ReadCompleted)
   {
      /* previous non-blocking read */
      sesolaptr->ReadCompleted = false;
      BIO_clear_retry_flags (bioptr);
      /* in case of an error give it zero (shutdown) */
      if (VMSok (rqptr->rqNet.ReadIOsb.Status))
         return (rqptr->rqNet.ReadIOsb.Count);
      else
         return (0);
   }

   if (sesolaptr->ReadType == SESOLA_DATA_BLOCKING)
   {
      /* blocking I/O */
      sesolaptr->ReadInProgress = false;
      BIO_clear_retry_flags (bioptr);
      status = NetReadRaw (rqptr, NULL, DataPtr, DataSize);
      /* if success return the number of characters written */
      if (VMSok (status)) return (rqptr->rqNet.ReadIOsb.Count);
      /* whoa, error ... will be checked for by SeSoLaRead() */
      rqptr->rqNet.ReadIOsb.Status = status;
      return (DataSize);
   }
   else
   {
      /* non-blocking I/O */
      sesolaptr->ReadInProgress = true;
      BIO_set_retry_read (bioptr);
      if (sesolaptr->ReadType == SESOLA_ACCEPT)
         sesolaptr->AcceptReadDataPtr = DataPtr;
      NetReadRaw (rqptr, &sesola_read_ast, DataPtr, DataSize);
      /* return indicating non-blocking I/O */
      return (-1);
   }
}

/*****************************************************************************/
/*
*/

int sesola_read_ast (struct RequestStruct *rqptr)

{
   struct SeSoLaStruct  *sesolaptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "sesola_read_ast() %%X%08.08X %d\n",
               rqptr->rqNet.ReadIOsb.Status, rqptr->rqNet.ReadIOsb.Count);

   /* the 'rqptr->SeSoLaPtr' is typeless! */
   sesolaptr = (struct SeSoLaStruct*)rqptr->SeSoLaPtr;

   sesolaptr->ReadInProgress = false;
   sesolaptr->ReadCompleted = true;

   if (sesolaptr->ReadType == SESOLA_DATA_NON_BLOCKING)
      SeSoLaRead (rqptr, sesolaptr->ReadAstFunctionPtr,
                  sesolaptr->ReadDataPtr, sesolaptr->ReadDataSize);
   else
   if (sesolaptr->ReadType == SESOLA_ACCEPT)
      SeSoLaAccept (rqptr);
   else
   if (sesolaptr->ReadType == SESOLA_SHUTDOWN)
      SeSoLaEnd (rqptr);
   else
      ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
}

/*****************************************************************************/
/*
Implements a required function of a OpenSSL BIO_METHOD.
*/

int sesola_write
(
BIO *bioptr,
char *DataPtr,
int DataLength
)
{
   int  status;
   struct RequestStruct  *rqptr;
   struct SeSoLaStruct  *sesolaptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "sesola_write() %d %d\n", DataPtr, DataLength);

   sesolaptr = (struct SeSoLaStruct*)bioptr->ptr;
   rqptr = sesolaptr->rqptr;

   if (Debug)
      fprintf (stdout,
         "WriteCompleted: %d ReadInProgress: %d WriteInProgress: %d\n",
         sesolaptr->WriteCompleted, sesolaptr->ReadInProgress,
         sesolaptr->WriteInProgress);

   if (sesolaptr->WriteInProgress)
   {
      /* asynchronous write in progress, retry next call */
      BIO_set_retry_write (bioptr);
      return (-1);
   }

   if (sesolaptr->WriteCompleted)
   {
      /* previous non-blocking write */
      sesolaptr->WriteCompleted = false;
      BIO_clear_retry_flags (bioptr);
      /* if an error give it what it wants, error is detected SeSolaWrite() */
      if (VMSok (rqptr->rqNet.WriteIOsb.Status))
         return (rqptr->rqNet.WriteIOsb.Count);
      else
         return (DataLength);
   }

   if (sesolaptr->WriteType == SESOLA_DATA_BLOCKING)
   {
      /* blocking I/O */
      sesolaptr->WriteInProgress = sesolaptr->WriteCompleted = false;
      BIO_clear_retry_flags (bioptr);
      status = NetWriteRaw (sesolaptr->rqptr, NULL, DataPtr, DataLength);
      /* if success return the number of characters written */
      if (VMSok (status)) return (rqptr->rqNet.WriteIOsb.Count);
      /* whoa, error ... will be checkd for by SeSoLaWrite() */
      rqptr->rqNet.WriteIOsb.Status = status;
      return (DataLength);
   }
   else
   {
      /* non-blocking I/O */
      sesolaptr->WriteInProgress = true;
      /* indicate to the calling routine this write should be retried */
      BIO_set_retry_write (bioptr);
      NetWriteRaw (sesolaptr->rqptr, &sesola_write_ast, DataPtr, DataLength);
      /* return indicating non-blocking I/O */
      return (-1);
   }
}

/*****************************************************************************/
/*
*/

int sesola_write_ast (struct RequestStruct *rqptr)

{
   struct SeSoLaStruct  *sesolaptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "sesola_write_ast() %%X%08.08X %d\n",
               rqptr->rqNet.WriteIOsb.Status, rqptr->rqNet.WriteIOsb.Count);

   sesolaptr = (struct SeSoLaStruct*)rqptr->SeSoLaPtr;

   sesolaptr->WriteInProgress = false;
   sesolaptr->WriteCompleted = true;

   if (sesolaptr->WriteType == SESOLA_DATA_NON_BLOCKING)
      SeSoLaWrite (rqptr, sesolaptr->WriteAstFunctionPtr,
                   sesolaptr->WriteDataPtr, sesolaptr->WriteDataLength);
   else
   if (sesolaptr->WriteType == SESOLA_ACCEPT)
      SeSoLaAccept (rqptr);
   else
   if (sesolaptr->WriteType == SESOLA_SHUTDOWN)
      SeSoLaEnd (rqptr);
   else
      ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
}

/*****************************************************************************/
/*
Implements a required function of a OpenSSL BIO_METHOD.
*/

long sesola_ctrl
(
BIO *bioptr,
int Command,
long Number,
char *Pointer
)
{
   int  value;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "sesola_ctrl() %d %d %d\n", Command, Number, Pointer);

   value = 1;
   switch (Command)
   {
      case BIO_CTRL_RESET:
         if (Debug) fprintf (stdout, "BIO_CTRL_RESET\n");
         return (1);

      case BIO_CTRL_EOF:
         if (Debug) fprintf (stdout, "BIO_CTRL_EOF\n");
         return (1);

      case BIO_CTRL_SET:
         if (Debug) fprintf (stdout, "BIO_CTRL_SET\n");
         bioptr->num = Number;
         return (1);

      case BIO_CTRL_SET_CLOSE:
         if (Debug) fprintf (stdout, "BIO_CTRL_SET_CLOSE\n");
         return (1);

      case BIO_CTRL_FLUSH:
         if (Debug) fprintf (stdout, "BIO_CTRL_FLUSH\n");
         return (1);

      case BIO_CTRL_DUP:
         if (Debug) fprintf (stdout, "BIO_CTRL_DUP\n");
         return (1);

      case BIO_CTRL_GET_CLOSE:
         if (Debug) fprintf (stdout, "BIO_CTRL_GET_CLOSE\n");
         return (0);

      case BIO_CTRL_INFO:
         if (Debug) fprintf (stdout, "BIO_CTRL_INFO\n");
         return (0);

      case BIO_CTRL_GET:
         if (Debug) fprintf (stdout, "BIO_CTRL_GET\n");
         return (0);

      case BIO_CTRL_PENDING:
         if (Debug) fprintf (stdout, "BIO_CTRL_PENDING\n");
         return (0);

      case BIO_CTRL_POP:
         if (Debug) fprintf (stdout, "BIO_CTRL_POP\n");
         return (0);

      case BIO_CTRL_PUSH:
         if (Debug) fprintf (stdout, "BIO_CTRL_PUSH\n");
         return (0);

      case BIO_CTRL_WPENDING:
         if (Debug) fprintf (stdout, "BIO_CTRL_WPENDING\n");
         return (0);

      default:
         if (Debug) fprintf (stdout, "default:\n");
         return (0);
   }
}

/*****************************************************************************/
/*
Implements a required function of a OpenSSL BIO_METHOD.
*/

int sesola_gets
(
BIO *bioptr,
char *StringPtr,
int StringSize
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "sesola_gets()\n");
   return(0);
}

/*****************************************************************************/
/*
Implements a required function of a OpenSSL BIO_METHOD.
*/

int sesola_puts
(
BIO *bioptr,
char *StringPtr
)
{
    int  Length;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "sesola_puts() |%s|\n", StringPtr);

    if (StringPtr == NULL) return (0);
    Length = strlen (StringPtr);
    if (Length == 0) return (0);
    return (sesola_write (bioptr, StringPtr, Length));
}

/*****************************************************************************/
/*
For compilations without SSL these functions provide LINKage stubs for the
rest of the HTTPd modules, allowing for just recompiling the SESOLA module to
integrate the SSL functionality.
*/

/*********************/
#else  /* not SESOLA */
/*********************/

#ifdef DBUG
extern BOOL Debug;
#else
#define Debug 0 
#endif

/* global storage */
BOOL  ProtocolHttpsAvailable,
      ProtocolHttpsConfigured;
/* i.e. disabled */
int  SeSoLaProtocolVersion = -1;
char  HttpdSesola [] = "",
      SeSoLaParams [256] = "";


/* external storage */
extern char  ErrorSanityCheck[];
extern char  Utility[];

SeSoLaInit ()
{
   ProtocolHttpsAvailable = false;
   if (SeSoLaProtocolVersion <= 0) return;
   fprintf (stdout, "%%%s-E-SSL, non-SSL version\n", Utility);
   exit (STS$K_ERROR | STS$M_INHIB_MSG);
}

SeSoLaInitService
(
struct ServiceStruct *svptr,
struct ServiceStruct *csvptr
)
{
   return;
}

SeSoLaBegin (struct RequestStruct *rqptr)
{
   ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
}

SeSoLaAccept (struct RequestStruct *rqptr)
{
   ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
}

SeSoLaEnd (struct RequestStruct *rqptr)
{
   ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
}

SeSoLaFree (struct RequestStruct *rqptr)
{
   ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
}

SeSoLaShutdown (struct RequestStruct *rqptr)
{
   ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
}

SeSoLaWrite
(
struct RequestStruct *rqptr,
void *AstFunctionPtr,
char *DataPtr,
int DataLength
)
{
   ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
}

SeSoLaRead
(
struct RequestStruct *rqptr,
void *AstFunctionPtr,
char *DataPtr,
int DataSize
)
{
   ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
}

SesolaCgiGenerateVariables
(
struct RequestStruct *rqptr,
int VarType
)
{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SesolaCgiGenerateVariables()\n");

   if (VMSnok (status =
       CgiVariable (rqptr, "SECURITY_STATUS", "NONE", VarType)))
      return (status);

   return (SS$_NORMAL);
}

SeSoLaReport
(
struct RequestStruct *rqptr,
void *NextTaskFunction
)
{
   rqptr->rqResponse.HttpStatus = 500;
   ErrorGeneral (rqptr, "This is a non-SSL version.", FI_LI);
   SysDclAst (NextTaskFunction, rqptr);
}

char* SesolaVersion ()
{
   if (Debug) fprintf (stdout, "SesolaVersion()\n");

   return ("");
}

SeSoLaWatchPeek
(
struct RequestStruct *rqptr,
struct RequestStruct *rqeptr
)
{
   if (Debug) fprintf (stdout, "SesolaWatchPeek()\n");

   return;
}

/************************/
#endif  /* ifdef SESOLA */
/************************/

/*****************************************************************************/

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               