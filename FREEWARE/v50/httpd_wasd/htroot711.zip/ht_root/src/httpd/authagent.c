/*****************************************************************************/
/*
                               AuthAgent.c


    THE GNU GENERAL PUBLIC LICENSE APPLIES DOUBLY TO ANYTHING TO DO WITH
                    AUTHENTICATION AND AUTHORIZATION!

    This package is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License, or any later
    version.

>   This package is distributed in the hope that it will be useful,
>   but WITHOUT ANY WARRANTY; without even the implied warranty of
>   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
>   GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


This module interfaces with an authentication agent script.  These are CGIplus
scripts that perform a username/password validation role (authentication) or a
group membership role (authorization by virtue of group membership).  In this
environment the script has basically all the resources available to a CGIplus
script and must communicate with the server (to pass back the authorization
results) using "escaped" CGIplus data (see the DCL module for further detail).

See AUTH.C for overall detail on the WASD authorization environment.

The name of the script to be activated is derived from the realm or group name
(passed as 'AgentName') and the script directory contained in 'AUTH_AGENT_PATH'
(currently "/cgiauth-bin/", and could be remapped using HTTPD$MAP of course).

The WATCH facility is a valuable adjunct in understanding/debugging agent
script behaviour.


AUTHENTICATING A USERNAME/PASSWORD
----------------------------------
The transaction details are found in the following CGI variables.

WWW_AUTH_AGENT .................. "REALM" or other parameter
WWW_AUTH_PASSWORD ............... user supplied case-sensitive password
WWW_AUTH_REALM .................. realm name (same as agent name)
WWW_AUTH_REALM_DESCRIPTION ...... realm description user is prompted with
WWW_REMOTE_USER ................. case-sensitive username

Valid responses (digits and 'access' are mandatory, other text is optional):

'000 any text' ........... ignored by the server, provides WATCHable trace info 
'100 LIFETIME integer' ... set script's CGIplus lifetime (zero makes infinite)
'100 NOCACHE' ............ do not cache the results of this authorization
'100 REMOTE-USER name .... provide user name (authenticated some non-401 way)
'100 SET-COOKIE cookie' .. RFC2109 cookie (generates "Set-Cookie:" header)
'100 USER any text' ...... provide user details (only after 200 response)
'200 access' ............. username/password verified
                           access: "READ", "WRITE", "READ+WRITE", "FULL"
'302 location' ........... redirect to specified location
                           e.g. http://the.host.name/the/path
                                //the.host.name/the/path
                                ///the/path
'401 reason' ............. username/password did not verify
'401 "any-text"' ......... (quoted) used as the browser authorization prompt
'403 reason' ............. access is forbidden
'500 description' ........ script error to be reported via server


ESTABLISHING GROUP MEMBERSHIP
-----------------------------
The transaction details are found in the following CGI variables.

WWW_AUTH_AGENT .................. "GROUP"
WWW_AUTH_GROUP .................. name of group
WWW_REMOTE_USER ................. case-sensitive username

Valid responses (digits are mandatory, other text is optional):

'000 any text' ........... ignored by the server, provides WATCHable trace info 
'100 LIFETIME integer' ... set script's CGIplus lifetime (zero makes infinite)
'100 NOCACHE' ............ do not cache the results of this authorization
'100 SET-COOKIE cookie' .. RFC2109 cookie (generates "Set-Cookie:" header)
'200 any text' ........... indicates group membership
'302 location ............ redirect to specified location
                           e.g. http://the.host.name/the/path
                                //the.host.name/the/path
                                ///the/path
'403 reason' ............. indicates not a group member
'500 description' ........ script error to be reported via server


VERSION HISTORY
---------------
07-DEC-2000  MGD  agent can now '100 SET-COOKIE rfc2109-cookie'
27-NOV-2000  MGD  bugfix; ensure a mapping rule exists for the agent
09-JUN-2000  MGD  allow "302 location" redirection response
28-AUG-1999  MGD  initial, for v6.1
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <descrip.h>
#include <ssdef.h>
#include <stsdef.h>

/* application related header files */
#include "wasd.h"

#define WASD_MODULE "AUTHAGENT"

#if DBUG
#define FI_NOLI WASD_MODULE, __LINE__
#else
/* in production let's keep the exact line to ourselves! */
#define FI_NOLI WASD_MODULE, 0
#endif

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern int  WatchEnabled;
extern char  ErrorSanityCheck[];
extern struct AccountingStruct  Accounting;
extern struct MsgStruct  Msgs;

/*****************************************************************************/
/*
Initiate an authenication agent script.  After calling this function all
authentication processing occurs asynchronously.
*/ 

AuthAgentBegin
(
struct RequestStruct *rqptr,
char *AgentName,
void *AgentCalloutFunction
)
{
   char *cptr;
   char  AgentFileName [ODS_MAX_FILE_NAME_LENGTH+1],
         AgentScriptName [SCRIPT_NAME_SIZE+1],
         Scratch [256];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthAgentBegin()\n");

   /* after calling this function authorization completes asynchronously! */
   rqptr->rqAuth.AstFunction = rqptr->rqAuth.AstFunctionBuffer;
   rqptr->rqAuth.FinalStatus = AUTH_PENDING;
   /* this pointer may not be valid after asynchronous activity! */
   rqptr->rqAuth.CacheRecordPtr = NULL;

   strcpy (Scratch, AUTH_AGENT_PATH);
   strcat (Scratch, AgentName);

   AgentFileName[0] = AgentScriptName[0] = '\0';
   cptr = MapUrl_Map (Scratch, 0,
                      NULL, 0,
                      AgentScriptName, sizeof(AgentScriptName),
                      AgentFileName, sizeof(AgentFileName),
                      NULL, 0,
                      NULL, rqptr);
   if (Debug)
      fprintf (stdout, "|%s|%s|%s|\n", cptr, AgentScriptName, AgentFileName);
   if (AgentScriptName[0] == '+') AgentScriptName[0] = '/';
   if ((!cptr[0] && cptr[1]) || !AgentScriptName[0] || !AgentFileName[0])
   {
      /* either mapping error or no rule to map the agent */
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_AGENT_MAPPING), FI_LI);
      SysDclAst (AgentCalloutFunction, rqptr);
      return;
   }

   DclBegin (rqptr, AgentCalloutFunction, NULL,
             AgentScriptName, NULL, AgentFileName, NULL, &AuthAgentCallout);
}

/*****************************************************************************/
/*
This is the function called each time the agent script outputs escaped data to
the server.  It must check for beginning and end of agent processing (indicated
by various states of the the 'OutputPtr' and 'OutputCount' storage), and
appropriately process the status responses output by the agent.
*/ 

AuthAgentCallout (struct RequestStruct *rqptr)

{
   int  idx,
        CgiPlusLifeTime,
        Length,
        OutputCount;
   char  *cptr, *sptr, *zptr,
         *OutputPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "AuthAgentCallout() |%s|\n",
               rqptr->rqAuth.AgentParameterPtr);

   OutputPtr = rqptr->rqCgi.CalloutOutputPtr;
   OutputCount = rqptr->rqCgi.CalloutOutputCount;

   if (OutputPtr == NULL &&
       OutputCount == -1)
   {
      /***************/
      /* agent begin */
      /***************/

      if (rqptr->WatchItem &&
          (WatchEnabled & WATCH_AUTH))
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
                    "CALLOUT !AZ begin", rqptr->rqAuth.AgentParameterPtr);
      return;
   }

   if (OutputPtr == NULL &&
       OutputCount == 0)
   {
      /*************/
      /* agent end */
      /*************/

      if (Debug) fprintf (stdout, "agent EOT!\n");

      if (rqptr->WatchItem &&
          (WatchEnabled & WATCH_AUTH))
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
                    "CALLOUT !AZ end", rqptr->rqAuth.AgentParameterPtr);

      /* always ensure any authentication agent information is cancelled! */
      rqptr->rqAuth.AgentParameterPtr = "";
      rqptr->rqAuth.AgentParameterLength = 0;

      return;
   }

   /**************/
   /* agent data */
   /**************/

   if (Debug) fprintf (stdout, "%d |%s|\n", OutputCount, OutputPtr);

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_AUTH))
   {
      WatchThis (rqptr, FI_LI, WATCH_AUTH,
                 "CALLOUT !AZ !UL bytes",
                 rqptr->rqAuth.AgentParameterPtr, OutputCount);
      WatchDataDump (OutputPtr, OutputCount);
      /* if it's trace information then provide it slightly more readably */
      if (!strncmp (OutputPtr, "000 ", 4)) WatchData (OutputPtr, OutputCount);
   }

   if (OutputCount <= 4 ||
       !isdigit(OutputPtr[0]) ||
       !isdigit(OutputPtr[1]) ||
       !isdigit(OutputPtr[2]) ||
       OutputPtr[3] != ' ')
   {
      /* agent response error */
      AuthAgentCalloutResponseError (rqptr);
      return;
   }

   if (!strcmp (rqptr->rqAuth.AgentParameterPtr, "GROUP"))
   {
      if (!strncmp (OutputPtr, "200 ", 4))
      {
         /* a group member */
         if (rqptr->rqAuth.FinalStatus != STS$K_ERROR)
            rqptr->rqAuth.FinalStatus = SS$_NORMAL;
         return;
      }
      if (!strncmp (OutputPtr, "403 ", 4))
      {
         /* not a group member */
         rqptr->rqAuth.FinalStatus = AUTH_DENIED_BY_GROUP;
         return;
      }
   }

   if (!strncmp (OutputPtr, "000 ", 4))
   {
      /* just WATCHable debug information */
      return;
   }

   if (!strncmp (OutputPtr, "100 ", 4))
   {
      /* informational */
      if (strsame (OutputPtr+4, "LIFETIME ", 9))
      {
         /* set lifetime of agent script */
         if (isdigit(OutputPtr[13]))
         {
            /* zero makes the script immune to supervisor purging */
            if ((CgiPlusLifeTime = atoi(OutputPtr+13)) == 0)
               CgiPlusLifeTime = -1;
            rqptr->DclTaskPtr->LifeTimeCount = CgiPlusLifeTime;
            return;
         }               
      }
      if (strsame (OutputPtr+4, "NOCACHE", 7))
      {
         /* do not cache this authorization */
         rqptr->rqAuth.NoCache = true;
         return;
      }
      if (strsame (OutputPtr+4, "REMOTE-USER ", 12))
      {
         /* user details */
         if (OutputPtr[OutputCount-1] == '\n') OutputPtr[--OutputCount] = '\0'; 
         zptr = (sptr = rqptr->RemoteUser) + sizeof(rqptr->RemoteUser)-1;
         for (cptr = OutputPtr+16; *cptr && sptr < zptr; *sptr++ = *cptr++);
         if (sptr >= zptr)
         {
            rqptr->RemoteUser[0] = '\0';
            rqptr->rqAuth.FinalStatus = STS$K_ERROR;
            ErrorGeneralOverflow (rqptr, FI_LI);
            return;
         }
         *sptr = '\0';
         rqptr->RemoteUserLength = sptr - rqptr->RemoteUser;
         return;
      }
      if (strsame (OutputPtr+4, "SET-COOKIE ", 11))
      {
         /* add a cookie to the header */
         if (OutputPtr[OutputCount-1] == '\n') OutputPtr[--OutputCount] = '\0'; 
         Length = OutputCount-15;
         cptr = VmGetHeap (rqptr, Length+1);
         for (idx = 0; idx < RESPONSE_COOKIE_MAX; idx++)
         {
            if (rqptr->rqResponse.CookiePtr[idx] == NULL)
            {
               memcpy (rqptr->rqResponse.CookiePtr[idx] = cptr,
                       OutputPtr+15, Length+1);
               return;
            }
         }
      }
      if (strsame (OutputPtr+4, "USER ", 5))
      {
         /* user details */
         if (OutputPtr[OutputCount-1] == '\n') OutputPtr[--OutputCount] = '\0'; 
         rqptr->rqAuth.UserDetailsLength = OutputCount-9;
         rqptr->rqAuth.UserDetailsPtr = VmGetHeap (rqptr, OutputCount);
         strcpy (rqptr->rqAuth.UserDetailsPtr, OutputPtr+9);
         return;
      }
      AuthAgentCalloutResponseError (rqptr);
      return;
   }

   if (!strncmp (OutputPtr, "200 ", 4))
   {
      /* authenticated */
      rqptr->rqAuth.FinalStatus = SS$_NORMAL;
      if (strsame (OutputPtr+4, "FULL", 4))
      {
         rqptr->rqAuth.UserCan = AUTH_READWRITE_ACCESS;
         if (rqptr->rqAuth.FinalStatus != STS$K_ERROR)
            rqptr->rqAuth.FinalStatus = SS$_NORMAL;
         return;
      }
      if (strsame (OutputPtr+4, "READ+WRITE", 10))
      {
         rqptr->rqAuth.UserCan = AUTH_READWRITE_ACCESS;
         if (rqptr->rqAuth.FinalStatus != STS$K_ERROR)
            rqptr->rqAuth.FinalStatus = SS$_NORMAL;
         return;
      }
      if (strsame (OutputPtr+4, "READ", 4))
      {
         rqptr->rqAuth.UserCan = AUTH_READONLY_ACCESS;
         if (rqptr->rqAuth.FinalStatus != STS$K_ERROR)
            rqptr->rqAuth.FinalStatus = SS$_NORMAL;
         return;
      }
      if (strsame (OutputPtr+4, "WRITE", 5))
      {
         rqptr->rqAuth.UserCan = AUTH_WRITEONLY_ACCESS;
         if (rqptr->rqAuth.FinalStatus != STS$K_ERROR)
            rqptr->rqAuth.FinalStatus = SS$_NORMAL;
         return;
      }
      AuthAgentCalloutResponseError (rqptr);
      return;
   }

   if (!strncmp (OutputPtr, "302 ", 4))
   {
      /* redirection */
      rqptr->rqAuth.FinalStatus = AUTH_DENIED_BY_REDIRECT;
      cptr = OutputPtr + 4;
      while (*cptr && ISLWS(*cptr)) cptr++;
      for (sptr = cptr; *sptr && NOTEOL(*sptr) && !ISLWS(*sptr); sptr++);
      *sptr = '\0';
      rqptr->rqResponse.LocationPtr = sptr = VmGetHeap (rqptr, sptr-cptr);
      while (*cptr) *sptr++ = *cptr++;
      *sptr = '\0';
      return;
   }

   if (!strncmp (OutputPtr, "401 ", 4))
   {
      /* not authenticated */
      rqptr->rqAuth.FinalStatus = AUTH_DENIED_BY_LOGIN;
      cptr = OutputPtr + 4;
      while (*cptr && ISLWS(*cptr)) cptr++;
      if (*cptr == '\"')
      {
         for (sptr = cptr+1; *sptr && *sptr != '\"'; sptr++);
         *sptr = '\0';
         rqptr->rqAuth.RealmDescrPtr = sptr = VmGetHeap (rqptr, sptr-cptr);
         cptr++;
         /* trim leading white-space */
         while (*cptr && ISLWS(*cptr)) cptr++;
         while (*cptr) *sptr++ = *cptr++;
         *sptr = '\0';
         /* trim trailing white-space */
         if (sptr > rqptr->rqAuth.RealmDescrPtr) sptr--;
         while (sptr > rqptr->rqAuth.RealmDescrPtr && ISLWS(*sptr)) sptr--;
         if (Debug) fprintf (stdout, "|%s|\n", rqptr->rqAuth.RealmDescrPtr); 
      }
      return;
   }

   if (!strncmp (OutputPtr, "403 ", 4))
   {
      /* not authorized */
      rqptr->rqAuth.FinalStatus = AUTH_DENIED_BY_OTHER;
      return;
   }

   if (!strncmp (OutputPtr, "500 ", 4))
   {
      /* report this error via the server */
      rqptr->rqAuth.FinalStatus = STS$K_ERROR;
      if (OutputPtr[OutputCount-1] == '\n') OutputPtr[--OutputCount] = '\0'; 
      ErrorGeneral (rqptr, OutputPtr+4, FI_LI);
      return;
   }

   AuthAgentCalloutResponseError (rqptr);
}

/*****************************************************************************/
/*
Simple way to generate this particular error message from various points.
*/ 

AuthAgentCalloutResponseError (struct RequestStruct *rqptr)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthAgentCalloutResponseError()\n");

   ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_AGENT_RESPONSE), FI_LI);

   rqptr->rqAuth.FinalStatus = STS$K_ERROR;
}

/****************************************************************************/
                                                                                                                                                                                                                