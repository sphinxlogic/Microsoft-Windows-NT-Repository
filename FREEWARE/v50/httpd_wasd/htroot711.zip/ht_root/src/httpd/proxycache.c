/*****************************************************************************/
/*
                               ProxyCache.c

*************
** CAUTION **
*************

THIS MODULE IS TASK-ORIENTED, NOT REQUEST-ORIENTED.

That is, most of the functions take a pointer to proxy task rather than a
pointer to request as do other modules. The reason is simple. Many of these
functions are designed for use independently of a request.


INTRODUCTION
------------
Implements a basic HTTP proxy disk caching service.  The design always trades
simplicity off against efficiency and elegance.  Cache management is performed
by the PROXYMAINT.C module.  It work intimately with this module to provide
routine and reactive purging (deletion) of cache files to maintain device free
space and currency of cache content.


CACHE CRITERIA
--------------
Proxied requests COULD ONLY have been cached if THE REQUEST ...

  o  uses the GET method
  o  does not contain a query string
  [o  does not contain a cookie] <-relaxed experimentally 10-NOV-1999
  o  is HTTP/1.n compliant (i.e. not HTTP/0.9)

Proxied request responses WILL ONLY be cached if THE RESPONSE ...

  o  status code begins with '2' (success)
  o  contains a "Last-Modified:" header field
  o  one or more hours since the last modification
  o  does not contain a "Pragma: no-cache" field
  [o  does not contain a cookie] <-relaxed experimentally 10-NOV-1999
  o  does not exceed a configuration parameter in size
  o  is HTTP/1.n compliant (i.e. not HTTP/0.9)

"Content-Length:" is only used (if available) to check load integrity.

Configuration parameter for maximum cachable response size.  This applies to
response without content-length header fields, the in-progress caching is just
aborted if the response grows to exceed this size.

  [ProxyCacheFileKbytesMax] ... maximum number of Kbytes for any one response


FILE CACHE
----------
The file cache is supported using ODS-2 conventions.  This does not mean that
it cannot be located on an ODS-5 device, just that the directory depth,
structure and file naming must be ODS-2 compliant (which it is by default). 
There seems little advantage in supporting extended file specifications for
this functionality so I'm spending the time elsewhere!

One file is used for each unique request.  A request is made unique by creating
a request identifier using the request host name, the port, and the request
path (excluding any query string of course).  This is essentially the URL.  A
unique file name is generated for each of these unique requests by generating
an MD5 digest using the identifier.  This, for all intents and purpose (at
least according to RSA), generates a unique "fingerprint" of the identifier's
text.  No other checking is required to ensure the file represents the request!

A quotation from RFC1321 (April 1992):

  The algorithm takes as input a message of arbitrary length and produces
  as output a 128-bit "fingerprint" or "message digest" of the input. It
  is conjectured that it is computationally infeasible to produce two
  messages having the same message digest ...

The digest is 16 bytes (128 bits) represented as 32 hexadecimal digits and
looks like this:

  2BF641901B1661D3345C4D058A0F390F

Use of the MD5 algorithm has been shown in practice to produce a *very* even
distribution of file names.

To help reduce per-directory congestion the cached files are distributed
throughout a number of subdirectories.

Two cache directory organizations are currently available.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
These are selected using the [ProxyCacheDeviceDirOrg] configuration directive.

The first (and default) provides a single level structure with a possible 256
directories at the top level and files organized immediate below these. The
directory name for any file is generated using the first two hexadecimal
digits, hence subdirectory names range from [00], [01], [02] to [FF]! The other
30 digits comprise the file name, with an extension of ".HTC". Subirectories
are created by the server as required. Hence a proxy cache file name looks
something like: 

  HT_CACHE_ROOT:[2B]F641901B1661D3345C4D058A0F390F.HTC

This is the original structure and works well where files do not exceed 256 per
directory for a total of approximately 65,000 files.  For versions of VMS prior
to V7.2 exceeding 256 files per directory incurs a significant performance
penalty for some directory operations. 

The second organization involves two levels of directory, each with a maximum
of 64 directories.  This is accomplished by using the leading three hexadecimal
digits (12 bits), the first becomes the first character of the top-level
directory name, the upper two bits of the second represented byte the
hexadecimal equivalent of the second character, the lower two bits of the
hexadecimal equivalent of the first character of the second directory and the
third character the second character of the second directory.  A file in this
structure cache might look like:

  HT_CACHE_ROOT:[22.3F]641901B1661D3345C4D058A0F390F.HTC

Here the first three characters, "2BF" or 0010+1011+1111, as a bit-pattern,
become "22", or 0010+10, for the first directory name, and "3F", or 11+1111,
for the second directory name.  Hence the first three hexdecimal characters of
the MD5 digest become the directory path [22.3F].  Directory names will begin
at [00.00], [00.01], [00.02] and range through to [F3.3D], [F3.3E], [F3.3F].
This allows for approximately 1,000,000 files before encountering the 256 file
per directory issue.

No "database" or other record is maintained of the files in the cache. All
access is via the unique MD5 "fingerprint" of the request. Hence it is easy to
reclaim disk space by manually deleting files. Cache files should not of
course be renamed to other subdirectories.


CACHE FILE STRUCTURE
--------------------
Three 32 bit integers prefix the cache file; cache version number, request URL
length (length of "http://node.domain:port/path"), response header length (that
received from the remote server).  Following these three integers is a null
terminated string, the URL string (length, including terminating null in second
integer). Then the response header (not null-terminated), immediately followed
by the response body (not null-terminated) to the end-of-file (which delimits
the body ... and response header for that matter).  The following diagram
illutrates this layout.

   16       (URL)12             8             4             0   VBN 1
    +-------------+-------------+-------------+-------------+
    | uu uu uu uu |  HEADER LEN |     URL LEN |     VERSION |
    +-------------+-------------+-------------+-------------+
    | uu uu uu uu | uu uu uu uu | uu uu uu uu | uu uu uu uu |
    +-------------+-------------+-------------+-------------+
    .
    .                           (HEADER)
    +-------------+-------------+-------------+-------------+
    | hh hh hh hh | hh hh hh hh | hh hh \0 uu | uu uu uu uu |
    +-------------+-------------+-------------+-------------+
    | hh hh hh hh | hh hh hh hh | hh hh hh hh | hh hh hh hh |
    +-------------+-------------+-------------+-------------+
    .
    .               (BODY)
    +-------------+-------------+-------------+-------------+
    | bb bb bb bb | bb bb hh hh | hh hh hh hh | hh hh hh hh |
    +-------------+-------------+-------------+-------------+
    | bb bb bb bb | bb bb bb bb | bb bb bb bb | bb bb bb bb |
    +-------------+-------------+-------------+-------------+
    .
    .
    +-------------+-------------+-------------+-------------+
    |             |             |       bb bb | bb bb bb bb |
    +-------------+-------------+-------------+-------------+
                                    EOF^                        VBN n


DISK SPACE USAGE
----------------
To simplify cache management and processing overhead the proxy cache is allowed
to use up to a configuration maximum percentage of the particular device it is
located on.  That is, it is allowed to continue to use free space until the
device reaches a specified percentage used.  At that point it deletes cache
files until another, lower device usage percentage is reached.  Hence the cache
will grow using available free space, unless that free space is called-on for
some other purpose, at which time it reduces it's own usage.  The following
configuration parameters control this behaviour.

  [ProxyCacheDeviceMaxPercent] ...... maximum device percentage in use 
  [ProxyCacheDevicePurgePercent] ... when purging usage reduce by this


CACHE FILE MANAGEMENT
---------------------
Cache file deletion takes two forms.  The first is ROUTINE, where files that
have not been accessed within specified limits are deleted.  The second is
remedial, a PURGE, where cache space usage is reaching it's limit and files
need to be deleted.  The following two configuration parameters control the
minutes between each of these events.

  [ProxyCacheRoutineHourOfDay] ..... routine delete of non-accessed files
  [ProxyCacheDeviceCheckMinutes] ... check if the cache device needs purging

In the first, ROUTINE form the cache files are scanned looking for those that
exceed the configuration parameters for maximum period since last access, which
are then deleted (see [ProxyCachePurgeList] described below).

The second form, a PURGE of cache space, the files are scanned using the
[ProxyCachePurgeList] parameter above, working from the greatest to least
number of hours in the steps provided.  At each scan files not accessed within
that period are deleted.  Each few files deleted the device free space is
checked for having reached the lower purge percentage limit, at which point the
scan terminates.

  [ProxyCachePurgeList] ... series of comma-separated integers

This parameter has as it's input a series of comma-separated integers
representing a series of purges to the hour a file was last accessed. In this
way the cache can be progressively reduced until percentage usage targets are
realized.  (Note that this parameter specifies hours in the reverse order to
[ProxyCacheReloadList].)  Such a parameter would be specified as follows,

  [ProxyCachePurgeList] 168,48,24,8,0

meaning the purge would first delete files not accessed in the last week, then
not for the last two days, then the last twenty-four hours, then eight, then
finally all files.  The largest of the specified periods (in this case 168) is
also used as the limit for the ROUTINE scan and file delete.

Once the target reduction percentage is reached the purge stops. During the
purge operation, and until the target reduction is reached, cache files are not
created.  Unless the target reduction percentage can be reached no more cache
files will be created.  Even when cache file cannot be created for any reason
proxy serving still continues transparently to the clients.

CACHE FILES CAN BE MANUALLY DELETED AT ANY TIME (FROM THE COMMAND LINE, AND
PROVIDED THEY ARE NOT LOCKED FOR ANY REASON) WITHOUT DISTURBING THE
PROXY-CACHING SERVER AND WITHOUT REBUILDING ANY DATABASES.  WHEN DELETING, THE
/BEFORE= QUALIFIER CAN BE USED, WITH /CREATED BEING THE DOCUMENT'S
LAST-MODIFIED DATE, /REVISED BEING THE LAST TIME IT WAS LOADED, AND /EXPIRED
THE LAST TIME THE FILE WAS ACCESSED (USED TO SUPPLY A REQUEST).


CACHE MAINTENANCE COMMENT
-------------------------
This cache design is obviously very file system intensive (not necesarily an
optimal choice with the notoriously slow VMS file system).  The trade-off is of
course simplicity of implementation and management.  Let the file system do the
database management for it, with nothing to go wrong, maintain or rebuild
outside of that ;^)  The use of the MD5 algorithm to generate unique cache file
names makes all this straight-forward.  Let's hope it works!


CACHE INVALIDATION
------------------
For this purpose, cache invalidation is defined as the determination when a
cache file's data is no longer valid and needs to be reloaded.

The method used to for cache validation is deliberately quite simple in
algorithm and implementation. In this first attempt at a proxy server the
overriding criteria have been efficiency, simplicity of implementation, and
reliability. Wishing to avoid complicated revalidation using behind-the-scenes
HEAD requests the basic approach has been to just invalidate the cache item
upon exiry of a period related to it's "Last-Modified:" age or upon a
"no-cache" request, both described further below.

If a "Pragma: no-cache" request header field is present (as is generated by
Netscape Navigator when using the "reload" function) then the server should
completely reload the response from the remote server. (Too often the author
seems to have received incomplete responses where the proxy server caches only
part of a response and has seemed to refuse to explicitly re-request.) OK it's
a a bit more expensive but who's to say the proxy server is right all the
time! The response is still cached ... the next request may not have the
"no-cache" parameter.

When a response is cached the file creation date is set to the local equivalent
of the "Last-Modified:" GMT date and time supplied with the response. In this
manner the file's absolute age can be determined solely from the file header.

Also, when a file is cached, the "revision" and "expires" date/times is set to
current.  The "revision" date/time is used when assessing when the file was
last loaded/validated/reloaded.  The "expires" is used as described below.

Once a file is cached the RMS "expiration" date/time is updated every time it
is subsequently accessed. In this way recency of usage of the item can be
easily tracked.

The revision count (automatically updated by VMS) tracks the absolute number of
accesses since the file was created (actually a maximum of 65535, or an
unsigned short, but that should be enough).


AGE ALGORITHM
-------------
The following configuration parameter is used to control when a file being
accessed is forceably reloaded from source.

  [ProxyCacheReloadList] ... series of comma-separated integers

This parameter supplied a series of integers representing the hours after which
an access to a cache file causes the file to be invalidated and reloaded from
it's source during the proxied request.  (Note that this parameter specifies
hours in the reverse order to [ProxyCachePurgeList].) Each number in the
series represents the lower boundary of the range between it and the next
number of hours.  A file with a last-loaded age falling within a range is
reloaded at the lower boundary of that particular range.  The following example

  [ProxyCacheReloadList] 1,2,4,8,12,24,48,96,168

would result in a file 1.5 hours old being reloaded every hour, 3.25 hours old
every 2 hours, 4-8 hours old every 4 hours, etc.  Here "old" means since last
(or of course first) loaded.  Files not reloaded since the final integer, in
this example 168, are always reloaded.


VERSION HISTORY
---------------
28-AUG-2000  MGD  flat256 and 64x64 cache directory organizations
01-JUN-2000  MGD  bugfix; use 'rqHeader.RequestUriPtr' as '->RequestUriPtr'
                  (non-URL-decoded path plus query string)
03-JAN-2000  MGD  no changes required for ODS-5 compliance ... it's not
                  (see not above)
10-NOV-1999  MGD  cookie constraint relaxed (improved cache perform by 100%)
19-AUG-1998  MGD  initial development (recommenced DEC 1998)
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <atrdef.h>
#include <descrip.h>
#include <dvidef.h>
#include <fibdef.h>
#include <iodef.h>
#include <libdef.h>
#include <libdtdef.h>
#include <psldef.h>
#include <ssdef.h>
#include <stsdef.h>

/* application-related header files */
#include "wasd.h"

#define WASD_MODULE "PROXYCACHE"

/******************/
/* global storage */
/******************/

#define COOKIE_THEN_NOT_CACHED 0
#define PROXY_CACHE_DEFAULT_PURGE_LIST "168,48,24,8,0"
#define PROXY_CACHE_DEFAULT_RELOAD_LIST "1,2,4,8,12,24,48,96,168"
#define PROXY_CACHE_DIR_ORG_DEFAULT PROXY_CACHE_DIR_ORG_FLAT256

char  ErrorProxyCacheVersion [] = "Proxy cache file version mismatch!";

boolean  ProxyCacheAllowReload = true,
         ProxyCacheEnabled,
         ProxyCacheFreeSpaceAvailable,
         ProxyReportCacheLog,
         ProxyReportLog;

int  ProxyCacheDeviceCheckMinutes,
     ProxyCacheDeviceDirOrg,
     ProxyCacheDeviceMaxPercent,
     ProxyCacheDevicePurgePercent,
     ProxyCacheDeviceTargetPercent,
     ProxyCacheFileKBytesMax,
     ProxyCacheAllocationQuantityMax,
     ProxyCacheRoutineHourOfDay;

char  *ProxyCachePurgeListPtr,
      *ProxyCacheReloadListPtr;

#define PROXY_CACHE_PURGE_HOURS_MAX 32
int  ProxyCachePurgeList [PROXY_CACHE_PURGE_HOURS_MAX];
int  ProxyCachePurgeListCount;
char  ProxyCachePurgeListString [64];

#define PROXY_CACHE_RELOAD_HOURS_MAX 32
int  ProxyCacheReloadList [PROXY_CACHE_RELOAD_HOURS_MAX];
int  ProxyCacheReloadListCount;
char  ProxyCacheReloadListString [64];

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern int  ProxyReadBufferSize,
            WatchEnabled;

extern char  ErrorSanityCheck[],
             HttpProtocol[],
             SoftwareID[],
             Utility[];

extern struct AccountingStruct  Accounting;
extern struct ConfigStruct  Config;
extern struct MsgStruct  Msgs;
extern struct ProxyAccountingStruct  ProxyAccounting;

/****************************************************************************/
/*
*/

ProxyCacheInit (boolean CacheEnabled)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyCacheInit() %d\n", CacheEnabled);

   ProxyCacheEnabled = CacheEnabled;

   if (!(ProxyCacheDeviceDirOrg = Config.cfProxy.CacheDeviceDirOrg))
      ProxyCacheDeviceDirOrg = PROXY_CACHE_DIR_ORG_DEFAULT;
   ProxyCacheDeviceCheckMinutes = Config.cfProxy.CacheDeviceCheckMinutes;
   ProxyCacheDeviceMaxPercent = Config.cfProxy.CacheDeviceMaxPercent;
   ProxyCacheDevicePurgePercent = Config.cfProxy.CacheDevicePurgePercent;
   ProxyCacheFileKBytesMax = Config.cfProxy.CacheFileKBytesMax;
   ProxyCacheRoutineHourOfDay = Config.cfProxy.CacheRoutineHourOfDay;
   ProxyCachePurgeListPtr = Config.cfProxy.CachePurgeList;
   ProxyCacheReloadListPtr = Config.cfProxy.CachePurgeList;
   ProxyReportCacheLog = Config.cfProxy.ReportCacheLog;
   ProxyReportLog = Config.cfProxy.ReportLog;

   ProxyCacheInitValues ();

   if (ProxyCacheEnabled) ProxyMaintInit ();
}

/****************************************************************************/
/*
Make sure the configuration parameters are reasonable.  Build the purge and
reload arrays.
*/

ProxyCacheInitValues ()

{
   int  Number,
        LastNumber;
   char  *cptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyCacheInitValues()\n");

   if (ProxyCacheDeviceCheckMinutes < 1)
      ProxyCacheDeviceCheckMinutes = 15;
   if (ProxyCacheDeviceCheckMinutes > 60)
      ProxyCacheDeviceCheckMinutes = 60;

   if (ProxyCacheDeviceMaxPercent < 10)
      ProxyCacheDeviceMaxPercent = 85;
   if (ProxyCacheDeviceMaxPercent > 85)
      ProxyCacheDeviceMaxPercent = 85;

   if (ProxyCacheDevicePurgePercent < 1)
      ProxyCacheDevicePurgePercent = 1;
   if (ProxyCacheDevicePurgePercent > 25)
      ProxyCacheDevicePurgePercent = 25;

   ProxyCacheDeviceTargetPercent = ProxyCacheDeviceMaxPercent -
                                   ProxyCacheDevicePurgePercent;
   if (ProxyCacheDeviceTargetPercent < 0) ProxyCacheDeviceTargetPercent = 0;

   if (ProxyCacheFileKBytesMax < 1)
      ProxyCacheFileKBytesMax = 256;
   if (ProxyCacheFileKBytesMax > 1024)
      ProxyCacheFileKBytesMax = 1024;
   /* number of KBytes * 2 (2x512bytes) plus 1 block for URL, etc. */
   ProxyCacheAllocationQuantityMax = (ProxyCacheFileKBytesMax * 2) + 1;

   if (ProxyCacheRoutineHourOfDay < 0)
      ProxyCacheRoutineHourOfDay = 0;
   if (ProxyCacheRoutineHourOfDay > 23)
      ProxyCacheRoutineHourOfDay = 23;

   ProxyCacheInitPurgeList ();

   ProxyCacheInitReloadList ();
}

/****************************************************************************/
/*
*/

ProxyCacheInitPurgeList ()

{
   static $DESCRIPTOR (ListFaoDsc, "!AZ!UL");

   int  idx,
        status,
        Number,
        LastNumber;
   unsigned long  *vecptr;
   char  *cptr;
   unsigned long  FaoVector [2];
   unsigned short  Length;
   $DESCRIPTOR (ListDsc, ProxyCachePurgeListString);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyCacheInitPurgeList()\n");

   for (;;)
   {
      LastNumber = 999999999;
      ProxyCachePurgeListCount = 0;
      if (!*ProxyCachePurgeListPtr)
         ProxyCachePurgeListPtr = PROXY_CACHE_DEFAULT_PURGE_LIST;
      cptr = ProxyCachePurgeListPtr;
      while (*cptr && *ProxyCachePurgeListPtr)
      {
         while (*cptr && !isdigit(*cptr)) cptr++;
         if (!*cptr) break;
         Number = atoi(cptr);
         while (isdigit(*cptr)) cptr++;
         if (Number >= LastNumber ||
             ProxyCachePurgeListCount >= PROXY_CACHE_PURGE_HOURS_MAX)
         {
            ProxyCachePurgeListPtr = "";
            break;
         }
         ProxyCachePurgeList[ProxyCachePurgeListCount++] = LastNumber = Number;
      }

      /* exit, having built the array of hours */
      if (*ProxyCachePurgeListPtr) break;
   }

   memset (&ProxyCachePurgeListString, 0, sizeof(ProxyCachePurgeListString));
   Length = 0;
   for (idx = 0; idx < ProxyCachePurgeListCount; idx++)
   {
      ListDsc.dsc$w_length += Length;
      ListDsc.dsc$a_pointer += Length;
      vecptr = &FaoVector;
      if (idx) *vecptr++ = ","; else *vecptr++ = "";
      *vecptr++ = ProxyCachePurgeList[idx];
      status = sys$faol (&ListFaoDsc, &Length, &ListDsc, &FaoVector);
      if (Debug) fprintf (stdout, "sys$faol() %%X%08.08X %d\n", status, Length);
      if (VMSnok (status))
      {
         strcpy (ProxyCachePurgeListString, "*ERROR*");
         break;
      }
   }
   ProxyCachePurgeListPtr = ProxyCachePurgeListString;
}

/****************************************************************************/
/*
*/

ProxyCacheInitReloadList ()

{
   static $DESCRIPTOR (ListFaoDsc, "!AZ!UL");

   int  idx,
        status,
        Number,
        LastNumber;
   unsigned long  FaoVector [2];
   unsigned short  Length;
   unsigned long  *vecptr;
   char  *cptr;
   $DESCRIPTOR (ListDsc, ProxyCacheReloadListString);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyCacheInitReloadList()\n");

   for (;;)
   {
      LastNumber = 0;
      ProxyCacheReloadListCount = 0;
      if (!*ProxyCacheReloadListPtr)
         ProxyCacheReloadListPtr = PROXY_CACHE_DEFAULT_RELOAD_LIST;
      cptr = ProxyCacheReloadListPtr;
      while (*cptr)
      {
         while (*cptr && !isdigit(*cptr)) cptr++;
         if (!*cptr) break;
         Number = atoi(cptr);
         while (isdigit(*cptr)) cptr++;
         if (Number <= LastNumber ||
             ProxyCacheReloadListCount >= PROXY_CACHE_RELOAD_HOURS_MAX)
         {
            ProxyCacheReloadListPtr = "";
            break;
         }
         ProxyCacheReloadList[ProxyCacheReloadListCount++] =
            LastNumber = Number;
      }

      /* exit, having built the array of hours */
      if (*ProxyCacheReloadListPtr) break;
   }

   memset (&ProxyCacheReloadListString, 0, sizeof(ProxyCacheReloadListString));
   Length = 0;
   for (idx = 0; idx < ProxyCacheReloadListCount; idx++)
   {
      ListDsc.dsc$w_length += Length;
      ListDsc.dsc$a_pointer += Length;
      vecptr = &FaoVector;
      if (idx) *vecptr++ = ","; else *vecptr++ = "";
      *vecptr++ = ProxyCacheReloadList[idx];
      status = sys$faol (&ListFaoDsc, &Length, &ListDsc, &FaoVector);
      if (Debug) fprintf (stdout, "sys$faol() %%X%08.08X %d\n", status, Length);
      if (VMSnok (status))
      {
         strcpy (ProxyCacheReloadListString, "*ERROR*");
         break;
      }
   }
   ProxyCacheReloadListPtr = ProxyCacheReloadListString;
}

/*****************************************************************************/
/*
After an asynchronous sys$close() call ProxyEnd() with the 'tkptr' parameter
stored in the FAB context.
*/

ProxyCacheCloseAst_ProxyEnd (struct FAB *FabPtr)

{
   int  status;
   struct ProxyTaskStruct  *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyCacheCloseAst_ProxyEnd()\n");

   /* get the task pointer via the context block */
   tkptr = FabPtr->fab$l_ctx;

   if (ProxyReportCacheLog)
      if (VMSnok (status = FabPtr->fab$l_sts))
         WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, file delete-on-close error (!AZ !UL)\n-!%M\n \\!AZ\\\n",
            Utility, 0, FI_LI, status, tkptr->ProxyCacheFileName);

   ProxyEnd (tkptr);
} 

/*****************************************************************************/
/*
After an asynchronous sys$close() call ProxyResponseNetWrite() with the 'tkptr'
parameter stored in the FAB context. 
*/

ProxyCacheCloseAst_NetWrite (struct FAB *FabPtr)

{
   int  status;
   struct ProxyTaskStruct  *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyCacheCloseAst_NetWrite()\n");

   /* get the task pointer via the context block */
   tkptr = FabPtr->fab$l_ctx;

   if (ProxyReportCacheLog)
      if (VMSnok (status = FabPtr->fab$l_sts))
         WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, file delete-on-close error (!AZ !UL)\n-!%M\n \\!AZ\\\n",
            Utility, 0, FI_LI, status, tkptr->ProxyCacheFileName);

   ProxyResponseNetWrite (tkptr);
} 

/*****************************************************************************/
/*
If there was a proxy load in progress then just finalize that.  If the read
file is still open it cannot have been closed by either the ProxyCacheReadEnd()
or the ProxyCacheLoadBegin() functions, therefore it cannot still be a valid
cache file so delete it as it is closed.
*/

ProxyCacheEnd (struct ProxyTaskStruct *tkptr)

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyCacheEnd()\n");

   if (tkptr->ParseInUse)
   {
      /* ensure parse internal data structures are released */
      tkptr->ReadFab.fab$l_fna = "a:[b]c.d;";
      tkptr->ReadFab.fab$b_fns = 9;
      tkptr->ReadFab.fab$b_dns = tkptr->FileNam.nam$l_rlf = 0;
      tkptr->FileNam.nam$b_nop = NAM$M_SYNCHK;

      /* synchronous service */
      tkptr->ReadFab.fab$l_fop &= ~FAB$M_ASY;
      status = sys$parse (&tkptr->ReadFab, 0, 0);
      if (Debug) fprintf (stdout, "sys$parse() %%X%08.08X\n", status);
   }

   if (tkptr->ReadFab.fab$w_ifi)
   {
      /* close/delete file asynchronously ASTing to ProxyEnd() */
      tkptr->ReadFab.fab$l_fop |= FAB$M_DLT | FAB$M_ASY;
      status = sys$close (&tkptr->ReadFab, &ProxyCacheCloseAst_ProxyEnd,
                                           &ProxyCacheCloseAst_ProxyEnd);
      if (Debug) fprintf (stdout, "sys$close() %%X%08.08X\n", status);
      return;
   }

   if (tkptr->LoadFab.fab$w_ifi)
   {
      /* this function ASTs to ProxyEnd() */
      ProxyCacheLoadEnd (tkptr);
      return;
   }
}

/*****************************************************************************/
/*
Check the obvious and early criteria on whether a proxied request could be
cached.  If not just return an error status.  If it's possible to have cached
this request then construct the cache file ident block from the request
host-name[:port] and the request path.  Use this to generate the MD5 digest
string of that ident block and generate a unique cache file name using that.
Create a file FAB and NAM and attempt to open the file.  This open ASTs to
ProxyCacheReadConnect() where it's success is checked.
*/

int ProxyCacheReadBegin (struct ProxyTaskStruct *tkptr)

{
   boolean  SetPathNoCache;
   int  status,
        UrlLength;
   char  *cptr, *sptr, *zptr,
         *UrlPtr;
   struct ProxyCacheDescrStruct  *pcdptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyCacheReadBegin() %d\n", tkptr);

   tkptr->ProxyCacheSuitable = tkptr->ProxyCacheFileExisted = false;

   if (!ProxyCacheEnabled) return (STS$K_ERROR);

   if (tkptr->RequestPtr == NULL)
      SetPathNoCache = false;
   else
      SetPathNoCache = tkptr->RequestPtr->rqPathSet.NoCache;
         
   if (tkptr->RequestHttpMethod != HTTP_METHOD_GET ||
       tkptr->RequestQueryStringPresent ||
#if COOKIE_THEN_NOT_CACHED
       tkptr->RequestHttpCookiePtr != NULL ||
#endif
       tkptr->RequestHttpVersion == HTTP_VERSION_0_9 ||
       SetPathNoCache)
   {
      if (Debug) fprintf (stdout, "NOT CACHED!\n");

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY_CACHE))
      {
         char  String [256];

         String[0] = '\0';
         if (tkptr->RequestHttpMethod != HTTP_METHOD_GET)
         {
            strcpy (String, "method ");
            strcat (String, tkptr->RequestHttpMethodNamePtr);
         }
         if (tkptr->RequestQueryStringPresent)
         {
            if (String[0]) strcat (String, ", ");
            strcat (String, "query string");
         }
#if COOKIE_THEN_NOT_CACHED
         if (tkptr->RequestHttpCookiePtr != NULL)
         {
            if (String[0]) strcat (String, ", ");
            strcat (String, "supplies cookie");
         }
#endif
         if (tkptr->RequestHttpVersion == HTTP_VERSION_0_9)
         {
            if (String[0]) strcat (String, ", ");
            strcat (String, "HTTP/0.9");
         }
         if (SetPathNoCache)
         {
            if (String[0]) strcat (String, ", ");
            strcat (String, "path set NOCACHE");
         }
         if (!String[0]) strcpy (String, "?");

         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                    "CACHE READ not cachable: !AZ", String);
      }

      tkptr->NotCacheable = true;
      ProxyAccounting.RequestNotCacheableCount++;

      return (STS$K_ERROR);
   }

   /****************************/
   /* generate cache file name */
   /****************************/

   pcdptr = (struct ProxyCacheDescrStruct*)tkptr->ResponseBufferPtr;
   pcdptr->CacheVersion = PROXY_CACHE_FILE_VERSION;

   zptr = (sptr = tkptr->ResponseBufferPtr) + tkptr->ResponseBufferSize;
   sptr += sizeof(struct ProxyCacheDescrStruct);
   UrlPtr = sptr;
   for (cptr = "http://";
        *cptr && sptr < zptr;
        *sptr++ = *cptr++);
   for (cptr = tkptr->RequestHostNamePort;
        *cptr && sptr < zptr;
        *sptr++ = *cptr++);
   /* copy in the path portion, stopping at any query string */
   for (cptr = tkptr->RequestUriPtr;
        *cptr && *cptr != '?' && sptr < zptr;
        *sptr++ = *cptr++);

   /* if cache information block overflowed then just forget it! */
   if (sptr >= zptr)
   {
      if (Debug) fprintf (stdout, "URI overflow\n");

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY_CACHE))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                    "CACHE READ URI overflow");

      return (STS$K_ERROR);
   }

   /* the terminating null is included in this length */
   *sptr++ = '\0';
   pcdptr->UrlLength = UrlLength = sptr - UrlPtr;

   /* now the currently free space in the buffer follows the description */
   tkptr->ResponseBufferCurrentPtr = sptr;
   tkptr->ResponseBufferRemaining = tkptr->ResponseBufferSize -
                                    (tkptr->ResponseBufferCurrentPtr -
                                     tkptr->ResponseBufferPtr);

   if (Debug) fprintf (stdout, "%d |%s|\n", UrlLength, UrlPtr);

   /* flag that this request is suitable for caching */
   tkptr->ProxyCacheSuitable = true;

   /* generate an MD5 digest representing the "http://host-name:port/path" */
   Md5HexString (UrlPtr, UrlLength, tkptr->ProxyCacheMd5HexDigest);
   if (Debug) fprintf (stdout, "Md5 |%s|\n", tkptr->ProxyCacheMd5HexDigest);

   /* using the MD5 digest generate a unique cache file name */
   sptr = tkptr->ProxyCacheFileName;
   for (cptr = PROXY_CACHE_ROOT; *cptr; *sptr++ = *cptr++);
   if (ProxyCacheDeviceDirOrg == PROXY_CACHE_DIR_ORG_FLAT256)
   {
      *sptr++ = toupper(tkptr->ProxyCacheMd5HexDigest[0]);
      *sptr++ = toupper(tkptr->ProxyCacheMd5HexDigest[1]);
      cptr = tkptr->ProxyCacheMd5HexDigest + 2;
   }
   else
   {
      /* PROXY_CACHE_DIR_ORG_64X64 */
      *sptr++ = toupper(tkptr->ProxyCacheMd5HexDigest[0]);
      switch (toupper(tkptr->ProxyCacheMd5HexDigest[1]))
      {
         case '0' : *sptr++ = '0'; *sptr++ = '.'; *sptr++ = '0'; break;
         case '1' : *sptr++ = '0'; *sptr++ = '.'; *sptr++ = '1'; break;
         case '2' : *sptr++ = '0'; *sptr++ = '.'; *sptr++ = '2'; break;
         case '3' : *sptr++ = '0'; *sptr++ = '.'; *sptr++ = '3'; break;
         case '4' : *sptr++ = '1'; *sptr++ = '.'; *sptr++ = '0'; break;
         case '5' : *sptr++ = '1'; *sptr++ = '.'; *sptr++ = '1'; break;
         case '6' : *sptr++ = '1'; *sptr++ = '.'; *sptr++ = '2'; break;
         case '7' : *sptr++ = '1'; *sptr++ = '.'; *sptr++ = '3'; break;
         case '8' : *sptr++ = '2'; *sptr++ = '.'; *sptr++ = '0'; break;
         case '9' : *sptr++ = '2'; *sptr++ = '.'; *sptr++ = '1'; break;
         case 'A' : *sptr++ = '2'; *sptr++ = '.'; *sptr++ = '2'; break;
         case 'B' : *sptr++ = '2'; *sptr++ = '.'; *sptr++ = '3'; break;
         case 'C' : *sptr++ = '3'; *sptr++ = '.'; *sptr++ = '0'; break;
         case 'D' : *sptr++ = '3'; *sptr++ = '.'; *sptr++ = '1'; break;
         case 'E' : *sptr++ = '3'; *sptr++ = '.'; *sptr++ = '2'; break;
         case 'F' : *sptr++ = '3'; *sptr++ = '.'; *sptr++ = '3'; break;
         default : *sptr++ = 'X'; *sptr++ = '.'; *sptr++ = 'X';
      } 
      *sptr++ = toupper(tkptr->ProxyCacheMd5HexDigest[2]);
      cptr = tkptr->ProxyCacheMd5HexDigest + 3;
   }
   *sptr++ = ']';
   while (*cptr) *sptr++ = toupper(*cptr++);
   for (cptr = ".HTC;1"; *cptr; *sptr++ = *cptr++);
   *sptr = '\0';
   tkptr->ProxyCacheFileNameLength = sptr - tkptr->ProxyCacheFileName;
   if (Debug)
      fprintf (stdout, "ProxyCacheFileName |%s|\n", tkptr->ProxyCacheFileName);

   /*******************/
   /* parse file name */
   /*******************/

   tkptr->ReadFab = cc$rms_fab;
   tkptr->ReadFab.fab$l_ctx = tkptr;
   tkptr->ReadFab.fab$l_fna = tkptr->ProxyCacheFileName;
   tkptr->ReadFab.fab$b_fns = tkptr->ProxyCacheFileNameLength;
   tkptr->ReadFab.fab$l_nam = &tkptr->FileNam;
   tkptr->ReadFab.fab$b_fac = FAB$M_GET | FAB$M_BIO; 
   tkptr->ReadFab.fab$b_shr = FAB$M_SHRGET;
   tkptr->ReadFab.fab$l_xab = &tkptr->FileXabDat;

   /* initialize the NAM block */
   tkptr->FileNam = cc$rms_nam;
   tkptr->FileNam.nam$l_esa = tkptr->ExpandedFileName;
   tkptr->FileNam.nam$b_ess = sizeof(tkptr->ExpandedFileName)-1;

   /* date/time extended attribute block */
   tkptr->FileXabDat = cc$rms_xabdat;

   /* asynchronous service */
   tkptr->ReadFab.fab$l_fop |= FAB$M_ASY;
   status = sys$parse (&tkptr->ReadFab, &ProxyCacheReadAcpInfo,
                                        &ProxyCacheReadAcpInfo);
   if (Debug) fprintf (stdout, "sys$parse() %%X%08.08X\n", status);

   return (SS$_NORMAL);
} 

/*****************************************************************************/
/*
Get the file size and creation date/time (document last modified) of the file.

This function uses the ACP-QIO interface detailed in the "OpenVMS I/O User's 
Reference Manual", and is probably as fast as we can get for this type of file
system functionality!
*/ 

ProxyCacheReadAcpInfo (struct FAB *FabPtr)

{
   static $DESCRIPTOR (DeviceDsc, "");

   int  status;
   struct ProxyTaskStruct  *tkptr;
   struct ProxyCacheFileAcpStruct  *faptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
         "ProxyCacheReadAcpInfo() sts: %%X%08.08X stv: %%X%08.08X\n",
         FabPtr->fab$l_sts, FabPtr->fab$l_stv);

   /* get the task pointer via the context block */
   tkptr = FabPtr->fab$l_ctx;

   if (VMSnok (status = tkptr->ReadFab.fab$l_sts))
   {
      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY_CACHE))
      {
         /* here directory not found means file not found! */
         if (status == RMS$_DNF)
            WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                       "CACHE READ not found !AZ",
                       tkptr->ProxyCacheFileName);
         else
            WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                       "CACHE READ parse fail !AZ %X!8XL %!%M",
                       tkptr->ProxyCacheFileName, status, status);
      }

      /* directory not found means file could not be found! */
      if (ProxyReportCacheLog)
         if (status != RMS$_DNF)
            WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, file parse error (!AZ !UL)\n-!%M\n \\!AZ\\\n",
               Utility, 0, FI_LI, status, tkptr->ProxyCacheFileName);

      ProxyReadCacheFailed (tkptr);
      return;
   }

   tkptr->ParseInUse = true;

   faptr = &tkptr->FileAcpData;

   /* assign a channel to the disk device containing the file */
   DeviceDsc.dsc$a_pointer = tkptr->FileNam.nam$l_dev;
   DeviceDsc.dsc$w_length = tkptr->FileNam.nam$b_dev;
   if (Debug)
      fprintf (stdout, "device |%*.*s|\n",
               tkptr->FileNam.nam$b_dev, tkptr->FileNam.nam$b_dev,
               tkptr->FileNam.nam$l_dev);

   status = sys$assign (&DeviceDsc, &faptr->Channel, 0, 0, 0);
   if (Debug) fprintf (stdout, "sys$assign() %%X%08.08X\n", status);
   if (VMSnok (status)) return (status);

   /* set up the File Information Block for the ACP interface */
   faptr->FileFibAcpDsc.dsc$w_length = sizeof(struct fibdef);
   faptr->FileFibAcpDsc.dsc$a_pointer = &faptr->FileFib;

   memcpy (&faptr->FileFib.fib$w_did, &tkptr->FileNam.nam$w_did, 6);

   faptr->FileNameAcpDsc.dsc$a_pointer = tkptr->FileNam.nam$l_name;
   faptr->FileNameAcpDsc.dsc$w_length = tkptr->FileNam.nam$b_name +
                                        tkptr->FileNam.nam$b_type +
                                        tkptr->FileNam.nam$b_ver;
   if (Debug)
      fprintf (stdout, "name |%*.*s|\n",
               faptr->FileNameAcpDsc.dsc$w_length,
               faptr->FileNameAcpDsc.dsc$w_length,
               faptr->FileNameAcpDsc.dsc$a_pointer);

   faptr->FileAtr[0].atr$w_size = sizeof(faptr->CdtBinTime);
   faptr->FileAtr[0].atr$w_type = ATR$C_CREDATE;
   faptr->FileAtr[0].atr$l_addr = &faptr->CdtBinTime;
   faptr->FileAtr[1].atr$w_size = sizeof(faptr->RdtBinTime);
   faptr->FileAtr[1].atr$w_type = ATR$C_REVDATE;
   faptr->FileAtr[1].atr$l_addr = &faptr->RdtBinTime;
   faptr->FileAtr[2].atr$w_size = sizeof(faptr->EdtBinTime);
   faptr->FileAtr[2].atr$w_type = ATR$C_EXPDATE;
   faptr->FileAtr[2].atr$l_addr = &faptr->EdtBinTime;
   faptr->FileAtr[3].atr$w_size = sizeof(faptr->AscDates);
   faptr->FileAtr[3].atr$w_type = ATR$C_ASCDATES;
   faptr->FileAtr[3].atr$l_addr = &faptr->AscDates;
   faptr->FileAtr[4].atr$w_size = sizeof(faptr->RecAttr);
   faptr->FileAtr[4].atr$w_type = ATR$C_RECATTR;
   faptr->FileAtr[4].atr$l_addr = &faptr->RecAttr;
   faptr->FileAtr[5].atr$w_size =
      faptr->FileAtr[5].atr$w_type =
      faptr->FileAtr[5].atr$l_addr = 0;

   status = sys$qio (0, faptr->Channel, IO$_ACCESS,
                     &faptr->AcpIOsb, &ProxyCacheReadAcpInfoAst, tkptr, 
                     &faptr->FileFibAcpDsc, &faptr->FileNameAcpDsc, 0, 0,
                     &faptr->FileAtr, 0);
   if (Debug) fprintf (stdout, "sys$qio() %%X%08.08X\n", status);

   return (SS$_NORMAL);
}

/****************************************************************************/
/*
*/

ProxyCacheReadAcpInfoAst (struct ProxyTaskStruct *tkptr)

{
   int  status,
        AccessHours,
        AgeHours,
        LoadHours;
   unsigned long  EndOfFileVbn;
   unsigned long  CurrentBinTime[2];
   struct ProxyCacheFileAcpStruct  *faptr;
   struct RequestStruct  *rqptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyCacheReadAcpInfoAst() %%X%08.08X\n",
               tkptr->FileAcpData.AcpIOsb.Status);

   /* get the file ACP pointer from the task structure */
   faptr = &tkptr->FileAcpData;

   sys$dassgn (faptr->Channel);

   if (VMSnok (status = faptr->AcpIOsb.Status))
   {
      /*************/
      /* ACP error */
      /*************/

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY_CACHE))
      {
         if (status == SS$_NOSUCHFILE)
            WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                       "CACHE READ not found !AZ",
                       tkptr->ProxyCacheFileName);
         else
            WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                       "CACHE ACP fail !AZ %X!8XL %!%M",
                       tkptr->ProxyCacheFileName, status, status);
      }

      if (ProxyReportCacheLog)
         if (status != SS$_NOSUCHFILE)
            WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, file ACP error (!AZ !UL)\n-!%M\n \\!AZ\\\n",
               Utility, 0, FI_LI, status, tkptr->ProxyCacheFileName);

      ProxyReadCacheFailed (tkptr);
      return;
   }

   ProxyAccounting.CacheReadCount++;

   /* note that the cache file at least existed at the time it was checked! */
   tkptr->ProxyCacheFileExisted = true;

   EndOfFileVbn = faptr->RecAttr.EndOfFileVbnLo +
                  (faptr->RecAttr.EndOfFileVbnHi << 16);
   if (Debug)
      fprintf (stdout, "EndOfFileVbn: %d FirstFreeByte %d\n",
               EndOfFileVbn, faptr->RecAttr.FirstFreeByte);

   if (EndOfFileVbn <= 1)
      tkptr->ProxyCacheFileSizeInBytes = faptr->RecAttr.FirstFreeByte;
   else
      tkptr->ProxyCacheFileSizeInBytes = ((EndOfFileVbn-1) << 9) +
                                         faptr->RecAttr.FirstFreeByte;
   if (Debug)
      fprintf (stdout, "file size %d bytes\n",
               tkptr->ProxyCacheFileSizeInBytes); 

   if (tkptr->WatchItem &&
       (WatchEnabled & WATCH_PROXY_CACHE))
   {
      /* WATCH is in use here, generate these now, not later! */
      sys$gettim (&CurrentBinTime);
      AgeHours = ProxyCacheAgeHours (&CurrentBinTime, &faptr->CdtBinTime);
      LoadHours = ProxyCacheAgeHours (&CurrentBinTime, &faptr->RdtBinTime);
      AccessHours = ProxyCacheAgeHours (&CurrentBinTime, &faptr->EdtBinTime);
      WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
"CACHE READ (hrs/days) age !UL/!UL, load !UL/!UL, access !UL/!UL (!UL), !AZ",
         AgeHours, AgeHours/24,
         LoadHours, LoadHours/24,
         AccessHours, AccessHours/24,
         faptr->AscDates.RevisionCount,
         tkptr->ProxyCacheFileName);
   }

   /******************/
   /* check currency */
   /******************/

   if (ProxyCacheAllowReload &&
       tkptr->RequestPragmaNoCache)
   {
      /*******************/
      /* pragma no-cache */
      /*******************/

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY_CACHE))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                    "CACHE READ pragma no-cache RELOAD");

      ProxyReadCacheFailed (tkptr);
      return;
   }

   if (!(tkptr->WatchItem &&
         (WatchEnabled & WATCH_PROXY_CACHE)))
   {
      /* WATCH is not in use here and so these will not have been generated */
      sys$gettim (&CurrentBinTime);
      AgeHours = ProxyCacheAgeHours (&CurrentBinTime, &faptr->CdtBinTime);
      LoadHours = ProxyCacheAgeHours (&CurrentBinTime, &faptr->RdtBinTime);
   }

   if (ProxyCacheReloadAge (AgeHours, LoadHours))
   {
      /*************/
      /* age limit */
      /*************/

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY_CACHE))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                    "CACHE READ age limit reload");

      ProxyReadCacheFailed (tkptr);
      return;
   }

   /***************************************/
   /* check any request if-modified-since */
   /***************************************/

   if ((rqptr = tkptr->RequestPtr) != NULL)
   {
      if ((rqptr->rqTime.IfModifiedSinceVMS64bit[0] ||
           rqptr->rqTime.IfModifiedSinceVMS64bit[1]) &&
          !rqptr->PragmaNoCache)
      {
         /*********************/
         /* if modified since */
         /*********************/

/*
         if (VMSnok (status =
             HttpIfModifiedSince (rqptr, &faptr->CdtBinTime,
                                  tkptr->ProxyCacheFileSizeInBytes)))
*/
         if (VMSnok (status =
             HttpIfModifiedSince (rqptr, &faptr->CdtBinTime, -1)))
         {
            /* task status LIB$_NEGTIM if not modified/sent */

            if (tkptr->WatchItem &&
                (WatchEnabled & WATCH_PROXY_CACHE))
               WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                          "CACHE READ not modified");

            /* update the last-accessed time even for not-modified! */
            sys$gettim (&CurrentBinTime);
            ProxyCacheSetLastAccessed (&tkptr->FileNam,
                                       &faptr->RdtBinTime,
                                       &CurrentBinTime);

            ProxyAccounting.CacheRead304Count++;
            /* the 304 header length */
            tkptr->ProxyCacheReadBytes = rqptr->rqResponse.HeaderLength;

            ProxyEnd (tkptr);
            return;
         }
      }
   }

   /*****************/
   /* open the file */
   /*****************/

   /* asynchronous service */
   tkptr->ReadFab.fab$l_fop |= FAB$M_ASY;
   status = sys$open (&tkptr->ReadFab, &ProxyCacheReadConnect,
                                       &ProxyCacheReadConnect);
   if (Debug) fprintf (stdout, "sys$open() %%X%08.08X\n", status);
}

/*****************************************************************************/
/*
Check whether the cache file open succeded.  If it didn't then call the AST
function supplied with the call to ProxyCacheReadBegin().  This will commence
an attempt to supply the request from the network.
*/

ProxyCacheReadConnect (struct FAB *FabPtr)

{
   int  status;
   unsigned long  CurrentBinTime[2];
   struct ProxyTaskStruct *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
         "ProxyCacheReadConnect() sts: %%X%08.08X stv: %%X%08.08X\n",
         FabPtr->fab$l_sts, FabPtr->fab$l_stv);

   /* get the task pointer from the context block */
   tkptr = FabPtr->fab$l_ctx;

   if (VMSnok (status = tkptr->ReadFab.fab$l_sts))
   {
      /********************/
      /* sys$open() error */
      /********************/

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY_CACHE))
      {
         if (status == RMS$_FNF || status == RMS$_DNF)
            WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                       "CACHE READ not found");
         else
            WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                       "CACHE READ open fail !AZ %X!8XL %!%M",
                       tkptr->ProxyCacheFileName, status, status);
      }

      if (status != RMS$_FNF &&
          status != RMS$_DNF)
      {
         if (ProxyReportCacheLog)
            WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, file open error (!AZ !UL)\n-!%M\n \\!AZ\\\n",
               Utility, 0, FI_LI, status, tkptr->ProxyCacheFileName);
      }

      ProxyReadCacheFailed (tkptr);
      return;
   }

   tkptr->ParseInUse = false;

   /***********************/
   /* connect to the file */
   /***********************/

   sys$gettim (&CurrentBinTime);
   ProxyCacheSetLastAccessed (&tkptr->FileNam,
                              &tkptr->FileXabDat.xab$q_rdt,
                              &CurrentBinTime);

   tkptr->FileNam.nam$l_ver[tkptr->FileNam.nam$b_ver] = '\0';
   if (Debug)
      fprintf (stdout, "ExpandedFileName |%s|\n", tkptr->ExpandedFileName);

   tkptr->FileRab = cc$rms_rab;
   tkptr->FileRab.rab$l_fab = &tkptr->ReadFab;
   tkptr->FileRab.rab$l_ctx = tkptr;
   tkptr->FileRab.rab$l_rop = RAB$M_ASY;

   status = sys$connect (&tkptr->FileRab, ProxyCacheReadConnectAst,
                                          ProxyCacheReadConnectAst);
   if (Debug) fprintf (stdout, "sys$connect() %%X%08.08X\n", status);
} 

/*****************************************************************************/
/*
If the RAB can't be connected it's a serious error.  Report it to the process
log and generate an error message for the client.
*/

ProxyCacheReadConnectAst (struct RAB *RabPtr)

{
   int  status;
   struct ProxyTaskStruct *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
         "ProxyCacheReadConnectAst() sts: %%X%08.08X stv: %%X%08.08X\n",
         RabPtr->rab$l_sts, RabPtr->rab$l_stv);

   /* get the task pointer from the context block */
   tkptr = RabPtr->rab$l_ctx;

   if (VMSnok (status = tkptr->FileRab.rab$l_sts))
   {
      /***********************/
      /* sys$connect() error */
      /***********************/

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY_CACHE))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                    "CACHE READ connect fail !AZ %X!8XL %!%M",
                    tkptr->ProxyCacheFileName, status, status);

      if (ProxyReportCacheLog)
         WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, file read connect error (!AZ !UL)\n-!%M\n \\!AZ\\\n",
            Utility, 0, FI_LI, status, tkptr->ProxyCacheFileName);

      tkptr->RequestPtr->rqResponse.HttpStatus = 500;
      tkptr->RequestPtr->rqResponse.ErrorTextPtr = tkptr->RequestHostNamePort;
      ErrorVmsStatus (tkptr->RequestPtr, status, FI_LI);
      ProxyCacheReadEnd (tkptr);
      return;
   }

   /* only successful responses are ever cached, hence ... */
   tkptr->ResponseStatusCode = 200;
   memcpy (tkptr->ResponseStatusCodeString, "200", 4);
   if (tkptr->RequestPtr != NULL)
      tkptr->RequestPtr->rqResponse.HttpStatus = tkptr->ResponseStatusCode;

   tkptr->ProxyCacheReadBytes = 0;;

   /* fake the first network write status */
   tkptr->RequestPtr->rqNet.WriteIOsb.Status = SS$_NORMAL;

   ProxyCacheReadNext (tkptr->RequestPtr);
} 

/*****************************************************************************/
/*
************
*** NOTE ***  This function takes a pointer to a request!!!
************

Queue a read of the next series of Virtual Blocks from the file.  When the 
read completes call ProxyCacheNextAST() function to send the data to the
client.  Don't bother to test any status here, the AST routine will do that!
*/ 

ProxyCacheReadNext (struct RequestStruct *rqptr)

{
   int  status;
   struct ProxyTaskStruct  *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyCacheReadNext()\n");

   tkptr = rqptr->ProxyTaskPtr; 

   if (VMSnok (status = rqptr->rqNet.WriteIOsb.Status))
   {
      /******************************/
      /* client network write error */
      /******************************/

      if (Debug)
         fprintf (stdout, "rqptr->rqNet.WriteIOsb.Status %%X%08.08X\n",
                  rqptr->rqNet.WriteIOsb.Status);

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY_CACHE))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                    "CACHE READ client write fail %X!8XL %!%M", status, status);

      ProxyCacheReadEnd (tkptr);
      return;
   }

   /*********************/
   /* first/next blocks */
   /*********************/

   if (tkptr->FileRab.rab$l_bkt)
   {
      /* get next lot of virtual blocks */
      tkptr->FileRab.rab$l_bkt += tkptr->FileRab.rab$w_usz >> 9;
   }
   else
   {
      /* "... start at the very beginning, a very good place to start ..." */
      tkptr->FileRab.rab$l_bkt = 1;
      tkptr->FileRab.rab$l_ubf = tkptr->ResponseBufferPtr;
      /* make buffer size an even number of 512 byte blocks */
      tkptr->FileRab.rab$w_usz = tkptr->ResponseBufferSize & 0xfe00;
   }

   sys$read (&tkptr->FileRab, &ProxyCacheReadNextAst, &ProxyCacheReadNextAst);
}

/*****************************************************************************/
/*
The read of the next series of Virtual Blocks from the file has completed.  
Post-process and/or queue a network write to the client.  When the network 
write completes it will call the function ProxyCacheReadNextAst() to queue a
read of the next series of blocks.
*/ 

ProxyCacheReadNextAst (struct RAB *RabPtr)

{
   int  status,
        DataLength;
   char  *BodyPtr,
         *DataPtr,
         *HeaderPtr,
         *UrlPtr;
   struct RequestStruct  *rqptr;
   struct ProxyCacheDescrStruct  *pcdptr;
   struct ProxyTaskStruct  *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
               "ProxyCacheReadNextAst() sts: %%X%08.08X stv: %%X%08.08X\n",
               RabPtr->rab$l_sts, RabPtr->rab$l_stv);

   /* get the task pointer from the context block */
   tkptr = RabPtr->rab$l_ctx;
   /* get associated request */
   rqptr = tkptr->RequestPtr;

   if (VMSnok (status = tkptr->FileRab.rab$l_sts))
   {
      /*************************/
      /* cache file read error */
      /*************************/

      if (status == RMS$_EOF)
      {
         if (tkptr->WatchItem &&
             (WatchEnabled & WATCH_PROXY_CACHE))
            WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                       "CACHE READ eof !UL bytes",
                       tkptr->ProxyCacheReadBytes);

         ProxyCacheReadEnd (tkptr);
         return;
      }

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY_CACHE))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                    "CACHE READ fail %X!8XL %!%M", status, status);

      rqptr->rqResponse.HttpStatus = 500;
      rqptr->rqResponse.ErrorTextPtr = tkptr->RequestHostNamePort;
      ErrorVmsStatus (rqptr, status, FI_LI);
      ProxyCacheReadEnd (tkptr);
      return;
   }

   if (tkptr->FileRab.rab$l_bkt == 1)
   {
      /***************/
      /* first block */
      /***************/

      /* contains cache file description (lengths and request URL) */
      DataPtr = (char*)tkptr->FileRab.rab$l_ubf;
      DataLength = tkptr->FileRab.rab$w_rsz;
      pcdptr = (struct ProxyCacheDescrStruct*)tkptr->FileRab.rab$l_ubf;
      UrlPtr = DataPtr + sizeof(struct ProxyCacheDescrStruct);
      HeaderPtr = UrlPtr + pcdptr->UrlLength;
      BodyPtr = HeaderPtr + pcdptr->HeaderLength;

      if (Debug)
         fprintf (stdout, "ver: %d req: %d/%d hdr: %d/%d bdy: %d\n",
                  pcdptr->CacheVersion,  UrlPtr, pcdptr->UrlLength,
                  HeaderPtr, pcdptr->HeaderLength, BodyPtr);

      if (pcdptr->CacheVersion != PROXY_CACHE_FILE_VERSION)
      {
         /*********************************/
         /* version mismatch, delete file */
         /*********************************/

         if (tkptr->WatchItem &&
             (WatchEnabled & WATCH_PROXY_CACHE))
            WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                       "CACHE READ cache VERSION MISMATCH");

         tkptr->ReadFab.fab$l_fop |= FAB$M_DLT;
         /* synchronous service */
         tkptr->ReadFab.fab$l_fop &= ~FAB$M_ASY;
         status = sys$erase (&tkptr->ReadFab, 0, 0);
         if (Debug) fprintf (stdout, "sys$erase() %%X%08.08X\n", status);

         if (VMSnok (status))
            WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, file erase error (!AZ !UL)\n-!%M\n \\!AZ\\\n",
               Utility, 0, FI_LI, status, tkptr->ProxyCacheFileName);

         rqptr->rqResponse.HttpStatus = 500;
         ErrorGeneral (rqptr, ErrorProxyCacheVersion, FI_LI);
         ProxyCacheReadEnd (tkptr);
         return;
      }

      DataLength = DataLength - (HeaderPtr - DataPtr);
      DataPtr = HeaderPtr;
      tkptr->ProxyCacheReadBytes += DataLength;
   }
   else
   {
      DataPtr = tkptr->FileRab.rab$l_ubf;
      DataLength = tkptr->FileRab.rab$w_rsz;
      tkptr->ProxyCacheReadBytes += DataLength;
   }

   NetWrite (rqptr, &ProxyCacheReadNext, DataPtr, DataLength);
}

/*****************************************************************************/
/*
Close the cache file.  End the proxy request.
*/

ProxyCacheReadEnd (struct ProxyTaskStruct *tkptr)

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyCacheReadEnd()\n");

   /* close file asynchronously eventually ASTing to ProxyEnd() */
   tkptr->ReadFab.fab$l_fop |= FAB$M_ASY;
   status = sys$close (&tkptr->ReadFab, &ProxyCacheCloseAst_ProxyEnd,
                                        &ProxyCacheCloseAst_ProxyEnd);
   if (Debug) fprintf (stdout, "sys$close() %%X%08.08X\n", status);
} 

/*****************************************************************************/
/*
Begin to load a file to cache the contents of a proxied request.  First assess
whether the request meets the criteria for caching.  If it does not. If it does then
initialize the RMS structures for the file and call the create service, which
ASTs to ProxyCacheLoadConnect().  Check the success there.
*/

int ProxyCacheLoadBegin (struct ProxyTaskStruct *tkptr)

{
   int  status,
        ExpiresHours,
        LastModifiedHours;
   unsigned int  AllocationQuantity;
   unsigned long  CurrentBinTime [2];
   struct ProxyCacheDescrStruct  *pcdptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyCacheLoadBegin() %d\n", tkptr);

   if (!ProxyCacheFreeSpaceAvailable)
   {
      /* no file system space available for caching purposes */
      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY_CACHE))
      {
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                    "CACHE LOAD insufficient device space (!UL% max)",
                    ProxyCacheDeviceMaxPercent);
         ProxyMaintWatchDeviceStats ();
      }
      return (STS$K_ERROR);
   }

   sys$gettim (&CurrentBinTime);

   if (tkptr->ResponseLastModified[0])
      tkptr->ProxyCacheLastModifiedHours = LastModifiedHours =
         ProxyCacheAgeHours (&CurrentBinTime,
                             &tkptr->ResponseLastModifiedBinaryTime);

   if (tkptr->ResponseExpires[0])
      ExpiresHours = ProxyCacheAgeHours (&tkptr->ResponseExpiresBinaryTime,
                                         &CurrentBinTime);

   if (tkptr->ResponseStatusCodeString[0] != '2' ||
       tkptr->ResponsePragmaNoCache ||
#if COOKIE_THEN_NOT_CACHED
       tkptr->ResponseSetCookie ||
#endif
       tkptr->ResponseHttpVersion == HTTP_VERSION_0_9 ||
       !tkptr->ResponseLastModified[0] ||
       (tkptr->ResponseLastModified[0] && LastModifiedHours < 1) ||
       (tkptr->ResponseExpires[0] && ExpiresHours < 1) ||
       (tkptr->ResponseContentLength >= 0 &&
        (tkptr->ResponseContentLength >> 10) + 1 > ProxyCacheFileKBytesMax))
   {
      /****************/
      /* not cachable */
      /****************/

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY_CACHE))
      {
         char  String [256];

         String[0] = '\0';
         if (tkptr->ResponseStatusCodeString[0] != '2')
         {
            strcpy (String, "status ");
            strcat (String, tkptr->ResponseStatusCodeString);
         }
         if (tkptr->ResponsePragmaNoCache)
         {
            if (String[0]) strcat (String, ", ");
            strcat (String, "pragma no-cache");
         }
#if COOKIE_THEN_NOT_CACHED
         if (tkptr->ResponseSetCookie)
         {
            if (String[0]) strcat (String, ", ");
            strcat (String, "contains cookie");
         }
#endif
         if (tkptr->ResponseHttpVersion == HTTP_VERSION_0_9)
         {
            if (String[0]) strcat (String, ", ");
            strcat (String, "HTTP/0.9");
         }
         if (!tkptr->ResponseLastModified[0])
         {
            if (String[0]) strcat (String, ", ");
            strcat (String, "no last-modified");
         }
         if (tkptr->ResponseLastModified[0] && LastModifiedHours < 1)
         {
            if (String[0]) strcat (String, ", ");
            strcat (String, "last-modified < 1");
         }
         if (tkptr->ResponseExpires[0] && ExpiresHours < 1)
         {
            if (String[0]) strcat (String, ", ");
            strcat (String, "expires < 1");
         }
         if (tkptr->ResponseContentLength >= 0 &&
             (tkptr->ResponseContentLength >> 10) + 1 > ProxyCacheFileKBytesMax)
         {
            char  *cptr;

            for (cptr = String; *cptr; cptr++);
            if (String[0]) *(unsigned short*)cptr++ = ', ';
            sprintf (cptr, "content-length %d > %d kB",
                     (tkptr->ResponseContentLength >> 10) + 1,
                     ProxyCacheFileKBytesMax);
                     
         }
         if (!String[0]) strcpy (String, "?");

         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                    "CACHE LOAD not cachable: !AZ", String);
      }

      /* 'tkptr->ProxyCacheSuitable' checked method and query string */
      if (tkptr->ResponseStatusCode == 304)
      {
         if (tkptr->ProxyCacheFileExisted)
         {
            /*****************************/
            /* not modified, leave as-is */
            /*****************************/

            if (tkptr->WatchItem &&
                (WatchEnabled & WATCH_PROXY_CACHE))
               WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                          "CACHE LOAD not modified !AZ",
                          tkptr->ProxyCacheFileName);

            /* update both the load and access times to current */
            ProxyCacheSetLastAccessed (&tkptr->FileNam,
                                       &CurrentBinTime,
                                       &CurrentBinTime);

            return (STS$K_ERROR);
         }
      }

      /* it's not cacheable but already existed so delete it! */
      if (tkptr->ProxyCacheFileExisted)
      {
         /******************************/
         /* delete original cache file */
         /******************************/

         if (tkptr->WatchItem &&
             (WatchEnabled & WATCH_PROXY_CACHE))
            WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                       "CACHE LOAD delete !AZ", tkptr->ProxyCacheFileName);

         tkptr->ReadFab.fab$l_fop |= FAB$M_DLT;
         /* synchronous service */
         tkptr->ReadFab.fab$l_fop &= ~FAB$M_ASY;
         status = sys$erase (&tkptr->ReadFab, 0, 0);
         if (Debug) fprintf (stdout, "sys$erase() %%X%08.08X\n", status);

         if (ProxyReportCacheLog)
            if (VMSnok (status))
               WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, file erase error (!AZ !UL)\n-!%M\n \\!AZ\\\n",
                  Utility, 0, FI_LI, status, tkptr->ProxyCacheFileName);
      }

      tkptr->NotCacheable = true;
      ProxyAccounting.ResponseNotCacheableCount++;

      return (STS$K_ERROR);
   }

   /**************/
   /* begin load */
   /**************/

   ProxyAccounting.CacheWriteCount++;

   /* slip the header length into the cache file description block */
   pcdptr = (struct ProxyCacheDescrStruct*)tkptr->ResponseBufferPtr;
   pcdptr->HeaderLength = tkptr->ResponseHeaderLength;

   AllocationQuantity = sizeof(struct ProxyCacheDescrStruct) +
                        pcdptr->UrlLength +
                        tkptr->ResponseHeaderLength;
   if (tkptr->ResponseContentLength > 0)
      AllocationQuantity += tkptr->ResponseContentLength;
   AllocationQuantity = (AllocationQuantity >> 9) + 1;
   /* bit of a sanity check ... don't want to chew up the whole disk */
   if (AllocationQuantity > ProxyCacheAllocationQuantityMax)
      AllocationQuantity = ProxyCacheAllocationQuantityMax;
   if (Debug) fprintf (stdout, "alq: %d\n", AllocationQuantity);

   if (tkptr->WatchItem &&
       (WatchEnabled & WATCH_PROXY_CACHE))
   {
      char  *ReloadPtr;

      if (tkptr->ProxyCacheFileExisted)
         ReloadPtr = "RE";
      else
         ReloadPtr = "";
      if (tkptr->ResponseContentLength >= 0)
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                    "CACHE !AZLOAD !AZ content !UL bytes (!UL blocks)",
                    ReloadPtr,
                    tkptr->ProxyCacheFileName,
                    tkptr->ResponseContentLength,
                    AllocationQuantity);
      else
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                    "CACHE !AZLOAD !AZ content ? bytes (!UL blocks)",
                    ReloadPtr,
                    tkptr->ProxyCacheFileName,
                    AllocationQuantity);
   }

   /* if currently open then close ready to re-sys$create() */
   if (tkptr->ReadFab.fab$w_ifi)
   {
      /* synchronous service */
      tkptr->ReadFab.fab$l_fop &= ~FAB$M_ASY;
      status = sys$close (&tkptr->ReadFab, 0, 0);
      if (Debug) fprintf (stdout, "sys$close() %%X%08.08X\n", status);

      if (ProxyReportCacheLog)
         if (VMSnok (status))
            WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, file delete-on-close error (!AZ !UL)\n-!%M\n \\!AZ\\\n",
               Utility, 0, FI_LI, status, tkptr->ProxyCacheFileName);
   }

   tkptr->LoadFab = cc$rms_fab;
   tkptr->LoadFab.fab$l_alq = AllocationQuantity;
   tkptr->LoadFab.fab$l_ctx = tkptr;
   tkptr->LoadFab.fab$b_fac = FAB$M_PUT | FAB$M_TRN;
   tkptr->LoadFab.fab$l_fna = tkptr->ProxyCacheFileName;
   tkptr->LoadFab.fab$b_fns = tkptr->ProxyCacheFileNameLength;
   tkptr->LoadFab.fab$l_fop = FAB$M_CIF | FAB$M_SQO |
                              FAB$M_DFW | FAB$M_TEF;
   tkptr->LoadFab.fab$l_nam = &tkptr->FileNam;
   tkptr->LoadFab.fab$b_rat = 0;
   tkptr->LoadFab.fab$b_rfm = FAB$C_UDF;

   tkptr->LoadFab.fab$b_shr = FAB$M_NIL;
   tkptr->LoadFab.fab$l_xab = &tkptr->FileXabDat;

   /* initialize the name block */
   tkptr->FileNam = cc$rms_nam;
   tkptr->FileNam.nam$l_esa = tkptr->ExpandedFileName;
   tkptr->FileNam.nam$b_ess = sizeof(tkptr->ExpandedFileName)-1;

   /* date/time extended attribute block */
   tkptr->FileXabDat = cc$rms_xabdat;
   tkptr->FileXabDat.xab$l_nxt = &tkptr->FileXabPro;
   memcpy (&tkptr->FileXabDat.xab$q_cdt,
           &tkptr->ResponseLastModifiedBinaryTime,
           8);
   memcpy (&tkptr->FileXabDat.xab$q_edt, &CurrentBinTime, 8);

   /* protection extended attribute block */
   tkptr->FileXabPro = cc$rms_xabpro;
   /* W:RE,G:RE,O:RWED,S:RWED */
   tkptr->FileXabPro.xab$w_pro = 0xaa00;

   /* asynchronous service */
   tkptr->ReadFab.fab$l_fop |= FAB$M_ASY;
   status = sys$create (&tkptr->LoadFab, ProxyCacheLoadConnect,
                                         ProxyCacheLoadConnect);
   if (Debug) fprintf (stdout, "sys$create() %%X%08.08X\n", status);

   return (SS$_NORMAL);
} 

/*****************************************************************************/
/*
AST function delivered from ProxyCacheLoadBegin(). Check the success of the
file create. If not report it to the process log and forget about caching the
file. If OK initialize a RAB structure and call the connect service, which
ASTs to ProxyCacheLoadConnectAst(). Check the status there.
*/

ProxyCacheLoadConnect (struct FAB *FabPtr)

{
   struct ProxyTaskStruct *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
         "ProxyCacheLoadConnect() sts: %%X%08.08X stv: %%X%08.08X\n",
         FabPtr->fab$l_sts, FabPtr->fab$l_stv);

   tkptr = FabPtr->fab$l_ctx;

   if (VMSnok (status = tkptr->LoadFab.fab$l_sts))
   {
      /**********************/
      /* sys$create() error */
      /**********************/

      /* only try once per request to create a cache subdirectory */
      if (status == RMS$_DNF && !tkptr->ProxyCacheDirectoryName[0])
      {
         char  *cptr, *sptr;

         sptr = tkptr->ProxyCacheDirectoryName;
         for (cptr = PROXY_CACHE_ROOT; *cptr; *sptr++ = *cptr++);
         if (ProxyCacheDeviceDirOrg == PROXY_CACHE_DIR_ORG_FLAT256)
         {
            *sptr++ = toupper(tkptr->ProxyCacheMd5HexDigest[0]);
            *sptr++ = toupper(tkptr->ProxyCacheMd5HexDigest[1]);
         }
         else
         {
            /* PROXY_CACHE_DIR_ORG_64X64 */
            *sptr++ = toupper(tkptr->ProxyCacheMd5HexDigest[0]);
            switch (toupper(tkptr->ProxyCacheMd5HexDigest[1]))
            {
               case '0' : *sptr++ = '0'; *sptr++ = '.'; *sptr++ = '0'; break;
               case '1' : *sptr++ = '0'; *sptr++ = '.'; *sptr++ = '1'; break;
               case '2' : *sptr++ = '0'; *sptr++ = '.'; *sptr++ = '2'; break;
               case '3' : *sptr++ = '0'; *sptr++ = '.'; *sptr++ = '3'; break;
               case '4' : *sptr++ = '1'; *sptr++ = '.'; *sptr++ = '0'; break;
               case '5' : *sptr++ = '1'; *sptr++ = '.'; *sptr++ = '1'; break;
               case '6' : *sptr++ = '1'; *sptr++ = '.'; *sptr++ = '2'; break;
               case '7' : *sptr++ = '1'; *sptr++ = '.'; *sptr++ = '3'; break;
               case '8' : *sptr++ = '2'; *sptr++ = '.'; *sptr++ = '0'; break;
               case '9' : *sptr++ = '2'; *sptr++ = '.'; *sptr++ = '1'; break;
               case 'A' : *sptr++ = '2'; *sptr++ = '.'; *sptr++ = '2'; break;
               case 'B' : *sptr++ = '2'; *sptr++ = '.'; *sptr++ = '3'; break;
               case 'C' : *sptr++ = '3'; *sptr++ = '.'; *sptr++ = '0'; break;
               case 'D' : *sptr++ = '3'; *sptr++ = '.'; *sptr++ = '1'; break;
               case 'E' : *sptr++ = '3'; *sptr++ = '.'; *sptr++ = '2'; break;
               case 'F' : *sptr++ = '3'; *sptr++ = '.'; *sptr++ = '3'; break;
               default : *sptr++ = 'X'; *sptr++ = '.'; *sptr++ = 'X';
            } 
            *sptr++ = toupper(tkptr->ProxyCacheMd5HexDigest[2]);
         }
         *sptr++ = ']';
         *sptr = '\0';
         status = ProxyCacheCreateDirectory (tkptr->ProxyCacheDirectoryName);

         if (tkptr->WatchItem &&
             (WatchEnabled & WATCH_PROXY_CACHE))
         {
            if (VMSnok (status))
               WatchThis (tkptr->RequestPtr, FI_LI,
                          WATCH_PROXY_CACHE,
                          "CACHE DIRECTORY create fail !AZ %X!8XL %!%M",
                          tkptr->ProxyCacheDirectoryName, status, status);
            else
               WatchThis (tkptr->RequestPtr, FI_LI,
                          WATCH_PROXY_CACHE,
                          "CACHE DIRECTORY created !AZ",
                          tkptr->ProxyCacheDirectoryName);
         }

         /* now, one more time, attempt to create the file */
         status = sys$create (&tkptr->LoadFab, ProxyCacheLoadConnect,
                                               ProxyCacheLoadConnect);
         if (Debug) fprintf (stdout, "sys$create() %%X%08.08X\n", status);
         return;
      }

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY_CACHE))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                    "CACHE CREATE fail %X!8XL %!%M", status, status);

      /* sys$create() error */
      if (ProxyReportCacheLog)
         WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, file create error (!AZ !UL)\n-!%M\n \\!AZ\\\n",
            Utility, 0, FI_LI, status, tkptr->ProxyCacheFileName);

      /* explicitly call the function to continue transaction with client */
      ProxyResponseNetWrite (tkptr);
      return;
   }

   tkptr->FileNam.nam$l_ver[tkptr->FileNam.nam$b_ver] = '\0';
   if (Debug)
      fprintf (stdout, "ExpandedFileName |%s|\n", tkptr->ExpandedFileName);

   tkptr->FileRab = cc$rms_rab;
   tkptr->FileRab.rab$l_fab = &tkptr->LoadFab;
   tkptr->FileRab.rab$l_ctx = tkptr;
   tkptr->FileRab.rab$b_rac = RAB$C_SEQ;
   /* asynchronous truncate on put, in case file existed and we're reloading*/
   tkptr->FileRab.rab$l_rop = RAB$M_ASY | RAB$M_TPT;

   status = sys$connect (&tkptr->FileRab, ProxyCacheLoadConnectAst,
                                          ProxyCacheLoadConnectAst);
   if (Debug) fprintf (stdout, "sys$connect() %%X%08.08X\n", status);
} 

/*****************************************************************************/
/*
AST function delivered from ProxyCacheLoadConnect(). Check the status of the
connect service. If not OK report it via the process log and forget about
caching the file.  If sucessful and the file did not previously exist the begin
to write.  If it did exist then we need to rewind the file, read the first
record (to establish a record context) and then truncate the file.  Whay all
this trouble?  Because file name deletion and creation is fairly expensive with
VMS (especially if the directory is crowded), so avoid whenever we can!
*/

ProxyCacheLoadConnectAst (struct RAB *RabPtr)

{
   /* it's an undefine-format file so any buffer size really will do */
   static char DummyGetBuffer[512];

   int  status;
   struct ProxyTaskStruct *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
         "ProxyCacheLoadConnectAst() sts: %%X%08.08X stv: %%X%08.08X\n",
         RabPtr->rab$l_sts, RabPtr->rab$l_stv);

   tkptr = RabPtr->rab$l_ctx;

   if (VMSnok (status = tkptr->FileRab.rab$l_sts))
   {
      /***********************/
      /* sys$connect() error */
      /***********************/

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY_CACHE))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                    "CACHE CONNECT fail %X!8XL %!%M", status, status);

      if (ProxyReportCacheLog)
         WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, file connect error (!AZ !UL)\n-!%M\n \\!AZ\\\n",
            Utility, 0, FI_LI, status, tkptr->ProxyCacheFileName);

      /* delete file as closed, ensure an asynchronous close service */
      tkptr->LoadFab.fab$l_fop |= FAB$M_ASY | FAB$M_DLT;
      /* AST the function to continue the transaction with client */
      status = sys$close (&tkptr->LoadFab, &ProxyCacheCloseAst_NetWrite,
                                           &ProxyCacheCloseAst_NetWrite);
      if (Debug) fprintf (stdout, "sys$close() %%X%08.08X\n", status);
      return;
   }

   ProxyCacheLoadWrite (tkptr);
} 

/*****************************************************************************/
/*
Called after a chunk of data has been read from the remote server to write
that chunk into the cache file.  AST to ProxyCacheLoadWriteAst() to check the
success of the write.
*/

ProxyCacheLoadWrite (struct ProxyTaskStruct *tkptr)

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyCacheLoadWrite() %d\n", tkptr);

   if (tkptr->ResponseContentLength < 0)
   {
      /* response had no content-length, check the quantity received so far */
      if (((tkptr->ResponseBytes - tkptr->ResponseHeaderLength) >> 10) + 1 >
          ProxyCacheFileKBytesMax)
      {
         /*********************************/
         /* exceeds configuration maximum */
         /*********************************/

         if (tkptr->WatchItem &&
             (WatchEnabled & WATCH_PROXY_CACHE))
            WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
               "CACHE LOAD abort !UL exceeds !UL kB",
               ((tkptr->ResponseBytes - tkptr->ResponseHeaderLength) >> 10) + 1,
               ProxyCacheFileKBytesMax);

         /* close/delete file, fab$w_ifi will then indicate no cache file */
         tkptr->LoadFab.fab$l_fop |= FAB$M_DLT;
         /* synchronous service */
         tkptr->LoadFab.fab$l_fop &= ~FAB$M_ASY;
         status = sys$close (&tkptr->LoadFab, 0, 0);
         if (Debug) fprintf (stdout, "sys$close() %%X%08.08X\n", status);

         if (ProxyReportCacheLog)
            if (VMSnok (status))
               WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, file delete-on-close error (!AZ !UL)\n-!%M\n \\!AZ\\\n",
                  Utility, 0, FI_LI, status, tkptr->ProxyCacheFileName);

         /* explicitly call the function to continue transaction with client */
         ProxyResponseNetWrite (tkptr);
         return;
      }
   }

   tkptr->FileRab.rab$l_rbf = tkptr->ResponseBufferCachePtr;
   tkptr->FileRab.rab$w_rsz = tkptr->ResponseBufferCacheCount;

   sys$put (&tkptr->FileRab, &ProxyCacheLoadWriteAst,
                             &ProxyCacheLoadWriteAst);
} 

/*****************************************************************************/
/*
AST delivered from ProxyCacheLoadWrite().  Check the status of the write and
if successful declare the AST originally passed to that routine to continue
retrieving the request from the remote server.  If an error was encountered
delete as the file is closed and forget about further caching the response
(although in all these cases continuing to retrieve it via the network!)
*/

ProxyCacheLoadWriteAst (struct RAB *RabPtr)

{
   int  status;
   struct ProxyTaskStruct *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
         "ProxyCacheLoadWriteAst() sts: %%X%08.08X stv: %%X%08.08X rsz: %d\n",
         RabPtr->rab$l_sts,
         RabPtr->rab$l_stv,
         RabPtr->rab$w_rsz);

   tkptr = RabPtr->rab$l_ctx;

   if (VMSnok (status = tkptr->FileRab.rab$l_sts))
   {
      /**************************/
      /* cache file write error */
      /**************************/

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY_CACHE))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                    "CACHE WRITE fail %X!8XL %!%M", status, status);

      if (ProxyReportCacheLog)
         WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, file write error (!AZ !UL)\n-!%M\n \\!AZ\\\n",
            Utility, 0, FI_LI, status, tkptr->ProxyCacheFileName);

      /* delete file as closed, ensure an asynchronous close service */
      tkptr->LoadFab.fab$l_fop |= FAB$M_ASY | FAB$M_DLT;
      status = sys$close (&tkptr->LoadFab, &ProxyCacheCloseAst_NetWrite,
                                           &ProxyCacheCloseAst_NetWrite);
      return;
   }

   ProxyResponseNetWrite (tkptr);
} 

/*****************************************************************************/
/*
Called by ProxyCacheEnd() when the response is complete.  Check if it meets the
criteria to be retained (i.e. essentially a completely successful transaction). 
If it does then just close the file.  If not then delete it as it is closed. 
The sys$close() are asynchronous, AST to ProxyEnd() to complete the
transaction.
*/

ProxyCacheLoadEnd (struct ProxyTaskStruct *tkptr)

{
   int  status,
        ClientWriteStatus,
        ProxyReadStatus;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyCacheLoadEnd() %d\n", tkptr);

   ClientWriteStatus = SS$_NORMAL;
   if (tkptr->RequestPtr != NULL)
      if (VMSnok (tkptr->RequestPtr->rqNet.WriteIOsb.Status))
         ClientWriteStatus = tkptr->RequestPtr->rqNet.WriteIOsb.Status;
   ProxyReadStatus = tkptr->ProxyReadIOsb.Status;
   /* normal for servers to abruptly disconnect at the end of a request */
   if (ProxyReadStatus == SS$_LINKDISCON) ProxyReadStatus = SS$_NORMAL;

   if ((tkptr->ResponseContentLength >= 0 &&
        tkptr->ResponseBodyLength != tkptr->ResponseContentLength) ||
       VMSnok (ClientWriteStatus) ||
       VMSnok (ProxyReadStatus))
   {
      if (Debug) fprintf (stdout, "FAILED!\n");

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY_CACHE))
      {
         if (VMSnok (ProxyReadStatus))
            WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                       "CACHE LOAD FAIL server read %X!8XL %!%M",
                       ProxyReadStatus, ProxyReadStatus);
         else
         if (VMSnok (ClientWriteStatus))
            WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                       "CACHE LOAD FAIL client write %X!8XL %!%M",
                       ClientWriteStatus, ClientWriteStatus);
         else
         if (tkptr->ResponseContentLength >= 0)
            WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                       "CACHE LOAD FAIL received:!UL expecting:!UL",
                        tkptr->ResponseBodyLength,
                        tkptr->ResponseContentLength);
         else
            WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
                       "CACHE LOAD FAIL reason unknown");
      }

      if (ProxyReportCacheLog)
      {
         if (VMSnok (ProxyReadStatus))
            WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, cache load read fail (!AZ !UL)\n-!%M\n \\!AZ\\\n",
               Utility, 0, FI_LI, ProxyReadStatus, tkptr->ProxyCacheFileName);
         else 
         if (VMSnok (ClientWriteStatus))
            WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, cache load write fail (!AZ !UL)\n-!%M\n \\!AZ\\\n",
               Utility, 0, FI_LI, ClientWriteStatus, tkptr->ProxyCacheFileName);
         else 
         if (tkptr->ResponseContentLength >= 0)
            WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, cache load fail, received:!UL expecting:!UL (!AZ !UL)\n\
 \\!AZ\\\n",
               Utility, 0,
               tkptr->ResponseBodyLength, tkptr->ResponseContentLength,
               FI_LI, tkptr->ProxyCacheFileName);
         else
            WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, cache load fail (!AZ !UL)\n \\!AZ\\\n",
               Utility, 0, FI_LI, tkptr->ProxyCacheFileName);
      }

      /* close/delete file asynchronously AST calling ProxyEnd() */
      tkptr->LoadFab.fab$l_fop |= FAB$M_DLT | FAB$M_ASY;
      status = sys$close (&tkptr->LoadFab, &ProxyCacheCloseAst_ProxyEnd,
                                           &ProxyCacheCloseAst_ProxyEnd);
      if (Debug) fprintf (stdout, "sys$close() %%X%08.08X\n", status);
      return;
   }
   else
   {    
      if (Debug) fprintf (stdout, "SUCCESS!\n");
                               
      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY_CACHE))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY_CACHE,
"CACHE LOAD OK content !UL bytes (!UL blocks), age !UL/!UL (hrs/days)",
            tkptr->ResponseBodyLength,
          ((tkptr->ResponseHeaderLength + tkptr->ResponseBodyLength) >> 9) + 1,
            tkptr->ProxyCacheLastModifiedHours,
            tkptr->ProxyCacheLastModifiedHours/24);

      /* close file asynchronously AST calling ProxyEnd() */
      tkptr->LoadFab.fab$l_fop |= FAB$M_ASY;
      status = sys$close (&tkptr->LoadFab, &ProxyCacheCloseAst_ProxyEnd,
                                           &ProxyCacheCloseAst_ProxyEnd);
      if (Debug) fprintf (stdout, "sys$close() %%X%08.08X\n", status);
      return;
   }
} 

/*****************************************************************************/
/*
Create a directory!  Directory can be specified "device:[dir1.dir2]" or
"device:[dir1]dir2" (first preferable, only one sys$parse() required).
*/ 
 
ProxyCacheCreateDirectory (char *DirectoryName)

{
   static unsigned short  ProtectionEnable = 0xffff, /* alter all S,O,G,W */ 
                          ProtectionMask = 0xaa00; /* S:RWED */
   static $DESCRIPTOR (DirectoryDsc, "");

   int  status;
   char  Directory [64];

   /*********/
   /* begin */
   /*********/

   if (Debug)
       fprintf (stdout, "ProxyCacheCreateDirectory() |%s|\n", DirectoryName);

   DirectoryDsc.dsc$a_pointer = DirectoryName;
   DirectoryDsc.dsc$w_length = strlen(DirectoryName);

   status = lib$create_dir (&DirectoryDsc, 0, &ProtectionEnable,
                            &ProtectionMask, 0, 0);
   if (Debug) fprintf (stdout, "lib$create_dir() %%X%08.08X\n", status);

   if (status == SS$_CREATED) return (SS$_NORMAL);
   if (status == SS$_NORMAL) status = RMS$_DNF;
   if (ProxyReportCacheLog)
      WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, directory create error (!AZ !UL)\n-!%M\n \\!AZ\\\n",
         Utility, 0, FI_LI, status, Directory);
   return (status);
}

/****************************************************************************/
/*
Return the age in hours relative to the current time.
*/

int ProxyCacheAgeHours
(
unsigned long *CurrentBinaryTimePtr,
unsigned long *AgeBinaryTimePtr
)
{
   static unsigned long  LibDeltaHours = LIB$K_DELTA_HOURS;

   int  status;
   unsigned long  AgeHours;
   unsigned long  BinTime[2],
                  ResultBinTime [2];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyCacheAgeHours()\n");

   if (!AgeBinaryTimePtr[0] && !AgeBinaryTimePtr[1]) return (999999999);

   if (CurrentBinaryTimePtr == NULL)
      sys$gettim (CurrentBinaryTimePtr = &BinTime);

   status = lib$sub_times (CurrentBinaryTimePtr,
                           AgeBinaryTimePtr,
                           &ResultBinTime);
   if (Debug) fprintf (stdout, "lib$sub_times() %%X%08.08X\n", status);
   if (status == LIB$_NEGTIM) return (0);

   status = lib$cvt_from_internal_time (&LibDeltaHours,
                                        &AgeHours,
                                        &ResultBinTime);
   if (Debug) fprintf (stdout, "lib$cvt_() %%X%08.08X\n", status);

   if (Debug) fprintf (stdout, "hours: %d\n", AgeHours);
   return (AgeHours);
}

/****************************************************************************/
/*
Returns true if 'TheseHours' exceed the limit implemented by the age
algorithm as applied to 'AgeHours'. See "AGE ALGORITHM" in the description of
this module.
*/

int ProxyCacheReloadAge
(
unsigned long AgeHours,
unsigned long TheseHours
)
{
   int  idx;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyCacheReloadAge() %d %d\n", AgeHours, TheseHours);

   /* always reload if less than one hour (should never occur!) */
   if (AgeHours < 1) return (true);

   /* element one is always a default bottom-of-the-range zero */
   for (idx = 1; idx < ProxyCacheReloadListCount; idx++)
   {
      if (Debug)
         fprintf (stdout, "[%d] %d %d %d\n",
                 idx, ProxyCacheReloadList[idx], AgeHours, TheseHours);
      if (AgeHours > ProxyCacheReloadList[idx]) continue;
      /* if these hours exceed the lower limit of the range then reload */
      if (TheseHours >= ProxyCacheReloadList[idx-1]) return (true);
      /* does not exceed the lower limit of the range therefore no reload */
      return (false);
   }

   /* same criteria as above */
   if (TheseHours >= ProxyCacheReloadList[idx-1]) return (true);
   return (false);
}

/*****************************************************************************/
/*
Two functions to update a cache file's "revised" and "expired" date/times. 
This function executes completely independently of any other processing, uses
it's own dynamically allocated data structure, and delivers an AST to check the
success of the operation and then deallocate the structure.  Note that both
revision and expired date/time must be updated.  The ACP action appears to
update the revision date/time to be the same as the expired if the revision is
not explicitly supplied!

This function uses the ACP-QIO interface detailed in the "OpenVMS I/O User's 
Reference Manual", and is probably as fast as we can get for this type of file
system functionality!
*/ 

int ProxyCacheSetLastAccessed
(
struct NAM *NamPtr,
unsigned long *RdtBinaryTimePtr,
unsigned long *EdtBinaryTimePtr
)
{
   static $DESCRIPTOR (DeviceDsc, "");

   int  status;
   unsigned short  Channel;
   struct ProxyCacheFileAcpStruct  *faptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyCacheSetLastAccessed() |%s|\n",
               NamPtr->nam$l_esa);

   /* assign a channel to the disk device containing the file */
   DeviceDsc.dsc$a_pointer = NamPtr->nam$l_dev;
   DeviceDsc.dsc$w_length = NamPtr->nam$b_dev;
   if (Debug)
      fprintf (stdout, "device |%*.*s|\n",
               NamPtr->nam$b_dev, NamPtr->nam$b_dev,
               NamPtr->nam$l_dev);

   status = sys$assign (&DeviceDsc, &Channel, 0, 0, 0);
   if (Debug) fprintf (stdout, "sys$assign() %%X%08.08X\n", status);
   if (VMSnok (status)) return (status);

   faptr = VmGet (sizeof(struct ProxyCacheFileAcpStruct));

   faptr->Channel = Channel;

   /* set up the File Information Block for the ACP interface */
   faptr->FileFibAcpDsc.dsc$w_length = sizeof(struct fibdef);
   faptr->FileFibAcpDsc.dsc$a_pointer = &faptr->FileFib;

   memcpy (&faptr->FileFib.fib$w_did, &NamPtr->nam$w_did, 6);

   faptr->AcpFileNameLength = NamPtr->nam$b_name +
                              NamPtr->nam$b_type +
                              NamPtr->nam$b_ver;
   memcpy (faptr->AcpFileName, NamPtr->nam$l_name, faptr->AcpFileNameLength);
   faptr->AcpFileName[faptr->AcpFileNameLength] = '\0';

   faptr->FileNameAcpDsc.dsc$a_pointer = faptr->AcpFileName;
   faptr->FileNameAcpDsc.dsc$w_length = faptr->AcpFileNameLength;

   if (Debug)
      fprintf (stdout, "name |%s|\n", faptr->FileNameAcpDsc.dsc$a_pointer);

   memcpy (&faptr->RdtBinTime, RdtBinaryTimePtr, 8);
   memcpy (&faptr->EdtBinTime, EdtBinaryTimePtr, 8);

   faptr->FileAtr[0].atr$w_size = sizeof(faptr->RdtBinTime);
   faptr->FileAtr[0].atr$w_type = ATR$C_REVDATE;
   faptr->FileAtr[0].atr$l_addr = &faptr->RdtBinTime;
   faptr->FileAtr[1].atr$w_size = sizeof(faptr->EdtBinTime);
   faptr->FileAtr[1].atr$w_type = ATR$C_EXPDATE;
   faptr->FileAtr[1].atr$l_addr = &faptr->EdtBinTime;
   faptr->FileAtr[2].atr$w_size =
      faptr->FileAtr[2].atr$w_type =
      faptr->FileAtr[2].atr$l_addr = 0;

   status = sys$qio (0, faptr->Channel, IO$_MODIFY,
                     &faptr->AcpIOsb, &ProxyCacheSetLastAccessedAst, faptr, 
                     &faptr->FileFibAcpDsc, &faptr->FileNameAcpDsc, 0, 0,
                     &faptr->FileAtr, 0);
   if (Debug) fprintf (stdout, "sys$qio() %%X%08.08X\n", status);

   if (VMSnok (status))
   {
      sys$dassgn (faptr->Channel);
      VmFree (faptr, FI_LI);
   }

   return (SS$_NORMAL);
}

/****************************************************************************/
/*
*/

ProxyCacheSetLastAccessedAst (struct ProxyCacheFileAcpStruct *faptr)

{
   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyCacheSetLastAccessedAst() %%X%08.08X\n",
               faptr->AcpIOsb.Status);

   if (VMSnok (faptr->AcpIOsb.Status))
   {
      if (ProxyReportCacheLog)
         WriteFaoStdout (
"%!AZ-W-PROXY, !20%D, expired timestamp update error (!AZ !UL)\n-!%M\n \\!#AZ\\\n",
            Utility, 0, FI_LI, faptr->AcpIOsb.Status,
            faptr->FileNameAcpDsc.dsc$w_length,
            faptr->FileNameAcpDsc.dsc$a_pointer);
   }

   sys$dassgn (faptr->Channel);

   VmFree (faptr, FI_LI);
}

/****************************************************************************/
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          