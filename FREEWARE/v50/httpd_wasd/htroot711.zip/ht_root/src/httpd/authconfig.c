/*****************************************************************************/
/*
                               AuthConfig.c


    THE GNU GENERAL PUBLIC LICENSE APPLIES DOUBLY TO ANYTHING TO DO WITH
                    AUTHENTICATION AND AUTHORIZATION!

    This package is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License, or any later
    version.

>   This package is distributed in the hope that it will be useful,
>   but WITHOUT ANY WARRANTY; without even the implied warranty of
>   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
>   GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


This module hadles authentication/authorization configuration.  It reads
configuration files, creates the configuration database (linked list), checking
paths against that database, and reports surrounding it.

See AUTH.C for overall detail on the WASD authorization environment.


VERSION HISTORY
---------------
02-OCT-2000  MGD  flush the persona cache when (re)loading
01-SEP-2000  MGD  AuthConfigSearch() passed the path as a parameter
13-AUG-2000  MGD  bugfix; AuthConfigSearch() quick index
06-MAY-2000  MGD  proxy authorization requires changes to path searching
18-MAR-2000  MGD  bugfix; lexicographic cut-off point
16-MAR-2000  MGD  bugfix; AuthSearchConfig() removed '.' (?!) from match code
04-MAR-2000  MGD  use NetWriteFaol(), et.al.
02-JAN-2000  MGD  config file opened via ODS module
20-NOV-1999  MGD  add nil-access identifier to bypass hour restrictions
28-AUG-1999  MGD  unbundled from AUTH.C for v6.1
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

/* VMS related header files */
#include <descrip.h>
#include <rms.h>
#include <rmsdef.h>
#include <ssdef.h>
#include <stsdef.h>

/* application related header files */
#include "wasd.h"

#define WASD_MODULE "AUTH"

#if DBUG
#define FI_NOLI WASD_MODULE, __LINE__
#else
/* in production let's keep the exact line to ourselves! */
#define FI_NOLI WASD_MODULE, 0
#endif


/******************/
/* global storage */
/******************/

boolean  AuthorizationEnabled,
         AuthPolicyAuthorizedOnly,
         AuthPolicySysUafRelaxed,
         AuthPolicySslOnly,
         AuthPolicySysUafIdentifiers,
         AuthPolicySysUafSslOnly,
         AuthPolicySysUafWasdIdentifiers,
         AuthPromiscuous,
         AuthSysUafEnabled,
         AuthSysUafPromiscuous,
         AuthVmsUserSecProfileEnabled;

unsigned long  AuthHttpsOnlyVmsIdentifier,
               AuthNilAccessVmsIdentifier,
               AuthPasswordChangeVmsIdentifier,
               AuthWasdPwdVmsIdentifier,
               AuthWasdHttpsVmsIdentifier,
               AuthWasdReadVmsIdentifier,
               AuthWasdWriteVmsIdentifier;

char  *AuthPromiscuousPwdPtr;

struct AuthConfigStruct  AuthServerConfig;

char  ErrorAuthSysFaoBufferOvf [] = "*ERROR* sys$fao() BUFFEROVF",
      ErrorAuthSysFao [] = "*ERROR* sys$fao()";

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern int  WatchEnabled,
            ServerPort,
            ServiceCount;

extern char  ErrorSanityCheck[],
             ServerHostName[],
             ServerHostPort[],
             SoftwareID[],
             Utility[];

extern struct AccountingStruct  Accounting;
extern struct ConfigStruct  Config;
extern struct MsgStruct  Msgs;

/*****************************************************************************/
/*
Initialize the authentication/authorization environment.  Is used at server
startup and when the authorization configuration is reloaded.
*/ 

AuthConfigInit ()

{
   static $DESCRIPTOR (AuthHttpsOnlyVmsIdentifierDsc, AUTH_HTTPS_ONLY_VMS_ID);
   static $DESCRIPTOR (AuthNilAccessVmsIdentifierDsc, AUTH_NIL_ACCESS_VMS_ID);
   static $DESCRIPTOR (AuthPasswordChangeVmsIdentifierDsc,
                       AUTH_PASSWORD_CHANGE_VMS_ID);
   static $DESCRIPTOR (AuthWasdHttpsVmsIdentifierDsc, AUTH_WASD_HTTPS_VMS_ID);
   static $DESCRIPTOR (AuthWasdPwdVmsIdentifierDsc, AUTH_WASD_PWD_VMS_ID);
   static $DESCRIPTOR (AuthWasdReadVmsIdentifierDsc, AUTH_WASD_READ_VMS_ID);
   static $DESCRIPTOR (AuthWasdWriteVmsIdentifierDsc, AUTH_WASD_WRITE_VMS_ID);

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthConfigInit()\n");

   /* it's implied! */
   if (AuthPolicySysUafWasdIdentifiers) AuthPolicySysUafIdentifiers = true;

   /* initialize the configuration database */
   AuthConfigRead (NULL);

   if (AuthSysUafEnabled)
      AuthConfigReadStatus (&AuthServerConfig,
         "%HTTPD-I-AUTH, SYSUAF authentication enabled\n");

   if (AuthPolicyAuthorizedOnly)
      AuthConfigReadStatus (&AuthServerConfig,
         "%HTTPD-I-AUTH, all request paths must be authorized\n");

   if (AuthPolicySslOnly)
      AuthConfigReadStatus (&AuthServerConfig,
         "%HTTPD-I-AUTH, only SSL requests (https:) will be authorized\n");

   if (AuthPolicySysUafIdentifiers)
      AuthConfigReadStatus (&AuthServerConfig,
         "%HTTPD-I-AUTH, SYSUAF authentication only with identifier\n");

   if (AuthPolicySysUafWasdIdentifiers)
      AuthConfigReadStatus (&AuthServerConfig,
"%HTTPD-I-AUTH, SYSUAF authentication using WASD identifier (deprecated)\n");

   if (AuthVmsUserSecProfileEnabled)
      AuthConfigReadStatus (&AuthServerConfig,
         "%HTTPD-I-AUTH, VMS security profile enabled\n");

   if (AuthSysUafPromiscuous)
      AuthConfigReadStatus (&AuthServerConfig,
         "%HTTPD-W-AUTH, SYSUAF !AZ (testing only)\n",
         AUTH_REALM_PROMISCUOUS);

   if (AuthPromiscuous)
      AuthConfigReadStatus (&AuthServerConfig,
          "%HTTPD-W-AUTH, !AZ authenticating any username/password!!\n",
          AUTH_REALM_PROMISCUOUS);

   /* load the authorization paths */
   AuthConfigRead (&AuthServerConfig);

   if (AuthorizationEnabled)
   {
      if (!(Config.cfAuth.BasicEnabled || Config.cfAuth.DigestEnabled))
         AuthConfigReadStatus (&AuthServerConfig,
            "%HTTPD-W-AUTH, neither BASIC or DIGEST authentication enabled\n");
   }
   else
      AuthConfigReadStatus (&AuthServerConfig,
            "%HTTPD-W-AUTH, none configured\n");

   if (AuthPolicySysUafIdentifiers)
   {
      status = sys$asctoid (&AuthHttpsOnlyVmsIdentifierDsc,
                            &AuthHttpsOnlyVmsIdentifier, 0);
      if (VMSnok (status))
         AuthConfigReadStatus (&AuthServerConfig,
            "%HTTPD-W-AUTH, optional identifier !AZ\n-!%M\n",
            AUTH_HTTPS_ONLY_VMS_ID, status);

      status = sys$asctoid (&AuthNilAccessVmsIdentifierDsc,
                            &AuthNilAccessVmsIdentifier, 0);
      if (VMSnok (status))
         AuthConfigReadStatus (&AuthServerConfig,
            "%HTTPD-W-AUTH, optional identifier !AZ\n-!%M\n",
            AUTH_NIL_ACCESS_VMS_ID, status);

      status = sys$asctoid (&AuthPasswordChangeVmsIdentifierDsc,
                            &AuthPasswordChangeVmsIdentifier, 0);
      if (VMSnok (status))
         AuthConfigReadStatus (&AuthServerConfig,
            "%HTTPD-W-AUTH, optional identifier !AZ\n-!%M\n",
            AUTH_PASSWORD_CHANGE_VMS_ID, status);
   }

   if (AuthPolicySysUafWasdIdentifiers)
   {
      status = sys$asctoid (&AuthWasdWriteVmsIdentifierDsc,
                            &AuthWasdWriteVmsIdentifier, 0);
      if (VMSnok (status))
         AuthConfigReadStatus (&AuthServerConfig,
            "%HTTPD-W-AUTH, required identifier !AZ\n-!%M\n",
            AUTH_WASD_WRITE_VMS_ID, status);

      status = sys$asctoid (&AuthWasdReadVmsIdentifierDsc,
                            &AuthWasdReadVmsIdentifier, 0);
      if (VMSnok (status))
         AuthConfigReadStatus (&AuthServerConfig,
            "%HTTPD-W-AUTH, required identifier !AZ\n!-!%M\n",
            AUTH_WASD_READ_VMS_ID, status);

      status = sys$asctoid (&AuthWasdHttpsVmsIdentifierDsc,
                            &AuthWasdHttpsVmsIdentifier, 0);
      if (VMSnok (status))
         AuthConfigReadStatus (&AuthServerConfig,
            "%HTTPD-W-AUTH, required identifier !AZ\n-!%M\n",
            AUTH_WASD_HTTPS_VMS_ID, status);

      status = sys$asctoid (&AuthWasdPwdVmsIdentifierDsc,
                            &AuthWasdPwdVmsIdentifier, 0);
      if (VMSnok (status))
         AuthConfigReadStatus (&AuthServerConfig,
            "%HTTPD-W-AUTH, required identifier !AZ\n-!%M\n",
            AUTH_WASD_PWD_VMS_ID, status);
   }

   /* if this is an in-service configuration load then we'll need to do this */
   AuthCacheTreeFree ();

   /* also flush the server persona cache */
   PersonaCache (NULL, 0);
}

/*****************************************************************************/
/*
Open the authorization configuration file defined by the logical name
HTTPD$AUTH.  Read the directives applying them to the authorization path tree. 
Close the file.
*/

int AuthConfigRead (struct AuthConfigStruct *acptr)

{
   boolean  DebugBuffer;
   int  status;
   char  Line [512],
         LineBuffer [512];
   struct OdsStruct  ConfigFileOds;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthConfigRead()\n");

   if (acptr == NULL)
   {
      /**************/
      /* initialize */
      /**************/

      acptr = &AuthServerConfig;
      AuthCacheTreeFree ();
      AuthConfigFree (acptr);
      if (acptr->ProblemReportPtr != NULL) free (acptr->ProblemReportPtr);
      memset (acptr, 0, sizeof(struct AuthConfigStruct));

      return (SS$_NORMAL);
   }

   /* initialize */
   AuthConfigLine (acptr, NULL);
   sys$gettim (&acptr->LoadBinTime);

   /* guarantee access to the administration menu */
   if (AuthPromiscuous)
   {
      /* these may generate duplicate rule errors at startup! */
      AuthConfigLine (acptr, "[PROMISCUOUS]");
      /* access to the server administration menu */
      strcpy (Line, "/httpd/-/admin/* r+w");
      AuthConfigLine (acptr, Line);
      /* access to write into the "normal" location for configuration files */
      strcpy (Line, "/ht_root/local/* r+w");
      AuthConfigLine (acptr, Line);
   }

   /************************/
   /* open the config file */
   /************************/

   /* use SYSPRV to allow access to possibly protected file */
   EnableSysPrv();
   status = OdsOpenReadOnly (&ConfigFileOds, CONFIG_AUTH_FILE_NAME);
   DisableSysPrv();
   if (VMSnok (status))
   {
      AuthConfigReadStatus (acptr,
         "%HTTPD-W-AUTH, opening configuration file\n!-!%M\n", status);
      /* loading at startup, report any errors */
      if (acptr->ProblemCount && !acptr->RequestPtr)
         fputs (acptr->ProblemReportPtr, stdout);
      return (status);
   }

   /* get the configuration file revision date and time */
   strcpy (acptr->LoadFileName, ConfigFileOds.ResFileName);
   memcpy (acptr->RevBinTime, &ConfigFileOds.XabDat.xab$q_rdt, 8);

   /************************/
   /* read the config file */
   /************************/

#ifdef DBUG
   /* not interested anymore in seeing debug information for auth load! */
   DebugBuffer = Debug;
   Debug = false;
#endif

   ConfigFileOds.Rab.rab$l_ubf = Line;
   ConfigFileOds.Rab.rab$w_usz = sizeof(Line)-1;

   while (VMSok (status = sys$get (&ConfigFileOds.Rab, 0, 0)))
   {
      acptr->LineNumber++;
      ConfigFileOds.Rab.rab$l_ubf[ConfigFileOds.Rab.rab$w_rsz] = '\0';
      memcpy (acptr->LinePtr = LineBuffer, Line, ConfigFileOds.Rab.rab$w_rsz+1);
      if (Debug)
         fprintf (stdout, "line %d |%s|\n",
                  acptr->LineNumber, ConfigFileOds.Rab.rab$l_ubf);

      if (ConfigFileOds.Rab.rab$w_rsz)
      {
         if (ConfigFileOds.Rab.rab$l_ubf[ConfigFileOds.Rab.rab$w_rsz-1] == '\\')
         {
            /* directive is continued on next line */
            ConfigFileOds.Rab.rab$l_ubf[ConfigFileOds.Rab.rab$w_rsz-1] = ' ';
            ConfigFileOds.Rab.rab$l_ubf += ConfigFileOds.Rab.rab$w_rsz;
            ConfigFileOds.Rab.rab$w_usz -= ConfigFileOds.Rab.rab$w_rsz;
            continue;
         }
      }

      AuthConfigLine (acptr, Line);

      ConfigFileOds.Rab.rab$l_ubf = Line;
      ConfigFileOds.Rab.rab$w_usz = sizeof(Line)-1;
   }

   if (status == RMS$_EOF) status = SS$_NORMAL;

#ifdef DBUG
   Debug = DebugBuffer;
#endif

   /******************/
   /* close the file */
   /******************/

   sys$close (&ConfigFileOds.Fab, 0, 0); 

   if (VMSnok (status))
      ErrorExitVmsStatus (status, "reading HTTPD$AUTH file", FI_LI);

   if (Debug)
   {
      register struct AuthPathRecordStruct  *plptr;

      fprintf (stdout, "-\n");
      for (plptr = acptr->PathListHead;
           plptr != NULL;
           plptr = plptr->NextPtr)
         fprintf (stdout, "plptr |%s|%s|%s|%s|\n",
                  plptr->PathPtr, plptr->RealmPtr,
                  plptr->GroupWritePtr, plptr->GroupReadPtr);
      fprintf (stdout, "-\n");
   }

   /* let this function do its initialization */
   AuthConfigSearch (NULL, NULL, NULL);

   return (status);
}

/*****************************************************************************/
/*
Process a line of authorization configuration.
*/

#define ACCESS_RESTRICTION_LIST_SIZE 256
#define AGENT_PARAMETER_SIZE AUTH_MAX_AGENT_PARAM_LENGTH+1

AuthConfigLine
(
struct AuthConfigStruct *acptr,
char *Line
)
{
   static boolean  VirtualServerUnknown;
   static int  SourceGroupRead,
               SourceGroupWrite,
               SourceRealm;
   static char  GroupRead [AUTH_MAX_REALM_GROUP_LENGTH+1],
                GroupWrite [AUTH_MAX_REALM_GROUP_LENGTH+1],
                Realm [AUTH_MAX_REALM_GROUP_LENGTH+1],
                RealmDescription [AUTH_MAX_REALM_DESCR_LENGTH+1],
                RealmCanString [256],
                VirtualServerHostPort [256];

   register char  *lptr, *sptr, *zptr;

   boolean  NoCache;
   int  status;
   unsigned long  *CanFlagsPtr;
   unsigned long  GroupCanFlags,
                  GroupReadVmsIdentifier,
                  GroupWriteVmsIdentifier,
                  RealmCanFlags,
                  RealmVmsIdentifier,
                  WorldCanFlags;
   char  *PathTemplatePtr,
         *RestrictListPtr,
         *VirtualServerHostPortPtr;
   char  AgentParameter [AGENT_PARAMETER_SIZE],
         GroupRestrictList [ACCESS_RESTRICTION_LIST_SIZE],
         WorldRestrictList [ACCESS_RESTRICTION_LIST_SIZE];

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "AuthConfigLine() |%s|%s|%s|%s|%s|\n",
               Realm, RealmDescription, GroupRead, GroupWrite, Line);

   if (Line == NULL)
   {
      /* initialize */
      strcpy (Realm, AUTH_REALM_FAIL);
      VirtualServerUnknown = false;
      strcpy (VirtualServerHostPort, "*");
      return;
   }

   if (strsame (Realm, AUTH_REALM_FAIL, -1))
   {
      /* for the "always failed realm" make sure these are always reset */
      GroupReadVmsIdentifier = GroupWriteVmsIdentifier =
         RealmVmsIdentifier = GroupCanFlags = RealmCanFlags =
         SourceGroupRead = SourceGroupWrite = 0;
         GroupRead[0] = GroupWrite[0] = RealmCanString[0] = '\0';
      SourceRealm = AUTH_SOURCE_FAIL;
   }

   lptr = Line;
   while (ISLWS(*lptr)) lptr++;
   if (!*lptr || *lptr == '#') return;

   NoCache = false;
   GroupCanFlags = WorldCanFlags = 0;
   AgentParameter[0] = GroupRestrictList[0] = WorldRestrictList[0] = '\0';
   CanFlagsPtr = &GroupCanFlags;
   RestrictListPtr = &GroupRestrictList;

   if (*lptr != '[' && !strsame (lptr, "REALM", 5))
   {
      /********/
      /* path */
      /********/

      /* ignore all paths associated with an unknown virtual server */
      if (VirtualServerUnknown) return;

      /* unless in promiscuous mode completely ignore PROMISCUOUS realm! */
      if (!AuthPromiscuous && strsame (Realm, AUTH_REALM_PROMISCUOUS, -1))
         return;

      /* note start of path template */
      PathTemplatePtr = lptr;
      while (*lptr && !ISLWS(*lptr)) lptr++;
      /* terminate at the end of the path template */
      if (*lptr) *lptr++ = '\0';

      if (SourceRealm == AUTH_SOURCE_NONE)
         while (*lptr) lptr++;
      else
      { 
         /* find start of access flags */
         while (*lptr && ISLWS(*lptr)) lptr++;
         if (!*lptr)
         {
            if (RealmCanString[0])
               lptr = RealmCanString;
            else
            {
               AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, no access specified \
(no realm defaults to apply) at line !UL\n",
                  acptr->LineNumber);
               lptr = "";
            }
         }
      }

      while (*lptr)
      {
         /********************************/
         /* set flags controlling access */
         /********************************/

         /* find the start of the next element */
         while (*lptr && (ISLWS(*lptr) || *lptr == ',' || *lptr == ';'))
         {
            if (*lptr++ != ';') continue;
            /* semicolon separates realm/group and optional world access */
            CanFlagsPtr = &WorldCanFlags;
            RestrictListPtr = &WorldRestrictList;
         }
         if (!*lptr) break;

         if (*lptr == '*' ||
             *lptr == '#' ||
             isdigit(*lptr) ||
             *lptr == '~' ||
             strsame (lptr, "http:", 5) ||
             strsame (lptr, "https:", 6) ||
             strsame (lptr, "localhost", 9))
         {
            /* access restriction list */
            for (sptr = RestrictListPtr; *sptr; sptr++);
            zptr = RestrictListPtr + ACCESS_RESTRICTION_LIST_SIZE;
            if (sptr > RestrictListPtr && sptr < zptr) *sptr++ = ',';
            while (*lptr && !ISLWS(*lptr) &&
                   *lptr != ',' && *lptr != ';' &&
                   sptr < zptr)
               *sptr++ = *lptr++;
            if (sptr >= zptr)
            {
               AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, restriction list too long at line !UL\n",
                  acptr->LineNumber);
               strcpy (RestrictListPtr, AUTH_RESTRICTED_FAIL);
               break;
            }
            else
               *sptr = '\0';
         }
         else
         if (strsame (lptr, "param=", 6))
         {
            /* agent parameter */
            zptr = (sptr = AgentParameter) + AGENT_PARAMETER_SIZE;
            lptr += 6;
            if (*lptr == '\"')
            {
               /* delimitted by double quotes */
               lptr++;
               while (*lptr && *lptr != '\"' && sptr < zptr) *sptr++ = *lptr++;
               if (*lptr) lptr++;
            }
            else
            if (*lptr == '\'')
            {
               /* delimitted by single quotes */
               lptr++;
               while (*lptr && *lptr != '\'' && sptr < zptr) *sptr++ = *lptr++;
               if (*lptr) lptr++;
            }
            else
            {
               /* delimited by restriction list syntax */
               while (*lptr && !ISLWS(*lptr) &&
                      *lptr != ',' && *lptr != ';' && 
                      sptr < zptr)
                  *sptr++ = *lptr++;
            }
            if (sptr >= zptr)
            {
               AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, agent parameter too long at line !UL\n",
                  acptr->LineNumber);
               strcpy (AgentParameter, AUTH_AGENT_PARAM_FAIL);
               break;
            }
            else
               *sptr = '\0';
         }
         else
         if (strsame (lptr, "nocache", 7) && !isalpha(lptr[7]))
            NoCache = true;
         else
         if (strsame (lptr, "none", 4) && !isalpha(lptr[4]))
            *CanFlagsPtr = 0;
         else
         /* must come before "read" for obvious reasons! */
         if ((strsame (lptr, "READ+WRITE", 10) && !isalpha(lptr[10])) ||
             (strsame (lptr, "R+W", 3) && !isalpha(lptr[3])))
            *CanFlagsPtr |= (HTTP_METHOD_GET | HTTP_METHOD_HEAD |
                             HTTP_METHOD_DELETE | HTTP_METHOD_POST |
                             HTTP_METHOD_PUT);
         else
         if ((strsame (lptr, "READ", 4) && !isalpha(lptr[4])) ||
             (strsame (lptr, "R", 1) && !isalpha(lptr[1])))
            *CanFlagsPtr |= (HTTP_METHOD_GET | HTTP_METHOD_HEAD);
         else
         if ((strsame (lptr, "WRITE", 5) && !isalpha(lptr[5])) ||
             (strsame (lptr, "W", 1) && !isalpha(lptr[1])))
            *CanFlagsPtr |= (HTTP_METHOD_DELETE | HTTP_METHOD_POST |
                             HTTP_METHOD_PUT);
         else
         if (strsame (lptr, "DELETE", 6) && !isalpha(lptr[6]))
            *CanFlagsPtr |= HTTP_METHOD_DELETE;
         else
         if (strsame (lptr, "GET", 3) && !isalpha(lptr[3]))
            *CanFlagsPtr |= HTTP_METHOD_GET | HTTP_METHOD_HEAD;
         else
         if (strsame (lptr, "HEAD", 4) && !isalpha(lptr[4]))
            *CanFlagsPtr |= HTTP_METHOD_HEAD;
         else
         if (strsame (lptr, "POST", 4) && !isalpha(lptr[4]))
            *CanFlagsPtr |= HTTP_METHOD_POST;
         else
         if (strsame (lptr, "PUT", 3) && !isalpha(lptr[3]))
            *CanFlagsPtr |= HTTP_METHOD_PUT;
         else
         {
            /* otherwise assume it's an alpha-numeric host name */
            for (sptr = RestrictListPtr; *sptr; sptr++);
            zptr = RestrictListPtr + ACCESS_RESTRICTION_LIST_SIZE;
            if (sptr > RestrictListPtr && sptr < zptr) *sptr++ = ',';
            while (*lptr && !ISLWS(*lptr) &&
                   *lptr != ',' && *lptr != ';' &&
                   sptr < zptr)
               *sptr++ = *lptr++;
            if (sptr >= zptr)
            {
               AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, restriction list too long at line !UL\n",
                  acptr->LineNumber);
               strcpy (RestrictListPtr, AUTH_RESTRICTED_FAIL);
               break;
            }
            else
               *sptr = '\0';
         }
         while (*lptr && !ISLWS(*lptr) && *lptr != ',' && *lptr != ';') lptr++;
      }

      if (VMSnok (status =
          AuthConfigAdd (acptr,
             VirtualServerHostPort,
             Realm, RealmDescription, SourceRealm, RealmVmsIdentifier,
             GroupWrite, SourceGroupWrite, GroupWriteVmsIdentifier,
             GroupRead, SourceGroupRead, GroupReadVmsIdentifier,
             PathTemplatePtr, AgentParameter,
             GroupRestrictList, WorldRestrictList,
             GroupCanFlags, WorldCanFlags, NoCache)))
      if (status == RMS$_DUP)
         AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, duplicate path (ignored) at line !UL\n",
            acptr->LineNumber);
      else
         ErrorExitVmsStatus (status, "AuthConfigAdd()", FI_LI);

      /* increment this boolean if authorization paths are loaded */
      AuthorizationEnabled++;

      return;
   }

   if (*(unsigned short*)lptr == '[[')
   {
      /*******************/
      /* virtual service */
      /*******************/

      VirtualServerHostPortPtr = lptr += 2;
      for (sptr = lptr; *sptr && *sptr != ']'; sptr++);
      if (*(unsigned short*)sptr != ']]')
      {
         AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, virtual service problem at line !UL\n",
            acptr->LineNumber);
         VirtualServerUnknown = true;
         return;
      }
      *sptr = '\0';

      if (*VirtualServerHostPortPtr != '*')
      {
         if (!NetServiceConfigured (VirtualServerHostPortPtr))
         {
            AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, virtual service not configured at line !UL\n",
               acptr->LineNumber);
            VirtualServerUnknown = true;
            return;
         }
      }
      strcpy (VirtualServerHostPort, VirtualServerHostPortPtr);
      VirtualServerUnknown = false;
      return;
   }

   if (*lptr == '[' || strsame (lptr, "REALM", 5))
   {
      /*********/
      /* realm */
      /*********/

      /* ignore all realms associated with an unknown virtual server */
      if (VirtualServerUnknown) return;

      if (*lptr == '[')
      {
         lptr++;
         while (*lptr && ISLWS(*lptr)) lptr++;
      }
      else
      {
         /* skip over keyword and find start of realm name */
         while (*lptr && !ISLWS(*lptr)) lptr++;
         while (*lptr && ISLWS(*lptr)) lptr++;
      }

      GroupReadVmsIdentifier = GroupWriteVmsIdentifier =
         RealmVmsIdentifier = GroupCanFlags = RealmCanFlags =
         SourceGroupRead = SourceGroupWrite = SourceRealm = 0;
      GroupRead[0] = GroupWrite[0] =
         Realm[0] = RealmDescription[0] = RealmCanString[0] = '\0';

      if (*lptr == '\"')
      {
         lptr++;
         zptr = (sptr = RealmDescription) + sizeof(RealmDescription);
         while (*lptr &&
                *lptr != '\"' &&
                sptr < zptr)
            *sptr++ = *lptr++;
         if (sptr >= zptr)
         {
            AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, problem configuring realm description at line !UL\n",
               acptr->LineNumber);
            strcpy (Realm, AUTH_REALM_FAIL);
            return;
         }
         else
            *sptr = '\0';
         if (*lptr == '\"') lptr++;
         if (*lptr == '=') lptr++;
      }

      SourceRealm = AUTH_SOURCE_HTA;
      zptr = (sptr = Realm) + sizeof(Realm);
      while (*lptr &&
             *lptr != ';' &&
             *lptr != '=' &&
             *lptr != ']' &&
             !ISLWS(*lptr) &&
             sptr < zptr)
         *sptr++ = toupper(*lptr++);
      if (sptr >= zptr || !Realm[0])
      {
         AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, problem configuring realm at line !UL\n",
            acptr->LineNumber);
         strcpy (Realm, AUTH_REALM_FAIL);
         return;
      }
      *sptr = '\0';

      if (*lptr == '=')
      {
         if (strsame (lptr, "=AGENT", 6))
         {
            lptr += 6;
            SourceRealm = AUTH_SOURCE_AGENT;
         }
         else
         if (strsame (lptr, "=HTA", 4))
         {
            lptr += 4;
            SourceRealm = AUTH_SOURCE_HTA;
         }
         else
         if (strsame (lptr, "=ID", 3))
         {
            lptr += 3;
            SourceRealm = AUTH_SOURCE_ID;
            if (VMSnok (status =
                AuthConfigIdentifier (Realm, &RealmVmsIdentifier)))
            {
               AuthConfigReadStatus (&AuthServerConfig,
"%HTTPD-W-AUTH, realm !AZ identifier at line !UL\n-!%M\n",
                  Realm, acptr->LineNumber, status);
               strcpy (Realm, AUTH_REALM_FAIL);
               return;
            }
         }
         else
         if (strsame (lptr, "=LIST", 5))
         {
            lptr += 5;
            SourceRealm = AUTH_SOURCE_LIST;
         }
         else
         if (strsame (lptr, "=VMS", 4))
         {
            lptr += 4;
            SourceRealm = AUTH_SOURCE_VMS;
         }
         else
         {
            AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, problem configuring realm source at line !UL\n",
               acptr->LineNumber);
            strcpy (Realm, AUTH_REALM_FAIL);
            return;
         }
      }

      /* if was "VMS" then it's SYSUAF no matter what was made equal to!! */
      if (strsame (Realm, AUTH_REALM_VMS, -1))
         SourceRealm = AUTH_SOURCE_VMS;
      else
      /* same for "WORLD" */
      if (strsame (Realm, AUTH_REALM_WORLD, -1))
         SourceRealm = AUTH_SOURCE_WORLD;
      else
      /* and for "EXTERNAL" */
      if (strsame (Realm, AUTH_REALM_EXTERNAL, -1))
         SourceRealm = AUTH_SOURCE_EXTERNAL;
      else
      /* and "NONE" */
      if (strsame (Realm, AUTH_REALM_NONE, -1))
         SourceRealm = AUTH_SOURCE_NONE;
      else
      /* and last but by no means least "PROMISCUOUS" */
      if (strsame (Realm, AUTH_REALM_PROMISCUOUS, -1))
         SourceRealm = AUTH_SOURCE_PROMISCUOUS;

      if (AuthPolicySysUafWasdIdentifiers)
      {
         /*
            If this is the VMS realm and identifiers are mandatory for
            SYSUAF authentication but the realm is not a specific identifier
            then it must be through the "hard-wired" WASD identifiers.
         */
         if (SourceRealm == AUTH_SOURCE_VMS && AuthPolicySysUafIdentifiers)
            SourceRealm = AUTH_SOURCE_WASD_ID;
      }

      while (*lptr && ISLWS(*lptr)) lptr++;

      /* semicolon separating realm from optional full-access (write) group */
      if (*lptr == ';')
      {
         SourceGroupWrite = AUTH_SOURCE_HTA;

         lptr++;
         while (*lptr && ISLWS(*lptr)) lptr++;
         zptr = (sptr = GroupWrite) + sizeof(GroupWrite);
         while (*lptr &&
                *lptr != ';' &&
                *lptr != '=' &&
                *lptr != ']' &&
                !ISLWS(*lptr) &&
                sptr < zptr)
            *sptr++ = toupper(*lptr++);
         if (sptr >= zptr || !GroupWrite[0])
         {
            AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, problem configuring (first) group at line !UL\n",
               acptr->LineNumber);
            strcpy (Realm, AUTH_REALM_FAIL);
            return;
         }
         *sptr = '\0';

         if (*lptr == '=')
         {
            if (strsame (lptr, "=AGENT", 6))
            {
               lptr += 6;
               SourceGroupWrite = AUTH_SOURCE_AGENT;
            }
            else
            if (strsame (lptr, "=HTA", 4))
            {
               lptr += 4;
               SourceGroupWrite = AUTH_SOURCE_HTA;
            }
            else
            if (strsame (lptr, "=ID", 3))
            {
               lptr += 3;
               SourceGroupWrite = AUTH_SOURCE_ID;
               if (VMSnok (status =
                   AuthConfigIdentifier (GroupWrite, &GroupWriteVmsIdentifier)))
               {
                  AuthConfigReadStatus (&AuthServerConfig,
"%HTTPD-W-AUTH, group !AZ identifier at line !UL\n-!%M\n",
                     GroupWrite, acptr->LineNumber, status);
                  strcpy (Realm, AUTH_REALM_FAIL);
                  return;
               }
            }
            else
            if (strsame (lptr, "=LIST", 5))
            {
               lptr += 5;
               SourceGroupWrite = AUTH_SOURCE_LIST;
            }
            else
            {
               AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, problem configuring (first) group source at line !UL\n",
                  acptr->LineNumber);
               strcpy (Realm, AUTH_REALM_FAIL);
               return;
            }
         }
      }

      /* semicolon separating realm from optional read-only-access group */
      if (*lptr == ';')
      {
         SourceGroupRead = AUTH_SOURCE_HTA;

         lptr++;
         while (*lptr && ISLWS(*lptr)) lptr++;
         zptr = (sptr = GroupRead) + sizeof(GroupRead);
         while (*lptr &&
                *lptr != '=' &&
                *lptr != ']' &&
                !ISLWS(*lptr) &&
                sptr < zptr)
            *sptr++ = toupper(*lptr++);
         if (sptr >= zptr || !GroupRead[0])
         {
            AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, problem configuring second group at line !UL\n",
               acptr->LineNumber);
            strcpy (Realm, AUTH_REALM_FAIL);
            return;
         }
         *sptr = '\0';

         if (*lptr == '=')
         {
            if (strsame (lptr, "=AGENT", 6))
            {
               lptr += 6;
               SourceGroupRead = AUTH_SOURCE_AGENT;
            }
            else
            if (strsame (lptr, "=HTA", 4))
            {
               lptr += 4;
               SourceGroupRead = AUTH_SOURCE_HTA;
            }
            else
            if (strsame (lptr, "=ID", 3))
            {
               lptr += 3;
               SourceGroupRead = AUTH_SOURCE_ID;
               if (VMSnok (status =
                   AuthConfigIdentifier (GroupRead, &GroupReadVmsIdentifier)))
               {
                  AuthConfigReadStatus (&AuthServerConfig,
"%HTTPD-W-AUTH, group !AZ identifier at line !UL\n-!%M\n",
                     GroupWrite, acptr->LineNumber, status);
                  strcpy (Realm, AUTH_REALM_FAIL);
                  return;
               }
            }
            else
            if (strsame (lptr, "=LIST", 5))
            {
               lptr += 5;
               SourceGroupRead = AUTH_SOURCE_LIST;
            }
            else
            {
               AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, problem configuring second group source at line !UL\n",
                  acptr->LineNumber);
               strcpy (Realm, AUTH_REALM_FAIL);
               return;
            }
         }
      }

      while (*lptr && ISLWS(*lptr)) lptr++;
      if (*lptr == ']')
         lptr++;
      else
      {
         AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, generally confused at end of line !UL\n",
            acptr->LineNumber);
         strcpy (Realm, AUTH_REALM_FAIL);
         return;
      }

      /* find start of any realm-context access flags */
      while (*lptr && ISLWS(*lptr)) lptr++;
      if (*lptr)
         strcpy (RealmCanString, lptr);
      else
         RealmCanString[0] = '\0';

      /***************************/
      /* bit more usage checking */
      /***************************/

      if ((SourceGroupWrite == AUTH_SOURCE_ID ||
           SourceGroupRead == AUTH_SOURCE_ID) &&
          SourceRealm != AUTH_SOURCE_VMS &&
          SourceRealm != AUTH_SOURCE_ID)
      {
         AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, identifier used without SYSUAF authentication at line !UL\n",
            acptr->LineNumber);
         strcpy (Realm, AUTH_REALM_FAIL);
         return;
      }

      if (AuthPolicySysUafIdentifiers &&
          SourceRealm == AUTH_SOURCE_VMS)
      {
         AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, realm indicates VMS but /SYSUAF=ID active at line !UL\n",
            acptr->LineNumber);
         strcpy (Realm, AUTH_REALM_FAIL);
         return;
      }

      if (AuthPolicySysUafWasdIdentifiers &&
          SourceRealm == AUTH_SOURCE_WASD_ID &&
          SourceGroupWrite != AUTH_SOURCE_WASD_ID &&
          (GroupWrite[0] || GroupRead[0]))
      {
         AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, \"hard-wired\" WASD identifier usage problem at line !UL\n",
            acptr->LineNumber);
         strcpy (Realm, AUTH_REALM_FAIL);
         return;
      }

      return;
   }

   AuthConfigReadStatus (acptr,
"%HTTPD-W-AUTH, generally confused by line !UL\n",
       acptr->LineNumber);
}

/*****************************************************************************/
/*
Scan through the path list until the first record GREATER than the new path is
encountered.  Insert the new path immediately BEFORE that record.  The data
structure has strings stored immediately following the formally declared
structure and pointed to by character pointers within the formal structure.
*/ 

int AuthConfigAdd
(
struct AuthConfigStruct *acptr,
char *VirtualServerHostPort,
char *Realm,
char *RealmDescription,
unsigned long SourceRealm,
unsigned long RealmVmsIdentifier,
char *GroupWrite,
unsigned long SourceGroupWrite,
unsigned long GroupWriteVmsIdentifier,
char *GroupRead,
unsigned long SourceGroupRead,
unsigned long GroupReadVmsIdentifier,
char *Path,
char *AgentParameter,
char *GroupRestrictList,
char *WorldRestrictList,
unsigned long  GroupCanFlags,
unsigned long  WorldCanFlags,
boolean NoCache
)
{
   register char  *cptr, *pptr, *sptr, *tptr;
   register struct AuthPathRecordStruct  *plptr, *nlptr;

   int  AgentParameterLength,
        GroupReadLength,
        GroupWriteLength,
        GroupRestrictListLength,
        PathLength,
        RealmLength,
        RealmDescriptionLength,
        StringSpace,
        VirtualServerHostPortLength,
        WorldRestrictListLength;

    char  *OffsetPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
"AuthConfigAdd() |%s|\n\
|%s|%s|%d|%08.08X|\n\
|%s|%d|%08.08X|\n\
|%s|%d|%08.08X|\n\
|%s|%s|\n\
|%s|%s|%08.08X|%08.08X|%d|\n",
         VirtualServerHostPort,
         Realm, RealmDescription, SourceRealm, RealmVmsIdentifier,
         GroupWrite, SourceGroupWrite, GroupWriteVmsIdentifier,
         GroupRead, SourceGroupRead, GroupReadVmsIdentifier,
         Path, AgentParameter, GroupRestrictList,
         WorldRestrictList, GroupCanFlags, WorldCanFlags, NoCache);

   if (acptr == NULL) acptr = &AuthServerConfig;

   AgentParameterLength = strlen(AgentParameter);
   GroupReadLength = strlen(GroupRead);
   GroupWriteLength = strlen(GroupWrite);
   PathLength = strlen(Path);
   RealmLength = strlen(Realm);
   RealmDescriptionLength = strlen(RealmDescription);
   GroupRestrictListLength = strlen(GroupRestrictList);
   VirtualServerHostPortLength = strlen(VirtualServerHostPort);
   WorldRestrictListLength = strlen(WorldRestrictList);

   cptr = Path;
   for (plptr = acptr->PathListHead; plptr != NULL; plptr = plptr->NextPtr)
   {
/*
      if (Debug)
         fprintf (stdout, "plptr |%s|%s|%08.08X|\n",
                  plptr->PathPtr, plptr->RealmPtr, plptr->AuthGroupCan);
*/

      pptr = cptr;
      tptr = plptr->PathPtr;
      while (*tptr && *pptr && tolower(*tptr) == tolower(*pptr))
      {
         tptr++;
         pptr++;
      }

      if (!*tptr && !*pptr)
      {
         /* paths are the same, same virtual server? */
         if (*plptr->VirtualServerHostPortPtr != '*')
         {
            /* rule is for a specific virtual server */
            if (strsame (VirtualServerHostPort,
                         plptr->VirtualServerHostPortPtr,
                         -1))
            {
               /* server name and port match, duplicate record! */
               return (RMS$_DUP);
            }
            /* otherwise, just drop through to continue processing */
         }
         else
         {
            /* no specific virtual server, duplicate record! */
            return (RMS$_DUP);
         }
      }

      /* got to end of template and new path longer (sub-path), goes first */
      if (*tptr == '*' && PathLength > plptr->PathLength) break;

      /* got to end of new path, must be a "parent"-path */
      if (*pptr == '*') continue;

      /* if not at end of template and new path is less then add now */
      if (*tptr && (tolower(*tptr) >= tolower(*pptr))) break;
   }

   StringSpace = 9 + /* number of terminating nulls! */
                 AgentParameterLength +
                 GroupReadLength +
                 GroupRestrictListLength +
                 GroupWriteLength +
                 PathLength +
                 RealmLength +
                 RealmDescriptionLength +
                 VirtualServerHostPortLength +
                 WorldRestrictListLength;
   if (Debug) fprintf (stdout, "StringSpace: %d\n", StringSpace);

   nlptr = VmGet (sizeof(struct AuthPathRecordStruct) + StringSpace);
   OffsetPtr = (char*)nlptr + sizeof(struct AuthPathRecordStruct);

   nlptr->AgentParameterPtr = OffsetPtr;
   memcpy (nlptr->AgentParameterPtr, AgentParameter, AgentParameterLength+1);
   OffsetPtr += (nlptr->AgentParameterLength = AgentParameterLength) + 1;

   nlptr->GroupReadPtr = OffsetPtr;
   memcpy (nlptr->GroupReadPtr, GroupRead, GroupReadLength+1);
   OffsetPtr += (nlptr->GroupReadLength = GroupReadLength) + 1;
   nlptr->SourceGroupRead = SourceGroupRead;
   nlptr->GroupReadVmsIdentifier = GroupReadVmsIdentifier;

   nlptr->GroupRestrictListPtr = sptr = OffsetPtr;
   cptr = GroupRestrictList;
   while (*cptr) *sptr++ = tolower(*cptr++);      
   *sptr = '\0';
   OffsetPtr += (nlptr->GroupRestrictListLength =
                 GroupRestrictListLength) + 1;

   nlptr->GroupWritePtr = OffsetPtr;
   memcpy (nlptr->GroupWritePtr, GroupWrite, GroupWriteLength+1);
   OffsetPtr += (nlptr->GroupWriteLength = GroupWriteLength) + 1;
   nlptr->SourceGroupWrite = SourceGroupWrite;
   nlptr->GroupWriteVmsIdentifier = GroupWriteVmsIdentifier;

   nlptr->PathPtr = sptr = OffsetPtr;
   cptr = Path;
   while (*cptr) *sptr++ = tolower(*cptr++);      
   *sptr = '\0';
   OffsetPtr += (nlptr->PathLength = PathLength) + 1;

   nlptr->RealmPtr = OffsetPtr;
   memcpy (nlptr->RealmPtr, Realm, RealmLength+1);
   OffsetPtr += (nlptr->RealmLength = RealmLength) + 1;
   nlptr->SourceRealm = SourceRealm;
   nlptr->RealmVmsIdentifier = RealmVmsIdentifier;

   nlptr->RealmDescrPtr = OffsetPtr;
   memcpy (nlptr->RealmDescrPtr,
           RealmDescription,
           RealmDescriptionLength+1);
   OffsetPtr += (nlptr->RealmDescriptionLength = RealmDescriptionLength) + 1;

   nlptr->VirtualServerHostPortPtr = sptr = OffsetPtr;
   cptr = VirtualServerHostPort;
   while (*cptr) *sptr++ = tolower(*cptr++);      
   *sptr = '\0';
   OffsetPtr += (nlptr->VirtualServerHostPortLength =
                 VirtualServerHostPortLength) + 1;
   nlptr->VirtualServerHostNameHashValue =
      NetHostNameHash (nlptr->VirtualServerHostPortPtr);

   cptr = WorldRestrictList;
   nlptr->WorldRestrictListPtr = sptr = OffsetPtr;
   while (*cptr) *sptr++ = tolower(*cptr++);      
   *sptr = '\0';

   nlptr->AuthGroupCan = GroupCanFlags;
   nlptr->AuthWorldCan = WorldCanFlags;
   nlptr->NoCache = NoCache;

   if (plptr == NULL)
   {
      /* no entry greater than the new one */
      if (acptr->PathListHead == NULL)
      {
         /* empty list */
         acptr->PathListHead = acptr->PathListTail = nlptr;
         nlptr->PrevPtr = nlptr->NextPtr = NULL;
      }
      else
      {
         /* add to end of list */
         nlptr->PrevPtr = acptr->PathListTail;
         acptr->PathListTail->NextPtr = nlptr;
         nlptr->NextPtr = NULL;
         acptr->PathListTail = nlptr;
      }
   }
   else
   {
      /* insert before the entry found */
      nlptr->PrevPtr = plptr->PrevPtr;
      if (nlptr->PrevPtr != NULL) nlptr->PrevPtr->NextPtr = nlptr;
      nlptr->NextPtr = plptr;
      plptr->PrevPtr = nlptr;
      if (acptr->PathListHead == plptr)
          acptr->PathListHead = nlptr;
   }

   if (Debug)
      fprintf (stdout, "nlptr |%s|%s| group: %08.08X world: %08.08X\n",
               nlptr->PathPtr, nlptr->RealmPtr,
               nlptr->AuthGroupCan, nlptr->AuthWorldCan);

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Frees all dynamic structures (memory) in the authorization path list.
*/

AuthConfigFree (struct AuthConfigStruct *acptr)

{
   register int  EntryCount;
   register struct AuthPathRecordStruct  *plptr, *nlptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthConfigFree() %d\n", acptr);

   if (acptr == NULL) acptr = &AuthServerConfig;

   if (acptr->PathListHead == NULL) return;

   for (plptr = acptr->PathListHead; plptr != NULL; plptr = nlptr)
   {
      if (Debug)
         fprintf (stdout, "plptr |%s|%s|%s|%s|\n",
                  plptr->PathPtr, plptr->RealmPtr,
                  plptr->GroupWritePtr, plptr->GroupReadPtr);

      nlptr = plptr->NextPtr;
      VmFree (plptr, FI_LI);
   }

   acptr->PathListHead = acptr->PathListTail = NULL;
}

/****************************************************************************/
/*
Get the identifier value from the supplied name.
*/ 

AuthConfigIdentifier
(
char *NamePtr,
unsigned long  *ValuePtr
)
{
   static $DESCRIPTOR (NameDsc, "");

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthConfigIdentifier() |%s|\n", NamePtr);

   *ValuePtr = 0;
   NameDsc.dsc$a_pointer = NamePtr;
   NameDsc.dsc$w_length = strlen(NamePtr);
   status = sys$asctoid (&NameDsc, ValuePtr, 0);
   if (Debug)
      fprintf (stdout, "sys$asctoid() %%X%08.08X %08.08X\n", status, *ValuePtr);
   return (status);
}

/*****************************************************************************/
/*
Look for a path template matching the request path in the path authorization
database.  If one can't be found return with '->AuthRealmPtr',
'rqptr->rqAuth.GroupRestrictListPtr' and 'rqptr->rqAuth.WorldRestrictListPtr'
pointing to empty strings and the path capabilities '->AuthGroupCan' and
'->AuthWorldCan' set to zero.  If found return with the realm name and path
capabilities set to what's in the database.  The 'QuickIndex' attempts to
reduce search times in larger authorization databases by allowing the search to
begin in the vicinity of a likely hit.  This function must be called with a
parameter of NULL to initialize the quick index after the paths are loaded.
*/ 

int AuthConfigSearch
(
struct RequestStruct *rqptr,
struct AuthConfigStruct *acptr,
char *PathBeingAuthorized
)
{
   static struct AuthPathRecordStruct  *QuickIndex [256];

   register int  ch;
   register char  *cptr, *pptr, *tptr;
   register struct AuthPathRecordStruct  *plptr;

   boolean  LexicographicCutoff;
   int  TotalLength;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthConfigSearch()\n");

   if (acptr == NULL) acptr = &AuthServerConfig;

   if (rqptr == NULL)
   {
      /***************************/
      /* function initialization */
      /***************************/

      /* note the first instance of a path beginning with that character */
      for (ch = 0; ch <= 255; ch++) QuickIndex[ch] = NULL;
      for (plptr = acptr->PathListHead;
           plptr != NULL;
           plptr = plptr->NextPtr)
      {
         /* only if it's a path (begins with a '/') */
         if (plptr->PathPtr[0] != '/')
         {
            /* first of the non-path rules (grouped towards end of list) */
            if (QuickIndex[0] == NULL) QuickIndex[0] = plptr;  
            continue;
         }
         ch = tolower(plptr->PathPtr[1]);
         if (Debug) fprintf (stdout, "%d\n", ch);
         if (QuickIndex[ch] != NULL) continue;
         QuickIndex[ch] = plptr;
         if (Debug) fprintf (stdout, "%d |%s|\n", ch, QuickIndex[ch]->PathPtr);
      }
      return (SS$_NORMAL);
   }

   /**********************/
   /* function execution */
   /**********************/

   if (Debug) fprintf (stdout, "|%s|\n", PathBeingAuthorized);

   if ((plptr = acptr->PathListHead) == NULL) return (STS$K_ERROR);

   cptr = PathBeingAuthorized;
   if (cptr[0] == '/' && cptr[1])
   {
      /* if there is an entry for this character then start with that one */
      ch = tolower(cptr[1]);
      if (QuickIndex[ch] == NULL)
      {
         /* any non-path rules (perhaps full wildcards), if so start there */
         if (QuickIndex[0] == NULL)
         {
            /* can't be any applicable rules */
            return (STS$K_ERROR);
         }
         else
            plptr = QuickIndex[0];  
      }
      else
         plptr = QuickIndex[ch];
   }
   else
   if (QuickIndex[0] != NULL)
   {
      /* if any non-path rules (perhaps full wildcards) start there */
      plptr = QuickIndex[0];  
   }
   else
   {
      /* can't be any applicable rules */
      return (STS$K_ERROR);
   }

   LexicographicCutoff = false;
   if (Debug) fprintf (stdout, "|%s|\n", plptr->PathPtr);
   for ( /* from above */ ; plptr != NULL; plptr = plptr->NextPtr)
   {
      if (Debug)
         fprintf (stdout,
"4 plptr |%s|%s|\n\
|%s|%s|%d|%08.08X|\n\
|%s|%d|%08.08X|\n\
|%s|%d|%08.08X|\n\
|%s|\n\
|%s|%s|\n\
|%08.08X|%08.08X|%d|\n",
            plptr->PathPtr,
            plptr->VirtualServerHostPortPtr,
            plptr->RealmPtr, plptr->RealmDescrPtr,
            plptr->SourceRealm, plptr->RealmVmsIdentifier,
            plptr->GroupWritePtr, plptr->SourceGroupWrite,
            plptr->GroupWriteVmsIdentifier,
            plptr->GroupReadPtr, plptr->SourceGroupRead,
            plptr->GroupReadVmsIdentifier,
            plptr->AgentParameterPtr,
            plptr->GroupRestrictListPtr,
            plptr->WorldRestrictListPtr,
            plptr->AuthGroupCan, plptr->AuthWorldCan, plptr->NoCache);

      if (!LexicographicCutoff &&
          cptr[0] == '/' && plptr->PathPtr[0] == '/' &&
          tolower(plptr->PathPtr[1]) > tolower(cptr[1]))
      {
         /* reached lexicographic cut-off point */
         LexicographicCutoff = true;
         if (QuickIndex[0] == NULL)
         {
            /* can't be any applicable rules */
            return (STS$K_ERROR);
         }
         else
         {
            /* continue with the non-path rules */
            plptr = QuickIndex[0];  
         }
      }

      pptr = cptr;
      tptr = plptr->PathPtr;

      if (rqptr->WatchItem &&
          (WatchEnabled & WATCH_AUTH))
      {
         WatchDataFormatted ("!#AZ !AZ\n",
            plptr->PathLength > 31 ? plptr->PathLength : 31,
            plptr->PathPtr, plptr->VirtualServerHostPortPtr);
      }

      while (*tptr && *pptr &&
             *tptr != '*' &&
             (tolower(*tptr) == tolower(*pptr) ||
              *pptr == '*' || *pptr == '%'))
      {
         /** if (Debug) fprintf (stdout, "|%s|%s|\n", tptr, pptr); **/
         if (*pptr == '*' || *pptr == '%')
            while (*pptr == '*' || *pptr == '%') pptr++;
         else
         {
            tptr++;
            pptr++;
         }
      }

      if (*tptr == '*' || !(*tptr || *pptr))
      {
         /****************/
         /* path matched */
         /****************/

         /* path template ended in a wildcard or exact match */
         if (Debug)
            fprintf (stdout, "|%s|%s|\n",
                     plptr->VirtualServerHostPortPtr,
                     rqptr->ServicePtr->ServerHostPort);

          /* if the following rules apply to all services then break */
         if (*plptr->VirtualServerHostPortPtr == '*')
            break;

         /* if the request service matches the rule service then break */
         if (rqptr->ServicePtr->ServerHostNameHashValue ==
             plptr->VirtualServerHostNameHashValue &&
             NetThisVirtualService (rqptr->ServicePtr->ServerHostPort,
                                    plptr->VirtualServerHostPortPtr))
            break;
      }
   }

   if (plptr == NULL) return (STS$K_ERROR);

   /*
      As the path authorization information is potentially volatile
      (i.e. can be reloaded) we need request-local copies of these fields.
   */ 

   TotalLength = 7 + /* number of terminating nulls */
                 plptr->AgentParameterLength +
                 plptr->GroupWriteLength +
                 plptr->GroupReadLength +
                 plptr->GroupRestrictListLength +
                 plptr->RealmLength +
                 plptr->RealmDescriptionLength +
                 plptr->WorldRestrictListLength;
   if (Debug) fprintf (stdout, "TotalLength: %d\n", TotalLength);
   cptr = VmGetHeap (rqptr, TotalLength);

   memcpy (rqptr->rqAuth.AgentParameterPtr = cptr,
           plptr->AgentParameterPtr, plptr->AgentParameterLength+1);
   cptr += plptr->AgentParameterLength + 1;
   rqptr->rqAuth.AgentParameterLength = plptr->AgentParameterLength;

   memcpy (rqptr->rqAuth.RealmPtr = cptr,
           plptr->RealmPtr, plptr->RealmLength+1);
   cptr += plptr->RealmLength+1;
   rqptr->rqAuth.RealmLength = plptr->RealmLength;
   rqptr->rqAuth.SourceRealm = plptr->SourceRealm;
   rqptr->rqAuth.RealmVmsIdentifier = plptr->RealmVmsIdentifier;

   if (plptr->RealmDescrPtr[0])
   {
      memcpy (rqptr->rqAuth.RealmDescrPtr = cptr,
              plptr->RealmDescrPtr, plptr->RealmDescriptionLength+1);
      cptr += plptr->RealmDescriptionLength+1;
   }
   else
      rqptr->rqAuth.RealmDescrPtr = rqptr->rqAuth.RealmPtr;

   memcpy (rqptr->rqAuth.GroupWritePtr = cptr,
           plptr->GroupWritePtr, plptr->GroupWriteLength+1);
   cptr += plptr->GroupWriteLength+1;
   rqptr->rqAuth.GroupWriteLength = plptr->GroupWriteLength;
   rqptr->rqAuth.SourceGroupWrite = plptr->SourceGroupWrite;
   rqptr->rqAuth.GroupWriteVmsIdentifier = plptr->GroupWriteVmsIdentifier;

   memcpy (rqptr->rqAuth.GroupReadPtr = cptr,
           plptr->GroupReadPtr, plptr->GroupReadLength+1);
   cptr += plptr->GroupReadLength+1;
   rqptr->rqAuth.GroupReadLength = plptr->GroupReadLength;
   rqptr->rqAuth.SourceGroupRead = plptr->SourceGroupRead;
   rqptr->rqAuth.GroupReadVmsIdentifier = plptr->GroupReadVmsIdentifier;

   rqptr->rqAuth.GroupCan = plptr->AuthGroupCan;
   memcpy (rqptr->rqAuth.GroupRestrictListPtr = cptr,
           plptr->GroupRestrictListPtr, plptr->GroupRestrictListLength+1);
   cptr += plptr->GroupRestrictListLength+1;

   rqptr->rqAuth.WorldCan = plptr->AuthWorldCan;
   memcpy (rqptr->rqAuth.WorldRestrictListPtr = cptr,
           plptr->WorldRestrictListPtr, plptr->WorldRestrictListLength+1);
   rqptr->rqAuth.WorldRestrictListPtr = plptr->WorldRestrictListPtr;

   rqptr->rqAuth.NoCache = plptr->NoCache;

   return (SS$_NORMAL);
}

/****************************************************************************/
/*
VMS sys$fao()-formatted print statement. This function formats a read report. 
All lines are concatenated onto a single string of dynamically allocated memory
that (obviously) grows as reports are added to it.  This string is then output
if loading the server configuration or is available for inclusion in an HTML
page.
*/

AuthConfigReadStatus
(
struct AuthConfigStruct *acptr,
char *FormatString,
...
)
{
   int  status,
        argcnt;
   unsigned short  Length;
   unsigned long  *vecptr;
   unsigned long  FaoVector [32];
   char  Buffer [512];
   va_list  argptr;

   /*********/
   /* begin */
   /*********/

   va_count (argcnt);

   if (Debug)
      fprintf (stdout, "AuthConfigReadStatus() |%s| %d\n",
               FormatString, argcnt);

   if (argcnt >= 32) ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);

   vecptr = FaoVector;
   va_start (argptr, FormatString);
   for (argcnt -= 2; argcnt && argcnt < 32; argcnt--)
      *vecptr++ = va_arg (argptr, unsigned long);
   va_end (argptr);

   status = WriteFaol (Buffer, sizeof(Buffer), &Length,
                       FormatString, &FaoVector);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
      ErrorNoticed (status, "WriteFao()", FI_LI);

   if (acptr->RequestPtr == NULL) fputs (Buffer, stdout);

   acptr->ProblemReportPtr =
      VmRealloc (acptr->ProblemReportPtr,
                 acptr->ProblemReportLength+Length+1, FI_LI);

   /* include the terminating null */
   memcpy (acptr->ProblemReportPtr+acptr->ProblemReportLength,
           Buffer, Length+1);
   acptr->ProblemReportLength += Length;

   acptr->ProblemCount++;
}

/*****************************************************************************/
/*
This function just wraps the reporting function, loading a temporary database
if necessary for reporting from the configuration file.
*/ 

AuthConfigReport
(
struct RequestStruct *rqptr,
void *NextTaskFunction,
boolean  UseServerDatabase,
char *VirtualHostNamePort
)
{
   int  status;
   struct AuthConfigStruct  AuthLoad;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthConfigReport()\n");

   if (UseServerDatabase)
      AuthConfigReportNow (rqptr, UseServerDatabase, &AuthServerConfig,
                           VirtualHostNamePort);
   else
   {
      memset (&AuthLoad, 0, sizeof(struct AuthConfigStruct)); 
      /* indicate it's being used for a report */
      AuthLoad.RequestPtr = rqptr;
      AuthConfigRead (&AuthLoad);
      AuthConfigReportNow (rqptr, UseServerDatabase, &AuthLoad,
                           VirtualHostNamePort);
      AuthConfigFree (&AuthLoad);
      if (AuthLoad.ProblemReportPtr != NULL)
         VmFree (AuthLoad.ProblemReportPtr, FI_LI);
   }

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Display all records in the authorization path linked-list. Called from the
admin report.
*/

AuthConfigReportNow
(
struct RequestStruct *rqptr,
boolean UseServerDatabase,
struct AuthConfigStruct *acptr,
char *VirtualHostNamePort
)
{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Path Authorization</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Path Authorization</H3>\n\
!%%\
!20%W\n";

   static char  ProblemReportFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH><FONT COLOR=\"#ff0000\">!UL Report!%s \
!%?At Startup\rDuring Load\r</FONT></TH></TR>\n\
<TR><TD><PRE>!HZ</PRE></TD></TR>\n\
</TABLE>\n";

   static char  VirtualFormFao [] =
"<FORM ACTION=\"!AZ\">\n\
<INPUT TYPE=hidden NAME=server VALUE=\"!%?yes\rno\r\">\n\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Virtual Server</TH></TR>\n\
<TR><TD><NOBR>\n\
<SELECT NAME=virtual>\n";

   static char  SourceFao [] =
"</SELECT>\n\
<INPUT TYPE=submit VALUE=\" select \">\n\
</NOBR>\n\
</TD></TR>\n\
</TABLE>\n\
</FORM>\n\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Source: &quot;!%?Server\rFile\r&quot;</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR>\
<TH ALIGN=RIGHT>File:</TH>\
<TD ALIGN=LEFT>!AZ</TD>\
<TD>&nbsp;</TD><TH>[<A HREF=\"!AZ\">View</A>]</TH>\
</TR>\n\
<TR><TH ALIGN=RIGHT>!AZ</TH>\
<TD ALIGN=LEFT>!20%W</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR>\
<TH>Path</TH><TH>Realm</TH>\
<TH>Group-R+W</TH><TH>Group-R</TH>\
<TH>Group Access</TH><TH>World Access</TH>\
</TR>\n";

   static char  PathFao [] =
"<TR>\
<TD><TT>!AZ</TT></TD><TD>!%%!AZ!AZ</TD>\
<TD>!AZ!AZ</TD><TD>!AZ!AZ</TD><TD>!AZ</TD><TD>!AZ</TD>\
</TR>\n\
!%%!%%!%%!%%";

   static char  NoneFao [] =
"<TR ALIGN=CENTER><TD COLSPAN=5><I>(none)</I></TD></TR>\n";

   static char  EndPageFao [] =
"</TABLE>\n\
</BODY>\n\
</HTML>\n";

   register char  *cptr;
   register unsigned long  *vecptr;
   register struct AuthPathRecordStruct  *plptr, *pplptr;

   int  status,
        EntryCount;
   unsigned long  ServiceContext;
   unsigned long  FaoVector [64];
   char  *CanStringPtr;
   char  GroupCanString [128],
         WorldCanString [128];

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "AuthConfigReportNow() |%s|\n", VirtualHostNamePort);

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;

   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   if (VirtualHostNamePort[0])
   {
      *vecptr++ = "<H3>Virtual Server: !AZ</H3>\n";
      *vecptr++ = VirtualHostNamePort;
   }
   else
      *vecptr++ = "";
   *vecptr++ = &rqptr->rqTime.Vms64bit;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   if (acptr->ProblemReportLength)
   {
      vecptr = FaoVector;
      *vecptr++ = acptr->ProblemCount;
      *vecptr++ = (acptr == &AuthServerConfig);
      *vecptr++ = acptr->ProblemReportPtr;

      status = NetWriteFaol (rqptr, ProblemReportFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   vecptr = FaoVector;
   *vecptr++ = ADMIN_REPORT_AUTH_PATHS;
   *vecptr++ = UseServerDatabase;

   status = NetWriteFaol (rqptr, VirtualFormFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   vecptr = FaoVector;
   *vecptr++ = VirtualHostNamePort[0];
   *vecptr++ = (ServiceCount == 1);

   status = NetWriteFaol (rqptr,
"<OPTION!%?\r SELECT\r VALUE=\"\">!%?none configured\rfor all services\r\n",
                          &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   if (ServiceCount > 1)
   {
      ServiceContext = 0;
      while ((cptr = NetServiceNextHostPort (&ServiceContext)) != NULL)
      {
         vecptr = FaoVector;
         *vecptr++ = cptr;
         *vecptr++ = strsame (cptr, VirtualHostNamePort, -1);
         *vecptr++ = cptr;
         status = NetWriteFaol (rqptr,
                     "<OPTION VALUE=\"!AZ\"!%? SELECTED\r\r>!AZ\n",
                     &FaoVector);
         if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      }
   }

   vecptr = FaoVector;
   *vecptr++ = UseServerDatabase;
   *vecptr++ = acptr->LoadFileName;
   *vecptr++ = MapVmsPath (acptr->LoadFileName, rqptr);
   if (acptr == &AuthServerConfig)
   {
      *vecptr++ = "Loaded:";
      *vecptr++ = &acptr->LoadBinTime;
   }
   else
   {
      *vecptr++ = "Revised:";
      *vecptr++ = &acptr->RevBinTime;
   }

   status = NetWriteFaol (rqptr, SourceFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   pplptr = NULL;
   EntryCount = 0;

   for (plptr = acptr->PathListHead; plptr != NULL; plptr = plptr->NextPtr)
   {
      if (Debug)
         fprintf (stdout,
"plptr |%s|%s|%s|%s|%s|%s||%08.08X|%08.08X|\n",
            plptr->VirtualServerHostPortPtr, 
            plptr->PathPtr, plptr->RealmPtr, plptr->RealmDescrPtr,
            plptr->GroupWritePtr, plptr->GroupReadPtr,
            plptr->AuthGroupCan, plptr->AuthWorldCan);

      if (VirtualHostNamePort[0])
         if (plptr->VirtualServerHostPortPtr[0] != '*')
            if (strcmp (VirtualHostNamePort, plptr->VirtualServerHostPortPtr))
               continue;

      EntryCount++;

      if ((CanStringPtr =
           AuthCanString (plptr->AuthGroupCan, AUTH_CAN_FORMAT_HTML)) == NULL)
         return;
      strcpy (GroupCanString, CanStringPtr);

      if ((CanStringPtr =
           AuthCanString (plptr->AuthWorldCan, AUTH_CAN_FORMAT_HTML)) == NULL)
         return;
      strcpy (WorldCanString, CanStringPtr);

      vecptr = FaoVector;

      if (pplptr == NULL)
         *vecptr++ = plptr->PathPtr;
      else
      if (strsame (plptr->PathPtr, pplptr->PathPtr, -1))
         *vecptr++ = "";
      else
         *vecptr++ = plptr->PathPtr;
      pplptr = plptr;

      if (plptr->RealmDescrPtr[0])
      {
         *vecptr++ = "\"!HZ\"=";
         *vecptr++ = plptr->RealmDescrPtr;
      }
      else
         *vecptr++ = "";

      *vecptr++ = plptr->RealmPtr;
      *vecptr++ = AuthSourceString (plptr->RealmPtr, plptr->SourceRealm);

      *vecptr++ = plptr->GroupWritePtr;
      *vecptr++ = AuthSourceString (plptr->GroupWritePtr,
                                    plptr->SourceGroupWrite);

      *vecptr++ = plptr->GroupReadPtr;
      *vecptr++ = AuthSourceString (plptr->GroupReadPtr,
                                    plptr->SourceGroupRead);

      *vecptr++ = GroupCanString;
      *vecptr++ = WorldCanString;

      if (*plptr->VirtualServerHostPortPtr != '*')
      {
         *vecptr++ =
"<TR><TD></TD><TD COLSPAN=5>\
<FONT SIZE=-1><I>service:</I> !AZ</FONT>\
</TD></TR>\n";
         *vecptr++ = plptr->VirtualServerHostPortPtr;
      }
      else
         *vecptr++ = "";

      if (plptr->AgentParameterPtr[0] ||
          plptr->NoCache)
      {
         *vecptr++ = "<TR><TD></TD><TD COLSPAN=5>!AZ!%%</TD></TR>\n";

         if (plptr->NoCache)
            *vecptr++ = "<FONT SIZE=-1><I>cache:</I> NO</FONT>\n";
         else
            *vecptr++ = "";

         if (plptr->AgentParameterPtr[0])
         {
            *vecptr++ = "<FONT SIZE=-1><I>param=</I>\"!HZ\"</FONT>\n";
            *vecptr++ = plptr->AgentParameterPtr;
         }
         else
            *vecptr++ = "";
      }
      else
         *vecptr++ = "";

      if (plptr->GroupRestrictListPtr[0])
      {
         *vecptr++ =
"<TR><TD></TD><TD COLSPAN=5>\
<FONT SIZE=-1><I>!AZ restricted to:</I>&nbsp;&nbsp;!HZ</FONT>\
</TD></TR>\n";
         if (plptr->GroupWritePtr[0])
            *vecptr++ = "group";
         else
            *vecptr++ = "realm";
         *vecptr++ = plptr->GroupRestrictListPtr;
      }
      else
         *vecptr++ = "";

      if (plptr->WorldRestrictListPtr[0])
      {
         *vecptr++ =
"<TR><TD></TD><TD COLSPAN=5>\
<FONT SIZE=-1><I>world restricted to:</I>&nbsp;&nbsp;!HZ</FONT>\
</TD></TR>\n";
         *vecptr++ = plptr->WorldRestrictListPtr;
      }
      else
         *vecptr++ = "";

      status = NetWriteFaol (rqptr, PathFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   if (!EntryCount)
   {
      status = NetWriteFaol (rqptr, NoneFao, NULL);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   status = NetWriteFaol (rqptr, EndPageFao, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
}

/*****************************************************************************/
/*
Perform a authorization configuration reload from the administration menu.
*/

AuthConfigReload
(
struct RequestStruct *rqptr,
void *NextTaskFunction
)
{
   int  status;
   struct AuthConfigStruct  *acptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthConfigReload()\n");

   AuthConfigInit ();

   acptr = &AuthServerConfig;

   if (acptr->ProblemReportLength)
   {
      ReportSuccess (rqptr,
"$Server !AZ authorization rules reloaded.\n\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH><FONT COLOR=\"#ff0000\">!UL Report!%s During Load</FONT></TH></TR>\n\
<TR><TD><PRE>!HZ</PRE></TD></TR>\n\
</TABLE>\n",
         ServerHostPort, acptr->ProblemCount, acptr->ProblemReportPtr);
   }
   else
      ReportSuccess (rqptr, "$Server !AZ authorization paths reloaded.",
                     ServerHostPort);

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/

