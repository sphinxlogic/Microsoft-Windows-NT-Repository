/*****************************************************************************/
/*
                                  DCL.c

*************
** CAUTION **
*************

THIS MODULE IS TASK-ORIENTED, NOT REQUEST-ORIENTED.

That is, most of the functions take a pointer to DCL task rather than a pointer
to request as do other modules. The reason is simple. In this module the
more-permanent data-structures are those associated with the DCL script
processes, which persist for multiple requests. With the requests transient the
DCL script processes must be managed in their absence. Hence requests are
associated with DCL script processes not vice-versa.


OVERVIEW
--------
Provides multi-threaded, concurrent HTTPd script processes executing DCL.

This module never returns a valid status and ALWAYS calls the supplied next
task (AST) function.  This should check for a generated error message to
determine is there were any problems.

The DCL can either be in the form of a command, or a procedure or executable
image file specification. Both should not be supplied, but file specifications
have precedence. If a file specfication is supplied the module verifies its
existance, and if not qualified with an extension, looks for a procedure first
(".COM"), then an executable image (".EXE"), then through any user-defined
list of file types (extensions) and associated scripting executables (e.g.
".PL" associated with the verb "PERL"). Furthermore, the DCL can be executed
either standalone or as a CGI script (indicated by the presence of a script
name in the request data structure). If a CGI script, then the output stream
is parsed for header information, if not a script then the stream is just
checked for correct carriage control (terminated by a newline). CGI variables
are created for both standalone DCL and scripts, although some (e.g.
WWW_SCRIPT_NAME) will be empty, and meaningless, for standalone DCL. 

The AST-driven nature makes the code a little more difficult to follow, but 
creates a powerful, event-driven, multi-threaded server.  All of the 
necessary functions implementing this module are designed to be non-blocking. 

All of these functions are designed to be, and should be, called at AST 
delivery level, which means they cannot be interrupted at the same level (in 
this case USER mode), and so their actions are essentially atomic at that 
level, meaning no additional synchronization is required for such activities 
as thread disposal, etc.

The HTTPd can maintain a number of script processes limited only by its process 
quotas, memory is dynamically allocated and there are no fixed data structures 
related to script process management. 

The use of byte-streams (effectively "pipes") allows even DCL procedures to
output as HTTP servers, without the need for explicit network I/O. 

Four mailboxes are created for each script process' IPC:

  1.  A mailbox connected to its SYS$COMMAND.  This is used to pass DCL
      commands and/or other data to the script process.  It effectively allows
      the HTTPd to control the activities of the script process this way.

  2.  A mailbox connected to its SYS$OUTPUT.  This recieves records from
      the script process, if required appends HTTP-required carriage-control
      (single <LF>), then sends the record to the client via the network.
      This allows even DCL procedures to supply a correct output stream to
      the client (see next paragraph).

      If the first line from a script is an HTTP status line (e.g.
      "HTTP/1.0 200 ok") then HTTPD assumes the script will be supplying
      a complete HTTP data stream, including full header and required
      carriage control (single <LF> terminating each line).  If the first
      line is not a HTTP status line it assumes CGI script output compliance
      and also ensures each record (line) received has correct HTTP
      carriage-control.

      This stream also attempts to maintain compliance with CGI scripting.
      If the first line output by a script is not an HTTP status line it
      creates and sends one to the client before sending the first line.

  3.  A mailbox defined for the script process by the name HTTP$INPUT.
      This may be used to read the request data steam sent by the client.
      Note that from v4.2 this is also the SYS$INPUT <stdin> stream as well,
      which appears to be the more common CGI implementation. As of version
      4.3 the default behaviour is to supply only the request body to the
      script (CGI standard and the more common implmentation).  Defining the 
      environment variable HTTPD_DCL_FULL_REQUEST it is possible to revert
      to the previous behaviour of supplying the header then the body.
      (It's an easy enough modification for most scripts to skip the header by
      reading until the header-separating empty (blank) line is encountered.)

  4.  A mailbox defined by the name CGIPLUSIN.  This allows CGIplus scripts
      to read a stream of CGI variable information.  Each request begins with
      a comment line "!", which can be used for request start synchronisation
      and may always be discarded, and ends with an empty record (blank line),
      with a variable number of records in between.

The script script processes can use the basic CGI variables (VMS CERN-like) and 
behave very much like a CGI script.

That is, if a script wants to be CGI-compliant it provides as the first line a 
"Status:", "Content-type:" or a "Location:" then a blank line.   If the first 
line output by a script is a "Content-Type:" header line an HTTP "200" status 
line is prepended.  If the first line output by a script is a "Location:" 
redirection header line the redirection is processed to ensure CERN HTTPD/CGI 
behaviour.  An HTTP "302" status line is prepended if not a local redirection. 
If none of these, HTTPD creates a complete HTTP header comprising status line, 
"Content-Type: text/plain" and blank line (this is an extension of CERN HTTPD 
behaviour). 

If the first characters are "HTTP/1.0 ..." the script will be considered to be 
supplying the raw HTTP stream and record boundaries, carriage-control, etc., 
are of no further concern to the module.  This is the equivalent of a
"no-parse-header" script.  If CGI-compliant each record should represent a 
line of output.   That is lines should not be buffered together and sent as a 
block unless the script is supplying a raw HTTP data stream. 


CGI VARIABLES
-------------
See CGI.c module.


CGI-PLUS
--------
CGI plus lower latency, plus greater efficiency, plus less system impact!

CGIplus attempts to eliminate the overhead associated with creating the script
process and then executing the image of a CGI script.  It does this by allowing
the script process and associated image to continue executing in-between uses,
eliminating the startup overhead.  This both reduces the load on the system and
the request latency where one of these scripts is involved. In this sense these
advantages parallel those offered by commercial HTTP server-integration APIs,
such as Netscape NSAPI and Microsoft ISAPI.

The script interface is still largely CGI, which means a new API does not need
to be learned and that existing CGI scripts are simple to modify. The script
must read the CGI variables from CGIPLUSIN. They are supplied as a series of
records (lines) containing the CGI variable name, an equate symbol and then
the variable value. This format may be easily parsed and as the value contains
no encoded characters may be directly used. An empty record (blank line)
indicates the end of the request information. The request may be processed at
that stage.

After processing the CGIplus script can loop, waiting to read the details of
the next request from CGIPLUSIN. The first line read may ALWAYS be discarded
allowing a read to be used as a simple synchronization mechanism.

HTTP output (to the client) is written to SYS$OUTPUT (stdout). End of output
MUST be indicated by writing a special EOF string to the output stream. This
is a KLUDGE, and the least elegant part of CGIplus design, BUT it is also the
simplest implementation and should work in all but the most exceptional
circumstances. The special EOF string has been chosen to be most unlikely to
occur in normal output (a hopefully unique 248 bit sequence), but there is
still a very, very small chance! The CGIplus EOF string is obtained from the
logical name CGIPLUSEOF, defined in the script process's process table, using the
language's equivalent of F$TRNLNM(), SYS$TRNLNM(), or a getenv() call in the C
Language. This string will always contain less than 64 characters and comprise
only common, printable characters. It must be written at the conclusion of a
request's output to the output stream as a single record (line) but may also
contain a <CR><LF> or just <LF> trailing carriage-control (to allow for
programming language constraints). See examples in HT_ROOT:[SRC.CGIPLUS]

HTTP input (raw request stream, header and any body) is still available to the
CGIplus script.

Multiple CGIplus scripts may be executing in script processes at any one time.
This includes multiple instances of any particular script.  It is the server's
task to track these, distributing appropriate requests to idle script processes,
monitoring those currently processing requests, creating new instances if and
when necessary, and deleting the least-used, idle CGIplus script processes when
configurable thresholds are reached.

A CGIplus script can be terminated by the server at any time (the script
process SYS$DELPRC()ed) so resources should be largely quiescent when not
actually processing. CGIplus script processes may also be terminated from the
command line using STOP/ID=. The server administration menu provides a simple
mechansim to purge (stop) all CGIplus processes, allowing the server to be
flushed of all script processes. This can be useful if some new compilation of
a CGIplus script executable needs to made available.

CGIplus scripts are differentiated from "normal" CGI scripts in the mapping
rule configuration file using the "script+" and "exec+" directives.  Of course
it would be possible to design a script to simply modify it's behaviour so it
was possible to execute in both environments.  Simply detecting the presence
or absence of one of the "normal" CGI variables (i.e. DCL symbols,
e.g. WWW_PATH_INFO, WWW_CGI_GATEWAY_INTERFACE, etc.) would be sufficient
indication.

See examples in HT_ROOT:[SRC.CGIPLUS]

April 1998 Note:  It has been observed that under rare circumstances a
persistant script process script-serviced request can die unexpectedly.  This
has been isolated to the following scenario.  A request underway results in a
CGIplus script terminating and the script process exiting.  Any output in the
script's C RTL buffers is flushed during exit, including possibly the CGI
output EOF indicator, generating an I/O AST which is serviced indicating the
request is complete and the CGIplus script is ready for reuse.  In fact it
isn't because the process is running-down.  Before the script process
termination AST can be processed another AST containing a request for that same
CGIplus script is serviced.  The DCL task structure is allocated to the new
request but shortly, possibly immediately after, that DCL task receives the
termination AST and is run-down.  The request receives no output and Netscape
Navigator for instance reports "Document contains no data".  This has been
addressed by checking whether the script has begun processing (by reading from
the COMMAND or CGIPLUSIN variable stream.  If this stream has not been read
from it is considered the above has happened and the script request is
resubmitted to DclBegin().  A limit is placed on the number of times this may
happen in succession, to prevent an errant script from producing a runaway
condition in the server.


CGIPLUS RUNTIME
---------------
This is a variation on the CGIplus environment.  It allows for mapping a
request path into *three* components (well sort of).  MAPURL.C allows an EXEC
to do some special mapping, essentially the derivation of a special run-time
file (script), then completely remapping the whole thing again to derive a
script file name (provided as a "parameter" to the executing run-time file) and
a resultant path.  The idea is the run-time environment is some sort of
persistant engine/interpreter operating in a CGIplus environment and getting
its requests via the CGIplus stream.  The actual script to be processed by it
is passed as CGI variables SCRIPT_NAME and SCRIPT_FILENAME which the engine
can then use as source for it's interpreter.  The rest of the environment is
normal CGI/CGIplus.  When finished the engine then runs-down the processing
environment, signals CGIplus-EOF and goes quiescent waiting for the next
request.

These run-time environments are so much like CGIplus scripts (with only a
slightly different handling of the script file name itself) that CGIplus
scripts can behave as run-time environments.  For example the CONAN script.  It
essentially "interprets" the "scripting" input of a VMS Help or text library. 
See the examples in the section immediately below.


SCRIPT RUNTIME ENVIRONMENTS
---------------------------
File types (extensions) and associated scripting languages can be defined in
the configuration file.  The syntax is "type foreign-verb".  For example:

  [DclRunTime]
  .PL  $PERL_EXE:PERL.EXE
  .CGI PERL

Two are predefined, ".COM" for DCL procedures, and ".EXE" for executables. 
There are two further run-time types, CGIplus and (persitant) Run-Time
Environment (RTE) indicated by enclosing them in parentheses.  For example:

  [DclRunTime]
  .PL  (HT_EXE:PERLRTE.EXE)
  .HLB (CGI-BIN:[000000]CONAN)

When these are encountered against a file type the script processing is
restarted from the current CGI type, to either CGIplus or RTE respectively. 
This incurs a small request processing penalty but the potential efficiencies
of the latter two environments make it well worthwhile.

NOTE: it is assumed the RTE executable/procedure exists.  No check is made by
the server for its existance or access permissions before activating under DCL.


CGI CALLOUT
-----------
The CGIplus input/output streams are used to provide support for the script
process to "escape" from the normal SYS$OUTPUT stream and send records directly
to a server function for interpretation and processing.  In turn this function
can return records to the script via the CGIPLUSIN stream.  This works for
*BOTH* CGIplus *AND* vanilla CGI scripting!

The script indicates it wishes to suspend normal output by providing a record
containing the string found in the script process' CGIPLUSESC logical.  End of
this mode of communication is indicated by a record containing the string from
the CGIPLUSEOT logical (after which output to the client is resumed).  These
sequences are generated and used in much the same way as CGIPLUSEOF.

This functionality is used to supports CGIplus scripts that act not in the
traditional role as a CGI script but as "agents" to perform some required
function transparently to request processing.  An obvious example is an
external authentication/authorization processor.  These agents execute in the
normal CGI environment, with the request's CGI variables available (with some
minor differences depending on authorization state), <stdout> output stream,
etc.  There are some behavioural constraints on agents but this general
approach confers the considerable benefits of being able to write and operate
these agents as if CGI/CGIplus scripts, even as (CG)ISAPI DLLs.

A default callout for a CGIplus script is provided.  This function provides a
number of operations that may be useful to special-purpose scripts.  The
responses provided by the server are always an HTTP-like code, 200 for success,
400 for script request error, etc., with trailing plain-text explanation. 
The provision of and requirement for reading a response may be suppressed by
leading the directive with a '!' or '#'.

CGI "callout" requests (case-insensitive):

  AUTH-FILE:string            authorize/deny SYSPRV access to file specified
  CLIENT-READ:[string]        initiate reads directly from client to script
  GATEWAY-BEGIN:integer       HTTP response status code (e.g. 200) BG: device
  GATEWAY-END:integer         count of bytes output directly to the BG: device
  LIFETIME:integer            or "none" sets the idle script process lifetime
  MAP-FILE:string             map the supplied file to a path
  MAP-PATH:string             map the supplied path to a file
  NOOP:[string]               do nothing, just return a success status
  TIMEOUT-NOPROGRESS:integer  or "none" sets request output timeout
  TIMEOUT-OUTPUT:integer      or "none" sets request output timeout

(all times are in minutes)


CLIENT-READ: CALLOUT
--------------------
A script can initiate reads direct from the client using the CLIENT-READ:
callout.  Although this has little value for the standard browser, which when
using HTTP will only supply a body with a POSTed request and then only as a
block of request data, a custom application or Java applet could initiate an
"interactive" dialog with a script.  When the CLIENT-READ: callout is received
by the server it queues a network read from the client.  If an when this
completes the record is written to the script via the normal HTTP$INPUT stream. 
The script can write records to the client via it's normal SYS$OUTPUT stream. 
This I/O is asynchronous.  The client records read are transported via the
normal server protocols and so support communication via SSL, providing a
secured stream for such communication.  Any functionality that can be built
into a server-end script and it's associated client-end application should be
able to be supported via this mechanism.  Of course, for extended transactions
some consideration must be given to request and script timeouts.


GATEWAY_BG
----------
The CGI.C module provides a "GATEWAY_BG" CGI variable that contains the BG:
(socket) device connected to the client.  This device is created shareable. 
Opening a channel to it allows a script to directly output to the TCP/IP
socket, bypassing the server completely.  NEEDLESS TO SAY THIS REDUCES OVERHEAD
CONSIDERABLY and for a certain class of services may be appropriate.  Note that
this is a completely RAW stream, the script must supply all carriage-control,
etc.  Also, because it is raw, it is also completely unencrypted and so cannot
be used with an SSL request or WATCHed for trouble-shooting purposes.

The script must supply a full NPH response header to the client, and a
GATEWAY-BEGIN:nnn callout to the server, supplying (for logging, etc.) the HTTP
status code of the response.  When the response body transmission is complete
the script must supply a GATEWAY-END:nnn callout, providing the server with
the data count transfered (again for logging, etc.).  If a channel to the BG:
device is opened it should always be closed when it is finished with.  Failure
to do so could lead to resource starvation for the server.  When complete the
script just concludes as normal.  The following is an example.

  fflush (stdout);
  fprintf (stdout, "%s\n", getenv("CGIPLUSESC"));
  fflush (stdout);
  fprintf (stdout, "GATEWAY-BEGIN: %d\n", 200);
  fflush (stdout);

  byteCount = fprintf (BgOut, "All sorts of rubbish to the raw socket!\n");

  fprintf (stdout, "GATEWAY-END: %d\n", bytesCount);
  fflush (stdout);
  fprintf (stdout, "%s\n", getenv("CGIPLUSEOT"));
  fflush (stdout);


ZOMBIES
-------
The reuse of DCL script processes for CGI scripting provides very significant
performance gains with very little _real_ possibility of undesirable
interaction between uses (where scripts are "well-behaved", which should be all
enviornments). When a non-zero zombie lifetime is specified DCL script
processes implicitly persist between uses for standard CGI and DCL (SSI)
commands as well as explicitly with CGIplus scripts. When not being used to
process a request these script processes are termed "zombies" ;^) they are
neither "alive" (executing a script and processing a request) nor are they
"dead" (script process deleted and task structure free). Instead the script
process is in a LEF state waiting for more input via CGIPLUSIN. A great deal of
care is taken to ensure there is no interaction between uses (all symbols are
deleted, output mailbox is emptied), but there can be no "iron-clad" guarantee.
Use of zombies (persistant DCL processes) is disabled by setting the
appropriate configuration parameter to zero. The same DCL EOF mechansism is
used to signal end-of-output in all process-persistant environments.


SCRIPTING PROCESSES
-------------------
As of WASD 7.1 the creation of scripting processes has been moved from
lib$spawn() to sys$creprc().  This was primarily to support detached processes
executing under a different persona.  There are two modes for scripting now. 

The first exclusively bases scripting on subprocesses (still created using
sys$creprc()) executing using the server account).  This is (should be ;^)
completely compatible with versions prior to WASD 7.1 and can be supported on
all previous VMS versions WASD compiled and executed under.

The second mode uses detached processes.  These are completely autonomous
processes, with full, not pooled quotas, etc.  This may be an advantage in
itself, with resource exhaustion (by the server itself) less likely.  These
processes would usually be created using the same account as the server, but
with the server using the sys$persona...() services (the basics available since
VMS V6.2) can be executing under a different account opening up a whole raft of
possibilities (a la U**x setuid()), see below.

One of the real advantages in using subprocesses is their automatic cleanup
during parent process deletion.  With detached processes there is no such
convenience.  It is very much up to the application author to completely manage
the life-cycle of these processes.  Whilst the author wishes to only employ
user-mode code this becomes an issue under some circumstances.  The server
maintains a list of all processes it manages and so during normal image
run-down the exit handler can sys$delprc() these without any trouble.  This
will probably be 99.9% of the time.  The other 0.1% might be represented by a
site administrator doing a STOP/ID= instead of the more usual and convenient
HTTPD/DO=EXIT on the server process for some reason.  The STOP results in the
exit handler not gaining control and so any scripting processes not being
deleted.

To avoid having potentially a large number of now unmanaged processes left
permanently on the system (or worse still, after a number of these accumulating
on the system), the server during startup scans all candidate processes on the
system and deletes those associated with it's previous incarnation.  How can it
tell processes it created from any others?  Good question!  Well, it may have
created them under a different account so it can't just delete any others
running under it's account besides itself, particularly if there may be
multiple server executing on the one system.  OK, how do we find them?  These
processes have a mailbox 'terminal', so scan for those with 'MBA'.  So do lots
of other processes!  But only those created by the server have a specific ACL
attached to the device, with a special, unique identifier in the first ACE.  If
this ACL is detected the process is deleted.  The rights identifier must be
server-process-unique and by default is generated from the process name.  For
instance "HTTPd:80" would require an identifier "WASD_HTTPD_80".  Not too
complex, especially considering the basics of the code to create such an ACL
must exist anyway, allowing processes under non-server accounts to connect to
them.

Yet another issue!  With detached processes created via LOGINOUT.EXE the full
process life-cycle is undertaken, including SYLOGIN.COM and LOGIN.COM, which
may write to SYS$OUTPUT during execution.  This output is obviously undesirable
;^) and so is absorbed.  A sentinal (similar to those used for script EOF and
callout ESC and EOT) is output when the server supplied DCL commands being read
via the SYS$COMMAND mailbox gain control.  This is detected by the server,
output absorbtion is turned off and normal CGI output processing begun.

Scripting process priorities are set in the following way.  Script processes
created for execution under the server username, or a username specified via a
"SET SCRIPT=AS=" are created one priority lower than the server process itself. 
Processes to be executed under a /~username, that is via a "SET SCRIPT=AS=~"
rule, are created two priorities lower than the server.  The rationale being
that the server process itself should always have a slight edge (it will
probably be I/O bound anyway), and "server" scripts should have a slight edge
over "user" scripts.  This way the server should respond quickly, even if
script processing on a busy system then takes a little time to complete the
request.  For example, if the server executes at 4 then scripts created under
the server account will execute at 3 and /~username scripts at 2.  These may be
changed in DCL.H and via recompilation.


"suEXEC"/"SETUID" SCRIPTING
---------------------------
The detached scripting mechanism described above is coupled with the VMS V6.0
and later sys$persona...() system services to allow scripting under user
accounts specified by the system administrator using mapping rules.  This must
be enabled using the command-line qualifier /PERSONA.  As with all scripting
this should be used with caution, although the detached script process,
isolated from the main server by account differences, should not be able to
affect the server directly.  This only interaction with it should be via the
IPC mailboxes, which are still owned by the server process, with the user
script granted access via an ACL on the device.

The /PERSONA qualifier takes an optional rights identifier parameter.  If this
is supplied access to the persona services (as as a consequence all scripting)
is controlled by account possession of the identifier.  Note that this includes
*all* accounts, including the HTTP server account.  The format of the qualifier
use then becomes something like /PERSONA=WASD_SCRIPTING.

The 'SET /path/* SCRIPT=AS=username' mapping rule allows user names (accounts)
to be specified for (a) script(s) with a particular path.  For instance, the
script "/database/query" could be set up to execute under the user name
DATABASE using rules similar to the following:

  set /database/@ script=as=DATABASE
  exec /database/@ /database_root/cgi-bin/@

General user scripting (that is, access to accounts via the "/~username" style
syntax) may also be enabled using rules such as the following:

  set /~@/cgi-bin/@ script=as=~
  # the following is NOT a typo, the rule is UXEC (User eXEC)
  uxec /~@/cgi-bin/@ /@/www/cgi-bin/@
  user /~@/@ /@/www/@
  redirect /~@ ///~@/

For requests that have been authenticated using the SYSUAF, the username
may provide the scripting account.  Use a SET script=as=$ rule, where the
dollar indicates that before activating the script the server should substitute
the authenticated VMS username ... CAUTION!

  set /cgi-bin/showme* script=as=$

It is also possible to direct the server to execute *all* of it's own scripts
under some non-server account by prefixing the entire rule file using something
like the following rule.

  set /@ script=as=NOBODY


HT_SCRATCH
----------
If defined, this logical locates a directory where scripts can place temporary
files.  Although these scripts should clean up after themselves, temporary or
working files placed into this directory are automatically deleted if last
modified earlier than [DclCleanupScratchMinutesOld] before the scan starts. 
The scan that searches for and deletes these files if present occurs either
when there are no more script processes active or not greater than every
[DclCleanupScratchMinutesMax] minutes.

The CGI variable 'WWW_UNIQUE_ID' can be used to generate unique file names.  To
prevent a file being automatically cleaned up make the first character of it's
name a dollar symbol.  The following DCL code fragment creates unique server
and script file names.

  $ NAME = F$PARSE(WWW_SCRIPT_NAME,,,"NAME")
  $ FILENAME = NAME + "." + WWW_UNIQUE_ID
  $ OPEN /WRITE TMPFILE 'FILENAME'


LOGICAL NAMES
-------------
HTTPD$LOGIN     if defined, provides a command procedure executed immediately
                            before the script command/procedure/image
HTTPD$SCRATCH   if defined, directory for working/scratch files used by scripts
                            (cleaned up every [DclZombieLifeTime] minutes max.)
HTTPD$VERIFY    if defined, turns on script/DCL-level verify


VERSION HISTORY
---------------
05-DEC-2000  MGD  DclCleanupScratch(),
                  modify HTTPD$VERIFY to allow for strict CGI output
19-NOV-2000  MGD  bugfix; for $persona_assume() on VAX (sigh!)
01-OCT-2000  MGD  scripting process creation using sys$creprc(),
                  detached and persona-based scripting
13-SEP-2000  MGD  suppress callout response using leading '!' or '#',
                  APACHE_INPUT changed to APACHE$INPUT (1.3-12)
                  add GATEWAY-BEGIN: and GATEWAY-END: callouts,
                  add CLIENT-READ: callout reads direct from client to script
08-AUG-2000  MGD  limit script output of ENDOFFILE,
24-JUN-2000  MGD  persistant run-time environments,
                  script cache now uses mapped script file name,
                  fixed potential problem when setting 'DclSysOutputSize',
                  bugfix; HEAD requests specifying content-length
27-MAY-2000  MGD  add BYTLM check before creating mailboxes
08-APR-2000  MGD  some (VMS) Apache compatibility,
                  if(!cfptr->cfScript.Enabled)
04-MAR-2000  MGD  use NetWriteFaol(), et.al.
13-JAN-2000  MGD  add OPCOM messages
03-JAN-2000  MGD  support ODS-2 and ODS-5 using ODS module for script find
28-NOV-1999  MGD  provide HTTPD$LOGIN
10-OCT-1999  MGD  make SYS$COMMAND and CGIPLUSIN mailbox sizes configurable,
                  bugfix; DclSysOutputToClientAst()
28-AUG-1999  MGD  callout/agent support,
                  support Purveyor/Cern WWW_IN: and WWW_OUT:,
                  bugfix; sizeof(StopId)-1
12-JUN-1999  MGD  change some WatchData() to WatchDataDump()
12-FEB-1999  MGD  refine WATCH information
07-NOV-1998  MGD  WATCH facility
17-OCT-1998  MGD  script name cache,
                  error report support
19-SEP-1998  MGD  improve granularity of script search,
                  do not search for established CGIplus scripts
                  (this reduces CGIplus script activation time by 50%!!)
15-AUG-1998  MGD  replace per-script process timers with DclSupervisor()
27-MAY-1998  MGD  generate CGI variables only once for any one request
02-APR-1998  MGD  see "April 1998 Note" above,
                  report status 500/501 if script returns no output
28-MAR-1998  MGD  ensure script output is null-terminated (for CGI.C)
16-DEC-1997  MGD  generalized CGI processing unbundled into CGI.c module
06-DEC-1997  MGD  resolving a suspected inconsistent AST delivery situation
                  by requiring all $QIO()s with an AST routine to ensure any
                  queueing errors, etc. are reported via the AST routine
19-OCT-1997  MGD  extensible script run-time environment,
                  HTTP_ACCEPT_CHARSET, HTTP_FORWARDED and HTTP_HOST variables,
                  change in behaviour: CGI "Content-Type:" response bodies now
                  only have carriage-control checked/adjusted if "text/..."
10-SEP-1997  MGD  add "!'F$VERIFY(0)" to start of DCL in case verify on account
09-AUG-1997  MGD  ACCEPT_LANGUAGE variable
01-AUG-1997  MGD  allow supplying request header AS WELL AS body, or only body,
                  added AUTH_REALM, AUTH_GROUP, HTTP_ACCEPT, and 
                  REQUEST_TIME_GMT/LOCAL CGI variables
01-JUN-1997  MGD  Persistant DCL processes, CGIplus, new for HTTPd v4.2,
                  DCL.C completely re-designed!
26-APR-1997  MGD  bugfix; serious flaw POST content handling since v4.0
                  to REQUEST.C, PUT.C in version 4.0 (rewrite of HTTP$INPUT)
01-FEB-1997  MGD  HTTPd version 4
14-NOV-1996  MGD  bugfix; no status was being returned after "DELETE/SYMBOL X"
                  in DclSysCommandStringSymbol()
06-APR-1996  MGD  miscellaneous refinements
26-MAR-1996  MGD  added WWW_HTTP_AUTHENTICATION, scripts can now authenticate
01-DEC-1995  MGD  HTTPd version 3
19-SEP-1995  MGD  changed carriage-control on records from <CR><LF> (the strict
                  HTTP requirement) to single newline (<LF>, de facto standard)
                  This will be slightly more efficient, and "more compliant"!
21-APR-1995  MGD  bugfix; DclSysOutputAst()
03-APR-1995  MGD  added remote user authentication and CGI symbol
20-MAR-1995  MGD  bugfix; DclQioHttpInput()
20-DEC-1994  MGD  initial development as a module for multi-threaded daemon
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */

/* cmbdef.h is not defined for VAXC 3.n */
#define CMB$M_READONLY 0x01
#define CMB$M_WRITEONLY 0x02

/* let's just make sure these are available everywhere */
#define IO$M_NORSWAIT 0x400
#define SS$_MBFULL 0x000008d8

#include <descrip.h>
#include <iodef.h>
#include <jpidef.h>
#include <libdef.h>
#include <prcdef.h>
#include <prvdef.h>
#include <rms.h>
#include <ssdef.h>
#include <stsdef.h>
#include <syidef.h>

/* application header files */
#include "wasd.h"

#define WASD_MODULE "DCL"

/* provides code to support vanilla-CGI use of CGIplus callouts */
#define CGIPLUS_CALLOUT_FOR_CGI 1

/* provides APACHE$INPUT: stream for VMS Apache compatibility */
#define STREAMS_FOR_APACHE 1

/* provides WWW_IN: and WWW_OUT: streams for Purveyor/Cern compatibility */
#define STREAMS_FOR_PURVEYOR_AND_CERN 1

/******************/
/* global storage */
/******************/

boolean  DclUseZombies;

int  DclCgiPlusLifeTimePurgeCount,
     DclCgiPlusInSize,
     DclCleanupMinutesMax,
     DclCleanupMinutesOld,
     DclDetachProcessPriorityServer,
     DclDetachProcessPriorityUser,
     DclHitHardLimitCount,
     DclMailboxBytLmRequired,
     DclPersonaServicesAvailable,
     DclPurgeCount,
     DclPurgeScriptProcessesCount,
     DclPurgeScriptNameCacheCount,
     DclScriptDetachProcess,
     DclSoftLimitPurgeCount,
     DclScriptProcessCount,
     DclScriptProcessHardLimit,
     DclScriptProcessSoftLimit,
     DclSysCommandSize,
     DclSysOutputSize,
     DclZombieLifeTimePurgeCount;

struct ListHeadStruct  DclTaskList;

struct ListHeadStruct  DclScriptNameCacheList;

#define DEFAULT_CGI_VARIABLE_PREFIX "WWW_"
char DclCgiVariablePrefix [32] = DEFAULT_CGI_VARIABLE_PREFIX;
int DclCgiVariablePrefixLength = sizeof(DEFAULT_CGI_VARIABLE_PREFIX)-1;

#define DCL_RUNTIME_EXE DclRunTimeExe
#define DCL_RUNTIME_COM DclRunTimeProc
char  DclRunTimeExe [] = "$",
      DclRunTimeProc [] = "@";

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern boolean  OperateWithSysPrv;

extern int  CliPersonaEnabled,
            HttpdBytLmAvailable,
            NetAcceptBytLmRequired,
            NetListenBytLmRequired,
            NetReadBufferSize,
            OpcomMessages,
            OutputBufferSize,
            ProcessPriority,
            ServerPort,
            WatchEnabled;

extern unsigned long  PersonaRightsIdent;

extern unsigned long  DetachMask[],
                      SysPrvMask[],
                      WorldMask[];

extern char  ErrorSanityCheck[],
             HttpProtocol[],
             HttpdUserName[],
             ProcessIdentName[],
             ServerHostPort[],
             SoftwareID[],
             Utility[];

extern struct  ListHeadStruct  PersonaCacheList;
extern int  PersonaCacheCount,
            PersonaCacheEntries;

extern struct AccountingStruct Accounting;
extern struct ConfigStruct Config;
extern struct MsgStruct Msgs;

/*****************************************************************************/
/*
Set and ensure limits are reasonable at server startup.
*/ 

DclInit ()

{
   int  status,
        SetPrvStatus;
   char  *cptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DclInit()\n");

   /* command line overrides configuration, default fallbacks */
   if (!DclSysCommandSize) DclSysCommandSize = Config.cfBuffer.SizeDclCommand;
   if (!DclSysCommandSize) DclSysCommandSize = DEFAULT_DCL_SYSCOMMAND_SIZE;
   if (!DclSysOutputSize) DclSysOutputSize = Config.cfBuffer.SizeDclOutput;
   /* if not specified then make it the same as the network buffer */
   if (!DclSysOutputSize) DclSysOutputSize = OutputBufferSize;
   if (!DclSysOutputSize) DclSysOutputSize = DEFAULT_DCL_SYSOUTPUT_SIZE;
   if (!DclCgiPlusInSize) DclCgiPlusInSize = Config.cfBuffer.SizeDclCgiPlusIn;
   if (!DclCgiPlusInSize) DclCgiPlusInSize = DEFAULT_DCL_CGIPLUSIN_SIZE;
   /* HTTP$INPUT size is determined by network read buffer size! */

   DclScriptProcessSoftLimit = Config.cfScript.ScriptProcessSoftLimit;
   if (DclScriptProcessSoftLimit <= 0 || DclScriptProcessSoftLimit > 99)
      DclScriptProcessSoftLimit = Config.cfServer.BusyLimit;

   DclScriptProcessHardLimit = Config.cfScript.ScriptProcessHardLimit;
   if (DclScriptProcessHardLimit <= DclScriptProcessSoftLimit ||
       DclScriptProcessHardLimit > 99)
      DclScriptProcessHardLimit = DclScriptProcessSoftLimit +
                                  (DclScriptProcessSoftLimit / 4);

   DclCleanupMinutesMax = Config.cfScript.CleanupScratchMinutesMax;
   DclCleanupMinutesOld = Config.cfScript.CleanupScratchMinutesOld;
   if (DclCleanupMinutesOld < DclCleanupMinutesMax)
      DclCleanupMinutesOld = DclCleanupMinutesMax;

   if (Config.cfScript.ZombieLifeTime) DclUseZombies = true;

   if (DclScriptDetachProcess = Config.cfScript.DetachProcess)
   {
      /* initialize the rights identifier required for detached processes */
      status = DclMailboxAcl (NULL, NULL);
      if (VMSnok(status))
      {
         DclScriptDetachProcess = false;
         WriteFaoStdout (
"%!AZ-W-DCL, detached processes !AZ disabled\n-!%M\n",
            Utility, ProcessIdentName, status);
      }
   }
   if (DclScriptDetachProcess)
   {
      WriteFaoStdout ("%!AZ-I-DCL, detached process scripting active\n",
                      Utility);

      DclCleanupScriptProcesses ();

      if (VMSok (status = PersonaInit ()))
      {
         if (DclPersonaServicesAvailable = CliPersonaEnabled)
            WriteFaoStdout ("%!AZ-I-DCL, persona services enabled\n", Utility);
         else
            WriteFaoStdout (
"%!AZ-I-DCL, persona services not enabled at command line\n",
               Utility);
      }
      else
      if (status == SS$_ABORT) 
         WriteFaoStdout ("%!AZ-W-DCL, persona services not available\n",
                         Utility);
      else
         ErrorExitVmsStatus (status, "PersonaInit()", FI_LI);

      if (Config.cfScript.DetachProcessPriority[0])
      {
         /* get at most two integers from this parameter */
         cptr = Config.cfScript.DetachProcessPriority;
         while (*cptr && !isdigit(*cptr)) cptr++;
         if (isdigit(*cptr))
         {
            DclDetachProcessPriorityServer = atoi(cptr);
            while (*cptr && isdigit(*cptr)) cptr++;
         }
         while (*cptr && !isdigit(*cptr)) cptr++;
         if (isdigit(*cptr)) DclDetachProcessPriorityUser = atoi(cptr);
         /* can't set user script priorities above those of the server! */
         if (DclDetachProcessPriorityUser > DclDetachProcessPriorityServer)
            DclDetachProcessPriorityUser = DclDetachProcessPriorityServer;
      }
   }
   else
      WriteFaoStdout ("%!AZ-I-DCL, subprocess scripting active\n", Utility);
}

/*****************************************************************************/
/*
This function does not return a status value. If an error occurs the
'NextTaskFunction()' is executed. The calling routine may assume that this
module will always execute the 'NextTaskFunction()' at some stage. No need to
look for an established CGIplus script, we know it's there otherwise it never
would have been allocated. For new CGIplus scripts, as well as for standard
CGI scripts, first find the script file (as well as confirming it does exist!)
Already established CGIplus scripts and DCL commands can begin I/O with the
script process immediately.
*/ 

DclBegin
(
struct RequestStruct *rqptr,
void *NextTaskFunction,
char *DclCommand,
char *ScriptName,
char *CgiScriptFileName,
char *CgiPlusScriptFileName,
char *RteFileName,
void *CalloutFunction
)
{
   boolean  MappedScriptAs;
   int  status,
        BasePriority,
        TaskType;
   char  *RteFileNamePtr,
         *ScriptAsPtr;
   struct DclTaskStruct  *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
   {
      fprintf (stdout,
"DclBegin()\n\
DclCommand     |%s|\n\
ScriptName     |%s|\n\
CgiScriptFileName |%s|\n\
CgiPlusScriptFileName |%s|\n\
RteFileName    |%s|\n\
CalloutFunction: %d\n\
PathInfoPtr    |%s|\n\
QueryStringPtr |%s|\n",
      DclCommand, ScriptName, CgiScriptFileName, CgiPlusScriptFileName,
      RteFileName, CalloutFunction, rqptr->rqHeader.PathInfoPtr,
      rqptr->rqHeader.QueryStringPtr);
   }

   if (rqptr->rqResponse.ErrorReportPtr != NULL)
   {
      /* previous error, cause threaded processing to unravel */
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   if (!Config.cfScript.Enabled)
   {
      Accounting.RequestForbiddenCount++;
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_GENERAL_DISABLED), FI_LI);
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   BasePriority = ProcessPriority - DclDetachProcessPriorityServer;
   if (rqptr->rqPathSet.ScriptAsPtr == NULL)
   {
      /* no specific user account has been specified */
      if (DclScriptDetachProcess)
         ScriptAsPtr = HttpdUserName;
      else
         ScriptAsPtr = "";
      MappedScriptAs = false;
   }
   else
   if (rqptr->rqPathSet.ScriptAsPtr[0] == '~')
   {
      /* from a user rule mapping */
      ScriptAsPtr = rqptr->rqPathSet.ScriptAsPtr+1;
      BasePriority = ProcessPriority - DclDetachProcessPriorityUser;
      MappedScriptAs = true;
   }
   else
   if (rqptr->rqPathSet.ScriptAsPtr[0] == '$')
   {
      /* the SYSUAF authenticated username */
      if (rqptr->RemoteUser[0] &&
          rqptr->rqAuth.SysUafAuthenticated)
      {
         ScriptAsPtr = rqptr->RemoteUser;
         BasePriority = ProcessPriority - DclDetachProcessPriorityUser;
         MappedScriptAs = true;
      }
      else
      {
         rqptr->rqResponse.HttpStatus = 403;
         ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_REQUIRED), FI_LI);
         SysDclAst (NextTaskFunction, rqptr);
         return;
      }
   }
   else
   {
      /* an explicitly specified username */
      ScriptAsPtr = rqptr->rqPathSet.ScriptAsPtr;
      MappedScriptAs = true;
   }
   if (BasePriority < 0) BasePriority = 0;

   if (RteFileName != NULL && RteFileName[0])
      TaskType = DCL_TASK_TYPE_RTE_SCRIPT;
   else
   if (CgiPlusScriptFileName != NULL && CgiPlusScriptFileName[0])
      TaskType = DCL_TASK_TYPE_CGIPLUS_SCRIPT;
   else
   if (CgiScriptFileName != NULL && CgiScriptFileName[0])
      TaskType = DCL_TASK_TYPE_CGI_SCRIPT;
   else
   if (DclCommand != NULL && DclCommand[0])
      TaskType = DCL_TASK_TYPE_CLI;
   else
      ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_RESPONSE))
   {
      switch (TaskType)
      {
         case DCL_TASK_TYPE_CGI_SCRIPT :
            WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                       "SCRIPT!%% CGI !AZ !AZ",
                       ScriptAsPtr[0] ? " as !AZ" : "", ScriptAsPtr,
                       ScriptName, CgiScriptFileName);
            break;
         case DCL_TASK_TYPE_CGIPLUS_SCRIPT :
            WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                       "SCRIPT!%% CGIplus !AZ !AZ",
                       ScriptAsPtr[0] ? " as !AZ" : "", ScriptAsPtr,
                       ScriptName, CgiPlusScriptFileName);
            break;
         case DCL_TASK_TYPE_RTE_SCRIPT :
            WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                       "SCRIPT!%% RTE !AZ !AZ !AZ",
                       ScriptAsPtr[0] ? " as !AZ" : "", ScriptAsPtr,
                       ScriptName, CgiScriptFileName, RteFileName);
            break;
         case DCL_TASK_TYPE_CLI :
            WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                       "CLI!%% !AZ", 
                       ScriptAsPtr[0] ? " as !AZ" : "", ScriptAsPtr,
                       DclCommand);
            break;
         default :
               ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
      }
   }

   if (MappedScriptAs &&
       !DclPersonaServicesAvailable)
   {
      Accounting.RequestForbiddenCount++;
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_GENERAL_DISABLED), FI_LI);
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   status = DclAllocateTask (rqptr, TaskType,
                             ScriptAsPtr, BasePriority,
                             ScriptName, RteFileName);
   if (VMSnok (status))
   {
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   /* get a local pointer to the newly allocated DCL task structure */
   tkptr = rqptr->DclTaskPtr;

   tkptr->NextTaskFunction = NextTaskFunction;
   memcpy (&tkptr->LastUsedBinaryTime, &rqptr->rqTime.Vms64bit, 8);
   tkptr->WatchItem = rqptr->WatchItem;

   switch (tkptr->TaskType)
   {
      case DCL_TASK_TYPE_CGI_SCRIPT :

         if (CalloutFunction == NULL)
            tkptr->CalloutFunction = &DclCalloutDefault;
         else
            tkptr->CalloutFunction = CalloutFunction;

         strcpy (tkptr->ScriptName, ScriptName);
         strcpy (tkptr->ScriptFileName, CgiScriptFileName);
         tkptr->DclCommand[0] = tkptr->RteFileName[0] = '\0';

         /* reset CGI output processing */
         CgiOutput (rqptr, NULL, 0);

         if (!rqptr->AccountingDone)
         {
            rqptr->AccountingDone = true;
            Accounting.DoScriptCount++;
         }

         break;

      case DCL_TASK_TYPE_CGIPLUS_SCRIPT :

         if (CalloutFunction == NULL)
            tkptr->CalloutFunction = &DclCalloutDefault;
         else
            tkptr->CalloutFunction = CalloutFunction;

         /* reset CGI output processing */
         CgiOutput (rqptr, NULL, 0);

         if (!tkptr->ScriptName[0])
         {
            /* no need to reset these for established CGIplus scripts! */
            strcpy (tkptr->ScriptName, ScriptName);
            strcpy (tkptr->ScriptFileName, CgiPlusScriptFileName);
            tkptr->DclCommand[0] = tkptr->RteFileName[0] = '\0';

            if (!rqptr->AccountingDone)
            {
               rqptr->AccountingDone = true;
               Accounting.DoCgiPlusScriptCount++;
               if (tkptr->CgiPlusUsageCount > 1)
                  Accounting.DclCgiPlusReusedCount++;
            }
         }

         break;

      case DCL_TASK_TYPE_RTE_SCRIPT :

         if (CalloutFunction == NULL)
            tkptr->CalloutFunction = &DclCalloutDefault;
         else
            tkptr->CalloutFunction = CalloutFunction;

         /* reset CGI output processing */
         CgiOutput (rqptr, NULL, 0);

         strcpy (tkptr->ScriptName, ScriptName);
         strcpy (tkptr->ScriptFileName, CgiScriptFileName);
         strcpy (tkptr->RteFileName, RteFileName);
         tkptr->DclCommand[0] = '\0';

         if (!rqptr->AccountingDone)
         {
            rqptr->AccountingDone = true;
            Accounting.DoCgiPlusScriptCount++;
            if (tkptr->CgiPlusUsageCount > 1)
               Accounting.DclCgiPlusReusedCount++;
            Accounting.DoRteScriptCount++;
            if (tkptr->CgiPlusUsageCount > 1)
               Accounting.DclRteReusedCount++;
         }

         break;

      case DCL_TASK_TYPE_CLI :

         tkptr->CalloutFunction = NULL;
         strzcpy (tkptr->DclCommand, DclCommand, sizeof(tkptr->DclCommand));
         tkptr->RteFileName[0] =
            tkptr->ScriptName[0] =
            tkptr->ScriptFileName[0] = '\0';

         /* reset CGI output processing */
         CgiOutput (rqptr, NULL, 0);

         if (!rqptr->AccountingDone)
         {
            rqptr->AccountingDone = true;
            Accounting.DoDclCommandCount++;
         }

         break;

      default :
            ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
   }

   if (rqptr->rqPathSet.ScriptNoFind &&
       tkptr->TaskType == DCL_TASK_TYPE_RTE_SCRIPT)
   {
      /* the RTE will handle all script locating, error reporting, etc. */
      rqptr->rqCgi.ScriptFileNamePtr = tkptr->ScriptFileName;
      strcpy (tkptr->SearchOds.ResFileName, tkptr->ScriptFileName);
   }
   else
   if (tkptr->TaskType == DCL_TASK_TYPE_CGI_SCRIPT ||
       tkptr->TaskType == DCL_TASK_TYPE_CGIPLUS_SCRIPT ||
       tkptr->TaskType == DCL_TASK_TYPE_RTE_SCRIPT)
   {
      if (!tkptr->SearchOds.ResFileName[0])
      {
         if (DclUseZombies) DclSearchScriptNameCache (tkptr, rqptr);

         /* if not found in the name cache then look in the file system! */
         if (!tkptr->SearchOds.ResFileName[0] ||
             tkptr->ScriptRunTimePtr == NULL)
         {
            /* script is being requested, first look for the script file */
            tkptr->FindScriptState = DCL_FIND_SCRIPT_BEGIN;
            DclFindScript (tkptr);
            return;
         }
      }
   }
  
   /* must be an established CGIplus script or DCL command (from SSI module) */
   DclBeginScript (tkptr);
}

/*****************************************************************************/
/*
Allocate a DCL task structure to the request. All task structures are linked
together in a single list, function and state indicated by the various flags
and counters associated with each.

If a CGIplus task script is to be executed then check for an already
established, idle CGIplus task structure executing that particular script. If
none found, or CGIplus script not required, and zombies in use
(persistant-script processes) then look through the list for an idle zombie
script process. If no zombie available (or not enabled) then check if we have
reached the script process creation hard-limit. If not reached look through the
list for an existing but no-script process-executing DCL task structure. If
none found create an additional DCL task structure and add it to the list.

Initialize the task structure (no matter from which scan it originated) and if
necessary create a script process for it. (An obvious improvement to processing
would be to have multiple lists, but that will have to wait for another time
:^) If an error is encountered an error message is generated and the error
status returned. It is up to the calling routine to abort the processing.
*/

int DclAllocateTask
(
struct RequestStruct *rqptr,
int TaskType,
char* ScriptAsPtr,
int BasePriority,
char* ScriptName,
char* RteFileName
)
{
   boolean  WatchThisOne;
   int  status;
   struct DclTaskStruct  *tkptr;
   struct ListEntryStruct  *leptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "DclAllocateTask() %d |%s|%s|\n",
               TaskType, ScriptName, RteFileName);

   tkptr = NULL;

   if (rqptr->WatchItem && (WatchEnabled & WATCH_DCL))
      WatchThisOne = true;
   else
      WatchThisOne = false;

   if (TaskType == DCL_TASK_TYPE_CGIPLUS_SCRIPT)
   {
      /******************************************************/
      /* look for an unused instance of this CGIplus script */
      /******************************************************/

      for (leptr = DclTaskList.HeadPtr; leptr != NULL; leptr = leptr->NextPtr)
      {
         tkptr = (struct DclTaskStruct*)leptr;

         if (Debug) DclTaskItemDebug (leptr, tkptr);
 
         if (!tkptr->ScriptProcessPid ||
             tkptr->TaskType != DCL_TASK_TYPE_CGIPLUS_SCRIPT ||
             tkptr->QueuedSysCommand > tkptr->QueuedSysCommandAllowed ||
             tkptr->QueuedSysOutput ||
             tkptr->QueuedCgiPlusIn ||
             tkptr->QueuedHttpInput ||
             tkptr->QueuedClientRead ||
             tkptr->RequestPtr ||
             tkptr->FindScript ||
             tkptr->MarkedForDelete ||
             !strsame (ScriptName, tkptr->ScriptName, -1) ||
             (DclScriptDetachProcess &&
              !strsame (ScriptAsPtr, tkptr->CrePrcUserName, -1)))
         {
            tkptr = NULL;
            continue;
         }

         break;
      }

      if (Debug) fprintf (stdout, "CGIplus tkptr: %d\n", tkptr);

      if (tkptr != NULL && WatchThisOne)
         WatchThis (rqptr, FI_LI, WATCH_DCL,
                    "CGIPLUS idle pid !8XL!%%", tkptr->ScriptProcessPid,
                    tkptr->CrePrcUserName[0] ? " of !AZ" : "",
                    tkptr->CrePrcUserName);
   }

   if (TaskType == DCL_TASK_TYPE_RTE_SCRIPT)
   {
      /************************************************/
      /* look for an unused instance of this run-time */
      /************************************************/

      for (leptr = DclTaskList.HeadPtr; leptr != NULL; leptr = leptr->NextPtr)
      {
         tkptr = (struct DclTaskStruct*)leptr;

         if (Debug) DclTaskItemDebug (leptr, tkptr);
 
         if (!tkptr->ScriptProcessPid ||
             tkptr->TaskType != DCL_TASK_TYPE_RTE_SCRIPT ||
             tkptr->QueuedSysCommand > tkptr->QueuedSysCommandAllowed ||
             tkptr->QueuedSysOutput ||
             tkptr->QueuedCgiPlusIn ||
             tkptr->QueuedHttpInput ||
             tkptr->QueuedClientRead ||
             tkptr->RequestPtr ||
             tkptr->FindScript ||
             tkptr->MarkedForDelete ||
             !strsame (RteFileName, tkptr->RteFileName, -1) ||
             (DclScriptDetachProcess &&
              !strsame (ScriptAsPtr, tkptr->CrePrcUserName, -1)))
         {
            tkptr = NULL;
            continue;
         }

         /* ensure the previous script information is not carried over */
         tkptr->ScriptName[0] =
            tkptr->ScriptFileName[0] =
            tkptr->SearchOds.ResFileName[0] = '\0';

         break;
      }

      if (Debug) fprintf (stdout, "CGIplus tkptr: %d\n", tkptr);

      if (tkptr != NULL && WatchThisOne)
         WatchThis (rqptr, FI_LI, WATCH_DCL,
                    "RTE idle pid !8XL!%%", tkptr->ScriptProcessPid,
                    tkptr->CrePrcUserName[0] ? " of !AZ" : "",
                    tkptr->CrePrcUserName);
   }

   if (tkptr == NULL && DclUseZombies)
   {
      /************************/
      /* look for idle zombie */
      /************************/

      for (leptr = DclTaskList.HeadPtr; leptr != NULL; leptr = leptr->NextPtr)
      {
         tkptr = (struct DclTaskStruct*)leptr;

         if (Debug) DclTaskItemDebug (leptr, tkptr);

         if (!tkptr->ScriptProcessPid ||
             tkptr->TaskType == DCL_TASK_TYPE_CGIPLUS_SCRIPT ||
             tkptr->TaskType == DCL_TASK_TYPE_RTE_SCRIPT ||
             tkptr->QueuedSysCommand ||
             tkptr->QueuedSysOutput ||
             tkptr->QueuedCgiPlusIn ||
             tkptr->QueuedHttpInput ||
             tkptr->QueuedClientRead ||
             tkptr->FindScript ||
             tkptr->MarkedForDelete ||
             tkptr->RequestPtr != NULL ||
             (DclScriptDetachProcess &&
              !strsame (ScriptAsPtr, tkptr->CrePrcUserName, -1)))
         {
            tkptr = NULL;
            continue;
         }

         tkptr->DclCommand[0] =
            tkptr->RteFileName[0] =
            tkptr->ScriptName[0] =
            tkptr->ScriptFileName[0] =
            tkptr->SearchOds.ResFileName[0] = '\0';

         break;
      }

      if (Debug) fprintf (stdout, "idle zombie tkptr: %d\n", tkptr);

      if (tkptr != NULL && WatchThisOne)
         WatchThis (rqptr, FI_LI, WATCH_DCL,
                    "ZOMBIE idle pid !8XL!%%", tkptr->ScriptProcessPid,
                    tkptr->CrePrcUserName[0] ? " of !AZ" : "",
                    tkptr->CrePrcUserName);
   }

   if (tkptr == NULL && DclScriptProcessCount >= DclScriptProcessHardLimit)
   {
      if (WatchThisOne)
         WatchThis (rqptr, FI_LI, WATCH_DCL,
                    "SCRIPT-PROCESS hard-limit !UL", DclScriptProcessCount);

      /* let's see if we can do something about it! */
      DclScriptProcessPurge ();

      DclHitHardLimitCount++;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_SCRIPT_HARD_LIMIT), FI_LI);
      return (STS$K_ERROR);
   }

   if (tkptr == NULL)
   {
      /********************************/
      /* look for free task structure */
      /********************************/

      for (leptr = DclTaskList.HeadPtr; leptr != NULL; leptr = leptr->NextPtr)
      {
         tkptr = (struct DclTaskStruct*)leptr;

         if (Debug) DclTaskItemDebug (leptr, tkptr);

         if (tkptr->ScriptProcessPid ||
             tkptr->QueuedSysCommand ||
             tkptr->QueuedSysOutput ||
             tkptr->QueuedCgiPlusIn ||
             tkptr->QueuedHttpInput ||
             tkptr->QueuedClientRead ||
             tkptr->FindScript ||
             tkptr->MarkedForDelete ||
             tkptr->RequestPtr != NULL)
         {
            tkptr = NULL;
            continue;
         }

         tkptr->CrePrcUserName[0] =
            tkptr->DclCommand[0] =
            tkptr->RteFileName[0] =
            tkptr->ScriptName[0] =
            tkptr->ScriptFileName[0] =
            tkptr->SearchOds.ResFileName[0] = '\0';
         break;
      }

      if (Debug) fprintf (stdout, "free tkptr: %d\n", tkptr);
   }

   if (tkptr == NULL)
   {
      /* if we're getting short of script processes then start purging */
      if (DclScriptProcessCount >= DclScriptProcessSoftLimit)
      {
         if (WatchThisOne)
            WatchThis (rqptr, FI_LI, WATCH_DCL,
                       "SCRIPT-PROCESS soft-limit purge !UL",
                       DclScriptProcessCount);

         DclScriptProcessPurge ();
      }
   }

   if (tkptr == NULL)
   {
      /*********************/
      /* create a new task */
      /*********************/

      tkptr = VmGet (sizeof(struct DclTaskStruct));
      if (Debug) fprintf (stdout, "tkptr: %d\n", tkptr);

      /*
         Allocate memory in the DCL task for SYS$OUTPUT buffer.
         Allow two bytes for carriage control and terminating null.
      */
      tkptr->SysOutputPtr = VmGet (DclSysOutputSize+3);
      tkptr->SysOutputSize = DclSysOutputSize;

      if (VMSnok (status = DclCreateMailboxes (tkptr)))
      {
         VmFree (tkptr->SysOutputPtr, FI_LI);
         VmFree (tkptr, FI_LI);
         rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_SCRIPT_IPC);
         ErrorVmsStatus (rqptr, status, FI_LI);
         return (status);
      }

      ListAddTail (&DclTaskList, tkptr);
   }

   /*******************/
   /* initialize task */
   /*******************/

   /* associate the DCL task and the request */
   rqptr->DclTaskPtr = tkptr;
   tkptr->RequestPtr = rqptr;          

   tkptr->TaskType = TaskType;
   tkptr->TotalUsageCount++;
   tkptr->MarkedForDelete = false;
   tkptr->SysOutputEndOfFileCount = 0;

   switch (TaskType)
   {
      case DCL_TASK_TYPE_CGI_SCRIPT :

         if (Debug) fprintf (stdout, "CGI script\n");
         rqptr->rqCgi.IsCliDcl =
            tkptr->ScriptProcessActivated =
            tkptr->ScriptProcessResponded = false;
         tkptr->CgiPlusUsageCount =
            tkptr->CgiBelLength =
            tkptr->CgiEofLength =
            tkptr->CgiEotLength =
            tkptr->CgiEscLength = 0;
         tkptr->CgiBel[0] =
            tkptr->CgiEof[0] =
            tkptr->CgiEot[0] =
            tkptr->CgiEsc[0] = '\0';

         /* limited life in the twilight zone */
         if (DclUseZombies && Config.cfScript.ZombieLifeTime)
         {
            /* plus one allows at least that period */
            tkptr->LifeTimeCount = Config.cfScript.ZombieLifeTime+1;
            DclSupervisor (false);
         }

         if (DclUseZombies)
         {
            /* always generate new strings for standard CGI scripts */
            CgiSequenceBel (tkptr->CgiBel, &tkptr->CgiBelLength);
            CgiSequenceEof (tkptr->CgiEof, &tkptr->CgiEofLength);
            CgiSequenceEot (tkptr->CgiEot, &tkptr->CgiEotLength);
            CgiSequenceEsc (tkptr->CgiEsc, &tkptr->CgiEscLength);

            /* note: CgiBel is for DCL module internal use only */
            rqptr->rqCgi.EofPtr = tkptr->CgiEof;
            rqptr->rqCgi.EofLength = tkptr->CgiEofLength;
            rqptr->rqCgi.EotPtr = tkptr->CgiEot;
            rqptr->rqCgi.EotLength = tkptr->CgiEotLength;
            rqptr->rqCgi.EscPtr = tkptr->CgiEsc;
            rqptr->rqCgi.EscLength = tkptr->CgiEscLength;
         }

         break;

      case DCL_TASK_TYPE_CGIPLUS_SCRIPT :
      case DCL_TASK_TYPE_RTE_SCRIPT :

         rqptr->rqCgi.IsCliDcl =
            tkptr->ScriptProcessActivated =
            tkptr->ScriptProcessResponded = false;
         tkptr->ZombieCount = 0;
         tkptr->CgiPlusUsageCount++;

         /* give it three-score years and ten if life-time is specified */
         if (Config.cfScript.CgiPlusLifeTime)
         {
            /* plus one allows at least that period */
            tkptr->LifeTimeCount = Config.cfScript.CgiPlusLifeTime+1;
            DclSupervisor (false);
         }

         /* CGIplus MUST retain original EOF/EOT/ESC until process dies */
         if (!tkptr->CgiBelLength)
            CgiSequenceBel (tkptr->CgiBel, &tkptr->CgiBelLength);
         if (!tkptr->CgiEofLength)
            CgiSequenceEof (tkptr->CgiEof, &tkptr->CgiEofLength);
         if (!tkptr->CgiEotLength)
            CgiSequenceEot (tkptr->CgiEot, &tkptr->CgiEotLength);
         if (!tkptr->CgiEscLength)
            CgiSequenceEsc (tkptr->CgiEsc, &tkptr->CgiEscLength);

         /* note: CgiBel is for DCL module internal use only */
         rqptr->rqCgi.EofPtr = tkptr->CgiEof;
         rqptr->rqCgi.EofLength = tkptr->CgiEofLength;
         rqptr->rqCgi.EotPtr = tkptr->CgiEot;
         rqptr->rqCgi.EotLength = tkptr->CgiEotLength;
         rqptr->rqCgi.EscPtr = tkptr->CgiEsc;
         rqptr->rqCgi.EscLength = tkptr->CgiEscLength;

         break;

      case DCL_TASK_TYPE_CLI :

         if (Debug) fprintf (stdout, "DCL command\n");
         rqptr->rqCgi.IsCliDcl = true;
         tkptr->CgiPlusUsageCount =
            tkptr->CgiEofLength =
            tkptr->CgiEotLength =
            tkptr->CgiEscLength = 0;
         tkptr->CgiEof[0] =
            tkptr->CgiEot[0] =
            tkptr->CgiEsc[0] = '\0';
         CgiSequenceBel (tkptr->CgiBel, &tkptr->CgiBelLength);

         /* limited life in the twilight zone */
         if (DclUseZombies && Config.cfScript.ZombieLifeTime)
         {
            /* plus one allows at least that period */
            tkptr->LifeTimeCount = Config.cfScript.ZombieLifeTime+1;
            DclSupervisor (false);
         }

         if (DclUseZombies)
         {
            /* always generate a new EOF string for DCL commands */
            CgiSequenceEof (tkptr->CgiEof, &tkptr->CgiEofLength);
            rqptr->rqCgi.EofPtr = tkptr->CgiEof;
            rqptr->rqCgi.EofLength = tkptr->CgiEofLength;
         }

         break;

      default :
            ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
   }

   if (tkptr->ScriptProcessPid)
   {
      /******************/
      /* process exists */
      /******************/

      return (SS$_NORMAL);
   }

   /******************/
   /* create process */
   /******************/

   status = DclCreateScriptProcess (tkptr, ScriptAsPtr, BasePriority);
   if (VMSok (status))
   {
      tkptr->ZombieCount = 0;
      DclScriptProcessCount++;
      return (status);
   }
   else
   {
      /* disassociate the DCL task and request structures */
      rqptr->DclTaskPtr = tkptr->RequestPtr = NULL;
      tkptr->WatchItem = 0;
      return (status);
   }
}

/*****************************************************************************/
/*
Search the script name cache using a task structure to get information about
the script's environment.
*/ 

DclSearchScriptNameCache
(
struct DclTaskStruct *tkptr,
struct RequestStruct *rqptr
)
{
   struct DclScriptNameCacheStruct  *captr;
   struct ListEntryStruct  *leptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "DclSearchScriptNameCache() |%s|%s|\n",
               tkptr->ScriptFileName, tkptr->RteFileName);

   for (leptr = DclScriptNameCacheList.HeadPtr;
        leptr != NULL;
        leptr = leptr->NextPtr)
   {
      captr = (struct DclScriptNameCacheStruct*)leptr;

      if (!captr->ResFileName[0]) continue;
      if (!strsame (tkptr->ScriptFileName, captr->ScriptFileName, -1)) continue;

      if (!rqptr->PragmaNoCache)
      {
         /* found it */
         if (rqptr->WatchItem && (WatchEnabled & WATCH_DCL))
            WatchThis (rqptr, FI_LI, WATCH_DCL,
                       "SCRIPT name cache !UL hit!%s !AZ as !AZ",
                       captr->HitCount+1, tkptr->ScriptFileName, 
                       captr->ResFileName);

         /* copy the expanded (searched for) file name to the task */
         strcpy (tkptr->SearchOds.ResFileName, captr->ResFileName);
         rqptr->rqCgi.ScriptFileNamePtr = tkptr->SearchOds.ResFileName;
         tkptr->ScriptRunTimePtr = captr->ScriptRunTimePtr;
         captr->HitCount++;
         memcpy (&captr->LastBinaryTime, &rqptr->rqTime.Vms64bit, 8);

         return;
      }

      /* "reload" is used to purge the script name cache entry */
      captr->ResFileName[0] = captr->RteFileName[0] = '\0';
      captr->ScriptRunTimePtr = NULL;
      return;
   }

   if (rqptr->WatchItem && (WatchEnabled & WATCH_DCL))
      WatchThis (rqptr, FI_LI, WATCH_DCL,
                 "SCRIPT name cache !AZ not found", tkptr->ScriptFileName); 
}

/*****************************************************************************/
/*
Add the name details of a script to the cache.  First check that no other
request has provided this same entry while this request was finding the script
details.  Then update an empty entry if it can be found in the list, or create
a new entry and add it to the list.
*/ 

DclUpdateScriptNameCache (struct DclTaskStruct *tkptr)

{
   struct DclScriptNameCacheStruct  *captr;
   struct ListEntryStruct  *leptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "DclUpdateScriptNameCache() |%s|%s|\n",
               tkptr->ScriptFileName, tkptr->SearchOds.ResFileName);

   /* check that no one has beaten us to it */
   for (leptr = DclScriptNameCacheList.HeadPtr;
        leptr != NULL;
        leptr = leptr->NextPtr)
   {
      captr = (struct DclScriptNameCacheStruct*)leptr;
      if (strsame (tkptr->ScriptFileName, captr->ScriptFileName, -1) &&
          captr->ResFileName[0]) return;
   }

   /* now look for an empty entry */
   for (leptr = DclScriptNameCacheList.HeadPtr;
        leptr != NULL;
        leptr = leptr->NextPtr)
   {
      captr = (struct DclScriptNameCacheStruct*)leptr;
      if (!captr->ResFileName[0]) break;
   }

   if (leptr == NULL)
   {
      /* didn't find an instance of the script create a new entry */
      captr = VmGet (sizeof(struct DclScriptNameCacheStruct));
      if (Debug) fprintf (stdout, "captr: %d\n", captr);
      ListAddTail (&DclScriptNameCacheList, captr);
   }

   /* cache the script name information */
   strcpy (captr->ScriptFileName, tkptr->ScriptFileName);
   strcpy (captr->ResFileName, tkptr->SearchOds.ResFileName);
   if (tkptr->RteFileName[0]) strcpy (captr->RteFileName, tkptr->RteFileName);
   captr->ScriptRunTimePtr = tkptr->ScriptRunTimePtr;
   captr->HitCount = 0;
   memcpy (&captr->LastBinaryTime, tkptr->RequestPtr->rqTime.Vms64bit, 8);

   if (tkptr->RequestPtr->WatchItem && (WatchEnabled & WATCH_DCL))
      WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                 "SCRIPT name cache update !AZ as !AZ",
                 captr->ScriptFileName, captr->ResFileName);
}

/*****************************************************************************/
/*
Set all expanded file name entries in the script name cache to empty.  This
function is called when the DCLSupervisor() determines there are no more
zombies or CGIplus scripts active, and also when script processes are purged.
*/ 

DclPurgeScriptNameCache ()

{
   register struct DclScriptNameCacheStruct  *captr;
   register struct ListEntryStruct  *leptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DclPurgeScriptNameCache()\n");

   DclPurgeScriptNameCacheCount++;

   for (leptr = DclScriptNameCacheList.HeadPtr;
        leptr != NULL;
        leptr = leptr->NextPtr)
   {
      captr = (struct DclScriptNameCacheStruct*)leptr;
      captr->ResFileName[0] = '\0';
      captr->ScriptRunTimePtr = NULL;
   }
}

/*****************************************************************************/
/*
Perform an asynchronous search for the script file specified by
'tkptr->ScriptFileName'.  When found return the actual script file in
'tkptr->SearchOds.ResFileName' and call DclBeginScript().  If not found set to
empty and conclude the task.  The search is performed first by checking for a
file with the file type supplied with the script specification (usually not),
then by defaulting to ".COM", then ".EXE", and finally to any configured
runtime file types, in that order.

The file search uses a DCL task structure but no script process I/O is actually
underway. As the search is AST-driven it is possible for a cancelling client
to disconnect from the task structure via DclConcludeTask() while the search
is in progress. Each find-script-file function checks for the request pointer
and aborts the search if no longer present. The 'tkptr->FindScript' flag
indicates the structure is in use for this purpose and so will not be
reallocated until reset as the search is finally aborted.
*/ 

DclFindScript (struct DclTaskStruct *tkptr)

{
   register struct RequestStruct  *rqptr;

   int  status,
        idx;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "DclFindScript() %d |%s|%s|\n",
               tkptr->FindScriptState,
               tkptr->ScriptFileName,
               tkptr->RteFileName);

   if ((rqptr = tkptr->RequestPtr) == NULL)
   {
      /* request thread has disconnected during file search */
      DclFindScriptEnd (tkptr, true);
      return;
   }

   switch (tkptr->FindScriptState)
   {
      case DCL_FIND_SCRIPT_BEGIN :

         tkptr->FindScript = true;
         tkptr->FindScriptFileNamePtr = tkptr->ScriptFileName;

         /* first default to DCL procedure (overridden if file type supplied) */
         OdsParse (&tkptr->SearchOds,
                   tkptr->FindScriptFileNamePtr, 0, ".COM;", 5,
                   0, &DclFindScriptParseAst, tkptr);

         /* if not found then we'll be looking for executables */
         tkptr->FindScriptState = DCL_FIND_SCRIPT_EXE;

         return;

      case DCL_FIND_SCRIPT_EXE :

         /* move on to looking for executables */
         OdsParse (&tkptr->SearchOds,
                   tkptr->FindScriptFileNamePtr, 0, ".EXE;", 5,
                   0, &DclFindScriptParseAst, tkptr);

         /* if not found then we'll be looking for runtime-defined */
         tkptr->FindScriptRunTimeIdx = 0;
         tkptr->FindScriptState = DCL_FIND_SCRIPT_RUNTIME;

         return;

      case DCL_FIND_SCRIPT_RUNTIME :

         /* looking through any list of user-defined script file types */
         idx = tkptr->FindScriptRunTimeIdx++;
         if (idx >= Config.cfScript.RunTimeCount)
         {
            /********************/
            /* script not found */
            /********************/

            /* indicate the script was not found */
            tkptr->SearchOds.ResFileName[0] = '\0';

            if (tkptr->CalloutFunction == NULL ||
                (void*)tkptr->CalloutFunction ==
                (void*)&DclCalloutDefault)
            {
               /* standard CGI/CGIplus script */
               rqptr->rqResponse.HttpStatus = 404;
               ErrorGeneral (rqptr, MsgFor(rqptr,MSG_SCRIPT_NOT_FOUND), FI_LI);
            }
            else
            {
               /* not a standard CGIplus script, an agent task */
               rqptr->rqResponse.HttpStatus = 500;
               ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_AGENT_NOT_FOUND), FI_LI);
            }

            DclFindScriptEnd (tkptr, true);

            return;
         }

         if (Debug)
            fprintf (stdout, "[%d]|%s|\n",
                     idx, Config.cfScript.RunTime[idx].String);

         OdsParse (&tkptr->SearchOds,
                   tkptr->FindScriptFileNamePtr, 0,
                   Config.cfScript.RunTime[idx].String,
                   Config.cfScript.RunTime[idx].FileTypeLength,
                   0, &DclFindScriptParseAst, tkptr);

         return;

      default :
            ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
   }
}

/*****************************************************************************/
/*
AST called from DclFindScript() when asynchronous parse completes.  Check for
error status, then perform an asynchronous search with AST to
DclFindScriptSearchAst()
*/

DclFindScriptParseAst (struct FAB *FabPtr)

{
   register struct RequestStruct  *rqptr;
   register struct DclTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
         "DclFindScriptParseAst() sts: %%X%08.08X stv: %%X%08.08X\n",
         FabPtr->fab$l_sts, FabPtr->fab$l_stv);

   tkptr = FabPtr->fab$l_ctx;

   if ((rqptr = tkptr->RequestPtr) == NULL)
   {
      /* request thread has disconnected during file search */
      DclFindScriptEnd (tkptr, true);
      return;
   }

   if (VMSnok (status = FabPtr->fab$l_sts))
   {
      rqptr->rqResponse.ErrorTextPtr = tkptr->ScriptName;
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->ScriptFileName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      DclFindScriptEnd (tkptr, true);
      return;
   }

   if (tkptr->SearchOds.Nam_fnb & NAM$M_WILDCARD)
   {
      rqptr->rqResponse.HttpStatus = 403;
      rqptr->rqResponse.ErrorTextPtr = tkptr->ScriptName;
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->ScriptFileName;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_GENERAL_NO_WILDCARD), FI_LI);
      DclFindScriptEnd (tkptr, true);
      return;
   }

   if (Debug)
   {
      tkptr->SearchOds.NamVersionPtr[0] = '\0';
      fprintf (stdout, "|%s|\n", tkptr->SearchOds.ResFileName);
      tkptr->SearchOds.NamVersionPtr[0] = ';';
   }

   OdsSearch (&tkptr->SearchOds, &DclFindScriptSearchAst, tkptr);
}

/*****************************************************************************/
/*
AST called from DclFindScriptParseAst() when asynchronous search completes.
Check for a file-not-found status, if so then call DclFindScript() to search
for the next possibility.  Check for an error status.  If the file has been
found determine the runtime environment and initiate the script process
execution. 
*/

DclFindScriptSearchAst (struct FAB *FabPtr)

{
   register struct RequestStruct  *rqptr;
   register struct DclTaskStruct  *tkptr;

   register char  *cptr, *sptr, *zptr;
   int  status, idx;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
         "DclFindScriptSearchAst() sts: %%X%08.08X stv: %%X%08.08X\n",
         FabPtr->fab$l_sts, FabPtr->fab$l_stv);

   tkptr = FabPtr->fab$l_ctx;

   if ((rqptr = tkptr->RequestPtr) == NULL)
   {
      /* request thread has disconnected during file search */
      DclFindScriptEnd (tkptr, true);
      return;
   }

   if (VMSnok (status = FabPtr->fab$l_sts))
   {
      if (rqptr->WatchItem && (WatchEnabled & WATCH_DCL))
      {
         tkptr->SearchOds.NamVersionPtr[0] = '\0';
         WatchThis (rqptr, FI_LI, WATCH_DCL,
                    "SEARCH !AZ %X!8XL %!%M",
                    tkptr->SearchOds.NamDevicePtr, status, status);
         tkptr->SearchOds.NamVersionPtr[0] = ';';
      }

      if (status == RMS$_FNF)
      {
         /* not found, look for another */
         DclFindScript (tkptr);
         return;
      }

      /* some other error, report it and finish up */
      rqptr->rqResponse.ErrorTextPtr = tkptr->ScriptName;
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->ScriptFileName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      DclFindScriptEnd (tkptr, true);
      return;
   }

   if (rqptr->WatchItem && (WatchEnabled & WATCH_DCL))
   {
      tkptr->SearchOds.NamVersionPtr[0] = '\0';
      WatchThis (rqptr, FI_LI, WATCH_DCL,
                 "SEARCH found !AZ", tkptr->SearchOds.NamDevicePtr);
      tkptr->SearchOds.NamVersionPtr[0] = ';';
   }

   /*************/
   /* found it! */
   /*************/

   if (!memcmp (tkptr->SearchOds.NamTypePtr, ".COM;", 5))
      tkptr->ScriptRunTimePtr = DCL_RUNTIME_COM;
   else
   if (!memcmp (tkptr->SearchOds.NamTypePtr, ".EXE;", 5))
      tkptr->ScriptRunTimePtr = DCL_RUNTIME_EXE;
   else
   {
      /* look through the list of user-definable script file types */
      for (idx = 0; idx < Config.cfScript.RunTimeCount; idx++)
      {
         if (!memcmp (tkptr->SearchOds.NamTypePtr,
                      Config.cfScript.RunTime[idx].String,
                      Config.cfScript.RunTime[idx].FileTypeLength))
            break;
      }
      if (idx < Config.cfScript.RunTimeCount)
      {
         /* found the file type (file extension) */
         cptr = Config.cfScript.RunTime[idx].String;
         while (*cptr && *cptr != ' ') cptr++;
         if (*cptr) cptr++;
         tkptr->ScriptRunTimePtr = cptr;
      }
      else
      if (tkptr->TaskType == DCL_TASK_TYPE_RTE_SCRIPT)
         tkptr->ScriptRunTimePtr = NULL;
      else
      {
         /********************************************/
         /* don't know how to execute this file type */
         /********************************************/

         rqptr->rqResponse.HttpStatus = 500;
         tkptr->SearchOds.NamVersionPtr[0] = '\0';
         ErrorGeneral (rqptr,
"Execution of &nbsp;<TT>!AZ</TT>&nbsp; script types not configured.",
                       tkptr->SearchOds.NamTypePtr, FI_LI);
         DclFindScriptEnd (tkptr, true);
         return;
      }
   }

   /**********************/
   /* execute the script */
   /**********************/

   /* terminate the expanded CGI file name */
   tkptr->SearchOds.NamVersionPtr[0] = '\0';

   DclFindScriptEnd (tkptr, false);
}

/*****************************************************************************/
/*
The parse structures only really need to be explicitly released if the script
is actually found, otherwise they are always implicitly released on the
sys$search() file-not-found! Here we'll do it all the time as we are dealing
with possible search abort as well as general search conclusion. When doing so
use scratch expanded file name space so as not to overwrite the CGI file name
if the script file was found.
*/

DclFindScriptEnd
(
struct DclTaskStruct *tkptr,
boolean FileNotFound
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DclFindScriptEnd()\n");

   tkptr->FindScript = false;

   /* ensure parse internal data structures are released */
   if (tkptr->SearchOds.ParseInUse) OdsParseRelease (&tkptr->SearchOds);

   if (FileNotFound)
   {
      DclConcludeTask (tkptr, false); 
      return;
   }

   /* update the cache */
   DclUpdateScriptNameCache (tkptr);

   /* NOW update the script file name with the one actually resolved */
   strcpy (tkptr->ScriptFileName, tkptr->SearchOds.ResFileName);
   if (Debug) fprintf (stdout, "|%s|\n", tkptr->ScriptFileName);
   tkptr->RequestPtr->rqCgi.ScriptFileNamePtr = tkptr->ScriptFileName;

   DclBeginScript (tkptr);
}

/*****************************************************************************/
/*
Abort current request script processing, freeing the request and DCL task from
each other, then restart DCL processing appropriately.  Is used to restart
processing after CGIplus script failed to start (see "April 1998 Note:" above)
or when a run-time configuration entry indicates either CGIplus or RTE should
be used to handle scripting the file type.  When restarting for RTE two sources
of the RTE executable must be considered.  If from the [DclScriptRunTime]
configuration structure then 'ScriptRunTimePtr' points to a file name,
otherwise 'ScriptRunTimePtr' points to either "$" or "@" to indicate how the
file should be handled.  If the seconad character is a null then it's the
latter and the 'ResFileName' should be used.
*/ 

DclRestartScript (struct DclTaskStruct *tkptr)

{
   int  TaskType;
   char  *ScriptRunTimePtr;
   char  DclCommand [DCL_COMMAND_BUFFER_SIZE],
         RteFileName [ODS_MAX_FILE_NAME_LENGTH+1],
         ResFileName [ODS_MAX_FILE_NAME_LENGTH+1],
         ScriptFileName [ODS_MAX_FILE_NAME_LENGTH+1],
         ScriptName [SCRIPT_NAME_SIZE];
   void  *NextTaskFunction;
   struct RequestStruct  *rqptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DclRestartScript()\n");

   rqptr = tkptr->RequestPtr;

   if (rqptr->WatchItem && (WatchEnabled & WATCH_DCL))
      WatchThis (rqptr, FI_LI, WATCH_RESPONSE, "RESTART script !UL",
                 tkptr->RequestPtr->rqCgi.ScriptRetryCount);

   /* retrieve necessary information from the current DCL task */
   TaskType = tkptr->TaskType;
   NextTaskFunction = tkptr->NextTaskFunction;
   ScriptRunTimePtr = tkptr->ScriptRunTimePtr;
   strzcpy (ResFileName, tkptr->SearchOds.ResFileName, sizeof(ResFileName));
   strzcpy (RteFileName, tkptr->RteFileName, sizeof(RteFileName));
   strzcpy (ScriptFileName, tkptr->ScriptFileName, sizeof(ScriptFileName));
   strzcpy (ScriptName, tkptr->ScriptName, sizeof(ScriptName));
   strzcpy (DclCommand, tkptr->DclCommand, sizeof(DclCommand));

   /* disassociate the DCL task and request structures, then conclude */
   tkptr->RequestPtr->DclTaskPtr = NULL;
   tkptr->RequestPtr = tkptr->NextTaskFunction = NULL;
   tkptr->WatchItem = 0;
   DclConcludeTask (tkptr, false); 

   /* restart using a new DCL task */
   switch (TaskType)
   {
      case DCL_TASK_TYPE_CGIPLUS_SCRIPT :

         DclBegin (rqptr, NextTaskFunction, NULL, ScriptName, NULL,
                   ScriptFileName, NULL, NULL);
         return;

      case DCL_TASK_TYPE_RTE_SCRIPT :

         DclBegin (rqptr, NextTaskFunction, NULL, ScriptName, ScriptFileName,
                   NULL, RteFileName, NULL);
         return;

      case DCL_TASK_TYPE_CGI_SCRIPT :

         DclBegin (rqptr, NextTaskFunction, NULL, ScriptName, ScriptFileName,
                   NULL, NULL, NULL);
         return;

      case DCL_TASK_TYPE_CLI :

         DclBegin (rqptr, NextTaskFunction, NULL, NULL, NULL,
                   NULL, NULL, NULL);
         return;

      default :

         ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
   }
}

/*****************************************************************************/
/*
Called with an already-established CGIplus script, a DCL command, or when a
new CGIplus or CGI script file name has been searched for and found.  Begin
the I/O with the script process.
*/ 

DclBeginScript (struct DclTaskStruct *tkptr)

{
   register struct RequestStruct  *rqptr;

   int  status,
        Length;
   char  *ContentPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DclBeginScript()\n");

   if ((rqptr = tkptr->RequestPtr) == NULL)
   {
      /* request thread has disconnected during file search */
      DclConcludeTask (tkptr, false);
      return;
   }

   if (Debug)
      fprintf (stdout, "TaskType: %d DclCommand |%s|\n",
               tkptr->TaskType, tkptr->DclCommand);

   if (tkptr->TaskType == DCL_TASK_TYPE_CGI_SCRIPT ||
       tkptr->TaskType == DCL_TASK_TYPE_CGIPLUS_SCRIPT ||
       tkptr->TaskType == DCL_TASK_TYPE_RTE_SCRIPT)
   {
      /* provide request stream (HTTP$INPUT) to script process */
      if (Debug) 
         fprintf (stdout, "|%d|%d|%s|\n",
                  rqptr->rqHeader.ContentLength,
                  rqptr->rqBody.CurrentCount,
                  rqptr->rqBody.BufferPtr);

      /* initialize content information (POST, PUT, etc., only) */
      tkptr->ContentPtr = rqptr->rqBody.BufferPtr;
      tkptr->ContentLength = rqptr->rqBody.CurrentCount;

      if (Config.cfScript.FullRequest)
      {
         /* supply request header and body (pre-4.3 behaviour) */

         if (rqptr->WatchItem && (WatchEnabled & WATCH_DCL))
         {
            WatchThis (rqptr, FI_LI, WATCH_DCL,
                       "WRITE SYS$INPUT !UL bytes",
                       rqptr->rqHeader.RequestHeaderLength);
            WatchData (rqptr->rqHeader.RequestHeaderPtr,
                       rqptr->rqHeader.RequestHeaderLength);
         }

         if (VMSnok (status =
             sys$qio (0, tkptr->HttpInputChannel,
                      IO$_WRITELBLK, &tkptr->HttpInputIOsb,
                      &DclHttpInputAst, tkptr,
                      rqptr->rqHeader.RequestHeaderPtr,
                      rqptr->rqHeader.RequestHeaderLength,
                      0, 0, 0, 0)))
         {
            /* report this error via the AST */
            tkptr->HttpInputIOsb.Status = status;
            SysDclAst (&DclHttpInputAst, tkptr);
         }
      }
      else
      if (tkptr->ContentLength)
      {
         /* supply only the body of the request (standard CGI behaviour) */
         if (tkptr->ContentLength > NetReadBufferSize)
            Length = NetReadBufferSize;
         else
            Length = tkptr->ContentLength;
         ContentPtr = tkptr->ContentPtr;
         tkptr->ContentPtr += Length;
         tkptr->ContentLength -= Length;

         if (rqptr->WatchItem && (WatchEnabled & WATCH_DCL))
         {
            WatchThis (rqptr, FI_LI, WATCH_DCL,
                       "WRITE SYS$INPUT !UL bytes", Length);
            if (Length) WatchData (ContentPtr, Length);
         }

         if (VMSnok (status =
             sys$qio (0, tkptr->HttpInputChannel,
                      IO$_WRITELBLK, &tkptr->HttpInputIOsb,
                      &DclHttpInputAst, tkptr,
                      ContentPtr, Length,
                      0, 0, 0, 0)))
         {
            /* report this error via the AST */
            tkptr->HttpInputIOsb.Status = status;
            SysDclAst (&DclHttpInputAst, tkptr);
         }
      }
      else
      {
         /* the request has no body */

         if (rqptr->WatchItem && (WatchEnabled & WATCH_DCL))
            WatchThis (rqptr, FI_LI, WATCH_DCL, "WRITE HTTP$INPUT EOF");

         if (VMSnok (status =
             sys$qio (0, tkptr->HttpInputChannel,
                      IO$_WRITEOF, &tkptr->HttpInputIOsb,
                      &DclHttpInputAst, tkptr,
                      0, 0, 0, 0, 0, 0)))
         {
            /* report this error via the AST */
            tkptr->HttpInputIOsb.Status = status;
            SysDclAst (&DclHttpInputAst, tkptr);
         }
      }
      tkptr->QueuedHttpInput++;
   }

   /* queue the initial read of the script process' SYS$OUTPUT */
   DclQioSysOutput (tkptr);

   switch (tkptr->TaskType)
   {
      case DCL_TASK_TYPE_CGI_SCRIPT :

         tkptr->QueuedSysCommandAllowed = 0;
         rqptr->rqResponse.ErrorTextPtr =
            MsgFor(rqptr,MSG_SCRIPT_DCL_ENVIRONMENT);
         if (VMSnok (DclCgiScriptSysCommand (tkptr)))
         {
            DclConcludeTask (tkptr, true);
            return;
         }

         break;

      case DCL_TASK_TYPE_CGIPLUS_SCRIPT :
      case DCL_TASK_TYPE_RTE_SCRIPT :

         /* allow for the outstanding queued "STOP/ID=0" and EOF */
         tkptr->QueuedSysCommandAllowed = 2;
         if (tkptr->QueuedSysCommand < tkptr->QueuedSysCommandAllowed)
            DclCgiPlusScriptSysCommand (tkptr);

         /* here comes the CGI variable stream */
         if (VMSnok (DclCgiPlusScriptCgiPlusIn (tkptr)))
         {
            DclConcludeTask (tkptr, true);
            return;
         }

         break;

      case DCL_TASK_TYPE_CLI :

         tkptr->QueuedSysCommandAllowed = 0;
         if (VMSnok (DclCgiScriptSysCommand (tkptr)))
         {
            DclConcludeTask (tkptr, true);
            return;
         }

         break;

      default :
            ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
   }

   /* remove default error message */
   rqptr->rqResponse.ErrorTextPtr = NULL;
}

/*****************************************************************************/
/*
Delete any script (sub)processes. 
Called by the image user-mode exit handler.
*/

DclExit ()

{
   int  status,
        SetPrvStatus;
   struct DclTaskStruct  *tkptr;
   struct ListEntryStruct  *leptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DclExit()\n");

   for (leptr = DclTaskList.HeadPtr; leptr != NULL; leptr = leptr->NextPtr)
   {
      tkptr = (struct DclTaskStruct*)leptr;
      if (!tkptr->ScriptProcessPid) continue;
      if (tkptr->CrePrcUserName[0])
      {
         /* need WORLD privilege if process created under another username */
         if (VMSnok (SetPrvStatus = sys$setprv (1, &WorldMask, 0, 0)))
            ErrorExitVmsStatus (SetPrvStatus, "sys$setprv()", FI_LI);
         status = sys$delprc (&tkptr->ScriptProcessPid, 0);
         if (VMSnok (SetPrvStatus = sys$setprv (0, &WorldMask, 0, 0)))
            ErrorExitVmsStatus (SetPrvStatus, "sys$setprv()", FI_LI);
      }
      else
         status = sys$delprc (&tkptr->ScriptProcessPid, 0);
      if (VMSnok (status)) ErrorNoticed (status, "sys$delprc()", FI_LI); 
   }
}

/*****************************************************************************/
/*
The maximum number of concurrent script processes has been reached. Look
through the DCL task structure for a CGIplus script process not currently in
use. Find the least used script process and delete it.  A lifetime count of -1
indicates the script process has requested that it be immune to supervisor
purging.
*/

DclScriptProcessPurge ()

{
   int  status,
        MinUsageCount;
   struct DclTaskStruct  *mintkptr;
   struct DclTaskStruct  *tkptr;
   struct ListEntryStruct  *leptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "DclScriptProcessPurge() %d %d\n",
               DclScriptProcessCount, DclScriptProcessSoftLimit);

   DclPurgeCount++;
   MinUsageCount = 999999999;
   mintkptr = NULL;

   for (leptr = DclTaskList.HeadPtr; leptr != NULL; leptr = leptr->NextPtr)
   {
      tkptr = (struct DclTaskStruct*)leptr;

      if (Debug) DclTaskItemDebug (leptr, tkptr);

      if (!tkptr->ScriptProcessPid ||
          tkptr->TaskType != DCL_TASK_TYPE_CGIPLUS_SCRIPT ||
          tkptr->TaskType != DCL_TASK_TYPE_RTE_SCRIPT ||
          tkptr->LifeTimeCount == -1 ||
          tkptr->QueuedSysOutput ||
          tkptr->QueuedCgiPlusIn ||
          tkptr->QueuedHttpInput ||
          tkptr->QueuedClientRead ||
          tkptr->RequestPtr != NULL ||
          tkptr->FindScript ||
          tkptr->MarkedForDelete)
         continue;

      if (tkptr->CgiPlusUsageCount < MinUsageCount)
         MinUsageCount = (mintkptr = tkptr)->CgiPlusUsageCount;
   }

   if (mintkptr == NULL) return;

   mintkptr->MarkedForDelete = true;
   DclConcludeTask (mintkptr, true);
   DclSoftLimitPurgeCount++;
}

/*****************************************************************************/
/*
This function may be called at any stage to rundown or abort a DCL task,
including during the search for the script file (see note in DclFindScript()).
If there is still outstanding I/O this is cancelled as appropriate to task
rundown or abort. If no outstanding I/O then if there is an associated request
that request's next task function is called.
*/

DclConcludeTask
(
struct DclTaskStruct *tkptr,
boolean AbortTask
)
{
   int  status,
        SetPrvStatus;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "DclConcludeTask() %d %d %d %d %d %d %d %d %d %08.08X\n",
         AbortTask, tkptr, tkptr->RequestPtr, tkptr->MarkedForDelete,
         tkptr->QueuedSysCommand,
         tkptr->QueuedSysOutput, tkptr->QueuedCgiPlusIn,
         tkptr->QueuedHttpInput, tkptr->QueuedClientRead,
         tkptr->ScriptProcessPid);

   if (AbortTask)
   {
      tkptr->MarkedForDelete = true;
      tkptr->QueuedSysCommandAllowed = 0;
   }

   if (tkptr->QueuedSysCommand > tkptr->QueuedSysCommandAllowed ||
       tkptr->QueuedSysOutput ||
       tkptr->QueuedCgiPlusIn ||
       tkptr->QueuedHttpInput || 
       tkptr->QueuedClientRead)
   {
      /****************/
      /* rundown task */
      /****************/

      if (AbortTask)
      {
         /* cancel everything everywhere! */
         sys$cancel (tkptr->SysCommandChannel);
         sys$cancel (tkptr->SysOutputChannel);
         sys$cancel (tkptr->CgiPlusInChannel);
         sys$cancel (tkptr->HttpInputChannel);
         if (tkptr->QueuedClientRead && tkptr->RequestPtr != NULL)
            NetCloseSocket (tkptr->RequestPtr);
      }
      else
      {
         /* cancel any outstanding I/O on input channels */
         if (tkptr->QueuedCgiPlusIn) sys$cancel (tkptr->CgiPlusInChannel);
         if (tkptr->QueuedHttpInput) sys$cancel (tkptr->HttpInputChannel);
         if (tkptr->QueuedSysCommand > tkptr->QueuedSysCommandAllowed)
            sys$cancel (tkptr->SysCommandChannel);
         /* if reading directly from the client just close the socket */
         if (tkptr->QueuedClientRead && tkptr->RequestPtr != NULL)
            NetCloseSocket (tkptr->RequestPtr);
      }

      return;
   }

   /*********************/
   /* task has finished */
   /*********************/

   if (tkptr->ScriptName[0] && !tkptr->SearchOds.ResFileName[0])
   {
      /* search for script file was unsuccessful */
      if (tkptr->RequestPtr != NULL)
      {
         /* still has an associated request, declare the next task */
         SysDclAst (tkptr->NextTaskFunction, tkptr->RequestPtr);

         /* disassociate the DCL task and request structures */
         tkptr->RequestPtr->DclTaskPtr = NULL;
         tkptr->RequestPtr = tkptr->NextTaskFunction = NULL;
         tkptr->WatchItem = 0;
      }

      if (tkptr->TaskType == DCL_TASK_TYPE_CGIPLUS_SCRIPT ||
          tkptr->TaskType == DCL_TASK_TYPE_RTE_SCRIPT)
         tkptr->MarkedForDelete = true;
   }
   else
   if (tkptr->RequestPtr != NULL)
   {
      if (!tkptr->ScriptProcessActivated &&
          tkptr->RequestPtr->rqCgi.ScriptRetryCount++ < DCL_MAX_SCRIPT_RETRY &&
          tkptr->RequestPtr->rqResponse.ErrorReportPtr == NULL)
      {
         /* looks like the script exited before actually starting! */
         tkptr->MarkedForDelete = true;
         DclRestartScript (tkptr);
      }
      else
      {
         if (tkptr->TaskType != DCL_TASK_TYPE_CLI &&
             (!tkptr->ScriptProcessResponded ||
              !tkptr->ScriptProcessActivated) &&
             tkptr->RequestPtr->rqResponse.ErrorReportPtr == NULL)
         {
            /* hmmm, script has not provided any output! */
            if (tkptr->RequestPtr->rqHeader.Method == HTTP_METHOD_GET)
            {
               /* blame script for general GET method failures */
               tkptr->RequestPtr->rqResponse.HttpStatus = 502;
               ErrorGeneral (tkptr->RequestPtr,
                  MsgFor(tkptr->RequestPtr,MSG_SCRIPT_RESPONSE_ERROR), FI_LI);
            }
            else
            {
               /* other methods are probably not implemented by the script */
               tkptr->RequestPtr->rqResponse.HttpStatus = 501;
               ErrorGeneral (tkptr->RequestPtr,
                  MsgFor(tkptr->RequestPtr,MSG_REQUEST_METHOD), FI_LI);
            }
         }

         /* still has an associated request, declare the next task */
         SysDclAst (tkptr->NextTaskFunction, tkptr->RequestPtr);

         /* disassociate the DCL task and request structures */
         tkptr->RequestPtr->DclTaskPtr = NULL;
         tkptr->RequestPtr = tkptr->NextTaskFunction = NULL;
         tkptr->WatchItem = 0;
      }
   }

   if (DclUseZombies ||
       tkptr->TaskType == DCL_TASK_TYPE_CGIPLUS_SCRIPT ||
       tkptr->TaskType == DCL_TASK_TYPE_RTE_SCRIPT)
   {
      /* empty any remains in sys$output! */
      DclEmptySysOutput (tkptr);
   }

   /* if marked for process deletion */
   if (tkptr->MarkedForDelete)
   {
      if (tkptr->ScriptProcessPid)
      {
         if (tkptr->CrePrcUserName[0])
         {
            /* need WORLD privilege if process created under another username */
            if (VMSnok (SetPrvStatus = sys$setprv (1, &WorldMask, 0, 0)))
               ErrorExitVmsStatus (SetPrvStatus, "sys$setprv()", FI_LI);
            status = sys$delprc (&tkptr->ScriptProcessPid, 0);
            if (VMSnok (SetPrvStatus = sys$setprv (0, &WorldMask, 0, 0)))
               ErrorExitVmsStatus (SetPrvStatus, "sys$setprv()", FI_LI);
         }
         else
            status = sys$delprc (&tkptr->ScriptProcessPid, 0);
         if (Debug) fprintf (stdout, "sys$delprc() %%X%08.08X\n", status);
         if (VMSnok (status)) ErrorNoticed (status, "sys$delprc()", FI_LI); 
      }
      else
         tkptr->MarkedForDelete = false;
   }

   if (DclUseZombies &&
       tkptr->TaskType != DCL_TASK_TYPE_CGIPLUS_SCRIPT &&
       tkptr->TaskType != DCL_TASK_TYPE_RTE_SCRIPT)
      tkptr->ZombieCount++;
}

/*****************************************************************************/
/*
If an error is encountered an error message is generated and the error status
returned.  It is up to the calling routine to abort the processing.  Queue a
writer-wait I/O to the SYS$OUTPUT channel to stall I/O until the script process
has started.
*/ 

DclCreateScriptProcess
(
struct DclTaskStruct *tkptr,
char *ScriptAsPtr,
int BasePriority
)
{
   unsigned long  CrePrcMask [2] = { PRV$M_DETACH | PRV$M_SYSPRV, 0 };
   static int  ScriptProcessNumber;
   static unsigned long  JpiAuthPriv [2],
                         PrevPrivMask [2];
   static char  ScriptProcessName [16];
   static $DESCRIPTOR (LoginOutDsc, "SYS$SYSTEM:LOGINOUT.EXE");
   static $DESCRIPTOR (ScriptProcessNameFaoDsc, "HTTPd:!UL-!UL");
   static $DESCRIPTOR (ScriptProcessNameDsc, ScriptProcessName);
   static struct
   {
      unsigned short  buf_len;
      unsigned short  item;
      unsigned char   *buf_addr;
      unsigned short  *short_ret_len;
   }
      JpiItems [] =
   {
      { sizeof(JpiAuthPriv), JPI$_AUTHPRIV, &JpiAuthPriv, 0 },
      { 0,0,0,0 }
   };

   int  status,
        Count,
        BecomeStatus,
        SetPrvStatus;
   unsigned short  Length;
   unsigned long  CrePrcFlags;
   char  *cptr, *sptr, *zptr;
   struct RequestStruct  *rqptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "DclCreateScriptProcess() |%s| %d\n",
               ScriptAsPtr, BasePriority);

   /* start with a known quantity (yep, got caught ;^) */
   status = SS$_NORMAL;

   /* sanity check */
   if (BasePriority > 5) BasePriority = 5;

   /* get a pointer to the request structure */
   rqptr = tkptr->RequestPtr;

#if OPERATE_WITH_SYSPRV
   /* if normally operating with SYSPRV *ensure* it's off before spawning */
   if (OperateWithSysPrv) 
      if (VMSnok (SetPrvStatus = sys$setprv (0, &SysPrvMask, 0, 0)))
         ErrorExitVmsStatus (SetPrvStatus, "sys$setprv()", FI_LI);
#endif

   if (DclScriptDetachProcess)
   {
      Accounting.DclCrePrcDetachCount++;
      CrePrcFlags = PRC$M_DETACH;
      tkptr->CrePrcDetachProcess = tkptr->CrePrcDetachStarting = true;
      if (VMSnok (SetPrvStatus = sys$setprv (1, &CrePrcMask, 0, 0)))
         ErrorExitVmsStatus (SetPrvStatus, "sys$setprv()", FI_LI);

      /* check if this task is for the same user as is required */
      if (strcmp (ScriptAsPtr, tkptr->CrePrcUserName)) 
      {
         /* nope, need to change the identity */
         zptr = (sptr = tkptr->CrePrcUserName) +
                sizeof(tkptr->CrePrcUserName)-1;
         for (cptr = ScriptAsPtr; *cptr && sptr < zptr; *sptr++ = *cptr++);
         *sptr = '\0';

         /* set mailbox ACLs to "tag" the mailbox, and allow user access */
         status = DclMailboxAcl (tkptr->SysCommandDevName,
                                 tkptr->CrePrcUserName);
         if (VMSok (status))
            status = DclMailboxAcl (tkptr->SysOutputDevName,
                                    tkptr->CrePrcUserName);
         if (VMSok (status))
            status = DclMailboxAcl (tkptr->HttpInputDevName,
                                    tkptr->CrePrcUserName);
         if (VMSok (status))
            status = DclMailboxAcl (tkptr->CgiPlusInDevName,
                                    tkptr->CrePrcUserName);
         if (VMSok (status))
            status = DclMailboxAcl (tkptr->CrePrcTermMbxDevName,
                                    tkptr->CrePrcUserName);
         if (Debug) fprintf (stdout, "DclMailboxAcl() %%X%08.08X\n", status);

         if (DclPersonaServicesAvailable && VMSok (status))
         {
            status = PersonaAssume (tkptr->CrePrcUserName);
            if (PersonaRightsIdent && VMSok (status))
            {
               /* persona access is identifier controlled, check for it */
               if (VMSnok (status = PersonaHoldsIdentifier ()))
               {
                  /* nope, return to the "natural" persona of the server */
                  PersonaAssume (NULL);
                  /* report this as "forbidden" */
                  if (status == SS$_NOSUCHID)
                     rqptr->rqResponse.HttpStatus = 403;
               }
            }
            if (VMSok (status)) Accounting.DclCrePrcPersonaCount++;
         }

         if (WatchEnabled & WATCH_DCL)
         {
            if (VMSok (status))
               WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                  "PERSONA !AZ", tkptr->CrePrcUserName);
            else
               WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                  "PERSONA !AZ %X!8XL %!%M",
                  tkptr->CrePrcUserName, status, status);
         }
      }
   }
   else
   {
      Accounting.DclCrePrcSubprocessCount++;
      CrePrcFlags = 0;
      if (Config.cfScript.SpawnAuthPriv)
      {
         /* enable persona's authorized privileges prior to spawning */
         if (VMSnok (status = sys$getjpiw (0, 0, 0, &JpiItems, 0, 0, 0)))
            ErrorExitVmsStatus (status, "sys$getjpiw()", FI_LI);
         if (VMSnok (SetPrvStatus =
             sys$setprv (1, &JpiAuthPriv, 0, &PrevPrivMask)))
            ErrorExitVmsStatus (SetPrvStatus, "sys$setprv()", FI_LI);
      }
   }

   if (VMSok (status))
   {                                
      for (Count = 100; Count; Count--)
      {
         /* script processes are consecutively numbered from 1..999 */
         ScriptProcessNameDsc.dsc$w_length = sizeof(ScriptProcessName)-1;
         sys$fao (&ScriptProcessNameFaoDsc, &Length, &ScriptProcessNameDsc, 
                  ServerPort, ScriptProcessNumber++ % 1000 + 1);
         ScriptProcessName[ScriptProcessNameDsc.dsc$w_length = Length] = '\0';
         if (Debug)
            fprintf (stdout, "ScriptProcessName |%s|\n", ScriptProcessName);

         status = sys$creprc (&tkptr->ScriptProcessPid,
                              &LoginOutDsc,
                              &tkptr->SysCommandDevNameDsc,
                              &tkptr->SysOutputDevNameDsc,
                              0, 0, 0,
                              &ScriptProcessNameDsc,
                              BasePriority,
                              0,
                              tkptr->CrePrcTermMbxUnit,
                              CrePrcFlags,
                              0, 0);
         if (Debug)
            fprintf (stdout, "sys$creprc() %%X%08.08X PID: %08.08X\n",
                     status, tkptr->ScriptProcessPid);

         if (WatchEnabled & WATCH_DCL)
         {
            if (VMSok (status))
               WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                  "CREATE !AZ pid !8XL priority !UL",
                  DclScriptDetachProcess ? "detached" : "subprocess",
                  tkptr->ScriptProcessPid, BasePriority);
            else
               WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                  "CREATE !AZ %X!8XL %!%M",
                  DclScriptDetachProcess ? "detached" : "subprocess",
                  status, status);
         }

         if (status != SS$_DUPLNAM) break;
      }
   }

   if (DclScriptDetachProcess)
   {
      if (DclPersonaServicesAvailable)
      {
         /* return to the "natural" persona of the server account */
         BecomeStatus = PersonaAssume (NULL);
         if (VMSnok (BecomeStatus)) status = BecomeStatus;
      }
      if (VMSnok (SetPrvStatus = sys$setprv (0, &CrePrcMask, 0, 0)))
         ErrorExitVmsStatus (SetPrvStatus, "sys$setprv()", FI_LI);
   }
   else
   if (Config.cfScript.SpawnAuthPriv)
   {
      /* spawned with authorized privileges, restore previous ones */
      if (VMSnok (SetPrvStatus = sys$setprv (0, &JpiAuthPriv, 0, 0)))
         ErrorExitVmsStatus (SetPrvStatus, "sys$setprv()", FI_LI);
      if (VMSnok (SetPrvStatus = sys$setprv (1, &PrevPrivMask, 0, 0)))
         ErrorExitVmsStatus (SetPrvStatus, "sys$setprv()", FI_LI);
   }

#if OPERATE_WITH_SYSPRV
   /* if normally operating with SYSPRV turn it back on */
   if (OperateWithSysPrv) 
      if (VMSnok (SetPrvStatus = sys$setprv (1, &SysPrvMask, 0, 0)))
         ErrorExitVmsStatus (SetPrvStatus, "sys$setprv()", FI_LI);
#endif

   if (VMSok (status))
   {
      /* queue a read from the process termination mailbox */
      sys$qio (0, tkptr->CrePrcTermMbxChannel, IO$_READLBLK,
               &tkptr->CrePrcTermMbxIOsb, &DclScriptProcessCompletionAST, tkptr,
               &tkptr->CrePrcTermRecord, sizeof(tkptr->CrePrcTermRecord),
               0, 0, 0, 0);
      if (Debug)
         fprintf (stdout, "sys$qio() %%X%08.08X %%X%08.08X\n", 
                  status, tkptr->CrePrcTermMbxIOsb.Count);
      if (VMSnok (status))
      {
         /* failed, need to know when the process exits ... delete now!! */
         status = sys$delprc (&tkptr->ScriptProcessPid, 0);
         if (VMSnok (status)) ErrorNoticed (status, "sys$delprc()", FI_LI); 
      }
   }

   if (VMSok (status))
   {
      Accounting.DclCrePrcCount++;
      return (status);
   }

   rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_SCRIPT_SPAWN);
   ErrorVmsStatus (rqptr, status, FI_LI);
   return (status);
}

/*****************************************************************************/
/*
This AST is called when the script processes exits.
*/

DclScriptProcessCompletionAST (struct DclTaskStruct *tkptr)

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
   {
      fprintf (stdout,
"DclScriptProcessCompletionAST() \
%%X%08.08X %08.08X %04.04X |%12.12s| %%X%08.08X\n",
         tkptr->CrePrcTermMbxIOsb.Status,
         tkptr->ScriptProcessPid,
         tkptr->CrePrcTermRecord.acc$w_msgtyp,
         tkptr->CrePrcTermRecord.acc$t_username,
         tkptr->CrePrcTermRecord.acc$l_finalsts);
   }

   if (VMSnok (tkptr->CrePrcTermMbxIOsb.Status))
   {
      if (WatchEnabled & WATCH_DCL)
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                    "TERMINATION-MBX !8XL %X!8XL %!%M",
                    tkptr->ScriptProcessPid,
                    tkptr->CrePrcTermMbxIOsb.Status,
                    tkptr->CrePrcTermMbxIOsb.Status);
      ErrorNoticed (tkptr->CrePrcTermMbxIOsb.Status,
                    "DclScriptProcessCompletionAST",FI_LI);
   }

   if (WatchEnabled & WATCH_DCL)
   {
      if (VMSok (tkptr->CrePrcTermRecord.acc$l_finalsts))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                    "!AZ completion pid !8XL",
                    DclScriptDetachProcess ? "DETACHED" : "SUBPROCESS",
                    tkptr->ScriptProcessPid);
      else
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                    "!AZ completion pid !8XL %X!8XL %!%M",
                    DclScriptDetachProcess ? "DETACHED" : "SUBPROCESS",
                    tkptr->ScriptProcessPid,
                    tkptr->CrePrcTermRecord.acc$l_finalsts,
                    tkptr->CrePrcTermRecord.acc$l_finalsts);
   }

   /* ensure SYS$COMMAND gets emptied! */
   tkptr->QueuedSysCommandAllowed = 0;

   /* won't be getting anymore output from this process! */
   status = sys$qio (0, tkptr->SysOutputChannel,
                     IO$_WRITEOF | IO$M_NORSWAIT, 0, 0, 0,
                     0, 0, 0, 0, 0, 0);
   if (Debug) fprintf (stdout, "sys$qio() %%X%08.08X\n", status);

   /* no longer marked for delete (if it was), set PID and lifetime to zero */
   tkptr->MarkedForDelete = false;
   tkptr->ScriptProcessPid = tkptr->LifeTimeCount = 0;
   tkptr->CrePrcUserName[0] = '\0';

   /* keep track of how many script processes are executing */
   if (DclScriptProcessCount) DclScriptProcessCount--;

   /* ensure any old sequence strings are not reused */
   tkptr->CgiBel[0] =
      tkptr->CgiEof[0] =
      tkptr->CgiEot[0] =
      tkptr->CgiEsc[0] = '\0';
   tkptr->CgiBelLength =
      tkptr->CgiEofLength =
      tkptr->CgiEotLength =
      tkptr->CgiEscLength = 0;

   DclConcludeTask (tkptr, false);
}

/*****************************************************************************/
/*
If a script application writes any output before it was/is terminated that
output will still be laying unread in the mailbox.  Clear any such noise lest
it be read by the next script process to use the mailbox.  Does this
synchronously (i.e. with QIO waits).
*/

DclEmptySysOutput (struct DclTaskStruct *tkptr)

{
   struct MbxSenseIOsb  SenseIOsb;
   int  LastMessageCount;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DclEmptySysOutput()\n");

   LastMessageCount = 999999999;
   SenseIOsb.MessageCount = 0;

   for (;;)
   {
      sys$qiow (0, tkptr->SysOutputChannel,
                IO$_SENSEMODE, &SenseIOsb,
                0, 0, 0, 0, 0, 0, 0, 0);

      if (VMSnok (SenseIOsb.Status))
         ErrorExitVmsStatus (SenseIOsb.Status, "sys$qiow()", FI_LI);

      if (Debug)
         fprintf (stdout, "sys$qiow() IO$_SENSEMODE %%X%08.08X %d %d\n", 
                  SenseIOsb.Status, SenseIOsb.MessageCount,
                  SenseIOsb.MessageBytes);

      if (!SenseIOsb.MessageCount) break;
      /* potential infinite loop, check message count is decreasing! */
      if (LastMessageCount <= SenseIOsb.MessageCount) break;
      LastMessageCount = SenseIOsb.MessageCount;

      sys$qiow (0, tkptr->SysOutputChannel,
                IO$_READLBLK, &tkptr->SysOutputIOsb, 0, 0,
                tkptr->SysOutputPtr, tkptr->SysOutputSize, 0, 0, 0, 0);

      if (Debug)
      {
         tkptr->SysOutputPtr[tkptr->SysOutputIOsb.Count] = '\0';
         fprintf (stdout, "sys$qiow() IO$_READLBLK %%X%08.08X %d\n|%s|\n", 
                  tkptr->SysOutputIOsb.Status, tkptr->SysOutputIOsb.Count,
                  tkptr->SysOutputPtr);
      }
   }
}

/*****************************************************************************/
/*
If an error is encountered an error message is generated and the error status
returned.  It is up to the calling routine to abort the processing.  Create
four mailboxes that will be associated with the script process I/O streams. If
an error occurs any mailbox created up to that point is deleted and the
channel set back to zero.
*/ 

#define DVI$_DEVNAM 32
#define DVI$_UNIT 12

DclCreateMailboxes (struct DclTaskStruct *tkptr)

{
   static unsigned long  DevNamItem = DVI$_DEVNAM,
                         UnitItem = DVI$_UNIT;

   int  status;
   unsigned short  Length;
   unsigned long  BytLmAfter,
                  BytLmBefore,
                  LongUnit;
   struct dsc$descriptor_s  *dscptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DclCreateMailboxes()\n");

   BytLmBefore = GetJpiBytLm ();

   if (Debug)
      fprintf (stdout, "DclMailboxBytLmRequired: %d BytLmBefore: %d\n",
              DclMailboxBytLmRequired, BytLmBefore);

   /* ensure we're leaving enough BYTLM for client socket creation at least */
   if (DclMailboxBytLmRequired &&
       BytLmBefore - DclMailboxBytLmRequired <=
       NetAcceptBytLmRequired * Config.cfServer.BusyLimit)
   {
      ErrorNoticed (0, "BYTLM exhausted", FI_LI);
      return (SS$_EXQUOTA);
   }

   tkptr->CgiPlusInChannel =
      tkptr->CrePrcTermMbxChannel =
      tkptr->HttpInputChannel =
      tkptr->SysCommandChannel =
      tkptr->SysOutputChannel = 0;

   /***********************/
   /* SYS$COMMAND mailbox */
   /***********************/

   if (VMSnok (status =
       sys$crembx (0,
                   &tkptr->SysCommandChannel,
                   DclSysCommandSize, DclSysCommandSize,
                   DCL_SUBPROCESS_MBX_PROT_MASK,
                   0, 0, CMB$M_WRITEONLY)))
   {
      if (Debug) fprintf (stdout, "sys$crembx() %%X%08.08X\n", status);
      goto DclCreateMailBoxesError;
   }

   dscptr = &tkptr->SysCommandDevNameDsc;
   dscptr->dsc$w_length = sizeof(tkptr->SysCommandDevName);
   dscptr->dsc$a_pointer = tkptr->SysCommandDevName;
   dscptr->dsc$b_class = DSC$K_CLASS_S;
   dscptr->dsc$b_dtype = DSC$K_DTYPE_T;

   if (VMSnok (status =
       lib$getdvi (&DevNamItem, &tkptr->SysCommandChannel,
                   0, 0, &tkptr->SysCommandDevNameDsc, &Length)))
   {
      if (Debug) fprintf (stdout, "lib$getdvi() %%X%08.08X\n", status);
      goto DclCreateMailBoxesError;
   }
   tkptr->SysCommandDevName[dscptr->dsc$w_length = Length] = '\0';
   if (Debug) fprintf (stdout, "SYS$COMMAND |%s|\n", tkptr->SysCommandDevName);

   /**********************/
   /* SYS$OUTPUT mailbox */
   /**********************/

   if (VMSnok (status =
       sys$crembx (0,
                   &tkptr->SysOutputChannel,
                   DclSysOutputSize, DclSysOutputSize,
                   DCL_SUBPROCESS_MBX_PROT_MASK,
                   0, 0, 0)))
   {
      if (Debug) fprintf (stdout, "sys$crembx() %%X%08.08X\n", status);
      goto DclCreateMailBoxesError;
   }

   dscptr = &tkptr->SysOutputDevNameDsc;
   dscptr->dsc$w_length = sizeof(tkptr->SysOutputDevName);
   dscptr->dsc$a_pointer = tkptr->SysOutputDevName;
   dscptr->dsc$b_class = DSC$K_CLASS_S;
   dscptr->dsc$b_dtype = DSC$K_DTYPE_T;

   if (VMSnok (status =
       lib$getdvi (&DevNamItem, &tkptr->SysOutputChannel,
                   0, 0, &tkptr->SysOutputDevNameDsc, &Length)))
   {
      if (Debug) fprintf (stdout, "lib$getdvi() %%X%08.08X\n", status);
      goto DclCreateMailBoxesError;
   }
   tkptr->SysOutputDevName [dscptr->dsc$w_length = Length] = '\0';
   if (Debug) fprintf (stdout, "SYS$OUTPUT |%s|\n", tkptr->SysOutputDevName);

   /*********************/
   /* CGIPLUSIN mailbox */
   /*********************/

   if (VMSnok (status =
       sys$crembx (0,
                   &tkptr->CgiPlusInChannel,
                   DclCgiPlusInSize, DclCgiPlusInSize,
                   DCL_SUBPROCESS_MBX_PROT_MASK,
                   0, 0, CMB$M_WRITEONLY)))
   {
      if (Debug) fprintf (stdout, "sys$crembx() %%X%08.08X\n", status);
      goto DclCreateMailBoxesError;
   }

   dscptr = &tkptr->CgiPlusInDevNameDsc;
   dscptr->dsc$w_length = sizeof(tkptr->CgiPlusInDevName);
   dscptr->dsc$a_pointer = tkptr->CgiPlusInDevName;
   dscptr->dsc$b_class = DSC$K_CLASS_S;
   dscptr->dsc$b_dtype = DSC$K_DTYPE_T;

   if (VMSnok (status =
       lib$getdvi (&DevNamItem, &tkptr->CgiPlusInChannel,
                   0, 0, &tkptr->CgiPlusInDevNameDsc, &Length)))
   {
      if (Debug) fprintf (stdout, "lib$getdvi() %%X%08.08X\n", status);
      goto DclCreateMailBoxesError;
   }
   tkptr->CgiPlusInDevName[dscptr->dsc$w_length = Length] = '\0';
   if (Debug) fprintf (stdout, "CGIPLUSIN |%s|\n", tkptr->CgiPlusInDevName);

   /**********************/
   /* HTTP$INPUT mailbox */
   /**********************/

   if (VMSnok (status =
       sys$crembx (0,
                   &tkptr->HttpInputChannel,
                   NetReadBufferSize, NetReadBufferSize,
                   DCL_SUBPROCESS_MBX_PROT_MASK,
                   0, 0, CMB$M_WRITEONLY)))
   {
      if (Debug) fprintf (stdout, "sys$crembx() %%X%08.08X\n", status);
      goto DclCreateMailBoxesError;
   }

   dscptr = &tkptr->HttpInputDevNameDsc;
   dscptr->dsc$w_length = sizeof(tkptr->HttpInputDevName);
   dscptr->dsc$a_pointer = tkptr->HttpInputDevName;
   dscptr->dsc$b_class = DSC$K_CLASS_S;
   dscptr->dsc$b_dtype = DSC$K_DTYPE_T;

   if (VMSnok (status =
       lib$getdvi (&DevNamItem, &tkptr->HttpInputChannel,
                   0, 0, &tkptr->HttpInputDevNameDsc, &Length)))
   {
      if (Debug) fprintf (stdout, "lib$getdvi() %%X%08.08X\n", status);
      goto DclCreateMailBoxesError;
   }
   tkptr->HttpInputDevName[dscptr->dsc$w_length = Length] = '\0';
   if (Debug) fprintf (stdout, "HTTP$INPUT |%s|\n", tkptr->HttpInputDevName);

   /************************************/
   /* SYS$CREPRC() termination mailbox */
   /************************************/

   if (VMSnok (status =
       sys$crembx (0,
                   &tkptr->CrePrcTermMbxChannel,
                   sizeof(struct DclCrePrcTermStruct),
                   sizeof(struct DclCrePrcTermStruct),
                   DCL_SUBPROCESS_MBX_PROT_MASK,
                   0, 0, CMB$M_READONLY)))
   {
      if (Debug) fprintf (stdout, "sys$crembx() %%X%08.08X\n", status);
      goto DclCreateMailBoxesError;
   }

   dscptr = &tkptr->CrePrcTermMbxDevNameDsc;
   dscptr->dsc$w_length = sizeof(tkptr->CrePrcTermMbxDevName);
   dscptr->dsc$a_pointer = tkptr->CrePrcTermMbxDevName;
   dscptr->dsc$b_class = DSC$K_CLASS_S;
   dscptr->dsc$b_dtype = DSC$K_DTYPE_T;

   status = lib$getdvi (&DevNamItem, &tkptr->CrePrcTermMbxChannel,
                        0, 0, &tkptr->CrePrcTermMbxDevNameDsc, &Length);
   if (VMSok (status))
      status = lib$getdvi (&UnitItem, &tkptr->CrePrcTermMbxChannel,
                           0, &LongUnit, 0, 0);
   if (VMSnok (status))
   {
      if (Debug) fprintf (stdout, "lib$getdvi() %%X%08.08X\n", status);
      goto DclCreateMailBoxesError;
   }
   /* lib$getdvi() requires 32 bit longs, the mailbox unit is only 16 bits */
   tkptr->CrePrcTermMbxUnit = (unsigned short)LongUnit;
   tkptr->CrePrcTermMbxDevName[dscptr->dsc$w_length = Length] = '\0';
   if (Debug)
      fprintf (stdout, "termination |%s| unit: %d\n",
               tkptr->CrePrcTermMbxDevName, tkptr->CrePrcTermMbxUnit);

   /******/
   /* OK */
   /******/

   if (!DclMailboxBytLmRequired)
   {
      BytLmAfter = GetJpiBytLm ();
      DclMailboxBytLmRequired = BytLmBefore - BytLmAfter;
      if (Debug)
         fprintf (stdout, "DclMailboxBytLmRequired: %d\n",
                  DclMailboxBytLmRequired);
   }

   return (SS$_NORMAL);

   /*********/
   /* ERROR */
   /*********/

DclCreateMailBoxesError:

   if (Debug) fprintf (stdout, "error %%X%08.08X\n", status);
   if (tkptr->CgiPlusInChannel) sys$dassgn (tkptr->CgiPlusInChannel);
   if (tkptr->CrePrcTermMbxChannel) sys$dassgn (tkptr->CrePrcTermMbxChannel);
   if (tkptr->HttpInputChannel) sys$dassgn (tkptr->HttpInputChannel);
   if (tkptr->SysCommandChannel) sys$dassgn (tkptr->SysCommandChannel);
   if (tkptr->SysOutputChannel) sys$dassgn (tkptr->SysOutputChannel);
   tkptr->CrePrcTermMbxChannel =
      tkptr->CgiPlusInChannel =
      tkptr->HttpInputChannel =
      tkptr->SysCommandChannel =
      tkptr->SysOutputChannel = 0;

   return (status);
}

/*****************************************************************************/
/*
Queue up a read from the script process "SYS$OUTPUT" mailbox.  When the read 
completes call function DclSysOutputAst(), do any post-processing required and
write the data to the client over the network.  The next read from the script
process via the mailbox will be queued by the network write completion AST
function.
*/ 

DclQioSysOutput (struct DclTaskStruct *tkptr)

{
   int  status,
        DclAstStatus;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "DclSysOutput() %d %d\n", tkptr, tkptr->RequestPtr);

   if (VMSnok (status =
       sys$qio (0, tkptr->SysOutputChannel,
                IO$_READLBLK, &tkptr->SysOutputIOsb, &DclSysOutputAst, tkptr,
                tkptr->SysOutputPtr, tkptr->SysOutputSize, 0, 0, 0, 0)))
   {
      /* report this error via the AST */
      tkptr->SysOutputIOsb.Status = status;
      SysDclAst (&DclSysOutputAst, tkptr);
   }
   tkptr->QueuedSysOutput++;
}

/*****************************************************************************/
/*
A queued asynchronous read from the script process "SYS$OUTPUT" mailbox has 
completed. 
*/ 

DclSysOutputAst (struct DclTaskStruct *tkptr)

{
   int  cnt, status, value;
   char  *cptr;
   struct RequestStruct  *rqptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
   {
      fprintf (stdout,
         "DclSysOutputAst() %d %d %08.08X %d %d %d %d %d %d %%X%08.08X\n",
         tkptr, tkptr->RequestPtr, tkptr->ScriptProcessPid,
         tkptr->QueuedSysCommand, tkptr->QueuedSysOutput,
         tkptr->QueuedCgiPlusIn, tkptr->QueuedHttpInput,
         tkptr->QueuedClientRead, tkptr->SysOutputIOsb.Count,
         tkptr->SysOutputIOsb.Status);

/**
      tkptr->SysOutputPtr[tkptr->SysOutputIOsb.Count] = '\0';
      fprintf (stdout, "|%s|\n", tkptr->SysOutputPtr);
**/
   }

   if (tkptr->QueuedSysOutput) tkptr->QueuedSysOutput--;

   rqptr = tkptr->RequestPtr;

   if (tkptr->WatchItem && (WatchEnabled & WATCH_DCL))
   {
      if (VMSnok (tkptr->SysOutputIOsb.Status))
         WatchThis (rqptr, FI_LI, WATCH_DCL,
                    "READ SYS$OUTPUT %X!8XL %!%M",
                    tkptr->SysOutputIOsb.Status,
                    tkptr->SysOutputIOsb.Status);
      else
      {
         WatchThis (rqptr, FI_LI, WATCH_DCL,
                    "READ SYS$OUTPUT %X!8XL !UL bytes",
                    tkptr->SysOutputIOsb.Status,
                    tkptr->SysOutputIOsb.Count);
         if (tkptr->SysOutputIOsb.Count)
            WatchDataDump (tkptr->SysOutputPtr,
                           tkptr->SysOutputIOsb.Count);
      }
   }

   if (rqptr->rqResponse.ErrorReportPtr != NULL)
   {
      /* this is an opportune point to report any error generated elsewhere */
      DclConcludeTask (tkptr, true);
      return;
   }

   if (tkptr->SysOutputIOsb.Status == SS$_ENDOFFILE)
   {
      if (!tkptr->ScriptProcessPid)
      {
         /* script process has already concluded, must be the last gasp! */
         DclConcludeTask (tkptr, false);
         return;
      }

      /* 
          If a script spawns multiple script processes each will
          terminate by queueing an end-of-file.  Ignore these.
          Queue the next read of the script process' SYS$OUTPUT.
          The CRTL outputs an end-of-file for a zero-length record.
          Put a count on the maximum number of these before the
          script is considered to be misbehaving.
      */
      if (tkptr->SysOutputEndOfFileCount++ > DCL_SCRIPT_MAX_ENDOFFILE)
      {
         tkptr->RequestPtr->rqResponse.HttpStatus = 502;
         ErrorGeneral (tkptr->RequestPtr,
            MsgFor(tkptr->RequestPtr,MSG_SCRIPT_RESPONSE_ERROR), FI_LI);
         DclConcludeTask (tkptr, true);
         return;
      }

      DclQioSysOutput (tkptr);
      return;
   }

   if (tkptr->ViaSysOutputStatus)
      tkptr->SysOutputIOsb.Status = tkptr->ViaSysOutputStatus;

   if (VMSnok (tkptr->SysOutputIOsb.Status))
   {
      if (tkptr->SysOutputIOsb.Status == SS$_ABORT ||
          tkptr->SysOutputIOsb.Status == SS$_CANCEL)
      {
         DclConcludeTask (tkptr, true);
         return;
      }

      rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_SCRIPT_IPC);
      ErrorVmsStatus (rqptr, tkptr->SysOutputIOsb.Status, FI_LI);
      DclConcludeTask (tkptr, true);
      return;
   }

   /*************/
   /* status OK */
   /*************/

   cptr = tkptr->SysOutputPtr;
   cnt = tkptr->SysOutputIOsb.Count;
   cptr[cnt] = '\0';

   if (tkptr->CrePrcDetachStarting)
   {
      if (cnt >= tkptr->CgiBelLength &&
          cnt <= tkptr->CgiBelLength+2 &&
          !memcmp (cptr, tkptr->CgiBel, tkptr->CgiBelLength))
      {
         tkptr->CrePrcDetachStarting = false;
         /* reset CGI output processing */
         CgiOutput (rqptr, NULL, 0);

         if (tkptr->WatchItem && (WatchEnabled & WATCH_DCL))
            WatchThis (rqptr, FI_LI, WATCH_DCL, "DETACHED process ready");
      }
      /* absorb this, just queue the next read */
      DclQioSysOutput (tkptr);
      return;
   }

   /*********************/
   /* finally it's true */
   /*********************/

   tkptr->ScriptProcessResponded = true;

   value = CgiOutput (rqptr, tkptr->SysOutputPtr, tkptr->SysOutputIOsb.Count);

   switch (value)
   {
      case CGI_OUTPUT_END :

         /* terminate processing */
         DclConcludeTask (tkptr, false);

         if (rqptr->rqCgi.CalloutInProgress)
         {
            if (tkptr->WatchItem && (WatchEnabled & WATCH_DCL))
               WatchThis (rqptr, FI_LI, WATCH_DCL, "CALLOUT end");

            /* script didn't send an EOT, let callable function know now! */
            rqptr->rqCgi.CalloutInProgress = false;

            /* the NULL and zero bytes indicates transaction end */
            rqptr->rqCgi.CalloutOutputPtr = NULL;
            rqptr->rqCgi.CalloutOutputCount = 0;

            /* execute the callout function */
            (*tkptr->CalloutFunction)(rqptr);
         }

         if ((void*)tkptr->CalloutFunction !=
             (void*)&DclCalloutDefault)
         {
            /* agent task */
            if (rqptr->rqCgi.BufferLength)
            {
               /* release the CGI variables used for this task */
               if (rqptr->rqCgi.BufferPtr != NULL)
                  VmFreeFromHeap (rqptr, rqptr->rqCgi.BufferPtr, FI_LI); 
               rqptr->rqCgi.BufferLength = 0;
               rqptr->rqCgi.BufferPtr = rqptr->rqCgi.BufferCurrentPtr = NULL;
            }
         }

         return;

      case CGI_OUTPUT_NOT_STRICT :

         /* not strictly CGI compliant, report and terminate processing */
         tkptr->RequestPtr->rqResponse.HttpStatus = 502;
         ErrorGeneral (tkptr->RequestPtr,
            MsgFor(tkptr->RequestPtr,MSG_SCRIPT_RESPONSE_ERROR), FI_LI);
         DclConcludeTask (tkptr, true);
         return;

      case CGI_OUTPUT_ESCAPE_BEGIN :

         /* start talking direct to the server */
         if (tkptr->WatchItem && (WatchEnabled & WATCH_DCL))
            WatchThis (rqptr, FI_LI, WATCH_DCL, "CALLOUT begin");

         rqptr->rqCgi.CalloutInProgress = true;

         /* the NULL and minus one bytes indicates transaction begin */
         rqptr->rqCgi.CalloutOutputPtr = NULL;
         rqptr->rqCgi.CalloutOutputCount = -1;

         /* execute the callout function */
         (*tkptr->CalloutFunction)(rqptr);

         DclQioSysOutput (tkptr);
         return;

      case CGI_OUTPUT_ESCAPE :

         /* the script is talking direct to the server */
         rqptr->rqCgi.CalloutOutputPtr = tkptr->SysOutputPtr;
         rqptr->rqCgi.CalloutOutputCount = tkptr->SysOutputIOsb.Count;

         if (tkptr->WatchItem && (WatchEnabled & WATCH_DCL))
         {
            WatchThis (rqptr, FI_LI, WATCH_DCL,
                       "CALLOUT !UL bytes",
                       rqptr->rqCgi.CalloutOutputCount);
            if (rqptr->rqCgi.CalloutOutputCount)
               WatchDataDump (rqptr->rqCgi.CalloutOutputPtr,
                              rqptr->rqCgi.CalloutOutputCount);
         }

         /* execute the callout function */
         (*tkptr->CalloutFunction)(rqptr);

         DclQioSysOutput (tkptr);
         return;

      case CGI_OUTPUT_ESCAPE_END :

         if (tkptr->WatchItem && (WatchEnabled & WATCH_DCL))
            WatchThis (rqptr, FI_LI, WATCH_DCL, "CALLOUT end");

         /* end talking direct to the server */
         rqptr->rqCgi.CalloutInProgress = false;

         /* the NULL and zero bytes indicates transaction end */
         rqptr->rqCgi.CalloutOutputPtr = NULL;
         rqptr->rqCgi.CalloutOutputCount = 0;

         /* execute the callout function */
         (*tkptr->CalloutFunction)(rqptr);

         DclQioSysOutput (tkptr);
         return;

      default :

         if (value > 0)
         {
            if (Debug) fprintf (stdout, "value: %d\n", value);
            cptr += value;
            cnt -= value;
         }

         /* step along any carriage control that may have been appended */
         while (cptr[cnt]) cnt++;

         if (!cnt)
         {
            /* output all absorbed, just queue the next read */
            DclQioSysOutput (tkptr);
            return;
         }

         if (rqptr->rqCgi.BufferRecords || rqptr->rqCgi.IsCliDcl)
         {
            /* buffer the record */
            NetWriteBuffered (rqptr, &DclSysOutputToClientAst, cptr, cnt);
            tkptr->QueuedSysOutput++;
            return;
         }

         /* write the record */
         NetWrite (rqptr, &DclSysOutputToClientAst, cptr, cnt);
         tkptr->QueuedSysOutput++;
         return;
   }
}

/*****************************************************************************/
/*
************
*** NOTE ***  This function takes a pointer to a request!!!
************  Due to is being an AST from a general network write function.

A queued asynchronous write of script process SYS$OUTPUT (mailbox) to the
client over the network has completed.
*/ 

DclSysOutputToClientAst (struct RequestStruct *rqptr)

{
   register struct DclTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   /* get a pointer to the DCL task from the request structure */
   tkptr = rqptr->DclTaskPtr;

   if (Debug)
      fprintf (stdout,
"DclSysOutputToClientAst() %d %d %d %d %d %d %d %%X%08.08X %%X%08.08X\n",
         tkptr, tkptr->RequestPtr, tkptr->QueuedSysCommand,
         tkptr->QueuedSysOutput, tkptr->QueuedCgiPlusIn,
         tkptr->QueuedHttpInput, tkptr->QueuedClientRead,
         tkptr->SysOutputIOsb.Status, rqptr->rqNet.WriteIOsb.Status);

   if (tkptr->QueuedSysOutput) tkptr->QueuedSysOutput--;

   /* abort task if NETWORK ERROR when writing TO CLIENT */
   if (VMSnok (rqptr->rqNet.WriteIOsb.Status))
   {
      DclConcludeTask (tkptr, true);
      return;
   }

   /* queue the next read of the script process' SYS$OUTPUT */
   DclQioSysOutput (tkptr);
}

/*****************************************************************************/
/*
Queue up a write of data to the script process "SYS$COMMAND" mailbox.  This is
the  script processes' "SYS$COMMAND", supplying the DCL commands to execute,
CGI information, etc.
*/ 

DclQioSysCommand 
(
struct DclTaskStruct *tkptr,
char *DataPtr,
int DataLength
)
{
   int  status,
        DclAstStatus;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "DclQioSysCommand() %d %d |%s|\n",
               tkptr, tkptr->RequestPtr, DataPtr);

   if (DataPtr == NULL)
   {
      /* NULL pointer means write an end-of-file to the channel */

      if (tkptr->WatchItem && (WatchEnabled & WATCH_DCL))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                    "WRITE SYS$COMMAND EOF");

      status = sys$qio (0, tkptr->SysCommandChannel,
                        IO$_WRITEOF | IO$M_NORSWAIT,
                        &tkptr->SysCommandIOsb, &DclSysCommandAst, tkptr,
                        0, 0, 0, 0, 0, 0);
   }
   else
   {
      if (tkptr->WatchItem && (WatchEnabled & WATCH_DCL))
      {
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                    "WRITE SYS$COMMAND !UL bytes", DataLength);
         if (DataLength) WatchData (DataPtr, DataLength);
      }

      status = sys$qio (0, tkptr->SysCommandChannel,
                        IO$_WRITELBLK | IO$M_NORSWAIT,
                        &tkptr->SysCommandIOsb, &DclSysCommandAst, tkptr,
                        DataPtr, DataLength, 0, 0, 0, 0);
   }

   if (Debug) fprintf (stdout, "sys$qio() %%X%08.08X\n", status);
   if (status == SS$_MBFULL)
   {
      tkptr->RequestPtr->rqResponse.ErrorTextPtr = "SYS$COMMAND";
      ErrorVmsStatus (tkptr->RequestPtr, status, FI_LI);
   }
   if (VMSnok (status))
   {
      /* report this error via the AST */
      tkptr->SysCommandIOsb.Status = status;
      SysDclAst (&DclSysCommandAst, tkptr);
   }
   tkptr->QueuedSysCommand++;
}

/*****************************************************************************/
/*
A queued write to the script process "SYS$COMMAND" mailbox has completed.  This
is  the script processes' "SYS$COMMAND", supplying the DCL commands to execute.
*/ 

DclSysCommandAst (struct DclTaskStruct *tkptr)

{
   /*********/
   /* begin */
   /*********/

   if (Debug)
   {
      fprintf (stdout,
         "DclSysCommandAst() %d %d %08.08X %d %d %d %d %d %%X%08.08X\n",
         tkptr, tkptr->RequestPtr, tkptr->ScriptProcessPid,
         tkptr->QueuedSysCommand, tkptr->QueuedSysOutput,
         tkptr->QueuedCgiPlusIn, tkptr->QueuedHttpInput,
         tkptr->QueuedClientRead, tkptr->SysCommandIOsb.Status);
   }

   if (tkptr->QueuedSysCommand) tkptr->QueuedSysCommand--;

   /* first AST is delivered %x00000000, make %X00000001 */
   if (!tkptr->SysCommandIOsb.Status) tkptr->SysCommandIOsb.Status = 1;

   if (tkptr->WatchItem && (WatchEnabled & WATCH_DCL))
   {
      if (VMSnok (tkptr->SysCommandIOsb.Status))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                    "WRITE SYS$COMMAND %X!8XL %!%M",
                    tkptr->SysCommandIOsb.Status,
                    tkptr->SysCommandIOsb.Status);
      else
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                    "WRITE SYS$COMMAND %X!8XL",
                    tkptr->SysCommandIOsb.Status);
   }

   /* if (effectively) no outstanding I/O then conclude the DCL task */
   if (tkptr->QueuedSysCommand <= tkptr->QueuedSysCommandAllowed &&
       !tkptr->QueuedSysOutput &&
       !tkptr->QueuedCgiPlusIn &&
       !tkptr->QueuedHttpInput &&
       !tkptr->QueuedClientRead)
   {
      DclConcludeTask (tkptr, false);
      return;
   }

   /* if I/O cancelled then just return */
   if (tkptr->SysCommandIOsb.Status == SS$_ABORT ||
       tkptr->SysCommandIOsb.Status == SS$_CANCEL)
      return;

   /* abort if an error writing SYS$COMMAND stream to script process */
   if (VMSnok (tkptr->SysCommandIOsb.Status))
   {
      tkptr->RequestPtr->rqResponse.ErrorTextPtr =
         MsgFor(tkptr->RequestPtr,MSG_SCRIPT_IPC);
      ErrorVmsStatus (tkptr->RequestPtr, tkptr->SysCommandIOsb.Status, FI_LI);
      DclConcludeTask (tkptr, true);
      return;
   }

   /* at least one DCL command was read indicating script activation */
   tkptr->ScriptProcessActivated = true;
}

/*****************************************************************************/
/*
Queue up a write of data to the script process "CGIPLUSIN" mailbox.  This is a
CGIplus script processes' CGI variable stream mailbox.             
*/ 

DclQioCgiPlusIn 
(
struct DclTaskStruct *tkptr,
char *DataPtr,
int DataLength
)
{
   int  status,
        DclAstStatus;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "DclQioCgiPlusIn() %d %d %d |%s|\n",
               tkptr, tkptr->RequestPtr, DataLength, DataPtr);

   if (DataPtr == NULL)
   {
      /* NULL pointer means write an end-of-file to the channel */

      if (tkptr->WatchItem && (WatchEnabled & WATCH_DCL))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                    "WRITE CGIPLUSIN EOF");

      status = sys$qio (0, tkptr->CgiPlusInChannel,
                        IO$_WRITEOF | IO$M_NORSWAIT, &tkptr->CgiPlusInIOsb,
                        &DclCgiPlusInAst, tkptr,
                        0, 0, 0, 0, 0, 0);
   }
   else
   {
      if (tkptr->WatchItem && (WatchEnabled & WATCH_DCL))
      {
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                    "WRITE CGIPLUSIN !UL bytes", DataLength);
         if (DataLength) WatchData (DataPtr, DataLength);
      }

      status = sys$qio (0, tkptr->CgiPlusInChannel,
                        IO$_WRITELBLK | IO$M_NORSWAIT, &tkptr->CgiPlusInIOsb,
                        &DclCgiPlusInAst, tkptr,
                        DataPtr, DataLength, 0, 0, 0, 0);
   }

   if (Debug) fprintf (stdout, "sys$qio() %%X%08.08X\n", status);
   if (status == SS$_MBFULL)
   {
      tkptr->RequestPtr->rqResponse.ErrorTextPtr = "CGIPLUSIN";
      ErrorVmsStatus (tkptr->RequestPtr, status, FI_LI);
   }
   if (VMSnok (status))
   {
      /* report this error via the AST */
      tkptr->CgiPlusInIOsb.Status = status;
      SysDclAst (&DclCgiPlusInAst, tkptr);
   }
   tkptr->QueuedCgiPlusIn++;
}

/*****************************************************************************/
/*
A queued write to the script process "CGIPLUSIN" mailbox has completed.  This
is a CGIplus script processes' CGI variable stream mailbox.             
*/ 

DclCgiPlusInAst (struct DclTaskStruct *tkptr)

{
   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
         "DclCgiPlusInAst() %d %d %08.08X %d %d %d %d %%X%08.08X\n",
         tkptr, tkptr->RequestPtr, tkptr->ScriptProcessPid,
         tkptr->QueuedCgiPlusIn, tkptr->QueuedSysOutput,
         tkptr->QueuedHttpInput, tkptr->QueuedClientRead,
         tkptr->CgiPlusInIOsb.Status);

   if (tkptr->QueuedCgiPlusIn) tkptr->QueuedCgiPlusIn--;

   /* first AST is delivered %x00000000, make %X00000001 */
   if (!tkptr->CgiPlusInIOsb.Status) tkptr->CgiPlusInIOsb.Status = 1;

   if (tkptr->WatchItem && (WatchEnabled & WATCH_DCL))
   {
      if (VMSnok (tkptr->CgiPlusInIOsb.Status))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                    "WRITE CGIPLUSIN %X!8XL %!%M",
                    tkptr->CgiPlusInIOsb.Status,
                    tkptr->CgiPlusInIOsb.Status);
      else
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                    "WRITE CGIPLUSIN %X!8XL",
                    tkptr->CgiPlusInIOsb.Status);
   }

   /* if (effectively) no outstanding I/O then conclude the DCL task */
   if (tkptr->QueuedSysCommand <= tkptr->QueuedSysCommandAllowed &&
       !tkptr->QueuedSysOutput &&
       !tkptr->QueuedCgiPlusIn &&
       !tkptr->QueuedHttpInput &&
       !tkptr->QueuedClientRead)
   {
      DclConcludeTask (tkptr, false);
      return;
   }

   /* if I/O cancelled then just return */
   if (tkptr->CgiPlusInIOsb.Status == SS$_ABORT ||
       tkptr->CgiPlusInIOsb.Status == SS$_CANCEL)
      return;

   /* abort if an error writing CGIPLUSIN stream to script process */
   if (VMSnok (tkptr->CgiPlusInIOsb.Status))
   {
      tkptr->RequestPtr->rqResponse.ErrorTextPtr =
         MsgFor(tkptr->RequestPtr,MSG_SCRIPT_IPC);
      ErrorVmsStatus (tkptr->RequestPtr, tkptr->CgiPlusInIOsb.Status, FI_LI);
      DclConcludeTask (tkptr, true);
      return;
   }

   /* at least one CGIPLUSIN variable was read indicating script activation */
   tkptr->ScriptProcessActivated = true;
}

/*****************************************************************************/
/*
A queued write to the script process "HTTP$INPUT" mailbox has completed.
Provide more (possibly first) of the request body, or EOF.
*/ 

DclHttpInputAst (struct DclTaskStruct *tkptr)

{
   int  status,
        DclAstStatus,
        Length;
   char  *ContentPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
         "DclHttpInputAst() %d %d %08.08X %d %d %d %d %d %d %%X%08.08X\n",
         tkptr, tkptr->RequestPtr, tkptr->ScriptProcessPid,
         tkptr->QueuedSysCommand, tkptr->QueuedSysOutput,
         tkptr->QueuedCgiPlusIn, tkptr->QueuedHttpInput,
         tkptr->QueuedClientRead, tkptr->HttpInputIOsb.Count,
         tkptr->HttpInputIOsb.Status);

   if (tkptr->QueuedHttpInput) tkptr->QueuedHttpInput--;

   if (tkptr->WatchItem && (WatchEnabled & WATCH_DCL))
   {
      if (VMSnok (tkptr->HttpInputIOsb.Status))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                    "WRITE HTTP$INPUT %X!8XL %!%M",
                    tkptr->HttpInputIOsb.Status,
                    tkptr->HttpInputIOsb.Status);
      else
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                    "WRITE HTTP$INPUT %X!8XL",
                    tkptr->HttpInputIOsb.Status);
   }

   /* if (effectively) no outstanding I/O then conclude the DCL task */
   if (tkptr->QueuedSysCommand <= tkptr->QueuedSysCommandAllowed &&
       !tkptr->QueuedSysOutput &&
       !tkptr->QueuedCgiPlusIn &&
       !tkptr->QueuedHttpInput &&
       !tkptr->QueuedClientRead)
   {
      DclConcludeTask (tkptr, false);
      return;
   }

   /* if I/O cancelled then just return */
   if (tkptr->HttpInputIOsb.Status == SS$_ABORT ||
       tkptr->HttpInputIOsb.Status == SS$_CANCEL)
      return;

   /* abort if an error writing HTTP stream to script process */
   if (VMSnok (tkptr->HttpInputIOsb.Status))
   {
      tkptr->RequestPtr->rqResponse.ErrorTextPtr =
         MsgFor(tkptr->RequestPtr,MSG_SCRIPT_IPC);
      ErrorVmsStatus (tkptr->RequestPtr, tkptr->HttpInputIOsb.Status, FI_LI);
      DclConcludeTask (tkptr, true);
      return;
   }

   if (Debug)
      fprintf (stdout, "%d %d\n", tkptr->ContentLength, tkptr->ContentPtr);

   if (tkptr->ContentLength)
   {
      if (tkptr->ContentLength > NetReadBufferSize)
         Length = NetReadBufferSize;
      else
         Length = tkptr->ContentLength;
      ContentPtr = tkptr->ContentPtr;
      tkptr->ContentPtr += Length;
      tkptr->ContentLength -= Length;

      if (tkptr->WatchItem && (WatchEnabled & WATCH_DCL))
      {
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                    "WRITE SYS$INPUT !UL bytes", Length);
         if (Length) WatchDataDump (ContentPtr, Length);
      }

      status = sys$qio (0, tkptr->HttpInputChannel,
                        IO$_WRITELBLK, &tkptr->HttpInputIOsb,
                        &DclHttpInputAst, tkptr,
                        ContentPtr, Length, 0, 0, 0, 0);
   }
   else
   {
      if (tkptr->WatchItem && (WatchEnabled & WATCH_DCL))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                    "WRITE SYS$INPUT EOF");

      status = sys$qio (0, tkptr->HttpInputChannel,
                        IO$_WRITEOF, &tkptr->HttpInputIOsb,
                        &DclHttpInputAst, tkptr,
                        0, 0, 0, 0, 0, 0);
   }

   if (Debug) fprintf (stdout, "sys$qio() %%X%08.08X\n", status);
   if (VMSnok (status))
   {
      /* report this error via the AST */
      tkptr->HttpInputIOsb.Status = status;
      SysDclAst (&DclHttpInputAst, tkptr);
   }
   tkptr->QueuedHttpInput++;
}

/*****************************************************************************/
/*
A CLIENT-READ: callout network read from the client has concluded.  If an error
then just conclude the task.  If OK then queue it to the HTTP$INPUT device so
the script can read it.
*/ 
 
DclClientReadAst (struct RequestStruct *rqptr)

{
   int  status;
   struct DclTaskStruct  *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
         "DclClientReadAst() Status: %%X%08.08X Count: %d \n",
         rqptr->rqNet.ReadIOsb.Status, rqptr->rqNet.ReadIOsb.Count);

   /* get a pointer to the DCL task from the request structure */
   tkptr = rqptr->DclTaskPtr;

   if (tkptr->QueuedClientRead) tkptr->QueuedClientRead--;

   /* if (effectively) no outstanding I/O then conclude the DCL task */
   if (tkptr->QueuedSysCommand <= tkptr->QueuedSysCommandAllowed &&
       !tkptr->QueuedSysOutput &&
       !tkptr->QueuedCgiPlusIn &&
       !tkptr->QueuedHttpInput &&
       !tkptr->QueuedClientRead)
   {
      DclConcludeTask (tkptr, false);
      return;
   }

   if (VMSnok (rqptr->rqNet.ReadIOsb.Status))
   {
      DclConcludeTask (tkptr, true);
      return;
   }

   if (tkptr->ClientReadStripCrLf)
   {
      if (rqptr->rqNet.ReadIOsb.Count >= 2 &&
          tkptr->ClientReadBufferPtr[rqptr->rqNet.ReadIOsb.Count-2] == '\r' &&
          tkptr->ClientReadBufferPtr[rqptr->rqNet.ReadIOsb.Count-1] == '\n')
         rqptr->rqNet.ReadIOsb.Count -= 2;
      else
      if (rqptr->rqNet.ReadIOsb.Count >= 1 &&
          tkptr->ClientReadBufferPtr[rqptr->rqNet.ReadIOsb.Count-1] == '\n')
         rqptr->rqNet.ReadIOsb.Count--;
   }

   status = sys$qio (0, tkptr->HttpInputChannel,
                     IO$_WRITELBLK, &tkptr->HttpInputIOsb,
                     &DclClientReadHttpInputAst, tkptr,
                     tkptr->ClientReadBufferPtr, rqptr->rqNet.ReadIOsb.Count,
                     0, 0, 0, 0);

   if (Debug) fprintf (stdout, "sys$qio() %%X%08.08X\n", status);
   if (VMSnok (status))
   {
      /* report this error via the AST */
      tkptr->HttpInputIOsb.Status = status;
      SysDclAst (&DclClientReadAst, tkptr);
   }
   tkptr->QueuedHttpInput++;
}

/*****************************************************************************/
/*
A CLIENT-READ: callout write of client data to the HTTP$DEVICE has concluded. 
If there was an error writing this to the script then just conclude the task. 
If OK then queue another network read from the client.
*/ 

DclClientReadHttpInputAst (struct DclTaskStruct *tkptr)

{
   int  status,
        DclAstStatus,
        Length;
   char  *ContentPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
"DclClientReadHttpInputAst() %d %d %08.08X %d %d %d %d %d %d %%X%08.08X\n",
         tkptr, tkptr->RequestPtr, tkptr->ScriptProcessPid,
         tkptr->QueuedSysCommand, tkptr->QueuedSysOutput,
         tkptr->QueuedCgiPlusIn, tkptr->QueuedHttpInput,
         tkptr->QueuedClientRead, tkptr->HttpInputIOsb.Count,
         tkptr->HttpInputIOsb.Status);

   if (tkptr->QueuedHttpInput) tkptr->QueuedHttpInput--;

   if (tkptr->WatchItem && (WatchEnabled & WATCH_DCL))
   {
      if (VMSnok (tkptr->HttpInputIOsb.Status))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                    "CLIENT-READ %X!8XL %!%M",
                    tkptr->HttpInputIOsb.Status,
                    tkptr->HttpInputIOsb.Status);
      else
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_DCL,
                    "CLIENT-READ %X!8XL",
                    tkptr->HttpInputIOsb.Status);
   }

   /* if (effectively) no outstanding I/O then conclude the DCL task */
   if (tkptr->QueuedSysCommand <= tkptr->QueuedSysCommandAllowed &&
       !tkptr->QueuedSysOutput &&
       !tkptr->QueuedCgiPlusIn &&
       !tkptr->QueuedHttpInput &&
       !tkptr->QueuedClientRead)
   {
      DclConcludeTask (tkptr, false);
      return;
   }

   /* if I/O cancelled then just return */
   if (tkptr->HttpInputIOsb.Status == SS$_ABORT ||
       tkptr->HttpInputIOsb.Status == SS$_CANCEL)
      return;

   /* abort if an error writing HTTP stream to script process */
   if (VMSnok (tkptr->HttpInputIOsb.Status))
   {
      tkptr->RequestPtr->rqResponse.ErrorTextPtr =
         MsgFor(tkptr->RequestPtr,MSG_SCRIPT_IPC);
      ErrorVmsStatus (tkptr->RequestPtr, tkptr->HttpInputIOsb.Status, FI_LI);
      DclConcludeTask (tkptr, true);
      return;
   }

   /* asynchronous read another record from the client */
   NetRead (tkptr->RequestPtr, &DclClientReadAst,
            tkptr->ClientReadBufferPtr, tkptr->ClientReadBufferSize);
   tkptr->QueuedClientRead++;
}

/*****************************************************************************/
/*
Send DCL commands to the CGI script or DCL command script process' SYS$COMMAND.
This sets up the DCL environment (defines logical names, assigns symbols)
executes the procedure or image.
*/ 

int DclCgiScriptSysCommand (struct DclTaskStruct *tkptr)

{
   static char  DclHttpdVerify1 [] = "!\'F$VERIFY(0)";
   static char  DclHttpdVerify2 [] =
"IF F$TRNLNM(\"HTTPD$VERIFY\") THEN \
WRITE SYS$OUTPUT \"Content-Type: text/plain\015\012\015\012\"";
   static char  DclHttpdVerify3 [] = "!\'F$VERIFY(F$TRNLNM(\"HTTPD$VERIFY\"))";
   static char  DelSymAll [] = "DELSYMALL=\"DELETE/SYMBOL/ALL\"";
   static char  DelSymAllGlobal[] = "DELSYMALL/GLOBAL";
   static char  DelSymAllLocal[] = "DELSYMALL/LOCAL";
   static char  HttpdLogin [] =
                "IF F$TRNLNM(\"HTTPD$LOGIN\").NES.\"\" THEN @HTTPD$LOGIN";
   static char  NoVerify [] = "!'F$VERIFY(0)";
   static char  SetNoOn[] = "SET NOON";
   /* this symbol is required by CGI.C module for single quote substitution */
   static char  StopId [] = "STOP/ID=0";
   static char  WriteIsWrite [] = "WRITE=\"WRITE\"";

   static $DESCRIPTOR (WriteDclQuoteFaoDsc, "WRITE SYS$OUTPUT \"!AZ\"");

   static $DESCRIPTOR (DefineHttpInputFaoDsc,
                       "DEFINE/NOLOG/SUPER HTTP$INPUT !AZ");
   static $DESCRIPTOR (DefineSysInputFaoDsc,
                       "DEFINE/NOLOG/SUPER SYS$INPUT !AZ");

#if CGIPLUS_CALLOUT_FOR_CGI

   static $DESCRIPTOR (DefineCgiPlusInFaoDsc,
                       "DEFINE/NOLOG/SUPER CGIPLUSIN !AZ");
   static $DESCRIPTOR (DefineCgiPlusEotFaoDsc,
                       "DEFINE/NOLOG/SUPER CGIPLUSEOT \"!AZ\"");
   static $DESCRIPTOR (DefineCgiPlusEscFaoDsc,
                       "DEFINE/NOLOG/SUPER CGIPLUSESC \"!AZ\"");

#endif /* CGIPLUS_CALLOUT_FOR_CGI */

#if STREAMS_FOR_APACHE

   static $DESCRIPTOR (DefineApacheInputFaoDsc,
                       "DEFINE/NOLOG/SUPER APACHE$INPUT !AZ");

#endif /* STREAMS_FOR_APACHE */

#if STREAMS_FOR_PURVEYOR_AND_CERN

   static $DESCRIPTOR (DefineWwwInFaoDsc,
                       "DEFINE/NOLOG/SUPER WWW_IN !AZ");
   static char  DefineWwwOut[] = "DEFINE/NOLOG/SUPER WWW_OUT SYS$OUTPUT:";

#endif /* STREAMS_FOR_PURVEYOR_AND_CERN */

   int  status,
        Count;
   unsigned short  Length;
   char  c;
   char  *cptr, *sptr, *zptr;
   char  FormFieldName [256],
         Scratch [1024],
         DclLine [256];
   struct RequestStruct *rqptr;
   $DESCRIPTOR (DclLineDsc, DclLine);

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "DclCgiScriptSysCommand() |%s|%s|%s|\n",
               tkptr->DclCommand, tkptr->ScriptFileName,
               tkptr->ScriptRunTimePtr);

   /* get the pointer to the request structure */
   rqptr = tkptr->RequestPtr;

   if (tkptr->CrePrcDetachStarting)
   {
      /* indicate any login message, etc. are finished, process is ready */
      DclQioSysCommand (tkptr, WriteIsWrite, sizeof(WriteIsWrite)-1);
      sys$fao (&WriteDclQuoteFaoDsc, &Length, &DclLineDsc, tkptr->CgiBel);
      DclLine[Length] = '\0';
      DclQioSysCommand (tkptr, DclLine, Length);
   }

   DclQioSysCommand (tkptr, DclHttpdVerify1, sizeof(DclHttpdVerify1)-1);
   DclQioSysCommand (tkptr, DclHttpdVerify2, sizeof(DclHttpdVerify2)-1);
   DclQioSysCommand (tkptr, DclHttpdVerify3, sizeof(DclHttpdVerify3)-1);
   DclQioSysCommand (tkptr, SetNoOn, sizeof(SetNoOn)-1);
   DclQioSysCommand (tkptr, DelSymAll, sizeof(DelSymAll)-1);
   DclQioSysCommand (tkptr, DelSymAllGlobal, sizeof(DelSymAllGlobal)-1);
   DclQioSysCommand (tkptr, DelSymAllLocal, sizeof(DelSymAllLocal)-1);

   if (tkptr->TaskType == DCL_TASK_TYPE_CGI_SCRIPT)
   {
      sys$fao (&DefineSysInputFaoDsc, &Length, &DclLineDsc,
               tkptr->HttpInputDevName);
      DclLine[Length] = '\0';
      DclQioSysCommand (tkptr, DclLine, Length);

      /* for backward compatibility */
      sys$fao (&DefineHttpInputFaoDsc, &Length, &DclLineDsc,
               tkptr->HttpInputDevName);
      DclLine[Length] = '\0';
      DclQioSysCommand (tkptr, DclLine, Length);

#if STREAMS_FOR_PURVEYOR_AND_CERN

      /* for Purveyor, Cern backward compatibility */
      sys$fao (&DefineWwwInFaoDsc, &Length, &DclLineDsc,
               tkptr->HttpInputDevName);
      DclLine[Length] = '\0';
      DclQioSysCommand (tkptr, DclLine, Length);
      DclQioSysCommand (tkptr, DefineWwwOut, sizeof(DefineWwwOut)-1);

#endif /* STREAMS_FOR_PURVEYOR_AND_CERN */

#if STREAMS_FOR_APACHE

      /* for VMS Apache forward compatibility :^) */
      sys$fao (&DefineApacheInputFaoDsc, &Length, &DclLineDsc,
               tkptr->HttpInputDevName);
      DclLine[Length] = '\0';
      DclQioSysCommand (tkptr, DclLine, Length);

#endif /* STREAMS_FOR_APACHE */

#if CGIPLUS_CALLOUT_FOR_CGI

      sys$fao (&DefineCgiPlusInFaoDsc, &Length, &DclLineDsc,
               tkptr->CgiPlusInDevName);
      DclLine[Length] = '\0';
      status = DclQioSysCommand (tkptr, DclLine, Length);

      sys$fao (&DefineCgiPlusEotFaoDsc, &Length, &DclLineDsc,
               tkptr->CgiEot);
      DclLine[Length] = '\0';
      status = DclQioSysCommand (tkptr, DclLine, Length);

      sys$fao (&DefineCgiPlusEscFaoDsc, &Length, &DclLineDsc,
               tkptr->CgiEsc);
      DclLine[Length] = '\0';
      status = DclQioSysCommand (tkptr, DclLine, Length);

#endif /* CGIPLUS_CALLOUT_FOR_CGI */
   }

   /*****************/
   /* CGI variables */
   /*****************/

   /*
      CGI script requests can only call this once.
      DCL commands from SSI documents can call this multiple times.
      Once the CGI information is generated is is essentially static
      for the life of the request ... so only generate it the once!
   */
   if (rqptr->rqCgi.BufferPtr == NULL)
      if (VMSnok (status = CgiGenerateVariables (rqptr, CGI_VARIABLE_DCL)))
         return (status);

   cptr = rqptr->rqCgi.BufferPtr;
   for (;;)
   {
      if (!(Length = *(short*)cptr)) break;
      DclQioSysCommand (tkptr, cptr+sizeof(short), Length-1);
      cptr += Length + sizeof(short);
   }

   /*******************************/
   /* DCL command/procedure/image */
   /*******************************/

   DclQioSysCommand (tkptr, HttpdLogin, sizeof(HttpdLogin)-1);

   if (tkptr->ScriptFileName[0])
   {
      /**************/
      /* CGI script */
      /**************/

      zptr = (sptr = DclLine) + sizeof(DclLine)-1;

      cptr = tkptr->ScriptRunTimePtr;
      if (cptr == DCL_RUNTIME_COM)
      {
         /* DCL procedure */
         *sptr++ = '@';
      }
      else
      if (cptr == DCL_RUNTIME_EXE)
      {
         /* execute an image */
         memcpy (sptr, "RUN ", 4);
         sptr += 4;
      }
      else
      if (*cptr == '@' || *cptr == '$')
      {
         /* foreign-verb DCL procedure or executable, create the verb */
         memcpy (sptr, "VERB:=", 6);
         sptr += 6;
         while (*cptr && sptr < zptr) *sptr++ = *cptr++;
         *sptr = '\0';
         DclQioSysCommand (tkptr, DclLine, sptr-DclLine);

         /* now place it as the verb before the script file */
         zptr = (sptr = DclLine) + sizeof(DclLine)-1;
         memcpy (sptr, "VERB ", 5);
         sptr += 5;
      }
      else
      {
         /* verb must already exist on site, place before the script file */
         while (*cptr && sptr < zptr) *sptr++ = *cptr++;
         if (sptr < zptr) *sptr++ = ' ';
      }

      cptr = tkptr->SearchOds.ResFileName;
      while (*cptr && sptr < zptr) *sptr++ = *cptr++;
      *sptr = '\0';
      DclQioSysCommand (tkptr, DclLine, sptr-DclLine);
   }
   else
   {
      /*******/
      /* CLI */
      /*******/

      /* multiple commands may be separated by newlines */
      sptr = tkptr->DclCommand;
      while (*sptr)
      {
         cptr = sptr;
         while (*sptr && *sptr != '\n') sptr++;
         Length = sptr - cptr;
         if (*sptr == '\n') *sptr++ = '\0';
         DclQioSysCommand (tkptr, cptr, Length);
      }
   }

   /*********************/
   /* after script runs */
   /*********************/

   if (DclUseZombies)
   {
      DclQioSysCommand (tkptr, NoVerify, sizeof(NoVerify)-1);
      DclQioSysCommand (tkptr, WriteIsWrite, sizeof(WriteIsWrite)-1);

      sys$fao (&WriteDclQuoteFaoDsc, &Length, &DclLineDsc, tkptr->CgiEof);
      DclLine[Length] = '\0';
      DclQioSysCommand (tkptr, DclLine, Length);

      /* do not send an end-of-file! */
      return (SS$_NORMAL);
   }
   else
   {
      /* ensure script process terminates! */
      DclQioSysCommand (tkptr, StopId, sizeof(StopId)-1);

      /* send end-of-file */
      DclQioSysCommand (tkptr, NULL, 0);
   }

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Send DCL commands to the CGIplus script process' SYS$COMMAND. This sets up the
DCL environment (defines logical names, assigns symbols) executes the procedure
or image.
*/ 

DclCgiPlusScriptSysCommand (struct DclTaskStruct *tkptr)

{
   static char  DclHttpdVerify1 [] = "!\'F$VERIFY(0)";
   static char  DclHttpdVerify2 [] =
"IF F$TRNLNM(\"HTTPD$VERIFY\") THEN \
WRITE SYS$OUTPUT \"Content-Type: text/plain\015\012\015\012\"";
   static char  DclHttpdVerify3 [] = "!\'F$VERIFY(F$TRNLNM(\"HTTPD$VERIFY\"))";
   static char  DelSymAll [] = "DELSYMALL=\"DELETE/SYMBOL/ALL\"";
   static char  DelSymAllGlobal[] = "DELSYMALL/GLOBAL";
   static char  DelSymAllLocal[] = "DELSYMALL/LOCAL";
   static char  HttpdLogin [] =
                "IF F$TRNLNM(\"HTTPD$LOGIN\").NES.\"\" THEN @HTTPD$LOGIN";
   static char  SetNoOn [] = "SET NOON";
   static char  StopId [] = "STOP/ID=0";

   static $DESCRIPTOR (DefineCgiPlusInFaoDsc,
                       "DEFINE/NOLOG/SUPER CGIPLUSIN !AZ");
   static $DESCRIPTOR (DefineCgiPlusEofFaoDsc,
                       "DEFINE/NOLOG/SUPER CGIPLUSEOF \"!AZ\"");
   static $DESCRIPTOR (DefineCgiPlusEotFaoDsc,
                       "DEFINE/NOLOG/SUPER CGIPLUSEOT \"!AZ\"");
   static $DESCRIPTOR (DefineCgiPlusEscFaoDsc,
                       "DEFINE/NOLOG/SUPER CGIPLUSESC \"!AZ\"");
   static $DESCRIPTOR (DefineHttpInputFaoDsc,
                       "DEFINE/NOLOG/SUPER HTTP$INPUT !AZ");
   static $DESCRIPTOR (DefineSysInputFaoDsc,
                       "DEFINE/NOLOG/SUPER SYS$INPUT !AZ");

   static $DESCRIPTOR (WriteDclQuoteFaoDsc, "WRITE SYS$OUTPUT \"!AZ\"");

   register char  *cptr, *sptr, *zptr;
   register struct RequestStruct *rqptr;

   int  status;
   unsigned short  Length;
   char  DclLine [256];
   $DESCRIPTOR (DclLineDsc, DclLine);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DclCgiPlusScriptSysCommand()\n");

   /* get the pointer to the request structure */
   rqptr = tkptr->RequestPtr;

   if (tkptr->CrePrcDetachStarting)
   {
      /* indicate any login message, etc. are finished, process is ready */
      sys$fao (&WriteDclQuoteFaoDsc, &Length, &DclLineDsc, tkptr->CgiBel);
      DclLine[Length] = '\0';
      DclQioSysCommand (tkptr, DclLine, Length);
   }

   DclQioSysCommand (tkptr, DclHttpdVerify1, sizeof(DclHttpdVerify1)-1);
   DclQioSysCommand (tkptr, DclHttpdVerify2, sizeof(DclHttpdVerify2)-1);
   DclQioSysCommand (tkptr, DclHttpdVerify3, sizeof(DclHttpdVerify3)-1);
   DclQioSysCommand (tkptr, SetNoOn, sizeof(SetNoOn)-1);
   DclQioSysCommand (tkptr, DelSymAll, sizeof(DelSymAll)-1);
   DclQioSysCommand (tkptr, DelSymAllGlobal, sizeof(DelSymAllGlobal)-1);
   DclQioSysCommand (tkptr, DelSymAllLocal, sizeof(DelSymAllLocal)-1);

   sys$fao (&DefineSysInputFaoDsc, &Length, &DclLineDsc,
            tkptr->HttpInputDevName);
   DclLine[Length] = '\0';
   DclQioSysCommand (tkptr, DclLine, Length);

   /* for backward compatibility */
   sys$fao (&DefineHttpInputFaoDsc, &Length, &DclLineDsc,
            tkptr->HttpInputDevName);
   DclLine[Length] = '\0';
   DclQioSysCommand (tkptr, DclLine, Length);

   sys$fao (&DefineCgiPlusInFaoDsc, &Length, &DclLineDsc,
            tkptr->CgiPlusInDevName);
   DclLine[Length] = '\0';
   status = DclQioSysCommand (tkptr, DclLine, Length);

   sys$fao (&DefineCgiPlusEofFaoDsc, &Length, &DclLineDsc,
            tkptr->CgiEof);
   DclLine[Length] = '\0';
   status = DclQioSysCommand (tkptr, DclLine, Length);

   sys$fao (&DefineCgiPlusEotFaoDsc, &Length, &DclLineDsc,
            tkptr->CgiEot);
   DclLine[Length] = '\0';
   status = DclQioSysCommand (tkptr, DclLine, Length);

   sys$fao (&DefineCgiPlusEscFaoDsc, &Length, &DclLineDsc,
            tkptr->CgiEsc);
   DclLine[Length] = '\0';
   status = DclQioSysCommand (tkptr, DclLine, Length);

   /***********************/
   /* DCL procedure/image */
   /***********************/

   DclQioSysCommand (tkptr, HttpdLogin, sizeof(HttpdLogin)-1);

   if (tkptr->TaskType == DCL_TASK_TYPE_RTE_SCRIPT)
   {
      /*******/
      /* RTE */
      /*******/

      zptr = (sptr = DclLine) + sizeof(DclLine)-1;
      if (tkptr->RteFileName[0] != '@')
         for (cptr = "RUN "; *cptr && sptr < zptr; *sptr++ = *cptr++);
      for (cptr = tkptr->RteFileName; *cptr && sptr < zptr; *sptr++ = *cptr++);
   }
   else
   {
      /******************/
      /* CGIplus script */
      /******************/

      zptr = (sptr = DclLine) + sizeof(DclLine)-1;
      cptr = tkptr->ScriptRunTimePtr;
      if (cptr == DCL_RUNTIME_COM)
      {
         /* DCL procedure */
         *sptr++ = '@';
      }
      else
      if (cptr == DCL_RUNTIME_EXE)
      {
         /* execute an image */
         memcpy (sptr, "RUN ", 4);
         sptr += 4;
      }
      else
      if (*cptr == '@' || *cptr == '$')
      {
         /* foreign-verb DCL procedure or executable, create the verb */
         memcpy (sptr, "VERB:=", 6);
         sptr += 6;
         while (*cptr && sptr < zptr) *sptr++ = *cptr++;
         *sptr = '\0';
         DclQioSysCommand (tkptr, DclLine, sptr-DclLine);

         /* now place it as the verb before the script file */
         zptr = (sptr = DclLine) + sizeof(DclLine)-1;
         memcpy (sptr, "VERB ", 5);
         sptr += 5;
      }
      else
      {
         /* verb must already exist on site, place before the script file */
         while (*cptr && sptr < zptr) *sptr++ = *cptr++;
         if (sptr < zptr) *sptr++ = ' ';
      }

      cptr = tkptr->SearchOds.ResFileName;
      while (*cptr && sptr < zptr) *sptr++ = *cptr++;
   }

   *sptr = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", DclLine);
   DclQioSysCommand (tkptr, DclLine, sptr-DclLine);

   /* ensure script process terminates! */
   DclQioSysCommand (tkptr, StopId, sizeof(StopId)-1);

   /* send end-of-file */
   DclQioSysCommand (tkptr, NULL, 0);
}

/*****************************************************************************/
/*
Send CGI variables to the script process' CGIPLUSIN input stream.
*/ 

int DclCgiPlusScriptCgiPlusIn (struct DclTaskStruct *tkptr)

{
   register char  *cptr;
   register struct RequestStruct *rqptr;

   int  status;
   unsigned short  Length;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DclCgiPlusScriptCgiPlusIn()\n");

   /* get the pointer to the request structure */
   rqptr = tkptr->RequestPtr;

   /* just a line for "start-of-request" that can always be discarded */
   DclQioCgiPlusIn (tkptr, "!", 1);

   if (VMSnok (status = CgiGenerateVariables (rqptr, CGI_VARIABLE_STREAM)))
      return (status);

   cptr = rqptr->rqCgi.BufferPtr;
   for (;;)
   {
      if (!(Length = *(short*)cptr)) break;
      DclQioCgiPlusIn (tkptr, cptr+sizeof(short), Length-1);
      cptr += Length + sizeof(short);
   }

   /* empty line terminates CGI variables */
   DclQioCgiPlusIn (tkptr, "", 0);

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
This function is available for an agent callout to write output to the agent's
CGIplus input mailbox.  It may be called one or more times from a single
callout (the only thing to be mindful of is BYTLM and the capacity of the
CGIPLUSIN mailbox.
*/ 

DclCalloutQio
(
struct RequestStruct *rqptr,
char *DataPtr,
int DataLength
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "DclCalloutQio() %d %d %d |%s|\n",
               rqptr, rqptr->DclTaskPtr, DataLength, DataPtr);

   if (rqptr->DclTaskPtr == NULL)
      ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);

   DclQioCgiPlusIn (rqptr->DclTaskPtr, DataPtr, DataLength);
}

/*****************************************************************************/
/*
Default callout for CGIplus scripting.  In other words; ask the the server to
do something for a CGIplus script.  See prologue to this module for description
of currently support functionality.
*/ 

DclCalloutDefault (struct RequestStruct *rqptr)

{
   static char  ResponseBadParam [] = "400 Bad parameter",
                ResponseUnauthorized [] = "401 Unauthorized",
                ResponseForbidden [] = "403 Forbidden",
                ResponseSuccess [] = "200 Success",
                ResponseUnknown [] = "400 Unknown request";

   boolean  ProvideResponse;
   int  status,
        Number;
   char  *cptr, 
         *FileNamePtr,
         *OutputPtr;
   char  Scratch [1024+4];
   struct DclTaskStruct  *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "DclCalloutDefault() %d |%s|\n",
               rqptr->rqCgi.CalloutOutputCount,
               rqptr->rqCgi.CalloutOutputPtr);

   /* get a local pointer to the DCL task structure */
   tkptr = rqptr->DclTaskPtr;

   if ((OutputPtr = rqptr->rqCgi.CalloutOutputPtr) == NULL &&
       (rqptr->rqCgi.CalloutOutputCount == 0 ||
        rqptr->rqCgi.CalloutOutputCount == -1))
   {
      /* indicates the script has sent a begin or end escape sequence */
      return;
   }

   if (OutputPtr[0] == '!' || OutputPtr[0] == '#')
   {
      ProvideResponse = false;
      OutputPtr++;
   }
   else
      ProvideResponse = true;

   if (toupper(OutputPtr[0]) == 'A' &&
       strsame (OutputPtr, "AUTH-FILE:", 10))
   {
      /* authorize access to a particular file */
      for (cptr = OutputPtr+10; *cptr && isspace(*cptr); cptr++);
      if (!*cptr)
      {
         if (ProvideResponse)
            DclCalloutQio (rqptr, ResponseBadParam, sizeof(ResponseBadParam)-1);
         return;
      }
      FileNamePtr = cptr;
      while (*cptr && !isspace(*cptr)) cptr++;
      if (rqptr->rqAuth.VmsUserProfileLength)
      {
         status = AuthVmsCheckUserAccess (rqptr, FileNamePtr, cptr-FileNamePtr);
         if (ProvideResponse)
         {
            if (status == RMS$_PRV)
               DclCalloutQio (rqptr, ResponseForbidden,
                              sizeof(ResponseForbidden)-1);
            else
            if (VMSok (status))
               DclCalloutQio (rqptr, ResponseSuccess, sizeof(ResponseSuccess)-1);
            else
            {
               /* error reported by access check */
               WriteFao (Scratch, sizeof(Scratch), NULL, "400 %!%M", status);
               DclCalloutQio (rqptr, Scratch, strlen(Scratch));
            }
         }
      }
      else
      if (ProvideResponse)
      {
         /* i.e. request does not have a VMS profile associated */
         DclCalloutQio (rqptr, ResponseUnauthorized,
                        sizeof(ResponseUnauthorized)-1);
      }
      return;
   }

   if (toupper(OutputPtr[0]) == 'C' &&
       strsame (OutputPtr, "CLIENT-READ:", 12))
   {
      tkptr->ClientReadStripCrLf = false;
      for (cptr = OutputPtr+12; *cptr && isspace(*cptr); cptr++);
      while (*cptr)
      {
         while (*cptr && (isspace(*cptr) || *cptr == ';')) cptr++;
         if (!*cptr) break;
         if (strsame (cptr, "STRIPCRLF", 9))
         {
            tkptr->ClientReadStripCrLf = true;
            cptr += 9;
         }
         else
         {
            if (ProvideResponse)
               DclCalloutQio (rqptr, ResponseBadParam,
                              sizeof(ResponseBadParam)-1);
            return;
         }
      }

      /* first cancel the normal end-of-request-body EOF on the channel */
      sys$cancel (tkptr->HttpInputChannel);

      /* allocate some storage for buffering this I/O */
      tkptr->ClientReadBufferPtr =
         VmGetHeap (rqptr, tkptr->ClientReadBufferSize = NetReadBufferSize);

      /* queue the first read from the client */
      NetRead (rqptr, &DclClientReadAst,
               tkptr->ClientReadBufferPtr, tkptr->ClientReadBufferSize);
      tkptr->QueuedClientRead++;

      if (ProvideResponse)
         DclCalloutQio (rqptr, ResponseSuccess, sizeof(ResponseSuccess)-1);

      return;
   }

   if (Config.cfScript.GatewayBg)
   {
      if (toupper(OutputPtr[0]) == 'G' &&
          strsame (OutputPtr, "GATEWAY-BEGIN:", 14))
      {
         /* HTTP status code of response directly to the BG (socket) device */
         for (cptr = OutputPtr+14; *cptr && isspace(*cptr); cptr++);
         if (isdigit(*cptr))
         {
            Number = atoi(cptr);
            rqptr->rqResponse.HttpStatus = Number;
            if (ProvideResponse)
               DclCalloutQio (rqptr, ResponseSuccess,
                              sizeof(ResponseSuccess)-1);
         }               
         else
         if (ProvideResponse)
            DclCalloutQio (rqptr, ResponseBadParam,
                           sizeof(ResponseBadParam)-1);
         return;
      }
      else
      if (toupper(OutputPtr[0]) == 'G' &&
          strsame (OutputPtr, "GATEWAY-END:", 12))
      {
         /* count of bytes output directly to the BG (socket) device */
         for (cptr = OutputPtr+12; *cptr && isspace(*cptr); cptr++);
         if (isdigit(*cptr))
         {
            Number = atoi(cptr);
            rqptr->BytesRawTx += Number;
            if (ProvideResponse)
               DclCalloutQio (rqptr, ResponseSuccess,
                              sizeof(ResponseSuccess)-1);
         }               
         else
         if (ProvideResponse)
            DclCalloutQio (rqptr, ResponseBadParam,
                           sizeof(ResponseBadParam)-1);
         return;
      }
   }

   if (toupper(OutputPtr[0]) == 'L' &&
       strsame (OutputPtr, "LIFETIME:", 9))
   {
      /* let a CGIplus script set/reset its own lifetime */
      for (cptr = OutputPtr+9; *cptr && isspace(*cptr); cptr++);
      if (isdigit(*cptr))
      {
         if (strsame (cptr, "none", 4))
            Number = -1;
         else
         if (!(Number = atoi(cptr) * 60))
         {
            if (tkptr->TaskType == DCL_TASK_TYPE_CGI_SCRIPT)
               Number = Config.cfScript.ZombieLifeTime+1;
            else
               Number = Config.cfScript.CgiPlusLifeTime+1;
         }
         tkptr->LifeTimeCount = Number;
         if (ProvideResponse)
            DclCalloutQio (rqptr, ResponseSuccess, sizeof(ResponseSuccess)-1);
      }               
      else
      if (ProvideResponse)
         DclCalloutQio (rqptr, ResponseBadParam, sizeof(ResponseBadParam)-1);
      return;
   }

   if (toupper(OutputPtr[0]) == 'M' &&
       strsame (OutputPtr, "MAP-FILE:", 9))
   {
      Scratch[4] = '\0';
      for (cptr = OutputPtr+9; *cptr && isspace(*cptr); cptr++);
      if (!*cptr)
      {
         if (ProvideResponse)
            DclCalloutQio (rqptr, ResponseBadParam, sizeof(ResponseBadParam)-1);
         return;
      }
      cptr = MapUrl_Map (Scratch+4, sizeof(Scratch)-4, cptr, 0,
                         NULL, 0, NULL, 0, NULL, 0, NULL, rqptr);
      if (!cptr[0] && cptr[1])
      {
         memcpy (Scratch, "400 ", 4);
         strcpy (Scratch+4, cptr+1);
         if (ProvideResponse)
            DclCalloutQio (rqptr, Scratch, strlen(Scratch));
      }
      else
      {
         memcpy (Scratch, "200 ", 4);
         if (ProvideResponse)
            DclCalloutQio (rqptr, Scratch, strlen(Scratch));
      }
      return;
   }

   if (toupper(OutputPtr[0]) == 'M' &&
       strsame (OutputPtr, "MAP-PATH:", 9))
   {
      Scratch[4] = '\0';
      for (cptr = OutputPtr+9; *cptr && isspace(*cptr); cptr++);
      if (!*cptr)
      {
         if (ProvideResponse)
            DclCalloutQio (rqptr, ResponseBadParam, sizeof(ResponseBadParam)-1);
         return;
      }
      cptr = MapUrl_Map (cptr, 0, Scratch+4, sizeof(Scratch)-4,
                         NULL, 0, NULL, 0, NULL, 0, NULL, rqptr);
      if (!cptr[0] && cptr[1])
      {
         memcpy (Scratch, "400 ", 4);
         strcpy (Scratch+4, cptr+1);
         if (ProvideResponse)
            DclCalloutQio (rqptr, Scratch, strlen(Scratch));
      }
      else
      {
         memcpy (Scratch, "200 ", 4);
         if (ProvideResponse)
            DclCalloutQio (rqptr, Scratch, strlen(Scratch));
      }
      return;
   }

   if (toupper(OutputPtr[0]) == 'N' &&
       strsame (OutputPtr, "NOOP:", 5))
   {
      /* could be used for WATCHable debugging information, comments, etc. */
      if (ProvideResponse)
         DclCalloutQio (rqptr, ResponseSuccess, sizeof(ResponseSuccess)-1);
      return;
   }

   if (toupper(OutputPtr[0]) == 'T' &&
       strsame (OutputPtr, "TIMEOUT-NOPROGRESS:", 19))
   {
      /* let a script set/reset it's own per-request no-progress timeout */
      for (cptr = OutputPtr+19; *cptr && isspace(*cptr); cptr++);
      if (isdigit(*cptr))
      {
         if (strsame (cptr, "none", 4))
            Number = -1;
         else
            Number = atoi(cptr);
         HttpdTimerSet (rqptr, TIMER_NOPROGRESS, Number);
         if (ProvideResponse)
            DclCalloutQio (rqptr, ResponseSuccess, sizeof(ResponseSuccess)-1);
      }               
      else
      if (ProvideResponse)
         DclCalloutQio (rqptr, ResponseBadParam, sizeof(ResponseBadParam)-1);
      return;
   }

   if (toupper(OutputPtr[0]) == 'T' &&
       strsame (OutputPtr, "TIMEOUT-OUTPUT:", 15))
   {
      /* let a script set/reset its own per-request output timeout */
      for (cptr = OutputPtr+15; *cptr && isspace(*cptr); cptr++);
      if (isdigit(*cptr))
      {
         if (strsame (cptr, "none", 4))
            Number = -1;
         else
            Number = atoi(cptr);
         HttpdTimerSet (rqptr, TIMER_OUTPUT, Number);
         if (ProvideResponse)
            DclCalloutQio (rqptr, ResponseSuccess, sizeof(ResponseSuccess)-1);
      }               
      else
         if (ProvideResponse)
            DclCalloutQio (rqptr, ResponseBadParam, sizeof(ResponseBadParam)-1);
      return;
   }

   if (ProvideResponse)
      DclCalloutQio (rqptr, ResponseUnknown, sizeof(ResponseUnknown)-1);
}

/*****************************************************************************/
/*
Every minute scan the list of DCL script processes looking for those whose
lifetimes have expired. Run those script processes down! As this is a one
minute tick set the lifetime counters to configuration plus one to ensure at
least that number of minutes before expiry.  A lifetime count of -1 indicates
the script process has requested that it be immune to supervisor purging.
*/

DclSupervisor (boolean TimerExpired)

{
   static boolean  TimerSet = false;
   static int  CleanupCount;
   static unsigned long  OneMinuteDelta [2] = { -600000000, -1 };

   register struct ListEntryStruct  *leptr;
   register struct DclTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DclSupervisor() %d\n", TimerExpired);

   if (!TimerExpired)
   {
      /* new request, if the supervisor is already running just return */
      if (TimerSet) return;

      /* kick the supervisor timer into life, and then return */
      if (VMSnok (status =
          sys$setimr (0, &OneMinuteDelta, &DclSupervisor, true, 0)))
         ErrorExitVmsStatus (status, "sys$setimr()", FI_LI);
      TimerSet = true;
      if (DclCleanupMinutesMax) CleanupCount = DclCleanupMinutesMax;
      return;
   }

   /* must have got here via the supervisor's timer expiring */
   TimerSet = false;

   for (leptr = DclTaskList.HeadPtr; leptr != NULL; leptr = leptr->NextPtr)
   {
      tkptr = (struct DclTaskStruct*)leptr;
      if (Debug) DclTaskItemDebug (leptr, tkptr);
 
      /* let the output timer take care of those in use, ignore marked */
      if (tkptr->RequestPtr != NULL ||
          tkptr->MarkedForDelete ||
          tkptr->LifeTimeCount == -1) continue;

      if (tkptr->LifeTimeCount > 0)
      {
         if (--tkptr->LifeTimeCount)
         {
            TimerSet = true;
            continue;
         }
      }

      /* process timer has expired, exterminate ... exxterrminnaattte */
      tkptr->MarkedForDelete = true;
      DclConcludeTask (tkptr, true);
      if (tkptr->TaskType == DCL_TASK_TYPE_CGIPLUS_SCRIPT ||
          tkptr->TaskType == DCL_TASK_TYPE_RTE_SCRIPT)
         DclCgiPlusLifeTimePurgeCount++;
      else
         DclZombieLifeTimePurgeCount++;
   }

   if (DclCleanupMinutesMax && (!CleanupCount-- || !TimerSet))
   {
      /* either the cleanup timer expired or no more scripts */
      CleanupCount = DclCleanupMinutesMax;
      /* kick off an independent thread of cleanup I/O */
      SysDclAst (&DclCleanupScratch, NULL);
   }

   if (TimerSet)
   {
      /* at least one item in the connect list is still counting down */
      if (VMSnok (status =
          sys$setimr (0, &OneMinuteDelta, &DclSupervisor, true, 0)))
         ErrorExitVmsStatus (status, "sys$setimr()", FI_LI);
   }
   else
   {
      /* purge the script name cache when there are no more zombies/CGIplus */
      DclPurgeScriptNameCache ();
   }
}

/*****************************************************************************/
/*
In an independent thread of execution search the script working/scratch
directory (HTTPD$SCRATCH) checking for files that are older than the limit
(based on their RDT).  This thread is initiated by being called with a NULL as
the parameter.  This initializes the RMS structures and begins an AST-driven
search, calling this function for each search call with the search FAB as the
parameter.  Files found have the revision date/time compared to a date/time the
required number of minutes earlier than the current time.  Those exceeding that
are deleted.  File names beginning with a dollar are never deleted in this way.
*/

void DclCleanupScratch (struct FAB *FabPtr)

{
   static unsigned long  OneMinuteDelta [2] = { -600000000, -1 };

   boolean  CleanupUnderway = false;
   static int  FileCount,
               FileDeletedCount,
               FileDollarCount;
   static unsigned long  CurrentBinTime [2],
                         OlderThanBinTime [2],
                         ScratchBinTime [2];
   static struct OdsStruct  SearchOds;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DclCleanupScratch() %d\n", FabPtr);

   if (FabPtr == NULL)
   {
      if (CleanupUnderway) return;
      CleanupUnderway = true;

      FileCount = FileDeletedCount = 0;

      memcpy (&ScratchBinTime, &OneMinuteDelta, sizeof(ScratchBinTime));
      status = lib$mult_delta_time (&DclCleanupMinutesOld, &ScratchBinTime);
      if (VMSnok (status))
      {
         ErrorNoticed (status, "lib$mult_delta_time()", FI_LI);
         CleanupUnderway = false;
         return;
      }
      /* add the (negative) delta to the current getting an earlier time */
      sys$gettim (&CurrentBinTime);
      status = lib$sub_times (&CurrentBinTime,
                              &ScratchBinTime,
                              &OlderThanBinTime);
      if (VMSnok (status))
      {
         ErrorNoticed (status, "lib$add_times()", FI_LI);
         CleanupUnderway = false;
         return;
      }
      if (Debug)
         WriteFaoStdout ("!20%D !20%D\n", &CurrentBinTime, &OlderThanBinTime);

      status = OdsParse (&SearchOds,
                         DCL_HTTPD_SCRATCH, sizeof(DCL_HTTPD_SCRATCH)-1,
                         "*.*;*", 5, 0, NULL, 0);
      if (VMSnok (status))
      {
         ErrorNoticed (status, "sys$parse()", FI_LI);
         CleanupUnderway = false;
         return;
      }
   }
   else
   {
      if (Debug)
         fprintf (stdout, "FAB sts: %%X%08.08X stv: %%X%08.08X\n",
                  SearchOds.Fab.fab$l_sts, SearchOds.Fab.fab$l_stv);

      if (VMSnok (status = SearchOds.Fab.fab$l_sts))
      {
         if (status == RMS$_FNF || status == RMS$_NMF)
         {
            if (FileDeletedCount)
               WriteFaoStdout (
"%!AZ-I-DCL, !20%D, cleanup !AZ, !UL files, !UL deleted ($!UL)\n",
                  Utility, 0, DCL_HTTPD_SCRATCH,
                  FileCount, FileDeletedCount, FileDollarCount);
         }
         else
            ErrorNoticed (status, "OdsSearch()", FI_LI);
         CleanupUnderway = false;
         if (SearchOds.ParseInUse) OdsParseRelease (&SearchOds);
         return;
      }

      FileCount++;
      if (SearchOds.NamNamePtr[0] == '$')
         FileDollarCount++;
      else
      {
         status = OdsFileAcpInfo (&SearchOds, NULL, 0); 
         if (VMSnok (status))
         {
            ErrorNoticed (status, "OdsFileAcpInfo()", FI_LI);
            CleanupUnderway = false;
            if (SearchOds.ParseInUse) OdsParseRelease (&SearchOds);
            return;
         }
         if (Debug)
            WriteFaoStdout ("!20%D !20%D\n",
                            &SearchOds.AcpInfo.RdtBinTime, &OlderThanBinTime);
         /* if a negative time the file is older than the specified period */
         status = lib$sub_times (&SearchOds.AcpInfo.RdtBinTime,
                                 &OlderThanBinTime,
                                 &ScratchBinTime);
         if (Debug) fprintf (stdout, "sys$sub_times() %%X%08.08X\n", status);
         if (status == LIB$_NEGTIM)
         {
            /* use SYSPRV to ensure the file is deleted */
            EnableSysPrv();
            SearchOds.Fab.fab$l_fop = FAB$M_NAM;
            status = sys$erase (&SearchOds.Fab, 0, 0);
            if (Debug) fprintf (stdout, "sys$erase() %%X%08.08X\n", status);
            DisableSysPrv();
            if (VMSok (status)) FileDeletedCount++;
         }
         else
         if (VMSnok (status))
         {
            ErrorNoticed (status, "lib$sub_times()", FI_LI);
            CleanupUnderway = false;
            if (SearchOds.ParseInUse) OdsParseRelease (&SearchOds);
            return;
         }
      }
   }

   OdsSearch (&SearchOds, &DclCleanupScratch, NULL);
}

/*****************************************************************************/
/*
Scan all detached processes on the system looking for those with a mailbox
'terminal' with the server's 'special' identifier in an ACL.  Delete these
processes. This function is called to clean-up detached script processes that
may have been left on the system if a server is sys$delprc()ed in some way
(e.g. STOP/ID=).  Normally the image exit handler will delete these during
user-mode image rundown.  This function obviously must be called during server
startup prior to actually beginning to process requests.
*/

#define PSCAN$_GETJPI_BUFFER_SIZE 24
#define PSCAN$_TERMINAL 21 
#define PSCAN$M_PREFIX_MATCH 0x80
#define PSCAN$M_EQL 0x400

DclCleanupScriptProcesses ()

{
   static unsigned long  GetJpiControlFlags = JPI$M_IGNORE_TARGET_STATUS;
   static unsigned long  MailboxMask [2] = { PRV$M_WORLD | PRV$M_SYSPRV, 0 };

   static unsigned long  JpiPid;
   static char  JpiPrcNam [16],
                JpiTerminal [9],
                JpiUserName [13];

   static struct
   {
      unsigned short  buf_len;
      unsigned short  item;
      unsigned char   *buf_addr;
      unsigned short  *short_ret_len;
   }
      JpiItems [] =
   {
      { sizeof(GetJpiControlFlags), JPI$_GETJPI_CONTROL_FLAGS,
        &GetJpiControlFlags, 0 },
      { sizeof(JpiPid), JPI$_PID, &JpiPid, 0 },
      { sizeof(JpiPrcNam), JPI$_PRCNAM, &JpiPrcNam, 0 },
      { sizeof(JpiUserName), JPI$_USERNAME, &JpiUserName, 0 },
      { sizeof(JpiTerminal), JPI$_TERMINAL, &JpiTerminal, 0 },
      { 0,0,0,0 }
   },
      ScanItems [] =
   {
      { 3, PSCAN$_TERMINAL, "MBA", PSCAN$M_PREFIX_MATCH },
      { 0, PSCAN$_GETJPI_BUFFER_SIZE, 2048, 0 },
      { 0,0,0,0 }
   };

   int  status,
        Context,
        ProcessCount,
        SetPrvStatus;
   unsigned long  ProcessContext;
   char  *cptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DclCleanupScriptProcesses()\n");

   ProcessContext = 0;
   status = sys$process_scan (&ProcessContext, &ScanItems);
   if (Debug) fprintf (stdout, "sys$process_scan() %%X%08.08X\n", status);
   if (VMSnok (status))
   {
      ErrorNoticed (status, "sys$process_scan()", FI_LI);
      return;
   }

   /* enable WORLD so we can access at *all* processes */
   if (VMSnok (SetPrvStatus = sys$setprv (1, &MailboxMask, 0, 0)))
      ErrorExitVmsStatus (SetPrvStatus, "sys$setprv()", FI_LI);

   ProcessCount = 0;
   for (;;)
   {
      status = sys$getjpiw (0, &ProcessContext, 0, &JpiItems, 0, 0, 0);
      if (Debug) fprintf (stdout, "sys$getjpiw() %%X%08.08X\n", status);
      if (VMSnok (status)) break;

      ProcessCount++;

      if (Debug) fprintf (stdout, "JpiTerminal |%s|\n", JpiTerminal);

      JpiUserName[12] = '\0';
      for (cptr = JpiUserName; *cptr && *cptr != ' '; cptr++);
      *cptr = '\0';
      if (Debug) fprintf (stdout, "JpiUserName |%s|\n", JpiUserName);

      JpiPrcNam[15] = '\0';
      for (cptr = JpiPrcNam; *cptr && *cptr != ' '; cptr++);
      *cptr = '\0';
      if (Debug) fprintf (stdout, "JpiPrcNam |%s|\n", JpiPrcNam);

      status = DclMailboxAcl (JpiTerminal, NULL);
      if (Debug) fprintf (stdout, "DclMailBoxAcl() %%X%08.08X\n", status);
      /* the STS$K_ERROR indicates the 'terminal' ACE was not detected */
      if (status == STS$K_ERROR) continue;
      if (VMSnok (status))
      {
         ErrorNoticed (status, "DclMailboxAcl()", FI_LI);
         continue;
      }

      WriteFaoStdout (
"%!AZ-I-DCL, cleanup detached script process; !8XL !AZ \'!AZ\'\n",
         Utility, JpiPid, JpiUserName, JpiPrcNam);
      status = sys$delprc (&JpiPid, 0);
      if (VMSnok (status)) ErrorNoticed (status, "sys$delprc()", FI_LI); 
   }

   if (VMSnok (SetPrvStatus = sys$setprv (0, &MailboxMask, 0, 0)))
      ErrorExitVmsStatus (SetPrvStatus, "sys$setprv()", FI_LI);

   if (status != SS$_NOMOREPROC)
   {
      ErrorNoticed (status, "sys$getjpiw()", FI_LI);
      return;
   }
}

/*****************************************************************************/
/*
Create an ACL comprising two ACEs and apply it to the specified mailbox device.
The first ACE is a special 'HTTPd...' one, used to distinguish between those
mailboxes and the associated processes created by the server from any other
process with a mailbox 'terminal' (used during DclCleanupScriptProcesses()). 
The second allows read and write access to the 'AllowName' identifier. 
Function must be initialized by calling with 'MailboxName' NULL.  If called
with 'AllowName' NULL the mailbox ACL is read and checked for the special
'HTTPd...' identifying ACE.
*/

#define OSS$M_RELCTX 0x2
#define OSS$_ACL_ADD_ENTRY 3
#define OSS$_ACL_POSITION_TOP 14
#define OSS$_ACL_READ_ENTRY 16
#define PSL$C_USER 3

int DclMailboxAcl
(
char *MailboxName,
char *AllowName
)
{
   static $DESCRIPTOR (AclHttpdFaoDsc, "(IDENT=!AZ,ACCESS=NONE)");
   static $DESCRIPTOR (AclAllowFaoDsc, "(IDENT=!AZ,ACCESS=R+W+E+D)");
   static $DESCRIPTOR (ClassNameDsc, "DEVICE");
   static $DESCRIPTOR (ProcessIdentNameDsc, "");

   static unsigned long  AccessMode = PSL$C_USER,
                         ProcessRightsIdent,
                         SecFlags = OSS$M_RELCTX;
   static unsigned short  Length;
   static unsigned char  AclAllowEntry [32],
                         AclHttpdEntry [32],
                         AclReadEntry [32];
   static char  AclString [64],
                PrevAllowName [32];
   static $DESCRIPTOR (AclAllowEntryDsc, AclAllowEntry);
   static $DESCRIPTOR (AclHttpdEntryDsc, AclHttpdEntry);
   static $DESCRIPTOR (AclStringDsc, AclString);
   static $DESCRIPTOR (MailboxNameDsc, "");
   static struct {
      unsigned short  buf_len;
      unsigned short  item;
      unsigned char   *buf_addr;
      unsigned long  *long_ret_len;
   }
   SetSecItems [] =
   {
      { 0, OSS$_ACL_ADD_ENTRY, AclHttpdEntry, 0 },
      { 0, OSS$_ACL_ADD_ENTRY, AclAllowEntry, 0 },
      {0,0,0,0}
   },
   GetSecItems [] =
   {
      { 0, OSS$_ACL_POSITION_TOP, 0, 0 },
      { sizeof(AclReadEntry), OSS$_ACL_READ_ENTRY, AclReadEntry, &Length },
      {0,0,0,0}
   };

   int  status;
   unsigned long  Context;
   unsigned short  ErrorPos;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "DclMailboxAcl() |%s|%s|%s|\n",
               MailboxName, AllowName, PrevAllowName);

   if (MailboxName == NULL)
   {
      /**************/
      /* initialize */
      /**************/

      /* create the identifier if it does not already exist */
      ProcessIdentNameDsc.dsc$a_pointer = ProcessIdentName;
      ProcessIdentNameDsc.dsc$w_length = strlen(ProcessIdentName);
      status = sys$asctoid (&ProcessIdentNameDsc, &ProcessRightsIdent, 0);
      if (Debug) fprintf (stdout, "sys$asctoid() %%X%08.08X\n", status);
      if (VMSnok (status))
      {
         /* use SYSPRV to allow access to the rights database */
         EnableSysPrv();
         status = sys$add_ident (&ProcessIdentNameDsc, 0, 0,
                                 &ProcessRightsIdent);
         if (Debug) fprintf (stdout, "sys$add_ident() %%X%08.08X\n", status);
         DisableSysPrv();
         if (VMSok (status))
            WriteFaoStdout (
"%!AZ-I-RDBADDMSG, identifier !AZ value %X!8XL added to rights database\n",
               Utility, ProcessIdentName, ProcessRightsIdent);
         else
            WriteFaoStdout (
"%!AZ-W-RDBADDERRU, unable to add !AZ to rights database\n-!%M\n",
               Utility, ProcessIdentName, status);
      }

      status = sys$fao (&AclHttpdFaoDsc, &Length, &AclStringDsc,
                        ProcessIdentName);
      if (VMSnok (status)) return (status);
      AclString[Length] = '\0';
      if (Debug) fprintf (stdout, "AclString |%s|\n", AclString);

      /* parse the ACE */
      AclStringDsc.dsc$a_pointer = AclString;
      AclStringDsc.dsc$w_length = strlen(AclString);
      status = sys$parse_acl (&AclStringDsc, &AclHttpdEntryDsc,
                              &ErrorPos, 0, 0);
      AclStringDsc.dsc$w_length = sizeof(AclString)-1;

      return (status);
   }

   MailboxNameDsc.dsc$a_pointer = MailboxName;
   MailboxNameDsc.dsc$w_length = strlen(MailboxName);

   if (AllowName == NULL)
   {
      /**********************/
      /* detect cleanup ACE */
      /**********************/

      Context = 0;
      status = sys$get_security (&ClassNameDsc, &MailboxNameDsc, 0, SecFlags,
                                 &GetSecItems, &Context, &AccessMode);
      if (Debug)
         fprintf (stdout, "sys$get_security() %%X%08.08X %d %d\n",
                  status, AclReadEntry[0], AclHttpdEntry[0]); 
      /* the STS$K_ERROR indicates the cleanup ACE was not detected */
      if (status == SS$_ACLEMPTY) return (STS$K_ERROR);
      if (VMSnok (status)) return (status);
      if (AclReadEntry[0] != AclHttpdEntry[0]) return (STS$K_ERROR);
      if (memcmp (AclReadEntry, AclHttpdEntry, AclHttpdEntry[0]))
         return (STS$K_ERROR);
      return (SS$_NORMAL);
   }

   if (strcmp (AllowName, PrevAllowName))
   {
      /****************************************/
      /* first/different name to allow access */
      /****************************************/

      status = sys$fao (&AclAllowFaoDsc, &Length, &AclStringDsc, AllowName);
      if (VMSnok (status)) return (status);
      AclString[Length] = '\0';
      if (Debug) fprintf (stdout, "AclString |%s|\n", AclString);

      /* parse the ACE */
      AclStringDsc.dsc$a_pointer = AclString;
      AclStringDsc.dsc$w_length = strlen(AclString);
      status = sys$parse_acl (&AclStringDsc, &AclAllowEntryDsc,
                              &ErrorPos, 0, 0);
      if (Debug) fprintf (stdout, "sys$parse_acl() %%X%08.08X\n", status);
      AclStringDsc.dsc$w_length = sizeof(AclString)-1;
      if (VMSnok (status)) return (status);

      strncpy (PrevAllowName, AllowName, sizeof(PrevAllowName));
      PrevAllowName[sizeof(PrevAllowName)-1] = '\0';
   }

   /***************************************/
   /* apply the ACL to the mailbox device */
   /***************************************/

   SetSecItems[0].buf_len = AclHttpdEntry[0];
   SetSecItems[1].buf_len = AclAllowEntry[0];
   Context = 0;
   status = sys$set_security (&ClassNameDsc, &MailboxNameDsc, 0, SecFlags,
                              &SetSecItems, &Context, &AccessMode);
   return (status);
}

/*****************************************************************************/
/*
************
*** NOTE ***  This function takes a pointer to a request!!!
************  Due to it being a general report processing function.

Return a report on the DCL task structure.  This function blocks while
executing.
*/ 

DclScriptingReport
(
struct RequestStruct *rqptr,
void *NextTaskFunction
)
{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... CGI/DCL Scripting</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>!AZ CGI/DCL Scripting</H3>\n\
!20%W\n\
\
<P><TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0>\n\
<TR><TD VALIGN=top>\n\
\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Statistics</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TH ALIGN=right>CGI:</TH><TD ALIGN=left>!UL</TD></TR>\n\
<TH ALIGN=right>CGIplus:</TH>\
<TD ALIGN=left>!UL / !UL &nbsp;<I>(all/reused)</I></TD></TR>\n\
<TH ALIGN=right>RTE:</TH>\
<TD ALIGN=left>!UL / !UL &nbsp;<I>(all/reused)</I></TD></TR>\n\
<TH ALIGN=right>Autoscripted:</TH><TD ALIGN=left>!UL</TD></TR>\n\
<TH ALIGN=right>CLI:</TH><TD ALIGN=left>!UL</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
</TD><TD>&nbsp;&nbsp;&nbsp;&nbsp;</TD><TD VALIGN=top>\n\
\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Script Processes</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TH ALIGN=right COLSPAN=2>Current:</TH><TD ALIGN=left>!UL</TD></TR>\n\
<TH ALIGN=right COLSPAN=2>Created:</TH><TD ALIGN=left>!UL</TD></TR>\n\
<TH ALIGN=right COLSPAN=2>Subprocess:</TH><TD ALIGN=left>!UL</TD></TR>\n\
<TH ALIGN=right COLSPAN=2>Detached:</TH><TD ALIGN=left>!UL</TD></TR>\n\
<TH ALIGN=right COLSPAN=2>Persona:</TH><TD ALIGN=left>!UL</TD></TR>\n\
<TH ALIGN=left><U>Soft-Limit</U></TH>\
<TH ALIGN=right>Value:</TH><TD ALIGN=left>!UL</TD></TR>\n\
<TH ALIGN=right COLSPAN=2>Purged-at:</TH><TD ALIGN=left>!UL</TD></TR>\n\
<TH ALIGN=left><U>Hard-Limit</U></TH>\
<TH ALIGN=right>Value:</TH><TD ALIGN=left>!UL</TD></TR>\n\
<TH ALIGN=right COLSPAN=2>Purged-at:</TH><TD ALIGN=left>!UL</TD></TR>\n\
<TH ALIGN=left><U>Purged</U></TH>\
<TH ALIGN=right>Soft-Limit:</TH><TD ALIGN=left>!UL</TD></TR>\n\
<TH ALIGN=right COLSPAN=2>Explicit:</TH><TD ALIGN=left>!UL</TD></TR>\n\
<TH ALIGN=left><U>Zombie</U></TH>\
<TH ALIGN=right>Lifetime:</TH><TD ALIGN=left>!%%</TD></TR>\n\
<TH ALIGN=right COLSPAN=2>Purged-at:</TH><TD ALIGN=left>!UL</TD></TR>\n\
<TH ALIGN=left><U>CGIplus</U></TH>\
<TH ALIGN=right>Lifetime:</TH><TD ALIGN=left>!%%</TD></TR>\n\
<TH ALIGN=right COLSPAN=2>Purged-at:</TH><TD ALIGN=left>!UL</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH COLSPAN=9>DCL Task List</TH></TR>\n\
<TR><TH></TH><TH>Script/DCL</TH><TH>PID</TH><TH>User</TH><TH>Lifetime</TH>\
<TH>Zombie</TH><TH>CGIplus</TH><TH>RTE</TH>\
<TH>Total</TH><TH>Last</TH></TR>\n\
<TR><TH></TH><TH COLSPAN=1>Client</TH><TH COLSPAN=8>Request</TH></TR>\n\
<TR><TH COLSPAN=9></TH></TR>\n";

   static char  TaskFao [] =
"<TR><TD ALIGN=right>!UL</TD>\
<TD ALIGN=left>!AZ</TD><TD>!%%</TD>\
<TD ALIGN=left>!AZ</TD>\
<TD ALIGN=right>!AZ!UL!AZ</TD>\
<TD ALIGN=right>!%%</TD>\
<TD ALIGN=right>!%%</TD>\
<TD ALIGN=right>!%%</TD>\
<TD ALIGN=right>!UL</TD>\
<TD><FONT SIZE=-2>!23%W</FONT></TD></TR>\n\
!%%";

   static char  ScriptNameCacheFao [] =
"</TABLE>\n\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH COLSPAN=6>Script Name Cache</TH></TR>\n\
<TR><TH></TH><TH>Mapped File</TH><TH>File Name</TH>\
<TH>Hits</TH><TH>Last</TH></TR>\n\
<TR><TH COLSPAN=4></TH></TR>\n";

   static char  NameCacheFao [] =
"<TR><TD ALIGN=right>!UL</TD><TD ALIGN=left><TT>!AZ</TT></TD>\
<TD ALIGN=left><TT>!AZ</TT></TD>\
<TD ALIGN=right>!UL</TD>\
<TD ALIGN=left><FONT SIZE=-2>!23%W</FONT></TD></TR>\n";

   static char  PersonaCacheFao [] =
"</TABLE>\n\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH COLSPAN=5>Persona Cache &nbsp;&nbsp;\
<FONT SIZE=-1>(maximum !UL)</FONT></TH></TR>\n\
<TR><TH></TH><TH>User</TH><TH>Hits</TH><TH>Last</TH><TH>Reuse</TH></TR>\n\
<TR><TH COLSPAN=5></TH></TR>\n";

   static char  PersonaEntryFao [] =
"<TR><TD ALIGN=right>!UL</TD><TD ALIGN=left>!AZ</TD>\
<TD ALIGN=right>!UL</TD><TD ALIGN=left><FONT SIZE=-2>!23%W</FONT></TD>\
<TD ALIGN=right>!UL</DT></TR>\n";

   static char  ButtonsFao [] =
"</TABLE>\n\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TD>\n\
<FORM METHOD=GET ACTION=\"!AZ\">\n\
<INPUT TYPE=submit VALUE=\" Purge \">\n\
</FORM>\n\
</TD><TD>&nbsp;</TD><TD>\n\
<FORM METHOD=GET ACTION=\"!AZ\">\n\
<INPUT TYPE=submit VALUE=\" Force Delete \">\n\
</FORM>\n\
</TD></TR>\n\
</TABLE>\n\
</BODY>\n\
</HTML>\n";

   int  status,
        Count;
   unsigned long  FaoVector [64];
   unsigned long  *vecptr;
   struct DclScriptNameCacheStruct  *captr;
   struct DclTaskStruct  *tkptr;
   struct ListEntryStruct  *leptr;
   struct PersonaCacheStruct  *pcptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DclScriptingReport()\n");

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;

   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   if (DclScriptDetachProcess)
     *vecptr++ = "Detached Process";
   else
     *vecptr++ = "Subprocess";
   *vecptr++ = &rqptr->rqTime.Vms64bit;

   *vecptr++ = Accounting.DoScriptCount;
   *vecptr++ = Accounting.DoCgiPlusScriptCount;
   *vecptr++ = Accounting.DclCgiPlusReusedCount;
   *vecptr++ = Accounting.DoRteScriptCount;
   *vecptr++ = Accounting.DclRteReusedCount;
   *vecptr++ = Accounting.DoAutoScriptCount;
   *vecptr++ = Accounting.DoDclCommandCount;

   *vecptr++ = DclScriptProcessCount;
   *vecptr++ = Accounting.DclCrePrcCount;
   *vecptr++ = Accounting.DclCrePrcSubprocessCount;
   *vecptr++ = Accounting.DclCrePrcDetachCount;
   *vecptr++ = Accounting.DclCrePrcPersonaCount;
   *vecptr++ = DclScriptProcessSoftLimit;
   *vecptr++ = DclSoftLimitPurgeCount;
   *vecptr++ = DclScriptProcessHardLimit;
   *vecptr++ = DclHitHardLimitCount;
   *vecptr++ = DclPurgeCount;
   *vecptr++ = DclPurgeScriptProcessesCount;
   if (DclUseZombies && Config.cfScript.ZombieLifeTime)
   {
      *vecptr++ = "!UL";
      *vecptr++ = Config.cfScript.ZombieLifeTime;
   }
   else
      *vecptr++ = "[disabled]";
   *vecptr++ = DclZombieLifeTimePurgeCount;
   if (Config.cfScript.CgiPlusLifeTime)
   {
      *vecptr++ = "!UL";
      *vecptr++ = Config.cfScript.CgiPlusLifeTime;
   }
   else
      *vecptr++ = "<I>none</I>";
   *vecptr++ = DclCgiPlusLifeTimePurgeCount;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /* task list entries */
   Count = 0;
   for (leptr = DclTaskList.HeadPtr; leptr != NULL; leptr = leptr->NextPtr)
   {
      tkptr = (struct DclTaskStruct*)leptr;

      vecptr = FaoVector;

      *vecptr++ = ++Count;

      if (tkptr->TaskType == DCL_TASK_TYPE_CLI)
         *vecptr++ = tkptr->DclCommand;
      else
         *vecptr++ = tkptr->ScriptName;

      if (tkptr->ScriptProcessPid)
      {
         *vecptr++ = "<A HREF=\"!AZ?pid=!8XL!%%\"><TT>!8XL</TT></A>";
         *vecptr++ = ADMIN_REPORT_SHOW_PROCESS;
         *vecptr++ = tkptr->ScriptProcessPid;
         if (DclPersonaServicesAvailable)
         {
            *vecptr++ = "&puser=!AZ";
            *vecptr++ = tkptr->CrePrcUserName;
         }
         else
            *vecptr++ = "";
         *vecptr++ = tkptr->ScriptProcessPid;
      }
      else
         *vecptr++ = "";

      *vecptr++ = tkptr->CrePrcUserName;

      if (tkptr->LifeTimeCount)
         *vecptr++ = "<B>";
      else
         *vecptr++ = "";
      /* fudge allows for correct reporting of lifetime */
      if (((tkptr->TaskType == DCL_TASK_TYPE_CGIPLUS_SCRIPT ||
            tkptr->TaskType == DCL_TASK_TYPE_RTE_SCRIPT) &&
           tkptr->LifeTimeCount == Config.cfScript.CgiPlusLifeTime+1) ||
          (tkptr->TaskType != DCL_TASK_TYPE_CGIPLUS_SCRIPT &&
           tkptr->TaskType != DCL_TASK_TYPE_RTE_SCRIPT &&
           tkptr->LifeTimeCount == Config.cfScript.ZombieLifeTime+1))
         *vecptr++ = tkptr->LifeTimeCount-1;
      else
         *vecptr++ = tkptr->LifeTimeCount;
      if (tkptr->LifeTimeCount)
         *vecptr++ = "</B>";
      else
         *vecptr++ = "";

      if (tkptr->ZombieCount)
      {
         *vecptr++ = "!UL";
         *vecptr++ = tkptr->ZombieCount;
      }
      else
         *vecptr++ = "";

      if (tkptr->TaskType == DCL_TASK_TYPE_CGIPLUS_SCRIPT)
      {
         *vecptr++ = "!UL";
         *vecptr++ = tkptr->CgiPlusUsageCount;
      }
      else
         *vecptr++ = "";

      if (tkptr->TaskType == DCL_TASK_TYPE_RTE_SCRIPT)
      {
         *vecptr++ = "!UL";
         *vecptr++ = tkptr->CgiPlusUsageCount;
      }
      else
         *vecptr++ = "";

      *vecptr++ = tkptr->TotalUsageCount;
      *vecptr++ = &tkptr->LastUsedBinaryTime;

      if (tkptr->RequestPtr != NULL)
      {
         *vecptr++ =
"<TR><TD></TD><TD ALIGN=left COLSPAN=1>!%%!AZ</TD>\
<TD ALIGN=left COLSPAN=6><TT>!HF!HF</TT></TD></TR>\n";

         if (tkptr->RequestPtr->RemoteUser[0])
         {
            *vecptr++ = "!HZ@";
            *vecptr++ = tkptr->RequestPtr->RemoteUser;
         }
         else
            *vecptr++ = "";
         *vecptr++ = tkptr->RequestPtr->rqNet.ClientHostName;
         *vecptr++ = tkptr->RequestPtr->ScriptName;
         *vecptr++ = tkptr->RequestPtr->rqHeader.PathInfoPtr;
      }
      else
         *vecptr++ = "";

      status = NetWriteFaol (rqptr, TaskFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   /* script name cache entries */
   status = NetWriteFaol (rqptr, ScriptNameCacheFao, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   Count = 0;
   for (leptr = DclScriptNameCacheList.HeadPtr;
        leptr != NULL;
        leptr = leptr->NextPtr)
   {
      captr = (struct DclScriptNameCacheStruct*)leptr;

      vecptr = FaoVector;
      *vecptr++ = ++Count;
      *vecptr++ = captr->ScriptFileName;
      *vecptr++ = captr->ResFileName;
      *vecptr++ = captr->HitCount;
      *vecptr++ = &captr->LastBinaryTime;

      status = NetWriteFaol (rqptr, NameCacheFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   /* persona cache entries */
   status = NetWriteFao (rqptr, PersonaCacheFao, PersonaCacheEntries);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   Count = 0;
   for (leptr = PersonaCacheList.HeadPtr;
        leptr != NULL;
        leptr = leptr->NextPtr)
   {
      pcptr = (struct PersonaCacheStruct*)leptr;

      vecptr = FaoVector;
      *vecptr++ = ++Count;
      *vecptr++ = pcptr->UserName;
      *vecptr++ = pcptr->HitCount;
      *vecptr++ = &pcptr->LastBinaryTime;
      *vecptr++ = pcptr->ReuseCount;

      status = NetWriteFaol (rqptr, PersonaEntryFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   vecptr = FaoVector;
   *vecptr++ = ADMIN_CONTROL_DCL_PURGE;
   *vecptr++ = ADMIN_CONTROL_DCL_DELETE;

   status = NetWriteFaol (rqptr, ButtonsFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
************
*** NOTE ***  This function takes a pointer to a request!!!
************  Due to it being a general control processing function.

Control function to delete and mark-for-delete all script processes. This is a
quick and effective means for purging all zombie and CGIplus script processes
forcing the next activation to reload the (possibly new) image.  The
'WithExtremePrejudice' option deletes script processes unconditionally,
processing or not.  It can be used to clear errant scripts without restarting
the server.  Called from Admin.c module.
*/

DclPurgeScriptProcesses
(
struct RequestStruct *rqptr,
void *NextTaskFunction,
boolean WithExtremePrejudice
)
{
   register struct  ListEntryStruct  *leptr;
   register struct DclTaskStruct  *tkptr;

   int  status,
        DeletedCount,
        MarkedCount;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DclPurgeScriptProcesses()\n");

   PersonaCache (NULL, 0);

   DclPurgeScriptNameCache ();

   DclPurgeScriptProcessesCount++;

   DeletedCount = MarkedCount = 0;

   for (leptr = DclTaskList.HeadPtr; leptr != NULL; leptr = leptr->NextPtr)
   {
      tkptr = (struct DclTaskStruct*)leptr;

      if (!tkptr->ScriptProcessPid) continue;

      tkptr->MarkedForDelete = true;

      if (WithExtremePrejudice ||
          (tkptr->QueuedSysCommand <= tkptr->QueuedSysCommandAllowed &&
           !tkptr->QueuedSysOutput &&
           !tkptr->QueuedCgiPlusIn &&
           !tkptr->QueuedHttpInput &&
           !tkptr->QueuedClientRead &&
           !tkptr->FindScript &&
           tkptr->RequestPtr == NULL))
      {
         /* forced delete or script process not currently active, abort task */
         DclConcludeTask (tkptr, true);
         DeletedCount++;
      }
      else
      {
         /* script process is currently active, just leave marked for delete */
         MarkedCount++;
      }
   }

   WriteFaoStdout (
"%!AZ-I-ADMIN, !20%D, !AZ.\'!HZ\'@!AZ, purge DCL script processes\n\
!UL deleted, !UL marked for deletion\n",
      Utility, 0, rqptr->RemoteUser, rqptr->rqAuth.RealmDescrPtr,
      rqptr->rqNet.ClientHostName, DeletedCount, MarkedCount);

   if (OpcomMessages & OPCOM_ADMIN)
      WriteFaoOpcom (
"%!AZ-I-ADMIN, !AZ.\'!HZ\'@!AZ, purge DCL script processes\r\n\
!UL deleted, !UL marked for deletion",
         Utility, rqptr->RemoteUser, rqptr->rqAuth.RealmDescrPtr,
         rqptr->rqNet.ClientHostName, DeletedCount, MarkedCount);

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   ReportSuccess (rqptr,
"Server !AZ had !UL process!AZ deleted, !UL marked for delete.",
      ServerHostPort, DeletedCount, DeletedCount == 1 ? "" : "es", MarkedCount);

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Same as for DclPurgeScriptProcesses() except called from control module from
command line!
*/

char* DclControlPurgeScriptProcesses (boolean WithExtremePrejudice)

{
   static char  Response [64];
   static $DESCRIPTOR (ResponseFaoDsc, "!UL deleted, !UL marked for delete");
   static $DESCRIPTOR (ResponseDsc, Response);

   register struct  ListEntryStruct  *leptr;
   register struct DclTaskStruct  *tkptr;

   int  status,
        DeletedCount,
        MarkedCount;
   unsigned short  Length;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DclControlPurgeScriptProcesses()\n");

   PersonaCache (NULL, 0);

   DclPurgeScriptNameCache ();

   DclPurgeScriptProcessesCount++;

   DeletedCount = MarkedCount = 0;

   for (leptr = DclTaskList.HeadPtr; leptr != NULL; leptr = leptr->NextPtr)
   {
      tkptr = (struct DclTaskStruct*)leptr;

      if (!tkptr->ScriptProcessPid) continue;

      tkptr->MarkedForDelete = true;

      if (WithExtremePrejudice ||
          (tkptr->QueuedSysCommand <= tkptr->QueuedSysCommandAllowed &&
           !tkptr->QueuedSysOutput &&
           !tkptr->QueuedCgiPlusIn &&
           !tkptr->QueuedHttpInput &&
           !tkptr->QueuedClientRead &&
           !tkptr->FindScript &&
           tkptr->RequestPtr == NULL))
      {
         /* forced delete or script process not currently active, abort task */
         DclConcludeTask (tkptr, true);
         DeletedCount++;
      }
      else
      {
         /* script process is currently active, just leave marked for delete */
         MarkedCount++;
      }
   }

   sys$fao (&ResponseFaoDsc, &Length, &ResponseDsc,
            DeletedCount, MarkedCount);
   Response[Length] = '\0';

   return (Response);
}

/*****************************************************************************/
/*
A mapping rule reload is a particularly "dangerous" time for scripting as
confusion could ensure about which CGIplus script is which and which script
name in the cache is which.  Hence at a mapping rule reload purge DCL suprocess
tasks and the script name cache.
*/

DclLoadedMappingRules ()

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DclLoadedMappingRules()\n");

   DclPurgeScriptNameCache ();

   DclControlPurgeScriptProcesses (false);
}

/*****************************************************************************/
/*
*/

DclTaskItemDebug
(
struct ListEntryStruct *leptr,
struct DclTaskStruct *tkptr
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DclTaskItemDebug()\n");

#ifdef DBUG

   fprintf (stdout, "leptr %d %d %d (%d)\n",
            leptr->PrevPtr, leptr, leptr->NextPtr, tkptr);

   fprintf (stdout, "%08.08X [%d] %d %d %d %d %d %d %d %d |%s| %d\n",
            tkptr->ScriptProcessPid, tkptr->RequestPtr, tkptr->FindScript,
            tkptr->CgiPlusUsageCount, tkptr->TotalUsageCount,
            tkptr->QueuedSysCommand, tkptr->QueuedSysOutput,
            tkptr->QueuedCgiPlusIn, tkptr->QueuedHttpInput,
            tkptr->QueuedClientRead, tkptr->ScriptName, tkptr->LifeTimeCount);

#endif /* DBUG */

}

/*****************************************************************************/

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               