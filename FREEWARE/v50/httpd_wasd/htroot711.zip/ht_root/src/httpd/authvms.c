/*****************************************************************************/
/*
                               AuthVMS.c


    THE GNU GENERAL PUBLIC LICENSE APPLIES DOUBLY TO ANYTHING TO DO WITH
                    AUTHENTICATION AND AUTHORIZATION!

    This package is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License, or any later
    version.

>   This package is distributed in the hope that it will be useful,
>   but WITHOUT ANY WARRANTY; without even the implied warranty of
>   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
>   GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


This module provides functions related to the authentication of usernames via
access to the SYSUAF and the hashed password and other entry flags, etc.  It
also processes VMS identifiers used for controlling access.  Functions create
and validate access against WASD's VMS user profile capability.  Other
functionality includes checking access to files, etc. via these for the server
as well as users holding profiles.

See AUTH.C for overall detail on the WASD authorization environment.


VERSION HISTORY
---------------
27-MAR-2000  MGD  bugfix; AuthVmsCheckIdentifier() error return changed from
                  AUTH_DENIED_BY_OTHER to AUTH_DENIED_BY_LOGIN
20-NOV-1999  MGD  add nil-access identifier to bypass hour restrictions
02-OCT-1999  MGD  VMS user profile WATCH enhancements
                  bugfix; AuthCreateVmsUserProfile()
28-AUG-1999  MGD  unbundled from AUTH.C for v6.1
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <armdef.h>
#include <descrip.h>
#include <chpdef.h>
#include <prvdef.h>
#include <ssdef.h>
#include <stsdef.h>

#include <uaidef.h>
/* not defined in VAX C 3.2 <uaidef.h> */
#define UAI$M_RESTRICTED 0x8
#define UAI$C_PURDY_S 3

/* application related header files */
#include "wasd.h"

#define WASD_MODULE "AUTHVMS"

#if DBUG
#define FI_NOLI WASD_MODULE, __LINE__
#else
/* in production let's keep the exact line to ourselves! */
#define FI_NOLI WASD_MODULE, 0
#endif

/******************/
/* global storage */
/******************/

unsigned short  HttpdUserProfileLength;
unsigned char  *HttpdUserProfilePtr;
$DESCRIPTOR (HttpdUserProfileDsc, "");

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern boolean  AuthPolicySysUafRelaxed,
                AuthPolicySysUafIdentifiers,
                AuthPolicySysUafWasdIdentifiers,
                AuthSysUafEnabled,
                AuthSysUafPromiscuous,
                AuthVmsUserSecProfileEnabled;

extern int  WatchEnabled,
            ServerPort,
            ServiceCount;

extern unsigned long  AuthHttpsOnlyVmsIdentifier,
                      AuthNilAccessVmsIdentifier,
                      AuthPasswordChangeVmsIdentifier,
                      AuthWasdPwdVmsIdentifier,
                      AuthWasdHttpsVmsIdentifier,
                      AuthWasdReadVmsIdentifier,
                      AuthWasdWriteVmsIdentifier;

extern char  ErrorSanityCheck[],
             HttpdUserName[],
             ServerHostName[],
             ServerHostPort[],
             SoftwareID[],
             Utility[];

extern struct AccountingStruct  Accounting;
extern struct ConfigStruct  Config;
extern struct MsgStruct  Msgs;

/*****************************************************************************/
/*
Verify the request username/password from the on-disk SYSUAF database.

Get the specified user's flags, authorized privileges, quadword password, hash
salt and encryption algorithm from SYSUAF.  If any of specified bits in the
flags are set (e.g. "disusered") then fail the password authentication.
Using the salt and encryption algorithm hash the supplied password and compare
it to the UAF hashed password.  A SYSPRV privileged account is always failed.

Returns a success status if user password authenticated,
AUTH_DENIED_BY_LOGIN if not  authenticated, or other error status if a
genuine VMS error occurs (which should be reported where and when it occurs).
*/ 

int AuthVmsVerifyPassword
(
struct RequestStruct* rqptr,
struct AuthCacheRecordStruct *acrptr
)
{
   /* UAI flags that disallow an identifier-controlled account access */
   static unsigned long  DisallowIdFlags =
          UAI$M_DISACNT | UAI$M_PWD_EXPIRED | UAI$M_PWD2_EXPIRED;

   /* UAI flags that disallow SYSUAF-controlled account access */
   static unsigned long  DisallowVmsFlags =
          UAI$M_DISACNT | UAI$M_PWD_EXPIRED | UAI$M_PWD2_EXPIRED |
          UAI$M_CAPTIVE | UAI$M_RESTRICTED;

   static unsigned long  Context = -1;

   static unsigned long  UaiFlags,
                         UaiUic;
   static unsigned long  UaiPriv [2],
                         HashedPwd [2],
                         UaiPwd [2];
   static unsigned short  UaiSalt;
   static unsigned char  UaiEncrypt;
   static char  UaiOwner [1+31+1];

   static char UserName [AUTH_MAX_USERNAME_LENGTH+1],
               Password [AUTH_MAX_PASSWORD_LENGTH+1];
   static $DESCRIPTOR (UserNameDsc, UserName);
   static $DESCRIPTOR (PasswordDsc, Password);

   static struct {
      short BufferLength;
      short ItemCode;
      void  *BufferPtr;
      void  *LengthPtr;
   } UaiItems [] = 
   {
      { sizeof(UaiUic), UAI$_UIC, &UaiUic, 0 },
      { sizeof(UaiOwner)-1, UAI$_OWNER, &UaiOwner, 0 },
      { sizeof(UaiFlags), UAI$_FLAGS, &UaiFlags, 0 },
      { sizeof(UaiPriv), UAI$_PRIV, &UaiPriv, 0 },
      { sizeof(UaiPwd), UAI$_PWD, &UaiPwd, 0 },
      { sizeof(UaiEncrypt), UAI$_ENCRYPT, &UaiEncrypt, 0 },
      { sizeof(UaiSalt), UAI$_SALT, &UaiSalt, 0 },
      { sizeof(unsigned long), UAI$_PRIMEDAYS, 0, 0 },
      { 3, UAI$_NETWORK_ACCESS_P, 0, 0 },
      { 3, UAI$_NETWORK_ACCESS_S, 0, 0 },
      { 3, UAI$_REMOTE_ACCESS_P, 0, 0 },
      { 3, UAI$_REMOTE_ACCESS_S, 0, 0 },
      { 0, 0, 0, 0 }
   };

   register char  *cptr, *sptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthVmsVerifyPassword()\n");

   /* flag that case-less username and password checks were performed */
   rqptr->rqAuth.CaseLess = true;

   /* double-check! */
   if (!AuthSysUafEnabled) return (AUTH_DENIED_BY_LOGIN);

   acrptr->UaiPrimeDays =
     acrptr->UaiNetworkAccessP = acrptr->UaiNetworkAccessS =
     acrptr->UaiRemoteAccessP = acrptr->UaiRemoteAccessS = 0;

   UaiItems[7].BufferPtr = &acrptr->UaiPrimeDays;
   UaiItems[8].BufferPtr = &acrptr->UaiNetworkAccessP;
   UaiItems[9].BufferPtr = &acrptr->UaiNetworkAccessS;
   UaiItems[10].BufferPtr = &acrptr->UaiRemoteAccessP;
   UaiItems[11].BufferPtr = &acrptr->UaiRemoteAccessS;

   /* turn on SYSPRV to allow access to SYSUAF records */
   EnableSysPrv();

   /* to uppercase! */
   sptr = UserName;
   for (cptr = rqptr->RemoteUser; *cptr; *sptr++ = toupper(*cptr++));
   *sptr = '\0';
   UserNameDsc.dsc$w_length = sptr - UserName;
   status = sys$getuai (0, &Context, &UserNameDsc, &UaiItems, 0, 0, 0);
   if (Debug) fprintf (stdout, "sys$getuai() %%X%08.08X\n", status);

   /* turn off SYSPRV */
   DisableSysPrv();

   if (VMSnok (status)) 
   {
      if (status == RMS$_RNF)
      {
         if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
            WatchThis (rqptr, FI_LI, WATCH_AUTH, "FAIL SYSUAF username");
         return (AUTH_DENIED_BY_LOGIN);
      }
      rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_AUTH_DATABASE_VMS);
      ErrorVmsStatus (rqptr, status, FI_LI);
      return (status);
   }

   /* automatically disallow if any of these flags are set! */
   if ((AuthPolicySysUafIdentifiers && (UaiFlags & DisallowIdFlags)) ||
       (AuthPolicySysUafWasdIdentifiers && (UaiFlags & DisallowIdFlags)) ||
       (!AuthPolicySysUafIdentifiers && (UaiFlags & DisallowVmsFlags)))
   {
      if (Debug) fprintf (stdout, "failed on flags\n");
      if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
         WatchThis (rqptr, FI_LI, WATCH_AUTH, "FAIL SYSUAF flags");
      return (AUTH_DENIED_BY_LOGIN);
   }

   /* to uppercase! */
   sptr = Password;
   for (cptr = rqptr->RemoteUserPassword; *cptr; *sptr++ = toupper(*cptr++));
   *sptr = '\0';
   PasswordDsc.dsc$w_length = sptr - Password;
   status = sys$hash_password (&PasswordDsc, UaiEncrypt,
                               UaiSalt, &UserNameDsc, &HashedPwd);
   if (Debug) fprintf (stdout, "sys$hash_password() %%X%08.08X\n", status);
   if (VMSnok (status))
   {
      rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_AUTH_USER);
      ErrorVmsStatus (rqptr, status, FI_LI);
      return (status);
   }

   if (HashedPwd[0] != UaiPwd[0] || HashedPwd[1] != UaiPwd[1])
   {
      if (Debug) fprintf (stdout, "failed on password match\n");
      if (!AuthSysUafPromiscuous)
      {
         if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
            WatchThis (rqptr, FI_LI, WATCH_AUTH, "FAIL SYSUAF password");
         return (AUTH_DENIED_BY_LOGIN);
      }
   }

   UaiOwner[32] = '\0';
   if (Debug) fprintf (stdout, "UaiOwner |%s|\n", UaiOwner+1);
   for (cptr = UaiOwner + 31; cptr > UaiOwner+1 && isspace(*cptr); cptr--);
   if (!isspace(*cptr)) cptr++;
   *cptr = '\0';
   rqptr->rqAuth.UserDetailsLength = cptr - (UaiOwner+1);
   rqptr->rqAuth.UserDetailsPtr = cptr =
      VmGetHeap (rqptr, rqptr->rqAuth.UserDetailsLength+1);
   strcpy (cptr, UaiOwner+1);

   /* identifier checking overrides privilege checking! */
   if (AuthPolicySysUafIdentifiers)
   {
      /* check SYSUAF-authenticated account holds the correct identifier */
      if (VMSnok (status = AuthVmsLoadIdentifiers (rqptr, UaiUic)))
         return (status);
      return (AuthVmsCheckIdentifier (rqptr));
   }

   if (!AuthPolicySysUafRelaxed && (UaiPriv[0] & PRV$M_SYSPRV))
   {
      /* not allowing all accounts, exclude those with extended privileges */
      if (Debug) fprintf (stdout, "failed on privileges\n");
      if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
         WatchThis (rqptr, FI_LI, WATCH_AUTH, "FAIL SYSUAF privileges");
      return (AUTH_DENIED_BY_LOGIN);
   }

   /* authenticated ... user can do anything (the path allows!) */
   rqptr->rqAuth.UserCan = AUTH_READWRITE_ACCESS;

   if (Debug) fprintf (stdout, "SYSUAF verified!\n");
   return (SS$_NORMAL);
}

/****************************************************************************/
/*
SYSUAF authentication is being controlled by possession of an identifier ...
got the identifier you can be SYSUAF-authenticated, haven't then you cant! See
description at beginning of module.  Returns normal status if account possesses
suitable identifier, AUTH_DENIED_BY_LOGIN if it doesn't, or error status.
*/ 

AuthVmsCheckIdentifier (struct RequestStruct *rqptr)

{
   boolean  HoldsRealmId,
            HoldsWasdReadId,
            HoldsWasdWriteId;
   unsigned long  ThisId;
   unsigned long  *idptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthVmsCheckIdentifier()\n");

   /* can't do anything until allowed to! */
   rqptr->rqAuth.UserCan = 0;

   if (rqptr->rqAuth.VmsIdentifiersPtr == NULL)
      ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);

   HoldsRealmId = HoldsWasdReadId = HoldsWasdWriteId = false;

   for (idptr = rqptr->rqAuth.VmsIdentifiersPtr; ThisId = *idptr; idptr++)
   {
      if (Debug) fprintf (stdout, "%08.08X\n", ThisId);

      if (rqptr->rqAuth.SourceRealm == AUTH_SOURCE_ID &&
          ThisId == rqptr->rqAuth.RealmVmsIdentifier)
      {                     
         HoldsRealmId = true;

         if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
            WatchThis (rqptr, FI_LI, WATCH_AUTH,
                       "HOLDS identifier !AZ", rqptr->rqAuth.RealmPtr);

         continue;
      }

      if (rqptr->rqAuth.SourceRealm == AUTH_SOURCE_WASD_ID)
      {
         if (ThisId == AuthWasdReadVmsIdentifier)
         {
            HoldsWasdReadId = true;

            if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
               WatchThis (rqptr, FI_LI, WATCH_AUTH,
                          "HOLDS identifier !AZ", AUTH_WASD_READ_VMS_ID);

            continue;
         }

         if (ThisId == AuthWasdWriteVmsIdentifier)
         {                     
            HoldsWasdWriteId = true;

            if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
               WatchThis (rqptr, FI_LI, WATCH_AUTH,
                          "HOLDS identifier !AZ", AUTH_WASD_WRITE_VMS_ID);

            continue;
         }
      }

      if (ThisId == AuthHttpsOnlyVmsIdentifier)
      {
         /* account is only allowed to authenticate via SSL */
         rqptr->rqAuth.HttpsOnly = true;

         if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
            WatchThis (rqptr, FI_LI, WATCH_AUTH,
                       "HOLDS identifier !AZ", AUTH_HTTPS_ONLY_VMS_ID);

         continue;
      }

      if (ThisId == AuthNilAccessVmsIdentifier)
      {
         /* account may always authenticate even if hours seem to prohibit */
         rqptr->rqAuth.SysUafNilAccess = true;

         if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
            WatchThis (rqptr, FI_LI, WATCH_AUTH,
                       "HOLDS identifier !AZ", AUTH_NIL_ACCESS_VMS_ID);

         continue;
      }

      if (ThisId == AuthPasswordChangeVmsIdentifier)
      {
         /* account is allowed to change it's password via the server */
         rqptr->rqAuth.SysUafCanChangePwd = true;

         if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
            WatchThis (rqptr, FI_LI, WATCH_AUTH,
                       "HOLDS identifier !AZ", AUTH_PASSWORD_CHANGE_VMS_ID);

         continue;
      }

      if (ThisId == AuthWasdHttpsVmsIdentifier)
      {
         /* account is only allowed to authenticate via SSL */
         rqptr->rqAuth.HttpsOnly = true;

         if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
            WatchThis (rqptr, FI_LI, WATCH_AUTH,
                       "HOLDS identifier !AZ", AUTH_WASD_HTTPS_VMS_ID);

         continue;
      }

      if (ThisId == AuthWasdPwdVmsIdentifier)
      {
         /* account is allowed to change it's password via the server */
         rqptr->rqAuth.SysUafCanChangePwd = true;

         if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
            WatchThis (rqptr, FI_LI, WATCH_AUTH,
                       "HOLDS identifier !AZ", AUTH_WASD_PWD_VMS_ID);

         continue;
      }
   }

   /************************/
   /* check authentication */
   /************************/

   if (rqptr->rqAuth.SourceRealm == AUTH_SOURCE_ID &&
       !HoldsRealmId)
   {
      /* authentication is by local identifier ... and doesn't have it */
      if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
                    "FAIL SYSUAF access identifier");
      return (AUTH_DENIED_BY_LOGIN);
   }

   if (rqptr->rqAuth.SourceRealm == AUTH_SOURCE_WASD_ID &&
       !HoldsWasdWriteId &&
       !HoldsWasdReadId)
   {
      /* authentication only with WASD identifier .. and doesn't have it */
      if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
                    "FAIL SYSUAF access identifier");
      return (AUTH_DENIED_BY_LOGIN);
   }

   /* authenticated ... user can do anything (the path allows!) */
   rqptr->rqAuth.UserCan = AUTH_READWRITE_ACCESS;

   if (Debug) fprintf (stdout, "identifier verified!\n");
   return (SS$_NORMAL);
}

/****************************************************************************/
/*
*/ 

AuthVmsLoadIdentifiers
(
struct RequestStruct *rqptr,
unsigned long  UaiUic
)
{
   static struct {
      unsigned long  Uic;
      unsigned long  Unused;
   } Holder = { 0, 0 };

   int  status,
        idcnt;
   unsigned long  Ctx,
                  ThisId;
   unsigned long  *idptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthVmsLoadIdentifiers()\n");

   /* if already loaded then just continue */
   if (rqptr->rqAuth.VmsIdentifiersPtr != NULL) return (SS$_NORMAL);

   /* plus one longword as a sentinal (will contain zero) */
   rqptr->rqAuth.VmsIdentifiersPtr = idptr =
      (unsigned long*)VmGetHeap (rqptr, (AUTH_MAX_VMS_IDENTIFIERS + 1) *
                                         sizeof(unsigned long));

   Holder.Uic = UaiUic;

   rqptr->rqAuth.VmsIdentifiersCount = 0;
   idcnt = AUTH_MAX_VMS_IDENTIFIERS;

   /* turn on SYSPRV to allow this to be done */
   EnableSysPrv();

   Ctx = 0;
   while (VMSok (status = sys$find_held (&Holder, &ThisId, 0, &Ctx)))
   {
      if (Debug) fprintf (stdout, "%08.08X\n", ThisId);
      if (!--idcnt)
      {
         status = SS$_BUFFEROVF;
         break;
      }
      *idptr++ = ThisId;
      rqptr->rqAuth.VmsIdentifiersCount++;
   }
   /* sentinal (not really necessary, but let's be over-cautious) */
   *idptr = 0;

   /* turn off SYSPRV */
   DisableSysPrv();

   if (Debug) fprintf (stdout, "sys$find_held() %%X%08.08X\n", status);

   /* if we got to the end of the identifiers without mishap */
   if (status == SS$_NOSUCHID) return (SS$_NORMAL);

   /*********/
   /* error */
   /*********/

   sys$finish_rdb (&Ctx);
   rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_AUTH_DATABASE_VMS);
   ErrorVmsStatus (rqptr, status, FI_LI);
   return (status);
}

/****************************************************************************/
/*
Look through the request's array of a VMS authenticated user's identifiers for
the specified one.  Return zero to indicate the identifier was not held, normal
to indicate it was, or any other error status.
*/ 

int AuthVmsHoldsIdentifier
(
struct RequestStruct *rqptr,
char *IdentifierName,
unsigned long ThisId
)
{
   register unsigned long  *idptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthVmsHoldsIdentifier() %08.08X\n", ThisId);

   /* if not already loaded via SYSUAF authentication then really an error */
   if (rqptr->rqAuth.VmsIdentifiersPtr == NULL)
   {
      /* has NOT been authenticated via the SYSUAF (shouldn't happen!) */

      if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
                    "IDENTIFIER request not SYSUAF authenticated");

      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_ACCESS_DENIED), FI_NOLI);

      return (SS$_ABORT);
   }

   if (!ThisId) return (false);

   for (idptr = rqptr->rqAuth.VmsIdentifiersPtr;
        *idptr && *idptr != ThisId;
        idptr++);

   if (*idptr)
   {
      if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
                    "HOLDS identifier !AZ", IdentifierName);

      return (SS$_NORMAL);
   }

   return (0);
}

/****************************************************************************/
/*
*/ 

AuthVmsHoldsWasdGroupIdent
(
struct RequestStruct *rqptr,
char *GroupName
)
{
   static char GroupIdName [AUTH_MAX_REALM_GROUP_LENGTH+1] =
                           AUTH_WASD__GROUP_VMS_ID;
   static $DESCRIPTOR (GroupIdNameDsc, GroupIdName);

   register char  *cptr, *sptr, *zptr;

   int  status;
   unsigned long  ThisId;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "AuthVmsHoldsWasdGroupIdent() |%s|\n", GroupName);

   zptr = (sptr = GroupIdName) + sizeof(GroupIdName);
   for (cptr = GroupName; *cptr && sptr < zptr; *sptr++ = *cptr++);
   if (sptr >= zptr)
   {
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_GENERAL_OVERFLOW), FI_LI);
      return (SS$_ABORT);
   }
   *sptr = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", GroupIdName);
   GroupIdNameDsc.dsc$w_length = sptr - GroupIdName;
   if (VMSnok (status = sys$asctoid (&GroupIdNameDsc, &ThisId, 0)))
   {
      rqptr->rqResponse.ErrorTextPtr = GroupIdName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      return (status);
   }

   return (AuthVmsHoldsIdentifier (rqptr, GroupIdName, ThisId));
}

/*****************************************************************************/
/*
Using sys$create_user_profile() create a permanent security profile of the
SYSUAF-authenticated user name.  This will be stored in the cache and attached
to the request structure each time the user is re-authenticated from it.  This
profile will be used to check file/directory (see AuthVmsCheckUserAccess())
access permission against the authenticated user not the server account.
*/

int AuthVmsCreateUserProfile (struct RequestStruct* rqptr)

{
   static unsigned long  Context = -1;
   static unsigned char  *UserProfilePtr;
   static $DESCRIPTOR (UserNameDsc, "");

   int  status;
   unsigned short  Length;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "AuthVmsCreateUserProfile() |%s|\n", rqptr->RemoteUser);

   if (UserProfilePtr == NULL)
      UserProfilePtr = VmGet (AUTH_CREATE_USER_PROFILE_SIZE);
   Length = AUTH_CREATE_USER_PROFILE_SIZE;

   rqptr->rqAuth.VmsUserProfilePtr = NULL;
   rqptr->rqAuth.VmsUserProfileLength = 0;

   UserNameDsc.dsc$a_pointer = rqptr->RemoteUser;
   UserNameDsc.dsc$w_length = rqptr->RemoteUserLength;

   /* turn on SYSPRV to allow this to be done */
   EnableSysPrv();

   status = sys$create_user_profile (&UserNameDsc, 0, 0,
                                     UserProfilePtr, &Length, &Context);
   if (Debug)
      fprintf (stdout, "sys$create_user_profile() %%X%08.08X %d bytes\n",
               status, Length);

   /* turn off SYSPRV */
   DisableSysPrv();

   if (VMSnok (status)) 
   {
      rqptr->rqResponse.ErrorTextPtr = "sys$create_user_profile()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      return (status);
   }

   if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
      WatchThis (rqptr, FI_LI, WATCH_AUTH,
                 "PROFILE created (!UL bytes)", Length);

   rqptr->rqAuth.VmsUserProfilePtr =
      VmGetHeap (rqptr, rqptr->rqAuth.VmsUserProfileLength = Length);
   memcpy (rqptr->rqAuth.VmsUserProfilePtr, UserProfilePtr, Length);
      
   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Using sys$create_user_profile() create a permanent security profile of the
HTTPd server account.  Returns no status, exits server if error encountered.
*/ 
 
AuthVmsCreateHttpdProfile ()

{
   static unsigned long  Flags = 0;

   int  status;
   char  HttpdUserProfile [512];
   $DESCRIPTOR (HttpdUserNameDsc, "");

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthVmsCreateHttpdProfile()\n");

   if (HttpdUserProfileLength) return;

   HttpdUserNameDsc.dsc$a_pointer = HttpdUserName;
   HttpdUserNameDsc.dsc$w_length = strlen(HttpdUserName);

   status = sys$create_user_profile (&HttpdUserNameDsc, 0, Flags,
                                     HttpdUserProfile,
                                     &HttpdUserProfileLength, 0);
   if (Debug)
      fprintf (stdout, "sys$create_user_profile() %%X%08.08X\n", status);

   if (VMSnok (status))
      ErrorExitVmsStatus (status, "sys$create_user_profile()", FI_LI);

   HttpdUserProfilePtr = VmGet (HttpdUserProfileLength);
   if (Debug) fprintf (stdout, "ptr: %d\n", HttpdUserProfilePtr);
   memcpy (HttpdUserProfilePtr, HttpdUserProfile, HttpdUserProfileLength);
   HttpdUserProfileDsc.dsc$a_pointer = HttpdUserProfilePtr;
   HttpdUserProfileDsc.dsc$w_length = HttpdUserProfileLength;
}

/*****************************************************************************/
/*
Using sys$check_access() check file read access permission for the supplied
file name against the SYSUAF-authenticated user's security profile (created by
AuthVmsCreateUserProfile()).  File or directory specifications can be supplied.
Returns SS$_NORMAL if access allowed, RMS$_PRV if denied, and other RMS status
codes. A VMS error other than from RMS (e.g. INSFMEM, which would disrupt the
system service results) will cause the server to exit.
*/

int AuthVmsCheckUserAccess
(
struct RequestStruct* rqptr,
char *FileName,
int FileNameLength
)
{
   static unsigned long  Flags = 0,
                         ArmReadAccess = ARM$M_READ;
   static $DESCRIPTOR (ClassNameDsc, "FILE");
   static $DESCRIPTOR (UserProfileDsc, "");
   static struct
   {
      short BufferLength;
      short ItemCode;
      void  *BufferPtr;
      void  *LengthPtr;
   }
   ReadItem [] = 
   {
      { sizeof(ArmReadAccess), CHP$_ACCESS, &ArmReadAccess, 0 },
      { 0, 0, 0, 0 }
   };

   int  status,
        DirFileNameLength;
   char  *NoProfilePtr,
         *WhoseProfilePtr;
   char  DirFileName [ODS_MAX_FILE_NAME_LENGTH+1];
   $DESCRIPTOR (FileNameDsc, "");

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "AuthVmsCheckUserAccess() |%s|%s| %d %d %d\n",
               rqptr->RemoteUser, FileName,
               rqptr->rqAuth.VmsUserProfileLength,
               rqptr->rqAuth.VmsUserProfilePtr,
               rqptr->rqPathSet.NoProfile);

   if (FileNameLength <= 0) FileNameLength = strlen(FileName);

   if (FileNameLength && FileName[FileNameLength-1] == ']')
   {
      /* a directory has been specified, get the directory file name */
      OdsNameOfDirectoryFile (FileName, FileNameLength,
                              DirFileName, &DirFileNameLength);
      FileNameDsc.dsc$a_pointer = DirFileName;
      FileNameDsc.dsc$w_length = DirFileNameLength;
   }
   else
   {
      FileNameDsc.dsc$a_pointer = FileName;
      FileNameDsc.dsc$w_length = FileNameLength;
   }

   /****************/
   /* check access */
   /****************/

   if (rqptr->rqAuth.VmsUserProfileLength &&
       !rqptr->rqPathSet.NoProfile)
   {
      /* against a SYSUAF-authenticated account */
      UserProfileDsc.dsc$a_pointer = rqptr->rqAuth.VmsUserProfilePtr;
      UserProfileDsc.dsc$w_length = rqptr->rqAuth.VmsUserProfileLength;
      WhoseProfilePtr = rqptr->RemoteUser;
      NoProfilePtr = "";
   }
   else
   {
      /* against the HTTPd server account */
      if (!HttpdUserProfileLength) AuthVmsCreateHttpdProfile ();
      UserProfileDsc.dsc$a_pointer = HttpdUserProfilePtr;
      UserProfileDsc.dsc$w_length = HttpdUserProfileLength;
      WhoseProfilePtr = HttpdUserName;
      if (rqptr->rqAuth.VmsUserProfileLength)
         NoProfilePtr = " (NOprofile)";
      else
         NoProfilePtr = "";
   }

   /* turn on SYSPRV to allow this to be done */
   EnableSysPrv();

   status = sys$check_access (0, &FileNameDsc, 0, &ArmReadAccess,
                              0, &ClassNameDsc, 0, &UserProfileDsc);
   if (Debug) fprintf (stdout, "sys$check_access() %%X%08.08X\n", status);

   /* turn off SYSPRV */
   DisableSysPrv();

   if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
      WatchThis (rqptr, FI_LI, WATCH_AUTH,
                 "ACCESS!AZ !AZ read !AZ %X!8XL !AZ",
                 NoProfilePtr, WhoseProfilePtr, FileNameDsc.dsc$a_pointer,
                 status, VMSok(status) ? "YES" : "NO");

   /* we are only dealing with files ... turn it into an RMS message */
   if (status == SS$_NOPRIV) return (RMS$_PRV);

   /* if access is permitted */
   if (VMSok (status)) return (status);

   /* if an RMS error return normal letting caller continue and report it */
   if (((status & STS$M_FAC_NO) >> STS$V_FAC_NO) == RMS$_FACILITY)
      return (SS$_NORMAL);

   rqptr->rqResponse.ErrorTextPtr = "sys$check_access()";
   rqptr->rqResponse.ErrorOtherTextPtr = FileName;
   ErrorVmsStatus (rqptr, status, FI_LI);
   return (status);
}

/*****************************************************************************/
/*
Check that the HTTPd account has CONTROL or WRITE access to the parent
directory of the file or directory specification supplied in 'FileName'. If
the server has CONTROL access then there is no general access to the
directory, only an authenticated VMS user can write into it. If there is WRITE
access then any authenticated user can write into it. Returns SS$_NORMAL if
access allowed, RMS$_PRV if denied, and other status codes.  Error report
should be generated by the calling routine.
*/ 
 
int AuthVmsCheckWriteAccess
(
struct RequestStruct *rqptr,
char *FileName,
int FileNameLength
)
{
   static unsigned long  Flags = 0;
   static unsigned long  ArmWriteAccess = ARM$M_WRITE,
                         ArmControlAccess = ARM$M_CONTROL;

   static struct {
      unsigned short  BufferLength;
      unsigned short  ItemCode;
      unsigned long  BufferAddress;
      unsigned long  ReturnLengthAddress;
   } WriteAccessItem [] =
       { { sizeof(ArmWriteAccess), CHP$_ACCESS, &ArmWriteAccess, 0 },
         { 0, 0, 0, 0 } },
     ControlAccessItem [] =
       { { sizeof(ArmControlAccess), CHP$_ACCESS, &ArmControlAccess, 0 },
         { 0, 0, 0, 0 } };

   static $DESCRIPTOR (ClassNameDsc, "FILE");
   static $DESCRIPTOR (ObjectNameDsc, "");
   static $DESCRIPTOR (UserProfileDsc, "");

   int  status,
        DirectoryFileLength;
   char  DirectoryFile [ODS_MAX_FILE_NAME_LENGTH+1];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthVmsCheckWriteAccess() |%s|\n", FileName);

   if (!HttpdUserProfileLength) AuthVmsCreateHttpdProfile ();

   if (FileNameLength <= 0) FileNameLength = strlen(FileName);

   OdsNameOfDirectoryFile (FileName, FileNameLength,
                           DirectoryFile, &DirectoryFileLength);

   ObjectNameDsc.dsc$a_pointer = DirectoryFile;
   ObjectNameDsc.dsc$w_length = DirectoryFileLength;

   /* turn on SYSPRV to allow this to be done */
   EnableSysPrv();

   if (AuthVmsUserSecProfileEnabled)
   {
      /****************************/
      /* check for control access */
      /****************************/

      status = sys$check_access (0, &ObjectNameDsc, 0, &ControlAccessItem,
                                 0, &ClassNameDsc, 0, &HttpdUserProfileDsc);
      if (Debug) fprintf (stdout, "1 sys$check_access() %%X%08.08X\n", status);

      if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
                    "ACCESS !AZ control !AZ %X!8XL !AZ",
                    HttpdUserName, ObjectNameDsc.dsc$a_pointer,
                    status, VMSok(status) ? "YES" : "NO");

      if (VMSok (status))
      {
         /* control access for HTTPd, must be authenticated VMS user! */
         if (!rqptr->rqAuth.VmsUserProfileLength)
         {
            /* turn off SYSPRV! */
            DisableSysPrv();
            /* not a SYSUAF-authenticated user therefore no privilege */
            return (SS$_NOPRIV);
         }

         /* now check if the authenticated VMS user has write access */
         UserProfileDsc.dsc$a_pointer = rqptr->rqAuth.VmsUserProfilePtr;
         UserProfileDsc.dsc$w_length = rqptr->rqAuth.VmsUserProfileLength;

         status = sys$check_access (0, &ObjectNameDsc, 0, &WriteAccessItem,
                                    0, &ClassNameDsc, 0, &UserProfileDsc);
         if (Debug)
            fprintf (stdout, "2 sys$check_access() %%X%08.08X\n", status);

         /* turn off SYSPRV */
         DisableSysPrv();

         if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
            WatchThis (rqptr, FI_LI, WATCH_AUTH,
                       "ACCESS !AZ write !AZ %X!8XL !AZ",
                       rqptr->RemoteUser, ObjectNameDsc.dsc$a_pointer,
                       status, VMSok(status) ? "YES" : "NO");

         /* no privilege to write */
         if (status == SS$_NOPRIV) return (status);

         /* write access OK */
         if (VMSok (status)) return (status);

         /* if the directory file not exist then directory does not exist */
         if (status == RMS$_FNF) status = RMS$_DNF;

         return (status);
      }

      /* no control access, drop through to check for write access */
   }

   /**************************/
   /* check for write access */
   /**************************/

   status = sys$check_access (0, &ObjectNameDsc, 0, &WriteAccessItem,
                              0, &ClassNameDsc, 0, &HttpdUserProfileDsc);
   if (Debug) fprintf (stdout, "3 sys$check_access() %%X%08.08X\n", status);

   /* turn off SYSPRV */
   DisableSysPrv();

   if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
      WatchThis (rqptr, FI_LI, WATCH_AUTH,
                 "ACCESS !AZ write !AZ %X!8XL !AZ",
                 HttpdUserName, ObjectNameDsc.dsc$a_pointer,
                 status, VMSok(status) ? "YES" : "NO");

   /* no privilege to write */
   if (status == SS$_NOPRIV) return (status);

   /* write access OK */
   if (VMSok (status)) return (status);

   /* if the directory file did not exist then directory does not exist */
   if (status == RMS$_FNF) status = RMS$_DNF;

   return (status);
}

/*****************************************************************************/

r                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        