/*****************************************************************************/
/*
                                    ODS.c 

Module supports file system access for both ODS-2 and where appropriate (Alpha
VMS v7.2ff) ODS-5.  This supports transparent access to ODS-5 file system
structure for the serving of data from the file-system.  (The WASD package
files however must still be supported inside of ODS-2 conventions.)

Basically it does this by abstracting the NAM block so that either the standard
or long formats may be used without other modules needing to be aware of the
underlying structure.  The VAX version does not need to know about long NAMs,
or extended file specifications in general (excluded for code compactness and
minor efficiency reasons using the ODS_EXTENDED macro).  Alpha versions prior
to 7.2 do not know about NAMLs and so for compilation in these environments a
compatible NAML is provided (ENAMEL.H header file), allowing extended file
specification compliant code to be compiled and linked on pre-v7.2 systems. 

Runtime decision structures based on the VMS version, device ACP type, etc.,
must be used if pre-v7.2 systems are to avoid using the NAML structure with RMS
(which would of course result in runtime errors).  In this way a single set of
base-level Alpha object modules, built in either environment, will support both
pre and post 7.2 environments.

The essential accessability to and functionality of RMS is not buried too
deeply by this wrapping.  File operations are still performed using RMS data
structures and services wherever possible, only those that process using NAM
structures are, and need to be, abstracted in this way (i.e. sys$open(),
sys$parse(), sys$search()).  ASTs are called using the same conventions as the
RMS service counterpart (i.e. with a pointer to the same data structure), and
success should be checked using the same mechanisms, etc.

Even when not supplying an AST address it is advised to supply the AST
parameter (usually a request or task pointer).  The reason?  Well this is often
placed into the FAB or RAB context storage for retrieval by an AST routine
subsequently and explicitly called by the code.  Experience has shown it's easy
to forget to set up this context in the non-AST instance ;^)


DISPLAYING FILE SPECIFICATIONS
------------------------------
As there are a number of ways of displaying VMS file names in mixed ODS-2 and
ODS-5 environments this module seemed the appropriate place to discuss the WASD
approach (although much of this processing is distributed through the MAPURL.C,
DIR.C and UPD.C modules).

Prior to the extended file specifications of VMS V7.2 and following WASD tended
to default all file and directory paths to lower case (as this is commonly
considered more aesthetically pleasing - and to the author).  This is obvious
in directory listings but may also be seen in UPD.C and SSI.C file naming. 
Optionally then DIR.C module would display specification in upper case (for
instance if a semicolon was used in the URL path).

Now that extended file specifications exist in Alpha VMS V7.2 and following
there exist a number of methods of displaying file names.  Files on ODS-2
volumes continue to be treated as described above.  Files from ODS-5 volumes
become more complex as a number of options are available.  As ODS-5 supports a
mixed upper and lower case character set WASD no longer forces case, names are
displayed as stored on-disk.  RMS displays many non-alpha-numeric characters
using escape sequences, of which some have multiple, possible representations
(e.g. the space, "^ ", "^_", "^20", and other possibles).

In addition, a Web URL has it's own escape syntax for forbidden characters, the
"%xx" hexadecimal representation.  WASD attempts to accept file specifications
in either RMS-escape syntax or URL-escape syntax.  Presentation is most
commonly done using URL-escape syntax, but may in directory listing be
optionally displayed in RMS ("^_") and even on-disk format (" ") (see the DIR.C
module).

16 BIT (UNICODE) FILE NAMES ARE NOT SUPPORTED!
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


VERSION HISTORY
---------------
09-JUN-2000  MGD  search-list processing refined
26-DEC-1999  MGD  initial
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <descrip.h>
#include <devdef.h>
#include <dvidef.h>
#include <iodef.h>
#include <rmsdef.h>
#include <ssdef.h>
#include <stsdef.h>

/* application related header files */
#include "wasd.h"

#define WASD_MODULE "ODS"

/******************/
/* global storage */
/******************/

boolean  OdsExtended;

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern int  OpcomMessages,
            VmsVersion,
            WatchEnabled;
extern char  SyiVersion[],
             Utility[];
extern struct AccountingStruct  Accounting;
extern struct MsgStruct  Msgs;

/****************************************************************************/
/*
Set the ODS extended flag (i.e. supports ODS-5) if the architecture is Alpha
and the VMS version is 7.2ff and not explicitly disabled at the command line.
Check whether any ENAMEL.H NAML structure basically looks ok.
*/ 

OdsSetExtended ()

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "OdsSetExtended()\n");

#ifdef ODS_EXTENDED

#ifdef ENAMEL_NAML
   /* just a check for stupid errors on compilations using ENAMEL.H NAML */
   if (sizeof(struct NAML) != NAML$C_BLN)
   {
      WriteFaoStdout ("%!AZ-W-ENAMEL, NAML problem, \
extended file specifications not supported\n",
                      Utility);
      if (OpcomMessages & OPCOM_HTTPD)
         WriteFaoOpcom ("%!AZ-W-ENAMEL, NAML problem, \
extended file specifications not supported\n",
                         Utility);
      OdsExtended = false;
      return;
   }
#endif /* ENAMEL_NAML */

#endif /* ODS_EXTENDED */

#ifdef __ALPHA
   if (VmsVersion >= 72)
      OdsExtended = true;
   else
#endif
      OdsExtended = false;

   WriteFaoStdout ("%!AZ-I-ODS5, !AZsupported by !AZ VMS !AZ\n",
                   Utility, OdsExtended ? "" : "not ",
#ifdef __ALPHA
                   "Alpha",
#else
                   "VAX",
#endif
                   SyiVersion);
}

/****************************************************************************/
/*
Generic open for read.  Intended for configuration files, etc.  Completely
synchronous with a RAB connected for sequential read.
*/ 

int OdsOpenReadOnly
(
struct OdsStruct *odsptr,
char *FileSpec
)
{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "OdsOpenReadOnly() |%s|\n", FileSpec);

   memset (odsptr, 0, sizeof(struct OdsStruct));

   odsptr->Fab = cc$rms_fab;
   odsptr->Fab.fab$b_fac = FAB$M_GET;
   odsptr->Fab.fab$b_shr = FAB$M_SHRGET;

#ifdef ODS_EXTENDED
   if (Debug) fprintf (stdout, "OdsExtended: %d\n", OdsExtended);
   if (OdsExtended)
   {
      odsptr->Fab.fab$l_fna = -1;  
      odsptr->Fab.fab$b_fns = 0;
      odsptr->Fab.fab$l_nam = &odsptr->Naml;

      odsptr->NamlInUse = true;
      ENAMEL_RMS_NAML(odsptr->Naml)
      odsptr->Naml.naml$l_long_filename = FileSpec;
      odsptr->Naml.naml$l_long_filename_size = strlen(FileSpec);
      odsptr->Naml.naml$l_long_expand = odsptr->ExpFileName;
      odsptr->Naml.naml$l_long_expand_alloc = sizeof(odsptr->ExpFileName)-1;
      odsptr->Naml.naml$l_long_result = odsptr->ResFileName;
      odsptr->Naml.naml$l_long_result_alloc = sizeof(odsptr->ResFileName)-1;
      odsptr->Naml.naml$l_filesys_name = odsptr->SysFileName;
      odsptr->Naml.naml$l_filesys_name_alloc = sizeof(odsptr->SysFileName)-1;
   }
   else
#endif /* ODS_EXTENDED */
   {
      odsptr->Fab.fab$l_fna = FileSpec;  
      odsptr->Fab.fab$b_fns = strlen(FileSpec);
      odsptr->Fab.fab$l_nam = &odsptr->Nam;

      odsptr->NamlInUse = false;
      odsptr->Nam = cc$rms_nam;
      odsptr->Nam.nam$l_esa = odsptr->ExpFileName;
      odsptr->Nam.nam$b_ess = ODS2_MAX_FILE_NAME_LENGTH;
      odsptr->Nam.nam$l_rsa = odsptr->ResFileName;
      odsptr->Nam.nam$b_rss = ODS2_MAX_FILE_NAME_LENGTH;
   }

   /* initialize the date, header and protection extended attribute blocks */
   odsptr->Fab.fab$l_xab = &odsptr->XabDat;
   odsptr->XabDat = cc$rms_xabdat;
   odsptr->XabDat.xab$l_nxt = &odsptr->XabFhc;
   odsptr->XabFhc = cc$rms_xabfhc;
   odsptr->XabFhc.xab$l_nxt = &odsptr->XabPro;
   odsptr->XabPro = cc$rms_xabpro;

   odsptr->Fab.fab$l_fop &= ~FAB$M_ASY;
   status = sys$open (&odsptr->Fab, 0, 0);
   if (Debug) fprintf (stdout, "sys$open() %%X%08.08X\n", status);
   if (VMSnok (status) || VMSnok (status = odsptr->Fab.fab$l_sts))
      return (status);

   /* set up the generic information from the NAM(L) block */
   odsptr->Fab.fab$l_ctx = odsptr;
   OdsNamBlockAst (&odsptr->Fab);

   /* record access block */
   odsptr->Rab = cc$rms_rab;
   odsptr->Rab.rab$l_fab = &odsptr->Fab;
   /* 2 buffers of six blocks each */
   odsptr->Rab.rab$b_mbc = 6;
   odsptr->Rab.rab$b_mbf = 2;
   /* read ahead performance option */
   odsptr->Rab.rab$l_rop = RAB$M_RAH;
   /* all synchronous (for now anyway) */
   odsptr->Rab.rab$l_rop &= ~FAB$M_ASY;

   status = sys$connect (&odsptr->Rab, 0, 0);
   if (Debug) fprintf (stdout, "sys$connect() %%X%08.08X\n", status);
   if (VMSnok (status) || VMSnok (status = odsptr->Rab.rab$l_sts))
   {
      sys$close (&odsptr->Fab, 0, 0);
      return (status);
   }

   return (status);
}

/****************************************************************************/
/*
RMS open the supplied file specification (using appropriate standard or long
NAM structure).  OdsNamBlockAst() is always called, which sets a number of
pointers and other data from the NAM block so that calling functions do not
need to know which was used.
*/ 

int OdsOpen
(
struct OdsStruct *odsptr,
char *FileSpec,
int FileSpecLength,
char *DefaultSpec,
int DefaultSpecLength,
int FabFac,
int FabFop,
int FabShr,
void *AstFunctionPtr,
unsigned long AstParam
)
{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "OdsOpen() |%s|%s|\n", FileSpec, DefaultSpec);

   memset (odsptr, 0, sizeof(struct OdsStruct));

   odsptr->AstFunctionPtr = AstFunctionPtr;
   odsptr->AstParam = AstParam;

   if (FabFop & FAB$M_DLT)
      odsptr->DeleteOnClose = true;
   else
      odsptr->DeleteOnClose = false;

   if (!FileSpecLength && FileSpec != NULL)
      FileSpecLength = strlen(FileSpec);
   if (!DefaultSpecLength && DefaultSpec != NULL)
      DefaultSpecLength = strlen(DefaultSpec);

   odsptr->Fab = cc$rms_fab;
   odsptr->Fab.fab$l_ctx = odsptr;
   odsptr->Fab.fab$b_fac = FabFac;
   odsptr->Fab.fab$l_fop = FabFop;
   odsptr->Fab.fab$b_shr = FabShr;

#ifdef ODS_EXTENDED
   if (Debug) fprintf (stdout, "OdsExtended: %d\n", OdsExtended);
   if (OdsExtended)
   {
      odsptr->Fab.fab$l_fna = -1;  
      odsptr->Fab.fab$b_fns = 0;
      odsptr->Fab.fab$l_nam = &odsptr->Naml;

      odsptr->NamlInUse = true;
      ENAMEL_RMS_NAML(odsptr->Naml)
      odsptr->Naml.naml$l_long_defname = DefaultSpec;
      odsptr->Naml.naml$l_long_defname_size = DefaultSpecLength;
      odsptr->Naml.naml$l_long_filename = FileSpec;
      odsptr->Naml.naml$l_long_filename_size = FileSpecLength;
      odsptr->Naml.naml$l_long_expand = odsptr->ExpFileName;
      odsptr->Naml.naml$l_long_expand_alloc = sizeof(odsptr->ExpFileName)-1;
      odsptr->Naml.naml$l_long_result = odsptr->ResFileName;
      odsptr->Naml.naml$l_long_result_alloc = sizeof(odsptr->ResFileName)-1;
      odsptr->Naml.naml$l_filesys_name = odsptr->SysFileName;
      odsptr->Naml.naml$l_filesys_name_alloc = sizeof(odsptr->SysFileName)-1;
   }
   else
#endif /* ODS_EXTENDED */
   {
      odsptr->Fab.fab$l_dna = DefaultSpec;  
      odsptr->Fab.fab$b_dns = DefaultSpecLength;
      odsptr->Fab.fab$l_fna = FileSpec;  
      odsptr->Fab.fab$b_fns = FileSpecLength;
      odsptr->Fab.fab$l_nam = &odsptr->Nam;

      odsptr->NamlInUse = false;
      odsptr->Nam = cc$rms_nam;
      odsptr->Nam.nam$l_esa = odsptr->ExpFileName;
      odsptr->Nam.nam$b_ess = ODS2_MAX_FILE_NAME_LENGTH;
      odsptr->Nam.nam$l_rsa = odsptr->ResFileName;
      odsptr->Nam.nam$b_rss = ODS2_MAX_FILE_NAME_LENGTH;
   }

   /* initialize the date, header and protection extended attribute blocks */
   odsptr->Fab.fab$l_xab = &odsptr->XabDat;
   odsptr->XabDat = cc$rms_xabdat;
   odsptr->XabDat.xab$l_nxt = &odsptr->XabFhc;
   odsptr->XabFhc = cc$rms_xabfhc;
   odsptr->XabFhc.xab$l_nxt = &odsptr->XabPro;
   odsptr->XabPro = cc$rms_xabpro;

   if (AstFunctionPtr == NULL)
   {
      /* synchronous service */
      odsptr->Fab.fab$l_fop &= ~FAB$M_ASY;
      status = sys$open (&odsptr->Fab, 0, 0);
      if (Debug) fprintf (stdout, "sys$open() %%X%08.08X\n", status);
      OdsNamBlockAst (&odsptr->Fab);
      if (VMSok (status)) status = odsptr->Fab.fab$l_sts;
      return (status);
   }
   else
   {
      /* asynchronous service */
      odsptr->Fab.fab$l_fop |= FAB$M_ASY;
      status = sys$open (&odsptr->Fab, &OdsNamBlockAst, &OdsNamBlockAst);
      if (Debug) fprintf (stdout, "sys$open() %%X%08.08X\n", status);
      return (status);
   }
}

/****************************************************************************/
/*
Close the currently open file (with delete if required).  If an AST function is
supplied this is called regardless.
*/ 

int OdsClose
(
struct OdsStruct *odsptr,
void *AstFunctionPtr,
unsigned long AstParam
)
{
   int  status;
   void (*AstPtr)(struct FAB*);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "OdsClose()\n");

   odsptr->Fab.fab$l_ctx = AstParam;

   if (!odsptr->DeleteOnClose)
   {
      if (AstFunctionPtr != NULL)
      {
         /* asynchronous close service */
         odsptr->Fab.fab$l_fop |= FAB$M_ASY;
         status = sys$close (&odsptr->Fab, AstFunctionPtr, AstFunctionPtr);
         if (Debug) fprintf (stdout, "sys$close() %%X%08.08X\n", status);
         return (status);
      }
      else
      {
         /* synchronous close service */
         odsptr->Fab.fab$l_fop &= ~FAB$M_ASY;
         status = sys$close (&odsptr->Fab, 0, 0);
         if (Debug) fprintf (stdout, "sys$close() %%X%08.08X\n", status);
         if (VMSok (status)) status = odsptr->Fab.fab$l_sts;
         return (status);
      }
   }
   else
   {
      /* use SYSPRV to ensure deletion-on-close of file */
      EnableSysPrv();
      /* synchronous close service (careful when using SYSPRV!) */
      odsptr->Fab.fab$l_fop &= ~FAB$M_ASY;
      odsptr->Fab.fab$l_fop |= FAB$M_DLT;
      status = sys$close (&odsptr->Fab, 0, 0);
      if (VMSok (status)) status = odsptr->Fab.fab$l_sts;
      if (Debug) fprintf (stdout, "sys$close() %%X%08.08X\n", status);
      DisableSysPrv();
      /* now explicitly call any AST */
      if (AstFunctionPtr != NULL) (AstPtr = AstFunctionPtr)(&odsptr->Fab);
      return (status);
   }
}

/****************************************************************************/
/*
RMS parse the supplied file specification into an appropriate standard or long
NAM structure.  OdsNamBlockAst() is always called, which sets a number of
pointers and other data from the NAM block so that calling functions do not
need to know which was used.
*/ 

int OdsParse
(
struct OdsStruct *odsptr,
char *FileSpec,
int FileSpecLength,
char *DefaultSpec,
int DefaultSpecLength,
int NamNop,
void *AstFunctionPtr,
unsigned long AstParam
)
{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "OdsParse() |%s|%s|\n", FileSpec, DefaultSpec);

   memset (odsptr, 0, sizeof(struct OdsStruct));

   odsptr->AstFunctionPtr = AstFunctionPtr;
   odsptr->AstParam = AstParam;
   odsptr->ParseInUse = true;

   if (!FileSpecLength && FileSpec != NULL)
      FileSpecLength = strlen(FileSpec);
   if (!DefaultSpecLength && DefaultSpec != NULL)
      DefaultSpecLength = strlen(DefaultSpec);

   odsptr->Fab = cc$rms_fab;
   odsptr->Fab.fab$l_ctx = odsptr;

#ifdef ODS_EXTENDED
   if (Debug) fprintf (stdout, "OdsExtended: %d\n", OdsExtended);
   if (OdsExtended)
   {
      odsptr->Fab.fab$l_fna = odsptr->Fab.fab$l_dna = -1;  
      odsptr->Fab.fab$b_fns = odsptr->Fab.fab$b_dns = 0;
      odsptr->Fab.fab$l_nam = &odsptr->Naml;

      odsptr->NamlInUse = true;
      ENAMEL_RMS_NAML(odsptr->Naml)
      odsptr->Naml.naml$l_long_filename = FileSpec;
      odsptr->Naml.naml$l_long_filename_size = FileSpecLength;
      odsptr->Naml.naml$l_long_defname = DefaultSpec;
      odsptr->Naml.naml$l_long_defname_size = DefaultSpecLength;
      odsptr->Naml.naml$l_long_expand = odsptr->ExpFileName;
      odsptr->Naml.naml$l_long_expand_alloc = sizeof(odsptr->ExpFileName)-1;
      odsptr->Naml.naml$l_filesys_name = odsptr->SysFileName;
      odsptr->Naml.naml$l_filesys_name_alloc = sizeof(odsptr->SysFileName)-1;
      odsptr->Naml.naml$b_nop = NamNop;
   }
   else
#endif /* ODS_EXTENDED */
   {
      odsptr->Fab.fab$l_fna = FileSpec;  
      odsptr->Fab.fab$b_fns = FileSpecLength;
      odsptr->Fab.fab$l_dna = DefaultSpec;  
      odsptr->Fab.fab$b_dns = DefaultSpecLength;
      odsptr->Fab.fab$l_nam = &odsptr->Nam;

      odsptr->NamlInUse = false;
      odsptr->Nam = cc$rms_nam;
      odsptr->Nam.nam$l_esa = odsptr->ExpFileName;
      odsptr->Nam.nam$b_ess = ODS2_MAX_FILE_NAME_LENGTH;
      odsptr->Nam.nam$b_nop = NamNop;
   }

   if (AstFunctionPtr == NULL)
   {
      /* synchronous service */
      odsptr->Fab.fab$l_fop &= ~FAB$M_ASY;
      status = sys$parse (&odsptr->Fab, 0, 0);
      if (Debug) fprintf (stdout, "sys$parse() %%X%08.08X\n", status);
      OdsNamBlockAst (&odsptr->Fab);
      if (VMSok (status)) status = odsptr->Fab.fab$l_sts;
      return (status);
   }
   else
   {
      /* asynchronous service */
      odsptr->Fab.fab$l_fop |= FAB$M_ASY;
      status = sys$parse (&odsptr->Fab, &OdsNamBlockAst, &OdsNamBlockAst);
      if (Debug) fprintf (stdout, "sys$parse() %%X%08.08X\n", status);
      return (status);
   }
}

/****************************************************************************/
/*
Do an RMS sys$search().  OdsNamBlockAst() is always called to set up generic
pointers and other data of the various components of interest regardless of
whether a standard or long NAM structure is in use.

*** THIS FUNCTION IS SIGNIFICANTLY BROKEN ***

It does not use the 'AstParam' parameter as was intended.  It always delivers
with a pointer to FAB.  It should be fixed one day.  (MGD 05-DEC-2000)
*/ 

int OdsSearch
(
struct OdsStruct *odsptr,
void *AstFunctionPtr,
unsigned long AstParam
)
{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "OdsSearch() |%s|\n", odsptr->ExpFileName);

   odsptr->AstFunctionPtr = AstFunctionPtr;
   odsptr->AstParam = AstParam;

   odsptr->Fab.fab$l_ctx = odsptr;

#ifdef ODS_EXTENDED
   if (Debug) fprintf (stdout, "OdsExtended: %d\n", OdsExtended);
   if (OdsExtended)
   {
      odsptr->Naml.naml$l_long_result = odsptr->ResFileName;
      odsptr->Naml.naml$l_long_result_alloc = sizeof(odsptr->ResFileName)-1;
      odsptr->Naml.naml$l_filesys_name = odsptr->SysFileName;
      odsptr->Naml.naml$l_filesys_name_alloc = sizeof(odsptr->SysFileName)-1;
   }
   else
#endif /* ODS_EXTENDED */
   {
      odsptr->Nam.nam$l_rsa = odsptr->ResFileName;
      odsptr->Nam.nam$b_rss = ODS2_MAX_FILE_NAME_LENGTH;
   }

   if (AstFunctionPtr == NULL)
   {
      /* synchronous service */
      odsptr->Fab.fab$l_fop &= ~FAB$M_ASY;
      status = sys$search (&odsptr->Fab, 0, 0);
      if (Debug) fprintf (stdout, "sys$search() %%X%08.08X\n", status);
      OdsNamBlockAst (&odsptr->Fab);
      if (VMSok (status)) status = odsptr->Fab.fab$l_sts;
      return (status);
   }
   else
   {
      /* asynchronous service */
      odsptr->Fab.fab$l_fop |= FAB$M_ASY;
      status = sys$search (&odsptr->Fab, &OdsNamBlockAst, &OdsNamBlockAst);
      if (Debug) fprintf (stdout, "sys$search() %%X%08.08X\n", status);
      return (status);
   }
}

/****************************************************************************/
/*
Open/Parse/Search is complete.  If successful set the generic pointers to the
various NAM components of interest.  If an AST has been provided declare that
(can be called as an AST or directly).
*/ 

OdsNamBlockAst (struct FAB *FabPtr)

{
   register struct OdsStruct  *odsptr;

   int  status;
   void (*AstFunctionPtr)(struct FAB *FabPtr);

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "OdsNamBlockAst() %%X%08.08X\n", FabPtr->fab$l_sts);

   odsptr = (struct OdsStruct*)FabPtr->fab$l_ctx;
   FabPtr->fab$l_ctx = odsptr->AstParam;

   if (VMSok (FabPtr->fab$l_sts) ||
       FabPtr->fab$l_sts == RMS$_FNF ||
       FabPtr->fab$l_sts == RMS$_DNF ||
       FabPtr->fab$l_sts == RMS$_DEV)
   {
      /* file name has been parsed under these status */
#ifdef ODS_EXTENDED
      if (Debug) fprintf (stdout, "OdsExtended: %d\n", OdsExtended);
      if (OdsExtended)
      {
         odsptr->NamNodePtr = odsptr->Naml.naml$l_long_node;
         odsptr->NamNodeLength = odsptr->Naml.naml$l_long_node_size;
         odsptr->NamDevicePtr = odsptr->Naml.naml$l_long_dev;
         odsptr->NamDeviceLength = odsptr->Naml.naml$l_long_dev_size;
         odsptr->NamDirectoryPtr = odsptr->Naml.naml$l_long_dir;
         odsptr->NamDirectoryLength = odsptr->Naml.naml$l_long_dir_size;
         odsptr->NamNamePtr = odsptr->Naml.naml$l_long_name;
         odsptr->NamNameLength = odsptr->Naml.naml$l_long_name_size;
         odsptr->NamTypePtr = odsptr->Naml.naml$l_long_type;
         odsptr->NamTypeLength = odsptr->Naml.naml$l_long_type_size;
         odsptr->NamVersionPtr = odsptr->Naml.naml$l_long_ver;
         odsptr->NamVersionLength = odsptr->Naml.naml$l_long_ver_size;
         odsptr->ExpFileNameLength = odsptr->Naml.naml$l_long_expand_size;
         odsptr->ResFileNameLength = odsptr->Naml.naml$l_long_result_size;
         odsptr->Nam_fnb = odsptr->Naml.naml$l_fnb;

         odsptr->NamFileSysNamePtr = odsptr->Naml.naml$l_filesys_name;
         odsptr->NamFileSysNameLength = odsptr->Naml.naml$l_filesys_name_size;
         odsptr->NamFileSysNamePtr[odsptr->NamFileSysNameLength] = '\0';
      }
      else
#endif /* ODS_EXTENDED */
      {
         odsptr->NamNodePtr = odsptr->Nam.nam$l_node;
         odsptr->NamNodeLength = odsptr->Nam.nam$b_node;
         odsptr->NamDevicePtr = odsptr->Nam.nam$l_dev;
         odsptr->NamDeviceLength = odsptr->Nam.nam$b_dev;
         odsptr->NamDirectoryPtr = odsptr->Nam.nam$l_dir;
         odsptr->NamDirectoryLength = odsptr->Nam.nam$b_dir;
         odsptr->NamNamePtr =
            odsptr->NamFileSysNamePtr = odsptr->Nam.nam$l_name;
         odsptr->NamNameLength =
            odsptr->NamFileSysNameLength = odsptr->Nam.nam$b_name;
         odsptr->NamTypePtr = odsptr->Nam.nam$l_type;
         odsptr->NamTypeLength = odsptr->Nam.nam$b_type;
         odsptr->NamVersionPtr = odsptr->Nam.nam$l_ver;
         odsptr->NamVersionLength = odsptr->Nam.nam$b_ver;
         odsptr->ExpFileNameLength = odsptr->Nam.nam$b_esl;
         odsptr->ResFileNameLength = odsptr->Nam.nam$b_rsl;
         odsptr->Nam_fnb = odsptr->Nam.nam$l_fnb;
      }

      odsptr->ExpFileName[odsptr->ExpFileNameLength] = '\0';
      odsptr->ResFileName[odsptr->ResFileNameLength] = '\0';
      if (Debug)
         fprintf (stdout, "%d |%s|\n%d |%s|\n%d |%s|\n",
                  odsptr->ExpFileNameLength, odsptr->ExpFileName,
                  odsptr->ResFileNameLength, odsptr->ResFileName,
                  odsptr->NamFileSysNameLength, odsptr->NamFileSysNamePtr);
   }

   if (odsptr->AstFunctionPtr == NULL) return;
   AstFunctionPtr = odsptr->AstFunctionPtr;
   odsptr->AstFunctionPtr = NULL;
   (AstFunctionPtr)(&odsptr->Fab);
}

/****************************************************************************/
/*
Ensure parse internal data structures are released.
*/ 

OdsParseRelease (struct OdsStruct *odsptr)

{
   int  status;
   char  ExpFileName [16];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "OdsParseRelease()\n");

   if (!odsptr->ParseInUse) return;
   odsptr->ParseInUse = false;

   odsptr->Fab.fab$l_fna = "a:[b]c.d;";
   odsptr->Fab.fab$b_fns = 9;
   odsptr->Fab.fab$b_dns = 0;
   /* synchronous service */
   odsptr->Fab.fab$l_fop &= ~FAB$M_ASY;

#ifdef ODS_EXTENDED
   if (Debug) fprintf (stdout, "OdsExtended: %d\n", OdsExtended);
   if (OdsExtended)
   {
      odsptr->Naml.naml$l_long_expand = ExpFileName;
      odsptr->Naml.naml$l_long_expand_alloc = sizeof(ExpFileName);
      odsptr->Naml.naml$l_long_result = 0;
      odsptr->Naml.naml$b_nop = NAM$M_SYNCHK;
   }
   else
#endif /* ODS_EXTENDED */
   {
      odsptr->Nam.nam$l_esa = ExpFileName;
      odsptr->Nam.nam$b_ess = ODS2_MAX_FILE_NAME_LENGTH;
      odsptr->Nam.nam$l_rlf = 0;
      odsptr->Nam.nam$b_nop = NAM$M_SYNCHK;
   }

   status = sys$parse (&odsptr->Fab, 0, 0);
   if (Debug) fprintf (stdout, "sys$parse() %%X%08.08X\n", status);
}

/****************************************************************************/
/*
Place a terminating null in the 'ExpFileName' appropriate to whether it is a
directory specific, file specification without version, or with version, and
adjust '...Length's as necessary.  This function can only be used after parse
using OdsParse() or open using OdsOpen().
*/ 

int OdsParseTerminate (struct OdsStruct *odsptr)

{
   register char  *cptr, *sptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "OdsParseTerminate()\n%d |%s|\n%d |%s|\n",
               odsptr->ExpFileNameLength, odsptr->ExpFileName,
               odsptr->NamFileSysNameLength, odsptr->NamFileSysNamePtr);

   if (!(odsptr->ExpFileNameLength || odsptr->ResFileNameLength))
      return (SS$_ABORT);

   if (odsptr->NamNamePtr == odsptr->NamTypePtr &&
       odsptr->NamTypeLength <= 1)
   {
      /* no name, no type; a directory specification (with possible version) */
      if (odsptr->Nam_fnb & NAM$M_EXP_VER ||
          odsptr->Nam_fnb & NAM$M_WILD_VER)
      {
         /* with version, remove that annoying single period */
         sptr = (cptr = odsptr->NamNamePtr) + 1;
         while (*sptr) *cptr++ = *sptr++;
         *cptr = '\0';
         odsptr->NamVersionPtr = odsptr->NamNamePtr;
         odsptr->NamTypeLength = 0;

#ifdef ODS_EXTENDED
         if (Debug) fprintf (stdout, "OdsExtended: %d\n", OdsExtended);
         if (OdsExtended && odsptr->NamFileSysNameLength)
         {
            sptr = (cptr = odsptr->NamFileSysNamePtr) + 1;
            while (*sptr) *cptr++ = *sptr++;
            *cptr = '\0';
            odsptr->NamFileSysNameLength--;
         }
#endif /* ODS_EXTENDED */
      }
      else
      {
         /* just lop it off at the directory terminator */
         odsptr->NamNamePtr[0] = '\0';
         odsptr->NamFileSysNamePtr = "";
         odsptr->NamTypeLength = odsptr->NamVersionLength =
            odsptr->NamFileSysNameLength = 0;
      }
   }
   else
   if (odsptr->NamTypeLength <= 1)
   {
      /* name but no type (with possible version) */
      if (odsptr->Nam_fnb & NAM$M_EXP_VER ||
          odsptr->Nam_fnb & NAM$M_WILD_VER)
      {
         /* remove that annoying single period */
         sptr = (cptr = odsptr->NamTypePtr) + 1;
         while (*sptr) *cptr++ = *sptr++;
         *cptr = '\0';
         odsptr->NamVersionPtr = odsptr->NamTypePtr;
         odsptr->NamTypeLength = 0;

#ifdef ODS_EXTENDED
         if (Debug) fprintf (stdout, "OdsExtended: %d\n", OdsExtended);
         if (OdsExtended && odsptr->NamFileSysNameLength)
         {
            cptr = odsptr->NamFileSysNamePtr + odsptr->NamFileSysNameLength;
            while (cptr > odsptr->NamFileSysNamePtr && *cptr != '.') cptr--;
            if (*cptr == '.')
            {
               sptr = cptr + 1;
               while (*sptr) *cptr++ = *sptr++;
               *cptr = '\0';
               odsptr->NamFileSysNameLength = cptr - odsptr->NamFileSysNamePtr;
            }
         }
#endif /* ODS_EXTENDED */
      }
      else
      {
         /* no type and no version supplied */
         (odsptr->NamVersionPtr = odsptr->NamTypePtr)[0] = '\0';
         odsptr->NamTypeLength = odsptr->NamVersionLength = 0;

#ifdef ODS_EXTENDED
         if (Debug) fprintf (stdout, "OdsExtended: %d\n", OdsExtended);
         if (OdsExtended && odsptr->NamFileSysNameLength)
         {
            cptr = odsptr->NamFileSysNamePtr + odsptr->NamFileSysNameLength;
            while (cptr > odsptr->NamFileSysNamePtr && *cptr != '.') cptr--;
            if (*cptr == '.')
            {
               *cptr = '\0';
               odsptr->NamFileSysNameLength = cptr - odsptr->NamFileSysNamePtr;
            }
         }
#endif /* ODS_EXTENDED */
      }
   }
   else
   if (odsptr->Nam_fnb & NAM$M_EXP_VER ||
       odsptr->Nam_fnb & NAM$M_WILD_VER)
   {
      /* a type and a version supplied */
      odsptr->NamVersionPtr[odsptr->NamVersionLength] = '\0';
   }
   else
   {
      /* a type but no version supplied */
      odsptr->NamVersionPtr[0] = '\0';
      odsptr->NamVersionLength = 0;

#ifdef ODS_EXTENDED
      if (Debug) fprintf (stdout, "OdsExtended: %d\n", OdsExtended);
      if (OdsExtended && odsptr->NamFileSysNameLength)
      {
         cptr = odsptr->NamFileSysNamePtr + odsptr->NamFileSysNameLength;
         while (cptr > odsptr->NamFileSysNamePtr && *cptr != ';') cptr--;
         if (*cptr == ';')
         {
            *cptr = '\0';
            odsptr->NamFileSysNameLength = cptr - odsptr->NamFileSysNamePtr;
         }
      }
#endif /* ODS_EXTENDED */
   }

   if (odsptr->ResFileNameLength)
      odsptr->ResFileNameLength = odsptr->NamVersionPtr -
                                  odsptr->ResFileName;
   else
      odsptr->ExpFileNameLength = odsptr->NamVersionPtr -
                                  odsptr->ExpFileName;

   if (Debug)
      fprintf (stdout, "exp: %d res:%d |%s|\n%d |%s|\n",
               odsptr->ExpFileNameLength, odsptr->ResFileNameLength,
               odsptr->NamNodePtr,
               odsptr->NamFileSysNameLength, odsptr->NamFileSysNamePtr);

   return (SS$_NORMAL);
}

/****************************************************************************/
/*
Using the information in the ODS structure NAM field queue an ACP I/O to
retrieve file information.  Of course, this function can only be used after
parse using OdsParse().  For simplicity retrieves all information of interest
to all users of the function regardless of whether an individual user is
interested in all information!  Any AST routine *MUST* deassign the channel
after use and before continuing.

This function uses the ACP-QIO interface detailed in the "OpenVMS I/O User's 
Reference Manual", and is probably as fast as we can get for this type of file
system functionality!
*/ 

int OdsFileAcpInfo
(
struct OdsStruct *odsptr,
void *AstFunctionPtr,
unsigned long AstParam
)

{
   static $DESCRIPTOR (DeviceDsc, "");

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "OdsFileAcpInfo()\n");

   /* assign a channel to the disk device containing the file */
   DeviceDsc.dsc$a_pointer = odsptr->NamDevicePtr;
   DeviceDsc.dsc$w_length = odsptr->NamDeviceLength;
   if (Debug)
      fprintf (stdout, "device |%*.*s|\n",
               DeviceDsc.dsc$w_length, DeviceDsc.dsc$w_length,
               DeviceDsc.dsc$a_pointer);

   status = sys$assign (&DeviceDsc, &odsptr->AcpInfo.Channel, 0, 0, 0);
   if (Debug) fprintf (stdout, "sys$assign() %%X%08.08X\n", status);
   if (VMSnok (status))
   {
      odsptr->AcpInfo.AcpIOsb.Status = status; 
      if (AstFunctionPtr == NULL) return (status);
      SysDclAst (AstFunctionPtr, AstParam);
      return (status);
   }

   /* set up the File Information Block for the ACP interface */
   odsptr->AcpInfo.FileFibAcpDsc.dsc$w_length = sizeof(struct fibdef);
   odsptr->AcpInfo.FileFibAcpDsc.dsc$a_pointer = &odsptr->AcpInfo.FileFib;

   memset (&odsptr->AcpInfo.FileFib, 0, sizeof(struct fibdef));

#ifdef ODS_EXTENDED
   if (Debug) fprintf (stdout, "OdsExtended: %d\n", OdsExtended);
   if (OdsExtended)
   {
      odsptr->AcpInfo.FileNameAcpDsc.dsc$a_pointer =
         odsptr->Naml.naml$l_filesys_name;
      odsptr->AcpInfo.FileNameAcpDsc.dsc$w_length =
         odsptr->Naml.naml$l_filesys_name_size;

      memcpy (&odsptr->AcpInfo.FileFib.fib$w_did,
              &odsptr->Naml.naml$w_did,
              sizeof(odsptr->AcpInfo.FileFib.fib$w_did));

      odsptr->AcpInfo.FileFib.fib$b_name_format_in = FIB$C_ISO_LATIN;
      odsptr->AcpInfo.FileFib.fib$b_name_format_out = FIB$C_ISO_LATIN;
      odsptr->AcpInfo.FileFib.fib$w_nmctl = FIB$M_NAMES_8BIT;
   }
   else
#endif /* ODS_EXTENDED */
   {
      odsptr->AcpInfo.FileNameAcpDsc.dsc$a_pointer = odsptr->NamNamePtr;
      odsptr->AcpInfo.FileNameAcpDsc.dsc$w_length = odsptr->NamNameLength +
                                                    odsptr->NamTypeLength +
                                                    odsptr->NamVersionLength;
      memcpy (&odsptr->AcpInfo.FileFib.fib$w_did,
              &odsptr->Nam.nam$w_did,
              sizeof(odsptr->AcpInfo.FileFib.fib$w_did));
   }

   if (Debug)
      fprintf (stdout, "name |%*.*s|\n",
               odsptr->AcpInfo.FileNameAcpDsc.dsc$w_length,
               odsptr->AcpInfo.FileNameAcpDsc.dsc$w_length,
               odsptr->AcpInfo.FileNameAcpDsc.dsc$a_pointer);

   odsptr->AcpInfo.FileAtr[0].atr$w_size = sizeof(odsptr->AcpInfo.CdtBinTime);
   odsptr->AcpInfo.FileAtr[0].atr$w_type = ATR$C_CREDATE;
   odsptr->AcpInfo.FileAtr[0].atr$l_addr = &odsptr->AcpInfo.CdtBinTime;
   odsptr->AcpInfo.FileAtr[1].atr$w_size = sizeof(odsptr->AcpInfo.RdtBinTime);
   odsptr->AcpInfo.FileAtr[1].atr$w_type = ATR$C_REVDATE;
   odsptr->AcpInfo.FileAtr[1].atr$l_addr = &odsptr->AcpInfo.RdtBinTime;
   odsptr->AcpInfo.FileAtr[2].atr$w_size = sizeof(odsptr->AcpInfo.AtrUic);
   odsptr->AcpInfo.FileAtr[2].atr$w_type = ATR$C_UIC;
   odsptr->AcpInfo.FileAtr[2].atr$l_addr = &odsptr->AcpInfo.AtrUic;
   odsptr->AcpInfo.FileAtr[3].atr$w_size = sizeof(odsptr->AcpInfo.AtrFpro);
   odsptr->AcpInfo.FileAtr[3].atr$w_type = ATR$C_FPRO;
   odsptr->AcpInfo.FileAtr[3].atr$l_addr = &odsptr->AcpInfo.AtrFpro;
   odsptr->AcpInfo.FileAtr[4].atr$w_size = sizeof(odsptr->AcpInfo.RecAttr);
   odsptr->AcpInfo.FileAtr[4].atr$w_type = ATR$C_RECATTR;
   odsptr->AcpInfo.FileAtr[4].atr$l_addr = &odsptr->AcpInfo.RecAttr;
   odsptr->AcpInfo.FileAtr[5].atr$w_size =
      odsptr->AcpInfo.FileAtr[5].atr$w_type =
      odsptr->AcpInfo.FileAtr[5].atr$l_addr = 0;

   if (AstFunctionPtr == NULL)
   {
      status = sys$qiow (0, odsptr->AcpInfo.Channel, IO$_ACCESS,
                         &odsptr->AcpInfo.AcpIOsb, 0, 0, 
                         &odsptr->AcpInfo.FileFibAcpDsc,
                         &odsptr->AcpInfo.FileNameAcpDsc, 0, 0,
                         &odsptr->AcpInfo.FileAtr, 0);
      sys$dassgn (odsptr->AcpInfo.Channel);
      odsptr->AcpInfo.Channel = 0;
      if (VMSok (status)) status = odsptr->AcpInfo.AcpIOsb.Status;
   }
   else
      status = sys$qio (0, odsptr->AcpInfo.Channel, IO$_ACCESS,
                        &odsptr->AcpInfo.AcpIOsb, AstFunctionPtr, AstParam, 
                        &odsptr->AcpInfo.FileFibAcpDsc,
                        &odsptr->AcpInfo.FileNameAcpDsc, 0, 0,
                        &odsptr->AcpInfo.FileAtr, 0);

   if (Debug) fprintf (stdout, "sys$qio() %%X%08.08X\n", status);
   if (VMSnok (status))
   {
      odsptr->AcpInfo.AcpIOsb.Status = status;
      if (AstFunctionPtr != NULL) SysDclAst (AstFunctionPtr, AstParam);
   }
   return (status);
}

/****************************************************************************/
/*
Using the information in the ODS structure NAM field queue an ACP I/O to modify
selected file information.  This function can only be used after parse using
OdsParse().  Any AST *MUST* deassign the channel after use and before
continuing.

This function uses the ACP-QIO interface detailed in the "OpenVMS I/O User's 
Reference Manual", and is probably as fast as we can get for this type of file
system functionality!
*/ 

int OdsFileAcpModify
(
struct OdsStruct *odsptr,
unsigned short *ProtectionMaskPtr,
unsigned short *VersionLimitPtr,
void *AstFunctionPtr,
unsigned long AstParam
)

{
   static $DESCRIPTOR (DeviceDsc, "");

   int  status,
        idx;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "OdsFileAcpModify() %d %d\n",
               ProtectionMaskPtr, VersionLimitPtr);

   /* assign a channel to the disk device containing the file */
   DeviceDsc.dsc$a_pointer = odsptr->NamDevicePtr;
   DeviceDsc.dsc$w_length = odsptr->NamDeviceLength;
   if (Debug)
      fprintf (stdout, "device |%*.*s|\n",
               DeviceDsc.dsc$w_length, DeviceDsc.dsc$w_length,
               DeviceDsc.dsc$a_pointer);

   status = sys$assign (&DeviceDsc, &odsptr->AcpInfo.Channel, 0, 0, 0);
   if (Debug) fprintf (stdout, "sys$assign() %%X%08.08X\n", status);
   if (VMSnok (status))
   {
      odsptr->AcpInfo.AcpIOsb.Status = status; 
      if (AstFunctionPtr == NULL) return (status);
      SysDclAst (AstFunctionPtr, AstParam);
      return (status);
   }

   /* set up the File Information Block for the ACP interface */
   odsptr->AcpInfo.FileFibAcpDsc.dsc$w_length = sizeof(struct fibdef);
   odsptr->AcpInfo.FileFibAcpDsc.dsc$a_pointer = &odsptr->AcpInfo.FileFib;

   memset (&odsptr->AcpInfo.FileFib, 0, sizeof(struct fibdef));

#ifdef ODS_EXTENDED
   if (Debug) fprintf (stdout, "OdsExtended: %d\n", OdsExtended);
   if (OdsExtended)
   {
      odsptr->AcpInfo.FileNameAcpDsc.dsc$a_pointer =
         odsptr->Naml.naml$l_filesys_name;
      odsptr->AcpInfo.FileNameAcpDsc.dsc$w_length =
         odsptr->Naml.naml$l_filesys_name_size;

      memcpy (&odsptr->AcpInfo.FileFib.fib$w_did,
              &odsptr->Naml.naml$w_did,
              sizeof(odsptr->AcpInfo.FileFib.fib$w_did));

      odsptr->AcpInfo.FileFib.fib$b_name_format_in = FIB$C_ISO_LATIN;
      odsptr->AcpInfo.FileFib.fib$b_name_format_out = FIB$C_ISO_LATIN;
      odsptr->AcpInfo.FileFib.fib$w_nmctl = FIB$M_NAMES_8BIT;
   }
   else
#endif /* ODS_EXTENDED */
   {
      odsptr->AcpInfo.FileNameAcpDsc.dsc$a_pointer = odsptr->NamNamePtr;
      odsptr->AcpInfo.FileNameAcpDsc.dsc$w_length = odsptr->NamNameLength +
                                                    odsptr->NamTypeLength +
                                                    odsptr->NamVersionLength;
      memcpy (&odsptr->AcpInfo.FileFib.fib$w_did,
              &odsptr->Nam.nam$w_did,
              sizeof(odsptr->AcpInfo.FileFib.fib$w_did));
   }

   if (Debug)
      fprintf (stdout, "name |%*.*s|\n",
               odsptr->AcpInfo.FileNameAcpDsc.dsc$w_length,
               odsptr->AcpInfo.FileNameAcpDsc.dsc$w_length,
               odsptr->AcpInfo.FileNameAcpDsc.dsc$a_pointer);

   if (VersionLimitPtr != NULL)
      odsptr->AcpInfo.FileFib.fib$w_verlimit = *VersionLimitPtr;

   idx = 0;
   if (ProtectionMaskPtr != NULL)
   {
      odsptr->AcpInfo.FileAtr[idx].atr$w_size = sizeof(*ProtectionMaskPtr);
      odsptr->AcpInfo.FileAtr[idx].atr$w_type = ATR$C_FPRO;
      odsptr->AcpInfo.FileAtr[idx].atr$l_addr = ProtectionMaskPtr;
      idx++;
   }
   odsptr->AcpInfo.FileAtr[idx].atr$w_size =
      odsptr->AcpInfo.FileAtr[idx].atr$w_type =
      odsptr->AcpInfo.FileAtr[idx].atr$l_addr = 0;

   if (AstFunctionPtr == NULL)
   {
      status = sys$qiow (0, odsptr->AcpInfo.Channel, IO$_MODIFY,
                         &odsptr->AcpInfo.AcpIOsb, 0, 0, 
                         &odsptr->AcpInfo.FileFibAcpDsc,
                         &odsptr->AcpInfo.FileNameAcpDsc, 0, 0,
                         &odsptr->AcpInfo.FileAtr, 0);
      sys$dassgn (odsptr->AcpInfo.Channel);
      odsptr->AcpInfo.Channel = 0;
      if (VMSok (status)) status = odsptr->AcpInfo.AcpIOsb.Status;
   }
   else
      status = sys$qio (0, odsptr->AcpInfo.Channel, IO$_MODIFY,
                        &odsptr->AcpInfo.AcpIOsb, AstFunctionPtr, AstParam, 
                        &odsptr->AcpInfo.FileFibAcpDsc,
                        &odsptr->AcpInfo.FileNameAcpDsc, 0, 0,
                        &odsptr->AcpInfo.FileAtr, 0);

   if (Debug) fprintf (stdout, "sys$qio() %%X%08.08X\n", status);
   if (VMSnok (status))
   {
      odsptr->AcpInfo.AcpIOsb.Status = status;
      if (AstFunctionPtr != NULL) SysDclAst (AstFunctionPtr, AstParam);
   }
   return (status);
}

/*****************************************************************************/
/*
Return success status if the specified file name exists in the specified
directory, error otherwise.  This function completes synchronously!
*/ 

int OdsFileExists
(
char *Directory,
char *FileName
)
{
   int  status;
   char  ExpFileName [ODS_MAX_FILE_NAME_LENGTH+1];
   struct FAB  SearchFab;
   struct NAM  SearchNam;
#ifdef ODS_EXTENDED
   struct NAML  SearchNaml;
#endif

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "OdsFileExists() |%s|%s|\n", Directory, FileName);

   SearchFab = cc$rms_fab;
   SearchFab.fab$l_fop = FAB$M_NAM;
   /* synchronous service */
   SearchFab.fab$l_fop &= ~FAB$M_ASY;

#ifdef ODS_EXTENDED
   if (Debug) fprintf (stdout, "OdsExtended: %d\n", OdsExtended);
   if (OdsExtended)
   {
      SearchFab.fab$l_fna = SearchFab.fab$l_dna = -1;  
      SearchFab.fab$b_fns = SearchFab.fab$b_dns = 0;
      SearchFab.fab$l_nam = &SearchNaml;

      ENAMEL_RMS_NAML(SearchNaml)
      SearchNaml.naml$l_long_defname = Directory;
      SearchNaml.naml$l_long_defname_size = strlen(Directory);
      SearchNaml.naml$l_long_filename = FileName;
      SearchNaml.naml$l_long_filename_size = strlen(FileName);
      SearchNaml.naml$l_long_expand = ExpFileName;
      SearchNaml.naml$l_long_expand_alloc = sizeof(ExpFileName)-1;
   }
   else
#endif /* ODS_EXTENDED */
   {
      SearchFab.fab$l_dna = Directory;
      SearchFab.fab$b_dns = strlen(Directory);
      SearchFab.fab$l_fna = FileName;
      SearchFab.fab$b_fns = strlen(FileName);
      SearchFab.fab$l_nam = &SearchNam;

      SearchNam = cc$rms_nam;
      SearchNam.nam$l_esa = ExpFileName;
      SearchNam.nam$b_ess = ODS2_MAX_FILE_NAME_LENGTH;
   }

   status = sys$parse (&SearchFab, 0, 0);
   if (Debug) fprintf (stdout, "sys$parse() %%X%08.08X\n", status);

   if (VMSok (status))
   {
      status = sys$search (&SearchFab, 0, 0);
      if (Debug) fprintf (stdout, "sys$search() %%X%08.08X\n", status);
   }

   /* release parse and search internal data structures */
   SearchFab.fab$l_fna = "a:[b]c.d;";
   SearchFab.fab$b_fns = 9;
   SearchFab.fab$b_dns = 0;
#ifdef ODS_EXTENDED
   if (OdsExtended)
   {
      SearchNaml.naml$l_long_result = 0;
      SearchNaml.naml$b_nop = NAM$M_SYNCHK;
   }
   else
#endif /* ODS_EXTENDED */
   {
      SearchNam.nam$l_rlf = 0;
      SearchNam.nam$b_nop = NAM$M_SYNCHK;
   }
   sys$parse (&SearchFab, 0, 0);

   return (status);
}

/*****************************************************************************/
/*
Given a file or directory specification in 'FileName' generate the file name
of the directory file.

(e.g. "DEVICE:[DIR1]DIR2.DIR" from "DEVICE:[DIR1.DIR2]FILE.EXT",
      "DEVICE:[DIR1]DIR2.DIR" from "DEVICE:[DIR1.DIR2]",
 and  "DEVICE:[000000]DIR1.DIR" from "DEVICE:[DIR1]", etc.)

Attempts to improve the perfomance of this function by storing the previous
file specification processed and the previous directory file name result.  If
this file specification directory part is the same as the previous directory
part then just return the previous result!
*/ 
 
int OdsNameOfDirectoryFile
(
char *FileName,
int FileNameLength,
char *DirFileNamePtr,
int *DirFileLengthPtr
)
{
   static int  DirFileNameBufferLength = 0;
   static char  FileNameBuffer [ODS_MAX_FILE_NAME_LENGTH+1],
                DirFileNameBuffer [ODS_MAX_FILE_NAME_LENGTH+1];

   register char  *cptr, *fptr, *sptr, *zptr;

   int  status;
   unsigned long  Nam_fnb;
   char  ExpFileName [ODS_MAX_FILE_NAME_LENGTH+1];
   struct FAB  ParseFab;
   struct NAM  ParseNam;
#ifdef ODS_EXTENDED
   struct NAML  ParseNaml;
#endif

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "OdsNameOfDirectoryFile() |%s|%s|%s|\n",
               FileName, FileNameBuffer, DirFileNameBuffer);

   if (!FileNameLength) FileNameLength = strlen(FileName);

   DirFileNamePtr[*DirFileLengthPtr = 0] = '\0';

   /* check if this has the same directory components as the last one */
   sptr = FileNameBuffer;
   cptr = FileName;
   while (toupper(*cptr) == toupper(*sptr) && *sptr != ']' && *cptr != ']')
   {
      *sptr++;
      *cptr++;
   }
   if (*cptr == ']' && *sptr == ']' && *(sptr-1) != '.' && *(cptr-1) != '.')
   {
      /* it does! return the result of the last one */
      strcpy (DirFileNamePtr, DirFileNameBuffer);
      *DirFileLengthPtr = DirFileNameBufferLength;
      if (Debug) fprintf (stdout, "buffer! |%s|\n", DirFileNamePtr);
      return (SS$_NORMAL);
   }

   ParseFab = cc$rms_fab;

#ifdef ODS_EXTENDED
   if (Debug) fprintf (stdout, "OdsExtended: %d\n", OdsExtended);
   if (OdsExtended)
   {
      ParseFab.fab$l_fna = -1;
      ParseFab.fab$b_fns = 0;
      ParseFab.fab$l_nam = &ParseNaml;

      ENAMEL_RMS_NAML(ParseNaml)
      ParseNaml.naml$l_long_filename = FileName;
      ParseNaml.naml$l_long_filename_size = FileNameLength;
      ParseNaml.naml$l_long_expand = ExpFileName;
      ParseNaml.naml$l_long_expand_alloc = sizeof(ExpFileName)-1;
      ParseNaml.naml$b_nop = NAM$M_NOCONCEAL;

      if (VMSnok (status = sys$parse (&ParseFab, 0, 0)))
         return (status);

      ParseNaml.naml$l_long_ver[ParseNaml.naml$l_long_ver_size] = '\0';
      if (Debug) fprintf (stdout, "ExpFileName |%s|\n", ExpFileName);
      fptr = ParseNaml.naml$l_long_name - 1;
   }
   else
#endif /* ODS_EXTENDED */
   {
      ParseFab.fab$l_fna = FileName;
      ParseFab.fab$b_fns = FileNameLength;
      ParseFab.fab$l_nam = &ParseNam;

      ParseNam = cc$rms_nam;
      ParseNam.nam$l_esa = ExpFileName;
      ParseNam.nam$b_ess = ODS2_MAX_FILE_NAME_LENGTH;
      ParseNam.nam$b_nop = NAM$M_NOCONCEAL;

      if (VMSnok (status = sys$parse (&ParseFab, 0, 0)))
         return (status);

      ParseNam.nam$l_ver[ParseNam.nam$b_ver] = '\0';
      if (Debug) fprintf (stdout, "ExpFileName |%s|\n", ExpFileName);
      fptr = ParseNam.nam$l_name - 1;
   }

#ifdef ODS_EXTENDED
   if (OdsExtended)
      Nam_fnb = ParseNaml.naml$l_fnb;
   else
#endif /* ODS_EXTENDED */
      Nam_fnb = ParseNam.nam$l_fnb;

   if (Nam_fnb & NAM$M_SEARCH_LIST)
   {
      /* search list, look for the actual file/directory */
      status = sys$search (&ParseFab, 0, 0);
      if (Debug) fprintf (stdout, "sys$search() %%X%08.08X\n", status);
      if (VMSok (status)) status = ParseFab.fab$l_sts;
      if (VMSnok (status))
      {
         /* release parse and search internal data structures */
         ParseFab.fab$l_fna = "a:[b]c.d;";
         ParseFab.fab$b_fns = 9;
         ParseFab.fab$b_dns = 0;
#ifdef ODS_EXTENDED
         if (OdsExtended)
         {
            ParseNaml.naml$l_long_result = 0;
            ParseNaml.naml$b_nop = NAM$M_SYNCHK;
         }
         else
#endif /* ODS_EXTENDED */
         {
            ParseNam.nam$l_rlf = 0;
            ParseNam.nam$b_nop = NAM$M_SYNCHK;
         }
         sys$parse (&ParseFab, 0, 0);
         return (status);
      }
   }

   while (fptr > ExpFileName && *fptr != '[' && *fptr != '.') fptr--;
   if (fptr > ExpFileName && fptr[-1] == ']')
   {
      /* concealed, logical device */
      fptr -= 2;
      if (!memcmp (fptr, ".][000000]", 10))
      {
         fptr--;
         while (fptr > ExpFileName && *fptr != '[' && *fptr != '.') fptr--;
      }
   }

   zptr = (sptr = DirFileNameBuffer) + sizeof(DirFileNameBuffer);
   if (!memcmp (fptr, "[000000]", 8) || !memcmp (fptr, "[000000.]", 9))
   {
#ifdef ODS_EXTENDED
      if (OdsExtended)
      {
         for (cptr = ParseNaml.naml$l_long_dev;
              cptr < fptr && sptr < zptr;
              *sptr++ = *cptr++);
      }
      else
#endif /* ODS_EXTENDED */
      {
         for (cptr = ParseNam.nam$l_dev;
              cptr < fptr && sptr < zptr;
              *sptr++ = *cptr++);
      }
      for (cptr = "[000000]000000.DIR";
           *cptr && sptr < zptr;
           *sptr++ = *cptr++);
      if (sptr >= zptr) sptr--;
      *sptr = '\0';
   }
   else
   if (*fptr == '[')
   {
#ifdef ODS_EXTENDED
      if (OdsExtended)
      {
         for (cptr = ParseNaml.naml$l_long_dev;
              cptr < fptr && sptr < zptr;
              *sptr++ = *cptr++);
      }
      else
#endif /* ODS_EXTENDED */
      {
         for (cptr = ParseNam.nam$l_dev;
              cptr < fptr && sptr < zptr;
              *sptr++ = *cptr++);
      }
      for (cptr = "[000000]"; *cptr && sptr < zptr; *sptr++ = *cptr++);
      if (fptr[0] == '.' && fptr[1] == ']')
         fptr += 3;
      else
         fptr++;
      while (*fptr && *fptr != '.' && *fptr != ']' && sptr < zptr)
         *sptr++ = *fptr++;
      for (cptr = ".DIR"; *cptr && sptr < zptr; *sptr++ = *cptr++);
      if (sptr >= zptr) sptr--;
      *sptr = '\0';
   }
   else
   {
#ifdef ODS_EXTENDED
      if (OdsExtended)
      {
         for (cptr = ParseNaml.naml$l_long_dev;
              cptr < fptr && sptr < zptr;
              *sptr++ = *cptr++);
      }
      else
#endif /* ODS_EXTENDED */
      {
         for (cptr = ParseNam.nam$l_dev;
              cptr < fptr && sptr < zptr;
              *sptr++ = *cptr++);
      }
      if (sptr < zptr) *sptr++ = ']';
      if (fptr[0] == '.' && fptr[1] == ']')
         fptr += 3;
      else
         fptr++;
      while (*fptr && *fptr != '.' && *fptr != ']' && sptr < zptr)
         *sptr++ = *fptr++;
      for (cptr = ".DIR"; *cptr && sptr < zptr; *sptr++ = *cptr++);
      if (sptr >= zptr) sptr--;
      *sptr = '\0';
   }

   /* buffer this (soon to be the previous) file name */
   strcpy (FileNameBuffer, FileName);

   /* copy out the generated directory file name */
   strcpy (DirFileNamePtr, DirFileNameBuffer);
   *DirFileLengthPtr = DirFileNameBufferLength = sptr - DirFileNameBuffer;

   if (Debug)
      fprintf (stdout, "DirFileNamePtr %d |%s|\n",
               *DirFileLengthPtr, DirFileNamePtr);

   /* release parse and search internal data structures */
   ParseFab.fab$l_fna = "a:[b]c.d;";
   ParseFab.fab$b_fns = 9;
   ParseFab.fab$b_dns = 0;
#ifdef ODS_EXTENDED
   if (OdsExtended)
   {
      ParseNaml.naml$l_long_result = 0;
      ParseNaml.naml$b_nop = NAM$M_SYNCHK;
   }
   else
#endif /* ODS_EXTENDED */
   {
      ParseNam.nam$l_rlf = 0;
      ParseNam.nam$b_nop = NAM$M_SYNCHK;
   }
   sys$parse (&ParseFab, 0, 0);

   return (SS$_NORMAL);
}

/****************************************************************************/

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    