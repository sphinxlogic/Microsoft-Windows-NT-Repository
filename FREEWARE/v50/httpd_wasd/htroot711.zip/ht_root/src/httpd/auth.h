/*****************************************************************************/
/*
                                 Auth.h
*/
/*****************************************************************************/

#ifndef AUTH_H_LOADED
#define AUTH_H_LOADED 1

#include "wasd.h"

/* some storage maximums */
#define  AUTH_MAX_DIGEST_RESPONSE      32
#define  AUTH_MAX_PASSWORD_LENGTH      31
#define  AUTH_MAX_REALM_GROUP_LENGTH   32
#define  AUTH_MAX_REALM_DESCR_LENGTH  127
#define  AUTH_MAX_USERNAME_LENGTH      15
#define  AUTH_MAX_FULLNAME_LENGTH      31
#define  AUTH_MAX_EMAIL_LENGTH        127
#define  AUTH_MAX_CONTACT_LENGTH      127
#define  AUTH_MAX_AGENT_PARAM_LENGTH   63
#define  AUTH_MAX_COOKIE_CACHE         32

#define  AUTH_LOGIN_COOKIE_NAME  "WASDlgn"

/* password minimum (when changing in HTADMIN.C) */
#define  AUTH_MIN_PASSWORD 6

/* maximum number of VMS identifiers in array */
#define  AUTH_MAX_VMS_IDENTIFIERS 127

/* size of static stroage allocated for sys$create_user_profile() use */
#define AUTH_CREATE_USER_PROFILE_SIZE 2048

/* constants used to identify authorization schemes */
#define  AUTH_SCHEME_BASIC   0x00000001
#define  AUTH_SCHEME_DIGEST  0x00000002

/* constants for bits for flags in HTA database */
#define  AUTH_FLAG_GET         0x00000001
#define  AUTH_FLAG_HEAD        0x00000002
#define  AUTH_FLAG_POST        0x00000004
#define  AUTH_FLAG_PUT         0x00000008
#define  AUTH_FLAG_DELETE      0x00000010
#define  AUTH_FLAG_TRACE       0x00000020
#define  AUTH_FLAG_HTTPS_ONLY  0x20000000
#define  AUTH_FLAG_MANAGER     0x40000000
#define  AUTH_FLAG_ENABLED     0x80000000

#define  AUTH_READWRITE_ACCESS  HTTP_METHOD_DELETE | \
                                HTTP_METHOD_GET | \
                                HTTP_METHOD_HEAD | \
                                HTTP_METHOD_POST | \
                                HTTP_METHOD_PUT

#define  AUTH_READONLY_ACCESS  HTTP_METHOD_GET | \
                               HTTP_METHOD_HEAD

#define  AUTH_WRITEONLY_ACCESS  HTTP_METHOD_POST | \
                                HTTP_METHOD_PUT

#define  AUTH_REALM_EXTERNAL     "EXTERNAL"
#define  AUTH_REALM_FAIL         "-FAIL-"
#define  AUTH_REALM_NONE         "NONE"
#define  AUTH_REALM_PROMISCUOUS  "PROMISCUOUS"
#define  AUTH_REALM_VMS          "VMS"
#define  AUTH_REALM_WORLD        "WORLD"

#define  AUTH_SOURCE_FAIL         1
#define  AUTH_SOURCE_NONE         2
#define  AUTH_SOURCE_WORLD        3
#define  AUTH_SOURCE_EXTERNAL     4
#define  AUTH_SOURCE_VMS          5
#define  AUTH_SOURCE_LIST         6
#define  AUTH_SOURCE_HTA          7
#define  AUTH_SOURCE_ID           8
#define  AUTH_SOURCE_WASD_ID      9
#define  AUTH_SOURCE_AGENT       10
#define  AUTH_SOURCE_PROMISCUOUS 11

#define  HTA_DIRECTORY     "HT_AUTH:"
#define  HTA_FILE_TYPE     ".$HTA"
#define  HTL_FILE_TYPE     ".$HTL"
#define  AUTH_AGENT_PATH   "/cgiauth-bin/"

/* bogus VMS status codes (errors), these can be passed back and detected */
#define  AUTH_DENIED_BY_FAIL      0x0fffff1a
#define  AUTH_DENIED_BY_GROUP     0x0fffff2a
#define  AUTH_DENIED_BY_HOSTNAME  0x0fffff3a
#define  AUTH_DENIED_BY_HOUR      0x0fffff4a
#define  AUTH_DENIED_BY_LOGIN     0x0fffff5a
#define  AUTH_DENIED_BY_LOGOUT    0x0fffff6a
#define  AUTH_DENIED_BY_NOCACHE   0x0fffff7a
#define  AUTH_DENIED_BY_OTHER     0x0fffff8a
#define  AUTH_DENIED_BY_PROTOCOL  0x0fffff9a
#define  AUTH_DENIED_BY_USERNAME  0x0fffffaa
#define  AUTH_DENIED_BY_REDIRECT  0x0fffffba
#define  AUTH_PENDING             0x0fffffca

#define  AUTH_RESTRICTED_FAIL "-FAIL-"
#define  AUTH_AGENT_PARAM_FAIL "-FAIL-"

/* identifier names controlling SYSUAF authentication with /SYSUAF=ID */
#define  AUTH_HTTPS_ONLY_VMS_ID        "WASD_HTTPS_ONLY"
#define  AUTH_NIL_ACCESS_VMS_ID        "WASD_NIL_ACCESS"
#define  AUTH_PASSWORD_CHANGE_VMS_ID   "WASD_PASSWORD_CHANGE"

/* identifier names controlling SYSUAF authentication with /SYSUAF=WASD */
#define  AUTH_WASD__GROUP_VMS_ID  "WASD_VMS__"
#define  AUTH_WASD_HTTPS_VMS_ID   "WASD_VMS_HTTPS"
#define  AUTH_WASD_PWD_VMS_ID     "WASD_VMS_PWD"
#define  AUTH_WASD_WRITE_VMS_ID   "WASD_VMS_RW"
#define  AUTH_WASD_READ_VMS_ID    "WASD_VMS_R"

/* when formatting can string */
#define  AUTH_CAN_FORMAT_SHORT  0
#define  AUTH_CAN_FORMAT_LONG   1
#define  AUTH_CAN_FORMAT_HTML   2

/**************/
/* structures */
/**************/

/*
   Store these structures naturally-aligned on AXP.
   Uses a bit more storage but makes access as efficient as possible.
*/

#ifdef __ALPHA
#   pragma member_alignment __save
#   pragma member_alignment
#endif

#define AuthCurrentDatabaseVersion 0x01

/* record structure of on-disk HTA database */
struct AuthHtRecordStruct
{
   char  UserName [AUTH_MAX_USERNAME_LENGTH+1];
   char  FullName [AUTH_MAX_FULLNAME_LENGTH+1];
   char  Email [AUTH_MAX_EMAIL_LENGTH+1];
   int  UserNameLength;
   unsigned long  Flags;
   unsigned long  HashedPwd [2];
   unsigned char  A1DigestLoCase [16];
   unsigned char  A1DigestUpCase [16];
   int  ChangeCount;
   unsigned long  LastChangeBinTime [2];
   int  AccessCount;
   unsigned long  LastAccessBinTime [2];
   int  FailureCount;
   unsigned long  LastFailureBinTime [2];
   unsigned long  AddedBinTime [2];
   char  Contact [AUTH_MAX_CONTACT_LENGTH+1];
   char  FillTo512Bytes [115];
   unsigned char  DatabaseVersion;
};

/* in-memory path authorization structure */
struct AuthPathRecordStruct
{
   struct AuthPathRecordStruct  *PrevPtr;
   struct AuthPathRecordStruct  *NextPtr;

   boolean  NoCache;

   int  AgentParameterLength,
        GroupReadLength,   
        GroupRestrictListLength,
        GroupWriteLength,   
        PathLength,
        RealmLength,
        RealmDescriptionLength,
        WorldRestrictListLength,
        VirtualServerHostPortLength;

   unsigned long  AuthGroupCan,
                  AuthWorldCan,
                  GroupReadVmsIdentifier,
                  GroupWriteVmsIdentifier,
                  RealmVmsIdentifier,
                  SourceRealm,
                  SourceGroupRead,
                  SourceGroupWrite,
                  VirtualServerHostNameHashValue;

   char  *AgentParameterPtr,
         *GroupReadPtr,
         *GroupRestrictListPtr,
         *GroupWritePtr,
         *PathPtr,
         *RealmPtr,
         *RealmAccessPtr,
         *RealmDescrPtr,
         *VirtualServerHostPortPtr,
         *WorldRestrictListPtr;

   /* string data is stored here and pointed to by above pointers */
};

/* in-memory user authentication cache structure */
struct AuthCacheRecordStruct
{
   /* this is the structure used by the VMS binary tree library functions */
   struct AuthCacheRecordStruct  *LeftLink;
   struct AuthCacheRecordStruct  *RightLink;
   unsigned short  Reserved;

   boolean  CaseLess,
            HttpsOnly,
            NoCache,
            SysUafAuthenticated,
            SysUafCanChangePwd,
            SysUafNilAccess;

   int  AccessCount,
        AgentParameterLength,
        AuthUserCan,
        BasicCount,
        DataBaseCount,
        DigestCount,
        FailureCount,
        GroupReadLength,
        GroupWriteLength,
        RealmLength,
        UserDetailsLength,
        UserNameLength;

   unsigned short  VmsUserProfileLength;

   unsigned long  SourceRealm,
                  SourceGroupRead,
                  SourceGroupWrite,
                  UaiPrimeDays,
                  UaiNetworkAccessP,
                  UaiNetworkAccessS,
                  UaiRemoteAccessP,
                  UaiRemoteAccessS;

   unsigned long  LastAccessBinTime [2];

   char  *UserDetailsPtr,
         *VmsUserProfilePtr;

   char  AgentParameter [AUTH_MAX_AGENT_PARAM_LENGTH+1],
         DigestResponse [AUTH_MAX_DIGEST_RESPONSE+1],
         GroupWrite [AUTH_MAX_REALM_GROUP_LENGTH+1],
         GroupRead [AUTH_MAX_REALM_GROUP_LENGTH+1],
         Password [AUTH_MAX_PASSWORD_LENGTH+1],
         Realm [AUTH_MAX_REALM_GROUP_LENGTH+1],
         UserName [AUTH_MAX_USERNAME_LENGTH+1];
};

/* structure used to hold an authorization database loaded from file */
struct AuthConfigStruct
{
   int  LineNumber,
        ProblemCount,
        ProblemReportLength;

   unsigned long  LoadBinTime [2],
                  RevBinTime [2];

   char  *LinePtr,
         *ProblemReportPtr;

   char  LoadFileName [ODS_MAX_FILE_NAME_LENGTH+1];

   struct AuthPathRecordStruct  *PathListHead,
                                *PathListTail;

   /* only used during HTTP request */
   struct RequestStruct  *RequestPtr;
};

#ifdef __ALPHA
#   pragma member_alignment __restore
#endif

/***********************/
/* function prototypes */
/***********************/

/*** AUTH.C prototypes ***/

Authorize (struct RequestStruct*, char*, int, void*);
AuthorizeRealm (struct RequestStruct*);
AuthorizeRealmCheck (struct RequestStruct*);
AuthorizeWasdId (struct RequestStruct*);
AuthorizeGroupWrite (struct RequestStruct*);
AuthorizeGroupWriteCheck (struct RequestStruct*);
AuthorizeGroupRead (struct RequestStruct*);
AuthorizeGroupReadCheck (struct RequestStruct*);
AuthorizeFinal (struct RequestStruct*);
AuthorizeResponse (struct RequestStruct*);

char* AuthCanString (unsigned long, int);
int AuthDoAuthorization (struct RequestStruct*);
int AuthParseAuthorization (struct RequestStruct*);
char* AuthSourceString (char*, unsigned long);
int AuthVerifyPassword (struct RequestStruct*);

/*** AUTHAGENT.C prototypes ***/

AuthAgentBegin (struct RequestStruct*, char*, void*);
AuthAgentCallout (struct RequestStruct*);
AuthAgentCalloutResponseError (struct RequestStruct*);

/*** AUTHHTA.C prototypes ***/

int AuthReadHtDatabase (struct RequestStruct*, char*, boolean);
int AuthAccessHtDatabase (boolean, char*, char*, 
                          struct AuthHtRecordStruct*,
                          struct AuthHtRecordStruct*,
                          struct AuthHtRecordStruct*);

/*** AUTHHTL.C prototypes ***/

int AuthReadSimpleList (struct RequestStruct*, char*, boolean);

/*** AUTHCACHE.C prototypes ***/

int AuthUserResetRecord (char*, char*, char*);
int AuthCacheTreeFree ();
int AuthCacheAddRecord (struct AuthCacheRecordStruct*);
int AuthCacheFindRecord (struct AuthCacheRecordStruct*,
                         struct AuthCacheRecordStruct**);
int AuthCacheCheckLoginCookie (struct RequestStruct*);
int AuthCacheResetLoginCookie (struct RequestStruct*);
int AuthCacheSetLoginCookie (struct RequestStruct*);
int AuthCacheTreeAllocateRecord (struct AuthCacheRecordStruct*,
                                 struct AuthCacheRecordStruct**,
                                 unsigned long);
int AuthCacheTreeCompareRecord (struct AuthCacheRecordStruct*,
                                struct AuthCacheRecordStruct*,
                                unsigned long);
int AuthCacheTreeFreeRecord (struct AuthCacheRecordStruct*, unsigned long);
int AuthCacheTreeReport (struct RequestStruct*, void*);
int AuthCacheTreeReportRecord (struct AuthCacheRecordStruct*,
                               struct RequestStruct*);
int AuthCacheResetEntry (struct AuthCacheRecordStruct*,
                         struct AuthCacheRecordStruct*);
int AuthCacheTreeEntryReset (struct AuthCacheRecordStruct*,
                             struct AuthCacheRecordStruct*);

/*** AUTHCONFIG.C prototypes ***/

int AuthConfigInit();
int AuthConfigIdentifier (char*, unsigned long*);
int AuthConfigAdd (struct AuthConfigStruct*, char*,
                   char*, char*, unsigned long, unsigned long,
                   char*, unsigned long, unsigned long,
                   char*, unsigned long, unsigned long,
                   char*, char*, char*, char*,
                   unsigned long, unsigned long, boolean);
int AuthConfigFree (struct AuthConfigStruct*);
int AuthConfigRead (struct AuthConfigStruct*);
int AuthConfigReadStatus (struct AuthConfigStruct*, char*, ...);
int AuthConfigReload (struct RequestStruct*, void*);
int AuthConfigReport (struct RequestStruct*, void*, boolean, char*);
int AuthConfigReportNow (struct RequestStruct*, boolean,
                         struct AuthConfigStruct*, char*);
int AuthConfigSearch (struct RequestStruct*, struct AuthConfigStruct*, char*);

/*** AUTHVMS.C prototypes ***/

int AuthVmsCheckIdentifier (struct RequestStruct*);
int AuthVmsCheckUserAccess (struct RequestStruct*, char*, int);
int AuthVmsCheckWriteAccess (struct RequestStruct*, char*, int);
int AuthVmsCreateHttpdProfile ();
int AuthVmsCreateUserProfile (struct RequestStruct*);
int AuthVmsHoldsIdentifier (struct RequestStruct*, char*, unsigned long);
int AuthVmsHoldsWasdGroupIdent (struct RequestStruct*, char*);
int AuthVmsLoadIdentifiers (struct RequestStruct*, unsigned long);
int AuthVmsVerifyPassword (struct RequestStruct*,
                           struct AuthCacheRecordStruct*);

#endif /* AUTH_H_LOADED */

/*****************************************************************************/
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  