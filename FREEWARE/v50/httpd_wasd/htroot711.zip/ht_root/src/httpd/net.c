/*****************************************************************************/
/*
                                 Net.c

The networking essentials are based on DEC TCP/IP Services for OpenVMS (aka
UCX). The QIO interface was obviously chosen because of its asynchronous,
non-blocking capabilities. Although some functionalilty could have been
implemented using the BSD sockets abstraction and only the asynchronous I/O
done using the QIO I opted for working out the QIOs. It wasn't too difficult
and avoids the (slight) extra overhead of the sockets layer.

With resource wait explicitly enabled all sys$qio()s should wait until
resources become available. The only execption is ASTLM, a fundamental
requirement for this server. If SS$_EXQUOTA is returned from a sys$qio() (i.e.
without wait for completion, and therefore depending on AST delivery) then
EXIT THE SERVER with error status!

The 'ServiceStruct' structure has two groups of fields and performs two basic
roles. First, it provides a linked list which can be traversed to determine
from the destination IP address of a request which host was specified in a
(multi-homed) request. Second, for each unique port specified for the same
server the client components of the structure are used for the accept()ing of
requests.  Note that there may be more 'service' structures in the list than
actual sockets created (and client components used) because only one is
allocated against a given port even though the services may specify multiple
host names using that port.

The server identity is derived from the 'ServerHostName' (gethostname()) name
and the 'ServerPort' (which is the first port specified as a service, or the
port specified in the configuration or /PORT= qualifier).


VERSION HISTORY
---------------
22-NOV-2000  MGD  rework service creation
17-OCT-2000  MGD  modify SSL initialization so that "sharing" conditions
                  (same port on same IP address) are more easily identified
08-AUG-2000  MGD  client sockets C_SHARE for direct script output to BG:
17-JUN-2000  MGD  modifications for SERVICE.C requirements
10-MAY-2000  MGD  per-service session tracking,
                  per-service listen queue backlog (for Compaq TCP/IP 5.0ff)
29-APR-2000  MGD  proxy authorization
10-NOV-1999  MGD  add IO$_NOWAIT to NetWriteDirect()
25-OCT-1999  MGD  remove NETLIB support
10-OCT-1999  MGD  allow virtual services more latitude,
                  check for request supervisor request timeout,
                  add FULL_DUPLEX_CLOSE,
                  workaround TCPWARE 5.3-3 behaviour (Laishev@SMTP.DeltaTel.RU)
18-AUG-1999  MGD  bugfix; parsing certificate/key from service
11-JUN-1999  MGD  bugfix; NetTooBusy() sys$fao() charset,
                  bugfix; NetDummyReadAst() UCX IOsb by reference
26-MAY-1999  MGD  bugfix; NetShutdownSocket() AST handling
04-APR-1999  MGD  provide HTTP/0.9 header absorbtion (finally!)
15-JAN-1999  MGD  changed AST delivery algorithm
07-NOV-1998  MGD  WATCH facility
24-OCT-1998  MGD  allow SSL certificate to be specified per-service
08-APR-1998  MGD  allow legitimate connects to be CANCELed in NetAcceptAst()
19-JAN-1998  MGD  redesigned NetWriteBuffer()
27-NOV-1997  MGD  hmmm, rationalized AST processing by making network
                  writes always deliver an AST (implicit or explicit)
                  (causing ACCVIOs for the last couple of versions)
25-OCT-1997  MGD  changes to MsgFor() function
06-SEP-1997  MGD  multi-homed hosts and multi-port services
30-AUG-1997  MGD  bugfix; get server host name before starting logging
                  (woops, problem introduced with NETLIB)
09-AUG-1997  MGD  message database
23-JUL-1997  MGD  HTTPD v4.3, MultiNet dropped, using the NETLIB Library
01-FEB-1997  MGD  HTTPd version 4
27-SEP-1996  MGD  add dummy read for early error reporting
12-APR-1996  MGD  observed Multinet disconnection/zero-byte behaviour
                  (request now aborts if Multinet returns zero bytes)
03-JAN-1996  MGD  support for both DEC TCP/IP Services and TGV MultiNet
01-DEC-1995  MGD  NetWriteBuffered() for improving network I/O
20-DEC-1994  MGD  multi-threaded version
20-JUN-1994  MGD  single-threaded version
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <descrip.h>
#include <dvidef.h>
#include <iodef.h>
#include <psldef.h>
#include <ssdef.h>
#include <stsdef.h>

/* application-related header files */
#include "wasd.h"

#define WASD_MODULE "NET"

/******************/
/* global storage */
/******************/

boolean NetMultiHomedHost;

int  ConnectCountCurrent,
     ConnectCountTotal,
     ConnectCountConcurrentMax,
     NetAcceptBytLmRequired,
     NetListenBytLmRequired,
     NetReadBufferSize,
     OutputBufferSize,
     ServerHostNameLength;

char  ServerHostName [128],
      ServerHostPort [128+8];

$DESCRIPTOR (InetDeviceDsc, "UCX$DEVICE");

int  OptionEnabled = 1;

struct {
   unsigned short  Length;
   unsigned short  Parameter;
   char  *Address;
}

  ServerOption [] = {
   { sizeof(OptionEnabled), UCX$C_REUSEADDR, &OptionEnabled },
  },
  ServerSocketOption =
   { sizeof(ServerOption), UCX$C_SOCKOPT, &ServerOption },

  ServerShareOption [] = {
   { sizeof(OptionEnabled), UCX$C_SHARE, &OptionEnabled },
   { sizeof(OptionEnabled), UCX$C_REUSEADDR, &OptionEnabled },
  },
  ServerSocketShareOption =
   { sizeof(ServerShareOption), UCX$C_SOCKOPT, &ServerShareOption },

  /* not all UCX versions support FULL_DUPLEX_CLOSE, it'll be ignored! */
  ClientSockOpt [] =
   { sizeof(OptionEnabled), UCX$C_FULL_DUPLEX_CLOSE, &OptionEnabled },

  ClientSocketOption =
   { sizeof(ClientSockOpt), UCX$C_SOCKOPT, &ClientSockOpt };

struct {
   unsigned short  Protocol;
   unsigned char  Type;
   unsigned char  Family;
} TcpSocket = { UCX$C_TCP, INET_PROTYP$C_STREAM, UCX$C_AF_INET };

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern boolean  ControlExitRequested,
                ControlRestartRequested,
                ProtocolHttpsAvailable,
                ProtocolHttpsConfigured;

extern int  WatchEnabled,
            WatchItem,
            OutputBufferSize,
            ServiceCount,
            ServerPort;

extern unsigned long  ServiceHashTableMask,
                      ServiceHashTableEntries;

extern char  CliLogFileName[],
             ControlBuffer[],
             ErrorSanityCheck[],
             HttpdName,
             HttpdVersion,
             Utility[];

extern struct AccountingStruct  Accounting;
extern struct ConfigStruct  Config;
extern struct MsgStruct  Msgs;
extern struct RequestStruct  *WatchRequestPtr;
extern struct ServiceLoadStruct  ServiceLoad;
extern struct ServiceStruct  *ServiceListHead,
                             *ServiceListTail;
extern struct ServiceStruct  **ServiceHashTable;

/*****************************************************************************/
/*
Get local host (server) name.
*/ 

NetGetServerHostName ()

{
   register char  *cptr;

   int  status;
   unsigned short  Length;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetGetServerHostName()\n");

   if (gethostname (ServerHostName, sizeof(ServerHostName)) != 0)
      ErrorExitVmsStatus (0, strerror(errno), FI_LI);

   /* looks better if its all in lower case (host name is sometimes upper) */
   for (cptr = ServerHostName; *cptr; cptr++) *cptr = tolower(*cptr);
   ServerHostNameLength = cptr - ServerHostName;
   if (Debug) fprintf (stdout, "|%s|\n", ServerHostName);
}

/*****************************************************************************/
/*
It is only necessary to create one socket for each port port on the same
server, even if that port is specified against a different (multi-home) host
name because the accept()ing socket can be interrogated to determine which
host had been specified.  Then in a infinite loop accept connections from
clients.

A hash table is used to expedite access when searching the service list.  The
first entry with a particular hash value is entered into the table.  If a hash
collision occurs the subsequent entry will be further down the list anyway and
so a search from that point and down the linked list can be performed.
*/ 

NetCreateService ()

{
   register char  *cptr, *sptr;
   register struct ServiceStruct  *svptr, *tsvptr;

   int  cnt,
        status,
        BytLmAfter,
        BytLmBefore,
        PortNumber;
   unsigned short  Length;
   char  *ProtocolPtr;
   
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetCreateService() %d\n", ServiceCount);

   /* hash table needs to be a power of 2 (i.e. 64, 128, 256, 512 ...) */
   ServiceHashTableEntries = ServiceCount;
   for (cnt = 0; ServiceHashTableEntries; cnt++)
      ServiceHashTableEntries >>= 1;
   ServiceHashTableEntries = 1;
   while (--cnt > 0) ServiceHashTableEntries <<= 1;
   /* bigger than it needs to be, gives a better hash spread and hit rate */
   ServiceHashTableEntries <<= 3;

   /* e.g. cache table size of 512 becomes a mask of 0x1ff */
   ServiceHashTableMask = ServiceHashTableEntries - 1;

   if (Debug)
      fprintf (stdout, "HashTableEntries: %d HashTableMask: %08.08X\n",
               ServiceHashTableEntries, ServiceHashTableMask);

   ServiceHashTable =
      VmGet (sizeof(struct ServiceStruct*)*ServiceHashTableEntries);

   /********************************/
   /* process the list of services */
   /********************************/

   for (svptr = ServiceListHead; svptr != NULL; svptr = svptr->NextPtr)
   {
      WriteFaoStdout ("%!AZ-I-SERVICE, !AZ//!AZ\n",
         Utility, svptr->RequestSchemeNamePtr, svptr->ServerHostPort);

      /* generate the name-only hash that will used for quick host compares */
      svptr->ServerHostNameHashValue = NetHostNameHash (svptr->ServerHostName);

      /* generate the name-port hash, if none set update the service table */
      svptr->ServerHostPortHashValue =
         NetHostPortHash (svptr->ServerHostPort, "");
      if (ServiceHashTable[svptr->ServerHostPortHashValue] == NULL)
         ServiceHashTable[svptr->ServerHostPortHashValue] = svptr;

      /**************************************/
      /* check for previous service on port */
      /**************************************/

      for (tsvptr = ServiceListHead; tsvptr != NULL; tsvptr = tsvptr->NextPtr)
      {
         /* if got this far in the list, can't be a socket for this port! */
         if (svptr == tsvptr)
         {
            tsvptr = NULL;
            break;
         }
              
         if (svptr->ServerIpAddress != tsvptr->ServerIpAddress)
            NetMultiHomedHost = true;

         if (svptr->RequestScheme == SCHEME_HTTPS)
         {
            if (svptr->ServerPort == tsvptr->ServerPort)
            {
               if (svptr->ServerIpAddress == tsvptr->ServerIpAddress)
               {
                  /* warn of a "sharing" situation */
                  WriteFaoStdout (
"%!AZ-W-SERVICE, already an SSL service for this IP address and port\n\
-!AZ-W-SHARING, with !AZ:!AZ (!AZ)\n",
                     Utility, Utility,
                     tsvptr->ServerIpAddressString, tsvptr->ServerPortString,
                     tsvptr->ServerHostPort);

                  /* initialize by "cloning" the original service */
                  SeSoLaInitService (svptr, tsvptr);
               }
               else
               {
                  /* initialize the service */
                  SeSoLaInitService (svptr, NULL);
               }
               break;
            }
         }
         else
         if (svptr->ServerPort == tsvptr->ServerPort)
         {
            /* channel not used except by WatchPeek() to display device */
            svptr->ServerChannel = tsvptr->ServerChannel;
            break;
         }
      }

      /* if a service has already bound to this port */
      if (tsvptr != NULL) continue;

      /*************************/
      /* create service socket */
      /*************************/

      if (!NetListenBytLmRequired) BytLmBefore = GetJpiBytLm ();

      /* if an SSL service then initialize, if a problem then just continue */
      if (svptr->RequestScheme == SCHEME_HTTPS)
         if (!SeSoLaInitService (svptr, NULL))
            continue;

      /* assign a channel to the internet template device */
      if (VMSnok (status =
          sys$assign (&InetDeviceDsc, &svptr->ServerChannel, 0, 0)))
         ErrorExitVmsStatus (status, "sys$assign()", FI_LI);

      /* make the channel a TCP, connection-oriented socket */

      if (Debug) fprintf (stdout, "sys$qiow() IO$_SETMODE\n");
      status = sys$qiow (0, svptr->ServerChannel, IO$_SETMODE,
                         &svptr->ServerIOsb, 0, 0,
                         &TcpSocket, 0, 0, 0,
                         Config.cfScript.GatewayBg ?
                            &ServerSocketShareOption :
                            &ServerSocketOption,
                         0);
      if (Debug)
         fprintf (stdout, "sys$qiow() %%X%08.08X IOsb %%X%08.08X\n",
                  status, svptr->ServerIOsb.Status);
      if (VMSok (status) && VMSnok (svptr->ServerIOsb.Status))
         status = svptr->ServerIOsb.Status;
      if (VMSnok (status))
         ErrorExitVmsStatus (status, "sys$qiow()", FI_LI);

      /**************************/
      /* bind the server socket */
      /**************************/

      svptr->ServerSocketNameItem.Length = sizeof(svptr->ServerSocketName);
      svptr->ServerSocketNameItem.Address = &svptr->ServerSocketName;

      svptr->ServerSocketName.sin_family = AF_INET;
      svptr->ServerSocketName.sin_port = htons (svptr->ServerPort);
      if (svptr->SuppliedIpAddressString[0])
         svptr->ServerSocketName.sin_addr.s_addr = svptr->ServerIpAddress;
      else
         svptr->ServerSocketName.sin_addr.s_addr = INADDR_ANY;

      if (Debug) fprintf (stdout, "sys$qiow() IO$_SETMODE\n");
      status = sys$qiow (0, svptr->ServerChannel, IO$_SETMODE,
                         &svptr->ServerIOsb, 0, 0,
                         0, 0, &svptr->ServerSocketNameItem,
                         svptr->ListenBacklog, 0, 0);
      if (Debug)
         fprintf (stdout, "sys$qiow() %%X%08.08X IOsb %%X%08.08X\n",
                  status, svptr->ServerIOsb.Status);
      if (VMSok (status) && VMSnok (svptr->ServerIOsb.Status))
         status = svptr->ServerIOsb.Status;
      if (VMSnok (status))
      {
         sys$dassgn (svptr->ServerChannel);
         WriteFaoStdout ("-!AZ-W-SERVICE, error binding\n-!%M\n",
                         Utility, status);
         continue;
      }

      if (!NetListenBytLmRequired)
      {
         BytLmAfter = GetJpiBytLm ();
         NetListenBytLmRequired = BytLmBefore - BytLmAfter;
         if (Debug)
            fprintf (stdout, "NetListenBytLmRequired: %d\n",
                     NetListenBytLmRequired);
      }

      /****************************/
      /* listen for first request */
      /****************************/

      NetAccept (svptr);
   }

   if (Debug) fprintf (stdout, "NetMultiHomedHost: %d\n", NetMultiHomedHost); 

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Scan through the list of services returning true if one is found matching the
supplied IP address (and optionally port), return false otherwise.  If a port
component is not supplied with the parameter it is considered to match any/all
ports.
*/ 

boolean NetServiceConfigured (char *HostNamePort)

{
   register char  *cptr, *sptr;
   register struct ServiceStruct  *svptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetServiceConfigured() |%s|\n", HostNamePort);

   for (svptr = ServiceListHead; svptr != NULL; svptr = svptr->NextPtr)
   {
      if (Debug) fprintf (stdout, "|%s|\n", svptr->ServerHostPort);
      cptr = HostNamePort;
      sptr = svptr->ServerHostPort;
      /* compare the host name portion */
      while (*cptr && *cptr != ':' && *sptr && *sptr != ':')
      {
         if (tolower(*cptr) != tolower(*sptr)) break;
         cptr++;
         sptr++;
      }
      /* continue if the host name portion did not match */
      if ((*cptr && *cptr != ':') || *sptr != ':') continue;
      /* return true if the parameter did not contain a specific port */
      if (!*cptr)
      {
         if (Debug) fprintf (stdout, "match\n");
         return (true);
      }
      cptr++;
      sptr++;
      /* compare the port portion */
      while (*cptr && *sptr)
      {
         if (*cptr != *sptr) break;
         cptr++;
         sptr++;
      }
      /* return true if the ports matched */
      if (!*cptr && !*sptr)
      {
         if (Debug) fprintf (stdout, "match\n");
         return (true);
      }
   }

   if (Debug) fprintf (stdout, "no match\n");
   return (false);
}

/*****************************************************************************/
/*
Zero the per-service accounting counters.
*/ 

NetServiceZeroAccounting ()

{
   register struct ServiceStruct  *svptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetServiceZeroAccounting()\n");

   for (svptr = ServiceListHead; svptr != NULL; svptr = svptr->NextPtr)
   {
      svptr->ConnectCount = 0;
      memset (&svptr->QuadBytesRawRx, 0, 8);
      memset (&svptr->QuadBytesRawTx, 0, 8);
   }
}

/*****************************************************************************/
/*
Return a pointer to the name of the next service.  Begin with 'ContextPtr' set
to zero, then call successively until a NULL is returned.
*/ 

char* NetServiceNextHostPort (unsigned long *ContextPtr)

{
   register struct ServiceStruct  *svptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetServiceNextHostPort() %d\n", *ContextPtr);

   if (!*ContextPtr)
      *ContextPtr = (unsigned long)(svptr = ServiceListHead);
   else
   {
      svptr = (struct ServiceStruct*)*ContextPtr;
      *ContextPtr = (unsigned long)(svptr = svptr->NextPtr);
   }
   if (svptr == NULL)
   {
      if (Debug) fprintf (stdout, "|(null)|\n");
      return (NULL);
   }
   if (Debug) fprintf (stdout, "|%s|\n", svptr->ServerHostPort);
   return (svptr->ServerHostPort);
}

/*****************************************************************************/
/*
Output service statistics (called from AdminReportServerStats()).
*/ 

int NetServiceReportStats (struct RequestStruct *rqptr)

{
   static char  ServicesFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Services</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH></TH><TH></TH>\
<TH ALIGN=right><U>Count</U></TH>\
<TH ALIGN=right><U><NOBR><FONT SIZE=-1>bytes</FONT> Rx</U></TH>\
<TH ALIGN=right><U><NOBR><FONT SIZE=-1>bytes</FONT> Tx</U></TH>\
<TH ALIGN=right><U>Traffic</U></TH></TR>\n";

   static char  OneServiceFao [] =
"<TR><TH ALIGN=right>!UL.&nbsp;</TH>\
<TD ALIGN=left><TT>!AZ//!AZ</TT></TD><TD ALIGN=right>!,UL</TD>\
<TD ALIGN=right>&nbsp;!,@SQ</TD>\
<TD ALIGN=right>&nbsp;!,@SQ</TD>\
<TD ALIGN=right>&nbsp;!UL%</TD></TR>\n";

   static char  TotalFao [] =
"<TR><TH></TH><TH ALIGN=right>total:</TH><TD ALIGN=right>!,UL</TD>\
<TD ALIGN=right>!,@SQ</TD><TD ALIGN=right>!,@SQ</TD></TR>\n\
<TR><TD COLSPAN=4><FONT SIZE=-1>\
<SUP>*</SUP><I>counts are per-startup only</I></FONT></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n";

   static long  Addx2 = 2;

   register unsigned long  *vecptr;
   register struct ServiceStruct  *svptr;

   int  status,
        PercentService,
        ServiceListCount,
        ServiceTotalCount;

   unsigned short  Length;

   unsigned long  FaoVector [32],
                  QuadBytesRawRx [2],
                  QuadBytesRawTx [2],
                  QuadBytesTotal [2];

   float  FloatBytes,
          FloatBytesTotal,
          FloatPercent;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetServiceReportStats()\n");

   ServiceTotalCount = 0;
   QuadBytesRawRx[0] = QuadBytesRawRx[1] =
      QuadBytesRawTx[0] = QuadBytesRawTx[1] =
      QuadBytesTotal[0] = QuadBytesTotal[1] = 0;

   /* accumulate the raw (network) bytes for the services */
   for (svptr = ServiceListHead; svptr != NULL; svptr = svptr->NextPtr)
   {
      ServiceTotalCount += svptr->ConnectCount;

      status = lib$addx (&svptr->QuadBytesRawRx, &QuadBytesRawRx,
                         &QuadBytesRawRx, &Addx2);
      if (Debug) fprintf (stdout, "lib$addx() %%X%08.08X\n", status);

      status = lib$addx (&svptr->QuadBytesRawTx, &QuadBytesRawTx,
                         &QuadBytesRawTx, &Addx2);
      if (Debug) fprintf (stdout, "lib$addx() %%X%08.08X\n", status);
   }

   status = lib$addx (&QuadBytesRawRx, &QuadBytesRawTx,
                      &QuadBytesTotal, &Addx2);
   if (Debug) fprintf (stdout, "lib$addx() %%X%08.08X\n", status);

   FloatBytesTotal = (float)QuadBytesTotal[0] +
                     (float)QuadBytesTotal[1] * (float)0xffffffff;
   if (Debug) fprintf (stdout, "FloatBytesTotal: %f\n", FloatBytesTotal);

   status = NetWriteFaol (rqptr, ServicesFao, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   ServiceListCount = 1;
   for (svptr = ServiceListHead; svptr != NULL; svptr = svptr->NextPtr)
   {
      FloatBytes = (float)svptr->QuadBytesRawRx[0] +
                   ((float)svptr->QuadBytesRawRx[1] * (float)0xffffffff) +
                   (float)svptr->QuadBytesRawTx[0] +
                   ((float)svptr->QuadBytesRawTx[1] * (float)0xffffffff);
      if (Debug) fprintf (stdout, "FloatBytes: %f\n", FloatBytes);

      if (FloatBytesTotal > 0.0)
      {
         PercentService = (int)(FloatPercent =
                                FloatBytes * 100.0 / FloatBytesTotal);
         if (FloatPercent - (float)PercentService >= 0.5) PercentService++;
      }
      else
         PercentService = 0;
      if (Debug) fprintf (stdout, "percent: %d\n", PercentService);

      vecptr = FaoVector;
      *vecptr++ = ServiceListCount++;
      *vecptr++ = svptr->RequestSchemeNamePtr;
      *vecptr++ = svptr->ServerHostPort;
      *vecptr++ = svptr->ConnectCount;
      *vecptr++ = &svptr->QuadBytesRawRx;
      *vecptr++ = &svptr->QuadBytesRawTx;
      *vecptr++ = PercentService;

      status = NetWriteFaol (rqptr, OneServiceFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   vecptr = FaoVector;

   *vecptr++ = ServiceTotalCount;
   *vecptr++ = &QuadBytesRawRx;
   *vecptr++ = &QuadBytesRawTx;

   status = NetWriteFaol (rqptr, TotalFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Generate and return a hash value for a host name and port as a single
colon-delimited string.  If the host-port string does not contain a port
component then use the additional parameter which must contain the string
equivalent of the port number.  The generated value may be used to index into
the service list hash table.
*/ 

#pragma inline(NetHostPortHash)

unsigned long NetHostPortHash
(
char *HostPortString,
char *PortString
)
{
   register unsigned long  HashValue;
   register char  *cptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetHostPortHash() |%s|\n", HostPortString);

   /* hash in the host component (forced to lower case) */
   HashValue = 1;
   for (cptr = HostPortString; *cptr && *cptr != ':'; cptr++)
      HashValue = ((tolower(*cptr)*541)^(HashValue*7)) & ServiceHashTableMask;
   if (!*cptr)
   {
      /* host-port did not include a port, used the additional parameter */
      HashValue = ((':'*541)^(HashValue*7)) & ServiceHashTableMask;
      cptr = PortString;
   }
   /* hash in the port component */
   while (*cptr)
   {
      HashValue = ((*cptr*541)^(HashValue*7)) & ServiceHashTableMask;
      cptr++;
   }
   if (Debug) fprintf (stdout, "HashValue: %d\n", HashValue);
   return (HashValue);
}

/*****************************************************************************/
/*
Generate and return a hash value for a host name (excludes any colon-delimited
port number).  THIS HASH VALUE CANNOT BE USED TO INDEX INTO ANY TABLE!!  It is
just for quick elimination of a host string before undergoing a full string
comparison.
*/ 

#pragma inline(NetHostNameHash)

unsigned long NetHostNameHash (char *HostNameString)

{
   register unsigned long  HashValue;
   register char  *cptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetHostNameHash() |%s|\n", HostNameString);

   /* generate lower-case hash */
   HashValue = 1;
   for (cptr = HostNameString; *cptr && *cptr != ':'; cptr++)
      HashValue = ((tolower(*cptr)*541)^(HashValue*7)) & 0x0ffff;
   if (Debug) fprintf (stdout, "HashValue: %d\n", HashValue);
   return (HashValue);
}

/*****************************************************************************/
/*
Find a service' host name and port that matches the request's "Host:" request
header line.  Point the request's service pointer at the virtual service's
structure is found.  Return true if a matching service was found, false if not.
A hash table is used to expedite access into the list.  This first entry with
a particular hash value is entered into the table.  If the hash entry does not
match by string comparison then the search just continues down the list.
*/ 

boolean NetVirtualService (struct RequestStruct *rqptr)

{
   register char  *sptr1, *sptr2;
   register struct ServiceStruct  *svptr;

   unsigned long  HashValue;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "NetVirtualServer() |%s|\n", rqptr->rqHeader.HostPtr);

   if (rqptr->rqHeader.HostPtr == NULL || !rqptr->rqHeader.HostPtr[0])
   {
      /* just use whatever service the request connected to */
      if (Debug) fprintf (stdout, "no \"Host:\"\n");

      if (rqptr->WatchItem &&
          (WatchEnabled & WATCH_CONNECT))
         WatchThis (rqptr, FI_LI, WATCH_CONNECT,
                    "ACTUAL !AZ", rqptr->ServicePtr->ServerHostPort); 

      return (true);
   }

   /* not worth the overhead of hash generation for small number of services */
   if (ServiceCount > 4)
   {
      /* generate a hash value for the "Host:" name/port */
      HashValue = NetHostPortHash (rqptr->rqHeader.HostPtr,
                                   rqptr->ServicePtr->ServerPortString);

      /* begin searching the list at the hash table entry */
      svptr = ServiceHashTable[HashValue];
   }
   else
   {
      /* begin with the start of the list */
      svptr = ServiceListHead;
   }

   for ( /* above */ ; svptr != NULL; svptr = svptr->NextPtr)
   {
      if (Debug) fprintf (stdout, "|%s|\n", svptr->ServerHostPort);

      sptr1 = rqptr->rqHeader.HostPtr;
      sptr2 = svptr->ServerHostPort;

      /* compare host names */
      while (*sptr1 && *sptr1 != ':' && *sptr2 && *sptr2 != ':')
         if (tolower (*sptr1++) != tolower (*sptr2++)) break;

      if (Debug) fprintf (stdout, "|%s|%s|\n", sptr1, sptr2);
      if (*sptr1 == ':' && *sptr2 == ':')
      {
         /* the "Host:" contained a port number */
         sptr1++;
         sptr2++;
      }
      else
      if (!*sptr1 && *sptr2 == ':')
      {
         /* the "Host:" did not contain a port number, use the service's */
         sptr1 = rqptr->ServicePtr->ServerPortString;
         sptr2++;
      }
      else
      {
         if (Debug) fprintf (stdout, "no match\n");
         continue;
      }

      /* compare port number strings */
      if (Debug) fprintf (stdout, "|%s|%s|\n", sptr1, sptr2);
      while (*sptr1 && *sptr2) if (*sptr1++ != *sptr2++) break;
      if (*sptr1 || *sptr2)
      {
         if (Debug) fprintf (stdout, "no match\n");
         continue;
      }

      if (Debug) fprintf (stdout, "match |%s|\n", svptr->ServerHostPort);

      if (rqptr->WatchItem &&
          (WatchEnabled & WATCH_CONNECT))
         WatchThis (rqptr, FI_LI, WATCH_CONNECT,
                    "VIRTUAL !AZ", svptr->ServerHostPort); 

      /* change the request's service pointer to it's virtual equivalent */
      rqptr->ServicePtr = svptr;

      return (true);
   }

   if (Debug) fprintf (stdout, "end of services!\n");
   return (false);
}

/*****************************************************************************/
/*
Compare the 'ActualHostPort' to the 'VirtualHostPort'.  Host name components
MUST match (case insensitive).  If the virtual specification contains a port
component then both must have port components and both must match.  Returns
true if they do, false if they don't.
*/ 

boolean NetThisVirtualService
(
char *ActualHostPort,
char *VirtualHostPort
)
{
   register char  *sptr1, *sptr2;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "NetThisVirtualService() |%s|%s|\n",
               ActualHostPort, VirtualHostPort);

   sptr1 = ActualHostPort;
   sptr2 = VirtualHostPort;

   /* compare host names */
   while (*sptr1 && *sptr1 != ':' && *sptr2 && *sptr2 != ':')
      if (tolower (*sptr1++) != tolower (*sptr2++)) return (false);
   if (Debug) fprintf (stdout, "|%s|%s|\n", sptr1, sptr2);

   if (!*sptr2 && (!*sptr1 || *sptr1 == ':'))
   {
      /* virtual does not include a port, match any */
      return (true);
   }

   /* at this stage both should contain port components */
   if (*sptr1 != ':' || *sptr2 != ':') return (false);

   /* compare the port numbers */
   sptr1++;
   sptr2++;
   while (*sptr1 && *sptr2)
      if (*sptr1++ != *sptr2++) return (false);
   if (*sptr1 || *sptr2) return (false);
   return (true);
}

/*****************************************************************************/
/*
Queue an accept() to the listening server socket.
*/ 

NetAccept (struct ServiceStruct *svptr)

{
   int  status,
        BytLmAfter,
        BytLmBefore;
   struct AnIOsb  LocalIOsb;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetAccept() %d\n", svptr);

   if (ControlExitRequested || ControlRestartRequested)
   {
      /* server exiting or restarting, no new accepts, just return */
      return;
   }

   if (!NetAcceptBytLmRequired) BytLmBefore = GetJpiBytLm ();

   /* assign a channel to the internet template device */
   if (VMSnok (status =
       sys$assign (&InetDeviceDsc, &svptr->ClientChannel, 0, 0)))
      ErrorExitVmsStatus (status, "sys$assign()", FI_LI);

   svptr->ClientSocketNameItem.Length = sizeof(svptr->ClientSocketName);
   svptr->ClientSocketNameItem.Address = &svptr->ClientSocketName;
   svptr->ClientSocketNameItem.LengthPtr = &svptr->ClientSocketNameLength;

   if (Debug) fprintf (stdout, "sys$qio() IO$_ACCESS | IO$M_ACCEPT\n");
   status = sys$qio (0, svptr->ServerChannel, IO$_ACCESS | IO$M_ACCEPT,
                     &svptr->ServerIOsb, &NetAcceptAst, svptr,
                     0, 0, &svptr->ClientSocketNameItem, &svptr->ClientChannel,
                     &ClientSocketOption, 0);
   if (Debug) fprintf (stdout, "sys$qio() %%X%08.08X\n", status);
   if (VMSnok (status)) 
      ErrorExitVmsStatus (status, "sys$qio()", FI_LI);

   if (!NetAcceptBytLmRequired)
   {
      BytLmAfter = GetJpiBytLm ();
      NetAcceptBytLmRequired = BytLmBefore - BytLmAfter;
      if (Debug)
         fprintf (stdout, "NetAcceptBytLmRequired: %d\n",
                  NetAcceptBytLmRequired);
   }
}

/*****************************************************************************/
/*
A connection has been accept()ed on the specified server socket.
*/ 

NetAcceptAst (struct ServiceStruct *svptr)

{
   register struct RequestStruct  *rqptr;
   register struct ServiceStruct  *tsvptr;

   boolean WatchThisOne;
   int  status,
        SocketNameLength,
        ServerSocketNameLength;
   unsigned short  PortNumber;
   char  ServerIpAddressString [32];
   struct AnIOsb  IOsb;
   struct sockaddr_in  SocketName;
   struct {
      unsigned int  Length;
      char  *Address;
      unsigned int  *LengthPtr;
   } SocketNameItem;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetAcceptAst() %d\n", svptr);

   if (Debug)
      fprintf (stdout, "sys$qio() IOsb %%X%08.08X %d\n",
               svptr->ServerIOsb.Status, svptr->ServerIOsb.Unused);

   if (VMSnok (svptr->ServerIOsb.Status)) 
   {
      if (ControlExitRequested || ControlRestartRequested)
      {
         /* server exiting or restarting, no new accepts, just return */
         return;
      }

      if (svptr->ServerIOsb.Status == SS$_CANCEL ||
          svptr->ServerIOsb.Status == SS$_ABORT ||
          svptr->ServerIOsb.Status == SS$_LINKABORT)
      {
         /* connect dropped, forget it, ready for next connection */
         NetAccept (svptr);
         return;
      }

      /* most often network/system shutting down ... SS$_SHUT */
      ErrorExitVmsStatus (svptr->ServerIOsb.Status, "accept()", FI_LI);
   }

   Accounting.ConnectCount++;

   svptr->ClientPort = svptr->ClientSocketName.sin_port;
   svptr->ClientIpAddress = svptr->ClientSocketName.sin_addr.S_un.S_addr;
   strcpy (svptr->ClientIpAddressString,
           inet_ntoa (svptr->ClientSocketName.sin_addr));
   if (Debug) fprintf (stdout, "|%s|\n", svptr->ClientIpAddressString);

   if (NetMultiHomedHost)
   {
      /************************************/
      /* multiple services, get host/port */
      /************************************/

      SocketNameItem.Length = sizeof(SocketName);
      SocketNameItem.Address = &SocketName;
      SocketNameItem.LengthPtr = &SocketNameLength;

      if (Debug) fprintf (stdout, "sys$qiow() IO$_SENSEMODE\n");
      status = sys$qiow (0, svptr->ClientChannel, IO$_SENSEMODE,
                         &IOsb, 0, 0, 0, 0, &SocketNameItem, 0, 0, 0);
      if (Debug)
         fprintf (stdout, "sys$qiow() %%X%08.08X IOsb %%X%08.08X\n",
                  status, IOsb.Status);
      if (VMSok (status) && VMSnok (IOsb.Status))
         status = IOsb.Status;
      if (VMSnok (status))
      {
         /* hmmm, forget it, ready for next connection */
         NetAccept (svptr);
         return;
      }

      PortNumber = ntohs(SocketName.sin_port);

      if (Debug)
         fprintf (stdout, "|%s|%d|\n",
                  inet_ntoa (SocketName.sin_addr), PortNumber);

      for (tsvptr = ServiceListHead; tsvptr != NULL; tsvptr = tsvptr->NextPtr)
      {
         if (SocketName.sin_addr.s_addr ==
             tsvptr->ServerIpAddress &&
             PortNumber == tsvptr->ServerPort) break;
      }
      /* if none matches then 'tsvptr' is set to NULL */
   }
   else
   if (ServiceCount > 1)
   {
      /* multiple, possibly virtual services */
      tsvptr = svptr;
   }
   else
   {
      /* "they can have any color they want, provided it's black" */
      tsvptr = ServiceListHead;
   }

   if (Debug && tsvptr != NULL)
      fprintf (stdout, "|%s|%s:%d|\n",
               tsvptr->ServerIpAddressString,
               tsvptr->ServerHostName, tsvptr->ServerPort);

   if (svptr->RequestScheme == SCHEME_HTTPS)
      Accounting.ConnectSslCount++;

   if (Config.cfMisc.DnsLookup)
      NetClientAddressLookup (svptr);
   else
      strcpy (svptr->ClientHostName, svptr->ClientIpAddressString);
   if (Debug) fprintf (stdout, "|%s|\n", svptr->ClientHostName);

   if (WatchEnabled && WatchEnabled != WATCH_ONE_SHOT)
      WatchThisOne = WatchFilter (svptr->ClientHostName,
                                  svptr->ClientIpAddressString,
                                  svptr->RequestSchemeNamePtr,
                                  svptr->ServerHostPort,
                                  NULL, NULL);
   else
      WatchThisOne = false;

   if (ConnectCountCurrent >= ConnectCountConcurrentMax)
   {
      /************/
      /* too busy */
      /************/

      if (WatchThisOne && (WatchEnabled & WATCH_CONNECT))
         WatchThis (NULL, FI_LI, WATCH_CONNECT,
                    "TOO BUSY !AZ,!UL on !AZ//!AZ:!AZ",
                     svptr->ClientHostName, svptr->ClientPort, 
                     svptr->RequestSchemeNamePtr,
                     svptr->ServerIpAddressString,
                     svptr->ServerPortString);

      Accounting.ConnectTooBusyCount++;
      Accounting.ResponseStatusCodeCountArray[5]++;

      NetTooBusy (svptr->ClientChannel,
                  svptr->ClientHostName,
                  svptr->ClientIpAddressString);
      NetDummyRead (svptr->ClientChannel);

      /* ready for next connection */
      NetAccept (svptr);

      return;
   }

   /* 'tsvptr' is NULL if the request did not match a known service */
   if (tsvptr == NULL ||
       !ConfigAcceptClientHostName (svptr->ClientIpAddressString,
                                    svptr->ClientHostName))
   {
      /************/
      /* rejected */
      /************/

      if (WatchThisOne && (WatchEnabled & WATCH_CONNECT))
         WatchThis (NULL, FI_LI, WATCH_CONNECT,
                    "REJECT !AZ,!UL on !AZ//!AZ:!AZ",
                     svptr->ClientHostName, svptr->ClientPort, 
                     svptr->RequestSchemeNamePtr,
                     svptr->ServerIpAddressString,
                     svptr->ServerPortString);

      Accounting.ConnectRejectedCount++;
      Accounting.ResponseStatusCodeCountArray[4]++;

      NetAccessDenied (svptr->ClientChannel,
                       svptr->ClientHostName,
                       svptr->ClientIpAddressString);
      NetDummyRead (svptr->ClientChannel);

      /* ready for next connection */
      NetAccept (svptr);

      return;
   }

   Accounting.ConnectAcceptedCount++;

   /* allocate zeroed dynamic memory for the connection thread */
   rqptr = VmGetRequest ();

   /***************************/
   /* process HTTP connection */
   /***************************/

   /* once the thread structure has been created we have a client! */
   rqptr->ConnectNumber = ++ConnectCountTotal;
   Accounting.ConnectCurrent = ++ConnectCountCurrent;
   if (ConnectCountCurrent > Accounting.ConnectPeak)
      Accounting.ConnectPeak = ConnectCountCurrent;

   /* point at this service' structure */
   rqptr->ServicePtr = tsvptr;

   /* copy the client network information */
   rqptr->rqNet.ClientChannel = svptr->ClientChannel;
   rqptr->rqNet.ClientPort = svptr->ClientPort;
   rqptr->rqNet.ClientIpAddress = svptr->ClientIpAddress;
   strcpy (rqptr->rqNet.ClientIpAddressString, svptr->ClientIpAddressString);
   strcpy (rqptr->rqNet.ClientHostName, svptr->ClientHostName);

   if (WatchThisOne)
   {
      /* assign a unique number for the life of this request structure */
      rqptr->WatchItem = ++WatchItem;

      if (WatchEnabled & WATCH_CONNECT)
         WatchThis (rqptr, FI_LI, WATCH_CONNECT,
                    "ACCEPT !AZ,!UL on !AZ//!AZ:!AZ",
                    svptr->ClientHostName, svptr->ClientPort, 
                    svptr->RequestSchemeNamePtr,
                    svptr->ServerIpAddressString,
                    svptr->ServerPortString);
   }

   RequestBegin (rqptr, true);

   /* ready for next connection */
   NetAccept (svptr);
}

/*****************************************************************************/
/*
Some browsers report a network error (e.g. Windows Netscape Navigator 2.n) if
the server does not read anything from them before returning an error message.
This routine and it's AST ensure a read is done before reporting an error
earlier that reading the request from it.  Needless-to-say, no status checking
is performed and the data just discarded (hope it works consistently :^)
*/ 

NetDummyRead (unsigned short Channel)

{
   static char  DummyBuffer [1024];
   static struct AnIOsb  DummyIOsb;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetDummyRead() Channel: %d\n", Channel);

   status = sys$qio (0, Channel, IO$_READVBLK, &DummyIOsb,
                     &NetDummyReadAst, Channel,
                     DummyBuffer, sizeof(DummyBuffer), 0, 0, 0, 0);

   if (Debug) fprintf (stdout, "sys$qio() %%X%08.08X\n", status);

}

/*****************************************************************************/
/*
See commentary in NetDummyRead().
*/ 

NetDummyReadAst (unsigned short Channel)

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetDummyReadAst() Channel: %d\n", Channel);

   status = sys$dassgn (Channel);
   if (Debug) fprintf (stdout, "sys$dassgn() %%X%08.08X\n", status);
}

/*****************************************************************************/
/*
Using the 'HostName' parameter get the lookup host name into 'HostNamePtr', the
decimal-dot-notation IP address string into 'IpAddressStringPtr' and the 32 bit
IP address into 'IpAddressPtr'.  Any of the '...Ptr' parameters can be NULL and
won't have the respective information returned.
*/ 

NetHostNameLookup
(
char *HostNamePort,
int PortNumber,
char *SuppliedIpAddressString,
char *HostNamePtr,
char *HostNamePortPtr,
char *IpAddressStringPtr,
int *IpAddressPtr
)
{

   static $DESCRIPTOR (HostNamePortFaoDsc, "!AZ:!UL\0");
   static $DESCRIPTOR (StringDsc, "");

   boolean  FullyQualified;
   int  idx,
        status;
   unsigned long  IpAddress,
                  SuppliedIpAddress;
   char  *cptr, *sptr, *zptr,
         *ResolvedNamePtr;
   char  HostName [128];
   struct ServiceStruct *svptr;
   struct hostent  *HostEntryPtr;
   struct in_addr  HostAddress;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetHostNameLookup() |%s|\n", HostNamePort);

   FullyQualified = false;
   SuppliedIpAddress = 0;
   HostName[0] = '\0';

   zptr = (sptr = HostName) + sizeof(HostName)-1;
   for (cptr = HostNamePort;
        *cptr && *cptr != ':' && sptr < zptr;
        *sptr++ = *cptr++)
       if (*cptr == '.') FullyQualified = true;
   *sptr = '\0';

   /*************************/
   /* UCX resolve host name */
   /*************************/

   if ((HostEntryPtr = gethostbyname (HostName)) == NULL)
   {
      WriteFaoStdout (
         "%!AZ-W-SERVICE, could not resolve host name\n \\!AZ\\\n-!%M\n",
         Utility, HostName, vaxc$errno);

      if (isdigit(HostName[0]))
      {
         /* workaround TCPWARE 5.3-3 behaviour (Laishev@SMTP.DeltaTel.RU) */
         if ((IpAddress = inet_addr (HostNamePort)) == -1)
         {
            WriteFaoStdout ("-!AZ-E-DOTDEC, parsing dotted-decimal address\n",
                            Utility);
            return (STS$K_ERROR);
         }
      }
      else
      if (!SuppliedIpAddressString[0])
      {
         if ((svptr = ServiceListHead) == NULL) return (STS$K_ERROR);
         IpAddress = svptr->ServerIpAddress;
         WriteFaoStdout ("%!AZ-W-INTERFACE, !AZ with !AZ\n",
            Utility, HostName, svptr->ServerIpAddressString);
      }
      ResolvedNamePtr = HostNamePort;
   }
   else
   {
      memcpy (&IpAddress, HostEntryPtr->h_addr, sizeof(IpAddress));
      ResolvedNamePtr = HostEntryPtr->h_name;
   }

   if (SuppliedIpAddressString[0])
   {
      if ((SuppliedIpAddress = inet_addr (SuppliedIpAddressString)) == -1)
      {
         WriteFaoStdout (
            "%!AZ-W-SERVICE, problem with supplied IP address\n \\!AZ\\\n",
            Utility, SuppliedIpAddressString);
         return (STS$K_ERROR);
      }
      IpAddress = SuppliedIpAddress;
   }

   /*****************************/
   /* return values as required */
   /*****************************/

   if (FullyQualified)
   {
      /* looks better if its all in lower case (sometimes upper) */
      for (cptr = HostName; *cptr; cptr++) *cptr = tolower(*cptr);
   }
   else
   {
      /* use the resolved name */
      zptr = (sptr = HostName) + 127;
      /* looks better if its all in lower case (sometimes upper) */
      for (cptr = ResolvedNamePtr;
           *cptr && sptr < zptr;
           *sptr++ = tolower(*cptr++));
      *sptr = '\0';
   }
   if (Debug) fprintf (stdout, "HostName |%s|\n", HostName);

   if (HostNamePtr != NULL)
   {
      strcpy (HostNamePtr, HostName);
      if (Debug) fprintf (stdout, "HostNamePtr |%s|\n", HostNamePtr);
   }

   if (HostNamePortPtr != NULL)
   {
      StringDsc.dsc$a_pointer = HostNamePortPtr;
      StringDsc.dsc$w_length = 128+16;
      sys$fao (&HostNamePortFaoDsc, 0, &StringDsc, HostName, PortNumber);
      if (Debug) fprintf (stdout, "HostNamePortPtr |%s|\n", HostNamePortPtr);
   }

   if (IpAddressPtr != NULL)
   {
      *IpAddressPtr = IpAddress;
      if (Debug) fprintf (stdout, "IpAddressPtr: %08.08X\n", *IpAddressPtr);
   }

   if (IpAddressStringPtr != NULL)
   {
      /* convert the binary address into a string */
      HostAddress.S_un.S_addr = IpAddress;
      strcpy (IpAddressStringPtr, inet_ntoa (HostAddress));
      if (Debug)
         fprintf (stdout, "IpAddressStringPtr |%s|\n", IpAddressStringPtr);
   }

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Perform the UCX get host name using QIO ACP functionality.  This can execute 
at AST-delivery level.  Doing this within NETLIB needs to cater for the
lowest-common-denominator package, which sometimes will not execute at AST
delivery level, therefore rendering some NETLIB packages incapable of
supporting DNS lookup!
*/ 

NetClientAddressLookup (struct ServiceStruct *svptr) 

{
   static unsigned char ControlSubFunction [4] =
      { INETACP_FUNC$C_GETHOSTBYADDR, INETACP$C_TRANS, 0, 0 };
   static struct dsc$descriptor AddressDsc =
      { 0, DSC$K_DTYPE_T, DSC$K_CLASS_S, 0};
   static struct dsc$descriptor ControlSubFunctionDsc =
      { 4, DSC$K_DTYPE_T, DSC$K_CLASS_S, &ControlSubFunction };
   static struct dsc$descriptor ClientHostNameDsc =
      { 0, DSC$K_DTYPE_T, DSC$K_CLASS_S, 0};

   int  status;
   unsigned short  Length;
   struct  AnIOsb  IOsb;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetClientAddressLookup()\n");

   AddressDsc.dsc$w_length = sizeof(svptr->ClientSocketName.sin_addr);
   AddressDsc.dsc$a_pointer = &svptr->ClientSocketName.sin_addr;

   ClientHostNameDsc.dsc$w_length = sizeof(svptr->ClientHostName)-1;
   ClientHostNameDsc.dsc$a_pointer = &svptr->ClientHostName;

   Length = 0;
   if (Debug) fprintf (stdout, "sys$qio() IO$_ACPCONTROL\n");
   status = sys$qiow (0, svptr->ServerChannel, IO$_ACPCONTROL,
                      &IOsb, 0, 0, &ControlSubFunctionDsc,
                      &AddressDsc, &Length, &ClientHostNameDsc, 0, 0);
   if (Debug)
      fprintf (stdout, "sys$qio() %%X%08.08X IOsb %%X%08.08X\n",
               status, IOsb.Status);
   if (Length)
      svptr->ClientHostName[Length] = '\0';
   else
      strcpy (svptr->ClientHostName, svptr->ClientIpAddressString);
}

/****************************************************************************/
/*
Just close the socket, bang!
*/

int NetCloseSocket (struct RequestStruct *rqptr)

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetCloseSocket() %d\n", rqptr);

   if (!rqptr->rqNet.ClientChannel) return (SS$_NORMAL);

   status = sys$dassgn (rqptr->rqNet.ClientChannel);
   if (Debug) fprintf (stdout, "sys$dassgn() %%X%08.08X\n", status);
   rqptr->rqNet.ClientChannel = 0;

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_CONNECT))
   {
      if (VMSok(status))
         WatchThis (rqptr, FI_LI, WATCH_CONNECT,
                    "CLOSE !AZ,!UL",
                    rqptr->rqNet.ClientHostName, rqptr->rqNet.ClientPort); 
      else
         WatchThis (rqptr, FI_LI, WATCH_CONNECT,
                    "CLOSE !AZ,!UL %X!8XL %!%M",
                    rqptr->rqNet.ClientHostName, rqptr->rqNet.ClientPort,
                    status, status);
   }

   return (status);
}

/****************************************************************************/
/*
Stop the server from receiving incoming requests.
*/

NetShutdownServerSocket ()

{
   register struct ServiceStruct  *svptr;

   int  status;
   struct  AnIOsb  IOsb;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetShutdownServerSocket()\n");

   for (svptr = ServiceListHead; svptr != NULL; svptr = svptr->NextPtr)
   {
      status = sys$qiow (0, svptr->ServerChannel, IO$_DEACCESS, &IOsb, 0, 0,
                         0, 0, 0, 0, 0, 0);
      if (Debug)
         fprintf (stdout, "sys$qiow() %%X%08.08X IOsb %%X%08.08X\n",
                  status, IOsb.Status);
   }
}

/*****************************************************************************/
/*
Unlike NetWrite() this function writes directly using a client channel/socket,
not using the full request data structure. This is for writing to the client
before any of the request data structures are created (e.g. when the server
denies access).  This is a blocking function, but shouldn't introduce much
granularity as it is only used for short messages before a client thread is
set up.  If it's going to block because it can't proceed then it does not wait.
*/ 

int NetWriteDirect
(
unsigned short Channel,
char *DataPtr,
int DataLength
)
{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetWriteDirect()\n");

   status = sys$qiow (0, Channel, IO$_WRITEVBLK | IO$M_NOWAIT, 0, 0, 0,
                      DataPtr, DataLength, 0, 0, 0, 0);

   if (Debug) fprintf (stdout, "sys$qio() %%X%08.08X\n", status);

   return (status);
}

/*****************************************************************************/
/*
Called from NetWrite() is a response header needs to be sent before any data.
Response header has now been sent, send the data using the buffered
information about it.
*/ 

NetResponseHeaderAst (struct RequestStruct *rqptr)

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetResponseHeaderAst()\n");

   NetWrite (rqptr,
             rqptr->rqResponse.HeaderAstFunctionPtr,
             rqptr->rqResponse.HeaderDataPtr,
             rqptr->rqResponse.HeaderDataLength);
}

/*****************************************************************************/
/*
Write 'DataLength' bytes located at 'DataPtr' to the client either using either
the "raw" network or via the Secure Sockets Layer.

If 'AstFunctionPtr' zero then use sys$qiow(), waiting for completion. If
an AST completion address is supplied then use sys$qio().  If empty data
buffer is supplied (zero length) then declare an AST to service any AST
routine supplied.  If none then just return.

For responses generated by the server the HTTP header is a separate structure
which can be sent separately. If the HTTP method is "HEAD" only allow bytes in
the header to be sent, absorb any other, explicitly calling the AST completion
routine as necessary (this, in particular, is for scripts that don't recognise
this method).

An "Xray" returns a full response (header and body) as a plain text document
(allows diagnostics, etc.) With an Xray just output a hard-wired, plain-text
response with wait for completion (won't be happening enough for any
significant impact!)

Explicitly declares any AST routine if an error occurs. The calling function
must not do any error recovery if an AST routine has been supplied but the
associated AST routine must!  If an AST was not supplied then the return
status can be checked.
*/ 

int NetWrite
(
struct RequestStruct *rqptr,
void *AstFunctionPtr,
char *DataPtr,
int DataLength
)
{
   int  status,
        ResponseHeaderLength;
   char  *ResponseHeaderPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "NetWrite() %d %d %d %d\n",
               rqptr, AstFunctionPtr, DataPtr, DataLength);
   /** if (Debug) fprintf (stdout, "|%s|\n", DataPtr); **/

   if (rqptr->rqTmr.TerminatedCount)
   {
      /* request supervisor has timed it out, fudge network status */
      if (Debug)
         fprintf (stdout, "rqptr->rqTmr.TerminatedCount: %d\n",
                  rqptr->rqTmr.TerminatedCount);
      rqptr->rqNet.WriteIOsb.Status = SS$_ABORT;
      rqptr->rqNet.WriteIOsb.Count = 0;
      if (AstFunctionPtr != NULL) SysDclAst (AstFunctionPtr, rqptr);
      return (rqptr->rqNet.WriteIOsb.Status);
   }

   status = SS$_NORMAL;

   if (!rqptr->rqResponse.HeaderSent)
   {
      /*******************************************/
      /* nothing of response sent to client yet! */
      /*******************************************/

      rqptr->rqResponse.HeaderSent = true;

      if (rqptr->XrayRequest)
      {
         /*********************************/
         /* header for "Xray" of response */
         /*********************************/

         ResponseHeaderPtr = rqptr->rqResponse.HeaderPtr;
         ResponseHeaderLength = rqptr->rqResponse.HeaderLength;

         rqptr->rqResponse.PreExpired = true;
         HTTP_HEADER_200_PLAIN (rqptr);

         if (rqptr->WatchItem &&
             (WatchEnabled & WATCH_RESPONSE_HEADER))
         {
            WatchThis (rqptr, FI_LI, WATCH_RESPONSE_HEADER,
                       "HEADER !UL bytes", rqptr->rqResponse.HeaderLength);
            WatchData (rqptr->rqResponse.HeaderPtr,
                       rqptr->rqResponse.HeaderLength);
         }

         rqptr->BytesTx += rqptr->rqResponse.HeaderLength;

         if (rqptr->SeSoLaPtr == NULL)
            status = NetWriteRaw (rqptr, 0,
                                  rqptr->rqResponse.HeaderPtr,
                                  rqptr->rqResponse.HeaderLength);
         else
            status = SeSoLaWrite (rqptr, 0,
                                  rqptr->rqResponse.HeaderPtr,
                                  rqptr->rqResponse.HeaderLength);

         rqptr->rqResponse.HeaderPtr = ResponseHeaderPtr;
         rqptr->rqResponse.HeaderLength = ResponseHeaderLength;
      }

      if (rqptr->rqResponse.HeaderPtr != NULL &&
          rqptr->rqHeader.HttpVersion != HTTP_VERSION_0_9)
      {
         /************************/
         /* send response header */
         /************************/

         if (Debug)
            fprintf (stdout, "flushing rqptr->rqResponse.HeaderPtr\n|%s|\n",
                     rqptr->rqResponse.HeaderPtr);

         if (!rqptr->rqResponse.HeaderLength)
            rqptr->rqResponse.HeaderLength = strlen(rqptr->rqResponse.HeaderPtr);

         if (rqptr->WatchItem &&
             (WatchEnabled & WATCH_RESPONSE_HEADER) &&
             rqptr != WatchRequestPtr)
         {
            WatchThis (rqptr, FI_LI, WATCH_RESPONSE_HEADER,
                       "HEADER !UL bytes", rqptr->rqResponse.HeaderLength);
            WatchData (rqptr->rqResponse.HeaderPtr,
                       rqptr->rqResponse.HeaderLength);
         }

         rqptr->BytesTx += rqptr->rqResponse.HeaderLength;

         if (AstFunctionPtr != NULL)
         {
            /************************/
            /* AST routine, no wait */
            /************************/

            if (DataLength)
            {
               rqptr->rqResponse.HeaderAstFunctionPtr = AstFunctionPtr;
               rqptr->rqResponse.HeaderDataPtr = DataPtr;
               rqptr->rqResponse.HeaderDataLength = DataLength;
               AstFunctionPtr = &NetResponseHeaderAst;
            }

            if (rqptr->SeSoLaPtr == NULL)
               status = NetWriteRaw (rqptr, AstFunctionPtr,
                                     rqptr->rqResponse.HeaderPtr,
                                     rqptr->rqResponse.HeaderLength);
            else
               status = SeSoLaWrite (rqptr, AstFunctionPtr,
                                     rqptr->rqResponse.HeaderPtr,
                                     rqptr->rqResponse.HeaderLength);

            /* return, the AST function will sys$qiow() the data */
            return (status);
         }
         else
         {
            /************************/
            /* no AST routine, wait */
            /************************/

            if (rqptr->SeSoLaPtr == NULL)
               status = NetWriteRaw (rqptr, 0,
                                     rqptr->rqResponse.HeaderPtr,
                                     rqptr->rqResponse.HeaderLength);
            else
               status = SeSoLaWrite (rqptr, 0,
                                     rqptr->rqResponse.HeaderPtr,
                                     rqptr->rqResponse.HeaderLength);

            /* continue on to sys$qiow() the data */
         }
      }
   }

   /********/
   /* data */
   /********/

   rqptr->BytesTx += DataLength;

   if (!DataLength)
   {
      /* without a real network write just fudge the status */
      rqptr->rqNet.WriteIOsb.Status = SS$_NORMAL;
      rqptr->rqNet.WriteIOsb.Count = 0;
      if (AstFunctionPtr == NULL) return (SS$_NORMAL);
      SysDclAst (AstFunctionPtr, rqptr);
      return (SS$_NORMAL);
   }

   if (rqptr->rqHeader.Method == HTTP_METHOD_HEAD)
   {
      /*****************************/
      /* send only response header */
      /*****************************/

      if (Debug) fprintf (stdout, "method HEAD\n");

      if (rqptr->rqResponse.HeaderPtr == NULL &&
          rqptr->rqResponse.HeaderNewlineCount <= 1 &&
          rqptr->ProxyTaskPtr == NULL)
      {
         /**********************/
         /* header from script */
         /**********************/

         register int  cnt, nlcnt;
         register char  *cptr;

         nlcnt = rqptr->rqResponse.HeaderNewlineCount;
         if (Debug) fprintf (stdout, "nlcnt: %d\n", nlcnt);
         cptr = DataPtr;
         cnt = DataLength;
         while (cnt--)
         {
            if (*cptr == '\n' && ++nlcnt == 2)
            {
               /* two successive end-of-lines, therefore end of header */
               if (Debug) fprintf (stdout, "end-of-header\n");
               cptr++;
               break;
            }
            else
            if (*cptr != '\r' && *cptr != '\n')
               nlcnt = 0;
            cptr++;
         }
         if ((rqptr->rqResponse.HeaderNewlineCount = nlcnt) == 2)
         {
            /* finally found those two consecutive newlines! */
            rqptr->rqResponse.HeaderSent = true;
            if (Debug) fprintf (stdout, "DataLength: %d\n", cptr - DataPtr);
            if (DataLength = cptr - DataPtr)
            {
               /* adjust data length to include only the HTTP header */
               DataLength = cptr - DataPtr;
            }
            else
            {
               /* no data in HTTP header left at all */
               rqptr->rqNet.WriteIOsb.Status = STS$K_SUCCESS;
               rqptr->rqNet.WriteIOsb.Count = 0;
               if (AstFunctionPtr != NULL) SysDclAst (AstFunctionPtr, rqptr);
               return (SS$_NORMAL);
            }
         }
      }
      else
      {
         /* HTTP header has been completely sent, absorb anything else */
         rqptr->rqNet.WriteIOsb.Status = STS$K_SUCCESS;
         rqptr->rqNet.WriteIOsb.Count = 0;
         if (AstFunctionPtr != NULL) SysDclAst (AstFunctionPtr, rqptr);
         return (SS$_NORMAL);
      }
   }

   if (rqptr->rqHeader.HttpVersion == HTTP_VERSION_0_9 &&
       rqptr->rqResponse.HeaderPtr == NULL &&
       rqptr->rqResponse.HeaderNewlineCount <= 1 &&
       rqptr->ProxyTaskPtr == NULL)
   {
      /*********************************/
      /* absorb any header from script */
      /*********************************/

      /* local storage */
      register int  cnt, nlcnt;
      register char  *cptr;

      nlcnt = rqptr->rqResponse.HeaderNewlineCount;
      if (Debug) fprintf (stdout, "HTTP/0.9 nlcnt: %d\n", nlcnt);

      cptr = DataPtr;
      cnt = DataLength;
      while (cnt--)
      {
         if (*cptr == '\n' && ++nlcnt == 2)
         {
            /* two successive end-of-lines, therefore end of header */
            if (Debug) fprintf (stdout, "end-of-header\n");
            cptr++;
            break;
         }
         else
         if (*cptr != '\r' && *cptr != '\n')
            nlcnt = 0;
         cptr++;
      }
      if ((rqptr->rqResponse.HeaderNewlineCount = nlcnt) == 2)
      {
         /* adjust data pointer and length to exclude header */
         rqptr->rqResponse.HeaderSent = true;
         DataLength = cptr - DataPtr;
         DataPtr = cptr;
         if (Debug)
            fprintf (stdout, "DataPtr: %d DataLength: %d\n",
                     DataPtr, DataLength);
      }
      else
      {
         /* no data in HTTP header left at all */
         rqptr->rqNet.WriteIOsb.Status = STS$K_SUCCESS;
         rqptr->rqNet.WriteIOsb.Count = 0;
         if (AstFunctionPtr != NULL) SysDclAst (AstFunctionPtr, rqptr);
         return (SS$_NORMAL);
      }
      /* HTTP header has been completely absorbed, send everything else */
   }

   /*************/
   /* send data */
   /*************/

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_RESPONSE_BODY))
   {
      if (rqptr->rqResponse.HeaderPtr == NULL)
         WatchThis (rqptr, FI_LI, WATCH_RESPONSE_BODY,
                    "STREAM !UL bytes", DataLength);
      else
         WatchThis (rqptr, FI_LI, WATCH_RESPONSE_BODY,
                    "BODY !UL bytes", DataLength);
      WatchDataDump (DataPtr, DataLength);
   }

   if (rqptr->SeSoLaPtr == NULL)
      status = NetWriteRaw (rqptr, AstFunctionPtr, DataPtr, DataLength);
   else
      status = SeSoLaWrite (rqptr, AstFunctionPtr, DataPtr, DataLength);

   return (status);
}

/*****************************************************************************/
/*
Write data to the network. Explicitly declares any AST routine if an error
occurs. The calling function must not do any error recovery if an AST routine
has been supplied but the associated AST routine must! If an AST was not
supplied then the return status can be checked.  AST to NetWriteRaw() which
calls the supplied AST function. 
*/

int NetWriteRaw
(
struct RequestStruct *rqptr,
void *AstFunctionPtr,
char *DataPtr,
int DataLength
)

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "NetWriteRaw() %d %d %d %d\n",
               rqptr, AstFunctionPtr, DataPtr, DataLength);
   /** fprintf (stdout, "|%*.*s|\n", DataLength, DataLength, DataPtr); **/

   if (rqptr->rqTmr.TerminatedCount)
   {
      /* request supervisor has timed it out, fudge network status */
      if (Debug)
         fprintf (stdout, "rqptr->rqTmr.TerminatedCount: %d\n",
                  rqptr->rqTmr.TerminatedCount);
      rqptr->rqNet.WriteIOsb.Status = SS$_ABORT;
      rqptr->rqNet.WriteIOsb.Count = 0;
      if (AstFunctionPtr != NULL) SysDclAst (AstFunctionPtr, rqptr);
      return (rqptr->rqNet.WriteIOsb.Status);
   }

   if (rqptr->rqNet.WriteRawAstFunctionPtr != NULL ||
       !DataLength)
   {
      rqptr->rqNet.WriteIOsb.Status = SS$_BUGCHECK;
      rqptr->rqNet.WriteIOsb.Count = 0;
      if (AstFunctionPtr != NULL) SysDclAst (AstFunctionPtr, rqptr);
      return (rqptr->rqNet.WriteIOsb.Status);
   }
   rqptr->rqNet.WriteRawAstFunctionPtr = AstFunctionPtr;
   rqptr->rqNet.WriteRawDataPtr = DataPtr;
   rqptr->rqNet.WriteRawDataLength = DataLength;

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_NETWORK_OCTETS))
   {
      WatchThis (rqptr, FI_LI, WATCH_NETWORK,
                 "WRITE !UL bytes", DataLength);
      WatchDataDump (DataPtr, DataLength);
   }

   if (AstFunctionPtr == NULL)
   {
      /***************/
      /* blocking IO */
      /***************/

      status = sys$qiow (0, rqptr->rqNet.ClientChannel, IO$_WRITEVBLK,
                         &rqptr->rqNet.WriteIOsb, 0, 0,
                         DataPtr, DataLength, 0, 0, 0, 0);
      if (Debug)
         fprintf (stdout, "sys$qiow() %%X%08.08X %%X%08.08X %d\n",
                  status, rqptr->rqNet.WriteIOsb.Status,
                  rqptr->rqNet.WriteIOsb.Count);

      /* for blocking IO use the status block for status information */
      if (VMSok (status) && VMSnok (rqptr->rqNet.WriteIOsb.Status))
         status = rqptr->rqNet.WriteIOsb.Status;
   }
   else
   {
      /*******************/
      /* non-blocking IO */
      /*******************/

      status = sys$qio (0, rqptr->rqNet.ClientChannel,
                        IO$_WRITEVBLK, &rqptr->rqNet.WriteIOsb,
                        &NetWriteRawAst, rqptr,
                        DataPtr, DataLength, 0, 0, 0, 0);
      if (Debug) fprintf (stdout, "sys$qio() %%X%08.08X\n", status);
   }

   /****************/
   /* check status */
   /****************/

   if (VMSok (status)) return (status);

   /* if resource wait enabled the only quota not waited for is ASTLM */
   if (status == SS$_EXQUOTA)
      ErrorExitVmsStatus (status, "sys$qio()", FI_LI);

   /* write failed, call AST explicitly, status in the IOsb */
   rqptr->rqNet.WriteIOsb.Status = status;
   rqptr->rqNet.WriteIOsb.Count = 0;
   if (NetWriteRawAst) SysDclAst (NetWriteRawAst, rqptr);
   return (status);
}

/*****************************************************************************/
/*
AST from NetWriteRaw().  Call the AST function.
*/ 

NetWriteRawAst (struct RequestStruct *rqptr)

{
   int  status;
   void (*AstFunctionPtr)(struct RequestStruct*);

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "NetWriteRawAst() %%X%08.08X %d\n",
               rqptr->rqNet.WriteIOsb.Status, rqptr->rqNet.WriteIOsb.Count);

   if (rqptr->rqTmr.TerminatedCount)
   {
      /* request supervisor has timed it out, fudge network status */
      if (Debug)
         fprintf (stdout, "rqptr->rqTmr.TerminatedCount: %d\n",
                  rqptr->rqTmr.TerminatedCount);
      rqptr->rqNet.WriteIOsb.Status = SS$_ABORT;
      rqptr->rqNet.WriteIOsb.Count = 0;
   }

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_NETWORK))
   {
      if (VMSok (rqptr->rqNet.WriteIOsb.Status))
         WatchThis (rqptr, FI_LI, WATCH_NETWORK,
                    "WRITE %X!8XL !UL bytes",
                    rqptr->rqNet.WriteIOsb.Status,
                    rqptr->rqNet.WriteIOsb.Count);
      else
         WatchThis (rqptr, FI_LI, WATCH_NETWORK,
                    "WRITE %X!8XL %!%M",
                    rqptr->rqNet.WriteIOsb.Status,
                    rqptr->rqNet.WriteIOsb.Status);
   }

   if (VMSok (rqptr->rqNet.WriteIOsb.Status))
      rqptr->BytesRawTx += rqptr->rqNet.WriteIOsb.Count;

   rqptr->rqNet.WriteRawDataPtr = rqptr->rqNet.WriteRawDataLength = 0;
   if ((AstFunctionPtr = rqptr->rqNet.WriteRawAstFunctionPtr) == NULL) return;
   rqptr->rqNet.WriteRawAstFunctionPtr = NULL;
   (*AstFunctionPtr)(rqptr);
}

/*****************************************************************************/
/*
Wrapper for NetReadRaw().
*/ 

int NetRead
(
struct RequestStruct *rqptr,
void *AstFunctionPtr,
char *DataPtr,
int DataSize
)
{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetRead()\n");

   if (rqptr->rqTmr.TerminatedCount)
   {
      /* request supervisor has timed it out, fudge network status */
      if (Debug)
         fprintf (stdout, "rqptr->rqTmr.TerminatedCount: %d\n",
                  rqptr->rqTmr.TerminatedCount);
      rqptr->rqNet.ReadIOsb.Status = SS$_ABORT;
      rqptr->rqNet.ReadIOsb.Count = 0;
      if (AstFunctionPtr != NULL) SysDclAst (AstFunctionPtr, rqptr);
      return (rqptr->rqNet.ReadIOsb.Status);
   }

   if (rqptr->SeSoLaPtr == NULL)
      status = NetReadRaw (rqptr, AstFunctionPtr, DataPtr, DataSize);
   else
      status = SeSoLaRead (rqptr, AstFunctionPtr, DataPtr, DataSize);
   if (Debug) fprintf (stdout, "status: %%X%08.08X\n", status);
   return (status);
}

/*****************************************************************************/
/*
Queue up a read from the client over the network. If 'AstFunctionPtr' 
is zero then no I/O completion AST routine is called.  If it is non-zero then 
the function pointed to by the parameter is called when the network write 
completes.

Explicitly declares any AST routine if an error occurs. The calling function
must not do any error recovery if an AST routine has been supplied but the
associated AST routine must!  If an AST was not supplied then the return
status can be checked.
*/ 

int NetReadRaw
(
struct RequestStruct *rqptr,
void *AstFunctionPtr,
char *DataPtr,
int DataSize
)
{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "NetReadRaw() %d %d %d %d\n",
               rqptr, AstFunctionPtr, DataPtr, DataSize);

   if (rqptr->rqTmr.TerminatedCount)
   {
      /* request supervisor has timed it out, fudge network status */
      if (Debug)
         fprintf (stdout, "rqptr->rqTmr.TerminatedCount: %d\n",
                  rqptr->rqTmr.TerminatedCount);
      rqptr->rqNet.ReadIOsb.Status = SS$_ABORT;
      rqptr->rqNet.ReadIOsb.Count = 0;
      if (AstFunctionPtr != NULL) SysDclAst (AstFunctionPtr, rqptr);
      return (rqptr->rqNet.ReadIOsb.Status);
   }

   if (rqptr->rqNet.ReadRawAstFunctionPtr != NULL)
   {
      rqptr->rqNet.ReadIOsb.Status = SS$_BUGCHECK;
      rqptr->rqNet.ReadIOsb.Count = 0;
      if (AstFunctionPtr != NULL) SysDclAst (AstFunctionPtr, rqptr);
      return (rqptr->rqNet.ReadIOsb.Status);
   }
   rqptr->rqNet.ReadRawAstFunctionPtr = AstFunctionPtr;
   rqptr->rqNet.ReadRawDataPtr = DataPtr;
   rqptr->rqNet.ReadRawDataSize = DataSize;

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_NETWORK_OCTETS))
      WatchThis (rqptr, FI_LI, WATCH_NETWORK,
                 "READ !UL bytes max", DataSize);

   if (AstFunctionPtr == NULL)
   {
      /***************/
      /* blocking IO */
      /***************/

      status = sys$qiow (0, rqptr->rqNet.ClientChannel,
                         IO$_READVBLK, &rqptr->rqNet.ReadIOsb, 0, 0,
                         DataPtr, DataSize, 0, 0, 0, 0);
      if (Debug)
         fprintf (stdout, "sys$qiow() %%X%08.08X %%X%08.08X %d\n",
                  status, rqptr->rqNet.ReadIOsb.Status,
                  rqptr->rqNet.ReadIOsb.Count);

      /* for blocking IO use the status block for status information */
      if (VMSok (status) && VMSnok (rqptr->rqNet.ReadIOsb.Status))
         status = rqptr->rqNet.ReadIOsb.Status;
   }
   else
   {
      /*******************/
      /* non-blocking IO */
      /*******************/

      status = sys$qio (0, rqptr->rqNet.ClientChannel,
                        IO$_READVBLK, &rqptr->rqNet.ReadIOsb,
                        &NetReadRawAst, rqptr,
                        DataPtr, DataSize, 0, 0, 0, 0);
      if (Debug) fprintf (stdout, "sys$qio() %%X%08.08X\n", status);
   }

   /****************/
   /* check status */
   /****************/

   /* if I/O successful */
   if (VMSok (status)) return (status);

   /* with resource wait enabled the only quota not waited for is ASTLM */
   if (status == SS$_EXQUOTA)
      ErrorExitVmsStatus (status, "sys$qio()", FI_LI);

   /* queuing of read failed, call AST explicitly, status in the IOsb */
   rqptr->rqNet.ReadIOsb.Status = status;
   rqptr->rqNet.ReadIOsb.Count = 0;
   if (NetReadRawAst) SysDclAst (NetReadRawAst, rqptr);
   return (status);
}

/*****************************************************************************/
/*
AST from NetReadRaw().  Call the AST function.
*/ 

NetReadRawAst (struct RequestStruct *rqptr)

{
   int  status;
   void (*AstFunctionPtr)(struct RequestStruct*);

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "NetReadRawAst() %%X%08.08X %d\n",
               rqptr->rqNet.ReadIOsb.Status, rqptr->rqNet.ReadIOsb.Count);

   if (rqptr->rqTmr.TerminatedCount)
   {
      /* request supervisor has timed it out, fudge network status */
      if (Debug)
         fprintf (stdout, "rqptr->rqTmr.TerminatedCount: %d\n",
                  rqptr->rqTmr.TerminatedCount);
      rqptr->rqNet.ReadIOsb.Status = SS$_ABORT;
      rqptr->rqNet.ReadIOsb.Count = 0;
   }

   if (rqptr->WatchItem)
   {
      if ((WatchEnabled & WATCH_NETWORK) ||
          (WatchEnabled & WATCH_NETWORK_OCTETS))
      {
         if (VMSok(rqptr->rqNet.ReadIOsb.Status))
         {
            WatchThis (rqptr, FI_LI, WATCH_NETWORK,
                       "READ %X!8XL !UL bytes",
                       rqptr->rqNet.ReadIOsb.Status,
                       rqptr->rqNet.ReadIOsb.Count);

            if (WatchEnabled & WATCH_NETWORK_OCTETS)
               WatchDataDump (rqptr->rqNet.ReadRawDataPtr,
                              rqptr->rqNet.ReadIOsb.Count);
         }
         else
            WatchThis (rqptr, FI_LI, WATCH_NETWORK,
                       "READ %X!8XL %!%M",
                       rqptr->rqNet.ReadIOsb.Status, rqptr->rqNet.ReadIOsb.Status);
      }
   }

   if (VMSok (rqptr->rqNet.ReadIOsb.Status))
   {
      rqptr->BytesRawRx += rqptr->rqNet.ReadIOsb.Count;
      /* zero bytes with a normal status is a definite no-no (TGV-Multinet) */
      if (!rqptr->rqNet.ReadIOsb.Count) rqptr->rqNet.ReadIOsb.Status = SS$_ABORT;
   }

   rqptr->rqNet.ReadRawDataPtr = rqptr->rqNet.ReadRawDataSize = 0;
   if ((AstFunctionPtr = rqptr->rqNet.ReadRawAstFunctionPtr) == NULL) return;
   rqptr->rqNet.ReadRawAstFunctionPtr = NULL;
   (*AstFunctionPtr)(rqptr);
}

/*****************************************************************************/
/*
This function buffers output without actually sending it to the client until
ready, either when the first buffer fills or when all output is completely
buffered. It will store any amount of output in a linked list of separately
allocated buffers. This is useful when a function that must not be interrupted
can rapidly store all required output without being slowed by actually
transfering it on the network, then flush it all asynchronously (e.g. the
server administration reports, for instance CacheReport(), which are
blocking).

If the data pointer is not NULL and the data length is -1 then the data is
assumed to be a null-terminated string.

Providing an AST parameter and a data parameter implies that after the first
buffer fills (and usually overflows into a second) the current buffered output
should be written to the client.

Providing an AST parameter and setting the data parameter to NULL and
the data length to 0 indicates all the currently buffered contents should be
written to the client.

Providing an AST parameter and setting the data parameter to NULL and the data
length parameter to -1 indicates all the currently buffered contents should be
written to the client if more than buffer-full has been written, otherwise just
declare the AST. 

Providing all parameters as NULL and zero, (except 'rqptr') as appropriate,
results in the data buffer initialized (if it didn't exist) or reset (if it
did).
*/ 

NetWriteBuffered
(
struct RequestStruct *rqptr,
void *AstFunctionPtr,
char *DataPtr,
int DataLength
)
{
   int  status;
   char  *BufferPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "NetWriteBuffered() %d %d %d %d\n",
               rqptr, AstFunctionPtr, DataPtr, DataLength);

   /* if all parameters essentially empty then reset the buffers */
   if (AstFunctionPtr == NULL && DataPtr == NULL && DataLength == 0)
   {
      NetWriteBufferedInit (rqptr, true);
      return;
   }

   /* first call, initialize a buffer */
   if (rqptr->rqOutput.BufferStructPtr == NULL)
      NetWriteBufferedInit (rqptr, true);

   if (rqptr->rqTmr.TerminatedCount)
   {
      /* request supervisor has timed it out, fudge network status */
      if (Debug)
         fprintf (stdout, "rqptr->rqTmr.TerminatedCount: %d\n",
                  rqptr->rqTmr.TerminatedCount);
      rqptr->rqNet.WriteIOsb.Status = SS$_ABORT;
      rqptr->rqNet.WriteIOsb.Count = 0;
      if (AstFunctionPtr != NULL) SysDclAst (AstFunctionPtr, rqptr);
      return;
   }

   if (DataPtr != NULL)
   {
      /**********************/
      /* buffer this output */
      /**********************/

      if (DataLength == -1) DataLength = strlen(DataPtr);

      if (rqptr->rqOutput.BufferEscapeHtml)
      {
         /* escape HTML-forbidden characters */
         NetBufferEscapeHtml (rqptr, DataPtr, DataLength);
      }
      else
      {
         while (DataLength)
         {
            if (Debug)
               fprintf (stdout, "%d %d\n",
                        rqptr->rqOutput.BufferRemaining, DataLength);

            if (DataLength <= rqptr->rqOutput.BufferRemaining)
            {
               /* enough space in this buffer */
               memcpy (rqptr->rqOutput.BufferCurrentPtr, DataPtr, DataLength);
               rqptr->rqOutput.BufferCount += DataLength;
               rqptr->rqOutput.BufferCurrentPtr += DataLength;
               rqptr->rqOutput.BufferRemaining -= DataLength;
               DataLength = 0;
            }
            else
            {
               /* fill up any that's left */
               memcpy (rqptr->rqOutput.BufferCurrentPtr,
                       DataPtr,
                       rqptr->rqOutput.BufferRemaining);
               DataPtr += rqptr->rqOutput.BufferRemaining;
               DataLength -= rqptr->rqOutput.BufferRemaining;
               rqptr->rqOutput.BufferCount += rqptr->rqOutput.BufferRemaining;
               /* need another buffer */
               NetWriteBufferedInit (rqptr, false);
            }
         }
      }
   }

   /* if an AST routine supplied then we can think about buffer flushing */
   if (AstFunctionPtr == NULL) return;

   /* if the first buffer is full or if the flush is being forced */
   if ((DataPtr == NULL && DataLength != -1) ||
       (rqptr->rqOutput.BufferCount > OutputBufferSize))
   {
      /***********************/
      /* flush the buffer(s) */
      /***********************/

      /* force all buffers to be flushed if 'DataPtr' is NULL */
      if (DataPtr == NULL) rqptr->rqOutput.BufferFlush = true;
      /* buffer the AST function pointer */
      rqptr->rqOutput.BufferAstFunctionPtr = AstFunctionPtr;
      /* get the "write now" pointer to the first buffer in the list */
      rqptr->rqOutput.BufferNowStructPtr =
         LIST_HEAD (&rqptr->rqOutput.BufferList);
      /* fudge this status for NetWriteBufferedNow() */
      rqptr->rqNet.WriteIOsb.Status = SS$_NORMAL;
      NetWriteBufferedNow (rqptr);
      return;
   }

   /************************/
   /* just declare the AST */
   /************************/

   /* fudge this status for the AST routine check */
   rqptr->rqNet.WriteIOsb.Status = SS$_NORMAL;
   rqptr->rqNet.WriteIOsb.Count = DataLength;

   SysDclAst (AstFunctionPtr, rqptr);
}

/*****************************************************************************/
/*
Copy the data into the buffer escaping HTML-forbidden characters.  If
'DataLength' is -1 then assumed to be a null-terminated string.
*/ 

NetBufferEscapeHtml
(
struct RequestStruct *rqptr,
char *DataPtr,
int DataLength
)
{
   register int  ch, dcnt, bcnt, brcnt;
   register char  *cptr, *bptr, *dptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "NetBufferEscapeHtml() %d %d\n",
               DataPtr, DataLength);

   /* first call, initialize a buffer */
   if (rqptr->rqOutput.BufferStructPtr == NULL)
      NetWriteBufferedInit (rqptr, true);

   dptr = DataPtr;
   if ((dcnt = DataLength) == -1) dcnt = strlen(dptr);
   bptr = rqptr->rqOutput.BufferCurrentPtr;
   bcnt = rqptr->rqOutput.BufferCount;
   brcnt = rqptr->rqOutput.BufferRemaining;

   while (dcnt)
   {
      if (!brcnt)
      {
         /* need another buffer */
         NetWriteBufferedInit (rqptr, false);
         bptr = rqptr->rqOutput.BufferCurrentPtr;
         brcnt = rqptr->rqOutput.BufferRemaining;
      }

      dcnt--;
      switch (ch = *dptr++)
      {
         case '<' :
            cptr = "&lt;";
            break;
         case '>' :
            cptr = "&gt;";
            break;
         case '&' :
            cptr = "&amp;";
            break;
         case '\"' :
            cptr = "&quot;";
            break;
         default :
            /* insert this character as-is */
            *bptr++ = ch;
            bcnt++; 
            brcnt--;
            continue;
      }

      /* add the escaped character */
      while (*cptr)
      {
         *bptr++ = *cptr++;
         bcnt++; 
         if (--brcnt) continue;
         /* need another buffer */
         NetWriteBufferedInit (rqptr, false);
         bptr = rqptr->rqOutput.BufferCurrentPtr;
         brcnt = rqptr->rqOutput.BufferRemaining;
      }
   }

   rqptr->rqOutput.BufferCurrentPtr = bptr;
   rqptr->rqOutput.BufferRemaining = brcnt;
   rqptr->rqOutput.BufferCount = bcnt;
}

/*****************************************************************************/
/*
This function processes the linked list of output buffers, writing them to the
client, and operates in two distinct modes. First, non-flush mode. In this
mode any full output buffers are written to the client. Any last,
partially-filled buffer is not, instead it is moved to the head of the list to
essentially become the first data in the output buffer to which more can then
be added. In this way when a buffer fills and overflows into a second buffer
the first is written but the second, scantily filled buffer is not. The second
mode is full-flush, where all buffers are written to the client. This is
forced by NetWriteBuffered() whenever an AST routine is supplied but no data
('DataPtr' is NULL).
*/ 

NetWriteBufferedNow (struct RequestStruct *rqptr)

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "NetWriteBufferedNow() %d %d %d %d %d\n",
               rqptr, rqptr->rqOutput.BufferStructPtr,
               rqptr->rqOutput.BufferRemaining,
               rqptr->rqOutput.BufferCount,
               rqptr->rqOutput.BufferFlush);

   if (VMSnok (rqptr->rqNet.WriteIOsb.Status))
   {
      /* network write has failed (as AST), bail out now */
      if (Debug)
         fprintf (stdout, "NetWriteIOsb.Status %%X%08.08X\n",
                  rqptr->rqNet.WriteIOsb.Status);
      SysDclAst (rqptr->rqOutput.BufferAstFunctionPtr, rqptr);
      return;
   }

   if ((rqptr->rqOutput.BufferFlush &&
        rqptr->rqOutput.BufferCount > OutputBufferSize) ||
       rqptr->rqOutput.BufferCount > OutputBufferSize + OutputBufferSize)
   {
      /*
         If flushing all buffers and at least one full buffer in list, or
         if two or more full buffers in list.
      */
      NetWrite (rqptr, &NetWriteBufferedNow,
                LIST_DATA (rqptr->rqOutput.BufferNowStructPtr),
                OutputBufferSize);
      rqptr->rqOutput.BufferCount -= OutputBufferSize;
      /* set the "write now" buffer pointer to the next buffer */
      rqptr->rqOutput.BufferNowStructPtr =
         LIST_NEXT (rqptr->rqOutput.BufferNowStructPtr);
      return;
   }
   else
   if (rqptr->rqOutput.BufferCount > OutputBufferSize)
   {
      /* if one full buffer, then one partially filled, NOTE the AST! */
      NetWrite (rqptr, rqptr->rqOutput.BufferAstFunctionPtr,
                LIST_DATA (rqptr->rqOutput.BufferNowStructPtr),
                OutputBufferSize);
      rqptr->rqOutput.BufferCount -= OutputBufferSize;
      /*
         Move currently-being-written-to buffer to the head of the list,
         effectively to the front of the buffer.
      */
      ListMoveHead (&rqptr->rqOutput.BufferList, rqptr->rqOutput.BufferStructPtr);
      return;
   }
   else
   {
      /* if last buffer in linked list, write whatever remains in it */
      NetWrite (rqptr, rqptr->rqOutput.BufferAstFunctionPtr,
                LIST_DATA (rqptr->rqOutput.BufferNowStructPtr),
                rqptr->rqOutput.BufferCount);
      /* reset the buffer(s) */
      NetWriteBufferedInit (rqptr, true);
      /* no more buffers therefore flush (if set) is complete */
      rqptr->rqOutput.BufferFlush = false;
      return;
   }
}

/*****************************************************************************/
/*
Get another output buffer.
*/ 

NetWriteBufferedInit
(
struct RequestStruct *rqptr,
boolean ResetBuffers
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "++++++++++++++++++++++++++++++++++\n");
   if (Debug) fprintf (stdout, "NetWriteBufferedInit()\n");

   if (ResetBuffers && !LIST_EMPTY (&rqptr->rqOutput.BufferList))
   {
      /* reset a non-empty list to the first buffer */
      if (Debug) fprintf (stdout, "reset non-empty\n");
      rqptr->rqOutput.BufferStructPtr = LIST_HEAD (&rqptr->rqOutput.BufferList);
      rqptr->rqOutput.BufferPtr = LIST_DATA (rqptr->rqOutput.BufferStructPtr);
      rqptr->rqOutput.BufferCurrentPtr = rqptr->rqOutput.BufferPtr;
      rqptr->rqOutput.BufferRemaining = OutputBufferSize;
      rqptr->rqOutput.BufferCount = 0;
      return;
   }

   if (rqptr->rqOutput.BufferStructPtr != NULL &&
       LIST_HAS_NEXT (rqptr->rqOutput.BufferStructPtr))
   {
      /* reuse a previously allocated buffer from the list */
      if (Debug) fprintf (stdout, "reuse\n");
      rqptr->rqOutput.BufferStructPtr =
         LIST_NEXT (rqptr->rqOutput.BufferStructPtr);
      rqptr->rqOutput.BufferPtr = LIST_DATA (rqptr->rqOutput.BufferStructPtr);
      rqptr->rqOutput.BufferCurrentPtr = rqptr->rqOutput.BufferPtr;
      rqptr->rqOutput.BufferRemaining = OutputBufferSize;
      return;
   }

   /* allocate the first or another buffer to the list */
   if (Debug) fprintf (stdout, "new\n");
   rqptr->rqOutput.BufferStructPtr =
      VmGetHeap (rqptr, sizeof(struct ListEntryStruct) + OutputBufferSize + 3);
   ListAddTail (&rqptr->rqOutput.BufferList, rqptr->rqOutput.BufferStructPtr);
   rqptr->rqOutput.BufferPtr = LIST_DATA (rqptr->rqOutput.BufferStructPtr);
   rqptr->rqOutput.BufferCurrentPtr = rqptr->rqOutput.BufferPtr;
   rqptr->rqOutput.BufferRemaining = OutputBufferSize;
}

/*****************************************************************************/
/*
Report that client host name has been denied access to the server.
*/
 
NetAccessDenied
(
unsigned short Channel,
char *HostName,
char *IpAddressString
)
{
   static $DESCRIPTOR (MessageFaoDsc,
"HTTP/1.0 403 Forbidden\r\n\
Content-Type: text/html!AZ!AZ\r\n\
\r\n\
<HTML>\n\
<HEAD>\n\
<TITLE>!AZ 403</TITLE>\n\
</HEAD>\n\
!AZ\n\
!AZ\n\
</BODY>\n\
</HTML>\n");

   short  Length;
   char  Buffer [512];
   $DESCRIPTOR (BufferDsc, Buffer);

   /*********/
   /* begin */
   /*********/

   if (Config.cfContent.CharsetDefault[0])
      sys$fao (&MessageFaoDsc, &Length, &BufferDsc,
         "; charset=", Config.cfContent.CharsetDefault,
         MsgForNoRequest(HostName,IpAddressString,MSG_STATUS_ERROR),
         Config.cfServer.ReportBodyTag,
         MsgForNoRequest(HostName,IpAddressString,MSG_GENERAL_ACCESS_DENIED));
   else
      sys$fao (&MessageFaoDsc, &Length, &BufferDsc,
         "", "",
         MsgForNoRequest(HostName,IpAddressString,MSG_STATUS_ERROR),
         Config.cfServer.ReportBodyTag,
         MsgForNoRequest(HostName,IpAddressString,MSG_GENERAL_ACCESS_DENIED));
   Buffer[Length] = '\0';

   NetWriteDirect (Channel, Buffer, Length);
}

/*****************************************************************************/
/*
Report that there is already the limit of client connections.
*/
 
NetTooBusy
(
unsigned short Channel,
char *HostName,
char *IpAddressString
)
{
   static $DESCRIPTOR (MessageFaoDsc,
"HTTP/1.0 502 Busy\r\n\
Content-Type: text/html!AZ!AZ\r\n\
\r\n\
<HTML>\n\
<HEAD>\n\
<TITLE>!AZ 502</TITLE>\n\
</HEAD>\n\
!AZ\n\
!AZ\n\
</BODY>\n\
</HTML>\n");

   short  Length;
   char  Buffer [512];
   $DESCRIPTOR (BufferDsc, Buffer);

   /*********/
   /* begin */
   /*********/

   if (Config.cfContent.CharsetDefault[0])
      sys$fao (&MessageFaoDsc, &Length, &BufferDsc,
         "; charset=", Config.cfContent.CharsetDefault,
         MsgForNoRequest(HostName,IpAddressString,MSG_STATUS_ERROR),
         Config.cfServer.ReportBodyTag,
         MsgForNoRequest(HostName,IpAddressString,MSG_GENERAL_TOO_BUSY));
   else
      sys$fao (&MessageFaoDsc, &Length, &BufferDsc,
         "", "",
         MsgForNoRequest(HostName,IpAddressString,MSG_STATUS_ERROR),
         Config.cfServer.ReportBodyTag,
         MsgForNoRequest(HostName,IpAddressString,MSG_GENERAL_TOO_BUSY));
   Buffer[Length] = '\0';

   NetWriteDirect (Channel, Buffer, Length);
}

/****************************************************************************/

*                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  