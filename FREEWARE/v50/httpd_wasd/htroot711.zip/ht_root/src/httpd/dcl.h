/*****************************************************************************/
/*
                                  DCL.h
*/     
/*****************************************************************************/

#ifndef DCL_H_LOADED
#define DCL_H_LOADED 1

#include "wasd.h"

/* number of times a 'not activated' script is retried */
#define DCL_MAX_SCRIPT_RETRY  5

/* number of times a script can output an ENDOFFILE */
#define DCL_SCRIPT_MAX_ENDOFFILE  50

/* location of script scratch area */
#define DCL_HTTPD_SCRATCH "HT_SCRATCH"

/* no world or group access */
#define DCL_SUBPROCESS_MBX_PROT_MASK 0xff00

/* size of buffer for DCL/CLI strings (can be multiple '\n' delimited) */
#define DCL_COMMAND_BUFFER_SIZE 512

#define DCL_TASK_TYPE_NONE            0
#define DCL_TASK_TYPE_CLI             1
#define DCL_TASK_TYPE_CGI_SCRIPT      2
#define DCL_TASK_TYPE_CGIPLUS_SCRIPT  3
#define DCL_TASK_TYPE_RTE_SCRIPT      4

#define DCL_FIND_SCRIPT_BEGIN   1
#define DCL_FIND_SCRIPT_EXE     2
#define DCL_FIND_SCRIPT_RUNTIME 3

/**************/
/* structures */
/**************/

struct DclCrePrcTermStruct
{
    unsigned short int acc$w_msgtyp;
    unsigned short int acc$w_msgsiz;
    unsigned int acc$l_finalsts;
    unsigned int acc$l_pid;
    unsigned int acc$l_jobid;
    unsigned int acc$q_termtime [2];
    char acc$t_account [8];
    char acc$t_username [12];
    unsigned int acc$l_cputim;
    unsigned int acc$l_pageflts;
    unsigned int acc$l_pgflpeak;
    unsigned int acc$l_wspeak;
    unsigned int acc$l_biocnt;
    unsigned int acc$l_diocnt;
    unsigned int acc$l_volumes;
    unsigned int acc$q_login [2];
    unsigned int acc$l_owner;
};

struct DclScriptNameCacheStruct
{
   struct  ListEntryStruct  DclListEntry;

   int  /* number of times "hit" since last cache file name load */
        HitCount;

   unsigned long  /* last time loaded/hit */
                  LastBinaryTime [2];

   char  /* the mapped script file name returned after mapping */
         ScriptFileName [ODS_MAX_FILE_NAME_LENGTH+1],
         /* the full searched-for script file name */
         ResFileName [ODS_MAX_FILE_NAME_LENGTH+1],
         /* or RTE file name */
         RteFileName [ODS_MAX_FILE_NAME_LENGTH+1];

   char  /* points to how the script is to be invoked */
         *ScriptRunTimePtr;
};

struct DclTaskStruct
{
   struct  ListEntryStruct  DclListEntry;

   boolean  /* add a newline to each record from a script subprocess */
            AddNewline,
            /* record-by-record output from DCL, flush immediately */
            BufferRecords,
            /* strip client I/O records of carriage-control */
            ClientReadStripCrLf,
            /* output is text (plain or html) */
            ContentTypeText,
            /* indicate it's a detached not subprocess */
            CrePrcDetachProcess,
            /* absorb login meassages etc., with detached script processes */
            CrePrcDetachStarting,
            /* DclFindScript() is currently using the structure */
            FindScript,
            /* when the task completes the subprocess is deleted */
            MarkedForDelete,
            /* subprocess read data/variables (i.e. became active) */
            ScriptProcessActivated,
            /* subprocess provided response (i.e. sent some output) */
            ScriptProcessResponded;
            
   int  /* */
        AgentUsageCount,
        /* copied from request structure for WATCHing purposes */
        WatchItem,
        /* number of times the CGIplus script has been used */
        CgiPlusUsageCount,
        /* size of storage when reading directly from client to HTTP$INPUT */
        ClientReadBufferSize,
        /* remaining content in POST script */
        ContentLength,
        /* */
        FindScriptRunTimeIdx,
        /* */
        FindScriptState,
        /* used by the DclSupervisor() */
        LifeTimeCount,
        /* count of I/Os CGIplus variables reads still outstanding */
        QueuedCgiPlusIn,
        /* count of network/client->HTTP$INPUT reads still outstanding */
        QueuedClientRead,
        /* count of HTTP$INPUT reads still outstanding */
        QueuedHttpInput,
        /* count of I/Os between subprocess and HTTPd still outstanding */
        QueuedSysCommand,
        /* when the count of I/Os is considered task finished */
        QueuedSysCommandAllowed,
        /* count of I/Os between subprocess and HTTPd still outstanding */
        QueuedSysOutput,
        /* SYS$OUTPUT end-of-files are ignored, ensure the script behaves */
        SysOutputEndOfFileCount,
        /* size of DCL subprocess' SYS$OUTPUT buffer */
        SysOutputSize,
        /* whether it's a command, CGI script, agent, etc. */
        TaskType,
        /* total number of times the task slot was used */
        TotalUsageCount,
        /* number of subprocess has been a zombie */
        ZombieCount;

   unsigned short  /* channel to subprocess' CGIPLUSIN mailbox */
                   CgiPlusInChannel,
                   /* channel to subprocess' sys$creprc() termination mailbox */
                   CrePrcTermMbxChannel,
                   /* device unit of sys$creprc() termination mailbox */
                   CrePrcTermMbxUnit,
                   /* channel to subprocess' HTTP$INPUT mailbox */
                   HttpInputChannel,
                   /* channel to subprocess' SYS$INPUT mailbox */
                   SysCommandChannel,
                   /* channel to subprocess' SYS$OUTPUT mailbox */
                   SysOutputChannel,
                   /* some are easier :^) to report via sys$output status */
                   ViaSysOutputStatus;

   unsigned long  /* subprocess' PID */
                  ScriptProcessPid;

   unsigned long  /* last time CGIplus script was used */
                  LastUsedBinaryTime [2];

   char  /* storage for when reading directly from client to HTTP$INPUT */
         *ClientReadBufferPtr,
         /* content pointer in POST script */
         *ContentPtr,
         /* points to the file name being used in parse/search */
         *FindScriptFileNamePtr,
         /* points to a string denoting how the script is invoked */
         *ScriptRunTimePtr,
         /* heap storage for buffering subprocess' SYS$OUTPUT */
         *SysOutputPtr;

   char  /* device name of subprocess' CGIPLUSIN mailbox */
         CgiPlusInDevName [64],
         /* device name of sys$creprc() process termination mailbox */
         CrePrcTermMbxDevName [64],
         /* user name persona the sys$creprc() process created under */
         CrePrcUserName [13],
         /* DCL command (from SSI, etc.) can contain multiple commands */
         DclCommand [DCL_COMMAND_BUFFER_SIZE],
         /* device name of subprocess' HTTP input mailbox */
         HttpInputDevName [64],
         /* the name of the script file being executed */
         RteFileName [ODS_MAX_FILE_NAME_LENGTH+1],
         /* script name */
         ScriptName [SCRIPT_NAME_SIZE],
         /* the name of the script file being executed */
         ScriptFileName [ODS_MAX_FILE_NAME_LENGTH+1],
         /* device name of subprocess' input mailbox */
         SysCommandDevName [64],
         /* device name of subprocess' output mailbox */
         SysOutputDevName [64];

   /* sentinal I/O sequences */

   int  /* length of the detached-script-output sequence */
        CgiBelLength,
        /* length of the end-of-file (output) sequence */
        CgiEofLength,
        /* length of the agent end-of-text sequence */
        CgiEotLength,
        /* length of the "escape" sequence */
        CgiEscLength;

   char  /* beginning of detached-script-output sequence */
         CgiBel [32],
         /* end-of-file (output) sequence */
         CgiEof [32],
         /* agent end-of-text sequence */
         CgiEot [32],
         /* CGI "escape" sequence */
         CgiEsc [32];

   struct AnIOsb  CgiPlusInIOsb,
                  CrePrcTermMbxIOsb,
                  HttpInputIOsb,
                  SysCommandIOsb,
                  SysOutputIOsb;

   /* sys$creprc() process termination accounting record */
   struct DclCrePrcTermStruct  CrePrcTermRecord;

   /* string descriptors for the various mailbox device names */
   struct dsc$descriptor_s  CgiPlusInDevNameDsc;
   struct dsc$descriptor_s  CrePrcTermMbxDevNameDsc;
   struct dsc$descriptor_s  HttpInputDevNameDsc;
   struct dsc$descriptor_s  SysCommandDevNameDsc;
   struct dsc$descriptor_s  SysOutputDevNameDsc;

   /* "on-disk structure" when finding a script file */
   struct  OdsStruct  SearchOds;

   /* pointer a request using this DCL task structure */
   struct RequestStruct  *RequestPtr;

   /* pointer to function, for specifying an "escape" processing function */
   void (*CalloutFunction)(struct RequestStruct*);

   /* pointer to function, for specifying the next task */
   void (*NextTaskFunction)(struct RequestStruct*);
};

/***********************/
/* function prototypes */
/***********************/

/* NOTE ... pointers to request structure! */
DclAllocateTask (struct RequestStruct*, int, char*, int, char*, char*); 
DclBegin (struct RequestStruct*, void*, char*, char*,
          char*, char*, char*, void*); 

DclBeginScript (struct DclTaskStruct*);

/* NOTE ... pointer to request structure! */
DclCalloutQio (struct RequestStruct*, char*, int); 
DclCalloutResume (struct RequestStruct*);
DclCalloutDefault (struct RequestStruct*);

DclCgiPlusInAst (struct DclTaskStruct*);
DclCgiPlusLifeTimeAst (struct DclTaskStruct*);
void DclCleanupScratch (struct FAB*);
DclClientReadAst (struct RequestStruct*);
DclClientReadHttpInputAst (struct DclTaskStruct*);
int DclCgiScriptSysCommand (struct DclTaskStruct*);
int DclCgiPlusScriptCgiPlusIn (struct DclTaskStruct*);
DclConcludeTask (struct DclTaskStruct*, boolean);
DclCreateScriptProcess (struct DclTaskStruct*, char*, int);
DclDeallocateTask (struct DclTaskStruct*);
DclEscapeInProgress (struct DclTaskStruct*);
DclFindScript (struct DclTaskStruct*);
DclFindScriptEnd (struct DclTaskStruct*, boolean);
DclFindScriptParseAst (struct FAB*);
DclFindScriptSearchAst (struct FAB*);
DclHttpInputAst (struct DclTaskStruct*);
DclQioSysCommand (struct DclTaskStruct*, char*, int);
DclQioCgiPlusIn (struct DclTaskStruct*, char*, int);
DclQioSysOutput (struct DclTaskStruct*);

/* NOTE ... pointer to request structure! */
DclSysOutputToClientAst (struct RequestStruct*);

DclPlusScriptSysCommand (struct DclTaskStruct*);
DclPlusScriptSysCgiPlusIn (struct DclTaskStruct*);
DclPurgeScriptNameCache ();
DclPurgeCgiPlusScripts (struct RequestStruct*, void*, boolean);
DclSysCommandAst (struct DclTaskStruct*);
DclSearchScriptNameCache (struct DclTaskStruct*, struct RequestStruct*);
DclScriptProcessCompletionAST (struct DclTaskStruct*);
DclSysOutputHeader (struct DclTaskStruct*);
DclSysOutputLocation (struct DclTaskStruct*);
DclSysOutputAst (struct DclTaskStruct*);
DclSysOutputWaitAst (struct DclTaskStruct*);
DclSetZombieLifeTime (struct DclTaskStruct*);
DclUpdateScriptNameCache (struct DclTaskStruct*);
DclZombieLifeTimeAst (struct DclTaskStruct*);

char* DclControlPurgeScriptProcesses (boolean);

#endif /* DCL_H_LOADED */

/*****************************************************************************/

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        