/*****************************************************************************/
/*
                                 File.c

This module implements a full multi-threaded, AST-driven, asynchronous file 
send.  The AST-driven nature makes the code a little more difficult to follow, 
but creates a powerful, event-driven, multi-threaded server.  All of the 
necessary functions implementing this module are designed to be non-blocking. 

It uses the same buffer space as, and interworks with, NetWriteBuffered().  If 
there is already data (text) buffered in this area the file module will, for 
record-oriented, non-HTML-escaped transfers, continue to fill the area (using 
its own buffering function), flushing when and if necessary.  At end-of-file 
explicitly flush the buffer only if escaping HTML-forbidden characters, 
otherwise allow subsequent processing to do it as necessary.  For binary-mode 
files the buffer is explicitly flushed before commencing the file transfer. 

It handles both VARIABLE file (record-by-record) and STREAM, FIXED and
UNDEFINED file (virtual block- oriented) transfers. Even with record mode
efficiency is increased by building up a series of file records in available
buffer space before transfering them as one I/O to the network. The binary
mode reads as many virtual blocks as will fit into the available buffer, then
transfers these as one I/O to the network. NON-VARIABLE FORMAT FILES ARE BY
FAR THE MOST EFFICIENT TO HANDLE.

For text mode transfers (record-oriented) the completion of each read of the 
next record using FileNextRecord() calls FileNextRecordAst().  This function 
checks if the record buffer is full (by detecting if the last read failed with 
a "record too big for user's buffer" error).  If full it writes the buffer to 
the network using NetWrite(), which when complete calls FileNextRecord() as 
an AST routine.  This begins by getting the next record again (the one that 
failed).  If the buffer is not full FileNextRecordAst() just calls 
FileNextRecord() to get the next record, until the buffer fills. 

For binary mode transfers (non-record oriented) the completion of each read of 
the next series of blocks using FileNextBlocks() calls FileNextBlocksAst().  
This function writes the blocks (binary) using NetWrite() which when 
complete calls FileNextBlocks() as an AST.  This in turn calls 
FileNextBlocksAst(), etc., which drives the transfer until EOF. 

The module can encapsulate plain-text and escape HTML-forbidden characters. 

Works in conjunction with the CACHE module. Two different buffer spaces are
used. A file read can be simultaneously used to send the data to the client
and load a cache buffer. The request structure fields 'CacheContentPtr' and
'CacheContentCount' being used in both block I/O and record mode access to
track through the available buffer space, for this located in the cache
structure. For non-cache-load reads uses the standard buffer space pointed to
by 'OutputBufferPtr' and for record mode access tracked using
'OutputBufferCurrentPtr' and 'OutputBufferRemaining' fields.

Implements defacto HTTP/1.0 persistent connections.  Only provide "keep-alive"
response if we're sending a file in binary mode and know its precise length.
An accurate "Content-Length:" field is vital for the client's correct reception
of the transmitted data.  Currently the only other time a "keep-alive" response
can be provided is when a "304 not-modified" header is returned (it has a
content length of precisely zero!).  October 1997: noted that Netscape
Navigator 3.n seems to pay no attention to a "Content-Length: 0" with a
"Keep-Alive:" connection, it just sits there waiting until the keep-alive time
closes the connection, after which it reports "document contains no data".
(IE 3.02 seems to behave correctly ;^)  I have therefore disabled persistent
connections for zero-length files.

Uses the ACP-QIO interface detailed in the "OpenVMS I/O User's Reference
Manual" to retrieve file record attributes, revision date/time and size.


VERSION HISTORY
---------------
06-DEC-2000  MGD  make a search list DNF appear as a FNF
01-SEP-2000  MGD  add optional, local path authorization
                  (for calls from the likes of SSI.C)
09-JUN-2000  MGD  search-list processing refined
04-MAR-2000  MGD  use NetWriteInit(), et.al.
27-DEC-1999  MGD  support ODS-2 and ODS-5 using ODS module
10-OCT-1999  MGD  "scrunched" (in fact all) SSI files, prevent streamLFing
17-SEP-1999  MGD  bugfix; sys$parse() NAM$M_NOCONCEAL for search lists
23-MAY-1999  MGD  do not allow "?httpd=content" requests to be cached
05-FEB-1999  MGD  bugfix; FileNextRecord() zero '_usz'
07-NOV-1998  MGD  WATCH facility
19-SEP-1998  MGD  improve granularity of file open, connect, close, ACP
14-MAY-1998  MGD  request-specified content-type ("httpd=content&type=")
19-MAR-1998  MGD  buffer VBN and first free byte for use by cache module
19-JAN-1998  MGD  new NetWriteBuffered() and structures
07-JAN-1998  MGD  groan, bugfix; record processing for files > 4096 bytes
                  completely brain-dead ... sorry
22-NOV-1997  MGD  sigh, bugfix; heap corruption by file cache
05-OCT-1997  MGD  file cache,
                  keep-alive now not used if the content-length is zero
17-SEP-1997  MGD  if block-mode open is locked retry open in record-mode
17-AUG-1997  MGD  message database,
                  SYSUAF-authenticated users security-profile,
                  addressed potential problem with FIXed and odd-byte records
08-JUN-1997  MGD  if request "Pragma: no-cache" then always return 
27-FEB-1997  MGD  delete on close for "temporary" files
01-FEB-1997  MGD  HTTPd version 4
01-AUG-1996  MGD  Variable to stream-LF file conversion "on-the-fly"
12-APR-1996  MGD  determine read method (record or binary) from record format;
                  implemented persistent connections ("keep-alive")
01-DEC-1995  MGD  HTTPd version 3
27-SEP-1995  MGD  added If-Modified-Since: functionality;
                  changed carriage-control on records from <CR><LF> to single
                  <LF> ('\n' ... newline), to better comply with some browsers
                  (Netscape was spitting on X-bitmap files, for example!)
07-AUG-1995  MGD  ConfigcfReport.MetaInfoEnabled to allow physical file
                  specification included as commentary within an HTML file
13-JUL-1995  MGD  bugfix; occasionally a record was re-read after flushing
                  the records accumulated in the buffer NOT due to RMS$_RTB
20-DEC-1994  MGD  initial development for multi-threaded daemon
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <atrdef.h>
#include <descrip.h>
#include <iodef.h>
#include <libdef.h>
#include <rms.h>
#include <rmsdef.h>
#include <ssdef.h>
#include <stsdef.h>

/* application header files */
#include "ods.h"
#include "wasd.h"

#define WASD_MODULE "FILE"

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern boolean  CacheEnabled,
                OdsExtended;

extern int  WatchEnabled,
            OutputBufferSize;

extern char  ConfigContentTypeSsi[],
             ConfigContentTypeUnknown[],
             ConfigDefaultFileContentType[],
             HttpProtocol[],
             SoftwareID[];

extern struct AccountingStruct  Accounting;
extern struct ConfigStruct  Config;
extern struct MsgStruct  Msgs;

/*****************************************************************************/
/*
Begin to transfer a "flat" file.  
*/ 
 
FileBegin
(
struct RequestStruct *rqptr,
void *NextTaskFunction,
void *FileOpenErrorFunction,
char *FileName,
char *ContentTypePtr,
boolean CacheAllowed,
boolean PreTagFileContents,
boolean EscapeHtml,
boolean AuthorizePath
)
{
   register char  *cptr, *sptr, *zptr;
   register struct FileTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "FileBegin() %d |%s|%s|\n",
               rqptr->rqResponse.ErrorReportPtr, FileName, ContentTypePtr);

   if (rqptr->rqResponse.ErrorReportPtr != NULL)
   {
      /* previous error, cause threaded processing to unravel */
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_RESPONSE))
      WatchThis (rqptr, FI_LI, WATCH_RESPONSE, "FILE !AZ", FileName);

   /* set up the task structure (possibly multiple serially) */
   if (rqptr->FileTaskPtr == NULL)
   {
      rqptr->FileTaskPtr = tkptr = (struct FileTaskStruct*)
         VmGetHeap (rqptr, sizeof(struct FileTaskStruct));
   }
   else
   {
      tkptr = rqptr->FileTaskPtr;
      memset (tkptr, 0, sizeof(struct FileTaskStruct));
   }

   /* must be set before ever calling FileEnd() */
   tkptr->NextTaskFunction = NextTaskFunction;

   cptr = FileName;
   zptr = (sptr = tkptr->FileName) + sizeof(tkptr->FileName);
   while (*cptr && sptr < zptr) *sptr++ = *cptr++;
   if (sptr >= zptr)
   {
      ErrorGeneralOverflow (rqptr, FI_LI);
      FileEnd (rqptr);
      return;
   }
   *sptr = '\0';
   tkptr->FileNameLength = sptr - tkptr->FileName;

   tkptr->FileOpenErrorFunction = FileOpenErrorFunction;
   tkptr->CacheAllowed = CacheAllowed;

   if (ConfigSameContentType (ContentTypePtr, ConfigContentTypeUnknown, -1))
   {
      /* if the content-type is not known then use the default */
      if (Config.cfContent.ContentTypeDefaultPtr[0])
         tkptr->ContentTypePtr = Config.cfContent.ContentTypeDefaultPtr;
      else
         tkptr->ContentTypePtr = ConfigDefaultFileContentType;
   }
   else
   {
      /* otherwise it's whatever it was initially resolved to */
      tkptr->ContentTypePtr = ContentTypePtr;
   }

   if (tkptr->PreTagFileContents = PreTagFileContents)
      tkptr->EscapeHtml = true;
   else
      tkptr->EscapeHtml = EscapeHtml;

   if (AuthorizePath)
   {
      /***********************/
      /* check authorization */
      /***********************/

      cptr = MapVmsPath (tkptr->FileName, rqptr);
      Authorize (rqptr, cptr, -1, &FileAuthorizationAst);
      if (Debug)
         fprintf (stdout, "rqAuth.FinalStatus: %%X%08.08X\n",
                  rqptr->rqAuth.FinalStatus);
      if (VMSnok (rqptr->rqAuth.FinalStatus))
      {
         /* if asynchronous authentication is underway then just wait for it */
         if (rqptr->rqAuth.FinalStatus == AUTH_PENDING) return;
         FileEnd (rqptr);
         return;
      }
   }

   /* not to-be-authorized, or authorized ... just carry on regardless! */
   FileAuthorizationAst (rqptr);
} 

/*****************************************************************************/
/*
This function provides an AST target is Authorize()ation ended up being done
asynchronously, otherwise it is just called directly to continue the modules
processing.
*/

FileAuthorizationAst (struct RequestStruct *rqptr)

{
   int  status;
   struct FileTaskStruct  *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "FileAuthorizationAst() %%X%08.08X\n",
               rqptr->rqAuth.FinalStatus);

   if (VMSnok (rqptr->rqAuth.FinalStatus))
   {
      FileEnd (rqptr);
      return;
   }

   tkptr = rqptr->FileTaskPtr;

   if (rqptr->rqAuth.VmsUserProfileLength)
   {
      /*****************************************/
      /* check VMS-authenticated user's access */
      /*****************************************/

      status = AuthVmsCheckUserAccess (rqptr, tkptr->FileName,
                                       tkptr->FileNameLength);
      if (status == RMS$_PRV)
         tkptr->AuthVmsUserHasAccess = false;
      else
      if (VMSok (status))
         tkptr->AuthVmsUserHasAccess = true;
      else
      {
         /* error reported by access check */
         FileEnd (rqptr);
         return;
      }
   }
   else
      tkptr->AuthVmsUserHasAccess = false;

   /*******************/
   /* parse file name */
   /*******************/

   OdsParse (&tkptr->FileOds,
             tkptr->FileName, tkptr->FileNameLength, ".", 1,
             0, &FileParseAst, rqptr);
} 

/*****************************************************************************/
/*
AST called from FileBegin() when asynchronous parse completes.  If status OK
set up and queue an ACP QIO to get file size and revision date/time, ASTing to
FileAcpInfoAst().
*/

FileParseAst (struct FAB *FabPtr)

{
   register struct RequestStruct  *rqptr;
   register struct FileTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "FileParseAst() sts: %%X%08.08X stv: %%X%08.08X\n",
               FabPtr->fab$l_sts, FabPtr->fab$l_stv);

   rqptr = FabPtr->fab$l_ctx;
   tkptr = rqptr->FileTaskPtr;

   if (VMSok (status = tkptr->FileOds.Fab.fab$l_sts))
   {
      if ((strsame (tkptr->FileOds.NamTypePtr,
                    HTA_FILE_TYPE, sizeof(HTA_FILE_TYPE)-1) &&
           *(tkptr->FileOds.NamTypePtr+sizeof(HTA_FILE_TYPE)-1) == ';') ||
          (strsame (tkptr->FileOds.NamTypePtr,
                    HTL_FILE_TYPE, sizeof(HTL_FILE_TYPE)-1) &&
           *(tkptr->FileOds.NamTypePtr+sizeof(HTL_FILE_TYPE)-1) == ';'))
      {
         /* attempt to retrieve an HTA/HTL authorization file, scotch that! */
         status = SS$_NOPRIV;
      }
   }

   /* if a wildcard the ACP function will return the first matching file! */
   if (tkptr->FileOds.Nam_fnb & NAM$M_WILDCARD) status = RMS$_WLD;

   if (VMSnok (status))
   {
      /* if its a search list treat directory not found as if file not found */
      if ((tkptr->FileOds.Nam_fnb & NAM$M_SEARCH_LIST) && status == RMS$_DNF)
         status = RMS$_FNF;

      if (tkptr->FileOpenErrorFunction != NULL)
      {
         /* do not report the error, the alternate function will handle it */

         if (rqptr->WatchItem &&
             (WatchEnabled & WATCH_RESPONSE))
            WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                       "FILE %X!8XL %!%M", status, status);

         rqptr->HomePageStatus = status;
         tkptr->NextTaskFunction = tkptr->FileOpenErrorFunction;
         FileEnd (rqptr);
         return;
      }
      rqptr->rqResponse.ErrorTextPtr = MapVmsPath (tkptr->FileName, rqptr);
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->FileName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      FileEnd (rqptr);
      return;
   }

   if (tkptr->FileOds.Nam_fnb & NAM$M_SEARCH_LIST &&
       !tkptr->SearchListCount++)
   {
      /*******************************/
      /* search to get actual device */
      /*******************************/

      if (Debug) fprintf (stdout, "SEARCH-LIST!\n");

      if (tkptr->AuthVmsUserHasAccess)
      {
         EnableSysPrv();
         OdsSearch (&tkptr->FileOds, NULL, rqptr);
         DisableSysPrv();
         /* explicitly call the AST routine */
         FileParseAst (&tkptr->FileOds.Fab);
         return;
      }
      else
      {
         OdsSearch (&tkptr->FileOds, &FileParseAst, rqptr);
         return;
      }
   }

   /************/
   /* ACP info */
   /************/

   if (tkptr->AuthVmsUserHasAccess)
   {
      EnableSysPrv();
      OdsFileAcpInfo (&tkptr->FileOds, NULL, rqptr); 
      DisableSysPrv();
      /* now call the AST routine explicitly */
      FileAcpInfoAst (rqptr);
   }
   else
      OdsFileAcpInfo (&tkptr->FileOds, &FileAcpInfoAst, rqptr); 
}

/****************************************************************************/
/*
AST called from FileParseAST() when ACP QIO completes.  If status indicates no
such file then call any file open error processing function originally
supplied, otherwise report the error.  If status OK call a function to open the
file, which function will AST to FileOpenAst().
*/

FileAcpInfoAst (struct RequestStruct *rqptr)

#define FAT$C_UNDEFINED 0
#define FAT$C_FIXED 1
#define FAT$C_VARIABLE 2
#define FAT$C_VFC 3
#define FAT$C_STREAM 4
#define FAT$C_STMLF 5
#define FAT$C_STMCR 6

{
   register struct FileTaskStruct  *tkptr;

   int  status,
        ContentLength,
        Length;
   unsigned long  EndOfFileVbn;
   char  *ContentTypePtr,
         *KeepAlivePtr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "FileAcpInfoAst() %%X%08.08X\n",
               rqptr->FileTaskPtr->FileOds.AcpInfo.AcpIOsb.Status);

   tkptr = rqptr->FileTaskPtr;

   /* first, deassign the channel allocated by OdsFileAcpInfo() */
   sys$dassgn (tkptr->FileOds.AcpInfo.Channel);

   if ((status = tkptr->FileOds.AcpInfo.AcpIOsb.Status) == SS$_NOSUCHFILE)
      status = RMS$_FNF;

   if (status == RMS$_FNF &&
       tkptr->FileOpenErrorFunction != NULL)
   {
      /* do not report an error, the alternate function will handle it */
      if (rqptr->WatchItem &&
          (WatchEnabled & WATCH_RESPONSE))
         WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                    "FILE %X!8XL %!%M", status, status);

      rqptr->HomePageStatus = status;
      tkptr->NextTaskFunction = tkptr->FileOpenErrorFunction;
      FileEnd (rqptr);
      return;
   }
   else
   if (VMSnok (status))
   {
      if (!rqptr->AccountingDone)
         rqptr->AccountingDone = ++Accounting.DoFileCount;
      rqptr->rqResponse.ErrorTextPtr = MapVmsPath (tkptr->FileName, rqptr);
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->FileName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      FileEnd (rqptr);
      return;
   }

   if (tkptr->FileOds.AcpInfo.RecAttr.RecordType == FAT$C_VARIABLE ||
       tkptr->FileOds.AcpInfo.RecAttr.RecordType == FAT$C_VFC ||
       (tkptr->FileOds.AcpInfo.RecAttr.RecordType == FAT$C_FIXED &&
        (tkptr->FileOds.AcpInfo.RecAttr.RecordSize & 1)))
   {
      if (Debug) fprintf (stdout, "record!\n");
      tkptr->RecordIO = true;
   }

   /***************/
   /* file exists */
   /***************/

   EndOfFileVbn = tkptr->FileOds.AcpInfo.RecAttr.EndOfFileVbnLo +
                  (tkptr->FileOds.AcpInfo.RecAttr.EndOfFileVbnHi << 16);
   if (Debug)
      fprintf (stdout, "EndOfFileVbn: %d FirstFreeByte %d\n",
               EndOfFileVbn, tkptr->FileOds.AcpInfo.RecAttr.FirstFreeByte);

   /* buffer these for possible use by the cache module */
   tkptr->EndOfFileVbn = EndOfFileVbn;
   tkptr->FirstFreeByte = tkptr->FileOds.AcpInfo.RecAttr.FirstFreeByte;

   if (EndOfFileVbn <= 1)
      tkptr->SizeInBytes = tkptr->FileOds.AcpInfo.RecAttr.FirstFreeByte;
   else
      tkptr->SizeInBytes = ((EndOfFileVbn-1) << 9) +
                           tkptr->FileOds.AcpInfo.RecAttr.FirstFreeByte;
   if (Debug) fprintf (stdout, "bytes %d\n", tkptr->SizeInBytes); 

   memcpy (&tkptr->ModifiedBinaryTime, &tkptr->FileOds.AcpInfo.RdtBinTime, 8);

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_RESPONSE))
   {
      char  *rfmptr;
      switch (tkptr->FileOds.AcpInfo.RecAttr.RecordType)
      {
         case FAT$C_VARIABLE :  rfmptr = "VAR"; break;
         case FAT$C_VFC :       rfmptr = "VFC"; break;
         case FAT$C_FIXED :     rfmptr = "FIX"; break;
         case FAT$C_STREAM :    rfmptr = "STM"; break;
         case FAT$C_STMLF :     rfmptr = "STMLF"; break;
         case FAT$C_STMCR :     rfmptr = "STMCR"; break;
         case FAT$C_UNDEFINED : rfmptr = "UDF"; break;
         default : rfmptr = "?";
      }
      WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
#ifdef ODS_EXTENDED
                 "FILE ODS:!UL rfm:!AZ ebk:!UL ffb:!UL (!UL bytes!AZ) rdt:!%D",
                 rqptr->PathOds,
#else
                 "FILE rfm:!AZ ebk:!UL ffb:!UL (!UL bytes!AZ) rdt:!%D",
#endif /* ODS_EXTENDED */
                 rfmptr, tkptr->EndOfFileVbn, tkptr->FirstFreeByte,
                 tkptr->SizeInBytes, tkptr->RecordIO ? " approx." : "",
                 &tkptr->ModifiedBinaryTime);
   }

   if (rqptr->rqResponse.HeaderPtr == NULL)
   {
      /****************************/
      /* response header required */
      /****************************/

      /*
         For variable-length, etc. files (accessed using record-mode) file size
         cannot be accurately determined.  Indicate this using length of -1.
      */
      if (tkptr->RecordIO)
         ContentLength = -1;
      else
         ContentLength = tkptr->SizeInBytes;
      if (Debug) fprintf (stdout, "ContentLength: %d\n", ContentLength);

      if (rqptr->rqHeader.Method == HTTP_METHOD_GET &&
          (rqptr->rqTime.IfModifiedSinceVMS64bit[0] ||
           rqptr->rqTime.IfModifiedSinceVMS64bit[1]) &&
           !rqptr->PragmaNoCache &&
           !rqptr->DeleteOnClose)

      {
         /*********************/
         /* if modified since */
         /*********************/

         if (VMSnok (status =
             HttpIfModifiedSince (rqptr, &tkptr->ModifiedBinaryTime,
                                  ContentLength)))
         {
            /* task status LIB$_NEGTIM if not modified/sent */
            if (!rqptr->AccountingDone)
            {
               rqptr->AccountingDone = ++Accounting.DoFileCount;
               Accounting.DoFileNotModifiedCount++;
            }
            FileEnd (rqptr);
            return;
         }
      }

      if (!rqptr->AccountingDone)
         rqptr->AccountingDone = ++Accounting.DoFileCount;

      if (Config.cfTimeout.SecondsKeepAlive &&
          rqptr->KeepAliveRequest &&
          ContentLength > 0)
      {
         rqptr->KeepAliveResponse = true;
         rqptr->rqNet.KeepAliveCount++;
         KeepAlivePtr = DEFAULT_KEEPALIVE_HTTP_HEADER;
      }
      else
         KeepAlivePtr = "";

      if (rqptr->rqHeader.QueryStringPtr[0] &&
          tolower(rqptr->rqHeader.QueryStringPtr[0]) == 'h' &&
          strsame (rqptr->rqHeader.QueryStringPtr, "httpd=content", 13))
      {
         /* request-specified content-type (default to plain-text) */
         if (strsame (rqptr->rqHeader.QueryStringPtr+13, "&type=", 6))
            ContentTypePtr = rqptr->rqHeader.QueryStringPtr + 19;
         else
            ContentTypePtr = "text/plain";
      }
      else
         ContentTypePtr = tkptr->ContentTypePtr;

      HttpHeader (rqptr, 200, ContentTypePtr, ContentLength,
                  &tkptr->ModifiedBinaryTime, KeepAlivePtr);

      /* quit here if the HTTP method was HEAD */
      if (rqptr->rqHeader.Method == HTTP_METHOD_HEAD)
      {
         FileEnd (rqptr);
         return;
      }
   }

   /*****************/
   /* NOW open file */
   /*****************/

   /* "temporary" file, automatic delete on closing it */
   if (rqptr->DeleteOnClose)
   {
      tkptr->FileOds.Fab.fab$l_fop |= FAB$M_DLT;
      tkptr->FileOds.DeleteOnClose = true;
   }

   tkptr->FileOds.Fab.fab$l_ctx = rqptr;

   FileOpen (tkptr);
} 

/*****************************************************************************/
/*
Complete the FAB according to record or block mode transfer.  Asynchronous
sys$open() ASTing to FileOpenAst().  FileOpenAst() can call this function
directly again, see note on locked files.
*/

FileOpen (struct FileTaskStruct *tkptr)

{

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "FileOpen()\n");

   /* get the 'fid' and use the NAM block to identify the file */
#ifdef ODS_EXTENDED
   if (OdsExtended)
   {
      memcpy (&tkptr->FileOds.Naml.naml$w_fid,
              tkptr->FileOds.AcpInfo.FileFib.fib$w_fid,
              sizeof(tkptr->FileOds.AcpInfo.FileFib.fib$w_fid));
   }
   else
#endif /* ODS_EXTENDED */
   {
      memcpy (&tkptr->FileOds.Nam.nam$w_fid,
              tkptr->FileOds.AcpInfo.FileFib.fib$w_fid,
              sizeof(tkptr->FileOds.AcpInfo.FileFib.fib$w_fid));
   }
   tkptr->FileOds.Fab.fab$l_fop |= FAB$M_NAM;

   if (tkptr->RecordIO)
   {
      tkptr->FileOds.Fab.fab$b_fac = FAB$M_GET;
      tkptr->FileOds.Fab.fab$b_shr = FAB$M_SHRGET | FAB$M_SHRPUT;
   }
   else
   {
      tkptr->FileOds.Fab.fab$b_fac = FAB$M_GET | FAB$M_BIO; 
      tkptr->FileOds.Fab.fab$b_shr = FAB$M_SHRGET;
   }

   if (!tkptr->AuthVmsUserHasAccess)
   {
      /* asynchronous service */
      tkptr->FileOds.Fab.fab$l_fop |= FAB$M_ASY;
      status = sys$open (&tkptr->FileOds.Fab, &FileOpenAst, &FileOpenAst);
      if (Debug) fprintf (stdout, "sys$open() %%X%08.08X\n", status);
      return;
   }
   else
   {
      EnableSysPrv();
      /* synchronous service (careful when using SYSPRV!) */
      tkptr->FileOds.Fab.fab$l_fop &= ~FAB$M_ASY;
      status = sys$open (&tkptr->FileOds.Fab, 0, 0);
      if (Debug) fprintf (stdout, "sys$open() %%X%08.08X\n", status);
      DisableSysPrv();
      /* call the AST explicitly */
      FileOpenAst (&tkptr->FileOds.Fab);
      return;
   }
} 

/*****************************************************************************/
/*
AST called from FileOpen() when asynchronous open completes.  Initiate an
asynchronous RAB connect.
*/

FileOpenAst (struct FAB *FabPtr)

{
   register struct RequestStruct  *rqptr;
   register struct FileTaskStruct  *tkptr;

   int  status,
        MultiBlockCount;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "FileOpenAst() sts: %%X%08.08X stv: %%X%08.08X\n",
               FabPtr->fab$l_sts, FabPtr->fab$l_stv);

   rqptr = FabPtr->fab$l_ctx;
   tkptr = rqptr->FileTaskPtr;

   status = tkptr->FileOds.Fab.fab$l_sts;
   if (status == RMS$_FLK && !tkptr->RecordIO)
   {
      /* RMS$_FLK, block-mode cannot SHRPUT, try record-mode! */
      tkptr->RecordIO = true;
      FileOpen (tkptr);
      return;
   }
   if (VMSnok (status))
   {
      /* ensure the response header created above is not used for the error */
      rqptr->rqResponse.HeaderPtr = NULL;
      rqptr->rqResponse.HeaderLength = 0;
      rqptr->rqResponse.HttpStatus = 0;

      /* if its a search list treat directory not found as if file not found */
      if ((tkptr->FileOds.Nam_fnb & NAM$M_SEARCH_LIST) &&
          status == RMS$_DNF)
         status = RMS$_FNF;

      rqptr->rqResponse.ErrorTextPtr = MapVmsPath (tkptr->FileName, rqptr);
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->FileName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      FileEnd (rqptr);
      return;
   }

   tkptr->FileOds.Rab = cc$rms_rab;
   tkptr->FileOds.Rab.rab$l_ctx = rqptr;
   tkptr->FileOds.Rab.rab$l_fab = &tkptr->FileOds.Fab;
   if (tkptr->RecordIO)
   {
      /* divide by 512 and one for trailing bytes */
      MultiBlockCount = (tkptr->SizeInBytes >> 9) + 1;
      if (MultiBlockCount > 127)
      {
         tkptr->FileOds.Rab.rab$b_mbc = 127;
         tkptr->FileOds.Rab.rab$b_mbf = 2;
      }
      else
      {
         /* less than 127 * 512 bytes in length, one buffer enough! */
         tkptr->FileOds.Rab.rab$b_mbc = MultiBlockCount;
         tkptr->FileOds.Rab.rab$b_mbf = 1;
      }
      tkptr->FileOds.Rab.rab$l_rop = RAB$M_RAH | RAB$M_ASY;
      if (Debug)
         fprintf (stdout, "rab$b_mbc: %d rab$b_mbf: %d\n",
                  tkptr->FileOds.Rab.rab$b_mbc, tkptr->FileOds.Rab.rab$b_mbf);
   }
   else
   {
      tkptr->FileOds.Rab.rab$l_bkt = 0;
      tkptr->FileOds.Rab.rab$l_rop = RAB$M_RAH | RAB$M_BIO | RAB$M_ASY;
   }

   status = sys$connect (&tkptr->FileOds.Rab, &FileConnectAst, &FileConnectAst);
   if (Debug) fprintf (stdout, "sys$connect() %%X%08.08X\n", status);
}

/*****************************************************************************/
/*
AST called from FileOpenAst() when asynchronous RAB connect completes.
Initiate stream-LF file conversion if the file meets requirements.  If
suitable for caching then initiate a cache load and begin reading the file
contents.
*/ 

FileConnectAst (struct RAB *RabPtr)

{
   register struct RequestStruct  *rqptr;
   register struct FileTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
         "FileConnectAst() sts: %%X%08.08X stv: %%X%08.08X\n",
         RabPtr->rab$l_sts, RabPtr->rab$l_stv);

   rqptr = RabPtr->rab$l_ctx;
   tkptr = rqptr->FileTaskPtr;

   if (VMSnok (status = RabPtr->rab$l_sts))
   {
      rqptr->rqResponse.ErrorTextPtr = MapVmsPath (tkptr->FileName, rqptr);
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->FileName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      FileEnd (rqptr);
      return;
   }

   /******************************/
   /* stream-LF file conversion? */
   /******************************/

   if (Config.cfMisc.StreamLfConversionMaxKbytes &&
       tkptr->RecordIO &&
       tkptr->FileOds.Fab.fab$b_rfm == FAB$C_VAR &&
       rqptr->rqPathSet.StmLF &&
       ConfigSameContentType (tkptr->ContentTypePtr, "text/", 5) &&
       !ConfigSameContentType (tkptr->ContentTypePtr, ConfigContentTypeSsi, -1))
   {
      /* divide by two to get the number of kilobytes (1024) in the file */
      if ((tkptr->SizeInBytes >> 10) <= Config.cfMisc.StreamLfConversionMaxKbytes)
         StmLfBegin (MapVmsPath(tkptr->FileName, rqptr),
                     tkptr->FileName,
                     tkptr->FileNameLength,
                     rqptr->PathOdsExtended,
                     tkptr->AuthVmsUserHasAccess);
   }

   /********************/
   /* begin processing */
   /********************/

   /* network writes are checked for success, fudge the first one! */
   rqptr->rqNet.WriteIOsb.Status = SS$_NORMAL;

   /*
      Cache load is not initiated if this is not a stand-alone file request
      (i.e. not part of some other activity, e.g. a directory read-me file,
      'CacheHashValue' zero), if we are not interested in caching the file
      ('CacheHashValue' zero), if it is already being loaded via another
      request, if a "temporary" file ('DeleteOnClose'), or via requests with
      a VMS authentication profile attached.
   */
   if (CacheEnabled &&
       tkptr->CacheAllowed &&
       rqptr->rqCache.HashValue &&
       !rqptr->rqHeader.QueryStringPtr[0] &&
       !tkptr->EscapeHtml &&
       !rqptr->rqCache.Loading &&
       !rqptr->DeleteOnClose &&
       !rqptr->rqAuth.VmsUserProfileLength)
   {
      /* get a cache structure allocated */
      CacheLoadBegin (rqptr, tkptr);
      /* 'rqptr->rqCache.EntryPtr' will now be used to control cache load behaviour */
   }
   else
      rqptr->rqCache.EntryPtr = NULL;

   if (tkptr->PreTagFileContents)
   {
      tkptr->PreTagEndFileContents = true;
      NetWriteBuffered (rqptr, &FileEmptyBuffer, "<PRE>", 5);
      return;
   }

   FileEmptyBuffer (rqptr);
}

/*****************************************************************************/
/*
End of file transfer, successful or otherwise.
*/

FileEnd (struct RequestStruct *rqptr)

{
   register struct FileTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "FileEnd()\n");

   tkptr = rqptr->FileTaskPtr;

   /* ensure the FAB user context is set for FileClosed() */
   tkptr->FileOds.Fab.fab$l_ctx = rqptr;

   if (rqptr->rqCache.EntryPtr != NULL) CacheLoadEnd (rqptr);

   /* release internal RMS parse structures */
   if (tkptr->FileOds.ParseInUse) OdsParseRelease (&tkptr->FileOds);

   if (tkptr->FileOds.Fab.fab$w_ifi)
      OdsClose (&tkptr->FileOds, &FileClosed, rqptr);
   else
      FileClosed (&tkptr->FileOds.Fab);
} 

/*****************************************************************************/
/*
May be called directly or as an AST from OdsClose() above.  Ihe file has been
sys$close()d at this stage.  Indirectly or directly call the next task.
*/

FileClosed (struct FAB *FabPtr)

{
   register struct RequestStruct  *rqptr;
   register struct FileTaskStruct  *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "FileClosed() sts: %%X%08.08X stv: %%X%08.08X\n",
               FabPtr->fab$l_sts, FabPtr->fab$l_stv);

   rqptr = FabPtr->fab$l_ctx;
   tkptr = rqptr->FileTaskPtr;

   if (rqptr->rqHeader.Method != HTTP_METHOD_HEAD &&
       tkptr->PreTagEndFileContents)
   {
      /* encapsulating a file, add the end tag, declaring next task as AST */
      NetWriteBuffered (rqptr, tkptr->NextTaskFunction, "</PRE>\n", 7);
   }
   else
   {
      /* declare the next task */
      SysDclAst (tkptr->NextTaskFunction, rqptr);
   }
} 

/*****************************************************************************/
/*
Ensure any output buffer contents are flushed.
*/

FileEmptyBuffer (struct RequestStruct *rqptr)

{
   register struct FileTaskStruct  *tkptr;

   int  status;
   void  *AstFunctionPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "FileEmptyBuffer()\n");

   tkptr = rqptr->FileTaskPtr;

   if (tkptr->RecordIO)
      AstFunctionPtr = &FileNextRecord;
   else
      AstFunctionPtr = &FileNextBlocks;
   if (rqptr->rqOutput.BufferCount)
   {
      /* need exclusive use, flush the current contents */
      NetWriteFullFlush (rqptr, AstFunctionPtr);
   }
   else
      SysDclAst (AstFunctionPtr, rqptr);
}

/*****************************************************************************/
/*
Queue a read of the next record from the file.  When the read completes call 
FileNextRecordAst() function to post-process the read and/or send the data 
to the client.  Don't bother to test any status here, the AST routine will do 
that!
*/ 

FileNextRecord (struct RequestStruct *rqptr)

{
   register struct FileTaskStruct  *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "FileNextRecord()\n");

   if (VMSnok (rqptr->rqNet.WriteIOsb.Status))
   {
      /* network write has failed (as AST), bail out now */
      if (Debug)
         fprintf (stdout, "NetWriteIOsb.Status %%X%08.08X\n",
                  rqptr->rqNet.WriteIOsb.Status);
      FileEnd (rqptr);
      return;
   }

   tkptr = rqptr->FileTaskPtr;

   if (!tkptr->FileOds.Rab.rab$l_ubf)
   {
      /* first IO in file transfer, organise the buffer */
      if (rqptr->rqCache.EntryPtr == NULL)
      {
         /* not loading cache, initialize output buffer */
         NetWriteInit (rqptr);
      }
      else
      {
         /* using a cache buffer */
         rqptr->rqCache.ContentPtr = rqptr->rqCache.ContentCurrentPtr =
            rqptr->rqCache.EntryPtr->ContentPtr;
         rqptr->rqCache.ContentCount = rqptr->rqCache.EntryPtr->CacheSize;
      }
   }

   if (rqptr->rqCache.EntryPtr == NULL)
   {
      /* not loading cache */
      tkptr->FileOds.Rab.rab$l_ubf = rqptr->rqOutput.BufferCurrentPtr;
      if (rqptr->rqOutput.BufferRemaining > 32767)
         tkptr->FileOds.Rab.rab$w_usz = 32767;
      else
         tkptr->FileOds.Rab.rab$w_usz = rqptr->rqOutput.BufferRemaining;
   }
   else
   {
      /* loading cache */
      tkptr->FileOds.Rab.rab$l_ubf = rqptr->rqCache.ContentCurrentPtr;
      if (rqptr->rqCache.ContentCount > 32767)
         tkptr->FileOds.Rab.rab$w_usz = 32767;
      else
         tkptr->FileOds.Rab.rab$w_usz = rqptr->rqCache.ContentCount;
   }

   /* GET the next record (or last read if RFA is set) */
   sys$get (&tkptr->FileOds.Rab, &FileNextRecordAst, &FileNextRecordAst);
}

/*****************************************************************************/
/*
The read of the next record from the file has completed.  Post-process and/or 
queue a network write to the client.  When the network write completes it will 
call the function FileNextRecord() to queue a read of the next record. Record-
by-record processing builds up as many file records as possible into available 
buffer space before transfering them to the network as one I/O.  The 
sys$get()s use the buffer area pointed to by
'rqptr->rqOutput.BufferCurrentPtr' and the size specified by
'rqptr->rqOutput.BufferRemaining'.  When a sys$get() fails with a "record 
too big for user's buffer", because we're running out of buffer space, the 
accumulated records are flushed to the network and the pointer and available 
space values are reset.  The FileNextRecord() AST called when the 
NetWrite() completes will re-read a record that failed with the "record too 
big" error by forcing the read to be by RFA for that one record.
*/ 

FileNextRecordAst (struct RAB *RabPtr)

{
   register int  rsz;
   register struct RequestStruct  *rqptr;
   register struct FileTaskStruct  *tkptr;

   int  status,
        CacheBufferRemaining;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
         "FileNextRecordAst() sts: %%X%08.08X stv: %%X%08.08X rsz: %d\n",
         RabPtr->rab$l_sts, RabPtr->rab$l_stv, RabPtr->rab$w_rsz);

   rqptr = RabPtr->rab$l_ctx;
   tkptr = rqptr->FileTaskPtr;

   if (VMSnok (tkptr->FileOds.Rab.rab$l_sts))
   {
      /*
         Test for "record too big for user's buffer", indicates that
         its time to flush the records accumulated in the buffer.
         This should never happen when reading into a cache buffer!!!
         (only possibly if the file was to be extended, etc.)
      */
      if (tkptr->FileOds.Rab.rab$l_sts == RMS$_RTB)
      {
         if (Debug) fprintf (stdout, "RMS$_RTB\n");

         if (rqptr->rqCache.EntryPtr == NULL)
         {
            if (rqptr->rqOutput.BufferCount == 0)
            {
               /* legitimate "record too big for user's buffer" error */
               rqptr->rqResponse.ErrorTextPtr =
                  MapVmsPath (tkptr->FileName, rqptr);
               rqptr->rqResponse.ErrorOtherTextPtr = tkptr->FileName;
               ErrorVmsStatus (rqptr, RMS$_RTB, FI_LI);
               FileEnd (rqptr);
               return;
            }

            /* insufficient space for next record, flush buffer contents */
            FileFlushBuffer (rqptr, &FileNextRecord);

            /* re-read the record that just failed by forcing a read by RFA */
            tkptr->FileOds.Rab.rab$b_rac |= RAB$C_RFA;

            return;
         }
         else
         {
            /*
               This is not supposed to happen!
               Possibly in between getting the file size and opening and
               reading this far the file has been extended or rewritten.
               Shouldn't happen often enough to be a worry!
            */
            rqptr->rqResponse.ErrorTextPtr =
               MapVmsPath (tkptr->FileName, rqptr);
            rqptr->rqResponse.ErrorOtherTextPtr = tkptr->FileName;
            ErrorVmsStatus (rqptr, RMS$_RTB, FI_LI);
            FileEnd (rqptr);
            return;
         }
      }

      if (tkptr->FileOds.Rab.rab$l_sts == RMS$_EOF)
      {
         if (Debug) fprintf (stdout, "RMS$_EOF\n");
         /* cache load becomes valid only after we get to end-of-file */
         if (rqptr->rqCache.EntryPtr != NULL)
            rqptr->rqCache.EntryPtr->CacheLoadValid = true;
         FileFlushBuffer (rqptr, &FileEnd);
         return;
      }

      /* hmmm, file transfer error */
      rqptr->rqResponse.ErrorTextPtr = MapVmsPath (tkptr->FileName, rqptr);
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->FileName;
      ErrorVmsStatus (rqptr, tkptr->FileOds.Rab.rab$l_sts, FI_LI);
      FileEnd (rqptr);
      return;
   }

   /* force the next read to be sequential (in case the last was by RFA) */
   tkptr->FileOds.Rab.rab$b_rac &= ~RAB$C_RFA;

   rsz = tkptr->FileOds.Rab.rab$w_rsz;
   if (rsz)
   {
      /* add newline if last character in line is not a newline! */
      if (tkptr->FileOds.Rab.rab$l_ubf[rsz-1] != '\n')
         tkptr->FileOds.Rab.rab$l_ubf[rsz++] = '\n';
   }
   else
   {
      /* must be a blank line (empty record), add a newline */
      tkptr->FileOds.Rab.rab$l_ubf[rsz++] = '\n';
   }

   if (Debug)
      fprintf (stdout, "rsz: %d remain: %d count: %d\n",
               rsz, rqptr->rqOutput.BufferRemaining, rqptr->rqCache.ContentCount);

   if (rqptr->rqCache.EntryPtr != NULL)
   {
      /* has not filled or overflowed this portion of the cache buffer */
      rqptr->rqCache.ContentCount -= rsz;
      rqptr->rqCache.ContentCurrentPtr += rsz;

      /* flush if we have arrived at a chunk of output */
      if (rqptr->rqCache.ContentCurrentPtr >=
          rqptr->rqCache.ContentPtr + OutputBufferSize)
         FileFlushBuffer (rqptr, &FileNextRecord);
      else
         FileNextRecord (rqptr);
   }
   else
   if (rqptr->rqOutput.BufferRemaining > rsz)
   {
      /* has not filled or overflowed the standard output buffer */
      rqptr->rqOutput.BufferRemaining -= rsz;
      rqptr->rqOutput.BufferCurrentPtr += rsz;
      rqptr->rqOutput.BufferCount += rsz;
      FileNextRecord (rqptr);
   }
   else
   {
      /* insufficient space for next record, flush buffer contents */
      FileFlushBuffer (rqptr, &FileNextRecord);

      /* re-read the record that just failed by forcing a read by RFA */
      tkptr->FileOds.Rab.rab$b_rac |= RAB$C_RFA;
   }
}

/*****************************************************************************/
/*
Flush the file records accumulated in the 'Buffer'.  If plain text and 
encapsulated then escape any HTML-forbidden characters using a separate 
function.
*/

FileFlushBuffer
(
struct RequestStruct *rqptr,
void *AstFunctionPtr
)
{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "FileFlushBuffer()\n");

   if (rqptr->FileTaskPtr->EscapeHtml)
      return (FileWriteBufferEscapeHtml (rqptr, AstFunctionPtr));
   else
   {
      if (rqptr->rqCache.EntryPtr == NULL)
      {
         if (!rqptr->rqOutput.BufferCount)
         {
            /* nothing to flush! */
            SysDclAst (AstFunctionPtr, rqptr);
            return;
         }

         NetWrite (rqptr, AstFunctionPtr,
                   rqptr->rqOutput.BufferPtr,
                   rqptr->rqOutput.BufferCount);

         /* reset standard output buffer */
         NetWriteInit (rqptr);
         return;
      }
      else
      {
         if (!(rqptr->rqCache.ContentCurrentPtr - rqptr->rqCache.ContentPtr))
         {
            /* nothing to flush! */
            SysDclAst (AstFunctionPtr, rqptr);
            return;
         }

         NetWrite (rqptr, AstFunctionPtr,
                   rqptr->rqCache.ContentPtr,
                   rqptr->rqCache.ContentCurrentPtr - rqptr->rqCache.ContentPtr);

         /* reset the pointer to the new flush position */
         rqptr->rqCache.ContentPtr = rqptr->rqCache.ContentCurrentPtr;
         return;
      }
   }
}

/*****************************************************************************/
/*
Queue a read of the next series of Virtual Blocks from the file.  When the 
read completes call FileNextBlocksAst() function to post-process the read 
and/or send the data to the client.  Don't bother to test any status here, the 
AST routine will do that!
*/ 

FileNextBlocks (struct RequestStruct *rqptr)

{
   register struct FileTaskStruct  *tkptr;

   unsigned int  BufferSize;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "FileNextBlocks()\n");

   if (VMSnok (rqptr->rqNet.WriteIOsb.Status))
   {
      /* network write has failed (as AST), bail out now */
      if (Debug)
         fprintf (stdout, "NetWriteIOsb.Status %%X%08.08X\n",
                  rqptr->rqNet.WriteIOsb.Status);
      FileEnd (rqptr);
      return;
   }

   tkptr = rqptr->FileTaskPtr;

   if (tkptr->FileOds.Rab.rab$l_bkt)
   {
      /* subsequent reads */
      tkptr->FileOds.Rab.rab$l_bkt += tkptr->FileOds.Rab.rab$w_usz >> 9;

      if (rqptr->rqCache.EntryPtr != NULL)
      {
         /* adjust according to size of previous read */
         rqptr->rqCache.ContentPtr += tkptr->FileOds.Rab.rab$w_rsz;
         rqptr->rqCache.ContentCount -= tkptr->FileOds.Rab.rab$w_rsz;
         if (Debug) fprintf (stdout, "count: %d\n", rqptr->rqCache.ContentCount);
         if (rqptr->rqCache.ContentCount <= 0)
         {
            /*
               This is not supposed to happen!
               Possibly in between getting the file size and opening and
               reading this far the file has been extended or rewritten.
               Shouldn't happen often enough to be a worry!
            */
            rqptr->rqResponse.ErrorTextPtr =
               MapVmsPath (tkptr->FileName, rqptr);
            rqptr->rqResponse.ErrorOtherTextPtr = tkptr->FileName;
            ErrorVmsStatus (rqptr, RMS$_RTB, FI_LI);
            FileEnd (rqptr);
            return;
         }
      }
   }
   else
   {
      /* first read */
      tkptr->FileOds.Rab.rab$l_bkt = 1;
      if (rqptr->rqCache.EntryPtr == NULL)
      {
         /* not using a cache buffer, initialize standard output buffer */
         NetWriteInit (rqptr);
      }
      else
      {
         /* using a cache buffer */
         rqptr->rqCache.ContentPtr = rqptr->rqCache.EntryPtr->ContentPtr;
         rqptr->rqCache.ContentCount = rqptr->rqCache.EntryPtr->CacheSize;
      }
   }

   /* make buffer size an even number of 512 byte blocks */
   BufferSize = OutputBufferSize & 0xfe00;

   if (rqptr->rqCache.EntryPtr == NULL)
   {
      /* not using a cache buffer, standard output buffer */
      tkptr->FileOds.Rab.rab$l_ubf = rqptr->rqOutput.BufferPtr;
      tkptr->FileOds.Rab.rab$w_usz = BufferSize;
   }
   else
   {
      /* using a cache buffer, load it progressively */
      if (Debug) fprintf (stdout, "count: %d\n", rqptr->rqCache.ContentCount);
      tkptr->FileOds.Rab.rab$l_ubf = rqptr->rqCache.ContentPtr;
      if (rqptr->rqCache.ContentCount > BufferSize)
         tkptr->FileOds.Rab.rab$w_usz = BufferSize;
      else
         tkptr->FileOds.Rab.rab$w_usz = rqptr->rqCache.ContentCount;
   }

   sys$read (&tkptr->FileOds.Rab, &FileNextBlocksAst, &FileNextBlocksAst);
}

/*****************************************************************************/
/*
The read of the next series of Virtual Blocks from the file has completed.  
Post-process and/or queue a network write to the client.  When the network 
write completes it will call the function FileNextBlocks() to queue a read 
of the next series of blocks.
*/ 

FileNextBlocksAst (struct RAB *RabPtr)

{
   register struct RequestStruct  *rqptr;
   register struct FileTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
               "FileNextBlocksAst() sts: %%X%08.08X stv: %%X%08.08X\n",
               RabPtr->rab$l_sts,
               RabPtr->rab$l_stv);

   rqptr = RabPtr->rab$l_ctx;
   tkptr = rqptr->FileTaskPtr;

   if (VMSnok (tkptr->FileOds.Rab.rab$l_sts))
   {
      if (tkptr->FileOds.Rab.rab$l_sts == RMS$_EOF)
      {
         if (rqptr->rqCache.EntryPtr == NULL)
         {
            /* reset the standard output buffer */
            NetWriteInit (rqptr);
         }
         else
         {
            /* a cache load becomes valid only after we get to end-of-file */
            rqptr->rqCache.EntryPtr->CacheLoadValid = true;
         }
         FileEnd (rqptr);
         return;
      }
      rqptr->rqResponse.ErrorTextPtr = MapVmsPath (tkptr->FileName, rqptr);
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->FileName;
      ErrorVmsStatus (rqptr, tkptr->FileOds.Rab.rab$l_sts, FI_LI);
      FileEnd (rqptr);
      return;
   }

   /* queue a network write to the client, AST to FileNextBlocks() */
   if (rqptr->FileTaskPtr->EscapeHtml)
   {
      rqptr->rqOutput.BufferCount = tkptr->FileOds.Rab.rab$w_rsz;
      FileWriteBufferEscapeHtml (rqptr, &FileNextBlocks);
   }
   else
      NetWrite (rqptr, &FileNextBlocks,
                tkptr->FileOds.Rab.rab$l_ubf, tkptr->FileOds.Rab.rab$w_rsz);
}

/*****************************************************************************/
/*
Send the buffer contents escaping any HTML-forbidden characters.
*/ 

FileWriteBufferEscapeHtml
(
struct RequestStruct *rqptr,
void *AstFunctionPtr
)
{
   register int  bcnt, ecnt;
   unsigned register char  *bptr, *sptr, *zptr;
   register struct FileTaskStruct  *tkptr;

   int  status;
                         
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "FileWriteBufferEscapeHtml()\n");

   tkptr = rqptr->FileTaskPtr;

   /* allocate a worst-case escaped HTML buffer (i.e. all "&amp;"s) */
   if (tkptr->EscapeHtmlPtr == NULL)
      tkptr->EscapeHtmlPtr = VmGetHeap (rqptr, OutputBufferSize * 5);

   sptr = tkptr->EscapeHtmlPtr;
   bptr = rqptr->rqOutput.BufferPtr;
   bcnt = rqptr->rqOutput.BufferCount;
   while (bcnt)
   {
      switch (*bptr)
      {
         case '<' :
            memcpy (sptr, "&lt;", 4); sptr += 4; bptr++; break;
         case '>' :
            memcpy (sptr, "&gt;", 4); sptr += 4; bptr++; break;
         case '&' :
            memcpy (sptr, "&amp;", 5); sptr += 5; bptr++; break;
         default :
            *sptr++ = *bptr++;
      }
      bcnt--;
   }

   /* flush the HTML-escaped buffer contents */
   NetWrite (rqptr, AstFunctionPtr, 
             tkptr->EscapeHtmlPtr, sptr - tkptr->EscapeHtmlPtr);

   /* reuse standard output buffer */
   NetWriteInit (rqptr);
}

/*****************************************************************************/

                                                                                                                                                                                                                                                                                                         