/*****************************************************************************/
/*
                                 Auth.c


    THE GNU GENERAL PUBLIC LICENSE APPLIES DOUBLY TO ANYTHING TO DO WITH
                    AUTHENTICATION AND AUTHORIZATION!

    This package is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License, or any later
    version.

>   This package is distributed in the hope that it will be useful,
>   but WITHOUT ANY WARRANTY; without even the implied warranty of
>   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
>   GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


Overview
--------

This is "path"-based authorization/authentication.  That is, access is
controlled according to the path specified in the request.  A path can have
capabilities, or access controls, allowing any combination of DELETE, GET,
HEAD, POST and PUT method capabilities.  The world can have capabilities
against a path. An authenticated user also can have capabilities.  The request
capability is the logical AND of the path and world/user capabilities, meaning
the request gets the minimum of the path and user's access.  There are no
access-control files in any data directory.  It is all under the control of the
HTTPd server manager.

AUTHORIZATION IS ALWAYS PERFORMED AGAINST THE REQUEST'S PATHINFO STRING (the
string parsed from the original request path), NOT AGAINST ANY RE-MAPPED PATH.
THERE SHOULD BE NO AMBIGUITY ABOUT WHAT IS BEING AUTHORIZED!

When a request contains a controlled path the authorization for access to that
path is made against a password database for the authentication "realm" the
path belongs to.  A realm (or group) name is a 1 to 31 character string
describing the collection of one or more paths for purposes of authenticating
against a common password file.  A realm/group name should contain only alpha-
numeric, underscore and hyphen characters.  See below for a description of the
difference between realms and groups.  REITERACTION: THE REALM NAME IS WHAT
THE USER-SUPPLIED PASSWORD IS CHECKED AGAINST.

Five realms are reserved, "EXTERNAL", "NONE", "PROMISCUOUS", "VMS" and "WORLD".

  o  "EXTERNAL"     scripts authenticating their own challenge/response,
                    realm, group, user names and plain-text password are
                    available to the script for it's own authorization

  o  "NONE"         any request, is not authenticated,
                    all authorization details are left empty 

  o  "PROMISCUOUS"  only ever mapped when /PROMISCUOUS in use

  o  "VMS"          SYSUAF authentication,
                    via the SYSUAF, or restricted to accounts with identifiers
                    prime/secondary days & network/remote hours will restrict

  o  "WORLD"        any request, is not authenticated,
                    both the realm and username are set to "WORLD"

Note that VMS can have one or more synonym realm names which can be used to
disguise the fact SYSUAF authentication is in use.  Just specify the synonym
name followed immediately by "=VMS", as in the following example: "TESTING=VMS"

A plain-text description can also be associated with a realm name, providing
a more informative message to the browser user during the username/password
dialog.  This must be specified as a double-quote enclosed string preceding the
realm name.  Here are a couple of examples:

  ["the server system's SYSUAF"=VMS]
  ["just a contrived example"=VMS]

Also see the topics "SYSUAF-authentication by WASD Identifier" and
"SYSUAF-authentication by non-WASD Identifier" below.

A path specification begins at the root and usually continues down to an
asterisk indicating a match against any path beginning with that string.  Paths
may overlap.  That is a parent directory may have subdirectory trees that
differ in access controls.  The same path specification may not belong to more
than one realm at a time :^)


User "Logout" From Authentication
---------------------------------

A user may cancel authentication for any path by submitting a request using
that path and a query string of "?httpd=cancel" (or "?httpd=logout").  An
authentication username/password dialog will be presented by the browser.  The
user should clear both username and password fields and submit.  The same
dialog will be represented at which time it should be cancelled resulting in an
authentication failure report.  The browser should have recognised this and
removed the path's cached authentication information.


Break-in Evasion and Failure Reports
------------------------------------
The configuration directive [AuthFailureLimit] specifies the maximum number of
attempts that can be made to authenticate before a particular username in a
particular realm is marked for break-in evasion.  Once marked for evasion no
authentication attempt will succeed until an evasion period expires.  This
period is simply calculated as the number of attempts in minutes.  Hence, once
the limit is exeeded 15 attempts to authenticate results in a 15 minute period
from the last attempt before any correct credentials can possibly succeed, 30
attempts, 30 minutes, etc.

Authentication failures are reported to the process log.
Four messages can be generated.  

  1.  %HTTPD-W-AUTHFAIL, if the request is not authenticated due to there
      being no such user or a password mismatch.  Isolated instances of this
      are only of moderate interest.  Consecutive instances may indicate a
      user thrashing about for the correct password, but they usually give up
      before a dozen attempts.

  2.  %HTTPD-I-AUTHFAILOK (informational), occurs if there has been at least
      one failed attempt to authenticate before a successful attempt.

  3.  %HTTPD-W-AUTHFAILIM, is of greater concern and occurs if the total
      number of failed attempts exceeds the configuration limit (such repeated
      attempts will always continue to fail for if this limit is reached
      successive attempts are automatically failed).

  4.  %HTTPD-I-AUTHFAILEXP, where the failure limit reaches the configuration
      limit (of 3 above) each failure represents one minute of a period before
      expiry of the evasion occurs.  A sucessful authentication after expiry
      of this period results in one of these messages.


Configuration
-------------

A collection of paths is controlled by a "realm" authentication source, against
which the request username/password is verified, and optionally one or two
"group" sources, from which the username's capabilities are determined (what
HTTP methods the username can apply against the path). 

Authentication sources:

  o  system SYSUAF account
  o  HTA database (WASD-specific, non-plain-text file)
  o  simple, plain-text list of names and unencrypted passwords
  o  agent (CGIplus script)

Authorization sources:

  o  account possession of specified VMS rights identifiers
     (only for SYSUAF authenticated requests)
  o  HTA database
  o  simple list
  o  agent (CGIplus script)

A single file contains authorization configuration directives.
The realm directive comprises the authentication source and zero, one or two
grouping sources, in the following format:

  [authentication-source;full-access-group;read-only-group]

Optional method or access keywords (e.g. GET, POST, R+W) may be appended to
specify default access for any paths belonging to the realm.  Multiple "realm"
directives for the same realm name may be included, each with its own trailing
paths.  These multiple declarations just accumulate.

All paths specified after a "realm" directive, up until the next "realm"
directive will belong to that realm and use the specified authentication
source. Paths are specified with a leading slash (i.e. from the root) down to
either the last character or a wildcard asterisk.

HTTP method keywords, or the generic "READ", "R", "READ+WRITE", "R+W", "WRITE"
and "W", control access to the path (in combination with user access methods).
The method keywords are "DELETE", "GET" (implying "HEAD"), "HEAD" "PUT" and
"POST". These keywords are optionally supplied following a path.  If none are
supplied the realm defaults are applied.  The generic keyword "NONE" sets all
access permissions off, including realm defaults.  It is an error not to supply
either. Multiple method keywords may be separated by commas or spaces.  Method
keywords are applied in two groups.  First the group keywords.  Second, an
optional set for controlling world access.  These are delimited from the path
keywords by a semi-colon.

As part of the path access control a list of comma-separated elements may
optionally be supplied.  These elements may be numeric or alphabetic IP host
addresses (with or without asterisk wildcarding allowing wildcard matching of
domains), authenticated username(s) or the request scheme (protocol, "http:" or
"https:").  If supplied this list restricts access to those matching.  For
example:

   *.wasd.dsto.gov.au       would forbid any host outside the WASD subdomain
   131.185.250.*            similarly, but specifying using numeric notation
   *.wasd.dsto.gov.au,~daniel
   https:,*.131.185.250.*   limited to a subnet requesting via SSL service

The reserved word "localhost", or used as "#localhost", refers to the system
the server is executing on.  In this way various functions can be restricted to
browsers executing only on that same system.  Another restriction list keyword,
"nocache", prevents caching of authentication information, forcing each request
to be revalidated (this adds significant processing overhead).

A network mask may be provided in lieu of a host string.  The mask is a
dotted-decimal network address, a slash, then a dotted-decimal mask.  For
example "131.185.250.0/255.255.255.192".  This has a 6 bit subnet.  It operates
by bitwise-ANDing the client host address with the mask, bitwise-ANDing the
network address supplied with the mask, then comparing the two results for
equality.  Using the above example the host 131.185.250.250 would be accepted,
but 131.185.250.50 would be rejected.

Realm names, paths, IP addresses, usernames and access method keywords are all
case insensistive.

Virtual server syntax is the same as for path mapping rules,
[[virtual-host]] (all ports of host) or [[virtual-host:virtual-port]] (
matching specified port of host) for a specific host and [[*]] to resume rules
for all virtual hosts.

Comments may be included by prefixing the line with a "#" characters.  Blank
lines are ignored.  Directives may span multiple lines by ensuring the last
character on any line to be continued is a backslash ("\").

Misconfigured paths, that might otherwise be left without access control, are
reported during server startup, loaded into the configuration and marked
"fail"ed, and will always deny access.  This does not however guarantee that
access control will always work the way intended!!

An example configuration file:

   |[WASD;CONFIDENTIAL]
   |/web/confidential/* get
   |/web/confidential/submissions/* https:,get,post;get
   |/web/authors/* get
   |
   |# realm-context access default
   |[WASD] get,head
   |/web/pub/*
   |/web/pub/submit/* ;get
   |
   |# realm plus full-access and read-only groups
   |[VMS;FULL=LIST;READ=LIST]
   |/web/project/jin/* r+w
   |
   |[WORLD]
   |/web/anyone-can-post-here/* post
   |/web/example/alpha/* *.wasd.dsto.gov.au,read
   |/web/example/numeric/* \
   |   131.185.250.*,read
   |
   |[EXTERNAL]
   |/cgi-bin/footypix*


HTA Databases
-------------

WASD authentication/authorization databases (which have the extension .$HTA
accounting for their generic name) are binary-content content files with fixed
512 byte records.  They may only be administered via the server administration
menu.  They provide for encrypted storage of passwords and can also be used to
store groups of usernames for determining group membership.  All HTA databases
must be located in the directory specified by the logical HT_AUTH:

HTA databases are the default for realm and group names.

For example: [VMS;ADMIN;USER]


Simple Lists
------------

Plain-text files may also be used to store collections of usernames.  This is
primarily intended as a simple yet effective means of collecting together names
for full-access and read-only access group membership.  The file should contain
one username at the beginning of each line.  Blank and comment lines are
ignored.  White-space delimited text following the username is ignored (with
the exception noted below).  The format for each line is
"username other text if required ...".  Simple lists have the extension .HTL
and must be stored in the directory specified by the logical name HT_AUTH:  The
free-form 'other text if required' is considered the authenticated user
details and supplied to scripts as 'AUTH_USER' CGI variable. 

Although it is better to use another, more secure authentication database,
these lists may have have plain-text "passwords" associated with the usernames. 
As these are unencrypted they should not be used for any security-sensitive
purpose, but may suffice for ad hoc or other simple uses.  The format for
specifying a password is "username=password other text if required ...".

Simple lists are indicated by appending "=LIST" to the realm or group name. 

For example: [VMS;ADMIN=LIST;USER=LIST]


VMS Identifiers
---------------

The qualifier /SYSUAF=ID directs the server to allow SYSUAF authentication only
when the VMS account possesses a specified identifier.  NO IDENTIFIER, NO
ACCESS, NO MATTER HOW MANY CORRECT PASSWORDS SUPPLIED.  An excellent
combination is /SYSUAF=(ID,SSL)!

VMS identifiers may be used to control who may authenticate using the SYSUAF,
who is a member of a full-access group, and who is a member of a read-only
group.  These may be any existing or web-specific VMS identifier name possessed
by a given account.  Standard [realm;group-r+w;group-r] syntax is employed,
with a trailing "=ID..." indicating it is an identifier.

For example: [VMS;JIN_PROJECT=ID;JIN_LIBRARIAN=ID]

For a realm specification without group membership requirements (i.e.
[realm;;]) full-access is granted to the username (this is of course adjusted
according to the path specified access level).  When used for determining group
membership, holding the identifier specified in the full-access group (i.e.
[realm;GROUP-R+W;group-r]) provides full read and write access.  If the
full-access identifier is not held by the user but the read-only one is (i.e.
[realm;group-r+w;GROUP-R]) the username receives read access.

NOTE: VMS Identifier identifiers may only be used for specifying group
membership for realms authenticated using the SYSUAF.  Specifying an identifier
group for any other authentication source results in an authorization
configuration error.

Identifier names may contain 1 to 31 characters.

The following examples should help clarify this description (note that the
identifier names are completely arbitrary).

  [JIN_PROJECT=ID]
  # If an account holds the JIN_PROJECT identifier that username and
  # password may be used for authentication for this realm's paths.
  # Note that this account gets read and write access against the username,
  # subject to the path's access specification (also read+write in this case).
  /web/project/jin/* r+w

  [JIN_PROJECT=ID;JIN_LIBRARIAN=ID;JIN_USER=ID]
  # If an account is a holder of the JIN_PROJECT identifier then the account
  # password may be used for server authentication for this realm's paths.
  # If the account also holds the JIN_LIBRARIAN will it be allowed write
  # access, if JIN_USER then read access, to the realm's paths.
  /web/project/jin/library/* r+w

  [JIN_PROJECT=ID;JIN_CODE=ID]
  # Only if the account possesses both the JIN_PROJECT and JIN_CODE
  # identifiers will the username get read+write access to realm's paths.

  [LOCAL=VMS;JIN_PROJECT=ID]
  # If an account holds the WASD_VMS_R or the WASD_VMS_RE then the username
  # can authenticate against the SYSUAF.  However, only if the account also
  # holds the JIN_PROJECT identifier can they access this realm's paths.
  # Read and/or write depends on the "WASD_VMS_..." identifier held and
  # the path access specification (read-only in this case).
  /web/project/jin/* r

  [JIN_PROJECT=ID;FELIX]
  # If an account is a holder of the JIN_PROJECT identifier then account
  # password may be used for server authentication for this realm's paths.
  # Only if the account also has the WASD_VMS__FELIX identifier will it be
  # allowed to access the realm's paths.
  /web/project/jin/* r+w


Special-purpose Identifiers
---------------------------

Three special-purpose identifiers allow supplementary capabilities.  These do
not have to be used or exist, even though if the server is configured to use
rights identifiers, at startup, it will warn of their absence.

WASD_HTTPS_ONLY ........ the account may SYSUAF authenticate only via a
                         secure (SSL) connection
WASD_NIL_ACCESS ........ allows nil-access account (with restrictions from
                         any/all sources and/or days/hours) to authenticate
WASD_PASSWORD_CHANGE ... allows the account to change it's SYSUAF primary
                         password via the server


Authentication agent scripts
----------------------------

An authentication agent script is a CGIplus script that can be activated during
the authorization process to perform the actual authentication/authorization
and return results to the server for access or denial.  Agents may be used with
realm specifications (for authentication) or with group specifications (for
authorization via group membership).

They are provided so that sites may provide a customized authentication
mechanism (perhaps in addition to the WASD standard ones) or for authentication
via some sort of potentially highly-latent source such as LDAP.  It allows
these authorization mechanisms to be relatively easily built, using a CGI-like
environment, and without the rigors of building in an AST-driven environment. 
See implementation comments in AUTHAGENT.C and example(s) provided in the
[SRC.CGIPLUS] directory.

An agent specification used for authentication might look something like:

  ["a remote database"=REMOTE=agent]
  /path/authorized/by/remote/database/*

The following script would need to be mapped and present:

  /cgiauth-bin/remote.exe

A parameter (any string, enclose in double or single quotes if necessary) may
be passed to the agent.  This parameter appears in the CGI variable
"WWW_AUTH_AGENT" and overrides both "REALM" and "GROUP" authorization passed by
default.  If a specific parameter is passed the agent should take on the role
of fully authenticating and authorizing the request, returning a response as if
authorizing a realm. The parameter should be placed in the restriction list
text as illustrated here.

  ["a remote database"=REMOTE=agent]
  /path/authorized/by/remote/database/* agent="HT_ROOT:[LOCAL]LIST.TXT"


SYSUAF-authentication by WASD Identifier
----------------------------------------

*** THIS FUNCTIONALITY IS DEPRECATED! ***
Use the more generalized form described in "VMS Identifiers" above.

In addition to general identifiers, other "hard-wired" identifiers may be used
to control access to and of VMS accounts.  If a username has been authenticated
using using one of the read or write "hard-wired" identifiers then any group
membership must be determined using the "hard-wired" WASD_VMS__<group>
identifier.  Only a realm and one grouping is allowed.

  o  WASD_VMS_R .......... account has read access
  o  WASD_VMS_RW ......... account has read and write access
  o  WASD_VMS__<group> ... account must possess identifier to access
  o  WASD_VMS_HTTPS ...... account can only SYSUAF authenticate via SSL
  o  WASD_VMS_PWD ........ account can change it's SYSUAF password


SYSUAF-authentication and VMS security profile
----------------------------------------------

The ability to be able to authenticate using the system's SYSUAF is controlled
by the server /SYSUAF qualifier.  By default it is disabled.  (This qualifier
was introduced in v4.4 as a result of creeping paranoia :^)

As of v4.4 it has become possible to control access to files and directories
based on the security profile of a SYSUAF-authenticated remote user. This
feature is controlled using the server /PROFILE qualifier.  By default it is
disabled.

A security-profile is created using sys$create_user_profile() and stored in
the authentication cache. This cached profile is the most efficient method of
implementing this as it obviously removes the need of creating a user profile
each time a resource is checked. If this profile exists in the cache it is
attached to each request structure authenticated via the cache.

When this profile is attached to a request all accesses to files and
directories are first assessed against that user profile using
sys$check_access(). If the user can access the resource (regardless of whether
that is because it is WORLD accessable, or because it is owned by, or
otherwise accessable to the user) SYSPRV is always enabled before accessing
the file/directory. This ensures that the authenticated user is always given
access to the resource (provided the SYSTEM permissions allow it!)

Of course, this functionality only provides access for the server, IT DOES NOT
PROPAGATE TO ANY SCRIPT ACCESS. If scripts must have a similar ability they
should implement their own sys$check_access() (which is not too difficult)
based on the WWW_AUTH_REALM which would be "VMS" indicating
SYSUAF-authentication, and the authenticated name in WWW_REMOTE_USER.

Note: the sys$assume_persona(), et.al., which might seem a more thorough
approach to this functionality, was not possible due to the "independently"
executing script processes associated with the server that might be adversely
affected by such an abrupt change in identity!


Controlling server write access
-------------------------------

Write access by the server into VMS directories should be controlled using VMS
ACLs.  World write access should not be given to any server accessed directory.
This is in addition to the path authorization of the server itself of course!
The requirement to have an ACL on the directory prevents inadvertant
mapping/authorization path being able to be written to.  Two different ACLs
control two different grades of access.

1. If the ACL grants CONTROL access to the server account then only
VMS-authenticated usernames with security profiles can potentially write to
the directory, potentially, because a further check is made to assess whether
that VMS account has write access.

This example show a suitable ACL that stays only on the original directory:

  $ SET SECURITY directory.DIR -
    /ACL=(IDENT=HTTP$SERVER,ACCESS=READ+WRITE+EXECUTE+DELETE+CONTROL)

This example shows setting an ACL that will propagate to created
subdirectories:

  $ SET SECURITY directory.DIR -
    /ACL=((IDENT=HTTP$SERVER,OPTIONS=DEFAULT,ACCESS=READ+WRITE+EXECUTE+DELETE+CONTROL), -
          (IDENT=HTTP$SERVER,ACCESS=READ+WRITE+EXECUTE+DELETE+CONTROL))

2. If the ACL grants WRITE access then the directory can be written into by
any authenticated username for the authorized path.

This example show a suitable ACL that stays only on the original directory:

  $ SET SECURITY directory.DIR -
    /ACL=(IDENT=HTTP$SERVER,ACCESS=READ+WRITE+EXECUTE+DELETE)

This example shows setting an ACL that will propagate to created
subdirectories:

  $ SET SECURITY directory.DIR -
    /ACL=((IDENT=HTTP$SERVER,OPTIONS=DEFAULT,ACCESS=READ+WRITE+EXECUTE+DELETE), -
          (IDENT=HTTP$SERVER,ACCESS=READ+WRITE+EXECUTE+DELETE))


Implementation
--------------

A linked-list, binary tree (using the the LIB$..._TREE routines) is used to 
store authentication records.  When a request with an "Authorization:" header 
line encounters a point where authentication is required this binary tree is 
checked for an existing record.  If one does not exist a new one is entered 
into the binary tree, with an empty password field.  The password in the 
authorization line is checked against the password in the record.  If it 
matches the request is authenticated.

If a binary tree record is not found the SYSUAF or REALM-based password is
checked.  If the hashed password matches, the plain password is copied into the
record and used for future authentications.  If not, the authentication fails.

Once a user name is authenticated from the password database, for a limited
period (currently 60 minutes), further requests are authenticated directly
from the binary tree.  This improves performance and reduces file system
references for authentication.  After that period expires the password and any
group access database is again explicitlty checked.  The internal, binary tree
database can be explicitly listed, flushed or re-loaded as required.

A request's authorization flags (->AuthRequestCan) governs what can and can't be
done using authorization.  These are arrived at by bit-wise ANDing of flags
from two sources ...

   o  'AuthGroupCan' flags associated with the authorization realm and path
   o  'AuthUserCan' flags associated with the authenticated user

... this ensuring that the minimum of actions permitted by either path or user
capabilities is reflected in the request capabilities.


VERSION HISTORY
---------------
24-JAN-2001  MGD  bugfix; memory leak with user details
03-DEC-2000  MGD  bugfix; final forbidden requires 403
01-SEP-2000  MGD  generalize authorization to take a path parameter
11-JUN-2000  MGD  add network-mask to authorization restriction list,
                  allow agent "302 location" redirection response
06-MAY-2000  MGD  proxy authorization
08-APR-2000  MGD  bugfix; update cache NoCache flag after authentication 
28-MAR-2000  MGD  AuthRestrictAny() check only if cache entry is authenticated
06-JAN-2000  MGD  bugfix; user restriction list pass (broken in 6.1)
24-DEC-1999  MGD  break-in evasion period with expiry
20-NOV-1999  MGD  add nil-access identifier to bypass hour restrictions
28-AUG-1999  MGD  AUTH.C split into more manageable modules,
                  asynchronous "agent" authentication,
                  usernames and passwords stored case-sensitive,
                  authenticated user details
05-AUG-1999  MGD  authentication cancellation via "?httpd=logout",
                  check UAI_NETWORK/REMOTE_ACCESS_x for access restrictions,
                  identifier enabled access allows CAPTIVE and RESTRICTED,
                  bugfix; check for "SSL only" after authorization cache hit,
                  bugfix; revalidate user minutes update
20-FEB-1999  MGD  extend authentication/authorization use of VMS identifiers,
                  refine authorization with [realm;group-r+w;group-r],
                  ALL paths with problems of any sort load, then always FAIL!
19-DEC-1998  MGD  refine authorization WATCH information
07-NOV-1998  MGD  WATCH facility
17-OCT-1998  MGD  [realm-name=VMS] synonym hiding the fact it's SYSUAF,
                  virtual services via "[[virtual-host:virtual-port]]"
29-AUG-1998  MGD  move authorization path processing into AuthPathLine(),
                  report authentication failures in process log,
                  change in behaviour: after cache minutes expires request
                  revalidation by the user via browser dialog
16-JUL-1998  MGD  /SYSUAF=ID, authentication with possession of an identifier,
                  AUTH_DENIED_BY_OTHER indicates non-authentication forbidden
11-MAR-1998  MGD  added local redirection kludge ('^'),
                  configurable SYSUAF authentication of privileged accounts,
                  bugfix; alpha-numeric hosts in access-restriction lists
                  rejected as "unknown HTTP method"
08-FEB-1998  MGD  provide SSL-only for SYSUAF and authorization in general,
                  provide SSL-only for authorized paths (via "https:" or
                  "http:" in path access restriction list),
                  removed full method descriptions from user auth report
17-AUG-1997  MGD  message database,
                  SYSUAF-authenticated users security-profile
16-JUL-1997  MGD  fixed design flaw with WORLD realm and access restriction
01-FEB-1997  MGD  HTTPd version 4
01-JUL-1996  MGD  path/realm-based authorization/authentication
15-MAR-1996  MGD  bugfix; some ErrorGeneral() not passing the request pointer
01-DEC-1995  MGD  HTTPd version 3
01-APR-1995  MGD  initial development for local (SYSUAF) authentication
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <descrip.h>
#include <libdef.h>
#include <ssdef.h>
#include <stsdef.h>

#include <uaidef.h>
/* not defined in VAX C 3.2 <uaidef.h> */
#define UAI$M_RESTRICTED 0x8
#define UAI$C_PURDY_S 3

/* application related header files */
#include "wasd.h"

#define WASD_MODULE "AUTH"

#if DBUG
#define FI_NOLI WASD_MODULE, __LINE__
#else
/* in production let's keep the exact line to ourselves! */
#define FI_NOLI WASD_MODULE, 0
#endif

/* NO reset after 401 HTTP status, authorization challenge needs the realm */
#define AUTH_RESET_REQUEST { \
   rqptr->RemoteUser[0] = \
      rqptr->RemoteUserPassword[0] = '\0'; \
   rqptr->rqAuth.AgentParameterPtr = \
      rqptr->rqAuth.GroupReadPtr = \
      rqptr->rqAuth.GroupRestrictListPtr = \
      rqptr->rqAuth.GroupWritePtr = \
      rqptr->rqAuth.RealmPtr = \
      rqptr->rqAuth.RealmDescrPtr = \
      rqptr->rqAuth.WorldRestrictListPtr = ""; \
   rqptr->rqAuth.AgentParameterLength = \
      rqptr->rqAuth.GroupCan = \
      rqptr->rqAuth.Scheme =  \
      rqptr->rqAuth.SourceGroupWrite = \
      rqptr->rqAuth.SourceGroupRead = \
      rqptr->rqAuth.SourceRealm = \
      rqptr->rqAuth.WorldCan = 0; }


/******************/
/* global storage */
/******************/

/* explicit storage so that the address can be used for comparison */
char  AuthAgentParamGroup [] = "GROUP",
      AuthAgentParamRealm [] = "REALM";


/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern boolean  AuthorizationEnabled,
                AuthPolicySslOnly,
                AuthPolicyAuthorizedOnly,
                AuthPolicySysUafSslOnly,
                AuthPromiscuous,
                AuthSysUafEnabled,
                AuthSysUafPromiscuous,
                AuthVmsUserSecProfileEnabled;

extern int  WatchEnabled,
            OpcomMessages,
            ServerPort,
            ServiceCount;

extern unsigned long  AuthHttpsOnlyVmsIdentifier,
                      AuthWasdPwdVmsIdentifier,
                      AuthWasdHttpsVmsIdentifier,
                      AuthWasdReadVmsIdentifier,
                      AuthWasdWriteVmsIdentifier;

extern char  *AuthPromiscuousPwdPtr;

extern char  ErrorSanityCheck[],
             ServerHostName[],
             ServerHostPort[],
             SoftwareID[],
             Utility[];

extern struct AccountingStruct  Accounting;
extern struct ConfigStruct  Config;
extern struct MsgStruct  Msgs;

/*****************************************************************************/
/*
This function is pivotal to the HTTPd's authorization and authentication.  All
requests should call this function before proceding.

The results of the authorization must always be determined from
'rqptr->rqAuth.FinalStatus'.  A success status indicates the request may
proceed, any other status (usually errors, including AUTH_DENIED_... pseudo
statuses) indicate not authorized, and the request should be ended. 
Authorization challenges, access denied and error reports, etc., generated
during authorization will be delivered as the request is run down.

This function CAN complete asynchronously and calling code should be prepared
for this.  It can, and often does, complete synchronously and THEREFORE DOES
NOT ALWAYS DELIVER the AST.  If an authorization needs to be completed
asynchronously the 'rqptr->rqAuth.FinalStatus' is set to AUTH_PENDING and
the calling routine after detecting this should just 'return;'.  Upon
completion of the authorization the AST function will be called, when the
results can be ascertained from 'rqptr->rqAuth.FinalStatus' in the normal
manner.  If completing synchronously the calling routine should immediately
call the AST function directly.
*/ 

Authorize
(
struct RequestStruct *rqptr,
char *PathBeingAuthorized,
int PathBeingAuthorizedLength,
void *AuthorizeAstFunction
)
/*
{
int  status;

Debug = 1;
status = Authorize_ (rqptr);
Debug = 0;
return status;
}

Authorize_ 
*/

{
   boolean  WatchThisOne;
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "Authorize() %d |%s|\n",
               PathBeingAuthorizedLength, PathBeingAuthorized);

   if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
      WatchThisOne = true;
   else
      WatchThisOne = false;

   if (WatchThisOne)
      WatchThis (rqptr, FI_LI, WATCH_AUTH,
                 "PATH !AZ", PathBeingAuthorized);

   /* buffer the completion AST address in case we need it later */
   rqptr->rqAuth.AstFunctionBuffer = AuthorizeAstFunction;
   rqptr->rqAuth.AstFunction = NULL;

   /* always start with this status denying access, allow by changing */
   rqptr->rqAuth.FinalStatus = STS$K_ERROR;

   if (!AuthPromiscuous &&
       ((!AuthorizationEnabled &&
         !AuthPolicyAuthorizedOnly) ||
        (!Config.cfAuth.BasicEnabled &&
         !Config.cfAuth.DigestEnabled)))
   {
      /********************************************/
      /* no authorization is mapped, use defaults */
      /********************************************/

      if (WatchThisOne)
         WatchThis (rqptr, FI_LI, WATCH_AUTH, "DISABLED");

      AUTH_RESET_REQUEST
      rqptr->rqAuth.GroupCan =
         rqptr->rqAuth.RequestCan =
         rqptr->rqAuth.UserCan =
         rqptr->rqAuth.WorldCan = AUTH_READONLY_ACCESS;
      rqptr->rqAuth.FinalStatus = SS$_NORMAL;
      return;
   }

   /****************************/
   /* authorization is enabled */
   /****************************/

   if (AuthPolicySslOnly && rqptr->ServicePtr->RequestScheme != SCHEME_HTTPS)
   {
      /***********************************************/
      /* policy ... authorization only when "https:" */
      /***********************************************/

      if (WatchThisOne)
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
                    "POLICY https: (SSL) ONLY");

      rqptr->rqAuth.FinalStatus = STS$K_ERROR;
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_ACCESS_DENIED), FI_NOLI);
      return;
   }

   /**************/
   /* check path */
   /**************/

   status = AuthConfigSearch (rqptr, NULL, PathBeingAuthorized);

   if (VMSnok (status))
   {
      /*************************/
      /* not a controlled path */
      /*************************/

      if (Debug) fprintf (stdout, "not controlled!\n");

      if (AuthPolicyAuthorizedOnly)
      {
         /******************************************/
         /* policy: no authorization ... no access */
         /******************************************/

         if (WatchThisOne)
            WatchThis (rqptr, FI_LI, WATCH_AUTH,
                       "POLICY authorized paths ONLY");

         rqptr->rqAuth.FinalStatus = STS$K_ERROR;
         rqptr->rqResponse.HttpStatus = 403;
         ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_ACCESS_DENIED), FI_NOLI);
         return;
      }

      /**********************/
      /* use default access */
      /**********************/

      if (WatchThisOne)
         WatchThis (rqptr, FI_LI, WATCH_AUTH, "NONE applies");

      /*
         If there is already a source realm set then this has been from
         authorization applied to the script portion of a script request.
         Do not reset this as in the absence of authorization on the
         "file" portion it defines the level of access for that request.
      */
      if (!rqptr->rqAuth.SourceRealm)
      {
         AUTH_RESET_REQUEST
         rqptr->rqAuth.GroupCan =
            rqptr->rqAuth.RequestCan =
            rqptr->rqAuth.UserCan =
            rqptr->rqAuth.WorldCan = AUTH_READONLY_ACCESS;
      }

      rqptr->rqAuth.FinalStatus = SS$_NORMAL;
      return;
   }

   /*********************************/
   /* controlled path, authorize it */
   /*********************************/

   if (PathBeingAuthorizedLength <= 0)
       PathBeingAuthorizedLength = strlen(PathBeingAuthorized);
   rqptr->rqAuth.PathBeingAuthorizedPtr =
      VmGetHeap (rqptr, PathBeingAuthorizedLength+1);
   /* including the terminating null */
   memcpy (rqptr->rqAuth.PathBeingAuthorizedPtr,
           PathBeingAuthorized,
           PathBeingAuthorizedLength+1);
   rqptr->rqAuth.PathBeingAuthorizedLength = PathBeingAuthorizedLength;

   if (Debug)
   {
      fprintf (stdout,
"|%s|%d|%s|%d|%s|%d|\n\
GroupCan: %08.08X WorldCan: %08.08X\n\
GroupRestriction |%s|\n\
WorldRestriction |%s|\n",
      rqptr->rqAuth.RealmPtr,
      rqptr->rqAuth.SourceRealm,
      rqptr->rqAuth.GroupWritePtr,
      rqptr->rqAuth.SourceGroupWrite,
      rqptr->rqAuth.GroupReadPtr,
      rqptr->rqAuth.SourceGroupRead,
      rqptr->rqAuth.GroupCan, rqptr->rqAuth.WorldCan,
      rqptr->rqAuth.GroupRestrictListPtr,
      rqptr->rqAuth.WorldRestrictListPtr);
   }

   if (WatchThisOne)
   {
      boolean ShowRealmDescription = rqptr->rqAuth.RealmDescrPtr[0] &&
                                     rqptr->rqAuth.RealmDescrPtr !=
                                     rqptr->rqAuth.RealmPtr; 

      WatchThis (rqptr, FI_LI, WATCH_AUTH,
         "[!AZ!AZ!AZ!AZ!AZ;!AZ!AZ;!AZ!AZ] !AZ !AZ ; !AZ !AZ",
         ShowRealmDescription ? "\"" : "",
         ShowRealmDescription ? (char*)rqptr->rqAuth.RealmDescrPtr : "",
         ShowRealmDescription ? "\"=" : "",
         rqptr->rqAuth.RealmPtr[0] ? (char*)rqptr->rqAuth.RealmPtr : "-",
         AuthSourceString (rqptr->rqAuth.RealmPtr, rqptr->rqAuth.SourceRealm),
         rqptr->rqAuth.GroupWritePtr[0] ? (char*)rqptr->rqAuth.GroupWritePtr : "-",
         AuthSourceString (rqptr->rqAuth.GroupWritePtr,
                           rqptr->rqAuth.SourceGroupWrite),
         rqptr->rqAuth.GroupReadPtr[0] ? (char*)rqptr->rqAuth.GroupReadPtr : "-",
         AuthSourceString (rqptr->rqAuth.GroupReadPtr,
                           rqptr->rqAuth.SourceGroupRead),
         rqptr->rqAuth.GroupRestrictListPtr[0] ?
            (char*)rqptr->rqAuth.GroupRestrictListPtr : "-",
         AuthCanString (rqptr->rqAuth.GroupCan, AUTH_CAN_FORMAT_SHORT),
         rqptr->rqAuth.WorldRestrictListPtr[0] ?
            (char*)rqptr->rqAuth.WorldRestrictListPtr : "-",
         AuthCanString (rqptr->rqAuth.WorldCan, AUTH_CAN_FORMAT_SHORT));
   }

   if (rqptr->rqAuth.SourceRealm == AUTH_SOURCE_NONE)
   {
      /******************/
      /* the NONE realm */
      /******************/

      /*
         The purpose of the "NONE" realm is to set the '->AuthRealmSource'
         so that the server knows it's passed through authorization, without
         actually requiring any authorization, etc.  Supports the use of
         'AuthPolicyAuthorizedOnly' for reducing the possibility of
         inadvertant resource access.
      */

      rqptr->rqAuth.FinalStatus = SS$_NORMAL;
      AUTH_RESET_REQUEST
      return;
   }

   if (rqptr->rqAuth.SourceRealm == AUTH_SOURCE_FAIL)
   {
      /*************************************************/
      /* problem with the configuration, default fail! */
      /*************************************************/

      rqptr->rqAuth.FinalStatus = STS$K_ERROR;
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_ACCESS_DENIED), FI_NOLI);
      return;
   }

   if (rqptr->rqHeader.Method & rqptr->rqAuth.WorldCan)
   {
      /**********************/
      /* world capabilities */
      /**********************/

      if (rqptr->rqAuth.WorldRestrictListPtr[0])
      {
         /***********************************************/
         /* check access against world restriction list */
         /***********************************************/

         status = AuthRestrictList (rqptr, rqptr->rqAuth.WorldRestrictListPtr);
         if (Debug) fprintf (stdout, "AuthRestrictList() %%X%08.08X\n", status);
         if (VMSnok (status))
         {
            rqptr->rqAuth.FinalStatus = status;
            rqptr->rqResponse.HttpStatus = 403;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_ACCESS_DENIED), FI_NOLI);
            return;
         }
      }

      if (WatchThisOne)
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
            "ACCESS world:!AZ",
            AuthCanString (rqptr->rqAuth.WorldCan, AUTH_CAN_FORMAT_SHORT));

      rqptr->rqAuth.RequestCan = rqptr->rqAuth.WorldCan;
      rqptr->rqAuth.FinalStatus = SS$_NORMAL;
      return;
   }

   if (rqptr->rqAuth.SourceRealm == AUTH_SOURCE_EXTERNAL)
   {
      /**********************************/
      /* externally (script) authorized */
      /**********************************/

      if (WatchThisOne)
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
            "ACCESS external:!AZ",
            AuthCanString (rqptr->rqAuth.GroupCan, AUTH_CAN_FORMAT_SHORT));

      status = AuthParseAuthorization (rqptr);
      if (Debug)
         fprintf (stdout, "AuthParseAuthorization() %%X%08.08X\n", status);

      if (VMSnok (status))
      {
         /* error from parse of authorization field */
         rqptr->rqAuth.FinalStatus = status;
         AuthorizeResponse (rqptr);
         return;
      }

      rqptr->rqAuth.RequestCan = rqptr->rqAuth.GroupCan;
      return;
   }

   if (rqptr->rqAuth.SourceRealm == AUTH_SOURCE_VMS ||
       rqptr->rqAuth.SourceRealm == AUTH_SOURCE_ID ||
       rqptr->rqAuth.SourceRealm == AUTH_SOURCE_WASD_ID)
   {
      if (!AuthSysUafEnabled ||
          (AuthPolicySysUafSslOnly &&
           rqptr->ServicePtr->RequestScheme != SCHEME_HTTPS))
      {
         /**********************/
         /* SYSUAF not allowed */
         /**********************/

         /* SYSUAF-authentication is disabled, or disabled for non-"https:" */ 

         if (WatchThisOne)
         {
            if (AuthPolicySysUafSslOnly)
               WatchThis (rqptr, FI_LI, WATCH_AUTH,
                          "SYSUAF SSL only");
            else
               WatchThis (rqptr, FI_LI, WATCH_AUTH,
                          "SYSUAF disabled");
         }

         rqptr->rqAuth.FinalStatus = STS$K_ERROR;
         rqptr->rqResponse.HttpStatus = 403;
         ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_ACCESS_DENIED), FI_NOLI);
         return;
      }
   }

   if (rqptr->rqAuth.GroupRestrictListPtr[0])
   {
      /*****************************************/
      /* check access against restriction list */
      /*****************************************/

      status = AuthRestrictList (rqptr, rqptr->rqAuth.GroupRestrictListPtr);
      if (Debug) fprintf (stdout, "AuthRestrictList() %%X%08.08X\n", status);
      /* denied by username is reported as authentication, not access, fail */
      if (status == AUTH_DENIED_BY_FAIL ||
          status == AUTH_DENIED_BY_HOSTNAME ||
          status == AUTH_DENIED_BY_PROTOCOL)
      {
         rqptr->rqAuth.FinalStatus = status;
         rqptr->rqResponse.HttpStatus = 403;
         ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_ACCESS_DENIED), FI_NOLI);
         return;
      }
   }

   if (rqptr->rqAuth.SourceRealm == AUTH_SOURCE_WORLD)
   {
      /********************************************/
      /* the WORLD realm (i.e. no authentication) */
      /********************************************/

      strcpy (rqptr->RemoteUser, AUTH_REALM_WORLD);
      rqptr->rqAuth.RequestCan = rqptr->rqAuth.UserCan = rqptr->rqAuth.GroupCan;
      rqptr->rqAuth.FinalStatus = SS$_NORMAL;
      return;
   }

   AuthorizeRealm (rqptr);
}

/*****************************************************************************/
/*
Look for an authentication record with the realm and username in the linked-
list, binary tree.  If one doesn't exists create a new one.  Check the supplied
password against the one in the record.  If it matches then authentication has
succeeded.  If not, the check the supplied password against the database.  If
it matches then copy the supplied password into the authentication record and
the authentication succeeds.  If it doesn't match then the authentication
fails.  Return AUTH_DENIED_BY_LOGIN to indicate authentication failure,
SS$_NORMAL indicating authentication success, or any other error status
indicating any other error.
*/ 

AuthorizeRealm (struct RequestStruct *rqptr)

{
   static long  Subx2 = 2,
                EdivIntoMinutes = 600000000;

   boolean  HttpdLogout,
            HasLoginCookie;
   int  status,
        MinutesAgo;
   unsigned long  Seconds,
                  Remainder;
   unsigned long  ResultTime [2];
   struct AuthCacheRecordStruct  *acrptr,
                                 *acsrptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthorizeRealm()\n");

   /* parse the "Authorization:" field */
   status = AuthParseAuthorization (rqptr);
   if (Debug) fprintf (stdout, "AuthParseAuthorization() %%X%08.08X\n", status);

   if (VMSnok (status))
   {
      /* error from parse of authorization field */
      rqptr->rqAuth.FinalStatus = status;
      AuthorizeResponse (rqptr);
      return;
   }

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_AUTH))
      WatchThis (rqptr, FI_LI, WATCH_AUTH,
                 "AUTHENTICATE user:!AZ realm:!AZ!AZ!AZ",
                 rqptr->RemoteUser, rqptr->rqAuth.RealmPtr,
                 AuthSourceString (rqptr->rqAuth.RealmPtr,
                                   rqptr->rqAuth.SourceRealm),
                 rqptr->rqAuth.NoCache ? " NOCACHE!" : "");

   if (tolower(rqptr->rqHeader.QueryStringPtr[0]) == 'h' &&
       (strsame (rqptr->rqHeader.QueryStringPtr, "httpd=cancel", 12) ||
        strsame (rqptr->rqHeader.QueryStringPtr, "httpd=logout", 12)))
      HttpdLogout = true;
   else
      HttpdLogout = false;

   /***********************************/
   /* generate a request cache record */
   /***********************************/

   rqptr->rqAuth.CacheSearchRecordPtr = acsrptr =
      VmGetHeap (rqptr, sizeof(struct AuthCacheRecordStruct));

   memcpy (acsrptr->AgentParameter,
           rqptr->rqAuth.AgentParameterPtr,
           (acsrptr->AgentParameterLength =
            rqptr->rqAuth.AgentParameterLength) + 1);

   memcpy (acsrptr->GroupWrite,
           rqptr->rqAuth.GroupWritePtr,
           (acsrptr->GroupWriteLength = rqptr->rqAuth.GroupWriteLength) + 1);

   memcpy (acsrptr->GroupRead,
           rqptr->rqAuth.GroupReadPtr,
           (acsrptr->GroupReadLength = rqptr->rqAuth.GroupReadLength) + 1);
                     
   strcpy (acsrptr->Password, rqptr->RemoteUserPassword);

   memcpy (acsrptr->Realm,
           rqptr->rqAuth.RealmPtr,
           (acsrptr->RealmLength = rqptr->rqAuth.RealmLength) + 1);

   memcpy (acsrptr->UserName,
           rqptr->RemoteUser,
           (acsrptr->UserNameLength = rqptr->RemoteUserLength) + 1);

   acsrptr->SourceRealm = rqptr->rqAuth.SourceRealm;
   acsrptr->SourceGroupRead = rqptr->rqAuth.SourceGroupRead;
   acsrptr->SourceGroupWrite = rqptr->rqAuth.SourceGroupWrite;

   HasLoginCookie = false;
   if (Config.cfAuth.RevalidateUserMinutes &&
       Config.cfAuth.RevalidateLoginCookie)
      if (rqptr->rqHeader.CookiePtr != NULL)
         if (HasLoginCookie = AuthCacheCheckLoginCookie (rqptr))
            AuthCacheResetLoginCookie (rqptr);

   /*********************/
   /* lookup the record */
   /*********************/

   status = AuthCacheFindRecord (acsrptr, &acrptr);
   if (Debug) fprintf (stdout, "AuthCacheFindRecord() %%X%08.08X\n", status);

   if (VMSok (status))
   {
      /*******************/
      /* existing record */
      /*******************/

      if (Debug)
         fprintf (stdout,
"AuthCacheRecord\n\
|%s|%d|\n\
|%s|%d|\n\
|%s|%d|\n\
|%s|%s|%08.08X|%d|%d|%d|%d\n",
            acrptr->Realm, acrptr->SourceRealm,
            acrptr->GroupWrite, acrptr->SourceGroupWrite,
            acrptr->GroupRead, acrptr->SourceGroupRead,
            acrptr->UserName, acrptr->UserDetailsPtr,
            acrptr->AuthUserCan, acrptr->AccessCount, acrptr->FailureCount,
            acrptr->VmsUserProfileLength, acrptr->VmsUserProfilePtr);

      status = lib$subx (&rqptr->rqTime.Vms64bit, &acrptr->LastAccessBinTime,
                         &ResultTime, &Subx2);
      if (VMSok (status))
      {
         status = lib$ediv (&EdivIntoMinutes, &ResultTime,
                            &MinutesAgo, &Remainder);
         if (Debug) fprintf (stdout, "lib$ediv() %%X%08.08X\n", status);
      }
      if (VMSnok (status)) MinutesAgo = 1440;
      if (Debug) fprintf (stdout, "%d\n", MinutesAgo);

      if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
      {
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
"CACHE [!AZ!AZ;!AZ!AZ;!AZ!AZ;!AZ!AZ] \
!AZ failures:!UL accesses:!UL minutes-ago:!UL!AZ",
            acrptr->Realm[0] ? (char*)acrptr->Realm : "-",
            AuthSourceString (acrptr->Realm, acrptr->SourceRealm),
            acrptr->AgentParameter[0] ? "param=" : "",
            acrptr->AgentParameter[0] ? (char*)acrptr->AgentParameter : "-",
            acrptr->GroupWrite[0] ? (char*)acrptr->GroupWrite : "-",
            AuthSourceString (acrptr->GroupWrite, acrptr->SourceGroupWrite),
            acrptr->GroupRead[0] ? (char*)acrptr->GroupRead : "-",
            AuthSourceString (acrptr->GroupRead, acrptr->SourceGroupRead),
            acrptr->UserName, acrptr->FailureCount, acrptr->AccessCount,
            MinutesAgo, rqptr->rqAuth.NoCache ? " NOCACHE!" : "");
      }

      /* buffer pointer for use through successive synchronous functions */
      rqptr->rqAuth.CacheRecordPtr = acrptr;

      if (acrptr->Password[0] &&
          VMSnok (status = AuthRestrictAny (rqptr, acrptr)))
      {
         /****************/
         /* restrictions */
         /****************/

         rqptr->rqAuth.FinalStatus = status;
         AuthorizeFinal (rqptr);
         return;
      }

      if (acrptr->FailureCount >= Config.cfAuth.FailureLimit)
      {
         /******************************/
         /* EXCEEDS FAILURE THRESHHOLD */
         /******************************/

         if (MinutesAgo > acrptr->FailureCount)
         {
            /*************************/
            /* failure record expiry */
            /*************************/

            WriteFaoStdout (
"%!AZ-I-AUTHFAILEXP, !20%D, !UL minutes, !UL !AZ.\'!AZ\'@!AZ\n \\!AZ !AZ\\\n",
               Utility, 0, MinutesAgo, acrptr->FailureCount,
               rqptr->RemoteUser, rqptr->rqAuth.RealmDescrPtr,
               rqptr->rqNet.ClientHostName,
               rqptr->rqHeader.MethodName, rqptr->rqHeader.RequestUriPtr);

            if (OpcomMessages & OPCOM_AUTHORIZATION)
               WriteFaoOpcom (
"%!AZ-I-AUTHFAILEXP, !UL minutes, !UL !AZ.\'!AZ\'@!AZ\r\n \\!AZ !AZ\\",
                  Utility, MinutesAgo, acrptr->FailureCount,
                  rqptr->RemoteUser, rqptr->rqAuth.RealmDescrPtr,
                  rqptr->rqNet.ClientHostName,
                  rqptr->rqHeader.MethodName, rqptr->rqHeader.RequestUriPtr);

            if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
               WatchThis (rqptr, FI_LI, WATCH_AUTH,
                  "EXPIRY break-in evasion after !UL minutes and !UL failures",
                   MinutesAgo, acrptr->FailureCount);

            acrptr->FailureCount = 0;
         }
         else
         {
            /***************************************/
            /* within expiry period ... fail again */
            /***************************************/

            acrptr->LastAccessBinTime[0] = rqptr->rqTime.Vms64bit[0];
            acrptr->LastAccessBinTime[1] = rqptr->rqTime.Vms64bit[1];

            memset (acrptr->Password, 0, sizeof(acrptr->Password));
            memset (acrptr->DigestResponse, 0, sizeof(acrptr->DigestResponse));

            if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
               WatchThis (rqptr, FI_LI, WATCH_AUTH,
                  "FAIL break-in evasion !UL failures exceeds limit of !UL",
                  acrptr->FailureCount, Config.cfAuth.FailureLimit);

            rqptr->rqAuth.FinalStatus = AUTH_DENIED_BY_LOGIN; 
            AuthorizeFinal (rqptr);
            return;
         }
      }

      acrptr->LastAccessBinTime[0] = rqptr->rqTime.Vms64bit[0];
      acrptr->LastAccessBinTime[1] = rqptr->rqTime.Vms64bit[1];

      if (Config.cfAuth.RevalidateUserMinutes)
      {
         /********************/
         /* revalidate user? */
         /********************/

         /*
            User validation only lasts for a limited period (< 24 hours).
            Check how long ago was the last authorization attempt, if that is
            exceeded force the user to reenter via browser dialog.
         */

         if (MinutesAgo >= Config.cfAuth.RevalidateUserMinutes)
         {
            if (HasLoginCookie)
            {
               if (rqptr->WatchItem &&
                   (WatchEnabled & WATCH_AUTH))
                  WatchThis (rqptr, FI_LI, WATCH_AUTH,
                             "REVALIDATE login cookie (!UL/!UL)",
                             MinutesAgo, Config.cfAuth.RevalidateUserMinutes);
            }
            else
            {
               if (rqptr->WatchItem &&
                   (WatchEnabled & WATCH_AUTH))
                  WatchThis (rqptr, FI_LI, WATCH_AUTH,
                             "FAIL !UL exceeds user revalidate timeout !UL",
                             MinutesAgo, Config.cfAuth.RevalidateUserMinutes);

               acrptr->Password[0]  = '\0';
               rqptr->rqAuth.FinalStatus = AUTH_DENIED_BY_LOGIN; 
               AuthorizeFinal (rqptr);
               return;
            }
         }
      }

      /*********************/
      /* revalidate cache? */
      /*********************/

      if (MinutesAgo >= Config.cfAuth.CacheMinutes)
      {
         /*
            Cache authentication only lasts for a limited period (< 24 hours).
            Must exceed the limit since the last authorization attempt.
         */

         if (rqptr->WatchItem &&
             (WatchEnabled & WATCH_AUTH))
            WatchThis (rqptr, FI_LI, WATCH_AUTH,
                       "FAIL !UL exceeds cache revalidate timeout !UL",
                       MinutesAgo, Config.cfAuth.CacheMinutes);

         acrptr->Password[0]  = '\0';
         /* drop through to recheck authentication */
      }

      /************************/
      /* check authentication */
      /************************/

      if (HttpdLogout)
         rqptr->rqAuth.FinalStatus = AUTH_DENIED_BY_LOGOUT;
      else
      if (rqptr->rqAuth.NoCache)
         rqptr->rqAuth.FinalStatus = AUTH_DENIED_BY_NOCACHE;
      else
      {
         if (rqptr->rqAuth.Scheme == AUTH_SCHEME_DIGEST)
         {
            if (acrptr->DigestResponse[0] &&
                !strcmp (rqptr->rqAuth.DigestResponsePtr, acrptr->DigestResponse))
            {
               rqptr->rqAuth.FinalStatus = SS$_NORMAL;
               acrptr->AccessCount++;
            }
         }
         else
         if (rqptr->rqAuth.Scheme == AUTH_SCHEME_BASIC)
         {
            if (acrptr->Password[0] &&
                !strcmp (rqptr->RemoteUserPassword, acrptr->Password))
            {
               rqptr->rqAuth.FinalStatus = SS$_NORMAL;
               acrptr->AccessCount++;
            }
         }
      }

      if (VMSok (rqptr->rqAuth.FinalStatus))
      {
         /*****************/
         /* authenticated */
         /*****************/

         rqptr->rqAuth.CaseLess = acrptr->CaseLess;
         rqptr->rqAuth.SysUafCanChangePwd = acrptr->SysUafCanChangePwd;
         rqptr->rqAuth.SysUafAuthenticated = acrptr->SysUafAuthenticated;
         rqptr->rqAuth.SysUafNilAccess = acrptr->SysUafNilAccess;
         rqptr->rqAuth.SourceRealm = acrptr->SourceRealm;
         rqptr->rqAuth.SourceGroupRead = acrptr->SourceGroupRead;
         rqptr->rqAuth.SourceGroupWrite = acrptr->SourceGroupWrite;
         rqptr->rqAuth.UserCan = acrptr->AuthUserCan;

         if (rqptr->rqAuth.VmsUserProfileLength = acrptr->VmsUserProfileLength)
         {
            rqptr->rqAuth.VmsUserProfilePtr =
                   VmGetHeap (rqptr, acrptr->VmsUserProfileLength);
            memcpy (rqptr->rqAuth.VmsUserProfilePtr,
                    acrptr->VmsUserProfilePtr,
                    acrptr->VmsUserProfileLength);
         }
         else
            rqptr->rqAuth.VmsUserProfilePtr = NULL;

         if (rqptr->rqAuth.UserDetailsLength = acrptr->UserDetailsLength)
         {
            rqptr->rqAuth.UserDetailsPtr =
               VmGetHeap (rqptr, rqptr->rqAuth.UserDetailsLength+1);
            strcpy (rqptr->rqAuth.UserDetailsPtr, acrptr->UserDetailsPtr);
         }
         else
            rqptr->rqAuth.UserDetailsPtr = NULL;

         if (Debug) fprintf (stdout, "authenticated (in tree)!\n");
         AuthorizeFinal (rqptr);
         return;
      }

      /*********************/
      /* not authenticated */
      /*********************/

      if (acrptr->UserDetailsLength)
         VmFree (acrptr->UserDetailsPtr, FI_LI);
      acrptr->UserDetailsLength = 0;
      acrptr->UserDetailsPtr = NULL;

      if (acrptr->VmsUserProfileLength)
         VmFree (acrptr->VmsUserProfilePtr, FI_LI);
      acrptr->VmsUserProfileLength = 0;
      acrptr->VmsUserProfilePtr = NULL;
   }
   else
   if (status == LIB$_KEYNOTFOU)
   {
      /****************************************/
      /* record not found in tree, create one */
      /****************************************/

      acrptr = VmGet (sizeof(struct AuthCacheRecordStruct));
      
      /* buffer pointer for use through successive synchronous functions */
      rqptr->rqAuth.CacheRecordPtr = acrptr;

      /* we know these'll fit, sizes have been checked during authentication */
      strcpy (acrptr->Realm, acsrptr->Realm);
      acrptr->RealmLength = acsrptr->RealmLength;
      strcpy (acrptr->AgentParameter, acsrptr->AgentParameter);
      acrptr->AgentParameterLength = acsrptr->AgentParameterLength;
      strcpy (acrptr->GroupWrite, acsrptr->GroupWrite);
      acrptr->GroupWriteLength = acsrptr->GroupWriteLength;
      strcpy (acrptr->GroupRead, acsrptr->GroupRead);
      acrptr->GroupReadLength = acsrptr->GroupReadLength;
      strcpy (acrptr->UserName, acsrptr->UserName);
      acrptr->UserNameLength = acsrptr->UserNameLength;
      acrptr->SourceRealm = acsrptr->SourceRealm;
      acrptr->SourceGroupRead = acsrptr->SourceGroupRead;
      acrptr->SourceGroupWrite = acsrptr->SourceGroupWrite;
      acrptr->LastAccessBinTime[0] = rqptr->rqTime.Vms64bit[0];
      acrptr->LastAccessBinTime[1] = rqptr->rqTime.Vms64bit[1];
      /* all other fields have zeroes from the memory allocation! */

      status = AuthCacheAddRecord (acrptr);
      if (Debug) fprintf (stdout, "AuthCacheAddRecord() %%X%08.08X\n", status);

      if (VMSnok (status))
      {
         /* error adding record to cache, abandon all hope! */
         VmFree (acrptr, FI_LI);
         rqptr->rqAuth.FinalStatus = status;
         rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_GENERAL_INTERNAL);
         ErrorVmsStatus (rqptr, status, FI_LI);
         AuthorizeResponse (rqptr);
         return;
      }
   }

   if (VMSnok (status))
   {
      /* some other error, report it */
      rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_AUTH_USER);
      ErrorVmsStatus (rqptr, status, FI_LI);
      rqptr->rqAuth.FinalStatus = status;
      return;
   }

   /**********************************************/
   /* get authentication from appropriate source */
   /**********************************************/

   acrptr->DataBaseCount++;

   if (HttpdLogout)
   {
      rqptr->rqAuth.FinalStatus = AUTH_DENIED_BY_LOGOUT;
      AuthorizeFinal (rqptr);
      return;
   }

   if (AuthPromiscuous)
   {
      rqptr->rqAuth.FinalStatus = SS$_NORMAL;

      if (AuthPromiscuousPwdPtr != NULL)
         if (!strsame (rqptr->RemoteUserPassword, AuthPromiscuousPwdPtr, -1))
            rqptr->rqAuth.FinalStatus = AUTH_DENIED_BY_LOGIN;

      /* allow the user to do any/everything */
      if (VMSok (rqptr->rqAuth.FinalStatus))
         rqptr->rqAuth.UserCan = AUTH_READWRITE_ACCESS;

      AuthorizeRealmCheck (rqptr);
      return;
   }

   switch (rqptr->rqAuth.SourceRealm)
   {
      case AUTH_SOURCE_AGENT :

         /* asynchronous check via agent */
         Accounting.AuthAgentCount++;

         if (!rqptr->rqAuth.AgentParameterPtr[0])
         {
            rqptr->rqAuth.AgentParameterPtr = AuthAgentParamRealm;
            rqptr->rqAuth.AgentParameterLength = sizeof(AuthAgentParamRealm)-1;
         }

         /* after calling this function all will be asynchronous! */
         AuthAgentBegin (rqptr, rqptr->rqAuth.RealmPtr, &AuthorizeRealmCheck);

         /* ASYNCHRONOUS ... so now we return */
         return;

      case AUTH_SOURCE_VMS :
      case AUTH_SOURCE_ID :
      case AUTH_SOURCE_WASD_ID :

         /* check against SYSUAF */
         Accounting.AuthVmsCount++;
         acrptr->SysUafAuthenticated = rqptr->rqAuth.SysUafAuthenticated = true;

         rqptr->rqAuth.FinalStatus =
            AuthVmsVerifyPassword (rqptr, acrptr);

         /*
            SYSUAF authentication can only be performed using the basic
            scheme (it needs a clear-text password to hash and then compare)
         */
         rqptr->rqAuth.ChallengeScheme = AUTH_SCHEME_BASIC;

         break;

      case AUTH_SOURCE_LIST :

         /* check against simple list */
         Accounting.AuthSimpleListCount++;

         rqptr->rqAuth.FinalStatus =
            AuthReadSimpleList (rqptr, rqptr->rqAuth.RealmPtr, true);

         /* if the list has the user name and corrrect password */
         if (VMSok (status)) rqptr->rqAuth.UserCan = AUTH_READWRITE_ACCESS;

         break;

      case AUTH_SOURCE_HTA :

         /* check against HTA database */
         Accounting.AuthHtDatabaseCount++;
         rqptr->rqAuth.FinalStatus = 
            AuthReadHtDatabase (rqptr, rqptr->rqAuth.RealmPtr, true);

         break;

      default :
         ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
   }

   AuthorizeRealmCheck (rqptr);
}

/*****************************************************************************/
/*
Called directly or as an AST.  Check the authorization status and if an error
call AuthorizeFinal() directly.  If not an error check for restrictions to this
correctly authenticated access and call AuthorizeFinal() is any found.  If no
restrictions check if there is a read/write group and if there is call
AuthorizeGroupWrite() to check against this, if none then call
AuthorizeFinal().
*/ 

AuthorizeRealmCheck (struct RequestStruct *rqptr)

{
   int  status;
   struct AuthCacheRecordStruct  *acrptr,
                                 *acsrptr;
   
   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "AuthorizeRealmCheck() %%X%08.08X\n",
               rqptr->rqAuth.FinalStatus);

   if (VMSnok (rqptr->rqAuth.FinalStatus))
   {
      /* failure/error from realm authentication */
      AuthorizeFinal (rqptr);
      return;
   }

   if ((acsrptr = rqptr->rqAuth.CacheSearchRecordPtr) == NULL)
      ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);

   if ((acrptr = rqptr->rqAuth.CacheRecordPtr) == NULL)
   {
      status = AuthCacheFindRecord (rqptr->rqAuth.CacheSearchRecordPtr, &acrptr);
      if (Debug) fprintf (stdout, "AuthCacheFindRecord() %%X%08.08X\n", status);
      if (VMSnok (status))
      {
         /* something has happened to the cache record in the meantime! */
         rqptr->rqAuth.FinalStatus = status;
         rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_AUTH_DATABASE);
         ErrorVmsStatus (rqptr, status, FI_LI);
         AuthorizeResponse (rqptr);
         return;
      }

      /* buffer pointer for use through successive synchronous functions */
      rqptr->rqAuth.CacheRecordPtr = acrptr;
   }

   /* update the cache record with these flags */
   acrptr->CaseLess = rqptr->rqAuth.CaseLess;
   acrptr->HttpsOnly = rqptr->rqAuth.HttpsOnly;
   acrptr->NoCache = rqptr->rqAuth.NoCache;
   acrptr->SysUafCanChangePwd = rqptr->rqAuth.SysUafCanChangePwd;
   acrptr->SysUafNilAccess = rqptr->rqAuth.SysUafNilAccess;

   /* check for any non-path restrictions (e.g. "https:"-only, hours, etc.) */
   rqptr->rqAuth.FinalStatus = AuthRestrictAny (rqptr, acrptr);
   if (VMSnok (rqptr->rqAuth.FinalStatus))
   {
      /* yep, some restriction on user, end of assessment */
      AuthorizeFinal (rqptr);
      return;
   }

   if (rqptr->rqAuth.SourceRealm == AUTH_SOURCE_WASD_ID)
   {
      /* access is controlled by the (deprecated) WASD identifiers */
      rqptr->rqAuth.FinalStatus = AuthorizeWasdId (rqptr);
      AuthorizeFinal (rqptr);
      return;
   }

   if (rqptr->rqAuth.SourceGroupWrite)
   {
      /* there is at least one group following the realm */
      AuthorizeGroupWrite (rqptr);
      return;
   }

   /* otherwise we've reached the end of the assessment - successfully */
   AuthorizeFinal (rqptr);
}

/*****************************************************************************/
/*
Deprecated WASD VMS identifiers control access.  Make appropriate assessment.
*/ 

int AuthorizeWasdId (struct RequestStruct *rqptr)

{
   int  status;
   
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthorizeWasdId()\n");

   status = AuthVmsHoldsIdentifier (rqptr, AUTH_WASD_WRITE_VMS_ID,
                                    AuthWasdWriteVmsIdentifier);
   /* if it has the full-access identifier */
   if (VMSok (status))
      rqptr->rqAuth.UserCan = AUTH_READWRITE_ACCESS;
   else
   if (status == 0)
   {
      /* did not hold the full-access identifier */
      status = AuthVmsHoldsIdentifier (rqptr, AUTH_WASD_READ_VMS_ID,
                                       AuthWasdReadVmsIdentifier);
      /* if it has the read-only identifier */
      if (VMSok (status))
         rqptr->rqAuth.UserCan = AUTH_READONLY_ACCESS;
      else
      if (status == 0)
      {
         /* one or other of these MUST have allowed authentication! */
         ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
      }
   }

   if (rqptr->rqAuth.SourceGroupWrite)
   {
      /*
         Group membership specified.  Check for possession of
         a "WASD_VMS__groupname" identifier.
      */

      if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
                    "CHECK group !AZ!AZ!AZ",
                    AUTH_WASD__GROUP_VMS_ID,
                    rqptr->rqAuth.GroupWritePtr,
                    AuthSourceString (rqptr->rqAuth.GroupWritePtr,
                                      rqptr->rqAuth.SourceGroupWrite));

      status = AuthVmsHoldsWasdGroupIdent (rqptr, rqptr->rqAuth.GroupWritePtr);

      if (VMSnok (status))
      {
         /* doesn't hold the group identifier, no access */
         rqptr->rqAuth.UserCan = 0;
         status = AUTH_DENIED_BY_GROUP;
      }
   }

   return (status);
}

/*****************************************************************************/
/*
Check for full-access (read+write) group membership.
*/ 

AuthorizeGroupWrite (struct RequestStruct *rqptr)

{
   int  status;
   
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthorizeGroupWrite()\n");

   if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
      WatchThis (rqptr, FI_LI, WATCH_AUTH,
                 "CHECK r+w group !AZ!AZ",
                 rqptr->rqAuth.GroupWritePtr,
                 AuthSourceString (rqptr->rqAuth.GroupWritePtr,
                                   rqptr->rqAuth.SourceGroupWrite));

   switch (rqptr->rqAuth.SourceGroupWrite)
   {
      case AUTH_SOURCE_AGENT :

         Accounting.AuthAgentCount++;

         if (!rqptr->rqAuth.AgentParameterPtr[0] ||
             rqptr->rqAuth.AgentParameterPtr == AuthAgentParamRealm)
         {
            rqptr->rqAuth.AgentParameterPtr = AuthAgentParamGroup;
            rqptr->rqAuth.AgentParameterLength = sizeof(AuthAgentParamGroup)-1;
         }

         /* after calling this function all will be asynchronous! */
         AuthAgentBegin (rqptr, rqptr->rqAuth.GroupWritePtr,
                         &AuthorizeGroupWriteCheck);

         /* ASYNCHRONOUS ... so now we return */
         return;

      case AUTH_SOURCE_HTA :

         rqptr->rqAuth.FinalStatus =
            AuthReadHtDatabase (rqptr, rqptr->rqAuth.GroupWritePtr, false);
         break;

      case AUTH_SOURCE_ID :

         rqptr->rqAuth.FinalStatus =
            AuthVmsHoldsIdentifier (rqptr, rqptr->rqAuth.GroupWritePtr,
                                    rqptr->rqAuth.GroupWriteVmsIdentifier);
         break;

      case AUTH_SOURCE_LIST :

         rqptr->rqAuth.FinalStatus =
            AuthReadSimpleList (rqptr, rqptr->rqAuth.GroupWritePtr, false);
         break;

      default :
         ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
   }

   AuthorizeGroupWriteCheck (rqptr);
}

/*****************************************************************************/
/*
Called directly or as an AST.  Check the outcome of the the full-access
(read+write) group membership assessment.
*/ 

AuthorizeGroupWriteCheck (struct RequestStruct *rqptr)

{
   int  status;
   
   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "AuthorizeGroupWriteCheck() %%X%08.08X\n",
               rqptr->rqAuth.FinalStatus);

   if (VMSok (rqptr->rqAuth.FinalStatus))
   {
      /* found in the full-access group and therefore has access */
      rqptr->rqAuth.UserCan = AUTH_READWRITE_ACCESS;
      AuthorizeFinal (rqptr);
      return;
   }

   if (rqptr->rqAuth.SourceGroupRead)
   {
      /* there is a "read" group following the "write" group */
      AuthorizeGroupRead (rqptr);
      return;
   }

   /* not found in full-access group, no read-only group ... no access */
   status = AUTH_DENIED_BY_GROUP;
   AuthorizeFinal (rqptr);
}

/*****************************************************************************/
/*
Check for read-only access (second of two) group membership.
*/ 

AuthorizeGroupRead (struct RequestStruct *rqptr)

{
   int  status;
   
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthorizeGroupRead()\n");

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_AUTH))
      WatchThis (rqptr, FI_LI, WATCH_AUTH,
                 "CHECK r-only group !AZ!AZ",
                 rqptr->rqAuth.GroupReadPtr,
                 AuthSourceString (rqptr->rqAuth.GroupReadPtr,
                                   rqptr->rqAuth.SourceGroupRead));

   /* reset this group name so the read-only group name is obvious to CGI.C */
   rqptr->rqAuth.GroupWritePtr = "";

   switch (rqptr->rqAuth.SourceGroupRead)
   {
      case AUTH_SOURCE_AGENT :

         Accounting.AuthAgentCount++;

         if (!rqptr->rqAuth.AgentParameterPtr[0] ||
             rqptr->rqAuth.AgentParameterPtr == AuthAgentParamRealm)
         {
            rqptr->rqAuth.AgentParameterPtr = AuthAgentParamGroup;
            rqptr->rqAuth.AgentParameterLength = sizeof(AuthAgentParamGroup)-1;
         }

         /* after calling this function all will be asynchronous! */
         AuthAgentBegin (rqptr, rqptr->rqAuth.GroupReadPtr,
                         &AuthorizeGroupReadCheck);

         /* ASYNCHRONOUS ... so now we return */
         return;

      case AUTH_SOURCE_HTA :

         rqptr->rqAuth.FinalStatus =
            AuthReadHtDatabase (rqptr, rqptr->rqAuth.GroupReadPtr, false);
         break;

      case AUTH_SOURCE_ID :

         rqptr->rqAuth.FinalStatus =
            AuthVmsHoldsIdentifier (rqptr, rqptr->rqAuth.GroupReadPtr,
                                           rqptr->rqAuth.GroupReadVmsIdentifier);
         break;

      case AUTH_SOURCE_LIST :

         rqptr->rqAuth.FinalStatus =
            AuthReadSimpleList (rqptr, rqptr->rqAuth.GroupReadPtr, false);
         break;

      default :
         ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
   }
 
   AuthorizeGroupReadCheck (rqptr);
}

/*****************************************************************************/
/*
Called directly or as an AST.  Check the outcome of the the read-only group
membership assessment.
*/ 

AuthorizeGroupReadCheck (struct RequestStruct *rqptr)

{
   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "AuthorizeGroupReadCheck() %%X%08.08X\n",
               rqptr->rqAuth.FinalStatus);

   /* if found in the read-only access group */
   if (VMSok (rqptr->rqAuth.FinalStatus))
      rqptr->rqAuth.UserCan = AUTH_READONLY_ACCESS;
   else
      rqptr->rqAuth.FinalStatus = AUTH_DENIED_BY_GROUP;

   AuthorizeFinal (rqptr);
}

/*****************************************************************************/
/*
Called directly or as an AST.  Finish the authentication by updating the
authentication cache record with the results of the processing.  Then call
AuthorizeResponse() to set access or generate an appropriate HTTP error
response.
*/ 

AuthorizeFinal (struct RequestStruct *rqptr)

{
   struct AuthCacheRecordStruct  *acrptr,
                                 *acsrptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "AuthorizeFinal() %%X%08.08X\n",
               rqptr->rqAuth.FinalStatus);

   if ((acsrptr = rqptr->rqAuth.CacheSearchRecordPtr) == NULL)
      ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);

   if ((acrptr = rqptr->rqAuth.CacheRecordPtr) == NULL)
   {
      status = AuthCacheFindRecord (rqptr->rqAuth.CacheSearchRecordPtr, &acrptr);
      if (Debug) fprintf (stdout, "AuthCacheFindRecord() %%X%08.08X\n", status);
      if (VMSnok (status))
      {
         /* something has happened to the cache record in the meantime! */
         rqptr->rqAuth.FinalStatus = status;
         rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_AUTH_DATABASE);
         ErrorVmsStatus (rqptr, status, FI_LI);
         AuthorizeResponse (rqptr);
         return;
      }

      /* buffer pointer for use through successive synchronous functions */
      rqptr->rqAuth.CacheRecordPtr = acrptr;
   }

   if (Debug)
      fprintf (stdout,
         "AuthCacheRecord |%s|%s|%s|%s| %08.08X %d %d\n",
         acrptr->Realm, acrptr->GroupWrite, acrptr->GroupRead,
         acrptr->UserName, acrptr->AuthUserCan,
         acrptr->AccessCount, acrptr->FailureCount);

   if (VMSok (rqptr->rqAuth.FinalStatus))
   {
      /*****************/
      /* authenticated */
      /*****************/

      if (rqptr->rqAuth.Scheme == AUTH_SCHEME_BASIC)
      {
         strcpy (acrptr->Password, rqptr->RemoteUserPassword);
         acrptr->BasicCount++;
      }
      else
      if (rqptr->rqAuth.Scheme == AUTH_SCHEME_DIGEST)
      {
         strcpy (acrptr->DigestResponse, rqptr->rqAuth.DigestResponsePtr);
         acrptr->DigestCount++;
      }

      if (acrptr->FailureCount)
      {
         /* just let the log know the access finally succeeded */
         WriteFaoStdout (
"%!AZ-I-AUTHFAILOK, !20%D, !UL !AZ.\'!AZ\'@!AZ\n \\!AZ !AZ\\\n",
            Utility, 0, acrptr->FailureCount,
            rqptr->RemoteUser, rqptr->rqAuth.RealmDescrPtr, rqptr->rqNet.ClientHostName,
            rqptr->rqHeader.MethodName, rqptr->rqHeader.RequestUriPtr);

         if (OpcomMessages & OPCOM_AUTHORIZATION)
            WriteFaoOpcom (
"%!AZ-I-AUTHFAILOK, !UL !AZ.\'!AZ\'@!AZ\r\n \\!AZ !AZ\\",
               Utility, acrptr->FailureCount, rqptr->RemoteUser,
               rqptr->rqAuth.RealmDescrPtr, rqptr->rqNet.ClientHostName,
               rqptr->rqHeader.MethodName, rqptr->rqHeader.RequestUriPtr);
      }

      acrptr->FailureCount = 0;
      acrptr->AuthUserCan = rqptr->rqAuth.UserCan;

      if (acrptr->UserDetailsPtr == NULL)
      {
         if (acrptr->UserDetailsLength = rqptr->rqAuth.UserDetailsLength)
         {
            acrptr->UserDetailsPtr = VmGet (acrptr->UserDetailsLength+1);
            strcpy (acrptr->UserDetailsPtr, rqptr->rqAuth.UserDetailsPtr);
         }
         else
            acrptr->UserDetailsPtr = NULL;
      }

      if (AuthVmsUserSecProfileEnabled)
      {
         if (rqptr->rqAuth.SysUafAuthenticated &&
             !rqptr->rqAuth.VmsUserProfileLength)
         {
            rqptr->rqAuth.FinalStatus = AuthVmsCreateUserProfile (rqptr);
            if (VMSok (rqptr->rqAuth.FinalStatus))
            {
               acrptr->VmsUserProfilePtr =
                  VmGet (rqptr->rqAuth.VmsUserProfileLength);
               memcpy (acrptr->VmsUserProfilePtr ,
                       rqptr->rqAuth.VmsUserProfilePtr,
                       rqptr->rqAuth.VmsUserProfileLength);
               acrptr->VmsUserProfileLength = rqptr->rqAuth.VmsUserProfileLength;
            }
            else
            {
               acrptr->VmsUserProfilePtr = NULL;
               acrptr->VmsUserProfileLength = 0;
            }
         }
      }

      if (Debug) fprintf (stdout, "authenticated!\n");
   }
   else
   {
      /*********************/
      /* not authenticated */
      /*********************/

      acrptr->FailureCount++;
      rqptr->rqAuth.UserCan = 0;

      if (rqptr->rqAuth.FinalStatus == AUTH_DENIED_BY_LOGOUT)
      {
         WriteFaoStdout (
"%!AZ-I-AUTHLOGOUT, !20%D, !UL !AZ.\'!AZ\'@!AZ\n \\!AZ !AZ\\\n",
            Utility, 0, acrptr->FailureCount,
            rqptr->RemoteUser, rqptr->rqAuth.RealmDescrPtr, rqptr->rqNet.ClientHostName,
            rqptr->rqHeader.MethodName, rqptr->rqHeader.RequestUriPtr);

         if (OpcomMessages & OPCOM_AUTHORIZATION)
            WriteFaoOpcom (
"%!AZ-I-AUTHLOGOUT, !UL !AZ.\'!AZ\'@!AZ\r\n \\!AZ !AZ\\",
               Utility, acrptr->FailureCount, rqptr->RemoteUser,
               rqptr->rqAuth.RealmDescrPtr, rqptr->rqNet.ClientHostName,
               rqptr->rqHeader.MethodName, rqptr->rqHeader.RequestUriPtr);
      }
      else
      if (acrptr->FailureCount >= Config.cfAuth.FailureLimit)
      {
         WriteFaoStdout (
"%!AZ-W-AUTHFAILIM, !20%D, !UL !AZ.\'!AZ\'@!AZ\n \\!AZ !AZ\\\n",
            Utility, 0, acrptr->FailureCount,
            rqptr->RemoteUser, rqptr->rqAuth.RealmDescrPtr, rqptr->rqNet.ClientHostName,
            rqptr->rqHeader.MethodName, rqptr->rqHeader.RequestUriPtr);

         if (OpcomMessages & OPCOM_AUTHORIZATION)
            WriteFaoOpcom (
"%!AZ-W-AUTHFAILIM, !UL !AZ.\'!AZ\'@!AZ\r\n \\!AZ !AZ\\",
               Utility, acrptr->FailureCount, rqptr->RemoteUser,
               rqptr->rqAuth.RealmDescrPtr, rqptr->rqNet.ClientHostName,
               rqptr->rqHeader.MethodName, rqptr->rqHeader.RequestUriPtr);
      }
      else
      {
         WriteFaoStdout (
"%!AZ-W-AUTHFAIL, !20%D, !UL !AZ.\'!AZ\'@!AZ\n \\!AZ !AZ\\\n",
            Utility, 0, acrptr->FailureCount,
            rqptr->RemoteUser, rqptr->rqAuth.RealmDescrPtr, rqptr->rqNet.ClientHostName,
            rqptr->rqHeader.MethodName, rqptr->rqHeader.RequestUriPtr);

         if (OpcomMessages & OPCOM_AUTHORIZATION)
            WriteFaoOpcom (
"%!AZ-W-AUTHFAIL, !UL !AZ.\'!AZ\'@!AZ\r\n \\!AZ !AZ\\",
               Utility, acrptr->FailureCount, rqptr->RemoteUser,
               rqptr->rqAuth.RealmDescrPtr, rqptr->rqNet.ClientHostName,
               rqptr->rqHeader.MethodName, rqptr->rqHeader.RequestUriPtr);
      }
   }

   AuthorizeResponse (rqptr);
}

/*****************************************************************************/
/*
If authenticated then set the request's level of access and resume processing
(either just return or declare an AST).  The calling routine must check the
'rqptr->rqAuth.orizeStatus' to determine whether access was granted or not.  A
normal status indicates yes, an error status no.  If not then generate an HTTP
response appropriate to the reason for the denial and then resume processing. 
*/ 

AuthorizeResponse (struct RequestStruct *rqptr)

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "AuthorizeResponse() %%X%08.08X\n",
               rqptr->rqAuth.FinalStatus);

   /* we no longer want this hanging around our CGI variables */
   rqptr->rqAuth.AgentParameterPtr = "";
   rqptr->rqAuth.AgentParameterLength = 0;

   if (rqptr->rqAuth.FinalStatus == AUTH_DENIED_BY_LOGIN)
   {
      /**************************/
      /* authentication failure */
      /**************************/

      Accounting.AuthNotAuthenticatedCount++;

      /* generate a "WWW-Authorize:" challenge */
      if (rqptr->ServicePtr->ProxyAuthRequired)
         rqptr->rqResponse.HttpStatus = 407;
      else
         rqptr->rqResponse.HttpStatus = 401;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_FAILED), FI_NOLI);
      if (rqptr->rqAuth.AstFunction)
         SysDclAst (rqptr->rqAuth.AstFunction, rqptr);
      return;
   }

   if (rqptr->rqAuth.FinalStatus == AUTH_DENIED_BY_LOGOUT)
   {
      /******************************/
      /* authentication user cancel */
      /******************************/

      Accounting.AuthNotAuthenticatedCount++;

      /* generate a "WWW-Authorize:" challenge */
      if (rqptr->ServicePtr->ProxyAuthRequired)
         rqptr->rqResponse.HttpStatus = 407;
      else
         rqptr->rqResponse.HttpStatus = 401;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_NO_LOGOUT), FI_NOLI);
      if (rqptr->rqAuth.AstFunction)
         SysDclAst (rqptr->rqAuth.AstFunction, rqptr);
      return;
   }

   if (rqptr->rqAuth.FinalStatus == AUTH_DENIED_BY_REDIRECT)
   {
      /*********************/
      /* agent redirection */
      /*********************/

      Accounting.AuthNotAuthenticatedCount++;
      if (rqptr->rqAuth.AstFunction)
         SysDclAst (rqptr->rqAuth.AstFunction, rqptr);
      return;
   }

   if (VMSnok (rqptr->rqAuth.FinalStatus))
   {
      /***************/
      /* other error */
      /***************/

      /* if a non-specific error occured then always deny access */
      rqptr->rqResponse.HttpStatus = 403;
      if (rqptr->rqResponse.ErrorReportPtr == NULL)
         ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_ACCESS_DENIED), FI_NOLI);
      if (rqptr->rqAuth.AstFunction)
         SysDclAst (rqptr->rqAuth.AstFunction, rqptr);
      return;
   }

   if (rqptr->rqAuth.GroupRestrictListPtr[0])
   {
      /*****************************************/
      /* check access against restriction list */
      /*****************************************/

      status = AuthRestrictList (rqptr, rqptr->rqAuth.GroupRestrictListPtr);
      if (Debug) fprintf (stdout, "AuthRestrictList() %%X%08.08X\n", status);
      if (VMSnok (status))
      {
         rqptr->rqAuth.FinalStatus = status;
         if (rqptr->rqAuth.SourceRealm == AUTH_SOURCE_WORLD ||
             status == AUTH_DENIED_BY_FAIL ||
             status == AUTH_DENIED_BY_HOSTNAME ||
             status == AUTH_DENIED_BY_PROTOCOL)
            rqptr->rqResponse.HttpStatus = 403;
         else
         if (rqptr->ServicePtr->ProxyAuthRequired)
            rqptr->rqResponse.HttpStatus = 407;
         else
            rqptr->rqResponse.HttpStatus = 401;
         if (rqptr->rqResponse.ErrorReportPtr == NULL)
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_ACCESS_DENIED), FI_NOLI);
         if (rqptr->rqAuth.AstFunction)
            SysDclAst (rqptr->rqAuth.AstFunction, rqptr);
         return;
      }
   }

   /**************************************/
   /* set and check request capabilities */
   /**************************************/

   /* bit-wise AND of capabilities ensures minimum apply */
   rqptr->rqAuth.RequestCan = rqptr->rqAuth.GroupCan & rqptr->rqAuth.UserCan;

   if (Debug)
   {
      fprintf (stdout,
      "|%s|%s|%s|\nGroupCan: %08.08X UserCan: %08.08X RequestCan: %08.08X\n",
      rqptr->rqAuth.RealmPtr, rqptr->RemoteUser, rqptr->RemoteUserPassword,
      rqptr->rqAuth.GroupCan, rqptr->rqAuth.UserCan, rqptr->rqAuth.RequestCan);
   }

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_AUTH))
   {
      if (rqptr->rqAuth.UserDetailsPtr != NULL)
         WatchData (rqptr->rqAuth.UserDetailsPtr,
                         rqptr->rqAuth.UserDetailsLength);

      WatchThis (rqptr, FI_LI, WATCH_AUTH,
         "CAN group:!AZ user:!AZ request:!AZ!AZ!AZ!AZ",
         AuthCanString (rqptr->rqAuth.GroupCan, AUTH_CAN_FORMAT_SHORT),
         AuthCanString (rqptr->rqAuth.UserCan, AUTH_CAN_FORMAT_SHORT),
         AuthCanString (rqptr->rqAuth.RequestCan, AUTH_CAN_FORMAT_SHORT),
         AuthVmsUserSecProfileEnabled ? " profile:" : "",
         AuthVmsUserSecProfileEnabled &&
         rqptr->rqAuth.VmsUserProfileLength ? "YES" : "",
         AuthVmsUserSecProfileEnabled &&
         !rqptr->rqAuth.VmsUserProfileLength ? "NO" : "");
   }

   if (rqptr->rqHeader.Method & rqptr->rqAuth.RequestCan)
   {
      /*************************/
      /* authorized (finally!) */
      /*************************/

      Accounting.AuthAuthorizedCount++;
      rqptr->rqAuth.FinalStatus = SS$_NORMAL;
      if (rqptr->rqAuth.AstFunction)
         SysDclAst (rqptr->rqAuth.AstFunction, rqptr);
      return;
   }

   /*****************/
   /* 403 forbidden */
   /*****************/

   Accounting.AuthNotAuthorizedCount++;
   rqptr->rqResponse.HttpStatus = 403;
   ErrorGeneral (rqptr, "Forbidden to !AZ <TT>!AZ</TT>",
                 rqptr->rqHeader.MethodName,
                 rqptr->rqAuth.PathBeingAuthorizedPtr,
                 FI_LI);

   if (rqptr->rqAuth.AstFunction)
      SysDclAst (rqptr->rqAuth.AstFunction, rqptr);
}

/*****************************************************************************/
/*
Parse the "Authorization:" HTTP request header line.  Call appropriate function
to decode authorization field.  Check information is complete.
*/ 

int AuthParseAuthorization (struct RequestStruct *rqptr)

{
   register char  *cptr, *sptr, *zptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthParseAuthorization()\n");

   if ((cptr = rqptr->rqAuth.RequestAuthorizationPtr) == NULL)
   {
      if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
                    "FAIL no request \"!AZ\"",
                    rqptr->ServicePtr->ProxyAuthRequired ?
                       "Proxy-Authorization:" : "Authorization:");

      if (Config.cfAuth.RevalidateUserMinutes &&
          Config.cfAuth.RevalidateLoginCookie)
         AuthCacheSetLoginCookie (rqptr);

      return (AUTH_DENIED_BY_LOGIN);
   }

   /***********************************/
   /* get the HTTP authorization line */
   /***********************************/

   if (Debug) fprintf (stdout, "AuthRequestAuthorizationPtr |%s|\n", cptr);

   zptr = (sptr = rqptr->rqAuth.Type) + sizeof(rqptr->rqAuth.Type);
   while (*cptr && !ISLWS(*cptr) && sptr < zptr) *sptr++ = toupper(*cptr++);
   if (sptr >= zptr)
   {
      if (rqptr->ServicePtr->ProxyAuthRequired)
         rqptr->rqResponse.HttpStatus = 407;
      else
         rqptr->rqResponse.HttpStatus = 401;
      ErrorGeneralOverflow (rqptr, FI_LI);
      return (STS$K_ERROR);
   }
   *sptr = '\0';

   if (strsame (rqptr->rqAuth.Type, "BASIC"))
   {
      Accounting.AuthBasicCount++;

      if (VMSnok (status = BasicAuthorization (rqptr)))
         return (status);

      if (rqptr->RemoteUser[0] && rqptr->RemoteUserPassword[0])
         return (SS$_NORMAL);

      if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
                    "FAIL authentication incomplete");
      return (AUTH_DENIED_BY_LOGIN);
   }
   else
   if (strsame (rqptr->rqAuth.Type, "DIGEST"))
   {
      Accounting.AuthDigestCount++;

      if (VMSnok (status = DigestAuthorization (rqptr)))
         return (status);

      if (rqptr->RemoteUser[0] && rqptr->RemoteUserPassword[0])
         return (SS$_NORMAL);

      if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
                    "FAIL authentication incomplete");
      return (AUTH_DENIED_BY_LOGIN);
   }

   if (rqptr->ServicePtr->ProxyAuthRequired)
      rqptr->rqResponse.HttpStatus = 407;
   else
      rqptr->rqResponse.HttpStatus = 401;
   ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_SCHEME), FI_LI);
   return (STS$K_ERROR);
}

/*****************************************************************************/
/*
Check for any access restrictions.  SSL only.  SYSUAF restrictions on hours.
*/ 

int AuthRestrictAny
(
struct RequestStruct *rqptr,
struct AuthCacheRecordStruct *acrptr
)
{
   static unsigned long  DayOfWeek,
                         DayOfWeekBit,
                         PreviousDateDay;

   int  status;
   unsigned long  HourOfDayBit;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthRestrictAny()\n");

   /* can only use this authentication with "https:" (SSL)? */
   if (acrptr->HttpsOnly &&
       rqptr->ServicePtr->RequestScheme != SCHEME_HTTPS)
   {
      if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
                    "FAIL restricted to SSL");
      return (AUTH_DENIED_BY_PROTOCOL);
   }

   /* limited access? */
   if (acrptr->SysUafAuthenticated &&
       !acrptr->SysUafNilAccess)
   {
      if (rqptr->rqTime.VmsVector[2] != PreviousDateDay)
      {
         /* day in date has changed, ergo ... so has day-of-week! */
         PreviousDateDay = rqptr->rqTime.VmsVector[2];
         if (VMSnok (status = lib$day_of_week (0, &DayOfWeek)))
            ErrorExitVmsStatus (status, "lib$day_of_week()", FI_LI);
         DayOfWeekBit = 1 << (DayOfWeek - 1);
      }

      HourOfDayBit = 1 << rqptr->rqTime.VmsVector[3];

      if (Debug)
         fprintf (stdout, "DayOfWeek: %d %08.08X %08.08X\n",
                  DayOfWeek, DayOfWeekBit, acrptr->UaiPrimeDays);

      if (acrptr->UaiPrimeDays & DayOfWeekBit)
      {
         /* secondary day */
         if (Debug)
            fprintf (stdout, "secondary: %08.08X %08.08X %08.08X\n",
                     HourOfDayBit, acrptr->UaiNetworkAccessS,
                     acrptr->UaiRemoteAccessS);

         if (HourOfDayBit & acrptr->UaiNetworkAccessS ||
             HourOfDayBit & acrptr->UaiRemoteAccessS)
         {
            if (rqptr->WatchItem &&
                (WatchEnabled & WATCH_AUTH))
               WatchThis (rqptr, FI_LI, WATCH_AUTH,
                          "FAIL restricted SYSUAF secondary hours");
            return (AUTH_DENIED_BY_HOUR);
         }
      }
      else
      {
         /* prime day */
         if (Debug)
            fprintf (stdout, "primary: %08.08X %08.08X %08.08X\n",
                     HourOfDayBit, acrptr->UaiNetworkAccessP,
                     acrptr->UaiRemoteAccessP);

         if (HourOfDayBit & acrptr->UaiNetworkAccessP ||
             HourOfDayBit & acrptr->UaiRemoteAccessP)
         {
            if (rqptr->WatchItem &&
                (WatchEnabled & WATCH_AUTH))
               WatchThis (rqptr, FI_LI, WATCH_AUTH,
                          "FAIL restricted SYSUAF primary hours");
            return (AUTH_DENIED_BY_HOUR);
         }
      }
   }

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
The list is a plain-text string of comma-separated elements, the presence of
which restricts the path to that element.  The element can be an IP host
address (numeric or alphabetic, with or without asterisk wildcard) or an
authenticated username.  IP addresses are recognised by either a leading digit
(for numeric host addresses), a leading asterisk (where hosts are wildcarded
across a domain), a leading "#" which forces an element to be compared to a
host name or address, "http:", "https:", or a leading "~" which indicates a
username.
*/ 

int AuthRestrictList
(
struct RequestStruct *rqptr,
char *RestrictList
)
{
   register char  *lptr, *cptr;

   boolean  CheckedHost,
            CheckedProtocol,
            CheckedUser,
            FoundHost,
            FoundProtocol,
            FoundUser,
            RestrictedOnFail,
            RestrictedOnHost,
            RestrictedOnProtocol,
            RestrictedOnUser;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthRestrictList() |%s|\n", RestrictList);

   RestrictedOnFail = false;
   RestrictedOnHost = RestrictedOnProtocol = RestrictedOnUser = true;
   FoundHost = FoundProtocol = FoundUser = false;
   lptr = RestrictList;
   while (*lptr)
   {
      CheckedUser = CheckedHost = false;
      while (*lptr && *lptr == ',') lptr++;
      if (*lptr == AUTH_RESTRICTED_FAIL[0] &&
          strsame (lptr, AUTH_RESTRICTED_FAIL, 6))
      {
         /* there was a problem with the restriction list, automatic failure */
         RestrictedOnFail = true;
         break;
      }
      if (isdigit(*lptr) || (lptr[0] == '#' && isdigit(lptr[1])))
      {
         /* numeric IP address */
         if (*lptr == '#') lptr++;
         CheckedHost = FoundHost = true;

         /* look ahead for a net-mask (e.g. "131.185.250.23/255.255.255.192") */
         for (cptr = lptr; *cptr && (isdigit(*cptr) || *cptr == '.'); cptr++);
         if (*cptr == '/')
         {
            /* yup, found a '/' so it has a trailing mask */
            struct NetMaskStruct  NetMask;
            if ((lptr = ParseNetMask (lptr, &NetMask)) == NULL)
            {
               /* there was a problem with the net-mask, automatic failure */
               RestrictedOnFail = true;
               break;
            }
            if ((NetMask.BitsNetwork & NetMask.BitsMask) ==
                (rqptr->rqNet.ClientIpAddress & NetMask.BitsMask))
               RestrictedOnHost = false;
            continue;
         }
         /* just a numeric host string, drop through to comparison routine */
         cptr = rqptr->rqNet.ClientIpAddressString;
      }
      else
      if (*lptr == '~')
      {
         /* authenticated user name */
         lptr++;
         cptr = rqptr->RemoteUser;
         CheckedUser = FoundUser = true;
         /* drop through to the comparison routine */
      }
      else
      if (tolower(*lptr) == 'h' && strsame (lptr, "https:", 6))
      {
         CheckedProtocol = FoundProtocol = true;
         if (rqptr->ServicePtr->RequestScheme == SCHEME_HTTPS)
            RestrictedOnProtocol = false;
         while (*lptr && *lptr != ',') lptr++;
         continue;
      }
      else
      if (tolower(*lptr) == 'h' && strsame (lptr, "http:", 5))
      {
         CheckedProtocol = FoundProtocol = true;
         if (rqptr->ServicePtr->RequestScheme == SCHEME_HTTP)
            RestrictedOnProtocol = false;
         while (*lptr && *lptr != ',') lptr++;
         continue;
      }
      else
      if (tolower(*lptr) == 'l' &&
          (strsame (lptr, "localhost", -1) ||
           strsame (lptr, "localhost,", 10)))
      {
         /* check reserved-word, server against client host's IP address */
         CheckedHost = FoundHost = true;
         if (strsame (rqptr->ServicePtr->ServerIpAddressString,
                      rqptr->rqNet.ClientIpAddressString, -1))
            RestrictedOnHost = false;
         while (*lptr && *lptr != ',') lptr++;
         continue;
      }
      else
      {
         /* by default, alpha-numeric IP host name */
         if (*lptr == '#') lptr++;
         cptr = rqptr->rqNet.ClientHostName;
         CheckedHost = FoundHost = true;
         /* drop through to the comparison routine */
      }
      if (Debug) fprintf (stdout, "|%s|%s|\n", lptr, cptr);

      while (*cptr && *lptr && *lptr != ',')
      {
         if (*lptr == '*')
         {
            while (*lptr == '*') lptr++;
            while (*cptr && tolower(*cptr) != tolower(*lptr)) cptr++;
         }
         while (tolower(*cptr) == tolower(*lptr) && *cptr && *lptr)
         {
            lptr++;
            cptr++;
         }
         if (*lptr != '*') break;
      }
      if (!*cptr && (!*lptr || *lptr == ','))
      {
         if (CheckedUser) RestrictedOnUser = false;
         if (CheckedHost) RestrictedOnHost = false;
      }
      while (*lptr && *lptr != ',') lptr++;
   }

   if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
   {
      char  Scratch [32];

      *(cptr = Scratch) = '\0';
      if (FoundProtocol && RestrictedOnProtocol)
      {
         strcpy (cptr, "PROTOCOL");
         cptr += 8;
      }
      if (FoundHost && RestrictedOnHost)
      {
         if (Scratch[0]) *cptr++ = '+';
         strcpy (cptr, "HOST");
         cptr += 4;
      }
      if (FoundUser && RestrictedOnUser)
      {
         if (Scratch[0]) *cptr++ = '+';
         strcpy (cptr, "USER");
      }
      if (RestrictedOnFail) strcpy (Scratch, AUTH_RESTRICTED_FAIL);
      if (Scratch[0])
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
                    "RESTRICT \"!AZ\" on:!AZ", RestrictList, Scratch);
   }

   if (RestrictedOnFail) return (AUTH_DENIED_BY_FAIL);
   if (FoundProtocol && RestrictedOnProtocol)
      return (AUTH_DENIED_BY_PROTOCOL);
   if (FoundHost && RestrictedOnHost) return (AUTH_DENIED_BY_HOSTNAME);
   if (FoundUser && RestrictedOnUser) return (AUTH_DENIED_BY_USERNAME);

   if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
      WatchThis (rqptr, FI_LI, WATCH_AUTH,
                 "RESTRICT \"!AZ\" none applies", RestrictList);
   return (SS$_NORMAL);
}

/****************************************************************************/
/*
Place the VMS-hashed password into the pointed to quadword.  This CANNOT be
used to hash the UAF password as it does not use the UAF entry salt, etc.
*/ 

AuthGenerateHashPassword
(
char *UserName,
char *Password,
unsigned long *HashedPwdPtr
)
{
   static $DESCRIPTOR (PasswordDsc, "");
   static $DESCRIPTOR (UserNameDsc, "");

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "AuthGenerateHashPassword() |%s|%s|\n",
               UserName, Password);

   UserNameDsc.dsc$w_length = strlen(UserName);
   UserNameDsc.dsc$a_pointer = UserName;

   PasswordDsc.dsc$w_length = strlen(Password);
   PasswordDsc.dsc$a_pointer = Password;

   status = sys$hash_password (&PasswordDsc, UAI$C_PURDY_S, 0,
                               &UserNameDsc, HashedPwdPtr);
   if (Debug)
      fprintf (stdout, "sys$hash_password() %%X%08.08X|%08.08X%08.08X|\n",
               status, HashedPwdPtr[1], HashedPwdPtr[0]);
   return (status);
}

/****************************************************************************/
/*
Place the MD5 Digest upper and lower case passwords into to pointed to
two 16-byte arrays.  This is the 128 bit, binary digest, NOT the hexadecimal
version.  See note on upper and lower case versions in program comments.
*/ 

AuthGenerateDigestPassword
(
char *DatabaseName,
char *UserName,
char *Password,
unsigned char *A1DigestLoCasePtr,
unsigned char *A1DigestUpCasePtr
)
{
   register char  *cptr, *sptr;

   int  status;
   char PasswordUpCase [AUTH_MAX_PASSWORD_LENGTH+1],
        PasswordLoCase [AUTH_MAX_PASSWORD_LENGTH+1],
        UserNameUpCase [AUTH_MAX_PASSWORD_LENGTH+1],
        UserNameLoCase [AUTH_MAX_PASSWORD_LENGTH+1];

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "AuthGenerateDigestPassword() |%s|%s|%s|\n",
               DatabaseName, UserName, Password);

   sptr = PasswordUpCase;
   for (cptr = Password; *cptr; *sptr++ = toupper(*cptr++));
   *sptr = '\0';
   sptr = PasswordLoCase;
   for (cptr = Password; *cptr; *sptr++ = tolower(*cptr++));
   *sptr = '\0';
   sptr = UserNameUpCase;
   for (cptr = UserName; *cptr; *sptr++ = toupper(*cptr++));
   *sptr = '\0';
   sptr = UserNameLoCase;
   for (cptr = UserName; *cptr; *sptr++ = tolower(*cptr++));
   *sptr = '\0';
   if (VMSok (status =
       DigestA1 (UserNameUpCase, DatabaseName, PasswordUpCase,
                 A1DigestUpCasePtr)))
       status = DigestA1 (UserNameLoCase, DatabaseName, PasswordLoCase,
                          A1DigestLoCasePtr);

   return (status);
}

/*****************************************************************************/
/*
Set string text according to capability vector in the in-memory authorization
information.  These may be different to the bits in the on-disk database,
reported by HTAdminCanString().
*/

char* AuthCanString
(
unsigned long CanFlags,
int Format
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthCanString()\n");

   if ((CanFlags & HTTP_METHOD_DELETE ||
        CanFlags & HTTP_METHOD_POST ||
        CanFlags & HTTP_METHOD_PUT) &&
       CanFlags & HTTP_METHOD_GET)
   {
      if (Format == AUTH_CAN_FORMAT_HTML)
         return ("read <B>+ write</B>");
      else
      if (Format == AUTH_CAN_FORMAT_LONG)
         return ("READ+WRITE");
      else
         return ("R+W");
   }
   else
   if ((CanFlags & HTTP_METHOD_DELETE ||
        CanFlags & HTTP_METHOD_POST ||
        CanFlags & HTTP_METHOD_PUT))
   {
      if (Format == AUTH_CAN_FORMAT_HTML)
         return ("write-only");
      else
      if (Format == AUTH_CAN_FORMAT_LONG)
         return ("WRITE");
      else
         return ("W");
   }
   else
   if (CanFlags & HTTP_METHOD_GET)
   {
      if (Format == AUTH_CAN_FORMAT_HTML)
         return ("read-only");
      else
      if (Format == AUTH_CAN_FORMAT_LONG)
         return ("READ");
      else
         return ("R");
   }
   else
   {
      if (Format == AUTH_CAN_FORMAT_HTML)
         return ("<I>none!</I>");
      else
      if (Format == AUTH_CAN_FORMAT_LONG)
         return ("");
      else
         return ("-");
   }
   return ("*ERROR*");
}

/*****************************************************************************/
/*
*/ 

char* AuthSourceString
(
char *NamePtr,
unsigned long Value
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthSourceString() |%s| %d\n", NamePtr, Value);

   switch (Value)
   {
      case AUTH_SOURCE_AGENT       : return ("=agent");
      case AUTH_SOURCE_EXTERNAL    : return ("");
      case AUTH_SOURCE_FAIL        : return ("*PROBLEM*");
      case AUTH_SOURCE_HTA         : return ("=hta");
      case AUTH_SOURCE_ID          : return ("=id");
      case AUTH_SOURCE_LIST        : return ("=list");
      case AUTH_SOURCE_NONE        : return ("");
      case AUTH_SOURCE_PROMISCUOUS : return ("");
      case AUTH_SOURCE_VMS :
         if (NamePtr != NULL &&
             strsame (NamePtr, AUTH_REALM_VMS, -1)) return ("");
         return ("=vms");
      case AUTH_SOURCE_WASD_ID     : return ("=wasd_id");
      case AUTH_SOURCE_WORLD       : return ("");
      default :
         if (NamePtr != NULL && NamePtr[0]) return ("=?");
         return ("");
   }
}

/*****************************************************************************/

