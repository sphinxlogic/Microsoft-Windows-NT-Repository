/*****************************************************************************/
/*
                               AuthCache.c


    THE GNU GENERAL PUBLIC LICENSE APPLIES DOUBLY TO ANYTHING TO DO WITH
                    AUTHENTICATION AND AUTHORIZATION!

    This package is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License, or any later
    version.

>   This package is distributed in the hope that it will be useful,
>   but WITHOUT ANY WARRANTY; without even the implied warranty of
>   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
>   GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


This modules maintains the authorization/authentication cache for WASD's
authorization environment.  A linked-list, binary tree (using the the
LIB$..._TREE routines) is used to store authentication records.  Records are
searched for and added using LIB$ library functions.

See AUTH.C for overall detail on the WASD authorization environment.


LOGIN COOKIE
------------
Consecutive browser authentication dialogs can occur if a cache entry exists
for the realm/username with a user revalidation timer expired but in the
interim the user has closed the browser and so submits the initial request with
no request header authorization field at all.  This is bounced straight back
and when valid credentials are entered and accessed the cached entry indicates
there need to be revalidation resulting in an immediate browser reprompt for
the same resource ... mighty irritating!

The "login" cookie approach attempts to work around this by returning a cookie
containing a unique, "one-shot" token (in this case a non-deterministically
generated 32 bit number) with the response to all requests that contain no
authorization.  This token is cached on the server and when the next request
(presumably containing the required authorization information) is returned the
cookie is with it, the token is looked up in the cache and if found user
revalidation suppressed.  The cached token is cancelled during this lookup and
so can "never" be used again.

Note that the cookie contains no authorization information itself!
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A request must always also contain the required HTTP authorization header
fields.  The method of generating the token makes spoofing the cookie
improbable, and it is also only valid for the next, single request.  Even if
spoofing could occur it wouldn't authorize anything of itself - the token just
suppresses revalidation of already supplied authentication.  If authentication
presented at the next request is incorrect and refused no new token is issued
and the user would then experience the revalidation-timeout-induced failure
once correct credentials are supplied.


VERSION HISTORY
---------------
07-MAY-2000  MGD  login cookie
08-APR-2000  MGD  bugfix; AuthCacheTreeFree()
04-MAR-2000  MGD  use NetWriteFaol(), et.al.
24-DEC-1999  MGD  break-in evasion period in report
28-AUG-1999  MGD  unbundled from AUTH.C for v6.1
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <descrip.h>
#include <libdef.h>
#include <ssdef.h>
#include <stsdef.h>

/* application related header files */
#include "wasd.h"

#define WASD_MODULE "AUTHCACHE"

#define FI_NOLI WASD_MODULE, __LINE__

/******************/
/* global storage */
/******************/

int  AuthCacheDisplayRecordCount;
     AuthCacheLoginCookieCacheMax,
     AuthCacheLoginCookieCacheNext,
     AuthCacheLoginCookieCount,
     AuthCacheFreeRecordCount,
     AuthCacheRecordCount;

int  AuthCacheLoginCookieCache [AUTH_MAX_COOKIE_CACHE];

unsigned long  AuthCacheTreeBinTime [2];

char  AuthCacheLoginCookieName [] = AUTH_LOGIN_COOKIE_NAME;
int AuthCacheLoginCookieNameLength = sizeof(AuthCacheLoginCookieName)-1;

struct AuthCacheRecordStruct  *AuthCacheLastHitPtr,
                              *AuthCacheTreeHead,
                              *AuthCacheTreeTailPtr;

struct AuthCacheRecordStruct  **AuthCacheTreeFreeArray;

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern int  WatchEnabled;
extern char ServerHostPort [];
extern struct AccountingStruct  Accounting;
extern struct ConfigStruct  Config;
extern struct MsgStruct  Msgs;

/*****************************************************************************/
/*
Add the supplied authorization cache structure to the binary tree.
*/ 

int AuthCacheAddRecord (struct AuthCacheRecordStruct *RecordPtr)

{
   static int  NoDuplicatesFlag = 0;

   int  status;
   struct AuthCacheRecordStruct *InsertedRecordPtr;
   
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthCacheAddRecord()\n");

   status = lib$insert_tree (&AuthCacheTreeHead,
                             RecordPtr,
                             &NoDuplicatesFlag,
                             &AuthCacheTreeCompareRecord,
                             &AuthCacheTreeAllocateRecord,
                             &InsertedRecordPtr, 0);
   if (Debug) fprintf (stdout, "lib$insert_tree() %%X%08.08X\n", status);

   if (VMSok (status))
   {
      AuthCacheRecordCount++;
      if (Debug)
         fprintf (stdout, "AuthCacheRecordCount: %d\n", AuthCacheRecordCount);
   }

   return (status);
}

/*****************************************************************************/
/*
Search for the 'ThisRecordPtr' authorization cache structure in the binary
tree.  If found set the pointer pointed-to by 'FoundRecordPtrPtr' to point to
the appropriate record in the tree.  Improve repeated lookups by caching the
last successfully located record pointer.
*/ 

int AuthCacheFindRecord
(
struct AuthCacheRecordStruct *ThisRecordPtr,
struct AuthCacheRecordStruct **FoundRecordPtrPtr
)
{
   int  status;
   
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthCacheFindRecord()\n");

   if (AuthCacheLastHitPtr != NULL)
   {
      if (!AuthCacheTreeCompareRecord (ThisRecordPtr, AuthCacheLastHitPtr, 0))
      {
         *FoundRecordPtrPtr = AuthCacheLastHitPtr;
         return (SS$_NORMAL);
      }
   }

   status = lib$lookup_tree (&AuthCacheTreeHead,
                             ThisRecordPtr,
                             &AuthCacheTreeCompareRecord,
                             FoundRecordPtrPtr);
   if (Debug) fprintf (stdout, "lib$lookup_tree() %%X%08.08X\n", status);

   if (VMSok (status))
   {
      AuthCacheLastHitPtr = *FoundRecordPtrPtr;
      return (status);
   }
   else
   {
      AuthCacheLastHitPtr = NULL;
      return (status);
   }
}

/*****************************************************************************/
/*
Called by lib$insert_tree() and lib$lookup_tree() in a variety of functions.
Returns negative number if node 1 is lexicographically less than the node 2,
positive if greater, or zero if exactly the same.
*/ 

int AuthCacheTreeCompareRecord
(
struct AuthCacheRecordStruct *acr1ptr,
struct AuthCacheRecordStruct *acr2ptr,
unsigned long Unused
)
{
   register int  cmp;
   
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthCacheTreeCompareRecord()\n");

   if (Debug)
      fprintf (stdout,
"%d %d\n\
%d %d\n\
%d %d\n\
%d |%s| %d |%s|\n\
%d |%s| %d |%s|\n\
%d |%s| %d |%s|\n\
%d |%s| %d |%s|\n\
%d |%s| %d |%s|\n",
      acr1ptr->SourceRealm, acr2ptr->SourceRealm,
      acr1ptr->SourceGroupWrite, acr2ptr->SourceGroupWrite,
      acr1ptr->SourceGroupRead, acr2ptr->SourceGroupRead,
      acr1ptr->RealmLength, acr1ptr->Realm,
      acr2ptr->RealmLength, acr2ptr->Realm,
      acr1ptr->AgentParameterLength, acr1ptr->AgentParameter,
      acr2ptr->AgentParameterLength, acr2ptr->AgentParameter,
      acr1ptr->GroupWriteLength, acr1ptr->GroupWrite,
      acr2ptr->GroupWriteLength, acr2ptr->GroupWrite,
      acr1ptr->GroupReadLength, acr1ptr->GroupRead,
      acr2ptr->GroupReadLength, acr2ptr->GroupRead,
      acr1ptr->UserNameLength, acr1ptr->UserName,
      acr2ptr->UserNameLength, acr2ptr->UserName);

   /* values of source indicators */
   if (cmp = acr1ptr->SourceRealm - acr2ptr->SourceRealm)
      return (cmp);
   if (cmp = acr1ptr->SourceGroupWrite - acr2ptr->SourceGroupWrite)
      return (cmp);
   if (cmp = acr1ptr->SourceGroupRead - acr2ptr->SourceGroupRead)
      return (cmp);

   /* lengths of all strings in the records */
   if (cmp = acr1ptr->RealmLength - acr2ptr->RealmLength)
      return (cmp);
   if (cmp = acr1ptr->AgentParameterLength - acr2ptr->AgentParameterLength)
      return (cmp);
   if (cmp = acr1ptr->GroupWriteLength - acr2ptr->GroupWriteLength)
      return (cmp);
   if (cmp = acr1ptr->GroupReadLength - acr2ptr->GroupReadLength)
      return (cmp);
   if (cmp = acr1ptr->UserNameLength - acr2ptr->UserNameLength)
      return (cmp);

   /* strings */
   if (cmp = strcmp (acr1ptr->Realm, acr2ptr->Realm))
      return (cmp);
   if (cmp = strcmp (acr1ptr->AgentParameter, acr2ptr->AgentParameter))
      return (cmp);
   if (cmp = strcmp (acr1ptr->GroupWrite, acr2ptr->GroupWrite))
      return (cmp);
   if (cmp = strcmp (acr1ptr->GroupRead, acr2ptr->GroupRead))
      return (cmp);
   return (strcmp (acr1ptr->UserName, acr2ptr->UserName));
}

/*****************************************************************************/
/*
Called by lib$insert_tree() in AuthDoAuthorization().  Insert the address
in 'acrptr' into the location pointed at by 'acrptrptr' (inside the binary tree
structure presumably!)
*/ 

AuthCacheTreeAllocateRecord
(
struct AuthCacheRecordStruct *acrptr,
struct AuthCacheRecordStruct **acrptrptr,
unsigned long Unused
)
{
   if (Debug) fprintf (stdout, "AuthCacheTreeAllocateRecord()\n");

   *acrptrptr = acrptr;

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Clear all of the authentication records from the tree.  Will result in all
subsequent requests being re-authenticated from their respective on-disk
databases.  Called from the Admin.c and Control.c modules.
*/

int AuthCacheTreeFree ()

{
   int  status,
        bytes,
        idx;
   struct AuthCacheRecordStruct  **actfptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "AuthCacheTreeFree() %d\n", AuthCacheRecordCount);

   sys$gettim (&AuthCacheTreeBinTime);
   if (!AuthCacheRecordCount) return (SS$_NORMAL);

   /* allocate a temporary array of pointers */
   bytes = sizeof(struct AuthCacheRecordStruct*) * AuthCacheRecordCount;
   actfptr = (struct AuthCacheRecordStruct*)VmGet(bytes);

   AuthCacheFreeRecordCount = 0;
   AuthCacheTreeFreeArray = actfptr;

   status = lib$traverse_tree (&AuthCacheTreeHead,
                               &AuthCacheTreeFreeRecord, 0);
   if (Debug) fprintf (stdout, "lib$traverse_tree() %%X%08.08X\n", status);

   if (AuthCacheFreeRecordCount != AuthCacheRecordCount)
      ErrorExitVmsStatus (SS$_BUGCHECK, "AuthCacheTreeFree()", FI_LI);

   /* free each record */
   for (idx = 0; idx < AuthCacheRecordCount; idx++)
   {
      if (actfptr[idx]->UserDetailsPtr != NULL)
         VmFree (actfptr[idx]->UserDetailsPtr, FI_LI);
      if (actfptr[idx]->VmsUserProfilePtr != NULL)
         VmFree (actfptr[idx]->VmsUserProfilePtr, FI_LI);
       VmFree (actfptr[idx], FI_LI);
   }

   /* now free the temporary array of pointers */
   VmFree (actfptr, FI_LI);

   /* reinitialize the cache */
   AuthCacheLastHitPtr = AuthCacheTreeHead = AuthCacheTreeTailPtr = NULL;
   AuthCacheRecordCount = 0;

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Set a pointer to this record in the 'AuthCacheFreeTreePtr' array of pointers.
Called from AuthCacheTreeFree().
*/

AuthCacheTreeFreeRecord
(                      
struct AuthCacheRecordStruct *acrptr,
unsigned long  Unused
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthCacheTreeFreeRecord()\n");

   if (Debug)
      fprintf (stdout, "AuthCacheRecord |%s|%s|\n",
               acrptr->Realm, acrptr->UserName);

   AuthCacheTreeFreeArray[AuthCacheFreeRecordCount++] = acrptr;

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Traverse the authentication cache tree reseting the password and failure count
for all entries with a matching realm and user name.  This effectively causes
the username to be revalidated next authorized path access.
*/

AuthCacheReset
(
struct RequestStruct *rqptr,
char *DatabaseName,
char *UserName
)
{
   register char  *cptr, *sptr;

   int  status;
   struct AuthHtRecordStruct AuthHtRecord;
   struct AuthCacheRecordStruct  AuthCacheRecord;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthCacheReset()\n");

   /* we know these'll fit, the sizes checked during authentication */
   cptr = DatabaseName;
   sptr = AuthCacheRecord.Realm;
   while (*cptr) *sptr++ = *cptr++;
   *sptr = '\0';
   AuthCacheRecord.RealmLength = sptr - AuthCacheRecord.Realm;

   cptr = UserName;
   sptr = AuthCacheRecord.UserName;
   while (*cptr) *sptr++ = *cptr++;
   *sptr = '\0';
   AuthCacheRecord.UserNameLength = sptr - AuthCacheRecord.UserName;

   status = lib$traverse_tree (&AuthCacheTreeHead,
                               &AuthCacheResetEntry,
                               &AuthCacheRecord);
   if (Debug) fprintf (stdout, "lib$traverse_tree() %%X%08.08X\n", status);

   if (VMSnok (status) && status != LIB$_KEYNOTFOU)
   {
      rqptr->rqResponse.ErrorTextPtr = "lib$traverse_tree()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      return (status);
   }

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Called for each node by lib$traverse_tree() int other functions.  Reset the
password and failure count for each matching realm and username (group is not
checked so may be multiple entries if user has membership of multiple groups
and used those paths).  If realm or username in empty then that is a wildcard
match for that parameter, hence all users in a given realm can be reset, all
realms for a given user, or all users in all realms!
*/ 

int AuthCacheResetEntry
(
struct AuthCacheRecordStruct *TreeNodePtr,
struct AuthCacheRecordStruct *AuthCacheRecordPtr
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "AuthCacheTreeEntryReset() |%s|%s|%s|%s|\n",
               TreeNodePtr->Realm, TreeNodePtr->UserName,
               AuthCacheRecordPtr->Realm, AuthCacheRecordPtr->UserName);

   if (AuthCacheRecordPtr->RealmLength &&
       AuthCacheRecordPtr->RealmLength != TreeNodePtr->RealmLength)
      return (SS$_NORMAL);
   if (AuthCacheRecordPtr->UserNameLength &&
       AuthCacheRecordPtr->UserNameLength != TreeNodePtr->UserNameLength)
      return (SS$_NORMAL);
   if (AuthCacheRecordPtr->RealmLength &&
       strcmp (AuthCacheRecordPtr->Realm, TreeNodePtr->Realm))
      return (SS$_NORMAL);
   if (AuthCacheRecordPtr->UserNameLength &&
       strcmp (AuthCacheRecordPtr->UserName, TreeNodePtr->UserName))
      return (SS$_NORMAL);

   /* realm and username match (or wildcarded) */
   if (Debug) fprintf (stdout, "reset password\n");
   TreeNodePtr->Password[0]  = '\0';
   TreeNodePtr->FailureCount = 0;
   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Display all records in the authentication linked-list, binary tree.  Called
by the Control.c or the Request.c module.  For HTTP report, uses blocking
network write.
*/

AuthCacheTreeReport
(
struct RequestStruct *rqptr,
void *NextTaskFunction
)
{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... User Authentication</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>User Authentication</H3>\n\
!20%W\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Since</TH></TR>\n\
<TR><TD>!20%W</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\\
<TR>\
<TH COLSPAN=2>Realm</TH>\
<TH COLSPAN=2>Group-R+W</TH>\
<TH>Group-R</TH>\
<TH COLSPAN=4>Agent-Param</TH>\
</TR>\n<TR>\
<TH>User</TH><TH>Access</TH>\
<TH COLSPAN=2>Scheme</TH>\
<TH>Most Recent</TH>\
<TH COLSPAN=4>Authenticated</TH>\
</TR>\n<TR>\
<TH COLSPAN=2></TH>\
<TH>Basic</TH><TH>Digest</TH>\
<TH></TH>\
<TH>Cache</TH><TH>Source</TH><TH>Fail</TH><TH>Break-in</TH>\
</TR>\n";

   static char  NoneFao [] =
"<TR ALIGN=CENTER><TD COLSPAN=9><I>(none)</I></TD></TR>\n";

   static char  EndPageFao [] =
"</TABLE>\n\
</BODY>\n\
</HTML>\n";

   register unsigned long  *vecptr;
   int  status;
   unsigned long  FaoVector [32];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthCacheTreeReport()\n");

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;

   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = &rqptr->rqTime.Vms64bit;
   *vecptr++ = &AuthCacheTreeBinTime;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   AuthCacheDisplayRecordCount = 0;
   status = lib$traverse_tree (&AuthCacheTreeHead,
                               &AuthCacheTreeReportRecord,
                               rqptr);
   if (Debug) fprintf (stdout, "lib$traverse_tree() %%X%08.08X\n", status);

   if (!AuthCacheDisplayRecordCount)
   {
      status = NetWriteFaol (rqptr, NoneFao, NULL);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   status = NetWriteFaol (rqptr, EndPageFao, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Called by AuthCacheTreeReport().  Display the details of all records in the
linked-list binary tree.  Output the details via blocking network write.
*/

AuthCacheTreeReportRecord
(                      
struct AuthCacheRecordStruct *acrptr,
struct RequestStruct *rqptr
)
{
   static char  ReportFao [] =
"<TR HEIGHT=1 COLSPAN=7><TD></TD>\
</TR>\n<TR>\
<TD COLSPAN=2>!AZ!AZ</TD>\
<TD COLSPAN=2>!AZ!AZ</TD>\
<TD>!AZ!AZ</TD>\
<TD COLSPAN=4>!AZ</TD>\
</TR>\n<TR>\
<TD>!AZ</TD><TD>!AZ!AZ!AZ</TD>\
<TD ALIGN=right>!UL</TD><TD ALIGN=right>!UL</TD>\
<TD><FONT SIZE=-1>!20%W</FONT></TD>\
<TD ALIGN=right>!UL</TD><TD ALIGN=right>!UL</TD>\
<TD ALIGN=right>!UL</TD><TD ALIGN=right>!AZ!UL!AZ</TD>\
</TR>\n";

   register unsigned long  *vecptr;

   int  status;
   unsigned long  FaoVector [32];
   char  *UserCanStringPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthCacheTreeReportRecord()\n");

   AuthCacheDisplayRecordCount++;

   if ((UserCanStringPtr =
       AuthCanString (acrptr->AuthUserCan, AUTH_CAN_FORMAT_HTML)) == NULL)
      return (STS$K_ERROR);

   vecptr = FaoVector;

   *vecptr++ = acrptr->Realm;
   *vecptr++ = AuthSourceString (acrptr->Realm, acrptr->SourceRealm);
   *vecptr++ = acrptr->GroupWrite;
   *vecptr++ = AuthSourceString (acrptr->GroupWrite, acrptr->SourceGroupWrite);
   *vecptr++ = acrptr->GroupRead;
   *vecptr++ = AuthSourceString (acrptr->GroupRead, acrptr->SourceGroupRead);
   *vecptr++ = acrptr->AgentParameter;

   *vecptr++ = acrptr->UserName;
   *vecptr++ = UserCanStringPtr;
   if (rqptr->rqAuth.VmsUserProfileLength)
      *vecptr++ = " (profile)";
   else
      *vecptr++ = "";
   if (acrptr->HttpsOnly)
      *vecptr++ = " (&quot;https:&quot;&nbsp;only)";
   else
      *vecptr++ = "";

   *vecptr++ = acrptr->BasicCount;
   *vecptr++ = acrptr->DigestCount;
   *vecptr++ = &acrptr->LastAccessBinTime;
   *vecptr++ = acrptr->AccessCount;
   *vecptr++ = acrptr->DataBaseCount;
   if (acrptr->FailureCount < Config.cfAuth.FailureLimit)
   {
      *vecptr++ = acrptr->FailureCount;
      *vecptr++ = "";
      *vecptr++ = 0;
      *vecptr++ = "";
   }
   else
   {
      *vecptr++ = 0;
      *vecptr++ = "<FONT COLOR=\"#ff0000\">";
      *vecptr++ = acrptr->FailureCount;
      *vecptr++ = "</FONT>";
   }

   status = NetWriteFaol (rqptr, ReportFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Set the "login" cookie.  See description at the beginning of the module.
*/

int AuthCacheSetLoginCookie (struct RequestStruct *rqptr)

{
   int  idx,
        TokenNumber;
   unsigned short  Length;
   char  *cptr;
   char  Buffer [256];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthCacheSetLoginCookie()\n");

   /* three bytes of the least-significant time longword plus a count byte */
   TokenNumber = ((int)rqptr->rqTime.Vms64bit[0] & 0xffffff00) |
                    (AuthCacheLoginCookieCount++ & 0x000000ff);

   for (idx = 0; idx <= AuthCacheLoginCookieCacheMax; idx++)
      if (!AuthCacheLoginCookieCache[idx]) break;
   if (idx <= AuthCacheLoginCookieCacheMax)
   {
      /* found a previously used but now empty cache entry */
      AuthCacheLoginCookieCache[idx] = TokenNumber;
   }
   else
   if (AuthCacheLoginCookieCacheMax < AUTH_MAX_COOKIE_CACHE)
   {
      /* the maximum number of entries in the cache have not yet been used */
      AuthCacheLoginCookieCache[AuthCacheLoginCookieCacheMax++] = TokenNumber;
   }
   else
   {
     /* complete cache in use, begin to cycle through using used entries */
     if (AuthCacheLoginCookieCacheNext > AuthCacheLoginCookieCacheMax)
        AuthCacheLoginCookieCacheNext = 0;
     AuthCacheLoginCookieCache[AuthCacheLoginCookieCacheNext++] = TokenNumber;
   }

   WriteFao (Buffer, sizeof(Buffer), &Length, "!AZ=!UL; path=/;",
             AuthCacheLoginCookieName, TokenNumber);

   cptr = VmGetHeap (rqptr, Length+1);
   for (idx = 0; idx < RESPONSE_COOKIE_MAX; idx++)
   {
      if (rqptr->rqResponse.CookiePtr[idx] == NULL)
      {
         memcpy (rqptr->rqResponse.CookiePtr[idx] = cptr, Buffer, Length+1);
         break;
      }
   }

   return (TokenNumber);
}

/*****************************************************************************/
/*
Reset the "login" cookie on the browser.  See description at the beginning of
the module.
*/

AuthCacheResetLoginCookie (struct RequestStruct *rqptr)

{
   int  idx;
   unsigned short  Length;
   char  *cptr;
   char  Buffer [256];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthCacheResetLoginCookie()\n");

   WriteFao (Buffer, sizeof(Buffer), &Length,
             "!AZ=; path=/; expires=Fri, 13 Jan 1978 14:00:00 GMT",
             AuthCacheLoginCookieName);

   cptr = VmGetHeap (rqptr, Length+1);
   for (idx = 0; idx < RESPONSE_COOKIE_MAX; idx++)
   {
      if (rqptr->rqResponse.CookiePtr[idx] == NULL)
      {
         memcpy (rqptr->rqResponse.CookiePtr[idx] = cptr, Buffer, Length+1);
         break;
      }
   }
}

/*****************************************************************************/
/*
Check for the "login" cookie in the request cookie.  If one is found look
through the revalidation cookie cache for the same number.  If found then empty
the entry and return true, otherwise always return false.  See description at
the beginning of the module.
*/

boolean AuthCacheCheckLoginCookie (struct RequestStruct *rqptr)

{
   int  idx,
        TokenNumber;
   char  *cptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AuthCacheCheckLoginCookie()\n");

   if ((cptr = rqptr->rqHeader.CookiePtr) == NULL) return (false);
   if (Debug) fprintf (stdout, "cptr |%s|\n", cptr);
   while (*cptr)
   {
      while (*cptr && *cptr != AuthCacheLoginCookieName[0]) cptr++;
      if (!*cptr) break;
      if (!memcmp (cptr, AuthCacheLoginCookieName,
                         AuthCacheLoginCookieNameLength))
      {
         cptr += AuthCacheLoginCookieNameLength;
         if (*cptr == '=')
         {
            TokenNumber = atoi(cptr+1);
            if (Debug) fprintf (stdout, "TokenNumber: %u\n", TokenNumber);
            if (!TokenNumber) return (false);
            for (idx = 0; idx <= AuthCacheLoginCookieCacheMax; idx++)
               if (AuthCacheLoginCookieCache[idx] == TokenNumber) break;
            if (idx <= AuthCacheLoginCookieCacheMax)
            {
               AuthCacheLoginCookieCache[idx] = 0;
               return (true);
            }
            return (false);
         }
      }
      if (*cptr) cptr++;
   }
   return (false);
}

/*****************************************************************************/

0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  