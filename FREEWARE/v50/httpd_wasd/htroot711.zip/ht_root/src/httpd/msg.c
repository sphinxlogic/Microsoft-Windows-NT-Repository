/*****************************************************************************/
/*
                                  msg.c

Provide a site-configurable message database.  This is particularly directed
towards non-English language sites.  No attempt has been made to completely
internationalize the server, only messages the average client is likely to be
exposed to are currently provided.

The only way of reloading the database is to restart the server. This is not
of great concern for once customized the messages should remain completely
stable between releases.


Current Message Groupings
-------------------------

  [auth]        authentication/authorization
  [dir]         directory listing
  [general]     messages belonging to no particular module or category
  [htadmin]     authentication database administration
  [http]        http status messages
  [ismap]       image mapping module
  [mapping]     mapping rules
  [proxy]       proxy module
  [put]         PUT/POST module
  [request]     request acceptance and initial parsing
  [script]      DCL/scripting module
  [ssi]         Server Side Includes
  [status]      error and other status reporting
  [upd]         update module


VERSION HISTORY
---------------
18-JUN-2000  MGD  add MsgRevise()
08-APR-2000  MGD  HTTP status messages, v7.0
04-MAR-2000  MGD  use WriteFaol(), et.al.
02-JAN-2000  MGD  config file opened via ODS module
04-DEC-1999  MGD  additional messages for v6.1
05-MAY-1999  MGD  proxy messages, v6.0
06-JUL-1998  MGD  bugfix; MsgUnload(), VmFree() of 'HostListPtr'
14-FEB-1998  MGD  message file format changed from v4.4 to v5.0
25-OCT-1997  MGD  changes around MsgFor() when no request structure available
09-AUG-1997  MGD  initial development (HTTPd v4.4)
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <ssdef.h>
#include <stsdef.h>

/* application related header files */
#include "wasd.h"

#define WASD_MODULE "MSG"

/******************/
/* global storage */
/******************/

#define MSG_VERSION "7.0"

char  MsgNotSet [] = "INTERNAL ERROR, please notify the administrator.";

struct MsgDbStruct  MsgDb;

char  ErrorMsgDupLangNumber [] = "duplicate [language] number",
      ErrorMsgDupMsgNumber [] = "duplicate message number",
      ErrorMsgLangDisabled [] = "[language] disabled",
      ErrorMsgLangName [] = "[language] name not specified",
      ErrorMsgLangNotFound [] = "[language] not found",
      ErrorMsgLangNotSpecified [] = "[language] not specified",
      ErrorMsgLangNumber [] = "[language] number out-of-range",
      ErrorMsgLangTooMany [] = "too many [language]s",
      ErrorMsgMessageNumber [] = "message number out-of-range",
      ErrorMsgNoGroup [] = "[group-name] has not been specified",
      ErrorMsgNoLangNumber [] = "no [language] number",
      ErrorMsgNoLangName [] = "no [language] name",
      ErrorMsgNoMessageNumber [] = "no message number",
      ErrorMsgTooFew [] = "too few messages",
      ErrorMsgTooMany [] = "too many messages",
      ErrorMsgUnknownGroup [] = "unknown [group-name]",
      ErrorMsgVersion [] = "message file [version] mismatch",
      ErrorMsgVersionNotChecked [] = "no [version] for checking";

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern char  ServerHostPort[],
             SoftwareID[],
             Utility[],
             ErrorSanityCheck[];

extern struct ConfigStruct Config;

/*****************************************************************************/
/*
Called from HTTPd.c during startup, or when creating a report from the file.
*/

MsgLoad (struct MsgDbStruct *mlptr)

{
   register char  *cptr, *sptr, *zptr;

   boolean  CheckedLanguages,
            DebugBuffer,
            VersionChecked;
   int  status,
        Count,
        LanguageNumber,
        LineCount,
        MessageBase,
        MessageCount,
        MessageMax,
        MessageNumber,
        StartLineNumber;
   char  LanguageName [32],
         Line [4096];
   struct OdsStruct  ConfigFileOds;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MsgLoad()\n");

   MsgUnLoad (mlptr);

   CheckedLanguages = false;
   mlptr->LanguageCount = mlptr->ProblemCount = 
      mlptr->LineNumber = mlptr->ProblemReportLength = 
      LanguageNumber = LineCount = StartLineNumber = MessageCount = 0;
   mlptr->ProblemReportPtr = NULL;
   sys$gettim (&mlptr->LoadBinTime);

   MessageBase = -1;
   VersionChecked = false;

   /*************************/
   /* open the message file */
   /*************************/

   /* use SYSPRV to allow access to possibly protected file */
   EnableSysPrv();
   status = OdsOpenReadOnly (&ConfigFileOds, CONFIG_MSG_FILE_NAME);
   DisableSysPrv();
   if (VMSnok (status))
   {
      if (mlptr->RequestPtr)
      {
         MsgReportProblem (mlptr, CONFIG_MSG_FILE_NAME, status);
         return;
      }
      else
         ErrorExitVmsStatus (status, CONFIG_MSG_FILE_NAME, FI_LI);
   }

   /* get the configuration file revision date and time */
   strcpy (mlptr->LoadFileName, ConfigFileOds.ResFileName);
   memcpy (&mlptr->RevBinTime,
           &ConfigFileOds.XabDat.xab$q_rdt,
           sizeof(mlptr->RevBinTime));

   /*************************/
   /* read the message file */
   /*************************/

#ifdef DBUG
   /* not interested anymore in seeing debug information for message load! */
   DebugBuffer = Debug;
   Debug = false;
#endif

   ConfigFileOds.Rab.rab$l_ubf = Line;
   ConfigFileOds.Rab.rab$w_usz = sizeof(Line)-1;

   while (VMSok (status = sys$get (&ConfigFileOds.Rab, 0, 0)))
   {
      LineCount++;
      if (!StartLineNumber) StartLineNumber = LineCount;
      ConfigFileOds.Rab.rab$l_ubf[ConfigFileOds.Rab.rab$w_rsz] = '\0';
      if (Debug)
         fprintf (stdout, "%d |%s|\n", LineCount, ConfigFileOds.Rab.rab$l_ubf);

      if (ConfigFileOds.Rab.rab$w_rsz)
      {
         if (ConfigFileOds.Rab.rab$l_ubf[ConfigFileOds.Rab.rab$w_rsz-1] == '\\')
         {
            /* line is continued, change backslash into linefeed, get more */
            ConfigFileOds.Rab.rab$l_ubf[ConfigFileOds.Rab.rab$w_rsz-1] = '\n';
            ConfigFileOds.Rab.rab$l_ubf += ConfigFileOds.Rab.rab$w_rsz;
            ConfigFileOds.Rab.rab$w_usz -= ConfigFileOds.Rab.rab$w_rsz;
            continue;
         }
      }
      /* reset the line buffer */
      ConfigFileOds.Rab.rab$l_ubf = Line;
      ConfigFileOds.Rab.rab$w_usz = sizeof(Line)-1;

      mlptr->LineNumber = StartLineNumber;
      mlptr->LinePtr = Line;
      StartLineNumber = 0;
      if (Debug) fprintf (stdout, "Line %d |%s|\n", mlptr->LineNumber, Line);

      if (Line[0] == '#') continue;
      for (cptr = Line; ISLWS(*cptr); cptr++);
      if (!*cptr) continue;

      if (*cptr == '[')
      {
         if (strsame (cptr, "[version]", 9))
         {
            /*************/
            /* [version] */
            /*************/

            cptr += 9;
            while (*cptr && ISLWS(*cptr)) cptr++;
            if (!strsame (cptr, MSG_VERSION, -1))
            {
               if (mlptr->RequestPtr)
               {
                  MsgReportProblem (mlptr, ErrorMsgVersion, 0);
                  break;
               }
               else
                  ErrorExitVmsStatus (0, ErrorMsgVersion, FI_LI);
            }
            VersionChecked = true;
            continue;
         }

         if (strsame (cptr, "[language]", 10))
         {
            /**************/
            /* [language] */
            /**************/

            /* allow for empty [Language] generated by configuration revise */
            for (sptr = cptr+10; *sptr && !isalnum(*sptr); sptr++);
            if (!*sptr) continue;

            mlptr->LanguageCount++;

            if (Debug)
               fprintf (stdout, "mlptr->LanguageCount: %d\n",
                        mlptr->LanguageCount);

            /* check if the number of languages specified exceeds limits */
            if (mlptr->LanguageCount > MAX_LANGUAGES)
            {
               if (mlptr->RequestPtr)
               {
                  MsgReportProblem (mlptr, ErrorMsgLangTooMany, 0);
                  break;
               }
               else
                  ErrorExitVmsStatus (0, ErrorMsgLangTooMany, FI_LI);
            }

            /* step over the [language] and any trailing white-space */
            cptr += 10;
            while (*cptr && ISLWS(*cptr)) cptr++;

            if (!isdigit(*cptr))
            {
               /* no language number (order) has been specified */
               if (mlptr->RequestPtr)
               {
                  MsgReportProblem (mlptr, ErrorMsgNoLangNumber, 0);
                  continue;
               }
               else
                  ErrorExitVmsStatus (0, ErrorMsgNoLangNumber, FI_LI);
            }

            /* language number (order) */
            LanguageNumber = atol (cptr);

            /* check if the number of languages specified exceeds limits */
            if (LanguageNumber < 0 ||
                LanguageNumber > MAX_LANGUAGES)
            {
               if (mlptr->RequestPtr)
               {
                  MsgReportProblem (mlptr, ErrorMsgLangNumber, 0);
                  break;
               }
               else
                  ErrorExitVmsStatus (0, ErrorMsgLangNumber, FI_LI);
            }

            for (Count = 1; Count <= MAX_LANGUAGES; Count++)
            {
               if (mlptr->Msgs[Count] == NULL) continue;
               if (mlptr->Msgs[Count]->LanguageNumber == LanguageNumber)
               {
                  if (mlptr->RequestPtr)
                  {
                     MsgReportProblem (mlptr, ErrorMsgDupLangNumber, 0);
                     break;
                  }
                  else
                     ErrorExitVmsStatus (0, ErrorMsgDupLangNumber, FI_LI);
               }
            }

            /* allocate memory for this new language */
            mlptr->Msgs[LanguageNumber] = (struct MsgStruct*)
               VmGet (sizeof(struct MsgStruct));

            /* set all the messages in the language to NULL */
            for (Count = 0; Count <= MSG_RANGE; Count++)
               mlptr->Msgs[LanguageNumber]->TextPtr[Count] = NULL;

            /* set the language number */
            mlptr->Msgs[LanguageNumber]->LanguageNumber = LanguageNumber;

            /* get the language name */
            while (*cptr && !ISLWS(*cptr)) cptr++;
            while (*cptr && ISLWS(*cptr)) cptr++;
            if (!*cptr)
            {
               if (mlptr->RequestPtr)
               {
                  MsgReportProblem (mlptr, ErrorMsgNoLangName, 0);
                  continue;
               }
               else
                  ErrorExitVmsStatus (0, ErrorMsgNoLangName, FI_LI);
            }
            zptr = (sptr = mlptr->Msgs[LanguageNumber]->LanguageName) +
                   sizeof(mlptr->Msgs[LanguageNumber]->LanguageName);
            while (*cptr && !ISLWS(*cptr) && sptr < zptr) *sptr++ = *cptr++;
            if (sptr > zptr) sptr--;
            *sptr = '\0';

            /* skip any white space and look for an optional host list */
            while (*cptr && ISLWS(*cptr)) cptr++;
            if (*cptr)
            {
               /* host list found */
               sptr = cptr;
               while (*cptr) cptr++;
               /* trim trailing white-space */
               if (cptr > sptr) cptr--;
               while (cptr > sptr && ISLWS(*cptr)) cptr--;
               if (cptr > sptr) cptr++;
               *cptr++ = '\0';

               /* allocate memory for the host list */
               zptr = mlptr->Msgs[LanguageNumber]->HostListPtr =
                  VmGet (cptr-sptr);

               memcpy (zptr, sptr, cptr-sptr);
            }

            if (mlptr->Msgs[LanguageNumber]->LanguageNumber == 0)
               MsgReportProblem (mlptr, ErrorMsgLangDisabled, 0);

            if (Debug)
               fprintf (stdout, "%d |%s|%s|\n",
                        mlptr->Msgs[LanguageNumber]->LanguageNumber,
                        mlptr->Msgs[LanguageNumber]->LanguageName,
                        mlptr->Msgs[LanguageNumber]->HostListPtr);
            continue;
         }

         /****************************/
         /* check language numbering */
         /****************************/

         if (!CheckedLanguages)
         {
            CheckedLanguages = true;
            for (Count = 1; Count <= mlptr->LanguageCount; Count++)
            {
               if (mlptr->Msgs[Count]->LanguageNumber < 0 ||
                   mlptr->Msgs[Count]->LanguageNumber > mlptr->LanguageCount)
               {
                  if (mlptr->RequestPtr)
                  {
                     MsgReportProblem (mlptr, ErrorMsgLangNumber, 0);
                     break;
                  }
                  else
                     ErrorExitVmsStatus (0, ErrorMsgLangNumber, FI_LI);
               }
            }
         }

         /****************/
         /* [group-name] */
         /****************/

         /* the '\b' backspace is a sentinal, will never occur in a message */
         if (strsame (cptr, "[auth]", 6))
         {
            MessageBase = MSG_AUTH__BASE;
            MessageMax = MSG_AUTH__MAX;
            mlptr->Msgs[1]->TextPtr[MessageBase] = "\b[auth]";
         }
         else
         if (strsame (cptr, "[dir]", 6))
         {
            MessageBase = MSG_DIR__BASE;
            MessageMax = MSG_DIR__MAX;
            mlptr->Msgs[1]->TextPtr[MessageBase] = "\b[dir]";
         }
         else
         if (strsame (cptr, "[general]", 9))
         {
            MessageBase = MSG_GENERAL__BASE;
            MessageMax = MSG_GENERAL__MAX;
            mlptr->Msgs[1]->TextPtr[MessageBase] = "\b[general]";
         }
         else
         if (strsame (cptr, "[htadmin]", 9))
         {
            MessageBase = MSG_HTADMIN__BASE;
            MessageMax = MSG_HTADMIN__MAX;
            mlptr->Msgs[1]->TextPtr[MessageBase] = "\b[htadmin]";
         }
         else
         if (strsame (cptr, "[http]", 6))
         {
            MessageBase = MSG_HTTP__BASE;
            MessageMax = MSG_HTTP__MAX;
            mlptr->Msgs[1]->TextPtr[MessageBase] = "\b[http]";
         }
         else
         if (strsame (cptr, "[ismap]", 7))
         {
            MessageBase = MSG_ISMAP__BASE;
            MessageMax = MSG_ISMAP__MAX;
            mlptr->Msgs[1]->TextPtr[MessageBase] = "\b[ismap]";
         }
         else
         if (strsame (cptr, "[mapping]", 9))
         {
            MessageBase = MSG_MAPPING__BASE;
            MessageMax = MSG_MAPPING__MAX;
            mlptr->Msgs[1]->TextPtr[MessageBase] = "\b[mapping]";
         }
         else
         if (strsame (cptr, "[proxy]", 7))
         {
            MessageBase = MSG_PROXY__BASE;
            MessageMax = MSG_PROXY__MAX;
            mlptr->Msgs[1]->TextPtr[MessageBase] = "\b[proxy]";
         }
         else
         if (strsame (cptr, "[put]", 5))
         {
            MessageBase = MSG_PUT__BASE;
            MessageMax = MSG_PUT__MAX;
            mlptr->Msgs[1]->TextPtr[MessageBase] = "\b[put]";
         }
         else
         if (strsame (cptr, "[request]", 9))
         {
            MessageBase = MSG_REQUEST__BASE;
            MessageMax = MSG_REQUEST__MAX;
            mlptr->Msgs[1]->TextPtr[MessageBase] = "\b[request]";
         }
         else
         if (strsame (cptr, "[script]", 8))
         {
            MessageBase = MSG_SCRIPT__BASE;
            MessageMax = MSG_SCRIPT__MAX;
            mlptr->Msgs[1]->TextPtr[MessageBase] = "\b[script]";
         }
         else
         if (strsame (cptr, "[ssi]", 5))
         {
            MessageBase = MSG_SSI__BASE;
            MessageMax = MSG_SSI__MAX;
            mlptr->Msgs[1]->TextPtr[MessageBase] = "\b[ssi]";
         }
         else
         if (strsame (cptr, "[status]", 8))
         {
            MessageBase = MSG_STATUS__BASE;
            MessageMax = MSG_STATUS__MAX;
            mlptr->Msgs[1]->TextPtr[MessageBase] = "\b[status]";
         }
         else
         if (strsame (cptr, "[upd]", 5))
         {
            MessageBase = MSG_UPD__BASE;
            MessageMax = MSG_UPD__MAX;
            mlptr->Msgs[1]->TextPtr[MessageBase] = "\b[upd]";
         }
         else
         {
            MessageBase = -1;
            MsgReportProblem (mlptr, ErrorMsgUnknownGroup, 0);
         }

         continue;
      }

      /***********/
      /* message */
      /***********/

      if (!VersionChecked)
      {
         if (mlptr->RequestPtr)
         {
            MsgReportProblem (mlptr, ErrorMsgVersionNotChecked, 0);
            break;
         }
         else
            ErrorExitVmsStatus (0, ErrorMsgVersionNotChecked, FI_LI);
      }

      if (!mlptr->LanguageCount)
      {
         if (mlptr->RequestPtr)
         {
            MsgReportProblem (mlptr, ErrorMsgLangNotSpecified, 0);
            break;
         }
         else
            ErrorExitVmsStatus (0, ErrorMsgLangNotSpecified, FI_LI);
      }

      if (MessageBase < 0)
      {
         /* before any [goup-name] has been specified */
         MsgReportProblem (mlptr, ErrorMsgNoGroup, 0);
         continue;
      }

      if (!isalpha(*cptr))
      {
         /* language name is not being specified at start of line */
         MsgReportProblem (mlptr, ErrorMsgNoLangName, 0);
         continue;
      }

      zptr = (sptr = LanguageName) + sizeof(LanguageName);
      while (*cptr && !ISLWS(*cptr) && sptr < zptr) *sptr++ = *cptr++;
      if (sptr > zptr) sptr--;
      *sptr = '\0';
      /* find the index for the specified language */
      for (Count = 1; Count <= mlptr->LanguageCount; Count++)
      {
         if (Debug)
            fprintf (stdout, "%d |%s|%s|\n",
               Count, LanguageName,
               mlptr->Msgs[mlptr->LanguageCount]->LanguageName);
         if (strsame (LanguageName, mlptr->Msgs[Count]->LanguageName, -1))
         {
             LanguageNumber = Count;
             break;
         }
      }
      if (Count > mlptr->LanguageCount)
      {
         MsgReportProblem (mlptr, ErrorMsgLangNotFound, 0);
         continue;
      }

      while (*cptr && !ISLWS(*cptr)) cptr++;
      while (*cptr && ISLWS(*cptr)) cptr++;

      if (!isdigit(*cptr))
      {
         /* no message number has been specified */
         MsgReportProblem (mlptr, ErrorMsgNoMessageNumber, 0);
         continue;
      }

      MessageNumber = atol(cptr);
      if (Debug) fprintf (stdout, "MessageNumber: %d\n", MessageNumber);

      /* zero disables a message or whole language */
      if (!MessageNumber || !mlptr->Msgs[LanguageNumber]->LanguageNumber)
         continue;

      if (MessageNumber < 0 || MessageNumber > MessageMax)
      {
         MsgReportProblem (mlptr, ErrorMsgMessageNumber, 0);
         continue;
      }

      MessageNumber += MessageBase;
      if (Debug) fprintf (stdout, "Number+Base: %d\n", MessageNumber);

      while (*cptr && !ISLWS(*cptr)) cptr++;
      while (*cptr && ISLWS(*cptr)) cptr++;

      /* empty message (from configuration load) */
      if (*cptr == '\0') continue;

      /* deliberately empty message */
      if (*(unsigned short*)cptr == '#\0') cptr++;

      if (mlptr->Msgs[LanguageNumber]->TextPtr[MessageNumber] == NULL)
      {
         mlptr->Msgs[LanguageNumber]->TextPtr[MessageNumber] = MsgCreate (cptr);
         if (LanguageNumber == mlptr->LanguageCount) MessageCount++;
      }
      else
         MsgReportProblem (mlptr, ErrorMsgDupMsgNumber, 0);
   }

   if (Debug) fprintf (stdout, "%d of %d\n", MessageCount, MSG_TOTAL);

#ifdef DBUG
   Debug = DebugBuffer;
#endif

   /**************************/
   /* close the message file */
   /**************************/

   sys$close (&ConfigFileOds.Fab, 0, 0); 

   if (status == RMS$_EOF) status = SS$_NORMAL;
   if (VMSnok (status))
   {
      if (mlptr->RequestPtr)
      {
         MsgReportProblem (mlptr, CONFIG_MSG_FILE_NAME, status);
         return;
      }
      else
         ErrorExitVmsStatus (status, CONFIG_MSG_FILE_NAME, FI_LI);
   }

   if (MessageCount < MSG_TOTAL)
   {
      if (mlptr->RequestPtr)
         MsgReportProblem (mlptr, ErrorMsgTooFew, 0);
      else
         ErrorExitVmsStatus (0, ErrorMsgTooFew, FI_LI);
   }
   else
   if (MessageCount > MSG_TOTAL)
   {
      /* technically, this shouldn't be possible! */
      if (mlptr->RequestPtr)
         MsgReportProblem (mlptr, ErrorMsgTooMany, 0);
      else
         ErrorExitVmsStatus (0, ErrorMsgTooMany, FI_LI);
   }

   mlptr->LanguageDefault = mlptr->LanguageCount;
}

/*****************************************************************************/
/*
Deallocate all memory used in this message database.
*/

MsgUnLoad (struct MsgDbStruct *mlptr)

{
   int  Count,
        LanguageCount;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MsgUnLoad()\n");

   for (LanguageCount = 1;
        LanguageCount <= mlptr->LanguageCount;
        LanguageCount++)
   {
      if (mlptr->Msgs[LanguageCount] != NULL)
      {
         for (Count = 0; Count <= MSG_RANGE; Count++)
         {
            /* the '\b' backspace is a sentinal, will never occur in a message */
            if (mlptr->Msgs[LanguageCount]->TextPtr[Count] != NULL &&
                *((unsigned short*)(mlptr->Msgs[LanguageCount]->TextPtr[Count])) != '\b[')
            {
               /* remember that MsgCreate() returns allocation plus one! */
               VmFree (mlptr->Msgs[LanguageCount]->TextPtr[Count]-1, FI_LI);
            }
         }

         if (mlptr->Msgs[LanguageCount]->HostListPtr != NULL)
            VmFree (mlptr->Msgs[LanguageCount]->HostListPtr, FI_LI);

         VmFree (mlptr->Msgs[LanguageCount], FI_LI);
      }
   }

   /* clean it out completely, just in case it's to be reused! */
   memset (mlptr, 0, sizeof(struct MsgDbStruct));
}

/*****************************************************************************/
/*
Allocate dynamic memory for the text of the message, copy it into it and
return a pointer to it.  The MapUrl.c module (for horrible, historical reasons)
requires a leading null character before the message.  Fudge this by creating
a one character longer string with that leading null and returning a pointer to
the first character.  The MapUrl.c module will the just use the returned
pointer minus one! (Neat huh?  Well it works anyway!)
*/

char* MsgCreate (char *Text)

{
   char  *MsgPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MsgCreate() |%s|\n", Text);

   MsgPtr = VmGet (strlen(Text)+2);
   *MsgPtr = '\0';
   strcpy (MsgPtr+1, Text);
   return (MsgPtr+1);
}

/*****************************************************************************/
/*
This function formats an error report.  All lines are concatenated onto a
single string of dynamically allocated memory that (obviously) grows as
reports are added to it.  This string is then output if loading the server
configuration or is available for inclusion in an HTML page.
*/

MsgReportProblem
(
struct MsgDbStruct *mlptr,
char *Explanation,
int StatusValue
)
{
   static $DESCRIPTOR (ExplanationFaoDsc,
          "%HTTPD-W-MSG, !AZ at line !UL\n");
   static $DESCRIPTOR (ExplanationLineFaoDsc,
          "%HTTPD-W-MSG, !AZ at line !UL\n \\!AZ\\\n");

   int  status;
   unsigned short  Length;
   char  Buffer [256];
   $DESCRIPTOR (BufferDsc, Buffer);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MsgReportProblem()\n");

   mlptr->ProblemCount++;

   if (StatusValue)
   {
      if (VMSok (status = sys$getmsg (StatusValue, &Length, &BufferDsc, 0)))
         Buffer[Length++] = '\n';
   }
   else
   if (mlptr->LinePtr[0])
      status = sys$fao (&ExplanationLineFaoDsc, &Length, &BufferDsc,
                        Explanation, mlptr->LineNumber, mlptr->LinePtr);
   else
      status = sys$fao (&ExplanationFaoDsc, &Length, &BufferDsc,
                        Explanation, mlptr->LineNumber);
   if (VMSnok (status))
      ErrorExitVmsStatus (status, "sys$fao()", FI_LI);
   else
      Buffer[Length] = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", Buffer);

   if (mlptr->RequestPtr == NULL) fputs (Buffer, stdout);

   mlptr->ProblemReportPtr =
      VmRealloc (mlptr->ProblemReportPtr,
                 mlptr->ProblemReportLength+Length+1, FI_LI);
   /* include the terminating null */
   memcpy (mlptr->ProblemReportPtr+mlptr->ProblemReportLength,
           Buffer, Length+1);
   mlptr->ProblemReportLength += Length;
}

/*****************************************************************************/
/*
Wraps a call to MsgFor() when there is no request structure.  Must initialize
all request structure fields accessed in MsgFor() and MsgInHostList() to some
reasonable value.  All others can be ignored.
*/

char* MsgForNoRequest
(
char *ClientHostName,
char *ClientIpAddressString,
int Message
)
{
   struct RequestStruct  BogusRequestStruct;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "MsgForNoRequest() |%s|%s|%d|\n",
               ClientHostName, ClientIpAddressString, Message);

   BogusRequestStruct.MsgLanguage = 0;
   BogusRequestStruct.rqHeader.AcceptLangPtr = NULL;
   strcpy (BogusRequestStruct.rqNet.ClientHostName, ClientHostName);
   strcpy (BogusRequestStruct.rqNet.ClientIpAddressString,
           ClientIpAddressString);

   return (MsgFor (&BogusRequestStruct, Message));
}

/*****************************************************************************/
/*
Return a pointer to a character string for the message number supplied in
'Message'.  If multiple languages are in use then use any supplied client list
of accepted languages ("Accept-Language:" request header field) to see if the
message can be supplied in a prefered language.  If none supplied or if none
match then check if the language has geographical information against it (a
list of host/domain specifications that can be used to determine if a specific
language would be more appropriate.  If none of the "hit" then return the
configuration-prefered language.
*/

char* MsgFor
(
struct RequestStruct *rqptr,
int Message
)
{
   int  Count,
        Language;
   char  *cptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MsgFor() |%d|%d|\n", rqptr, Message);

   if (rqptr == NULL)
   {
      /* no request structure, use the default language */
      Language = MsgDb.LanguageDefault;
   }
   else
   if (rqptr->MsgLanguage)
   {
      /* request message language has previously been set */
      Language = rqptr->MsgLanguage;
   }
   else
   if (MsgDb.LanguageCount == 1)
   {
      /* only one language in use, use it! */
      Language = rqptr->MsgLanguage = MsgDb.LanguageDefault;
   }
   else
   {
      if (rqptr->rqHeader.AcceptLangPtr != NULL)
      {
         /*******************************************/
         /* look for the client's prefered language */
         /*******************************************/

         register char  *sptr, *lptr;
         int  Count;

         lptr = rqptr->rqHeader.AcceptLangPtr;
         while (*lptr)
         {
            for (Count = 1; Count <= MsgDb.LanguageCount; Count++)
            {
               if (Debug)
                  fprintf (stdout, "%d |%s|%s|\n",
                           Count, lptr, MsgDb.Msgs[Count]->LanguageName);

               cptr = lptr;
               sptr = MsgDb.Msgs[Count]->LanguageName;
               while (toupper(*cptr) == toupper(*sptr) &&
                      *cptr != ',' && !ISLWS(*cptr))
               {
                  cptr++;
                  sptr++;
               }
               if (!*sptr && (!*cptr || *cptr == ',' || ISLWS(*cptr)))
               {
                  Language = rqptr->MsgLanguage =
                     MsgDb.Msgs[Count]->LanguageNumber;
                  break;
               }
            }
            if (rqptr->MsgLanguage) break;
            while (*lptr && *lptr != ',' && !ISLWS(*lptr)) lptr++;
            while (*lptr && (*lptr == ',' || ISLWS(*lptr))) lptr++;
         }
      }

      if (!rqptr->MsgLanguage)
      {
         /************************/
         /* look for a host list */
         /************************/

         for (Count = 1; Count <= MsgDb.LanguageCount; Count++)
         {
            if (Debug)
               fprintf (stdout, "%d |%s|\n",
                        Count, MsgDb.Msgs[Count]->LanguageName);

            if (MsgDb.Msgs[Count]->HostListPtr != NULL)
            {
               if (MsgInHostList (rqptr, MsgDb.Msgs[Count]->HostListPtr))
               {
                  Language = rqptr->MsgLanguage =
                     MsgDb.Msgs[Count]->LanguageNumber;
                  break;
               }
            }
         }
      }

      /* if none matching then fall back to the default language */
      if (!rqptr->MsgLanguage)
         Language = rqptr->MsgLanguage = MsgDb.LanguageDefault;
   }

   if (Debug) fprintf (stdout, "Language: %d\n", Language);

   if (Message <= 0 || Message > MSG_RANGE ||
       Language < 1 || Language > MsgDb.LanguageCount)
      ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);

   /*******************/
   /* get the message */
   /*******************/

   /* if a message has been assigned then return it */
   if ((cptr = MsgDb.Msgs[Language]->TextPtr[Message]) != NULL)
   {
      if (Debug) fprintf (stdout, "|%s|\n", cptr);
      return (cptr);
   }

   /*********************************/
   /* fallback to the base language */
   /*********************************/

   if ((cptr = MsgDb.Msgs[MsgDb.LanguageCount]->TextPtr[Message]) != NULL)
   {
      if (Debug) fprintf (stdout, "|%s|\n", cptr);
      return (cptr);
   }

   /**************************************/
   /* no message was set for this event! */
   /**************************************/

   if (Debug) fprintf (stdout, "|%s|\n", MsgNotSet);
   return (MsgNotSet);
}

/*****************************************************************************/
/*
If the client's IP host name or address matches the wildcard string in
'HostList' then return true, else return false.
*/ 

boolean MsgInHostList
(
struct RequestStruct *rqptr,
char *HostList
)
{
   register char  c;
   register char  *cptr, *hptr, *sptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "MsgInHostList() |%s|%s|%s|\n",
               rqptr->rqNet.ClientHostName, rqptr->rqNet.ClientIpAddressString, HostList);

   hptr = HostList;
   while (*hptr)
   {
      while (*hptr && (*hptr == ',' || ISLWS(*hptr))) hptr++;
      sptr = hptr;
      while (*hptr && *hptr != ',' && !ISLWS(*hptr)) hptr++;
      c = *hptr;
      *hptr = '\0';
      /* match against host address or name */
      if (isdigit(*sptr))
         cptr = rqptr->rqNet.ClientIpAddressString;
      else
         cptr = rqptr->rqNet.ClientHostName;
      if (Debug) fprintf (stdout, "|%s|%s|\n", cptr, sptr);
      if (SearchTextString (cptr, sptr, false, false, NULL) != NULL)
      {
         *hptr = c;
         return (true);
      }
      *hptr = c;
      if (*hptr) hptr++;
   }

   return (false);
}                             

/*****************************************************************************/
/*
A server administration report on the message database.  This function just
wraps the reporting function, loading a temporary database if necessary for
reporting from the configuration file.
*/ 

MsgReport
(
struct RequestStruct *rqptr,
void *NextTaskFunction,
boolean UseServerDatabase
)
{
   int  status;
   struct  MsgDbStruct  LocalMsgDb;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MsgReport()\n");

   if (UseServerDatabase)
      MsgReportNow (rqptr, &MsgDb);
   else
   {
      /* ensure it's an empty database! */
      memset (&LocalMsgDb, 0, sizeof(struct MsgDbStruct));
      /* indicate it's being used for a report */
      LocalMsgDb.RequestPtr = rqptr;
      MsgLoad (&LocalMsgDb);
      MsgReportNow (rqptr, &LocalMsgDb);
      MsgUnLoad (&LocalMsgDb);
      if (LocalMsgDb.ProblemReportPtr != NULL)
         VmFree (LocalMsgDb.ProblemReportPtr, FI_LI);
   }

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
A server administration report on the message database.
*/ 

MsgReportNow
(
struct RequestStruct *rqptr,
struct MsgDbStruct *mlptr
)
{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Server Messages</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Server Messages</H3>\n\
!20%W\n";

   static char  ProblemReportFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH><FONT COLOR=\"#ff0000\">!UL Report!%s \
!%?At Startup\rDuring Load\r</FONT></TH></TR>\n\
<TR><TD><PRE>!HZ</PRE></TD></TR>\n\
</TABLE>\n";

   static char  MessageLoadFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Source: &quot;!%?Server\rFile\r&quot;</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR>\
<TH ALIGN=right>File:</TH>\
<TD ALIGN=left>!AZ</TD>\
<TD>&nbsp;</TD><TH>[<A HREF=\"!AZ\">View</A>]</TH>\
<TH>[<A HREF=\"!AZ!AZ\">Edit</A>]</TH>\
</TR>\n\
<TR><TH ALIGN=right>!AZ</TH>\
<TD ALIGN=left>!20%W</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n";

   static char  LanguageTable [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH COLSPAN=3>Languages</TH></TR>\n\
<TR><TH>Order</TH><TH>Language</TH><TH>Host List</TH></TR>\n";

   static char  EndLanguageTable [] = "</TABLE>\n";

   static char  OneLanguageFao [] =
"<TR><TD>!UL</TD><TD>!AZ</TD><TD>!AZ</TD></TR>\n";

   static char  GroupFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH COLSPAN=3><FONT SIZE=+1>!AZ</FONT></TH></TR>\n\
<TR><TH>Number</TH><TH>Language</TH><TH>Text</TH></TR>\n";

   static char  MessageFao [] =
"<TR>!%%<TD VALIGN=top>!HZ</TD><TD>!%%</TD></TR>\n";
   
   char  EndOfGroup [] = "</TABLE>";

   char  MessagesNotLoaded [] =
"<P><FONT SIZE=+1 COLOR=\"#ff0000\">No messages could be loaded!</FONT>\n\
</BODY>\n\
</HTML>\n";

   char  EndOfPage [] =
"</TABLE>\n\
</BODY>\n\
</HTML>\n";

   register char  *cptr;
   register unsigned long  *vecptr;

   boolean  MultipleLines;
   int  status,
        GroupCount,
        Count,
        Language,
        MessageCount,
        RowCount;
   unsigned long  FaoVector [32];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MsgReportNow()\n");

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;

   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = &rqptr->rqTime.Vms64bit;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   if (mlptr->ProblemReportLength)
   {
      vecptr = FaoVector;
      *vecptr++ = mlptr->ProblemCount;
      *vecptr++ = (mlptr == &MsgDb);
      *vecptr = mlptr->ProblemReportPtr;

      status = NetWriteFaol (rqptr, ProblemReportFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   cptr = MapVmsPath (mlptr->LoadFileName, rqptr);

   vecptr = FaoVector;

   /* source information (i.e. from executing server or static file) */
   *vecptr++ = (mlptr == &MsgDb);
   *vecptr++ = mlptr->LoadFileName;
   *vecptr++ = cptr;
   *vecptr++ = ADMIN_SCRIPT_UPD;
   *vecptr++ = cptr;

   if (mlptr == &MsgDb)
   {
      *vecptr++ = "Loaded:";
      *vecptr++ = &mlptr->LoadBinTime;
   }
   else
   {
      *vecptr++ = "Revised:";
      *vecptr++ = &mlptr->RevBinTime;
   }

   status = NetWriteFaol (rqptr, MessageLoadFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   if (!mlptr->LanguageCount)
   {
      status = NetWriteFaol (rqptr, MessagesNotLoaded, NULL);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      rqptr->rqResponse.HttpStatus = 200;
      return;
   }

   /********************/
   /* language summary */
   /********************/

   status = NetWriteFaol (rqptr, LanguageTable, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   for (Count = 1; Count <= mlptr->LanguageCount; Count++)
   {
      vecptr = FaoVector;
      *vecptr++ = Count;
      *vecptr++ = mlptr->Msgs[Count]->LanguageName;
      if (mlptr->Msgs[Count]->HostListPtr != NULL)
         *vecptr++ = mlptr->Msgs[Count]->HostListPtr;
      else
         *vecptr++ = "";

      status = NetWriteFaol (rqptr, OneLanguageFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   status = NetWriteFaol (rqptr, EndLanguageTable, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /*****************************/
   /* loop through all messages */
   /*****************************/

   Count = GroupCount = 0;

   for (Count = 0; Count < MSG_RANGE; Count++)
   {
      if (mlptr->Msgs[1]->TextPtr[Count] != NULL)
      {
         /* the '\b' backspace is a sentinal, will never occur in a message */
         if (*((unsigned short*)(mlptr->Msgs[1]->TextPtr[Count])) == '\b[')
         {
            if (GroupCount++)
            {
               status = NetWriteFaol (rqptr, EndOfGroup, NULL);
               if (VMSnok (status))
                  ErrorNoticed (status, "NetWriteFaol()", FI_LI);
            }

            vecptr = FaoVector;
            *vecptr++ = mlptr->Msgs[1]->TextPtr[Count]+1;

            status = NetWriteFaol (rqptr, GroupFao, &FaoVector);
            if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

            Count++;
            MessageCount = 0;
         }
      }

      RowCount = 0;
      for (Language = 1; Language <= mlptr->LanguageCount; Language++)
         if (mlptr->Msgs[Language]->TextPtr[Count] != NULL) RowCount++;

      for (Language = 1; Language <= mlptr->LanguageCount; Language++)
      {
         if (Debug) fprintf (stdout, "Language: %d\n", Language);
         if (mlptr->Msgs[Language]->TextPtr[Count] == NULL) continue;

         /* '*cptr' will not be a pointer to a null character if linefeeds */
         for (cptr = mlptr->Msgs[Language]->TextPtr[Count];
              *cptr && *cptr != '\n';
              cptr++);
         if (*cptr)
            MultipleLines = true;
         else
            MultipleLines = false;

         vecptr = FaoVector;

         if (RowCount > 1)
         {
            *vecptr++ = "<TD VALIGN=top ROWSPAN=!UL>!2ZL</TD>";
            *vecptr++ = RowCount;
            *vecptr++ = ++MessageCount;
            RowCount = 0;
         }
         else
         if (RowCount == 1)
         {
            *vecptr++ = "<TD VALIGN=top>!2ZL</TD>";
            *vecptr++ = ++MessageCount;
         }
         else
            *vecptr++ = "";

         *vecptr++ = mlptr->Msgs[Language]->LanguageName;
         if (MultipleLines)
            *vecptr++ = "<PRE>!HZ</PRE>";
         else
            *vecptr++ = "<TT>!HZ</TT>";
         *vecptr++ = mlptr->Msgs[Language]->TextPtr[Count];

         status = NetWriteFaol (rqptr, MessageFao, &FaoVector);
         if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      }
   }

   /**************/
   /* end report */
   /**************/

   status = NetWriteFaol (rqptr, EndOfPage, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
}

/*****************************************************************************/
/*
A server administration revision on the message database.  This function just
wraps the revise function, loading a temporary database if necessary from the
configuration file.
*/ 

MsgRevise
(
struct RequestStruct *rqptr,
void *NextTaskFunction,
boolean UseServerDatabase
)
{
   int  status;
   struct  MsgDbStruct  LocalMsgDb;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MsgRevise()\n");

   if (UseServerDatabase)
      MsgReviseNow (rqptr, &MsgDb);
   else
   {
      /* ensure it's an empty database! */
      memset (&LocalMsgDb, 0, sizeof(struct MsgDbStruct));
      /* indicate it's being used for a report */
      LocalMsgDb.RequestPtr = rqptr;
      MsgLoad (&LocalMsgDb);
      MsgReviseNow (rqptr, &LocalMsgDb);
      MsgUnLoad (&LocalMsgDb);
      if (LocalMsgDb.ProblemReportPtr != NULL)
         VmFree (LocalMsgDb.ProblemReportPtr, FI_LI);
   }

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
A server administration revision for the message database.
*/ 

MsgReviseNow
(
struct RequestStruct *rqptr,
struct MsgDbStruct *mlptr
)
{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Server Messages</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Server Messages</H3>\n\
!20%W\n";

   static char  ProblemReportFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH><FONT COLOR=\"#ff0000\">!UL Report!%s \
!%?At Startup\rDuring Load\r</FONT></TH></TR>\n\
<TR><TD><PRE>!HZ</PRE></TD></TR>\n\
</TABLE>\n";

   static char  MessageLoadFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Source: &quot;!%?Server\rFile\r&quot;</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR>\
<TH ALIGN=right>File:</TH>\
<TD ALIGN=left>!AZ</TD>\
<TD>&nbsp;</TD><TH>[<A HREF=\"!AZ\">View</A>]</TH>\
<TH>[<A HREF=\"!AZ!AZ\">Edit</A>]</TH>\
</TR>\n\
<TR><TH ALIGN=right>!AZ</TH>\
<TD ALIGN=left>!20%W</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
<FORM METHOD=POST ACTION=\"!AZ\">\n\
\
<INPUT TYPE=hidden NAME=x VALUE=\"\
# Configuration:  !AZ&#10;\
#                 !AZ&#10;\
# Last Modified:  !20%W&#10;\
#                 !AZ.\'!AZ\'@!AZ&#10;\
\">";

   static char  LanguageTable [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Languages</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=left><U>Order</U></TH>\
<TH ALIGN=left><U>Language</U></TH>\
<TH ALIGN=left><U>Host List</U></TH></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[Version]  !AZ\">\n";

   static char  EndLanguageTable [] =
"<TR><TD COLSPAN=3>\n\
<FONT COLOR=\"#ff0000\"><B>IMPORTANT:</B>&nbsp;\n\
<I>The primary language (that with <U>all</U> message texts complete \
- usually &quot;en&quot;) must be the <U>highest numbered</U> (order) \
language.\n\
Failure to ensure this will render the server unable to start!!</I>\n\
</FONT>\n\
</TD></TR>\n\
</TABLE>\n</TD></TR>\n</TABLE>\n";

   static char  OneLanguageFao [] =
"<TR><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[Language]  \">\n\
<INPUT TYPE=text size=3 NAME=Order VALUE=\"!%%\">\n\
</TD><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\" \">\n\
<INPUT TYPE=text size=10 NAME=Language VALUE=\"!AZ\">\n\
</TD><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\" \">\n\
<INPUT TYPE=text size=35 NAME=HostList VALUE=\"!AZ\">\n\
</TD></TR>\n";

   static char  GroupFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;&#10;!AZ&#10;\">\n\
<TR><TH><FONT SIZE=+1>!AZ</FONT></TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n";

   static char  MessageFao [] =
"<TR><TD VALIGN=top>!2ZL&nbsp;<TD VALIGN=top>!HZ&nbsp;</TD><TD>!%%</TD></TR>\n";

   char  EndOfGroup [] = "</TABLE>\n</TD></TR>\n</TABLE>";

   char  MessagesNotLoaded [] =
"<P><FONT SIZE=+1 COLOR=\"#ff0000\">No messages could be loaded!</FONT>\n\
</BODY>\n\
</HTML>\n";

   static char  EndOfPage [] =
"</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
<P><INPUT TYPE=hidden NAME=x VALUE=\"&#10;&#10;# End!!&#10;\">\n\
<P><INPUT TYPE=submit VALUE=\" Commit Changes \">\n\
<INPUT TYPE=reset VALUE=\" Reset \">\n\
</FORM>\n\
</BODY>\n\
</HTML>\n";

   register char  *cptr, *sptr, *zptr;
   register unsigned long  *vecptr;

   int  status,
        GroupCount,
        Count,
        Language,
        LineCount,
        MessageCount;
   unsigned long  FaoVector [32];
   char  *MsgGroupPtr,
         *MsgTextPtr;
   char  MultiLineBuffer [2048];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MsgReviseNow()\n");

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;

   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = &rqptr->rqTime.Vms64bit;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   if (mlptr->ProblemReportLength)
   {
      vecptr = FaoVector;
      *vecptr++ = mlptr->ProblemCount;
      *vecptr++ = (mlptr == &MsgDb);
      *vecptr = mlptr->ProblemReportPtr;

      status = NetWriteFaol (rqptr, ProblemReportFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   cptr = MapVmsPath (mlptr->LoadFileName, rqptr);

   vecptr = FaoVector;

   /* source information (i.e. from executing server or static file) */
   *vecptr++ = (mlptr == &MsgDb);
   *vecptr++ = mlptr->LoadFileName;
   *vecptr++ = cptr;
   *vecptr++ = ADMIN_SCRIPT_UPD;
   *vecptr++ = cptr;

   if (mlptr == &MsgDb)
   {
      *vecptr++ = "Loaded:";
      *vecptr++ = &mlptr->LoadBinTime;
   }
   else
   {
      *vecptr++ = "Revised:";
      *vecptr++ = &mlptr->RevBinTime;
   }

   /* form action */
   *vecptr++ = cptr;

   /* comments */
   *vecptr++ = ServerHostPort;
   *vecptr++ = SoftwareID;
   *vecptr++ = &rqptr->rqTime.Vms64bit;
   *vecptr++ = rqptr->RemoteUser;
   *vecptr++ = rqptr->rqAuth.RealmDescrPtr;
   *vecptr++ = rqptr->rqNet.ClientHostName;

   status = NetWriteFaol (rqptr, MessageLoadFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   if (!mlptr->LanguageCount)
   {
      status = NetWriteFaol (rqptr, MessagesNotLoaded, NULL);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      rqptr->rqResponse.HttpStatus = 200;
      return;
   }

   /********************/
   /* language summary */
   /********************/

   vecptr = FaoVector;
   *vecptr++ = MSG_VERSION;

   status = NetWriteFaol (rqptr, LanguageTable, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   for (Count = 1; Count <= mlptr->LanguageCount; Count++)
   {
      vecptr = FaoVector;
      *vecptr++ = "!UL";
      *vecptr++ = Count;
      *vecptr++ = mlptr->Msgs[Count]->LanguageName;
      if (mlptr->Msgs[Count]->HostListPtr != NULL)
         *vecptr++ = mlptr->Msgs[Count]->HostListPtr;
      else
         *vecptr++ = "";

      status = NetWriteFaol (rqptr, OneLanguageFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }
   vecptr = FaoVector;
   *vecptr++ = "";
   *vecptr++ = "";
   *vecptr++ = "";
   status = NetWriteFaol (rqptr, OneLanguageFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   status = NetWriteFaol (rqptr, EndLanguageTable, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /*****************************/
   /* loop through all messages */
   /*****************************/

   Count = GroupCount = 0;

   for (Count = 0; Count < MSG_RANGE; Count++)
   {
      if (mlptr->Msgs[1]->TextPtr[Count] != NULL)
      {
         /* the '\b' backspace is a sentinal, will never occur in a message */
         if (*((unsigned short*)(mlptr->Msgs[1]->TextPtr[Count])) == '\b[')
         {
            if (GroupCount++)
            {
               status = NetWriteFaol (rqptr, EndOfGroup, NULL);
               if (VMSnok (status))
                  ErrorNoticed (status, "NetWriteFaol()", FI_LI);
            }

            vecptr = FaoVector;
            *vecptr++ = MsgGroupPtr = mlptr->Msgs[1]->TextPtr[Count]+1;
            *vecptr++ = mlptr->Msgs[1]->TextPtr[Count]+1;

            status = NetWriteFaol (rqptr, GroupFao, &FaoVector);
            if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

            Count++;
            MessageCount = 0;
         }
      }

      MessageCount++;
      for (Language = 1; Language <= mlptr->LanguageCount; Language++)
      {
         if (Debug) fprintf (stdout, "Language: %d\n", Language);

         if (mlptr->Msgs[Language]->TextPtr[Count] == NULL)
         {
            MsgTextPtr = "";
            /* fall back to the size of the message in the base language */
            cptr = mlptr->Msgs[mlptr->LanguageCount]->TextPtr[Count];
         }
         else
            MsgTextPtr = cptr = mlptr->Msgs[Language]->TextPtr[Count];

         /* count number of lines in message */
         LineCount = 1;
         for ( /*above*/ ; *cptr; cptr++) if (*cptr == '\n') LineCount++;

         vecptr = FaoVector;

         *vecptr++ = MessageCount;
         *vecptr++ = mlptr->Msgs[Language]->LanguageName;

         if (LineCount > 1)
         {
            /* add a '\' (line continuation) character at each end-of-line */
            cptr = MsgTextPtr;
            zptr = (sptr = MultiLineBuffer) + sizeof(MultiLineBuffer);
            while (*cptr && sptr < zptr)
            {
               if (*cptr == '\n' && sptr < zptr) *sptr++ = '\\';
               if (sptr < zptr) *sptr++ = *cptr++;
            }
            if (sptr >= zptr)
            {
               ErrorGeneralOverflow (rqptr, FI_LI);
               break;
            }
            if (sptr > MultiLineBuffer) sptr--;
            while (sptr > MultiLineBuffer &&
                   (ISLWS(*sptr) || *sptr == '\n' || *sptr == '\\')) sptr--;
            if (sptr > MultiLineBuffer) sptr++;
            *sptr = '\0';

            *vecptr++ =
"<INPUT TYPE=hidden NAME=x VALUE=\"&#10;!AZ !2ZL  \">\n\
<TEXTAREA NAME=\"!AZ!AZ!2ZL\" ROWS=!UL COLS=60>!HZ</TEXTAREA>";
            *vecptr++ = mlptr->Msgs[Language]->LanguageName;
            *vecptr++ = MessageCount;
            *vecptr++ = MsgGroupPtr;
            *vecptr++ = mlptr->Msgs[Language]->LanguageName;
            *vecptr++ = MessageCount;
            *vecptr++ = LineCount;
            *vecptr++ = MultiLineBuffer;
         }
         else
         {
            *vecptr++ =
"<INPUT TYPE=hidden NAME=x VALUE=\"&#10;!AZ !2ZL  \">\n\
<INPUT NAME=\"!AZ!AZ!2ZL\" TYPE=text SIZE=60 VALUE=\"!HZ\">";
            *vecptr++ = mlptr->Msgs[Language]->LanguageName;
            *vecptr++ = MessageCount;
            *vecptr++ = MsgGroupPtr;
            *vecptr++ = mlptr->Msgs[Language]->LanguageName;
            *vecptr++ = MessageCount;
            *vecptr++ = MsgTextPtr;
         }

         status = NetWriteFaol (rqptr, MessageFao, &FaoVector);
         if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      }
   }

   /**************/
   /* end revise */
   /**************/

   status = NetWriteFaol (rqptr, EndOfPage, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
}

/*****************************************************************************/

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        