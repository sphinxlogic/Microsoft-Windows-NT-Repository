/*****************************************************************************/
/*
                                MapUrl.c

Functions supporting mapping of URLs to VMS file specifications and VMS 
specifications to URLs, uses the HTTPd rule mapping file.  The number of rules 
it can store is not fixed, but is limited by available memory and the 
practical considerations of processing large, linear rule databases. 

Comment lines may be provided by beginning a line with a '#' character.

Lines may be continued by ensuring the last character on the line is a '\'.

Virtual server syntax is the same as for authentication/authorization rules,
[[virtual-host]] (all ports of host) or [[virtual-host:virtual-port]] (
matching specified port of host) for a specific host and [[*]] to resume rules
for all virtual hosts.


Extended File Specification
---------------------------
Extended file specifications (required for ODS-5) are supported.  A rule is
used to flag such paths for ODS-5 tailored processing.  Things that are not
done to ODS-5 paths; case-changes and character substitution.  Things that are
done to ODS-5 paths; escaping to and from the extended file specification
canonical escape syntax (i.e. '^').

Paths located on ODS-5 volumes need to have the ODS-5 rule SET against them.

  set /extended/* ODS-5

It is possible to explicitly mark a path as ODS-2 also, although as this is the
default it is usually unnecessary.  One situation where this might be useful is
where all paths are ODS-5 except a small minority, in which case a rule such as
the following might be used.

  set /* ODS-5
  set /old-path/* ODS-2

Paths derived using the USER rule are specially processed.  The SYSUAF user
home directory's structure is determined using a sys$getdvi() to determined
it's ACPTYPE.  Hence no explicit rule is required for these.


Mapping Rules
-------------
[[virtual-host:optional-virtual-port]]
EXEC       template  result           [conditional(s)]
EXEC       (runtime)template  result  [conditional(s)]
EXEC+      template  result           [conditional(s)]
FAIL       template                   [conditional(s)]
MAP        template  result           [conditional(s)]
PASS       template  [result]         [conditional(s)]
REDIRECT   template  result           [conditional(s)]
SCRIPT     template  result           [conditional(s)]
SCRIPT+    template  result           [conditional(s)]
SET        template  [setting(s)]     [conditional(s)]
USER       template  result           [conditional(s)]
UXEC       template  result           [conditional(s)]
UXEC       (runtime)template  result  [conditional(s)]
UXEC+      template  result           [conditional(s)]

(Somewhat awkwardly the square brackets both denote optional fields and to
literally delimit a conditional.  Please do not confuse the two!)

PASS rules can map to a result comprising an HTTP status code (e.g. 403) with a
following textual message (including white-space).  Just delimit the result
string with double or single quotes, or within curly braces.  For example:

PASS /private/stuff/* "403 Can't go in there!" [!ho:my.host.name]
PASS /private/stuff/* '403 "/private/stuff/" is off-limits!' [!ho:my.host.name]


Run-Time Environment (RTE) Mapping
----------------------------------
Each persistant run-time environment must have it's own mapping environment. 
This may, or may not, correspond to physically distinct directory areas.  It is
the mapping rules that identify run-time environments.  A parenthesized
interprester specification leads the result component of the rule.  This is
first extracted and then the EXEC rule behaves as normal.  Hence the following 
example shows two such environments each with it's own interpreter.

  exec /plbin/* (cgi-bin:[000000]perlrte.exe)/ht_root/perl_local/*
  exec /pybin/* (cgi-bin:[000000]javarte.exe)/ht_root/python_local/*

The "/plbin/*" identifies request paths beginning with this string as a
hypothetical, persistant Perl run-time interpreter, with the Perl source
scripts available to it from HT_ROOT:[PERL_LOCAL].  Similarly with a
hypothetical Java Environment.

If a request with the following URI is given to the server

  http://the.host.name/plbin/plsearch/web/doc/

the following components will be derived

  run-time interpreter ... CGI-BIN:[000000]PERLRT.EXE
  Perl source script ..... HT_ROOT:[PERL_LOCAL]PLSEARCH.PL
  request path-info ...... WEB:[DOC]


Mapping User Directories
------------------------
The USER rule effectively PASSes the user's SYSUAF default device and directory
as the first wildcard substitution in the rule.  Accounts that are disusered,
captive or have expired passwords are never mapped, they are always "denied
access by default".  In the same way privileged accounts (those possessing
SYSPRV) cannot be mapped this way (see below for a workaround).

An example; if the user name DANIEL has the default device USER$DISK: and
default directory [DANIEL] the following request path

  /~daniel/

would be mapped to the result and VMS file specification

  /user$disk/daniel/www/
  USER$DISK:[DANIEL.WWW]

using the following rule (note that in all these examples the '@' character has
been  substituted for the '*' because of constraints with C-language comment
structures).

  USER  /~@/@  /@/www/

Note the "/www" subdirectory component.  It is recommended that user
directories always be mapped to a subdirectory of the physcial area.  This
effectively "sandboxes" Web access to that subdirectory hierarchy, allowing the
user privacy elsewhere in the home area.

To accomodate request user paths that do not incorporate a trailing delimiter
after the username the following redirect may be used to cause the browser to
re-request with a more appropriate path.

  REDIRECT  /~@  ///@/www/

WASD also "reverse maps" VMS specifications into paths and so requires
additional rules to provides these mappings.  (Reverse mapping is required
during directory listings and error reporting.)  In the above case the
following rules would actually be required (and in the stated order).

  USER  /~@/@  /@/www/
  PASS  /~@/@  /user$disk/@/www/@

Where user home directories are spread over multiple devices (physical or
concealed logical) a reverse-mapping rule would be required for each. Consider
the following situation, where user directories are distributed across these
devices (concealed logicals)

  USER$GROUP1:
  USER$GROUP2:
  USER$GROUP2:
  USER$OTHER:

This would require the following mapping rules (in the stated order).

  USER  /~@/@  /@/www/
  PASS  /~@/@  /user$group1/@/www/@
  PASS  /~@/@  /user$group2/@/www/@
  PASS  /~@/@  /user$group3/@/www/@
  PASS  /~@/@  /user$other/@/www/@

Of course vanilla mapping rules may be used to provide for special cases.  For
instance, if there is requirement for a particular, privileged account to have
a user mapping that could be provided as in the following (rather exagerated)
example.

  PASS  /~system/@  /sys$common/sysmgr/www/@
  USER  /~@/@  /@/www/
  PASS  /~@/@  /user$disk/@/www/@


Path SETtings
-------------
The SET rule allows characteristics to be set against a particular path.  They
are then transfered to any request matching the path and applied to the
request.  This applies to FILES, not necessarily to scripts that supply a full
HTTP response.  These need to check and act on information provided by relevant
CGI variables.

[NO]AUTH=ONCE     authorize only the script portion of the request,
                  do not repeat authorization on any path component

[NO]AUTH=MAPPED   authorize against the mapped path

[NO]CACHE       files in the path should be cached (if at all possible,
                is overridden by a NOCACHE on the same line but overrides
                an NOCACHE set on any previous applicable rule)

CGIPREFIX=      instead of the default "WWW_" specify what is needed,
                to have no prefix at all specify CGIPREFIX=

CHARSET=        any "text/..." content-type files use the specified charset

CONTENT=        all files have the "Content-Type:" forced to that specified
                (obvious use is to provide plain-text or binary versions of
                files using perhaps "set /plain-text/@ content=text/plain",
                then mapping that generally back with "map /plain-text/@ /@")
                another: "set /bogus/@ "content=text/html; charset=BLAH"

[NO]EXPIRED     files in the path are sent "pre-expired"

INDEX=          "Index of" format string (same as "?httpd=index&...")

[NO]LOG         requests to this path are not to be access-logged

[NO]MAPEMPTY    traditionally a path must have contained at least one char
                to be mapped, this allows "empty" paths to be mapped

[NO]MAP=ONCE    normally, when a script has been derived from a path, WASD
                goes on to map the 'path' portion in a separate pass - this
                SETting provides the derived path as-is

ODS-2           path marked as ODS-2 (path default)
ODS-5           path marked as ODS-5

SCRIPT=find     (default) search for the script file in any 'script' or 'exec'
SCRIPT=nofind   do not search for the script file (for use with RTEs)
SCRIPT=AS=user  the script process will be using this username/account
                (only applies if detached script processes are enabled)

SSI=priv        mark a path as allowed to contain SSI documents that can
SSI=nopriv      use privileged SSI statements (e.g. "#dcl")

SSLCGI=none     sets the style of SSL-related CGI variables 
SSLCGI=Apache_mod_SSL      
SSLCGI=Purveyor      

[NO]PROFILE     VMS SYSUAF-authenticated security profile applies/does not
                apply to this path

REPORT=basic    supply basic error information for requests on this path
REPORT=detailed supply detailed error information for requests on this path

RMSCHAR=        provides the RMS-invalid substitution character, which unless
                otherwise specified is the dollar symbol. Any general
                RMS-valid character may be specified (e.g. alpha-numeric,
                '$', '-' or '_', although the latter three are probably the
                only REAL choices).  When an RMS-invalid character (e.g. '+')
                or syntax (e.g. multiple periods) is encountered this character
                is substituted.  NOTE: is not applied to ODS-5 volumes.

[NO]STMLF       files in this path can be converted from variable to stream-LF


$PERSONA-based User Scripting
-----------------------------
For use with VMS V6.2 and greater, with the /PERSONA qualifier active.
The following set of rules will allow user account based scripting.

  SET   /~@/www/cgi-bin/@  script=as=~
  UXEC  /~@/cgi-bin/@  /@/www/cgi-bin/@
  USER  /~@/@  /@/www/@
  REDIRECT  /~@  /~@/
  PASS  /~@/@  /dka0/users/@/@


DECnet-based User Scripting
---------------------------
If DECnet/OSU scripting is enabled then the following rule will activate a
script in the specified user's directory (all other things being equal).
Always map to some unique and specific subdirectory of the home directory.
(In these examples commercial-at symbols substitute for wildcard asterisks ..
we are in a C-language comment, after-all!!)

exec /~@/cgi-bin/@ /0""::/where/ever/@/cgi-bin/@

It's a little like the user-mapping rules:

pass /~@ /where/ever/@


Mapping Conditionals
--------------------
THIS OFFERS A POWERFUL TOOL TO THE SERVER ADMINISTRATOR!

Conditionals are new to v4.4 and allow mapping rules to be applied
conditionally! That is, the conditionals contain strings that are matched to
specific elements of the request and only if matched are the corresponding
rules applied. The conditionals may contain the '*' and '%' wildcards, and
optionally be negated by an '!' at the start of the conditional string.

Conditionals must follow the rule and are delimited by '[' and ']'. Multiple,
space-separated conditions may be included within one '[...]'. This behaves as
a logical OR (i.e. the condition is true if only one is matched). Multiple
'[...]' conditionals may be included against a rule. These act as a logical
AND (i.e. all must have at least one condition matched). The result of an
entire conditional may be optionally negated by prefixing the '[' with a '!'.

If a conditional is not met the line is completely ignored.  Conditional rules
are not used for 'backward' translation (i.e. from VMS to URL path) so another
rule must exist somewhere to do these mappings.  Conditional rules are only
used by the HTTPd server, they are completely ignored by any scripts using the
MapUrl.c module.

[!]ac:accept             ('Accept:')
[!]al:accept-language    ('Accept-Language:')
[!]as:accept-charset     ('Accept-Charset:')
[!]ck:cookie             ('Cookie:')
[!]ex:                   (extended file specification path)
[!]fo:host-name/address  ('Forwarded:', proxies/gateways)
[!]ho:host-name/address  (client's of course!)
[!]hm:host network mask  (client mask, see immediately below)
[!]me:http-method        (GET, POST, etc.)
[!]qs:query-string       (request query string)
[!]sc:scheme             (request scheme 'http:', 'http', 'https:' or 'https')
[!]sn:server-name        (server host name)
[!]sp:server-port        (server port)
[!]rf:refering-URL       ('Referer:')
[!]ru:remote-user        (if authenticated)
[!]ua:user-agent         ('User-Agent:')
[!]ud:user-details       (authorization user details)
[!]vs:host-name/address  (virtual server, "Host:", destination)

The host-mask ('HM') directive is a dotted-decimal network address, a slash,
then a dotted-decimal mask.  For example "[HM:131.185.250.0/255.255.255.192]". 
This has a 6 bit subnet.  It operates by bitwise-ANDing the client host address
with the mask, bitwise-ANDing the network address supplied with the mask, then
comparing the two results for equality.  Using the above example the host
131.185.250.250 would be accepted, but 131.185.250.50 would be rejected.


VERSION HISTORY
---------------
19-NOV-2000  MGD  bugfix; mapping '/'
10-NOV-2000  MGD  bugfix; MapUrl_UrlToVms() final ';'
01-OCT-2000  MGD  set rule SCRIPT=AS=,
                  rework mapping code somewhat,
                  MapUrl_VmsUserNameCache() on reset free entries
31-AUG-2000  MGD  bugfix; MapUrl_UrlToVms() escaped version semi-colon
24-JUN-2000  MGD  add network-mask to conditionals,
                  persistant run-time environment in EXEC rule (...),
                  change 'HH' to 'VS' (virtual service) backward compatible
06-APR-2000  MGD  set rules SSLCGI= and MAP=
04-MAR-2000  MGD  use NetWriteFaol(), et.al.
02-JAN-2000  MGD  config file opened via ODS module,
                  detection of a path's on-disk-structure (ODS-2 or ODS-5),
                  modify URL->VMS and VMS->URL mapping for extended syntax,
                  avoid confusion; redirect indicators changed from '^' and
                  '@' for local and remote, to '<' and '>' respectively,
                  bugfix; trailing wildcard in set rule comparison
24-OCT-1999  MGD  groan; ensure storage does not overflow!!
                  (plus copious quantities of self-flagellation),
                  SYSUAF-based user directory mapping via a "USER" rule,
                  CGIprefix, [no]profile and [no]authonce SET rules,
                  happy seventh wedding anniversary
12-SEP-1999  MGD  virtual services modifications
10-MAY-1999  MGD  conditional mapping on HTTP cookie and referer,
                  increase the size of scratch storage,
                  mapping endless-loop detection
16-JAN-1999  MGD  allow for proxy service mappings by removing requirement
                  for template and result paths to be absolute ("/...") paths
                  (every time I have to deal with this module I groan)
10-JAN-1999  MGD  bugfix; pass rules not returning mapped path
17-OCT-1998  MGD  SET mapping rule,
                  virtual services via "[[virtual-host:virtual-port]]",
                  "qs:" query string conditional,
                  invalid RMS file name/character substitution configurable
12-AUG-1998  MGD  MapUrl_VmsToUrl() now only optionally absorbs MFD
19-JUL-1998  MGD  'E'xec DECnet-based user scripts
10-MAR-1998  MGD  allow for local redirects (using '^' detect character)
07-FEB-1998  MGD  added "sc:" scheme/protocol conditional for SSL support
20-DEC-1997  MGD  added DECnet support in _UrlToVms(),
                  result paths can now begin with an '*'
25-OCT-1997  MGD  added "as:", "fo:", and "hh:" conditionals,
                  bugfix; MsgFor() required request pointer to find langauge
15-SEP-1997  MGD  MsgFor() was not returning a leading-null message (does now),
                  HTTP status code rules (e.g. "pass /no/* 403 forbidden"),
                  removed two consecutive slashes inhibiting rule mapping
07-SEP-1997  MGD  added "sn:" and "sp:" conditionals
09-AUG-1997  MGD  v4.3, message database, mapping "conditionals",
                  more cart-wheels, hand-stands and contortions (see 01-OCT-96)
05-JUN-1997  MGD  v4.2, CGIplus "exec+" and "script+" rules
01-FEB-1997  MGD  HTTPd version 4, major changes for form-based config
01-OCT-1996  MGD  not proud of how I shoe-horned the reporting features in,
                  good example of slop-down or object-disoriented programming,
                  :^( will rework the whole thing one day, sigh!
                  bugfix; requiring use of 'TheFirstRuleWillBeTheNextRule'
06-APR-1996  MGD  modified conversion of non-VMS characters in MapUrl_UrlToVms()
15-FEB-1995  MGD  bugfix; redirect rule
01-DEC-1995  MGD  v3.0
24-MAR-1995  MGD  bugfix; end-of-string sometimes not detected when matching
20-DEC-1994  MGD  revised for multi-threaded HTTP daemon
20-JUN-1994  MGD  single-threaded daemon
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <devdef.h>
#include <dvidef.h>
#include <prvdef.h>
#include <rms.h>
#include <ssdef.h>
#include <stsdef.h>
#include <uaidef.h>

#include "wasd.h"

#define WASD_MODULE "MAPURL"

/**********/
/* macros */
/**********/

#define MAPURL_RMS_SUBSTITUTION_DEFAULT '$'

/******************/
/* global storage */
/******************/

struct MappingRuleListStruct  MappingRulesList;

/*
   Point at the above storage as default for a rules list.
   This global pointer may be changed temporarily for using other rules.
*/
struct MappingRuleListStruct  *GlobalMappingRulesListPtr = &MappingRulesList;

char  ErrorMappingEndlessLoop [] = "\0Mapping endless-loop detected!";

#define MAPURL_DEFAULT_USER_CACHE_SIZE 32

struct  ListHeadStruct  MapUrlUserNameCacheList;
int  MapUrlUserNameCacheCount,
     MapUrlUserNameCacheEntries;

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern boolean  AuthPolicySysUafRelaxed,
                CliOdsExtendedDisabled,
                CliOdsExtendedEnabled,
                OdsExtended;

extern int  WatchEnabled,
            ServerPort,
            ServerHostNameLength,
            ServiceCount,
            VmsVersion;

extern char  ErrorWatchSysFao[],
             ServerHostName[],
             ServerHostPort[],
             SoftwareID[],
             Utility[];

extern struct ConfigStruct Config;
extern struct  MsgStruct  Msgs;
extern struct ServiceStruct  *ServiceListHead;

/*****************************************************************************/
/*
This overly-long function (sorry) is not AST reentrant, but when executed 
within the context of the HTTPd, is executed either without the possibility of 
AST interruption, or during AST processing and so provides atomic 
functionality.  Pointers to any strings returned must be used immediately 
(before leaving AST context), or copied into storage maintained by the calling 
routine. 

Maps from URL format to VMS file specification, and REVERSE-MAPS from VMS file 
specification to URL format.  Maps scripts.

Always returns a pointer to char.  An error message is detected by being  
returned as a pointer to a string beginning with a null-character!  The 
message begins from character one. 

Call with 'PathPtr' pointing at a string containing the URL path and 'VmsPtr' 
pointing to the storage to contain the mapped VMS equivalent.

Call with 'VmsPtr' pointing to a VMS file specification (dev:[dir]file.ext) 
and 'PathPtr' pointing to an empty string, used as storage to contain the 
REVERSE-MAPPED file specification.

Call with 'PathPtr' pointing at a string containing the URL path, 'VmsPtr' 
pointing to storage to contain the mapped VMS equivalent, 'ScriptPtr' pointing 
to storage for the URL format script path and 'ScriptVmsPtr' pointing to 
storage to contain the VMS specification of the script procedure/image.

The MapUrl_Map() just wraps MapUrl__Map() so that it's function can be WATCHed.

See alter-egos defined in MapUrl.h
*/ 

char* MapUrl_Map
(
char *PathPtr,
int SizeOfPathPtr,
char *VmsPtr,
int SizeOfVmsPtr,
char *ScriptPtr,
int SizeOfScriptPtr,
char *ScriptVmsPtr,
int SizeOfScriptVmsPtr,
char *RteVmsPtr,
int SizeOfRteVmsPtr,
int *PathOdsPtr,
struct RequestStruct *rqptr
)
{
   boolean  VmsToPath;
   char  *cptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MapUrl_Map()\n");

   if (rqptr == NULL || !rqptr->WatchItem)
     return (MapUrl__Map (PathPtr, SizeOfPathPtr,
                          VmsPtr, SizeOfVmsPtr,
                          ScriptPtr, SizeOfScriptPtr,
                          ScriptVmsPtr, SizeOfScriptVmsPtr,
                          RteVmsPtr, SizeOfRteVmsPtr,
                          PathOdsPtr, rqptr));

   if (!(WatchEnabled & WATCH_MAPPING))
     return (MapUrl__Map (PathPtr, SizeOfPathPtr,
                          VmsPtr, SizeOfVmsPtr,
                          ScriptPtr, SizeOfScriptPtr,
                          ScriptVmsPtr, SizeOfScriptVmsPtr,
                          RteVmsPtr, SizeOfRteVmsPtr,
                          PathOdsPtr, rqptr));

   VmsToPath = false;
   if (PathPtr != NULL && PathPtr[0])
      WatchThis (rqptr, FI_LI, WATCH_MAPPING, "PATH !AZ", PathPtr); 
   else
   if (VmsPtr != NULL && VmsPtr[0])
   {
      VmsToPath = true;
      WatchThis (rqptr, FI_LI, WATCH_MAPPING, "VMS !AZ", VmsPtr); 
   }

   cptr = MapUrl__Map (PathPtr, SizeOfPathPtr,
                       VmsPtr, SizeOfVmsPtr, 
                       ScriptPtr, SizeOfScriptPtr,
                       ScriptVmsPtr, SizeOfScriptVmsPtr,
                       RteVmsPtr, SizeOfRteVmsPtr,
                       PathOdsPtr, rqptr);

   if (cptr[0] || !(cptr[0] || cptr[1]))
   {
      if (VmsToPath)
         WatchThis (rqptr, FI_LI, WATCH_MAPPING, "RESULT !AZ", cptr);
      else
      {
         if (PathPtr == NULL) PathPtr = "";
         if (VmsPtr == NULL) VmsPtr = "";
         if (ScriptPtr == NULL) ScriptPtr = "";
         if (ScriptVmsPtr == NULL) ScriptVmsPtr = "";
         if (RteVmsPtr == NULL) RteVmsPtr = "";

         WatchThis (rqptr, FI_LI, WATCH_MAPPING, "RESULT");
         WatchDataFormatted (
"    Mapped: !AZ\n\
Translated: !AZ\n\
    Script: !AZ\n\
  Location: !AZ\n\
       RTE: !AZ\n",
            cptr, VmsPtr, ScriptPtr, ScriptVmsPtr, RteVmsPtr);
      }
   }
   else
      WatchThis (rqptr, FI_LI, WATCH_MAPPING, "RESULT \"!AZ\"", cptr+1);

   return (cptr);
}

char* MapUrl__Map
(
char *PathPtr,
int SizeOfPathPtr,
char *VmsPtr,
int SizeOfVmsPtr,
char *ScriptPtr,
int SizeOfScriptPtr,
char *ScriptVmsPtr,
int SizeOfScriptVmsPtr,
char *RteVmsPtr,
int SizeOfRteVmsPtr,
int *PathOdsPtr,
struct RequestStruct *rqptr
)
{
   static char  DerivedPathBuffer [1024+128],
                PathBuffer [1024+128],
                VmsBuffer [1024+128];

   static struct MappingRuleStruct  TheFirstRuleWillBeTheNextRule;

   register char  *cptr, *pptr, *sptr, *uptr, *zptr;

   boolean  LoadingRules,
            MapPathToVms,
            PathOdsExtended,
            SubstituteForUserName,
            WatchRule;
   int  status,
        MapPassCount,
        PathOds,
        TotalLength;
   unsigned short  Length;
   char  RmsSubstitutionChar;
   char  Scratch [1024+128],
         UserDefault [256],
         VmsUserMappedBuffer [256],
         WildBuffer [1024+128];
   struct MappingRuleStruct  *mrptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
   {
      fprintf (stdout, "MapUrl__Map()");
      if (PathPtr != NULL)
         fprintf (stdout, " PathPtr: %d |%s|\n", strlen(PathPtr), PathPtr);
      if (VmsPtr != NULL)
         fprintf (stdout, " VmsPtr: %d |%s|\n", strlen(VmsPtr), VmsPtr);
      if (ScriptPtr != NULL) fprintf (stdout, "(script)\n");
      fprintf (stdout, "%d %d %d %d\n",
               SizeOfPathPtr, SizeOfVmsPtr, SizeOfScriptPtr,
               SizeOfScriptVmsPtr);
      fputc ('\n', stdout);
   }

   /* if just loading the rules then free any previous set */
   if (LoadingRules = (PathPtr == NULL && VmsPtr == NULL && ScriptPtr == NULL))
      MapUrl_FreeRules (GlobalMappingRulesListPtr);

   if (GlobalMappingRulesListPtr->HeadPtr == NULL)
   {
      /*********************/
      /* read mapping file */
      /*********************/

      cptr = MapUrl_LoadRules (GlobalMappingRulesListPtr);
      /* return message if an error reported */
      if (!cptr[0] && cptr[1]) return (cptr);
      /* point at the location of the first rule as the next rule */
      TheFirstRuleWillBeTheNextRule.NextPtr =
         GlobalMappingRulesListPtr->HeadPtr;
   }

   /* if just (re)loading rules then return now */
   if (LoadingRules) return ("\0\0");

   /*****************************************/
   /* map from the URL or VMS to VMS or URL */
   /*****************************************/

   if (PathPtr == NULL)
   {
      *(unsigned short*)PathBuffer = '\0\0';
      PathPtr = PathBuffer + 1;
      SizeOfPathPtr = sizeof(PathBuffer);
   }
   if (VmsPtr == NULL)
   {
      *(VmsPtr = VmsBuffer) = '\0';
      SizeOfVmsPtr = sizeof(VmsBuffer);
   }
   /* making 'ScriptPtr' non-empty means "exec" and "script" are ignored */
   if (ScriptPtr == NULL) ScriptPtr = "?";

   if (PathPtr[0])
   {
      /* if the URL is not an empty string then force the conversion to VMS */
      MapPathToVms = true;
      *VmsPtr = '\0';
   }
   else
   {
      /* URL was an empty string, convert from VMS to URL */
      MapPathToVms = false;
      /* generate a URL-style version of the VMS specification */
      MapUrl_VmsToUrl (PathPtr, VmsPtr, SizeOfPathPtr, true,
                       rqptr->PathOdsExtended);
   }

   /***********************/
   /* loop thru the rules */
   /***********************/

   if (rqptr->WatchItem && (WatchEnabled & WATCH_MAPPING))
      WatchRule = true;
   else
      WatchRule = false;

   if ((mrptr = GlobalMappingRulesListPtr->HeadPtr) == NULL)
      return (MsgFor(rqptr,MSG_MAPPING_DENIED_NO_RULES)-1);

   MapPassCount = PathOdsExtended = 0;
   RmsSubstitutionChar = MAPURL_RMS_SUBSTITUTION_DEFAULT;

   /*
      This loop may be restarted by the "exec" or "script" rule after mapping
      the script component to further map the derived path.  This is done by
      setting up 'PathPtr' to the derived path and then repointing 'mrptr'
      to a scratch structure which has its 'NextPtr' set up to the first rule
      in the list and 'continue'ing the loop.
   */

   for ( /* above! */ ; mrptr != NULL; mrptr = mrptr->NextPtr)
   {
      if (Debug)
         fprintf (stdout, "Rule |%d|%s|%s|\n",
                  mrptr->RuleType, mrptr->TemplatePtr, mrptr->ResultPtr);

      if (MapPassCount > 2) return (ErrorMappingEndlessLoop);

      if (mrptr->RuleType == MAPURL_RULE_VIRTUAL)
      {
         /************************/
         /* virtual service rule */
         /************************/

         do {

            /* match while traversing down the list of virtual service rules */
            if (Debug)
               fprintf (stdout, "|%s|%s|\n",
                        mrptr->VirtualServerHostPortPtr,
                        rqptr->ServicePtr->ServerHostPort);

            /* if the following rules apply to all services then break */
            if (*mrptr->VirtualServerHostPortPtr == '*')
               break;

            /* if the request service matches the rule service then break */
            if (rqptr->ServicePtr->ServerHostNameHashValue ==
                mrptr->VirtualServerHostNameHashValue &&
                NetThisVirtualService (rqptr->ServicePtr->ServerHostPort,
                                       mrptr->VirtualServerHostPortPtr))
               break;

            if (WatchRule)
               MapUrl_WatchRule (rqptr, mrptr, PathPtr, PathOds,
                                 MAPURL_REPORT_MATCH_NOT);

            mrptr = mrptr->NextVirtualServiceRulePtr;

         } while (mrptr != NULL);

         /* if virtual service matched then continue with next rule */
         if (mrptr != NULL)
         {
            if (WatchRule)
               MapUrl_WatchRule (rqptr, mrptr, PathPtr, PathOds,
                                 MAPURL_REPORT_MATCH_VIRT);
            continue;
         }

         /* if at the end of the list of rules break out of outer loop */
         break;
      }

      /* when mapping from VMS to URL then ignore all BUT "pass" rules */
      if (!MapPathToVms && mrptr->RuleType != MAPURL_RULE_PASS) continue;

      /* if 'ScriptPtr' is not to be used then ignore "exec" and "script" */
      if (ScriptPtr[0] &&
          (mrptr->RuleType == MAPURL_RULE_EXEC ||
           mrptr->RuleType == MAPURL_RULE_SCRIPT ||
           mrptr->RuleType == MAPURL_RULE_UXEC))
         continue;

      /*****************************************************************/
      /* compare the URL with the template/result in the mapping entry */
      /*****************************************************************/

      if (mrptr->RuleType == MAPURL_RULE_SET)
      {
         /********************************/
         /* SET rule, light-weight match */
         /********************************/

         pptr = PathPtr;
         cptr = mrptr->TemplatePtr;
         while (*pptr && *cptr)
         {
            /** if (Debug) fprintf (stdout, "|%s|%s|\n", pptr, cptr); **/
            if (*cptr == '*')
            {
               /* wildcard in template */
               while (*cptr && *cptr == '*') cptr++;
               if (!*cptr)
               {
                  /* wildcard last character, matches the rest by default! */
                  pptr = "";
                  break;
               }
               while (*pptr && *pptr != *cptr) pptr++;
            }
            if (tolower(*pptr) != tolower(*cptr)) break;
            if (*pptr) pptr++;
            if (*cptr) cptr++;
         }

         /* account for trailing asterisk on rule template */
         if (*cptr == '*') while (*cptr == '*') cptr++;

         /* if either point to a non-null character then not matched */
         if (*pptr || *cptr)
         {
            if (WatchRule)
                MapUrl_WatchRule (rqptr, mrptr, PathPtr, PathOds,
                                  MAPURL_REPORT_MATCH_NOT);
            continue;
         }
      }
      else
      {
         /******************************/
         /* other rules, build buffers */
         /******************************/

         /* if reverse-mapping VMS to URL use the result if available */
         if (!MapPathToVms && mrptr->ResultPtr[0])
            cptr = mrptr->ResultPtr;
         else
            cptr = mrptr->TemplatePtr;
         pptr = PathPtr;
         /* 'WildBuffer' contains null-separated wildcard-matched portions */
         zptr = (sptr = WildBuffer) + sizeof(WildBuffer);
         /** if (Debug) fprintf (stdout, "|%s|%s|\n", pptr, cptr); **/

         /* extract the wildcarded sections */
         while (*pptr && *cptr)
         {
            while (tolower(*pptr) == tolower(*cptr) && *cptr != '*')
            {
               pptr++;
               cptr++;
               if (!*cptr || !*pptr) break;
            }
            if (*cptr != '*') break;
            /** if (Debug) fprintf (stdout, "1 |%s|%s|\n", pptr, cptr); **/
            /* asterisk wildcard, multiple consecutive treated as single */
            while (*cptr == '*') cptr++;
            while (*pptr &&
                   tolower(*pptr) != tolower(*cptr) &&
                   sptr < zptr) *sptr++ = *pptr++;
            if (sptr >= zptr)
               return (MsgFor(rqptr,MSG_MAPPING_DENIED_INTERNAL)-1);
            *sptr++ = '\0';
            /** if (Debug) fprintf (stdout, "2 |%s|%s|\n", pptr, cptr); **/
         }
         /* account for trailing asterisk on rule template */
         while (*cptr == '*') cptr++;

         /* if not matched then straight to next rule */
         if (*pptr || *cptr)
         {
            if (WatchRule)
                MapUrl_WatchRule (rqptr, mrptr, PathPtr, PathOds,
                                  MAPURL_REPORT_MATCH_NOT);
            continue;
         }

         /* final, terminating null(s) for 'WildBuffer' */
         if (sptr >= zptr)
            return (MsgFor(rqptr,MSG_MAPPING_DENIED_INTERNAL)-1);
         *sptr = '\0';
      }

      /************/
      /* matched! */
      /************/

      if (Debug) fprintf (stdout, "RULE MATCHED!\n");

      if (mrptr->ConditionalPtr[0])
      {
         /* when not mapping using a request then ignore conditionals */
         if (rqptr != NULL)
         {
            /* if condition not met then continue */
            if (!MapUrl_Conditional ((struct RequestStruct*)rqptr, mrptr))
            {
               if (WatchRule)
                  MapUrl_WatchRule (rqptr, mrptr, PathPtr, PathOds,
                                    MAPURL_REPORT_MATCH_RULE);
               continue;
            }

            /* report rule and conditional matched */
            if (WatchRule)
               MapUrl_WatchRule (rqptr, mrptr, PathPtr, PathOds,
                                 MAPURL_REPORT_MATCH_RULECOND);
         }

         if (Debug) fprintf (stdout, "CONDITIONAL MATCHED!\n");
      }
      else
      {
         /* report rule, there was no conditional */
         if (WatchRule)
            MapUrl_WatchRule (rqptr, mrptr, PathPtr, PathOds,
                              MAPURL_REPORT_MATCH_RULENOCOND);
      }

      if (MapPathToVms)
      {
         /***************************/
         /* mapping from URL to VMS */
         /***************************/

         switch (mrptr->RuleType)
         {
         case MAPURL_RULE_EXEC :
         case MAPURL_RULE_UXEC :

            /*******************/
            /* EXEC/UXEC rule */
            /*******************/

            /* first get the script component from the request */
            cptr = WildBuffer;
            sptr = mrptr->TemplatePtr;
            zptr = (pptr = ScriptPtr) + SizeOfScriptPtr;

            if (mrptr->RuleType == MAPURL_RULE_UXEC)
            {
               if (rqptr->rqPathSet.ScriptAsPtr == NULL ||
                   rqptr->rqPathSet.ScriptAsPtr[0] != '~')
               {
                  /* hmmm, not enabled with a mapping rule!! */
                  return (MsgFor(rqptr,MSG_GENERAL_DISABLED)-1);
               }

               /* first insert the /~username component */
               while (*sptr && *sptr != '*' && pptr < zptr) *pptr++ = *sptr++;
               if (*sptr) sptr++;
               while (*cptr && pptr < zptr) *pptr++ = *cptr++;
               cptr++;
            }

            while (*sptr && *sptr != '*' && pptr < zptr) *pptr++ = *sptr++;
            while (*cptr && *cptr != '/' && pptr < zptr) *pptr++ = *cptr++;

            if (pptr >= zptr)
               return (MsgFor(rqptr,MSG_MAPPING_DENIED_INTERNAL)-1);
            *pptr = '\0';

            if (mrptr->RuleType == MAPURL_RULE_UXEC)
            {
               /* "append" the username to the circumflex */
               rqptr->rqPathSet.ScriptAsPtr = sptr =
                   VmGetHeap (rqptr, strlen(WildBuffer)+2);
               *sptr++ = '~';
               for (cptr = WildBuffer; *cptr; *sptr++ = toupper(*cptr++));
               *sptr = '\0';
            }

            /* now get what it's mapped into (the more complex bit ;^) */
            cptr = WildBuffer;
            sptr = mrptr->ResultPtr;

            if (*sptr == '(')
            {
               /* run-time, e.g. exec /plbin/@ (ht_exe:pl.exe)/plbin/@ */
               sptr++;
               zptr = (pptr = RteVmsPtr) + SizeOfRteVmsPtr;
               while (*sptr && *sptr != ')' && pptr < zptr) *pptr++ = *sptr++;
               if (pptr >= zptr)
                  return (MsgFor(rqptr,MSG_MAPPING_DENIED_INTERNAL)-1);
               *pptr = '\0';
               if (*sptr) sptr++;
            }

            zptr = (pptr = Scratch) + sizeof(Scratch);

            if (mrptr->RuleType == MAPURL_RULE_UXEC)
            {
               /* begin with the mapped user instead of the /~username */
               uptr = MapUrl_VmsUserName (rqptr, WildBuffer, &PathOds);
               if (!uptr[0]) return (uptr);
#ifdef ODS_EXTENDED
               if (OdsExtended)
               {
                  if (Debug) fprintf (stdout, "PathOds: %d\n", PathOds);
                  if (OdsExtended) PathOdsExtended = (PathOds == 5);
                  if (PathOdsPtr != NULL) *PathOdsPtr = PathOds;
               }
#endif /* ODS_EXTENDED */
               /* copy in the-now mapped username */
               while (*uptr && pptr < zptr) *pptr++ = *uptr++;
               /* skip over the equivalent in the result (i.e. "/~*") */
               while (*sptr && *sptr != '*') sptr++;
               if (*sptr) sptr++;
               /* skip first element in the wildcard buffer (i.e. username) */
               if (Debug) fprintf (stdout, "WildBuffer |%s|\n", cptr);
               while (*cptr) cptr++;
               cptr++;
            }
            else
            if (*(unsigned short*)mrptr->TemplatePtr == '/~')
            {
               /*
                  e.g. exec /~@/cgi-bin/@ /0""::/web/user/@/cgi-bin/@
                  i.e. the user part must be prepended to the script part.
               */
               while (*sptr && *sptr != '*' && pptr < zptr) *pptr++ = *sptr++;
               while (*sptr == '*') sptr++;
               if (Debug) fprintf (stdout, "WildBuffer |%s|\n", cptr);
               while (*cptr && pptr < zptr) *pptr++ = *cptr++;
               cptr++;
            }

            /* now the leading script-location part of the result */
            while (*sptr && *sptr != '*' && pptr < zptr) *pptr++ = *sptr++;
            while (*sptr == '*') sptr++;

            /* now script name (i.e. second element of the wildcard buffer) */
            if (Debug) fprintf (stdout, "WildBuffer |%s|\n", cptr);
            while (*cptr && *cptr != '/' && pptr < zptr) *pptr++ = *cptr++;

            if (pptr >= zptr)
               return (MsgFor(rqptr,MSG_MAPPING_DENIED_INTERNAL)-1);
            *pptr = '\0';

            /* generate the VMS script name */
            MapUrl_UrlToVms (Scratch, ScriptVmsPtr, SizeOfScriptVmsPtr,
                             RmsSubstitutionChar, PathOdsExtended);

            /* indicate CGIplus script via leading '+' instead of '/' */
            if (mrptr->IsCgiPlusScript && (RteVmsPtr == NULL || !RteVmsPtr[0]))
               ScriptPtr[0] = '+';

            /* get all including and after the first slash as the new path */
            zptr = (pptr = DerivedPathBuffer) + sizeof(DerivedPathBuffer);
            while (*cptr && pptr < zptr) *pptr++ = *cptr++;
            if (pptr >= zptr)
               return (MsgFor(rqptr,MSG_MAPPING_DENIED_INTERNAL)-1);
            *pptr++ = '\0';
            TotalLength = pptr - DerivedPathBuffer;

            if (Debug)
               fprintf (stdout, "EXEC |%s|%s|%s|\n",
                        ScriptPtr, ScriptVmsPtr, DerivedPathBuffer);

            if (!rqptr->rqPathSet.MapEmpty && !DerivedPathBuffer[0])
               return ("\0\0");

            if (rqptr->rqPathSet.MapOnce)
            {
               /* convert the URL-style to a VMS-style specification */
               MapUrl_UrlToVms (DerivedPathBuffer, VmsPtr, SizeOfVmsPtr,
                                RmsSubstitutionChar, PathOdsExtended);
               if (Debug)
                  fprintf (stdout, "PASS |%s|%s|\n", DerivedPathBuffer, VmsPtr);
               return (DerivedPathBuffer);
            }

            /* restarting at first rule map the path derived from the script */
            *VmsPtr = '\0';
            PathPtr = DerivedPathBuffer;
            mrptr = &TheFirstRuleWillBeTheNextRule;
            MapPassCount++;
            continue;

         case MAPURL_RULE_FAIL :

            /*************/
            /* FAIL rule */
            /*************/

            if (Debug) fprintf (stdout, "FAIL |%s|\n", PathPtr);
            return (MsgFor(rqptr,MSG_MAPPING_DENIED_RULE)-1);

         case MAPURL_RULE_MAP :

            /************/
            /* MAP rule */
            /************/

            cptr = WildBuffer;
            /* place this in a buffer so not to overwrite original path */
            zptr = (pptr = PathPtr = PathBuffer+1) + sizeof(PathBuffer)-1;
            sptr = mrptr->ResultPtr;
            /* scan through the result string */
            while (*sptr)
            {
               while (*sptr && *sptr != '*' && pptr < zptr) *pptr++ = *sptr++;
               if (!*sptr) break;
               /* a wildcard asterisk, substitute from original path */
               while (*sptr == '*') sptr++;
               while (*cptr && pptr < zptr) *pptr++ = *cptr++;
               cptr++;
            }
            if (pptr >= zptr)
               return (MsgFor(rqptr,MSG_MAPPING_DENIED_INTERNAL)-1);
            *pptr = '\0';

            /* continue with the substituted URL mapping */
            if (Debug) fprintf (stdout, "MAP |%s|\n", PathPtr);
            continue;

         case MAPURL_RULE_PASS :
         case MAPURL_RULE_REDIRECT :
         case MAPURL_RULE_USER :

            /****************************/
            /* PASS/REDIRECT/USER rules */
            /****************************/

            cptr = WildBuffer;
            sptr = mrptr->ResultPtr; 
            zptr = (pptr = PathBuffer+1) + sizeof(PathBuffer)-1;

            /* if there is no result to map just pass back the original path */
            if (!*sptr) 
            {
               /* convert the URL-style to a VMS-style specification */
               MapUrl_UrlToVms (PathPtr, VmsPtr, SizeOfVmsPtr,
                                RmsSubstitutionChar, PathOdsExtended);
               if (Debug) fprintf (stdout, "PASS |%s|%s|\n", PathPtr, VmsPtr);
               return (PathPtr);
            }

            /* if redirect rule leave room for the redirection indicator */
            if (mrptr->RuleType == MAPURL_RULE_REDIRECT) pptr++;

            if (mrptr->RuleType == MAPURL_RULE_USER)
            {
               /* begin with the mapped user instead of the /~username */
               uptr = MapUrl_VmsUserName (rqptr, WildBuffer, &PathOds);
               if (!uptr[0]) return (uptr);
#ifdef ODS_EXTENDED
               if (OdsExtended)
               {
                  if (Debug) fprintf (stdout, "PathOds: %d\n", PathOds);
                  if (OdsExtended) PathOdsExtended = (PathOds == 5);
                  if (PathOdsPtr != NULL) *PathOdsPtr = PathOds;
               }
#endif /* ODS_EXTENDED */
               /* copy in the-now mapped username */
               while (*uptr && pptr < zptr) *pptr++ = *uptr++;
               /* skip over the equivalent in the result (i.e. "/~*") */
               while (*sptr && *sptr != '*') sptr++;
               if (*sptr) sptr++;
               /* skip first element in the wildcard buffer (i.e. username) */
               if (Debug) fprintf (stdout, "WildBuffer |%s|\n", cptr);
               while (*cptr) cptr++;
               cptr++;
            }

            /* scan through the result string */
            if (mrptr->RuleType == MAPURL_RULE_PASS &&
                isdigit(sptr[0]) && isdigit(sptr[1]) &&
                isdigit(sptr[2]) && sptr[3] == ' ')
            {
               /* HTTP status code mapping, ignore any asterisks */
               while (*sptr && pptr < zptr) *pptr++ = *sptr++;
            }
            else
            { 
               /* map wildcard asterisks */
               while (*sptr)
               {
                  while (*sptr && *sptr != '*' && pptr < zptr)
                     *pptr++ = *sptr++;
                  if (!*sptr) break;
                  /* wildcard asterisk, substitute from the wildcard buffer */
                  while (*sptr == '*') sptr++;
                  while (*cptr && pptr < zptr) *pptr++ = *cptr++;
                  cptr++;
               }
            }
            if (pptr >= zptr)
               return (MsgFor(rqptr,MSG_MAPPING_DENIED_INTERNAL)-1);
            *pptr = '\0';

            if (mrptr->RuleType == MAPURL_RULE_PASS ||
                mrptr->RuleType == MAPURL_RULE_USER)
            {
               /* if status code mapping return leading null char */
               if (isdigit(PathBuffer[1]) && isdigit(PathBuffer[2]) &&
                   isdigit(PathBuffer[3]) && PathBuffer[4] == ' ')
               {
                  PathBuffer[0] = '\0';
                  return (PathBuffer);
               }

               /* convert the URL-style to a VMS-style specification */
               MapUrl_UrlToVms (PathBuffer+1, VmsPtr, SizeOfVmsPtr,
                                RmsSubstitutionChar, PathOdsExtended);
               if (Debug) fprintf (stdout, "PASS |%s|%s|\n", PathPtr, VmsPtr);
               return (PathBuffer+1);
            }
            else
            {
               if (Debug)
                  fprintf (stdout, "REDIRECT |%s|%s|\n", PathPtr, VmsPtr);
               /* indicate if it's a local or remote redirect */
               if (PathBuffer[2] == '/')
                  PathBuffer[1] = '<';
               else
                  PathBuffer[1] = '>';
               return (PathBuffer+1);
            }

         case MAPURL_RULE_SCRIPT :

            /***************/
            /* SCRIPT rule */
            /***************/

            sptr = mrptr->TemplatePtr;
            zptr = (pptr = ScriptPtr) + SizeOfScriptPtr;
            while (*sptr && *sptr != '*' && pptr < zptr) *pptr++ = *sptr++;
            if (pptr > ScriptPtr && pptr[-1] == '/') pptr--;
            if (pptr >= zptr)
               return (MsgFor(rqptr,MSG_MAPPING_DENIED_INTERNAL)-1);
            *pptr = '\0';

            sptr = mrptr->ResultPtr;
            zptr = (pptr = Scratch) + sizeof(Scratch);
            while (*sptr &&
                   *sptr != '*' &&
                   *(unsigned short*)sptr != '/*' &&
                   pptr < zptr) *pptr++ = *sptr++;
            if (pptr >= zptr)
               return (MsgFor(rqptr,MSG_MAPPING_DENIED_INTERNAL)-1);
            *pptr = '\0';

            /* convert the URL-format script to a VMS-format specification */
            MapUrl_UrlToVms (Scratch, ScriptVmsPtr, SizeOfScriptVmsPtr,
                             RmsSubstitutionChar, PathOdsExtended);

            /* indicate CGIplus script via leading '+' instead of '/' */
            if (mrptr->IsCgiPlusScript) ScriptPtr[0] = '+';

            /* get wildcard matched second section of path as new path */
            zptr = (pptr = DerivedPathBuffer) + sizeof(DerivedPathBuffer);
            while (*sptr != '*' && pptr < zptr) *pptr++ = *sptr++;
            cptr = WildBuffer;
            while (*cptr && pptr < zptr) *pptr++ = *cptr++;
            if (pptr < zptr) *pptr++ = '\0';
            if (pptr >= zptr)
               return (MsgFor(rqptr,MSG_MAPPING_DENIED_INTERNAL)-1);
            TotalLength = pptr - DerivedPathBuffer;

            if (Debug)
               fprintf (stdout, "SCRIPT |%s|%s|%s|\n",
                        ScriptPtr, ScriptVmsPtr, DerivedPathBuffer);

            if (!rqptr->rqPathSet.MapEmpty && !DerivedPathBuffer[0])
               return ("\0\0");

            if (rqptr->rqPathSet.MapOnce)
            {
               /* convert the URL-style to a VMS-style specification */
               MapUrl_UrlToVms (DerivedPathBuffer, VmsPtr, SizeOfVmsPtr,
                                RmsSubstitutionChar, PathOdsExtended);
               if (Debug)
                  fprintf (stdout, "PASS |%s|%s|\n", DerivedPathBuffer, VmsPtr);
               return (DerivedPathBuffer);
            }

            /* restarting at first rule map the path derived from the script */
            *VmsPtr = '\0';
            PathPtr = DerivedPathBuffer;
            MapPassCount++;
            mrptr = &TheFirstRuleWillBeTheNextRule;
            continue;

         case MAPURL_RULE_SET :

            /************/
            /* SET rule */
            /************/

            if (rqptr != NULL)
            {
               if (mrptr->mpPathSet.NoAuthMapped)
                  rqptr->rqPathSet.AuthorizeMapped = false;
               else
               if (mrptr->mpPathSet.AuthMapped)
                  rqptr->rqPathSet.AuthorizeMapped = true;

               if (mrptr->mpPathSet.NoAuthOnce)
                  rqptr->rqPathSet.AuthorizeOnce = false;
               else
               if (mrptr->mpPathSet.AuthOnce)
                  rqptr->rqPathSet.AuthorizeOnce = true;

               if (mrptr->mpPathSet.NoCache)
                  rqptr->rqPathSet.NoCache = true;
               else
               if (mrptr->mpPathSet.Cache)
                  rqptr->rqPathSet.NoCache = false;

               if (mrptr->mpPathSet.NoExpired)
                  rqptr->rqPathSet.Expired = false;
               else
               if (mrptr->mpPathSet.Expired)
                  rqptr->rqPathSet.Expired = true;

               if (mrptr->mpPathSet.NoLog)
                  rqptr->rqPathSet.NoLog = true;
               else
               if (mrptr->mpPathSet.Log)
                  rqptr->rqPathSet.NoLog = false;

               if (mrptr->mpPathSet.MapNonEmpty)
                  rqptr->rqPathSet.MapEmpty = false;
               else
               if (mrptr->mpPathSet.MapEmpty)
                  rqptr->rqPathSet.MapEmpty = true;

               if (mrptr->mpPathSet.MapOnce)
                  rqptr->rqPathSet.MapOnce = true;
               else
               if (mrptr->mpPathSet.MapOnce)
                  rqptr->rqPathSet.MapOnce = false;

               if (mrptr->mpPathSet.PrivSsi)
                  rqptr->rqPathSet.PrivSsi = true;
               else
               if (mrptr->mpPathSet.PrivSsi)
                  rqptr->rqPathSet.PrivSsi = false;

               if (mrptr->mpPathSet.NoProfile)
                  rqptr->rqPathSet.NoProfile = true;
               else
               if (mrptr->mpPathSet.Profile)
                  rqptr->rqPathSet.NoProfile = false;

               /* BASIC overrides DETAILED */
               if (mrptr->mpPathSet.ReportBasic)
                  rqptr->rqPathSet.ReportBasic = true;
               else
               if (mrptr->mpPathSet.ReportDetailed)
                  rqptr->rqPathSet.ReportBasic = false;

               /* careful! this one's a little back-to-front */
               if (mrptr->mpPathSet.ScriptFind)
                  rqptr->rqPathSet.ScriptNoFind = false;
               else
               if (mrptr->mpPathSet.ScriptNoFind)
                  rqptr->rqPathSet.ScriptNoFind = true;

               if (mrptr->mpPathSet.NoStmLF)
                  rqptr->rqPathSet.StmLF = false;
               else
               if (mrptr->mpPathSet.StmLF)
                  rqptr->rqPathSet.StmLF = true;

               if (mrptr->mpPathSet.SSLCGIvar)
               {
                  if (rqptr->rqPathSet.SSLCGIvar == SESOLA_CGI_VAR_NONE)
                     rqptr->rqPathSet.SSLCGIvar = 0;
                  else
                     rqptr->rqPathSet.SSLCGIvar = mrptr->mpPathSet.SSLCGIvar;
               }

#ifdef ODS_EXTENDED
               if (OdsExtended && mrptr->mpPathSet.Ods)
               {
                  PathOds = mrptr->mpPathSet.Ods;
                  if (Debug) fprintf (stdout, "PathOds: %d\n", PathOds);
                  if (OdsExtended) PathOdsExtended = (PathOds == 5);
                  if (PathOdsPtr != NULL) *PathOdsPtr = mrptr->mpPathSet.Ods;
               }
#endif /* ODS_EXTENDED */

               /* CGI prefix is allowed to be an empty string */
               if (mrptr->mpPathSet.CgiPrefixPtr != NULL)
               {
                  rqptr->rqPathSet.CgiPrefixPtr =
                     VmGetHeap (rqptr, mrptr->mpPathSet.CgiPrefixLength+1);
                  memcpy (rqptr->rqPathSet.CgiPrefixPtr,
                          mrptr->mpPathSet.CgiPrefixPtr,
                          mrptr->mpPathSet.CgiPrefixLength+1);
               }

               if (mrptr->mpPathSet.CharsetPtr != NULL &&
                   mrptr->mpPathSet.CharsetPtr[0])
               {
                  rqptr->rqPathSet.CharsetPtr =
                     VmGetHeap (rqptr, mrptr->mpPathSet.CharsetLength+1);
                  memcpy (rqptr->rqPathSet.CharsetPtr,
                          mrptr->mpPathSet.CharsetPtr,
                          mrptr->mpPathSet.CharsetLength+1);
               }

               if (mrptr->mpPathSet.ContentTypePtr != NULL &&
                   mrptr->mpPathSet.ContentTypePtr[0])
               {
                  rqptr->rqPathSet.ContentTypePtr =
                     VmGetHeap (rqptr, mrptr->mpPathSet.ContentTypeLength+1);
                  memcpy (rqptr->rqPathSet.ContentTypePtr,
                          mrptr->mpPathSet.ContentTypePtr,
                          mrptr->mpPathSet.ContentTypeLength+1);
               }

               if (mrptr->mpPathSet.IndexPtr != NULL &&
                   mrptr->mpPathSet.IndexPtr[0])
               {
                  rqptr->rqPathSet.IndexPtr =
                     VmGetHeap (rqptr, mrptr->mpPathSet.IndexLength+1);
                  memcpy (rqptr->rqPathSet.IndexPtr,
                          mrptr->mpPathSet.IndexPtr,
                          mrptr->mpPathSet.IndexLength+1);
               }

               if (mrptr->mpPathSet.ScriptAsPtr != NULL &&
                   mrptr->mpPathSet.ScriptAsPtr[0])
               {
                  rqptr->rqPathSet.ScriptAsPtr =
                     VmGetHeap (rqptr, mrptr->mpPathSet.ScriptAsLength+1);
                  memcpy (rqptr->rqPathSet.ScriptAsPtr,
                          mrptr->mpPathSet.ScriptAsPtr,
                          mrptr->mpPathSet.ScriptAsLength+1);
               }

               if (mrptr->mpPathSet.RmsSubChar)
                  RmsSubstitutionChar = mrptr->mpPathSet.RmsSubChar;

               if (Debug)
                  fprintf (stdout,
"|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%dd|%d|%d|%d|%d|\n\
|%s|%s|%s|\n|%s|\n",
                     mrptr->mpPathSet.AuthMapped,
                     mrptr->mpPathSet.NoAuthMapped,
                     mrptr->mpPathSet.AuthOnce,
                     mrptr->mpPathSet.NoAuthOnce,
                     mrptr->mpPathSet.Cache,
                     mrptr->mpPathSet.NoCache,
                     mrptr->mpPathSet.Expired,
                     mrptr->mpPathSet.NoExpired,
                     mrptr->mpPathSet.Log,
                     mrptr->mpPathSet.NoLog,
                     mrptr->mpPathSet.MapEmpty,
                     mrptr->mpPathSet.MapNonEmpty,
                     mrptr->mpPathSet.MapOnce,
                     mrptr->mpPathSet.NoMapOnce,
                     mrptr->mpPathSet.PrivSsi,
                     mrptr->mpPathSet.NoPrivSsi,
                     mrptr->mpPathSet.Profile,
                     mrptr->mpPathSet.NoProfile,
                     mrptr->mpPathSet.ReportBasic,
                     mrptr->mpPathSet.ReportDetailed,
                     mrptr->mpPathSet.StmLF,
                     mrptr->mpPathSet.NoStmLF,
                     mrptr->mpPathSet.SSLCGIvar,
                     mrptr->mpPathSet.RmsSubChar,
                     mrptr->mpPathSet.CharsetPtr,
                     mrptr->mpPathSet.IndexPtr,
                     mrptr->mpPathSet.ScriptAsPtr,
                     mrptr->mpPathSet.ContentTypePtr,
                     mrptr->mpPathSet.CgiPrefixPtr);
            }
                          
            continue;
         }
      }
      else
      {
         /***************************/
         /* mapping from VMS to URL */
         /***************************/

         /* REVERSE maps a VMS "result" to a "template" :^) */

         cptr = WildBuffer;
         zptr = (pptr = PathPtr) + SizeOfPathPtr;
         sptr = mrptr->TemplatePtr;
         /* scan through the template string */
         while (*sptr)
         {
            while (*sptr && *sptr != '*' && pptr < zptr) *pptr++ = *sptr++;
            if (!*sptr) break;
            /* a wildcard asterisk, substitute from result path */
            while (*sptr == '*') sptr++;
            if (*cptr)
            {
               while (*cptr && pptr < zptr) *pptr++ = *cptr++;
               cptr++;
            }
         }
         if (pptr >= zptr)
            return (MsgFor(rqptr,MSG_MAPPING_DENIED_INTERNAL)-1);
         *pptr = '\0';

         if (Debug) fprintf (stdout, "PASS |%s|\n", PathPtr);
         return (PathPtr);
      }
   }

   /***********************/
   /* a mapping not found */
   /***********************/

   if (*PathPtr != '/')
   {
      /* a "normal" request must begin with an absolute path, it's a proxy! */
      return (PathPtr);
   }

   return (MsgFor(rqptr,MSG_MAPPING_DENIED_DEFAULT)-1);
}

/*****************************************************************************/
/*
Open the mapping rule file and reading each line place mapping rules into the
singly-linked list pointed to by the supplied list pointer.  Close the file.
*/ 
 
char* MapUrl_LoadRules (struct MappingRuleListStruct *rlptr)

{
   static int  MappingRuleStructOverhead = sizeof(struct MappingRuleStruct);

   static char  InformationOds5Disabled [] = "!ODS-5 processing CLI disabled",
                InformationOds5Enabled [] = "!ODS-5 processing enabled",
                InformationOds5NotSupported [] = "!ODS-5 not supported",
                ProblemConditional [] = "conditional problem",
                ProblemConfused [] = "confused",
                ProblemResultPath [] = "\"result\" path not acceptable",
                ProblemResultRequired [] = "requires a \"result\"",
                ProblemRmsSubstitution [] = "RMS substitution character",
                ProblemSetPath [] = "set path problem",
                ProblemTemplateRequired [] = "requires a \"template\"",
                ProblemVirtualService [] = "virtual service problem",
                ProblemVirtualServiceConfig [] =
                   "virtual service not configured",
                ProblemVirtualServiceHostName [] = "virtual host name unknown",
                ProblemWildcardMapping [] = "wildcard mapping problem";

   static char  ErrorString [256];

   register char  *cptr, *sptr, *zptr;
   register struct MappingRuleStruct  *mrptr;

   boolean  ConditionalProblem,
            DebugBuffer,
            IsCgiPlusScript,
            PathOds5,
            RequiresResult,
            SetRule,
            VirtualServerUnknown;
   int  status,
        ConditionalOffset,
        RuleType,
        SetPathAuthMapped,
        SetPathNoAuthMapped,
        SetPathAuthOnce,
        SetPathNoAuthOnce,
        SetPathCache,
        SetPathNoCache,
        SetPathCgiPrefixOffset,
        SetPathCharsetOffset,
        SetPathContentTypeOffset,
        SetPathIndexOffset,
        SetPathExpired,
        SetPathNoExpired,
        SetPathLog,
        SetPathNoLog,
        SetPathMapEmpty,
        SetPathMapNonEmpty,
        SetPathMapOnce,
        SetPathNoMapOnce,
        SetPathOds,
        SetPathPrivSsi,
        SetPathNoPrivSsi,
        SetPathProfile,
        SetPathNoProfile,
        SetPathReportBasic,
        SetPathReportDetailed,
        SetPathScriptAsOffset,
        SetPathScriptFind,
        SetPathScriptNoFind,
        SetPathStmLF,
        SetPathNoStmLF,
        SetPathSSLCGIvar,
        TemplateWildcardCount,
        TotalLength,
        ResultOffset,
        ResultWildcardCount;
   unsigned short  Length;
   char  RmsSubstitutionChar;
   char  *ConditionalPtr,
         *ResultPtr,
         *SetPathCgiPrefixPtr,
         *SetPathCharsetPtr,
         *SetPathContentTypePtr,
         *SetPathIndexPtr,
         *SetPathScriptAsPtr,
         *SetPathPtr,
         *TemplatePtr,
         *VirtualServerHostPortPtr;
   char  Line [512],
         LineBuffer [512],
         Scratch [512],
         VirtualServerHostPort [256];
   struct OdsStruct  ConfigFileOds;
   struct MappingRuleStruct  *PreviousVirtualServiceRulePtr;
   $DESCRIPTOR (ErrorStringDsc, ErrorString);

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "MapUrl_LoadRules() |%s|\n", CONFIG_MAP_FILE_NAME);

   /* reset the username cache */
   MapUrl_VmsUserNameCache (NULL, NULL, NULL, NULL);

   MapUrl_FreeRules (rlptr);

   if (rlptr->ProblemReportPtr != NULL) free (rlptr->ProblemReportPtr);

   memset (rlptr, 0, sizeof(struct MappingRuleListStruct));

   PathOds5 = VirtualServerUnknown = false;
   PreviousVirtualServiceRulePtr = NULL;
   rlptr->LineNumber = 0;
   sys$gettim (&rlptr->LoadBinTime);

   /*************************/
   /* open the mapping file */
   /*************************/

   /* use SYSPRV to allow access to possibly protected file */
   EnableSysPrv();
   status = OdsOpenReadOnly (&ConfigFileOds, CONFIG_MAP_FILE_NAME);
   DisableSysPrv();
   if (VMSnok (status))
   {
      if (Debug) fprintf (stdout, "sys$open() %%X%08.08X\n", status);
      cptr = MapUrl_ReportMessage (rlptr, NULL, status);
      ErrorString[0] = '\0';
      strcpy (ErrorString+1, cptr);
      return (ErrorString);
   }

   /* get the configuration file revision date and time */
   strcpy (rlptr->LoadFileName, ConfigFileOds.ResFileName);
   memcpy (&rlptr->RevBinTime,
           &ConfigFileOds.XabDat.xab$q_rdt,
           sizeof(rlptr->RevBinTime));

   /*************************/
   /* read the mapping file */
   /*************************/

#ifdef DBUG
   /* not interested anymore in seeing debug information for rule load! */
   DebugBuffer = Debug;
   Debug = false;
#endif

   /* set up RAB buffers */
   ConfigFileOds.Rab.rab$l_ubf = Line;
   ConfigFileOds.Rab.rab$w_usz = sizeof(Line)-1;

   while (VMSok (status = sys$get (&ConfigFileOds.Rab, 0, 0)))
   {
      rlptr->LineNumber++;
      ConfigFileOds.Rab.rab$l_ubf[ConfigFileOds.Rab.rab$w_rsz] = '\0';
      if (Debug)
         fprintf (stdout, "ConfigFileOds.Rab.rab$l_ubf |%s|\n",
                  ConfigFileOds.Rab.rab$l_ubf);

      if (ConfigFileOds.Rab.rab$w_rsz)
      {
         if (ConfigFileOds.Rab.rab$l_ubf[ConfigFileOds.Rab.rab$w_rsz-1] == '\\')
         {
            /* line is continued, effectively remove backslash, get more */
            ConfigFileOds.Rab.rab$l_ubf += ConfigFileOds.Rab.rab$w_rsz-1;
            ConfigFileOds.Rab.rab$w_usz -= ConfigFileOds.Rab.rab$w_rsz-1;
            continue;
         }
      }
      /* reset the line buffer */
      ConfigFileOds.Rab.rab$l_ubf = Line;
      ConfigFileOds.Rab.rab$w_usz = sizeof(Line)-1;

      if (Debug) fprintf (stdout, "Line |%s|\n", Line);
      memcpy (rlptr->LinePtr = LineBuffer, Line, ConfigFileOds.Rab.rab$w_rsz+1);
      for (cptr = Line; ISLWS(*cptr); cptr++);

      /* if a blank or comment line, then ignore */
      if (!*cptr || *cptr == '!' || *cptr == '#') continue;

      if (*(unsigned short*)cptr == '[[')
      {
         /************************/
         /* virtual service rule */
         /************************/

         VirtualServerHostPortPtr = cptr += 2;
         for (sptr = cptr; *sptr && *sptr != ']'; sptr++);
         if (*(unsigned short*)sptr != ']]')
         {
            MapUrl_ReportMessage (rlptr, ProblemVirtualService, 0);
            VirtualServerUnknown = true;
            continue;
         }
         *sptr = '\0';

         if (*VirtualServerHostPortPtr != '*')
         {
            if (!NetServiceConfigured (VirtualServerHostPortPtr))
            {
               MapUrl_ReportMessage (rlptr, ProblemVirtualServiceConfig, 0);
               VirtualServerUnknown = true;
               continue;
            }
         }
         strcpy (VirtualServerHostPort, VirtualServerHostPortPtr);
         VirtualServerUnknown = false;
         TotalLength = strlen(VirtualServerHostPort) + 1;

         mrptr = (struct MappingRuleStruct*)
            VmGet (MappingRuleStructOverhead+TotalLength);

         mrptr->RuleType = MAPURL_RULE_VIRTUAL;
         mrptr->NextPtr = NULL;
         mrptr->MapFileLineNumber = rlptr->LineNumber;

         cptr = (char*)mrptr + MappingRuleStructOverhead;
         strcpy (mrptr->VirtualServerHostPortPtr = cptr,
                 VirtualServerHostPort);
         mrptr->VirtualServerHostNameHashValue =
            NetHostNameHash (mrptr->VirtualServerHostPortPtr);
         if (PreviousVirtualServiceRulePtr != NULL)
            PreviousVirtualServiceRulePtr->NextVirtualServiceRulePtr = mrptr;
         PreviousVirtualServiceRulePtr = mrptr;

         /* add to rule list */
         if (rlptr->HeadPtr == NULL)
            rlptr->HeadPtr = mrptr;
         else
            rlptr->TailPtr->NextPtr = mrptr;
         rlptr->TailPtr = mrptr;

         continue;
      }

      /* ignore all rules associated with an unknown virtual server name */
      if (VirtualServerUnknown) continue;

      /**************/
      /* other rule */
      /**************/

      IsCgiPlusScript =
         SetPathAuthMapped = SetPathNoAuthMapped =
         SetPathAuthOnce = SetPathNoAuthOnce =
         SetPathCache = SetPathNoCache =
         SetPathExpired = SetPathNoExpired =
         SetPathLog = SetPathNoLog =
         SetPathMapEmpty = SetPathMapNonEmpty =
         SetPathMapOnce = SetPathNoMapOnce =
         SetPathPrivSsi = SetPathNoPrivSsi =
         SetPathProfile = SetPathNoProfile =
         SetPathReportBasic = SetPathReportDetailed =
         SetPathScriptFind = SetPathScriptNoFind =
         SetPathStmLF = SetPathNoStmLF = false;
      ResultOffset = SetPathCgiPrefixOffset =
         SetPathCharsetOffset =  SetPathContentTypeOffset =
         SetPathOds = SetPathIndexOffset = SetPathScriptAsOffset = 
         SetPathSSLCGIvar = 0;
      SetPathCgiPrefixPtr = SetPathCharsetPtr =
         SetPathContentTypePtr = SetPathIndexPtr =
         SetPathScriptAsPtr = NULL;
      RmsSubstitutionChar = '\0';

      zptr = (sptr = rlptr->RuleName) + sizeof(rlptr->RuleName);
      while (*cptr && !ISLWS(*cptr) && sptr < zptr) *sptr++ = *cptr++;
      if (sptr >= zptr)
      {
         *--sptr = '\0';
         MapUrl_ReportMessage (rlptr, ProblemConfused, 0);
         continue;
      }
      *sptr = '\0';
      while (ISLWS(*cptr)) cptr++;

      IsCgiPlusScript = false;
      if (strsame (rlptr->RuleName, "EXEC", -1))
         RuleType = MAPURL_RULE_EXEC;
      else
      if (strsame (rlptr->RuleName, "EXEC+", -1))
      {
         RuleType = MAPURL_RULE_EXEC;
         IsCgiPlusScript = true;
      }
      else
      if (strsame (rlptr->RuleName, "FAIL", -1))
         RuleType = MAPURL_RULE_FAIL;
      else
      if (strsame (rlptr->RuleName, "MAP", -1))
         RuleType = MAPURL_RULE_MAP;
      else
      if (strsame (rlptr->RuleName, "PASS", -1))
         RuleType = MAPURL_RULE_PASS;
      else
      if (strsame (rlptr->RuleName, "REDIRECT", -1))
         RuleType = MAPURL_RULE_REDIRECT;
      else
      if (strsame (rlptr->RuleName, "SCRIPT", -1))
         RuleType = MAPURL_RULE_SCRIPT;
      else
      if (strsame (rlptr->RuleName, "SCRIPT+", -1))
      {
         RuleType = MAPURL_RULE_SCRIPT;
         IsCgiPlusScript = true;
      }
      else
      if (strsame (rlptr->RuleName, "SET", -1))
         RuleType = MAPURL_RULE_SET;
      else
      if (strsame (rlptr->RuleName, "UXEC", -1) ||
          strsame (rlptr->RuleName, "UEXEC", -1))
         RuleType = MAPURL_RULE_UXEC;
      else
      if (strsame (rlptr->RuleName, "UXEC+", -1) ||
          strsame (rlptr->RuleName, "UEXEC+", -1))
      {
         RuleType = MAPURL_RULE_UXEC;
         IsCgiPlusScript = true;
      }
      else
      if (strsame (rlptr->RuleName, "USER", -1))
         RuleType = MAPURL_RULE_USER;
      else
      if (strsame (rlptr->RuleName, "VIRTUAL", -1))
         RuleType = MAPURL_RULE_VIRTUAL;
      else
      {
         MapUrl_ReportMessage (rlptr, "?", 0);
         continue;
      }
      /* extract template */
      TemplatePtr = cptr;
      while (*cptr && !ISLWS(*cptr)) cptr++;
      /* note the position of the empty string in case neither of these! */
      ResultPtr = ConditionalPtr = cptr;
      ResultOffset = ConditionalOffset = cptr - TemplatePtr;
      /* terminate in the white-space following the template */
      if (*cptr) *cptr++ = '\0';
      /* skip intervening white-space */
      while (ISLWS(*cptr)) cptr++;

      if (SetRule = (RuleType == MAPURL_RULE_SET))
      {
         /*****************/
         /* path SET rule */
         /*****************/

         while (*cptr)
         {
            /* break if this looks like a conditional */
            if (*cptr == '[' || *(unsigned short*)cptr == '![') break;

            if (*cptr == '\"')
            {
               /* delimitted by double quotes */
               SetPathPtr = ++cptr;
               while (*cptr && *cptr != '\"') cptr++;
               if (*cptr) *cptr++ = '\0';
            }
            else
            if (*cptr == '\'')
            {
               /* delimitted by single quotes */
               SetPathPtr = ++cptr;
               while (*cptr && *cptr != '\'') cptr++;
               if (*cptr) *cptr++ = '\0';
            }
            else
            if (*cptr == '{')
            {
               /* delimitted by curly braces */
               SetPathPtr = ++cptr;
               while (*cptr && *cptr != '}') cptr++;
               if (*cptr) *cptr++ = '\0';
            }
            else
            {
               /* up to first white-space */
               SetPathPtr = cptr;
               while (*cptr && !ISLWS(*cptr)) cptr++;
               /* terminate in the white-space following the path result */
               if (*cptr) *cptr++ = '\0';
            }
            if (Debug) fprintf (stdout, "SetPathPtr |%s|\n", SetPathPtr);
            /* skip intervening white-space */
            while (ISLWS(*cptr)) cptr++;

            if (strsame (SetPathPtr, "AUTH=MAPPED", -1))
               SetPathAuthMapped = true;
            else
            if (strsame (SetPathPtr, "NOAUTH=MAPPED", -1) ||
                strsame (SetPathPtr, "AUTH=REQUEST", -1))
               SetPathNoAuthMapped = true;
            else
            if (strsame (SetPathPtr, "AUTH=ONCE", -1) ||
                strsame (SetPathPtr, "AUTHONCE", -1))
               SetPathAuthOnce = true;
            else
            if (strsame (SetPathPtr, "NOAUTH=ONCE", -1) ||
                strsame (SetPathPtr, "NOAUTHONCE", -1))
               SetPathNoAuthOnce = true;
            else
            if (strsame (SetPathPtr, "CACHE", -1))
               SetPathCache = true;
            else
            if (strsame (SetPathPtr, "NOCACHE", -1))
               SetPathNoCache = true;
            else
            if (strsame (SetPathPtr, "CGIPREFIX=", 10))
            {
               SetPathCgiPrefixPtr = SetPathPtr + 10;
               SetPathCgiPrefixOffset = SetPathCgiPrefixPtr - TemplatePtr;
            }
            else
            if (strsame (SetPathPtr, "CHARSET=", 8))
            {
               SetPathCharsetPtr = SetPathPtr + 8;
               SetPathCharsetOffset = SetPathCharsetPtr - TemplatePtr;
            }
            else
            if (strsame (SetPathPtr, "CONTENT=", 8))
            {
               SetPathContentTypePtr = SetPathPtr + 8;
               SetPathContentTypeOffset = SetPathContentTypePtr - TemplatePtr;
            }
            else
            if (strsame (SetPathPtr, "CONTENT-TYPE=", 13))
            {
               /* just a synonym for "content=", bet someone uses it! */
               SetPathContentTypePtr = SetPathPtr + 13;
               SetPathContentTypeOffset = SetPathContentTypePtr - TemplatePtr;
            }
            else
            if (strsame (SetPathPtr, "INDEX=", 6))
            {
               SetPathIndexPtr = SetPathPtr + 6;
               SetPathIndexOffset = SetPathIndexPtr - TemplatePtr;
            }
            else
            if (strsame (SetPathPtr, "EXPIRED", -1))
               SetPathExpired = true;
            else
            if (strsame (SetPathPtr, "NOEXPIRED", -1))
               SetPathNoExpired = true;
            else
            if (strsame (SetPathPtr, "LOG", -1))
               SetPathLog = true;
            else
            if (strsame (SetPathPtr, "NOLOG", -1))
               SetPathNoLog = true;
            else
            if (strsame (SetPathPtr, "MAPEMPTY", -1) ||
                strsame (SetPathPtr, "MAP=EMPTY", -1))
               SetPathMapEmpty = true;
            else
            if (strsame (SetPathPtr, "NOMAPEMPTY", -1) ||
                strsame (SetPathPtr, "MAP=NONEMPTY", -1))
               SetPathMapNonEmpty = true;
            else
            if (strsame (SetPathPtr, "MAP=ONCE", -1) ||
                strsame (SetPathPtr, "MAPONCE", -1))
               SetPathMapOnce = true;
            else
            if (strsame (SetPathPtr, "NOMAP=ONCE", -1) ||
                strsame (SetPathPtr, "NOMAPONCE", -1))
               SetPathNoMapOnce = true;
            else
            if (strsame (SetPathPtr, "ODS-2", -1))
               SetPathOds = 2;
            else
            if (strsame (SetPathPtr, "ODS-5", -1))
            {
               SetPathOds = 5;
#ifdef ODS_EXTENDED
               PathOds5 = true;
#endif /* ODS_EXTENDED */
            }
            else
            if (strsame (SetPathPtr, "PROFILE", -1))
               SetPathProfile = true;
            else
            if (strsame (SetPathPtr, "NOPROFILE", -1))
               SetPathNoProfile = true;
            else
            if (strsame (SetPathPtr, "REPORT=BAS", 10))
               SetPathReportBasic = true;
            else
            if (strsame (SetPathPtr, "REPORT=DET", 10))
               SetPathReportDetailed = true;
            else
            if (strsame (SetPathPtr, "RMSCHAR=", 8))
               RmsSubstitutionChar = SetPathPtr[8];
            else
            if (strsame (SetPathPtr, "SCRIPT=AS=", 10))
            {
               /* while setting the required pointers force to upper-case */
               for (sptr = SetPathScriptAsPtr = SetPathPtr+10; *sptr; *sptr++)
                  *sptr = toupper(*sptr);
               SetPathScriptAsOffset = SetPathScriptAsPtr - TemplatePtr;
            }
            else
            if (strsame (SetPathPtr, "SCRIPT=FIND", 8))
               SetPathScriptFind = true;
            else
            if (strsame (SetPathPtr, "SCRIPT=NOFIND", 10))
               SetPathScriptNoFind = true;
            else
            if (strsame (SetPathPtr, "SSI=PRIV", 8))
               SetPathPrivSsi = true;
            else
            if (strsame (SetPathPtr, "SSI=NOPRIV", 10))
               SetPathNoPrivSsi = true;
            else
            if (strsame (SetPathPtr, "SSLCGI=NONE", 11))
               SetPathSSLCGIvar = SESOLA_CGI_VAR_NONE;
            else
            if (strsame (SetPathPtr, "SSLCGI=APACHE_MOD_SSL", 21))
               SetPathSSLCGIvar = SESOLA_CGI_VAR_APACHE_MOD_SSL;
            else
            if (strsame (SetPathPtr, "SSLCGI=PURVEYOR", 15))
               SetPathSSLCGIvar = SESOLA_CGI_VAR_PURVEYOR;
            else
            if (strsame (SetPathPtr, "STMLF", -1))
               SetPathStmLF = true;
            else
            if (strsame (SetPathPtr, "NOSTMLF", -1))
               SetPathNoStmLF = true;
            else
            {
               MapUrl_ReportMessage (rlptr, ProblemSetPath, 0);
               continue;
            }
         }
      }
      else
      {
         /*********************/
         /* path mapping rule */
         /*********************/

         if (*cptr != '[' && *(unsigned short*)cptr != '![')
         {
            /* extract result */
            if (*cptr == '\"')
            {
               /* delimitted by double quotes */
               ResultPtr = ++cptr;
               ResultOffset = cptr - TemplatePtr;
               while (*cptr && *cptr != '\"') cptr++;
               if (*cptr) *cptr++ = '\0';
            }
            else
            if (*cptr == '\'')
            {
               /* delimitted by single quotes */
               ResultPtr = ++cptr;
               ResultOffset = cptr - TemplatePtr;
               while (*cptr && *cptr != '\'') cptr++;
               if (*cptr) *cptr++ = '\0';
            }
            else
            if (*cptr == '{')
            {
               /* delimitted by curly braces */
               ResultPtr = ++cptr;
               ResultOffset = cptr - TemplatePtr;
               while (*cptr && *cptr != '}') cptr++;
               if (*cptr) *cptr++ = '\0';
            }
            else
            {
               /* normal path mapping, up to first white-space */
               ResultPtr = cptr;
               ResultOffset = cptr - TemplatePtr;
               while (*cptr && !ISLWS(*cptr)) cptr++;
               /* terminate in the white-space following the path result */
               if (*cptr) *cptr++ = '\0';
            }
            /* skip intervening white-space */
            while (ISLWS(*cptr)) cptr++;
         }
      }

      /* check for optional mapping conditional(s) */
      ConditionalProblem = false;

      if (*cptr == '[' || *(unsigned short*)cptr == '![')
      {
         /***************/
         /* conditional */
         /***************/

         ConditionalPtr = cptr;
         ConditionalOffset = cptr - TemplatePtr;
         while (*cptr == '[' || *cptr == '!')
         {
            while (*cptr == '[' || *cptr == '!') cptr++;
            while (*cptr && *cptr != ']')
            {
               while (ISLWS(*cptr)) cptr++;
               sptr = cptr;
               while (*cptr && *cptr != ':' && !ISLWS(*cptr) && *cptr != ']')
               {
                  *cptr = toupper(*cptr);
                  cptr++;
               }
               /* basic check of conditional rule */
               if (*sptr == '!') sptr++;
               if ((*(unsigned short*)sptr != 'AC' &&
                    *(unsigned short*)sptr != 'AL' &&
                    *(unsigned short*)sptr != 'AS' &&
                    *(unsigned short*)sptr != 'CK' &&
                    *(unsigned short*)sptr != 'EX' &&
                    *(unsigned short*)sptr != 'FO' &&
                    *(unsigned short*)sptr != 'HH' &&
                    *(unsigned short*)sptr != 'HM' &&
                    *(unsigned short*)sptr != 'HO' &&
                    *(unsigned short*)sptr != 'ME' &&
                    *(unsigned short*)sptr != 'QS' &&
                    *(unsigned short*)sptr != 'SC' &&
                    *(unsigned short*)sptr != 'SN' &&
                    *(unsigned short*)sptr != 'SP' &&
                    *(unsigned short*)sptr != 'RF' &&
                    *(unsigned short*)sptr != 'RU' &&
                    *(unsigned short*)sptr != 'UA' &&
                    *(unsigned short*)sptr != 'UD' &&
                    *(unsigned short*)sptr != 'VS') ||
                   sptr[2] != ':')
               {
                  ConditionalProblem = true;
                  break;
               }
               while (*cptr && !ISLWS(*cptr) && *cptr != ']') cptr++;
               while (ISLWS(*cptr)) cptr++;
            }
            if (*cptr == ']') cptr++;
            /* look ahead */
            for (sptr = cptr; ISLWS(*sptr); sptr++);
            if (*sptr == '[' || *sptr == '!')
            {
               cptr = sptr;
               continue;
            }
         }
         /* terminate in the white-space following the conditional(s) */
         if (*cptr) *cptr = '\0';
      }

      TotalLength = cptr - TemplatePtr + 1;

      if (Debug)
         fprintf (stdout,
"|%d|%d|%s|%s|%s|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|\
%d|%d|%d|%d|%d|%d|%d|%d|%d|%s|%s|%s|\n",
            RuleType, IsCgiPlusScript,
            TemplatePtr, ResultPtr, ConditionalPtr,
            SetPathAuthMapped, SetPathNoAuthMapped,
            SetPathAuthOnce, SetPathNoAuthOnce,
            SetPathCache, SetPathNoCache,
            SetPathExpired, SetPathNoExpired,
            SetPathLog, SetPathNoLog,
            SetPathMapEmpty, SetPathMapNonEmpty,
            SetPathMapOnce, SetPathNoMapOnce,
            SetPathOds,
            SetPathScriptFind, SetPathScriptNoFind,
            SetPathPrivSsi, SetPathNoPrivSsi,
            SetPathProfile, SetPathNoProfile,
            SetPathReportBasic, SetPathReportDetailed,
            SetPathStmLF, SetPathNoStmLF,
            SetPathSSLCGIvar,
            SetPathCgiPrefixPtr, SetPathCharsetPtr,
            SetPathContentTypePtr, SetPathIndexPtr),
            SetPathScriptAsPtr;

      /******************************/
      /* basic consistency checking */
      /******************************/

      if (ConditionalProblem)
      {
         MapUrl_ReportMessage (rlptr, ProblemConditional, 0);
         continue;
      }

      if (RmsSubstitutionChar &&
          !isalnum(RmsSubstitutionChar) && RmsSubstitutionChar != '$' &&
          RmsSubstitutionChar != '-' && RmsSubstitutionChar != '_')
      {
         MapUrl_ReportMessage (rlptr, ProblemRmsSubstitution, 0);
         continue;
      }

      TemplateWildcardCount = 0;
      for (cptr = TemplatePtr; *cptr; cptr++)
         if (*cptr == '*') TemplateWildcardCount++;

      ResultWildcardCount = 0;
      for (cptr = ResultPtr; *cptr; cptr++)
         if (*cptr == '*') ResultWildcardCount++;

      RequiresResult = false;
      switch (RuleType)
      {
         case MAPURL_RULE_EXEC :
         case MAPURL_RULE_SCRIPT :
         case MAPURL_RULE_UXEC :
            if (ResultWildcardCount < 1 &&
                TemplateWildcardCount < 1 &&
                ResultWildcardCount != TemplateWildcardCount)
            {
               MapUrl_ReportMessage (rlptr, ProblemWildcardMapping, 0);
               continue;
            }
            RequiresResult = true;
            break;

         case MAPURL_RULE_FAIL :
            break;

         case MAPURL_RULE_PASS :

            /* convert the path into the VMS mapping */
            Scratch[0] = '\0';
            if (ResultPtr[0])
               MapUrl_UrlToVms (ResultPtr, Scratch, sizeof(Scratch),
                                RmsSubstitutionChar, false);
            else
               MapUrl_UrlToVms (TemplatePtr, Scratch, sizeof(Scratch),
                                RmsSubstitutionChar, false);

            break;

         case MAPURL_RULE_MAP :
         case MAPURL_RULE_REDIRECT :
         case MAPURL_RULE_USER :
            RequiresResult = true;
            break;

         case MAPURL_RULE_SET :
            /* lower-case ess */
            break;

         default :
            MapUrl_ReportMessage (rlptr, "?", 0);
            continue;
      }

      if (!TemplatePtr[0])
      {
         /* there must be a "template" to map from */
         MapUrl_ReportMessage (rlptr, ProblemTemplateRequired, 0);
         continue;
      }

      if (!SetRule)
      {
         if (RequiresResult && !ResultPtr[0])
         {
            /* there must be a "result" to map to */
            MapUrl_ReportMessage (rlptr, ProblemResultRequired, 0);
            continue;
         }

         if (RuleType != MAPURL_RULE_PASS && isdigit(ResultPtr[0]))
         {
            /* only pass rules may use the status code format */
            MapUrl_ReportMessage (rlptr, ProblemResultPath, 0);
            continue;
         }

         if (ResultWildcardCount > TemplateWildcardCount &&
             !(RuleType == MAPURL_RULE_PASS && isdigit(ResultPtr[0])))
         {
            /* cannot wildcard map more elements than in template */
            MapUrl_ReportMessage (rlptr, ProblemWildcardMapping, 0);
            continue;
         }
      }

      /************************************/
      /* enter the rule into the database */
      /************************************/

      mrptr = (struct MappingRuleStruct*)
         VmGet (MappingRuleStructOverhead+TotalLength);

      cptr = (char*)mrptr + MappingRuleStructOverhead;
      memcpy (cptr, TemplatePtr, TotalLength);
      mrptr->NextPtr = NULL;
      mrptr->MapFileLineNumber = rlptr->LineNumber;
      mrptr->RuleType = RuleType;
      mrptr->IsCgiPlusScript = IsCgiPlusScript;
      mrptr->TemplatePtr = cptr;
      if (ResultOffset)
         mrptr->ResultPtr = cptr + ResultOffset;
      else
         mrptr->ResultPtr = NULL;
      mrptr->ConditionalPtr = cptr + ConditionalOffset;
      if (SetPathCgiPrefixOffset)
      {
         mrptr->mpPathSet.CgiPrefixPtr = cptr + SetPathCgiPrefixOffset;
         mrptr->mpPathSet.CgiPrefixLength =
            strlen(mrptr->mpPathSet.CgiPrefixPtr);
      }
      else
      {
         mrptr->mpPathSet.CgiPrefixPtr = NULL;
         mrptr->mpPathSet.CgiPrefixLength = 0;
      }
      if (SetPathCharsetOffset)
      {
         mrptr->mpPathSet.CharsetPtr = cptr + SetPathCharsetOffset;
         mrptr->mpPathSet.CharsetLength =
            strlen(mrptr->mpPathSet.CharsetPtr);
      }
      else
      {
         mrptr->mpPathSet.CharsetPtr = NULL;
         mrptr->mpPathSet.CharsetLength = 0;
      }
      if (SetPathContentTypeOffset)
      {
         mrptr->mpPathSet.ContentTypePtr = cptr + SetPathContentTypeOffset;
         mrptr->mpPathSet.ContentTypeLength =
            strlen(mrptr->mpPathSet.ContentTypePtr);
      }
      else
      {
         mrptr->mpPathSet.ContentTypePtr = NULL;
         mrptr->mpPathSet.ContentTypeLength = 0;
      }
      if (SetPathIndexOffset)
      {
         mrptr->mpPathSet.IndexPtr = cptr + SetPathIndexOffset;
         mrptr->mpPathSet.IndexLength = strlen(mrptr->mpPathSet.IndexPtr);
      }
      else
      {
         mrptr->mpPathSet.IndexPtr = NULL;
         mrptr->mpPathSet.IndexLength = 0;
      }
      if (SetPathScriptAsOffset)
      {
         mrptr->mpPathSet.ScriptAsPtr = cptr + SetPathScriptAsOffset;
         mrptr->mpPathSet.ScriptAsLength = strlen(mrptr->mpPathSet.ScriptAsPtr);
      }
      else
      {
         mrptr->mpPathSet.ScriptAsPtr = NULL;
         mrptr->mpPathSet.ScriptAsLength = 0;
      }
      mrptr->mpPathSet.RmsSubChar = RmsSubstitutionChar;
      mrptr->mpPathSet.AuthMapped = SetPathAuthMapped;
      mrptr->mpPathSet.NoAuthMapped = SetPathNoAuthMapped;
      mrptr->mpPathSet.AuthOnce = SetPathAuthOnce;
      mrptr->mpPathSet.NoAuthOnce = SetPathNoAuthOnce;
      mrptr->mpPathSet.Cache = SetPathCache;
      mrptr->mpPathSet.NoCache = SetPathNoCache;
      mrptr->mpPathSet.Expired = SetPathExpired;
      mrptr->mpPathSet.NoExpired = SetPathNoExpired;
      mrptr->mpPathSet.Log = SetPathLog;
      mrptr->mpPathSet.NoLog = SetPathNoLog;
      mrptr->mpPathSet.MapEmpty = SetPathMapEmpty;
      mrptr->mpPathSet.MapNonEmpty = SetPathMapNonEmpty;
      mrptr->mpPathSet.MapOnce = SetPathMapOnce;
      mrptr->mpPathSet.NoMapOnce = SetPathNoMapOnce;
      mrptr->mpPathSet.Ods = SetPathOds;
      mrptr->mpPathSet.ScriptFind = SetPathScriptFind;
      mrptr->mpPathSet.ScriptNoFind = SetPathScriptNoFind;
      mrptr->mpPathSet.PrivSsi = SetPathPrivSsi;
      mrptr->mpPathSet.NoPrivSsi = SetPathNoPrivSsi;
      mrptr->mpPathSet.Profile = SetPathProfile;
      mrptr->mpPathSet.NoProfile = SetPathNoProfile;
      mrptr->mpPathSet.ReportBasic = SetPathReportBasic;
      mrptr->mpPathSet.ReportDetailed = SetPathReportDetailed;
      mrptr->mpPathSet.StmLF = SetPathStmLF;
      mrptr->mpPathSet.NoStmLF = SetPathNoStmLF;
      mrptr->mpPathSet.SSLCGIvar = SetPathSSLCGIvar;

      /* add to rule list */
      if (rlptr->HeadPtr == NULL)
         rlptr->HeadPtr = mrptr;
      else
         rlptr->TailPtr->NextPtr = mrptr;
      rlptr->TailPtr = mrptr;
   }

   if (status == RMS$_EOF) status = SS$_NORMAL;

#ifdef DBUG
   Debug = DebugBuffer;
#endif

   /**************************/
   /* close the mapping file */
   /**************************/

   sys$close (&ConfigFileOds.Fab, 0, 0);

   if (VMSok (status))
      *(unsigned long*)ErrorString = 0;
   else
   {
      MapUrl_FreeRules (rlptr);
      cptr = MapUrl_ReportMessage (rlptr, NULL, status);
      ErrorString[0] = '\0';
      strcpy (ErrorString+1, cptr);
   }

   /* if mapping server rules (rather than rule report for instance) */
   if (rlptr == &MappingRulesList)
   {
      /* if no ODS5 paths then extended file specification can be disabled */
#ifdef ODS_EXTENDED
      if (CliOdsExtendedDisabled)
      {
         OdsExtended = false;
         MapUrl_ReportMessage (rlptr, InformationOds5Disabled, 0);
      }
      else
#endif /* ODS_EXTENDED */
      if (CliOdsExtendedEnabled || PathOds5)
      {
#ifdef ODS_EXTENDED
         if (VmsVersion >= 72)
         {
            OdsExtended = true;
            MapUrl_ReportMessage (rlptr, InformationOds5Enabled, 0);
         }
         else
#endif /* ODS_EXTENDED */
         {
            OdsExtended = false;
            MapUrl_ReportMessage (rlptr, InformationOds5NotSupported, 0);
         }
      }
      else
         OdsExtended = false;
   }

   return (ErrorString);
}

/*****************************************************************************/
/*
This function formats an error report.  All lines are concatenated onto a
single string of dynamically allocated memory that (obviously) grows as
reports are added to it.  This string is then output if loading the server
configuration or is available for inclusion in an HTML page.
*/

char* MapUrl_ReportMessage
(
struct MappingRuleListStruct *rlptr,
char *Explanation,
int StatusValue
)
{
   static char  Buffer [256];

   int  status;
   unsigned short  Length;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MapUrl_ReportMessage()\n");

   rlptr->ProblemCount++;

   if (StatusValue)
   {
      if (Explanation == NULL)
         status = WriteFao (Buffer, sizeof(Buffer), &Length, "%!%M",
                            StatusValue);
      else
         status = WriteFao (Buffer, sizeof(Buffer), &Length,
                     "%!AZ-W-MAP, !AZ at line !UL\n \\!AZ\\\n\-%!%M\n",
                     Utility, Explanation, rlptr->LineNumber, rlptr->LinePtr,
                     StatusValue);
   }
   else
   if (Explanation == NULL)
      status = WriteFao (Buffer, sizeof(Buffer), &Length,
                  "%!AZ-W-MAP, \"!AZ\" rule problem at line !UL\n \\!AZ\\\n",
                  Utility, rlptr->RuleName, rlptr->LineNumber, rlptr->LinePtr);
   else
   if (Explanation[0] == '?')
      status = WriteFao (Buffer, sizeof(Buffer), &Length,
                  "%!AZ-W-MAP, \"!AZ\" rule unknown at line !UL\n \\!AZ\\\n",
                  Utility, rlptr->RuleName, rlptr->LineNumber, rlptr->LinePtr);
   else
   if (Explanation[0] == '!')
      status = WriteFao (Buffer, sizeof(Buffer), &Length,
                  "%!AZ-I-MAP, !AZ\n", Utility, Explanation+1);
   else
      status = WriteFao (Buffer, sizeof(Buffer), &Length,
                  "%!AZ-W-MAP, !AZ at line !UL\n \\!AZ\\\n",
                  Utility, Explanation, rlptr->LineNumber, rlptr->LinePtr);

   if (VMSnok (status) || status == SS$_BUFFEROVF)
      ErrorExitVmsStatus (status, "WriteFao()", FI_LI);

   if (rlptr->RequestPtr == NULL) fputs (Buffer, stdout);

   rlptr->ProblemReportPtr =
      realloc (rlptr->ProblemReportPtr, rlptr->ProblemReportLength+Length+1);

   /* include the terminating null */
   memcpy (rlptr->ProblemReportPtr+rlptr->ProblemReportLength,
           Buffer, Length+1);
   rlptr->ProblemReportLength += Length;

   return (Buffer);
}


/*****************************************************************************/
/*
Free all entries in the singly-linked rule list.
*/ 
 
MapUrl_FreeRules (struct MappingRuleListStruct *rlptr)

{
   register char  *cptr;
   register struct MappingRuleStruct  *mrptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MapUrl_FreeRules()\n");

   mrptr = rlptr->HeadPtr;
   while (mrptr != NULL)
   {
      cptr = (char*)mrptr;
      mrptr = mrptr->NextPtr;
      VmFree (cptr, FI_LI);
   }
   rlptr->HeadPtr = rlptr->TailPtr = NULL;
}

/*****************************************************************************/
/*
Convert a URL-style specification into a RMS-style specification, example:
"/disk/dir1/dir2/file.txt" into "disk:[dir1.dir2]file.txt".

For ODS-2 paths forbidden characters (non-alphanumberic and non-"$_-" are
converted to the 'RmsSubstitutionChar', by default a dollar symbol).  Where a
specification has multiple ".", all but the final one of the file component is
also converted to a 'RmsSubstitutionChar'.

For ODS-5 paths forbidden characters are ^ (character or hexadecimal) escaped
and the case not altered.

Returns the length of the VMS specification.
*/ 
 
int MapUrl_UrlToVms
(
char *PathPtr,
char *VmsPtr,
int SizeOfVmsPtr,
char RmsSubstitutionChar,
boolean PathOdsExtended
)
{
   static char  HexDigits [] = "0123456789ABCDEF";

   register int  ncnt, ccnt;
   register char  *cptr, *pptr, *sptr, *zptr;

   boolean  DECnet;
   char  *FinalPeriod,
         *FinalSemiColon,
         *FinalSlash;
   char  PathComponents [ODS_MAX_FILE_NAME_LENGTH];

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "MapUrl_UrlToVms() %d %d |%s| %d\n",
               PathOdsExtended, RmsSubstitutionChar, PathPtr, SizeOfVmsPtr);

   if (!PathPtr[0] ||
       (PathPtr[0] == '/' && !PathPtr[1]))
   {
      *(unsigned short*)VmsPtr = '\0\0';
      return (0);
   }

   /******************************************/
   /* parse out each "/" delimited component */
   /******************************************/

   /* each component becomes a null-terminated string in a character array */
   DECnet = false;
   zptr = (sptr = PathComponents) + sizeof(PathComponents);
   pptr = PathPtr;
   ccnt = 0;

#ifdef ODS_EXTENDED

   if (PathOdsExtended)
   {
      /*********/
      /* ODS-5 */
      /*********/

      FinalPeriod = FinalSemiColon = FinalSlash = NULL;
      while (*pptr && sptr < zptr)
      {
         if (*pptr == '/') pptr++;
         cptr = sptr;
         while (*pptr && *pptr != '/' && sptr < zptr)
         {
            switch (*pptr)
            {
               case '!' :
               case '#' :
               case '&' :
               case '\'' :
               case '`' :
               case '(' :
               case ')' :
               case '+' :
               case '@' :
               case '{' :
               case '}' :
               case ',' :
               case ';' :
               case '[' :
               case ']' :
               case '=' :
                  if (*pptr == ';') FinalSemiColon = sptr;
                  *sptr++ = '^';
                  if (sptr < zptr) *sptr++ = *pptr++;
                  break;

               case ' ' :
                  *sptr++ = '^';
                  if (sptr < zptr) *sptr++ = '_';
                  pptr++;
                  break;

               case '.' :
                  if (*(unsigned short*)(pptr+1) == '..')
                  {
                     /* ellipsis wildcard */
                     if (sptr+3 < zptr)
                     {
                        *sptr++ = *pptr++;
                        *sptr++ = *pptr++;
                        *sptr++ = *pptr++;
                     }
                     else
                        sptr = zptr;
                  }
                  else
                  {
                     FinalPeriod = sptr;
                     *sptr++ = '^';
                     if (sptr < zptr) *sptr++ = *pptr++;
                  }
                  break;

               case '^' :
                  *sptr++ = *pptr++;
                  if (isxdigit(*pptr))
                  {
                     if (sptr < zptr) *sptr++ = *pptr++;
                     if (sptr < zptr && *pptr) *sptr++ = *pptr++;
                  }
                  else
                  if (sptr < zptr && *pptr)
                     *sptr++ = *pptr++;
                  break;

               default :
                  if (*pptr == 0x07f ||
                      *pptr == 0x0a0 ||
                      *pptr == 0x0ff ||
                      (*pptr >= 0x80 && *pptr <= 0x9f))
                  {
                     if (sptr+3 < zptr)
                     {
                        *sptr++ = '^';
                        *sptr++ = HexDigits[(*pptr & 0xf0) >> 4];
                        *sptr++ = HexDigits[*pptr++ & 0x0f];
                     }
                     else
                        sptr = zptr;
                  }
                  else
                     *sptr++ = *pptr++;
            }
         }
         if (*pptr == '/') FinalSlash = sptr;
         if (sptr < zptr) *sptr++ = '\0';
         ccnt++;
         if (Debug && sptr < zptr) fprintf (stdout, "%d |%s|\n", ccnt, cptr);
      }
      if (FinalSemiColon != NULL &&
          (FinalSemiColon > FinalSlash || FinalSlash == NULL) &&
          sptr < zptr)
      {
         /* a final semicolon delimitting the version must not be escaped */
         cptr = (sptr = FinalSemiColon) + 1;
         while (*cptr) *sptr++ = *cptr++;
         *sptr = '\0';
      }
      if (FinalPeriod != NULL &&
          (FinalPeriod > FinalSlash || FinalSlash == NULL) &&
          sptr < zptr)
      {
         /* a final period delimitting the type must not be escaped */
         cptr = (sptr = FinalPeriod) + 1;
         while (*cptr) *sptr++ = *cptr++;
         *sptr = '\0';
      }
   }
   else

#endif /* ODS_EXTENDED */

   {
      /*********/
      /* ODS-2 */
      /*********/

      while (*pptr && sptr < zptr)
      {
         if (*pptr == '/') pptr++;
         /* copy, converting all non-RMS characters into exclamation marks */
         cptr = sptr;
         while (*pptr && *pptr != '/' && sptr < zptr)
         {
            if (isalnum (*pptr))
            {
               if (sptr < zptr) *sptr++ = toupper(*pptr++);
            }
            else
            if (pptr[0] == '.' && pptr[1] == '.' && pptr[2] == '.')
            {
               if (sptr < zptr) *sptr++ = *pptr++;
               if (sptr < zptr) *sptr++ = *pptr++;
               if (sptr < zptr) *sptr++ = *pptr++;
            }
            else
            if (*pptr == '$' || *pptr == '_' || *pptr == '-' ||
                *pptr == '*' || *pptr == '%' || *pptr == ';' ||
                *pptr == '\"' || *pptr == '=')
            {
               if (sptr < zptr) *sptr++ = *pptr++;
            }
            else
            if (!ccnt && *(unsigned short*)pptr == '::')
            {
               /* DECnet (with or without access string) */
               DECnet = true;
               if (sptr < zptr) *sptr++ = *pptr++;
               if (sptr < zptr) *sptr++ = *pptr++;
            }
            else
            {
               if (*sptr == '.') FinalPeriod = sptr;
               if (sptr < zptr) *sptr++ = '?';
               pptr++;
            }
         }
         if (sptr < zptr) *sptr++ = '\0';
         ccnt++;
         if (Debug && sptr < zptr) fprintf (stdout, "%d |%s|\n", ccnt, cptr);
      }
   }

   if (sptr >= zptr)
   {
      /* storage overflowed */
      if (Debug) fprintf (stdout, "PathComponents OVERFLOW\n");
      *(unsigned short*)VmsPtr = '\0\0';
      return (0);
   }

   /********************************/
   /* build VMS file specification */
   /********************************/

   cptr = PathComponents;
   zptr = (sptr = VmsPtr) + SizeOfVmsPtr;

   if (DECnet) ccnt--;
   if (ccnt == 1)
   {
      /* single component */
      while (*cptr && sptr < zptr) *sptr++ = *cptr++;
      if (sptr < zptr) *sptr = '\0';
   }
   else
   if (ccnt == 2)
   {
      /***********************/
      /* top-level directory */
      /***********************/

      if (DECnet)
      {
         /* copy first component as-is */
         while (*cptr && sptr < zptr) *sptr++ = *cptr++;
         cptr++;
      }
      /* start with the first component, the "device" */
      while (*cptr && sptr < zptr) *sptr++ = *cptr++;
      cptr++;
      /* append a Master File Directory component */
      if (sptr+9 < zptr) strcpy (sptr, ":[000000]");
      sptr += 9;
      /* add the second component, the "file" */
      while (*cptr && sptr < zptr) *sptr++ = *cptr++;
      if (sptr < zptr) *sptr = '\0';
   }
   else
   if (ccnt >= 3)
   {
      /****************/
      /* subdirectory */
      /****************/

      if (DECnet)
      {
         /* copy first component as-is */
         while (*cptr && sptr < zptr) *sptr++ = *cptr++;
         cptr++;
      }
      /* start with the first component, the "device" */
      while (*cptr && sptr < zptr) *sptr++ = *cptr++;
      cptr++;
      if (sptr < zptr) *sptr++ = ':';
      if (sptr < zptr) *sptr++ = '[';
      if (cptr[0] == '.' && cptr[1] == '.' && cptr[2] == '.')
      {
         if (sptr+6 < zptr) strcpy (sptr, "000000");
         sptr += 6;
      }
      for (ncnt = 2; ncnt < ccnt; ncnt++)
      {
         /* add the next component, a "directory" */
         if (cptr[0] == '.' && cptr[1] == '.' && cptr[2] == '.')
            while (*cptr && sptr < zptr) *sptr++ = *cptr++;
         else
         {
            if (ncnt > 2 && sptr < zptr) *sptr++ = '.';
            while (*cptr && sptr < zptr) *sptr++ = *cptr++;
         }
         cptr++;
      }
      if (sptr < zptr) *sptr++ = ']';
      /* add the last component, the "file" */
      while (*cptr && sptr < zptr) *sptr++ = *cptr++;
      if (sptr < zptr) *sptr = '\0';
   }

   if (sptr >= zptr)
   {
      /* storage overflowed */
      if (Debug) fprintf (stdout, "VmsPtr OVERFLOW\n");
      *(unsigned short*)VmsPtr = '\0\0';
      return (0);
   }

   if (!PathOdsExtended)
   {
      /************************************/
      /* ODS-2 convert non-RMS characters */
      /************************************/

      if (!RmsSubstitutionChar)
         RmsSubstitutionChar = MAPURL_RMS_SUBSTITUTION_DEFAULT;

      for (sptr = VmsPtr; *sptr && *sptr != ']' && sptr < FinalPeriod; sptr++)
         if (*sptr == '?') *sptr = RmsSubstitutionChar;
      if (*sptr)
      {
         cptr = "";
         for (sptr++; *sptr; sptr++)
            if (*sptr == '?') *(cptr = sptr) = RmsSubstitutionChar;
         if (*cptr) *cptr = '.';
      }
   }

   if (!VmsPtr[0]) VmsPtr[1] = '\0';

   if (Debug) fprintf (stdout, "VmsPtr %d |%s|\n", sptr-VmsPtr, VmsPtr);
   return (sptr - VmsPtr);
}

/*****************************************************************************/
/*
Convert a VMS full file specification into a URL-style specification, example:
"DEVICE:[DIR1.DIR2]FILE.TXT" into "/device/dir1/dir2/file.txt", or just a file
name and type portion (ensuring it's correctly converted and escaped).  The URL
has URL forbidden characters URL-encoded.

For ODS-2 expects file specification to be ODS-2 compliant and forces the URL
to all lower-case.

For ODS-5 will decode literal and hexadecimal ^-escaped characters and leaves
the case as-is.

Returns the length of the generated URL-style path.
*/ 
 
int MapUrl_VmsToUrl
(
char *PathPtr,
char *VmsPtr,
int SizeOfPathPtr,
boolean AbsorbMfd,
boolean PathOdsExtended
)
{
   static char  HexDigits [] = "0123456789abcdef";

   register char  c;
   register char  *cptr, *sptr, *zptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "MapUrl_VmsToUrl() %d %d |%s| %d\n",
               PathOdsExtended, AbsorbMfd, VmsPtr, SizeOfPathPtr);

   zptr = (sptr = PathPtr) + SizeOfPathPtr;

   /**********************************************/
   /* copy (any) device and directory components */
   /**********************************************/

   /* look for indications it's a full file specification */
   cptr = VmsPtr;
   while (*cptr && *(unsigned short*)cptr != ':[' && *cptr != ']')
   {
#ifdef ODS_EXTENDED
      if (PathOdsExtended)
      {
         if (cptr[0] == '^' && isxdigit(cptr[1]) && isxdigit(cptr[2]))
            cptr += 3;
         else
         if (cptr[0] == '^' && cptr[1] == 'U' &&
             isxdigit(cptr[2]) && isxdigit(cptr[3]) &&
             isxdigit(cptr[4]) && isxdigit(cptr[5]))
            cptr += 6;
         else
         if (cptr[0] == '^')
            cptr += 2;
         else
            cptr++;
      }
      else
#endif /* ODS_EXTENDED */
         cptr++;
   }

   if (!*cptr)
   {
      /* no device/directory components detected, must be just a file name */
      cptr = VmsPtr;
   }
   else
   {
      /* copy device/directory components */
      cptr = VmsPtr;
      if (sptr < zptr) *sptr++ = '/';
      while (*cptr && sptr < zptr)
      {
         if (*(unsigned short*)cptr == ':[')
         {
            cptr++;
            cptr++;
            /* remove any reference to a Master File Directory */
            if (AbsorbMfd && strncmp (cptr, "000000", 6) == 0)
               cptr += 6;
            else
            if (sptr < zptr)
               *sptr++ = '/';
         }

         if (*cptr == '.')
         {
            if (*(unsigned short*)(cptr+1) == '..')
            {
               if (sptr < zptr) *sptr++ = '/';
               if (sptr < zptr) *sptr++ = *cptr++;
               if (sptr < zptr) *sptr++ = *cptr++;
               if (sptr < zptr) *sptr = *cptr++;
            }
            else
            {
               cptr++;
               if (sptr < zptr) *sptr = '/';
            }
         }
         else
         if (*cptr == ']')
         {
            cptr++;
            if (sptr < zptr) *sptr++ = '/';
            break;
         }
         else
#ifdef ODS_EXTENDED
         if (*cptr == '^' && PathOdsExtended)
         {
            /* ODS-5 extended specification escape character */
            cptr++;
            switch (*cptr)
            {
               case '!' :
               case '#' :
               case '&' :
               case '\'' :
               case '`' :
               case '(' :
               case ')' :
               case '+' :
               case '@' :
               case '{' :
               case '}' :
               /** case '.' : **/
               case ',' :
               case ';' :
               case '[' :
               case ']' :
               case '%' :
               case '^' :
               case '=' :
               /** case ' ' : **/
                  if (sptr < zptr) *sptr = *cptr++;
                  break;
               case '_' :
                  if (sptr < zptr) *sptr = ' ';
                  cptr++;
                  break;
               default :
                  if (isxdigit (*cptr))
                  {
                     c = 0;
                     if (*cptr >= '0' && *cptr <= '9')
                        c = (*cptr - (int)'0') << 4;
                     else
                     if (tolower(*cptr) >= 'a' && tolower(*cptr) <= 'f')
                        c = (tolower(*cptr) - (int)'a' + 10) << 4;
                     cptr++;   
                     if (*cptr >= '0' && *cptr <= '9')
                        c += (*cptr - (int)'0');
                     else
                     if (tolower(*cptr) >= 'a' && tolower(*cptr) <= 'f')
                        c += (tolower(*cptr) - (int)'a' + 10);
                     if (*cptr) cptr++;
                     *sptr = c;
                  }
                  else
                     *sptr = *cptr++;
            }
         }
         else
#endif /* ODS_EXTENDED */
         if (sptr < zptr)
         {
#ifdef ODS_EXTENDED
            if (PathOdsExtended)
               *sptr = *cptr++;
            else
#endif /* ODS_EXTENDED */
               *sptr = tolower(*cptr++);
         }
   
         /* now URL-escape it if it's a URL-forbidden character */
         if (!isalnum(*sptr) &&
             *sptr != '/' &&
             *sptr != '-' &&
             *sptr != '_' &&
             *sptr != '$' &&
             *sptr != '*' &&
             *sptr != ';' &&
             *sptr != '~' &&
             *sptr != '.')
         {
            c = *sptr;
            *sptr++ = '%';
            if (sptr < zptr) *sptr++ = HexDigits[(c & 0xf0) >> 4];
            if (sptr < zptr) *sptr++ = HexDigits[c & 0x0f];
         }
         else
            sptr++;
      }
   }

   /***************************/
   /* copy the file component */
   /***************************/

   while (*cptr && sptr < zptr)
   {
#ifdef ODS_EXTENDED
      if (*cptr == '^' && PathOdsExtended)
      {
         /* ODS-5 extended specification escape character */
         cptr++;
         switch (*cptr)
         {
            case '!' :
            case '#' :
            case '&' :
            case '\'' :
            case '`' :
            case '(' :
            case ')' :
            case '+' :
            case '@' :
            case '{' :
            case '}' :
            /** case '.' : **/
            case ',' :
            case ';' :
            case '[' :
            case ']' :
            case '%' :
            case '^' :
            case '=' :
            /** case ' ' : **/
               if (sptr < zptr) *sptr = *cptr++;
               break;
            case '_' :
               if (sptr < zptr) *sptr = ' ';
               cptr++;
               break;
            default :
               if (isxdigit (*cptr))
               {
                  c = 0;
                  if (*cptr >= '0' && *cptr <= '9')
                     c = (*cptr - (int)'0') << 4;
                  else
                  if (tolower(*cptr) >= 'a' && tolower(*cptr) <= 'f')
                     c = (tolower(*cptr) - (int)'a' + 10) << 4;
                  cptr++;   
                  if (*cptr >= '0' && *cptr <= '9')
                     c += (*cptr - (int)'0');
                  else
                  if (tolower(*cptr) >= 'a' && tolower(*cptr) <= 'f')
                     c += (tolower(*cptr) - (int)'a' + 10);
                  if (*cptr) cptr++;
                  *sptr = c;
               }
               else
                  *sptr = *cptr++;
         }
      }
      else
#endif /* ODS_EXTENDED */
      {
#ifdef ODS_EXTENDED
         if (PathOdsExtended)
            *sptr = *cptr++;
         else
#endif /* ODS_EXTENDED */
            *sptr = tolower(*cptr++);
      }

      /* now URL-escape it if it's a URL-forbidden character */
      if (!isalnum(*sptr) &&
          *sptr != '/' &&
          *sptr != '-' &&
          *sptr != '_' &&
          *sptr != '$' &&
          *sptr != '*' &&
          *sptr != ';' &&
          *sptr != '~' &&
          *sptr != '.')
      {
         c = *sptr;
         *sptr++ = '%';
         if (sptr < zptr) *sptr++ = HexDigits[(c & 0xf0) >> 4];
         if (sptr < zptr) *sptr++ = HexDigits[c & 0x0f];
      }
      else
         sptr++;
   }
   if (sptr < zptr) *sptr++ = '\0';
   if (sptr < zptr) *sptr++ = '\0';

   if (sptr >= zptr)
   {
      *(unsigned short*)PathPtr = '\0\0';
      return (0);
   }

   if (Debug) fprintf (stdout, "PathPtr %d |%s|\n", (sptr-PathPtr)-2, PathPtr);
   return ((sptr - PathPtr) - 2);
}

/*****************************************************************************/
/*
Given the current document's URL path and the specified document's URL path, 
generate a resultant URL path based on whether the specified document's path 
is absolute or relative the the current document's path.  Insufficient space to
contain the result path will not crash the function and the result will be set
to an empty string.
*/ 

int MapUrl_VirtualPath
(
char *CurrentPath,
char *DocumentPath,
char *ResultPath,
int SizeOfResultPath
)
{
   register char  *cptr, *dptr, *sptr, *tptr, *zptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "MapUrl_VirtualPath() |%s|%s| %d\n",
               CurrentPath, DocumentPath, SizeOfResultPath);

   if (*(dptr = DocumentPath) == '/' || strstr (DocumentPath, "//") != NULL) 
   {
      /*****************/
      /* absolute path */
      /*****************/

      strcpy (ResultPath, dptr);
      zptr = (sptr = ResultPath) + SizeOfResultPath;
      while (*dptr && sptr < zptr) *sptr++ = *dptr++;
      if (sptr >= zptr) return (-1);
      *sptr = '\0';
      if (Debug) fprintf (stdout, "ResultPath |%s|\n", ResultPath);
      return (sptr - ResultPath);
   }

   /* step over any "relative to this directory" syntax ("./") */
   if (dptr[0] == '.' && dptr[1] == '/') dptr += 2;
   if (*dptr != '.')
   {
      /*****************/
      /* inferior path */
      /*****************/

      zptr = (sptr = tptr = ResultPath) + SizeOfResultPath;
      cptr = CurrentPath;
      while (*cptr && sptr < zptr)
      {
         if (*cptr == '/') tptr = sptr+1;
         *sptr++ = *cptr++;
      }
      sptr = tptr;
      while (*dptr && sptr < zptr) *sptr++ = *dptr++;
      if (sptr >= zptr) return (-1);
      *sptr = '\0';
      if (Debug) fprintf (stdout, "ResultPath |%s|\n", ResultPath);
      return (sptr - ResultPath);
   }

   /*****************/
   /* relative path */
   /*****************/

   zptr = (sptr = tptr = ResultPath) + SizeOfResultPath;
   cptr = CurrentPath;
   while (*cptr && sptr < zptr)
   {
      if (*cptr == '/') tptr = sptr;
      *sptr++ = *cptr++;
   }
   sptr = tptr;
   /* loop, stepping back one level for each "../" in the document path */
   while (dptr[0] == '.' && dptr[1] == '.' && dptr[2] == '/')
   {
      dptr += 3;
      if (sptr > ResultPath) sptr--;
      while (sptr > ResultPath && *sptr != '/') sptr--;
   }
   if (sptr > ResultPath && sptr < zptr)
      sptr++;
   else
   if (sptr < zptr)
      *sptr++ = '/';
   while (*dptr && sptr < zptr) *sptr++ = *dptr++;
   if (sptr >= zptr) return (-1);
   *sptr = '\0';
   if (Debug) fprintf (stdout, "ResultPath |%s|\n", ResultPath);
   return (sptr - ResultPath);
}

/*****************************************************************************/
/*
A server administration report on the server's mapping rules. This function
just wraps the reporting function, loading a temporary database if necessary
for reporting from the rule file.
*/

MapUrl_Report
(
struct RequestStruct *rqptr,
void *NextTaskFunction,
boolean UseServerDatabase,
char *VirtualHostNamePort
)
{
   register char  *cptr;

   int  status;
   struct MappingRuleListStruct  LocalRulesList;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MapUrl_Report() |%s|\n", VirtualHostNamePort);

   if (UseServerDatabase)
   {
      /* use mapping rules from supplied pointer */
      MapUrl_ReportNow (rqptr, UseServerDatabase, GlobalMappingRulesListPtr,
                        VirtualHostNamePort);
   }
   else
   {
      /* load temporary set of rules from mapping file */
      memset (&LocalRulesList, 0, sizeof(struct MappingRuleListStruct)); 
      LocalRulesList.RequestPtr = rqptr;
      cptr = MapUrl_LoadRules (&LocalRulesList);
      if (!cptr[0] && cptr[1])
      {
         /* error reported */
         rqptr->rqResponse.HttpStatus = 403;
         ErrorGeneral (rqptr, cptr+1, FI_LI);
      }
      else
         MapUrl_ReportNow (rqptr, UseServerDatabase, &LocalRulesList,
                           VirtualHostNamePort);
      MapUrl_FreeRules (&LocalRulesList);
      if (LocalRulesList.ProblemReportPtr != NULL)
         free (LocalRulesList.ProblemReportPtr);
   }

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Return a report on the HTTPd server's mamping rules ... now!  This function
blocks while executing.
*/

MapUrl_ReportNow
(
struct RequestStruct *rqptr,
boolean UseServerDatabase,
struct MappingRuleListStruct *rlptr,
char *VirtualHostNamePort
)
{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Mapping Rules</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Mapping Rules</H3>\n\
!%%\
!20%W\n";

   static char  ProblemReportFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH><FONT COLOR=\"#ff0000\">!UL Report!%s \
!%?At Startup\rDuring Load\r</FONT></TH></TR>\n\
<TR><TD><PRE>!HZ</PRE></TD></TR>\n\
</TABLE>\n";

   static char  VirtualFormFao [] =
"<FORM ACTION=\"!AZ\">\n\
<INPUT TYPE=hidden NAME=server VALUE=\"!%?yes\rno\r\">\n\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Virtual Server</TH></TR>\n\
<TR><TD><NOBR>\n\
<SELECT NAME=virtual>\n";

   static char  CheckPathFao [] =
"</SELECT>\n\
<INPUT TYPE=submit VALUE=\" select \">\n\
</NOBR>\n\
</TD></TR>\n\
</TABLE>\n\
</FORM>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Source: &quot;!%?Server\rFile\r&quot;</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=RIGHT>File:</TH>\
<TD ALIGN=LEFT>!AZ</TD>\
<TD>&nbsp;</TD><TH>[<A HREF=\"!AZ\">View</A>]</TH>\
</TR>\n\
<TR><TH ALIGN=RIGHT>!AZ</TH>\
<TD ALIGN=LEFT>!20%W</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH COLSPAN=3>Mapping Rules</TH></TR>\n\
<TR><TH ROWSPAN=2>Rule</TH><TH>Path</TH>\
<TH>Result/Setting</TH></TR>\n\
<TR><TH COLSPAN=2>Condition</TH></TR>\n\
<TR></TR>\n";

   static char  RuleFao [] = "<TR><TH>!AZ</TH><TD>!AZ</TD><TD>!AZ</TD></TR>\n";

   static char  RuleConditionalFao [] =
"<TR><TH ROWSPAN=2>!AZ</TH><TD>!AZ</TD><TD>!AZ</TD></TR>\n\
<TR><TD COLSPAN=2><TT>!AZ</TT></TD></TR>\n";

   static char  RuleVirtualFao [] = "<TR><TH COLSPAN=3>[[!AZ]]</TH></TR>\n";

   static char  UserMappingFao [] =
"!AZ\
</TABLE>\n\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>User Mapping Cache &nbsp;&nbsp\
<FONT SIZE=-1>(maximum !UL)</FONT></TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR>\
<TH></TH>\
<TH ALIGN=left><U>Name</U></TH>\
<TH ALIGN=left><U>Path</U></TH>\
<TH ALIGN=left><U>ODS</U></TH>\
<TH ALIGN=right><U>Hits</U>&nbsp;</TH>\
<TH ALIGN=left><U>Last</U></TH>\
<TH ALIGN=left><U>Reuse</U></TH>\
</TR>\n";

   static char  EntryFao [] =
"<TR>\
<TH ALIGN=right>!UL.&nbsp;</TH>\
<TD ALIGN=left>!AZ&nbsp;</TD>\
<TD ALIGN=left>!AZ/&nbsp;</TD>\
<TD ALIGN=right>!AZ</TD>\
<TD ALIGN=right>!UL&nbsp;</TD>\
<TD ALIGN=left><FONT SIZE=-1>!20%W</FONT>&nbsp;</TD>\
<TD ALIGN=right>!UL</TD>\
</TR>\n";

   static char  EndPageFao [] =
"</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
</BODY>\n\
</HTML>\n";

   register struct MappingRuleStruct  *mrptr;
   register struct ServiceStruct *svptr;
   register struct ListEntryStruct  *leptr;
   register struct MapUrlUserCacheStruct  *ucptr;
   register unsigned long  *vecptr;
   register char  *cptr;

   boolean  CheckFromFile;
   int  status,
        EntryCount;
   unsigned long  FaoVector [32];
   unsigned short  Length;
   char  Buffer [2048],
         RmsSubChar [2],
         TimeString [32];
   $DESCRIPTOR (BufferDsc, Buffer);

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "MapUrl_ReportNow() |%s|\n", VirtualHostNamePort);

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_MAPPING_RULES;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;
   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   if (VirtualHostNamePort[0])
   {
      *vecptr++ = "<H3>Virtual Server: !AZ</H3>\n";
      *vecptr++ = VirtualHostNamePort;
   }
   else
      *vecptr++ = "";
   *vecptr++ = &rqptr->rqTime.Vms64bit;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   if (rlptr->ProblemReportLength)
   {
      vecptr = FaoVector;
      *vecptr++ = rlptr->ProblemCount;
      *vecptr++ = (rlptr == GlobalMappingRulesListPtr);
      *vecptr++ = rlptr->ProblemReportPtr;

      status = NetWriteFaol (rqptr, ProblemReportFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   vecptr = FaoVector;
   *vecptr++ = ADMIN_REPORT_MAPPING;
   *vecptr++ = (rlptr == GlobalMappingRulesListPtr);

   status = NetWriteFaol (rqptr, VirtualFormFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   vecptr = FaoVector;
   *vecptr++ = VirtualHostNamePort[0];
   *vecptr++ = (ServiceCount == 1);

   status = NetWriteFaol (rqptr,
"<OPTION!%?\r SELECT\r VALUE=\"\">!%?none configured\rfor all services\r\n",
                          &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   if (ServiceCount > 1)
   {
      for (svptr = ServiceListHead; svptr != NULL; svptr = svptr->NextPtr)
      {
         vecptr = FaoVector;
         *vecptr++ = svptr->ServerHostPort;
         *vecptr++ = strsame (svptr->ServerHostPort, VirtualHostNamePort, -1);
         *vecptr++ = svptr->ServerHostPort;

         status = NetWriteFaol (rqptr,
                     "<OPTION VALUE=\"!AZ\"!%? SELECTED\r\r>!AZ\n",
                     &FaoVector);
         if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      }
   }

   vecptr = FaoVector;
   *vecptr++ = (rlptr == GlobalMappingRulesListPtr);
   *vecptr++ = rlptr->LoadFileName;
   *vecptr++ = MapVmsPath (rlptr->LoadFileName, rqptr);
   if (rlptr == GlobalMappingRulesListPtr)
   {
      *vecptr++ = "Loaded:";
      *vecptr++ = &rlptr->LoadBinTime;
   }
   else
   {
      *vecptr++ = "Revised:";
      *vecptr++ = &rlptr->RevBinTime;
   }

   status = NetWriteFaol (rqptr, CheckPathFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /*****************/
   /* mapping rules */
   /*****************/

   status = SS$_NORMAL;
   EntryCount = 0;

   for (mrptr = rlptr->HeadPtr; mrptr != NULL; mrptr = mrptr->NextPtr)
   {
      if (Debug)
         fprintf (stdout, "Rule |%d|%s|%s|%s|\n",
                  mrptr->RuleType, mrptr->TemplatePtr, mrptr->ResultPtr,
                  mrptr->VirtualServerHostPortPtr);

      /* if filtering on a virtual server and this not a general rule */
      if (VirtualHostNamePort[0] &&
          mrptr->RuleType == MAPURL_RULE_VIRTUAL)
      {
         do {

            /* if the following rules apply to all services then break */
            if (*mrptr->VirtualServerHostPortPtr == '*')
               break;

            /* if the request service matches the rule service then break */
            if (!strcmp (VirtualHostNamePort, mrptr->VirtualServerHostPortPtr))
               break;

            mrptr = mrptr->NextVirtualServiceRulePtr;

         } while (mrptr != NULL);

         /* break from outer loop if reached the end of the rules */
         if (mrptr == NULL) break;
      }

      EntryCount++;

      if (mrptr->RuleType == MAPURL_RULE_VIRTUAL)
      {
         /* don't need to see these rules for a single virtual server */
         if (VirtualHostNamePort[0]) continue;

         status = NetWriteFao (rqptr, RuleVirtualFao,
                               mrptr->VirtualServerHostPortPtr);
         if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
         continue;
      }

      vecptr = FaoVector;

      if (mrptr->RuleType == MAPURL_RULE_EXEC)
      {
         if (mrptr->IsCgiPlusScript)
            *vecptr++ = "exec+";
         else
            *vecptr++ = "exec";
      }
      else
      if (mrptr->RuleType == MAPURL_RULE_FAIL)
         *vecptr++ = "fail";
      else
      if (mrptr->RuleType == MAPURL_RULE_MAP)
         *vecptr++ = "map";
      else
      if (mrptr->RuleType == MAPURL_RULE_PASS)
         *vecptr++ = "pass";
      else
      if (mrptr->RuleType == MAPURL_RULE_REDIRECT)
         *vecptr++ = "redirect";
      else
      if (mrptr->RuleType == MAPURL_RULE_SCRIPT)
      {
         if (mrptr->IsCgiPlusScript)
            *vecptr++ = "script+";
         else
            *vecptr++ = "script";
      }
      else
      if (mrptr->RuleType == MAPURL_RULE_SET)
         *vecptr++ = "set";
      else
      if (mrptr->RuleType == MAPURL_RULE_UXEC)
         *vecptr++ = "uxec";
      else
      if (mrptr->RuleType == MAPURL_RULE_USER)
         *vecptr++ = "user";
      else
         *vecptr++ = "*ERROR*";

      *vecptr++ = mrptr->TemplatePtr;

      if (mrptr->RuleType == MAPURL_RULE_SET)
         *vecptr++ = MapUrl_ExplainPathSet (mrptr);
      else
         *vecptr++ = mrptr->ResultPtr;

      if (mrptr->ConditionalPtr[0])
      {
         *vecptr++ = mrptr->ConditionalPtr;
         status = NetWriteFaol (rqptr, RuleConditionalFao, &FaoVector);
      }
      else
         status = NetWriteFaol (rqptr, RuleFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   vecptr = FaoVector;
   if (EntryCount)
      *vecptr++ = "";
   else
      *vecptr++ = "<TR><TD COLSPAN=3><I>(none)</I></TD></TR>\n";
   *vecptr++ = MapUrlUserNameCacheEntries;

   status = NetWriteFaol (rqptr, UserMappingFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /*****************/
   /* user mappings */
   /*****************/

   EntryCount = 0;

   /* process the cache entry list from most to least recent */
   for (leptr = MapUrlUserNameCacheList.HeadPtr;
        leptr != NULL;
        leptr = leptr->NextPtr)
   {
      ucptr = (struct MapUrlUserCacheStruct*)leptr;

      /* if empty name, must have been reset, no point in going any further */
      if (!ucptr->UserName[0]) break;

      vecptr = FaoVector;
      *vecptr++ = ++EntryCount;
      *vecptr++ = ucptr->UserName;
      *vecptr++ = ucptr->UserPath;

#ifdef ODS_EXTENDED
      if (ucptr->PathOds == 2)
         *vecptr++ = "ODS-2";
      else
      if (ucptr->PathOds == 5)
         *vecptr++ = "ODS-5";
      else
         *vecptr++ = "?";
#else /* ODS_EXTENDED */
      *vecptr++ = "";
#endif /* ODS_EXTENDED */

      *vecptr++ = ucptr->HitCount;
      *vecptr++ = &ucptr->LastBinaryTime;
      *vecptr++ = ucptr->ReuseCount;

      status = NetWriteFaol (rqptr, EntryFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   vecptr = FaoVector;
   if (!EntryCount)
   {
      static char  NotNone [] =
"<TR><TD ALIGN=center COLSPAN=6><I>(none)</I></TD></TR>\n";

      status = NetWriteFaol (rqptr, NotNone, NULL);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   status = NetWriteFaol (rqptr, EndPageFao, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
}

/*****************************************************************************/
/*
Report an individual rule during processing of a mapping rule check.
*/

MapUrl_WatchRule
(
struct RequestStruct *rqptr,
struct MappingRuleStruct  *mrptr,
char *PathPtr,
int PathOds,
int Match
)
{
   static char  RuleFao [] = "!AZ!AZ  !AZ  !8AZ  !AZ  !AZ!%%\n",
                RuleVirtualFao [] = "!AZ!AZ  !AZ  !8AZ  [[!AZ]]\n";

   register unsigned long  *vecptr;

   int  status;
   unsigned short  Length;
   unsigned long  FaoVector [32];
   char  Buffer [2048],
         RmsSubChar [2];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MapUrl_WatchRule()\n");

   vecptr = FaoVector;
   *vecptr++ = PathPtr;

#ifdef ODS_EXTENDED
   if (PathOds == 2)
      *vecptr++ = "  ODS-2";
   else
   if (PathOds == 5)
      *vecptr++ = "  ODS-5";
   else
      *vecptr++ = "  ods-2";
#else /* ODS_EXTENDED */
   *vecptr++ = "";
#endif /* ODS_EXTENDED */
 
   if (mrptr->RuleType == MAPURL_RULE_VIRTUAL)
   {
      if (Match == MAPURL_REPORT_MATCH_NOT)
         *vecptr++ = "N.";
      else
         *vecptr++ = "Y.";
      *vecptr++ = "service";
      *vecptr++ = mrptr->VirtualServerHostPortPtr;

      status = WriteFaol (Buffer, sizeof(Buffer), &Length,
                          RuleVirtualFao, &FaoVector);
   }
   else
   {
      if (Match == MAPURL_REPORT_MATCH_NOT)
         *vecptr++ = "..";
      else
      if (Match == MAPURL_REPORT_MATCH_RULE)
         *vecptr++ = "YN";
      else
      if (Match == MAPURL_REPORT_MATCH_RULECOND)
         *vecptr++ = "YY";
      else
      if (Match ==  MAPURL_REPORT_MATCH_RULENOCOND)
         *vecptr++ = "Y-";
      else
         *vecptr++ = "??";

      switch (mrptr->RuleType)
      {
         case MAPURL_RULE_EXEC :
            if (mrptr->IsCgiPlusScript)
               *vecptr++ = "EXEC+";
            else
               *vecptr++ = "EXEC";
            break;
         case MAPURL_RULE_FAIL :
            *vecptr++ = "FAIL";
            break;
         case MAPURL_RULE_MAP :
            *vecptr++ = "MAP";
            break;
         case MAPURL_RULE_PASS :     
            *vecptr++ = "PASS";
            break;
         case MAPURL_RULE_REDIRECT :
            *vecptr++ = "REDIRECT";
            break;
         case MAPURL_RULE_SCRIPT :
            if (mrptr->IsCgiPlusScript)
               *vecptr++ = "SCRIPT+";
            else
               *vecptr++ = "SCRIPT";
            break;
         case MAPURL_RULE_SET :
            *vecptr++ = "SET";
            break;
         case MAPURL_RULE_USER :
            *vecptr++ = "USER";
            break;
         case MAPURL_RULE_UXEC :
            if (mrptr->IsCgiPlusScript)
               *vecptr++ = "UXEC+";
            else
               *vecptr++ = "UXEC";
            break;
         default :
            *vecptr++ = "*ERROR*";
      }

      *vecptr++ = mrptr->TemplatePtr;

      if (mrptr->RuleType == MAPURL_RULE_SET)
         *vecptr++ = MapUrl_ExplainPathSet (mrptr);
      else
         *vecptr++ = mrptr->ResultPtr;

      if (mrptr->ConditionalPtr[0])
      {
         *vecptr++ = " !AZ";
         *vecptr++ = mrptr->ConditionalPtr;
      }
      else
         *vecptr++ = "";

      status = WriteFaol (Buffer, sizeof(Buffer), &Length,
                          RuleFao, &FaoVector);
   }

   if (VMSnok (status) || status == SS$_BUFFEROVF)
      ErrorNoticed (status, "WriteFaol()", FI_LI);

   WatchData (Buffer, Length); 
}

/*****************************************************************************/
/*
Display mapping rules used to resolve the path in the query string.  Called
from the Request.c modules.  For HTTP report, uses blocking network write.
*/

char* MapUrl_ExplainPathSet (struct MappingRuleStruct *mrptr)

{
   static char  SetFao [] =
"!AZ!AZ!AZ!AZ!AZ!AZ!AZ!AZ!AZ!AZ!AZ!AZ!AZ!%%!%%!%%!%%!%%!%%";
   static char  Buffer [256];

   register unsigned long  *vecptr;

   int  status;
   unsigned long  FaoVector [64];
   char  RmsSubChar [2];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MapUrl_ExplainPathSet()\n");

   vecptr = FaoVector;

   if (mrptr->mpPathSet.NoAuthMapped)
      *vecptr++ = " NOauth=MAPPED";
   else
   if (mrptr->mpPathSet.AuthMapped)
      *vecptr++ = " auth=MAPPED";
   else
      *vecptr++ = "";

   if (mrptr->mpPathSet.NoAuthOnce)
      *vecptr++ = " NOauth=ONCE";
   else
   if (mrptr->mpPathSet.AuthOnce)
      *vecptr++ = " auth=ONCE";
   else
      *vecptr++ = "";

   if (mrptr->mpPathSet.NoCache)
      *vecptr++ = " NOcache";
   else
   if (mrptr->mpPathSet.Cache)
      *vecptr++ = " cache";
   else
      *vecptr++ = "";

   if (mrptr->mpPathSet.NoExpired)
      *vecptr++ = " NOexpired";
   else
   if (mrptr->mpPathSet.Expired)
      *vecptr++ = " expired";
   else
      *vecptr++ = "";

   if (mrptr->mpPathSet.NoLog)
      *vecptr++ = " NOlog";
   else
   if (mrptr->mpPathSet.Log)
      *vecptr++ = " log";
   else
      *vecptr++ = "";

   if (mrptr->mpPathSet.MapNonEmpty)
      *vecptr++ = " map=NONEMPTY";
   else
   if (mrptr->mpPathSet.MapEmpty)
      *vecptr++ = " map=EMPTY";
   else
      *vecptr++ = "";

   if (mrptr->mpPathSet.NoMapOnce)
      *vecptr++ = " NOmap=ONCE";
   else
   if (mrptr->mpPathSet.MapOnce)
      *vecptr++ = " map=ONCE";
   else
      *vecptr++ = "";

   if (mrptr->mpPathSet.Ods == 2)
      *vecptr++ = "ODS-2";
   else
   if (mrptr->mpPathSet.Ods == 5)
      *vecptr++ = "ODS-5";
   else
      *vecptr++ = "";

   if (mrptr->mpPathSet.ScriptNoFind)
      *vecptr++ = " script=NOFIND";
   else
   if (mrptr->mpPathSet.ScriptFind)
      *vecptr++ = " script=FIND";
   else
      *vecptr++ = "";

   if (mrptr->mpPathSet.NoPrivSsi)
      *vecptr++ = " ssi=NOPRIV";
   else
   if (mrptr->mpPathSet.PrivSsi)
      *vecptr++ = " ssi=PRIV";
   else
      *vecptr++ = "";

   if (mrptr->mpPathSet.NoProfile)
      *vecptr++ = " NOprofile";
   else
   if (mrptr->mpPathSet.Profile)
      *vecptr++ = " profile";
   else
      *vecptr++ = "";

   if (mrptr->mpPathSet.ReportBasic)
      *vecptr++ = " report=BASIC";
   else
   if (mrptr->mpPathSet.ReportDetailed)
      *vecptr++ = " report=DETAILED";
   else
      *vecptr++ = "";

   if (mrptr->mpPathSet.SSLCGIvar == SESOLA_CGI_VAR_APACHE_MOD_SSL)
      *vecptr++ = " SSLCGI=Apache_mod_SSL";
   else
   if (mrptr->mpPathSet.SSLCGIvar == SESOLA_CGI_VAR_PURVEYOR)
      *vecptr++ = " SSLCGI=Purveyor";
   else
      *vecptr++ = "";

   if (mrptr->mpPathSet.NoStmLF)
      *vecptr++ = " NOstmLF";
   else
   if (mrptr->mpPathSet.StmLF)
      *vecptr++ = " stmLF";
   else
      *vecptr++ = "";

   if (mrptr->mpPathSet.CgiPrefixPtr == NULL)
      *vecptr++ = "";
   else
   {
      *vecptr++ = " CGIprefix=!AZ";
      *vecptr++ = mrptr->mpPathSet.CgiPrefixPtr;
   }

   if (mrptr->mpPathSet.CharsetPtr == NULL)
      *vecptr++ = "";
   else
   {
      *vecptr++ = " charset=!AZ";
      *vecptr++ = mrptr->mpPathSet.CharsetPtr;
   }

   if (mrptr->mpPathSet.ContentTypePtr == NULL)
      *vecptr++ = "";
   else
   {
      *vecptr++ = " content=!AZ";
      *vecptr++ = mrptr->mpPathSet.ContentTypePtr;
   }

   if (mrptr->mpPathSet.IndexPtr == NULL)
      *vecptr++ = "";
   else
   {
      *vecptr++ = " index=!AZ";
      *vecptr++ = mrptr->mpPathSet.IndexPtr;
   }

   if (mrptr->mpPathSet.ScriptAsPtr == NULL)
      *vecptr++ = "";
   else
   {
      *vecptr++ = " script=AS=!AZ";
      *vecptr++ = mrptr->mpPathSet.ScriptAsPtr;
   }

   if (mrptr->mpPathSet.RmsSubChar)
   {
      RmsSubChar[0] = mrptr->mpPathSet.RmsSubChar;
      RmsSubChar[1] = '\0';
      *vecptr++ = " RMSchar=!AZ";
      *vecptr++ = RmsSubChar;
   }
   else
      *vecptr++ = "";

   status = WriteFaol (Buffer, sizeof(Buffer), NULL, SetFao, &FaoVector);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
   {
      ErrorNoticed (status, "WriteFaol()", FI_LI);
      return ("*ERROR*");
   }
   return (Buffer);
}

/*****************************************************************************/
/*
Display mapping rules used to resolve the path in the query string.  Called
from the Request.c modules.  For HTTP report, uses blocking network write.
*/

MapUrl_ControlReload
(
struct RequestStruct *rqptr,
void *NextTaskFunction
)
{
   register char  *cptr;

   int  status;
   struct MappingRuleListStruct  *rlptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MapUrl_ControlReload()\n");

   rlptr = GlobalMappingRulesListPtr;
   cptr = MapUrl_LoadRules (rlptr);
   /* if error reported */
   if (!cptr[0] && cptr[1])
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, cptr+1, FI_LI);
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   /* purge DCL module script task list and script name cache */
   DclLoadedMappingRules();

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;

   if (rlptr->ProblemReportLength)
   {
      ReportSuccess (rqptr,
"$Server !AZ mapping rules reloaded.\n\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH><FONT COLOR=\"#ff0000\">!UL Report!%s During Load</FONT></TH></TR>\n\
<TR><TD><PRE>!HZ</PRE></TD></TR>\n\
</TABLE>\n",
         ServerHostPort, rlptr->ProblemCount, rlptr->ProblemReportPtr);
   }
   else
      ReportSuccess (rqptr, "$Server !AZ mapping rules reloaded.",
                     ServerHostPort);

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Scan the conditional string evaluating the conditions!  Return true or false.
Anything it cannot understand it ignores!
*/

boolean MapUrl_Conditional
(
struct RequestStruct  *rqptr,
struct MappingRuleStruct  *mrptr
)
{
   register char  *cptr, *sptr, *zptr;

   int  HostNetMaskCount;
   boolean  NegateThisCondition,
            NegateEntireConditional,
            Result,
            SoFarSoGood;
   int  ConditionalCount;
   char  Scratch [2048];
   struct NetMaskStruct  NetMask;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "MapUrl_Conditional() %d |%s|\n",
               rqptr, mrptr->ConditionalPtr);

   ConditionalCount = HostNetMaskCount = 0;
   NegateEntireConditional = NegateThisCondition = SoFarSoGood = false;
   cptr = mrptr->ConditionalPtr;
   while (*cptr)
   {
      while (ISLWS(*cptr)) cptr++;
      if (!*cptr) break;

      if (*cptr == '[' || (*cptr == '!' && *(cptr+1) == '['))
      {
         if (*cptr == '!')
         {
            NegateEntireConditional = true;
            cptr++;
         }
         else
            NegateEntireConditional = false;
         cptr++;
         ConditionalCount = 0;
         SoFarSoGood = false;
         continue;
      }
      if (*cptr == ']')
      {
         cptr++;
         if (NegateEntireConditional)
         {
            SoFarSoGood = !SoFarSoGood;
            NegateEntireConditional = false;
         }
         if (ConditionalCount && !SoFarSoGood) return (false);
         continue;
      }
      if (SoFarSoGood)
      {
         if (NegateEntireConditional)
         {
            SoFarSoGood = !SoFarSoGood;
            NegateEntireConditional = false;
         }
         /* at least one OK, skip to the end of the conditional */
         while (*cptr && *cptr != ']') cptr++;
         if (!*cptr) break;
      }

      NegateThisCondition = Result = false;
      zptr = (sptr = Scratch) + sizeof(Scratch);

      if (*cptr == '!')
      {
         cptr++;
         NegateThisCondition = true;
      }

      switch (*(unsigned short*)cptr)
      {
         case 'AC' :

            /*************/
            /* "Accept:" */
            /*************/

            ConditionalCount++;
            cptr += 3;
            while (*cptr && !ISLWS(*cptr) && *cptr != ']' && sptr < zptr)
               *sptr++ = *cptr++;
            if (sptr >= zptr) return (false);
            *sptr = '\0';
            if (rqptr->rqHeader.AcceptPtr != NULL)
               Result = MapUrl_ConditionalList (rqptr, Scratch,
                                                rqptr->rqHeader.AcceptPtr);
            break;
             
         case 'AL' :

            /**********************/
            /* "Accept-Language:" */
            /**********************/

            ConditionalCount++;
            cptr += 3;
            while (*cptr && !ISLWS(*cptr) && *cptr != ']' && sptr < zptr)
               *sptr++ = *cptr++;
            if (sptr >= zptr) return (false);
            *sptr = '\0';
            if (rqptr->rqHeader.AcceptLangPtr != NULL)
               Result = MapUrl_ConditionalList (rqptr, Scratch,
                                                rqptr->rqHeader.AcceptLangPtr);
            break;

         case 'AS' :

            /*********************/
            /* "Accept-Charset:" */
            /*********************/

            ConditionalCount++;
            cptr += 3;
            while (*cptr && !ISLWS(*cptr) && *cptr != ']' && sptr < zptr)
               *sptr++ = *cptr++;
            if (sptr >= zptr) return (false);
            *sptr = '\0';
            if (rqptr->rqHeader.AcceptCharsetPtr != NULL)
               Result = MapUrl_ConditionalList (rqptr, Scratch,
                                                rqptr->rqHeader.AcceptCharsetPtr);
            break;

         case 'CK' :

            /**********/
            /* cookie */
            /**********/

            ConditionalCount++;
            cptr += 3;
            while (*cptr && !ISLWS(*cptr) && *cptr != ']' && sptr < zptr)
               *sptr++ = *cptr++;
            if (sptr >= zptr) return (false);
            *sptr = '\0';
            if (rqptr->rqHeader.CookiePtr != NULL)
               Result = (SearchTextString (rqptr->rqHeader.CookiePtr,
                            Scratch, false, false, NULL) != NULL);
            break;

         case 'EX' :

            /**********************/
            /* extended file path */
            /**********************/

            ConditionalCount++;
            cptr += 3;
            while (*cptr && !ISLWS(*cptr) && *cptr != ']') cptr++;
            Result = rqptr->PathOdsExtended;
            break;

         case 'HM' :

            /****************************/
            /* client host network mask */
            /****************************/

            ConditionalCount++;
            cptr += 3;
            while (*cptr && !ISLWS(*cptr) && *cptr != ']' && sptr < zptr)
               *sptr++ = *cptr++;
            if (sptr >= zptr) return (false);
            *sptr = '\0';
            if (HostNetMaskCount < MAPURL_HOST_NETMASK_MAX &&
                mrptr->HostNetMask[HostNetMaskCount].BitsMask)
            {
               /* get the previously cached mask */
               memcpy (&NetMask,
                       &mrptr->HostNetMask[HostNetMaskCount],
                       sizeof(NetMask));
               HostNetMaskCount++;
            }
            else
            {
               /* if there's a problem with the mask then just fail it */
               if (ParseNetMask (Scratch, &NetMask) == NULL) return (false);
               /* cache the mask, saving a bit of processing next time */
               if (HostNetMaskCount < MAPURL_HOST_NETMASK_MAX)
               {
                  memcpy (&mrptr->HostNetMask[HostNetMaskCount],
                          &NetMask,
                          sizeof(NetMask));
                  HostNetMaskCount++;
               }
            }
            Result = ((NetMask.BitsNetwork & NetMask.BitsMask) ==
                      (rqptr->rqNet.ClientIpAddress & NetMask.BitsMask));
            break;

         case 'HO' :

            /****************************/
            /* client host name/address */
            /****************************/

            ConditionalCount++;
            cptr += 3;
            while (*cptr && !ISLWS(*cptr) && *cptr != ']' && sptr < zptr)
               *sptr++ = *cptr++;
            if (sptr >= zptr) return (false);
            *sptr = '\0';
            for (sptr = Scratch; *sptr && !isalnum(*sptr); sptr++);
            if (isdigit(*sptr))
               Result = (SearchTextString (rqptr->rqNet.ClientIpAddressString,
                            Scratch, false, false, NULL) != NULL);
            else
               Result = (SearchTextString (rqptr->rqNet.ClientHostName,
                            Scratch, false, false, NULL) != NULL);
            break;

         case 'FO' :

            /*******************/
            /* proxy forwarded */
            /*******************/

            ConditionalCount++;
            cptr += 3;
            while (*cptr && !ISLWS(*cptr) && *cptr != ']' && sptr < zptr)
               *sptr++ = *cptr++;
            if (sptr >= zptr) return (false);
            *sptr = '\0';
            if (rqptr->rqHeader.ForwardedPtr != NULL)
               Result = MapUrl_ConditionalList (rqptr, Scratch,
                                                rqptr->rqHeader.ForwardedPtr);
            break;

         case 'ME' :

            /***************/
            /* HTTP method */
            /***************/

            ConditionalCount++;
            cptr += 3;
            while (*cptr && !ISLWS(*cptr) && *cptr != ']' && sptr < zptr)
               *sptr++ = *cptr++;
            if (sptr >= zptr) return (false);
            *sptr = '\0';
            Result = (SearchTextString (rqptr->rqHeader.MethodName,
                         Scratch, false, false, NULL) != NULL);
            break;

         case 'QS' :

            /****************/
            /* query string */
            /****************/

            ConditionalCount++;
            cptr += 3;
            while (*cptr && !ISLWS(*cptr) && *cptr != ']' && sptr < zptr)
               *sptr++ = *cptr++;
            if (sptr >= zptr) return (false);
            *sptr = '\0';
            Result = (SearchTextString (rqptr->rqHeader.QueryStringPtr,
                         Scratch, false, false, NULL) != NULL);
            break;

         case 'RF' :

            /****************/
            /* refering URL */
            /****************/

            ConditionalCount++;
            cptr += 3;
            while (*cptr && !ISLWS(*cptr) && *cptr != ']' && sptr < zptr)
               *sptr++ = *cptr++;
            if (sptr >= zptr) return (false);
            *sptr = '\0';
            if (rqptr->rqHeader.RefererPtr != NULL)
               Result = (SearchTextString (rqptr->rqHeader.RefererPtr,
                            Scratch, false, false, NULL) != NULL);
            break;

         case 'RU' :

            /***************/
            /* remote user */
            /***************/

            ConditionalCount++;
            cptr += 3;
            while (*cptr && !ISLWS(*cptr) && *cptr != ']' && sptr < zptr)
               *sptr++ = *cptr++;
            if (sptr >= zptr) return (false);
            *sptr = '\0';
            if (!rqptr->RemoteUser[0])
               Result = MapUrl_ConditionalList (rqptr, Scratch,
                                                rqptr->RemoteUser);
            break;

         case 'SC' :

            /****************************************/
            /* request scheme ("http:" or "https:") */
            /****************************************/

            ConditionalCount++;
            cptr += 3;
            /* also ignore any trailing colon on the scheme string */
            while (*cptr && !ISLWS(*cptr) && *cptr != ':' && *cptr != ']' &&
                   sptr < zptr)
               *sptr++ = *cptr++;
            if (sptr >= zptr) return (false);
            *sptr = '\0';
            if (*cptr == ':') cptr++;
            /* any trailing colon has been stripped */
            if (strsame (Scratch, "https", -1) &&
                rqptr->ServicePtr->RequestScheme == SCHEME_HTTPS)
               Result = true;
            else
            if (strsame (Scratch, "http", -1) &&
                rqptr->ServicePtr->RequestScheme == SCHEME_HTTP)
               Result = true;
            else
               Result = false;

            break;

         case 'SN' :

            /***************/
            /* server name */
            /***************/

            ConditionalCount++;
            cptr += 3;
            while (*cptr && !ISLWS(*cptr) && *cptr != ']' && sptr < zptr)
               *sptr++ = *cptr++;
            if (sptr >= zptr) return (false);
            *sptr = '\0';
            Result = (SearchTextString (rqptr->ServicePtr->ServerHostName,
                         Scratch, false, false, NULL) != NULL);
            break;

         case 'SP' :

            /***************/
            /* server port */
            /***************/

            ConditionalCount++;
            cptr += 3;
            while (*cptr && !ISLWS(*cptr) && *cptr != ']' && sptr < zptr)
               *sptr++ = *cptr++;
            if (sptr >= zptr) return (false);
            *sptr = '\0';
            Result = (SearchTextString (rqptr->ServicePtr->ServerPortString,
                         Scratch, false, false, NULL) != NULL);
            break;

         case 'UA' :

            /*****************/
            /* "User-Agent:" */
            /*****************/

            ConditionalCount++;
            cptr += 3;
            while (*cptr && !ISLWS(*cptr) && *cptr != ']' && sptr < zptr)
               *sptr++ = *cptr++;
            if (sptr >= zptr) return (false);
            *sptr = '\0';
            if (rqptr->rqHeader.UserAgentPtr != NULL)
               Result = (SearchTextString (rqptr->rqHeader.UserAgentPtr,
                            Scratch, false, false, NULL) != NULL);
            break;

         case 'UD' :

            /****************/
            /* user details */
            /****************/

            ConditionalCount++;
            cptr += 3;
            while (*cptr && !ISLWS(*cptr) && *cptr != ']' && sptr < zptr)
               *sptr++ = *cptr++;
            if (sptr >= zptr) return (false);
            *sptr = '\0';
            if (rqptr->rqAuth.UserDetailsPtr != NULL)
               Result = (SearchTextString (rqptr->rqAuth.UserDetailsPtr,
                            Scratch, false, false, NULL) != NULL);
            break;

         case 'VS' :
         case 'HH' :  /* backward compatibility */

            /******************************************/
            /* virtual service ("Host:") name/address */
            /******************************************/

            ConditionalCount++;
            cptr += 3;
            while (*cptr && !ISLWS(*cptr) && *cptr != ']' && sptr < zptr)
               *sptr++ = *cptr++;
            if (sptr >= zptr) return (false);
            *sptr = '\0';
            if (rqptr->rqHeader.HostPtr != NULL)
               Result = (SearchTextString (rqptr->rqHeader.HostPtr,
                            Scratch, false, false, NULL) != NULL);
            break;

         default :

            /*******************/
            /* unknown, ignore */
            /*******************/

            /* should never occur due to basic check in MapUrl_LoadRules()! */
            while (*cptr && !ISLWS(*cptr) && *cptr != ']') cptr++;
            continue;

      }

      if (NegateThisCondition)
         SoFarSoGood = SoFarSoGood || !Result;
      else
         SoFarSoGood = SoFarSoGood || Result;
   }

   if (Debug)
      fprintf (stdout, "%d %d %d\n",
               ConditionalCount, NegateEntireConditional, SoFarSoGood);

   if (NegateEntireConditional) SoFarSoGood = !SoFarSoGood;
   if (ConditionalCount)
      return (SoFarSoGood);
   else
      return (true);
}

/*****************************************************************************/
/*
Compare single "??:" conditional string to each of a comma-separated list in
the form "item" or "item1, item2, item3", etc. String may contain '*' and '%'
wildcards.  We can munge the list string like this because we're operating at
AST-delivery level and cannot be preempted!
*/

boolean MapUrl_ConditionalList
(
struct RequestStruct  *rqptr,
char *String,
char *List
)
{
   register char  *cptr, *lptr;
   char  c;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MapUrl_ConditionalList() |%s|\n", List);

   if ((lptr = List) == NULL) return (false);
   while (*lptr)
   {
      /* spaces and commas are element separators, step over */
      while (ISLWS(*lptr) || *lptr == ',') lptr++;
      /* if end of list (or empty) then finished */
      if (!*lptr) return (false);
      /* find end of this element, save next character, terminate element */
      for (cptr = lptr; *lptr && !ISLWS(*lptr) && *lptr != ','; lptr++);
      c = *lptr;
      *lptr = '\0';
      /* look for what we want */
      cptr = SearchTextString (cptr, String, false, false, NULL);
      /* restore list */
      *lptr = c;
      /* if found then finished */
      if (cptr != NULL) return (true);
   }
   /* ran out of list elements, so it can't be a match! */
   return (false);
}

/*****************************************************************************/
/*
Get the path representing the username default device/directory.  This can be
retrieved from a cache, or retrieved from directly from the SYSUAF and the
cache subsequently updated.  The 'MAPURL_USER_RULE_FORBIDDEN_MSG' used to
return a user-access-denied to the calling routine, is designed to mask the
actual reason for denial.  This is done to help prevent the leakage of user
account information by being able to differentiate between accounts that exist
and those that don't, by looking at the message.  RequestExecute() checks for
this message and converts it into a "directory not found" message, the same as
that generated if a user does not have a [.WWW] subdirectory in the home area.
*/ 

char* MapUrl_VmsUserName
(
struct RequestStruct* rqptr,
char *UserNamePtr,
int *PathOdsPtr
)
{
   /* UAI flags that disallow SYSUAF-controlled account access */
   static unsigned long  DisallowVmsFlags =
          UAI$M_DISACNT | UAI$M_PWD_EXPIRED | UAI$M_PWD2_EXPIRED |
          UAI$M_CAPTIVE | UAI$M_RESTRICTED;

   static unsigned long  Context = -1;

   static unsigned long  UaiFlags;
   static unsigned long  UaiPriv [2];
   static char  UaiDefDev [MAPURL_USER_DEFDEV_SIZE+1],
                UaiDefDir [MAPURL_USER_DEFDIR_SIZE+1],
                UserName [MAPURL_USER_NAME_SIZE+1],
                UserPath [MAPURL_USER_PATH_SIZE+1];
   static $DESCRIPTOR (UserNameDsc, UserName);

   static struct {
      short BufferLength;
      short ItemCode;
      void  *BufferPtr;
      void  *LengthPtr;
   } UaiItems [] = 
   {
      { sizeof(UaiFlags), UAI$_FLAGS, &UaiFlags, 0 },
      { sizeof(UaiPriv), UAI$_PRIV, &UaiPriv, 0 },
      { sizeof(UaiDefDev), UAI$_DEFDEV, &UaiDefDev, 0 },
      { sizeof(UaiDefDir), UAI$_DEFDIR, &UaiDefDir, 0 },
      { 0,0,0,0 }
   };

   register char  *cptr, *sptr, *zptr;

   int  status,
        PathOds;
   char  UserDefault [MAPURL_USER_DEFDEV_SIZE+MAPURL_USER_DEFDIR_SIZE+1];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MapUrl_VmsUserName() |%s|\n", UserNamePtr);

   zptr = (sptr = UserName) + sizeof(UserName);
   for (cptr = UserNamePtr; *cptr && sptr < zptr; *sptr++ = toupper(*cptr++));
   if (sptr >= zptr) return (MAPURL_USER_RULE_FORBIDDEN_MSG);
   *sptr = '\0';
   if (Debug) fprintf (stdout, "UserName |%s|\n", UserName);
   UserNameDsc.dsc$w_length = sptr - UserName;

   /* look for it, and if found, return it from the cache */
   if ((cptr =
        MapUrl_VmsUserNameCache (rqptr, UserName, NULL, PathOdsPtr)) != NULL)
      return (cptr);

   /***************************************/
   /* get the information from the SYSUAF */
   /***************************************/

   /* turn on SYSPRV to allow access to SYSUAF records */
   EnableSysPrv();

   status = sys$getuai (0, &Context, &UserNameDsc, &UaiItems, 0, 0, 0);
   if (Debug) fprintf (stdout, "sys$getuai() %%X%08.08X\n", status);

   /* turn off SYSPRV */
   DisableSysPrv();

   if (VMSnok (status)) 
   {
      if (status == RMS$_RNF)
      {
         if (rqptr->WatchItem &&
             (WatchEnabled & WATCH_MAPPING))
            WatchThis (rqptr, FI_LI, WATCH_MAPPING,
                       "USER fail !AZ unknown", UserName);
         return (MAPURL_USER_RULE_FORBIDDEN_MSG);
      }
      if (rqptr->WatchItem &&
          (WatchEnabled & WATCH_MAPPING))
         WatchThis (rqptr, FI_LI, WATCH_MAPPING,
                    "USER sys$getuai() %X!8XL %!%M", status, status);
      return (MAPURL_USER_RULE_FORBIDDEN_MSG);
   }

   /* automatically disallow if any of these flags are set! */
   if (UaiFlags & DisallowVmsFlags)
   {
      if (Debug) fprintf (stdout, "failed on flags\n");
      if (rqptr->WatchItem &&
          (WatchEnabled & WATCH_MAPPING))
         WatchThis (rqptr, FI_LI, WATCH_MAPPING,
                    "USER !AZ fail SYSUAF flags", UserName);
      return (MAPURL_USER_RULE_FORBIDDEN_MSG);
   }

   if (!AuthPolicySysUafRelaxed && (UaiPriv[0] & PRV$M_SYSPRV))
   {
      /* not allowing all accounts, exclude those with extended privileges */
      if (Debug) fprintf (stdout, "failed on privileges\n");
      if (rqptr->WatchItem &&
          (WatchEnabled & WATCH_MAPPING))
         WatchThis (rqptr, FI_LI, WATCH_MAPPING,
                    "USER !AZ fail SYSUAF privileges", UserName);
      return (MAPURL_USER_RULE_FORBIDDEN_MSG);
   }

   zptr = (sptr = UserDefault) + sizeof(UserDefault);
   for (cptr = UaiDefDev+1; UaiDefDev[0] && sptr < zptr; UaiDefDev[0]--)
      *sptr++ = *cptr++;
   for (cptr = UaiDefDir+1; UaiDefDir[0] && sptr < zptr; UaiDefDir[0]--)
      *sptr++ = *cptr++;
   if (sptr >= zptr)
      return (MAPURL_USER_RULE_FORBIDDEN_MSG);
   *sptr = '\0';
   if (Debug) fprintf (stdout, "UserDefault |%s|\n", UserDefault);

   /* generate a URL-style version of the VMS specification */
   MapUrl_VmsToUrl (UserPath, UserDefault, sizeof(UserPath), true,
                    rqptr->PathOdsExtended);

#ifdef ODS_EXTENDED

   if (OdsExtended)
   {
      /* on-disk-structure of user area */
      PathOds = MapUrl_VolumeOds (UserDefault);
      if (PathOds && (PathOds != 2 && PathOds != 5))
      {
         if (rqptr->WatchItem &&
             (WatchEnabled & WATCH_MAPPING))
            WatchThis (rqptr, FI_LI, WATCH_MAPPING,
                       "USER !AZ !AZ ODS-? %X8XL %!%M",
                       UserName, UserDefault, PathOds, PathOds);
         return (MAPURL_USER_RULE_FORBIDDEN_MSG);
      }
   }
   else

#endif /* ODS_EXTENDED */

      PathOds = 0;

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_MAPPING))
      WatchThis (rqptr, FI_LI, WATCH_MAPPING,
                 "USER !AZ !AZ !AZ ODS-!UL",
                 UserName, UserDefault, UserPath, PathOds);

   /* trim trailing slash */
   for (cptr = UserPath; *cptr && *(unsigned short*)cptr != '/\0'; cptr++);
   *cptr = '\0';

   /* update it in the cache */
   MapUrl_VmsUserNameCache (rqptr, UserName, UserPath, &PathOds);

#ifdef ODS_EXTENDED
   /* if required return the path's on-disk-structure */
   if (PathOdsPtr != NULL) *PathOdsPtr = PathOds;
#endif /* ODS_EXTENDED */

   return (UserPath);
}

/*****************************************************************************/
/*
Keep a linked-list of cache entries.  If 'UserName' and 'UserPath' are NULL
then the list is reset (this happen on mapping rule reload).  If 'UserName' is
non-NULL and 'UserPath' is NULL the list is searched for a matching username
and the associated path string returned.  If 'UserName' and 'UserPath' are
non-NULL add/update a cache entry.  If the list has reached maximum size reuse
the last entry, otherwise create a new entry.  Move/add the entry to the head
of the list.  It's therefore a first-in/first-out queue.  Cache contents remain
current until demands on space (due to new entries) cycles through the maximum
available entries.  To explicitly flush the contents reload the rules.
*/ 

char* MapUrl_VmsUserNameCache
(
struct RequestStruct* rqptr,
char *UserName,
char *UserPath,
int *PathOdsPtr
)
{
   register struct ListEntryStruct  *leptr;
   register struct MapUrlUserCacheStruct  *ucptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "MapUrl_VmsUserNameCache() |%s|%s| %d\n",
               UserName, UserPath, PathOdsPtr);

   if (UserName == NULL && UserPath == NULL)
   {
      /***************/
      /* reset cache */
      /***************/

      MapUrlUserNameCacheEntries = Config.cfMisc.MapUserNameCacheEntries;
      if (!MapUrlUserNameCacheEntries)
         MapUrlUserNameCacheEntries = MAPURL_DEFAULT_USER_CACHE_SIZE;
      MapUrlUserNameCacheCount = 0;

      /* empty the list */
      leptr = MapUrlUserNameCacheList.HeadPtr;
      MapUrlUserNameCacheList.HeadPtr = MapUrlUserNameCacheList.TailPtr = NULL;
      MapUrlUserNameCacheList.EntryCount = 0;
      while (leptr != NULL) 
      {
         ucptr = (struct MapUrlUserCacheStruct*)leptr;
         leptr = leptr->NextPtr;
         VmFree (ucptr, FI_LI);
      }
      return (NULL);
   }

   if (UserPath == NULL)
   {
      /****************/
      /* search cache */
      /****************/

      /* process the cache entry list from most to least recent */
      for (leptr = MapUrlUserNameCacheList.HeadPtr;
           leptr != NULL;
           leptr = leptr->NextPtr)
      {
         ucptr = (struct MapUrlUserCacheStruct*)leptr;

         if (Debug)
            fprintf (stdout, "|%s|%s|\n", ucptr->UserName, ucptr->UserPath);

         /* if this one has been reset there won't be any more down the list */
         if (!ucptr->UserName[0]) break;

         /* compare the first two characters (at least one and a null) */
         if (*(unsigned short*)ucptr->UserName != *(unsigned short*)UserName)
            continue;
         /* full string comparison */
         if (strcmp (ucptr->UserName, UserName)) continue;

         /*************/
         /* cache hit */
         /*************/

         if ((void*)MapUrlUserNameCacheList.HeadPtr != (void*)ucptr)
         {
            /* move it to the head of the list */
            ListRemove (&MapUrlUserNameCacheList, ucptr);
            ListAddHead (&MapUrlUserNameCacheList, ucptr);
         }

         ucptr->HitCount++;
         memcpy (&ucptr->LastBinaryTime, &rqptr->rqTime.Vms64bit, 8);

         if (rqptr->WatchItem &&
             (WatchEnabled & WATCH_MAPPING))
            WatchThis (rqptr, FI_LI, WATCH_MAPPING,
                       "USER !AZ cache !AZ/ ODS-!UL !UL hits",
                       ucptr->UserName, ucptr->UserPath,
                       ucptr->PathOds, ucptr->HitCount);

         if (PathOdsPtr != NULL) *PathOdsPtr = ucptr->PathOds;
         return (ucptr->UserPath);
      }

      /* not found */
      return (NULL);
   }

   /****************/
   /* update cache */
   /****************/

   if (MapUrlUserNameCacheCount < MapUrlUserNameCacheEntries)
   {
      /* allocate memory for a new entry */
      ucptr = VmGet (sizeof (struct MapUrlUserCacheStruct));
      MapUrlUserNameCacheCount++;
   }
   else
   {
      /* reuse the tail entry (least recent) */
      ucptr = MapUrlUserNameCacheList.TailPtr;
      ucptr->ReuseCount++;
      ListRemove (&MapUrlUserNameCacheList, ucptr);
   }

   /* add entry to the head of the user cache list (most recent) */
   ListAddHead (&MapUrlUserNameCacheList, ucptr);

   strncpy (ucptr->UserName, UserName, sizeof(ucptr->UserName));
   strncpy (ucptr->UserPath, UserPath, sizeof(ucptr->UserPath));
   ucptr->UserName[sizeof(ucptr->UserName)-1] =
      ucptr->UserPath[sizeof(ucptr->UserPath)-1] = '\0';
   ucptr->HitCount = 1;
   memcpy (&ucptr->LastBinaryTime, &rqptr->rqTime.Vms64bit, 8);
#ifdef ODS_EXTENDED
   if (PathOdsPtr != NULL) ucptr->PathOds = *PathOdsPtr;
#endif /* ODS_EXTENDED */

   return (UserPath);
}

/****************************************************************************/
/*
Get a volume's underlying file system (ODS-2 or ODS-5), by sys$getdvi() the
ACPTYPE for the device.  Return 2 for an ODS-2 volume and 5 for an ODS-5
volume.  Any other value returned is a VMS status value (error)!
*/ 

#ifdef ODS_EXTENDED

/* if pre-7.2 Alpha then define this */
#ifndef DVI$C_ACP_F11V5
#define DVI$C_ACP_F11V5 11
#endif

int MapUrl_VolumeOds (char *DeviceName)

{
   static int  DevOds;
   static unsigned long  DevAcpType,
                         DevChar;
   static $DESCRIPTOR (DevNameDsc, "");
   static struct {
      short  buf_len;
      short  item;
      char   *buf_addr;
      short  *ret_len;
   }
   AcpTypeItemList [] = 
   {
      { sizeof(DevAcpType), DVI$_ACPTYPE, &DevAcpType, 0 },
      { sizeof(DevChar), DVI$_DEVCHAR, &DevChar, 0 },
      { 0, 0, 0, 0 }
   };

   register char  *cptr;

   int  status;
   struct {
      unsigned short  Status;
      unsigned short  Count;
      unsigned long  Unused;
   } IOsb;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MapUrl_VolumeOds() |%s|\n", DeviceName);

   if (!OdsExtended) return (0);

   for (cptr = DeviceName; *cptr && *cptr != ':'; cptr++);
   /* if we can't find a device in it then assume it's ODS-2 */
   if (!*cptr) return (0);
   DevNameDsc.dsc$a_pointer = DeviceName;
   DevNameDsc.dsc$w_length = cptr - DeviceName;
   if (Debug)
      fprintf (stdout, "|%*.*s|\n",
               DevNameDsc.dsc$w_length, DevNameDsc.dsc$w_length,
               DevNameDsc.dsc$a_pointer);

   status = sys$getdviw (0, 0, &DevNameDsc, &AcpTypeItemList, &IOsb, 0, 0, 0);
   if (Debug)
      fprintf (stdout,
               "sys$getdviw() %%X%08.08X IOsb: %%X%08.08X %d\n",
               status, IOsb.Status, DevAcpType);

   if (!(DevChar & DEV$M_MNT)) status = RMS$_DNR;
   if (VMSnok(status) || VMSnok(status = IOsb.Status))
   {
      /* volume not mounted or error */
      return (status);
   }

   if (DevAcpType == DVI$C_ACP_F11V2)
   { 
      if (Debug) fputs ("ODS:2\n", stdout); 
      return (DevOds = 2);
   }

   if (DevAcpType == DVI$C_ACP_F11V5)
   {
      if (Debug) fputs ("ODS:5\n", stdout); 
      return (DevOds = 5);
   }

   /* slightly bogus message */
   return (SS$_NOTFILEDEV);
}

#endif /* ODS_EXTENDED */

/*****************************************************************************/

