/*****************************************************************************/
/*
                               AuthHTL.c


    THE GNU GENERAL PUBLIC LICENSE APPLIES DOUBLY TO ANYTHING TO DO WITH
                    AUTHENTICATION AND AUTHORIZATION!

    This package is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License, or any later
    version.

>   This package is distributed in the hope that it will be useful,
>   but WITHOUT ANY WARRANTY; without even the implied warranty of
>   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
>   GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

This module provides functions related to the authentication of
case-insensitive usernames via simple lists of names (and optional
case-insensitive passwords and user detail).

See AUTH.C for overall detail on the WASD authorization environment.


VERSION HISTORY
---------------
05-FEB-2000  MGD  change HTL database type from ".HTL" to ".$HTL"
                  (keep the nomenclature in line with ".$HTA", see AUTHHTA.C)
01-JAN-2000  MGD  no significant modifications for ODS-5 (no NAM block)
28-AUG-1999  MGD  unbundled from AUTH.C for v6.1
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <descrip.h>
#include <rms.h>
#include <rmsdef.h>
#include <ssdef.h>
#include <stsdef.h>

/* application related header files */
#include "wasd.h"

#define WASD_MODULE "AUTHHTL"

#if DBUG
#define FI_NOLI WASD_MODULE, __LINE__
#else
/* in production let's keep the exact line to ourselves! */
#define FI_NOLI WASD_MODULE, 0
#endif

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern int  WatchEnabled;
extern char  ErrorSanityCheck[];
extern struct AccountingStruct  Accounting;
extern struct MsgStruct  Msgs;

/****************************************************************************/
/*
*/ 

int AuthReadSimpleList
(
struct RequestStruct* rqptr,
char *DatabaseName,
boolean AuthenticatePassword
)
{
   static char  AuthFileName [64];
   static $DESCRIPTOR (AuthFileNameFaoDsc, "!AZ!AZ!AZ");
   static $DESCRIPTOR (AuthFileNameDsc, AuthFileName);

   register char  *cptr, *sptr;

   int  status;
   unsigned short  AuthFileNameLength;
   char  *cptrBuffer;
   char  Line [1024];
   struct FAB  AuthFileFab;
   struct RAB  AuthFileRab;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "AuthReadSimpleList() |%s|%s| %d\n",
               DatabaseName, rqptr->RemoteUser, AuthenticatePassword);

   /* flag that case-less username and password checks were performed */
   rqptr->rqAuth.CaseLess = true;

   /* must supply a user name and database name */
   if (!rqptr->RemoteUser[0] || !DatabaseName[0])
      return (AUTH_DENIED_BY_LOGIN);

   sys$fao (&AuthFileNameFaoDsc, &AuthFileNameLength, &AuthFileNameDsc,
            HTA_DIRECTORY, DatabaseName, HTL_FILE_TYPE);
   AuthFileName[AuthFileNameLength] = '\0';
   if (Debug) fprintf (stdout, "AuthFileName |%s|\n", AuthFileName);

   AuthFileFab = cc$rms_fab;
   AuthFileFab.fab$b_fac = FAB$M_GET;
   AuthFileFab.fab$l_fna = AuthFileName;  
   AuthFileFab.fab$b_fns = AuthFileNameLength;
   AuthFileFab.fab$b_shr = FAB$M_SHRGET;

   /* turn on SYSPRV to allow access to authentication database file */
   EnableSysPrv();
   status = sys$open (&AuthFileFab, 0, 0);
   DisableSysPrv();

   /* status from sys$open() */
   if (VMSnok (status))
   {
      rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_AUTH_DATABASE);
      rqptr->rqResponse.ErrorOtherTextPtr = DatabaseName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      return (status);
   }

   AuthFileRab = cc$rms_rab;
   AuthFileRab.rab$l_fab = &AuthFileFab;
   AuthFileRab.rab$b_mbf = 2;
   AuthFileRab.rab$l_rop = RAB$M_RAH;

   if (VMSnok (status = sys$connect (&AuthFileRab, 0, 0)))
   {
      sys$close (&AuthFileFab, 0, 0);
      return (status);
   }

   /*****************/
   /* locate record */
   /*****************/

   AuthFileRab.rab$l_ubf = Line;
   AuthFileRab.rab$w_usz = sizeof(Line)-1;

   while (VMSok (status = sys$get (&AuthFileRab, 0, 0)))
   {
      AuthFileRab.rab$l_rbf[AuthFileRab.rab$w_rsz] = '\0';
      if (Debug) fprintf (stdout, "|%s|\n", AuthFileRab.rab$l_rbf);

      if (AuthFileRab.rab$w_rsz)
      {
         if (AuthFileRab.rab$l_ubf[AuthFileRab.rab$w_rsz-1] == '\\')
         {
            /* directive is continued on next line */
            AuthFileRab.rab$l_ubf[AuthFileRab.rab$w_rsz-1] = ' ';
            AuthFileRab.rab$l_ubf += AuthFileRab.rab$w_rsz;
            AuthFileRab.rab$w_usz -= AuthFileRab.rab$w_rsz;
            continue;
         }
      }

      if (Debug) fprintf (stdout, "|%s|\n", Line);
      for (cptr = Line; *cptr && ISLWS(*cptr); cptr++)
      if (*cptr == '#' || *cptr == '!') continue;

      sptr = rqptr->RemoteUser;
      while (*cptr && !ISLWS(*cptr) && *cptr != '=' && *sptr &&
             tolower(*cptr) == tolower(*sptr))
         { cptr++; sptr++; }
      if ((*cptr && !ISLWS(*cptr) && *cptr != '=') || *sptr) continue;
      break;
   }
   if (Debug) fprintf (stdout, "sys$get() %%X%08.08X\n", status);

   sys$close (&AuthFileFab);

   if (status == RMS$_EOF)
   {
      /* user record not found */
      if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
                    "FAIL !AZ!AZ username", DatabaseName,
                    AuthSourceString (DatabaseName, AUTH_SOURCE_LIST));

      if (AuthenticatePassword)
         return (AUTH_DENIED_BY_LOGIN);
      else
         return (AUTH_DENIED_BY_GROUP);
   }

   /* if just checking if the user name is an entry in the list file */
   if (!AuthenticatePassword) return (SS$_NORMAL);

   sptr = cptr;
   if (*sptr == '=') while (*sptr && !ISLWS(*sptr)) sptr++;
   while (*sptr && ISLWS(*sptr)) sptr++;
   if (*sptr)
   {
      cptrBuffer = cptr;
      for (cptr = sptr; *cptr; cptr++);
      if (cptr > sptr) cptr--;
      while (cptr > sptr && ISLWS(*cptr)) cptr--;
      if (!ISLWS(*cptr)) cptr++;
      *cptr = '\0';
      rqptr->rqAuth.UserDetailsLength = cptr - sptr;
      rqptr->rqAuth.UserDetailsPtr = cptr =
         VmGetHeap (rqptr, rqptr->rqAuth.UserDetailsLength+1);
      strcpy (cptr, sptr);
      cptr = cptrBuffer;
   }

   /* if just checking if the user name is an entry in the list file */
   if (!AuthenticatePassword) return (status);

   /* simple, clear-text password comparison */
   if (*cptr != '=')
   {
      if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
                    "FAIL !AZ!AZ no password", DatabaseName,
                    AuthSourceString (DatabaseName, AUTH_SOURCE_LIST));
      return (AUTH_DENIED_BY_LOGIN);
   }
   while (*cptr && *cptr == '=') cptr++;
   sptr = rqptr->RemoteUserPassword;
   while (*cptr && !ISLWS(*cptr) && *sptr && tolower(*cptr) == tolower(*sptr))
      { cptr++; sptr++; }
   if ((*cptr && !ISLWS(*cptr)) || *sptr)
   {
      /* passwords do not match */
      if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
                    "FAIL !AZ!AZ password", DatabaseName,
                    AuthSourceString (DatabaseName, AUTH_SOURCE_LIST));
      return (AUTH_DENIED_BY_LOGIN);
   }

   /* passwords match */
   return (SS$_NORMAL);
}

/****************************************************************************/

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          