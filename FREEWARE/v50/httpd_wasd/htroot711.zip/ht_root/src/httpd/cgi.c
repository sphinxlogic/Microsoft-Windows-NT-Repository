/*****************************************************************************/
/*
                                   CGI.c

Provide generalized CGI scripting support.

Creates a buffer containing either, the DCL commands to create CGI variables at
the VMS command line (e.g. for standard CGI scripts), or a stream of
'name=value' pairs for the CGI variables (e.g. for CGIplus scripts). 

The buffer is dynamically allocated and contains a series of sequential records
comprising a word (16 bits) with the length of a following (varying)
null-terminated string (including the null character).  The end of the series
is indicated by a zero length record.

This buffer is scanned from from first to last and the strings passed to the
script 'input' stream as appropriate.


CGI RESPONSE HEADER
-------------------
In common with other implementations, if the first line of the response header
begins "HTTP/1." then it is considered to be a full HTTP response (non-parsed
header output), the server does no more header processing and it is up to the
script to provide a fully compliant HTTP response.

Handling of the CGI response header is pretty standard.  It should begin with
"Content-Type:", "Status:", or "Location:".  One of more of these should be
received before the end-of-header blank line or other header lines.  As soon as
a any other line is received the server considered the CGI header complete.

The CGI header can be received record-by-record, with or without any
carriage-control, or as a block of lines with correct carriage-control (only
complete lines will be processed correctly).

The "X-vms-record-mode:" field is a VMS Apacheism for indicating to the server
whether VMS script output must be checked for correct carriage-control and
corrected if necessary.  It seems as if 0 is "not record mode", 1 is.

Current "Script-Control:" Directives
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
no-abort                  CGI/1.2, do not abort script because of timeout
X-buffer-records          buffer records before sending to client
X-lifetime=nnn            "none" or integer, set script process lifetime
X-crlf-mode               ensure all records have a trailing <CR><LF>
X-record-mode             ensure all records have at least trailing <LF>
X-stream-mode             do not alter records at all, WSSIWCG!
X-timeout-output=nnn      "none" or integer, set request output timer
X-timeout-noprogress=nnn  "none" or integer, set request no-progress timer
(all times are in minutes)

The "Script-Control:" is a proposed CGI/1.2 header field intended for script
control ;^). By default WASD writes each record to the client as it is received
from the script (in case of slow or intermittent output).  For script's where
this is known not to be an issue this directive can be used to have the server
buffer the records, outputting the block when the buffer fills or a script
conclusion.  This is often *much* more efficient.  The record mode forces each
record received to be checked for correct carriage-control (a trailing <LF>)
and if not present to be appended.


CGI VARIABLES
-------------
Most of these CGI variable names are those supported by the INTERNET-DRAFT
authored by D.Robinson (drtr@ast.cam.ac.uk), 8 January 1996, plus some
"convenience" variables, breaking the query string into its components (KEY_,
FORM_, etc.) The CGI symbols (CERN/VMS-HTTPd-like DCL symbols instead of Unix
environment variables) are created by the SYS$COMMAND stream of each
script process before the script DCL procedure is invoked. By default each
variable name is prefixed by "WWW_" (similar to CERN HTTPd), although this can
be modified at the command line when starting the server.

     VARIABLE NAME            DESCRIPTION                            "standard"
     -------------            -----------                            ----------

  (if the request is not authorized only AUTH_TYPE will exist)
  o  AUTH_ACCESS ............ "READ" or "READ+WRITE"                 [wasd]
  o  AUTH_AGENT ............. indicates authentication agent         [wasd]
  o  AUTH_GROUP ............. path authorization group               [wasd]
  o  AUTH_PASSWORD .......... only if "EXTERNAL" realm               [wasd]
  o  AUTH_REALM ............. authentication realm                   [wasd]
  o  AUTH_REALM_DESCRIPTION . realm description                      [wasd]
  o  AUTH_TYPE .............. "BASIC" or "DIGEST" (or empty)         [yes]
  o  AUTH_USER .............. details of user                        [wasd]

  o  CONTENT_LENGTH ......... "Content-Length:" from header          [yes]
  o  CONTENT_TYPE ........... "Content-Type:" from header            [yes]

  o  DOCUMENT_ROOT .......... base directory for serving files       [apache]

  o  FORM_field ............. query "&" separated form elements      [wasd]

  o  GATEWAY_BG ............. socket BG device name                  [wasd]
  o  GATEWAY_INTERFACE ...... "CGI/1.1"                              [yes]
  o  GATEWAY_MRS ............ maximum record size of mailbox         [wasd]

  o  HTTP_ACCEPT ............ list of browser-accepted content types [yes]
  O  HTTP_ACCEPT_ENCODING ... list of browser-accepted encodings     [yes]
  o  HTTP_ACCEPT_CHARSET .... list of browser-accepted character set [yes]
  o  HTTP_ACCEPT_LANGUAGE ... list of browser-accepted languages     [yes]
  o  HTTP_AUTHORIZATION ..... only if "EXTERNAL" realm               [yes]
  o  HTTP_COOKIE ............ any cookie sent by the client          [yes]
  o  HTTP_FORWARDED ......... list of proxy/gateway hosts            [yes]
  o  HTTP_HOST .............. destination host name/port             [yes]
  o  HTTP_IF_NOT_MODIFIED ... GMT time string                        [yes]
  o  HTTP_PRAGMA ............ any pragma directive of header         [yes]
  o  HTTP_REFERER ........... source document URL for this request   [yes]
  o  HTTP_USER_AGENT ........ client/browser identification string   [yes]

  o  KEY_n .................. query string "+" separated elements    [wasd]
  o  KEY_COUNT .............. number of "+" separated elements       [wasd]

  o  PATH_INFO .............. virtual path of data requested in URL  [yes]
  o  PATH_ODS ............... on-disk structure of path (0, 2 or 5)  [wasd]
  o  PATH_TRANSLATED ........ VMS file path of data requested in URL [yes]

  o  QUERY_STRING ........... string following "?" in URL            [yes]

  o  REMOTE_ADDR ............ IP host address of HTTP client         [yes]
  o  REMOTE_HOST ............ IP host name of HTTP client            [yes]
  o  REMOTE_PORT ............ IP port of HTTP client                 [wasd]
  o  REMOTE_USER ............ authenticated username (or empty)      [yes]
  o  REQUEST_CHARSET ........ charset SET by mapping rule            [wasd]
  o  REQUEST_CONTENT_TYPE ... content-type SET by mapping rule       [wasd]
  o  REQUEST_METHOD ......... "GET", "PUT", etc.                     [yes]
  o  REQUEST_SCHEME ......... "http:" or "https:"                    [wasd]
  o  REQUEST_TIME_GMT ....... request GMT time                       [wasd]
  o  REQUEST_TIME_LOCAL ..... request local time                     [wasd]
  o  REQUEST_URI ............ un-encoded path[?query-string]         [apache]

  o  SCRIPT_FILENAME ........ (e.g. "CGI-BIN:[000000]TEST.COM")      [apache]
  o  SCRIPT_NAME ............ name of script (e.g. "/query")         [yes]
  o  SCRIPT_RTE ............. script run-time environment            [wasd]
  o  SERVER_ADDR ............ IP host address of server system       [wasd]
  o  SERVER_ADMIN ........... "webmaster@site.domain"                [apache]
  o  SERVER_CHARSET ......... default charset (e.g. "ISO-8895-1")    [wasd]
  o  SERVER_GMT ............. offset from GMT time (e.g. "+09:30)    [wasd]
  o  SERVER_NAME ............ IP host name of server system          [yes]
  o  SERVER_PROTOCOL ........ HTTP protocol version ("HTTP/1.0")     [yes]
  o  SERVER_PORT ............ IP port request was received on        [yes]
  o  SERVER_SOFTWARE ........ software ID of the HTTPD daemon        [yes]
  o  SERVER_SIGNATURE ....... "server host port"                     [apache]

  o  UNIQUE_ID .............. a "unqiue" request ID                  [apache]

  o  some SSL related CGI variable can be generated when SSL is available
     (see SESOLA.C module)

NOTE: If script portability is a concern then confine use to the "standard" CGI
variables.  For WASD-specific scripts the extension variables may be used.  Not
all variables will be present for all requests.


CGI VARIABLES USING DCL SYMBOLS
-------------------------------
Due to the mechanism used to create DCL symbols for the CGI variables (for
standard CGI) the variable value is limited to 1005 characters minus the length
of the DCL symbol name assignment (e.g. "WWW_QUERY_STRING=A+B+C+D"), or in
round terms approximately 980 characters maximum.  This 1005 appears to be a
"magic number" for the DCL command line (VAX VMS V7.2 anyway).


CGI VARIABLES USING CGIPLUS STREAM
----------------------------------
The maximum 'name=value' length for a CGI variable conveyed using the CGIPLUSIN
stream is limited by the size of of the 'DclCgiPlusInSize' global storage value
which is in turn set by the [BufferSizeDclCgiPlusIn] configuration directive. 
Hence if this is set to 3072 bytes (the current default) then the maximum
'name=value' length is the that value minus 3 bytes.  This value is also the
total mailbox buffer space allocated for script process IPC and so is also the
limit on all variables!  So, in the circumstance where the largest variable
needs to be 4000 bytes in length, and the rest total up to another 3000 bytes,
the [BufferSizeDclCgiPlusIn] is suggested to be 8192 bytes.  When this value is
adjusted it is recommended to review the HTTP server account's BYTLM quota.


VERSION HISTORY
---------------
18-JAN-2001  MGD  bugfix; REMOTE_PORT ntohs()
19-DEC-2000  MGD  refine [CgiStrictOutput] to detect an incomplete header
05-SEP-2000  MGD  additional "Script-Control:" directives
08-AUG-2000  MGD  if response "Content-Encoding:" force stream mode,
                  add GATEWAY_BG and GATEWAY_MRS variables
01-JUL-2000  MGD  modify CgiOutput() to better handle CGI responses,
                  add "Script-Control:" (CGI/1.2)
24-JUN-2000  MGD  SCRIPT_RTE for persistant run-time environments
10-MAY-2000  MGD  refined CgiOutput() and CgiHeader()
08-APR-2000  MGD  CGI binary header response can now be processed,
                  (some) VMS Apache compatibility
31-DEC-1999  MGD  PATH_ODS variable (to indicate on-disk file system)
17-DEC-1999  MGD  bugfix; quote double-up in CgiVariable()
27-NOV-1999  MGD  rework DCL variable stream,
                  remove sys$fao() from stream CGI variable creation,
                  avoid "''" substitution creating DCL symbol CGI variables
20-NOV-1999  MGD  end-of-header blank line may now be an empty record,
                  or a record containing a single '\n' or '\r\n' sequence
06-NOV-1999  MGD  allow slightly more latitude with form fields, no "=value"
                  (i.e. name terminated by '&') and back-to-back '&'
14-SEP-1999  MGD  modify CgiOutput() for delayed CGI "Content-Type:"
28-AUG-1999  MGD  support CGIplus "agents", added AUTH_USER
30-MAY-1999  MGD  add SSL variables (via call to SesolaCgiGenerateVariables())
21-FEB-1999  MGD  change authorization CGI variables
28-DEC-1998  MGD  added HTTP_ACCEPT_ENCODING
07-NOV-1998  MGD  WATCH facility
17-OCT-1998  MGD  CgiUrlDecodeString(),
                  SERVER_CHARSET, REQUEST_CHARSET, REQUEST_CONTENT_TYPE
28-APR-1998  MGD  CGI variable memory allocation changed in support of SSI
03-APR-1998  MGD  bugfix; extra quotes generated in form field value
19-MAR-1998  MGD  suppress 'Authorization:' unless "external" authorization
06-DEC-1997  MGD  functionality unbundled from DCL.c, generalized for version 5
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <stdio.h>

/* VMS related header files */
#include <descrip.h>
#include <dvidef.h>
#include <ssdef.h>
#include <stsdef.h>

/* application header files */
#include "wasd.h"

#define WASD_MODULE "CGI"

/***********/
/* defines */
/***********/

#define CLI$_BUFOVF 229400

/******************/
/* global storage */
/******************/

char  ErrorCgiNotStrict [] = "NOT a strict CGI response!!";

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern boolean  OdsExtended;

extern int  DclCgiPlusInSize,
            DclSysCommandSize,
            DclSysOutputSize,
            ServerPort,
            WatchEnabled;

unsigned long HttpdProcessId;

extern char  DclCgiVariablePrefix[],
             HttpProtocol[],
             SoftwareID[],
             TimeGmtString[];

extern struct ConfigStruct Config;
extern struct MsgStruct Msgs;

/*****************************************************************************/
/*
Creates a buffer containing a series of null-terminated strings, terminated by
a null-string (two successive null characters).  Each of the strings contains
either DCL command(s) to create a DCL symbol (CGI variable) using the CLI, or
an equate separated 'name=value' pair used for CGIplus variable streams, etc.
*/ 

CgiGenerateVariables
(
struct RequestStruct *rqptr,
int VarType
)
{
   static $DESCRIPTOR (NumberFaoDsc, "!UL\0");
   static $DESCRIPTOR (StatusValueFaoDsc, "%X!8UL\0");
   static char  BgDevNam [65];
   static unsigned short  BgDevNamLength;
   static struct {
      short  buf_len;
      short  item;
      char   *buf_addr;
      short  *ret_len;
   }
   BgDevNamItemList [] = 
   {
      { sizeof(BgDevNam), DVI$_DEVNAM, &BgDevNam, &BgDevNamLength },
      { 0, 0, 0, 0 }
   };


   register char  c;
   register char  *cptr, *sptr, *zptr;

   int  status,
        Count,
        KeyCount;
   char  FormFieldName [256],
         LocalDateTime [48],
         String [1024];
   $DESCRIPTOR (StringDsc, String);
   struct {
      unsigned short  Status;
      unsigned short  Count;
      unsigned long  Unused;
   } IOsb;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "CgiGenerateVariables()\n");

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_CGI))
   {
      if (VarType == CGI_VARIABLE_STREAM)
         WatchThis (rqptr, FI_LI, WATCH_CGI, "VARIABLES stream");
      else
         WatchThis (rqptr, FI_LI, WATCH_CGI, "VARIABLES dcl");
   }

   if (rqptr->rqCgi.BufferLength)
   {
      /* free previous variables and storage */
      if (rqptr->rqCgi.BufferPtr != NULL)
         VmFreeFromHeap (rqptr, rqptr->rqCgi.BufferPtr, FI_LI); 
      rqptr->rqCgi.BufferLength = 0;
      rqptr->rqCgi.BufferPtr = rqptr->rqCgi.BufferCurrentPtr = NULL;
   }

   if (VarType == CGI_VARIABLE_STREAM)
      CgiVariableBufferMemory (rqptr, DclCgiPlusInSize*2);
   else
      CgiVariableBufferMemory (rqptr, DclSysCommandSize);

   HttpLocalTimeString (LocalDateTime, &rqptr->rqTime.Vms64bit);

   if (rqptr->rqAuth.Type[0])
   {
      if (rqptr->rqAuth.SourceRealm)
      { 
         if (VMSnok (status =
             CgiVariable (rqptr, "AUTH_ACCESS", 
                          AuthCanString (rqptr->rqAuth.RequestCan,
                                         AUTH_CAN_FORMAT_LONG),
                          VarType)))
            return (status);
      }

      if (rqptr->rqAuth.AgentParameterPtr != NULL &&
          rqptr->rqAuth.AgentParameterPtr[0])
      { 
         if (VMSnok (status =
             CgiVariable (rqptr, "AUTH_AGENT",
                          rqptr->rqAuth.AgentParameterPtr, VarType)))
            return (status);
      }

      if (rqptr->rqAuth.GroupWritePtr[0])
      {
         if (VMSnok (status =
             CgiVariable (rqptr, "AUTH_GROUP",
                          rqptr->rqAuth.GroupWritePtr, VarType)))
            return (status);
      }
      else
      {
         if (VMSnok (status =
             CgiVariable (rqptr, "AUTH_GROUP",
                          rqptr->rqAuth.GroupReadPtr, VarType)))
            return (status);
      }

      if ((rqptr->rqAuth.AgentParameterPtr != NULL &&
           rqptr->rqAuth.AgentParameterPtr[0]) ||
          rqptr->rqAuth.SourceRealm == AUTH_SOURCE_EXTERNAL)
      {
         if (VMSnok (status =
             CgiVariable (rqptr, "AUTH_PASSWORD",
                          rqptr->RemoteUserPassword, VarType)))
            return (status);
      }

      if (VMSnok (status =
          CgiVariable (rqptr, "AUTH_REALM", rqptr->rqAuth.RealmPtr, VarType)))
         return (status);

      if (VMSnok (status =
          CgiVariable (rqptr, "AUTH_REALM_DESCRIPTION",
                       rqptr->rqAuth.RealmDescrPtr, VarType)))
         return (status);
   }

   if (VMSnok (status =
       CgiVariable (rqptr, "AUTH_TYPE", rqptr->rqAuth.Type, VarType)))
      return (status);

   if (rqptr->rqAuth.Type[0])
   {
      if (VMSnok (status =
          CgiVariable (rqptr, "AUTH_USER", rqptr->rqAuth.UserDetailsPtr, VarType)))
         return (status);
   }

   sys$fao (&NumberFaoDsc, 0, &StringDsc, rqptr->rqHeader.ContentLength);
   if (VMSnok (status =
       CgiVariable (rqptr, "CONTENT_LENGTH", String, VarType)))
      return (status);

   if (rqptr->rqHeader.ContentTypePtr != NULL)
   {
      if (VMSnok (status =
          CgiVariable (rqptr, "CONTENT_TYPE",
                       rqptr->rqHeader.ContentTypePtr, VarType)))
         return (status);
   }
   else
   if (rqptr->rqContentInfo.ContentTypePtr != NULL)
   {
      if (VMSnok (status =
          CgiVariable (rqptr, "CONTENT_TYPE",
                       rqptr->rqContentInfo.ContentTypePtr, VarType)))
         return (status);
   }
   else
   {
      if (VMSnok (status =
          CgiVariable (rqptr, "CONTENT_TYPE", "", VarType)))
         return (status);
   }

   /* Apache-like - just empty for WASD */
   if (VMSnok (status =
       CgiVariable (rqptr, "DOCUMENT_ROOT", "", VarType)))
      return (status);

   if (Config.cfScript.GatewayBg &&
       rqptr->ServicePtr->RequestScheme != SCHEME_HTTPS)
   {
      status = sys$getdviw (0, rqptr->rqNet.ClientChannel, 0,
                            &BgDevNamItemList, &IOsb, 0, 0, 0);
      if (Debug)
         fprintf (stdout, "sys$getdviw() %%X%08.08X IOsb: %%X%08.08X\n",
                  status, IOsb.Status);
      if (VMSok(status) || VMSok(status = IOsb.Status))
      {
         BgDevNam[BgDevNamLength] = '\0';
         if (VMSnok (status =
             CgiVariable (rqptr, "GATEWAY_BG",
                          BgDevNam[0] == '_' ? BgDevNam+1 : BgDevNam,
                          VarType)))
            return (status);
      }
      else
         return (status);
   }

   if (VMSnok (status =
       CgiVariable (rqptr, "GATEWAY_INTERFACE", "CGI/1.1", VarType)))
      return (status);

   if (rqptr->DclTaskPtr != NULL)
   {
      /* size of mailbox */
      sys$fao (&NumberFaoDsc, 0, &StringDsc, DclSysOutputSize);
      if (VMSnok (status =
           CgiVariable (rqptr, "GATEWAY_MRS", String, VarType)))
          return (status);
   }

   if (rqptr->rqHeader.AcceptPtr != NULL)
      if (VMSnok (status =
          CgiVariable (rqptr, "HTTP_ACCEPT", rqptr->rqHeader.AcceptPtr, VarType)))
      return (status);

   if (rqptr->rqHeader.AcceptCharsetPtr != NULL)
      if (VMSnok (status =
          CgiVariable (rqptr, "HTTP_ACCEPT_CHARSET",
                       rqptr->rqHeader.AcceptCharsetPtr, VarType)))
      return (status);

   if (rqptr->rqHeader.AcceptEncodingPtr != NULL)
      if (VMSnok (status =
          CgiVariable (rqptr, "HTTP_ACCEPT_ENCODING",
                       rqptr->rqHeader.AcceptEncodingPtr, VarType)))
      return (status);

   if (rqptr->rqHeader.AcceptLangPtr != NULL)
      if (VMSnok (status =
          CgiVariable (rqptr, "HTTP_ACCEPT_LANGUAGE",
                       rqptr->rqHeader.AcceptLangPtr, VarType)))
         return (status);

   if (rqptr->rqAuth.SourceRealm == AUTH_SOURCE_EXTERNAL &&
       rqptr->rqHeader.AuthorizationPtr != NULL)
      if (VMSnok (status =
          CgiVariable (rqptr, "HTTP_AUTHORIZATION",
                       rqptr->rqHeader.AuthorizationPtr, VarType)))
         return (status);

   if (rqptr->rqHeader.CookiePtr != NULL)
      if (VMSnok (status =
          CgiVariable (rqptr, "HTTP_COOKIE", rqptr->rqHeader.CookiePtr, VarType)))
         return (status);

   if (rqptr->rqHeader.ForwardedPtr != NULL)
      if (VMSnok (status =
          CgiVariable (rqptr, "HTTP_FORWARDED",
                       rqptr->rqHeader.ForwardedPtr, VarType)))
         return (status);

   if (rqptr->rqHeader.HostPtr != NULL)
      if (VMSnok (status =
          CgiVariable (rqptr, "HTTP_HOST", rqptr->rqHeader.HostPtr, VarType)))
         return (status);

   if (rqptr->rqHeader.IfModifiedSincePtr != NULL)
      if (VMSnok (status =
          CgiVariable (rqptr, "HTTP_IF_MODIFIED_SINCE",
                       rqptr->rqHeader.IfModifiedSincePtr, VarType)))
         return (status);

   if (rqptr->rqHeader.PragmaPtr != NULL)
      if (VMSnok (status =
          CgiVariable (rqptr, "HTTP_PRAGMA", rqptr->rqHeader.PragmaPtr, VarType)))
         return (status);

   if (rqptr->rqHeader.RefererPtr != NULL)
      if (VMSnok (status =
          CgiVariable (rqptr, "HTTP_REFERER", rqptr->rqHeader.RefererPtr, VarType)))
         return (status);

   if (rqptr->rqHeader.UserAgentPtr != NULL)
      if (VMSnok (status =
          CgiVariable (rqptr, "HTTP_USER_AGENT",
                       rqptr->rqHeader.UserAgentPtr, VarType)))
         return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "PATH_INFO", rqptr->rqHeader.PathInfoPtr, VarType)))
      return (status);

   if (OdsExtended)
   {
      /* only supply when supporting both ODS-2 and ODS-5 */
      sys$fao (&NumberFaoDsc, 0, &StringDsc, rqptr->PathOds);
      if (VMSnok (status =
          CgiVariable (rqptr, "PATH_ODS", String, VarType)))
         return (status);
   }

   if (VMSnok (status =
       CgiVariable (rqptr, "PATH_TRANSLATED",
                    rqptr->ParseOds.ExpFileName, VarType)))
      return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "QUERY_STRING", rqptr->rqHeader.QueryStringPtr, VarType)))
      return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "REMOTE_ADDR",
                    rqptr->rqNet.ClientIpAddressString, VarType)))
      return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "REMOTE_HOST", rqptr->rqNet.ClientHostName, VarType)))
      return (status);

   sys$fao (&NumberFaoDsc, 0, &StringDsc, ntohs(rqptr->rqNet.ClientPort));
   if (VMSnok (status =
       CgiVariable (rqptr, "REMOTE_PORT", String, VarType)))
      return (status);

   if (rqptr->rqAuth.CaseLess)
   {
      /* force remote user name to upper-case if a case-less authentication */
      zptr = (sptr = String) + sizeof(String)-1;
      for (cptr = rqptr->RemoteUser;
           *cptr && sptr < zptr;
           *sptr++ = toupper(*cptr++));
      *sptr = '\0';
      if (VMSnok (status =
          CgiVariable (rqptr, "REMOTE_USER", String, VarType)))
         return (status);
   }
   else
   if (VMSnok (status =
       CgiVariable (rqptr, "REMOTE_USER", rqptr->RemoteUser, VarType)))
      return (status);

   if (rqptr->rqPathSet.CharsetPtr != NULL)
   {
      if (VMSnok (status =
          CgiVariable (rqptr, "REQUEST_CHARSET",
                       rqptr->rqPathSet.CharsetPtr, VarType)))
         return (status);
   }

   if (rqptr->rqPathSet.ContentTypePtr != NULL)
   {
      if (VMSnok (status =
          CgiVariable (rqptr, "REQUEST_CONTENT_TYPE",
                       rqptr->rqPathSet.ContentTypePtr, VarType)))
         return (status);
   }

   if (VMSnok (status =
       CgiVariable (rqptr, "REQUEST_METHOD", rqptr->rqHeader.MethodName, VarType)))
      return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "REQUEST_SCHEME",
                    rqptr->ServicePtr->RequestSchemeNamePtr, VarType)))
      return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "REQUEST_TIME_GMT", rqptr->rqTime.GmDateTime, VarType)))
      return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "REQUEST_TIME_LOCAL", LocalDateTime, VarType)))
      return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "REQUEST_URI", rqptr->rqHeader.RequestUriPtr, VarType)))
      return (status);

   /* Apache-like */
   if (rqptr->rqCgi.ScriptFileNamePtr != NULL &&
       rqptr->rqCgi.ScriptFileNamePtr[0])
   {
      /* VMS syntax, script complete file name */
      if (VMSnok (status =
           CgiVariable (rqptr, "SCRIPT_FILENAME",
                        rqptr->rqCgi.ScriptFileNamePtr, VarType)))
          return (status);
   }

   if (VMSnok (status =
       CgiVariable (rqptr, "SCRIPT_NAME", rqptr->ScriptName, VarType)))
      return (status);

   if (rqptr->DclTaskPtr != NULL &&
       rqptr->DclTaskPtr->RteFileName[0])
   {
      /* Run-Time Environment (interpreter file name) */
      if (VMSnok (status =
           CgiVariable (rqptr, "SCRIPT_RTE",
                        rqptr->DclTaskPtr->RteFileName, VarType)))
          return (status);
   }

   /* Apache-like */
   if (Config.cfServer.AdminEmail[0])
      if (VMSnok (status =
          CgiVariable (rqptr, "SERVER_ADMIN",
                       Config.cfServer.AdminEmail, VarType)))
         return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "SERVER_CHARSET", Config.cfContent.CharsetDefault, VarType)))
      return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "SERVER_GMT", TimeGmtString, VarType)))
      return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "SERVER_NAME",
                    rqptr->ServicePtr->ServerHostName, VarType)))
      return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "SERVER_ADDR",
                    rqptr->ServicePtr->ServerIpAddressString, VarType)))
      return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "SERVER_PROTOCOL", HttpProtocol, VarType)))
      return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "SERVER_PORT",
                    rqptr->ServicePtr->ServerPortString, VarType)))
      return (status);

   /* Apache-like */
   ServerSignature (rqptr, String, sizeof(String));
   if (String[0])
      if (VMSnok (status =
          CgiVariable (rqptr, "SERVER_SIGNATURE", String, VarType)))
         return (status);

   if (VMSnok (status =
       CgiVariable (rqptr, "SERVER_SOFTWARE", SoftwareID, VarType)))
      return (status);

   /* Apache-like */
   if (VMSnok (status =
       CgiVariable (rqptr, "UNIQUE_ID", GenerateUniqueId(rqptr), VarType)))
      return (status);

   /*****************/
   /* SSL variables */
   /*****************/

   if (VMSnok (status = SesolaCgiGenerateVariables (rqptr, VarType)))
      return (status);

   /***************************/
   /* query string components */
   /***************************/

   if (rqptr->rqHeader.QueryStringPtr[0])
   {
      KeyCount = 0;

      cptr = rqptr->rqHeader.QueryStringPtr;
      while (*cptr && *cptr != '=') cptr++;
      /* if an equal symbol was found then its a form not a keyword search */
      if (*cptr)
      {
         /***************/
         /* form fields */
         /***************/

         memcpy (FormFieldName, "FORM_", 5);
         cptr = rqptr->rqHeader.QueryStringPtr;
         while (*cptr)
         {
            sptr = FormFieldName + 5;
            zptr = FormFieldName + sizeof(FormFieldName);
            while (*cptr && *cptr != '=' && *cptr != '&' && sptr < zptr)
            {
               if (isalnum(*cptr))
                  *sptr++ = toupper(*cptr++);
               else
               {
                  *sptr++ = '_';
                  cptr++;
               }
            }
            if (sptr >= zptr)
            {
               ErrorVmsStatus (rqptr, SS$_BUFFEROVF, FI_LI);
               return (STS$K_ERROR);
            }
            *sptr = '\0';

            if (!FormFieldName[5] || (*cptr && *cptr != '=' && *cptr != '&'))
            {
               if (*cptr == '&')
               {
                  /* allow back-to-back '&' (effectively null field name) */
                  cptr++;
                  continue;
               }
               /* error, out-of-place '=' (no field name) */
               rqptr->rqResponse.HttpStatus = 400;
               ErrorGeneral (rqptr, MsgFor(rqptr,MSG_REQUEST_URL_FORM), FI_LI);
               return (STS$K_ERROR);
            }

            /* if encountered an '=' */
            if (*cptr == '=') cptr++;
            Count = CgiUrlDecodeString (rqptr, cptr,
                                        String, sizeof(String), '&');
            if (Count < 0) return (STS$K_ERROR);
            cptr += Count;
            if (VMSnok (status =
                CgiVariable (rqptr, FormFieldName, String, VarType)))
               return (status);
         }

         if (VMSnok (status =
             CgiVariable (rqptr, "KEY_COUNT", "0", VarType)))
            return (status);
      }
      else
      {
         /******************/
         /* query keywords */
         /******************/

         cptr = rqptr->rqHeader.QueryStringPtr;
         while (*cptr)
         {
            sys$fao (&NumberFaoDsc, 0, &StringDsc, ++KeyCount);
            memcpy (FormFieldName, "KEY_", 4);
            strcpy (FormFieldName+4, String);

            Count = CgiUrlDecodeString (rqptr, cptr,
                                        String, sizeof(String), '+');
            if (Count < 0) return (STS$K_ERROR);
            cptr += Count;
            if (VMSnok (status =
                CgiVariable (rqptr, FormFieldName, String, VarType)))
               return (status);
         }

         sys$fao (&NumberFaoDsc, 0, &StringDsc, KeyCount);
         if (VMSnok (status =
             CgiVariable (rqptr, "KEY_COUNT", String, VarType)))
            return (status);
      }
   }
   else
   {
      /* no keywords if no query string! */
      if (VMSnok (status =
          CgiVariable (rqptr, "KEY_COUNT", "0", VarType)))
         return (status);
   }

   return (CgiVariable (rqptr, NULL, NULL, VarType));
}

/*****************************************************************************/
/*
URL-decode a URL-encoded string!  Return -1 if an error occurs, otherwise
return the number of characters read from the original, encoded string.
*/ 

int CgiUrlDecodeString
(
struct RequestStruct *rqptr,
char *EncodedString,
char *DecodedString,
int SizeofDecodedString,
char Separator
)
{
   register char  c;
   register char  *cptr, *sptr, *zptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "CgiUrlDecodeString() |%s|\n", EncodedString);

   cptr = EncodedString;
   zptr = (sptr = DecodedString) + SizeofDecodedString;
   while (*cptr && *cptr != Separator && sptr < zptr)
   {
      if (*cptr == '+')
      {
         *sptr++ = ' ';
         cptr++;
      }
      else
      if (*cptr == '%')
      {
         /* an escaped character ("%xx" where xx is a hex number) */
         cptr++;
         c = 0;
         if (*cptr >= '0' && *cptr <= '9')
            { c = (*cptr - (int)'0') << 4; cptr++; }
         else
         if (tolower(*cptr) >= 'a' && tolower(*cptr) <= 'f')
            { c = (tolower(*cptr) - (int)'a' + 10) << 4; cptr++; }
         else
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_REQUEST_URL_ENC), FI_LI);
            return (-1);
         }
         if (*cptr >= '0' && *cptr <= '9')
            { c += (*cptr - (int)'0'); cptr++; }
         else
         if (tolower(*cptr) >= 'a' && tolower(*cptr) <= 'f')
            { c += (tolower(*cptr) - (int)'a' + 10); cptr++; }
         else
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_REQUEST_URL_ENC), FI_LI);
            return (-1);
         }
         if (sptr < zptr) *sptr++ = c;
      }
      else
         *sptr++ = *cptr++;
   }
   if (sptr >= zptr)
   {
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_GENERAL_OVERFLOW), FI_LI);
      return (-1);
   }
   *sptr = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", DecodedString);
   if (*cptr) cptr++;

   return (cptr - EncodedString);
}

/*****************************************************************************/
/*
Depending on whether the CGI variable is for creation at the DCL CLI or as part
of a CGI variable stream (e.g. CGIplus) create a null-terminated string
conatining either commands to create a DCL symbol, or a 'name=value' pair.

DCL symbol creation at the command line is limited by the CLI command line 
length (255 characters).  Symbol values however can be up to approximately 
1000 characters, probably enough for any CGI variable value.  If a CGI value 
is too large for for a single command-line assignment then build it up using 
multiple assignments, a symbol assignment kludge!
*/ 

int CgiVariable
(
struct RequestStruct *rqptr,
char *SymbolName,
char *SymbolValue,
int VarType
)
{
   static char  DeleteAllLocalSymbol[] = "DELETE/SYMBOL/LOCAL/ALL";

   register char  *cptr, *sptr, *zptr;

   int  status,
        SymbolCount,
        SymbolValueLength;
   unsigned short  Length;
   char  *CgiVariablePrefixPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "CgiVariable() |%s|%s|\n", SymbolName, SymbolValue);

   if (SymbolName == NULL)
   {
      /************************/
      /* end of CGI variables */
      /************************/

      if (rqptr->rqCgi.BufferRemaining < sizeof(short))
         CgiVariableBufferMemory (rqptr, sizeof(short));

      /* zero length record terminates generated CGI variables */
      *(short*)rqptr->rqCgi.BufferCurrentPtr = 0;
      rqptr->rqCgi.BufferRemaining -= sizeof(short);
      rqptr->rqCgi.BufferCurrentPtr += sizeof(short);

      if (Debug)
         fprintf (stdout, "buffer used: %d\n",
                  rqptr->rqCgi.BufferCurrentPtr - rqptr->rqCgi.BufferPtr);

      return (SS$_NORMAL);
   }

   if (rqptr->rqPathSet.CgiPrefixPtr == NULL)
      CgiVariablePrefixPtr = DclCgiVariablePrefix;
   else
      CgiVariablePrefixPtr = rqptr->rqPathSet.CgiPrefixPtr;

   if (SymbolValue == NULL) SymbolValue = "";

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_CGI))
      WatchDataFormatted ("!AZ=!AZ\n", SymbolName, SymbolValue);

   if (VarType == CGI_VARIABLE_STREAM)
   {
      /******************************/
      /* variables in record stream */
      /******************************/

      if (rqptr->rqCgi.BufferRemaining <= DclCgiPlusInSize + sizeof(short))
         CgiVariableBufferMemory (rqptr, DclCgiPlusInSize*2);

      zptr = (sptr = rqptr->rqCgi.BufferCurrentPtr + sizeof(short)) +
             (rqptr->rqCgi.BufferRemaining - sizeof(short));
      for (cptr = CgiVariablePrefixPtr; *cptr; *sptr++ = *cptr++);
      for (cptr = SymbolName; *cptr && sptr < zptr; *sptr++ = *cptr++);
      if (sptr < zptr) *sptr++ = '=';
      for (cptr = SymbolValue; *cptr && sptr < zptr; *sptr++ = *cptr++);
      if (sptr < zptr) *sptr++ = '\0';
      if (sptr < zptr)
      {
         Length = sptr - (char*)rqptr->rqCgi.BufferCurrentPtr - sizeof(short);
         *(short*)rqptr->rqCgi.BufferCurrentPtr = Length;
         rqptr->rqCgi.BufferRemaining -= Length + sizeof(short);
         rqptr->rqCgi.BufferCurrentPtr += Length + sizeof(short);
         return (SS$_NORMAL);
      }
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_GENERAL_OVERFLOW), FI_LI);
      return (STS$K_ERROR);
   }

   /********************************/
   /* variables created at DCL CLI */
   /********************************/

   if (rqptr->rqCgi.BufferRemaining <= 256 + sizeof(short))
      CgiVariableBufferMemory (rqptr, DclSysCommandSize);

   zptr = (sptr = rqptr->rqCgi.BufferCurrentPtr + sizeof(short)) + 255;
   for (cptr = CgiVariablePrefixPtr; *cptr; *sptr++ = *cptr++);
   for (cptr = SymbolName; *cptr && sptr < zptr; *sptr++ = *cptr++);
   if (sptr < zptr) *sptr++ = '=';
   if (sptr < zptr) *sptr++ = '=';
   if (sptr < zptr) *sptr++ = '\"';
   cptr = SymbolValue;
   while (*cptr && sptr < zptr)
   {
      if (*cptr == '\"')
      {
         /* escape double quotes, by doubling up */
         if (sptr+2 < zptr)
         {
            cptr++;
            *sptr++ = '\"';
            *sptr++ = '\"';
         }
         else
            zptr = sptr;
         continue;
      }

      if (*cptr == '\'')
      {
         /* escape single quotes by concatenation */
         if (sptr+7 < zptr)
         {
            cptr++;
            memcpy (sptr, "\"+\"\'\"+\"", 7);
            sptr += 7;
         }
         else
            sptr = zptr;
         continue;
      }

      if (sptr < zptr) *sptr++ = *cptr++;
   }
   if (sptr < zptr) *sptr++ = '\"';
   if (sptr < zptr)
   {
      *sptr++ = '\0';
      Length = sptr - (char*)rqptr->rqCgi.BufferCurrentPtr - sizeof(short);
      *(short*)rqptr->rqCgi.BufferCurrentPtr = Length;
      rqptr->rqCgi.BufferRemaining -= Length + sizeof(short);
      rqptr->rqCgi.BufferCurrentPtr += Length + sizeof(short);
      return (SS$_NORMAL);
   }

   /* loop assigning maximum amount allowed by DCL until all assigned */
   SymbolCount = 0;
   cptr = SymbolValue;
   while (*cptr)
   {
      if (rqptr->rqCgi.BufferRemaining <= 256 + sizeof(short))
         CgiVariableBufferMemory (rqptr, DclSysCommandSize);

      if (Debug) fprintf (stdout, "|%s|\n", cptr);

      /* set this to DCL line length minus one for the terminating quote */
      zptr = (sptr = rqptr->rqCgi.BufferCurrentPtr + sizeof(short)) + 254;
      switch (++SymbolCount)
      {
         case 1 : memcpy (sptr, "A=\"", 3); break;
         case 2 : memcpy (sptr, "B=\"", 3); break;
         case 3 : memcpy (sptr, "C=\"", 3); break;
         case 4 : memcpy (sptr, "D=\"", 3); break;
         case 5 : memcpy (sptr, "E=\"", 3); break;
         case 6 : memcpy (sptr, "F=\"", 3); break;
         default : memcpy (sptr, "X=\"", 3); break;
      }
      sptr += 3;
      while (*cptr && sptr < zptr)
      {
         if (*cptr == '\"')
         {
            /* escape double quotes, by doubling up */
            if (sptr+2 < zptr)
            {
               cptr++;
               *sptr++ = '\"';
               *sptr++ = '\"';
            }
            else
               zptr = sptr;
            continue;
         }

         if (*cptr == '\'')
         {
            /* escape single quotes by concatenation */
            if (sptr+7 < zptr)
            {
               cptr++;
               memcpy (sptr, "\"+\"\'\"+\"", 7);
               sptr += 7;
            }
            else
               sptr = zptr;
            continue;
         }

         if (sptr < zptr) *sptr++ = *cptr++;
      }

      *sptr++ = '\"';
      *sptr++ = '\0';
      Length = sptr - (char*)rqptr->rqCgi.BufferCurrentPtr - sizeof(short);
      *(short*)rqptr->rqCgi.BufferCurrentPtr = Length;
      rqptr->rqCgi.BufferRemaining -= Length + sizeof(short);
      rqptr->rqCgi.BufferCurrentPtr += Length + sizeof(short);
   }
   SymbolValueLength = cptr - SymbolValue;

   /* assign the temporary symbol value(s) to the CGI symbol */
   if (rqptr->rqCgi.BufferRemaining <= 256 + sizeof(short))
      CgiVariableBufferMemory (rqptr, DclSysCommandSize);
   sptr = rqptr->rqCgi.BufferCurrentPtr + sizeof(short);
   for (cptr = CgiVariablePrefixPtr; *cptr; *sptr++ = *cptr++);
   for (cptr = SymbolName; *cptr; *sptr++ = *cptr++);
   switch (SymbolCount)
   {
      case 1 : memcpy (sptr, "==A", 4); sptr += 4; break;
      case 2 : memcpy (sptr, "==A+B", 6); sptr += 6; break;
      case 3 : memcpy (sptr, "==A+B+C", 8); sptr += 8; break;
      case 4 : memcpy (sptr, "==A+B+C+D", 10); sptr += 10; break;
      case 5 : memcpy (sptr, "==A+B+C+D+E", 12); sptr += 12; break;
      case 6 : memcpy (sptr, "==A+B+C+D+E+F", 14); sptr += 14; break;
      default : break;
   }
   Length = sptr - (char*)rqptr->rqCgi.BufferCurrentPtr - sizeof(short);

   /* 1005 seems to be a MAGIC TOTAL LINE LENGTH (for this approach anyway) */
   if (SymbolCount > 6 ||
       Length + SymbolValueLength > 1006)
   {
      /* cannot create a symbol this size */
      rqptr->rqResponse.ErrorTextPtr = SymbolName;
      rqptr->rqResponse.ErrorOtherTextPtr = "DCL symbol assignment too large!";
      ErrorVmsStatus (rqptr, CLI$_BUFOVF, FI_LI);
      return (STS$K_ERROR);
   }

   *(short*)rqptr->rqCgi.BufferCurrentPtr = Length;
   rqptr->rqCgi.BufferRemaining -= Length + sizeof(short);
   rqptr->rqCgi.BufferCurrentPtr += Length + sizeof(short);

   /* not really necessary, but let's be tidy */
   if (rqptr->rqCgi.BufferRemaining <=
       sizeof(DeleteAllLocalSymbol) + sizeof(short))
      CgiVariableBufferMemory (rqptr, DclSysCommandSize);
   memcpy (rqptr->rqCgi.BufferCurrentPtr + sizeof(short),
           DeleteAllLocalSymbol, sizeof(DeleteAllLocalSymbol));
   *(short*)rqptr->rqCgi.BufferCurrentPtr = sizeof(DeleteAllLocalSymbol);
   rqptr->rqCgi.BufferRemaining -= sizeof(DeleteAllLocalSymbol) + sizeof(short);
   rqptr->rqCgi.BufferCurrentPtr += sizeof(DeleteAllLocalSymbol) + sizeof(short);

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Allocate, or reallocate on subsequent calls, memory for storing the CGI
variables in.  Adjusts the CGI variable buffer pointers, lengths, etc,
appropriately.
*/ 

CgiVariableBufferMemory
(
struct RequestStruct *rqptr,
int BufferChunk
)
{
   int  CurrentLength,
        CurrentOffset;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "CgiVariableBufferMemory() %d %d\n",
               rqptr->rqCgi.BufferLength, BufferChunk);

   if (!rqptr->rqCgi.BufferLength)
   {
      /* initialize CGI variable buffer */
      rqptr->rqCgi.BufferLength = rqptr->rqCgi.BufferRemaining = BufferChunk;
      rqptr->rqCgi.BufferPtr = rqptr->rqCgi.BufferCurrentPtr =
         VmGetHeap (rqptr, BufferChunk);
      return;
   }

   CurrentLength = rqptr->rqCgi.BufferLength;
   CurrentOffset = rqptr->rqCgi.BufferCurrentPtr - rqptr->rqCgi.BufferPtr;

   rqptr->rqCgi.BufferPtr =
      VmReallocHeap (rqptr, rqptr->rqCgi.BufferPtr,
                     CurrentLength + BufferChunk, FI_LI);

   rqptr->rqCgi.BufferLength = CurrentLength + BufferChunk;
   rqptr->rqCgi.BufferRemaining += BufferChunk;
   rqptr->rqCgi.BufferCurrentPtr = rqptr->rqCgi.BufferPtr + CurrentOffset;
}

/*****************************************************************************/
/*
Process output from a CGI script (or even plain DCL processing).  For CGI
scripts check the first output from each for CGI-relevant HTTP header lines. 
For all output check that carriage-control is as required.  Returns one of two
things.   Either a constant value ("DCL_OUTPUT_...") that indicates some event
in output processing, or a value indicating by how much the count of bytes in
the buffer should be increased (practically this can only be 0, 1, or 2, for
added carriage-control).
*/ 

int CgiOutput
(
struct RequestStruct *rqptr,
char *OutputPtr,
int OutputCount
)
{
   boolean  CarRet,
            GenerateHeader;
   int  cnt,
        AbsorbCount,
        HeaderLineCount,
        Number;
   char  *cptr, *sptr, *zptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "CgiOutput() %d %d %d\n",
               rqptr, OutputPtr, OutputCount);

   cptr = OutputPtr;
   cnt = OutputCount;

   if (cptr == NULL)
   {
      /********************/
      /* reset CGI output */
      /********************/

      rqptr->rqCgi.BufferRecords = 
      rqptr->rqCgi.CalloutInProgress =
         rqptr->rqCgi.ContentEncoding =
         rqptr->rqCgi.ContentTypeText =
         rqptr->rqCgi.ProcessingBody = false;

      rqptr->rqCgi.CalloutOutputCount =
         rqptr->rqCgi.HeaderLineCount =
         rqptr->rqCgi.OutputMode =
         rqptr->rqCgi.RecordCount =
         rqptr->rqCgi.XVMSRecordMode = 0;

      return (0);
   }

   rqptr->rqCgi.RecordCount++;

   if (rqptr->rqCgi.EofLength)
   {
      if (cnt >= rqptr->rqCgi.EofLength &&
          cnt <= rqptr->rqCgi.EofLength+2 &&
          !memcmp (cptr, rqptr->rqCgi.EofPtr, rqptr->rqCgi.EofLength))
      {
         /******************************/
         /* end of output from script! */
         /******************************/

         if (!rqptr->rqCgi.IsCliDcl &&
             !rqptr->rqCgi.ProcessingBody &&
             Config.cfScript.CgiStrictOutput)
         {
            /* hmmmm, didn't receive any output */
            if (rqptr->WatchItem && (WatchEnabled & WATCH_CGI))
               WatchThis (rqptr, FI_LI, WATCH_CGI, ErrorCgiNotStrict);
            if (Debug) fprintf (stdout, "NOT SCRICT\n");
            return (CGI_OUTPUT_NOT_STRICT);
         }

         if (Debug) fprintf (stdout, "OUTPUT EOF!\n");
         return (CGI_OUTPUT_END);
      }
   }

   if (rqptr->rqCgi.CalloutInProgress)
   {
      /********************************/
      /* output escape is in progress */
      /********************************/

      if (cnt >= rqptr->rqCgi.EotLength &&
          cnt <= rqptr->rqCgi.EotLength+2 &&
          !memcmp (cptr, rqptr->rqCgi.EotPtr, rqptr->rqCgi.EotLength))
      {
         /******************************/
         /* end of escape from script! */
         /******************************/

         if (Debug) fprintf (stdout, "OUTPUT EOT!\n");
         return (CGI_OUTPUT_ESCAPE_END);
      }

      return (CGI_OUTPUT_ESCAPE);
   }

   if (rqptr->rqCgi.EscLength)
   {
      if (cnt >= rqptr->rqCgi.EscLength &&
          cnt <= rqptr->rqCgi.EscLength+2 &&
          !memcmp (cptr, rqptr->rqCgi.EscPtr, rqptr->rqCgi.EscLength))
      {
         /******************************/
         /* escape from script output! */
         /******************************/

         if (Debug) fprintf (stdout, "OUTPUT ESC!\n");
         return (CGI_OUTPUT_ESCAPE_BEGIN);
      }
   }

   AbsorbCount = HeaderLineCount = 0;

   if (!rqptr->rqCgi.ProcessingBody && !rqptr->rqCgi.IsCliDcl)
   {
      /*************************/
      /* processing CGI header */
      /*************************/

      /* look at each line in the script-generated CGI response header */
      GenerateHeader = false;
      while (!rqptr->rqCgi.ProcessingBody)
      { 
         HeaderLineCount++;
         rqptr->rqCgi.HeaderLineCount++;

         /* scan to the end of this line and check carriage-control */
         for (zptr = cptr;
              *zptr && *zptr != '\n' && *(unsigned short*)zptr != '\r\n';
              zptr++);
         switch (*zptr)
         {
            case '\0' : sptr = "\\0"; CarRet = false; break;
            case '\n' : sptr = "\\n"; CarRet = true; break;
            case '\r' : sptr = "\\r\\n"; CarRet = true;
         }

         if (rqptr->WatchItem && (WatchEnabled & WATCH_CGI))
         {
            WatchThis (rqptr, FI_LI, WATCH_CGI,
                       "RESPONSE header line !UL \'!AZ\' !UL bytes",
                       rqptr->rqCgi.HeaderLineCount, sptr, zptr-cptr);
            WatchDataFormatted ("!#AZ\n", zptr-cptr, cptr);
         }

         /* continue on the the beginning of (any) next line */
         if (*zptr == '\r') zptr++;
         if (*zptr == '\n') zptr++;

         if (Debug) fprintf (stdout, "|%*.*s|\n", zptr-cptr, zptr-cptr, cptr);

         if (rqptr->rqCgi.HeaderLineCount == 1 &&
             *cptr == 'H' && !memcmp (cptr, "HTTP/1.", 7))
         {
            /*************************************************/
            /* script is supplying the full HTTP data stream */
            /*************************************************/

            if (Debug) fprintf (stdout, "(HTTP data stream)\n");
            rqptr->rqCgi.ProcessingBody = true;

            /* a simple way to generate 0.9 responses, just for testing ! */
            if (!memcmp (cptr+4, "/0.9", 4)) *(long*)cptr = 'PTTH';

            /* get the response status code for logging purposes */
            while (*cptr && !ISLWS(*cptr)) cptr++;
            while (*cptr && !isdigit(*cptr)) cptr++;
            if (isdigit(*cptr)) rqptr->rqResponse.HttpStatus = atoi(cptr);

            if (rqptr->WatchItem && (WatchEnabled & WATCH_CGI))
               WatchThis (rqptr, FI_LI, WATCH_CGI,
                          "RESPONSE stream mode (HTTP)");

            return (0);
         }

         if (rqptr->rqCgi.HeaderLineCount > 1 &&
             (!*cptr || *cptr == '\n' || *(unsigned short*)cptr == '\r\n'))
         {
            /***************************/
            /* end of response header! */
            /***************************/

            if (Debug) fprintf (stdout, "end header\n");

            if (!rqptr->rqCgi.OutputMode)
            {
               if (rqptr->rqCgi.XVMSRecordMode)
               {
                  if (rqptr->rqCgi.XVMSRecordMode-1)
                     rqptr->rqCgi.OutputMode = CGI_OUTPUT_MODE_RECORD;
                  else
                     rqptr->rqCgi.OutputMode = CGI_OUTPUT_MODE_STREAM;
               }
               else
               /* always enforce stream mode if it's encoded in some way! */
               if (rqptr->rqCgi.ContentEncoding)
                  rqptr->rqCgi.OutputMode = CGI_OUTPUT_MODE_STREAM;
               else
               if (rqptr->rqCgi.ContentTypeText)
                  rqptr->rqCgi.OutputMode = CGI_OUTPUT_MODE_RECORD;
               else
                  rqptr->rqCgi.OutputMode = CGI_OUTPUT_MODE_STREAM;
            }

            if (rqptr->WatchItem && (WatchEnabled & WATCH_CGI))
            {
               switch (rqptr->rqCgi.OutputMode)
               {
                  case CGI_OUTPUT_MODE_STREAM : cptr = "stream"; break;
                  case CGI_OUTPUT_MODE_RECORD : cptr = "record"; break;
                  case CGI_OUTPUT_MODE_CRLF : cptr = "crlf"; break;
                  default : cptr = "?";
               }
               WatchThis (rqptr, FI_LI, WATCH_CGI, "RESPONSE !AZ mode", cptr);
            }

            GenerateHeader = rqptr->rqCgi.ProcessingBody = true;
         }

         if (toupper(*cptr) == 'C' && strsame (cptr, "Content-Type:", 13))
         {
            /****************/
            /* content-type */
            /****************/

            cptr += 13;
            while (ISLWS(*cptr) && NOTEOL(*cptr)) cptr++;
            sptr = cptr;
            while (NOTEOL(*cptr)) cptr++;
            rqptr->rqHeader.ContentTypePtr = VmGetHeap (rqptr, cptr-sptr+1);
            memcpy (rqptr->rqHeader.ContentTypePtr, sptr, cptr-sptr);
            rqptr->rqHeader.ContentTypePtr[cptr-sptr] = '\0';

            if (strsame (sptr, "text/", 5))
               rqptr->rqCgi.ContentTypeText = true;
            else
               rqptr->rqCgi.ContentTypeText = false;

            if (!rqptr->rqResponse.HeaderLength)
            {
               /* we can absorb the header field this early on */
               AbsorbCount = zptr - OutputPtr;
            }
         }
         else
         if (toupper(*cptr) == 'C' && strsame (cptr, "Content-Encoding:", 17))
         {
            /********************/
            /* content-encoding */
            /********************/

            /* take note the response body is encoded in some way */
            rqptr->rqCgi.ContentEncoding = true;
         }
         else
         if (toupper(*cptr) == 'S' && strsame (cptr, "Status:", 7))
         {
            /**********/
            /* status */
            /**********/

            /* create HTTP header status line using supplied status */
            cptr += 7;
            while (*cptr++ && !isdigit(*cptr) && *cptr != '\n') cptr++;
            /* get the response status code for header and logging purposes */
            if (isdigit(*cptr)) rqptr->rqResponse.HttpStatus = atoi(cptr);

            if (!rqptr->rqResponse.HeaderLength)
            {
               /* we can absorb the header field this early on */
               AbsorbCount = zptr - OutputPtr;
            }
         }
         else
         if (toupper(*cptr) == 'S' && strsame (cptr, "Script-Control:", 15))
         {
            /*****************************************/
            /* script control (Apache Group CGI/1.2) */
            /*****************************************/

            cptr += 15;
            while (*cptr)
            {
               while ((ISLWS(*cptr) || *cptr == ',' || *cptr == ';') &&
                       NOTEOL(*cptr)) cptr++;
               if (EOL(*cptr)) break;
               if (strsame (cptr, "no-abort", 8))
               {
                  HttpdTimerSet (rqptr, TIMER_OUTPUT, -1);
                  HttpdTimerSet (rqptr, TIMER_NOPROGRESS, -1);
                  cptr += 8;
               }
               else
               if (strsame (cptr, "X-crlf-mode", 11))
               {
                  rqptr->rqCgi.OutputMode = CGI_OUTPUT_MODE_CRLF;
                  cptr += 11;
               }
               else
               if (strsame (cptr, "X-record-mode", 13))
               {
                  rqptr->rqCgi.OutputMode = CGI_OUTPUT_MODE_RECORD;
                  cptr += 13;
               }
               else
               if (strsame (cptr, "X-stream-mode", 13))
               {
                  rqptr->rqCgi.OutputMode = CGI_OUTPUT_MODE_STREAM;
                  cptr += 13;
               }
               else
               if (strsame (cptr, "X-buffer-records", 16))
               {
                  rqptr->rqCgi.BufferRecords = true;
                  cptr += 16;
               }
               else
               if (strsame (cptr, "X-timeout-output=", 17))
               {
                  cptr += 17;
                  if (strsame (cptr, "none", 4))
                  {
                     Number = -1;
                     cptr += 4;
                  }
                  else
                  {
                     Number = atoi(cptr);
                     while (isdigit(*cptr) || *cptr == '-') cptr++;
                  }
                  HttpdTimerSet (rqptr, TIMER_OUTPUT, Number);
               }
               else
               if (strsame (cptr, "X-timeout-noprogress=", 21))
               {
                  cptr += 21;
                  if (strsame (cptr, "none", 4))
                  {
                     Number = -1;
                     cptr += 4;
                  }
                  else
                  {
                     Number = atoi(cptr);
                     while (isdigit(*cptr) || *cptr == '-') cptr++;
                  }
                  HttpdTimerSet (rqptr, TIMER_NOPROGRESS, Number);
               }
               else
               if (strsame (cptr, "X-lifetime=", 11))
               {
                  cptr += 11;
                  if (strsame (cptr, "none", 4))
                  {
                     Number = -1;
                     cptr += 4;
                  }
                  else
                  {
                     if (!(Number = atoi(cptr) * 60))
                     {
                        if (rqptr->DclTaskPtr->TaskType ==
                            DCL_TASK_TYPE_CGI_SCRIPT)
                           Number = Config.cfScript.ZombieLifeTime+1;
                        else
                           Number = Config.cfScript.CgiPlusLifeTime+1;
                     }
                     while (isdigit(*cptr) || *cptr == '-') cptr++;
                  }
                  rqptr->DclTaskPtr->LifeTimeCount = Number;
               }
               else
               {
                  /* ignore anything else */
                  while (!ISLWS(*cptr) && NOTEOL(*cptr)) cptr++;
                  if (EOL(*cptr)) break;
               }
            }

            if (!rqptr->rqResponse.HeaderLength)
            {
               /* we can absorb the header field this early on */
               AbsorbCount = zptr - OutputPtr;
            }
         }
         else
         if (toupper(*cptr) == 'X' && strsame (cptr, "X-vms-record-mode:", 18))
         {
            /*****************************/
            /* VMS Apache record control */
            /*****************************/

            /*
               VMS Apache uses an eXtension header field so that the script
               can convey to the server whether the output should be processed
               as a binary stream or as records (the default).
            */

            cptr += 18;
            while (ISLWS(*cptr) && NOTEOL(*cptr)) cptr++;
            /* this value should either 0 or 1 ("no" or "yes") plus 1 */
            rqptr->rqCgi.XVMSRecordMode = atoi(cptr)+1;

            if (!rqptr->rqResponse.HeaderLength)
            {
               /* we can absorb the header field this early on */
               AbsorbCount = zptr - OutputPtr;
            }
         }
         else
         if (toupper(*cptr) == 'L' && strsame (cptr, "Location:", 9))
         {
            /************/
            /* location */
            /************/

            rqptr->rqResponse.HttpStatus = 302;
            GenerateHeader = true;
         }
         else
         if (rqptr->rqCgi.HeaderLineCount == 1)
         {
            /**************************/
            /* non-CGI-header-output? */
            /**************************/

            if (Config.cfScript.CgiStrictOutput)
            {
               if (rqptr->WatchItem && (WatchEnabled & WATCH_CGI))
                  WatchThis (rqptr, FI_LI, WATCH_CGI, ErrorCgiNotStrict);
               return (CGI_OUTPUT_NOT_STRICT);
            }

            if (Debug) fprintf (stdout, "plain-text stream\n");
            HttpHeader (rqptr, 200, "text/plain", -1, NULL, NULL);
            HeaderLineCount = 0;
            rqptr->rqCgi.ContentTypeText = rqptr->rqCgi.ProcessingBody = true;
            rqptr->rqCgi.OutputMode = CGI_OUTPUT_MODE_RECORD;
         }
         else
         {
            /**********************/
            /* other header field */
            /**********************/

            GenerateHeader = true;
         }
         
         if (GenerateHeader && !rqptr->rqResponse.HeaderLength)
         {
            HttpHeader (rqptr, rqptr->rqResponse.HttpStatus,
                        rqptr->rqHeader.ContentTypePtr, -1, NULL, NULL);
            /* remove generated empty header line, script supplies rest */
            if (rqptr->rqResponse.HeaderLength > 2)
            {
               rqptr->rqResponse.HeaderPtr[
                  rqptr->rqResponse.HeaderLength-2] = '\0';
               rqptr->rqResponse.HeaderLength -= 2;
            }
         }

         /* bump to the start of the next (if any) line */
         if (!*(cptr = zptr)) break;
      }

      /* if not a blank line then and it all must have been absorbed */
      if (OutputCount && AbsorbCount == OutputCount) return (AbsorbCount);
   }

   /*************************/
   /* HTTP carriage-control */
   /*************************/

   if (rqptr->rqCgi.OutputMode == CGI_OUTPUT_MODE_RECORD ||
       rqptr->rqCgi.IsCliDcl)
   {
      if (Debug) fprintf (stdout, "record mode\n");
      if (!OutputCount || OutputPtr[OutputCount-1] != '\n' )
      {
         OutputPtr[OutputCount++] = '\n';
         OutputPtr[OutputCount] = '\0';
         return (AbsorbCount);
      }
   }
   else
   if (HeaderLineCount == 1 && !CarRet)
   {
      if (Debug) fprintf (stdout, "response header\n");
      if (!OutputCount || OutputPtr[OutputCount-1] != '\n' )
      {
         /* by rights CGI header lines should have '\r\n' carriage-control */
         OutputPtr[OutputCount++] = '\r';
         OutputPtr[OutputCount++] = '\n';
         OutputPtr[OutputCount] = '\0';
         return (AbsorbCount);
      }
   }
   else
   if (rqptr->rqCgi.OutputMode == CGI_OUTPUT_MODE_CRLF)
   {
      if (Debug) fprintf (stdout, "crlf mode\n");
      if (!OutputCount ||
          OutputPtr[OutputCount-1] != '\n' ||
          (OutputCount >= 2 && OutputPtr[OutputCount-2] != '\r'))
      {
         /* empty record, or no trailing <LF>, or no trailing <CR><LF> */
         if (OutputPtr[OutputCount-1] == '\n') OutputCount--;
         OutputPtr[OutputCount++] = '\r';
         OutputPtr[OutputCount++] = '\n';
         OutputPtr[OutputCount] = '\0';
         return (AbsorbCount);
      }
   }

   return (AbsorbCount);
}

/*****************************************************************************/
/*
Generate a (hopefully) unique sequence of 224 bits (28 bytes, which is a fair
bit :^) The string is generated using the a count sequence and quadword binary
times each time it is called.  This provides a continuous, non-repeating series
of unlikely bit combinations with a one in 2^224 chance (I think!) of presence
in an I/O stream.
*/ 

CgiSequence
(
char OneChar,
char *CgiSequencePtr,
int *CgiSequenceLengthPtr
)
{                                           
   static $DESCRIPTOR (SequenceFaoDsc, "^!AZ-!8XL!8XL!8XL-\0");
   static $DESCRIPTOR (SequenceDsc, "");
   static char  OneCharString [] = " ";
   static int  SequenceCount = 0;

   unsigned short  Length;
   unsigned long  BinTime[2];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "CgiSequence()\n");

   SequenceCount++;
   sys$gettim(&BinTime);
   SequenceDsc.dsc$w_length = 29;
   SequenceDsc.dsc$a_pointer = CgiSequencePtr;
   OneCharString[0] = OneChar;
   sys$fao (&SequenceFaoDsc, &Length, &SequenceDsc,
            OneCharString, SequenceCount, BinTime[1], BinTime[0]);
   *CgiSequenceLengthPtr = Length - 1;

   if (Debug)
      fprintf (stdout, "%d |%s|\n", *CgiSequenceLengthPtr, CgiSequencePtr);
}

/*****************************************************************************/

