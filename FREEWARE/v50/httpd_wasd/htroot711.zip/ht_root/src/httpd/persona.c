/*****************************************************************************/
/*
                                Persona.c

Tuck in the cape.
Don the hat and glasses.
There ... we're hardly recognizable!

For VMS versions 6.2 and later the sys$persona...() system services provide a
reliable mechanism for a process to assume all the defining characteristics of
another user.  This offers a number of potential uses, in particular scripting
under non-server user names.  As the persona services affect processes job-wide
(i.e. a (sub)process tree) this facility may only be used where scripting
processes can be detached and not spawned.

Obviously, for VMS versions that do not support the persona services this
facility is not available!


VERSION HISTORY
---------------
19-NOV-2000  MGD  bugfix; VAX requires IMP$M_ASSUME_SECURITY 
01-OCT-2000  MGD  initial
*/
/*****************************************************************************/

#define WASD_MODULE "PERSONA"

#ifdef PERSONA_STUB 

#undef  _VMS_V6_SOURCE
#define _VMS_V6_SOURCE
#undef  __VMS_VER
#define __VMS_VER 60000000
#undef  __CRTL_VER
#define __CRTL_VER 60000000

#else /* PERSONA_STUB */

#undef  _VMS_V6_SOURCE
#define _VMS_V6_SOURCE
#undef  __VMS_VER
#define __VMS_VER 60200000
#undef  __CRTL_VER
#define __CRTL_VER 60200000

#endif /* PERSONA_STUB */

/* standard C header files */
#include <errno.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <descrip.h>
#include <jpidef.h>
#include <ssdef.h>
#include <stsdef.h>

/* application-related header files */
#include "wasd.h"

#ifdef PERSONA_STUB 

/*
For versions of VMS where the sys$persona...() services are not available
provide some that can be linked to but just return a detectable error.  On
these systems the WASD persona-based features will of course be unavailable.
*/
#define sys$persona_create PersonaStub
#define sys$persona_delete PersonaStub
#define sys$persona_assume PersonaStub

#endif /* PERSONA_STUB */

/******************/
/* global storage */
/******************/

#define PERSONA_DEFAULT_CACHE_SIZE 32

struct  ListHeadStruct  PersonaCacheList;
int  PersonaCacheCount,
     PersonaCacheEntries;

char  PersonaIdentName [64];
unsigned long  PersonaRightsIdent;

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern char  Utility[];

extern struct ConfigStruct  Config;

/****************************************************************************/
/*
If an identifier is required for access to the non-server-account scripting
persona services then check that it exists.
*/ 

int PersonaInit ()

{
   static $DESCRIPTOR (PersonaIdentNameDsc, PersonaIdentName);

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "PersonaInit()\n");

#ifdef PERSONA_STUB
   return (SS$_ABORT);
#else

   if (!PersonaIdentName[0]) return (SS$_NORMAL);

   PersonaIdentNameDsc.dsc$w_length = strlen(PersonaIdentName);

   status = sys$asctoid (&PersonaIdentNameDsc, &PersonaRightsIdent, 0);

   if (VMSnok (status))
   {
      WriteFaoStdout (
"%!AZ-W-PERSONA, services disabled; \'!AZ\'\n-!%M\n",
         Utility, PersonaIdentName, status);
   }

   return (status);

#endif
}

/*****************************************************************************/
/*
Using the sys$persona...() services assume the persona of the specified user
name.  If 'UserName' is NULL then return to the "natural" persona of the
process.
*/

#define ISS$C_ID_NATURAL 1
#define IMP$M_ASSUME_SECURITY 1

int PersonaAssume (char *UserName)

{
   static int  PersonaHandle;
   static long  PersonaCreateFlags;
#ifndef __ALPHA
   static long  PersonaAssumeFlags = IMP$M_ASSUME_SECURITY;
#endif
   static $DESCRIPTOR (UserNameDsc, "");

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "PersonaAssume() |%s|\n", UserName);

   if (UserName == NULL)
   {
      /* resume being the original server persona */
      PersonaHandle = ISS$C_ID_NATURAL;
   }
   else
   if (!(PersonaHandle = PersonaCache (UserName, 0)))
   {
      UserNameDsc.dsc$a_pointer = UserName;
      UserNameDsc.dsc$w_length = strlen(UserName);

#ifdef __ALPHA
      status = sys$persona_create (&PersonaHandle, &UserNameDsc,
                                   PersonaCreateFlags, 0, 0);
#else
      status = sys$persona_create (&PersonaHandle, &UserNameDsc,
                                   PersonaCreateFlags);
#endif
      if (Debug) fprintf (stdout, "sys$persona_create() %%X%08.08X\n", status);
      if (VMSnok (status)) return (status);

      /* update the persona cache */
      PersonaCache (UserName, PersonaHandle);
   }

#ifdef __ALPHA
   status = sys$persona_assume (&PersonaHandle, 0, 0, 0);
#else
   status = sys$persona_assume (&PersonaHandle, PersonaAssumeFlags);
#endif
   if (Debug) fprintf (stdout, "sys$persona_assume() %%X%08.08X\n", status);

   return (status);
} 

/*****************************************************************************/
/*
Keep a linked-list of cache entries.  If 'UserName' is NULL then the list is
reset (this happen on authorization rule reload and DCL script purge).  If
'UserName' is  non-NULL and 'PersonaHandle' zero the list is searched for a
matching username and any associated persona returned.  If 'UserName' is
non-NULL and 'PersonaHandle' non-zero 'PersonaHandle' add/update a cache entry. 
If the list has reached maximum size reuse the last entry, otherwise create a
new entry.  Move/add the entry to the head of the list.  It's therefore a
first-in/first-out queue.  Cache contents remain current until demands on space
(due to new entries) cycles through the maximum available entries.  To
explicitly flush the contents reload the authorization rules. 
*/ 

int PersonaCache
(
char *UserName,
int PersonaHandle
)
{
   struct ListEntryStruct  *leptr;
   struct PersonaCacheStruct  *pcptr;
   char  *cptr, *sptr, *zptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "PersonaCache() |%s| %d\n", UserName, PersonaHandle);

   if (UserName == NULL || !PersonaCacheEntries)
   {
      /***************/
      /* reset cache */
      /***************/

      PersonaCacheEntries = Config.cfMisc.PersonaCacheEntries;
      if (!PersonaCacheEntries)
         PersonaCacheEntries = PERSONA_DEFAULT_CACHE_SIZE;
      PersonaCacheCount = 0;

      /* empty the list */
      leptr = PersonaCacheList.HeadPtr;
      PersonaCacheList.HeadPtr = PersonaCacheList.TailPtr = NULL;
      PersonaCacheList.EntryCount = 0;
      while (leptr != NULL)
      {
         pcptr = (struct PersonaCacheStruct*)leptr;
         leptr = leptr->NextPtr;
         VmFree (pcptr, FI_LI);
      }

      if (UserName == NULL) return (0);
   }

   if (PersonaHandle == 0)
   {
      /****************/
      /* search cache */
      /****************/

      /* process the cache entry list from most to least recent */
      for (leptr = PersonaCacheList.HeadPtr;
           leptr != NULL;
           leptr = leptr->NextPtr)
      {
         pcptr = (struct PersonaCacheStruct*)leptr;

         if (Debug)
            fprintf (stdout, "|%s| %d\n",
                     pcptr->UserName, pcptr->PersonaHandle);

         /* if this one has been reset there won't be any more down the list */
         if (!pcptr->UserName[0]) break;

         /* string comparison */
         cptr = UserName;
         sptr = pcptr->UserName;
         while (*cptr && *sptr && toupper(*cptr) == toupper(*sptr))
         {
            cptr++;
            sptr++;
         }
         if (*cptr || *sptr) continue;

         /*************/
         /* cache hit */
         /*************/

         if ((void*)PersonaCacheList.HeadPtr != (void*)pcptr)
         {
            /* move it to the head of the list */
            ListRemove (&PersonaCacheList, pcptr);
            ListAddHead (&PersonaCacheList, pcptr);
         }

         pcptr->HitCount++;
         sys$gettim (&pcptr->LastBinaryTime);

         return (pcptr->PersonaHandle);
      }

      /* not found */
      return (0);
   }

   /****************/
   /* update cache */
   /****************/

   if (PersonaCacheCount < PersonaCacheEntries)
   {
      /* allocate memory for a new entry */
      pcptr = (struct PersonaCacheStruct*)
         VmGet (sizeof (struct PersonaCacheStruct));
      PersonaCacheCount++;
   }
   else
   {
      /* reuse the tail entry (least recent) */
      pcptr = PersonaCacheList.TailPtr;
      pcptr->ReuseCount++;
      ListRemove (&PersonaCacheList, pcptr);
      /* delete the previous persona (uses dynamic storage) */
      if (pcptr->PersonaHandle) sys$persona_delete (&pcptr->PersonaHandle);
   }

   /* add entry to the head of the user cache list (most recent) */
   ListAddHead (&PersonaCacheList, pcptr);

   zptr = (sptr = pcptr->UserName) + sizeof(pcptr->UserName)-1;
   for (cptr = UserName; *cptr && sptr < zptr; *sptr++ = *cptr++);
   *sptr = '\0';
   pcptr->PersonaHandle = PersonaHandle;
   pcptr->HitCount = 1;
   sys$gettim (&pcptr->LastBinaryTime);

   return (PersonaHandle);
}

/****************************************************************************/
/*
Get the current persona's process rights list.  Check for the required
identifiers.  If found return success, if not found return no-such-identifier. 
Can return other VMS error status.
*/ 

int PersonaHoldsIdentifier ()

{
   static unsigned short  RetLength;

   static struct
   {
      unsigned short  buf_len;
      unsigned short  item;
      unsigned char   *buf_addr;
      unsigned short  *short_ret_len;
   }
   JpiItem [] =
   {
      { 0, JPI$_PROCESS_RIGHTS, 0, &RetLength },
      {0,0,0,0}
   };

   int  idx, status;
   struct
   {
      unsigned long  identifier;
      unsigned long  attributes;
   } JpiProcessRights [PERSONA_RIGHTS_MAX+1];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "PersonaHoldsIdentifier()\n");

   /* use the final, additional element as a zeroed sentinal */
   JpiProcessRights[PERSONA_RIGHTS_MAX].identifier = 0;
   JpiItem[0].buf_len = sizeof(JpiProcessRights) - sizeof(JpiProcessRights[0]);
   JpiItem[0].buf_addr = &JpiProcessRights;

   if (VMSnok (status = sys$getjpiw (0, 0, 0, &JpiItem, 0, 0, 0)))
   {
      ErrorNoticed (status, "sys$getjpiw()", FI_LI);
      return (status);
   }
   if (Debug) fprintf (stdout, "RetLength: %d %d\n", RetLength, RetLength/8);

   for (idx = 0; JpiProcessRights[idx].identifier; idx++)
      if (JpiProcessRights[idx].identifier == PersonaRightsIdent)
         return (SS$_NORMAL);

   return (SS$_NOSUCHID);
}

/*****************************************************************************/
/*
See note in module macro section.
*/

int PersonaStub (...)

{
   if (Debug) fprintf (stdout, "PersonaStub()\n");
   return (SS$_ABORT);
}

/*****************************************************************************/

n                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    