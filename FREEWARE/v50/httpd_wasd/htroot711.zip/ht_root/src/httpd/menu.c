/*****************************************************************************/
/*
                                  Menu.c

This module implements a full multi-threaded, AST-driven, asynchronous "menu" 
file send.  The AST-driven nature makes the code a little more difficult to 
follow, but creates a powerful, event-driven, multi-threaded server.  All of 
the necessary functions implementing this module are designed to be non-
blocking. 

This module uses the NetWriteBuffered() function to buffer any output it can
into larger chunks before sending it to the client.

Implements the WASD menu file.  A WASD menu comprises a file with 1, 2, 3 or 
more blank-line delimitted sections.  The optional first is the document 
title.  The optional second is a menu description.  The mandatory section 
consists of the menu items.  Any blank-line delimtted sections thereafter 
alternate between descriptive paragraphs and menu sections.  For example: 

|This is the HTML <TITLE> line.  It must be only one line.|
||
|This is the descriptive paragraph.|
|It can be multi-line.|
||
|HT_DATA:FILE1.TXT   This is the first text file.|
|HT_DATA:FILE2.TXT   This is the second text file.|
|HT_DATA:FILE1.HTML  This would be an HTML file.|
||
|This is another (optional) descriptive paragraph.|
|It can also be multi-line.|
||
|HT_DATA:FILE1.TXT   This is the first file of the second menu.|
|HT_DATA:FILE2.TXT   This is the second file, etc.|
|!This is a comment|
|*.TXT?  This is a search item
|!The next item lists all matching files from their internal description|
|*.HTML|
 

VERSION HISTORY
---------------
01-SEP-2000  MGD  add optional, local path authorization
                  (for calls from the likes of SSI.C)
04-MAR-2000  MGD  use WriteFao(), et.al.
27-DEC-1999  MGD  support ODS-2 and ODS-5 using ODS module
07-NOV-1998  MGD  WATCH facility
17-AUG-1997  MGD  message database,
                  SYSUAF-authenticated users security-profile
27-FEB-1997  MGD  delete on close for "temporary" files
01-FEB-1997  MGD  HTTPd version 4
23-MAY-1996  MGD  added listing from file descriptions (i.e. Description())
28-MAR-1996  MGD  bugfix, MenuMextContent() caused RequestEnd() to be
                  called twice (two log entries only deleterious effect :^)
01-DEC-1995  MGD  HTTPd version 3
27-SEP-1995  MGD  added "If-Modified-Since:" functionality
07-AUG-1995  MGD  ConfigcfReport.MetaInfoEnabled to allow physical file
                  specification to be included as commentary within menu output
20-DEC-1994  MGD  initial development for multi-threaded daemon
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <descrip.h>
#include <libdef.h>
#include <rms.h>
#include <ssdef.h>
#include <stsdef.h>

/* application-related header files */
#include "wasd.h"

#define WASD_MODULE "MENU"

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern int  WatchEnabled,
            FileBufferSize;

extern char  SoftwareID[];

extern struct AccountingStruct  Accounting;
extern struct ConfigStruct  Config;
extern struct MsgStruct  Msgs;

/*****************************************************************************/
/*
Open the specified file.  If there is a problem opening it then just return 
the status, do not report an error or anything.  This is used to determine 
whether the file exists, as when attempting to open one of multiple, possible 
home pages.

As fixed documents (files) can have revision date/times easily checked any
"If-Modified-Since:" request field date/time supplied in the request is 
processed and the file only sent if modified later than specified.
A "Last-Modified:" field is included in any response header. 

When successfully opened generate an HTTP header if required.  Once open and 
connected the menu interpretation becomes I/O event-driven. 
*/

MenuBegin
(
struct RequestStruct *rqptr,
void *NextTaskFunction,
void *FileOpenErrorFunction,
char *FileName,
boolean AuthorizePath
)
{
   register char  *cptr, *sptr, *zptr;
   register struct MenuTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "MenuBegin() %d |%s|\n",
               rqptr->rqResponse.ErrorReportPtr, FileName);

   if (rqptr->rqResponse.ErrorReportPtr != NULL)
   {
      /* previous error, cause threaded processing to unravel */
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_RESPONSE))
      WatchThis (rqptr, FI_LI, WATCH_RESPONSE, "MENU !AZ", FileName);

   /* set up the task structure (only ever one per request!) */
   rqptr->MenuTaskPtr = tkptr = (struct MenuTaskStruct*)
      VmGetHeap (rqptr, sizeof(struct MenuTaskStruct));

   tkptr->NextTaskFunction = NextTaskFunction;
   tkptr->FileOpenErrorFunction = FileOpenErrorFunction;

   cptr = FileName;
   zptr = (sptr = tkptr->FileName) + sizeof(tkptr->FileName);
   while (*cptr && sptr < zptr) *sptr++ = *cptr++;
   if (sptr >= zptr)
   {
      ErrorGeneralOverflow (rqptr, FI_LI);
      MenuEnd (rqptr);
      return;
   }
   *sptr = '\0';
   tkptr->FileNameLength = sptr - tkptr->FileName;

   if (AuthorizePath)
   {
      /***********************/
      /* check authorization */
      /***********************/

      cptr = MapVmsPath (tkptr->FileName, rqptr);
      Authorize (rqptr, cptr, -1, &MenuAuthorizationAst);
      if (Debug)
         fprintf (stdout, "rqAuth.FinalStatus: %%X%08.08X\n",
                  rqptr->rqAuth.FinalStatus);
      if (VMSnok (rqptr->rqAuth.FinalStatus))
      {
         /* if asynchronous authentication is underway then just wait for it */
         if (rqptr->rqAuth.FinalStatus == AUTH_PENDING) return;
         MenuEnd (rqptr);
         return;
      }
   }

   /* not to-be-authorized, or authorized ... just carry on regardless! */
   MenuAuthorizationAst (rqptr);
} 

/*****************************************************************************/
/*
This function provides an AST target is Authorize()ation ended up being done
asynchronously, otherwise it is just called directly to continue the modules
processing.
*/

MenuAuthorizationAst (struct RequestStruct *rqptr)

{
   int  status,
        FabFop;
   struct MenuTaskStruct  *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "MenuAuthorizationAst() %%X%08.08X\n",
               rqptr->rqAuth.FinalStatus);

   if (VMSnok (rqptr->rqAuth.FinalStatus))
   {
      MenuEnd (rqptr);
      return;
   }

   tkptr = rqptr->MenuTaskPtr;

   if (rqptr->rqAuth.VmsUserProfileLength)
   {
      /*****************************************/
      /* check VMS-authenticated user's access */
      /*****************************************/

      status = AuthVmsCheckUserAccess (rqptr, tkptr->FileName,
                                       tkptr->FileNameLength);
      if (status == RMS$_PRV)
         tkptr->AuthVmsUserHasAccess = false;
      else
      if (VMSok (status))
         tkptr->AuthVmsUserHasAccess = true;
      else
      {
         /* error reported by access check */
         MenuEnd (rqptr);
         return;
      }
   }
   else
      tkptr->AuthVmsUserHasAccess = false;

   /*************/
   /* open file */
   /*************/

   if (rqptr->DeleteOnClose)
      FabFop = FAB$M_DLT;
   else
      FabFop = 0;

   if (tkptr->AuthVmsUserHasAccess)
   {
      EnableSysPrv();
      OdsOpen (&tkptr->FileOds, tkptr->FileName, tkptr->FileNameLength,
               NULL, 0, FAB$M_GET, FabFop, FAB$M_SHRGET, NULL, rqptr);  
      DisableSysPrv();
   }
   else
      OdsOpen (&tkptr->FileOds, tkptr->FileName, tkptr->FileNameLength,
               NULL, 0, FAB$M_GET, FabFop, FAB$M_SHRGET, NULL, rqptr);  

   if (VMSnok (status = tkptr->FileOds.Fab.fab$l_sts))
   {
      /* if its a search list treat directory not found as if file not found */
      if ((tkptr->FileOds.Nam_fnb & NAM$M_SEARCH_LIST) && status == RMS$_DNF)
         status = RMS$_FNF;

      if (tkptr->FileOpenErrorFunction != NULL)
      {
         /* do not report the error, the alternate function will handle it */

         if (rqptr->WatchItem &&
             (WatchEnabled & WATCH_RESPONSE))
            WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                       "MENU %X!8XL %!%M", status, status);

         rqptr->HomePageStatus = status;
         tkptr->NextTaskFunction = tkptr->FileOpenErrorFunction;
         MenuEnd (rqptr);
         return;
      }
      else
      {
         if (!rqptr->AccountingDone)
            rqptr->AccountingDone = ++Accounting.DoMenuCount;
         rqptr->rqResponse.ErrorTextPtr = MapVmsPath (tkptr->FileName, rqptr);
         rqptr->rqResponse.ErrorOtherTextPtr = tkptr->FileName;
         ErrorVmsStatus (rqptr, status, FI_LI);
         MenuEnd (rqptr);
         return;
      }
   }

   if (!rqptr->AccountingDone)
      rqptr->AccountingDone = ++Accounting.DoMenuCount;

   /*******************************/
   /* connect record access block */
   /*******************************/

   tkptr->FileOds.Rab = cc$rms_rab;
   tkptr->FileOds.Rab.rab$l_fab = &tkptr->FileOds.Fab;
   /* 2 buffers and read ahead performance option */
   tkptr->FileOds.Rab.rab$b_mbf = 2;
   tkptr->FileOds.Rab.rab$l_rop = RAB$M_RAH | RAB$M_ASY;
   tkptr->FileOds.Rab.rab$l_ubf = tkptr->ReadBuffer;
   tkptr->FileOds.Rab.rab$w_usz = sizeof(tkptr->ReadBuffer)-1;

   if (VMSnok (status = sys$connect (&tkptr->FileOds.Rab, 0, 0)))
   {
      if (Debug) fprintf (stdout, "sys$connect() %%X%08.08X\n", status);
      rqptr->rqResponse.ErrorTextPtr = MapVmsPath (tkptr->FileName, rqptr);
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->FileName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      MenuEnd (rqptr);
      return;
   }

   /********************/
   /* begin processing */
   /********************/

   if (rqptr->rqResponse.HeaderPtr == NULL)
   {
      rqptr->rqResponse.PreExpired = PRE_EXPIRE_MENU;
      HTTP_HEADER_200_HTML (rqptr);

      if (rqptr->rqHeader.Method == HTTP_METHOD_HEAD)
      {
         MenuEnd (rqptr);
         return;
      }
   }

   /* set then RAB user context storage to the client thread pointer */
   tkptr->FileOds.Rab.rab$l_ctx = rqptr;

   tkptr->MenuBlankLineCount = tkptr->MenuLineCount =
      tkptr->MenuSectionNumber = 0;

   /* network writes are checked for success, fudge the first one! */
   rqptr->rqNet.WriteIOsb.Status = SS$_NORMAL;

   /* queue the first record read, count the number of sections in the menu */
   sys$get (&tkptr->FileOds.Rab, &MenuContents, &MenuContents);
}

/*****************************************************************************/
/*
Ensure the menu file is closed.  Flush the output buffer, activating the next 
task (if any).
*/ 

MenuEnd (struct RequestStruct *rqptr)

{
   register struct MenuTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MenuEnd()\n");

   tkptr = rqptr->MenuTaskPtr;

   if (tkptr->FileOds.Fab.fab$w_ifi)
      OdsClose (&tkptr->FileOds, NULL, rqptr);

   /* release internal RMS parse structures */
   if (tkptr->FileOds.ParseInUse) OdsParseRelease (&tkptr->SearchOds);

   /* declare the next task */
   SysDclAst (tkptr->NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Process the records (lines) of the menu file according to the total count of 
the sections (blank-line delimited text) in the file and the section number 
the current line falls within.  This routine is event-driven, using itself as 
an AST completion routine to sys$get()s.
*/ 

MenuContents (struct RAB *RabPtr)

{
   static char  MenuEndHtml [] = "</BODY>\n</HTML>\n",
                MenuEndListEndHtml [] = "</UL>\n</BODY>\n</HTML>\n";

   register unsigned char  *rptr;
   register struct RequestStruct  *rqptr;
   register struct MenuTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
               "MenuContents() sts: %%X%08.08X stv: %%X%08.08X\n",
               RabPtr->rab$l_sts, RabPtr->rab$l_stv);

   rqptr = RabPtr->rab$l_ctx;
   tkptr = rqptr->MenuTaskPtr;

   if (VMSnok (tkptr->FileOds.Rab.rab$l_sts))
   {
      if (tkptr->FileOds.Rab.rab$l_sts == RMS$_EOF)
      {
         /********************/
         /* end of menu file */
         /********************/

         /* disable implicit listing for now, not convinced it's way to go */
/**
         if (tkptr->MenuSectionNumber <= 2)
         {
            NetWriteBuffered (rqptr, &MenuBeginImplicitDescription,
                             "<P>\n<UL>\n", 9);
            return;
         }
**/

         if (!((tkptr->MenuSectionNumber-1) % 2))
         {
            NetWriteBuffered (rqptr, &MenuEnd,
                             MenuEndListEndHtml,
                             sizeof(MenuEndListEndHtml)-1);
            return;
         }
         else
         {
            NetWriteBuffered (rqptr, &MenuEnd,
                             MenuEndHtml, sizeof(MenuEndHtml)-1);
            return;
         }
      }

      /***************************/
      /* error reading menu file */
      /***************************/

      rqptr->rqResponse.ErrorTextPtr = MapVmsPath (tkptr->FileName, rqptr);
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->FileName;
      ErrorVmsStatus (rqptr, tkptr->FileOds.Rab.rab$l_sts, FI_LI);
      MenuEnd (rqptr);
      return;
   }

   /* terminate the line just read */
   (rptr = tkptr->FileOds.Rab.rab$l_ubf)[tkptr->FileOds.Rab.rab$w_rsz] = '\0';
   /* terminate on any carriage control that may be in the buffer */
   while (*rptr && *rptr != '\r' && *rptr != '\n') rptr++;
   *rptr = '\0';
   if (Debug)
      fprintf (stdout, "tkptr->FileOds.Rab.rab$l_ubf |%s|\n",
               tkptr->FileOds.Rab.rab$l_ubf);

   if (!tkptr->FileOds.Rab.rab$l_ubf[0])
   {
      /**************/
      /* empty line */
      /**************/

      tkptr->MenuBlankLineCount++;
      tkptr->MenuLineCount = 0;
      /* queue another read, completion AST back to this function again */
      sys$get (&tkptr->FileOds.Rab, &MenuContents, &MenuContents);
      return;
   }

   if (tkptr->FileOds.Rab.rab$l_ubf[0] == '!')
   {
      /*********************/
      /* comment-only line */
      /*********************/

      /* queue another read, completion AST back to this function again */
      sys$get (&tkptr->FileOds.Rab, &MenuContents, &MenuContents);
      return;
   }

   /******************/
   /* non-blank line */
   /******************/

   if (tkptr->MenuBlankLineCount) tkptr->MenuSectionNumber++;
   tkptr->MenuLineCount++;
   tkptr->MenuBlankLineCount = 0;
   if (!tkptr->MenuSectionNumber) tkptr->MenuSectionNumber++;

   /******************/
   /* interpret line */
   /******************/

   if (tkptr->MenuSectionNumber == 1 && tkptr->MenuLineCount == 1)
      MenuTitle (rqptr);
   else
   if (!(tkptr->MenuSectionNumber % 2))
   {
      /* ensure the description lines have HTTP carriage-control */
      *rptr++ = '\n';
      *rptr = '\0';
      MenuDescription (rqptr,
                       rptr - (unsigned char*)tkptr->FileOds.Rab.rab$l_ubf);
   }
   else
   if (!((tkptr->MenuSectionNumber-1) % 2))
   {
      if (tkptr->MenuLineCount == 1)
         NetWriteBuffered (rqptr, &MenuItems, "<P>\n<UL>\n", 9);
      else
         MenuItems (rqptr);
   }
}

/*****************************************************************************/
/*
*/

MenuNextContents (struct RequestStruct *rqptr)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MenuNextContents()\n");

   if (VMSnok (rqptr->rqNet.WriteIOsb.Status))
   {
      /* network write has failed (as AST), bail out now */
      if (Debug)
         fprintf (stdout, "NetWriteIOsb.Status %%X%08.08X\n",
                  rqptr->rqNet.WriteIOsb.Status);
      MenuEnd (rqptr);
      return;
   }

   /* queue another read, completion AST back to contents interpretation */
   sys$get (&rqptr->MenuTaskPtr->FileOds.Rab, &MenuContents, &MenuContents);
}

/*****************************************************************************/
/*
The line just read is the menu title.
*/
MenuTitle (struct RequestStruct *rqptr)

{
   static $DESCRIPTOR (TitleFaoDsc,
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>!AZ</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2>!AZ</H2>\n");

   static $DESCRIPTOR (StringDsc, "");

   register unsigned long  *vecptr;
   register struct MenuTaskStruct  *tkptr;

   int  status;
   unsigned short  Length;
   unsigned long  FaoVector [16];
   char  String [1024];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MenuTitle()\n");

   tkptr = rqptr->MenuTaskPtr;

   /* should only be one line, ignore all but the first */
   if (tkptr->MenuLineCount > 1)
      SysDclAst (&MenuNextContents, rqptr);

   vecptr = FaoVector;

   *vecptr++ = HtmlMetaInfo (rqptr, tkptr->FileName);
   *vecptr++ = tkptr->FileOds.Rab.rab$l_ubf;
   if (rqptr->ServicePtr->BodyTag[0])
      *vecptr++ = rqptr->ServicePtr->BodyTag;
   else
      *vecptr++ = Config.cfServer.ReportBodyTag;
   *vecptr++ = tkptr->FileOds.Rab.rab$l_ubf;

   StringDsc.dsc$a_pointer = String;
   StringDsc.dsc$w_length = sizeof(String)-1;

   status = sys$faol (&TitleFaoDsc, &Length, &StringDsc, &FaoVector);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
   {
      rqptr->rqResponse.ErrorTextPtr = "sys$faol()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      MenuEnd (rqptr);
      return;
   }
   String[Length] = '\0';

   /* output the title */
   NetWriteBuffered (rqptr, &MenuNextContents, String, Length);
}

/*****************************************************************************/
/*
The line just read forms part of a description section.  The calling routine 
has appended HTTP carriage-control, so this line is just output as-is.  If 
this is the first (and possibly only) description section separate using a 
paragraph, or <P>, tag.  If the second (or more) description section first 
terminate the unsigned list, or </UL> begun in the preceding item section 
before separating using the pragraph tag.
*/ 

MenuDescription
(
struct RequestStruct *rqptr,
int LineLength
)
{
   register struct MenuTaskStruct  *tkptr;

   char  String [256];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MenuDescription()\n");

   tkptr = rqptr->MenuTaskPtr;

   if (tkptr->MenuLineCount == 1)
   {
      /* first line of the description section */
      if (tkptr->MenuSectionNumber == 2)
      {
         /* first description section of the menu */
         if (LineLength > sizeof(String)-5) LineLength -= 5;
         memcpy (String, "<P>\n", 4);
         memcpy (String+4, tkptr->FileOds.Rab.rab$l_ubf, LineLength);
         String[LineLength += 4] = '\0';
      }
      else
      {
         /* second or subsequent description section of the menu */
         if (LineLength > sizeof(String)-11) LineLength -= 11;
         memcpy (String, "</UL>\n<P>\n", 10);
         memcpy (String+10, tkptr->FileOds.Rab.rab$l_ubf, LineLength);
         String[LineLength += 10] = '\0';
      }
      NetWriteBuffered (rqptr, &MenuNextContents, String, LineLength);
   }
   else
   {
      /* second or subsequent line of the description section */
      NetWriteBuffered (rqptr, &MenuNextContents,
                       tkptr->FileOds.Rab.rab$l_ubf, LineLength);
   }
}

/*****************************************************************************/
/*
Interpret this line as a menu item comprising a URI, white-space, and a 
description comprising the rest of the line after the first non-space.  Each 
line in the item section is output as an item in an non-ordered list, or <UL>.
*/

MenuItems (struct RequestStruct *rqptr)

{
   static char  NoDescription [] = "<I>(no description for this line)</I>";
   static $DESCRIPTOR (FileFaoDsc, "<LI><A HREF=\"!AZ\">!AZ</A>\n");
   static $DESCRIPTOR (StringDsc, "");

   register char  *cptr, *sptr, *zptr;
   register struct MenuTaskStruct  *tkptr;

   unsigned short  Length;
   char  *DescriptionPtr;
   char  Description [256],
         String [512],
         Uri [256];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MenuItems()\n");

   tkptr = rqptr->MenuTaskPtr;

   cptr = tkptr->FileOds.Rab.rab$l_ubf;
   /* skip leading white-space */
   while (*cptr && ISLWS(*cptr)) cptr++;
   zptr = (sptr = Uri) + sizeof(Uri)-2;
   while (*cptr && !ISLWS(*cptr) && sptr < zptr) *sptr++ = *cptr++;
   *sptr = '\0';

   /* skip intervening white-space */
   while (*cptr && ISLWS(*cptr)) cptr++;
   zptr = (sptr = Description) + sizeof(Description)-2;
   while (*cptr && sptr < zptr) *sptr++ = *cptr++;
   *sptr = '\0';

   if (Description[0])
      DescriptionPtr = Description;
   else
      DescriptionPtr = NoDescription;

   if (Uri[0] == '\"')
   {
      /* full URI/URL specification, remove quotes and include as-is */
      for (cptr = Uri+1; *cptr && *cptr != '\"'; cptr++);
      if (*cptr == '\"') *cptr = '\0';
      StringDsc.dsc$a_pointer = String;
      StringDsc.dsc$w_length = sizeof(String)-1;
      sys$fao (&FileFaoDsc, &Length, &StringDsc,
               Uri+1, DescriptionPtr);
      String[Length] = '\0';
      NetWriteBuffered (rqptr, &MenuNextContents, String, Length);
   }
   else
   {
      for (cptr = Uri; *cptr && *cptr != '?'; cptr++);
      if (*cptr == '?')
      {
         /* search item */
         *cptr++ = '\0';
         MenuSearchItem (rqptr, &MenuNextContents, Uri, Description, cptr);
      }
      else
      if (Uri[0] == '*' && !*cptr)
      {
         /* wildcard description list item */
         MenuFileDescription (rqptr, &MenuNextContents, Uri);
      }
      else
      {
         /* file item */
         StringDsc.dsc$a_pointer = String;
         StringDsc.dsc$w_length = sizeof(String)-1;
         sys$fao (&FileFaoDsc, &Length, &StringDsc,
                  Uri, DescriptionPtr);
         String[Length] = '\0';
         NetWriteBuffered (rqptr, &MenuNextContents, String, Length);
      }
   }
}

/*****************************************************************************/
/*
The URI contains a question mark, which is menu-speak for "this is a search
item".  Create and output a search form.  Optional characters following the 
question mark include an "A" for and "about the search" link, "C" for case-
sensitivity buttons, and "O" for output style buttons.
*/

MenuSearchItem
(
struct RequestStruct *rqptr,
void *AstFunctionPtr,
char *Uri,
char *Description,
char *SearchOptions
)
{
   static $DESCRIPTOR (StringDsc, "");

   static $DESCRIPTOR (BeginFormFaoDsc,
"<LI>\n\
<FORM ACTION=\"!AZ\">\n\
<INPUT TYPE=submit VALUE=\"!AZ\">\n\
<INPUT TYPE=text NAME=\"search\">\n\
<INPUT TYPE=reset VALUE=\"Reset\">\n");

   static char  AboutForm[] =
"<BR><I><A HREF=\"?about=search\">About</A> this search.</I>\n";

   static char  CaseForm[] =
"<BR><I>Output By:  \
line<INPUT TYPE=radio NAME=\"hits\" VALUE=\"line\" CHECKED>\
 document<INPUT TYPE=radio NAME=\"hits\" VALUE=\"document\"></I>\n";

   static char  OutputForm[] =
"<BR><I>Case Sensitive:  \
no<INPUT TYPE=radio NAME=\"case\" VALUE=\"no\" CHECKED>\
 yes<INPUT TYPE=radio NAME=\"case\" VALUE=\"yes\"></I>\n";

   static char EndForm[] = "</FORM>\n";

   int  status;
   unsigned short  Length;
   char  HtmlDescription [512],
         String [1024];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MenuSearchItem()\n");

   status = WriteFao (HtmlDescription, sizeof(HtmlDescription), NULL,
                      "!HZ", Description);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
      ErrorNoticed (status, "WriteFao()", FI_LI);

   StringDsc.dsc$a_pointer = String;
   StringDsc.dsc$w_length = sizeof(String)-1;
   sys$fao (&BeginFormFaoDsc, &Length, &StringDsc, Uri, HtmlDescription);

   while (*SearchOptions)
   {
      if (toupper(*SearchOptions) == 'A')
      {
         if (sizeof(AboutForm)-1 < sizeof(String)-1 - Length)
         {
            memcpy (String+Length, AboutForm, sizeof(AboutForm)-1);
            Length += sizeof(AboutForm)-1;
         }
      }
      else
      if (toupper(*SearchOptions) == 'O')
      {
         if (sizeof(OutputForm)-1 < sizeof(String)-1 - Length)
         {
            memcpy (String+Length, OutputForm, sizeof(OutputForm)-1);
            Length += sizeof(OutputForm)-1;
         }
      }
      else
      if (toupper(*SearchOptions) == 'C')
      {
         if (sizeof(CaseForm)-1 < sizeof(String)-1 - Length)
         {
            memcpy (String+Length, CaseForm, sizeof(CaseForm)-1);
            Length += sizeof(CaseForm)-1;
         }
      }
      SearchOptions++;
   }

   if (sizeof(EndForm)-1 < sizeof(String)-1 - Length)
   {
      memcpy (String+Length, EndForm, sizeof(EndForm)-1);
      Length += sizeof(EndForm)-1;
   }

   String[Length] = '\0';
   NetWriteBuffered (rqptr, AstFunctionPtr, String, Length);
}

/*****************************************************************************/
/*
Only called, as an AST, if an implicit file contents listing is generated
because there was no third (item) section in the menu.
*/ 

MenuBeginImplicitDescription (struct RequestStruct *rqptr)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MenuBeginImplicitDescription()\n");

   MenuFileDescription (rqptr, &MenuEndImplicitDescription, "*.*");
}

/*****************************************************************************/
/*
Only called, as an AST, if an implicit file contents listing is generated
because there was no third (item) section in the menu.
*/ 

MenuEndImplicitDescription (struct RequestStruct *rqptr)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MenuEndImplicitDescription()\n");

   NetWriteBuffered (rqptr, &MenuEnd, "</UL>\n", 6);
}

/*****************************************************************************/
/*
*/ 

MenuFileDescription
(
struct RequestStruct *rqptr,
void *AstFunctionPtr,
char *FileWildcard
)
{
   register struct MenuTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MenuFileDescription()\n");

   tkptr = rqptr->MenuTaskPtr;

   tkptr->MenuAstFunctionPtr = AstFunctionPtr;

   OdsParse (&tkptr->SearchOds,
             FileWildcard, 0,
             tkptr->FileOds.NamDevicePtr,
             tkptr->FileOds.NamDeviceLength +
               tkptr->FileOds.NamDirectoryLength,
             0, NULL, rqptr);

   status = tkptr->FileOds.Fab.fab$l_sts;

   if (VMSok (status) &&
       tkptr->FileOds.Nam_fnb & NAM$M_SEARCH_LIST)
   {
      /*******************************/
      /* search to get actual device */
      /*******************************/

      if (Debug) fprintf (stdout, "SEARCH-LIST!\n");
      if (tkptr->AuthVmsUserHasAccess)
      {
         EnableSysPrv();
         OdsSearch (&tkptr->FileOds, NULL, rqptr);
         DisableSysPrv();
      }
      else
         OdsSearch (&tkptr->FileOds, NULL, 0);
      status = tkptr->FileOds.Fab.fab$l_sts;
   }

   if (VMSnok (status))
   {
      tkptr->FileOds.NamNamePtr[0] = '\0';
      rqptr->rqResponse.ErrorTextPtr =
         MapVmsPath (tkptr->FileOds.NamDevicePtr, rqptr);
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->FileOds.NamDevicePtr;
      ErrorVmsStatus (rqptr, status, FI_LI);
      MenuEnd (rqptr);
      return;
   }

   MenuFileSearch (rqptr);
}

/*****************************************************************************/
/*
*/

MenuFileSearch (struct RequestStruct *rqptr)

{
   register struct MenuTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MenuFileSearch()\n");

   tkptr = rqptr->MenuTaskPtr;

   if (tkptr->AuthVmsUserHasAccess)
   {
      EnableSysPrv();
      OdsSearch (&tkptr->SearchOds, NULL, 0);
      DisableSysPrv();
      /* explicitly call the AST routine */
      MenuFileDescriptionOf (rqptr);
      return;
   }

   OdsSearch (&tkptr->SearchOds, &MenuFileDescriptionOf, rqptr);
}

/*****************************************************************************/
/*
*/

MenuFileDescriptionOf (struct FAB *FabPtr)

{
   register char  *cptr, *sptr;
   register struct RequestStruct  *rqptr;
   register struct MenuTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
      "MenuFileDescriptionOf() sts: %%X%08.08X stv: %%X%08.08X\n",
      FabPtr->fab$l_sts, FabPtr->fab$l_stv);

   rqptr = FabPtr->fab$l_ctx;
   tkptr = rqptr->MenuTaskPtr;

   if (VMSnok (status = tkptr->SearchOds.Fab.fab$l_sts))
   {
      /* if its a search list treat directory not found as if file not found */
      if ((tkptr->FileOds.Nam_fnb & NAM$M_SEARCH_LIST) && status == RMS$_DNF)
         status = RMS$_FNF;

      if (status == RMS$_FNF || status == RMS$_NMF)
      {
         /**********************/
         /* end of file search */
         /**********************/

         tkptr->SearchOds.ParseInUse = false;
         SysDclAst (tkptr->MenuAstFunctionPtr, rqptr);
         return;
      }

      /**********************/
      /* sys$search() error */
      /**********************/

      rqptr->rqResponse.ErrorTextPtr =
         MapVmsPath (tkptr->SearchOds.ExpFileName, rqptr);
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->SearchOds.ExpFileName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      MenuEnd (rqptr);
      return;
   }

   /* terminate following the last character in the version number */
   tkptr->SearchOds.NamVersionPtr[tkptr->SearchOds.NamVersionLength] = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", tkptr->SearchOds.ResFileName);

   if (!strcmp (tkptr->SearchOds.NamNamePtr, tkptr->FileOds.NamNamePtr))
   {
      /* this is the same menu file, don't need a description of this! */
      MenuFileSearch (rqptr);
      return;
   }

   Description (rqptr,
                &MenuFileDescriptionDone,
                tkptr->SearchOds.ResFileName,
                tkptr->Description,
                sizeof(tkptr->Description),
                DESCRIPTION_ALL);
}

/*****************************************************************************/
/*
*/ 

MenuFileDescriptionDone (struct RequestStruct *rqptr)

{
   static $DESCRIPTOR (LinkFaoDsc, "<LI><A HREF=\"!AZ\">!AZ!AZ!AZ</A>\n");

   register char  *cptr, *sptr;
   register struct MenuTaskStruct  *tkptr;

   int  status;
   unsigned short  Length;
   char  LowerCaseName [128],
         Link [512];
   $DESCRIPTOR (LinkDsc, Link);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MenuFileDescriptionDone()\n");

   tkptr = rqptr->MenuTaskPtr;

   if (tkptr->Description[0] == DESCRIPTION_IMPOSSIBLE)
      SysDclAst (&MenuFileSearch, rqptr);

   sptr = LowerCaseName;
   for (cptr = tkptr->SearchOds.NamNamePtr;
        *cptr && *cptr != ';';
        *sptr++ = tolower(*cptr++));
   *sptr = '\0';
   if (tkptr->Description[0])
      sys$fao (&LinkFaoDsc, &Length, &LinkDsc, 
               LowerCaseName, "&quot;", tkptr->Description, "&quot;");
   else
      sys$fao (&LinkFaoDsc, &Length, &LinkDsc, 
               LowerCaseName, "", LowerCaseName, "");
   Link[Length] = '\0';

   NetWriteBuffered (rqptr, &MenuFileSearch, Link, Length);
}

/*****************************************************************************/

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            