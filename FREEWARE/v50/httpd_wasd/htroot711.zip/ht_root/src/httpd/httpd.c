/*****************************************************************************/
/*
                                  HTTPd.c

WASD VMS Hypertext Transfer Protocol daemon.


COPYRIGHT NOTICE
----------------
WASD VMS Hypertext Services, Copyright (C) 1996-2000 Mark G.Daniel.
(prior to 01-JUL-1997, "HFRD VMS Hypertext Services")

This package is free software; you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation; version 2 of the License, or any later version. 

This package is distributed in the hope that it will be useful, but WITHOUT 
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more 
details. 

You should have received a copy of the GNU General Public License along with 
this package; if not, write to the Free Software Foundation, Inc., 675 Mass 
Ave, Cambridge, MA 02139, USA. 


PRIVILEGES REQUIRED
-------------------
These should be INSTALLed against the image.

ALTPRI   Allows the server account to raise it's prioity above 4 if enabled by
         the /PRIORITY= qualifier.

DETACH   (IMPERSONATE) Allows the server to impersonate specific accounts
         for scripting and startup putposes.

SYSLCK   Allows SYSTEM locks to be enqueued for sending commands to all
         server processes on a node/cluster (via /DO=/ALL or Admin Menu).

SYSPRV   Used for various purposes, including creating sockets within the
         privileged port range (1-1023, which includes port 80 of course),
         accessing configuration files (which can be protected from world
         access), enable AUTHORIZED write access to the file system, checking
         authentication details, amongst others.

SYSNAM   Allows the server to write into the LNM$SYSTEM logical name table.

PRMMBX   Used by the DCL scripting module to create permanent mailboxes

PSWAPM   Allows the server process to prevent itself from being swapped out if 
         enabled by the /[NO]SWAP qualifier.

WORLD    (optional) Allows the CONTROL module to obtain information about
         the process sending it commands.


QUALIFIERS  (implemented in the CLI.c module)
----------
/ACCEPT=                comma separated list of accepted hosts/domains
/ALL[=resname]          /do= this to all server processes on node/cluster
/AUTHORIZE=[SSL|ALL]    authorization may only be used with "https:",
                        all paths must be authorized
/CGI_PREFIX=            prefix to CGI-script variable (symbol) names
/DBUG                   turn on all "if (Debug)" statements (if compiled DBUG)
/DETACH=                DCL procedure to be run as /USER=
/DO=                    command to be passed to server
/FILBUF=                number of bytes in record buffer
/FORMAT=                log record format
/IDENT=                 VMS rights identifier name used for detached processes
/[NO]LOG[=]             logging enabled/disabled, optional log file name
/[NO]MONITOR            monitor logicals enabled/disabled
/NETBUF=                number of bytes in network read buffer
/[NO]ODS5               explicit extended file specification (testing only)
/OUTBUF=                number of bytes in output buffer
/PERIOD=                log file period
/PERSONA[=ident]        enable PERSONA services for DCL scripting,
                        optiona identifier name controlling persona access
/PORT=                  server IP port number (overriden by [service] config)
/PRIORITY=              process priority
/[NO]PROFILE            allow/disallow SYSUAF-authenticated access control
/[NO]PROMISCUOUS[=pwd]  authenticates any user name for path authorization
                        (optional password required for authorization) 
/REJECT=                comma separated list of rejected hosts/domains
/SERVICES=              list of [host-name:]port providing HTTP service
/SOFTWAREID=            overrides the server's software ID string
/SYSPRV                 normally operate with SYSPRV enabled (CAUTION!)
/[NO]SSL=               enables Secure Sockets Layer, sets protocol parameters
/[NO]SYSUAF[=ID,SSL,RELAXED]    allow/disallow SYSUAF authentication, or
                        SYSUAF authentication is allowed by identifier,
                        SYSUAF authentication is only allowed with "https:",
                        SYSUAF authentication allowed with any current account
/[NO]SWAP               allow/disallow process to be swapped out
/USER=                  set the username (account) the server executes under
/VERSION                simply display the server version
/[NO]ZERO               accounting zeroed on startup (default is non-zeroed)


VERSION HISTORY
---------------
See VERSION.H
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <descrip.h>
#include <iodef.h>
#include <jpidef.h>
#include <libdef.h>
#include <libclidef.h>
#include <prvdef.h>
#include <prcdef.h>
#include <psldef.h>
#include <ssdef.h>
#include <stsdef.h>
#include <syidef.h>

/* application-related header files */
#include "wasd.h"
#include "copyright.h"

#define WASD_MODULE "HTTPD"

/******************/
/* global storage */
/******************/

/*
   These are the required privileges of the executing HTTP server.
   The server ACCOUNT should only have TMPMBX and NETMBX (just for
   extra security, policy ... keep privileged accounts to a minimum).
   The image should be installed with SYSPRV, PRMMBX, PSWAPM and SYSNAM.
   Script processes are created only with the process's current privileges,
   which are always maintained at TMPMBX and NETMBX.  If additional
   privileges are required for any particular purpose (e.g. binding to
   a privileged IP port) then they are enabled, the action performed,
   and then they are disabled again immediately.
*/
unsigned long  AltPriMask [2] = { PRV$M_ALTPRI, 0 },
               AveJoePrvMask [2] = { PRV$M_NETMBX | PRV$M_TMPMBX, 0 },
               DetachMask [2] = { PRV$M_DETACH, 0 },
               PswapmMask [2] = { PRV$M_PSWAPM, 0 },
               ResetPrvMask [2] = { 0xffffffff, 0xffffffff },
               SysPrvMask [2] = { PRV$M_SYSPRV, 0 },
               WorldMask [2] = { PRV$M_WORLD, 0 };

char  Utility [] = "HTTPD";

/*
   Decided to be able to eliminate the debug statements from production
   executables completely.  This will eliminate some largely unused code
   from the images reducing the overall file size, but more importantly
   will eliminate the test and branch execution overhead each time a debug
   statement is encountered.  Do this by conditionally turning the integer
   Debug storage into a constant false value ... compiler optimization of
   an impossible-to-execute section of code does the rest!  Very little
   other code needs to be explicitly conditionally compiled.
*/
#ifdef DBUG
boolean  Debug;
#else
#define Debug 0
#endif

boolean  HttpdServerExecuting,
         MonitorEnabled,
         NaturalLanguageEnglish,
         NoSwapOut = true,
         OperateWithSysPrv = false;

int  ExitStatus,
     FileBufferSize = DEFAULT_FILE_BUFFER_SIZE,
     HttpdBytLmAvailable,
     HttpdJpiAstLm,
     HttpdJpiBioLm,
     HttpdJpiBytLm,
     HttpdJpiDioLm,
     HttpdJpiEnqLm,
     HttpdJpiFilLm,
     HttpdJpiPgFlQuo,
     HttpdJpiPrcLm,
     HttpdJpiTqLm,
     ProcessPriority = 4,
     ServerPort = 80,
     VmsVersion;

unsigned long  HttpdProcessId,
               HttpdUic;

unsigned long  HttpdStartBinTime [2];

char  HttpdUserName [13],
      NaturalLanguage [64],
      ProcessName [16],
      ProcessIdentName [32] = "WASD_",
      ServerGroupResName [32] = DEFAULT_SERVER_GROUP_RESNAME,
      ServerPortString [16],
      SyiHwName [32],
      SyiVersion [9];

struct AnExitHandler  ExitHandler;

struct AccountingStruct  Accounting;
boolean  AccountingZeroOnStartup;

#ifdef DBUG
   USEC_TIMER_STORAGE
#endif

/********************/
/* external storage */
/********************/

extern boolean  AuthorizationEnabled,
                CliDetach,
                CliMonitorDisabled,
                CliMonitorEnabled,
                CliOdsExtendedEnabled,
                CliOdsExtendedDisabled,
                CliVersion,
                ControlDoAllHttpd,
                LoggingEnabled,
                OdsExtended,
                ProtocolHttpsConfigured;

extern int  CliServerPort,
            ConnectCountConcurrentMax,
            HttpdAccountingVersion,
            OpcomMessages,
            RequestHistoryMax,
            ServerPort,
            WatchEnabled;

extern char  BuildInfo[],
             CliLogFileName[],
             CliParameter[],
             CliProcessIdentName[],
             CliUserName[],
             ControlBuffer[],
             ErrorSanityCheck[],
             HttpdIpPackage[],
             HttpdSesola[],
             LoggingFileName[],
             Services[],
             SoftwareID[],
             TimeGmtString[];

extern struct ConfigStruct  Config;
extern struct ListHeadStruct  RequestList;
extern struct MsgDbStruct  MsgDb;
extern struct ServiceLoadStruct  ServiceLoad;

/* for initial debugging only */
extern unsigned long  VmCacheVmZoneId,
                      VmGeneralVmZoneId,
                      VmRequestVmZoneId;

/*****************************************************************************/
/*
*/

int main ()

{
   static unsigned short  SyiHwNameLength;
   static unsigned long  JpiGrp,
                         SyiMaxSysGroup;

   static struct
   {
      unsigned short  buf_len;
      unsigned short  item;
      unsigned char   *buf_addr;
      unsigned short  *short_ret_len;
   }
   JpiItems [] =
   {
     { sizeof(JpiGrp), JPI$_GRP, &JpiGrp, 0 },
     { sizeof(HttpdProcessId), JPI$_PID, &HttpdProcessId, 0 },
     { sizeof(HttpdUic), JPI$_UIC, &HttpdUic, 0 },
     { sizeof(HttpdUserName)-1, JPI$_USERNAME, &HttpdUserName, 0 },
     { sizeof(HttpdJpiAstLm), JPI$_ASTLM, &HttpdJpiAstLm, 0 },
     { sizeof(HttpdJpiBioLm), JPI$_BIOLM, &HttpdJpiBioLm, 0 },
     { sizeof(HttpdJpiBytLm), JPI$_BYTLM, &HttpdJpiBytLm, 0 },
     { sizeof(HttpdJpiDioLm), JPI$_DIOLM, &HttpdJpiDioLm, 0 },
     { sizeof(HttpdJpiEnqLm), JPI$_ENQLM, &HttpdJpiEnqLm, 0 },
     { sizeof(HttpdJpiFilLm), JPI$_FILLM, &HttpdJpiFilLm, 0 },
     { sizeof(HttpdJpiPgFlQuo), JPI$_PGFLQUOTA, &HttpdJpiPgFlQuo, 0 },
     { sizeof(HttpdJpiPrcLm), JPI$_PRCLM, &HttpdJpiPrcLm, 0 },
     { sizeof(HttpdJpiTqLm), JPI$_TQLM, &HttpdJpiTqLm, 0 },
     { 0,0,0,0 }
   },
   SyiItem [] =
   {
     { sizeof(SyiMaxSysGroup), SYI$_MAXSYSGROUP, &SyiMaxSysGroup, 0 },
     { sizeof(SyiVersion)-1, SYI$_VERSION, &SyiVersion, 0 },
     { sizeof(SyiHwName)-1, SYI$_HW_NAME, &SyiHwName, &SyiHwNameLength },
     { 0,0,0,0 }
   };

   int  status;
   unsigned short  Length;
   char  *cptr, *sptr, *zptr;
   char  TimeScratch [32];
   $DESCRIPTOR (NaturalLanguageDsc, NaturalLanguage);
   $DESCRIPTOR (ProcessNameDsc, ProcessName);
   $DESCRIPTOR (ProcessNameFaoDsc, "HTTPd:!UL");

   /*********/
   /* begin */
   /*********/

   if (VMSnok (status = ParseCommandLine ()))
      exit (status);

#ifdef DBUG
   if (!Debug)
      if ((char*)getenv ("HTTPD$DBUG") != NULL)
         Debug = true;
#endif

   if (ControlBuffer[0])
   {
      /*********************************************************/
      /* this image is being used to control the HTTPd process */
      /*********************************************************/

      if (CliServerPort) ServerPort = CliServerPort;
      if (ServerPort < 1 || ServerPort > 65535)
         ErrorExitVmsStatus (0, "IP port", FI_LI);
      if (ControlDoAllHttpd)
         exit (ControlAllCommand (ControlBuffer));
      else
         exit (ControlCommand (ControlBuffer));
   }

   if (CliDetach)
   {
      /************************************/
      /* create a detached server process */
      /************************************/

      exit (HttpdDetachServerProcess ());
   }
   
   VersionInfo ();

   /* output the GNU GENERAL PUBLIC LICENSE message */
   WriteFaoStdout ("%!AZ-I-SOFTWAREID, !AZ\n!AZ",
                   Utility, SoftwareID, CopyRightMessageBrief);

   if (CliVersion) exit (SS$_NORMAL);

   /****************/
   /* HTTPd server */
   /****************/

   /* timestamp the server startup */
   sys$gettim (&HttpdStartBinTime);
   WriteFaoStdout ("%!AZ-I-STARTUP, !20%D\n", Utility, 0);

   /* display information about any CLI WATCH facility settings */
   WatchCliSettings ();

   /* set up and declare the exit handler */
   ExitHandler.HandlerAddress = &HttpdExit;
   ExitHandler.ArgCount = 1;
   ExitHandler.ExitStatusPtr = &ExitStatus;
   if (VMSnok (status = sys$dclexh (&ExitHandler)))
      ErrorExitVmsStatus (status, "sys$dclexh()", FI_LI);

   HttpdServerExecuting = true;
   HttpdOnControlY (false);

   /* initialize general-use virtual memory management */
   VmGeneralInit ();
   /** if (Debug) VmDebug (VmGeneralVmZoneId); **/

   /* get some details of the account */
   if (VMSnok (status = sys$getjpiw (0, 0, 0, &JpiItems, 0, 0, 0)))
      ErrorExitVmsStatus (status, "sys$getjpiw()", FI_LI);
   HttpdUserName[sizeof(HttpdUserName)-1] = '\0';
   for (cptr = HttpdUserName; *cptr && *cptr != ' '; cptr++);
   *cptr = '\0';
   if (Debug)
      fprintf (stdout,
         "Uic: %08.08X UserName |%s| ProcessId: %08.08X Grp: %d\n",
          HttpdUic, HttpdUserName, HttpdProcessId, JpiGrp);

   /* get system information */
   if (VMSnok (status = sys$getsyi (0, 0, 0, &SyiItem, 0, 0, 0)))
      ErrorExitVmsStatus (status, "sys$getsyi()", FI_LI);

   SyiHwName[SyiHwNameLength] = '\0';
   SyiVersion[sizeof(SyiVersion)-1] = '\0';
   for (cptr = SyiVersion; *cptr && *cptr != ' '; cptr++);
   *cptr = '\0';
   VmsVersion = ((SyiVersion[1]-48) * 10) + (SyiVersion[3]-48);
   if (Debug)
      fprintf (stdout, "HwName |%s| SyiVersion |%s| VmsVersion: %d\n",
               SyiHwName, SyiVersion, VmsVersion);

   if (JpiGrp <= SyiMaxSysGroup)
      WriteFaoStdout (
"%!AZ-W-SYSPRV, operating with implicit SYSPRV (UIC group !UL)\n",
         Utility, JpiGrp);

   /* set the flag and report indicating whether ODS-5 is supported */
   OdsSetExtended ();

   /* make sure the process' privileges are those of a mere mortal */
   if (VMSnok (status = sys$setprv (0, &ResetPrvMask, 0, 0)))
      ErrorExitVmsStatus (status, "sys$setprv()", FI_LI);
   if (VMSnok (status = sys$setprv (1, &AveJoePrvMask, 0, 0)))
      ErrorExitVmsStatus (status, "sys$setprv()", FI_LI);

   if (OperateWithSysPrv && OPERATE_WITH_SYSPRV)
   {
      /* looks like we're been asked to use Superman's Xray vision! */
      if (VMSnok (status = sys$setprv (1, &SysPrvMask, 0, 0)))
         ErrorExitVmsStatus (status, "sys$setprv()", FI_LI);
      WriteFaoStdout ("%!AZ-I-SYSPRV, operating with explicit SYSPRV\n",
                      Utility);
   }
   else
   if (OperateWithSysPrv)
   {
      OperateWithSysPrv = false;
      WriteFaoStdout ("%!AZ-W-SYSPRV, operation is NOT a compiled option\n",
                      Utility);
   }

   /* set (a sensible) process priority */
   if (ProcessPriority > 6) ProcessPriority = 6;
   if (VMSnok (status = sys$setprv (1, &AltPriMask, 0, 0)))
      ErrorExitVmsStatus (status, "sys$setprv()", FI_LI);
   if (VMSnok (status = sys$setpri (0, 0, ProcessPriority, 0, 0, 0)))
      ErrorExitVmsStatus (status, "sys$setpri()", FI_LI);
   if (VMSnok (status = sys$setprv (0, &AltPriMask, 0, 0)))
      ErrorExitVmsStatus (status, "sys$setprv()", FI_LI);

   /* anywhere near before starting logging! */
   NetGetServerHostName ();

   /* read the server configuration file */
   Configure (&Config);

   if (CliServerPort)
      ServerPort = CliServerPort;
   else
   if (Config.cfServer.DefaultPort)
      ServerPort = Config.cfServer.DefaultPort;
   if (ServerPort < 1 || ServerPort > 65535)
      ErrorExitVmsStatus (0, "IP port", FI_LI);
   sprintf (ServerPortString, "%d", ServerPort);

   /* initialize Secure Sockets Layer, if available and if required */
   SeSoLaInit ();

   /* get the configured services */
   ServiceConfigLoad(&ServiceLoad);

   /* set the process name */
   if (VMSnok (status =
       sys$fao (&ProcessNameFaoDsc, &Length, &ProcessNameDsc, ServerPort)))
      ErrorExitVmsStatus (status, "sys$fao()", FI_LI);
   ProcessName[ProcessNameDsc.dsc$w_length = Length] = '\0';
   if (Debug) fprintf (stdout, "ProcessName |%s|\n", ProcessName);
   if (VMSnok (status = sys$setprn (&ProcessNameDsc)))
      ErrorExitVmsStatus (status, "sys$setprn()", FI_LI);

   /* not the process name has been set OPCOM can be used */
   if (OpcomMessages & OPCOM_HTTPD)
      WriteFaoOpcom ("%!AZ-I-STARTUP, !AZ", Utility, SoftwareID);

   /* set up a rights identifier name (currently for detached scripting) */
   zptr = (sptr = ProcessIdentName) + sizeof(ProcessIdentName)-1;
   if (CliProcessIdentName[0])
      for (cptr = CliProcessIdentName; *cptr && sptr < zptr; *sptr++ = *cptr++);
   else
   {
      /* server-set rights identifiers begin with the following */
      for (cptr = "WASD_"; *cptr; *sptr++ = *cptr++);
      for (cptr = ProcessName; *cptr && sptr < zptr; cptr++)
         if (isalnum(*cptr)) *sptr++ = toupper(*cptr); else *sptr++ = '_';
   }
   *sptr = '\0';
   if (Debug) fprintf (stdout, "ProcessIdentName |%s|\n", ProcessIdentName);

   /* ensure the GMT time/logical is available */
   if (VMSnok (status = TimeSetGMT ()))
      ErrorExitVmsStatus (status, "TimeSetGMT()", FI_LI);
   fprintf (stdout, "%%%s-I-GMT, %s\n", Utility, TimeGmtString);

   if (CliMonitorDisabled)
      MonitorEnabled = false;
   else
   if (Config.cfMisc.MonitorEnabled || CliMonitorEnabled)
      MonitorEnabled = true;
   else
      MonitorEnabled = false;

   /* reset logical names provided to the HTTPd monitor utility */
   if (MonitorEnabled)
      if (VMSnok (status = DefineMonitorLogicals (NULL)))
         ErrorExitVmsStatus (status, "DefineMonitorLogicals()", FI_LI);

   /* must be done after DefineMonitorLogicals(), which gets previous values */
   if (AccountingZeroOnStartup ||
       HttpdAccountingVersion != Accounting.AccountingVersion ||
       !MonitorEnabled)
   {
      /* initialize accounting information without reseting the logicals */
      ZeroAccounting ();
   }
   Accounting.AccountingVersion = HttpdAccountingVersion;

   /* initialize message database */
   MsgLoad (&MsgDb);

   /* check some contents of that message database */
   ErrorCheckReportFormats ();

   /* authentication/authorization configuration */
   AuthConfigInit ();

   /* load the rule mapping database */
   MapUrl_Load ();

   /* initialize proxy processing */
   ProxyInit ();

   /* initialize DCL processing */
   DclInit ();

   if (Config.cfServer.BusyLimit)
      ConnectCountConcurrentMax = Config.cfServer.BusyLimit;

   /* initialize request virtual memory management */
   VmRequestInit (ConnectCountConcurrentMax); 
   /** if (Debug) VmDebug (VmRequestVmZoneId); **/

   /* initialize file cache  */
   CacheInit (true);
   /** if (Debug) VmDebug (VmCacheVmZoneId); **/
   /** if (Debug) VmDebug (0); **/

   /* initialize activity statistics */
   GraphActivityInit ();

   /* initialize the language environment */
   if (VMSok (status = lib$get_users_language (&NaturalLanguageDsc)))
   {
      for (cptr = NaturalLanguage; *cptr && !ISLWS(*cptr); cptr++);
      *cptr = '\0';
      if (strsame (NaturalLanguage, "ENGLISH"))
         NaturalLanguageEnglish = true;
      else
      {
         NaturalLanguageEnglish = false;
         fprintf (stdout, "%%%s-I-LANGUAGE, natural language is %s\n",
                  Utility, NaturalLanguage);
      }
   }
   else
   {
      if (status == LIB$_ENGLUSED)
      {
         NaturalLanguageEnglish = true;
         strcpy (NaturalLanguage, "ENGLISH");
         fprintf (stdout,
            "%%%s-W-LANGUAGE, natural language has defaulted to %s\n",
            Utility, NaturalLanguage);
      }
      else
         ErrorExitVmsStatus (status, "lib$get_users_language()", FI_LI);
   }

   /* set up for the HTTPD process to be controlled via mailbox */
   if (VMSnok (status = ControlHttpd ()))
      ErrorExitVmsStatus (status, "ControlHttpd()", FI_LI);
   /* set up for the HTTPD process to be controlled via dlocking */
   if (VMSnok (status = ControlAllHttpd (0)))
      ErrorExitVmsStatus (status, "ControlAllThisServer()", FI_LI);

   /* initialize request history mechanism (ensure it's reasonable!) */
   RequestHistoryMax = Config.cfMisc.RequestHistory;
   if (RequestHistoryMax > 999) RequestHistoryMax = 0;

   /* disable process swapping */
   if (NoSwapOut)
   {
      if (VMSnok (status = sys$setprv (1, &PswapmMask, 0, 0)))
         ErrorExitVmsStatus (status, "sys$setprv()", FI_LI);
      if (VMSnok (status = sys$setswm (1)))
         ErrorExitVmsStatus (status, "sys$setswm()", FI_LI);
      if (VMSnok (status = sys$setprv (0, &PswapmMask, 0, 0)))
         ErrorExitVmsStatus (status, "sys$setprv()", FI_LI);
   }

   /* disable AST's until we've created the listening sockets */
   sys$setast (0);

   /* need SYSPRV to bind to a well-known port */
   EnableSysPrv();

   /* create network services */
   NetCreateService ();

   /* turn off SYSPRV after binding to well-known port */
   DisableSysPrv();

   /* initialize logging after service creation (in case of per-service logs) */
   if (VMSnok (status = Logging (NULL, LOGGING_BEGIN)))
      ErrorExitVmsStatus (status, "Logging()", FI_LI);

   /* ensure any alterations to accounting during startup show up */
   if (MonitorEnabled)
      if (VMSnok (status = DefineMonitorLogicals (NULL)))
         ErrorExitVmsStatus (status, "DefineMonitorLogicals()", FI_LI);

   /* force ODS extended if the command-line requested it (testing only) */
   if (CliOdsExtendedEnabled) OdsExtended = true;
   if (CliOdsExtendedDisabled) OdsExtended = false;

   /*****************************/
   /* begin to process requests */
   /*****************************/

   /* get the available BYTLM quota after all server sockets created */
   HttpdBytLmAvailable = GetJpiBytLm();
   if (Debug) fprintf (stdout, "BytLmAvailable: %d\n", HttpdBytLmAvailable);

   WriteFaoStdout ("%!AZ-I-BEGIN, !20%D, accepting requests\n", Utility, 0);

   /* reenable user-mode ASTs to allow use of our services */
   sys$setast (1);

   sys$hiber ();

   exit (SS$_NORMAL);
}

/*****************************************************************************/
/*
Create a detached server process.  If the /USER= qualifier was used the process
will  have changed it's persona and the process created here will be created
under that user name.
*/

HttpdDetachServerProcess ()

{
   static unsigned long  CrePrcFlags = PRC$M_DETACH;
   static $DESCRIPTOR (LoginOutDsc, "SYS$SYSTEM:LOGINOUT.EXE");
   static $DESCRIPTOR (SysCommandDsc, "HT_ROOT:[LOCAL]STARTUP_SERVER.COM");
   static $DESCRIPTOR (SysOutputFaoDsc, "HT_ROOT:[LOG.SERVER]!AZ.LOG");
   static $DESCRIPTOR (SysOutputDsc, "");

   static unsigned short  Length;
   static char  SyiNodeName [16];
   static struct
   {
      unsigned short  buf_len;
      unsigned short  item;
      unsigned char   *buf_addr;
      unsigned short  *short_ret_len;
   }
   SyiItem [] =
   {
     { sizeof(SyiNodeName)-1, SYI$_NODENAME, &SyiNodeName, &Length },
     { 0,0,0,0 }
   };

   int  status;
   unsigned int  ProcessPid;
   char  LogFileName [256];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HttpDetachServerProcess()\n");

   if (CliUserName[0])
      if (VMSnok (status = PersonaAssume (CliUserName)))
         exit (status);

   if (CliParameter[0])
   {
      SysCommandDsc.dsc$a_pointer = CliParameter;
      SysCommandDsc.dsc$w_length = strlen(CliParameter);
   }

   if (LoggingFileName[0])
   {
      SysOutputDsc.dsc$a_pointer = LoggingFileName;
      SysOutputDsc.dsc$w_length = strlen(LoggingFileName);
   }
   else
   {
      if (VMSnok (status = sys$getsyi (0, 0, 0, &SyiItem, 0, 0, 0)))
         ErrorExitVmsStatus (status, "sys$getsyi()", FI_LI);
      SyiNodeName[Length] = '\0';
      WriteFao (LogFileName, sizeof(LogFileName), &Length,
                "HT_ROOT:[LOG.SERVER]!AZ.LOG", SyiNodeName);
      SysOutputDsc.dsc$a_pointer = LogFileName;
      SysOutputDsc.dsc$w_length = Length;
   }

   status = sys$creprc (&ProcessPid,
                        &LoginOutDsc,
                        &SysCommandDsc,
                        &SysOutputDsc,
                        0, 0, 0, 0, ProcessPriority, 0, 0,
                        CrePrcFlags,
                        0, 0);
   if (VMSnok (status)) exit (status);

   WriteFaoStdout (
      "%!AZ-S-PROC_ID, identification of created process is !8XL\n",
      Utility, ProcessPid);

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Exit the HTTP server, via this declared exit handler.
*/

HttpdExit (unsigned long *ExitStatusPtr)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HttpdExit() %%X%08.08X\n", *ExitStatusPtr);

   /* run down any script processes associated with script processing */
   DclExit ();

   if (LoggingEnabled)
   {
      /* provide a server exit entry */
      Logging (NULL, LOGGING_END);
   }

   if (MonitorEnabled)
   {
      /* set exit status in logical names used by HTTPd monitor utility */
      Accounting.LastExitStatus = *ExitStatusPtr;
      DefineMonitorLogicals (NULL);
   }

   /* report to process log */
   if (VMSnok (*ExitStatusPtr))
      WriteFaoStdout ("%!AZ-F-EXIT, %X!8XL\n",
                      Utility, *ExitStatusPtr);
   else
      WriteFaoStdout ("%!AZ-I-EXIT, %X!8XL\n-!%M\n",
                      Utility, *ExitStatusPtr, *ExitStatusPtr);

   if (OpcomMessages)
   {
      /* an error exit is always reported via OPCOM */
      if (VMSnok (*ExitStatusPtr))
         WriteFaoOpcom ("%!AZ-F-EXIT, %X!8XL\r\n-!%M",
                        Utility, *ExitStatusPtr, *ExitStatusPtr);
      else
      if (OpcomMessages & OPCOM_HTTPD)
         WriteFaoOpcom ("%!AZ-I-EXIT, %X!8XL\r\n-!%M",
                        Utility, *ExitStatusPtr, *ExitStatusPtr);
   }
}

/*****************************************************************************/
/*
*/

int HttpdOnControlY (boolean ControlY)

{
   static boolean  Disabled = false;
   static unsigned long  Mask = LIB$M_CLI_CTRLY,
                         OldMask;
   static unsigned short  TTChannel = 0;

   int  status;
   $DESCRIPTOR (TTDsc, "TT:");

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HttpdOnControlY() %d\n", ControlY);

   if (ControlY) exit (0x00000610);

   if (!TTChannel)
      if (VMSnok (status = sys$assign (&TTDsc, &TTChannel, 0, 0, 0)))
         return (status);

   if (VMSnok (status =
       sys$qiow (0, TTChannel, IO$_SETMODE | IO$M_CTRLYAST, 0, 0, 0,
                 &HttpdOnControlY, true, PSL$C_USER, 0, 0, 0)))
      return (status);

   if (VMSnok (status =
       sys$qiow (0, TTChannel, IO$_SETMODE | IO$M_CTRLCAST, 0, 0, 0,
                 &HttpdOnControlY, true, PSL$C_USER, 0, 0, 0)))
      return (status);

   if (!Disabled)
   {
      Disabled = true;
      return (lib$disable_ctrl (&Mask, &OldMask));
   }
   else
      return (status);
}

/*****************************************************************************/
/*
As the code gets more complex it's becoming increasingly possible a coding or
design error will leave privileges turned on somewhere. To help detect any such
problem occasionally (when there are no more connections to process) ensure
everthing's off that's supposed to be off.
*/

#ifdef __DECC
#pragma inline(HttpdCheckPriv)
#endif

HttpdCheckPriv ()

{
   static long  Pid = 0;
   static unsigned long  JpiCurPriv [2];
   static struct
   {
      unsigned short  buf_len;
      unsigned short  item;
      unsigned char   *buf_addr;
      unsigned short  *short_ret_len;
   }
      JpiItems [] =
   {
      { sizeof(JpiCurPriv), JPI$_CURPRIV, &JpiCurPriv, 0 },
      {0,0,0,0}
   };

   int  status;
   char  Buffer [128];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HttpdCheckPriv()\n");

   if (VMSnok (status = sys$getjpiw (0, &Pid, 0, &JpiItems, 0, 0, 0)))
      ErrorExitVmsStatus (status, "sys$getjpiw()", FI_LI);

   if (Debug)
      fprintf (stdout, "%08.08X%08.08X\n", JpiCurPriv[1], JpiCurPriv[0]);

   JpiCurPriv[0] &= ~AveJoePrvMask[0];
   JpiCurPriv[1] &= ~AveJoePrvMask[1];

   /* if only NETMBX and TMPMBX enabled then ok */
   if (!(JpiCurPriv[0] || JpiCurPriv[1])) return;

#if OPERATE_WITH_SYSPRV
   /* if operating with SYSPRV and it's enabled then ok */
   if (OperateWithSysPrv && (JpiCurPriv[0] == SysPrvMask[0])) return;
#endif

   /* hmmmm, shouldn't have extended privileges!! */
   WriteFao (Buffer, sizeof(Buffer), 0,
             "privilege sanity check: !8XL!8XL",
             ~JpiCurPriv[1], ~JpiCurPriv[0]);
   ErrorExitVmsStatus (SS$_BUGCHECK, Buffer, FI_LI);
}

/*****************************************************************************/
/*
Set the timer counters for the request according to the function code. 
HttpdSupervisor() will monitor these counters.  Due to the way the seconds are
counted-down, and the setting of a timer may be in the middle of any one
second interval, increment very small periods to ensure they are at least that.
The 'DurationSeconds' is an optional parameter.  If set to zero the standard
timer values are used.  If non-zero the value is used.  This allows CGI
callouts and scripting control to set these with specific values.
*/

HttpdTimerSet
(
struct RequestStruct *rqptr,
int Function,
int DurationSeconds
)
{
   static boolean  Initialize = true;
   static unsigned long  InputSeconds,
                         KeepAliveSeconds,
                         NoProgressSeconds,
                         OutputSeconds;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HttpdTimerSet() %d\n", Function);

   if (Initialize)
   {
      Initialize = false;
      if (Config.cfTimeout.MinutesInput)
         InputSeconds = Config.cfTimeout.MinutesInput * 60;
      else
         InputSeconds = DEFAULT_TIMEOUT_INPUT_MINUTES * 60;
      if (Config.cfTimeout.MinutesOutput)
         OutputSeconds = Config.cfTimeout.MinutesOutput * 60;
      else
         OutputSeconds = DEFAULT_TIMEOUT_OUTPUT_MINUTES * 60;
      if (Config.cfTimeout.MinutesNoProgress)
         NoProgressSeconds = Config.cfTimeout.MinutesNoProgress * 60;
      else
         NoProgressSeconds = DEFAULT_TIMEOUT_NOPROGRESS_MINUTES * 60;
      if (Config.cfTimeout.SecondsKeepAlive)
         KeepAliveSeconds = Config.cfTimeout.SecondsKeepAlive;
      else
         KeepAliveSeconds = DEFAULT_TIMEOUT_KEEPALIVE_SECONDS;
      /* ensure small periods are at least that duration */
      if (KeepAliveSeconds && KeepAliveSeconds < 10) KeepAliveSeconds++;
   }

   switch (Function)
   {
      case TIMER_INPUT :

         rqptr->rqTmr.OutputCount =
            rqptr->rqTmr.NoProgressBytesRx =
            rqptr->rqTmr.NoProgressBytesTx =
            rqptr->rqTmr.NoProgressCount =
            rqptr->rqTmr.NoProgressSeconds =
            rqptr->rqTmr.KeepAliveCount = 0;
         if (DurationSeconds)
            rqptr->rqTmr.InputCount = DurationSeconds;
         else
            rqptr->rqTmr.InputCount = InputSeconds;

         if (rqptr->WatchItem &&
            (WatchEnabled & WATCH_TIMER))
            WatchThis (rqptr, FI_LI, WATCH_TIMER,
                       "INPUT !UL seconds", rqptr->rqTmr.InputCount);

         return;

      case TIMER_OUTPUT :

         rqptr->rqTmr.InputCount =
            rqptr->rqTmr.NoProgressBytesRx =
            rqptr->rqTmr.NoProgressBytesTx =
            rqptr->rqTmr.KeepAliveCount = 0;
         if (DurationSeconds)
            rqptr->rqTmr.OutputCount = DurationSeconds;
         else
            rqptr->rqTmr.OutputCount = OutputSeconds;
         rqptr->rqTmr.NoProgressCount =
            rqptr->rqTmr.NoProgressSeconds = NoProgressSeconds;

         if (rqptr->WatchItem &&
            (WatchEnabled & WATCH_TIMER))
            WatchThis (rqptr, FI_LI, WATCH_TIMER,
                       "OUTPUT !UL seconds", rqptr->rqTmr.OutputCount);

         return;

      case TIMER_NOPROGRESS :

         if (DurationSeconds)
            rqptr->rqTmr.NoProgressCount =
               rqptr->rqTmr.NoProgressSeconds = DurationSeconds;
         else
            rqptr->rqTmr.NoProgressCount =
               rqptr->rqTmr.NoProgressSeconds = NoProgressSeconds;

         if (rqptr->WatchItem &&
            (WatchEnabled & WATCH_TIMER))
            WatchThis (rqptr, FI_LI, WATCH_TIMER,
                       "NOPROGRESS !UL seconds",
                       rqptr->rqTmr.NoProgressSeconds);

         return;

      case TIMER_KEEPALIVE :

         rqptr->rqTmr.InputCount =
            rqptr->rqTmr.OutputCount =
            rqptr->rqTmr.NoProgressBytesRx =
            rqptr->rqTmr.NoProgressBytesTx =
            rqptr->rqTmr.NoProgressCount =
            rqptr->rqTmr.NoProgressSeconds = 0;
         rqptr->rqTmr.KeepAliveCount = KeepAliveSeconds;

         if (rqptr->WatchItem &&
            (WatchEnabled & WATCH_TIMER))
            WatchThis (rqptr, FI_LI, WATCH_TIMER,
                       "KEEP-ALIVE !UL seconds", rqptr->rqTmr.KeepAliveCount);

         return;

      default :
         ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
   }

   rqptr->rqTmr.TerminatedCount = 0;
}

/*****************************************************************************/
/*
Whenever at least one request is being processed this function is called every
second to supervise the requests' progress.  Scanning the list of current
processes it decrements set timer counters.  When a counter reaches zero
the request is run down.

This function was introduced to address a suspected multi-thread timing problem
associated with setting and cancelling independent timers and ASTs for each
request.  It is probably no more expensive than setting and reseting VMS
timers for each request's processing, and does seem to give some measure (or
feeling of) more structure and control!
*/

HttpdSupervisor (boolean TimerExpired)

{
   static unsigned long  OneSecondDelta [2] = { -10000000, -1 };
   static boolean  TimerSet = false;

   register struct RequestStruct  *rqeptr;
   register struct ListEntryStruct  *leptr;

   int  status;
   char  *TimerTypePtr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "HttpdSupervisor() %d HeadPtr: %d\n",
               TimerExpired, RequestList.HeadPtr);

   if (!TimerExpired)
   {
      /* new request, if the supervisor is already running just return */
      if (TimerSet) return;

      /* kick the request supervisor timer into life */
      if (VMSnok (status =
          sys$setimr (0, &OneSecondDelta, &HttpdSupervisor, true, 0)))
         ErrorExitVmsStatus (status, "sys$setimr()", FI_LI);
      TimerSet = true;

      return;
   }

   /* must have got here via the supervisor's timer expiring */
   TimerSet = false;

   /* if nothing in the current request list return without sys$setimr() */
   if ((leptr = RequestList.HeadPtr) == NULL) return;

   /* process the current request list entries */
   for ( /* from above */ ; leptr != NULL; leptr = leptr->NextPtr)
   {
      rqeptr = (struct RequestStruct*)leptr;

      if (Debug)
         fprintf (stdout,
"%d <- %d -> %d (%d) in: %d out: %d alive: %d terminated: %d\n",
                  leptr->PrevPtr, leptr, leptr->NextPtr, rqeptr,
                  rqeptr->rqTmr.InputCount, rqeptr->rqTmr.OutputCount,
                  rqeptr->rqTmr.KeepAliveCount, rqeptr->rqTmr.TerminatedCount);


      /* ordered in the most common occurance of timings */
      if (rqeptr->rqTmr.OutputCount)
      {
         if (rqeptr->rqTmr.NoProgressBytesRx == rqeptr->BytesRx &&
             rqeptr->rqTmr.NoProgressBytesTx == rqeptr->BytesTx)
         {
            /* note the start of any no-progress timing */
            if (rqeptr->WatchItem &&
                (WatchEnabled & WATCH_TIMER) &&
                rqeptr->rqTmr.NoProgressCount ==
                   rqeptr->rqTmr.NoProgressSeconds)
               WatchThis (rqeptr, FI_LI, WATCH_TIMER,
                          "NO-PROGRESS !UL seconds",
                          rqeptr->rqTmr.NoProgressSeconds);

            if (rqeptr->rqTmr.NoProgressCount) rqeptr->rqTmr.NoProgressCount--;
         }
         else
         {
            rqeptr->rqTmr.NoProgressCount = rqeptr->rqTmr.NoProgressSeconds;
            rqeptr->rqTmr.NoProgressBytesRx = rqeptr->BytesRx;
            rqeptr->rqTmr.NoProgressBytesTx = rqeptr->BytesTx;
         }

         if (rqeptr->rqTmr.NoProgressCount)
         {
            if (--rqeptr->rqTmr.OutputCount)
               continue;
            else
               TimerTypePtr = "OUTPUT";
         }
         else
            TimerTypePtr = "NO-PROGRESS";
      }
      else
      if (rqeptr->rqTmr.KeepAliveCount)
      {
         if (--rqeptr->rqTmr.KeepAliveCount)
            continue;
         else
         {
            TimerTypePtr = "KEEP-ALIVE";
            if (rqeptr->rqNet.ClientChannel) NetCloseSocket (rqeptr);
         }
      }
      else
      if (rqeptr->rqTmr.InputCount)
      {
         if (--rqeptr->rqTmr.InputCount)
            continue;
         else
         {
            TimerTypePtr = "INPUT";
            if (rqeptr->rqNet.ClientChannel) NetCloseSocket (rqeptr);
         }
      }

      if (!rqeptr->rqTmr.TerminatedCount++)
      {
         if (rqeptr->WatchItem &&
             (WatchEnabled & WATCH_TIMER))
            WatchThis (rqeptr, FI_LI, WATCH_TIMER,
                       "!AZ expired", TimerTypePtr);

         if (rqeptr->DclTaskPtr != NULL)
         {
            /* DCL involved, do any DCL-specific cleanup */
            DclConcludeTask (rqeptr->DclTaskPtr, true);
         }
         else
         if (rqeptr->DECnetTaskPtr != NULL)
         {
            /* DECnet (CGI or OSU) involved */
            DECnetDisconnectTask (rqeptr->DECnetTaskPtr);
         }
         else
         if (rqeptr->ProxyTaskPtr != NULL)
         {
            if (rqeptr->ProxyTaskPtr->ProxyChannel)
               ProxyCloseSocket (rqeptr->ProxyTaskPtr);
         }

         if (rqeptr->rqNet.ClientChannel) NetCloseSocket (rqeptr);
      }
   }

   if (VMSnok (status =
       sys$setimr (0, &OneSecondDelta, &HttpdSupervisor, true, 0)))
      ErrorExitVmsStatus (status, "sys$setimr()", FI_LI);

   TimerSet = true;
}

/*****************************************************************************/

k                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        