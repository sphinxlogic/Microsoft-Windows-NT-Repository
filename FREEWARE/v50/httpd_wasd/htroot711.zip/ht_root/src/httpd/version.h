/*****************************************************************************/
/*
                                version.h


VERSION HISTORY
---------------
18-JAN-2001  MGD  v7.1.1,
                  HTTPD$SCRATCH automatic script scratch file cleanup
                  authentication agent can now '100 SET-COOKIE rfc2109-cookie'
                  bugfix; memory leak in AUTH.C
                  bugfix; apache_mod_ssl-style CGI variables
                  bugfix; FILE.C make a search list DNF appear as a FNF
                  bugfix; /PROFILE empty directory passing incorrect parameter,
                  bugfix; general error reporter variable arguments,
                  bugfix; final authorization failure should specify 403,
                  bugfix; ensure mapping rules exist for authentication agents
                  bugfix; control cache purge arguments
17-OCT-2000  MGD  v7.1.0,
                  sys$creprc() scripting,
                  sys$persona...() scripting,
                  Run Time Environments (RTEs),
                  server-group/cluster-wide directives (via DLM),
                  further refined CGI.C module output handling,
                  apply authorization to SSI.C #include'd and #dir'e,
                  client socket (BGnnnn:) potentially sharable for scripts,
                  proxy cache device directory organization flat256/64x64,
                  modify SSL initialization to better indicate "fallback",
                  integration of WATCH peek/one-shot
03-SEP-2000  MGD  v7.0.2
                  limit script output of ENDOFFILE,
                  if CGI response "Content-Encoding:" force stream mode,
                  bugfix; ProxyResolveHostLookup() can be called multiple
                  during host name resolution - only allocate channel once!!
                  bugfix; include Accept-Encoding when redirecting,
                  bugfix; ParseQueryField() string length check
09-JUL-2000  MGD  v7.0.1
                  locking around proxy cache scans,
                  add "success=" 303 processing to PUT.C file upload,
                  improve CgiOutput() header processing (again!),
                  correct concealed/searchlist parsing,
                  allow "302 location" redirection from authentication agent,
                  bugfix; proxy CONNECT service
                  bugfix; HEAD requests specifying content-length,
                  bugfix; WatchCliSettings() storage
01-JUN-2000  MGD  v7.0.0
                  support extended file specifications
                  (ODS-5 under Alpha VMS V7.2ff),
                  event reporting via OPCOM,
                  some "Apache" support for easing CGI script ports,
                  access log file naming refinements
18-MAR-2000  MGD  v6.1.3,
                  bugfix; authconfig processing
06-JAN-2000  MGD  v6.1.2,
                  authorization failure limit evasion period,
                  numerous warnings from DECC v6.2 addressed,
                  bugfix; user restriction list pass (broken in 6.1)
17-DEC-1999  MGD  v6.1.1,
                  bugfix; quote double-up in CgiVariable() (INSVIRMEM exit)
04-DEC-1999  MGD  v6.1.0,
                  "agent" authentication/authorization,
                  CGI(plus) processing provides callouts,
                  SSI module now supports OSU-specific directives,
                  /SYSPRV now allows operation with SYSPRV turned on,
                  "one-shot" WATCH and "peek" reports,
                  output no-progress timer,
                  remove NETLIB support
16-OCT-1999  MGD  v6.0.3,
                  bugfix; sys$create_user_profile,
                  bugfix; mapping storage overflow
                  USER mapping rule for SYSUAF access
12-SEP-1999  MGD  v6.0.2,
                  minor changes to authorization processing,
                  bugfix; service parsing and SSL,
                  virtual services now match using "Host:" field
19-JUN-1999  MGD  v6.0.1,
                  refinements to request termination/rundown,
                  bugfix; DECnet (CGI and OSU) task handling
                  bugfix; proxy request HTTP/0.9 response processing
30-MAY-1999  MGD  v6.0.0,
                  proxy, with HTTP caching,
                  OpenSSL 0.9.3 support (also SSLeay support),
                  extended authorization/authentication environment
31-MAR-1999  MGD  v5.3.4,
                  bugfix; SesolaReport(), HttpHeaderChallenge()
28-MAR-1999  MGD  v5.3.3,
                  SSI variables global (when "#include"ing other SSI),
                  SSI read buffer determined by 'FileXabFhc.xab$w_lrl'
05-FEB-1999  MGD  v5.3.2,
                  bugfix; FileNextRecord() zero '_usz'
10-JAN-1999  MGD  v5.3.1,
                  greater granularity when WATCHing authorization,
                  bugfix; OSU scripting pass *mapped* file spec
14-NOV-1998  MGD  v5.3.0,
                  [[host:port]] virtual service syntax,
                  [AddType] can now "text/html; charset=ISO-8859-1",
                  [CharsetDefault] sets text and server character set,
                  improved AST granularity several significant modules,
                  WATCH report and CLI,
                  RMS-invalid substitution character in mapping rules,
                  bugfix; NameOfDirectoryFile()
29-AUG-1998  MGD  v5.2.0,
                  reuse DECnet task connections,
                  allow specified hosts exclusion from logging,
                  stream-LF conversion only on specified paths,
                  bugfix; SYS$TIMEZONE_DIFFERENTIAL processing
                  bugfix; DECnet tasks not aborted at timeout
07-JUL-1998  MGD  v5.1.0,
                  add eXtended Server Side Includes processing,
                  design-problem; modify CGIplus script rundown,
                  SYSUAF authentication by identifier,
                  per-service logging,
                  rqptr->rqTmr.Terminated (occasional lib$get_vm()
                  %LIB-F-BADLOADR around connection expiry termination)
20-DEC-1997  MGD  v5.0.0,
                  optional Secure Sockets Layer (using SSLeay),
                  DECnet-based scripting including OSU emulation,
                  miscellaneous revisions and "improvements"
07-JAN-1997  MGD  v4.5.2,
                  bugfix; record-mode file transfer,
                  bugfix; activity graph
06-DEC-1997  MGD  v4.5.1,
                  resolving a suspected inconsistent AST delivery situation
                  by requiring all $QIO()s with AST routines to ensure any
                  queueing errors, etc. are reported via the AST routine, by
                  an explicit $DCLAST() ... this removes ambiguity about how
                  $QIO() returns should be handled ... drastic, but desperate
                  times, etc. (a more consistent and desirable model anyway :^)
02-NOV-1997  MGD  v4.5.0,
                  file cache,
                  logging periods,
                  HttpdSupervisor(),
                  configurable script run-time environments,
                  additional request header fields
18-OCT-1997  MGD  v4.4.1,
                  bugfix; duration,
                  bugfix; logging period
01-OCT-1997  MGD  v4.4.0,
                  message module,
                  conditional rule mapping,
                  SYSUAF-authenticated user access control,
                  multi-homed/multi-port services
                  (some NETLIB packages now cannot DNS lookup),
                  echo and Xray internal scripts,
                  extensions to logging functionality,
                  additional command-line server control,
                  bugfix; redirection loop detection
01-AUG-1997  MGD  v4.3.0,
                  MadGoat NETLIB broadens TCP/IP package support,
                  server activity report
16-JUL-1997  MGD  v4.2.2,
                  bugfix; WORLD realm and access list
07-JUL-1997  MGD  v4.2.1,
                  minimum heap allocation chunk size,
                  prevent keep-alive timeout redefining request logical
01-JUL-1997  MGD  v4.2.0,
                  change name to WASD (Wide Area Surveillance Division)
                  persistant DCL subprocesses and CGIplus 
                  (see re-written DCL.C module),
                  scripting and client reports,
                  potential multi-thread problems in reports fixed
27-MAR-1997  MGD  v4.1.0,
                  rationalized HTTP response header generation,
                  delete on close for "temporary" files, to support
                  UPD module "preview" functionality ... WARNING, any
                  file with a name comprising a leading hyphen,
                  sixteen digits and a trailing hyphen will be deleted!
01-FEB-1997  MGD  v4.0.0,
                  HTTPd version 4
01-OCT-1996  MGD  v3.4.0,
                  extended server reporting  
01-AUG-1996  MGD  v3.3.0,
                  realm/path-based authorization,
                  BASIC and DIGEST authentication,
                  PUT(/POST/DELETE) module,
                  StmLf module (variable to stream-LF file conversion)
12-APR-1996  MGD  v3.2.0,
                  file record/binary now determined by record format,
                  persistent connections ("Keep-Alive" within HTTP/1.0),
                  moved RMS parse structures into thread data,
                  improved local redirection detection,
                  observed Multinet disconnection/zero-byte behaviour
                  (request now aborts if network read returns zero bytes)
15-FEB-1996  MGD  v3.1.1,
                  fixed rediculous :^( bug in 302 HTTP header,
                  minor changes to request accounting and server report,
                  minor changes for user directory support,
                  minor changes to error reporting
03-JAN-1996  MGD  v3.1.0,
                  support for both DEC TCP/IP Services and TGV MultiNet
01-DEC-1995  MGD  v3.0.0,
                  single heap for each thread's dynamic memory management,
                  extensive rework of DCL subprocess functionality,
                  HTML pre-processsing module (aka Server Side Includes),
                  NCSA/CERN compliant image-mapping module,
                  NetWriteBuffered() for improving network IO,
                  miscellaneous reworks/rewrites
27-SEP-1995  MGD  v2.3.0,
                  carriage-control on non-header records from <CR><LF> 
                  to single <LF> ('\n' ... newline), some browsers expect
                  only this (e.g. Netscape 1.n was spitting on X-bitmaps)
                  added Greenwich Mean Time time-stamp functionality,
                  added 'Referer:', 'If-Modified-Since:', 'User-Agent:'
07-AUG-1995  MGD  v2.2.2,
                  optionally include commented VMS file specifications
                  in HTML documents and VMS-style directory listings
16-JUN-1995  MGD  v2.2.1,
                  added file type description to "Index of" (directory)
24-MAY-1995  MGD  v2.2.0,
                  minor changes to allow compilation on AXP platform
03-APR-1995  MGD  v2.1.0,
                  add SYSUAF authentication, POST method handling
20-DEC-1994  MGD  v2.0.0,
                  multi-threaded version
20-JUN-1994  MGD  v1.0.0,
                  single-threaded version
*/
/*****************************************************************************/

#ifndef VERSION_H_LOADED
#define VERSION_H_LOADED 1

#define HTTPD_NAME "WASD"
#define HTTPD_SOFTWAREID_NAME "HTTPd-WASD"

/* keep 'HttpdAccountingVersion' in step with this version (as necessary) */
#define HTTPD_VERSION "7.1.1"

/* used to check when accounting requires zeroing on change of version */
#define HTTPD_ACCOUNTING_VERSION 0x0710

VersionInfo();

#endif /* VERSION_H_LOADED */

/*****************************************************************************/
