/*****************************************************************************/
/*
                                  Upd.c

This module implements a full multi-threaded, AST-driven, asynchronous file
and directory update facility.

It provides for directory navigation, allowing subdirectories to be created,
moved to, listed and deleted.  Files within directories may be selected for
viewing, update, copying and deletion.  The module honours the directory
access controls implemented by the directory module (e.g. ".WWW_HIDDEN",
etc., see Dir.c).

It allows the creation or update of "text/*" files via an editing page.  The
<TEXTAREA></TEXTAREA> tag widget is used as the edit window.

The file editing page also has custom functionality for providing for the
partial administration of HTTPd server configuration files.

This module behaves as if it was an external script :^).  This allows the
generic script processing functionality of the the request module to provide
all necessary parsing of the script and file components of the path, as well
as the all-important authorization checking of these.  The script component
of the path is detected before an external script is launched, and the request
redirected to this module.  This has certain efficiencies as well as allowing
a "generic" module to provide some of the functionality for server
configuration.  This module does its own query string parsing.

An essential component of this modules functionality is the ability to
generate a redirection.  This allows the parent directory and name to be
reconstructed as a path and then processed as if a new request.  Although
resulting in a higher overhead this considerably simplifies the handling of
these requests.


VERSION HISTORY
---------------
22-DEC-2000  MGD  allow navigation on wildcard file specification
29-JUN-2000  MGD  bugfix; ODS-5 file rename
18-JUN-2000  MGD  support site log update
04-MAR-2000  MGD  support ODS-2 and ODS-5 using ODS module,
                  substantial rework of entire module,
                  remove browser check for file upload (many now support)
10-OCT-1999  MGD  change AuthCheckVmsUserAccess() always supply 'rqptr'
04-APR-1999  MGD  bugfix; rule check still included (woops, obsoleted in v5.3)
07-NOV-1998  MGD  WATCH facility
12-MAR-1998  MGD  add file protection selector
24-FEB-1998  MGD  request scheme ("http:" or "https:") for hard-wired "http:"
18-OCT-1997  MGD  facility to wildcard file deletes
17-AUG-1997  MGD  message database,
                  internationalized file date/times,
                  SYSUAF-authenticated users security-profile
07-JUL-1997  MGD  apparently MSIE 3.0ff allows file upload
30-JUN-1997  MGD  bugfix; rename failed without SYSPRV (wonders will never)
12-APR-1997  MGD  extended tree facility to providing general directory tree
25-MAR-1997  MGD  added tree and filter capabilities
01-FEB-1997  MGD  new for HTTPd version 4 (adapted from the UPD script)
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* VMS related header files */
#include <iodef.h>
#include <libdef.h>
#include <libdtdef.h>
#include <rmsdef.h>
#include <rms.h>
#include <ssdef.h>
#include <stsdef.h>

/* application related header */
#include "wasd.h"

#define WASD_MODULE "UPD"

/****************/
/* global stuff */
/****************/

/* number of rows in directory and file lists */
#define NAVIGATE_SIZE 9

/* this could be relocated without change by using a mapping rule */
#define UPD_HELP_PATH "/httpd/-/UpdHelp.html"

/*
The preview note is introduced at the start of a file being previewed.
See PUT.C module for how it is further processed.
Experimentation (Navigator 3 and MSIE 3) has shown it can contain text
but no page or line layup tags (e.g. <BR>).
Here is a choice between an animated GIF and text.
*/
#define UPD_PREVIEW_NOTE_PLAIN "-PREVIEW-\n\n"

#ifndef UPD_PREVIEW_TEXT

#define UPD_PREVIEW_NOTE_HTML \
"&lt;IMG SRC=&quot;/httpd/-/UpdPreview.gif&quot; \
ALT=&quot;-PREVIEW- &quot;&gt;&lt;BR&gt;"
#define UPD_PREVIEW_NOTE_HTML_NEWLINE "&#10;"
#define UPD_PREVIEW_NOTE_MENU_NEWLINE "&lt;BR&gt;"

#else

#define UPD_PREVIEW_NOTE_HTML \
"&lt;FONT SIZE=1 COLOR=&quot;#ff0000&quot;&gt;\
&lt;SUP&gt;&lt;BLINK&gt;&lt;B&gt;-PREVIEW-&lt;/B&gt;&lt;/BLINK&gt;&lt;/SUP&gt;\
&lt;/FONT&gt;&amp;nbsp;&amp;nbsp;"
#define UPD_PREVIEW_NOTE_HTML_NEWLINE "&#10;"
#define UPD_PREVIEW_NOTE_MENU_NEWLINE "&lt;BR&gt;"

#endif /* UPD_PREVIEW_TEXT */

char  UpdProtectionListFao [] =
"<SELECT NAME=protection>\n\
<OPTION VALUE=\"aa00\" SELECTED>!AZ\n\
<OPTION VALUE=\"fa00\">!AZ\n\
<OPTION VALUE=\"ff00\">!AZ\n\
</SELECT>\n";

/* must be the size of the above descriptor string plus enough for the !AZs */
char  UpdProtectionList [256];

char  UpdLayout [64];

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern boolean  NaturalLanguageEnglish,
                OdsExtended;

extern int  WatchEnabled;

extern char*  DayName[];

extern char  ClientHostName[],
             ClientIpAddressString[],
             DirBrowsableFileName[],
             DirHiddenFileName[],
             DirNopFileName[],
             DirNosFileName[],
             DirNopsFileName[],
             DirNoWildFileName[],
             ErrorSanityCheck[],
             ServerHostPort[],
             SoftwareID[],
             Utility[];

extern struct AccountingStruct  Accounting;
extern struct ConfigStruct  Config;
extern struct MsgStruct  Msgs;

/*****************************************************************************/
/*
Begin processing an update request by allocating an update task structure,
processing the query string, and initiating the required function.
*/

UpdBegin
(
struct RequestStruct *rqptr,
void *NextTaskFunction
)
{
   register unsigned long  *vecptr;
   register char  *cptr, *qptr, *sptr, *zptr;
   register struct UpdTaskStruct  *tkptr;

   boolean  DoCopy,
            DoDirProtect,
            DoFileProtect,
            DoFileRename,
            DoTree,
            Navigate,
            NameIsPeriod,
            SubmitCopy,
            SubmitCreate,
            SubmitDelete,
            SubmitDirProtect,
            SubmitEdit,
            SubmitFilter,
            SubmitFileRename,
            SubmitFileProtect,
            SubmitGoto,
            SubmitList,
            SubmitMkdir,
            SubmitRmdir,
            SubmitTree,
            SubmitView,
            WatchThisOne;
   int  status;
   unsigned short  Length;
   unsigned long  FaoVector [32];
   char  *WatchPathPtr;
   char  AsName [256],
         FieldName [128],
         FieldValue [256],
         Location [ODS_MAX_FILE_NAME_LENGTH+1],
         Name [128],
         Scratch [ODS_MAX_FILE_NAME_LENGTH+1],
         SubmitButton [16];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UpdBegin()\n");

   if (rqptr->rqResponse.ErrorReportPtr != NULL)
   {
      /* previous error, cause threaded processing to unravel */
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   if (!rqptr->AccountingDone)
      rqptr->AccountingDone = ++Accounting.DoUpdateCount;

   /* set up the task structure (only ever one per request!) */
   rqptr->UpdTaskPtr = tkptr = (struct UpdTaskStruct*)
      VmGetHeap (rqptr, sizeof(struct UpdTaskStruct));
   tkptr->NextTaskFunction = NextTaskFunction;

   tkptr->ProtectionMask = PUT_DEFAULT_FILE_PROTECTION;
   tkptr->SearchOds.ParseInUse = false;

   if (rqptr->WatchItem && (WatchEnabled & WATCH_RESPONSE))
      WatchThisOne = true;
   else
      WatchThisOne = false;

   if (strsame (rqptr->ScriptName, ADMIN_SCRIPT_TREE,
                sizeof(ADMIN_SCRIPT_TREE)-1))      
   {
      /***********/
      /* tree of */
      /***********/

      tkptr->UpdateTree = false;

      if (WatchThisOne)
         WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                    "TREEOF !AZ !AZ",
                    rqptr->rqHeader.PathInfoPtr, rqptr->ParseOds.ExpFileName);

      if (!rqptr->ParseOds.ExpFileNameLength)
      {
         rqptr->rqResponse.HttpStatus = 400;
         ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_DIRECTORY), FI_LI);
         UpdEnd (rqptr);
         return;
      }

      if (rqptr->ParseOds.Nam_fnb & NAM$M_WILD_VER ||
          rqptr->ParseOds.Nam_fnb & NAM$M_EXP_VER)
         tkptr->FormatTreeLikeVms = true;
      else
         tkptr->FormatTreeLikeVms = false;

      /* get any file name, type, version from request specification */
      zptr = (sptr = tkptr->FileNamePart) + sizeof(tkptr->FileNamePart)-1;
      for (cptr = rqptr->ParseOds.NamNamePtr;
           *cptr && sptr < zptr;
           *sptr++ = *cptr++);
      if (sptr >= zptr)
      {
         ErrorGeneralOverflow (rqptr, FI_LI);
         UpdEnd (rqptr);
         return;
      }
      *sptr = '\0';

      if (Debug) fprintf (stdout, "|%s|\n", tkptr->FileNamePart);
 
      rqptr->rqResponse.PreExpired = Config.cfDir.PreExpired;
      /* scan the query string looking for "expired=[yes|no|true|false|1|0]" */
      for (cptr = rqptr->rqHeader.QueryStringPtr; *cptr; cptr++)
      {
         /* experience shows both make it easier! */
         if (tolower(*cptr) == 'e' && 
             (strsame (cptr, "expired=", 8)) || strsame (cptr, "expire=", 7))
         {
            if (cptr[7] == '=')
               cptr += 8;
            else
               cptr += 7;
            /* "true", "yes", "1", "false", "no" or "0" */
            if (tolower(*cptr) == 't' || tolower(*cptr) == 'y' || *cptr == '1')
               rqptr->rqResponse.PreExpired = true;
            else
            if (tolower(*cptr) == 'f' || tolower(*cptr) == 'n' || *cptr == '0')
               rqptr->rqResponse.PreExpired = false;
            break;
         }
         while (*cptr && *cptr != '&') cptr++;
         if (*cptr) cptr++;
      }

      UpdTreeBegin (rqptr);

      return;
   }

   /**********/
   /* update */
   /**********/

   AsName[0] = Name[0] = SubmitButton[0] = tkptr->CxR[0] = '\0';
   DoCopy = DoDirProtect = DoFileProtect = DoFileRename = DoTree =
      SubmitCreate = SubmitCopy = SubmitDelete = SubmitDirProtect =
      SubmitEdit = SubmitFileProtect = SubmitFilter = SubmitFileRename =
      SubmitGoto = SubmitList = SubmitMkdir = SubmitRmdir = SubmitTree = 
      SubmitView = false;

   if (rqptr->rqHeader.Method == HTTP_METHOD_GET ||
       rqptr->rqHeader.Method == HTTP_METHOD_HEAD)
      qptr = rqptr->rqHeader.QueryStringPtr;
   else
      qptr = rqptr->rqBody.BufferPtr;
   while (*qptr)
   {
      qptr = ParseQueryField (rqptr, qptr,
                              FieldName, sizeof(FieldName),
                              FieldValue, sizeof(FieldValue),
                              FI_LI);
      if (qptr == NULL)
      {
         /* error occured */
         SysDclAst (NextTaskFunction, rqptr);
         return;
      }

      /********************/
      /* get field values */
      /********************/

      if (strsame (FieldName, "as", -1))
      {
         cptr = FieldValue;
         zptr = (sptr = AsName) + sizeof(AsName);
         while (*cptr && sptr < zptr) *sptr++ = *cptr++;
         if (sptr >= zptr)
         {
            ErrorGeneralOverflow (rqptr, FI_LI);
            UpdEnd (rqptr);
            return;
         }
         *sptr = '\0';
      }
      else
      if (strsame (FieldName, "cxr", -1))
      {
         cptr = FieldValue;
         zptr = (sptr = tkptr->CxR) + sizeof(tkptr->CxR);
         while (*cptr && sptr < zptr) *sptr++ = *cptr++;
         if (sptr >= zptr)
         {
            ErrorGeneralOverflow (rqptr, FI_LI);
            UpdEnd (rqptr);
            return;
         }
         *sptr = '\0';
      }
      else
      if (strsame (FieldName, "name", -1))
      {
         cptr = FieldValue;
         zptr = (sptr = Name) + sizeof(Name);
         while (*cptr && sptr < zptr) *sptr++ = *cptr++;
         if (sptr >= zptr)
         {
            ErrorGeneralOverflow (rqptr, FI_LI);
            UpdEnd (rqptr);
            return;
         }
         *sptr = '\0';
      }
      else
      if (strsame (FieldName, "protection", -1))
      {
         if (isxdigit(FieldValue[0]))
            tkptr->ProtectionMask = strtol (FieldValue, NULL, 16);
      }
      else
      if (tolower(FieldName[0]) == 'd' && FieldName[1] == '-')
      {
         if (strsame (FieldName, "d-copy", -1))
            DoCopy = true;
         else
         if (strsame (FieldName, "d-dirprotect", -1))
            DoDirProtect = true;
         else
         if (strsame (FieldName, "d-fileprotect", -1))
            DoDirProtect = true;
         else
         if (strsame (FieldName, "d-filerename", -1))
            DoFileRename = true;
         else
         if (strsame (FieldName, "d-tree", -1))
            DoTree = true;
      }
      else
      if (tolower(FieldName[0]) == 's' && FieldName[1] == '-')
      {
         if (strsame (FieldName, "s-copy", -1))
            SubmitCopy = true;
         else
#ifdef UPD_CREATE
         if (strsame (FieldName, "s-create", -1))
            SubmitCreate = true;
         else
#endif /* UPD_CREATE */
         if (strsame (FieldName, "s-delete", -1))
            SubmitDelete = true;
         else
         if (strsame (FieldName, "s-dirprotect", -1))
            SubmitDirProtect = true;
         else
         if (strsame (FieldName, "s-edit", -1))
            SubmitEdit = true;
         else
         if (strsame (FieldName, "s-fileprotect", -1))
            SubmitFileProtect = true;
         else
#ifdef UPD_FILTER
         if (strsame (FieldName, "s-filter", -1))
            SubmitFilter = true;
         else
#endif /* UPD_FILTER */
         if (strsame (FieldName, "s-goto", -1))
            SubmitGoto = true;
         else
         if (strsame (FieldName, "s-list", -1))
            SubmitList = true;
         else
         if (strsame (FieldName, "s-mkdir", -1))
            SubmitMkdir = true;
         else
         if (strsame (FieldName, "s-filerename", -1))
            SubmitFileRename = true;
         else
         if (strsame (FieldName, "s-rmdir", -1))
            SubmitRmdir = true;
         else
         if (strsame (FieldName, "s-tree", -1))
            SubmitTree = true;
         else
         if (strsame (FieldName, "s-view", -1))
            SubmitView = true;
         else
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_QUERY_FIELD), FI_LI);
            UpdEnd (rqptr);
            return;
         }
         strcpy (SubmitButton, FieldName+2);
      }
      else
      {
         rqptr->rqResponse.HttpStatus = 403;
         ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_QUERY_FIELD), FI_LI);
         UpdEnd (rqptr);
         return;
      }
   }

   /**************************/
   /* end parse query string */
   /**************************/

   /* ensure something has been entered into the file name field */
   if (*(unsigned short*)Name == '.\0')
   {
      NameIsPeriod = true;
      Name[0] = '\0';
   }
   else
      NameIsPeriod = false;

   if (SubmitDelete)
   {
      /***************/
      /* delete file */
      /***************/

      if (!Name[0] && !AsName[0])
      {
         rqptr->rqResponse.HttpStatus = 400;
         ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_FILENAME), FI_LI);
         UpdEnd (rqptr);
         return;
      }

      if (WatchThisOne)
         WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                    "UPDATE !AZ !AZ!AZ",
                    SubmitButton, rqptr->rqHeader.PathInfoPtr,
                    AsName[0] ? AsName : Name);

      UpdConfirmDelete (rqptr, AsName[0] ? AsName : Name, "");
      return;
   }

   if (SubmitMkdir)
   {
      /***********************/
      /* create subdirectory */
      /***********************/

      if (!AsName[0])
      {
         rqptr->rqResponse.HttpStatus = 400;
         ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_DIRECTORY), FI_LI);
         UpdEnd (rqptr);
         return;
      }

      if (WatchThisOne)
         WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                    "UPDATE !AZ !AZ!AZ",
                    SubmitButton, rqptr->rqHeader.PathInfoPtr, AsName);

      UpdConfirmMkdir (rqptr, AsName);
      return;
   }

   if (SubmitRmdir)
   {
      /***********************/
      /* delete subdirectory */
      /***********************/

      if (!Name[0])
      {
         rqptr->rqResponse.HttpStatus = 400;
         ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_DIRECTORY), FI_LI);
         UpdEnd (rqptr);
         return;
      }

      if (WatchThisOne)
         WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                    "UPDATE !AZ !AZ!AZ",
                    SubmitButton, rqptr->rqHeader.PathInfoPtr, Name);

      UpdConfirmDelete (rqptr, Name, "/");
      return;
   }

   if (SubmitCopy ||
#ifdef UPD_CREATE
       SubmitCreate ||
#endif /* UPD_CREATE */
       SubmitDirProtect ||
       SubmitEdit ||
       SubmitFileProtect ||
#ifdef UPD_FILTER
       SubmitFilter ||
#endif /* UPD_FILTER */
       SubmitGoto ||
       SubmitList ||
       SubmitMkdir ||
       SubmitFileRename ||
       SubmitTree ||
       SubmitView)
   {
      /******************************/
      /* REDIRECT (via "Location:") */
      /******************************/

      if (SubmitCopy)
      {
         if (!Name[0])
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_SRC_FILENAME), FI_LI);
            UpdEnd (rqptr);
            return;
         }
         if (!AsName[0])
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_DST_FILENAME), FI_LI);
            UpdEnd (rqptr);
            return;
         }
         status = WriteFao (Location, sizeof(Location), &Length,
                            "!UZ!UZ!UZ?d-copy=1&as=!UZ&protection=!4XL",
                            rqptr->ScriptName, rqptr->rqHeader.PathInfoPtr, Name,
                            AsName, tkptr->ProtectionMask);
      }
      else
#ifdef UPD_CREATE
      if (SubmitCreate)
      {
         if (!AsName[0])
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_FILENAME), FI_LI);
            UpdEnd (rqptr);
            return;
         }
         status = WriteFao (Location, sizeof(Location), &Length,
                            "!UZ!UZ!UZ",
                            rqptr->ScriptName, rqptr->rqHeader.PathInfoPtr, AsName);
      }
      else
#endif /* UPD_CREATE */
      if (SubmitDirProtect)
      {
         if (!Name[0] && !AsName[0])
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_DIRECTORY), FI_LI);
            UpdEnd (rqptr);
            return;
         }
         status = WriteFao (Location, sizeof(Location), &Length,
                            "!UZ!UZ!UZ.dir?d-dirprotect=1&protection=!4XL",
                            rqptr->ScriptName, rqptr->rqHeader.PathInfoPtr,
                            AsName[0] ? AsName : Name,
                            tkptr->ProtectionMask);
      }
      else
      if (SubmitEdit)
      {
         if (!Name[0] && !AsName[0])
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_FILENAME), FI_LI);
            UpdEnd (rqptr);
            return;
         }
         status = WriteFao (Location, sizeof(Location), &Length,
                            "!UZ!UZ!UZ!AZ!UZ",
                            rqptr->ScriptName, rqptr->rqHeader.PathInfoPtr,
                            AsName[0] && !Name[0] ? AsName : Name,
                            AsName[0] && Name[0] ? "?as=" : "",
                            AsName[0] && Name[0] ? AsName : "");
      }
      else
#ifdef UPD_FILTER
      if (SubmitFilter)
      {
         if (!Name[0])
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_FILENAME), FI_LI);
            UpdEnd (rqptr);
            return;
         }
         if (!AsName[0])
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_FILTER), FI_LI);
            UpdEnd (rqptr);
            return;
         }
         status = WriteFao (Location, sizeof(Location), &Length,
                            "!AZ!UZ!UZ!UZ",
                            AsName[0] ? "/" : "",
                            AsName, rqptr->rqHeader.PathInfoPtr, AsName);
      }
      else
#endif /* UPD_FILTER */
      if (SubmitFileProtect)
      {
         if (!Name[0] && !AsName)
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_FILENAME), FI_LI);
            UpdEnd (rqptr);
            return;
         }
         status = WriteFao (Location, sizeof(Location), &Length,
                            "!UZ!UZ!UZ?d-fileprotect=1&protection=!4XL",
                            rqptr->ScriptName, rqptr->rqHeader.PathInfoPtr,
                            AsName[0] ? AsName : Name,
                            tkptr->ProtectionMask);
      }
      else
      if (SubmitGoto)
      {
         if (!Name[0])
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_DIRECTORY), FI_LI);
            UpdEnd (rqptr);
            return;
         }
         status = WriteFao (Location, sizeof(Location), &Length,
                           "!UZ!UZ!UZ/",
                           rqptr->ScriptName, rqptr->rqHeader.PathInfoPtr, Name);
      }
      else
      if (SubmitList)
      {
         if (!Name[0] && !NameIsPeriod)
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_DIRECTORY), FI_LI);
            UpdEnd (rqptr);
            return;
         }

         /* update directory listing layout including protection */
         if (!UpdLayout[0])
         {
            zptr = (sptr = UpdLayout) + sizeof(UpdLayout);
            for (cptr = "&layout="; *cptr; *sptr++ = *cptr++);

            if (Config.cfDir.DefaultLayout[0])
               cptr = Config.cfDir.DefaultLayout;
            else
               cptr = DEFAULT_DIR_LAYOUT;

            while (*cptr)
            {
               if (sptr >= zptr) break;
               if (*cptr == ':')
               {
                  if (sptr < zptr) *sptr++ = *cptr++;
                  if (*cptr && sptr < zptr) *sptr++ = *cptr++;
                  continue;
               }
               if (toupper(*cptr) == 'P')
               {
                  cptr++;
                  while (*cptr == '_') cptr++;
                  continue;
               }
               if (toupper(*cptr) == 'S')
               {
                  if (sptr < zptr) *sptr++ = *cptr++;
                  if (*cptr == ':')
                  {
                     *sptr++ = *cptr++;
                     if (*cptr && sptr < zptr) *sptr++ = *cptr++;
                  }
                  if (sptr < zptr) *sptr++ = '_';
                  if (sptr < zptr) *sptr++ = '_';
                  if (sptr < zptr) *sptr++ = 'P';
                  while (*cptr == '_' && sptr < zptr) *sptr++ = *cptr++;
                  continue;
               }
               if (sptr < zptr) *sptr++ = *cptr++;
            }
            if (sptr >= zptr)
            {
               UpdLayout[0] = '\0';
               ErrorGeneralOverflow (rqptr, FI_LI);
               UpdEnd (rqptr);
               return;
            }
            *sptr = '\0';
            if (Debug) fprintf (stdout, "UpdLayout |%s|\n", UpdLayout);
         }

         status = WriteFao (Location, sizeof(Location), &Length,
                            "!AZ//!AZ!UZ!UZ!AZ!UZ?httpd=index&expired=yes!AZ",
                            rqptr->ServicePtr->RequestSchemeNamePtr,
                            rqptr->ServicePtr->ServerHostPort,
                            rqptr->rqHeader.PathInfoPtr, Name,
                            Name[0] ? "/" : "",
                            AsName[0] ? AsName : "*.*",
                            UpdLayout);
      }
      else
      if (SubmitMkdir)
      {
         if (!AsName[0])
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_DIRECTORY), FI_LI);
            UpdEnd (rqptr);
            return;
         }
         status = WriteFao (Location, sizeof(Location), &Length,
                           "!UZ!UZ!UZ/?d-mkdir=1",
                           rqptr->ScriptName, rqptr->rqHeader.PathInfoPtr, AsName);
      }
      else
      if (SubmitFileRename)
      {
         if (!Name[0])
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_CUR_FILENAME), FI_LI);
            UpdEnd (rqptr);
            return;
         }
         if (!AsName[0])
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_NEW_FILENAME), FI_LI);
            UpdEnd (rqptr);
            return;
         }
         if (strsame (Name, AsName, -1))
         {
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_RENAME_SAME), FI_LI);
            UpdEnd (rqptr);
            return;
         }

         UpdConfirmRename (rqptr, Name, AsName);
         return;
      }
      else
      if (SubmitTree)
      {
         if (!Name[0] && !NameIsPeriod)
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_DIRECTORY), FI_LI);
            UpdEnd (rqptr);
            return;
         }
         status = WriteFao (Location, sizeof(Location), &Length,
                            "!UZ!UZ!UZ!AZ?d-tree=1",
                            rqptr->ScriptName, rqptr->rqHeader.PathInfoPtr, 
                            Name, Name[0] ? "/" : "");
      }
      else
      if (SubmitView)
      {
         if (!Name[0])
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_FILENAME), FI_LI);
            UpdEnd (rqptr);
            return;
         }
         status = WriteFao (Location, sizeof(Location), &Length,
                            "!AZ//!AZ!UZ!UZ",
                            rqptr->ServicePtr->RequestSchemeNamePtr,
                            rqptr->ServicePtr->ServerHostPort,
                            rqptr->rqHeader.PathInfoPtr, Name);
      }
      else
      {
         rqptr->rqResponse.HttpStatus = 400;
         ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_ACTION), FI_LI);
         UpdEnd (rqptr);
         return;
      }

      if (VMSnok (status) || status == SS$_BUFFEROVF)
      {
         ErrorNoticed (status, "WriteFao()", FI_LI);
         rqptr->rqResponse.ErrorTextPtr = "WriteFao()";
         ErrorVmsStatus (rqptr, status, FI_LI);
         UpdEnd (rqptr);
         return;
      }
      if (Debug) fprintf (stdout, "Location |%s|\n", Location);

      rqptr->rqResponse.LocationPtr = VmGetHeap (rqptr, Length+1);
      memcpy (rqptr->rqResponse.LocationPtr, Location, Length+1);

      if (WatchThisOne)
         WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                    "UPDATE !AZ !AZ", SubmitButton, Location);

      UpdEnd (rqptr);
      return;
   }

   /********************************/
   /* navigate, edit, copy, rename */
   /********************************/

   if (DoTree)
   {
      /********/
      /* tree */
      /********/

      if (WatchThisOne)
         WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                    "UPDATE treeof !AZ", rqptr->ParseOds.ExpFileName);

      /* remove the query string that got us here */
      rqptr->rqHeader.QueryStringPtr = "";

      rqptr->rqResponse.PreExpired = PRE_EXPIRE_UPD_TREE_OF;
      tkptr->UpdateTree = true;
      UpdTreeBegin (rqptr);
      return;
   }

   if (DoFileProtect || DoDirProtect)
   {
      /*********************/
      /* change protection */
      /*********************/

      /* this function supplies it's own watch response item */
      UpdProtection (rqptr);
      return;
   }

   if (DoFileRename)
   {
      /***************/
      /* file rename */
      /***************/

      /* this function supplies it's own watch response item */
      UpdFileRename (rqptr, Name, AsName);
      return;
   }

   if (DoCopy)
   {
      /********/
      /* copy */
      /********/

      /* this function supplies it's own watch response item */
      UpdCopyFileBegin (rqptr, AsName);
      return;
   }

   if (rqptr->ParseOds.Nam_fnb & NAM$M_WILDCARD)
      Navigate = true;
   else
   if (rqptr->ParseOds.NamNameLength ||
       rqptr->ParseOds.NamTypeLength ||
       rqptr->ParseOds.NamVersionLength)
      Navigate = false;
   else
      Navigate = true;

   if (Navigate)
   {
      /******************/
      /* let's navigate */
      /******************/

      /* this function supplies it's own watch response item */
      UpdNavigateBegin (rqptr);
      return;
   }

   /*****************/
   /* edit the file */
   /*****************/

   /* this function supplies it's own watch response item */
   UpdEditFileBegin (rqptr, AsName);
}

/*****************************************************************************/
/*
All requests processed by the UPD.C module should call this function at the
end of processing.
*/ 

UpdEnd (struct RequestStruct *rqptr)

{
   register struct UpdTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UpdEnd()\n");

   tkptr = rqptr->UpdTaskPtr;

   if (tkptr->FileOds.Fab.fab$w_ifi)
      OdsClose (&tkptr->FileOds, NULL, rqptr);

   /* ensure parse internal data structures are released */
   if (tkptr->FileOds.ParseInUse) OdsParseRelease (&tkptr->FileOds);
   if (tkptr->SearchOds.ParseInUse) OdsParseRelease (&tkptr->SearchOds);

   SysDclAst (tkptr->NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Begin by setting up a search for all directories.
*/

UpdNavigateBegin (struct RequestStruct *rqptr)

{
   register unsigned long  *vecptr;
   register char  *cptr, *sptr, *zptr;
   register struct UpdTaskStruct  *tkptr;

   int  status;
   unsigned short  Length;
   unsigned long  FaoVector [32];
   char  ch;
   char  Scratch [256];
   void  *AstFunctionPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UpdNavigateBegin()\n");

   tkptr = rqptr->UpdTaskPtr;

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_RESPONSE))
      WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                 "UPDATE navigate !AZ", rqptr->ParseOds.ExpFileName);

   if (!UpdProtectionList[0])
   {
      /***************************/
      /* initialize if necessary */
      /***************************/

      strcpy (cptr = Scratch, MsgFor (rqptr, MSG_UPD_PROTECTION_LIST));

      vecptr = FaoVector;
      *vecptr++ = cptr;
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) *cptr++ = '\0';
      *vecptr++ = cptr;
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) *cptr++ = '\0';
      *vecptr++ = cptr;

      status = WriteFaol (UpdProtectionList, sizeof(UpdProtectionList), NULL,
                          UpdProtectionListFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   /*****************************************/
   /* check VMS-authenticated user's access */
   /*****************************************/

   if (rqptr->rqAuth.VmsUserProfileLength)
   {
      status = AuthVmsCheckUserAccess (rqptr, rqptr->ParseOds.ExpFileName,
                                       rqptr->ParseOds.ExpFileNameLength);
      if (status == RMS$_PRV)
         tkptr->AuthVmsUserHasAccess = false;
      else
      if (VMSok (status))
         tkptr->AuthVmsUserHasAccess = true;
      else
      {
         /* error reported by access check */
         UpdEnd (rqptr);
         return;
      }
   }
   else
      tkptr->AuthVmsUserHasAccess = false;

   /************/
   /* navigate */
   /************/

   /* first check if the directory can be accessed */
   if (tkptr->AuthVmsUserHasAccess) EnableSysPrv();
   if (Config.cfDir.AccessSelective)
      status = OdsFileExists (rqptr->ParseOds.ExpFileName,
                              DirBrowsableFileName);
   else
   {
      if (VMSok (status =
          OdsFileExists (rqptr->ParseOds.ExpFileName, DirHiddenFileName)))
         status = RMS$_FNF;
      else
      if (VMSok (status =
          OdsFileExists (rqptr->ParseOds.ExpFileName, DirNoWildFileName)))
         status = RMS$_WLD;
      else
         status = SS$_NORMAL;
   }
   if (tkptr->AuthVmsUserHasAccess) DisableSysPrv();

   if (VMSnok (status))
   {
      /* give some "disinformation"  ;^)  */
      if (status == RMS$_FNF) status = RMS$_DNF;
      rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
      rqptr->rqResponse.ErrorOtherTextPtr = rqptr->ParseOds.ExpFileName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   /* check if we can see its subdirectories, if not then straight to files */

   if (tkptr->AuthVmsUserHasAccess) EnableSysPrv();

   if (VMSnok (status =
       OdsFileExists (rqptr->ParseOds.ExpFileName, DirNosFileName)))
      status = OdsFileExists (rqptr->ParseOds.ExpFileName, DirNopsFileName);

   if (tkptr->AuthVmsUserHasAccess) DisableSysPrv();

   if (VMSnok(status))
   {
      AstFunctionPtr = &UpdNavigateSearchDirs;

      /***************************/
      /* set up directory search */
      /***************************/

      if (tkptr->AuthVmsUserHasAccess) EnableSysPrv();
      OdsParse (&tkptr->SearchOds,
                rqptr->ParseOds.ExpFileName,
                rqptr->ParseOds.NamNamePtr - rqptr->ParseOds.ExpFileName,
                "*.DIR;", 6, 0, NULL, rqptr);
      if (tkptr->AuthVmsUserHasAccess) DisableSysPrv();

      if (VMSnok (status = tkptr->SearchOds.Fab.fab$l_sts))
      {
         rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
         rqptr->rqResponse.ErrorOtherTextPtr = rqptr->ParseOds.ExpFileName;
         ErrorVmsStatus (rqptr, status, FI_LI);
         UpdEnd (rqptr);
         return;
      }
   }
   else
      AstFunctionPtr = &UpdNavigateBeginFiles;

   /**************/
   /* begin page */
   /**************/

   cptr = MsgFor(rqptr,MSG_UPD_NAVIGATE);
   zptr = (sptr = tkptr->MsgString) + sizeof(tkptr->MsgString);
   while (*cptr && sptr < zptr)
   {
      /* don't need any extraneous linefeeds from this long string */
      if (*cptr == '\n') cptr++; else *sptr++ = *cptr++;
   }
   if (sptr >= zptr)
   {
      ErrorGeneralOverflow (rqptr, FI_LI);
      UpdEnd (rqptr);
      return;
   }
   *sptr = '\0';

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_UPD;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;

   *vecptr++ = HtmlMetaInfo (rqptr, rqptr->ParseOds.ExpFileName);

   /* "Update" */
   *vecptr++ = cptr = tkptr->MsgString;
   *vecptr++ = rqptr->ServicePtr->ServerHostPort;

   *vecptr++ = Config.cfServer.AdminBodyTag;

   /* "Update" again */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';
   *vecptr++ = rqptr->ServicePtr->ServerHostPort;

   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = rqptr->rqHeader.PathInfoPtr;

#ifdef ODS_EXTENDED
   if (OdsExtended)
   {
      if (rqptr->PathOds == 0 ||
          rqptr->PathOds == 2)
         *vecptr++ = "&nbsp;&nbsp;&nbsp;ODS-2";
      else
      if (rqptr->PathOds == 5)
         *vecptr++ = "&nbsp;&nbsp;&nbsp;ODS-5";
      else
         *vecptr++ = "ODS-?";
   }
   else
#endif /* ODS_EXTENDED */
      *vecptr++ = "";

   *vecptr++ = UPD_HELP_PATH;

   /* ["help"] */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* form action */
   *vecptr++ = rqptr->ScriptName;
   *vecptr++ = rqptr->rqHeader.PathInfoPtr;

   /* "subdirectories" title */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* save the current position for use in later parts of the page */
   tkptr->MsgStringPtr = cptr;

   *vecptr++ = NAVIGATE_SIZE;

   /* terminate the path string at the first character of any file name part */
   cptr = rqptr->rqHeader.PathInfoPtr + rqptr->rqHeader.PathInfoLength;
   while (cptr > rqptr->rqHeader.PathInfoPtr && *cptr != '/') cptr--;
   if (*cptr == '/')
   {
      ch = *++cptr;
      *cptr = '\0';
   }
   else
      cptr = NULL;

   status = NetWriteFaol (rqptr,
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>!AZ !AZ</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2>!AZ !AZ</H2>\n\
\
<P><TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1>\n\
\
<TR><TH COLSPAN=2>\n\
<FONT SIZE=+2><A HREF=\"!UF\">!UF</A></FONT>\n\
!AZ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n\
[<A HREF=\"!UF\">!UF</A>]\n\
</TH></TR>\n\
\
<TR>\n\
\
<TD VALIGN=top>\n\
<FORM METHOD=GET ACTION=\"!UF!UF\">\n\
<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=0>\n\
\
<TR><TH COLSPAN=2><FONT SIZE=+1><U>!AZ</U></FONT></TH></TR>\n\
\
<TR><TD VALIGN=top ALIGN=left>\n\
<SELECT SIZE=!UL NAME=name>\n\
<OPTION VALUE=\".\" SELECTED>./\n",
      &FaoVector);

   /* restore character */
   if (cptr != NULL) *cptr = ch;

   if (VMSnok (status))
   {
      ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      rqptr->rqResponse.ErrorTextPtr = "NetWriteFaol()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   tkptr->FileCount = 0;

   NetWritePartFlush (rqptr, AstFunctionPtr);
}

/*****************************************************************************/
/*
(AST) function to invoke another sys$search() call when listing directories.
*/ 

UpdNavigateSearchDirs (struct RequestStruct *rqptr)

{
   register struct UpdTaskStruct  *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NavigateSearchDirs()\n");

   /* get the pointer to the task structure */
   tkptr = rqptr->UpdTaskPtr;

   if (tkptr->AuthVmsUserHasAccess)
   {
      EnableSysPrv();
      OdsSearch (&tkptr->SearchOds, NULL, rqptr);
      DisableSysPrv();
      /* explicitly call the AST routine */
      UpdNavigateDirs (&tkptr->SearchOds.Fab);
      return;
   }

   OdsSearch (&tkptr->SearchOds, &UpdNavigateDirs, rqptr);
}

/*****************************************************************************/
/*
AST completion routine called each time sys$search() completes.  It will 
either point to another file name found or have "no more files found" status 
(or an error!).
*/ 

UpdNavigateDirs (struct FAB *FabPtr)

{
   register char  *cptr, *sptr;
   register struct RequestStruct  *rqptr;
   register struct UpdTaskStruct  *tkptr;

   int  status;
   char  ch;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
      "UpdNavigateDirs() sts: %%X%08.08X stv: %%X%08.08X\n",
      FabPtr->fab$l_sts, FabPtr->fab$l_stv);

   /* retrieve the pointer to the client thread from the FAB user context */
   rqptr = FabPtr->fab$l_ctx;
   /* get the pointer to the task structure */
   tkptr = rqptr->UpdTaskPtr;

   if (VMSnok (status = tkptr->SearchOds.Fab.fab$l_sts))
   {
      /* if its a search list treat directory not found as if file not found */
      if ((tkptr->SearchOds.Nam_fnb & NAM$M_SEARCH_LIST) && status == RMS$_DNF)
         status = RMS$_FNF;

      if (status == RMS$_FNF || status == RMS$_NMF)
      {
         /* end of directory search, list files */
         tkptr->SearchOds.ParseInUse = false;
         UpdNavigateBeginFiles (rqptr);
         return;
      }

      /* sys$search() error */
      rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->SearchOds.NamDevicePtr;
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   /* terminate following the last character in the version number */
   tkptr->SearchOds.NamVersionPtr[tkptr->SearchOds.NamVersionLength] = '\0';
   if (Debug) fprintf (stdout, "Dir |%s|\n", tkptr->SearchOds.ResFileName);

   if (!memcmp (tkptr->SearchOds.NamNamePtr, "000000.", 7))
   {
      /* not interested in master file directories :^) */
      UpdNavigateSearchDirs (rqptr);
      return;
   }

   tkptr->SearchOds.NamNamePtr[-1] = '.';
   tkptr->SearchOds.NamTypePtr[0] = ']';
   ch = tkptr->SearchOds.NamTypePtr[1];
   tkptr->SearchOds.NamTypePtr[1] = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", tkptr->SearchOds.ResFileName);

   if (tkptr->AuthVmsUserHasAccess) EnableSysPrv();

   if (Config.cfDir.AccessSelective)
      status = OdsFileExists (tkptr->SearchOds.ResFileName,
                              DirBrowsableFileName);
   else
   {
      if (VMSok (status =
          OdsFileExists (tkptr->SearchOds.ResFileName, DirHiddenFileName)))
         status = STS$K_ERROR;
      else
      if (status == RMS$_FNF)
         status = SS$_NORMAL;
   }

   if (tkptr->AuthVmsUserHasAccess) DisableSysPrv();

   tkptr->SearchOds.NamNamePtr[-1] = ']';
   tkptr->SearchOds.NamTypePtr[0] = '.';
   tkptr->SearchOds.NamTypePtr[1] = ch;

   if (VMSnok (status))
   {
      /* no, it shouldn't/couldn't be accessed */
      UpdNavigateSearchDirs (rqptr);
      return;
   }

   tkptr->FileCount++;

   tkptr->SearchOds.NamTypePtr[0] = '\0';

   status = NetWriteFao (rqptr, "<OPTION VALUE=\"!HF\">!%%\n",
                         tkptr->SearchOds.NamNamePtr,
                         rqptr->PathOdsExtended ? "!HZ" : "!HF",
                         tkptr->SearchOds.NamNamePtr);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   tkptr->SearchOds.NamTypePtr[0] = '.';

   NetWritePartFlush (rqptr, &UpdNavigateSearchDirs);
}

/*****************************************************************************/
/*
End directory search.  Begin file search.
*/

UpdNavigateBeginFiles (struct RequestStruct *rqptr)

{
   register unsigned long  *vecptr;
   register char  *cptr, *sptr, *zptr;
   register struct UpdTaskStruct  *tkptr;

   int  status;
   unsigned long  FaoVector [32];
   char  ch;
   char  *MsgFilesPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UpdNavigateBeginFiles()\n");

   tkptr = rqptr->UpdTaskPtr;

   if (tkptr->AuthVmsUserHasAccess) EnableSysPrv();
   OdsParse (&tkptr->SearchOds,
             rqptr->ParseOds.ExpFileName,
             rqptr->ParseOds.NamVersionPtr - rqptr->ParseOds.ExpFileName,
             "*.*;0", 5, 0, NULL, rqptr);
   if (tkptr->AuthVmsUserHasAccess) DisableSysPrv();

   if (VMSnok (status = tkptr->SearchOds.Fab.fab$l_sts))
   {
      rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
      rqptr->rqResponse.ErrorOtherTextPtr = rqptr->ParseOds.ExpFileName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   /**************/
   /* begin page */
   /**************/

   vecptr = FaoVector;

   /* retrieve the previously saved position in the string */
   cptr = tkptr->MsgStringPtr;

   /* "files" (for historical reasons is here) */
   MsgFilesPtr = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   if (tkptr->FileCount)
   {
      /* "select from list" */
      *vecptr++ = cptr;
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) *cptr++ = '\0';
      /* skip over "none available" */
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) cptr++;
   }
   else
   {
      /* skip over "select from list" */
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) cptr++;
      /* "none available" */
      *vecptr++ = cptr;
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) *cptr++ = '\0';
   }

   /* "enter name" */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* file protection */
   *vecptr++ = UpdProtectionList;

   /* reset */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* goto */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* list */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* tree */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* create */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* protection */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* delete */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* save the current position for use in later parts of the page */
   tkptr->MsgStringPtr = cptr;

   /* form action */
   *vecptr++ = rqptr->ScriptName;
   *vecptr++ = rqptr->rqHeader.PathInfoPtr;

   /* "files" title */
   *vecptr++ = MsgFilesPtr;

   *vecptr++ = NAVIGATE_SIZE;

   /* terminate the path string at the first character of any file name part */
   cptr = rqptr->rqHeader.PathInfoPtr + rqptr->rqHeader.PathInfoLength;
   while (cptr > rqptr->rqHeader.PathInfoPtr && *cptr != '/') cptr--;
   if (*cptr == '/')
   {
      ch = *++cptr;
      *cptr = '\0';
   }
   else
      cptr = NULL;

   status = NetWriteFaol (rqptr,
"</SELECT>\n\
<BR><SUP>1.</SUP> !AZ\n\
<BR><SUP>2.</SUP> !AZ\n\
<BR><INPUT TYPE=text NAME=as SIZE=20>\n\
<BR>!AZ\
<BR><INPUT TYPE=reset VALUE=\" !AZ \">\n\
</TD><TD ALIGN=left VALIGN=top>\n\
<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=0>\n\
<TR ALIGN=left><TD><INPUT TYPE=submit NAME=s-goto VALUE=\" !AZ \"></TD>\
<TD><SUP>1.</SUP></TD></TR>\n\
<TR ALIGN=left><TD><INPUT TYPE=submit NAME=s-list VALUE=\" !AZ \"></TD>\
<TD><SUP>1.</SUP></TD></TR>\n\
<TR ALIGN=left><TD><INPUT TYPE=submit NAME=s-tree VALUE=\" !AZ \"></TD>\
<TD><SUP>1.</SUP></TD></TR>\n\
<TR ALIGN=left><TD><INPUT TYPE=submit NAME=s-mkdir VALUE=\" !AZ \"></TD>\
<TD><SUP>2.</SUP></TD></TR>\n\
<TR ALIGN=left><TD><INPUT TYPE=submit NAME=s-dirprotect VALUE=\" !AZ \"></TD>\
<TD><SUP>1./2.</SUP></TD></TR>\n\
<TR ALIGN=left><TD><INPUT TYPE=submit NAME=s-rmdir VALUE=\" !AZ \"></TD>\
<TD><SUP>1.</SUP></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
</FORM>\n\
</TD>\n\
\
<TD VALIGN=top>\n\
\
<FORM METHOD=GET ACTION=\"!UF!UF\">\n\
<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=0>\n\
\
<TR><TH COLSPAN=2><FONT SIZE=+1><U>!AZ</U></FONT></TH></TR>\n\
\
<TR><TD VALIGN=top ALIGN=left>\n\
<SELECT SIZE=!UL NAME=name>\n",
      &FaoVector);

   /* restore character */
   if (cptr != NULL) *cptr = ch;

   if (VMSnok (status))
   {
      ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      rqptr->rqResponse.ErrorTextPtr = "NetWriteFaol()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   tkptr->FileCount = 0;

   NetWritePartFlush (rqptr, &UpdNavigateSearchFiles);
}

/*****************************************************************************/
/*
(AST) function to invoke another sys$search() call when listing Files.
*/ 

UpdNavigateSearchFiles (struct RequestStruct *rqptr)

{
   register struct UpdTaskStruct  *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UpdNavigateSearchFiles()\n");

   /* get the pointer to the task structure */
   tkptr = rqptr->UpdTaskPtr;

   if (tkptr->AuthVmsUserHasAccess)
   {
      EnableSysPrv();
      OdsSearch (&tkptr->SearchOds, NULL, rqptr);
      DisableSysPrv();
      /* explicitly call the AST routine */
      UpdNavigateFiles (&tkptr->SearchOds.Fab);
      return;
   }

   OdsSearch (&tkptr->SearchOds, &UpdNavigateFiles, rqptr);
}

/*****************************************************************************/
/*
AST completion routine called each time sys$search() completes.  It will 
either point to another file name found or have "no more files found" status 
(or an error!).
*/ 

UpdNavigateFiles (struct FAB *FabPtr)

{
   register char  *cptr, *sptr;
   register struct RequestStruct  *rqptr;
   register struct UpdTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
      "UpdNavigateFiles() sts: %%X%08.08X stv: %%X%08.08X\n",
      FabPtr->fab$l_sts, FabPtr->fab$l_stv);

   /* retrieve the pointer to the client thread from the FAB user context */
   rqptr = FabPtr->fab$l_ctx;
   /* get the pointer to the task structure */
   tkptr = rqptr->UpdTaskPtr;

   if (VMSnok (status = tkptr->SearchOds.Fab.fab$l_sts))
   {
      if (status == RMS$_FNF || status == RMS$_NMF)
      {
         /* end of file search */
         tkptr->SearchOds.ParseInUse = false;
         UpdNavigateEnd (rqptr);
         return;
      }

      /* sys$search() error */
      rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->SearchOds.NamDevicePtr;
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   /* terminate following the last character in the version number */
   tkptr->SearchOds.NamVersionPtr[tkptr->SearchOds.NamVersionLength] = '\0';
   if (Debug) fprintf (stdout, "File |%s|\n", tkptr->SearchOds.ResFileName);

   if (!memcmp (tkptr->SearchOds.NamTypePtr, ".DIR;", 5))
   {
      /* already have directories */
      UpdNavigateSearchFiles (rqptr);
      return;
   }

   if (*tkptr->SearchOds.NamNamePtr == '.')
   {
      /* "hidden" file, let it stay hidden */
      UpdNavigateSearchFiles (rqptr);
      return;
   }

   /* specially check permissions for each file! */
   status = AuthVmsCheckUserAccess (rqptr, tkptr->SearchOds.ResFileName,
                                           tkptr->SearchOds.ResFileNameLength);
   if (VMSnok (status))
   {
      if (status == RMS$_PRV)
      {
         /* does not have access */
         UpdNavigateSearchFiles (rqptr);
         return;
      }
      /* error reported by access check */
      UpdEnd (rqptr);
      return;
   }

   tkptr->FileCount++;

   tkptr->SearchOds.NamVersionPtr[0] = '\0';

   status = NetWriteFao (rqptr, "<OPTION VALUE=\"!HF\">!%%\n",
                         tkptr->SearchOds.NamNamePtr,
                         rqptr->PathOdsExtended ? "!HZ" : "!HF",
                         tkptr->SearchOds.NamNamePtr);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   tkptr->SearchOds.NamVersionPtr[0] = ';';

   NetWritePartFlush (rqptr, &UpdNavigateSearchFiles);
}

/*****************************************************************************/
/*
End file search and end of navigation functions.
*/

UpdNavigateEnd (struct RequestStruct *rqptr)

{
   register unsigned long  *vecptr;
   register char  *cptr;
   register struct UpdTaskStruct  *tkptr;

   int  status;
   unsigned long  FaoVector [32];
   char  *MsgAsPtr,
         *MsgLocalFilePtr,
         *MsgUploadPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UpdNavigateEnd()\n");

   tkptr = rqptr->UpdTaskPtr;

   /* retrieve the previously saved position in the string */
   cptr = tkptr->MsgStringPtr;

   /* for historical reasons "Upload", "As", "Local File" messages are here */
   MsgUploadPtr = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';
   MsgAsPtr = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';
   MsgLocalFilePtr = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   vecptr = FaoVector;

   if (tkptr->FileCount)
   {
      /* "select from list" */
      *vecptr++ = cptr;
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) *cptr++ = '\0';
      /* skip over "none available" */
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) cptr++;
   }
   else
   {
      /* skip over "select from list" */
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) cptr++;
      /* "none available" */
      *vecptr++ = cptr;
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) *cptr++ = '\0';
   }

   /* "enter name/path" */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* file protection */
   *vecptr++ = UpdProtectionList;

   /* "reset" */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* view */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* edit */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* create */
#ifdef UPD_CREATE
   *vecptr++ = cptr;
#endif /* UPD_CREATE */
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* filter */
#ifdef UPD_FILTER
   *vecptr++ = cptr;
#endif /* UPD_FILTER */
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* rename */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* copy */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* protection */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* delete */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* file upload */
   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = MsgUploadPtr;
   *vecptr++ = MsgAsPtr;
   *vecptr++ = UpdProtectionList;
   *vecptr++ = MsgLocalFilePtr;

   status = NetWriteFaol (rqptr,
"</SELECT>\n\
<BR><SUP>1.</SUP> !AZ\n\
<BR><SUP>2.</SUP> !AZ\n\
<BR><INPUT TYPE=text NAME=as SIZE=25>\n\
<BR>!AZ\
<BR><INPUT TYPE=reset VALUE=\" !AZ \">\n\
</TD><TD ALIGN=left VALIGN=top>\n\
<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=0>\n\
<TR ALIGN=left><TD><INPUT TYPE=submit NAME=s-view VALUE=\" !AZ \"></TD>\
<TD><SUP>1.</SUP></TD></TR>\n\
<TR ALIGN=left><TD><INPUT TYPE=submit NAME=s-edit VALUE=\" !AZ \"></TD>\
<TD><SUP>1.[&amp;2.]</SUP></TD></TR>\n"

#ifdef UPD_CREATE
"<TR ALIGN=left><TD><INPUT TYPE=submit NAME=s-create VALUE=\" !AZ \"></TD>\
<TD><SUP>2.</SUP></TD></TR>\n"
#endif /* UPD_CREATE */

#ifdef UPD_FILTER
"<TR ALIGN=left><TD><INPUT TYPE=submit NAME=s-filter VALUE=\" !AZ \"></TD>\
<TD><SUP>1.&amp;2.</SUP></TD></TR>\n"
#endif /* UPD_FILTER */

"<TR ALIGN=left><TD><INPUT TYPE=submit NAME=s-filerename VALUE=\" !AZ \"></TD>\
<TD><SUP>1.&amp;2.</SUP></TD></TR>\n\
<TR ALIGN=left><TD><INPUT TYPE=submit NAME=s-copy VALUE=\" !AZ \"></TD>\
<TD><SUP>1.&amp;2.</SUP></TD></TR>\n\
<TR ALIGN=left><TD><INPUT TYPE=submit NAME=s-fileprotect VALUE=\" !AZ \"></TD>\
<TD><SUP>1./2.</SUP></TD></TR>\n\
<TR ALIGN=left><TD><INPUT TYPE=submit NAME=s-delete VALUE=\" !AZ \"></TD>\
<TD><SUP>1./2.</SUP></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
</FORM>\n\
\
<NOBR>\n\
<P><FORM METHOD=POST ACTION=\"!UF\" ENCTYPE=\"multipart/form-data\">\n\
&nbsp;<INPUT TYPE=submit VALUE=\" !AZ \">\n\
!AZ <INPUT TYPE=text NAME=uploadfilename SIZE=25>\n\
<BR>&nbsp;!AZ\
<BR>&nbsp;!AZ <INPUT TYPE=file NAME=name SIZE=25>\n\
</FORM>\n\
</NOBR>\n\
</TD>\n\
\
</TR>\n\
</TABLE>\n\
\
</BODY>\n\
</HTML>\n",
      &FaoVector);

   if (VMSnok (status))
   {
      ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      rqptr->rqResponse.ErrorTextPtr = "NetWriteFaol()";
      ErrorVmsStatus (rqptr, status, FI_LI);
   }

   UpdEnd (rqptr);
}

/*****************************************************************************/
/*
Provide a directory tree display.  Provides two types of tree.  The first, an
update tree, where tree node selection opens a new directory update page. 
Second, a general directory tree, where selecting a tree node behaves as any
other directory URL (i.e. if a wildcard name.type;version is provided a listing
is produced, if none then any home page existing in the directory is returned,
else a directory listing, any query string supplied is reproduced in the tree
link paths).
*/

UpdTreeBegin (struct RequestStruct *rqptr)

{
   register unsigned long  *vecptr;
   register char  *cptr, *sptr, *zptr;
   register struct UpdTaskStruct  *tkptr;
   register struct UpdTreeStruct  *tnptr;

   int  status;
   unsigned long  FaoVector [32];
   char  NameBuffer [ODS_MAX_FILE_NAME_LENGTH+64+1],
         PathBuffer [ODS_MAX_FILE_NAME_LENGTH+64+1];
   void  *AstFunctionPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UpdTreeBegin()\n");

   tkptr = rqptr->UpdTaskPtr;

   /*****************************************/
   /* check VMS-authenticated user's access */
   /*****************************************/

   if (rqptr->rqAuth.VmsUserProfileLength)
   {
      status = AuthVmsCheckUserAccess (rqptr,
                                       rqptr->ParseOds.ExpFileName,
                                       rqptr->ParseOds.ExpFileNameLength);
      if (status == RMS$_PRV)
         tkptr->AuthVmsUserHasAccess = false;
      else
      if (VMSok (status))
         tkptr->AuthVmsUserHasAccess = true;
      else
      {
         /* error reported by access check */
         UpdEnd (rqptr);
         return;
      }
   }
   else
      tkptr->AuthVmsUserHasAccess = false;

   /************/
   /* traverse */
   /************/

   /* first check if the directory can be accessed */

   if (tkptr->AuthVmsUserHasAccess) EnableSysPrv();

   if (Config.cfDir.AccessSelective)
      status = OdsFileExists (rqptr->ParseOds.ExpFileName,
                              DirBrowsableFileName);
   else
   {
      if (VMSok (status = OdsFileExists (rqptr->ParseOds.ExpFileName,
                                         DirHiddenFileName)))
         status = STS$K_ERROR;
      else
      if (status == RMS$_FNF)
         status = SS$_NORMAL;
   }

   if (tkptr->AuthVmsUserHasAccess) DisableSysPrv();

   if (VMSnok (status))
   {
      /* give some "disinformation"  ;^)  */
      if (status == RMS$_FNF) status = RMS$_DNF;
      rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
      rqptr->rqResponse.ErrorOtherTextPtr = rqptr->ParseOds.ExpFileName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   /* allocate heap memory for the initial tree structure */
   if (Debug) fprintf (stdout, "tnptr from HEAP\n");
   tnptr = (struct UpdTreeStruct*)
      VmGetHeap (rqptr, sizeof(struct UpdTreeStruct));
   tnptr->PrevTreeNodePtr = tnptr->NextTreeNodePtr = NULL;
   tkptr->TreeHeadPtr = tkptr->TreeNodePtr = tnptr;

   /* check if we can see its subdirectories, if not then end */
   if (OdsFileExists (rqptr->ParseOds.ExpFileName,
                      DirNosFileName) == RMS$_FNF &&
       OdsFileExists (rqptr->ParseOds.ExpFileName,
                      DirNopsFileName) == RMS$_FNF)
   {
      AstFunctionPtr = &UpdTreeListDirs;

      /* transfer the VMS access information to the tree node */
      tnptr->AuthVmsUserHasAccess = tkptr->AuthVmsUserHasAccess;

      /***************************/
      /* set up directory search */
      /***************************/

      if (tkptr->AuthVmsUserHasAccess) EnableSysPrv();
      OdsParse (&tnptr->SearchOds,
                rqptr->ParseOds.ExpFileName,
                /* i.e. just the length of the dev:[dir] */
                rqptr->ParseOds.NamNamePtr - rqptr->ParseOds.ExpFileName,
                "*.DIR;", 6, 0, NULL, rqptr);
      if (tkptr->AuthVmsUserHasAccess) DisableSysPrv();

      if (VMSnok (status = tnptr->SearchOds.Fab.fab$l_sts))
      {
         rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
         rqptr->rqResponse.ErrorOtherTextPtr = rqptr->ParseOds.ExpFileName;
         ErrorVmsStatus (rqptr, status, FI_LI);
         UpdEnd (rqptr);
         return;
      }
   }
   else
      AstFunctionPtr = &UpdTreeEnd;

   /**************/
   /* begin page */
   /**************/

   zptr = (sptr = NameBuffer) + sizeof(NameBuffer)-1;
   cptr = rqptr->rqHeader.PathInfoPtr;
   while (*cptr && sptr < zptr) *sptr++ = *cptr++;
   if (sptr > NameBuffer && *(sptr-1) != '/')
   {
      /* look for the last directory delimitter (eliminate any name part) */
      sptr--;
      while (sptr > NameBuffer && *sptr != '/') sptr--;
      if (*sptr == '/') sptr++;
   }
   *sptr = '\0';

   /* get the length of all but the last directory element */
   if (sptr > NameBuffer) sptr--;
   while (sptr > NameBuffer && *sptr != '/') sptr--;
   if (sptr > NameBuffer) sptr--;
   while (sptr > NameBuffer && *sptr != '/') sptr--;
   tkptr->TreeIndent = sptr - NameBuffer + 3;
   if (Debug) fprintf (stdout, "TreeIndent: %d\n", tkptr->TreeIndent);

   if (tkptr->FormatTreeLikeVms)
   {
      strcpy (PathBuffer, NameBuffer);
      MapUrl_UrlToVms (PathBuffer, NameBuffer, sizeof(NameBuffer),
                       true, rqptr->PathOdsExtended);
   }

   if (Debug) fprintf (stdout, "NameBuffer |%s|\n", NameBuffer);

   zptr = (sptr = PathBuffer) + sizeof(PathBuffer)-1;
   if (tkptr->UpdateTree)
   {
      cptr = rqptr->ScriptName;
      while (*cptr && sptr < zptr) *sptr++ = *cptr++;
   }
   cptr = rqptr->rqHeader.PathInfoPtr;
   while (*cptr && sptr < zptr) *sptr++ = *cptr++;
   *sptr = '\0';

   if (Debug) fprintf (stdout, "PathBuffer |%s|\n", PathBuffer);

   /* "tree"s can have pre-expiry controlled from the query string */
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;

   *vecptr++ = HtmlMetaInfo (rqptr, rqptr->ParseOds.ExpFileName);

   if (tkptr->UpdateTree)
   {
      *vecptr++ = "Update";
      *vecptr++ = rqptr->ServicePtr->ServerHostPort;
      *vecptr++ = Config.cfServer.AdminBodyTag;
      *vecptr++ = "Update";
      *vecptr++ = rqptr->ServicePtr->ServerHostPort;
   }
   else
   {
      *vecptr++ = cptr = MsgFor(rqptr,MSG_DIR_TREE_OF);
      if (tkptr->FormatTreeLikeVms)
         *vecptr++ = NameBuffer;
      else
         *vecptr++ = rqptr->rqHeader.PathInfoPtr;
      *vecptr++ = Config.cfServer.AdminBodyTag;
      *vecptr++ = cptr;  /* "Tree Of" again! */
      if (tkptr->FormatTreeLikeVms)
         *vecptr++ = NameBuffer;
      else
         *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   }

   if (NameBuffer[0] && NameBuffer[1] && !tkptr->FormatTreeLikeVms)
      *vecptr++ = "/";
   else
      *vecptr++ = "";
   if (tkptr->UpdateTree)
   {
      *vecptr++ = PathBuffer;
      *vecptr++ = "";
      *vecptr++ = "";
   }
   else
   {
      *vecptr++ = PathBuffer;
      if (tkptr->UpdateTree)
      {
         *vecptr++ = "";
         *vecptr++ = "";
      }
      else
      {
         if (rqptr->rqHeader.QueryStringPtr[0])
            *vecptr++ = "?";
         else
            *vecptr++ = "";
         *vecptr++ = rqptr->rqHeader.QueryStringPtr;
      }
   }

   if (tkptr->FormatTreeLikeVms)
      *vecptr++ = "!#UV";
   else
      *vecptr++ = "!#UF";

   if (NameBuffer[0] && NameBuffer[1] && !tkptr->FormatTreeLikeVms)
   {
      *vecptr++ = strlen(NameBuffer)-2;
      *vecptr++ = NameBuffer+1;
      *vecptr++ = "/";
   }
   else
   {
      *vecptr++ = strlen(NameBuffer);
      *vecptr++ = NameBuffer;
      *vecptr++ = "";
   }

   status = NetWriteFaol (rqptr,
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>!AZ !HZ</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2>!AZ &nbsp;!HZ</H2>\n\
<HR SIZE=2 NOSHADE><P>\n\
<PRE>  !AZ<A HREF=\"!UF!AZ!AZ\"><B>!%%</B></A>!AZ\n",
      &FaoVector);

   if (VMSnok (status))
   {
      ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      rqptr->rqResponse.ErrorTextPtr = "NetWriteFaol()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   tkptr->TreeLevel = 0;

   NetWriteFullFlush (rqptr, AstFunctionPtr);
}

/*****************************************************************************/
/*
(AST) function to invoke another sys$search() call when listing directories.
*/ 

UpdTreeListDirs (struct RequestStruct *rqptr)

{
   register struct UpdTreeStruct  *tnptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UpdTreeListDirs()\n");

   /* get the pointer to the tree structure */
   tnptr = rqptr->UpdTaskPtr->TreeNodePtr;

   if (tnptr->AuthVmsUserHasAccess)
   {
      EnableSysPrv();
      OdsSearch (&tnptr->SearchOds, NULL, rqptr);
      DisableSysPrv();
      /* explicitly call the AST routine */
      UpdTreeDirs (&tnptr->SearchOds.Fab);
      return;
   }

   OdsSearch (&tnptr->SearchOds, &UpdTreeDirs, rqptr);
}

/*****************************************************************************/
/*
AST completion routine called each time sys$search() completes.  It will 
either point to another dir name found or have "no more files found" status 
(or an error!).
*/ 

UpdTreeDirs (struct FAB *FabPtr)

{
   register unsigned long  *vecptr;
   register char  *cptr, *sptr, *tptr, *zptr;
   register struct RequestStruct  *rqptr;
   register struct UpdTaskStruct  *tkptr;
   register struct UpdTreeStruct  *tnptr,
                                  *tmptnptr;

   boolean  VmsUserHasAccess;
   int  status,
        cnt;
   unsigned long  FaoVector [32];
   char  ch;
   char  Buffer [2048],
         NameBuffer [ODS_MAX_FILE_NAME_LENGTH+64+1],
         PathBuffer [ODS_MAX_FILE_NAME_LENGTH+64+1],
         NestingBuffer [512];
   struct UpdTreeStruct  *NextTreeNodePtr,
                         *PrevTreeNodePtr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
      "UpdTreeDirs() sts: %%X%08.08X stv: %%X%08.08X\n",
      FabPtr->fab$l_sts, FabPtr->fab$l_stv);

   rqptr = FabPtr->fab$l_ctx;
   tkptr = rqptr->UpdTaskPtr;
   tnptr = tkptr->TreeNodePtr;

   if (VMSnok (status = tnptr->SearchOds.Fab.fab$l_sts))
   {
      if (status == RMS$_FNF || status == RMS$_NMF)
      {
         /* end of directory search, nest back one level or end */
         tnptr->SearchOds.ParseInUse = false;
         tkptr->TreeLevel--;
         if (tnptr->PrevTreeNodePtr != NULL)
         {
            tkptr->TreeNodePtr = tnptr->PrevTreeNodePtr;
            UpdTreeListDirs (rqptr);
         }
         else
            UpdTreeEnd (rqptr);
         return;
      }

      /* sys$search() error */
      rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
      rqptr->rqResponse.ErrorOtherTextPtr = tnptr->SearchOds.NamDevicePtr;
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdTreeEnd (rqptr);
      return;
   }

   /* terminate following the last character in the version number */
   tnptr->SearchOds.NamVersionPtr[tnptr->SearchOds.NamVersionLength] = '\0';
   if (Debug)
      fprintf (stdout, "Directory |%s|\n", tnptr->SearchOds.ResFileName);

   if (!memcmp (tnptr->SearchOds.NamNamePtr, "000000.", 7))
   {
      /* not interested in master file directories :^) */
      UpdTreeListDirs (rqptr);
      return;
   }

   /* check permissions for each directory */
   status = AuthVmsCheckUserAccess (rqptr,
                                    tnptr->SearchOds.ResFileName,
                                    tnptr->SearchOds.ResFileNameLength);
   if (VMSnok (status))
   {
      if (status == RMS$_PRV && Config.cfDir.NoPrivIgnore)
      {
         /* does not have access, as if it didn't exist! */
         UpdTreeListDirs (rqptr);
         return;
      }
      /* error reported by access check */
      UpdTreeEnd (rqptr);
      return;
   }

   if (rqptr->rqAuth.VmsUserProfileLength) VmsUserHasAccess = true;

   /************/
   /* continue */
   /************/

   /* first check if the directory can be accessed */

   tnptr->SearchOds.NamNamePtr[-1] = '.';
   tnptr->SearchOds.NamTypePtr[0] = ']';
   ch = tnptr->SearchOds.NamTypePtr[1];
   tnptr->SearchOds.NamTypePtr[1] = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", tnptr->SearchOds.ResFileName);

   if (VmsUserHasAccess) EnableSysPrv();

   if (Config.cfDir.AccessSelective)
      status = OdsFileExists (tnptr->SearchOds.ResFileName,
                              DirBrowsableFileName);
   else
   {
      if (VMSok (status =
          OdsFileExists (tnptr->SearchOds.ResFileName, DirHiddenFileName)))
         status = STS$K_ERROR;
      else
      if (status == RMS$_FNF)
         status = SS$_NORMAL;
   }

   if (VmsUserHasAccess) DisableSysPrv();

   tnptr->SearchOds.NamNamePtr[-1] = ']';
   tnptr->SearchOds.NamTypePtr[0] = '.';
   tnptr->SearchOds.NamTypePtr[1] = ch;

   if (VMSnok (status))
   {
      /* no, it can't be accessed */
      UpdTreeListDirs (rqptr);
      return;
   }

   /*********************/
   /* new level of tree */
   /*********************/

   if (tnptr->NextTreeNodePtr == NULL)
   {
      /* allocate heap memory for the new (nested) tree task structure */
      if (Debug) fprintf (stdout, "tnptr from HEAP\n");
      tnptr = (struct UpdTreeStruct*)
         VmGetHeap (rqptr, sizeof(struct UpdTreeStruct));
      tnptr->PrevTreeNodePtr = tkptr->TreeNodePtr;
      tnptr->PrevTreeNodePtr->NextTreeNodePtr = tnptr;
      tnptr->NextTreeNodePtr = NULL;
      
      /* transfer the VMS access information to the tree node */
      tnptr->AuthVmsUserHasAccess = VmsUserHasAccess;
   }
   else
   {
      /* reuse previously allocated structure */
      if (Debug) fprintf (stdout, "REUSE tnptr\n");
      tnptr = tnptr->NextTreeNodePtr;
      NextTreeNodePtr = tnptr->NextTreeNodePtr;
      PrevTreeNodePtr = tnptr->PrevTreeNodePtr;
      memset (tnptr, 0, sizeof(struct UpdTreeStruct));
      tnptr->NextTreeNodePtr = NextTreeNodePtr;
      tnptr->PrevTreeNodePtr = PrevTreeNodePtr;

      /* tranfer the VMS access information to the tree node */
      tnptr->AuthVmsUserHasAccess = VmsUserHasAccess;
   }
   tkptr->TreeNodePtr = tnptr;

   tkptr->TreeLevel++;

   sptr = tnptr->FileName;
   for (cptr = tnptr->PrevTreeNodePtr->SearchOds.ResFileName;
        cptr < tnptr->PrevTreeNodePtr->SearchOds.NamNamePtr;
        *sptr++ = *cptr++);
   sptr[-1] = '.';
   while (cptr < tnptr->PrevTreeNodePtr->SearchOds.NamTypePtr)
      *sptr++ = *cptr++;
   *sptr++ = ']';
   *sptr = '\0';
   tnptr->FileNameLength = sptr - tnptr->FileName;
   if (Debug)
      fprintf (stdout, "%d |%s|\n", tnptr->FileNameLength, tnptr->FileName);

   /***************************/
   /* set up directory search */
   /***************************/

   if (tkptr->AuthVmsUserHasAccess) EnableSysPrv();
   OdsParse (&tnptr->SearchOds,
             tnptr->FileName, tnptr->FileNameLength, "*.DIR;", 6,
             0, NULL, rqptr);
   if (tkptr->AuthVmsUserHasAccess) DisableSysPrv();

   if (VMSnok (status = tnptr->SearchOds.Fab.fab$l_sts))
   {
      if (Debug) fprintf (stdout, "OdsParse() %%X%08.08X\n", status);
      rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
      rqptr->rqResponse.ErrorOtherTextPtr = tnptr->FileName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   /**************************/
   /* display this directory */
   /**************************/

   zptr = (sptr = NameBuffer) + sizeof(NameBuffer)-1;
   cptr = tnptr->PrevTreeNodePtr->SearchOds.NamNamePtr;
   tptr = tnptr->PrevTreeNodePtr->SearchOds.NamTypePtr;
   while (*cptr && cptr < tptr && sptr < zptr) *sptr++ = *cptr++;
   *sptr = '\0';
   if (Debug) fprintf (stdout, "NameBuffer |%s|\n", NameBuffer);

   zptr = (sptr = PathBuffer) + sizeof(PathBuffer)-1;
   if (tkptr->UpdateTree)
   {
      cptr = rqptr->ScriptName;
      while (*cptr && sptr < zptr) *sptr++ = *cptr++;
   }
   cptr = rqptr->rqHeader.PathInfoPtr;
   while (*cptr && sptr < zptr) *sptr++ = *cptr++;
   if (sptr > PathBuffer && *(sptr-1) != '/')
   {
      /* look for the last directory delimitter (eliminate name part) */
      sptr--;
      while (sptr > PathBuffer && *sptr != '/') sptr--;
      if (*sptr == '/') sptr++;
   }

   /* add the name of all the directories to the link path */
   tmptnptr = tkptr->TreeHeadPtr;
   while (tmptnptr != tnptr)
   {
      cptr = tmptnptr->SearchOds.NamNamePtr;
      tptr = tmptnptr->SearchOds.NamTypePtr;
      if (rqptr->PathOdsExtended && tkptr->FormatTreeLikeVms)
         while (*cptr && cptr < tptr && sptr < zptr) *sptr++ = *cptr++;
      else
         while (*cptr && cptr < tptr && sptr < zptr) *sptr++ = tolower(*cptr++);
      if (sptr < zptr) *sptr++ = '/';
      tmptnptr = tmptnptr->NextTreeNodePtr;
   }
   *sptr = '\0';

   if (Debug) fprintf (stdout, "PathBuffer |%s|\n", PathBuffer);

   /* indent tree diagram using spaces, '|' and '-' */
   zptr = (sptr = NestingBuffer) + sizeof(NestingBuffer)-1;
   for (cnt = tkptr->TreeIndent; cnt && sptr < zptr; cnt--) *sptr++ = ' ';
   for (cnt = tkptr->TreeLevel-1; cnt && sptr < zptr; cnt--)
      for (cptr = "|   "; *cptr && sptr < zptr; *sptr++ = *cptr++);
   for (cptr = "|---"; *cptr && sptr < zptr; *sptr++ = *cptr++);
   *sptr = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", NestingBuffer);

   vecptr = FaoVector;

   *vecptr++ = NestingBuffer;
   if (tkptr->FormatTreeLikeVms)
      *vecptr++ = "!UV!UV";
   else
      *vecptr++ = "!UF!UF";
   *vecptr++ = PathBuffer;
   *vecptr++ = rqptr->ParseOds.NamNamePtr;

   if (rqptr->rqHeader.QueryStringPtr[0])
   {
      *vecptr++ = "?!AZ";
      *vecptr++ = rqptr->rqHeader.QueryStringPtr;
   }
   else
      *vecptr++ = "";

   if (tkptr->FormatTreeLikeVms)
      *vecptr++ = "!HZ";
   else
      *vecptr++ = "!UF";

   *vecptr++ = NameBuffer;

   status = NetWriteFaol (rqptr, "!AZ<A HREF=\"!%%!%%\">!%%</A>\n",
                          &FaoVector);
   if (VMSnok (status))
   {
      ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      NetWriteFaol (rqptr, "\n<FONT COLOR=\"#ff0000\">[Error]</FONT>\n", NULL);
   }

   NetWritePartFlush (rqptr, &UpdTreeListDirs);
}

/*****************************************************************************/
/*
*/ 

UpdTreeEnd (struct RequestStruct *rqptr)

{
   static char  TreeEndFao [] =
"</PRE>\n\
<P><HR SIZE=2 NOSHADE>\n\
</BODY>\n\
</HTML>\n";

   register struct UpdTaskStruct  *tkptr;
   register struct UpdTreeStruct  *tnptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UpdTreeEnd()\n");

   /* get the pointer to the task structure */
   tkptr = rqptr->UpdTaskPtr;
   /* get the pointer to the tree structure */
   tnptr = tkptr->TreeNodePtr;

   while (tnptr->PrevTreeNodePtr != NULL)
   {
      /* ensure parse internal data structures are released */
      OdsParseRelease (&tnptr->SearchOds);
      /* get any previous node */
      tnptr = tnptr->PrevTreeNodePtr;
   }

   status = NetWriteFaol (rqptr, TreeEndFao, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   UpdEnd (rqptr);
}

/*****************************************************************************/
/*
Generate a file editing page.  This comprises an HTTP response header.  Open
the file.  This checks whether it is an update (file exists) or create (file
does not exist).  Generate an HTML page and the start of a text area widget.
Then initiate the file records being read, to be included within the
<TEXTAREA></TEXTAREA> tags.
*/

UpdEditFileBegin
(
struct RequestStruct *rqptr,
char* AsName
)
{
   static $DESCRIPTOR (BytesFaoDsc, " <NOBR>(!UL bytes)</NOBR>\0");
   static $DESCRIPTOR (DayDateFaoDsc, "!AZ, !20%D\0");
   static $DESCRIPTOR (OutputFormatDsc, "|!WC, !DB-!MAAU-!Y4|!H04:!M0:!S0|");
   static $DESCRIPTOR (NewFileFaoDsc, "<FONT COLOR=\"#ff0000\">!AZ</FONT>\0");

   register unsigned long  *vecptr;
   register char  *cptr, *sptr, *zptr;
   register struct UpdTaskStruct  *tkptr;

   boolean  ConfigurationEdit,
            FileExists,
            SpecialCaseConfig,
            SpecialCaseMessages,
            SpecialCasePaths,
            SpecialCaseRules,
            SpecialCaseServices,
            SpecialCaseSiteLog;
   int  status,
        ByteCount,
        RevDayOfWeek;
   unsigned long  DateLength;
   unsigned long  FaoVector [32];
   char  *ContentTypePtr,
         *FileNamePtr,
         *HtmlTemplatePtr,
         *TitlePtr;
   char  Bytes [32],
         DayDate [128],
         PostPath [ODS_MAX_FILE_NAME_LENGTH+1],
         SiteLogEntry [256],
         Source [1024];
   void  *AstFunctionPtr;
   $DESCRIPTOR (BytesDsc, Bytes);
   $DESCRIPTOR (DayDateDsc, DayDate);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UpdEditFileBegin() |%s|\n", AsName);

   tkptr = rqptr->UpdTaskPtr;

   SpecialCaseConfig = ConfigurationEdit = SpecialCaseMessages =
      SpecialCasePaths = SpecialCaseRules = SpecialCaseSiteLog = false;
   TitlePtr = "";
   SiteLogEntry[0] = '\0';

   if ((SpecialCaseConfig =
        strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REVISE_CONFIG, -1)) ||
       (SpecialCaseMessages =
        strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REVISE_MESSAGES, -1)) ||
       (SpecialCasePaths =
        strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REVISE_AUTH_PATHS, -1)) ||
       (SpecialCaseRules =
        strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REVISE_MAPPING, -1)) ||
       (SpecialCaseServices =
        strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REVISE_SERVICES, -1)) ||
       (SpecialCaseSiteLog =
        strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REVISE_SITELOG, -1)))
   {
      /*****************/
      /* special cases */
      /*****************/

      if (SpecialCaseConfig)
      {
         FileNamePtr = CONFIG_FILE_NAME;
         TitlePtr = "<H3>Edit Server Configuration File</H3>\n";
         ConfigurationEdit = true;
      }
      else
      if (SpecialCaseMessages)
      {
         FileNamePtr = CONFIG_MSG_FILE_NAME;
         TitlePtr = "<H3>Edit Message File</H3>\n";
         ConfigurationEdit = true;
      }
      else
      if (SpecialCasePaths)
      {
         FileNamePtr = CONFIG_AUTH_FILE_NAME;
         TitlePtr = "<H3>Edit Path Authorization File</H3>\n";
         ConfigurationEdit = true;
      }
      else
      if (SpecialCaseRules)
      {
         FileNamePtr = CONFIG_MAP_FILE_NAME;
         TitlePtr = "<H3>Edit Mapping Rule File</H3>\n";
         ConfigurationEdit = true;
      }
      else
      if (SpecialCaseServices)
      {
         FileNamePtr = CONFIG_SERVICE_FILE_NAME;
         TitlePtr = "<H3>Edit Service Configuration File</H3>\n";
         ConfigurationEdit = true;
      }
      else
      if (SpecialCaseSiteLog)
      {
         if (getenv (CONFIG_SITELOG_FILE_NAME) == NULL)
            FileNamePtr = DEFAULT_SITELOG_FILE_NAME;
         else
            FileNamePtr = CONFIG_SITELOG_FILE_NAME;
         TitlePtr = "<H3>Edit Site Log</H3>\n";

         if (AsName[0])
         {
            vecptr = FaoVector;
            *vecptr++ = &rqptr->rqTime.Vms64bit;
            *vecptr++ = rqptr->RemoteUser;
            *vecptr++ = rqptr->rqAuth.RealmDescrPtr;
            *vecptr++ = rqptr->rqNet.ClientHostName;
            *vecptr++ = strlen(rqptr->RemoteUser) +
                        strlen(rqptr->rqAuth.RealmDescrPtr) +
                        strlen(rqptr->rqNet.ClientHostName) + 5;
            status = WriteFaol (SiteLogEntry, sizeof(SiteLogEntry), NULL,
                        "+!79*-\n+ !17%W\n+ !HZ.\'!HZ\'@!HZ\n+!#*-\n\n\n\n",
                        &FaoVector);
            if (VMSnok (status)) ErrorNoticed (status, "WriteFaol()", FI_LI);
         }

         ConfigurationEdit = true;
      }
      else
      {
         ErrorInternal (rqptr, 0, ErrorSanityCheck, FI_LI);
         UpdEnd (rqptr);
         return;
      }

      if (rqptr->WatchItem &&
          (WatchEnabled & WATCH_RESPONSE))
         WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                    "UPDATE edit !AZ", FileNamePtr);

      /*******************/
      /* parse file name */
      /*******************/

      if (tkptr->AuthVmsUserHasAccess) EnableSysPrv();
      OdsParse (&tkptr->SearchOds, FileNamePtr, strlen(FileNamePtr),
                NULL, 0, NAM$M_SYNCHK, NULL, rqptr);
      if (tkptr->AuthVmsUserHasAccess) DisableSysPrv();

      if (VMSnok (status = tkptr->SearchOds.Fab.fab$l_sts))
      {
         rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
         ErrorVmsStatus (rqptr, status, FI_LI);
         UpdEnd (rqptr);
         return;
      }

      if (VMSnok (status = OdsParseTerminate (&tkptr->SearchOds)))
      {
         ErrorNoticed (status, "OdsParseTerminate()", FI_LI);
         UpdEnd (rqptr);
         return;
      }

      /**********************/
      /* check content type */
      /**********************/

      ContentTypePtr = ConfigContentType (NULL, tkptr->SearchOds.NamTypePtr);
      if (!ConfigSameContentType (ContentTypePtr, "text/", 5))
      {
         rqptr->rqResponse.HttpStatus = 400;
         ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_NOT_TEXT_FILE), FI_LI);
         UpdEnd (rqptr);
         return;
      }

      /*************/
      /* open file */
      /*************/

      EnableSysPrv();
      OdsOpen (&tkptr->FileOds,
               tkptr->SearchOds.ExpFileName, tkptr->SearchOds.ExpFileNameLength,
               NULL, 0, 0, FAB$M_GET, FAB$M_SHRGET, NULL, rqptr);  
      DisableSysPrv();
   }
   else
   {
      /*****************************************/
      /* check VMS-authenticated user's access */
      /*****************************************/

      if (rqptr->WatchItem &&
          (WatchEnabled & WATCH_RESPONSE))
         WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                    "UPDATE edit !AZ", rqptr->ParseOds.ExpFileName);

      if (rqptr->rqAuth.VmsUserProfileLength)
      {
         /* from the request file parse */
         status = AuthVmsCheckUserAccess (rqptr, rqptr->ParseOds.ExpFileName,
                                          rqptr->ParseOds.ExpFileNameLength);
         if (status == RMS$_PRV)
            tkptr->AuthVmsUserHasAccess = false;
         else
         if (VMSok (status))
            tkptr->AuthVmsUserHasAccess = true;
         else
         {
            /* error reported by access check */
            UpdEnd (rqptr);
            return;
         }
      }
      else
         tkptr->AuthVmsUserHasAccess = false;

      /**********************/
      /* check content type */
      /**********************/

      /* from the request file parse */
      ContentTypePtr = ConfigContentType (NULL, rqptr->ParseOds.NamTypePtr);
      if (!ConfigSameContentType (ContentTypePtr, "text/", 5))
      {
         rqptr->rqResponse.HttpStatus = 400;
         ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_NOT_TEXT_FILE), FI_LI);
         UpdEnd (rqptr);
         return;
      }

      /*************/
      /* open file */
      /*************/

      FileNamePtr = rqptr->ParseOds.ExpFileName;

      if (tkptr->AuthVmsUserHasAccess) EnableSysPrv();
      OdsOpen (&tkptr->FileOds,
               rqptr->ParseOds.ExpFileName, rqptr->ParseOds.ExpFileNameLength,
               NULL, 0, 0, FAB$M_GET, FAB$M_SHRGET, NULL, rqptr);  
      if (tkptr->AuthVmsUserHasAccess) DisableSysPrv();
   }

   /************/
   /* continue */
   /************/

   status = tkptr->FileOds.Fab.fab$l_sts;
   if (VMSnok (status) && status != RMS$_FNF)
   {
      rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
      rqptr->rqResponse.ErrorOtherTextPtr = FileNamePtr;
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   if (status == RMS$_FNF)
      FileExists = tkptr->RecordFormatFixed = false;
   else
   {
      FileExists = true;
      if (tkptr->FileOds.Fab.fab$b_rfm == FAB$C_FIX ||
          tkptr->FileOds.Fab.fab$b_rfm == FAB$C_UDF)
         tkptr->RecordFormatFixed = true;
      else
         tkptr->RecordFormatFixed = false;
   }

   if (VMSnok (status = OdsParseTerminate (&tkptr->FileOds)))
   {
      ErrorNoticed (status, "OdsParseTerminate()", FI_LI);
      UpdEnd (rqptr);
      return;
   }

   if (FileExists)
   {
      /* record access block */
      tkptr->FileOds.Rab = cc$rms_rab;
      tkptr->FileOds.Rab.rab$l_ctx = rqptr;
      tkptr->FileOds.Rab.rab$l_fab = &tkptr->FileOds.Fab;
      /* 2 buffers, transfer 6 blocks */
      tkptr->FileOds.Rab.rab$b_mbc = 6;
      tkptr->FileOds.Rab.rab$b_mbf = 2;
      /* read ahead performance option */
      tkptr->FileOds.Rab.rab$l_rop = RAB$M_RAH;
      tkptr->FileOds.Rab.rab$l_ubf = tkptr->EditBuffer;
      /* allow for two extra characters, a newline and a terminating null */
      tkptr->FileOds.Rab.rab$w_usz = sizeof(tkptr->EditBuffer)-2;

      status = sys$connect (&tkptr->FileOds.Rab, 0, 0);
      if (Debug) fprintf (stdout, "sys$connect() %%X%08.08X\n", status);
      if (VMSnok (status))
      {
         rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
         rqptr->rqResponse.ErrorOtherTextPtr = FileNamePtr;
         ErrorVmsStatus (rqptr, status, FI_LI);
         UpdEnd (rqptr);
         return;
      }
   }

   /**************/
   /* begin page */
   /**************/

   if (!ConfigurationEdit)
   {
      cptr = MsgFor(rqptr,MSG_UPD_EDIT);
      zptr = (sptr = tkptr->MsgString) + sizeof(tkptr->MsgString);
      while (*cptr && sptr < zptr)
      {
         /* don't need any extraneous linefeeds from this long string */
         if (*cptr == '\n')
            cptr++;
         else
            *sptr++ = *cptr++;
      }
      if (sptr >= zptr)
      {
         ErrorGeneralOverflow (rqptr, FI_LI);
         UpdEnd (rqptr);
         return;
      }
      *sptr = '\0';

      /* "Start at the very beginning, very good place to start ..." */
      tkptr->MsgStringPtr = tkptr->MsgString;
   }

   if (FileExists)
   {
      if (ConfigurationEdit || NaturalLanguageEnglish)
      {
         lib$day_of_week (&tkptr->FileOds.XabDat.xab$q_rdt, &RevDayOfWeek);
         sys$fao (&DayDateFaoDsc, 0, &DayDateDsc,
                  DayName[RevDayOfWeek], &tkptr->FileOds.XabDat.xab$q_rdt);
      }
      else
      {
         static unsigned long  LibDateTimeContext = 0,
                               LibOutputFormat = LIB$K_OUTPUT_FORMAT;

         if (!LibDateTimeContext)
         {
            /* initialize this particular date/time format */
            if (VMSnok (status =
               lib$init_date_time_context (&LibDateTimeContext,
                                           &LibOutputFormat,
                                           &OutputFormatDsc)))
            {
               rqptr->rqResponse.ErrorTextPtr = "lib$init_date_time_context()";
               ErrorVmsStatus (rqptr, status, FI_LI);
               UpdEnd (rqptr);
               return;
            }
         }

         if (VMSnok (status =
             lib$format_date_time (&DayDateDsc,
                                   &tkptr->FileOds.XabDat.xab$q_rdt,
                                   &LibDateTimeContext, &DateLength, 0)))
         {
            if (status != LIB$_ENGLUSED)
            {
               rqptr->rqResponse.ErrorTextPtr = "lib$format_date_time()";
               ErrorVmsStatus (rqptr, status, FI_LI);
               UpdEnd (rqptr);
               return;
            }
         }
         DayDate[DateLength] = '\0';
      }

      /* true for non-VAR record formats, almost true for those :^) */
      if (tkptr->FileOds.XabFhc.xab$l_ebk)
         ByteCount = ((tkptr->FileOds.XabFhc.xab$l_ebk - 1) * 512) +
                     tkptr->FileOds.XabFhc.xab$w_ffb;
      else
         ByteCount = tkptr->FileOds.XabFhc.xab$w_ffb;
      sys$fao (&BytesFaoDsc, 0, &BytesDsc, ByteCount);

      if (!ConfigurationEdit)
      {
         /* retrieve the previously saved position in the string */
         cptr = tkptr->MsgStringPtr;
         /* step over "New Document" */
         while (*cptr && *cptr != '|') cptr++;
         if (*cptr) cptr++;
        /* save the current position for use in later parts of the page */
        tkptr->MsgStringPtr = cptr;
     }
   }
   else
   {
      if (ConfigurationEdit)
         sptr = "New File";
      else
      {
         /* "New Document" */
         sptr = cptr = tkptr->MsgStringPtr;
         while (*cptr && *cptr != '|') cptr++;
         if (*cptr) *cptr++ = '\0';
         /* save the current position for use in later parts of the page */
         tkptr->MsgStringPtr = cptr;
      }

      if (VMSnok (status = sys$fao (&NewFileFaoDsc, 0, &DayDateDsc, sptr)))
         strcpy (DayDate, "New File");

      Bytes[0] = '\0';
   }

   if (ConfigurationEdit)
   {
      /* generate a URL-style version of the VMS specification */
      MapUrl_VmsToUrl (PostPath, tkptr->FileOds.NamDevicePtr,
                       sizeof(PostPath), true, false);
   }
   else
   {
      /* remove any explicit version from the path to be POSTed */
      zptr = (sptr = PostPath) + sizeof(PostPath);
      for (cptr = rqptr->rqHeader.PathInfoPtr; *cptr && sptr < zptr; *sptr++ = *cptr++);
      if (AsName[0] && sptr < zptr)
      {
         /* eliminate the trailing file name */
         while (sptr > PostPath && *sptr != '/') sptr--;
         if (*sptr == '/') sptr++;
         /* add the destination file name */
         for (cptr = AsName; *cptr && sptr < zptr; *sptr++ = *cptr++);
      }
      if (sptr >= zptr)
      {
         ErrorGeneralOverflow (rqptr, FI_LI);
         UpdEnd (rqptr);
         return;
      }
      *sptr = '\0';
   }
   if (Debug) fprintf (stdout, "PostPath |%s|\n", PostPath);

   if (ConfigurationEdit)
   {
      /**************************************************/
      /* editing a configuration file from server admin */
      /**************************************************/

      vecptr = FaoVector;

      if (ConfigurationEdit)
         *vecptr++ = tkptr->FileOds.NamDevicePtr;
      else
         *vecptr++ = PostPath;
      *vecptr++ = PostPath;
      *vecptr++ = DayDate;

      if (AsName[0])
         *vecptr++ = "Save As";
      else
      if (FileExists)
         *vecptr++ = "Update";
      else
         *vecptr++ = "Create";

      status = WriteFaol (Source, sizeof(Source), NULL,
"<P><TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Source: &quot;File&quot;</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=RIGHT>File:</TH>\
<TD ALIGN=LEFT>!UZ</TD>\
<TD>&nbsp;</TD><TH>[<A HREF=\"!UZ\">View</A>]</TH></TR>\n\
<TR><TH ALIGN=RIGHT>Revised:</TH><TD ALIGN=LEFT>!AZ</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n",
         &FaoVector);

      /* the administration menus, etc. are always in English (for now!) */
      strcpy (tkptr->MsgStringPtr = tkptr->MsgString,
      "Update|Save As|Update|Create|Preview|Undo Editing|Change Edit Window");
   }
   else
   {
      /******************************/
      /* editing any other document */
      /******************************/

      /* retrieve the previously saved position in the string */
      cptr = tkptr->MsgStringPtr;

      vecptr = FaoVector;

      /* "Document" */
      *vecptr++ = cptr;
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) *cptr++ = '\0';

      *vecptr++ = rqptr->rqHeader.PathInfoPtr;
      *vecptr++ = rqptr->rqHeader.PathInfoPtr;
      *vecptr++ = Bytes;

      *vecptr++ = UPD_HELP_PATH;

      /* "Help" */
      *vecptr++ = cptr;
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) *cptr++ = '\0';

      /* "Revised" */
      *vecptr++ = cptr;
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) *cptr++ = '\0';

      *vecptr++ = DayDate;

      /* save the current position for use in later parts of the page */
      tkptr->MsgStringPtr = cptr;

      if (AsName[0] && FileExists)
      {
         char  ch;

         /* "Save As" */
         while (*cptr && *cptr != '|') cptr++;
         if (*cptr) cptr++;
         *vecptr++ = cptr;
         while (*cptr && *cptr != '|') cptr++;
         ch = *cptr;
         *cptr = '\0';

         *vecptr++ = PostPath;
         *vecptr++ = PostPath;

         status = WriteFaol (Source, sizeof(Source), NULL,
"<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1>\n\
<TR><TD>\n\
<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=RIGHT>!AZ:</TH>\
<TD ALIGN=LEFT><A HREF=\"!UZ\">!UZ</A>!AZ</TD>\n\
<TH ALIGN=RIGHT>[<A HREF=\"!UZ\">!UZ</A>]</TH></TR>\n\
<TR><TH ALIGN=RIGHT>!AZ:</TH><TD ALIGN=LEFT>!AZ</TD></TR>\n\
<TR><TH ALIGN=RIGHT>!AZ:</TH>\
<TD ALIGN=LEFT><A HREF=\"!UZ\">!UZ</A></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n",
            &FaoVector);

         *cptr = ch;
      }
      else
      {
         status = WriteFaol (Source, sizeof(Source), NULL,
"<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1>\n\
<TR><TD>\n\
<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=RIGHT>!AZ:</TH>\
<TD ALIGN=LEFT><A HREF=\"!UZ\">!UZ</A>!AZ</TD>\n\
<TD>&nbsp;</TD><TH>[<A HREF=\"!UZ\">!UZ</A>]</TH></TR>\n\
<TR><TH ALIGN=RIGHT>!AZ:</TH><TD ALIGN=LEFT>!AZ</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n",
            &FaoVector);
      }
   }
   if (VMSnok (status) || status == SS$_BUFFEROVF)
   {
      rqptr->rqResponse.ErrorTextPtr = "WriteFaol()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdEnd (rqptr);
      return;
   }

#define X11_80X24
   if (!tkptr->CxR[0])
   {
#ifdef X11_80X24
      if (rqptr->rqHeader.UserAgentPtr == NULL)
         strcpy (tkptr->CxR, "80x16");
      else
      {
         /* larger window if X Window System browser (assume workstation) */
         if (strstr (rqptr->rqHeader.UserAgentPtr, "X11") != NULL)
            strcpy (tkptr->CxR, "80x24");
         else
            strcpy (tkptr->CxR, "80x16");
      }
#else
      strcpy (tkptr->CxR, "80x16");
#endif
   }

   if (!FileExists &&
       ConfigSameContentType (ContentTypePtr, "text/html", 9))
   {
      HtmlTemplatePtr =
"&lt;HTML&gt;\n\
&lt;HEAD&gt;\n\
&lt;TITLE&gt;&lt;/TITLE&gt;\n\
&lt;/HEAD&gt;\n\
&lt;BODY&gt;\n\
&lt;/BODY&gt;\n\
&lt;/HTML&gt;\n";
   }
   else
      HtmlTemplatePtr = "";

   cptr = tkptr->CxR;
   tkptr->Cols = atoi(cptr);
   while (*cptr && tolower(*cptr) != 'x') cptr++;
   if (*cptr) cptr++;
   tkptr->Rows = atoi(cptr);

   if (tkptr->Cols <= 0)
      tkptr->Cols = 80;
   else
   if (tkptr->Cols >= 132)
      tkptr->Cols = 132;
   if (tkptr->Rows <= 0)
      tkptr->Rows = 12;
   else
   if (tkptr->Rows >= 48)
      tkptr->Rows = 48;

   /*
      The file edit page is deliberately not pre-expired.
      To do so results in the page being reloaded each time it's displayed.
   */
   HTTP_HEADER_200_HTML (rqptr);

   /* retrieve the previously saved position in the string */
   cptr = tkptr->MsgStringPtr;

   vecptr = FaoVector;

   *vecptr++ = HtmlMetaInfo (rqptr, tkptr->FileOds.ExpFileName);

   /* ordinary editing or server administration file editing again */
   if (ConfigurationEdit)
   {
      *vecptr++ = "HTTPd";
      *vecptr++ = ServerHostPort;
      *vecptr++ = Config.cfServer.AdminBodyTag;
      *vecptr++ = "HTTPd";
      *vecptr++ = ServerHostPort;
   }
   else
   {
      *vecptr++ = cptr;
      *vecptr++ = rqptr->ServicePtr->ServerHostPort;
      *vecptr++ = Config.cfServer.AdminBodyTag;
      *vecptr++ = cptr;
      *vecptr++ = rqptr->ServicePtr->ServerHostPort;
   }

   /* step over the "Update" */
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   *vecptr++ = TitlePtr;
   *vecptr++ = Source;

   *vecptr++ = PostPath;

   if (AsName[0])
   {
      /* "save as" */
      *vecptr++ = cptr;
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) *cptr++ = '\0';
      /* step over "Update" */
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) cptr++;
      /* step over "Create" */
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) cptr++;
   }
   else
   if (FileExists)
   {
      /* step over "save as" */
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) cptr++;
      /* "Update" */
      *vecptr++ = cptr;
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) *cptr++ = '\0';
      /* step over "Create" */
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) cptr++;
   }
   else
   {
      /* step over "save as" */
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) cptr++;
      /* step over "Update" */
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) cptr++;
      /* "Create" */
      *vecptr++ = cptr;
      while (*cptr && *cptr != '|') cptr++;
      if (*cptr) *cptr++ = '\0';
   }

   /* "Preview" */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   if (ConfigSameContentType (ContentTypePtr, "text/html", -1))
   {
      *vecptr++ = UPD_PREVIEW_NOTE_HTML;
      *vecptr++ = UPD_PREVIEW_NOTE_HTML_NEWLINE;
   }
   else
   if (ConfigSameContentType (ContentTypePtr, "text/x-menu", -1))
   {
      *vecptr++ = UPD_PREVIEW_NOTE_HTML;
      *vecptr++ = UPD_PREVIEW_NOTE_MENU_NEWLINE;
   }
   else
   {
      *vecptr++ = UPD_PREVIEW_NOTE_PLAIN;
      *vecptr++ = "";
   }

   /* Undo Editing */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* save the current position for use in later parts of the page */
   tkptr->MsgStringPtr = cptr;

   /* file protection */
   *vecptr++ = UpdProtectionList;

   *vecptr++ = tkptr->Cols;
   *vecptr++ = tkptr->Rows;

   *vecptr++ = SiteLogEntry;
   *vecptr++ = HtmlTemplatePtr;

   status = NetWriteFaol (rqptr,
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>!AZ !AZ</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2>!AZ !AZ</H2>\n\
!AZ\
!AZ\
<P>\n\
<FORM METHOD=POST ACTION=\"!UF\">\n\
<INPUT TYPE=submit VALUE=\" !AZ \">&nbsp;\n\
<INPUT TYPE=submit NAME=previewonly VALUE=\" !AZ \">&nbsp;\n\
<INPUT TYPE=hidden NAME=previewnote VALUE=\"!AZ!AZ\">\n\
<INPUT TYPE=reset VALUE=\" !AZ \">\n\
!AZ\
<BR>\n\
<TEXTAREA NAME=document COLS=!UL ROWS=!UL>\
!AZ!AZ",
      &FaoVector);

   if (VMSnok (status))
   {
      ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      rqptr->rqResponse.ErrorTextPtr = "NetWriteFaol()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   if (FileExists)
      AstFunctionPtr = &UpdEditFileNextRecord;
   else
      AstFunctionPtr = &UpdEditFileEnd;

   NetWriteFullFlush (rqptr, AstFunctionPtr);
}

/*****************************************************************************/
/*
Queue a read of the next record from the file.  When the read completes call 
UpdEditFileNextRecordAST() function to HTML-escape and include in the text
area.
*/ 

UpdEditFileNextRecord (struct RequestStruct *rqptr)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UpdEditFileNextRecord()\n");

   /* asynchronous get service */
   rqptr->UpdTaskPtr->FileOds.Rab.rab$l_rop |= RAB$M_ASY;
   sys$get (&rqptr->UpdTaskPtr->FileOds.Rab,
            &UpdEditFileNextRecordAST,
            &UpdEditFileNextRecordAST);
}

/*****************************************************************************/
/*
A record has been read.  Ensure it is newline terminated.  Escape any
HTML-forbidden characters (it is being included within <TEXTAREA></TEXTAREA>
tags!).  Buffer it.
*/ 

UpdEditFileNextRecordAST (struct RAB *RabPtr)

{
   register int  rsz;
   register struct RequestStruct  *rqptr;
   register struct UpdTaskStruct  *tkptr;

   int  status,
        Length;

   /*********/
   /* begin */
   /*********/

   if (Debug)
   {
      fprintf (stdout,
      "UpdEditFileNextRecordAST() sts: %%X%08.08X stv: %%X%08.08X rsz: %d\n",
      RabPtr->rab$l_sts, RabPtr->rab$l_stv,  RabPtr->rab$w_rsz);
   }

   rqptr = RabPtr->rab$l_ctx;
   tkptr = rqptr->UpdTaskPtr;

   if (VMSnok (tkptr->FileOds.Rab.rab$l_sts))
   {
      if (tkptr->FileOds.Rab.rab$l_sts == RMS$_EOF)
      {
         if (Debug) fprintf (stdout, "RMS$_EOF\n");
         UpdEditFileEnd (rqptr);
         return;
      }

      rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->FileOds.ExpFileName;
      ErrorVmsStatus (rqptr, tkptr->FileOds.Rab.rab$l_sts, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   rsz = tkptr->FileOds.Rab.rab$w_rsz;
   if (!tkptr->RecordFormatFixed)
   {
      /* add newline if empty, or if last character in line not a newline! */
      if (rsz && tkptr->FileOds.Rab.rab$l_ubf[rsz-1] != '\n')
         tkptr->FileOds.Rab.rab$l_ubf[rsz++] = '\n';
      else
      if (!rsz)
         tkptr->FileOds.Rab.rab$l_ubf[rsz++] = '\n';
   }
   tkptr->FileOds.Rab.rab$l_ubf[rsz] = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", tkptr->FileOds.Rab.rab$l_ubf);

   status = NetWriteFao (rqptr, "!HZ", tkptr->FileOds.Rab.rab$l_ubf);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   NetWritePartFlush (rqptr, &UpdEditFileNextRecord);
}

/*****************************************************************************/
/*
End-of-file detected.  End text area, add form submit botton, change text
edit area form, etc., complete editing page HTML.
*/

UpdEditFileEnd (struct RequestStruct *rqptr)

{
   register char  *cptr;
   register unsigned long  *vecptr;
   register struct UpdTaskStruct  *tkptr;

   int  status;
   unsigned long  FaoVector [16];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UpdEditFileEnd()\n");

   tkptr = rqptr->UpdTaskPtr;

   vecptr = FaoVector;

   *vecptr++ = rqptr->ScriptName;
   *vecptr++ = rqptr->rqHeader.PathInfoPtr;

   /* "Change Edit Window" */
   *vecptr++ = cptr = tkptr->MsgStringPtr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   *vecptr++ = tkptr->Cols;
   *vecptr++ = tkptr->Rows;
   *vecptr++ = tkptr->Cols;
   *vecptr++ = tkptr->Rows;

   status = NetWriteFaol (rqptr,
"</TEXTAREA>\n\
</FORM>\n\
<P><FORM METHOD=GET ACTION=\"!UF!UF\">\n\
<INPUT TYPE=submit VALUE=\" !AZ \">\n\
<SELECT NAME=cxr>\n\
<OPTION VALUE=!ULx!UL SELECTED>!ULx!UL\n\
<OPTION VALUE=132x48>132x48\n\
<OPTION VALUE=132x24>132x24\n\
<OPTION VALUE=132x16>132x16\n\
<OPTION VALUE=132x12>132x12\n\
<OPTION VALUE=80x48>80x48\n\
<OPTION VALUE=80x24>80x24\n\
<OPTION VALUE=80x16>80x16\n\
<OPTION VALUE=80x12>80x12\n\
<OPTION VALUE=40x48>40x48\n\
<OPTION VALUE=40x24>40x24\n\
<OPTION VALUE=40x12>40x12\n\
</SELECT>\n\
</FORM>\n\
</BODY>\n\
</HTML>\n",
      &FaoVector);

   if (VMSnok (status))
   {
      ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      rqptr->rqResponse.ErrorTextPtr = "NetWriteFaol()";
      ErrorVmsStatus (rqptr, status, FI_LI);
   }

   UpdEnd (rqptr);
}

/*****************************************************************************/
/*
*/

UpdFileRename
(
struct RequestStruct *rqptr,
char *OldOne,
char *NewOne
)
{
   register char  *cptr;
   register unsigned long  *vecptr;
   register struct UpdTaskStruct  *tkptr;

   int  status,
        RenameCount;
   unsigned short  Length;
   unsigned long  Context,
                  RenameFlags;
   char  NewName [ODS_MAX_FILE_NAME_LENGTH+1],
         NewFileName [ODS_MAX_FILE_NAME_LENGTH+1],
         OldName [ODS_MAX_FILE_NAME_LENGTH+1],
         OldFileName [ODS_MAX_FILE_NAME_LENGTH+1],
         Scratch [ODS_MAX_FILE_NAME_LENGTH+1];
   $DESCRIPTOR (OldFileNameDsc, OldFileName);
   $DESCRIPTOR (NewFileNameDsc, NewFileName);

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "UpdFileRename() |%s|%s|%s|\n",
               rqptr->rqHeader.PathInfoPtr, OldName, NewName);

   tkptr = rqptr->UpdTaskPtr;

   /* authentication is mandatory for a PUT, DELETE or POST */
   if (!rqptr->RemoteUser[0] ||
       !((rqptr->rqAuth.RequestCan & HTTP_METHOD_PUT) ||
         (rqptr->rqAuth.RequestCan & HTTP_METHOD_POST) ||
         (rqptr->rqAuth.RequestCan & HTTP_METHOD_DELETE)))
   {
      rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
      ErrorVmsStatus (rqptr, SS$_NOPRIV, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   if (!OldOne[0] || !NewOne[0] || rqptr->rqHeader.Method != HTTP_METHOD_POST)
   {
      ErrorInternal (rqptr, 0, ErrorSanityCheck, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   MapUrl_UrlToVms (OldOne, OldName, sizeof(OldName), '_',
                    rqptr->PathOdsExtended);
   WriteFao (OldFileName, sizeof(OldFileName), &Length, "!AZ!AZ",
             rqptr->ParseOds.ExpFileName, OldName);
   OldFileNameDsc.dsc$w_length = Length;

   MapUrl_UrlToVms (NewOne, NewName, sizeof(NewName), '_',
                    rqptr->PathOdsExtended);
   WriteFao (NewFileName, sizeof(NewFileName), &Length, "!AZ!AZ",
             rqptr->ParseOds.ExpFileName, NewName);
   NewFileNameDsc.dsc$w_length = Length;

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_RESPONSE))
      WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                 "UPDATE rename !AZ !AZ", OldFileName, NewFileName);

   if (strsame (OldName, NewName, -1))
   {
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_UPD_RENAME_SAME), FI_LI);
      UpdEnd (rqptr);
      return;
   }

   /* check access to parent directory */
   if (VMSnok (status =
       AuthVmsCheckWriteAccess (rqptr, rqptr->ParseOds.ExpFileName, 0)))
   {
      rqptr->rqResponse.ErrorTextPtr = MapVmsPath (rqptr->ParseOds.ExpFileName, rqptr);
      rqptr->rqResponse.ErrorOtherTextPtr = rqptr->ParseOds.ExpFileName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   /* use SYSPRV to ensure deletion of file (provided protection is S:RWED) */
   EnableSysPrv();

   RenameFlags = 0x1;
#ifdef ODS_EXTENDED
   if (rqptr->PathOdsExtended) RenameFlags += 0x4;
#endif /* ODS_EXTENDED */

   RenameCount = Context = 0;
   while (VMSok (status =
          lib$rename_file (&OldFileNameDsc, &NewFileNameDsc,
                           0, 0, &RenameFlags, 0, 0, 0, 0, 0, 0, &Context)))
      RenameCount++;

   DisableSysPrv();

   if (!RenameCount)
   {
      rqptr->rqResponse.ErrorOtherTextPtr = rqptr->ParseOds.ExpFileName;
      if (status == RMS$_FNF)
      {
         rqptr->rqResponse.ErrorTextPtr = OldName;
         ErrorVmsStatus (rqptr, status, FI_LI);
      }
      else
      if (status == RMS$_SYN)
      {
         rqptr->rqResponse.ErrorTextPtr = NewName;
         ErrorVmsStatus (rqptr, status, FI_LI);
      }
      else
      {
         rqptr->rqResponse.ErrorTextPtr = MapVmsPath (NewName, rqptr);
         ErrorVmsStatus (rqptr, status, FI_LI);
      }
      UpdEnd (rqptr);
      return;
   }

   /***********/
   /* success */
   /***********/

   ReportSuccess (rqptr,
      "!AZ &nbsp;<TT>!UF</TT>&nbsp; !AZ &nbsp;<TT>!UF</TT>\n",
       MsgFor(rqptr,MSG_GENERAL_FILE), OldName,
       MsgFor(rqptr,MSG_UPD_RENAMED), NewName);

   UpdEnd (rqptr);
}

/*****************************************************************************/
/*
Copy a file by reading each 512 byte block and converting these into
4 x 128 byte, hexadecimal-encoded, form fields that can be recreated into a
file when POSTed to this server (see "hexencoded" in PUT.c module).
*/

UpdCopyFileBegin
(
struct RequestStruct *rqptr,
char *AsName
)
{
   register unsigned long  *vecptr;
   register char  *cptr, *sptr, *zptr;
   register struct UpdTaskStruct  *tkptr;

   int  status,
        ByteCount,
        RevDayOfWeek;
   unsigned long  FaoVector [32];
   char  *ToPtr;
   char  PostPath [ODS_MAX_FILE_NAME_LENGTH+1],
         Scratch [256];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UpdCopyFileBegin() |%s|\n", AsName);

   tkptr = rqptr->UpdTaskPtr;

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_RESPONSE))
      WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                 "UPDATE copy !AZ", rqptr->ParseOds.ExpFileName);

   /*****************************************/
   /* check VMS-authenticated user's access */
   /*****************************************/

   if (rqptr->rqAuth.VmsUserProfileLength)
   {
      status = AuthVmsCheckUserAccess (rqptr, rqptr->ParseOds.ExpFileName, 0);
      if (status == RMS$_PRV)
         tkptr->AuthVmsUserHasAccess = false;
      else
      if (VMSok (status))
         tkptr->AuthVmsUserHasAccess = true;
      else
      {
         /* error reported by access check */
         UpdEnd (rqptr);
         return;
      }
   }
   else
      tkptr->AuthVmsUserHasAccess = false;

   /********/
   /* open */
   /********/

   if (tkptr->AuthVmsUserHasAccess) EnableSysPrv();
   OdsOpen (&tkptr->FileOds,
            rqptr->ParseOds.ExpFileName, rqptr->ParseOds.ExpFileNameLength,
            NULL, 0, FAB$M_GET | FAB$M_BIO, 0, FAB$M_SHRGET,
            NULL, rqptr);  
   if (tkptr->AuthVmsUserHasAccess) DisableSysPrv();

   if (VMSnok (status = tkptr->FileOds.Fab.fab$l_sts))
   {
      rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
      rqptr->rqResponse.ErrorOtherTextPtr = rqptr->ParseOds.ExpFileName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   if (VMSnok (status = OdsParseTerminate (&tkptr->FileOds)))
   {
      ErrorNoticed (status, "OdsParseTerminate()", FI_LI);
      UpdEnd (rqptr);
      return;
   }

   /* record access block */
   tkptr->FileOds.Rab = cc$rms_rab;
   tkptr->FileOds.Rab.rab$l_ctx = rqptr;
   tkptr->FileOds.Rab.rab$l_fab = &tkptr->FileOds.Fab;
   tkptr->FileOds.Rab.rab$l_bkt = 0;
   tkptr->FileOds.Rab.rab$l_rop = RAB$M_RAH | RAB$M_BIO;
   tkptr->FileOds.Rab.rab$l_ubf = tkptr->CopyBuffer;
   /* MUST be 512 bytes (one block) */
   tkptr->FileOds.Rab.rab$w_usz = sizeof(tkptr->CopyBuffer);

   status = sys$connect (&tkptr->FileOds.Rab, 0, 0);
   if (Debug) fprintf (stdout, "sys$connect() %%X%08.08X\n", status);
   if (VMSnok (status))
   {
      rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->FileOds.ExpFileName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   /**************/
   /* begin page */
   /**************/

   /* remove any explicit version from the path to be POSTed */
   zptr = (sptr = PostPath) + sizeof(PostPath);
   /* a full (local) path could have been supplied */
   if (AsName[0] != '/')
      for (cptr = rqptr->rqHeader.PathInfoPtr; *cptr && sptr < zptr; *sptr++ = *cptr++);
   if (sptr < zptr)
   {
      /* eliminate the trailing file name */
      while (sptr > PostPath && *sptr != '/') sptr--;
      if (*sptr == '/') sptr++;
      /* add the destination file name */
      for (cptr = AsName; *cptr && sptr < zptr; *sptr++ = *cptr++);
   }
   if (sptr >= zptr)
   {
      ErrorGeneralOverflow (rqptr, FI_LI);
      UpdEnd (rqptr);
      return;
   }
   *sptr = '\0';
   if (Debug) fprintf (stdout, "PostPath |%s|\n", PostPath);

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_UPD;
   HTTP_HEADER_200_HTML (rqptr);

   cptr = MsgFor(rqptr,MSG_UPD_COPY);
   zptr = (sptr = Scratch) + sizeof(Scratch);
   while (*cptr && sptr < zptr) *sptr++ = *cptr++;
   if (sptr >= zptr)
   {
      ErrorGeneralOverflow (rqptr, FI_LI);
      UpdEnd (rqptr);
      return;
   }
   *sptr = '\0';

   vecptr = FaoVector;

   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   /* "Update" */
   *vecptr++ = cptr = Scratch;
   *vecptr++ = rqptr->ServicePtr->ServerHostPort;

   *vecptr++ = Config.cfServer.AdminBodyTag;

   /* "Update" again */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';
   *vecptr++ = rqptr->ServicePtr->ServerHostPort;

   *vecptr++ = PostPath;
   *vecptr++ = tkptr->ProtectionMask;

   /* "Copy" */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = rqptr->rqHeader.PathInfoPtr;

   /* "Confirm" (for historical reasons "confirm" is after "to") */
   ToPtr = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* "To" */
   *vecptr++ = ToPtr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   *vecptr++ = PostPath;
   *vecptr++ = PostPath;

   status = NetWriteFaol (rqptr,
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>!AZ !AZ</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2>!AZ !AZ</H2>\n\
<FORM METHOD=POST ACTION=\"!UF\">\n\
<INPUT TYPE=hidden NAME=protection VALUE=\"!4XL\">\n\
<P><TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1>\n\
<TR><TD>\n\
<TABLE CELLPADDING=1 CELLSPACING=0 BORDER=0>\n\
<TR><TD ALIGN=right>&nbsp;<B>!AZ</B>&nbsp;&nbsp;</TD>\
<TD><A HREF=\"!UF\"><TT>!UF</TT></A></TD>\
<TD VALIGN=top ROWSPAN=2>\
&nbsp;&nbsp;&nbsp;<INPUT TYPE=submit VALUE=\" !AZ \">\
</TD></TR>\n\
<TR><TD ALIGN=right>&nbsp;<B>!AZ</B>&nbsp;&nbsp;</TD>\
<TD><A HREF=\"!UF\"><TT>!UF</TT></A></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n",
      &FaoVector);

   if (VMSnok (status))
   {
      ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      rqptr->rqResponse.ErrorTextPtr = "NetWriteFaol()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   NetWriteFullFlush (rqptr, &UpdCopyFileNextBlock);
}

/*****************************************************************************/
/*
Queue a read of the next record from the file.  When the read completes call 
UpdCopyFileNextBlockAST() function to HTML-escape and include in the text
area.
*/ 

UpdCopyFileNextBlock (struct RequestStruct *rqptr)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UpdCopyFileNextBlock()\n");

   rqptr->UpdTaskPtr->FileOds.Rab.rab$l_bkt++;

   /* asynchronous read service */
   rqptr->UpdTaskPtr->FileOds.Rab.rab$l_rop |= RAB$M_ASY;
   sys$read (&rqptr->UpdTaskPtr->FileOds.Rab,
             &UpdCopyFileNextBlockAST,
             &UpdCopyFileNextBlockAST);
}

/*****************************************************************************/
/*
A record has been read.  Turn the record into 128 byte, hexdecimal-encoded
form hidden fields.
*/ 

UpdCopyFileNextBlockAST (struct RAB *RabPtr)

{
   static char  HexDigit [] = "0123456789ABCDEF";
   static char  Bucket [64];
   static $DESCRIPTOR (BucketDsc, Bucket);
   static $DESCRIPTOR (BucketFaoDsc,
          "<INPUT TYPE=hidden NAME=hexencoded_!UL_!UL VALUE=\"\0");

   register int  cnt;
   register char  *cptr, *sptr;
   register struct RequestStruct  *rqptr;
   register struct UpdTaskStruct  *tkptr;

   int  status;
   char  Buffer [2048];

   /*********/
   /* begin */
   /*********/

   if (Debug)
   {
      fprintf (stdout,
      "UpdCopyFileNextBlockAST() sts: %%X%08.08X stv: %%X%08.08X rsz: %d\n",
      RabPtr->rab$l_sts, RabPtr->rab$l_stv,  RabPtr->rab$w_rsz);
   }

   rqptr = RabPtr->rab$l_ctx;
   tkptr = rqptr->UpdTaskPtr;

   if (VMSnok (tkptr->FileOds.Rab.rab$l_sts))
   {
      if (tkptr->FileOds.Rab.rab$l_sts == RMS$_EOF)
      {
         if (Debug) fprintf (stdout, "RMS$_EOF\n");
         UpdCopyFileEnd (rqptr);
         return;
      }

      rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->FileOds.ExpFileName;
      ErrorVmsStatus (rqptr, tkptr->FileOds.Rab.rab$l_sts, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   sptr = Buffer;
   for (cnt = 0; cnt < RabPtr->rab$w_rsz; cnt++)
   {
       if (!(cnt % 128))
       {
          if (cnt) for (cptr = "\">\n"; *cptr; *sptr++ = *cptr++);
          sys$fao (&BucketFaoDsc, 0, &BucketDsc,
                   tkptr->FileOds.Rab.rab$l_bkt, cnt);          
          for (cptr = Bucket; *cptr; *sptr++ = *cptr++);
          cptr = tkptr->FileOds.Rab.rab$l_ubf + cnt;
      }
      *sptr++ = HexDigit[((unsigned char)*cptr & 0xf0) >> 4];
      *sptr++ = HexDigit[(unsigned char)*cptr & 0x0f];
      cptr++;
   }
   for (cptr = "\">\n"; *cptr; *sptr++ = *cptr++);
   *sptr = '\0';

   NetWriteBuffered (rqptr, &UpdCopyFileNextBlock, Buffer, sptr-Buffer);
}

/*****************************************************************************/
/*
End-of-file detected.
*/

UpdCopyFileEnd (struct RequestStruct *rqptr)

{
   static char  CopyFileEndFao [] = 
"</FORM>\n\
</BODY>\n\
</HTML>\n";

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UpdCopyFileEnd()\n");

   status = NetWriteFaol (rqptr, CopyFileEndFao, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   UpdEnd (rqptr);
}

/*****************************************************************************/
/*
Output HTML allowing confirmation of directory creation.
*/

UpdConfirmMkdir
(
struct RequestStruct *rqptr,
char *AsName
)
{
   register char  *cptr, *sptr, *zptr;
   register unsigned long  *vecptr;
   register struct UpdTaskStruct  *tkptr;

   int  status;
   unsigned long  FaoVector [32];
   char  Scratch [256];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UpdConfirmMkdir() |%s|\n", AsName);

   tkptr = rqptr->UpdTaskPtr;

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_UPD;
   HTTP_HEADER_200_HTML (rqptr);

   cptr = MsgFor(rqptr,MSG_UPD_CREATE);
   zptr = (sptr = Scratch) + sizeof(Scratch);
   while (*cptr && sptr < zptr) *sptr++ = *cptr++;
   if (sptr >= zptr)
   {
      ErrorGeneralOverflow (rqptr, FI_LI);
      UpdEnd (rqptr);
      return;
   }
   *sptr = '\0';

   vecptr = FaoVector;

   *vecptr++ = HtmlMetaInfo (rqptr, NULL);

   /* "Update" */
   *vecptr++ = cptr = Scratch;
   *vecptr++ = rqptr->ServicePtr->ServerHostPort;

   *vecptr++ = Config.cfServer.AdminBodyTag;

   /* "Update" again */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   *vecptr++ = rqptr->ServicePtr->ServerHostPort;
   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = AsName;
   *vecptr++ = tkptr->ProtectionMask;

   /* "Create" */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = AsName;
   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = AsName;

   /* "Confirm" */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   status = NetWriteFaol (rqptr,
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>!AZ !AZ</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2>!AZ !AZ</H2>\n\
<FORM METHOD=POST ACTION=\"!UZ!UZ/\">\n\
<INPUT TYPE=hidden NAME=protection VALUE=\"!4XL\">\n\
<P><TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1>\n\
<TR><TD ALIGN=right VALIGN=top>\n\
<NOBR>&nbsp;<B>!AZ</B>&nbsp;&nbsp;&nbsp;\
<A HREF=\"!UF!UF/\">!UF!UF/</A>&nbsp;&nbsp;&nbsp;\
<INPUT TYPE=submit VALUE=\" !AZ \"></NOBR>\n\
</TD></TR>\n\
</TABLE>\n\
</FORM>\n\
</BODY>\n\
</HTML>\n",
      &FaoVector);

   if (VMSnok (status))
   {
      ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      rqptr->rqResponse.ErrorTextPtr = "NetWriteFaol()";
      ErrorVmsStatus (rqptr, status, FI_LI);
   }

   UpdEnd (rqptr);
}

/*****************************************************************************/
/*
Output HTML allowing confirmation of directory deletion.
*/

UpdConfirmDelete
(
struct RequestStruct *rqptr,
char *Name,
char *Slash
)
{
   register char  *cptr, *sptr, *zptr;
   register unsigned long  *vecptr;
   register struct UpdTaskStruct  *tkptr;

   int  status;
   unsigned long  FaoVector [32];
   char  Scratch [256];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UpdConfirmDelete() |%s|\n", Name);

   tkptr = rqptr->UpdTaskPtr;

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_UPD;
   HTTP_HEADER_200_HTML (rqptr);

   cptr = MsgFor(rqptr,MSG_UPD_DELETE);
   zptr = (sptr = Scratch) + sizeof(Scratch);
   while (*cptr && sptr < zptr) *sptr++ = *cptr++;
   if (sptr >= zptr)
   {
      ErrorGeneralOverflow (rqptr, FI_LI);
      UpdEnd (rqptr);
      return;
   }
   *sptr = '\0';

   vecptr = FaoVector;

   *vecptr++ = HtmlMetaInfo (rqptr, NULL);

   /* "Update" */
   *vecptr++ = cptr = Scratch;
   *vecptr++ = rqptr->ServicePtr->ServerHostPort;

   *vecptr++ = Config.cfServer.AdminBodyTag;

   /* "Update" again */
   *vecptr++ = cptr;
   *vecptr++ = rqptr->ServicePtr->ServerHostPort;

   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = Name;
   *vecptr++ = Slash;

   /* "delete" */
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';
   *vecptr++ = cptr;

   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = Name;
   *vecptr++ = Slash;
   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = Name;
   *vecptr++ = Slash;

   /* "Confirm" */
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';
   *vecptr++ = cptr;

   status = NetWriteFaol (rqptr,
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>!AZ !AZ</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2>!AZ !AZ</H2>\n\
<FORM METHOD=POST ACTION=\"!UZ!UZ!AZ;*\">\n\
<P><TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1>\n\
<TR><TD ALIGN=right VALIGN=top>\n\
<NOBR>&nbsp;<B>!AZ</B>&nbsp;&nbsp;\
<A HREF=\"!UF!UF!AZ\"><TT>!UF!UF!AZ</TT></A>&nbsp;&nbsp;&nbsp;\
<INPUT TYPE=submit VALUE=\" !AZ \"></NOBR>\n\
</TD></TR>\n\
</TABLE>\n\
</FORM>\n\
</BODY>\n\
</HTML>\n",
      &FaoVector);

   if (VMSnok (status))
   {
      ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      rqptr->rqResponse.ErrorTextPtr = "NetWriteFaol()";
      ErrorVmsStatus (rqptr, status, FI_LI);
   }

   UpdEnd (rqptr);
}

/*****************************************************************************/
/*
Output HTML allowing confirmation of action (file/directory creation/deletion).
*/

UpdConfirmRename
(
struct RequestStruct *rqptr,
char *OldName,
char *NewName
)
{
   register char  *cptr, *sptr, *zptr;
   register unsigned long  *vecptr;
   register struct UpdTaskStruct  *tkptr;

   int  status;
   unsigned long  FaoVector [32];
   char  Scratch [256];
   char  *ToPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "UpdConfirmRename() |%s|%s|\n", OldName, NewName);

   tkptr = rqptr->UpdTaskPtr;

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_UPD;
   HTTP_HEADER_200_HTML (rqptr);

   cptr = MsgFor(rqptr,MSG_UPD_RENAME);
   zptr = (sptr = Scratch) + sizeof(Scratch);
   while (*cptr && sptr < zptr) *sptr++ = *cptr++;
   if (sptr >= zptr)
   {
      ErrorGeneralOverflow (rqptr, FI_LI);
      UpdEnd (rqptr);
      return;
   }
   *sptr = '\0';

   vecptr = FaoVector;

   *vecptr++ = HtmlMetaInfo (rqptr, NULL);

   /* "Update" */
   *vecptr++ = cptr = Scratch;
   *vecptr++ = rqptr->ServicePtr->ServerHostPort;

   *vecptr++ = Config.cfServer.AdminBodyTag;

   /* "Update" again */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';
   *vecptr++ = rqptr->ServicePtr->ServerHostPort;

   *vecptr++ = rqptr->ScriptName;
   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = OldName,
   *vecptr++ = NewName,

   /* "Rename" */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = OldName,
   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = OldName,

   /* "Confirm" (for historical reasons "confirm" is after "to") */
   ToPtr = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* "to" */
   *vecptr++ = ToPtr;

   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = NewName,
   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = NewName,

   status = NetWriteFaol (rqptr,
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>!AZ !AZ</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2>!AZ !AZ</H2>\n\
<FORM METHOD=POST ACTION=\"!AZ!AZ\">\n\
<INPUT TYPE=hidden NAME=d-filerename VALUE=1>\n\
<INPUT TYPE=hidden NAME=name VALUE=\"!AZ\">\n\
<INPUT TYPE=hidden NAME=as VALUE=\"!AZ\">\n\
<P><TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1>\n\
<TR><TD>\n\
<TABLE CELLPADDING=1 CELLSPACING=0 BORDER=0>\n\
<TR><TD ALIGN=right>&nbsp;<B>!AZ</B>&nbsp;&nbsp;</TD>\
<TD><A HREF=\"!UF!UF\"><TT>!UF!UF</TT></A></TD>\
<TD VALIGN=top ROWSPAN=2>\
&nbsp;&nbsp;&nbsp;<INPUT TYPE=submit VALUE=\" !AZ \">\
</TD></TR>\n\
<TR><TD ALIGN=right>&nbsp;<B>!AZ</B>&nbsp;&nbsp;</TD>\
<TD><A HREF=\"!UF!UF\"><TT>!UF!UF</TT></A></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
</FORM>\n\
</BODY>\n\
</HTML>\n",
      &FaoVector);

   if (VMSnok (status))
   {
      ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      rqptr->rqResponse.ErrorTextPtr = "NetWriteFaol()";
      ErrorVmsStatus (rqptr, status, FI_LI);
   }

   UpdEnd (rqptr);
}

/*****************************************************************************/
/*
Update the protection of rqptr->ParseOds.ExpFileName.
*/ 

UpdProtection (struct RequestStruct *rqptr)

{
   static unsigned short  EnsureSystemAccessMask = 0xfff0; /* S:RWED */
   static $DESCRIPTOR (DeviceDsc,  "");

   register char  *cptr, *sptr;
   register unsigned long  *vecptr;
   register struct UpdTaskStruct  *tkptr;

   int  status;
   unsigned short  ProtectionMask;
   unsigned long  FaoVector [32];
   char  ProtectionString [32];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UpdProtection()\n");

   tkptr = rqptr->UpdTaskPtr;

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_RESPONSE))
      WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                 "UPDATE protection !AZ", rqptr->ParseOds.ExpFileName);

   /* authentication is mandatory for such an update */
   if (!rqptr->RemoteUser[0] ||
       !((rqptr->rqAuth.RequestCan & HTTP_METHOD_PUT) ||
         (rqptr->rqAuth.RequestCan & HTTP_METHOD_POST) ||
         (rqptr->rqAuth.RequestCan & HTTP_METHOD_DELETE)))
   {
      rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
      rqptr->rqResponse.ErrorOtherTextPtr = rqptr->ParseOds.ExpFileName;
      ErrorVmsStatus (rqptr, SS$_NOPRIV, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   ProtectionMask = tkptr->ProtectionMask & EnsureSystemAccessMask;
   if (Debug)
      fprintf (stdout, "ProtectionMask: %%X%04.04X\n", ProtectionMask);

   status = OdsParse (&tkptr->FileOds, rqptr->ParseOds.ExpFileName,
                      rqptr->ParseOds.ExpFileNameLength,
                      NULL, 0, 0, NULL, rqptr);

   /* check access to parent directory */
   if (VMSnok (status =
       AuthVmsCheckWriteAccess (rqptr, tkptr->FileOds.ExpFileName, 0)))
   {
      rqptr->rqResponse.ErrorTextPtr = tkptr->FileOds.ExpFileName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   if (VMSok (status))
   {
      /* use SYSPRV to ensure modification of file */
      EnableSysPrv();
      status = OdsFileAcpModify (&tkptr->FileOds, &ProtectionMask, NULL,
                                 NULL, rqptr);
      DisableSysPrv();
   }

   if (VMSnok (status)) 
   {
      rqptr->rqResponse.ErrorTextPtr = rqptr->rqHeader.PathInfoPtr;
      rqptr->rqResponse.ErrorOtherTextPtr = rqptr->ParseOds.ExpFileName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      UpdEnd (rqptr);
      return;
   }

   /***********/
   /* success */
   /***********/

   FormatProtection (tkptr->ProtectionMask, ProtectionString);

   ReportSuccess (rqptr,
      "!AZ &nbsp;<TT>!UF</TT>&nbsp; !AZ&nbsp; (!AZ)\n",
       MsgFor(rqptr,MSG_GENERAL_FILE), rqptr->rqHeader.PathInfoPtr,
       MsgFor(rqptr,MSG_UPD_PROTECTION), ProtectionString);

   UpdEnd (rqptr);
}

/*****************************************************************************/

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                