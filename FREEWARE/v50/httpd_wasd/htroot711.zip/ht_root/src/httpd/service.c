/*****************************************************************************/
/*
                                Service.c

This module provides a complementary function to CONFIG.C, which basically
configures per-HTTPD process runtime characterstics, whereas SERVICE.C allows
per-service (essentially virtual services) characteristics to be specified. 
While there is some overlap between the two they do perform different tasks.

Prior to WASD v7.1 service configuration was performed by CONFIG.C as part of
general configuration.  This had it's limitations and this module goes some way
in providing a more flexible and understandable configuration environment. 
This module configuration file, HTTP$SERVICE, does not have to be used and if
is not present the HTTP$CONFIG configuration file [Service] directive will
continue to provide backward-compatible service configuration.  However, new
features will only be incorporated via this module, and HTTP$SERVICE is
available it's service configuration overrides anything still present in
HTTPD$CONFIG.

All service directives must be delimitted with '[' and ']'.  The (virtual)
service they apply to are specified with the usual '[[' and ']]' directive.

  [[http://the.host.name:80]]
  [ServiceIPaddress] 130.185.250.1 
  [ServiceProxy]  disabled
  [ServiceNoLog]  disabled
  [ServiceNoTrack]  disabled
  [ServiceBodyTag]  
  [ServiceErrorReportPath]  
    
In the case of a service specification a 'generic' host name can be specified
using "*".  This generic host name is replaced with the IP host name of
whichever system starts the server.  This is a simple way for providing a basic
or common service on all members of a cluster for instance.

  [[http://*:80]]
  [ServiceProxy]  disabled
  [ServiceNoLog]  disabled
  [ServiceNoTrack]  disabled

This configuration file only really needs to be used for more complex service
configurations.  Basic HTTP and HTTPS services need only be specified using the
the HTTPD$CONFIG [Service] directive.


PRECEDENCE OF SERVICE SPECIFICATIONS
------------------------------------
1. /SERVICE= command line qualifier
2. HTTPD$SERVER configuration file (if logical defined and file exists)
3. HTTPD$CONFIG [Service] directive


HTTPD$SERVICE DIRECTIVES
------------------------
  o  ServiceBodyTag                   <string>
  o  ServiceErrorReportPath           <string>
  o  ServiceIPaddress                 <string>
  o  ServiceNoLog                     DISABLED | ENABLED
  o  ServiceNoTrack                   DISABLED | ENABLED
  o  ServiceProxy                     DISABLED | ENABLED
  o  ServiceProxyAuth                 NONE | PROXY | LOCAL
  o  ServiceProxyCache                DISABLED | ENABLED
  o  ServiceProxyChain                <string>
  o  ServiceProxyTrack                DISABLED | ENABLED
  o  ServiceProxySSL                  DISABLED | ENABLED
  o  ServiceSSLcert                   <string>
  o  ServiceSSLkey                    <string>


COMMAND-LINE PARAMETERS
-----------------------
The following syntax and values are also available for both the HTTPD$CONFIG
[service] configuration parameter and /SERVICE= qualifier.  Also see SESOLA.C
for SSL parameter processing.

  http:                      system host name, HTTP service
  https:                     system host name, SSL service
  http:port                  system host name, supplied port, HTTP service
  https:port                 system host name, supplied SSL service
  http://host.domain         specified host name, pot 80, HTTP service
  https://host.domain        specified host name port 443, SSL service
  http://host.domain:port    specified host name and port, HTTP service
  https://host.domain:port   specified host name and port, SSL service
  ;ip=                       supplied IP address for service
  ;cert=                     SSL service's non-default server certificate
  ;chain=                    service chains to up-stream proxy service
  ;cipher=                   SSL service's specific, non-default cipher list
  ;connect                   service provides SSL connect proxy access
  ;key=                      SSL service's non-default server RSA private key
  ;lauth                     local authorization required
  ;backlog=                  listen queue length
  ;pauth                     proxy authorization required
  ;proxy                     service provide proxy access
  ;[no]track                 enable/disable session tracking on this service
                             (by default is tracking is configuration enabled
                              proxy services have it off, non-proxy on)

For example:

  [service]
  http://host.name:8080;proxy;connect
  https://host.name:443;cert=HT_ROOT:[LOCAL]SITE.PEM


VERSION HISTORY
---------------
21-NOV-2000  MGD  allow for generic service (no host name specified)
17-JUN-2000  MGD  initial
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* VMS related header files */
#include <rmsdef.h>
#include <ssdef.h>
#include <stsdef.h>

/* application related header */
#include "wasd.h"

#define WASD_MODULE "SERVICE"

/******************/
/* global storage */
/******************/

boolean  ServiceConfigFileDefined;
         ServiceLoadFromConfigFile;
 
int  ServiceCount;

struct ServiceLoadStruct  ServiceLoad;

struct ServiceStruct  *ServiceListHead,
                      *ServiceListTail;

unsigned long  ServiceHashTableMask,
               ServiceHashTableEntries;
struct ServiceStruct  **ServiceHashTable;

char  ErrorServiceConfigFile [] = "Service configuration file not defined!\n",
      ErrorServiceList [] = "service list confusing";

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern boolean  ProtocolHttpsAvailable,
                ProtocolHttpsConfigured;

extern int  ServerPort;

extern char  CliServices[],
             ErrorSanityCheck[],
             ServerHostName[],
             ServerHostPort[],
             SoftwareID[],
             Utility[];

extern struct MsgStruct  Msgs;
extern struct ConfigStruct  Config;

/*****************************************************************************/
/*
Open the configuration file defined by the logical name HTTPD$SERVICE.  Read 
each line, passing to the appropriate interpretation function according to the 
directive on the line.  Close the file.  Function is either called before
AST-driven  processing or called at AST delivery level which makes processing
atomic.
*/

ServiceConfigLoad (struct ServiceLoadStruct *slptr)

{
   boolean  DebugBuffer,
            ServiceLooksValid;
   int  status,
        retval,
        LineLength;
   char  *cptr, *sptr, *zptr;
   char  Line [512],
         String [256];
   void  *RequestPtrBuffer;
   struct OdsStruct  ConfigFileOds;
   struct ServiceStruct  ConfigService;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ServiceConfigLoad()\n");

   if (CliServices[0])
   {
      /* set services using /SERVICE= */
      ServiceConfigFromString ();
      return;
   }

   if (!ServiceConfigFileDefined && getenv (CONFIG_SERVICE_FILE_NAME) != NULL)
      ServiceConfigFileDefined = true;

   RequestPtrBuffer = slptr->RequestPtr;
   memset (slptr, 0, sizeof(*slptr));
   slptr->RequestPtr = RequestPtrBuffer;

   /************************/
   /* open the config file */
   /************************/

   /* use SYSPRV to allow access to possibly protected file */
   EnableSysPrv();
   status = OdsOpenReadOnly (&ConfigFileOds, CONFIG_SERVICE_FILE_NAME);
   DisableSysPrv();
   if (VMSnok (status))
   {
      if (slptr->RequestPtr)
      {
         if (ServiceConfigFileDefined)
            ServiceReportProblem (slptr, ConfigFileOds.ExpFileName, status);
         else
            ServiceReportProblem (slptr, CONFIG_SERVICE_FILE_NAME,
                                  status | STS$K_INFO);
         return;
      }
      else
      if (status == RMS$_FNF)
      {
         /* get the parsed configuration file name (if logical defined) */
         strcpy (slptr->LoadFileName, ConfigFileOds.ExpFileName);
         if (ServiceConfigFileDefined)
            ServiceReportProblem (slptr, ConfigFileOds.ExpFileName, status);
         else
            ServiceReportProblem (slptr, CONFIG_SERVICE_FILE_NAME,
                                  status | STS$K_INFO);

         /* set services using HTTPD$CONFIG [Service] */
         ServiceConfigFromString ();
         return;
      }
      else
         ErrorExitVmsStatus (status, ConfigFileOds.ExpFileName, FI_LI);
   }

   /* get the configuration file name and revision date and time */
   strcpy (slptr->LoadFileName, ConfigFileOds.ResFileName);
   memcpy (&slptr->RevBinTime,
           &ConfigFileOds.XabDat.xab$q_rdt,
           sizeof(slptr->RevBinTime));

   ServiceLoadFromConfigFile = true;

   /************************/
   /* read the config file */
   /************************/

#ifdef DBUG
   /* not interested anymore in seeing debug information for config load! */
   DebugBuffer = Debug;
   Debug = false;
#endif

   sys$gettim (&slptr->LoadBinTime);

   /* initialize local service structure */
   memset (&ConfigService, 0, sizeof(ConfigService));
   ServiceLooksValid = false;

   /* set up RAB buffers */
   ConfigFileOds.Rab.rab$l_ubf = Line;
   ConfigFileOds.Rab.rab$w_usz = sizeof(Line)-1;

   while (VMSok (status = sys$get (&ConfigFileOds.Rab, 0, 0)))
   {
      slptr->LineNumber++;
      ConfigFileOds.Rab.rab$l_ubf[ConfigFileOds.Rab.rab$w_rsz] = '\0';
      if (Debug) fprintf (stdout, "Line |%s|\n", Line);

      /* if a blank or comment line, then ignore */
      for (cptr = Line; *cptr && ISLWS(*cptr); cptr++);
      if (!*cptr || *cptr == '!' || *cptr == '#') continue;

      if (*(unsigned short*)cptr == '[[')
      {
         /***************************/
         /* next (or first) service */
         /***************************/

         /* if previous valid service add this to the list */
         if (ServiceLooksValid)
         {
            status = ServiceConfigAdd (slptr, &ConfigService);
            if (Debug)
               fprintf (stdout, "ServiceConfigAdd() %%X%08.08X\n", status);
            if (VMSnok (status))
               ServiceReportProblem (slptr, "cannot configure service", 0);
         }

         /* initialize service structure */
         memset (&ConfigService, 0, sizeof(ConfigService));
         ServiceLooksValid = false;

         /*******************/
         /* process service */
         /*******************/

         zptr = (sptr = slptr->DirectiveName) + sizeof(slptr->DirectiveName)-1;
         cptr += 2;
         while (*cptr && *cptr != ']' && sptr < zptr) *sptr++ = *cptr++;
         *sptr = '\0';
         if (*(unsigned short*)cptr != ']]')
         {
            ServiceReportProblem (slptr, "missing \']]\'?", 0);
            continue;
         }

         /* avoid loading the "next new service" entry ;^) */
         if (strchr (slptr->DirectiveName, '?') != NULL) continue;

         retval = ServiceParse (slptr->DirectiveName,
                                &ConfigService.RequestScheme,
                                &ConfigService.ServerHostName,
                                sizeof(ConfigService.ServerHostName),
                                &ConfigService.ServerPort,
                                &ConfigService.GenericService);
         if (retval == -1)
         {
            ServiceReportProblem (slptr, "invalid service specification", 0);
            continue;
         }

         if (!ProtocolHttpsAvailable &&
             ConfigService.RequestScheme == SCHEME_HTTPS)
         {
            ServiceReportProblem (slptr, "SSL not available", 0);
            continue;
         }

         ServiceLooksValid = true;
         continue;
      }

      /**********************/
      /* service directives */
      /**********************/

      /* ignore all directives unless the server specification looks ok */
      if (!ServiceLooksValid) continue;

      if (*cptr == '[')
      {
         cptr++;
         zptr = (sptr = slptr->DirectiveName) + sizeof(slptr->DirectiveName)-1;
         while (*cptr && *cptr != ']' && sptr < zptr) *sptr++ = *cptr++;
         *sptr = '\0';
         if (*cptr != ']')
         {
            ServiceReportProblem (slptr, "missing \']\'?", 0);
            continue;
         }
         if (Debug) fprintf (stdout, "|%s|\n", slptr->DirectiveName);
         cptr++;
         while (*cptr && ISLWS(*cptr)) cptr++;
      }

      if (strsame (slptr->DirectiveName, "ServiceBodyTag", -1))
         ServiceSetString (slptr, cptr,
                          ConfigService.BodyTag,
                          sizeof(ConfigService.BodyTag));
      else
      if (strsame (slptr->DirectiveName, "ServiceErrorReportPath", -1))
         ServiceSetString (slptr, cptr,
                          ConfigService.ErrorReportPath,
                          sizeof(ConfigService.ErrorReportPath));
      else
      if (strsame (slptr->DirectiveName, "ServiceIPaddress", -1))
         ServiceSetString (slptr, cptr,
                          ConfigService.SuppliedIpAddressString,
                          sizeof(ConfigService.SuppliedIpAddressString));
      else
      if (strsame (slptr->DirectiveName, "ServiceNoLog", -1))
         ConfigService.NoLog = ServiceSetBoolean (slptr, cptr);
      else
      if (strsame (slptr->DirectiveName, "ServiceNoTrack", -1))
         ConfigService.SetNoTrack = ServiceSetBoolean (slptr, cptr);
      else
      if (strsame (slptr->DirectiveName, "ServiceProxy", -1))
         ConfigService.ProxyService = ServiceSetBoolean (slptr, cptr);
      else
      if (strsame (slptr->DirectiveName, "ServiceProxyAuth", -1))
      {
         ServiceSetString (slptr, cptr, String, sizeof(String));
         if (!String[0] || strsame (String, "none", -1))
            ConfigService.ProxyAuthRequired = 
               ConfigService.LocalAuthRequired = false;
         else
         if (strsame (String, "PROXY", -1))
            ConfigService.ProxyAuthRequired = true;
         else
         if (strsame (String, "LOCAL", -1))
            ConfigService.LocalAuthRequired = true;
         else
            ServiceReportProblem (slptr, "unknown authorization parameter", 0);
      }
      else
      if (strsame (slptr->DirectiveName, "ServiceProxyCache", -1))
         ConfigService.ProxyFileCacheEnabled = ServiceSetBoolean (slptr, cptr);
      else
      if (strsame (slptr->DirectiveName, "ServiceProxyChain", -1))
         ServiceSetString (slptr, cptr,
                           ConfigService.ProxyChainHostPort,
                           sizeof(ConfigService.ProxyChainHostPort));
      else
      if (strsame (slptr->DirectiveName, "ServiceProxySSL", -1))
         ConfigService.ConnectService = ServiceSetBoolean (slptr, cptr);
      else
      if (strsame (slptr->DirectiveName, "ServiceProxyTrack", -1))
         ConfigService.SetProxyTrack = ServiceSetBoolean (slptr, cptr);
      else
      if (strsame (slptr->DirectiveName, "ServiceSSLcert", -1))
         ServiceSetString (slptr, cptr,
                           ConfigService.SSLcert,
                           sizeof(ConfigService.SSLcert));
      else
      if (strsame (slptr->DirectiveName, "ServiceSSLkey", -1))
         ServiceSetString (slptr, cptr,
                           ConfigService.SSLkey,
                           sizeof(ConfigService.SSLkey));
      else
         ServiceReportProblem (slptr, "?", 0);
   }

   if (status == RMS$_EOF) status = SS$_NORMAL;

   /*************************/
   /* close the config file */
   /*************************/

   sys$close (&ConfigFileOds.Fab, 0, 0); 

   /* if previous valid service add this to the list */
   if (ServiceLooksValid)
   {
      status = ServiceConfigAdd (slptr, &ConfigService);
      if (Debug) fprintf (stdout, "ServiceConfigAdd() %%X%08.08X\n", status);
      if (VMSnok (status))
         ServiceReportProblem (slptr, "cannot configure service", 0);
   }

#ifdef DBUG
   Debug = DebugBuffer;
#endif

   if (VMSnok (status))
   {
      if (slptr->RequestPtr)
      {
         ServiceReportProblem (slptr, NULL, status);
         return;
      }
      else
         ErrorExitVmsStatus (status, CONFIG_SERVICE_FILE_NAME, FI_LI);
   }

   if (slptr == &ServiceLoad)
   {
      /* configuring at server startup */
      if (!ServiceLoad.ServiceCount)
         ErrorExitVmsStatus (0, "No service specified!", FI_LI);

      ServiceListHead = ServiceLoad.ListHead;
      ServiceListTail = ServiceLoad.ListTail;
      ServiceCount = ServiceLoad.ServiceCount;
   }
}

/*****************************************************************************/
/*
Add the service to the loaded list.
*/

int ServiceConfigAdd
(
struct ServiceLoadStruct *slptr,
struct ServiceStruct *svptr
)
{
   static boolean  SetOfficialServer;

   int  status;
   struct ServiceStruct *nsvptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ServiceConfigAdd()\n");

   status = NetHostNameLookup (svptr->ServerHostName,
                               svptr->ServerPort,
                               svptr->SuppliedIpAddressString,
                               &svptr->ServerHostName,
                               &svptr->ServerHostPort,
                               &svptr->ServerIpAddressString,
                               &svptr->ServerIpAddress);
   if (Debug) fprintf (stdout, "NetHostNameLookup() %%X%08.08X\n", status);
   if (VMSnok (status)) return (status);

   /************************/
   /* check/set parameters */
   /************************/

   svptr->ServerHostNameLength = strlen(svptr->ServerHostName);
   sprintf (svptr->ServerPortString, "%d", svptr->ServerPort); 

   if (svptr->RequestScheme == SCHEME_HTTPS)
      svptr->RequestSchemeNamePtr = "https:";
   else
      svptr->RequestSchemeNamePtr = "http:";

   if (!svptr->ListenBacklog)
      svptr->ListenBacklog = Config.cfServer.ListenBacklog;
   if (!svptr->ListenBacklog)
      svptr->ListenBacklog = DEFAULT_LISTEN_BACKLOG;

   /*
      By default proxy services have tracking disabled, others enabled.
      Explicitly enabling tracking for a service overrides this for both.
      Explicitly disabling tracking for a service overrides this for both.
   */
   if (Config.cfTrack.Enabled)
   {
      if (svptr->RequestScheme == SCHEME_HTTP &&
          !svptr->ProxyService &&
          !svptr->ConnectService)
         svptr->TrackEnabled = true;
      if (svptr->ProxyService && svptr->SetProxyTrack)
         svptr->TrackEnabled = true;
      if (svptr->SetNoTrack) svptr->TrackEnabled = false;
   }

   if (!svptr->ErrorReportPath[0])
      strzcpy (svptr->ErrorReportPath,
               Config.cfReport.ErrorReportPath,
               sizeof(svptr->ErrorReportPath));

   /*****************************/
   /* proxy service information */
   /*****************************/

   if (svptr->ProxyService || svptr->ConnectService)
   {
      if (svptr->ProxyChainHostName[0])
      {
         status = NetHostNameLookup (svptr->ProxyChainHostName,
                                     svptr->ProxyChainPort,
                                     "",
                                     &svptr->ProxyChainHostName,
                                     &svptr->ProxyChainHostPort,
                                     &svptr->ProxyChainIpAddressString,
                                     &svptr->ProxyChainIpAddress);
         if (Debug)
            fprintf (stdout, "NetHostNameLookup() %%X%08.08X\n", status);
         if (VMSnok (status)) return (status);

         svptr->ProxyChainHostNameLength = strlen(svptr->ProxyChainHostName);
         sprintf (svptr->ProxyChainPortString, "%d", svptr->ProxyChainPort);
      }
   }

   /***************************************/
   /* allocate memory add and new service */
   /***************************************/

   /* copy the filled-out service structure into an in-list structure */
   nsvptr = VmGet (sizeof (struct ServiceStruct));
   if (Debug) fprintf (stdout, "nsvptr: %d\n", nsvptr);
   memcpy (nsvptr, svptr, sizeof(struct ServiceStruct));
   if (slptr->ListHead == NULL)
      slptr->ListHead = slptr->ListTail = nsvptr;
   else
   {
      slptr->ListTail->NextPtr = nsvptr;
      slptr->ListTail = nsvptr;
   }
   nsvptr->NextPtr = NULL;

   slptr->ServiceCount++;

   /*********/
   /* other */
   /*********/

   /* process name, etc., generated from the primary port */
   if (!SetOfficialServer)
   {
      /* the host and port for the "official" server */
      SetOfficialServer = ServerPort = svptr->ServerPort;
      sprintf (ServerHostPort, "%s:%d", ServerHostName, ServerPort);
      if (Debug) fprintf (stdout, "|%s|\n", ServerHostPort);
   }

   if (svptr->RequestScheme == SCHEME_HTTPS)
      if (ProtocolHttpsAvailable)
         ProtocolHttpsConfigured = true;

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Parse a HTTP scheme, host name, and integer port number from a string. 
Defaults apply to missing components.  Some basic checking is performed on the
components.  Return the number of characters scanned from the string, or -1 to
indicate a fatal error.
*/ 

int ServiceParse
(
char *SourceString,
int *SchemeValuePtr,
char *HostNamePtr,
int SizeOfHostName,
int *PortNumberPtr,
boolean *GenericServicePtr
)
{
   boolean  IsHost;
   char  *cptr, *sptr, *tptr, *zptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ServiceParse() |%s|\n", SourceString);

   *SchemeValuePtr = *PortNumberPtr = 0;
   *HostNamePtr = '\0';
   *GenericServicePtr = false;

   cptr = SourceString;

   if (strsame (cptr, "http:", 5))
   {
      *SchemeValuePtr = SCHEME_HTTP;
      cptr += 5;
   }
   else
   if (strsame (cptr, "https:", 6))
   {
      *SchemeValuePtr = SCHEME_HTTPS;
      cptr += 6;
   }
   else
   {
      /* if it looks like an incorrect scheme specification */
      for (tptr = cptr; *tptr && *tptr != '.' && *tptr != ':'; tptr++);
      if (tptr[0] == ':' && !isdigit(tptr[1])) return (-1);
      /* otherwise it defaults to */
      *SchemeValuePtr = SCHEME_HTTP;
   }

   if (*cptr == '/') cptr++;
   if (*cptr == '/') cptr++;

   if (isdigit(*cptr))
   {
      /* check if it's a dotted-decimal address */
      for (tptr = cptr; *tptr && isdigit(*tptr); tptr++);
      if (*tptr == '.')
      {
         /* dotted decimal address */
         zptr = (sptr = HostNamePtr) + SizeOfHostName;
         while (*cptr && (*cptr == '.' || isdigit(*cptr)) && sptr < zptr)
            *sptr++ = *cptr++;
         if (sptr >= zptr) return (-1);
         *sptr = '\0';
      }
   }
   else
   if (*cptr == '*')
   {
      /* generic service */
      while (*cptr && *cptr == '*') cptr++;
   }
   else
   {
      /* alphanumeric host name */
      zptr = (sptr = HostNamePtr) + SizeOfHostName;
      while (*cptr && (*cptr == '*' || *cptr == '.' || isalnum(*cptr) ||
                       *cptr == '-' || *cptr == '_') && sptr < zptr)
         *sptr++ = *cptr++;
      if (sptr >= zptr) return (-1);
      *sptr = '\0';
   }
   if (!HostNamePtr[0])
   {
      /* none or generic specified, default to primary server name */
      *GenericServicePtr = true;
      zptr = (sptr = HostNamePtr) + SizeOfHostName;
      for (tptr = ServerHostName; *tptr && sptr < zptr; *sptr++ = *tptr++);
      if (sptr >= zptr) return (-1);
      *sptr = '\0';
   }

   if (*cptr == ':' || isdigit(*cptr))
   {
      /* IP port */
      if (*cptr == ':') cptr++;
      *PortNumberPtr = atol(cptr);
      while (*cptr && isdigit(*cptr)) cptr++;
      if (*PortNumberPtr <= 0 || *PortNumberPtr > 65535) return (-1);
   }
   else
   if (*SchemeValuePtr == SCHEME_HTTPS)
      *PortNumberPtr = DEFAULT_HTTPS_PORT;
   else
      *PortNumberPtr = DEFAULT_HTTP_PORT;

   if (Debug)
      fprintf (stdout, "%d|%s|%d\n",
               *SchemeValuePtr, HostNamePtr, *PortNumberPtr);

   return (cptr - SourceString);
}

/*****************************************************************************/
/*
Return SERVICE_ specific values equivalent to the string pointed to by 'pptr'.
*/

boolean ServiceSetBoolean
(
struct ServiceLoadStruct *slptr,
char *pptr
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ServiceSetBoolean() |%s|\n", pptr);

   if (strsame (pptr, "YES", 3) ||
       strsame (pptr, "ON", 2) ||
       strsame (pptr, "ENABLED", 7))
      return (true);

   if (strsame (pptr, "NO", 2) ||
       strsame (pptr, "OFF", 3) ||
       strsame (pptr, "DISABLED", 8))
      return (false);

   ServiceReportProblem (slptr, NULL, 0);
   return (false);
}

/*****************************************************************************/
/*
Return an integer equivalent to the numeric string pointed to by 'pptr'.
*/

int ServiceSetInteger
(
struct ServiceLoadStruct *slptr,
char *pptr
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ServiceSetInteger() |%s|\n", pptr);

   if (isdigit(*pptr)) return (atoi(pptr));
   if (!*pptr) return (0);
   ServiceReportProblem (slptr, NULL, 0);
   return (-1);
}

/*****************************************************************************/
/*
Copy a simple string configuration parameter trimming leadin and trailing
white-space.
*/

ServiceSetString
(
struct ServiceLoadStruct *slptr,
char *pptr,
char *String,
int SizeOfString
)
{
   char  *sptr, *zptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ServiceSetString() |%s|\n", pptr);

   zptr = (sptr = String) + SizeOfString;
   while (*pptr && ISLWS(*pptr)) pptr++;
   while (*pptr && sptr < zptr) *sptr++ = *pptr++;
   if (sptr >= zptr)
   {
      *String = '\0';
      ServiceReportProblem (slptr, NULL, 0);
      return;
   }
   *sptr = '\0';
   if (sptr > String)
   {
      sptr--;
      while (*sptr && ISLWS(*sptr) && sptr > String) sptr--;
      *++sptr = '\0';
   }
}

/*****************************************************************************/
/*
This function formats an error report.  All lines are concatenated onto a
single string of dynamically allocated memory that (obviously) grows as
reports are added to it.  This string is then output if loading the server
configuration or is available for inclusion in an HTML page.
*/

ServiceReportProblem
(
struct ServiceLoadStruct *slptr,
char *Explanation,
int StatusValue
)
{
   int  status;
   unsigned short  Length;
   char  Buffer [512];

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ServiceReportProblem() |%s| %08.08X\n",
               Explanation, StatusValue);

   slptr->ProblemCount++;

   if (Explanation == NULL)
      Explanation = "problem";
   else
   if (Explanation[0] == '?')
      Explanation = "directive unknown";

   /* a little more elbow room please */
   if (StatusValue)
      status = WriteFao (Buffer, sizeof(Buffer), &Length,
                         "%!%M\n \\!AZ\\\n",
                         StatusValue, Explanation);
   else
      status = WriteFao (Buffer, sizeof(Buffer), &Length,
                         "%HTTPD-W-SERVICE, \"!AZ\" !AZ at line !UL\n",
                         slptr->DirectiveName, Explanation, slptr->LineNumber);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
      ErrorExitVmsStatus (status, "WriteFao()", FI_LI);
   if (Debug) fprintf (stdout, "|%s|\n", Buffer);

   if (slptr->RequestPtr == NULL) fputs (Buffer, stdout);

   slptr->ProblemReportPtr =
      VmRealloc (slptr->ProblemReportPtr,
                 slptr->ProblemReportLength+Length+1, FI_LI);

   /* include the terminating null */
   memcpy (slptr->ProblemReportPtr+slptr->ProblemReportLength,
           Buffer, Length+1);
   slptr->ProblemReportLength += Length;
}

/*****************************************************************************/
/*
Parse the 'Service's parameter to determine which host(s)/port(s) services need
to be provided for.  This is a comma-separated list with no white-space.  The
service information may comprise of the following optional components:
"[scheme://][host][:port][;ip=address][;proxy][;chain=server][;cert=file]".
*/ 

ServiceConfigFromString ()

{
   struct ServiceStruct *svptr;
   struct ServiceStruct  ConfigService;

   boolean  ConnectService,
            LocalAuthRequired,
            ProxyAuthRequired,
            ProxyService,
            ProxyServiceFileCache,
            TrackEnabled,
            TrackDisabled;

   int  status,
        DummyRequestScheme,
        Length,
        ListenBacklog;

   char  *cptr, *sptr, *zptr;

   char  SSLcert [sizeof(svptr->SSLcert)],
         SSLcipherList [sizeof(svptr->SSLcipherList)],
         SSLkey [sizeof(svptr->SSLkey)],
         SuppliedIpAddressString [sizeof(svptr->SuppliedIpAddressString)];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ServiceConfigFromString()\n");

   ServiceLoadFromConfigFile = false;

   if (CliServices[0])
      cptr = CliServices;
   else
   if (Config.cfServer.ServicePtr == NULL)
      sprintf (cptr = CliServices, "%s:%d", ServerHostName, ServerPort);
   else
      cptr = Config.cfServer.ServicePtr;

   /******************************/
   /* parse comma-separated list */
   /******************************/

   while (*cptr)
   {
      while (*cptr && (ISLWS(*cptr) || *cptr == ',')) cptr++;
      if (!*cptr) break;
      if (Debug) fprintf (stdout, "|%s|\n", cptr);

      memset (&ConfigService, 0, sizeof(ConfigService));

      /*************************/
      /* service specification */
      /*************************/

      Length = ServiceParse (cptr,
                             &ConfigService.RequestScheme,
                             &ConfigService.ServerHostName,
                             sizeof(ConfigService.ServerHostName),
                             &ConfigService.ServerPort,
                             &ConfigService.GenericService);
      if (Length < 0) ErrorExitVmsStatus (0, ErrorServiceList, FI_LI);
      cptr += Length;

      if (!ProtocolHttpsAvailable &&
          ConfigService.RequestScheme == SCHEME_HTTPS)
      {
         WriteFaoStdout (
"%!AZ-W-SERVICE, SSL not available, service ignored\n \\!AZ//!AZ:!UL\\\n",
            Utility, ConfigService.RequestSchemeNamePtr,
                     ConfigService.ServerHostPort);
         continue;
      }

      if (ConfigService.RequestScheme == SCHEME_HTTPS)
         ConfigService.RequestSchemeNamePtr = "https:";
      else
         ConfigService.RequestSchemeNamePtr = "http:";

      /****************************/
      /* other service parameters */
      /****************************/

      if (*cptr == ';')
      {
         while (*cptr == ';')
         {
            if (strsame (cptr, ";backlog=", 9))
            {
               cptr += 9;
               ConfigService.ListenBacklog = atoi(cptr);
               while (*cptr && (isdigit(*cptr) || *cptr == ';')) cptr++;
            }
            else
            if (strsame (cptr, ";cache", 6))
            {
               ConfigService.ProxyFileCacheEnabled = true;
               cptr += 6;
            }
            else
            if (strsame (cptr, ";cert=", 6))
            {
               cptr += 6;
               zptr = (sptr = ConfigService.SSLcert) +
                      sizeof(ConfigService.SSLcert);
               while (*cptr && !ISLWS(*cptr) &&
                      *cptr != ',' && *cptr != ';' && sptr < zptr)
                  *sptr++ = toupper(*cptr++);
               if (sptr >= zptr)
                  ErrorExitVmsStatus (0, ErrorServiceList, FI_LI);
               *sptr = '\0';
            }
            else
            if (strsame (cptr, ";chain=", 7))
            {
               cptr += 7;
               Length = ServiceParse (cptr,
                                      &DummyRequestScheme,
                                      &ConfigService.ProxyChainHostName,
                                      sizeof(ConfigService.ProxyChainHostName),
                                      &ConfigService.ProxyChainPort,
                                      &ConfigService.GenericService);
               if (Length < 0) ErrorExitVmsStatus (0, ErrorServiceList, FI_LI);
               cptr += Length;
            }
            else
            if (strsame (cptr, ";connect", 8))
            {
               ConfigService.ConnectService = true;
               cptr += 8;
            }
            else
            if (strsame (cptr, ";cipher=", 5))
            {
               while (*cptr && *cptr != '=') cptr++;
               if (*cptr) cptr++;
               zptr = (sptr = ConfigService.SSLcipherList) +
                      sizeof(ConfigService.SSLcipherList);
               while (*cptr && !ISLWS(*cptr) && *cptr != ',' && sptr < zptr)
                  *sptr++ = *cptr++;
               if (sptr >= zptr)
                  ErrorExitVmsStatus (0, ErrorServiceList, FI_LI);
               *sptr = '\0';
            }
            else
            if (strsame (cptr, ";ip=", 4))
            {
               cptr += 4;
               zptr = (sptr = ConfigService.SuppliedIpAddressString) +
                       sizeof(ConfigService.SuppliedIpAddressString);
               while (*cptr && !ISLWS(*cptr) && *cptr != ',' && sptr < zptr)
                  *sptr++ = *cptr++;
               if (sptr >= zptr)
                  ErrorExitVmsStatus (0, ErrorServiceList, FI_LI);
               *sptr = '\0';
            }
            else
            if (strsame (cptr, ";key=", 5))
            {
               while (*cptr && *cptr != '=') cptr++;
               if (*cptr) cptr++;
               zptr = (sptr = ConfigService.SSLkey) +
                      sizeof(ConfigService.SSLkey);
               while (*cptr && !ISLWS(*cptr) && *cptr != ',' && sptr < zptr)
                  *sptr++ = toupper(*cptr++);
               if (sptr >= zptr)
                  ErrorExitVmsStatus (0, ErrorServiceList, FI_LI);
               *sptr = '\0';
            }
            else
            if (strsame (cptr, ";lauth", 6))
            {
               ConfigService.LocalAuthRequired = true;
               cptr += 6;
            }
            else
            if (strsame (cptr, ";pauth", 6))
            {
               ConfigService.ProxyAuthRequired = true;
               cptr += 6;
            }
            else
            if (strsame (cptr, ";proxy", 6))
            {
               ConfigService.ProxyService = true;
               cptr += 6;
            }
            else
            if (strsame (cptr, ";track", 6))
            {
               ConfigService.SetProxyTrack = true;
               cptr += 6;
            }
            else
            if (strsame (cptr, ";notrack", 8))
            {
               ConfigService.SetNoTrack = true;
               cptr += 8;
            }
            else
            {
               if (*cptr == ';') cptr++;
               sptr = cptr;
               while (*sptr && *sptr != ';' && *sptr != ',') sptr++;
               WriteFaoStdout (
                  "%!AZ-W-SERVICE, unknown parameter, ignored\n \\!#AZ\\\n",
                  Utility, sptr-cptr, cptr);
               cptr = sptr;
            }
         }
      }

      /***************/
      /* add service */
      /***************/

      status = ServiceConfigAdd (&ServiceLoad, &ConfigService);
      if (Debug) fprintf (stdout, "ServiceConfigAdd() %%X%08.08X\n", status);
      if (VMSnok (status))
      {
         WriteFaoStdout (
            "%!AZ-W-SERVICE, cannot configure service\n \\!AZ//!AZ\\\n",
            Utility, ConfigService.RequestSchemeNamePtr,
                     ConfigService.ServerHostPort);
         continue;
      }

      if (Debug) fprintf (stdout, "cptr |%s|\n", cptr);
      if (*cptr && *cptr != ',')
         ErrorExitVmsStatus (0, ErrorServiceList, FI_LI);
   }

   if (!ServiceLoad.ServiceCount)
      ErrorExitVmsStatus (0, "No service specified!", FI_LI);

   ServiceListHead = ServiceLoad.ListHead;
   ServiceListTail = ServiceLoad.ListTail;
   ServiceCount = ServiceLoad.ServiceCount;
}

/*****************************************************************************/
/*
Output string configured services (called from ConfigReportNow()).
*/ 

int ServiceReportConfigFromString
(
struct RequestStruct *rqptr,
struct ConfigStruct *cfptr
)
{
   static char  ServicesFao [] = 
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Service</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n";

   static char  ServiceLoadFao [] =
"<TR><TH ALIGN=center>(see &quot;Services&quot; report)</TH></TR>\n";

   static char  ServiceNoneFao [] =
"<TR><TD><FONT SIZE=-1><I>(none)</I></FONT></TD></TR>\n";

   static char  OneServiceFao [] =
"<TR><TH ALIGN=right>!UL.&nbsp;</TH>\
<TD><TT>!AZ//!AZ!AZ!%%!AZ!%%!%%!AZ!AZ!AZ!AZ</TT></TD>\
<TD>&nbsp;<TT>!AZ</TT></TD></TR>\n";

   static char  ServiceListFao [] =
"<TR><TH ALIGN=right>!UL.&nbsp;</TH><TD><TT>!AZ<TT></TD></TR>\n";

   static char  EndServicesFao [] =
"<TR><TD COLSPAN=2>\
<NOBR><B>Service Not Found URL:&nbsp;</B></NOBR>!AZ\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n";

   static char  NotNoneFao [] = "<FONT SIZE=-1><I>(none)</I></FONT>\n";

   int  status,
        ServiceListCount;
   unsigned long  FaoVector [32];
   char  *cptr, *sptr;
   unsigned long  *vecptr;
   struct ServiceStruct  *svptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ServiceReportConfigFromString()\n");

   status = NetWriteFaol (rqptr, ServicesFao, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   if (ServiceLoadFromConfigFile)
   {
      status = NetWriteFaol (rqptr, ServiceLoadFao, NULL);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }
   else
   if (cfptr->cfServer.ServicePtr == NULL)
   {
      status = NetWriteFaol (rqptr, ServiceNoneFao, NULL);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }
   else
   if (cfptr != &Config)
   {
      ServiceListCount = 1;
      for (cptr = cfptr->cfServer.ServicePtr; *cptr; cptr++)
      {
         sptr = cptr;
         vecptr = FaoVector;
         *vecptr++ = ServiceListCount++;
         *vecptr++ = sptr;
         while (*cptr && *cptr != ',') cptr++;
         if (*cptr)
         {
            *cptr = '\0';
            status = NetWriteFaol (rqptr, ServiceListFao, &FaoVector);
            if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
            *cptr = ',';
         }
         else
         {
            status = NetWriteFaol (rqptr, ServiceListFao, &FaoVector);
            if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
         }
      }
   }
   else
   {
      ServiceListCount = 1;
      for (svptr = ServiceListHead; svptr != NULL; svptr = svptr->NextPtr)
      {
         vecptr = FaoVector;

         *vecptr++ = ServiceListCount++;
         *vecptr++ = svptr->RequestSchemeNamePtr;
         *vecptr++ = svptr->ServerHostPort;

         if (svptr->ProxyFileCacheEnabled)
            *vecptr++ = ";cache";
         else
            *vecptr++ = "";
         if (svptr->ProxyChainHostPort[0])
         {
            *vecptr++ = ";chain=!AZ";
            *vecptr++ = svptr->ProxyChainHostPort;
         }
         else
            *vecptr++ = "";
         if (svptr->ConnectService)
            *vecptr++ = ";connect";
         else
            *vecptr++ = "";
         if (svptr->SuppliedIpAddressString[0])
         {
            *vecptr++ = ";ip=!AZ";
            *vecptr++ = svptr->SuppliedIpAddressString;
         }
         else
            *vecptr++ = "";
         if (svptr->ListenBacklog != DEFAULT_LISTEN_BACKLOG)
         {
            *vecptr++ = ";backlog=!UL";
            *vecptr++ = svptr->ListenBacklog;
         }
         else
            *vecptr++ = "";
         if (svptr->LocalAuthRequired)
            *vecptr++ = ";lauth";
         else
            *vecptr++ = "";
         if (svptr->ProxyAuthRequired)
            *vecptr++ = ";pauth";
         else
            *vecptr++ = "";
         if (svptr->ProxyService)
            *vecptr++ = ";proxy";
         else
            *vecptr++ = "";
         if (svptr->TrackEnabled)
            *vecptr++ = ";track";
         else
            *vecptr++ = "";

         *vecptr++ = svptr->ServerIpAddressString;

         status = NetWriteFaol (rqptr, OneServiceFao, &FaoVector);
         if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      }
   }

   vecptr = FaoVector;
   if (cfptr->cfServer.ServiceNotFoundUrl[0])
      *vecptr++ = cfptr->cfServer.ServiceNotFoundUrl;
   else
      *vecptr++ = NotNoneFao;

   status = NetWriteFaol (rqptr, EndServicesFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Parse a host name, integer port number, supplied IP address from a string. Any
comma or  semi-colon will terminate the host name/port.  Return the number of
characters scanned from the string, or -1 to indicate a fatal error.
*/ 

int NetParseHostString
(
char *SourceString,
char *HostNamePtr,
int SizeOfHostName,
int *PortNumberPtr
)
{
   boolean  IsHost;
   char  *cptr, *sptr, *zptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetParseHostString() |%s|\n", SourceString);

   cptr = SourceString;

   IsHost = false;
   if (isdigit(*cptr))
   {
      /* check it's not a dotted-decimal address */
      while (*cptr && *cptr != '.' && *cptr != ',' &&
             *cptr != ':' && *cptr != ';') cptr++;
      if (*cptr == '.') IsHost = true;
      cptr = SourceString;
   }
   else
   if (isalpha(*cptr))
      IsHost = true;

   if (IsHost)
   {
      /* IP host name */
      zptr = (sptr = HostNamePtr) + SizeOfHostName;
      while (*cptr &&  *cptr != ',' && *cptr != ':' &&
             *cptr != ';' && sptr < zptr)
         *sptr++ = *cptr++;
      if (sptr >= zptr) return (-1);
      *sptr = '\0';
   }
   else
      *HostNamePtr = '\0';

   if (*cptr == ':' || isdigit(*cptr))
   {
      /* IP port */
      if (*cptr == ':') cptr++;
      *PortNumberPtr = atol(cptr);
      while (*cptr && isdigit(*cptr)) cptr++;
   }
   else
      *PortNumberPtr = 0;

   return (cptr - SourceString);
}

/*****************************************************************************/
/*
A server administration report on the server's configuration. This function
just wraps the reporting function, loading a temporary database if necessary
for reporting from the configuration file.
*/ 

ServiceReport
(
struct RequestStruct *rqptr,
void *NextTaskFunction,
boolean  UseServerDatabase
)
{
   int  status;
   struct ServiceLoadStruct  LocalServiceLoad;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ServiceReport()\n");

   if (UseServerDatabase)
   {
      if (!ServiceLoadFromConfigFile)
      {
         /* services specified via HTTPD$CONFIG [Service] so just fudge it */
         ServiceLoad.RequestPtr = rqptr;
         ServiceLoad.ListHead = ServiceListHead;
      }
      ServiceReportNow (rqptr, &ServiceLoad);
   }
   else
   {
      memset (&LocalServiceLoad, 0, sizeof(LocalServiceLoad));
      /* indicate it's being used for a report */
      LocalServiceLoad.RequestPtr = rqptr;
      ServiceConfigLoad (&LocalServiceLoad);
      if (ServiceLoadFromConfigFile)
      {
         ServiceReportNow (rqptr, &LocalServiceLoad);
         if (LocalServiceLoad.ProblemReportPtr != NULL)
            VmFree (LocalServiceLoad.ProblemReportPtr, FI_LI);
      }
      else
      {
         rqptr->rqResponse.HttpStatus = 500;
         ErrorGeneral (rqptr, ErrorServiceConfigFile, FI_LI);
      }
   }

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Return a report on the HTTPd service configuration ... now!  This function
blocks while executing.
*/ 

ServiceReportNow
(
struct RequestStruct *rqptr,
struct ServiceLoadStruct *slptr
)
{
/* macro to push booleans onto the parameter list */
#define REPBOOL_ENDIS(b) \
if (b) *vecptr++ = "[enabled]"; else *vecptr++ = "[disabled]";

   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Service Report</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Service Report</H3>\n\
!20%W\n";

   static char  ProblemReportFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH><FONT COLOR=\"#ff0000\">!UL Report!%s \
!%?At Startup\rDuring Load\r</FONT></TH></TR>\n\
<TR><TD><PRE>!AZ</PRE></TD></TR>\n\
</TABLE>\n";

   static char  ReportSourceFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Source: &quot;!%?Server\rFile\r&quot;</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>File:</TH>\
<TD ALIGN=left>!AZ</TD>\
<TD>&nbsp;</TD><TH>[<A HREF=\"!AZ\">View</A>]</TH>\
<TH>[<A HREF=\"!AZ!AZ\">Edit</A>]</TH>\
</TR>\n\
<TR><TH ALIGN=right>!AZ</TH>\
<TD ALIGN=left>!20%W</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n";

   static char  ReportServiceFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>&nbsp;&nbsp;!UL&nbsp;&nbsp;-&nbsp;&nbsp;\
!AZ//!AZ&nbsp;&nbsp;</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0>\n\
<TR><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>Using IP Address:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Specified IP Address:</TH><TD>!AZ</TD></TR>\n";

   static char  ReportSesolaFao [] =
"<TR><TH ALIGN=right>SSL Certificate:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>SSL Private Key:</TH><TD>!AZ</TD></TR>\n";

   static char  ReportProxyFao [] =
"<TR><TD HEIGHT=3></TD></TR>\n\
<TR><TH ALIGN=right>Proxy:</TH><TD>!AZ</TD></TR>\n";

   static char  ReportProxyDetailsFao [] =
"<TR><TH ALIGN=right>Proxy SSL:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Proxy Cache:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Proxy Authorization:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Proxy Chain:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Proxy Track:</TH><TD>!AZ</TD></TR>\n";

   static char  ReportOtherFao [] =
"<TR><TD HEIGHT=3></TD></TR>\n\
<TR><TH ALIGN=right>NoLog:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>NoTrack:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Body Tag:</TH><TD COLSPAN=2>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Report Path:</TH><TD COLSPAN=2>!AZ</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n";

   static char  EndPageFao [] =
"</TABLE>\n\
</BODY>\n\
</HTML>\n";

   static char  ReportDefault [] = "<I>(default)</I>",
                ReportNotNone [] = "<I>(none)</I>",
                ReportServiceNoneFao [] = "<I>(no services defined)</I>";

   int  idx, status,
        ServiceListCount;
   unsigned long  *vecptr;
   unsigned long  FaoVector [64];
   char  *cptr, *sptr, *zptr;
   struct ServiceStruct  *svptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ServiceReportNow()\n");

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;
   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = &rqptr->rqTime.Vms64bit;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   if (slptr->ProblemReportLength)
   {
      vecptr = FaoVector;
      *vecptr++ = slptr->ProblemCount;
      *vecptr++ = (slptr == &ServiceLoad);
      if (ServiceConfigFileDefined)
         *vecptr++ = slptr->ProblemReportPtr;
      else
         *vecptr++ = ErrorServiceConfigFile;

      status = NetWriteFaol (rqptr, ProblemReportFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   if (ServiceConfigFileDefined)
   {
      cptr = MapVmsPath (slptr->LoadFileName, rqptr);

      vecptr = FaoVector;

      /* source file */
      *vecptr++ = (slptr == &ServiceLoad);
      *vecptr++ = slptr->LoadFileName;
      *vecptr++ = cptr;
      *vecptr++ = ADMIN_SCRIPT_UPD;
      *vecptr++ = cptr;
      if (slptr == &ServiceLoad)
      {
         *vecptr++ = "Loaded:";
         *vecptr++ = &slptr->LoadBinTime;
      }
      else
      {
         *vecptr++ = "Revised:";
         *vecptr++ = &slptr->RevBinTime;
      }

      status = NetWriteFaol (rqptr, ReportSourceFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   /************/
   /* services */
   /************/

   if (slptr->ListHead == NULL)
   {
      status = NetWriteFaol (rqptr, ReportServiceNoneFao, NULL);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }
   else
   {
      ServiceListCount = 0;
      for (svptr = slptr->ListHead;
           svptr != NULL;
           svptr = svptr->NextPtr)
      {
         vecptr = FaoVector;

         *vecptr++ = ++ServiceListCount;
         *vecptr++ = svptr->RequestSchemeNamePtr;
         *vecptr++ = svptr->ServerHostPort;
         *vecptr++ = svptr->ServerIpAddressString;

         if (svptr->SuppliedIpAddressString[0])
            *vecptr++ = svptr->SuppliedIpAddressString;
         else
            *vecptr++ = ReportNotNone;

         status = NetWriteFaol (rqptr, ReportServiceFao, &FaoVector);
         if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

         if (svptr->RequestScheme == SCHEME_HTTPS)
         {
            vecptr = FaoVector;

            if (svptr->SSLcert[0])
               *vecptr++ = svptr->SSLcert;
            else
               *vecptr++ = ReportDefault;
            if (svptr->SSLkey[0])
               *vecptr++ = svptr->SSLkey;
            else
               *vecptr++ = ReportDefault;

            status = NetWriteFaol (rqptr, ReportSesolaFao, &FaoVector);
            if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
         }

         vecptr = FaoVector;

         REPBOOL_ENDIS (svptr->ProxyService)

         status = NetWriteFaol (rqptr, ReportProxyFao, &FaoVector);
         if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

         if (svptr->ProxyService)
         {
            vecptr = FaoVector;

            REPBOOL_ENDIS (svptr->ConnectService)
            REPBOOL_ENDIS (svptr->ProxyFileCacheEnabled)
            if (svptr->ProxyAuthRequired)
               *vecptr++ = "PROXY";
            else
            if (svptr->LocalAuthRequired)
               *vecptr++ = "LOCAL";
            else
               *vecptr++ = ReportNotNone;
            if (svptr->ProxyChainHostPort[0])
               *vecptr++ = svptr->ProxyChainHostPort;
            else
               *vecptr++ = ReportNotNone;
            REPBOOL_ENDIS (svptr->ProxyTrack)

            status = NetWriteFaol (rqptr, ReportProxyDetailsFao, &FaoVector);
            if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
         }

         vecptr = FaoVector;

         REPBOOL_ENDIS (svptr->NoLog)
         REPBOOL_ENDIS (svptr->SetNoTrack)
         if (svptr->BodyTag[0])
            *vecptr++ = svptr->BodyTag;
         else
            *vecptr++ = ReportDefault;
         if (svptr->ErrorReportPath[0])
            *vecptr++ = svptr->ErrorReportPath;
         else
            *vecptr++ = ReportDefault;

         status = NetWriteFaol (rqptr, ReportOtherFao, &FaoVector);
         if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      }
   }

   /**************/
   /* end report */
   /**************/

   status = NetWriteFao (rqptr, EndPageFao);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

#undef REPBOOL_ENDIS
}

/*****************************************************************************/
/*
A server administration menu for service configuration. This function just
wraps the revision function, loading a temporary database if necessary for
reporting from the configuration file.
*/ 

ServiceConfigRevise
(
struct RequestStruct *rqptr,
void *NextTaskFunction,
boolean  UseServerDatabase
)
{
   int  status;
   struct ServiceLoadStruct  LocalServiceLoad;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ServiceConfigRevise()\n");

   if (UseServerDatabase)
   {
      if (!ServiceLoadFromConfigFile)
      {
         /* services specified via HTTPD$CONFIG [Service] so just fudge it */
         ServiceLoad.RequestPtr = rqptr;
         ServiceLoad.ListHead = ServiceListHead;
      }
      ServiceConfigReviseNow (rqptr, &ServiceLoad);
   }
   else
   {
      memset (&LocalServiceLoad, 0, sizeof(LocalServiceLoad));
      /* indicate it's being used for a revision */
      LocalServiceLoad.RequestPtr = rqptr;
      ServiceConfigLoad (&LocalServiceLoad);
      if (ServiceLoadFromConfigFile)
      {
         ServiceConfigReviseNow (rqptr, &LocalServiceLoad);
         if (LocalServiceLoad.ProblemReportPtr != NULL)
            VmFree (LocalServiceLoad.ProblemReportPtr, FI_LI);
      }
      else
      {
         rqptr->rqResponse.HttpStatus = 500;
         ErrorGeneral (rqptr, ErrorServiceConfigFile, FI_LI);
      }
   }

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Return a report on the HTTPd service configuration ... now!  This function
blocks while executing.
*/ 

ServiceConfigReviseNow
(
struct RequestStruct *rqptr,
struct ServiceLoadStruct *slptr
)
{
#define CHECKED_RADIO " CHECKED"
#define UNCHECKED_RADIO ""
#define REPBOOL_RADIO(b) \
if (b)\
{\
   *vecptr++ = CHECKED_RADIO;\
   *vecptr++ = UNCHECKED_RADIO;\
}\
else\
{\
   *vecptr++ = UNCHECKED_RADIO;\
   *vecptr++ = CHECKED_RADIO;\
}

   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Service Configuration</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Service Configuration</H3>\n\
!20%W\n";

   static char  ProblemReportFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH><FONT COLOR=\"#ff0000\">!UL Report!%s \
!%?At Startup\rDuring Load\r</FONT></TH></TR>\n\
<TR><TD><PRE>!AZ</PRE></TD></TR>\n\
</TABLE>\n";

   static char  ReviseSourceFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Source: &quot;!%?Server\rFile\r&quot;</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>File:</TH>\
<TD ALIGN=left>!AZ</TD>\
<TD>&nbsp;</TD><TH>[<A HREF=\"!AZ\">View</A>]</TH>\
<TH>[<A HREF=\"!AZ!AZ\">Edit</A>]</TH>\
</TR>\n\
<TR><TH ALIGN=right>!AZ</TH>\
<TD ALIGN=left>!20%W</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<FORM METHOD=POST ACTION=\"!AZ\">\n\
\
<INPUT TYPE=hidden NAME=x VALUE=\"\
# Configuration:  !AZ&#10;\
#                 !AZ&#10;\
# Last Modified:  !20%W&#10;\
#                 !AZ.\'!AZ\'@!AZ&#10;\
\">";

   static char  ReviseServiceNoneFao [] = "<I>(no services defined)</I>";

   static char  ReviseServiceFao [] =
"!AZ\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>!%%!AZ!AZ!AZ</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0>\n\
<TR><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
\
<TR><TH ALIGN=right>Scheme:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[[\">\n\
<INPUT TYPE=radio NAME=ServiceScheme VALUE=\"http:\"!AZ>http\n\
<INPUT TYPE=radio NAME=ServiceScheme VALUE=\"https:\"!AZ>https\n\
</TD></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"//\">\n\
<TR><TH ALIGN=right>Name:</TH><TD>\
<INPUT TYPE=text SIZE=40 NAME=ServiceName VALUE=\"!AZ\">\
</TD></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\":\">\n\
<TR><TH ALIGN=right>Port:</TH><TD>\
<INPUT TYPE=text SIZE=5 NAME=ServicePort VALUE=\"!AZ\">\n\
<INPUT TYPE=hidden NAME=x VALUE=\"]]\">\n\
</TD></TR>\n\
\
<TR><TH ALIGN=right>IP Address:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServiceIPaddress]  \">\n\
<INPUT TYPE=text SIZE=20 NAME=ServiceIPaddress VALUE=\"!AZ\">\n\
<FONT SIZE=-1>(only if NI multi-homed)</FONT></TD></TR>\n";

   static char  ReviseSesolaFao [] =
"<TR><TH ALIGN=right>SSL Certificate:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServiceSSLcert]  \">\n\
<INPUT TYPE=text SIZE=40 NAME=ServiceSSLcert VALUE=\"!AZ\">\n\
</TD></TR>\n\
<TR><TH ALIGN=right>SSL Private Key:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServiceSSLkey]  \">\n\
<INPUT TYPE=text SIZE=40 NAME=ServiceSSLkey VALUE=\"!AZ\">\n\
</TD></TR>\n";

   static char  ReviseProxyFao [] =
"<TR><TD HEIGHT=3></TD></TR>\n\
\
<TR><TH ALIGN=right>Proxy:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServiceProxy]  \">\n\
<INPUT TYPE=radio NAME=ServiceProxy VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ServiceProxy VALUE=disabled!AZ>disabled\n\
</TD></TR>\n";

   static char  ReviseProxyDetailsFao [] =
"<TR><TH ALIGN=right>Proxy SSL:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServiceProxySSL]  \">\n\
<INPUT TYPE=radio NAME=ServiceProxySSL VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ServiceProxySSL VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
\
<TR><TH ALIGN=right>Proxy Cache:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServiceProxyCache]  \">\n\
<INPUT TYPE=radio NAME=ServiceProxyCache VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ServiceProxyCache VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
\
<TR><TH ALIGN=right>Proxy Authorization:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServiceProxyAuth]  \">\n\
<INPUT TYPE=radio NAME=ServiceProxyAuth VALUE=\"none\"!AZ>none\n\
<INPUT TYPE=radio NAME=ServiceProxyAuth VALUE=\"PROXY\"!AZ>PROXY\n\
<INPUT TYPE=radio NAME=ServiceProxyAuth VALUE=\"LOCAL\"!AZ>LOCAL\n\
</TD></TR>\n\
\
<TR><TH ALIGN=right>Proxy Chain:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServiceProxyChain]  \">\n\
<INPUT TYPE=text SIZE=40 NAME=ServiceProxyChain VALUE=\"!AZ\">\n\
</TD></TR>\n\
\
<TR><TH ALIGN=right>Proxy Track:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServiceProxyTrack]  \">\n\
<INPUT TYPE=radio NAME=ServiceProxyTrack VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ServiceProxyTrack VALUE=disabled!AZ>disabled\n\
</TD></TR>\n";

   static char  ReviseOtherFao [] =
"<TR><TD HEIGHT=3></TD></TR>\n\
\
<TR><TH ALIGN=right>NoLog:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServiceNoLog]  \">\n\
<INPUT TYPE=radio NAME=ServiceNoLog VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ServiceNoLog VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
\
<TR><TH ALIGN=right>NoTrack:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServiceNoTrack]  \">\n\
<INPUT TYPE=radio NAME=ServiceNoTrack VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ServiceNoTrack VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
\
<TR><TH ALIGN=right>Body Tag:</TH><TD COLSPAN=2>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServiceBodyTag]  \">\n\
<INPUT TYPE=text size=40 NAME=ServiceBodyTag VALUE=\"!AZ\">\n\
</TD></TR>\n\
\
<TR><TH ALIGN=right>Error Report Path:</TH><TD COLSPAN=2>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServiceErrorReportPath]  \">\n\
<INPUT TYPE=text size=40 NAME=ServiceErrorReportPath VALUE=\"!AZ\">\n\
</TD></TR>\n\
\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;\">\n";

   static char  EndPageFao [] =
"<P><INPUT TYPE=hidden NAME=x VALUE=\"&#10;# End!!&#10;\">\n\
<P><INPUT TYPE=submit VALUE=\" Commit Changes \">\n\
<INPUT TYPE=reset VALUE=\" Reset \">\n\
</FORM>\n\
</BODY>\n\
</HTML>\n";

   static char  EndPageNoCommitFao [] =
"</FORM>\n\
</BODY>\n\
</HTML>\n";

   static char  NotNone [] = "<FONT SIZE=-1><I>(none)</I></FONT>\n";

   int  idx, status,
        ServiceListCount;
   unsigned long  *vecptr;
   unsigned long  FaoVector [64];
   char  *cptr, *sptr, *zptr;
   struct ServiceStruct  *svptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ServiceConfigReviseNow()\n");

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;
   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = &rqptr->rqTime.Vms64bit;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   if (slptr->ProblemReportLength)
   {
      vecptr = FaoVector;
      *vecptr++ = slptr->ProblemCount;
      *vecptr++ = (slptr == &ServiceLoad);
      if (ServiceConfigFileDefined)
         *vecptr++ = slptr->ProblemReportPtr;
      else
         *vecptr++ = ErrorServiceConfigFile;
      status = NetWriteFaol (rqptr, ProblemReportFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   if (ServiceConfigFileDefined)
   {
      cptr = MapVmsPath (slptr->LoadFileName, rqptr);

      vecptr = FaoVector;

      /* source file */
      *vecptr++ = (slptr == &ServiceLoad);
      *vecptr++ = slptr->LoadFileName;
      *vecptr++ = cptr;
      *vecptr++ = ADMIN_SCRIPT_UPD;
      *vecptr++ = cptr;
      if (slptr == &ServiceLoad)
      {
         *vecptr++ = "Loaded:";
         *vecptr++ = &slptr->LoadBinTime;
      }
      else
      {
         *vecptr++ = "Revised:";
         *vecptr++ = &slptr->RevBinTime;
      }

      /* form action */
      *vecptr++ = cptr;

      /* comments */
      *vecptr++ = ServerHostPort;
      *vecptr++ = SoftwareID;
      *vecptr++ = &rqptr->rqTime.Vms64bit;
      *vecptr++ = rqptr->RemoteUser;
      *vecptr++ = rqptr->rqAuth.RealmDescrPtr;
      *vecptr++ = rqptr->rqNet.ClientHostName;

      status = NetWriteFaol (rqptr, ReviseSourceFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }
   else
   {
      status = NetWriteFao (rqptr, "<FORM METHOD=POST ACTION=\"\">");
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFao()", FI_LI);
   }

   /************/
   /* services */
   /************/

   if (slptr->ListHead == NULL)
   {
      status = NetWriteFaol (rqptr, ReviseServiceNoneFao, NULL);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }
   else
   {
      ServiceListCount = 0;
      for (svptr = slptr->ListHead;
           svptr != NULL;
           svptr = svptr->NextPtr)
      {
         vecptr = FaoVector;

         /* place holder for the "next new service" comment (see below) */
         *vecptr++ = "";

         *vecptr++ = "!UL&nbsp;&nbsp;-&nbsp;&nbsp;";
         *vecptr++ = ++ServiceListCount;

         *vecptr++ = svptr->RequestSchemeNamePtr;
         *vecptr++ = "//";
         *vecptr++ = svptr->ServerHostPort;

         if (svptr->RequestScheme == SCHEME_HTTPS)
         {
            *vecptr++ = UNCHECKED_RADIO;
            *vecptr++ = CHECKED_RADIO;
         }
         else
         {
            *vecptr++ = CHECKED_RADIO;
            *vecptr++ = UNCHECKED_RADIO;
         }
         if (svptr->GenericService)
            *vecptr++ = "*";
         else
            *vecptr++ = svptr->ServerHostName;
         *vecptr++ = svptr->ServerPortString;
         *vecptr++ = svptr->SuppliedIpAddressString;

         status = NetWriteFaol (rqptr, ReviseServiceFao, &FaoVector);
         if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

         if (svptr->RequestScheme == SCHEME_HTTPS)
         {
            vecptr = FaoVector;
            *vecptr++ = svptr->SSLcert;
            *vecptr++ = svptr->SSLkey;
            status = NetWriteFaol (rqptr, ReviseSesolaFao, &FaoVector);
            if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
         }

         vecptr = FaoVector;
         REPBOOL_RADIO (svptr->ProxyService)
         status = NetWriteFaol (rqptr, ReviseProxyFao, &FaoVector);
         if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

         if (svptr->ProxyService)
         {
            vecptr = FaoVector;

            REPBOOL_RADIO (svptr->ConnectService)
            REPBOOL_RADIO (svptr->ProxyFileCacheEnabled)
            if (svptr->ProxyAuthRequired)
            {
               *vecptr++ = UNCHECKED_RADIO;
               *vecptr++ = CHECKED_RADIO;
               *vecptr++ = UNCHECKED_RADIO;
            }
            if (svptr->LocalAuthRequired)
            {
               *vecptr++ = UNCHECKED_RADIO;
               *vecptr++ = UNCHECKED_RADIO;
               *vecptr++ = CHECKED_RADIO;
            }
            else
            {
               *vecptr++ = CHECKED_RADIO;
               *vecptr++ = UNCHECKED_RADIO;
               *vecptr++ = UNCHECKED_RADIO;
            }
            *vecptr++ = svptr->ProxyChainHostPort;
            REPBOOL_RADIO (svptr->ProxyTrack)

            status = NetWriteFaol (rqptr, ReviseProxyDetailsFao, &FaoVector);
            if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
         }

         vecptr = FaoVector;

         REPBOOL_RADIO (svptr->NoLog)
         REPBOOL_RADIO (svptr->SetNoTrack)
         *vecptr++ = svptr->BodyTag;
         *vecptr++ = svptr->ErrorReportPath;

         status = NetWriteFaol (rqptr, ReviseOtherFao, &FaoVector);
         if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      }
   }

   /***********************/
   /* "blank" new service */
   /***********************/

   vecptr = FaoVector;
   *vecptr++ =
"<INPUT TYPE=hidden NAME=x VALUE=\"\
&#10;# place-holder for the next new service\">\n";
   *vecptr++ = "";
   *vecptr++ = "- Next New Service -";
   *vecptr++ = "";
   *vecptr++ = "";
   *vecptr++ = CHECKED_RADIO;
   *vecptr++ = UNCHECKED_RADIO;
   *vecptr++ = "?.?.?.?";
   *vecptr++ = "80";
   *vecptr++ = "";
   *vecptr++ = "";
   status = NetWriteFaol (rqptr, ReviseServiceFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   vecptr = FaoVector;
   REPBOOL_RADIO (false)
   status = NetWriteFaol (rqptr, ReviseProxyFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   vecptr = FaoVector;
   REPBOOL_RADIO (false)
   REPBOOL_RADIO (false)
   *vecptr++ = "";
   *vecptr++ = "";
   status = NetWriteFaol (rqptr, ReviseOtherFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /**************/
   /* end report */
   /**************/

   if (ServiceConfigFileDefined)
      status = NetWriteFao (rqptr, EndPageFao);
   else
      status = NetWriteFao (rqptr, EndPageNoCommitFao);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

#undef CHECKED_RADIO
#undef UNCHECKED_RADIO
#undef REPBOOL_RADIO
}

/*****************************************************************************/
