/*****************************************************************************/
/*
                               AuthHTA.c


    THE GNU GENERAL PUBLIC LICENSE APPLIES DOUBLY TO ANYTHING TO DO WITH
                    AUTHENTICATION AND AUTHORIZATION!

    This package is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License, or any later
    version.

>   This package is distributed in the hope that it will be useful,
>   but WITHOUT ANY WARRANTY; without even the implied warranty of
>   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
>   GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

This module provides functions related to the authentication of usernames via
the WASD HTA databases (maintained via HTADMIN.C).

See AUTH.C for overall detail on the WASD authorization environment.


VERSION HISTORY
---------------
02-JAN-2000  MGD  no significant modifications for ODS-5 (no NAM block)
28-AUG-1999  MGD  unbundled from AUTH.C for v6.1
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <descrip.h>
#include <rms.h>
#include <rmsdef.h>
#include <ssdef.h>
#include <stsdef.h>

#include <uaidef.h>
/* not defined in VAX C 3.2 <uaidef.h> */
#define UAI$M_RESTRICTED 0x8
#define UAI$C_PURDY_S 3

/* application related header files */
#include "wasd.h"

#define WASD_MODULE "AUTHHTA"

#if DBUG
#define FI_NOLI WASD_MODULE, __LINE__
#else
/* in production let's keep the exact line to ourselves! */
#define FI_NOLI WASD_MODULE, 0
#endif

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern int  WatchEnabled,
            ServerPort,
            ServiceCount;

extern char  ErrorSanityCheck[],
             ServerHostName[],
             ServerHostPort[],
             SoftwareID[],
             Utility[];

extern struct AccountingStruct  Accounting;
extern struct ConfigStruct  Config;
extern struct MsgStruct  Msgs;

/****************************************************************************/
/*
Verify the request username/password and/or read capabilities from the on-disk
HTA (HTTPd) authorization database.

Returns a success status if user password authenticated,
AUTH_DENIED_BY_LOGIN if not authenticated, or other error status if a
genuine VMS error occurs (which should be reported where and when it occurs).

The digest is stored in both upper and lower case versions because clients
will have case-lock either on or off producing a digest of either upper or
lower case username and password.  Keep digests of both so that provided one
or other case is used exclusively the digest thereof can still be matched
with one or other stored here :^)
*/ 

int AuthReadHtDatabase
(
struct RequestStruct* rqptr,
char *DatabaseName,
boolean AuthenticatePassword
)
{
   static char UserName [AUTH_MAX_USERNAME_LENGTH+1],
               Password [AUTH_MAX_PASSWORD_LENGTH+1];
   static $DESCRIPTOR (PasswordDsc, Password);
   static $DESCRIPTOR (UserNameDsc, UserName);

   register char  *cptr, *sptr;

   boolean  PasswordAuthenticated,
            UserNameEnabled;
   int  status;
   unsigned long  HashedPwd [2];
   char  A1HexDigest [33],
         HexDigest [33];
   struct AuthHtRecordStruct AuthHtRecord;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "AuthReadHtDatabase() |%s|%s|\n",
               DatabaseName, rqptr->RemoteUser);

   /* flag that case-less username and password checks were performed */
   rqptr->rqAuth.CaseLess = true;

   /* set the capabilities to zero before we do anything else! */
   rqptr->rqAuth.UserCan = 0;

   /* to uppercase! */
   sptr = UserName;
   for (cptr = rqptr->RemoteUser; *cptr; *sptr++ = toupper(*cptr++));
   *sptr = '\0';
   UserNameDsc.dsc$w_length = sptr - UserName;

   /* look for the record, leave the database file open if found */
   status = AuthAccessHtDatabase (true, DatabaseName, UserName,
                                  &AuthHtRecord, NULL, NULL);
   if (status == RMS$_EOF)
   {
      if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
         WatchThis (rqptr, FI_LI, WATCH_AUTH,
                    "FAIL !AZ!AZ username", DatabaseName,
                    AuthSourceString (DatabaseName, AUTH_SOURCE_HTA));

      /* close the database */
      AuthAccessHtDatabase (false, NULL, NULL, NULL, NULL, NULL);

      if (AuthenticatePassword)
         return (AUTH_DENIED_BY_LOGIN);
      else
         return (AUTH_DENIED_BY_GROUP);
   }

   if (VMSnok (status))
   {
      rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_AUTH_DATABASE);
      rqptr->rqResponse.ErrorOtherTextPtr = DatabaseName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      return (status);
   }

   /****************/
   /* record found */
   /****************/

   PasswordAuthenticated = false;

   if (AuthHtRecord.Flags & AUTH_FLAG_ENABLED)
   {
      UserNameEnabled = true;
      if (AuthenticatePassword &&
          AuthHtRecord.HashedPwd[0] && AuthHtRecord.HashedPwd[1])
      {
         if (rqptr->rqAuth.Scheme == AUTH_SCHEME_BASIC)
         {
            if (Debug) fprintf (stdout, "BASIC\n");

            /* to uppercase! */
            sptr = Password;
            for (cptr = rqptr->RemoteUserPassword;
                 *cptr;
                 *sptr++ = toupper(*cptr++));
            *sptr = '\0';
            PasswordDsc.dsc$w_length = sptr - Password;

            status = sys$hash_password (&PasswordDsc, UAI$C_PURDY_S, 0,
                                        &UserNameDsc, &HashedPwd);
            if (Debug)
               fprintf (stdout, "sys$hash_password() %%X%08.08X\n", status);
            if (VMSnok (status))
            {
               /* ensure the currently open database is closed */
               AuthAccessHtDatabase (false, NULL, NULL, NULL, NULL, NULL);
               rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_AUTH_USER);
               ErrorVmsStatus (rqptr, status, FI_LI);
               return (status);
            }

            if (Debug)
               fprintf (stdout, "|%08.08X%08.08X|%08.08X%08.08X|\n",
                        HashedPwd[1], HashedPwd[0],
                        AuthHtRecord.HashedPwd[1], AuthHtRecord.HashedPwd[0]);

            if (HashedPwd[0] == AuthHtRecord.HashedPwd[0] &&
                HashedPwd[1] == AuthHtRecord.HashedPwd[1])
               PasswordAuthenticated = true;
         }
         else
         if (rqptr->rqAuth.Scheme == AUTH_SCHEME_DIGEST)
         {
            if (Debug)
               fprintf (stdout, "DIGEST |%s|\n",
                        rqptr->rqAuth.DigestResponsePtr);

            DigestHexString (AuthHtRecord.A1DigestLoCase, 16, A1HexDigest);
            DigestResponse (A1HexDigest,
                            rqptr->rqAuth.DigestNoncePtr,
                            rqptr->rqHeader.MethodName,
                            rqptr->rqAuth.DigestUriPtr,
                            HexDigest);
            if (!strcmp (rqptr->rqAuth.DigestResponsePtr, HexDigest))
               PasswordAuthenticated = true;
            else
            {
               DigestHexString (AuthHtRecord.A1DigestUpCase, 16, A1HexDigest);
               DigestResponse (A1HexDigest,
                               rqptr->rqAuth.DigestNoncePtr,
                               rqptr->rqHeader.MethodName,
                               rqptr->rqAuth.DigestUriPtr,
                               HexDigest);
               if (!strcmp (rqptr->rqAuth.DigestResponsePtr, HexDigest))
                  PasswordAuthenticated = true;
            }
         }

         if (!PasswordAuthenticated)
            if (rqptr->WatchItem && (WatchEnabled & WATCH_AUTH))
               WatchThis (rqptr, FI_LI, WATCH_AUTH,
                         "FAIL !AZ!AZ password", DatabaseName,
                         AuthSourceString (DatabaseName, AUTH_SOURCE_HTA));

         if (Debug)
            fprintf (stdout, "PasswordAuthenticated: %d\n",
                     PasswordAuthenticated);
      }

      if (!AuthenticatePassword || PasswordAuthenticated)
      {
         /* set the appropriate authorization flags */
         if (AuthHtRecord.Flags & AUTH_FLAG_DELETE)
            rqptr->rqAuth.UserCan |= HTTP_METHOD_DELETE;
         if (AuthHtRecord.Flags & AUTH_FLAG_GET)
            rqptr->rqAuth.UserCan |= HTTP_METHOD_GET | HTTP_METHOD_HEAD;
         if (AuthHtRecord.Flags & AUTH_FLAG_HEAD)
            rqptr->rqAuth.UserCan |= HTTP_METHOD_HEAD;
         if (AuthHtRecord.Flags & AUTH_FLAG_POST)
            rqptr->rqAuth.UserCan |= HTTP_METHOD_POST;
         if (AuthHtRecord.Flags & AUTH_FLAG_PUT)
            rqptr->rqAuth.UserCan |= HTTP_METHOD_PUT;

         if (AuthHtRecord.Flags & AUTH_FLAG_HTTPS_ONLY)
            rqptr->rqAuth.HttpsOnly = true;
         else
            rqptr->rqAuth.HttpsOnly = false;
      }
   }

   if (UserNameEnabled && (!AuthenticatePassword || PasswordAuthenticated))
   {
      AuthHtRecord.AccessCount++;
      memcpy (&AuthHtRecord.LastAccessBinTime, &rqptr->rqTime.Vms64bit, 8);
   }
   else
   {
      AuthHtRecord.FailureCount++;
      memcpy (&AuthHtRecord.LastFailureBinTime, &rqptr->rqTime.Vms64bit, 8);
   }

   /* update the record, close the database file */
   status = AuthAccessHtDatabase (false, NULL, NULL, NULL, NULL, &AuthHtRecord);
   if (VMSnok (status))
   {
      rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_AUTH_DATABASE);
      rqptr->rqResponse.ErrorOtherTextPtr = DatabaseName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      return (status);
   }

   if (!AuthenticatePassword || PasswordAuthenticated)
   {
      if (AuthenticatePassword)
      {
         register char  *cptr, *sptr;
         int  Length;

         Length = 0;
         if (AuthHtRecord.FullName[0])
            Length += strlen(AuthHtRecord.FullName);
         if (AuthHtRecord.Email[0])
         {
            if (Length) Length++;
            Length += strlen(AuthHtRecord.Email);
         }
         if (AuthHtRecord.Contact[0])
         {
            if (Length) Length++;
            Length += strlen(AuthHtRecord.Contact);
         }

         if (Length)
         {
            rqptr->rqAuth.UserDetailsLength = Length;
            rqptr->rqAuth.UserDetailsPtr = sptr =
               VmGetHeap (rqptr, rqptr->rqAuth.UserDetailsLength+1);
            if (AuthHtRecord.FullName[0])
               for (cptr = AuthHtRecord.FullName; *cptr; *sptr++ = *cptr++);
            if (AuthHtRecord.Email[0])
            {
               if (sptr > rqptr->rqAuth.UserDetailsPtr) *sptr++ = '\n';
               for (cptr = AuthHtRecord.Email; *cptr; *sptr++ = *cptr++);
            }
            if (AuthHtRecord.Contact[0])
            {
               if (sptr > rqptr->rqAuth.UserDetailsPtr) *sptr++ = '\n';
               for (cptr = AuthHtRecord.Contact; *cptr; *sptr++ = *cptr++);
            }
            *sptr = '\0';
         }
      }

      return (SS$_NORMAL);
   }
   else
   if (AuthenticatePassword)
      return (AUTH_DENIED_BY_LOGIN);
   else
      return (AUTH_DENIED_BY_GROUP);
}

/****************************************************************************/
/*
Locate a specified user record in a specified on-disk database.  Either return
that record if found or if an update record supplied, update it! Can return any
RMS or VMS error status code.  Returns SS$_NORMAL is operation (read, add or
update) completed successfully.  Returns AUTH_DENIED_BY_LOGIN if the record
could not be found.  Returns SS$_INCOMPAT if the database file version is
incorrect.

THE DATABASE FILE IS ALWAYS CLOSED ON AN ERROR CONDITION.

'LeaveFileOpen' will leave the database file open with the current record
context ready for update, or for locating another user record.  This function
is not reentrant and therefore this context is valid ONLY within the one AST.

Call with 'DatabaseName' and 'UserName' non-NULL and all other pointers
set to NULL to check whether the user name has a record in the database.
*/ 

int AuthAccessHtDatabase
(
boolean LeaveFileOpen,
char *DatabaseName,
char *UserName,
struct AuthHtRecordStruct *AuthHtRecordReadPtr,
struct AuthHtRecordStruct *AuthHtRecordAddPtr,
struct AuthHtRecordStruct *AuthHtRecordUpdatePtr
)
{
   static char  AuthFileName [64],
                PrevDatabaseName [64];
   static unsigned short  AuthFileNameLength;
   static $DESCRIPTOR (AuthFileNameFaoDsc, "!AZ!AZ!AZ");
   static $DESCRIPTOR (AuthFileNameDsc, AuthFileName);
   static struct FAB  AuthFileFab;
   static struct RAB  AuthFileRab;

   register char  *cptr, *sptr;

   int  status,
        UserNameLength;
   struct AuthHtRecordStruct *AuthHtRecordPtr;
   struct AuthHtRecordStruct AuthHtRecord;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "AuthAccessHtDatabase() %d |%s|%s| %d %d %d\n",
               LeaveFileOpen, DatabaseName, UserName,
               AuthHtRecordReadPtr, AuthHtRecordAddPtr, AuthHtRecordUpdatePtr);

   if (AuthHtRecordReadPtr == NULL &&
       AuthHtRecordAddPtr == NULL &&
       AuthHtRecordUpdatePtr == NULL)
   {
      /************************/
      /* force database close */
      /************************/

      sys$close (&AuthFileFab, 0, 0);
      return (SS$_NORMAL);
   }

   if (UserName == NULL && AuthHtRecordUpdatePtr != NULL)
   {
      /*********************************/
      /* update previously read record */
      /*********************************/

      AuthFileRab.rab$l_rbf = AuthHtRecordUpdatePtr;
      AuthFileRab.rab$w_rsz = sizeof(struct AuthHtRecordStruct);
      status = sys$update (&AuthFileRab, 0, 0);
      if (Debug) fprintf (stdout, "sys$update() %%X%08.08X\n", status);
      if (VMSok (status))
      {
         /* update completed successfully */
         if (!LeaveFileOpen) sys$close (&AuthFileFab, 0, 0);
         return (SS$_NORMAL);
      }
      /* update error */
      sys$close (&AuthFileFab, 0, 0);
      return (status);
   }

   if (DatabaseName == NULL)
   {
      /*****************************************/
      /* locate within currently open database */
      /*****************************************/

      if (VMSnok (status = sys$rewind (&AuthFileRab, 0, 0)))
      {
         sys$close (&AuthFileFab, 0, 0);
         return (status);
      }
      if (Debug) fprintf (stdout, "sys$rewind() %%X%08.08X\n", status);
   }
   else
   {
      /**********************************/
      /* open currently closed database */
      /**********************************/

      if (strcmp (DatabaseName, PrevDatabaseName))
      {
         sys$fao (&AuthFileNameFaoDsc, &AuthFileNameLength, &AuthFileNameDsc,
                  HTA_DIRECTORY, DatabaseName, HTA_FILE_TYPE);
         AuthFileName[AuthFileNameLength] = '\0';
      }
      if (Debug) fprintf (stdout, "AuthFileName |%s|\n", AuthFileName);

      AuthFileFab = cc$rms_fab;
      /* if a read-only operation without file left open then read-only! */
      if (!LeaveFileOpen &&
          AuthHtRecordAddPtr == NULL &&
          AuthHtRecordUpdatePtr == NULL)
         AuthFileFab.fab$b_fac = FAB$M_GET;
      else
         AuthFileFab.fab$b_fac = FAB$M_GET | FAB$M_PUT | FAB$M_UPD;
      AuthFileFab.fab$l_fna = AuthFileName;  
      AuthFileFab.fab$b_fns = AuthFileNameLength;
      AuthFileFab.fab$b_shr = FAB$M_SHRGET | FAB$M_SHRPUT | FAB$M_SHRUPD;

      /* turn on SYSPRV to allow access to authentication database file */
      EnableSysPrv();
      status = sys$open (&AuthFileFab, 0, 0);
      DisableSysPrv();

      /* status from sys$open() */
      if (VMSnok (status)) return (status);

      AuthFileRab = cc$rms_rab;
      AuthFileRab.rab$l_fab = &AuthFileFab;
      AuthFileRab.rab$b_mbf = 2;
      AuthFileRab.rab$l_rop = RAB$M_RAH;

      if (VMSnok (status = sys$connect (&AuthFileRab, 0, 0)))
      {
         sys$close (&AuthFileFab, 0, 0);
         return (status);
      }
   }

   /*****************/
   /* locate record */
   /*****************/

   /* for add and update read into the scratch record */
   if (AuthHtRecordReadPtr == NULL)
      AuthFileRab.rab$l_ubf = AuthHtRecordPtr = &AuthHtRecord;
   else
      AuthFileRab.rab$l_ubf = AuthHtRecordPtr = AuthHtRecordReadPtr;
   AuthFileRab.rab$w_usz = sizeof(struct AuthHtRecordStruct);

   if (UserName != NULL) UserNameLength = strlen(UserName);

   while (VMSok (status = sys$get (&AuthFileRab, 0, 0)))
   {
      /* check the version of the authorization database */
      if (AuthHtRecordPtr->DatabaseVersion &&
          AuthHtRecordPtr->DatabaseVersion != AuthCurrentDatabaseVersion)
      {
         status = SS$_INCOMPAT & 0xfffffffe;
         break;
      }

      /* if deleted record (all set to zeroes) continue */
      if (AuthHtRecordAddPtr == NULL && !AuthHtRecordPtr->UserNameLength)
         continue;

      /* if adding a record then use the first deleted one found */
      if (AuthHtRecordAddPtr != NULL && !AuthHtRecordPtr->UserNameLength)
         break;
/**
      if (Debug)
         fprintf (stdout, "AuthHtRecordPtr->UserName |%s|\n",
                  AuthHtRecordPtr->UserName);
**/
      if (UserNameLength != AuthHtRecordPtr->UserNameLength) continue;
      cptr = AuthHtRecordPtr->UserName;
      sptr = UserName;
      while (*cptr && *sptr && tolower(*cptr) == tolower(*sptr))
         { cptr++; sptr++; }
      if (*cptr || *sptr) continue;
      break;
   }
   if (Debug) fprintf (stdout, "sys$get() %%X%08.08X\n", status);

   if (AuthHtRecordUpdatePtr == NULL && AuthHtRecordAddPtr == NULL)
   {
      /***************/
      /* read record */
      /***************/

      if (VMSok (status))
      {
         /* record found */
         if (!LeaveFileOpen) sys$close (&AuthFileFab, 0, 0);
         return (SS$_NORMAL);
      }

      if (status == RMS$_EOF)
      {
         /* user record not found */
         if (!LeaveFileOpen) sys$close (&AuthFileFab, 0, 0);
         return (status);
      }
      /* RMS error */
      sys$close (&AuthFileFab);
      return (status);
   }

   if (AuthHtRecordUpdatePtr != NULL)
   {
      /*****************/
      /* update record */
      /*****************/

      if (VMSnok (status))
      {
         if (status == RMS$_EOF)
         {
            /* user record not found */
            if (!LeaveFileOpen) sys$close (&AuthFileFab, 0, 0);
            return (status);
         }
         /* RMS error */
         sys$close (&AuthFileFab, 0, 0);
         return (status);
      }

      AuthFileRab.rab$l_rbf = AuthHtRecordUpdatePtr;
      AuthFileRab.rab$w_rsz = sizeof(struct AuthHtRecordStruct);

      status = sys$update (&AuthFileRab, 0, 0);
      if (Debug) fprintf (stdout, "sys$update() %%X%08.08X\n", status);
      if (VMSok (status))
      {
         /* update completed successfully */
         if (!LeaveFileOpen) sys$close (&AuthFileFab, 0, 0);
         return (SS$_NORMAL);
      }
      /* RMS error */
      sys$close (&AuthFileFab, 0, 0);
      return (status);
   }

   if (AuthHtRecordAddPtr != NULL)
   {
      /****************/
      /* add a record */
      /****************/

      if (VMSnok (status) && status != RMS$_EOF)
      {
         /* RMS error */
         sys$close (&AuthFileFab, 0, 0);
         return (status);
      }

      AuthFileRab.rab$l_rbf = AuthHtRecordAddPtr;
      AuthFileRab.rab$w_rsz = sizeof(struct AuthHtRecordStruct);

      /* if reached end-of-file then add a record, else undate zeroed one */
      if (status == RMS$_EOF)
         status = sys$put (&AuthFileRab, 0, 0);
      else
         status = sys$update (&AuthFileRab, 0, 0);
      if (Debug) fprintf (stdout, "sys$put/update() %%X%08.08X\n", status);
      if (VMSok (status))
      {
         /* put or update completed successfully */
         if (!LeaveFileOpen) sys$close (&AuthFileFab, 0, 0);
         return (SS$_NORMAL);
      }
      /* RMS error */
      sys$close (&AuthFileFab, 0, 0);
      return (status);
   }

   /* sanity check error, should never get here */
   return (SS$_BUGCHECK);
}

/****************************************************************************/

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  