/*****************************************************************************
/*
                                 HTAdmin.c

Administer the user authentication (HTA) Databases.
Change an authenticated username's SYSUAF password.


VERSION HISTORY
---------------
28-MAR-2000  MGD  bugfix; SYSUAF password change username and password
                  both need to be upper case!
04-MAR-2000  MGD  use NetWriteFaol(), et.al.
05-FEB-2000  MGD  change HTA database type from ".HTA" to ".$HTA"
                  (due to potential conflict with Microsoft HTA technology)
03-JAN-2000  MGD  support ODS-2 and ODS-5 using ODS module
29-SEP-1999  MGD  'AuthPolicySysUafRelaxed' control password change
20-FEB-1999  MGD  password change refinements
16-JUL-1998  MGD  "https:" only flag,
                  extend HTAdminPasswordChange() to VMS (SYSUAF)
09-AUG-1997  MGD  message database
01-FEB-1997  MGD  new for HTTPd version 4
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <descrip.h>
#include <jpidef.h>
#include <libdef.h>
#include <libdtdef.h>
#include <ssdef.h>
#include <stsdef.h>
#include <uaidef.h>

/* application related header files */
#include "wasd.h"

#define WASD_MODULE "HTADMIN"

/***********************/
/* module requirements */
/***********************/

#define DatabaseListSize 8
#define UserNameListSize 7

/******************/
/* global storage */
/******************/

char  ErrorHTAdminAction [] = "Unknown action.",
      ErrorHTAdminDatabase [] = "Authentication database.",
      ErrorHTAdminDatabaseEnter [] = "Enter a database name.",
      ErrorHTAdminDatabaseExists [] = "Database already exists.",
      ErrorHTAdminDatabaseNBG [] =
"Database name may contain only A..Z, 0..9, _ and - characters.",
      ErrorHTAdminDatabaseSelect[] = "Select a database.",
      ErrorHTAdminInsufficient [] = "Insufficient parameters.",
      ErrorHTAdminParameter [] = "Parameter out-of-range.",
      ErrorHTAdminPurgeCache [] = "purging authentication cache",
      ErrorHTAdminQuery [] = "Unknown query component.",
      ErrorHTAdminUserNotFound [] = "Username not found in database.",
      ErrorHTAdminUserEnter [] = "Enter a username.",
      ErrorHTAdminUserExists [] = "Username already exists.",
      ErrorHTAdminUserNBG [] =
"Username may contain only A..Z, 0..9, _ and - characters.",
      ErrorHTAdminUserSelect [] = "Select a username.",
      ErrorHTAdminVerify [] = "Password verification failure.";

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern boolean  AuthSysUafEnabled,
                AuthPolicySysUafRelaxed;

extern int  OpcomMessages,
            WatchEnabled;

extern char  *DayName[];

extern char  ServerHostPort[],
             SoftwareID[],
             Utility[];

extern struct AccountingStruct Accounting;
extern struct ConfigStruct  Config;
extern struct MsgStruct  Msgs;
extern struct AuthCacheRecordStruct  *AuthCacheTreeHead;

/*****************************************************************************/
/*
*/ 

HTAdminBegin
(
struct RequestStruct *rqptr,
void *NextTaskFunction
)
{
   static $DESCRIPTOR (LocationDatabaseFaoDsc, "!AZ!AZ?do=!AZ\0");

   register char  *cptr, *sptr, *qptr, *zptr;
   register struct HTAdminTaskStruct  *tkptr;

   boolean  ForceUpperCase;
   int  status;
   unsigned long  FaoVector [32];
   unsigned short  Length;
   char  Access [32],
         Action [32],
         AsDatabaseName [AUTH_MAX_REALM_GROUP_LENGTH+1],
         AsUserName [AUTH_MAX_USERNAME_LENGTH+1],
         Contact [AUTH_MAX_CONTACT_LENGTH+1],
         DatabaseName [AUTH_MAX_REALM_GROUP_LENGTH+1],
         Email [AUTH_MAX_EMAIL_LENGTH+1],
         Enabled [32],
         FieldName [32],
         FieldValue [256],
         FullName [AUTH_MAX_FULLNAME_LENGTH+1],
         HttpsOnly [32],
         Location [512],
         PasswordNew [AUTH_MAX_PASSWORD_LENGTH+1],
         PasswordCurrent [AUTH_MAX_PASSWORD_LENGTH+1],
         PasswordVerify [AUTH_MAX_PASSWORD_LENGTH+1],
         UserName [AUTH_MAX_USERNAME_LENGTH+1];
   $DESCRIPTOR (LocationDsc, Location);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminBegin()\n");

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_RESPONSE))
      WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                 "HTADMIN !AZ", rqptr->rqHeader.PathInfoPtr);

   if (!rqptr->AccountingDone)
      rqptr->AccountingDone = ++Accounting.DoServerAdminCount;

   if (rqptr->rqResponse.ErrorReportPtr != NULL)
   {
      /* previous error, cause threaded processing to unravel */
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   /* set up the task structure (only ever one per request!) */
   rqptr->HTAdminTaskPtr = tkptr = (struct HTAdminTaskStruct*)
      VmGetHeap (rqptr, sizeof(struct HTAdminTaskStruct));
   tkptr->NextTaskFunction = NextTaskFunction;

   /**********************/
   /* parse query string */
   /**********************/

   Action[0] = Access[0] = AsDatabaseName[0] = DatabaseName[0] =
      AsUserName[0] = Contact[0] = Email[0] = Enabled[0] = HttpsOnly[0] =
      PasswordCurrent[0] = PasswordNew[0] = PasswordVerify[0] =
      UserName[0] = '\0';

   if (rqptr->rqHeader.Method == HTTP_METHOD_POST)
      qptr = rqptr->rqBody.BufferPtr;
   else
      qptr = rqptr->rqHeader.QueryStringPtr;
   while (*qptr)
   {
      qptr = ParseQueryField (rqptr, qptr,
                              FieldName, sizeof(FieldName),
                              FieldValue, sizeof(FieldValue),
                              FI_LI);
      if (qptr == NULL)
      {
         /* error occured */
         HTAdminEnd (rqptr);
         return;
      }

      /********************/
      /* get field values */
      /********************/

      ForceUpperCase = false;
      sptr = NULL;
      if (strsame (FieldName, "ac", -1))
         zptr = (sptr = Access) + sizeof(Access);
      else
      if (strsame (FieldName, "ad", -1))
         zptr = (sptr = AsDatabaseName) + sizeof(AsDatabaseName);
      else
      if (ForceUpperCase = strsame (FieldName, "au", -1))
         zptr = (sptr = AsUserName) + sizeof(AsUserName);
      else
      if (strsame (FieldName, "co", -1))
         zptr = (sptr = Contact) + sizeof(Contact);
      else
      if (ForceUpperCase = strsame (FieldName, "cu", -1))
         zptr = (sptr = PasswordCurrent) + sizeof(PasswordCurrent);
      else
      if (strsame (FieldName, "da", -1))
         zptr = (sptr = DatabaseName) + sizeof(DatabaseName);
      else
      if (strsame (FieldName, "do", -1))
         zptr = (sptr = Action) + sizeof(Action);
      else
      if (strsame (FieldName, "em", -1))
         zptr = (sptr = Email) + sizeof(Email);
      else
      if (strsame (FieldName, "en", -1))
         zptr = (sptr = Enabled) + sizeof(Enabled);
      else
      if (strsame (FieldName, "f", -1))
         zptr = (sptr = FullName) + sizeof(FullName);
      else
      if (strsame (FieldName, "hs", -1))
         zptr = (sptr = HttpsOnly) + sizeof(HttpsOnly);
      else
      if (ForceUpperCase = strsame (FieldName, "p", -1))
         zptr = (sptr = PasswordNew) + sizeof(PasswordNew);
      else
      if (ForceUpperCase = strsame (FieldName, "v", -1))
         zptr = (sptr = PasswordVerify) + sizeof(PasswordVerify);
      else
      if (ForceUpperCase = strsame (FieldName, "u", -1))
         zptr = (sptr = UserName) + sizeof(UserName);

      if (sptr == NULL)
      {
         rqptr->rqResponse.HttpStatus = 400;
         ErrorGeneral (rqptr, ErrorHTAdminQuery, FI_LI);
         HTAdminEnd (rqptr);
         return;
      }
      else
      {
         cptr = FieldValue;
         if (ForceUpperCase)
            while (*cptr && sptr < zptr) *sptr++ = toupper(*cptr++);
         else
            while (*cptr && sptr < zptr) *sptr++ = *cptr++;
         if (sptr >= zptr)
         {
            ErrorGeneralOverflow (rqptr, FI_LI);
            HTAdminEnd (rqptr);
            return;
         }
         *sptr = '\0';
      }
   }

   /**************************************/
   /* special case, user change password */
   /**************************************/

   if (strsame (rqptr->rqHeader.RequestUriPtr, INTERNAL_PASSWORD_CHANGE,
                sizeof(INTERNAL_PASSWORD_CHANGE)-1))
   {
      if (rqptr->rqHeader.Method == HTTP_METHOD_POST)
          HTAdminPasswordChange (rqptr, PasswordCurrent,
                                 PasswordNew, PasswordVerify);
      else  
          HTAdminPasswordChangeForm (rqptr);
      return;
   }

   /****************************/
   /* administration functions */
   /****************************/

   Location[0] = '\0';

   if (!strcmp (Action, "HTALISTB") ||
       !strcmp (Action, "HTALISTF") ||
       !strcmp (Action, "HTAACCESS") ||
       !strcmp (Action, "HTADELETE") ||
       !strcmp (Action, "HTARESET"))
   {
      if (!DatabaseName[0])
      {
         rqptr->rqResponse.HttpStatus = 400;
         ErrorGeneral (rqptr, ErrorHTAdminDatabaseSelect, FI_LI);
         HTAdminEnd (rqptr);
         return;
      }
      for (cptr = Action; *cptr; cptr++) *cptr = tolower(*cptr);
      status = sys$fao (&LocationDatabaseFaoDsc, &Length, &LocationDsc,
                        rqptr->rqHeader.PathInfoPtr, DatabaseName, Action);
   }
   else
   if (!strcmp (Action, "HTACREATE"))
   {
      if (!AsDatabaseName[0])
      {
         rqptr->rqResponse.HttpStatus = 400;
         ErrorGeneral (rqptr, ErrorHTAdminDatabaseEnter, FI_LI);
         HTAdminEnd (rqptr);
         return;
      }
      for (cptr = Action; *cptr; cptr++) *cptr = tolower(*cptr);
      status = sys$fao (&LocationDatabaseFaoDsc, &Length, &LocationDsc,
                        rqptr->rqHeader.PathInfoPtr, AsDatabaseName, Action);
   }

   if (Location[0])
   {
      rqptr->rqResponse.LocationPtr = VmGetHeap (rqptr, Length);
      memcpy (rqptr->rqResponse.LocationPtr, Location, Length);
      HTAdminEnd (rqptr);
      return;
   }

   zptr = (sptr = DatabaseName) + sizeof(DatabaseName);
   for (cptr = rqptr->rqHeader.PathInfoPtr; *cptr; cptr++);
   while (cptr > rqptr->rqHeader.PathInfoPtr && *cptr != '/') cptr--;
   if (*cptr == '/')
   {
      cptr++;
      while (*cptr && *cptr != '/' && sptr < zptr) *sptr++ = toupper(*cptr++);
      if (sptr >= zptr)
      {
         ErrorGeneralOverflow (rqptr, FI_LI);
         HTAdminEnd (rqptr);
         return;
      }
      *sptr = '\0';
   }
   else
      DatabaseName[0] = '\0';

   if (DatabaseName[0])
   {
      for (cptr = DatabaseName; *cptr; cptr++)
      {
         if (isalnum(*cptr) || *cptr == '_' || *cptr == '-') continue;
         rqptr->rqResponse.HttpStatus = 400;
         ErrorGeneral (rqptr, ErrorHTAdminDatabaseNBG, FI_LI);
         HTAdminEnd (rqptr);
         return;
      }
   }

   if (Action[0])
   {
      if (UserName[0] || AsUserName[0])
      {
         if (strsame (Action, "add", -1))
            cptr = AsUserName;
         else
            cptr = UserName;
         for ( /* above */ ; *cptr; cptr++)
         {
            if (isalnum(*cptr) || *cptr == '_' || *cptr == '-') continue;
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, ErrorHTAdminUserNBG, FI_LI);
            HTAdminEnd (rqptr);
            return;
         }
      }

      if (strsame (Action, "view", -1) ||
          strsame (Action, "modify", -1) ||
          strsame (Action, "delete", -1))
      {
         if (!UserName[0])
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, ErrorHTAdminUserSelect, FI_LI);
            HTAdminEnd (rqptr);
            return;
         }
      }
      else
      if (strsame (Action, "add", -1))
      {
         if (!AsUserName[0])
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, ErrorHTAdminUserEnter, FI_LI);
            HTAdminEnd (rqptr);
            return;
         }
      }

      if (rqptr->rqHeader.Method == HTTP_METHOD_POST)
      {
         /***************/
         /* POST method */
         /***************/

         if (strsame (Action, "add", -1))
            HTAdminModifyUser (rqptr, true, DatabaseName, AsUserName,
                               FullName, Contact, Email, Enabled,
                               Access, HttpsOnly,
                               PasswordNew, PasswordVerify);
         else
         if (strsame (Action, "modify", -1))
            HTAdminModifyUser (rqptr, false, DatabaseName, UserName,
                               FullName, Contact, Email, Enabled,
                               Access, HttpsOnly,
                               PasswordNew, PasswordVerify);
         else
         if (strsame (Action, "htacreate", -1))
            HTAdminDatabaseCreate (rqptr, DatabaseName);
         else
         if (strsame (Action, "htadelete", -1))
            HTAdminDatabaseDelete (rqptr, DatabaseName);
         else
         if (strsame (Action, "userdelete", -1))
            HTAdminUserDelete (rqptr, DatabaseName, UserName);
         else
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, ErrorHTAdminAction, FI_LI);
            HTAdminEnd (rqptr);
            return;
         }
      }
      else
      {
         /**************/
         /* GET method */
         /**************/

         if (strsame (Action, "view", -1))
            HTAdminUserView (rqptr, DatabaseName, UserName);
         else
         if (strsame (Action, "modify", -1))
            HTAdminModifyUserForm (rqptr, false, DatabaseName, UserName);
         else
         if (strsame (Action, "add", -1))
            HTAdminModifyUserForm (rqptr, true, DatabaseName, AsUserName);
         else
         if (strsame (Action, "delete", -1))
            HTAdminUserDeleteForm (rqptr, DatabaseName, UserName);
         else
         if (strsame (Action, "purge", -1))
            HTAdminCachePurge (rqptr, "", "");
         else
         if (strsame (Action, "htalistb", -1))
         {
            tkptr->BriefList = true;
            HTAdminListUsersBegin (rqptr, DatabaseName);
         }
         else
         if (strsame (Action, "htalistf", -1))
         {
            tkptr->BriefList = false;
            HTAdminListUsersBegin (rqptr, DatabaseName);
         }
         else
         if (strsame (Action, "htaaccess", -1))
            HTAdminDatabaseUsersBegin (rqptr, DatabaseName);
         else
         if (strsame (Action, "htacreate", -1))
            HTAdminDatabaseCreateForm (rqptr, DatabaseName);
         else
         if (strsame (Action, "htadelete", -1))
            HTAdminDatabaseDeleteForm (rqptr, DatabaseName);
         else
         {
            rqptr->rqResponse.HttpStatus = 400;
            ErrorGeneral (rqptr, ErrorHTAdminAction, FI_LI);
            HTAdminEnd (rqptr);
            return;
         }
      }
   }
   else
   if (DatabaseName[0])
      HTAdminDatabaseUsersBegin (rqptr, DatabaseName);
   else
      HTAdminDatabaseBegin (rqptr);
}

/*****************************************************************************/
/*
*/ 

HTAdminEnd (struct RequestStruct *rqptr)

{
   register struct HTAdminTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminEnd()\n");

   tkptr = rqptr->HTAdminTaskPtr;

   /* ensure parse internal data structures are released */
   if (tkptr->SearchOds.ParseInUse) OdsParseRelease (&tkptr->SearchOds);

   if (tkptr->FileOds.Fab.fab$w_ifi) OdsClose (&tkptr->FileOds, NULL, 0);

   SysDclAst (tkptr->NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Begin a page providing a list of HTA Databases in a form for administering
them.  Set up search for authentication Database files.
*/

HTAdminDatabaseBegin (struct RequestStruct *rqptr)

{
   static $DESCRIPTOR (AuthFileSpecFaoDsc, "!AZ*!AZ;0");

   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Administer HTA Database</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Administer HTA Database</H3>\n\
\
<FORM METHOD=GET ACTION=\"!AZ\">\n\
<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Database</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=0>\n\
<TR><TD VALIGN=top>\n\
<SELECT SIZE=!UL NAME=da>\n";

   register unsigned long  *vecptr;
   register char  *cptr, *sptr, *zptr;
   register struct HTAdminTaskStruct  *tkptr;

   int  status;
   unsigned short  Length;
   unsigned long  FaoVector [32];
   void  *AstFunctionPtr;
   $DESCRIPTOR (AuthFileSpecDsc, "");

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminDatabaseBegin()\n");

   tkptr = rqptr->HTAdminTaskPtr;

   AuthFileSpecDsc.dsc$a_pointer = tkptr->AuthFileSpec;
   AuthFileSpecDsc.dsc$w_length = sizeof(tkptr->AuthFileSpec)-1;

   sys$fao (&AuthFileSpecFaoDsc, &Length, &AuthFileSpecDsc,
            HTA_DIRECTORY, HTA_FILE_TYPE);
   tkptr->AuthFileSpec[Length] = '\0';
   if (Debug) fprintf (stdout, "AuthFileSpec |%s|\n", tkptr->AuthFileSpec);

   OdsParse (&tkptr->SearchOds,
             tkptr->AuthFileSpec, Length, NULL, 0,
             0, NULL, rqptr);

   if (VMSnok (status = tkptr->SearchOds.Fab.fab$l_sts))
   {
      rqptr->rqResponse.ErrorTextPtr = MapVmsPath (tkptr->AuthFileSpec, rqptr);
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->AuthFileSpec;
      ErrorVmsStatus (rqptr, status, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;
   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = rqptr->ScriptName;
   *vecptr++ = DatabaseListSize;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   tkptr->FileCount = 0;

   SysDclAst (&HTAdminDatabaseSearch, rqptr);
}

/*****************************************************************************/
/*
(AST) function to invoke another sys$search() call when listing authentication
Databases.
*/ 

HTAdminDatabaseSearch (struct RequestStruct *rqptr)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminDatabaseSearch()\n");

   OdsSearch (&rqptr->HTAdminTaskPtr->SearchOds,
              &HTAdminDatabaseSearchAst, rqptr);
}

/*****************************************************************************/
/*
AST completion routine called each time sys$search() completes.  It will 
either point to another file name found or have "no more files found" status 
(or an error!).
*/ 

HTAdminDatabaseSearchAst (struct FAB *FabPtr)

{
   register struct RequestStruct  *rqptr;
   register struct HTAdminTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
      "HTAdminDatabaseSearchAst() sts: %%X%08.08X stv: %%X%08.08X\n",
      FabPtr->fab$l_sts, FabPtr->fab$l_stv);

   /* retrieve the pointer to the client thread from the FAB user context */
   rqptr = FabPtr->fab$l_ctx;
   /* get the pointer to the task structure */
   tkptr = rqptr->HTAdminTaskPtr;

   if (VMSnok (status = tkptr->SearchOds.Fab.fab$l_sts))
   {
      if (status == RMS$_FNF || status == RMS$_NMF)
      {
         /* end of search */
         tkptr->SearchOds.ParseInUse = false;
         HTAdminDatabaseEnd (rqptr);
         return;
      }

      /* sys$search() error */
      rqptr->rqResponse.ErrorTextPtr = MapVmsPath (tkptr->AuthFileSpec, rqptr);
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->AuthFileSpec;
      ErrorVmsStatus (rqptr, status, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /* terminate following the last character in the version number */
   tkptr->SearchOds.NamVersionPtr[tkptr->SearchOds.NamVersionLength] = '\0';
   if (Debug) fprintf (stdout, "Database |%s|\n", tkptr->SearchOds.ResFileName);

   tkptr->FileCount++;

   status = NetWriteFao (rqptr, "<OPTION VALUE=\"!#HF\">!#HF\n",
                         tkptr->SearchOds.NamNameLength,
                         tkptr->SearchOds.NamNamePtr,
                         tkptr->SearchOds.NamNameLength,
                         tkptr->SearchOds.NamNamePtr);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFao()", FI_LI);

   SysDclAst (&HTAdminDatabaseSearch, rqptr);
}

/*****************************************************************************/
/*
End authentication Database file search.  Conclude form's HTML.
*/

HTAdminDatabaseEnd (struct RequestStruct *rqptr)

{
   static char  EndPageFao [] =
"</SELECT>\n\
</TD><TD VALIGN=top>\n\
<INPUT TYPE=radio NAME=do VALUE=HTAACCESS CHECKED>access<SUP>1</SUP>\n\
<BR><INPUT TYPE=radio NAME=do VALUE=HTALISTB>list/brief<SUP>1</SUP>\n\
<BR><INPUT TYPE=radio NAME=do VALUE=HTALISTF>list/full<SUP>1</SUP>\n\
<BR><INPUT TYPE=radio NAME=do VALUE=HTACREATE>create<SUP>2</SUP>\n\
<BR><INPUT TYPE=radio NAME=do VALUE=HTADELETE>delete<SUP>1</SUP>\n\
<BR><INPUT TYPE=radio NAME=do VALUE=reset>purge cache<SUP>1[or3]</SUP>\n\
<BR><INPUT TYPE=submit VALUE=\" Do \">\n\
<INPUT TYPE=reset VALUE=\" Reset \">\n\
</TD></TR>\n\
</TABLE>\n\
<SUP>1.</SUP> !AZ\n\
<BR><SUP>2.</SUP> enter name <INPUT TYPE=text NAME=ad SIZE=20>\n\
<BR><SUP>3.</SUP> if none selected then purges complete cache\n\
\
</TR>\n\
</TABLE>\n\
</FORM>\n\
\
</BODY>\n\
</HTML>\n";

   register unsigned long  *vecptr;
   register struct HTAdminTaskStruct  *tkptr;

   int  status;
   unsigned long  FaoVector [32];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminDatabaseEnd()\n");

   tkptr = rqptr->HTAdminTaskPtr;

   vecptr = FaoVector;
   if (tkptr->FileCount)
      *vecptr++ = "select from list";
   else
      *vecptr++ = "<I>none available</I>";

   status = NetWriteFaol (rqptr, EndPageFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (&HTAdminEnd, rqptr);
}

/*****************************************************************************/
/*
*/

HTAdminDatabaseUsersBegin
(
struct RequestStruct *rqptr,
char *DatabaseName
)
{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Administer HTA Database</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Administer HTA Database</H3>\n\
\
<FORM METHOD=GET ACTION=\"!AZ\">\n\
<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Users in !AZ</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=0>\n\
<TR><TD VALIGN=top>\n\
<SELECT SIZE=!UL NAME=u>\n";

   register unsigned long  *vecptr;
   register char  *cptr, *sptr, *zptr;
   register struct HTAdminTaskStruct  *tkptr;

   int  status;
   unsigned long  FaoVector [32];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminDatabaseBegin()\n");

   tkptr = rqptr->HTAdminTaskPtr;

   if (VMSnok (HTAdminOpenDatabaseForRead (rqptr, DatabaseName)))
      return;

   /**************/
   /* begin page */
   /**************/

   tkptr->RecordCount = tkptr->UserCount = 0;

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;
   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = DatabaseName;
   *vecptr++ = UserNameListSize;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (&HTAdminDatabaseUsersNext, rqptr);
}

/*****************************************************************************/
/*
Queue a read of the next record from the file.  When the read completes call 
HTAdminDatabaseUsersNextAst() function.
*/ 

HTAdminDatabaseUsersNext (struct RequestStruct *rqptr)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminDatabaseUsersNext()\n");

   /* asynchronous get service */
   rqptr->HTAdminTaskPtr->FileOds.Rab.rab$l_rop |= RAB$M_ASY;
   sys$get (&rqptr->HTAdminTaskPtr->FileOds.Rab,
            &HTAdminDatabaseUsersNextAst,
            &HTAdminDatabaseUsersNextAst);
}

/*****************************************************************************/
/*
A user record has been read from the authentication Database.
*/ 

HTAdminDatabaseUsersNextAst (struct RAB *RabPtr)

{
   register int  cnt;
   register char  *cptr, *sptr;
   register struct RequestStruct  *rqptr;
   register struct HTAdminTaskStruct  *tkptr;

   int  status;
   char  Buffer [128];

   /*********/
   /* begin */
   /*********/

   if (Debug)
   {
      fprintf (stdout,
"HTAdminDatabaseUsersNextAst sts: %%X%08.08X stv: %%X%08.08X rsz: %d\n",
      RabPtr->rab$l_sts, RabPtr->rab$l_stv,  RabPtr->rab$w_rsz);
   }

   rqptr = RabPtr->rab$l_ctx;
   tkptr = rqptr->HTAdminTaskPtr;

   if (VMSnok (tkptr->FileOds.Rab.rab$l_sts))
   {
      if (tkptr->FileOds.Rab.rab$l_sts == RMS$_EOF)
      {
         if (Debug) fprintf (stdout, "RMS$_EOF\n");
         OdsClose (&tkptr->FileOds, NULL, 0);
         HTAdminDatabaseUsersList (rqptr);
         return;
      }

      rqptr->rqResponse.ErrorTextPtr = MapVmsPath (tkptr->AuthFileName, rqptr);
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->AuthFileName;
      ErrorVmsStatus (rqptr, tkptr->FileOds.Rab.rab$l_sts, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /* check the version of the authorization database */
   if (tkptr->AuthHtRecord.DatabaseVersion &&
       tkptr->AuthHtRecord.DatabaseVersion != AuthCurrentDatabaseVersion)
   {
      rqptr->rqResponse.ErrorTextPtr = MapVmsPath (tkptr->AuthFileName, rqptr);
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->AuthFileName;
      ErrorVmsStatus (rqptr, SS$_INCOMPAT & 0xfffffffe, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /* if the record has been removed (by zeroing) then ignore */
   if (!tkptr->AuthHtRecord.UserNameLength)
   {
      HTAdminDatabaseUsersNext (rqptr);
      return;
   }

   tkptr->UserCount++;
   if (Debug)
      fprintf (stdout, "%d. |%s|\n",
               tkptr->UserCount, tkptr->AuthHtRecord.UserName);

   if ((tkptr->UserCount * sizeof(tkptr->AuthHtRecord.UserName)) >
       tkptr->UserListLength)
   {
      /* need more (or some) list space */
      tkptr->UserListLength += 32 * sizeof(tkptr->AuthHtRecord.UserName);
      tkptr->UserListPtr = VmReallocHeap (rqptr, tkptr->UserListPtr,
                                          tkptr->UserListLength, FI_LI);
   }

   /* copy username including name terminating null */
   memcpy (tkptr->UserListPtr +
           ((tkptr->UserCount - 1) * sizeof(tkptr->AuthHtRecord.UserName)),
           tkptr->AuthHtRecord.UserName,
           sizeof(tkptr->AuthHtRecord.UserName));

   HTAdminDatabaseUsersNext (rqptr);
}

/*****************************************************************************/
/*
Humble bubble sort I'm afraid :^(  Gives the illusion that the database is
ordered (apart from that of entry sequence :^), although does provide the
advantage of viewing an ordered list.  It formats them as part of HTML
selection list.
*/ 

HTAdminDatabaseUsersList (struct RequestStruct *rqptr)

{
   register int  idx1, idx2, size;
   register char  *cptr1, *cptr2;
   register struct HTAdminTaskStruct  *tkptr;

   int  status,
        UserCount;
   char UserName [sizeof(tkptr->AuthHtRecord.UserName)];

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "HTAdminDatabaseUsersList() %d of %d\n",
               rqptr->HTAdminTaskPtr->UserListCount,
               rqptr->HTAdminTaskPtr->UserCount);

   tkptr = rqptr->HTAdminTaskPtr;

   size = sizeof(tkptr->AuthHtRecord.UserName);

   if (!tkptr->UserCount)
   {
      HTAdminDatabaseUsersEnd (rqptr);
      return;
   }

   /********/
   /* sort */
   /********/

   for (idx1 = 0; idx1 < tkptr->UserCount-1; idx1++)
   {
      for (idx2 = idx1+1; idx2 < tkptr->UserCount; idx2++)
      {
          cptr1 = tkptr->UserListPtr + (idx1 * size);
          cptr2 = tkptr->UserListPtr + (idx2 * size);
          if (strcmp (cptr1, cptr2) <= 0) continue;
          memcpy (UserName, cptr1, size);
          memcpy (cptr1, cptr2, size);
          memcpy (cptr2, UserName, size);
      }
   }

   /*************************/
   /* create selection list */
   /*************************/

   cptr1 = tkptr->UserListPtr;
   for (UserCount = 0; UserCount < tkptr->UserCount; UserCount++)
   {
      status = NetWriteFao (rqptr, "<OPTION VALUE=\"!HZ\">!HZ\n", cptr1, cptr1);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFao()", FI_LI);
      cptr1 += sizeof(tkptr->AuthHtRecord.UserName);
   }

   HTAdminDatabaseUsersEnd (rqptr);
}

/*****************************************************************************/
/*
End user names in authentication Database.
*/

HTAdminDatabaseUsersEnd (struct RequestStruct *rqptr)

{
   static char  EndPageFao [] =
"</SELECT>\n\
</TD><TD VALIGN=top>\n\
<INPUT TYPE=radio NAME=do VALUE=view CHECKED>view<SUP>1</SUP>\n\
<BR><INPUT TYPE=radio NAME=do VALUE=modify>modify<SUP>1</SUP>\n\
<BR><INPUT TYPE=radio NAME=do VALUE=add>add<SUP>2</SUP>\n\
<BR><INPUT TYPE=radio NAME=do VALUE=delete>delete<SUP>1</SUP>\n\
<BR><INPUT TYPE=radio NAME=do VALUE=purge>purge cache<SUP>1[or3]</SUP>\n\
<BR><INPUT TYPE=submit VALUE=\" Do \">\n\
<INPUT TYPE=reset VALUE=\" Reset \">\n\
</TD></TR>\n\
</TABLE>\n\
<SUP>1.</SUP> !AZ\n\
<BR><SUP>2.</SUP> enter name <INPUT TYPE=text NAME=au SIZE=20>\n\
<BR><SUP>3.</SUP> if none selected then resets all users\n\
\
</TR>\n\
</TABLE>\n\
</FORM>\n\
\
</BODY>\n\
</HTML>\n";

   register unsigned long  *vecptr;
   register struct HTAdminTaskStruct  *tkptr;

   int  status;
   unsigned long  FaoVector [32];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminDatabaseUsersEnd()\n");

   tkptr = rqptr->HTAdminTaskPtr;

   vecptr = FaoVector;
   if (tkptr->UserCount)
      *vecptr++ = "select from list";
   else
      *vecptr++ = "<I>none available</I>";

   status = NetWriteFaol (rqptr, EndPageFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (&HTAdminEnd, rqptr);
}

/*****************************************************************************/
/*
*/

HTAdminListUsersBegin
(
struct RequestStruct *rqptr,
char *DatabaseName
)
{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Administer HTA Database</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Administer HTA Database</H3>\n\
\
<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1>\n\
<TR><TH COLSPAN=!UL>Users in !AZ</TH></TR>\n\
!AZ";

   static char  BriefHeading [] =
"<TR><TH>Username</TH><TH>Full Name</TH><TH>Access</TH>\
<TH>Added</TH><TH COLSPAN=2>Accessed</TH></TR>\n\
<TR><TH COLSPAN=6></TH></TR>\n";

   static char  FullHeading [] =
"<TR><TH>Username</TH><TH COLSPAN=2>Full Name</TH>\
<TH COLSPAN=3>Access</TH><TH>Added</TH></TR>\n\
<TR><TD></TD><TH COLSPAN=6>Contact</TH></TR>\n\
<TR><TD></TD><TH COLSPAN=6>Email</TH></TR>\n\
<TR><TD></TD>\
<TH COLSPAN=2>Accessed</TH>\
<TH COLSPAN=2>Change</TH>\
<TH COLSPAN=2>Failure</TH></TR>\n\
<TR><TH COLSPAN=7></TH></TR>\n";

   register unsigned long  *vecptr;
   register char  *cptr, *sptr, *zptr;
   register struct HTAdminTaskStruct  *tkptr;

   int  status;
   unsigned long  FaoVector [32];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminListUsersBegin()\n");

   tkptr = rqptr->HTAdminTaskPtr;

   if (VMSnok (HTAdminOpenDatabaseForRead (rqptr, DatabaseName)))
      return;

   /**************/
   /* begin page */
   /**************/

   tkptr->RecordCount = tkptr->UserCount = 0;

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;
   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;

   if (tkptr->BriefList)
      *vecptr++ = 6;
   else
      *vecptr++ = 7;

   *vecptr++ = DatabaseName;

   if (tkptr->BriefList)
      *vecptr++ = BriefHeading;
   else
      *vecptr++ = FullHeading;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (&HTAdminListUsersNext, rqptr);
}

/*****************************************************************************/
/*
Queue a read of the next record from the file.  When the read completes call 
HTAdminListUsersNextAst() function.
*/ 

HTAdminListUsersNext (struct RequestStruct *rqptr)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminListUsersNext()\n");

   /* asynchronous get service */
   rqptr->HTAdminTaskPtr->FileOds.Rab.rab$l_rop |= RAB$M_ASY;
   sys$get (&rqptr->HTAdminTaskPtr->FileOds.Rab,
            &HTAdminListUsersNextAst,
            &HTAdminListUsersNextAst);
}

/*****************************************************************************/
/*
A user record has been read from the authentication Database.
*/ 

HTAdminListUsersNextAst (struct RAB *RabPtr)

{
   register int  cnt;
   register char  *cptr, *sptr;
   register struct RequestStruct  *rqptr;
   register struct HTAdminTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
   {
      fprintf (stdout,
"HTAdminListUsersNextAst sts: %%X%08.08X stv: %%X%08.08X rsz: %d\n",
      RabPtr->rab$l_sts, RabPtr->rab$l_stv,  RabPtr->rab$w_rsz);
   }

   rqptr = RabPtr->rab$l_ctx;
   tkptr = rqptr->HTAdminTaskPtr;

   if (VMSnok (tkptr->FileOds.Rab.rab$l_sts))
   {
      if (tkptr->FileOds.Rab.rab$l_sts == RMS$_EOF)
      {
         if (Debug) fprintf (stdout, "RMS$_EOF\n");
         OdsClose (&tkptr->FileOds, NULL, 0);
         HTAdminListUsersListSort (rqptr);
         return;
      }

      rqptr->rqResponse.ErrorTextPtr = MapVmsPath (tkptr->AuthFileName, rqptr);
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->AuthFileName;
      ErrorVmsStatus (rqptr, tkptr->FileOds.Rab.rab$l_sts, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /* check the version of the authorization database */
   if (tkptr->AuthHtRecord.DatabaseVersion &&
       tkptr->AuthHtRecord.DatabaseVersion != AuthCurrentDatabaseVersion)
   {
      rqptr->rqResponse.ErrorTextPtr = MapVmsPath (tkptr->AuthFileName, rqptr);
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->AuthFileName;
      ErrorVmsStatus (rqptr, SS$_INCOMPAT & 0xfffffffe, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /* if the record has been removed (by zeroing) then ignore */
   if (!tkptr->AuthHtRecord.UserNameLength)
   {
      HTAdminListUsersNext (rqptr);
      return;
   }

   tkptr->UserCount++;

   if ((tkptr->UserCount * sizeof(struct AuthHtRecordStruct)) >
       tkptr->UserListLength)
   {
      /* need more (or some) list space */
      tkptr->UserListLength += 32 * sizeof(struct AuthHtRecordStruct);
      tkptr->UserListPtr = VmReallocHeap (rqptr, tkptr->UserListPtr,
                                          tkptr->UserListLength, FI_LI);
   }

   /* copy the entire user record into the list */
   memcpy (tkptr->UserListPtr +
           ((tkptr->UserCount - 1) * sizeof(struct AuthHtRecordStruct)),
           &tkptr->AuthHtRecord, sizeof(struct AuthHtRecordStruct));

   HTAdminListUsersNext (rqptr);
}

/*****************************************************************************/
/*
Humble bubble sort I'm afraid :^(  Gives the illusion that the database is
ordered (apart from that of entry sequence :^), although does provide the
advantage of viewing an ordered list.  Bit more expensive this one, copying
aroung 512 byte records.  I'll improve it someday, sigh :^(
*/ 

HTAdminListUsersListSort (struct RequestStruct *rqptr)

{
   register int  idx1, idx2, size;
   register char  *cptr1, *cptr2;
   register struct AuthHtRecordStruct  *rptr1, *rptr2;
   register struct HTAdminTaskStruct  *tkptr;

   struct AuthHtRecordStruct  AuthHtRecord;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminListUsersListSort()\n");

   tkptr = rqptr->HTAdminTaskPtr;

   if (!tkptr->UserCount)
   {
      HTAdminListUsersEnd (rqptr);
      return;
   }

   size = sizeof(struct AuthHtRecordStruct);

   for (idx1 = 0; idx1 < tkptr->UserCount-1; idx1++)
   {
      for (idx2 = idx1+1; idx2 < tkptr->UserCount; idx2++)
      {
          rptr1 = &((struct AuthHtRecordStruct*)tkptr->UserListPtr)[idx1];
          rptr2 = &((struct AuthHtRecordStruct*)tkptr->UserListPtr)[idx2];
          if (strcmp (rptr1->UserName, rptr2->UserName) <= 0) continue;
          memcpy (&AuthHtRecord, (char*)rptr1, size);
          memcpy ((char*)rptr1, (char*)rptr2, size);
          memcpy ((char*)rptr2, &AuthHtRecord, size);
      }
   }

   tkptr->UserListCount = 0;
   HTAdminListUsersList (rqptr);
}

/*****************************************************************************/
/*
This function is called for each username in the sorted list.  It reads them
sequentially, formats them as part of HTML table, then buffers the output,
ASTing back to this function for the next.
*/ 

HTAdminListUsersList (struct RequestStruct *rqptr)

{
   static char  BriefFao [] =
"<TR>\
<TD><B>!AZ!HZ!AZ</B></TD><TD>!HZ</TD><TD>!AZ!AZ</TD>\n\
<TD>!17%W</TD>\
<TD>!UL</TD><TD>!17%W</TD>\
</TR>\n";

   static char  FullFao [] =
"<TR><TD><B>!AZ!HZ!AZ</B></TD><TD COLSPAN=2>!HZ</TD>\
<TD COLSPAN=3>!AZ!AZ</TD><TD>!17%W</TD></TR>\n\
<TR><TD></TD><TD COLSPAN=6><PRE>!HZ</PRE></TD></TR>\n\
<TR><TD></TD><TD COLSPAN=6>!%%</TD></TR>\n\
<TR><TD></TD>\
<TD>!UL</TD><TD>!17%W</TD>\
<TD>!UL</TD><TD>!17%W</TD>\
<TD>!UL</TD><TD>!17%W</TD>\
</TR>\n";

   register unsigned long  *vecptr;
   register struct AuthHtRecordStruct  *rptr;
   register struct HTAdminTaskStruct  *tkptr;

   int  status;
   unsigned long  FaoVector [32];
   char  *CanStringPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "HTAdminListUsersList() %d of %d\n",
               rqptr->HTAdminTaskPtr->UserListCount,
               rqptr->HTAdminTaskPtr->UserCount);

   tkptr = rqptr->HTAdminTaskPtr;

   if (tkptr->UserListCount >= tkptr->UserCount)
   {
      HTAdminListUsersEnd (rqptr);
      return;
   }

   rptr = &((struct AuthHtRecordStruct*)tkptr->UserListPtr)
             [tkptr->UserListCount];

   if ((CanStringPtr =
        HTAdminCanString (rqptr, rptr->Flags, tkptr->BriefList)) == NULL)
   {
      HTAdminEnd (rqptr);
      return;
   }

   vecptr = FaoVector;

   if (rptr->Flags & AUTH_FLAG_ENABLED)
      *vecptr++ = "";
   else
      *vecptr++ = "<I>";
   *vecptr++ = rptr->UserName;
   if (rptr->Flags & AUTH_FLAG_ENABLED)
      *vecptr++ = "";
   else
      *vecptr++ = "</I>";

   *vecptr++ = rptr->FullName;
   *vecptr++ = CanStringPtr;

   if (rptr->Flags & AUTH_FLAG_HTTPS_ONLY)
      *vecptr++ = " (&quot;https:&quot;&nbsp;only)";
   else
      *vecptr++ = "";

   if (tkptr->BriefList)
   {
      *vecptr++ = &rptr->AddedBinTime;
      *vecptr++ = rptr->AccessCount;
      *vecptr++ = &rptr->LastAccessBinTime;
   }
   else
   {
      *vecptr++ = &rptr->AddedBinTime;
      *vecptr++ = rptr->Contact;
      if (rptr->Email[0])
      {
         *vecptr++ = "<A HREF=\"mailto:!AZ\">!AZ</A>";
         *vecptr++ = rptr->Email;
         *vecptr++ = rptr->Email;
      }
      else
         *vecptr++ = "";
      *vecptr++ = rptr->AccessCount;
      *vecptr++ = &rptr->LastAccessBinTime;
      *vecptr++ = rptr->ChangeCount;
      *vecptr++ = &rptr->LastChangeBinTime;
      *vecptr++ = rptr->FailureCount;
      *vecptr++ = &rptr->LastFailureBinTime;
   }

   if (tkptr->BriefList)
      status = NetWriteFaol (rqptr, BriefFao, &FaoVector);
   else
      status = NetWriteFaol (rqptr, FullFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   tkptr->UserListCount++;

   SysDclAst (&HTAdminListUsersList, rqptr);
}

/*****************************************************************************/
/*
End list user information in authentication Database.
*/

HTAdminListUsersEnd (struct RequestStruct *rqptr)

{
   static char  NotNoneFao [] =
"<TR><TD COLSPAN=!UL><I>(none)</I></TD></TR>\n\
</TABLE>\n\
\
</BODY>\n\
</HTML>\n";

   static char  TotalFao [] =
"<TR><TH></TH></TR>\n\
<TR><TH COLSPAN=!UL>Total: !UL</TH></TR>\n\
</TABLE>\n\
\
</BODY>\n\
</HTML>\n";

   register unsigned long  *vecptr;
   register struct HTAdminTaskStruct  *tkptr;

   int  status;
   unsigned long  FaoVector [32];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminListUsersEnd()\n");

   tkptr = rqptr->HTAdminTaskPtr;

   vecptr = FaoVector;

   if (tkptr->BriefList)
      *vecptr++ = 6;
   else
      *vecptr++ = 7;

   if (tkptr->UserCount)
   {
      *vecptr++ = tkptr->UserCount;
      status = NetWriteFaol (rqptr, TotalFao, &FaoVector);
   }
   else
      status = NetWriteFaol (rqptr, NotNoneFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (&HTAdminEnd, rqptr);
}

/*****************************************************************************/
/*
Display an authentication database record.
*/

HTAdminUserView
(
struct RequestStruct *rqptr,
char *DatabaseName,
char *UserName
)
{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Administer HTA Database</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Administer HTA Database</H3>\n\
!20%W\n\
\
<P><TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1>\n\
<TR><TD>\n\
<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=0>\n\
<TR><TH COLSPAN=4>User !HZ in !AZ!AZ</TH></TR>\n\
<TR><TH ALIGN=right>Full Name:&nbsp;</TH>\
<TD COLSPAN=3>!HZ</TD></TR>\n\
<TR><TH ALIGN=right VALIGN=top>Contact:&nbsp;</TH>\
<TD COLSPAN=3><PRE>!HZ</PRE></TD></TR>\n\
<TR><TH ALIGN=right>E-mail:&nbsp;</TH>\
<TD COLSPAN=3>!%%</TD></TR>\n\
<TR><TH ALIGN=right>Access:&nbsp;</TH>\
<TD COLSPAN=3>!AZ!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Password:&nbsp;</TH>\
<TD>!AZ</TD><TD></TD><TD></TD></TR>\n\
<TR><TH ALIGN=right>Added:&nbsp;</TH>\
<TD COLSPAN=2>!20%W</TD></TR>\n\
<TR><TH ALIGN=right>Changed:&nbsp;</TH>\
<TD COLSPAN=2>!20%W</TD><TD ALIGN=right>!UL</TD></TR>\n\
<TR><TH ALIGN=right>Accessed:&nbsp;</TH>\
<TD COLSPAN=2>!20%W</TD><TD ALIGN=right>!UL</TD></TR>\n\
<TR><TH ALIGN=right>Failed:&nbsp;</TH>\
<TD COLSPAN=2>!20%W</TD><TD ALIGN=right>!UL</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
</BODY>\n\
</HTML>\n";

   register unsigned long  *vecptr;
   register struct HTAdminTaskStruct  *tkptr;

   int  status;
   unsigned long  FaoVector [64];
   char  *CanStringPtr;
   struct AuthHtRecordStruct AuthHtRecord;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminUserView()\n");

   tkptr = rqptr->HTAdminTaskPtr;

   if (!DatabaseName || !UserName[0])
   {
      rqptr->rqResponse.HttpStatus = 400;
      ErrorGeneral (rqptr, ErrorHTAdminInsufficient, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /* look for the record, close the database file immediately */
   status = AuthAccessHtDatabase (false, DatabaseName, UserName,
                                  &AuthHtRecord, NULL, NULL);
   if (status == RMS$_EOF)
   {
      rqptr->rqResponse.HttpStatus = 404;
      ErrorGeneral (rqptr, ErrorHTAdminUserNotFound, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }
   if (VMSnok (status))
   {
      rqptr->rqResponse.ErrorTextPtr = ErrorHTAdminDatabase;
      rqptr->rqResponse.ErrorOtherTextPtr = DatabaseName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /**************/
   /* begin page */
   /**************/

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;
   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = &rqptr->rqTime.Vms64bit;

   *vecptr++ = AuthHtRecord.UserName;
   *vecptr++ = DatabaseName;
   if (AuthHtRecord.Flags & AUTH_FLAG_ENABLED)
      *vecptr++ = "";
   else
      *vecptr++ = "<FONT COLOR=\"#ff0000\"> is DISABLED</FONT>";

   *vecptr++ = AuthHtRecord.FullName;
   *vecptr++ = AuthHtRecord.Contact;

   if (AuthHtRecord.Email[0])
   {
      *vecptr++ = "<A HREF=\"mailto:!HZ\">!HZ</A>";
      *vecptr++ = AuthHtRecord.Email;
      *vecptr++ = AuthHtRecord.Email;
   }
   else
      *vecptr++ = "";

   if ((CanStringPtr =
        HTAdminCanString (rqptr, AuthHtRecord.Flags, false)) == NULL)
   {
      HTAdminEnd (rqptr);
      return;
   }
   *vecptr++ = CanStringPtr;

   if (AuthHtRecord.Flags & AUTH_FLAG_HTTPS_ONLY)
      *vecptr++ = " (&quot;https:&quot;&nbsp;only)";
   else
      *vecptr++ = "";

   if (AuthHtRecord.HashedPwd[0] || AuthHtRecord.HashedPwd[1])
      *vecptr++ = "********";
   else
      *vecptr++ = "";

   *vecptr++ = &AuthHtRecord.AddedBinTime;
   *vecptr++ = &AuthHtRecord.LastChangeBinTime;
   *vecptr++ = AuthHtRecord.ChangeCount;
   *vecptr++ = &AuthHtRecord.LastAccessBinTime;
   *vecptr++ = AuthHtRecord.AccessCount;
   *vecptr++ = &AuthHtRecord.LastFailureBinTime;
   *vecptr++ = AuthHtRecord.FailureCount;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (&HTAdminEnd, rqptr);
}

/*****************************************************************************/
/*
Form for modify or add an authentication database record.
*/

HTAdminModifyUserForm
(
struct RequestStruct *rqptr,
boolean AddUser,
char *DatabaseName,
char *UserName
)
{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Administer HTA Database</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Administer HTA Database</H3>\n\
\
<FORM METHOD=POST ACTION=\"!AZ\">\n\
<INPUT TYPE=HIDDEN NAME=do VALUE=!AZ>\n\
<INPUT TYPE=HIDDEN NAME=!AZ VALUE=\"!AZ\">\n\
<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1>\n\
<TR><TH COLSPAN=2>!AZ !AZ !AZin !AZ</TH></TR>\n\
<TR><TD COLSPAN=2>\n\
\
<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right>Full Name:&nbsp;</TH>\
<TD><INPUT TYPE=text NAME=f SIZE=!UL MAXLENGTH=!UL \
VALUE=\"!HZ\"></TD></TR>\n\
<TR><TH ALIGN=right>Contact:&nbsp;</TH>\
<TD><TEXTAREA NAME=co COLS=!UL ROWS=!UL>!HZ\
</TEXTAREA></TD></TR>\n\
<TR><TH ALIGN=right>E-mail:&nbsp;</TH>\
<TD><INPUT TYPE=text NAME=em SIZE=!UL MAXLENGTH=!UL \
VALUE=\"!HZ\"></TD></TR>\n\
<TR><TH ALIGN=right>Enabled:&nbsp;</TH><TD>\n\
<INPUT TYPE=radio NAME=en VALUE=yes!AZ>yes\n\
<INPUT TYPE=radio NAME=en VALUE=no!AZ>no\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Access:&nbsp;</TH><TD>\n\
<INPUT TYPE=radio NAME=ac VALUE=\"r\"!AZ>read-only\n\
<INPUT TYPE=radio NAME=ac VALUE=\"r+w\"!AZ>read <B>& write</B>\n\
<INPUT TYPE=radio NAME=ac VALUE=\"w\"!AZ>write-only\n\
</TD></TR>\n\
<TR><TH ALIGN=right>&quot;https:&quot; (SSL) Only:&nbsp;</TH><TD>\n\
<INPUT TYPE=radio NAME=hs VALUE=yes!AZ>yes\n\
<INPUT TYPE=radio NAME=hs VALUE=no!AZ>no\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Password:&nbsp;</TH>\
<TD><INPUT TYPE=password NAME=p SIZE=!UL MAXLENGTH=!UL></TD></TR>\n\
<TR><TH ALIGN=right>Verify:&nbsp;</TH>\
<TD><INPUT TYPE=password NAME=v SIZE=!UL MAXLENGTH=!UL></TD></TR>\n\
</TABLE>\n\
\
</TD></TR>\n\
<TR><TD COLSPAN=2><INPUT TYPE=submit VALUE=\" !AZ \">\n\
<INPUT TYPE=reset VALUE=\" Reset \"></TD></TR>\n\
</TD></TR>\n\
</TABLE>\n\
</FORM>\n\
\
</BODY>\n\
</HTML>\n";

   register unsigned long  *vecptr;
   register struct HTAdminTaskStruct  *tkptr;

   boolean  AlreadyExists;
   int  status;
   unsigned short  Length;
   unsigned long  FaoVector [64];
   struct AuthHtRecordStruct AuthHtRecord;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminModifyUserForm()\n");

   tkptr = rqptr->HTAdminTaskPtr;

   if (!DatabaseName[0] || !UserName[0])
   {
      rqptr->rqResponse.HttpStatus = 400;
      ErrorGeneral (rqptr, ErrorHTAdminInsufficient, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /* look for the record, close the database file immediately */
   if (AddUser)
   {
      status = AuthAccessHtDatabase (false, DatabaseName, UserName,
                                     &AuthHtRecord, NULL, NULL);
      if (VMSok (status))
         AlreadyExists = true;
      else
         AlreadyExists = false;
      if (status == RMS$_EOF) status = SS$_NORMAL;
   }
   else
   {
      status = AuthAccessHtDatabase (false, DatabaseName, UserName,
                                     &AuthHtRecord, NULL, NULL);
      if (status == RMS$_EOF)
      {
         rqptr->rqResponse.HttpStatus = 404;
         ErrorGeneral (rqptr, ErrorHTAdminUserNotFound, FI_LI);
         HTAdminEnd (rqptr);
         return;
      }
      AlreadyExists = false;
   }
   if (VMSnok (status))
   {
      rqptr->rqResponse.ErrorTextPtr = ErrorHTAdminDatabase;
      rqptr->rqResponse.ErrorOtherTextPtr = DatabaseName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }
      
   if (AddUser && !AlreadyExists)
      memset (&AuthHtRecord, 0, sizeof(struct AuthHtRecordStruct));

   /**************/
   /* begin page */
   /**************/

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;
   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;

   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   if (AddUser && !AlreadyExists)
   {
      *vecptr++ = "add";
      *vecptr++ = "au";
      *vecptr++ = UserName;
      *vecptr++ = "<FONT COLOR=\"#ff0000\">New User</FONT>";
      *vecptr++ = UserName;
      *vecptr++ = "";
      *vecptr++ = DatabaseName;
   }
   else
   {     
      *vecptr++ = "modify";
      *vecptr++ = "u";
      *vecptr++ = UserName;
      *vecptr++ = "User";
      *vecptr++ = UserName;
      if (AlreadyExists)
         *vecptr++ =
"<FONT COLOR=\"#ff0000\"> &nbsp;&nbsp;&nbsp;\
ALREADY EXISTS&nbsp;&nbsp;&nbsp; </FONT>";
      else
         *vecptr++ = "";
      *vecptr++ = DatabaseName;
   }

   *vecptr++ = AUTH_MAX_FULLNAME_LENGTH;
   *vecptr++ = AUTH_MAX_FULLNAME_LENGTH;
   *vecptr++ = AuthHtRecord.FullName;

   *vecptr++ = 40;
   *vecptr++ = 3;
   *vecptr++ = AuthHtRecord.Contact;

   *vecptr++ = 40;
   *vecptr++ = 40;
   *vecptr++ = AuthHtRecord.Email;

   if ((AuthHtRecord.Flags & AUTH_FLAG_ENABLED) ||
       (AddUser && !AlreadyExists))
   {
      *vecptr++ = " CHECKED";
      *vecptr++ = "";
   }
   else
   {
      *vecptr++ = "";
      *vecptr++ = " CHECKED";
   }

   if ((AuthHtRecord.Flags & AUTH_FLAG_DELETE  ||
        AuthHtRecord.Flags & AUTH_FLAG_POST ||
        AuthHtRecord.Flags & AUTH_FLAG_PUT) &&
       AuthHtRecord.Flags & AUTH_FLAG_GET)
   {
      *vecptr++ = "";
      *vecptr++ = " CHECKED";
      *vecptr++ = "";
   }
   else
   if (AuthHtRecord.Flags & AUTH_FLAG_GET)
   {
      *vecptr++ = " CHECKED";
      *vecptr++ = "";
      *vecptr++ = "";
   }
   else
   {
      *vecptr++ = " CHECKED";
      *vecptr++ = "";
      *vecptr++ = "";
   }

   if (AuthHtRecord.Flags & AUTH_FLAG_HTTPS_ONLY)
   {
      *vecptr++ = " CHECKED";
      *vecptr++ = "";
   }
   else
   {
      *vecptr++ = "";
      *vecptr++ = " CHECKED";
   }

   *vecptr++ = AUTH_MAX_PASSWORD_LENGTH;
   *vecptr++ = AUTH_MAX_PASSWORD_LENGTH;
   *vecptr++ = AUTH_MAX_PASSWORD_LENGTH;
   *vecptr++ = AUTH_MAX_PASSWORD_LENGTH;

   if (AddUser && !AlreadyExists)
      *vecptr++ = "Add";
   else
      *vecptr++ = "Modify";

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (&HTAdminEnd, rqptr);
}

/*****************************************************************************/
/*
*/

HTAdminModifyUser
(
struct RequestStruct *rqptr,
boolean AddUser,
char *DatabaseName,
char *UserName,
char *FullName,
char *Contact,
char *Email,
char *Enabled,
char *Access,
char *HttpsOnly,
char *PasswordNew,
char *PasswordVerify
)
{
   register char  *cptr, *sptr;

   int  status;
   unsigned long  HashedPwd [2];
   unsigned char  A1DigestLoCase [16],
                  A1DigestUpCase [16];
   struct AuthHtRecordStruct AuthHtRecord;
   struct AuthCacheRecordStruct  AuthCacheRecord;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminModifyUserForm()\n");

   if (!rqptr->RemoteUser[0])
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_REQUIRED), FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /*******************/
   /* process request */
   /*******************/

   if (!DatabaseName[0] || !UserName[0] || !FullName[0] ||
       !Enabled[0] || !Access[0])
   {
      rqptr->rqResponse.HttpStatus = 400;
      ErrorGeneral (rqptr, ErrorHTAdminInsufficient, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   if ((toupper(Enabled[0]) != 'Y' && toupper(Enabled[0]) != 'N') ||
       (!strsame(Access, "r", -1) && !strsame(Access, "r+w", -1) &&
        !strsame(Access, "w", -1)))
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, ErrorHTAdminParameter, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   if (!strsame (PasswordNew, PasswordVerify, -1))
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_HTADMIN_PWD_INCORRECT), FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   if (PasswordNew[0])
   {
      if (VMSnok (status =
          AuthGenerateHashPassword (UserName, PasswordNew, &HashedPwd)))
      {
         rqptr->rqResponse.ErrorTextPtr = "password hash";
         ErrorVmsStatus (rqptr, status, FI_LI);
         HTAdminEnd (rqptr);
         return;
      }

      if (VMSnok (status =
          AuthGenerateDigestPassword (rqptr->rqAuth.RealmDescrPtr,
                                      rqptr->RemoteUser,
                                      PasswordNew, &A1DigestLoCase,
                                      &A1DigestUpCase)))
      {
         rqptr->rqResponse.ErrorTextPtr = "password digest";
         ErrorVmsStatus (rqptr, status, FI_LI);
         HTAdminEnd (rqptr);
         return;
      }
   }

   /***********************/
   /* update the database */
   /***********************/

   /* look for the record, leave the database file open if found */
   status = AuthAccessHtDatabase (true, DatabaseName, UserName,
                                  &AuthHtRecord, NULL, NULL);
   if (AddUser)
   {
      if (VMSok (status))
      {
         /* ensure the database is closed */
         AuthAccessHtDatabase (false, NULL, NULL, NULL, NULL, NULL);
         rqptr->rqResponse.HttpStatus = 404;
         ErrorGeneral (rqptr, ErrorHTAdminUserExists, FI_LI);
         HTAdminEnd (rqptr);
         return;
      }
      if (status == RMS$_EOF) status = SS$_NORMAL;
      memset (&AuthHtRecord, 0, sizeof(struct AuthHtRecordStruct));
   }
   else
   {
      if (status == RMS$_EOF)
      {
         /* ensure the database is closed */
         AuthAccessHtDatabase (false, NULL, NULL, NULL, NULL, NULL);
         rqptr->rqResponse.HttpStatus = 404;
         ErrorGeneral (rqptr, ErrorHTAdminUserNotFound, FI_LI);
         HTAdminEnd (rqptr);
         return;
      }
   }
   if (VMSnok (status))
   {
      rqptr->rqResponse.ErrorTextPtr = ErrorHTAdminDatabase;
      rqptr->rqResponse.ErrorOtherTextPtr = DatabaseName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   memcpy (&AuthHtRecord.UserName, UserName, sizeof(AuthHtRecord.UserName));
   AuthHtRecord.UserNameLength = strlen(UserName);
   memcpy (&AuthHtRecord.FullName, FullName, sizeof(AuthHtRecord.FullName));
   memcpy (&AuthHtRecord.Contact, Contact, sizeof(AuthHtRecord.Contact));
   memcpy (&AuthHtRecord.Email, Email, sizeof(AuthHtRecord.Email));
   if (AddUser)
   {
      memcpy (&AuthHtRecord.AddedBinTime, &rqptr->rqTime.Vms64bit, 8);
      AuthHtRecord.DatabaseVersion = AuthCurrentDatabaseVersion;
   }
   else
   {
      memcpy (&AuthHtRecord.LastChangeBinTime, &rqptr->rqTime.Vms64bit, 8);
      AuthHtRecord.ChangeCount++;
   }
   if (PasswordNew[0])
   {
      memcpy (&AuthHtRecord.HashedPwd, &HashedPwd, 8);
      memcpy (&AuthHtRecord.A1DigestLoCase, &A1DigestLoCase, 16);
      memcpy (&AuthHtRecord.A1DigestUpCase, &A1DigestUpCase, 16);
   }

   if (toupper(Enabled[0]) == 'Y')
      AuthHtRecord.Flags |= AUTH_FLAG_ENABLED;
   else
      AuthHtRecord.Flags &= ~AUTH_FLAG_ENABLED;

   if (toupper(HttpsOnly[0]) == 'Y')
      AuthHtRecord.Flags |= AUTH_FLAG_HTTPS_ONLY;
   else
      AuthHtRecord.Flags &= ~AUTH_FLAG_HTTPS_ONLY;

   /* reset all the method bits to zero */
   AuthHtRecord.Flags &= ~(AUTH_FLAG_DELETE | AUTH_FLAG_GET |
                           AUTH_FLAG_HEAD | AUTH_FLAG_POST | AUTH_FLAG_PUT);
   /* now set the relevant method bits on */
   if (strsame (Access, "r", -1))
      AuthHtRecord.Flags |= (AUTH_FLAG_GET | AUTH_FLAG_HEAD);
   else
   if (strsame (Access, "r+w", -1))
      AuthHtRecord.Flags |= (AUTH_FLAG_DELETE | AUTH_FLAG_GET |
                             AUTH_FLAG_HEAD | AUTH_FLAG_POST | AUTH_FLAG_PUT);
   else
   if (strsame (Access, "w", -1))
      AuthHtRecord.Flags |= (AUTH_FLAG_DELETE | AUTH_FLAG_POST | AUTH_FLAG_PUT);

   /* add/update the record, close the database file */
   if (AddUser)
      status = AuthAccessHtDatabase (false, NULL, NULL,
                                     NULL, &AuthHtRecord, NULL);
   else
      status = AuthAccessHtDatabase (false, NULL, NULL,
                                     NULL, NULL, &AuthHtRecord);
   if (VMSnok (status))
   {
      rqptr->rqResponse.ErrorTextPtr = ErrorHTAdminDatabase;
      rqptr->rqResponse.ErrorOtherTextPtr = DatabaseName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /**************/
   /* successful */
   /**************/

   if (AddUser)
      WriteFaoStdout ("%!AZ-I-AUTHHTA, !20%D, add !AZ to !AZ by !AZ.\'!AZ\'@!AZ\n",
         Utility, 0, UserName, DatabaseName,
         rqptr->RemoteUser, rqptr->rqAuth.RealmPtr,
         rqptr->rqNet.ClientHostName);
   else
      WriteFaoStdout (
         "%!AZ-I-AUTHHTA, !20%D, modify !AZ in !AZ by !AZ.\'!AZ\'@!AZ\n",
         Utility, 0, UserName, DatabaseName,
         rqptr->RemoteUser, rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

   /* reset relevant entries in the cache */
   if (VMSnok (AuthCacheReset (rqptr, DatabaseName, UserName)))
      return;

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   ReportSuccess (rqptr, "Record for !HZ in !AZ at !AZ !AZ.",
                  UserName, DatabaseName, ServerHostPort,
                  AddUser ? "added" : "modified");

   SysDclAst (&HTAdminEnd, rqptr);
}

/*****************************************************************************/
/*
*/

HTAdminUserDeleteForm
(
struct RequestStruct *rqptr,
char *DatabaseName,
char *UserName
)
{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Administer HTA Database</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Administer HTA Database</H3>\n\
\
<FORM METHOD=POST ACTION=\"!AZ\">\n\
<INPUT TYPE=hidden NAME=do VALUE=userdelete>\n\
<INPUT TYPE=hidden NAME=u VALUE=\"!HZ\">\n\
<P><TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1>\n\
<TR><TD ALIGN=left VALIGN=top>\n\
<NOBR>&nbsp;<B>User:</B>&nbsp;&nbsp;!AZ&nbsp;\
<B>in</B>&nbsp;!AZ&nbsp;&nbsp;&nbsp;\
<INPUT TYPE=submit VALUE=\" Delete !! \"></NOBR>\n\
<BR>\n\
<TABLE CELLPADDING=1 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right>&nbsp;Full Name:&nbsp;</TH><TD>!HZ</TD></TR>\n\
<TR><TH ALIGN=right VALIGN=top>&nbsp;Contact:&nbsp;</TH>\
<TD><PRE>!HZ</PRE></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
</FORM>\n\
\
</BODY>\n\
</HTML>\n";

   register unsigned long  *vecptr;
   register struct HTAdminTaskStruct  *tkptr;

   int  status;
   unsigned long  FaoVector [32];
   struct AuthHtRecordStruct AuthHtRecord;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminUserDeleteForm()\n");

   tkptr = rqptr->HTAdminTaskPtr;

   if (!DatabaseName || !UserName[0])
   {
      rqptr->rqResponse.HttpStatus = 400;
      ErrorGeneral (rqptr, ErrorHTAdminInsufficient, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /* look for the record, close the database file immediately */
   status = AuthAccessHtDatabase (false, DatabaseName, UserName,
                                  &AuthHtRecord, NULL, NULL);
   if (status == RMS$_EOF)
   {
      rqptr->rqResponse.HttpStatus = 404;
      ErrorGeneral (rqptr, ErrorHTAdminUserNotFound, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }
   if (VMSnok (status))
   {
      rqptr->rqResponse.ErrorTextPtr = ErrorHTAdminDatabase;
      rqptr->rqResponse.ErrorOtherTextPtr = DatabaseName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /**************/
   /* begin page */
   /**************/

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;
   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = AuthHtRecord.UserName;
   *vecptr++ = AuthHtRecord.UserName;
   *vecptr++ = DatabaseName;
   *vecptr++ = AuthHtRecord.FullName;
   if (AuthHtRecord.Contact[0])
      *vecptr++ = AuthHtRecord.Contact;
   else
      *vecptr++ = "(none)";

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (&HTAdminEnd, rqptr);
}

/*****************************************************************************/
/*
*/

HTAdminUserDelete
(
struct RequestStruct *rqptr,
char *DatabaseName,
char *UserName
)
{
   int  status;
   struct AuthHtRecordStruct AuthHtRecord;
   struct AuthCacheRecordStruct  AuthCacheRecord;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminUserDelete()\n");

   if (!rqptr->RemoteUser[0])
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_REQUIRED), FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   if (!DatabaseName[0] || !UserName[0])
   {
      rqptr->rqResponse.HttpStatus = 400;
      ErrorGeneral (rqptr, ErrorHTAdminInsufficient, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /* look for the record, leave the database file open if found */
   status = AuthAccessHtDatabase (true, DatabaseName, UserName,
                                  &AuthHtRecord, NULL, NULL);
   if (status == RMS$_EOF)
   {
      /* ensure the database is closed */
      AuthAccessHtDatabase (false, NULL, NULL, NULL, NULL, NULL);
      rqptr->rqResponse.HttpStatus = 404;
      ErrorGeneral (rqptr, ErrorHTAdminUserNotFound, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }
   if (VMSnok (status))
   {
      rqptr->rqResponse.ErrorTextPtr = ErrorHTAdminDatabase;
      rqptr->rqResponse.ErrorOtherTextPtr = DatabaseName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   memset (&AuthHtRecord, 0, sizeof(struct AuthHtRecordStruct));

   /* update the now zeroed record */
   status = AuthAccessHtDatabase (false, NULL, NULL,
                                  NULL, NULL, &AuthHtRecord);
   if (VMSnok (status))
   {
      rqptr->rqResponse.ErrorTextPtr = ErrorHTAdminDatabase;
      rqptr->rqResponse.ErrorOtherTextPtr = DatabaseName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /**************/
   /* successful */
   /**************/

   WriteFaoStdout ("%!AZ-I-AUTHHTA, !20%D, delete !AZ from !AZ by !AZ.\'!AZ\'@!AZ\n",
      Utility, 0, UserName, DatabaseName,
      rqptr->RemoteUser, rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

   /* reset relevant entries in the cache */
   if (VMSnok (AuthCacheReset (rqptr, DatabaseName, UserName)))
      return;

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   ReportSuccess (rqptr,
"<FONT COLOR=\"#ff0000\">Deleted</FONT> record for !HZ in !AZ at !AZ.",
                  UserName, DatabaseName, ServerHostPort);

   SysDclAst (&HTAdminEnd, rqptr);
}

/*****************************************************************************/
/*
Form for a user to change their own realm password.  The function that
actually performs the change, AuthPasswordChange(), is located in module
Auth.c
*/

HTAdminPasswordChangeForm (struct RequestStruct *rqptr)

{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>!AZ</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2>!AZ</H2>\n\
<P><FORM METHOD=POST ACTION=\"!AZ\">\n\
<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1>\n\
<TR><TH>!AZ.\'!HZ\'@!AZ</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=RIGHT>!AZ:</TH>\
<TD ALIGN=LEFT><INPUT TYPE=password SIZE=!UL MAXLENGTH=!UL NAME=cu></TD></TR>\n\
<TR><TH ALIGN=RIGHT>!AZ:</TH>\
<TD ALIGN=LEFT><INPUT TYPE=password SIZE=!UL MAXLENGTH=!UL NAME=p></TD></TR>\n\
<TR><TH ALIGN=RIGHT>!AZ:</TH>\
<TD ALIGN=LEFT><INPUT TYPE=password SIZE=!UL MAXLENGTH=!UL NAME=v></TD></TR>\n\
<TR><TD COLSPAN=2><INPUT TYPE=submit VALUE=\" !AZ \">\n\
<INPUT TYPE=reset VALUE=\" !AZ \"></TD></TR>\n\
</TABLE>\n\
</TABLE>\n\
</FORM>\n\
</BODY>\n\
</HTML>\n";

   register char  *cptr;
   register unsigned long  *vecptr;

   int  status;
   unsigned long  FaoVector [32];
   char  Scratch [256];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminPasswordChangeForm()\n");

   if (!rqptr->RemoteUser[0])
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_REQUIRED), FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   strcpy (cptr = Scratch, MsgFor(rqptr,MSG_HTADMIN_PWD_CHANGE));

   vecptr = FaoVector;

   *vecptr++ = HtmlMetaInfo (rqptr, NULL);

   /* "Change Authentication" x 2 */
   *vecptr++ = cptr;
   if (rqptr->ServicePtr->BodyTag[0])
      *vecptr++ = rqptr->ServicePtr->BodyTag;
   else
      *vecptr++ = Config.cfServer.ReportBodyTag;
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = rqptr->RemoteUser;
   *vecptr++ = rqptr->rqAuth.RealmDescrPtr;
   /* the user is dealing with the host/port they specified, not the base */
   *vecptr++ = rqptr->ServicePtr->ServerHostPort;

   /* "Current" */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';
   *vecptr++ = AUTH_MAX_PASSWORD_LENGTH;
   *vecptr++ = AUTH_MAX_PASSWORD_LENGTH;

   /* "New" */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';
   *vecptr++ = AUTH_MAX_PASSWORD_LENGTH;
   *vecptr++ = AUTH_MAX_PASSWORD_LENGTH;

   /* "Verify" */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';
   *vecptr++ = AUTH_MAX_PASSWORD_LENGTH;
   *vecptr++ = AUTH_MAX_PASSWORD_LENGTH;

   /* "Change" */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* "Reset" */
   *vecptr++ = cptr;
   while (*cptr && *cptr != '|') cptr++;
   if (*cptr) *cptr++ = '\0';

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (&HTAdminEnd, rqptr);
}

/*****************************************************************************/
/*
Changes a user's password in the on-disk HTA database or the SYSUAF database
(if realm is VMS).  User determined by 'rqptr->RemoteUser', database by
'rqptr->rqAuth.RealmPtr'.  The authorization cache is then searched for all
entries for the username and that realm and the password reset forcing it to be
revalidated the next time it is accessed. The form this request is generated by
comes from AdminPasswordChangeForm().

If the realm is VMS there _must_ be a group, as well as the realm associated
with change path.  This will normally be a site-chosen VMS rights identifier
that allows that particular account to modify it's password in such a manner. 
NOTE: The SYSUAF password change facility makes minor integrity checks on the
supplied password (length and characters contained) but does not enforce any
local password policy that may be in place.
*/

HTAdminPasswordChange
(
struct RequestStruct *rqptr,
char *PasswordCurrent,
char *PasswordNew,
char *PasswordVerify
)
{
   int  status;
   unsigned long  HashedPwd [2];
   unsigned char  A1DigestLoCase [16],
                  A1DigestUpCase [16];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminPasswordChange()\n");

   if (!rqptr->RemoteUser[0])
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_REQUIRED), FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /*******************/
   /* process request */
   /*******************/

   if (!(PasswordCurrent[0] && PasswordNew[0] && PasswordVerify[0]))
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_HTADMIN_PWD_INCOMPLETE), FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   if (!strsame (PasswordNew, PasswordVerify, -1))
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_HTADMIN_PWD_VERIFY), FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   if (strsame (PasswordCurrent, PasswordNew, -1))
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_HTADMIN_PWD_IDENTICAL), FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   if (strlen (PasswordNew) < AUTH_MIN_PASSWORD)
   {
      /* password's too short */
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_HTADMIN_PWD_ERROR), FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /* check the correct current password has been supplied */
   if (!strsame (PasswordCurrent, rqptr->RemoteUserPassword, -1))
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_HTADMIN_PWD_INCORRECT), FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   if (rqptr->rqAuth.SourceRealm == AUTH_SOURCE_VMS ||
       rqptr->rqAuth.SourceRealm == AUTH_SOURCE_ID ||
       rqptr->rqAuth.SourceRealm == AUTH_SOURCE_WASD_ID)
   {
      /*********************/
      /* update the SYSUAF */
      /*********************/

      static unsigned long  Context = -1;

      register char  *cptr, *sptr, *zptr;

      boolean  AccessAllowed;
      unsigned long  UaiPriv [2],
                     HashedPwd [2],
                     UaiPwd [2];
      unsigned short  UaiSalt;
      unsigned char  UaiEncrypt;
      char  PasswordUpperCase [AUTH_MAX_PASSWORD_LENGTH+1],
            UserNameUpperCase [AUTH_MAX_USERNAME_LENGTH+1];
      struct {
         short BufferLength;
         short ItemCode;
         void  *BufferPtr;
         void  *LengthPtr;
      } GetItems [] = 
      {
         { sizeof(UaiPwd), UAI$_PWD, &UaiPwd, 0 },
         { sizeof(UaiEncrypt), UAI$_ENCRYPT, &UaiEncrypt, 0 },
         { sizeof(UaiSalt), UAI$_SALT, &UaiSalt, 0 },
         { 0, 0, 0, 0 }
      },
        SetItems [] = 
      {
         { sizeof(HashedPwd), UAI$_PWD, &HashedPwd, 0 },
         { 0, 0, 0, 0 } 
      };
      $DESCRIPTOR (UserNameDsc, UserNameUpperCase);
      $DESCRIPTOR (PasswordDsc, PasswordUpperCase);

      /* double-check! */
      if (!AuthSysUafEnabled)
      {
         rqptr->rqResponse.HttpStatus = 403;
         ErrorGeneral (rqptr, MsgFor(rqptr,MSG_GENERAL_DISABLED), FI_LI);
         HTAdminEnd (rqptr);
         return;
      }

      if (AuthPolicySysUafRelaxed)
         AccessAllowed = true;
      else
      {
         /* was VMS or a VMS identifier and no group control identifier */
         if ((rqptr->rqAuth.SourceRealm == AUTH_SOURCE_VMS ||
              rqptr->rqAuth.SourceRealm == AUTH_SOURCE_ID) &&
              rqptr->rqAuth.SourceGroupWrite == AUTH_SOURCE_ID) 
            AccessAllowed = true;
         else
         /* deprecated WASD identifier and didn't have pwd change identifier */
         if (rqptr->rqAuth.SourceRealm == AUTH_SOURCE_WASD_ID &&
             rqptr->rqAuth.SysUafCanChangePwd)
            AccessAllowed = true;
         else
            AccessAllowed = false;
      }

      if (!AccessAllowed)
      {
         rqptr->rqResponse.HttpStatus = 403;
         ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_ACCESS_DENIED), FI_LI);
         HTAdminEnd (rqptr);
         return;
      }

      /* yet more checking! */
      zptr = (sptr = PasswordUpperCase) + sizeof(PasswordUpperCase)-1;
      cptr = PasswordNew; 
      while (*cptr && sptr < zptr)
      {
         if (!(isalnum(*cptr) || *cptr == '_' || *cptr == '$')) break;
         *sptr++ = toupper(*cptr++);
      }
      if (*cptr)
      {
         /* unacceptable character present */
         rqptr->rqResponse.HttpStatus = 403;
         ErrorGeneral (rqptr, MsgFor(rqptr,MSG_HTADMIN_PWD_ERROR), FI_LI);
         HTAdminEnd (rqptr);
         return;
      }
      *sptr = '\0';
      PasswordDsc.dsc$w_length = sptr - PasswordUpperCase;

      zptr = (sptr = UserNameUpperCase) + sizeof(UserNameUpperCase)-1;
      for (cptr = rqptr->RemoteUser;
           *cptr && sptr < zptr;
           *sptr++ = toupper(*cptr++));
      *sptr = '\0';
      UserNameDsc.dsc$w_length = sptr - UserNameUpperCase;

      /* turn on SYSPRV to allow access to SYSUAF records */
      EnableSysPrv();

      UserNameDsc.dsc$w_length = rqptr->RemoteUserLength;
      status = sys$getuai (0, &Context, &UserNameDsc, &GetItems, 0, 0, 0);
      if (Debug) fprintf (stdout, "sys$getuai() %%X%08.08X\n", status);

      /* turn off SYSPRV */
      DisableSysPrv();

      if (VMSnok (status)) 
      {
         rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_AUTH_USER);
         ErrorVmsStatus (rqptr, status, FI_LI);                      
         HTAdminEnd (rqptr);
         return;
      }

      status = sys$hash_password (&PasswordDsc, UaiEncrypt,
                                  UaiSalt, &UserNameDsc, &HashedPwd);
      if (Debug) fprintf (stdout, "sys$hash_password() %%X%08.08X\n", status);
      if (VMSnok (status))
      {
         rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_AUTH_USER);
         ErrorVmsStatus (rqptr, status, FI_LI);
         HTAdminEnd (rqptr);
         return;
      }

      /* turn on SYSPRV to allow access to SYSUAF records */
      EnableSysPrv();

      status = sys$setuai (0, 0, &UserNameDsc, &SetItems, 0, 0, 0);
      if (Debug) fprintf (stdout, "sys$setuai() %%X%08.08X\n", status);

      /* turn off SYSPRV */
      DisableSysPrv();

      if (VMSnok (status)) 
      {
         rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_AUTH_USER);
         ErrorVmsStatus (rqptr, status, FI_LI);
         HTAdminEnd (rqptr);
         return;
      }
   }
   else
   {
      /***************************/
      /* update the HTA database */
      /***************************/

      struct AuthHtRecordStruct AuthHtRecord;
      struct AuthCacheRecordStruct  AuthCacheRecord;

      if (VMSnok (status =
          AuthGenerateHashPassword (rqptr->RemoteUser, PasswordNew,
                                    &HashedPwd)))
      {
         rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_HTADMIN_PWD_ERROR);
         ErrorVmsStatus (rqptr, status, FI_LI);
         HTAdminEnd (rqptr);
         return;
      }

      if (VMSnok (status =
          AuthGenerateDigestPassword (rqptr->rqAuth.RealmDescrPtr,
                                      rqptr->RemoteUser,
                                      PasswordNew, &A1DigestLoCase,
                                      &A1DigestUpCase)))
      {
         rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_HTADMIN_PWD_ERROR);
         ErrorVmsStatus (rqptr, status, FI_LI);
         HTAdminEnd (rqptr);
         return;
      }

      /* look for the record, leave the database file open if found */
      status = AuthAccessHtDatabase (true, rqptr->rqAuth.RealmPtr,
                                     rqptr->RemoteUser,
                                     &AuthHtRecord, NULL, NULL);
      if (status == RMS$_EOF)
      {
         rqptr->rqResponse.HttpStatus = 404;
         rqptr->rqResponse.ErrorTextPtr =
            MsgFor(rqptr,MSG_HTADMIN_PWD_NOT_FOUND);
         HTAdminEnd (rqptr);
         return;
      }
      if (VMSnok (status))
      {
         rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_HTADMIN_DATABASE);
         rqptr->rqResponse.ErrorOtherTextPtr = rqptr->rqAuth.RealmPtr;
         ErrorVmsStatus (rqptr, status, FI_LI);
         HTAdminEnd (rqptr);
         return;
      }

      memcpy (&AuthHtRecord.HashedPwd, &HashedPwd, 8);
      memcpy (&AuthHtRecord.A1DigestLoCase, &A1DigestLoCase, 16);
      memcpy (&AuthHtRecord.A1DigestUpCase, &A1DigestUpCase, 16);
      memcpy (&AuthHtRecord.LastChangeBinTime, &rqptr->rqTime.Vms64bit, 8);
      AuthHtRecord.ChangeCount++;

      /* update the record, close the database file */
      status = AuthAccessHtDatabase (false, NULL, NULL, NULL, NULL,
                                     &AuthHtRecord);
      if (VMSnok (status))
      {
         rqptr->rqResponse.ErrorTextPtr = MsgFor(rqptr,MSG_HTADMIN_DATABASE);
         rqptr->rqResponse.ErrorOtherTextPtr = rqptr->rqAuth.RealmPtr;
         ErrorVmsStatus (rqptr, status, FI_LI);
         HTAdminEnd (rqptr);
         return;
      }
   }

   /**************/
   /* successful */
   /**************/

   /* report this to the log */
   WriteFaoStdout ("%!AZ-I-PASSWORD, !20%D, change !AZ.\'!AZ\'@!AZ\n",
      Utility, 0, rqptr->RemoteUser, rqptr->rqAuth.RealmDescrPtr,
      rqptr->rqNet.ClientHostName);

   /* and to the operator log if so enabled */
   if (OpcomMessages & OPCOM_AUTHORIZATION)
       WriteFaoOpcom ("%!AZ-I-PASSWORD, change !AZ.\'!AZ\'@!AZ",
          Utility, 0, rqptr->RemoteUser, rqptr->rqAuth.RealmDescrPtr,
          rqptr->rqNet.ClientHostName);

   /* reset this username for all realms in cache (overkill, but it works)*/
   if (VMSnok (AuthCacheReset (rqptr, "", rqptr->RemoteUser)))
      return;

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   /* the user is dealing with the host/port they specified, not the base */
   ReportSuccess (rqptr, MsgFor(rqptr,MSG_HTADMIN_PWD_BEEN_CHANGED),
                  "!AZ.\'!HZ\'@!AZ", rqptr->RemoteUser,
                  rqptr->rqAuth.RealmDescrPtr, rqptr->ServicePtr->ServerHostPort);

   SysDclAst (&HTAdminEnd, rqptr);
}

/*****************************************************************************/
/*
Reset an entry in the authentication cache. The cache is searched for all
entries for the username and realm with the failure count and password reset
forcing it to be revalidated the next time it is accessed.
*/

HTAdminCachePurge (struct RequestStruct *rqptr)

{
   register char  *cptr;

   int  status;
   struct AuthCacheRecordStruct  AuthCacheRecord;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminCachePurge()\n");

   if (!rqptr->RemoteUser[0])
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_REQUIRED), FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /* purge (release memory) for the entire cache */
   if (VMSnok (status = AuthCacheTreeFree ()))
   {
      rqptr->rqResponse.ErrorTextPtr = ErrorHTAdminPurgeCache;
      ErrorVmsStatus (rqptr, status, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /* report this to the log */
   WriteFaoStdout (
"%!AZ-I-AUTHCACHE, !20%D, purge authorization cache by !AZ.\'!AZ\'@!AZ\n",
      Utility, 0, rqptr->RemoteUser, rqptr->rqAuth.RealmPtr,
      rqptr->rqNet.ClientHostName);

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   ReportSuccess (rqptr, "Purge of !AZ authorization cache.", ServerHostPort);

   SysDclAst (&HTAdminEnd, rqptr);
}

/*****************************************************************************/
/*
Set string text according to capability bits in on-disk HTA database.  These
may be different to the bits in the authorization capability vector, reported
by AuthCanString().
*/

char* HTAdminCanString
(
struct RequestStruct *rqptr,
unsigned long CanFlags,
boolean Brief
)
{
   static $DESCRIPTOR (CanBriefFaoDsc, "!AZ\0");
   static $DESCRIPTOR (CanFullFaoDsc, "!AZ!AZ!AZ!AZ!AZ!AZ!AZ!AZ\0");
   static char  Buffer [128];
   static $DESCRIPTOR (BufferDsc, Buffer);

   register unsigned long  *vecptr;

   int  status;
   unsigned long  FaoVector [32];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminCanString()\n");

   vecptr = FaoVector;

   if ((CanFlags & AUTH_FLAG_DELETE ||
        CanFlags & AUTH_FLAG_POST ||
        CanFlags & AUTH_FLAG_PUT) &&
       CanFlags & AUTH_FLAG_GET)
      *vecptr++ = "read <B>+ write</B>";
   else
   if ((CanFlags & AUTH_FLAG_DELETE ||
        CanFlags & AUTH_FLAG_POST ||
        CanFlags & AUTH_FLAG_PUT))
      *vecptr++ = "write-only";
   else
   if (CanFlags & AUTH_FLAG_GET)
      *vecptr++ = "read-only";
   else
      *vecptr++ = "<I>none!</I>";

   if (Brief)
      status = sys$faol (&CanBriefFaoDsc, 0, &BufferDsc, &FaoVector);
   else
   {
      if (CanFlags & AUTH_FLAG_DELETE ||
          CanFlags & AUTH_FLAG_GET ||
          CanFlags & AUTH_FLAG_HEAD ||
          CanFlags & AUTH_FLAG_POST ||
          CanFlags & AUTH_FLAG_PUT)
         *vecptr++ = " <FONT SIZE=1><NOBR>( ";
      else
         *vecptr++ = "";
      if (CanFlags & AUTH_FLAG_DELETE)
         *vecptr++ = " DELETE";
      else
         *vecptr++ = "";
      if (CanFlags & AUTH_FLAG_GET)
         *vecptr++ = " GET";
      else
         *vecptr++ = "";
      if (CanFlags & AUTH_FLAG_HEAD)
         *vecptr++ = " HEAD";
      else
         *vecptr++ = "";
      if (CanFlags & AUTH_FLAG_POST)
         *vecptr++ = " POST";
      else
         *vecptr++ = "";
      if (CanFlags & AUTH_FLAG_PUT)
         *vecptr++ = " PUT";
      else
         *vecptr++ = "";
      if (CanFlags & AUTH_FLAG_DELETE ||
          CanFlags & AUTH_FLAG_GET ||
          CanFlags & AUTH_FLAG_HEAD ||
          CanFlags & AUTH_FLAG_POST ||
          CanFlags & AUTH_FLAG_PUT)
         *vecptr++ = " )</NOBR></FONT>";
      else
         *vecptr++ = "";

      status = sys$faol (&CanFullFaoDsc, 0, &BufferDsc, &FaoVector);
   }

   if (VMSnok (status) || status == SS$_BUFFEROVF)
   {
      rqptr->rqResponse.ErrorTextPtr = "sys$faol()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      return (NULL);
   }
   return (Buffer);
}

/*****************************************************************************/
/*
*/

HTAdminDatabaseCreateForm
(
struct RequestStruct *rqptr,
char *DatabaseName
)
{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Administer HTA Database</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Administer HTA Database</H3>\n\
\
<FORM METHOD=POST ACTION=\"!AZ\">\n\
<INPUT TYPE=hidden NAME=do VALUE=htacreate>\n\
<P><TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1>\n\
<TR><TD ALIGN=right VALIGN=top>\n\
<NOBR>&nbsp;<B>Database:</B>&nbsp;&nbsp;!AZ&nbsp;&nbsp;&nbsp;\
<INPUT TYPE=submit VALUE=\" Create \"></NOBR>\n\
</TD></TR>\n\
</TABLE>\n\
</FORM>\n\
\
</BODY>\n\
</HTML>\n";

   register unsigned long  *vecptr;
   register struct HTAdminTaskStruct  *tkptr;

   int  status;
   unsigned long  FaoVector [32];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminDatabaseCreateForm()\n");

   tkptr = rqptr->HTAdminTaskPtr;

   if (!DatabaseName)
   {
      rqptr->rqResponse.HttpStatus = 400;
      ErrorGeneral (rqptr, ErrorHTAdminInsufficient, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;
   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = DatabaseName;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (&HTAdminEnd, rqptr);
}

/*****************************************************************************/
/*
*/

HTAdminDatabaseCreate
(
struct RequestStruct *rqptr,
char *DatabaseName,
char *UserName
)
{
   static $DESCRIPTOR (AuthFileNameFaoDsc, "!AZ!AZ!AZ");

   register struct HTAdminTaskStruct  *tkptr;

   int  status,
        EraseCount;
   unsigned short  AuthFileNameLength,
                   Length;
   char  AuthFileName [256];
   struct AuthHtRecordStruct AuthHtRecord;
   $DESCRIPTOR (AuthFileNameDsc, AuthFileName);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminDatabaseCreate()\n");

   tkptr = rqptr->HTAdminTaskPtr;

   if (!rqptr->RemoteUser[0])
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_REQUIRED), FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   if (!DatabaseName[0])
   {
      rqptr->rqResponse.HttpStatus = 400;
      ErrorGeneral (rqptr, ErrorHTAdminInsufficient, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   sys$fao (&AuthFileNameFaoDsc, &AuthFileNameLength, &AuthFileNameDsc,
            HTA_DIRECTORY, DatabaseName, HTA_FILE_TYPE);
   AuthFileName[AuthFileNameLength] = '\0';

   OdsParse (&tkptr->FileOds,
             AuthFileName, AuthFileNameLength, NULL, 0,
             0, NULL, rqptr);

   if (VMSok (status = tkptr->FileOds.Fab.fab$l_sts))
   {
      OdsSearch (&tkptr->FileOds, NULL, rqptr);
      status = tkptr->FileOds.Fab.fab$l_sts;
   }

   if (VMSnok (status) && status != RMS$_FNF)
   {
      rqptr->rqResponse.ErrorTextPtr = ErrorHTAdminDatabase;
      rqptr->rqResponse.ErrorOtherTextPtr = DatabaseName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }
   else
   if (VMSok (status))
   {
      /* ensure parse internal data structures are released */
      OdsParseRelease (&tkptr->FileOds);
      rqptr->rqResponse.HttpStatus = 409;
      ErrorGeneral (rqptr, ErrorHTAdminDatabaseExists, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /* OK, now carefully adjust some of the data in the RMS structures */
   tkptr->FileOds.Fab.fab$l_fop = FAB$M_SQO;
   tkptr->FileOds.Fab.fab$w_mrs = sizeof(struct AuthHtRecordStruct);
   tkptr->FileOds.Fab.fab$b_rfm = FAB$C_FIX;
   tkptr->FileOds.Fab.fab$l_xab = &tkptr->FileOds.XabPro;

   tkptr->FileOds.XabPro = cc$rms_xabpro;
   /* ownded by SYSTEM ([1,4]) */
   tkptr->FileOds.XabPro.xab$w_grp = 1;
   tkptr->FileOds.XabPro.xab$w_mbm = 4;
   tkptr->FileOds.XabPro.xab$l_nxt = 0;
   /* w:,g:,o:rwed,s:rwed */
   tkptr->FileOds.XabPro.xab$w_pro = 0xff00;

   /* use SYSPRV to ensure creation of database file */
   EnableSysPrv();
   status = sys$create (&tkptr->FileOds.Fab, 0, 0);
   DisableSysPrv();

   /* sys$create() status */
   if (VMSnok (status))
   {
      rqptr->rqResponse.ErrorTextPtr = ErrorHTAdminDatabase;
      rqptr->rqResponse.ErrorOtherTextPtr = DatabaseName;
      ErrorVmsStatus (rqptr, tkptr->FileOds.Fab.fab$l_stv, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   OdsClose (&tkptr->FileOds, NULL, 0);
   if (VMSnok (status = tkptr->FileOds.Fab.fab$l_sts))
   {
      rqptr->rqResponse.ErrorTextPtr = ErrorHTAdminDatabase;
      rqptr->rqResponse.ErrorOtherTextPtr = DatabaseName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /**************/
   /* successful */
   /**************/

   WriteFaoStdout ("%!AZ-I-AUTHHTA, !20%D, create !AZ by !AZ.\'!AZ\'@!AZ\n",
      Utility, 0, DatabaseName,
      rqptr->RemoteUser, rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   ReportSuccess (rqptr, "Created !AZdatabase !AZ at !AZ",
                  tkptr->FileOds.Nam_fnb & NAM$M_LOWVER ?
                  "<FONT COLOR=\"#ff0000\">new version</FONT> of " : "",
                  DatabaseName, ServerHostPort);

   SysDclAst (&HTAdminEnd, rqptr);
}

/*****************************************************************************/
/*
*/

HTAdminDatabaseDeleteForm
(
struct RequestStruct *rqptr,
char *DatabaseName
)
{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Administer HTA Database</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Administer HTA Database</H3>\n\
\
<FORM METHOD=POST ACTION=\"!AZ\">\n\
<INPUT TYPE=hidden NAME=do VALUE=htadelete>\n\
<P><TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1>\n\
<TR><TD ALIGN=right VALIGN=top>\n\
<NOBR>&nbsp;<B>Database:</B>&nbsp;&nbsp;!AZ&nbsp;&nbsp;&nbsp;\
<INPUT TYPE=submit VALUE=\" Delete !! \"></NOBR>\n\
</TD></TR>\n\
</TABLE>\n\
</FORM>\n\
\
</BODY>\n\
</HTML>\n";

   register unsigned long  *vecptr;
   register struct HTAdminTaskStruct  *tkptr;

   int  status;
   unsigned long  FaoVector [32];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminDatabaseDeleteForm()\n");

   tkptr = rqptr->HTAdminTaskPtr;

   if (!DatabaseName)
   {
      rqptr->rqResponse.HttpStatus = 400;
      ErrorGeneral (rqptr, ErrorHTAdminInsufficient, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;
   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = rqptr->rqHeader.PathInfoPtr;
   *vecptr++ = DatabaseName;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (&HTAdminEnd, rqptr);
}

/*****************************************************************************/
/*
*/

HTAdminDatabaseDelete
(
struct RequestStruct *rqptr,
char *DatabaseName,
char *UserName
)
{
   static $DESCRIPTOR (AuthFileNameFaoDsc, "!AZ!AZ!AZ");

   register char  *cptr, *sptr;
   register struct HTAdminTaskStruct  *tkptr;

   int  status,
        EraseCount;
   unsigned short  AuthFileNameLength,
                   Length;
   char  AuthFileName [256];
   $DESCRIPTOR (AuthFileNameDsc, AuthFileName);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminDatabaseDelete()\n");

   tkptr = rqptr->HTAdminTaskPtr;

   if (!rqptr->RemoteUser[0])
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_REQUIRED), FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   if (!DatabaseName[0])
   {
      rqptr->rqResponse.HttpStatus = 400;
      ErrorGeneral (rqptr, ErrorHTAdminInsufficient, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   sys$fao (&AuthFileNameFaoDsc, &AuthFileNameLength, &AuthFileNameDsc,
            HTA_DIRECTORY, DatabaseName, HTA_FILE_TYPE);
   AuthFileName[AuthFileNameLength] = '\0';

   OdsParse (&tkptr->FileOds,
             AuthFileName, AuthFileNameLength, NULL, 0,
             0, NULL, rqptr);

   if (VMSok (status = tkptr->FileOds.Fab.fab$l_sts))
   {
      tkptr->FileOds.NamVersionPtr[0] = '\0'; 
      if (Debug)
         fprintf (stdout, "ExpFileName |%s|\n", tkptr->FileOds.ExpFileName);

      /* turn on SYSPRV to allow deletion of database file */
      EnableSysPrv();

      EraseCount = 0;
      while (VMSok (status = sys$erase (&tkptr->FileOds.Fab, 0, 0)))
          EraseCount++;
      if (status == RMS$_FNF && EraseCount) status = SS$_NORMAL;

      DisableSysPrv();
   }

   /* ensure parse internal data structures are released */
   OdsParseRelease (&tkptr->FileOds);

   if (VMSnok (status))
   {
      rqptr->rqResponse.ErrorTextPtr = ErrorHTAdminDatabase;
      rqptr->rqResponse.ErrorOtherTextPtr = DatabaseName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      HTAdminEnd (rqptr);
      return;
   }

   /**************/
   /* successful */
   /**************/

   WriteFaoStdout ("%!AZ-I-AUTHHTA, !20%D, delete !AZ by !AZ.\'!AZ\'@!AZ\n",
      Utility, 0, DatabaseName,
      rqptr->RemoteUser, rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

   /* reset relevant entries in the cache */
   if (VMSnok (AuthCacheReset (rqptr, DatabaseName, "")))
      return;

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   ReportSuccess (rqptr,
"<FONT COLOR=\"#ff0000\">Deleted</FONT> database !AZ at !AZ.",
                  DatabaseName, ServerHostPort);

   SysDclAst (&HTAdminEnd, rqptr);
}

/*****************************************************************************/
/*
*/

HTAdminOpenDatabaseForRead
(
struct RequestStruct *rqptr,
char *DatabaseName
)
{
   static $DESCRIPTOR (AuthFileNameFaoDsc, "!AZ!AZ!AZ");

   register struct HTAdminTaskStruct  *tkptr;

   int  status;
   unsigned short  Length;
   $DESCRIPTOR (AuthFileNameDsc, "");

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HTAdminOpenDatabaseForRead()\n");

   tkptr = rqptr->HTAdminTaskPtr;

   AuthFileNameDsc.dsc$a_pointer = tkptr->AuthFileName;
   AuthFileNameDsc.dsc$w_length = sizeof(tkptr->AuthFileName)-1;

   status = sys$fao (&AuthFileNameFaoDsc, &Length, &AuthFileNameDsc,
                     HTA_DIRECTORY, DatabaseName, HTA_FILE_TYPE);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
   {
      rqptr->rqResponse.ErrorTextPtr = "sys$fao()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      HTAdminEnd (rqptr);
      return (status & 0xfffffffe);
   }
   tkptr->AuthFileName[Length] = '\0';
   if (Debug) fprintf (stdout, "AuthFileName |%s|\n", tkptr->AuthFileName);

   /* turn on SYSPRV to allow access to authentication Database file */
   EnableSysPrv();
   OdsOpen (&tkptr->FileOds, tkptr->AuthFileName, Length, NULL, 0, 0,
            FAB$M_GET, FAB$M_SHRGET | FAB$M_SHRPUT | FAB$M_SHRUPD,
            NULL, rqptr);  
   DisableSysPrv();

   if (VMSnok (status = tkptr->FileOds.Fab.fab$l_sts))
   {
      rqptr->rqResponse.ErrorTextPtr = ErrorHTAdminDatabase;
      rqptr->rqResponse.ErrorOtherTextPtr = DatabaseName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      HTAdminEnd (rqptr);
      return (status);
   }

   tkptr->FileOds.Rab = cc$rms_rab;
   tkptr->FileOds.Rab.rab$l_ctx = rqptr;
   tkptr->FileOds.Rab.rab$l_fab = &tkptr->FileOds.Fab;
   /* 2 buffers of thiry-two blocks each */
   tkptr->FileOds.Rab.rab$b_mbc = 32;
   tkptr->FileOds.Rab.rab$b_mbf = 2;
   /* read ahead performance option */
   tkptr->FileOds.Rab.rab$l_rop = RAB$M_RAH;
   tkptr->FileOds.Rab.rab$l_ubf = &tkptr->AuthHtRecord;
   tkptr->FileOds.Rab.rab$w_usz = sizeof(struct AuthHtRecordStruct);

   if (VMSnok (status = sys$connect (&tkptr->FileOds.Rab, 0, 0)))
   {
      if (Debug) fprintf (stdout, "sys$connect() %%X%08.08X\n", status);
      rqptr->rqResponse.ErrorTextPtr = MapVmsPath (tkptr->AuthFileName, rqptr);
      rqptr->rqResponse.ErrorOtherTextPtr = tkptr->AuthFileName;
      ErrorVmsStatus (rqptr, status, FI_LI);
      HTAdminEnd (rqptr);
      return (status);
   }

   return (status);
}

/****************************************************************************/

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          