/*****************************************************************************/
/*
                                  Config.h

Function prototypes for configuration module.

*/
/*****************************************************************************/

#ifndef CONFIG_H_LOADED
#define CONFIG_H_LOADED 1

#ifndef ODSSTRUCT_H_LOADED
#   include "odsstruct.h"
#endif

#ifndef TRACK_H_LOADED
#   include "track.h"
#endif

#include "wasd.h"

/* must be powers of two! */
#define CONTENT_TYPE_HASH_TABLE_SIZE  128
#define CONTENT_TYPE_HASH_TABLE_MASK  CONTENT_TYPE_HASH_TABLE_SIZE-1
#define ICON_HASH_TABLE_SIZE          64
#define ICON_HASH_TABLE_MASK          ICON_HASH_TABLE_SIZE-1

/**********************************/
/* config authorization structure */
/**********************************/

struct ConfigAuthStruct
{
   boolean  BasicEnabled,
            DigestEnabled,
            RevalidateLoginCookie;
   int  CacheMinutes,
        DigestNonceGetLifeTime,
        DigestNoncePutLifeTime,
        FailureLimit,
        RevalidateUserMinutes;
};

/********************************/
/* config buffer size structure */
/********************************/

struct ConfigBufferStruct
{
   int  SizeDclCommand,
        SizeDclOutput,
        SizeDclCgiPlusIn,
        SizeNetRead,
        SizeNetWrite;
};

/**************************/
/* config cache structure */
/**************************/

struct ConfigCacheStruct
{
   boolean  Enabled;
   int  EntriesMax,
        ChunkKBytes,
        FileKBytesMax,
        FrequentHits,
        FrequentSeconds,
        HashTableEntries,
        TotalKBytesMax,
        ValidateSeconds;
};

/****************************/
/* config content structure */
/****************************/

struct ConfigContentStruct
{
   int  ContentInfoStructOverhead,
        HomePageCount,
        IconStructOverhead;
   char  *ContentTypeDefaultPtr;
   char  CharsetDefault [32];
   char  *HomePageArray [CONFIG_HOME_PAGES_MAX];
   struct ContentInfoStruct  *ContentInfoListHeadPtr,
                             *ContentInfoListTailPtr;
   struct IconStruct  *IconListHeadPtr,
                      *IconListTailPtr;
   struct ContentInfoStruct
      *ContentInfoHashTable [CONTENT_TYPE_HASH_TABLE_SIZE];
   struct IconStruct *IconHashTable [ICON_HASH_TABLE_SIZE];
};

/************************/
/* config dir structure */
/************************/

struct ConfigDirStruct
{
   boolean  Access,
            AccessSelective,
            MetaInfoEnabled,
            NoImpliedWildcard,
            NoPrivIgnore,
            OwnerEnabled,
            PreExpired,
            ReadMeBottom,
            ReadMeTop,
            WildcardEnabled;
   int  DescriptionLines,
        ReadMeFileCount;
   char  DefaultLayout [32],
         BodyTag [256];
   char  *ReadMeFileArray [CONFIG_README_FILES_MAX];
};

/****************************/
/* config logging structure */
/****************************/

struct ConfigLogStruct
{
   boolean  Enabled,
            PerService,
            PerServiceHostOnly;
   int  ExcludeHostsLength;
   char  *ExcludeHostsPtr;
   char  FileName [128],
         Format [128],
         Naming [32],
         Period [32];
};

/**********************************/
/* config miscellaneous structure */
/**********************************/

struct ConfigMiscStruct
{
   boolean  DnsLookup,
            MonitorEnabled;
   int  ActivityNumberOfDays,
        MapUserNameCacheEntries,
        PersonaCacheEntries,
        PutMaxKbytes,
        PutVersionLimit,
        RequestHistory,
        StreamLfConversionMaxKbytes;
};

/**************************/
/* config OPCOM structure */
/**************************/

struct ConfigOpcomStruct
{
   int  Index,
        Messages,
        Target;
};

/**********************************/
/* config proxy serving structure */
/**********************************/

struct ConfigProxyStruct
{
   boolean  AddForwardedByEnabled,
            CacheEnabled,
            ReportCacheLog,
            ReportLog,
            ServingEnabled;
   int  CacheDeviceMaxPercent,
        CacheDevicePurgePercent,
        CacheDeviceCheckMinutes,
        CacheDeviceDirOrg,
        CacheFileKBytesMax,
        CacheRoutineHourOfDay,
        HostCachePurgeHours,
        HostLookupRetryCount;
   char  CachePurgeList [64],
         CacheReloadList [64];
};

/***************************/
/* config report structure */
/***************************/

struct ConfigReportStruct
{
   boolean  ErrorRecommend,
            BasicOnly,
            MetaInfoEnabled;
   int  ErrorReportPathLength;
   char  ErrorReportPath [128];
};

/******************************/
/* config scripting structure */
/******************************/

struct ConfigRunTimeStruct
{
   int  FileTypeLength;
   char  String [128];   
};

struct ConfigScriptStruct
{
   boolean  CgiStrictOutput,
            DetachProcess,
            Enabled,
            FullRequest,
            GatewayBg,
            SpawnAuthPriv;
   int  CgiPlusLifeTime,
        CleanupScratchMinutesMax,
        CleanupScratchMinutesOld,
        DECnetConnectListMax,
        DECnetReuseLifeTime,
        DefaultSearchLength,
        DefaultSearchExcludeLength,
        RunTimeCount,
        ScriptProcessHardLimit,
        ScriptProcessSoftLimit,
        ZombieLifeTime;
   char  *DefaultSearchExcludePtr;
   char  DetachProcessPriority [32],
         DefaultSearch [128];
   struct ConfigRunTimeStruct RunTime  [CONFIG_SCRIPT_RUNTIME_MAX];
};

/***************************/
/* config server structure */
/***************************/

struct ConfigServerStruct
{
   int  AcceptHostsLength,
        BusyLimit,
        DefaultPort,
        ListenBacklog,
        RejectHostsLength,
        Signature,
        ServiceLength;
   char  *AcceptHostsPtr,
         *RejectHostsPtr,
         *ServicePtr;
   char  AdminEmail [64],
         AdminBodyTag [256],
         ReportBodyTag [256],
         ServiceNotFoundUrl [128];
};

/*****************************************/
/* config Server Side Includes structure */
/*****************************************/

struct ConfigSsiStruct
{
   boolean  Enabled,
            AccessesEnabled,
            ExecEnabled;
};

/****************************/
/* config timeout structure */
/****************************/

struct ConfigTimeoutStruct
{
   int  MinutesInput,
        MinutesNoProgress,
        MinutesOutput,
        SecondsKeepAlive;
};

/**************************/
/* config track structure */
/**************************/

struct ConfigTrackStruct
{
   boolean  Enabled,
            MultiSession;
   char  Domain [TRACK_DOMAIN_SIZE];
};

/***************************/
/* configuration structure */
/***************************/

struct ConfigStruct
{
   struct ConfigAuthStruct    cfAuth;
   struct ConfigBufferStruct  cfBuffer;
   struct ConfigCacheStruct   cfCache;
   struct ConfigContentStruct cfContent;
   struct ConfigDirStruct     cfDir;
   struct ConfigLogStruct     cfLog;
   struct ConfigMiscStruct    cfMisc;
   struct ConfigOpcomStruct   cfOpcom;
   struct ConfigProxyStruct   cfProxy;
   struct ConfigReportStruct  cfReport;
   struct ConfigScriptStruct  cfScript;
   struct ConfigServerStruct  cfServer;
   struct ConfigSsiStruct     cfSsi;
   struct ConfigTimeoutStruct cfTimeout;
   struct ConfigTrackStruct   cfTrack;

   /* basically only used while reading configuration from file */
   int  LineNumber,
        ProblemCount,
        ProblemReportLength;
   char  *ProblemReportPtr;
   char  DirectiveName [64],
         LoadFileName [ODS_MAX_FILE_NAME_LENGTH+1];
   unsigned long  LoadBinTime [2],
                  RevBinTime [2];

   /* only used when reporting or changing configuration */
   void  *RequestPtr;
};

/***********************/
/* function prototypes */
/***********************/

Configure (struct ConfigStruct*);
boolean ConfigAcceptClientHostName (char*, char*);
ConfigAddType (struct ConfigStruct*, char*);
char* ConfigCommaList (struct RequestStruct*, char*, char);
char* ConfigContentType (struct ContentInfoStruct*, char*);
ConfigContentTypeIcon (struct ConfigStruct*);
char* ConfigHomePage (int);
ConfigAddIcon (struct ConfigStruct*, char*);
char* ConfigIconFor (char*);
char* ConfigReadMeFile (int);
ConfigReport (struct RequestStruct*, void*, boolean);
ConfigRevise (struct RequestStruct*, void*, boolean);
boolean ConfigSameContentType (char*, char*, int);
ConfigSetAccept (struct ConfigStruct*, char*);
ConfigSetCommaList (struct ConfigStruct*, char*, char**, int*);
ConfigSetDirReadMe (struct ConfigStruct*, char*);
ConfigSetDirReadMeFile (struct ConfigStruct*, char*);
ConfigSetReject (struct ConfigStruct*, char*);
ConfigSetWelcome (struct ConfigStruct*, char*);

#endif /* CONFIG_H_LOADED */

/*****************************************************************************/
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    